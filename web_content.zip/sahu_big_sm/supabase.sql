-- Run this in Supabase SQL Editor. Creates secure user profiles and free-game history.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  role text not null default 'player' check (role in ('player','admin')),
  demo_points integer not null default 100 check (demo_points >= 0),
  created_at timestamptz not null default now()
);
create table if not exists public.rounds (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  choice text not null check (choice in ('BIG','SMALL')),
  number integer not null check (number between 0 and 9),
  result text not null check (result in ('WIN','LOSE')),
  created_at timestamptz not null default now()
);
alter table public.profiles enable row level security;
alter table public.rounds enable row level security;

create policy "players read own profile" on public.profiles
for select to authenticated using (auth.uid() = id);
create policy "players read own rounds" on public.rounds
for select to authenticated using (auth.uid() = user_id);
create policy "players insert own rounds" on public.rounds
for insert to authenticated with check (auth.uid() = user_id);

-- Automatically create a profile when someone registers.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id,email) values (new.id,new.email);
  return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

-- IMPORTANT: Promote your own account to admin manually after registering:
-- update public.profiles set role='admin' where email='YOUR-ADMIN-EMAIL';
-- Run that statement only for the email address you control.
-- Do not expose service_role keys in browser code.
