# SAHU BIG SM — Free online Big/Small game

This is a mobile-friendly starter website. It uses Supabase Auth + Postgres for online accounts and saved rounds. The game is free entertainment only: no deposits, withdrawals, cash prizes, or real-money betting.

## Setup
1. Create a Supabase project at https://supabase.com/.
2. Open SQL Editor and run all of `supabase.sql`.
3. In Project Settings → API, copy the Project URL and anon/public key into `config.js`.
4. Register your account on the site. Confirm your email if confirmation is enabled.
5. In Supabase SQL Editor, promote your own account to admin by running the final UPDATE statement in `supabase.sql` with your email.
6. Deploy this folder to a static host such as Netlify, Vercel, or Cloudflare Pages. Upload the files in this folder; set the published directory to the project root.

## Security notes
- Never put a Supabase `service_role` key in `config.js`.
- Enable email confirmation and configure your production auth URL/redirect URLs in Supabase.
- The browser game uses `crypto.getRandomValues` for a random digit. The browser submits the round record; for a production competitive game, move outcome generation into a trusted server-side function and add rate limiting / anti-abuse checks.
- This starter's admin area is intentionally minimal. Admin role is assigned manually in SQL, not by public signup.
- Demo points are not redeemable and have no cash value.

## Included
- Email/password signup and login
- User profile with demo points
- Big (5–9) / Small (0–4) free game
- Saved personal round history
- Basic admin role indicator
