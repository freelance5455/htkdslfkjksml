LoanDesk updated HTML project

Updates in this version:
- Customer search by name, mobile number, and linked Loan ID.
- Loan search by Loan ID, customer name, and mobile number.
- Loan cards display their Loan ID.
- WhatsApp new-loan confirmation, statement, and payment reminder messages use proper line breaks and a structured readable layout.
- WhatsApp messages include customer and loan identifiers where applicable.

APKForge:
1. Create/open your HTML-to-APK project.
2. Replace the existing index.html with this index.html.
3. Keep internet access enabled if you want WhatsApp links to open WhatsApp.
4. Build a new APK and install/update it.

Important: Keep a LoanDesk JSON backup before replacing the app. Existing localStorage data may not automatically carry over if the APK wrapper changes its app storage origin/package configuration.
