MrSearch — Android project

Це готовий Android Studio / онлайн-збірник проєкт.

Головна HTML-сторінка: app/src/main/assets/index.html
Application ID: com.mrsmileys.mrsearch
Compile/Target SDK: 35

Для Android Studio:
1. Відкрий цю папку як Project.
2. Дочекайся Gradle Sync.
3. Build → Generate App Bundles or APKs → Generate APKs.

Для онлайн-збірника:
1. Завантаж ZIP цілком.
2. Обери APK / Debug APK, якщо є вибір.
3. Натисни Build.

Важливо: ZIP вже має settings.gradle у корені, а не всередині додаткової папки.
