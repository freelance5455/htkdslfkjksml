TOUCHLINE - Football Tracker Prototype
Files:
- index.html: mobile-first app prototype

Features:
- Dashboard and XP/level
- Log goals (+30 XP) and assists (+20 XP)
- Match event history
- Sample friend leaderboard
- Training drills (+20 XP) and daily challenge (+25 XP)
- Player name editor
- Local browser/device storage

Limitations:
This is a local prototype. Friends are demo entries and do not sync between phones.
Real accounts, friend requests, live shared stats and online leaderboard require backend/database.
