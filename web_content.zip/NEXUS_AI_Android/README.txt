NEXUS AI — projeto-fonte Android

O ZIP contém um projeto Android Studio com WebView e a interface NEXUS AI em app/src/main/assets/index.html.

COMO GERAR O APK
1. Instale o Android Studio em um computador.
2. Abra a pasta NexusAI (a pasta que contém settings.gradle).
3. Aguarde a sincronização do Gradle.
4. Se necessário, instale o Android SDK 35 pelo SDK Manager.
5. Use Build > Build Bundle(s) / APK(s) > Build APK(s).
6. O APK de teste será gerado em app/build/outputs/apk/debug/app-debug.apk.

IMPORTANTE
- Este ambiente não compilou o APK; o arquivo entregue é o projeto-fonte Android pronto para abrir no Android Studio.
- O editor aceita várias linguagens como texto, mas a prévia de execução incluída é apenas para HTML.
- Modo offline é básico; IA generativa offline exige integrar e distribuir um modelo local compatível.
- Modo online exige um endpoint de servidor próprio que receba POST {"message":"..."} e responda {"reply":"..."}.
- Não inclua chaves secretas de API no HTML ou no APK.
