PAINEL FORCE — PASTA DE EXTENSÕES

Esta pasta é um local organizado para futuras integrações legítimas do projeto.
Não coloque credenciais secretas aqui: os arquivos do site/APK podem ser extraídos.

Podem ser adicionados módulos para:
- preferências e perfis de desempenho do Android;
- ferramentas de treino independentes do jogo;
- integração com APIs próprias, chamadas por um backend seguro.

Não incluí código de aimbot, injeção, manipulação de memória ou alteração do Free Fire.
Esses recursos não são implementados por um site comum e podem comprometer a conta/dispositivo.

A tela administrativa atual é uma demonstração local: a senha e a lista de keys estão no código/armazenamento do navegador. NÃO use esta versão para distribuir acesso pago ou sensível. Para validar e revogar keys entre dispositivos, implemente um backend HTTPS com autenticação e banco de dados.
