# V55 — Excel Android Picker Chooser Fix

Based on V54. The V54 native picker could silently fail on some TECNO/Android builds because it launched GET_CONTENT/OPEN_DOCUMENT directly and assumed a successful `startActivityForResult()` meant the picker UI appeared.

V55 changes:
- Uses Android's user-facing `Intent.createChooser()` around the file-picking intent.
- Lets the installed file manager resolve Excel/CSV selection instead of forcing a guessed DocumentsUI package.
- Supplies explicit Excel/CSV/text MIME types.
- Keeps the native Android import/parser path.
- Handles the fallback request code correctly in `onActivityResult()`.
- Version 2.23 / versionCode 27.
