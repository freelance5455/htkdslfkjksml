# MIKU · Quest Log (Installable App)

A cute quest & habit tracker that works like a real phone app.

## What you get
- Quests with EXP and levels
- Workouts, meals, sleep tracking
- Journal + badges
- Data stays on the phone (even after closing the app)
- Offline support
- Add to Home Screen on Android & iPhone

## How to install on a phone (recommended)

### Option A – Easiest (GitHub Pages / Netlify / any free host)
1. Upload the whole folder to any free static host (GitHub Pages, Netlify, Cloudflare Pages, Vercel, etc.).
2. Open the link on your phone.
3. Android (Chrome): tap the ⋮ menu → **Install app** or **Add to Home screen**.
4. iPhone (Safari): tap Share → **Add to Home Screen**.

After installing it opens full-screen like a normal app and keeps all your data.

### Option B – Share the folder / zip
1. Send the zip or the whole folder to another phone.
2. Put the files on any web server or use a local server (see below).
3. Open `index.html` through that server and install as above.

> **Important**: Opening the file directly (`file://`) works for basic use, but the install button and offline mode only work when the page is served over **http** or **https**.

### Quick local test on computer
```bash
# From inside this folder
python3 -m http.server 8080
# Then open http://localhost:8080 on your phone (same Wi-Fi)
```

## Data safety
- Everything is saved automatically on the device (localStorage + IndexedDB).
- Use **Settings → Save backup file** regularly (especially before updating the app).
- You can also copy the backup text and paste it later.

## Files included
- `index.html` – the full app
- `manifest.webmanifest` – makes it installable
- `sw.js` – service worker (offline + caching)
- `icon-192.png`, `icon-512.png`, `apple-touch-icon.png` – app icons
- `icon.svg` – source icon

Version: 3.2 (PWA edition)
