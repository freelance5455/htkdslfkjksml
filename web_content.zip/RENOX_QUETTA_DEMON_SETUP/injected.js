(function() {
  console.log('[ Renox — QUETTA CLEAR VOICE PRO] V9 - CLARITY-FIRST AUDIO CHAIN');

  // ==== WEBRTC BITRATE BOOST ====
  // Even a perfectly boosted, clean signal gets squashed again by the call's
  // own audio codec (Opus) if it's left at its default low voice bitrate -
  // that re-compression is a second, separate source of distortion that
  // happens AFTER our DSP chain, on the wire. This raises the ceiling so the
  // encoder doesn't need to throw quality away, and turns off DTX (which
  // otherwise can stop transmitting during brief quiet moments - another
  // possible cause of choppy-sounding audio on the receiving end).
  const AUDIO_MAX_BITRATE = 320000;
  function boostOpusSdp(sdp) {
    if (typeof sdp !== 'string' || !sdp.includes('m=audio')) return sdp;
    let next = sdp.replace(/a=fmtp:(\d+) ([^\r\n]*)/g, (line, pt, params) => {
      if (!/opus/i.test(sdp.slice(Math.max(0, sdp.indexOf(line) - 40), sdp.indexOf(line)))
          && !/a=rtpmap:\d+ opus/i.test(sdp)) return line; // best-effort, harmless if no match
      const extra = ['maxaveragebitrate=' + AUDIO_MAX_BITRATE, 'useinbandfec=1', 'usedtx=0'];
      const add = extra.filter(kv => !new RegExp('(^|;)\\s*' + kv.split('=')[0] + '=', 'i').test(params));
      return add.length ? line + ';' + add.join(';') : line;
    });
    return next;
  }
  function patchPeerConnectionAudio() {
    const PC = window.RTCPeerConnection || window.webkitRTCPeerConnection;
    if (!PC || !PC.prototype || PC.prototype.__akhandPatched) return;

    const wrapSdpMethod = (name) => {
      const orig = PC.prototype[name];
      if (typeof orig !== 'function') return;
      PC.prototype[name] = function(...args) {
        return orig.apply(this, args).then((desc) => {
          try {
            if (desc && desc.sdp) return new RTCSessionDescription({ type: desc.type, sdp: boostOpusSdp(desc.sdp) });
          } catch (e) { /* ignore, fall back to original */ }
          return desc;
        });
      };
    };
    wrapSdpMethod('createOffer');
    wrapSdpMethod('createAnswer');

    const wrapSetDesc = (name) => {
      const orig = PC.prototype[name];
      if (typeof orig !== 'function') return;
      PC.prototype[name] = function(desc) {
        try {
          if (desc && desc.sdp) desc = new RTCSessionDescription({ type: desc.type, sdp: boostOpusSdp(desc.sdp) });
        } catch (e) { /* ignore */ }
        return orig.call(this, desc);
      };
    };
    wrapSetDesc('setLocalDescription');
    wrapSetDesc('setRemoteDescription');

    const origAddTrack = PC.prototype.addTrack;
    if (typeof origAddTrack === 'function') {
      PC.prototype.addTrack = function(track, ...streams) {
        const sender = origAddTrack.call(this, track, ...streams);
        if (track && track.kind === 'audio' && sender && typeof sender.getParameters === 'function') {
          try {
            const params = sender.getParameters();
            params.encodings = (params.encodings && params.encodings.length ? params.encodings : [{}]).map(enc => ({
              ...enc, maxBitrate: Math.max(enc.maxBitrate || 0, AUDIO_MAX_BITRATE)
            }));
            sender.setParameters(params).catch(() => {});
          } catch (e) { /* ignore */ }
        }
        return sender;
      };
    }
    PC.prototype.__akhandPatched = true;
  }
  try { patchPeerConnectionAudio(); } catch (e) { /* non-fatal */ }

  let audioContext = null;
  let currentSettings = {
    gain: 120,         // restrained gain for clearer speech
    bass: 10,          // gentle low shelf
    treble: 25,        // speech detail
    clarity: 35,       // vocal presence/articulation
    echo: 0,           // echo off for intelligible calls
    loudness: 12,      // modest makeup gain to reduce distortion
    noiseGate: 18      // gentle noise control; avoid chopping words
  };

  window.addEventListener('message', (event) => {
    if (event.data.type === 'AUDIO_SETTINGS_UPDATE') {
      currentSettings = event.data.settings;
      console.log('[Renox — QUETTA CLEAR VOICE PRO] Settings:', currentSettings);
    }
  });

  // Smooth parameter setter - avoids clicks/crackle.
  // Skips redundant scheduling: calling setTargetAtTime every tick forever (even
  // with an unchanged value) keeps queuing automation events on that AudioParam,
  // and on a long call that pile-up is exactly what causes the audio thread to
  // fall behind and produce choppy/stuttery playback. Only schedule when the
  // target actually moved.
  const lastTargets = new WeakMap();
  function smoothSet(audioParam, value, timeConstant = 0.05) {
    if (!audioContext) return;
    const prev = lastTargets.get(audioParam);
    if (prev !== undefined && Math.abs(prev - value) < 0.001) return;
    lastTargets.set(audioParam, value);
    audioParam.setTargetAtTime(value, audioContext.currentTime, timeConstant);
  }

  function processAudioStream(originalStream) {
    try {
      if (!audioContext) {
        try {
          audioContext = new (window.AudioContext || window.webkitAudioContext)({
            latencyHint: 'interactive',
            sampleRate: 48000 // matches typical WebRTC pipeline rate, avoids extra resampling
          });
        } catch (e) {
          audioContext = new (window.AudioContext || window.webkitAudioContext)({ latencyHint: 'interactive' });
        }
      }
      if (audioContext.state === 'suspended') {
        audioContext.resume().catch(() => {});
      }

      const source = audioContext.createMediaStreamSource(originalStream);

      // ==== MAIN VOLUME / GAIN (0-1000%) ====
      const volumeGain = audioContext.createGain();
      volumeGain.gain.value = 1.0;

      // ==== NOISE FLOOR SMOOTHING (Omni-style: NEVER mutes, only rides gain) ====
      // Old approach hard-muted (near-zero gain) when quiet, with hold timers to
      // stop flicker. Even with hold timers, any boolean on/off gate can clip the
      // start/end of words -> perceived as "atak atak". Omni's pipeline has no
      // mute step at all - it only ever nudges gain up/down smoothly. We do the
      // same: gateGain continuously interpolates toward a floor based on how far
      // below threshold the signal is, never snapping, never muting.
      const gateGain = audioContext.createGain();
      gateGain.gain.value = 1.0;

      // Analyser taps the RAW mic (pre-gain) so thresholds stay consistent
      // no matter how high the GAIN slider is pushed
      const gateAnalyser = audioContext.createAnalyser();
      gateAnalyser.fftSize = 1024;
      gateAnalyser.smoothingTimeConstant = 0;
      source.connect(gateAnalyser);
      const gateBuf = new Float32Array(gateAnalyser.fftSize);

      // ==== HIGH-PASS (cuts rumble/mic thump, always on) ====
      const highpass = audioContext.createBiquadFilter();
      highpass.type = 'highpass';
      highpass.frequency.value = 85;
      highpass.Q.value = 0.7;

      // ==== BASS ====
      const bassBoost = audioContext.createBiquadFilter();
      bassBoost.type = 'lowshelf';
      bassBoost.frequency.value = 150;
      bassBoost.gain.value = 0;

      // ==== CLARITY (presence/articulation ~3.2kHz) ====
      const clarityBoost = audioContext.createBiquadFilter();
      clarityBoost.type = 'peaking';
      clarityBoost.frequency.value = 3200;
      clarityBoost.Q.value = 0.9;
      clarityBoost.gain.value = 0;

      // ==== TREBLE ====
      const trebleBoost = audioContext.createBiquadFilter();
      trebleBoost.type = 'highshelf';
      trebleBoost.frequency.value = 6000;
      trebleBoost.gain.value = 0;

      // ==== LOW-PASS (cuts harsh hiss, always on) ====
      const lowpass = audioContext.createBiquadFilter();
      lowpass.type = 'lowpass';
      lowpass.frequency.value = 15000;
      lowpass.Q.value = 0.7;

      // ==== COMPRESSOR (evens out loudness - smooth, no pumping) ====
      const compressor = audioContext.createDynamicsCompressor();
      compressor.threshold.value = -30;
      compressor.knee.value = 24;
      compressor.ratio.value = 3.5;
      compressor.attack.value = 0.008;
      compressor.release.value = 0.28;

      // ==== ECHO (parallel wet/dry, feedback capped to avoid resonant chatter) ====
      const delay = audioContext.createDelay(2.0);
      delay.delayTime.value = 0.26;
      const feedback = audioContext.createGain();
      feedback.gain.value = 0;
      const echoWet = audioContext.createGain();
      echoWet.gain.value = 0;
      const echoDry = audioContext.createGain();
      echoDry.gain.value = 1.0;
      const echoMix = audioContext.createGain();
      echoMix.gain.value = 1.0;

      // ==== LOUDNESS / MAKEUP GAIN (pushed hard - like a loudnorm pass) ====
      const loudnessGain = audioContext.createGain();
      loudnessGain.gain.value = 1.0;

      // ==== STAGE 1 LIMITER (leveling comp - evens out peaks before saturation) ====
      const limiter = audioContext.createDynamicsCompressor();
      limiter.threshold.value = -9;
      limiter.knee.value = 10;
      limiter.ratio.value = 12;
      limiter.attack.value = 0.004;
      limiter.release.value = 0.2;

      // ==== SOFT SATURATOR (gentle asymmetric-free waveshaper) ====
      // Rounds off the very tips of loud peaks BEFORE the brickwall instead of
      // letting the brickwall's hard-knee compression do all the work. This is
      // what makes extreme loudness sound "thick/loud" instead of "crackly/fizzy" -
      // it's the same trick used in analog tape/tube saturation and mastering
      // limiters. Curve strength is tied to the loudness slider.
      const saturator = audioContext.createWaveShaper();
      saturator.oversample = '2x'; // 4x was CPU-heavy enough to contribute to stutter
      function makeSatCurve(amount) {
        // amount: 0 (transparent) -> 1 (heavy soft-clip)
        const n = 1024;
        const curve = new Float32Array(n);
        const k = 1 + amount * 6; // shaping strength
        for (let i = 0; i < n; i++) {
          const x = (i / (n - 1)) * 2 - 1;
          // tanh-style soft clip: smooth, no odd-harmonic buzz at low amounts
          curve[i] = Math.tanh(k * x) / Math.tanh(k);
        }
        return curve;
      }
      saturator.curve = makeSatCurve(0.15);

      // ==== STAGE 2 LIMITER (native brickwall - all-AudioNode, runs on the
      // browser's real-time audio thread, NOT JS main thread. A ScriptProcessorNode
      // hard-clip stage was used here before for max loudness, but doing sample
      // math on the JS thread is exactly what Omni's pipeline avoids - it's a
      // real source of glitches/stutter under any CPU load. This native
      // DynamicsCompressorNode gets pushed very hard (tiny knee, high ratio,
      // near-instant attack) so it still behaves almost like a hard ceiling,
      // but stays glitch-safe because it's native. ====
      const brickwall = audioContext.createDynamicsCompressor();
      brickwall.threshold.value = -1;
      brickwall.knee.value = 1;
      brickwall.ratio.value = 20;
      brickwall.attack.value = 0.0008;
      brickwall.release.value = 0.05;

      // ==== KEEPALIVE NOISE FLOOR (Omni trick) ====
      // Mixes in an inaudibly quiet looping noise buffer so the outgoing stream
      // is never bit-for-bit silent. Some call platforms detect true digital
      // silence and suppress/gate the stream on their own end, which can look
      // identical to "stuttering". This floor is far below the noise gate's own
      // threshold, so it never gets picked up as speech.
      const keepAliveBuf = audioContext.createBuffer(1, audioContext.sampleRate * 2, audioContext.sampleRate);
      const kaData = keepAliveBuf.getChannelData(0);
      for (let i = 0; i < kaData.length; i++) kaData[i] = (Math.random() * 2 - 1) * 0.15;
      const keepAliveSource = audioContext.createBufferSource();
      keepAliveSource.buffer = keepAliveBuf;
      keepAliveSource.loop = true;
      const keepAliveGain = audioContext.createGain();
      keepAliveGain.gain.value = 0.0003;
      keepAliveSource.connect(keepAliveGain);

      // outputGain stays at unity - the brickwall already maximizes loudness right up
      // to the ceiling; pushing gain again AFTER it just re-clips everything it just fixed
      const outputGain = audioContext.createGain();
      outputGain.gain.value = 1.0;

      // ==== CONNECTIONS ====
      source.connect(volumeGain);
      volumeGain.connect(gateGain);
      gateGain.connect(highpass);
      highpass.connect(bassBoost);
      bassBoost.connect(clarityBoost);
      clarityBoost.connect(trebleBoost);
      trebleBoost.connect(lowpass);
      lowpass.connect(compressor);

      compressor.connect(echoDry);
      compressor.connect(delay);
      delay.connect(feedback);
      feedback.connect(delay);
      delay.connect(echoWet);

      echoDry.connect(echoMix);
      echoWet.connect(echoMix);

      echoMix.connect(loudnessGain);
      loudnessGain.connect(limiter);
      limiter.connect(saturator);
      saturator.connect(brickwall);
      brickwall.connect(outputGain);
      keepAliveGain.connect(outputGain);
      keepAliveSource.start(0);

      const destination = audioContext.createMediaStreamDestination();
      outputGain.connect(destination);

      // ==== REALTIME SETTINGS + NOISE GATE UPDATE LOOP ====
      const updateLoop = setInterval(() => {
        const s = currentSettings;

        // GAIN - 0-1000%
        const gainMultiplier = Math.max(0, Math.min(10, s.gain / 100));
        smoothSet(volumeGain.gain, gainMultiplier, 0.06);

        // BASS / CLARITY / TREBLE (0-150 -> 0-30dB)
        smoothSet(bassBoost.gain, s.bass / 5, 0.06);
        smoothSet(clarityBoost.gain, s.clarity / 5, 0.06);
        smoothSet(trebleBoost.gain, s.treble / 5, 0.06);

        // ECHO (feedback capped so it can't build into resonant chatter)
        const echoAmt = Math.max(0, Math.min(100, s.echo)) / 100;
        smoothSet(feedback.gain, Math.min(0.55, echoAmt * 0.6), 0.05);
        smoothSet(echoWet.gain, echoAmt, 0.05);
        smoothSet(echoDry.gain, 1.0 - echoAmt * 0.3, 0.05);

        // LOUDNESS - pushed hard (leveling comp + saturator + 2-stage limiter protects against clipping)
        const loud = Math.max(0, Math.min(100, s.loudness));
        compressor.threshold.value = -30 + (loud * 0.10);
        compressor.ratio.value = Math.min(8, 3.5 + (loud / 25));
        smoothSet(loudnessGain.gain, 1.0 + (loud / 35), 0.08);   // modest makeup gain; preserve speech transients
        // Final ceiling stage - native compressor pushed hard so it still reads as
        // "khatarnak loud" (very little headroom left before clamp), but it's a
        // real AudioNode running on the audio thread, so it can't stutter the way
        // the old JS-thread hard-clip could.
        smoothSet(brickwall.threshold, -1.5, 0.05); // rides toward 0dB as loud climbs
        // saturator gets progressively "warmer"/rounder as loudness climbs, so the
        // extra makeup gain is absorbed as thickness instead of hard-clip fizz
        const satCurve = makeSatCurve(0.03 + (loud / 100) * 0.18);
        if (!saturator._lastAmt || Math.abs(saturator._lastAmt - loud) > 5) {
          saturator.curve = satCurve;
          saturator._lastAmt = loud;
        }

        // ==== NOISE FLOOR (continuous ride, never mutes - see gateGain comment above) ====
        const gateAmt = Math.max(0, Math.min(100, s.noiseGate));
        if (gateAmt <= 0) {
          smoothSet(gateGain.gain, 1.0, 0.1);
        } else {
          gateAnalyser.getFloatTimeDomainData(gateBuf);
          let sumSquares = 0;
          for (let i = 0; i < gateBuf.length; i++) sumSquares += gateBuf[i] * gateBuf[i];
          const rms = Math.sqrt(sumSquares / gateBuf.length);

          const thresh = 0.0015 + (gateAmt / 100) * 0.022;
          // floor = quietest the gate will ever push the signal to. Pushed much
          // lower now (down to ~1.5% at gateAmt=100 instead of ~10% before) so
          // continuous room/background noise is barely audible, while still never
          // hard-muting (so no click/stutter at the on/off edge).
          const floor = 0.30 - (gateAmt / 100) * 0.285;
          // Curved (squared) instead of linear: a whisper-quiet signal near the
          // threshold gets suppressed harder, but genuine speech (clearly above
          // threshold) still snaps open to full volume almost immediately.
          const aboveLinear = Math.min(1, rms / thresh);
          const above = aboveLinear * aboveLinear;
          const target = floor + (1 - floor) * above;
          // Slow, continuous time constant - this is a level *ride*, not a switch,
          // so there's nothing to flicker regardless of how quickly rms jitters.
          smoothSet(gateGain.gain, target, 0.18);
        }

      }, 60);

      originalStream.getVideoTracks().forEach(track => {
        destination.stream.addTrack(track);
      });

      console.log('[Renox — QUETTA CLEAR VOICE PRO] Audio chain initialized (best-effort)');
      window.postMessage({ type: 'AUDIO_STATUS', status: 'PROCESSING_INITIALIZED'  }, '*');

      return destination.stream;

    } catch (error) {
      console.error('[Renox — QUETTA CLEAR VOICE PRO] Error:', error);
      return originalStream;
    }
  }

  // ==== CLARITY-FIRST MIC CONSTRAINTS ====
  // Preserve browser echo cancellation, noise suppression, and auto gain where
  // supported. This is a best-effort request; the browser/device may ignore it.
  function clarityMicConstraints(audio) {
    const base = (audio && typeof audio === 'object') ? audio : {};
    return {
      ...base,
      echoCancellation: true,
      noiseSuppression: true,
      autoGainControl: true,
      sampleRate: { ideal: 48000 }
    };
  }

  function withClarityMicConstraints(constraints) {
    if (!constraints || !constraints.audio) return constraints;
    return { ...constraints, audio: clarityMicConstraints(constraints.audio) };
  }

  const originalGetUserMedia = navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);

  navigator.mediaDevices.getUserMedia = async function(constraints) {
    console.log('[Renox — QUETTA CLEAR VOICE PRO] getUserMedia called');
    let stream;
    try {
      stream = await originalGetUserMedia(withClarityMicConstraints(constraints));
    } catch (e) {
      stream = await originalGetUserMedia(constraints); // fallback if strict constraints get rejected
    }

    if (constraints && constraints.audio) {
      console.log('[Renox — QUETTA CLEAR VOICE PRO] Applying clarity-first processing...');
      return processAudioStream(stream);
    }

    return stream;
  };

  if (navigator.getUserMedia) {
    const legacyGetUserMedia = navigator.getUserMedia.bind(navigator);
    navigator.getUserMedia = function(constraints, successCallback, errorCallback) {
      legacyGetUserMedia(constraints, (stream) => {
        if (constraints && constraints.audio) {
          successCallback(processAudioStream(stream));
        } else {
          successCallback(stream);
        }
      }, errorCallback);
    };
  }

  console.log('[Renox — QUETTA CLEAR VOICE PRO] READY (best-effort)');
})();