Renox — QUETTA CLEAR VOICE PRO v3.3.0

Purpose
- Mobile-friendly Chromium extension UI with clarity-first voice presets.
- Clear Pro, Voice Boost, and Studio presets use restrained gain, modest EQ, no echo by default, and gentler compression/saturation settings.
- Browser echo cancellation, noise suppression, and auto gain control are requested where supported.

IMPORTANT LIMITATIONS
- This package targets web pages matching web.telegram.org and Instagram; it does not modify the separate Telegram Android app.
- The code attempts to process microphone streams when the website uses compatible getUserMedia/WebRTC paths. Telegram Web may use a different path or isolate APIs, so effects may not apply to live calls.
- The popup status reports initialization/availability, not proof that remote listeners hear processed audio.
- No live call was tested in Quetta Browser. Audio results depend on browser, website, microphone, Bluetooth codec, and call processing.
- Quetta's extension manager may not import arbitrary local ZIP files. If it only supports store installation, this ZIP cannot be installed through that route. Do not rename the ZIP to CRX or APK.

Package contents
- manifest.json: Manifest V3 extension configuration
- popup.html / popup.css / popup.js: responsive mobile controls
- content.js / injected.js: best-effort page integration and audio processing

Recommended test
1. Install/load the extension only if your Quetta version supports local extension loading.
2. Open Telegram Web and reload the page after enabling the extension.
3. Use Clear Pro first and make a short test call with a trusted contact.
4. If audio becomes distorted, lower MIC GAIN and LOUDNESS; if no effect is heard, the website/browser path may not be compatible.
