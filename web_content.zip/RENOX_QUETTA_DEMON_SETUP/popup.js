// ======================================================================
// Renox — QUETTA DEMON SETUP popup - entire UI built in JS (no static markup in HTML)
// Only transform/opacity are animated (GPU-composited) so nothing lags.
// ======================================================================

const SLIDER_DEFS = [
  { id: 'gain',      label: 'MIC GAIN',      min: 0, max: 1000, step: 10, def: 120 },
  { id: 'bass',      label: 'BASS',          min: 0, max: 150,  step: 1,  def: 10  },
  { id: 'treble',    label: 'TREBLE',        min: 0, max: 150,  step: 1,  def: 25  },
  { id: 'clarity',   label: 'VOICE CLARITY', min: 0, max: 150,  step: 1,  def: 35  },
  { id: 'echo',      label: 'ECHO',          min: 0, max: 100,  step: 1,  def: 0   },
  { id: 'loudness',  label: 'LOUDNESS',      min: 0, max: 100,  step: 1,  def: 12  },
  { id: 'noiseGate', label: 'NOISE CONTROL', min: 0, max: 100,  step: 1,  def: 18  }
];

const sliderIds = SLIDER_DEFS.map(s => s.id);
const DEFAULTS = Object.fromEntries(SLIDER_DEFS.map(s => [s.id, s.def]));

const PRESET_NUCLEAR    = { gain: 180, bass: 12, treble: 30, clarity: 42, echo: 0, loudness: 20, noiseGate: 22 };
const PRESET_GODMODE    = { gain: 140, bass: 5,  treble: 22, clarity: 32, echo: 0, loudness: 10, noiseGate: 12 };
const SAFE_CLEAR_PRESET = { gain: 120, bass: 10, treble: 25, clarity: 35, echo: 0, loudness: 12, noiseGate: 18 };
let audioStatus = 'CHECKING';

let saveTimeout = null;
let sendTimeout = null;

function applyTheme(theme, persist = true) {
  const app = document.getElementById('app');
  app.classList.remove('theme-full', 'theme-nuclear', 'theme-god');
  if (theme === 'full' || theme === 'nuclear') app.classList.add('theme-' + theme);
  if (persist) chrome.storage.local.set({ uiTheme: theme });
}

const UI_THEMES = {
  cyan:    { name: 'NEON CYAN',    cyan: '#55e6ff', purple: '#9b7cff', glow: '#55e6ff' },
  violet:  { name: 'VIOLET',       cyan: '#b79cff', purple: '#7c5cff', glow: '#a47cff' },
  emerald: { name: 'EMERALD',      cyan: '#52f2b0', purple: '#28c79b', glow: '#52f2b0' },
  crimson: { name: 'CRIMSON',      cyan: '#ff6f91', purple: '#ff3f68', glow: '#ff587d' },
  gold:    { name: 'GOLD',         cyan: '#ffd45a', purple: '#ff9b62', glow: '#ffd45a' }
};

function applyUICustomizer(opts = {}, persist = true) {
  const app = document.getElementById('app');
  const theme = UI_THEMES[opts.color] ? opts.color : 'cyan';
  const density = opts.density === 'compact' ? 'compact' : 'comfortable';
  const glow = Math.max(0, Math.min(100, Number(opts.glow ?? 70)));
  const t = UI_THEMES[theme];

  app.dataset.uiColor = theme;
  app.dataset.density = density;
  app.style.setProperty('--custom-cyan', t.cyan);
  app.style.setProperty('--custom-purple', t.purple);
  app.style.setProperty('--custom-glow', (glow / 100).toFixed(2));

  document.querySelectorAll('.color-swatch').forEach(b => b.classList.toggle('active', b.dataset.color === theme));
  const glowInput = document.getElementById('uiGlow');
  if (glowInput) glowInput.value = glow;
  const glowValue = document.getElementById('uiGlowValue');
  if (glowValue) glowValue.textContent = glow + '%';
  const densityBtn = document.getElementById('densityToggle');
  if (densityBtn) densityBtn.textContent = density === 'compact' ? 'COMPACT' : 'COMFORTABLE';

  if (persist) chrome.storage.local.set({ uiCustomizer: { color: theme, density, glow } });
}

function buildUICustomizer() {
  const panel = el('div', 'ui-customizer');
  const head = el('div', 'customizer-head', [
    el('div', 'customizer-title', ['◆ UI CUSTOMIZER']),
    button('customizer-close', '×', 'customizerClose')
  ]);

  const colorLabel = el('div', 'customizer-label', 'ACCENT COLOR');
  const colors = el('div', 'color-swatches');
  Object.entries(UI_THEMES).forEach(([key, theme]) => {
    const b = document.createElement('button');
    b.className = 'color-swatch';
    b.dataset.color = key;
    b.title = theme.name;
    b.style.setProperty('--swatch', theme.cyan);
    b.innerHTML = `<span></span><small>${theme.name}</small>`;
    b.addEventListener('click', () => applyUICustomizer({ ...getUICustomizer(), color: key }));
    colors.appendChild(b);
  });

  const glowTop = el('div', 'customizer-row', [
    el('span', 'customizer-label', 'GLOW INTENSITY'),
    el('span', 'customizer-value', '70%')
  ]);
  glowTop.querySelector('.customizer-value').id = 'uiGlowValue';
  const glow = document.createElement('input');
  glow.type = 'range'; glow.id = 'uiGlow'; glow.min = 0; glow.max = 100; glow.value = 70;
  glow.addEventListener('input', e => applyUICustomizer({ ...getUICustomizer(), glow: e.target.value }));

  const densityRow = el('div', 'customizer-row', [
    el('span', 'customizer-label', 'PANEL DENSITY'),
    button('density-btn', 'COMFORTABLE', 'densityToggle')
  ]);
  densityRow.querySelector('#densityToggle').addEventListener('click', () => {
    const next = getUICustomizer().density === 'compact' ? 'comfortable' : 'compact';
    applyUICustomizer({ ...getUICustomizer(), density: next });
  });

  const reset = button('customizer-reset', 'RESET UI STYLE', 'customizerReset');
  reset.addEventListener('click', () => applyUICustomizer({ color: 'cyan', density: 'comfortable', glow: 70 }));

  panel.append(head, colorLabel, colors, glowTop, glow, densityRow, reset);
  return panel;
}

function getUICustomizer() {
  const app = document.getElementById('app');
  return {
    color: app.dataset.uiColor || 'cyan',
    density: app.dataset.density || 'comfortable',
    glow: Number(document.getElementById('uiGlow')?.value || 70)
  };
}

function toggleUICustomizer(force) {
  const panel = document.querySelector('.ui-customizer');
  const open = typeof force === 'boolean' ? force : !panel.classList.contains('open');
  panel.classList.toggle('open', open);
  document.getElementById('uiCustomizeBtn')?.classList.toggle('active', open);
}

// ---------- Build UI ----------
function buildUI() {
  const app = document.getElementById('app');

  const customizeBtn = button('ui-customize-btn', '⚙', 'uiCustomizeBtn');
  customizeBtn.title = 'Customize UI';
  customizeBtn.addEventListener('click', () => toggleUICustomizer());

  const header = el('div', 'header', [
    customizeBtn,
    el('div', 'shine-sweep'),
    el('div', 'title', [diamond(), 'Renox KA SETUP ', diamond()]),
    el('div', 'developer', ['DEVELOPER = ', el('span', 'developer-name', 'Renox KA SETUP')]),
    el('div', 'subtitle', [diamond(), ' QUETTA • CLEAR VOICE PRO ', diamond()])
  ]);

  const presetRow = el('div', 'preset-buttons', [
    presetButton('p1', 'CLEAR PRO', 'natural + clear', 'preset1'),
    presetButton('p2', 'VOICE BOOST', 'strong, controlled', 'preset2'),
    presetButton('p3', 'STUDIO', 'soft + balanced', 'preset3')
  ]);

  const status = el('div', 'status-row', [
    el('span', 'status-dot'),
    el('span', 'status-text', 'VOICE CONTROL PANEL'),
    el('span', 'status-mode', 'READY')
  ]);

  const content = el('div', 'content', [presetRow, status]);
  status.querySelector('.status-text').id = 'deviceStatusText';
  status.querySelector('.status-mode').id = 'deviceStatusMode';
  SLIDER_DEFS.forEach(def => content.appendChild(buildSlider(def)));
  content.appendChild(button('reset-btn', 'RESET ALL', 'resetBtn'));
  content.appendChild(buildDevicePanel());
  content.appendChild(buildSettingsPanel());

  const taglineEl = el('div', 'tagline');
  taglineEl.innerHTML = 'Renox &amp;   CLEAR<br>VOICE PRO • QUETTA';
  const footer = el('div', 'footer', [taglineEl]);

  app.appendChild(header);
  app.appendChild(content);
  app.appendChild(footer);
  const customizer = buildUICustomizer();
  customizer.querySelector('#customizerClose').addEventListener('click', () => toggleUICustomizer(false));
  app.appendChild(customizer);
}

function buildDevicePanel() {
  const panel = el('section', 'feature-panel device-panel');
  panel.appendChild(el('div', 'panel-heading', ['◈ DEVICE STATUS']));
  const rows = el('div', 'device-grid', [
    el('div', 'device-cell', [el('span', 'device-label', 'BROWSER'), el('strong', 'device-value', 'Checking…')]),
    el('div', 'device-cell', [el('span', 'device-label', 'MIC API'), el('strong', 'device-value', 'Checking…')]),
    el('div', 'device-cell', [el('span', 'device-label', 'ACTIVE TAB'), el('strong', 'device-value', 'Checking…')])
  ]);
  rows.children[0].querySelector('.device-value').id = 'browserValue';
  rows.children[1].querySelector('.device-value').id = 'micValue';
  rows.children[2].querySelector('.device-value').id = 'tabValue';
  panel.appendChild(rows);
  panel.appendChild(el('p', 'panel-note', 'Status checks availability only; it does not secretly activate your microphone.'));
  const refresh = button('small-action', 'REFRESH STATUS', 'refreshDeviceBtn');
  refresh.addEventListener('click', refreshDeviceStatus);
  panel.appendChild(refresh);
  return panel;
}

function buildSettingsPanel() {
  const panel = el('section', 'feature-panel settings-panel');
  panel.appendChild(el('div', 'panel-heading', ['⚙ QUICK SETTINGS & SAVED PRESETS']));
  panel.appendChild(el('p', 'panel-note', 'Save your current slider values in a slot, then load them any time.'));
  const slots = el('div', 'saved-slots');
  [1, 2, 3].forEach(n => {
    const row = el('div', 'saved-slot');
    row.appendChild(el('span', 'slot-name', `CUSTOM ${n}`));
    const load = button('small-action', 'LOAD', `loadSlot${n}`);
    const save = button('small-action secondary-action', 'SAVE CURRENT', `saveSlot${n}`);
    load.addEventListener('click', () => loadCustomPreset(n));
    save.addEventListener('click', () => saveCustomPreset(n));
    row.append(load, save);
    slots.appendChild(row);
  });
  panel.appendChild(slots);
  const actions = el('div', 'settings-actions');
  const exportBtn = button('small-action', 'EXPORT SETTINGS', 'exportSettingsBtn');
  const importBtn = button('small-action secondary-action', 'IMPORT SETTINGS', 'importSettingsBtn');
  const fileInput = document.createElement('input');
  fileInput.type = 'file'; fileInput.accept = 'application/json,.json'; fileInput.id = 'importSettingsFile'; fileInput.hidden = true;
  exportBtn.addEventListener('click', exportSettings);
  importBtn.addEventListener('click', () => fileInput.click());
  fileInput.addEventListener('change', importSettings);
  actions.append(exportBtn, importBtn, fileInput);
  panel.appendChild(actions);
  return panel;
}

function currentSettings() {
  return Object.fromEntries(sliderIds.map(id => [id, Number(document.getElementById(id).value)]));
}

function validateSettings(value) {
  if (!value || typeof value !== 'object') return null;
  const clean = {};
  for (const def of SLIDER_DEFS) {
    const n = Number(value[def.id]);
    if (!Number.isFinite(n) || n < def.min || n > def.max) return null;
    clean[def.id] = Math.round(n / def.step) * def.step;
  }
  return clean;
}

function saveCustomPreset(slot) {
  const name = `customPreset${slot}`;
  chrome.storage.local.set({ [name]: currentSettings() }, () => showToast(`CUSTOM ${slot} SAVED`));
}

function loadCustomPreset(slot) {
  chrome.storage.local.get(`customPreset${slot}`, result => {
    const clean = validateSettings(result[`customPreset${slot}`]);
    if (!clean) return showToast(`SAVE CUSTOM ${slot} FIRST`);
    applySettings(clean, { notify: `CUSTOM ${slot} LOADED` });
  });
}

function exportSettings() {
  chrome.storage.local.get(null, result => {
    const exportData = { app: 'Renox KA SETUP', version: 2, settings: currentSettings(), uiCustomizer: result.uiCustomizer || { color: 'crimson', density: 'comfortable', glow: 70 }, customPresets: {} };
    [1, 2, 3].forEach(n => { if (result[`customPreset${n}`]) exportData.customPresets[n] = result[`customPreset${n}`]; });
    const url = URL.createObjectURL(new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' }));
    const a = document.createElement('a'); a.href = url; a.download = 'Renox-ka-setup-settings.json'; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    showToast('SETTINGS EXPORTED');
  });
}

function importSettings(event) {
  const file = event.target.files && event.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const data = JSON.parse(String(reader.result || '{}'));
      const clean = validateSettings(data.settings || data);
      if (!clean) throw new Error('Invalid settings');
      applySettings(clean, { notify: 'SETTINGS IMPORTED' });
      if (data.uiCustomizer && typeof data.uiCustomizer === 'object') applyUICustomizer(data.uiCustomizer);
      const saved = {};
      [1, 2, 3].forEach(n => {
        const preset = validateSettings(data.customPresets && data.customPresets[n]);
        if (preset) saved[`customPreset${n}`] = preset;
      });
      if (Object.keys(saved).length) chrome.storage.local.set(saved);
    } catch (_) { showToast('INVALID SETTINGS FILE'); }
    event.target.value = '';
  };
  reader.readAsText(file);
}

async function refreshDeviceStatus() {
  const set = (id, value) => { const node = document.getElementById(id); if (node) node.textContent = value; };
  set('browserValue', navigator.userAgent.includes('Edg/') ? 'EDGE' : navigator.userAgent.includes('Chrome/') ? 'CHROME' : 'CHROMIUM');
  set('micValue', navigator.mediaDevices && navigator.mediaDevices.enumerateDevices ? 'AVAILABLE' : 'UNAVAILABLE');
  set('deviceStatusText', 'DEVICE STATUS');
  let tabText = 'UNKNOWN';
  try {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    const url = tabs[0] && tabs[0].url || '';
    if (/web\.telegram\.org/i.test(url)) tabText = 'TELEGRAM WEB';
    else if (/instagram\.com/i.test(url)) tabText = 'INSTAGRAM';
    else if (/^https?:/i.test(url)) tabText = 'WEB PAGE';
    else tabText = 'UNSUPPORTED PAGE';
  } catch (_) { tabText = 'UNAVAILABLE'; }
  set('tabValue', tabText);
  set('deviceStatusMode', audioStatus);
}

function presetButton(cls, title, sub, id) {
  const b = document.createElement('button');
  b.className = 'preset-btn ' + cls;
  b.id = id;
  b.appendChild(el('span', 'p-title', title));
  b.appendChild(el('span', 'p-sub', sub));
  return b;
}

function buildSlider(def) {
  const container = el('div', 'slider-container');

  const top = el('div', 'slider-top', [
    el('label', null, [diamond(), ' ' + def.label]),
    el('span', 'value', def.def + '%')
  ]);
  top.querySelector('.value').id = def.id + 'Value';

  const input = document.createElement('input');
  input.type = 'range';
  input.id = def.id;
  input.min = def.min;
  input.max = def.max;
  input.step = def.step;
  input.value = def.def;

  container.appendChild(top);
  container.appendChild(input);
  return container;
}

function el(tag, className, content) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (Array.isArray(content)) {
    content.forEach(c => node.appendChild(typeof c === 'string' ? document.createTextNode(c) : c));
  } else if (typeof content === 'string') {
    node.textContent = content;
  }
  return node;
}

function diamond() {
  return el('span', 'diamond', '◆');
}

function button(className, text, id) {
  const b = document.createElement('button');
  b.className = className;
  b.id = id;
  b.textContent = text;
  return b;
}

// ---------- Wire up behavior ----------
function updateValueDisplay(slider, value) {
  document.getElementById(slider + 'Value').textContent = Math.round(value) + '%';
}

function updateTrackFill(slider) {
  const input = document.getElementById(slider);
  if (!input) return;
  const min = parseFloat(input.min), max = parseFloat(input.max), val = parseFloat(input.value);
  const pct = ((val - min) / (max - min)) * 100;
  input.style.background = `linear-gradient(to right, #f4d576 0%, #d4af37 ${pct}%, #2a2a30 ${pct}%, #2a2a30 100%)`;
}

function applySettings(settings, { persist = true, notify = null } = {}) {
  Object.keys(settings).forEach(slider => {
    const input = document.getElementById(slider);
    if (!input) return;
    input.value = settings[slider];
    updateValueDisplay(slider, settings[slider]);
    updateTrackFill(slider);
  });
  if (persist) chrome.storage.local.set(settings);
  sendSettings();
  if (notify) showToast(notify);
}

function sendSettings() {
  const settings = {};
  sliderIds.forEach(slider => {
    settings[slider] = parseFloat(document.getElementById(slider).value);
  });
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]) {
      chrome.tabs.sendMessage(tabs[0].id, {
        type: 'UPDATE_AUDIO_SETTINGS',
        settings
      }).catch(() => { /* tab not ready, ignore */ });
    }
  });
}

function showToast(message) {
  const toast = el('div', 'toast', message);
  document.body.appendChild(toast);
  requestAnimationFrame(() => toast.classList.add('show'));
  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.remove(), 200);
  }, 1400);
}

function init() {
  buildUI();

  // Restore visual UI preferences only
  chrome.storage.local.get(['uiTheme', 'uiCustomizer'], (result) => {
    applyTheme(result.uiTheme || 'full');
    applyUICustomizer(result.uiCustomizer || { color: 'crimson', density: 'comfortable', glow: 70 }, false);
  });

  refreshDeviceStatus();
  document.getElementById('refreshDeviceBtn').addEventListener('click', refreshDeviceStatus);
  chrome.runtime.onMessage.addListener(message => {
    if (message && message.type === 'AUDIO_STATUS_UPDATE') {
      audioStatus = String(message.status || 'UNKNOWN').replaceAll('_', ' ');
      const mode = document.getElementById('deviceStatusMode'); if (mode) mode.textContent = audioStatus;
    }
  });

  // One-time migration: older Demon builds stored extreme gain values.
  // Apply the clarity-first profile once after upgrade; later visits keep user settings.
  chrome.storage.local.get([...sliderIds, 'clearVoiceProV3'], (result) => {
    const initial = result.clearVoiceProV3 ? Object.fromEntries(
      sliderIds.map(id => [id, result[id] !== undefined ? result[id] : DEFAULTS[id]])
    ) : SAFE_CLEAR_PRESET;
    sliderIds.forEach(slider => {
      const value = initial[slider] !== undefined ? initial[slider] : DEFAULTS[slider];
      document.getElementById(slider).value = value;
      updateValueDisplay(slider, value);
      updateTrackFill(slider);
    });
    chrome.storage.local.set({ ...initial, clearVoiceProV3: true });
    sendSettings();
  });

  // Slider drag: display updates instantly, storage/messaging throttled
  sliderIds.forEach(slider => {
    document.getElementById(slider).addEventListener('input', (e) => {
      const value = parseFloat(e.target.value);
      updateValueDisplay(slider, value);
      updateTrackFill(slider);

      clearTimeout(saveTimeout);
      saveTimeout = setTimeout(() => {
        chrome.storage.local.set({ [slider]: value });
      }, 120);

      clearTimeout(sendTimeout);
      sendTimeout = setTimeout(sendSettings, 60);
    });
  });

  document.getElementById('resetBtn').addEventListener('click', () => {
    applySettings(DEFAULTS, { notify: '◆ SETTINGS RESET ◆' });
    applyTheme('full');
  });

  document.getElementById('preset1').addEventListener('click', () => {
    applySettings(SAFE_CLEAR_PRESET, { notify: '◆ CLEAR PRO • BALANCED MIC PROFILE ◆' });
    applyTheme('full');
  });

  document.getElementById('preset2').addEventListener('click', () => {
    applySettings(PRESET_NUCLEAR, { notify: '◆ VOICE BOOST • CONTROLLED GAIN ◆' });
    applyTheme('nuclear');
  });

  document.getElementById('preset3').addEventListener('click', () => {
    applySettings(PRESET_GODMODE, { notify: '◆ STUDIO • SOFT & BALANCED ◆' });
    applyTheme('god');
  });
}

document.addEventListener('DOMContentLoaded', init);