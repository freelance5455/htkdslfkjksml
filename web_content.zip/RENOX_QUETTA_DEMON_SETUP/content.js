// Inject script into page context
(function() {
  const script = document.createElement('script');
  script.src = chrome.runtime.getURL('injected.js');
  script.onload = function() {
    this.remove();
  };
  (document.head || document.documentElement).appendChild(script);
})();

// Receive settings from popup and send to page
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'UPDATE_AUDIO_SETTINGS') {
    window.postMessage({
      type: 'AUDIO_SETTINGS_UPDATE',
      settings: message.settings
    }, '*');
  }
});

// Listen for status updates from injected script
window.addEventListener('message', (event) => {
  if (event.source !== window) return;

  if (event.data.type === 'AUDIO_STATUS') {
    console.log('[Renox — QUETTA CLEAR VOICE PRO] Audio processing:', event.data.status);
    try { chrome.runtime.sendMessage({ type: 'AUDIO_STATUS_UPDATE', status: event.data.status }); } catch (_) { /* popup may be closed */ }
  }
});