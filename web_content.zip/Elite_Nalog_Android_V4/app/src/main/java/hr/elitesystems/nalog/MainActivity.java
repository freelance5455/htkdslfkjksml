package hr.elitesystems.nalog;
import android.app.Activity;
import android.os.Bundle;
import android.content.Context;
import android.content.Intent;
import android.content.ClipData;
import android.net.Uri;
import android.print.*;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.webkit.*;
import android.graphics.Color;
import android.util.Base64;
import android.widget.Toast;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
 private WebView web;
 private ValueCallback<Uri[]> fileCallback;
 private static final int FILE_REQUEST=101;
 private final ArrayList<Uri> shareUris=new ArrayList<>();
 private File shareFolder;
 @Override public void onCreate(Bundle b){super.onCreate(b);
  shareFolder=new File(getCacheDir(),"share");shareFolder.mkdirs();
  web=new WebView(this);web.setBackgroundColor(Color.WHITE);web.setWebViewClient(new WebViewClient());
  web.setWebChromeClient(new WebChromeClient(){
   @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> callback, FileChooserParams params){
    if(fileCallback!=null)fileCallback.onReceiveValue(null);fileCallback=callback;
    try{Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("image/*");intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);startActivityForResult(Intent.createChooser(intent,"Odaberi fotografije"),FILE_REQUEST);return true;}
    catch(Exception ex){fileCallback=null;return false;}
   }
  });
  WebSettings set=web.getSettings();set.setJavaScriptEnabled(true);set.setDomStorageEnabled(true);set.setAllowFileAccess(true);set.setAllowContentAccess(true);
  web.addJavascriptInterface(new Object(){
   @JavascriptInterface public void printPdf(){runOnUiThread(()->{PrintManager mgr=(PrintManager)getSystemService(Context.PRINT_SERVICE);mgr.print("Elite radni nalog",web.createPrintDocumentAdapter("Elite_radni_nalog"),new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build());});}
   @JavascriptInterface public void beginOfficeShare(){synchronized(shareUris){shareUris.clear();}File[] old=shareFolder.listFiles();if(old!=null)for(File f:old)f.delete();}
   @JavascriptInterface public void addOfficePhoto(String name,String dataUrl){try{
    String b64=dataUrl.substring(dataUrl.indexOf(',')+1);byte[] bytes=Base64.decode(b64,Base64.DEFAULT);
    String safe=name.replaceAll("[^a-zA-Z0-9._-]","_");File target=new File(shareFolder,safe);
    try(FileOutputStream os=new FileOutputStream(target)){os.write(bytes);}
    synchronized(shareUris){shareUris.add(toUri(target));}
   }catch(Exception e){notifyError("Pogreška fotografije: "+e.getMessage());}}
   @JavascriptInterface public void sendCompleteOrder(String subject,String body,String number){runOnUiThread(()->makePdfAndShare(subject,body,number));}
  },"Android");
  setContentView(web);web.loadUrl("file:///android_asset/index.html");
 }
 private Uri toUri(File file){return Uri.parse("content://hr.elitesystems.nalog.share/"+file.getName());}
 private void notifyError(String message){runOnUiThread(()->Toast.makeText(this,message,Toast.LENGTH_LONG).show());}
 private void makePdfAndShare(String subject,String body,String number){
  String safe=number.replaceAll("[^a-zA-Z0-9._-]","_");if(safe.isEmpty())safe="Radni_nalog";
  File output=new File(shareFolder,"Elite_Radni_nalog_"+safe+".pdf");
  PrintDocumentAdapter adapter=web.createPrintDocumentAdapter("Elite_Radni_nalog");
  PrintAttributes attrs=new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setResolution(new PrintAttributes.Resolution("pdf","PDF",300,300)).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build();
  adapter.onStart();
  adapter.onLayout(null,attrs,new CancellationSignal(),new PrintDocumentAdapter.LayoutResultCallback(){
   @Override public void onLayoutFinished(PrintDocumentInfo info,boolean changed){
    try{ParcelFileDescriptor fd=ParcelFileDescriptor.open(output,ParcelFileDescriptor.MODE_CREATE|ParcelFileDescriptor.MODE_TRUNCATE|ParcelFileDescriptor.MODE_READ_WRITE);
     adapter.onWrite(new PageRange[]{PageRange.ALL_PAGES},fd,new CancellationSignal(),new PrintDocumentAdapter.WriteResultCallback(){
      @Override public void onWriteFinished(PageRange[] pages){try{fd.close();}catch(Exception e){}adapter.onFinish();shareEmail(subject,body,output);}
      @Override public void onWriteFailed(CharSequence error){try{fd.close();}catch(Exception e){}adapter.onFinish();notifyError("PDF nije izrađen: "+error);}
      @Override public void onWriteCancelled(){try{fd.close();}catch(Exception e){}adapter.onFinish();notifyError("Izrada PDF-a je prekinuta");}
     });
    }catch(Exception e){adapter.onFinish();notifyError("Ne mogu spremiti PDF: "+e.getMessage());}
   }
   @Override public void onLayoutFailed(CharSequence error){adapter.onFinish();notifyError("Priprema PDF-a nije uspjela: "+error);}
   @Override public void onLayoutCancelled(){adapter.onFinish();notifyError("Priprema PDF-a prekinuta");}
  },null);
 }
 private void shareEmail(String subject,String body,File pdf){
  ArrayList<Uri> items=new ArrayList<>();items.add(toUri(pdf));synchronized(shareUris){items.addAll(shareUris);}
  Intent send=new Intent(Intent.ACTION_SEND_MULTIPLE);send.setType("application/octet-stream");
  send.putParcelableArrayListExtra(Intent.EXTRA_STREAM,items);send.putExtra(Intent.EXTRA_SUBJECT,subject);send.putExtra(Intent.EXTRA_TEXT,body);
  send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
  ClipData clip=ClipData.newUri(getContentResolver(),"Radni nalog i fotografije",items.get(0));for(int i=1;i<items.size();i++)clip.addItem(new ClipData.Item(items.get(i)));send.setClipData(clip);
  try{startActivity(Intent.createChooser(send,"Pošalji radni nalog uredu"));}catch(Exception e){notifyError("Nije pronađena aplikacija za slanje: "+e.getMessage());}
 }
 @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request==FILE_REQUEST&&fileCallback!=null){Uri[] out=null;if(result==RESULT_OK&&data!=null){if(data.getClipData()!=null){ClipData clip=data.getClipData();out=new Uri[clip.getItemCount()];for(int i=0;i<out.length;i++)out[i]=clip.getItemAt(i).getUri();}else if(data.getData()!=null){out=new Uri[]{data.getData()};}}fileCallback.onReceiveValue(out);fileCallback=null;}}
 @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}
