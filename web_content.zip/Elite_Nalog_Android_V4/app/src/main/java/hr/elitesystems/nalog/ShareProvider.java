package hr.elitesystems.nalog;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import android.database.MatrixCursor;
import java.io.File;
import java.io.FileNotFoundException;

public class ShareProvider extends ContentProvider {
 @Override public boolean onCreate(){return true;}
 private File getFile(Uri uri) throws FileNotFoundException {String name=uri.getLastPathSegment();if(name==null||name.contains("/")||name.contains(".."))throw new FileNotFoundException();File f=new File(getContext().getCacheDir(),"share/"+name);if(!f.isFile())throw new FileNotFoundException();return f;}
 @Override public String getType(Uri uri){return uri.getLastPathSegment()!=null&&uri.getLastPathSegment().endsWith(".pdf")?"application/pdf":"image/jpeg";}
 @Override public ParcelFileDescriptor openFile(Uri uri,String mode)throws FileNotFoundException {if(!"r".equals(mode))throw new FileNotFoundException();return ParcelFileDescriptor.open(getFile(uri),ParcelFileDescriptor.MODE_READ_ONLY);}
 @Override public Cursor query(Uri uri,String[] projection,String selection,String[] args,String sort){try{File f=getFile(uri);MatrixCursor c=new MatrixCursor(new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE});c.addRow(new Object[]{f.getName(),f.length()});return c;}catch(Exception e){return null;}}
 @Override public Uri insert(Uri uri,ContentValues values){throw new UnsupportedOperationException();}
 @Override public int delete(Uri uri,String where,String[] args){return 0;}
 @Override public int update(Uri uri,ContentValues values,String where,String[] args){return 0;}
}
