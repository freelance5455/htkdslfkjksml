ELITE SYSTEMS – RADNI NALOG V4

Projekt otvoriti u Android Studiju (Open folder Elite_Nalog_Android_V4). Build > Build APK(s). Instalirati APK na Samsung Galaxy Tab S10 Lite.

VAZNO: Ovaj ZIP sadrzi izvorni projekt, a ne gotov APK. Aplikacija nije testirana na fizickom uredjaju.

Podaci i fotografije cuvaju se u privatnoj pohrani aplikacije (WebView localStorage i IndexedDB); brisanje podataka aplikacije moze ih izbrisati.

Slanje uredu: aplikacija izradi PDF pomocu Android WebView PrintDocumentAdaptera i otvori Android dijeljenje s PDF-om i svim fotografijama. Opisi slika navedeni su u tijelu e-maila. Korisnik u e-mail aplikaciji bira primatelja i potvrdu slanja. Internetska veza potrebna je za stvarno slanje.

HTML otvoren iz Samsung My Files ili Chrome content:// NE PODRZAVA pouzdanu pohranu fotografija niti zajednicko slanje priloga. Koristiti instaliranu aplikaciju.
