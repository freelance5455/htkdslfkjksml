FINAL PLANNING CALCULATOR - ANDROID APP PROJECT

यह Android WebView project है। आपके मौजूदा HTML को app/src/main/assets/index.html में रखा गया है।
- App नाम: Final Planning Calculator
- Offline चलने के लिए बनाया गया है
- कोई INTERNET permission नहीं मांगी जाती
- Minimum Android: 7.0 (API 24)
- Package: com.ashish.planningcalculator

APK बनाने के लिए AndroidIDE में इस ZIP को extract करके project folder खोलें और Gradle sync/build करें।
पहली बार AndroidIDE/Android के unknown-apps security prompt आ सकते हैं; इन्हें पूरी तरह हटाने की गारंटी नहीं दी जा सकती। केवल अपने भरोसेमंद source से बनी APK install करें।
