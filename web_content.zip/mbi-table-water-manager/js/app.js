/* App core: helpers, router, dialogs, PIN lock. Pages register themselves on MBI.pages. */
window.MBI = (function () {
  const M = { pages: {}, settings: {}, unlocked: false, current: '' };
  const $ = (s, r = document) => r.querySelector(s);
  M.$ = $;
  M.esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  M.toast = (t, kind) => { const e = $('#toast'); e.textContent = t; e.className = 'toast show ' + (kind || ''); clearTimeout(M._t); M._t = setTimeout(() => e.className = 'toast', 3500); };
  M.errBox = (el, list) => { el.innerHTML = list.length ? '<div class="msg err">' + list.map(M.esc).join('<br>') + '</div>' : ''; };
  M.opts = (arr, sel, label = x => x.name) => arr.map(x => `<option value="${M.esc(x.id)}" ${x.id === sel ? 'selected' : ''}>${M.esc(label(x))}</option>`).join('');
  M.changed = () => M.render();

  /* Generic modal: fields [{name,label,type,value,options,required}] -> values object or null */
  M.ask = (title, fields, okText = 'OK', note = '') => new Promise(res => {
    const d = $('#dlg');
    d.innerHTML = `<form method="dialog"><h3 style="margin-top:0">${M.esc(title)}</h3>${note ? `<p>${note}</p>` : ''}` +
      fields.map(f => `<label for="d_${f.name}">${M.esc(f.label)}</label>` + (f.type === 'select'
        ? `<select id="d_${f.name}">${f.options}</select>`
        : f.type === 'textarea' ? `<textarea id="d_${f.name}" rows="2">${M.esc(f.value || '')}</textarea>`
        : `<input id="d_${f.name}" type="${f.type || 'text'}" value="${M.esc(f.value ?? '')}" ${f.type === 'number' ? 'inputmode="decimal" step="any"' : ''} autocomplete="off">`)).join('') +
      `<p class="err-text" id="d_err"></p><div class="actions"><button class="btn primary" value="ok">${M.esc(okText)}</button><button class="btn" value="cancel" formnovalidate>Cancel</button></div></form>`;
    const form = d.querySelector('form');
    form.addEventListener('submit', ev => {
      if (ev.submitter && ev.submitter.value === 'ok') {
        const out = {}; let bad = '';
        fields.forEach(f => { const v = $('#d_' + f.name).value.trim(); out[f.name] = v; if (f.required && !v) bad = f.label + ' is required.'; });
        if (bad) { ev.preventDefault(); $('#d_err').textContent = bad; return; }
        d._out = out;
      } else d._out = null;
    });
    d.onclose = () => { res(d._out || null); d._out = null; };
    d.showModal();
  });
  M.confirm = async (title, text, okText = 'Yes, continue') => !!(await M.ask(title, [], okText, text));

  /* Authorisation for corrections: asks for the PIN when one is set */
  M.authorise = async () => {
    if (!M.settings.pinHash) return true;
    const r = await M.ask('Authorise this action', [{ name: 'pin', label: 'Enter PIN', type: 'password', required: true }], 'Confirm');
    if (!r) return false;
    if (await M.hashPin(r.pin, M.settings.pinSalt) === M.settings.pinHash) return true;
    M.toast('Wrong PIN', 'err'); return false;
  };
  M.hashPin = async (pin, salt) => {
    const enc = new TextEncoder();
    if (window.crypto && crypto.subtle) {
      const k = await crypto.subtle.importKey('raw', enc.encode(String(pin)), 'PBKDF2', false, ['deriveBits']);
      const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt: enc.encode(salt), iterations: 100000, hash: 'SHA-256' }, k, 256);
      return [...new Uint8Array(bits)].map(b => b.toString(16).padStart(2, '0')).join('');
    }
    let h = 5381; for (const b of enc.encode(salt + ':' + pin)) h = ((h << 5) + h + b) >>> 0; return 'x' + h; // weak fallback when Web Crypto is unavailable (non-secure page)
  };
  M.norm = t => String(t).trim().toLowerCase().replace(/\s+/g, ' ');
  M.questions = ["What is your mother's first name?", 'What was the name of your first school?', 'In which town or village were you born?', 'What was the name of your first pet or your best childhood friend?', 'What was your first phone?'];
  M.validPin = (a, b) => !/^\d{4,8}$/.test(a) ? 'PIN must be 4 to 8 digits (numbers only).' : a !== b ? 'The two PINs do not match.' : '';
  M.lockWait = () => Math.max(0, Math.ceil(((M.settings.lockUntil || 0) - Date.now()) / 1000));
  M.failed = async () => {
    const n = (M.settings.failCount || 0) + 1; M.settings.failCount = n; await DB.setSetting('failCount', n);
    if (n % 5 === 0) { M.settings.lockUntil = Date.now() + Math.min(30 * 2 ** (n / 5 - 1), 900) * 1000; await DB.setSetting('lockUntil', M.settings.lockUntil); }
  };
  M.cleared = async () => { M.settings.failCount = 0; M.settings.lockUntil = 0; await DB.setSetting('failCount', 0); await DB.setSetting('lockUntil', 0); };
  M.setCredentials = async (pin, q, answer) => {
    const salt = V.uid(); await DB.setSetting('pinSalt', salt); await DB.setSetting('pinHash', await M.hashPin(pin, salt));
    if (q) { await DB.setSetting('secQ', q); await DB.setSetting('secAHash', await M.hashPin(M.norm(answer), salt + ':answer')); }
    M.settings = await DB.settings();
  };

  /* Lock screen: modes setup | unlock | forgot */
  M.showLock = mode => {
    const box = $('#lockBox'), S = M.settings; $('#lock').hidden = false;
    const logo = '<img src="assets/images/mbi-logo.jpg" alt="MBI Table Water logo" class="lock-logo">';
    const pinF = (id, label) => `<label for="${id}">${label}</label><input id="${id}" type="password" inputmode="numeric" autocomplete="off" maxlength="8">`;
    const err = '<p class="err-text" id="lockErr" role="alert"></p>';
    const setErr = t => { $('#lockErr').textContent = t; };
    if (mode === 'setup') {
      box.innerHTML = `${logo}<h2>Welcome. Create your PIN</h2><p>This PIN protects this phone or computer only. Nobody can use the app until it is set. Each manager sets their own PIN on their own device.</p>
       <label for="sName">Your name</label><input id="sName" autocomplete="off">${pinF('sPin', 'Choose a PIN (4 to 8 digits)')}${pinF('sPin2', 'Repeat the PIN')}
       <label for="sQ">Security question (used if you forget the PIN)</label><select id="sQ">${M.questions.map(q => `<option>${M.esc(q)}</option>`).join('')}<option value="">Write my own question</option></select>
       <input id="sQc" placeholder="Type your own question" hidden><label for="sA">Answer to the question</label><input id="sA" autocomplete="off">${err}<button class="btn primary big" id="sGo">Create PIN and start</button>`;
      $('#sQ').onchange = e => { $('#sQc').hidden = e.target.value !== ''; };
      $('#sGo').onclick = async () => {
        const name = $('#sName').value.trim(), q = $('#sQ').value || $('#sQc').value.trim(), a = $('#sA').value, e = M.validPin($('#sPin').value, $('#sPin2').value);
        if (!name) return setErr('Type your name.'); if (e) return setErr(e); if (!q) return setErr('Type your security question.'); if (M.norm(a).length < 2) return setErr('Type an answer you will remember.');
        $('#sGo').disabled = true; await M.setCredentials($('#sPin').value, q, a); await DB.setSetting('userName', name); M.settings = await DB.settings(); M.enter();
      };
    } else if (mode === 'unlock') {
      box.innerHTML = `${logo}<h2>Enter your PIN</h2>${pinF('uPin', 'PIN')}${err}<button class="btn primary big" id="uGo">Unlock</button><p><button class="btn sm" id="uForgot" type="button">Forgot PIN?</button></p>`;
      const go = async () => {
        const w = M.lockWait(); if (w) return setErr('Too many wrong tries. Wait ' + w + ' seconds.');
        if (await M.hashPin($('#uPin').value, S.pinSalt) === S.pinHash) { await M.cleared(); M.enter(); }
        else { await M.failed(); const w2 = M.lockWait(); setErr(w2 ? 'Too many wrong tries. Wait ' + w2 + ' seconds.' : 'Wrong PIN. Try again.'); $('#uPin').value = ''; }
      };
      $('#uGo').onclick = go; $('#uPin').onkeydown = e => { if (e.key === 'Enter') go(); }; $('#uForgot').onclick = () => M.showLock('forgot'); setTimeout(() => $('#uPin').focus(), 50);
    } else {
      box.innerHTML = `${logo}<h2>Forgot PIN</h2><p>Answer your security question to set a new PIN.</p><p><strong>${M.esc(S.secQ || '')}</strong></p><label for="fA">Your answer</label><input id="fA" autocomplete="off">${pinF('fPin', 'New PIN (4 to 8 digits)')}${pinF('fPin2', 'Repeat the new PIN')}${err}<button class="btn primary big" id="fGo">Set new PIN</button><p><button class="btn sm" id="fBack" type="button">Back</button></p>`;
      $('#fBack').onclick = () => M.showLock('unlock');
      $('#fGo').onclick = async () => {
        const w = M.lockWait(); if (w) return setErr('Too many wrong tries. Wait ' + w + ' seconds.');
        const e = M.validPin($('#fPin').value, $('#fPin2').value); if (e) return setErr(e);
        if (await M.hashPin(M.norm($('#fA').value), S.pinSalt + ':answer') !== S.secAHash) { await M.failed(); const w2 = M.lockWait(); return setErr(w2 ? 'Too many wrong tries. Wait ' + w2 + ' seconds.' : 'That answer is not correct.'); }
        await M.setCredentials($('#fPin').value, S.secQ, $('#fA').value); await M.cleared(); M.toast('New PIN saved', 'ok'); M.enter();
      };
    }
  };
  M.enter = () => { M.unlocked = true; $('#lock').hidden = true; $('#lockBox').innerHTML = ''; M.render(); };
  M.lock = () => { M.unlocked = false; $('#view').innerHTML = ''; M.showLock('unlock'); };

  /* Save a text file: Capacitor Filesystem+Share if present (Android), otherwise normal download */
  M.saveFile = async (name, text, mime) => {
    const C = window.Capacitor && window.Capacitor.Plugins;
    if (C && C.Filesystem && C.Share) {
      try {
        const r = await C.Filesystem.writeFile({ path: name, data: text, directory: 'CACHE', encoding: 'utf8' });
        await C.Share.share({ title: name, url: r.uri }); return;
      } catch (e) { if (String(e).includes('cancel')) return; }
    }
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type: mime || 'text/plain' }));
    a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  };

  M.render = async () => {
    if (!M.unlocked) return;
    const p = (location.hash.replace('#/', '') || 'dashboard').split('?')[0];
    const page = M.pages[p] ? p : 'dashboard'; M.current = page;
    document.querySelectorAll('#nav a').forEach(a => a.classList.toggle('on', a.dataset.p === page));
    M.settings = await DB.settings();
    const v = $('#view');
    try { await M.pages[page](v); } catch (e) { console.error(e); v.innerHTML = '<div class="msg err">Something went wrong loading this page: ' + M.esc(e.message) + '</div>'; }
  };

  M.start = async () => {
    try { await DB.open(); await DB.ensureSeed(); }
    catch (e) { document.body.innerHTML = '<div class="msg err" style="margin:20px">This browser cannot open local storage (IndexedDB). Private browsing may be the cause. ' + M.esc(e.message) + '</div>'; return; }
    M.settings = await DB.settings();
    if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol)) navigator.serviceWorker.register('service-worker.js').catch(() => { });
    if (navigator.storage && navigator.storage.persist) navigator.storage.persist().catch(() => { });
    window.addEventListener('hashchange', M.render);
    $('#lockNow').onclick = M.lock;
    let hiddenAt = 0;
    document.addEventListener('visibilitychange', () => { // auto-lock after 2 minutes away from the app
      if (document.hidden) hiddenAt = Date.now(); else if (M.unlocked && hiddenAt && Date.now() - hiddenAt > 120000) M.lock();
    });
    M.showLock(M.settings.pinHash ? 'unlock' : 'setup'); // the app is never shown until a PIN exists and has been entered
  };
  return M;
})();
