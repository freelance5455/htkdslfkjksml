MBI.pages.customers = async function (el) {
  const { esc, $ } = MBI; const s = MBI.settings;
  const [customers, sales] = await Promise.all(['customers', 'sales'].map(DB.all));
  const live = sales.filter(x => !x.voided);
  const stats = c => { const m = live.filter(x => x.customerId === c.id); return { m, bags: m.reduce((a, x) => a + x.qty, 0), val: m.reduce((a, x) => a + x.total, 0), paid: m.reduce((a, x) => a + (x.amountPaid || 0), 0), bal: m.reduce((a, x) => a + x.balance, 0) }; };
  const open = MBI._cust;
  const fields = c => [{ name: 'name', label: 'Customer name', value: c.name, required: true }, { name: 'phone', label: 'Phone number', type: 'tel', value: c.phone }, { name: 'business', label: 'Business name (optional)', value: c.business }, { name: 'address', label: 'Address (optional)', value: c.address }, { name: 'notes', label: 'Notes', type: 'textarea', value: c.notes }];
  const edit = async c => { const r = await MBI.ask(c.id ? 'Edit customer' : 'Add customer', fields(c), 'Save customer'); if (!r) return; await DB.put('customers', { ...c, ...r, id: c.id || V.uid(), createdAt: c.createdAt || new Date().toISOString() }); MBI.toast('Customer saved', 'ok'); MBI.changed(); };
  if (open) {
    const c = customers.find(x => x.id === open); if (!c) { MBI._cust = ''; return MBI.render(); }
    const st = stats(c), pn = id => id;
    el.innerHTML = `<p><button class="btn sm" id="back">&larr; All customers</button></p><h2>${esc(c.name)}</h2>
     <p>${esc(c.phone || '')} ${esc(c.business ? '| ' + c.business : '')} ${esc(c.address ? '| ' + c.address : '')}<br>${esc(c.notes || '')}</p>
     <div class="cards"><div class="card"><div class="k">Bags bought</div><div class="v">${st.bags}</div></div><div class="card"><div class="k">Total purchases</div><div class="v">${V.naira(st.val)}</div></div>
     ${s.creditOn ? `<div class="card good"><div class="k">Recorded as paid</div><div class="v">${V.naira(st.paid)}</div></div><div class="card ${st.bal > 0 ? 'warn' : ''}"><div class="k">Balance owed</div><div class="v">${V.naira(st.bal)}</div></div>` : ''}</div>
     <div class="actions"><button class="btn" id="ed">Edit details</button></div>
     <h3>Purchase history</h3>${st.m.length ? `<div class="tablewrap"><table><tr><th>Date</th><th>Receipt</th><th class="n">Bags</th><th class="n">Total</th><th class="n">Paid</th><th class="n">Balance</th><th></th></tr>` +
      st.m.sort((a, b) => b.date.localeCompare(a.date)).map(x => `<tr><td>${x.date}</td><td>${esc(x.receiptNo)}</td><td class="n">${x.qty}</td><td class="n">${V.naira(x.total)}</td><td class="n">${V.naira(x.amountPaid)}</td><td class="n">${V.naira(x.balance)}</td><td>${x.balance > 0 ? `<button class="btn sm good" data-p="${x.id}">Add payment</button>` : ''}</td></tr>`).join('') + '</table></div>' : '<div class="empty">No purchases yet.</div>'}`;
    $('#back').onclick = () => { MBI._cust = ''; MBI.render(); }; $('#ed').onclick = () => edit(c);
    el.querySelectorAll('[data-p]').forEach(b => b.onclick = async () => {
      const r = await MBI.ask('Record a payment received', [{ name: 'amt', label: 'Amount (₦)', type: 'number', required: true }, { name: 'date', label: 'Date', type: 'date', value: V.today() }], 'Save payment', 'For your records only. No money is moved by this app.');
      if (!r) return; try { await DB.addPayment(b.dataset.p, Number(r.amt), r.date); MBI.toast('Payment recorded', 'ok'); MBI.changed(); } catch (e) { MBI.toast(e.message, 'err'); }
    });
    return;
  }
  el.innerHTML = `<h2>Customers</h2><div class="actions"><button class="btn primary" id="add">Add customer</button><button class="btn" id="exp">Export customers (CSV)</button></div>
   ${customers.length ? `<div class="tablewrap"><table><tr><th>Name</th><th>Phone</th><th class="n">Bags</th><th class="n">Purchases</th>${s.creditOn ? '<th class="n">Owes</th>' : ''}<th></th></tr>` +
    customers.sort((a, b) => a.name.localeCompare(b.name)).map(c => { const t = stats(c); return `<tr><td>${esc(c.name)}</td><td>${esc(c.phone || '')}</td><td class="n">${t.bags}</td><td class="n">${V.naira(t.val)}</td>${s.creditOn ? `<td class="n">${V.naira(t.bal)}</td>` : ''}<td><button class="btn sm" data-o="${c.id}">Open</button></td></tr>`; }).join('') + '</table></div>' : '<div class="empty">No customers yet. Walk-in sales do not need a customer record.</div>'}`;
  $('#add').onclick = () => edit({});
  el.querySelectorAll('[data-o]').forEach(b => b.onclick = () => { MBI._cust = b.dataset.o; MBI.render(); });
  $('#exp').onclick = () => MBI.saveFile('mbi-customers-' + V.today() + '.csv', V.csv([['Name', 'Phone', 'Business', 'Address', 'Notes', 'Bags bought', 'Total purchases', 'Recorded paid', 'Balance owed']].concat(customers.map(c => { const t = stats(c); return [c.name, c.phone, c.business, c.address, c.notes, t.bags, t.val, t.paid, t.bal]; }))), 'text/csv');
};
