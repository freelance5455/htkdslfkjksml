MBI.pages.backup = async function (el) {
  const { esc, $ } = MBI; const s = MBI.settings; const products = await DB.all('products');
  const last = s.lastBackup ? new Date(s.lastBackup).toLocaleString() : 'Never';
  el.innerHTML = `<h2>Backup &amp; Settings</h2>
  <div class="msg warn"><strong>Your records are stored only on this device.</strong> They are not backed up to the cloud. Clearing app data, clearing browser data or uninstalling the app can erase everything. Save a backup file regularly and keep a copy somewhere safe (for example send it to yourself on WhatsApp or email).</div>
  <div class="panel"><h3 style="margin-top:0">Backup</h3><p>Last backup: <strong>${esc(last)}</strong></p>
   <button class="btn good big" id="bk">Save backup file</button></div>
  <div class="panel"><h3 style="margin-top:0">Restore from a backup</h3>
   <input type="file" id="rf" accept=".json,application/json"><div id="rerr"></div>
   <label for="mode">How to restore</label><select id="mode"><option value="replace">Replace everything on this device with the backup</option><option value="merge">Merge: add backup records, keep other records</option></select>
   <div class="actions"><button class="btn danger" id="rs">Restore</button></div></div>
  <div class="panel"><h3 style="margin-top:0">Export records (CSV)</h3><div class="actions">
   ${['sales', 'production', 'expenses', 'customers', 'movements'].map(k => `<button class="btn sm" data-x="${k}">${k[0].toUpperCase() + k.slice(1)}</button>`).join('')}</div></div>
  <div class="panel"><h3 style="margin-top:0">Products and prices</h3><p>The price is a suggestion that fills the sale form. Old sales keep the price they were sold at.</p>
   <div class="tablewrap"><table><tr><th>Product</th><th class="n">Current price</th><th></th></tr>${products.map(p => `<tr class="${p.active ? '' : 'void'}"><td>${esc(p.name)}</td><td class="n">${V.naira(p.price)}</td><td><button class="btn sm" data-e="${p.id}">Edit</button></td></tr>`).join('')}</table></div>
   <div class="actions"><button class="btn" id="np">Add product</button></div></div>
  <div class="panel"><h3 style="margin-top:0">Settings</h3>
   <label><input type="checkbox" id="credit" style="width:auto" ${s.creditOn ? 'checked' : ''}> Track credit sales (amount paid and balances)</label>
   <label for="low">Low stock warning (bags)</label><input id="low" type="number" min="0" value="${s.lowStock}">
   <div class="actions"><button class="btn primary" id="ss">Save settings</button></div></div>
  <div class="panel"><h3 style="margin-top:0">PIN and security</h3>
   <p>The PIN on this device is required every time the app opens, and before cancelling or correcting records. The app locks by itself after 2 minutes away. Each manager has their own PIN on their own device. Backup files never contain the PIN.</p>
   <p><small>Local security has limits: a PIN stops normal users, but it cannot stop a skilled person who has full access to the unlocked phone's files. Also keep the phone's own screen lock on.</small></p>
   <div class="actions"><button class="btn primary" id="sp">Change PIN</button><button class="btn" id="sq">Change security question</button><button class="btn" id="ln">Lock now</button></div></div>
  <div class="panel" id="bioPanel"></div>
  <div class="panel" id="aboutPanel"><h3 style="margin-top:0">About application</h3><div class="devrow"><div style="flex:0 0 auto">${MBI.lafeneLogo(84)}</div><div>${MBI.devInfoHtml()}</div></div>
   <div class="actions"><a class="btn primary" href="#/about" style="text-decoration:none;display:inline-block">ABOUT DEVELOPER</a></div></div>`;

  $('#bk').onclick = async () => {
    const b = await DB.exportAll(); const err = DB.validateBackup(b); if (err) return MBI.toast(err, 'err');
    await MBI.saveFile('mbi-backup-' + V.today() + '.json', JSON.stringify(b), 'application/json');
    await DB.setSetting('lastBackup', new Date().toISOString()); MBI.toast('Backup file created', 'ok'); MBI.render();
  };
  $('#rs').onclick = async () => {
    const f = $('#rf').files[0]; if (!f) return MBI.errBox($('#rerr'), ['Choose a backup file first.']);
    let b; try { b = JSON.parse(await f.text()); } catch (e) { return MBI.errBox($('#rerr'), ['This file is not a valid backup (cannot be read).']); }
    const err = DB.validateBackup(b); if (err) return MBI.errBox($('#rerr'), [err]); MBI.errBox($('#rerr'), []);
    const mode = $('#mode').value, n = Object.values(b.counts || {}).reduce((a, c) => a + c, 0);
    const ok = await MBI.confirm('Restore this backup?', `Backup made ${new Date(b.exportedAt).toLocaleString()} with ${n} records. ` + (mode === 'replace' ? '<strong>All current records on this device will be replaced.</strong> Save a backup of the current data first if unsure.' : 'Records with the same ID will be overwritten.'), 'Restore now');
    if (!ok || !(await MBI.authorise())) return;
    try { await DB.restore(b, mode); MBI.toast('Restore complete: ' + n + ' records loaded.', 'ok'); MBI.render(); }
    catch (e) { MBI.errBox($('#rerr'), ['Restore failed and nothing was changed: ' + e.message]); }
  };
  el.querySelectorAll('[data-x]').forEach(b => b.onclick = async () => {
    const k = b.dataset.x, rows = await DB.all(k); if (!rows.length) return MBI.toast('No ' + k + ' records to export.');
    const cols = [...new Set(rows.flatMap(r => Object.keys(r)))].filter(c => typeof rows[0][c] !== 'object' || rows[0][c] === null);
    await MBI.saveFile('mbi-' + k + '-' + V.today() + '.csv', V.csv([cols].concat(rows.map(r => cols.map(c => r[c])))), 'text/csv');
  });
  const prodForm = p => [{ name: 'name', label: 'Product name', value: p.name, required: true }, { name: 'price', label: 'Current price per bag (₦)', type: 'number', value: p.price }, { name: 'active', label: 'Status', type: 'select', options: `<option value="1" ${p.active !== false ? 'selected' : ''}>In use</option><option value="0" ${p.active === false ? 'selected' : ''}>Hidden</option>` }];
  const saveProd = async p => { const r = await MBI.ask(p.id ? 'Edit product' : 'Add product', prodForm(p), 'Save'); if (!r) return; const price = Number(r.price || 0); if (!(price >= 0)) return MBI.toast('Invalid price', 'err'); await DB.put('products', { ...p, id: p.id || V.uid(), name: r.name, price, active: r.active !== '0', createdAt: p.createdAt || new Date().toISOString() }); MBI.render(); };
  el.querySelectorAll('[data-e]').forEach(b => b.onclick = () => saveProd(products.find(p => p.id === b.dataset.e)));
  $('#np').onclick = () => saveProd({});
  $('#ss').onclick = async () => { await DB.setSetting('creditOn', $('#credit').checked); await DB.setSetting('lowStock', Math.max(0, Number($('#low').value) || 0)); MBI.toast('Settings saved', 'ok'); MBI.render(); };
  $('#sp').onclick = async () => {
    if (!(await MBI.authorise())) return;
    const r = await MBI.ask('Change PIN', [{ name: 'a', label: 'New PIN (4 to 8 digits)', type: 'password', required: true }, { name: 'b', label: 'Repeat new PIN', type: 'password', required: true }, { name: 'ans', label: 'Security answer: ' + s.secQ, required: true }], 'Save PIN', 'Your security answer is asked so that "Forgot PIN" keeps working.');
    if (!r) return; const e = MBI.validPin(r.a, r.b); if (e) return MBI.toast(e, 'err');
    if (await MBI.hashPin(MBI.norm(r.ans), s.pinSalt + ':answer') !== s.secAHash) return MBI.toast('Security answer is not correct. PIN not changed.', 'err');
    await MBI.setCredentials(r.a, s.secQ, r.ans); MBI.toast('PIN changed', 'ok'); MBI.render();
  };
  $('#sq').onclick = async () => {
    if (!(await MBI.authorise())) return;
    const r = await MBI.ask('Security question', [{ name: 'q', label: 'Question', value: s.secQ, required: true }, { name: 'a', label: 'Answer', required: true }], 'Save');
    if (!r) return; if (MBI.norm(r.a).length < 2) return MBI.toast('Answer is too short', 'err');
    await DB.setSetting('secQ', r.q); await DB.setSetting('secAHash', await MBI.hashPin(MBI.norm(r.a), s.pinSalt + ':answer')); MBI.toast('Security question saved', 'ok'); MBI.render();
  };
  $('#ln').onclick = MBI.lock;
  const sup = await Biometric.support(), on = !!s.bioCred, bp = $('#bioPanel');
  bp.innerHTML = '<h3 style="margin-top:0">Fingerprint unlock</h3>' + (!sup && !on ? '<p>Fingerprint unlock is not available on this device or in this browser. You can keep using your PIN as normal.</p>'
    : `<p>Status: <strong>${on ? 'ON' : 'OFF'}</strong>. Your PIN always still works. The phone checks your fingerprint itself; this app never sees or stores fingerprint data. Some phones may also accept their screen-lock method.</p><div class="actions">${on ? '<button class="btn danger" id="bd">Turn off fingerprint unlock</button>' : '<button class="btn primary" id="be">Turn on fingerprint unlock</button>'}</div>`);
  if ($('#be')) $('#be').onclick = async () => { if (!(await MBI.authorise())) return; try { await Biometric.enable(); MBI.toast('Fingerprint unlock is on', 'ok'); MBI.render(); } catch (e) { MBI.toast(/cancel|abort|NotAllowed/i.test(e.name + e.message) ? 'Fingerprint was not confirmed. Not turned on.' : e.message, 'err'); } };
  if ($('#bd')) $('#bd').onclick = async () => { if (!(await MBI.authorise())) return; await Biometric.disable(); MBI.toast('Fingerprint unlock is off', 'ok'); MBI.render(); };
};
