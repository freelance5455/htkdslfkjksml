MBI.pages.reports = async function (el) {
  const { esc, $ } = MBI; const s = MBI.settings; const date = MBI._rDate || V.today();
  const [products, sales, exp, mvs, prod] = await Promise.all(['products', 'sales', 'expenses', 'movements', 'production'].map(DB.all));
  const bucket = m => m.type === 'reversal' ? m.refType : (m.type === 'opening' ? 'adjustment' : m.type);
  const lines = products.map(p => {
    const pm = mvs.filter(m => m.productId === p.id);
    const sum = f => pm.filter(m => m.date === date && bucket(m) === f).reduce((a, m) => a + m.qty, 0);
    const opening = pm.filter(m => m.date < date).reduce((a, m) => a + m.qty, 0);
    const r = { name: p.name, opening, prod: sum('production'), recv: sum('received'), sold: -sum('sale'), dmg: -sum('damaged'), iss: -sum('issued'), adj: sum('adjustment') };
    r.closing = V.closingStock(r.opening, r.prod, r.recv, r.sold, r.dmg, r.iss, r.adj); return r;
  }).filter(r => r.opening || r.prod || r.recv || r.sold || r.dmg || r.iss || r.adj || r.closing);
  const T = k => lines.reduce((a, r) => a + r[k], 0);
  const daySales = sales.filter(x => x.date === date && !x.voided), dayExp = exp.filter(x => x.date === date && !x.voided);
  const salesVal = daySales.reduce((a, x) => a + x.total, 0), expVal = dayExp.reduce((a, x) => a + x.amount, 0);
  const bal = daySales.reduce((a, x) => a + x.balance, 0), allBal = sales.filter(x => !x.voided).reduce((a, x) => a + x.balance, 0);
  const txCount = daySales.length + dayExp.length + prod.filter(x => x.date === date && !x.voided).length + mvs.filter(m => m.date === date && ['received', 'damaged', 'issued', 'adjustment'].includes(m.type)).length;
  const hdr = ['Product', 'Opening', 'Produced', 'Received', 'Sold', 'Damaged', 'Other issued', 'Adjustments', 'Closing'];
  const body = lines.map(r => [r.name, r.opening, r.prod, r.recv, r.sold, r.dmg, r.iss, r.adj, r.closing]);
  el.innerHTML = `<div class="print-only" style="text-align:center"><img src="assets/images/mbi-logo.jpg" alt="MBI Table Water" style="height:90px"></div>
  <h2>Daily report: ${date}</h2><div class="filter no-print"><div><label for="rd">Report date</label><input type="date" id="rd" value="${date}"></div></div>
  <div class="actions"><button class="btn primary" id="pr">Print report</button><button class="btn" id="csv">Download CSV</button></div>
  <div class="tablewrap"><table><tr>${hdr.map((h, i) => `<th class="${i ? 'n' : ''}">${h}</th>`).join('')}</tr>${body.map(r => '<tr>' + r.map((c, i) => `<td class="${i ? 'n' : ''}">${i ? c : esc(c)}</td>`).join('') + '</tr>').join('') || '<tr><td colspan="9"><div class="empty">No stock records yet.</div></td></tr>'}
   <tr><th>Total</th>${['opening', 'prod', 'recv', 'sold', 'dmg', 'iss', 'adj', 'closing'].map(k => `<th class="n">${T(k)}</th>`).join('')}</tr></table></div>
  <p><small>Closing = Opening + Produced + Received − Sold − Damaged − Other issued + Adjustments. Adjustments include stock counts, opening balances and reversals of non-sale records.</small></p>
  <div class="cards"><div class="card good"><div class="k">Total sales value</div><div class="v">${V.naira(salesVal)}</div></div><div class="card"><div class="k">Recorded expenses</div><div class="v">${V.naira(expVal)}</div></div>
  <div class="card"><div class="k">Transactions</div><div class="v">${txCount}</div></div>${s.creditOn ? `<div class="card ${bal > 0 ? 'warn' : ''}"><div class="k">Unpaid from today's sales</div><div class="v">${V.naira(bal)}</div></div>` : ''}</div>
  ${s.creditOn ? `<p>Total customer balances outstanding (all dates): <strong>${V.naira(allBal)}</strong></p>` : ''}
  <p><small>Expenses are shown separately from sales. This report does not calculate profit.</small></p>
  <p class="print-only">Printed ${new Date().toLocaleString()}</p>`;
  $('#rd').onchange = e => { MBI._rDate = e.target.value || V.today(); MBI.render(); };
  $('#pr').onclick = () => window.print();
  $('#csv').onclick = () => MBI.saveFile('mbi-daily-report-' + date + '.csv', V.csv([['MBI Table Water daily report', date], hdr].concat(body, [[], ['Total sales value', salesVal], ['Recorded expenses', expVal], ['Transactions', txCount], ['Unpaid from this day\'s sales', bal], ['Outstanding customer balances (all dates)', allBal]])), 'text/csv');
};
