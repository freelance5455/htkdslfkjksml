/* Developer attribution + About Developer page. Official logo file: assets/images/lafene-logo.jpg (the developer's uploaded file, unmodified). */
(function () {
  const LOGO = 'assets/images/lafene-logo.jpg';
  MBI.lafeneLogo = (h, cls) => `<img src="${LOGO}" alt="Lafene Tech Hub logo" class="${cls || ''}" style="height:${h}px;width:auto;max-width:100%;object-fit:contain" onerror="this.outerHTML='<span class=&quot;logo-missing&quot; style=&quot;height:${h}px;min-width:${h}px&quot;>Logo not added yet</span>'">`;
  const SKILLS = [
    ['A. Graphic Design and Branding', ['Graphic design', 'Logo design', 'Flyer and poster design', 'Social media graphics', 'Brand identity design', 'Typography and layout', 'Business promotional materials', 'Advertising designs', 'Visual communication']],
    ['B. Video Editing and Video Production', ['Video editing', 'Promotional video production', 'Social media video creation', 'Video storytelling', 'Audio and video synchronization', 'Subtitle creation', 'Video transitions and effects', 'Video colour correction', 'Advertisement editing', 'Educational video production', 'AI-assisted video production']],
    ['C. Animation and Visual Effects', ['2D animation', '3D animation', 'Motion graphics', 'Visual effects (VFX)', 'Animated advertisements', 'Character-based animation', 'AI-assisted animation workflows']],
    ['D. Website Design and Web Development', ['Website design', 'Front-end development', 'Back-end development', 'Responsive web design', 'HTML', 'CSS', 'JavaScript', 'PHP', 'MySQL', 'Database integration', 'Website maintenance', 'Web-based management systems']],
    ['E. Software and Application Development', ['Programming', 'Software development', 'Web application development', 'Android application development', 'Application interface development', 'Application testing', 'Application debugging', 'Database design', 'Business management software', 'Offline-first application development']],
    ['F. UI/UX Design', ['User interface design', 'User experience design', 'Website interface design', 'Mobile application interface design', 'Responsive layouts', 'Usability improvements', 'Interface consistency']],
    ['G. Artificial Intelligence and Machine Learning', ['Artificial intelligence', 'Machine learning', 'AI-assisted design', 'AI-assisted video production', 'AI image-generation workflows', 'AI video-generation workflows', 'AI tools for productivity', 'AI-powered automation concepts']],
    ['H. Cybersecurity and Ethical Hacking (learning field)', ['Cybersecurity education', 'Computer security fundamentals', 'Ethical hacking education', 'Digital safety awareness', 'Security research', 'Authorized security testing', 'Learning about cybersecurity tools and techniques']],
    ['I. Computer Hardware and Software', ['Computer hardware maintenance', 'Computer assembly and troubleshooting', 'Operating system installation', 'Software installation', 'Computer maintenance', 'Computer diagnostics', 'Hardware troubleshooting', 'Software troubleshooting']],
    ['J. Mobile Phone Technology', ['Mobile phone repair', 'Mobile phone troubleshooting', 'Mobile software maintenance', 'Phone hardware diagnostics', 'Mobile device support']],
    ['K. Electrical Engineering and Electronics (interest and learning field)', ['Electrical engineering as a technical field', 'Basic electronics', 'Electrical and electronic systems', 'Learning about electrical components and circuits', 'Practical technology and engineering projects']],
    ['L. Robotics and Automation', ['Robotics', 'Technology automation', 'Smart systems', 'AI-powered automation concepts', 'Innovative engineering projects']],
    ['M. Computer Science and Programming', ['Computer science', 'Programming fundamentals', 'Software logic', 'Database management systems', 'Web technologies', 'Technology research', 'Software problem-solving']],
    ['N. Technology Education and Digital Skills', ['Computer skills training', 'Digital literacy', 'Technology tutorials', 'Beginner-friendly technical instruction', 'Educational content creation', 'Technology awareness', 'Digital skills development']],
  ];
  MBI.devInfoHtml = () => `<dl class="info"><dt>Application name</dt><dd>MBI TABLE WATER Manager</dd><dt>Developed by</dt><dd>Lafene Tech Hub</dd><dt>Developer</dt><dd>Abdul Kareem Muhammad Lafene</dd>
    <dt>Education</dt><dd>Computer Science student at Niger State Polytechnic, Zungeru, Niger State, Nigeria.</dd><dt>Copyright</dt><dd>© 2026 Lafene Tech Hub. All rights reserved.</dd></dl>`;
  MBI.pages.about = async function (el) {
    el.innerHTML = `<p><a class="btn sm" href="#/backup">&larr; Back to Settings</a></p>
    <div class="panel" style="text-align:center">${MBI.lafeneLogo(190)}
     <h2 style="margin-bottom:0">LAFENE TECH HUB</h2><p style="margin:.3em 0">Developed by:<br><strong>Abdul Kareem Muhammad Lafene</strong></p>
     <p class="muted">Computer Science Student | Technology Developer | Creative Designer | Video Editor</p></div>
    <div class="panel"><h3 style="margin-top:0">About the developer</h3>
     <p>Abdul Kareem Muhammad Lafene is a Computer Science student at Niger State Polytechnic, Zungeru, Niger State, Nigeria. He is a technology enthusiast, creative designer, video editor, web developer, software developer and digital technology practitioner, working under the brand name Lafene Tech Hub.</p>
     <p><strong>Lafene Tech Hub</strong> offers: website and application development, software development, graphic design, video editing and production, and digital technology solutions.</p></div>
    <div class="panel"><h3 style="margin-top:0">Skills, areas of practice and learning fields</h3>
     <p class="muted">These describe the developer's skills, interests and fields of study. They are not professional licences or certifications.</p>
     ${SKILLS.map(([t, l], i) => `<details ${i === 0 ? 'open' : ''}><summary>${MBI.esc(t)}</summary><ul>${l.map(x => `<li>${MBI.esc(x)}</li>`).join('')}</ul></details>`).join('')}</div>
    <div class="panel"><h3 style="margin-top:0">Application information</h3>${MBI.devInfoHtml()}<p class="muted">MBI TABLE WATER Manager keeps all business records on this device. No information is sent to the developer or to any server.</p></div>`;
  };
})();
