/* Fingerprint / biometric unlock. Real device verification only: nothing here fakes a fingerprint.
   Path A (Android APK): native BiometricPrompt via the Capacitor plugin "BiometricAuth" (UNTESTED here).
   Path B (browser/PWA): WebAuthn platform authenticator with userVerification required; the result is
   verified locally (challenge, origin, user-verified flag, signature). No fingerprint data is ever read or stored. */
(function (root) {
  const B = {};
  const b64 = u => btoa(String.fromCharCode(...new Uint8Array(u)));
  const unb64 = s => Uint8Array.from(atob(s), c => c.charCodeAt(0));
  const b64url = u => b64(u).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  const native = () => root.Capacitor && root.Capacitor.Plugins && root.Capacitor.Plugins.BiometricAuth;

  B.support = async () => {
    const n = native();
    if (n) { try { const r = await n.checkBiometry(); return r && r.isAvailable ? 'native' : null; } catch (e) { return null; } }
    try {
      if (root.isSecureContext && root.PublicKeyCredential && PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable && await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable()) return 'webauthn';
    } catch (e) { }
    return null;
  };

  B.enable = async () => { // caller must have verified the PIN first
    const kind = await B.support(); if (!kind) throw new Error('Fingerprint unlock is not available on this device or browser. Keep using your PIN.');
    if (kind === 'native') {
      await native().authenticate({ reason: 'Confirm your fingerprint to turn on fingerprint unlock', cancelTitle: 'Cancel', allowDeviceCredential: false });
      return DB.setSetting('bioCred', { kind: 'native' });
    }
    const cred = await navigator.credentials.create({ publicKey: {
      challenge: crypto.getRandomValues(new Uint8Array(32)), rp: { name: 'MBI Table Water Manager', id: location.hostname },
      user: { id: crypto.getRandomValues(new Uint8Array(16)), name: 'device-owner', displayName: 'Device owner' },
      pubKeyCredParams: [{ type: 'public-key', alg: -7 }, { type: 'public-key', alg: -257 }],
      authenticatorSelection: { authenticatorAttachment: 'platform', userVerification: 'required', residentKey: 'discouraged' }, timeout: 60000, attestation: 'none' } });
    const r = cred.response;
    if (!r.getPublicKey || !r.getPublicKeyAlgorithm || !r.getAuthenticatorData) throw new Error('This browser cannot check fingerprint results safely. Keep using your PIN.');
    if (!(new Uint8Array(r.getAuthenticatorData())[32] & 4)) throw new Error('The phone did not verify your fingerprint. Not enabled.');
    await DB.setSetting('bioCred', { kind: 'webauthn', id: b64(cred.rawId), pk: b64(r.getPublicKey()), alg: r.getPublicKeyAlgorithm() });
  };

  const derToRaw = d => { // ECDSA DER signature -> 64-byte raw
    d = new Uint8Array(d); let i = 2; const part = () => { i++; let l = d[i++]; let x = d.slice(i, i + l); i += l; while (x.length > 32 && x[0] === 0) x = x.slice(1); const o = new Uint8Array(32); o.set(x, 32 - x.length); return o; };
    const r = part(), s = part(); const out = new Uint8Array(64); out.set(r); out.set(s, 32); return out;
  };

  /* Resolves true only after real, verified success. Anything else throws. */
  B.unlock = async () => {
    const c = (await DB.settings()).bioCred; if (!c) throw new Error('Fingerprint unlock is not turned on.');
    if (c.kind === 'native') { const n = native(); if (!n) throw new Error('Fingerprint is not available. Use your PIN.'); await n.authenticate({ reason: 'Unlock MBI Table Water Manager', cancelTitle: 'Use PIN', allowDeviceCredential: false }); return true; }
    const challenge = crypto.getRandomValues(new Uint8Array(32));
    const a = await navigator.credentials.get({ publicKey: { challenge, rpId: location.hostname, allowCredentials: [{ type: 'public-key', id: unb64(c.id) }], userVerification: 'required', timeout: 60000 } });
    const r = a.response, cd = JSON.parse(new TextDecoder().decode(r.clientDataJSON)), ad = new Uint8Array(r.authenticatorData);
    if (cd.type !== 'webauthn.get' || cd.challenge !== b64url(challenge) || cd.origin !== location.origin) throw new Error('Fingerprint check failed.');
    if (!(ad[32] & 4)) throw new Error('Fingerprint was not verified.');
    const hash = new Uint8Array(await crypto.subtle.digest('SHA-256', r.clientDataJSON)), data = new Uint8Array(ad.length + 32); data.set(ad); data.set(hash, ad.length);
    const pk = unb64(c.pk); let ok;
    if (c.alg === -7) ok = await crypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, await crypto.subtle.importKey('spki', pk, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']), derToRaw(r.signature), data);
    else if (c.alg === -257) ok = await crypto.subtle.verify('RSASSA-PKCS1-v1_5', await crypto.subtle.importKey('spki', pk, { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' }, false, ['verify']), r.signature, data);
    if (!ok) throw new Error('Fingerprint check failed.');
    return true;
  };
  B.disable = () => DB.setSetting('bioCred', '');
  root.Biometric = B;
})(window);
