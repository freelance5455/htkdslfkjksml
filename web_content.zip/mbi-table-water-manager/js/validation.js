/* Pure helpers: money maths, stock maths, validation. No DOM, no storage. */
(function (root) {
  const V = {
    money: n => Math.round((Number(n) + Number.EPSILON) * 100) / 100,
    naira: n => '₦' + Number(n || 0).toLocaleString('en-NG', { maximumFractionDigits: 2 }),
    today() { const d = new Date(); return V.dateStr(d); },
    dateStr(d) { return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); },
    isDate: s => /^\d{4}-\d{2}-\d{2}$/.test(s || '') && !isNaN(new Date(s + 'T00:00:00')),
    isWhole: n => Number.isInteger(n) && n > 0,
    calcSale(qty, price, discount) {
      const subtotal = V.money((qty || 0) * (price || 0));
      return { subtotal, total: V.money(subtotal - (discount || 0)) };
    },
    closingStock: (o, prod, recv, sold, dmg, issued, adj) => o + prod + recv - sold - dmg - issued + (adj || 0),
    validateSale(s, creditOn) {
      const e = [];
      if (!V.isDate(s.date)) e.push('Choose a valid sale date.');
      if (!s.productId) e.push('Choose a product.');
      if (!V.isWhole(s.qty)) e.push('Number of bags must be a whole number above zero.');
      if (!(s.unitPrice >= 0) || !isFinite(s.unitPrice)) e.push('Enter a valid price per bag.');
      if (!(s.discount >= 0)) e.push('Discount cannot be negative.');
      const c = V.calcSale(s.qty, s.unitPrice, s.discount);
      if (s.discount > c.subtotal) e.push('Discount cannot be more than the subtotal.');
      if (creditOn) {
        if (!(s.amountPaid >= 0)) e.push('Amount paid cannot be negative.');
        if (s.amountPaid > c.total) e.push('Amount paid cannot be more than the total.');
        if (s.amountPaid < c.total && !s.customerId) e.push('Choose a customer for a part-paid or unpaid sale.');
      }
      return e;
    },
    validateQtyDate(r) {
      const e = [];
      if (!V.isDate(r.date)) e.push('Choose a valid date.');
      if (!r.productId) e.push('Choose a product.');
      if (!V.isWhole(r.qty)) e.push('Number of bags must be a whole number above zero.');
      return e;
    },
    csv(rows) {
      const q = v => { v = v == null ? '' : String(v); return /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; };
      return '\ufeff' + rows.map(r => r.map(q).join(',')).join('\r\n');
    },
    uid() { return (crypto.randomUUID ? crypto.randomUUID() : 'id-' + Date.now() + '-' + Math.random().toString(16).slice(2)); }
  };
  if (typeof module !== 'undefined') module.exports = V; else root.V = V;
})(typeof window !== 'undefined' ? window : globalThis);
