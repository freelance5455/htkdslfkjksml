MBI.pages.expenses = async function (el) {
  const { esc, $ } = MBI; const s = MBI.settings;
  const all = await DB.all('expenses'); const cats = ['Generator fuel', 'Transportation', 'Electricity', 'Machine maintenance', 'Packaging materials', 'Staff wages', 'Other'];
  const now = new Date(), pad = V.dateStr;
  const mon = new Date(now); mon.setDate(now.getDate() - ((now.getDay() + 6) % 7));
  const presets = { day: [V.today(), V.today()], week: [pad(mon), V.today()], month: [pad(new Date(now.getFullYear(), now.getMonth(), 1)), V.today()] };
  const [from, to] = MBI._eRange || presets.day;
  el.innerHTML = `<h2>Record an expense</h2><form class="panel" id="ef" novalidate><div class="row">
   <div><label for="date">Expense date</label><input type="date" id="date" value="${V.today()}"></div>
   <div><label for="cat">Category</label><select id="cat">${cats.map(c => `<option>${c}</option>`).join('')}</select></div>
   <div><label for="amt">Amount (₦)</label><input id="amt" type="number" inputmode="decimal" min="0" step="any"></div>
   <div><label for="person">Recorded by</label><input id="person" value="${esc(s.userName)}"></div></div>
   <label for="desc">Description</label><input id="desc"><label for="notes">Notes</label><input id="notes"><div id="err"></div>
   <button class="btn good big" id="save" type="submit">Save expense</button></form>
  <h3>Expense totals</h3><div class="actions"><button class="btn sm" data-r="day">Today</button><button class="btn sm" data-r="week">This week</button><button class="btn sm" data-r="month">This month</button></div>
  <div class="filter"><div><label for="f1">From</label><input type="date" id="f1" value="${from}"></div><div><label for="f2">To</label><input type="date" id="f2" value="${to}"></div></div><div id="hist"></div>`;
  let clientDone = false;
  $('#ef').onsubmit = async ev => {
    ev.preventDefault(); if (clientDone) return; const amt = Number($('#amt').value), errs = [];
    if (!V.isDate($('#date').value)) errs.push('Choose a valid date.'); if (!(amt > 0)) errs.push('Enter an amount above zero.'); if (!$('#desc').value.trim()) errs.push('Add a short description.');
    MBI.errBox($('#err'), errs); if (errs.length) return; clientDone = true; $('#save').disabled = true;
    try { await DB.saveExpense({ date: $('#date').value, category: $('#cat').value, amount: V.money(amt), description: $('#desc').value.trim(), person: $('#person').value.trim(), notes: $('#notes').value.trim() }); MBI.toast('Expense saved', 'ok'); MBI.changed(); }
    catch (e) { MBI.errBox($('#err'), [e.message]); clientDone = false; $('#save').disabled = false; }
  };
  const rows = all.filter(x => x.date >= from && x.date <= to).sort((a, b) => b.date.localeCompare(a.date));
  const live = rows.filter(x => !x.voided), tot = live.reduce((a, x) => a + x.amount, 0), by = {};
  live.forEach(x => by[x.category] = (by[x.category] || 0) + x.amount);
  $('#hist').innerHTML = `<div class="panel"><strong>Total recorded expenses: ${V.naira(tot)}</strong><br>${Object.entries(by).map(([k, v]) => `${esc(k)}: ${V.naira(v)}`).join(' | ') || 'None in this period.'}
   <br><small>This is only the expenses you recorded. It is not the business's net profit.</small></div>` +
    (rows.length ? `<div class="tablewrap"><table><tr><th>Date</th><th>Category</th><th>Description</th><th class="n">Amount</th><th></th></tr>` + rows.map(x => `<tr class="${x.voided ? 'void' : ''}"><td>${x.date}</td><td>${esc(x.category)}</td><td>${esc(x.description)}</td><td class="n">${V.naira(x.amount)}</td><td>${x.voided ? 'Cancelled' : `<button class="btn sm danger" data-v="${x.id}">Cancel</button>`}</td></tr>`).join('') + '</table></div>' : '');
  el.querySelectorAll('[data-r]').forEach(b => b.onclick = () => { MBI._eRange = presets[b.dataset.r]; MBI.render(); });
  $('#f1').onchange = $('#f2').onchange = () => { MBI._eRange = [$('#f1').value, $('#f2').value]; MBI.render(); };
  el.querySelectorAll('[data-v]').forEach(b => b.onclick = async () => {
    const r = await MBI.ask('Cancel this expense?', [{ name: 'reason', label: 'Reason', required: true }], 'Cancel expense', 'It stays in history, marked as cancelled.');
    if (!r || !(await MBI.authorise())) return; const x = all.find(y => y.id === b.dataset.v); await DB.put('expenses', { ...x, voided: true, voidReason: r.reason }); MBI.toast('Expense cancelled', 'ok'); MBI.changed();
  });
};
