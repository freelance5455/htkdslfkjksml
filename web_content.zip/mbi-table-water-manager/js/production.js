MBI.pages.production = async function (el) {
  const { esc, $ } = MBI; const s = MBI.settings;
  const [products, prod] = await Promise.all(['products', 'production'].map(DB.all));
  const act = products.filter(p => p.active), name = id => (products.find(p => p.id === id) || {}).name || '?';
  const from = MBI._pFrom || V.today(), to = MBI._pTo || V.today(); const clientKey = V.uid();
  el.innerHTML = `<h2>Record production</h2><form class="panel" id="pf" novalidate><div class="row">
   <div><label for="date">Production date</label><input type="date" id="date" value="${V.today()}"></div>
   <div><label for="prod">Product</label><select id="prod">${MBI.opts(act)}</select></div>
   <div><label for="qty">Bags produced</label><input id="qty" type="number" inputmode="numeric" min="1" step="1"></div>
   <div><label for="shift">Shift (optional)</label><input id="shift" placeholder="Morning / Afternoon"></div>
   <div><label for="person">Recorded by</label><input id="person" value="${esc(s.userName)}"></div></div>
   <label for="notes">Notes</label><textarea id="notes" rows="2"></textarea><div id="err"></div>
   <button class="btn good big" id="save" type="submit">Save production</button></form>
  <h3>Production history</h3>
  <div class="filter"><div><label for="f1">From</label><input type="date" id="f1" value="${from}"></div><div><label for="f2">To</label><input type="date" id="f2" value="${to}"></div></div><div id="hist"></div>`;
  $('#pf').onsubmit = async ev => {
    ev.preventDefault(); const b = $('#save'); if (b.disabled) return;
    const r = { clientKey, date: $('#date').value, productId: $('#prod').value, qty: Number($('#qty').value), shift: $('#shift').value.trim(), person: $('#person').value.trim(), notes: $('#notes').value.trim() };
    const errs = V.validateQtyDate(r); MBI.errBox($('#err'), errs); if (errs.length) return;
    b.disabled = true;
    try { const x = await DB.saveProduction(r); if (r.person !== s.userName) await DB.setSetting('userName', r.person); MBI.toast(x.duplicate ? 'Already saved.' : 'Production saved', 'ok'); MBI.changed(); }
    catch (e) { MBI.errBox($('#err'), [e.message]); b.disabled = false; }
  };
  const rows = prod.filter(x => x.date >= from && x.date <= to).sort((a, b) => b.date.localeCompare(a.date) || b.createdAt.localeCompare(a.createdAt));
  $('#hist').innerHTML = rows.length ? `<div class="tablewrap"><table><tr><th>Date</th><th>Product</th><th class="n">Bags</th><th>Shift</th><th>By</th><th></th></tr>` +
    rows.map(x => `<tr class="${x.voided ? 'void' : ''}"><td>${x.date}</td><td>${esc(name(x.productId))}</td><td class="n">${x.qty}</td><td>${esc(x.shift || '')}</td><td>${esc(x.person || '')}</td><td>${x.voided ? 'Reversed' : `<button class="btn sm danger" data-v="${x.id}">Reverse</button>`}</td></tr>`).join('') + '</table></div>' : '<div class="empty">No production in these dates.</div>';
  el.querySelectorAll('[data-v]').forEach(b => b.onclick = async () => {
    const r = await MBI.ask('Reverse this production record?', [{ name: 'reason', label: 'Reason', required: true }], 'Reverse', 'The record stays in history as reversed and the bags are removed from stock.');
    if (!r || !(await MBI.authorise())) return;
    try { await DB.voidProduction(b.dataset.v, r.reason, s.userName); MBI.toast('Production reversed', 'ok'); MBI.changed(); } catch (e) { MBI.toast(e.message, 'err'); }
  });
  $('#f1').onchange = e => { MBI._pFrom = e.target.value; MBI.render(); }; $('#f2').onchange = e => { MBI._pTo = e.target.value; MBI.render(); };
};
