MBI.pages.dashboard = async function (el) {
  const { esc } = MBI; const date = MBI._dashDate || V.today(); const s = MBI.settings;
  const [products, sales, prod, exp, mvs, customers] = await Promise.all(['products', 'sales', 'production', 'expenses', 'movements', 'customers'].map(DB.all));
  const live = sales.filter(x => !x.voided), pName = id => (products.find(p => p.id === id) || {}).name || '?';
  const day = live.filter(x => x.date === date);
  const bucket = m => m.type === 'reversal' ? m.refType : m.type;
  const produced = mvs.filter(m => m.date === date && bucket(m) === 'production').reduce((a, m) => a + m.qty, 0);
  const sold = -mvs.filter(m => m.date === date && bucket(m) === 'sale').reduce((a, m) => a + m.qty, 0);
  const stock = await DB.stockMap();
  const totalStock = Object.values(stock).reduce((a, b) => a + b, 0);
  const salesValue = day.reduce((a, x) => a + x.total, 0);
  const expToday = exp.filter(x => x.date === date && !x.voided).reduce((a, x) => a + x.amount, 0);
  const owed = live.reduce((a, x) => a + x.balance, 0);
  const warns = products.filter(p => p.active && (stock[p.id] || 0) <= s.lowStock).map(p => `<div class="msg warn">Low stock: ${esc(p.name)} has ${stock[p.id] || 0} bag(s) left (warning level ${s.lowStock}).</div>`).join('');
  const days = s.lastBackup ? Math.floor((Date.now() - new Date(s.lastBackup)) / 864e5) : null;
  const bk = days === null ? '<div class="msg warn">No backup made yet. Your records live only on this device. Go to Backup &amp; Settings and save a backup file.</div>' : days >= 7 ? `<div class="msg warn">Last backup was ${days} days ago. Please make a new backup.</div>` : '';
  const recent = (arr, f) => arr.slice().sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 5).map(f).join('');
  const nothing = '<div class="empty">Nothing recorded yet.</div>';
  const rs = recent(live, x => `<tr><td>${x.date}</td><td>${esc(x.receiptNo)}</td><td>${esc(x.customerName || 'Walk-in')}</td><td class="n">${x.qty}</td><td class="n">${V.naira(x.total)}</td></tr>`);
  const rp = recent(prod.filter(x => !x.voided), x => `<tr><td>${x.date}</td><td>${esc(pName(x.productId))}</td><td class="n">${x.qty}</td><td>${esc(x.person || '')}</td></tr>`);
  el.innerHTML = `<h2>Home</h2>
  <div class="filter"><div><label for="dd">Show figures for</label><input type="date" id="dd" value="${date}"></div><div><button class="btn" id="dt">Today</button></div></div>
  ${bk}${warns}
  <div class="cards">
   <div class="card"><div class="k">Bags produced</div><div class="v">${produced}</div></div>
   <div class="card"><div class="k">Bags sold</div><div class="v">${sold}</div></div>
   <div class="card ${totalStock <= s.lowStock ? 'warn' : ''}"><div class="k">Current stock (bags)</div><div class="v">${totalStock}</div></div>
   <div class="card good"><div class="k">Sales value</div><div class="v">${V.naira(salesValue)}</div></div>
   <div class="card"><div class="k">Expenses recorded</div><div class="v">${V.naira(expToday)}</div></div>
   ${s.creditOn ? `<div class="card ${owed > 0 ? 'warn' : ''}"><div class="k">Customers owe (all time)</div><div class="v">${V.naira(owed)}</div></div>` : ''}
  </div>
  <div class="panel"><strong>Summary for ${date}:</strong> ${day.length} sale(s) worth ${V.naira(salesValue)}; ${produced} bag(s) produced; ${sold} bag(s) sold; expenses ${V.naira(expToday)}. ${customers.length ? '' : ''}</div>
  <h3>Recent sales</h3><div class="tablewrap"><table><tr><th>Date</th><th>Receipt</th><th>Customer</th><th class="n">Bags</th><th class="n">Total</th></tr>${rs || `<tr><td colspan="5">${nothing}</td></tr>`}</table></div>
  <h3>Recent production</h3><div class="tablewrap"><table><tr><th>Date</th><th>Product</th><th class="n">Bags</th><th>Recorded by</th></tr>${rp || `<tr><td colspan="4">${nothing}</td></tr>`}</table></div>`;
  MBI.$('#dd').onchange = e => { MBI._dashDate = e.target.value || V.today(); MBI.render(); };
  MBI.$('#dt').onclick = () => { MBI._dashDate = ''; MBI.render(); };
};
