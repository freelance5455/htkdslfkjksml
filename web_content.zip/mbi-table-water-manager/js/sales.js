MBI.pages.sales = async function (el) {
  const { esc, $ } = MBI; const s = MBI.settings;
  const [products, customers, sales] = await Promise.all(['products', 'customers', 'sales'].map(DB.all));
  const act = products.filter(p => p.active); const stock = await DB.stockMap();
  const from = MBI._sFrom || V.today(), to = MBI._sTo || V.today();
  let clientKey = V.uid(), paidEdited = false;
  el.innerHTML = `<h2>Record a sale</h2><form class="panel" id="sf" novalidate>
   <div class="row"><div><label for="date">Sale date</label><input type="date" id="date" value="${V.today()}"></div>
   <div><label for="prod">Product</label><select id="prod">${MBI.opts(act, '', p => `${p.name} (${stock[p.id] || 0} in stock)`)}</select></div>
   <div><label for="cust">Customer</label><select id="cust"><option value="">Walk-in customer</option>${MBI.opts(customers, '', c => c.name)}</select></div>
   <div><label for="qty">Number of bags</label><input id="qty" type="number" inputmode="numeric" min="1" step="1"></div>
   <div><label for="price">Price per bag (₦)</label><input id="price" type="number" inputmode="decimal" min="0" step="any"></div>
   <div><label for="disc">Authorised discount (₦)</label><input id="disc" type="number" inputmode="decimal" min="0" step="any" value="0"></div>
   ${s.creditOn ? `<div><label for="paid">Amount paid (₦)</label><input id="paid" type="number" inputmode="decimal" min="0" step="any"></div>
   <div><label>Balance owed</label><div class="total" id="bal">₦0</div></div>` : ''}
   <div><label for="person">Recorded by</label><input id="person" value="${esc(s.userName)}"></div></div>
   <label for="notes">Notes</label><textarea id="notes" rows="2"></textarea>
   <p>Subtotal: <strong id="sub">₦0</strong><br>Total: <span class="total" id="tot">₦0</span></p>
   <div id="err"></div><button class="btn good big" id="save" type="submit">Save sale</button></form>
  <h3>Sales history</h3>
  <div class="filter"><div><label for="f1">From</label><input type="date" id="f1" value="${from}"></div><div><label for="f2">To</label><input type="date" id="f2" value="${to}"></div></div>
  <div id="hist"></div>`;
  const num = id => { const v = $('#' + id); return v && v.value !== '' ? Number(v.value) : 0; };
  const calc = () => {
    const c = V.calcSale(num('qty'), num('price'), num('disc'));
    $('#sub').textContent = V.naira(c.subtotal); $('#tot').textContent = V.naira(c.total);
    if (s.creditOn) { if (!paidEdited) $('#paid').value = c.total || ''; $('#bal').textContent = V.naira(V.money(c.total - num('paid'))); }
  };
  const fillPrice = () => { const p = products.find(x => x.id === $('#prod').value); $('#price').value = p && p.price ? p.price : ''; calc(); };
  ['qty', 'price', 'disc', 'paid'].forEach(i => { const e = $('#' + i); if (e) e.oninput = () => { if (i === 'paid') paidEdited = true; calc(); }; });
  $('#prod').onchange = fillPrice; fillPrice();

  $('#sf').onsubmit = async ev => {
    ev.preventDefault(); const btn = $('#save'); if (btn.disabled) return;
    const c = customers.find(x => x.id === $('#cust').value);
    const rec = { clientKey, date: $('#date').value, productId: $('#prod').value, customerId: c ? c.id : '', customerName: c ? c.name : '', qty: num('qty'), unitPrice: num('price'), discount: num('disc'),
      amountPaid: s.creditOn ? num('paid') : V.calcSale(num('qty'), num('price'), num('disc')).total, person: $('#person').value.trim(), notes: $('#notes').value.trim() };
    const errs = V.validateSale(rec, s.creditOn); MBI.errBox($('#err'), errs); if (errs.length) return;
    btn.disabled = true;
    try {
      const r = await DB.saveSale(rec);
      if (rec.person && rec.person !== s.userName) await DB.setSetting('userName', rec.person);
      MBI.toast(r.duplicate ? 'This sale was already saved.' : 'Sale saved: ' + r.sale.receiptNo, 'ok'); MBI.changed();
    } catch (e) { MBI.errBox($('#err'), [e.message]); btn.disabled = false; }
  };

  const draw = () => {
    const rows = sales.filter(x => x.date >= from && x.date <= to).sort((a, b) => b.date.localeCompare(a.date) || b.createdAt.localeCompare(a.createdAt));
    const tot = rows.filter(x => !x.voided).reduce((a, x) => a + x.total, 0);
    $('#hist').innerHTML = rows.length ? `<div class="tablewrap"><table><tr><th>Date</th><th>Receipt</th><th>Customer</th><th class="n">Bags</th><th class="n">Price</th><th class="n">Total</th><th class="n">Balance</th><th></th></tr>` +
      rows.map(x => `<tr class="${x.voided ? 'void' : ''}"><td>${x.date}</td><td>${esc(x.receiptNo)}</td><td>${esc(x.customerName || 'Walk-in')}</td><td class="n">${x.qty}</td><td class="n">${V.naira(x.unitPrice)}</td><td class="n">${V.naira(x.total)}</td><td class="n">${V.naira(x.balance)}</td><td>${x.voided ? 'Cancelled' : `<button class="btn sm danger" data-v="${x.id}">Cancel sale</button>`}</td></tr>`).join('') +
      `</table></div><p>Total for these dates (excluding cancelled): <strong>${V.naira(tot)}</strong></p>` : '<div class="empty">No sales in these dates.</div>';
    el.querySelectorAll('[data-v]').forEach(b => b.onclick = async () => {
      const r = await MBI.ask('Cancel this sale?', [{ name: 'reason', label: 'Reason', required: true }], 'Cancel sale', 'The bags go back into stock. The record stays in history as cancelled.');
      if (!r || !(await MBI.authorise())) return;
      try { await DB.voidSale(b.dataset.v, r.reason, s.userName); MBI.toast('Sale cancelled', 'ok'); MBI.changed(); } catch (e) { MBI.toast(e.message, 'err'); }
    });
  };
  $('#f1').onchange = e => { MBI._sFrom = e.target.value; MBI.render(); }; $('#f2').onchange = e => { MBI._sTo = e.target.value; MBI.render(); };
  draw();
};
