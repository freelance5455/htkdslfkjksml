/* IndexedDB layer + business services. Every multi-record change runs in ONE transaction. */
(function (root) {
  const STORES = ['products', 'customers', 'sales', 'production', 'expenses', 'movements', 'settings', 'meta'];
  const DB = { name: 'mbi-table-water', version: 1, db: null, STORES };
  const req = r => new Promise((res, rej) => { r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
  DB.req = req;

  DB.open = function () {
    if (DB.db) return Promise.resolve(DB.db);
    return new Promise((res, rej) => {
      const o = indexedDB.open(DB.name, DB.version);
      o.onupgradeneeded = () => {
        const d = o.result;
        STORES.forEach(s => d.createObjectStore(s, { keyPath: (s === 'settings' || s === 'meta') ? 'key' : 'id' }));
        const t = o.transaction;
        t.objectStore('sales').createIndex('date', 'date');
        t.objectStore('sales').createIndex('clientKey', 'clientKey', { unique: true });
        t.objectStore('production').createIndex('date', 'date');
        t.objectStore('production').createIndex('clientKey', 'clientKey', { unique: true });
        t.objectStore('expenses').createIndex('date', 'date');
        t.objectStore('movements').createIndex('productId', 'productId');
        t.objectStore('movements').createIndex('date', 'date');
      };
      o.onsuccess = () => { DB.db = o.result; res(DB.db); };
      o.onerror = () => rej(o.error);
    });
  };

  /* Run fn inside one transaction. Resolves only after commit; any throw aborts everything. */
  DB.run = function (stores, mode, fn) {
    return DB.open().then(db => new Promise((res, rej) => {
      const tx = db.transaction(stores, mode);
      let out, failed = null;
      tx.oncomplete = () => res(out);
      tx.onabort = () => rej(failed || tx.error || new Error('Transaction aborted'));
      tx.onerror = () => { failed = failed || tx.error; };
      Promise.resolve().then(() => fn(tx)).then(r => { out = r; }).catch(e => { failed = e; try { tx.abort(); } catch (_) { } });
    }));
  };
  DB.all = s => DB.run([s], 'readonly', tx => req(tx.objectStore(s).getAll()));
  DB.get = (s, k) => DB.run([s], 'readonly', tx => req(tx.objectStore(s).get(k)));
  DB.put = (s, o) => DB.run([s], 'readwrite', tx => req(tx.objectStore(s).put(o)));

  /* settings */
  const DEFAULTS = { creditOn: true, lowStock: 50, userName: '', pinHash: '', pinSalt: '', secQ: '', secAHash: '', failCount: 0, lockUntil: 0, lastBackup: '' };
  /* Per-device security keys: never exported, never overwritten by a restore */
  const SEC = ['pinHash', 'pinSalt', 'secQ', 'secAHash', 'failCount', 'lockUntil'];
  DB.settings = async () => {
    const rows = await DB.all('settings'); const s = { ...DEFAULTS };
    rows.forEach(r => s[r.key] = r.value); return s;
  };
  DB.setSetting = (key, value) => DB.put('settings', { key, value });

  DB.ensureSeed = async () => {
    await DB.run(['products'], 'readwrite', async tx => {
      const st = tx.objectStore('products');
      if (!(await req(st.count()))) st.put({ id: V.uid(), name: 'Table water (bag)', price: 0, active: true, createdAt: new Date().toISOString() });
    });
  };

  /* stock = sum of the ledger, never an overwritten number */
  const stockIn = async (tx, productId) => {
    const rows = await req(tx.objectStore('movements').index('productId').getAll(productId));
    return rows.reduce((a, m) => a + m.qty, 0);
  };
  DB.stockMap = async () => {
    const m = {}; (await DB.all('movements')).forEach(x => m[x.productId] = (m[x.productId] || 0) + x.qty); return m;
  };
  const nextNo = async (tx, key, prefix) => {
    const st = tx.objectStore('meta'); const r = (await req(st.get(key))) || { key, n: 0 };
    r.n++; await req(st.put(r)); return prefix + String(r.n).padStart(5, '0');
  };
  const mv = (o) => ({ id: V.uid(), createdAt: new Date().toISOString(), notes: '', person: '', refType: '', refId: '', ...o });

  /* SALE: validate (caller) -> dup check -> stock check -> sale + movement, one commit */
  DB.saveSale = (s) => DB.run(['sales', 'movements', 'meta'], 'readwrite', async tx => {
    const dup = await req(tx.objectStore('sales').index('clientKey').get(s.clientKey));
    if (dup) return { duplicate: true, sale: dup };
    const avail = await stockIn(tx, s.productId);
    if (s.qty > avail) throw new Error('Not enough stock. Only ' + avail + ' bag(s) available.');
    const c = V.calcSale(s.qty, s.unitPrice, s.discount);
    const sale = { ...s, id: V.uid(), receiptNo: await nextNo(tx, 'sale', 'S-'), subtotal: c.subtotal, total: c.total,
      balance: V.money(c.total - (s.amountPaid || 0)), payments: [], voided: false, createdAt: new Date().toISOString() };
    await req(tx.objectStore('sales').add(sale));
    await req(tx.objectStore('movements').add(mv({ date: s.date, productId: s.productId, qty: -s.qty, type: 'sale', refType: 'sale', refId: sale.id, person: s.person, notes: sale.receiptNo })));
    return { duplicate: false, sale };
  });

  DB.voidSale = (id, reason, person) => DB.run(['sales', 'movements'], 'readwrite', async tx => {
    const st = tx.objectStore('sales'); const s = await req(st.get(id));
    if (!s || s.voided) throw new Error('Sale not found or already cancelled.');
    s.voided = true; s.voidReason = reason; s.voidedAt = new Date().toISOString(); await req(st.put(s));
    await req(tx.objectStore('movements').add(mv({ date: V.today(), productId: s.productId, qty: s.qty, type: 'reversal', refType: 'sale', refId: id, person, notes: 'Cancelled ' + s.receiptNo + ': ' + reason })));
  });

  DB.addPayment = (id, amount, date) => DB.run(['sales'], 'readwrite', async tx => {
    const st = tx.objectStore('sales'); const s = await req(st.get(id));
    amount = V.money(amount);
    if (!s || s.voided) throw new Error('Sale not found.');
    if (!(amount > 0) || amount > s.balance) throw new Error('Payment must be above zero and not more than the balance (' + V.naira(s.balance) + ').');
    s.payments.push({ date, amount }); s.amountPaid = V.money((s.amountPaid || 0) + amount); s.balance = V.money(s.total - s.amountPaid);
    await req(st.put(s));
  });

  DB.saveProduction = (p) => DB.run(['production', 'movements'], 'readwrite', async tx => {
    const dup = await req(tx.objectStore('production').index('clientKey').get(p.clientKey));
    if (dup) return { duplicate: true };
    const rec = { ...p, id: V.uid(), voided: false, createdAt: new Date().toISOString() };
    await req(tx.objectStore('production').add(rec));
    await req(tx.objectStore('movements').add(mv({ date: p.date, productId: p.productId, qty: p.qty, type: 'production', refType: 'production', refId: rec.id, person: p.person, notes: p.shift || '' })));
    return { duplicate: false };
  });

  DB.voidProduction = (id, reason, person) => DB.run(['production', 'movements'], 'readwrite', async tx => {
    const st = tx.objectStore('production'); const p = await req(st.get(id));
    if (!p || p.voided) throw new Error('Record not found or already reversed.');
    const avail = await stockIn(tx, p.productId);
    if (p.qty > avail) throw new Error('Cannot reverse: ' + p.qty + ' bags were produced but only ' + avail + ' are in stock now.');
    p.voided = true; p.voidReason = reason; await req(st.put(p));
    await req(tx.objectStore('movements').add(mv({ date: V.today(), productId: p.productId, qty: -p.qty, type: 'reversal', refType: 'production', refId: id, person, notes: 'Reversed production: ' + reason })));
  });

  /* Other movements: received(+), damaged(-), issued(-), opening(+), adjustment(+/-) */
  DB.saveMovement = (m) => DB.run(['movements'], 'readwrite', async tx => {
    const sign = { received: 1, opening: 1, damaged: -1, issued: -1, adjustment: Math.sign(m.qty) }[m.type];
    const qty = m.type === 'adjustment' ? m.qty : sign * m.qty;
    if (!qty) throw new Error('Quantity cannot be zero.');
    if (qty < 0 && -qty > await stockIn(tx, m.productId)) throw new Error('Not enough stock for this movement.');
    await req(tx.objectStore('movements').add(mv({ date: m.date, productId: m.productId, qty, type: m.type, person: m.person, notes: m.notes, refType: m.type })));
  });

  DB.saveExpense = (e) => DB.put('expenses', { ...e, id: e.id || V.uid(), voided: false, createdAt: new Date().toISOString() });

  /* Backup / restore */
  DB.exportAll = async () => {
    const data = {}; for (const s of STORES) data[s] = await DB.all(s);
    data.settings = data.settings.filter(r => !SEC.includes(r.key));
    const counts = {}; STORES.forEach(s => counts[s] = data[s].length);
    return { app: 'MBI-TABLE-WATER-MANAGER', backupVersion: 1, exportedAt: new Date().toISOString(), counts, data };
  };
  DB.validateBackup = (b) => {
    if (!b || b.app !== 'MBI-TABLE-WATER-MANAGER') return 'This is not an MBI Table Water Manager backup file.';
    if (b.backupVersion !== 1) return 'Unsupported backup version: ' + b.backupVersion;
    if (!b.data || typeof b.data !== 'object') return 'Backup has no data section.';
    for (const s of STORES) {
      const a = b.data[s]; if (!Array.isArray(a)) return 'Backup is missing "' + s + '".';
      if (b.counts && b.counts[s] !== a.length) return 'Record count mismatch in "' + s + '". File may be damaged.';
      const k = (s === 'settings' || s === 'meta') ? 'key' : 'id';
      if (a.some(r => !r || typeof r !== 'object' || r[k] == null)) return 'Invalid record found in "' + s + '".';
    }
    return '';
  };
  DB.restore = (b, mode) => DB.run(STORES, 'readwrite', async tx => {
    const keep = (await req(tx.objectStore('settings').getAll())).filter(r => SEC.includes(r.key));
    for (const s of STORES) {
      const st = tx.objectStore(s);
      if (mode === 'replace') await req(st.clear());
      for (const r of b.data[s]) if (!(s === 'settings' && SEC.includes(r.key))) await req(st.put(r));
    }
    for (const r of keep) await req(tx.objectStore('settings').put(r)); // this device's PIN stays
  });

  root.DB = DB;
})(window);
