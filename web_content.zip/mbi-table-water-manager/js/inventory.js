MBI.pages.stock = async function (el) {
  const { esc, $ } = MBI; const s = MBI.settings;
  const [products, mvs] = await Promise.all(['products', 'movements'].map(DB.all));
  const stock = await DB.stockMap(), name = id => (products.find(p => p.id === id) || {}).name || '?';
  const act = products.filter(p => p.active);
  const types = { opening: 'Opening stock', production: 'Production', received: 'Stock received', sale: 'Sale', damaged: 'Damaged', issued: 'Other stock issued', adjustment: 'Adjustment', reversal: 'Reversal' };
  const ft = MBI._mType || '';
  const rows = mvs.filter(m => !ft || m.type === ft).sort((a, b) => b.date.localeCompare(a.date) || b.createdAt.localeCompare(a.createdAt)).slice(0, 200);
  el.innerHTML = `<h2>Stock</h2>
  <div class="cards">${act.map(p => `<div class="card ${(stock[p.id] || 0) <= s.lowStock ? 'warn' : 'good'}"><div class="k">${esc(p.name)}</div><div class="v">${stock[p.id] || 0}</div></div>`).join('')}</div>
  <h3>Record a stock movement</h3><form class="panel" id="mf" novalidate><div class="row">
   <div><label for="type">What happened?</label><select id="type"><option value="damaged">Damaged bags</option><option value="received">Stock received from elsewhere</option><option value="issued">Other stock issued (free, samples, etc.)</option><option value="opening">Opening stock (starting balance)</option></select></div>
   <div><label for="prod">Product</label><select id="prod">${MBI.opts(act)}</select></div>
   <div><label for="date">Date</label><input type="date" id="date" value="${V.today()}"></div>
   <div><label for="qty">Bags</label><input id="qty" type="number" inputmode="numeric" min="1" step="1"></div>
   <div><label for="person">Recorded by</label><input id="person" value="${esc(s.userName)}"></div></div>
   <label for="notes">Notes</label><input id="notes"><div id="err"></div><button class="btn good big" id="save" type="submit">Save movement</button></form>
  <h3>Physical stock count</h3><form class="panel" id="rf" novalidate><div class="row">
   <div><label for="rprod">Product</label><select id="rprod">${MBI.opts(act)}</select></div>
   <div><label for="rcount">Bags counted on the shelves</label><input id="rcount" type="number" inputmode="numeric" min="0" step="1"></div></div>
   <p id="rdiff">System stock: <strong id="rsys">0</strong> | Difference: <strong id="rd">-</strong></p>
   <div id="rerr"></div><button class="btn primary big" type="submit">Correct stock to counted figure</button></form>
  <h3>Stock ledger (latest 200)</h3>
  <div class="filter"><div><label for="ft">Show</label><select id="ft"><option value="">All movements</option>${Object.entries(types).map(([k, v]) => `<option value="${k}" ${k === ft ? 'selected' : ''}>${v}</option>`).join('')}</select></div></div>
  ${rows.length ? `<div class="tablewrap"><table><tr><th>Date</th><th>Product</th><th>Type</th><th class="n">Bags</th><th>By</th><th>Notes</th></tr>` +
    rows.map(m => `<tr><td>${m.date}</td><td>${esc(name(m.productId))}</td><td>${types[m.type] || m.type}</td><td class="n" style="color:${m.qty < 0 ? 'var(--red)' : 'var(--green)'}">${m.qty > 0 ? '+' : ''}${m.qty}</td><td>${esc(m.person || '')}</td><td>${esc(m.notes || '')}</td></tr>`).join('') + '</table></div>' : '<div class="empty">No stock movements yet. Record production or an opening stock balance to start.</div>'}`;
  $('#ft').onchange = e => { MBI._mType = e.target.value; MBI.render(); };
  $('#mf').onsubmit = async ev => {
    ev.preventDefault(); const b = $('#save'); if (b.disabled) return;
    const r = { type: $('#type').value, productId: $('#prod').value, date: $('#date').value, qty: Number($('#qty').value), person: $('#person').value.trim(), notes: $('#notes').value.trim() };
    const errs = V.validateQtyDate(r); MBI.errBox($('#err'), errs); if (errs.length) return;
    b.disabled = true;
    try { await DB.saveMovement(r); MBI.toast('Movement saved', 'ok'); MBI.changed(); } catch (e) { MBI.errBox($('#err'), [e.message]); b.disabled = false; }
  };
  const upd = () => { const sys = stock[$('#rprod').value] || 0; $('#rsys').textContent = sys; const c = $('#rcount').value; $('#rd').textContent = c === '' ? '-' : (Number(c) - sys > 0 ? '+' : '') + (Number(c) - sys); };
  $('#rprod').onchange = upd; $('#rcount').oninput = upd; upd();
  $('#rf').onsubmit = async ev => {
    ev.preventDefault(); const pid = $('#rprod').value, c = $('#rcount').value;
    if (c === '' || !Number.isInteger(Number(c)) || Number(c) < 0) return MBI.errBox($('#rerr'), ['Enter the counted number of bags (0 or more).']);
    const diff = Number(c) - (stock[pid] || 0); if (!diff) return MBI.errBox($('#rerr'), ['Counted figure matches the system. No correction needed.']);
    const r = await MBI.ask('Correct stock by ' + (diff > 0 ? '+' : '') + diff + ' bags?', [{ name: 'reason', label: 'Reason for the difference', required: true }], 'Apply correction', 'A recorded adjustment will be added to the stock ledger.');
    if (!r || !(await MBI.authorise())) return;
    try { await DB.saveMovement({ type: 'adjustment', productId: pid, date: V.today(), qty: diff, person: s.userName, notes: 'Stock count: ' + r.reason }); MBI.toast('Stock corrected', 'ok'); MBI.changed(); } catch (e) { MBI.errBox($('#rerr'), [e.message]); }
  };
};
