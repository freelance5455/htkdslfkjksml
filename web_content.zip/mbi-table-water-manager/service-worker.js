const CACHE = 'mbi-manager-v2';
const FILES = ['./', 'index.html', 'manifest.json', 'css/style.css', 'css/responsive.css',
  'js/validation.js', 'js/database.js', 'js/app.js', 'js/dashboard.js', 'js/sales.js', 'js/production.js',
  'js/inventory.js', 'js/customers.js', 'js/expenses.js', 'js/reports.js', 'js/backup.js',
  'assets/images/mbi-logo.jpg', 'assets/icons/icon-192.png', 'assets/icons/icon-512.png'];
self.addEventListener('install', e => { e.waitUntil(caches.open(CACHE).then(c => c.addAll(FILES)).then(() => self.skipWaiting())); });
self.addEventListener('activate', e => { e.waitUntil(caches.keys().then(k => Promise.all(k.filter(x => x !== CACHE).map(x => caches.delete(x)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  e.respondWith(caches.match(e.request, { ignoreSearch: true }).then(r => r || fetch(e.request).catch(() => caches.match('index.html'))));
});
