# Upgrade notes: developer branding, About Developer, fingerprint unlock

![Lafene Tech Hub logo](assets/images/lafene-logo.jpg)

Developed by **Lafene Tech Hub**. Developer: **Abdul Kareem Muhammad Lafene**.
Copyright (c) 2026 Lafene Tech Hub. All rights reserved.

## 1. Inspection result (before any change)
The project is an **offline-first web app / PWA** (HTML, CSS, vanilla JS, IndexedDB, service worker, web manifest). It is **not** a native Android app and **no APK exists yet** (the Capacitor wrapper steps in `android/README.md` have not been run). Authentication: mandatory per-device PIN (PBKDF2-SHA-256, 100,000 iterations, random salt) plus a security question for PIN recovery. No version number existed anywhere, so none was invented or shown.
The original project was backed up before editing: `BACKUP-original-before-developer-upgrade.zip`.

## 2. Files added
- `js/about.js`: developer info block, About Developer page (#/about), 14 skill categories A to N.
- `js/biometric.js`: fingerprint/biometric unlock (see section 4).
- `assets/images/lafene-logo.jpg`: your uploaded logo, byte-for-byte unchanged (verified identical).
- `tests/run-upgrade-tests.py`, `docs/screenshots/*.png`, `UPGRADE-NOTES.md`.

## 3. Files modified (small edits only)
- `index.html`: two `<script>` tags added.
- `js/backup.js` (the Backup & Settings page): two panels appended at the bottom ("Fingerprint unlock", "About application" with ABOUT DEVELOPER button). Nothing existing was moved or removed.
- `js/app.js`: a "Use fingerprint" button on the lock screen, shown only when fingerprint unlock is on. The PIN field, Unlock button and Forgot PIN are unchanged.
- `js/database.js`: new per-device setting `bioCred` (default empty) added to the keys that are never exported in backups and never overwritten by a restore. No database structure or version change, so **no data migration was needed and no records are touched**.
- `css/style.css`: a few lines appended (info list, collapsible sections, logo placeholder). Existing rules unchanged.
- `service-worker.js`: cache name bumped to v3 so installed copies pick up the new files; the two new scripts and the logo added to the cache list; same-origin files fetched later are now cached too.

Unchanged: application name, MBI logo, icons, colours, fonts, dashboard, navigation, all business modules, calculations, reports, backup/restore, PIN setup/recovery/lockout, offline behaviour.

## 4. How fingerprint unlock works
- Ordinary JavaScript cannot read a fingerprint sensor, and this app never tries. It asks the phone to verify the user.
- **In a browser / installed PWA (needs https or localhost):** WebAuthn with a platform authenticator and `userVerification: required`. At unlock the app checks the challenge, origin, the "user verified" flag and the signature against the public key saved when the feature was turned on. Only a credential ID and a public key are stored. No fingerprint image or template is ever available to the app.
- **In the Android APK (not built yet):** the code also supports the Capacitor plugin `@aparajita/capacitor-biometric-auth` (Android BiometricPrompt). This path is **written but completely untested**.
- Turning it on or off requires the current PIN, then a successful phone verification. The PIN always keeps working. Failed or cancelled attempts unlock nothing. Phones without support show "not available" and carry on with the PIN.

### Enable it
1. Unlock with your PIN. 2. Backup & Settings > Fingerprint unlock > Turn on fingerprint unlock. 3. Enter your PIN, then touch the fingerprint sensor when the phone asks. 4. Next time, tap **Use fingerprint** on the lock screen (or type your PIN).
Note: some phones also accept their screen-lock method in the same prompt. Each device must enable it separately. It does not carry over in backups.

## 5. Security review (existing PIN system)
No PIN, answer or fingerprint data is logged (the only console call is an error message when a page fails to load). Findings, none of which were changed because they are outside the requested scope:
- PBKDF2 hashing needs a secure page (https, localhost or the APK). Opened over plain http on a network address, the browser lacks Web Crypto and the app falls back to a **weak hash**. Use https or the APK.
- Records in IndexedDB and backup files are **not encrypted**. Anyone who can copy the phone's app data or a backup file can read them.
- A 4-digit PIN is guessable offline if someone extracts the stored hash. The wait-after-5-tries only slows the on-screen login.
- All protection runs on the device, so a skilled person with full access to an unlocked phone can bypass it.
- The security answer can be low-entropy. Choose an answer others cannot guess.
Recommended later: encrypt backups with a password; longer PIN (6+ digits).

## 6. Test results
Automated, desktop Chromium (Playwright), run locally: 36 earlier regression checks (sales, stock, backup/restore, offline, PIN) all pass, and 24 new checks pass (developer info, About page, logo not distorted, name spelling, 14 categories, PIN needed to enable fingerprint, unlock on success, no unlock on failure or forged key, PIN fallback, unsupported device, backup excludes biometric data).
Fingerprint checks used Chromium's **virtual authenticator (software simulation)**, not real fingerprint hardware.
**Not tested (need a real Android phone):** real fingerprint enrollment and unlock, behaviour of WebAuthn inside an Android WebView/APK, the native plugin path, the APK itself, Android backup saving/sharing, automatic lock after 2 minutes away.

## 7. Known limitations
- No APK was built (no Android SDK/network here). See `android/README.md`. After wrapping, **test fingerprint on a real phone before relying on it**. WebAuthn inside Android WebViews is not reliable, so the APK should use the native biometric plugin.
- Logo is a JPG on a white background, so it shows as a white square (fine on the white pages). It has wide white margins, so it looks smaller than the box it sits in. I did **not** crop it; if you approve, I can trim only the blank margin.
- No splash screen or launcher icon was changed. Adding the Lafene logo there would change existing branding, so I need your approval first.
- The About page lists skills and learning fields as supplied; it makes no claims of certification, employment or degrees.
- No website, email, phone or social account was added for Lafene Tech Hub, because none was supplied.
