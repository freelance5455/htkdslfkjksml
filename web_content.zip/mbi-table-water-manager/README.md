# MBI TABLE WATER MANAGER

Offline-first business app for MBI Table Water (sales, production, stock ledger, customers, expenses, daily reports, backup/restore). HTML + CSS + vanilla JS + IndexedDB. No server, no CDN, no network calls.

## Run it (testing in a browser)
Service workers need `http://localhost` or HTTPS. Opening `index.html` by double-click (file://) shows the app but **without offline install**.

    cd mbi-table-water-manager
    python3 -m http.server 8080      # then open http://localhost:8080
    (or: npx serve .)

First-time setup: Backup & Settings > Products and prices > set the bag price. Then Stock > "Opening stock" to enter bags already in store. Production, sales etc. follow.

## Install on a phone (PWA, optional)
Host the folder on any HTTPS site once, open it in Chrome, choose "Add to Home screen". After that it runs offline. For the APK route see `android/README.md`.

## Structure (changes from the brief)
- `css/responsive.css` kept as a separate file as requested.
- Business logic (all IndexedDB transactions: sales, production, reversals, stock movements, restore) lives in `js/database.js`; `js/app.js` holds the router, modals, PIN and file-saving helpers; `js/validation.js` holds pure maths/validation. Each page has its own file.
- Logo is `assets/images/mbi-logo.jpg` (your file, unmodified; JPG, not PNG). App icons are resized copies of it.
- Extra: `tests/run-tests.py` (automated browser tests).

## How the data works
- Stock is never overwritten. It is the sum of the **stock movement ledger**. Closing = Opening + Production + Received - Sold - Damaged - Other issued + Adjustments.
- A sale, its receipt number, and its stock movement are written in ONE IndexedDB transaction, after a stock check. Failure leaves nothing behind.
- Each form has a one-time key (unique index) so a double tap or double submit cannot create a duplicate.
- Records are never silently deleted: sales/expenses are "cancelled", production is "reversed", both with a reason; reversals add opposite ledger entries.
- Each sale stores its own unit price, so later price changes do not alter history.
- `date` = business date you choose; `createdAt` = when it was typed in.
- Overselling is checked against total current stock, even for back-dated sales.

## PIN security (mandatory)
- First open on any device: the app shows **only** a PIN setup screen (name, 4-8 digit PIN, security question and answer). Nothing else can be reached until it is done.
- Every later open (and after 2 minutes away, and when you tap Lock) asks for the PIN. 5 wrong tries cause a wait that grows (30 s, 60 s, ...) and survives closing the app.
- Forgot PIN: answer the security question, then set a new PIN. Change PIN / question: Backup & Settings (needs the current PIN). There is deliberately **no "remove PIN"** option.
- PIN and answer are stored only as salted PBKDF2 hashes (needs https/localhost/APK; on plain http to a LAN address the browser falls back to a weak hash).
- PIN data is never put in backup files and a restore never overwrites the device's own PIN.
- Each device has its own separate database. Three managers = three separate sets of records; they do not sync.
- Limit: this is app-level protection. Someone with full technical access to an unlocked device (or its browser data) could still get around it, and anyone who knows the PIN and the security answer can reset it.

## Limitations (be aware)
- Data lives only on the device. Clearing browser/app data or uninstalling can erase it. Save backups (Backup & Settings) regularly.
- "Authorised user" = whoever knows the PIN (if set). There are no separate user accounts.
- PDF is not built in; use Print > "Save as PDF" in the browser/phone print dialog. CSV and JSON work offline.
- Restoring in "replace" mode overwrites everything; "merge" overwrites records with the same ID.
- Weekly total = Monday to today. Expense totals are recorded expenses only, not profit.
