# Test cases and results

Automated: `python3 tests/run-tests.py` (Chromium via Playwright, local server). Last run result is in the project handover message.

| # | Test | Method | Result (desktop Chromium, 390px viewport) |
|---|------|--------|------|
| 1 | 30 x ₦2,000 = ₦60,000 | automated + real form | PASS |
| 2 | 20 + 100 - 65 - 2 = 53 | automated, via ledger | PASS |
| 3 | Price change keeps old sale at ₦2,000 | automated | PASS |
| 4 | Persistence after reload | automated (page reload) | PASS in browser. NOT tested in an Android package |
| 5 | Offline use | automated (service worker, offline reload, report) | PASS in browser. NOT tested on a phone/APK |
| 6 | Backup / restore | automated (validate, wipe, restore, rollback on failure) | PASS. File download/picker not exercised by automation |
| 7 | Insufficient stock rejected, nothing saved | automated | PASS |
| 8 | Duplicate submission (sale and production) | automated (same key twice) | PASS. Rapid double-tap on button is also blocked by disabling it (not automated) |
| 9 | Damaged bags reduce stock | automated | PASS (report figure checked by formula; visual check manual) |

Manual checks still to do: PIN lock/unlock, printing, CSV file opens in Excel, customer payments, small phone screens, Android APK (see android/README.md).

## PIN / security (automated, PASS in desktop Chromium)
Setup is mandatory and validated; app hidden and unreachable by URL while locked; PIN/answer stored hashed; wrong PIN rejected; Lock button; forgot-PIN with wrong/right answer; old PIN stops working; Change PIN in settings; backups contain no PIN data and cannot overwrite the device PIN; 5 wrong tries cause a wait that survives reload.
Not tested: auto-lock after 2 minutes away; Android WebView behaviour.
