"""Automated browser tests (Playwright + Chromium). Run: python3 tests/run-tests.py"""
import subprocess, sys, time, json, os
from playwright.sync_api import sync_playwright
root = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
srv = subprocess.Popen([sys.executable, '-m', 'http.server', '8765'], cwd=root, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(1)

def setup(pg, pin='4321'):
    pg.wait_for_selector('#sName'); pg.fill('#sName','Musa'); pg.fill('#sPin',pin); pg.fill('#sPin2',pin); pg.fill('#sA','Kaduna'); pg.click('#sGo'); pg.wait_for_selector('#view h2')
def unlock(pg, pin='4321'):
    try: pg.wait_for_selector('#uPin', timeout=2500)
    except Exception: return
    pg.fill('#uPin', pin); pg.click('#uGo'); pg.wait_for_selector('#view h2')
JS = r"""
async () => {
  const out = []; const t = (n, ok, d) => out.push({n, ok: !!ok, d: d || ''});
  if (DB.db) { DB.db.close(); DB.db = null; } DB.name = 'mbi-test-' + Date.now(); await DB.open();
  const pid = V.uid(); await DB.put('products', {id: pid, name: 'Bag', price: 2000, active: true});
  const base = {productId: pid, customerId: '', customerName: '', discount: 0, person: 't', notes: ''};
  // T1
  t('T1 sales calc 30x2000', V.calcSale(30, 2000, 0).total === 60000);
  // T7 insufficient stock (stock is 0)
  let e7 = ''; try { await DB.saveSale({...base, clientKey: 'k0', date: '2026-10-27', qty: 1, unitPrice: 2000, amountPaid: 2000}); } catch (e) { e7 = e.message; }
  t('T7 oversell rejected', /Not enough stock/.test(e7), e7);
  t('T7 no partial records', (await DB.all('sales')).length === 0 && (await DB.all('movements')).length === 0);
  // T2 inventory
  await DB.saveMovement({type: 'opening', productId: pid, date: '2026-10-27', qty: 20, person: 't', notes: ''});
  await DB.saveProduction({clientKey: 'p1', date: '2026-10-27', productId: pid, qty: 100, person: 't'});
  const s1 = await DB.saveSale({...base, clientKey: 'k1', date: '2026-10-27', qty: 65, unitPrice: 2000, amountPaid: 130000});
  await DB.saveMovement({type: 'damaged', productId: pid, date: '2026-10-27', qty: 2, person: 't', notes: ''});
  let st = (await DB.stockMap())[pid];
  t('T2/T9 closing stock 53 (20+100-65-2)', st === 53, 'got ' + st);
  // T8 duplicate
  const d = await DB.saveSale({...base, clientKey: 'k1', date: '2026-10-27', qty: 65, unitPrice: 2000, amountPaid: 130000});
  t('T8 duplicate sale blocked', d.duplicate && (await DB.all('sales')).length === 1 && (await DB.stockMap())[pid] === 53);
  const dp = await DB.saveProduction({clientKey: 'p1', date: '2026-10-27', productId: pid, qty: 100, person: 't'});
  t('T8 duplicate production blocked', dp.duplicate && (await DB.all('production')).length === 1);
  // T3 price change
  await DB.put('products', {id: pid, name: 'Bag', price: 2200, active: true});
  t('T3 old sale keeps 2000', (await DB.all('sales'))[0].unitPrice === 2000 && (await DB.get('products', pid)).price === 2200);
  // T9 damaged > stock rejected
  let e9 = ''; try { await DB.saveMovement({type: 'damaged', productId: pid, date: '2026-10-27', qty: 999, person: 't', notes: ''}); } catch (e) { e9 = e.message; }
  t('T9 damaged beyond stock rejected', /Not enough/.test(e9));
  // void sale restores stock
  await DB.voidSale(s1.sale.id, 'test', 't');
  t('void sale returns 65 bags', (await DB.stockMap())[pid] === 118);
  // T6 backup/restore
  const b = await DB.exportAll(); t('T6 backup validates', DB.validateBackup(b) === '');
  t('T6 invalid file rejected', DB.validateBackup({app: 'x'}) !== '' && DB.validateBackup({...b, backupVersion: 9}) !== '');
  const bad = JSON.parse(JSON.stringify(b)); bad.data.sales.push({noid: 1});
  t('T6 corrupt records rejected', DB.validateBackup(bad) !== '');
  await DB.run(DB.STORES, 'readwrite', async tx => { for (const s of DB.STORES) await DB.req(tx.objectStore(s).clear()); });
  t('T6 wiped', (await DB.all('sales')).length === 0);
  await DB.restore(b, 'replace');
  t('T6 restored', (await DB.all('sales')).length === 1 && (await DB.all('movements')).length === b.data.movements.length && (await DB.stockMap())[pid] === 118);
  // atomic restore failure: bad record type should abort and keep data
  const b2 = JSON.parse(JSON.stringify(b)); b2.data.sales.push({id: 'dupkey', clientKey: b.data.sales[0].clientKey});
  let rf = ''; try { await DB.restore(b2, 'replace'); } catch (e) { rf = 'failed'; }
  t('T6 failed restore rolls back', rf === 'failed' && (await DB.all('sales')).length === 1);
  return out;
}
"""
UI = r"""
async () => { // T4 persistence + UI smoke
  return {hash: location.hash, nav: document.querySelectorAll('#nav a').length, h2: document.querySelector('#view h2')?.textContent};
}
"""
with sync_playwright() as p:
    br = p.chromium.launch()
    ctx = br.new_context(viewport={'width': 390, 'height': 800})
    page = ctx.new_page(); errs = []
    page.on('pageerror', lambda e: errs.append(str(e)))
    reqs = []; page.on('request', lambda r: reqs.append(r.url) if not r.url.startswith('http://localhost:8765') and not r.url.startswith('data:') else None)
    page.goto('http://localhost:8765/index.html'); page.wait_for_selector('#sName')
    res = page.evaluate(JS)
    for r in res: print(('PASS ' if r['ok'] else 'FAIL ') + r['n'] + ' ' + r['d'])
    # UI part runs in a brand-new browser profile (clean real database)
    ctx.close(); ctx = br.new_context(viewport={'width': 390, 'height': 800}); page = ctx.new_page(); page.on('pageerror', lambda e: errs.append(str(e)))
    page.on('request', lambda r: reqs.append(r.url) if not r.url.startswith('http://localhost:8765') and not r.url.startswith('data:') else None)
    page.goto('http://localhost:8765/index.html'); setup(page)
    page.evaluate("async()=>{const ps=await DB.all('products');ps[0].price=2000;await DB.put('products',ps[0]);await DB.saveProduction({clientKey:'ui-p',date:V.today(),productId:ps[0].id,qty:100,person:'x'})}")
    page.goto('http://localhost:8765/index.html#/sales'); page.wait_for_selector('#sf')
    page.reload(); unlock(page); page.wait_for_selector('#sf')
    page.fill('#qty', '30'); page.wait_for_timeout(100)
    print('UI total shown:', page.inner_text('#tot'))
    page.click('#save'); page.wait_for_timeout(600)
    n1 = page.evaluate("DB.all('sales').then(a=>a.length)")
    page.goto('http://localhost:8765/index.html#/dashboard'); page.reload(); unlock(page); page.wait_for_selector('.cards')
    print('T4 persistence after reload: sales =', n1, '| dashboard sales value:', page.inner_text('.cards .card.good .v'))
    for pg in ['sales','production','stock','customers','expenses','reports','backup']:
        page.goto('http://localhost:8765/index.html#/'+pg); page.wait_for_timeout(300)
        bad = page.query_selector('.msg.err')
        print('page', pg, 'OK' if not bad else 'ERROR: '+bad.inner_text())
    # T5 offline (service worker)
    page.goto('http://localhost:8765/index.html'); unlock(page); page.wait_for_timeout(1500)
    sw = page.evaluate("navigator.serviceWorker.getRegistration().then(r=>!!r&&!!r.active)")
    print('service worker active:', sw)
    page.reload(); unlock(page); page.wait_for_timeout(800)
    ctx.set_offline(True); page.reload(); unlock(page)
    print('T5 offline reload works, title:', page.inner_text('#view h2'))
    page.goto('http://localhost:8765/index.html#/reports'); page.wait_for_selector('table')
    print('T5 offline report rendered')
    print('external requests:', reqs, '| JS errors:', errs)

    # ---------- PIN / security tests (fresh profile) ----------
    c2 = br.new_context(viewport={'width': 390, 'height': 780}); q = c2.new_page(); q.goto('http://localhost:8765/index.html'); q.wait_for_selector('#sName')
    def chk(n, ok, d=''): print(('PASS ' if ok else 'FAIL ') + 'PIN: ' + n + ' ' + d)
    chk('first open shows PIN setup, app hidden', q.is_visible('#sName') and q.inner_html('#view') == '')
    q.evaluate("location.hash='#/sales'"); q.wait_for_timeout(300); chk('cannot open pages by changing the address while locked', q.inner_html('#view') == '')
    q.click('#sGo'); chk('setup refuses empty form', 'Type your name' in q.inner_text('#lockErr'))
    q.fill('#sName','Musa'); q.fill('#sPin','12'); q.fill('#sPin2','12'); q.fill('#sA','Kaduna'); q.click('#sGo'); chk('setup refuses short PIN', '4 to 8' in q.inner_text('#lockErr'))
    q.fill('#sPin','4321'); q.fill('#sPin2','1111'); q.click('#sGo'); chk('setup refuses mismatched PIN', 'do not match' in q.inner_text('#lockErr'))
    q.fill('#sPin2','4321'); q.click('#sGo'); q.wait_for_selector('#view h2'); chk('PIN created, app opens', True)
    st = q.evaluate("DB.all('settings').then(a=>JSON.stringify(a))"); chk('PIN and answer stored hashed, not plain', '4321' not in st and 'kaduna' not in st.lower())
    q.reload(); q.wait_for_selector('#uPin'); chk('every reopen asks for PIN', q.inner_html('#view') == '')
    q.fill('#uPin','0000'); q.click('#uGo'); q.wait_for_timeout(400); chk('wrong PIN rejected', 'Wrong PIN' in q.inner_text('#lockErr') and q.inner_html('#view') == '')
    q.fill('#uPin','4321'); q.click('#uGo'); q.wait_for_selector('#view h2'); chk('correct PIN opens app', True)
    q.click('#lockNow'); q.wait_for_selector('#uPin'); chk('Lock button locks', q.inner_html('#view') == '')
    q.click('#uForgot'); q.fill('#fA','wrong'); q.fill('#fPin','7777'); q.fill('#fPin2','7777'); q.click('#fGo'); q.wait_for_timeout(500); chk('forgot: wrong answer rejected', 'not correct' in q.inner_text('#lockErr'))
    q.fill('#fA','  KADUNA '); q.click('#fGo'); q.wait_for_selector('#view h2'); chk('forgot: right answer sets new PIN and opens', True)
    q.reload(); q.wait_for_selector('#uPin'); q.fill('#uPin','4321'); q.click('#uGo'); q.wait_for_timeout(400); chk('old PIN no longer works', q.inner_html('#view') == '')
    q.fill('#uPin','7777'); q.click('#uGo'); q.wait_for_selector('#view h2'); chk('new PIN works', True)
    q.evaluate("location.hash='#/backup'"); q.wait_for_selector('#sp'); q.click('#sp'); q.fill('#d_pin','7777'); q.click('dialog button[value=ok]'); q.wait_for_selector('#d_a')
    q.fill('#d_a','2468'); q.fill('#d_b','2468'); q.fill('#d_ans','kaduna'); q.click('dialog button[value=ok]'); q.wait_for_timeout(700)
    q.reload(); q.wait_for_selector('#uPin'); q.fill('#uPin','2468'); q.click('#uGo'); q.wait_for_selector('#view h2'); chk('Change PIN in Settings works (needs current PIN)', True)
    bk = q.evaluate("DB.exportAll().then(b=>JSON.stringify(b))"); chk('backup file contains no PIN data', 'pinHash' not in bk and 'secAHash' not in bk)
    q.evaluate("DB.exportAll().then(b=>{b.data.settings.push({key:'pinHash',value:'evil'});b.counts.settings++;window._b=b})")
    q.evaluate("DB.restore(window._b,'replace')"); ok = q.evaluate("DB.settings().then(s=>s.pinHash!=='evil'&&s.pinHash.length>10)"); chk('restoring a backup cannot overwrite this device PIN', ok)
    q.click('#lockNow'); q.wait_for_selector('#uPin')
    for i in range(5):
        q.fill('#uPin','0000'); q.click('#uGo'); q.wait_for_timeout(350)
    chk('5 wrong PINs trigger a wait', 'Wait' in q.inner_text('#lockErr'))
    q.fill('#uPin','2468'); q.click('#uGo'); q.wait_for_timeout(300); chk('correct PIN refused during the wait', q.inner_html('#view') == '')
    q.reload(); q.wait_for_selector('#uPin'); q.fill('#uPin','2468'); q.click('#uGo'); q.wait_for_timeout(300); chk('wait survives a reload', q.inner_html('#view') == '')
    c2.close()
    br.close()
srv.terminate()
