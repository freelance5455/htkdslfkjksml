# Android APK guide (Capacitor, bundled local files)

**Status: NOT built or tested here.** These steps need Node.js, Android Studio and internet once, on your computer, to download tools. The finished APK does not need internet.

1. Install Node.js (LTS) and Android Studio (with an SDK and a phone/emulator).
2. In a new folder: `npm init -y` then `npm i @capacitor/core @capacitor/cli @capacitor/android @capacitor/filesystem @capacitor/share`
3. `npx cap init "MBI Table Water Manager" com.mbi.tablewater --web-dir=www`
4. Copy the app into `www/`: `index.html manifest.json service-worker.js css js assets` (everything from the project root except `tests`, `android`).
5. `npx cap add android` then `npx cap sync android`
6. `npx cap open android`. In Android Studio: Build > Build Bundle(s)/APK(s) > Build APK(s). For a release APK, create a keystore (Build > Generate Signed App Bundle/APK). Keep the keystore safe.
7. Copy the `.apk` to the phone, allow "install unknown apps", install.

Notes
- Capacitor serves bundled files from `https://localhost` inside the app, so the interface loads with no website. Capacitor's default manifest only adds the INTERNET permission to its template; you may remove `<uses-permission android:name="android.permission.INTERNET"/>` from `android/app/src/main/AndroidManifest.xml` if the app does not need it (test after removing).
- IndexedDB inside the WebView persists across closing/reopening but is erased by uninstall or "Clear data". Browser data is NOT shared with the APK, so the first run starts empty: restore a backup file to move data across.
- Backups: the app tries Capacitor Filesystem + Share (so you can send the file to WhatsApp/Drive). If those plugins are missing it falls back to a normal download, which may not work in a WebView. **Test backup and restore on a real phone before relying on it.**
- Printing from the WebView may be limited; CSV export is the reliable fallback.

## Android testing checklist
- [ ] APK installs; app opens with the MBI logo, in airplane mode
- [ ] Set price, add opening stock, record production and a sale
- [ ] Close the app fully (swipe away), reopen: records still there
- [ ] Daily report opens; CSV export shares/saves
- [ ] Save backup file; copy it off the phone
- [ ] Uninstall, reinstall, restore the backup: records return
- [ ] Back button behaves sensibly; PIN lock works after restart
- [ ] No network requests (airplane mode all day)

## Fingerprint unlock in the APK (added in the developer/biometric upgrade)
Status: **written, not tested**.
1. In the Capacitor folder: `npm i @aparajita/capacitor-biometric-auth` then `npx cap sync android`.
2. Add `<uses-permission android:name="android.permission.USE_BIOMETRIC"/>` if the plugin docs require it for your plugin version.
3. Build, install, then on a real phone with a fingerprint enrolled: Backup & Settings > Turn on fingerprint unlock. Test success, a wrong finger, cancelling, and the PIN fallback.
Do not rely on the feature until those tests pass on your phone.
