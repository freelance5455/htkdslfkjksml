# عالم المكعبات - تطبيق أندرويد + سيرفر اللعب الجماعي

المشروع يتكون من جزأين:
- **التطبيق (APK):** اللعبة داخل تطبيق أندرويد عبر Capacitor.
- **السيرفر:** لعب جماعي عبر الإنترنت، يُرفع على خدمة استضافة (مثل Render أو Railway).

> مهم: التطبيق لا يشغّل السيرفر بنفسه. السيرفر يعمل على الإنترنت، والتطبيق يتصل به.

---

## أولًا: رفع السيرفر (مرة واحدة)

التطبيق يعمل من `https`، لذلك يجب أن يكون السيرفر بعنوان `wss://` (مشفّر). معظم خدمات الاستضافة توفر ذلك تلقائيًا.

### على Render (مجاني):
1. ارفع مجلد `server/` إلى GitHub (ملفات `server.js`، `package.json`، `Dockerfile`).
2. من render.com: **New → Web Service** واختر المستودع.
3. Runtime: **Docker**. المنفذ يُقرأ تلقائيًا من المتغير `PORT`.
4. بعد النشر ستحصل على عنوان مثل `https://cube-world-xyz.onrender.com`.
5. عنوان اللعب الجماعي يكون: `wss://cube-world-xyz.onrender.com` (بدّل `https` بـ `wss`).

> ملاحظة: الخطة المجانية تنام بعد فترة بدون نشاط، فأول اتصال قد يتأخر حوالي 30 ثانية.

### تجربة السيرفر محليًا (اختياري):
```
cd server
npm install
npm start
```

---

## ثانيًا: بناء التطبيق

### المتطلبات
- Node.js 18 أو أحدث
- Android Studio (أحدث إصدار) مع Android SDK
- JDK 17 (يأتي مع Android Studio غالبًا)

### الخطوات
```
cd cube-world-apk
npm install
SERVER_URL=wss://cube-world-xyz.onrender.com npm run prepare-www
npx cap add android
npm run sync
npm run open
```

على Windows في PowerShell استخدم بدلًا من السطر الخاص بـ `SERVER_URL`:
```
$env:SERVER_URL="wss://cube-world-xyz.onrender.com"; npm run prepare-www
```

### ضبط الشاشة أفقية (مستحسن)
بعد `npx cap add android` افتح الملف:
`android/app/src/main/AndroidManifest.xml`
وأضف داخل عنصر `<activity>` الخاص بـ `MainActivity` السطر:
```
android:screenOrientation="sensorLandscape"
```

### إنشاء ملف APK
داخل Android Studio:
- **Build → Build Bundle(s) / APK(s) → Build APK(s)**
- الملف الناتج: `android/app/build/outputs/apk/debug/app-debug.apk`

للتوزيع على متجر Google Play تحتاج إلى **Build → Generate Signed Bundle / APK** وإنشاء مفتاح توقيع.

### بعد أي تعديل على اللعبة
عدّل الملف `game/cube-world-optimized.html` ثم:
```
npm run sync
```
وأعد بناء الـ APK.

---

## ثالثًا: اللعب الجماعي من التطبيق
1. افتح التطبيق ومن القائمة الرئيسية في قسم "لعب جماعي" تأكد أن عنوان السيرفر هو `wss://...`.
2. اختر اسم الغرفة (نفس الاسم لكل من يريد اللعب معك) واكتب اسمك.
3. اضغط "اتصال بالغرفة".

## ملاحظات
- **الحفظ المحلي** للعوالم يتم داخل التطبيق نفسه، ولا ينتقل بين الأجهزة.
- **وضع البقاء** متاح للعوالم الفردية فقط، واللعب الجماعي إبداعي.
- **تعديلات اللعب الجماعي** تُحفظ في ذاكرة السيرفر فقط، وتُفقد عند إعادة تشغيله.
- **الخط العربي (Cairo)** يُحمَّل من الإنترنت عند فتح التطبيق، أما اللعب نفسه فيعمل بعد التحميل الأول.
- لم يُختبر البناء هنا على جهاز أندرويد حقيقي، لذا جرّب النسخة أولًا على جهاز واحد.
