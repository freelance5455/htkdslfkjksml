// يجهّز مجلد www الذي يقرأه تطبيق الأندرويد:
// 1) ينسخ اللعبة كـ index.html
// 2) يستبدل CDN مكتبة three.js بنسخة محلية (لتعمل بدون إنترنت للمكتبة نفسها)
// 3) يضع عنوان السيرفر الافتراضي داخل القائمة
//
// الاستخدام:  SERVER_URL=wss://your-server.onrender.com npm run prepare-www

const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const src = path.join(root, 'game', 'cube-world-optimized.html');
const www = path.join(root, 'www');
const SERVER_URL = process.env.SERVER_URL || 'wss://your-server.example.com';

fs.mkdirSync(www, { recursive: true });

let html = fs.readFileSync(src, 'utf8');

const CDN = 'https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js';
if (!html.includes(CDN)) console.warn('تحذير: لم يُعثر على رابط three.js في الملف');
html = html.replace(CDN, 'three.min.js');

const DEFAULT_URL = 'value="ws://localhost:8080"';
if (html.includes(DEFAULT_URL)) {
  html = html.replace(DEFAULT_URL, `value="${SERVER_URL}"`);
} else {
  console.warn('تحذير: لم يُعثر على عنوان السيرفر الافتراضي');
}

fs.writeFileSync(path.join(www, 'index.html'), html);

const three = path.join(root, 'node_modules', 'three', 'build', 'three.min.js');
if (fs.existsSync(three)) {
  fs.copyFileSync(three, path.join(www, 'three.min.js'));
  console.log('تمت إضافة three.min.js');
} else {
  console.warn('three.min.js غير موجود: شغّل npm install أولًا');
}

console.log(`www جاهز · السيرفر الافتراضي: ${SERVER_URL}`);
