// سيرفر عالم المكعبات متعدد اللاعبين
// التشغيل:  npm install   ثم   npm start
// الافتراضي: ws://localhost:8080  (يمكن تغيير المنفذ بمتغير PORT)

const { WebSocketServer } = require('ws');

const PORT = Number(process.env.PORT) || 8080;
const MAX_BLOCK = 44;   // أعلى رقم بلوك مسموح
const WORLD_H = 112;    // ارتفاع العالم

const wss = new WebSocketServer({ port: PORT, maxPayload: 1 << 16 });
const rooms = new Map();
let nextId = 1;

function getRoom(name) {
  let r = rooms.get(name);
  if (!r) {
    r = {
      seed: Math.floor(Math.random() * 1e9),   // بذرة العالم: كل اللاعبين يولّدون نفس الأرض
      edits: new Map(),                         // تعديلات اللاعبين على البلوكات
      clients: new Set()
    };
    rooms.set(name, r);
    console.log(`[room] created "${name}" seed=${r.seed}`);
  }
  return r;
}

function send(ws, obj) {
  if (ws.readyState === 1) ws.send(JSON.stringify(obj));
}

function broadcast(room, obj, except) {
  for (const c of room.clients) if (c !== except) send(c, obj);
}

const clampSkin = s => Math.max(0, Math.min(5, s | 0));

wss.on('connection', ws => {
  ws.id = nextId++;
  ws.room = null;
  ws.name = 'لاعب';
  ws.skin = 0;
  ws.p = null;

  ws.on('message', raw => {
    let m;
    try { m = JSON.parse(raw); } catch (e) { return; }
    if (!m || typeof m.t !== 'string') return;

    if (m.t === 'join' && !ws.room) {
      const room = getRoom(String(m.room || 'main').slice(0, 32));
      ws.room = room;
      ws.name = String(m.name || 'لاعب').slice(0, 16);
      ws.skin = clampSkin(Number(m.skin) || 0);

      const players = [...room.clients]
        .filter(c => c.p)
        .map(c => ({ id: c.id, name: c.name, skin: c.skin, p: c.p }));

      const edits = [];
      for (const [k, b] of room.edits) {
        const [x, y, z] = k.split(',').map(Number);
        edits.push([x, y, z, b]);
      }

      room.clients.add(ws);
      send(ws, { t: 'welcome', id: ws.id, seed: room.seed, edits, players });
      broadcast(room, { t: 'join', id: ws.id, name: ws.name, skin: ws.skin }, ws);
    }

    else if (m.t === 'pos' && ws.room && Array.isArray(m.p) && m.p.length === 5) {
      ws.p = m.p.map(Number);
      if (Number.isInteger(m.s)) ws.skin = clampSkin(m.s);
      broadcast(ws.room, { t: 'pos', id: ws.id, p: ws.p, s: ws.skin }, ws);
    }

    else if (m.t === 'set' && ws.room) {
      const x = Math.trunc(Number(m.x)), y = Math.trunc(Number(m.y));
      const z = Math.trunc(Number(m.z)), b = Math.trunc(Number(m.b));
      if (!Number.isFinite(x) || !Number.isFinite(z)) return;
      if (y < 1 || y >= WORLD_H || b < 0 || b > MAX_BLOCK) return;
      ws.room.edits.set(`${x},${y},${z}`, b);
      broadcast(ws.room, { t: 'set', x, y, z, b }, ws);
    }
  });

  ws.on('close', () => {
    if (ws.room) {
      ws.room.clients.delete(ws);
      broadcast(ws.room, { t: 'leave', id: ws.id });
    }
  });
});

console.log(`Cube World server listening on ws://localhost:${PORT}`);
