blure UI + CSS preview
Upload all files to htdocs. In IDE create main.blu and style.css. See docs.html for syntax. UI preview supports static elements and CSS; click-to-blure-functions is not implemented yet.
