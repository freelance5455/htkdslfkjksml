STARSMVRT CONCEPT — CEMENT DISTRIBUTION MANAGER
================================================

CONTENTS
- index.html: the complete mobile-friendly app prototype.
- README.txt: setup and operating notes.

HOW TO USE
1. Extract the ZIP file.
2. Open index.html in Chrome, Edge, Firefox or another modern browser.
3. On Android, open the HTML file in Chrome. Use Chrome's menu > Add to Home screen
   (if offered) to create a home-screen shortcut.
4. Start in Inventory and use Add stock to enter opening stock for each branch/product.
5. Open Price Management and enter the current selling and cost prices.
6. Use Record a Sale to record transactions. Sales deduct inventory automatically.
7. Use Stock Transfers to move stock between branches.
8. Record operating costs in Expenses.
9. Download a JSON backup regularly from Data & Settings.

IMPORTANT LIMITATIONS
- This is a working offline/local prototype, not a hosted multi-user system.
- Data is stored in the browser on the device where it is used. It does not sync
  automatically across the five branches or multiple staff phones.
- Back up regularly. Browser data deletion may remove saved records.
- For production use, add secure staff logins, cloud database synchronization,
  permissions, audit logs, receipt printing, and tested backup/restore procedures.
- No bank, payment gateway or live bank feed is connected.
- All initial stock and prices are zero. Enter your actual figures before use.

BRANCHES
Abeokuta, Ibadan, Lagos, Ifo, Sagamu

PRODUCTS
Dangote Cement, BUA Cement, HBM Cement

ABEOKUTA PRICING
The sale screen allows Truck and Walk-in customer types at Abeokuta. Other branches
use the Walk-in price list. Configure the relevant rates in Price Management.
