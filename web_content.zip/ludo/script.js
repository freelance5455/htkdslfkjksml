// ---- Board data ----
const PATH=[[6,1],[6,2],[6,3],[6,4],[6,5],[5,6],[4,6],[3,6],[2,6],[1,6],[0,6],[0,7],[0,8],[1,8],[2,8],[3,8],[4,8],[5,8],[6,9],[6,10],[6,11],[6,12],[6,13],[6,14],[7,14],[8,14],[8,13],[8,12],[8,11],[8,10],[8,9],[9,8],[10,8],[11,8],[12,8],[13,8],[14,8],[14,7],[14,6],[13,6],[12,6],[11,6],[10,6],[9,6],[8,5],[8,4],[8,3],[8,2],[8,1],[8,0],[7,0],[6,0]];
const COLORS=['red','green','yellow','blue'], START=[0,13,26,39];
const HOME=[[[7,1],[7,2],[7,3],[7,4],[7,5]],[[1,7],[2,7],[3,7],[4,7],[5,7]],[[7,13],[7,12],[7,11],[7,10],[7,9]],[[13,7],[12,7],[11,7],[10,7],[9,7]]];
const YARD=[[0,0],[0,9],[9,9],[9,0]], SAFE=[0,8,13,21,26,34,39,47];
const FACES='⚀⚁⚂⚃⚄⚅';

let active,tokens,turn,dice,movable,busy,useCpu;
const $=id=>document.getElementById(id);
const boardEl=$('board');

function drawBoard(){
  boardEl.innerHTML='';
  for(let r=0;r<15;r++)for(let c=0;c<15;c++){
    const d=document.createElement('div');d.className='cell';d.style.gridArea=`${r+1}/${c+1}`;
    boardEl.appendChild(d);
  }
  const cell=(r,c)=>boardEl.children[r*15+c];
  YARD.forEach(([r,c],p)=>{
    for(let i=0;i<6;i++)for(let j=0;j<6;j++){const e=cell(r+i,c+j);e.className='cell yard '+COLORS[p];}
    const inner=document.createElement('div');inner.className='yardIn';
    inner.style.gridArea=`${r+2}/${c+2}/${r+6}/${c+6}`;boardEl.appendChild(inner);
  });
  for(let r=6;r<9;r++)for(let c=6;c<9;c++)cell(r,c).className='cell center';
  PATH.forEach(([r,c],i)=>{
    const e=cell(r,c);e.className='cell';
    const s=START.indexOf(i);
    if(s>=0)e.classList.add(COLORS[s]);
    else if(SAFE.includes(i))e.textContent='★';
  });
  HOME.forEach((cells,p)=>cells.forEach(([r,c])=>cell(r,c).className='cell '+COLORS[p]));
}

// ---- Game logic ----
const absCell=(p,pos)=>(START[p]+pos)%52;
function xy(p,i,pos){
  if(pos<0){const [r,c]=YARD[p];return [r+2+(i>>1)*2,c+2+(i&1)*2];}
  if(pos<=50){const [r,c]=PATH[absCell(p,pos)];return [r+.5,c+.5];}
  if(pos<56){const [r,c]=HOME[p][pos-51];return [r+.5,c+.5];}
  return [[7.5,6.9],[6.9,7.5],[7.5,8.1],[8.1,7.5]][p];
}
function render(){
  const seen={};
  tokens.forEach((arr,p)=>arr.forEach((pos,i)=>{
    let el=document.getElementById(`t${p}${i}`);
    if(!el){el=document.createElement('button');el.id=`t${p}${i}`;el.className='token '+COLORS[p];
      el.setAttribute('aria-label',`${COLORS[p]} token ${i+1}`);
      el.onclick=()=>moveToken(i);boardEl.appendChild(el);}
    let [y,x]=xy(p,i,pos);
    const k=y+','+x;seen[k]=(seen[k]||0)+1;
    if(pos>=0&&pos<56&&seen[k]>1){x+=(seen[k]-1)*.18;y-=(seen[k]-1)*.12;}
    el.style.left=(x/15*100)+'%';el.style.top=(y/15*100)+'%';
    el.classList.toggle('can',p===turn&&movable.includes(i));
  }));
}
function setStatus(t){$('status').textContent=t;$('status').style.color=`var(--${COLORS[turn]})`;}
function name(){return COLORS[turn][0].toUpperCase()+COLORS[turn].slice(1);}
const isCpu=()=>useCpu&&turn!==0;

function newGame(){
  const n=+$('numPlayers').value;useCpu=$('cpu').checked;
  active=n===2?[0,2]:n===3?[0,1,2]:[0,1,2,3];
  tokens=[0,1,2,3].map(()=>[-1,-1,-1,-1]);
  boardEl.querySelectorAll('.token').forEach(e=>e.remove());
  turn=0;dice=0;movable=[];busy=false;drawBoard();render();startTurn();
}
function startTurn(){
  dice=0;movable=[];render();$('dice').disabled=isCpu();$('dice').textContent=FACES[0];
  setStatus(`${name()} ki baari: dice roll karo`);
  if(isCpu())setTimeout(roll,700);
}
function roll(){
  if(busy||dice)return;
  dice=1+Math.floor(Math.random()*6);$('dice').textContent=FACES[dice-1];$('dice').disabled=true;
  movable=[0,1,2,3].filter(i=>{const p=tokens[turn][i];return p<0?dice===6:p+dice<=56;});
  render();
  if(!movable.length){setStatus(`${name()}: ${dice} aaya, koi chaal nahi`);busy=true;
    setTimeout(()=>{busy=false;nextPlayer();},900);return;}
  setStatus(`${name()}: ${dice} aaya, token chuno`);
  if(isCpu())setTimeout(()=>moveToken(cpuPick()),700);
  else if(movable.length===1)setTimeout(()=>moveToken(movable[0]),400);
}
function cpuPick(){
  const score=i=>{const p=tokens[turn][i],np=p<0?0:p+dice;let s=np;
    if(np===56)s+=100;if(p<0)s+=50;
    if(np<=50&&!SAFE.includes(absCell(turn,np)))
      for(const o of active)if(o!==turn)tokens[o].forEach(q=>{if(q>=0&&q<=50&&absCell(o,q)===absCell(turn,np))s+=80;});
    return s;};
  return movable.reduce((a,b)=>score(b)>score(a)?b:a);
}
function moveToken(i){
  if(busy||!movable.includes(i))return;
  const p=tokens[turn][i];let bonus=dice===6;
  tokens[turn][i]=p<0?0:p+dice;
  const np=tokens[turn][i];
  if(np<=50&&!SAFE.includes(absCell(turn,np))){
    for(const o of active)if(o!==turn)tokens[o].forEach((q,j)=>{
      if(q>=0&&q<=50&&absCell(o,q)===absCell(turn,np)){tokens[o][j]=-1;bonus=true;}});
  }
  if(np===56)bonus=true;
  movable=[];render();
  if(tokens[turn].every(x=>x===56)){setStatus(`🎉 ${name()} jeet gaya!`);$('dice').disabled=true;busy=true;return;}
  busy=true;
  setTimeout(()=>{busy=false;bonus?startTurn():nextPlayer();},500);
}
function nextPlayer(){turn=active[(active.indexOf(turn)+1)%active.length];startTurn();}

$('dice').onclick=roll;$('newGame').onclick=newGame;
newGame();
