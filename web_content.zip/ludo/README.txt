Ludo Game
Chalane ke liye: index.html ko browser me double-click karke kholo.
Rules: 6 aane par token bahar nikalta hai, 6 ya kaatne par dobara chance.
Star (★) wale aur rang wale start squares safe hain.
