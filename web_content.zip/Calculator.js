let Ansower = document.querySelector("#Ansower");
let tagNum1 = document.querySelector("#Num1");
let tagNum2 = document.querySelector("#Num2");
let tagAmaliat = document.querySelector("#amaliat");
let expression = "";
let resetOnNext = false;

document.addEventListener("keydown", function (event) {
  if (event.key === "1") add("1");
  else if (event.key === "2") add("2");
  else if (event.key === "3") add("3");
  else if (event.key === "4") add("4");
  else if (event.key === "5") add("5");
  else if (event.key === "6") add("6");
  else if (event.key === "7") add("7");
  else if (event.key === "8") add("8");
  else if (event.key === "9") add("9");
  else if (event.key === "0") zero();
  else if (event.key === ".") dat();
  else if (event.key === "+") amaliata("+");
  else if (event.key === "-") amaliata("-");
  else if (event.key === "*") amaliata("*");
  else if (event.key === "/") amaliata("÷");
  else if (event.key === "(" || event.key === ")") paren();
  else if (event.key === "Enter") equal();
  else if (event.key === "Backspace") deleteNum();
  else if (event.key === "Escape") c();
});

/* ===== تابع پاک کردن کل ===== */
function clearAll() {
  expression = "";
  resetOnNext = false;
  Ansower.innerHTML = "";
  tagNum1.innerHTML = "";
  tagNum2.innerHTML = "";
  tagAmaliat.innerHTML = "";
}

/* ===== کاماگذاری ===== */
function formatNumber(num) {
  let str = String(num);

  if (str.includes(".")) {
    let parts = str.split(".");
    let intPart = parts[0];
    let decPart = parts[1];

    let result = "";
    let count = 0;
    for (let i = intPart.length - 1; i >= 0; i--) {
      result = intPart[i] + result;
      count++;
      if (count === 3 && i !== 0 && intPart[i - 1] !== "-") {
        result = "," + result;
        count = 0;
      }
    }
    return result + "." + decPart;
  }

  let result = "";
  let count = 0;
  for (let i = str.length - 1; i >= 0; i--) {
    result = str[i] + result;
    count++;
    if (count === 3 && i !== 0 && str[i - 1] !== "-") {
      result = "," + result;
      count = 0;
    }
  }
  return result;
}

function formatExpression(exp) {
  let result = "";
  let current = "";

  for (let i = 0; i < exp.length; i++) {
    let ch = exp[i];
    if (ch == "+" || ch == "-" || ch == "÷" || ch == "*" || ch == "(" || ch == ")") {
      if (current !== "") {
        result += formatNumber(current);
        current = "";
      }
      result += ch;
    } else {
      current += ch;
    }
  }

  if (current !== "") {
    result += formatNumber(current);
  }

  return result;
}

/* ===== توابع اصلی ===== */
function add(value) {
  if (resetOnNext) {
    clearAll();
  }
  expression += value;
  Ansower.innerHTML = formatExpression(expression);
}

function zero() {
  if (resetOnNext) {
    clearAll();
  }

  if (expression === "") {
    alert("در اول نمی توان صفر گذاشت");
    return;
  }
  let last = expression[expression.length - 1];
  if (last == "+" || last == "-" || last == "÷" || last == "*" || last == "(") {
    alert("در اول نمی توان صفر گذاشت");
  } else {
    expression += "0";
    Ansower.innerHTML = formatExpression(expression);
  }
}

function amaliata(value) {
  // اگه بعد از مساوی عملگر زد → ادامه بده ولی بالا رو خالی نکن
  resetOnNext = false;

  if (expression === "") {
    alert("عددی وارد نشده است");
    return;
  }
  let last = expression[expression.length - 1];
  if (last == "+" || last == "-" || last == "÷" || last == "*") {
    alert("عملیات یکبار وارد می شود");
    return;
  }
  if (last == "(") {
    alert("بعد از پرانتز باید عدد وارد کنی");
    return;
  }
  expression += value;
  Ansower.innerHTML = formatExpression(expression);
}

function paren() {
  if (resetOnNext) {
    clearAll();
  }

  let open = 0;
  let close = 0;
  for (let i = 0; i < expression.length; i++) {
    if (expression[i] == "(") open++;
    if (expression[i] == ")") close++;
  }

  let last = expression[expression.length - 1];

  if (open > close && last != "+" && last != "-" && last != "÷" && last != "*" && last != "(") {
    expression += ")";
  } else {
    if (expression !== "" && (last >= "0" && last <= "9" || last == ")" || last == ".")) {
      expression += "*";
    }
    expression += "(";
  }

  Ansower.innerHTML = formatExpression(expression);
}

function dat() {
  if (resetOnNext) {
    clearAll();
  }

  let lastNumber = "";
  for (let i = expression.length - 1; i >= 0; i--) {
    let ch = expression[i];
    if (ch == "+" || ch == "-" || ch == "÷" || ch == "*" || ch == "(" || ch == ")") {
      break;
    }
    lastNumber = ch + lastNumber;
  }

  if (lastNumber.includes(".")) {
    alert("'.' یکبار گذاشته می شود");
    return;
  }

  if (lastNumber === "") {
    expression += "0.";
  } else {
    expression += ".";
  }
  Ansower.innerHTML = formatExpression(expression);
}

function deleteNum() {
  if (resetOnNext) {
    clearAll();
    return;
  }

  if (expression === "") return;
  expression = expression.slice(0, -1);
  Ansower.innerHTML = formatExpression(expression);
}

function equal() {
  if (expression === "") {
    alert("عددی وارد نشده است");
    return;
  }

  let lastCh = expression[expression.length - 1];
  if (lastCh == "+" || lastCh == "-" || lastCh == "÷" || lastCh == "*" || lastCh == "(") {
    alert("عبارت کامل نیست");
    return;
  }

  let exp = "";
  for (let i = 0; i < expression.length; i++) {
    if (expression[i] == "÷") {
      exp += "/";
    } else {
      exp += expression[i];
    }
  }

  while (exp.includes("(")) {
    let lastOpen = -1;
    for (let i = 0; i < exp.length; i++) {
      if (exp[i] == "(") lastOpen = i;
    }

    let firstClose = -1;
    for (let i = lastOpen; i < exp.length; i++) {
      if (exp[i] == ")") {
        firstClose = i;
        break;
      }
    }

    if (firstClose == -1) {
      alert("پرانتز بسته نشده");
      return;
    }

    let inside = exp.slice(lastOpen + 1, firstClose);
    let result = calculate(inside);
    exp = exp.slice(0, lastOpen) + result + exp.slice(firstClose + 1);
  }

  let result = calculate(exp);

  Ansower.innerHTML = formatNumber(result);

  tagNum1.innerHTML = formatExpression(expression);

  save(expression + "=" + result);

  expression = String(result);

  resetOnNext = true;
}

function calculate(exp) {
  let numbers = [];
  let operators = [];
  let current = "";

  for (let i = 0; i < exp.length; i++) {
    let ch = exp[i];
    if (ch == "+" || ch == "-" || ch == "*" || ch == "/") {
      numbers.push(parseFloat(current));
      operators.push(ch);
      current = "";
    } else {
      current += ch;
    }
  }
  numbers.push(parseFloat(current));

  for (let i = 0; i < operators.length; i++) {
    if (operators[i] == "*" || operators[i] == "/") {
      let result;
      if (operators[i] == "*") {
        result = numbers[i] * numbers[i + 1];
      } else {
        result = numbers[i] / numbers[i + 1];
      }
      numbers[i] = result;
      numbers.splice(i + 1, 1);
      operators.splice(i, 1);
      i--;
    }
  }

  let result = numbers[0];
  for (let i = 0; i < operators.length; i++) {
    if (operators[i] == "+") {
      result += numbers[i + 1];
    } else if (operators[i] == "-") {
      result -= numbers[i + 1];
    }
  }

  return result;
}

function save(text) {
  let n = Number(localStorage.getItem("numbers")) || 0;
  n++;
  localStorage.setItem("Number" + n, text);
  localStorage.setItem("numbers", n);
}

function c() {
  clearAll();
}

/* ===== اعمال تنظیمات ===== */
document.querySelector("body").style.backgroundColor =
  localStorage.getItem("bgColor") || "#ccd5ae";

let btnColor = localStorage.getItem("btnColor") || "#d4a373";
let textColor = localStorage.getItem("textColor") || "#fff";

document
  .querySelectorAll(
    ".button, .button-enter, .button-zero, .button-dat, .buuton-history",
  )
  .forEach(function (el) {
    el.style.backgroundColor = btnColor;
    el.style.borderColor = btnColor;
    el.style.color = textColor;
  });

let boxColor = localStorage.getItem("boxColor") || "#e9edc9";
document.querySelectorAll(".main").forEach(function (el) {
  el.style.backgroundColor = boxColor;
  el.style.borderColor = boxColor;
});

let fontsize = localStorage.getItem("fontsize") || "18";
document.querySelector(".Ansower").style.fontSize = fontsize + "px";
let ansowerColor = localStorage.getItem("ansowerColor") || "#fefae0";
document.querySelector(".Ansower").style.backgroundColor = ansowerColor;
document.querySelector(".ja").style.backgroundColor = ansowerColor;