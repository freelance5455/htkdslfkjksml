# Relatório técnico v1.53.8

## Causa
A criação de carreira chamava `brazilWorldResetAll()`, que serializava os calendários completos das Séries A, B e C — 1.140 partidas — dentro de uma única chave `cc_brazil_world_leagues_v123`. Em aparelhos Android/WebView, essa única gravação podia ultrapassar a quota do `localStorage` e interromper a criação da carreira.

## Correção
- Armazenamento separado por divisão (`cc_brazil_world_leagues_v124_A`, `_B`, `_C`).
- Formato compacto de cada jogo: `[mandante, visitante, golsMandante, golsVisitante, disputado]`.
- Migração da chave antiga para o formato compacto.
- Calendários e placares são reidratados para o formato interno usado pela interface.
- O estado principal da carreira e o sistema Sub-20 não são removidos nem reescritos pela migração de ligas independentes.

## Limites da verificação
Os testes automatizados verificam o formato compacto, persistência, migração e a capacidade de salvar cada divisão sob um limite simulado de tamanho por chave. Ainda é necessário validar a criação no navegador/WebView real do aparelho.
