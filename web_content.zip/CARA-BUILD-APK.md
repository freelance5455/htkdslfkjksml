# Panduan Kompilasi APK Android Full Offline (Catatan SLO & NIDI Vault)

Proyek ini berisi aplikasi **Catatan SLO & NIDI Vault** dengan enkripsi database lokal **AES-256-GCM (PBKDF2-SHA256)** yang berjalan 100% offline tanpa memerlukan koneksi internet.

## Informasi Konfigurasi Proyek
- **Nama Aplikasi**: Catatan SLO & NIDI Vault
- **Package ID**: `id.slonidi.vault`
- **Versi**: 2.4.0 (Code: 24)
- **Enkripsi Lokal**: Web Crypto API `AES-256-GCM` + `PBKDF2` (100.000 iterasi) di atas `IndexedDB`
- **File Mandiri**: `app/src/main/assets/index.html`

---

## Cara 1: Buka / Bungkus Langsung File `assets/index.html` di HP Android
File `app/src/main/assets/index.html` adalah file tunggal mandiri (Single-File Offline App):
1. Anda dapat membuka file `index.html` langsung di Chrome Android atau mengonversinya secara instan menggunakan aplikasi **Website 2 APK Builder** / **HTML2APK** / **HopWeb** di HP Android.
2. Pilih mode **Local HTML File**, arahkan ke `app/src/main/assets/index.html`, aktifkan **DOM Storage / IndexedDB**, lalu klik **Generate APK**.

## Cara 2: Build APK Menggunakan Android Studio (Offline di PC/Laptop)
1. Buka **Android Studio** -> **Open** -> Pilih folder hasil ekstrak ZIP ini.
2. Tunggu Gradle Sync selesai.
3. Klik menu **Build** -> **Build Bundle(s) / APK(s)** -> **Build APK(s)**.
4. File `.apk` siap dipasang di `app/build/outputs/apk/debug/app-debug.apk`.

## Cara 3: Build APK Otomatis Tanpa Install Android Studio (GitHub Actions)
1. Buat repository baru di GitHub dan unggah seluruh isi folder ZIP ini.
2. Buka tab **Actions** di GitHub repository Anda.
3. Workflow **Build Offline Encrypted Android APK** akan otomatis mengompilasi file `.apk` dan Anda tinggal mengunduhnya pada bagian **Artifacts**.
