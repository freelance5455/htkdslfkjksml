# Fideo — التشغيل من الموبايل

## ما تم تجهيزه
- Android app باسم Fideo.
- عمودي Video Feed مع autoplay.
- حسابات وتسجيل دخول/تسجيل جديد عبر Supabase Auth.
- رفع الفيديوهات إلى Supabase Storage.
- نشر الفيديوهات في قاعدة البيانات.
- Likes / Comments / Follow.
- Search / Profile.
- Reports.
- Live sessions data model.
- Admin dashboard موجود كجزء منفصل من المشروع.
- RLS policies في Supabase.
- Notifications + device-token data model.
- عدادات likes/comments/view/share في قاعدة البيانات.

## الجزء الوحيد الذي لا يمكن وضعه داخل APK
الخدمات الخارجية تحتاج حساباتك أنت:
1. Supabase project + URL + publishable/anon key.
2. مزود LIVE مثل LiveKit أو Agora مع token endpoint على backend/Edge Function.
3. Firebase Cloud Messaging إذا أردت Push Notifications حقيقية.
4. استضافة HTTPS للوحة الأدمن.

**ممنوع** وضع service-role key أو LiveKit secret داخل التطبيق.

## تشغيل Supabase
- افتح SQL Editor.
- الصق الملف `supabase/schema.sql` بالكامل.
- فعّل Email/Password من Authentication.
- ضع URL وANON/PUBLISHABLE KEY في:
  `app/src/main/assets/config.js`

## LIVE
قاعدة البيانات جاهزة لتسجيل جلسات LIVE، لكن الفيديو المباشر الحقيقي يحتاج WebRTC provider.
يتم إصدار token من backend/Edge Function، وليس من APK.

## البناء
المشروع Android Gradle Plugin 8.13.2، compileSdk 35، minSdk 23.
