const IMG={
 "hero": {
  "naruto": "assets/naruto.webp",
  "panda": "assets/panda.webp",
  "shadow": "assets/shadow.webp"
 },
 "en": {
  "zombie": "assets/zombie.webp",
  "spiky": "assets/spiky.webp",
  "masked": "assets/masked.webp",
  "ghoul": "assets/ghoul.webp",
  "armor": "assets/armor.webp",
  "hooded": "assets/hooded.webp"
 },
 "bg": [
  "assets/bg1.webp",
  "assets/bg2.webp",
  "assets/bg3.webp",
  "assets/bg4.webp",
  "assets/bg5.webp",
  "assets/bg6.webp",
  "assets/bg7.webp",
  "assets/bg8.webp",
  "assets/bg9.webp",
  "assets/bg10.webp"
 ]
};