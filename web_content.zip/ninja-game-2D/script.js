const $=s=>document.querySelector(s),cv=$('#c'),g=cv.getContext('2d'),W=800,H=400,GY=335,L=16000;
const HR=[{k:'naruto',n:'Orange Ninja',a:'Chakra Blast: bada energy gola 🔵',c:35,h:128,rig:{n:.27,s:.28,h:.47,l:.27,r:.8,x:.48}},
{k:'panda',n:'Panda Monk',a:'Chi Shield: health + shield 🛡️',c:50,h:108,rig:{n:.42,s:.42,h:.72,l:.3,r:.68,x:.55}},
{k:'shadow',n:'Shadow Warrior',a:'Shadow Dash: dash + damage 💨',c:40,h:128,rig:{n:.25,s:.27,h:.62,l:.3,r:.72,x:.5}}];
const AR=[{n:'Fists',e:'',d:0,p:0},{n:'Katana',e:'🗡️',d:6,p:150},{n:'War Axe',e:'🪓',d:12,p:350},{n:'Hammer',e:'🔨',d:18,p:600},{n:'Trident',e:'🔱',d:28,p:1200}],
SK=[{n:'Classic',f:'none',p:0},{n:'Fire',f:'hue-rotate(160deg) saturate(1.5)',p:250},{n:'Ice',f:'hue-rotate(-120deg) saturate(1.3)',p:250},{n:'Golden',f:'sepia(1) saturate(3) brightness(1.1)',p:700},{n:'Night',f:'brightness(.55) contrast(1.35)',p:500}],
ES=['😎','😂','😡','👋','🔥','❤️'];let SV={co:0,sk:0,eq:0,os:[0],ow:[0]},PK=0;
try{Object.assign(SV,JSON.parse(localStorage.getItem('nj_sv')||'{}'))}catch(e){}
const sv=()=>{try{localStorage.setItem('nj_sv',JSON.stringify(SV))}catch(e){}};
const GR={n:.24,s:.26,h:.55,l:.3,r:.7,x:.5};
const EN={zombie:{s:'zombie',h:108,hm:1,dm:1,sp:1.1,nat:1,rig:{n:.25,s:.22,h:.52,l:.38,r:.68,x:.5}},
ghoul:{s:'ghoul',h:102,hm:.6,dm:.8,sp:1.9,nat:-1},masked:{s:'masked',h:120,hm:1.1,dm:1.1,sp:1,nat:-1},
hooded:{s:'hooded',h:124,hm:1.3,dm:1.3,sp:1.3,nat:0},armor:{s:'armor',h:132,hm:1.9,dm:1.4,sp:.8,nat:-1},
spiky:{s:'spiky',h:215,nat:1},abig:{s:'armor',h:235,nat:-1}};
const LN=['Dark Lake','Haunted Woods','Graveyard','Moon Planks','Blood Forest','Phantom Lake','Mist Woods','Ghost Graveyard','Haunted Moon','Crimson Hell'];
const WB={'🗡️':12,'🪓':16,'🔨':22},WL=Object.keys(WB);
const SP={},BG=[];let ch=0,lv=1,UN=1,P,E,I,B,PR=[],FX=[],PT=[],RG=[],T=null,cam=0,t=0,cp=0,run=false,sh=0,K={},joy=0,jump=0,did=0,acc=0,last=0,tile=null,ac;
try{UN=+localStorage.getItem('nj_un')||1}catch(e){}
function fit(){const s=Math.min(innerWidth/W,innerHeight/H);cv.style.width=W*s+'px';cv.style.height=H*s+'px'}
addEventListener('resize',fit);fit();
const rnd=(a,b)=>a+Math.random()*(b-a),pick=a=>a[Math.floor(Math.random()*a.length)];
function sfx(f,d=.1,ty='square',v=.07,f2){try{ac=ac||new(window.AudioContext||window.webkitAudioContext)();const o=ac.createOscillator(),n=ac.createGain(),c=ac.currentTime;o.type=ty;o.frequency.setValueAtTime(f,c);if(f2)o.frequency.exponentialRampToValueAtTime(f2,c+d);n.gain.setValueAtTime(v,c);n.gain.exponentialRampToValueAtTime(.001,c+d);o.connect(n).connect(ac.destination);o.start();o.stop(c+d)}catch(e){}}
/* load images */
const loads=[];const ld=src=>new Promise(r=>{const i=new Image();i.onload=()=>r(i);i.onerror=()=>r(i);i.src=src});
for(const k in IMG.hero)loads.push(ld(IMG.hero[k]).then(i=>SP[k]=i));
for(const k in IMG.en)loads.push(ld(IMG.en[k]).then(i=>SP[k]=i));
IMG.bg.forEach((s,n)=>loads.push(ld(s).then(i=>BG[n]=i)));
/* menu */
function menu(){$('#menu').style.display='flex';$('#msg').style.display='none';$('#ctl').style.display='none';run=false;
 $('#chs').innerHTML=HR.map((c,i)=>`<div class="card ${i==ch?'sel':''}" data-i="${i}"><img src="${IMG.hero[c.k]}"><h3>${c.n}</h3><small>${c.a}</small></div>`).join('');
 $('#lvs').innerHTML=[...Array(10)].map((_,i)=>`<button ${i+1>UN?'disabled':''} data-l="${i+1}">${i+1>UN?'🔒':'Level '+(i+1)}</button>`).join('')}
$('#chs').onclick=e=>{const c=e.target.closest('.card');if(c){ch=+c.dataset.i;menu()}};
$('#lvs').onclick=e=>{const b=e.target.closest('button');if(b&&!b.disabled)start(+b.dataset.l)};
/* level */
function mk(tp,x,boss){const T=EN[tp],hp=boss?220+lv*45:(28+lv*6)*T.hm,w=!boss&&Math.random()<.3+lv*.06?pick(WL):null;
 return{x,tp,T,sz:T.h,hp,mh:hp,sp:boss?1.1+lv*.05:T.sp*(.9+lv*.04)*rnd(.9,1.1),w,cd:50,dmg:boss?12+lv*1.5:(5+lv)*T.dm+(w?3:0),st:0,v:0,f:-1,d:0,dt:0,an:0,ph:rnd(0,6),boss}}
function build(){E=[];I=[];const pool=['zombie','zombie','ghoul'];
 if(lv>=2)pool.push('masked');if(lv>=3)pool.push('hooded');if(lv>=4)pool.push('armor','masked');if(lv>=6)pool.push('armor','hooded');
 for(let i=0;i<22+lv*3;i++)E.push(mk(pick(pool),rnd(700,L-1500)));
 B=mk(lv%2?'spiky':'abig',L-450,1);E.push(B);
 for(let i=0;i<70;i++)I.push({k:'coin',e:'🪙',x:rnd(500,L-600)});for(let i=0;i<3;i++)I.push({k:'kit',e:'🧰',x:rnd(1500,L-2500)});
 for(let i=0;i<5;i++)I.push({k:'wp',e:pick(WL),x:rnd(900,L-1500)});
 I.push({k:'fairy',e:'🧚',x:L/2});
 const b=BG[lv-1]||BG[0],c=document.createElement('canvas');c.width=b.width*2;c.height=H;const x=c.getContext('2d');
 x.drawImage(b,0,0,b.width,H);x.save();x.translate(b.width*2,0);x.scale(-1,1);x.drawImage(b,0,0,b.width,H);x.restore();tile=c}
function start(l){lv=l;build();P={x:80,y:GY,vy:0,hp:100,en:50,f:1,pc:0,an:0,al:10,inv:0,dash:0,wp:null,wu:0,ph:0,mv:0,cb:0,ct:0,sc:0};
 t=0;cp=0;cam=0;PR=[];FX=[];PT=[];RG=[];sh=0;$('#menu').style.display='none';$('#msg').style.display='none';$('#ctl').style.display='block';
 run=true;last=performance.now();acc=0;toast('Level '+lv+': '+LN[lv-1]);sfx(200,.4,'sawtooth',.06,500);requestAnimationFrame(loop)}
function toast(s){T={s,l:120}}
function fx(s,x,y){FX.push({s,x,y,l:50})}
function spark(x,y,c='#ffd23f',n=8){for(let i=0;i<n;i++)PT.push({x,y,vx:rnd(-4,4),vy:rnd(-5,1),l:rnd(15,30),c})}
function hit(e,d,kb){d*=1+Math.min(P.cb,12)*.04;e.hp-=d;e.v=kb;e.st=Math.max(e.st,10);fx('-'+Math.round(d),e.x,GY-e.sz-8);
 P.cb=P.ct>0?P.cb+1:1;P.ct=90;P.sc+=10;spark(e.x,GY-e.sz*.55);sfx(120,.1,'sawtooth',.09,60);
 if(e.hp<=0&&!e.d){e.d=1;e.dt=0;P.en=Math.min(100,P.en+10);P.sc+=e.boss?1000:100;SV.co+=e.boss?200:8;sv();fx(e.boss?'👹 BOSS DOWN!':'💀',e.x,GY-60);sfx(300,.4,'triangle',.1,40)}}
function punch(){if(!run||P.pc>0)return;P.pc=16;P.an=P.al=10;sfx(260,.08,'square',.05,420);P.pk=(P.k3=(P.k3||0)+1)%3==0?1:0;const b=(P.wp?WB[P.wp]:0)+AR[SV.eq].d,r=P.wp?75:62;let h=0;
 for(const e of E)if(!e.d&&(e.x-P.x)*P.f>-10&&(e.x-P.x)*P.f<r+(e.boss?35:0)&&P.y>GY-40){hit(e,10+b,6*P.f);h=1}
 if(h){P.en=Math.min(100,P.en+5);if(P.wp&&--P.wu<=0){P.wp=null;toast('Weapon toot gaya!')}}}
function superP(){if(!run||P.pc>0)return;P.pk=2;if(P.en<30)return toast('Energy kam hai! ⚡');P.en-=30;P.pc=30;P.an=P.al=14;sh=12;sfx(70,.5,'sawtooth',.12,30);
 RG.push({x:P.x,r:10,l:20,c:'#ffd23f'});
 for(const e of E)if(!e.d&&Math.abs(e.x-P.x)<130)hit(e,38,(e.x>P.x?1:-1)*14);fx('💥 SUPER!',P.x,GY-100)}
function abil(){if(!run)return;const c=HR[ch];if(P.en<c.c)return toast('Energy kam hai! ⚡');P.en-=c.c;sfx(500,.3,'sine',.1,900);
 if(ch==0){PR.push({x:P.x+P.f*40,y:GY-60,vx:P.f*10,l:80});P.an=P.al=12}
 if(ch==1){P.hp=Math.min(100,P.hp+35);P.inv=240;toast('🛡️ Chi Shield!')}
 if(ch==2){P.dash=14;P.inv=30;did++}}
function step(){t+=1/60;
 const mx=Math.abs(joy)>.15?joy:(K.r?1:0)-(K.l?1:0),ax=Math.abs(mx);P.mv=0;
 if(P.dash>0){P.x+=P.f*13;P.dash--;P.mv=1;for(const e of E)if(!e.d&&Math.abs(e.x-P.x)<50&&e.di!==did){e.di=did;hit(e,42,9*P.f)}}
 else if(ax>.15){P.f=mx>0?1:-1;const s=ax>.75?4.2:2.4;P.x+=P.f*s;P.mv=1;P.ph+=s*.09}
 P.x=Math.max(20,Math.min(L,P.x));
 if(jump&&P.y>=GY){P.vy=-13.5;sfx(300,.15,'sine',.06,600)}jump=0;
 P.vy+=.7;P.y=Math.min(GY,P.y+P.vy);if(P.y>=GY)P.vy=0;if(P.y<GY-4)P.mv=1;
 if(P.pc>0)P.pc--;if(P.an>0)P.an--;if(P.inv>0)P.inv--;P.en=Math.min(100,P.en+.04);if(sh>0)sh--;if(P.ct>0&&--P.ct==0)P.cb=0;
 for(const e of E){if(e.d){e.dt++;continue}
  if(e.an>0)e.an--;
  if(e.st>0){e.st--;e.x+=e.v;e.v*=.8;continue}
  const dx=P.x-e.x,ad=Math.abs(dx);if(ad>800)continue;e.f=dx>0?1:-1;
  const reach=Math.max(46,e.sz*.36);
  if(ad>reach){e.x+=e.f*e.sp;e.ph+=e.sp*.09;e.cd=Math.max(e.cd,30)}
  else{e.cd--;if(e.cd<=0){e.cd=60;e.an=12;if(P.y>GY-35&&P.inv<=0){P.hp-=e.dmg;P.inv=30;P.x+=e.f*18;sh=6;P.cb=0;fx('-'+Math.round(e.dmg),P.x,GY-90);spark(P.x,GY-60,'#e63946');sfx(90,.15,'square',.1,50)}}}}
 for(const p of PR){p.x+=p.vx;p.l--;for(const e of E)if(!e.d&&p.l>0&&Math.abs(e.x-p.x)<40){hit(e,50,Math.sign(p.vx)*8);p.l=0}}
 PR=PR.filter(p=>p.l>0);
 for(const i of I)if(!i.u&&Math.abs(i.x-P.x)<38){i.u=1;sfx(700,.2,'sine',.08,1100);
  if(i.k=='coin'){SV.co+=5;sv()}if(i.k=='kit'){P.hp=Math.min(100,P.hp+40);toast('🧰 Health kit +40')}
  if(i.k=='wp'){P.wp=i.e;P.wu=8;toast(i.e+' Weapon mila! (8 hits)')}
  if(i.k=='fairy'){P.hp=100;P.en=100;toast('🧚 Pari ne sab theek kar diya!')}}
 const k=Math.floor(P.x/(L/10));
 if(k>cp&&k<=10){cp=k;P.hp=Math.min(100,P.hp+10);toast('💾 Save Point '+k+'/10');try{localStorage.setItem('nj_cp'+lv,k)}catch(e){}}
 if(P.hp<=0){P.hp=100;P.en=30;P.x=cp?cp*L/10:80;P.inv=120;t+=10;toast('Save point se dobara! (+10s)')}
 if(B.d&&P.x>L-140)return win();
 cam=Math.max(0,Math.min(L-W+120,P.x-300));
 for(const f of FX)f.l--;FX=FX.filter(f=>f.l>0);
 for(const p of PT){p.x+=p.vx;p.y+=p.vy;p.vy+=.3;p.l--}PT=PT.filter(p=>p.l>0);
 for(const r of RG){r.r+=9;r.l--}RG=RG.filter(r=>r.l>0);
 if(T&&--T.l<=0)T=null}
/* puppet animation: sprite cut into head / torso / two arms / two legs */
function puppet(k,r,x,y,dh,fl,ph,atk,mv,al,rot){const im=SP[k];if(!im||!im.width)return;
 const iw=im.width,ih=im.height,sc=dh/ih,sw=Math.sin(ph),A=mv?.55:.03,AA=mv?.6:.05;
 const ny=r.n*ih,sy=r.s*ih,hy=r.h*ih,lx=r.l*iw,rx=r.r*iw,hx=r.x*iw,bob=mv?Math.abs(sw)*ih*.014:Math.sin(ph*.5)*ih*.006;
 g.save();g.globalAlpha=al;g.translate(x,y);g.scale(fl,1);g.rotate((mv?.05:0)+atk*.14+(rot||0)-(PK==2?atk*6.28*fl:0));g.scale(sc,sc);g.translate(-iw/2,-ih);
 const part=(x0,y0,w0,h0,px,py,a,dy)=>{g.save();g.translate(px,py+(dy||0));g.rotate(a);g.drawImage(im,x0,y0,w0,h0,x0-px,y0-py,w0,h0);g.restore()};
 part(0,ny,lx+2,hy-ny+2,lx,sy,mv?-sw*AA:Math.sin(ph*.5)*AA,-bob);
 part(0,hy-2,hx+2,ih-hy+2,hx-iw*.08,hy,sw*A,0);
 part(hx-2,hy-2,iw-hx+2,ih-hy+2,hx+iw*.08,hy,-sw*A-(PK==1?atk*1.4:0),0);
 part(lx,ny,rx-lx,hy-ny+3,hx,hy,sw*.03,-bob);
 part(rx-2,ny,iw-rx+2,hy-ny+2,rx,sy,(mv?sw*AA:Math.sin(ph*.5)*-AA)-1.5*atk,-bob);
 part(0,0,iw,ny+2,iw/2,ny,Math.sin(ph*2)*.03+atk*.12,-bob*1.3);
 g.restore()}
function em(s,x,y,sz,fl){g.font=sz+'px serif';g.save();g.translate(x,y);g.scale(fl||1,1);g.fillText(s,0,0);g.restore()}
function bar(x,y,w,h,v,c){g.fillStyle='#0008';g.fillRect(x,y,w,h);g.fillStyle=c;g.fillRect(x,y,w*Math.max(0,v),h)}
function shadow(x,w){g.fillStyle='#0006';g.beginPath();g.ellipse(x,GY+6,w,6,0,0,7);g.fill()}
function draw(){g.textAlign='center';g.fillStyle='#000';g.fillRect(0,0,W,H);
 g.save();if(sh>0)g.translate(rnd(-sh,sh)/2,rnd(-sh,sh)/2);
 if(tile){const tw=tile.width,o=(cam*.3)%tw;for(let x=-o;x<W;x+=tw)g.drawImage(tile,x,0)}
 g.fillStyle='#0007';g.fillRect(-10,GY+8,W+20,H);g.fillStyle='#ffffff22';g.fillRect(-10,GY+8,W+20,2);
 for(let k=1;k<=10;k++){const x=k*L/10-cam;if(x>-40&&x<W+40)em(cp>=k?'✅':'🚩',x,GY+5,36)}
 em('🏁',L-60-cam,GY+5,50);
 for(const i of I)if(!i.u){const x=i.x-cam;if(x>-40&&x<W+40)em(i.e,x,GY-(i.k=='fairy'?40+Math.sin(t*4)*8:0),i.k=='fairy'?46:34)}
 for(const e of E){const x=e.x-cam;if(x<-150||x>W+150||(e.d&&e.dt>50))continue;
  PK=0;const T=EN[e.tp],fl=T.nat?e.f*T.nat:e.f,atk=e.an>0?Math.sin(Math.PI*(1-e.an/12)):0;
  if(!e.d)shadow(x,e.sz*.28);
  const jit=e.st>0?rnd(-2,2):0;
  puppet(T.s,T.rig||GR,x+jit+e.f*atk*10,GY+4,e.sz,fl,e.ph,atk,!e.d&&e.st<=0&&e.an<=0&&Math.abs(P.x-e.x)>Math.max(46,e.sz*.36),e.d?1-e.dt/50:(e.st>0?.65:1),e.d?-Math.min(e.dt/10,1)*1.45:0);
  if(e.d)continue;
  if(e.w)em(e.w,x+e.f*e.sz*.36+e.f*atk*14,GY-e.sz*.42,e.sz*.34,e.f);
  if(e.cd<20&&Math.abs(P.x-e.x)<Math.max(46,e.sz*.36))em('❗',x,GY-e.sz-14,22);
  if(e.st>0)em('💫',x,GY-e.sz-14,22);
  bar(x-22,GY-e.sz-8,44,5,e.hp/e.mh,e.boss?'#ff7b00':'#e63946')}
 for(const p of PR){const x=p.x-cam;g.fillStyle='#4cc9f0';g.beginPath();g.arc(x,p.y,16,0,7);g.fill();g.fillStyle='#fff';g.beginPath();g.arc(x,p.y,8,0,7);g.fill()}
 const px=P.x-cam,H0=HR[ch],atk=P.an>0?Math.sin(Math.PI*(1-P.an/P.al)):0;
 shadow(px,34+(GY-P.y)*-.05);
 PK=P.pk||0;g.filter=SK[SV.sk].f;if(P.dash>0)for(let n=3;n>0;n--)puppet(H0.k,H0.rig,px-P.f*n*20,P.y+4,H0.h,P.f,P.ph,0,1,.2,0);
 if(P.inv%6<3||P.inv>40)puppet(H0.k,H0.rig,px+P.f*atk*8,P.y+4,H0.h,P.f,P.ph,atk,P.mv,1,0);
 g.filter='none';PK=0;if(P.wp||AR[SV.eq].e)em(P.wp||AR[SV.eq].e,px+P.f*(30+atk*30),P.y-H0.h*.4-atk*10,34,P.f);
 if(atk>0){g.strokeStyle=`rgba(255,255,255,${atk})`;g.lineWidth=5;g.beginPath();g.arc(px+P.f*20,P.y-H0.h*.5,50,P.f>0?-1.1:Math.PI-.4,P.f>0?.4:Math.PI+1.1);g.stroke()}
 if(P.em&&P.em.l>0){P.em.l--;em(P.em.s,px,P.y-H0.h-20-(90-P.em.l)*.15,36)}if(P.inv>40){g.strokeStyle='#7df9ff';g.lineWidth=4;g.beginPath();g.arc(px,P.y-H0.h*.45,H0.h*.55,0,7);g.stroke()}
 for(const r of RG){g.strokeStyle=`rgba(255,210,63,${r.l/20})`;g.lineWidth=6;g.beginPath();g.arc(r.x-cam,GY-40,r.r,0,7);g.stroke()}
 for(const p of PT){g.fillStyle=p.c;g.fillRect(p.x-cam,p.y,4,4)}
 for(const f of FX){g.fillStyle='#fff';g.font='bold 18px sans-serif';g.fillText(f.s,f.x-cam,f.y-(50-f.l)*.8)}
 g.restore();
 const th=SP[H0.k];if(th&&th.width){const h=40,w=h*th.width/th.height;g.drawImage(th,8,6,w,h);g.save();g.translate(0,0);g.restore();var bx=16+w}else bx=60;
 bar(bx,10,170,14,P.hp/100,'#e63946');bar(bx,28,170,10,P.en/100,'#3a86ff');
 g.fillStyle='#fff';g.font='bold 13px sans-serif';g.textAlign='left';
 const m=Math.floor(t/60),s=Math.floor(t%60);
 g.fillText(`Lv ${lv}  ⏱ ${m}:${String(s).padStart(2,'0')} / 2:00  💾 ${cp}/10${P.wp?'  '+P.wp+'×'+P.wu:''}`,bx,56);
 g.textAlign='right';g.fillText('Score '+P.sc,W-10,20);g.fillText('🪙 '+SV.co,W-10,70);if(P.cb>1){g.fillStyle='#ffd23f';g.font='bold 20px sans-serif';g.fillText('x'+P.cb+' COMBO',W-10,44)}
 g.textAlign='center';g.fillStyle='#fff';g.font='bold 13px sans-serif';
 if(!B.d&&Math.abs(B.x-P.x)<750){bar(W/2-100,12,200,12,B.hp/B.mh,'#ff7b00');g.fillText('👹 BOSS',W/2,40)}
 if(T){g.globalAlpha=Math.min(1,T.l/30);g.font='bold 26px sans-serif';g.fillStyle='#ffd23f';g.fillText(T.s,W/2,120);g.globalAlpha=1}}
function loop(ts){if(!run)return;acc+=Math.min(ts-last,100);last=ts;while(acc>=16.67&&run){step();acc-=16.67}if(run)draw();requestAnimationFrame(loop)}
function win(){run=false;if(lv<10&&UN<lv+1){UN=lv+1;try{localStorage.setItem('nj_un',UN)}catch(e){}}
 $('#ctl').style.display='none';$('#mt').innerHTML=lv<10?`🎉 Level ${lv} complete!<br>Time: ${Math.floor(t/60)}m ${Math.floor(t%60)}s<br>Score: ${P.sc}`:`🏆 Tum Ninja Master ho! Saare 10 levels khatam!<br>Score: ${P.sc}`;
 $('#mb').innerHTML=(lv<10?'<button id="nx">Next Level ➜</button>':'')+'<button id="mn">Menu</button>';
 $('#msg').style.display='flex';if($('#nx'))$('#nx').onclick=()=>start(lv+1);$('#mn').onclick=menu}
/* controls */
const jy=$('#joy'),kn=$('#knob');let jid=null;
function jm(e){const r=jy.getBoundingClientRect(),dx=e.clientX-(r.left+r.width/2),dy=e.clientY-(r.top+r.height/2),R=r.width/2,d=Math.min(Math.hypot(dx,dy),R),a=Math.atan2(dy,dx),x=Math.cos(a)*d,y=Math.sin(a)*d;
 kn.style.transform=`translate(${x}px,${y}px)`;joy=x/R;if(y/R<-.8)jump=1}
jy.onpointerdown=e=>{jid=e.pointerId;jy.setPointerCapture(jid);jm(e)};
jy.onpointermove=e=>{if(e.pointerId===jid)jm(e)};
jy.onpointerup=jy.onpointercancel=()=>{jid=null;joy=0;kn.style.transform=''};
[['bj',()=>jump=1],['bp',punch],['bs',superP],['ba',abil]].forEach(([id,f])=>$('#'+id).onpointerdown=e=>{e.preventDefault();if(run)f()});
addEventListener('keydown',e=>{const k=e.key.toLowerCase();if(k=='arrowleft'||k=='a')K.l=1;if(k=='arrowright'||k=='d')K.r=1;
 if(run){if(k==' '||k=='arrowup'||k=='w'){jump=1;e.preventDefault()}if(k=='j')punch();if(k=='k')superP();if(k=='l')abil()}});
addEventListener('keyup',e=>{const k=e.key.toLowerCase();if(k=='arrowleft'||k=='a')K.l=0;if(k=='arrowright'||k=='d')K.r=0});
Promise.all(loads).then(menu);
/* emotes, store, armory */
function emote(i){if(!run)return;P.em={s:ES[i%ES.length],l:90};sfx(600,.15,'sine',.06,900)}
const be=document.createElement('b');be.textContent='😎';be.onpointerdown=e=>{e.preventDefault();P.ei=((P.ei||0)+1)%ES.length;be.textContent=ES[(P.ei+1)%ES.length];emote(P.ei)};$('#bt').appendChild(be);
addEventListener('keydown',e=>{if(run&&e.key>='1'&&e.key<='6')emote(+e.key-1)});
const sh2=document.createElement('div');sh2.style.cssText='position:fixed;inset:0;display:none;flex-direction:column;align-items:center;background:#000e;color:#fff;overflow:auto;z-index:20;padding:10px;font-family:sans-serif';document.body.appendChild(sh2);
function shop(){sh2.style.display='flex';
 const it=(a,own,sel,kind)=>a.map((x,i)=>`<div class="card ${sel==i?'sel':''}" data-k="${kind}" data-i="${i}"><h3>${kind=='s'?'🎨':x.e||'👊'} ${x.n}</h3><small>${own.includes(i)?(sel==i?'✅ Equipped':'Tap to equip'):'🪙 '+x.p}${kind=='w'&&x.d?' · +'+x.d+' dmg':''}</small></div>`).join('');
 sh2.innerHTML=`<h2>🏪 Store · 🪙 ${SV.co}</h2><p>⚔️ Armory</p><div class="row">${it(AR,SV.ow,SV.eq,'w')}</div><p>🎨 Skins</p><div class="row">${it(SK,SV.os,SV.sk,'s')}</div><p>😎 Emotes: game mein 😎 button ya keys 1-6</p><button id="sx">⬅ Back</button>`;
 $('#sx').onclick=()=>sh2.style.display='none'}
sh2.onclick=e=>{const c=e.target.closest('.card');if(!c)return;const k=c.dataset.k,i=+c.dataset.i,A=k=='w'?AR:SK,o=k=='w'?SV.ow:SV.os;
 if(!o.includes(i)){if(SV.co<A[i].p)return toast('Coins kam hain 🪙');SV.co-=A[i].p;o.push(i);sfx(800,.2,'sine',.08,1200)}
 if(k=='w')SV.eq=i;else SV.sk=i;sv();shop()};
const sb=document.createElement('button');sb.textContent='🏪 Store / Armory / Skins';sb.style.margin='8px';sb.onclick=shop;$('#menu').appendChild(sb);
