"""Phase 6: executable browser tests of full 24-month lifecycle, branching,
  transparent math, cap checks, progress locking, exports, reset and compatibility.
  Uses a fake localStorage fixture, not anyone's real saved data.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json,re,math
ROOT=Path(__file__).resolve().parent
html=(ROOT/'index.html').read_text('utf-8')
for f in ('curriculum-v6.js','curriculum-v7.js','university-v8.js','inquiry-v9.js','kingdom-v10.js','career-v11.js','life-v12.js','curriculum-v13.js','academy-v13.js'):
    assert f'<script src="{f}"></script>' in html
    html=html.replace(f'<script src="{f}"></script>','<script>\n'+(ROOT/f).read_text('utf-8')+'\n</script>')
for f in ('university-v8.css','inquiry-v9.css','kingdom-v10.css','career-v11.css','life-v12.css','academy-v13.css'):
    assert f'<link rel="stylesheet" href="{f}">' in html
    html=html.replace(f'<link rel="stylesheet" href="{f}">','<style>'+ (ROOT/f).read_text('utf-8')+'</style>')
html=re.sub(r'<link rel="preconnect"[^>]*>|<link href="https://fonts.googleapis.com[^>]*>','',html)

def make(browser,initial=None,viewport=None):
    ctx=browser.new_context(viewport=viewport or {'width':390,'height':844},accept_downloads=True)
    page=ctx.new_page();page.set_default_timeout(6500)
    errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    db=initial if initial is not None else {'loonieAcademy_v1':json.dumps({'onboarded':True,'done':{'79':'5/5'},'notes':{'79':'Legacy Note'},'stars':{'79':3},'kingdomV10':{'notes':{'lantern':'Legacy Kingdom note'}},'careerV11':{'projects':{'accounting-1':{'passedAt':1710000000000}},'active':'accounting','custom':{'manual-1':{'title':'My sample'}},'portfolio':{'goal':'My career goal','weeklyMinutes':150}}})}
    page.evaluate('''db=>{window.__db=db;Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>window.__db[k]??null,setItem:(k,v)=>window.__db[k]=String(v),removeItem:k=>delete window.__db[k],clear:()=>Object.keys(window.__db).forEach(k=>delete window.__db[k])}})}''',db)
    page.set_content(html,wait_until='domcontentloaded',timeout=90000)
    page.wait_for_function('window.LOONIE_V12 && window.LOONIE_V11 && window.LOONIE_V10 && window.LOONIE_V9 && window.LOONIE_V8')
    assert not errors,errors
    return ctx,page,errors

def route(page,h,should_have=None):
    page.evaluate('''()=>document.querySelectorAll('.overlay').forEach(e=>e.remove())''')
    page.evaluate('h=>{location.hash="#"+h;route();}',h)
    content=page.locator('#screen').inner_text()
    assert 'Something went wrong' not in content,(h,content[:500])
    if should_have:assert should_have.lower() in content.lower(),(h,should_have,content[:300])
    assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth + 1'),(h,'horizontal overflow',page.evaluate('document.documentElement.scrollWidth'))
    return content

with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    ctx,page,errors=make(browser)
    c=page.evaluate('({ls:LESSONS.length,subjects:SUBJECTS.length,questions:LESSONS.reduce((a,l)=>a+l.quiz.length,0)})')
    assert c=={'ls':807,'subjects':37,'questions':3714},c
    for m in ('LOONIE_V12','LOONIE_V11','LOONIE_V10','LOONIE_V9','LOONIE_V8'):
        assert page.evaluate(m+'.validate().ok'),(m,page.evaluate(m+'.validate()'))
    val=page.evaluate('LOONIE_V12.validate()')
    assert (val['careers'],val['storyEvents'],val['choices'],val['ventures'],val['months'])==(8,12,36,3,24),val
    assert page.evaluate('state.notes[79]')=='Legacy Note'
    assert page.evaluate('state.kingdomV10.notes.lantern')=='Legacy Kingdom note'
    assert page.evaluate('state.careerV11.custom["manual-1"].title')=='My sample'
    print('COMPATIBILITY/CATALOGS PASS',val,flush=True)
    for h,s in [('learn','Loonie Life'),('world','Loonie Life'),('me','My Loonie Life Journal'),('life12','Choose your starting path'),('life12-month','Choose your starting path')]:route(page,h,s)
    route(page,'life12');assert page.locator('input[name="ll-track"]').count()==8
    page.locator('input[name="ll-track"][value="accounting"]').check();page.locator('#ll-begin').click()
    assert page.evaluate('LOONIE_V12.get().started')
    assert not page.evaluate('LOONIE_V12.openBusiness("shop").ok')
    assert not page.evaluate('LOONIE_V12.start("design").ok')
    assert not page.evaluate('LOONIE_V12.advance(2,{...LOONIE_V12.get().plan}).ok') # gated choice month 1
    assert page.evaluate('state.lifeV12.month')==0
    route(page,'life12-month','Make this month');assert page.locator('[data-plan]').count()==7
    page.locator('[data-plan="housing"]').select_option('studio')
    page.locator('[data-plan="training"]').select_option('intensive')
    preview=page.evaluate('LOONIE_V12.project(LOONIE_V12.get(),LOONIE_V12.get().plan,0)')
    assert preview['ok'] and preview['summary']['expenses']['rent']==1180 and preview['summary']['expenses']['training']==280
    assert page.evaluate('LOONIE_V12.get().month')==0 # preview is side effect free
    route(page,'life12-month');page.locator('input[name="ll-choice"][value="1"]').check();page.locator('#ll-commit').click()
    assert page.evaluate('LOONIE_V12.get().month')==1
    route(page,'life12-result','What changed?');page.locator('#ll-note').fill('I am practising realistic financial trade-offs and understanding costs.')
    assert 'financial trade-offs' in page.evaluate('LOONIE_V12.get().journal[1]')
    assert page.evaluate('state.lifeAwardsV12.month1')
    print('NEW-STORY/FORM/FORECAST/CHOICE/NOTES PASS',flush=True)
    route(page,'life12-story','Monthly ledger');assert page.locator('.ll-table tbody tr').count()==1
    with page.expect_download() as download_info:page.locator('#ll-csv').click()
    assert download_info.value.suggested_filename=='loonie-life-ledger.csv'
    route(page,'life12-journal');assert 'monthly reflections' in page.locator('#screen').inner_text().lower()
    with page.expect_download() as download_info:page.locator('#ll-jexport').click()
    assert download_info.value.suggested_filename=='loonie-life-story-private.json'
    # An existing v11 completed practice project satisfies only the project gate;
    # second-tier career pay still needs actual lesson quiz progress AND sim experience.
    assert page.evaluate('LOONIE_V12.lessonScore(LOONIE_V12.get()).projects')==1
    assert page.evaluate('LOONIE_V12.tier(LOONIE_V12.get())')==0
    # Apply completed quizzes for the linked lesson IDs using original saved format.
    ids=page.evaluate('LOONIE_V11.lessons(LOONIE_V11.paths.find(p=>p.id==="accounting"))')
    page.evaluate('ids=>{ids.forEach(id=>{state.done[id]="4/4";state.stars[id]=3;});save();}',ids)
    results=[]
    for i in range(2,25):
        # Mix aggressive and protective spending to exercise overdraft and interest handling.
        page.evaluate('''i=>{const x=LOONIE_V12.get();x.plan={...x.plan,housing:i%3===0?'family':'shared',food:i%4===0?'fresh':'balanced',transport:i%5===0?'car':'bike',training:i%3===0?'intensive':'course',work:i%4===0?'overtime':'regular',save:i%2?200:100,repay:i%3===0?250:100};save();}''',i)
        # Validate all event decisions and locked branches before committing.
        check=page.evaluate('''()=>{const c=LOONIE_V12.get(),e=LOONIE_V12.event(c);return e.opts.map((o,i)=>[LOONIE_V12.canUse(c,o[1]),LOONIE_V12.project(c,c.plan,i).ok]);}''')
        assert all(allowed==projectOk for allowed,projectOk in check),check
        result=page.evaluate('LOONIE_V12.advance(0,LOONIE_V12.get().plan)')
        assert result['ok'],(i,result)
        s=result['summary'];results.append(s)
        assert s['month']==i and s['endingCash']>=0 and s['endingDebt']>=0
        assert s['endingSavings']>=0 and 0<=s['energy']<=100 and 0<=s['reputation']<=100
        assert abs(s['endingCash']+s['endingSavings']-s['endingDebt']-s['netWorth'])<.011
        assert abs(s['openingCash']+s['salary']+s['business']['profit']+s['decision']-s['living']-s['expenses']['training']-s['repay']-s['deposit']+s['overdraft']-s['endingCash'])<.011
        assert s['endingDebt']>=-0.01
        if i==4:
            # Career + financial conditions (may or may not all be satisfied depending on play).
            ready=page.evaluate('LOONIE_V12.businessEligible(LOONIE_V12.get())')
            if ready:
                business=page.evaluate('LOONIE_V12.openBusiness("shop")');assert business['ok'],business
                assert not page.evaluate('LOONIE_V12.openBusiness("studio").ok')
        if i==10:
            before=page.evaluate('LOONIE_V12.get().experience')
            assert page.evaluate('LOONIE_V12.switchTrack("software").ok')
            assert page.evaluate('LOONIE_V12.get().experience')==max(0,before-8)
            assert not page.evaluate('LOONIE_V12.switchTrack("software").ok')
            assert page.evaluate('state.careerV11.custom["manual-1"].title')=='My sample'
        if i in (6,12,24):assert page.evaluate(f'!!state.lifeAwardsV12.month{i}')
    assert page.evaluate('LOONIE_V12.get().finished')
    assert len(results)==23
    assert page.evaluate('LOONIE_V12.get().history.length')==24
    assert not page.evaluate('LOONIE_V12.advance(0,LOONIE_V12.get().plan).ok')
    print('24 MONTHS/LEDGER RECONCILIATION/MILESTONES/CAREER SWITCH PASS',flush=True)
    route(page,'life12-finale','24 months');route(page,'life12-story');assert page.locator('.ll-table tbody tr').count()==24
    route(page,'life12-journal');assert page.locator('[data-jmonth]').count()==24
    report=page.evaluate('LOONIE_V12.report(false)');assert report['months']==24 and report['fictional']
    assert 'reflections' not in report
    reportPrivate=page.evaluate('LOONIE_V12.report(true)');assert 'reflections' in reportPrivate
    with page.expect_download() as d:page.locator('#ll-jexport').click()
    assert d.value.suggested_filename.endswith('.json')
    # Academy backup must include lifeV12 and track-dependent data without changing legacy keys.
    exported=page.evaluate('JSON.parse(makeBackup())')
    assert exported['state']['lifeV12']['month']==24
    assert exported['state']['notes']['79']=='Legacy Note'
    assert 'careerV11' in exported['state'] and 'kingdomV10' in exported['state']
    # Switching to a new story cannot repeat a single-use Academy reward.
    xp=page.evaluate('state.xp');coins=page.evaluate('state.coins');oldawards=page.evaluate('JSON.stringify(state.lifeAwardsV12)')
    route(page,'life12-settings');page.locator('#ll-reset').click()
    assert page.evaluate('LOONIE_V12.get().started')
    page.locator('#ll-reset').click()
    assert not page.evaluate('LOONIE_V12.get().started')
    assert page.evaluate('JSON.stringify(state.lifeAwardsV12)')==oldawards
    assert page.evaluate('state.careerV11.projects["accounting-1"].passedAt')
    page.evaluate('LOONIE_V12.start("accounting")')
    assert page.evaluate('LOONIE_V12.advance(0,LOONIE_V12.get().plan).ok')
    assert page.evaluate('state.xp')==xp and page.evaluate('state.coins')==coins
    print('EXPORTS/BACKUP/RESET/PERMANENT ANTI-FARMING PASS',flush=True)
    for h in ('career11','portfolio11','kingdom','inquiry','uni','learn','world','me'):
        route(page,h)
    assert not errors,errors
    ctx.close()
    # small-phone overflow + desktop
    for viewport in ({'width':360,'height':740},{'width':1280,'height':800}):
        ctx,page,errors=make(browser,viewport=viewport)
        route(page,'life12');page.locator('#ll-begin').click()
        for h in ('life12','life12-month','life12-business','life12-career','life12-story','life12-journal','life12-settings','learn','world','me'):
            route(page,h)
        assert not errors,errors
        ctx.close()
    browser.close()
print('PASS: Phase 6 full 24 months, source, exports, quiz gates, no reward farming, mobile+desktop routes',flush=True)
