STOCK PORTFOLIO – ANDROID PWA PACKAGE

Files:
- index.html: Your existing stock calculator with PWA metadata and service-worker registration.
- manifest.json: App name, home-screen display mode, colors and icons.
- service-worker.js: Caches the app shell for offline reopening after the first successful load.
- icons/: Android app icons.

INSTALL ON ANDROID:
1. Upload the CONTENTS of this folder to an HTTPS website/hosting service. Keep the folder structure unchanged.
2. Open the hosted website in Google Chrome on your Android phone.
3. Wait for the page to finish loading.
4. Tap Chrome's ⋮ menu and choose "Install app" or "Add to Home screen" (wording can vary).
5. Confirm. The Stock Portfolio icon will appear on your home screen/app drawer.

IMPORTANT:
- A PWA must be served from HTTPS (or localhost for testing). Opening index.html directly as a file will not install it as a PWA.
- Offline reopening works after the app has loaded successfully online at least once.
- Your calculator stores portfolio data in this browser's local storage. Avoid clearing Chrome site data. This is not cloud backup and will not automatically sync to another phone.
- This package does not connect to Angel One or fetch live market prices.
