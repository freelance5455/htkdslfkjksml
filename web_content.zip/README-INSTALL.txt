MAA NIRMALA DJ & TENT HOUSE — FINAL MANAGEMENT + ADS SEQUENCE UPDATE

PACKAGE FILES
- index.html
- manifest.webmanifest
- sw.js
- assets/mnd-icon-192.png
- assets/mnd-icon-512.png
- assets/mnd-splash-logo.png
- assets/apple-touch-icon.png

CHANGES IN THIS REVISION
1. Management auto-login remains disabled. Admin must click VERY SECURE LOGIN and pass verification on each visit.
2. After a successful login, the registration/mobile number is remembered in localStorage and the PIN is kept only in sessionStorage for the current browser tab session. Both fields can prefill after reopening the management login in that same tab session. This does NOT grant access automatically.
3. The PIN is not persisted in localStorage. Session storage is still accessible to page JavaScript, so this is a convenience feature, not strong credential storage. For strong security, use server-side authentication/Firebase Authentication and browser password-manager support.
4. Live Feed logout clears the saved mobile number, session-only PIN and legacy admin/manager credential keys.
5. Ads manager cards now show each ad's display sequence and include SET SEQUENCE beside PERMANENT DELETE. Set 1 for first, 2 for second, etc.; set 0 to return to automatic ordering. The sequence is saved to Firebase and is used by the public post-login ad scheduler. Ads with explicit sequence values appear before unsequenced ads; scheduled start/end times still apply.
6. Existing ad timing settings remain: first popup delay, start/end date-time, and delay between ads. Ads are shown one at a time and each is marked seen for the browser tab session.
7. The install CTA remains in Official Links Hub above Premium Client Portals. PWA install requires the browser's native prompt and an explicit user action; sites cannot silently force-install.
8. Service-worker cache bumped to v13 so deployed clients can fetch the latest shell.

DEPLOY TO VERCEL
1. Back up your current project.
2. Extract the ZIP and upload/replace index.html, manifest.webmanifest, sw.js, and the complete assets/ folder at the website root.
3. Keep the existing Vercel project/domain settings.
4. Confirm /manifest.webmanifest, /sw.js, /assets/mnd-icon-192.png and /assets/mnd-icon-512.png load after deployment.
5. On Android Chrome, refresh the website and test management login, logout, ad sequence ordering and PWA installation.

IMPORTANT SECURITY LIMITATIONS
The current project is a client-side HTML app. This ZIP cannot make client-side admin checks genuinely secure. The source contains hardcoded admin credentials/checks and a Telegram bot token; public HTML can be inspected. Rotate any exposed bot token and move admin authentication and Telegram messaging to a trusted server/API (or Firebase Authentication with strict database/storage rules). Do not treat browser storage as a security boundary.

TEST STATUS
- Executable inline JavaScript syntax checked with Node.js: passed.
- ZIP integrity: to be checked after packaging.
- Live Firebase behavior, deployed Vercel behavior and physical Android installation were not tested in this build.
