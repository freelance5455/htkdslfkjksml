PINPLAY — PWA (aplikasi yang bisa dipasang)

CARA MEMASANG KE NETLIFY
1. Ekstrak ZIP ini.
2. Upload isi folder PINPLAY_PWA ke Netlify sebagai deploy baru. Pastikan index.html, manifest.json, dan service-worker.js berada di folder publik paling atas (root), bukan di dalam folder tambahan.
3. Tunggu deploy selesai lalu buka https://pinply.netlify.app/ dengan Chrome di Android.
4. Tunggu beberapa detik. Jika tombol “Pasang PINPLAY di HP” muncul, tekan tombol itu. Jika tidak muncul, buka menu ⋮ Chrome lalu pilih “Install app” / “Tambahkan ke layar utama”.
5. Setelah terpasang, buka PINPLAY dari ikon di layar utama.

CATATAN
- Paket ini membuat PINPLAY menjadi PWA yang bisa dipasang; ini bukan APK Android native.
- Katalog, cover, pencarian, dan pemutaran lagu dari layanan internet tetap membutuhkan koneksi internet.
- Jangan upload hanya index.html. Semua file dalam ZIP ini dibutuhkan untuk instalasi PWA.
