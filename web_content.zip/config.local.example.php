<?php
/**
 * Copy this file to config.local.php and add your Decart permanent API key.
 * The application uses a private SQLite database at storage/workspace.sqlite.
 * Keep config.local.php private. The supplied .htaccess blocks web access.
 */
return [
    'decart_api_key' => 'PASTE_YOUR_DECART_PERMANENT_API_KEY_HERE',
    // Optional fallback only. Prefer entering this key in Admin → Magic Hour.
    'magichour_api_key' => '',
    // Optional Fish Audio fallback. Prefer adding the key in Admin → Voice AI (encrypted vault).
    'fish_audio_api_key' => '',
    // Optional: zero records agent LLM USD usage without charging platform credits.
    'agent_credits_per_usd' => 0,
    // Generate a private 32+ character secret; do not change it after encrypting admin API keys.
    'admin_api_encryption_key' => bin2hex(random_bytes(32)),
    'decart_api_base' => 'https://api.decart.ai/v1',
    // Use sdk-direct by default. Set http-signaling only if Decart grants private-preview access.
    'realtime_transport' => 'http-signaling',
    // Database selection is fixed to PDO SQLite in app/bootstrap.php.
    'max_reference_bytes' => 5242880,
    'max_image_bytes' => 15728640,
    'max_video_bytes' => 104857600,
    'max_audio_bytes' => 31457280,
    'max_prompt_length' => 2000,
    'max_storage_per_user_bytes' => 1073741824,
    'video_job_timeout_seconds' => 7200,
    'force_https' => true,
    // Set to the exact HTTPS origin/path for safe redirects; do not derive redirects from HTTP_HOST.
    'canonical_base_url' => 'https://your-domain.example',
    // Only list reverse-proxy IPs you operate and trust; otherwise forwarded headers are ignored.
    'trusted_proxy_ips' => [],
];
