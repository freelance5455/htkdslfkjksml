# LexiCards — Android WebView + Kotlin

Это исходный Android-проект. Интерфейс и учебная логика остаются в `app/src/main/assets/index.html` (JavaScript), а Kotlin предоставляет Android-интеграцию: полноэкранный WebView, выбор папки CSV через системный SAF picker, импорт/экспорт файлов и настройки для встроенного видео.

## Что внутри

- Полный интерфейс LexiCards из HTML-версии.
- SQL.js: настоящая SQLite база (`cards`, `decks`) сохраняется в IndexedDB WebView.
- CSV импорт/экспорт.
- Импорт всех CSV-файлов из выбранной папки Android через системный выбор папки.
- Экспорт `.sqlite` и `.csv` через системный диалог сохранения.
- UK/US аудио через Free Dictionary API с системным TTS fallback.
- Встроенный YouGlish JavaScript widget, переключение UK/US, статусы и ошибки.
- Android WebViewAssetLoader (`https://appassets.androidplatform.net/...`) вместо `file://`, JavaScript, DOM storage, third-party cookies и media playback.

## Сборка

Требуется Android Studio с Android SDK 35 и JDK 17.

1. Распаковать ZIP.
2. Android Studio → Open → выбрать папку `LexiCards-Kotlin`.
3. Дождаться Gradle Sync.
4. Build → Build Bundle(s) / APK(s) → Build APK(s).
5. APK появится в `app/build/outputs/apk/debug/app-debug.apk`.

Проект использует Android Gradle Plugin 8.7.3 и Kotlin 2.0.21. Gradle wrapper в архив не включён: Android Studio использует встроенный Gradle/создаёт wrapper при необходимости.

## YouGlish: диагностика и причина прежнего сбоя

В прежнем HTML был race condition: при нажатии «Видео» код ждал ровно 900 мс. Если API YouGlish загружался дольше, `fetch()` больше не вызывался. Если пользователь нажимал кнопку до готовности API, запрос терялся. Теперь запрос сохраняется в `ygPending` и выполняется из `onYouglishAPIReady()` сразу после создания виджета. Также добавлены `onerror`, `onFetchDone`, `onError` и видимый статус.

Исправлена конфигурация компонентов. Значения YouGlish: Search=1, Accent panel=2, Title=4, Caption=8, Speed=16. Раньше `64` ошибочно принималось за thumbnails, хотя в API это Control Buttons. Сейчас используется `1+2+4+8+16`, а выбор UK/US передаётся как третий аргумент `widget.fetch(word, "english", accent)`.

**Ограничение сервиса:** в документации YouGlish прямо указано, что использование виджета в мобильном приложении требует отдельного разрешения YouGlish. Без разрешения они могут ограничить или не разрешить встраивание. Это не технический обход; нужно запросить согласие у YouGlish. Виджет также зависит от сети и доступности YouTube в WebView. Ссылка «Powered by YouGlish.com» оставлена видимой.

## Важные примечания

- Для первого запуска нужен интернет: SQL.js загружается с CDN, а YouGlish и словарное аудио являются сетевыми функциями.
- Сама SQLite-база после загрузки хранится локально в IndexedDB WebView. Экспорт `.sqlite` создаёт отдельный файл по запросу.
- Не очищайте данные приложения без предварительного экспорта базы.
- Я проверил структуру исходников и JavaScript-синтаксис. Полную Gradle-сборку и запуск на физическом Xiaomi в этой среде выполнить нельзя: здесь нет Android SDK/Gradle. Поэтому это исходный проект, а не готовый APK.

## Политики YouGlish / YouTube

YouGlish использует YouTube. Для распространения приложения проверьте действующие требования YouGlish, YouTube Terms of Service и Google Privacy Policy, включая уведомление пользователя о cookies и конфиденциальности.
