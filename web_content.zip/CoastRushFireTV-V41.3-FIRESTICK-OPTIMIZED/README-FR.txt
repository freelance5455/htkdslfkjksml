COAST RUSH V41.2 – FIRE TV STICK 4K MAX – PROJET SOURCE COMPLET

Cette archive est le projet Android source consolidé destiné à une seule synchronisation/build de validation.

CONTENU
- Jeu HTML V41 embarqué dans app/src/main/assets/index.html.
- Chargement local depuis les assets via loadDataWithBaseURL (évite les erreurs file:/// et Page not found).
- Affichage paysage immersif et ratio logique 16:9 conservé.
- Ponts Android pour deux manettes, dimensions écran et statistiques Choreographer.
- Compteur de diagnostic WEB FPS / RAF / Android bridge / callbacks / JS / DRAW / PAD.
- Cache du fond statique et caches bornés de dégradés pour réduire les allocations Canvas répétées.
- LOD existant conservé : réduction déterministe d'environ 10 % de certains décors secondaires Fire TV; objets importants, route et profondeur de vision conservés.
- Version Android 42 (41.2-firestick-complete) pour permettre l'installation comme mise à jour si la signature est identique.

OUVRIR / COMPILER
1. Décompresser le dossier CoastRushFireTV.
2. Ouvrir ce dossier racine dans Android Studio (pas le sous-dossier app).
3. Laisser Gradle synchroniser le plugin Android déclaré dans build.gradle.
4. Choisir Build > Build Bundle(s) / APK(s) > Build APK(s).

PRÉREQUIS
- Android Studio récent, JDK 17 ou supérieur.
- Android SDK Platform 35 et Android Gradle Plugin 8.6.1 téléchargé par Gradle.
- Connexion réseau nécessaire au premier sync si les dépendances ne sont pas en cache.

IMPORTANT – LIMITES DE VALIDATION
- Cette archive est un projet source, PAS un APK compilé.
- L'environnement de préparation ne contient ni Gradle installé, ni Android SDK / android.jar : compilation APK impossible ici.
- La syntaxe JavaScript intégrée a été vérifiée avec Node.js; le code Java a été relu et les appels/liaisons contrôlés statiquement, mais n'a pas été compilé contre Android SDK.
- Choreographer mesure la cadence des callbacks UI Android; ce n'est pas une mesure directe des images effectivement présentées par le GPU/HDMI.
- Le cache Canvas et les modifications doivent être validés sur Fire TV Stick réel. Le gain FPS n'est pas garanti avant mesure.
- Le multijoueur HTTPS/WSS nécessite toujours son service de signalisation hébergé; l'APK local ne crée pas ce serveur.

AUDIT DES REGLAGES QUI PEUVENT IMPOSER UNE CONTRAINTE
- Suppression de la préférence Android preferredRefreshRate=60 Hz et de preferredDisplayModeId. L'application ne demande plus de mode écran fixe; Fire OS / le téléviseur conserve le choix du mode réellement négocié.
- Conservation de Choreographer uniquement comme sonde de diagnostic; il ne pilote pas la boucle de jeu et ne force pas le rafraîchissement.
- Conservation de l'accélération matérielle WebView et de la priorité importante du renderer; ces réglages évitent plutôt une dépriorisation du moteur.
- Suppression sur Fire TV du filtre CSS contrast/saturate et de l'ombre portée du canvas, qui ajoutaient une composition graphique par-dessus toute l'image.
- Résolution interne AUTO Fire TV limitée à 720p. FULL HD reste sélectionnable explicitement; ÉCO et HD gardent leurs plafonds. Cela réduit la charge de remplissage GPU sans toucher au ratio 16:9 ni à la géométrie de la route.
- Aucun limiteur artificiel de FPS ajouté. La boucle reste basée sur requestAnimationFrame.
- Le dt de simulation reste plafonné à 33 ms pour éviter les grands sauts physiques après une image perdue; ce plafond ne limite pas le nombre d'images par seconde, mais peut ralentir la simulation lors de longues interruptions.

AUDIT STATIQUE
- Aucun appel setFrameRate / preferredRefreshRate / preferredDisplayModeId ne subsiste.
- Aucun Thread.sleep ni temporisation bloquante n'a été trouvé dans le code de l'application.
- Syntaxe du JavaScript embarqué vérifiée avec Node.js.
- Le code Java Android reste à compiler dans Android Studio et à mesurer sur le Fire TV Stick réel.


V41.3 - OPTIMISATIONS FIRE TV (consolidation)
--------------------------------------------
- Correction d'un défaut du cache de décor : le contexte Canvas doit être réaffectable pendant la génération du cache hors écran.
- Cache des dégradés de halo et de vignettage pour éviter de les recréer à chaque image.
- Réduction des particules météo sur Fire TV (pluie 58 au lieu de 150, neige 52 au lieu de 140), sans changer les autres plateformes.
- LOD de décors secondaire conservé ; profondeur de route protégée par un plancher de 90 segments.
- Lecture du pont Choreographer via l'identifiant global injecté par Android, avec état d'erreur explicite.
- Fréquence d'affichage relue côté natif au moment de la mesure, car elle peut être indisponible trop tôt au démarrage.

IMPORTANT : archive source vérifiée et JavaScript contrôlé avec Node.js. APK non compilé et FPS non mesurés sur appareil physique dans cet environnement.
