COAST RUSH V41.4 — FIRE TV — OPTIMISATION RENDU
================================================

Base : source V41.3 fournie dans le dossier de travail.

CHANGEMENTS EFFECTIFS
---------------------
1. Réutilisation du tableau des segments visibles dans render() : plus de nouveau tableau à chaque frame.
2. Réutilisation de deux objets de projection par segment : les coordonnées projetées sont mises à jour en place au lieu de créer environ deux nouveaux objets par segment visible à chaque frame.
3. Le compteur Choreographer est désormais libellé « callbacks/s » dans le HUD. Il mesure la cadence des callbacks UI Android et NE constitue pas une mesure certifiée des images réellement présentées à l'écran.
4. Les éléments de jeu, les circuits, la route, les ponts, les tunnels/faux loopings, les décors, les voitures et les commandes n'ont pas été supprimés ni redessinés.

AUDIT DU RENDU V41.3
--------------------
- Canvas logique : 320 × 224, mis à l'échelle par le facteur RS.
- render() est appelé à chaque requestAnimationFrame.
- Le rendu projette jusqu'à drawN segments (105 au départ sur TV, plage adaptative 90–125).
- Chaque segment visible dessine la chaussée et parcourt ses objets de décor et véhicules.
- Le ciel, le dégradé d'horizon, le soleil, la vignette et certains dégradés de voiture sont déjà mis en cache.
- Le skyline/thème d'arrière-plan utilise déjà un canvas hors écran réutilisé.
- Le temps mesuré autour de render() correspond au temps JavaScript synchrone ; il ne mesure pas à lui seul le travail GPU, la composition WebView ou la présentation physique.
- Le pont Choreographer est un signal de cadence UI Android, pas un compteur de présentation matérielle.

ÉLÉMENTS PRÉSERVÉS
------------------
- Tous les segments et données de circuits présents dans la base V41.3.
- Tous les sprites et fonctions de dessin existants.
- Les décors et leur règle de LOD existante (aucune nouvelle suppression ajoutée).
- Les systèmes météo, conduite, collisions, adversaires, HUD et multijoueur.
- L'interface Android, le chargement WebView, les bridges manette et affichage.

VALIDATION EFFECTUÉE
--------------------
- Vérification des remplacements ciblés : effectuée.
- Vérification syntaxique JavaScript : voir résultat de livraison.
- Vérification intégrité ZIP : effectuée après génération.
- Aucun APK n'a été compilé dans cet environnement.
- Aucun test FPS réel sur Fire TV Stick n'a été effectué. Les gains doivent être mesurés sur l'appareil.

NOTE
----
Cette livraison cible une réduction des allocations temporaires dans le chemin chaud du rendu, qui peut réduire la pression du ramasse-miettes et les saccades. Elle ne prétend pas résoudre à elle seule un coût GPU ou une limitation de composition WebView. Les changements structurels plus lourds (cache bitmap des décors mobiles/projetés) ne sont pas activés car leur invalidation dépend des courbes, de la position, de la météo, des tunnels et des loopings ; les activer sans tests visuels sur Fire TV risquerait de figer ou faire disparaître des éléments.
