# Kpata — version prête pour compilation cloud

Ce ZIP contient un projet Android standard avec un wrapper WebView.
Il est structuré pour les services de compilation Android en ligne qui
acceptent un projet Android ZIP.

## Build
Le point d'entrée Android est `app/src/main/java/com/kpata/app/MainActivity.java`.
L'application charge `app/src/main/assets/index.html`.

## Important
Cette version permet de produire un APK de test. Pour une utilisation
réelle multi-utilisateurs, l'interface doit être reliée au serveur Kpata
déployé en HTTPS, puis les paiements MTN MoMo doivent être branchés avec
les identifiants API/merchant officiels.

Ne jamais mettre un PIN MTN MoMo dans le code.
