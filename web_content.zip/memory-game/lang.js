// Add a new language here: copy one block and translate it.
const LANGS = {
  ar: { dir:"rtl", title:"لعبة الذاكرة", moves:"الحركات", time:"الوقت", restart:"لعبة جديدة",
        win:"مبروك! خلصتها بـ {m} حركة وخلال {t} ثانية.",
        names:["قطة","كلب","أسد","سمكة","طائر","حصان","أرنب","بقرة"] },
  en: { dir:"ltr", title:"Memory Game", moves:"Moves", time:"Time", restart:"New game",
        win:"You won in {m} moves and {t} seconds!",
        names:["Cat","Dog","Lion","Fish","Bird","Horse","Rabbit","Cow"] },
  ku: { dir:"rtl", title:"یاری یادگە", moves:"جوڵە", time:"کات", restart:"یاریی نوێ",
        win:"پیرۆزە! بە {m} جوڵە و {t} چرکە تەواوت کرد.",
        names:["پشیلە","سەگ","شێر","ماسی","باڵندە","ئەسپ","کەروێشک","مانگا"] },
  tr: { dir:"ltr", title:"Hafıza Oyunu", moves:"Hamle", time:"Süre", restart:"Yeni oyun",
        win:"Tebrikler! {m} hamlede ve {t} saniyede bitirdin.",
        names:["Kedi","Köpek","Aslan","Balık","Kuş","At","Tavşan","İnek"] },
  fr: { dir:"ltr", title:"Jeu de mémoire", moves:"Coups", time:"Temps", restart:"Nouvelle partie",
        win:"Bravo ! Terminé en {m} coups et {t} secondes.",
        names:["Chat","Chien","Lion","Poisson","Oiseau","Cheval","Lapin","Vache"] }
};
const EMOJI = ["🐱","🐶","🦁","🐟","🐦","🐴","🐰","🐮"];
