Memory Game / لعبة الذاكرة
Open index.html in any browser. Languages: العربية, English, کوردی, Türkçe, Français.
To add a language, edit lang.js and add an <option> in index.html.
