const $ = id => document.getElementById(id);
let lang = localStorage.getItem("lang") || "ar";
let cards = [], open = [], moves = 0, matched = 0, seconds = 0, timer = null, lock = false;

function applyLang() {
  const L = LANGS[lang];
  document.documentElement.lang = lang;
  document.documentElement.dir = L.dir;
  $("lang").value = lang;
  $("title").textContent = L.title;
  document.title = L.title;
  $("lblMoves").textContent = L.moves;
  $("lblTime").textContent = L.time;
  $("restart").textContent = L.restart;
  document.querySelectorAll(".card .name").forEach(el => el.textContent = L.names[el.dataset.i]);
  if (!$("win").hidden) showWin();
}

function showWin() {
  $("win").hidden = false;
  $("win").textContent = LANGS[lang].win.replace("{m}", moves).replace("{t}", seconds);
}

function newGame() {
  clearInterval(timer); timer = null;
  moves = 0; matched = 0; seconds = 0; open = []; lock = false;
  $("moves").textContent = 0; $("time").textContent = 0; $("win").hidden = true;
  const deck = [...Array(8).keys(), ...Array(8).keys()].sort(() => Math.random() - .5);
  const board = $("board"); board.innerHTML = "";
  deck.forEach(i => {
    const b = document.createElement("button");
    b.className = "card"; b.dataset.i = i;
    b.innerHTML = `<span class="inner"><span class="face back"></span><span class="face front"><span class="emo">${EMOJI[i]}</span><span class="name" data-i="${i}"></span></span></span>`;
    b.addEventListener("click", () => flip(b));
    board.appendChild(b);
  });
  applyLang();
}

function flip(c) {
  if (lock || c.classList.contains("up") || c.classList.contains("done")) return;
  if (!timer) timer = setInterval(() => $("time").textContent = ++seconds, 1000);
  c.classList.add("up"); open.push(c);
  if (open.length < 2) return;
  moves++; $("moves").textContent = moves; lock = true;
  const [a, b] = open;
  if (a.dataset.i === b.dataset.i) {
    a.classList.add("done"); b.classList.add("done");
    open = []; lock = false; matched++;
    if (matched === 8) { clearInterval(timer); showWin(); }
  } else {
    setTimeout(() => { a.classList.remove("up"); b.classList.remove("up"); open = []; lock = false; }, 800);
  }
}

$("lang").addEventListener("change", e => { lang = e.target.value; localStorage.setItem("lang", lang); applyLang(); });
$("restart").addEventListener("click", newGame);
newGame();
