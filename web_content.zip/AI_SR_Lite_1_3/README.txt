AI-SR Lite 1.3 — ZIP prototype
================================

Open index.html in a browser on Android or desktop.

Included:
- Interactive graphics modes: Performance, Balanced, Quality, Ultra Quality, Native
- Scale and sharpness sliders
- Processing FPS limit selector
- Auto-optimization, frame-skip, and GPU preference toggles
- Mobile-friendly layout

Important limitation:
This is an HTML interface prototype, not a native Android APK and not a working screen upscaler. It does not capture other apps, process game frames, load a super-resolution neural network, or improve game graphics. The GPU toggle is a preference in the UI only. Those functions require a native Android implementation and a compatible upscaling model/pipeline.
