# JAS LAUNDRY ROOM ERP — Android wrapper (starter)

## ഉൾപ്പെടുത്തിയിരിക്കുന്നത്
- നിങ്ങൾ നൽകിയ `index.html` അടിസ്ഥാനമാക്കിയുള്ള നിലവിലെ billing, orders, customers, price list, reports, backup എന്നിവ.
- Android WebView wrapper project; Android Studio ഉപയോഗിച്ച് APK build ചെയ്യാനുള്ള അടിസ്ഥാന ഘടന.
- ബില്ലിൽ നിന്ന് QR order label പ്രിന്റ് ചെയ്യാനുള്ള prototype.
- WhatsApp-ൽ bill summary തയ്യാറാക്കി share ചെയ്യാനുള്ള prototype.
- പ്രിന്റ് ഡയലോഗിനുള്ള Android bridge.

## APK നിർമ്മിക്കുന്ന വിധം
1. Android Studio ഇൻസ്റ്റാൾ ചെയ്യുക.
2. ഈ ZIP extract ചെയ്ത് `JASLaundryRoom` ഫോൾഡർ Android Studio-യിൽ തുറക്കുക.
3. `app/src/main/assets/index.html` എന്ന ഫയലിലേക്ക് നൽകിയ `index.html` പകർത്തുക (assets ഫോൾഡർ ഇല്ലെങ്കിൽ സൃഷ്ടിക്കുക).
4. Gradle sync പൂർത്തിയാക്കുക.
5. **Build → Build APK(s)** തിരഞ്ഞെടുക്കുക.
6. സാധാരണ debug APK `app/build/outputs/apk/debug/app-debug.apk` എന്നിടത്ത് ലഭിക്കും.

ഈ പരിതസ്ഥിതിയിൽ Android SDK/Gradle build പ്രവർത്തിപ്പിച്ച് APK സൈൻ ചെയ്ത് പരിശോധിച്ചിട്ടില്ല; അതിനാൽ ZIP ഒരു Android Studio project ആണ്, APK ഫയൽ അല്ല.

## Barcode / QR കുറിപ്പ്
ഇപ്പോൾ order label-ൽ QR ചിത്രം ഒരു ഓൺലൈൻ QR service വഴി ലഭിക്കുന്നു; അതിന് ഇന്റർനെറ്റ് ആവശ്യമാണ്. യഥാർത്ഥ offline barcode scanner/QR camera scanning ചേർക്കാൻ Android camera permission, scanner library, test എന്നിവ കൂടി വേണം.

## WhatsApp കുറിപ്പ്
WhatsApp സന്ദേശം മുൻകൂട്ടി തയ്യാറാക്കുന്നു; അയയ്ക്കുന്നതിന് മുമ്പ് ഉപയോക്താവ് WhatsApp-ൽ സ്ഥിരീകരിക്കണം. ഇത് WhatsApp Business API integration അല്ല.

## Staff login + Cloud sync — production-നു മുമ്പ് നിർബന്ധം
നിലവിലെ HTML localStorage-ൽ ഡാറ്റ സൂക്ഷിക്കുന്നു. യഥാർത്ഥ multi-device cloud sync-നായി Firebase/Supabase പോലുള്ള backend, authentication, database rules, user roles, secure backups എന്നിവ കോൺഫിഗർ ചെയ്യണം. ഈ ZIP-ൽ backend project credentials ഉൾപ്പെടുത്തിയിട്ടില്ല. നിലവിലെ localStorage ഡാറ്റ സ്വയം cloud-ലേക്ക് സിങ്ക് ആവില്ല.

## സുരക്ഷാ മുന്നറിയിപ്പ്
ഇത് starter/demo project ആണ്. യഥാർത്ഥ customer data ഉപയോഗിക്കുന്നതിന് മുമ്പ് login, server-side authorization, backup/restore validation, privacy, and Android release signing എന്നിവ നടപ്പിലാക്കി പരിശോധിക്കുക.

## കമ്പ്യൂട്ടർ ഇല്ലാതെ GitHub വഴി APK ഉണ്ടാക്കാനുള്ള മറ്റൊരു മാർഗം

ഈ പ്രോജക്റ്റിൽ `.github/workflows/build-apk.yml` ചേർത്തിട്ടുണ്ട്. GitHub-ൽ പ്രോജക്റ്റ് അപ്‌ലോഡ് ചെയ്താൽ GitHub Actions വഴി APK build ചെയ്യാം. AndroidIDE ഇൻസ്റ്റാൾ ചെയ്യേണ്ടതില്ല; GitHub അക്കൗണ്ടും ഇന്റർനെറ്റും വേണം.

1. GitHub.com തുറന്ന് sign in ചെയ്യുക.
2. New repository ഉണ്ടാക്കുക; ഉദാഹരണത്തിന് `jas-laundry-erp` എന്ന് പേര് നൽകുക. Public അല്ലെങ്കിൽ Private തിരഞ്ഞെടുക്കാം.
3. ZIP ഫയൽ ഫോണിൽ Extract ചെയ്യുക.
4. Extract ചെയ്ത പ്രോജക്റ്റിലെ ഫയലുകളും `.github` ഫോൾഡറും repository-യുടെ root-ലേക്ക് upload/commit ചെയ്യുക. `.github/workflows/build-apk.yml` ഫയൽ upload ആയിട്ടുണ്ടെന്ന് ഉറപ്പാക്കുക.
5. Repository-യിലെ Actions tab തുറക്കുക. `Build JAS Laundry ERP APK` workflow തിരഞ്ഞെടുക്കുക; ആവശ്യമെങ്കിൽ `Run workflow` അമർത്തുക.
6. Run വിജയിച്ചാൽ ആ run തുറന്ന് Artifacts വിഭാഗത്തിൽ `JAS-Laundry-ERP-debug-APK` ഡൗൺലോഡ് ചെയ്യുക.
7. ഡൗൺലോഡ് ചെയ്ത artifact ZIP Extract ചെയ്താൽ `app-debug.apk` ലഭിക്കും.

ഇത് debug APK ആണ്; Play Store-ലേക്ക് പ്രസിദ്ധീകരിക്കാൻ signing/release തയ്യാറെടുപ്പുകൾ വേണം. GitHub Actions build പരാജയപ്പെട്ടാൽ error message പരിശോധിച്ച് പരിഹരിക്കണം. APK build ചെയ്യുന്നത് മാത്രം cloud database അല്ലെങ്കിൽ staff login സൗകര്യങ്ങൾ ചേർക്കുന്നില്ല.
