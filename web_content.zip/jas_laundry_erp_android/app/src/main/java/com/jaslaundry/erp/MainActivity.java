package com.jaslaundry.erp;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.print.PrintManager;
import android.content.Context;
import android.webkit.JavascriptInterface;
import android.print.PrintAttributes;

public class MainActivity extends Activity {
    private WebView webView;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new PrintBridge(), "AndroidPrint");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }
    private class PrintBridge {
        @JavascriptInterface public void printPage() {
            runOnUiThread(() -> {
                if (android.os.Build.VERSION.SDK_INT >= 19) {
                    PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                    android.print.PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter("JAS-Laundry");
                    pm.print("JAS-Laundry", adapter, new PrintAttributes.Builder().build());
                }
            });
        }
    }
    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
