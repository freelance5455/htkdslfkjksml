HAJI MURREED HUSSAIN PETROLEUM — VERSION 8.2

Features:
- Separate Petrol and Diesel rates.
- Rate buttons save independently and apply immediately to NEW sales.
- New Fuel Transaction: choose Petrol or Diesel.
- Enter Amount OR Liters; the other value calculates automatically.
- Every saved transaction keeps its own rate, amount and liters.
- Today dashboard shows Petrol, Diesel and combined totals for money and liters.
- Sale history with Petrol/Diesel filters.
- Profile image works and can be replaced; default pump image is included.
- Password lock, password change, backup/restore, calculator.
- Expenses, stock, purchases, shifts and other unnecessary modules removed as requested.

First password: 1234

Open index.html in a browser. Keep profile-default.jpg in the same folder.
