# AppForge – gerador de apps com IA local

Grátis e open source (MIT). Chat com IA, imagem de referência da interface, e salvamento dos apps gerados no armazenamento do celular.

## Gerar o APK (Capacitor)
Requisitos: Node 18+, Android Studio (ou JDK 17 + Android SDK).

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android   # Build > Build APK(s)
```

Permissões: no arquivo `android/app/src/main/AndroidManifest.xml` confirme que existem
`READ_EXTERNAL_STORAGE` e `WRITE_EXTERNAL_STORAGE` (o plugin Filesystem já adiciona).
Os projetos gerados são salvos em `Documentos/AppForge/<nome-do-projeto>/`.

## IA local – duas opções
1. **Servidor local (recomendado):** Ollama ou llama.cpp (API compatível com OpenAI) rodando no próprio celular via Termux, ou no PC da mesma rede. Endpoint padrão: `http://localhost:11434/v1`. Para imagem, use um modelo com visão (ex.: `llava`, `qwen2.5vl`).
2. **No navegador (WebLLM/WebGPU):** baixa o modelo uma vez e depois funciona offline. Exige celular com WebGPU; modelos pequenos (ex.: `Qwen2.5-Coder-1.5B-Instruct-q4f16_1-MLC`). Não aceita imagem.

## Como funciona
O app instrui a IA a responder arquivos no formato ```` ```file:caminho/arquivo.ext ````. O app lê esses blocos, mostra a lista, permite pré-visualizar o `index.html` e salvar tudo no armazenamento.
