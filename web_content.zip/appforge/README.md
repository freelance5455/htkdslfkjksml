# AppForge – gerador de apps com IA local
Grátis e open source (MIT). Chat com IA, imagem de referência da interface, e salvamento dos apps gerados no armazenamento do celular.
## Gerar o APK (Capacitor)
Requisitos: Node 18+, Android Studio (ou JDK 17 + Android SDK).
```bash
npm install
npx cap add android
npx cap sync android
npx cap open android   # Build > Build APK(s)
```
Armazenamento: o app usa o seletor oficial de arquivos/pastas do Android (Storage Access Framework via seletor do WebView). O usuário escolhe explicitamente o que compartilhar. Não adicione `MANAGE_EXTERNAL_STORAGE`, `READ_EXTERNAL_STORAGE` ou `WRITE_EXTERNAL_STORAGE`: são desnecessárias para esse fluxo e permissões antigas/restritas nas versões recentes do Android.
A exportação gera um único ZIP e, no Android, grava em `Documentos/AppForge/` usando o plugin Capacitor Filesystem. Fora do Android, inicia o download pelo navegador.
O botão “Escolher pasta / arquivos” abre o seletor do sistema. O botão de seleção GGUF também abre o seletor diretamente; não há solicitação de acesso amplo ao armazenamento.
Os projetos gerados são exportados como `Documentos/AppForge/<nome-do-projeto>.zip`.
## IA local – três opções
1. **Servidor local (recomendado):** Ollama ou llama.cpp (API compatível com OpenAI) rodando no próprio celular via Termux, ou no PC da mesma rede. Endpoint padrão: `http://localhost:11434/v1`. Para imagem, use um modelo com visão (ex.: `llava`, `qwen2.5vl`).
2. **No navegador (WebLLM/WebGPU):** baixa o modelo uma vez e depois funciona offline. Exige celular com WebGPU; modelos pequenos (ex.: `Qwen2.5-Coder-1.5B-Instruct-q4f16_1-MLC`). Não aceita imagem.
3. **Arquivo .gguf no celular (novo):** toque em *Selecionar arquivo de IA*, conceda a permissão de armazenamento quando pedida, escolha o arquivo `.gguf` que você baixou e toque em **OK**. Na primeira mensagem o modelo é carregado e a IA roda 100% no dispositivo via llama.cpp/WebAssembly (wllama), sem servidor e sem depender de WebGPU.
   - Use modelos pequenos e quantizados (Q4/Q5), ex.: `Qwen2.5-Coder-1.5B-Instruct-Q4_K_M.gguf` ou `Qwen2.5-Coder-3B-Instruct-Q4_K_M.gguf`.
   - Limite de ~2 GB por arquivo (restrição do navegador). Modelos maiores precisam ser divididos.
   - Na primeira vez o app baixa ~10 MB do motor WebAssembly (depois fica em cache). A velocidade depende do celular; WASM em CPU é mais lento que um servidor nativo.
   - Imagens de referência não são processadas neste modo (apenas texto).
## Como funciona
O app instrui a IA a responder arquivos no formato ```` ```file:caminho/arquivo.ext ````. O app lê esses blocos, mostra a lista, permite pré-visualizar o `index.html` e salvar tudo no armazenamento.
