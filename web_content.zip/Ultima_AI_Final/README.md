# Ultima AI — Final Android Foundation

This is the production-oriented Android foundation for Ultima AI. It is deliberately **backend-ready** and contains **no Gemini API key**. The private backend will be connected in the next step.

## What is included
- Native Android wrapper with Android 16 / API 36 target for current Google Play submission requirements.
- Ultima AI workspace UI: Talk, Sources, Notes, Writing, Settings.
- Source library with local file selection and text/markdown/CSV/JSON extraction.
- Notes that can also become sources.
- AI mode selector: AI only, Sources only, Web search, Sources + Web.
- Web search OFF by default.
- Local draft saving and TXT export.
- Voice input where the device supports Android WebView speech recognition.
- Backend URL setting with a simple `/chat` contract.
- No API key in the app.

## Important
The AI response engine is intentionally not active until the private server is created. This prevents the Gemini credential from being shipped inside the APK. Google’s Gemini documentation says production mobile apps should not expose API keys client-side and recommends a backend proxy.

## Next step
After this ZIP is accepted by the build tool/Android build environment, create the private backend. The backend should expose `POST /chat` and keep the Gemini credential in server-side secret storage. Then set the backend URL in Ultima AI Settings.

For Google Play, build a signed Android App Bundle (`.aab`) and upload it through Play Console. New apps submitted from Aug. 31, 2026 must target Android 16 / API 36 or higher.

## Opening experience
The app now opens with a built-in Ultima AI splash sequence: futuristic computer/AI graphic, green energy burst, full-screen green transition, then the Ultima AI title before the workspace loads. The launcher icon is a matching futuristic AI-at-computer design.
