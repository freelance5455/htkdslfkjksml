# RWC HTML Terminal

A local HTML terminal connected to a native Python adapter and a custom, allowlisted command interpreter.

## Run

Requirements: Python 3.9+; no third-party packages.

- Linux/macOS: `./run.sh`
- Windows: `run.bat`
- Or: `python3 server.py`

Then open <http://127.0.0.1:8765>.

Set another local port with `RWC_PORT=9000 ./run.sh`.

## Implemented commands

`help`, `about`, `pwd`, `ls`, `cd`, `cat`, `write`, `mkdir`, `touch`, `rm`, `echo`, `whoami`, `uname`, `date`, `env`, `history`, `status`, `clear`, `exit`.

All filesystem operations are confined to `vfs/`. The interpreter does not use `os.system`, `subprocess`, or a host shell. Shell chaining, redirection, pipes, and command substitution are intentionally rejected.

## About the uploaded native daemon

The original x86-64 and Android ARM64 binaries are preserved in `original_artifacts/`. Static inspection identifies the x86-64 binary as an ELF executable and its embedded strings refer to a Stratum mining pool, port 3333, a BTC wallet, and an HTTP status page. This is not evidence of a CPU instruction emulator or shell. The binaries are therefore **not auto-started** and are not used to execute shell commands.

This package does not claim to be a full Linux VM, machine-code CPU emulator, or a wrapper for the original daemon. Integrating the original binary requires its protocol/source or documentation and a separate review of its network behavior.

## Security notes

- HTTP server binds only to `127.0.0.1`.
- Requests are size-limited and checked for local host/origin.
- Commands run against a virtual filesystem only.
- This is a development/demo adapter, not a hardened multi-user service.
