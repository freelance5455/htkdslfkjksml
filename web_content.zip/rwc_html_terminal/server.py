#!/usr/bin/env python3
"""RWC HTML Terminal adapter.
Runs a deliberately small command interpreter over a virtual filesystem.
It does not execute arbitrary host shell commands.
"""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import json, os, threading, time, shlex, mimetypes

ROOT = Path(__file__).resolve().parent
WEB_ROOT = ROOT
VFS_ROOT = ROOT / "vfs"
VFS_ROOT.mkdir(exist_ok=True)
LOCK = threading.RLock()
STARTED = time.time()

DEFAULT_FILES = {
    "welcome.txt": "RWC local terminal\nType 'help' to see available commands.\n",
    "etc/motd": "Welcome to the RWC virtual environment.\nThis is a sandboxed simulated shell.\n",
    "home/guest/notes.txt": "Files here are stored in the local virtual filesystem.\n",
}
for rel, content in DEFAULT_FILES.items():
    p = VFS_ROOT / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    if not p.exists():
        p.write_text(content, encoding="utf-8")

def safe_path(cwd, raw):
    raw = raw or "."
    if raw.startswith("/"):
        candidate = (VFS_ROOT / raw.lstrip("/")).resolve()
    else:
        candidate = (VFS_ROOT / cwd.lstrip("/") / raw).resolve()
    if candidate != VFS_ROOT and VFS_ROOT not in candidate.parents:
        raise ValueError("path escapes the virtual filesystem")
    return candidate

def vpath(path):
    try:
        return "/" + str(path.relative_to(VFS_ROOT)).replace(os.sep, "/")
    except ValueError:
        return "/"

class Session:
    def __init__(self):
        self.cwd = "/home/guest"
        self.env = {"USER": "guest", "HOME": "/home/guest", "SHELL": "/bin/rwcsh", "TERM": "xterm-256color"}
        self.history = []

    def run(self, command):
        command = command.strip()
        if not command:
            return {"ok": True, "output": "", "cwd": self.cwd}
        if len(command) > 4096:
            return {"ok": False, "output": "error: command too long (4096 character limit)", "cwd": self.cwd}
        self.history.append(command)
        try:
            # Small, explicit grammar. No pipes, redirects, substitutions, or host shell.
            if any(x in command for x in (";", "&&", "||", "`", "$(", ">", "<", "|")):
                return {"ok": False, "output": "error: shell operators and command chaining are disabled in this sandbox", "cwd": self.cwd}
            args = shlex.split(command)
            if not args:
                return {"ok": True, "output": "", "cwd": self.cwd}
            cmd, *argv = args
            out = self.dispatch(cmd, argv)
            return {"ok": True, "output": out, "cwd": self.cwd}
        except (ValueError, OSError) as e:
            return {"ok": False, "output": f"error: {e}", "cwd": self.cwd}

    def dispatch(self, cmd, argv):
        if cmd in ("help", "?"):
            return ("RWC custom command interpreter\n"
                    "help                 show this help\n"
                    "about                describe this environment\n"
                    "pwd                  print virtual working directory\n"
                    "ls [path]            list virtual directory\n"
                    "cd [path]            change virtual directory\n"
                    "cat <file>           print a virtual file\n"
                    "write <file> <text>  create/replace a virtual file\n"
                    "mkdir <path>         create a virtual directory\n"
                    "touch <file>         create an empty virtual file\n"
                    "rm <file>            remove a virtual file (not directories)\n"
                    "echo <text...>       print text\n"
                    "whoami               print simulated user\n"
                    "uname                print simulated system name\n"
                    "date                 print local server time\n"
                    "env                  list simulated environment variables\n"
                    "clear                clear terminal display\n"
                    "history              show this session's command history\n"
                    "status               show adapter status\n"
                    "exit                 show a message (server stays running)\n"
                    "Note: commands run only in the virtual filesystem; arbitrary host commands are not executed.")
        if cmd == "about":
            return "RWC HTML Terminal 1.0 — local adapter + custom sandboxed interpreter.\nThis is not a Linux VM or CPU emulator."
        if cmd == "pwd":
            return self.cwd
        if cmd == "whoami":
            return self.env["USER"]
        if cmd == "uname":
            return "RWC-Virtual 1.0 sandbox"
        if cmd == "date":
            return time.strftime("%a %b %d %H:%M:%S %Y %Z")
        if cmd == "env":
            return "\n".join(f"{k}={v}" for k, v in sorted(self.env.items()))
        if cmd == "history":
            return "\n".join(f"{i+1:4}  {line}" for i, line in enumerate(self.history)) or "(empty)"
        if cmd == "clear":
            return "__CLEAR__"
        if cmd == "exit":
            return "Session remains available in this browser. Close the tab to leave the terminal."
        if cmd == "status":
            return f"adapter: online\nuptime: {int(time.time()-STARTED)} seconds\nmode: simulated shell\nfilesystem: {VFS_ROOT}"
        if cmd == "echo":
            return " ".join(argv)
        if cmd == "ls":
            p = safe_path(self.cwd, argv[0] if argv else ".")
            if not p.exists():
                raise ValueError(f"no such path: {argv[0] if argv else '.'}")
            if p.is_file():
                return p.name
            items = sorted(p.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower()))
            return "\n".join(("d " if x.is_dir() else "f ") + x.name + ("/" if x.is_dir() else "") for x in items) or "(empty directory)"
        if cmd == "cd":
            target = argv[0] if argv else self.env["HOME"]
            p = safe_path(self.cwd, target)
            if not p.exists() or not p.is_dir():
                raise ValueError(f"not a directory: {target}")
            self.cwd = vpath(p)
            return ""
        if cmd == "cat":
            if len(argv) != 1:
                raise ValueError("usage: cat <file>")
            p = safe_path(self.cwd, argv[0])
            if not p.is_file():
                raise ValueError(f"not a file: {argv[0]}")
            if p.stat().st_size > 256_000:
                raise ValueError("file exceeds 256 KB display limit")
            return p.read_text(encoding="utf-8", errors="replace")
        if cmd == "write":
            if len(argv) < 2:
                raise ValueError("usage: write <file> <text...>")
            p = safe_path(self.cwd, argv[0])
            if p.exists() and p.is_dir():
                raise ValueError("target is a directory")
            p.parent.mkdir(parents=True, exist_ok=True)
            content = " ".join(argv[1:])
            if len(content.encode("utf-8")) > 65536:
                raise ValueError("file content exceeds 64 KB limit")
            p.write_text(content + "\n", encoding="utf-8")
            return f"wrote {len(content.encode('utf-8'))} bytes to {vpath(p)}"
        if cmd == "mkdir":
            if len(argv) != 1:
                raise ValueError("usage: mkdir <path>")
            p = safe_path(self.cwd, argv[0])
            p.mkdir(parents=True, exist_ok=False)
            return f"created {vpath(p)}"
        if cmd == "touch":
            if len(argv) != 1:
                raise ValueError("usage: touch <file>")
            p = safe_path(self.cwd, argv[0])
            if p.exists() and p.is_dir():
                raise ValueError("target is a directory")
            p.parent.mkdir(parents=True, exist_ok=True)
            p.touch(exist_ok=True)
            return f"touched {vpath(p)}"
        if cmd == "rm":
            if len(argv) != 1:
                raise ValueError("usage: rm <file>")
            p = safe_path(self.cwd, argv[0])
            if p.is_dir():
                raise ValueError("rm only removes files; directory deletion is disabled")
            if not p.exists():
                raise ValueError(f"no such file: {argv[0]}")
            p.unlink()
            return f"removed {vpath(p)}"
        raise ValueError(f"unknown command: {cmd}. Type 'help'.")

class Handler(SimpleHTTPRequestHandler):
    sessions = {}
    session_lock = threading.Lock()
    server_version = "RWCTerminal/1.0"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(WEB_ROOT), **kwargs)

    def log_message(self, fmt, *args):
        print("[http]", fmt % args)

    def _json(self, code, data):
        body = json.dumps(data).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == "/api/status":
            return self._json(200, {"ok": True, "name": "RWC HTML Terminal Adapter", "mode": "simulated shell", "uptime_seconds": int(time.time()-STARTED)})
        if self.path == "/":
            self.path = "/index.html"
        return super().do_GET()

    def do_POST(self):
        if self.path != "/api/command":
            return self._json(404, {"ok": False, "output": "not found"})
        origin = self.headers.get("Origin")
        host = self.headers.get("Host", "")
        # Local-only server: reject remote host headers and cross-origin browser calls.
        if not (host.startswith("127.0.0.1:") or host.startswith("localhost:") or host.startswith("[::1]:")):
            return self._json(403, {"ok": False, "output": "local connections only"})
        if origin and not (origin.startswith("http://127.0.0.1:") or origin.startswith("http://localhost:") or origin.startswith("http://[::1]:")):
            return self._json(403, {"ok": False, "output": "cross-origin request rejected"})
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length < 0 or length > 8192:
                return self._json(413, {"ok": False, "output": "request too large"})
            payload = json.loads(self.rfile.read(length).decode("utf-8"))
            command = payload.get("command", "")
            sid = str(payload.get("session", "default"))[:80]
            with self.session_lock:
                session = self.sessions.setdefault(sid, Session())
            with LOCK:
                result = session.run(str(command))
            return self._json(200, result)
        except Exception as e:
            return self._json(400, {"ok": False, "output": f"bad request: {e}"})

if __name__ == "__main__":
    host = "127.0.0.1"
    port = int(os.environ.get("RWC_PORT", "8765"))
    print(f"RWC HTML Terminal available at http://{host}:{port}")
    print("Only the local simulated command interpreter is enabled; original daemon is not auto-started.")
    ThreadingHTTPServer((host, port), Handler).serve_forever()
