LIVE LOOPS 200 - Android Project

यह project reference वाले 9:16 Live Loops interface के अनुसार बनाया गया है।

मुख्य सुविधाएँ:
- A: 1-50, B: 51-100, C: 101-150, D: 151-200
- हर Loop पर + Add से MP3/WAV चुन सकते हैं
- Loop दबाने पर audio repeat होती है (Repeat ON)
- दूसरा Loop दबाने पर पहला बंद होकर नया Loop चलता है
- हर Loop का BPM 30-300 और Volume 0-100 सेव होता है
- Bank बदलने पर चालू Loop बंद नहीं होता
- Delete, Import, Settings, Search और Master Volume
- पूरा data offline phone में सेव होता है
- Portrait / 9:16 Android screen

Build:
Android Studio में इस folder को Open करें और Run/Build APK करें।
अगर कोई online builder wrapper मांगता है, तो Android Studio में पहले Gradle Sync करके APK बनाएं।
