package com.liveloops.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.graphics.*;
import android.media.MediaPlayer;
import android.media.PlaybackParams;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import java.io.*;

public class MainActivity extends Activity {
    static final int PICK_AUDIO = 7001;
    LoopCanvas ui;
    android.content.SharedPreferences prefs;
    MediaPlayer player;
    int currentSlot = -1;
    boolean repeatOn = true;
    int masterVolume = 80;
    int pendingFileSlot = -1;

    static class Loop {
        String name, path;
        int bpm = 120, volume = 80;
        Loop(int i) { name = "Loop " + (i + 1); path = ""; }
    }
    final Loop[] loops = new Loop[200];

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(3,8,15));
        getWindow().setNavigationBarColor(Color.rgb(3,8,15));
        prefs = getSharedPreferences("live_loops", MODE_PRIVATE);
        load();
        ui = new LoopCanvas(this);
        setContentView(ui);
    }

    int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    void load() {
        masterVolume = clamp(prefs.getInt("master", 80), 0, 100);
        repeatOn = prefs.getBoolean("repeat", true);
        for (int i=0;i<200;i++) {
            loops[i] = new Loop(i);
            loops[i].name = prefs.getString("name_"+i, "Loop "+(i+1));
            loops[i].path = prefs.getString("path_"+i, "");
            loops[i].bpm = clamp(prefs.getInt("bpm_"+i, 120),30,300);
            loops[i].volume = clamp(prefs.getInt("vol_"+i, 80),0,100);
        }
    }
    void saveLoop(int i) {
        prefs.edit().putString("name_"+i, loops[i].name).putString("path_"+i, loops[i].path)
                .putInt("bpm_"+i, loops[i].bpm).putInt("vol_"+i, loops[i].volume).apply();
    }
    void saveGlobal() { prefs.edit().putInt("master", masterVolume).putBoolean("repeat", repeatOn).apply(); }

    void chooseFile(int slot) {
        pendingFileSlot = slot;
        Intent in = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        in.addCategory(Intent.CATEGORY_OPENABLE); in.setType("audio/*");
        in.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(in, PICK_AUDIO);
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req,res,data);
        if (req != PICK_AUDIO || res != RESULT_OK || data == null || data.getData() == null || pendingFileSlot < 0) return;
        int slot = pendingFileSlot; pendingFileSlot = -1;
        Uri uri = data.getData();
        try {
            String name = uri.getLastPathSegment();
            if (name == null || name.trim().isEmpty()) name = "Loop " + (slot+1);
            name = name.replaceFirst("^.*[:/]", "");
            File dst = new File(getFilesDir(), "loop_"+(slot+1)+"_"+System.currentTimeMillis()+".audio");
            try (InputStream in=getContentResolver().openInputStream(uri); OutputStream out=new FileOutputStream(dst)) {
                byte[] buf=new byte[8192]; int n; while ((n=in.read(buf))!=-1) out.write(buf,0,n);
            }
            if (!loops[slot].path.isEmpty()) try { new File(loops[slot].path).delete(); } catch(Exception ignored) {}
            loops[slot].path = dst.getAbsolutePath(); loops[slot].name = name; saveLoop(slot);
            ui.invalidate(); play(slot);
        } catch(Exception e) { toast("Audio file save नहीं हुई"); }
    }

    void play(int slot) {
        if (slot < 0 || slot >= 200) return;
        if (loops[slot].path.isEmpty()) { chooseFile(slot); return; }
        releasePlayer();
        try {
            player = new MediaPlayer();
            player.setDataSource(loops[slot].path);
            player.setLooping(repeatOn);
            player.setOnPreparedListener(mp -> {
                applyAudioSettings(mp, loops[slot]);
                mp.start(); currentSlot=slot; ui.invalidate();
            });
            player.setOnErrorListener((mp,what,extra)->{ toast("इस Loop की audio नहीं चल सकी"); releasePlayer(); return true; });
            player.prepareAsync();
            currentSlot = slot; ui.invalidate();
        } catch(Exception e) { toast("Audio error"); releasePlayer(); }
    }

    void applyAudioSettings(MediaPlayer mp, Loop l) {
        float vol=(l.volume/100f)*(masterVolume/100f); mp.setVolume(vol,vol);
        if (Build.VERSION.SDK_INT>=23) {
            try { PlaybackParams pp=mp.getPlaybackParams(); pp.setSpeed(clamp(l.bpm,30,300)/120f); mp.setPlaybackParams(pp); } catch(Exception ignored) {}
        }
    }
    void refreshPlayingAudio() { if (player != null && currentSlot >= 0) { try { player.setLooping(repeatOn); applyAudioSettings(player, loops[currentSlot]); } catch(Exception ignored) {} } }
    void releasePlayer() { if(player!=null){ try{player.stop();}catch(Exception ignored){} try{player.release();}catch(Exception ignored){} player=null; } currentSlot=-1; if(ui!=null)ui.invalidate(); }
    void stopOnly() { releasePlayer(); }

    void loopSettings(final int slot) {
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(28,8,28,2);
        EditText name=new EditText(this); name.setHint("Loop Name"); name.setSingleLine(); name.setText(loops[slot].name);
        EditText bpm=new EditText(this); bpm.setHint("BPM 30–300"); bpm.setInputType(2); bpm.setText(String.valueOf(loops[slot].bpm));
        EditText vol=new EditText(this); vol.setHint("Volume 0–100"); vol.setInputType(2); vol.setText(String.valueOf(loops[slot].volume));
        box.addView(name); box.addView(bpm); box.addView(vol);
        new AlertDialog.Builder(this).setTitle("Loop "+(slot+1)+" Settings").setView(box)
            .setPositiveButton("Save",(d,w)->{
                loops[slot].name=name.getText().toString().trim(); if(loops[slot].name.isEmpty()) loops[slot].name="Loop "+(slot+1);
                try{loops[slot].bpm=clamp(Integer.parseInt(bpm.getText().toString()),30,300);}catch(Exception ignored){}
                try{loops[slot].volume=clamp(Integer.parseInt(vol.getText().toString()),0,100);}catch(Exception ignored){}
                saveLoop(slot); if(currentSlot==slot) refreshPlayingAudio(); ui.invalidate();
            })
            .setNeutralButton("Add / Change File",(d,w)->chooseFile(slot))
            .setNegativeButton("Delete File",(d,w)->{ if(!loops[slot].path.isEmpty())try{new File(loops[slot].path).delete();}catch(Exception ignored){} loops[slot].path=""; saveLoop(slot); if(currentSlot==slot)stopOnly(); ui.invalidate(); })
            .show();
    }

    void globalSettings() {
        String[] items={"Selected Loop Settings","Add / Change Loop File","How it works","App Info"};
        new AlertDialog.Builder(this).setTitle("⚙ Settings").setItems(items,(d,which)->{
            if(which==0){ if(currentSlot>=0) loopSettings(currentSlot); else toast("पहले कोई Loop चुनें"); }
            else if(which==1){ chooseFile(currentSlot>=0?currentSlot:ui.bank*50); }
            else if(which==2){ new AlertDialog.Builder(this).setTitle("Live Loops 200").setMessage("A = 1–50\nB = 51–100\nC = 101–150\nD = 151–200\n\nLoop दबाएँ = Play/Repeat\n+ Add Loop = Audio जोड़ें\nBPM 30–300 और Volume 0–100 अलग-अलग सेव होते हैं। Bank बदलने पर चालू Loop चलता रहता है।").setPositiveButton("OK",null).show(); }
            else { new AlertDialog.Builder(this).setTitle("Live Loops 200").setMessage("Offline Android Live Loop Player\n200 slots • MP3/WAV • BPM • Volume • Repeat").setPositiveButton("OK",null).show(); }
        }).show();
    }
    void toast(String s){ Toast.makeText(this,s,Toast.LENGTH_SHORT).show(); }
    @Override protected void onDestroy(){ releasePlayer(); super.onDestroy(); }

    class LoopCanvas extends View {
        final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); final RectF r=new RectF();
        final int[] accents={Color.rgb(25,140,255),Color.rgb(30,210,105),Color.rgb(255,165,20),Color.rgb(205,60,245)};
        int bank=0; String filter="";
        float den;
        LoopCanvas(Context c){super(c); den=getResources().getDisplayMetrics().density; setBackgroundColor(Color.rgb(2,7,14)); p.setTypeface(Typeface.create("sans",Typeface.NORMAL)); setFocusable(true);}
        void text(Canvas c,String s,float x,float y,float size,int color,Paint.Align a){p.setStyle(Paint.Style.FILL);p.setColor(color);p.setTextSize(size);p.setTextAlign(a);c.drawText(s,x,y,p);}
        void box(Canvas c,float l,float t,float rr,float b,float rad,int color,boolean stroke){r.set(l,t,rr,b);p.setStyle(stroke?Paint.Style.STROKE:Paint.Style.FILL);p.setStrokeWidth(2);p.setColor(color);c.drawRoundRect(r,rad,rad,p);}
        float dp(float x){return x*den;}
        @Override protected void onDraw(Canvas c){
            super.onDraw(c); float w=getWidth(),h=getHeight();
            // Compact 9:16-friendly header: title, brand, offline status and settings stay readable on narrow phones.
            text(c,"☰",16,31,27,Color.WHITE,Paint.Align.LEFT);
            text(c,"♫",50,31,27,Color.rgb(0,205,255),Paint.Align.LEFT);
            text(c,"Live Loops 200",82,27,19,Color.WHITE,Paint.Align.LEFT);
            text(c,"VS MUSICAL STUDIO",84,46,9,Color.LTGRAY,Paint.Align.LEFT);
            box(c,w-128,8,w-58,38,9,Color.rgb(5,55,65),true); text(c,"● Offline",w-93,25,9,Color.rgb(0,255,140),Paint.Align.CENTER);
            box(c,w-51,8,w-10,38,9,Color.rgb(12,30,50),true); text(c,"⚙",w-30,28,18,Color.WHITE,Paint.Align.CENTER);
            text(c,"No Internet Required",w-12,54,8,Color.LTGRAY,Paint.Align.RIGHT);
            float bankTop=62,gap=5,bw=(w-20-gap*3)/4;
            for(int i=0;i<4;i++){float l=14+i*(bw+gap);box(c,l,bankTop,l+bw,bankTop+53,11,i==bank?accents[i]:Color.rgb(12,29,48),i!=bank);text(c,""+(char)('A'+i),l+bw/2,bankTop+25,21,Color.WHITE,Paint.Align.CENTER);text(c,(i*50+1)+"–"+((i+1)*50),l+bw/2,bankTop+44,10,Color.LTGRAY,Paint.Align.CENTER);}
            float head=121; box(c,10,head,w-10,head+43,10,Color.rgb(8,25,40),true); text(c,""+(char)('A'+bank),34,head+31,19,Color.WHITE,Paint.Align.CENTER); text(c,"Bank "+(char)('A'+bank)+"  ("+(bank*50+1)+"–"+((bank+1)*50)+")",59,head+30,17,Color.WHITE,Paint.Align.LEFT);
            box(c,w-275,head+7,w-25,head+40,9,Color.rgb(6,18,30),true); text(c,"⌕  Search Loop...",w-260,head+29,12,Color.LTGRAY,Paint.Align.LEFT);
            float gridTop=head+50, bottom=h-132; int cols=5,rows=10; float gx=4,gy=4,tileW=(w-20-gx*4)/5f,tileH=Math.max(42,(bottom-gridTop-gy*9)/10f); int start=bank*50;
            for(int row=0;row<10;row++) for(int col=0;col<5;col++){
                int idx=start+row*5+col; float l=14+col*(tileW+gx),t=gridTop+row*(tileH+gy); int ac=accents[(row+col)%4]; boolean active=idx==currentSlot;
                box(c,l,t,l+tileW,t+tileH,8,active?Color.rgb(6,75,70):Color.rgb(7,20,32),true); if(active){p.setColor(Color.rgb(0,255,150));p.setStrokeWidth(3);p.setStyle(Paint.Style.STROKE);c.drawRoundRect(new RectF(l,t,l+tileW,t+tileH),8,8,p);}
                box(c,l+5,t+5,l+31,t+31,7,ac,false); text(c,""+(idx+1),l+18,t+23,12,Color.BLACK,Paint.Align.CENTER);
                String nm=loops[idx].name; if(nm.length()>12) nm=nm.substring(0,12); text(c,nm,l+37,t+17,9,Color.WHITE,Paint.Align.LEFT); text(c,loops[idx].bpm+" BPM",l+37,t+31,8,Color.LTGRAY,Paint.Align.LEFT);
                box(c,l+5,t+tileH-20,l+tileW-5,t+tileH-5,6,Color.rgb(16,95,180),false); text(c,loops[idx].path.isEmpty()?"+ Add":"♫",l+tileW/2,t+tileH-9,7,Color.WHITE,Paint.Align.CENTER);
            }
            float cy=h-121; box(c,10,cy,w-10,cy+42,10,Color.rgb(7,24,39),true);
            if(currentSlot>=0){ text(c,"Loop "+(currentSlot+1),18,cy+17,11,Color.WHITE,Paint.Align.LEFT); text(c,loops[currentSlot].bpm+" BPM",18,cy+32,8,Color.LTGRAY,Paint.Align.LEFT); } else { text(c,"No Loop Selected",18,cy+25,10,Color.LTGRAY,Paint.Align.LEFT); }
            box(c,112,cy+7,145,cy+35,7,Color.rgb(14,62,94),false); text(c,"−",128,cy+27,16,Color.WHITE,Paint.Align.CENTER);
            text(c,currentSlot>=0?""+loops[currentSlot].bpm:"120",169,cy+26,12,Color.WHITE,Paint.Align.CENTER); text(c,"BPM",169,cy+37,7,Color.LTGRAY,Paint.Align.CENTER);
            box(c,191,cy+7,224,cy+35,7,Color.rgb(14,62,94),false); text(c,"+",207,cy+27,16,Color.WHITE,Paint.Align.CENTER);
            text(c,"Vol",238,cy+16,8,Color.LTGRAY,Paint.Align.LEFT); box(c,260,cy+12,318,cy+22,5,Color.rgb(15,55,80),false); box(c,260,cy+12,260+(58*(currentSlot>=0?loops[currentSlot].volume:80)/100f),cy+22,5,Color.rgb(0,150,255),false);
            box(c,w-92,cy+7,w-53,cy+35,7,Color.rgb(18,105,215),false); text(c,"▶",w-72,cy+27,14,Color.WHITE,Paint.Align.CENTER);
            box(c,w-48,cy+7,w-10,cy+35,7,Color.rgb(90,35,45),false); text(c,"■",w-29,cy+27,12,Color.WHITE,Paint.Align.CENTER);
            box(c,174,cy,260,cy+43,10,Color.rgb(12,27,42),true); text(c,"▣ Delete",217,cy+27,12,Color.WHITE,Paint.Align.CENTER);
            box(c,269,cy,420,cy+43,10,Color.rgb(12,27,42),true); text(c,"◀  ▶  Play",344,cy+27,12,Color.WHITE,Paint.Align.CENTER);
            box(c,429,cy,w-14,cy+43,10,repeatOn?Color.rgb(8,80,80):Color.rgb(12,27,42),true); text(c,repeatOn?"↻ Repeat ON":"↻ Repeat OFF",(429+w-14)/2,cy+27,12,Color.WHITE,Paint.Align.CENTER);
            float mv=cy+53; text(c,"🔊 Master Volume",16,mv+14,11,Color.WHITE,Paint.Align.LEFT); box(c,140,mv+5,w-78,mv+18,6,Color.rgb(15,55,80),false); box(c,140,mv+5,140+(w-218)*masterVolume/100f,mv+18,6,Color.rgb(0,150,255),false); text(c,masterVolume+"%",w-24,mv+16,10,Color.LTGRAY,Paint.Align.RIGHT);
            float nav=h-35; String[] ns={"▦\nLoops","◌\nBPM","🔊\nVolume","＋\nAdd Loop","⚙\nSettings"}; for(int i=0;i<5;i++){float l=i*w/5f; if(i==0)box(c,l+2,nav-4,l+w/5f-2,h-4,10,Color.rgb(5,50,100),false); String[] z=ns[i].split("\\n"); text(c,z[0],l+w/10,nav+10,19,i==0?Color.rgb(0,220,255):Color.WHITE,Paint.Align.CENTER); text(c,z[1],l+w/10,nav+29,9,i==0?Color.rgb(0,220,255):Color.LTGRAY,Paint.Align.CENTER); }
        }

        void searchDialog(){ final EditText q=new EditText(MainActivity.this); q.setHint("Loop 1, Kick, 120..."); new AlertDialog.Builder(MainActivity.this).setTitle("Search Loop").setView(q).setPositiveButton("Search",(d,w)->{filter=q.getText().toString().trim();invalidate();}).setNegativeButton("Clear",(d,w)->{filter="";invalidate();}).show(); }
        @Override public boolean onTouchEvent(MotionEvent e){
            if(e.getAction()!=MotionEvent.ACTION_UP)return true; float x=e.getX(),y=e.getY(),w=getWidth(),h=getHeight();
            if(y<65&&x>w-105){globalSettings();return true;}
            float gap=7,bw=(w-28-gap*3)/4;
            if(y>=68&&y<=125){for(int i=0;i<4;i++){float l=14+i*(bw+gap);if(x>=l&&x<=l+bw){bank=i;invalidate();return true;}}}
            float head=129;
            if(y>=head&&y<=head+47){if(x>w-290){searchDialog();} else if(x<100&&currentSlot>=0){loopSettings(currentSlot);} return true;}
            float gridTop=head+55,bottom=h-112;float gx=6,gy=6,tileW=(w-28-gx*4)/5f,tileH=Math.max(44,(bottom-gridTop-gy*9)/10f); int row=(int)((y-gridTop)/(tileH+gy)),col=(int)((x-14)/(tileW+gx));
            if(row>=0&&row<10&&col>=0&&col<5&&y>=gridTop&&y<gridTop+10*(tileH+gy)){int idx=bank*50+row*5+col;float localX=x-(14+col*(tileW+gx));if(localX>tileW-70)chooseFile(idx);else play(idx);return true;}
            float cy=h-121;
            if(y>=cy&&y<=cy+45){
                if(x>=112&&x<145&&currentSlot>=0){ loops[currentSlot].bpm=clamp(loops[currentSlot].bpm-5,30,300); saveLoop(currentSlot); refreshPlayingAudio(); invalidate(); }
                else if(x>=191&&x<224&&currentSlot>=0){ loops[currentSlot].bpm=clamp(loops[currentSlot].bpm+5,30,300); saveLoop(currentSlot); refreshPlayingAudio(); invalidate(); }
                else if(x>=w-95&&x<w-50){ if(currentSlot>=0) play(currentSlot); else play(bank*50); }
                else if(x>=w-50){ stopOnly(); }
                else if(x>=250&&x<325&&currentSlot>=0){ loops[currentSlot].volume=clamp((int)((x-260)/58f*100),0,100); saveLoop(currentSlot); refreshPlayingAudio(); invalidate(); }
                else if(x<105){ chooseFile(currentSlot>=0?currentSlot:bank*50); }
                return true;
            }
            float mv=cy+50;if(y>=mv&&y<=mv+25){masterVolume=clamp((int)((x-140)/(w-218f)*100),0,100);saveGlobal();refreshPlayingAudio();invalidate();return true;}
            if(y>=h-42){int nav=(int)(x/(w/5f));if(nav==1&&currentSlot>=0)loopSettings(currentSlot);else if(nav==2&&currentSlot>=0)loopSettings(currentSlot);else if(nav==3)chooseFile(currentSlot>=0?currentSlot:bank*50);else if(nav==4)globalSettings();return true;}
            return true;
        }
    }
}
