import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, onAuthStateChanged, setPersistence, browserLocalPersistence } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";

const firebaseConfig = {
    apiKey: "AIzaSyBaINUsaM4Zy8KZGStbQgXS0RfY2Mkgzpg",
    authDomain: "aut-9e6a3.firebaseapp.com",
    projectId: "aut-9e6a3",
    storageBucket: "aut-9e6a3.firebasestorage.app",
    messagingSenderId: "901681725549",
    appId: "1:901681725549:web:91b4230b9c8fbeea263f64",
    measurementId: "G-11KL65PMY5"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

window.selectedDeviceType = null;
let isSubmitting = false;

// Красивые звуковые уведомления (Toast)
function showToast(text, isError = false) {
    const toast = document.getElementById('toast-notification');
    const toastText = document.getElementById('toast-text');
    const toastIcon = document.getElementById('toast-icon');

    toastText.innerText = text;
    if (isError) {
        toast.classList.add('error-toast');
        toastIcon.innerText = "❌";
    } else {
        toast.classList.remove('error-toast');
        toastIcon.innerText = "✨";
        try {
            const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
            const osc = audioCtx.createOscillator();
            const gain = audioCtx.createGain();
            osc.connect(gain); gain.connect(audioCtx.destination);
            osc.type = 'sine'; osc.frequency.setValueAtTime(587.33, audioCtx.currentTime);
            osc.frequency.setValueAtTime(880, audioCtx.currentTime + 0.08);
            gain.gain.setValueAtTime(0.1, audioCtx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + 0.4);
            osc.start(); osc.stop(audioCtx.currentTime + 0.4);
        } catch(e) {}
    }

    toast.classList.add('show');
    setTimeout(() => { toast.classList.remove('show'); }, 3000);
}

window.showToastExternal = showToast;

// Автовизначення типу пристрою (щоб форма одразу була робочою і на телефоні, і на ПК)
function detectDeviceType() {
    const isTouch = ('ontouchstart' in window) || (navigator.maxTouchPoints > 0);
    const isNarrow = window.innerWidth <= 600;
    return (isTouch && isNarrow) ? 'phone' : 'pc';
}

function markDeviceCard(type) {
    document.getElementById('dev-pc').classList.remove('selected');
    document.getElementById('dev-phone').classList.remove('selected');
    const el = document.getElementById('dev-' + type);
    if (el) el.classList.add('selected');
}

// Вибір пристрою (клік користувача завжди має пріоритет над автовизначенням)
window.selectDevice = function(type) {
    window.selectedDeviceType = type;
    markDeviceCard(type);
};

// Ініціалізація дефолтного пристрою одразу, щоб форма не була "заблокована"
window.selectedDeviceType = detectDeviceType();
document.addEventListener('DOMContentLoaded', () => {
    markDeviceCard(window.selectedDeviceType);
});

function setFieldError(fieldId, errorId, message) {
    const field = document.getElementById(fieldId);
    const errorEl = document.getElementById(errorId);
    if (message) {
        field.classList.add('invalid');
        errorEl.innerText = message;
    } else {
        field.classList.remove('invalid');
        errorEl.innerText = '';
    }
}

function clearFieldErrors() {
    setFieldError('auth-email', 'email-error', '');
    setFieldError('auth-password', 'password-error', '');
}

function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

// Переклад помилок Firebase на зрозумілу українську
function translateAuthError(error) {
    const code = error && error.code ? error.code : '';
    switch (code) {
        case 'auth/email-already-in-use':
            return 'Цей email вже зареєстрований. Спробуйте увійти.';
        case 'auth/invalid-email':
            return 'Некоректний формат email.';
        case 'auth/weak-password':
            return 'Пароль занадто слабкий (мінімум 6 знаків).';
        case 'auth/missing-password':
            return 'Введіть пароль.';
        case 'auth/user-not-found':
        case 'auth/invalid-credential':
        case 'auth/wrong-password':
            return 'Невірний логін або пароль.';
        case 'auth/too-many-requests':
            return 'Забагато спроб. Спробуйте пізніше.';
        case 'auth/network-request-failed':
            return 'Немає з\'єднання з мережею. Перевірте інтернет.';
        default:
            return 'Помилка: ' + (error && error.message ? error.message : 'спробуйте ще раз');
    }
}

function setButtonsBusy(busy, activeLabelId) {
    const loginBtn = document.getElementById('submit-login');
    const regBtn = document.getElementById('submit-reg');
    const loginLabel = document.getElementById('login-btn-label');
    const regLabel = document.getElementById('reg-btn-label');

    loginBtn.disabled = busy;
    regBtn.disabled = busy;

    if (busy) {
        if (activeLabelId === 'login-btn-label') {
            loginLabel.innerHTML = '<span class="btn-spinner"></span>Вхід...';
        } else {
            regLabel.innerHTML = '<span class="btn-spinner"></span>Реєстрація...';
        }
    } else {
        loginLabel.innerText = 'Вхід';
        regLabel.innerText = 'Реєстрація';
    }
}

// Приховуємо екран завантаження і показуємо потрібний екран
function finishLoading(showAuth) {
    if (window.__loadingFailsafeTimer) {
        clearTimeout(window.__loadingFailsafeTimer);
        window.__loadingFailsafeTimer = null;
    }

    const loadingScreen = document.getElementById('loading-screen');
    const authScreen = document.getElementById('auth-screen');

    loadingScreen.classList.add('hidden');

    if (showAuth) {
        authScreen.classList.remove('hidden');
        // невелика затримка, щоб анімація появи спрацювала коректно
        requestAnimationFrame(() => authScreen.classList.add('visible'));
    } else {
        authScreen.classList.add('hidden');
        authScreen.classList.remove('visible');
        document.getElementById('main-controls').classList.remove('hidden');
    }
}

// Перевірка сесії
setPersistence(auth, browserLocalPersistence)
  .then(() => {
      onAuthStateChanged(auth, (user) => {
          if (user) {
              window.selectedDeviceType = localStorage.getItem('userDevice') || detectDeviceType();
              finishLoading(false);
          } else {
              finishLoading(true);
          }
      });
  })
  .catch(() => {
      // Навіть якщо сесія не відновилась - не залишаємо користувача на вічному завантаженні
      finishLoading(true);
  });

// Запасний таймаут: якщо Firebase з якоїсь причини не відповів (немає мережі тощо),
// не тримаємо користувача на екрані завантаження вічно.
setTimeout(() => {
    const loadingScreen = document.getElementById('loading-screen');
    if (!loadingScreen.classList.contains('hidden')) {
        finishLoading(true);
    }
}, 8000);

// Авторизация Вход / Регистрация
window.handleAuth = function(mode) {
    if (isSubmitting) return;

    clearFieldErrors();
    const email = document.getElementById('auth-email').value.trim();
    const password = document.getElementById('auth-password').value;

    let hasError = false;
    if (!email) {
        setFieldError('auth-email', 'email-error', 'Введіть email');
        hasError = true;
    } else if (!isValidEmail(email)) {
        setFieldError('auth-email', 'email-error', 'Некоректний формат email');
        hasError = true;
    }
    if (!password) {
        setFieldError('auth-password', 'password-error', 'Введіть пароль');
        hasError = true;
    } else if (password.length < 6) {
        setFieldError('auth-password', 'password-error', 'Мінімум 6 знаків');
        hasError = true;
    }

    if (hasError) {
        showToast("Перевірте поля форми", true);
        return;
    }

    isSubmitting = true;
    const activeLabelId = mode === 'login' ? 'login-btn-label' : 'reg-btn-label';
    setButtonsBusy(true, activeLabelId);

    const deviceType = window.selectedDeviceType || detectDeviceType();

    const authPromise = mode === 'register'
        ? createUserWithEmailAndPassword(auth, email, password)
        : signInWithEmailAndPassword(auth, email, password);

    authPromise
        .then(() => {
            localStorage.setItem('userDevice', deviceType);
            showToast(mode === 'register' ? "Реєстрація успішна! Ласкаво просимо." : "Вхід успішний!");
            // onAuthStateChanged сам приховає екран авторизації
        })
        .catch((error) => {
            showToast(translateAuthError(error), true);
        })
        .finally(() => {
            isSubmitting = false;
            setButtonsBusy(false);
        });
};
