// Ініціалізація карти та логіки додатка
const objectConfig = window.objectConfig;    

const map = L.map('map', { zoomControl: false, attributionControl: false }).setView([48.2, 36.5], 6);  

const tileLayers = {
    standard: L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19 }),
    deepstate: L.maplibreGL({
        style: 'https://api.maptiler.com/maps/01a0548d-df8f-788f-a9b5-b1478a9c15e9/style.json?key=kNnrfHqiZzNJJOp6luhd',
        attribution: '&copy; MapTiler &copy; OpenStreetMap contributors'
    }),
    darkmap: L.maplibreGL({
        style: 'https://api.maptiler.com/maps/01a00cf8-ea2b-729c-8626-7cc595eb5818/style.json?key=kNnrfHqiZzNJJOp6luhd',
        attribution: '&copy; MapTiler &copy; OpenStreetMap contributors'
    })
};

tileLayers.standard.addTo(map);
let currentTileLayer = 'standard';

let activeType = null;    
let currentMarker = null;    
let selectedMarker = null;    
let copyMode = false;    
let moveMode = false;   
let rotateOnlyMode = false;
let moveOnlyMode = false;
let copiedData = null;    

const markersLayer = L.layerGroup().addTo(map);    

fetch('deepstate.geojson').then(res => res.json()).then(data => {    
    L.geoJSON(data, { style: { color: "transparent", weight: 0, fillOpacity: 0.25, fillColor: "red" } }).addTo(map);    
}).catch(() => {});    

window.changeMapTheme = function(themeType) {
    if (!tileLayers[themeType]) return;
    
    map.removeLayer(tileLayers[currentTileLayer]);
    tileLayers[themeType].addTo(map);
    currentTileLayer = themeType;

    const bodyEl = document.getElementById('main-body');
    const mapEl = document.getElementById('map');
    
    if (themeType === 'standard') {
        bodyEl.classList.remove('dark-ui');
        mapEl.style.backgroundColor = '#ffffff';
    } else {
        bodyEl.classList.add('dark-ui');
        mapEl.style.backgroundColor = (themeType === 'deepstate') ? '#1c1c1e' : '#0b0b0b';
    }

    document.querySelectorAll('.theme-btn').forEach(btn => btn.classList.remove('active'));
    const activeBtn = document.getElementById(`btn-theme-${themeType}`);
    if (activeBtn) activeBtn.classList.add('active');

    if (typeof window.updateWatermarkImage === 'function') window.updateWatermarkImage();
    if (typeof window.rulerRefreshColors === 'function') window.rulerRefreshColors();

    if (typeof window.showToastExternal === 'function') {
        window.showToastExternal(`Тема змінена на: ${themeType === 'deepstate' ? 'Супутникова карта' : themeType}`);
    }
};

window.triggerSearch = function() {  
    const query = prompt("Введіть назву міста:");  
    if (!query) return;  
    fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=1`)
      .then(res => res.json()).then(data => {  
          if (data && data.length > 0) { map.setView([parseFloat(data[0].lat), parseFloat(data[0].lon)], 12); } 
          else { alert("Нічого не знадено."); }  
      });  
};  

function captionHtml(marker) {
    if (!marker.caption) return '';
    return `<div class="obj-caption-label">${escapeHtml(marker.caption)}</div>`;
}

function escapeHtml(text) {
    return String(text).replace(/[<>&"]/g, function(ch) {
        return ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;' })[ch];
    });
}

function updateMarkerHtml(marker) {
    const config = objectConfig[marker.objectType];
    const currentSrc = marker.customSrc || config.src;
    const captionDiv = captionHtml(marker);
    
    let html = "";
    if (marker.objectType === 'custom_marker') {
        html = `<div style="position: relative; width:${config.size}px; height:${config.size}px; display: flex; flex-direction: column; align-items: center;">${captionDiv}<img src="${currentSrc}" class="obj-icon" style="width:${config.size}px; height:${config.size}px;">${marker.textLabel ? `<div class="custom-marker-label" style="position: absolute; top: ${config.size + 2}px;">${marker.textLabel}</div>` : ''}</div>`;
    } else {
        if (config.requireLabel && marker.textLabel) {
            html = `<div style="position: relative; width:${config.size}px; height:${config.size}px;">
                        ${captionDiv}
                        <img src="${currentSrc}" class="obj-icon" style="width:${config.size}px; height:${config.size}px; transform: rotate(${marker.rotationAngle}deg);">
                        <div class="uav-top-right-label" style="position: absolute; left: ${config.size - 2}px; bottom: ${config.size - 4}px;">${marker.textLabel}</div>
                    </div>`;
        } else {
            html = `<div style="position: relative; width:${config.size}px; height:${config.size}px;">
                        ${captionDiv}
                        <img src="${currentSrc}" class="obj-icon" style="width:${config.size}px; height:${config.size}px; transform: rotate(${marker.rotationAngle}deg);">
                    </div>`;
        }
    }
    const icon = L.divIcon({ className: '', html: html, iconSize: [config.size, config.size], iconAnchor: [config.size / 2, config.size / 2] });
    marker.setIcon(icon);
}

function createMarker(latlng, type, angle = 0, textLabel = "") {    
    const config = objectConfig[type];    
    let radiusCircle = null;  
    if (config.radius) {  
        radiusCircle = L.circle(latlng, { radius: config.radius, color: 'red', weight: 1, fillColor: 'red', fillOpacity: 0.15, interactive: false }).addTo(markersLayer);  
    }  
    let html = "";
    if (type === 'custom_marker') {
        html = `<div style="position: relative; width:${config.size}px; height:${config.size}px; display: flex; flex-direction: column; align-items: center;"><img src="${config.src}" class="obj-icon" style="width:${config.size}px; height:${config.size}px;">${textLabel ? `<div class="custom-marker-label" style="position: absolute; top: ${config.size + 2}px;">${textLabel}</div>` : ''}</div>`;
    } else {
        if (config.requireLabel && textLabel) {
            html = `<div style="position: relative; width:${config.size}px; height:${config.size}px;">
                        <img src="${config.src}" class="obj-icon" style="width:${config.size}px; height:${config.size}px; transform: rotate(${angle}deg);">
                        <div class="uav-top-right-label" style="position: absolute; left: ${config.size - 2}px; bottom: ${config.size - 4}px;">${textLabel}</div>
                    </div>`;
        } else {
            html = `<div style="position: relative; width:${config.size}px; height:${config.size}px;">
                        <img src="${config.src}" class="obj-icon" style="width:${config.size}px; height:${config.size}px; transform: rotate(${angle}deg);">
                    </div>`;
        }
    }
    const icon = L.divIcon({ className: '', html: html, iconSize: [config.size, config.size], iconAnchor: [config.size / 2, config.size / 2] });    
    const marker = L.marker(latlng, { icon }).addTo(markersLayer);    
    marker.objectType = type; marker.rotationAngle = angle; marker.associatedCircle = radiusCircle; marker.textLabel = textLabel;
    
    marker.trailCoords = [latlng];
    marker.trailLine = null;
    marker.trailColor = 'red';
    marker.customSrc = null;
    marker.caption = "";

    marker.on('click', function(e) { e.originalEvent.stopPropagation(); selectMarker(marker); });    
    marker.on('dblclick', function(e) { e.originalEvent.stopPropagation(); selectMarker(marker); openCaptionEditor(marker); });
    return marker;    
}    

function selectMarker(marker) { clearSelectedMarker(); selectedMarker = marker; const el = marker.getElement(); if (el) el.classList.add('selected-marker'); }    
function clearSelectedMarker() { if (selectedMarker) { const el = selectedMarker.getElement(); if (el) el.classList.remove('selected-marker'); } selectedMarker = null; rotateOnlyMode = false; moveOnlyMode = false; hideObjectMenu(); }    

// Оновлений вибір об'єкта: повторне натискання вимикає режим розстановки
window.selectObject = function(type) { 
    if (activeType === type) {
        activeType = null;
        currentMarker = null;
        document.querySelectorAll('.controls button').forEach(btn => btn.classList.remove('active'));
    } else {
        activeType = type; 
        currentMarker = null; 
        document.querySelectorAll('.controls button').forEach(btn => btn.classList.remove('active')); 
        const btn = document.getElementById('btn-' + type); 
        if (btn) btn.classList.add('active'); 
    }
};    

window.toggleCategory = function(type) { const categories = ['uav-controls', 'missiles-controls', 'planes-controls', 'airdefense-controls', 'ships-controls']; categories.forEach(id => { if (id === type + '-controls') { document.getElementById(id).classList.toggle('hidden'); } else { document.getElementById(id).classList.add('hidden'); } }); };    
window.clearMap = function() { markersLayer.clearLayers(); currentMarker = null; clearSelectedMarker(); moveMode = false; hideObjectMenu(); };    

function showObjectMenu(marker) {
    const config = objectConfig[marker.objectType];
    document.getElementById('menu-object-name').innerText = config.name || marker.objectType;
    document.getElementById('menu-object-img').src = marker.customSrc || config.src;
    document.getElementById('object-menu-panel').classList.remove('hidden');
}

function hideObjectMenu() { document.getElementById('object-menu-panel').classList.add('hidden'); }

// ===== Підписи над об'єктами (подвійний клік) =====
let captionEditorMarker = null;

function truncateCaption(text) {
    const maxLen = 24;
    if (text.length > maxLen) {
        return text.slice(0, maxLen).trim() + '.';
    }
    return text;
}

function openCaptionEditor(marker) {
    captionEditorMarker = marker;
    const panel = document.getElementById('caption-editor-panel');
    const input = document.getElementById('caption-editor-input');
    input.value = marker.caption || '';

    const mapRect = map.getContainer().getBoundingClientRect();
    const point = map.latLngToContainerPoint(marker.getLatLng());
    const panelWidth = 200;
    let left = mapRect.left + point.x - (panelWidth / 2);
    let top = mapRect.top + point.y - 95;
    left = Math.max(8, Math.min(left, window.innerWidth - panelWidth - 8));
    top = Math.max(8, top);

    panel.style.left = left + 'px';
    panel.style.top = top + 'px';

    panel.classList.remove('hidden');
    input.focus();
}

window.closeCaptionEditor = function() {
    document.getElementById('caption-editor-panel').classList.add('hidden');
    captionEditorMarker = null;
};

window.saveCaption = function() {
    if (!captionEditorMarker) { window.closeCaptionEditor(); return; }
    const input = document.getElementById('caption-editor-input');
    const text = input.value.trim();
    captionEditorMarker.caption = text ? truncateCaption(text) : "";
    updateMarkerHtml(captionEditorMarker);
    window.closeCaptionEditor();
};

window.applyAutoCaptions = function() {
    markersLayer.eachLayer(function(layer) {
        if (layer.objectType) {
            const config = objectConfig[layer.objectType];
            const name = (config && config.name) ? config.name : "Невідомий об'єкт";
            layer.caption = truncateCaption(name);
            updateMarkerHtml(layer);
        }
    });
    window.closeCaptionEditor();
    if (typeof window.showToastExternal === 'function') window.showToastExternal("Автопідпис застосовано до всіх об'єктів!");
};
// ===== Кінець підписів над об'єктами =====

window.menuReplaceObject = function() {
    if (!selectedMarker) return;
    if (selectedMarker.objectType === 'kab') {
        selectedMarker.customSrc = 'images/shahed2.png';
        updateMarkerHtml(selectedMarker);
        document.getElementById('menu-object-img').src = selectedMarker.customSrc;
        if (typeof window.showToastExternal === 'function') window.showToastExternal("Об'єкт змінено на Шахед-2!");
    } else if (selectedMarker.objectType === 'kabk') {
        selectedMarker.customSrc = 'images/KAb250.png';
        updateMarkerHtml(selectedMarker);
        document.getElementById('menu-object-img').src = selectedMarker.customSrc;
        if (typeof window.showToastExternal === 'function') window.showToastExternal("Об'єкт змінено на КАБ-250!");
    } else {
        if (typeof window.showToastExternal === 'function') window.showToastExternal("Заміна доступна лише для Шахеда/КАБ", true);
    }
};

window.menuChangeRouteColor = function() {
    if (!selectedMarker) return;
    const newColor = prompt("Введіть колір для курсу англійською:", selectedMarker.trailColor);
    if (newColor) {
        selectedMarker.trailColor = newColor.trim();
        if (selectedMarker.trailLine) selectedMarker.trailLine.setStyle({ color: selectedMarker.trailColor, opacity: 0.5 });
        if (typeof window.showToastExternal === 'function') window.showToastExternal("Колір курсу змінено!");
    }
};

// ===== Лінійка (вимірювання відстані) =====
let rulerMode = false;
let rulerPoints = [];
let rulerLine = null;
let rulerMarkersLayer = L.layerGroup().addTo(map);

function formatDistance(meters) {
    if (meters >= 1000) return (meters / 1000).toFixed(2) + ' км';
    return Math.round(meters) + ' м';
}

function getRulerTextColor() {
    const isDark = document.getElementById('main-body').classList.contains('dark-ui');
    return isDark ? '#ffffff' : '#000000';
}

function rulerAddLabel(latlng, text) {
    const color = getRulerTextColor();
    const icon = L.divIcon({
        className: '',
        html: `<div class="ruler-label" style="background:rgba(33,150,243,0.9); color:${color}; font-size:11px; font-weight:bold; padding:2px 6px; border-radius:4px; white-space:nowrap; transform:translate(-50%,-100%); box-shadow:0 1px 3px rgba(0,0,0,0.4);">${text}</div>`,
        iconSize: [0, 0]
    });
    return L.marker(latlng, { icon, interactive: false }).addTo(rulerMarkersLayer);
}

window.rulerRefreshColors = function() {
    const color = getRulerTextColor();
    rulerMarkersLayer.eachLayer(function(layer) {
        const el = layer.getElement && layer.getElement();
        if (el) {
            const labelDiv = el.querySelector('.ruler-label');
            if (labelDiv) labelDiv.style.color = color;
        }
    });
};

function rulerAddPoint(latlng) {
    const dotIcon = L.divIcon({
        className: '',
        html: `<div style="width:8px; height:8px; border-radius:50%; background:#2196f3; border:2px solid #fff; box-shadow:0 0 4px rgba(0,0,0,0.5); transform:translate(-50%,-50%);"></div>`,
        iconSize: [0, 0]
    });
    L.marker(latlng, { icon: dotIcon, interactive: false }).addTo(rulerMarkersLayer);

    rulerPoints.push(latlng);

    if (rulerPoints.length > 1) {
        if (!rulerLine) {
            rulerLine = L.polyline(rulerPoints, { color: '#2196f3', weight: 3, opacity: 0.85, dashArray: '6,6' }).addTo(rulerMarkersLayer);
        } else {
            rulerLine.setLatLngs(rulerPoints);
        }

        const prev = rulerPoints[rulerPoints.length - 2];
        const curr = rulerPoints[rulerPoints.length - 1];
        const segmentDist = prev.distanceTo(curr);
        const midpoint = L.latLng((prev.lat + curr.lat) / 2, (prev.lng + curr.lng) / 2);

        let totalDist = 0;
        for (let i = 1; i < rulerPoints.length; i++) {
            totalDist += rulerPoints[i - 1].distanceTo(rulerPoints[i]);
        }

        rulerAddLabel(midpoint, formatDistance(segmentDist));
        rulerAddLabel(curr, `Разом: ${formatDistance(totalDist)}`);
    }
}

function rulerClear() {
    rulerMarkersLayer.clearLayers();
    rulerPoints = [];
    rulerLine = null;
}

window.toggleRuler = function() {
    rulerMode = !rulerMode;
    const btn = document.getElementById('btn-ruler');

    if (rulerMode) {
        if (btn) btn.classList.add('active');
        if (map.getContainer()) map.getContainer().style.cursor = 'crosshair';
        if (typeof window.showToastExternal === 'function') window.showToastExternal("Лінійка увімкнена: клікайте по карті");
    } else {
        if (btn) btn.classList.remove('active');
        if (map.getContainer()) map.getContainer().style.cursor = '';
        rulerClear();
        if (typeof window.showToastExternal === 'function') window.showToastExternal("Лінійка вимкнена");
    }
};
// ===== Кінець лінійки =====

document.getElementById('caption-editor-input').addEventListener('keydown', function(event) {
    event.stopPropagation();
    if (event.key === 'Enter') { window.saveCaption(); }
    if (event.key === 'Escape') { window.closeCaptionEditor(); }
});

map.on('click', function(e) {    
    if (!document.getElementById('caption-editor-panel').classList.contains('hidden')) {
        window.closeCaptionEditor();
    }

    if (rulerMode) {
        rulerAddPoint(e.latlng);
        return;
    }

    if (rotateOnlyMode && selectedMarker) {
        if (!objectConfig[selectedMarker.objectType].noRotate) {
            const p1 = map.latLngToContainerPoint(selectedMarker.getLatLng());
            const p2 = map.latLngToContainerPoint(e.latlng);
            const angle = Math.atan2(p2.y - p1.y, p2.x - p1.x) * 180 / Math.PI + 90;
            selectedMarker.rotationAngle = angle;
            updateMarkerHtml(selectedMarker);
        }
        return;
    }

    if (moveOnlyMode && selectedMarker) {
        const newLatLng = e.latlng;
        selectedMarker.setLatLng(newLatLng);
        if (selectedMarker.associatedCircle) selectedMarker.associatedCircle.setLatLng(newLatLng);
        return;
    }

    if (moveMode && selectedMarker) {
        const lastLatLng = selectedMarker.getLatLng();
        const newLatLng = e.latlng;

        if (!objectConfig[selectedMarker.objectType].noRotate) {
            const p1 = map.latLngToContainerPoint(lastLatLng);    
            const p2 = map.latLngToContainerPoint(newLatLng);    
            const angle = Math.atan2(p2.y - p1.y, p2.x - p1.x) * 180 / Math.PI + 90;    
            selectedMarker.rotationAngle = angle;
            updateMarkerHtml(selectedMarker);
        }

        selectedMarker.setLatLng(newLatLng);
        if (selectedMarker.associatedCircle) selectedMarker.associatedCircle.setLatLng(newLatLng);

        selectedMarker.trailCoords.push(newLatLng);
        if (!selectedMarker.trailLine) {
            selectedMarker.trailLine = L.polyline(selectedMarker.trailCoords, { color: selectedMarker.trailColor || 'red', weight: 3, opacity: 0.5 }).addTo(markersLayer);
        } else {
            selectedMarker.trailLine.setLatLngs(selectedMarker.trailCoords);
        }
        return;
    }

    if (copyMode && copiedData) { createMarker(e.latlng, copiedData.type, copiedData.angle, copiedData.textLabel); copyMode = false; return; }    
    if (!activeType) return;    
    
    if (activeType === 'custom_marker') {
        const labelText = prompt("Введіть підпис для метки:");
        if (labelText !== null) createMarker(e.latlng, 'custom_marker', 0, labelText.trim());
      // Кнопка тепер НЕ вимикається сама, можна ставити мітки далі!
        return;
    }

    const isStaticObj = objectConfig[activeType].noRotate;

    if (!currentMarker) { 
        currentMarker = createMarker(e.latlng, activeType, 0); 
        if (isStaticObj) {
            // Статичні об'єкти (без повороту) створюються за 1 клік і кнопка також залишається активною
            currentMarker = null;
        }
    } else {    
        const p1 = map.latLngToContainerPoint(currentMarker.getLatLng());    
        const p2 = map.latLngToContainerPoint(e.latlng);    
        const angle = Math.atan2(p2.y - p1.y, p2.x - p1.x) * 180 / Math.PI + 90;    
        currentMarker.rotationAngle = angle;
        
        updateMarkerHtml(currentMarker);
       // Скидаємо лише посилання на поточний маркер, але активний тип (activeType) НЕ зануляємо!
        currentMarker = null; 
    }    
});    

window.toggleWatermark = function() { document.getElementById('watermark').classList.toggle('hidden'); };    

// ===== Налаштування вотермарки (V) =====
let watermarkText = '@operativno_monitor';
let watermarkRotation = -15;

function buildWatermarkSVG(text, rotation, color, opacity) {
    const safeText = String(text).replace(/[<>&]/g, '');
    const encoded = encodeURIComponent(safeText);
    return `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='280' height='150'%3E%3Ctext x='30' y='80' fill='${color}' opacity='${opacity}' font-size='16' font-family='sans-serif' font-weight='bold' transform='rotate(${rotation} 30 80)'%3E${encoded}%3C/text%3E%3C/svg%3E`;
}

function updateWatermarkImage() {
    const isDark = document.getElementById('main-body').classList.contains('dark-ui');
    const color = isDark ? 'white' : 'black';
    const opacity = isDark ? 0.12 : 0.15;
    const svgUrl = buildWatermarkSVG(watermarkText, watermarkRotation, color, opacity);
    const el = document.getElementById('watermark');
    if (el) el.style.backgroundImage = `url("${svgUrl}")`;
}

window.openWatermarkPanel = function() {
    const panel = document.getElementById('watermark-panel');
    panel.classList.remove('hidden');
    const textInput = document.getElementById('watermark-text-input');
    const rotationInput = document.getElementById('watermark-rotation-input');
    textInput.value = watermarkText;
    rotationInput.value = watermarkRotation;
    textInput.focus();
};

window.closeWatermarkPanel = function() {
    document.getElementById('watermark-panel').classList.add('hidden');
};

window.applyWatermarkSettings = function() {
    const textInput = document.getElementById('watermark-text-input');
    const rotationInput = document.getElementById('watermark-rotation-input');

    const newText = textInput.value.trim();
    if (newText) watermarkText = newText;

    const newRotation = parseFloat(rotationInput.value);
    if (!isNaN(newRotation)) watermarkRotation = newRotation;

    updateWatermarkImage();
    closeWatermarkPanel();
    if (typeof window.showToastExternal === 'function') window.showToastExternal("Вотермарку оновлено!");
};

document.getElementById('watermark-text-input').addEventListener('keydown', function(event) {
    event.stopPropagation();
    if (event.key === 'Enter') { window.applyWatermarkSettings(); }
    if (event.key === 'Escape') { window.closeWatermarkPanel(); }
});

document.getElementById('watermark-rotation-input').addEventListener('keydown', function(event) {
    event.stopPropagation();
    if (event.key === 'Enter') { window.applyWatermarkSettings(); }
    if (event.key === 'Escape') { window.closeWatermarkPanel(); }
});

updateWatermarkImage();
window.updateWatermarkImage = updateWatermarkImage;
// ===== Кінець налаштувань вотермарки =====

// Статус-текст (Shift+S): вікно вводу з вибором кольору (зелений/червоний), що пульсує
window.openStatusInput = function() {
    const modal = document.getElementById('status-input-modal');
    modal.classList.remove('hidden');
    const input = document.getElementById('status-text-input');
    input.value = '';
    input.focus();
};

window.closeStatusInput = function() {
    document.getElementById('status-input-modal').classList.add('hidden');
};

window.submitStatusText = function() {
    const input = document.getElementById('status-text-input');
    const text = input.value.trim();
    const colorInput = document.querySelector('input[name="status-color"]:checked');
    const color = colorInput ? colorInput.value : 'green';
    const display = document.getElementById('status-display');

    display.classList.remove('status-text-green', 'status-text-red');

    if (!text) {
        display.classList.add('hidden');
        display.textContent = '';
    } else {
        display.textContent = text;
        display.classList.add(color === 'red' ? 'status-text-red' : 'status-text-green');
        display.classList.remove('hidden');
    }
    closeStatusInput();
};

document.getElementById('status-text-input').addEventListener('keydown', function(event) {
    event.stopPropagation();
    if (event.key === 'Enter') { window.submitStatusText(); }
    if (event.key === 'Escape') { window.closeStatusInput(); }
});

// ===== Панель гарячих клавіш (I) =====
window.openHotkeysPanel = function() {
    document.getElementById('hotkeys-panel').classList.remove('hidden');
};

window.closeHotkeysPanel = function() {
    document.getElementById('hotkeys-panel').classList.add('hidden');
};

window.toggleHotkeysPanel = function() {
    const panel = document.getElementById('hotkeys-panel');
    if (panel.classList.contains('hidden')) { window.openHotkeysPanel(); }
    else { window.closeHotkeysPanel(); }
};
// ===== Кінець панелі гарячих клавіш =====

// ===== Скріншот карти без кнопок (P) =====
function downloadCanvasAsPng(canvas) {
    const now = new Date();
    const pad = n => String(n).padStart(2, '0');
    const filename = `screenshot_${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}_${pad(now.getHours())}-${pad(now.getMinutes())}-${pad(now.getSeconds())}.png`;
    const link = document.createElement('a');
    link.download = filename;
    link.href = canvas.toDataURL('image/png');
    link.click();
}

function waitTwoFrames() {
    return new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));
}

// Запасний варіант через html2canvas (якщо Screen Capture API недоступний)
function screenshotViaHtml2Canvas() {
    if (typeof html2canvas === 'undefined') {
        if (typeof window.showToastExternal === 'function') window.showToastExternal("Скріншот не підтримується цим браузером", true);
        return;
    }
    html2canvas(document.body, { useCORS: true, allowTaint: false, backgroundColor: null, logging: false, scale: 1 })
        .then(function(canvas) {
            downloadCanvasAsPng(canvas);
            if (typeof window.showToastExternal === 'function') window.showToastExternal("Скриншот збережено!");
        })
        .catch(function(err) {
            console.error('Помилка скріншоту:', err);
            if (typeof window.showToastExternal === 'function') window.showToastExternal("Помилка при створенні скріншоту", true);
        });
}

window.takeScreenshot = async function() {
    document.body.classList.add('capturing');
    await waitTwoFrames(); // дати браузеру реально сховати кнопки перед кадром

    const canSupportCurrentTab = navigator.mediaDevices && navigator.mediaDevices.getDisplayMedia;

    if (!canSupportCurrentTab) {
        document.body.classList.remove('capturing');
        screenshotViaHtml2Canvas();
        return;
    }

    let stream = null;
    try {
        // preferCurrentTab/selfBrowserSurface автоматично підставляють поточну вкладку в Chrome/Edge
        stream = await navigator.mediaDevices.getDisplayMedia({
            video: { cursor: "never" },
            preferCurrentTab: true,
            selfBrowserSurface: "include"
        });
    } catch (err) {
        document.body.classList.remove('capturing');
        if (typeof window.showToastExternal === 'function') window.showToastExternal("Скріншот скасовано", true);
        return;
    }

    try {
        const video = document.createElement('video');
        video.srcObject = stream;
        video.muted = true;
        await video.play();
        await new Promise(r => setTimeout(r, 150)); // дати кадру стабілізуватись

        const canvas = document.createElement('canvas');
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        canvas.getContext('2d').drawImage(video, 0, 0);

        downloadCanvasAsPng(canvas);
        if (typeof window.showToastExternal === 'function') window.showToastExternal("Скриншот збережено!");
    } catch (err) {
        console.error('Помилка скріншоту:', err);
        if (typeof window.showToastExternal === 'function') window.showToastExternal("Помилка при створенні скріншоту", true);
    } finally {
        stream.getTracks().forEach(t => t.stop());
        document.body.classList.remove('capturing');
    }
};
// ===== Кінець скріншоту =====

function toggleUI() {    
    document.getElementById('main-controls').classList.toggle('hidden');    
    ['uav-controls', 'missiles-controls', 'planes-controls', 'airdefense-controls', 'ships-controls'].forEach(id => document.getElementById(id).classList.add('hidden'));    
}    

document.addEventListener('keydown', function(event) {    
    // Не реагувати на глобальні хоткеї, якщо фокус у полі вводу
    if (event.target.tagName === 'INPUT' || event.target.tagName === 'TEXTAREA') return;

    if (event.code === 'KeyA') toggleUI();    
    if (event.code === 'KeyB') {
        if (selectedMarker) {
            openCaptionEditor(selectedMarker);
        } else {
            window.toggleCategory('uav');
        }
    }
    if (event.code === 'KeyC') window.toggleCategory('planes');    
    if (event.code === 'KeyZ') window.toggleCategory('airdefense');   
    if (event.code === 'Delete') window.clearMap();   
    if (event.code === 'KeyK') window.selectObject('custom_marker');
    if (event.code === 'KeyL') window.toggleRuler();
    if (event.code === 'KeyY') window.triggerSearch();
    if (event.code === 'KeyI') window.toggleHotkeysPanel();
    if (event.code === 'KeyP') window.takeScreenshot();

    if (event.code === 'KeyV') {
        const panel = document.getElementById('watermark-panel');
        if (!panel.classList.contains('hidden')) {
            window.closeWatermarkPanel();
        } else {
            window.openWatermarkPanel();
        }
    }

    if (event.code === 'KeyM') {
        document.getElementById('sidebar-menu').classList.toggle('hidden');
    }

    if (event.code === 'KeyN') {
        const menuPanel = document.getElementById('object-menu-panel');
        if (!menuPanel.classList.contains('hidden')) { 
            hideObjectMenu(); 
        } else if (selectedMarker) { 
            showObjectMenu(selectedMarker); 
        } else if (typeof window.showToastExternal === 'function') { 
            window.showToastExternal("Спочатку виберіть об'єкт на карті!", true); 
        }
    }

    if (event.code === 'KeyD' && selectedMarker) { 
        if (selectedMarker.associatedCircle) markersLayer.removeLayer(selectedMarker.associatedCircle); 
        if (selectedMarker.trailLine) markersLayer.removeLayer(selectedMarker.trailLine);
        markersLayer.removeLayer(selectedMarker); selectedMarker = null; rotateOnlyMode = false; moveOnlyMode = false; hideObjectMenu();
    }    
    if (event.code === 'KeyS' && event.shiftKey) {
        event.preventDefault();
        window.openStatusInput();
    } else if (event.code === 'KeyS' && selectedMarker) {
        copiedData = { type: selectedMarker.objectType, angle: selectedMarker.rotationAngle || 0, textLabel: selectedMarker.textLabel || "" };
        copyMode = true;
    }
    
    if (event.code === 'KeyO') {
        if (selectedMarker) {
            moveMode = !moveMode;
            if (typeof window.showToastExternal === 'function') window.showToastExternal(moveMode ? "Режим переміщення: Клініть на карті" : "Режим переміщення вимкнено");
        } else if (typeof window.showToastExternal === 'function') {
            window.showToastExternal("Спочатку виберіть об'єкт на карті!", true);
        }
    }

    if (event.code === 'KeyH') {
        if (selectedMarker) {
            if (objectConfig[selectedMarker.objectType].noRotate) {
                if (typeof window.showToastExternal === 'function') window.showToastExternal("Цей об'єкт не можна повертати!", true);
            } else {
                rotateOnlyMode = !rotateOnlyMode;
                moveOnlyMode = false;
                moveMode = false;
                if (typeof window.showToastExternal === 'function') window.showToastExternal(rotateOnlyMode ? "Режим повороту: клацніть на карті, куди має дивитись об'єкт" : "Режим повороту вимкнено");
            }
        } else if (typeof window.showToastExternal === 'function') {
            window.showToastExternal("Спочатку виберіть об'єкт на карті!", true);
        }
    }

    if (event.code === 'KeyR') {
        if (selectedMarker) {
            moveOnlyMode = !moveOnlyMode;
            rotateOnlyMode = false;
            moveMode = false;
            if (typeof window.showToastExternal === 'function') window.showToastExternal(moveOnlyMode ? "Режим переміщення (R): клацніть на карті, куди перемістити об'єкт" : "Режим переміщення (R) вимкнено");
        } else if (typeof window.showToastExternal === 'function') {
            window.showToastExternal("Спочатку виберіть об'єкт на карті!", true);
        }
    }
});

