# Telugu Theft Auto – Android project

This folder is a ready Capacitor project. An APK could not be compiled in the cloud sandbox (no Android SDK), so build it on your PC in ~5 minutes:

1. Install Node 18+, Android Studio (includes the SDK) and JDK 17.
2. In this folder run:
   npm install
   cp resources/icon.png resources/icon-only.png   (logo, already provided)
   npm run add
   npm run icons
   npm run sync
   npm run apk
3. The APK is at android/app/build/outputs/apk/debug/app-debug.apk. Copy to your phone and install (allow unknown sources).
   Or open the `android` folder in Android Studio -> Build -> Build APK(s).

Notes
- Landscape lock: after `npm run add`, edit android/app/src/main/AndroidManifest.xml and add android:screenOrientation="sensorLandscape" to the <activity> tag.
- The game loads three.js and the Telugu font from CDNs, so the phone needs internet on first launch.
- Logo: resources/icon.svg / icon.png (1024 px).
