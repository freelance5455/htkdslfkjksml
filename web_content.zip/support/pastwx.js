/* ECC Pro — pastwx.js
   Past-weather widget for the Toronto area (or anywhere): the last 7
   actual days — high / low / precipitation — plus the same week one year
   ago for comparison. Data from Open-Meteo (free, no API key, no account):
   the forecast endpoint provides recent past days, the archive endpoint
   the year-ago reference. Everything is cached for offline use. */
(function () {
  'use strict';

  var KEY = 'pastwx';

  function defaults() {
    return {
      loc: { name: 'Long Branch, Toronto', lat: 43.6106, lon: -79.5339 },
      days: 7,
      cache: null
    };
  }

  function load() {
    var s = window.ECCStorage.get(KEY, null);
    if (!s) return defaults();
    if (!s.loc || typeof s.loc.lat !== 'number') s.loc = defaults().loc;
    if (!s.cache || !Array.isArray(s.cache.week)) s.cache = null;
    return s;
  }

  function save(s) { window.ECCStorage.set(KEY, s); }

  function esc(t) {
    return String(t).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function iso(d) { return d.toISOString().slice(0, 10); }

  function fetchPast(quiet) {
    var s = load();
    var n = Math.min(Math.max(s.days | 0, 4), 10);
    /* recent past days from the forecast endpoint (observed history) */
    var url1 = 'https://api.open-meteo.com/v1/forecast' +
      '?latitude=' + encodeURIComponent(s.loc.lat) +
      '&longitude=' + encodeURIComponent(s.loc.lon) +
      '&daily=temperature_2m_max,temperature_2m_min,precipitation_sum' +
      '&past_days=16&forecast_days=1&timezone=auto';
    /* same calendar days one year earlier, from the ERA5 archive */
    var yesterday = new Date();
    yesterday.setHours(12, 0, 0, 0);
    yesterday.setDate(yesterday.getDate() - 1);
    var end = iso(yesterday);
    var startD = new Date(yesterday);
    startD.setDate(startD.getDate() - (n - 1));
    var start = iso(startD);
    var ly = new Date(yesterday);
    ly.setFullYear(ly.getFullYear() - 1);
    var lyEnd = iso(ly);
    var lyStartD = new Date(ly);
    lyStartD.setDate(lyStartD.getDate() - (n - 1));
    var lyStart = iso(lyStartD);
    var url2 = 'https://archive-api.open-meteo.com/v1/archive' +
      '?latitude=' + encodeURIComponent(s.loc.lat) +
      '&longitude=' + encodeURIComponent(s.loc.lon) +
      '&start_date=' + lyStart + '&end_date=' + lyEnd +
      '&daily=temperature_2m_max,temperature_2m_min,precipitation_sum&timezone=auto';

    function extract(d) {
      var out = [];
      var t = (d.daily && d.daily.time) || [];
      for (var i = 0; i < t.length; i++) {
        out.push({
          date: t[i],
          max: d.daily.temperature_2m_max ? d.daily.temperature_2m_max[i] : null,
          min: d.daily.temperature_2m_min ? d.daily.temperature_2m_min[i] : null,
          prcp: d.daily.precipitation_sum ? d.daily.precipitation_sum[i] : null
        });
      }
      return out;
    }

    var p1 = fetch(url1).then(function (r) {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.json();
    }).then(function (d) {
      if (!d || !d.daily) throw new Error('bad response');
      var all = extract(d).filter(function (x) { return x.date <= end; });
      return all.slice(-n);
    });

    var p2 = fetch(url2).then(function (r) {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.json();
    }).then(function (d) {
      if (!d || !d.daily) throw new Error('bad response');
      return extract(d);
    }).catch(function () { return null; }); /* year-ago data is optional */

    return Promise.all([p1, p2]).then(function (res) {
      var week = res[0], lastYear = res[1];
      if (!week || !week.length) throw new Error('no past data');
      s.cache = {
        fetched: Date.now(),
        end: end,
        week: week,
        lastYear: lastYear || []
      };
      save(s);
      renderAll();
      if (!quiet && window.ECCToast) window.ECCToast('Past weather updated');
      return s.cache;
    }).catch(function (e) {
      if (!quiet && window.ECCToast) {
        window.ECCToast('Past weather unavailable — showing saved data');
      }
      return null;
    });
  }

  function avg(arr, key) {
    var v = arr.filter(function (x) { return isFinite(x[key]); });
    if (!v.length) return null;
    return v.reduce(function (a, x) { return a + x[key]; }, 0) / v.length;
  }

  function sumPrcp(arr) {
    return arr.reduce(function (a, x) { return a + (isFinite(x.prcp) ? x.prcp : 0); }, 0);
  }

  function renderWidget(container) {
    container.classList.add('hw-body');
    if (container.dataset.editing === '1') return;
    var s = load();
    var c = s.cache;

    var html = '';
    if (c && c.week && c.week.length) {
      var avgMax = avg(c.week, 'max');
      var rain = sumPrcp(c.week);
      html += '<div class="hw-strip">';
      c.week.forEach(function (d) {
        var label = new Date(d.date + 'T12:00:00')
          .toLocaleDateString('en-CA', { weekday: 'short', day: 'numeric' });
        html += '<div class="hw-day"><span class="hw-name">' + label + '</span>' +
          '<span class="hw-temps mono"><b>' + Math.round(d.max) + '°</b> ' +
          '<span class="wx-min">' + Math.round(d.min) + '°</span></span>' +
          '<span class="hw-prcp">' + (isFinite(d.prcp) ? (d.prcp >= 1 ? '💧 ' + Math.round(d.prcp) + ' mm' : '· 0 mm') : '—') + '</span></div>';
      });
      html += '</div>';
      html += '<div class="hw-sum">Past ' + c.week.length + ' days: avg high <b>' +
        (avgMax !== null ? avgMax.toFixed(1) : '—') + '°C</b> · rain total <b>' +
        Math.round(rain) + ' mm</b>';
      if (c.lastYear && c.lastYear.length) {
        var lyAvg = avg(c.lastYear, 'max');
        if (lyAvg !== null && avgMax !== null) {
          var d = avgMax - lyAvg;
          html += '<br>Same week last year: avg high ' + lyAvg.toFixed(1) + '°C (' +
            (d > 0 ? '+' : '') + d.toFixed(1) + '° vs now)';
        }
      }
      html += '</div>';
      var when = new Date(c.fetched);
      html += '<div class="gt-note hw-upd">Actuals up to ' + c.end + ' · updated ' +
        when.toLocaleTimeString('en-CA', { hour: '2-digit', minute: '2-digit', hour12: false }) + '</div>';
    } else {
      html += '<div class="w-empty">No past-weather data yet.<br>Press ⟳ once when online — it is cached for offline use.</div>';
    }
    html += '<div class="gt-actions">' +
      '<button class="hw-refresh" title="Fetch the last 7 actual days (needs internet)">⟳ Refresh</button>' +
      '<button class="hw-loc" title="Change location">📍 Location</button></div>' +
      '<div class="gt-note">Actual highs / lows / rain for the Toronto area, with a same-week-last-year comparison.</div>';
    container.innerHTML = html;

    container.querySelector('.hw-refresh').addEventListener('click', function () { fetchPast(false); });
    container.querySelector('.hw-loc').addEventListener('click', function () { renderEditor(container); });

    if (!c) fetchPast(true);
  }

  function renderEditor(container) {
    var s = load();
    container.dataset.editing = '1';
    container.innerHTML =
      '<div class="st-form"><div class="st-form-grid">' +
      '<div class="gt-form-row"><label>Location name</label><input type="text" class="hwf-name" maxlength="40" value="' + esc(s.loc.name) + '"></div>' +
      '<div class="gt-form-row"><label>Days (4–10)</label><input type="number" min="4" max="10" class="hwf-days" value="' + (s.days || 7) + '"></div>' +
      '<div class="gt-form-row"><label>Latitude</label><input type="number" step="any" class="hwf-lat" value="' + s.loc.lat + '"></div>' +
      '<div class="gt-form-row"><label>Longitude</label><input type="number" step="any" class="hwf-lon" value="' + s.loc.lon + '"></div>' +
      '</div>' +
      '<div class="gt-actions"><button class="hw-save">💾 Save</button><button class="hw-cancel">Cancel</button></div>' +
      '<div class="gt-note">Long Branch ≈ 43.6106, -79.5339 · downtown Toronto ≈ 43.6532, -79.3832.</div></div>';
    container.querySelector('.hw-save').addEventListener('click', function () {
      var s2 = load();
      s2.loc = {
        name: container.querySelector('.hwf-name').value.trim() || s2.loc.name,
        lat: parseFloat(container.querySelector('.hwf-lat').value) || s2.loc.lat,
        lon: parseFloat(container.querySelector('.hwf-lon').value) || s2.loc.lon
      };
      var d = parseInt(container.querySelector('.hwf-days').value, 10);
      s2.days = Math.min(10, Math.max(4, isFinite(d) ? d : 7));
      save(s2);
      container.dataset.editing = '0';
      fetchPast(false);
    });
    container.querySelector('.hw-cancel').addEventListener('click', function () {
      container.dataset.editing = '0';
      renderWidget(container);
    });
  }

  function renderAll() {
    document.querySelectorAll('.hw-body').forEach(function (el) {
      el.dataset.editing = '0';
      renderWidget(el);
    });
  }

  window.ECCPastwx = {
    renderWidget: renderWidget,
    renderAll: renderAll,
    fetchPast: fetchPast,
    load: load
  };
})();

/* ECC Pro v1.7 — support-plugin registration. Active when this file is
   loaded from the support/ folder (the core defines ECCPlugins first);
   harmless if the module is bundled some other way. */
if (window.ECCPlugins) {
  window.ECCPlugins.register({
    id: 'pastwx', name: 'Past Weather', file: 'pastwx.js',
    icon: '🌧️', color: '#6366f1', w: 3, h: 9,
    render: function (el) { window.ECCPastwx.renderWidget(el); }
  });
}
