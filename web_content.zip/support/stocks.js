/* ECC Pro — stocks.js
   Stock watchlist / portfolio widget. Fully usable offline: enter your
   holdings (ticker, shares, cost, last price) and it computes portfolio
   value and gain/loss, saved locally. The optional "online refresh"
   button tries a configurable free quote endpoint (default: Stooq CSV)
   when you have internet — if it is offline or blocked, prices simply
   keep their last saved values. No accounts, no API keys, no tracking.

   v1.5: 🔎 search — a bundled catalog of ~135 popular TSX / US stocks
   and ETFs you can find by name or ticker, fully offline (online ticker
   search APIs such as Yahoo's are blocked for local pages by CORS, so
   the catalog ships with the app). ⚡ live — per-holding auto-refresh
   every 60 s while online. */

(function () {
  'use strict';

  var KEY = 'stocks';
  var DEFAULT_ENDPOINT = 'https://stooq.com/q/l/?s={t}&f=sd2t2ohlcv&h&e=csv';

  /* ---------- Bundled symbol catalog (offline search) ----------
     [stooq symbol, company / fund name, exchange] */
  var CATALOG = [
    ['RY.TO', 'Royal Bank of Canada', 'TSX'],
    ['TD.TO', 'Toronto-Dominion Bank', 'TSX'],
    ['BNS.TO', 'Bank of Nova Scotia', 'TSX'],
    ['BMO.TO', 'Bank of Montreal', 'TSX'],
    ['CM.TO', 'CIBC (Canadian Imperial Bank of Commerce)', 'TSX'],
    ['NA.TO', 'National Bank of Canada', 'TSX'],
    ['BN.TO', 'Brookfield Corporation', 'TSX'],
    ['BAM.TO', 'Brookfield Asset Management', 'TSX'],
    ['CNR.TO', 'Canadian National Railway', 'TSX'],
    ['CP.TO', 'Canadian Pacific Kansas City', 'TSX'],
    ['ENB.TO', 'Enbridge', 'TSX'],
    ['TRP.TO', 'TC Energy', 'TSX'],
    ['SU.TO', 'Suncor Energy', 'TSX'],
    ['CNQ.TO', 'Canadian Natural Resources', 'TSX'],
    ['CVE.TO', 'Cenovus Energy', 'TSX'],
    ['IMO.TO', 'Imperial Oil', 'TSX'],
    ['ARX.TO', 'ARC Resources', 'TSX'],
    ['TOU.TO', 'Tourmaline Oil', 'TSX'],
    ['OVV.TO', 'Ovintiv', 'TSX'],
    ['FTS.TO', 'Fortis', 'TSX'],
    ['EMA.TO', 'Emera', 'TSX'],
    ['H.TO', 'Hydro One', 'TSX'],
    ['CU.TO', 'Canadian Utilities', 'TSX'],
    ['NTR.TO', 'Nutrien', 'TSX'],
    ['CCO.TO', 'Cameco', 'TSX'],
    ['FM.TO', 'First Quantum Minerals', 'TSX'],
    ['LUN.TO', 'Lundin Mining', 'TSX'],
    ['IVN.TO', 'Ivanhoe Mines', 'TSX'],
    ['K.TO', 'Kinross Gold', 'TSX'],
    ['AB.TO', 'Barrick Mining', 'TSX'],
    ['AEM.TO', 'Agnico Eagle Mines', 'TSX'],
    ['WPM.TO', 'Wheaton Precious Metals', 'TSX'],
    ['FNV.TO', 'Franco-Nevada', 'TSX'],
    ['OR.TO', 'Osisko Gold Royalties', 'TSX'],
    ['MFC.TO', 'Manulife Financial', 'TSX'],
    ['SLF.TO', 'Sun Life Financial', 'TSX'],
    ['GWO.TO', 'Great-West Lifeco', 'TSX'],
    ['IFC.TO', 'Intact Financial', 'TSX'],
    ['FFH.TO', 'Fairfax Financial', 'TSX'],
    ['POW.TO', 'Power Corporation of Canada', 'TSX'],
    ['TRI.TO', 'Thomson Reuters', 'TSX'],
    ['BCE.TO', 'BCE (Bell Canada)', 'TSX'],
    ['T.TO', 'TELUS', 'TSX'],
    ['ATD.TO', 'Alimentation Couche-Tard', 'TSX'],
    ['L.TO', 'Loblaw Companies', 'TSX'],
    ['MRU.TO', 'Metro', 'TSX'],
    ['WN.TO', 'George Weston', 'TSX'],
    ['QSR.TO', 'Restaurant Brands International', 'TSX'],
    ['WCN.TO', 'Waste Connections', 'TSX'],
    ['AC.TO', 'Air Canada', 'TSX'],
    ['CAE.TO', 'CAE', 'TSX'],
    ['CSU.TO', 'Constellation Software', 'TSX'],
    ['SHOP.TO', 'Shopify', 'TSX'],
    ['OTEX.TO', 'Open Text', 'TSX'],
    ['DSG.TO', 'Descartes Systems Group', 'TSX'],
    ['KXS.TO', 'Kinaxis', 'TSX'],
    ['BHC.TO', 'Bausch Health', 'TSX'],
    ['XIU.TO', 'iShares S&P/TSX 60 Index ETF', 'ETF'],
    ['XIC.TO', 'iShares Core S&P/TSX Capped Composite ETF', 'ETF'],
    ['ZSP.TO', 'BMO S&P 500 Index ETF (CAD)', 'ETF'],
    ['VDY.TO', 'Vanguard Canadian High Dividend ETF', 'ETF'],
    ['VEQT.TO', 'Vanguard All-Equity ETF Portfolio', 'ETF'],
    ['XEQT.TO', 'iShares Core Equity ETF Portfolio', 'ETF'],
    ['VUS.TO', 'Vanguard U.S. Total Market Index ETF (CAD)', 'ETF'],
    ['AAPL.US', 'Apple', 'NASDAQ'],
    ['MSFT.US', 'Microsoft', 'NASDAQ'],
    ['GOOGL.US', 'Alphabet (Class A)', 'NASDAQ'],
    ['AMZN.US', 'Amazon', 'NASDAQ'],
    ['META.US', 'Meta Platforms', 'NASDAQ'],
    ['NVDA.US', 'NVIDIA', 'NASDAQ'],
    ['TSLA.US', 'Tesla', 'NASDAQ'],
    ['AVGO.US', 'Broadcom', 'NASDAQ'],
    ['AMD.US', 'AMD', 'NASDAQ'],
    ['INTC.US', 'Intel', 'NASDAQ'],
    ['MU.US', 'Micron Technology', 'NASDAQ'],
    ['QCOM.US', 'Qualcomm', 'NASDAQ'],
    ['TXN.US', 'Texas Instruments', 'NASDAQ'],
    ['IBM.US', 'IBM', 'NYSE'],
    ['ORCL.US', 'Oracle', 'NYSE'],
    ['CRM.US', 'Salesforce', 'NYSE'],
    ['ADBE.US', 'Adobe', 'NASDAQ'],
    ['NOW.US', 'ServiceNow', 'NYSE'],
    ['CSCO.US', 'Cisco', 'NASDAQ'],
    ['PLTR.US', 'Palantir', 'NASDAQ'],
    ['UBER.US', 'Uber', 'NYSE'],
    ['ABNB.US', 'Airbnb', 'NASDAQ'],
    ['NFLX.US', 'Netflix', 'NASDAQ'],
    ['DIS.US', 'Walt Disney', 'NYSE'],
    ['CMCSA.US', 'Comcast', 'NASDAQ'],
    ['WMT.US', 'Walmart', 'NYSE'],
    ['COST.US', 'Costco', 'NASDAQ'],
    ['TGT.US', 'Target', 'NYSE'],
    ['HD.US', 'Home Depot', 'NYSE'],
    ['LOW.US', "Lowe's", 'NYSE'],
    ['MCD.US', "McDonald's", 'NYSE'],
    ['SBUX.US', 'Starbucks', 'NASDAQ'],
    ['NKE.US', 'Nike', 'NYSE'],
    ['PG.US', 'Procter & Gamble', 'NYSE'],
    ['KO.US', 'Coca-Cola', 'NYSE'],
    ['PEP.US', 'PepsiCo', 'NASDAQ'],
    ['JNJ.US', 'Johnson & Johnson', 'NYSE'],
    ['PFE.US', 'Pfizer', 'NYSE'],
    ['MRK.US', 'Merck', 'NYSE'],
    ['LLY.US', 'Eli Lilly', 'NYSE'],
    ['UNH.US', 'UnitedHealth', 'NYSE'],
    ['ABBV.US', 'AbbVie', 'NYSE'],
    ['ABT.US', 'Abbott Laboratories', 'NYSE'],
    ['TMO.US', 'Thermo Fisher Scientific', 'NYSE'],
    ['MDT.US', 'Medtronic', 'NYSE'],
    ['V.US', 'Visa', 'NYSE'],
    ['MA.US', 'Mastercard', 'NYSE'],
    ['PYPL.US', 'PayPal', 'NASDAQ'],
    ['JPM.US', 'JPMorgan Chase', 'NYSE'],
    ['BAC.US', 'Bank of America', 'NYSE'],
    ['WFC.US', 'Wells Fargo', 'NYSE'],
    ['C.US', 'Citigroup', 'NYSE'],
    ['GS.US', 'Goldman Sachs', 'NYSE'],
    ['MS.US', 'Morgan Stanley', 'NYSE'],
    ['BRK-B.US', 'Berkshire Hathaway (Class B)', 'NYSE'],
    ['XOM.US', 'Exxon Mobil', 'NYSE'],
    ['CVX.US', 'Chevron', 'NYSE'],
    ['COP.US', 'ConocoPhillips', 'NYSE'],
    ['OXY.US', 'Occidental Petroleum', 'NYSE'],
    ['SLB.US', 'SLB (Schlumberger)', 'NYSE'],
    ['NEM.US', 'Newmont', 'NYSE'],
    ['FCX.US', 'Freeport-McMoRan', 'NYSE'],
    ['DOW.US', 'Dow', 'NYSE'],
    ['GE.US', 'GE Aerospace', 'NYSE'],
    ['BA.US', 'Boeing', 'NYSE'],
    ['CAT.US', 'Caterpillar', 'NYSE'],
    ['DE.US', 'Deere & Co', 'NYSE'],
    ['HON.US', 'Honeywell', 'NASDAQ'],
    ['MMM.US', '3M', 'NYSE'],
    ['EMR.US', 'Emerson Electric', 'NYSE'],
    ['ETN.US', 'Eaton', 'NYSE'],
    ['LMT.US', 'Lockheed Martin', 'NYSE'],
    ['RTX.US', 'RTX (Raytheon)', 'NYSE'],
    ['F.US', 'Ford', 'NYSE'],
    ['GM.US', 'General Motors', 'NYSE'],
    ['UPS.US', 'United Parcel Service', 'NYSE'],
    ['DAL.US', 'Delta Air Lines', 'NYSE'],
    ['T.US', 'AT&T', 'NYSE'],
    ['VZ.US', 'Verizon', 'NYSE'],
    ['SPY.US', 'SPDR S&P 500 ETF Trust', 'ETF'],
    ['QQQ.US', 'Invesco QQQ (Nasdaq-100 ETF)', 'ETF'],
    ['VOO.US', 'Vanguard S&P 500 ETF', 'ETF'],
    ['VTI.US', 'Vanguard Total Stock Market ETF', 'ETF'],
    ['DIA.US', 'SPDR Dow Jones Industrial Average ETF', 'ETF'],
    ['IWM.US', 'iShares Russell 2000 ETF', 'ETF'],
    ['EEM.US', 'iShares MSCI Emerging Markets ETF', 'ETF'],
    ['GLD.US', 'SPDR Gold Shares', 'ETF'],
    ['SLV.US', 'iShares Silver Trust', 'ETF']
  ];

  function searchCatalog(q) {
    q = String(q || '').trim().toLowerCase();
    if (!q) return [];
    var starts = [], within = [];
    CATALOG.forEach(function (e) {
      var t = e[0].toLowerCase(), n = e[1].toLowerCase(), x = (e[2] || '').toLowerCase();
      if (t.indexOf(q) === 0 || n.indexOf(q) === 0 || x === q) starts.push(e);
      else if (t.indexOf(q) >= 0 || n.indexOf(q) >= 0) within.push(e);
    });
    return starts.concat(within).slice(0, 8);
  }

  function defaults() {
    return { holdings: [], endpoint: DEFAULT_ENDPOINT };
  }

  function load() {
    var s = window.ECCStorage.get(KEY, null);
    if (!s) s = defaults();
    if (!Array.isArray(s.holdings)) s.holdings = [];
    if (typeof s.endpoint !== 'string' || !s.endpoint) s.endpoint = DEFAULT_ENDPOINT;
    s.holdings = s.holdings.map(function (h) {
      return {
        id: h.id || window.ECCWidgets.uid('h'),
        ticker: h.ticker || '',
        name: h.name || '',
        shares: Number(h.shares) || 0,
        cost: Number(h.cost) || 0,
        price: Number(h.price) || 0,
        live: !!h.live
      };
    });
    if (!Array.isArray(s.hist)) s.hist = [];
    s.hist = s.hist.filter(function (p) { return p && isFinite(p.d) && isFinite(p.v); }).slice(-90);
    return s;
  }

  function save(s) { window.ECCStorage.set(KEY, s); }

  function esc(t) {
    return String(t).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function money(n) {
    if (!isFinite(n)) return '—';
    var sign = n < 0 ? '-' : '';
    return sign + '$' + Math.abs(n).toLocaleString('en-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }

  function pct(n) {
    if (!isFinite(n)) return '—';
    return (n >= 0 ? '+' : '') + n.toFixed(1) + '%';
  }

  function anyLive(s) {
    return s.holdings.some(function (h) { return h.live && h.ticker; });
  }

  /* ---------- portfolio value history (v1.6) ---------- */
  function pushHistory(s) {
    var total = s.holdings.reduce(function (a, h) { return a + h.shares * h.price; }, 0);
    if (!isFinite(total) || total <= 0) return;
    var d = new Date();
    d.setHours(0, 0, 0, 0);
    var key = d.getTime();
    var last = s.hist[s.hist.length - 1];
    if (last && last.d === key) last.v = Math.round(total * 100) / 100;
    else s.hist.push({ d: key, v: Math.round(total * 100) / 100 });
    if (s.hist.length > 90) s.hist = s.hist.slice(-90);
  }

  function sparkline(hist) {
    var W = 220, H = 34, pad = 3;
    var vals = hist.map(function (p) { return p.v; });
    var min = Math.min.apply(null, vals), max = Math.max.apply(null, vals);
    if (min === max) { min -= 1; max += 1; }
    var pts = hist.map(function (p, i) {
      var x = pad + (i / (hist.length - 1)) * (W - 2 * pad);
      var y = pad + (1 - (p.v - min) / (max - min)) * (H - 2 * pad);
      return x.toFixed(1) + ',' + y.toFixed(1);
    }).join(' ');
    var up = vals[vals.length - 1] >= vals[0];
    var col = up ? 'var(--ok)' : 'var(--danger)';
    var days = Math.max(1, Math.round((hist[hist.length - 1].d - hist[0].d) / 86400000));
    return '<div class="st-sparkwrap"><svg class="st-spark" viewBox="0 0 ' + W + ' ' + H +
      '" preserveAspectRatio="none"><polyline fill="none" stroke="' + col +
      '" stroke-width="1.6" points="' + pts + '"/></svg><span class="st-sparknote mono">' +
      (hist.length > 1 ? days + '-day value trend' : 'value trend starts…') + '</span></div>';
  }

  /* ---------- live auto-refresh (60 s, only while online) ---------- */
  function stopLiveTimer(container) {
    if (container._stLive) { clearInterval(container._stLive); container._stLive = null; }
  }
  function startLiveTimer(container) {
    stopLiveTimer(container);
    container._stLive = setInterval(function () {
      if (!container.isConnected) { stopLiveTimer(container); return; }
      if (container.dataset.editing === '1') return;
      if (typeof navigator.onLine === 'boolean' && !navigator.onLine) return;
      var s = load();
      if (!anyLive(s)) return;
      refreshOnline(container, { onlyLive: true, quiet: true });
    }, 60000);
  }

  function renderWidget(container) {
    container.classList.add('st-body');
    if (container.dataset.editing === '1') return;
    stopLiveTimer(container);
    var s = load();
    var html = '';

    if (!s.holdings.length) {
      html += '<div class="w-empty">No holdings yet.<br>Use 🔎 search below to find a stock — works fully offline.</div>';
    } else {
      var totV = 0, totC = 0;
      html += '<table class="st-table"><thead><tr>' +
        '<th>Ticker</th><th class="st-num">Shares</th><th class="st-num">Price</th>' +
        '<th class="st-num">Value</th><th class="st-num">±</th><th></th></tr></thead><tbody>';
      s.holdings.forEach(function (h) {
        var value = h.shares * h.price;
        var basis = h.shares * h.cost;
        var gain = value - basis;
        var gpct = basis > 0 ? (gain / basis) * 100 : 0;
        totV += value;
        totC += basis;
        var cls = gain > 0 ? 'pos' : gain < 0 ? 'neg' : '';
        html += '<tr class="st-row" data-id="' + esc(h.id) + '">' +
          '<td class="st-tick" title="' + esc(h.name) + '">' + esc(h.ticker || '—') +
          (h.live ? '<span class="st-livepill" title="Live — auto-refreshes every 60 s while online">⚡</span>' : '') + '</td>' +
          '<td class="st-num">' + h.shares.toLocaleString() + '</td>' +
          '<td class="st-num mono">' + (h.price ? h.price.toFixed(2) : '—') + '</td>' +
          '<td class="st-num mono">' + (h.price ? money(value) : '—') + '</td>' +
          '<td class="st-num st-gain ' + cls + ' mono">' + (h.price ? money(gain) + ' ' + pct(gpct) : '—') + '</td>' +
          '<td class="st-mini">' +
          '<button class="st-live' + (h.live ? ' on' : '') + '" title="' +
          (h.live ? 'Live on — auto-refresh every 60 s while online. Click to turn off' : 'Turn on live — auto-refresh every 60 s while online') + '">⚡</button>' +
          '<button class="st-edit" title="Edit">✎</button>' +
          '<button class="st-del" title="Remove">✕</button></td></tr>';
      });
      var totGain = totV - totC;
      var totPct = totC > 0 ? (totGain / totC) * 100 : 0;
      html += '<tr class="st-total"><td>Total</td><td></td><td></td>' +
        '<td class="st-num mono">' + money(totV) + '</td>' +
        '<td class="st-num st-gain ' + (totGain >= 0 ? 'pos' : 'neg') + ' mono">' + money(totGain) + ' ' + pct(totPct) + '</td><td></td></tr>';
      html += '</tbody></table>';
      if (s.hist.length >= 2) html += sparkline(s.hist);
      if (s.updated) {
        var d = new Date(s.updated);
        html += '<div class="gt-note st-upd">Prices as of ' +
          d.toLocaleTimeString('en-CA', { hour: '2-digit', minute: '2-digit' }) +
          (d.toDateString() === new Date().toDateString() ? '' :
            ' · ' + d.toLocaleDateString('en-CA', { month: 'short', day: 'numeric' })) +
          (anyLive(s) ? ' · <span class="st-livenote">⚡ live every 60 s while online</span>' : '') + '</div>';
      }
    }

    html += '<div class="st-actions">' +
      '<div class="st-wrap">' +
      '<input type="text" class="st-search" maxlength="60" placeholder="🔎 Search stocks & ETFs — e.g. Brookfield, NVDA, gold" autocomplete="off">' +
      '<div class="st-results" hidden></div></div>' +
      '<button class="st-add">＋ Add</button>' +
      '<button class="st-refresh" title="Fetch the latest prices online">⟳ Refresh prices</button>' +
      '</div>';
    container.innerHTML = html;

    container.querySelector('.st-add').addEventListener('click', function () {
      renderEditor(container, null);
    });
    container.querySelectorAll('.st-edit').forEach(function (b) {
      b.addEventListener('click', function () {
        var id = b.closest('tr.st-row').dataset.id;
        renderEditor(container, id);
      });
    });
    container.querySelectorAll('.st-del').forEach(function (b) {
      b.addEventListener('click', function () {
        var s2 = load();
        var id = b.closest('tr.st-row').dataset.id;
        s2.holdings = s2.holdings.filter(function (h) { return h.id !== id; });
        save(s2);
        renderWidget(container);
        if (window.ECCToast) window.ECCToast('Holding removed');
      });
    });
    container.querySelectorAll('.st-live').forEach(function (b) {
      b.addEventListener('click', function () {
        var s2 = load();
        var id = b.closest('tr.st-row').dataset.id;
        s2.holdings.forEach(function (h) {
          if (h.id === id) h.live = !h.live;
        });
        save(s2);
        renderWidget(container);
        if (window.ECCToast) {
          var h2 = s2.holdings.filter(function (x) { return x.id === id; })[0];
          window.ECCToast(h2 && h2.live ? '⚡ Live on — ' + h2.ticker + ' refreshes every 60 s while online' : 'Live off — refresh manually with ⟳');
        }
      });
    });
    container.querySelector('.st-refresh').addEventListener('click', function () {
      refreshOnline(container);
    });
    wireSearch(container);

    if (anyLive(s)) startLiveTimer(container);
  }

  /* ---------- offline catalog search ---------- */
  function wireSearch(container) {
    var input = container.querySelector('.st-search');
    var box = container.querySelector('.st-results');
    if (!input || !box) return;
    var hide = function () { box.hidden = true; };
    var onDoc = function (e) {
      if (!container.contains(e.target)) hide();
    };
    document.addEventListener('click', onDoc);
    if (container._stSearchDoc) document.removeEventListener('click', container._stSearchDoc);
    container._stSearchDoc = onDoc;

    input.addEventListener('input', function () {
      var q = input.value;
      var res = searchCatalog(q);
      if (!q.trim() || !res.length) { hide(); return; }
      box.innerHTML = res.map(function (e, i) {
        return '<button type="button" class="st-res" data-i="' + i + '">' +
          '<span class="st-res-sym mono">' + esc(e[0]) + '</span>' +
          '<span class="st-res-name">' + esc(e[1]) + '</span>' +
          '<span class="st-res-ex">' + esc(e[2]) + '</span></button>';
      }).join('');
      box.hidden = false;
      box.querySelectorAll('.st-res').forEach(function (b) {
        b.addEventListener('click', function () {
          var e = res[Number(b.dataset.i)];
          hide();
          input.value = '';
          renderEditor(container, null, { ticker: e[0], name: e[1], live: true });
        });
      });
    });
    input.addEventListener('keydown', function (ev) {
      if (ev.key === 'Escape') hide();
    });
  }

  function renderEditor(container, editId, prefill) {
    var s = load();
    var h = editId ? s.holdings.filter(function (x) { return x.id === editId; })[0] : null;
    var f = h || prefill || {};
    container.dataset.editing = '1';
    stopLiveTimer(container);
    container.innerHTML =
      '<div class="st-form">' +
      '<div class="st-form-grid">' +
      '<div class="gt-form-row"><label>Ticker</label><input type="text" class="stf-ticker" maxlength="12" placeholder="e.g. BN.TO / AAPL.US" value="' + esc(f.ticker || '') + '"></div>' +
      '<div class="gt-form-row"><label>Name</label><input type="text" class="stf-name" maxlength="40" placeholder="Company or fund" value="' + esc(f.name || '') + '"></div>' +
      '<div class="gt-form-row"><label>Shares</label><input type="number" class="stf-shares" step="any" min="0" placeholder="10" value="' + (h ? h.shares : '') + '"></div>' +
      '<div class="gt-form-row"><label>Avg cost / share</label><input type="number" class="stf-cost" step="any" min="0" placeholder="0.00" value="' + (h ? h.cost : '') + '"></div>' +
      '<div class="gt-form-row"><label>Last price</label><input type="number" class="stf-price" step="any" min="0" placeholder="0.00" value="' + (h ? h.price : '') + '"></div>' +
      '</div>' +
      '<div class="gt-form-row"><label><input type="checkbox" class="stf-live"' + (f.live ? ' checked' : '') + '> ⚡ Live — auto-refresh this price every 60 s while online</label></div>' +
      '<div class="gt-actions"><button class="st-save">💾 Save</button><button class="st-cancel">Cancel</button></div>' +
      '<div class="gt-note">Offline: type the price yourself anytime. "⟳ Refresh prices" fills it automatically when internet is available. ⚡ live holdings refresh by themselves.</div>' +
      '</div>';
    container.querySelector('.st-save').addEventListener('click', function () {
      var s2 = load();
      var rec = {
        ticker: container.querySelector('.stf-ticker').value.trim().toUpperCase(),
        name: container.querySelector('.stf-name').value.trim(),
        shares: parseFloat(container.querySelector('.stf-shares').value) || 0,
        cost: parseFloat(container.querySelector('.stf-cost').value) || 0,
        price: parseFloat(container.querySelector('.stf-price').value) || 0,
        live: !!container.querySelector('.stf-live').checked
      };
      if (!rec.ticker) return;
      if (editId) {
        s2.holdings = s2.holdings.map(function (x) {
          return x.id === editId ? Object.assign({ id: x.id }, rec) : x;
        });
      } else {
        rec.id = window.ECCWidgets.uid('h');
        s2.holdings.push(rec);
      }
      save(s2);
      container.dataset.editing = '0';
      renderWidget(container);
      if (window.ECCToast) window.ECCToast('Holding saved');
    });
    container.querySelector('.st-cancel').addEventListener('click', function () {
      container.dataset.editing = '0';
      renderWidget(container);
    });
  }

  /* Optional online refresh. Default endpoint is Stooq's free CSV
     (comma-separated tickers, Close = last price). Fails gracefully when
     offline or if the endpoint blocks the request. opts.onlyLive refreshes
     only ⚡ live holdings (used by the 60 s auto-poll); opts.quiet skips
     the success toast. */
  function refreshOnline(container, opts) {
    opts = opts || {};
    var s = load();
    var pool = s.holdings.filter(function (h) {
      return h.ticker && (!opts.onlyLive || h.live);
    });
    if (!pool.length) {
      if (!opts.quiet && window.ECCToast) window.ECCToast('Add a holding first');
      return;
    }
    var btn = container.querySelector('.st-refresh');
    if (btn) btn.textContent = '⟳ …';
    var url = s.endpoint.replace('{t}', encodeURIComponent(pool.map(function (h) { return h.ticker; }).join(',')));
    fetch(url)
      .then(function (r) {
        if (!r.ok) throw new Error('HTTP ' + r.status);
        return r.text();
      })
      .then(function (csv) {
        var lines = csv.trim().split(/\r?\n/);
        if (lines.length < 2) throw new Error('empty response');
        var updated = 0;
        lines.slice(1).forEach(function (line) {
          var c = line.split(',');
          if (c.length < 7) return;
          var sym = (c[0] || '').toUpperCase();
          var close = parseFloat(c[6]);
          if (!isFinite(close)) return;
          s.holdings.forEach(function (h) {
            if (h.ticker.toUpperCase() === sym) { h.price = close; updated++; }
          });
        });
        if (!updated) throw new Error('no matching tickers — check ticker format (e.g. AAPL.US)');
        s.updated = new Date().toISOString();
        pushHistory(s);
        save(s);
        container.dataset.editing = '0';
        renderWidget(container);
        if (!opts.quiet && window.ECCToast) window.ECCToast('Updated ' + updated + ' price(s) online');
      })
      .catch(function (e) {
        if (btn) btn.textContent = '⟳ Refresh prices';
        if (!opts.quiet && window.ECCToast) window.ECCToast('Online refresh unavailable — enter prices manually (' + e.message + ')');
      });
  }

  window.ECCStocks = {
    load: load,
    renderWidget: renderWidget
  };
})();

/* ECC Pro v1.7 — support-plugin registration. Active when this file is
   loaded from the support/ folder (the core defines ECCPlugins first);
   harmless if the module is bundled some other way. */
if (window.ECCPlugins) {
  window.ECCPlugins.register({
    id: 'stocks', name: 'Stocks', file: 'stocks.js',
    icon: '💹', color: '#14b8a6', w: 3, h: 9,
    render: function (el) { window.ECCStocks.renderWidget(el); }
  });
}
