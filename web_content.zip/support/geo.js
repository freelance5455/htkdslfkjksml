/* ECC Pro — geo.js
   Geotechnical Monitoring Reference — offline quick-reference tables for
   instrumentation engineers: sensor types, typical measurement ranges,
   output signals, wiring conventions and standards. Search filters every
   row. Typical values gathered from major manufacturer datasheets
   (Geokon, RST, Soil Instruments, Roctest class equipment) — always
   confirm against the project spec and sensor calibration sheet. */
(function () {
  'use strict';

  /* [instrument, measures, typical range, output signal, notes] */
  var INSTRUMENTS = [
    ['Vibrating-wire piezometer', 'Pore water pressure', '70–6895 kPa (350 / 700 / 1700 kPa common; sealed ≥350 kPa also read −100 kPa)', 'VW frequency — digits = f²/1000', 'Barometric correction for unvented gauges; surge arrestors standard; 3 kΩ thermistor built in'],
    ['Standpipe / observation well', 'Groundwater level', 'Water-level tape 30–150 m; accuracy ≈ 5–10 mm', 'Graduated dipmeter (conductivity beep)', 'Simplest GW monitoring; slug tests possible'],
    ['Traversing inclinometer probe', 'Lateral ground movement', '±10° to ±30° over 500 mm gauge length; casing to 100+ m', 'Servo-accelerometer or MEMS (analogue / RS-232)', 'Read at 0.5 m intervals, A0 then A180; casing 70 mm OD with 4 orthogonal grooves; cable graduated every 0.5 m'],
    ['In-place inclinometer (IPI)', 'Continuous lateral movement', '±10° (MEMS), chain nodes 1–2 m', '4–20 mA or VW', 'Automated / real-time arrays over active slip zones'],
    ['Rod / borehole extensometer (MPBX)', 'Rock & soil settlement / heave', '25 / 50 / 100 mm travel; rods 1–100 m', 'LVDT or VW displacement', '1–8 anchors per borehole; BH Ø 50–200 mm; stainless or fibreglass rods'],
    ['Magnetic extensometer', 'Soil settlement profile vs depth', 'Reed-switch probe; magnets on 1–3 m centres; to 100 m', 'Probe count on mm-graduated tape', 'Multi-point settlement under fills / embankments'],
    ['Vibrating-wire strain gauge', 'Strain in concrete / steel', '≈3000 µε (extended-range versions available)', 'VW — readout in µε', 'Embedment or weldable; temperature compensation needed'],
    ['Vibrating-wire load cell', 'Load in anchors / tiebacks', '50–2000 kN typical capacities', 'VW + thermistor', 'Calibration sheet in kN; avoid eccentric loading'],
    ['Total pressure cell', 'Total stress in soil / at contacts', '0.35–5 MPa typical', 'VW', 'Concrete–soil contact; installation stress correction'],
    ['Hydraulic settlement cell', 'Settlement at depth', 'Tubing runs to 100+ m', 'VW / differential pressure', 'Needs surveyed reference elevation; twin-tube liquid-filled'],
    ['TDR coaxial cable', 'Shear / deformation localization', 'Cable runs tens–hundreds of m', 'Time-domain reflectometry', 'Locates the depth of an active shear zone'],
    ['Surface tiltmeter (MEMS)', 'Rotation of walls / structures', '±5° to ±10°, resolution 0.001–0.01°', '4–20 mA / VW / RS-485', 'Retaining walls, bridges, historical structures'],
    ['Crack / joint meter', 'Joint & crack movement', '10–100 mm', 'VW or LVDT', 'Across construction joints & monitor cracks'],
    ['Thermistor string', 'Ground / structure temperature', '−30 to +60 °C', '3 kΩ NTC (±0.5 °C; 0.1 °C readout resolution)', 'Standard add-on in VW instruments (green/white leads)'],
    ['VW datalogger / node', 'Automated acquisition', 'VW sweep excitation, 12 V battery + solar panel', 'Hz, digits, µε, °C', 'CR1000-class loggers with multiplexers; remote download'],
    ['Tipping-bucket rain gauge', 'Precipitation', '0.2–0.5 mm per tip', 'Reed-switch pulse', 'Correlate rainfall with GW & pore-pressure response']
  ];

  /* [topic, typical value] */
  var SIGNALS = [
    ['VW reading conventions', 'Hz · period (µs) · digits (Geokon digits = f²/1000) · µε — match the readout convention across datasets'],
    ['Thermistor standard', '3 kΩ NTC @ 25 °C (Geokon green/white leads); readouts display °C directly'],
    ['4–20 mA loop', 'Supply 12–24 VDC; 4 mA = zero, 20 mA = full scale; max loop R = (Vsupply − Vmin) / 0.02 A'],
    ['Cable types', '4-conductor shielded geotechnical cable; flooded for buried runs; splice kits with heat-shrink + resin'],
    ['Cable length effects', 'VW frequency signals are immune to cable resistance & moisture — ideal for long wet runs; resistive signals need correction'],
    ['Surge protection', 'Tripolar plasma surge arrestors standard on VW coils against lightning'],
    ['Inclinometer survey runs', '0.5 m intervals, A0 (up) + A180 (down) passes; compare against baseline & checksum sums'],
    ['VW pluck reading', 'Coils excite the wire and read resonant frequency — take readings under identical conditions & temperature-correct']
  ];

  /* [standard, covers] */
  var STANDARDS = [
    ['ISO 18674-1', 'Geotechnical monitoring by ground instrumentation — extensometers'],
    ['ISO 18674-2', 'Inclinometers'],
    ['ISO 18674-3', 'Load cells'],
    ['ISO 18674-4', 'Piezometers'],
    ['Project specs', 'Always confirm ranges, accuracy class and readout convention against the project instrumentation spec & each sensor calibration sheet']
  ];

  function esc(t) {
    return String(t).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function table(rows, heads, q) {
    var body = '';
    var shown = 0;
    rows.forEach(function (r) {
      if (q && r.join(' ').toLowerCase().indexOf(q) < 0) return;
      shown++;
      body += '<tr>';
      r.forEach(function (c) { body += '<td>' + esc(c) + '</td>'; });
      body += '</tr>';
    });
    if (!shown) return '';
    return '<table class="geo-table"><thead><tr>' +
      heads.map(function (h) { return '<th>' + esc(h) + '</th>'; }).join('') +
      '</tr></thead><tbody>' + body + '</tbody></table>';
  }

  function renderWidget(container) {
    container.classList.add('geo-body');
    var html =
      '<div class="geo-searchwrap"><input type="text" class="geo-search" maxlength="60" placeholder="🔎 Filter — e.g. piezometer, 4–20, inclinometer, kPa" autocomplete="off"></div>' +
      '<div class="geo-scroll">' +
      '<div class="geo-sec">🛠 Instruments</div>' +
      '<div class="geo-inst"></div>' +
      '<div class="geo-sec">⚡ Signals &amp; wiring</div>' +
      '<div class="geo-sig"></div>' +
      '<div class="geo-sec">📐 Standards &amp; practice</div>' +
      '<div class="geo-std"></div>' +
      '<div class="gt-note">Typical manufacturer ranges — always confirm against the project spec and each sensor\'s calibration sheet. 100% offline.</div>' +
      '</div>';
    container.innerHTML = html;

    var q = '';
    function apply() {
      var lq = q.trim().toLowerCase();
      container.querySelector('.geo-inst').innerHTML = table(INSTRUMENTS, ['Instrument', 'Measures', 'Typical range', 'Output', 'Notes'], lq);
      container.querySelector('.geo-sig').innerHTML = table(SIGNALS, ['Topic', 'Typical value'], lq);
      container.querySelector('.geo-std').innerHTML = table(STANDARDS, ['Standard', 'Covers'], lq);
      container.querySelectorAll('.geo-sec').forEach(function (s) {
        var has = s.nextElementSibling && s.nextElementSibling.innerHTML.trim();
        s.style.display = has ? '' : 'none';
      });
    }
    container.querySelector('.geo-search').addEventListener('input', function () {
      q = this.value;
      apply();
    });
    apply();
  }

  function renderAll() {
    document.querySelectorAll('.geo-body').forEach(function (el) { renderWidget(el); });
  }

  window.ECCGeo = {
    renderWidget: renderWidget,
    renderAll: renderAll
  };
})();

/* ECC Pro v1.7 — support-plugin registration. Active when this file is
   loaded from the support/ folder (the core defines ECCPlugins first);
   harmless if the module is bundled some other way. */
if (window.ECCPlugins) {
  window.ECCPlugins.register({
    id: 'geo', name: 'Geo Monitoring Reference', file: 'geo.js',
    icon: '📐', color: '#0ea5e9', w: 4, h: 9,
    render: function (el) { window.ECCGeo.renderWidget(el); }
  });
}
