/* ECC Pro — phrases.js
   Phrase of the Day — Croatian 🇭🇷 and Spanish 🇪🇸, with English
   translations. One phrase per language per day, the same on the PC and
   the phone (anchored to the calendar date). Optional pronunciation via
   the browser's built-in speech (works offline on most systems). */
(function () {
  'use strict';

  var KEY = 'phrases';

  var HR = [
    ['Dobar dan', 'Good day'],
    ['Dobro jutro', 'Good morning'],
    ['Dobra večer', 'Good evening'],
    ['Laku noć', 'Good night'],
    ['Kako ste?', 'How are you? (formal)'],
    ['Hvala lijepa', 'Thank you kindly'],
    ['Nema na čemu', "You're welcome (lit. 'nothing to it')"],
    ['Molim vas', "Please / You're welcome (formal)"],
    ['Izvolite', 'Here you go / After you'],
    ['Oprostite', 'Excuse me / Sorry (formal)'],
    ['Drago mi je', 'Nice to meet you / I am glad'],
    ['Kako se zoveš?', 'What is your name?'],
    ['Zovem se Kresimir', 'My name is Kresimir'],
    ['Govorite li engleski?', 'Do you speak English?'],
    ['Ne razumijem', 'I do not understand'],
    ['Koliko to košta?', 'How much does it cost?'],
    ['Gdje je stanica?', 'Where is the station?'],
    ['Želim kavu, molim', 'I would like a coffee, please'],
    ['Vlak kasni', 'The train is late'],
    ['Vidimo se sutra', 'See you tomorrow'],
    ['Vidimo se kasnije', 'See you later'],
    ['Ugodan dan!', 'Have a nice day!'],
    ['Danas je lijep dan', 'Today is a beautiful day'],
    ['Radim na projektu', 'I am working on a project'],
    ['Sretno!', 'Good luck!'],
    ['Sve najbolje!', 'All the best!'],
    ['Nema problema', 'No problem'],
    ['Jako dobro', 'Very good'],
    ['Puno hvala', 'Many thanks'],
    ['Volim Hrvatsku', 'I love Croatia'],
    ['Duga je noć', 'The night is long'],
    ['Do viđenja', 'Goodbye']
  ];

  var ES = [
    ['Buenos días', 'Good morning'],
    ['Buenas tardes', 'Good afternoon'],
    ['Buenas noches', 'Good evening / night'],
    ['¿Cómo está usted?', 'How are you? (formal)'],
    ['Muchas gracias', 'Thank you very much'],
    ['De nada', "You're welcome"],
    ['Por favor', 'Please'],
    ['Perdóneme', 'Excuse me / Forgive me (formal)'],
    ['Mucho gusto', 'Nice to meet you'],
    ['Me llamo Kresimir', 'My name is Kresimir'],
    ['¿Habla usted inglés?', 'Do you speak English? (formal)'],
    ['No entiendo', 'I do not understand'],
    ['¿Cuánto cuesta?', 'How much does it cost?'],
    ['¿Dónde está la estación?', 'Where is the station?'],
    ['Quiero un café, por favor', 'I would like a coffee, please'],
    ['El tren llega tarde', 'The train is late'],
    ['Hasta mañana', 'See you tomorrow'],
    ['Hasta luego', 'See you later'],
    ['Que tenga un buen día', 'Have a nice day (formal)'],
    ['Hoy es un buen día', 'Today is a good day'],
    ['Trabajo en un proyecto', 'I am working on a project'],
    ['¡Buena suerte!', 'Good luck!'],
    ['Sin problema', 'No problem'],
    ['Claro que sí', 'Of course'],
    ['Lo siento mucho', 'I am very sorry'],
    ['¿Qué hora es?', 'What time is it?'],
    ['Está bien', 'It is all right'],
    ['Un placer', 'A pleasure'],
    ['Saludos a todos', 'Greetings to all'],
    ['Nos vemos pronto', 'See you soon'],
    ['Me encanta España', 'I love Spain'],
    ['Adiós', 'Goodbye']
  ];

  function defaults() { return { offHr: 0, offEs: 0 }; }

  function load() {
    var s = window.ECCStorage.get(KEY, null) || defaults();
    if (typeof s.offHr !== 'number') s.offHr = 0;
    if (typeof s.offEs !== 'number') s.offEs = 0;
    if (!Array.isArray(s.rev)) s.rev = [];
    s.rev = s.rev.filter(function (c) {
      return c && c.text && typeof c.due === 'number';
    });
    return s;
  }

  function save(s) { window.ECCStorage.set(KEY, s); }

  function esc(t) {
    return String(t).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  /* Day index from the calendar date — the PC and the phone agree. */
  function dayIndex() {
    var d = new Date();
    return Math.round(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) / 86400000);
  }

  function pick(arr, off) {
    var i = dayIndex() + off;
    var n = arr.length;
    return arr[((i % n) + n) % n];
  }

  function speak(text, lang) {
    try {
      if (!window.speechSynthesis) throw new Error('unavailable');
      window.speechSynthesis.cancel();
      var u = new SpeechSynthesisUtterance(text);
      u.lang = lang;
      u.rate = 0.9;
      window.speechSynthesis.speak(u);
    } catch (e) {
      if (window.ECCToast) window.ECCToast('Speech is not available here');
    }
  }

  function block(langKey, flag, name, bank, off, cls) {
    var p = pick(bank, off);
    return '<div class="ph-block ph-' + langKey + '">' +
      '<div class="ph-head"><span class="ph-flag">' + flag + '</span>' +
      '<span class="ph-lang">' + name + '</span>' +
      '<button class="ph-star-' + langKey + '" title="Save this phrase for review">★</button>' +
      '<button class="ph-speak-' + langKey + '" title="Hear it (browser speech)">🔊</button>' +
      '<button class="ph-next-' + langKey + '" title="Another phrase">Next ▸</button></div>' +
      '<div class="ph-phrase ' + cls + '">' + esc(p[0]) + '</div>' +
      '<div class="ph-trans">' + esc(p[1]) + '</div></div>';
  }

  /* ---------- flashcards (v1.6) ---------- */
  var IV = [1, 3, 7, 14, 30, 60]; /* review interval per level */
  var revOn = false; /* review mode is transient */
  var revIdx = 0;

  function dueCards(s) {
    var today = dayIndex();
    return (s.rev || []).filter(function (c) { return c.due <= today; });
  }

  function reviewHtml(s) {
    var due = dueCards(s);
    if (!due.length) {
      return '<div class="ph-rv-empty">No cards due — come back tomorrow 🌙 (' +
        (s.rev || []).length + ' saved)</div>';
    }
    if (revIdx >= due.length) revIdx = 0;
    var c = due[revIdx];
    var flag = c.lang === 'hr' ? '🇭🇷' : '🇪🇸';
    return '<div class="ph-rv-card">' +
      '<div class="ph-head"><span class="ph-flag">' + flag + '</span>' +
      '<span class="ph-lang">Review ' + (revIdx + 1) + ' / ' + due.length + '</span></div>' +
      '<div class="ph-phrase">' + esc(c.text) + '</div>' +
      '<div class="ph-rv-trans" hidden>' + esc(c.trans) + '</div>' +
      '<div class="gt-actions">' +
      '<button class="ph-rv-show">👁 Show translation</button>' +
      '<button class="ph-rv-got" hidden>✔ Got it</button>' +
      '<button class="ph-rv-again" hidden>⟳ Again</button>' +
      '<button class="ph-rv-next">Next ▸</button></div></div>';
  }

  function renderWidget(container) {
    container.classList.add('ph-body');
    var s = load();
    var due = dueCards(s).length;
    var html = '';
    if (revOn) html += reviewHtml(s);
    html +=
      '<div class="ph-grid">' +
      block('hr', '🇭🇷', 'Croatian', HR, s.offHr, 'ph-hr-text') +
      block('es', '🇪🇸', 'Spanish', ES, s.offEs, 'ph-es-text') +
      '</div>' +
      '<div class="gt-actions">' +
      '<button class="ph-today" title="Back to today\'s phrase">⟳ Today</button>' +
      '<button class="ph-review" title="Spaced-repetition review of saved phrases">🎴 Review' +
      (due ? ' (' + due + ' due)' : '') + '</button></div>' +
      '<div class="gt-note">A new phrase every day — the same one on your PC and phone. ★ saves a phrase for review; 🔊 hears it; 🎴 uses spaced repetition (1, 3, 7, 14, 30, 60 days).</div>';
    container.innerHTML = html;

    /* review wiring */
    var rvDone = function () {
      revOn = false;
      revIdx = 0;
      renderAll();
    };
    var rvBtn = container.querySelector('.ph-review');
    if (rvBtn) rvBtn.addEventListener('click', function () {
      var s2 = load();
      if (!dueCards(s2).length) {
        if (window.ECCToast) window.ECCToast('Nothing due — ★ save phrases first');
        return;
      }
      revOn = true;
      revIdx = 0;
      renderAll();
    });
    var showBtn = container.querySelector('.ph-rv-show');
    if (showBtn) {
      showBtn.addEventListener('click', function () {
        var tr = container.querySelector('.ph-rv-trans');
        if (tr) tr.hidden = false;
        showBtn.hidden = true;
        container.querySelector('.ph-rv-got').hidden = false;
        container.querySelector('.ph-rv-again').hidden = false;
      });
      container.querySelector('.ph-rv-got').addEventListener('click', function () {
        var s2 = load();
        var due2 = dueCards(s2);
        var c = due2[revIdx] || due2[0];
        var days = 1;
        if (c) {
          var stored = s2.rev.filter(function (x) { return x.lang === c.lang && x.text === c.text; })[0];
          if (stored) {
            stored.level = Math.min(5, (stored.level || 0) + 1);
            days = IV[stored.level];
            stored.due = dayIndex() + days;
          }
          save(s2);
        }
        revIdx++;
        if (revIdx >= dueCards(load()).length) { revIdx = 0; }
        renderAll();
        if (window.ECCToast) window.ECCToast('Nice — next review in ' + days + ' day' + (days > 1 ? 's' : ''));
      });
      container.querySelector('.ph-rv-again').addEventListener('click', function () {
        var s2 = load();
        var due2 = dueCards(s2);
        var c = due2[revIdx] || due2[0];
        if (c) {
          var stored = s2.rev.filter(function (x) { return x.lang === c.lang && x.text === c.text; })[0];
          if (stored) {
            stored.level = 0;
            stored.due = dayIndex() + 1;
          }
          save(s2);
        }
        revIdx++;
        if (revIdx >= dueCards(load()).length) { revIdx = 0; }
        renderAll();
      });
      container.querySelector('.ph-rv-next').addEventListener('click', function () {
        revIdx++;
        if (revIdx >= dueCards(load()).length) { revIdx = 0; }
        renderAll();
      });
      if (!dueCards(s).length && container.querySelector('.ph-rv-empty')) {
        /* review mode with nothing due — show exit button */
        var empty = container.querySelector('.ph-rv-empty');
        var exit = document.createElement('button');
        exit.textContent = '⏹ Done';
        exit.style.cssText = 'margin-top:10px;padding:6px 12px;border-radius:8px;border:1px solid var(--panel-border);background:var(--input);color:var(--text);cursor:pointer';
        exit.addEventListener('click', rvDone);
        empty.appendChild(document.createElement('br'));
        empty.appendChild(exit);
      }
    }

    container.querySelector('.ph-today').addEventListener('click', function () {
      var s2 = load();
      s2.offHr = 0;
      s2.offEs = 0;
      save(s2);
      renderAll();
      if (window.ECCToast) window.ECCToast('Back to today\'s phrases');
    });
    ['hr', 'es'].forEach(function (lk) {
      container.querySelector('.ph-star-' + lk).addEventListener('click', function () {
        var s2 = load();
        if (!Array.isArray(s2.rev)) s2.rev = [];
        var p = pick(lk === 'hr' ? HR : ES, lk === 'hr' ? s2.offHr : s2.offEs);
        var dupe = s2.rev.some(function (x) { return x.lang === lk && x.text === p[0]; });
        if (dupe) {
          if (window.ECCToast) window.ECCToast('Already saved for review');
          return;
        }
        s2.rev.push({ lang: lk, text: p[0], trans: p[1], level: 0, due: dayIndex() });
        if (s2.rev.length > 100) s2.rev.shift();
        save(s2);
        renderAll();
        if (window.ECCToast) window.ECCToast('★ Saved — 🎴 Review to practice it');
      });
      container.querySelector('.ph-speak-' + lk).addEventListener('click', function () {
        speak(pick(lk === 'hr' ? HR : ES, lk === 'hr' ? load().offHr : load().offEs)[0], lk === 'hr' ? 'hr-HR' : 'es-ES');
      });
      container.querySelector('.ph-next-' + lk).addEventListener('click', function () {
        var s2 = load();
        if (lk === 'hr') s2.offHr += 1; else s2.offEs += 1;
        save(s2);
        renderAll();
      });
    });
  }

  function renderAll() {
    document.querySelectorAll('.ph-body').forEach(function (el) { renderWidget(el); });
  }

  window.ECCPhrases = {
    renderWidget: renderWidget,
    renderAll: renderAll,
    load: load
  };
})();

/* ECC Pro v1.7 — support-plugin registration. Active when this file is
   loaded from the support/ folder (the core defines ECCPlugins first);
   harmless if the module is bundled some other way. */
if (window.ECCPlugins) {
  window.ECCPlugins.register({
    id: 'phrases', name: 'Phrase of the Day', file: 'phrases.js',
    icon: '💬', color: '#ec4899', w: 12, h: 7,
    render: function (el) { window.ECCPhrases.renderWidget(el); }
  });
}
