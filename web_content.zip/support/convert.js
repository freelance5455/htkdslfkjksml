/* ECC Pro — convert.js
   Unit converter for engineering work: length, mass, pressure
   (kPa ↔ psi ↔ inH2O…), volume, speed, energy, power, temperature.
   100% offline — pure arithmetic, no network, remembers your last setup. */
(function () {
  'use strict';

  var KEY = 'convert';

  var UNITS = {
    'Length': { 'mm': 0.001, 'cm': 0.01, 'm': 1, 'km': 1000, 'in': 0.0254, 'ft': 0.3048, 'yd': 0.9144, 'mi': 1609.344 },
    'Mass': { 'mg': 1e-6, 'g': 0.001, 'kg': 1, 't': 1000, 'oz': 0.028349523125, 'lb': 0.45359237 },
    'Pressure': { 'Pa': 1, 'kPa': 1000, 'MPa': 1e6, 'bar': 1e5, 'mbar': 100, 'psi': 6894.757293, 'mmHg': 133.3223874, 'inHg': 3386.389, 'inH2O': 249.0889, 'ftH2O': 2989.067 },
    'Volume': { 'mL': 0.001, 'L': 1, 'm³': 1000, 'ft³': 28.316846592, 'gal (US)': 3.785411784, 'gal (UK)': 4.54609, 'fl oz (US)': 0.0295735295625 },
    'Speed': { 'm/s': 1, 'km/h': 0.277777778, 'mph': 0.44704, 'ft/s': 0.3048, 'kn': 0.514444444 },
    'Energy': { 'J': 1, 'kJ': 1000, 'MJ': 1e6, 'kWh': 3.6e6, 'BTU': 1055.05585, 'cal': 4.184 },
    'Power': { 'W': 1, 'kW': 1000, 'MW': 1e6, 'hp': 745.699872 }
  };
  var TEMPS = ['°C', '°F', 'K'];

  function defaults() {
    return { cat: 'Pressure', from: 'kPa', to: 'psi', val: 100 };
  }

  function load() {
    var s = window.ECCStorage.get(KEY, null);
    if (!s) return defaults();
    if (!UNITS[s.cat] && s.cat !== 'Temperature') s.cat = defaults().cat;
    return s;
  }

  function save(s) { window.ECCStorage.set(KEY, s); }

  function esc(t) {
    return String(t).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function convert(cat, from, to, v) {
    var n = parseFloat(v);
    if (!isFinite(n)) return null;
    if (cat === 'Temperature') {
      /* to °C first */
      var c = from === '°C' ? n : from === '°F' ? (n - 32) * 5 / 9 : n - 273.15;
      return to === '°C' ? c : to === '°F' ? c * 9 / 5 + 32 : c + 273.15;
    }
    var f = UNITS[cat];
    if (!f[from] || !f[to]) return null;
    return n * f[from] / f[to];
  }

  function fmtResult(x) {
    if (x === null || !isFinite(x)) return '—';
    var ax = Math.abs(x);
    if (ax !== 0 && (ax < 0.001 || ax >= 1e9)) return x.toExponential(4);
    if (ax >= 1000) return +x.toFixed(2) + '';
    if (ax >= 1) return +x.toFixed(4) + '';
    return +x.toFixed(6) + '';
  }

  function unitKeys(cat) {
    return cat === 'Temperature' ? TEMPS : Object.keys(UNITS[cat]);
  }

  function optionsFor(cat, sel) {
    return unitKeys(cat).map(function (u) {
      return '<option value="' + esc(u) + '"' + (u === sel ? ' selected' : '') + '>' + esc(u) + '</option>';
    }).join('');
  }

  function renderWidget(container) {
    container.classList.add('cv-body');
    var s = load();
    var catList = Object.keys(UNITS).concat(['Temperature']);
    if (catList.indexOf(s.cat) < 0) s.cat = defaults().cat;
    var keys = unitKeys(s.cat);
    if (keys.indexOf(s.from) < 0) s.from = keys[0];
    if (keys.indexOf(s.to) < 0) s.to = keys[1] || keys[0];

    container.innerHTML =
      '<div class="cv-top">' +
      '<select class="cv-cat">' +
      catList.map(function (c) { return '<option value="' + c + '"' + (c === s.cat ? ' selected' : '') + '>' + c + '</option>'; }).join('') +
      '</select>' +
      '<button class="cv-swap" title="Swap units">⇄</button>' +
      '<button class="cv-reset" title="Reset to defaults (Pressure, kPa → psi, 100)">⟳</button></div>' +
      '<div class="cv-row">' +
      '<input type="number" step="any" class="cv-val mono" value="' + esc(s.val) + '">' +
      '<select class="cv-from">' + optionsFor(s.cat, s.from) + '</select></div>' +
      '<div class="cv-eq">=</div>' +
      '<div class="cv-row"><div class="cv-out mono">' + fmtResult(convert(s.cat, s.from, s.to, s.val)) +
      '</div><select class="cv-to">' + optionsFor(s.cat, s.to) + '</select></div>' +
      '<div class="gt-note cv-note">' + esc(s.cat) + ' · offline math, 6-digit precision.</div>';

    function persist() {
      var s2 = load();
      s2.cat = container.querySelector('.cv-cat').value;
      s2.from = container.querySelector('.cv-from').value;
      s2.to = container.querySelector('.cv-to').value;
      s2.val = container.querySelector('.cv-val').value;
      save(s2);
    }
    function update() {
      var cat = container.querySelector('.cv-cat').value;
      var from = container.querySelector('.cv-from').value;
      var to = container.querySelector('.cv-to').value;
      var v = container.querySelector('.cv-val').value;
      container.querySelector('.cv-out').textContent = fmtResult(convert(cat, from, to, v));
      container.querySelector('.cv-note').textContent = cat + ' · offline math, 6-digit precision.';
      persist();
    }
    container.querySelector('.cv-cat').addEventListener('change', function () {
      var cat = this.value;
      var keys2 = unitKeys(cat);
      s.cat = cat; s.from = keys2[0]; s.to = keys2[1] || keys2[0];
      container.querySelector('.cv-from').innerHTML = optionsFor(cat, s.from);
      container.querySelector('.cv-to').innerHTML = optionsFor(cat, s.to);
      update();
    });
    container.querySelector('.cv-from').addEventListener('change', update);
    container.querySelector('.cv-to').addEventListener('change', update);
    container.querySelector('.cv-val').addEventListener('input', update);
    container.querySelector('.cv-swap').addEventListener('click', function () {
      var f = container.querySelector('.cv-from').value;
      container.querySelector('.cv-from').value = container.querySelector('.cv-to').value;
      container.querySelector('.cv-to').value = f;
      update();
    });
    container.querySelector('.cv-reset').addEventListener('click', function () {
      var d = defaults();
      var s2 = load();
      s2.cat = d.cat; s2.from = d.from; s2.to = d.to; s2.val = d.val;
      save(s2);
      renderAll();
      if (window.ECCToast) window.ECCToast('Converter reset to defaults');
    });
  }

  function renderAll() {
    document.querySelectorAll('.cv-body').forEach(function (el) { renderWidget(el); });
  }

  window.ECCConvert = {
    renderWidget: renderWidget,
    renderAll: renderAll,
    load: load
  };
})();

/* ECC Pro v1.7 — support-plugin registration. Active when this file is
   loaded from the support/ folder (the core defines ECCPlugins first);
   harmless if the module is bundled some other way. */
if (window.ECCPlugins) {
  window.ECCPlugins.register({
    id: 'convert', name: 'Converter', file: 'convert.js',
    icon: '🔄', color: '#a78bfa', w: 3, h: 8,
    render: function (el) { window.ECCConvert.renderWidget(el); }
  });
}
