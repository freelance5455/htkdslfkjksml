/* ECC Pro — gotrain.js
   GO Train timer widget (default: Exhibition → Long Branch, Lakeshore
   West). Offline-first: countdowns are computed from an editable local
   timetable, so they work with zero internet. Live status is one click
   away via the GO Transit link. Update the timetable with the ✎ button
   whenever GO publishes schedule changes (schedules shift seasonally
   and during construction). */

(function () {
  'use strict';

  var KEY = 'gotrain';
  var LIVE_URL = 'https://www.gotransit.com/en/find-a-station/ex/routes-departures';

  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function fmt(mins) { return pad(Math.floor(mins / 60) % 24) + ':' + pad(mins % 60); }

  /* Typical Lakeshore West westbound pattern — EDIT with exact times
     from GO Transit via the widget's ✎ button. Times 00:xx–01:xx are
     late-evening continuation trips. */
  function defaultSchedule() {
    var wd = [];
    for (var m = 5 * 60 + 5; m <= 23 * 60 + 35; m += 30) wd.push(fmt(m));
    for (m = 15 * 60 + 20; m <= 18 * 60 + 50; m += 30) wd.push(fmt(m)); /* PM rush extras */
    [5, 35, 65].forEach(function (x) { wd.push(fmt(x)); });
    wd.sort();
    var we = [];
    for (m = 7 * 60 + 5; m <= 23 * 60 + 5; m += 60) we.push(fmt(m));
    [5, 65].forEach(function (x) { we.push(fmt(x)); });
    we.sort();
    return { weekday: wd, saturday: we.slice(), sunday: we.slice() };
  }

  function defaults() {
    var s = defaultSchedule();
    return {
      from: 'Exhibition',
      to: 'Long Branch',
      travelMin: 14,
      weekday: s.weekday,
      saturday: s.saturday,
      sunday: s.sunday,
      alert: 'Oct 24–25: Lakeshore West construction — train service adjusted; '
        + 'GO buses replace trains at Exhibition & Long Branch. Check live status before travelling.',
      note: 'Typical pattern — edit times with ✎'
    };
  }

  function load() {
    var d = defaults();
    var s = window.ECCStorage.get(KEY, null);
    if (!s) return d;
    s.weekday = Array.isArray(s.weekday) ? s.weekday : d.weekday;
    s.saturday = Array.isArray(s.saturday) ? s.saturday : d.saturday;
    s.sunday = Array.isArray(s.sunday) ? s.sunday : d.sunday;
    return s;
  }

  function save(s) { window.ECCStorage.set(KEY, s); }

  function dayKey(d) {
    var day = d.getDay();
    return day === 0 ? 'sunday' : day === 6 ? 'saturday' : 'weekday';
  }

  function toMin(t) {
    var m = /^(\d{1,2}):(\d{2})$/.exec(String(t).trim());
    return m ? (parseInt(m[1], 10) % 24) * 60 + parseInt(m[2], 10) : null;
  }

  function normalize(list) {
    return (Array.isArray(list) ? list : [])
      .map(function (t) { return String(t).trim(); })
      .filter(function (t) { return /^\d{1,2}:\d{2}$/.test(t); })
      .sort(function (a, b) { return toMin(a) - toMin(b); });
  }

  /* Next n departures from "now" (handles late-evening rollover). */
  function nextDepartures(s, n) {
    var now = new Date();
    var nowMin = now.getHours() * 60 + now.getMinutes() + now.getSeconds() / 60;
    var times = s[dayKey(now)].map(toMin).filter(function (m) { return m !== null; });
    var out = [];
    var horizon = nowMin + 36 * 60;
    for (var offset = 0; offset <= 1440 + 300; offset += 1440) {
      times.forEach(function (m) {
        var abs = m + offset;
        if (abs > nowMin && abs < horizon && out.length < n) {
          out.push({ depMin: m, inMin: abs - nowMin });
        }
      });
      if (out.length >= n) break;
    }
    out.sort(function (a, b) { return a.inMin - b.inMin; });
    return out.slice(0, n);
  }

  function esc(t) {
    return String(t).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function renderWidget(container) {
    if (container._gtTimer) clearInterval(container._gtTimer);
    var s = load();
    container.className = container.className.replace(/\bwx-body\b|\bst-body\b/g, '').trim();
    container.classList.add('gt-body');
    if (container.dataset.editing === '1') return; /* editor open — don't stomp it */
    if (!container._gtSynced) container._gtSynced = new Date();

    var next = nextDepartures(s, 4);
    var html = '<div class="gt-route"><span class="gt-from">' + esc(s.from) + '</span>' +
      '<span class="gt-arrow">→</span><span class="gt-to">' + esc(s.to) + '</span></div>';
    if (next.length) {
      var n0 = next[0];
      html += '<div class="gt-next"><span class="gt-count mono">' +
        (n0.inMin < 1 ? 'now' : Math.floor(n0.inMin) + '') +
        '</span><span class="gt-unit">min</span>' +
        '<span class="gt-dep mono">' + fmt(n0.depMin) + '</span></div>';
      html += '<div class="gt-list">';
      next.slice(1).forEach(function (t) {
        html += '<div class="gt-row"><span class="mono">' + fmt(t.depMin) + '</span>' +
          '<span class="gt-eta">in ' + Math.floor(t.inMin) + ' min</span>' +
          '<span class="gt-arr mono">arr ' + fmt((t.depMin + (s.travelMin || 14)) % 1440) + '</span></div>';
      });
      html += '</div>';
    } else {
      html += '<div class="w-empty">No departures in the local timetable — edit it with ✎.</div>';
    }
    html += '<div class="gt-note gt-sync">Synced ' +
      container._gtSynced.toLocaleTimeString('en-CA', { hour: '2-digit', minute: '2-digit', second: '2-digit' }) +
      '</div>';
    if (s.alert) html += '<div class="gt-alert">⚠ ' + esc(s.alert) + '</div>';
    if (s.note) html += '<div class="gt-note">' + esc(s.note) + '</div>';
    html += '<div class="gt-actions">' +
      '<button class="gt-refresh" title="Re-sync the countdown to the clock and timetable">⟳ Refresh</button>' +
      '<button class="gt-edit">✎ Schedule</button>' +
      '<a class="gt-live" href="' + LIVE_URL + '" target="_blank" rel="noopener">● Live status</a></div>';
    container.innerHTML = html;
    container.querySelector('.gt-refresh').addEventListener('click', function () {
      container._gtSynced = new Date();
      renderWidget(container);
      if (window.ECCToast) window.ECCToast('Departures re-synced to the clock');
    });
    container.querySelector('.gt-edit').addEventListener('click', function () {
      renderEditor(container);
    });

    container._gtTimer = setInterval(function () {
      if (container.dataset.editing === '1' || !container.isConnected) {
        clearInterval(container._gtTimer);
        return;
      }
      renderWidget(container);
    }, 20000);
  }

  function renderEditor(container) {
    var s = load();
    container.dataset.editing = '1';
    container.innerHTML =
      '<div class="gt-form">' +
      '<div class="gt-form-row"><label>From</label><input type="text" class="gtf-from" value="' + esc(s.from) + '"></div>' +
      '<div class="gt-form-row"><label>To</label><input type="text" class="gtf-to" value="' + esc(s.to) + '"></div>' +
      '<div class="gt-form-row"><label>Travel time (min)</label><input type="number" class="gtf-travel" min="1" max="120" value="' + (s.travelMin || 14) + '"></div>' +
      '<div class="gt-form-row"><label>Weekday times</label><textarea class="gtf-wd" rows="5">' + esc(s.weekday.join('\n')) + '</textarea></div>' +
      '<div class="gt-form-row"><label>Saturday times</label><textarea class="gtf-sat" rows="3">' + esc(s.saturday.join('\n')) + '</textarea></div>' +
      '<div class="gt-form-row"><label>Sunday times</label><textarea class="gtf-sun" rows="3">' + esc(s.sunday.join('\n')) + '</textarea></div>' +
      '<div class="gt-form-row"><label>Alert note (optional)</label><textarea class="gtf-alert" rows="2">' + esc(s.alert || '') + '</textarea></div>' +
      '<div class="gt-actions"><button class="gt-save">💾 Save</button><button class="gt-cancel">Cancel</button></div>' +
      '<div class="gt-note">One HH:MM per line. Times 00:xx–01:xx = late-evening trips.</div>' +
      '</div>';
    container.querySelector('.gt-save').addEventListener('click', function () {
      var upd = {
        from: container.querySelector('.gtf-from').value.trim() || 'Exhibition',
        to: container.querySelector('.gtf-to').value.trim() || 'Long Branch',
        travelMin: parseInt(container.querySelector('.gtf-travel').value, 10) || 14,
        weekday: normalize(container.querySelector('.gtf-wd').value.split('\n')),
        saturday: normalize(container.querySelector('.gtf-sat').value.split('\n')),
        sunday: normalize(container.querySelector('.gtf-sun').value.split('\n')),
        alert: container.querySelector('.gtf-alert').value.trim(),
        note: s.note
      };
      save(upd);
      container.dataset.editing = '0';
      renderWidget(container);
      if (window.ECCToast) window.ECCToast('GO timetable saved');
    });
    container.querySelector('.gt-cancel').addEventListener('click', function () {
      container.dataset.editing = '0';
      renderWidget(container);
    });
  }

  window.ECCGotrain = {
    load: load,
    nextDepartures: nextDepartures,
    renderWidget: renderWidget
  };
})();

/* ECC Pro v1.7 — support-plugin registration. Active when this file is
   loaded from the support/ folder (the core defines ECCPlugins first);
   harmless if the module is bundled some other way. */
if (window.ECCPlugins) {
  window.ECCPlugins.register({
    id: 'gotrain', name: 'GO Train', file: 'gotrain.js',
    icon: '🚆', color: '#22d3ee', w: 3, h: 8,
    render: function (el) { window.ECCGotrain.renderWidget(el); }
  });
}
