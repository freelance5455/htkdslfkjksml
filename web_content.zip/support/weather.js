/* ECC Pro — weather.js
   Weather widget. Offline-first: the last forecast is cached locally and
   always shown; when internet is available it refreshes from Open-Meteo
   (free, no API key, no account, no tracking — https://open-meteo.com).
   Location (name + lat/lon) is fully editable. */

(function () {
  'use strict';

  var KEY = 'weather';
  var STALE_MS = 30 * 60 * 1000;

  function defaults() {
    return {
      loc: { name: 'Long Branch, Toronto', lat: 43.6106, lon: -79.5339 },
      auto: true,
      cache: null
    };
  }

  function load() {
    var s = window.ECCStorage.get(KEY, null);
    if (!s) return defaults();
    if (!s.loc || typeof s.loc.lat !== 'number') s.loc = defaults().loc;
    if (!s.cache || !s.cache.current) s.cache = null;
    return s;
  }

  function save(s) { window.ECCStorage.set(KEY, s); }

  /* WMO weather codes → [emoji, label] */
  function codeInfo(c) {
    var m = {
      0: ['☀️', 'Clear'], 1: ['☀️', 'Mainly clear'], 2: ['⛅', 'Partly cloudy'], 3: ['☁️', 'Overcast'],
      45: ['🌫️', 'Fog'], 48: ['🌫️', 'Freezing fog'],
      51: ['🌦️', 'Light drizzle'], 53: ['🌦️', 'Drizzle'], 55: ['🌧️', 'Heavy drizzle'],
      61: ['🌦️', 'Light rain'], 63: ['🌧️', 'Rain'], 65: ['🌧️', 'Heavy rain'],
      66: ['🌧️', 'Freezing rain'], 67: ['🌧️', 'Freezing rain'],
      71: ['🌨️', 'Light snow'], 73: ['❄️', 'Snow'], 75: ['❄️', 'Heavy snow'], 77: ['❄️', 'Snow grains'],
      80: ['🌦️', 'Light showers'], 81: ['🌧️', 'Showers'], 82: ['⛈️', 'Heavy showers'],
      85: ['🌨️', 'Snow showers'], 86: ['❄️', 'Snow showers'],
      95: ['⛈️', 'Thunderstorm'], 96: ['⛈️', 'Storm w/ hail'], 99: ['⛈️', 'Storm w/ hail']
    };
    return m[c] || ['🌡️', '—'];
  }

  function esc(t) {
    return String(t).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function stale(s) {
    return !s.cache || (Date.now() - (s.cache.fetched || 0)) > STALE_MS;
  }

  /* Fetch from Open-Meteo. quiet=true suppresses the failure toast
     (used for background auto-refresh). */
  function fetchWeather(quiet) {
    var s = load();
    var url = 'https://api.open-meteo.com/v1/forecast' +
      '?latitude=' + encodeURIComponent(s.loc.lat) +
      '&longitude=' + encodeURIComponent(s.loc.lon) +
      '&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m' +
      '&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max' +
      '&forecast_days=5&timezone=auto';
    return fetch(url)
      .then(function (r) {
        if (!r.ok) throw new Error('HTTP ' + r.status);
        return r.json();
      })
      .then(function (d) {
        if (!d || !d.current || !d.daily) throw new Error('bad response');
        var daily = [];
        for (var i = 0; i < (d.daily.time || []).length && i < 5; i++) {
          daily.push({
            date: d.daily.time[i],
            code: d.daily.weather_code ? d.daily.weather_code[i] : 0,
            max: d.daily.temperature_2m_max ? Math.round(d.daily.temperature_2m_max[i]) : null,
            min: d.daily.temperature_2m_min ? Math.round(d.daily.temperature_2m_min[i]) : null,
            pop: d.daily.precipitation_probability_max ? Math.round(d.daily.precipitation_probability_max[i]) : null
          });
        }
        s.cache = {
          fetched: Date.now(),
          current: {
            temp: Math.round(d.current.temperature_2m),
            feels: d.current.apparent_temperature != null ? Math.round(d.current.apparent_temperature) : null,
            code: d.current.weather_code || 0,
            wind: d.current.wind_speed_10m != null ? Math.round(d.current.wind_speed_10m) : null
          },
          daily: daily
        };
        save(s);
        renderAll();
        if (window.ECCToast) window.ECCToast('Weather updated');
        return s.cache;
      })
      .catch(function (e) {
        if (!quiet && window.ECCToast) {
          window.ECCToast('Weather offline — showing saved forecast');
        }
        return null;
      });
  }

  function renderWidget(container) {
    container.classList.add('wx-body');
    if (container.dataset.editing === '1') return;
    var s = load();
    var c = s.cache;

    var html = '';
    if (c && c.current) {
      var ci = codeInfo(c.current.code);
      html += '<div class="wx-now"><span class="wx-emoji">' + ci[0] + '</span>' +
        '<span class="wx-temp mono">' + c.current.temp + '°</span>' +
        '<span class="wx-desc"><span class="wx-cond">' + ci[1] + '</span>' +
        '<span class="wx-sub">' + esc(s.loc.name) +
        (c.current.feels != null ? ' · feels ' + c.current.feels + '°' : '') +
        (c.current.wind != null ? ' · wind ' + c.current.wind + ' km/h' : '') + '</span></span></div>';
      html += '<div class="wx-days">';
      (c.daily || []).forEach(function (d, i) {
        var di = codeInfo(d.code);
        var label = i === 0 ? 'Today' : new Date(d.date + 'T12:00:00')
          .toLocaleDateString('en-CA', { weekday: 'short' });
        html += '<div class="wx-day"><span class="wx-day-name">' + label + '</span>' +
          '<span class="wx-day-ico">' + di[0] + '</span>' +
          '<span class="wx-day-temps mono">' + d.max + '°<span class="wx-min"> ' + d.min + '°</span></span></div>';
      });
      html += '</div>';
      var when = new Date(c.fetched);
      var age = Math.round((Date.now() - c.fetched) / 60000);
      html += '<div class="wx-upd">Updated ' +
        when.toLocaleTimeString('en-CA', { hour: '2-digit', minute: '2-digit', hour12: false }) +
        (age > 90 ? ' (' + Math.round(age / 60) + ' h old, offline copy)' : '') + '</div>';
    } else {
      html += '<div class="w-empty">No forecast yet.<br>Press ⟳ once when online — it is cached for offline use.</div>';
    }
    html += '<div class="gt-actions">' +
      '<button class="wx-refresh" title="Fetch fresh forecast (needs internet)">⟳ Refresh</button>' +
      '<button class="wx-loc" title="Change location">📍 Location</button></div>';
    container.innerHTML = html;

    container.querySelector('.wx-refresh').addEventListener('click', function () { fetchWeather(false); });
    container.querySelector('.wx-loc').addEventListener('click', function () { renderEditor(container); });

    if (s.auto && stale(s)) fetchWeather(true);
  }

  function renderEditor(container) {
    var s = load();
    container.dataset.editing = '1';
    container.innerHTML =
      '<div class="st-form"><div class="st-form-grid">' +
      '<div class="gt-form-row"><label>Location name</label><input type="text" class="wxf-name" maxlength="40" value="' + esc(s.loc.name) + '"></div>' +
      '<div class="gt-form-row"><label>Latitude</label><input type="number" step="any" class="wxf-lat" value="' + s.loc.lat + '"></div>' +
      '<div class="gt-form-row"><label>Longitude</label><input type="number" step="any" class="wxf-lon" value="' + s.loc.lon + '"></div>' +
      '</div>' +
      '<div class="gt-actions"><button class="wx-save">💾 Save</button><button class="wx-cancel">Cancel</button></div>' +
      '<div class="gt-note">Any place on Earth. Long Branch GO ≈ 43.6106, -79.5339 · Exhibition GO ≈ 43.6302, -79.4219.</div></div>';
    container.querySelector('.wx-save').addEventListener('click', function () {
      var s2 = load();
      s2.loc = {
        name: container.querySelector('.wxf-name').value.trim() || s2.loc.name,
        lat: parseFloat(container.querySelector('.wxf-lat').value) || s2.loc.lat,
        lon: parseFloat(container.querySelector('.wxf-lon').value) || s2.loc.lon
      };
      save(s2);
      container.dataset.editing = '0';
      fetchWeather(false);
      renderAll();
    });
    container.querySelector('.wx-cancel').addEventListener('click', function () {
      container.dataset.editing = '0';
      renderWidget(container);
    });
  }

  function renderAll() {
    document.querySelectorAll('.wx-body').forEach(function (el) {
      el.dataset.editing = '0';
      renderWidget(el);
    });
  }

  /* ---------- weather hint + clothing suggestion (greeting) ---------- */
  function isRainCode(c) { return (c >= 51 && c <= 67) || (c >= 80 && c <= 82) || c >= 95; }
  function isSnowCode(c) { return (c >= 71 && c <= 77) || c === 85 || c === 86; }
  function isFreezingCode(c) { return c === 66 || c === 67 || c === 48; }

  function clothing(temp, code, wind, pop) {
    var t = (temp != null) ? temp : null;
    var c = [];
    if (t == null) return '';
    if (t >= 28) c.push('🕶️ light clothing + sunscreen');
    else if (t >= 20) c.push('👕 light layers');
    else if (t >= 13) c.push('🧥 light jacket');
    else if (t >= 6) c.push('🧥 warm jacket');
    else if (t >= -5) c.push('🧣 winter coat + gloves');
    else c.push('🧤 heavy coat, toque + boots');
    var wet = isRainCode(code) || (pop != null && pop >= 60);
    var snow = isSnowCode(code);
    if (wet) c.push('☂️ umbrella / rainshell');
    if (snow) c.push('🥾 waterproof boots');
    if (isFreezingCode(code)) c.push('🧊 icy — take care');
    if (wind != null && wind >= 40) c.push('💨 windy');
    return c.join(' · ');
  }

  /* One-line hint for the greeting, from the cached forecast.
     e.g. "🌧️ 4°, rain likely — 🧣 winter coat + gloves · ☂️ umbrella". */
  function wxHint() {
    var s = load();
    var c = s.cache;
    if (!c || !c.current) return '';
    var ci = codeInfo(c.current.code);
    var today = (c.daily || [])[0] || {};
    var bits = [ci[0] + ' ' + c.current.temp + '°'];
    if (today.pop != null && today.pop >= 40 && !isSnowCode(today.code)) {
      bits.push(today.pop >= 70 ? 'rain very likely' : 'rain possible');
    }
    var cloth = clothing(c.current.temp, today.code != null ? today.code : c.current.code, c.current.wind, today.pop);
    if (cloth) bits.push(cloth);
    return bits.join(', ');
  }

  window.ECCWeather = {
    load: load,
    fetchWeather: fetchWeather,
    renderWidget: renderWidget,
    renderAll: renderAll,
    wxHint: wxHint,
    clothing: clothing
  };
})();

/* ECC Pro v1.7 — support-plugin registration. Active when this file is
   loaded from the support/ folder (the core defines ECCPlugins first);
   harmless if the module is bundled some other way. */
if (window.ECCPlugins) {
  window.ECCPlugins.register({
    id: 'weather', name: 'Weather', file: 'weather.js',
    icon: '🌤️', color: '#60a5fa', w: 6, h: 8,
    render: function (el) { window.ECCWeather.renderWidget(el); }
  });
}
