/* ECC Pro — pomodoro.js
   Pomodoro / focus timer. Fully offline. The timer survives page reloads
   and PC wake-ups: while running it is anchored to the wall clock, so
   reopening the new-tab page (or opening the phone) shows the same
   countdown. A soft triple-beep (Web Audio, local) marks transitions. */
(function () {
  'use strict';

  var KEY = 'pomodoro';
  var MODES = { work: 'Focus', short: 'Short break', long: 'Long break' };

  function defaults() {
    return { work: 25, short: 5, long: 15, cycles: 4, auto: true, timer: null };
  }

  function load() {
    var s = window.ECCStorage.get(KEY, null);
    if (!s) return defaults();
    ['work', 'short', 'long', 'cycles'].forEach(function (k) {
      if (typeof s[k] !== 'number' || s[k] < 1) s[k] = defaults()[k];
    });
    s.auto = s.auto !== false;
    if (!s.log || typeof s.log !== 'object') s.log = {};
    if (!s.timer || !MODES[s.timer.mode]) s.timer = null;
    else {
      s.timer.done = s.timer.done | 0;
      if (typeof s.timer.remain !== 'number') s.timer.remain = s.work * 60;
    }
    return s;
  }

  function save(s) { window.ECCStorage.set(KEY, s); }

  function esc(t) {
    return String(t).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function totalFor(s, mode) { return Math.max(1, s[mode]) * 60; }

  function freshTimer(s) {
    return { mode: 'work', running: false, endAt: 0, remain: s.work * 60, done: 0 };
  }

  function remaining(s) {
    var t = s.timer;
    if (t.running) return Math.max(0, Math.round((t.endAt - Date.now()) / 1000));
    return t.remain;
  }

  function fmt(sec) {
    var m = Math.floor(sec / 60), r = sec % 60;
    return (m < 10 ? '0' : '') + m + ':' + (r < 10 ? '0' : '') + r;
  }

  /* ---------- focus log (v1.6) ---------- */
  function dayKey(d) {
    var x = d || new Date();
    return x.getFullYear() + '-' +
      ('0' + (x.getMonth() + 1)).slice(-2) + '-' +
      ('0' + x.getDate()).slice(-2);
  }
  function addFocusMinutes(s, min) {
    if (!min) return;
    var k = dayKey();
    s.log[k] = (s.log[k] || 0) + min;
    /* prune entries older than 60 days */
    var cutoff = new Date();
    cutoff.setDate(cutoff.getDate() - 60);
    var ck = dayKey(cutoff);
    Object.keys(s.log).forEach(function (d) {
      if (d < ck) delete s.log[d];
    });
  }
  function focusStats() {
    var s = load();
    var today = s.log[dayKey()] || 0;
    var week = 0;
    for (var i = 0; i < 7; i++) {
      var d = new Date();
      d.setDate(d.getDate() - i);
      week += s.log[dayKey(d)] || 0;
    }
    return { today: today, week: week };
  }

  /* ---------- audio ---------- */
  function beep() {
    try {
      var AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      var ctx = beep._ctx && beep._ctx.state !== 'closed' ? beep._ctx : (beep._ctx = new AC());
      [0, 0.18, 0.36].forEach(function (delay) {
        var o = ctx.createOscillator();
        var g = ctx.createGain();
        o.type = 'sine';
        o.frequency.value = 880;
        g.gain.setValueAtTime(0.001, ctx.currentTime + delay);
        g.gain.exponentialRampToValueAtTime(0.18, ctx.currentTime + delay + 0.02);
        g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + delay + 0.14);
        o.connect(g); g.connect(ctx.destination);
        o.start(ctx.currentTime + delay);
        o.stop(ctx.currentTime + delay + 0.16);
      });
    } catch (e) { /* audio unavailable — silent */ }
  }

  function nextMode(s) {
    var t = s.timer;
    if (t.mode === 'work') {
      t.done += 1;
      return (t.done % s.cycles === 0) ? 'long' : 'short';
    }
    return 'work';
  }

  function transition(s, container) {
    var t = s.timer;
    var wasWork = t.mode === 'work';
    t.mode = nextMode(s);
    if (s.auto) {
      t.running = true;
      t.endAt = Date.now() + totalFor(s, t.mode) * 1000;
      t.remain = totalFor(s, t.mode);
    } else {
      t.running = false;
      t.remain = totalFor(s, t.mode);
    }
    if (wasWork) addFocusMinutes(s, s.work);
    save(s);
    beep();
    if (window.ECCToast) {
      window.ECCToast(wasWork
        ? (t.mode === 'long' ? 'Long break — well earned! ☕' : 'Break time — stretch! ☕')
        : 'Back to focus 💪');
    }
    renderAll();
  }

  /* ---------- rendering ---------- */
  function renderWidget(container) {
    container.classList.add('pm-body');
    if (container.dataset.editing === '1') return;
    clearInterval(container._pmTimer);

    var s = load();
    if (!s.timer) { s.timer = freshTimer(s); }
    var t = s.timer;
    var rem = remaining(s);
    var total = totalFor(s, t.mode);

    var dots = '';
    for (var i = 0; i < s.cycles; i++) {
      dots += '<span class="pm-dot' + (i < (t.done % s.cycles || (t.done && t.done % s.cycles === 0 ? s.cycles : 0)) ? ' on' : '') + '"></span>';
    }

    container.innerHTML =
      '<div class="pm-top"><span class="pm-mode">' + MODES[t.mode] + '</span>' +
      '<span class="pm-cycle">Session ' + (t.done + 1) + '</span></div>' +
      '<div class="pm-time mono">' + fmt(rem) + '</div>' +
      '<div class="pm-bar"><div class="pm-fill" style="width:' +
        Math.round((1 - rem / total) * 100) + '%"></div></div>' +
      '<div class="pm-dots">' + dots + '</div>' +
      '<div class="gt-actions">' +
      '<button class="pm-toggle">' + (t.running ? '⏸ Pause' : '▶ Start') + '</button>' +
      '<button class="pm-reset" title="Reset this interval">⟲ Reset</button>' +
      '<button class="pm-skip" title="Skip to the next interval">⏭ Skip</button>' +
      '<button class="pm-sync" title="Re-sync the display with the wall clock (e.g. after sleep/wake)">⟳</button>' +
      '<button class="pm-edit" title="Edit durations">✎</button></div>' +
      '<div class="gt-note">' + s.work + ' min focus · ' + s.short + ' / ' + s.long +
      ' min breaks · long break every ' + s.cycles + ' sessions' +
      (t.running ? '' : ' · saved across tabs') + '</div>' +
      (focusStats().today || focusStats().week
        ? '<div class="gt-note pm-focus mono">🔥 Today ' + focusStats().today + ' min · last 7 days ' + focusStats().week + ' min</div>'
        : '');

    container.querySelector('.pm-toggle').addEventListener('click', function () {
      var s2 = load();
      var t2 = s2.timer;
      if (t2.running) {
        t2.remain = Math.max(0, Math.round((t2.endAt - Date.now()) / 1000));
        t2.running = false;
      } else {
        t2.endAt = Date.now() + (t2.remain || totalFor(s2, t2.mode)) * 1000;
        t2.running = true;
      }
      save(s2);
      renderAll();
    });
    container.querySelector('.pm-reset').addEventListener('click', function () {
      var s2 = load();
      s2.timer.running = false;
      s2.timer.remain = totalFor(s2, s2.timer.mode);
      save(s2);
      renderAll();
    });
    container.querySelector('.pm-skip').addEventListener('click', function () {
      var s2 = load();
      transition(s2, container);
    });
    container.querySelector('.pm-sync').addEventListener('click', function () {
      var s2 = load();
      var rem2 = s2.timer && s2.timer.running ? remaining(s2) : (s2.timer ? s2.timer.remain : 0);
      renderAll();
      if (window.ECCToast) window.ECCToast('Timer re-synced with the clock — ' + fmt(rem2) + ' left');
    });
    container.querySelector('.pm-edit').addEventListener('click', function () {
      renderEditor(container);
    });

    container._pmTimer = setInterval(function () {
      if (!container.isConnected) { clearInterval(container._pmTimer); return; }
      if (container.dataset.editing === '1') return;
      var s2 = load();
      if (!s2.timer || !s2.timer.running) return;
      var rem2 = remaining(s2);
      var timeEl = container.querySelector('.pm-time');
      var fillEl = container.querySelector('.pm-fill');
      if (timeEl) timeEl.textContent = fmt(rem2);
      if (fillEl) fillEl.style.width = Math.round((1 - rem2 / totalFor(s2, s2.timer.mode)) * 100) + '%';
      if (rem2 <= 0) transition(s2, container);
    }, 500);
  }

  function renderEditor(container) {
    var s = load();
    container.dataset.editing = '1';
    clearInterval(container._pmTimer);
    container.innerHTML =
      '<div class="st-form"><div class="st-form-grid">' +
      '<div class="gt-form-row"><label>Focus (min)</label><input type="number" min="1" max="120" class="pmf-work" value="' + s.work + '"></div>' +
      '<div class="gt-form-row"><label>Short break (min)</label><input type="number" min="1" max="60" class="pmf-short" value="' + s.short + '"></div>' +
      '<div class="gt-form-row"><label>Long break (min)</label><input type="number" min="1" max="60" class="pmf-long" value="' + s.long + '"></div>' +
      '<div class="gt-form-row"><label>Long break every…</label><input type="number" min="2" max="10" class="pmf-cycles" value="' + s.cycles + '"></div>' +
      '</div>' +
      '<div class="gt-form-row"><label><input type="checkbox" class="pmf-auto"' + (s.auto ? ' checked' : '') + '> Auto-start next interval</label></div>' +
      '<div class="gt-actions"><button class="pm-save">💾 Save</button><button class="pm-cancel">Cancel</button></div>' +
      '<div class="gt-note">Classic Pomodoro: 25 / 5 / 15 with a long break every 4 sessions.</div></div>';
    container.querySelector('.pm-save').addEventListener('click', function () {
      var s2 = load();
      s2.work = clampInt(container.querySelector('.pmf-work').value, 1, 120, 25);
      s2.short = clampInt(container.querySelector('.pmf-short').value, 1, 60, 5);
      s2.long = clampInt(container.querySelector('.pmf-long').value, 1, 60, 15);
      s2.cycles = clampInt(container.querySelector('.pmf-cycles').value, 2, 10, 4);
      s2.auto = container.querySelector('.pmf-auto').checked;
      if (s2.timer && !s2.timer.running) s2.timer.remain = totalFor(s2, s2.timer.mode);
      save(s2);
      container.dataset.editing = '0';
      renderAll();
    });
    container.querySelector('.pm-cancel').addEventListener('click', function () {
      container.dataset.editing = '0';
      renderWidget(container);
    });
  }

  function clampInt(v, lo, hi, dflt) {
    var n = parseInt(v, 10);
    if (!isFinite(n)) n = dflt;
    return Math.min(hi, Math.max(lo, n));
  }

  function renderAll() {
    document.querySelectorAll('.pm-body').forEach(function (el) {
      el.dataset.editing = '0';
      renderWidget(el);
    });
  }

  window.ECCPomodoro = {
    renderWidget: renderWidget,
    renderAll: renderAll,
    load: load
  };
})();

/* ECC Pro v1.7 — support-plugin registration. Active when this file is
   loaded from the support/ folder (the core defines ECCPlugins first);
   harmless if the module is bundled some other way. */
if (window.ECCPlugins) {
  window.ECCPlugins.register({
    id: 'pomodoro', name: 'Pomodoro', file: 'pomodoro.js',
    icon: '🍅', color: '#ef4444', w: 3, h: 8,
    render: function (el) { window.ECCPomodoro.renderWidget(el); }
  });
}
