/* ECC Pro — support/support.js
   Widget plugin catalog (support v1.7.0).

   The app core loads this one file. It lists every compatible widget
   plugin and loads them in order, in the same parse step, so widgets
   are ready before the dashboard boots.

   Adding a new widget later: drop its .js file into this folder and
   add one line to PLUGINS below. The HTML core never changes. */
(function () {
  'use strict';

  /* [id, file, display name] — keep in sync with the plugin files. */
  var PLUGINS = [
    ['gotrain',    'gotrain.js',    'GO Train'],
    ['stocks',     'stocks.js',     'Stocks'],
    ['weather',    'weather.js',    'Weather'],
    ['pomodoro',   'pomodoro.js',   'Pomodoro'],
    ['forex',      'forex.js',      'Currency'],
    ['convert',    'convert.js',    'Converter'],
    ['pastwx',     'pastwx.js',     'Past Weather'],
    ['phrases',    'phrases.js',    'Phrase of the Day'],
    ['geo',        'geo.js',        'Geo Monitoring Reference'],
    ['sitelog',    'sitelog.js',    'Site Log'],
    ['scratchpad', 'scratchpad.js', 'Scratchpad']
  ];

  window.ECC_SUPPORT = {
    version: '1.7.0',
    plugins: PLUGINS.map(function (p) {
      return { id: p[0], file: p[1], name: p[2] };
    })
  };

  /* Load every plugin file now, in order, during page parse. */
  window.ECC_SUPPORT.plugins.forEach(function (p) {
    document.write('<script src="support/' + p.file + '"><\/script>');
  });
})();
