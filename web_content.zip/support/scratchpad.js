/* ECC Pro — scratchpad.js
   Scratchpad — a single always-saving notebook for prompts, snippets
   and quick notes (built for the BLUEBERRY AI project). Autosaves with
   every keystroke; copy it or save it as a .txt file locally. */
(function () {
  'use strict';

  var KEY = 'scratch';

  function load() {
    var s = window.ECCStorage.get(KEY, null);
    return { text: s && typeof s.text === 'string' ? s.text : '' };
  }

  function save(s) { window.ECCStorage.set(KEY, s); }

  function downloadTxt() {
    var text = load().text || '(empty)';
    var blob = new Blob([text], { type: 'text/plain' });
    var a = document.createElement('a');
    var stamp = new Date().toISOString().slice(0, 10);
    a.href = URL.createObjectURL(blob);
    a.download = 'ECC-Scratchpad-' + stamp + '.txt';
    document.body.appendChild(a);
    a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
  }

  function renderWidget(container) {
    container.classList.add('sc-body');
    var s = load();
    var words = s.text.trim() ? s.text.trim().split(/\s+/).length : 0;
    container.innerHTML =
      '<textarea class="sc-area" spellcheck="true" placeholder="Scratchpad — prompts, snippets, quick notes. Autosaves as you type…">' +
      (s.text || '').replace(/[&<>]/g, function (c) {
        return { '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c];
      }) + '</textarea>' +
      '<div class="gt-actions">' +
      '<button class="sc-copy" title="Copy everything to the clipboard">⧉ Copy</button>' +
      '<button class="sc-dl" title="Save as a .txt file locally">⬇ Save .txt</button>' +
      '<button class="sc-clear" title="Clear the scratchpad">🗑 Clear</button>' +
      '</div>' +
      '<div class="gt-note sc-count mono">' + words + ' words · autosaved locally</div>';

    var t = null;
    container.querySelector('.sc-area').addEventListener('input', function () {
      var s2 = { text: this.value };
      save(s2);
      var w = this.value.trim() ? this.value.trim().split(/\s+/).length : 0;
      var c = container.querySelector('.sc-count');
      if (c) c.textContent = w + ' words · autosaved locally';
      clearTimeout(t);
      t = setTimeout(function () {
        if (window.ECCToast) window.ECCToast('Scratchpad saved');
      }, 1200);
    });
    container.querySelector('.sc-copy').addEventListener('click', function () {
      var text = container.querySelector('.sc-area').value;
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(function () {
          if (window.ECCToast) window.ECCToast('Scratchpad copied');
        }, function () {
          if (window.ECCToast) window.ECCToast('Copy not available here');
        });
      } else if (window.ECCToast) window.ECCToast('Copy not available here');
    });
    container.querySelector('.sc-dl').addEventListener('click', function () {
      save({ text: container.querySelector('.sc-area').value });
      downloadTxt();
      if (window.ECCToast) window.ECCToast('Saving scratchpad .txt');
    });
    container.querySelector('.sc-clear').addEventListener('click', function () {
      if (!confirm('Clear the whole scratchpad?')) return;
      save({ text: '' });
      renderAll();
    });
  }

  function renderAll() {
    document.querySelectorAll('.sc-body').forEach(function (el) { renderWidget(el); });
  }

  window.ECCScratch = {
    renderWidget: renderWidget,
    renderAll: renderAll
  };
})();

/* ECC Pro v1.7 — support-plugin registration. Active when this file is
   loaded from the support/ folder (the core defines ECCPlugins first);
   harmless if the module is bundled some other way. */
if (window.ECCPlugins) {
  window.ECCPlugins.register({
    id: 'scratchpad', name: 'Scratchpad', file: 'scratchpad.js',
    icon: '🗒️', color: '#8b5cf6', w: 4, h: 9,
    render: function (el) { window.ECCScratch.renderWidget(el); }
  });
}
