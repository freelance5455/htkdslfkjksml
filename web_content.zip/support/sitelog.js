/* ECC Pro — sitelog.js
   Site & Decision Log — quick date-stamped entries for site visits,
   calls and engineering decisions. Fully offline; entries live in
   localStorage with the rest of the dashboard and travel in every
   backup. Copy out as text or save a .txt file locally. */
(function () {
  'use strict';

  var KEY = 'sitelog';

  function load() {
    var s = window.ECCStorage.get(KEY, null);
    if (!s || !Array.isArray(s.entries)) s = { entries: [] };
    s.entries = s.entries.filter(function (e) { return e && e.text; });
    return s;
  }

  function save(s) { window.ECCStorage.set(KEY, s); }

  function esc(t) {
    return String(t).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function fmtTs(ts) {
    var d = new Date(ts);
    return d.toLocaleDateString('en-CA', { month: 'short', day: 'numeric', year: 'numeric' }) +
      ' ' + d.toLocaleTimeString('en-CA', { hour: '2-digit', minute: '2-digit', hour12: false });
  }

  function asText() {
    return load().entries.map(function (e) {
      return fmtTs(e.ts) + ' — ' + e.text;
    }).join('\n');
  }

  function downloadTxt() {
    var text = asText() || '(no entries yet)';
    var blob = new Blob([text], { type: 'text/plain' });
    var a = document.createElement('a');
    var stamp = new Date().toISOString().slice(0, 10);
    a.href = URL.createObjectURL(blob);
    a.download = 'ECC-SiteLog-' + stamp + '.txt';
    document.body.appendChild(a);
    a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
  }

  function renderWidget(container) {
    container.classList.add('gl-body');
    var s = load();
    var html =
      '<div class="gl-addwrap">' +
      '<input type="text" class="gl-input" maxlength="300" placeholder="Log an entry — site visit, call, decision…">' +
      '<button class="gl-add" title="Add entry">＋</button></div>';
    if (!s.entries.length) {
      html += '<div class="w-empty">No entries yet.<br>Site visits, phone calls, engineering decisions — log them here.</div>';
    } else {
      html += '<div class="gl-list">';
      s.entries.slice(-100).reverse().forEach(function (e) {
        html += '<div class="gl-row" data-id="' + esc(e.id) + '">' +
          '<span class="gl-date mono">' + fmtTs(e.ts) + '</span>' +
          '<span class="gl-text">' + esc(e.text) + '</span>' +
          '<button class="gl-del" title="Delete">✕</button></div>';
      });
      html += '</div>';
    }
    html += '<div class="gt-actions">' +
      '<button class="gl-copy" title="Copy the whole log to the clipboard">⧉ Copy log</button>' +
      '<button class="gl-dl" title="Save the log as a .txt file locally">⬇ Save .txt</button>' +
      '</div>';
    container.innerHTML = html;

    container.querySelector('.gl-add').addEventListener('click', function () {
      var inp = container.querySelector('.gl-input');
      var t = inp.value.trim();
      if (!t) return;
      var s2 = load();
      s2.entries.push({ id: window.ECCWidgets.uid('e'), ts: Date.now(), text: t });
      save(s2);
      renderAll();
      if (window.ECCToast) window.ECCToast('Entry logged');
    });
    container.querySelector('.gl-input').addEventListener('keydown', function (ev) {
      if (ev.key === 'Enter') container.querySelector('.gl-add').click();
    });
    container.querySelectorAll('.gl-del').forEach(function (b) {
      b.addEventListener('click', function () {
        var s2 = load();
        var id = b.closest('.gl-row').dataset.id;
        s2.entries = s2.entries.filter(function (e) { return e.id !== id; });
        save(s2);
        renderAll();
      });
    });
    container.querySelector('.gl-copy').addEventListener('click', function () {
      var text = asText();
      var done = function () { if (window.ECCToast) window.ECCToast('Log copied to clipboard'); };
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(done, function () {
          if (window.ECCToast) window.ECCToast('Copy not available here — use ⬇ Save .txt');
        });
      } else if (window.ECCToast) {
        window.ECCToast('Copy not available here — use ⬇ Save .txt');
      }
    });
    container.querySelector('.gl-dl').addEventListener('click', function () {
      downloadTxt();
      if (window.ECCToast) window.ECCToast('Saving ECC-SiteLog .txt');
    });
  }

  function renderAll() {
    document.querySelectorAll('.gl-body').forEach(function (el) {
      el.dataset.editing = '0';
      renderWidget(el);
    });
  }

  window.ECCLog = {
    renderWidget: renderWidget,
    renderAll: renderAll
  };
})();

/* ECC Pro v1.7 — support-plugin registration. Active when this file is
   loaded from the support/ folder (the core defines ECCPlugins first);
   harmless if the module is bundled some other way. */
if (window.ECCPlugins) {
  window.ECCPlugins.register({
    id: 'sitelog', name: 'Site Log', file: 'sitelog.js',
    icon: '📝', color: '#84cc16', w: 4, h: 9,
    render: function (el) { window.ECCLog.renderWidget(el); }
  });
}
