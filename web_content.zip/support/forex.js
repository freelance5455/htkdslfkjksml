/* ECC Pro — forex.js
   Currency exchange widget (default: EUR → CAD, plus any pair you like).
   Offline-first: rates you set by hand always work. When online, ⟳ Refresh
   pulls fresh reference rates from frankfurter.app (ECB daily reference
   rates — free, no API key, no account, no tracking). */
(function () {
  'use strict';

  var KEY = 'forex';
  var API = 'https://api.frankfurter.app/latest?from=';

  function defaults() {
    return {
      pairs: [
        { id: 'fx-eur-cad', from: 'EUR', to: 'CAD', rate: 1.48 },
        { id: 'fx-usd-cad', from: 'USD', to: 'CAD', rate: 1.37 }
      ],
      updated: null
    };
  }

  function load() {
    var s = window.ECCStorage.get(KEY, null);
    if (!s) return defaults();
    if (!Array.isArray(s.pairs) || !s.pairs.length) s.pairs = defaults().pairs;
    s.pairs = s.pairs.filter(function (p) {
      return p && typeof p.from === 'string' && typeof p.to === 'string' && isFinite(p.rate);
    });
    return s;
  }

  function save(s) { window.ECCStorage.set(KEY, s); }

  function esc(t) {
    return String(t).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function uid() {
    return 'fx-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 6);
  }

  function fmtRate(r) {
    var v = Number(r);
    if (!isFinite(v) || v <= 0) return '—';
    return v >= 100 ? v.toFixed(2) : v >= 10 ? v.toFixed(3) : v.toFixed(4);
  }

  /* ---------- rendering ---------- */
  function renderWidget(container) {
    container.classList.add('fx-body');
    if (container.dataset.editing === '1') return;
    var s = load();

    var html = '<div class="fx-list">';
    s.pairs.forEach(function (p) {
      html += '<div class="fx-row">' +
        '<span class="fx-pair mono">' + esc(p.from) + '<span class="fx-arrow">→</span>' + esc(p.to) + '</span>' +
        '<span class="fx-rate mono">1 ' + esc(p.from) + ' = <b>' + fmtRate(p.rate) + '</b> ' + esc(p.to) + '</span>' +
        '<span class="fx-inv">1 ' + esc(p.to) + ' = ' + fmtRate(1 / p.rate) + ' ' + esc(p.from) + '</span>' +
        '</div>';
    });
    html += '</div>';
    if (s.updated) {
      var d = new Date(s.updated);
      html += '<div class="gt-note fx-upd">Rates as of ' +
        d.toLocaleTimeString('en-CA', { hour: '2-digit', minute: '2-digit', hour12: false }) +
        (d.toDateString() === new Date().toDateString() ? '' :
          ' · ' + d.toLocaleDateString('en-CA', { month: 'short', day: 'numeric' })) + '</div>';
    } else {
      html += '<div class="gt-note fx-upd">Manual rates — press ⟳ when online for live rates.</div>';
    }
    html += '<div class="gt-actions">' +
      '<button class="fx-refresh" title="Fetch live reference rates (needs internet)">⟳ Refresh rates</button>' +
      '<button class="fx-edit" title="Edit pairs and rates">✎ Pairs</button></div>' +
      '<div class="gt-note">ECB reference rates via frankfurter.app · works fully offline with your own rates.</div>';
    container.innerHTML = html;

    container.querySelector('.fx-refresh').addEventListener('click', function () { refreshOnline(container); });
    container.querySelector('.fx-edit').addEventListener('click', function () { renderEditor(container); });
  }

  function refreshOnline(container) {
    var btn = container.querySelector('.fx-refresh');
    if (btn) btn.textContent = '⟳ Fetching…';
    var s = load();
    var chain = Promise.resolve();
    var ok = 0;
    s.pairs.forEach(function (p) {
      chain = chain.then(function () {
        return fetch(API + encodeURIComponent(p.from) + '&to=' + encodeURIComponent(p.to))
          .then(function (r) {
            if (!r.ok) throw new Error('HTTP ' + r.status);
            return r.json();
          })
          .then(function (d) {
            var v = d && d.rates && d.rates[p.to];
            if (!isFinite(v) || v <= 0) throw new Error(p.to + ' not found');
            p.rate = v;
            ok++;
          });
      });
    });
    chain.then(function () {
      s.updated = new Date().toISOString();
      save(s);
      if (window.ECCToast) window.ECCToast('Updated ' + ok + ' rate(s) from ECB reference rates');
      renderAll();
    }).catch(function (e) {
      if (btn) btn.textContent = '⟳ Refresh rates';
      if (window.ECCToast) window.ECCToast('Online rates unavailable — keeping your rates (' +
        (e && e.message ? e.message : 'offline') + ')');
    });
  }

  function renderEditor(container) {
    var s = load();
    container.dataset.editing = '1';
    var rows = s.pairs.map(function (p, i) {
      return '<div class="fx-edit-row" data-i="' + i + '">' +
        '<input class="fxe-from" maxlength="3" value="' + esc(p.from) + '" title="From (e.g. EUR)">' +
        '<span class="fx-arrow">→</span>' +
        '<input class="fxe-to" maxlength="3" value="' + esc(p.to) + '" title="To (e.g. CAD)">' +
        '<input type="number" step="any" min="0" class="fxe-rate" value="' + p.rate + '" title="Manual rate (1 FROM = rate TO)">' +
        '<button class="fxe-del" title="Remove pair">✕</button></div>';
    }).join('');
    container.innerHTML =
      '<div class="st-form">' + rows +
      '<div class="gt-actions" style="margin-top:6px">' +
      '<button class="fx-add">＋ Add pair</button>' +
      '<button class="fx-save">💾 Save</button>' +
      '<button class="fx-cancel">Cancel</button></div>' +
      '<div class="gt-note">3-letter codes (EUR, CAD, USD, GBP…). Type the rate yourself, or leave it — ⟳ fills it when online.</div></div>';

    container.querySelectorAll('.fxe-del').forEach(function (b) {
      b.addEventListener('click', function () { b.closest('.fx-edit-row').remove(); });
    });
    container.querySelector('.fx-add').addEventListener('click', function () {
      var row = document.createElement('div');
      row.className = 'fx-edit-row';
      row.innerHTML =
        '<input class="fxe-from" maxlength="3" value="EUR">' +
        '<span class="fx-arrow">→</span>' +
        '<input class="fxe-to" maxlength="3" value="CAD">' +
        '<input type="number" step="any" min="0" class="fxe-rate" placeholder="rate">' +
        '<button class="fxe-del" title="Remove pair">✕</button>';
      row.querySelector('.fxe-del').addEventListener('click', function () { row.remove(); });
      container.querySelector('.st-form').insertBefore(row, container.querySelector('.gt-actions'));
    });
    container.querySelector('.fx-save').addEventListener('click', function () {
      var s2 = load();
      var out = [];
      container.querySelectorAll('.fx-edit-row').forEach(function (row) {
        var from = row.querySelector('.fxe-from').value.trim().toUpperCase();
        var to = row.querySelector('.fxe-to').value.trim().toUpperCase();
        if (!/^[A-Z]{3}$/.test(from) || !/^[A-Z]{3}$/.test(to) || from === to) return;
        var rate = parseFloat(row.querySelector('.fxe-rate').value);
        var old = s2.pairs.filter(function (p) { return p.from === from && p.to === to; })[0];
        out.push({
          id: old ? old.id : uid(),
          from: from, to: to,
          rate: isFinite(rate) && rate > 0 ? rate : (old ? old.rate : 1)
        });
      });
      if (!out.length) out = s2.pairs;
      s2.pairs = out;
      save(s2);
      container.dataset.editing = '0';
      renderAll();
      if (window.ECCToast) window.ECCToast('Pairs saved');
    });
    container.querySelector('.fx-cancel').addEventListener('click', function () {
      container.dataset.editing = '0';
      renderWidget(container);
    });
  }

  function renderAll() {
    document.querySelectorAll('.fx-body').forEach(function (el) {
      el.dataset.editing = '0';
      renderWidget(el);
    });
  }

  window.ECCForex = {
    renderWidget: renderWidget,
    renderAll: renderAll,
    load: load
  };
})();

/* ECC Pro v1.7 — support-plugin registration. Active when this file is
   loaded from the support/ folder (the core defines ECCPlugins first);
   harmless if the module is bundled some other way. */
if (window.ECCPlugins) {
  window.ECCPlugins.register({
    id: 'forex', name: 'Currency', file: 'forex.js',
    icon: '💱', color: '#f59e0b', w: 3, h: 8,
    render: function (el) { window.ECCForex.renderWidget(el); }
  });
}
