# Vườn Cây - Android WebView Edition

Đây là project Android Studio đóng gói bản `Vuon-Cay-Performance-Edition.html` vào WebView.

## Tính năng app
- Fullscreen ngang.
- Chạy offline từ assets.
- JavaScript + localStorage/DOM storage được bật để game giữ save.
- Back button hoạt động.
- Không cần server riêng.
- Hardware acceleration của WebView được bật; bản game đã được tối giản hiệu ứng để ưu tiên FPS.

## Build APK bằng Android Studio
1. Giải nén project.
2. Mở thư mục `VuonCayAndroid` bằng Android Studio.
3. Chờ Gradle Sync.
4. Chọn `Build > Build APK(s)`.
5. APK debug nằm trong `app/build/outputs/apk/debug/`.

Nếu Android Studio hỏi cài Android SDK 35 hoặc Gradle plugin, cho phép cài/sync.
