import { getStore } from "@netlify/blobs";
import crypto from "node:crypto";
import nodemailer from "nodemailer";

const blank = { messages: [], applications: [], market: [], jobs: [], community: [], payments: [], uploads: [], users: [] };
const MAX_BODY = 5 * 1024 * 1024;
const RATE = new Map();

function json(data, status=200, extra={}) { return new Response(JSON.stringify(data), { status, headers: { "content-type":"application/json; charset=utf-8", "cache-control":"no-store", "x-content-type-options":"nosniff", "x-frame-options":"DENY", "referrer-policy":"strict-origin-when-cross-origin", "permissions-policy":"camera=(), microphone=(), geolocation=()", ...extra } }); }
function clean(v, n=3000){ return String(v ?? "").trim().slice(0,n); }
function getDbStore(){
  const siteID = process.env.SITE_ID || process.env.NETLIFY_SITE_ID || undefined;
  return siteID ? getStore("tayode-data", { siteID }) : getStore("tayode-data");
}
async function db(){
  const store = getDbStore();
  try { return { ...blank, ...(await store.get("db", { type:"json" }) || {}) }; }
  catch (e) { console.error("TAYODE DB READ ERROR:", e?.message || e); return structuredClone(blank); }
}
async function save(d){
  const store = getDbStore();
  await store.setJSON("db", d);
}
function parseCookies(req){ return Object.fromEntries((req.headers.get("cookie")||"").split(";").filter(Boolean).map(x=>{const i=x.indexOf("="); return [x.slice(0,i).trim(), decodeURIComponent(x.slice(i+1))]})); }
function secret(){ return process.env.SESSION_SECRET || ""; }
function sign(v){ return crypto.createHmac("sha256", secret()).update(v).digest("hex"); }
function sessionToken(){ if(!secret()) return null; const payload=Buffer.from(JSON.stringify({sub:"owner",exp:Date.now()+8*3600e3})).toString("base64url"); return payload+"."+sign(payload); }
function isAdmin(req){ if(!secret()) return false; const t=parseCookies(req).tayode_admin||""; const [p,s]=t.split("."); if(!p||!s||s!==sign(p)) return false; try { return JSON.parse(Buffer.from(p,"base64url").toString()).exp>Date.now(); } catch { return false; } }
function rate(req,key,limit=20,windowMs=60000){ const ip=req.headers.get("x-nf-client-connection-ip")||"unknown", k=ip+":"+key, now=Date.now(), a=(RATE.get(k)||[]).filter(t=>now-t<windowMs); a.push(now); RATE.set(k,a); return a.length<=limit; }
async function body(req){ const text=await req.text(); if(text.length>MAX_BODY) throw Object.assign(new Error("Request too large"),{status:413}); return text?JSON.parse(text):{}; }
async function email(subject,text,to=process.env.OWNER_EMAIL){ if(!process.env.SMTP_HOST||!process.env.SMTP_USER||!process.env.SMTP_PASS||!to) return false; try { const tr=nodemailer.createTransport({host:process.env.SMTP_HOST,port:Number(process.env.SMTP_PORT||587),secure:process.env.SMTP_SECURE==="true",auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASS}}); await tr.sendMail({from:process.env.SMTP_FROM||process.env.SMTP_USER,to,subject,text}); return true; } catch(e){ console.error(e.message); return false; } }
function addRecord(d,type,data){ const x={id:crypto.randomUUID(),type,createdAt:new Date().toISOString(),...Object.fromEntries(Object.entries(data).map(([k,v])=>[k,clean(v)]))}; d.messages.push(x); if(["professional","unprofessional"].includes(type)) d.applications.push(x); if(type==="seller") d.market.push(x); if(type==="employer") d.jobs.push(x); return x; }

export default async (req) => {
 try {
  const u=new URL(req.url), path=u.pathname.replace(/^\/.netlify\/functions\/api/,"").replace(/^\/api/,"")||"/";
  const method=req.method.toUpperCase();
  if(!rate(req,path,method==="GET"?120:30)) return json({error:"Too many requests. Jaribu tena baadaye."},429);
  if(method==="GET"&&path==="/health") return json({ok:true,service:"tayode-api",blobsConfigured:Boolean(process.env.SITE_ID||process.env.NETLIFY_SITE_ID)});
  const d=await db();

  if(method==="GET"&&path==="/listings") return json({items:d.market.slice(-100).reverse()});
  if(method==="GET"&&path==="/community") return json({items:d.community.slice(-100).reverse()});
  if(method==="GET"&&path==="/payment-status") { const id=clean(u.searchParams.get("id"),100); const p=d.payments.find(x=>x.id===id); if(!p)return json({error:"Payment not found"},404); return json({status:p.status,module:p.module,expiresAt:p.expiresAt||null}); }

  if(method==="POST"&&path==="/payments"){
   const x=await body(req), amount=Number(x.amount);
   if(![700,400].includes(amount)||!["market","chat"].includes(x.module)) return json({error:"Kiasi au module si sahihi"},400);
   if(clean(x.reference,120).length<4||clean(x.payerPhone,40).length<7)return json({error:"Transaction reference na namba ya simu vinahitajika"},400);
   const p={id:crypto.randomUUID(),module:x.module,amount,reference:clean(x.reference,120),payerPhone:clean(x.payerPhone,40),createdAt:new Date().toISOString(),status:"PENDING_REVIEW"}; d.payments.push(p); await save(d); email(`TAYODE Payment ${amount}`,JSON.stringify(p,null,2)); return json({ok:true,id:p.id,status:p.status},201);
  }
  if(method==="POST"&&path==="/submit"){
   const x=await body(req), type=clean(x.type,50); delete x.type;
   if(!["seller","buyer","professional","unprofessional","employer","opportunity","marketing","contact"].includes(type))return json({error:"Aina ya ombi haijatambuliwa"},400);
   if((type==="professional"||type==="unprofessional") && Number(x.age)<18)return json({error:"Mtumiaji lazima awe 18+"},400);
   const rec=addRecord(d,type,x); await save(d); email(`TAYODE — ${type}`,JSON.stringify(rec,null,2)); return json({ok:true,id:rec.id},201);
  }
  if(method==="POST"&&path==="/community"){
   const x=await body(req); if(!clean(x.message,500))return json({error:"Ujumbe unahitajika"},400); const rec={id:crypto.randomUUID(),topic:clean(x.topic,80),message:clean(x.message,500),name:clean(x.name,120)||"User",createdAt:new Date().toISOString()}; d.community.push(rec); await save(d); return json({ok:true},201);
  }
  if(method==="POST"&&path==="/admin/login"){
   if(!process.env.ADMIN_PASSWORD||!secret())return json({error:"ADMIN_PASSWORD na SESSION_SECRET lazima ziwekwe Netlify Environment Variables"},503);
   const x=await body(req); const supplied=Buffer.from(String(x.password||"")); const expected=Buffer.from(String(process.env.ADMIN_PASSWORD));
   const valid=supplied.length===expected.length && crypto.timingSafeEqual(supplied,expected);
   if(!valid)return json({error:"Password si sahihi"},401);
   const token=sessionToken(); return json({ok:true},200,{"set-cookie":`tayode_admin=${encodeURIComponent(token)}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=28800`});
  }
  if(path.startsWith("/admin/")){
   if(!isAdmin(req))return json({error:"Owner login required"},401);
   if(method==="GET"&&path==="/admin/dashboard")return json({counts:{messages:d.messages.length,applications:d.applications.length,market:d.market.length,jobs:d.jobs.length,payments:d.payments.length},messages:d.messages.slice(-200).reverse(),payments:d.payments.slice(-200).reverse()});
   if(method==="POST"&&path==="/admin/payment"){
    const x=await body(req), p=d.payments.find(z=>z.id===x.id); if(!p)return json({error:"Payment not found"},404); if(!["APPROVE","REJECT"].includes(x.action))return json({error:"Invalid action"},400); p.status=x.action==="APPROVE"?"APPROVED":"REJECTED"; p.reviewedAt=new Date().toISOString(); if(p.status==="APPROVED")p.expiresAt=new Date(Date.now()+2*3600e3).toISOString(); await save(d); return json({ok:true,payment:p});
   }
   if(method==="POST"&&path==="/admin/reply") { const x=await body(req); if(!/^\S+@\S+\.\S+$/.test(String(x.to||""))||!clean(x.message,5000))return json({error:"Email na ujumbe vinahitajika"},400); await email("TAYODE Company — Reply",clean(x.message,5000),clean(x.to,200)); return json({ok:true}); }
  }
  if(method==="POST"&&path==="/upload"){
   const x=await body(req); if(!x.name||!x.data)return json({error:"File name/data missing"},400); const raw=String(x.data).replace(/^data:[^;]+;base64,/,''); if(raw.length>4*1024*1024*1.4)return json({error:"File kubwa. Maximum 4MB."},413); const allowed=/\.(pdf|doc|docx|jpg|jpeg|png|webp)$/i; if(!allowed.test(x.name))return json({error:"File type hairuhusiwi"},400);
   const ct=clean(x.contentType,100).toLowerCase(); const ext=String(x.name).toLowerCase().split(".").pop();
   const typeMap={pdf:"application/pdf",doc:"application/msword",docx:"application/vnd.openxmlformats-officedocument.wordprocessingml.document",jpg:"image/jpeg",jpeg:"image/jpeg",png:"image/png",webp:"image/webp"};
   if(typeMap[ext]&&ct&&ct!==typeMap[ext])return json({error:"File type haifanani na extension"},400); const id=crypto.randomUUID(), key=`uploads/${id}-${clean(x.name,100).replace(/[^a-zA-Z0-9._-]/g,'_')}`; await store.set(key,Buffer.from(raw,"base64"),{metadata:{contentType:clean(x.contentType,100)||"application/octet-stream"}}); d.uploads.push({id,name:clean(x.name,120),key,createdAt:new Date().toISOString()}); await save(d); return json({ok:true,id,name:clean(x.name,120)} ,201);
  }
  return json({error:"Not found"},404);
 } catch(e){ console.error(e); return json({error:e.status===413?e.message:"Server error"},e.status||500); }
};
