# TAYODE Android App

Hii ni Android wrapper rasmi ya TAYODE. Inatumia mfumo ule ule wa TAYODE ulioko Netlify, hivyo Website na Android App hutumia backend/API/database moja.

## Kabla ya kujenga APK

Fungua:
`app/build.gradle`

Badilisha:
`https://YOUR-TAYODE-SITE.netlify.app/`

kuwa URL halisi ya TAYODE baada ya kui-deploy Netlify, kwa mfano:
`https://tayode-company.netlify.app/`

Kisha fungua folder `android/` kwenye Android Studio na Build > Build APK(s).

## Muhimu
- App haihitaji Chrome kuonyeshwa kwa mtumiaji; inafunguka kama Android App.
- Internet inahitajika kwa login, chat, payments na data ya server.
- Website inaweza kutumika sambamba kupitia Chrome/browser.
- Mabadiliko ya website yanaonekana pia kwenye App kwa sababu App ina-load TAYODE URL ile ile.
- Usihifadhi API secrets ndani ya Android code. Secrets zibaki Netlify Environment Variables.
