window.TAYODE_PLATFORM = { isAndroidWebView: /; wv\)/i.test(navigator.userAgent) || /TAYODEAndroid/i.test(navigator.userAgent) };
