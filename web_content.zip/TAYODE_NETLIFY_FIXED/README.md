# TAYODE Company — Netlify Ready — V2.1

Version hii imeandaliwa kwa Netlify: static website/PWA + Netlify Function + Netlify Blobs persistent storage.

## Features
- Marketplace TSh 700 / saa 2
- Community Chat TSh 400 / saa 2
- Manual payment verification: PENDING_REVIEW → APPROVED/REJECTED
- Owner Dashboard + secure signed HttpOnly cookie
- Persistent data kupitia Netlify Blobs
- SMTP notifications/replies (optional)
- CV/product image upload hadi 4MB kupitia Netlify Blobs
- Input validation, rate limiting, security headers
- PWA manifest + service worker

## Payment
Tigo/Yas: 0775 058 045 (website inaonyesha ******8045)
HaloPesa: 0622658045 (website inaonyesha ******8045)

API za payment hazijawekwa kwa sababu hakuna credentials/API provider iliyotolewa. Mfumo haujifanyi payment kuwa verified: access inafunguliwa tu baada ya Owner ku-APPROVE.

## Netlify Environment Variables
REQUIRED:
- ADMIN_PASSWORD
- SESSION_SECRET
- OWNER_EMAIL

OPTIONAL SMTP:
- SMTP_HOST
- SMTP_PORT
- SMTP_SECURE
- SMTP_USER
- SMTP_PASS
- SMTP_FROM

Usiweke secrets ndani ya code au netlify.toml. Weka kwenye Netlify Project configuration → Environment variables.

## Deploy
1. Unzip ZIP hii.
2. Upload project kwa GitHub au Netlify manual deploy.
3. Netlify itatumia `public` kama publish directory na `netlify/functions` kama Functions directory.
4. Weka environment variables zilizoorodheshwa juu.
5. Redeploy baada ya kuweka variables.
6. Fungua website na test payment: submit reference → Owner Dashboard → APPROVE → user refreshes/checks status.

## Local
Node.js 20+
`npm install`
`npm start`

## Important
Netlify Functions zina default endpoint `/.netlify/functions/api`, na `netlify.toml` inafanya route `/api/*` kwenda function hiyo. Data ya TAYODE haitegemei local JSON file; inahifadhiwa persistent kwenye Netlify Blobs.

## Android App
Folder `android/` ni Android Studio project ya TAYODE. Inatumia Website/API ile ile ya Netlify, kwa hiyo App na Browser zina account, payments, marketplace na community data moja. Kabla ya build, badilisha `TAYODE_WEB_URL` kwenye `android/app/build.gradle` iwe Netlify URL yako halisi.


## Fix ya Server Error / Deployment
- Upload **folder nzima `tayode_build`**, si `public` peke yake.
- Hakikisha Netlify Build settings zina Publish directory `public` na Functions directory `netlify/functions`.
- Endpoint ya afya ni `/api/health`; inapaswa kurudisha `ok: true`.
- Baada ya kubadilisha Environment Variables, fanya redeploy.

## V2.1 Audit fixes
- Owner login no longer throws a 500 when an incorrect password has a different length; it returns 401.
- Upload validation checks extension/content-type consistency.
- PWA cache version is bumped and stale caches are removed.
- Visual system upgraded for mobile-first presentation using TAYODE Black, Deep Blue, Gold and Deep Green.
- `/api/health` remains the first deployment smoke test.

## Production scaling note
Netlify Blobs JSON storage is retained for this MVP because it is simple and persistent, but a single JSON document is not the correct final datastore for 100,000–1,000,000 concurrent users. Before national/Africa scale, migrate core records to a transactional database with indexes, constraints and atomic writes. Do not scale the current JSON blob architecture blindly.
