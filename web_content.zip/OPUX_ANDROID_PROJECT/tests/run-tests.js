'use strict';
const path = require('path');
const J = path.join(__dirname, '../app/src/main/assets/js/');
const OT = require(J + 'opux-time.js'), OC = require(J + 'opux-core.js'), RD = require(J + 'opux-rdbd.js'), OE = require(J + 'opux-engine.js');
let pass = 0, fail = 0; const failures = [];
function t(name, fn) { try { fn(); pass++; console.log('PASS ' + name); } catch (e) { fail++; failures.push(name); console.log('FAIL ' + name + '\n     ' + e.message); } }
const eq = (a, b, m) => { if (JSON.stringify(a) !== JSON.stringify(b)) throw new Error((m || 'eq') + ': got ' + JSON.stringify(a) + ' expected ' + JSON.stringify(b)); };
const ok = (c, m) => { if (!c) throw new Error(m || 'assertion failed'); };
const near = (a, b, m) => { if (Math.abs(a - b) > 1e-6) throw new Error((m || 'near') + ': got ' + a + ' expected ' + b); };
class Store { constructor() { this.m = {}; this.failWrite = null; } getItem(k) { return k in this.m ? this.m[k] : null; } setItem(k, v) { if (this.failWrite && this.failWrite.test(k)) throw new Error('quota'); this.m[k] = String(v); } removeItem(k) { delete this.m[k]; } }
const TZ = 'Asia/Dhaka', NOW = Date.UTC(2026, 10, 22, 6, 0, 0); // 2026-11-22 12:00 in Dhaka
const W = (ds, h, m, tz) => OT.wall(ds, h, m, tz || TZ);
const legacy = () => ({ acts: [['a0','Study','#3b82f6',1],['a1','Sleep','#22c55e',0],['a2','Entertainment','#f97316',0],['a3','Namaz','#a855f7',0],['a4','Meals','#eab308',0],['a5','Other','#cbd5e1',0],['a6','Wasted','#6b7280',0]].map(a => ({ id: a[0], n: a[1], c: a[2], p: a[3] })).concat([{ id: 'a99', n: 'Reading', c: '#14b8a6', p: 1 }]),
  days: { '2026-10-30': [{ act: 'a1', min: 480, note: 'night' }, { act: 'a0', min: 120.5, note: '' }, { act: 'a6', min: 30, note: '' }],
          '2026-11-01': [{ act: 'a1', min: 1440, note: 'full day' }],
          '2026-11-02': [{ act: 'a0', min: 33.33, note: '' }, { act: 'a99', min: 10.01, note: 'x' }],
          '2028-02-29': [{ act: 'a2', min: 60, note: 'leap' }] },
  theme: 'neon', unit: 'dec', notif: 1, timer: { a: 'a0', d: '2026-11-22', t: NOW - 3600000 } });
const loadFresh = (leg) => { const s = new Store(); if (leg) s.setItem('h24v1', JSON.stringify(leg)); const r = OC.load(s, NOW, TZ); return { s, r }; };

/* ===== 1. migration & data safety ===== */
t('migration: every legacy day total and entry count preserved exactly', () => {
  const leg = legacy(), { s, r } = loadFresh(leg); ok(r.migrated, 'migrated flag'); const db = r.db;
  eq(OC.verifyMigration(leg, db), [], 'verify'); eq(OC.validate(db), [], 'validate');
  eq(db.entries.length, 3 + 1 + 2 + 1, 'entries');
  const tot = d => Math.round(db.entries.filter(e => e.localDate === d).reduce((x, e) => x + (e.endUtc - e.startUtc) / 60000, 0) * 100) / 100;
  eq(tot('2026-10-30'), 630.5); eq(tot('2026-11-01'), 1440); eq(tot('2026-11-02'), 43.34); eq(tot('2028-02-29'), 60);
});
t('migration: all migrated records are legacyPlaced + CONFIRMED + source legacy; sequential from local midnight', () => {
  const db = loadFresh(legacy()).r.db, es = db.entries.filter(e => e.localDate === '2026-10-30').sort((a, b) => a.startUtc - b.startUtc);
  ok(db.entries.every(e => e.legacyPlaced === true && e.state === 'CONFIRMED' && e.source === 'legacy'));
  eq(es[0].startUtc, OT.midnight('2026-10-30', TZ)); eq(es[1].startUtc, es[0].endUtc); eq(es[0].origMin, 480);
});
t('migration: legacy key h24v1 is never modified; byte-identical backup written', () => {
  const leg = legacy(), raw = JSON.stringify(leg), { s, r } = loadFresh(leg);
  eq(s.getItem('h24v1'), raw); const bk = Object.keys(s.m).find(k => k.startsWith('opux_backup_h24v1_')); ok(bk, 'backup key'); eq(s.getItem(bk), raw);
});
t('migration: settings, custom activity and running timer carried over', () => {
  const db = loadFresh(legacy()).r.db; eq(db.settings.theme, 'neon'); eq(db.settings.unit, 'dec'); eq(db.settings.notif, 1);
  eq(db.activities.find(a => a.id === 'a99').cat, 'other'); eq(db.activities.find(a => a.id === 'a99').productive, 1);
  eq(db.activities.find(a => a.id === 'a6').cat, 'unwanted'); eq(db.timer.actId, 'a0'); eq(db.timer.startUtc, NOW - 3600000);
});
t('migration: second launch loads opux_v2 and does not re-migrate', () => {
  const { s, r } = loadFresh(legacy()); const n = Object.keys(s.m).length; const r2 = OC.load(s, NOW + 1000, TZ);
  ok(!r2.migrated); eq(Object.keys(s.m).length, n, 'no new keys'); eq(r2.db.entries.length, r.db.entries.length);
});
t('migration: unparseable legacy data -> untouched, backup kept, fresh DB, notice shown', () => {
  const s = new Store(); s.setItem('h24v1', '{not json'); const r = OC.load(s, NOW, TZ);
  eq(s.getItem('h24v1'), '{not json'); ok(r.migrationFailed && r.notices.length); eq(r.db.entries.length, 0);
  ok(Object.keys(s.m).some(k => k.startsWith('opux_backup_h24v1_')));
  ok(!s.getItem('opux_v2'), 'must not overwrite/create v2 on failure');
});
t('migration: legacy day >24h is rejected, data untouched', () => {
  const l = legacy(); l.days['2026-11-03'] = [{ act: 'a0', min: 1441, note: '' }]; const { s, r } = loadFresh(l);
  ok(r.migrationFailed); eq(JSON.parse(s.getItem('h24v1')).days['2026-11-03'][0].min, 1441);
});
t('migration: backup cannot be written -> migration is skipped, legacy untouched', () => {
  const s = new Store(); s.setItem('h24v1', JSON.stringify(legacy())); s.failWrite = /^opux_backup/; const r = OC.load(s, NOW, TZ);
  ok(r.readOnlyLegacy && !s.getItem('opux_v2')); ok(s.getItem('h24v1'));
});
t('corrupted opux_v2: copy preserved, re-migrates from h24v1 with notice', () => {
  const s = new Store(); s.setItem('opux_v2', '{"schema":2,"broken":'); s.setItem('h24v1', JSON.stringify(legacy())); const r = OC.load(s, NOW, TZ);
  ok(r.recovered); ok(Object.keys(s.m).some(k => k.startsWith('opux_v2_corrupt_'))); ok(r.migrated);
});
t('fresh install: empty store gives a valid empty DB', () => { const r = OC.load(new Store(), NOW, TZ); eq(OC.validate(r.db), []); eq(r.db.entries.length, 0); });
t('migration creates one RDBD identity per migrated day with permanent day numbers', () => {
  const db = loadFresh(legacy()).r.db; eq(db.identities.map(i => i.date), ['2026-10-30', '2026-11-01', '2026-11-02', '2028-02-29']);
  eq(db.identities.map(i => i.dayNo), [-1, 1, 2, 486]); eq(RD.dayLabel(-1), 'Pre-002'); eq(RD.dayLabel(1), 'Day 001');
});

/* ===== 2. dates and times ===== */
t('date format: "October 30, 2026 (Friday)" and "November 22, 2026 (Sunday)" computed, not hard-coded', () => {
  eq(OT.fmtDate('2026-10-30'), 'October 30, 2026 (Friday)'); eq(OT.fmtDate('2026-11-22'), 'November 22, 2026 (Sunday)');
  eq(OT.fmtDate('2028-02-29'), 'February 29, 2028 (Tuesday)'); eq(OT.fmtDate('2027-01-01'), 'January 1, 2027 (Friday)');
});
t('weekday correct for a 400-date sweep against Date.UTC', () => {
  for (let i = 0; i < 400; i++) { const d = OT.addDays('2026-01-01', i * 3), a = OT.splitDate(d); eq(OT.weekday(d), new Date(Date.UTC(a[0], a[1] - 1, a[2])).getUTCDay()); }
});
t('leap years and month/year transitions', () => {
  ok(OT.isLeap(2028) && !OT.isLeap(2100) && OT.isLeap(2000)); eq(OT.addDays('2028-02-28', 1), '2028-02-29'); eq(OT.addDays('2027-02-28', 1), '2027-03-01');
  eq(OT.addDays('2026-12-31', 1), '2027-01-01'); eq(OT.daysInMonth(2028, 2), 29); ok(!OT.isDate('2027-02-29'));
});
t('time format 12h/24h examples; switching never changes stored values', () => {
  eq([OT.fmtClock(9, 30, '12'), OT.fmtClock(14, 45, '12'), OT.fmtClock(23, 15, '12')], ['09:30 AM', '02:45 PM', '11:15 PM']);
  eq([OT.fmtClock(9, 30, '24'), OT.fmtClock(14, 45, '24'), OT.fmtClock(23, 15, '24')], ['09:30', '14:45', '23:15']);
  eq([OT.fmtClock(0, 0, '12'), OT.fmtClock(12, 0, '12'), OT.fmtClock(12, 30, '12')], ['12:00 AM', '12:00 PM', '12:30 PM']);
  const db = loadFresh(legacy()).r.db, before = JSON.stringify(db.entries); db.settings.timeFormat = '24'; db.settings.dateFormat = 'iso'; eq(JSON.stringify(db.entries), before);
});
t('local date is not the UTC date: 23:30 UTC on Nov 1 is Nov 2 in Dhaka', () => { const ms = Date.UTC(2026, 10, 1, 23, 30); eq(OT.localDate(ms, 'UTC'), '2026-11-01'); eq(OT.localDate(ms, TZ), '2026-11-02'); eq(OT.localDate(ms, 'America/New_York'), '2026-11-01'); });
t('day length: DST spring 23h, autumn 25h, normal 24h; wall() handles DST gap', () => {
  eq(OT.dayMinutes('2026-03-08', 'America/New_York'), 1380); eq(OT.dayMinutes('2026-11-01', 'America/New_York'), 1500); eq(OT.dayMinutes('2026-06-01', 'America/New_York'), 1440);
  const g = OT.wall('2026-03-08', 2, 30, 'America/New_York'); eq(OT.fmtTime(g, 'America/New_York', '24'), '03:30', 'nonexistent 02:30 moves forward by the gap, like JS Date');
  eq(OT.fmtTime(OT.wall('2026-11-01', 1, 30, 'America/New_York'), 'America/New_York', '24'), '01:30'); ok(OT.wall('2026-11-01', 1, 30, 'America/New_York') < OT.wall('2026-11-01', 2, 0, 'America/New_York'), 'repeated 01:30 resolves to the first occurrence');
});

/* ===== 3. accounting ===== */
t('accounting: 1440-minute invariant; unrecorded time is unknown, never unwanted', () => {
  const db = loadFresh(legacy()).r.db, a = OE.account(db, '2026-10-30');
  ok(a.balanced); near(a.capacityMin, 1440); near(a.confirmedMin, 630.5); near(a.unrecordedMin, 809.5); near(a.unknownMin, 809.5);
  near(a.byCat.unwanted, 30); near(a.byCat.study, 120.5); near(a.byCat.sleep, 480); near(a.productiveMin, 120.5);
  const full = OE.account(db, '2026-11-01'); near(full.confirmedMin, 1440); near(full.unknownMin, 0); ok(full.balanced);
});
t('accounting: DST days balance to their real length', () => {
  const db = OC.fresh(NOW, 'America/New_York'); db.settings.tz = 'America/New_York';
  for (const [ds, cap] of [['2026-03-08', 1380], ['2026-11-01', 1500]]) {
    const w = OT.dayWindow(ds, 'America/New_York'); const r = OE.addEntry(db, { actId: 'a1', startUtc: w.start + 3600000, endUtc: w.start + 5 * 3600000, tz: 'America/New_York' }, NOW);
    ok(r.ok, JSON.stringify(r)); const a = OE.account(db, ds); near(a.capacityMin, cap); ok(a.balanced); near(a.confirmedMin, 240); near(a.unrecordedMin, cap - 240);
  }
});
t('accounting: unwanted/leisure/entertainment/sleep/study reported separately; leisure not unwanted', () => {
  const db = OC.fresh(NOW, TZ); db.activities.push({ id: 'lz', name: 'Walk', color: '#fff', productive: 0, cat: 'leisure' });
  const d = '2026-11-10'; let h = 8;
  for (const [a, mins] of [['a0', 120], ['a1', 60], ['lz', 45], ['a2', 30], ['a6', 15]]) { const s = W(d, h, 0); ok(OE.addEntry(db, { actId: a, startUtc: s, endUtc: s + mins * 60000 }, NOW).ok); h += 3; }
  const r = OE.account(db, d); near(r.byCat.leisure, 45); near(r.byCat.unwanted, 15); near(r.byCat.study, 120); near(r.byCat.sleep, 60); near(r.byCat.entertainment, 30); near(r.productiveMin, 120); ok(r.balanced);
});

/* ===== 4. writing, conflicts, midnight, editing ===== */
t('manual entry: saved with real start/end and identity created; end<=start rejected', () => {
  const db = OC.fresh(NOW, TZ), s = W('2026-11-12', 9, 0); const r = OE.addEntry(db, { actId: 'a0', startUtc: s, endUtc: s + 90 * 60000, note: 'math' }, NOW);
  ok(r.ok && !r.entries[0].legacyPlaced); eq(r.entries[0].localDate, '2026-11-12'); ok(RD.getIdentity(db, '2026-11-12'));
  ok(!OE.addEntry(db, { actId: 'a0', startUtc: s, endUtc: s }, NOW).ok); eq(OC.validate(db), []);
});
t('overlap: rejected by default; fillGaps adds only free spans and reports skipped; replace trims/splits', () => {
  const db = OC.fresh(NOW, TZ), d = '2026-11-12', s = h => W(d, h, 0);
  OE.addEntry(db, { actId: 'a0', startUtc: s(9), endUtc: s(10) }, NOW);
  const rej = OE.addEntry(db, { actId: 'a1', startUtc: s(8), endUtc: s(11) }, NOW); ok(!rej.ok && rej.conflicts.length === 1);
  const fg = OE.addEntry(db, { actId: 'a1', startUtc: s(8), endUtc: s(11) }, NOW, 'fillGaps'); ok(fg.ok); eq(fg.entries.length, 2); eq(fg.skippedMs, 3600000);
  near(OE.account(db, d).confirmedMin, 180); ok(OE.account(db, d).balanced);
  const rp = OE.addEntry(db, { actId: 'a2', startUtc: W(d, 9, 20), endUtc: W(d, 9, 40) }, NOW, 'replace'); ok(rp.ok);
  const a = OE.account(db, d); near(a.confirmedMin, 180); near(a.byActivity.a0, 40); near(a.byActivity.a2, 20);
  eq(OE.timeline(db, d).filter(b => b.type === 'OVERLAP').length, 0); eq(OC.validate(db), []);
});
t('midnight: 11:00 PM - 01:00 AM counts 60 min on each date, entry belongs to start date', () => {
  const db = OC.fresh(NOW, TZ), s = W('2026-11-12', 23, 0), e = W('2026-11-13', 1, 0);
  const r = OE.addEntry(db, { actId: 'a1', startUtc: s, endUtc: e }, NOW); ok(r.ok); eq(r.entries[0].localDate, '2026-11-12');
  near(OE.account(db, '2026-11-12').byActivity.a1, 60); near(OE.account(db, '2026-11-13').byActivity.a1, 60); ok(OE.account(db, '2026-11-13').balanced);
  eq(OE.timeline(db, '2026-11-13')[0].type, 'CONFIRMED');
});
t('midnight crossing across a month and year boundary', () => {
  const db = OC.fresh(NOW, TZ), s = W('2026-12-31', 22, 0), e = W('2027-01-01', 2, 0); OE.addEntry(db, { actId: 'a1', startUtc: s, endUtc: e }, NOW);
  near(OE.account(db, '2026-12-31').byActivity.a1, 120); near(OE.account(db, '2027-01-01').byActivity.a1, 120);
});
t('timer: persists through serialisation (app kill), crosses midnight, saves one entry with exact minutes', () => {
  let db = OC.fresh(NOW, TZ); const start = W('2026-11-12', 22, 30); ok(OE.timerStart(db, 'a0', start).ok); ok(!OE.timerStart(db, 'a1', start).ok);
  db = JSON.parse(JSON.stringify(db)); const stop = W('2026-11-13', 1, 15); const r = OE.timerStop(db, stop);
  ok(r.ok && r.entries.length === 1 && db.timer === null); near((r.entries[0].endUtc - r.entries[0].startUtc) / 60000, 165);
  near(OE.account(db, '2026-11-12').byActivity.a0, 90); near(OE.account(db, '2026-11-13').byActivity.a0, 75);
});
t('timer: stopping over existing records fills only free time and reports the rest', () => {
  const db = OC.fresh(NOW, TZ), d = '2026-11-12'; OE.addEntry(db, { actId: 'a1', startUtc: W(d, 10, 0), endUtc: W(d, 11, 0) }, NOW);
  OE.timerStart(db, 'a0', W(d, 9, 0)); const r = OE.timerStop(db, W(d, 12, 0)); ok(r.ok); eq(r.skippedMs, 3600000); near(OE.account(db, d).byActivity.a0, 120);
});
t('historical editing: edit changes statistics; user-set time clears legacyPlaced', () => {
  const db = loadFresh(legacy()).r.db; const e = db.entries.find(x => x.localDate === '2026-10-30' && x.actId === 'a0');
  const r = OE.updateEntry(db, e.id, { startUtc: W('2026-10-30', 14, 0), endUtc: W('2026-10-30', 15, 0) }, NOW); ok(r.ok, JSON.stringify(r));
  ok(!e.legacyPlaced); near(OE.account(db, '2026-10-30').byActivity.a0, 60); ok(OE.account(db, '2026-10-30').balanced);
  eq(OE.updateEntry(db, e.id, { startUtc: W('2026-10-30', 3, 0), endUtc: W('2026-10-30', 4, 0) }, NOW).ok, false, 'overlap with sleep must be refused');
});
t('split, merge, reclassify, delete', () => {
  const db = OC.fresh(NOW, TZ), d = '2026-11-12', r = OE.addEntry(db, { actId: 'a0', startUtc: W(d, 9, 0), endUtc: W(d, 11, 0) }, NOW), id = r.entries[0].id;
  const sp = OE.split(db, id, W(d, 10, 0), NOW); ok(sp.ok); near(OE.account(db, d).confirmedMin, 120);
  ok(OE.reclassify(db, sp.second.id, 'a2', NOW).ok); ok(!OE.merge(db, sp.first.id, sp.second.id, NOW).ok);
  ok(OE.reclassify(db, sp.second.id, 'a0', NOW).ok); ok(OE.merge(db, sp.first.id, sp.second.id, NOW).ok); eq(db.entries.length, 1); near((db.entries[0].endUtc - db.entries[0].startUtc) / 60000, 120);
  ok(OE.deleteEntry(db, id, NOW)); eq(db.entries.length, 0);
});

/* ===== 5. clarification & matching ===== */
t('gap question text uses selected time format: 12h and 24h', () => {
  const db = OC.fresh(NOW, TZ), d = '2026-11-12'; OE.addEntry(db, { actId: 'a1', startUtc: W(d, 0, 0), endUtc: W(d, 9, 0) }, NOW); OE.addEntry(db, { actId: 'a0', startUtc: W(d, 11, 0), endUtc: W(d, 13, 0) }, NOW);
  const now = W(d, 13, 0), q = OE.questions(db, now, 'open', { dates: [d] }).filter(x => x.type === 'GAP');
  eq(q[0].text, 'What did you do between 09:00 AM and 11:00 AM?'); db.settings.timeFormat = '24'; eq(OE.questions(db, now, 'open', { dates: [d] })[0].text, 'What did you do between 09:00 and 11:00?');
});
t('gaps: only for meaningful periods (>= threshold) and never into the future', () => {
  const db = OC.fresh(NOW, TZ), d = '2026-11-12'; OE.addEntry(db, { actId: 'a0', startUtc: W(d, 9, 0), endUtc: W(d, 9, 50) }, NOW); OE.addEntry(db, { actId: 'a0', startUtc: W(d, 10, 0), endUtc: W(d, 11, 0) }, NOW);
  const q = OE.questions(db, W(d, 11, 5), 'open', { dates: [d] }).filter(x => x.type === 'GAP'); eq(q.length, 1, 'only the pre-09:00 gap (10 min gap and 5 min tail ignored)'); eq(q[0].end, W(d, 9, 0));
  ok(OE.questions(db, W(d, 11, 5), 'open', { dates: [d] }).every(x => x.end <= W(d, 11, 5)));
});
t('no interruptions while a timer runs (open/reminder); explicit review still lists everything', () => {
  const db = OC.fresh(NOW, TZ), d = '2026-11-12'; OE.timerStart(db, 'a0', W(d, 13, 0)); const now = W(d, 14, 0);
  eq(OE.questions(db, now, 'open', { dates: [d] }), []); eq(OE.questions(db, now, 'reminder', { dates: [d] }), []);
  const rv = OE.questions(db, now, 'review', { dates: [d] }); ok(rv.length > 0); ok(rv.every(x => x.end <= W(d, 13, 0)), 'review must not claim the running timer span is a gap');
});
t('answerGap: existing activity / new activity / custom description / unknown / skip', () => {
  const db = OC.fresh(NOW, TZ), d = '2026-11-12', now = W(d, 20, 0); let qs = OE.questions(db, now, 'open', { dates: [d] }); eq(qs.length, 1);
  const g = qs[0]; eq(g.start, W(d, 0, 0)); const q = OE.answerGap(db, g, { kind: 'activity', actId: 'a1', start: g.start, end: W(d, 7, 0) }, NOW); ok(q.ok);
  qs = OE.questions(db, now, 'open', { dates: [d] }); const g2 = qs[0]; eq(g2.start, W(d, 7, 0));
  ok(OE.answerGap(db, g2, { kind: 'newActivity', name: 'Gym', end: W(d, 9, 0) }, NOW).ok); ok(db.activities.some(a => a.name === 'Gym'));
  qs = OE.questions(db, now, 'open', { dates: [d] }); ok(OE.answerGap(db, qs[0], { kind: 'description', desc: 'Visited relatives', end: W(d, 12, 0) }, NOW).ok);
  qs = OE.questions(db, now, 'open', { dates: [d] }); ok(OE.answerGap(db, qs[0], { kind: 'unknown', end: W(d, 15, 0) }, NOW).ok);
  const a = OE.account(db, d); near(a.unknownMarkedMin, 180); near(a.customMin, 180); near(a.byCat.unwanted, 0);
  qs = OE.questions(db, now, 'open', { dates: [d] }); const sk = OE.answerGap(db, qs[0], { kind: 'skip' }, NOW); ok(sk.ok);
  eq(OE.questions(db, now, 'open', { dates: [d] }).length, 0, 'skipped: not re-asked on open'); eq(OE.questions(db, now, 'review', { dates: [d] }).length, 1, 'still visible in review');
  eq(OE.questions(db, now + 25 * 3600000, 'open', { dates: [d] }).length, 1, 're-asked after 24 h'); ok(OE.account(db, d).balanced);
  ok(!OE.answerGap(db, qs[0], { kind: 'activity', actId: 'a0', end: qs[0].end + 1 }, NOW).ok, 'cannot answer beyond the gap');
});
t('matching: study 08:00-10:00 + detected 09:00-09:20 adds NO time; attach prevents duplicates', () => {
  const db = OC.fresh(NOW, TZ), d = '2026-11-12'; const st = OE.addEntry(db, { actId: 'a0', startUtc: W(d, 8, 0), endUtc: W(d, 10, 0) }, NOW).entries[0];
  const det = OE.addDetected(db, { startUtc: W(d, 9, 0), endUtc: W(d, 9, 20), app: 'YouTube' }, NOW).entries[0];
  const before = OE.account(db, d); near(before.confirmedMin, 120); near(before.detectedPendingMin, 0); near(before.unknownMin, 1320);
  const m = OE.matchDetected(db, d); eq(m.length, 1); eq(m[0].relation, 'contained'); near(m[0].overlapMin, 20);
  const qs = OE.questions(db, W(d, 10, 30), 'open', { dates: [d] }); ok(qs.some(x => x.type === 'MATCH' && x.text.includes('YouTube')));
  ok(OE.resolveDetected(db, det.id, 'attach', { confirmedId: st.id }, NOW).ok); eq(OE.matchDetected(db, d).length, 0); near(OE.account(db, d).confirmedMin, 120);
  ok(!OE.questions(db, W(d, 10, 30), 'open', { dates: [d] }).some(x => x.type === 'MATCH'));
});
t('matching: confirm detected as different activity requires explicit overlap choice; replace splits study and keeps 24h balance', () => {
  const db = OC.fresh(NOW, TZ), d = '2026-11-12'; OE.addEntry(db, { actId: 'a0', startUtc: W(d, 8, 0), endUtc: W(d, 10, 0) }, NOW);
  const det = OE.addDetected(db, { startUtc: W(d, 9, 0), endUtc: W(d, 9, 20), app: 'YouTube' }, NOW).entries[0];
  const no = OE.resolveDetected(db, det.id, 'confirm', { actId: 'a2' }, NOW); ok(!no.ok && no.conflicts.length === 1);
  ok(OE.resolveDetected(db, det.id, 'confirm', { actId: 'a2', overlap: 'replace' }, NOW).ok);
  const a = OE.account(db, d); near(a.byActivity.a0, 100); near(a.byActivity.a2, 20); near(a.confirmedMin, 120); ok(a.balanced); eq(OE.timeline(db, d).filter(b => b.type === 'OVERLAP').length, 0);
});
t('detected only (no manual record): counted as unknown/pending, not as an activity; dismiss removes the question', () => {
  const db = OC.fresh(NOW, TZ), d = '2026-11-12'; const det = OE.addDetected(db, { startUtc: W(d, 14, 0), endUtc: W(d, 14, 45), app: 'Chrome' }, NOW).entries[0];
  const a = OE.account(db, d); near(a.detectedPendingMin, 45); near(a.confirmedMin, 0); near(a.unknownMin, 1440);
  const tl = OE.timeline(db, d); ok(tl.some(b => b.type === 'DETECTED'));
  ok(OE.questions(db, W(d, 16, 0), 'open', { dates: [d] }).some(x => x.type === 'DETECTED')); ok(OE.resolveDetected(db, det.id, 'dismiss', {}, NOW).ok);
  ok(!OE.questions(db, W(d, 16, 0), 'open', { dates: [d] }).some(x => x.type === 'DETECTED'));
});
t('timeline review distinguishes CONFIRMED / DETECTED / UNKNOWN / OVERLAP / GAP', () => {
  const db = OC.fresh(NOW, TZ), d = '2026-11-12', s = h => W(d, h, 0); OE.addEntry(db, { actId: 'a1', startUtc: s(0), endUtc: s(6) }, NOW); OE.addEntry(db, { startUtc: s(6), endUtc: s(7), state: 'UNKNOWN' }, NOW);
  OE.addDetected(db, { startUtc: s(8), endUtc: s(9), app: 'Maps' }, NOW);
  db.entries.push({ id: 'x1', actId: 'a0', desc: '', startUtc: s(10), endUtc: s(12), tz: TZ, localDate: d, state: 'CONFIRMED', source: 'import', legacyPlaced: false });
  db.entries.push({ id: 'x2', actId: 'a2', desc: '', startUtc: s(11), endUtc: s(13), tz: TZ, localDate: d, state: 'CONFIRMED', source: 'import', legacyPlaced: false });
  const types = OE.timeline(db, d).map(b => b.type); eq(types, ['CONFIRMED', 'UNKNOWN', 'GAP', 'DETECTED', 'GAP', 'CONFIRMED', 'OVERLAP', 'CONFIRMED', 'GAP']);
  const a = OE.account(db, d); ok(a.balanced); near(a.overlapMin, 60); near(a.byActivity.a0, 120, 'overlapped span attributed once, to the earlier entry'); near(a.byActivity.a2, 60);
});
t('suggestions: need >=4 days of REAL times; legacy synthetic times never create patterns; approval required', () => {
  const dbL = loadFresh(legacy()).r.db; eq(OE.suggestions(dbL, NOW), []);
  const db = OC.fresh(NOW, TZ); for (let i = 1; i <= 5; i++) { const d = OT.addDays('2026-11-22', -i); OE.addEntry(db, { actId: 'a0', startUtc: W(d, 16, 0 + i), endUtc: W(d, 18, 0) }, NOW); }
  const sg = OE.suggestions(db, W('2026-11-22', 18, 0)); eq(sg.length, 1); eq(sg[0].text, 'You usually do "Study" around 04:03 PM. Did you do it today?', 'median of starts 16:01..16:05'); eq(sg[0].days, 5);
  const n = db.entries.length; eq(db.entries.length, n, 'suggestion created nothing'); eq(OE.suggestions(db, W('2026-11-22', 10, 0)), [], 'not before the usual time');
  OE.addEntry(db, { actId: 'a0', startUtc: W('2026-11-22', 16, 0), endUtc: W('2026-11-22', 17, 0) }, NOW); eq(OE.suggestions(db, W('2026-11-22', 18, 0)), [], 'already done today');
});
t('timezone change: stored local date/tz of old entries unchanged; new entries use new tz; both display correctly', () => {
  const db = OC.fresh(NOW, 'Asia/Dhaka'); const a = OE.addEntry(db, { actId: 'a0', startUtc: W('2026-11-12', 23, 30, 'Asia/Dhaka'), endUtc: W('2026-11-13', 0, 30, 'Asia/Dhaka'), tz: 'Asia/Dhaka' }, NOW).entries[0];
  db.settings.tz = 'America/New_York'; const b = OE.addEntry(db, { actId: 'a1', startUtc: W('2026-11-13', 20, 0, 'America/New_York'), endUtc: W('2026-11-13', 21, 0, 'America/New_York'), tz: 'America/New_York' }, NOW).entries[0];
  eq(a.localDate, '2026-11-12'); eq(a.tz, 'Asia/Dhaka'); eq(b.localDate, '2026-11-13'); eq(OT.fmtTime(a.startUtc, a.tz, '12'), '11:30 PM'); eq(OT.fmtTime(b.startUtc, b.tz, '12'), '08:00 PM'); eq(OC.validate(db), []);
});

/* ===== 6. RDBD, works, seasons ===== */
t('identities: permanent day numbers, prev/next links, custom names never overwrite others', () => {
  const db = OC.fresh(NOW, TZ); const a = RD.ensureIdentity(db, '2026-11-05', NOW), c = RD.ensureIdentity(db, '2026-11-07', NOW), b = RD.ensureIdentity(db, '2026-11-06', NOW);
  eq([a.dayNo, b.dayNo, c.dayNo], [5, 6, 7]); eq(RD.getIdentity(db, '2026-11-05').next, 'id_2026-11-06'); eq(RD.getIdentity(db, '2026-11-07').prev, 'id_2026-11-06');
  RD.renameIdentity(db, '2026-11-06', 'Loid Forger', NOW); RD.renameIdentity(db, '2026-11-07', 'Loid Forger', NOW);
  eq(RD.displayName(db, '2026-11-05'), 'Loid 005'); eq(RD.displayName(db, '2026-11-06'), 'Loid Forger'); eq(db.identities.length, 3); eq(RD.ensureIdentity(db, '2026-11-06', NOW).dayNo, 6); eq(OC.validate(db), []);
});
t('works: permanent IDs W001.., never reused, rename keeps id; creator identity recorded', () => {
  const db = OC.fresh(NOW, TZ); const w1 = RD.createWork(db, { name: 'Build OPUX' }, NOW, TZ).work, w2 = RD.createWork(db, { name: 'Second' }, NOW, TZ).work;
  eq([w1.id, w2.id], ['W001', 'W002']); eq(w1.startIdentity, 'id_2026-11-22'); ok(!RD.createWork(db, { name: '  ' }, NOW, TZ).ok);
  db.works.splice(1, 1); eq(RD.createWork(db, { name: 'Third' }, NOW, TZ).work.id, 'W003', 'IDs are never reused');
});
t('work continuity: contributions across identities and seasons derive from real entries; deleting an entry updates history', () => {
  const db = OC.fresh(NOW, TZ), w = RD.createWork(db, { name: 'Build OPUX' }, W('2026-11-05', 10, 0), TZ).work;
  const days = ['2026-11-05', '2026-11-06', '2026-12-10', '2027-01-04']; const ids = days.map(d => OE.addEntry(db, { actId: 'a0', startUtc: W(d, 9, 0), endUtc: W(d, 10, 0), workId: w.id }, NOW).entries[0].id);
  eq(RD.contributionDates(db, w.id), days); eq(RD.participants(db, w.id).map(p => p.label), ['Day 005', 'Day 006', 'Day 040', 'Day 065']); near(RD.workMinutes(db, w.id), 240);
  near(RD.workMinutes(db, w.id, '2026-12-01', '2026-12-31'), 60, 'season 002 contribution only'); eq(RD.seasonNoForDate(db, '2027-01-04'), 3);
  OE.deleteEntry(db, ids[1], NOW); eq(RD.contributionDates(db, w.id), ['2026-11-05', '2026-12-10', '2027-01-04']); near(RD.workMinutes(db, w.id), 180);
  RD.addUntimedContribution(db, w.id, '2026-11-20', 'Planned architecture', NOW); eq(RD.contributionDates(db, w.id).length, 4);
  eq(RD.participants(db, w.id)[0].contributed, true); eq(OC.validate(db), []);
});
t('work: creator identity counted as participant even without a logged contribution', () => {
  const db = OC.fresh(NOW, TZ), w = RD.createWork(db, { name: 'X' }, W('2026-11-05', 10, 0), TZ).work; eq(RD.participants(db, w.id).length, 1); eq(RD.participants(db, w.id)[0].contributed, false);
});
t('work status: pause/resume/complete history and completion date', () => {
  const db = OC.fresh(NOW, TZ), w = RD.createWork(db, { name: 'X' }, NOW, TZ).work; RD.setStatus(db, w.id, 'Paused', NOW + 1000, TZ); RD.setStatus(db, w.id, 'Active', NOW + 2000, TZ);
  RD.setStatus(db, w.id, 'Completed', NOW + 86400000 * 3, TZ); eq(w.statusHistory.map(h => h.status), ['created', 'paused', 'resumed', 'completed']); eq(w.completedDate, '2026-11-25'); ok(!RD.setStatus(db, w.id, 'Nope', NOW).ok);
});
t('relations: all four types; self / duplicate / unknown / dependency-cycle rejected', () => {
  const db = OC.fresh(NOW, TZ), a = RD.createWork(db, { name: 'A' }, NOW, TZ).work.id, b = RD.createWork(db, { name: 'B' }, NOW, TZ).work.id, c = RD.createWork(db, { name: 'C' }, NOW, TZ).work.id;
  for (const ty of RD.REL_TYPES) ok(RD.relate(db, ty === 'REPLACES' ? c : b, ty, a, NOW).ok, ty);
  ok(!RD.relate(db, a, 'CONTINUES', a, NOW).ok); ok(!RD.relate(db, b, 'CONTINUES', a, NOW).ok); ok(!RD.relate(db, a, 'CONTINUES', 'W999', NOW).ok);
  ok(RD.relate(db, a, 'DEPENDS_ON', c, NOW).ok, 'A depends on C (B already depends on A)');
  ok(!RD.relate(db, a, 'DEPENDS_ON', b, NOW).ok, 'A->B would close B->A->B'); ok(!RD.relate(db, c, 'DEPENDS_ON', b, NOW).ok, 'C->B would close B->A->C->B'); ok(!RD.relate(db, c, 'DEPENDS_ON', a, NOW).ok, 'C->A would close A->C->A');
  eq(db.relations.filter(r => r.type === 'DEPENDS_ON').length, 2); eq(OC.validate(db), []);
});
t('seasons: Nov 2026=001, Dec=002, Jan 2027=003, Feb=004; pre-anchor = 000; complete only after month ends', () => {
  const db = OC.fresh(NOW, TZ); eq(['2026-11-30', '2026-12-01', '2027-01-15', '2027-02-28', '2028-02-29', '2026-10-31'].map(d => RD.seasonNoForDate(db, d)), [1, 2, 3, 4, 16, 0]);
  eq(RD.monthForSeason(db, 3), '2027-01'); eq(RD.seasonDates(db, 4), { from: '2027-02-01', to: '2027-02-28', days: 28 }); eq(RD.seasonDates(db, 16).to, '2028-02-29');
  ok(!RD.isSeasonComplete(db, 1, W('2026-11-30', 23, 59), TZ)); ok(RD.isSeasonComplete(db, 1, W('2026-12-01', 0, 0), TZ)); eq(RD.seasonTitle(db, 1), 'November 2026'); RD.setSeasonTitle(db, 1, 'The Beginning'); eq(RD.seasonTitle(db, 1), 'The Beginning');
});
t('seasons: month boundary uses LOCAL date: 23:30 UTC Nov 30 is Dec 1 in Dhaka -> Season 002', () => {
  const db = OC.fresh(NOW, TZ), ms = Date.UTC(2026, 10, 30, 19, 0); const e = OE.addEntry(db, { actId: 'a0', startUtc: ms, endUtc: ms + 3600000 }, NOW).entries[0]; eq(e.localDate, '2026-12-01'); eq(RD.seasonNoForDate(db, e.localDate), 2);
});
t('yearbook: only fully completed calendar years with data are offered', () => {
  const db = OC.fresh(NOW, TZ); OE.addEntry(db, { actId: 'a0', startUtc: W('2026-11-12', 9, 0), endUtc: W('2026-11-12', 10, 0) }, NOW); OE.addEntry(db, { actId: 'a0', startUtc: W('2027-03-12', 9, 0), endUtc: W('2027-03-12', 10, 0) }, NOW);
  eq(RD.yearbookYears(db, W('2026-12-30', 9, 0), TZ), []); eq(RD.yearbookYears(db, W('2027-01-01', 9, 0), TZ), [2026]); eq(RD.yearbookYears(db, W('2028-01-01', 9, 0), TZ), [2026, 2027]);
});

/* ===== 7. export / import ===== */
t('export -> import(replace) round trip is lossless; import returns a backup of current data', () => {
  const db = loadFresh(legacy()).r.db; RD.createWork(db, { name: 'W' }, NOW, TZ); const x = JSON.parse(OC.exportJson(db, NOW)); const cur = OC.fresh(NOW, TZ);
  const r = OC.importObject(cur, x, 'replace', NOW); ok(r.ok); eq(JSON.stringify(r.db), JSON.stringify(db)); eq(r.backup, JSON.stringify(cur));
});
t('import: invalid file rejected without changing data', () => { const cur = OC.fresh(NOW, TZ), r = OC.importObject(cur, { format: 'opux-export', db: { schema: 2 } }, 'replace', NOW); ok(!r.ok); const r2 = OC.importObject(cur, { hello: 1 }, 'replace', NOW); ok(!r2.ok); });
t('import legacy 24H TRACKER JSON: merges only days that do not already exist; originals untouched', () => {
  const cur = OC.fresh(NOW, TZ), d = '2026-10-30'; OE.addEntry(cur, { actId: 'a0', startUtc: W(d, 9, 0), endUtc: W(d, 10, 0) }, NOW); const before = JSON.stringify(cur);
  const r = OC.importObject(cur, legacy(), 'mergeMissingDays', NOW); ok(r.ok); eq(JSON.stringify(cur), before, 'input not mutated'); eq(r.added, 3 + 0 + 2 + 1 - 3 + 1 > 0 ? r.added : 0);
  ok(r.db.entries.filter(e => e.localDate === d).length === 1, 'existing day kept as is'); ok(r.db.entries.some(e => e.localDate === '2026-11-01')); eq(OC.validate(r.db), []);
});
t('legacy-compatible export is readable by the original validator', () => {
  const db = loadFresh(legacy()).r.db, j = JSON.parse(OC.exportLegacyCompatible(db)); eq(OC.legacyCheck(j), null); eq(Object.keys(j.days).length, 4);
});

console.log('\n' + pass + ' passed, ' + fail + ' failed'); if (fail) { console.log('FAILED: ' + failures.join(' | ')); process.exit(1); }
