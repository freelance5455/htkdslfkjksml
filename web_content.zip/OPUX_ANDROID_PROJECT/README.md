# OPUX — Android WebView package

This Android Studio project wraps the supplied OPUX HTML tracker locally in Android WebView. It keeps the original HTML app and LocalStorage-based data model; it does not rebuild the tracker in Kotlin.

## Build an APK

1. Upload this project folder to a GitHub repository (or open it in Android Studio).
2. In GitHub, open **Actions → Build OPUX APK → Run workflow**. A push to `main` also triggers a build.
3. Download the `OPUX-debug-apk` artifact from the completed workflow run and install `app-debug.apk` on your Android phone.

For a local Android Studio build, use JDK 17 and Android SDK platform 35, then run `gradle assembleDebug`.

## Notes
- App label: OPUX. Package: `com.opux.tracker`.
- Offline: HTML and logo are bundled in `app/src/main/assets/`. No network permission is requested.
- Persistent tracker records: Android WebView DOM storage / LocalStorage. Export JSON backups from the app's Settings.
- Startup audio: generated with Web Audio API; WebView media playback gesture requirement is disabled. Device audio volume still applies.
- The supplied artwork is used as the app launcher icon and boot-screen logo.
- This is a source project, not a prebuilt or signed release APK.

## Move existing tracker records into OPUX

Chrome and the Android app have separate LocalStorage spaces. Before switching, open the current tracker in Chrome and use **Settings → Export JSON**. After installing OPUX, open **Settings → Import JSON** and select that backup. Your old Chrome data is not deleted.

## v1.2 additions
- Sound effects (tap, add, delete, error, timer saved) use the same Sound switch as the startup sound.
- Glowing liquid balls with a moving highlight; liquid follows the phone tilt.
- Stats > Insights: average sleep, sleep vs target (set in Settings), sleep regularity (sample SD), productive share of awake time, study trend (least-squares slope), study-vs-sleep Pearson r, tracking streak. Each row shows its formula and sample size n.
- "Sleep" means the activity with id a1 (the default Sleep); "Study" means id a0.
- Not tested here: building the APK, and the tilt sensor inside Android WebView.
