/* OPUX data core: versioned schema (v2), validation, safe h24v1 migration, storage, import/export.
   Rules: the legacy 'h24v1' key is NEVER modified or deleted by this module. A raw copy is stored
   before every migration, and migration output is validated against the legacy durations. */
(function (g) {
  'use strict';
  var OT = g.OPUX.time;
  var OC = {};
  OC.SCHEMA = 2;
  OC.KEY = 'opux_v2';
  OC.LEGACY_KEY = 'h24v1';
  OC.STATES = ['CONFIRMED', 'DETECTED', 'UNKNOWN'];
  OC.CATS = ['study', 'sleep', 'leisure', 'entertainment', 'unwanted', 'other'];
  OC.SEASON_ANCHOR = '2026-11';      // Season 001 = November 2026 (specification)
  OC.EPOCH_DATE = '2026-11-01';      // Day 001 = first day of Season 001
  var LEGACY_THEMES = ['classic', 'ocean', 'sunset', 'neon', 'forest', 'pastel'];
  // Legacy default activities, mapped to accounting categories only because the user already had
  // them with those names. Custom legacy activities stay 'other' (never assumed).
  var LEGACY_CAT = { a0: 'study', a1: 'sleep', a2: 'entertainment', a6: 'unwanted' };

  var R2 = function (x) { return Math.round(x * 100) / 100; };

  OC.fresh = function (nowMs, tz) {
    tz = tz || OT.deviceTz();
    var defs = [['a0', 'Study', '#3b82f6', 1], ['a1', 'Sleep', '#22c55e', 0], ['a2', 'Entertainment', '#f97316', 0],
      ['a3', 'Namaz', '#a855f7', 0], ['a4', 'Meals', '#eab308', 0], ['a5', 'Other', '#cbd5e1', 0], ['a6', 'Wasted', '#6b7280', 0]];
    return {
      schema: OC.SCHEMA,
      meta: { createdAt: nowMs || 0, tz: tz, epochDate: OC.EPOCH_DATE, seasonAnchor: OC.SEASON_ANCHOR, migratedFrom: null, migration: null },
      settings: { theme: 'classic', unit: 'hm', notif: 0, dateFormat: 'full', timeFormat: '12', language: 'en',
        quality: 'BALANCED', sound: 1, haptics: 1, reminderTime: null, clarifyMinGapMin: 15, tz: tz },
      activities: defs.map(function (a) { return { id: a[0], name: a[1], color: a[2], productive: a[3], cat: LEGACY_CAT[a[0]] || 'other' }; }),
      entries: [], timer: null,
      identities: [], seasons: [], works: [], contributions: [], relations: [],
      achievements: [], memories: [], legacyArchive: [],
      music: { tracks: [], playlists: [], favourites: [], last: null },
      wheels: [], focus: [], appMap: {}, clarify: { skipped: {}, dismissed: {} },
      counters: { entry: 0, work: 0, activity: 0, relation: 0, contribution: 0, memory: 0, achievement: 0, legacy: 0 },
      log: []
    };
  };

  /* ---------- legacy validation (same rules as the original app) ---------- */
  OC.legacyCheck = function (d) {
    if (!d || typeof d !== 'object' || !Array.isArray(d.acts) || !d.acts.length || !d.days || typeof d.days !== 'object') return 'Not a 24H TRACKER file';
    var ids = {}, i, k, e;
    for (i = 0; i < d.acts.length; i++) {
      var a = d.acts[i];
      if (!a || typeof a.id !== 'string' || typeof a.n !== 'string' || !/^#[0-9a-f]{6}$/i.test(a.c)) return 'Bad activity list';
      ids[a.id] = 1;
    }
    for (k in d.days) {
      if (!/^\d{4}-\d\d-\d\d$/.test(k) || !OT.isDate(k) || !Array.isArray(d.days[k])) return 'Bad day ' + k;
      var t = 0;
      for (i = 0; i < d.days[k].length; i++) {
        e = d.days[k][i];
        if (!e || !ids[e.act] || typeof e.min !== 'number' || !isFinite(e.min) || e.min <= 0) return 'Bad entry on ' + k;
        t += e.min;
      }
      if (t > 1440 + 1e-6) return k + ' exceeds 24 h';
    }
    return null;
  };

  function sumLegacy(d) { var o = {}; for (var k in d.days) o[k] = R2(d.days[k].reduce(function (s, e) { return s + R2(e.min); }, 0)); return o; }

  /** Convert a parsed legacy object into a v2 database. Does not touch storage. */
  OC.migrateLegacyObject = function (leg, nowMs, tz) {
    var err = OC.legacyCheck(leg);
    if (err) return { ok: false, error: err };
    tz = tz || OT.deviceTz();
    var db = OC.fresh(nowMs, tz);
    db.activities = leg.acts.map(function (a) {
      return { id: a.id, name: String(a.n).slice(0, 30), color: a.c, productive: a.p ? 1 : 0, cat: LEGACY_CAT[a.id] || 'other' };
    });
    if (LEGACY_THEMES.indexOf(leg.theme) >= 0) db.settings.theme = leg.theme;
    if (['hm', 'dec', 'min'].indexOf(leg.unit) >= 0) db.settings.unit = leg.unit;
    db.settings.notif = leg.notif ? 1 : 0;
    var dates = Object.keys(leg.days).sort(), nEntries = 0, flagged = [];
    dates.forEach(function (ds) {
      var M = OT.midnight(ds, tz), cap = OT.dayMinutes(ds, tz), pos = 0;
      leg.days[ds].forEach(function (e, idx) {
        var min = R2(e.min), startMs = M + Math.round(pos * 60000), endMs = startMs + Math.round(min * 60000);
        pos = R2(pos + min);
        db.entries.push({
          id: 'e_' + ds + '_' + idx, actId: e.act, desc: '', startUtc: startMs, endUtc: endMs, tz: tz, localDate: ds,
          state: 'CONFIRMED', source: 'legacy', legacyPlaced: true, origMin: min, note: String(e.note || '').slice(0, 200),
          workId: null, createdAt: nowMs || 0, updatedAt: nowMs || 0
        });
        nEntries++;
      });
      if (pos > cap + 1e-6) flagged.push({ date: ds, recordedMin: pos, dayMin: cap });
    });
    db.counters.entry = nEntries;
    if (leg.timer && typeof leg.timer.t === 'number' && db.activities.some(function (a) { return a.id === leg.timer.a; }))
      db.timer = { actId: leg.timer.a, startUtc: leg.timer.t, tz: tz, workId: null };
    db.meta.migratedFrom = OC.LEGACY_KEY;
    db.meta.migration = { at: nowMs || 0, legacyDays: dates.length, legacyEntries: nEntries, dayLengthWarnings: flagged };
    // identities for every migrated day (late import to avoid circular dependency)
    if (g.OPUX.rdbd) dates.forEach(function (ds) { g.OPUX.rdbd.ensureIdentity(db, ds, nowMs); });
    return { ok: true, db: db, report: db.meta.migration };
  };

  /** Verify that every legacy day's total minutes survived migration exactly. */
  OC.verifyMigration = function (leg, db) {
    var want = sumLegacy(leg), got = {}, problems = [];
    db.entries.forEach(function (e) { if (e.source === 'legacy') got[e.localDate] = R2((got[e.localDate] || 0) + e.origMin); });
    Object.keys(want).forEach(function (k) { if (want[k] !== (got[k] || 0)) problems.push(k + ': legacy ' + want[k] + ' min, migrated ' + (got[k] || 0)); });
    Object.keys(got).forEach(function (k) { if (!(k in want)) problems.push(k + ': day not in legacy data'); });
    var nl = 0; for (var k in leg.days) nl += leg.days[k].length;
    var nm = db.entries.filter(function (e) { return e.source === 'legacy'; }).length;
    if (nl !== nm) problems.push('entry count legacy ' + nl + ' vs migrated ' + nm);
    return problems;
  };

  /* ---------- validation of a v2 database ---------- */
  OC.validate = function (db) {
    var errs = [], i, seen;
    if (!db || typeof db !== 'object') return ['not an object'];
    if (db.schema !== OC.SCHEMA) errs.push('schema ' + db.schema);
    ['activities', 'entries', 'identities', 'seasons', 'works', 'contributions', 'relations', 'achievements', 'memories'].forEach(function (k) { if (!Array.isArray(db[k])) errs.push(k + ' missing'); });
    if (errs.length) return errs;
    var acts = {}; seen = {};
    db.activities.forEach(function (a) { if (!a.id || seen[a.id]) errs.push('activity id ' + a.id); seen[a.id] = 1; acts[a.id] = 1; if (OC.CATS.indexOf(a.cat) < 0) errs.push('activity cat ' + a.id); });
    seen = {};
    db.entries.forEach(function (e) {
      if (!e.id || seen[e.id]) errs.push('entry id ' + e.id); seen[e.id] = 1;
      if (!(isFinite(e.startUtc) && isFinite(e.endUtc) && e.endUtc > e.startUtc)) errs.push('entry time ' + e.id);
      if (OC.STATES.indexOf(e.state) < 0) errs.push('entry state ' + e.id);
      if (e.actId && !acts[e.actId]) errs.push('entry activity ' + e.id);
      if (!e.actId && !e.desc && e.state !== 'UNKNOWN') errs.push('entry has no activity or description ' + e.id);
      if (!OT.isDate(e.localDate) || !OT.isValidTz(e.tz)) errs.push('entry date/tz ' + e.id);
    });
    seen = {}; var days = {};
    db.identities.forEach(function (x) { if (seen[x.id]) errs.push('identity id ' + x.id); seen[x.id] = 1; if (days[x.dayNo]) errs.push('dayNo dup ' + x.dayNo); days[x.dayNo] = 1; });
    seen = {};
    db.works.forEach(function (w) { if (!/^W\d{3,}$/.test(w.id) || seen[w.id]) errs.push('work id ' + w.id); seen[w.id] = 1; });
    var wk = seen;
    db.entries.forEach(function (e) { if (e.workId && !wk[e.workId]) errs.push('entry work ' + e.id); });
    db.relations.forEach(function (r) { if (!wk[r.from] || !wk[r.to] || r.from === r.to) errs.push('relation ' + r.id); });
    return errs;
  };

  /* ---------- storage-backed store ---------- */
  function stamp(nowMs) { return new Date(nowMs).toISOString().replace(/[-:.]/g, '').slice(0, 15); }
  /** Load (and if necessary migrate) the database. `store` has getItem/setItem. Never throws. */
  OC.load = function (store, nowMs, tz) {
    var res = { db: null, notices: [], migrated: false, recovered: false };
    var safeGet = function (k) { try { return store.getItem(k); } catch (e) { return null; } };
    var safeSet = function (k, v) { try { store.setItem(k, v); return true; } catch (e) { return false; } };
    var raw2 = safeGet(OC.KEY), rawLeg = safeGet(OC.LEGACY_KEY);
    if (raw2) {
      var db2 = null, errs;
      try { db2 = JSON.parse(raw2); errs = OC.validate(db2); } catch (e) { errs = ['parse error']; }
      if (db2 && !errs.length) { res.db = OC.upgrade(db2); return res; }
      safeSet(OC.KEY + '_corrupt_' + stamp(nowMs), raw2);
      res.notices.push('Stored OPUX data failed validation (' + errs.slice(0, 3).join('; ') + '). A copy was kept under ' + OC.KEY + '_corrupt_*.');
      res.recovered = true;
    }
    if (rawLeg) {
      var leg = null;
      try { leg = JSON.parse(rawLeg); } catch (e) { leg = null; }
      var bk = 'opux_backup_h24v1_' + stamp(nowMs);
      var okBackup = safeSet(bk, rawLeg) && safeGet(bk) === rawLeg;
      if (!okBackup) { res.notices.push('Could not write a backup copy; migration was not performed. Legacy data is untouched.'); res.db = OC.fresh(nowMs, tz); res.readOnlyLegacy = true; return res; }
      var m = leg ? OC.migrateLegacyObject(leg, nowMs, tz) : { ok: false, error: 'legacy data is not valid JSON' };
      if (m.ok) {
        var problems = OC.verifyMigration(leg, m.db).concat(OC.validate(m.db));
        if (!problems.length) {
          m.db.meta.migration.backupKey = bk;
          if (safeSet(OC.KEY, JSON.stringify(m.db))) { res.db = m.db; res.migrated = true; res.notices.push('Imported ' + m.report.legacyDays + ' days from the previous tracker. Backup: ' + bk + '.'); return res; }
          problems = ['could not write new database'];
        }
        res.notices.push('Migration check failed (' + problems.slice(0, 3).join('; ') + '). Legacy data is untouched and backed up as ' + bk + '.');
      } else res.notices.push('Legacy data could not be migrated (' + m.error + '). It is untouched and backed up as ' + bk + '.');
      res.db = OC.fresh(nowMs, tz); res.migrationFailed = true; res.readOnlyLegacy = true; return res;
    }
    res.db = OC.fresh(nowMs, tz); return res;
  };
  /** Forward-compatible fill of missing keys (does not drop unknown keys). */
  OC.upgrade = function (db) {
    var f = OC.fresh(0, db.meta && db.meta.tz);
    Object.keys(f).forEach(function (k) { if (db[k] === undefined) db[k] = f[k]; });
    Object.keys(f.settings).forEach(function (k) { if (db.settings[k] === undefined) db.settings[k] = f.settings[k]; });
    Object.keys(f.counters).forEach(function (k) { if (db.counters[k] === undefined) db.counters[k] = f.counters[k]; });
    return db;
  };
  OC.save = function (store, db) {
    var s = JSON.stringify(db);
    try { store.setItem(OC.KEY, s); return true; } catch (e) { return false; }
  };

  /* ---------- JSON export / import ---------- */
  OC.exportJson = function (db, nowMs) { return JSON.stringify({ format: 'opux-export', schema: OC.SCHEMA, exportedAt: nowMs, db: db }, null, 1); };
  /** Legacy-compatible export (durations only; times are not representable). Lossy and labelled as such. */
  OC.exportLegacyCompatible = function (db) {
    var days = {};
    db.entries.filter(function (e) { return e.state === 'CONFIRMED' && e.actId; }).sort(function (a, b) { return a.startUtc - b.startUtc; })
      .forEach(function (e) { (days[e.localDate] = days[e.localDate] || []).push({ act: e.actId, min: R2((e.endUtc - e.startUtc) / 60000), note: e.note || '' }); });
    Object.keys(days).forEach(function (k) { var t = 0; days[k] = days[k].filter(function (e) { if (t + e.min > 1440) return false; t += e.min; return e.min > 0; }); });
    return JSON.stringify({ acts: db.activities.map(function (a) { return { id: a.id, n: a.name, c: a.color, p: a.productive }; }),
      days: days, theme: db.settings.theme, unit: db.settings.unit, notif: db.settings.notif, timer: null }, null, 1);
  };
  /** Import a JSON object. mode: 'replace' | 'mergeMissingDays'. Returns {ok, db, error, backup}. The input db is not mutated. */
  OC.importObject = function (db, obj, mode, nowMs) {
    var backup = JSON.stringify(db), incoming = null;
    if (obj && obj.format === 'opux-export') {
      var errs = OC.validate(obj.db);
      if (errs.length) return { ok: false, error: 'Invalid OPUX file: ' + errs.slice(0, 3).join('; ') };
      incoming = OC.upgrade(obj.db);
    } else {
      var m = OC.migrateLegacyObject(obj, nowMs, db.meta.tz);
      if (!m.ok) return { ok: false, error: m.error };
      incoming = m.db;
    }
    if (mode === 'replace') return { ok: true, db: incoming, backup: backup };
    var out = JSON.parse(backup), have = {};
    out.entries.forEach(function (e) { have[e.localDate] = 1; });
    var actIds = {}; out.activities.forEach(function (a) { actIds[a.id] = 1; });
    var added = 0;
    incoming.activities.forEach(function (a) { if (!actIds[a.id]) out.activities.push(a); });
    incoming.entries.forEach(function (e) {
      if (have[e.localDate]) return;
      e = JSON.parse(JSON.stringify(e)); e.id = 'i' + (++out.counters.entry) + '_' + e.id; out.entries.push(e); added++;
      if (g.OPUX.rdbd) g.OPUX.rdbd.ensureIdentity(out, e.localDate, nowMs);
    });
    return { ok: true, db: out, backup: backup, added: added };
  };

  g.OPUX.core = OC;
  if (typeof module !== 'undefined') module.exports = OC;
})(typeof window !== 'undefined' ? window : globalThis);
