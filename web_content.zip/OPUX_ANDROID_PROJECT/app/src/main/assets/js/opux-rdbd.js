/* RDBD: daily identities, work continuity, project relationships, seasons.
   All values here are derived from or attached to the same records the time engine uses. */
(function (g) {
  'use strict';
  var OT = g.OPUX.time, OC = g.OPUX.core;
  var RD = {};
  var pad3 = function (n) { return OT.pad(n, 3); };

  /* ---------------- identities ---------------- */
  /** Day number is permanent and deterministic: calendar days since meta.epochDate, +1 (Day 001 = epoch).
      Dates before the epoch get numbers <= 0 (labelled "Pre-NNN"). */
  RD.dayNo = function (db, ds) { return OT.daysBetween(db.meta.epochDate, ds) + 1; };
  RD.dayLabel = function (n) { return n > 0 ? 'Day ' + pad3(n) : 'Pre-' + pad3(1 - n); };
  RD.identityId = function (ds) { return 'id_' + ds; };
  RD.getIdentity = function (db, ds) { return db.identities.find(function (x) { return x.date === ds; }) || null; };
  RD.ensureIdentity = function (db, ds, nowMs) {
    var x = RD.getIdentity(db, ds);
    if (x) return x;
    x = { id: RD.identityId(ds), date: ds, dayNo: RD.dayNo(db, ds), customName: null, notes: '', prev: null, next: null, createdAt: nowMs || 0 };
    db.identities.push(x);
    db.identities.sort(function (a, b) { return a.date < b.date ? -1 : 1; });
    for (var i = 0; i < db.identities.length; i++) {
      db.identities[i].prev = i ? db.identities[i - 1].id : null;
      db.identities[i].next = i < db.identities.length - 1 ? db.identities[i + 1].id : null;
    }
    return x;
  };
  RD.displayName = function (db, ds) {
    var x = RD.getIdentity(db, ds), n = x ? x.dayNo : RD.dayNo(db, ds);
    return x && x.customName ? x.customName : 'Loid ' + pad3(Math.max(n, 0) || n);
  };
  RD.renameIdentity = function (db, ds, name, nowMs) {
    var x = RD.ensureIdentity(db, ds, nowMs); name = String(name || '').trim().slice(0, 40);
    x.customName = name || null; return x; // never overwrites other identities: names need not be unique, ids are
  };

  /* ---------------- works ---------------- */
  RD.WORK_STATUS = ['Planned', 'Active', 'Paused', 'Completed', 'Abandoned'];
  RD.REL_TYPES = ['CONTINUES', 'DEPENDS_ON', 'BRANCHES_FROM', 'REPLACES'];
  var workId = function (n) { return 'W' + (n < 1000 ? pad3(n) : String(n)); };
  RD.createWork = function (db, o, nowMs, tz) {
    tz = tz || db.settings.tz;
    var name = String(o.name || '').trim();
    if (!name) return { ok: false, error: 'Work needs a name' };
    var n = ++db.counters.work, today = OT.localDate(nowMs, tz);
    var idn = RD.ensureIdentity(db, today, nowMs);
    var w = { id: workId(n), seq: n, name: name.slice(0, 80), description: String(o.description || '').slice(0, 500), createdAt: nowMs, createdDate: today,
      startIdentity: idn.id, status: o.status && RD.WORK_STATUS.indexOf(o.status) >= 0 ? o.status : 'Active',
      statusHistory: [{ at: nowMs, date: today, status: 'created', to: o.status || 'Active' }],
      subprojects: [], milestones: [], notes: [], progress: [], completedDate: null };
    db.works.push(w); return { ok: true, work: w };
  };
  RD.getWork = function (db, id) { return db.works.find(function (w) { return w.id === id; }) || null; };
  RD.setStatus = function (db, id, status, nowMs, tz) {
    var w = RD.getWork(db, id); if (!w) return { ok: false, error: 'No such work' };
    if (RD.WORK_STATUS.indexOf(status) < 0) return { ok: false, error: 'Bad status' };
    tz = tz || db.settings.tz;
    var d = OT.localDate(nowMs, tz);
    w.statusHistory.push({ at: nowMs, date: d, status: status === 'Active' && w.status === 'Paused' ? 'resumed' : status.toLowerCase(), from: w.status, to: status });
    w.status = status;
    w.completedDate = status === 'Completed' ? d : null;
    return { ok: true, work: w };
  };
  RD.addSubproject = function (db, id, name) { var w = RD.getWork(db, id); if (!w || !String(name).trim()) return null; var s = { id: w.id + '.' + (w.subprojects.length + 1), name: String(name).trim().slice(0, 80) }; w.subprojects.push(s); return s; };
  RD.addMilestone = function (db, id, title, date, note) { var w = RD.getWork(db, id); if (!w || !OT.isDate(date)) return null; var m = { id: w.id + '.M' + (w.milestones.length + 1), title: String(title).slice(0, 100), date: date, note: String(note || '').slice(0, 300) }; w.milestones.push(m); RD.ensureIdentity(db, date, 0); return m; };
  RD.addProgress = function (db, id, date, percent, note) { var w = RD.getWork(db, id); if (!w || !OT.isDate(date) || !(percent >= 0 && percent <= 100)) return null; var p = { date: date, percent: percent, note: String(note || '').slice(0, 200) }; w.progress.push(p); return p; };

  /** Contributions are DERIVED from time entries tagged with a workId, plus explicit untimed ones.
      Deleting/editing an entry therefore updates work history automatically. */
  RD.contributions = function (db, id) {
    var out = [];
    db.entries.forEach(function (e) {
      if (e.workId === id && e.state === 'CONFIRMED') out.push({ date: e.localDate, minutes: (e.endUtc - e.startUtc) / 60000, entryId: e.id, timed: true, identityId: RD.identityId(e.localDate), legacyPlaced: !!e.legacyPlaced });
    });
    db.contributions.forEach(function (c) { if (c.workId === id) out.push({ date: c.date, minutes: 0, entryId: null, timed: false, note: c.note, identityId: RD.identityId(c.date), contributionId: c.id }); });
    return out.sort(function (a, b) { return a.date < b.date ? -1 : a.date > b.date ? 1 : 0; });
  };
  RD.addUntimedContribution = function (db, id, date, note, nowMs) {
    if (!RD.getWork(db, id) || !OT.isDate(date)) return null;
    var c = { id: 'c' + (++db.counters.contribution), workId: id, date: date, note: String(note || '').slice(0, 300), createdAt: nowMs }; db.contributions.push(c); RD.ensureIdentity(db, date, nowMs); return c;
  };
  RD.contributionDates = function (db, id) { var s = {}; RD.contributions(db, id).forEach(function (c) { s[c.date] = 1; }); return Object.keys(s).sort(); };
  /** Participating identities = creator's day plus every identity that contributed. Not exclusive to the creator. */
  RD.participants = function (db, id) {
    var w = RD.getWork(db, id); if (!w) return [];
    var ds = RD.contributionDates(db, id), start = w.startIdentity.slice(3);
    if (ds.indexOf(start) < 0) ds.unshift(start);
    return ds.map(function (d) { return { date: d, dayNo: RD.dayNo(db, d), label: RD.dayLabel(RD.dayNo(db, d)), name: RD.displayName(db, d), contributed: RD.contributionDates(db, id).indexOf(d) >= 0 }; });
  };
  RD.workMinutes = function (db, id, from, to) { return RD.contributions(db, id).filter(function (c) { return (!from || c.date >= from) && (!to || c.date <= to); }).reduce(function (s, c) { return s + c.minutes; }, 0); };

  /* relationships */
  RD.dependsPath = function (db, from, to) { // is there a DEPENDS_ON path from -> to ?
    var seen = {}, st = [from];
    while (st.length) { var x = st.pop(); if (x === to) return true; if (seen[x]) continue; seen[x] = 1; db.relations.forEach(function (r) { if (r.type === 'DEPENDS_ON' && r.from === x) st.push(r.to); }); }
    return false;
  };
  RD.relate = function (db, from, type, to, nowMs) {
    if (RD.REL_TYPES.indexOf(type) < 0) return { ok: false, error: 'Bad relation type' };
    if (!RD.getWork(db, from) || !RD.getWork(db, to)) return { ok: false, error: 'Unknown work' };
    if (from === to) return { ok: false, error: 'A work cannot relate to itself' };
    if (db.relations.some(function (r) { return r.from === from && r.to === to && r.type === type; })) return { ok: false, error: 'Relation already exists' };
    if (type === 'DEPENDS_ON' && RD.dependsPath(db, to, from)) return { ok: false, error: 'Would create a dependency cycle' };
    var r = { id: 'r' + (++db.counters.relation), from: from, to: to, type: type, createdAt: nowMs }; db.relations.push(r); return { ok: true, relation: r };
  };
  RD.relatedWorks = function (db, id) { return db.relations.filter(function (r) { return r.from === id || r.to === id; }); };

  /* ---------------- seasons ---------------- */
  /** Season number follows the calendar month: anchor month = Season 001, then +1 per month.
      Months before the anchor are all "Season 000 — Prologue". */
  RD.seasonNoForMonth = function (db, ym) {
    var a = db.meta.seasonAnchor.split('-').map(Number), b = ym.split('-').map(Number);
    var n = (b[0] - a[0]) * 12 + (b[1] - a[1]) + 1; return n < 1 ? 0 : n;
  };
  RD.seasonNoForDate = function (db, ds) { return RD.seasonNoForMonth(db, ds.slice(0, 7)); };
  RD.monthForSeason = function (db, no) {
    if (no < 1) return null;
    var a = db.meta.seasonAnchor.split('-').map(Number), i = a[0] * 12 + (a[1] - 1) + (no - 1);
    return OT.pad(Math.floor(i / 12), 4) + '-' + OT.pad((i % 12) + 1);
  };
  RD.seasonLabel = function (db, no) { return 'Season ' + pad3(no); };
  RD.seasonTitle = function (db, no) { var s = db.seasons.find(function (x) { return x.no === no; }); return s && s.title ? s.title : (no === 0 ? 'Prologue' : OT.MONTHS[+RD.monthForSeason(db, no).slice(5) - 1] + ' ' + RD.monthForSeason(db, no).slice(0, 4)); };
  RD.setSeasonTitle = function (db, no, title) { var s = db.seasons.find(function (x) { return x.no === no; }); if (!s) { s = { no: no, title: '', cover: null }; db.seasons.push(s); } s.title = String(title).trim().slice(0, 60); return s; };
  /** Which season numbers contain recorded data. */
  RD.activeSeasons = function (db) { var s = {}; db.entries.forEach(function (e) { s[RD.seasonNoForDate(db, e.localDate)] = 1; }); return Object.keys(s).map(Number).sort(function (a, b) { return a - b; }); };
  RD.seasonDates = function (db, no) {
    var ym = RD.monthForSeason(db, no); if (!ym) return null;
    var y = +ym.slice(0, 4), m = +ym.slice(5), n = OT.daysInMonth(y, m); return { from: ym + '-01', to: ym + '-' + OT.pad(n), days: n };
  };
  /** A season is complete once its month has fully passed in the given timezone. */
  RD.isSeasonComplete = function (db, no, nowMs, tz) { var sd = RD.seasonDates(db, no); return !!sd && OT.localDate(nowMs, tz || db.settings.tz) > sd.to; };
  /** Completed calendar years (every month Jan-Dec lies in the past) for Yearbook generation. */
  RD.yearbookYears = function (db, nowMs, tz) {
    var today = OT.localDate(nowMs, tz || db.settings.tz), ys = {};
    db.entries.forEach(function (e) { ys[+e.localDate.slice(0, 4)] = 1; });
    return Object.keys(ys).map(Number).filter(function (y) { return OT.ymd(y, 12, 31) < today; }).sort();
  };

  g.OPUX.rdbd = RD;
  if (typeof module !== 'undefined') module.exports = RD;
})(typeof window !== 'undefined' ? window : globalThis);
