/* OPUX time utilities: timezone-aware date/time maths and display formatting.
   Stored values are UTC epoch milliseconds. Local calendar dates ('YYYY-MM-DD') are always
   derived with an explicit IANA timezone, never from the UTC date. */
(function (g) {
  'use strict';
  var OT = {};
  var pad = function (n, w) { n = String(Math.abs(n)); w = w || 2; while (n.length < w) n = '0' + n; return n; };
  OT.pad = pad;
  OT.MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December'];
  OT.WEEKDAYS = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];

  OT.deviceTz = function () {
    try { return Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC'; } catch (e) { return 'UTC'; }
  };

  var dtfCache = {};
  function dtf(tz) {
    return dtfCache[tz] || (dtfCache[tz] = new Intl.DateTimeFormat('en-US', {
      timeZone: tz, hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit',
      hour: '2-digit', minute: '2-digit', second: '2-digit'
    }));
  }
  OT.isValidTz = function (tz) { try { dtf(tz); return true; } catch (e) { return false; } };

  /** Wall-clock parts of an instant in a timezone. */
  OT.parts = function (ms, tz) {
    var o = {}, ps = dtf(tz).formatToParts(new Date(ms));
    for (var i = 0; i < ps.length; i++) o[ps[i].type] = ps[i].value;
    return { y: +o.year, mo: +o.month, d: +o.day, h: (+o.hour) % 24, mi: +o.minute, s: +o.second };
  };
  OT.ymd = function (y, m, d) { return pad(y, 4) + '-' + pad(m) + '-' + pad(d); };
  OT.splitDate = function (ds) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(ds);
    if (!m) throw new Error('Bad date ' + ds);
    var y = +m[1], mo = +m[2], d = +m[3], t = new Date(Date.UTC(y, mo - 1, d));
    if (t.getUTCFullYear() !== y || t.getUTCMonth() !== mo - 1 || t.getUTCDate() !== d) throw new Error('Impossible date ' + ds);
    return [y, mo, d];
  };
  OT.isDate = function (ds) { try { OT.splitDate(ds); return true; } catch (e) { return false; } };
  /** Local calendar date of an instant in a timezone. */
  OT.localDate = function (ms, tz) { var p = OT.parts(ms, tz); return OT.ymd(p.y, p.mo, p.d); };
  OT.addDays = function (ds, n) {
    var a = OT.splitDate(ds), t = new Date(Date.UTC(a[0], a[1] - 1, a[2] + n));
    return OT.ymd(t.getUTCFullYear(), t.getUTCMonth() + 1, t.getUTCDate());
  };
  OT.daysBetween = function (a, b) { // b - a in calendar days
    var x = OT.splitDate(a), y = OT.splitDate(b);
    return Math.round((Date.UTC(y[0], y[1] - 1, y[2]) - Date.UTC(x[0], x[1] - 1, x[2])) / 86400000);
  };
  /** Weekday index 0=Sunday, calculated from the date (never hard-coded). */
  OT.weekday = function (ds) { var a = OT.splitDate(ds); return new Date(Date.UTC(a[0], a[1] - 1, a[2])).getUTCDay(); };
  OT.isLeap = function (y) { return (y % 4 === 0 && y % 100 !== 0) || y % 400 === 0; };
  OT.daysInMonth = function (y, m) { return new Date(Date.UTC(y, m, 0)).getUTCDate(); };
  OT.weekStart = function (ds) { return OT.addDays(ds, -((OT.weekday(ds) + 6) % 7)); }; // Monday

  var midCache = {};
  /** First instant (ms) of a local calendar date in tz; correct on DST days and midnight gaps. */
  OT.midnight = function (ds, tz) {
    var key = tz + '|' + ds;
    if (midCache[key] != null) return midCache[key];
    var a = OT.splitDate(ds), guess = Date.UTC(a[0], a[1] - 1, a[2]);
    var lo = guess - 15 * 3600000, hi = guess + 15 * 3600000; // smallest ms with localDate >= ds
    lo = Math.floor(lo / 1000) * 1000; hi = Math.floor(hi / 1000) * 1000;
    while (hi - lo > 1000) {
      var mid = lo + Math.floor((hi - lo) / 2000) * 1000;
      if (OT.localDate(mid, tz) >= ds) hi = mid; else lo = mid;
    }
    if (Object.keys(midCache).length > 5000) midCache = {};
    return (midCache[key] = hi);
  };
  /** Real length of a local day in minutes (1440 normally; 1380/1500 on DST changes). */
  OT.dayMinutes = function (ds, tz) { return (OT.midnight(OT.addDays(ds, 1), tz) - OT.midnight(ds, tz)) / 60000; };
  OT.dayWindow = function (ds, tz) { return { start: OT.midnight(ds, tz), end: OT.midnight(OT.addDays(ds, 1), tz) }; };

  /** Instant for a local wall-clock time; skipped (DST-gap) times move forward by the gap, repeated times use the first occurrence. */
  OT.wall = function (ds, h, mi, tz) {
    var a = OT.splitDate(ds), guess = Date.UTC(a[0], a[1] - 1, a[2], h, mi, 0);
    var off = function (t) { var p = OT.parts(t, tz); return Date.UTC(p.y, p.mo - 1, p.d, p.h, p.mi, p.s) - t; };
    var t1 = guess - off(guess), t2 = guess - off(t1);
    var cands = [t1, t2, t1 - 3600000, t1 + 3600000].filter(function (t) {
      var p = OT.parts(t, tz); return p.y === a[0] && p.mo === a[1] && p.d === a[2] && p.h === h && p.mi === mi;
    });
    if (cands.length) return Math.min.apply(null, cands);
    return Math.max(t1, t2); // inside a DST gap: shifted forward by the gap length (02:30 -> 03:30), as JS Date does
  };

  /* ---------- display formatting (never alters stored values) ---------- */
  OT.DATE_FORMATS = ['full', 'weekdayFirst', 'short', 'iso'];
  OT.fmtDate = function (ds, fmt) {
    var a = OT.splitDate(ds), mn = OT.MONTHS[a[1] - 1], wd = OT.WEEKDAYS[OT.weekday(ds)];
    switch (fmt || 'full') {
      case 'weekdayFirst': return wd + ', ' + mn + ' ' + a[2] + ', ' + a[0];
      case 'short': return mn.slice(0, 3) + ' ' + a[2] + ', ' + a[0];
      case 'iso': return ds;
      default: return mn + ' ' + a[2] + ', ' + a[0] + ' (' + wd + ')';
    }
  };
  OT.fmtClock = function (h, mi, f) {
    if (f === '24') return pad(h) + ':' + pad(mi);
    var h12 = h % 12 || 12; return pad(h12) + ':' + pad(mi) + ' ' + (h < 12 ? 'AM' : 'PM');
  };
  /** Format an instant as a clock time in tz. f = '12' | '24'. */
  OT.fmtTime = function (ms, tz, f) { var p = OT.parts(ms, tz); return OT.fmtClock(p.h, p.mi, f); };
  OT.fmtDateTime = function (ms, tz, df, tf) { return OT.fmtDate(OT.localDate(ms, tz), df) + ' ' + OT.fmtTime(ms, tz, tf); };
  OT.fmtDuration = function (min, unit) {
    min = Math.round(min * 100) / 100;
    if (unit === 'dec') return Math.round(min / 60 * 100) / 100 + ' h';
    if (unit === 'min') return min + ' min';
    var h = Math.floor(min / 60 + 1e-9), r = Math.round((min - h * 60) * 100) / 100;
    return h + 'h' + (r ? ' ' + r + 'm' : '');
  };
  OT.fmtRange = function (a, b, tz, f) { return OT.fmtTime(a, tz, f) + ' – ' + OT.fmtTime(b, tz, f); };

  g.OPUX = g.OPUX || {}; g.OPUX.time = OT;
  if (typeof module !== 'undefined') module.exports = OT;
})(typeof window !== 'undefined' ? window : globalThis);
