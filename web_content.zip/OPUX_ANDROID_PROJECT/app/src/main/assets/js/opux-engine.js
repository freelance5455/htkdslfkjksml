/* OPUX time engine: day accounting, gap/overlap detection, detected-vs-manual matching,
   clarification questions, timers, editing. Time is UTC ms; a "day" is a local calendar date
   whose real length (1380/1440/1500 min) comes from the timezone rules. */
(function (g) {
  'use strict';
  var OT = g.OPUX.time, OC = g.OPUX.core, RD = g.OPUX.rdbd;
  var OE = {};
  var MIN = 60000;
  var actOf = function (db, id) { return db.activities.find(function (a) { return a.id === id; }) || null; };
  OE.activity = actOf;

  OE.dayTz = function (db, ds) {
    for (var i = 0; i < db.entries.length; i++) if (db.entries[i].localDate === ds) return db.entries[i].tz;
    return db.settings.tz || db.meta.tz;
  };
  OE.window = function (db, ds) { return OT.dayWindow(ds, OE.dayTz(db, ds)); };

  /** Entries clipped to the day window. Midnight-crossing entries contribute a segment to each day. */
  OE.segments = function (db, ds) {
    var w = OE.window(db, ds), out = [];
    db.entries.forEach(function (e) {
      if (e.resolved) return; // detected records already attached/dismissed
      var a = Math.max(e.startUtc, w.start), b = Math.min(e.endUtc, w.end);
      if (b > a) out.push({ entry: e, start: a, end: b });
    });
    return out;
  };

  /** Complete, ordered timeline of one day. Block types: CONFIRMED, OVERLAP, UNKNOWN, DETECTED, GAP. */
  OE.timeline = function (db, ds) {
    var w = OE.window(db, ds), segs = OE.segments(db, ds), pts = [w.start, w.end];
    segs.forEach(function (s) { pts.push(s.start, s.end); });
    pts = pts.filter(function (p, i, a) { return a.indexOf(p) === i; }).sort(function (a, b) { return a - b; });
    var blocks = [];
    for (var i = 0; i < pts.length - 1; i++) {
      var a = pts[i], b = pts[i + 1], cov = segs.filter(function (s) { return s.start <= a && s.end >= b; }).map(function (s) { return s.entry; });
      var C = cov.filter(function (e) { return e.state === 'CONFIRMED'; }).sort(function (x, y) { return x.startUtc - y.startUtc || (x.id < y.id ? -1 : 1); });
      var U = cov.filter(function (e) { return e.state === 'UNKNOWN'; }), D = cov.filter(function (e) { return e.state === 'DETECTED'; });
      var type = C.length > 1 ? 'OVERLAP' : C.length ? 'CONFIRMED' : U.length ? 'UNKNOWN' : D.length ? 'DETECTED' : 'GAP';
      var key = type + '|' + cov.map(function (e) { return e.id; }).sort().join(',');
      var last = blocks[blocks.length - 1];
      if (last && last.key === key && last.end === a) last.end = b;
      else blocks.push({ type: type, start: a, end: b, key: key, confirmed: C, unknown: U, detected: D });
    }
    return blocks;
  };

  /** Exclusive, exhaustive accounting. Invariant: sum of all buckets === day length (ms). */
  OE.account = function (db, ds) {
    var w = OE.window(db, ds), cap = w.end - w.start;
    var r = { date: ds, capacityMin: cap / MIN, byActivity: {}, byCat: { study: 0, sleep: 0, leisure: 0, entertainment: 0, unwanted: 0, other: 0 },
      productiveMin: 0, confirmedMin: 0, unknownMarkedMin: 0, detectedPendingMin: 0, unrecordedMin: 0, overlapMin: 0, customMin: 0, ms: {} };
    var ms = { confirmed: 0, unknownMarked: 0, detectedPending: 0, unrecorded: 0 }, byAct = {}, byCat = {}, prod = 0, custom = 0, ovl = 0;
    OE.timeline(db, ds).forEach(function (bl) {
      var d = bl.end - bl.start;
      if (bl.type === 'CONFIRMED' || bl.type === 'OVERLAP') {
        var e = bl.confirmed[0]; // overlapped span counted once, attributed to the earliest-starting confirmed entry
        ms.confirmed += d; if (bl.type === 'OVERLAP') ovl += d;
        if (e.actId) { byAct[e.actId] = (byAct[e.actId] || 0) + d; var a = actOf(db, e.actId); byCat[a.cat] = (byCat[a.cat] || 0) + d; if (a.productive) prod += d; }
        else custom += d;
      } else if (bl.type === 'UNKNOWN') ms.unknownMarked += d;
      else if (bl.type === 'DETECTED') ms.detectedPending += d;
      else ms.unrecorded += d;
    });
    Object.keys(byAct).forEach(function (k) { r.byActivity[k] = byAct[k] / MIN; });
    Object.keys(byCat).forEach(function (k) { r.byCat[k] = byCat[k] / MIN; });
    r.productiveMin = prod / MIN; r.customMin = custom / MIN; r.overlapMin = ovl / MIN;
    r.confirmedMin = ms.confirmed / MIN; r.unknownMarkedMin = ms.unknownMarked / MIN;
    r.detectedPendingMin = ms.detectedPending / MIN; r.unrecordedMin = ms.unrecorded / MIN;
    r.unknownMin = (ms.unknownMarked + ms.detectedPending + ms.unrecorded) / MIN; // everything not yet classified; never "wasted"
    r.ms = ms; r.capacityMs = cap;
    r.balanced = ms.confirmed + ms.unknownMarked + ms.detectedPending + ms.unrecorded === cap;
    return r;
  };
  /** Aggregate accounting over a list of dates. */
  OE.accountRange = function (db, dates) {
    var t = { days: dates.length, capacityMin: 0, byCat: { study: 0, sleep: 0, leisure: 0, entertainment: 0, unwanted: 0, other: 0 }, byActivity: {}, productiveMin: 0, confirmedMin: 0, unknownMin: 0, customMin: 0 };
    dates.forEach(function (d) {
      var a = OE.account(db, d); t.capacityMin += a.capacityMin; t.productiveMin += a.productiveMin; t.confirmedMin += a.confirmedMin; t.unknownMin += a.unknownMin; t.customMin += a.customMin;
      Object.keys(a.byCat).forEach(function (k) { t.byCat[k] += a.byCat[k]; });
      Object.keys(a.byActivity).forEach(function (k) { t.byActivity[k] = (t.byActivity[k] || 0) + a.byActivity[k]; });
    });
    return t;
  };

  /* ---------------- conflicts & writing ---------------- */
  var overlaps = function (e, s, t) { return e.startUtc < t && e.endUtc > s; };
  OE.findConflicts = function (db, s, t, ignoreId) {
    return db.entries.filter(function (e) { return e.id !== ignoreId && e.state === 'CONFIRMED' && !e.resolved && overlaps(e, s, t); });
  };
  var nextId = function (db) { return 'e' + (++db.counters.entry) + '_' + (db.counters.entry * 7919 % 100003).toString(36); };
  function mk(db, o, nowMs) {
    var tz = o.tz || db.settings.tz;
    return { id: nextId(db), actId: o.actId || null, desc: String(o.desc || '').slice(0, 200), startUtc: o.startUtc, endUtc: o.endUtc, tz: tz,
      localDate: OT.localDate(o.startUtc, tz), state: o.state || 'CONFIRMED', source: o.source || 'manual', legacyPlaced: false,
      note: String(o.note || '').slice(0, 200), workId: o.workId || null, app: o.app || null, createdAt: nowMs, updatedAt: nowMs };
  }
  function log(db, what, nowMs) { db.log.push({ at: nowMs, what: what }); if (db.log.length > 200) db.log.splice(0, db.log.length - 200); }
  function afterWrite(db, e, nowMs) { RD.ensureIdentity(db, e.localDate, nowMs); }

  /** Add an entry. resolve: 'reject' (default) | 'fillGaps' | 'replace'.
      Only CONFIRMED entries conflict with CONFIRMED entries; DETECTED and UNKNOWN never block. */
  OE.addEntry = function (db, o, nowMs, resolve) {
    resolve = resolve || 'reject';
    if (!(isFinite(o.startUtc) && isFinite(o.endUtc) && o.endUtc > o.startUtc)) return { ok: false, error: 'End must be after start' };
    if (o.endUtc - o.startUtc > 7 * 86400000) return { ok: false, error: 'An entry cannot exceed 7 days' };
    if (o.actId && !actOf(db, o.actId)) return { ok: false, error: 'Unknown activity' };
    var state = o.state || 'CONFIRMED';
    if (!o.actId && !o.desc && state !== 'UNKNOWN') return { ok: false, error: 'Choose an activity or enter a description' };
    if (o.workId && !RD.getWork(db, o.workId)) return { ok: false, error: 'Unknown work' };
    var made = [], skippedMs = 0, replaced = [];
    if (state !== 'CONFIRMED' || !OE.findConflicts(db, o.startUtc, o.endUtc).length) {
      var e = mk(db, o, nowMs); db.entries.push(e); afterWrite(db, e, nowMs); return { ok: true, entries: [e], skippedMs: 0 };
    }
    var conf = OE.findConflicts(db, o.startUtc, o.endUtc);
    if (resolve === 'reject') return { ok: false, error: 'Overlaps recorded time', conflicts: conf.map(function (c) { return c.id; }) };
    if (resolve === 'replace') {
      conf.forEach(function (c) { replaced.push(c.id); OE.cutOut(db, c, o.startUtc, o.endUtc, nowMs); });
      var e2 = mk(db, o, nowMs); db.entries.push(e2); afterWrite(db, e2, nowMs); return { ok: true, entries: [e2], replaced: replaced, skippedMs: 0 };
    }
    // fillGaps: only the free spans become entries; the overlapped time is reported, never silently added
    var cuts = conf.map(function (c) { return [Math.max(c.startUtc, o.startUtc), Math.min(c.endUtc, o.endUtc)]; }).sort(function (a, b) { return a[0] - b[0]; });
    var cur = o.startUtc;
    cuts.forEach(function (c) { if (c[0] > cur) made.push([cur, c[0]]); cur = Math.max(cur, c[1]); });
    if (cur < o.endUtc) made.push([cur, o.endUtc]);
    var res = [];
    made.forEach(function (m) { var e3 = mk(db, Object.assign({}, o, { startUtc: m[0], endUtc: m[1] }), nowMs); db.entries.push(e3); afterWrite(db, e3, nowMs); res.push(e3); });
    skippedMs = (o.endUtc - o.startUtc) - made.reduce(function (s, m) { return s + m[1] - m[0]; }, 0);
    return { ok: true, entries: res, skippedMs: skippedMs };
  };
  /** Remove [s,t) from an entry by trimming or splitting it. Legacy placement flag is preserved on remainders. */
  OE.cutOut = function (db, e, s, t, nowMs) {
    var idx = db.entries.indexOf(e); if (idx < 0) return;
    var left = e.startUtc < s, right = e.endUtc > t;
    if (!left && !right) { db.entries.splice(idx, 1); return; }
    if (left && right) {
      var r = JSON.parse(JSON.stringify(e)); r.id = nextId(db); r.startUtc = t; r.localDate = OT.localDate(r.startUtc, r.tz); r.updatedAt = nowMs; r.origMin = undefined;
      e.endUtc = s; e.updatedAt = nowMs; e.origMin = undefined; db.entries.push(r); return;
    }
    if (left) e.endUtc = s; else { e.startUtc = t; e.localDate = OT.localDate(e.startUtc, e.tz); }
    e.updatedAt = nowMs; e.origMin = undefined;
  };
  OE.getEntry = function (db, id) { return db.entries.find(function (e) { return e.id === id; }) || null; };
  OE.updateEntry = function (db, id, patch, nowMs, resolve) {
    var e = OE.getEntry(db, id); if (!e) return { ok: false, error: 'No such entry' };
    var n = Object.assign({}, e, patch), s = n.startUtc, t = n.endUtc;
    if (!(t > s)) return { ok: false, error: 'End must be after start' };
    if (n.actId && !actOf(db, n.actId)) return { ok: false, error: 'Unknown activity' };
    if (!n.actId && !n.desc && n.state !== 'UNKNOWN') return { ok: false, error: 'Choose an activity or enter a description' };
    if (n.workId && !RD.getWork(db, n.workId)) return { ok: false, error: 'Unknown work' };
    if (n.state === 'CONFIRMED') {
      var conf = OE.findConflicts(db, s, t, id);
      if (conf.length) {
        if (resolve !== 'replace') return { ok: false, error: 'Overlaps recorded time', conflicts: conf.map(function (c) { return c.id; }) };
        conf.forEach(function (c) { OE.cutOut(db, c, s, t, nowMs); });
      }
    }
    var timeChanged = n.startUtc !== e.startUtc || n.endUtc !== e.endUtc;
    Object.assign(e, patch);
    if (timeChanged || patch.tz) { e.localDate = OT.localDate(e.startUtc, e.tz); e.legacyPlaced = false; e.origMin = undefined; } // a user-set time is no longer synthetic
    e.updatedAt = nowMs; afterWrite(db, e, nowMs); log(db, 'update ' + id, nowMs); return { ok: true, entry: e };
  };
  OE.deleteEntry = function (db, id, nowMs) { var i = db.entries.findIndex(function (e) { return e.id === id; }); if (i < 0) return false; db.entries.splice(i, 1); log(db, 'delete ' + id, nowMs); return true; };
  OE.reclassify = function (db, id, actId, nowMs) { return OE.updateEntry(db, id, { actId: actId, desc: '' }, nowMs); };
  OE.split = function (db, id, atMs, nowMs) {
    var e = OE.getEntry(db, id); if (!e || !(atMs > e.startUtc && atMs < e.endUtc)) return { ok: false, error: 'Split point must be inside the entry' };
    var b = JSON.parse(JSON.stringify(e)); b.id = nextId(db); b.startUtc = atMs; b.localDate = OT.localDate(atMs, b.tz); b.updatedAt = nowMs; b.origMin = undefined;
    e.endUtc = atMs; e.updatedAt = nowMs; e.origMin = undefined; db.entries.push(b); afterWrite(db, b, nowMs); return { ok: true, first: e, second: b };
  };
  OE.merge = function (db, idA, idB, nowMs) {
    var a = OE.getEntry(db, idA), b = OE.getEntry(db, idB); if (!a || !b || a === b) return { ok: false, error: 'Pick two entries' };
    if (a.startUtc > b.startUtc) { var t = a; a = b; b = t; }
    if (a.endUtc !== b.startUtc) return { ok: false, error: 'Entries must be adjacent' };
    if (a.state !== b.state || a.actId !== b.actId || a.desc !== b.desc || a.workId !== b.workId) return { ok: false, error: 'Entries differ in activity, description, state or work' };
    a.endUtc = b.endUtc; a.legacyPlaced = a.legacyPlaced && b.legacyPlaced; a.origMin = undefined; a.note = [a.note, b.note].filter(Boolean).join(' / ').slice(0, 200); a.updatedAt = nowMs;
    OE.deleteEntry(db, b.id, nowMs); return { ok: true, entry: a };
  };

  /* ---------------- timer ---------------- */
  OE.timerStart = function (db, actId, nowMs, workId) {
    if (db.timer) return { ok: false, error: 'A timer is already running' };
    if (!actOf(db, actId)) return { ok: false, error: 'Unknown activity' };
    db.timer = { actId: actId, startUtc: nowMs, tz: db.settings.tz, workId: workId || null }; return { ok: true };
  };
  OE.timerStop = function (db, nowMs) {
    var t = db.timer; if (!t) return { ok: false, error: 'No timer running' };
    if (nowMs <= t.startUtc) { db.timer = null; return { ok: true, entries: [], skippedMs: 0, note: 'Timer was shorter than 1 ms and was discarded.' }; }
    var r = OE.addEntry(db, { actId: t.actId, startUtc: t.startUtc, endUtc: nowMs, tz: t.tz, source: 'timer', workId: t.workId }, nowMs, 'fillGaps');
    if (r.ok) db.timer = null; return r;
  };

  /* ---------------- detected records & matching ---------------- */
  OE.addDetected = function (db, o, nowMs) { return OE.addEntry(db, Object.assign({}, o, { state: 'DETECTED', source: 'usage', actId: null, desc: o.desc || o.app || 'Phone usage' }), nowMs); };
  /** For each unresolved DETECTED entry: how it relates to CONFIRMED entries. Never adds time. */
  OE.matchDetected = function (db, ds) {
    var w = OE.window(db, ds), out = [];
    db.entries.forEach(function (d) {
      if (d.state !== 'DETECTED' || d.resolved || d.endUtc <= w.start || d.startUtc >= w.end) return;
      var cs = OE.findConflicts(db, d.startUtc, d.endUtc), ov = 0;
      var spans = cs.map(function (c) { return [Math.max(c.startUtc, d.startUtc), Math.min(c.endUtc, d.endUtc)]; }).sort(function (a, b) { return a[0] - b[0]; }), cur = d.startUtc;
      spans.forEach(function (s) { var a = Math.max(s[0], cur); if (s[1] > a) { ov += s[1] - a; cur = s[1]; } });
      var rel = !cs.length ? 'none' : ov >= d.endUtc - d.startUtc ? 'contained' : 'partial';
      out.push({ detectedId: d.id, app: d.app || d.desc, start: d.startUtc, end: d.endUtc, relation: rel, overlapMin: ov / MIN, confirmedIds: cs.map(function (c) { return c.id; }) });
    });
    return out;
  };
  /** User decision on a detected entry. action: attach | confirm | dismiss. Duplicates are prevented by construction. */
  OE.resolveDetected = function (db, id, action, o, nowMs) {
    var d = OE.getEntry(db, id); if (!d || d.state !== 'DETECTED') return { ok: false, error: 'Not a detected record' };
    o = o || {};
    if (action === 'attach') { var c = OE.getEntry(db, o.confirmedId); if (!c || c.state !== 'CONFIRMED') return { ok: false, error: 'Choose a confirmed entry' }; d.resolved = 'attached'; d.linkedTo = c.id; d.updatedAt = nowMs; return { ok: true }; }
    if (action === 'dismiss') { d.resolved = 'dismissed'; d.updatedAt = nowMs; return { ok: true }; }
    if (action === 'confirm') {
      if (!o.actId && !o.desc) return { ok: false, error: 'Choose an activity or enter a description' };
      if (o.actId && !actOf(db, o.actId)) return { ok: false, error: 'Unknown activity' };
      var conf = OE.findConflicts(db, d.startUtc, d.endUtc, d.id);
      if (conf.length) {
        if (o.overlap !== 'replace') return { ok: false, error: 'Overlaps confirmed time', conflicts: conf.map(function (x) { return x.id; }) };
        conf.forEach(function (x) { OE.cutOut(db, x, d.startUtc, d.endUtc, nowMs); });
      }
      d.state = 'CONFIRMED'; d.actId = o.actId || null; d.desc = o.actId ? '' : String(o.desc).slice(0, 200); d.source = 'usage-confirmed'; d.updatedAt = nowMs; return { ok: true, entry: d };
    }
    return { ok: false, error: 'Unknown action' };
  };

  /* ---------------- clarification questions ---------------- */
  var key = function (type, a, b) { return type + ':' + a + '-' + b; };
  /** Questions about real missing information only. trigger: 'open' | 'review' | 'reminder'.
      While a timer is running, only an explicit review asks anything (active activities are not interrupted). */
  OE.questions = function (db, nowMs, trigger, opts) {
    opts = opts || {}; trigger = trigger || 'open';
    if (db.timer && trigger !== 'review') return [];
    var tf = db.settings.timeFormat, minGap = (opts.minGapMin || db.settings.clarifyMinGapMin || 15) * MIN, out = [];
    var dates = opts.dates || [OT.localDate(nowMs, db.settings.tz)];
    dates.forEach(function (ds) {
      var tz = OE.dayTz(db, ds);
      if (trigger !== 'review' && ds > OT.localDate(nowMs, tz)) return;
      OE.timeline(db, ds).forEach(function (bl) {
        var s = bl.start, t = Math.min(bl.end, nowMs);
        if (t <= s) return;
        if (db.timer && s < nowMs && t > db.timer.startUtc) { if (s >= db.timer.startUtc) return; t = Math.min(t, db.timer.startUtc); if (t <= s) return; }
        var k = key(bl.type, s, t), skipUntil = db.clarify.skipped[k];
        var skipped = skipUntil && skipUntil > nowMs && trigger !== 'review';
        if (bl.type === 'GAP' && t - s >= minGap && !skipped && !db.clarify.dismissed[k])
          out.push({ id: k, type: 'GAP', date: ds, start: s, end: t, text: 'What did you do between ' + OT.fmtTime(s, tz, tf) + ' and ' + OT.fmtTime(t, tz, tf) + '?', options: ['activity', 'newActivity', 'description', 'unknown', 'skip'] });
        else if (bl.type === 'DETECTED' && !skipped)
          out.push({ id: k, type: 'DETECTED', date: ds, start: s, end: t, detectedIds: bl.detected.map(function (e) { return e.id; }), text: 'Phone usage was detected between ' + OT.fmtTime(s, tz, tf) + ' and ' + OT.fmtTime(t, tz, tf) + '. What were you doing?', options: ['confirm', 'dismiss', 'skip'] });
        else if (bl.type === 'OVERLAP' && !skipped)
          out.push({ id: k, type: 'OVERLAP', date: ds, start: s, end: t, entryIds: bl.confirmed.map(function (e) { return e.id; }), text: 'Two records overlap between ' + OT.fmtTime(s, tz, tf) + ' and ' + OT.fmtTime(t, tz, tf) + '. Which one is correct?', options: ['keepOne', 'skip'] });
      });
      OE.matchDetected(db, ds).filter(function (m) { return m.relation !== 'none'; }).forEach(function (m) {
        var k = 'MATCH:' + m.detectedId;
        if (db.clarify.skipped[k] > nowMs && trigger !== 'review') return;
        out.push({ id: k, type: 'MATCH', date: ds, start: m.start, end: m.end, detectedId: m.detectedId, relation: m.relation, overlapMin: m.overlapMin, confirmedIds: m.confirmedIds,
          text: m.app + ' usage (' + OT.fmtRange(m.start, m.end, tz, tf) + ') overlaps a recorded activity. Is it part of that activity?', options: ['attach', 'confirm', 'dismiss', 'skip'] });
      });
    });
    return out.sort(function (a, b) { return a.start - b.start; });
  };
  OE.skipQuestion = function (db, qid, nowMs) { db.clarify.skipped[qid] = nowMs + 24 * 3600000; return { ok: true }; };
  /** Answer a GAP question. ans: {kind:'activity'|'newActivity'|'description'|'unknown'|'skip', actId, name, color, desc, start?, end?}.
      The answered span must lie inside the asked gap, so nothing outside it is assumed. */
  OE.answerGap = function (db, q, ans, nowMs) {
    if (ans.kind === 'skip') return OE.skipQuestion(db, q.id, nowMs);
    var s = ans.start != null ? ans.start : q.start, t = ans.end != null ? ans.end : q.end;
    if (s < q.start || t > q.end || t <= s) return { ok: false, error: 'Answer must stay within the unrecorded period' };
    if (ans.kind === 'unknown') return OE.addEntry(db, { startUtc: s, endUtc: t, state: 'UNKNOWN', source: 'clarified', desc: '' }, nowMs);
    var actId = null, desc = '';
    if (ans.kind === 'activity') actId = ans.actId;
    else if (ans.kind === 'newActivity') {
      var nm = String(ans.name || '').trim(); if (!nm) return { ok: false, error: 'Enter a name' };
      var a = { id: 'a' + (++db.counters.activity) + 'x', name: nm.slice(0, 30), color: ans.color || '#14b8a6', productive: 0, cat: 'other' };
      while (db.activities.some(function (x) { return x.id === a.id; })) a.id = 'a' + (++db.counters.activity) + 'x';
      db.activities.push(a); actId = a.id;
    } else if (ans.kind === 'description') { desc = String(ans.desc || '').trim(); if (!desc) return { ok: false, error: 'Enter a description' }; }
    else return { ok: false, error: 'Unknown answer' };
    return OE.addEntry(db, { startUtc: s, endUtc: t, actId: actId, desc: desc, source: 'clarified', workId: ans.workId }, nowMs, 'reject');
  };

  /* ---------------- pattern suggestions (need user approval; create nothing) ---------------- */
  OE.suggestions = function (db, nowMs, opts) {
    opts = opts || {}; var look = opts.lookbackDays || 14, minDays = opts.minDays || 4, tol = (opts.toleranceMin || 45) * MIN, out = [];
    var tz = db.settings.tz, today = OT.localDate(nowMs, tz), from = OT.addDays(today, -look);
    var tf = db.settings.timeFormat, byAct = {};
    db.entries.forEach(function (e) {
      if (e.state !== 'CONFIRMED' || e.legacyPlaced || !e.actId || e.localDate < from || e.localDate >= today) return; // synthetic legacy times are never patterns
      if (e.endUtc - e.startUtc < 20 * MIN) return;
      var p = OT.parts(e.startUtc, e.tz), mod = p.h * 60 + p.mi;
      (byAct[e.actId] = byAct[e.actId] || []).push({ date: e.localDate, mod: mod, dur: (e.endUtc - e.startUtc) / MIN });
    });
    Object.keys(byAct).forEach(function (id) {
      var L = byAct[id], dates = {}; L.forEach(function (x) { dates[x.date] = 1; });
      if (Object.keys(dates).length < minDays) return;
      var mods = L.map(function (x) { return x.mod; }).sort(function (a, b) { return a - b; }), med = mods[Math.floor(mods.length / 2)];
      var near = L.filter(function (x) { return Math.abs(x.mod - med) * MIN <= tol; }), nd = {}; near.forEach(function (x) { nd[x.date] = 1; });
      if (Object.keys(nd).length < minDays) return;
      var durs = near.map(function (x) { return x.dur; }).sort(function (a, b) { return a - b; }), dm = durs[Math.floor(durs.length / 2)];
      var w = OT.dayWindow(today, tz), startMs = w.start + med * MIN;
      if (nowMs < startMs + tol) return; // only ask after the usual window has begun
      var has = db.entries.some(function (e) { return e.actId === id && e.state === 'CONFIRMED' && e.localDate === today; });
      var k = 'SUGGEST:' + id + ':' + today; if (has || db.clarify.dismissed[k] || db.clarify.skipped[k] > nowMs) return;
      var a = actOf(db, id);
      out.push({ id: k, actId: id, medianStartMin: med, medianDurMin: dm, days: Object.keys(nd).length,
        text: 'You usually do "' + a.name + '" around ' + OT.fmtClock(Math.floor(med / 60), med % 60, tf) + '. Did you do it today?',
        evidence: Object.keys(nd).length + ' of the last ' + look + ' days' });
    });
    return out;
  };
  /** Approve a suggestion: creates a confirmed entry only with user-supplied times. */
  OE.approveSuggestion = function (db, sug, startUtc, endUtc, nowMs) { return OE.addEntry(db, { actId: sug.actId, startUtc: startUtc, endUtc: endUtc, source: 'suggested' }, nowMs, 'reject'); };
  OE.dismissSuggestion = function (db, sug) { db.clarify.dismissed[sug.id] = 1; };

  g.OPUX.engine = OE;
  if (typeof module !== 'undefined') module.exports = OE;
})(typeof window !== 'undefined' ? window : globalThis);
