# OPUX development status — Phase 1 (data core + time engine)

Date of this report: November 22, 2026 (Sunday).

## What the shipped app does right now
The app UI (`assets/index.html`) is **unchanged** and still uses the legacy `h24v1` storage. The new modules in
`assets/js/` are **not wired into the UI yet** on purpose: wiring the loader while the UI still writes `h24v1` would make
`opux_v2` go stale after the first launch. Wiring happens together with the UI port (step 9).

## Implemented (assets/js)
| File | Contents |
|---|---|
| `opux-time.js` | Timezone-aware date/time maths (UTC ms storage, local date per IANA tz), DST-correct day length, date formats (default `October 30, 2026 (Friday)`), 12h/24h time formats |
| `opux-core.js` | Schema v2, validation, `h24v1` → v2 migration with byte-identical backup + post-migration verification, corrupt-data handling, JSON export/import (v2, legacy-compatible export, legacy import) |
| `opux-rdbd.js` | Daily identities (permanent day numbers), works W001… (status history, subprojects, milestones, progress), 4 relation types with cycle protection, contributions derived from time entries, seasons (calendar-month numbering), yearbook years |
| `opux-engine.js` | Accounting (exclusive buckets that always sum to the real day length), timeline (CONFIRMED / DETECTED / UNKNOWN / OVERLAP / GAP), conflict handling (reject / fillGaps / replace), split / merge / reclassify / edit / delete, timer (survives restart, crosses midnight), detected-vs-manual matching, clarification questions, pattern suggestions |

## Tested and passed (Node 22, `node tests/run-tests.js`): 51 / 51
Plus one browser check (headless Chromium, `file://` classic scripts, real `localStorage`): migration ran, backup key and
`opux_v2` created, `h24v1` kept, accounting balanced. Chromium is not the Android WebView; this is **partial** evidence.

## Not implemented yet
UI port to the v2 model, review/clarification screens, Neural Atlas, widgets, Settings panel, boot sequence rework, liquid
upgrades, native Android layer (UsageStats, music service, PDF), reports/Yearbook, Decision Wheel, Focus Mode, Achievements,
Intelligence, season archive UI.

## Not tested
Gradle build, APK, any Android device behaviour (UsageStats permission, sensors, music, notifications), PDF output,
performance on mid-range hardware, offline behaviour inside the WebView.

## Decisions and assumptions (please check)
1. **Legacy records** have durations only. They are placed sequentially from local midnight, flagged `legacyPlaced`, state
   CONFIRMED, source `legacy`, with `origMin` kept. Their clock times are synthetic and are excluded from pattern suggestions.
2. **Day numbers** = calendar days since 2026-11-01 (+1), so Day 001 = November 1, 2026. Earlier dates get `Pre-NNN`.
3. **Season 001** = November 2026; earlier months fall into Season 000 (Prologue).
4. **Statistics:** only CONFIRMED time is counted per category. DETECTED-only and unrecorded time are reported as unknown,
   never as unwanted. An overlapped span is counted once (earlier-starting entry) and flagged OVERLAP.
5. **Timer stop** over existing records records only the free time and reports the skipped remainder.
6. **While a timer runs**, questions appear only in an explicit review.
7. **Storage origin:** the app keeps loading from `file:///android_asset/` so the existing WebView `localStorage` (with
   `h24v1`) stays readable. Switching to `WebViewAssetLoader` (https origin) would hide it.

## Known limitation / blocker
`three_module.js` imports `./three.core.js`, which was not supplied. Without it, Scene, Mesh, Vector3, etc. do not exist.
Needed: `three.core.js` of the same release as `three.module.js`. Both are kept in `vendor-src/`. They will be bundled into
one classic script (esbuild is available here) because ES modules cannot be loaded from `file://` in WebView.
