PG CINEMATIC — PWA-ready source package
Theme: Black + Gold Premium
Contact: WhatsApp +91 92095 72201; Instagram @pg_cinematic_graphic_designer

Included:
- index.html: mobile-friendly app prototype, prices, gallery, order form
- manifest.webmanifest: installable PWA metadata
- service-worker.js: basic offline cache
- icons/icon.svg: app icon

IMPORTANT:
This package is NOT an APK and is NOT yet hosted online.
To use PWABuilder for an Android package, publish these files to a public HTTPS website first. PWABuilder requires a valid PWA with a web manifest, hosted securely through HTTPS. Then enter that public URL at https://www.pwabuilder.com/ and choose the Android package option.
Do not upload a personal phone number publicly unless you want customers to contact it. The current app includes the WhatsApp number supplied for this project.
For Play Store publication, prepare the .aab package and complete Google Play Console requirements, review, and testing. New personal developer accounts may need a closed test with at least 12 testers continuously opted in for 14 days before applying for production access.
