const currencyNamesPashto = {
    AFN: "افغانۍ (افغانستان)",
    USD: "امریکايي ډالر (امریکا)",
    EUR: "یورو (اروپايي اتحادیه)",
    PKR: "پاکستانۍ کلدارې (پاکستان)",
    IRR: "ایراني تومان/ریال (ایران)",
    SAR: "سعودي ریال (سعودي عربستان)",
    AED: "اماراتي درهم (متحده عرب امارات)",
    GBP: "برتانوي پونډ (برتانیا)",
    INR: "هندي روپۍ (هند)",
    TRY: "ترکي لیره (ترکیه)",
    CNY: "چینايي یوان (چین)",
    RUB: "روسي روبل (روسیه)",
    CAD: "کاناډايي ډالر (کاناډا)",
    AUD: "آسټرالیايي ډالر (آسټرالیا)",
    CHF: "سویس فرانک (سویس)",
    JPY: "جاپاني ین (جاپان)",
    KWD: "کویتي دینار (کویت)",
    QAR: "قطري ریال (قطر)",
    OMR: "عماني ریال (عمان)",
    BHD: "بحریني دینار (بحرین)",
    JOD: "اردني دینار (اردن)",
    IQD: "عراقي دینار (عراق)",
    EGP: "مصري پونډ (مصر)",
    UZS: "ازبکستاني سوم (ازبکستان)",
    TJS: "تاجکستاني سوموني (تاجکستان)",
    TMT: "ترکمنستاني منات (ترکمنستان)",
    KZT: "قزاقستاني ټېنګه (قزاقستان)",
    MYR: "مالیزیايي رینګیټ (مالیزیا)",
    IDR: "اندونیزیايي روپیه (اندونیزیا)",
    KRW: "جنوبي کوریايي وون (کوریا)",
    SEK: "سویډني کرون (سویډن)",
    NOK: "ناروېجي کرون (ناروې)",
    DKK: "ډنمارکي کرون (ډنمارک)",
    NZD: "نیوزیلنډي ډالر (نیوزیلنډ)",
    SGD: "سینګاپوري ډالر (سینګاپور)",
    HKD: "هانګ کانګ ډالر (هانګ کانګ)",
    ZAR: "جنوبي افریقايي رنډ (جنوبي افریقا)",
    BRL: "برازیلي ریال (برازیل)",
    MXN: "مکسیکويي پېسو (مکسیکو)"
};

const perThousandCurrencies = ["IRR", "UZS", "IDR", "KRW", "IQD"];
const watchlistCodes = ["USD", "EUR", "PKR", "SAR", "AED", "GBP", "IRR", "INR", "TRY", "CNY"];

// لومړني باوري نرخونه (فوري د اپلېکېشن د چلولو لپاره)
const defaultRates = {
    AFN: 70.50, USD: 1.00, EUR: 0.92, PKR: 278.50, IRR: 42100.00,
    SAR: 3.75, AED: 3.67, GBP: 0.79, INR: 84.40, TRY: 34.50,
    CNY: 7.24, RUB: 98.50, CAD: 1.40, AUD: 1.53, CHF: 0.88,
    JPY: 154.20, KWD: 0.31, QAR: 3.64, OMR: 0.38, BHD: 0.38,
    JOD: 0.71, IQD: 1310.00, EGP: 49.30, UZS: 12800.00, TJS: 10.65,
    TMT: 3.50, KZT: 495.00, MYR: 4.46, IDR: 15850.00, KRW: 1395.00
};

let baseRatesFromUSD = { ...defaultRates };
let liveRatesFromUSD = { ...defaultRates };
let baseGoldOzUSD = 2650.00;
let liveGoldOzUSD = 2650.00;
let baseSilverOzUSD = 31.50;
let liveSilverOzUSD = 31.50;

let currentMode = "GOLD"; // GOLD, SILVER, CURRENCY
let currentCurrencyCode = "USD";
let currentChartType = "CANDLE"; // CANDLE یا AREA
let currentTimeframe = "1S";
let currentCandles = [];
let sessionOpenPrice = 0;
let sessionHighPrice = 0;
let sessionLowPrice = 0;
let tickCounter = 0;
let engineTimer = null;

document.addEventListener("DOMContentLoaded", () => {
    setupNavigation();
    setupTerminalControls();
    loadCache();
    populateDropdowns();
    rebuildChartSeries();
    renderAllLists();
    updateLivePricesInDOM();
    startRealTimeMarketEngine();
    fetchInitialMarketPrices();
});

// ۱. د لاندینۍ مینو تنظیمول (اوس ۱۰۰٪ کار کوي)
function setupNavigation() {
    const navBtns = document.querySelectorAll(".nav-btn");
    const views = document.querySelectorAll(".tab-view");

    navBtns.forEach(btn => {
        btn.addEventListener("click", () => {
            const target = btn.getAttribute("data-tab");
            navBtns.forEach(b => b.classList.remove("active"));
            btn.classList.add("active");

            views.forEach(v => {
                if (v.id === target) {
                    v.classList.add("active");
                } else {
                    v.classList.remove("active");
                }
            });

            if (target === "tradingSection") {
                drawCustomTradingChart();
            }
        });
    });
}

// ۲. د تڼیو او انتخابونو تنظیمول
function setupTerminalControls() {
    document.querySelectorAll(".a-tab").forEach(btn => {
        btn.addEventListener("click", () => {
            document.querySelectorAll(".a-tab").forEach(b => b.classList.remove("active-gold", "active-silver", "active-currency"));
            currentMode = btn.getAttribute("data-mode");

            const curBar = document.getElementById("currencyDropdownRow");
            if (currentMode === "GOLD") {
                btn.classList.add("active-gold");
                curBar.style.display = "none";
            } else if (currentMode === "SILVER") {
                btn.classList.add("active-silver");
                curBar.style.display = "none";
            } else {
                btn.classList.add("active-currency");
                curBar.style.display = "flex";
            }
            rebuildChartSeries();
        });
    });

    document.querySelectorAll(".type-btn").forEach(btn => {
        btn.addEventListener("click", () => {
            document.querySelectorAll(".type-btn").forEach(b => b.classList.remove("active"));
            btn.classList.add("active");
            currentChartType = btn.getAttribute("data-charttype");
            drawCustomTradingChart();
        });
    });

    document.querySelectorAll(".tf-pill").forEach(btn => {
        btn.addEventListener("click", () => {
            document.querySelectorAll(".tf-pill").forEach(b => b.classList.remove("active"));
            btn.classList.add("active");
            currentTimeframe = btn.getAttribute("data-tf");
            rebuildChartSeries();
        });
    });

    document.getElementById("tvCurrencySelect").addEventListener("change", (e) => {
        currentCurrencyCode = e.target.value;
        rebuildChartSeries();
    });

    document.getElementById("searchInput").addEventListener("input", (e) => {
        renderFullCurrencies(e.target.value);
    });

    document.getElementById("convAmount").addEventListener("input", updateConverter);
    document.getElementById("convFrom").addEventListener("change", updateConverter);
    document.getElementById("convTo").addEventListener("change", updateConverter);
    document.getElementById("convSwap").addEventListener("click", () => {
        const f = document.getElementById("convFrom");
        const t = document.getElementById("convTo");
        const temp = f.value;
        f.value = t.value;
        t.value = temp;
        updateConverter();
    });

    document.getElementById("refreshBtn").addEventListener("click", fetchInitialMarketPrices);
    window.addEventListener("resize", drawCustomTradingChart);
}

// ۳. له انټرنېټ څخه د ژوندیو نرخونو راوستل
async function fetchInitialMarketPrices() {
    const icon = document.querySelector("#refreshBtn i");
    if (icon) icon.classList.add("spinning");

    try {
        const res = await fetch("https://open.er-api.com/v6/latest/USD");
        const data = await res.json();
        if (data && data.rates) {
            baseRatesFromUSD = { ...data.rates };
            liveRatesFromUSD = { ...data.rates };
        }

        try {
            const gRes = await fetch("https://api.gold-api.com/price/XAU");
            const gData = await gRes.json();
            if (gData && gData.price) {
                baseGoldOzUSD = liveGoldOzUSD = gData.price;
            }

            const sRes = await fetch("https://api.gold-api.com/price/XAG");
            const sData = await sRes.json();
            if (sData && sData.price) {
                baseSilverOzUSD = liveSilverOzUSD = sData.price;
            }
        } catch (e) {
            if (baseRatesFromUSD.XAU) baseGoldOzUSD = liveGoldOzUSD = 1 / baseRatesFromUSD.XAU;
            if (baseRatesFromUSD.XAG) baseSilverOzUSD = liveSilverOzUSD = 1 / baseRatesFromUSD.XAG;
        }

        localStorage.setItem("ar_tv_cache_v2", JSON.stringify({
            rates: baseRatesFromUSD,
            gold: baseGoldOzUSD,
            silver: baseSilverOzUSD
        }));

        document.getElementById("marketStatusText").textContent = "نړیوال بازار فعال دی • ژوندی جریان (Live)";
        populateDropdowns();
        rebuildChartSeries();
        renderAllLists();
    } catch (err) {
        document.getElementById("marketStatusText").textContent = "آفلاین حالت • خوندي شوي ژوندي نرخونه";
    } finally {
        if (icon) icon.classList.remove("spinning");
    }
}

function loadCache() {
    try {
        const raw = localStorage.getItem("ar_tv_cache_v2");
        if (raw) {
            const parsed = JSON.parse(raw);
            if (parsed.rates) {
                baseRatesFromUSD = { ...parsed.rates };
                liveRatesFromUSD = { ...parsed.rates };
            }
            if (parsed.gold) baseGoldOzUSD = liveGoldOzUSD = parsed.gold;
            if (parsed.silver) baseSilverOzUSD = liveSilverOzUSD = parsed.silver;
        }
    } catch (e) {}
}

function getActiveAssetPrice() {
    const afnPerUsd = liveRatesFromUSD.AFN || 70.5;
    if (currentMode === "GOLD") {
        return liveGoldOzUSD;
    } else if (currentMode === "SILVER") {
        return liveSilverOzUSD;
    } else {
        const rate = liveRatesFromUSD[currentCurrencyCode] || 1;
        const mult = perThousandCurrencies.includes(currentCurrencyCode) ? 1000 : 1;
        return (afnPerUsd / rate) * mult;
    }
}

// ۴. د شمعو (Candles) تاریخچه جوړول
function rebuildChartSeries() {
    const currentPrice = getActiveAssetPrice();
    const count = 34;
    let price = currentPrice * 0.9965;
    currentCandles = [];

    const volFactor = currentTimeframe === "1S" ? 0.0012 :
                      currentTimeframe === "15M" ? 0.0025 :
                      currentTimeframe === "1H" ? 0.0045 : 0.008;

    for (let i = count; i >= 1; i--) {
        const open = price;
        const move = (Math.sin(i * 0.8) + (Math.random() - 0.48)) * (currentPrice * volFactor);
        const close = i === 1 ? currentPrice : Math.max(0.0001, open + move);
        const high = Math.max(open, close) + Math.abs(move) * (0.4 + Math.random() * 0.5);
        const low = Math.min(open, close) - Math.abs(move) * (0.4 + Math.random() * 0.5);

        currentCandles.push({ open, high, low, close });
        price = close;
    }

    sessionOpenPrice = currentCandles[0].open;
    sessionHighPrice = Math.max(...currentCandles.map(c => c.high));
    sessionLowPrice = Math.min(...currentCandles.map(c => c.low));

    updateTerminalHeaderUI(currentPrice, currentPrice);
    drawCustomTradingChart();
}

// ۵. د خپلواک TradingView ګراف رسمول (Candles + Area Line + Live Price Tag)
function drawCustomTradingChart() {
    const canvas = document.getElementById("proTradingCanvas");
    if (!canvas || currentCandles.length === 0) return;

    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.parentElement.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return;

    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;

    const ctx = canvas.getContext("2d");
    ctx.scale(dpr, dpr);

    const w = rect.width;
    const h = rect.height;
    const padRight = 64; // د ښي اړخ نرخونو لپاره ځای
    const padTop = 16;
    const padBottom = 18;
    const plotW = w - padRight;
    const plotH = h - padTop - padBottom;

    ctx.clearRect(0, 0, w, h);

    // تر ټولو لوړ او ټیټ قیمت موندل
    let maxP = Math.max(...currentCandles.map(c => c.high));
    let minP = Math.min(...currentCandles.map(c => c.low));
    const margin = (maxP - minP) * 0.12 || maxP * 0.002;
    maxP += margin;
    minP -= margin;
    const range = maxP - minP || 1;

    const priceToY = (p) => padTop + plotH - ((p - minP) / range) * plotH;

    // شالید شبکې کرښې (Grid Lines) او ښي اړخ نرخونه
    ctx.strokeStyle = "rgba(42, 46, 57, 0.55)";
    ctx.lineWidth = 1;
    ctx.font = "10px Poppins, monospace";
    ctx.fillStyle = "#787b86";
    ctx.textAlign = "left";

    const gridSteps = 4;
    for (let i = 0; i <= gridSteps; i++) {
        const y = padTop + (plotH / gridSteps) * i;
        const pVal = maxP - (range / gridSteps) * i;

        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(plotW, y);
        ctx.stroke();

        ctx.fillText(formatAxisPrice(pVal), plotW + 6, y + 3);
    }

    // د رنګونو انتخاب
    const isGold = currentMode === "GOLD";
    const isSilver = currentMode === "SILVER";
    const bullColor = isGold ? "#fbbf24" : isSilver ? "#e2e8f0" : "#089981";
    const bearColor = "#f23645";

    const stepX = plotW / currentCandles.length;

    if (currentChartType === "CANDLE") {
        // د شمعو (Candlesticks) رسمول
        const candleW = Math.max(3, stepX * 0.58);

        currentCandles.forEach((c, idx) => {
            const centerX = idx * stepX + stepX / 2;
            const yOpen = priceToY(c.open);
            const yClose = priceToY(c.close);
            const yHigh = priceToY(c.high);
            const yLow = priceToY(c.low);

            const isUp = c.close >= c.open;
            const color = isUp ? bullColor : bearColor;

            // د شمعې پلته (Wick)
            ctx.strokeStyle = color;
            ctx.lineWidth = 1.3;
            ctx.beginPath();
            ctx.moveTo(centerX, yHigh);
            ctx.lineTo(centerX, yLow);
            ctx.stroke();

            // د شمعې تنه (Body)
            ctx.fillStyle = color;
            const bodyTop = Math.min(yOpen, yClose);
            const bodyH = Math.max(2, Math.abs(yClose - yOpen));
            ctx.fillRect(centerX - candleW / 2, bodyTop, candleW, bodyH);
        });
    } else {
        // د کرښې (Area Line) رسمول
        const grad = ctx.createLinearGradient(0, padTop, 0, h - padBottom);
        grad.addColorStop(0, isGold ? "rgba(251, 191, 36, 0.38)" : isSilver ? "rgba(226, 232, 240, 0.35)" : "rgba(16, 185, 129, 0.35)");
        grad.addColorStop(1, "rgba(0, 0, 0, 0)");

        ctx.beginPath();
        currentCandles.forEach((c, idx) => {
            const x = idx * stepX + stepX / 2;
            const y = priceToY(c.close);
            if (idx === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
        });

        ctx.strokeStyle = bullColor;
        ctx.lineWidth = 2.2;
        ctx.stroke();

        // لاندې سیوری
        ctx.lineTo((currentCandles.length - 1) * stepX + stepX / 2, h - padBottom);
        ctx.lineTo(stepX / 2, h - padBottom);
        ctx.closePath();
        ctx.fillStyle = grad;
        ctx.fill();
    }

    // د وروستي ژوندي قیمت افقي کرښه او لیبل (Live Ticker Tag)
    const lastCandle = currentCandles[currentCandles.length - 1];
    const lastY = priceToY(lastCandle.close);
    const isLastUp = lastCandle.close >= lastCandle.open;
    const tagColor = isLastUp ? bullColor : bearColor;

    ctx.setLineDash([4, 4]);
    ctx.strokeStyle = tagColor;
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, lastY);
    ctx.lineTo(plotW, lastY);
    ctx.stroke();
    ctx.setLineDash([]);

    // د ښي اړخ د قیمت بکس
    ctx.fillStyle = tagColor;
    ctx.fillRect(plotW + 2, lastY - 9, padRight - 4, 18);
    ctx.fillStyle = "#0b0e14";
    ctx.font = "bold 10px Poppins, monospace";
    ctx.fillText(formatAxisPrice(lastCandle.close), plotW + 6, lastY + 3.5);
}

function formatAxisPrice(val) {
    if (val >= 1000) return val.toFixed(1);
    if (val >= 10) return val.toFixed(2);
    return val.toFixed(3);
}

// ۶. د ژوندي بازار انجن: هره ثانیه نرخونه پورته او ښکته کوي
function startRealTimeMarketEngine() {
    if (engineTimer) clearInterval(engineTimer);

    engineTimer = setInterval(() => {
        const prevPrice = getActiveAssetPrice();

        // سره زر او سپین زر ژوندی حرکت
        const goldDelta = (Math.random() - 0.495) * (baseGoldOzUSD * 0.0005);
        liveGoldOzUSD = Math.max(baseGoldOzUSD * 0.97, Math.min(baseGoldOzUSD * 1.03, liveGoldOzUSD + goldDelta));

        const silverDelta = (Math.random() - 0.495) * (baseSilverOzUSD * 0.0007);
        liveSilverOzUSD = Math.max(baseSilverOzUSD * 0.97, Math.min(baseSilverOzUSD * 1.03, liveSilverOzUSD + silverDelta));

        // د نړۍ ټول اسعار ژوندی حرکت
        Object.keys(liveRatesFromUSD).forEach(code => {
            if (code === "USD") return;
            const baseVal = baseRatesFromUSD[code];
            const delta = (Math.random() - 0.498) * (baseVal * 0.0004);
            liveRatesFromUSD[code] = Math.max(baseVal * 0.98, Math.min(baseVal * 1.02, liveRatesFromUSD[code] + delta));
        });

        const newPrice = getActiveAssetPrice();
        tickCounter++;

        if (currentCandles.length > 0) {
            if (tickCounter % 4 === 0) {
                // هر ۴ ثانیې نوې شمعه جوړول
                const prevClose = currentCandles[currentCandles.length - 1].close;
                currentCandles.push({
                    open: prevClose,
                    high: Math.max(prevClose, newPrice),
                    low: Math.min(prevClose, newPrice),
                    close: newPrice
                });
                if (currentCandles.length > 36) currentCandles.shift();
            } else {
                // وروستۍ شمعه ژوندۍ پورته/ښکته کول
                const last = currentCandles[currentCandles.length - 1];
                last.close = newPrice;
                if (newPrice > last.high) last.high = newPrice;
                if (newPrice < last.low) last.low = newPrice;
            }
        }

        if (newPrice > sessionHighPrice) sessionHighPrice = newPrice;
        if (newPrice < sessionLowPrice) sessionLowPrice = newPrice;

        updateTerminalHeaderUI(newPrice, prevPrice);
        drawCustomTradingChart();
        updateLivePricesInDOM();
    }, 1000);
}

function updateTerminalHeaderUI(newPrice, prevPrice) {
    const priceEl = document.getElementById("tvLivePrice");
    const symName = document.getElementById("tvSymbolName");
    const subDetail = document.getElementById("tvSubDetail");
    const badge = document.getElementById("tvChangeBadge");
    const afnRate = liveRatesFromUSD.AFN || 70.5;

    let prefix = "$";
    let suffix = "";
    let afnEquivalent = 0;

    if (currentMode === "GOLD") {
        symName.textContent = "XAU / USD • سره زر (نړیوال)";
        afnEquivalent = newPrice * afnRate;
        subDetail.textContent = `۱ اونس سره زر • ${formatNum(afnEquivalent)} AFN`;
    } else if (currentMode === "SILVER") {
        symName.textContent = "XAG / USD • سپین زر (نړیوال)";
        afnEquivalent = newPrice * afnRate;
        subDetail.textContent = `۱ اونس سپین زر • ${formatNum(afnEquivalent)} AFN`;
    } else {
        prefix = "";
        suffix = " AFN";
        const isK = perThousandCurrencies.includes(currentCurrencyCode);
        const unitStr = isK ? `۱۰۰۰ ${currentCurrencyCode}` : `۱ ${currentCurrencyCode}`;
        const pName = (currencyNamesPashto[currentCurrencyCode] || currentCurrencyCode).split("(")[0];
        symName.textContent = `${currentCurrencyCode} / AFN • ${pName}`;
        afnEquivalent = newPrice;
        subDetail.textContent = `${unitStr} • 1 USD = ${formatNum(liveRatesFromUSD[currentCurrencyCode] || 1)} ${currentCurrencyCode}`;
    }

    priceEl.textContent = `${prefix}${formatNum(newPrice)}${suffix}`;

    priceEl.classList.remove("flash-up", "flash-down");
    if (newPrice > prevPrice) {
        priceEl.classList.add("flash-up");
    } else if (newPrice < prevPrice) {
        priceEl.classList.add("flash-down");
    }
    setTimeout(() => priceEl.classList.remove("flash-up", "flash-down"), 450);

    const pct = sessionOpenPrice > 0 ? ((newPrice - sessionOpenPrice) / sessionOpenPrice) * 100 : 0;
    badge.className = `change-pill ${pct >= 0 ? "up" : "down"}`;
    badge.innerHTML = `<i class="fa-solid fa-caret-${pct >= 0 ? "up" : "down"}"></i> ${pct >= 0 ? "+" : ""}${pct.toFixed(2)}%`;

    document.getElementById("statHigh").textContent = `${prefix}${formatNum(sessionHighPrice)}`;
    document.getElementById("statLow").textContent = `${prefix}${formatNum(sessionLowPrice)}`;
    document.getElementById("statAfn").textContent = `${formatNum(afnEquivalent)} AFN`;
}

function updateLivePricesInDOM() {
    const afnRate = liveRatesFromUSD.AFN || 70.5;

    const strip = document.getElementById("topTickerStrip");
    if (strip) {
        const items = [
            { label: "GOLD", val: `$${liveGoldOzUSD.toFixed(2)}`, mode: "GOLD" },
            { label: "SILVER", val: `$${liveSilverOzUSD.toFixed(2)}`, mode: "SILVER" },
            { label: "USD/AFN", val: afnRate.toFixed(2), code: "USD" },
            { label: "EUR/AFN", val: (afnRate / (liveRatesFromUSD.EUR || 0.92)).toFixed(2), code: "EUR" },
            { label: "PKR/AFN", val: (afnRate / (liveRatesFromUSD.PKR || 278)).toFixed(3), code: "PKR" },
            { label: "SAR/AFN", val: (afnRate / (liveRatesFromUSD.SAR || 3.75)).toFixed(2), code: "SAR" }
        ];

        strip.innerHTML = items.map(it => `
            <div class="mini-tick" onclick="${it.mode ? `selectModeFromTicker('${it.mode}')` : `openCurrencyChart('${it.code}')`}">
                <strong>${it.label}</strong>
                <span class="gold-txt">${it.val}</span>
            </div>
        `).join("");
    }

    document.querySelectorAll("[data-live-code]").forEach(el => {
        const code = el.getAttribute("data-live-code");
        if (!liveRatesFromUSD[code]) return;
        const mult = perThousandCurrencies.includes(code) ? 1000 : 1;
        const val = (afnRate / liveRatesFromUSD[code]) * mult;
        const oldVal = parseFloat(el.getAttribute("data-prev")) || val;

        el.textContent = `${formatNum(val)} AFN`;
        el.setAttribute("data-prev", val);

        if (val > oldVal) el.style.color = "#10b981";
        else if (val < oldVal) el.style.color = "#f23645";
    });

    renderMetalsTab();
}

function selectModeFromTicker(mode) {
    const btn = document.querySelector(`.a-tab[data-mode="${mode}"]`);
    if (btn) btn.click();
}

function openCurrencyChart(code) {
    currentMode = "CURRENCY";
    currentCurrencyCode = code;

    document.querySelectorAll(".a-tab").forEach(b => b.classList.remove("active-gold", "active-silver", "active-currency"));
    document.querySelector('.a-tab[data-mode="CURRENCY"]').classList.add("active-currency");
    document.getElementById("currencyDropdownRow").style.display = "flex";
    document.getElementById("tvCurrencySelect").value = code;

    document.querySelector('.nav-btn[data-tab="tradingSection"]').click();
    rebuildChartSeries();
    window.scrollTo({ top: 0, behavior: "smooth" });
}

function populateDropdowns() {
    const codes = Object.keys(liveRatesFromUSD).sort((a, b) => {
        if (a === "AFN") return -1;
        if (b === "AFN") return 1;
        if (a === "USD") return -1;
        if (b === "USD") return 1;
        return a.localeCompare(b);
    });

    const opts = codes.map(c => `<option value="${c}">${c} - ${currencyNamesPashto[c] || c}</option>`).join("");
    const nonAfnOpts = codes.filter(c => c !== "AFN").map(c => `<option value="${c}">${c} - ${currencyNamesPashto[c] || c}</option>`).join("");

    document.getElementById("tvCurrencySelect").innerHTML = nonAfnOpts;
    document.getElementById("tvCurrencySelect").value = currentCurrencyCode;

    const cFrom = document.getElementById("convFrom");
    const cTo = document.getElementById("convTo");
    const prevF = cFrom.value || "USD";
    const prevT = cTo.value || "AFN";
    cFrom.innerHTML = opts;
    cTo.innerHTML = opts;
    cFrom.value = prevF;
    cTo.value = prevT;
    updateConverter();
}

function renderAllLists() {
    const afnRate = liveRatesFromUSD.AFN || 70.5;
    const wlContainer = document.getElementById("liveWatchlist");
    wlContainer.innerHTML = watchlistCodes.map(code => {
        if (!liveRatesFromUSD[code]) return "";
        const isK = perThousandCurrencies.includes(code);
        const mult = isK ? 1000 : 1;
        const val = (afnRate / liveRatesFromUSD[code]) * mult;
        const name = (currencyNamesPashto[code] || code).split("(")[0];
        return `
            <div class="watch-row" onclick="openCurrencyChart('${code}')">
                <div class="watch-left">
                    <div class="code-pill">${code}</div>
                    <div class="watch-name">
                        <h4>${name}</h4>
                        <small>${isK ? `۱۰۰۰ ${code}` : `۱ ${code}`} • ګراف</small>
                    </div>
                </div>
                <div class="watch-right">
                    <div class="watch-price" data-live-code="${code}" data-prev="${val}">${formatNum(val)} AFN</div>
                    <div class="watch-sub">1 USD = ${formatNum(liveRatesFromUSD[code])} ${code}</div>
                </div>
            </div>
        `;
    }).join("");

    renderFullCurrencies("");
    renderMetalsTab();
}

function renderFullCurrencies(query) {
    const q = query.trim().toLowerCase();
    const afnRate = liveRatesFromUSD.AFN || 70.5;
    const codes = Object.keys(liveRatesFromUSD).filter(c => c !== "AFN");

    document.getElementById("fullCurrenciesContainer").innerHTML = codes.filter(code => {
        const full = currencyNamesPashto[code] || code;
        return !q || code.toLowerCase().includes(q) || full.toLowerCase().includes(q);
    }).map(code => {
        const isK = perThousandCurrencies.includes(code);
        const mult = isK ? 1000 : 1;
        const val = (afnRate / liveRatesFromUSD[code]) * mult;
        const name = (currencyNamesPashto[code] || code).split("(")[0];
        return `
            <div class="watch-row" onclick="openCurrencyChart('${code}')">
                <div class="watch-left">
                    <div class="code-pill">${code}</div>
                    <div class="watch-name">
                        <h4>${name}</h4>
                        <small>${isK ? `1,000 ${code}` : `1 ${code}`}</small>
                    </div>
                </div>
                <div class="watch-right">
                    <div class="watch-price" data-live-code="${code}" data-prev="${val}">${formatNum(val)} AFN</div>
                    <div class="watch-sub">1 USD = ${formatNum(liveRatesFromUSD[code])} ${code}</div>
                </div>
            </div>
        `;
    }).join("");
}

function updateConverter() {
    const amt = parseFloat(document.getElementById("convAmount").value) || 0;
    const from = document.getElementById("convFrom").value;
    const to = document.getElementById("convTo").value;
    if (!liveRatesFromUSD[from] || !liveRatesFromUSD[to]) return;

    const rate = liveRatesFromUSD[to] / liveRatesFromUSD[from];
    document.getElementById("convFormula").textContent = `1 ${from} = ${formatNum(rate)} ${to}`;
    document.getElementById("convResult").textContent = `${formatNum(amt * rate)} ${to}`;
}

function renderMetalsTab() {
    const afnRate = liveRatesFromUSD.AFN || 70.5;
    const G_OZ = 31.1034768;
    const g24 = liveGoldOzUSD / G_OZ;

    const goldList = [
        { t: "۱ ګرام (۲۴ عیار)", s: "خالص سره زر 999", u: g24 },
        { t: "۱ ګرام (۲۲ عیار)", s: "خلیجي طلا", u: g24 * (22 / 24) },
        { t: "۱ ګرام (۲۱ عیار)", s: "د افغانستان بازاري طلا", u: g24 * (21 / 24) },
        { t: "۱ ګرام (۱۸ عیار)", s: "اېټالوي طلا", u: g24 * (18 / 24) },
        { t: "۱ اونس (31.10g)", s: "نړیوال معیار", u: liveGoldOzUSD }
    ];

    document.getElementById("goldCairatList").innerHTML = goldList.map(i => `
        <div class="m-row">
            <div><span>${i.t}</span><small>${i.s}</small></div>
            <div class="m-prices"><strong>${formatNum(i.u * afnRate)} AFN</strong><span>$${formatNum(i.u)}</span></div>
        </div>
    `).join("");

    const s1 = liveSilverOzUSD / G_OZ;
    const silverList = [
        { t: "۱ ګرام سپین زر", s: "خالص نقره 999", u: s1 },
        { t: "۱۰ ګرامه سپین زر", s: "نږدې یوه توله", u: s1 * 10 },
        { t: "۱ اونس (31.10g)", s: "نړیوال معیار", u: liveSilverOzUSD },
        { t: "۱ کیلوګرام سپین زر", s: "1000 Grams", u: s1 * 1000 }
    ];

    document.getElementById("silverCairatList").innerHTML = silverList.map(i => `
        <div class="m-row">
            <div><span>${i.t}</span><small>${i.s}</small></div>
            <div class="m-prices"><strong>${formatNum(i.u * afnRate)} AFN</strong><span>$${formatNum(i.u)}</span></div>
        </div>
    `).join("");
}

function formatNum(n) {
    if (n >= 100) return n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    if (n >= 1) return n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 3 });
    return n.toLocaleString("en-US", { minimumFractionDigits: 4, maximumFractionDigits: 4 });
}
