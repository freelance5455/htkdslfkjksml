KIA Iraq - نسخة تأسيسية للويب وAndroid

الملفات:
- index.html / style.css / app.js: الواجهة والوظائف.
- firebase-config.js: إعدادات مشروع Firebase الخاصة بك.
- firestore.rules: قواعد أمان مبدئية.
- manifest.json / sw.js: أساس تثبيت الويب كتطبيق PWA.
- package.json / capacitor.config.json: إعداد أولي لتغليف التطبيق عبر Capacitor.

تشغيل الربط:
1) أنشئ مشروعاً في https://console.firebase.google.com/
2) أضف تطبيق Web، وانسخ firebaseConfig إلى firebase-config.js.
3) فعّل Authentication > Email/Password.
4) أنشئ Firestore Database.
5) انشر قواعد firestore.rules من تبويب Rules.
6) انشر ملفات المجلد على استضافة HTTPS مثل Firebase Hosting.

مهم:
- لا تضع مفاتيح حساب خدمة Firebase أو كلمات مرور في ملفات الواجهة.
- حساب المدير يحتاج Custom Claims من بيئة موثوقة (Cloud Functions/Admin SDK)، ولا تمنحه من واجهة التسجيل.
- نسخة المدير ولوحات السائق والشركة والتحديثات المباشرة والإشعارات والدفع ليست مكتملة بعد.
- قواعد الأمان الحالية تمنح الإدارة فقط للحساب الذي يحمل custom claim باسم admin=true.
- بناء APK يحتاج بيئة Android build مثل Android Studio على حاسوب أو خدمة بناء سحابية موثوقة. هذا المجلد ليس APK جاهزاً.
