// انسخ إعدادات تطبيق الويب من Firebase Console والصقها هنا.
// لا تضع كلمات مرور أو مفاتيح حساب خدمة إدارية في هذا الملف.
export const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.firebasestorage.app",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID"
};
