# CricScorer

Offline-first, mobile-first cricket tournament manager built as a Progressive Web App (PWA). Tournament data and each recorded delivery are saved in browser `localStorage`. Includes the November Champions preset, editable teams/rosters, fixture scheduling, toss workflow, ball-by-ball scoring, scorecards, standings/NRR, a bracket builder, backup/import and a data-grounded offline assistant.

## Run locally

For best results serve this folder over HTTP (service workers do not work from every `file://` context):

```bash
python -m http.server 8080
```

Open `http://localhost:8080` in a browser. On Android Chrome, use **Install app** / **Add to Home screen**. Scoring and saved data work offline after the first successful load.

## Android APK path (requires Android Studio / Node.js)

This project is a PWA, not a compiled APK. To package it as an Android app using Capacitor:

```bash
npm init -y
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init CricScorer com.example.cricscorer --web-dir=.
npx cap add android
npx cap open android
```

In Android Studio select **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Use a unique application ID before publishing. Capacitor's webDir must include `index.html`, `app.js`, `manifest.json` and `sw.js`. For a production project, consider putting the PWA files in a `www/` folder and set `webDir: "www"`.

## Important implementation notes

- Data is local to the browser/device; no account, cloud sync or external AI API is configured. Export JSON backups regularly.
- The AI Assistant is a transparent, rule-based offline helper using saved tournament records, not a connected generative AI.
- Toss selection uses `Math.random()` for equal probability, persists the winner and decision, and cannot be rerun once saved unless an admin reset is permitted before deliveries begin.
- The points table documents NRR as runs-per-over for minus runs-per-over against, charging all-out innings the configured full overs.
- This starter implementation is runnable but should receive full cricket-rules QA before official competition use. Advanced features such as full super-over flow, robust bracket result linking, advanced run-out crossing/retired-hurt handling, and exhaustive edge-case scorekeeping need further testing and hardening.
