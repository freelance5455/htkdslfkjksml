const chat=document.getElementById('chat'), input=document.getElementById('input'), form=document.getElementById('composer');
const lang=document.getElementById('language'), historyBox=document.getElementById('history');

const texts={
 ar:{title:'مرحباً، أنا OLO AI',desc:'اسألني أي شيء. اختر العربية أو الكردية أو الإنجليزية.',ph:'اكتب رسالتك إلى OLO AI...'},
 ku:{title:'سڵاو، من OLO AIم',desc:'هەر پرسیارێکت هەیە، بپرسە. زمانی خۆت هەڵبژێرە.',ph:'پەیامێک بۆ OLO AI بنووسە...'},
 en:{title:'Hello, I’m OLO AI',desc:'Ask me anything. Choose Arabic, Kurdish, or English.',ph:'Message OLO AI...'}
};

function addMessage(who,text){
  const row=document.createElement('div'); row.className='message '+who;
  row.innerHTML=`<div class="avatar">${who==='user'?'You':'O'}</div><div class="bubble"></div>`;
  row.querySelector('.bubble').textContent=text; chat.appendChild(row); chat.scrollTop=chat.scrollHeight;
}
function botReply(message){
  const l=lang.value;
  const replies={
   ar:'هذه نسخة تجريبية من OLO AI. واجهة المحادثة جاهزة، ويمكن ربطها لاحقاً بخادم ذكاء اصطناعي حقيقي. اكتب سؤالك وسأعرضه هنا.',
   ku:'ئەمە وەشانی تاقیکردنەوەی OLO AI ـە. ڕووکاری گفتوگۆ ئامادەیە و دەتوانرێت بە سێرڤەرێکی زیرەکی دەستکردەوە پەیوەست بکرێت.',
   en:'This is the OLO AI starter app. The chat interface is ready and can later be connected to a real AI backend.'
  };
  setTimeout(()=>addMessage('bot',replies[l]),450);
}
form.addEventListener('submit',e=>{e.preventDefault();const v=input.value.trim();if(!v)return;addMessage('user',v);input.value='';botReply(v);historyBox.insertAdjacentHTML('afterbegin',`<div>${v.slice(0,28)}</div>`);});
document.querySelectorAll('[data-prompt]').forEach(b=>b.onclick=()=>{input.value=b.dataset.prompt;input.focus()});
lang.onchange=()=>{document.getElementById('welcomeTitle').textContent=texts[lang.value].title;document.getElementById('welcomeText').textContent=texts[lang.value].desc;input.placeholder=texts[lang.value].ph};
document.getElementById('newChat').onclick=()=>{chat.innerHTML='';location.reload()};
document.getElementById('menu').onclick=()=>document.querySelector('.sidebar').classList.toggle('open');
