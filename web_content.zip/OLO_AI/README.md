# OLO AI

A clean, mobile-friendly starter interface for an AI chat app called OLO AI.

## Run
Open `index.html` in a browser.

## Languages
Arabic, Kurdish, and English are included in the interface.

## Important
This starter is a frontend prototype. The chat currently returns demo responses. To make OLO AI a real AI assistant, connect the frontend to a secure backend that calls an AI model API. Never put a secret API key directly inside `app.js` or `index.html`.

## Next upgrades
- Real AI backend
- User accounts
- Saved conversations
- Voice input/output
- Image/file uploads
- Dark mode
- App-store/mobile packaging
