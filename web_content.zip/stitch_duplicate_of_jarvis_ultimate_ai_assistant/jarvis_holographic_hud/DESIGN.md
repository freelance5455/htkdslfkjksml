---
name: JARVIS Holographic HUD
colors:
  surface: '#0e131f'
  surface-dim: '#0e131f'
  surface-bright: '#343946'
  surface-container-lowest: '#080e1a'
  surface-container-low: '#161c28'
  surface-container: '#1a202c'
  surface-container-high: '#242a36'
  surface-container-highest: '#2f3542'
  on-surface: '#dde2f3'
  on-surface-variant: '#b9cacb'
  inverse-surface: '#dde2f3'
  inverse-on-surface: '#2b303d'
  outline: '#849495'
  outline-variant: '#3b494b'
  surface-tint: '#00dbe9'
  primary: '#dbfcff'
  on-primary: '#00363a'
  primary-container: '#00f0ff'
  on-primary-container: '#006970'
  inverse-primary: '#006970'
  secondary: '#7bd0ff'
  on-secondary: '#00354a'
  secondary-container: '#00a6e0'
  on-secondary-container: '#00374d'
  tertiary: '#f7f4ff'
  on-tertiary: '#131e8c'
  tertiary-container: '#d4d6ff'
  on-tertiary-container: '#4953bc'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#7df4ff'
  primary-fixed-dim: '#00dbe9'
  on-primary-fixed: '#002022'
  on-primary-fixed-variant: '#004f54'
  secondary-fixed: '#c4e7ff'
  secondary-fixed-dim: '#7bd0ff'
  on-secondary-fixed: '#001e2c'
  on-secondary-fixed-variant: '#004c69'
  tertiary-fixed: '#e0e0ff'
  tertiary-fixed-dim: '#bdc2ff'
  on-tertiary-fixed: '#000767'
  on-tertiary-fixed-variant: '#2f3aa3'
  background: '#0e131f'
  on-background: '#dde2f3'
  surface-variant: '#2f3542'
typography:
  headline-xl:
    fontFamily: Space Grotesk
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: 0.12em
  headline-xl-mobile:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: 0.1em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: 0.08em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: 0.06em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: 0.05em
  body-lg:
    fontFamily: Space Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0.02em
  body-md:
    fontFamily: Space Grotesk
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.02em
  body-sm:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.08em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.1em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 9px
    fontWeight: '600'
    lineHeight: 12px
    letterSpacing: 0.14em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-lg: 1.5rem
  margin: 1rem
  margin-md: 1.5rem
  margin-lg: 2.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system channels an advanced artificial intelligence heads-up display (HUD), engineered for real-time tactical awareness, flight telemetry, and biometric diagnostics. The brand aesthetic merges high-performance aerospace computing with futuristic sci-fi realism. It rejects flat, conventional web tropes in favor of an immersive tactical environment: dark, pitch-black space illuminated by high-energy electric cyan vectors, optical wireframes, glowing orbital rings, and dynamic system readouts.

Targeted at operators requiring instantaneous, mission-critical clarity, the UI projects razor-sharp computational intelligence, cold calm efficiency, and technological mastery. The design style combines dark glassmorphism, glowing vector optics, and structural blueprint brutalism. Surfaces behave as translucent glass lenses hovering in volumetric 3D space, filtering data through layered reticles, circular arc telemetry, and high-frequency real-time waveforms.

## Colors

The palette is anchored in an abyss-level void (#020617 and #030712) designed to make energetic spectral emissions pop with holographic intensity. 

- **Primary Electric Cyan (`#00f0ff`)**: The central photon emitter. Used for active targeting reticles, primary flight data indicators, vital alerts, interactive controls, and luminous arc rings.
- **Secondary Neon Blue (`#38bdf8`)**: Supportive data layer. Applied to secondary telemetry readouts, contextual borders, inactive HUD rings, and dynamic metric graphs.
- **Tertiary Deep Plasma (`#818cf8`)**: Reserved for neural analytics, override states, computational sub-routines, and auxiliary diagnostic nodes.
- **Neutral Void / Obsidian Glass (`#030712` base, `#0b1329` panel fill)**: Used for glass substrate layers, telemetry backdrops, and HUD container frames.
- **Cobalt Grid & Structural Accents (`#0f172a`, `#1e293b`)**: Structural guides, subtle raster lines, calibrated tick marks, and optical divider vectors.

Glow tokens must rely on layered drop shadows using semi-transparent primary values (`rgba(0, 240, 255, 0.45)` to `rgba(0, 240, 255, 0.08)`) rather than heavy opaque fills. All text defaults to pure cyan, pale ice white (`#f0fdff`), or muted sky cyan (`#7dd3fc`) to guarantee maximum contrast against pitch-black backgrounds.

## Typography

Typography functions as visual instrumentation. **Space Grotesk** serves as the primary structural display typeface, offering geometric precision, wide posture, and high legibility across dynamic optical displays. **JetBrains Mono** anchors all telemetry streams, coordinates, micro-labels, biometric readouts, system counters, and status values.

All titles, sub-headers, and diagnostic labels must be displayed in full uppercase with extended letter spacing to emulate targeting grids and avionics HUD readouts. For critical status metrics and telemetry values, font variants should utilize tabular numerals (`font-variant-numeric: tabular-nums`) to prevent optical shifting during live number streams.

## Layout & Spacing

The layout model simulates an adaptive 3-dimensional tactical HUD frame overlaid on an infinite viewport. 

- **Grid Architecture**: A modular 12-column dynamic HUD grid anchored by outer HUD corner brackets. Elements span 2, 3, 4, 6, or 12 units.
- **Center-Core Focal Zone**: A persistent circular or hexagonal dead-zone in desktop layouts reserved for central diagnostics (Arc Core reactor, target tracking reticles, weapon/power convergence).
- **Flank Wings**: Side telemetry pods (flight vectors, system integrity, audio waveforms, neural sync) dock on peripheral left and right columns.
- **Breakpoints**:
  - *Mobile (< 768px)*: Single vertical tactical column with docked bottom controls, stacked HUD metric strips, collapsed arc gauges, and reduced canvas margins (1rem).
  - *Tablet (768px - 1024px)*: 8-column layout. Central gauge shrinks, peripheral pods wrap into two-column side clusters.
  - *Desktop (> 1024px)*: Full 12-column peripheral wrap-around HUD layout with ultra-wide 2.5rem safe margins simulating full-visor situational awareness.

## Elevation & Depth

Visual hierarchy is constructed through optical projection tiers rather than physical drop shadows:

1. **Substrate (Layer 0)**: Pitch-black void (`#020617` / `#030712`) with ultra-faint coordinate dot matrices or circular polar grids at 5% opacity.
2. **Telemetry Glass Panels (Layer 1)**: Translucent, frosted glass backings using `backdrop-filter: blur(12px)`, background fills of `rgba(3, 7, 18, 0.65)`, framed by delicate 1px borders of `rgba(0, 240, 255, 0.2)`. Corner chamfers feature high-intensity tick marks.
3. **Active Vector Indicators (Layer 2)**: Crisp 1px vector lines, circular concentric rings, biometric wave graphs, and active readouts carrying a localized luminous bloom (`box-shadow: 0 0 12px rgba(0, 240, 255, 0.35)`).
4. **Primary Tactical Focus / Reticle (Layer 3)**: Core alerts, targeting matrices, and arc reactor state indicators elevated with concentrated dual glows (`box-shadow: 0 0 8px rgba(0, 240, 255, 0.8), 0 0 24px rgba(0, 240, 255, 0.4)`).
5. **Modal HUD Overrides (Layer 4)**: Full-visor warning overlays featuring high-contrast scanlines, ambient cyan vignette vignetting, and tactical dismiss nodes.

## Shapes

The interface utilizes a precision-engineered, soft technical aesthetic (roundedness scale `1`, standard border-radius `0.25rem` / `4px`). Elements avoid friendly bulbous curves; all geometries emphasize tactical instrument pods, clipped corners, circular dials, and segmented arc paths.

- **Chamfered Cuts & Tactical Brackets**: Panels feature 45-degree corner notches (4px to 8px) or L-shaped bracket bounds on top-left and bottom-right corners.
- **Circular Instrumentation**: Gauges, neural status monitors, and arc reactors use perfect circles (`rounded-full`) divided into segmented rotational arcs with dash-arrays.
- **Segmented Progress Bars**: Linear telemetry bars must be broken into discrete segmented pips (e.g., 20 individual capsules spaced 2px apart) to reflect machine calculations.

## Components

### Buttons & Tactical Triggers
- **Primary Action**: Hollow cyber-capsule with 1px border (`#00f0ff`), translucent cyan backdrop (`rgba(0, 240, 255, 0.08)`), text set in uppercase `JetBrains Mono` (`label-md`). Hover triggers a high-frequency cyan bloom, white-cyan interior flash, and audio-style tick feedback.
- **Critical / Override Action**: Dual-ringed border, glowing pulse animation, accompanied by a numeric sub-label indicating authorization state.
- **Ghost/Auxiliary Action**: Framed with faint cobalt borders (`#1e293b`), shifting to sky blue (`#38bdf8`) on focus.

### Telemetry Panels & Cards
- Constructed with obsidian glass (`rgba(3, 7, 18, 0.7)`), 1px border (`rgba(0, 240, 255, 0.2)`), and backdrop blur (12px to 16px).
- Every card must include a micro-header rail displaying subsystem name (e.g., `SYS.ARC_01 // ONLINE`), status LED dot, and optical coordinate indices.

### Biometric & Neural Status Chips
- Pill-shaped or micro-bracketed tags.
- Left edge contains a pulsating live vector dot (`#00f0ff` or `#818cf8`), followed by uppercase monospace diagnostic tags (e.g., `NEURAL SYNC: 99.4%`, `HEART RATE: 72 BPM`).
- State styles: Normal (Cyan), Elevated (Amber/Plasma), Compromised/Critical (Crimson Red with rapid glow pulse).

### Input Fields & Terminal Sliders
- Minimalist open-bottom or boxed frames: subtle bottom border (`1px solid #38bdf8`) or fully enclosed frosted obsidian container.
- Placeholder text in muted cyan-gray (`#38bdf8`, 40% opacity). Active state triggers a full cyan highlight and blinking block cursor.

### Audio Waveform & Arc Reactor Widgets
- **Waveform Monitor**: Real-time equalizer bars drawn with variable opacity gradients peaking at `#00f0ff` with a subtle mirror floor reflection.
- **Arc Core Reticle**: Dual concentric counter-rotating vector rings with degree marks (0° to 360°), inner core wattage readout, and dynamic particle emission ring.

### Checkboxes & Toggle Switches
- Checkboxes: Square with inverted chamfers, displaying an electric cyan crosshair or solid cyan fill pip when engaged.
- Switches: Segmented sliding node along a laser-thin track with numeric binary states (`01` / `00`) instead of traditional rounded knobs.