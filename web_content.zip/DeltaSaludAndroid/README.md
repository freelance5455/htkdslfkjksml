# DELTA SALUD — Proyecto Android

Aplicación Android que contiene el prototipo funcional de DELTA SALUD dentro de un WebView.

## Funciones incluidas
- Informe diario de traslados
- Nuevo traslado
- Pacientes
- Móviles
- Checklist del móvil
- Combustible
- Historial y exportación CSV
- Almacenamiento local en el teléfono

## Generar APK
Abrir esta carpeta en Android Studio y ejecutar:
- Build > Build APK(s)

El APK de depuración queda normalmente en:
`app/build/outputs/apk/debug/app-debug.apk`

Para publicar en Google Play se debe generar además una versión release firmada.
