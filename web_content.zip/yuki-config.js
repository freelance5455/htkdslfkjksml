window.YukiConfig = {
  version: '2.0-dev',
  aiMode: 'cloud',
  apiBase: '',
  features: {
    memory: true,
    animatedAvatar: false,
    voiceCall: false
  }
};
