# Busdriver Navi V16 – Android-Projekt mit Standortfreigabe

Dieses ZIP enthält **Android-Studio-Quellcode, keine installierbare APK**.

- Enthält den Stand der Weboberfläche V15 als lokale App-Assets.
- Lädt die App über eine HTTPS-App-Asset-Adresse, damit Web-Geolocation zulässig ist.
- Fragt Android-Standortberechtigungen bei GPS-Nutzung an (präzise/ungefähr).
- Unterstützt Android-Dateiauswahl für Fotos im Dienstplan-Scanner.
- Benötigt Internet für OpenStreetMap-Kartenkacheln und externe Bibliotheken/OCR.

Zum Bauen Android Studio verwenden, Projektordner öffnen, Gradle synchronisieren und Build > Build APK(s). Ein APK-Build wurde hier **nicht** durchgeführt.

**Sicherheit:** GPX-Fahrwege sind keine geprüfte Busnavigation. Dienstplan-Pausen sind nicht automatisch gesetzlich anrechenbare Pausen.
