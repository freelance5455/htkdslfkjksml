plugins { id("com.android.application") }
android { namespace = "de.busdrivernavi.app"; compileSdk = 35
 defaultConfig { applicationId = "de.busdrivernavi.app"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "1.0" } }
