Matematika Xazinasi — Asalxon
30 ta matematika topshirig‘i.
ZIPni APK builderga yuklang. Bosh sahifa, oldingi/keyingi, 30 ta raqamli navigatsiya va natija oynasi mavjud.
Internet talab qilinmaydi: barcha rasmlar va sahifalar lokal.
