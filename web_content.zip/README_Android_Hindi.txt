RIZWAN MALIK MULTI-BUSINESS PRO — VERSION 3 STARTER
Android मोबाइल पर उपयोग

इस ZIP में 4 अलग HTML स्क्रीन हैं:
1. Rizwan_Malik_Master_Admin.html — मुख्य मालिक/Admin
2. Rizwan_Malik_Customer_App.html — ग्राहक सामान देखकर ऑर्डर कर सकता है
3. Rizwan_Malik_Seller_App.html — कारीगर/Seller प्रोफाइल और सामान सूची
4. Rizwan_Malik_Driver_App.html — ड्राइवर अपने मोबाइल नंबर से असाइन माल देख सकता है

शुरुआती डेमो PIN: 2468
Admin स्क्रीन में PIN बदलने का विकल्प है।

महत्वपूर्ण सीमाएँ:
- यह अभी HTML starter/demo है, Android APK नहीं।
- चारों स्क्रीन एक ही Android फोन और एक ही ब्राउज़र में खोली जाएँ तो local browser storage के माध्यम से डेटा साझा कर सकती हैं। Chrome में अलग-अलग प्रोफाइल/ब्राउज़र या अलग फोन पर यह डेटा साझा नहीं होगा।
- डेटा फोन/ब्राउज़र में रहता है। ब्राउज़र डेटा साफ होने पर रिकॉर्ड मिट सकते हैं। नियमित JSON बैकअप डाउनलोड करें।
- Admin PIN केवल शुरुआती लोकल लॉक है; इसे असली सुरक्षित सर्वर लॉगिन न समझें।
- SMS OTP, अलग-अलग फोन पर live sync, secure role permissions, online UPI/payment gateway, push notifications, cloud backup, production hosting अभी जुड़े नहीं हैं। इनके लिए Firebase/Backend, SMS provider और payment gateway account तथा सेटअप जरूरी है।
- UPI विकल्प अभी केवल डेमो चयन है; पैसे का भुगतान नहीं करता।
- टैक्स/GST, पार्टनर लाभ-विभाजन और पूर्ण ledger अभी प्रमाणित accounting नहीं हैं; इन्हें अलग चरण में जोड़ना होगा।

Android पर:
1. ZIP डाउनलोड करके Files/Downloads में Extract करें।
2. Chrome में पहले Master Admin HTML खोलें।
3. फिर उसी Chrome में Customer, Seller और Driver HTML खोलें।
4. पहले Admin में सामान और स्टॉक जोड़ें। Customer से test order करें। Admin में order देखें।
5. Admin में transport entry करते समय ड्राइवर का मोबाइल नंबर डालें। Driver स्क्रीन में वही नंबर डालें।
6. Backup विकल्प से JSON फाइल नियमित डाउनलोड करें।

पहले टेस्ट के लिए डेमो डेटा डालें; असली ग्राहक/व्यापार का संवेदनशील डेटा तब तक न डालें जब तक cloud security और backup लागू न हों।
