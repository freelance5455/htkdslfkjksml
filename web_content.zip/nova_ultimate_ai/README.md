# NOVA ULTIMATE AI — Studio IA Multimédia

## Description
**NOVA ULTIMATE AI** est une plateforme web d'intelligence artificielle multimédia complète, conçue pour la création d'images HD (Anime & Manhwa), l'assemblage automatique de films à partir de chapitres textuels, la composition de bandes dessinées/webtoons, la création musicale, vidéo et le développement web/applications.

---

## Architecture du Projet
```
nova_ultimate_ai/
├── server.py              # Serveur backend Python Flask
├── templates/
│   └── index.html         # Interface utilisateur futuriste (Tailwind CSS)
├── static/
│   ├── css/
│   │   └── style.css      # Styles personnalisés
│   └── js/
│       └── app.js         # Interactivité front-end et appels API
├── requirements.txt       # Dépendances Python nécessaires
└── README.md              # Documentation & Guide de conversion Android
```

---

## Instructions d'Installation et d'Exécution

### 1. Prérequis
- Python 3.8+ installé.

### 2. Lancement Local
1. Extrayez l'archive ZIP.
2. Accédez au dossier du projet :
   ```bash
   cd nova_ultimate_ai
   ```
3. Installez les dépendances :
   ```bash
   pip install -r requirements.txt
   ```
4. Démarrez le serveur :
   ```bash
   python server.py
   ```
5. Ouvrez votre navigateur sur `http://localhost:5000`.

---

## Guide de Conversion en Application Android (.APK)

Pour transformer **NOVA ULTIMATE AI** en une application native sur votre téléphone Android :

### Option A : Conversion Web App / APK Builder (La plus simple sur Android)
1. Déployez le projet sur un hébergeur gratuit (Render, Vercel ou PythonAnywhere).
2. Obtenez l'URL web de votre projet (ex: `https://nova-ultimate-ai.onrender.com`).
3. Utilisez une application Android comme **Hermit**, **Website 2 APK Builder** ou le site **Web2App**.
4. Entrez l'URL de votre projet et générez l'APK directement sur votre téléphone.

### Option B : Utilisation de WebView dans Android Studio
1. Créez un nouveau projet Android avec une activité simple (`MainActivity`).
2. Ajoutez un composant `WebView` dans votre layout XML.
3. Chargez l'URL locale ou hébergée dans votre `WebView` :
   ```java
   WebView myWebView = (WebView) findViewById(R.id.webview);
   myWebView.getSettings().setJavaScriptEnabled(true);
   myWebView.loadUrl("https://votre-url-nova-ai.com");
   ```
4. Compilez l'application pour obtenir le fichier `.apk`.

---

## Connexion des Services API (Moteurs IA)
Les clés API externes (Google Gemini, OpenAI, Midjourney API Proxy, ElevenLabs) sont administrées dans `server.py` côté serveur pour garantir la sécurité des identifiants sans les exposer dans le navigateur des utilisateurs.
