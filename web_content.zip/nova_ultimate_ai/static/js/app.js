// NOVA ULTIMATE AI Front-end Controller

let currentTab = 'chat';
let isOnline = true;

function switchTab(tabId) {
    currentTab = tabId;
    document.querySelectorAll('.tab-view').forEach(el => el.classList.add('hidden'));
    document.querySelectorAll('.nav-btn').forEach(btn => btn.classList.remove('active', 'text-indigo-400', 'bg-gray-800'));

    const activeBtn = event ? event.currentTarget : null;
    if (activeBtn) activeBtn.classList.add('active', 'text-indigo-400', 'bg-gray-800');

    const titleEl = document.getElementById('tab-title');

    if (['chat', 'image', 'manga', 'auto-movie', 'app-creator'].includes(tabId)) {
        document.getElementById(`view-${tabId}`).classList.remove('hidden');
    } else {
        const viewGen = document.getElementById('view-generic');
        viewGen.classList.remove('hidden');
        
        const titles = {
            'anime': 'Studio de Création d'Animés',
            'video': 'Studio Vidéo',
            'music': 'Studio Musical'
        };
        const icons = {
            'anime': 'fa-clapperboard',
            'video': 'fa-video',
            'music': 'fa-music'
        };

        document.getElementById('generic-title').innerText = titles[tabId] || 'Studio Multimédia';
        document.getElementById('generic-icon').className = `fa-solid ${icons[tabId] || 'fa-sparkles'}`;
    }
}

function toggleNetworkMode(mode) {
    isOnline = mode === 'online';
    alert(`Mode basculé en : ${isOnline ? 'En Ligne (Clés API centralisées)' : 'Hors Ligne (Génération Locale Synthétique)'}`);
}

async function sendChatMessage() {
    const input = document.getElementById('chat-input');
    const msg = input.value.trim();
    if (!msg) return;

    const container = document.getElementById('chat-messages');
    container.innerHTML += `
        <div class="flex gap-3 justify-end">
            <div class="bg-indigo-600 p-3.5 rounded-2xl max-w-xl text-sm leading-relaxed">${msg}</div>
        </div>
    `;
    input.value = '';

    try {
        const res = await fetch('/api/chat', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ message: msg, mode: isOnline ? 'online' : 'offline' })
        });
        const data = await res.json();

        container.innerHTML += `
            <div class="flex gap-3">
                <div class="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center text-xs font-bold">AI</div>
                <div class="bg-gray-800 p-3.5 rounded-2xl max-w-xl border border-gray-700/50 text-sm leading-relaxed">${data.reply}</div>
            </div>
        `;
        container.scrollTop = container.scrollHeight;
    } catch(err) {
        console.error(err);
    }
}

async function generateImage() {
    const prompt = document.getElementById('img-prompt').value;
    const style = document.getElementById('img-style').value;
    const placeholder = document.getElementById('image-result-placeholder');
    const resultImg = document.getElementById('image-result');

    if (!prompt) return alert('Veuillez saisir une description visuelle.');

    placeholder.innerHTML = `<i class="fa-solid fa-spinner animate-spin text-3xl text-indigo-500"></i><p class="text-xs mt-2">Génération HD en cours...</p>`;

    try {
        const res = await fetch('/api/generate-image', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ prompt, style, mode: isOnline ? 'online' : 'offline' })
        });
        const data = await res.json();
        
        placeholder.classList.add('hidden');
        resultImg.src = data.image_url;
        resultImg.classList.remove('hidden');
    } catch(err) {
        alert('Erreur lors de la génération d'image');
    }
}

async function generateManga() {
    const script = document.getElementById('manga-script').value;
    if(!script) return alert('Entrez le scénario de la scène.');

    const res = await fetch('/api/generate-manga', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ script })
    });
    const data = await res.json();

    const preview = document.getElementById('manga-preview');
    const container = document.getElementById('manga-container');
    preview.classList.remove('hidden');
    
    container.innerHTML = data.panels.map(p => `
        <div class="relative bg-gray-900 border border-gray-700 rounded overflow-hidden">
            <img src="${p.image}" class="w-full h-48 object-cover">
            <div class="absolute bottom-2 left-2 bg-white/90 text-black px-3 py-1 rounded-full text-xs font-bold shadow">
                ${p.dialogue}
            </div>
        </div>
    `).join('');
}

async function startAutoMovieGeneration() {
    const chapters = document.getElementById('chapters-input').value;
    if(!chapters) return alert('Veuillez entrer les chapitres du film.');

    const box = document.getElementById('movie-progress-box');
    const stepText = document.getElementById('movie-step-text');
    const bar = document.getElementById('movie-bar');
    const log = document.getElementById('movie-log');
    const percent = document.getElementById('movie-percent');

    box.classList.remove('hidden');
    log.innerHTML = '';

    const steps = [
        { p: 20, t: "Analyse et découpage des chapitres en scènes..." },
        { p: 40, t: "Génération des storyboard et visuels Anime HD..." },
        { p: 70, t: "Synthèse vocale et voix-off des personnages..." },
        { p: 90, t: "Assemblage vidéo & effets spéciaux FX..." },
        { p: 100, t: "Film finalisé avec succès !" }
    ];

    for(let i=0; i<steps.length; i++) {
        await new Promise(r => setTimeout(r, 1200));
        bar.style.width = steps[i].p + '%';
        percent.innerText = steps[i].p + '%';
        stepText.innerText = steps[i].t;
        log.innerHTML += `<div>[${new Date().toLocaleTimeString()}] ${steps[i].t}</div>`;
        log.scrollTop = log.scrollHeight;
    }
}

async function generateWebApp() {
    const prompt = document.getElementById('app-prompt').value;
    if(!prompt) return alert('Décrivez l'application à construire.');

    const res = await fetch('/api/create-app', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ prompt })
    });
    const data = await res.json();

    document.getElementById('app-output-box').classList.remove('hidden');
    document.getElementById('app-code-preview').innerText = data.code;
}

function downloadGeneratedApp() {
    alert("Téléchargement du package source de l'application (ZIP) démarré.");
}

function executeGenericStudio() {
    const input = document.getElementById('generic-input').value;
    const resDiv = document.getElementById('generic-result');
    if(!input) return alert('Veuillez entrer vos directives.');

    resDiv.classList.remove('hidden');
    resDiv.innerText = `[PROCESSED] Commande transmise au moteur multimédia centralisé. Statut : Succès.`;
}
