const KEY='gfx_demo_orders_v1';
function readOrders(){try{return JSON.parse(localStorage.getItem(KEY)||'[]')}catch(e){return []}}
function saveOrders(a){localStorage.setItem(KEY,JSON.stringify(a))}
function money(n){return '৳ '+Number(n||0).toLocaleString('en-US')}
function syncHeader(){let bal=localStorage.getItem('gfx_demo_wallet')||'0';document.querySelectorAll('#wallet,#wallet2').forEach(e=>e.textContent=Number(bal).toLocaleString('en-US'));let orders=readOrders();let c=document.getElementById('orderCount');if(c)c.textContent=orders.length;let co=document.getElementById('coins');if(co)co.textContent=localStorage.getItem('gfx_demo_coins')||'0'}
document.addEventListener('DOMContentLoaded',()=>{
 syncHeader();
 const packages=[...document.querySelectorAll('.package')];let selected=packages.find(p=>p.classList.contains('selected'))||packages[0];
 function choose(p){if(!p)return;selected=p;packages.forEach(x=>x.classList.toggle('selected',x===p));let n=document.getElementById('chosen'),pr=document.getElementById('price');if(n)n.textContent=p.dataset.name;if(pr)pr.textContent=money(p.dataset.price)}
 packages.forEach(p=>p.addEventListener('click',()=>choose(p)));if(selected)choose(selected);
 const btn=document.getElementById('orderBtn');if(btn)btn.addEventListener('click',()=>{let uid=(document.getElementById('uid')?.value||'').trim();if(!/^[0-9]{5,20}$/.test(uid)){alert('সঠিক Player UID লিখুন (৫–২০ ডিজিট)।');return}if(!selected){alert('একটি প্যাকেজ নির্বাচন করুন।');return}let orders=readOrders();let order={id:'GFX'+Date.now().toString().slice(-8),item:selected.dataset.name,price:Number(selected.dataset.price),uid,nickname:(document.getElementById('nickname')?.value||'').trim(),server:document.getElementById('server')?.value||'Bangladesh',status:'Pending',date:new Date().toLocaleString('bn-BD')};orders.unshift(order);saveOrders(orders);alert('ডেমো অর্ডার রিকোয়েস্ট তৈরি হয়েছে! এটি বাস্তব টপআপ বা পেমেন্ট নয়।');location.href='orders.html'});
 const list=document.getElementById('ordersList'),empty=document.getElementById('empty');if(list){let os=readOrders();if(os.length){empty.style.display='none';list.innerHTML=os.map(o=>`<article class="order-card"><div class="order-top"><div><b>${escapeHtml(o.item)}</b><small>Order ID: ${escapeHtml(o.id)}</small></div><span class="status">${escapeHtml(o.status)}</span></div><div class="order-details">Player UID: ${escapeHtml(o.uid)}<br>Server: ${escapeHtml(o.server)}<br>Price: <b>${money(o.price)}</b><br>Date: ${escapeHtml(o.date)}</div></article>`).join('')}}
 const al=document.getElementById('adminOrders'),ae=document.getElementById('adminEmpty');if(al){let os=readOrders();document.getElementById('adminCount').textContent=os.length;document.getElementById('adminRevenue').textContent=money(os.reduce((s,o)=>s+Number(o.price||0),0));if(os.length){ae.style.display='none';al.innerHTML=os.map(o=>`<article class="order-card"><div class="order-top"><div><b>${escapeHtml(o.item)}</b><small>${escapeHtml(o.id)} · UID ${escapeHtml(o.uid)}</small></div><span class="status">${escapeHtml(o.status)}</span></div><div class="order-details">Server: ${escapeHtml(o.server)} · ${money(o.price)}<br>${escapeHtml(o.date)}</div><button class="btn small-btn" onclick="setStatus('${o.id}','Completed')">Mark completed</button> <button class="btn btn-danger small-btn" onclick="setStatus('${o.id}','Cancelled')">Cancel</button></article>`).join('')}}
 const clear=document.getElementById('clearOrders');if(clear)clear.addEventListener('click',()=>{if(confirm('সব ডেমো অর্ডার মুছবেন?')){saveOrders([]);location.reload()}});
});
function escapeHtml(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function setStatus(id,status){let os=readOrders();os=os.map(o=>o.id===id?{...o,status}:o);saveOrders(os);location.reload()}

/* Connected demo helper: admin reads the same browser storage as the User Panel.
   Both panels must be hosted on the same origin (same scheme + domain + port). */
document.addEventListener('DOMContentLoaded', function () {
  const refreshButton = document.getElementById('admin-refresh-orders');
  if (refreshButton) {
    refreshButton.addEventListener('click', function () {
      window.location.reload();
    });
  }
});
