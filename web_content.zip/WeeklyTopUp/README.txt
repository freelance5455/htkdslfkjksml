WEEKLY TOP-UP - ANDROID PROJECT
===============================

This folder builds an Android app (APK) that runs fully on the phone, with no internet.
Pick ONE of the three ways below to get the APK.

A. Android Studio (on a computer)
   1. Unzip this file. In Android Studio choose File > Open and pick the WeeklyTopUp folder.
   2. Wait for the Gradle sync to finish. The first time it downloads a lot, so it needs internet.
   3. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
   4. Click "locate" in the pop-up. The file is app/build/outputs/apk/debug/app-debug.apk
   5. Copy it to your phone and open it. Allow "install unknown apps" when Android asks.

B. Command line (Java 17 and the Android SDK installed)
   ./gradlew assembleDebug        (Windows: gradlew.bat assembleDebug)

C. GitHub, without Android Studio
   1. Make a free repository at github.com.
   2. Upload everything INSIDE the WeeklyTopUp folder, including the hidden .github folder,
      so that gradlew and .github sit at the top of the repository.
   3. Open the Actions tab, choose "Build APK", then "Run workflow".
   4. When it finishes, open the run and download "weekly-topup-apk" under Artifacts.
      Unzip it and install app-debug.apk on your phone.

NOTES
- Needs Android 8.0 or newer.
- The APK is signed with a debug key. That is fine for your own phone but not for Google Play.
- Your accounts and expenses are saved inside the app on the phone. They are separate from
  the Claude page version and do not sync with it.
- The app uses the phone's own fonts.
- The app code is in app/src/main/assets/index.html. The Android part is only a small wrapper
  in app/src/main/java/com/weeklytopup/app/MainActivity.java.
