BLOCK BLAST PUZZLE — projeto HTML5 + Android WebView

CONTEÚDO
- jogo/index.html: jogo HTML5 completo e jogável no navegador
- app/: projeto Android Studio que abre o jogo em tela cheia
- Recursos: tabuleiro 8x8, 3 peças, limpar linhas/colunas, pontuação, recorde local, reiniciar, ajuda e tela de fim de jogo.

COMO JOGAR NO CELULAR
Abra app/src/main/assets/index.html no navegador ou hospede a pasta do jogo em um site estático.

COMO GERAR APK
1. Instale Android Studio recente com Android SDK 35.
2. Abra a pasta BlockBlast_Projeto no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Use Build > Build Bundle(s) / APK(s) > Build APK(s).
5. O APK será criado em app/build/outputs/apk/debug/app-debug.apk.

IMPORTANTE
Este pacote contém o projeto-fonte e o jogo HTML5, não um APK já compilado. O ambiente de criação não tem Android SDK/Gradle configurados para compilar o APK aqui. É uma recriação inspirada no estilo de puzzle de blocos, com nome e arte próprios; não inclui os recursos proprietários originais do Block Blast.
