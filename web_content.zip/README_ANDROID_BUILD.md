# Guia de Compilação APK — Angola Connect 🇦🇴

Este projeto foi configurado com a estrutura completa para Android (compatível com Android Studio e Apache Cordova / Capacitor).

## Requisitos
- Node.js 18+ e npm
- Android Studio (versão Hedgehog ou superior) ou Android SDK com JDK 17+

## Passos para gerar o APK:
1. Extraia o ficheiro ZIP.
2. No terminal, instale as dependências:
   ```bash
   npm install
   ```
3. Compile o build de produção web:
   ```bash
   npm run build
   ```
4. Sincronize com o Capacitor:
   ```bash
   npx cap sync android
   ```
5. Abra no Android Studio:
   ```bash
   npx cap open android
   ```
6. No Android Studio, clique em:
   **Build > Build Bundle(s) / APK(s) > Build APK(s)**
   O ficheiro `app-debug.apk` ou `app-release.apk` será gerado em `android/app/build/outputs/apk/`.

## Informações do Pacote
- **Nome da Aplicação**: Angola Connect
- **Package Name**: ao.connect.angolaconnect
- **Slogan**: Conectando Angola ao mundo
- **Permissões**: Câmera, Microfone, Internet, Armazenamento, Notificações, WebRTC.
