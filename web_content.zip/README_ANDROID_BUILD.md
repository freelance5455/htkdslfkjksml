# KingSaroj Routine Android APK Build
1. Open in Android Studio
2. Click Build APK
3. Install APK on phone!