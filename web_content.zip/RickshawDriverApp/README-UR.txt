رکشہ ڈرائیور لسٹ — Android Studio پروجیکٹ

اہم:
یہ Android APK نہیں بلکہ APK بنانے کے لیے مکمل Android Studio پروجیکٹ ہے۔
اس چیٹ کے ماحول میں Android SDK/Gradle موجود نہیں، اس لیے یہاں سے APK compile نہیں کیا جا سکا۔

APK بنانے کا طریقہ:
1) کمپیوٹر پر Android Studio انسٹال کریں۔
2) اس ZIP فائل کو Extract کریں۔
3) Android Studio میں "Open" منتخب کرکے RickshawDriverApp فولڈر کھولیں۔
4) Gradle Sync مکمل ہونے دیں۔ اگر SDK 35 مانگے تو Android SDK Platform 35 انسٹال کریں۔
5) Build > Build Bundle(s) / APK(s) > Build APK(s) پر کلک کریں۔
6) APK عموماً app/build/outputs/apk/debug/app-debug.apk میں بنے گی۔
7) APK موبائل میں منتقل کرکے انسٹال کریں۔ ضرورت پڑنے پر Android کی Settings میں اس فائل/ایپ کے لیے Install unknown apps اجازت دیں۔

ایپ کی خصوصیات:
- آف لائن سرچ: رکشہ نمبر، نام، موبائل، CNIC، والد کا نام اور پتہ
- نیا ریکارڈ شامل، ترمیم اور حذف
- JSON بیک اپ ڈاؤن لوڈ اور بحال
- ابتدائی طور پر بھیجی گئی تصویر کے 15 ریکارڈ شامل

ڈیٹا اور پرائیویسی:
- ڈیٹا اسی ایپ کے اندر اسی موبائل پر محفوظ ہوتا ہے۔
- ایپ کو uninstall کرنے یا app data صاف کرنے سے ریکارڈ ضائع ہو سکتے ہیں۔
- باقاعدگی سے بیک اپ بنائیں۔
- CNIC حساس ذاتی معلومات ہے؛ موبائل لاک رکھیں اور بیک اپ محفوظ رکھیں۔
