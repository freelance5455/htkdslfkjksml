TMT Transport s.r.o. – Android WebView projekt

Obsahuje offline HTML aplikaci zabalenou jako jednoduchý Android projekt.
Toto je ZDROJOVÝ PROJEKT, ne hotové APK. APK je nutné sestavit v Android Studio nebo kompatibilním Android build prostředí.

Jak sestavit APK:
1. Rozbalte složku TMT_Transport_Android_Wrapper.
2. Otevřete ji v Android Studio jako existující projekt.
3. Nechte Gradle dokončit synchronizaci (vyžaduje Android SDK; při prvním sestavení může být potřeba internet).
4. Zvolte Build > Build APK(s).
5. APK najdete v app/build/outputs/apk/debug/app-debug.apk.
6. Před ostrým použitím otestujte zadání, editaci, mazání, export a obnovu zálohy.

Důležité:
- Data v Android WebView jsou uložena odděleně od dat v Chrome a od HTML souboru otevřeného v prohlížeči.
- Před přechodem exportujte JSON zálohu ze staré verze a po instalaci nové aplikace ji obnovte.
- Odinstalace aplikace může odstranit její lokální data. Pravidelně exportujte JSON mimo telefon.
- Projekt nebyl v tomto prostředí zkompilován do APK ani otestován na zařízení.
