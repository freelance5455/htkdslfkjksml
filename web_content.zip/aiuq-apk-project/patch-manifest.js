// يضيف صلاحيات الكاميرا لملف AndroidManifest.xml (آمن للتشغيل أكثر من مرة)
const fs=require('fs'),f='android/app/src/main/AndroidManifest.xml';
if(!fs.existsSync(f)){console.error('شغّل npx cap add android أولاً');process.exit(1)}
let x=fs.readFileSync(f,'utf8');
const add=[['<uses-permission android:name="android.permission.CAMERA" />','android.permission.CAMERA'],['<uses-feature android:name="android.hardware.camera" android:required="false" />','android.hardware.camera']];
add.forEach(([tag,key])=>{if(!x.includes(key))x=x.replace('<application',tag+'\n    <application')});
fs.writeFileSync(f,x);console.log('تم تحديث صلاحيات AndroidManifest.xml');
