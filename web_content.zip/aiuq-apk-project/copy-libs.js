// ينسخ مكتبات three.js و pdf.js إلى www/lib ليعمل التطبيق بدون انترنت
const fs=require('fs'),path=require('path');
const out=path.join(__dirname,'www','lib');fs.mkdirSync(out,{recursive:true});
[['three/build/three.min.js','three.min.js'],['pdfjs-dist/build/pdf.min.js','pdf.min.js'],['pdfjs-dist/build/pdf.worker.min.js','pdf.worker.min.js']].forEach(([f,t])=>{
  const src=path.join(__dirname,'node_modules',f);
  if(!fs.existsSync(src)){console.error('مفقود: '+f+' (شغّل npm install أولاً)');process.exit(1)}
  fs.copyFileSync(src,path.join(out,t));console.log('تم نسخ '+t);
});
