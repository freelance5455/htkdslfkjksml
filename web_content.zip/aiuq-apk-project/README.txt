بناء APK لتطبيق جامعة العين العراقية
المتطلبات: Node.js + Android Studio + انترنت (الشعار يحتاج مكتبة three.js من الانترنت)
1) npm install
2) npx cap add android
3) npx cap sync
4) npx cap open android
5) من Android Studio: Build > Build Bundle(s)/APK(s) > Build APK(s)
