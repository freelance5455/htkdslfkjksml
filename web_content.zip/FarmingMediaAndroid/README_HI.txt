FARMING MEDIA - UPDATED ANDROID PROJECT

नया अपडेट:
- Android WebView में फोन से वीडियो/फोटो चुनने के लिए native file picker जोड़ा।
- इंटरनेट और नेटवर्क permissions जोड़ीं।
- वीडियो स्क्रीन पर चुनी गई फाइल का नाम और आकार दिखता है।
- Android के document picker के कारण सामान्य फाइल चुनने के लिए broad storage permission की जरूरत नहीं।

महत्वपूर्ण सीमाएँ:
- फाइल चुनना और ऑनलाइन अपलोड करना अलग चीजें हैं।
- इस ZIP में अभी वीडियो को सर्वर पर भेजने वाला backend/API नहीं है।
- सभी यूज़र्स को वीडियो दिखाने के लिए server/storage, login, admin approval और upload API सेटअप करना होगा।
- कैमरा/माइक्रोफोन permission जानबूझकर स्वतः नहीं मांगी गई; केवल gallery/document picker से मीडिया चुनने पर इनकी जरूरत नहीं।
- Android permission उपयोगकर्ता के फोन पर ऐप चलने के बाद मांगी/मंजूर होती है; ZIP से permission पहले से ON नहीं की जा सकती।

यह APK नहीं, Android Studio project ZIP है। APK बनाने के लिए Android Studio, Android SDK और Java 17 चाहिए।
App: Farming Media
Tagline: किसानों और पशुपालकों का अपना डिजिटल प्लेटफॉर्म
