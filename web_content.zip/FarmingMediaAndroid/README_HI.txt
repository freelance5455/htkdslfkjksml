Farming Media Android starter project
====================================

यह Android Studio project है। इसमें आपके दिए हुए Farming Media लोगो के साथ हिंदी में शुरुआती ऐप UI है।

शामिल स्क्रीन:
- Home
- Videos & Reels (अभी placeholder)
- Products Store और demo order button
- पशुपालन जानकारी
- गाय-भैंस की देखभाल
- दूध बढ़ाने के सुरक्षित सामान्य सुझाव
- किसान Community (local demo post)
- Admin Panel (placeholder)

APK बनाने के लिए:
1. Android Studio इंस्टॉल करें।
2. इस ZIP को extract करें।
3. Android Studio में Open चुनकर FarmingMedia फ़ोल्डर खोलें।
4. Gradle sync पूरा होने दें (Android SDK 35 और JDK 17 आवश्यक हो सकते हैं)।
5. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।

महत्वपूर्ण:
यह अभी शुरुआती UI/demo है, production-ready ऐप नहीं।
असली वीडियो अपलोड/स्ट्रीमिंग, ऑनलाइन लॉगिन, Admin permissions, database,
किसानों की live chat, product inventory, order management और payment gateway
के लिए backend/server, hosting और payment provider account/configuration चाहिए।
अभी ऑर्डर, login और video upload demo placeholders हैं; कोई वास्तविक भुगतान नहीं होता।
