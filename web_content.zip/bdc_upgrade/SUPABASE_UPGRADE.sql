-- Run this AFTER your existing donors and blood_requests tables exist.
-- Keep your frontend anon/publishable key only; never put a service_role/secret key in HTML/JS.

ALTER TABLE public.blood_requests ADD COLUMN IF NOT EXISTS details text;
ALTER TABLE public.donors ADD COLUMN IF NOT EXISTS latitude double precision;
ALTER TABLE public.donors ADD COLUMN IF NOT EXISTS longitude double precision;
ALTER TABLE public.blood_requests ADD COLUMN IF NOT EXISTS latitude double precision;
ALTER TABLE public.blood_requests ADD COLUMN IF NOT EXISTS longitude double precision;

ALTER TABLE public.donors ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.blood_requests ENABLE ROW LEVEL SECURITY;

-- Existing registration/search workflow for the college demo.
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='donors' AND policyname='Allow donor registration') THEN
    CREATE POLICY "Allow donor registration" ON public.donors FOR INSERT TO anon WITH CHECK (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='donors' AND policyname='Allow donor search') THEN
    CREATE POLICY "Allow donor search" ON public.donors FOR SELECT TO anon USING (available = true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='blood_requests' AND policyname='Allow request creation') THEN
    CREATE POLICY "Allow request creation" ON public.blood_requests FOR INSERT TO anon WITH CHECK (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='blood_requests' AND policyname='Allow request viewing') THEN
    CREATE POLICY "Allow request viewing" ON public.blood_requests FOR SELECT TO anon USING (true);
  END IF;
END $$;

-- IMPORTANT: The public SELECT policies above are suitable only for a classroom prototype.
-- A real public deployment should use Supabase Auth, consent, verification, role-based access,
-- and restricted views/RLS so personal phone/contact information is not exposed anonymously.
