async function loadHome(){
 const reqBox=document.getElementById('homeRequests');
 const [{data:donors,error:dErr},{data:reqs,error:rErr}]=await Promise.all([
  supabaseClient.from('donors').select('id',{count:'exact',head:false}).eq('available',true),
  supabaseClient.from('blood_requests').select('id,patient_name,blood_group,hospital,location,units,urgency,status,created_at').neq('status','Fulfilled').order('created_at',{ascending:false}).limit(3)
 ]);
 if(!dErr)document.getElementById('donorCount').textContent=donors.length;
 if(!rErr){document.getElementById('requestCount').textContent=reqs.length; reqBox.innerHTML=reqs.length?reqs.map(requestCard).join(''):'<div class="empty">No active blood requests yet.</div>';} else reqBox.innerHTML='<div class="empty">Could not load active requests. Check your Supabase SELECT policy.</div>';
}
function requestCard(r){return `<article class="request-card"><div class="request-top"><span class="blood-big">${escapeHtml(r.blood_group)}</span><span class="urgency ${String(r.urgency).toLowerCase()}">${escapeHtml(r.urgency||'Emergency')}</span></div><h3>${escapeHtml(r.blood_group)} Required <small>• ${r.units} Unit${r.units==1?'':'s'}</small></h3><p>📍 ${escapeHtml(r.hospital)} · ${escapeHtml(r.location)}</p><p class="muted">${fmtDate(r.created_at)}</p><div class="card-actions"><a href="requests.html">RESPOND NOW</a><a class="secondary" href="requests.html">DETAILS</a></div></article>`}
loadHome();
