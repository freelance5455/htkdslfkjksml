const params=new URLSearchParams(location.search);if(params.get('group'))document.getElementById('searchBloodGroup').value=params.get('group');if(params.get('q'))document.getElementById('searchLocation').value=params.get('q');
async function searchDonors(){
 const group=document.getElementById('searchBloodGroup').value, locationValue=document.getElementById('searchLocation').value.trim(), results=document.getElementById('donorResults');results.innerHTML='<div class="loading">Searching...</div>';
 let query=supabaseClient.from('donors').select('id,name,age,blood_group,phone,location,available').eq('available',true).order('created_at',{ascending:false});
 if(group)query=query.eq('blood_group',group);if(locationValue)query=query.ilike('location',`%${locationValue}%`);
 const {data,error}=await query;if(error){console.error(error);results.innerHTML='<div class="empty">Unable to search. Your Supabase table needs a SELECT policy for anonymous users.</div>';return;}
 if(!data.length){results.innerHTML='<div class="empty">No available donors matched your search.</div>';return;}
 results.innerHTML=data.map(d=>`<article class="donor-card"><div class="blood">${escapeHtml(d.blood_group)}</div><div class="donor-main"><h3>${escapeHtml(d.name)}</h3><p>📍 ${escapeHtml(d.location)} · Age ${d.age}</p><p class="available">● Available</p></div><a class="contact-btn" href="tel:${encodeURIComponent(d.phone)}">📞 Contact</a></article>`).join('');}
