function goSearch(){const q=document.getElementById('homeSearch')?.value.trim();location.href='find-donor.html'+(q?'?q='+encodeURIComponent(q):'');}
function goGroup(g){location.href='find-donor.html?group='+encodeURIComponent(g);}
function escapeHtml(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));}
function fmtDate(v){if(!v)return '—';return new Date(v).toLocaleString([], {dateStyle:'medium',timeStyle:'short'});}
