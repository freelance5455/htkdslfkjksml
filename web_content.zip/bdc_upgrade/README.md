# BloodConnect — upgraded college prototype

This version keeps the original Supabase donor/request workflow and adds Home, Requests, Alerts, Profile/Roles and a Leaflet Radar Map.

## Setup
1. Open `js/supabase.js`.
2. Put your Supabase project URL and frontend-safe anon/publishable key there.
3. Never use a `service_role`/secret key in browser code.
4. Run `SUPABASE_UPGRADE.sql` in Supabase SQL Editor.
5. Serve the folder with VS Code Live Server.

## Real vs production
The prototype uses real Supabase records for donor registrations and blood requests. The map uses real Leaflet/OpenStreetMap tiles and can plot records when latitude/longitude are stored. It is not a medical dispatch or verified blood-bank service. A real public deployment needs authentication, donor consent, hospital verification, secure contact exchange, audit logs and stronger RLS.
