JPF Feed Cost Android App

This is a ready-to-open Android Studio project.
App name: JPF Feed Cost
App icon: Jagdamba Udyog Samuha logo supplied by the user.

To build APK:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. Install the generated APK on the Android phone.

The app loads the tested JPF Feed Cost V3 interface from app/src/main/assets/index.html.
