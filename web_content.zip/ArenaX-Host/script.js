import { auth, db } from "./firebase-config.js";

import {
    onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/13.0.0/firebase-auth.js";

import {
    collection,
    query,
    where,
    getDocs
} from "https://www.gstatic.com/firebasejs/13.0.0/firebase-firestore.js";

"use strict";

const totalTournamentsEl =
    document.getElementById("totalTournaments");

const activeTournamentsEl =
    document.getElementById("activeTournaments");

const totalRegistrationsEl =
    document.getElementById("totalRegistrations");

const totalPrizeEl =
    document.getElementById("totalPrize");

const recentTournamentsEl =
    document.getElementById("recentTournaments");

const toastEl =
    document.getElementById("toast");

let tournaments = [];
let toastTimer;
let currentHostId = null;
let dashboardLoaded = false;


async function loadTournaments() {
    const user = auth.currentUser;

    if (!user) {
        throw new Error("Host login required.");
    }

    const tournamentsRef = collection(db, "tournaments");

    const q = query(
        tournamentsRef,
        where("hostId", "==", user.uid)
    );

    const snapshot = await getDocs(q);

    tournaments = snapshot.docs.map(function (item) {
        const data = item.data();

        return {
            ...data,
            id: item.id,
            createdAt: data.createdAt?.toMillis
                ? data.createdAt.toMillis()
                : Number(data.createdAt || 0)
        };
    });

    return tournaments;
}


function formatCurrency(amount) {
    return "₹" + Number(amount || 0).toLocaleString("en-IN");
}


function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, function (char) {
        const entities = {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#39;"
        };

        return entities[char];
    });
}


function showToast(message) {
    clearTimeout(toastTimer);

    toastEl.textContent = message;
    toastEl.classList.add("show");

    toastTimer = setTimeout(function () {
        toastEl.classList.remove("show");
    }, 2600);
}


async function renderDashboard() {
    try {
        await loadTournaments();

        const total = tournaments.length;

        const active = tournaments.filter(function (item) {
            return item.status === "published" ||
                   item.status === "Published";
        }).length;

        const registrations = tournaments.reduce(function (sum, item) {
            return sum + Number(item.registrations || 0);
        }, 0);

        const prizeTotal = tournaments.reduce(function (sum, item) {
            return sum + Number(item.prizePool || 0);
        }, 0);

        totalTournamentsEl.textContent =
            String(total).padStart(2, "0");

        activeTournamentsEl.textContent =
            String(active).padStart(2, "0");

        totalRegistrationsEl.textContent =
            registrations.toLocaleString("en-IN");

        totalPrizeEl.textContent =
            formatCurrency(prizeTotal);

        renderRecentTournaments();

    } catch (error) {
        console.error("Dashboard Firebase error:", error);
        showToast("Could not load tournaments from Firebase.");
    }
}


function renderRecentTournaments() {
    if (tournaments.length === 0) {
        recentTournamentsEl.innerHTML = `
            <div class="empty-state glass-card">
                <div class="empty-icon">🏆</div>

                <h3>No tournaments yet</h3>

                <p>
                    Your created tournaments will appear here.
                </p>

                <button class="secondary-btn"
                        id="emptyCreateBtn">
                    Create Your First Tournament
                </button>
            </div>
        `;

        const emptyCreateBtn =
            document.getElementById("emptyCreateBtn");

        emptyCreateBtn.addEventListener("click", openCreateScreen);

        return;
    }

    const latest = [...tournaments]
        .sort(function (a, b) {
            return Number(b.createdAt) - Number(a.createdAt);
        })
        .slice(0, 5);

    recentTournamentsEl.innerHTML = latest.map(function (item) {
        return `
            <article class="recent-item glass-card">

                <div class="recent-item-top">
                    <div>
                        <p class="recent-game">
                            ${escapeHTML(item.game)}
                        </p>

                        <h3>${escapeHTML(item.name)}</h3>

                        <p class="recent-mode">
                            ${escapeHTML(item.mode)}
                            · ${escapeHTML(item.format || "Tournament")}
                        </p>
                    </div>

                    <span class="recent-status">
                        ${escapeHTML(item.status)}
                    </span>
                </div>

                <div class="recent-stats">
                    <span>🏆 ${formatCurrency(item.prizePool)}</span>
                    <span>🎟️ ${Number(item.slots || 0)} slots</span>
                    <span>👥 ${Number(item.registrations || 0)} players</span>
                </div>

               

            </article>
        `;
    }).join("");


}




function openCreateScreen() {
    window.location.href = "create.html";
}


function openPage(page) {
    switch (page) {
        case "home":
            window.scrollTo({
                top: 0,
                behavior: "smooth"
            });
            break;

        case "create":
            openCreateScreen();
            break;

        case "tournaments":
    window.location.href = "tournaments.html";
    break;

        case "registrations":
    window.location.href = "registrations.html";
    break;

        case "profile":
  window.location.href = "host-profile.html";
  break;

        case "tournament-details":
    window.location.href = "tournament-details.html";
    break;

      
        default:
            showToast("This section is coming soon.");
    }
}


document
    .getElementById("createTournamentBtn")
    .addEventListener("click", openCreateScreen);


document
    .getElementById("emptyCreateBtn")
    ?.addEventListener("click", openCreateScreen);


document
    .getElementById("viewAllBtn")
    .addEventListener("click", function () {
        openPage("tournaments");
    });


document
    .getElementById("notificationBtn")
    .addEventListener("click", function () {
        showToast("You have no new notifications.");
    });


document
    .querySelectorAll("[data-action]")
    .forEach(function (button) {
        button.addEventListener("click", function () {
            openPage(button.dataset.action);
        });
    });


document
    .querySelectorAll(".nav-item")
    .forEach(function (button) {
        button.addEventListener("click", function () {
            const page = button.dataset.page;

            document
                .querySelectorAll(".nav-item")
                .forEach(function (item) {
                    item.classList.toggle(
                        "active",
                        item.dataset.page === page
                    );
                });

            openPage(page);
        });
    });


onAuthStateChanged(auth, (user) => {
    if (!user) {
        showToast("Please login first.");
        return;
    }

    currentHostId = user.uid;
    renderDashboard();
});