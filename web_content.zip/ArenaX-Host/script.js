"use strict";

/*
  ArenaX Host Dashboard
  Frontend prototype only.
  Tournament records are stored locally in this browser.
  This is NOT a shared backend or secure server.
*/

const STORAGE_KEY = "arenax_host_tournaments_demo_v1";

const totalTournamentsEl =
    document.getElementById("totalTournaments");

const activeTournamentsEl =
    document.getElementById("activeTournaments");

const totalRegistrationsEl =
    document.getElementById("totalRegistrations");

const totalPrizeEl =
    document.getElementById("totalPrize");

const recentTournamentsEl =
    document.getElementById("recentTournaments");

const toastEl =
    document.getElementById("toast");


let tournaments = loadTournaments();
let toastTimer;


function loadTournaments() {
    try {
        const saved = localStorage.getItem(STORAGE_KEY);

        if (!saved) {
            return [];
        }

        const parsed = JSON.parse(saved);

        return Array.isArray(parsed) ? parsed : [];

    } catch (error) {
        console.error("Could not load tournaments:", error);
        return [];
    }
}


function saveTournaments() {
    try {
        localStorage.setItem(
            STORAGE_KEY,
            JSON.stringify(tournaments)
        );

        return true;

    } catch (error) {
        console.error("Could not save tournaments:", error);

        showToast(
            "Storage unavailable. Please check browser settings."
        );

        return false;
    }
}


function formatCurrency(amount) {
    return "₹" + Number(amount || 0).toLocaleString("en-IN");
}


function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, function (char) {
        const entities = {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#39;"
        };

        return entities[char];
    });
}


function showToast(message) {
    clearTimeout(toastTimer);

    toastEl.textContent = message;
    toastEl.classList.add("show");

    toastTimer = setTimeout(function () {
        toastEl.classList.remove("show");
    }, 2600);
}


function renderDashboard() {
    const total = tournaments.length;

    const active = tournaments.filter(function (item) {
        return item.status === "Published";
    }).length;

    const registrations = tournaments.reduce(function (sum, item) {
        return sum + Number(item.registrations || 0);
    }, 0);

    const prizeTotal = tournaments.reduce(function (sum, item) {
        return sum + Number(item.prizePool || 0);
    }, 0);

    totalTournamentsEl.textContent =
        String(total).padStart(2, "0");

    activeTournamentsEl.textContent =
        String(active).padStart(2, "0");

    totalRegistrationsEl.textContent =
        registrations.toLocaleString("en-IN");

    totalPrizeEl.textContent =
        formatCurrency(prizeTotal);

    renderRecentTournaments();
}


function renderRecentTournaments() {
    if (tournaments.length === 0) {
        recentTournamentsEl.innerHTML = `
            <div class="empty-state glass-card">
                <div class="empty-icon">🏆</div>

                <h3>No tournaments yet</h3>

                <p>
                    Your created tournaments will appear here.
                </p>

                <button class="secondary-btn"
                        id="emptyCreateBtn">
                    Create Your First Tournament
                </button>
            </div>
        `;

        const emptyCreateBtn =
            document.getElementById("emptyCreateBtn");

        emptyCreateBtn.addEventListener("click", openCreateScreen);

        return;
    }

    const latest = [...tournaments]
        .sort(function (a, b) {
            return Number(b.createdAt) - Number(a.createdAt);
        })
        .slice(0, 5);

    recentTournamentsEl.innerHTML = latest.map(function (item) {
        return `
            <article class="recent-item glass-card">

                <div class="recent-item-top">
                    <div>
                        <p class="recent-game">
                            ${escapeHTML(item.game)}
                        </p>

                        <h3>${escapeHTML(item.name)}</h3>

                        <p class="recent-mode">
                            ${escapeHTML(item.mode)}
                            · ${escapeHTML(item.format || "Tournament")}
                        </p>
                    </div>

                    <span class="recent-status">
                        ${escapeHTML(item.status)}
                    </span>
                </div>

                <div class="recent-stats">
                    <span>🏆 ${formatCurrency(item.prizePool)}</span>
                    <span>🎟️ ${Number(item.slots || 0)} slots</span>
                    <span>👥 ${Number(item.registrations || 0)} players</span>
                </div>

                <button
                    class="recent-delete"
                    data-delete-id="${escapeHTML(item.id)}">
                    Remove demo record
                </button>

            </article>
        `;
    }).join("");

    recentTournamentsEl
        .querySelectorAll("[data-delete-id]")
        .forEach(function (button) {
            button.addEventListener("click", function () {
                deleteTournament(button.dataset.deleteId);
            });
        });
}


function deleteTournament(id) {
    const confirmed = window.confirm(
        "Remove this tournament from this device's demo data?"
    );

    if (!confirmed) {
        return;
    }

    tournaments = tournaments.filter(function (item) {
        return item.id !== id;
    });

    if (saveTournaments()) {
        renderDashboard();
        showToast("Demo tournament removed.");
    }
}


function openCreateScreen() {
    window.location.href = "create.html";
}


function openPage(page) {
    switch (page) {
        case "home":
            window.scrollTo({
                top: 0,
                behavior: "smooth"
            });
            break;

        case "create":
            openCreateScreen();
            break;

        case "tournaments":
    window.location.href = "tournaments.html";
    break;

        case "registrations":
    window.location.href = "registrations.html";
    break;

        case "profile":
  window.location.href = "host-profile.html";
  break;

        case "tournament-details":
    window.location.href = "tournament-details.html";
    break;

      
        default:
            showToast("This section is coming soon.");
    }
}


document
    .getElementById("createTournamentBtn")
    .addEventListener("click", openCreateScreen);


document
    .getElementById("emptyCreateBtn")
    ?.addEventListener("click", openCreateScreen);


document
    .getElementById("viewAllBtn")
    .addEventListener("click", function () {
        openPage("tournaments");
    });


document
    .getElementById("notificationBtn")
    .addEventListener("click", function () {
        showToast("You have no new notifications.");
    });


document
    .querySelectorAll("[data-action]")
    .forEach(function (button) {
        button.addEventListener("click", function () {
            openPage(button.dataset.action);
        });
    });


document
    .querySelectorAll(".nav-item")
    .forEach(function (button) {
        button.addEventListener("click", function () {
            const page = button.dataset.page;

            document
                .querySelectorAll(".nav-item")
                .forEach(function (item) {
                    item.classList.toggle(
                        "active",
                        item.dataset.page === page
                    );
                });

            openPage(page);
        });
    });


renderDashboard();