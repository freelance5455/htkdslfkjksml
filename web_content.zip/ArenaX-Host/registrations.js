"use strict";

/*
 * ArenaX Host — Player Registrations
 *
 * Current version:
 * - Reads demo registration records from localStorage.
 * - Supports search, filters and tournament filtering.
 * - Approve/reject changes are local demo actions only.
 *
 * Real player registrations must come from a shared backend.
 */

const REGISTRATIONS_KEY = "arenax_host_registrations_demo_v1";
const TOURNAMENTS_KEY = "arenax_host_tournaments_demo_v1";

const playerList = document.getElementById("playerList");
const playerSearch = document.getElementById("playerSearch");
const tournamentFilter = document.getElementById("tournamentFilter");

const playerModal = document.getElementById("playerModal");
const playerDetails = document.getElementById("playerDetails");

let registrations = loadRegistrations();
let tournaments = loadTournaments();
let activeFilter = "All";
let toastTimer;


/* STORAGE */

function readArray(key) {
    try {
        const value = JSON.parse(localStorage.getItem(key) || "[]");
        return Array.isArray(value) ? value : [];
    } catch (error) {
        console.error("Could not read storage:", key, error);
        return [];
    }
}


function loadRegistrations() {
    return readArray(REGISTRATIONS_KEY);
}


function loadTournaments() {
    return readArray(TOURNAMENTS_KEY);
}


function saveRegistrations() {
    try {
        localStorage.setItem(
            REGISTRATIONS_KEY,
            JSON.stringify(registrations)
        );
        return true;
    } catch (error) {
        console.error(error);
        showToast("Could not save changes on this device.");
        return false;
    }
}


/* HELPERS */

function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, function (char) {
        return {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#39;"
        }[char];
    });
}


function showToast(message) {
    const toast = document.getElementById("toast");

    clearTimeout(toastTimer);

    toast.textContent = message;
    toast.classList.add("show");

    toastTimer = setTimeout(function () {
        toast.classList.remove("show");
    }, 2600);
}


function getStatus(registration) {
    const status = String(registration.status || "Pending");

    if (["Pending", "Approved", "Rejected"].includes(status)) {
        return status;
    }

    return "Pending";
}


function getTournamentName(registration) {
    const tournament = tournaments.find(function (item) {
        return item.id === registration.tournamentId;
    });

    return registration.tournamentName ||
        (tournament ? tournament.name : "Tournament unavailable");
}


function getTournamentGame(registration) {
    const tournament = tournaments.find(function (item) {
        return item.id === registration.tournamentId;
    });

    return registration.game ||
        (tournament ? tournament.game : "Game unavailable");
}


function getTournamentMode(registration) {
    const tournament = tournaments.find(function (item) {
        return item.id === registration.tournamentId;
    });

    return registration.mode ||
        (tournament ? tournament.mode : "Mode unavailable");
}


function formatDate(value) {
    if (!value) return "Not available";

    const parts = String(value).split("-").map(Number);

    if (parts.length !== 3 || parts.some(Number.isNaN)) {
        return "Not available";
    }

    return new Intl.DateTimeFormat("en-IN", {
        day: "numeric",
        month: "short",
        year: "numeric"
    }).format(new Date(parts[0], parts[1] - 1, parts[2]));
}


/* TOURNAMENT FILTER */

function renderTournamentFilter() {
    const currentValue = tournamentFilter.value || "all";

    const uniqueTournaments = [];

    tournaments.forEach(function (item) {
        if (!uniqueTournaments.some(function (existing) {
            return existing.id === item.id;
        })) {
            uniqueTournaments.push(item);
        }
    });

    tournamentFilter.innerHTML =
        '<option value="all">All tournaments</option>';

    uniqueTournaments.forEach(function (item) {
        const option = document.createElement("option");

        option.value = item.id;
        option.textContent = item.name || "Untitled tournament";

        tournamentFilter.appendChild(option);
    });

    const optionExists = Array.from(tournamentFilter.options).some(
        function (option) {
            return option.value === currentValue;
        }
    );

    tournamentFilter.value = optionExists ? currentValue : "all";
}


/* COUNTS */

function renderCounts() {
    const pending = registrations.filter(function (item) {
        return getStatus(item) === "Pending";
    }).length;

    const approved = registrations.filter(function (item) {
        return getStatus(item) === "Approved";
    }).length;

    const rejected = registrations.filter(function (item) {
        return getStatus(item) === "Rejected";
    }).length;

    document.getElementById("totalPlayers").textContent =
        String(registrations.length).padStart(2, "0");

    document.getElementById("pendingPlayers").textContent =
        String(pending).padStart(2, "0");

    document.getElementById("approvedPlayers").textContent =
        String(approved).padStart(2, "0");

    document.getElementById("rejectedPlayers").textContent =
        String(rejected).padStart(2, "0");

    document.getElementById("allCount").textContent =
        registrations.length;

    document.getElementById("pendingCount").textContent =
        pending;
}


/* FILTER */

function getFilteredRegistrations() {
    const query = playerSearch.value.trim().toLowerCase();
    const selectedTournament = tournamentFilter.value;

    return registrations.filter(function (item) {
        const status = getStatus(item);

        const matchesStatus =
            activeFilter === "All" || status === activeFilter;

        const matchesTournament =
            selectedTournament === "all" ||
            item.tournamentId === selectedTournament;

        const searchable = [
            item.nickname,
            item.playerName,
            item.playerId,
            item.gameId,
            item.id,
            getTournamentName(item),
            getTournamentGame(item),
            getTournamentMode(item)
        ].join(" ").toLowerCase();

        const matchesSearch =
            !query || searchable.includes(query);

        return matchesStatus &&
            matchesTournament &&
            matchesSearch;
    });
}


/* RENDER */

function renderPlayers() {
    renderCounts();

    const visible = getFilteredRegistrations();

    document.getElementById("resultCount").textContent =
        visible.length + (visible.length === 1 ? " RECORD" : " RECORDS");

    if (visible.length === 0) {
        playerList.innerHTML = `
            <div class="empty-state glass-card">
                <div class="empty-icon">♙</div>
                <h3>No registrations found</h3>
                <p>
                    ${
                        registrations.length
                            ? "Try another status, tournament or search term."
                            : "Registrations will appear when player data is added."
                    }
                </p>
            </div>
        `;
        return;
    }

    playerList.innerHTML = visible.map(function (item) {
        const status = getStatus(item);
        const statusClass = status.toLowerCase();

        const nickname = item.nickname ||
            item.playerName ||
            "Unknown Player";

        const playerId = item.playerId ||
            item.gameId ||
            item.id ||
            "Not provided";

        const tournamentName = getTournamentName(item);
        const game = getTournamentGame(item);
        const mode = getTournamentMode(item);

        const isPending = status === "Pending";

        return `
            <article class="player-card glass-card">

                <div class="player-card-top">

                    <div class="player-avatar">
                        ${escapeHTML(nickname.charAt(0).toUpperCase())}
                    </div>

                    <div class="player-info">
                        <h3>${escapeHTML(nickname)}</h3>

                        <p class="player-id">
                            Registration: ${escapeHTML(item.id || "N/A")}
                        </p>

                        <p class="player-game">
                            ${escapeHTML(game)} · ${escapeHTML(mode)}
                        </p>
                    </div>

                    <span class="player-status ${statusClass}">
                        ${escapeHTML(status)}
                    </span>

                </div>


                <div class="player-meta">

                    <div>
                        <span>TOURNAMENT</span>
                        <strong>${escapeHTML(tournamentName)}</strong>
                    </div>

                    <div>
                        <span>PLAYER ID</span>
                        <strong>${escapeHTML(playerId)}</strong>
                    </div>

                </div>


                <div class="player-actions">

                    <button
                        class="player-action approve"
                        data-action="approve"
                        data-id="${escapeHTML(item.id)}"
                        ${!isPending ? "disabled" : ""}>
                        ✓ APPROVE
                    </button>

                    <button
                        class="player-action reject"
                        data-action="reject"
                        data-id="${escapeHTML(item.id)}"
                        ${!isPending ? "disabled" : ""}>
                        × REJECT
                    </button>

                    <button
                        class="player-action details"
                        data-action="details"
                        data-id="${escapeHTML(item.id)}">
                        VIEW PLAYER DETAILS
                    </button>

                </div>

            </article>
        `;
    }).join("");

    playerList.querySelectorAll("[data-action]").forEach(function (button) {
        button.addEventListener("click", function () {
            handlePlayerAction(
                button.dataset.action,
                button.dataset.id
            );
        });
    });
}


/* APPROVE / REJECT */

function handlePlayerAction(action, id) {
    const item = registrations.find(function (registration) {
        return String(registration.id) === String(id);
    });

    if (!item) {
        showToast("Registration record not found.");
        return;
    }

    if (action === "details") {
        openPlayerDetails(item);
        return;
    }

    if (getStatus(item) !== "Pending") {
        showToast("Only pending demo registrations can be reviewed.");
        return;
    }

    if (action === "approve") {
        const confirmed = window.confirm(
            "Approve this registration in local demo data?"
        );

        if (!confirmed) return;

        item.status = "Approved";
    }

    if (action === "reject") {
        const confirmed = window.confirm(
            "Reject this registration in local demo data?"
        );

        if (!confirmed) return;

        item.status = "Rejected";
    }

    if (!saveRegistrations()) return;

    renderPlayers();

    showToast(
        action === "approve"
            ? "Demo registration approved."
            : "Demo registration rejected."
    );
}


/* PLAYER DETAILS */

function openPlayerDetails(item) {
    const nickname = item.nickname ||
        item.playerName ||
        "Unknown Player";

    document.getElementById("modalPlayerName").textContent =
        nickname;

    const rows = [
        ["Registration ID", item.id],
        ["Player Name", item.playerName || nickname],
        ["In-game Nickname", item.nickname],
        ["Player ID", item.playerId || item.gameId],
        ["Game", getTournamentGame(item)],
        ["Mode", getTournamentMode(item)],
        ["Tournament", getTournamentName(item)],
        ["Registration Date", formatDate(item.registrationDate || item.createdAtDate)],
        ["Status", getStatus(item)]
    ];

    playerDetails.innerHTML = rows.map(function (row) {
        return `
            <div class="detail-row">
                <span>${escapeHTML(row[0])}</span>
                <strong>${escapeHTML(row[1] || "Not provided")}</strong>
            </div>
        `;
    }).join("");

    playerModal.classList.add("open");
    playerModal.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
}


function closePlayerDetails() {
    playerModal.classList.remove("open");
    playerModal.setAttribute("aria-hidden", "true");
    document.body.style.overflow = "";
}


document.getElementById("closePlayerModal")
    .addEventListener("click", closePlayerDetails);

document.getElementById("closeDetailsBtn")
    .addEventListener("click", closePlayerDetails);

playerModal.addEventListener("click", function (event) {
    if (event.target === playerModal) {
        closePlayerDetails();
    }
});

document.addEventListener("keydown", function (event) {
    if (event.key === "Escape" && playerModal.classList.contains("open")) {
        closePlayerDetails();
    }
});


/* FILTER EVENTS */

document.querySelectorAll("[data-filter]").forEach(function (button) {
    button.addEventListener("click", function () {
        activeFilter = button.dataset.filter;

        document.querySelectorAll("[data-filter]").forEach(function (item) {
            item.classList.toggle(
                "active",
                item.dataset.filter === activeFilter
            );
        });

        renderPlayers();
    });
});


playerSearch.addEventListener("input", renderPlayers);

document.getElementById("clearSearch").addEventListener("click", function () {
    playerSearch.value = "";
    renderPlayers();
    playerSearch.focus();
});

tournamentFilter.addEventListener("change", renderPlayers);


/* NAVIGATION */

document.getElementById("backBtn").addEventListener("click", function () {
    window.location.href = "index.html";
});


/* INITIALIZE */

renderTournamentFilter();
renderPlayers();