import { auth, db } from "./firebase-config.js";

import {
    createUserWithEmailAndPassword,
    signInWithEmailAndPassword,
    signOut
} from "https://www.gstatic.com/firebasejs/13.0.0/firebase-auth.js";

import {
    doc,
    getDoc,
    setDoc,
    serverTimestamp
} from "https://www.gstatic.com/firebasejs/13.0.0/firebase-firestore.js";

(function () {
    "use strict";

    const form = document.getElementById("hostLoginForm");
    const tabs = document.querySelectorAll(".form-tab");
    const password = document.getElementById("loginPassword");
    const submitBtn = document.getElementById("submitBtn");
    const message = document.getElementById("loginMessage");

    const emailInput = document.getElementById("loginEmail");
    const hostIdInput = document.getElementById("hostId");
    const requestBtn = document.getElementById("requestApprovalBtn");
    const approvalStatus = document.getElementById("approvalStatus");

    if (!form || !password || !submitBtn || !message || !emailInput) {
        console.error("ArenaX Host login: Required elements missing.");
        return;
    }

    let currentMode = "login";
    let submitting = false;

    function showMessage(text, type = "") {
        message.textContent = text;
        message.className = "login-message " + type;
    }

    function setLoading(loading) {
        submitting = loading;
        submitBtn.disabled = loading;

        if (loading) {
            submitBtn.textContent = "PLEASE WAIT...";
        } else {
            submitBtn.textContent =
                currentMode === "signup"
                    ? "CREATE HOST ACCOUNT →"
                    : "LOGIN TO ARENAX →";
        }
    }

    function getErrorMessage(error) {
        switch (error.code) {
            case "auth/invalid-email":
                return "Please enter a valid email address.";

            case "auth/email-already-in-use":
                return "This email already has an account. Please login.";

            case "auth/weak-password":
                return "Password must contain at least 6 characters.";

            case "auth/invalid-credential":
            case "auth/user-not-found":
            case "auth/wrong-password":
                return "Incorrect email or password.";

            case "auth/too-many-requests":
                return "Too many attempts. Please try again later.";

            case "auth/network-request-failed":
                return "Network error. Check your internet connection.";

            case "permission-denied":
            case "firestore/permission-denied":
                return "Database permission denied. Security rules need setup.";

            default:
                console.error("ArenaX Host Auth error:", error);
                return "Something went wrong. Please try again.";
        }
    }

    tabs.forEach(function (tab) {
        tab.addEventListener("click", function () {
            if (submitting) return;

            currentMode = tab.dataset.tab;

            tabs.forEach(function (item) {
                item.classList.toggle("active", item === tab);
            });

            password.autocomplete =
                currentMode === "signup"
                    ? "new-password"
                    : "current-password";

            showMessage("");
            setLoading(false);
        });
    });

    form.addEventListener("submit", async function (event) {
        event.preventDefault();

        if (submitting) return;

        const email = emailInput.value.trim().toLowerCase();
        const pass = password.value;

        if (!email || !pass) {
            showMessage("Please complete all fields.", "error");
            return;
        }

        if (pass.length < 6) {
            showMessage(
                "Password must contain at least 6 characters.",
                "error"
            );
            return;
        }

        setLoading(true);
        showMessage("");

        let createdUser = null;

        try {
            if (currentMode === "signup") {
                const credential =
                    await createUserWithEmailAndPassword(
                        auth,
                        email,
                        pass
                    );

                createdUser = credential.user;

                await setDoc(doc(db, "hosts", createdUser.uid), {
                    uid: createdUser.uid,
                    email: createdUser.email,
                    role: "host",
                    status: "pending",
                    approved: false,
                    createdAt: serverTimestamp()
                });

                showMessage(
                    "Account created! Your account is awaiting Admin approval.",
                    "success"
                );

                form.reset();
            } else {
                const credential =
                    await signInWithEmailAndPassword(
                        auth,
                        email,
                        pass
                    );

                const user = credential.user;
                const hostRef = doc(db, "hosts", user.uid);
                const hostSnapshot = await getDoc(hostRef);

                if (!hostSnapshot.exists()) {
                    await signOut(auth);

                    showMessage(
                        "Host profile not found. Please contact Admin.",
                        "error"
                    );

                    return;
                }

                const hostData = hostSnapshot.data();

                if (
                    hostData.role !== "host" ||
                    hostData.status !== "approved" ||
                    hostData.approved !== true
                ) {
                    await signOut(auth);

                    showMessage(
                        "Your account is awaiting Admin approval.",
                        "error"
                    );

                    return;
                }

                window.location.replace("home.html");
                return;
            }
        } catch (error) {
            console.error("Host authentication failed:", error);

            /*
             * If signup created an Auth account but Firestore rejected
             * its profile, do not leave the new user signed in.
             */
            if (createdUser) {
                try {
                    await signOut(auth);
                } catch (signOutError) {
                    console.error(signOutError);
                }

                showMessage(
                    "Account authentication succeeded, but the host profile could not be saved. Database rules must be configured before retrying. If this email is already registered, contact Admin.",
                    "error"
                );
            } else {
                showMessage(getErrorMessage(error), "error");
            }
        } finally {
            setLoading(false);
        }
    });

    if (requestBtn && hostIdInput && approvalStatus) {
        requestBtn.addEventListener("click", async function () {
            const hostId = hostIdInput.value.trim().toUpperCase();

            if (!/^AXH-[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(hostId)) {
                approvalStatus.textContent =
                    "Enter a valid Host ID, e.g. AXH-AB12-CD34.";
                return;
            }

            approvalStatus.textContent =
                "Host ID format is valid. Sign in to your host account before requesting approval.";
        });
    }
})();