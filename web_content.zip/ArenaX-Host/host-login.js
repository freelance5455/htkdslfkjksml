(function () {
    "use strict";

    const form = document.getElementById("hostLoginForm");
    const tabs = document.querySelectorAll(".form-tab");
    const password = document.getElementById("loginPassword");
    const submitBtn = document.getElementById("submitBtn");
    const message = document.getElementById("loginMessage");

    let currentMode = "login";

    function showMessage(text, type) {
        message.textContent = text;
        message.className = "login-message " + (type || "");
    }

    tabs.forEach(function (tab) {
        tab.addEventListener("click", function () {
            currentMode = tab.dataset.tab;

            tabs.forEach(function (item) {
                item.classList.toggle("active", item === tab);
            });

            if (currentMode === "signup") {
                submitBtn.textContent = "CREATE HOST ACCOUNT →";
                password.autocomplete = "new-password";
            } else {
                submitBtn.textContent = "LOGIN TO ARENAX →";
                password.autocomplete = "current-password";
            }

            showMessage("", "");
        });
    });

    form.addEventListener("submit", function (event) {
        event.preventDefault();

        const email = document.getElementById("loginEmail").value.trim();
        const pass = password.value;

        if (!email || !pass) {
            showMessage("Please complete all fields.", "error");
            return;
        }

        /*
         * UI prototype only.
         * No real account is created and no approval request is sent.
         * Firebase Authentication and a secured backend will be added next.
         */
        if (currentMode === "signup") {
            showMessage(
                "Signup UI is ready. Secure account registration will be enabled after backend setup.",
                "error"
            );
        } else {
            showMessage(
                "Login backend is not connected yet. Your dashboard remains protected.",
                "error"
            );
        }
    });
  const hostIdInput = document.getElementById("hostId");
const requestBtn = document.getElementById("requestApprovalBtn");
const approvalStatus = document.getElementById("approvalStatus");

if (requestBtn && hostIdInput && approvalStatus) {
    requestBtn.addEventListener("click", function () {
        const hostId = hostIdInput.value.trim().toUpperCase();

        if (!/^AXH-[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(hostId)) {
            approvalStatus.innerHTML =
                '<span class="status-dot" style="background:#FF293D"></span>' +
                '<span>Enter a valid Host ID, e.g. AXH-AB12-CD34.</span>';
            return;
        }

        approvalStatus.innerHTML =
            '<span class="status-dot" style="background:#FFC857"></span>' +
            '<span>Host ID entered. Admin approval backend is not connected yet.</span>';
    });
}
})();