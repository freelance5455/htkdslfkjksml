(function () {
  "use strict";

  const PROFILE_KEY = "arenax_host_profile_demo_v1";
  const TOURNAMENT_KEY = "arenax_host_tournaments_demo_v1";
  const REGISTRATION_KEY = "arenax_host_registrations_demo_v1";
  const NOTIFICATION_KEY = "arenax_host_notifications_demo_v1";

  const $ = (id) => document.getElementById(id);

  function readJSON(key, fallback) {
    try {
      const value = localStorage.getItem(key);
      return value ? JSON.parse(value) : fallback;
    } catch (error) {
      return fallback;
    }
  }

  function saveJSON(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (error) {
      showToast("Unable to save. Device storage may be full.");
      return false;
    }
  }

  function getProfile() {
    let profile = readJSON(PROFILE_KEY, null);

    if (!profile || typeof profile !== "object" || Array.isArray(profile)) {
      profile = {
        name: "ArenaX Host",
        username: "arenaxhost",
        email: "",
        phone: "",
        hostId: "AX-HOST-001",
        joinedAt: Date.now()
      };

      saveJSON(PROFILE_KEY, profile);
    }

    return profile;
  }

  function cleanText(value, maxLength) {
    return String(value || "").trim().slice(0, maxLength);
  }

  function escapeText(value) {
    return String(value ?? "").replace(/[&<>"']/g, function (char) {
      const map = {
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
      };

      return map[char];
    });
  }

  function showToast(message) {
    const toast = $("toast");
    if (!toast) return;

    toast.textContent = message;
    toast.classList.add("show");

    clearTimeout(showToast.timer);

    showToast.timer = setTimeout(function () {
      toast.classList.remove("show");
    }, 2400);
  }

  function openModal(id) {
    const modal = $(id);
    if (!modal) return;

    modal.hidden = false;
    document.body.style.overflow = "hidden";
  }

  function closeModal(id) {
    const modal = $(id);
    if (!modal) return;

    modal.hidden = true;

    if (!document.querySelector(".modal-backdrop:not([hidden])")) {
      document.body.style.overflow = "";
    }
  }

  function showInfo(title, message) {
    $("infoModalTitle").textContent = title;
    $("infoModalMessage").textContent = message;
    openModal("infoModal");
  }

  function formatDate(value) {
    if (!value) return "Today";

    const date = new Date(value);

    if (Number.isNaN(date.getTime())) return "Today";

    return date.toLocaleDateString("en-IN", {
      day: "numeric",
      month: "short",
      year: "numeric"
    });
  }

  function renderProfile() {
    const profile = getProfile();

    const name = cleanText(profile.name, 50) || "ArenaX Host";
    const username = cleanText(profile.username, 24) || "arenaxhost";

    $("displayName").textContent = name;
    $("displayUsername").textContent = "@" + username.replace(/^@/, "");
    $("displayHostId").textContent = profile.hostId || "AX-HOST-001";

    $("avatarDisplay").textContent =
      Array.from(name)[0]?.toUpperCase() || "H";

    $("infoName").textContent = name;
    $("infoEmail").textContent = profile.email || "Not added";
    $("infoPhone").textContent = profile.phone || "Not added";
    $("infoJoined").textContent = formatDate(profile.joinedAt);

    $("editName").value = name;
    $("editUsername").value = username.replace(/^@/, "");
    $("editEmail").value = profile.email || "";
    $("editPhone").value = profile.phone || "";
  }

  function renderStats() {
    const tournaments = readJSON(TOURNAMENT_KEY, []);
    const registrations = readJSON(REGISTRATION_KEY, []);

    const safeTournaments = Array.isArray(tournaments) ? tournaments : [];
    const safeRegistrations = Array.isArray(registrations)
      ? registrations
      : [];

    const published = safeTournaments.filter(function (item) {
      return String(item.status || "").toLowerCase() === "published";
    });

    $("statTournaments").textContent = safeTournaments.length;
    $("statRegistrations").textContent = safeRegistrations.length;
    $("statPublished").textContent = published.length;
  }

  function loadNotifications() {
    const preferences = readJSON(NOTIFICATION_KEY, {
      tournaments: true,
      registrations: true,
      announcements: false
    });

    $("tournamentNotifications").checked = preferences.tournaments !== false;
    $("registrationNotifications").checked = preferences.registrations !== false;
    $("announcementNotifications").checked = preferences.announcements === true;
  }

  function saveNotifications() {
    const preferences = {
      tournaments: $("tournamentNotifications").checked,
      registrations: $("registrationNotifications").checked,
      announcements: $("announcementNotifications").checked
    };

    if (saveJSON(NOTIFICATION_KEY, preferences)) {
      $("notificationStatus").textContent =
        "Preferences saved on this device.";

      showToast("Notification preferences saved.");
    }
  }

  function saveProfile(event) {
    event.preventDefault();

    const name = cleanText($("editName").value, 50);
    const username = cleanText($("editUsername").value, 24)
      .replace(/^@+/, "")
      .replace(/\s+/g, "");

    const email = cleanText($("editEmail").value, 100);
    const phone = cleanText($("editPhone").value, 20);

    if (!name || !username) {
      showToast("Name and username are required.");
      return;
    }

    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      showToast("Enter a valid email address.");
      return;
    }

    const current = getProfile();

    const updated = {
      ...current,
      name: name,
      username: username,
      email: email,
      phone: phone
    };

    if (!saveJSON(PROFILE_KEY, updated)) return;

    renderProfile();
    closeModal("editModal");
    showToast("Profile updated successfully.");
  }

  function copyHostId() {
    const hostId = $("displayHostId").textContent;

    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(hostId)
        .then(function () {
          showToast("Host ID copied.");
        })
        .catch(function () {
          showInfo("Host ID", hostId);
        });
    } else {
      showInfo("Host ID", hostId);
    }
  }

  function resetNotifications() {
    const defaults = {
      tournaments: true,
      registrations: true,
      announcements: false
    };

    if (!saveJSON(NOTIFICATION_KEY, defaults)) return;

    loadNotifications();
    showToast("Notification preferences reset.");
  }

  function connectEvents() {
    $("backBtn").addEventListener("click", function () {
      if (window.history.length > 1) {
        window.history.back();
      } else {
        window.location.href = "index.html";
      }
    });

    $("settingsBtn").addEventListener("click", function () {
      $("appSettings").scrollIntoView({
        behavior: "smooth",
        block: "start"
      });
    });

    $("editProfileBtn").addEventListener("click", function () {
      renderProfile();
      openModal("editModal");
    });

    $("closeEditBtn").addEventListener("click", function () {
      closeModal("editModal");
    });

    $("cancelEditBtn").addEventListener("click", function () {
      closeModal("editModal");
    });

    $("profileForm").addEventListener("submit", saveProfile);
    $("copyHostId").addEventListener("click", copyHostId);

    [
      "tournamentNotifications",
      "registrationNotifications",
      "announcementNotifications"
    ].forEach(function (id) {
      $(id).addEventListener("change", saveNotifications);
    });

    $("privacyBtn").addEventListener("click", function () {
      showInfo(
        "Privacy & Security",
        "This is a frontend demo. Profile details and preferences are stored in this browser's localStorage. No server-side authentication, encryption, or account security is implemented yet. Avoid storing sensitive information."
      );
    });

    $("aboutBtn").addEventListener("click", function () {
      showInfo(
        "About ArenaX",
        "ARENAX | ELITE DIVISION\n\nONE ARENA • MULTIPLE GAMES • ONE LEGACY\n\nHost App frontend demo — Version 1.0"
      );
    });

    $("resetBtn").addEventListener("click", resetNotifications);

    $("logoutBtn").addEventListener("click", function () {
      openModal("logoutModal");
    });

    $("closeLogoutBtn").addEventListener("click", function () {
      closeModal("logoutModal");
    });

    $("cancelLogoutBtn").addEventListener("click", function () {
      closeModal("logoutModal");
    });

    $("confirmLogoutBtn").addEventListener("click", function () {
      // Demo only: no real authentication session exists.
      window.location.href = "index.html";
    });

    $("closeInfoBtn").addEventListener("click", function () {
      closeModal("infoModal");
    });

    $("confirmInfoBtn").addEventListener("click", function () {
      closeModal("infoModal");
    });

    document.querySelectorAll(".modal-backdrop").forEach(function (modal) {
      modal.addEventListener("click", function (event) {
        if (event.target === modal) {
          closeModal(modal.id);
        }
      });
    });

    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape") {
        document.querySelectorAll(".modal-backdrop:not([hidden])")
          .forEach(function (modal) {
            closeModal(modal.id);
          });
      }
    });

    window.addEventListener("storage", function (event) {
      if (
        event.key === PROFILE_KEY ||
        event.key === TOURNAMENT_KEY ||
        event.key === REGISTRATION_KEY
      ) {
        renderProfile();
        renderStats();
      }
    });
  }

  function init() {
    renderProfile();
    renderStats();
    loadNotifications();
    connectEvents();
  }

  document.addEventListener("DOMContentLoaded", init);
})();