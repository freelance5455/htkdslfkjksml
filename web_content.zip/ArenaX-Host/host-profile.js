import { auth, db } from "./firebase-config.js";

import {
  onAuthStateChanged,
  signOut
} from "https://www.gstatic.com/firebasejs/13.0.0/firebase-auth.js";

import {
  doc,
  getDoc,
  setDoc,
  collection,
  query,
  where,
  getDocs,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/13.0.0/firebase-firestore.js";

(function () {
  "use strict";

  const $ = (id) => document.getElementById(id);

  const DEFAULT_PREFERENCES = {
    tournaments: true,
    registrations: true,
    announcements: false
  };

  let currentUser = null;
  let hostData = {};
  let preferences = { ...DEFAULT_PREFERENCES };
  let isSavingProfile = false;
  let isSavingPreferences = false;

  function cleanText(value, maxLength) {
    return String(value ?? "").trim().slice(0, maxLength);
  }

  function showToast(message) {
    const toast = $("toast");
    if (!toast) return;

    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(showToast.timer);

    showToast.timer = setTimeout(() => {
      toast.classList.remove("show");
    }, 2600);
  }

  function openModal(id) {
    const modal = $(id);
    if (!modal) return;

    modal.hidden = false;
    document.body.style.overflow = "hidden";
  }

  function closeModal(id) {
    const modal = $(id);
    if (!modal) return;

    modal.hidden = true;

    if (!document.querySelector(".modal-backdrop:not([hidden])")) {
      document.body.style.overflow = "";
    }
  }

  function showInfo(title, message) {
    $("infoModalTitle").textContent = title;
    $("infoModalMessage").textContent = message;
    openModal("infoModal");
  }

  function asDate(value) {
    if (!value) return null;
    if (value instanceof Date) return value;

    if (typeof value.toDate === "function") {
      return value.toDate();
    }

    if (typeof value === "number" || typeof value === "string") {
      const date = new Date(value);
      return Number.isNaN(date.getTime()) ? null : date;
    }

    return null;
  }

  function formatDate(value) {
    const date = asDate(value);
    if (!date) return "Not available";

    return date.toLocaleDateString("en-IN", {
      day: "numeric",
      month: "short",
      year: "numeric"
    });
  }

  function getHostId() {
    return currentUser ? currentUser.uid : "";
  }

  function renderProfile() {
    const name = cleanText(
      hostData.name ||
      hostData.displayName ||
      currentUser?.displayName,
      50
    ) || "ArenaX Host";

    const username = cleanText(
      hostData.username || hostData.userName,
      24
    ) || (
      currentUser?.email
        ? currentUser.email.split("@")[0]
        : "arenaxhost"
    );

    const email = cleanText(
      hostData.email || currentUser?.email,
      100
    );

    const phone = cleanText(
      hostData.phone || currentUser?.phoneNumber,
      20
    );

    const hostId = cleanText(
      hostData.hostId || getHostId(),
      100
    );

    const joinedAt =
      hostData.joinedAt ||
      hostData.createdAt ||
      currentUser?.metadata?.creationTime ||
      null;

    $("displayName").textContent = name;
    $("displayUsername").textContent =
      "@" + username.replace(/^@/, "");

    $("displayHostId").textContent = hostId || "Not available";
    $("avatarDisplay").textContent =
      Array.from(name)[0]?.toUpperCase() || "H";

    $("infoName").textContent = name;
    $("infoEmail").textContent = email || "Not added";
    $("infoPhone").textContent = phone || "Not added";
    $("infoJoined").textContent = formatDate(joinedAt);

    $("editName").value = name;
    $("editUsername").value = username.replace(/^@/, "");
    $("editEmail").value = email;
    $("editPhone").value = phone;
  }

  async function loadHostProfile() {
    if (!currentUser) return;

    const hostRef = doc(db, "hosts", currentUser.uid);
    const hostSnap = await getDoc(hostRef);

    if (!hostSnap.exists()) {
      throw new Error("Host profile not found in Firebase.");
    }

    hostData = hostSnap.data() || {};
    renderProfile();
  }
  async function saveProfile(event) {
    event.preventDefault();

    if (!currentUser || isSavingProfile) return;

    const name = cleanText($("editName").value, 50);

    const username = cleanText(
      $("editUsername").value,
      24
    )
      .replace(/^@+/, "")
      .replace(/\s+/g, "");

    const email = cleanText($("editEmail").value, 100);
    const phone = cleanText($("editPhone").value, 20);

    if (!name || !username) {
      showToast("Name and username are required.");
      return;
    }

    if (
      email &&
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
    ) {
      showToast("Enter a valid email address.");
      return;
    }

    isSavingProfile = true;

    const submitButton = $("profileForm")
      .querySelector('button[type="submit"]');

    if (submitButton) {
      submitButton.disabled = true;
      submitButton.textContent = "Saving...";
    }

    try {
      const updates = {
        name,
        username,
        email,
        phone,
        updatedAt: serverTimestamp()
      };

      await setDoc(
        doc(db, "hosts", currentUser.uid),
        updates,
        { merge: true }
      );

      hostData = { ...hostData, ...updates };

      renderProfile();
      closeModal("editModal");
      showToast("Profile updated in Firebase.");

    } catch (error) {
      console.error("Host profile save failed:", error);

      showToast(
        error.code === "permission-denied"
          ? "Firebase permission denied. Rules baad mein fix karenge."
          : (error.message || "Could not save profile.")
      );

    } finally {
      isSavingProfile = false;

      if (submitButton) {
        submitButton.disabled = false;
        submitButton.textContent = "Save Changes";
      }
    }
  }

  function renderPreferences() {
    $("tournamentNotifications").checked =
      preferences.tournaments !== false;

    $("registrationNotifications").checked =
      preferences.registrations !== false;

    $("announcementNotifications").checked =
      preferences.announcements === true;

    $("notificationStatus").textContent =
      "Preferences are synced with your host account.";
  }

  async function loadPreferences() {
    if (!currentUser) return;

    const prefSnap = await getDoc(
      doc(db, "hostPreferences", currentUser.uid)
    );

    preferences = prefSnap.exists()
      ? {
          ...DEFAULT_PREFERENCES,
          ...(prefSnap.data().notifications || {})
        }
      : { ...DEFAULT_PREFERENCES };

    renderPreferences();
  }

  async function saveNotifications() {
    if (!currentUser || isSavingPreferences) return;

    preferences = {
      tournaments: $("tournamentNotifications").checked,
      registrations: $("registrationNotifications").checked,
      announcements: $("announcementNotifications").checked
    };

    isSavingPreferences = true;

    try {
      await setDoc(
        doc(db, "hostPreferences", currentUser.uid),
        {
          notifications: preferences,
          updatedAt: serverTimestamp()
        },
        { merge: true }
      );

      $("notificationStatus").textContent =
        "Preferences synced with your host account.";

      showToast("Notification preferences saved to Firebase.");

    } catch (error) {
      console.error("Notification preferences save failed:", error);

      showToast(
        error.code === "permission-denied"
          ? "Firebase permission denied. Rules baad mein fix karenge."
          : "Could not save notification preferences."
      );

    } finally {
      isSavingPreferences = false;
    }
  }

  async function resetNotifications() {
    preferences = { ...DEFAULT_PREFERENCES };
    renderPreferences();
    await saveNotifications();
  }
  async function loadStats() {
    if (!currentUser) return;

    try {
      const tournamentQuery = query(
        collection(db, "tournaments"),
        where("hostId", "==", currentUser.uid)
      );

      const tournamentSnapshot = await getDocs(tournamentQuery);

      const tournaments = tournamentSnapshot.docs.map(
        (item) => item.data()
      );

      $("statTournaments").textContent =
        String(tournaments.length);

      $("statPublished").textContent = String(
        tournaments.filter((item) =>
          String(item.status || "").toLowerCase() === "published"
        ).length
      );

      try {
        const registrationQuery = query(
          collection(db, "registrations"),
          where("hostId", "==", currentUser.uid)
        );

        const registrationSnapshot = await getDocs(
          registrationQuery
        );

        $("statRegistrations").textContent =
          String(registrationSnapshot.size);

      } catch (error) {
        console.warn(
          "Registration stats not available yet:",
          error
        );

        $("statRegistrations").textContent = "—";
      }

    } catch (error) {
      console.error("Host stats load failed:", error);

      $("statTournaments").textContent = "—";
      $("statPublished").textContent = "—";
      $("statRegistrations").textContent = "—";
    }
  }

  function copyHostId() {
    const hostId = $("displayHostId").textContent;

    if (navigator.clipboard?.writeText) {
      navigator.clipboard.writeText(hostId)
        .then(() => showToast("Host ID copied."))
        .catch(() => showInfo("Host ID", hostId));
    } else {
      showInfo("Host ID", hostId);
    }
  }

  function connectEvents() {
    $("backBtn").addEventListener("click", function () {
      if (window.history.length > 1) {
        window.history.back();
      } else {
        window.location.href = "index.html";
      }
    });

    $("settingsBtn").addEventListener("click", function () {
      $("appSettings").scrollIntoView({
        behavior: "smooth",
        block: "start"
      });
    });

    $("editProfileBtn").addEventListener("click", function () {
      renderProfile();
      openModal("editModal");
    });

    $("closeEditBtn").addEventListener(
      "click",
      () => closeModal("editModal")
    );

    $("cancelEditBtn").addEventListener(
      "click",
      () => closeModal("editModal")
    );

    $("profileForm").addEventListener(
      "submit",
      saveProfile
    );

    $("copyHostId").addEventListener(
      "click",
      copyHostId
    );

    [
      "tournamentNotifications",
      "registrationNotifications",
      "announcementNotifications"
    ].forEach((id) => {
      $(id).addEventListener("change", saveNotifications);
    });

    $("privacyBtn").addEventListener("click", function () {
      showInfo(
        "Privacy & Security",
        "Your host profile and notification preferences are stored in Firebase under your signed-in host account. Access is controlled by Firestore security rules."
      );
    });

    $("aboutBtn").addEventListener("click", function () {
      showInfo(
        "About ArenaX",
        "ARENAX | ELITE DIVISION\n\nONE ARENA • MULTIPLE GAMES • ONE LEGACY\n\nHost App — Version 1.0"
      );
    });

    $("resetBtn").addEventListener(
      "click",
      resetNotifications
    );

    $("logoutBtn").addEventListener(
      "click",
      () => openModal("logoutModal")
    );

    $("closeLogoutBtn").addEventListener(
      "click",
      () => closeModal("logoutModal")
    );

    $("cancelLogoutBtn").addEventListener(
      "click",
      () => closeModal("logoutModal")
    );

    $("confirmLogoutBtn").addEventListener(
      "click",
      async function () {
        try {
          await signOut(auth);
          window.location.href = "host-login.html";
        } catch (error) {
          console.error("Logout failed:", error);
          showToast("Could not log out. Please try again.");
        }
      }
    );

    $("closeInfoBtn").addEventListener(
      "click",
      () => closeModal("infoModal")
    );

    $("confirmInfoBtn").addEventListener(
      "click",
      () => closeModal("infoModal")
    );

    document.querySelectorAll(".modal-backdrop").forEach(
      (modal) => {
        modal.addEventListener("click", function (event) {
          if (event.target === modal) {
            closeModal(modal.id);
          }
        });
      }
    );

    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape") {
        document
          .querySelectorAll(".modal-backdrop:not([hidden])")
          .forEach((modal) => closeModal(modal.id));
      }
    });
  }
  async function initForUser(user) {
    currentUser = user;

    if (!user) {
      showToast("Please log in to your host account.");

      setTimeout(() => {
        window.location.href = "host-login.html";
      }, 900);

      return;
    }

    try {
      await loadHostProfile();

    } catch (error) {
      console.error("Host profile load failed:", error);

      showToast(
        error.code === "permission-denied"
          ? "Firebase permission denied. Rules baad mein fix karenge."
          : (error.message || "Could not load host profile.")
      );

      hostData = {};
      renderProfile();
    }

    await Promise.allSettled([
      loadPreferences(),
      loadStats()
    ]);
  }

  function init() {
    connectEvents();

    onAuthStateChanged(auth, function (user) {
      initForUser(user);
    });
  }

  document.addEventListener(
    "DOMContentLoaded",
    init
  );

})();