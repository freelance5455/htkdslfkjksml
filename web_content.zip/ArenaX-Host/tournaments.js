"use strict";

const STORAGE_KEY = "arenax_host_tournaments_demo_v1";

const listEl = document.getElementById("tournamentList");
const searchInput = document.getElementById("searchInput");
const clearSearchBtn = document.getElementById("clearSearch");
const sortSelect = document.getElementById("sortSelect");

const countEl = document.getElementById("tournamentCount");
const draftCountEl = document.getElementById("draftCount");
const publishedCountEl = document.getElementById("publishedCount");
const allCountEl = document.getElementById("allFilterCount");

const editModal = document.getElementById("editModal");
const deleteModal = document.getElementById("deleteModal");
const editForm = document.getElementById("editForm");
const toastEl = document.getElementById("toast");

let tournaments = loadTournaments();
let activeFilter = "All";
let pendingDeleteId = null;
let toastTimer;


/* STORAGE */

function loadTournaments() {
    try {
        const data = JSON.parse(
            localStorage.getItem(STORAGE_KEY) || "[]"
        );

        return Array.isArray(data) ? data : [];

    } catch (error) {
        console.error("Could not load tournament records:", error);
        return [];
    }
}


function saveTournaments() {
    try {
        localStorage.setItem(
            STORAGE_KEY,
            JSON.stringify(tournaments)
        );

        return true;

    } catch (error) {
        console.error("Could not save tournaments:", error);
        showToast("Could not save changes. Check device storage.");
        return false;
    }
}


/* HELPERS */

function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, function (char) {
        return {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#39;"
        }[char];
    });
}


function formatCurrency(value) {
    return "₹" + Number(value || 0).toLocaleString("en-IN");
}


function formatDate(value) {
    if (!value) return "Date not set";

    const parts = value.split("-").map(Number);

    if (parts.length !== 3 || parts.some(Number.isNaN)) {
        return "Date not set";
    }

    const date = new Date(parts[0], parts[1] - 1, parts[2]);

    return new Intl.DateTimeFormat("en-IN", {
        day: "numeric",
        month: "short",
        year: "numeric"
    }).format(date);
}


function formatTime(value) {
    if (!value) return "Time not set";

    const parts = value.split(":").map(Number);

    if (parts.length !== 2 || parts.some(Number.isNaN)) {
        return "Time not set";
    }

    const date = new Date();
    date.setHours(parts[0], parts[1], 0, 0);

    return new Intl.DateTimeFormat("en-IN", {
        hour: "numeric",
        minute: "2-digit",
        hour12: true
    }).format(date);
}


function getGameIcon(game) {
    const icons = {
        "BGMI": "🎯",
        "Free Fire MAX": "🔥",
        "Call of Duty Mobile": "⚔️",
        "ScarFall": "🎮",
        "Stumble Guys": "🏃"
    };

    return icons[game] || "🏆";
}


function showToast(message) {
    clearTimeout(toastTimer);

    toastEl.textContent = message;
    toastEl.classList.add("show");

    toastTimer = setTimeout(function () {
        toastEl.classList.remove("show");
    }, 2600);
}


/* COUNTS */

function renderCounts() {
    countEl.textContent =
        String(tournaments.length).padStart(2, "0");

    const drafts = tournaments.filter(function (item) {
        return item.status === "Draft";
    }).length;

    const published = tournaments.filter(function (item) {
        return item.status === "Published";
    }).length;

    draftCountEl.textContent =
        String(drafts).padStart(2, "0");

    publishedCountEl.textContent =
        String(published).padStart(2, "0");

    allCountEl.textContent = tournaments.length;
}


/* FILTER AND SORT */

function getVisibleTournaments() {
    const query = searchInput.value.trim().toLowerCase();

    let filtered = tournaments.filter(function (item) {
        const status = item.status || "Draft";

        const matchesFilter =
            activeFilter === "All" ||
            status === activeFilter;

        const searchableText = [
            item.name,
            item.game,
            item.mode,
            item.map,
            item.id
        ].join(" ").toLowerCase();

        const matchesSearch =
            !query || searchableText.includes(query);

        return matchesFilter && matchesSearch;
    });

    switch (sortSelect.value) {

        case "oldest":
            filtered.sort(function (a, b) {
                return Number(a.createdAt || 0) -
                    Number(b.createdAt || 0);
            });
            break;

        case "prize":
            filtered.sort(function (a, b) {
                return Number(b.prizePool || 0) -
                    Number(a.prizePool || 0);
            });
            break;

        case "name":
            filtered.sort(function (a, b) {
                return String(a.name || "").localeCompare(
                    String(b.name || "")
                );
            });
            break;

        default:
            filtered.sort(function (a, b) {
                return Number(b.createdAt || 0) -
                    Number(a.createdAt || 0);
            });
            break;
    }

    return filtered;
}


/* RENDER TOURNAMENTS */

function renderTournaments() {
    renderCounts();

    const visible = getVisibleTournaments();

    if (visible.length === 0) {
        const hasAny = tournaments.length > 0;

        listEl.innerHTML = `
            <div class="empty-state glass-card">
                <div class="empty-icon">
                    ${hasAny ? "⌕" : "🏆"}
                </div>

                <h2>
                    ${
                        hasAny
                            ? "No matching tournaments"
                            : "No tournaments yet"
                    }
                </h2>

                <p>
                    ${
                        hasAny
                            ? "Try another search or filter."
                            : "Create your first tournament and its draft will appear here."
                    }
                </p>

                ${
                    hasAny
                        ? ""
                        : `<button class="secondary-btn" id="emptyCreateBtn">
                               Create Tournament
                           </button>`
                }
            </div>
        `;

        const emptyCreateBtn =
            document.getElementById("emptyCreateBtn");

        if (emptyCreateBtn) {
            emptyCreateBtn.addEventListener(
                "click",
                openCreatePage
            );
        }

        return;
    }

    listEl.innerHTML = visible.map(function (item) {
        const status = item.status || "Draft";

        const statusClass =
            status === "Published" ? "published" : "";

        const safeId = escapeHTML(item.id);

        return `
            <article class="tournament-card glass-card">

                <div class="card-top">

                    <div class="game-symbol">
                        ${getGameIcon(item.game)}
                    </div>

                    <div class="card-title-area">

                        <p class="card-game">
                            ${escapeHTML(item.game || "Game")}
                        </p>

                        <h3>
                            ${escapeHTML(item.name || "Untitled Tournament")}
                        </h3>

                        <p class="card-mode">
                            ${escapeHTML(item.mode || "Mode not set")}
                            ·
                            ${escapeHTML(item.format || "Tournament")}
                        </p>

                    </div>

                    <span class="status-badge ${statusClass}">
                        ${escapeHTML(status)}
                    </span>

                </div>

                <div class="card-metrics">

                    <div>
                        <span class="metric-label">PRIZE POOL</span>
                        <strong class="metric-value gold">
                            ${formatCurrency(item.prizePool)}
                        </strong>
                    </div>

                    <div>
                        <span class="metric-label">ENTRY FEE</span>
                        <strong class="metric-value">
                            ${
                                item.entryType === "Paid"
                                    ? formatCurrency(item.entryFee)
                                    : "FREE"
                            }
                        </strong>
                    </div>

                    <div>
                        <span class="metric-label">TOTAL SLOTS</span>
                        <strong class="metric-value">
                            ${Number(item.slots || 0)}
                        </strong>
                    </div>

                    <div>
                        <span class="metric-label">REGISTRATIONS</span>
                        <strong class="metric-value">
                            ${Number(item.registrations || 0)}
                        </strong>
                    </div>

                </div>

                <div class="card-meta">
                    <span>📅 ${formatDate(item.date)}</span>
                    <span>◷ ${formatTime(item.time)}</span>
                    <span>🗺️ ${escapeHTML(item.map || "Room not set")}</span>
                </div>

                <div class="card-actions">

                    <button
                        class="card-action-btn manage"
                        data-action="manage"
                        data-id="${safeId}">
                        ◈ MANAGE
                    </button>

                    <button
                        class="card-action-btn edit"
                        data-action="edit"
                        data-id="${safeId}">
                        ✎ EDIT
                    </button>

                    <button
                        class="card-action-btn"
                        data-action="status"
                        data-id="${safeId}">
                        ${
                            status === "Published"
                                ? "↩ MARK DRAFT"
                                : "↗ MARK PUBLISHED"
                        }
                    </button>

                    <button
                        class="card-action-btn delete"
                        data-action="delete"
                        data-id="${safeId}">
                        DELETE DEMO RECORD
                    </button>

                </div>

            </article>
        `;
    }).join("");


    /* CARD BUTTON ACTIONS */

    listEl.querySelectorAll("[data-action]").forEach(function (button) {
        button.addEventListener("click", function () {
            const id = button.dataset.id;
            const action = button.dataset.action;

            if (action === "manage") {
                window.location.href =
                    "tournament-details.html?id=" +
                    encodeURIComponent(id);
                return;
            }

            if (action === "edit") {
                openEditModal(id);
            }

            if (action === "delete") {
                openDeleteModal(id);
            }

            if (action === "status") {
                toggleStatus(id);
            }
        });
    });
}


/* EDIT */

function openEditModal(id) {
    const item = tournaments.find(function (tournament) {
        return String(tournament.id) === String(id);
    });

    if (!item) {
        showToast("Tournament not found.");
        return;
    }

    document.getElementById("editId").value = item.id;

    document.getElementById("editName").value =
        item.name || "";

    document.getElementById("editPrize").value =
        Number(item.prizePool || 0);

    document.getElementById("editSlots").value =
        Number(item.slots || 2);

    document.getElementById("editMap").value =
        item.map || "";

    document.getElementById("editRules").value =
        item.rules || "";

    openModal(editModal);

    document.getElementById("editName").focus({
        preventScroll: true
    });
}


editForm.addEventListener("submit", function (event) {
    event.preventDefault();

    const id = document.getElementById("editId").value;

    const item = tournaments.find(function (tournament) {
        return String(tournament.id) === String(id);
    });

    if (!item) {
        showToast("Tournament not found.");
        return;
    }

    const name =
        document.getElementById("editName").value.trim();

    const prize = Number(
        document.getElementById("editPrize").value
    );

    const slots = Number(
        document.getElementById("editSlots").value
    );

    const map =
        document.getElementById("editMap").value.trim();

    const rules =
        document.getElementById("editRules").value.trim();

    if (!name || !map || !rules) {
        showToast("Complete all fields.");
        return;
    }

    if (
        !Number.isFinite(prize) ||
        prize < 0 ||
        prize > 10000000
    ) {
        showToast("Enter a valid prize pool.");
        return;
    }

    if (
        !Number.isInteger(slots) ||
        slots < 2 ||
        slots > 1000
    ) {
        showToast("Slots must be between 2 and 1000.");
        return;
    }

    item.name = name;
    item.prizePool = prize;
    item.slots = slots;
    item.map = map;
    item.rules = rules;

    if (!saveTournaments()) return;

    closeModal(editModal);
    renderTournaments();

    showToast("Tournament updated on this device.");
});


/* DELETE */

function openDeleteModal(id) {
    const item = tournaments.find(function (tournament) {
        return String(tournament.id) === String(id);
    });

    if (!item) {
        showToast("Tournament not found.");
        return;
    }

    pendingDeleteId = id;

    document.getElementById("deleteMessage").textContent =
        'Remove "' + item.name +
        '" from this device? This cannot be undone.';

    openModal(deleteModal);
}


document
    .getElementById("confirmDeleteBtn")
    .addEventListener("click", function () {
        if (pendingDeleteId === null) return;

        const previous = tournaments;

        tournaments = tournaments.filter(function (item) {
            return String(item.id) !== String(pendingDeleteId);
        });

        if (!saveTournaments()) {
            tournaments = previous;
            return;
        }

        pendingDeleteId = null;

        closeModal(deleteModal);
        renderTournaments();

        showToast("Demo tournament deleted.");
    });


/* STATUS */

function toggleStatus(id) {
    const item = tournaments.find(function (tournament) {
        return String(tournament.id) === String(id);
    });

    if (!item) return;

    if (item.status === "Published") {
        item.status = "Draft";

    } else {
        const confirmed = window.confirm(
            "Mark this tournament as Published in local demo data? " +
            "This does not publish it to the Player App."
        );

        if (!confirmed) return;

        item.status = "Published";
    }

    if (!saveTournaments()) return;

    renderTournaments();

    showToast(
        item.status === "Published"
            ? "Demo status changed to Published."
            : "Tournament returned to Draft."
    );
}


/* MODALS */

function openModal(modal) {
    modal.classList.add("open");
    modal.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
}


function closeModal(modal) {
    modal.classList.remove("open");
    modal.setAttribute("aria-hidden", "true");

    if (
        !editModal.classList.contains("open") &&
        !deleteModal.classList.contains("open")
    ) {
        document.body.style.overflow = "";
    }
}


document
    .getElementById("closeEditBtn")
    .addEventListener("click", function () {
        closeModal(editModal);
    });


document
    .getElementById("cancelEditBtn")
    .addEventListener("click", function () {
        closeModal(editModal);
    });


document
    .getElementById("cancelDeleteBtn")
    .addEventListener("click", function () {
        pendingDeleteId = null;
        closeModal(deleteModal);
    });


[editModal, deleteModal].forEach(function (modal) {
    modal.addEventListener("click", function (event) {
        if (event.target === modal) {
            closeModal(modal);
        }
    });
});


document.addEventListener("keydown", function (event) {
    if (event.key === "Escape") {
        if (editModal.classList.contains("open")) {
            closeModal(editModal);
        }

        if (deleteModal.classList.contains("open")) {
            closeModal(deleteModal);
            pendingDeleteId = null;
        }
    }
});


/* FILTERS */

document.querySelectorAll("[data-filter]").forEach(function (button) {
    button.addEventListener("click", function () {
        activeFilter = button.dataset.filter;

        document.querySelectorAll("[data-filter]").forEach(
            function (item) {
                item.classList.toggle(
                    "active",
                    item.dataset.filter === activeFilter
                );
            }
        );

        renderTournaments();
    });
});


searchInput.addEventListener("input", renderTournaments);


clearSearchBtn.addEventListener("click", function () {
    searchInput.value = "";

    renderTournaments();

    searchInput.focus();
});


sortSelect.addEventListener("change", renderTournaments);


/* NAVIGATION */

function openCreatePage() {
    window.location.href = "create.html";
}


document
    .getElementById("createBtn")
    .addEventListener("click", openCreatePage);


document
    .getElementById("bottomCreateBtn")
    .addEventListener("click", openCreatePage);


document
    .getElementById("backBtn")
    .addEventListener("click", function () {
        window.location.href = "index.html";
    });


/* STARTUP */

renderTournaments();