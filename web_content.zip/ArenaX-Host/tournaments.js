import { auth, db } from "./firebase-config.js";

import { onAuthStateChanged } from
  "https://www.gstatic.com/firebasejs/13.0.0/firebase-auth.js";

import {
  collection,
  query,
  where,
  getDocs,
  doc,
  updateDoc,
  deleteDoc,
  serverTimestamp
} from
  "https://www.gstatic.com/firebasejs/13.0.0/firebase-firestore.js";

const editModal = document.getElementById("editModal");
const editForm = document.getElementById("editForm");
const editId = document.getElementById("editId");
const editName = document.getElementById("editName");
const editPrize = document.getElementById("editPrize");
const editSlots = document.getElementById("editSlots");
const editMap = document.getElementById("editMap");
const editRules = document.getElementById("editRules");

const closeEditBtn = document.getElementById("closeEditBtn");
const cancelEditBtn = document.getElementById("cancelEditBtn");

const deleteModal = document.getElementById("deleteModal");
const cancelDeleteBtn = document.getElementById("cancelDeleteBtn");
const confirmDeleteBtn = document.getElementById("confirmDeleteBtn");
const deleteMessage = document.getElementById("deleteMessage");

const tournamentList =
  document.getElementById("tournamentList");

const searchInput =
  document.getElementById("searchInput");

const filterButtons =
  document.querySelectorAll(".filter-btn");

const sortSelect =
  document.getElementById("sortSelect");

const tournamentCount =
  document.getElementById("tournamentCount");

const draftCount =
  document.getElementById("draftCount");

const publishedCount =
  document.getElementById("publishedCount");

const allFilterCount =
  document.getElementById("allFilterCount");

const clearSearchBtn =
  document.getElementById("clearSearch");

let activeFilter = "All";

let tournaments = [];
let selectedTournamentId = null;

function showMessage(message) {
  alert(message);
}

function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, char => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[char]);
}

function normalizeStatus(status) {
  return String(status || "draft").toLowerCase();
}

function renderTournaments() {
  if (!tournamentList) return;

  const search = (searchInput?.value || "").toLowerCase();

  let filtered = tournaments.filter(tournament => {
    const name = String(tournament.name || "").toLowerCase();
    const game = String(tournament.game || "").toLowerCase();
    const status = normalizeStatus(tournament.status);

    const matchesSearch =
      name.includes(search) || game.includes(search);

    const matchesFilter =
      activeFilter === "All" ||
      status === activeFilter.toLowerCase();

    return matchesSearch && matchesFilter;
  });

  const sortMode = sortSelect?.value || "newest";

  if (sortMode === "newest") {
    filtered.sort((a, b) =>
      timestampValue(b.createdAt) - timestampValue(a.createdAt)
    );
  } else if (sortMode === "oldest") {
    filtered.sort((a, b) =>
      timestampValue(a.createdAt) - timestampValue(b.createdAt)
    );
  } else if (sortMode === "prize") {
    filtered.sort((a, b) =>
      Number(b.prizePool || 0) - Number(a.prizePool || 0)
    );
  } else if (sortMode === "name") {
    filtered.sort((a, b) =>
      String(a.name || "").localeCompare(String(b.name || ""))
    );
  }

  if (tournamentCount) {
    tournamentCount.textContent = String(tournaments.length).padStart(2, "0");
  }

  if (draftCount) {
    draftCount.textContent = String(
      tournaments.filter(t => normalizeStatus(t.status) === "draft").length
    ).padStart(2, "0");
  }

  if (publishedCount) {
    publishedCount.textContent = String(
      tournaments.filter(t => normalizeStatus(t.status) === "published").length
    ).padStart(2, "0");
  }

  if (allFilterCount) {
    allFilterCount.textContent = tournaments.length;
  }

  if (!filtered.length) {
    tournamentList.innerHTML = `
      <div class="empty-state glass-card">
        <div class="empty-icon">🏆</div>
        <h2>No tournaments found</h2>
        <p>Try another filter or create a tournament.</p>
      </div>
    `;
    return;
  }

  tournamentList.innerHTML = filtered.map(tournament => {
    const id = escapeHTML(tournament.id);
    const name = escapeHTML(tournament.name || "Untitled Tournament");
    const game = escapeHTML(tournament.game || "Game not specified");
    const status = normalizeStatus(tournament.status);

    return `
  <article class="tournament-card glass-card" data-id="${id}">

    <div class="card-top">
      <div class="game-symbol">🏆</div>

      <div class="card-title-area">
        <p class="card-game">${game}</p>
        <h3>${name}</h3>
        <p class="card-mode">${escapeHTML(tournament.mode || tournament.format || "Tournament")}</p>
      </div>

      <span class="status-badge ${status === "published" ? "published" : ""}">
        ${escapeHTML(status.toUpperCase())}
      </span>
    </div>

    <div class="card-metrics">
      <div>
        <span class="metric-label">PRIZE POOL</span>
        <strong class="metric-value gold">₹${escapeHTML(tournament.prizePool ?? "0")}</strong>
      </div>

      <div>
        <span class="metric-label">TOTAL SLOTS</span>
        <strong class="metric-value">${escapeHTML(tournament.slots ?? "—")}</strong>
      </div>
    </div>

    <div class="card-meta">
      <span>🗺️ ${escapeHTML(tournament.map || "Map not set")}</span>
      <span>👥 ${escapeHTML(tournament.registrations ?? 0)} registrations</span>
    </div>

    <div class="card-actions">
      <button class="card-action-btn" type="button" data-action="manage">
        MANAGE
      </button>

      <button class="card-action-btn edit" type="button" data-action="edit">
        EDIT
      </button>

      <button class="card-action-btn" type="button" data-action="toggle">
        ${status === "published" ? "UNPUBLISH" : "PUBLISH"}
      </button>

      <button class="card-action-btn delete" type="button" data-action="delete">
        DELETE TOURNAMENT
      </button>
    </div>

  </article>
`;
  }).join("");
}

function timestampValue(value) {
  if (value && typeof value.toMillis === "function") {
    return value.toMillis();
  }

  const date = new Date(value || 0).getTime();
  return Number.isFinite(date) ? date : 0;
}

async function loadTournaments(user) {
  if (!tournamentList) return;

  tournamentList.innerHTML = "<p>Loading tournaments...</p>";

  try {
    const tournamentQuery = query(
      collection(db, "tournaments"),
      where("hostId", "==", user.uid)
    );

    const snapshot = await getDocs(tournamentQuery);

    tournaments = snapshot.docs.map(item => ({
      id: item.id,
      ...item.data()
    }));

    renderTournaments();

  } catch (error) {
    console.error("Load tournaments error:", error);
    tournamentList.innerHTML =
      "<p>Could not load tournaments. Check Firebase rules and connection.</p>";
  }
}

async function toggleTournament(id) {
  const tournament = tournaments.find(item => item.id === id);
  if (!tournament) return;

  const currentlyPublished =
    normalizeStatus(tournament.status) === "published";

  const newStatus = currentlyPublished ? "draft" : "published";

  try {
    await updateDoc(doc(db, "tournaments", id), {
      status: newStatus,
      published: !currentlyPublished,
      updatedAt: serverTimestamp()
    });

    tournament.status = newStatus;
    tournament.published = !currentlyPublished;

    renderTournaments();
    showMessage(`Tournament status changed to ${newStatus}.`);

  } catch (error) {
    console.error("Publish status error:", error);
    showMessage("Status update failed. Firebase rules may be blocking it.");
  }
}

function editTournament(id) {
  const tournament = tournaments.find(item => item.id === id);
  if (!tournament || !editModal || !editForm) return;

  editId.value = id;
  editName.value = tournament.name || "";
  editPrize.value = tournament.prizePool ?? 0;
  editSlots.value = tournament.slots ?? 2;
  editMap.value = tournament.map || "";
  editRules.value = tournament.rules || "";

  editModal.classList.add("open");
  editModal.setAttribute("aria-hidden", "false");
}

function deleteTournament(id) {
  const tournament = tournaments.find(item => item.id === id);
  if (!tournament || !deleteModal) return;

  selectedTournamentId = id;

  if (deleteMessage) {
    deleteMessage.textContent =
      `Delete "${tournament.name || "this tournament"}" permanently?`;
  }

  deleteModal.classList.add("active");
  deleteModal.setAttribute("aria-hidden", "false");
}

cancelDeleteBtn?.addEventListener("click", () => {
  selectedTournamentId = null;
  deleteModal?.classList.remove("active");
  deleteModal?.setAttribute("aria-hidden", "true");
});

confirmDeleteBtn?.addEventListener("click", async () => {
  if (!selectedTournamentId) return;

  const id = selectedTournamentId;
  confirmDeleteBtn.disabled = true;

  try {
    await deleteDoc(doc(db, "tournaments", id));

    tournaments = tournaments.filter(item => item.id !== id);
    selectedTournamentId = null;

    deleteModal?.classList.remove("active");
    deleteModal?.setAttribute("aria-hidden", "true");

    renderTournaments();
    showMessage("Tournament deleted successfully.");

  } catch (error) {
    console.error("Delete error:", error);
    showMessage("Delete failed. Check Firebase rules.");
  } finally {
    confirmDeleteBtn.disabled = false;
  }
});

editForm?.addEventListener("submit", async event => {
  event.preventDefault();

  const id = editId.value;
  const tournament = tournaments.find(item => item.id === id);

  if (!tournament) {
    showMessage("Tournament not found.");
    return;
  }

  const name = editName.value.trim();
  const prizePool = Number(editPrize.value);
  const slots = Number(editSlots.value);
  const map = editMap.value.trim();
  const rules = editRules.value.trim();

  if (!name || !map || !rules ||
      !Number.isFinite(prizePool) || prizePool < 0 ||
      !Number.isInteger(slots) || slots < 2) {
    showMessage("Please enter valid tournament details.");
    return;
  }

  try {
    await updateDoc(doc(db, "tournaments", id), {
      name,
      prizePool,
      slots,
      map,
      rules,
      updatedAt: serverTimestamp()
    });

    Object.assign(tournament, { name, prizePool, slots, map, rules });

    editModal.classList.remove("active");
    editModal.setAttribute("aria-hidden", "true");

    renderTournaments();
    showMessage("Tournament updated successfully.");

  } catch (error) {
    console.error("Edit save error:", error);
    showMessage("Save failed. Check Firebase rules.");
  }
});

function closeEditModal() {
  if (!editModal) return;

  editModal.classList.remove("open");
  editModal.setAttribute("aria-hidden", "true");
}

closeEditBtn?.addEventListener("click", closeEditModal);
cancelEditBtn?.addEventListener("click", closeEditModal);

closeEditBtn?.addEventListener("click", closeEditModal);
cancelEditBtn?.addEventListener("click", closeEditModal);
tournamentList?.addEventListener("click", async event => {
  const button = event.target.closest("button[data-action]");
  if (!button) return;

  const card = button.closest("[data-id]");
  if (!card) return;

  const id = card.dataset.id;
  const action = button.dataset.action;

  if (action === "manage") {
  window.location.href =
    "tournament-details.html?id=" + encodeURIComponent(id);
  }
  if (action === "toggle") await toggleTournament(id);
  if (action === "edit") await editTournament(id);
  if (action === "delete") await deleteTournament(id);
});

searchInput?.addEventListener("input", renderTournaments);

clearSearchBtn?.addEventListener("click", () => {
  if (searchInput) searchInput.value = "";
  renderTournaments();
});

sortSelect?.addEventListener("change", renderTournaments);

filterButtons.forEach(button => {
  button.addEventListener("click", () => {
    activeFilter = button.dataset.filter || "All";

    filterButtons.forEach(item => {
      item.classList.toggle("active", item === button);
    });

    renderTournaments();
  });
});

onAuthStateChanged(auth, user => {
  if (!user) {
    tournaments = [];

    if (tournamentList) {
      tournamentList.innerHTML =
        "<p>Please log in to view your tournaments.</p>";
    }

    return;
  }

  loadTournaments(user);
});
// Back button
document.getElementById("backBtn")?.addEventListener("click", () => {
  window.location.href = "index.html";
});

// Create tournament buttons
function openCreateTournament() {
  window.location.href = "create.html";
}

document.getElementById("createBtn")
  ?.addEventListener("click", openCreateTournament);

document.getElementById("bottomCreateBtn")
  ?.addEventListener("click", openCreateTournament);