"use strict";

const STORAGE_KEY = "arenax_host_tournaments_demo_v1";

const form = document.getElementById("tournamentForm");
const gameSelect = document.getElementById("game");
const modeSelect = document.getElementById("mode");
const entryType = document.getElementById("entryType");
const entryFeeGroup = document.getElementById("entryFeeGroup");
const entryFeeInput = document.getElementById("entryFee");
const dateInput = document.getElementById("startDate");
const timeInput = document.getElementById("startTime");
const errorBox = document.getElementById("formError");
const toast = document.getElementById("toast");

const pickerBackdrop = document.getElementById("pickerBackdrop");
const pickerTitle = document.getElementById("pickerTitle");
const pickerContent = document.getElementById("pickerContent");
const pickerActions = document.getElementById("pickerActions");

let toastTimer;
let activePicker = null;
let calendarMonth = new Date();
let pendingDate = "";
let pendingHour = 20;
let pendingMinute = 0;


/* GAME MODES */

const gameModes = {
    "BGMI": [
        "1v1 TDM",
        "2v2 TDM",
        "4v4 TDM",
        "Solo",
        "Squad"
    ],

    "Free Fire MAX": [
        "1v1 CS",
        "2v2 CS",
        "4v4 CS",
        "Solo",
        "Duo",
        "Squad"
    ],

    "Call of Duty Mobile": [
        "Solo",
        "Duo",
        "Squad"
    ],

    "ScarFall": [
        "Solo",
        "Duo",
        "Squad"
    ],

    "Stumble Guys": [
        "Tournament Room"
    ]
};


/* STORAGE */

function loadSavedTournaments() {
    try {
        const data = JSON.parse(
            localStorage.getItem(STORAGE_KEY) || "[]"
        );

        return Array.isArray(data) ? data : [];

    } catch (error) {
        console.error(error);
        return [];
    }
}


/* NOTIFICATIONS */

function showToast(message) {
    clearTimeout(toastTimer);

    toast.textContent = message;
    toast.classList.add("show");

    toastTimer = setTimeout(function () {
        toast.classList.remove("show");
    }, 2500);
}


function showError(message) {
    errorBox.textContent = message;
    errorBox.classList.add("show");

    errorBox.scrollIntoView({
        behavior: "smooth",
        block: "center"
    });
}


function clearError() {
    errorBox.textContent = "";
    errorBox.classList.remove("show");
}


function getFormValue(name) {
    return String(form.elements[name].value || "").trim();
}


/* DATE AND TIME HELPERS */

function localISODate(date) {
    return [
        date.getFullYear(),
        String(date.getMonth() + 1).padStart(2, "0"),
        String(date.getDate()).padStart(2, "0")
    ].join("-");
}


function parseISODate(value) {
    if (!value) return null;

    const parts = value.split("-").map(Number);

    return new Date(
        parts[0],
        parts[1] - 1,
        parts[2]
    );
}


function formatDate(value) {
    const date = parseISODate(value);

    if (!date) {
        return "Choose tournament date";
    }

    return new Intl.DateTimeFormat("en-IN", {
        day: "numeric",
        month: "short",
        year: "numeric"
    }).format(date);
}


function formatTime(value) {
    if (!value) {
        return "Choose start time";
    }

    const parts = value.split(":").map(Number);
    const date = new Date();

    date.setHours(parts[0], parts[1], 0, 0);

    return new Intl.DateTimeFormat("en-IN", {
        hour: "numeric",
        minute: "2-digit",
        hour12: true
    }).format(date);
}


/* GLASS PICKER */

function openPicker(title, type) {
    activePicker = type;

    pickerTitle.textContent = title;

    pickerBackdrop.classList.add("open");
    pickerBackdrop.setAttribute("aria-hidden", "false");

    document.body.style.overflow = "hidden";
}


function closePicker() {
    pickerBackdrop.classList.remove("open");
    pickerBackdrop.setAttribute("aria-hidden", "true");

    document.body.style.overflow = "";

    activePicker = null;
}


function actionButton(label, primary, callback) {
    const button = document.createElement("button");

    button.type = "button";

    button.className =
        "picker-action-btn" +
        (primary ? " primary" : "");

    button.textContent = label;

    button.addEventListener("click", callback);

    return button;
}


/* CUSTOM DROPDOWN */

function showOptionPicker(select, title, iconMap = {}) {
    if (select.disabled) return;

    openPicker(title, "options");

    pickerContent.innerHTML = "";
    pickerActions.innerHTML = "";

    const list = document.createElement("div");

    list.className = "picker-options";

    Array.from(select.options)
        .filter(function (option) {
            return !option.disabled && option.value !== "";
        })
        .forEach(function (option) {

            const button = document.createElement("button");

            button.type = "button";

            button.className =
                "picker-option" +
                (
                    option.value === select.value
                        ? " selected"
                        : ""
                );

            const icon = document.createElement("span");

            icon.className = "picker-option-icon";

            icon.textContent =
                iconMap[option.value] ||
                (
                    option.value.includes("Paid")
                        ? "₹"
                        : "✦"
                );

            const label = document.createElement("span");

            label.textContent = option.textContent;

            const check = document.createElement("span");

            check.className = "picker-check";

            check.textContent =
                option.value === select.value
                    ? "✓"
                    : "";

            button.append(icon, label, check);

            button.addEventListener("click", function () {

                select.value = option.value;

                select.dispatchEvent(
                    new Event("change", {
                        bubbles: true
                    })
                );

                syncSelectTrigger(select);

                if (select === gameSelect) {
                    syncSelectTrigger(modeSelect);
                }

                closePicker();
            });

            list.appendChild(button);
        });

    pickerContent.appendChild(list);

    pickerActions.appendChild(
        actionButton("CANCEL", false, closePicker)
    );
}


function syncSelectTrigger(select) {
    const trigger = select.parentElement.querySelector(
        ".custom-select-trigger"
    );

    if (!trigger) return;

    const option = select.options[select.selectedIndex];

    const value = trigger.querySelector(
        ".custom-trigger-value"
    );

    value.textContent = option
        ? option.textContent
        : "Choose option";

    value.classList.toggle(
        "placeholder",
        !select.value
    );

    trigger.disabled = select.disabled;

    trigger.style.opacity = select.disabled
        ? ".5"
        : "1";
}


function enhanceSelect(select, title, icons = {}) {
    select.classList.add("custom-source-select");

    const trigger = document.createElement("button");

    trigger.type = "button";

    trigger.className = "custom-select-trigger";

    trigger.innerHTML = `
        <span class="custom-trigger-value placeholder"></span>
        <span class="custom-trigger-chevron">⌄</span>
    `;

    select.insertAdjacentElement("afterend", trigger);

    trigger.addEventListener("click", function () {
        showOptionPicker(select, title, icons);
    });

    syncSelectTrigger(select);
}


/* CUSTOM DATE AND TIME BUTTONS */

function enhanceDateTimeInput(input, kind) {
    input.classList.add("custom-source-input");

    const wrap = document.createElement("div");

    wrap.className = "custom-field-wrap";

    input.parentNode.insertBefore(wrap, input);

    wrap.appendChild(input);

    const trigger = document.createElement("button");

    trigger.type = "button";

    trigger.className =
        kind === "date"
            ? "custom-date-trigger"
            : "custom-time-trigger";

    trigger.innerHTML = `
        <span class="custom-trigger-value placeholder"></span>
        <span class="custom-trigger-chevron">
            ${kind === "date" ? "▦" : "◷"}
        </span>
    `;

    wrap.appendChild(trigger);

    trigger.addEventListener("click", function () {

        if (kind === "date") {
            openCalendar();
        } else {
            openTimePicker();
        }

    });

    input.addEventListener("change", function () {
        syncDateTimeTrigger(input, trigger, kind);
    });

    syncDateTimeTrigger(input, trigger, kind);

    return trigger;
}


function syncDateTimeTrigger(input, trigger, kind) {
    const value = trigger.querySelector(
        ".custom-trigger-value"
    );

    const hasValue = Boolean(input.value);

    value.textContent =
        kind === "date"
            ? formatDate(input.value)
            : formatTime(input.value);

    value.classList.toggle(
        "placeholder",
        !hasValue
    );
}


/* CUSTOM CALENDAR */

function openCalendar() {
    openPicker(
        "Select tournament date",
        "calendar"
    );

    pendingDate =
        dateInput.value ||
        dateInput.min ||
        localISODate(new Date());

    const parsed = parseISODate(pendingDate) || new Date();

    calendarMonth = new Date(
        parsed.getFullYear(),
        parsed.getMonth(),
        1
    );

    renderCalendar();
}


function renderCalendar() {
    pickerContent.innerHTML = "";
    pickerActions.innerHTML = "";

    const top = document.createElement("div");

    top.className = "calendar-top";

    const prev = document.createElement("button");

    prev.type = "button";
    prev.className = "calendar-nav";
    prev.textContent = "‹";
    prev.setAttribute("aria-label", "Previous month");

    const next = document.createElement("button");

    next.type = "button";
    next.className = "calendar-nav";
    next.textContent = "›";
    next.setAttribute("aria-label", "Next month");

    const monthLabel = document.createElement("div");

    monthLabel.className = "calendar-month";

    monthLabel.textContent =
        new Intl.DateTimeFormat("en-IN", {
            month: "long",
            year: "numeric"
        }).format(calendarMonth);

    prev.addEventListener("click", function () {

        calendarMonth.setMonth(
            calendarMonth.getMonth() - 1
        );

        renderCalendar();
    });

    next.addEventListener("click", function () {

        calendarMonth.setMonth(
            calendarMonth.getMonth() + 1
        );

        renderCalendar();
    });

    top.append(prev, monthLabel, next);

    pickerContent.appendChild(top);

    const grid = document.createElement("div");

    grid.className = "calendar-grid";

    ["S", "M", "T", "W", "T", "F", "S"]
        .forEach(function (day) {

            const cell = document.createElement("div");

            cell.className = "calendar-weekday";
            cell.textContent = day;

            grid.appendChild(cell);
        });

    const firstDay = new Date(
        calendarMonth.getFullYear(),
        calendarMonth.getMonth(),
        1
    ).getDay();

    const daysInMonth = new Date(
        calendarMonth.getFullYear(),
        calendarMonth.getMonth() + 1,
        0
    ).getDate();

    const todayISO = localISODate(new Date());

    for (let i = 0; i < firstDay; i++) {

        const blank = document.createElement("div");

        blank.className = "calendar-empty";

        grid.appendChild(blank);
    }

    for (let day = 1; day <= daysInMonth; day++) {

        const date = new Date(
            calendarMonth.getFullYear(),
            calendarMonth.getMonth(),
            day
        );

        const iso = localISODate(date);

        const button = document.createElement("button");

        button.type = "button";
        button.className = "calendar-day";
        button.textContent = String(day);

        if (iso === todayISO) {
            button.classList.add("today");
        }

        if (iso === pendingDate) {
            button.classList.add("selected");
        }

        button.disabled = iso < todayISO;

        button.addEventListener("click", function () {

            pendingDate = iso;

            renderCalendar();
        });

        grid.appendChild(button);
    }

    pickerContent.appendChild(grid);

    pickerActions.appendChild(
        actionButton("CANCEL", false, closePicker)
    );

    pickerActions.appendChild(
        actionButton("SET DATE", true, function () {

            if (!pendingDate) return;

            dateInput.value = pendingDate;

            dateInput.dispatchEvent(
                new Event("change", {
                    bubbles: true
                })
            );

            clearError();

            closePicker();
        })
    );
}


/* CUSTOM TIME PICKER */

function openTimePicker() {
    const parts = (
        timeInput.value || "20:00"
    ).split(":").map(Number);

    pendingHour = Number.isFinite(parts[0])
        ? parts[0]
        : 20;

    pendingMinute = Number.isFinite(parts[1])
        ? parts[1]
        : 0;

    openPicker(
        "Select start time",
        "time"
    );

    renderTimePicker();
}


function renderTimePicker() {
    pickerContent.innerHTML = "";
    pickerActions.innerHTML = "";

    const row = document.createElement("div");

    row.className = "time-picker-row";


    function makeColumn(value, type) {

        const col = document.createElement("div");

        col.className = "time-column";

        const up = document.createElement("button");

        up.type = "button";
        up.className = "time-spin";
        up.textContent = "＋";
        up.setAttribute(
            "aria-label",
            "Increase " + type
        );

        const val = document.createElement("div");

        val.className = "time-value";

        val.textContent = String(value).padStart(2, "0");

        const down = document.createElement("button");

        down.type = "button";
        down.className = "time-spin";
        down.textContent = "−";
        down.setAttribute(
            "aria-label",
            "Decrease " + type
        );


        up.addEventListener("click", function () {

            if (type === "hour") {
                pendingHour = (pendingHour + 1) % 24;
            } else {
                pendingMinute = (pendingMinute + 5) % 60;
            }

            renderTimePicker();
        });


        down.addEventListener("click", function () {

            if (type === "hour") {
                pendingHour = (pendingHour + 23) % 24;
            } else {
                pendingMinute = (pendingMinute + 55) % 60;
            }

            renderTimePicker();
        });

        col.append(up, val, down);

        return col;
    }


    const separator = document.createElement("div");

    separator.className = "time-separator";
    separator.textContent = ":";

    row.append(
        makeColumn(pendingHour, "hour"),
        separator,
        makeColumn(pendingMinute, "minute")
    );

    pickerContent.appendChild(row);

    const hint = document.createElement("p");

    hint.className = "field-hint";
    hint.style.textAlign = "center";

    hint.textContent =
        "Use + and − to adjust the hour and minutes.";

    pickerContent.appendChild(hint);

    pickerActions.appendChild(
        actionButton("CANCEL", false, closePicker)
    );

    pickerActions.appendChild(
        actionButton("SET TIME", true, function () {

            timeInput.value =
                String(pendingHour).padStart(2, "0") +
                ":" +
                String(pendingMinute).padStart(2, "0");

            timeInput.dispatchEvent(
                new Event("change", {
                    bubbles: true
                })
            );

            clearError();

            closePicker();
        })
    );
}


/* UPDATE GAME MODES */

function updateModes() {
    const modes = gameModes[gameSelect.value] || [];

    modeSelect.innerHTML = "";

    const placeholder = document.createElement("option");

    placeholder.value = "";

    placeholder.textContent = modes.length
        ? "Choose a tournament mode"
        : "Select game first";

    modeSelect.appendChild(placeholder);

    modes.forEach(function (mode) {

        const option = document.createElement("option");

        option.value = mode;
        option.textContent = mode;

        modeSelect.appendChild(option);
    });

    modeSelect.disabled = modes.length === 0;

    syncSelectTrigger(modeSelect);
}


/* ENTRY TYPE */

function updateEntryType() {
    const isPaid = entryType.value === "Paid";

    entryFeeGroup.classList.toggle(
        "hidden",
        !isPaid
    );

    entryFeeInput.disabled = !isPaid;
    entryFeeInput.required = isPaid;

    if (!isPaid) {
        entryFeeInput.value = "";
    }
}


/* DATE LIMIT */

function setMinimumDate() {
    dateInput.min = localISODate(new Date());
}


/* FORM VALIDATION */

function validateForm() {
    clearError();

    const requiredFields = [
        ["tournamentName", "Enter a tournament name."],
        ["game", "Choose a game."],
        ["mode", "Choose a tournament mode."],
        ["format", "Choose a tournament format."],
        ["prizePool", "Enter the prize pool."],
        ["slots", "Enter total slots."],
        ["startDate", "Choose a tournament date."],
        ["startTime", "Choose a start time."],
        ["map", "Enter the map or room."],
        ["rules", "Enter tournament rules."]
    ];

    for (const [name, message] of requiredFields) {

        if (!getFormValue(name)) {

            showError(message);

            return false;
        }
    }

    if (
        entryType.value === "Paid" &&
        !entryFeeInput.value
    ) {
        showError("Enter the paid entry fee.");

        return false;
    }

    const startDateTime = new Date(
        getFormValue("startDate") +
        "T" +
        getFormValue("startTime")
    );

    if (Number.isNaN(startDateTime.getTime())) {

        showError("Please enter a valid date and time.");

        return false;
    }

    if (startDateTime.getTime() <= Date.now()) {

        showError(
            "Choose a future tournament date and time."
        );

        return false;
    }

    const slots = Number(getFormValue("slots"));

    const prizePool = Number(
        getFormValue("prizePool")
    );

    const perKill = Number(
        getFormValue("perKill") || 0
    );

    if (
        !Number.isInteger(slots) ||
        slots < 2 ||
        slots > 1000
    ) {
        showError(
            "Total slots must be between 2 and 1000."
        );

        return false;
    }

    if (
        !Number.isFinite(prizePool) ||
        prizePool < 0 ||
        prizePool > 10000000
    ) {
        showError("Enter a valid prize pool.");

        return false;
    }

    if (
        !Number.isFinite(perKill) ||
        perKill < 0 ||
        perKill > 100000
    ) {
        showError(
            "Per-kill reward must be between ₹0 and ₹100,000."
        );

        return false;
    }

    if (entryType.value === "Paid") {

        const fee = Number(entryFeeInput.value);

        if (
            !Number.isFinite(fee) ||
            fee <= 0 ||
            fee > 100000
        ) {
            showError(
                "Enter a valid entry fee between ₹1 and ₹100,000."
            );

            return false;
        }
    }

    return true;
}


/* CREATE TOURNAMENT RECORD */

function createTournamentRecord() {
    return {
        id: "HOST-" +
            Date.now().toString(36).toUpperCase(),

        name: getFormValue("tournamentName"),

        game: gameSelect.value,

        mode: modeSelect.value,

        format: getFormValue("format"),

        entryType: entryType.value,

        entryFee: entryType.value === "Paid"
            ? Number(entryFeeInput.value)
            : 0,

        prizePool: Number(
            getFormValue("prizePool")
        ),

        perKill: Number(
            getFormValue("perKill") || 0
        ),

        slots: Number(
            getFormValue("slots")
        ),

        date: getFormValue("startDate"),

        time: getFormValue("startTime"),

        map: getFormValue("map"),

        rules: getFormValue("rules"),

        registrations: 0,

        status: "Draft",

        createdAt: Date.now()
    };
}


/* INITIALIZE CUSTOM PICKERS */

enhanceSelect(
    gameSelect,
    "Choose a game",
    {
        "BGMI": "🎮",
        "Free Fire MAX": "🔥",
        "Call of Duty Mobile": "🎯",
        "ScarFall": "⚔️",
        "Stumble Guys": "🏃"
    }
);

enhanceSelect(
    modeSelect,
    "Choose a tournament mode"
);

enhanceSelect(
    document.getElementById("format"),
    "Choose tournament format"
);

enhanceSelect(
    entryType,
    "Choose entry type",
    {
        "Free": "✦",
        "Paid": "₹"
    }
);

const dateTrigger = enhanceDateTimeInput(
    dateInput,
    "date"
);

const timeTrigger = enhanceDateTimeInput(
    timeInput,
    "time"
);


/* EVENT LISTENERS */

gameSelect.addEventListener(
    "change",
    updateModes
);

entryType.addEventListener(
    "change",
    updateEntryType
);

form.addEventListener("input", function () {

    if (errorBox.classList.contains("show")) {
        clearError();
    }
});


document
    .getElementById("pickerClose")
    .addEventListener("click", closePicker);


pickerBackdrop.addEventListener("click", function (event) {

    if (event.target === pickerBackdrop) {
        closePicker();
    }
});


document.addEventListener("keydown", function (event) {

    if (
        event.key === "Escape" &&
        pickerBackdrop.classList.contains("open")
    ) {
        closePicker();
    }
});


/* SAVE DRAFT */

form.addEventListener("submit", function (event) {

    event.preventDefault();

    if (!validateForm()) {
        return;
    }

    const record = createTournamentRecord();

    const tournaments = loadSavedTournaments();

    tournaments.push(record);

    try {

        localStorage.setItem(
            STORAGE_KEY,
            JSON.stringify(tournaments)
        );

        showToast(
            "Tournament draft saved on this device!"
        );

        setTimeout(function () {

            window.location.href = "index.html";

        }, 900);

    } catch (error) {

        console.error(error);

        showError(
            "Could not save the draft. Check your browser storage."
        );
    }
});


/* NAVIGATION */

document
    .getElementById("backBtn")
    .addEventListener("click", function () {

        window.location.href = "index.html";
    });


document
    .getElementById("cancelBtn")
    .addEventListener("click", function () {

        window.location.href = "index.html";
    });


/* STARTUP */

updateModes();
updateEntryType();
setMinimumDate();

syncDateTimeTrigger(
    dateInput,
    dateTrigger,
    "date"
);

syncDateTimeTrigger(
    timeInput,
    timeTrigger,
    "time"
);