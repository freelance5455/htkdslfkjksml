import { initializeApp } from "https://www.gstatic.com/firebasejs/13.0.0/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/13.0.0/firebase-auth.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/13.0.0/firebase-firestore.js";

const firebaseConfig = {
    apiKey: "AIzaSyDr1oJaWSgX16GBBpxrJW_8y6RceFxJIWY",
    authDomain: "arenax-95c3c.firebaseapp.com",
    projectId: "arenax-95c3c",
    storageBucket: "arenax-95c3c.firebasestorage.app",
    messagingSenderId: "288476781459",
    appId: "1:288476781459:web:a70917c0075268b3b7e666"
};

const app = initializeApp(firebaseConfig);

const auth = getAuth(app);
const db = getFirestore(app);

export { app, auth, db };