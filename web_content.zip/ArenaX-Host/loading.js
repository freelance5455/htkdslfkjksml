(function () {
  "use strict";

  const bar = document.getElementById("progressBar");
  const percent = document.getElementById("progressPercent");
  const status = document.getElementById("loadingText");

  if (!bar || !percent || !status) return;

  const messages = [
    { at: 0, text: "Preparing your arena..." },
    { at: 25, text: "Loading host interface..." },
    { at: 50, text: "Synchronizing tournament tools..." },
    { at: 75, text: "Almost ready, Host..." },
    { at: 100, text: "Entering the arena..." }
  ];

  let progress = 0;
  let messageIndex = 0;

  const interval = setInterval(function () {
    progress = Math.min(progress + 2, 100);

    bar.style.width = progress + "%";
    percent.textContent = progress + "%";

    while (
      messageIndex < messages.length - 1 &&
      progress >= messages[messageIndex + 1].at
    ) {
      messageIndex++;
      status.textContent = messages[messageIndex].text;
    }

    if (progress >= 100) {
      clearInterval(interval);

      setTimeout(function () {
        window.location.replace("index.html");
      }, 400);
    }
  }, 60);
})();