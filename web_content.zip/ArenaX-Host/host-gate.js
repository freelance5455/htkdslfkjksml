import { auth, db } from "./firebase-config.js";
import {
  onAuthStateChanged,
  signOut
} from "https://www.gstatic.com/firebasejs/13.0.0/firebase-auth.js";

import {
  doc,
  getDoc
} from "https://www.gstatic.com/firebasejs/13.0.0/firebase-firestore.js";

const loader = document.getElementById("arenaxLoader");
const progress = document.getElementById("loaderProgress");
const startBtn = document.getElementById("loaderStartBtn");

let approvedHost = false;
let authChecked = false;
let progressValue = 0;

if (loader && progress && startBtn) {
  startBtn.textContent = "INITIALIZING...";
  startBtn.disabled = true;

  const timer = setInterval(() => {
    progressValue = Math.min(progressValue + 2, 100);
    progress.style.width = progressValue + "%";

    if (progressValue >= 100) {
      clearInterval(timer);
      checkButton();
    }
  }, 50);
}

function checkButton() {
  if (!startBtn) return;

  if (!authChecked) {
    startBtn.textContent = "VERIFYING HOST...";
    startBtn.disabled = true;
    return;
  }

  startBtn.disabled = false;
  startBtn.textContent = "ENTER ARENAX";

  startBtn.onclick = () => {
    window.location.replace("host-login.html");
  };
}

onAuthStateChanged(auth, async (user) => {
  authChecked = true;
  approvedHost = false;

  if (user) {
    try {
      const hostRef = doc(db, "hosts", user.uid);
      const hostSnap = await getDoc(hostRef);

      if (hostSnap.exists()) {
        const host = hostSnap.data();

        approvedHost =
          host.role === "host" &&
          host.status === "approved" &&
          host.approved === true;
      }

      if (!approvedHost) {
        await signOut(auth);
      }
    } catch (error) {
      console.error("Host verification failed:", error);
      approvedHost = false;
    }
  }

  checkButton();
});