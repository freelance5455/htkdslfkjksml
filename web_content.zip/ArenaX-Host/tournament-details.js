(function () {
  "use strict";

  const TOURNAMENT_KEY = "arenax_host_tournaments_demo_v1";
  const REGISTRATION_KEY = "arenax_host_registrations_demo_v1";
  const ROOM_KEY = "arenax_host_room_details_demo_v1";
  const ANNOUNCEMENT_KEY = "arenax_host_announcements_demo_v1";
  const RESULTS_KEY = "arenax_host_results_demo_v1";

  const $ = (id) => document.getElementById(id);

  let currentTournamentId = null;
  let pendingConfirmation = null;

  function readJSON(key, fallback) {
    try {
      const value = localStorage.getItem(key);
      return value ? JSON.parse(value) : fallback;
    } catch (error) {
      return fallback;
    }
  }

  function saveJSON(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (error) {
      toast("Unable to save. Device storage may be full.");
      return false;
    }
  }

  function getArray(key) {
    const value = readJSON(key, []);
    return Array.isArray(value) ? value : [];
  }

  function safeString(value) {
    return String(value ?? "").trim();
  }

  function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, function (char) {
      return {
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
      }[char];
    });
  }

  function toast(message) {
    const el = $("toast");
    if (!el) return;

    el.textContent = message;
    el.classList.add("show");

    clearTimeout(toast.timer);

    toast.timer = setTimeout(function () {
      el.classList.remove("show");
    }, 2400);
  }

  function openModal(id) {
    const modal = $(id);
    if (!modal) return;

    modal.hidden = false;
    document.body.style.overflow = "hidden";
  }

  function closeModal(id) {
    const modal = $(id);
    if (!modal) return;

    modal.hidden = true;

    if (!document.querySelector(".td-modal-backdrop:not([hidden])")) {
      document.body.style.overflow = "";
    }
  }

  function getTournaments() {
    return getArray(TOURNAMENT_KEY);
  }

  function getCurrentTournament() {
    return getTournaments().find(function (item) {
      return String(item.id) === String(currentTournamentId);
    }) || null;
  }

  function getTournamentId(item) {
    return String(
      item.tournamentId ??
      item.tournament_id ??
      item.tournament ??
      ""
    );
  }

  function getTournamentRegistrations() {
    const registrations = getArray(REGISTRATION_KEY);

    return registrations.filter(function (item) {
      return getTournamentId(item) === String(currentTournamentId);
    });
  }

  function normalizeStatus(status) {
    const value = safeString(status).toLowerCase();

    if (value === "approved" || value === "accepted") return "approved";
    if (value === "rejected" || value === "declined") return "rejected";

    return "pending";
  }

  function formatMoney(value) {
    const amount = Number(value || 0);

    if (!Number.isFinite(amount)) return "₹0";

    return "₹" + amount.toLocaleString("en-IN", {
      maximumFractionDigits: 2
    });
  }

  function formatDate(value) {
    if (!value) return "Not scheduled";

    const date = new Date(value + (String(value).length === 10 ? "T00:00:00" : ""));

    if (Number.isNaN(date.getTime())) return String(value);

    return date.toLocaleDateString("en-IN", {
      day: "numeric",
      month: "short",
      year: "numeric"
    });
  }

  function formatTime(value) {
    if (!value) return "Not scheduled";

    const match = String(value).match(/^(\d{1,2}):(\d{2})$/);

    if (!match) return String(value);

    let hour = Number(match[1]);
    const minute = match[2];
    const suffix = hour >= 12 ? "PM" : "AM";

    hour = hour % 12 || 12;

    return hour + ":" + minute + " " + suffix;
  }

  function getGameSymbol(game) {
    const value = safeString(game).toLowerCase();

    if (value.includes("bgmi")) return "BG";
    if (value.includes("free fire")) return "FF";
    if (value.includes("call of duty") || value.includes("cod")) return "CD";
    if (value.includes("scarfall")) return "SF";
    if (value.includes("stumble")) return "SG";

    return "AX";
  }

  function loadTournamentOptions() {
    const select = $("tournamentSelect");
    const tournaments = getTournaments();

    select.innerHTML = "";

    if (!tournaments.length) {
      const option = document.createElement("option");
      option.value = "";
      option.textContent = "No tournaments available";
      select.appendChild(option);

      currentTournamentId = null;
      $("emptyState").hidden = false;
      $("tournamentContent").hidden = true;
      $("selectionHint").textContent = "Create a tournament to get started.";
      return;
    }

    tournaments.forEach(function (item) {
      const option = document.createElement("option");

      option.value = String(item.id);
      option.textContent =
        safeString(item.name) || "Untitled Tournament";

      select.appendChild(option);
    });

   const requestedId = new URLSearchParams(
  window.location.search
).get("id");

const preferred = tournaments.find(function (item) {
  return String(item.id) === String(requestedId);
}) || tournaments.find(function (item) {
  return String(item.id) === String(currentTournamentId);
}); 

    currentTournamentId = preferred
      ? String(preferred.id)
      : String(tournaments[0].id);

    select.value = currentTournamentId;

    $("emptyState").hidden = true;
    $("tournamentContent").hidden = false;

    renderAll();
  }

  function renderTournament() {
    const tournament = getCurrentTournament();
    if (!tournament) return;

    const status = safeString(tournament.status) || "Draft";

    $("gameBadge").textContent = tournament.game || "Game";
    $("gameSymbol").textContent = getGameSymbol(tournament.game);
    $("tournamentName").textContent = tournament.name || "Untitled Tournament";

    $("tournamentMode").textContent = [
      tournament.mode || "Mode not specified",
      tournament.format || "Format not specified"
    ].join(" · ");

    $("tournamentId").textContent = "Tournament ID: " + tournament.id;
    $("tournamentStatus").textContent = status.toUpperCase();

    $("tournamentStatus").className = "td-status";

    if (status.toLowerCase() === "published") {
      $("tournamentStatus").classList.add("status-published");
    } else if (status.toLowerCase() === "completed") {
      $("tournamentStatus").classList.add("status-completed");
    } else if (status.toLowerCase() === "cancelled") {
      $("tournamentStatus").classList.add("status-cancelled");
    }

    $("publishBtn").textContent =
      status.toLowerCase() === "published"
        ? "Unpublish Tournament"
        : "Publish Tournament";

    $("prizePool").textContent = formatMoney(tournament.prizePool);
    $("totalSlots").textContent = Number(tournament.slots || 0);

    const entryType = safeString(tournament.entryType).toLowerCase();
    $("entryFee").textContent =
      entryType === "paid"
        ? formatMoney(tournament.entryFee)
        : "FREE";

    $("matchDate").textContent = formatDate(tournament.date);
    $("matchTime").textContent = formatTime(tournament.time);
    $("matchMap").textContent = tournament.map || "Not specified";
    $("killReward").textContent = formatMoney(tournament.perKill);
    $("tournamentRules").textContent = tournament.rules || "No rules added yet.";

    const registrations = getTournamentRegistrations();

    $("registeredCount").textContent = registrations.length;

    $("selectionHint").textContent =
      status + " · " + registrations.length + " registration(s)";

    renderPlayers();
    loadRoomDetails();
    renderAnnouncements();
    renderResults();
  }

  function renderAll() {
    renderTournament();
  }

  function renderPlayers() {
    const registrations = getTournamentRegistrations();
    const search = safeString($("playerSearch").value).toLowerCase();
    const filter = $("playerFilter").value;

    const filtered = registrations.filter(function (item) {
      const nickname = safeString(
        item.nickname || item.playerName || item.username || item.name
      );

      const playerId = safeString(item.playerId || item.uid || item.id);

      const matchesSearch =
        nickname.toLowerCase().includes(search) ||
        playerId.toLowerCase().includes(search);

      const status = normalizeStatus(item.status);
      const matchesStatus = filter === "all" || status === filter;

      return matchesSearch && matchesStatus;
    });

    const approved = registrations.filter(function (item) {
      return normalizeStatus(item.status) === "approved";
    }).length;

    $("playerCountLabel").textContent =
      registrations.length + (registrations.length === 1 ? " player" : " players");

    $("approvedCountLabel").textContent = approved + " approved";

    const list = $("playersList");
    list.innerHTML = "";

    $("noPlayers").hidden = filtered.length !== 0;

    filtered.forEach(function (player) {
      const nickname = safeString(
        player.nickname || player.playerName || player.username || player.name
      ) || "Unnamed Player";

      const playerId = safeString(player.playerId || player.uid || player.id) || "No ID";
      const status = normalizeStatus(player.status);

      const card = document.createElement("article");
      card.className = "td-player-card";

      const avatar = document.createElement("div");
      avatar.className = "td-player-avatar";
      avatar.textContent = Array.from(nickname)[0]?.toUpperCase() || "P";

      const info = document.createElement("div");
      info.className = "td-player-info";

      const name = document.createElement("strong");
      name.textContent = nickname;

      const id = document.createElement("small");
      id.textContent = "Player ID: " + playerId;

      const badge = document.createElement("span");
      badge.className = "td-player-status " + status;
      badge.textContent = status;

      info.append(name, id, badge);

      const actions = document.createElement("div");
      actions.className = "td-player-actions";

      if (status !== "approved") {
        const approve = document.createElement("button");
        approve.className = "approve-player";
        approve.textContent = "Approve";
        approve.dataset.action = "approve";
        approve.dataset.id = String(player.id);

        actions.appendChild(approve);
      }

      if (status !== "rejected") {
        const reject = document.createElement("button");
        reject.className = "reject-player";
        reject.textContent = "Reject";
        reject.dataset.action = "reject";
        reject.dataset.id = String(player.id);

        actions.appendChild(reject);
      }

      card.append(avatar, info);

      if (actions.children.length) {
        card.appendChild(actions);
      }

      list.appendChild(card);
    });
  }

  function loadRoomDetails() {
    const rooms = readJSON(ROOM_KEY, {});
    const room = rooms[String(currentTournamentId)] || {};

    $("roomId").value = room.roomId || "";
    $("roomPassword").value = room.roomPassword || "";
    $("roomPassword").type = "password";
    $("togglePassword").textContent = "Show";
  }

  function saveRoomDetails(event) {
    event.preventDefault();

    const rooms = readJSON(ROOM_KEY, {});
    const roomId = safeString($("roomId").value);
    const roomPassword = safeString($("roomPassword").value);

    rooms[String(currentTournamentId)] = {
      roomId: roomId,
      roomPassword: roomPassword,
      updatedAt: Date.now()
    };

    if (saveJSON(ROOM_KEY, rooms)) {
      toast("Room details saved on this device.");
    }
  }

  function clearRoomDetails() {
    $("roomId").value = "";
    $("roomPassword").value = "";

    const rooms = readJSON(ROOM_KEY, {});
    delete rooms[String(currentTournamentId)];

    if (saveJSON(ROOM_KEY, rooms)) {
      toast("Room details cleared.");
    }
  }

  function loadEditForm() {
    const tournament = getCurrentTournament();
    if (!tournament) return;

    $("editName").value = tournament.name || "";
    $("editGame").value = tournament.game || "BGMI";
    $("editMode").value = tournament.mode || "";
    $("editFormat").value = tournament.format || "";
    $("editSlots").value = Number(tournament.slots || 1);
    $("editEntryType").value =
      String(tournament.entryType).toLowerCase() === "paid" ? "Paid" : "Free";
    $("editEntryFee").value = Number(tournament.entryFee || 0);
    $("editPrizePool").value = Number(tournament.prizePool || 0);
    $("editDate").value = tournament.date || "";
    $("editTime").value = tournament.time || "";
    $("editMap").value = tournament.map || "";
    $("editRules").value = tournament.rules || "";

    openModal("editModal");
  }

  function saveEditedTournament(event) {
    event.preventDefault();

    const tournaments = getTournaments();
    const index = tournaments.findIndex(function (item) {
      return String(item.id) === String(currentTournamentId);
    });

    if (index === -1) {
      toast("Tournament not found.");
      return;
    }

    const old = tournaments[index];

    const entryType = $("editEntryType").value;
    const entryFee = entryType === "Paid"
      ? Number($("editEntryFee").value || 0)
      : 0;

    const updated = {
      ...old,
      name: safeString($("editName").value),
      game: $("editGame").value,
      mode: safeString($("editMode").value),
      format: safeString($("editFormat").value),
      slots: Number($("editSlots").value),
      entryType: entryType,
      entryFee: entryFee,
      prizePool: Number($("editPrizePool").value || 0),
      date: $("editDate").value,
      time: $("editTime").value,
      map: safeString($("editMap").value),
      rules: safeString($("editRules").value)
    };

    if (!updated.name) {
      toast("Tournament name is required.");
      return;
    }

    if (!Number.isFinite(updated.slots) || updated.slots < 1) {
      toast("Enter a valid number of slots.");
      return;
    }

    if (
      !Number.isFinite(updated.entryFee) ||
      updated.entryFee < 0 ||
      !Number.isFinite(updated.prizePool) ||
      updated.prizePool < 0
    ) {
      toast("Enter valid fee and prize amounts.");
      return;
    }

    tournaments[index] = updated;

    if (!saveJSON(TOURNAMENT_KEY, tournaments)) return;

    closeModal("editModal");
    loadTournamentOptions();
    toast("Tournament updated.");
  }

  function togglePublish() {
    const tournaments = getTournaments();
    const index = tournaments.findIndex(function (item) {
      return String(item.id) === String(currentTournamentId);
    });

    if (index === -1) return;

    const currentStatus = safeString(tournaments[index].status).toLowerCase();

    if (currentStatus === "completed" || currentStatus === "cancelled") {
      toast("Completed or cancelled tournaments cannot be published here.");
      return;
    }

    const nextStatus = currentStatus === "published" ? "Draft" : "Published";

    showConfirmation(
      nextStatus === "Published" ? "Publish Tournament?" : "Unpublish Tournament?",
      nextStatus === "Published"
        ? "This changes the tournament status in your local demo records. It does not publish the tournament to the Player App."
        : "This will change the tournament back to Draft in your local demo records.",
      function () {
        const refreshed = getTournaments();
        const idx = refreshed.findIndex(function (item) {
          return String(item.id) === String(currentTournamentId);
        });

        if (idx === -1) return;

        refreshed[idx].status = nextStatus;

        if (saveJSON(TOURNAMENT_KEY, refreshed)) {
          loadTournamentOptions();
          toast("Tournament status changed to " + nextStatus + ".");
        }
      }
    );
  }

  function handlePlayerAction(event) {
    const button = event.target.closest("button[data-action]");
    if (!button) return;

    const action = button.dataset.action;
    const id = button.dataset.id;

    const registrations = getArray(REGISTRATION_KEY);
    const index = registrations.findIndex(function (item) {
      return String(item.id) === String(id);
    });

    if (index === -1) {
      toast("Registration record not found.");
      return;
    }

    if (getTournamentId(registrations[index]) !== String(currentTournamentId)) {
      toast("Registration belongs to another tournament.");
      return;
    }

    registrations[index].status = action === "approve" ? "Approved" : "Rejected";

    if (saveJSON(REGISTRATION_KEY, registrations)) {
      renderTournament();
      toast("Player " + (action === "approve" ? "approved." : "rejected."));
    }
  }

  function getAnnouncements() {
    const all = getArray(ANNOUNCEMENT_KEY);

    return all.filter(function (item) {
      return String(item.tournamentId) === String(currentTournamentId);
    }).sort(function (a, b) {
      return Number(b.createdAt || 0) - Number(a.createdAt || 0);
    });
  }

  function renderAnnouncements() {
    const list = $("announcementsList");
    list.innerHTML = "";

    getAnnouncements().forEach(function (announcement) {
      const card = document.createElement("article");
      card.className = "td-announcement-card";

      const top = document.createElement("div");
      top.className = "td-announcement-top";

      const title = document.createElement("h4");
      title.textContent = announcement.title || "Announcement";

      const remove = document.createElement("button");
      remove.className = "td-announcement-delete";
      remove.textContent = "Delete";
      remove.dataset.announcementId = String(announcement.id);

      top.append(title, remove);

      const message = document.createElement("p");
      message.textContent = announcement.message || "";

      const date = document.createElement("small");
      date.textContent = new Date(
        announcement.createdAt || Date.now()
      ).toLocaleString("en-IN");

      card.append(top, message, date);
      list.appendChild(card);
    });
  }

  function saveAnnouncement(event) {
    event.preventDefault();

    const title = safeString($("announcementTitle").value);
    const message = safeString($("announcementMessage").value);

    if (!title || !message) {
      toast("Enter an announcement title and message.");
      return;
    }

    const announcements = getArray(ANNOUNCEMENT_KEY);

    announcements.push({
      id: "ann_" + Date.now() + "_" + Math.random().toString(36).slice(2, 7),
      tournamentId: String(currentTournamentId),
      title: title,
      message: message,
      createdAt: Date.now()
    });

    if (saveJSON(ANNOUNCEMENT_KEY, announcements)) {
      $("announcementForm").reset();
      $("announcementCharCount").textContent = "0 / 1000";
      renderAnnouncements();
      toast("Announcement saved locally.");
    }
  }

  function deleteAnnouncement(event) {
    const button = event.target.closest("[data-announcement-id]");
    if (!button) return;

    const id = button.dataset.announcementId;

    showConfirmation(
      "Delete Announcement?",
      "This removes the announcement from local demo storage.",
      function () {
        const announcements = getArray(ANNOUNCEMENT_KEY).filter(function (item) {
          return String(item.id) !== String(id);
        });

        if (saveJSON(ANNOUNCEMENT_KEY, announcements)) {
          renderAnnouncements();
          toast("Announcement deleted.");
        }
      }
    );
  }

  function getResults() {
    const all = readJSON(RESULTS_KEY, {});
    return all[String(currentTournamentId)] || null;
  }

  function renderResults() {
    const result = getResults();

    $("resultDisplay").hidden = !result;

    if (!result) {
      $("winnerName").value = "";
      $("resultNotes").value = "";
      return;
    }

    $("winnerName").value = result.winner || "";
    $("resultNotes").value = result.notes || "";

    $("savedWinner").textContent = result.winner || "Not specified";
    $("savedResultNotes").textContent = result.notes || "No additional notes.";
  }

  function saveResults(event) {
    event.preventDefault();

    const winner = safeString($("winnerName").value);
    const notes = safeString($("resultNotes").value);

    if (!winner) {
      toast("Enter a winner name first.");
      return;
    }

    const results = readJSON(RESULTS_KEY, {});

    results[String(currentTournamentId)] = {
      tournamentId: String(currentTournamentId),
      winner: winner,
      notes: notes,
      updatedAt: Date.now()
    };

    if (saveJSON(RESULTS_KEY, results)) {
      $("savedWinner").textContent = winner;
      $("savedResultNotes").textContent = notes || "No additional notes.";
      $("resultDisplay").hidden = false;
      toast("Demo results saved.");
    }
  }

  function showConfirmation(title, message, callback) {
    pendingConfirmation = callback;

    $("confirmTitle").textContent = title;
    $("confirmMessage").textContent = message;

    openModal("confirmModal");
  }

  function closeConfirmation() {
    pendingConfirmation = null;
    closeModal("confirmModal");
  }

  function acceptConfirmation() {
    const callback = pendingConfirmation;
    pendingConfirmation = null;
    closeModal("confirmModal");

    if (typeof callback === "function") {
      callback();
    }
  }

  function deleteTournament() {
    const tournament = getCurrentTournament();
    if (!tournament) return;

    showConfirmation(
      "Delete Tournament?",
      'Delete "' + tournament.name + '" from your local tournament records? This cannot be undone here.',
      function () {
        const tournaments = getTournaments().filter(function (item) {
          return String(item.id) !== String(currentTournamentId);
        });

        if (!saveJSON(TOURNAMENT_KEY, tournaments)) return;

        const rooms = readJSON(ROOM_KEY, {});
        delete rooms[String(currentTournamentId)];
        saveJSON(ROOM_KEY, rooms);

        const announcements = getArray(ANNOUNCEMENT_KEY).filter(function (item) {
          return String(item.tournamentId) !== String(currentTournamentId);
        });
        saveJSON(ANNOUNCEMENT_KEY, announcements);

        const results = readJSON(RESULTS_KEY, {});
        delete results[String(currentTournamentId)];
        saveJSON(RESULTS_KEY, results);

        currentTournamentId = null;

        loadTournamentOptions();
        toast("Tournament deleted from local demo records.");
      }
    );
  }

  function connectEvents() {
    $("backBtn").addEventListener("click", function () {
      if (window.history.length > 1) {
        window.history.back();
      } else {
        window.location.href = "tournaments.html";
      }
    });

    $("refreshBtn").addEventListener("click", function () {
      loadTournamentOptions();
      toast("Tournament data refreshed.");
    });

    $("tournamentSelect").addEventListener("change", function () {
      currentTournamentId = this.value || null;

      if (!currentTournamentId) {
        $("tournamentContent").hidden = true;
        $("emptyState").hidden = false;
        return;
      }

      $("tournamentContent").hidden = false;
      $("emptyState").hidden = true;
      renderAll();
    });

    $("createTournamentBtn").addEventListener("click", function () {
      window.location.href = "create.html";
    });

    $("editTournamentBtn").addEventListener("click", loadEditForm);
    $("publishBtn").addEventListener("click", togglePublish);

    $("closeEditModal").addEventListener("click", function () {
      closeModal("editModal");
    });

    $("cancelEditModal").addEventListener("click", function () {
      closeModal("editModal");
    });

    $("editForm").addEventListener("submit", saveEditedTournament);

    $("roomForm").addEventListener("submit", saveRoomDetails);
    $("clearRoomBtn").addEventListener("click", clearRoomDetails);

    $("togglePassword").addEventListener("click", function () {
      const input = $("roomPassword");
      const isPassword = input.type === "password";

      input.type = isPassword ? "text" : "password";
      this.textContent = isPassword ? "Hide" : "Show";
    });

    $("playerSearch").addEventListener("input", renderPlayers);
    $("playerFilter").addEventListener("change", renderPlayers);
    $("playersList").addEventListener("click", handlePlayerAction);

    $("announcementForm").addEventListener("submit", saveAnnouncement);
    $("announcementsList").addEventListener("click", deleteAnnouncement);

    $("announcementMessage").addEventListener("input", function () {
      $("announcementCharCount").textContent =
        this.value.length + " / 1000";
    });

    $("resultsForm").addEventListener("submit", saveResults);
    $("deleteTournamentBtn").addEventListener("click", deleteTournament);

    $("closeConfirmModal").addEventListener("click", closeConfirmation);
    $("cancelConfirm").addEventListener("click", closeConfirmation);
    $("acceptConfirm").addEventListener("click", acceptConfirmation);

    document.querySelectorAll(".td-modal-backdrop").forEach(function (modal) {
      modal.addEventListener("click", function (event) {
        if (event.target === modal) {
          if (modal.id === "confirmModal") {
            closeConfirmation();
          } else {
            closeModal(modal.id);
          }
        }
      });
    });

    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape") {
        document.querySelectorAll(".td-modal-backdrop:not([hidden])")
          .forEach(function (modal) {
            if (modal.id === "confirmModal") {
              closeConfirmation();
            } else {
              closeModal(modal.id);
            }
          });
      }
    });

    window.addEventListener("storage", function (event) {
      if (
        event.key === TOURNAMENT_KEY ||
        event.key === REGISTRATION_KEY
      ) {
        loadTournamentOptions();
      }
    });
  }

  function init() {
    connectEvents();
    loadTournamentOptions();
  }

  document.addEventListener("DOMContentLoaded", init);
})();