import { auth, db } from "./firebase-config.js";

import { onAuthStateChanged } from
  "https://www.gstatic.com/firebasejs/13.0.0/firebase-auth.js";

import {
  collection,
  query,
  where,
  getDocs,
  doc,
  getDoc,
  updateDoc,
  deleteDoc,
  addDoc,
  setDoc,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/13.0.0/firebase-firestore.js";

"use strict";

let currentUser = null;

  const ROOM_COLLECTION = "tournamentRooms";
const ANNOUNCEMENT_COLLECTION = "tournamentAnnouncements";
const RESULTS_COLLECTION = "tournamentResults";
const REGISTRATION_COLLECTION = "registrations";

let tournamentRegistrations = [];
let tournamentAnnouncements = [];
let tournamentRoom = null;
let tournamentResult = null;

  const $ = (id) => document.getElementById(id);

  let currentTournamentId = null;
  let pendingConfirmation = null;

  function readJSON(key, fallback) {
    try {
      const value = localStorage.getItem(key);
      return value ? JSON.parse(value) : fallback;
    } catch (error) {
      return fallback;
    }
  }

  function saveJSON(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (error) {
      toast("Unable to save. Device storage may be full.");
      return false;
    }
  }

  function getArray(key) {
    const value = readJSON(key, []);
    return Array.isArray(value) ? value : [];
  }

  function safeString(value) {
    return String(value ?? "").trim();
  }

  function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, function (char) {
      return {
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
      }[char];
    });
  }

  function toast(message) {
    const el = $("toast");
    if (!el) return;

    el.textContent = message;
    el.classList.add("show");

    clearTimeout(toast.timer);

    toast.timer = setTimeout(function () {
      el.classList.remove("show");
    }, 2400);
  }

  function openModal(id) {
    const modal = $(id);
    if (!modal) return;

    modal.hidden = false;
    document.body.style.overflow = "hidden";
  }

  function closeModal(id) {
    const modal = $(id);
    if (!modal) return;

    modal.hidden = true;

    if (!document.querySelector(".td-modal-backdrop:not([hidden])")) {
      document.body.style.overflow = "";
    }
  }

  async function getTournaments() {
  if (!currentUser) return [];

  try {
    const tournamentsQuery = query(
      collection(db, "tournaments"),
      where("hostId", "==", currentUser.uid)
    );

    const snapshot = await getDocs(tournamentsQuery);

    return snapshot.docs.map(item => ({
      id: item.id,
      ...item.data()
    }));

  } catch (error) {
    console.error("Firebase tournaments load error:", error);
    toast("Unable to load tournaments from Firebase.");
    return [];
  }
}

  let currentTournament = null;

function getCurrentTournament() {
  return currentTournament;
}

  function getTournamentId(item) {
    return String(
      item.tournamentId ??
      item.tournament_id ??
      item.tournament ??
      ""
    );
  }

  function getTournamentRegistrations() {
    const registrations = getArray(REGISTRATION_KEY);

    return registrations.filter(function (item) {
      return getTournamentId(item) === String(currentTournamentId);
    });
  }

  function normalizeStatus(status) {
    const value = safeString(status).toLowerCase();

    if (value === "approved" || value === "accepted") return "approved";
    if (value === "rejected" || value === "declined") return "rejected";

    return "pending";
  }

  function formatMoney(value) {
    const amount = Number(value || 0);

    if (!Number.isFinite(amount)) return "₹0";

    return "₹" + amount.toLocaleString("en-IN", {
      maximumFractionDigits: 2
    });
  }

  function formatDate(value) {
    if (!value) return "Not scheduled";

    const date = new Date(value + (String(value).length === 10 ? "T00:00:00" : ""));

    if (Number.isNaN(date.getTime())) return String(value);

    return date.toLocaleDateString("en-IN", {
      day: "numeric",
      month: "short",
      year: "numeric"
    });
  }

  function formatTime(value) {
    if (!value) return "Not scheduled";

    const match = String(value).match(/^(\d{1,2}):(\d{2})$/);

    if (!match) return String(value);

    let hour = Number(match[1]);
    const minute = match[2];
    const suffix = hour >= 12 ? "PM" : "AM";

    hour = hour % 12 || 12;

    return hour + ":" + minute + " " + suffix;
  }

  function getGameSymbol(game) {
    const value = safeString(game).toLowerCase();

    if (value.includes("bgmi")) return "BG";
    if (value.includes("free fire")) return "FF";
    if (value.includes("call of duty") || value.includes("cod")) return "CD";
    if (value.includes("scarfall")) return "SF";
    if (value.includes("stumble")) return "SG";

    return "AX";
  }

  async function loadTournamentOptions() {
  const select = $("tournamentSelect");
  if (!select || !currentUser) return;

  select.innerHTML = '<option value="">Loading tournaments...</option>';

  try {
    const tournaments = await getTournaments();

    select.innerHTML = "";

    if (!tournaments.length) {
      const option = document.createElement("option");
      option.value = "";
      option.textContent = "No tournaments available";
      select.appendChild(option);

      currentTournamentId = null;
      currentTournament = null;
      $("emptyState").hidden = false;
      $("tournamentContent").hidden = true;
      $("selectionHint").textContent = "No tournaments found in Firebase.";
      return;
    }

    tournaments.forEach(item => {
      const option = document.createElement("option");
      option.value = String(item.id);
      option.textContent = item.name || "Untitled Tournament";
      select.appendChild(option);
    });

    const requestedId =
      new URLSearchParams(window.location.search).get("id");

    const preferred =
      tournaments.find(item => String(item.id) === String(requestedId)) ||
      tournaments.find(item => String(item.id) === String(currentTournamentId)) ||
      tournaments[0];

    currentTournament = preferred;
    currentTournamentId = String(preferred.id);
    select.value = currentTournamentId;

    $("emptyState").hidden = true;
    $("tournamentContent").hidden = false;

    renderAll();

  } catch (error) {
    console.error("Load tournament options failed:", error);
    select.innerHTML = '<option value="">Could not load tournaments</option>';
    toast("Firebase se tournaments load nahi hue.");
  }
}

  function renderTournament() {
    const tournament = getCurrentTournament();
    if (!tournament) return;

    const status = safeString(tournament.status) || "Draft";

    $("gameBadge").textContent = tournament.game || "Game";
    $("gameSymbol").textContent = getGameSymbol(tournament.game);
    $("tournamentName").textContent = tournament.name || "Untitled Tournament";

    $("tournamentMode").textContent = [
      tournament.mode || "Mode not specified",
      tournament.format || "Format not specified"
    ].join(" · ");

    $("tournamentId").textContent = "Tournament ID: " + tournament.id;
    $("tournamentStatus").textContent = status.toUpperCase();

    $("tournamentStatus").className = "td-status";

    if (status.toLowerCase() === "published") {
      $("tournamentStatus").classList.add("status-published");
    } else if (status.toLowerCase() === "completed") {
      $("tournamentStatus").classList.add("status-completed");
    } else if (status.toLowerCase() === "cancelled") {
      $("tournamentStatus").classList.add("status-cancelled");
    }

    $("publishBtn").textContent =
      status.toLowerCase() === "published"
        ? "Unpublish Tournament"
        : "Publish Tournament";

    $("prizePool").textContent = formatMoney(tournament.prizePool);
    $("totalSlots").textContent = Number(tournament.slots || 0);

    const entryType = safeString(tournament.entryType).toLowerCase();
    $("entryFee").textContent =
      entryType === "paid"
        ? formatMoney(tournament.entryFee)
        : "FREE";

    $("matchDate").textContent = formatDate(tournament.date);
    $("matchTime").textContent = formatTime(tournament.time);
    $("matchMap").textContent = tournament.map || "Not specified";
    $("killReward").textContent = formatMoney(tournament.perKill);
    $("tournamentRules").textContent = tournament.rules || "No rules added yet.";

    const registrations = getTournamentRegistrations();

    $("registeredCount").textContent = registrations.length;

    $("selectionHint").textContent =
      status + " · " + registrations.length + " registration(s)";

    renderPlayers();
    loadRoomDetails();
    renderAnnouncements();
    renderResults();
  }

  function renderAll() {
    renderTournament();
  }

  function renderPlayers() {
    const registrations = getTournamentRegistrations();
    const search = safeString($("playerSearch").value).toLowerCase();
    const filter = $("playerFilter").value;

    const filtered = registrations.filter(function (item) {
      const nickname = safeString(
        item.nickname || item.playerName || item.username || item.name
      );

      const playerId = safeString(item.playerId || item.uid || item.id);

      const matchesSearch =
        nickname.toLowerCase().includes(search) ||
        playerId.toLowerCase().includes(search);

      const status = normalizeStatus(item.status);
      const matchesStatus = filter === "all" || status === filter;

      return matchesSearch && matchesStatus;
    });

    const approved = registrations.filter(function (item) {
      return normalizeStatus(item.status) === "approved";
    }).length;

    $("playerCountLabel").textContent =
      registrations.length + (registrations.length === 1 ? " player" : " players");

    $("approvedCountLabel").textContent = approved + " approved";

    const list = $("playersList");
    list.innerHTML = "";

    $("noPlayers").hidden = filtered.length !== 0;

    filtered.forEach(function (player) {
      const nickname = safeString(
        player.nickname || player.playerName || player.username || player.name
      ) || "Unnamed Player";

      const playerId = safeString(player.playerId || player.uid || player.id) || "No ID";
      const status = normalizeStatus(player.status);

      const card = document.createElement("article");
      card.className = "td-player-card";

      const avatar = document.createElement("div");
      avatar.className = "td-player-avatar";
      avatar.textContent = Array.from(nickname)[0]?.toUpperCase() || "P";

      const info = document.createElement("div");
      info.className = "td-player-info";

      const name = document.createElement("strong");
      name.textContent = nickname;

      const id = document.createElement("small");
      id.textContent = "Player ID: " + playerId;

      const badge = document.createElement("span");
      badge.className = "td-player-status " + status;
      badge.textContent = status;

      info.append(name, id, badge);

      const actions = document.createElement("div");
      actions.className = "td-player-actions";

      if (status !== "approved") {
        const approve = document.createElement("button");
        approve.className = "approve-player";
        approve.textContent = "Approve";
        approve.dataset.action = "approve";
        approve.dataset.id = String(player.id);

        actions.appendChild(approve);
      }

      if (status !== "rejected") {
        const reject = document.createElement("button");
        reject.className = "reject-player";
        reject.textContent = "Reject";
        reject.dataset.action = "reject";
        reject.dataset.id = String(player.id);

        actions.appendChild(reject);
      }

      card.append(avatar, info);

      if (actions.children.length) {
        card.appendChild(actions);
      }

      list.appendChild(card);
    });
  }

  async function loadRoomDetails() {
  if (!currentUser || !currentTournamentId) return;

  try {
    const roomRef = doc(
      db,
      ROOM_COLLECTION,
      String(currentTournamentId)
    );

    const roomSnap = await getDoc(roomRef);

    tournamentRoom = roomSnap.exists()
      ? roomSnap.data()
      : null;

    $("roomId").value = tournamentRoom?.roomId || "";
    $("roomPassword").value =
      tournamentRoom?.roomPassword || "";

    $("roomPassword").type = "password";
    $("togglePassword").textContent = "Show";

  } catch (error) {
    console.error("Room load error:", error);
    toast("Room details load nahi hue.");
  }
}

async function saveRoomDetails(event) {
  event.preventDefault();

  if (!currentUser || !currentTournamentId) {
    toast("Pehle tournament select kar.");
    return;
  }

  const roomId = safeString($("roomId").value);
  const roomPassword = safeString(
    $("roomPassword").value
  );

  try {
    await setDoc(
      doc(
        db,
        ROOM_COLLECTION,
        String(currentTournamentId)
      ),
      {
        tournamentId: String(currentTournamentId),
        hostId: currentUser.uid,
        roomId,
        roomPassword,
        updatedAt: serverTimestamp()
      },
      { merge: true }
    );

    tournamentRoom = { roomId, roomPassword };

    toast("Room details Firebase mein save ho gayi! ✅");

  } catch (error) {
    console.error("Room save error:", error);
    toast("Room save failed: " + error.message);
  }
}

async function clearRoomDetails() {
  if (!currentUser || !currentTournamentId) return;

  try {
    await deleteDoc(
      doc(
        db,
        ROOM_COLLECTION,
        String(currentTournamentId)
      )
    );

    tournamentRoom = null;

    $("roomId").value = "";
    $("roomPassword").value = "";

    toast("Room details Firebase se clear ho gayi.");

  } catch (error) {
    console.error("Room clear error:", error);
    toast("Room clear failed: " + error.message);
  }
}

  function loadEditForm() {
    const tournament = getCurrentTournament();
    if (!tournament) return;

    $("editName").value = tournament.name || "";
    $("editGame").value = tournament.game || "BGMI";
    $("editMode").value = tournament.mode || "";
    $("editFormat").value = tournament.format || "";
    $("editSlots").value = Number(tournament.slots || 1);
    $("editEntryType").value =
      String(tournament.entryType).toLowerCase() === "paid" ? "Paid" : "Free";
    $("editEntryFee").value = Number(tournament.entryFee || 0);
    $("editPrizePool").value = Number(tournament.prizePool || 0);
    $("editDate").value = tournament.date || "";
    $("editTime").value = tournament.time || "";
    $("editMap").value = tournament.map || "";
    $("editRules").value = tournament.rules || "";

    openModal("editModal");
  }

  async function saveEditedTournament(event) {
  event.preventDefault();

  const tournament = getCurrentTournament();

  if (!tournament || !currentUser) {
    toast("Tournament ya login session nahi mila.");
    return;
  }

  const entryType = $("editEntryType").value;
  const entryFee = entryType === "Paid"
    ? Number($("editEntryFee").value || 0)
    : 0;

  const updated = {
    name: safeString($("editName").value),
    game: $("editGame").value,
    mode: safeString($("editMode").value),
    format: safeString($("editFormat").value),
    slots: Number($("editSlots").value),
    entryType,
    entryFee,
    prizePool: Number($("editPrizePool").value || 0),
    date: $("editDate").value,
    time: $("editTime").value,
    map: safeString($("editMap").value),
    rules: safeString($("editRules").value),
    updatedAt: serverTimestamp()
  };

  if (!updated.name) {
    toast("Tournament name required hai.");
    return;
  }

  if (!Number.isFinite(updated.slots) || updated.slots < 1) {
    toast("Valid slots enter kar.");
    return;
  }

  if (
    !Number.isFinite(updated.entryFee) ||
    updated.entryFee < 0 ||
    !Number.isFinite(updated.prizePool) ||
    updated.prizePool < 0
  ) {
    toast("Entry fee ya prize pool valid nahi hai.");
    return;
  }

  try {
    await updateDoc(
      doc(db, "tournaments", String(currentTournamentId)),
      updated
    );

    Object.assign(tournament, updated);
    closeModal("editModal");
    await loadTournamentOptions();

    toast("Tournament Firebase mein update ho gaya! ✅");
  } catch (error) {
    console.error("Tournament update error:", error);
    toast("Update failed: " + error.message);
  }
}

async function togglePublish() {
  const tournament = getCurrentTournament();

  if (!tournament || !currentUser) {
    toast("Tournament ya login session nahi mila.");
    return;
  }

  const currentStatus = String(tournament.status || "draft").toLowerCase();

  if (currentStatus === "completed" || currentStatus === "cancelled") {
    toast("Completed ya cancelled tournament publish nahi ho sakta.");
    return;
  }

  const isPublished =
    currentStatus === "published" || tournament.published === true;

  const nextStatus = isPublished ? "draft" : "published";
  const nextPublished = !isPublished;

  showConfirmation(
    isPublished ? "Unpublish Tournament?" : "Publish Tournament?",
    isPublished
      ? "Tournament ko Draft mein wapas karna hai?"
      : "Tournament ko Player App par publish karna hai?",
    async function () {
      try {
        await updateDoc(
          doc(db, "tournaments", String(currentTournamentId)),
          {
            status: nextStatus,
            published: nextPublished,
            updatedAt: serverTimestamp()
          }
        );

        tournament.status = nextStatus;
        tournament.published = nextPublished;

        await loadTournamentOptions();

        toast(
          nextPublished
            ? "Tournament published! ✅"
            : "Tournament unpublished."
        );
      } catch (error) {
        console.error("Publish error:", error);
        toast("Publish failed: " + error.message);
      }
    }
  );
}

  function handlePlayerAction(event) {
    const button = event.target.closest("button[data-action]");
    if (!button) return;

    const action = button.dataset.action;
    const id = button.dataset.id;

    const registrations = getArray(REGISTRATION_KEY);
    const index = registrations.findIndex(function (item) {
      return String(item.id) === String(id);
    });

    if (index === -1) {
      toast("Registration record not found.");
      return;
    }

    if (getTournamentId(registrations[index]) !== String(currentTournamentId)) {
      toast("Registration belongs to another tournament.");
      return;
    }

    registrations[index].status = action === "approve" ? "Approved" : "Rejected";

    if (saveJSON(REGISTRATION_KEY, registrations)) {
      renderTournament();
      toast("Player " + (action === "approve" ? "approved." : "rejected."));
    }
  }

  async function getAnnouncements() {
  if (!currentUser || !currentTournamentId) return [];

  try {
    const announcementsQuery = query(
      collection(db, ANNOUNCEMENT_COLLECTION),
      where(
        "tournamentId",
        "==",
        String(currentTournamentId)
      )
    );

    const snapshot = await getDocs(announcementsQuery);

    tournamentAnnouncements = snapshot.docs
      .map(item => ({
        id: item.id,
        ...item.data()
      }))
      .sort((a, b) => {
        const timeA = a.createdAt?.toMillis?.() || 0;
        const timeB = b.createdAt?.toMillis?.() || 0;
        return timeB - timeA;
      });

    return tournamentAnnouncements;

  } catch (error) {
    console.error("Announcements load error:", error);
    toast("Announcements load nahi hue.");
    return [];
  }
}

async function renderAnnouncements() {
  const list = $("announcementsList");
  list.innerHTML = "";

  const announcements = await getAnnouncements();

  announcements.forEach(announcement => {
    const card = document.createElement("article");
    card.className = "td-announcement-card";

    const top = document.createElement("div");
    top.className = "td-announcement-top";

    const title = document.createElement("h4");
    title.textContent = announcement.title || "Announcement";

    const remove = document.createElement("button");
    remove.className = "td-announcement-delete";
    remove.textContent = "Delete";
    remove.dataset.announcementId = announcement.id;

    top.append(title, remove);

    const message = document.createElement("p");
    message.textContent = announcement.message || "";

    const date = document.createElement("small");

    const created = announcement.createdAt?.toDate?.();

    date.textContent = created
      ? created.toLocaleString("en-IN")
      : "Recently added";

    card.append(top, message, date);
    list.appendChild(card);
  });
}

async function saveAnnouncement(event) {
  event.preventDefault();

  if (!currentUser || !currentTournamentId) {
    toast("Pehle tournament select kar.");
    return;
  }

  const title = safeString($("announcementTitle").value);
  const message = safeString(
    $("announcementMessage").value
  );

  if (!title || !message) {
    toast("Announcement title aur message daal.");
    return;
  }

  try {
    await addDoc(
      collection(db, ANNOUNCEMENT_COLLECTION),
      {
        tournamentId: String(currentTournamentId),
        hostId: currentUser.uid,
        title,
        message,
        createdAt: serverTimestamp()
      }
    );

    $("announcementForm").reset();
    $("announcementCharCount").textContent = "0 / 1000";

    await renderAnnouncements();

    toast("Announcement Firebase mein save ho gayi! ✅");

  } catch (error) {
    console.error("Announcement save error:", error);
    toast("Announcement save failed: " + error.message);
  }
}

function deleteAnnouncement(event) {
  const button = event.target.closest(
    "[data-announcement-id]"
  );

  if (!button) return;

  const announcementId = button.dataset.announcementId;

  showConfirmation(
    "Delete Announcement?",
    "Kya tu is announcement ko delete karna chahta hai?",
    async function () {
      try {
        await deleteDoc(
          doc(
            db,
            ANNOUNCEMENT_COLLECTION,
            announcementId
          )
        );

        await renderAnnouncements();
        toast("Announcement delete ho gayi.");

      } catch (error) {
        console.error("Announcement delete error:", error);
        toast("Delete failed: " + error.message);
      }
    }
  );
}

  async function getResults() {
  if (!currentUser || !currentTournamentId) return null;

  try {
    const resultRef = doc(
      db,
      RESULTS_COLLECTION,
      String(currentTournamentId)
    );

    const resultSnap = await getDoc(resultRef);

    tournamentResult = resultSnap.exists()
      ? resultSnap.data()
      : null;

    return tournamentResult;

  } catch (error) {
    console.error("Results load error:", error);
    toast("Results load nahi hue.");
    return null;
  }
}

async function renderResults() {
  const result = await getResults();

  $("resultDisplay").hidden = !result;

  if (!result) {
    $("winnerName").value = "";
    $("resultNotes").value = "";
    $("savedWinner").textContent = "";
    $("savedResultNotes").textContent = "";
    return;
  }

  $("winnerName").value = result.winner || "";
  $("resultNotes").value = result.notes || "";

  $("savedWinner").textContent =
    result.winner || "Not specified";

  $("savedResultNotes").textContent =
    result.notes || "No additional notes.";
}

async function saveResults(event) {
  event.preventDefault();

  if (!currentUser || !currentTournamentId) {
    toast("Pehle tournament select kar.");
    return;
  }

  const winner = safeString($("winnerName").value);
  const notes = safeString($("resultNotes").value);

  if (!winner) {
    toast("Winner ka naam enter kar.");
    return;
  }

  try {
    await setDoc(
      doc(
        db,
        RESULTS_COLLECTION,
        String(currentTournamentId)
      ),
      {
        tournamentId: String(currentTournamentId),
        hostId: currentUser.uid,
        winner,
        notes,
        updatedAt: serverTimestamp()
      },
      { merge: true }
    );

    $("savedWinner").textContent = winner;
    $("savedResultNotes").textContent =
      notes || "No additional notes.";

    $("resultDisplay").hidden = false;

    toast("Results Firebase mein save ho gaye! 🏆");

  } catch (error) {
    console.error("Results save error:", error);
    toast("Results save failed: " + error.message);
  }
}

  function showConfirmation(title, message, callback) {
    pendingConfirmation = callback;

    $("confirmTitle").textContent = title;
    $("confirmMessage").textContent = message;

    openModal("confirmModal");
  }

  function closeConfirmation() {
    pendingConfirmation = null;
    closeModal("confirmModal");
  }

  function acceptConfirmation() {
    const callback = pendingConfirmation;
    pendingConfirmation = null;
    closeModal("confirmModal");

    if (typeof callback === "function") {
      callback();
    }
  }

function deleteTournament() {
  const tournament = getCurrentTournament();

  if (!tournament || !currentUser) {
    toast("Tournament ya login session nahi mila.");
    return;
  }

  showConfirmation(
    "Delete Tournament?",
    "Kya tu is tournament ko permanently delete karna chahta hai? Ye action undo nahi hoga.",
    async function () {
      try {
        await deleteDoc(
          doc(db, "tournaments", String(currentTournamentId))
        );

        currentTournament = null;
        currentTournamentId = null;

        closeModal("deleteModal");
        await loadTournamentOptions();

        toast("Tournament Firebase se delete ho gaya! ✅");
      } catch (error) {
        console.error("Delete tournament error:", error);
        toast("Delete failed: " + error.message);
      }
    }
  );
}

  function connectEvents() {
    $("backBtn").addEventListener("click", function () {
      if (window.history.length > 1) {
        window.history.back();
      } else {
        window.location.href = "tournaments.html";
      }
    });

    $("refreshBtn").addEventListener("click", function () {
      loadTournamentOptions();
      toast("Tournament data refreshed.");
    });

    $("tournamentSelect").addEventListener("change", function () {
      currentTournamentId = this.value || null;

      if (!currentTournamentId) {
        $("tournamentContent").hidden = true;
        $("emptyState").hidden = false;
        return;
      }

      $("tournamentContent").hidden = false;
      $("emptyState").hidden = true;
      renderAll();
    });

    $("createTournamentBtn").addEventListener("click", function () {
      window.location.href = "create.html";
    });

    $("editTournamentBtn").addEventListener("click", loadEditForm);
    $("publishBtn").addEventListener("click", togglePublish);

    $("closeEditModal").addEventListener("click", function () {
      closeModal("editModal");
    });

    $("cancelEditModal").addEventListener("click", function () {
      closeModal("editModal");
    });

    $("editForm").addEventListener("submit", saveEditedTournament);

    $("roomForm").addEventListener("submit", saveRoomDetails);
    $("clearRoomBtn").addEventListener("click", clearRoomDetails);

    $("togglePassword").addEventListener("click", function () {
      const input = $("roomPassword");
      const isPassword = input.type === "password";

      input.type = isPassword ? "text" : "password";
      this.textContent = isPassword ? "Hide" : "Show";
    });

    $("playerSearch").addEventListener("input", renderPlayers);
    $("playerFilter").addEventListener("change", renderPlayers);
    $("playersList").addEventListener("click", handlePlayerAction);

    $("announcementForm").addEventListener("submit", saveAnnouncement);
    $("announcementsList").addEventListener("click", deleteAnnouncement);

    $("announcementMessage").addEventListener("input", function () {
      $("announcementCharCount").textContent =
        this.value.length + " / 1000";
    });

    $("resultsForm").addEventListener("submit", saveResults);
    $("deleteTournamentBtn").addEventListener("click", deleteTournament);

    $("closeConfirmModal").addEventListener("click", closeConfirmation);
    $("cancelConfirm").addEventListener("click", closeConfirmation);
    $("acceptConfirm").addEventListener("click", acceptConfirmation);

    document.querySelectorAll(".td-modal-backdrop").forEach(function (modal) {
      modal.addEventListener("click", function (event) {
        if (event.target === modal) {
          if (modal.id === "confirmModal") {
            closeConfirmation();
          } else {
            closeModal(modal.id);
          }
        }
      });
    });

    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape") {
        document.querySelectorAll(".td-modal-backdrop:not([hidden])")
          .forEach(function (modal) {
            if (modal.id === "confirmModal") {
              closeConfirmation();
            } else {
              closeModal(modal.id);
            }
          });
      }
    });

    window.addEventListener("storage", function (event) {
      if (
        event.key === TOURNAMENT_KEY ||
        event.key === REGISTRATION_KEY
      ) {
        loadTournamentOptions();
      }
    });
  }

  function init() {
  connectEvents();

  onAuthStateChanged(auth, async (user) => {
    if (!user) {
      currentUser = null;

      $("emptyState").hidden = false;
      $("tournamentContent").hidden = true;
      $("selectionHint").textContent = "Please login to continue.";

      toast("Please login to your Host account.");
      return;
    }

    currentUser = user;
    await loadTournamentOptions();
  });
}

document.addEventListener("DOMContentLoaded", init);
