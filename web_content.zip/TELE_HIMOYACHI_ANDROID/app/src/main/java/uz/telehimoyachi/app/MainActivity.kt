package uz.telehimoyachi.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStream
import java.security.MessageDigest

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView

    private val chooseFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            Thread {
                val result = inspectFile(uri)
                runOnUiThread {
                    web.evaluateJavascript("window.onNativeFileResult(${JSONObject.quote(result.toString())})", null)
                }
            }.start()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(Bridge(), "TeleHimoyachi")
        web.loadUrl("file:///android_asset/index.html")
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
        }
    }

    inner class Bridge {
        @JavascriptInterface fun getInstalledApps(): String {
            val out = JSONArray()
            val pm = packageManager
            val apps = if (Build.VERSION.SDK_INT >= 33) {
                pm.getInstalledPackages(PackageManager.PackageInfoFlags.of(
                    (PackageManager.GET_PERMISSIONS or PackageManager.GET_META_DATA).toLong()
                ))
            } else {
                @Suppress("DEPRECATION")
                pm.getInstalledPackages(PackageManager.GET_PERMISSIONS or PackageManager.GET_META_DATA)
            }
            for (p in apps.sortedBy { it.applicationInfo?.loadLabel(pm)?.toString()?.lowercase() ?: "" }) {
                val ai = p.applicationInfo ?: continue
                val item = JSONObject()
                item.put("name", ai.loadLabel(pm).toString())
                item.put("package", p.packageName)
                item.put("system", (ai.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0)
                item.put("source", try {
                    if (Build.VERSION.SDK_INT >= 30) pm.getInstallSourceInfo(p.packageName).installingPackageName ?: "Noma'lum"
                    else @Suppress("DEPRECATION") pm.getInstallerPackageName(p.packageName) ?: "Noma'lum"
                } catch (_: Exception) { "Noma'lum" })
                val perms = JSONArray()
                p.requestedPermissions?.forEach { perms.put(it) }
                item.put("permissions", perms)
                out.put(item)
            }
            return out.toString()
        }

        @JavascriptInterface fun openAppSettings() {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }

        @JavascriptInterface fun openSecuritySettings() {
            startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS))
        }

        @JavascriptInterface fun openUnknownSourcesSettings() {
            if (Build.VERSION.SDK_INT >= 26) {
                startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
            }
        }

        @JavascriptInterface fun openBatterySettings() {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }

        @JavascriptInterface fun requestBatteryExemption() {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (Build.VERSION.SDK_INT >= 23 && !pm.isIgnoringBatteryOptimizations(packageName)) {
                try {
                    startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:$packageName")))
                } catch (_: Exception) { openBatterySettings() }
            }
        }

        @JavascriptInterface fun chooseApk() {
            runOnUiThread { chooseFile.launch(arrayOf("application/vnd.android.package-archive", "*/*")) }
        }

        @JavascriptInterface fun startMonitoring() {
            val i = Intent(this@MainActivity, MonitorService::class.java)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        }

        @JavascriptInterface fun stopMonitoring() {
            stopService(Intent(this@MainActivity, MonitorService::class.java))
        }

        @JavascriptInterface fun deviceInfo(): String {
            val o = JSONObject()
            o.put("manufacturer", Build.MANUFACTURER)
            o.put("model", Build.MODEL)
            o.put("android", Build.VERSION.RELEASE)
            o.put("sdk", Build.VERSION.SDK_INT)
            o.put("securityPatch", Build.VERSION.SECURITY_PATCH)
            o.put("brand", Build.BRAND)
            return o.toString()
        }
    }

    private fun inspectFile(uri: Uri): JSONObject {
        val o = JSONObject()
        val name = queryDisplayName(uri)
        o.put("name", name)
        var sha = ""
        try {
            val md = MessageDigest.getInstance("SHA-256")
            contentResolver.openInputStream(uri)?.use { input ->
                val buf = ByteArray(8192)
                while (true) {
                    val n = input.read(buf)
                    if (n <= 0) break
                    md.update(buf, 0, n)
                }
            }
            sha = md.digest().joinToString("") { "%02x".format(it) }
        } catch (_: Exception) {}
        o.put("sha256", sha)
        val isApk = name.lowercase().endsWith(".apk")
        o.put("isApk", isApk)
        if (isApk) {
            try {
                val flags = if (Build.VERSION.SDK_INT >= 33)
                    PackageManager.PackageInfoFlags.of(PackageManager.GET_PERMISSIONS.toLong())
                else @Suppress("DEPRECATION") null
                val pi = if (Build.VERSION.SDK_INT >= 33) packageManager.getPackageArchiveInfo(uriPathForArchive(uri), flags!!)
                    else @Suppress("DEPRECATION") packageManager.getPackageArchiveInfo(uriPathForArchive(uri), PackageManager.GET_PERMISSIONS)
                o.put("apkPackage", pi?.packageName ?: JSONObject.NULL)
                o.put("apkVersion", pi?.versionName ?: JSONObject.NULL)
                val p = JSONArray()
                pi?.requestedPermissions?.forEach { p.put(it) }
                o.put("apkPermissions", p)
            } catch (_: Exception) { o.put("apkParse", "APK ma'lumotini o'qib bo'lmadi") }
        }
        o.put("verdict", "Tahlil ma'lumoti olindi; bu antivirus kafolati emas.")
        return o
    }

    private fun queryDisplayName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) return it.getString(0) ?: "file"
        }
        return uri.lastPathSegment ?: "file"
    }

    private fun uriPathForArchive(uri: Uri): String {
        // PackageManager needs a filesystem path; copy content URI to app cache first.
        val temp = java.io.File(cacheDir, "selected_scan.apk")
        contentResolver.openInputStream(uri).use { input ->
            temp.outputStream().use { output -> input?.copyTo(output) }
        }
        return temp.absolutePath
    }
}
