TELE HIMOYACHI — Android Studio loyiha manbasi

MUHIM
- Bu Android Studio uchun to'liq loyiha MANBASI. Bu zip ichida oldindan kompilyatsiya qilingan APK yo'q.
- APK olish uchun Android Studio'da loyihani ochib Build > Build APK(s) ni tanlang.
- Birinchi build uchun internet orqali Android Gradle Plugin/SDK yuklanishi kerak bo'lishi mumkin.
- compileSdk 36 uchun Android SDK Platform 36 o'rnatilgan bo'lishi kerak.

NIMALAR ISHLAYDI
1. Android PackageManager orqali o'rnatilgan paketlar ro'yxati, ilova nomi, tizim ilovasi belgisi, installer source va so'ralgan permissionlar.
2. Android SAF fayl tanlagichi orqali foydalanuvchi tanlagan faylni o'qish.
3. Tanlangan fayl uchun SHA-256 hisoblash.
4. APK faylning package name, version va requested permissions ma'lumotlarini olish (APK fayl tizim yo'li sifatida cache'ga nusxalanadi).
5. Qurilma modeli, Android versiyasi va xavfsizlik patch sanasini ko'rsatish.
6. Foydalanuvchi o'zi yoqadigan foreground monitoring xizmati va doimiy bildirishnoma.
7. Android Security, Unknown Sources va Battery settings sahifalarini ochish.

MUHIM CHEKLOVLAR
- Oddiy Android ilovasi boshqa ilovalar o'rnatilishini universal tarzda ushlab qololmaydi. Android Package Installer jarayonini uchinchi tomon ilovasi bloklay olmaydi. Bunday siyosat odatda Device Owner/MDM kabi maxsus boshqaruvda qo'llanadi.
- Foreground service cheksiz ishlash kafolati emas; Android/OEM uni cheklashi mumkin. Batareya optimizatsiyasini o'chirish ham kafolat bermaydi.
- Android 11+ da QUERY_ALL_PACKAGES ruxsati Google Play siyosati bo'yicha cheklangan. Play Store'ga chiqarishda package visibility deklaratsiyasi va asosli core use case talab qilinadi. Sinov/sideload APK sifatida o'rnatishda ham foydalanuvchi maxfiyligi va Android siyosatlariga rioya qiling.
- Bu loyiha antivirus emas: fayl xeshi va manifest ma'lumotlari zararli ekanini aniqlamaydi. Reputatsiya/virus bazasi yoki imzo tekshiruvi qo'shilishi kerak.
- Ilovalar avtomatik o'chirilmaydi. Foydalanuvchini Android App Info sahifasiga olib borib, o'zi qaror qilishiga imkon berish kerak.
- HTML/JS ko'prigi lokal asset bilan cheklangan; internet ruxsati yo'q.

QURISH
1. Android Studio (Giraffe yoki undan yangiroq) o'rnating.
2. ZIP'ni oching, Android Studio > Open > TELE_HIMOYACHI_ANDROID papkasini tanlang.
3. Gradle sync tugashini kuting.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK app/build/outputs/apk/debug/app-debug.apk manzilida hosil bo'ladi.

SINOV QURILMASI
Min SDK 26 (Android 8.0). Android 14 qurilmalarda ham ishlashga mo'ljallangan.
