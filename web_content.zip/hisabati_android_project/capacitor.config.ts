import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'ly.hisabati.app',
  appName: 'حساباتي',
  webDir: 'www',
  android: {
    backgroundColor: '#ffffff'
  }
};

export default config;
