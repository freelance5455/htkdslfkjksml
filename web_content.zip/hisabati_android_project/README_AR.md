# حساباتي - Android

هذا مشروع أولي لتحويل نسخة HTML الحالية إلى تطبيق Android باستخدام Capacitor.

## المتطلبات
- Node.js
- Android Studio
- Android SDK

## الأوامر
1. npm install
2. npx cap add android
3. npx cap sync android
4. npx cap open android

بعد فتح Android Studio:
- تأكد أن targetSdkVersion مناسب لمتطلبات Google Play الحالية.
- أنشئ نسخة Release.
- ارفع ملف AAB إلى Play Console.

## Package ID
ly.hisabati.app

## ملاحظة
هذه النسخة ما زالت تعتمد على التخزين المحلي داخل التطبيق. قبل بيعها على نطاق واسع، نحتاج إضافة قاعدة بيانات/نسخ احتياطي ومزامنة وحماية بيانات.
