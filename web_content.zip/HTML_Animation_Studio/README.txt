HTML Animation Studio — Xiaomi Pad 7

WHAT THIS IS
A responsive, installable web app (PWA) for loading an HTML animation, recording its largest canvas, and saving the recording.

IMPORTANT LIMITATION
This package is not an Android APK. It can be opened in Chrome on the Xiaomi Pad 7. If hosted on HTTPS, it can be installed from Chrome's menu using "Add to Home screen" / "Install app". Opening the file directly may disable PWA installation, but the main app can still work in many browsers.

MP4 SUPPORT
The app checks the browser's MediaRecorder support. If MP4 is not supported, Automatic mode records WebM. This is a browser/Android limitation, not a setting the app can override. Use Chrome and choose Automatic for best compatibility.

HOW TO USE
1. Extract the ZIP.
2. Open index.html in a modern browser or host the folder on HTTPS for PWA installation.
3. Choose an HTML file.
4. Set the recording length (for the supplied MyAction.html use 10.6 seconds).
5. Tap Record animation and then tap the preview to start the animation from the beginning.
6. Save video when recording finishes.

BEST RESULTS
- Use canvas-based HTML animations.
- Keep the app open and screen awake.
- Do not switch apps during recording.
- Check the preview first and set duration long enough for the full animation.
