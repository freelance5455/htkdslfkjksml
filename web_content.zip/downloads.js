// js/downloads.js
// Controla o limite diário de downloads de livros (5 por utilizador, por dia)
// e executa o download real do ficheiro (via blob, não apenas abrir num separador).

export const LIMITE_DOWNLOADS_DIARIO = 5;

function hojeStr() {
  const d = new Date();
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}

function nomeFicheiroSeguro(titulo) {
  const base = (titulo || 'livro').normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-zA-Z0-9 _-]/g, '').trim();
  return (base || 'livro') + '.pdf';
}

/**
 * @param {object} opts
 * @param {object} opts.db - instância Firestore
 * @param {object} opts.fns - { doc, getDoc, setDoc } importados de firebase-firestore.js
 * @param {string} opts.uid - uid do utilizador autenticado
 * @param {{titulo?:string, mediaUrl?:string}} opts.book
 * @param {(msg:string, type?:string)=>void} opts.showToast
 * @param {()=>void} [opts.onStart]
 * @param {()=>void} [opts.onEnd]
 * @returns {Promise<boolean>}
 */
export async function descarregarLivro({ db, fns, uid, book, showToast, onStart, onEnd }) {
  const { doc, getDoc, setDoc } = fns;

  if (!book || !book.mediaUrl) {
    showToast('Este livro ainda não tem ficheiro disponível para download.', 'error');
    return false;
  }

  try {
    const ref = doc(db, 'downloads', uid);
    const snap = await getDoc(ref);
    const hoje = hojeStr();
    let count = 0;
    if (snap.exists()) {
      const data = snap.data();
      count = data.date === hoje ? (data.count || 0) : 0;
    }

    if (count >= LIMITE_DOWNLOADS_DIARIO) {
      showToast(`Atingiste o limite de ${LIMITE_DOWNLOADS_DIARIO} downloads hoje. Volta amanhã.`, 'error');
      return false;
    }

    if (onStart) onStart();

    // Descarrega o ficheiro real (blob) para forçar o "guardar como", em vez de abrir no separador
    if (window.debugLog) window.debugLog('downloads.js: fetch', book.mediaUrl);
    const resp = await fetch(book.mediaUrl, { mode: 'cors' });
    if (window.debugLog) window.debugLog('downloads.js: status', String(resp.status));
    if (!resp.ok) throw new Error('Falha ao obter o ficheiro (' + resp.status + ')');
    const blob = await resp.blob();
    const blobUrl = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = blobUrl;
    a.download = nomeFicheiroSeguro(book.titulo);
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(blobUrl), 8000);

    // Só regista o consumo da quota depois de o download ter sido bem-sucedido
    await setDoc(ref, { uid, date: hoje, count: count + 1 });

    showToast(`Download iniciado! (${count + 1}/${LIMITE_DOWNLOADS_DIARIO} hoje)`);
    return true;
  } catch (e) {
    console.error('Erro ao descarregar livro:', e);
    if (window.debugLog) window.debugLog('downloads.js: erro', (e && e.message) || String(e));
    showToast('Não foi possível descarregar o livro agora. Tenta novamente.', 'error');
    return false;
  } finally {
    if (onEnd) onEnd();
  }
}
