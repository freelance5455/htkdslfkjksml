package com.samettuzun.vardiya;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;

/**
 * Her gün belirlenen saatte (varsayılan 20:00) SKT özeti bildirimi gösterir.
 * Ürün listesi sayfadan AndroidApp.scheduleSkt(json) ile gelir ve telefonda saklanır,
 * böylece uygulama kapalıyken de bildirim çıkar. Telefon yeniden başlayınca alarm yeniden kurulur.
 */
public class SktReceiver extends BroadcastReceiver {

    static final String PREFS = "skt";
    static final String CHANNEL = "skt_gunluk";
    static final String ACTION = "com.samettuzun.vardiya.SKT_HATIRLAT";

    @Override
    public void onReceive(Context ctx, Intent intent) {
        String a = intent.getAction();
        if (ACTION.equals(a)) {
            notifyNow(ctx);
        }
        schedule(ctx); // ertesi günü kur (açılışta ve yeniden başlatmada da)
    }

    static void save(Context ctx, String json) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("data", json).apply();
        schedule(ctx);
    }

    private static JSONObject data(Context ctx) {
        try {
            return new JSONObject(ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("data", "{}"));
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    static void schedule(Context ctx) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Intent i = new Intent(ctx, SktReceiver.class).setAction(ACTION);
        PendingIntent pi = PendingIntent.getBroadcast(ctx, 1, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        am.cancel(pi);

        JSONObject o = data(ctx);
        if (!o.optBoolean("on", false)) return;

        int h = 20, m = 0;
        try {
            String[] t = o.optString("time", "20:00").split(":");
            h = Integer.parseInt(t[0]);
            m = Integer.parseInt(t[1]);
        } catch (Exception ignored) { }

        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, h);
        c.set(Calendar.MINUTE, m);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        if (c.getTimeInMillis() <= System.currentTimeMillis() + 1000) {
            c.add(Calendar.DAY_OF_MONTH, 1);
        }
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), pi);
    }

    private static Calendar startOfToday() {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c;
    }

    static void notifyNow(Context ctx) {
        JSONObject o = data(ctx);
        JSONArray items = o.optJSONArray("items");
        if (items == null || items.length() == 0) return;
        int defWarn = o.optInt("defWarn", 7);
        long today = startOfToday().getTimeInMillis();

        int exp = 0, soon = 0;
        StringBuilder names = new StringBuilder();
        for (int k = 0; k < items.length(); k++) {
            JSONObject it = items.optJSONObject(k);
            if (it == null) continue;
            String[] p = it.optString("date", "").split("-");
            if (p.length != 3) continue;
            Calendar d = Calendar.getInstance();
            try {
                d.set(Integer.parseInt(p[0]), Integer.parseInt(p[1]) - 1, Integer.parseInt(p[2]), 0, 0, 0);
            } catch (Exception e) {
                continue;
            }
            d.set(Calendar.MILLISECOND, 0);
            long days = Math.round((d.getTimeInMillis() - today) / 86400000.0);
            int warn = it.isNull("warn") ? defWarn : it.optInt("warn", defWarn);
            if (days < 0) exp++;
            else if (days <= warn) soon++;
            else continue;
            if (names.length() < 250) {
                if (names.length() > 0) names.append(", ");
                names.append(it.optString("name", "Ürün"))
                     .append(days < 0 ? " (geçti)" : days == 0 ? " (bugün)" : " (" + days + " gün)");
            }
        }

        String title;
        String text;
        if (exp + soon == 0) {
            title = "SKT: bugün kontrol edilecek ürün yok";
            text = "Takipteki ürünlerin hepsi uyarı süresinin dışında.";
        } else {
            title = exp > 0 ? "SKT: " + exp + " ürün hâlâ raftan kaldırılmadı" : "SKT: " + (exp + soon) + " ürün kontrol bekliyor";
            text = (exp > 0 ? exp + " ürün kaldırılmayı bekliyor. " : "")
                 + (soon > 0 ? soon + " ürün yaklaşıyor. " : "")
                 + names;
        }

        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "SKT hatırlatma",
                    NotificationManager.IMPORTANCE_DEFAULT));
        }
        Intent open = new Intent(ctx, MainActivity.class)
                .putExtra("tab", "skt")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(ctx, 2, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(ctx, CHANNEL)
                : new Notification.Builder(ctx);
        b.setSmallIcon(R.mipmap.ic_launcher)
         .setContentTitle(title)
         .setContentText(text)
         .setStyle(new Notification.BigTextStyle().bigText(text))
         .setContentIntent(pi)
         .setAutoCancel(true);
        try {
            nm.notify(100, b.build());
        } catch (SecurityException ignored) {
            // Android 13+ bildirim izni verilmemiş
        }
    }
}
