package com.samettuzun.vardiya;

import android.app.Activity;
import android.graphics.Color;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.print.PrintManager;
import android.Manifest;
import android.content.pm.PackageManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

/**
 * Vardiya Planlayıcı: programın tamamı assets/index.html içinde.
 * Bu ekran onu tam ekran bir WebView'da açar. Planlar telefonda (localStorage) saklanır.
 * Samet Tüzün projesi.
 */
public class MainActivity extends Activity {

    private WebView webView;
    private PermissionRequest pendingRequest;
    private boolean openSkt = false;

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == 1 && pendingRequest != null) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
                pendingRequest.grant(pendingRequest.getResources());
            } else {
                pendingRequest.deny();
            }
            pendingRequest = null;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.parseColor("#1C6A47"));

        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);      // planların kaydı için gerekli
        s.setDatabaseEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);

        openSkt = "skt".equals(getIntent().getStringExtra("tab"));
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                if (openSkt) {
                    openSkt = false;
                    view.evaluateJavascript("window.__openSkt&&window.__openSkt()", null);
                }
            }
        });
        webView.setWebChromeClient(new WebChromeClient() { // "Emin misin?" pencereleri ve kamera izni
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        request.grant(request.getResources());
                    } else {
                        pendingRequest = request;
                        requestPermissions(new String[]{Manifest.permission.CAMERA}, 1);
                    }
                });
            }
        });
        webView.addJavascriptInterface(new AppBridge(), "AndroidApp");

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
        } else {
            webView.loadUrl("file:///android_asset/index.html");
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        webView.saveState(outState);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if ("skt".equals(intent.getStringExtra("tab"))) {
            webView.evaluateJavascript("window.__openSkt&&window.__openSkt()", null);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    /** Sayfadaki "Yazdır" düğmesi Android yazdırma / PDF'e kaydetme ekranını açar. */
    private class AppBridge {
        /** SKT listesini ve hatırlatma saatini alır, her gün bildirim kurar. */
        @JavascriptInterface
        public void scheduleSkt(String json) {
            SktReceiver.save(MainActivity.this, json);
            try {
                boolean on = new JSONObject(json).optBoolean("on", false);
                if (on && Build.VERSION.SDK_INT >= 33
                        && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                    runOnUiThread(() -> requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 2));
                }
            } catch (Exception ignored) { }
        }

        @JavascriptInterface
        public void print() {
            runOnUiThread(() -> {
                PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
                if (pm != null) {
                    pm.print("Vardiya", webView.createPrintDocumentAdapter("Vardiya"), null);
                }
            });
        }
    }
}
