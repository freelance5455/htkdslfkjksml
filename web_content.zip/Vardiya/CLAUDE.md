# Vardiya Planlayıcı (Android)

Market için haftalık vardiya planlayıcı. Samet Tüzün projesi.

## Yapı
- Programın tamamı tek dosya: `app/src/main/assets/index.html` (HTML + CSS + JS).
- `MainActivity.java` bu dosyayı tam ekran WebView'da açar. localStorage açık (planlar telefonda saklanır).
- "Yazdır" düğmesi `window.AndroidApp.print()` köprüsüyle Android yazdırma ekranını açar.
- Harici bağımlılık yok (AndroidX kullanılmıyor). AGP 8.5.2, Gradle 8.9, JDK 17, compileSdk 34, minSdk 24.

## APK derleme
- Yerelde (Android SDK kurulu olmalı, ANDROID_HOME ayarlı): `gradle assembleDebug`
  Çıktı: `app/build/outputs/apk/debug/app-debug.apk`
- Gradle wrapper yok; gerekirse `gradle wrapper --gradle-version 8.9` ile oluşturulabilir.
- GitHub'a gönderilince `.github/workflows/apk.yml` APK'yı otomatik derler (Actions → son çalışma → Artifacts → vardiya-apk).

## Güncelleme
- Program değişikliği için sadece `assets/index.html` değiştirilir, sonra `versionCode` bir artırılır.
- Kullanıcı verisi localStorage anahtarı `market-vardiya-v3` altında; bu anahtar değiştirilirse eski planlar kaybolur.

## SKT günlük bildirimi
- Sayfa `AndroidApp.scheduleSkt(json)` ile ürün listesini ve saati (varsayılan 20:00) gönderir.
- `SktReceiver` bunu SharedPreferences'a yazar, AlarmManager ile her gün o saatte bildirim gösterir, açılışta ve telefon yeniden başlayınca alarmı yeniden kurar.
- Android 13+ için POST_NOTIFICATIONS izni ilk kurulumda istenir. Bildirime dokununca uygulama SKT sekmesinde açılır.
