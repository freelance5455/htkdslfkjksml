@echo off
setlocal
cd /d "%~dp0"
set "GRADLE_VERSION=8.13"
set "TOOLS_ROOT=%LOCALAPPDATA%\TheHollowHouseBuildTools"
set "GRADLE_HOME=%TOOLS_ROOT%\gradle-%GRADLE_VERSION%"

rem Use Android Studio's bundled Java if JAVA_HOME is not already configured.
if not defined JAVA_HOME if exist "%ProgramFiles%\Android\Android Studio\jbr\bin\java.exe" set "JAVA_HOME=%ProgramFiles%\Android\Android Studio\jbr"
if not defined JAVA_HOME if exist "%ProgramFiles%\Android\Android Studio\jre\bin\java.exe" set "JAVA_HOME=%ProgramFiles%\Android\Android Studio\jre"
if not defined JAVA_HOME (
  echo Java was not found. Install Android Studio or JDK 17+, then run this file again.
  pause
  exit /b 1
)

rem Find the usual Android SDK location when ANDROID_HOME is not configured.
if not defined ANDROID_HOME if exist "%LOCALAPPDATA%\Android\Sdk" set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"
if not defined ANDROID_HOME (
  echo Android SDK not found. Install Android SDK 36 in Android Studio, then run this file again.
  pause
  exit /b 1
)

if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  echo Downloading Gradle %GRADLE_VERSION%...
  if not exist "%TOOLS_ROOT%" mkdir "%TOOLS_ROOT%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $zip=Join-Path $env:TEMP 'hollowhouse-gradle-%GRADLE_VERSION%-bin.zip'; Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile $zip; Expand-Archive -LiteralPath $zip -DestinationPath '%TOOLS_ROOT%' -Force; Remove-Item $zip -Force"
  if errorlevel 1 (
    echo Could not download Gradle. Check your internet connection and try again.
    pause
    exit /b 1
  )
)

call "%GRADLE_HOME%\bin\gradle.bat" assembleDebug
if errorlevel 1 (
  echo.
  echo Build failed. Open the HollowHouse folder in Android Studio and check the Gradle output.
  pause
  exit /b %errorlevel%
)
echo.
echo APK created at app\build\outputs\apk\debug\app-debug.apk
pause
