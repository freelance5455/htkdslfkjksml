# The Hollow House — Android Studio project

This folder contains the Android WebView wrapper. The complete game is bundled at `app/src/main/assets/www/index.html`.

- Landscape locked, immersive fullscreen.
- Android application ID: `com.fiflake.hollowtable`.
- Version: 3.0.0.
- Requires Android SDK 36 and JDK 17 or newer for the included build configuration.

Open this folder in Android Studio and build **Build → Build APK(s)**, or run `build-apk.bat` on Windows after installing Android Studio and Android SDK 36.

The online room feature loads PeerJS over HTTPS at runtime and uses WebRTC data connections. Local AI matches do not need an internet connection.
