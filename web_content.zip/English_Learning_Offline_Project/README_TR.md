# İngilizce Öğrenme — Web + Android APK başlangıç projesi

Bu proje, mevcut `English_Learning_Multilingual_fixed.html` uygulamanız temel alınarak hazırlanmıştır. Uygulama dört dil seçeneğini (Arapça, Türkçe, İngilizce, Fransızca) korur.

## Çevrimdışı davranış
- Web sürümü HTTPS üzerinden ilk kez açılıp Service Worker kurulduktan sonra uygulama kabuğunu önbelleğe alır.
- Uygulamanın `localStorage` ile sakladığı dil/ilerleme gibi yerel kayıtlar aynı tarayıcı/cihazda kalır.
- Kelime/ders ekranlarının çevrimdışı kullanılabilmesi için uygulamanın kendi HTML/CSS/JS içeriği yereldir.
- Google Fonts, uzaktaki fotoğraflar ve **Ask Araz AI** bağlantısı internet gerektirebilir. Tam çevrimdışı fotoğraflar için görsellerin projeye yerel olarak eklenmesi gerekir.

## Web sitesini test etme
Service Worker `file://` ile çalışmaz; HTTPS barındırma veya localhost gerekir. `www/` klasörünü HTTPS destekleyen statik bir siteye yükleyin.

## Android projesini oluşturma
Gereksinimler: Node.js LTS, Android Studio ve Android SDK.

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```

Android Studio'da Gradle senkronizasyonunu tamamlayın, ardından **Build > Build Bundle(s) / APK(s) > Build APK(s)** seçin. APK, Android Studio'nun gösterdiği `app/build/outputs/apk/` yolunda oluşur.

Bu paket kaynak proje ve yapılandırmadır; bu ortamda Android SDK/Gradle ile derleme yapılmadığından hazır APK içermez.

## Sonraki iyileştirme
Ask Araz AI düğmesi mevcut HTML'deki bağlantı olarak korunur; adres `https://arazai.lovable.app` olarak kontrol edilip ayarlanmalıdır. Tam çevrimdışı medya ve bütün ders/test metinlerinin dört dile eksiksiz çevrilmesi ayrı bir sonraki adımdır.
