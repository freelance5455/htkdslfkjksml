Biga Pizza Guide - installable Android app (PWA)

Put this folder on any free https web host, then install from Chrome on your phone:

1. Upload the unzipped folder to a static host, for example Netlify Drop (app.netlify.com/drop),
   GitHub Pages or Cloudflare Pages. You get an https link.
2. Open that link in Chrome on your Android phone.
3. Tap the three-dot menu, then Install app (or Add to Home screen).
   It then opens full screen from your home screen and works offline.

Want a real APK? Paste your https link into pwabuilder.com and download its Android package.

Your progress and timers are saved on the phone. Timers cannot ring while the app is closed.
