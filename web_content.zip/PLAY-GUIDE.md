# Publish 24 Life OS on Google Play

This package is the web app, store graphics and checklist. It is NOT an .aab/.apk file: that is built in step 2.
Works on the Samsung Galaxy M12 (Android 11 and newer) with Chrome installed and updated.

## 1. Host the app (free)
- Fill in your name and email in `web/privacy-policy.html` (search for "[YOUR").
- Upload the `web` folder to Netlify Drop (app.netlify.com/drop) or GitHub Pages. Keep hidden files (`.well-known`, `.nojekyll`, `_headers`).
- Your privacy policy URL is `https://YOUR-SITE/privacy-policy.html` (needed in Play Console).

## 2. Build the Play bundle
- Go to pwabuilder.com, paste your site URL, then Package for stores, Android, Google Play.
- Choose a permanent package ID (for example `com.yourname.lifeos`). It cannot change after publishing.
- Confirm the target API level is 36. Google Play requires new apps to target Android 16 (API 36) since 31 Aug 2026.
- Download the zip: it has the `.aab` (upload to Play), an `.apk` (test on your M12) and your signing key. Back up the key and its passwords somewhere safe.

## 3. Connect app and website (Digital Asset Links)
- Edit `web/.well-known/assetlinks.json`: put your package ID and the SHA-256 fingerprints (Play Console, Test and release, App integrity, App signing key; also add your upload key fingerprint).
- Redeploy, then open `https://YOUR-SITE/.well-known/assetlinks.json` to check it loads. Without this the app shows a browser address bar.

## 4. Play Console
- Create the app, then upload the `.aab` to Internal testing first and install it on your M12.
- Store listing: icon `play-store/store-icon-512.png`, feature graphic `play-store/feature-graphic-1024x500.png`, and at least 2 phone screenshots taken on your M12.
- App content: privacy policy URL, no ads, no login needed, content rating questionnaire, target audience adults, Data safety form (the app itself collects nothing; mention the Google Fonts request if asked). Complete the Health and Financial features declarations if the console shows them, and avoid medical or financial advice claims.
- New personal accounts created after 13 Nov 2023 must run a closed test with 12 testers opted in for 14 continuous days before applying for production. Organization accounts are exempt.

## Store listing text
Title: 24 Life OS: Habit Tracker
Short description: Track habits, fitness, money, career and goals in one beautiful daily view.
Full description:
24 Life OS puts your whole day on one screen. Tick off habits, log workouts, water and steps, track monthly income and expenses, count job applications and new skills, rate your mood and write a short note. A glowing ring shows your progress, and charts show 30-day trends and a 12-week consistency map.

Features:
- Custom daily habits with streaks and 30-day insights
- Fitness targets you set yourself
- Monthly money tracker with savings rate
- Career log for applications and skills
- Goals with due dates
- Works offline, no account, no ads
- Your data stays on your phone, with text backup and restore
