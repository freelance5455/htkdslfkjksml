-- GET MONEY MACHINE — persistent ledger, stations, payouts
create table if not exists gmm_stations (
  id serial primary key,
  user_id text not null,
  name text not null,
  sort_order integer not null,
  enabled boolean not null default true,
  active boolean not null default false,
  paused boolean not null default false,
  emergency_stopped boolean not null default false,
  last_activity timestamptz,
  last_scan_at timestamptz,
  cycle_started_at timestamptz,
  next_cycle_at timestamptz,
  cycle_count integer not null default 0,
  paused_remaining_seconds integer not null default 0,
  unique (user_id, name)
);
create index if not exists gmm_stations_user_idx on gmm_stations (user_id, sort_order);

create table if not exists gmm_ledger (
  id serial primary key,
  user_id text not null,
  kind text not null,
  station_id integer references gmm_stations(id),
  amount numeric(14,2) not null,
  status text not null,
  description text not null,
  provider_reference text,
  created_at timestamptz not null default now()
);
create index if not exists gmm_ledger_user_idx on gmm_ledger (user_id, created_at desc);

create table if not exists gmm_destinations (
  id serial primary key,
  user_id text not null,
  type text not null,
  label text not null,
  external_id text not null,
  enabled boolean not null default true,
  created_at timestamptz not null default now()
);
create index if not exists gmm_destinations_user_idx on gmm_destinations (user_id);

create table if not exists gmm_withdrawals (
  id serial primary key,
  user_id text not null,
  amount numeric(14,2) not null,
  destination_id integer not null references gmm_destinations(id),
  status text not null default 'PENDING',
  provider_reference text,
  idempotency_key text not null,
  error_message text,
  created_at timestamptz not null default now(),
  unique (user_id, idempotency_key)
);
create index if not exists gmm_withdrawals_user_idx on gmm_withdrawals (user_id, created_at desc);

create table if not exists gmm_audit (
  id serial primary key,
  user_id text not null,
  action text not null,
  detail text not null,
  created_at timestamptz not null default now()
);
create index if not exists gmm_audit_user_idx on gmm_audit (user_id, created_at desc);

create table if not exists gmm_opportunities (
  id serial primary key,
  user_id text not null,
  station_id integer not null references gmm_stations(id),
  title text not null,
  source_url text,
  estimated_value numeric(14,2),
  state text not null default 'DETECTED',
  verified_value numeric(14,2),
  evidence text,
  error_message text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists gmm_opportunities_user_idx on gmm_opportunities (user_id, created_at desc);

create table if not exists gmm_station_events (
  id serial primary key,
  user_id text not null,
  station_id integer not null references gmm_stations(id),
  event_type text not null,
  status text not null,
  detail text not null default '',
  created_at timestamptz not null default now()
);
create index if not exists gmm_station_events_idx on gmm_station_events (station_id, created_at desc);

create table if not exists gmm_connectors (
  id serial primary key,
  user_id text not null,
  station_id integer not null references gmm_stations(id),
  connector_type text not null default 'http_json',
  endpoint text,
  enabled boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (user_id, station_id)
);

create table if not exists gmm_notifications (
  id serial primary key,
  user_id text not null,
  kind text not null,
  title text not null,
  message text not null,
  read boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists gmm_notifications_user_idx on gmm_notifications (user_id, created_at desc);

create table if not exists gmm_provider_records (
  id serial primary key,
  user_id text not null,
  provider text not null,
  reference text not null,
  withdrawal_id integer references gmm_withdrawals(id),
  status text not null,
  raw_status text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists gmm_provider_ref_idx on gmm_provider_records (reference);

create table if not exists gmm_webhook_events (
  id serial primary key,
  provider text not null,
  event_id text not null unique,
  event_type text not null,
  processed boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists gmm_account_locks (
  id serial primary key,
  user_id text not null unique,
  name text not null default 'owner-financial-lock',
  created_at timestamptz not null default now()
);

create table if not exists gmm_revoked_tokens (
  token_jti text primary key,
  user_id text not null,
  expires_at timestamptz not null
);
