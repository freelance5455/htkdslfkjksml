GET MONEY MACHINE — BUILDER PACKAGE

SOURCE OF TRUTH
Use the included native Android project under /android. Do not replace it with a WebView, Kivy, demo, mockup, placeholder screen, or a different application.

ANDROID ENTRY POINT
android/app/src/main/java/com/getmoneymachine/MainActivity.kt
Manifest launcher: android/app/src/main/AndroidManifest.xml
Application ID: com.getmoneymachine

BUILD
cd android
./gradlew :app:assembleRelease -PAPI_URL=https://get-money-machine-api.onrender.com

The APK output is under android/app/build/outputs/apk/release/.
If the builder requires an installable test APK before release signing is configured, use:
./gradlew :app:assembleDebug -PAPI_URL=https://get-money-machine-api.onrender.com

IMPORTANT STARTUP FIX
The native app now has a production API fallback and a visible startup/loading/error state. It does not silently return an empty Compose screen while initialization is pending or fails.

ACCEPTANCE
1. Install the generated APK on a real Android device.
2. Launch it and verify GET MONEY MACHINE is visible immediately; a blank white screen is a failed build.
3. Verify the login screen appears and the app does not require a fake provider-confirmation screen.
4. Verify Free Money remains station #1 and all source stations are preserved.
5. Verify the dashboard, station controls, 90-minute cycle, Transfer Center, transactions, security/audit, notifications, and backend error handling.
6. Verify production PayPal credentials remain server-side and are never placed in the APK.

This package has been statically validated in this environment. A real Android SDK/Gradle build and device launch must still be performed by a networked Android build environment; this environment cannot download Gradle 8.9.
