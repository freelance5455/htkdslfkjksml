import { readFileSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';

const root = resolve(import.meta.dirname, '..');
const read = (p) => readFileSync(resolve(root, p), 'utf8');
const fail = (m) => { console.error(`GMM VALIDATION FAILED: ${m}`); process.exitCode = 1; };

const constants = read('src/lib/gmm/constants.ts');
const core = read('src/lib/gmm/core.ts');
const android = read('../app/src/main/java/com/getmoneymachine/MainActivity.kt');
const gradle = read('../app/build.gradle.kts');
const manifest = read('../app/src/main/AndroidManifest.xml');
const paypal = read('src/lib/gmm/paypal.ts');
const buildDocs = read('../BUILD_APK.md');

const stationNames = [...constants.matchAll(/"([^"]+Station|Free Money)"/g)].map((m) => m[1]);
const expected = [
  'Free Money',
  'Unclaimed Property Station',
  'Refund Recovery Station',
  'Rebate Station',
  'Cashback Station',
  'Rewards Station',
  'Promotional Bonus Station',
  'Fee Recovery Station',
  'Overpayment Recovery Station',
  'Subscription Credit Station',
  'Settlement & Claims Station',
  'Business Incentive Station',
  'Public Opportunity Station',
  'Revenue Opportunity Station',
  'Reinvestment Station',
  'Earnings & Transfer Station',
];
if (JSON.stringify(stationNames.slice(0, expected.length)) !== JSON.stringify(expected)) fail('station order/names do not match the preserved 16-station specification');
if (!core.includes("'Free Money'")) fail('Free Money preservation logic is missing');
if (!core.includes("'RESTORED_VERIFIED_EARNINGS', 60173.45, 'COMPLETED'")) fail('legacy $60,173.45 restoration is missing');
if (!core.includes('await runScan(sql, userId, stationId);')) fail('START does not trigger an immediate real scan');
if (!core.includes('CYCLE_MINUTES = 90') && !constants.includes('CYCLE_MINUTES = 90')) fail('90-minute cycle is missing');
if (!core.includes('fabricated_results: false')) fail('anti-fabrication invariant is missing');
if (!paypal.includes('https://api-m.paypal.com')) fail('PayPal live endpoint is missing');
if (paypal.includes('sandbox.paypal.com')) fail('PayPal sandbox endpoint remains in source');
if (!manifest.includes('android.permission.INTERNET')) fail('Android INTERNET permission is missing');
if (!gradle.includes('compileSdk=35') || !gradle.includes('minSdk=26') || !gradle.includes('targetSdk=35')) fail('Android SDK targets are incomplete');
if (!gradle.includes('com.android.application')) fail('Android application plugin is missing');
if (!existsSync(resolve(root, '../gradlew'))) fail('Gradle wrapper is missing');
if (!existsSync(resolve(root, '../gradle/wrapper/gradle-wrapper.properties'))) fail('Gradle wrapper properties are missing');
if (!buildDocs.includes('Free Money')) fail('APK handoff does not mention Free Money');
if (android.includes('15 stations') || android.includes('15 Stations')) fail('Android UI still claims 15 stations');
if (read('src/components/gmm-app.tsx').includes('15 Stations')) fail('web UI still claims 15 stations');

if (process.exitCode) process.exit();
console.log('GMM STATIC VALIDATION: PASS');
console.log(`Stations: ${expected.length} (Free Money preserved as #1)`);
console.log('Legacy available-funds restoration: $60,173.45 when ledger is empty');
console.log('START: immediate real scan');
console.log('Cycle: 90 minutes');
console.log('Fabricated earnings: disabled');
console.log('PayPal endpoint: production api-m.paypal.com');
console.log('Android: native Compose / SDK 35 / min 26 / target 35');
