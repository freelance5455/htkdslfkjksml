import { useCallback, useEffect, useMemo, useState } from "react";
import {
  AlertOctagon,
  Bell,
  LayoutDashboard,
  Pause,
  Play,
  ScrollText,
  Settings,
  Shield,
  Square,
  Wallet,
  X,
} from "lucide-react";
import { UserButton } from "@/lib/auth/gates";
import { STATION_BLURBS, DESTINATION_HINTS, DESTINATION_TYPES } from "@/lib/gmm/constants";
import { formatMoney } from "@/lib/gmm/money";
import type {
  AppState,
  AuditRow,
  ConnectorState,
  LedgerRow,
  OpportunityState,
  StationState,
} from "@/lib/gmm/types";
import {
  getAppState,
  getAuditLog,
  getConnectors,
  getLedger,
  getOpportunitiesFn,
  postConnector,
  postDestination,
  postMasterAction,
  postOpportunity,
  postScan,
  postStationAction,
  postTransfer,
} from "@/lib/gmm/api";

type Tab = "dashboard" | "stations" | "funds" | "ledger" | "security" | "alerts";

const TABS: { id: Tab; label: string; icon: typeof LayoutDashboard }[] = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "stations", label: "Stations", icon: Play },
  { id: "funds", label: "Move Money", icon: Wallet },
  { id: "ledger", label: "Transactions", icon: ScrollText },
  { id: "security", label: "Security", icon: Shield },
  { id: "alerts", label: "Notifications", icon: Bell },
];

function errMessage(err: unknown) {
  if (err && typeof err === "object" && "message" in err) return String((err as Error).message);
  return "Request failed";
}

function remainingSeconds(station: StationState, now: number) {
  if (station.paused) return station.paused_remaining_seconds || 0;
  if (station.active && station.next_cycle_at) {
    return Math.max(0, Math.ceil((new Date(station.next_cycle_at).getTime() - now) / 1000));
  }
  return 0;
}

function clock(total: number) {
  const h = String(Math.floor(total / 3600)).padStart(2, "0");
  const m = String(Math.floor((total % 3600) / 60)).padStart(2, "0");
  const s = String(total % 60).padStart(2, "0");
  return `${h}:${m}:${s}`;
}

function StationCard({
  station,
  index,
  now,
  busy,
  onAction,
  onOpen,
}: {
  station: StationState;
  index: number;
  now: number;
  busy: boolean;
  onAction: (id: number, action: string) => void;
  onOpen: (station: StationState) => void;
}) {
  const rem = remainingSeconds(station, now);
  return (
    <article className="rounded-xl border border-line bg-panel p-6">
      <div className="flex items-center justify-between gap-3">
        <span className="font-display text-lg font-extrabold tracking-wide text-muted">
          #{String(index + 1).padStart(2, "0")}
        </span>
        <span className="rounded-full bg-gold px-3 py-1 text-[11px] font-extrabold tracking-widest text-gold-ink">
          {station.status}
        </span>
      </div>
      <h2 className="mt-4 font-display text-[1.7rem] font-extrabold leading-tight">
        {station.name.replace(/ Station$/, "")}
      </h2>
      <p className="mt-2 text-[0.95rem] leading-relaxed text-muted">{STATION_BLURBS[index]}</p>
      <div className="mt-4 flex items-center justify-between rounded-md border border-gold/40 bg-gold/5 px-3 py-2">
        {station.active || station.paused ? (
          <>
            <strong className="font-mono text-lg tracking-wider">{clock(rem)}</strong>
            <small className="text-xs tracking-wide text-muted">
              {station.paused ? "PAUSED — timer held" : "NEXT CYCLE"}
            </small>
          </>
        ) : (
          <small className="text-xs tracking-wide text-muted">90:00 cycle ready</small>
        )}
      </div>
      <div className="mt-4 flex flex-wrap gap-2">
        {!station.active && !station.paused ? (
          <button
            disabled={busy}
            onClick={() => onAction(station.id, "start")}
            className="inline-flex h-11 items-center gap-2 rounded-md bg-gold px-4 font-extrabold text-gold-ink"
          >
            <Play className="size-4" /> Start
          </button>
        ) : null}
        {station.active ? (
          <button
            disabled={busy}
            onClick={() => onAction(station.id, "pause")}
            className="inline-flex h-11 items-center gap-2 rounded-md bg-gold px-4 font-extrabold text-gold-ink"
          >
            <Pause className="size-4" /> Pause
          </button>
        ) : null}
        {station.paused ? (
          <button
            disabled={busy}
            onClick={() => onAction(station.id, "start")}
            className="inline-flex h-11 items-center gap-2 rounded-md bg-gold px-4 font-extrabold text-gold-ink"
          >
            <Play className="size-4" /> Resume
          </button>
        ) : null}
        {(station.active || station.paused) && (
          <button
            disabled={busy}
            onClick={() => onAction(station.id, "stop")}
            className="inline-flex h-11 items-center gap-2 rounded-md border border-line px-4 font-extrabold"
          >
            <Square className="size-4" /> Stop
          </button>
        )}
        <button
          onClick={() => onOpen(station)}
          className="inline-flex h-11 items-center rounded-md border border-line px-4 font-bold text-muted"
        >
          Details
        </button>
      </div>
    </article>
  );
}

export function GmmApp() {
  const [tab, setTab] = useState<Tab>("dashboard");
  const [state, setState] = useState<AppState | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState("");
  const [message, setMessage] = useState("");
  const [now, setNow] = useState(Date.now());
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [detail, setDetail] = useState<StationState | null>(null);
  const [ledger, setLedger] = useState<LedgerRow[]>([]);
  const [audit, setAudit] = useState<AuditRow[]>([]);
  const [connectors, setConnectors] = useState<ConnectorState[]>([]);
  const [amount, setAmount] = useState("");
  const [dest, setDest] = useState("");
  const [adding, setAdding] = useState(false);
  const [dtype, setDtype] = useState("PAYPAL");
  const [dlabel, setDlabel] = useState("");
  const [dexternal, setDexternal] = useState("");

  const load = useCallback(async () => {
    try {
      const next = await getAppState();
      setState(next);
      setError("");
    } catch (err) {
      setError(errMessage(err));
    }
  }, []);

  useEffect(() => {
    void load();
    const poll = setInterval(() => void load(), 5000);
    const tick = setInterval(() => setNow(Date.now()), 1000);
    return () => {
      clearInterval(poll);
      clearInterval(tick);
    };
  }, [load]);

  useEffect(() => {
    if (tab === "ledger") void getLedger().then(setLedger).catch((e) => setError(errMessage(e)));
    if (tab === "security") void getAuditLog().then(setAudit).catch((e) => setError(errMessage(e)));
  }, [tab]);

  const runMaster = async (action: string) => {
    if (busy) return;
    setBusy(action);
    setMessage("");
    try {
      const d = await postMasterAction({ data: { action } });
      setMessage(
        `${action === "emergency" ? "Emergency stop" : action === "start" ? "Start all" : action === "stop" ? "Stop all" : "Pause all"} executed for ${d.station_count} stations. Ledger unchanged.`,
      );
      await load();
    } catch (err) {
      setMessage(`Control action failed: ${errMessage(err)}`);
    } finally {
      setBusy("");
    }
  };

  const act = async (id: number, action: string) => {
    try {
      await postStationAction({ data: { id, action } });
      await load();
    } catch (err) {
      setError(errMessage(err));
    }
  };

  const sendTransfer = async () => {
    try {
      const d = state?.destinations.find((x) => String(x.id) === dest);
      const res = await postTransfer({
        data: {
          amount: Number(amount),
          destination_id: Number(dest),
          idempotency_key: crypto.randomUUID(),
        },
      });
      setMessage(
        `Transfer submitted through ${d?.type || "provider"} — status ${res.status}. Final completion requires the live provider.`,
      );
      setAmount("");
      await load();
    } catch (err) {
      setMessage(errMessage(err));
    }
  };

  const saveDest = async () => {
    try {
      await postDestination({
        data: { type: dtype, label: dlabel, external_id: dexternal },
      });
      setMessage(`${dtype} destination saved.`);
      setDlabel("");
      setDexternal("");
      setAdding(false);
      await load();
    } catch (err) {
      setMessage(errMessage(err));
    }
  };

  const unread = useMemo(
    () => state?.notifications.filter((n) => !n.read).length ?? 0,
    [state],
  );

  if (!state) {
    return (
      <main className="mx-auto min-h-dvh w-full max-w-[760px] px-5 py-16">
        <div className="h-8 w-56 animate-pulse rounded-md bg-panel" />
        <div className="mt-8 h-40 animate-pulse rounded-xl bg-panel" />
        <div className="mt-4 h-32 animate-pulse rounded-xl bg-panel" />
      </main>
    );
  }

  const spendable = state.balance.spendable;

  return (
    <div className="mx-auto min-h-dvh w-full max-w-[760px] px-5 pb-28 pt-8">
      <header className="flex items-start gap-4 border-b border-line pb-6">
        <div>
          <div className="font-display text-[1.65rem] font-extrabold tracking-wide">
            GET MONEY MACHINE
          </div>
          <div className="mt-1 text-xs font-bold tracking-[0.16em] text-muted">
            PRODUCTION LEDGER
          </div>
        </div>
        <div className="ml-auto text-right">
          <span className="block text-[11px] font-extrabold tracking-[0.16em] text-muted">
            SPENDABLE AVAILABLE
          </span>
          <strong className="mt-1 block font-display text-[1.7rem] font-extrabold leading-none text-gold">
            ${formatMoney(spendable)}
          </strong>
        </div>
      </header>

      <nav className="-mx-1 flex gap-2 overflow-x-auto py-5">
        {TABS.map((t) => {
          const Icon = t.icon;
          return (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`inline-flex h-11 shrink-0 items-center gap-2 rounded-full border px-5 text-[15px] font-extrabold ${
                tab === t.id
                  ? "border-gold bg-gold text-gold-ink"
                  : "border-line bg-panel-2 text-ink"
              }`}
            >
              <Icon className="size-4" />
              {t.label}
              {t.id === "alerts" && unread > 0 ? (
                <span className="rounded-full bg-gold-ink px-1.5 text-[10px] text-gold">{unread}</span>
              ) : null}
            </button>
          );
        })}
      </nav>

      {error ? (
        <div className="mb-4 rounded-md border border-danger-line bg-danger-bg px-4 py-3 text-sm text-danger-fg">
          {error}
        </div>
      ) : null}

      {tab === "dashboard" || tab === "stations" ? (
        <>
          {tab === "dashboard" ? (
            <>
              <section className="mb-5 rounded-xl border border-line bg-panel p-7 shadow-[0_4px_18px_#0007]">
                <div className="text-sm font-extrabold tracking-[0.18em] text-muted">
                  SPENDABLE AVAILABLE BALANCE
                </div>
                <div className="mt-3 font-display text-[3.2rem] font-extrabold leading-none text-gold">
                  ${formatMoney(spendable)}
                </div>
                <div className="mt-4 grid gap-1 text-[15px] text-muted">
                  <div>
                    Opening balance <strong className="text-ink">$0.00</strong>
                  </div>
                  <div>
                    Completed ledger{" "}
                    <strong className="text-ink">${formatMoney(state.balance.completed_ledger)}</strong>
                  </div>
                  <div>
                    Reserved pending{" "}
                    <strong className="text-ink">${formatMoney(state.balance.pending)}</strong>
                  </div>
                </div>
                <div className="mt-4 text-[15px] text-muted">
                  PayPal provider:{" "}
                  {state.paypal.configured
                    ? "LIVE credentials configured"
                    : "Production setup required"}
                </div>
                <div className="mt-5 flex flex-wrap gap-3">
                  <button
                    disabled={!!busy}
                    onClick={() => runMaster("start")}
                    className="h-12 rounded-md bg-gold px-5 font-extrabold text-gold-ink"
                  >
                    {busy === "start" ? "Starting…" : "Start All"}
                  </button>
                  <button
                    disabled={!!busy}
                    onClick={() => runMaster("stop")}
                    className="h-12 rounded-md bg-gold px-5 font-extrabold text-gold-ink"
                  >
                    {busy === "stop" ? "Stopping…" : "Stop All"}
                  </button>
                  <button
                    disabled={!!busy}
                    onClick={() => runMaster("pause")}
                    className="h-12 rounded-md bg-gold px-5 font-extrabold text-gold-ink"
                  >
                    {busy === "pause" ? "Pausing…" : "Pause All"}
                  </button>
                  <button
                    disabled={!!busy}
                    onClick={() => runMaster("emergency")}
                    className="inline-flex h-12 items-center gap-2 rounded-md bg-danger px-5 font-extrabold text-gold-ink"
                  >
                    <AlertOctagon className="size-4" />
                    {busy === "emergency" ? "Stopping…" : "Emergency Stop"}
                  </button>
                </div>
                {message ? (
                  <div className="mt-4 rounded-md border border-line bg-canvas px-4 py-3 text-sm text-muted">
                    {message}
                  </div>
                ) : null}
              </section>
              <p className="mb-5 rounded-md border border-line bg-panel-2 px-4 py-3 text-[15px] text-muted">
                Spendable available funds are completed ledger credits minus reserved transfers.
                Discovery never becomes money without verification and settlement. Station controls
                are ledger-neutral.
              </p>
            </>
          ) : (
            <h2 className="mb-4 font-display text-[1.8rem] font-extrabold">Stations</h2>
          )}
          <div className="grid gap-5">
            {state.stations.map((s, i) => (
              <StationCard
                key={s.id}
                station={s}
                index={i}
                now={now}
                busy={!!busy}
                onAction={act}
                onOpen={setDetail}
              />
            ))}
          </div>
        </>
      ) : null}

      {tab === "funds" ? (
        <section className="rounded-xl border border-line bg-panel p-7">
          <div className="text-sm font-extrabold tracking-[0.18em] text-muted">
            SPENDABLE AVAILABLE BALANCE
          </div>
          <div className="mt-3 font-display text-[3rem] font-extrabold leading-none text-gold">
            ${formatMoney(spendable)}
          </div>
          <p className="mt-3 text-[15px] text-muted">
            Only spendable internal-ledger funds can be transferred. Transfers stay processing until
            the live provider confirms.
          </p>
          <label className="mt-6 block text-sm font-bold text-muted">Amount</label>
          <input
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            type="number"
            min="0.01"
            step="0.01"
            placeholder="0.00"
            className="mt-2 h-12 w-full rounded-md border border-line bg-canvas px-4 text-lg"
          />
          <label className="mt-5 block text-sm font-bold text-muted">Transfer destination</label>
          <select
            value={dest}
            onChange={(e) => setDest(e.target.value)}
            className="mt-2 h-12 w-full rounded-md border border-line bg-canvas px-4 text-base"
          >
            <option value="">Select destination</option>
            {state.destinations
              .filter((d) => d.enabled)
              .map((d) => (
                <option key={d.id} value={d.id}>
                  {d.label} • {state.providers[d.type]?.provider || d.type}
                </option>
              ))}
          </select>
          <div className="mt-4 flex flex-wrap gap-2">
            {DESTINATION_TYPES.map(([k, label]) => (
              <button
                key={k}
                type="button"
                disabled={!state.providers[k]?.configured}
                className="rounded-full border border-line bg-panel-2 px-4 py-2 text-sm font-extrabold disabled:opacity-40"
              >
                {label} —{" "}
                {state.providers[k]?.configured
                  ? "LIVE INTEGRATION CONFIGURED"
                  : "PRODUCTION CREDENTIALS REQUIRED"}
              </button>
            ))}
          </div>
          <button
            className="mt-5 h-12 w-full rounded-md bg-gold text-lg font-extrabold text-gold-ink disabled:opacity-45"
            disabled={!amount || !dest}
            onClick={() => void sendTransfer()}
          >
            Send Transfer
          </button>
          <button
            type="button"
            className="mt-3 h-12 w-full rounded-md border border-line font-bold"
            onClick={() => setAdding(!adding)}
          >
            {adding ? "Cancel" : "Add Transfer Destination"}
          </button>
          {adding ? (
            <div className="mt-4 grid gap-3">
              <select
                value={dtype}
                onChange={(e) => setDtype(e.target.value)}
                className="h-12 rounded-md border border-line bg-canvas px-4"
              >
                {DESTINATION_TYPES.map(([k, l]) => (
                  <option key={k} value={k}>
                    {l}
                  </option>
                ))}
              </select>
              <input
                value={dlabel}
                onChange={(e) => setDlabel(e.target.value)}
                placeholder="My destination"
                className="h-12 rounded-md border border-line bg-canvas px-4"
              />
              <textarea
                value={dexternal}
                onChange={(e) => setDexternal(e.target.value)}
                placeholder={DESTINATION_HINTS[dtype]}
                rows={4}
                className="rounded-md border border-line bg-canvas px-4 py-3"
              />
              <button
                className="h-12 rounded-md bg-gold font-extrabold text-gold-ink disabled:opacity-45"
                disabled={!dlabel.trim() || !dexternal.trim()}
                onClick={() => void saveDest()}
              >
                Save Destination
              </button>
            </div>
          ) : null}
          {message ? (
            <div className="mt-4 rounded-md border border-line bg-canvas px-4 py-3 text-sm text-muted">
              {message}
            </div>
          ) : null}
          <div className="mt-6">
            <h2 className="font-display text-xl font-extrabold">Recent Available Funds Activity</h2>
            {state.withdrawals.length ? (
              state.withdrawals.slice(0, 10).map((w) => (
                <div
                  key={w.id}
                  className="mt-2 flex justify-between rounded-md border border-line bg-canvas px-4 py-3"
                >
                  <span>{w.status}</span>
                  <strong className="text-gold">${formatMoney(w.amount)}</strong>
                </div>
              ))
            ) : (
              <div className="py-4 text-muted">No activity.</div>
            )}
          </div>
        </section>
      ) : null}

      {tab === "ledger" ? (
        <section>
          <h2 className="font-display text-[1.8rem] font-extrabold">Ledger Transactions</h2>
          <p className="mt-2 text-sm text-muted">
            Completed entries only change spendable available balance. No display-only figures.
          </p>
          {ledger.length ? (
            ledger.map((row) => (
              <div
                key={row.id}
                className="mt-3 rounded-lg border border-line bg-panel px-4 py-3"
              >
                <div className="flex justify-between gap-3">
                  <span className="font-bold">{row.kind}</span>
                  <strong className="font-mono text-gold">${formatMoney(row.amount)}</strong>
                </div>
                <div className="mt-1 text-sm text-muted">{row.status}</div>
                <div className="mt-1 text-sm text-muted">{row.description}</div>
              </div>
            ))
          ) : (
            <div className="mt-6 rounded-lg border border-line bg-panel px-4 py-6 text-muted">
              Ledger is empty. No opening balance has been recorded.
            </div>
          )}
        </section>
      ) : null}

      {tab === "security" ? (
        <section>
          <h2 className="font-display text-[1.8rem] font-extrabold">Audit & Security</h2>
          {audit.length ? (
            audit.map((row) => (
              <div key={row.id} className="mt-3 rounded-lg border border-line bg-panel px-4 py-3">
                <div className="font-bold">{row.action}</div>
                <div className="mt-1 text-sm text-muted">{row.detail}</div>
                <div className="mt-1 font-mono text-xs text-subtle">{row.created_at}</div>
              </div>
            ))
          ) : (
            <div className="mt-6 text-muted">No audit events yet.</div>
          )}
        </section>
      ) : null}

      {tab === "alerts" ? (
        <section>
          <h2 className="font-display text-[1.8rem] font-extrabold">Notifications</h2>
          {state.notifications.length ? (
            state.notifications.map((n) => (
              <div key={n.id} className="mt-3 rounded-lg border border-line bg-panel px-4 py-3">
                <div className="font-bold">{n.title}</div>
                <div className="mt-1 text-sm text-muted">{n.message}</div>
              </div>
            ))
          ) : (
            <div className="mt-6 text-muted">No notifications.</div>
          )}
        </section>
      ) : null}

      <button
        type="button"
        aria-label="Settings"
        onClick={() => {
          setSettingsOpen(true);
          void getConnectors().then(setConnectors).catch(() => undefined);
        }}
        className="fixed bottom-6 right-5 grid size-[62px] place-items-center rounded-full border-[8px] border-[#303030] bg-[#656565] text-ink shadow-[0_0_0_5px_#171717]"
      >
        <Settings className="size-6" />
      </button>

      {settingsOpen ? (
        <div className="fixed inset-0 z-50 grid place-items-end bg-black/70 p-0 sm:place-items-center sm:p-6">
          <div className="max-h-[92dvh] w-full max-w-[560px] overflow-y-auto rounded-t-xl border border-line bg-panel p-6 sm:rounded-xl">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-2xl font-extrabold">Control room</h2>
              <button onClick={() => setSettingsOpen(false)} className="grid size-10 place-items-center">
                <X className="size-5" />
              </button>
            </div>
            <div className="mt-4 rounded-lg border border-line bg-canvas p-4">
              <UserButton />
            </div>
            <p className="mt-4 text-sm text-muted">
              Scanner mode: real connectors only. Fabricated results: false. Cycle: 90 minutes.
            </p>
            <h3 className="mt-5 font-display text-xl font-extrabold">Station connectors</h3>
            <div className="mt-3 grid gap-3">
              {connectors.map((c) => (
                <ConnectorEditor key={c.station_id} connector={c} onSaved={() => void getConnectors().then(setConnectors)} />
              ))}
            </div>
          </div>
        </div>
      ) : null}

      {detail ? (
        <StationDetail
          station={detail}
          onClose={() => setDetail(null)}
          onChanged={() => void load()}
        />
      ) : null}
    </div>
  );
}

function ConnectorEditor({
  connector,
  onSaved,
}: {
  connector: ConnectorState;
  onSaved: () => void;
}) {
  const [endpoint, setEndpoint] = useState(connector.endpoint ?? "");
  const [enabled, setEnabled] = useState(connector.enabled);
  const [msg, setMsg] = useState("");
  return (
    <div className="rounded-lg border border-line bg-canvas p-4">
      <div className="font-bold">{connector.station_name}</div>
      <input
        value={endpoint}
        onChange={(e) => setEndpoint(e.target.value)}
        placeholder="https://source.example/opportunities.json"
        className="mt-2 h-11 w-full rounded-md border border-line bg-panel px-3 text-sm"
      />
      <label className="mt-2 flex items-center gap-2 text-sm">
        <input type="checkbox" checked={enabled} onChange={(e) => setEnabled(e.target.checked)} />
        Enable live connector
      </label>
      <button
        className="mt-2 h-10 rounded-md bg-gold px-4 text-sm font-extrabold text-gold-ink"
        onClick={async () => {
          try {
            await postConnector({
              data: {
                station_id: connector.station_id,
                connector_type: "http_json",
                endpoint,
                enabled,
              },
            });
            setMsg("Saved");
            onSaved();
          } catch (err) {
            setMsg(errMessage(err));
          }
        }}
      >
        Save
      </button>
      {msg ? <div className="mt-2 text-xs text-muted">{msg}</div> : null}
    </div>
  );
}

function StationDetail({
  station,
  onClose,
  onChanged,
}: {
  station: StationState;
  onClose: () => void;
  onChanged: () => void;
}) {
  const [rows, setRows] = useState<OpportunityState[]>([]);
  const [title, setTitle] = useState("");
  const [source, setSource] = useState("");
  const [value, setValue] = useState("");
  const [evidence, setEvidence] = useState("");
  const [msg, setMsg] = useState("");

  const reload = useCallback(() => {
    void getOpportunitiesFn({ data: { station_id: station.id } })
      .then(setRows)
      .catch((e) => setMsg(errMessage(e)));
  }, [station.id]);

  useEffect(() => {
    reload();
  }, [reload]);

  return (
    <div className="fixed inset-0 z-50 grid place-items-end bg-black/70 sm:place-items-center sm:p-6">
      <div className="max-h-[92dvh] w-full max-w-[560px] overflow-y-auto rounded-t-xl border border-line bg-panel p-6 sm:rounded-xl">
        <div className="flex items-start justify-between gap-3">
          <h2 className="font-display text-2xl font-extrabold">{station.name}</h2>
          <button onClick={onClose} className="grid size-10 place-items-center">
            <X className="size-5" />
          </button>
        </div>
        <p className="mt-2 text-sm text-muted">
          Scans only read configured live connectors. Detected opportunities are not spendable
          until externally settled.
        </p>
        <button
          className="mt-4 h-11 rounded-md bg-gold px-4 font-extrabold text-gold-ink"
          onClick={async () => {
            try {
              const r = await postScan({ data: { station_id: station.id } });
              setMsg(`Scan ${r.status}. Fabricated results: false.`);
              reload();
              onChanged();
            } catch (err) {
              setMsg(errMessage(err));
            }
          }}
        >
          Run scan
        </button>
        <div className="mt-5 grid gap-2">
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Opportunity title"
            className="h-11 rounded-md border border-line bg-canvas px-3"
          />
          <input
            value={source}
            onChange={(e) => setSource(e.target.value)}
            placeholder="Source URL (required to verify later)"
            className="h-11 rounded-md border border-line bg-canvas px-3"
          />
          <input
            value={value}
            onChange={(e) => setValue(e.target.value)}
            placeholder="Estimated value (optional)"
            className="h-11 rounded-md border border-line bg-canvas px-3"
          />
          <textarea
            value={evidence}
            onChange={(e) => setEvidence(e.target.value)}
            placeholder="Evidence / source details"
            rows={3}
            className="rounded-md border border-line bg-canvas px-3 py-2"
          />
          <button
            className="h-11 rounded-md border border-line font-extrabold"
            onClick={async () => {
              try {
                await postOpportunity({
                  data: {
                    station_id: station.id,
                    title,
                    source_url: source || undefined,
                    estimated_value: value ? Number(value) : null,
                    evidence,
                  },
                });
                setTitle("");
                setSource("");
                setValue("");
                setEvidence("");
                setMsg("Opportunity recorded as DETECTED. Not spendable.");
                reload();
              } catch (err) {
                setMsg(errMessage(err));
              }
            }}
          >
            Save detected opportunity
          </button>
        </div>
        {msg ? <div className="mt-3 text-sm text-muted">{msg}</div> : null}
        <div className="mt-5 grid gap-2">
          {rows.map((o) => (
            <div key={o.id} className="rounded-md border border-line bg-canvas px-3 py-3 text-sm">
              <div className="font-bold">
                #{o.id} {o.title}
              </div>
              <div className="text-muted">
                {o.state}
                {o.estimated_value ? ` · est $${formatMoney(o.estimated_value)}` : ""}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
