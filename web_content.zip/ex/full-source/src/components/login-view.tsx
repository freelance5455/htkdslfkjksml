import { useState } from "react";
import { GROK_PROVIDERS, authClient, signIn } from "@/lib/auth/client";

export function LoginView() {
  const [mode, setMode] = useState<"in" | "up">("in");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (busy) return;
    setBusy(true);
    setError("");
    try {
      if (mode === "up") {
        const { error: err } = await authClient.signUp.email({
          email: email.trim(),
          password,
          name: email.trim(),
          callbackURL: "/",
        });
        if (err) throw new Error(err.message || "Could not create account");
      } else {
        const { error: err } = await authClient.signIn.email({
          email: email.trim(),
          password,
          callbackURL: "/",
        });
        if (err) throw new Error(err.message || "Invalid credentials");
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Sign-in failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="grid min-h-dvh place-items-center bg-canvas px-5 py-10">
      <section className="w-full max-w-[440px] rounded-xl border border-line bg-panel p-7 shadow-[0_4px_18px_#0007]">
        <p className="font-display text-sm font-extrabold tracking-[0.18em] text-gold">
          OWNER ACCESS
        </p>
        <h1 className="mt-2 font-display text-4xl font-extrabold leading-none tracking-tight">
          GET MONEY MACHINE
        </h1>
        <p className="mt-3 text-sm leading-relaxed text-muted">
          Production ledger. Spendable available balance is the internal source of
          truth. No simulated earnings.
        </p>
        <form className="mt-6 grid gap-3" onSubmit={onSubmit}>
          <label className="text-sm font-semibold text-muted" htmlFor="email">
            Email
          </label>
          <input
            id="email"
            type="email"
            required
            autoComplete="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="h-12 w-full rounded-md border border-line bg-panel-2 px-4 text-base text-ink outline-none focus:border-gold"
          />
          <label className="text-sm font-semibold text-muted" htmlFor="password">
            Password
          </label>
          <input
            id="password"
            type="password"
            required
            minLength={8}
            autoComplete={mode === "up" ? "new-password" : "current-password"}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="h-12 w-full rounded-md border border-line bg-panel-2 px-4 text-base text-ink outline-none focus:border-gold"
          />
          <button
            type="submit"
            disabled={busy}
            className="mt-2 h-12 rounded-md bg-gold text-base font-extrabold text-gold-ink disabled:opacity-50"
          >
            {busy ? "WORKING…" : mode === "up" ? "CREATE ACCOUNT" : "LOG IN"}
          </button>
          {error ? (
            <div className="rounded-md border border-danger-line bg-danger-bg px-3 py-2 text-sm text-danger-fg">
              {error}
            </div>
          ) : null}
        </form>
        <button
          type="button"
          className="mt-4 text-sm font-semibold text-muted underline-offset-4 hover:text-ink hover:underline"
          onClick={() => {
            setMode(mode === "in" ? "up" : "in");
            setError("");
          }}
        >
          {mode === "in" ? "Need an owner account? Create one" : "Already registered? Log in"}
        </button>
        <div className="mt-6 grid gap-2">
          {GROK_PROVIDERS.map((p) => (
            <button
              key={p.providerId}
              type="button"
              onClick={() => signIn(p.providerId, { callbackURL: "/" })}
              className="h-12 rounded-md border border-line bg-panel-2 text-sm font-bold text-ink hover:border-gold"
            >
              Continue with {p.label}
            </button>
          ))}
        </div>
      </section>
    </main>
  );
}
