import { createFileRoute } from "@tanstack/react-router";
import { health } from "@/lib/gmm/core";

export const Route = createFileRoute("/health")({
  server: {
    handlers: {
      GET: async () => {
        const data = await health();
        return new Response(JSON.stringify(data), {
          headers: { "Content-Type": "application/json" },
        });
      },
    },
  },
});
