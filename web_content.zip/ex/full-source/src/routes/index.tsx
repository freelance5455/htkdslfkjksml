import { createFileRoute } from "@tanstack/react-router";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { GmmApp } from "@/components/gmm-app";
import { LoginView } from "@/components/login-view";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const { user, isPending } = useCurrentUserState();
  if (isPending) {
    return (
      <main className="mx-auto min-h-dvh w-full max-w-[760px] bg-canvas px-5 py-16">
        <div className="font-display text-3xl font-extrabold tracking-wide text-ink">
          GET MONEY MACHINE
        </div>
        <div className="mt-2 text-xs font-bold tracking-[0.16em] text-muted">
          SPENDABLE AVAILABLE BALANCE
        </div>
        <div className="mt-8 h-40 animate-pulse rounded-xl bg-panel" />
        <div className="mt-4 h-32 animate-pulse rounded-xl bg-panel" />
      </main>
    );
  }
  if (!user) return <LoginView />;
  return <GmmApp />;
}
