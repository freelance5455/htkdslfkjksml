import { createFileRoute } from "@tanstack/react-router";
import { GmmError, handlePaypalWebhook } from "@/lib/gmm/core";

export const Route = createFileRoute("/paypal/webhook")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        try {
          const data = await handlePaypalWebhook(request);
          return new Response(JSON.stringify(data), {
            headers: { "Content-Type": "application/json" },
          });
        } catch (err) {
          const status = err instanceof GmmError ? err.status : 400;
          const message = err instanceof Error ? err.message : "Webhook failed";
          return new Response(JSON.stringify({ detail: message }), {
            status,
            headers: { "Content-Type": "application/json" },
          });
        }
      },
    },
  },
});
