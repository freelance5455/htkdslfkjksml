import { createFileRoute } from "@tanstack/react-router";
import { handleGmmRequest } from "@/lib/gmm/rest";

export const Route = createFileRoute("/api/gmm/$")({
  server: {
    handlers: {
      GET: ({ request }) => handleGmmRequest(request),
      POST: ({ request }) => handleGmmRequest(request),
      PATCH: ({ request }) => handleGmmRequest(request),
    },
  },
});
