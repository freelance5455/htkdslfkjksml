import { env } from "@/lib/env.server";

export function paypalConfigured(): boolean {
  return Boolean(
    env("PAYPAL_CLIENT_ID") && env("PAYPAL_CLIENT_SECRET") && env("PAYPAL_WEBHOOK_ID"),
  );
}

export function paypalClientId(): string | undefined {
  return env("PAYPAL_CLIENT_ID");
}

export function paypalClientSecret(): string | undefined {
  return env("PAYPAL_CLIENT_SECRET");
}

export function paypalWebhookId(): string | undefined {
  return env("PAYPAL_WEBHOOK_ID");
}

export function settlementKey(): string | undefined {
  return env("SETTLEMENT_KEY");
}

export function providerStatusMap() {
  const plaid = Boolean(env("PLAID_CLIENT_ID") && env("PLAID_SECRET"));
  const visa = Boolean(
    env("VISA_API_KEY") &&
      env("VISA_SHARED_SECRET") &&
      env("VISA_ACQUIRING_BIN") &&
      env("VISA_MERCHANT_ID"),
  );
  const cash = Boolean(
    env("CASHAPP_CLIENT_ID") && env("CASHAPP_API_KEY_ID") && env("CASHAPP_API_SECRET"),
  );
  return {
    PAYPAL: {
      configured: paypalConfigured(),
      mode: "live" as const,
      provider: "PayPal Payouts",
    },
    ACH: {
      configured: plaid,
      provider: "Plaid Transfer",
    },
    ONEPAY: {
      configured: plaid,
      provider: "Plaid Transfer to linked OnePay account",
    },
    DEBIT_CARD: {
      configured: visa,
      provider: "Visa Direct",
    },
    CASH_APP: {
      configured: cash,
      provider: "Cash App Pay Payouts",
    },
  };
}
