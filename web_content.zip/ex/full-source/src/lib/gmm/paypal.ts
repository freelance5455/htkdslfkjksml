import { env } from "@/lib/env.server";
import {
  paypalClientId,
  paypalClientSecret,
  paypalConfigured,
  paypalWebhookId,
} from "./env";

const PAYPAL_HOST = "https://api-m.paypal.com";

export class ProviderError extends Error {
  status: number;
  constructor(message: string, status = 502) {
    super(message);
    this.status = status;
  }
}

async function accessToken(): Promise<string> {
  const id = paypalClientId();
  const secret = paypalClientSecret();
  if (!id || !secret) {
    throw new ProviderError("PAYPAL SETUP REQUIRED", 503);
  }
  const basic = Buffer.from(`${id}:${secret}`).toString("base64");
  const res = await fetch(`${PAYPAL_HOST}/v1/oauth2/token`, {
    method: "POST",
    headers: {
      Authorization: `Basic ${basic}`,
      Accept: "application/json",
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: "grant_type=client_credentials",
  });
  const body = (await res.json().catch(() => ({}))) as { access_token?: string };
  if (!res.ok || !body.access_token) {
    throw new ProviderError(`PayPal authentication failed (${res.status})`);
  }
  return body.access_token;
}

export async function createPaypalPayout(opts: {
  amount: string;
  recipientEmail: string;
  reference: string;
}) {
  if (!paypalConfigured()) {
    throw new ProviderError("PAYPAL SETUP REQUIRED", 503);
  }
  const token = await accessToken();
  const batchId = `GMM-${opts.reference}`.slice(0, 255);
  const res = await fetch(`${PAYPAL_HOST}/v1/payments/payouts`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
      Accept: "application/json",
      "PayPal-Request-Id": batchId,
    },
    body: JSON.stringify({
      sender_batch_header: {
        sender_batch_id: batchId,
        email_subject: "GET MONEY MACHINE payout",
        email_message: "A payout has been initiated.",
      },
      items: [
        {
          recipient_type: "EMAIL",
          amount: { value: opts.amount, currency: "USD" },
          receiver: opts.recipientEmail,
          note: opts.reference,
          sender_item_id: opts.reference,
        },
      ],
    }),
  });
  const body = (await res.json().catch(() => ({}))) as {
    message?: string;
    name?: string;
    batch_header?: { batch_status?: string; payout_batch_id?: string };
  };
  if (!res.ok) {
    throw new ProviderError(
      `PayPal payout failed (${res.status}): ${body.message || body.name || "provider error"}`,
    );
  }
  const header = body.batch_header ?? {};
  return {
    provider: "PAYPAL",
    status: header.batch_status ?? "PENDING",
    provider_reference: header.payout_batch_id ?? batchId,
    raw: body,
  };
}

export async function getPaypalPayout(payoutBatchId: string) {
  const token = await accessToken();
  const res = await fetch(`${PAYPAL_HOST}/v1/payments/payouts/${payoutBatchId}`, {
    headers: { Authorization: `Bearer ${token}`, Accept: "application/json" },
  });
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw new ProviderError(`PayPal payout lookup failed (${res.status})`);
  return body as Record<string, unknown>;
}

export async function verifyPaypalWebhook(
  headers: Headers,
  event: Record<string, unknown>,
) {
  const webhookId = paypalWebhookId();
  const required = [
    "paypal-auth-algo",
    "paypal-cert-url",
    "paypal-transmission-id",
    "paypal-transmission-sig",
    "paypal-transmission-time",
  ];
  if (!webhookId || required.some((k) => !headers.get(k))) {
    throw new ProviderError("Invalid PayPal webhook headers", 400);
  }
  const token = await accessToken();
  const res = await fetch(`${PAYPAL_HOST}/v1/notifications/verify-webhook-signature`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
      Accept: "application/json",
    },
    body: JSON.stringify({
      auth_algo: headers.get("paypal-auth-algo"),
      cert_url: headers.get("paypal-cert-url"),
      transmission_id: headers.get("paypal-transmission-id"),
      transmission_sig: headers.get("paypal-transmission-sig"),
      transmission_time: headers.get("paypal-transmission-time"),
      webhook_id: webhookId,
      webhook_event: event,
    }),
  });
  const body = (await res.json().catch(() => ({}))) as {
    verification_status?: string;
  };
  if (!res.ok || body.verification_status !== "SUCCESS") {
    throw new ProviderError("Invalid PayPal webhook signature", 400);
  }
  return true;
}

export function paypalLiveEnv(): string {
  return env("PAYPAL_ENV") || "live";
}
