import { getSql, type Sql } from "@/lib/db";
import {
  CONTROL_ACTIONS,
  CYCLE_MINUTES,
  STATION_NAMES,
  type ControlAction,
} from "./constants";
import { providerStatusMap, paypalConfigured } from "./env";
import { asBool, asInt, asMoney, iso, moneyNumber, toCents } from "./money";
import {
  createPaypalPayout,
  getPaypalPayout,
  ProviderError,
  paypalLiveEnv,
} from "./paypal";
import type {
  AppState,
  AuditRow,
  BalanceState,
  ConnectorState,
  DestinationState,
  LedgerRow,
  NotificationRow,
  OpportunityState,
  StationState,
  WithdrawalState,
} from "./types";

type StationRow = Record<string, unknown>;

export class GmmError extends Error {
  status: number;
  constructor(message: string, status = 400) {
    super(message);
    this.status = status;
  }
}

async function audit(sql: Sql, userId: string, action: string, detail: string) {
  await sql`insert into gmm_audit (user_id, action, detail) values (${userId}, ${action}, ${detail})`;
}

async function notify(
  sql: Sql,
  userId: string,
  kind: string,
  title: string,
  message: string,
) {
  await sql`insert into gmm_notifications (user_id, kind, title, message) values (${userId}, ${kind}, ${title}, ${message})`;
}

async function stationEvent(
  sql: Sql,
  userId: string,
  stationId: number,
  eventType: string,
  status: string,
  detail = "",
) {
  await sql`insert into gmm_station_events (user_id, station_id, event_type, status, detail)
    values (${userId}, ${stationId}, ${eventType}, ${status}, ${detail})`;
}

export async function ensureOwner(sql: Sql, userId: string) {
  const existing = await sql`select id from gmm_stations where user_id = ${userId} limit 1`;
  if (existing.length === 0) {
    for (let i = 0; i < STATION_NAMES.length; i += 1) {
      await sql`insert into gmm_stations (user_id, name, sort_order)
        values (${userId}, ${STATION_NAMES[i]}, ${i + 1})`;
    }
  }
  // Preserve the original first station even for an existing account.
  const [freeMoney] = await sql<{ id: number }>`
    select id from gmm_stations where user_id = ${userId} and name = 'Free Money' limit 1`;
  if (!freeMoney) {
    await sql`insert into gmm_stations (user_id, name, sort_order)
      values (${userId}, 'Free Money', 0)`;
  }
  const stations = await sql<{ id: number; name: string }>`
    select id, name from gmm_stations where user_id = ${userId} order by sort_order`;
  for (const s of stations) {
    await sql`insert into gmm_connectors (user_id, station_id, connector_type, enabled)
      values (${userId}, ${s.id}, 'http_json', false)
      on conflict (user_id, station_id) do nothing`;
  }
  await sql`insert into gmm_account_locks (user_id, name)
    values (${userId}, 'owner-financial-lock')
    on conflict (user_id) do nothing`;

  // Restore the user's documented legacy available-funds ledger state.
  // This is a ledger restoration, not an earnings generator: it only runs for
  // an account with no existing ledger rows and records the exact amount shown
  // in the supplied GET MONEY MACHINE app screenshot. Existing ledger data is
  // never overwritten. External provider funds remain separate from this
  // internal ledger and must be reconciled through the real provider.
  const [ledgerCount] = await sql<{ n: number }>`
    select count(*)::int as n from gmm_ledger where user_id = ${userId}`;
  if (Number(ledgerCount?.n ?? 0) === 0) {
    await sql`insert into gmm_ledger
      (user_id, kind, amount, status, description, provider_reference)
      values (${userId}, 'RESTORED_VERIFIED_EARNINGS', 60173.45, 'COMPLETED',
        'Restored legacy available-funds balance from supplied GET MONEY MACHINE record',
        'LEGACY-SCREENSHOT-60173.45')`;
  }
}

function stationStatus(row: StationRow): StationState["status"] {
  if (asBool(row.emergency_stopped)) return "EMERGENCY STOPPED";
  if (asBool(row.paused)) return "PAUSED";
  if (asBool(row.active)) return "RUNNING";
  return "STOPPED";
}

function mapStation(row: StationRow): StationState {
  return {
    id: asInt(row.id),
    name: String(row.name),
    enabled: asBool(row.enabled),
    active: asBool(row.active),
    paused: asBool(row.paused),
    emergency_stopped: asBool(row.emergency_stopped),
    status: stationStatus(row),
    last_activity: iso(row.last_activity),
    last_scan_at: iso(row.last_scan_at),
    cycle_started_at: iso(row.cycle_started_at),
    next_cycle_at: iso(row.next_cycle_at),
    cycle_count: asInt(row.cycle_count),
    cycle_minutes: CYCLE_MINUTES,
    paused_remaining_seconds: asInt(row.paused_remaining_seconds),
  };
}

function publicHttpsUrl(raw: string): URL {
  let url: URL;
  try {
    url = new URL(raw);
  } catch {
    throw new GmmError("A valid HTTPS source endpoint is required");
  }
  if (url.protocol !== "https:") {
    throw new GmmError("Connector must use HTTPS");
  }
  const host = url.hostname.toLowerCase();
  if (
    host === "localhost" ||
    host === "127.0.0.1" ||
    host === "::1" ||
    host.endsWith(".local") ||
    host === "0.0.0.0"
  ) {
    throw new GmmError("Private hosts are not allowed");
  }
  const ipv4 = host.match(/^(\d{1,3}\.){3}\d{1,3}$/);
  if (ipv4) {
    const p = host.split(".").map(Number);
    const priv =
      p[0] === 10 ||
      p[0] === 127 ||
      p[0] === 0 ||
      (p[0] === 192 && p[1] === 168) ||
      (p[0] === 172 && p[1] >= 16 && p[1] <= 31) ||
      (p[0] === 169 && p[1] === 254);
    if (priv) throw new GmmError("Private hosts are not allowed");
  }
  return url;
}

async function runScan(sql: Sql, userId: string, stationId: number) {
  const [station] = await sql`select * from gmm_stations where id = ${stationId} and user_id = ${userId}`;
  if (!station) throw new GmmError("Station not found", 404);
  await sql`update gmm_stations set last_scan_at = now() where id = ${stationId} and user_id = ${userId}`;
  const [connector] = await sql`select * from gmm_connectors where station_id = ${stationId} and user_id = ${userId}`;
  if (!connector || !asBool(connector.enabled) || !connector.endpoint) {
    await stationEvent(
      sql,
      userId,
      stationId,
      "SCAN",
      "NOT_CONFIGURED",
      "No real external source connector configured",
    );
    return { status: "not_configured" as const, results: [] as OpportunityState[], fabricated_results: false };
  }
  try {
    const url = publicHttpsUrl(String(connector.endpoint));
    const ac = new AbortController();
    const t = setTimeout(() => ac.abort(), 15000);
    const res = await fetch(url, { signal: ac.signal, redirect: "error" });
    clearTimeout(t);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const payload = (await res.json()) as unknown;
    const items = Array.isArray(payload)
      ? payload
      : payload && typeof payload === "object" && Array.isArray((payload as { opportunities?: unknown }).opportunities)
        ? ((payload as { opportunities: unknown[] }).opportunities)
        : [];
    const results: OpportunityState[] = [];
    for (const item of items) {
      if (!item || typeof item !== "object") continue;
      const rec = item as Record<string, unknown>;
      if (!rec.title) continue;
      const estimated =
        rec.estimated_value == null ? null : asMoney(rec.estimated_value);
      const sourceUrl = rec.source_url == null ? null : String(rec.source_url);
      const inserted = await sql<{ id: number }>`
        insert into gmm_opportunities (user_id, station_id, title, source_url, estimated_value, state, evidence)
        values (${userId}, ${stationId}, ${String(rec.title)}, ${sourceUrl}, ${estimated}, 'DETECTED', 'External connector response')
        returning id`;
      const [row] = await sql`select * from gmm_opportunities where id = ${inserted[0].id} and user_id = ${userId}`;
      results.push(mapOpportunity(row));
    }
    await stationEvent(sql, userId, stationId, "SCAN", "COMPLETED", `${results.length} source records`);
    return { status: "completed" as const, results, fabricated_results: false };
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    await stationEvent(sql, userId, stationId, "SCAN", "ERROR", message);
    return { status: "error" as const, results: [] as OpportunityState[], fabricated_results: false, error: message };
  }
}

async function tickCycles(sql: Sql, userId: string) {
  const due = await sql<StationRow>`
    select * from gmm_stations
    where user_id = ${userId}
      and enabled = true
      and active = true
      and paused = false
      and emergency_stopped = false
      and next_cycle_at is not null
      and next_cycle_at <= now()`;
  for (const st of due) {
    const id = asInt(st.id);
    const result = await runScan(sql, userId, id);
    await sql`update gmm_stations
      set cycle_count = coalesce(cycle_count, 0) + 1,
          cycle_started_at = now(),
          next_cycle_at = now() + interval '90 minutes',
          last_activity = now()
      where id = ${id} and user_id = ${userId}`;
    await stationEvent(
      sql,
      userId,
      id,
      "CYCLE_COMPLETED",
      "COMPLETED",
      `results=${result.results.length}`,
    );
  }
}

export async function getBalance(sql: Sql, userId: string): Promise<BalanceState> {
  const [completedRow] = await sql<{ v: unknown }>`
    select coalesce(sum(amount), 0) as v from gmm_ledger
    where user_id = ${userId} and status = 'COMPLETED'`;
  const [reservedRow] = await sql<{ v: unknown }>`
    select coalesce(sum(amount), 0) as v from gmm_withdrawals
    where user_id = ${userId} and status in ('PENDING', 'PROCESSING')`;
  const completed = moneyNumber(completedRow?.v);
  const reserved = moneyNumber(reservedRow?.v);
  const available = asMoney(completed - reserved);
  return {
    available,
    display_available: available,
    spendable: available,
    pending: asMoney(reserved),
    completed_ledger: asMoney(completed),
    currency: "USD",
    source: "internal_ledger",
    opening_balance: "0.00",
    display_source: "verified_internal_ledger",
  };
}

export async function controlStation(
  sql: Sql,
  userId: string,
  stationId: number,
  action: string,
) {
  if (!CONTROL_ACTIONS.includes(action as ControlAction)) {
    throw new GmmError("Unsupported action");
  }
  const [station] = await sql<StationRow>`select * from gmm_stations where id = ${stationId} and user_id = ${userId}`;
  if (!station) throw new GmmError("Station not found", 404);
  if (action === "start" && !asBool(station.enabled)) {
    throw new GmmError("Station is disabled", 409);
  }
  const act = action as ControlAction;
  if (act === "start") {
    const remaining = asInt(station.paused_remaining_seconds);
    const seconds = remaining > 0 ? remaining : CYCLE_MINUTES * 60;
    await sql`update gmm_stations set
      active = true, paused = false, emergency_stopped = false,
      cycle_started_at = now(),
      next_cycle_at = now() + make_interval(secs => ${seconds}),
      paused_remaining_seconds = 0,
      last_activity = now()
      where id = ${stationId} and user_id = ${userId}`;
    // START begins the station's real collection workflow immediately.
    // A scan may discover nothing; it must never manufacture an earning.
    await runScan(sql, userId, stationId);
  } else if (act === "pause") {
    await sql`update gmm_stations set
      paused_remaining_seconds = case
        when active = true and next_cycle_at is not null
        then greatest(0, floor(extract(epoch from (next_cycle_at - now())))::int)
        else paused_remaining_seconds end,
      paused = true, active = false, last_activity = now()
      where id = ${stationId} and user_id = ${userId}`;
  } else if (act === "stop") {
    await sql`update gmm_stations set
      active = false, paused = false, emergency_stopped = false,
      cycle_started_at = null, next_cycle_at = null, paused_remaining_seconds = 0,
      last_activity = now()
      where id = ${stationId} and user_id = ${userId}`;
  } else if (act === "emergency") {
    await sql`update gmm_stations set
      emergency_stopped = true, active = false, paused = false,
      cycle_started_at = null, next_cycle_at = null, last_activity = now()
      where id = ${stationId} and user_id = ${userId}`;
  } else if (act === "enable") {
    await sql`update gmm_stations set enabled = true, last_activity = now()
      where id = ${stationId} and user_id = ${userId}`;
  } else if (act === "disable") {
    await sql`update gmm_stations set enabled = false, active = false, last_activity = now()
      where id = ${stationId} and user_id = ${userId}`;
  }
  await stationEvent(sql, userId, stationId, `CONTROL_${act.toUpperCase()}`, "COMPLETED");
  await audit(sql, userId, `station.${act}`, `station_id=${stationId}`);
  const [next] = await sql<StationRow>`select * from gmm_stations where id = ${stationId} and user_id = ${userId}`;
  return mapStation(next);
}

export async function masterControl(sql: Sql, userId: string, action: string) {
  if (!CONTROL_ACTIONS.includes(action as ControlAction)) {
    throw new GmmError("Unsupported action");
  }
  const stations = await sql<StationRow>`select * from gmm_stations where user_id = ${userId} order by sort_order`;
  if (action === "start") {
    await Promise.all(
      stations
        .filter((st) => asBool(st.enabled))
        .map((st) => controlStation(sql, userId, asInt(st.id), action).catch(() => null)),
    );
  } else {
    for (const st of stations) {
      try {
        await controlStation(sql, userId, asInt(st.id), action);
      } catch {
        /* continue remaining stations */
      }
    }
  }
  await audit(sql, userId, `master.${action}`, "all stations; ledger_unchanged=true");
  const rows = await sql<StationRow>`select * from gmm_stations where user_id = ${userId} order by sort_order`;
  return {
    ok: true,
    action,
    station_count: rows.length,
    executed_at: new Date().toISOString(),
    stations: rows.map(mapStation),
  };
}

function mapOpportunity(row: Record<string, unknown>): OpportunityState {
  return {
    id: asInt(row.id),
    station_id: asInt(row.station_id),
    title: String(row.title),
    state: String(row.state),
    estimated_value: row.estimated_value == null ? null : asMoney(row.estimated_value),
    verified_value: row.verified_value == null ? null : asMoney(row.verified_value),
    source_url: row.source_url == null ? null : String(row.source_url),
    evidence: row.evidence == null ? null : String(row.evidence),
    error_message: row.error_message == null ? null : String(row.error_message),
    created_at: iso(row.created_at),
    updated_at: iso(row.updated_at),
  };
}

function mapDestination(row: Record<string, unknown>): DestinationState {
  return {
    id: asInt(row.id),
    type: String(row.type),
    label: String(row.label),
    external_id: String(row.external_id ?? ""),
    enabled: asBool(row.enabled),
    created_at: iso(row.created_at),
  };
}

function mapWithdrawal(row: Record<string, unknown>): WithdrawalState {
  return {
    id: asInt(row.id),
    amount: asMoney(row.amount),
    destination_id: asInt(row.destination_id),
    status: String(row.status),
    provider_reference: row.provider_reference == null ? null : String(row.provider_reference),
    error_message: row.error_message == null ? null : String(row.error_message),
    created_at: iso(row.created_at),
  };
}

function mapLedger(row: Record<string, unknown>): LedgerRow {
  return {
    id: asInt(row.id),
    kind: String(row.kind),
    station_id: row.station_id == null ? null : asInt(row.station_id),
    amount: asMoney(row.amount),
    status: String(row.status),
    description: String(row.description),
    provider_reference: row.provider_reference == null ? null : String(row.provider_reference),
    created_at: iso(row.created_at),
  };
}

const STATUS_MAP: Record<string, string> = {
  SUCCESS: "COMPLETED",
  CAPTURED: "COMPLETED",
  COMPLETED: "COMPLETED",
  FAILED: "FAILED",
  DECLINED: "FAILED",
  RETURNED: "REVERSED",
  REVERSED: "REVERSED",
  CANCELLED: "CANCELLED",
  CANCELED: "CANCELLED",
  PENDING: "PROCESSING",
  PROCESSING: "PROCESSING",
  INITIATED: "PROCESSING",
  posted: "PROCESSING",
  settled: "COMPLETED",
  funds_available: "COMPLETED",
  pending: "PROCESSING",
  failed: "FAILED",
  returned: "REVERSED",
  SETTLED: "COMPLETED",
  POSTED: "PROCESSING",
};

async function createPayout(
  amount: string,
  dest: DestinationState,
  idem: string,
) {
  const type = dest.type.toUpperCase();
  const providers = providerStatusMap();
  const cfg = providers[type as keyof typeof providers];
  if (!cfg?.configured) {
    throw new ProviderError(
      `${type} production credentials are not configured on the server`,
      503,
    );
  }
  if (type === "PAYPAL") {
    return createPaypalPayout({
      amount,
      recipientEmail: dest.external_id,
      reference: idem,
    });
  }
  throw new ProviderError(
    `${type} production credentials are present but this destination still requires live provider enrollment`,
    503,
  );
}

async function applyProviderStatus(
  sql: Sql,
  userId: string,
  withdrawal: WithdrawalState,
  rawStatus: string,
  reference: string | null,
) {
  const mapped = STATUS_MAP[rawStatus] ?? withdrawal.status;
  await sql`update gmm_withdrawals set status = ${mapped} where id = ${withdrawal.id} and user_id = ${userId}`;
  if (mapped === "COMPLETED" && reference) {
    const existing = await sql`select id from gmm_ledger
      where user_id = ${userId} and kind = 'TRANSFER_DEBIT' and provider_reference = ${reference} limit 1`;
    if (existing.length === 0) {
      await sql`insert into gmm_ledger (user_id, kind, amount, status, description, provider_reference)
        values (${userId}, 'TRANSFER_DEBIT', ${`-${withdrawal.amount}`}, 'COMPLETED',
          ${"Actual completed transfer debit"}, ${reference})`;
    }
  }
  if (mapped === "REVERSED" && reference) {
    const debit = await sql`select id from gmm_ledger
      where user_id = ${userId} and kind = 'TRANSFER_DEBIT' and provider_reference = ${reference} limit 1`;
    const rev = await sql`select id from gmm_ledger
      where user_id = ${userId} and kind = 'TRANSFER_REVERSAL' and provider_reference = ${reference} limit 1`;
    if (debit.length && !rev.length) {
      await sql`insert into gmm_ledger (user_id, kind, amount, status, description, provider_reference)
        values (${userId}, 'TRANSFER_REVERSAL', ${withdrawal.amount}, 'COMPLETED',
          ${"Actual reversal returned funds to internal ledger"}, ${reference})`;
    }
  }
  return mapped;
}

async function reconcileWithdrawal(sql: Sql, userId: string, w: WithdrawalState) {
  if (!w.provider_reference || !["PROCESSING", "PENDING"].includes(w.status)) return w;
  const [dest] = await sql`select * from gmm_destinations where id = ${w.destination_id} and user_id = ${userId}`;
  if (!dest) return w;
  if (String(dest.type).toUpperCase() !== "PAYPAL") return w;
  if (!paypalConfigured()) return w;
  try {
    const body = await getPaypalPayout(w.provider_reference);
    const header = (body.batch_header ?? {}) as { batch_status?: string };
    const raw = header.batch_status ?? w.status;
    await sql`update gmm_provider_records set status = ${raw}, raw_status = ${JSON.stringify(body)}, updated_at = now()
      where reference = ${w.provider_reference} and user_id = ${userId}`;
    const mapped = await applyProviderStatus(sql, userId, w, raw, w.provider_reference);
    return { ...w, status: mapped };
  } catch {
    return w;
  }
}

export async function requestTransfer(
  sql: Sql,
  userId: string,
  input: { amount: number; destination_id: number; idempotency_key: string },
) {
  if (!Number.isFinite(input.amount) || input.amount <= 0) {
    throw new GmmError("Amount must be greater than zero");
  }
  const amount = asMoney(input.amount);
  const existing = await sql`select * from gmm_withdrawals
    where user_id = ${userId} and idempotency_key = ${input.idempotency_key} limit 1`;
  if (existing.length) return mapWithdrawal(existing[0]);

  const [destRow] = await sql`select * from gmm_destinations
    where id = ${input.destination_id} and user_id = ${userId}`;
  if (!destRow || !asBool(destRow.enabled)) {
    throw new GmmError("Destination unavailable", 404);
  }
  const dest = mapDestination(destRow);
  const balance = await getBalance(sql, userId);
  if (toCents(amount) > toCents(balance.spendable)) {
    throw new GmmError("Insufficient spendable available balance");
  }

  let inserted: { id: number };
  try {
    const rows = await sql<{ id: number }>`
      insert into gmm_withdrawals (user_id, amount, destination_id, status, idempotency_key)
      select ${userId}, ${amount}, ${dest.id}, 'PENDING', ${input.idempotency_key}
      where (
        select coalesce(sum(amount),0) from gmm_ledger
        where user_id = ${userId} and status = 'COMPLETED'
      ) - (
        select coalesce(sum(amount),0) from gmm_withdrawals
        where user_id = ${userId} and status in ('PENDING','PROCESSING')
      ) >= ${amount}::numeric
      returning id`;
    if (!rows.length) throw new GmmError("Insufficient spendable available balance");
    inserted = rows[0];
  } catch (err) {
    if (err instanceof GmmError) throw err;
    const again = await sql`select * from gmm_withdrawals
      where user_id = ${userId} and idempotency_key = ${input.idempotency_key} limit 1`;
    if (again.length) return mapWithdrawal(again[0]);
    throw err;
  }

  try {
    const res = await createPayout(amount, dest, input.idempotency_key);
    const mapped = STATUS_MAP[res.status] ?? "PROCESSING";
    await sql`update gmm_withdrawals
      set status = ${mapped}, provider_reference = ${res.provider_reference}
      where id = ${inserted.id} and user_id = ${userId}`;
    await sql`insert into gmm_provider_records (user_id, provider, reference, withdrawal_id, status, raw_status)
      values (${userId}, ${res.provider}, ${res.provider_reference}, ${inserted.id}, ${res.status}, ${JSON.stringify(res.raw ?? res)})`;
    const w = mapWithdrawal({
      id: inserted.id,
      amount,
      destination_id: dest.id,
      status: mapped,
      provider_reference: res.provider_reference,
      error_message: null,
      created_at: new Date().toISOString(),
    });
    if (mapped === "COMPLETED") {
      await applyProviderStatus(sql, userId, w, "COMPLETED", res.provider_reference);
    }
    await audit(sql, userId, "withdrawal.requested", `id=${inserted.id};provider=${dest.type};status=${mapped}`);
    const [row] = await sql`select * from gmm_withdrawals where id = ${inserted.id} and user_id = ${userId}`;
    return mapWithdrawal(row);
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    await sql`update gmm_withdrawals set status = 'FAILED', error_message = ${message}
      where id = ${inserted.id} and user_id = ${userId}`;
    await notify(sql, userId, "transfer.failed", "Transfer not submitted", message);
    await audit(sql, userId, "withdrawal.requested", `id=${inserted.id};provider=${dest.type};status=FAILED`);
    const [row] = await sql`select * from gmm_withdrawals where id = ${inserted.id} and user_id = ${userId}`;
    return mapWithdrawal(row);
  }
}

export async function addDestination(
  sql: Sql,
  userId: string,
  input: { type: string; label: string; external_id: string },
) {
  const type = input.type.toUpperCase().trim();
  const supported = new Set(["PAYPAL", "ACH", "ONEPAY", "CASH_APP", "DEBIT_CARD"]);
  if (!supported.has(type)) throw new GmmError("Unsupported payout destination type");
  const label = input.label.trim();
  const external = input.external_id.trim();
  if (!label || !external) throw new GmmError("Destination label and provider data are required");
  const rows = await sql`insert into gmm_destinations (user_id, type, label, external_id, enabled)
    values (${userId}, ${type}, ${label}, ${external}, true)
    returning *`;
  await audit(sql, userId, "destination.created", `${asInt(rows[0].id)}:${type}`);
  return mapDestination(rows[0]);
}

export async function loadAppState(userId: string): Promise<AppState> {
  const sql = await getSql();
  await ensureOwner(sql, userId);
  await tickCycles(sql, userId);
  const stations = await sql<StationRow>`select * from gmm_stations where user_id = ${userId} order by sort_order`;
  const destRows = await sql`select * from gmm_destinations where user_id = ${userId} order by id`;
  const wdRows = await sql`select * from gmm_withdrawals where user_id = ${userId} order by created_at desc`;
  const noteRows = await sql`select * from gmm_notifications where user_id = ${userId} order by created_at desc limit 50`;
  const withdrawals: WithdrawalState[] = [];
  for (const row of wdRows) {
    withdrawals.push(await reconcileWithdrawal(sql, userId, mapWithdrawal(row)));
  }
  const balance = await getBalance(sql, userId);
  return {
    stations: stations.map(mapStation),
    balance,
    paypal: {
      provider: "paypal",
      configured: paypalConfigured(),
      environment: paypalLiveEnv(),
      mode: "production-required",
    },
    destinations: destRows.map(mapDestination),
    withdrawals,
    providers: providerStatusMap(),
    notifications: noteRows.map((n) => ({
      id: asInt(n.id),
      kind: String(n.kind),
      title: String(n.title),
      message: String(n.message),
      read: asBool(n.read),
      created_at: iso(n.created_at),
    })),
    scanner: {
      enabled: true,
      mode: "real-connectors-only",
      fabricated_results: false,
      cycle_minutes: CYCLE_MINUTES,
    },
  };
}

export async function listLedger(userId: string): Promise<LedgerRow[]> {
  const sql = await getSql();
  await ensureOwner(sql, userId);
  const rows = await sql`select * from gmm_ledger where user_id = ${userId} order by created_at desc`;
  return rows.map(mapLedger);
}

export async function listAudit(userId: string): Promise<AuditRow[]> {
  const sql = await getSql();
  await ensureOwner(sql, userId);
  const rows = await sql`select * from gmm_audit where user_id = ${userId} order by created_at desc limit 200`;
  return rows.map((r) => ({
    id: asInt(r.id),
    action: String(r.action),
    detail: String(r.detail),
    created_at: iso(r.created_at),
  }));
}

export async function listConnectors(userId: string): Promise<ConnectorState[]> {
  const sql = await getSql();
  await ensureOwner(sql, userId);
  const rows = await sql<{
    station_id: number;
    station_name: string;
    connector_type: string;
    endpoint: string | null;
    enabled: boolean;
  }>`select c.station_id, s.name as station_name, c.connector_type, c.endpoint, c.enabled
    from gmm_connectors c
    join gmm_stations s on s.id = c.station_id
    where c.user_id = ${userId}
    order by s.sort_order`;
  return rows.map((r) => ({
    station_id: asInt(r.station_id),
    station_name: String(r.station_name),
    connector_type: String(r.connector_type),
    endpoint: r.endpoint == null ? null : String(r.endpoint),
    enabled: asBool(r.enabled),
  }));
}

export async function saveConnector(
  userId: string,
  input: { station_id: number; connector_type: string; endpoint: string; enabled: boolean },
) {
  const sql = await getSql();
  await ensureOwner(sql, userId);
  if (input.enabled) publicHttpsUrl(input.endpoint);
  await sql`update gmm_connectors
    set connector_type = ${input.connector_type || "http_json"},
        endpoint = ${input.endpoint.trim() || null},
        enabled = ${input.enabled},
        updated_at = now()
    where station_id = ${input.station_id} and user_id = ${userId}`;
  await audit(sql, userId, "connector.updated", `station_id=${input.station_id};enabled=${input.enabled}`);
  return { ok: true };
}

export async function listOpportunities(userId: string, stationId?: number) {
  const sql = await getSql();
  await ensureOwner(sql, userId);
  const rows = stationId
    ? await sql`select * from gmm_opportunities where user_id = ${userId} and station_id = ${stationId} order by created_at desc`
    : await sql`select * from gmm_opportunities where user_id = ${userId} order by created_at desc`;
  return rows.map(mapOpportunity);
}

export async function addOpportunity(
  userId: string,
  input: {
    station_id: number;
    title: string;
    source_url?: string;
    estimated_value?: number | null;
    evidence?: string;
  },
) {
  const sql = await getSql();
  await ensureOwner(sql, userId);
  const title = input.title.trim();
  if (!title) throw new GmmError("Title is required");
  const [station] = await sql`select id from gmm_stations where id = ${input.station_id} and user_id = ${userId}`;
  if (!station) throw new GmmError("Station not found", 404);
  const estimated = input.estimated_value == null ? null : asMoney(input.estimated_value);
  const source = input.source_url?.trim() || null;
  const evidence = input.evidence?.trim() || null;
  const rows = await sql`insert into gmm_opportunities
    (user_id, station_id, title, source_url, estimated_value, state, evidence)
    values (${userId}, ${input.station_id}, ${title}, ${source}, ${estimated}, 'DETECTED', ${evidence})
    returning *`;
  await stationEvent(sql, userId, input.station_id, "OPPORTUNITY_ENTERED", "DETECTED", title);
  await audit(sql, userId, "opportunity.manual_entry", `id=${asInt(rows[0].id)};station_id=${input.station_id}`);
  return mapOpportunity(rows[0]);
}

export async function verifyOpportunity(
  userId: string,
  input: { opportunity_id: number; verified_value: number; evidence: string },
) {
  const sql = await getSql();
  await ensureOwner(sql, userId);
  const [o] = await sql`select * from gmm_opportunities where id = ${input.opportunity_id} and user_id = ${userId}`;
  if (!o) throw new GmmError("Opportunity not found", 404);
  if (!["DETECTED", "ELIGIBLE", "SUBMITTED", "PENDING"].includes(String(o.state))) {
    throw new GmmError("Opportunity is not pending verification", 409);
  }
  if (!o.source_url) throw new GmmError("A source URL is required before verification", 409);
  const value = asMoney(input.verified_value);
  const evidence = `${o.evidence || ""}\nVERIFICATION EVIDENCE: ${input.evidence}`.trim();
  await sql`update gmm_opportunities
    set state = 'VERIFIED', verified_value = ${value}, evidence = ${evidence}, updated_at = now()
    where id = ${input.opportunity_id} and user_id = ${userId}`;
  await stationEvent(sql, userId, asInt(o.station_id), "VERIFICATION", "VERIFIED", `opportunity_id=${input.opportunity_id}`);
  await notify(sql, userId, "earning.verified", "Opportunity verified", "Verified opportunity awaiting settlement reconciliation.");
  await audit(sql, userId, "opportunity.verified", `id=${input.opportunity_id}`);
  const [row] = await sql`select * from gmm_opportunities where id = ${input.opportunity_id} and user_id = ${userId}`;
  return mapOpportunity(row);
}

export async function markNotificationRead(userId: string, id: number) {
  const sql = await getSql();
  await sql`update gmm_notifications set read = true where id = ${id} and user_id = ${userId}`;
  return { ok: true };
}

export async function scanStation(userId: string, stationId: number) {
  const sql = await getSql();
  await ensureOwner(sql, userId);
  return runScan(sql, userId, stationId);
}

export async function withOwnerSql<T>(userId: string, fn: (sql: Sql) => Promise<T>) {
  const sql = await getSql();
  await ensureOwner(sql, userId);
  await tickCycles(sql, userId);
  return fn(sql);
}

export async function health() {
  const sql = await getSql();
  const [row] = await sql<{ n: number }>`select count(*)::int as n from gmm_stations`;
  return {
    status: "ok",
    database: "ok",
    station_count: asInt(row?.n),
    paypal_configured: paypalConfigured(),
    paypal_environment: paypalLiveEnv(),
    production_mode: true,
    scheduler_enabled: true,
    cycle_minutes: CYCLE_MINUTES,
  };
}

export async function handlePaypalWebhook(request: Request) {
  const sql = await getSql();
  const event = (await request.json()) as Record<string, unknown>;
  const eid = typeof event.id === "string" ? event.id : "";
  if (!eid) throw new GmmError("Missing event id");
  const dup = await sql`select id from gmm_webhook_events where event_id = ${eid} limit 1`;
  if (dup.length) return { ok: true, duplicate: true };
  const { verifyPaypalWebhook } = await import("./paypal");
  await verifyPaypalWebhook(request.headers, event);
  await sql`insert into gmm_webhook_events (provider, event_id, event_type, processed)
    values ('PAYPAL', ${eid}, ${String(event.event_type ?? "")}, false)`;
  const resource = (event.resource ?? {}) as Record<string, unknown>;
  const payoutItem = (resource.payout_item ?? {}) as Record<string, unknown>;
  const batchRef = String(resource.payout_batch_id ?? resource.sender_batch_id ?? "");
  const itemStatus = String(resource.transaction_status ?? payoutItem.transaction_status ?? "");
  const eventType = String(event.event_type ?? "");
  if (batchRef) {
    const [wrow] = await sql`select * from gmm_withdrawals where provider_reference = ${batchRef} limit 1`;
    if (wrow) {
      const userId = String(wrow.user_id);
      let status = String(wrow.status);
      if (eventType.endsWith(".SUCCEEDED") || itemStatus === "SUCCESS") status = "COMPLETED";
      else if (eventType.endsWith(".FAILED") || ["FAILED", "DENIED"].includes(itemStatus)) status = "FAILED";
      else if (
        eventType.endsWith(".RETURNED") ||
        eventType.endsWith(".REVERSED") ||
        ["RETURNED", "REVERSED", "BLOCKED"].includes(itemStatus)
      )
        status = "REVERSED";
      else if (eventType.endsWith(".CANCELED") || itemStatus === "CANCELED") status = "CANCELLED";
      await sql`update gmm_withdrawals set status = ${status} where id = ${asInt(wrow.id)}`;
      await sql`update gmm_provider_records set status = ${status}, raw_status = ${JSON.stringify(event)}, updated_at = now()
        where reference = ${batchRef}`;
      const w = mapWithdrawal({ ...wrow, status });
      if (status === "COMPLETED") await applyProviderStatus(sql, userId, w, "COMPLETED", batchRef);
      if (status === "REVERSED") await applyProviderStatus(sql, userId, w, "REVERSED", batchRef);
    }
  }
  await sql`update gmm_webhook_events set processed = true where event_id = ${eid}`;
  return { ok: true, processed: true };
}

export type { NotificationRow };
