import { getSql } from "@/lib/db";
import { auth } from "@/lib/auth/server";
import {
  addDestination,
  addOpportunity,
  controlStation,
  GmmError,
  handlePaypalWebhook,
  health,
  listAudit,
  listConnectors,
  listLedger,
  listOpportunities,
  loadAppState,
  markNotificationRead,
  masterControl,
  requestTransfer,
  saveConnector,
  scanStation,
  verifyOpportunity,
  withOwnerSql,
} from "./core";
import { signOwnerToken, verifyOwnerToken } from "./token";

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

function err(message: string, status = 400) {
  return json({ detail: message }, status);
}

async function bodyOf(request: Request) {
  return (await request.json().catch(() => ({}))) as Record<string, unknown>;
}

async function requireUser(request: Request): Promise<string> {
  const header = request.headers.get("Authorization") || "";
  if (!header.startsWith("Bearer ")) throw new GmmError("Authorization required", 401);
  const token = header.slice(7);
  try {
    const payload = await verifyOwnerToken(token);
    const sql = await getSql();
    const revoked = await sql`select token_jti from gmm_revoked_tokens where token_jti = ${payload.jti} limit 1`;
    if (revoked.length) throw new GmmError("Invalid session", 401);
    return payload.userId;
  } catch (e) {
    if (e instanceof GmmError) throw e;
    throw new GmmError("Invalid session", 401);
  }
}

export async function handleGmmRequest(request: Request): Promise<Response> {
  const url = new URL(request.url);
  const path = url.pathname.replace(/^\/api\/gmm/, "") || "/";
  const method = request.method.toUpperCase();

  try {
    if (method === "POST" && path === "/auth/login") {
      const body = await bodyOf(request);
      const email = String(body.email ?? "").trim().toLowerCase();
      const password = String(body.password ?? "");
      if (!email || !password) return err("Invalid credentials", 401);
      const result = await auth.api.signInEmail({
        body: { email, password },
      });
      const userId = result.user?.id;
      if (!userId) return err("Invalid credentials", 401);
      const { token } = await signOwnerToken(userId, result.user.email ?? email);
      return json({ access_token: token, token_type: "bearer" });
    }

    if (method === "GET" && path === "/health") return json(await health());

    if (method === "POST" && path === "/paypal/webhook") {
      return json(await handlePaypalWebhook(request));
    }

    const userId = await requireUser(request);

    if (method === "GET" && path === "/auth/me") {
      return json({ id: userId });
    }
    if (method === "POST" && path === "/auth/logout") {
      const header = request.headers.get("Authorization") || "";
      const token = header.slice(7);
      try {
        const payload = await verifyOwnerToken(token);
        const sql = await getSql();
        const exp = payload.exp
          ? new Date(payload.exp * 1000).toISOString()
          : new Date(Date.now() + 86400000).toISOString();
        await sql`insert into gmm_revoked_tokens (token_jti, user_id, expires_at)
          values (${payload.jti}, ${userId}, ${exp})
          on conflict (token_jti) do nothing`;
      } catch {
        /* already invalid */
      }
      return json({ status: "logged_out" });
    }

    if (method === "GET" && path === "/stations") {
      const state = await loadAppState(userId);
      return json(state.stations);
    }
    if (method === "GET" && path === "/balance") {
      const state = await loadAppState(userId);
      return json(state.balance);
    }
    if (method === "GET" && path === "/destinations") {
      const state = await loadAppState(userId);
      return json(state.destinations);
    }
    if (method === "GET" && path === "/withdrawals") {
      const state = await loadAppState(userId);
      return json(state.withdrawals);
    }
    if (method === "GET" && (path === "/transactions" || path === "/ledger")) {
      return json(await listLedger(userId));
    }
    if (method === "GET" && path === "/audit") return json(await listAudit(userId));
    if (method === "GET" && path === "/notifications") {
      const state = await loadAppState(userId);
      return json(state.notifications);
    }
    if (method === "GET" && path === "/paypal/status") {
      const state = await loadAppState(userId);
      return json(state.paypal);
    }
    if (method === "GET" && path === "/payout-providers") {
      const state = await loadAppState(userId);
      return json(state.providers);
    }
    if (method === "GET" && path === "/connectors") {
      return json(await listConnectors(userId));
    }
    if (method === "GET" && path === "/scanner/status") {
      const state = await loadAppState(userId);
      return json(state.scanner);
    }
    if (method === "GET" && path === "/opportunities") {
      const stationId = url.searchParams.get("station_id");
      return json(await listOpportunities(userId, stationId ? Number(stationId) : undefined));
    }

    const stationGet = path.match(/^\/stations\/(\d+)$/);
    if (method === "GET" && stationGet) {
      const state = await loadAppState(userId);
      const s = state.stations.find((x) => x.id === Number(stationGet[1]));
      if (!s) return err("Station not found", 404);
      return json(s);
    }

    const control = path.match(/^\/stations\/control\/([a-z]+)$/);
    if (method === "POST" && control) {
      return json(await withOwnerSql(userId, (sql) => masterControl(sql, userId, control[1])));
    }

    const stationAct = path.match(/^\/stations\/(\d+)\/([a-z]+)$/);
    if (method === "POST" && stationAct) {
      if (stationAct[2] === "scan") {
        return json(await scanStation(userId, Number(stationAct[1])));
      }
      return json(
        await withOwnerSql(userId, (sql) =>
          controlStation(sql, userId, Number(stationAct[1]), stationAct[2]),
        ),
      );
    }

    if (method === "POST" && path === "/destinations") {
      const body = await bodyOf(request);
      return json(
        await withOwnerSql(userId, (sql) =>
          addDestination(sql, userId, {
            type: String(body.type ?? ""),
            label: String(body.label ?? ""),
            external_id: String(body.external_id ?? ""),
          }),
        ),
      );
    }

    if (method === "POST" && path === "/withdrawals") {
      const body = await bodyOf(request);
      return json(
        await withOwnerSql(userId, (sql) =>
          requestTransfer(sql, userId, {
            amount: Number(body.amount),
            destination_id: Number(body.destination_id),
            idempotency_key: String(body.idempotency_key ?? crypto.randomUUID()),
          }),
        ),
      );
    }

    if (method === "POST" && path === "/opportunities/manual") {
      const body = await bodyOf(request);
      return json(
        await addOpportunity(userId, {
          station_id: Number(body.station_id),
          title: String(body.title ?? ""),
          source_url: body.source_url ? String(body.source_url) : undefined,
          estimated_value:
            body.estimated_value == null ? null : Number(body.estimated_value),
          evidence: body.evidence ? String(body.evidence) : undefined,
        }),
      );
    }

    const verify = path.match(/^\/opportunities\/(\d+)\/verify$/);
    if (method === "POST" && verify) {
      const body = await bodyOf(request);
      return json(
        await verifyOpportunity(userId, {
          opportunity_id: Number(verify[1]),
          verified_value: Number(body.verified_value),
          evidence: String(body.evidence ?? ""),
        }),
      );
    }

    const conn = path.match(/^\/connectors\/(\d+)$/);
    if (method === "POST" && conn) {
      const body = await bodyOf(request);
      return json(
        await saveConnector(userId, {
          station_id: Number(conn[1]),
          connector_type: String(body.connector_type ?? "http_json"),
          endpoint: String(body.endpoint ?? ""),
          enabled: Boolean(body.enabled),
        }),
      );
    }

    const note = path.match(/^\/notifications\/(\d+)\/read$/);
    if (method === "POST" && note) {
      return json(await markNotificationRead(userId, Number(note[1])));
    }

    return err("Not found", 404);
  } catch (e) {
    if (e instanceof GmmError) return err(e.message, e.status);
    const message = e instanceof Error ? e.message : "Server error";
    if (/invalid credentials|unauthorized|invalid email or password/i.test(message)) {
      return err("Invalid credentials", 401);
    }
    return err(message, 500);
  }
}
