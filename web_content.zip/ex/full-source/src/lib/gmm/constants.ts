export const CYCLE_MINUTES = 90;

export const STATION_NAMES = [
  "Free Money",
  "Unclaimed Property Station",
  "Refund Recovery Station",
  "Rebate Station",
  "Cashback Station",
  "Rewards Station",
  "Promotional Bonus Station",
  "Fee Recovery Station",
  "Overpayment Recovery Station",
  "Subscription Credit Station",
  "Settlement & Claims Station",
  "Business Incentive Station",
  "Public Opportunity Station",
  "Revenue Opportunity Station",
  "Reinvestment Station",
  "Earnings & Transfer Station",
] as const;

export const STATION_BLURBS = [
  "Find legitimate, verified opportunities to receive money at no upfront cost.",
  "Find public/state unclaimed money and property.",
  "Find refunds, reimbursements, and returned payments.",
  "Find eligible rebates and verified rebate programs.",
  "Find legitimate cashback opportunities.",
  "Find verified rewards and incentive programs.",
  "Find legitimate promotional bonus programs.",
  "Find recoverable fees and fee credits.",
  "Find verified overpayment recovery opportunities.",
  "Find legitimate subscription credits.",
  "Find verified settlements and claims.",
  "Find legitimate business incentives.",
  "Find public opportunities from legitimate sources.",
  "Find legitimate revenue opportunities.",
  "Manage verified reinvestment activity.",
  "Earnings & Transfer — manage verified earnings and transfers.",
] as const;

export const DESTINATION_TYPES = [
  ["PAYPAL", "PayPal"],
  ["ACH", "Bank / ACH"],
  ["DEBIT_CARD", "Debit Card"],
  ["CASH_APP", "Cash App"],
  ["ONEPAY", "OnePay"],
] as const;

export const DESTINATION_HINTS: Record<string, string> = {
  PAYPAL: "PayPal recipient email",
  ACH: 'JSON: {"access_token":"...","account_id":"...","legal_name":"...","network":"ach","ach_class":"ppd"}',
  ONEPAY:
    "JSON: Plaid access_token/account_id for the linked OnePay account",
  CASH_APP: 'JSON: {"merchant_id":"...","customer_id":"...","grant_id":"..."}',
  DEBIT_CARD:
    "JSON with recipient_primary_account_number or recipient_payment_credential_reference",
};

export const CONTROL_ACTIONS = [
  "start",
  "stop",
  "pause",
  "emergency",
  "enable",
  "disable",
] as const;

export type ControlAction = (typeof CONTROL_ACTIONS)[number];
