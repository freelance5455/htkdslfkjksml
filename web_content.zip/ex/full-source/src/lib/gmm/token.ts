import { randomBytes } from "node:crypto";
import * as jose from "jose";
import { env } from "@/lib/env.server";

const globalRef = globalThis as typeof globalThis & {
  __gmmJwtSecret__?: Uint8Array;
};

function jwtSecret(): Uint8Array {
  const fromEnv = env("BETTER_AUTH_SECRET") || env("AUTH_SECRET") || env("GMM_JWT_SECRET");
  if (fromEnv) return new TextEncoder().encode(fromEnv);
  globalRef.__gmmJwtSecret__ ??= randomBytes(32);
  return globalRef.__gmmJwtSecret__;
}

export async function signOwnerToken(userId: string, email: string) {
  const jti = randomBytes(16).toString("hex");
  const token = await new jose.SignJWT({ email })
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(userId)
    .setJti(jti)
    .setIssuedAt()
    .setExpirationTime("30d")
    .sign(jwtSecret());
  return { token, jti };
}

export async function verifyOwnerToken(token: string) {
  const { payload } = await jose.jwtVerify(token, jwtSecret());
  if (!payload.sub || !payload.jti) throw new Error("Invalid session");
  return {
    userId: payload.sub,
    email: typeof payload.email === "string" ? payload.email : "",
    jti: payload.jti,
    exp: payload.exp,
  };
}
