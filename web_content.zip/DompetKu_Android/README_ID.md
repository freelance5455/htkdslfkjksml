# DompetKu — proyek Android offline

Ini adalah proyek Android untuk membungkus aplikasi DompetKu offline berbasis HTML menjadi APK.

## Build di AndroidIDE
1. Ekstrak ZIP ini.
2. Buka folder `DompetKu_Android` sebagai project di AndroidIDE.
3. Tunggu Gradle sync selesai.
4. Jalankan **Build > Assemble Debug APK**.
5. APK biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.
6. Install APK tersebut di HP.

Project membutuhkan Android Gradle Plugin 8.6.1 dan compileSdk 35. Jika AndroidIDE meminta SDK/Build Tools, pasang versi yang sesuai.

Aplikasi memuat `index.html` dari assets secara lokal. Tidak ada server atau login yang diperlukan untuk fitur offline.
