CONNECTLY V2 SETUP

1. Run database-v2.sql in Supabase SQL Editor.
2. Deploy the Edge Function:
   Name: connectly-login
   File: supabase/functions/connectly-login/index.ts

3. Ensure the Edge Function has these Supabase environment variables:
   SUPABASE_URL
   SUPABASE_SERVICE_ROLE_KEY
   SUPABASE_ANON_KEY or SUPABASE_PUBLISHABLE_KEY

4. Test registration and login with two accounts.

Features:
- Email, password and username registration.
- Username or email login.
- WhatsApp-inspired chat interface.
- Recent conversations.
- Text messages.
- Voice message recording and playback.

Updates, Communities and Calls are interface placeholders.
Voice messages require HTTPS, microphone permission and the
existing connectly-voice storage bucket and policies.

This is a starter app, not a security-audited production service.
