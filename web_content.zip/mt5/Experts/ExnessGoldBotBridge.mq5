#property strict
#property version "1.0"

input string BridgeUrl = "https://YOUR-VPS-DOMAIN";
input string ApiToken = "CHANGE_ME_LONG_RANDOM_TOKEN";
input int PollSeconds = 3;
input bool DemoOnly = true;

string JsonEscape(string s) { StringReplace(s, "\\", "\\\\"); StringReplace(s, "\"", "\\\""); return s; }

string HttpGet(string url) {
   char data[], result[]; string headers = "X-API-Token: " + ApiToken + "\r\n"; string result_headers;
   ResetLastError();
   int code = WebRequest("GET", url, headers, 5000, data, result, result_headers);
   if(code == -1) { Print("Bridge GET failed: ", GetLastError()); return ""; }
   return CharArrayToString(result);
}

bool HttpPost(string url, string body) {
   char data[], result[]; string headers = "Content-Type: application/json\r\nX-API-Token: " + ApiToken + "\r\n"; string result_headers;
   StringToCharArray(body, data, 0, WHOLE_ARRAY, CP_UTF8);
   ResetLastError();
   int code = WebRequest("POST", url, headers, 5000, data, result, result_headers);
   if(code == -1) { Print("Bridge POST failed: ", GetLastError()); return false; }
   return code >= 200 && code < 300;
}

void SendStatus() {
   string account = IntegerToString((long)AccountInfoInteger(ACCOUNT_LOGIN));
   string server = JsonEscape(AccountInfoString(ACCOUNT_SERVER));
   double balance = AccountInfoDouble(ACCOUNT_BALANCE);
   double equity = AccountInfoDouble(ACCOUNT_EQUITY);
   string body = StringFormat("{\"connected\":true,\"account\":\"%s\",\"server\":\"%s\",\"balance\":%.2f,\"equity\":%.2f,\"symbol\":\"XAUUSD\",\"bot_running\":%s}", account, server, balance, equity, DemoOnly ? "false" : "true");
   HttpPost(BridgeUrl + "/mt5/status", body);
}

void PollCommand() {
   string response = HttpGet(BridgeUrl + "/command/next");
   if(response == "") return;
   if(StringFind(response, "\"action\":\"START\"") >= 0) {
      Print("START command received. DemoOnly=", DemoOnly);
      // Production strategy execution belongs here. Keep DemoOnly=true until independently tested.
   } else if(StringFind(response, "\"action\":\"STOP\"") >= 0) {
      Print("STOP command received.");
   } else if(StringFind(response, "\"action\":\"CLOSE_ALL\"") >= 0) {
      Print("CLOSE_ALL command received. No order action is executed while DemoOnly=true.");
   }
}

int OnInit() {
   EventSetTimer(PollSeconds);
   SendStatus();
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason) { EventKillTimer(); }
void OnTimer() { PollCommand(); SendStatus(); }
