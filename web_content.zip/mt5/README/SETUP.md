# MT5 EA setup

1. Copy `ExnessGoldBotBridge.mq5` into MT5 `MQL5/Experts/`.
2. Compile it in MetaEditor.
3. In MT5, enable WebRequest for the exact bridge URL under Tools -> Options -> Expert Advisors.
4. Set `BridgeUrl` and `ApiToken` to match the VPS.
5. Attach the EA to an XAUUSD chart.
6. Keep `DemoOnly=true` while testing connectivity.

The EA currently reports account/status data and receives control commands. It deliberately does not execute trades. A production trading strategy should be added only after backtesting, demo testing, authentication hardening, and risk controls are independently validated.
