/* JOSTECH — BANQUE DE QUESTIONNAIRES ET D'EXAMENS (PHASE 3) */
const QUIZZES = [
  {
    id: "quiz-ig-1",
    discId: 1,
    mode: "training",
    title: "Quiz d'entraînement — Architecture & Binaire",
    subtitle: "01. Informatique générale • Niveau 1",
    durationMin: 10,
    questions: [
      {
        type: "single",
        q: "Quelle est l'idée révolutionnaire du modèle de Von Neumann (1945) ?",
        options: [
          "Utiliser deux mémoires physiques séparées pour le texte et les nombres",
          "Stocker dans une même mémoire RAM les données et les instructions du programme",
          "Remplacer la mémoire RAM par des câbles manuels",
          "Supprimer l'Unité Arithmétique et Logique"
        ],
        answer: 1,
        explanation: "Avant 1945 (ENIAC), il fallait recâbler la machine. Von Neumann stocke les instructions en binaire dans la même RAM que les données."
      },
      {
        type: "tf",
        q: "Avec 8 bits (1 octet), on peut représenter exactement 256 valeurs entières positives (de 0 à 255).",
        answer: true,
        explanation: "2 puissance 8 = 256 combinaisons possibles, allant de 00000000 (0) à 11111111 (255)."
      },
      {
        type: "multi",
        q: "Parmi ces organes, lesquels font partie des 4 unités du modèle de Von Neumann ?",
        options: [
          "Unité Arithmétique et Logique (UAL)",
          "Carte graphique 3D obligatoire",
          "Unité de Contrôle (UC)",
          "Mémoire Centrale (RAM)"
        ],
        answers: [0, 2, 3],
        explanation: "Les 4 organes fondamentaux sont : UAL, UC, Mémoire Centrale (RAM) et Entrées/Sorties (E/S)."
      },
      {
        type: "short",
        q: "Quel registre spécial de l'Unité de Contrôle contient toujours l'adresse de la prochaine instruction à lire ?",
        accepted: ["pc", "compteur ordinal", "program counter"],
        displayAnswer: "Compteur Ordinal (PC / Program Counter)",
        explanation: "Le PC (Program Counter) pointe vers l'adresse suivante et s'incrémente automatiquement durant l'étape Fetch."
      },
      {
        type: "single",
        q: "Que vaut le nombre binaire 101101 (base 2) en décimal (base 10) ?",
        options: ["37", "45", "53", "43"],
        answer: 1,
        explanation: "Poids : 32 + 0 + 8 + 4 + 0 + 1 = 45."
      },
      {
        type: "single",
        q: "Comment s'écrit 45 (base 10) en hexadécimal (base 16) ?",
        options: ["2C", "2D", "3D", "1F"],
        answer: 1,
        explanation: "45 en binaire = 0010 1101. 0010 = 2 et 1101 = 13 = D, donc 2D."
      }
    ]
  },
  {
    id: "exam-ig-full",
    discId: 1,
    mode: "exam",
    title: "Examen Officiel — Informatique générale",
    subtitle: "01. Informatique générale • Niveaux 1, 2 & 3",
    durationMin: 15,
    questions: [
      {
        type: "single",
        q: "Un processeur dispose d'un bus d'adresses de 16 bits (1 case = 1 octet). Quelle RAM maximale peut-il adresser ?",
        options: ["16 Kio", "32 Kio", "64 Kio", "4 Gio"],
        answer: 2,
        explanation: "2^16 = 65 536 octets. Divisé par 1024 octets/Kio = 64 Kio."
      },
      {
        type: "tf",
        q: "Le bus de données est strictement unidirectionnel (uniquement du processeur vers la RAM).",
        answer: false,
        explanation: "C'est le bus d'adresses qui est unidirectionnel. Le bus de données est bidirectionnel (lecture ET écriture)."
      },
      {
        type: "single",
        q: "Quel est le codage de -25 en Complément à 2 sur 8 bits ?",
        options: ["1001 1001", "1110 0110", "1110 0111", "0001 1001"],
        answer: 2,
        explanation: "+25 = 0001 1001. Inversion = 1110 0110. +1 = 1110 0111."
      },
      {
        type: "single",
        q: "Selon la 1re Loi de De Morgan, à quoi équivaut NON(A ET B) ?",
        options: ["(NON A) OU (NON B)", "(NON A) ET (NON B)", "A OU B", "A XOR B"],
        answer: 0,
        explanation: "La négation casse la barre et inverse l'opérateur ET en OU : NON(A·B) = Ā + B̄."
      },
      {
        type: "multi",
        q: "Quelles affirmations sur les mémoires Caches sont exactes ?",
        options: [
          "Le cache L1 utilise la technologie SRAM (très rapide)",
          "La RAM (DRAM) est plus rapide que le cache L1",
          "Une ligne de cache transfère souvent 64 octets d'un coup",
          "La localité spatiale concerne l'accès aux cases mémoire voisines"
        ],
        answers: [0, 2, 3],
        explanation: "Le cache SRAM L1 (~1 ns) est ~80x plus rapide que la RAM DRAM (~80 ns)."
      },
      {
        type: "short",
        q: "Quelle porte logique est dite « universelle » et donne son nom aux mémoires Flash modernes ?",
        accepted: ["nand", "porte nand", "non-et", "non et"],
        displayAnswer: "NAND (NON-ET)",
        explanation: "Avec uniquement des portes NAND, on peut recréer toutes les autres portes logiques (NOT, AND, OR, XOR)."
      },
      {
        type: "single",
        q: "Dans le cycle CPU (Fetch-Decode-Execute), que réalise l'étape FETCH ?",
        options: [
          "Aller chercher l'instruction en mémoire RAM via le PC",
          "Additionner deux registres dans l'UAL",
          "Afficher le résultat à l'écran",
          "Éteindre le processeur"
        ],
        answer: 0,
        explanation: "Fetch signifie recherche : l'UC lit l'instruction pointée par le Compteur Ordinal (PC)."
      },
      {
        type: "tf",
        q: "L'architecture Harvard modifiée des CPU modernes sépare le cache L1 en L1i (instructions) et L1d (données).",
        answer: true,
        explanation: "Cela permet de lire simultanément une instruction et une donnée sans goulot d'étranglement."
      }
    ]
  },
  {
    id: "quiz-prog-1",
    discId: 2,
    mode: "training",
    title: "Quiz d'entraînement — Algorithmique & Python",
    subtitle: "02. Programmation informatique • Niveau 1",
    durationMin: 10,
    questions: [
      {
        type: "multi",
        q: "Quelles propriétés sont exigées pour qu'un algorithme soit scientifiquement valide ?",
        options: ["Finitude", "Déterminisme", "Être écrit obligatoirement en Python", "Effectivité"],
        answers: [0, 1, 3],
        explanation: "Un algorithme est indépendant du langage : il doit se terminer (finitude), être non ambigu (déterminisme) et exécutable (effectivité)."
      },
      {
        type: "single",
        q: "En Python, que valent respectivement 7 // 2 et 7 % 2 ?",
        options: ["3.5 et 1", "3 et 1", "3 et 0", "4 et 1"],
        answer: 1,
        explanation: "// est la division entière (quotient = 3) et % est le modulo (reste = 1)."
      },
      {
        type: "tf",
        q: "En Python, une fonction sans mot-clé « return » renvoie automatiquement la valeur numérique 0.",
        answer: false,
        explanation: "Elle renvoie l'objet spécial « None » (absence de valeur), ce qui provoque une erreur si on essaie de l'additionner."
      },
      {
        type: "short",
        q: "Quel mot-clé termine une fonction et livre un résultat calculé au reste du programme ?",
        accepted: ["return"],
        displayAnswer: "return",
        explanation: "Contrairement à print() qui n'affiche que du texte, return transmet une vraie donnée réutilisable."
      },
      {
        type: "single",
        q: "Que vaut « a » après ces 4 lignes : a = 10 ; b = 20 ; a = b ; b = a ?",
        options: ["10", "30", "20", "Erreur"],
        answer: 2,
        explanation: "a = b écrase 10 par 20. Pour échanger deux variables, il faut une variable temporaire temp."
      },
      {
        type: "single",
        q: "Quelle boucle choisir quand on ne connaît pas d'avance le nombre de répétitions (ex: saisie mot de passe) ?",
        options: ["La boucle for", "La boucle while", "Une condition if simple", "Une variable constante"],
        answer: 1,
        explanation: "La boucle while (« Tant que ») continue jusqu'à ce qu'une condition dynamique devienne fausse."
      }
    ]
  },
  {
    id: "exam-prog-full",
    discId: 2,
    mode: "exam",
    title: "Examen Officiel — Programmation informatique",
    subtitle: "02. Programmation • Python, C (Pointeurs) & POO/Big-O",
    durationMin: 15,
    questions: [
      {
        type: "single",
        q: "En Python, quelle suite de nombres génère exactement range(1, 5) ?",
        options: ["1, 2, 3, 4", "1, 2, 3, 4, 5", "0, 1, 2, 3, 4", "2, 3, 4, 5"],
        answer: 0,
        explanation: "Dans range(debut, fin), la borne de début (1) est incluse et la borne de fin (5) est toujours exclue."
      },
      {
        type: "tf",
        q: "Pour éviter un Stack Overflow en récursivité, il faut obligatoirement un cas de base et une convergence.",
        answer: true,
        explanation: "Sans cas de base ni convergence, les appels s'empilent en RAM jusqu'à saturation (RecursionError)."
      },
      {
        type: "single",
        q: "En Langage C, quel opérateur obtient l'adresse mémoire RAM d'une variable x ?",
        options: ["*x", "&x", "#x", "@x"],
        answer: 1,
        explanation: "&x donne l'adresse de x ; *p lit ou modifie la valeur pointée par p."
      },
      {
        type: "multi",
        q: "Quels sont de vrais bugs ou failles de sécurité liés à la mémoire en Langage C ?",
        options: [
          "Fuite mémoire (malloc sans free)",
          "Segmentation Fault sur pointeur sauvage non initialisé",
          "Use-After-Free (utilisation après libération)",
          "Indentation avec des tabulations"
        ],
        answers: [0, 1, 2],
        explanation: "En C, la gestion manuelle du Tas (malloc/free) et des pointeurs demande une rigueur absolue."
      },
      {
        type: "single",
        q: "Un tableau « int t[4] » démarre à l'adresse 0x2000 (sizeof(int) = 4 octets). Quelle est l'adresse de t[2] ?",
        options: ["0x2002", "0x2004", "0x2008", "0x2012"],
        answer: 2,
        explanation: "0x2000 + (2 × 4 octets) = 0x2008."
      },
      {
        type: "short",
        q: "Quel pilier de la POO protège les attributs sensibles d'un objet contre une modification directe illégale ?",
        accepted: ["encapsulation", "l'encapsulation", "l encapsulation"],
        displayAnswer: "Encapsulation",
        explanation: "L'encapsulation impose de passer par des méthodes de validation plutôt que de modifier directement les attributs internes."
      },
      {
        type: "single",
        q: "Combien d'étapes au maximum exige une recherche dichotomique O(log₂ n) sur 1 024 000 éléments triés ?",
        options: ["Environ 1 000 étapes", "Environ 20 étapes", "512 000 étapes", "1 étape"],
        answer: 1,
        explanation: "2^20 = 1 048 576 : en divisant l'intervalle par 2 à chaque étape, 20 comparaisons suffisent !"
      },
      {
        type: "tf",
        q: "Parcourir une liste de taille n et tester « if x in autre_liste_de_taille_n » a une complexité cachée de O(n²).",
        answer: true,
        explanation: "« x in liste » effectue un parcours linéaire O(n) à chaque tour de boucle, soit n × n = O(n²)."
      }
    ]
  },
  {
    id: "quiz-web-1",
    discId: 3,
    mode: "training",
    title: "Quiz d'entraînement — HTML5 & CSS3",
    subtitle: "03. Développement Web et mobile • Niveau 1",
    durationMin: 10,
    questions: [
      {
        type: "single",
        q: "Quel service réseau traduit un nom de domaine comme « jostech.edu » en adresse IP numérique ?",
        options: ["HTTP", "CSS", "DNS", "DOM"],
        answer: 2,
        explanation: "Le DNS (Domain Name System) joue le rôle d'annuaire entre noms lisibles et adresses IP."
      },
      {
        type: "tf",
        q: "HTML5 est un langage de programmation permettant d'écrire des boucles et des conditions logiques.",
        answer: false,
        explanation: "HTML5 est un langage de balisage structurel, pas un langage de programmation (c'est JavaScript qui programme côté navigateur)."
      },
      {
        type: "multi",
        q: "Parmi ces balises, lesquelles sont de vraies balises sémantiques HTML5 ?",
        options: ["<article>", "<div>", "<nav>", "<main>"],
        answers: [0, 2, 3],
        explanation: "<div> est un conteneur neutre sans signification sémantique, contrairement à <article>, <nav> et <main>."
      },
      {
        type: "short",
        q: "Quelle valeur de la propriété CSS box-sizing inclut le padding et la bordure à l'intérieur de la largeur width ?",
        accepted: ["border-box", "box-sizing: border-box", "border box"],
        displayAnswer: "border-box",
        explanation: "Avec box-sizing: border-box, une boîte de width: 100% ne déborde jamais à cause de son padding."
      },
      {
        type: "single",
        q: "En mode par défaut (content-box), width: 200px, padding: 20px (gauche/droite), border: 5px. Largeur totale ?",
        options: ["200 px", "225 px", "240 px", "250 px"],
        answer: 3,
        explanation: "200 + 20 + 20 + 5 + 5 = 250 px."
      },
      {
        type: "single",
        q: "En Flexbox (en ligne), quelle propriété centre les éléments sur l'axe vertical (transversal) ?",
        options: ["justify-content", "align-items", "gap", "flex-direction"],
        answer: 1,
        explanation: "justify-content gère l'axe principal, tandis qu'align-items aligne sur l'axe transversal."
      }
    ]
  },
  {
    id: "exam-web-full",
    discId: 3,
    mode: "exam",
    title: "Examen Officiel — Développement Web & Mobile",
    subtitle: "03. Web & Mobile • HTML/CSS, JS/XSS & API REST/PWA",
    durationMin: 15,
    questions: [
      {
        type: "single",
        q: "Pourquoi utiliser element.textContent plutôt que element.innerHTML pour afficher une saisie utilisateur ?",
        options: [
          "Pour rendre le texte plus grand",
          "Pour empêcher l'exécution de scripts malveillants (faille XSS)",
          "Pour traduire automatiquement la page",
          "Pour économiser la batterie"
        ],
        answer: 1,
        explanation: "textContent affiche les balises <script> comme du texte brut inoffensif, bloquant les attaques XSS."
      },
      {
        type: "tf",
        q: "En JavaScript, JSON.stringify() convertit un objet ou tableau JS en chaîne de caractères texte.",
        answer: true,
        explanation: "C'est indispensable avant de sauvegarder dans localStorage ou d'envoyer des données à une API REST."
      },
      {
        type: "single",
        q: "Dans quel ordre s'affichent : console.log('A'); setTimeout(()=>console.log('B'), 0); console.log('C'); ?",
        options: ["A, B, C", "B, A, C", "A, C, B", "C, B, A"],
        answer: 2,
        explanation: "setTimeout passe par la file asynchrone de l'Event Loop et attend la fin du code synchrone (A puis C)."
      },
      {
        type: "multi",
        q: "En API REST, quelles méthodes HTTP sont idempotentes (répéter la requête produit le même état final) ?",
        options: ["GET", "POST", "PUT", "DELETE"],
        answers: [0, 2, 3],
        explanation: "Répéter POST crée plusieurs ressources en double ; GET, PUT et DELETE sont idempotents."
      },
      {
        type: "single",
        q: "Un étudiant connecté tente de supprimer un cours (action réservée à l'admin). Quel code HTTP renvoyer ?",
        options: ["200 OK", "401 Unauthorized", "403 Forbidden", "404 Not Found"],
        answer: 2,
        explanation: "401 = non authentifié ; 403 = authentifié mais permissions insuffisantes."
      },
      {
        type: "short",
        q: "Quel script d'une PWA tourne en arrière-plan pour gérer le cache et le mode hors connexion ?",
        accepted: ["service worker", "service-worker", "un service worker", "service workers"],
        displayAnswer: "Service Worker",
        explanation: "Le Service Worker intercepte les requêtes réseau (ex: stratégie Cache-First) pour permettre le mode hors ligne."
      },
      {
        type: "tf",
        q: "Il est sûr d'écrire la clé secrète d'une API d'IA payante directement dans app.js côté navigateur.",
        answer: false,
        explanation: "Tout code Front-end est visible par l'utilisateur. Les clés secrètes doivent toujours rester côté serveur."
      },
      {
        type: "single",
        q: "À quoi sert la 3e partie d'un jeton JWT (la Signature) ?",
        options: [
          "Garantir que le jeton n'a pas été modifié par un attaquant",
          "Compresser les images CSS",
          "Chiffrer l'écran tactile",
          "Remplacer le DNS"
        ],
        answer: 0,
        explanation: "Si un attaquant modifie le rôle dans le Payload du JWT, la signature cryptographique devient immédiatement invalide."
      }
    ]
  }
];