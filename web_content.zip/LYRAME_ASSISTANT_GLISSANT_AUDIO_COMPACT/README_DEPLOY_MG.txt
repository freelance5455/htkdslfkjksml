LYRAME — Espace propriétaire dans Paramètres

Source: V96.8 (messages modernes) ; modification ciblée.

- Entrée Administration LYRAME déplacée du Menu vers le haut de Paramètres.
- Un seul bouton Administration (ID existant conservé), sans doublon dans Menu.
- Visible uniquement pour le compte connecté christionalain1@gmail.com.
- La validation email Firebase reste OBLIGATOIRE pour l'accès au panneau et les écritures. Si l'email n'est pas validé, l'entrée est désactivée avec un message explicatif.
- Fonctionnalités et données administrateur actuelles maintenues, aucun changement de backend.
- IMPORTANT : le code source fourni ne contient PAS de module Gmail/Automation autonome; cette version restaure l'accès au panneau Administration existant, sans prétendre activer de nouvelles automatisations.
- Aucune indication de version technique ajoutée à l'interface utilisateur.
- Aucun changement de Firebase, firebase.json, .firebaserc, Firestore rules, Cloudinary, Floot ou des autres fonctions.

Termux:
cd ~ && unzip -o /sdcard/Download/LYRAME_V96_9_GESTION_PROPRIETAIRE.zip -d ~ && cd ~/LYRAME_V96_9_GESTION_PROPRIETAIRE && node --check public/script.js && node verify_owner_settings.cjs && firebase deploy --only hosting --project rinix-ai-22f55

Après deploy: ouvrir Paramètres avec le compte fondateur, voir «Espace propriétaire» > «Administration LYRAME». Si le mail n'est pas validé, le message de validation apparait à la place de l'accès actif.
