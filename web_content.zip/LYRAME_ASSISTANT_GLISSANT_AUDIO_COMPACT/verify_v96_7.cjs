#!/usr/bin/env node
'use strict';
const fs=require('node:fs'), cp=require('node:child_process'), crypto=require('node:crypto'), assert=require('node:assert/strict');
const h=fs.readFileSync('public/index.html','utf8'), j=fs.readFileSync('public/script.js','utf8'), c=fs.readFileSync('public/v96_7_message_navigation.css','utf8');
assert.equal((h.match(/id="conv-info-btn"/g)||[]).length,1,'only one contextual chat settings trigger');
assert(h.includes('id="conv-info-btn"') && h.includes('id="conv-audio-call-btn"') && h.includes('id="conv-video-call-btn"'),'chat call controls preserved');
assert(h.includes('href="/v96_7_message_navigation.css?v=967"'),'stylesheet load');
assert(/script\.js\?v=web96-[7-9]-[a-z-]+/.test(h),'script cache refreshed');
assert(!h.includes('id="settings-conversation-context-btn"'),'no duplicate chat-specific settings in global settings');
assert(j.includes('$("#conv-info-btn")?.addEventListener('),'chat settings has existing event listener');
assert(j.includes('function openConversationSettings()'),'chat modal remains');
assert(j.includes('lyrameDisableNativeChatSelection'),'Android selection prevention');
assert(j.includes('event.preventDefault();'),'selection/contextmenu cancelled');
assert(!j.includes('selectMessageText('),'no deliberate triggering of native Android selector');
assert(j.includes('Copier') && j.includes('openMessageActionSheet'),'custom message actions preserved');
assert(c.includes('-webkit-user-select: none') && c.includes('-webkit-touch-callout: none'),'CSS prevents native text selection');
assert(c.includes('#conv-text') && c.includes('user-select:text'),'composer select/copy/paste preserved');
assert.equal((h.match(/data-nav="settings"/g)||[]).length,1,'global settings navigation remains unique');
for(const [rel,digest] of Object.entries(JSON.parse(fs.readFileSync('protected_hashes_v96_5.json','utf8')))){
 assert.equal(crypto.createHash('sha256').update(fs.readFileSync(rel)).digest('hex'),digest,'protected file unchanged: '+rel);
}
const chk=cp.spawnSync('node',['--check','public/script.js'],{encoding:'utf8'});
assert.equal(chk.status,0,chk.stderr);
console.log('OK — Android native text selection in message bubbles blocked; LYRAME message menu still accessible; chat settings restored at header; only one global settings nav; protected files unchanged; JavaScript valid.');
