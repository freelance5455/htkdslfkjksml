LYRAME V96.3 — NAVIGATION RETOUR ANDROID
======================================

BASE : LYRAME_V96_2_NAVIGATION_ANDROID (source ZIP teo aloha).

IZAY NAHITSY :
- Bouton/geste RETOUR Android no mitantana ny retour écran amin'ny History API.
- Accueil -> Messages -> Conversation -> Android Retour : Messages -> Accueil.
- Oubli/Inscription -> Android Retour : pejy authentification teo aloha.
- Raha misy popup/modal, media-viewer, story, assistant history misokatra :
  ny Android Retour no manidy azy aloha, fa tsy miova écran.
- Tsy ampiana bokotra Retour na Home amin'ny écran LYRAME.
- Ny Home Android dia avela ho an'ny Android, tsy sokafana/soloin'ny JS.
- Nesorina ny bokotra "Retour à la connexion" amin'ny écran Oubli de mot de passe.
- Ny logo "LYRAME" (Accueil), ary ireo tabs Accueil/Messages/Profil dia
afa-piasaina ho navigation LYRAME mahazatra, fa tsy bouton Retour Android.
- Nohatsaraina ny fitahirizana ny historique; tsy mamorona entrée mitovy.

TSY NOKITIHINA :
- firebase.json sy .firebaserc : byte-identiques amin'ny V96.2.
- Firestore rules : tsy nisy fichier rules novaina na deploy.
- sw.js : byte-identique, push notifications tsy voakitika.
- Firestore collections, authentification, Cloudinary, Floot : tsy novaina.
- Splash / 3 feeds / fonctionnalités hafa : nomena ny base efa nisy.

FIZAHANA TERMUX (TSY DEPLOY) :
  cd ~ && unzip -o /sdcard/Download/LYRAME_V96_3_NAVIGATION_ANDROID.zip -d ~ && cd ~/LYRAME_V96_3_NAVIGATION_ANDROID && node installer_v96_3.cjs --verify

DEPLOY FIREBASE HOSTING IRERY (REHEFA VONONA) :
  cd ~/LYRAME_V96_3_NAVIGATION_ANDROID && node installer_v96_3.cjs --deploy

NA COMMANDE NENTIM-PAHARAZANA :
  cd ~/LYRAME_V96_3_NAVIGATION_ANDROID && node --check public/script.js && firebase deploy --only hosting --project rinix-ai-22f55

TEST AMIN'NY TELEPHONE :
  1. Sokafy LYRAME APK -> Accueil.
  2. Midira Messages -> Conversation, dia tsindrio Retour Android indroa.
     Tokony Conversation -> Messages -> Accueil.
  3. Sokafy story na sary lehibe : Android Retour manidy ilay sary/storie.
  4. Sokafy menu/modal : Android Retour manidy ilay menu aloha.
  5. Ao Accueil tsy misy popup, Android Retour dia tokony hiverina any
     ivelan'ny app araka ny gestion native; Android Home = Android mihitsy.
  6. Fitsapana fanampiny: Login -> Inscription -> Android Retour.

FANAMARIHANA :
Ny fanitsiana dia amin'ny WEB / Firebase Hosting ihany, fa tsy manova
Java/Kotlin na APK. Raha onBackPressed() custom WebView no misakana ny
Android Retour tsy hahazo navigateur history, tsy maintsy ahitsy ny source
native APK. Ho an'ny TWA/PWA mampiasa browser history dia natao hifanaraka.
Tsy voasedra mivantana tamin'ny téléphone / APK ity ZIP ity; jereo ny tests.
