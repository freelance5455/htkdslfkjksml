LYRAME — ASSISTANT GLISSANT + AUDIO VOCAL COMPACT

Fanovana:
- Ny icône Assistant LYRAME ao amin'ny conversation dia azo sintonina amin'ny rantsantanana, avy eo mijanona amin'ny sisiny gauche na droit.
- Tsindry tsotra amin'ny icône: manokatra ny Assistant LYRAME toy ny teo aloha.
- Tadidina amin'ny localStorage eo amin'ny téléphone ny toerana nosafidian'ny mpampiasa.
- Voafetra ao anatin'ny faritry ny hafatra ny toerana mba tsy hanakonana header sy barre de saisie.
- Nesorina tao amin'ny code ny audio-wave haingon-trano teo ambonin'ny lecteur audio.
- Ny lecteur audio (Play/Pause, progression, menu native) dia mbola miasa; nohafohezina ny bulle.
- Splash Signature Motion / logo / background: tsy novaina.
- Firebase config / firestore.rules / account data: tsy novaina.
- Floot sy Cloudinary: tsy novaina.

Google Drive: christionalain1@gmail.com ONLY.

TERMUX:
cd ~ && unzip -o /sdcard/Download/LYRAME_ASSISTANT_GLISSANT_AUDIO_COMPACT.zip -d ~ && cd ~/LYRAME_ASSISTANT_GLISSANT_AUDIO_COMPACT && node --check public/script.js && node --check public/lyrame_fab_glissant.js && node verify_assistant_audio.cjs && firebase deploy --only hosting --project rinix-ai-22f55
