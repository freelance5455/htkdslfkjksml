/* ============================================================
   LYRAME — script.js (FINAL PASS)
   Firebase Authentication + Firestore + Cloudinary (unsigned)
   ES Modules — Firebase v12.4.0
   ============================================================ */

/* ------------------------------------------------------------
   1. IMPORTS FIREBASE
   ------------------------------------------------------------ */
import { initializeApp } from "https://www.gstatic.com/firebasejs/12.4.0/firebase-app.js";
import {
  getAuth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  GoogleAuthProvider,
  signInWithPopup,
  signInWithRedirect,
  getRedirectResult,
  signOut,
  sendPasswordResetEmail,
  onAuthStateChanged,
  updateProfile,
  updatePassword,
  reauthenticateWithCredential,
  EmailAuthProvider,
  setPersistence,
  browserLocalPersistence,
  browserSessionPersistence,
  RecaptchaVerifier,
  signInWithPhoneNumber,
  linkWithPhoneNumber
} from "https://www.gstatic.com/firebasejs/12.4.0/firebase-auth.js";
import {
  getFirestore,
  initializeFirestore,
  collection,
  doc,
  addDoc,
  setDoc,
  getDoc,
  getDocs,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  startAfter,
  limitToLast,
  onSnapshot,
  serverTimestamp,
  increment,
  arrayRemove,
  arrayUnion,
  runTransaction,
  writeBatch
} from "https://www.gstatic.com/firebasejs/12.4.0/firebase-firestore.js";
import {
  getMessaging,
  getToken,
  deleteToken,
  onMessage,
  isSupported as isMessagingSupported
} from "https://www.gstatic.com/firebasejs/12.4.0/firebase-messaging.js";

/* ------------------------------------------------------------
   2. CONFIGURATION
   ------------------------------------------------------------ */
const firebaseConfig = {
  apiKey: "AIzaSyDjusjiXUXFqVJLrEwYTobdP1oKxguTHl4",
  authDomain: "rinix-ai-22f55.firebaseapp.com",
  projectId: "rinix-ai-22f55",
  storageBucket: "rinix-ai-22f55.firebasestorage.app",
  messagingSenderId: "1055181730802",
  appId: "1:1055181730802:web:383b06489ff3b12283716b",
  measurementId: "G-QFKYBGG644"
};

const app  = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db   = initializeFirestore(app, {
  // LYRAME 2026-10-09 : laisser Firebase détecter automatiquement si le réseau
  // exige le long-polling. Le forcer en permanence ralentissait inutilement
  // les navigateurs modernes, notamment la messagerie temps réel.
  experimentalAutoDetectLongPolling: true,
  useFetchStreams: false
});

const CLOUDINARY_CLOUD_NAME = "qzgtlkc7";
const CLOUDINARY_UPLOAD_PRESET = "lyrame_unsigned";

/* LYRAME 39 — Media Router / mode économie média.
   Cloudinary reste actif. ImageKit est préparé comme fournisseur secondaire,
   mais n'est jamais activé tant que les paramètres du compte ne sont pas renseignés.
   La clé privée ImageKit ne doit JAMAIS être placée ici. */
const LYRAME_MEDIA_PRIMARY = "cloudinary";
const LYRAME_MEDIA_SECONDARY_ENABLED = false;
const IMAGEKIT_PUBLIC_KEY = "";
const IMAGEKIT_URL_ENDPOINT = "";
const IMAGEKIT_AUTH_ENDPOINT = "";
const LYRAME_PUBLIC_ORIGIN = "https://rinix-ai-22f55.web.app";
const LYRAME_VAPID_PUBLIC_KEY = "BBDwnkaXeb_pIvADX7GOgSGVEHc9tuqze38Q3a2hLq4YkaYKGbkM6ArpfHom3Go--A61hUtfYkP04JNE1-0ppHM";
const LYRAME_SW_URL = "/sw.js";
let lyrameMessagingPromise = null;
let lyrameSwRegistrationPromise = null;
let lyrameForegroundMessageUnsubscribe = null;
const lyramePushRuntime = { token: "", tokenDocId: "", registeredUid: "" };

function publicAppUrl(pathAndQuery = "") {
  const suffix = String(pathAndQuery || "");
  return `${LYRAME_PUBLIC_ORIGIN}${suffix.startsWith("/") ? "" : "/"}${suffix}`;
}

async function configureAuthPersistence() {
  try {
    await setPersistence(auth, browserLocalPersistence);
    return;
  } catch (localErr) {
    console.warn("[auth] LOCAL persistence failed:", localErr);
  }
  try {
    await setPersistence(auth, browserSessionPersistence);
  } catch (sessionErr) {
    console.error("[auth] persistence unavailable:", sessionErr);
  }
}

/* ------------------------------------------------------------
   3. CONSTANTES
   ------------------------------------------------------------ */
const POSTS_LIMIT        = 30;
const COMMENTS_LIMIT     = 50;
const COMMENTS_PREVIEW   = 3;
const NOTIF_PREVIEW      = 5;
const NOTIF_DELETE_AFTER = 2 * 24 * 60 * 60 * 1000;
const AUDIO_MAX_SEC      = 60;
const VIDEO_MAX_SEC      = 300;
const PROFILE_CACHE_TTL  = 60 * 1000;
const HEARTBEAT_MS       = 90 * 1000;
const ONLINE_FRESH_MS    = 4 * 60 * 1000;
const TITLE_MAX          = 150;
const TEXT_MAX           = 5000;

const MAX_AVATAR_BYTES = 5  * 1024 * 1024;
const MAX_COVER_BYTES  = 8  * 1024 * 1024;
const MAX_IMAGE_BYTES  = 8  * 1024 * 1024;
const MAX_VIDEO_BYTES  = 50 * 1024 * 1024;
const MAX_AUDIO_BYTES  = 10 * 1024 * 1024;

const ALLOWED_BUCKETS = Array.from(new Set([
  firebaseConfig.storageBucket,
  firebaseConfig.projectId + ".firebasestorage.app",
  firebaseConfig.projectId + ".appspot.com"
]));

const REACTIONS = [
  { type: "like",    emoji: "👍", label: "J'aime" },
  { type: "love",    emoji: "❤️", label: "J'adore" },
  { type: "laugh",   emoji: "😂", label: "Haha" },
  { type: "wow",     emoji: "😮", label: "Wow" },
  { type: "sad",     emoji: "😢", label: "Triste" },
  { type: "support", emoji: "🤝", label: "Soutien" }
];

function reactionLabel(type) {
  const labels = {
    like:    { fr: "J'aime", mg: "Tiako", en: "Like" },
    love:    { fr: "J'adore", mg: "Tiako be", en: "Love" },
    laugh:   { fr: "Haha", mg: "Haha", en: "Haha" },
    wow:     { fr: "Wow", mg: "Gaga", en: "Wow" },
    sad:     { fr: "Triste", mg: "Malahelo", en: "Sad" },
    support: { fr: "Soutien", mg: "Fanohanana", en: "Support" }
  };
  return labels[type]?.[state.lang] || labels[type]?.fr || "";
}

function categoryLabel(value) {
  const map = {
    poesie: { fr:"Poésie", mg:"Tononkalo", en:"Poetry" },
    motivation: { fr:"Motivation", mg:"Famporisihana", en:"Motivation" },
    amour: { fr:"Amour", mg:"Fitiavana", en:"Love" },
    vie: { fr:"Vie", mg:"Fiainana", en:"Life" },
    tristesse: { fr:"Tristesse", mg:"Alahelo", en:"Sadness" },
    separation: { fr:"Séparation", mg:"Fisarahana", en:"Separation" },
    mariage: { fr:"Mariage", mg:"Fanambadiana", en:"Marriage" },
    espoir: { fr:"Espoir", mg:"Fanantenana", en:"Hope" }
  };
  return map[value]?.[state.lang] || value || "";
}

function countryFlag(code) {
  const c = String(code || "").toUpperCase();
  if (!/^[A-Z]{2}$/.test(c)) return "";
  return String.fromCodePoint(...Array.from(c).map(ch => 127397 + ch.charCodeAt(0)));
}

const EMOJIS = [
  "😀","😃","😄","😂","😊","😍","🥰","😘","😎","🤔","😮","😢","😭","😡",
  "❤️","💜","💙","💚","✨","🔥","👍","👏","🙏","💯","🌹","🥺","🤝"
];

/* LYRAME — 20 stickers animés distants (GIF animé servi depuis Google Fonts/Noto Emoji, aucun fichier image local). */
const COMMENT_STICKERS = [
  { id:"love_heart", tone:"love", icon:"😍", fr:"J’adore !", mg:"Tiako be!", en:"Love it!", keywords:["amour","aime","adore","love","fitiavana","tiako","fo","heart","mamy"] },
  { id:"love_hug", tone:"love", icon:"🥰", fr:"Plein d’amour", mg:"Fitiavana be", en:"So much love", keywords:["amour","love","fitiavana","mamy","cheri","chérie","heart"] },
  { id:"joy_laugh", tone:"joy", icon:"🤣", fr:"Trop drôle !", mg:"Mampihomehy be!", en:"So funny!", keywords:["haha","mdr","lol","drôle","drole","rire","mampihomehy","hehy","funny"] },
  { id:"joy_smile", tone:"joy", icon:"😄", fr:"Ça fait plaisir", mg:"Mahafaly izany", en:"That made me smile", keywords:["faly","heureux","heureuse","joie","plaisir","smile","happy","mahafaly"] },
  { id:"sad_tears", tone:"sad", icon:"😢", fr:"Quelle tristesse…", mg:"Mampalahelo…", en:"So sad…", keywords:["triste","tristesse","malheur","décès","deces","mort","alahelo","mampalahelo","maty","sad","death","pleure"] },
  { id:"sad_support", tone:"sad", icon:"🫂", fr:"Je suis avec toi", mg:"Miaraka aminao aho", en:"I’m with you", keywords:["triste","alahelo","marary","malade","sick","difficile","sarotra","perdu","very hard"] },
  { id:"support_courage", tone:"support", icon:"💪", fr:"Courage !", mg:"Mahereza!", en:"Stay strong!", keywords:["courage","mahereza","force","strong","difficile","sarotra","combat","miady","effort"] },
  { id:"support_hope", tone:"support", icon:"🌟", fr:"Ne lâche rien", mg:"Aza kivy", en:"Keep going", keywords:["espoir","hope","fanantenana","aza kivy","continue","mitohy","réussir","reussir","tafita"] },
  { id:"celebrate_bravo", tone:"celebrate", icon:"👏", fr:"Bravo !", mg:"Bravo!", en:"Bravo!", keywords:["bravo","félicitations","felicitations","congrats","ara habaina","arahabaina","réussi","reussi","tafita","excellent"] },
  { id:"celebrate_party", tone:"celebrate", icon:"🎉", fr:"Félicitations !", mg:"Arahabaina!", en:"Congratulations!", keywords:["anniversaire","birthday","mariage","wedding","fety","fête","fete","succès","succes","victoire","nahazo"] },
  { id:"thanks_thankyou", tone:"thanks", icon:"🙏", fr:"Merci !", mg:"Misaotra!", en:"Thank you!", keywords:["merci","misaotra","thank","thanks","remerci","gratitude"] },
  { id:"thanks_respect", tone:"thanks", icon:"🤝", fr:"Respect", mg:"Hajaina", en:"Respect", keywords:["respect","haja","merci","misaotra","bravo","solidarité","solidarite"] },
  { id:"surprise_wow", tone:"surprise", icon:"🤩", fr:"Waouh !", mg:"Wow!", en:"Wow!", keywords:["wow","waouh","incroyable","mahagaga","amazing","superbe","magnifique","extraordinaire"] },
  { id:"surprise_really", tone:"surprise", icon:"😮", fr:"Vraiment ?!", mg:"Tena ve?!", en:"Really?!", keywords:["vraiment","tena ve","really","serieux","sérieux","marina ve","surprise"] },
  { id:"agree_true", tone:"agree", icon:"✅", fr:"Exactement !", mg:"Marina mihitsy!", en:"Exactly!", keywords:["marina","exact","exactement","agree","d'accord","accord","ekeko","vrai","true"] },
  { id:"agree_yes", tone:"agree", icon:"👍", fr:"Je suis d’accord", mg:"Ekeko", en:"I agree", keywords:["ekeko","d'accord","accord","oui","yes","marina","agree"] },
  { id:"prayer_amen", tone:"prayer", icon:"🙏", fr:"Amen", mg:"Amen", en:"Amen", keywords:["amen","andriamanitra","dieu","god","jesosy","jésus","jesus","prière","priere","vavaka"] },
  { id:"prayer_bless", tone:"prayer", icon:"✨", fr:"Que Dieu bénisse", mg:"Hotahin’Andriamanitra", en:"God bless", keywords:["andriamanitra","dieu","god","tahio","bénisse","benisse","bless","vavaka","prière"] },
  { id:"disagree_no", tone:"disagree", icon:"🙅", fr:"Pas d’accord", mg:"Tsy ekeko", en:"I disagree", keywords:["tsy ekeko","pas d'accord","disagree","non","tsia","faux","diso","wrong"] },
  { id:"disagree_stop", tone:"disagree", icon:"🛑", fr:"Ça ne va pas", mg:"Tsy mety izany", en:"That’s not right", keywords:["tsy mety","inacceptable","incorrect","diso","wrong","stop","hate","tezitra","colère","colere"] }
];

function stickerLabel(sticker) {
  return sticker?.[state.lang] || sticker?.fr || sticker?.mg || "";
}

function stickerById(id) {
  return COMMENT_STICKERS.find(s => s.id === id) || null;
}

const PRIVACY_ICONS = {
  public: `
    <svg viewBox="0 0 24 24" width="14" height="14" fill="none"
      stroke="currentColor" stroke-width="1.8" stroke-linecap="round"
      stroke-linejoin="round" aria-hidden="true">
      <circle cx="12" cy="12" r="9"/>
      <path d="M3 12h18M12 3a15 15 0 0 1 0 18M12 3a15 15 0 0 0 0 18"/>
    </svg>
  `,
  friends: `
    <svg viewBox="0 0 24 24" width="14" height="14" fill="none"
      stroke="currentColor" stroke-width="1.8" stroke-linecap="round"
      stroke-linejoin="round" aria-hidden="true">
      <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/>
      <circle cx="9" cy="7" r="4"/>
      <path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>
    </svg>
  `,
  private: `
    <svg viewBox="0 0 24 24" width="14" height="14" fill="none"
      stroke="currentColor" stroke-width="1.8" stroke-linecap="round"
      stroke-linejoin="round" aria-hidden="true">
      <rect x="4" y="10" width="16" height="10" rx="2"/>
      <path d="M8 10V7a4 4 0 0 1 8 0v3"/>
    </svg>
  `
};
const POST_PRIVACY_VALUES = ["public", "friends", "private"];

const FONT_FAMILIES = {
  default: "",
  sans: "Arial, Helvetica, sans-serif",
  serif: "Georgia, 'Times New Roman', serif",
  mono: "'Courier New', monospace",
  cursive: "'Brush Script MT', cursive"
};
const FONT_SIZES = { small: "13px", normal: "", large: "18px", xlarge: "22px" };

/* ------------------------------------------------------------
   4. ÉTAT GLOBAL
   ------------------------------------------------------------ */
const state = {
  theme: "light",
  lang:  "fr",
  currentUser: null,
  currentProfile: null,
  profileExists: false,
  profileViewUid: null,
  activePostId: null,
  activeConvId: null,
  activeConv: null,
  activePostAuthorId: "",
  screenStack: [],
  activeCategory: "pour-vous",
  commentsExpanded: false,
  notificationsExpanded: false,
  uploading: false,
  myPostsUid: null,
  profileRepairUid: null,
  registering: false,
  phoneRegistrationPending: false,
  phoneLoginPending: false,
  authTransitioning: false,
  editingPostId: null,

  /* Publications utilisées par les onglets profil */
  myProfilePosts: [],
  otherProfilePosts: [],
  profileMeTab: "posts",
  profileOtherTab: "posts",

  selectedPostMedia: null,
  postFormat: null,

  commentImageFile: null,
  commentImagePreviewUrl: "",
  commentMediaKind: "image",
  commentReplyTo: null,

  profileAvatarFile: null,
  profileCoverFile: null,
  profileAvatarPreviewUrl: "",
  profileCoverPreviewUrl: "",
  profileAvatarRemove: false,
  profileCoverRemove: false,
  profileAvatarSelectedHistory: null,
  profileCoverSelectedHistory: null,

  groupCoverFile: null,
  groupCoverPreviewUrl: "",
  groupEditFile: null,
  groupEditPreviewUrl: "",
  groupCandidates: [],
  groupSelected: new Map(),

  activeReactionPostId: null,

  friendshipStatus: "none",
  friendIds: new Set(),
  friendsLoaded: false,
  incomingRequests: [],
  outgoingRequests: [],

  presenceHeartbeat: null,
  presenceStarted: false,
  lastPresenceWrite: 0,

  selectedImageRatio: "original",
  selectedVideoRatio: "original",
  selectedBackgroundRatio: "original",
  selectedPostBackground: null,
  commentAnonymous: false,
  richEditorEnabled: false,
  commentsCollapsed: false,

  messageReplyTo: null,
  messageUploadAbort: null,
  pendingMessageMedia: null,

  typingTimer: null,
  typingActive: false,
  lastTypingWrite: 0,

  mediaRecorder: null,
  recorderStream: null,
  recorderChunks: [],
  recorderBlob: null,
  recorderUrl: "",
  recorderStartedAt: 0,
  recorderTimer: null,
  recorderAudioContext: null,
  recorderAnalyser: null,
  recorderAnimationFrame: null,
  recorderDiscard: false,

  activeCallId: null,
  activeCallType: "audio",
  callPeer: null,
  callLocalStream: null,
  callRawLocalStream: null,
  callRemoteStream: null,
  callVideoProcessor: null,
  callVideoFilter: "none",
  callDocUnsub: null,
  callCandidatesUnsub: null,
  callRingTimer: null,
  callDisconnectTimer: null,
  callMinimized: false,
  incomingCallShownId: null,

  registerMethod: "email",
  phoneConfirmationResult: null,
  phoneVerifiedUser: null,
  recaptchaVerifier: null,

  loginMethod: "email",
  loginPhoneConfirmationResult: null,
  loginRecaptchaVerifier: null,
  accountPhoneRecaptchaVerifier: null,
  accountPhoneConfirmationResult: null,

  reportScreenshotFile: null,
  reportScreenshotUrl: "",

  profileGalleryPhotos: []
};
state.postFormat = defaultFormatting();

const listeners = {
  profile: null, feed: null, comments: null,
  myPosts: null, otherPosts: null,
  conversations: null, messages: null, conversationDoc: null,
  notifications: null, followers: null, following: null,
  friends: null, friendRequests: null, outgoingRequests: null,
  presence: null, activeProfilePresence: null, calls: null
};

function clearListeners() {
  Object.keys(listeners).forEach(k => {
    const unsub = listeners[k];
    if (typeof unsub === "function") {
      try { unsub(); } catch (e) { /* noop */ }
    }
    listeners[k] = null;
  });
  state.myPostsUid = null;
  state.profileRepairUid = null;
}

const profileCache   = new Map();
const profilePending = new Map();
const reactionCache  = new Map(); // postId -> type | ""

const listTokens = {
  followers: 0, following: 0, groupCandidates: 0,
  feed: 0, myPosts: 0, otherPosts: 0,
  friends: 0, requests: 0, manageMembers: 0
};

/* ------------------------------------------------------------
   5. TRADUCTIONS
   ------------------------------------------------------------ */
const I18N = {
  fr: {
    nav_home: "Accueil", nav_search: "Recherche", nav_create: "Créer",
    nav_messages: "Messages", nav_profile: "Profil",
    settings: "Paramètres", notifications: "Notifications",
    lang_updated: "Langue mise à jour",
    theme_light: "Thème clair activé",
    theme_dark: "Thème sombre activé",
    err_generic: "Une erreur est survenue. Vérifiez votre connexion puis réessayez.",
    err_network: "Connexion impossible.",
    err_email_in_use: "Cet email est déjà utilisé.",
    err_invalid_email: "Adresse email invalide.",
    err_weak_password: "Mot de passe trop faible (6 caractères minimum).",
    err_invalid_credential: "Email ou mot de passe incorrect.",
    err_user_not_found: "Aucun compte avec cet email.",
    err_too_many: "Trop de tentatives. Réessayez plus tard.",
    err_required: "Veuillez remplir tous les champs.",
    err_password_mismatch: "Les mots de passe ne correspondent pas.",
    err_username_taken: "Ce nom d'utilisateur est déjà pris.",
    err_username_format: "Nom d'utilisateur : 3-24 caractères (a-z, 0-9, _, .).",
    err_media_too_long_audio: "Audio trop long (1 minute maximum).",
    err_media_too_long_video: "Vidéo trop longue (5 minutes maximum).",
    err_empty_post: "Ajoutez un titre et du contenu (texte, média ou arrière-plan).",
    err_empty_comment: "Ajoutez un texte ou un média.",
    err_upload_failed: "Impossible d'envoyer le fichier.",
    err_image_upload: "Impossible d'envoyer l'image.",
    err_no_permission: "Action non autorisée.",
    err_birthdate: "Date de naissance invalide.",
    err_media_read: "Fichier illisible.",
    msg_login_success: "Connexion réussie.",
    msg_register_success: "Compte créé. Bienvenue !",
    msg_reset_sent: "Email de réinitialisation envoyé.",
    msg_post_created: "Publication partagée.",
    msg_comment_added: "Commentaire ajouté.",
    msg_profile_saved: "Profil enregistré.",
    msg_followed: "Vous suivez maintenant cet utilisateur.",
    msg_unfollowed: "Vous ne suivez plus cet utilisateur.",
    msg_notif_deleted: "Notification supprimée.",
    msg_message_sent: "Message envoyé.",
    msg_logout: "Déconnexion...",
    msg_link_copied: "Lien copié.",
    msg_cache_cleared: "Cache vidé.",
    msg_data_cleared: "Données locales effacées.",
    msg_group_created: "Groupe créé.",
    msg_group_left: "Vous avez quitté le groupe.",
    msg_group_deleted: "Groupe supprimé.",
    msg_group_updated: "Groupe mis à jour.",
    msg_group_member_added: "Membre ajouté.",
    msg_group_members_added: "Membres ajoutés.",
    msg_group_member_removed: "Membre retiré.",
    msg_ownership_transferred: "Propriété transférée.",
    msg_post_deleted: "Publication supprimée.",
    msg_user_not_found: "Utilisateur introuvable.",
    msg_password_changed: "Mot de passe modifié.",
    msg_friend_request_sent: "Demande d'ami envoyée.",
    msg_friend_accepted: "Vous êtes maintenant amis.",
    msg_friend_removed: "Ami retiré.",
    msg_request_declined: "Demande refusée.",
    msg_request_cancelled: "Demande annulée.",
    empty_search: "Aucun utilisateur trouvé.",
    post_unavailable: "Publication indisponible.",
    post_not_found: "Publication introuvable.",
    loading: "Chargement…",
    confirm_yes: "Confirmer",
    confirm_no: "Annuler",
    delete: "Supprimer",
    leave: "Quitter",
    remove: "Retirer",
    save: "Enregistrer",
    cancel: "Annuler",
    add: "Ajouter",
    close: "Fermer",
    confirm_delete_post_title: "Supprimer la publication",
    confirm_delete_post: "Supprimer cette publication ?",
    confirm_leave_group_title: "Quitter le groupe",
    confirm_leave_group: "Quitter ce groupe ?",
    confirm_delete_group_title: "Supprimer le groupe",
    confirm_delete_group: "Vous êtes le seul membre. Le groupe sera supprimé.",
    confirm_remove_member_title: "Retirer le membre",
    confirm_remove_member: "Retirer ce membre du groupe ?",
    confirm_transfer_title: "Transférer la propriété",
    confirm_transfer: "Transférer la propriété du groupe à ce membre ?",
    confirm_remove_friend_title: "Retirer des amis",
    confirm_remove_friend: "Retirer cette personne de vos amis ?",
    friend_add: "Ajouter aux amis",
    friend_sent: "Demande envoyée",
    friend_accept: "Accepter",
    friend_reject: "Refuser",
    friend_friends: "Amis",
    friend_cancel: "Annuler la demande",
    friend_remove: "Retirer des amis",
    online: "En ligne",
    yesterday: "Hier",
    privacy_public: "Public",
    privacy_friends: "Amis",
    privacy_private: "Moi uniquement",
    name_required: "Donnez un nom au groupe.",
    members_required: "Sélectionnez au moins un membre.",
    msg_already_member: "Cette personne est déjà membre.",
    msg_not_a_group: "Cette conversation n'est pas un groupe.",
    msg_not_member: "Vous n'êtes pas membre de ce groupe.",
    err_owner_must_transfer: "Transférez d'abord la propriété du groupe avant de le quitter.",
    err_owner_cannot_be_removed: "Le propriétaire ne peut pas être retiré.",
    group_manage: "Gérer les membres",
    group_members: "Membres",
    group_add_members: "Ajouter des membres",
    group_owner: "Propriétaire",
    group_admin: "Admin",
    group_transfer: "Transférer la propriété",
    group_members_count: "membres",
    search_members: "Rechercher un membre",
    no_candidates: "Aucun résultat.",
    pw_title: "Changer le mot de passe",
    pw_current: "Mot de passe actuel",
    pw_new: "Nouveau mot de passe",
    pw_confirm: "Confirmer le nouveau mot de passe",
    pw_show: "Afficher le mot de passe",
    pw_hide: "Masquer le mot de passe",
    reply_to: "Réponse à",
    err_file_type: "Type de fichier non autorisé.",
    err_file_too_large: "Fichier trop volumineux.",
    err_avatar_type: "Avatar : image uniquement.",
    err_avatar_too_large: "Avatar trop volumineux (max 5 Mo).",
    err_cover_type: "Couverture : image uniquement.",
    err_cover_too_large: "Couverture trop volumineuse (max 8 Mo).",
  
    uploading: "Envoi en cours…",
    upload_failed: "Échec de l'envoi",
    upload_cancelled: "Envoi annulé",
    recording: "Enregistrement",
    ready_to_send: "Prêt à envoyer",
    audio_not_supported: "L'enregistrement audio n'est pas pris en charge sur cet appareil.",
    microphone_denied: "Impossible d'accéder au microphone.",
    add_photo: "Ajouter une photo",
    report_saved: "Signalement enregistré.",
    verified: "Vérifié",
    not_verified: "Non vérifié",
    invalid_phone: "Numéro de téléphone invalide.",
    phone_code_sent: "Code envoyé.",
    phone_verified: "Numéro vérifié.",
    invalid_code: "Code incorrect ou expiré.",
    verify_phone_first: "Vérifiez d'abord votre numéro de téléphone.",
    phone_account_no_password: "Ce compte utilise la connexion par téléphone.",
    phone_code_first: "Envoyez d’abord le code de vérification.",
    phone_login_success: "Connexion par téléphone réussie.",
    upload_failed_keep_recording: "Échec de l’envoi. L’enregistrement est conservé.",
  },
  mg: {
    nav_home: "Fandraisana", nav_search: "Fikarohana", nav_create: "Hamorona",
    nav_messages: "Hafatra", nav_profile: "Profil",
    settings: "Kirakira", notifications: "Fampandrenesana",
    lang_updated: "Voaova ny fiteny",
    theme_light: "Thème mazava", theme_dark: "Thème maizina",
    err_generic: "Nisy olana teo amin'ny fangatahana. Hamarino ny connexion-nao dia andramo indray.",
    err_network: "Tsy afaka mifandray.",
    err_email_in_use: "Efa nampiasaina io email io.",
    err_invalid_email: "Email diso.",
    err_weak_password: "Tenimiafina malemy (6 litera farafahakeliny).",
    err_invalid_credential: "Email na tenimiafina diso.",
    err_user_not_found: "Tsy misy kaonty amin'io email io.",
    err_too_many: "Be loatra ny fanandramana.",
    err_required: "Fenoy ny saha rehetra.",
    err_password_mismatch: "Tsy mifanaraka ny tenimiafina.",
    err_username_taken: "Efa misy io anarana io.",
    err_username_format: "Anarana : 3-24 litera (a-z, 0-9, _, .).",
    err_media_too_long_audio: "Lava loatra ny feo (1 minitra farafahabetsany).",
    err_media_too_long_video: "Lava loatra ny vidéo (5 minitra farafahabetsany).",
    err_empty_post: "Asio lohateny sy votoaty (lahatsoratra, media na fond).",
    err_empty_comment: "Asio lahatsoratra na media.",
    err_upload_failed: "Tsy afaka nandefa ny fichier.",
    err_image_upload: "Tsy afaka nandefa ny sary.",
    err_no_permission: "Tsy azo atao izany.",
    err_birthdate: "Daty nahaterahana diso.",
    err_media_read: "Tsy voavaky ny fichier.",
    msg_login_success: "Tafiditra soa aman-tsara.",
    msg_register_success: "Vita ny kaonty. Tongasoa !",
    msg_reset_sent: "Nalefa ny email famerenana.",
    msg_post_created: "Navoaka ny publication.",
    msg_comment_added: "Nampiana ny hevitra.",
    msg_profile_saved: "Voatahiry ny profil.",
    msg_followed: "Manaraka azy ianao izao.",
    msg_unfollowed: "Tsy manaraka azy intsony ianao.",
    msg_notif_deleted: "Voafafa ny fampandrenesana.",
    msg_message_sent: "Nalefa ny hafatra.",
    msg_logout: "Miala...",
    msg_link_copied: "Voakopia ny rohy.",
    msg_cache_cleared: "Voafafa ny cache.",
    msg_data_cleared: "Voafafa ny angona eo an-toerana.",
    msg_group_created: "Vita ny vondrona.",
    msg_group_left: "Niala tamin'ny vondrona ianao.",
    msg_group_deleted: "Voafafa ny vondrona.",
    msg_group_updated: "Voavao ny vondrona.",
    msg_group_member_added: "Nampiana mpikambana.",
    msg_group_members_added: "Nampiana ny mpikambana.",
    msg_group_member_removed: "Voaala ny mpikambana.",
    msg_ownership_transferred: "Nafindra ny fananana.",
    msg_post_deleted: "Voafafa ny publication.",
    msg_user_not_found: "Tsy hita ny mpampiasa.",
    msg_password_changed: "Voaova ny tenimiafina.",
    msg_friend_request_sent: "Nalefa ny fangatahana.",
    msg_friend_accepted: "Namana izao ianareo.",
    msg_friend_removed: "Voaala ny namana.",
    msg_request_declined: "Nolavina ny fangatahana.",
    msg_request_cancelled: "Nofoanana ny fangatahana.",
    empty_search: "Tsy misy mpampiasa hita.",
    post_unavailable: "Tsy azo jerena ny publication.",
    post_not_found: "Tsy hita ny publication.",
    loading: "Mandany…",
    confirm_yes: "Hamafiso",
    confirm_no: "Foano",
    delete: "Fafao",
    leave: "Hiala",
    remove: "Esory",
    save: "Tehirizo",
    cancel: "Foano",
    add: "Ampio",
    close: "Akatony",
    confirm_delete_post_title: "Hamafa ny publication",
    confirm_delete_post: "Hamafa ity publication ity ?",
    confirm_leave_group_title: "Hiala amin'ny vondrona",
    confirm_leave_group: "Hiala amin'ny vondrona ?",
    confirm_delete_group_title: "Hamafa ny vondrona",
    confirm_delete_group: "Ianao irery no mpikambana.Ho voafafa ny vondrona.",
    confirm_remove_member_title: "Hanala mpikambana",
    confirm_remove_member: "Esorina amin'ny vondrona ity mpikambana ity ?",
    confirm_transfer_title: "Hamindra ny fananana",
    confirm_transfer: "Afindra amin'ity mpikambana ity ny fananana ny vondrona ?",
    confirm_remove_friend_title: "Hanala namana",
    confirm_remove_friend: "Esorina amin'ny namana ity olona ity ?",
    friend_add: "Ampio ho namana",
    friend_sent: "Nalefa ny fangatahana",
    friend_accept: "Ekena",
    friend_reject: "Lavina",
    friend_friends: "Namana",
    friend_cancel: "Foano ny fangatahana",
    friend_remove: "Esory amin'ny namana",
    online: "An-tserasera",
    yesterday: "Omaly",
    privacy_public: "Ho an'ny rehetra",
    privacy_friends: "Namana",
    privacy_private: "Ahy irery",
    name_required: "Asio anarana ny vondrona.",
    members_required: "Misafidiana mpikambana iray farafahakeliny.",
    msg_already_member: "Efa mpikambana io olona io.",
    msg_not_a_group: "Tsy vondrona io resaka io.",
    msg_not_member: "Tsy mpikambana ao amin'ity vondrona ity ianao.",
    err_owner_must_transfer: "Afindrao aloha ny fananana ny vondrona vao miala.",
    err_owner_cannot_be_removed: "Tsy azo esorina ny tompony.",
    group_manage: "Tantano ny mpikambana",
    group_members: "Mpikambana",
    group_add_members: "Ampio mpikambana",
    group_owner: "Tompony",
    group_admin: "Admin",
    group_transfer: "Afindra ny fananana",
    group_members_count: "mpikambana",
    search_members: "Karohy mpikambana",
    no_candidates: "Tsy misy valiny.",
    pw_title: "Hanova ny tenimiafina",
    pw_current: "Tenimiafina ankehitriny",
    pw_new: "Tenimiafina vaovao",
    pw_confirm: "Hamafiso ny tenimiafina vaovao",
    pw_show: "Asehoy ny tenimiafina",
    pw_hide: "Afeno ny tenimiafina",
    reply_to: "Valiny ho an'i",
    err_file_type: "Karazana fichier tsy azo.",
    err_file_too_large: "Lehibe loatra ny fichier.",
    err_avatar_type: "Avatar : sary ihany.",
    err_avatar_too_large: "Avatar lehibe loatra (5 Mo farafahabetsany).",
    err_cover_type: "Couverture : sary ihany.",
    err_cover_too_large: "Couverture lehibe loatra (8 Mo farafahabetsany).",
  
    uploading: "Eo am-pandefasana…",
    upload_failed: "Tsy tafapetraka ny fandefasana",
    upload_cancelled: "Nofoanana ny fandefasana",
    recording: "Mandrakitra feo",
    ready_to_send: "Vonona halefa",
    audio_not_supported: "Tsy mahazaka fandraketana feo ity fitaovana ity.",
    microphone_denied: "Tsy azo ampiasaina ny mikrô.",
    add_photo: "Hanampy sary",
    report_saved: "Voatahiry ny tatitra.",
    verified: "Voamarina",
    not_verified: "Tsy mbola voamarina",
    invalid_phone: "Tsy mety ny laharana finday.",
    phone_code_sent: "Nalefa ny kaody.",
    phone_verified: "Voamarina ny laharana finday.",
    invalid_code: "Diso na lany daty ny kaody.",
    verify_phone_first: "Hamarino aloha ny laharana finday.",
    phone_account_no_password: "Laharana finday no ampiasain'ity kaonty ity fa tsy tenimiafina.",
    phone_code_first: "Alefaso aloha ny kaody fanamarinana.",
    phone_login_success: "Tafiditra tamin’ny laharana finday.",
    upload_failed_keep_recording: "Tsy tafalefa. Voatahiry hatrany ilay feo noraketina.",
  },
  en: {
    nav_home: "Home", nav_search: "Search", nav_create: "Create",
    nav_messages: "Messages", nav_profile: "Profile",
    settings: "Settings", notifications: "Notifications",
    lang_updated: "Language updated",
    theme_light: "Light theme on", theme_dark: "Dark theme on",
    err_generic: "Something went wrong. Check your connection and try again.",
    err_network: "Connection failed.",
    err_email_in_use: "This email is already in use.",
    err_invalid_email: "Invalid email address.",
    err_weak_password: "Password too weak (6 characters minimum).",
    err_invalid_credential: "Invalid email or password.",
    err_user_not_found: "No account with this email.",
    err_too_many: "Too many attempts. Try again later.",
    err_required: "Please fill all fields.",
    err_password_mismatch: "Passwords do not match.",
    err_username_taken: "This username is already taken.",
    err_username_format: "Username: 3-24 characters (a-z, 0-9, _, .).",
    err_media_too_long_audio: "Audio too long (1 minute max).",
    err_media_too_long_video: "Video too long (5 minutes max).",
    err_empty_post: "Add a title and content (text, media or background).",
    err_empty_comment: "Add text or media.",
    err_upload_failed: "Unable to send the file.",
    err_image_upload: "Unable to send the image.",
    err_no_permission: "Action not allowed.",
    err_birthdate: "Invalid birth date.",
    err_media_read: "Unreadable file.",
    msg_login_success: "Signed in successfully.",
    msg_register_success: "Account created. Welcome!",
    msg_reset_sent: "Reset email sent.",
    msg_post_created: "Post shared.",
    msg_comment_added: "Comment added.",
    msg_profile_saved: "Profile saved.",
    msg_followed: "You now follow this user.",
    msg_unfollowed: "You no longer follow this user.",
    msg_notif_deleted: "Notification deleted.",
    msg_message_sent: "Message sent.",
    msg_logout: "Signing out...",
    msg_link_copied: "Link copied.",
    msg_cache_cleared: "Cache cleared.",
    msg_data_cleared: "Local data cleared.",
    msg_group_created: "Group created.",
    msg_group_left: "You left the group.",
    msg_group_deleted: "Group deleted.",
    msg_group_updated: "Group updated.",
    msg_group_member_added: "Member added.",
    msg_group_members_added: "Members added.",
    msg_group_member_removed: "Member removed.",
    msg_ownership_transferred: "Ownership transferred.",
    msg_post_deleted: "Post deleted.",
    msg_user_not_found: "User not found.",
    msg_password_changed: "Password changed.",
    msg_friend_request_sent: "Friend request sent.",
    msg_friend_accepted: "You are now friends.",
    msg_friend_removed: "Friend removed.",
    msg_request_declined: "Request declined.",
    msg_request_cancelled: "Request cancelled.",
    empty_search: "No users found.",
    post_unavailable: "Post unavailable.",
    post_not_found: "Post not found.",
    loading: "Loading…",
    confirm_yes: "Confirm",
    confirm_no: "Cancel",
    delete: "Delete",
    leave: "Leave",
    remove: "Remove",
    save: "Save",
    cancel: "Cancel",
    add: "Add",
    close: "Close",
    confirm_delete_post_title: "Delete post",
    confirm_delete_post: "Delete this post?",
    confirm_leave_group_title: "Leave group",
    confirm_leave_group: "Leave this group?",
    confirm_delete_group_title: "Delete group",
    confirm_delete_group: "You are the only member. The group will be deleted.",
    confirm_remove_member_title: "Remove member",
    confirm_remove_member: "Remove this member from the group?",
    confirm_transfer_title: "Transfer ownership",
    confirm_transfer: "Transfer group ownership to this member?",
    confirm_remove_friend_title: "Remove friend",
    confirm_remove_friend: "Remove this person from your friends?",
    friend_add: "Add friend",
    friend_sent: "Request sent",
    friend_accept: "Accept",
    friend_reject: "Decline",
    friend_friends: "Friends",
    friend_cancel: "Cancel request",
    friend_remove: "Remove friend",
    online: "Online",
    yesterday: "Yesterday",
    privacy_public: "Public",
    privacy_friends: "Friends",
    privacy_private: "Only me",
    name_required: "Give the group a name.",
    members_required: "Select at least one member.",
    msg_already_member: "This person is already a member.",
    msg_not_a_group: "This conversation is not a group.",
    msg_not_member: "You are not a member of this group.",
    err_owner_must_transfer: "Transfer group ownership before leaving.",
    err_owner_cannot_be_removed: "The owner cannot be removed.",
    group_manage: "Manage members",
    group_members: "Members",
    group_add_members: "Add members",
    group_owner: "Owner",
    group_admin: "Admin",
    group_transfer: "Transfer ownership",
    group_members_count: "members",
    search_members: "Search a member",
    no_candidates: "No results.",
    pw_title: "Change password",
    pw_current: "Current password",
    pw_new: "New password",
    pw_confirm: "Confirm new password",
    pw_show: "Show password",
    pw_hide: "Hide password",
    reply_to: "Replying to",
    err_file_type: "File type not allowed.",
    err_file_too_large: "File too large.",
    err_avatar_type: "Avatar: image only.",
    err_avatar_too_large: "Avatar too large (max 5 MB).",
    err_cover_type: "Cover: image only.",
    err_cover_too_large: "Cover too large (max 8 MB).",
  
    uploading: "Uploading…",
    upload_failed: "Upload failed",
    upload_cancelled: "Upload cancelled",
    recording: "Recording",
    ready_to_send: "Ready to send",
    audio_not_supported: "Audio recording is not supported on this device.",
    microphone_denied: "Microphone access is unavailable.",
    add_photo: "Add photo",
    report_saved: "Report saved.",
    verified: "Verified",
    not_verified: "Not verified",
    invalid_phone: "Invalid phone number.",
    phone_code_sent: "Code sent.",
    phone_verified: "Phone number verified.",
    invalid_code: "Incorrect or expired code.",
    verify_phone_first: "Verify your phone number first.",
    phone_account_no_password: "This account uses phone sign-in and does not have a password.",
    phone_code_first: "Send the verification code first.",
    phone_login_success: "Phone sign-in successful.",
    upload_failed_keep_recording: "Upload failed. Your recording has been kept.",
  },
  es: { nav_home: "Inicio", nav_search: "Buscar", nav_create: "Crear", nav_messages: "Mensajes", nav_profile: "Perfil", settings: "Ajustes", notifications: "Notificaciones" },
  pt: { nav_home: "Início", nav_search: "Buscar", nav_create: "Criar", nav_messages: "Mensagens", nav_profile: "Perfil", settings: "Configurações", notifications: "Notificações" },
  de: { nav_home: "Start", nav_search: "Suche", nav_create: "Erstellen", nav_messages: "Nachrichten", nav_profile: "Profil", settings: "Einstellungen", notifications: "Benachrichtigungen" },
  it: { nav_home: "Home", nav_search: "Cerca", nav_create: "Crea", nav_messages: "Messaggi", nav_profile: "Profilo", settings: "Impostazioni", notifications: "Notifiche" },
  ar: { nav_home: "الرئيسية", nav_search: "بحث", nav_create: "إنشاء", nav_messages: "الرسائل", nav_profile: "الملف", settings: "الإعدادات", notifications: "الإشعارات" },
  zh: { nav_home: "首页", nav_search: "搜索", nav_create: "创建", nav_messages: "消息", nav_profile: "我的", settings: "设置", notifications: "通知" },
  ja: { nav_home: "ホーム", nav_search: "検索", nav_create: "作成", nav_messages: "メッセージ", nav_profile: "プロフィール", settings: "設定", notifications: "通知" },
  ko: { nav_home: "홈", nav_search: "검색", nav_create: "만들기", nav_messages: "메시지", nav_profile: "프로필", settings: "설정", notifications: "알림" },
  hi: { nav_home: "होम", nav_search: "खोज", nav_create: "बनाएं", nav_messages: "संदेश", nav_profile: "प्रोफ़ाइल", settings: "सेटिंग्स", notifications: "सूचनाएं" },
  ru: { nav_home: "Главная", nav_search: "Поиск", nav_create: "Создать", nav_messages: "Сообщения", nav_profile: "Профиль", settings: "Настройки", notifications: "Уведомления" },
  sw: { nav_home: "Nyumbani", nav_search: "Tafuta", nav_create: "Unda", nav_messages: "Ujumbe", nav_profile: "Wasifu", settings: "Mipangilio", notifications: "Taarifa" }
};

function t(key) {
  const dict = I18N[state.lang] || I18N.fr;
  return dict[key] || I18N.fr[key] || key;
}

function uiText(fr, mg, en) {
  if (state.lang === "mg") return mg;
  if (state.lang === "en") return en;
  return fr;
}

function uiSomeone() {
  return uiText("Quelqu’un", "Olona iray", "Someone");
}

function uiGroup() {
  return uiText("Groupe", "Vondrona", "Group");
}

function uiConversation() {
  return uiText("Conversation", "Resaka", "Conversation");
}

/* ------------------------------------------------------------
   6. LANGUES
   ------------------------------------------------------------ */
const LANGS = [
  { code: "mg", label: "Malagasy" },
  { code: "fr", label: "Français" },
  { code: "en", label: "English" }
];
const SUPPORTED_UI_LANGS = new Set(LANGS.map(l => l.code));

/* ------------------------------------------------------------
   7. HELPERS
   ------------------------------------------------------------ */
const $  = (sel, ctx = document) => ctx.querySelector(sel);
const $$ = (sel, ctx = document) => Array.from(ctx.querySelectorAll(sel));

function showEl(el) {
  if (!el) return;
  const wasShown = isShown(el);
  el.classList.remove("hidden");
  el.hidden = false;
  if (!wasShown) lyrameAndroidPushOverlay(el);
}
function hideEl(el) {
  if (!el) return;
  const wasShown = isShown(el);
  el.classList.add("hidden");
  if (wasShown && el.id) lyrameAndroidOverlayClosed(el.id);
}
function isShown(el) {
  return !!el && !el.classList.contains("hidden") && !el.hidden;
}

function escapeHtml(s) {
  return String(s == null ? "" : s).replace(/[&<>"']/g, c => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[c]));
}

/* URL de confiance : https (Cloudinary du projet, anciens médias Firebase)
   et blob: UNIQUEMENT pour les aperçus locaux (allowBlob). */
function safeUrl(u, opts = {}) {
  if (!u || typeof u !== "string") return "";
  try {
    const url = new URL(u);
    if (url.protocol === "blob:") return opts.allowBlob ? url.href : "";
    if (url.protocol !== "https:") return "";
    if (url.hostname === "res.cloudinary.com") {
      const first = url.pathname.split("/")[1] || "";
      return first === CLOUDINARY_CLOUD_NAME ? optimizeCloudinaryDeliveryUrl(url.href) : "";
    }
    if (IMAGEKIT_URL_ENDPOINT && url.href.startsWith(String(IMAGEKIT_URL_ENDPOINT).replace(/\/$/, "") + "/")) {
      return url.href;
    }
    if (url.hostname === "images.unsplash.com") return url.href;
    if (url.hostname === "firebasestorage.googleapis.com") {
      const m = url.pathname.match(/^\/v0\/b\/([^/]+)\//);
      return (m && ALLOWED_BUCKETS.includes(m[1])) ? url.href : "";
    }
    if (url.hostname === "storage.googleapis.com") {
      const first = url.pathname.split("/")[1] || "";
      return ALLOWED_BUCKETS.includes(first) ? url.href : "";
    }
    return "";
  } catch (e) {
    return "";
  }
}

function firstChar(name) {
  const chars = Array.from(String(name || "?").trim());
  return (chars[0] || "?").toUpperCase();
}

function avatarMarkup(url, name) {
  const safe = safeUrl(url);

  if (safe) {
    return `<img src="${escapeHtml(safe)}" alt="" />`;
  }

  return `<span class="avatar-fallback">${escapeHtml(firstChar(name))}</span>`;
}

function toDate(ts) {
  if (!ts) return null;
  if (typeof ts.toDate === "function") return ts.toDate();
  if (ts instanceof Date) return ts;
  if (typeof ts === "number") return new Date(ts);
  if (typeof ts.seconds === "number") return new Date(ts.seconds * 1000);
  return null;
}

function formatTime(ts) {
  const d = toDate(ts);
  if (!d) return "";
  const diff = (Date.now() - d.getTime()) / 1000;
  const nMin = Math.floor(diff / 60), nHour = Math.floor(diff / 3600), nDay = Math.floor(diff / 86400);
  if (state.lang === "mg") {
    if (diff < 60) return "vao izao";
    if (diff < 3600) return `${nMin} min lasa`;
    if (diff < 86400) return `${nHour} ora lasa`;
    if (diff < 604800) return `${nDay} andro lasa`;
    return d.toLocaleDateString("mg-MG");
  }
  if (state.lang === "en") {
    if (diff < 60) return "just now";
    if (diff < 3600) return `${nMin} min ago`;
    if (diff < 86400) return `${nHour} h ago`;
    if (diff < 604800) return `${nDay} d ago`;
    return d.toLocaleDateString("en");
  }
  if (diff < 60) return "à l'instant";
  if (diff < 3600) return `il y a ${nMin} min`;
  if (diff < 86400) return `il y a ${nHour} h`;
  if (diff < 604800) return `il y a ${nDay} j`;
  return d.toLocaleDateString("fr");
}

function setBusy(el, busy, label) {
  if (!el) return;
  if (busy) {
    if (el.dataset.originalHtml === undefined) el.dataset.originalHtml = el.innerHTML;
    el.disabled = true;
    el.setAttribute("aria-busy", "true");
    if (label) el.textContent = label;
  } else {
    el.disabled = false;
    el.removeAttribute("aria-busy");
    if (el.dataset.originalHtml !== undefined) {
      el.innerHTML = el.dataset.originalHtml;
      delete el.dataset.originalHtml;
    }
  }
}

function toggleEmpty(emptyId, hidden) {
  const el = document.getElementById(emptyId);
  if (!el) return;
  el.classList.toggle("hidden", hidden);
}

function setText(id, val) {
  const el = document.getElementById(id);
  if (el) el.textContent = val;
}

function setStatusLine(id, message, stateName = "info") {
  const el = document.getElementById(id);
  if (!el) return;
  el.textContent = message || "";
  if (message) el.dataset.state = stateName;
  else delete el.dataset.state;
}

function friendlyAuthError(err) {
  const code = err && err.code ? err.code : "";
  const map = {
    "auth/email-already-in-use": t("err_email_in_use"),
    "auth/invalid-email": t("err_invalid_email"),
    "auth/weak-password": t("err_weak_password"),
    "auth/invalid-credential": t("err_invalid_credential"),
    "auth/user-not-found": t("err_user_not_found"),
    "auth/wrong-password": t("err_invalid_credential"),
    "auth/too-many-requests": t("err_too_many"),
    "auth/network-request-failed": t("err_network"),
    "auth/requires-recent-login": t("err_invalid_credential"),
    "auth/credential-already-in-use": t("err_invalid_credential"),
    "auth/account-exists-with-different-credential": t("err_invalid_credential")
  };
  if (map[code]) return map[code];
  const phone = {
    fr: {
      "auth/invalid-phone-number":"Numéro de téléphone invalide.",
      "auth/missing-phone-number":"Entrez un numéro de téléphone.",
      "auth/quota-exceeded":"Quota SMS Firebase dépassé. Réessayez plus tard.",
      "auth/captcha-check-failed":"La vérification reCAPTCHA a échoué. Réessayez.",
      "auth/invalid-app-credential":"La vérification de l’application a échoué. Vérifiez reCAPTCHA et le domaine autorisé.",
      "auth/missing-app-credential":"reCAPTCHA n’a pas été initialisé correctement.",
      "auth/operation-not-allowed":"La connexion par téléphone n’est pas activée dans Firebase Authentication.",
      "auth/unauthorized-domain":"Ce domaine n’est pas autorisé dans Firebase Authentication.",
      "auth/code-expired":"Le code SMS a expiré. Demandez un nouveau code.",
      "auth/invalid-verification-code":"Code de vérification incorrect."
    },
    mg: {
      "auth/invalid-phone-number":"Tsy mety ny laharana finday.",
      "auth/missing-phone-number":"Ampidiro ny laharana finday.",
      "auth/quota-exceeded":"Lany ny quota SMS Firebase. Andramo indray afaka kelikely.",
      "auth/captcha-check-failed":"Tsy nahomby ny reCAPTCHA. Andramo indray.",
      "auth/invalid-app-credential":"Tsy nahomby ny fanamarinana ny app. Jereo ny reCAPTCHA sy authorized domain.",
      "auth/missing-app-credential":"Tsy voaomana tsara ny reCAPTCHA.",
      "auth/operation-not-allowed":"Tsy mbola navela ao Firebase Authentication ny connexion téléphone.",
      "auth/unauthorized-domain":"Tsy authorized ao Firebase Authentication ity domaine ity.",
      "auth/code-expired":"Lany daty ilay kaody SMS. Mangataha kaody vaovao.",
      "auth/invalid-verification-code":"Diso ilay kaody fanamarinana."
    },
    en: {
      "auth/invalid-phone-number":"Invalid phone number.",
      "auth/missing-phone-number":"Enter a phone number.",
      "auth/quota-exceeded":"Firebase SMS quota exceeded. Try again later.",
      "auth/captcha-check-failed":"reCAPTCHA verification failed. Try again.",
      "auth/invalid-app-credential":"App verification failed. Check reCAPTCHA and authorized domains.",
      "auth/missing-app-credential":"reCAPTCHA was not initialized correctly.",
      "auth/operation-not-allowed":"Phone sign-in is not enabled in Firebase Authentication.",
      "auth/unauthorized-domain":"This domain is not authorized in Firebase Authentication.",
      "auth/code-expired":"The SMS code has expired. Request a new code.",
      "auth/invalid-verification-code":"Incorrect verification code."
    }
  };
  return (phone[state.lang] || phone.fr)[code] || t("err_generic");
}

function cryptoRandom() {
  if (window.crypto && typeof window.crypto.randomUUID === "function") {
    return window.crypto.randomUUID();
  }
  return Date.now().toString(36) + "_" + Math.random().toString(36).slice(2, 10);
}

function revokeUrl(url) {
  if (url && typeof url === "string" && url.startsWith("blob:")) {
    try { URL.revokeObjectURL(url); } catch (e) { /* noop */ }
  }
}

function normalizeUsername(raw) {
  return String(raw || "").trim().toLowerCase().replace(/^@+/, "");
}

function isValidUsername(u) {
  return /^[a-z0-9_.]{3,24}$/.test(u);
}

function insertAtCursor(el, text) {
  if (!el) return;
  const start = typeof el.selectionStart === "number" ? el.selectionStart : el.value.length;
  const end   = typeof el.selectionEnd === "number" ? el.selectionEnd : start;
  el.value = el.value.slice(0, start) + text + el.value.slice(end);
  const pos = start + text.length;
  try { el.setSelectionRange(pos, pos); } catch (e) { /* noop */ }
  el.focus();
  el.dispatchEvent(new Event("input", { bubbles: true }));
}

function pairKeyOf(a, b) { return [a, b].sort().join("_"); }
function friendshipId(uid1, uid2) { return [uid1, uid2].sort().join("_"); }

function privacyOf(value, fallback = "public") {
  return POST_PRIVACY_VALUES.includes(value) ? value : fallback;
}

function postTimeMs(p) {
  const c = p && p.createdAt;
  if (!c) return Date.now();
  if (typeof c.toMillis === "function") return c.toMillis();
  if (typeof c.seconds === "number") return c.seconds * 1000;
  return 0;
}

function sortPostsNewestFirst(posts) {
  return posts.sort((a, b) => postTimeMs(b) - postTimeMs(a));
}

function logError(tag, err) {
  console.error(tag, (err && err.code) || "", (err && err.message) || err);
}

/* ------------------------------------------------------------
   8. TOAST
   ------------------------------------------------------------ */
let toastTimer = null;
function toast(msg, duration = 2600) {
  const el = $("#toast");
  if (!el) return;
  el.textContent = msg;
  el.classList.remove("hidden");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.add("hidden"), duration);
}

/* ------------------------------------------------------------
   9. MODALES DYNAMIQUES + CONFIRM MODAL
   ------------------------------------------------------------ */
const dynamicModals = [];

function modalColors() {
  return state.theme === "dark"
    ? { bg: "#1c1c22", fg: "#f2f2f5", border: "#34343d", muted: "#9a9aa8", field: "#26262e" }
    : { bg: "#ffffff", fg: "#17171c", border: "#e3e3ea", muted: "#6b6b78", field: "#f4f4f8" };
}

function styledButton(label, kind = "secondary") {
  const c = modalColors();
  const accent = getComputedStyle(document.documentElement).getPropertyValue("--accent").trim() || "#7A1831";
  const accentStrong = getComputedStyle(document.documentElement).getPropertyValue("--accent-strong").trim() || accent;
  const danger = getComputedStyle(document.documentElement).getPropertyValue("--danger").trim() || "#dc2626";
  const b = document.createElement("button");
  b.type = "button";
  b.textContent = label;
  Object.assign(b.style, {
    padding: "10px 16px", borderRadius: "12px", border: "1px solid " + c.border,
    background: c.field, color: c.fg, fontWeight: "600", cursor: "pointer", fontSize: "14px"
  });
  if (kind === "primary") {
    b.style.background = accent;
    b.style.color = "#fff";
    b.style.borderColor = accent;
  } else if (kind === "danger") {
    b.style.background = danger;
    b.style.color = "#fff";
    b.style.borderColor = danger;
  } else if (kind === "secondary") {
    b.style.borderColor = c.border;
  }
  b.addEventListener("mouseenter", () => {
    if (kind === "primary") b.style.background = accentStrong;
  });
  b.addEventListener("mouseleave", () => {
    if (kind === "primary") b.style.background = accent;
  });
  return b;
}

function styledInput(type = "text", placeholder = "") {
  const c = modalColors();
  const i = document.createElement("input");
  i.type = type;
  i.placeholder = placeholder;
  Object.assign(i.style, {
    width: "100%", boxSizing: "border-box", padding: "10px 12px", borderRadius: "10px",
    border: "1px solid " + c.border, background: c.field, color: c.fg, fontSize: "15px"
  });
  return i;
}

function openDynamicModal(title) {
  const c = modalColors();
  const overlay = document.createElement("div");
  overlay.className = "lyrame-dyn-modal";
  Object.assign(overlay.style, {
    position: "fixed", top: "0", right: "0", bottom: "0", left: "0",
    background: "rgba(0,0,0,.55)", zIndex: "10000", display: "flex",
    alignItems: "center", justifyContent: "center", padding: "16px"
  });
  const panel = document.createElement("div");
  panel.setAttribute("role", "dialog");
  panel.setAttribute("aria-modal", "true");
  Object.assign(panel.style, {
    background: c.bg, color: c.fg, borderRadius: "16px", width: "100%", maxWidth: "440px",
    maxHeight: "88vh", overflowY: "auto", padding: "18px", boxSizing: "border-box",
    boxShadow: "0 10px 40px rgba(0,0,0,.35)"
  });
  const h = document.createElement("h3");
  h.textContent = title || "";
  Object.assign(h.style, { margin: "0 0 12px", fontSize: "17px" });
  const body = document.createElement("div");
  panel.append(h, body);
  overlay.appendChild(panel);
  document.body.appendChild(overlay);

  const modal = { overlay, panel, body, onClose: null, close: null };
  modal.close = () => {
    const idx = dynamicModals.indexOf(modal);
    if (idx >= 0) dynamicModals.splice(idx, 1);
    overlay.remove();
    lyrameAndroidOverlayClosed("dynamic-modal");
    if (typeof modal.onClose === "function") modal.onClose();
  };
  overlay.addEventListener("mousedown", e => { if (e.target === overlay) modal.close(); });
  dynamicModals.push(modal);
  lyrameAndroidPushOverlayId("dynamic-modal");
  return modal;
}

let confirmResolver = null;

function resolveConfirm(value) {
  const r = confirmResolver;
  confirmResolver = null;
  hideEl($("#confirm-modal"));
  if (r) r(value);
}

async function showConfirm({
  title = "",
  message = "",
  confirmText = t("confirm_yes"),
  cancelText = t("confirm_no"),
  danger = false
} = {}) {
  return new Promise(resolve => {
    const modal  = $("#confirm-modal");
    const okBtn  = $("#confirm-modal-confirm");
    const noBtn  = $("#confirm-modal-cancel");
    const titleEl = $("#confirm-modal-title");
    const msgEl   = $("#confirm-modal-message");

    if (modal && okBtn && noBtn) {
      if (confirmResolver) { confirmResolver(false); confirmResolver = null; }
      confirmResolver = resolve;
      if (titleEl) titleEl.textContent = title;
      if (msgEl) msgEl.textContent = message;
      okBtn.textContent = confirmText;
      noBtn.textContent = cancelText;
      okBtn.classList.toggle("danger", !!danger);
      okBtn.classList.toggle("btn-danger", !!danger);
      showEl(modal);
      try { noBtn.focus(); } catch (e) { /* noop */ }
      return;
    }

    /* Fallback dynamique (jamais window.confirm) */
    const m = openDynamicModal(title);
    const p = document.createElement("p");
    p.textContent = message;
    p.style.margin = "0 0 16px";
    const row = document.createElement("div");
    Object.assign(row.style, { display: "flex", gap: "10px", justifyContent: "flex-end" });
    const cancel = styledButton(cancelText);
    const ok = styledButton(confirmText, danger ? "danger" : "primary");
    let done = false;
    const finish = v => { if (done) return; done = true; m.close(); resolve(v); };
    cancel.addEventListener("click", () => finish(false));
    ok.addEventListener("click", () => finish(true));
    m.onClose = () => { if (!done) { done = true; resolve(false); } };
    row.append(cancel, ok);
    m.body.append(p, row);
  });
}

/* ------------------------------------------------------------
   9B. LYRAME 39 — ÉCONOMIE MÉDIA / ROUTEUR MULTI-PROVIDER
   ------------------------------------------------------------ */
function optimizeCloudinaryDeliveryUrl(rawUrl) {
  try {
    const u = new URL(String(rawUrl || ""));
    if (u.hostname !== "res.cloudinary.com") return u.href;
    if ((u.pathname.split("/")[1] || "") !== CLOUDINARY_CLOUD_NAME) return "";
    if (/\/(image|video)\/upload\/(?:f_auto\/)?q_auto(?::[^/]+)?\//.test(u.pathname)) return u.href;
    if (u.pathname.includes("/image/upload/")) {
      u.pathname = u.pathname.replace("/image/upload/", "/image/upload/f_auto/q_auto:good/");
    } else if (u.pathname.includes("/video/upload/")) {
      u.pathname = u.pathname.replace("/video/upload/", "/video/upload/f_auto/q_auto:good/");
    }
    return u.href;
  } catch (_) {
    return "";
  }
}

function imageCompressionProfile(folder = "") {
  const f = String(folder || "").toLowerCase();
  if (f.includes("avatar")) return { maxEdge: 720, quality: 0.86 };
  if (f.includes("stories") || f.includes("comments") || f.includes("messages")) return { maxEdge: 1440, quality: 0.84 };
  if (f.includes("cover") || f.includes("posts") || f.includes("marketplace") || f.includes("pages")) return { maxEdge: 1920, quality: 0.86 };
  return { maxEdge: 1600, quality: 0.85 };
}

function loadImageForCompression(file) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => { URL.revokeObjectURL(url); resolve(img); };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error("IMAGE_DECODE_FAILED")); };
    img.src = url;
  });
}

async function compressImageForUpload(file, folder = "") {
  if (!file || !String(file.type || "").startsWith("image/")) return file;
  const type = String(file.type || "").toLowerCase();
  if (type.includes("gif") || type.includes("svg")) return file; // animation/vectoriel préservés
  if (file.size <= 450 * 1024) return file; // déjà léger : ne pas recomprimer

  try {
    const img = await loadImageForCompression(file);
    const profile = imageCompressionProfile(folder);
    const w = Number(img.naturalWidth || img.width || 0);
    const h = Number(img.naturalHeight || img.height || 0);
    if (!w || !h) return file;

    const scale = Math.min(1, profile.maxEdge / Math.max(w, h));
    const outW = Math.max(1, Math.round(w * scale));
    const outH = Math.max(1, Math.round(h * scale));
    const canvas = document.createElement("canvas");
    canvas.width = outW;
    canvas.height = outH;
    const ctx = canvas.getContext("2d", { alpha: true });
    if (!ctx) return file;
    ctx.drawImage(img, 0, 0, outW, outH);

    const blob = await new Promise(resolve => canvas.toBlob(resolve, "image/webp", profile.quality));
    if (!blob || blob.size >= file.size * 0.92) return file; // tsy misy tombony mazava

    const base = String(file.name || "image").replace(/\.[^.]+$/, "");
    return new File([blob], `${base}.webp`, { type: "image/webp", lastModified: Date.now() });
  } catch (err) {
    console.warn("[media compression] original preserved", err);
    return file;
  }
}

async function fetchImageKitUploadAuth() {
  if (!IMAGEKIT_AUTH_ENDPOINT || !IMAGEKIT_PUBLIC_KEY) throw new Error("IMAGEKIT_NOT_CONFIGURED");
  if (!state.currentUser) throw new Error("IMAGEKIT_AUTH_REQUIRED");
  const idToken = await state.currentUser.getIdToken();
  const res = await fetch(IMAGEKIT_AUTH_ENDPOINT, {
    method: "POST",
    headers: { "Content-Type": "text/plain;charset=UTF-8" },
    body: JSON.stringify({ action: "imagekitAuth", idToken })
  });
  if (!res.ok) throw new Error(`IMAGEKIT_AUTH_${res.status}`);
  const data = await res.json();
  if (!data?.token || !data?.signature || !data?.expire) throw new Error("IMAGEKIT_AUTH_INVALID");
  return data;
}

async function uploadToImageKit(file, { folder = "lyrame", onProgress } = {}) {
  if (!LYRAME_MEDIA_SECONDARY_ENABLED) throw new Error("IMAGEKIT_DISABLED");
  const authData = await fetchImageKitUploadAuth();
  const prepared = await compressImageForUpload(file, folder);
  const form = new FormData();
  form.append("file", prepared);
  form.append("fileName", prepared.name || `lyrame-${Date.now()}`);
  form.append("publicKey", IMAGEKIT_PUBLIC_KEY);
  form.append("token", authData.token);
  form.append("signature", authData.signature);
  form.append("expire", String(authData.expire));
  if (folder) form.append("folder", "/" + String(folder).replace(/^\/+/, ""));

  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "https://upload.imagekit.io/api/v1/files/upload");
    if (xhr.upload && typeof onProgress === "function") {
      xhr.upload.onprogress = e => e.lengthComputable && onProgress(Math.min(99, Math.round((e.loaded / e.total) * 100)));
    }
    xhr.onload = () => {
      let data = null;
      try { data = JSON.parse(xhr.responseText || "{}"); } catch (_) {}
      if (xhr.status >= 200 && xhr.status < 300 && data?.url) {
        if (typeof onProgress === "function") onProgress(100);
        resolve({
          url: data.url,
          publicId: data.fileId || "",
          fileId: data.fileId || "",
          provider: "imagekit",
          resourceType: String(prepared.type || "").startsWith("video/") ? "video" : "image",
          format: String(data.fileType || ""),
          bytes: Number(data.size || prepared.size || 0),
          width: data.width || null,
          height: data.height || null,
          duration: data.duration || null
        });
      } else reject(new Error(data?.message || `IMAGEKIT_UPLOAD_${xhr.status}`));
    };
    xhr.onerror = () => reject(new Error("IMAGEKIT_UPLOAD_NETWORK"));
    xhr.send(form);
  });
}

async function uploadMedia(file, options = {}) {
  /* Auto-router. Cloudinary reste le primaire tant qu'ImageKit n'est pas activé.
     Après activation, une erreur ImageKit retombe toujours sur Cloudinary pour
     éviter de perdre une publication. */
  if (LYRAME_MEDIA_SECONDARY_ENABLED && LYRAME_MEDIA_PRIMARY === "imagekit") {
    try { return await uploadToImageKit(file, options); }
    catch (err) { console.warn("[media router] ImageKit -> Cloudinary fallback", err); }
  }
  return uploadToCloudinary(file, options);
}

/* ------------------------------------------------------------
   10. CLOUDINARY (unsigned, XMLHttpRequest pour la progression)
   ------------------------------------------------------------ */
async function uploadToCloudinary(
  file,
  {
    folder = "lyrame",
    resourceType = "auto",
    onProgress,
    signal = null
  } = {}
) {
  if (!file) throw new Error("NO_FILE");
  const originalFile = file;
  const preparedFile = String(file.type || "").startsWith("image/")
    ? await compressImageForUpload(file, folder)
    : file;

  return new Promise((resolve, reject) => {
    const form = new FormData();
    form.append("file", preparedFile);
    form.append("upload_preset", CLOUDINARY_UPLOAD_PRESET);

    if (folder) {
      form.append("folder", folder);
    }

    const endpoint =
      `https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUD_NAME}/${resourceType}/upload`;

    const xhr = new XMLHttpRequest();
    xhr.open("POST", endpoint);

    let settled = false;

    const fail = err => {
      if (settled) return;
      settled = true;
      reject(err);
    };

    if (signal) {
      if (signal.aborted) {
        fail(new Error("UPLOAD_ABORTED"));
        return;
      }

      signal.addEventListener(
        "abort",
        () => {
          try {
            xhr.abort();
          } catch (_) {}
        },
        { once: true }
      );
    }

    if (xhr.upload && typeof onProgress === "function") {
      xhr.upload.onprogress = e => {
        if (!e.lengthComputable) return;

        onProgress(
          Math.min(
            99,
            Math.round((e.loaded / e.total) * 100)
          )
        );
      };
    }

    xhr.onload = () => {
      let data = null;

      try {
        data = JSON.parse(xhr.responseText);
      } catch (_) {
        fail(new Error("INVALID_RESPONSE"));
        return;
      }

      if (
        xhr.status >= 200 &&
        xhr.status < 300 &&
        data &&
        data.secure_url
      ) {
        if (settled) return;

        settled = true;

        if (typeof onProgress === "function") {
          onProgress(100);
        }

        resolve({
          url: (String(originalFile.type || "").startsWith("audio/") ? data.secure_url : optimizeCloudinaryDeliveryUrl(data.secure_url)),
          originalUrl: data.secure_url,
          publicId: data.public_id || "",
          provider: "cloudinary",
          resourceType: data.resource_type || resourceType,
          format: data.format || "",
          bytes: data.bytes || preparedFile.size || 0,
          originalBytes: originalFile.size || 0,
          width: data.width || null,
          height: data.height || null,
          duration: data.duration || null
        });

        return;
      }

      const err = new Error(
        (data && data.error && data.error.message) ||
        `UPLOAD_FAILED_${xhr.status}`
      );

      err.status = xhr.status;

      fail(err);
    };

    xhr.onerror = () => fail(new Error("UPLOAD_NETWORK"));
    xhr.onabort = () => fail(new Error("UPLOAD_ABORTED"));
    xhr.ontimeout = () => fail(new Error("UPLOAD_TIMEOUT"));

    xhr.send(form);
  });
}

/* Suppression Cloudinary : impossible en unsigned depuis le front.
   No-op (console seulement) en attendant un backend signé. */
async function safeDeleteMediaAsset(publicId) {
  if (!publicId) return;
  console.warn("[cloudinary cleanup skipped]", publicId);
}

/* ------------------------------------------------------------
   11. VALIDATION DES FICHIERS
   ------------------------------------------------------------ */
function getMediaDuration(file, tag) {
  return new Promise(resolve => {
    const url = URL.createObjectURL(file);
    const el = document.createElement(tag);
    el.preload = "metadata";
    el.onloadedmetadata = () => { const d = el.duration; URL.revokeObjectURL(url); resolve(d); };
    el.onerror = () => { URL.revokeObjectURL(url); resolve(NaN); };
    el.src = url;
  });
}

async function validateMedia(file, kind) {
  if (!file) return { ok: false, msg: t("err_generic") };
  const type = file.type || "";
  switch (kind) {
    case "avatar":
      if (!type.startsWith("image/")) return { ok: false, msg: t("err_avatar_type") };
      if (file.size > MAX_AVATAR_BYTES) return { ok: false, msg: t("err_avatar_too_large") };
      return { ok: true };
    case "cover":
      if (!type.startsWith("image/")) return { ok: false, msg: t("err_cover_type") };
      if (file.size > MAX_COVER_BYTES) return { ok: false, msg: t("err_cover_too_large") };
      return { ok: true };
    case "image":
      if (!type.startsWith("image/")) return { ok: false, msg: t("err_file_type") };
      if (file.size > MAX_IMAGE_BYTES) return { ok: false, msg: t("err_file_too_large") };
      return { ok: true };
    case "video": {
      if (!type.startsWith("video/")) return { ok: false, msg: t("err_file_type") };
      if (file.size > MAX_VIDEO_BYTES) return { ok: false, msg: t("err_file_too_large") };
      const d = await getMediaDuration(file, "video");
      if (!Number.isFinite(d)) return { ok: false, msg: t("err_media_read") };
      if (d > VIDEO_MAX_SEC) return { ok: false, msg: t("err_media_too_long_video") };
      return { ok: true };
    }
    case "audio": {
      if (!type.startsWith("audio/")) return { ok: false, msg: t("err_file_type") };
      if (file.size > MAX_AUDIO_BYTES) return { ok: false, msg: t("err_file_too_large") };
      const d = await getMediaDuration(file, "audio");
      if (!Number.isFinite(d)) return { ok: false, msg: t("err_media_read") };
      if (d > AUDIO_MAX_SEC) return { ok: false, msg: t("err_media_too_long_audio") };
      return { ok: true };
    }
    default:
      return { ok: false, msg: t("err_file_type") };
  }
}

/* ------------------------------------------------------------
   12. PROFILS (cache), NOTIFICATIONS
   ------------------------------------------------------------ */
async function getUserProfile(uid, { force = false } = {}) {
  if (!uid) return null;
  if (!force && state.currentUser && uid === state.currentUser.uid && state.currentProfile) {
    return state.currentProfile;
  }
  const hit = profileCache.get(uid);
  if (!force && hit && (Date.now() - hit.at) < PROFILE_CACHE_TTL) return hit.data;
  if (profilePending.has(uid)) return profilePending.get(uid);

  const p = getDoc(doc(db, "users", uid))
    .then(snap => {
      const data = snap.exists() ? { uid, ...snap.data() } : null;
      profileCache.set(uid, { data, at: Date.now() });
      return data;
    })
    .catch(err => {
      console.warn("[getUserProfile]", uid, err);
      return hit ? hit.data : null;
    })
    .finally(() => { profilePending.delete(uid); });

  profilePending.set(uid, p);
  return p;
}

/* users/{uid} doit exister avant une écriture qui dépend de lui */
async function ensureUserDocument() {
  const user = state.currentUser;
  if (!user) return;
  const ref = doc(db, "users", user.uid);
  try {
    const snap = await getDoc(ref);
    if (snap.exists()) return;
  } catch (e) {
    console.warn("[ensureUserDocument read]", e);
  }
  try {
    await setDoc(ref, buildFallbackProfile(user), { merge: true });
  } catch (e) {
    console.warn("[ensureUserDocument write]", e);
  }
}

function buildFallbackProfile(user) {
  return {
    uid: user.uid,
    fullname: user.displayName || "",
    username: "",
    email: user.email || "",
    bio: "",
    photoURL: user.photoURL || "",
    coverURL: "",
    avatarPublicId: "",
    coverPublicId: "",
    followersCount: 0,
    followingCount: 0,
    postsCount: 0,
    birthdate: "",
    birthdatePrivacy: "private",
    showOnlineStatus: true,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp()
  };
}

/* ------------------------------------------------------------
   BADGES D’IDENTITÉ — badge fondateur protégé + badges utilisateurs
   ------------------------------------------------------------ */
const LYRAME_FOUNDER_AUTH_EMAIL = "christionalain1@gmail.com";
let founderBadgeAttemptedUid = "";

function badgeTypeOf(profile) {
  if (!profile) return "";
  const allowed = new Set(["founder", "verified", "creator", "moderator", "admin", "supporter"]);
  const direct = String(profile.badgeType || "").trim().toLowerCase();
  if (allowed.has(direct)) return direct;

  const badges = Array.isArray(profile.badges) ? profile.badges.map(x => String(x || "").toLowerCase()) : [];
  for (const type of ["founder", "admin", "moderator", "verified", "creator", "supporter"]) {
    if (badges.includes(type)) return type;
  }

  const role = String(profile.appRole || profile.role || "").trim().toLowerCase();
  if (role === "founder") return "founder";
  if (["app_admin", "admin"].includes(role)) return "admin";
  if (["moderator", "mod"].includes(role)) return "moderator";
  if (profile.verified === true) return "verified";
  if (profile.creator === true) return "creator";
  return "";
}

function badgeLabel(type) {
  const labels = {
    founder: uiText("Fondateur LYRAME", "Mpanorina LYRAME", "LYRAME Founder"),
    verified: uiText("Compte vérifié", "Kaonty voamarina", "Verified account"),
    creator: uiText("Créateur", "Mpamorona", "Creator"),
    moderator: uiText("Modérateur", "Mpanara-maso", "Moderator"),
    admin: uiText("Administrateur", "Mpitantana", "Administrator"),
    supporter: uiText("Supporter", "Mpanohana", "Supporter")
  };
  return labels[type] || "";
}

function identityBadgeMarkup(profile) {
  const type = badgeTypeOf(profile);
  if (!type) return "";
  const label = badgeLabel(type);
  const icon = { founder: "◆", verified: "✓", creator: "✦", moderator: "M", admin: "A", supporter: "★" }[type] || "✓";
  const word = type === "founder" ? '<span class="identity-badge-word">LYRAME</span>' : "";
  return `<span class="identity-badge identity-badge-${type}" title="${escapeHtml(label)}" aria-label="${escapeHtml(label)}"><span class="identity-badge-icon" aria-hidden="true">${icon}</span>${word}</span>`;
}

function setNameWithBadge(id, name, profile) {
  const el = document.getElementById(id);
  if (!el) return;
  el.innerHTML = `${escapeHtml(name || "")}${identityBadgeMarkup(profile)}`;
}

async function ensureFounderBadgeForCurrentUser() {
  const user = state.currentUser;
  if (!user?.uid) return;
  if (String(user.email || "").trim().toLowerCase() !== LYRAME_FOUNDER_AUTH_EMAIL) return;
  if (badgeTypeOf(state.currentProfile) === "founder") return;
  if (founderBadgeAttemptedUid === user.uid) return;
  founderBadgeAttemptedUid = user.uid;
  try {
    await setDoc(doc(db, "users", user.uid), {
      badgeType: "founder",
      updatedAt: serverTimestamp()
    }, { merge: true });
  } catch (err) {
    console.warn("[founder badge sync]", err);
  }
}

const LYRAME_INSTANT_PUSH_URL = "https://script.google.com/macros/s/AKfycbzWJb_p4b7xN1ItxNCqIbHL3-jswWzB54aEE5i1f-I6XITNRIpuBIhL-bRhqXtcEJBTmw/exec";

async function requestInstantPush(notificationId) {
  if (!notificationId || !state.currentUser) return;
  try {
    const idToken = await state.currentUser.getIdToken();
    await fetch(LYRAME_INSTANT_PUSH_URL, {
      method: "POST",
      mode: "no-cors",
      headers: { "Content-Type": "text/plain;charset=UTF-8" },
      body: JSON.stringify({ idToken, notificationId })
    });
  } catch (err) {
    console.warn("[instant push]", err);
  }
}

async function createNotification({ id, userId, actorId, type, title, preview, extra }) {
  if (!userId || !state.currentUser) return;
  const actor = actorId || state.currentUser.uid;
  if (userId === actor) return;
  const payload = {
    userId,
    actorId: actor,
    actorName: state.currentProfile?.fullname || "",
    actorPhotoURL: state.currentProfile?.photoURL || "",
    type: type || "generic",
    title: title || "Notification",
    preview: preview || "",
    read: false,
    createdAt: serverTimestamp(),
    ...(extra || {})
  };
  try {
    let notificationId = id || "";
    if (id) {
      await setDoc(doc(db, "notifications", id), payload);
    } else {
      const ref = await addDoc(collection(db, "notifications"), payload);
      notificationId = ref.id;
    }
    requestInstantPush(notificationId);
  } catch (e) {
    console.warn("[createNotification]", e);
  }
}

async function notifyConversationMembers(convId, text, kind) {
  if (!state.currentUser) return;
  try {
    const snap = await getDoc(doc(db, "conversations", convId));
    if (!snap.exists()) return;
    const c = snap.data();
    const members = Array.isArray(c.memberIds) ? c.memberIds : [];
    const senderName = state.currentProfile?.fullname || uiSomeone();
    const title = c.isGroup ? `${c.name || uiGroup()}` : senderName;
    const mediaLabel = kind === "image" ? uiText("image", "sary", "image")
      : kind === "video" ? uiText("vidéo", "horonan-tsary", "video")
      : kind === "audio" ? uiText("audio", "feo", "audio") : "";
    const preview = text ? text.slice(0, 80) : (mediaLabel ? `[${mediaLabel}]` : uiText("Nouveau message", "Hafatra vaovao", "New message"));
    await Promise.all(members
      .filter(uid => uid !== state.currentUser.uid)
      .map(uid => createNotification({
        userId: uid,
        actorId: state.currentUser.uid,
        type: "message",
        title,
        preview,
        extra: { conversationId: convId }
      })));
  } catch (e) {
    console.warn("[notifyConversationMembers]", e);
  }
}

/* ------------------------------------------------------------
   13. THÈME & LANGUE
   ------------------------------------------------------------ */
function applyTheme(theme, { persist = false } = {}) {
  theme = theme === "dark" ? "dark" : "light";
  document.documentElement.setAttribute("data-theme", theme);
  state.theme = theme;
  if (persist && state.currentUser) void saveAccountUiPreferences({ uiTheme: theme });

  const icon = $("#header-theme-icon");
  if (icon) {
    icon.innerHTML = theme === "dark"
      ? `<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>`
      : `<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/></svg>`;
  }
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute("content", theme === "dark" ? "#09090B" : "#7A1831");
}

function toggleTheme() {
  const next = state.theme === "dark" ? "light" : "dark";
  applyTheme(next, { persist: true });
  toast(next === "dark" ? t("theme_dark") : t("theme_light"));
}

const STATIC_UI_TEXT = [
  ["Email", "Mailaka", "Email"],
  ["Mot de passe", "Tenimiafina", "Password"],
  ["Se connecter", "Hiditra", "Sign in"],
  ["Mot de passe oublié ?", "Hadinonao ny tenimiafina?", "Forgot password?"],
  ["Créer un compte", "Hamorona kaonty", "Create account"],
  ["Rejoignez LYRAME.", "Midira ao amin'ny LYRAME.", "Join LYRAME."],
  ["Nom complet", "Anarana feno", "Full name"],
  ["Nom d'utilisateur", "Anaran'ny mpampiasa", "Username"],
  ["Téléphone", "Laharana finday", "Phone"],
  ["Numéro de téléphone", "Laharana finday", "Phone number"],
  ["Envoyer le code", "Handefa kaody", "Send code"],
  ["Code de vérification", "Kaody fanamarinana", "Verification code"],
  ["Vérifier le numéro", "Hanamarina ny laharana", "Verify number"],
  ["Vérifier et se connecter", "Hanamarina ary hiditra", "Verify and sign in"],
  ["Confirmation du mot de passe", "Fanamafisana ny tenimiafina", "Confirm password"],
  ["S'inscrire", "Hisoratra anarana", "Sign up"],
  ["J'ai déjà un compte", "Efa manana kaonty aho", "I already have an account"],
  ["Mot de passe oublié", "Tenimiafina hadino", "Forgot password"],
  ["Recevez un lien de réinitialisation.", "Mahazoa rohy hanovana tenimiafina.", "Receive a reset link."],
  ["Envoyer le lien", "Handefa ny rohy", "Send link"],
  ["Retour à la connexion", "Hiverina amin'ny fidirana", "Back to sign in"],
  ["Pour vous", "Ho anao", "For you"],
  ["Poésie", "Tononkalo", "Poetry"],
  ["Motivation", "Famporisihana", "Motivation"],
  ["Amour", "Fitiavana", "Love"],
  ["Vie", "Fiainana", "Life"],
  ["Tristesse", "Alahelo", "Sadness"],
  ["Séparation", "Fisarahana", "Separation"],
  ["Mariage", "Fanambadiana", "Marriage"],
  ["Espoir", "Fanantenana", "Hope"],
  ["Aucune publication pour le moment", "Mbola tsy misy publication", "No posts yet"],
  ["Soyez parmi les premiers à publier.", "Ho an'ny mpampiasa voalohany ianao raha manomboka manoratra.", "Be among the first to start writing."],
  ["Créer une publication", "Hamorona publication", "Create a post"],
  ["Chargement…", "Eo am-pampidirana…", "Loading…"],
  ["Rechercher des utilisateurs", "Mikaroka mpampiasa", "Search users"],
  ["Saisissez un nom ou un nom d’utilisateur pour commencer.", "Soraty ny anarana na username hanombohana.", "Type a name or username to begin."],
  ["Nouvelle publication", "Publication vaovao", "New post"],
  ["Publier", "Hamoaka", "Publish"],
  ["Couleur du texte", "Lokon'ny soratra", "Text color"],
  ["Confidentialité", "Fahitana", "Privacy"],
  ["Public", "Ho an'ny rehetra", "Public"],
  ["Amis", "Namana", "Friends"],
  ["Moi uniquement", "Izaho ihany", "Only me"],
  ["Catégorie", "Sokajy", "Category"],
  ["Photo", "Sary", "Photo"],
  ["Format de l'image", "Endriky ny sary", "Image format"],
  ["Original", "Tany am-boalohany", "Original"],
  ["Vidéo", "Horonan-tsary", "Video"],
  ["Retirer le média", "Hanala rakitra", "Remove media"],
  ["Publication", "Publication", "Post"],
  ["Commentaires", "Hevitra", "Comments"],
  ["Masquer les commentaires", "Hanafina hevitra", "Hide comments"],
  ["Envoyer", "Handefa", "Send"],
  ["Aucun commentaire pour le moment", "Mbola tsy misy hevitra", "No comments yet"],
  ["Soyez le premier à commenter.", "Manaova voalohany ny hevitrao.", "Be the first to comment."],
  ["Voir plus de commentaires", "Hijery hevitra fanampiny", "View more comments"],
  ["Messages", "Hafatra", "Messages"],
  ["Aucune conversation pour le moment", "Mbola tsy misy resaka", "No conversations yet"],
  ["Commencez une conversation avec un autre utilisateur ou créez un groupe.", "Manomboha resaka amin'ny mpampiasa hafa na mamorona vondrona.", "Start a conversation or create a group."],
  ["Commencer la conversation", "Manomboha ny resaka", "Start the conversation"],
  ["Envoyez votre premier message.", "Alefaso ny hafatrao voalohany.", "Send your first message."],
  ["Enregistrement", "Mandrakitra feo", "Recording"],
  ["Supprimer", "Hamafa", "Delete"],
  ["Arrêter", "Hajanona", "Stop"],
  ["Envoi en cours…", "Eo am-pandefasana…", "Uploading…"],
  ["Réessayer", "Hanandrana indray", "Retry"],
  ["Annuler", "Hanafoana", "Cancel"],
  ["Infos du groupe", "Mombamomba ny vondrona", "Group info"],
  ["Modifier le groupe", "Hanova vondrona", "Edit group"],
  ["Gérer les membres", "Hitantana mpikambana", "Manage members"],
  ["Membres", "Mpikambana", "Members"],
  ["Aucun membre pour le moment", "Mbola tsy misy mpikambana", "No members yet"],
  ["Ajouter un membre", "Hanampy mpikambana", "Add member"],
  ["Quitter le groupe", "Hiala amin'ny vondrona", "Leave group"],
  ["Enregistrer", "Hitahiry", "Save"],
  ["Nom du groupe", "Anaran'ny vondrona", "Group name"],
  ["Description", "Famaritana", "Description"],
  ["Confidentialité du groupe", "Fahitan'ny vondrona", "Group privacy"],
  ["Privé", "Manokana", "Private"],
  ["Nouveau groupe", "Vondrona vaovao", "New group"],
  ["Créer", "Hamorona", "Create"],
  ["Retirer la couverture", "Hanala sary fonony", "Remove cover"],
  ["Sélectionner les membres", "Hisafidy mpikambana", "Select members"],
  ["Aucun utilisateur trouvé", "Tsy misy mpampiasa hita", "No users found"],
  ["Modifier le profil", "Hanova profil", "Edit profile"],
  ["Demandes d'amis", "Fangatahana ho namana", "Friend requests"],
  ["Aide", "Fanampiana", "Help"],
  ["Publications", "Publication", "Posts"],
  ["Abonnés", "Mpanaraka", "Followers"],
  ["Abonnements", "Arahi-nao", "Following"],
  ["Photos", "Sary", "Photos"],
  ["Vidéos", "Horonan-tsary", "Videos"],
  ["À propos", "Momba", "About"],
  ["Commencez à partager vos pensées avec le monde.", "Manomboka mizara amin'ny tontolo ny eritreritrao.", "Start sharing your thoughts."],
  ["Profil", "Profil", "Profile"],
  ["S'abonner", "Hanaraka", "Follow"],
  ["Ajouter aux amis", "Hanampy ho namana", "Add friend"],
  ["Message", "Hafatra", "Message"],
  ["Aucun abonné pour le moment", "Mbola tsy misy mpanaraka", "No followers yet"],
  ["Vous ne suivez encore personne", "Mbola tsy manaraka olona ianao", "You are not following anyone yet"],
  ["Demandes", "Fangatahana", "Requests"],
  ["Aucun ami pour le moment", "Mbola tsy misy namana", "No friends yet"],
  ["Aucune demande pour le moment", "Tsy misy fangatahana", "No requests"],
  ["Bio", "Mombamomba", "Bio"],
  ["Date de naissance", "Daty nahaterahana", "Date of birth"],
  ["Qui peut voir ma date de naissance", "Iza no afaka mahita ny daty nahaterahako", "Who can see my date of birth"],
  ["Afficher mon statut en ligne", "Hampiseho fa an-tserasera aho", "Show my online status"],
  ["Notifications", "Fampandrenesana", "Notifications"],
  ["Aucune notification pour le moment", "Mbola tsy misy fampandrenesana", "No notifications yet"],
  ["Voir tout", "Hijery rehetra", "View all"],
  ["Répondre", "Hamaly", "Reply"],
  ["Votre réponse", "Valinteninao", "Your reply"],
  ["Envoyer la réponse", "Handefa valiny", "Send reply"],
  ["Paramètres", "Fikirana", "Settings"],
  ["Compte", "Kaonty", "Account"],
  ["Paramètres du compte", "Fikirana kaonty", "Account settings"],
  ["Trouver un compte", "Hitady kaonty", "Find an account"],
  ["Ajouter un compte", "Hanampy kaonty", "Add account"],
  ["Sécurité du compte", "Fiarovana ny kaonty", "Account security"],
  ["Application", "Rindranasa", "Application"],
  ["Langue", "Fiteny", "Language"],
  ["Vider le cache", "Hanadio cache", "Clear cache"],
  ["Effacer les données", "Hamafa angona", "Clear data"],
  ["Informations", "Fampahalalana", "Information"],
  ["Tester un lien", "Hitsapa rohy", "Test a link"],
  ["Vérifiez si un lien public répond avant de le partager.", "Hamarino raha mandeha ny rohy public alohan'ny hizarana azy.", "Check whether a public link responds before sharing it."],
  ["Lien à tester", "Rohy hotsapaina", "Link to test"],
  ["Collez ou modifiez un lien ici…", "Apetaho na ovay eto ny rohy…", "Paste or edit a link here…"],
  ["Tester", "Hitsapa", "Test"],
  ["Ouvrir le lien", "Hanokatra ny rohy", "Open link"],
  ["Vérification", "Fanamarinana", "Verification"],
  ["Adresse finale", "Adiresy farany", "Final address"],
  ["Signaler un problème", "Hitatitra olana", "Report a problem"],
  ["Se déconnecter", "Hivoaka", "Sign out"],
  ["Ajouter ou vérifier un numéro", "Hanampy na hanamarina laharana", "Add or verify a number"],
  ["Modifier le mot de passe LYRAME", "Hanova tenimiafina LYRAME", "Change LYRAME password"],
  ["Sécurité", "Fiarovana", "Security"],
  ["Authentification à deux facteurs", "Fanamarinana dingana roa", "Two-factor authentication"],
  ["Type de problème", "Karazana olana", "Problem type"],
  ["Bug", "Olana ara-teknika", "Bug"],
  ["Autre", "Hafa", "Other"],
  ["Décrivez le problème", "Farito ny olana", "Describe the problem"],
  ["Ajouter une capture d'écran", "Hanampy pikantsary", "Add screenshot"],
  ["Retirer la capture", "Hanala pikantsary", "Remove screenshot"],
  ["Envoyer le signalement", "Handefa tatitra", "Send report"],
  ["Créer une publication", "Hamorona publication", "Create a post"],
  ["Commenter", "Hametraka hevitra", "Comment"],
  ["Réagir à une publication", "Haneho fihetseham-po amin'ny publication", "React to a post"],
  ["Envoyer un message", "Handefa hafatra", "Send a message"],
  ["Créer un groupe", "Hamorona vondrona", "Create a group"],
  ["Gérer ses amis", "Hitantana namana", "Manage friends"],
  ["Modifier son profil", "Hanova profil", "Edit profile"],
  ["Changer la langue", "Hanova fiteny", "Change language"],
  ["Modifier son mot de passe", "Hanova tenimiafina", "Change password"],
  ["Accueil", "Fandraisana", "Home"],
  ["Recherche", "Fikarohana", "Search"],
  ["Confirmation", "Fanamafisana", "Confirmation"],
  ["LYRAME — Les mots qui viennent du cœur", "LYRAME — Teny avy ao am-po", "LYRAME — Words from the heart"],
  ["Les idées trouvent leur orbite", "Mahita ny lalany ny hevitra", "Ideas find their orbit"],
  ["Petit", "Kely", "Small"],
  ["Normal", "Mahazatra", "Normal"],
  ["Grand", "Lehibe", "Large"],
  ["Très grand", "Tena lehibe", "Very large"],
  ["Mention", "Hanonona", "Mention"],
  ["Fond LYRAME", "Fond LYRAME", "LYRAME background"],
  ["Format vidéo", "Endriky ny horonan-tsary", "Video format"],
  ["Arrière-plan LYRAME", "Fond LYRAME", "LYRAME background"],
  ["Format arrière-plan", "Endriky ny fond", "Background format"],
  ["Voir plus", "Hijery fanampiny", "See more"],
  ["Appuyez sur Créer, ajoutez un titre, écrivez votre texte, choisissez la mise en forme, la confidentialité et la catégorie. Vous pouvez ajouter une photo ou une vidéo, puis appuyez sur Publier.", "Tsindrio Hamorona, ampio lohateny, soraty ny lahatsoratrao, safidio ny endrika, ny fahitana ary ny sokajy. Afaka manampy sary na horonan-tsary ianao, avy eo tsindrio Hamoaka.", "Tap Create, add a title, write your text, choose formatting, privacy and category. You can add a photo or video, then tap Publish."],
  ["Ouvrez une publication et écrivez votre commentaire dans le champ sous le contenu. Vous pouvez ajouter un emoji ou une image avant d'envoyer.", "Sokafy ny publication iray ary soraty eo ambanin'ny votoaty ny hevitrao. Afaka manampy emoji na sary ianao alohan'ny handefasana.", "Open a post and write your comment in the field below the content. You can add an emoji or image before sending."],
  ["Appuyez sur le bouton de réaction sous une publication, puis choisissez un emoji. Une seule réaction est active par publication.", "Tsindrio ny bokotra fihetseham-po eo ambanin'ny publication, avy eo mifidiana emoji. Fihetseham-po iray ihany no mavitrika isaky ny publication.", "Tap the reaction button under a post, then choose an emoji. Only one reaction is active per post."],
  ["Ouvrez l'onglet Messages, choisissez une conversation ou créez-en une. Vous pouvez envoyer du texte, une image, une vidéo (max 5 min) ou un audio (max 1 min).", "Sokafy ny Hafatra, mifidiana resaka na mamoròna vaovao. Afaka mandefa lahatsoratra, sary, horonan-tsary (5 minitra farafahabetsany) na feo (1 minitra farafahabetsany) ianao.", "Open Messages, choose a conversation or create one. You can send text, an image, a video (max 5 min) or audio (max 1 min)."],
  ["Dans Messages, appuyez sur l'icône groupe en haut. Ajoutez une couverture, un nom, une description, choisissez la confidentialité, puis sélectionnez les membres.", "Ao amin'ny Hafatra, tsindrio ny kisary vondrona eo ambony. Ampio sary fonony, anarana, famaritana, safidio ny fahitana, avy eo fidio ny mpikambana.", "In Messages, tap the group icon at the top. Add a cover, name, description, choose privacy, then select members."],
  ["Sur le profil d'un utilisateur, appuyez sur Ajouter aux amis. Retrouvez vos amis et vos demandes depuis le menu de votre profil.", "Ao amin'ny profil-n'ny mpampiasa, tsindrio Hanampy ho namana. Hita ao amin'ny menun'ny profil-nao ny namanao sy ny fangatahana.", "On a user's profile, tap Add friend. Find your friends and requests from your profile menu."],
  ["Allez sur votre Profil, puis Modifier le profil. Vous pouvez changer la photo de profil, la couverture, le nom, le nom d'utilisateur, la bio, la date de naissance et vos options de confidentialité.", "Mankanesa ao amin'ny Profil, avy eo Hanova profil. Azonao ovaina ny sarin'ny profil, ny sary fonony, ny anarana, ny anaran'ny mpampiasa, ny bio, ny daty nahaterahana ary ny safidy momba ny fahitana.", "Go to Profile, then Edit profile. You can change the profile photo, cover, name, username, bio, date of birth and privacy options."],
  ["Paramètres, puis Langue. Choisissez la langue de l'interface.", "Fikirana, avy eo Fiteny. Safidio ny fitenin'ny interface.", "Settings, then Language. Choose the interface language."],
  ["Paramètres, puis Sécurité du compte, puis Modifier le mot de passe.", "Fikirana, avy eo Fiarovana ny kaonty, avy eo Hanova tenimiafina.", "Settings, then Account security, then Change password."],
  ["LYRAME est un réseau social centré sur les mots, les émotions, la poésie, l'amour, la motivation, la vie, la tristesse, la séparation, le mariage, l'espoir et le partage.", "LYRAME dia tambajotra sosialy mifantoka amin'ny teny, fihetseham-po, tononkalo, fitiavana, famporisihana, fiainana, alahelo, fisarahana, fanambadiana, fanantenana ary fizarana.", "LYRAME is a social network centered on words, emotions, poetry, love, motivation, life, sadness, separation, marriage, hope and sharing."],
  ["Vous pouvez publier, réagir, commenter, suivre d'autres utilisateurs, vous faire des amis, échanger en messages privés et créer des groupes.", "Afaka mamoaka publication, maneho fihetseham-po, mametraka hevitra, manaraka mpampiasa hafa, manao namana, mifampiresaka manokana ary mamorona vondrona ianao.", "You can publish, react, comment, follow other users, make friends, exchange private messages and create groups."],
  ["Méthode de connexion", "Fomba fidirana", "Sign-in method"],
  ["Méthode d'inscription", "Fomba fisoratana anarana", "Sign-up method"],
  ["Afficher le mot de passe", "Hampiseho tenimiafina", "Show password"],
  ["Retour à l'accueil", "Hiverina amin'ny fandraisana", "Back to home"],
  ["Basculer le thème clair/sombre", "Hanova thème mazava/maizina", "Toggle light/dark theme"],
  ["Nouvelles notifications", "Fampandrenesana vaovao", "New notifications"],
  ["Catégories", "Sokajy", "Categories"],
  ["Rechercher un utilisateur…", "Hitady mpampiasa…", "Search for a user…"],
  ["Rechercher un utilisateur", "Hitady mpampiasa", "Search for a user"],
  ["Titre de la publication", "Lohatenin'ny publication", "Post title"],
  ["Mise en forme du texte", "Fanamboarana endriky ny soratra", "Text formatting"],
  ["Gras", "Matevina", "Bold"],
  ["Italique", "Mitanila", "Italic"],
  ["Souligné", "Misy tsipika ambany", "Underline"],
  ["Aligner à gauche", "Hampirindra ankavia", "Align left"],
  ["Centrer", "Hampovoany", "Center"],
  ["Aligner à droite", "Hampirindra ankavanana", "Align right"],
  ["Police", "Endri-tsoratra", "Font"],
  ["Taille du texte", "Haben'ny soratra", "Text size"],
  ["Texte de la publication", "Lahatsoratry ny publication", "Post text"],
  ["Écrivez ce que votre cœur ressent…", "Soraty izay tsapan'ny fonao…", "Write what your heart feels…"],
  ["Confidentialité de la publication", "Fahitan'ny publication", "Post privacy"],
  ["Mentionner un ami", "Hanonona namana", "Mention a friend"],
  ["Choisir un arrière-plan", "Hisafidy fond", "Choose a background"],
  ["Ajouter une vidéo", "Hanampy horonan-tsary", "Add video"],
  ["Arrière-plans LYRAME", "Fond LYRAME", "LYRAME backgrounds"],
  ["Fermer", "Hanakatona", "Close"],
  ["Retour", "Hiverina", "Back"],
  ["Retirer l'image", "Hanala sary", "Remove image"],
  ["Masquer mon profil", "Hanafina ny profil-ko", "Hide my profile"],
  ["Écrivez un commentaire…", "Soraty ny hevitrao…", "Write a comment…"],
  ["Votre commentaire", "Ny hevitrao", "Your comment"],
  ["Ajouter un emoji", "Hanampy emoji", "Add emoji"],
  ["Ajouter une image", "Hanampy sary", "Add image"],
  ["Ajouter un audio", "Hanampy feo", "Add audio"],
  ["Choisir un emoji", "Hisafidy emoji", "Choose an emoji"],
  ["Conversation", "Resaka", "Conversation"],
  ["Appel vocal", "Antso feo", "Voice call"],
  ["Appel vidéo", "Antso horonan-tsary", "Video call"],
  ["Annuler la réponse", "Hanafoana valiny", "Cancel reply"],
  ["Image", "Sary", "Image"],
  ["Vidéo (max 5 min)", "Horonan-tsary (5 minitra farafahabetsany)", "Video (max 5 min)"],
  ["Enregistrer un message vocal", "Handrakitra hafatra feo", "Record a voice message"],
  ["Votre message…", "Ny hafatrao…", "Your message…"],
  ["Votre message", "Ny hafatrao", "Your message"],
  ["Niveau sonore", "Haavon'ny feo", "Sound level"],
  ["Changer la couverture du groupe", "Hanova sary fonon'ny vondrona", "Change group cover"],
  ["Description du groupe", "Famaritana ny vondrona", "Group description"],
  ["Ajouter une couverture", "Hanampy sary fonony", "Add cover"],
  ["Rechercher des membres", "Hitady mpikambana", "Search members"],
  ["Mon profil", "Ny profil-ko", "My profile"],
  ["Menu du profil", "Menun'ny profil", "Profile menu"],
  ["Ajouter ou changer la couverture", "Hanampy na hanova sary fonony", "Add or change cover"],
  ["Voir les couvertures déjà enregistrées", "Hijery sary fonony efa voatahiry", "View saved covers"],
  ["Voir les photos de profil déjà enregistrées", "Hijery sarin'ny profil efa voatahiry", "View saved profile photos"],
  ["Changer la photo de profil", "Hanova sarin'ny profil", "Change profile photo"],
  ["Retirer la photo de profil", "Hanala sarin'ny profil", "Remove profile photo"],
  ["Écrivez votre réponse…", "Soraty ny valinteninao…", "Write your reply…"],
  ["Expliquez ce qui s'est passé…", "Hazavao izay nitranga…", "Explain what happened…"],
  ["Navigation principale", "Fitetezana lehibe", "Main navigation"],
  ["Ajouter une photo", "Hanampy sary", "Add a photo"],
  ["Répondre à un email", "Hamaly mailaka", "Reply to an email"],
  ["J'aime", "Tiako", "Like"],
  ["J'adore", "Tiako be", "Love"],
  ["Drôle", "Mampihomehy", "Funny"],
  ["Surpris", "Gaga", "Surprised"],
  ["Triste", "Malahelo", "Sad"],
  ["Soutien", "Fanohanana", "Support"],
  ["Ex : Poètes du soir", "Ohatra: Poeta amin’ny hariva", "Example: Evening poets"],
  ["vous@exemple.com", "ianao@ohatra.com", "you@example.com"]
];

let staticUiCaptured = false;
const staticUiTextNodes = [];
const staticUiAttrs = [];

function staticUiLookup(text, lang) {
  const value = String(text || "").trim();
  for (const row of STATIC_UI_TEXT) {
    if (row.includes(value)) {
      const index = lang === "mg" ? 1 : lang === "en" ? 2 : 0;
      return row[index];
    }
  }
  return null;
}

function captureStaticUi() {
  if (staticUiCaptured) return;
  staticUiCaptured = true;
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  let node;
  while ((node = walker.nextNode())) {
    const parent = node.parentElement;
    if (!parent || parent.closest("script,style")) continue;
    const raw = node.nodeValue || "";
    const trimmed = raw.trim();
    if (!trimmed || !STATIC_UI_TEXT.some(row => row.includes(trimmed))) continue;
    staticUiTextNodes.push({ node, original: trimmed, prefix: raw.match(/^\s*/)?.[0] || "", suffix: raw.match(/\s*$/)?.[0] || "" });
  }
  document.querySelectorAll("[placeholder],[aria-label],[title],[data-placeholder]").forEach(el => {
    ["placeholder", "aria-label", "title", "data-placeholder"].forEach(attr => {
      const val = el.getAttribute(attr);
      if (val && STATIC_UI_TEXT.some(row => row.includes(val.trim()))) {
        staticUiAttrs.push({ el, attr, original: val.trim() });
      }
    });
  });
}

function translateStaticUi() {
  captureStaticUi();
  staticUiTextNodes.forEach(item => {
    const translated = staticUiLookup(item.original, state.lang);
    if (translated != null && item.node.isConnected) item.node.nodeValue = item.prefix + translated + item.suffix;
  });
  staticUiAttrs.forEach(item => {
    const translated = staticUiLookup(item.original, state.lang);
    if (translated != null && item.el.isConnected) item.el.setAttribute(item.attr, translated);
  });
}

/* LYRAME V59 — informations de l'application affichées aussi dans l'APK TWA.
   La version web n'est pas le versionCode ni la versionName de l'APK Android. */
const LYRAME_ABOUT_V59 = Object.freeze({
  slogan: { fr: "Les mots qui viennent du cœur.", mg: "Teny avy ao am-po.", en: "Words from the heart." },
  title: { fr: "À propos de l'application", mg: "Mombamomba ny fampiharana", en: "About the app" },
  description: {
    fr: "LYRAME est un espace de partage, d'expression et d'échanges. Publiez vos pensées, partagez des stories, discutez avec vos proches et rejoignez des groupes.",
    mg: "LYRAME dia toerana hizarana hevitra sy hifandraisana. Mamoaha izay ao an-tsainao, zarao ny stories, mifampiresaha amin'ny akaiky anao ary midira amin'ny vondrona.",
    en: "LYRAME is a place to share, express yourself and connect. Publish your thoughts, share stories, chat with friends and join groups."
  },
  creatorLabel: { fr: "Créateur de LYRAME", mg: "Mpamorona ny LYRAME", en: "Creator of LYRAME" },
  createdBy: { fr: "Créé par Christion Alain", mg: "Noforonin’i Christion Alain", en: "Created by Christion Alain" },
  creatorDescription: {
    fr: "Conception et création de l’application LYRAME.",
    mg: "Famolavolana sy famoronana ny fampiharana LYRAME.",
    en: "Design and creation of the LYRAME application."
  },
  information: { fr: "Informations", mg: "Fampahalalana", en: "Information" },
  appName: { fr: "Application", mg: "Fampiharana", en: "Application" },
  languages: { fr: "Langues", mg: "Fiteny", en: "Languages" },
  languageNames: { fr: "Malagasy · Français · English", mg: "Malagasy · Français · English", en: "Malagasy · Français · English" },
  supportTitle: { fr: "Assistance", mg: "Fanampiana", en: "Support" },
  supportText: {
    fr: "Pour signaler un problème dans LYRAME, utilisez le formulaire d'assistance intégré.",
    mg: "Raha misy olana ao amin'ny LYRAME dia ampiasao ny taratasy fitaterana olana ao amin'ny app.",
    en: "To report an issue in LYRAME, use the built-in support form."
  },
  report: { fr: "Signaler un problème", mg: "Hitatitra olana", en: "Report a problem" }
});
function translateLyrameAboutV59() {
  const lang = LYRAME_ABOUT_V59.title[state.lang] ? state.lang : "fr";
  document.querySelectorAll("#screen-about [data-lyrame-about-i18n]").forEach(el => {
    const value = LYRAME_ABOUT_V59[el.dataset.lyrameAboutI18n]?.[lang];
    if (typeof value === "string") el.textContent = value;
  });
}

function applyTranslations() {
  if (!SUPPORTED_UI_LANGS.has(state.lang)) state.lang = "fr";
  document.documentElement.setAttribute("lang", state.lang);
  document.documentElement.setAttribute("dir", state.lang === "ar" ? "rtl" : "ltr");

  const navMap = {
    "home": "nav_home", "search": "nav_search", "create": "nav_create",
    "messages": "nav_messages", "profile-me": "nav_profile"
  };
  Object.entries(navMap).forEach(([nav, key]) => {
    const el = document.querySelector(`.nav-btn[data-nav="${nav}"] span`);
    if (el) el.textContent = t(key);
  });

  $("#header-settings-btn")?.setAttribute("aria-label", t("settings"));
  $("#header-notifications-btn")?.setAttribute("aria-label", t("notifications"));

  const label = $("#settings-language-current");
  if (label) {
    const cur = LANGS.find(l => l.code === state.lang);
    if (cur) label.textContent = cur.label;
  }

  translateStaticUi();
  translateLyrameAboutV59();

  $$(".lang-item").forEach(item => {
    const supported = SUPPORTED_UI_LANGS.has(item.dataset.lang);
    item.classList.toggle("hidden", !supported);
    item.hidden = !supported;
    if (!supported) return;
    const active = item.dataset.lang === state.lang;
    item.classList.toggle("active", active);
    const check = item.querySelector(".check");
    if (check) check.remove();
    if (active) {
      const span = document.createElement("span");
      span.className = "check";
      span.textContent = "✓";
      item.appendChild(span);
    }
  });
}

function setLang(code) {
  state.lang = SUPPORTED_UI_LANGS.has(code) ? code : "fr";
  if (state.currentUser) void saveAccountUiPreferences({ uiLang: state.lang });
  applyTranslations();
  toast(t("lang_updated"));
}

/* ------------------------------------------------------------
   14. NAVIGATION
   ------------------------------------------------------------ */
const TAB_NAMES = ["home", "settings", "create", "messages", "menu"];

/* V96.3 — Navigation Android : aucun bouton Retour/Home dans LYRAME.
   Bouton/geste Retour Android -> historique SPA (PWA/TWA/WebView compatible).
   Le bouton Home Android reste exclusivement géré par Android. */
const LYRAME_ANDROID_HISTORY_KEY = "__lyrame_v963_route";
const LYRAME_ANDROID_OVERLAY_KEY = "__lyrame_v963_overlay";
const LYRAME_ANDROID_LEGACY_HISTORY_KEY = "__lyrame_v962_screen";
const LYRAME_ANDROID_TRACKED_OVERLAYS = new Set([
  "confirm-modal", "media-viewer", "story-viewer", "assistant-history-sheet",
  "header-inline-search", "create-background-picker",
  "reaction-picker", "comment-emoji-picker", "conv-emoji-picker", "media-viewer-menu"
]);
let lyrameAndroidApplyingHistory = false;
let lyrameAndroidCurrentOverlay = null;

function lyrameAndroidValidRoute(route) {
  if (typeof route !== "string") return "";
  if (["auth:login", "auth:register", "auth:forgot"].includes(route)) return route;
  if (!/^[a-z0-9-]{1,48}$/.test(route)) return "";
  return $("#app-shell .screen[data-screen=\"" + route + "\"]") ? route : "";
}

function lyrameAndroidRouteOf(value) {
  return lyrameAndroidValidRoute(value?.[LYRAME_ANDROID_HISTORY_KEY] ||
    value?.[LYRAME_ANDROID_LEGACY_HISTORY_KEY]);
}

function lyrameAndroidRememberScreen(screen, push) {
  if (lyrameAndroidApplyingHistory) return;
  if (!state.currentUser && !screen.startsWith("auth:")) return;
  try {
    const oldState = history.state && typeof history.state === "object" ? history.state : {};
    const lastRoute = lyrameAndroidRouteOf(oldState);
    const next = { ...oldState, [LYRAME_ANDROID_HISTORY_KEY]: screen };
    delete next[LYRAME_ANDROID_LEGACY_HISTORY_KEY];
    delete next[LYRAME_ANDROID_OVERLAY_KEY];
    // Tsy mamorona entrée roa ho an'ny écran iray; initialisation = replace.
    if (push && lastRoute && lastRoute !== screen) history.pushState(next, "", location.href);
    else history.replaceState(next, "", location.href);
    lyrameAndroidCurrentOverlay = null;
  } catch (error) {
    console.warn("[LYRAME Android route]", error);
  }
}

function lyrameAndroidPushOverlayId(id) {
  if (!state.currentUser || lyrameAndroidApplyingHistory ||
      (!LYRAME_ANDROID_TRACKED_OVERLAYS.has(id) && id !== "dynamic-modal")) return;
  const route = currentScreenName();
  if (!route) return;
  try {
    const previous = history.state && typeof history.state === "object" ? history.state : {};
    if (previous[LYRAME_ANDROID_OVERLAY_KEY] === id) return;
    const next = { ...previous, [LYRAME_ANDROID_HISTORY_KEY]: route,
      [LYRAME_ANDROID_OVERLAY_KEY]: id };
    delete next[LYRAME_ANDROID_LEGACY_HISTORY_KEY];
    history.pushState(next, "", location.href);
    lyrameAndroidCurrentOverlay = id;
  } catch (error) {
    console.warn("[LYRAME Android overlay]", error);
  }
}

function lyrameAndroidPushOverlay(el) {
  if (el?.id && LYRAME_ANDROID_TRACKED_OVERLAYS.has(el.id))
    lyrameAndroidPushOverlayId(el.id);
}

function lyrameAndroidOverlayVisible(id) {
  if (id === "dynamic-modal") return dynamicModals.length > 0;
  const el = document.getElementById(id);
  return isShown(el);
}

function lyrameAndroidOverlayClosed(id) {
  // Fermeture par un bouton X : supprimer l'entrée modale par History.back().
  // Différer : une navigation vers un autre écran dans le même clic l'emporte.
  if (history.state?.[LYRAME_ANDROID_OVERLAY_KEY] !== id) return;
  setTimeout(() => {
    if (history.state?.[LYRAME_ANDROID_OVERLAY_KEY] === id &&
        !lyrameAndroidOverlayVisible(id)) history.back();
  }, 0);
}

function lyrameAndroidCloseOverlay(id) {
  if (id === "dynamic-modal") {
    dynamicModals[dynamicModals.length - 1]?.close();
  } else if (id === "confirm-modal" && confirmResolver) {
    resolveConfirm(false);
  } else if (id === "story-viewer") {
    clearTimeout(state.storyTimer);
    lyrameStopStoryPlayback();
    hideEl($("#story-viewer"));
  } else if (id === "media-viewer") {
    $("#media-viewer")?.querySelectorAll("video,audio").forEach(el => { try { el.pause(); } catch (_) {} });
    hideEl($("#media-viewer"));
    hideEl($("#media-viewer-menu"));
    state.mediaViewerGallery = false;
  } else if (id === "assistant-history-sheet") {
    assistantCloseHistory();
  } else if (id === "header-inline-search") {
    closeHeaderInlineSearch();
  } else {
    hideEl(document.getElementById(id));
  }
}

function lyrameAndroidOnPopState(event) {
  const requestedOverlay = typeof event.state?.[LYRAME_ANDROID_OVERLAY_KEY] === "string"
    ? event.state[LYRAME_ANDROID_OVERLAY_KEY] : null;
  const departedOverlay = lyrameAndroidCurrentOverlay;
  lyrameAndroidCurrentOverlay = requestedOverlay;
  const route = lyrameAndroidRouteOf(event.state);

  if (!state.currentUser || $("#app-shell")?.classList.contains("hidden")) {
    // Écrans de connexion/inscription : toujours la navigation native Android.
    if (route.startsWith("auth:")) {
      lyrameAndroidApplyingHistory = true;
      try { showAuthPanel(route.slice(5), { push: false }); }
      finally { lyrameAndroidApplyingHistory = false; }
    } else if (route) {
      // Après déconnexion : ne pas rendre visible une page privée de l'historique.
      history.back();
    }
    return;
  }

  if (route.startsWith("auth:")) {
    // Ne jamais revenir à Inscription / Connexion si la session est encore active.
    history.back();
    return;
  }
  if (departedOverlay && departedOverlay !== requestedOverlay)
    lyrameAndroidCloseOverlay(departedOverlay);

  if (requestedOverlay && !lyrameAndroidOverlayVisible(requestedOverlay)) {
    // Entrée modale obsolète (fermeture en naviguant) : la sauter.
    history.back();
    return;
  }
  // Ne jamais réinsérer un écran inventé si Android quitte l'activité.
  if (!route) return;
  const current = currentScreenName();
  if (route === current) return;
  const index = state.screenStack.lastIndexOf(route);
  if (index >= 0) state.screenStack.length = index + 1;
  else state.screenStack = route === "home" ? ["home"] : [...state.screenStack, route];
  lyrameAndroidApplyingHistory = true;
  try { showScreen(route, { push: false }); }
  finally { lyrameAndroidApplyingHistory = false; }
}

function currentScreenName() {
  return $("#app-shell .screen.active")?.dataset.screen || "";
}

function showScreen(name, { push = true } = {}) {
  if (!name) return;
  if (window.__lyrV92Ready && !lyrV92MayEnter(name)) { toast("Fonction masquée pour ce compte."); return; }
  const shell = $("#app-shell");
  const target = shell ? shell.querySelector(`.screen[data-screen="${name}"]`) : null;
  if (!target) return;

  const prev = currentScreenName();
  if (prev === "edit-profile" && name !== "edit-profile") resetProfileEditTemp();
  if (prev === "group-edit" && name !== "group-edit") resetGroupEditTemp();
  if (prev !== name) closeAllPopups();

  $$("#app-shell .screen").forEach(s => s.classList.remove("active"));
  target.classList.add("active");

  /* Navigation LYRAME : la barre des onglets reste sur Accueil ;
     Retour/Home sont les commandes SYSTÈME d'Android, jamais des boutons flottants. */
  const isHomeScreen = name === "home";
  shell?.classList.toggle("is-home-screen", isHomeScreen);
  shell?.classList.toggle("is-messaging-view", ["messages", "conversation", "assistant"].includes(name));
  const bottomNav = shell?.querySelector(".bottom-nav");
  if (bottomNav) {
    bottomNav.hidden = !isHomeScreen;
    bottomNav.setAttribute("aria-hidden", isHomeScreen ? "false" : "true");
  }

  if (TAB_NAMES.includes(name)) {
    $$(".nav-btn").forEach(b => b.classList.toggle("active", b.dataset.nav === name));
  }

  if (name === "profile-me") {
    state.profileViewUid = null;

    if (prev !== "profile-me") {
      state.profileMeTab = "posts";

      const scope = $("#screen-profile-me");

      scope?.querySelectorAll(".tab").forEach(tab => {
        const active = tab.dataset.tab === "posts";
        tab.classList.toggle("active", active);
        tab.setAttribute(
          "aria-selected",
          active ? "true" : "false"
        );
      });
    }
  }

  if (push && state.screenStack[state.screenStack.length - 1] !== name) {
    state.screenStack.push(name);
  }
  // Chaque écran possède une entrée History. Le système Android déclenche
  // popstate lors du geste/bouton Retour (navigateur, WebView ou TWA compatible).
  if (prev !== name) lyrameAndroidRememberScreen(name, push);
  else if (!push && !lyrameAndroidApplyingHistory) lyrameAndroidRememberScreen(name, false);

  if (name === "admin" && window.__lyrV92Ready) setTimeout(lyrV92RenderAdmin, 0);
  switch (name) {
    case "friends":         renderFriendsList(); lyrV966RenderPendingRequests(); break;
    case "friend-requests": renderRequestsList(); break;
    case "group-edit":      loadGroupEdit(); break;
    case "edit-profile":    fillEditProfileForm(); break;
    case "create-group":    resetCreateGroupState(); loadGroupCandidates(); break;
    case "create":          updatePublishState(); break;
    default: break;
  }

  try { window.scrollTo({ top: 0, behavior: "auto" }); }
  catch (e) { window.scrollTo(0, 0); }
}

function goBack() {
  // Retour interne nécessaire après une action métier, sans bouton visible.
  if (state.screenStack.length > 1 &&
      lyrameAndroidRouteOf(history.state) === currentScreenName()) {
    history.back();
    return;
  }
  if (state.screenStack.length > 1) state.screenStack.pop();
  showScreen(state.screenStack[state.screenStack.length - 1] || "home", { push: false });
}

/* LYRAME V60 — conserver le formulaire choisi durant l'initialisation
   Firebase et après un retour d'application Android/TWA. */
function showAuthPanel(name, { push = true } = {}) {
  if (!["login", "register", "forgot"].includes(name)) return;
  const target = document.querySelector(`.auth-panel[data-screen="${name}"]`);
  if (!target) return;
  $$(".auth-panel").forEach(panel => {
    const active = panel === target;
    panel.classList.toggle("active", active);
    panel.setAttribute("aria-hidden", active ? "false" : "true");
  });
  const screen = $("#auth-screen");
  if (screen) screen.dataset.activeAuthPanel = name;
  // Les champs déjà saisis ne sont jamais réinitialisés lors du changement.
  // Remettre le scroll au début sans toucher au focus utilisateur.
  if (screen) screen.scrollTop = 0;
  if (!state.currentUser && !lyrameAndroidApplyingHistory)
    lyrameAndroidRememberScreen("auth:" + name, push);
}

/* ------------------------------------------------------------
   15. POPUPS (menu profil, réactions, emojis, menus propriétaire)
   ------------------------------------------------------------ */
function closeProfileMenu() {
  // Profil : aucune liste cachée ; les actions sont dans leurs pages dédiées.
}

function closeReactionPicker() {
  hideEl($("#reaction-picker"));
  state.activeReactionPostId = null;
}

function closeEmojiPickers() {
  hideEl($("#comment-emoji-picker"));
  hideEl($("#conv-emoji-picker"));
  hideCommentStickerPickers();
}

function hideCommentStickerPickers() {
  document.querySelectorAll(".comment-sticker-picker").forEach(p => hideEl(p));
}

function closeOwnerMenus() {
  $$(".owner-menu").forEach(m => hideEl(m));
}

function closeAllPopups() {
  closeProfileMenu();
  closeReactionPicker();
  closeEmojiPickers();
  closeOwnerMenus();
}

function anyPopupOpen() {
  return isShown($("#reaction-picker")) ||
    isShown($("#comment-emoji-picker")) || isShown($("#conv-emoji-picker")) ||
    Array.from(document.querySelectorAll(".comment-sticker-picker")).some(isShown) ||
    $$(".owner-menu").some(isShown);
}

function positionFixedNear(popup, anchor) {
  if (!popup || !anchor) return;
  const r = anchor.getBoundingClientRect();
  popup.style.position = "fixed";
  popup.style.zIndex = "9000";
  popup.style.maxWidth = "min(92vw, 320px)";
  const width = popup.offsetWidth || 280;
  const left = Math.max(8, Math.min(r.left, window.innerWidth - width - 8));
  popup.style.left = left + "px";
  popup.style.right = "auto";
  const height = popup.offsetHeight || 60;
  const above = r.top - height - 8;
  popup.style.top = (above > 8 ? above : r.bottom + 8) + "px";
  popup.style.bottom = "auto";
}

/* --- Réactions --- */
function ensureReactionPicker() {
  let p = $("#reaction-picker");
  if (!p) {
    const c = modalColors();
    p = document.createElement("div");
    p.id = "reaction-picker";
    p.className = "reaction-picker hidden";
    Object.assign(p.style, {
      background: c.bg, border: "1px solid " + c.border, borderRadius: "999px",
      padding: "6px 10px", display: "flex", gap: "6px", boxShadow: "0 6px 24px rgba(0,0,0,.25)"
    });
    document.body.appendChild(p);
  }
  if (!p.querySelector("[data-reaction]")) {
    p.innerHTML = "";
    REACTIONS.forEach(r => {
      const b = document.createElement("button");
      b.type = "button";
      b.className = "reaction-option";
      b.dataset.reaction = r.type;
      const label = reactionLabel(r.type);
      b.setAttribute("aria-label", label);
      b.title = label;
      b.textContent = r.emoji;
      Object.assign(b.style, { background: "transparent", border: "0", fontSize: "24px", cursor: "pointer", padding: "2px 4px" });
      p.appendChild(b);
    });
  }
  return p;
}

function openReactionPicker(postId, anchor) {
  const p = ensureReactionPicker();
  closeEmojiPickers();
  state.activeReactionPostId = postId;
  showEl(p);
  p.style.display = "flex";
  positionFixedNear(p, anchor);
}

/* --- Emojis --- */
function ensureEmojiPicker(pickerId, getTarget, onSelect = null) {
  let p = document.getElementById(pickerId);
  let dynamic = false;
  if (!p) {
    dynamic = true;
    const c = modalColors();
    p = document.createElement("div");
    p.id = pickerId;
    p.className = "emoji-picker hidden";
    Object.assign(p.style, {
      background: c.bg, border: "1px solid " + c.border, borderRadius: "14px", padding: "8px",
      display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: "2px", boxShadow: "0 6px 24px rgba(0,0,0,.25)"
    });
    document.body.appendChild(p);
  }
  if (!p.dataset.ready) {
    p.innerHTML = "";
    EMOJIS.forEach(em => {
      const b = document.createElement("button");
      b.type = "button";
      b.className = "emoji-option";
      b.textContent = em;
      b.setAttribute("aria-label", em);
      if (dynamic) Object.assign(b.style, { background: "transparent", border: "0", fontSize: "22px", cursor: "pointer", padding: "4px" });
      b.addEventListener("click", ev => {
        ev.stopPropagation();
        if (typeof onSelect === "function") onSelect(em);
        else insertAtCursor(getTarget(), em);
      });
      p.appendChild(b);
    });
    p.dataset.ready = "1";
  }
  return { picker: p, dynamic };
}

function toggleEmojiPicker(pickerId, anchor, getTarget, onSelect = null) {
  const { picker, dynamic } = ensureEmojiPicker(pickerId, getTarget, onSelect);
  if (isShown(picker)) { hideEl(picker); return; }
  closeReactionPicker();
  closeEmojiPickers();
  showEl(picker);
  if (dynamic) {
    picker.style.display = "grid";
    positionFixedNear(picker, anchor);
  }
}

/* ------------------------------------------------------------
   16. MOT DE PASSE — OEIL (afficher / masquer)
   ------------------------------------------------------------ */
const EYE_OPEN = `<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z"/><circle cx="12" cy="12" r="3"/></svg>`;
const EYE_OFF  = `<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M17.94 17.94A10.94 10.94 0 0 1 12 19c-7 0-11-7-11-7a19.8 19.8 0 0 1 5.06-5.94"/><path d="M9.9 4.24A10.9 10.9 0 0 1 12 5c7 0 11 7 11 7a19.9 19.9 0 0 1-3.17 4.19"/><path d="M1 1l22 22"/></svg>`;

function bindPasswordToggle(buttonEl, inputEl) {
  if (!buttonEl || !inputEl || buttonEl.dataset.pwBound === "1") return;
  buttonEl.dataset.pwBound = "1";
  buttonEl.setAttribute("aria-label", t("pw_show"));
  buttonEl.setAttribute("aria-pressed", "false");

  /* Ne pas perdre le focus de l'input */
  buttonEl.addEventListener("mousedown", e => e.preventDefault());
  buttonEl.addEventListener("click", e => {
    e.preventDefault();
    const visible = inputEl.type === "password";
    const start = inputEl.selectionStart, end = inputEl.selectionEnd;
    inputEl.type = visible ? "text" : "password";
    buttonEl.setAttribute("aria-label", visible ? t("pw_hide") : t("pw_show"));
    buttonEl.setAttribute("aria-pressed", visible ? "true" : "false");
    buttonEl.classList.toggle("is-visible", visible);
    buttonEl.classList.toggle("active", visible);

    const svgs = buttonEl.querySelectorAll("svg");
    if (svgs.length >= 2) {
      svgs[0].style.display = visible ? "none" : "";
      svgs[1].style.display = visible ? "" : "none";
    } else {
      buttonEl.innerHTML = visible ? EYE_OFF : EYE_OPEN;
    }
    if (document.activeElement === inputEl && typeof start === "number") {
      try { inputEl.setSelectionRange(start, end); } catch (err) { /* noop */ }
    }
  });
}

/* ------------------------------------------------------------
   17. FORMATTAGE DE TEXTE (état structuré, jamais de HTML brut)
   ------------------------------------------------------------ */
function defaultFormatting() {
  return {
    bold: false, italic: false, underline: false,
    align: "left", fontFamily: "default", fontSize: "normal", color: ""
  };
}

function sanitizeFormatting(f) {
  const d = defaultFormatting();
  if (!f || typeof f !== "object") return d;
  const out = { ...d };
  out.bold = f.bold === true;
  out.italic = f.italic === true;
  out.underline = f.underline === true;
  out.align = ["left", "center", "right"].includes(f.align) ? f.align : "left";

  const ff = String(f.fontFamily || "default");
  if (Object.prototype.hasOwnProperty.call(FONT_FAMILIES, ff)) out.fontFamily = ff;
  else if (/^[A-Za-z0-9 _-]{1,40}$/.test(ff)) out.fontFamily = ff;

  const fs = String(f.fontSize || "normal");
  if (Object.prototype.hasOwnProperty.call(FONT_SIZES, fs)) out.fontSize = fs;
  else {
    const n = parseInt(fs, 10);
    if (Number.isFinite(n) && n >= 10 && n <= 40) out.fontSize = String(n);
  }

  const col = String(f.color || "");
  if (/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(col)) out.color = col;
  return out;
}

const RICH_ALLOWED_TAGS = new Set([
  "DIV",
  "P",
  "BR",
  "SPAN",
  "FONT",
  "STRONG",
  "B",
  "EM",
  "I",
  "U"
]);

const RICH_ALLOWED_STYLES = new Set([
  "color",
  "font-family",
  "font-size",
  "font-weight",
  "font-style",
  "text-decoration",
  "text-align"
]);

function sanitizeRichHtml(rawHtml) {
  const parser = new DOMParser();

  const docx = parser.parseFromString(
    `<div>${String(rawHtml || "")}</div>`,
    "text/html"
  );

  const root = docx.body.firstElementChild;

  const cleanNode = node => {
    if (node.nodeType === Node.TEXT_NODE) {
      return document.createTextNode(node.textContent || "");
    }

    if (node.nodeType !== Node.ELEMENT_NODE) {
      return document.createDocumentFragment();
    }

    const tag = node.tagName.toUpperCase();

    if (!RICH_ALLOWED_TAGS.has(tag)) {
      const frag = document.createDocumentFragment();

      Array.from(node.childNodes).forEach(child => {
        frag.appendChild(cleanNode(child));
      });

      return frag;
    }

    // execCommand("foreColor") on several mobile/WebView browsers still emits
    // legacy <font color="..."> nodes. Normalize FONT to SPAN so the selected
    // per-range text colour survives sanitization and remains safe to render.
    const out = document.createElement(tag === "FONT" ? "span" : tag.toLowerCase());

    const style = node.getAttribute("style") || "";
    const safeStyles = [];

    if (tag === "FONT") {
      const legacyColor = String(node.getAttribute("color") || "").trim();
      if (
        /^#[0-9a-f]{3,6}$/i.test(legacyColor) ||
        /^rgb(a)?\([\d\s,.%]+\)$/i.test(legacyColor)
      ) {
        safeStyles.push(`color:${legacyColor}`);
      }
    }

    style.split(";").forEach(rule => {
      const idx = rule.indexOf(":");

      if (idx <= 0) return;

      const prop = rule.slice(0, idx).trim().toLowerCase();
      const value = rule.slice(idx + 1).trim();

      if (!RICH_ALLOWED_STYLES.has(prop)) {
        return;
      }

      if (prop === "color") {
        if (
          /^#[0-9a-f]{3,6}$/i.test(value) ||
          /^rgb(a)?\([\d\s,.%]+\)$/i.test(value)
        ) {
          safeStyles.push(`${prop}:${value}`);
        }

        return;
      }

      if (prop === "font-size") {
        const n = parseInt(value, 10);

        if (
          Number.isFinite(n) &&
          n >= 10 &&
          n <= 40
        ) {
          safeStyles.push(`font-size:${n}px`);
        }

        return;
      }

      if (prop === "font-family") {
        const clean = value.replace(
          /[^A-Za-z0-9 ,'"_-]/g,
          ""
        );

        if (clean.length <= 80) {
          safeStyles.push(`font-family:${clean}`);
        }

        return;
      }

      if (prop === "font-weight") {
        if (/^(normal|bold|[1-9]00)$/i.test(value)) {
          safeStyles.push(`font-weight:${value}`);
        }

        return;
      }

      if (prop === "font-style") {
        if (/^(normal|italic)$/i.test(value)) {
          safeStyles.push(`font-style:${value}`);
        }

        return;
      }

      if (prop === "text-decoration") {
        if (/^(none|underline)$/i.test(value)) {
          safeStyles.push(`text-decoration:${value}`);
        }

        return;
      }

      if (prop === "text-align") {
        if (/^(left|center|right)$/i.test(value)) {
          safeStyles.push(`text-align:${value}`);
        }
      }
    });

    if (safeStyles.length) {
      out.setAttribute(
        "style",
        safeStyles.join(";")
      );
    }

    Array.from(node.childNodes).forEach(child => {
      out.appendChild(cleanNode(child));
    });

    return out;
  };

  const output = document.createElement("div");

  Array.from(root.childNodes).forEach(child => {
    output.appendChild(cleanNode(child));
  });

  return output.innerHTML;
}

function richEditorPlainText() {
  const editor = $("#create-rich-editor");

  if (!editor) {
    return "";
  }

  return (editor.innerText || "").trim();
}

function syncRichEditorToLegacyTextarea() {
  const editor = $("#create-rich-editor");
  const legacy = $("#create-text");

  if (!editor || !legacy) {
    return;
  }

  legacy.value = (editor.innerText || "").slice(0, TEXT_MAX);
}

function applyCommandToRichSelection(command, value = null) {
  const editor = $("#create-rich-editor");

  if (!editor) {
    return;
  }

  editor.focus();

  try {
    document.execCommand(
      command,
      false,
      value
    );
  } catch (err) {
    console.warn(
      "[rich editor command]",
      command,
      err
    );
  }

  syncRichEditorToLegacyTextarea();
  updatePublishState();
}

function applyFormattingToElement(el, formatting) {
  if (!el) return;
  const f = sanitizeFormatting(formatting);
  el.style.fontWeight = f.bold ? "700" : "";
  el.style.fontStyle = f.italic ? "italic" : "";
  el.style.textDecoration = f.underline ? "underline" : "";
  el.style.textAlign = f.align;
  if (FONT_FAMILIES[f.fontFamily] !== undefined) el.style.fontFamily = FONT_FAMILIES[f.fontFamily];
  else el.style.fontFamily = `"${f.fontFamily}", sans-serif`;
  if (FONT_SIZES[f.fontSize] !== undefined) el.style.fontSize = FONT_SIZES[f.fontSize];
  else el.style.fontSize = f.fontSize + "px";
  el.style.color = f.color || "";
}

function refreshFormatToolbar() {
  const f = state.postFormat;
  const map = {
    "create-bold-btn": f.bold, "create-italic-btn": f.italic, "create-underline-btn": f.underline,
    "create-align-left-btn": f.align === "left",
    "create-align-center-btn": f.align === "center",
    "create-align-right-btn": f.align === "right"
  };
  Object.entries(map).forEach(([id, on]) => {
    const b = document.getElementById(id);
    if (!b) return;
    b.classList.toggle("active", !!on);
    b.setAttribute("aria-pressed", on ? "true" : "false");
  });
  applyFormattingToElement($("#create-text"), f);
}

function resetPostFormat() {
  state.postFormat = defaultFormatting();
  const ff = $("#create-font-family"); if (ff) ff.value = "default";
  const fs = $("#create-font-size");   if (fs) fs.value = "normal";
  refreshFormatToolbar();
}

function bindFormatToolbar() {
  const editor = $("#create-rich-editor");
  const legacy = $("#create-text");

  if (editor && legacy) {
    showEl(editor);
    legacy.classList.add("hidden");
    state.richEditorEnabled = true;

    editor.addEventListener("input", () => {
      syncRichEditorToLegacyTextarea();
      updatePublishState();
    });
  }

  [
    ["create-bold-btn", "bold"],
    ["create-italic-btn", "italic"],
    ["create-underline-btn", "underline"]
  ].forEach(([id, command]) => {
    $(`#${id}`)?.addEventListener("click", e => {
      e.preventDefault();
      applyCommandToRichSelection(command);
    });
  });

  [
    ["create-align-left-btn", "justifyLeft"],
    ["create-align-center-btn", "justifyCenter"],
    ["create-align-right-btn", "justifyRight"]
  ].forEach(([id, command]) => {
    $(`#${id}`)?.addEventListener("click", e => {
      e.preventDefault();
      applyCommandToRichSelection(command);
    });
  });

  $("#create-font-family")?.addEventListener("change", e => {
    const value = e.target.value;

    const family =
      FONT_FAMILIES[value] ||
      (
        value &&
        /^[A-Za-z0-9 _-]{1,40}$/.test(value)
          ? value
          : ""
      );

    if (family) {
      applyCommandToRichSelection(
        "fontName",
        family
      );
    }
  });

  $("#create-font-size")?.addEventListener("change", e => {
    const value = e.target.value;

    const map = {
      small: "2",
      normal: "3",
      large: "5",
      xlarge: "6"
    };

    applyCommandToRichSelection(
      "fontSize",
      map[value] || "3"
    );
  });

  $("#create-text-color")?.addEventListener("input", e => {
    const color = e.target.value;

    if (/^#[0-9a-f]{6}$/i.test(color)) {
      applyCommandToRichSelection(
        "foreColor",
        color
      );
    }
  });
}

const LYRAME_BACKGROUND_CATALOG = [
  { id: "grenat", kind: "css", label: "Grenat", value: "linear-gradient(145deg,#2a0712,#7A1831 55%,#120308)" },
  { id: "nuit", kind: "css", label: "Nuit", value: "linear-gradient(145deg,#050506,#211018 55%,#7A1831)" },
  { id: "rose", kind: "css", label: "Rose", value: "linear-gradient(145deg,#7A1831,#B6516E,#261019)" },
  { id: "aurore", kind: "css", label: "Aurore", value: "linear-gradient(135deg,#24101b,#7A1831,#d17a95)" },
  { id: "nature", kind: "remote", label: "Nature", url: "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80" },
  { id: "ciel", kind: "remote", label: "Ciel", url: "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=1200&q=80" },
  { id: "ocean", kind: "remote", label: "Océan", url: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1200&q=80" }
];

function renderBackgroundPicker() {
  const grid = $("#create-background-grid");
  if (!grid) return;
  grid.innerHTML = "";
  LYRAME_BACKGROUND_CATALOG.forEach(bg => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "background-option";
    btn.setAttribute("aria-label", bg.label || "LYRAME");
    const preview = document.createElement("span");
    preview.className = "background-option-preview";
    if (bg.kind === "css") preview.style.background = bg.value;
    else {
      const url = safeUrl(bg.url);
      if (!url) return;
      preview.style.backgroundImage = `url("${url}")`;
      preview.style.backgroundSize = "cover";
      preview.style.backgroundPosition = "center";
    }
    const label = document.createElement("small");
    label.textContent = bg.label || "LYRAME";
    btn.append(preview, label);
    btn.addEventListener("click", () => {
      clearSelectedPostMedia();
      state.selectedPostBackground = bg.kind === "css"
        ? { kind: "css", value: bg.value, catalogId: bg.id }
        : { kind: "remote", url: bg.url, catalogId: bg.id };
      renderPostMediaPreview();
      updatePublishState();
      hideEl($("#create-background-picker"));
    });
    grid.appendChild(btn);
  });
}

async function openMentionFriends() {
  if (!state.currentUser) return;
  const ids = Array.from(state.friendIds || []);
  if (!ids.length) {
    toast(state.lang === "mg" ? "Tsy mbola misy namana azo tononina." : state.lang === "en" ? "No friends available to mention." : "Aucun ami à mentionner.");
    return;
  }
  const modal = openDynamicModal(state.lang === "mg" ? "Hanonona namana" : state.lang === "en" ? "Mention a friend" : "Mentionner un ami");
  const list = document.createElement("div");
  list.className = "mention-friend-list";
  const profiles = (await Promise.all(ids.slice(0,100).map(id => getUserProfile(id).catch(() => null)))).filter(Boolean);
  profiles.sort((a,b) => String(a.fullname||a.username||"").localeCompare(String(b.fullname||b.username||"")));
  profiles.forEach(profile => {
    if (!profile.username) return;
    const row = document.createElement("button");
    row.type = "button";
    row.className = "mention-friend-row";
    row.innerHTML = `<span class="avatar">${avatarMarkup(profile.photoURL, profile.fullname)}</span><span><strong>${escapeHtml(profile.fullname || "")}</strong><small>@${escapeHtml(profile.username)}</small></span>`;
    row.addEventListener("click", () => {
      const mention = `@${profile.username} `;
      const editor = $("#create-rich-editor");
      if (state.richEditorEnabled && editor) {
        editor.focus();
        try { document.execCommand("insertText", false, mention); }
        catch (_) { editor.append(document.createTextNode(mention)); }
        syncRichEditorToLegacyTextarea();
      } else {
        const ta = $("#create-text");
        if (ta) {
          const start = ta.selectionStart ?? ta.value.length;
          const end = ta.selectionEnd ?? start;
          ta.value = ta.value.slice(0,start) + mention + ta.value.slice(end);
          ta.selectionStart = ta.selectionEnd = start + mention.length;
          ta.focus();
        }
      }
      updatePublishState();
      modal.close();
    });
    list.appendChild(row);
  });
  modal.body.appendChild(list);
}


/* ------------------------------------------------------------
   18. APERÇU MÉDIA D'UNE PUBLICATION
   ------------------------------------------------------------ */
function clearComposerBackgroundCanvas() {
  const editor = $("#create-rich-editor");
  if (!editor) return;
  editor.classList.remove("background-compose-mode");
  editor.style.background = "";
  editor.style.backgroundImage = "";
  editor.style.backgroundSize = "";
  editor.style.backgroundPosition = "";
  editor.style.backgroundRepeat = "";
  editor.removeAttribute("data-ratio");
}

function applyComposerBackgroundCanvas(bg) {
  const editor = $("#create-rich-editor");
  if (!editor || !bg) return;
  clearComposerBackgroundCanvas();
  editor.classList.add("background-compose-mode");
  editor.dataset.ratio = state.selectedBackgroundRatio || "original";
  if (bg.kind === "css") {
    editor.style.background = bg.value || "";
  } else {
    const bgUrl = bg.kind === "upload"
      ? safeUrl(bg.localUrl, { allowBlob: true })
      : safeUrl(bg.url);
    if (bgUrl) editor.style.backgroundImage = `url("${String(bgUrl).replace(/"/g, "%22")}")`;
  }
  editor.style.backgroundSize = "cover";
  editor.style.backgroundPosition = "center";
  editor.style.backgroundRepeat = "no-repeat";
}

function renderPostMediaPreview() {
  const box = $("#create-preview");
  const media = state.selectedPostMedia;
  const bg = state.selectedPostBackground;
  if (!box) return;
  box.innerHTML = "";
  box.classList.remove("has-background");
  box.style.backgroundImage = "";
  box.style.background = "";
  box.removeAttribute("data-ratio");
  clearComposerBackgroundCanvas();
  hideEl($("#create-image-ratio-wrap"));
  hideEl($("#create-video-ratio-wrap"));
  hideEl($("#create-background-ratio-wrap"));

  if (media) {
    const url = safeUrl(media.url, { allowBlob: true });
    if (!url) { hideEl(box); return; }
    const node = document.createElement(media.kind === "image" ? "img" : "video");
    node.src = url;
    if (media.kind === "image") {
      node.alt = ""; showEl($("#create-image-ratio-wrap"));
      box.dataset.ratio = state.selectedImageRatio || "original";
    } else {
      node.controls = true; node.playsInline = true; showEl($("#create-video-ratio-wrap"));
      box.dataset.ratio = state.selectedVideoRatio || "original";
    }
    box.appendChild(node); showEl(box); return;
  }

  if (bg) {
    /* Fond LYRAME = canevas de saisie, pas un aperçu séparé. */
    applyComposerBackgroundCanvas(bg);
    showEl($("#create-background-ratio-wrap"));
    hideEl(box);
    const editor = $("#create-rich-editor");
    if (editor) {
      editor.focus({ preventScroll: true });
    }
    return;
  }

  hideEl(box);
}

function bindImageRatioButtons() {
  const allowed = ["original","1:1","4:5","3:4","16:9","9:16"];
  $$("[data-ratio], [data-video-ratio], [data-bg-ratio]").forEach(btn => {
    btn.addEventListener("click", () => {
      const ratio = btn.dataset.ratio || btn.dataset.videoRatio || btn.dataset.bgRatio || "original";
      if (!allowed.includes(ratio)) return;
      let selector = "";
      if (btn.dataset.videoRatio !== undefined) { state.selectedVideoRatio = ratio; selector = "[data-video-ratio]"; }
      else if (btn.dataset.bgRatio !== undefined) { state.selectedBackgroundRatio = ratio; selector = "[data-bg-ratio]"; }
      else { state.selectedImageRatio = ratio; selector = "[data-ratio]"; }
      $$(selector).forEach(other => { const active = other === btn; other.classList.toggle("active", active); other.setAttribute("aria-pressed", active ? "true" : "false"); });
      renderPostMediaPreview();
    });
  });
}

function clearSelectedPostMedia() {
  if (state.selectedPostMedia) revokeUrl(state.selectedPostMedia.url);
  if (state.selectedPostBackground?.localUrl) revokeUrl(state.selectedPostBackground.localUrl);
  state.selectedPostMedia = null;
  state.selectedPostBackground = null;
  const p = $("#create-photo-input"); if (p) p.value = "";
  const v = $("#create-video-input"); if (v) v.value = "";
  clearComposerBackgroundCanvas();
  renderPostMediaPreview();
  updatePublishState();
}

async function onPostMediaChosen(file, kind, input) {
  if (!file) return;
  const check = await validateMedia(file, kind);
  if (!check.ok) {
    toast(check.msg);
    if (input) input.value = "";
    return;
  }
  if (state.selectedPostMedia) revokeUrl(state.selectedPostMedia.url);
  state.selectedPostBackground = null;
  state.selectedPostMedia = { file, kind, url: URL.createObjectURL(file) };
  /* un seul média à la fois */
  if (kind === "image") { const v = $("#create-video-input"); if (v) v.value = ""; }
  else { const p = $("#create-photo-input"); if (p) p.value = ""; }
  renderPostMediaPreview();
  updatePublishState();
}

function setUploadProgress(pct) {
  const wrap = $("#create-upload-progress");
  const bar  = $("#create-upload-progress-bar");
  const txt  = $("#create-upload-progress-text");
  if (pct === null || pct === undefined) {
    hideEl(wrap);
    if (bar) bar.style.width = "0%";
    if (txt) txt.textContent = "";
    return;
  }
  showEl(wrap);
  if (bar) bar.style.width = pct + "%";
  if (txt) txt.textContent = pct + "%";
}

function updatePublishState() {
  const btn = $("#create-publish-btn");

  if (!btn) {
    return;
  }

  const title =
    ($("#create-title")?.value || "").trim();

  const text =
    state.richEditorEnabled
      ? richEditorPlainText()
      : ($("#create-text")?.value || "").trim();

  const empty =
    !title ||
    (!text && !state.selectedPostMedia && !state.selectedPostBackground);

  btn.disabled = state.uploading || empty;
  btn.classList.toggle("hidden", empty);
}

function resetCreateForm() {
  const title = $("#create-title");

  if (title) {
    title.value = "";
  }

  const text = $("#create-text");

  if (text) {
    text.value = "";
  }

  const editor =
    $("#create-rich-editor");

  if (editor) {
    editor.innerHTML = "";
  }

  const priv =
    $("#create-privacy");

  if (priv) {
    priv.value = "public";
  }

  state.selectedImageRatio = "original";
  state.selectedVideoRatio = "original";
  state.selectedBackgroundRatio = "original";
  if (state.selectedPostBackground?.localUrl) revokeUrl(state.selectedPostBackground.localUrl);
  state.selectedPostBackground = null;
  clearComposerBackgroundCanvas();
  state.editingPostId = null;

  $$(".ratio-btn").forEach(btn => {
    const active = (btn.dataset.ratio || btn.dataset.videoRatio || btn.dataset.bgRatio) === "original";

    btn.classList.toggle(
      "active",
      active
    );

    btn.setAttribute(
      "aria-pressed",
      active
        ? "true"
        : "false"
    );
  });

  clearSelectedPostMedia();
  resetPostFormat();
  setUploadProgress(null);
  updatePublishState();
}

/* ------------------------------------------------------------
   19. AMIS (friendships / friendRequests)
   ------------------------------------------------------------ */
function requestIdFor(senderUid, receiverUid) { return `${senderUid}_${receiverUid}`; }

async function areFriends(uid1, uid2) {
  if (!uid1 || !uid2) return false;
  if (uid1 === uid2) return true;
  const me = state.currentUser?.uid;
  if (me && (uid1 === me || uid2 === me) && state.friendsLoaded) {
    return state.friendIds.has(uid1 === me ? uid2 : uid1);
  }
  try {
    const snap = await getDoc(doc(db, "friendships", friendshipId(uid1, uid2)));
    return snap.exists();
  } catch (e) {
    return false;
  }
}

/* Statut dérivé des listeners (aucune lecture de doc inexistant) */
function getFriendshipStatus(uid) {
  const me = state.currentUser?.uid;
  if (!me || !uid) return { status: "none" };
  if (me === uid) return { status: "self" };
  if (state.friendIds.has(uid)) return { status: "friends" };
  const out = state.outgoingRequests.find(r => r.receiverId === uid);
  if (out) return { status: "request_sent", requestId: out.id };
  const inc = state.incomingRequests.find(r => r.senderId === uid);
  if (inc) return { status: "request_received", requestId: inc.id };
  return { status: "none" };
}

async function sendFriendRequest(uid) {
  const me = state.currentUser?.uid;
  if (!me || !uid || me === uid) return;
  const st = getFriendshipStatus(uid);
  if (st.status === "friends" || st.status === "request_sent") return;
  if (st.status === "request_received") { await acceptFriendRequest(st.requestId); return; }

  const id = requestIdFor(me, uid);
  try {
    await setDoc(doc(db, "friendRequests", id), {
      senderId: me,
      receiverId: uid,
      status: "pending",
      createdAt: serverTimestamp()
    });
    await createNotification({
      id: `friend_request_${id}`,
      userId: uid,
      actorId: me,
      type: "friend_request",
      title: uiText("Demande d'ami", "Fangatahana ho namana", "Friend request"),
      preview: `${state.currentProfile?.fullname || uiSomeone()} ${uiText("vous a envoyé une demande d'ami.", "nandefa fangatahana ho namana taminao.", "sent you a friend request.")}`
    });
    toast(t("msg_friend_request_sent"));
  } catch (err) {
    logError("[friend request]", err);
    toast(t("err_generic"));
  }
}

async function acceptFriendRequest(requestId) {
  const me = state.currentUser?.uid;
  if (!me || !requestId) return;
  try {
    const ref = doc(db, "friendRequests", requestId);
    const snap = await getDoc(ref);
    if (!snap.exists()) return;
    const r = snap.data();
    if (r.receiverId !== me) { toast(t("err_no_permission")); return; }

    const pairId = friendshipId(r.senderId, r.receiverId);
    const batch = writeBatch(db);
    batch.set(doc(db, "friendships", pairId), {
      users: [r.senderId, r.receiverId].sort(),
      createdAt: serverTimestamp()
    });
    batch.delete(ref);
    await batch.commit();

    await createNotification({
      id: `friend_accept_${pairId}_${me}`,
      userId: r.senderId,
      actorId: me,
      type: "friend_accept",
      title: uiText("Demande acceptée", "Nekena ny fangatahana", "Request accepted"),
      preview: `${state.currentProfile?.fullname || uiSomeone()} ${uiText("a accepté votre demande d'ami.", "nanaiky ny fangatahanao ho namana.", "accepted your friend request.")}`
    });
    toast(t("msg_friend_accepted"));
  } catch (err) {
    logError("[accept friend]", err);
    toast(t("err_generic"));
  }
}

async function rejectFriendRequest(requestId) {
  if (!requestId) return;
  try {
    await deleteDoc(doc(db, "friendRequests", requestId));
    toast(t("msg_request_declined"));
  } catch (err) {
    logError("[reject friend]", err);
    toast(t("err_generic"));
  }
}

async function cancelFriendRequest(requestId) {
  if (!requestId) return;
  try {
    await deleteDoc(doc(db, "friendRequests", requestId));
    toast(t("msg_request_cancelled"));
  } catch (err) {
    logError("[cancel friend]", err);
    toast(t("err_generic"));
  }
}

async function removeFriend(uid) {
  const me = state.currentUser?.uid;
  if (!me || !uid || me === uid) return;
  const ok = await showConfirm({
    title: t("confirm_remove_friend_title"),
    message: t("confirm_remove_friend"),
    confirmText: t("friend_remove"),
    danger: true
  });
  if (!ok) return;
  try {
    await deleteDoc(doc(db, "friendships", friendshipId(me, uid)));
    toast(t("msg_friend_removed"));
  } catch (err) {
    logError("[remove friend]", err);
    toast(t("err_generic"));
  }
}

function updateFriendButton() {
  const btn = $("#profile-other-friend-btn");
  const uid = state.profileViewUid;
  if (!btn) return;
  if (!uid || !state.currentUser || uid === state.currentUser.uid) { hideEl(btn); return; }
  showEl(btn);
  const st = getFriendshipStatus(uid);
  state.friendshipStatus = st.status;
  btn.dataset.status = st.status;
  btn.disabled = false;
  const labels = {
    none: t("friend_add"),
    request_sent: t("friend_sent"),
    request_received: t("friend_accept"),
    friends: t("friend_friends")
  };
  btn.textContent = labels[st.status] || t("friend_add");
  if (st.status === "request_sent") btn.setAttribute("aria-label", t("friend_cancel"));
  else if (st.status === "friends") btn.setAttribute("aria-label", t("friend_remove"));
  else btn.removeAttribute("aria-label");
}

async function handleFriendButtonClick() {
  const uid = state.profileViewUid;
  const btn = $("#profile-other-friend-btn");
  if (!uid || !state.currentUser || uid === state.currentUser.uid || !btn || btn.disabled) return;
  const st = getFriendshipStatus(uid);
  btn.disabled = true;
  try {
    if (st.status === "none") await sendFriendRequest(uid);
    else if (st.status === "request_sent") await cancelFriendRequest(st.requestId);
    else if (st.status === "request_received") await acceptFriendRequest(st.requestId);
    else if (st.status === "friends") await removeFriend(uid);
  } finally {
    btn.disabled = false;
    updateFriendButton();
  }
}

function startFriendsListeners() {
  const me = state.currentUser?.uid;
  if (!me) return;

  listeners.friends = onSnapshot(
    query(collection(db, "friendships"), where("users", "array-contains", me), limit(300)),
    snap => {
      const ids = new Set();
      snap.forEach(d => (d.data().users || []).forEach(u => { if (u !== me) ids.add(u); }));
      state.friendIds = ids;
      state.friendsLoaded = true;

      setText(
        "profile-me-friends-count",
        ids.size
      );

      renderFriendsList();
      updateFriendButton();
    },
    err => logError("[friends listener]", err)
  );

  listeners.friendRequests = onSnapshot(
    query(collection(db, "friendRequests"), where("receiverId", "==", me), limit(100)),
    snap => {
      state.incomingRequests = snap.docs
        .map(d => ({ id: d.id, ...d.data() }))
        .filter(r => r.status === "pending");
      renderRequestsList();
      updateFriendButton();
    },
    err => logError("[friend requests listener]", err)
  );

  listeners.outgoingRequests = onSnapshot(
    query(collection(db, "friendRequests"), where("senderId", "==", me), limit(100)),
    snap => {
      state.outgoingRequests = snap.docs
        .map(d => ({ id: d.id, ...d.data() }))
        .filter(r => r.status === "pending");
      renderRequestsList();
      updateFriendButton();
    },
    err => logError("[outgoing requests listener]", err)
  );
}

function makeSmallButton(label, kind, onClick) {
  const b = document.createElement("button");
  b.type = "button";
  b.className = "btn-small" + (kind === "primary" ? " primary" : kind === "danger" ? " danger" : "");
  b.textContent = label;
  Object.assign(b.style, { padding: "6px 12px", borderRadius: "10px", fontSize: "13px", cursor: "pointer", marginLeft: "6px" });
  b.addEventListener("click", async e => {
    e.stopPropagation();
    if (b.disabled) return;
    b.disabled = true;
    try { await onClick(); } finally { b.disabled = false; }
  });
  return b;
}

function buildUserRow(u, actions = []) {
  const el = renderUserCard(u);
  if (actions.length) {
    const box = document.createElement("div");
    box.className = "user-card-actions";
    Object.assign(box.style, { display: "flex", alignItems: "center", marginLeft: "auto" });
    actions.forEach(a => box.appendChild(a));
    el.appendChild(box);
  }
  return el;
}

async function renderFriendsList() {
  const container = document.getElementById("friends-list");
  if (!container) return;
  const token = ++listTokens.friends;
  const uids = Array.from(state.friendIds);
  if (!uids.length) {
    container.querySelectorAll(".user-card").forEach(n => n.remove());
    toggleEmpty("friends-empty", false);
    return;
  }
  toggleEmpty("friends-empty", true);
  const profiles = await Promise.all(uids.map(uid => getUserProfile(uid)));
  if (token !== listTokens.friends) return;
  container.querySelectorAll(".user-card").forEach(n => n.remove());
  profiles.forEach((p, i) => {
    const uid = uids[i];

    const u = p || {
      uid,
      fullname: "",
      username: ""
    };

    const row = buildUserRow(
      u,
      [
        makeSmallButton(
          t("friend_remove"),
          "danger",
          () => removeFriend(uid)
        )
      ]
    );

    row.classList.add("friend-manage-row");

    row.addEventListener("click", e => {
      if (e.target.closest("button")) {
        return;
      }

      openOtherProfile(uid);
    });

    container.appendChild(row);
  });
}

async function renderRequestsList() {
  const container = document.getElementById("friend-requests-list");
  if (!container) return;
  const token = ++listTokens.requests;
  const incoming = state.incomingRequests.slice();
  const outgoing = state.outgoingRequests.slice();

  if (!incoming.length && !outgoing.length) {
    container.querySelectorAll(".user-card").forEach(n => n.remove());
    toggleEmpty("friend-requests-empty", false);
    return;
  }
  toggleEmpty("friend-requests-empty", true);

  const [inProfiles, outProfiles] = await Promise.all([
    Promise.all(incoming.map(r => getUserProfile(r.senderId))),
    Promise.all(outgoing.map(r => getUserProfile(r.receiverId)))
  ]);
  if (token !== listTokens.requests) return;

  container.querySelectorAll(".user-card").forEach(n => n.remove());
  incoming.forEach((r, i) => {
    const u = inProfiles[i] || { uid: r.senderId, fullname: "", username: "" };
    container.appendChild(buildUserRow(u, [
      makeSmallButton(t("friend_accept"), "primary", () => acceptFriendRequest(r.id)),
      makeSmallButton(t("friend_reject"), "", () => rejectFriendRequest(r.id))
    ]));
  });
  outgoing.forEach((r, i) => {
    const u = outProfiles[i] || { uid: r.receiverId, fullname: "", username: "" };
    container.appendChild(buildUserRow(u, [
      makeSmallButton(t("friend_cancel"), "", () => cancelFriendRequest(r.id))
    ]));
  });
}

/* ------------------------------------------------------------
   20. PRÉSENCE / DERNIÈRE CONNEXION
   ------------------------------------------------------------ */
function formatPresence(profile) {
  if (!profile) return "";
  if (profile.showOnlineStatus === false) return "";
  const last = toDate(profile.lastSeen);
  if (profile.isOnline === true) {
    if (!last || (Date.now() - last.getTime()) < ONLINE_FRESH_MS) return "● " + t("online");
  }
  if (!last) return "";
  const diffSec = (Date.now() - last.getTime()) / 1000;
  if (diffSec < 3600) return `il y a ${Math.max(1, Math.floor(diffSec / 60))} min`;
  if (diffSec < 86400) return `il y a ${Math.floor(diffSec / 3600)} h`;
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  if (last.toDateString() === yesterday.toDateString()) return t("yesterday");
  return last.toLocaleDateString();
}

async function writePresence(online) {
  const user = state.currentUser;
  if (!user || !state.profileExists) return;
  state.lastPresenceWrite = Date.now();
  try {
    await setDoc(doc(db, "users", user.uid), {
      isOnline: online,
      lastSeen: serverTimestamp()
    }, { merge: true });
  } catch (e) {
    console.warn("[presence]", e);
  }
}

function startPresence() {
  if (state.presenceStarted || !state.currentUser) return;
  state.presenceStarted = true;
  if (document.visibilityState === "visible") writePresence(true);
  state.presenceHeartbeat = setInterval(() => {
    if (document.visibilityState === "visible") writePresence(true);
  }, HEARTBEAT_MS);
}

function stopPresence() {
  if (state.presenceHeartbeat) clearInterval(state.presenceHeartbeat);
  state.presenceHeartbeat = null;
  state.presenceStarted = false;
}

function onVisibilityChange() {
  if (!state.presenceStarted) return;
  if (document.visibilityState === "visible") writePresence(true);
  else writePresence(false);
}

function onBeforeUnload() {
  /* best-effort uniquement */
  if (state.presenceStarted) writePresence(false);
}

function listenActiveProfilePresence(uid) {
  if (listeners.activeProfilePresence) { listeners.activeProfilePresence(); listeners.activeProfilePresence = null; }
  if (!uid) return;
  listeners.activeProfilePresence = onSnapshot(doc(db, "users", uid), snap => {
    if (state.profileViewUid !== uid || !snap.exists()) return;
    setText("profile-other-presence", formatPresence(snap.data()));
  }, err => console.warn("[profile presence]", err));
}

function listenConversationPresence(uid) {
  if (listeners.presence) { listeners.presence(); listeners.presence = null; }
  setText("conv-presence", "");
  if (!uid) return;
  listeners.presence = onSnapshot(doc(db, "users", uid), snap => {
    if (!snap.exists()) { setText("conv-presence", ""); return; }
    setText("conv-presence", formatPresence(snap.data()));
  }, err => console.warn("[conv presence]", err));
}

/* ------------------------------------------------------------
   21. AUTH — INSCRIPTION / CONNEXION / OUBLI
   ------------------------------------------------------------ */
function normalizePhoneNumber(raw) {
  // Convertit les variantes malgaches 034... / 34... / 26134... / +261 34...
  // sans changer les numéros internationaux explicites (+33..., +1...).
  let value = String(raw || "").trim().replace(/[\s().\-/]/g, "");
  if (value.startsWith("00")) value = "+" + value.slice(2);
  if (/^0\d{9}$/.test(value)) return "+261" + value.slice(1);
  if (/^261\d{9}$/.test(value)) return "+" + value;
  if (/^(?:32|33|34|38)\d{7}$/.test(value)) return "+261" + value;
  return value;
}

function phoneAuthMessage(err) {
  const code = String(err?.code || "");
  if (["auth/billing-not-enabled", "auth/payment-required", "auth/operation-not-supported-in-this-environment"].includes(code)) {
    return state.lang === "mg"
      ? "Mila plan Blaze sy SMS Phone Auth mavitrika ao amin'ny Firebase ny SMS tena izy."
      : state.lang === "en"
      ? "Real phone SMS requires Firebase Blaze billing and Phone Authentication enabled."
      : "Les SMS réels nécessitent Firebase Blaze et l'activation de l'authentification Téléphone.";
  }
  if (["auth/invalid-recaptcha-token", "auth/captcha-check-failed", "auth/missing-app-credential", "auth/invalid-app-credential"].includes(code)) {
    return state.lang === "mg"
      ? "Tsy nahomby ny reCAPTCHA. Jereo ny internet sy ny domaine autorisé, dia andramo indray."
      : state.lang === "en"
      ? "reCAPTCHA failed. Check your connection and authorized domain, then retry."
      : "Échec reCAPTCHA. Vérifiez la connexion et le domaine autorisé, puis réessayez.";
  }
  if (code === "auth/invalid-verification-id" || code === "auth/session-expired") {
    return state.lang === "mg" ? "Lany daty ny fanamarinana. Mangataha kaody vaovao." :
      state.lang === "en" ? "Verification expired. Request a new code." :
      "Vérification expirée. Demandez un nouveau code.";
  }
  const message = friendlyAuthError(err);
  return code && message === t("err_generic") ? `${message} (${code})` : message;
}

function resetPhoneCaptcha(stateKey, containerId) {
  try { state[stateKey]?.clear(); } catch (_) {}
  state[stateKey] = null;
  const host = document.getElementById(containerId);
  if (host) host.replaceChildren();
}

function createVisiblePhoneCaptcha(stateKey, containerId, parent) {
  if (state[stateKey]) return state[stateKey];
  let host = document.getElementById(containerId);
  if (!host) {
    host = document.createElement("div");
    host.id = containerId;
    parent?.appendChild(host);
  }
  host.classList.add("lyrame-phone-recaptcha-host");
  host.setAttribute("aria-label", "Vérification anti-robot");
  // reCAPTCHA visible et réellement présent dans le formulaire mobile.
  state[stateKey] = new RecaptchaVerifier(auth, host, { size: "normal" });
  return state[stateKey];
}

function ensurePhoneRecaptcha() {
  return createVisiblePhoneCaptcha("recaptchaVerifier", "phone-recaptcha-container", $("#register-phone-section"));
}


async function sendPhoneVerificationCode() {
  const phone = normalizePhoneNumber($("#register-phone")?.value);
  const fullname = ($("#register-fullname")?.value || "").trim();
  const username = normalizeUsername($("#register-username")?.value);
  if (!fullname || !username || !isValidUsername(username)) {
    const message = !fullname || !username ? t("err_required") : t("err_username_format");
    setStatusLine("register-phone-status", message, "error");
    toast(message);
    return;
  }
  if (!/^\+[1-9]\d{7,14}$/.test(phone)) {
    setStatusLine("register-phone-status", t("invalid_phone"), "error");
    toast(t("invalid_phone"));
    return;
  }
  const btn = $("#register-send-code-btn");
  setBusy(btn, true, "...");
  try {
    // Si le nom est déjà utilisé, ne gaspillons pas de SMS et conservons le compte existant.
    const usernameTaken = await getDoc(doc(db, "usernames", username));
    if (usernameTaken.exists()) throw new Error("USERNAME_TAKEN");
    resetPhoneCaptcha("recaptchaVerifier", "phone-recaptcha-container");
    state.phoneConfirmationResult = null;
    state.phoneVerifiedUser = null;
    state.phoneRegistrationPending = false;
    hideEl($("#register-phone-verification"));
    setStatusLine("register-phone-status", "Validez le contrôle anti-robot pour recevoir votre code SMS.", "info");
    const verifier = ensurePhoneRecaptcha();
    await verifier.render();
    state.phoneConfirmationResult = await signInWithPhoneNumber(auth, phone, verifier);
    showEl($("#register-phone-verification"));
    setStatusLine("register-phone-status", t("phone_code_sent"), "success");
  } catch (err) {
    logError("[phone otp]", err);
    const msg = err?.message === "USERNAME_TAKEN" ? t("err_username_taken") : phoneAuthMessage(err);
    setStatusLine("register-phone-status", msg, "error");
    toast(msg);
    resetPhoneCaptcha("recaptchaVerifier", "phone-recaptcha-container");
  } finally {
    setBusy(btn, false);
  }
}

async function verifyPhoneCode() {
  const code = ($("#register-phone-code")?.value || "").trim();
  if (!/^\d{6}$/.test(code)) {
    setStatusLine("register-phone-status", t("invalid_code"), "error");
    return;
  }
  if (!state.phoneConfirmationResult) {
    setStatusLine("register-phone-status", t("phone_code_first"), "error");
    return;
  }
  const btn = $("#register-verify-code-btn");
  setBusy(btn, true, "...");
  state.phoneRegistrationPending = true;
  try {
    const result = await state.phoneConfirmationResult.confirm(code);
    if (!result?.user) throw new Error("PHONE_AUTH_NO_USER");
    state.phoneVerifiedUser = result.user;
    state.phoneConfirmationResult = null;
    // Un numéro déjà inscrit connecte le compte existant ; ne réécrit jamais son profil.
    const existing = await getDoc(doc(db, "users", result.user.uid));
    if (existing.exists()) {
      state.phoneRegistrationPending = false;
      await transitionToAuthenticatedApp(result.user);
      setStatusLine("register-phone-status", t("phone_login_success"), "success");
    } else {
      // Termine automatiquement l'inscription avec le nom et le pseudo déjà saisis.
      setStatusLine("register-phone-status", t("phone_verified"), "success");
      await handleRegisterSubmit({ preventDefault() {}, target: $("#form-register") });
    }
  } catch (err) {
    // Si le code est valide mais l'écriture du profil a échoué, conserver le compte
    // vérifié et laisser l'utilisateur réessayer "S'inscrire" sans renvoyer un SMS.
    if (!state.phoneVerifiedUser) state.phoneRegistrationPending = false;
    logError("[verify phone]", err);
    const msg = phoneAuthMessage(err);
    setStatusLine("register-phone-status", msg, "error");
    toast(msg);
  } finally {
    setBusy(btn, false);
  }
}

function ensureLoginPhoneRecaptcha() {
  return createVisiblePhoneCaptcha("loginRecaptchaVerifier", "login-phone-recaptcha-container", $("#login-phone-section"));
}

async function sendLoginPhoneVerificationCode() {
  const phone = normalizePhoneNumber($("#login-phone")?.value);
  if (!/^\+[1-9]\d{7,14}$/.test(phone)) {
    setStatusLine("login-phone-status", t("invalid_phone"), "error");
    toast(t("invalid_phone"));
    return;
  }
  const btn = $("#login-send-code-btn");
  setBusy(btn, true, "...");
  try {
    state.loginPhoneConfirmationResult = null;
    resetPhoneCaptcha("loginRecaptchaVerifier", "login-phone-recaptcha-container");
    hideEl($("#login-phone-verification"));
    setStatusLine("login-phone-status", "Validez le contrôle anti-robot pour recevoir votre code SMS.", "info");
    const verifier = ensureLoginPhoneRecaptcha();
    await verifier.render();
    state.loginPhoneConfirmationResult = await signInWithPhoneNumber(auth, phone, verifier);
    showEl($("#login-phone-verification"));
    setStatusLine("login-phone-status", t("phone_code_sent"), "success");
  } catch (err) {
    logError("[login phone otp]", err);
    const msg = phoneAuthMessage(err);
    setStatusLine("login-phone-status", msg, "error");
    toast(msg);
    resetPhoneCaptcha("loginRecaptchaVerifier", "login-phone-recaptcha-container");
  } finally {
    setBusy(btn, false);
  }
}

async function verifyLoginPhoneCode() {
  const code = ($("#login-phone-code")?.value || "").trim();
  if (!/^\d{6}$/.test(code)) {
    setStatusLine("login-phone-status", t("invalid_code"), "error");
    return;
  }
  if (!state.loginPhoneConfirmationResult) {
    setStatusLine("login-phone-status", t("phone_code_first"), "error");
    return;
  }
  const btn = $("#login-verify-code-btn");
  setBusy(btn, true, "...");
  state.phoneLoginPending = true;
  try {
    const result = await state.loginPhoneConfirmationResult.confirm(code);
    if (!result?.user) throw new Error("PHONE_AUTH_NO_USER");
    state.loginPhoneConfirmationResult = null;
    const profile = await getDoc(doc(db, "users", result.user.uid));
    if (profile.exists()) {
      state.phoneLoginPending = false;
      await transitionToAuthenticatedApp(result.user);
      setStatusLine("login-phone-status", t("phone_login_success"), "success");
      toast(t("phone_login_success"));
    } else {
      // Firebase peut créer un utilisateur Auth sans document profil au premier OTP.
      // Proposer une inscription, sans créer un deuxième utilisateur ni demander un autre SMS.
      state.phoneVerifiedUser = result.user;
      state.phoneRegistrationPending = true;
      state.phoneLoginPending = false;
      showAuthPanel("register");
      $("#register-method-phone")?.click();
      if ($("#register-phone")) $("#register-phone").value = result.user.phoneNumber || "";
      setStatusLine("register-phone-status", state.lang === "mg" ?
        "Voaamarina ny laharana. Fenoy ny anarana sy pseudo, avy eo tsindrio S'inscrire."
        : "Numéro vérifié. Saisissez nom et pseudo puis cliquez sur S'inscrire.", "success");
      toast(state.lang === "mg" ? "Fenoy ny profil hamitana ny fisoratana anarana." : "Complétez le profil pour terminer l'inscription.");
      $("#register-fullname")?.focus();
    }
  } catch (err) {
    logError("[login phone verify]", err);
    const msg = phoneAuthMessage(err);
    setStatusLine("login-phone-status", msg, "error");
    toast(msg);
  } finally {
    state.phoneLoginPending = false;
    setBusy(btn, false);
  }
}

async function handleRegisterSubmit(event) {
  event.preventDefault();

  const form = event.target;

  const fullname = ($("#register-fullname")?.value || "").trim();

  const username = normalizeUsername($("#register-username")?.value);

  const email = ($("#register-email")?.value || "")
    .trim()
    .toLowerCase();

  const password = $("#register-password")?.value || "";

  const confirmPassword = $("#register-confirm")?.value || "";

  const button = form.querySelector('button[type="submit"]');

  if (!fullname || !username) {
    toast(t("err_required"));
    return;
  }

  if (!isValidUsername(username)) {
    toast(t("err_username_format"));
    return;
  }

  if (state.registerMethod === "email") {
    if (!email || !password || !confirmPassword) {
      toast(t("err_required"));
      return;
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      toast(t("err_invalid_email"));
      return;
    }

    if (password.length < 6) {
      toast(t("err_weak_password"));
      return;
    }

    if (password !== confirmPassword) {
      toast(t("err_password_mismatch"));
      return;
    }
  } else {
    if (!state.phoneVerifiedUser) {
      toast(t("verify_phone_first"));
      return;
    }
  }

  setBusy(button, true, "...");

  state.registering = true;

  try {
    let createdUser = null;

    if (state.registerMethod === "email") {
      if (auth.currentUser && auth.currentUser.email === email && !state.profileExists) {
        createdUser = auth.currentUser;
      } else {
        const credential = await createUserWithEmailAndPassword(auth, email, password);
        createdUser = credential.user;
      }
    } else {
      createdUser = state.phoneVerifiedUser;
    }

    if (!createdUser) {
      throw new Error("NO_AUTH_USER");
    }

    const usernameRef = doc(db, "usernames", username);

    const userRef = doc(db, "users", createdUser.uid);

    await runTransaction(db, async transaction => {
      const usernameSnap = await transaction.get(usernameRef);

      if (usernameSnap.exists()) {
        throw new Error("USERNAME_TAKEN");
      }

      transaction.set(usernameRef, {
        uid: createdUser.uid,
        username,
        createdAt: serverTimestamp()
      });

      transaction.set(userRef, {
        uid: createdUser.uid,
        fullname,
        username,
        email: createdUser.email || "",
        phoneNumber: createdUser.phoneNumber || "",
        authMethod: createdUser.phoneNumber ? "phone" : "email",
        bio: "",
        photoURL: "",
        coverURL: "",
        avatarPublicId: "",
        coverPublicId: "",
        followersCount: 0,
        followingCount: 0,
        postsCount: 0,
        birthdate: "",
        birthdatePrivacy: "private",
        showOnlineStatus: true,
        isOnline: true,
        lastSeen: serverTimestamp(),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
    });

    try {
      await updateProfile(createdUser, {
        displayName: fullname
      });
    } catch (_) {}

    toast(t("msg_register_success"));

    form.reset();

    state.phoneConfirmationResult = null;
    state.phoneRegistrationPending = false;
    state.phoneVerifiedUser = null;
    await transitionToAuthenticatedApp(createdUser);
  } catch (err) {
    logError("[register]", err);

    if (err?.message === "USERNAME_TAKEN") {
      toast(t("err_username_taken"));
    } else if (err?.code && String(err.code).startsWith("auth/")) {
      toast(friendlyAuthError(err));
    } else {
      toast(t("err_generic"));
    }
  } finally {
    state.registering = false;

    setBusy(button, false);
  }
}

function configureCallButtons() {
  const audio = $("#conv-audio-call-btn");
  const video = $("#conv-video-call-btn");
  showEl(audio);
  showEl(video);
}

const DEFAULT_RTC_ICE_SERVERS = [
  { urls: "stun:stun.l.google.com:19302" },
  { urls: "stun:stun1.l.google.com:19302" }
];

async function getRtcIceServers() {
  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 3000);
    const res = await fetch("/api/rtc-config", { credentials: "same-origin", signal: ctrl.signal });
    clearTimeout(timer);
    if (res.ok) {
      const data = await res.json();
      if (Array.isArray(data?.iceServers) && data.iceServers.length) return data.iceServers;
    }
  } catch (_) { /* Floot/TURN optional; STUN fallback below */ }
  return DEFAULT_RTC_ICE_SERVERS;
}

function otherDirectParticipant(conv = state.activeConv) {
  const me = state.currentUser?.uid;
  const ids = Array.isArray(conv?.memberIds) ? conv.memberIds : [];
  return ids.find(uid => uid && uid !== me) || "";
}


const LYRAME_CALL_VIDEO_FILTERS = [
  { id:"none", label:uiText("Naturel","Ara-boajanahary","Natural"), filter:"none" },
  { id:"hd", label:"HD", filter:"contrast(1.08) saturate(1.06) brightness(1.02)" },
  { id:"vivid", label:uiText("Vif","Mazava","Vivid"), filter:"contrast(1.12) saturate(1.28)" },
  { id:"warm", label:uiText("Chaud","Mafana","Warm"), filter:"sepia(.10) saturate(1.15) hue-rotate(-7deg) brightness(1.03)" },
  { id:"cool", label:uiText("Froid","Mangatsiaka","Cool"), filter:"saturate(1.05) hue-rotate(9deg) brightness(1.02)" },
  { id:"soft", label:uiText("Doux","Malefaka","Soft"), filter:"brightness(1.06) contrast(.94) saturate(.94)" },
  { id:"mono", label:uiText("Noir & blanc","Mainty sy fotsy","B&W"), filter:"grayscale(1) contrast(1.08)" },
  { id:"cinema", label:uiText("Cinéma","Sinema","Cinema"), filter:"contrast(1.16) saturate(.88) sepia(.08)" }
];
function callPresenceState(profile){if(!profile||profile.showOnlineStatus===false)return"unknown";if(profile.isOnline!==true)return"offline";const last=toDate(profile.lastSeen);if(!last)return"unknown";return(Date.now()-last.getTime())<ONLINE_FRESH_MS?"online":"offline";}
function clearCallTimers(){if(state.callRingTimer)clearTimeout(state.callRingTimer);if(state.callDisconnectTimer)clearTimeout(state.callDisconnectTimer);state.callRingTimer=null;state.callDisconnectTimer=null;}
function stopCallVideoProcessor(){const p=state.callVideoProcessor;if(!p)return;try{if(p.raf)cancelAnimationFrame(p.raf);}catch(_){}try{p.video?.pause();}catch(_){}try{p.stream?.getVideoTracks?.().forEach(t=>t.stop());}catch(_){}state.callVideoProcessor=null;}
async function makeProcessedCallStream(rawStream){const rawVideo=rawStream?.getVideoTracks?.()[0],audios=rawStream?.getAudioTracks?.()||[];if(!rawVideo)return rawStream;try{await rawVideo.applyConstraints({width:{ideal:1280,max:1280},height:{ideal:720,max:720},frameRate:{ideal:30,max:30}});}catch(_){}try{rawVideo.contentHint="detail";}catch(_){}const canvas=document.createElement("canvas");if(typeof canvas.captureStream!=="function"){console.warn("[call filter] captureStream unavailable");return rawStream;}const video=document.createElement("video");video.muted=true;video.playsInline=true;video.autoplay=true;video.srcObject=new MediaStream([rawVideo]);try{await video.play();}catch(_){}const s=rawVideo.getSettings?.()||{},w=Math.max(640,Math.min(1280,Number(s.width)||1280)),h=Math.max(360,Math.min(720,Number(s.height)||720));canvas.width=w;canvas.height=h;const ctx=canvas.getContext("2d",{alpha:false,desynchronized:true});if(!ctx)return rawStream;const processed=canvas.captureStream(30),outVideo=processed.getVideoTracks()[0];try{outVideo.contentHint="detail";}catch(_){}const out=new MediaStream([...audios,outVideo]);state.callVideoProcessor={video,canvas,ctx,stream:processed,raf:0};const draw=()=>{const pp=state.callVideoProcessor;if(!pp)return;if(video.readyState>=2){const f=LYRAME_CALL_VIDEO_FILTERS.find(x=>x.id===state.callVideoFilter)||LYRAME_CALL_VIDEO_FILTERS[0];ctx.save();ctx.filter=f.filter||"none";ctx.drawImage(video,0,0,w,h);ctx.restore();}pp.raf=requestAnimationFrame(draw);};draw();return out;}
function setCallVideoFilter(id){const f=LYRAME_CALL_VIDEO_FILTERS.find(x=>x.id===id)||LYRAME_CALL_VIDEO_FILTERS[0];state.callVideoFilter=f.id;document.querySelectorAll(".lyrame-call-filter-btn").forEach(b=>b.classList.toggle("active",b.dataset.filter===f.id));const local=document.getElementById("lyrame-local-video");if(local&&!state.callVideoProcessor)local.style.filter=f.filter||"none";}
function toggleCallFilterTray(force){const tray=document.getElementById("lyrame-call-filter-tray");if(!tray)return;const show=force===undefined?tray.classList.contains("hidden"):!!force;tray.classList.toggle("hidden",!show);}
function toggleCallMinimized(force){const overlay=document.getElementById("lyrame-call-overlay");if(!overlay)return;const next=force===undefined?!overlay.classList.contains("is-minimized"):!!force;overlay.classList.toggle("is-minimized",next);state.callMinimized=next;document.getElementById("lyrame-call-restore")?.remove();const min=document.getElementById("lyrame-call-minimize");if(min){min.textContent=next?"□":"—";}if(next)toggleCallFilterTray(false);}
function renderCallFilterTray(overlay){const tray=overlay?.querySelector("#lyrame-call-filter-tray");if(!tray)return;tray.innerHTML="";for(const f of LYRAME_CALL_VIDEO_FILTERS){const b=document.createElement("button");b.type="button";b.className="lyrame-call-filter-btn";b.dataset.filter=f.id;b.textContent=f.label;b.addEventListener("click",()=>setCallVideoFilter(f.id));tray.appendChild(b);}setCallVideoFilter(state.callVideoFilter||"none");}

function closeCallOverlay(){document.getElementById("lyrame-call-overlay")?.remove();document.getElementById("lyrame-call-restore")?.remove();state.callMinimized=false;}

function callOverlay({ type="audio", title="", incoming=false, onAccept=null, onDecline=null }={}){
 closeCallOverlay();const overlay=document.createElement("div");overlay.id="lyrame-call-overlay";overlay.className=`lyrame-call-overlay ${type==="video"?"is-video":"is-audio"}${incoming?" is-incoming":""}`;
 overlay.innerHTML=`<div class="lyrame-call-stage"><div class="lyrame-call-top"><div class="lyrame-call-top-actions"><button type="button" id="lyrame-call-minimize" class="lyrame-call-mini-btn">—</button><button type="button" id="lyrame-call-end-mini" class="lyrame-call-mini-btn danger">×</button></div><strong>${escapeHtml(title||uiText("Appel LYRAME","Antso LYRAME","LYRAME call"))}</strong><span id="lyrame-call-status">${escapeHtml(incoming?uiText("Appel entrant…","Antso miditra…","Incoming call…"):uiText("Connexion…","Mampifandray…","Connecting…"))}</span>${type==="video"?'<span class="lyrame-call-quality">HD · 720p</span>':''}</div><video id="lyrame-remote-video" autoplay playsinline></video><video id="lyrame-local-video" autoplay muted playsinline></video><div class="lyrame-call-avatar">${type==="video"?"":"☎"}</div>${type==="video"&&!incoming?'<div id="lyrame-call-filter-tray" class="lyrame-call-filter-tray hidden"></div>':''}<div class="lyrame-call-actions"></div></div>`;
 const actions=overlay.querySelector(".lyrame-call-actions");if(incoming){overlay.querySelector("#lyrame-call-minimize")?.classList.add("hidden");overlay.querySelector("#lyrame-call-end-mini")?.classList.add("hidden");const reject=styledButton(uiText("Refuser","Handà","Decline"),"danger"),accept=styledButton(uiText(type==="video"?"Répondre en vidéo":"Répondre",type==="video"?"Hamaly video":"Hamaly",type==="video"?"Answer video":"Answer"),"primary");reject.addEventListener("click",()=>onDecline?.());accept.addEventListener("click",()=>onAccept?.());actions.append(reject,accept);}else{if(type==="video"){const f=styledButton(uiText("Filtres","Filtre","Filters"),"ghost");f.addEventListener("click",()=>toggleCallFilterTray());actions.append(f);}const min=styledButton(uiText("Réduire","Ahena","Minimize"),"ghost"),end=styledButton(uiText("Raccrocher","Hampiato","End call"),"danger");min.addEventListener("click",()=>toggleCallMinimized(true));end.addEventListener("click",()=>endActiveCall("ended"));actions.append(min,end);}document.body.appendChild(overlay);overlay.querySelector("#lyrame-call-minimize")?.addEventListener("click",()=>toggleCallMinimized());overlay.querySelector("#lyrame-call-end-mini")?.addEventListener("click",()=>endActiveCall("ended"));if(type==="video"&&!incoming)renderCallFilterTray(overlay);return overlay;
}

function setCallStatus(text) {
  const el = document.getElementById("lyrame-call-status");
  if (el) el.textContent = text || "";
}

function attachCallStreams() {
  const remote = document.getElementById("lyrame-remote-video");
  const local = document.getElementById("lyrame-local-video");
  if (remote && state.callRemoteStream) remote.srcObject = state.callRemoteStream;
  if (local && state.callLocalStream) local.srcObject = state.callLocalStream;
  if (state.activeCallType !== "video") { if (remote) remote.classList.add("audio-only"); if (local) local.classList.add("audio-only"); }
}

async function cleanupCall({updateStatus=""}={}){
  clearCallTimers();
  const callId=state.activeCallId, uid=state.currentUser?.uid||"";
  if(typeof state.callDocUnsub==="function")try{state.callDocUnsub();}catch(_){}
  if(typeof state.callCandidatesUnsub==="function")try{state.callCandidatesUnsub();}catch(_){}
  state.callDocUnsub=null; state.callCandidatesUnsub=null;
  try{state.callPeer?.close();}catch(_){} state.callPeer=null;
  stopCallVideoProcessor();
  for(const stream of [state.callLocalStream,state.callRawLocalStream,state.callRemoteStream])try{stream?.getTracks().forEach(t=>t.stop());}catch(_){}
  state.callLocalStream=null; state.callRawLocalStream=null; state.callRemoteStream=null; state.callVideoFilter="none";
  state.activeCallId=null; state.incomingCallShownId=null; state.callMinimized=false;
  // Fermer l'interface immédiatement : ne jamais bloquer le bouton Raccrocher/X sur Firestore.
  closeCallOverlay();
  if(updateStatus&&callId&&uid){
    updateDoc(doc(db,"calls",callId),{status:updateStatus,endedAt:serverTimestamp(),endedBy:uid,updatedAt:serverTimestamp()})
      .catch(err=>console.warn("[call status update]",err));
  }
}

async function endActiveCall(status = "ended") { await cleanupCall({ updateStatus: status }); }

// Android/WebView: les contrôles d'appel doivent répondre même si une couche vidéo intercepte le clic.
document.addEventListener("pointerup", e => {
  const end=e.target.closest?.("#lyrame-call-end-mini,.lyrame-call-actions .btn");
  if(!end) return;
  const label=(end.textContent||"").trim().toLowerCase();
  if(end.id==="lyrame-call-end-mini" || /raccrocher|hampiato|end call/.test(label)){
    e.preventDefault(); e.stopPropagation(); endActiveCall("ended");
  }
}, true);

async function preparePeerForCall(type,candidateCollection){const iceServers=await getRtcIceServers(),pc=new RTCPeerConnection({iceServers});state.callPeer=pc;state.activeCallType=type;state.callRemoteStream=new MediaStream();state.callVideoFilter="none";const constraints=type==="video"?{audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true},video:{facingMode:"user",width:{ideal:1280,max:1280},height:{ideal:720,max:720},frameRate:{ideal:30,max:30}}}:{audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true},video:false};state.callRawLocalStream=await navigator.mediaDevices.getUserMedia(constraints);state.callLocalStream=type==="video"?await makeProcessedCallStream(state.callRawLocalStream):state.callRawLocalStream;state.callLocalStream.getTracks().forEach(track=>{const sender=pc.addTrack(track,state.callLocalStream);if(track.kind==="video")try{const params=sender.getParameters();if(!params.encodings?.length)params.encodings=[{}];params.encodings[0].maxBitrate=2500000;params.encodings[0].maxFramerate=30;sender.setParameters(params).catch(()=>{});}catch(_){}});pc.ontrack=ev=>{ev.streams?.[0]?.getTracks().forEach(track=>{if(!state.callRemoteStream.getTracks().some(t=>t.id===track.id))state.callRemoteStream.addTrack(track);});attachCallStreams();};pc.onconnectionstatechange=()=>{if(state.callDisconnectTimer){clearTimeout(state.callDisconnectTimer);state.callDisconnectTimer=null;}if(pc.connectionState==="connected"){if(state.callRingTimer){clearTimeout(state.callRingTimer);state.callRingTimer=null;}setCallStatus(uiText("Connecté","Mifandray","Connected"));}else if(pc.connectionState==="disconnected"){setCallStatus(uiText("Reconnexion…","Mamerina fifandraisana…","Reconnecting…"));state.callDisconnectTimer=setTimeout(()=>{if(pc.connectionState==="disconnected")cleanupCall({updateStatus:"ended"});},9000);}else if(["failed","closed"].includes(pc.connectionState))cleanupCall({updateStatus:"ended"});};pc.onicecandidate=ev=>{if(!ev.candidate||!state.activeCallId)return;addDoc(collection(db,"calls",state.activeCallId,candidateCollection),ev.candidate.toJSON()).catch(err=>logError("[call candidate]",err));};attachCallStreams();return pc;}

function listenRemoteCandidates(callId, collectionName, pc) {
  const seen = new Set();
  state.callCandidatesUnsub = onSnapshot(collection(db, "calls", callId, collectionName), snap => {
    snap.docChanges().forEach(ch => {
      if (ch.type !== "added" || seen.has(ch.doc.id)) return;
      seen.add(ch.doc.id);
      pc.addIceCandidate(new RTCIceCandidate(ch.doc.data())).catch(err => logError("[remote candidate]", err));
    });
  }, err => logError("[call candidates listener]", err));
}

async function startOutgoingCall(type="audio"){if(!state.currentUser||!state.activeConvId||!state.activeConv)return;if(state.activeConv.isGroup||state.activeConv.type==="group"){toast(uiText("Les appels de groupe seront activés séparément.","Hampidirina misaraka ny antso vondrona.","Group calling will be enabled separately."));return;}if(!navigator.mediaDevices?.getUserMedia||!window.RTCPeerConnection){toast(uiText("Les appels ne sont pas pris en charge sur cet appareil.","Tsy tohanan’ity fitaovana ity ny antso.","Calls are not supported on this device."));return;}const calleeId=otherDirectParticipant();if(!calleeId)return;const other=await getUserProfile(calleeId),presence=callPresenceState(other),title=other?.fullname||other?.username||uiText("Appel","Antso","Call");if(presence==="offline"){const callRef=doc(collection(db,"calls"));state.activeCallId=callRef.id;state.activeCallType=type;callOverlay({type,title});setCallStatus(uiText("Hors ligne","Tsy en ligne","Offline"));try{await setDoc(callRef,{conversationId:state.activeConvId,callerId:state.currentUser.uid,calleeId,type,status:"missed",reason:"callee_offline",createdAt:serverTimestamp(),endedAt:serverTimestamp(),endedBy:state.currentUser.uid,updatedAt:serverTimestamp()});}catch(_){}state.callRingTimer=setTimeout(()=>cleanupCall(),4200);return;}try{const callRef=doc(collection(db,"calls"));state.activeCallId=callRef.id;state.activeCallType=type;callOverlay({type,title});const pc=await preparePeerForCall(type,"callerCandidates"),offer=await pc.createOffer();await pc.setLocalDescription(offer);await setDoc(callRef,{conversationId:state.activeConvId,callerId:state.currentUser.uid,calleeId,type,status:"ringing",offer:{type:offer.type,sdp:offer.sdp},createdAt:serverTimestamp(),updatedAt:serverTimestamp()});listenRemoteCandidates(callRef.id,"calleeCandidates",pc);state.callRingTimer=setTimeout(async()=>{if(state.activeCallId!==callRef.id)return;try{const snap=await getDoc(callRef);if(snap.exists()&&snap.data()?.status==="ringing"){await updateDoc(callRef,{status:"missed",endedAt:serverTimestamp(),endedBy:state.currentUser.uid});setCallStatus(uiText("Pas de réponse","Tsy namaly","No answer"));setTimeout(()=>cleanupCall(),1000);}}catch(_){}},presence==="online"?30000:18000);state.callDocUnsub=onSnapshot(callRef,async snap=>{if(!snap.exists())return;const data=snap.data();if(data.answer&&!pc.currentRemoteDescription){await pc.setRemoteDescription(new RTCSessionDescription(data.answer));if(state.callRingTimer){clearTimeout(state.callRingTimer);state.callRingTimer=null;}setCallStatus(uiText("Connexion…","Mampifandray…","Connecting…"));}if(["declined","ended","missed","cancelled"].includes(data.status))cleanupCall();},err=>logError("[call doc]",err));}catch(err){logError("[outgoing call]",err);toast(uiText("Impossible de démarrer l’appel.","Tsy afaka manomboka antso.","Could not start the call."));await cleanupCall({updateStatus:"cancelled"});}}

async function answerIncomingCall(callId, data) {
  try {
    clearCallTimers();
    state.activeCallId = callId;
    state.activeCallType = data.type === "video" ? "video" : "audio";
    callOverlay({ type: state.activeCallType, title: uiText("Appel en cours", "Antso mandeha", "Call in progress") });
    const pc = await preparePeerForCall(state.activeCallType, "calleeCandidates");
    await pc.setRemoteDescription(new RTCSessionDescription(data.offer));
    const answer = await pc.createAnswer();
    await pc.setLocalDescription(answer);
    await updateDoc(doc(db, "calls", callId), { answer: { type: answer.type, sdp: answer.sdp }, status: "accepted", answeredAt: serverTimestamp(), updatedAt: serverTimestamp() });
    listenRemoteCandidates(callId, "callerCandidates", pc);
    state.callDocUnsub = onSnapshot(doc(db, "calls", callId), snap => { const d = snap.data(); if (d && ["ended", "cancelled"].includes(d.status)) cleanupCall(); }, err => logError("[answered call]", err));
  } catch (err) { logError("[answer call]", err); toast(uiText("Impossible de répondre à l’appel.", "Tsy afaka mamaly antso.", "Could not answer the call.")); await cleanupCall({ updateStatus: "ended" }); }
}

function startIncomingCallsListener(uid) {
  if (listeners.calls) { listeners.calls(); listeners.calls = null; }
  if (!uid) return;
  listeners.calls = onSnapshot(query(collection(db, "calls"), where("calleeId", "==", uid), limit(12)), snap => {
    const ringing = snap.docs.map(d => ({ id: d.id, ...d.data() })).filter(c => c.status === "ringing").sort((a,b) => (toDate(b.createdAt)?.getTime()||0)-(toDate(a.createdAt)?.getTime()||0))[0];
    if (!ringing || state.activeCallId || state.incomingCallShownId === ringing.id) return;
    state.incomingCallShownId = ringing.id;
    getUserProfile(ringing.callerId).then(caller => {
      if (state.activeCallId || state.incomingCallShownId !== ringing.id) return;
      callOverlay({
        type: ringing.type === "video" ? "video" : "audio",
        title: caller?.fullname || caller?.username || uiText("Appel entrant", "Antso miditra", "Incoming call"),
        incoming: true,
        onAccept: () => answerIncomingCall(ringing.id, ringing),
        onDecline: async () => { try { await updateDoc(doc(db, "calls", ringing.id), { status: "declined", endedAt: serverTimestamp(), endedBy: uid }); } catch (_) {} state.incomingCallShownId = null; closeCallOverlay(); }
      });
    });
  }, err => logError("[incoming calls]", err));
}

function lyrV60SetLoginError(message = "") {
  const status = $("#login-error-status");
  if (!status) return;
  status.textContent = String(message || "");
  status.classList.toggle("hidden", !message);
}
// Google OAuth : même transition de session que les connexions existantes.
const lyrameGoogleProvider = new GoogleAuthProvider();
lyrameGoogleProvider.setCustomParameters({ prompt: "select_account" });
async function handleGoogleLogin() {
  const btn = $("#login-google-btn");
  lyrV60SetLoginError();
  setBusy(btn, true, "...");
  try {
    const credential = await signInWithPopup(auth, lyrameGoogleProvider);
    revealAuthenticatedShell(credential.user);
    await transitionToAuthenticatedApp(credential.user);
    toast(t("msg_login_success"));
  } catch (err) {
    if (err?.code === "auth/popup-blocked" || err?.code === "auth/operation-not-supported-in-this-environment") {
      try {
        await signInWithRedirect(auth, lyrameGoogleProvider);
        return;
      } catch (redirectError) { err = redirectError; }
    }
    if (err?.code !== "auth/popup-closed-by-user" && err?.code !== "auth/cancelled-popup-request") {
      console.error("[google login]", err);
      const msg = friendlyAuthError(err);
      lyrV60SetLoginError(msg);
      toast(msg);
    }
  } finally { setBusy(btn, false); }
}
// Traiter le retour OAuth sans modifier le fonctionnement de onAuthStateChanged.
getRedirectResult(auth).catch(err => {
  console.error("[google redirect]", err);
  const msg = friendlyAuthError(err);
  lyrV60SetLoginError(msg);
  toast(msg);
});

async function handleLoginSubmit(e) {
  e.preventDefault();
  lyrV60SetLoginError();
  if (state.loginMethod === "phone") {
    if (!state.loginPhoneConfirmationResult) {
      const msg=t("phone_code_first");
      toast(msg);
      setStatusLine("login-phone-status",msg,"error");
    }
    return;
  }
  const form     = e.target;
  const email    = ($("#login-email")?.value || "").trim().toLowerCase();
  const password = $("#login-password")?.value || "";
  const btn      = form.querySelector('button[type="submit"]');
  if (!email || !password) {
    const msg=t("err_required");
    lyrV60SetLoginError(msg);toast(msg);return;
  }

  setBusy(btn, true, "...");
  try {
    const credential = await signInWithEmailAndPassword(auth, email, password);
    revealAuthenticatedShell(credential.user);
    await transitionToAuthenticatedApp(credential.user);
    toast(t("msg_login_success"));
    form.reset();
    lyrV60SetLoginError();
  } catch (err) {
    console.error("[login]", err);
    const msg=friendlyAuthError(err);
    lyrV60SetLoginError(msg);
    toast(msg);
    // Ne jamais effacer l'adresse/mot de passe ou revenir à l'écran initial.
  } finally {
    setBusy(btn, false);
  }
}

async function handleForgotSubmit(e) {
  e.preventDefault();
  const form  = e.target;
  const email = ($("#forgot-email")?.value || "").trim().toLowerCase();
  const btn   = form.querySelector('button[type="submit"]');
  if (!email) { toast(t("err_required")); return; }

  setBusy(btn, true, "...");
  try {
    await sendPasswordResetEmail(auth, email);
    toast(t("msg_reset_sent"));
    form.reset();
  } catch (err) {
    console.error("[forgot]", err);
    toast(friendlyAuthError(err));
  } finally {
    setBusy(btn, false);
  }
}

/* ------------------------------------------------------------
   22. ÉTAT TEMPORAIRE
   ------------------------------------------------------------ */
function resetCommentComposer() {
  revokeUrl(state.commentImagePreviewUrl);
  state.commentImageFile = null;
  state.commentImagePreviewUrl = "";
  state.commentMediaKind = "image";
  state.commentReplyTo = null;
  state.commentMentionSelections?.clear?.();
  const input = $("#comment-image-input");
  if (input) input.value = "";
  renderCommentImagePreview();
  hideCommentMentionSuggestions();
  const ta = $("#comment-text");
  if (ta) {
    ta.value = "";
    ta.placeholder = uiText("Écrivez un commentaire…", "Soraty ny hevitrao…", "Write a comment…");
    ta.style.height = "38px";
    ta.classList.remove("is-scrollable");
  }
  renderReplyIndicator();
  updateCommentSubmitState();
}

function resetProfileEditTemp() {
  revokeUrl(state.profileAvatarPreviewUrl);
  revokeUrl(state.profileCoverPreviewUrl);
  state.profileAvatarFile = null;
  state.profileCoverFile = null;
  state.profileAvatarPreviewUrl = "";
  state.profileCoverPreviewUrl = "";
  state.profileAvatarRemove = false;
  state.profileCoverRemove = false;
  state.profileAvatarSelectedHistory = null;
  state.profileCoverSelectedHistory = null;
  const ai = $("#edit-avatar-input"); if (ai) ai.value = "";
  const ci = $("#edit-cover-input");  if (ci) ci.value = "";
}

function resetGroupEditTemp() {
  revokeUrl(state.groupEditPreviewUrl);
  state.groupEditFile = null;
  state.groupEditPreviewUrl = "";
  const gi = $("#group-edit-cover-input"); if (gi) gi.value = "";
}

function resetCreateGroupState() {
  revokeUrl(state.groupCoverPreviewUrl);
  state.groupCoverFile = null;
  state.groupCoverPreviewUrl = "";
  state.groupSelected = new Map();
  state.groupCandidates = [];
  const photo = $("#create-group-photo"); if (photo) photo.value = "";
  const name = $("#create-group-name"); if (name) name.value = "";
  const desc = $("#create-group-description"); if (desc) desc.value = "";
  const search = $("#create-group-member-search"); if (search) search.value = "";
  renderGroupCoverPreview();
  renderSelectedMemberChips();
}

function clearTemporaryState() {
  if (state.selectedPostMedia) revokeUrl(state.selectedPostMedia.url);
  state.selectedPostMedia = null;
  state.postFormat = defaultFormatting();
  revokeUrl(state.commentImagePreviewUrl);
  state.commentImageFile = null;
  state.commentImagePreviewUrl = "";
  state.commentMediaKind = "image";
  state.commentReplyTo = null;
  resetProfileEditTemp();
  revokeUrl(state.groupCoverPreviewUrl);
  state.groupCoverFile = null;
  state.groupCoverPreviewUrl = "";
  resetGroupEditTemp();
  state.groupSelected = new Map();
  state.groupCandidates = [];
  state.activeReactionPostId = null;
  state.friendshipStatus = "none";
  state.friendIds = new Set();
  state.friendsLoaded = false;
  state.incomingRequests = [];
  state.outgoingRequests = [];
  reactionCache.clear();
}

/* ------------------------------------------------------------
   23. AUTH — DÉCONNEXION
   ------------------------------------------------------------ */
async function handleLogout() {
  try {
    toast(t("msg_logout"));
    /* best-effort : hors-ligne avant de couper la session */
    if (state.presenceStarted) {
      await Promise.race([
        writePresence(false),
        new Promise(r => setTimeout(r, 1500))
      ]);
    }
    await cleanupCall();
    await unregisterLyramePushForCurrentDevice().catch(err => console.warn("[push logout cleanup]", err));
    clearListeners();
    stopPresence();
    clearTemporaryState();
    await signOut(auth);
    showAuthPanel("login"); // Seule la déconnexion voulue remet le formulaire initial.
  } catch (err) {
    console.error("[logout]", err);
    toast(friendlyAuthError(err));
  }
}

/* ------------------------------------------------------------
   24. AUTH — ÉTAT
   ------------------------------------------------------------ */
function revealAuthenticatedShell(user) {
  if (!user) return false;
  state.currentUser = user;
  if (!Array.isArray(state.screenStack) || state.screenStack.length === 0) {
    state.screenStack = ["home"];
  }
  const authScreen = $("#auth-screen");
  const appShell = $("#app-shell");
  authScreen?.classList.add("hidden");
  if (authScreen) authScreen.hidden = true;
  appShell?.classList.remove("hidden");
  if (appShell) appShell.hidden = false;
  showScreen("home", { push: false });
  return !!appShell;
}

async function transitionToAuthenticatedApp(user) {
  if (!user) return;

  // IMPORTANT: l'interface s'ouvre AVANT tout listener Firestore.
  // Ainsi une erreur de listener ou une course avec onAuthStateChanged ne peut
  // plus laisser l'utilisateur bloqué sur l'écran de connexion après succès.
  revealAuthenticatedShell(user);

  if (state.authTransitioning) return;
  state.authTransitioning = true;
  try {
    clearListeners();
    stopPresence();
    profileCache.clear();
    profilePending.clear();
    state.currentUser = user;
    state.currentProfile = null;
    state.profileExists = false;
    state.screenStack = ["home"];
    revealAuthenticatedShell(user);
    startProfileListener(user.uid);
    startFeedListener();
    startConversationsListener();
    startNotificationsListener();
    startFriendsListeners();
    startIncomingCallsListener(user.uid);
    void assistantSyncFromCloud({force:true});
  } catch (err) {
    console.error("[post-auth transition]", err);
    revealAuthenticatedShell(user);
  } finally {
    state.authTransitioning = false;
  }
}

function handleAuthState(user) {
  if (user && (state.phoneRegistrationPending || state.phoneLoginPending || state.registering)) {
    state.currentUser = user;
    return;
  }
  if (user) {
    revealAuthenticatedShell(user);
    transitionToAuthenticatedApp(user);
    return;
  }

  // Ignore un ancien événement null si Firebase possède déjà une session active.
  if (auth.currentUser) {
    revealAuthenticatedShell(auth.currentUser);
    transitionToAuthenticatedApp(auth.currentUser);
    return;
  }

  clearListeners();
  stopPresence();
  profileCache.clear();
  profilePending.clear();
  state.currentUser = null;
  assistantCloudSyncedUid = "";
  assistantCloudSyncPromise = null;
  assistantMemoryChats = [];
  assistantMemoryActiveChatId = "";
  state.currentProfile = null;
  founderBadgeAttemptedUid = "";
  state.profileExists = false;
  state.profileViewUid = null;
  state.activePostId = null;
  state.activeConvId = null;
  state.activeConv = null;
  state.screenStack = [];
  clearTemporaryState();
  const appShell = $("#app-shell");
  const authScreen = $("#auth-screen");
  appShell?.classList.add("hidden");
  if (appShell) appShell.hidden = true;
  authScreen?.classList.remove("hidden");
  if (authScreen) authScreen.hidden = false;
  // IMPORTANT V60 : un événement Firebase « utilisateur null » ne doit
  // JAMAIS refermer Inscription/Oubli de mot de passe ou l'onglet Téléphone.
  // L'ancienne version revenait toujours à Connexion ici, même pendant
  // une action de l'utilisateur ou une reprise depuis l'arrière-plan.
  if (!$(".auth-panel.active")) showAuthPanel("login");
  else lyrameAndroidRememberScreen("auth:" + $(".auth-panel.active").dataset.screen, false);
}

function consumeDeepLink() {
  try {
    const params = new URLSearchParams(location.search);
    const conversationId = params.get("conversation");
    const postId = params.get("post");
    const screen = params.get("screen");
    if (!conversationId && !postId && !screen) return;
    // Retirer les paramètres du deep-link tout en préservant l’entrée écran Android.
    history.replaceState(history.state, "", location.pathname);
    if (conversationId) {
      openConversation(conversationId);
      return;
    }
    if (postId) {
      openPostDetail(postId);
      return;
    }
    if (screen === "notifications") showScreen("notifications");
  } catch (e) { /* noop */ }
}

/* ------------------------------------------------------------
   25. PROFIL — LISTENER + RENDU
   ------------------------------------------------------------ */
let deepLinkDone = false;

function startProfileListener(uid) {
  if (listeners.profile) { listeners.profile(); listeners.profile = null; }
  const userRef = doc(db, "users", uid);

  listeners.profile = onSnapshot(userRef, async snap => {
    if (!snap.exists()) {
      state.profileExists = false;
      const fallback = buildFallbackProfile(state.currentUser || { uid });
      state.currentProfile = { ...fallback, createdAt: null, updatedAt: null };
      hydrateAccountUiPreferences(state.currentProfile);
      renderMyProfile();
      if (typeof Notification !== "undefined" && Notification.permission === "granted") {
        void syncLyramePushRegistration({ requestPermission: false });
      }

      if (!snap.metadata.fromCache && !state.registering && state.profileRepairUid !== uid) {
        state.profileRepairUid = uid;
        try {
          await setDoc(userRef, fallback, { merge: true });
        } catch (err) {
          logError("[profile repair]", err);
        }
      }
      if (state.myPostsUid !== uid) startMyPostsListener(uid);
      return;
    }

    state.profileExists = true;
    state.currentProfile = { uid, ...snap.data() };
    hydrateAccountUiPreferences(state.currentProfile);
    renderMyProfile();
    ensureFounderBadgeForCurrentUser();
    startPresence();
    if (state.currentProfile?.notificationsEnabled !== false && typeof Notification !== "undefined" && Notification.permission === "granted") {
      void syncLyramePushRegistration({ requestPermission: false });
    }

    if (state.myPostsUid !== uid) startMyPostsListener(uid);
    if (!deepLinkDone) { deepLinkDone = true; consumeDeepLink(); }
  }, err => logError("[profile listener]", err));
}

function formatBirthdate(str) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(str || "");
  if (!m) return "";
  const d = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
  if (isNaN(d.getTime())) return "";
  try {
    return d.toLocaleDateString(state.lang === "mg" ? "fr" : state.lang, { day: "numeric", month: "long", year: "numeric" });
  } catch (e) {
    return d.toLocaleDateString();
  }
}

async function canViewBirthdate(profile, ownerUid, viewerUid) {
  if (!profile || !profile.birthdate) return false;
  if (ownerUid === viewerUid) return true;
  const priv = profile.birthdatePrivacy || "private";
  if (priv === "public") return true;
  if (priv === "friends") return areFriends(viewerUid, ownerUid);
  return false;
}

function renderMyProfile() {
  const p = state.currentProfile;
  if (!p) return;

  setNameWithBadge("profile-me-name", p.fullname || "", p);
  setText("profile-me-username", p.username ? "@" + p.username : "");
  setText("profile-me-bio", p.bio || "");
  setText("profile-me-posts", String(p.postsCount || 0));
  setText("profile-me-followers", String(p.followersCount || 0));
  setText("profile-me-following", String(p.followingCount || 0));
  setText("profile-me-presence", formatPresence({ ...p, isOnline: true, lastSeen: null }));
  setText("profile-me-birthdate", p.birthdate ? "🎂 " + formatBirthdate(p.birthdate) : "");

  const avatar = $("#profile-me-avatar");
  const avatarURL = p.photoURL || state.currentUser?.photoURL || "";
  if (avatar) avatar.innerHTML = avatarMarkup(avatarURL, p.fullname || state.currentUser?.displayName || "");

  const cover = $("#profile-me-cover");
  if (cover) {
    const safeCover = safeUrl(p.coverURL);
    cover.style.backgroundImage = safeCover ? `url("${safeCover}")` : "";
  }

  const fillIfIdle = (id, val) => {
    const el = document.getElementById(id);
    if (el && document.activeElement !== el && currentScreenName() !== "edit-profile") el.value = val;
  };
  fillIfIdle("edit-fullname", p.fullname || "");
  fillIfIdle("edit-username", p.username || "");
  fillIfIdle("edit-bio", p.bio || "");
}

/* ------------------------------------------------------------
   26. PUBLICATIONS — CONFIDENTIALITÉ
   ------------------------------------------------------------ */
async function canViewPost(post, viewerUid) {
  if (!post || !viewerUid) return false;
  if (post.authorId === viewerUid) return true;
  const raw = post.privacy;
  const privacy = raw === undefined || raw === null || raw === "" ? "public" : raw;
  if (privacy === "public") return true;
  if (privacy === "friends") return areFriends(viewerUid, post.authorId);
  return false;
}

async function renderPostsInto(container, posts, emptyId, tokenKey) {
  if (!container) return;
  const token = ++listTokens[tokenKey];
  const me = state.currentUser?.uid;
  const flags = await Promise.all(posts.map(p => canViewPost(p, me).catch(() => false)));
  if (token !== listTokens[tokenKey]) return;

  const visible = posts.filter((_, i) => flags[i]);

  container
    .querySelectorAll(".post-card, .profile-about-panel")
    .forEach(n => n.remove());

  if (!visible.length) { toggleEmpty(emptyId, false); return; }
  toggleEmpty(emptyId, true);
  const frag = document.createDocumentFragment();
  visible.forEach(p => frag.appendChild(renderPostCard(p)));
  container.appendChild(frag);
}

async function loadProfileGallery(uid) {
  if (!uid) {
    return [];
  }

  try {
    const snap = await getDocs(
      query(
        collection(db, "users", uid, "photos"),
        orderBy("createdAt", "desc"),
        limit(100)
      )
    );

    return snap.docs.map(d => ({
      id: d.id,
      ...d.data()
    }));
  } catch (err) {
    console.warn("[profile gallery]", err);
    return [];
  }
}

async function renderProfilePhotoGallery(kind, container, emptyId) {
  const mine = kind === "me";

  const uid = mine
    ? state.currentUser?.uid
    : state.profileViewUid;

  if (!uid) {
    return;
  }

  container
    .querySelectorAll(".post-card, .profile-about-panel, .profile-photo-gallery")
    .forEach(node => node.remove());

  const photos = await loadProfileGallery(uid);

  state.profileGalleryPhotos = photos;

  const galleryPhotos = photos.filter(photo => photo.category !== "profile-media");
  const visible = [];

  for (const photo of galleryPhotos) {
    if (mine) {
      visible.push(photo);
      continue;
    }

    const privacy = privacyOf(photo.privacy, "public");

    if (privacy === "public") {
      visible.push(photo);
      continue;
    }

    if (privacy === "friends" && state.friendIds?.has(uid)) {
      visible.push(photo);
    }
  }

  const gallery = document.createElement("div");
  gallery.className = "profile-photo-gallery";

  if (mine) {
    const add = document.createElement("button");
    add.type = "button";
    add.className = "profile-photo-add";
    add.textContent = "+";
    add.setAttribute("aria-label", t("add_photo"));

    add.addEventListener("click", () => {
      const input = document.createElement("input");
      input.type = "file";
      input.accept = "image/*";

      input.addEventListener("change", async () => {
        const file = input.files?.[0];
        if (!file) {
          return;
        }
        await addProfileGalleryPhoto(file);
      });

      input.click();
    });

    gallery.appendChild(add);
  }

  visible.forEach(photo => {
    const url = safeUrl(photo.url);
    if (!url) {
      return;
    }

    const item = document.createElement("div");
    item.className = "profile-photo-item";

    const img = document.createElement("img");
    img.src = url;
    img.alt = "";

    item.appendChild(img);
    gallery.appendChild(item);
  });

  container.appendChild(gallery);

  toggleEmpty(emptyId, gallery.children.length > 0);
}

async function saveProfileMediaHistory(uid, kind, url, publicId, file, extra = {}) {
  if (!uid || !url) return;
  try {
    await addDoc(collection(db, "users", uid, "photos"), {
      ownerId: uid,
      category: "profile-media",
      kind,
      url,
      publicId: publicId || "",
      privacy: "private",
      fileName: file?.name || "",
      fullname: extra.fullname || "",
      username: extra.username || "",
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });
  } catch (err) {
    console.warn("[save profile media history]", err);
  }
}

async function getProfileMediaHistoryEntries(uid, kind) {
  const entries = (await loadProfileGallery(uid))
    .filter(item => item && item.category === "profile-media" && item.kind === kind && safeUrl(item.url))
    .map(item => ({
      id: item.id,
      url: safeUrl(item.url),
      publicId: item.publicId || "",
      createdAt: item.createdAt || null,
      source: "history"
    }));

  const currentUrl = safeUrl(kind === "avatar" ? (state.currentProfile?.photoURL || state.currentUser?.photoURL || "") : (state.currentProfile?.coverURL || ""));
  const currentPublicId = kind === "avatar" ? (state.currentProfile?.avatarPublicId || "") : (state.currentProfile?.coverPublicId || "");

  if (currentUrl && !entries.some(item => item.url === currentUrl)) {
    entries.unshift({
      id: `current-${kind}`,
      url: currentUrl,
      publicId: currentPublicId,
      createdAt: null,
      source: "current"
    });
  }

  return entries;
}

function applyProfileMediaSelection(kind, entry) {
  if (!entry || !entry.url) return;

  if (kind === "avatar") {
    revokeUrl(state.profileAvatarPreviewUrl);
    state.profileAvatarFile = null;
    state.profileAvatarPreviewUrl = "";
    state.profileAvatarRemove = false;
    state.profileAvatarSelectedHistory = { url: entry.url, publicId: entry.publicId || "" };
    const input = $("#edit-avatar-input");
    if (input) input.value = "";
    setPreviewElement($("#edit-avatar-preview"), entry.url, state.currentProfile?.fullname || "");
  } else {
    revokeUrl(state.profileCoverPreviewUrl);
    state.profileCoverFile = null;
    state.profileCoverPreviewUrl = "";
    state.profileCoverRemove = false;
    state.profileCoverSelectedHistory = { url: entry.url, publicId: entry.publicId || "" };
    const input = $("#edit-cover-input");
    if (input) input.value = "";
    setPreviewElement($("#edit-cover-preview"), entry.url, "");
  }
}

async function openProfileMediaHistory(kind) {
  const uid = state.currentUser?.uid;
  if (!uid) return;

  const entries = await getProfileMediaHistoryEntries(uid, kind);
  if (!entries.length) {
    toast(kind === "cover" ? "Tsy mbola misy couverture voatahiry." : "Tsy mbola misy photo de profil voatahiry.");
    return;
  }

  const modal = openDynamicModal(kind === "cover" ? uiText("Couvertures enregistrées", "Sary fonony voatahiry", "Saved covers") : uiText("Photos de profil enregistrées", "Sarin’ny profil voatahiry", "Saved profile photos"));
  Object.assign(modal.body.style, { display: "grid", gap: "12px" });

  const hint = document.createElement("p");
  hint.textContent = kind === "cover"
    ? "Safidio ny couverture tianao haverina, na ampiasao ny bouton appareil photo hanampiana sary vaovao."
    : "Tsindrio ny sary profil tianao haverina. Ny sary profil mihitsy no misokatra eto fa tsy bouton trois points.";
  Object.assign(hint.style, { margin: "0", fontSize: "13px", color: modalColors().muted });
  modal.body.appendChild(hint);

  const grid = document.createElement("div");
  Object.assign(grid.style, {
    display: "grid",
    gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
    gap: "12px"
  });

  entries.forEach(entry => {
    const card = document.createElement("button");
    card.type = "button";
    Object.assign(card.style, {
      display: "grid",
      gap: "8px",
      padding: "8px",
      borderRadius: "14px",
      border: "1px solid " + modalColors().border,
      background: modalColors().field,
      cursor: "pointer"
    });

    const frame = document.createElement("div");
    Object.assign(frame.style, {
      width: "100%",
      aspectRatio: kind === "cover" ? "16 / 9" : "1 / 1",
      overflow: "hidden",
      borderRadius: kind === "cover" ? "12px" : "50%",
      background: modalColors().bg
    });

    const img = document.createElement("img");
    img.src = entry.url;
    img.alt = "";
    Object.assign(img.style, { width: "100%", height: "100%", objectFit: "cover" });
    frame.appendChild(img);

    const label = document.createElement("span");
    label.textContent = entry.source === "current" ? uiText("Image actuelle", "Sary ampiasaina izao", "Current image") : uiText("Réutiliser", "Hampiasa indray", "Reuse");
    Object.assign(label.style, { fontSize: "13px", fontWeight: "600", color: modalColors().fg });

    card.append(frame, label);
    card.addEventListener("click", () => {
      applyProfileMediaSelection(kind, entry);
      modal.close();
      toast(kind === "cover" ? uiText("Couverture sélectionnée.", "Voafidy ny sary fonony.", "Cover selected.") : uiText("Photo de profil sélectionnée.", "Voafidy ny sarin’ny profil.", "Profile photo selected."));
    });

    grid.appendChild(card);
  });

  modal.body.appendChild(grid);
}

async function addProfileGalleryPhoto(file) {
  if (!state.currentUser || !file) {
    return;
  }

  const check = await validateMedia(file, "image");

  if (!check.ok) {
    toast(check.msg);
    return false;
  }

  try {
    const up = await uploadMedia(file, {
      folder: `lyrame/users/${state.currentUser.uid}/gallery`,
      resourceType: "image"
    });

    await addDoc(collection(db, "users", state.currentUser.uid, "photos"), {
      ownerId: state.currentUser.uid,
      url: up.url,
      publicId: up.publicId,
      privacy: "public",
      createdAt: serverTimestamp()
    });

    await renderProfileTab("me");
  } catch (err) {
    logError("[gallery upload]", err);
    toast(t("err_image_upload"));
  }
}

async function renderProfileTab(kind) {
  const mine = kind === "me";

  const container = mine
    ? $("#profile-me-content")
    : $("#profile-other-content");

  if (!container) return;

  const emptyId = mine
    ? "profile-me-empty"
    : "profile-other-empty";

  const tokenKey = mine
    ? "myPosts"
    : "otherPosts";

  const tab = mine
    ? (state.profileMeTab || "posts")
    : (state.profileOtherTab || "posts");

  const posts = mine
    ? (state.myProfilePosts || [])
    : (state.otherProfilePosts || []);

  container
    .querySelectorAll(".profile-about-panel")
    .forEach(n => n.remove());

  if (tab === "about") {
    container
      .querySelectorAll(".post-card, .profile-photo-gallery")
      .forEach(n => n.remove());

    toggleEmpty(emptyId, true);

    const profile = mine
      ? state.currentProfile
      : (
          state.profileViewUid
            ? await getUserProfile(state.profileViewUid).catch(() => null)
            : null
        );

    const panel = document.createElement("div");
    panel.className = "profile-about-panel";

    const title = document.createElement("h3");
    title.textContent = uiText("À propos", "Momba", "About");

    const name = document.createElement("p");
    name.textContent = profile?.fullname || "";

    const username = document.createElement("p");
    username.className = "muted";
    username.textContent = profile?.username ? `@${profile.username}` : "";

    const bio = document.createElement("p");
    bio.textContent = profile?.bio || "";

    panel.append(title);

    if (name.textContent) panel.append(name);
    if (username.textContent) panel.append(username);

    if (bio.textContent) {
      panel.append(bio);
    } else {
      const emptyBio = document.createElement("p");
      emptyBio.className = "muted";
      emptyBio.textContent = uiText("Aucune biographie.", "Tsy misy mombamomba.", "No bio.");
      panel.append(emptyBio);
    }

    const birthId = mine
      ? "profile-me-birthdate"
      : "profile-other-birthdate";

    const birthText = document.getElementById(birthId)?.textContent?.trim() || "";

    if (birthText) {
      const birth = document.createElement("p");
      birth.textContent = birthText;
      panel.append(birth);
    }

    container.appendChild(panel);
    return;
  }

  let filtered = posts;

  if (tab === "photos") {
    await renderProfilePhotoGallery(kind, container, emptyId);
    return;
  }

  if (tab === "videos") {
    filtered = posts.filter(p => p.mediaURL && p.mediaType === "video");
  }

  await renderPostsInto(container, filtered, emptyId, tokenKey);
}

function startMyPostsListener(uid) {
  if (listeners.myPosts) {
    listeners.myPosts();
    listeners.myPosts = null;
  }

  state.myPostsUid = uid;

  const q = query(
    collection(db, "posts"),
    where("authorId", "==", uid),
    limit(POSTS_LIMIT)
  );

  listeners.myPosts = onSnapshot(
    q,
    snap => {
      state.myProfilePosts = sortPostsNewestFirst(
        snap.docs.map(d => ({
          id: d.id,
          ...d.data()
        }))
      );

      renderProfileTab("me");
    },
    err => logError("[my posts]", err)
  );
}

/* ============================================================
   V96 — publication feed: For You / Recent / Trending.
   No Firestore writes, ranking limited to the latest 60 fetched posts.
   Existing privacy filter stays in renderPostsInto().
   ============================================================ */
const lyrameV96Modes = ["forYou", "recent", "trending"];
const lyrameV96StoreKey = "lyrame-feed-sort-v96";
function lyrameV96SavedMode() {
  try {
    const v = window.localStorage.getItem(lyrameV96StoreKey);
    return lyrameV96Modes.includes(v) ? v : "forYou";
  } catch (_) { return "forYou"; }
}
const lyrameV96Feed = {
  mode: lyrameV96SavedMode(),
  posts: [],
  follows: new Set(),
  userUid: "",
  followLoadId: 0,
  bound: false
};

function lyrameV96PostTime(post) {
  const t = post?.createdAt;
  if (!t) return 0;
  if (typeof t.toMillis === "function") return Number(t.toMillis()) || 0;
  if (typeof t.seconds === "number") return t.seconds * 1000;
  if (typeof t.getTime === "function") return t.getTime();
  return 0;
}
function lyrameV96SafeCount(value) {
  const n = Number(value);
  return Number.isFinite(n) ? Math.max(0, Math.min(1000000, n)) : 0;
}
function lyrameV96Popularity(post) {
  // logarithmic scores stop a single very popular post from dominating forever
  const reactions = lyrameV96SafeCount(post.reactionsCount ?? post.likesCount);
  const comments = lyrameV96SafeCount(post.commentsCount);
  const views = lyrameV96SafeCount(post.viewsCount);
  return 1.5 * Math.log1p(reactions) + 2.2 * Math.log1p(comments) + 0.2 * Math.log1p(views);
}
function lyrameV96Freshness(post, now) {
  const ms = lyrameV96PostTime(post);
  if (!ms) return 0;
  const ageHours = Math.max(0, (now - ms) / 3600000);
  return 5 * Math.exp(-ageHours / 72);
}
function lyrameV96Sort(posts, mode = lyrameV96Feed.mode) {
  const now = Date.now();
  const myId = state.currentUser?.uid;
  const friends = state.friendIds instanceof Set ? state.friendIds : new Set(state.friendIds || []);
  const follows = lyrameV96Feed.follows;
  const scored = posts.map((post, i) => {
    let score = 0;
    if (mode === "trending") score = 2 * lyrameV96Popularity(post) + lyrameV96Freshness(post, now);
    if (mode === "forYou") {
      score = lyrameV96Popularity(post) + 1.5 * lyrameV96Freshness(post, now);
      if (friends.has(post.authorId)) score += 7;
      else if (follows.has(post.authorId)) score += 5;
      else if (post.authorId === myId) score += 1;
    }
    return { post, i, score, time: lyrameV96PostTime(post) };
  });
  scored.sort((a, b) => {
    if (mode !== "recent" && b.score !== a.score) return b.score - a.score;
    return b.time - a.time || a.i - b.i;
  });
  return scored.map(row => row.post);
}
function lyrameV96UpdateButtons() {
  const names = {
    forYou: uiText("✨ Pour toi", "✨ Ho anao", "✨ For you"),
    recent: uiText("🕒 Récent", "🕒 Vaovao farany", "🕒 Recent"),
    trending: uiText("🔥 Tendances", "🔥 Malaza", "🔥 Trending")
  };
  document.querySelectorAll("[data-lyr-v96-feed-mode]").forEach(btn => {
    const mode = btn.dataset.lyrV96FeedMode;
    btn.textContent = names[mode] || mode;
    const active = mode === lyrameV96Feed.mode;
    btn.classList.toggle("active", active);
    btn.setAttribute("aria-pressed", active ? "true" : "false");
  });
}
function lyrameV96RenderFeed() {
  lyrameV96UpdateButtons();
  let posts = lyrameV96Feed.posts.slice();
  if (state.activeCategory && state.activeCategory !== "pour-vous") {
    posts = posts.filter(p => p.category === state.activeCategory);
  }
  return renderPostsInto($("#feed-list"), lyrameV96Sort(posts), "feed-empty", "feed");
}
function lyrameV96BindModes() {
  if (lyrameV96Feed.bound) return;
  const nav = document.getElementById("lyr-v96-feed-nav");
  if (!nav) return;
  lyrameV96Feed.bound = true;
  nav.addEventListener("click", e => {
    const btn = e.target.closest("[data-lyr-v96-feed-mode]");
    if (!btn || !nav.contains(btn)) return;
    const next = btn.dataset.lyrV96FeedMode;
    if (!lyrameV96Modes.includes(next)) return;
    lyrameV96Feed.mode = next;
    try { window.localStorage.setItem(lyrameV96StoreKey, next); } catch (_) {}
    void lyrameV96RenderFeed();
  });
}
function lyrameV96LoadFollows(uid) {
  const request = ++lyrameV96Feed.followLoadId;
  lyrameV96Feed.follows = new Set();
  if (!uid) return;
  getDocs(query(collection(db, "users", uid, "following"), limit(200))).then(snap => {
    if (request !== lyrameV96Feed.followLoadId || state.currentUser?.uid !== uid) return;
    lyrameV96Feed.follows = new Set(snap.docs.map(d => d.id));
    if (lyrameV96Feed.mode === "forYou") void lyrameV96RenderFeed();
  }).catch(err => {
    // Access could be limited by Firestore rules; use friends + recent posts safely.
    console.info("[V96 follows] classement basé sur amis + récence", err?.code || "");
  });
}
let feedLoadingTimeout = null;
function startFeedListener() {
  if (listeners.feed) { listeners.feed(); listeners.feed = null; }
  clearTimeout(feedLoadingTimeout);
  lyrameV96BindModes();
  lyrameV96UpdateButtons();
  const uid = state.currentUser?.uid || "";
  if (lyrameV96Feed.userUid !== uid) {
    lyrameV96Feed.userUid = uid;
    lyrameV96Feed.posts = [];
    lyrameV96LoadFollows(uid);
  }
  // Sort from a bounded set of recent posts. No new index or Firestore write needed.
  const q = query(collection(db, "posts"), orderBy("createdAt", "desc"), limit(60));
  toggleEmpty("feed-empty", true);
  const loading = $("#feed-loading");
  showEl(loading);
  feedLoadingTimeout = setTimeout(() => hideEl(loading), 10000);
  listeners.feed = onSnapshot(q, snap => {
    clearTimeout(feedLoadingTimeout);
    hideEl(loading);
    lyrameV96Feed.posts = snap.docs.map(d => ({ id: d.id, ...d.data() }));
    void lyrameV96RenderFeed();
  }, err => {
    clearTimeout(feedLoadingTimeout);
    hideEl(loading);
    logError("[feed listener V96]", err);
  });
}

/* ------------------------------------------------------------
   27. RENDU D'UNE PUBLICATION
   ------------------------------------------------------------ */
function countLabel(n, one, many) {
  n = Number(n) || 0;
  if (n <= 0) return "";
  return `${n} ${n > 1 ? many : one}`;
}

function postReactionCountLabel(n) {
  return countLabel(
    n,
    uiText("réaction", "fihetseham-po", "reaction"),
    uiText("réactions", "fihetseham-po", "reactions")
  );
}

function postCommentCountLabel(n) {
  return countLabel(
    n,
    uiText("commentaire", "hevitra", "comment"),
    uiText("commentaires", "hevitra", "comments")
  );
}

function renderPostCard(post) {
  const el = document.createElement("article");
  el.className = "post-card";
  el.dataset.postId = post.id;

  const safeMedia = safeUrl(post.mediaURL);
  const mediaHtml = safeMedia
    ? `<div class="post-media">${
        post.mediaType === "video"
          ? `<video src="${escapeHtml(safeMedia)}" controls playsinline></video>`
          : `<img src="${escapeHtml(safeMedia)}" alt="" />`
      }</div>`
    : "";

  const isOwner = !!state.currentUser && post.authorId === state.currentUser.uid;
  const privacy = privacyOf(post.privacy);
  const myReaction = reactionCache.get(post.id) || "";
  const reactionObj = REACTIONS.find(r => r.type === myReaction);

  el.innerHTML = `
    <div class="post-head">
      <div class="avatar">${avatarMarkup(post.authorPhotoURL, post.authorName)}</div>
      <div class="post-author">
        <div class="post-author-name">${escapeHtml(post.authorName || "")}${identityBadgeMarkup({ badgeType: post.authorBadgeType })}</div>
        <div class="post-meta"></div>
      </div>
      ${isOwner ? `<div class="post-owner-menu">
        <button type="button" class="icon-btn sm" data-owner-menu aria-label="Options">
          <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="5" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="12" cy="19" r="1.5"/></svg>
        </button>
        <div class="owner-menu hidden">
          <button type="button" data-post-copy>${escapeHtml(state.lang === "mg" ? "Handika rohy" : state.lang === "en" ? "Copy link" : "Copier le lien")}</button>
          <button type="button" data-post-edit>${escapeHtml(state.lang === "mg" ? "Hanova" : state.lang === "en" ? "Edit" : "Modifier")}</button>
          <button type="button" data-post-delete>${escapeHtml(t("delete"))}</button>
        </div>
      </div>` : ""}
    </div>
    <div class="post-content"></div>
    ${mediaHtml}
    <div class="post-stats small muted">
      <span class="post-reaction-count">${escapeHtml(postReactionCountLabel(post.reactionsCount))}</span>
      <span class="post-comment-count">${escapeHtml(postCommentCountLabel(post.commentsCount))}</span>
      ${isOwner ? `<span class="post-view-count" data-post-views title="${escapeHtml(state.lang === "mg" ? "Mpijery" : state.lang === "en" ? "Views" : "Vues")}"><svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12Z"/><circle cx="12" cy="12" r="2.5"/></svg><span>0</span></span>` : ""}
    </div>
    <div class="post-actions">
      <button class="post-action${reactionObj ? " active" : ""}" data-act="react" type="button">${escapeHtml(reactionObj ? reactionObj.emoji + " " + reactionLabel(reactionObj.type) : (state.lang === "mg" ? "Fihetseham-po" : state.lang === "en" ? "React" : "Réaction"))}</button>
      <button class="post-action" data-act="comment" type="button">💬 ${escapeHtml(state.lang === "mg" ? "Hevitra" : state.lang === "en" ? "Comments" : "Commentaires")}</button>
      <button class="post-action" data-act="share" type="button">${escapeHtml(state.lang === "mg" ? "Hizara" : state.lang === "en" ? "Share" : "Partager")}</button>
    </div>
    <div class="feed-comment-preview" data-feed-comment-preview></div>
  `;

  const mediaBox =
    el.querySelector(".post-media");

  if (mediaBox && (post.mediaType === "image" || post.mediaType === "video")) {
    const allowedRatios = [
      "1:1",
      "4:5",
      "3:4",
      "16:9",
      "9:16"
    ];

    mediaBox.dataset.ratio =
      allowedRatios.includes(
        post.mediaType === "video" ? post.videoRatio : post.imageRatio
      )
        ? (post.mediaType === "video" ? post.videoRatio : post.imageRatio)
        : "original";
  }

  /* Contenu : titre + corps (texte brut + formatage structuré) */
  const content = el.querySelector(".post-content");
  if (post.title) {
    const h = document.createElement("h3");
    h.className = "post-title";
    h.textContent = post.title;
    content.appendChild(h);
  }
  if (post.background && content) {
    content.classList.add("post-background-content");
    content.dataset.ratio = post.background.ratio || "original";
    if (post.background.kind === "css") content.style.background = post.background.value || "";
    else if (safeUrl(post.background.url)) { content.style.backgroundImage = `url("${safeUrl(post.background.url)}")`; content.style.backgroundSize = "cover"; content.style.backgroundPosition = "center"; }
  }
  if (post.richTextHtml) {
    const body =
      document.createElement("div");

    body.className =
      "post-body";

    body.innerHTML =
      sanitizeRichHtml(
        post.richTextHtml
      );

    content.appendChild(body);
  } else if (post.text) {
    const body =
      document.createElement("div");

    body.className =
      "post-body";

    body.style.whiteSpace =
      "pre-wrap";

    body.style.wordBreak =
      "break-word";

    body.textContent =
      post.text;

    applyFormattingToElement(
      body,
      post.formatting
    );

    content.appendChild(body);
  }

  /* Méta : @username · temps (fallback profil si username manquant) */
  const metaEl = el.querySelector(".post-meta");
  const nameEl = el.querySelector(".post-author-name");
  const avEl = el.querySelector(".avatar");
  const timeText = formatTime(post.createdAt);
  const icon =
    PRIVACY_ICONS[privacy] || "";

  const writeMeta = username => {
    if (!metaEl) {
      return;
    }

    metaEl.innerHTML = "";

    if (username) {
      const usernameLine =
        document.createElement("div");

      usernameLine.className =
        "post-meta-username";

      usernameLine.textContent =
        "@" + username;

      metaEl.appendChild(
        usernameLine
      );
    }

    const details =
      document.createElement("div");

    details.className =
      "post-meta-details";

    if (timeText) {
      const time =
        document.createElement("span");

      time.textContent =
        timeText;

      details.appendChild(time);
    }

    if (post.category) {
      const category =
        document.createElement("span");

      category.textContent = categoryLabel(post.category);

      details.appendChild(category);
    }

    const flag = countryFlag(post.countryCode || post.locationCountryCode || "");
    if (flag) {
      const location = document.createElement("span");
      location.className = "post-location-flag";
      location.textContent = flag;
      details.appendChild(location);
    }

    if (icon) {
      const privacyIcon =
        document.createElement("span");

      privacyIcon.className =
        "post-privacy-icon";

      privacyIcon.innerHTML =
        icon;

      privacyIcon.setAttribute(
        "aria-label",
        privacy === "public"
          ? uiText("Public", "Ho an’ny rehetra", "Public")
          : privacy === "friends"
            ? uiText("Amis", "Namana", "Friends")
            : uiText("Privé", "Manokana", "Private")
      );

      details.appendChild(
        privacyIcon
      );
    }

    if (
      details.childNodes.length
    ) {
      metaEl.appendChild(
        details
      );
    }
  };
  writeMeta(post.authorUsername || "");
  if (post.authorId) {
    getUserProfile(post.authorId).then(p => {
      if (!p) return;
      writeMeta(post.authorUsername || p.username || "");
      if (nameEl) nameEl.innerHTML = `${escapeHtml(post.authorName || p.fullname || "")}${identityBadgeMarkup(p)}`;
      if (!post.authorPhotoURL && avEl) avEl.innerHTML = avatarMarkup(p.photoURL, p.fullname);
    }).catch(() => { /* noop */ });
  }

  /* Ma réaction (cache de session) */
  if (state.currentUser && !reactionCache.has(post.id)) {
    getDoc(doc(db, "posts", post.id, "reactions", state.currentUser.uid)).then(s => {
      const type = s.exists() ? (s.data().type || "") : "";
      reactionCache.set(post.id, type);
      if (type) updateReactionUI(post.id, type);
    }).catch(() => { reactionCache.set(post.id, ""); });
  }

  /* Interactions */
  const goProfile = e => {
    e.stopPropagation();
    if (post.authorId) openOtherProfile(post.authorId);
  };
  avEl?.addEventListener("click", goProfile);
  nameEl?.addEventListener("click", goProfile);

  el.addEventListener("click", e => {
    if (e.target.closest("button")) return;
    openPostDetail(post.id);
  });

  const ownerBtn = el.querySelector("[data-owner-menu]");
  const ownerMenu = el.querySelector(".owner-menu");
  if (ownerBtn && ownerMenu) {
    ownerBtn.addEventListener("click", e => {
      e.stopPropagation();
      const wasHidden = ownerMenu.classList.contains("hidden");
      closeOwnerMenus();
      if (wasHidden) showEl(ownerMenu);
    });
    ownerMenu.querySelector("[data-post-copy]")?.addEventListener("click", async e => {
      e.stopPropagation();
      hideEl(ownerMenu);
      await sharePost(post, { copyOnly: true });
    });
    ownerMenu.querySelector("[data-post-edit]")?.addEventListener("click", e => {
      e.stopPropagation();
      hideEl(ownerMenu);
      beginEditPost(post);
    });

    ownerMenu.querySelector("[data-post-delete]")?.addEventListener("click", async e => {
      e.stopPropagation();
      hideEl(ownerMenu);
      await deletePost(post);
    });
  }

  el.querySelectorAll(".post-action").forEach(a => {
    a.addEventListener("click", e => {
      e.stopPropagation();
      const act = a.dataset.act;
      if (act === "comment") {
        if (currentScreenName() === "post-detail" && state.activePostId === post.id) {
          state.commentsCollapsed = !state.commentsCollapsed;
          applyFullCommentsCollapse();
          updateCommentsToggle();
        } else {
          openPostDetail(post.id);
        }
      }
      else if (act === "react") {
        if (state.activeReactionPostId === post.id && isShown($("#reaction-picker"))) closeReactionPicker();
        else openReactionPicker(post.id, a);
      }
      else if (act === "share") sharePost(post);
    });
  });

  hydratePostViewCount(el, post);
  if (currentScreenName() !== "post-detail") hydrateFeedCommentPreview(el, post);
  return el;
}


async function hydrateFeedCommentPreview(card, post) {
  const host = card?.querySelector?.("[data-feed-comment-preview]");
  if (!host || !post?.id) return;
  host.innerHTML = "";

  let root = null;
  if (Number(post.commentsCount || 0) > 0) {
    try {
      const snap = await getDocs(query(
        collection(db, "posts", post.id, "comments"),
        orderBy("createdAt", "desc"),
        limit(16)
      ));
      root = snap.docs.map(d => ({ id: d.id, ...d.data() })).find(c => !c.parentId) || null;
    } catch (err) {
      console.warn("[feed comment preview]", err);
    }
  }

  if (root) {
    const row = document.createElement("button");
    row.type = "button";
    row.className = "feed-comment-one";
    // Conserver l'identité de l'auteur réellement affiché : V53 évite
    // une seconde requête asynchrone susceptible de lier le mauvais profil.
    if (!root.isAnonymous && root.authorId) row.dataset.lyrPreviewAuthorId = String(root.authorId);
    row.innerHTML = `
      <span class="feed-comment-avatar">${root.isAnonymous ? "?" : avatarMarkup(root.authorPhotoURL, root.authorName)}</span>
      <span class="feed-comment-bubble">
        <strong>${escapeHtml(root.isAnonymous ? uiText("Anonyme", "Tsy mitonona anarana", "Anonymous") : (root.authorName || ""))}${root.isAnonymous ? "" : identityBadgeMarkup({ badgeType: root.authorBadgeType })}</strong>
        <span>${root.deleted ? escapeHtml(uiText("Commentaire supprimé", "Hevitra voafafa", "Comment deleted")) : commentTextWithMentions(root.text || "", root.mentions || [])}</span>
      </span>
      <span class="feed-comment-meta">${escapeHtml(formatTime(root.createdAt))}</span>`;
    if (!root.isAnonymous && root.authorId) {
      getUserProfile(root.authorId).then(profile => {
        if (!profile) return;
        const strong = row.querySelector("strong");
        if (strong) strong.innerHTML = `${escapeHtml(root.authorName || profile.fullname || "")}${identityBadgeMarkup(profile)}`;
      }).catch(() => {});
    }
    row.addEventListener("click", e => { e.stopPropagation(); openPostDetail(post.id); });
    host.appendChild(row);
  }

  const composer = document.createElement("button");
  composer.type = "button";
  composer.className = "feed-comment-input";
  const me = state.currentProfile || {};
  composer.innerHTML = `
    <span class="feed-comment-avatar">${avatarMarkup(me.photoURL || state.currentUser?.photoURL || "", me.fullname || state.currentUser?.displayName || "")}</span>
    <span class="feed-comment-placeholder">${escapeHtml(uiText("Écrivez un commentaire…", "Soraty ny hevitrao…", "Write a comment…"))}</span>
    <span class="feed-comment-image" aria-hidden="true"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/></svg></span>`;
  composer.addEventListener("click", e => {
    e.stopPropagation();
    openPostDetail(post.id);
    setTimeout(() => $("#comment-text")?.focus(), 180);
  });
  host.appendChild(composer);
}

function cardsFor(postId) {
  return $$(".post-card").filter(c => c.dataset.postId === postId);
}

function updateReactionUI(postId, type, count) {
  const reaction = REACTIONS.find(r => r.type === type);
  cardsFor(postId).forEach(card => {
    const btn = card.querySelector('[data-act="react"]');
    if (btn) {
      btn.textContent = reaction ? `${reaction.emoji} ${reactionLabel(reaction.type)}` : (state.lang === "mg" ? "Fihetseham-po" : state.lang === "en" ? "React" : "Réaction");
      btn.classList.toggle("active", !!reaction);
    }
    if (typeof count === "number") {
      const c = card.querySelector(".post-reaction-count");
      if (c) c.textContent = postReactionCountLabel(count);
    }
  });
}

/* ------------------------------------------------------------
   28. PUBLICATION — SUPPRESSION
   ------------------------------------------------------------ */
async function bestEffortDeleteSubcollection(parts) {
  try {
    const snap = await getDocs(query(collection(db, ...parts), limit(400)));
    if (snap.empty) return;
    let batch = writeBatch(db);
    let n = 0;
    for (const d of snap.docs) {
      batch.delete(d.ref);
      n++;
      if (n % 400 === 0) { await batch.commit(); batch = writeBatch(db); }
    }
    if (n % 400 !== 0) await batch.commit();
  } catch (e) {
    console.warn("[cleanup]", parts.join("/"), e);
  }
}

async function cleanupPostChildrenBeforeDelete(postId) {
  try {
    const commentsSnap = await getDocs(query(collection(db, "posts", postId, "comments"), limit(400)));
    for (const c of commentsSnap.docs) {
      await bestEffortDeleteSubcollection(["posts", postId, "comments", c.id, "reactions"]);
    }
    await bestEffortDeleteSubcollection(["posts", postId, "comments"]);
    await bestEffortDeleteSubcollection(["posts", postId, "reactions"]);
    await bestEffortDeleteSubcollection(["posts", postId, "views"]);
  } catch (e) {
    console.warn("[post cleanup]", postId, e);
  }
}

async function deletePost(post) {
  if (!state.currentUser || post.authorId !== state.currentUser.uid) return;
  const ok = await showConfirm({
    title: t("confirm_delete_post_title"),
    message: t("confirm_delete_post"),
    confirmText: t("delete"),
    danger: true
  });
  if (!ok) return;

  try {
    const uid = state.currentUser.uid;
    const userRef = doc(db, "users", uid);
    await ensureUserDocument();

    /* Les sous-collections doivent être nettoyées tant que le parent existe,
       sinon les règles postOwner() ne peuvent plus autoriser le nettoyage. */
    await cleanupPostChildrenBeforeDelete(post.id);

    await runTransaction(db, async tx => {
      const uSnap = await tx.get(userRef);
      const cur = uSnap.exists() ? (uSnap.data().postsCount || 0) : 0;
      tx.delete(doc(db, "posts", post.id));
      tx.set(userRef, { postsCount: Math.max(0, cur - 1), updatedAt: serverTimestamp() }, { merge: true });
    });

    if (post.mediaPublicId) await safeDeleteMediaAsset(post.mediaPublicId);

    reactionCache.delete(post.id);
    toast(t("msg_post_deleted"));
    if (state.activePostId === post.id && currentScreenName() === "post-detail") goBack();
  } catch (err) {
    logError("[delete post]", err);
    toast(t("err_generic"));
  }
}

/* ------------------------------------------------------------
   29. RÉACTIONS
   ------------------------------------------------------------ */
async function toggleReaction(postId, type) {
  if (!state.currentUser || !REACTIONS.some(r => r.type === type)) return;
  const uid = state.currentUser.uid;
  const reactRef = doc(db, "posts", postId, "reactions", uid);
  const postRef  = doc(db, "posts", postId);

  try {
    const result = await runTransaction(db, async tx => {
      const reactSnap = await tx.get(reactRef);
      const postSnap  = await tx.get(postRef);
      if (!postSnap.exists()) throw new Error("POST_NOT_FOUND");

      const cur = Math.max(0, postSnap.data().reactionsCount || 0);
      const existed = reactSnap.exists();
      const sameType = existed && reactSnap.data().type === type;
      const authorId = postSnap.data().authorId || "";

      if (sameType) {
        tx.delete(reactRef);
        const next = Math.max(0, cur - 1);
        tx.update(postRef, { reactionsCount: next });
        return { state: "removed", authorId, count: next };
      }
      if (existed) {
        tx.update(reactRef, { type, updatedAt: serverTimestamp() });
        return { state: "changed", authorId, count: cur };
      }
      tx.set(reactRef, { userId: uid, type, createdAt: serverTimestamp(), updatedAt: serverTimestamp() });
      tx.update(postRef, { reactionsCount: cur + 1 });
      return { state: "added", authorId, count: cur + 1 };
    });

    const finalType = result.state === "removed" ? "" : type;
    reactionCache.set(postId, finalType);
    updateReactionUI(postId, finalType, result.count);

    if (result.state === "added" && result.authorId && result.authorId !== uid) {
      await createNotification({
        id: `reaction_${postId}_${uid}`,
        userId: result.authorId,
        actorId: uid,
        type: "reaction",
        title: uiText("Nouvelle réaction", "Fihetseham-po vaovao", "New reaction"),
        preview: `${state.currentProfile?.fullname || uiSomeone()} ${uiText("a réagi à votre publication.", "naneho fihetseham-po tamin’ny publication-nao.", "reacted to your post.")}`,
        extra: { postId }
      }).catch(err => console.warn("[reply notification]", err));
    }
  } catch (err) {
    logError("[reaction]", err);
    toast(t("err_generic"));
  }
}

/* ------------------------------------------------------------
   30. PARTAGE
   ------------------------------------------------------------ */
async function sharePost(post, { copyOnly = false } = {}) {
  const url = publicAppUrl(`?post=${encodeURIComponent(post.id)}`);
  try {
    if (!copyOnly && navigator.share) {
      await navigator.share({ title: "LYRAME", text: post.title || post.text || "", url });
    } else if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(url);
      toast(t("msg_link_copied"));
    } else {
      const ta = document.createElement("textarea");
      ta.value = url; ta.style.position = "fixed"; ta.style.opacity = "0";
      document.body.appendChild(ta); ta.select();
      const ok = document.execCommand("copy"); ta.remove();
      toast(ok ? t("msg_link_copied") : t("err_generic"));
    }
  } catch (e) { if (e?.name !== "AbortError") toast(t("err_generic")); }
}

function beginEditPost(post) {
  if (!state.currentUser || post.authorId !== state.currentUser.uid) return;
  const modal = openDynamicModal(state.lang === "mg" ? "Hanova publication" : state.lang === "en" ? "Edit post" : "Modifier la publication");
  const wrap = document.createElement("div");
  wrap.className = "post-edit-form";
  const title = document.createElement("input");
  title.type = "text"; title.maxLength = TITLE_MAX; title.value = post.title || "";
  title.placeholder = state.lang === "mg" ? "Lohateny" : state.lang === "en" ? "Title" : "Titre";
  const editor = document.createElement("div");
  editor.className = "post-edit-rich";
  editor.contentEditable = "true";
  editor.setAttribute("role", "textbox");
  editor.setAttribute("aria-multiline", "true");
  editor.innerHTML = post.richTextHtml ? sanitizeRichHtml(post.richTextHtml) : escapeHtml(post.text || "").replace(/\n/g,"<br>");
  const save = styledButton(t("save"), "primary");
  save.addEventListener("click", async () => {
    const nextTitle = title.value.trim().slice(0, TITLE_MAX);
    const nextHtml = sanitizeRichHtml(editor.innerHTML);
    const nextText = (editor.innerText || "").trim().slice(0, TEXT_MAX);
    if (!nextTitle && !nextText && !post.mediaURL && !post.background) { toast(t("err_empty_post")); return; }
    setBusy(save, true, "...");
    try {
      await updateDoc(doc(db, "posts", post.id), { title: nextTitle, text: nextText, richTextHtml: nextHtml, updatedAt: serverTimestamp() });
      modal.close();
      toast(state.lang === "mg" ? "Voavao ny publication." : state.lang === "en" ? "Post updated." : "Publication mise à jour.");
      if (state.activePostId === post.id) openPostDetail(post.id);
    } catch (err) { logError("[edit post]", err); toast(t("err_generic")); }
    finally { setBusy(save, false); }
  });
  wrap.append(title, editor, save);
  modal.body.appendChild(wrap);
}

async function registerPostView(post) {
  const uid = state.currentUser?.uid;
  if (!uid || !post?.id || post.authorId === uid) return;
  try {
    await setDoc(doc(db, "posts", post.id, "views", uid), { userId: uid, viewedAt: serverTimestamp() }, { merge: true });
  } catch (err) { console.warn("[post view]", err); }
}

async function hydratePostViewCount(card, post) {
  if (!card || !post?.id || post.authorId !== state.currentUser?.uid) return;
  const target = card.querySelector("[data-post-views]");
  if (!target) return;
  try {
    const snap = await getDocs(query(collection(db, "posts", post.id, "views"), limit(1000)));
    target.querySelector("span")?.replaceChildren(document.createTextNode(String(snap.size)));
  } catch (err) { console.warn("[post views count]", err); }
}

/* ------------------------------------------------------------
   31. PUBLICATION DÉTAILLÉE
   ------------------------------------------------------------ */
async function openPostDetail(postId) {
  if (!postId) return;
  state.activePostId = postId;
  /* Depuis le feed, le bouton Commentaires ouvre la liste complète. */
  state.commentsExpanded = true;
  state.commentsCollapsed = false;
  state.activePostAuthorId = "";
  if (listeners.comments) { listeners.comments(); listeners.comments = null; }
  resetCommentComposer();
  showScreen("post-detail");

  const box = $("#post-detail-content");
  const list = $("#comments-list");
  if (list) list.querySelectorAll(".comment").forEach(n => n.remove());
  toggleEmpty("comments-empty", true);
  if (box) box.innerHTML = `<div class="muted small pad">${escapeHtml(t("loading"))}</div>`;

  const showUnavailable = msg => {
    if (box) box.innerHTML = `<div class="empty-state"><p class="empty-title">${escapeHtml(msg)}</p></div>`;
  };

  try {
    const snap = await getDoc(doc(db, "posts", postId));
    if (state.activePostId !== postId) return;
    if (!snap.exists()) { showUnavailable(t("post_unavailable")); return; }

    const post = { id: snap.id, ...snap.data() };
    const allowed = await canViewPost(post, state.currentUser?.uid);
    if (state.activePostId !== postId) return;
    if (!allowed) { showUnavailable(t("post_unavailable")); return; }
    registerPostView(post);

    if (box) {
      box.innerHTML = "";
      box.appendChild(renderPostCard(post));
    }
    state.activePostAuthorId = post.authorId || "";
    startCommentsListener(postId);
    applyFullCommentsCollapse();
  } catch (err) {
    logError("[open post]", err);
    showUnavailable(t("post_unavailable"));
  }
}

/* ------------------------------------------------------------
   COMMENTAIRES — Emoji rapide + stickers contextuels
   ------------------------------------------------------------ */
let commentQuickSendBusy = false;

function normalizeContextText(value) {
  return String(value || "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9à-ÿ'’\s-]/gi, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function currentPostStickerContext() {
  const post = $("#post-detail-content");
  const raw = post?.innerText || post?.textContent || "";
  return String(raw).slice(0, 2500);
}

function rankCommentStickers(contextText) {
  const ctx = normalizeContextText(contextText);
  const toneScore = new Map();
  COMMENT_STICKERS.forEach(sticker => {
    let score = 0;
    (sticker.keywords || []).forEach(keyword => {
      const k = normalizeContextText(keyword);
      if (k && ctx.includes(k)) score += k.includes(" ") ? 5 : 3;
    });
    toneScore.set(sticker.id, score);
  });
  // Négations/émotions simples pour éviter de proposer un sticker joyeux sur un contexte triste.
  if (/triste|alahelo|mampalahelo|deces|mort|maty|pleure|marary|malade|accident/.test(ctx)) {
    COMMENT_STICKERS.filter(s => s.tone === "sad" || s.tone === "support" || s.tone === "prayer").forEach(s => toneScore.set(s.id, (toneScore.get(s.id)||0)+8));
    COMMENT_STICKERS.filter(s => s.tone === "joy" || s.tone === "celebrate").forEach(s => toneScore.set(s.id, (toneScore.get(s.id)||0)-5));
  }
  if (/haha|mdr|lol|mampihomehy|hehy|drole|funny/.test(ctx)) COMMENT_STICKERS.filter(s => s.tone === "joy").forEach(s => toneScore.set(s.id,(toneScore.get(s.id)||0)+8));
  if (/bravo|felicitation|arahabaina|anniversaire|fety|mariage|reussi|tafita|victoire/.test(ctx)) COMMENT_STICKERS.filter(s => s.tone === "celebrate").forEach(s => toneScore.set(s.id,(toneScore.get(s.id)||0)+8));
  if (/amour|fitiavana|tiako|adore|love|heart/.test(ctx)) COMMENT_STICKERS.filter(s => s.tone === "love").forEach(s => toneScore.set(s.id,(toneScore.get(s.id)||0)+8));
  if (/amen|andriamanitra|dieu|god|jesus|jesosy|vavaka|priere/.test(ctx)) COMMENT_STICKERS.filter(s => s.tone === "prayer").forEach(s => toneScore.set(s.id,(toneScore.get(s.id)||0)+8));
  if (/tsy ekeko|pas d'accord|disagree|tsy mety|inacceptable|diso|wrong|colere|tezitra/.test(ctx)) COMMENT_STICKERS.filter(s => s.tone === "disagree").forEach(s => toneScore.set(s.id,(toneScore.get(s.id)||0)+8));
  if (/merci|misaotra|thank|gratitude/.test(ctx)) COMMENT_STICKERS.filter(s => s.tone === "thanks").forEach(s => toneScore.set(s.id,(toneScore.get(s.id)||0)+8));

  return [...COMMENT_STICKERS].sort((a,b) => {
    const d = (toneScore.get(b.id)||0) - (toneScore.get(a.id)||0);
    return d || COMMENT_STICKERS.indexOf(a) - COMMENT_STICKERS.indexOf(b);
  });
}

const COMMENT_STICKER_REMOTE_CODES = {
  love_heart:"1f60d", love_hug:"1f970", joy_laugh:"1f923", joy_smile:"1f604",
  sad_tears:"1f622", sad_support:"1fac2", support_courage:"1f4aa", support_hope:"1f31f",
  celebrate_bravo:"1f44f", celebrate_party:"1f389", thanks_thankyou:"1f64f", thanks_respect:"1f91d",
  surprise_wow:"1f929", surprise_really:"1f62e", agree_true:"2705", agree_yes:"1f44d",
  prayer_amen:"2728", prayer_bless:"1f64f", disagree_no:"274c", disagree_stop:"1f6d1"
};

function stickerAssetSrc(sticker) {
  const code = COMMENT_STICKER_REMOTE_CODES[String(sticker?.id || "")] || "";
  return code ? `https://fonts.gstatic.com/s/e/notoemoji/latest/${code}/512.gif` : "";
}
function stickerFallbackSrc(sticker) {
  const fallbackCode = sticker?.tone === "disagree" ? "1f6d1" : sticker?.tone === "sad" ? "1f622" : sticker?.tone === "prayer" ? "1f64f" : "2728";
  return `https://fonts.gstatic.com/s/e/notoemoji/latest/${fallbackCode}/512.gif`;
}

function renderCommentStickerMarkup(stickerId, { compact = false } = {}) {
  const sticker = stickerById(stickerId);
  if (!sticker) return "";
  const src = stickerAssetSrc(sticker);
  const fallback = stickerFallbackSrc(sticker);
  const webp = src.replace(/\/512\.gif$/i, "/512.webp");
  return `<div class="lyrame-sticker${compact ? " is-compact" : ""}" data-sticker-id="${escapeHtml(sticker.id)}" role="img" aria-label="${escapeHtml(stickerLabel(sticker))}">
    <picture class="lyrame-sticker-picture">
      <source srcset="${escapeHtml(webp)}" type="image/webp">
      <img class="lyrame-sticker-media" src="${escapeHtml(src)}" data-fallback-src="${escapeHtml(fallback)}" data-fallback-icon="${escapeHtml(sticker.icon || "✨")}" alt="" ${compact ? 'loading="lazy"' : 'loading="eager"'} decoding="async" draggable="false">
    </picture>
    <span class="lyrame-sticker-label">${escapeHtml(stickerLabel(sticker))}</span>
  </div>`;
}

document.addEventListener("error", event => {
  const img = event.target?.closest?.("img.lyrame-sticker-media");
  if (!img) return;
  const fallback = img.dataset.fallbackSrc || "";
  if (fallback && img.dataset.fallbackTried !== "1") {
    img.dataset.fallbackTried = "1";
    img.src = fallback;
    return;
  }
  const span = document.createElement("span");
  span.className = "lyrame-sticker-remote-fallback";
  span.textContent = img.dataset.fallbackIcon || "✨";
  img.replaceWith(span);
}, true);

function positionStickerPickerNear(popup, anchor) {
  if (!popup || !anchor) return;
  const r = anchor.getBoundingClientRect();
  const width = Math.min(430, Math.max(300, window.innerWidth - 20));
  popup.style.position = "fixed";
  popup.style.zIndex = "10030";
  popup.style.width = `${width}px`;
  popup.style.maxWidth = "calc(100vw - 20px)";
  popup.style.left = `${Math.max(10, Math.min(r.left - width + r.width, window.innerWidth - width - 10))}px`;
  popup.style.right = "auto";
  const estimatedHeight = Math.min(520, Math.round(window.innerHeight * .68));
  const above = r.top - estimatedHeight - 10;
  popup.style.top = `${above > 10 ? above : Math.min(r.bottom + 10, window.innerHeight - estimatedHeight - 10)}px`;
  popup.style.bottom = "auto";
}

function ensureCommentStickerPicker(pickerId, contextText, onSelect) {
  let picker = document.getElementById(pickerId);
  if (!picker) {
    picker = document.createElement("section");
    picker.id = pickerId;
    picker.className = "comment-sticker-picker hidden";
    document.body.appendChild(picker);
  }
  const ranked = rankCommentStickers(contextText);
  const recommended = new Set(ranked.slice(0, 6).map(s => s.id));
  picker.innerHTML = `
    <div class="comment-sticker-head">
      <div><strong>${escapeHtml(uiText("Stickers LYRAME", "Stickers LYRAME", "LYRAME stickers"))}</strong><small>${escapeHtml(uiText("Suggestions selon cette discussion", "Soso-kevitra mifanaraka amin’ity resaka ity", "Suggestions for this discussion"))}</small></div>
      <button type="button" class="icon-btn sm" data-sticker-close aria-label="${escapeHtml(t("close") || "Fermer")}">×</button>
    </div>
    <div class="comment-sticker-grid">
      ${ranked.map(sticker => `<button type="button" class="comment-sticker-option${recommended.has(sticker.id) ? " is-recommended" : ""}" data-sticker-choice="${escapeHtml(sticker.id)}">${renderCommentStickerMarkup(sticker.id, {compact:true})}${recommended.has(sticker.id) ? `<span class="sticker-recommended-dot" title="${escapeHtml(uiText("Recommandé", "Mifanaraka", "Recommended"))}">★</span>` : ""}</button>`).join("")}
    </div>`;
  picker.querySelector("[data-sticker-close]")?.addEventListener("click", ev => { ev.stopPropagation(); hideEl(picker); });
  picker.querySelectorAll("[data-sticker-choice]").forEach(btn => btn.addEventListener("click", ev => {
    ev.stopPropagation();
    const id = btn.dataset.stickerChoice || "";
    hideEl(picker);
    if (id && typeof onSelect === "function") onSelect(id);
  }));
  return picker;
}

function toggleCommentStickerPicker(pickerId, anchor, contextText, onSelect) {
  const existing = document.getElementById(pickerId);
  if (existing && isShown(existing)) { hideEl(existing); return; }
  closeReactionPicker();
  closeEmojiPickers();
  const picker = ensureCommentStickerPicker(pickerId, contextText, onSelect);
  showEl(picker);
  picker.style.display = "block";
  requestAnimationFrame(() => positionStickerPickerNear(picker, anchor));
}

async function sendQuickCommentContent({ text = "", stickerId = "", parentId = null, replyTarget = null, isAnonymous = false } = {}) {
  if (!state.currentUser || !state.activePostId || commentQuickSendBusy) return false;
  const cleanText = String(text || "").trim().slice(0, 2000);
  const sticker = stickerById(stickerId);
  if (!cleanText && !sticker) return false;
  commentQuickSendBusy = true;
  try {
    const postId = state.activePostId;
    const uid = state.currentUser.uid;
    const p = state.currentProfile || {};
    const postRef = doc(db, "posts", postId);
    const newRef = doc(collection(db, "posts", postId, "comments"));
    const postSnap = await getDoc(postRef);
    if (!postSnap.exists()) throw new Error("POST_NOT_FOUND");
    const postAuthorId = postSnap.data().authorId || "";

    await setDoc(newRef, {
      authorId: uid,
      authorName: p.fullname || state.currentUser.displayName || "",
      authorUsername: p.username || "",
      authorPhotoURL: p.photoURL || "",
      authorBadgeType: badgeTypeOf(p),
      isAnonymous: !!isAnonymous,
      text: cleanText,
      mentions: [],
      imageURL: "",
      imagePublicId: "",
      mediaURL: "",
      mediaPublicId: "",
      mediaType: "",
      stickerId: sticker?.id || "",
      stickerTone: sticker?.tone || "",
      parentId: parentId || null,
      replyToUsername: replyTarget?.authorUsername || replyTarget?.username || "",
      createdAt: serverTimestamp()
    });
    updateDoc(postRef, { commentsCount: increment(1) }).catch(err => console.warn("[quick comment counter]", err));

    const who = p.fullname || uiSomeone();
    if (postAuthorId && postAuthorId !== uid) {
      createNotification({
        id:`comment_${postId}_${newRef.id}`, userId:postAuthorId, actorId:uid, type:"comment",
        title:uiText("Nouveau commentaire","Hevitra vaovao","New comment"),
        preview:`${who} ${uiText("a commenté votre publication.","nametraka hevitra tamin’ny publication-nao.","commented on your post.")}`,
        extra:{postId}
      }).catch(err => console.warn("[quick comment notification]", err));
    }
    const parentAuthorId = replyTarget?.authorId || "";
    if (parentAuthorId && parentAuthorId !== uid && parentAuthorId !== postAuthorId) {
      createNotification({
        id:`reply_${postId}_${newRef.id}`, userId:parentAuthorId, actorId:uid, type:"reply",
        title:uiText("Nouvelle réponse","Valiny vaovao","New reply"),
        preview:`${who} ${uiText("a répondu à votre commentaire.","namaly ny hevitrao.","replied to your comment.")}`,
        extra:{postId}
      }).catch(err => console.warn("[quick reply notification]", err));
    }
    return true;
  } catch (err) {
    logError("[quick comment]", err);
    toast(firestoreWriteErrorLabel(err, t("err_generic")));
    return false;
  } finally {
    commentQuickSendBusy = false;
  }
}

/* ------------------------------------------------------------
   32. COMMENTAIRES
   ------------------------------------------------------------ */
function startCommentsListener(postId) {
  if (listeners.comments) listeners.comments();
  toggleEmpty("comments-empty", true);

  const q = query(
    collection(db, "posts", postId, "comments"),
    orderBy("createdAt", "asc"),
    limit(COMMENTS_LIMIT)
  );

  listeners.comments = onSnapshot(q, snap => {
    const commentsList = $("#comments-list");
    if (!commentsList) return;
    commentsList.querySelectorAll(".comment").forEach(n => n.remove());

    if (snap.empty) {
      toggleEmpty("comments-empty", false);
      updateCommentsToggle();
      return;
    }
    toggleEmpty("comments-empty", true);

    const all = snap.docs.map(d => ({ id: d.id, ...d.data() }));
    const ids = new Set(all.map(c => c.id));
    const roots = all.filter(c => !c.parentId || !ids.has(c.parentId));
    const replies = all.filter(c => c.parentId && ids.has(c.parentId));

    roots.forEach(c => {
      commentsList.appendChild(renderComment(c, replies.filter(r => r.parentId === c.id)));
    });

    applyCommentsVisibility();
    updateCommentsToggle();
  }, err => logError("[comments listener]", err));
}

function renderComment(c, replies = [], rootId = null) {
  const el = document.createElement("div");
  el.className = "comment" + (c.isAnonymous ? " comment-anonymous" : "");
  el.dataset.commentId = c.id;

  const isDeleted = c.deleted === true;
  const commentMediaUrl = isDeleted ? "" : safeUrl(c.mediaURL || c.imageURL);
  const commentMediaType = c.mediaType || (c.imageURL ? "image" : "");
  const mediaHtml = commentMediaUrl
    ? `<div class="comment-media comment-media-${escapeHtml(commentMediaType)}">${
        commentMediaType === "video"
          ? `<video src="${escapeHtml(commentMediaUrl)}" controls playsinline></video>`
          : commentMediaType === "audio"
            ? `<audio src="${escapeHtml(commentMediaUrl)}" controls preload="metadata"></audio>`
            : `<img src="${escapeHtml(commentMediaUrl)}" alt="" />`
      }</div>`
    : "";
  const stickerHtml = (!isDeleted && c.stickerId) ? renderCommentStickerMarkup(c.stickerId) : "";
  const hasVisibleText = !isDeleted && !!String(c.text || "").trim();

  const me = state.currentUser?.uid || "";
  const canDelete = !!me && (c.authorId === me || state.activePostAuthorId === me);
  const reactionLabel = state.lang === "mg" ? "Tiako" : state.lang === "en" ? "Like" : "J’aime";
  const replyLabel = state.lang === "mg" ? "Hamaly" : state.lang === "en" ? "Reply" : "Répondre";

  el.innerHTML = `
    <div class="avatar">
      ${c.isAnonymous ? "?" : avatarMarkup(c.authorPhotoURL, c.authorName)}
    </div>
    <div class="comment-content">
      <div class="comment-bubble${c.stickerId ? " comment-bubble-sticker" : ""}">
        <div class="comment-name">
          ${escapeHtml(c.isAnonymous ? (state.lang === "mg" ? "Tsy mitonona anarana" : state.lang === "en" ? "Anonymous" : "Anonyme") : (c.authorName || ""))}${c.isAnonymous ? "" : identityBadgeMarkup({ badgeType: c.authorBadgeType })}${(!c.isAnonymous && c.authorUsername) ? `<span class="comment-username">@${escapeHtml(c.authorUsername)}</span>` : ""}
        </div>
        ${isDeleted ? `<div class="comment-text">${escapeHtml(state.lang === "mg" ? "Hevitra voafafa" : state.lang === "en" ? "Comment deleted" : "Commentaire supprimé")}</div>` : (hasVisibleText ? `<div class="comment-text">${commentTextWithMentions(c.text || "", c.mentions || [])}</div>` : "")}
        ${stickerHtml}
        ${mediaHtml}
      </div>
      <div class="comment-action-row">
        <span class="comment-time">${escapeHtml(formatTime(c.createdAt))}</span>
        ${isDeleted ? "" : `<button type="button" class="comment-like-trigger" data-comment-like>${escapeHtml(reactionLabel)}</button>`}
        ${isDeleted ? "" : `<button type="button" data-reply>${escapeHtml(replyLabel)}</button>`}
        ${canDelete ? `<button type="button" class="comment-delete-btn" data-delete-comment>${escapeHtml(t("delete"))}</button>` : ""}
        <span class="comment-reaction-summary" data-comment-reaction-summary></span>
      </div>
      ${isDeleted ? "" : `<div class="comment-reaction-picker hidden" data-comment-reaction-picker>${["👍","♥️","🤣","😮","😢"].map(e => `<button type="button" class="comment-reaction-choice" data-comment-reaction="${e}" aria-label="${e}">${e}</button>`).join("")}</div>`}
    </div>`;

  const avatar = el.querySelector(".avatar");
  const name = el.querySelector(".comment-name");
  if (!c.isAnonymous && c.authorId) {
    getUserProfile(c.authorId).then(profile => {
      if (!profile || !name) return;
      name.innerHTML = `${escapeHtml(c.authorName || profile.fullname || "")}${identityBadgeMarkup(profile)}${c.authorUsername ? `<span class="comment-username">@${escapeHtml(c.authorUsername)}</span>` : ""}`;
    }).catch(() => {});
  }
  const openAuthor = ev => {
    ev.stopPropagation();
    if (c.isAnonymous) { toast(state.lang === "mg" ? "Nafenin'ity mpanoratra ity ny profil." : state.lang === "en" ? "This author hid their profile." : "Profil masqué par cet auteur."); return; }
    if (!c.authorId) return;
    if (c.authorId === state.currentUser?.uid) showScreen("profile-me");
    else openOtherProfile(c.authorId);
  };
  avatar?.addEventListener("click", openAuthor);
  name?.addEventListener("click", openAuthor);

  if (replies.length) {
    const wrap = document.createElement("div");
    wrap.className = "replies replies-compact";
    const ordered = [...replies].sort((a,b) => timestampMs(a.createdAt) - timestampMs(b.createdAt));
    if (ordered.length > 1) {
      const more = document.createElement("button");
      more.type = "button";
      more.className = "replies-more-btn";
      const countPrevious = ordered.length - 1;
      more.textContent = state.lang === "mg"
        ? `Hijery valiny ${countPrevious} teo aloha`
        : state.lang === "en"
          ? `View ${countPrevious} previous ${countPrevious === 1 ? "reply" : "replies"}`
          : `Voir ${countPrevious === 1 ? "la réponse précédente" : `les ${countPrevious} réponses précédentes`}`;
      more.addEventListener("click", ev => { ev.stopPropagation(); openCommentThread(c); });
      wrap.appendChild(more);
    }
    wrap.appendChild(renderComment(ordered[ordered.length - 1], [], c.id));
    el.querySelector(".comment-content")?.appendChild(wrap);
  }

  el.querySelector("[data-reply]")?.addEventListener("click", ev => {
    ev.stopPropagation();
    state.commentReplyTo = { id: rootId || c.id, username: c.authorUsername || "", authorId: c.authorId || "", authorName: c.authorName || "", text: c.text || "", stickerId: c.stickerId || "" };
    const ta = $("#comment-text");
    renderReplyIndicator();
    ta?.focus();
    updateCommentSubmitState();
  });

  el.querySelector("[data-delete-comment]")?.addEventListener("click", async ev => {
    ev.stopPropagation();
    await deleteComment(c, replies.length > 0);
  });

  const likeTrigger = el.querySelector("[data-comment-like]");
  const picker = el.querySelector("[data-comment-reaction-picker]");
  let longPressTimer = 0;
  let longPressed = false;
  const openPicker = () => {
    longPressed = true;
    picker?.classList.remove("hidden");
    el.classList.add("reaction-picker-open");
  };
  const cancelLongPress = () => {
    if (longPressTimer) clearTimeout(longPressTimer);
    longPressTimer = 0;
  };
  likeTrigger?.addEventListener("pointerdown", ev => {
    if (ev.pointerType === "mouse" && ev.button !== 0) return;
    longPressed = false;
    cancelLongPress();
    longPressTimer = setTimeout(openPicker, 520);
  });
  ["pointerup","pointercancel","pointerleave"].forEach(type => likeTrigger?.addEventListener(type, cancelLongPress));
  likeTrigger?.addEventListener("contextmenu", ev => { ev.preventDefault(); openPicker(); });
  likeTrigger?.addEventListener("click", async ev => {
    ev.stopPropagation();
    cancelLongPress();
    if (longPressed) { longPressed = false; return; }
    await setCommentReaction(c.id, "👍", el);
  });

  el.querySelectorAll("[data-comment-reaction]").forEach(btn => {
    btn.addEventListener("click", async ev => {
      ev.stopPropagation();
      const emoji = btn.dataset.commentReaction || "";
      await setCommentReaction(c.id, emoji, el);
      picker?.classList.add("hidden");
      el.classList.remove("reaction-picker-open");
    });
  });

  document.addEventListener("click", function outsideReaction(ev) {
    if (!el.isConnected) { document.removeEventListener("click", outsideReaction); return; }
    if (!el.contains(ev.target)) {
      picker?.classList.add("hidden");
      el.classList.remove("reaction-picker-open");
    }
  });

  hydrateCommentReactions(el, c.id);
  return el;
}

async function setCommentReaction(commentId, emoji, commentEl) {
  if (!state.currentUser || !state.activePostId || !commentId || !emoji) return;
  const rRef = doc(db, "posts", state.activePostId, "comments", commentId, "reactions", state.currentUser.uid);
  try {
    const snap = await getDoc(rRef);
    if (snap.exists() && snap.data().emoji === emoji) await deleteDoc(rRef);
    else await setDoc(rRef, { userId: state.currentUser.uid, emoji, updatedAt: serverTimestamp() });
    await hydrateCommentReactions(commentEl, commentId);
  } catch (err) { logError("[comment reaction]", err); }
}

function timestampMs(v) {
  try {
    if (v?.toMillis) return v.toMillis();
    if (v?.seconds) return Number(v.seconds) * 1000;
    const n = new Date(v || 0).getTime();
    return Number.isFinite(n) ? n : 0;
  } catch (_) { return 0; }
}

function openCommentThread(rootComment) {
  if (!state.activePostId || !rootComment?.id) return;
  closeCommentThread();

  const overlay = document.createElement("section");
  overlay.id = "comment-thread-overlay";
  overlay.className = "comment-thread-overlay";
  const pickerId = `thread-comment-emoji-${rootComment.id}`;
  const stickerPickerId = `thread-comment-sticker-${rootComment.id}`;
  overlay.innerHTML = `
    <header class="comment-thread-head">
      <button type="button" class="icon-btn" data-thread-close aria-label="${escapeHtml(t("back"))}">←</button>
      <strong>${escapeHtml(uiText("Réponses", "Valiny", "Replies"))}</strong>
      <span class="thread-head-spacer"></span>
    </header>
    <div class="comment-thread-list" data-thread-list></div>
    <div class="thread-media-preview hidden" data-thread-media-preview></div>
    <form class="comment-thread-composer comment-unified-composer" data-thread-form novalidate>
      <button type="button" class="comment-media-main-btn thread-photo-btn" data-thread-photo aria-label="${escapeHtml(uiText("Ajouter une photo", "Hanampy sary", "Add a photo"))}">
        <svg viewBox="0 0 24 24" width="23" height="23" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="9" cy="9" r="2"/><path d="m21 15-5-5L5 21"/></svg>
      </button>
      <input type="file" accept="image/*" data-thread-file hidden />
      <div class="comment-input-wrap thread-input-wrap">
        <textarea rows="1" maxlength="2000" placeholder="${escapeHtml(uiText("Écrivez une réponse…", "Soraty ny valinteninao…", "Write a reply…"))}" data-thread-input></textarea>
        <button type="button" class="icon-btn sm thread-emoji-btn" data-thread-emoji aria-label="Emoji">
          <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M8 14s1.5 2 4 2 4-2 4-2M9 9h.01M15 9h.01"/></svg>
        </button>
        <button type="button" class="icon-btn sm thread-sticker-btn" data-thread-sticker aria-label="${escapeHtml(uiText("Ajouter un sticker", "Hanampy sticker", "Add a sticker"))}">
          <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 3h10a4 4 0 0 1 4 4v6l-6 6H7a4 4 0 0 1-4-4V5a2 2 0 0 1 2-2Z"/><path d="M13 19v-4a2 2 0 0 1 2-2h4"/><circle cx="8" cy="9" r="1"/><circle cx="14" cy="9" r="1"/><path d="M8 13s1.2 1.5 3 1.5 3-1.5 3-1.5"/></svg>
        </button>
        <button type="submit" class="comment-send-icon thread-send-btn hidden" aria-label="${escapeHtml(uiText("Envoyer", "Handefa", "Send"))}">
          <svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor"><path d="M22 2 9.7 21.1l-1.8-7-6.9-2.6L22 2Zm-11.9 10.1 1.1 4.3 5.7-8.9-6.8 4.6Z"/></svg>
        </button>
      </div>
    </form>`;
  document.body.appendChild(overlay);
  document.documentElement.classList.add("thread-open");

  const input = overlay.querySelector("[data-thread-input]");
  const form = overlay.querySelector("[data-thread-form]");
  const sendBtn = overlay.querySelector(".thread-send-btn");
  const photoBtn = overlay.querySelector("[data-thread-photo]");
  const fileInput = overlay.querySelector("[data-thread-file]");
  const emojiBtn = overlay.querySelector("[data-thread-emoji]");
  const stickerBtn = overlay.querySelector("[data-thread-sticker]");
  const preview = overlay.querySelector("[data-thread-media-preview]");
  let replyTarget = rootComment;
  let file = null;
  let fileUrl = "";
  const mentionStore = new Map();
  overlay._cleanup = () => {
    if (fileUrl) revokeUrl(fileUrl);
    document.getElementById(pickerId)?.remove();
    document.getElementById(stickerPickerId)?.remove();
    hideCommentMentionSuggestions();
  };

  const resize = () => resizeUnifiedCommentTextarea(input);
  const sync = () => {
    const has = !!((input?.value || "").trim() || file);
    if (sendBtn) {
      sendBtn.disabled = !has;
      sendBtn.classList.toggle("hidden", !has);
    }
    input?.closest(".comment-input-wrap")?.classList.toggle("has-content", has);
    resize();
  };
  const resetLocal = () => {
    if (fileUrl) revokeUrl(fileUrl);
    file = null; fileUrl = "";
    if (fileInput) fileInput.value = "";
    if (preview) { preview.innerHTML = ""; hideEl(preview); }
    mentionStore.clear();
    if (input) {
      input.value = "";
      input.placeholder = uiText("Écrivez une réponse…", "Soraty ny valinteninao…", "Write a reply…");
      input.style.height = "38px";
      input.classList.remove("is-scrollable");
    }
    replyTarget = rootComment;
    sync();
  };

  overlay.querySelector("[data-thread-close]")?.addEventListener("click", () => closeCommentThread());
  input?.addEventListener("input", () => { sync(); refreshCommentMentionSuggestions(input, mentionStore); });
  bindCommentMentionInput(input, mentionStore);
  photoBtn?.addEventListener("click", () => fileInput?.click());
  fileInput?.addEventListener("change", async () => {
    const chosen = fileInput.files?.[0];
    if (!chosen) return;
    const check = await validateMedia(chosen, "image");
    if (!check.ok) { toast(check.msg); fileInput.value = ""; return; }
    if (fileUrl) revokeUrl(fileUrl);
    file = chosen;
    fileUrl = URL.createObjectURL(chosen);
    if (preview) {
      preview.innerHTML = `<img src="${escapeHtml(fileUrl)}" alt=""><button type="button" data-thread-remove-media aria-label="${escapeHtml(t("delete"))}">×</button>`;
      showEl(preview);
      preview.querySelector("[data-thread-remove-media]")?.addEventListener("click", () => {
        if (fileUrl) revokeUrl(fileUrl);
        file = null; fileUrl = ""; fileInput.value = ""; preview.innerHTML = ""; hideEl(preview); sync();
      });
    }
    sync();
  });
  emojiBtn?.addEventListener("click", ev => {
    ev.stopPropagation();
    toggleEmojiPicker(pickerId, emojiBtn, () => input, async em => {
      hideEl(document.getElementById(pickerId));
      await sendQuickCommentContent({ text: em, parentId: rootComment.id, replyTarget: replyTarget || rootComment, isAnonymous:false });
    });
  });
  stickerBtn?.addEventListener("click", ev => {
    ev.stopPropagation();
    const context = [rootComment?.text || "", replyTarget?.text || "", stickerById(replyTarget?.stickerId)?.mg || ""].join(" ");
    toggleCommentStickerPicker(stickerPickerId, stickerBtn, context, async stickerId => {
      await sendQuickCommentContent({ stickerId, parentId: rootComment.id, replyTarget: replyTarget || rootComment, isAnonymous:false });
    });
  });

  const renderThread = all => {
    const list = overlay.querySelector("[data-thread-list]");
    if (!list) return;
    list.innerHTML = "";
    const root = all.find(x => x.id === rootComment.id) || rootComment;
    const replies = all.filter(x => x.parentId === rootComment.id).sort((a,b)=>timestampMs(a.createdAt)-timestampMs(b.createdAt));
    [root, ...replies].forEach((item, idx) => {
      const node = renderComment(item, [], rootComment.id);
      node.classList.add(idx === 0 ? "thread-root" : "thread-reply");
      const replyBtn = node.querySelector("[data-reply]");
      replyBtn?.addEventListener("click", ev => {
        ev.preventDefault(); ev.stopImmediatePropagation();
        replyTarget = item;
        if (input) {
          const target = item.authorName || item.authorUsername || uiSomeone();
          input.placeholder = `${uiText("Répondre à", "Hamaly an'i", "Reply to")} ${target}…`;
          input.focus();
        }
      }, true);
      list.appendChild(node);
    });
    list.scrollTop = list.scrollHeight;
  };

  const q = query(collection(db, "posts", state.activePostId, "comments"), orderBy("createdAt", "asc"), limit(COMMENTS_LIMIT));
  overlay._unsubscribe = onSnapshot(q, snap => {
    const all = snap.docs.map(d => ({ id:d.id, ...d.data() }));
    renderThread(all.filter(x => x.id === rootComment.id || x.parentId === rootComment.id));
  }, err => console.warn("[comment thread]", err));

  form?.addEventListener("submit", async ev => {
    ev.preventDefault();
    const text = (input?.value || "").trim().slice(0,2000);
    if ((!text && !file) || !state.currentUser) return;
    const mentions = collectCommentMentions(text, mentionStore);
    setBusy(sendBtn, true, "…");
    try {
      let mediaURL = "", mediaPublicId = "";
      if (file) {
        const up = await uploadMedia(file, { folder:`lyrame/comments/${state.currentUser.uid}`, resourceType:"image" });
        mediaURL = up.url; mediaPublicId = up.publicId;
      }
      const postRef = doc(db, "posts", state.activePostId);
      const newRef = doc(collection(db, "posts", state.activePostId, "comments"));
      const p = state.currentProfile || {};
      const target = replyTarget || rootComment;
      const postSnap = await getDoc(postRef);
      if (!postSnap.exists()) throw new Error("POST_NOT_FOUND");
      const postAuthorId = postSnap.data().authorId || "";
      await setDoc(newRef, {
        authorId: state.currentUser.uid,
        authorName: p.fullname || state.currentUser.displayName || "",
        authorUsername: p.username || "",
        authorPhotoURL: p.photoURL || "",
        authorBadgeType: badgeTypeOf(p),
        isAnonymous: false,
        text,
        mentions,
        imageURL: mediaURL,
        imagePublicId: mediaPublicId,
        mediaURL,
        mediaPublicId,
        mediaType: file ? "image" : "",
        parentId: rootComment.id,
        replyToUsername: target.authorUsername || "",
        createdAt: serverTimestamp()
      });
      lyrV48BumpCommentCount(1, "[thread comment counter]");
      const who = p.fullname || uiSomeone();
      const targetAuthorId = target.authorId || "";
      if (targetAuthorId && targetAuthorId !== state.currentUser.uid && targetAuthorId !== postAuthorId) {
        createNotification({
          id:`reply_${state.activePostId}_${newRef.id}`,
          userId:targetAuthorId, actorId:state.currentUser.uid, type:"reply",
          title:uiText("Nouvelle réponse","Valiny vaovao","New reply"),
          preview:`${who} ${uiText("a répondu à votre commentaire.","namaly ny hevitrao.","replied to your comment.")}`,
          extra:{postId:state.activePostId}
        }).catch(err => console.warn("[thread reply notification]", err));
      }
      notifyCommentMentions(mentions, { postId: state.activePostId, commentId: newRef.id, actorName: who }).catch(err => console.warn("[thread mention notification]", err));
      resetLocal();
    } catch (err) {
      logError("[thread reply]", err);
      toast(firestoreWriteErrorLabel(err, t("err_generic")));
    } finally {
      setBusy(sendBtn, false);
      sync();
    }
  });
  sync();
  setTimeout(() => input?.focus(), 100);
}

function closeCommentThread() {
  const overlay = document.getElementById("comment-thread-overlay");
  if (!overlay) return;
  try { overlay._unsubscribe?.(); } catch (_) {}
  try { overlay._cleanup?.(); } catch (_) {}
  overlay.remove();
  document.documentElement.classList.remove("thread-open");
}

async function hydrateCommentReactions(commentEl, commentId) {
  if (!commentEl || !state.activePostId || !commentId) return;
  try {
    const snap = await getDocs(query(collection(db, "posts", state.activePostId, "comments", commentId, "reactions"), limit(200)));
    const counts = new Map();
    let mine = "";
    snap.forEach(d => {
      const e = d.data()?.emoji || "";
      if (!e) return;
      counts.set(e, (counts.get(e) || 0) + 1);
      if (d.id === state.currentUser?.uid) mine = e;
    });
    const total = [...counts.values()].reduce((a,b)=>a+b,0);
    const top = [...counts.entries()].sort((a,b)=>b[1]-a[1]).slice(0,3).map(([e])=>e);
    const summary = commentEl.querySelector("[data-comment-reaction-summary]");
    if (summary) {
      summary.innerHTML = total ? `<span class="comment-reaction-icons">${top.map(escapeHtml).join("")}</span><small>${total}</small>` : "";
      summary.classList.toggle("hidden", !total);
    }
    const like = commentEl.querySelector("[data-comment-like]");
    if (like) {
      like.classList.toggle("active", !!mine);
      like.dataset.mineReaction = mine;
    }
    commentEl.querySelectorAll("[data-comment-reaction]").forEach(btn => {
      const e = btn.dataset.commentReaction || "";
      btn.classList.toggle("active", mine === e);
    });
  } catch (err) { console.warn("[comment reactions read]", err); }
}

async function deleteComment(comment, hasReplies = false) {
  if (!state.currentUser || !state.activePostId || !comment?.id) {
    return;
  }

  const uid = state.currentUser.uid;

  try {
    const postRef = doc(db, "posts", state.activePostId);
    const postSnap = await getDoc(postRef);

    if (!postSnap.exists()) {
      return;
    }

    const post = postSnap.data();
    const allowed = comment.authorId === uid || post.authorId === uid;

    if (!allowed) {
      toast(t("err_no_permission"));
      return;
    }

    const ok = await showConfirm({
      title: state.lang === "mg" ? "Hamafa hevitra" : state.lang === "en" ? "Delete comment" : "Supprimer le commentaire",
      message: state.lang === "mg" ? "Hofafana ve ity hevitra ity?" : state.lang === "en" ? "Delete this comment?" : "Supprimer ce commentaire ?",
      confirmText: t("delete"),
      danger: true
    });

    if (!ok) {
      return;
    }

    const commentRef = doc(db, "posts", state.activePostId, "comments", comment.id);

    if (hasReplies) {
      await updateDoc(commentRef, {
        deleted: true,
        text: "",
        imageURL: "",
        imagePublicId: "",
        mediaURL: "",
        mediaPublicId: "",
        mediaType: "",
        updatedAt: serverTimestamp()
      });

      return;
    }

    await runTransaction(db, async tx => {
      const pSnap = await tx.get(postRef);

      if (!pSnap.exists()) {
        return;
      }

      const count = Math.max(0, Number(pSnap.data().commentsCount || 0) - 1);

      tx.delete(commentRef);
      tx.update(postRef, { commentsCount: count });
    });
  } catch (err) {
    logError("[delete comment]", err);
    toast(t("err_generic"));
  }
}

function applyFullCommentsCollapse() {
  const list = $("#comments-list");
  const btn = $("#comments-collapse-btn");
  const more = $("#comments-toggle");
  if (!list || !btn) return;
  list.classList.toggle("is-collapsed", state.commentsCollapsed);
  btn.setAttribute("aria-expanded", state.commentsCollapsed ? "false" : "true");
  if (more) more.classList.toggle("hidden", state.commentsCollapsed || more.hidden);
}

function renderReplyIndicator() {
  const form = $("#comment-form");
  const composer = form?.querySelector(".comment-composer-modern");
  let bar = document.getElementById("comment-reply-indicator");
  const reply = state.commentReplyTo;
  const ta = $("#comment-text");
  if (!reply) {
    bar?.remove();
    if (ta) ta.placeholder = uiText("Écrivez un commentaire…", "Soraty ny hevitrao…", "Write a comment…");
    return;
  }
  if (!form || !composer) return;
  if (!bar) {
    bar = document.createElement("div");
    bar.id = "comment-reply-indicator";
    bar.className = "comment-reply-indicator";
    composer.insertAdjacentElement("beforebegin", bar);
  }
  const target = reply.authorName || reply.username || uiSomeone();
  bar.innerHTML = "";
  const span = document.createElement("span");
  span.textContent = `${uiText("Réponse à", "Valiny ho an'i", "Replying to")} ${target}`;
  const x = document.createElement("button");
  x.type = "button";
  x.textContent = "✕";
  x.setAttribute("aria-label", t("cancel"));
  x.addEventListener("click", () => {
    state.commentReplyTo = null;
    renderReplyIndicator();
    ta?.focus();
  });
  bar.append(span, x);
  if (ta) ta.placeholder = uiText("Écrivez une réponse…", "Soraty ny valinteninao…", "Write a reply…");
}

function applyCommentsVisibility() {
  const list = $("#comments-list");
  if (!list) return;
  const roots = Array.from(list.querySelectorAll(":scope > .comment"));
  const showAll = state.commentsExpanded;
  roots.forEach((c, i) => { c.style.display = (!showAll && i >= COMMENTS_PREVIEW) ? "none" : ""; });
}

function updateCommentsToggle() {
  const list   = $("#comments-list");
  const toggle = $("#comments-toggle");
  if (!list || !toggle) return;
  const count = list.querySelectorAll(":scope > .comment").length;
  if (count <= COMMENTS_PREVIEW || state.commentsCollapsed) { toggle.hidden = true; toggle.classList.add("hidden"); return; }
  toggle.hidden = false; toggle.classList.remove("hidden");
  toggle.textContent = state.commentsExpanded ? (state.lang === "mg" ? "Hijery kely" : state.lang === "en" ? "See less" : "Voir moins") : (state.lang === "mg" ? "Hijery fanampiny" : state.lang === "en" ? "See more" : "Voir plus");
}

/* --- Image de commentaire --- */
function renderCommentImagePreview() {
  const box = $("#comment-image-preview");
  const removeBtn = $("#comment-image-remove");
  if (!box) { if (removeBtn) removeBtn.classList.toggle("hidden", !state.commentImageFile); return; }
  box.innerHTML = "";
  const url = safeUrl(state.commentImagePreviewUrl, { allowBlob: true });
  if (!url) { hideEl(box); hideEl(removeBtn); return; }
  let node;
  if (state.commentMediaKind === "video") {
    node = document.createElement("video"); node.controls = true; node.playsInline = true;
  } else if (state.commentMediaKind === "audio") {
    node = document.createElement("audio"); node.controls = true; node.preload = "metadata";
  } else {
    node = document.createElement("img"); node.alt = "";
  }
  node.src = url;
  box.appendChild(node);
  showEl(box); showEl(removeBtn);
}

async function onCommentMediaChosen(file, kind, input) {
  if (!file) return;
  const check = await validateMedia(file, kind);
  if (!check.ok) { toast(check.msg); if (input) input.value = ""; return; }
  revokeUrl(state.commentImagePreviewUrl);
  state.commentImageFile = file;
  state.commentMediaKind = kind;
  state.commentImagePreviewUrl = URL.createObjectURL(file);
  ["#comment-image-input","#comment-video-input","#comment-audio-input"].forEach(sel => { const el=$(sel); if (el && el !== input) el.value=""; });
  renderCommentImagePreview();
  updateCommentSubmitState();
}

function removeCommentImage() {
  revokeUrl(state.commentImagePreviewUrl);
  state.commentImageFile = null;
  state.commentImagePreviewUrl = "";
  state.commentMediaKind = "image";
  ["#comment-image-input","#comment-video-input","#comment-audio-input"].forEach(sel => { const input=$(sel); if(input) input.value=""; });
  renderCommentImagePreview();
}

function resizeCommentTextarea() {
  const ta = $("#comment-text");
  if (!ta) return;
  const maxHeight = window.matchMedia?.("(max-width: 430px)")?.matches ? 118 : 126;
  if (!(ta.value || "").trim()) {
    ta.style.height = "38px";
    ta.classList.remove("is-scrollable");
    ta.scrollTop = 0;
    return;
  }
  ta.style.height = "38px";
  const measured = Math.max(38, ta.scrollHeight || 38);
  const next = Math.min(measured, maxHeight);
  ta.style.height = `${next}px`;
  ta.classList.toggle("is-scrollable", measured > maxHeight);
  if (measured > maxHeight) ta.scrollTop = ta.scrollHeight;
}

function updateCommentSubmitState() {
  const btn = $("#comment-submit-btn");
  const ta = $("#comment-text");
  const wrap = ta?.closest(".comment-input-wrap");
  if (!btn) return;
  const hasContent = !!((ta?.value || "").trim() || state.commentImageFile);
  const canSend = hasContent && !state.uploading;
  btn.disabled = !canSend;
  btn.classList.toggle("hidden", !hasContent);
  wrap?.classList.toggle("has-content", hasContent);
  resizeCommentTextarea();
}

function firestoreWriteErrorLabel(err, fallback) {
  const rawCode = String(err?.code || "unknown");
  const code = rawCode.replace(/^firestore\//, "");
  const msg = String(err?.message || "").replace(/\s+/g, " ").slice(0, 180);
  console.error("[firestore write diagnostic]", { code, message: msg, uid: state.currentUser?.uid || "" });

  const labels = {
    "permission-denied": uiText(
      "Firestore a refusé cette écriture (permission-denied).",
      "Nolavin'ny Firestore ity fanoratana ity (permission-denied).",
      "Firestore refused this write (permission-denied)."
    ),
    "unavailable": uiText(
      "Firestore est momentanément inaccessible (unavailable).",
      "Tsy tratra vetivety ny Firestore (unavailable).",
      "Firestore is temporarily unavailable (unavailable)."
    ),
    "unauthenticated": uiText(
      "La session Firebase n'est pas reconnue (unauthenticated).",
      "Tsy eken'ny Firebase ny session (unauthenticated).",
      "Firebase session is not authenticated (unauthenticated)."
    ),
    "failed-precondition": uiText(
      "Firestore exige une condition/index manquant (failed-precondition).",
      "Misy condition/index takian'ny Firestore (failed-precondition).",
      "Firestore requires a missing condition/index (failed-precondition)."
    )
  };
  if (labels[code]) return labels[code];
  return `${fallback} [Firestore: ${code}${msg ? ` — ${msg}` : ""}]`;
}

async function handleCommentSubmit(e) {
  e.preventDefault();
  if (!state.currentUser || !state.activePostId || state.uploading) return;
  const ta = $("#comment-text");
  const text = (ta?.value || "").trim().slice(0, 2000);
  const mediaFile = state.commentImageFile;
  if (!text && !mediaFile) { toast(t("err_empty_comment")); return; }

  const postId = state.activePostId;
  const uid = state.currentUser.uid;
  const reply = state.commentReplyTo;
  const parentId = reply ? reply.id : null;
  const mentions = collectCommentMentions(text, state.commentMentionSelections);

  const btn = e.target?.querySelector?.('button[type="submit"]') || $("#comment-submit-btn");
  state.uploading = true;
  updateCommentSubmitState();
  setBusy(btn, true, "...");

  try {
    let mediaURL = "", mediaPublicId = "";
    if (mediaFile) {
      try {
        const up = await uploadMedia(mediaFile, {
          folder: `lyrame/comments/${uid}`,
          resourceType: "image"
        });
        mediaURL = up.url;
        mediaPublicId = up.publicId;
      } catch (upErr) {
        logError("[comment upload]", upErr);
        toast(t("err_image_upload"));
        return;
      }
    }

    const p = state.currentProfile || {};
    const postRef = doc(db, "posts", postId);
    const newRef = doc(collection(db, "posts", postId, "comments"));
    const postSnap = await getDoc(postRef);
    if (!postSnap.exists()) throw new Error("POST_NOT_FOUND");
    const postAuthorId = postSnap.data().authorId || "";

    await setDoc(newRef, {
      authorId: uid,
      authorName: p.fullname || state.currentUser.displayName || "",
      authorUsername: p.username || "",
      authorPhotoURL: p.photoURL || "",
      authorBadgeType: badgeTypeOf(p),
      isAnonymous: !!state.commentAnonymous,
      text,
      mentions,
      imageURL: mediaURL,
      imagePublicId: mediaPublicId,
      mediaURL,
      mediaPublicId,
      mediaType: mediaFile ? "image" : "",
      parentId: parentId || null,
      replyToUsername: reply?.username || "",
      createdAt: serverTimestamp()
    });
    updateDoc(postRef, { commentsCount: increment(1) }).catch(err => console.warn("[comment counter]", err));

    const who = p.fullname || uiSomeone();
    resetCommentComposer();
    toast(t("msg_comment_added"));

    if (postAuthorId && postAuthorId !== uid) {
      createNotification({
        id: `comment_${postId}_${newRef.id}`,
        userId: postAuthorId, actorId: uid, type: "comment",
        title: uiText("Nouveau commentaire", "Hevitra vaovao", "New comment"),
        preview: `${who} ${uiText("a commenté votre publication.", "nametraka hevitra tamin’ny publication-nao.", "commented on your post.")}`,
        extra: { postId }
      }).catch(err => console.warn("[comment notification]", err));
    }
    const parentAuthorId = reply?.authorId || "";
    if (parentAuthorId && parentAuthorId !== uid && parentAuthorId !== postAuthorId) {
      createNotification({
        id: `reply_${postId}_${newRef.id}`,
        userId: parentAuthorId, actorId: uid, type: "reply",
        title: uiText("Nouvelle réponse", "Valiny vaovao", "New reply"),
        preview: `${who} ${uiText("a répondu à votre commentaire.", "namaly ny hevitrao.", "replied to your comment.")}`,
        extra: { postId }
      }).catch(err => console.warn("[reply notification]", err));
    }
    notifyCommentMentions(mentions, { postId, commentId: newRef.id, actorName: who }).catch(err => console.warn("[mention notification]", err));
  } catch (err) {
    logError("[comment]", err);
    toast(firestoreWriteErrorLabel(err, t("err_generic")));
  } finally {
    state.uploading = false;
    setBusy(btn, false);
    updateCommentSubmitState();
  }
}

/* ------------------------------------------------------------
   33. CRÉATION DE PUBLICATION
   ------------------------------------------------------------ */
async function handlePublishPost() {
  if (!state.currentUser || state.uploading) return;

  const title =
    ($("#create-title")?.value || "")
      .trim()
      .slice(0, TITLE_MAX);

  const text = (
    state.richEditorEnabled
      ? richEditorPlainText()
      : ($("#create-text")?.value || "").trim()
  ).slice(0, TEXT_MAX);

  const richTextHtml =
    state.richEditorEnabled &&
    $("#create-rich-editor")
      ? sanitizeRichHtml(
          $("#create-rich-editor").innerHTML
        )
      : "";

  const category =
    $("#create-category")?.value ||
    "poesie";

  const privacy =
    privacyOf(
      $("#create-privacy")?.value,
      "public"
    );

  const formatting =
    sanitizeFormatting(
      state.postFormat
    );

  const media =
    state.selectedPostMedia;

  const imageRatio =
    media?.kind === "image"
      ? state.selectedImageRatio ||
        "original"
      : "original";

  if (!title || (!text && !media && !state.selectedPostBackground)) { toast(t("err_empty_post")); return; }

  const btn = $("#create-publish-btn");
  state.uploading = true;
  setBusy(btn, true, "...");
  let uploadedPublicId = "";

  try {
    let mediaURL = "", mediaPublicId = "", mediaType = "", mediaResourceType = "", mediaMeta = null;
    let publishedBackground = state.selectedPostBackground ? { ...state.selectedPostBackground } : null;

    if (publishedBackground?.kind === "upload" && publishedBackground.file) {
      const bgUp = await uploadMedia(publishedBackground.file, {
        folder: `lyrame/posts/${state.currentUser.uid}/backgrounds`, resourceType: "image", onProgress: setUploadProgress
      });
      uploadedPublicId = bgUp.publicId;
      publishedBackground = { kind: "remote", url: bgUp.url, publicId: bgUp.publicId, ratio: state.selectedBackgroundRatio || "original" };
    }

    if (media) {
      const check = await validateMedia(media.file, media.kind);
      if (!check.ok) { toast(check.msg); return; }

      setUploadProgress(0);
      try {
        const up = await uploadMedia(media.file, {
          folder: `lyrame/posts/${state.currentUser.uid}`,
          resourceType: media.kind === "video" ? "video" : "image",
          onProgress: setUploadProgress
        });
        mediaURL = up.url;
        mediaPublicId = up.publicId;
        mediaType = media.kind;
        mediaResourceType = up.resourceType;
        mediaMeta = {
          format: up.format, bytes: up.bytes, width: up.width, height: up.height, duration: up.duration
        };
        uploadedPublicId = up.publicId;
      } catch (upErr) {
        logError("[post upload]", upErr);
        toast(t("err_upload_failed"));
        return;
      }
    }

    await ensureUserDocument();

    const p = state.currentProfile || {};
    const backgroundPayload = publishedBackground ? { ...publishedBackground, ratio: state.selectedBackgroundRatio || "original" } : null;
    if (backgroundPayload) { delete backgroundPayload.file; delete backgroundPayload.localUrl; }
    const editing = !!state.editingPostId;
    const postRef = editing ? doc(db, "posts", state.editingPostId) : doc(collection(db, "posts"));
    const batch = writeBatch(db);
    const postPayload = {
      authorId: state.currentUser.uid,
      authorName: p.fullname || state.currentUser.displayName || "",
      authorUsername: p.username || "",
      authorPhotoURL: p.photoURL || "",
      authorBadgeType: badgeTypeOf(p),
      title,
      text,
      richTextHtml,
      formatting,
      category,
      privacy,
      countryCode: String(p.countryCode || "").toUpperCase().slice(0,2),
      imageRatio,
      videoRatio: media?.kind === "video" ? (state.selectedVideoRatio || "original") : "original",
      background: backgroundPayload,
      mediaURL,
      mediaPublicId,
      mediaType,
      mediaResourceType,
      mediaMeta,
      reactionsCount: 0,
      commentsCount: 0,
      updatedAt: serverTimestamp()
    };
    if (editing) {
      batch.update(postRef, postPayload);
    } else {
      postPayload.createdAt = serverTimestamp();
      batch.set(postRef, postPayload);
      batch.set(doc(db, "users", state.currentUser.uid), {
        uid: state.currentUser.uid,
        postsCount: increment(1),
        updatedAt: serverTimestamp()
      }, { merge: true });
    }
    await batch.commit();
    uploadedPublicId = "";

    resetCreateForm();
    toast(t("msg_post_created"));
    showScreen("home");
  } catch (err) {
    logError("[publish post]", err);
    toast(t("err_generic"));
  } finally {
    if (uploadedPublicId) await safeDeleteMediaAsset(uploadedPublicId);
    setUploadProgress(null);
    setBusy(btn, false);
    state.uploading = false;
    updatePublishState();
  }
}

/* ------------------------------------------------------------
   34. RECHERCHE
   ------------------------------------------------------------ */
let searchDebounce = null;
let searchToken = 0;

function onSearchInput(e) {
  clearTimeout(searchDebounce);

  const term = String(e.target.value || "")
    .trim()
    .toLowerCase()
    .replace(/^@+/, "");

  searchDebounce = setTimeout(() => runSearch(term), 300);
}

async function runSearch(term) {
  const list = $("#search-results");
  if (!list) return;

  const token = ++searchToken;

  list
    .querySelectorAll(".user-card, .empty-state.small-empty")
    .forEach(n => n.remove());

  if (!term) {
    toggleEmpty("search-empty", false);
    return;
  }

  toggleEmpty("search-empty", true);

  try {
    /*
      Tsy username ihany no tadiavina.
      Maka users bounded dia manao filtre client-side:
      - fullname
      - username
      - @username
      Izany koa dia miasa amin'ireo comptes taloha tsy manana
      searchName/searchKeywords.
    */
    const snap = await getDocs(
      query(
        collection(db, "users"),
        limit(100)
      )
    );

    if (token !== searchToken) return;

    const normalizedTerm = term
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "");

    const users = snap.docs
      .map(d => ({ uid: d.id, ...d.data() }))
      .filter(u => {
        const fullname = String(u.fullname || "")
          .trim()
          .toLowerCase()
          .normalize("NFD")
          .replace(/[\u0300-\u036f]/g, "");

        const username = String(u.username || "")
          .trim()
          .toLowerCase()
          .replace(/^@+/, "");

        return (
          fullname.includes(normalizedTerm) ||
          username.includes(normalizedTerm)
        );
      })
      .sort((a, b) => {
        const aUsername = String(a.username || "").toLowerCase();
        const bUsername = String(b.username || "").toLowerCase();
        const aName = String(a.fullname || "").toLowerCase();
        const bName = String(b.fullname || "").toLowerCase();

        const aExact =
          aUsername === normalizedTerm ||
          aName === normalizedTerm;

        const bExact =
          bUsername === normalizedTerm ||
          bName === normalizedTerm;

        if (aExact !== bExact) return aExact ? -1 : 1;

        const aStarts =
          aUsername.startsWith(normalizedTerm) ||
          aName.startsWith(normalizedTerm);

        const bStarts =
          bUsername.startsWith(normalizedTerm) ||
          bName.startsWith(normalizedTerm);

        if (aStarts !== bStarts) return aStarts ? -1 : 1;

        return aName.localeCompare(bName);
      })
      .slice(0, 20);

    list
      .querySelectorAll(".user-card, .empty-state.small-empty")
      .forEach(n => n.remove());

    if (!users.length) {
      const note = document.createElement("div");
      note.className = "empty-state small-empty";
      note.innerHTML =
        `<p class="empty-title">${escapeHtml(t("empty_search"))}</p>`;
      list.appendChild(note);
      return;
    }

    users.forEach(u => {
      list.appendChild(renderUserCard(u));
    });

  } catch (err) {
    logError("[search]", err);
    toast(t("err_generic"));
  }
}

function renderUserCard(u) {
  const el = document.createElement("div");
  el.className = "user-card";
  el.dataset.uid = u.uid || "";
  el.innerHTML = `
    <div class="avatar">${avatarMarkup(u.photoURL, u.fullname)}</div>
    <div class="info">
      <div class="name">${escapeHtml(u.fullname || "")}${identityBadgeMarkup(u)}</div>
      <div class="username">${u.username ? "@" + escapeHtml(u.username) : ""}</div>
    </div>
  `;
  el.addEventListener("click", () => { if (u.uid) openOtherProfile(u.uid); });
  return el;
}

/* ------------------------------------------------------------
   35. PROFIL D'UN AUTRE
   ------------------------------------------------------------ */
async function openOtherProfile(uid) {
  if (!uid) return;
  if (state.currentUser && uid === state.currentUser.uid) {
    state.profileViewUid = null;
    showScreen("profile-me");
    return;
  }
  state.profileViewUid = uid;

  try {
    const friendSnap = await getDocs(
      query(
        collection(db, "friendships"),
        where("users", "array-contains", uid),
        limit(300)
      )
    );

    setText("profile-other-friends-count", friendSnap.size);
  } catch (err) {
    console.warn("[profile friend count]", err);

    setText("profile-other-friends-count", "0");
  }

  state.profileOtherTab = "posts";
  state.otherProfilePosts = [];

  const profileOtherScope = $("#screen-profile-other");

  profileOtherScope?.querySelectorAll(".tab").forEach(tab => {
    const active = tab.dataset.tab === "posts";

    tab.classList.toggle("active", active);
    tab.setAttribute(
      "aria-selected",
      active ? "true" : "false"
    );
  });

  showScreen("profile-other");
  updateFriendButton();
  setText("profile-other-presence", "");
  setText("profile-other-birthdate", "");

  try {
    const snap = await getDoc(doc(db, "users", uid));
    if (state.profileViewUid !== uid) return;
    if (!snap.exists()) { toast(t("msg_user_not_found")); return; }
    const u = { uid, ...snap.data() };
    await renderOtherProfile(u);
    if (state.profileViewUid !== uid) return;
    updateFollowButton(uid);
    updateFriendButton();
    startOtherPostsListener(uid);
    listenActiveProfilePresence(uid);
  } catch (err) {
    logError("[other profile]", err);
    toast(t("err_generic"));
  }
}

async function renderOtherProfile(u) {
  setText("profile-other-username-title", u.username ? "@" + u.username : "");
  setNameWithBadge("profile-other-name", u.fullname || "", u);
  setText("profile-other-username", u.username ? "@" + u.username : "");
  setText("profile-other-bio", u.bio || "");
  setText("profile-other-posts", String(u.postsCount || 0));
  setText("profile-other-followers", String(u.followersCount || 0));
  setText("profile-other-following", String(u.followingCount || 0));
  setText("profile-other-presence", formatPresence(u));

  const avatar = $("#profile-other-avatar");
  if (avatar) avatar.innerHTML = avatarMarkup(u.photoURL, u.fullname);
  const cover = $("#profile-other-cover");
  if (cover) {
    const safeCover = safeUrl(u.coverURL);
    cover.style.backgroundImage = safeCover ? `url("${safeCover}")` : "";
  }

  const allowed = await canViewBirthdate(u, u.uid, state.currentUser?.uid);
  if (state.profileViewUid === u.uid) {
    setText("profile-other-birthdate", allowed ? "🎂 " + formatBirthdate(u.birthdate) : "");
  }
}

function startOtherPostsListener(uid) {
  if (listeners.otherPosts) {
    listeners.otherPosts();
    listeners.otherPosts = null;
  }

  state.otherProfilePosts = [];

  const q = query(
    collection(db, "posts"),
    where("authorId", "==", uid),
    limit(POSTS_LIMIT)
  );

  listeners.otherPosts = onSnapshot(
    q,
    snap => {
      if (state.profileViewUid !== uid) return;

      state.otherProfilePosts = sortPostsNewestFirst(
        snap.docs.map(d => ({
          id: d.id,
          ...d.data()
        }))
      );

      renderProfileTab("other");
    },
    err => logError("[other posts]", err)
  );
}

/* ------------------------------------------------------------
   36. FOLLOW (indépendant de l'amitié)
   ------------------------------------------------------------ */
async function updateFollowButton(targetUid) {
  const btn = $("#profile-other-follow-btn");
  if (!btn || !state.currentUser) return;
  try {
    const snap = await getDoc(doc(db, "users", state.currentUser.uid, "following", targetUid));
    if (state.profileViewUid !== targetUid) return;
    btn.textContent = snap.exists() ? uiText("Abonné", "Manaraka", "Following") : uiText("S’abonner", "Hanaraka", "Follow");
    btn.dataset.following = snap.exists() ? "1" : "0";
  } catch (err) {
    logError("[follow state]", err);
  }
}

async function applyFollowState(targetUid, shouldFollow) {
  if (!state.currentUser || !targetUid || targetUid === state.currentUser.uid) return false;
  const uid = state.currentUser.uid;
  const meRef = doc(db, "users", uid);
  const targetRef = doc(db, "users", targetUid);
  const myFollowRef = doc(db, "users", uid, "following", targetUid);
  const theirFollowerRef = doc(db, "users", targetUid, "followers", uid);

  await ensureUserDocument();
  const [meSnap, targetSnap, followSnap] = await Promise.all([
    getDoc(meRef),
    getDoc(targetRef),
    getDoc(myFollowRef)
  ]);

  if (!targetSnap.exists()) {
    const e = new Error("TARGET_PROFILE_MISSING");
    e.code = "lyrame/target-profile-missing";
    throw e;
  }

  if (shouldFollow && followSnap.exists()) return true;
  if (!shouldFollow && !followSnap.exists()) return false;

  // Etape critique minimale : écrire uniquement les sous-documents Follow.
  // Les compteurs sont secondaires et ne doivent jamais faire échouer l'action principale.
  const batch = writeBatch(db);
  if (shouldFollow) {
    batch.set(myFollowRef, { uid: targetUid, createdAt: serverTimestamp() });
    batch.set(theirFollowerRef, { uid, createdAt: serverTimestamp() });
  } else {
    batch.delete(myFollowRef);
    batch.delete(theirFollowerRef);
  }
  await batch.commit();

  // Synchronisation des compteurs en best-effort.
  const meCount = shouldFollow
    ? increment(1)
    : Math.max(0, Number(meSnap.data()?.followingCount || 0) - 1);
  const targetCount = shouldFollow
    ? increment(1)
    : Math.max(0, Number(targetSnap.data()?.followersCount || 0) - 1);
  Promise.allSettled([
    updateDoc(meRef, { followingCount: meCount }),
    updateDoc(targetRef, { followersCount: targetCount })
  ]).then(results => {
    results.forEach(r => { if (r.status === "rejected") console.warn("[follow counter]", r.reason); });
  });
  return shouldFollow;
}

function followErrorMessage(err) {
  const code = String(err?.code || "");
  if (code.includes("permission-denied")) return uiText("Action refusée par les règles Firebase.", "Nolavin'ny Firestore Rules ilay fangatahana.", "Action blocked by Firebase rules.");
  if (code.includes("unavailable") || code.includes("network")) return uiText("Connexion Firestore indisponible. Réessayez.", "Tsy afaka mifandray amin'ny Firestore. Andramo indray.", "Firestore connection unavailable. Try again.");
  if (code === "lyrame/target-profile-missing") return uiText("Profil utilisateur incomplet ou introuvable.", "Tsy feno na tsy hita ny profil an'ilay olona.", "User profile is missing or incomplete.");
  return uiText("Impossible de modifier l’abonnement.", "Tsy afaka manova ny fanarahana.", "Could not change follow state.");
}

async function toggleFollow() {
  if (!state.currentUser || !state.profileViewUid) return;
  const target = state.profileViewUid;
  if (state.currentUser.uid === target) return;
  const btn = $("#profile-other-follow-btn");
  if (!btn || btn.disabled) return;

  const following = btn.dataset.following === "1";
  let nextFollowing = following;
  setBusy(btn, true, "...");

  try {
    nextFollowing = await applyFollowState(target, !following);
    if (nextFollowing) {
      createNotification({
        id: `follow_${state.currentUser.uid}_${target}`,
        userId: target,
        actorId: state.currentUser.uid,
        type: "follow",
        title: uiText("Nouvel abonné", "Mpanaraka vaovao", "New follower"),
        preview: `${state.currentProfile?.fullname || uiSomeone()} ${uiText("vous suit maintenant.", "manaraka anao izao.", "is now following you.")}`
      }).catch(err => console.warn("[follow notification]", err));
      toast(t("msg_followed"));
    } else {
      toast(t("msg_unfollowed"));
    }
  } catch (err) {
    logError("[follow]", err);
    toast(followErrorMessage(err));
  } finally {
    setBusy(btn, false);
    btn.dataset.following = nextFollowing ? "1" : "0";
    btn.textContent = nextFollowing ? uiText("Abonné", "Manaraka", "Following") : uiText("S’abonner", "Hanaraka", "Follow");
    getUserProfile(target, { force: true }).then(u => {
      if (u && state.profileViewUid === target) {
        setText("profile-other-followers", String(u.followersCount || 0));
        setText("profile-other-following", String(u.followingCount || 0));
      }
    });
  }
}

function openFollowers() {
  const uid = state.profileViewUid || state.currentUser?.uid;
  if (!uid) return;
  showScreen("followers");
  startFollowersListener(uid);
}

function openFollowing() {
  const uid = state.profileViewUid || state.currentUser?.uid;
  if (!uid) return;
  showScreen("following");
  startFollowingListener(uid);
}

async function renderUserListFromSnapshot(snap, { containerId, emptyId, tokenKey }) {
  const token = ++listTokens[tokenKey];
  const container = document.getElementById(containerId);
  if (!container) return;
  if (snap.empty) {
    container.querySelectorAll(".user-card").forEach(n => n.remove());
    toggleEmpty(emptyId, false);
    return;
  }
  toggleEmpty(emptyId, true);
  const profiles = await Promise.all(snap.docs.map(d => getUserProfile(d.id)));
  if (token !== listTokens[tokenKey]) return;
  container.querySelectorAll(".user-card").forEach(n => n.remove());
  profiles.filter(Boolean).forEach(u => container.appendChild(renderUserCard(u)));
}

function startFollowersListener(uid) {
  if (listeners.followers) listeners.followers();
  $("#followers-list")?.querySelectorAll(".user-card").forEach(n => n.remove());
  toggleEmpty("followers-empty", true);
  listeners.followers = onSnapshot(
    query(collection(db, "users", uid, "followers"), limit(100)),
    snap => {
      renderUserListFromSnapshot(snap, { containerId: "followers-list", emptyId: "followers-empty", tokenKey: "followers" })
        .catch(err => logError("[followers render]", err));
    },
    err => logError("[followers]", err)
  );
}

function startFollowingListener(uid) {
  if (listeners.following) listeners.following();
  $("#following-list")?.querySelectorAll(".user-card").forEach(n => n.remove());
  toggleEmpty("following-empty", true);
  listeners.following = onSnapshot(
    query(collection(db, "users", uid, "following"), limit(100)),
    snap => {
      renderUserListFromSnapshot(snap, { containerId: "following-list", emptyId: "following-empty", tokenKey: "following" })
        .catch(err => logError("[following render]", err));
    },
    err => logError("[following]", err)
  );
}

/* ------------------------------------------------------------
   37. GROUPES — HELPERS DE PERMISSIONS (rétro-compatibles)
   ------------------------------------------------------------ */
function groupOwnerId(c) { return (c && (c.ownerId || c.createdBy)) || ""; }
function groupAdminIds(c) {
  const a = Array.isArray(c?.adminIds) ? c.adminIds : [];
  const o = groupOwnerId(c);
  return Array.from(new Set([...(o ? [o] : []), ...a]));
}
function canManageGroup(c, uid) { return !!uid && groupAdminIds(c).includes(uid); }
function isGroupOwner(c, uid) { return !!uid && groupOwnerId(c) === uid; }
function groupCover(c) { return (c && (c.coverURL || c.photoURL)) || ""; }
function sanitizeGroupPrivacy(v) { return /^[a-z_-]{1,20}$/.test(String(v || "")) ? v : "private"; }

/* ------------------------------------------------------------
   38. MESSAGES — LISTE DES CONVERSATIONS
   ------------------------------------------------------------ */
function startConversationsListener() {
  if (!state.currentUser) return;
  if (listeners.conversations) listeners.conversations();

  const q = query(
    collection(db, "conversations"),
    where("memberIds", "array-contains", state.currentUser.uid),
    limit(50)
  );

  listeners.conversations = onSnapshot(q, snap => {
    const list = $("#conversations-list");
    if (!list) return;
    list.querySelectorAll(".conv-item").forEach(n => n.remove());
    if (snap.empty) {
      toggleEmpty("conversations-empty", false);
      lyrameMessagesUpdateCount(0);
      return;
    }
    toggleEmpty("conversations-empty", true);

    const items = snap.docs.map(d => ({ id: d.id, ...d.data() }));
    items.sort((a, b) => (b.lastMessageAt?.toMillis?.() || 0) - (a.lastMessageAt?.toMillis?.() || 0));
    items.forEach(c => list.appendChild(renderConversationItem(c)));
    lyrameMessagesUpdateCount(items.length);
    lyrameMessagesFilterConversations();
  }, err => logError("[conversations]", err));
}

/* L'écran Messages n'affiche pas deux fois les mêmes discussions. */
function lyrameMessagesUpdateCount(total) {
  const el = document.getElementById("messages-count");
  if (!el) return;
  el.textContent = total === 1
    ? uiText("1 discussion", "Resaka 1", "1 chat")
    : uiText(`${total} discussions`, `Resaka ${total}`, `${total} chats`);
}

function lyrameMessagesFilterConversations() {
  const field = document.getElementById("messages-search");
  const needle = String(field?.value || "").trim().toLocaleLowerCase();
  document.querySelectorAll("#conversations-list .conv-item").forEach(item => {
    const searchText = [item.querySelector(".name")?.textContent,
                        item.querySelector(".preview")?.textContent].join(" ").toLocaleLowerCase();
    item.hidden = Boolean(needle) && !searchText.includes(needle);
  });
}

function lyrameMessagesTranslateHeader() {
  const subtitle = document.getElementById("messages-subtitle");
  const title = document.getElementById("messages-discussions-label");
  const search = document.getElementById("messages-search");
  const newBtn = document.getElementById("messages-new-message");
  const assistantBtn = document.getElementById("messages-assistant-entry");
  if (subtitle) subtitle.textContent = uiText("Gardez le lien, simplement.", "Mifandraisa mora foana.", "Stay connected, simply.");
  if (title) title.textContent = uiText("Discussions", "Resaka", "Chats");
  if (search) {
    search.placeholder = uiText("Rechercher une personne, un groupe ou une discussion…", "Hitady olona, vondrona na resaka…", "Search people, groups or chats…");
    search.setAttribute("aria-label", uiText("Rechercher des messages", "Hikaroka hafatra", "Search messages"));
  }
  if (newBtn) {
    const label = uiText("Nouvelle conversation", "Resaka vaovao", "New conversation");
    newBtn.title = label; newBtn.setAttribute("aria-label", label);
  }
  if (assistantBtn) {
    const label = uiText("Assistant LYRAME", "Mpanampy LYRAME", "LYRAME assistant");
    assistantBtn.title = label; assistantBtn.setAttribute("aria-label", label);
  }
  const count=document.getElementById("messages-count");
  if (count) lyrameMessagesUpdateCount(document.querySelectorAll("#conversations-list .conv-item").length);
}

async function resolveConversationInfo(c) {
  const memberIds = Array.isArray(c.memberIds) ? c.memberIds : [];
  if (c.isGroup) {
    return {
      name: c.name || uiGroup(),
      photoURL: groupCover(c),
      sub: `${memberIds.length} ${t("group_members_count")}`,
      otherUid: ""
    };
  }
  const myUid = state.currentUser ? state.currentUser.uid : "";
  const otherUid = memberIds.find(id => id !== myUid) || "";
  let other = otherUid ? await getUserProfile(otherUid) : null;
  if (!other && Array.isArray(c.memberProfiles)) {
    other = c.memberProfiles.find(p => p && p.uid !== myUid) || null;
  }
  return {
    name: other?.fullname || uiConversation(),
    photoURL: other?.photoURL || "",
    sub: other?.username ? `@${other.username}` : "",
    otherUid,
    badgeProfile: other || null
  };
}

function renderConversationItem(c) {
  const el = document.createElement("div");
  el.className = "conv-item";
  el.dataset.convId = c.id;
  el.setAttribute("role", "button");
  el.tabIndex = 0;

  const initialName = c.isGroup ? (c.name || uiGroup()) : "…";
  const initialPhoto = c.isGroup ? groupCover(c) : "";

  el.innerHTML = `
    <div class="avatar">${avatarMarkup(initialPhoto, initialName)}</div>
    <div class="info">
      <div class="name">${escapeHtml(initialName)}</div>
      <div class="preview">${escapeHtml(c.lastMessage || "")}</div>
    </div>
    <div class="date">${escapeHtml(formatTime(c.lastMessageAt))}</div>
  `;

  resolveConversationInfo(c).then(info => {
    const nameEl = el.querySelector(".name");
    const avEl = el.querySelector(".avatar");
    if (nameEl) nameEl.innerHTML = `${escapeHtml(info.name)}${identityBadgeMarkup(info.badgeProfile)}`;
    if (avEl) avEl.innerHTML = avatarMarkup(info.photoURL, info.name);
    lyrameMessagesFilterConversations();
  }).catch(err => console.warn("[conv item]", err));

  el.addEventListener("click", () => openConversation(c.id));
  el.addEventListener("keydown", e => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      openConversation(c.id);
    }
  });
  return el;
}

/* ------------------------------------------------------------
   39. MESSAGE DIRECT — pas de doublon (pairKey déterministe)
   ------------------------------------------------------------ */
async function getOrCreateDirectConversation(otherUid) {
  if (!state.currentUser || !otherUid) return null;
  const myUid = state.currentUser.uid;
  if (myUid === otherUid) return null;

  // Conversation directe déterministe : l'ID est le pairKey.
  // IMPORTANT : ne pas faire une requête collection `where(pairKey == ...)` ici.
  // Les règles Firestore autorisent la lecture d'une conversation seulement aux membres;
  // une requête par pairKey ne prouve pas ce membership à Firestore et peut donc être refusée.
  const pairKey = pairKeyOf(myUid, otherUid);
  const convRef = doc(db, "conversations", pairKey);
  const snap = await getDoc(convRef);

  if (snap.exists()) {
    const data = snap.data() || {};
    const members = Array.isArray(data.memberIds) ? data.memberIds : [];
    if (!members.includes(myUid) || !members.includes(otherUid)) {
      const err = new Error("DIRECT_CONVERSATION_MEMBERS_MISMATCH");
      err.code = "lyrame/direct-members-mismatch";
      throw err;
    }
    return convRef.id;
  }

  // Création uniquement si le document n'existe pas.
  // Ne jamais utiliser merge:true ici sur une conversation existante : cela tenterait
  // de réécrire des champs immuables (memberIds, pairKey, createdAt...) et les règles
  // Firestore refuseraient l'opération.
  await setDoc(convRef, {
    type: "direct",
    isGroup: false,
    pairKey,
    memberIds: [myUid, otherUid],
    createdBy: myUid,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
    lastMessage: "",
    lastMessageAt: serverTimestamp()
  });
  return convRef.id;
}

function directMessageOpenErrorLabel(err) {
  const code = String(err?.code || "unknown").replace(/^firestore\//, "");
  if (code === "permission-denied") return uiText(
    "Ouverture du message refusée par Firestore (permission-denied).",
    "Nolavin'ny Firestore ny fanokafana hafatra (permission-denied).",
    "Firestore refused to open this message (permission-denied)."
  );
  if (code === "unavailable") return uiText(
    "Firestore est momentanément indisponible (unavailable).",
    "Tsy tratra vetivety ny Firestore (unavailable).",
    "Firestore is temporarily unavailable (unavailable)."
  );
  if (code === "lyrame/direct-members-mismatch") return uiText(
    "Cette conversation directe a des membres incohérents.",
    "Tsy mifanaraka ny mpikambana ao amin'ity conversation directe ity.",
    "This direct conversation has inconsistent members."
  );
  const msg = String(err?.message || "").replace(/\s+/g, " ").slice(0, 160);
  return `${uiText("Impossible d’ouvrir la conversation.", "Tsy afaka manokatra conversation.", "Could not open conversation.")} [${code}${msg ? ` — ${msg}` : ""}]`;
}

async function openDirectMessageWith(otherUid) {
  if (!state.currentUser || otherUid === state.currentUser.uid) return;
  try {
    const convId = await getOrCreateDirectConversation(otherUid);
    if (convId) openConversation(convId);
  } catch (err) {
    logError("[open DM]", err);
    toast(directMessageOpenErrorLabel(err));
  }
}

/* ------------------------------------------------------------
   40. CONVERSATION
   ------------------------------------------------------------ */
function setGroupControlsVisible(visible, id) {
  const el = document.getElementById(id);
  if (!el) return;
  if (visible) showEl(el); else hideEl(el);
}

function renderGroupInfo(c) {
  const uid = state.currentUser?.uid;
  const isGroup = !!c?.isGroup;
  const manage = isGroup && canManageGroup(c, uid);
  const owner = isGroup && isGroupOwner(c, uid);
  const isMember = isGroup && Array.isArray(c.memberIds) && c.memberIds.includes(uid);

  setGroupControlsVisible(manage, "group-edit-btn");
  setGroupControlsVisible(manage, "group-add-member-btn");
  setGroupControlsVisible(manage, "group-manage-members-btn");
  setGroupControlsVisible(manage || owner, "group-owner-settings");
  setGroupControlsVisible(isMember, "group-leave-btn");

  if (!isGroup) return;

  setText("group-info-name", c.name || "");
  setText("group-info-description", c.description || "");
  const privLabel = { public: t("privacy_public"), private: t("privacy_private") }[c.privacy] || "";
  setText("group-info-privacy", privLabel);
  setText("group-info-role", owner ? t("group_owner") : (manage ? t("group_admin") : ""));
  setText("group-info-members-count", `${(c.memberIds || []).length} ${t("group_members_count")}`);

  const cover = $("#group-info-cover");
  if (cover) {
    const url = safeUrl(groupCover(c));
    if (cover.tagName === "IMG") { if (url) cover.src = url; else cover.removeAttribute("src"); }
    else cover.style.backgroundImage = url ? `url("${url}")` : "";
  }

  const membersBox = $("#group-members-list");
  if (membersBox) {
    const ids = Array.isArray(c.memberIds) ? c.memberIds.slice() : [];
    Promise.all(ids.map(id => getUserProfile(id))).then(profiles => {
      if (state.activeConvId !== c.id) return;
      membersBox.querySelectorAll(".user-row, .user-card").forEach(node => node.remove());
      toggleEmpty("group-members-empty", ids.length > 0);
      profiles.forEach((p, i) => {
        const u = p || { uid: ids[i], fullname: "", username: "" };
        const row = renderUserCard(u);
        const badge = isGroupOwner(c, ids[i]) ? t("group_owner") : (groupAdminIds(c).includes(ids[i]) ? t("group_admin") : "");
        if (badge) {
          const s = document.createElement("span");
          s.className = "badge small muted";
          s.textContent = badge;
          s.style.marginLeft = "auto";
          row.appendChild(s);
        }
        membersBox.appendChild(row);
      });
    }).catch(() => { /* noop */ });
  }
}

function clearMessageReply() {
  state.messageReplyTo = null;

  hideEl($("#conv-reply-preview"));

  setText("conv-reply-name", "");

  setText("conv-reply-text", "");
}

function setMessageReply(message) {
  if (!message) {
    clearMessageReply();
    return;
  }

  state.messageReplyTo = {
    messageId: message.id,
    senderId: message.senderId || "",
    senderName: message.senderName || "",
    text: (message.text || "").slice(0, 160),
    mediaType: message.mediaType || ""
  };

  setText("conv-reply-name", message.senderName || "");

  setText(
    "conv-reply-text",
    message.text
      ? message.text.slice(0, 160)
      : message.mediaType
        ? `[${message.mediaType}]`
        : ""
  );

  showEl($("#conv-reply-preview"));
}

async function openConversation(convId) {
  if (!convId) {
    return;
  }

  clearMessageReply();

  state.activeConvId = convId;

  state.activeConv = null;

  showScreen("conversation");
  closeEmojiPickers();
  setText("conv-presence", "");
  if (listeners.presence) { listeners.presence(); listeners.presence = null; }
  startConversationDocListener(convId);
  startMessagesListener(convId);
}

function typingDataFromConversation(conv) {
  const me = state.currentUser?.uid;

  if (!me || !conv || !conv.typing) {
    return null;
  }

  const entries = Object.entries(conv.typing);

  for (const [uid, data] of entries) {
    if (uid === me || !data?.active) {
      continue;
    }

    const ms = toDate(data.updatedAt)?.getTime() || 0;

    if (Date.now() - ms <= 5000) {
      return {
        uid,
        name: data.name || ""
      };
    }
  }

  return null;
}

async function writeTypingState(active) {
  if (!state.currentUser || !state.activeConvId) {
    return;
  }

  /* Confidentialité : si l'utilisateur masque sa saisie, ne jamais publier active=true. */
  if (active && state.messageUiSettings?.sendTypingIndicator === false) {
    state.typingActive = false;
    return;
  }

  const uid = state.currentUser.uid;

  try {
    await updateDoc(
      doc(db, "conversations", state.activeConvId),
      {
        [`typing.${uid}`]: {
          active: !!active,
          name: state.currentProfile?.fullname || "",
          updatedAt: serverTimestamp()
        }
      }
    );

    state.typingActive = !!active;

    state.lastTypingWrite = Date.now();
  } catch (err) {
    console.warn("[typing]", err);
  }
}

function handleConversationTyping() {
  if (!state.activeConvId) {
    return;
  }

  if (state.messageUiSettings?.sendTypingIndicator === false) {
    clearTimeout(state.typingTimer);
    state.typingTimer = null;
    if (state.typingActive) writeTypingState(false);
    return;
  }

  const now = Date.now();

  if (!state.typingActive || now - state.lastTypingWrite > 1800) {
    writeTypingState(true);
  }

  clearTimeout(state.typingTimer);

  state.typingTimer = setTimeout(
    () => {
      writeTypingState(false);
    },
    2200
  );
}

function startConversationDocListener(convId) {
  if (listeners.conversationDoc) { listeners.conversationDoc(); listeners.conversationDoc = null; }
  let lastOtherUid = null;

  listeners.conversationDoc = onSnapshot(doc(db, "conversations", convId), async snap => {
    if (state.activeConvId !== convId) return;
    if (!snap.exists()) {
      state.activeConv = null;
      return;
    }
    const c = { id: snap.id, ...snap.data() };
    const uid = state.currentUser?.uid;
    if (Array.isArray(c.memberIds) && uid && !c.memberIds.includes(uid)) {
      /* retiré du groupe */
      state.activeConv = null;
      if (listeners.messages) { listeners.messages(); listeners.messages = null; }
      state.activeConvId = null;
      if (currentScreenName() === "conversation" || currentScreenName() === "group-edit") showScreen("messages");
      return;
    }
    state.activeConv = c;

    const typing = typingDataFromConversation(c);

    const typingEl = $("#conv-typing");

    if (typingEl) {
      if (typing) {
        typingEl.innerHTML = '<span></span><span></span><span></span>';
        typingEl.setAttribute("aria-label", state.lang === "mg" ? "Manoratra" : state.lang === "en" ? "Typing" : "Écrit");
        showEl(typingEl);
      } else {
        typingEl.innerHTML = "";
        hideEl(typingEl);
      }
    }

    const info = await resolveConversationInfo(c);
    if (state.activeConvId !== convId) return;
    const avatar = $("#conv-profile-avatar");
    if (avatar) avatar.innerHTML = avatarMarkup(info.photoURL, info.name);
    applyConversationTheme(c.messageTheme || null);
    const box = $("#conv-header-info");
    if (box) {
      box.innerHTML = `
        <div class="name">${escapeHtml(info.name)}${identityBadgeMarkup(info.badgeProfile)}</div>
        <div class="sub">${escapeHtml(info.sub)}</div>
      `;
    }
    renderGroupInfo(c);

    if (c.isGroup) {
      if (listeners.presence) { listeners.presence(); listeners.presence = null; }
      lastOtherUid = null;
      setText("conv-presence", `${(c.memberIds || []).length} ${t("group_members_count")}`);
    } else if (info.otherUid !== lastOtherUid) {
      lastOtherUid = info.otherUid;
      listenConversationPresence(info.otherUid);
    }
  }, err => logError("[conversation doc]", err));
}

async function markVisibleMessagesRead(convId, docs) {
  if (state.messageUiSettings?.sendReadReceipts === false) return;
  if (!state.currentUser || !convId || !docs?.length) {
    return;
  }

  const me = state.currentUser.uid;

  const batch = writeBatch(db);

  let changed = 0;

  docs.forEach(d => {
    const data = d.data();

    if (data.senderId === me) {
      return;
    }

    const readBy = Array.isArray(data.readBy) ? data.readBy : [];

    if (readBy.includes(me)) {
      return;
    }

    batch.update(d.ref, { readBy: arrayUnion(me) });

    changed++;
  });

  if (!changed) {
    return;
  }

  try {
    await batch.commit();
  } catch (err) {
    console.warn("[read receipts]", err);
  }
}

function startMessagesListener(convId) {
  if (listeners.messages) {
    listeners.messages();
  }

  $("#conv-messages")
    ?.querySelectorAll(".msg")
    .forEach(n => n.remove());

  toggleEmpty("conv-empty", true);

  const q = query(
    collection(db, "conversations", convId, "messages"),
    orderBy("createdAt", "asc"),
    limit(100)
  );

  listeners.messages = onSnapshot(
    q,
    snap => {
      const box = $("#conv-messages");

      if (!box) {
        return;
      }

      box.querySelectorAll(".msg").forEach(n => n.remove());

      if (snap.empty) {
        toggleEmpty("conv-empty", false);

        return;
      }

      toggleEmpty("conv-empty", true);

      const me = state.currentUser?.uid || "";

      snap.forEach(d => {
        const msg = {
          id: d.id,
          ...d.data()
        };

        const deletedFor = Array.isArray(msg.deletedFor) ? msg.deletedFor : [];

        if (deletedFor.includes(me)) {
          return;
        }

        box.appendChild(renderMessage(msg));
      });

      markVisibleMessagesRead(convId, snap.docs);

      box.scrollTop = box.scrollHeight;
    },
    err => logError("[messages]", err)
  );
}

async function deleteMessageForMe(message) {
  if (!state.currentUser || !state.activeConvId || !message?.id) {
    return;
  }

  await updateDoc(
    doc(db, "conversations", state.activeConvId, "messages", message.id),
    {
      deletedFor: arrayUnion(state.currentUser.uid)
    }
  );
}

async function deleteMessageForEveryone(message) {
  if (!state.currentUser || !state.activeConvId || !message?.id) {
    return;
  }

  if (message.senderId !== state.currentUser.uid) {
    toast(t("err_no_permission"));

    return;
  }

  await updateDoc(
    doc(db, "conversations", state.activeConvId, "messages", message.id),
    {
      deletedForEveryone: true,
      text: "",
      mediaURL: "",
      mediaPublicId: "",
      mediaType: "",
      updatedAt: serverTimestamp()
    }
  );
}

function openMessageDeleteActions(message) {
  if (!message) {
    return;
  }

  const modal = openDynamicModal(uiText("Supprimer le message", "Hamafa hafatra", "Delete message"));

  const wrap = document.createElement("div");

  Object.assign(wrap.style, {
    display: "flex",
    flexDirection: "column",
    gap: "8px"
  });

  const mine = styledButton(uiText("Supprimer pour moi", "Hamafa ho ahy", "Delete for me"));

  mine.addEventListener("click", async () => {
    modal.close();

    try {
      await deleteMessageForMe(message);
    } catch (err) {
      logError("[delete message me]", err);

      toast(t("err_generic"));
    }
  });

  wrap.appendChild(mine);

  if (message.senderId === state.currentUser?.uid) {
    const all = styledButton(uiText("Supprimer pour tout le monde", "Hamafa ho an’ny rehetra", "Delete for everyone"), "danger");

    all.addEventListener("click", async () => {
      modal.close();

      const ok = await showConfirm({
        title: uiText("Supprimer le message", "Hamafa hafatra", "Delete message"),
        message: uiText("Supprimer ce message pour tout le monde ?", "Hofafana ho an’ny rehetra ve ity hafatra ity?", "Delete this message for everyone?"),
        confirmText: t("delete"),
        danger: true
      });

      if (!ok) {
        return;
      }

      try {
        await deleteMessageForEveryone(message);
      } catch (err) {
        logError("[delete message all]", err);

        toast(t("err_generic"));
      }
    });

    wrap.appendChild(all);
  }

  modal.body.appendChild(wrap);
}

function renderMessage(m) {
  const el = document.createElement("div");

  const isMe = !!state.currentUser && m.senderId === state.currentUser.uid;

  el.className = "msg " + (isMe ? "me" : "them");

  el.dataset.messageId = m.id || "";

  // Afficher explicitement la provenance IA ; pas d'usurpation du titulaire.
  if(m.lyrameAiAutoReply === true){
    el.classList.add('lyrame-ai-generated');
    const marker=document.createElement('span');
    marker.className='lyrame-ai-marker';
    marker.textContent='✦ Assistant LYRAME · IA';
    marker.setAttribute('aria-label','Réponse générée par intelligence artificielle');
    el.appendChild(marker);
  }

  if (m.deletedForEveryone) {
    const deleted = document.createElement("div");

    deleted.className = "msg-deleted";

    deleted.textContent = state.lang === "mg" ? "Hafatra voafafa" : state.lang === "en" ? "Message deleted" : "Message supprimé";

    el.appendChild(deleted);

    return el;
  }

  if (m.replyTo) {
    const quote = document.createElement("div");

    quote.className = "msg-reply-quote";

    const strong = document.createElement("strong");

    strong.textContent = m.replyTo.senderName || "";

    const span = document.createElement("span");

    span.textContent =
      m.replyTo.text ||
      (m.replyTo.mediaType ? `[${m.replyTo.mediaType}]` : "");

    quote.append(strong, span);

    el.appendChild(quote);
  }

  const safeMedia = safeUrl(m.mediaURL);

  if (safeMedia) {
    const wrap = document.createElement("div");

    wrap.className = `msg-media msg-media-${m.mediaType || "file"}`;

    let node = null;

    if (m.mediaType === "image") {
      node = document.createElement("img");

      node.alt = "";
    } else if (m.mediaType === "video") {
      node = document.createElement("video");

      node.controls = true;

      node.playsInline = true;
    } else if (m.mediaType === "audio") {
      // Vocal compact: supprimer l'onde décorative au-dessus du véritable lecteur.
      // Garder le lecteur HTML5 natif pour Play / Pause / progression.
      el.classList.add("is-audio-message");
      node = document.createElement("audio");
      node.controls = true;
      node.preload = "metadata";
    }

    if (node) {
      node.src = safeMedia;
      wrap.appendChild(node);
      if (m.mediaType === "video") {
        const duration = document.createElement("span");
        duration.className = "video-duration";
        const setDuration = secs => {
          const n = Math.max(0, Math.round(Number(secs) || 0));
          duration.textContent = `${Math.floor(n/60)}:${String(n%60).padStart(2,"0")}`;
        };
        setDuration(m.mediaMeta?.duration || 0);
        node.addEventListener("loadedmetadata", () => setDuration(node.duration), { once:true });
        wrap.appendChild(duration);
      }
      el.appendChild(wrap);
    }
  }

  if (m.text) {
    const text = document.createElement("div");

    text.className = "msg-text";

    text.textContent = m.text;

    el.appendChild(text);
  }

  const meta = document.createElement("div");

  meta.className = "message-status";

  const time = document.createElement("span");

  time.textContent = formatTime(m.createdAt);

  meta.appendChild(time);

  if (isMe) {
    const readBy = Array.isArray(m.readBy) ? m.readBy : [];

    const convMembers = Array.isArray(state.activeConv?.memberIds)
      ? state.activeConv.memberIds
      : [];

    const others = convMembers.filter(uid => uid !== state.currentUser.uid);

    const seen = others.length > 0 && others.every(uid => readBy.includes(uid));

    if (seen) {
      meta.classList.add("read");
      const status = document.createElement("span");
      status.className = "message-seen-icon";
      const seenLabel = state.lang === "mg" ? "Hita" : state.lang === "en" ? "Seen" : "Vu";
      status.setAttribute("aria-label", seenLabel);
      status.title = seenLabel;
      status.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12Z"/><circle cx="12" cy="12" r="2.5"/></svg>`;
      meta.appendChild(status);
    }
  }

  el.appendChild(meta);

  const actions = document.createElement("div");

  actions.className = "message-actions";

  const reply = document.createElement("button");

  reply.type = "button";

  reply.className = "message-action-btn";
  reply.dataset.action = "reply";

  reply.setAttribute("aria-label", state.lang === "mg" ? "Hamaly" : state.lang === "en" ? "Reply" : "Répondre");

  reply.textContent = "↩";

  reply.addEventListener("click", e => {
    e.stopPropagation();

    setMessageReply(m);

    $("#conv-text")?.focus();
  });

  const del = document.createElement("button");

  del.type = "button";

  del.className = "message-action-btn";

  del.setAttribute("aria-label", t("delete"));

  del.textContent = "⋯";

  del.addEventListener("click", e => {
    e.stopPropagation();

    openMessageDeleteActions(m);
  });

  actions.append(reply, del);

  el.appendChild(actions);

  return el;
}

async function handleSendMessage(e) {
  e.preventDefault();
  if (!state.currentUser || !state.activeConvId || state.messageSending) return;
  const input = $("#conv-text");
  const text = (input?.value || "").trim().slice(0, 4000);
  if (!text) return;

  const btn = e.submitter || e.target?.querySelector?.('button[type="submit"]') || $("#conv-form button[type=\"submit\"]");
  const convId = state.activeConvId;
  state.messageSending = true;
  setBusy(btn, true, "...");
  try {
    const msgRef = doc(collection(db, "conversations", convId, "messages"));
    await setDoc(msgRef, {
      senderId: state.currentUser.uid,
      senderName: state.currentProfile?.fullname || "",
      text,
      mediaURL: "",
      mediaPublicId: "",
      mediaType: "",
      replyTo: state.messageReplyTo ? { ...state.messageReplyTo } : null,
      readBy: [state.currentUser.uid],
      deletedFor: [],
      deletedForEveryone: false,
      createdAt: serverTimestamp()
    });

    if (input) input.value = "";
    clearMessageReply();
    clearTimeout(state.typingTimer);
    state.typingTimer = null;
    state.typingActive = false;
    writeTypingState(false).catch?.(() => {});

    updateDoc(doc(db, "conversations", convId), {
      lastMessage: text.slice(0, 120),
      lastMessageAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    }).catch(err => console.warn("[conversation metadata]", err));

    notifyConversationMembers(convId, text, null).catch?.(err => console.warn("[message notification]", err));
    input?.focus();
  } catch (err) {
    logError("[send message]", err);
    toast(firestoreWriteErrorLabel(err, t("err_generic")));
  } finally {
    state.messageSending = false;
    setBusy(btn, false);
  }
}

function clearConversationUploadStatus() {
  const box = $("#conv-upload-preview");

  if (box) {
    box.innerHTML = "";
  }

  setText("conv-upload-label", "");

  setText("conv-upload-percent", "");

  const bar = $("#conv-upload-progress-bar");

  if (bar) {
    bar.style.width = "0%";
  }

  hideEl($("#conv-upload-status"));

  hideEl($("#conv-upload-retry-btn"));

  state.pendingMessageMedia = null;
}

function showConversationUploadPreview(file, kind) {
  const wrap = $("#conv-upload-status");

  const box = $("#conv-upload-preview");

  if (!wrap || !box || !file) {
    return;
  }

  box.innerHTML = "";

  const url = URL.createObjectURL(file);

  let node = null;

  if (kind === "image") {
    node = document.createElement("img");
  } else if (kind === "video") {
    node = document.createElement("video");

    node.controls = true;
    node.muted = true;
    node.playsInline = true;
  }

  if (node) {
    node.src = url;

    const cleanup = () => {
      revokeUrl(url);
    };

    node.addEventListener("load", cleanup, { once: true });

    node.addEventListener("loadeddata", cleanup, { once: true });

    box.appendChild(node);
  }

  setText("conv-upload-label", t("uploading"));

  setText("conv-upload-percent", "0%");

  showEl(wrap);
}

function updateConversationUploadProgress(pct) {
  const n = Math.max(0, Math.min(100, Number(pct) || 0));

  setText("conv-upload-percent", `${n}%`);

  const bar = $("#conv-upload-progress-bar");

  if (bar) {
    bar.style.width = `${n}%`;
  }
}

function cleanupVoiceRecorder({ keepBlob = false } = {}) {
  clearInterval(state.recorderTimer);
  state.recorderTimer = null;

  if (state.recorderAnimationFrame) {
    cancelAnimationFrame(state.recorderAnimationFrame);
  }
  state.recorderAnimationFrame = null;

  try {
    state.recorderAudioContext?.close();
  } catch (_) {}

  state.recorderAudioContext = null;
  state.recorderAnalyser = null;

  if (state.recorderStream) {
    state.recorderStream.getTracks().forEach(track => track.stop());
  }

  state.recorderStream = null;
  state.mediaRecorder = null;
  state.recorderChunks = [];

  if (!keepBlob) {
    revokeUrl(state.recorderUrl);
    state.recorderUrl = "";
    state.recorderBlob = null;
  }
}

function updateVoiceTimer() {
  const seconds = Math.max(
    0,
    Math.floor((Date.now() - state.recorderStartedAt) / 1000)
  );

  const mm = String(Math.floor(seconds / 60)).padStart(2, "0");

  const ss = String(seconds % 60).padStart(2, "0");

  setText("voice-recorder-time", `${mm}:${ss}`);

  if (seconds >= AUDIO_MAX_SEC) {
    stopVoiceRecording();
  }
}

function animateVoiceWaveform() {
  if (!state.recorderAnalyser) {
    return;
  }

  const analyser = state.recorderAnalyser;

  const data = new Uint8Array(analyser.frequencyBinCount);

  analyser.getByteFrequencyData(data);

  const bars = $$("#voice-waveform span");

  bars.forEach((bar, index) => {
    const i = Math.floor(
      (index * data.length) / Math.max(1, bars.length)
    );

    const value = data[i] || 0;

    const height = Math.max(3, Math.round((value / 255) * 23));

    bar.style.height = `${height}px`;
  });

  state.recorderAnimationFrame = requestAnimationFrame(animateVoiceWaveform);
}

function setVoicePreviewPlaying(playing) {
  const btn = $("#voice-recorder-preview-btn");
  if (!btn) return;
  btn.classList.toggle("is-playing", !!playing);
  btn.setAttribute("aria-label", playing
    ? uiText("Mettre en pause", "Ajanony vetivety", "Pause preview")
    : uiText("Visionner le vocal", "Henoy ny vocal", "Preview voice"));
}

function resetVoicePreviewControl({ enabled = false } = {}) {
  const btn = $("#voice-recorder-preview-btn");
  const audio = $("#voice-recorder-preview");
  if (btn) btn.disabled = !enabled;
  if (audio) {
    try { audio.pause(); } catch (_) {}
    try { audio.currentTime = 0; } catch (_) {}
  }
  setVoicePreviewPlaying(false);
}

function toggleVoicePreview() {
  const audio = $("#voice-recorder-preview");
  const btn = $("#voice-recorder-preview-btn");
  if (!audio || !btn || btn.disabled || !audio.src) return;
  if (audio.paused) {
    audio.play().then(() => setVoicePreviewPlaying(true)).catch(err => {
      console.warn("[voice preview]", err);
      toast(t("audio_not_supported"));
    });
  } else {
    audio.pause();
    setVoicePreviewPlaying(false);
  }
}

async function startVoiceRecording() {
  if (
    !navigator.mediaDevices?.getUserMedia ||
    !window.MediaRecorder
  ) {
    toast(t("audio_not_supported"));

    return;
  }

  cleanupVoiceRecorder();
  clearConversationUploadStatus();
  resetVoicePreviewControl({ enabled: false });

  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });

    state.recorderStream = stream;

    const recorder = new MediaRecorder(stream);

    state.mediaRecorder = recorder;

    state.recorderChunks = [];
    state.recorderDiscard = false;

    recorder.addEventListener("dataavailable", event => {
      if (event.data && event.data.size) {
        state.recorderChunks.push(event.data);
      }
    });

    recorder.addEventListener("stop", () => {
      if (state.recorderDiscard) {
        state.recorderDiscard = false;
        cleanupVoiceRecorder();
        hideEl($("#voice-recorder"));
        return;
      }
      const blob = new Blob(state.recorderChunks, {
        type: recorder.mimeType || "audio/webm"
      });

      state.recorderBlob = blob;

      revokeUrl(state.recorderUrl);

      state.recorderUrl = URL.createObjectURL(blob);

      const preview = $("#voice-recorder-preview");

      if (preview) {
        preview.src = state.recorderUrl;
        preview.load();
        preview.addEventListener("ended", () => setVoicePreviewPlaying(false), { once: true });
      }
      resetVoicePreviewControl({ enabled: true });

      hideEl($("#voice-recorder-stop-btn"));

      showEl($("#voice-recorder-send-btn"));

      setText("voice-recorder-status", t("ready_to_send"));

      cleanupVoiceRecorder({ keepBlob: true });
    });

    const AudioContextClass = window.AudioContext || window.webkitAudioContext;

    if (AudioContextClass) {
      const context = new AudioContextClass();

      const source = context.createMediaStreamSource(stream);

      const analyser = context.createAnalyser();

      analyser.fftSize = 128;

      source.connect(analyser);

      state.recorderAudioContext = context;

      state.recorderAnalyser = analyser;

      animateVoiceWaveform();
    }

    state.recorderStartedAt = Date.now();

    setText("voice-recorder-time", "00:00");

    setText("voice-recorder-status", t("recording"));

    resetVoicePreviewControl({ enabled: false });

    hideEl($("#voice-recorder-send-btn"));

    showEl($("#voice-recorder-stop-btn"));

    showEl($("#voice-recorder"));

    recorder.start(250);

    state.recorderTimer = setInterval(updateVoiceTimer, 500);
  } catch (err) {
    logError("[voice recorder]", err);

    toast(t("microphone_denied"));

    cleanupVoiceRecorder();
  }
}

function stopVoiceRecording() {
  if (
    state.mediaRecorder &&
    state.mediaRecorder.state !== "inactive"
  ) {
    try {
      state.mediaRecorder.stop();
    } catch (_) {}
  }
}

function deleteVoiceRecording() {
  const recorder = state.mediaRecorder;
  state.recorderDiscard = true;
  if (recorder && recorder.state !== "inactive") {
    try { recorder.stop(); } catch (_) {}
  }
  cleanupVoiceRecorder();

  const preview = $("#voice-recorder-preview");

  if (preview) {
    preview.removeAttribute("src");

    preview.load();

    hideEl(preview);
  }

  resetVoicePreviewControl({ enabled: false });
  hideEl($("#voice-recorder"));
  clearConversationUploadStatus();

  setText("voice-recorder-time", "00:00");
}

async function convertVoiceBlobToWavFile(blob) {
  if (!blob || !blob.size) return null;
  const Ctx = window.AudioContext || window.webkitAudioContext;
  if (!Ctx) return null;
  let ctx = null;
  try {
    ctx = new Ctx();
    const arr = await blob.arrayBuffer();
    const audio = await ctx.decodeAudioData(arr.slice(0));
    const channels = Math.min(2, Math.max(1, audio.numberOfChannels || 1));
    const rate = audio.sampleRate || 48000;
    const frames = audio.length;
    const bytesPerSample = 2;
    const blockAlign = channels * bytesPerSample;
    const out = new ArrayBuffer(44 + frames * blockAlign);
    const view = new DataView(out);
    const writeStr = (off, str) => { for (let i=0;i<str.length;i++) view.setUint8(off+i,str.charCodeAt(i)); };
    writeStr(0,"RIFF"); view.setUint32(4,36+frames*blockAlign,true); writeStr(8,"WAVE");
    writeStr(12,"fmt "); view.setUint32(16,16,true); view.setUint16(20,1,true); view.setUint16(22,channels,true);
    view.setUint32(24,rate,true); view.setUint32(28,rate*blockAlign,true); view.setUint16(32,blockAlign,true); view.setUint16(34,16,true);
    writeStr(36,"data"); view.setUint32(40,frames*blockAlign,true);
    const data=[]; for(let c=0;c<channels;c++) data.push(audio.getChannelData(c));
    let o=44;
    for(let i=0;i<frames;i++) for(let c=0;c<channels;c++) { const x=Math.max(-1,Math.min(1,data[c][i]||0)); view.setInt16(o,x<0?x*0x8000:x*0x7fff,true); o+=2; }
    return new File([out],`voice-${Date.now()}.wav`,{type:"audio/wav"});
  } catch (err) {
    console.warn("[voice wav fallback]",err);
    return null;
  } finally { try { await ctx?.close(); } catch (_) {} }
}

async function sendRecordedVoice() {
  const blob = state.recorderBlob;

  if (!blob) {
    return;
  }

  const extension = blob.type.includes("ogg")
    ? "ogg"
    : blob.type.includes("mp4")
      ? "m4a"
      : "webm";

  const file = new File(
    [blob],
    `voice-${Date.now()}.${extension}`,
    {
      type: blob.type || "audio/webm"
    }
  );

  let sent = await handleSendMedia(file, "audio");

  // Certains WebView Android produisent un WebM/Opus que Cloudinary refuse de lire.
  // On convertit alors localement en WAV PCM, largement compatible, puis on renvoie.
  if (!sent && blob.size) {
    setText("voice-recorder-status", uiText("Conversion audio…", "Manova audio…", "Converting audio…"));
    const wav = await convertVoiceBlobToWavFile(blob);
    if (wav) sent = await handleSendMedia(wav, "audio");
  }

  if (sent) {
    deleteVoiceRecording();
  } else {
    showEl($("#voice-recorder"));
    resetVoicePreviewControl({ enabled: true });
    showEl($("#voice-recorder-send-btn"));
    setText("voice-recorder-status", t("upload_failed_keep_recording"));
  }
}

async function handleSendMedia(file, kind) {
  if (
    !state.currentUser ||
    !state.activeConvId ||
    !file ||
    state.uploading
  ) {
    return false;
  }

  const check = await validateMedia(file, kind);

  if (!check.ok) {
    toast(check.msg);
    return;
  }

  state.uploading = true;

  state.pendingMessageMedia = { file, kind };

  const isVoiceUpload = kind === "audio";
  if (isVoiceUpload) {
    clearConversationUploadStatus();
    showEl($("#voice-recorder"));
    setText("voice-recorder-status", uiText("Envoi 0%", "Mandefa 0%", "Sending 0%"));
  }

  const controller = new AbortController();

  state.messageUploadAbort = controller;

  if (!isVoiceUpload) {
    const uploadWrap = $("#conv-upload-status");
    if (uploadWrap) uploadWrap.dataset.kind = kind;
    showConversationUploadPreview(file, kind);
  }

  let uploadedPublicId = "";

  try {
    const convId = state.activeConvId;

    const resourceType = kind === "image"
      ? "image"
      : kind === "audio"
        ? "video"
        : "video";

    const up = await uploadMedia(file, {
      folder: `lyrame/conversations/${convId}`,
      resourceType,
      onProgress: isVoiceUpload
        ? pct => setText("voice-recorder-status", uiText(`Envoi ${pct}%`, `Mandefa ${pct}%`, `Sending ${pct}%`))
        : updateConversationUploadProgress,
      signal: controller.signal
    });

    uploadedPublicId = up.publicId;

    const msgRef = doc(collection(db, "conversations", convId, "messages"));

    const batch = writeBatch(db);

    batch.set(msgRef, {
      senderId: state.currentUser.uid,
      senderName: state.currentProfile?.fullname || "",
      text: "",
      mediaURL: up.url,
      mediaPublicId: up.publicId,
      mediaType: kind,
      mediaResourceType: up.resourceType,
      mediaMeta: { duration: up.duration || null, width: up.width || null, height: up.height || null, bytes: up.bytes || null },
      replyTo: state.messageReplyTo ? { ...state.messageReplyTo } : null,
      readBy: [state.currentUser.uid],
      deletedFor: [],
      deletedForEveryone: false,
      createdAt: serverTimestamp()
    });

    batch.update(doc(db, "conversations", convId), {
      lastMessage: `[${kind}]`,
      lastMessageAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });

    await batch.commit();

    uploadedPublicId = "";

    clearMessageReply();
    if (isVoiceUpload) {
      setText("voice-recorder-status", uiText("Envoyé", "Vita nalefa", "Sent"));
    } else {
      clearConversationUploadStatus();
    }

    toast(t("msg_message_sent"));

    notifyConversationMembers(convId, null, kind);
    return true;
  } catch (err) {
    if (isVoiceUpload) {
      if (err?.message === "UPLOAD_ABORTED") {
        setText("voice-recorder-status", t("upload_cancelled"));
      } else {
        logError("[message upload]", err);
        setText("voice-recorder-status", t("upload_failed"));
      }
    } else if (err?.message === "UPLOAD_ABORTED") {
      setText("conv-upload-label", t("upload_cancelled"));
    } else {
      logError("[message upload]", err);
      setText("conv-upload-label", t("upload_failed"));
      showEl($("#conv-upload-retry-btn"));
    }
    return false;
  } finally {
    if (uploadedPublicId) {
      await safeDeleteMediaAsset(uploadedPublicId);
    }

    state.messageUploadAbort = null;

    state.uploading = false;
  }
}

/* ------------------------------------------------------------
   41. GROUPES — CANDIDATS (amis + abonnements), RECHERCHE, CHIPS
   ------------------------------------------------------------ */
async function loadMemberCandidates() {
  const me = state.currentUser?.uid;
  if (!me) return [];
  const ids = new Set(state.friendIds);
  try {
    const snap = await getDocs(query(collection(db, "users", me, "following"), limit(100)));
    snap.forEach(d => ids.add(d.id));
  } catch (e) {
    console.warn("[candidates following]", e);
  }
  ids.delete(me);
  const profiles = await Promise.all(Array.from(ids).map(id => getUserProfile(id)));
  return profiles.filter(Boolean);
}

async function loadGroupCandidates() {
  const box = $("#create-group-members");
  if (!box || !state.currentUser) return;
  const token = ++listTokens.groupCandidates;
  const list = await loadMemberCandidates();
  if (token !== listTokens.groupCandidates) return;
  state.groupCandidates = list;
  renderGroupCandidates();
}

function matchesTerm(u, term) {
  if (!term) return true;
  return (u.fullname || "").toLowerCase().includes(term) || (u.username || "").toLowerCase().includes(term);
}

function renderGroupCandidates() {
  const box = $("#create-group-members");
  if (!box) return;
  const term = ($("#create-group-member-search")?.value || "").trim().toLowerCase().replace(/^@/, "");
  box.querySelectorAll(".user-card").forEach(n => n.remove());
  state.groupCandidates.filter(u => matchesTerm(u, term)).forEach(u => {
    const el = renderUserCard(u);
    const selected = state.groupSelected.has(u.uid);
    el.classList.toggle("selected", selected);
    el.setAttribute("role", "button");
    el.setAttribute("aria-pressed", selected ? "true" : "false");
    /* remplacer le clic "ouvrir profil" par une sélection */
    const clone = el.cloneNode(true);
    clone.addEventListener("click", () => {
      if (state.groupSelected.has(u.uid)) state.groupSelected.delete(u.uid);
      else state.groupSelected.set(u.uid, u);
      renderGroupCandidates();
      renderSelectedMemberChips();
    });
    box.appendChild(clone);
  });
}

function renderSelectedMemberChips() {
  const box = $("#create-group-selected-members");
  if (!box) return;
  box.innerHTML = "";
  state.groupSelected.forEach((u, uid) => {
    const chip = document.createElement("span");
    chip.className = "chip member-chip";
    chip.dataset.uid = uid;
    Object.assign(chip.style, { display: "inline-flex", alignItems: "center", gap: "6px", margin: "2px" });
    const label = document.createElement("span");
    label.textContent = u.fullname || (u.username ? "@" + u.username : "");
    const x = document.createElement("button");
    x.type = "button";
    x.textContent = "✕";
    x.setAttribute("aria-label", t("remove"));
    Object.assign(x.style, { background: "transparent", border: "0", cursor: "pointer", color: "inherit" });
    x.addEventListener("click", () => {
      state.groupSelected.delete(uid);
      renderSelectedMemberChips();
      renderGroupCandidates();
    });
    chip.append(label, x);
    box.appendChild(chip);
  });
}

function renderGroupCoverPreview() {
  const el = $("#create-group-cover-preview");
  if (!el) return;
  const url = safeUrl(state.groupCoverPreviewUrl, { allowBlob: true });
  setPreviewElement(el, url, "");
  const rm = $("#create-group-cover-remove-btn");
  if (rm) { if (url) showEl(rm); else hideEl(rm); }
}

function setPreviewElement(el, url, fallbackName) {
  if (!el) return;
  if (el.tagName === "IMG") {
    if (url) { el.src = url; showEl(el); }
    else { el.removeAttribute("src"); if (!fallbackName) hideEl(el); }
    return;
  }

  const controls = Array.from(el.querySelectorAll(".media-edit-btn"));
  el.querySelectorAll("img, .avatar-fallback").forEach(node => node.remove());
  Array.from(el.childNodes).forEach(node => {
    if (node.nodeType === 3 && node.textContent.trim()) node.remove();
  });

  if (url) {
    const img = document.createElement("img");
    img.src = url;
    img.alt = "";
    el.insertBefore(img, controls[0] || null);
    showEl(el);
    return;
  }

  if (fallbackName) {
    const span = document.createElement("span");
    span.className = "avatar-fallback";
    span.textContent = firstChar(fallbackName);
    el.insertBefore(span, controls[0] || null);
  }
}

async function onGroupCoverChosen(file, input) {
  if (!file) return;
  const check = await validateMedia(file, "image");
  if (!check.ok) { toast(check.msg); if (input) input.value = ""; return; }
  revokeUrl(state.groupCoverPreviewUrl);
  state.groupCoverFile = file;
  state.groupCoverPreviewUrl = URL.createObjectURL(file);
  renderGroupCoverPreview();
}

function removeGroupCover() {
  revokeUrl(state.groupCoverPreviewUrl);
  state.groupCoverFile = null;
  state.groupCoverPreviewUrl = "";
  const photo = $("#create-group-photo"); if (photo) photo.value = "";
  renderGroupCoverPreview();
}

async function handleCreateGroup() {
  if (!state.currentUser || state.uploading) return;
  const myUid = state.currentUser.uid;
  const name = ($("#create-group-name")?.value || "").trim().slice(0, 80);
  const description = ($("#create-group-description")?.value || "").trim().slice(0, 500);
  const privacy = sanitizeGroupPrivacy($("#create-group-privacy")?.value);
  const selected = Array.from(state.groupSelected.keys()).filter(uid => uid && uid !== myUid);

  if (!name) { toast(t("name_required")); return; }
  if (selected.length === 0) { toast(t("members_required")); return; }

  const btn = $("#create-group-submit");
  setBusy(btn, true, "...");
  state.uploading = true;
  let uploadedPublicId = "";

  try {
    let coverURL = "", coverPublicId = "";
    if (state.groupCoverFile) {
      const check = await validateMedia(state.groupCoverFile, "image");
      if (!check.ok) { toast(check.msg); return; }
      try {
        const up = await uploadMedia(state.groupCoverFile, {
          folder: `lyrame/groups/${myUid}`,
          resourceType: "image"
        });
        coverURL = up.url;
        coverPublicId = up.publicId;
        uploadedPublicId = up.publicId;
      } catch (upErr) {
        logError("[group cover upload]", upErr);
        toast(t("err_image_upload"));
        return;
      }
    }

    const memberIds = Array.from(new Set([myUid, ...selected]));
    const ref = await addDoc(collection(db, "conversations"), {
      type: "group",
      isGroup: true,
      name,
      description,
      privacy,
      coverURL,
      coverPublicId,
      memberIds,
      ownerId: myUid,
      adminIds: [myUid],
      createdBy: myUid,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
      lastMessage: "",
      lastMessageAt: serverTimestamp()
    });
    uploadedPublicId = "";

    const who = state.currentProfile?.fullname || uiSomeone();
    await Promise.all(selected.map(uid => createNotification({
      id: `group_${ref.id}_${uid}`,
      userId: uid,
      actorId: myUid,
      type: "group_added",
      title: uiText("Ajouté à un groupe", "Nampidirina tao anaty vondrona", "Added to a group"),
      preview: `${who} ${uiText("vous a ajouté au groupe", "nampiditra anao tao amin’ny vondrona", "added you to the group")} "${name}".`,
      extra: { conversationId: ref.id }
    })));

    toast(t("msg_group_created"));
    resetCreateGroupState();
    state.screenStack = state.screenStack.filter(s => s !== "create-group");
    openConversation(ref.id);
  } catch (err) {
    logError("[create group]", err);
    toast(t("err_generic"));
  } finally {
    if (uploadedPublicId) await safeDeleteMediaAsset(uploadedPublicId);
    setBusy(btn, false);
    state.uploading = false;
  }
}

/* ------------------------------------------------------------
   42. GROUPE — ÉDITION
   ------------------------------------------------------------ */
async function fetchActiveGroup() {
  if (!state.activeConvId) return null;
  const snap = await getDoc(doc(db, "conversations", state.activeConvId));
  if (!snap.exists()) return null;
  const c = { id: snap.id, ...snap.data() };
  return c.isGroup ? c : null;
}

async function loadGroupEdit() {
  const uid = state.currentUser?.uid;
  try {
    const c = await fetchActiveGroup();
    if (!c || !canManageGroup(c, uid)) { toast(t("err_no_permission")); goBack(); return; }
    resetGroupEditTemp();
    const name = $("#group-edit-name"); if (name) name.value = c.name || "";
    const desc = $("#group-edit-description"); if (desc) desc.value = c.description || "";
    const priv = $("#group-edit-privacy"); if (priv) priv.value = c.privacy || "private";
    setPreviewElement($("#group-edit-cover-preview"), safeUrl(groupCover(c)), "");
  } catch (err) {
    logError("[load group edit]", err);
    toast(t("err_generic"));
  }
}

async function onGroupEditCoverChosen(file, input) {
  if (!file) return;
  const check = await validateMedia(file, "image");
  if (!check.ok) { toast(check.msg); if (input) input.value = ""; return; }
  revokeUrl(state.groupEditPreviewUrl);
  state.groupEditFile = file;
  state.groupEditPreviewUrl = URL.createObjectURL(file);
  setPreviewElement($("#group-edit-cover-preview"), safeUrl(state.groupEditPreviewUrl, { allowBlob: true }), "");
}

async function handleGroupEditSave() {
  if (!state.currentUser || state.uploading) return;
  const uid = state.currentUser.uid;
  const btn = $("#group-edit-save-btn");
  setBusy(btn, true, "...");
  state.uploading = true;
  let uploadedPublicId = "";

  try {
    const c = await fetchActiveGroup();
    if (!c) { toast(t("msg_not_a_group")); return; }
    if (!canManageGroup(c, uid)) { toast(t("err_no_permission")); return; }

    const name = ($("#group-edit-name")?.value || "").trim().slice(0, 80);
    if (!name) { toast(t("name_required")); return; }
    const updates = {
      name,
      description: ($("#group-edit-description")?.value || "").trim().slice(0, 500),
      privacy: sanitizeGroupPrivacy($("#group-edit-privacy")?.value),
      updatedAt: serverTimestamp()
    };

    if (state.groupEditFile) {
      try {
        const up = await uploadMedia(state.groupEditFile, {
          folder: `lyrame/groups/${uid}`,
          resourceType: "image"
        });
        updates.coverURL = up.url;
        updates.coverPublicId = up.publicId;
        uploadedPublicId = up.publicId;
      } catch (upErr) {
        logError("[group edit upload]", upErr);
        toast(t("err_image_upload"));
        return;
      }
    }

    /* le doc existe (vérifié ci-dessus) */
    await updateDoc(doc(db, "conversations", c.id), updates);
    uploadedPublicId = "";
    resetGroupEditTemp();
    toast(t("msg_group_updated"));
    goBack();
  } catch (err) {
    logError("[group edit save]", err);
    toast(t("err_generic"));
  } finally {
    if (uploadedPublicId) await safeDeleteMediaAsset(uploadedPublicId);
    setBusy(btn, false);
    state.uploading = false;
  }
}

/* ------------------------------------------------------------
   43. GROUPE — MEMBRES (modal dynamique : plus de window.prompt)
   ------------------------------------------------------------ */
async function addGroupMembers(uids) {
  const me = state.currentUser?.uid;
  const convRef = doc(db, "conversations", state.activeConvId);
  const added = await runTransaction(db, async tx => {
    const snap = await tx.get(convRef);
    if (!snap.exists()) throw new Error("NOT_FOUND");
    const c = snap.data();
    if (!c.isGroup) throw new Error("NOT_GROUP");
    if (!canManageGroup(c, me)) throw new Error("FORBIDDEN");
    const current = new Set(c.memberIds || []);
    const toAdd = uids.filter(u => u && !current.has(u));
    if (!toAdd.length) return [];
    tx.update(convRef, { memberIds: arrayUnion(...toAdd), updatedAt: serverTimestamp() });
    return toAdd.map(u => ({ uid: u, name: c.name || uiGroup() }));
  });

  const who = state.currentProfile?.fullname || uiSomeone();
  await Promise.all(added.map(a => createNotification({
    id: `group_${state.activeConvId}_${a.uid}`,
    userId: a.uid,
    actorId: me,
    type: "group_added",
    title: uiText("Ajouté à un groupe", "Nampidirina tao anaty vondrona", "Added to a group"),
    preview: `${who} ${uiText("vous a ajouté au groupe", "nampiditra anao tao amin’ny vondrona", "added you to the group")} "${a.name}".`,
    extra: { conversationId: state.activeConvId }
  })));
  return added.length;
}

async function removeGroupMember(targetUid) {
  const me = state.currentUser?.uid;
  if (!me || !state.activeConvId || !targetUid) return false;
  const ok = await showConfirm({
    title: t("confirm_remove_member_title"),
    message: t("confirm_remove_member"),
    confirmText: t("remove"),
    danger: true
  });
  if (!ok) return false;

  const convRef = doc(db, "conversations", state.activeConvId);
  try {
    let groupName = "";
    await runTransaction(db, async tx => {
      const snap = await tx.get(convRef);
      if (!snap.exists()) throw new Error("NOT_FOUND");
      const c = snap.data();
      if (!c.isGroup) throw new Error("NOT_GROUP");
      if (!canManageGroup(c, me)) throw new Error("FORBIDDEN");
      if (groupOwnerId(c) === targetUid) throw new Error("OWNER");
      if (!(c.memberIds || []).includes(targetUid)) return;
      groupName = c.name || uiGroup();
      tx.update(convRef, {
        memberIds: arrayRemove(targetUid),
        adminIds: arrayRemove(targetUid),
        updatedAt: serverTimestamp()
      });
    });
    await createNotification({
      id: `group_removed_${state.activeConvId}_${targetUid}`,
      userId: targetUid,
      actorId: me,
      type: "group_removed",
      title: "Retiré d'un groupe",
      preview: `Vous avez été retiré du groupe "${groupName}".`
    });
    toast(t("msg_group_member_removed"));
    return true;
  } catch (err) {
    if (err && err.message === "OWNER") toast(t("err_owner_cannot_be_removed"));
    else if (err && err.message === "FORBIDDEN") toast(t("err_no_permission"));
    else { logError("[remove member]", err); toast(t("err_generic")); }
    return false;
  }
}

async function transferGroupOwnership(targetUid) {
  const me = state.currentUser?.uid;
  if (!me || !state.activeConvId || !targetUid || targetUid === me) return false;
  const ok = await showConfirm({
    title: t("confirm_transfer_title"),
    message: t("confirm_transfer"),
    confirmText: t("confirm_yes")
  });
  if (!ok) return false;

  const convRef = doc(db, "conversations", state.activeConvId);
  try {
    await runTransaction(db, async tx => {
      const snap = await tx.get(convRef);
      if (!snap.exists()) throw new Error("NOT_FOUND");
      const c = snap.data();
      if (!c.isGroup || !isGroupOwner(c, me)) throw new Error("FORBIDDEN");
      if (!(c.memberIds || []).includes(targetUid)) throw new Error("NOT_MEMBER");
      tx.update(convRef, {
        ownerId: targetUid,
        adminIds: Array.from(new Set([...groupAdminIds(c), targetUid])),
        updatedAt: serverTimestamp()
      });
    });
    toast(t("msg_ownership_transferred"));
    return true;
  } catch (err) {
    if (err && err.message === "FORBIDDEN") toast(t("err_no_permission"));
    else { logError("[transfer owner]", err); toast(t("err_generic")); }
    return false;
  }
}

async function handleAddGroupMember() {
  if (!state.activeConvId || !state.currentUser) return;
  const uid = state.currentUser.uid;

  let conv = null;
  try { conv = await fetchActiveGroup(); } catch (e) { logError("[add member load]", e); }
  if (!conv) { toast(t("msg_not_a_group")); return; }
  if (!canManageGroup(conv, uid)) { toast(t("err_no_permission")); return; }

  const modal = openDynamicModal(t("group_manage"));
  const c = modalColors();
  const body = modal.body;

  const sectionTitle = txt => {
    const h = document.createElement("div");
    h.textContent = txt;
    Object.assign(h.style, { fontWeight: "700", fontSize: "13px", margin: "14px 0 6px", color: c.muted, textTransform: "uppercase" });
    return h;
  };

  const membersSection = document.createElement("div");
  const addSection = document.createElement("div");
  body.append(sectionTitle(t("group_members")), membersSection, sectionTitle(t("group_add_members")), addSection);

  const search = styledInput("text", t("search_members"));
  const candidatesBox = document.createElement("div");
  const chipsBox = document.createElement("div");
  chipsBox.style.margin = "8px 0";
  const actions = document.createElement("div");
  Object.assign(actions.style, { display: "flex", gap: "10px", justifyContent: "flex-end", marginTop: "14px" });
  const closeBtn = styledButton(t("close"));
  const addBtn = styledButton(t("add"), "primary");
  actions.append(closeBtn, addBtn);
  addSection.append(search, chipsBox, candidatesBox);
  body.appendChild(actions);

  const selected = new Map();
  let currentConv = conv;
  let candidates = [];
  let searchResults = [];
  let renderToken = 0;

  const rowStyle = el => Object.assign(el.style, {
    display: "flex", alignItems: "center", gap: "10px", padding: "8px 4px", borderBottom: "1px solid " + c.border
  });

  const makeAvatar = u => {
    const av = document.createElement("div");
    av.className = "avatar";
    av.innerHTML = avatarMarkup(u.photoURL, u.fullname);
    return av;
  };

  const renderMembers = async () => {
    const token = ++renderToken;
    const ids = currentConv.memberIds || [];
    const profiles = await Promise.all(ids.map(id => getUserProfile(id)));
    if (token !== renderToken) return;
    membersSection.innerHTML = "";
    profiles.forEach((p, i) => {
      const id = ids[i];
      const u = p || { uid: id, fullname: "", username: "" };
      const row = document.createElement("div");
      rowStyle(row);
      const info = document.createElement("div");
      info.style.flex = "1";
      const nm = document.createElement("div");
      nm.textContent = u.fullname || "";
      nm.style.fontWeight = "600";
      const un = document.createElement("div");
      un.textContent = u.username ? "@" + u.username : "";
      un.style.fontSize = "12px";
      un.style.color = c.muted;
      info.append(nm, un);
      row.append(makeAvatar(u), info);

      if (isGroupOwner(currentConv, id)) {
        const b = document.createElement("span");
        b.textContent = t("group_owner");
        b.style.fontSize = "12px";
        b.style.color = c.muted;
        row.appendChild(b);
      } else {
        if (isGroupOwner(currentConv, uid)) {
          const tr = styledButton(t("group_transfer"));
          tr.style.padding = "6px 10px"; tr.style.fontSize = "12px";
          tr.addEventListener("click", async () => {
            tr.disabled = true;
            const done = await transferGroupOwnership(id);
            tr.disabled = false;
            if (done) await refresh();
          });
          row.appendChild(tr);
        }
        const rm = styledButton(t("remove"), "danger");
        rm.style.padding = "6px 10px"; rm.style.fontSize = "12px";
        rm.addEventListener("click", async () => {
          rm.disabled = true;
          const done = await removeGroupMember(id);
          rm.disabled = false;
          if (done) await refresh();
        });
        row.appendChild(rm);
      }
      membersSection.appendChild(row);
    });
  };

  const renderChips = () => {
    chipsBox.innerHTML = "";
    selected.forEach((u, id) => {
      const chip = document.createElement("span");
      Object.assign(chip.style, {
        display: "inline-flex", alignItems: "center", gap: "6px", padding: "4px 10px",
        borderRadius: "999px", background: c.field, margin: "2px", fontSize: "13px"
      });
      const l = document.createElement("span");
      l.textContent = u.fullname || (u.username ? "@" + u.username : "");
      const x = document.createElement("button");
      x.type = "button";
      x.textContent = "✕";
      Object.assign(x.style, { background: "transparent", border: "0", cursor: "pointer", color: "inherit" });
      x.addEventListener("click", () => { selected.delete(id); renderChips(); renderCandidates(); });
      chip.append(l, x);
      chipsBox.appendChild(chip);
    });
  };

  const renderCandidates = () => {
    const term = search.value.trim().toLowerCase().replace(/^@/, "");
    const memberSet = new Set(currentConv.memberIds || []);
    const merged = new Map();
    candidates.forEach(u => merged.set(u.uid, u));
    searchResults.forEach(u => merged.set(u.uid, u));
    const list = Array.from(merged.values())
      .filter(u => u.uid && !memberSet.has(u.uid) && matchesTerm(u, term));
    candidatesBox.innerHTML = "";
    if (!list.length) {
      const empty = document.createElement("div");
      empty.textContent = t("no_candidates");
      Object.assign(empty.style, { color: c.muted, fontSize: "13px", padding: "8px 0" });
      candidatesBox.appendChild(empty);
      return;
    }
    list.forEach(u => {
      const row = document.createElement("div");
      rowStyle(row);
      row.style.cursor = "pointer";
      const info = document.createElement("div");
      info.style.flex = "1";
      const nm = document.createElement("div");
      nm.textContent = u.fullname || "";
      nm.style.fontWeight = "600";
      const un = document.createElement("div");
      un.textContent = u.username ? "@" + u.username : "";
      un.style.fontSize = "12px";
      un.style.color = c.muted;
      info.append(nm, un);
      const mark = document.createElement("span");
      mark.textContent = selected.has(u.uid) ? "✓" : "";
      row.append(makeAvatar(u), info, mark);
      row.addEventListener("click", () => {
        if (selected.has(u.uid)) selected.delete(u.uid); else selected.set(u.uid, u);
        renderChips();
        renderCandidates();
      });
      candidatesBox.appendChild(row);
    });
  };

  const refresh = async () => {
    try {
      const fresh = await fetchActiveGroup();
      if (!fresh) { modal.close(); return; }
      currentConv = fresh;
    } catch (e) { /* noop */ }
    await renderMembers();
    renderCandidates();
  };

  let searchTimer = null;
  search.addEventListener("input", () => {
    renderCandidates();
    clearTimeout(searchTimer);
    const term = normalizeUsername(search.value);
    searchTimer = setTimeout(async () => {
      if (term.length < 2) { searchResults = []; renderCandidates(); return; }
      try {
        const snap = await getDocs(query(
          collection(db, "users"),
          where("username", ">=", term),
          where("username", "<=", term + "\uf8ff"),
          limit(10)
        ));
        searchResults = snap.docs.map(d => ({ uid: d.id, ...d.data() })).filter(u => u.uid !== uid);
        renderCandidates();
      } catch (e) { console.warn("[member search]", e); }
    }, 300);
  });

  closeBtn.addEventListener("click", () => modal.close());
  addBtn.addEventListener("click", async () => {
    if (!selected.size) { toast(t("members_required")); return; }
    addBtn.disabled = true;
    try {
      const n = await addGroupMembers(Array.from(selected.keys()));
      if (n === 0) toast(t("msg_already_member"));
      else toast(n > 1 ? t("msg_group_members_added") : t("msg_group_member_added"));
      selected.clear();
      renderChips();
      await refresh();
    } catch (err) {
      if (err && err.message === "FORBIDDEN") toast(t("err_no_permission"));
      else { logError("[add members]", err); toast(t("err_generic")); }
    } finally {
      addBtn.disabled = false;
    }
  });

  renderMembers();
  renderCandidates();
  loadMemberCandidates().then(list => {
    candidates = list;
    renderCandidates();
  }).catch(() => { /* noop */ });
}

/* ------------------------------------------------------------
   44. QUITTER LE GROUPE
   ------------------------------------------------------------ */
async function handleLeaveGroup() {
  if (!state.activeConvId || !state.currentUser) return;
  const uid = state.currentUser.uid;
  const convId = state.activeConvId;
  const convRef = doc(db, "conversations", convId);

  let c = null;
  try { c = await fetchActiveGroup(); } catch (e) { logError("[leave load]", e); }
  if (!c) { toast(t("msg_not_a_group")); return; }
  if (!(c.memberIds || []).includes(uid)) { toast(t("msg_not_member")); return; }

  const owner = isGroupOwner(c, uid);
  const others = (c.memberIds || []).filter(id => id !== uid);

  if (owner && others.length > 0) {
    toast(t("err_owner_must_transfer"));
    handleAddGroupMember(); /* ouvre la gestion des membres (transfert) */
    return;
  }

  if (owner && others.length === 0) {
    const ok = await showConfirm({
      title: t("confirm_delete_group_title"),
      message: t("confirm_delete_group"),
      confirmText: t("delete"),
      danger: true
    });
    if (!ok) return;
    try {
      if (listeners.messages) { listeners.messages(); listeners.messages = null; }
      if (listeners.conversationDoc) { listeners.conversationDoc(); listeners.conversationDoc = null; }
      await bestEffortDeleteSubcollection(["conversations", convId, "messages"]);
      await deleteDoc(convRef);
      state.activeConvId = null;
      state.activeConv = null;
      toast(t("msg_group_deleted"));
      showScreen("messages");
    } catch (err) {
      logError("[delete group]", err);
      toast(t("err_generic"));
    }
    return;
  }

  const ok = await showConfirm({
    title: t("confirm_leave_group_title"),
    message: t("confirm_leave_group"),
    confirmText: t("leave"),
    danger: true
  });
  if (!ok) return;

  try {
    await runTransaction(db, async tx => {
      const snap = await tx.get(convRef);
      if (!snap.exists()) return;
      const data = snap.data();
      if (!data.isGroup) throw new Error("NOT_GROUP");
      if (isGroupOwner(data, uid) && (data.memberIds || []).length > 1) throw new Error("OWNER");
      const upd = {
        memberIds: arrayRemove(uid),
        adminIds: arrayRemove(uid),
        updatedAt: serverTimestamp()
      };
      if (Array.isArray(data.memberProfiles)) {
        upd.memberProfiles = data.memberProfiles.filter(p => p && p.uid !== uid);
      }
      tx.update(convRef, upd);
    });

    if (listeners.messages) { listeners.messages(); listeners.messages = null; }
    if (listeners.conversationDoc) { listeners.conversationDoc(); listeners.conversationDoc = null; }
    state.activeConvId = null;
    state.activeConv = null;
    toast(t("msg_group_left"));
    showScreen("messages");
  } catch (err) {
    if (err && err.message === "OWNER") toast(t("err_owner_must_transfer"));
    else if (err && err.message === "NOT_GROUP") toast(t("msg_not_a_group"));
    else { logError("[leave group]", err); toast(t("err_generic")); }
  }
}

/* ------------------------------------------------------------
   45. NOTIFICATIONS
   ------------------------------------------------------------ */
function startNotificationsListener() {
  if (!state.currentUser) return;
  syncMessageUiControls();
  if (listeners.notifications) listeners.notifications();

  /* Pas d'orderBy : évite un index composite. Tri côté client. */
  const q = query(
    collection(db, "notifications"),
    where("userId", "==", state.currentUser.uid),
    limit(100)
  );
  let initialSnapshotDone = false;

  listeners.notifications = onSnapshot(q, snap => {
    const list = $("#notifications-list");
    if (!list) return;

    const messageNotifsAllowed = state.currentProfile?.notificationsEnabled !== false && state.messageUiSettings?.messageNotificationsEnabled !== false;
    if (initialSnapshotDone && messageNotifsAllowed) {
      const incoming = snap.docChanges().some(ch => ch.type === "added" && ch.doc.data()?.type === "message" && ch.doc.data()?.read !== true);
      if (incoming) playMessageNotificationSound(state.messageUiSettings?.messageNotificationSound || "lyrame");
    }
    initialSnapshotDone = true;

    list.querySelectorAll(".notif").forEach(n => n.remove());
    let items = snap.docs.map(d => ({ id: d.id, ...d.data() }));
    if (!messageNotifsAllowed) {
      items = items.filter(n => n.type !== "message");
    }

    if (!items.length) {
      toggleEmpty("notifications-empty", false);
      updateNotificationsToggle();
      updateNotificationBadge(0);
      return;
    }
    toggleEmpty("notifications-empty", true);

    items.sort((a, b) => postTimeMs(b) - postTimeMs(a));

    let unread = 0;
    items.forEach(n => {
      if (n.read !== true) unread++;
      list.appendChild(renderNotification(n));
    });

    applyNotificationsVisibility();
    updateNotificationsToggle();
    updateNotificationBadge(unread);
  }, err => logError("[notifications]", err));
}

function openNotificationTarget(n) {
  const postTypes = ["post", "comment", "reply", "reaction", "mention"];
  const profileTypes = ["follow", "friend_request", "friend_accept"];
  if (postTypes.includes(n.type) && n.postId) { openPostDetail(n.postId); return; }
  if (profileTypes.includes(n.type) && n.actorId) { openOtherProfile(n.actorId); return; }
  if ((n.type === "message" || n.type === "group_added") && n.conversationId) { openConversation(n.conversationId); return; }
  if (n.postId) openPostDetail(n.postId);
  else if (n.conversationId) openConversation(n.conversationId);
}

function localizedNotificationCopy(n) {
  const who = n.actorName || uiSomeone();
  switch (n.type) {
    case "reaction":
      return {
        title: uiText("Nouvelle réaction", "Fihetseham-po vaovao", "New reaction"),
        preview: `${who} ${uiText("a réagi à votre publication.", "naneho fihetseham-po tamin’ny publication-nao.", "reacted to your post.")}`
      };
    case "comment":
      return {
        title: uiText("Nouveau commentaire", "Hevitra vaovao", "New comment"),
        preview: `${who} ${uiText("a commenté votre publication.", "nametraka hevitra tamin’ny publication-nao.", "commented on your post.")}`
      };
    case "reply":
      return {
        title: uiText("Nouvelle réponse", "Valiny vaovao", "New reply"),
        preview: `${who} ${uiText("a répondu à votre commentaire.", "namaly ny hevitrao.", "replied to your comment.")}`
      };
    case "mention":
      return {
        title: uiText("Vous avez été mentionné", "Voatonona ianao", "You were mentioned"),
        preview: `${who} ${uiText("vous a mentionné dans un commentaire.", "nanonona anao tao amin’ny commentaire.", "mentioned you in a comment.")}`
      };
    case "follow":
      return {
        title: uiText("Nouvel abonné", "Mpanaraka vaovao", "New follower"),
        preview: `${who} ${uiText("vous suit maintenant.", "manaraka anao izao.", "is now following you.")}`
      };
    case "friend_request":
      return {
        title: uiText("Demande d’ami", "Fangatahana ho namana", "Friend request"),
        preview: `${who} ${uiText("vous a envoyé une demande d’ami.", "nandefa fangatahana ho namana taminao.", "sent you a friend request.")}`
      };
    case "friend_accept":
      return {
        title: uiText("Demande acceptée", "Nekena ny fangatahana", "Request accepted"),
        preview: `${who} ${uiText("a accepté votre demande d’ami.", "nanaiky ny fangatahanao ho namana.", "accepted your friend request.")}`
      };
    case "group_added":
      return {
        title: uiText("Ajouté à un groupe", "Nampidirina tao anaty vondrona", "Added to a group"),
        preview: `${who} ${uiText("vous a ajouté à un groupe.", "nampiditra anao tao anaty vondrona.", "added you to a group.")}`
      };
    default:
      return {
        title: n.title || uiText("Notification", "Fampandrenesana", "Notification"),
        preview: n.preview || ""
      };
  }
}

function renderNotification(n) {
  const el = document.createElement("div");
  el.className = "notif";
  el.dataset.notifId = n.id;
  el.dataset.read = n.read === true ? "1" : "0";

  const created = n.createdAt?.toMillis?.() || 0;
  const canDelete = created > 0 && (Date.now() - created) > NOTIF_DELETE_AFTER;

  const localized = localizedNotificationCopy(n);
  el.innerHTML = `
    <div class="info">
      <div class="title">${escapeHtml(localized.title)}</div>
      <div class="preview">${escapeHtml(localized.preview)}</div>
      <div class="date">${escapeHtml(formatTime(n.createdAt))}</div>
    </div>
    <div class="actions">
      ${canDelete ? `<button type="button" class="icon-btn sm" data-notif-delete aria-label="${escapeHtml(t("delete"))}">
        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="m6 6 1 14h10l1-14"/></svg>
      </button>` : ""}
    </div>
  `;

  el.addEventListener("click", e => {
    if (e.target.closest("button")) return;
    openNotificationTarget(n);
  });

  el.querySelector("[data-notif-delete]")?.addEventListener("click", async e => {
    e.stopPropagation();
    try {
      await deleteDoc(doc(db, "notifications", n.id));
      toast(t("msg_notif_deleted"));
    } catch (err) {
      logError("[del notif]", err);
      toast(t("err_generic"));
    }
  });
  return el;
}

async function markAllNotificationsRead() {
  const list = $("#notifications-list");
  if (!list || !state.currentUser) return;
  const unreadIds = [];
  list.querySelectorAll(".notif").forEach(el => {
    if (el.dataset.read === "0") unreadIds.push(el.dataset.notifId);
  });
  if (!unreadIds.length) return;
  try {
    for (let i = 0; i < unreadIds.length; i += 400) {
      const batch = writeBatch(db);
      unreadIds.slice(i, i + 400).forEach(id => {
        batch.update(doc(db, "notifications", id), { read: true, readAt: serverTimestamp() });
      });
      await batch.commit();
    }
  } catch (e) {
    console.warn("[mark-read]", e);
  }
}

function applyNotificationsVisibility() {
  const list = $("#notifications-list");
  if (!list) return;
  const showAll = state.notificationsExpanded;
  Array.from(list.querySelectorAll(".notif")).forEach((n, i) => {
    n.style.display = (!showAll && i >= NOTIF_PREVIEW) ? "none" : "";
  });
}

function updateNotificationsToggle() {
  const list   = $("#notifications-list");
  const toggle = $("#notifications-toggle");
  if (!list || !toggle) return;
  const count = list.querySelectorAll(".notif").length;
  if (count <= NOTIF_PREVIEW) { toggle.hidden = true; return; }
  toggle.hidden = false;
  toggle.textContent = state.notificationsExpanded ? uiText("Voir moins", "Hijery kely", "See less") : uiText("Voir tout", "Hijery rehetra", "View all");
}

function updateNotificationBadge(count) {
  const badge = $("#notification-badge");
  if (!badge) return;
  if (count > 0) {
    badge.textContent = count > 99 ? "99+" : String(count);
    badge.classList.remove("hidden");
  } else {
    badge.classList.add("hidden");
  }
}

/* ------------------------------------------------------------
   46. MODIFICATION DU PROFIL
   ------------------------------------------------------------ */
function fillEditProfileForm() {
  const p = state.currentProfile;
  if (!p) return;
  resetProfileEditTemp();
  const set = (id, v) => { const el = document.getElementById(id); if (el) el.value = v; };
  set("edit-fullname", p.fullname || "");
  set("edit-username", p.username || "");
  set("edit-bio", p.bio || "");
  set("edit-birthdate", p.birthdate || "");
  set("edit-birthdate-privacy", p.birthdatePrivacy || "private");
  const online = $("#edit-show-online-status");
  if (online) online.checked = p.showOnlineStatus !== false;

  const avatarURL = safeUrl(p.photoURL || state.currentUser?.photoURL || "");
  setPreviewElement($("#edit-avatar-preview"), avatarURL, p.fullname || "");
  setPreviewElement($("#edit-cover-preview"), safeUrl(p.coverURL), "");
}

async function onProfileMediaChosen(kind, file, input) {
  if (!file) return;
  const check = await validateMedia(file, kind);
  if (!check.ok) { toast(check.msg); if (input) input.value = ""; return; }

  if (kind === "avatar") {
    revokeUrl(state.profileAvatarPreviewUrl);
    state.profileAvatarFile = file;
    state.profileAvatarRemove = false;
    state.profileAvatarSelectedHistory = null;
    state.profileAvatarPreviewUrl = URL.createObjectURL(file);
    setPreviewElement($("#edit-avatar-preview"), state.profileAvatarPreviewUrl, state.currentProfile?.fullname || "");
  } else {
    revokeUrl(state.profileCoverPreviewUrl);
    state.profileCoverFile = file;
    state.profileCoverRemove = false;
    state.profileCoverSelectedHistory = null;
    state.profileCoverPreviewUrl = URL.createObjectURL(file);
    setPreviewElement($("#edit-cover-preview"), state.profileCoverPreviewUrl, "");
  }
}

function removeProfileMedia(kind) {
  if (kind === "avatar") {
    revokeUrl(state.profileAvatarPreviewUrl);
    state.profileAvatarFile = null;
    state.profileAvatarPreviewUrl = "";
    state.profileAvatarRemove = true;
    state.profileAvatarSelectedHistory = null;
    const i = $("#edit-avatar-input"); if (i) i.value = "";
    setPreviewElement($("#edit-avatar-preview"), "", state.currentProfile?.fullname || "");
  } else {
    revokeUrl(state.profileCoverPreviewUrl);
    state.profileCoverFile = null;
    state.profileCoverPreviewUrl = "";
    state.profileCoverRemove = true;
    state.profileCoverSelectedHistory = null;
    const i = $("#edit-cover-input"); if (i) i.value = "";
    setPreviewElement($("#edit-cover-preview"), "", "");
  }
}

function isValidBirthdate(str) {
  if (!str) return true; /* champ vide autorisé */
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(str);
  if (!m) return false;
  const y = Number(m[1]), mo = Number(m[2]), d = Number(m[3]);
  const date = new Date(y, mo - 1, d);
  if (date.getFullYear() !== y || date.getMonth() !== mo - 1 || date.getDate() !== d) return false;
  return y >= 1900 && date.getTime() <= Date.now();
}

async function handleSaveProfile() {
  if (!state.currentUser || state.uploading) return;
  const btn = $("#edit-profile-save");
  setBusy(btn, true, "...");
  state.uploading = true;

  const newPublicIds = [];
  let committed = false;

  try {
    const uid = state.currentUser.uid;
    const fullname    = ($("#edit-fullname")?.value || "").trim().slice(0, 80);
    const newUsername = normalizeUsername($("#edit-username")?.value);
    const bio         = ($("#edit-bio")?.value || "").trim().slice(0, 500);
    const birthdate   = ($("#edit-birthdate")?.value || "").trim();
    const bdPrivacy   = privacyOf($("#edit-birthdate-privacy")?.value, "private");
    const showOnline  = $("#edit-show-online-status") ? !!$("#edit-show-online-status").checked : true;

    if (newUsername && !isValidUsername(newUsername)) { toast(t("err_username_format")); return; }
    if (!isValidBirthdate(birthdate)) { toast(t("err_birthdate")); return; }

    const avatarFile = state.profileAvatarFile;
    const coverFile  = state.profileCoverFile;
    const avatarHistory = state.profileAvatarSelectedHistory;
    const coverHistory  = state.profileCoverSelectedHistory;
    if (avatarFile) { const c = await validateMedia(avatarFile, "avatar"); if (!c.ok) { toast(c.msg); return; } }
    if (coverFile)  { const c = await validateMedia(coverFile, "cover");   if (!c.ok) { toast(c.msg); return; } }

    const oldUsername = state.currentProfile?.username || "";
    const oldAvatarPublicId = state.currentProfile?.avatarPublicId || "";
    const oldCoverPublicId = state.currentProfile?.coverPublicId || "";

    const updates = { bio, birthdate, birthdatePrivacy: bdPrivacy, showOnlineStatus: showOnline };
    if (fullname) updates.fullname = fullname;

    let newAvatarURL = null;
    try {
      if (avatarFile) {
        const up = await uploadMedia(avatarFile, { folder: `lyrame/users/${uid}/avatar`, resourceType: "image" });
        newPublicIds.push(up.publicId);
        newAvatarURL = up.url;
        updates.photoURL = up.url;
        updates.avatarPublicId = up.publicId;
      } else if (avatarHistory?.url) {
        newAvatarURL = avatarHistory.url;
        updates.photoURL = avatarHistory.url;
        updates.avatarPublicId = avatarHistory.publicId || "";
      } else if (state.profileAvatarRemove) {
        newAvatarURL = "";
        updates.photoURL = "";
        updates.avatarPublicId = "";
      }
      if (coverFile) {
        const up = await uploadMedia(coverFile, { folder: `lyrame/users/${uid}/cover`, resourceType: "image" });
        newPublicIds.push(up.publicId);
        updates.coverURL = up.url;
        updates.coverPublicId = up.publicId;
      } else if (coverHistory?.url) {
        updates.coverURL = coverHistory.url;
        updates.coverPublicId = coverHistory.publicId || "";
      } else if (state.profileCoverRemove) {
        updates.coverURL = "";
        updates.coverPublicId = "";
      }
    } catch (upErr) {
      logError("[profile upload]", upErr);
      toast(t("err_image_upload"));
      return;
    }

    const userRef = doc(db, "users", uid);
    const usernameChanged = !!newUsername && newUsername !== oldUsername;
    const base = { uid, email: state.currentUser.email || "" };

    if (usernameChanged) {
      updates.username = newUsername;
      const newRef = doc(db, "usernames", newUsername);
      const oldRef = oldUsername ? doc(db, "usernames", oldUsername) : null;

      await runTransaction(db, async tx => {
        const newSnap = await tx.get(newRef);
        if (newSnap.exists() && newSnap.data().uid !== uid) throw new Error("USERNAME_TAKEN");
        let oldOwned = false;
        if (oldRef) {
          const oldSnap = await tx.get(oldRef);
          oldOwned = oldSnap.exists() && oldSnap.data().uid === uid;
        }
        if (oldOwned) tx.delete(oldRef);
        tx.set(newRef, { uid, username: newUsername, createdAt: serverTimestamp() });
        tx.set(userRef, { ...base, ...updates, updatedAt: serverTimestamp() }, { merge: true });
      });
    } else {
      await setDoc(userRef, { ...base, ...updates, updatedAt: serverTimestamp() }, { merge: true });
    }
    committed = true;

    try {
      const authUpdate = {};
      if (fullname) authUpdate.displayName = fullname;
      if (newAvatarURL !== null) authUpdate.photoURL = newAvatarURL;
      if (Object.keys(authUpdate).length) await updateProfile(state.currentUser, authUpdate);
    } catch (authErr) {
      console.warn("[save profile auth]", authErr);
    }

    if (avatarFile) {
      await saveProfileMediaHistory(uid, "avatar", updates.photoURL, updates.avatarPublicId, avatarFile, {
        fullname: fullname || state.currentProfile?.fullname || state.currentUser?.displayName || "",
        username: newUsername || oldUsername || state.currentProfile?.username || ""
      });
    }
    if (coverFile) {
      await saveProfileMediaHistory(uid, "cover", updates.coverURL, updates.coverPublicId, coverFile, {
        fullname: fullname || state.currentProfile?.fullname || state.currentUser?.displayName || "",
        username: newUsername || oldUsername || state.currentProfile?.username || ""
      });
    }

    /* On conserve les anciennes images pour permettre de les réutiliser depuis l'historique. */

    resetProfileEditTemp();
    profileCache.delete(uid);
    toast(t("msg_profile_saved"));
    goBack();
  } catch (err) {
    if (err && err.message === "USERNAME_TAKEN") toast(t("err_username_taken"));
    else { logError("[save profile]", err); toast(t("err_generic")); }
  } finally {
    if (!committed && newPublicIds.length) {
      await Promise.all(newPublicIds.map(safeDeleteMediaAsset));
    }
    setBusy(btn, false);
    state.uploading = false;
  }
}

/* ------------------------------------------------------------
   47. SÉCURITÉ — CHANGEMENT DE MOT DE PASSE (modal, sans prompt)
   ------------------------------------------------------------ */
function handleChangePassword() {
  if (!state.currentUser || !state.currentUser.email) return;

  const c = modalColors();
  const modal = openDynamicModal(t("pw_title"));
  const form = document.createElement("form");
  form.noValidate = true;
  form.autocomplete = "off";

  const makeField = (label, autocomplete) => {
    const wrap = document.createElement("label");
    Object.assign(wrap.style, { display: "block", margin: "0 0 12px", fontSize: "13px", color: c.muted });
    const cap = document.createElement("span");
    cap.textContent = label;
    const row = document.createElement("div");
    Object.assign(row.style, { position: "relative", marginTop: "4px" });
    const input = styledInput("password");
    input.autocomplete = autocomplete;
    input.style.paddingRight = "44px";
    const eye = document.createElement("button");
    eye.type = "button";
    eye.innerHTML = EYE_OPEN;
    Object.assign(eye.style, {
      position: "absolute", right: "8px", top: "50%", transform: "translateY(-50%)",
      background: "transparent", border: "0", cursor: "pointer", color: c.muted, display: "flex"
    });
    bindPasswordToggle(eye, input);
    row.append(input, eye);
    wrap.append(cap, row);
    return { wrap, input };
  };

  const cur = makeField(t("pw_current"), "current-password");
  const nw  = makeField(t("pw_new"), "new-password");
  const cf  = makeField(t("pw_confirm"), "new-password");

  const row = document.createElement("div");
  Object.assign(row.style, { display: "flex", gap: "10px", justifyContent: "flex-end", marginTop: "6px" });
  const cancel = styledButton(t("cancel"));
  const save = styledButton(t("save"), "primary");
  save.type = "submit";
  row.append(cancel, save);
  form.append(cur.wrap, nw.wrap, cf.wrap, row);
  modal.body.appendChild(form);
  setTimeout(() => cur.input.focus(), 30);

  cancel.addEventListener("click", () => modal.close());
  form.addEventListener("submit", async e => {
    e.preventDefault();
    const currentPass = cur.input.value;
    const newPass = nw.input.value;
    const confirmPass = cf.input.value;
    if (!currentPass || !newPass || !confirmPass) { toast(t("err_required")); return; }
    if (newPass.length < 6) { toast(t("err_weak_password")); return; }
    if (newPass !== confirmPass) { toast(t("err_password_mismatch")); return; }

    save.disabled = true;
    cancel.disabled = true;
    try {
      const cred = EmailAuthProvider.credential(state.currentUser.email, currentPass);
      await reauthenticateWithCredential(state.currentUser, cred);
      await updatePassword(state.currentUser, newPass);
      modal.close();
      toast(t("msg_password_changed"));
    } catch (err) {
      console.error("[change password]", err);
      toast(friendlyAuthError(err));
      save.disabled = false;
      cancel.disabled = false;
    }
  });
}

/* ------------------------------------------------------------
   48. TABS
   ------------------------------------------------------------ */
function clearReportScreenshot() {
  revokeUrl(state.reportScreenshotUrl);

  state.reportScreenshotFile = null;

  state.reportScreenshotUrl = "";

  const input = $("#report-screenshot-input");

  if (input) {
    input.value = "";
  }

  const box = $("#report-screenshot-preview");

  if (box) {
    box.innerHTML = "";
    hideEl(box);
  }

  hideEl($("#report-remove-screenshot-btn"));
}

async function handleReportScreenshot(file) {
  if (!file) {
    return;
  }

  const check = await validateMedia(file, "image");

  if (!check.ok) {
    toast(check.msg);
    return;
  }

  clearReportScreenshot();

  state.reportScreenshotFile = file;

  state.reportScreenshotUrl = URL.createObjectURL(file);

  const box = $("#report-screenshot-preview");

  if (box) {
    const img = document.createElement("img");

    img.src = state.reportScreenshotUrl;

    img.alt = "";

    box.appendChild(img);

    showEl(box);
  }

  showEl($("#report-remove-screenshot-btn"));
}

async function handleReportSubmit(event) {
  event.preventDefault();

  if (!state.currentUser) {
    return;
  }

  const type = $("#report-problem-type")?.value || "other";

  const text = ($("#report-problem-text")?.value || "")
    .trim()
    .slice(0, 3000);

  if (!text) {
    toast(t("err_required"));
    return;
  }

  const button = $("#report-submit-btn");

  setBusy(button, true, "...");

  let screenshotURL = "";

  let screenshotPublicId = "";

  try {
    if (state.reportScreenshotFile) {
      const up = await uploadMedia(state.reportScreenshotFile, {
        folder: `lyrame/support/${state.currentUser.uid}`,
        resourceType: "image",
        onProgress: pct => {
          const bar = $("#report-upload-progress-bar");
          const label = $("#report-upload-progress-text");

          showEl($("#report-upload-progress"));

          if (bar) {
            bar.style.width = `${pct}%`;
          }

          if (label) {
            label.textContent = `${pct}%`;
          }
        }
      });

      screenshotURL = up.url;

      screenshotPublicId = up.publicId;
    }

    await addDoc(collection(db, "supportReports"), {
      reporterUid: state.currentUser.uid,
      reporterEmail: state.currentUser.email || "",
      reporterPhone: state.currentUser.phoneNumber || "",
      reporterName: state.currentProfile?.fullname || "",
      reporterUsername: state.currentProfile?.username || "",
      type,
      message: text,
      screenshotURL,
      screenshotPublicId,
      page: document.body?.dataset?.screen || "",
      userAgent: navigator.userAgent,
      status: "new",
      appVersion: "1.0",
      emailDelivery: "pending_backend",
      createdAt: serverTimestamp()
    });

    const textarea = $("#report-problem-text");

    if (textarea) {
      textarea.value = "";
    }

    clearReportScreenshot();

    hideEl($("#report-upload-progress"));

    setText("report-status", t("report_saved"));
  } catch (err) {
    logError("[support report]", err);

    setText("report-status", "");

    toast(t("err_generic"));
  } finally {
    setBusy(button, false);
  }
}

function clearAccountPhoneVerifier() {
  try { state.accountPhoneRecaptchaVerifier?.clear(); } catch (_) {}
  state.accountPhoneRecaptchaVerifier = null;
  state.accountPhoneConfirmationResult = null;
  document.getElementById("account-phone-recaptcha-container")?.replaceChildren();
}

function ensureAccountPhoneRecaptcha() {
  return createVisiblePhoneCaptcha("accountPhoneRecaptchaVerifier", "account-phone-recaptcha-container", document.querySelector(".account-phone-linker"));
}

function openAccountPhoneLinker() {
  const user = auth.currentUser;
  if (!user) return;
  if (user.phoneNumber) {
    toast(state.lang === "mg" ? "Efa misy laharana finday mifandray amin'ity kaonty ity." : state.lang === "en" ? "A phone number is already linked to this account." : "Un numéro est déjà lié à ce compte.");
    return;
  }
  clearAccountPhoneVerifier();
  const modal = openDynamicModal(state.lang === "mg" ? "Hanampy laharana finday" : state.lang === "en" ? "Add phone number" : "Ajouter un numéro");
  const wrap = document.createElement("div"); wrap.className = "account-phone-linker";
  const phone = document.createElement("input"); phone.type="tel"; phone.inputMode="tel"; phone.placeholder="+261...";
  const send = styledButton(state.lang === "mg" ? "Handefa kaody" : state.lang === "en" ? "Send code" : "Envoyer le code", "primary");
  const code = document.createElement("input"); code.type="text"; code.inputMode="numeric"; code.maxLength=6; code.placeholder="000000"; code.classList.add("hidden");
  const verify = styledButton(state.lang === "mg" ? "Hanamarina" : state.lang === "en" ? "Verify" : "Vérifier", "primary"); verify.classList.add("hidden");
  const status = document.createElement("p"); status.className="form-status";
  send.addEventListener("click", async () => {
    const normalized = normalizePhoneNumber(phone.value);
    if (!/^\+[1-9]\d{7,14}$/.test(normalized)) { status.textContent=t("invalid_phone"); status.dataset.state="error"; return; }
    setBusy(send,true,"...");
    try {
      clearAccountPhoneVerifier();
      const verifier = ensureAccountPhoneRecaptcha();
      await verifier.render();
      state.accountPhoneConfirmationResult = await linkWithPhoneNumber(user, normalized, verifier);
      code.classList.remove("hidden"); verify.classList.remove("hidden");
      status.textContent=t("phone_code_sent"); status.dataset.state="success";
    } catch (err) {
      const msg=phoneAuthMessage(err); status.textContent=msg; status.dataset.state="error"; clearAccountPhoneVerifier();
    } finally { setBusy(send,false); }
  });
  verify.addEventListener("click", async () => {
    const otp=code.value.trim();
    if (!/^\d{6}$/.test(otp) || !state.accountPhoneConfirmationResult) { status.textContent=t("invalid_code"); status.dataset.state="error"; return; }
    setBusy(verify,true,"...");
    try {
      const result=await state.accountPhoneConfirmationResult.confirm(otp);
      await setDoc(doc(db,"users",result.user.uid),{phoneNumber:result.user.phoneNumber||"",authMethod:result.user.email?"email+phone":"phone",updatedAt:serverTimestamp()},{merge:true});
      status.textContent=t("phone_verified"); status.dataset.state="success";
      clearAccountPhoneVerifier(); renderAccountSettings();
      window.setTimeout(()=>modal.close(),500);
    } catch(err) { const msg=phoneAuthMessage(err); status.textContent=msg; status.dataset.state="error"; }
    finally { setBusy(verify,false); }
  });
  wrap.append(phone,send,code,verify,status); modal.body.appendChild(wrap);
}

function renderAccountSettings() {
  const user = state.currentUser;

  if (!user) {
    return;
  }

  setText("account-email-value", user.email || "—");

  setText("account-phone-value", user.phoneNumber || "—");

  setText(
    "account-email-status",
    user.email
      ? (user.emailVerified ? t("verified") : t("not_verified"))
      : ""
  );

  setText(
    "account-phone-status",
    user.phoneNumber ? t("verified") : ""
  );
}

function bindTabs(scopeSelector) {
  const scope = document.querySelector(scopeSelector);
  if (!scope) return;

  const tabs = Array.from(scope.querySelectorAll(".tab"));

  tabs.forEach(tab => {
    tab.addEventListener("click", () => {
      tabs.forEach(other => {
        other.classList.remove("active");
        other.setAttribute("aria-selected", "false");
      });

      tab.classList.add("active");
      tab.setAttribute("aria-selected", "true");

      const tabName = tab.dataset.tab || "posts";

      if (scopeSelector === "#screen-profile-me") {
        state.profileMeTab = tabName;
        renderProfileTab("me");
      }

      if (scopeSelector === "#screen-profile-other") {
        state.profileOtherTab = tabName;
        renderProfileTab("other");
      }
    });
  });
}

function bindAuthMethodSwitches() {
  $$('[data-login-method]').forEach(button => {
    if (button.dataset.lyrameBound === "1") return;
    button.dataset.lyrameBound = "1";
    button.addEventListener("click", () => {
      const method = button.dataset.loginMethod;
      if (!["email", "phone"].includes(method)) return;
      state.loginMethod = method;
      $$('[data-login-method]').forEach(other => {
        const active = other === button;
        other.classList.toggle("active", active);
        other.setAttribute("aria-pressed", active ? "true" : "false");
      });
      const emailSection = $("#login-email-section");
      const phoneSection = $("#login-phone-section");
      const emailInput = $("#login-email");
      const passwordInput = $("#login-password");
      const submit = $("#login-submit-btn");
      if (method === "email") {
        showEl(emailSection); hideEl(phoneSection); showEl(submit);
        if (emailInput) emailInput.required = true;
        if (passwordInput) passwordInput.required = true;
      } else {
        hideEl(emailSection); showEl(phoneSection); hideEl(submit);
        if (emailInput) emailInput.required = false;
        if (passwordInput) passwordInput.required = false;
        window.setTimeout(() => $("#login-phone")?.focus(), 0);
      }
    });
  });

  $$('[data-register-method]').forEach(button => {
    if (button.dataset.lyrameBound === "1") return;
    button.dataset.lyrameBound = "1";
    button.addEventListener("click", () => {
      const method = button.dataset.registerMethod;
      if (!["email", "phone"].includes(method)) return;
      state.registerMethod = method;
      $$('[data-register-method]').forEach(other => {
        const active = other === button;
        other.classList.toggle("active", active);
        other.setAttribute("aria-pressed", active ? "true" : "false");
      });
      const emailSection = $("#register-email-section");
      const phoneSection = $("#register-phone-section");
      const emailInput = $("#register-email");
      const passwordInput = $("#register-password");
      const confirmInput = $("#register-confirm");
      const passwordField = passwordInput?.closest(".field");
      const confirmField = confirmInput?.closest(".field");
      if (method === "email") {
        showEl(emailSection); hideEl(phoneSection);
        if (emailInput) emailInput.required = true;
        if (passwordInput) passwordInput.required = true;
        if (confirmInput) confirmInput.required = true;
        showEl(passwordField); showEl(confirmField);
      } else {
        hideEl(emailSection); showEl(phoneSection);
        if (emailInput) emailInput.required = false;
        if (passwordInput) passwordInput.required = false;
        if (confirmInput) confirmInput.required = false;
        hideEl(passwordField); hideEl(confirmField);
        window.setTimeout(() => $("#register-phone")?.focus(), 0);
      }
    });
  });
}

/* ------------------------------------------------------------
   49. INITIALISATION (chaque contrôle lié UNE seule fois)
   ------------------------------------------------------------ */
function hideUnavailableFeatures() {
  /* Fonctions non réalisables en sécurité côté front : masquées silencieusement */
  ["#security-2fa-btn", "#settings-add-account-btn"].forEach(sel => {
    const el = $(sel);
    if (el) { el.classList.add("hidden"); el.hidden = true; }
  });
  const emailForm = $("#email-reply-form");
  if (emailForm) {
    emailForm.addEventListener("submit", e => e.preventDefault());
    emailForm.querySelectorAll("button, input, textarea").forEach(x => { x.disabled = true; });
  }
}

async function init() {
  applyTheme(state.theme);
  applyTranslations();

  $("#auth-screen")?.classList.remove("hidden");
  $("#app-shell")?.classList.add("hidden");
  if (!$(".auth-panel.active")) showAuthPanel("login");
  else lyrameAndroidRememberScreen("auth:" + $(".auth-panel.active").dataset.screen, false);
  bindAuthMethodSwitches();
  hideUnavailableFeatures();

  /* HEADER */
  $("#header-home-btn")?.addEventListener("click", () => showScreen("home"));
  $("#header-search-btn")?.addEventListener("click", openHeaderInlineSearch);
  $("#search-settings-btn")?.addEventListener("click", () => showScreen("settings"));
  $("#header-theme-btn")?.addEventListener("click", toggleTheme);
  $("#header-notifications-btn")?.addEventListener("click", () => {
    showScreen("notifications");
    setTimeout(() => { markAllNotificationsRead(); }, 800);
  });

  /* NAVIGATION */
  $$(".nav-btn, [data-nav]").forEach(el => {
    el.addEventListener("click", () => {
      const nav = el.dataset.nav;
      if (!nav) return;
      if (nav === "profile-me") state.profileViewUid = null;
      showScreen(nav);
    });
  });
  /* V96.3 : pas de bouton data-back; bouton/geste Retour = Android uniquement. */
  $$("[data-close]").forEach(el => {
    el.addEventListener("click", () => {
      const target = el.dataset.close;
      state.screenStack = state.screenStack.filter(s => s !== target);
      showScreen("home", { push: false });
    });
  });
  $$("[data-goto]").forEach(el => {
    el.addEventListener("click", () => {
      const target = el.dataset.goto;
      if (["login", "register", "forgot"].includes(target)) { showAuthPanel(target); return; }
      if (target === "followers") { openFollowers(); return; }
      if (target === "following") { openFollowing(); return; }
      showScreen(target);
    });
  });

  /* AUTH */
  $("#form-login")?.addEventListener("submit", handleLoginSubmit);
  $("#login-google-btn")?.addEventListener("click", handleGoogleLogin);
  $("#form-register")?.addEventListener("submit", handleRegisterSubmit);
  $("#form-forgot")?.addEventListener("submit", handleForgotSubmit);
  bindPasswordToggle($("#login-password-toggle"), $("#login-password"));
  bindPasswordToggle($("#register-password-toggle"), $("#register-password"));
  bindPasswordToggle($("#register-confirm-toggle"), $("#register-confirm"));

  /* CATÉGORIES */
  $$(".chip[data-category]").forEach(chip => {
    chip.addEventListener("click", () => {
      $$(".chip[data-category]").forEach(c => c.classList.remove("active"));
      chip.classList.add("active");
      state.activeCategory = chip.dataset.category;
      if (state.currentUser) void lyrameV96RenderFeed();
    });
  });

  /* CRÉER */
  $("#create-mention-btn")?.addEventListener("click", openMentionFriends);
  $("#create-background-btn")?.addEventListener("click", () => { renderBackgroundPicker(); showEl($("#create-background-picker")); });
  $("#create-background-close")?.addEventListener("click", () => hideEl($("#create-background-picker")));
  $("#create-add-photo")?.addEventListener("click", () => $("#create-photo-input")?.click());
  $("#create-add-video")?.addEventListener("click", () => $("#create-video-input")?.click());
  $("#create-photo-input")?.addEventListener("change", e => onPostMediaChosen(e.target.files, "image", e.target));
  $("#create-video-input")?.addEventListener("change", e => onPostMediaChosen(e.target.files[0], "video", e.target));
  bindImageRatioButtons();
  $("#create-remove-media-btn")?.addEventListener("click", clearSelectedPostMedia);
  $("#create-title")?.addEventListener("input", updatePublishState);
  $("#create-text")?.addEventListener("input", () => { updatePublishState(); renderPostMediaPreview(); });
  $("#create-rich-editor")?.addEventListener("input", () => { updatePublishState(); renderPostMediaPreview(); });
  $("#create-privacy")?.addEventListener("change", e => {
    if (!POST_PRIVACY_VALUES.includes(e.target.value)) e.target.value = "public";
  });
  const privSel = $("#create-privacy"); if (privSel && !privSel.value) privSel.value = "public";
  $("#create-publish-btn")?.addEventListener("click", handlePublishPost);
  bindFormatToolbar();
  updatePublishState();

  /* COMMENTAIRES */
  $("#comment-form")?.addEventListener("submit", handleCommentSubmit);
  $("#comment-anonymous-btn")?.addEventListener("click", e => { state.commentAnonymous = !state.commentAnonymous; e.currentTarget.setAttribute("aria-pressed", state.commentAnonymous ? "true" : "false"); e.currentTarget.textContent = state.commentAnonymous ? "∞" : "◉"; });
  $("#comment-submit-btn")?.addEventListener("click", e => {
    const form = $("#comment-form");
    if (e.currentTarget.type === "submit" && form && form.contains(e.currentTarget)) return;
    handleCommentSubmit({ preventDefault() {}, target: form || document.body });
  });
  $("#comment-emoji-btn")?.addEventListener("click", e => {
    e.stopPropagation();
    toggleEmojiPicker("comment-emoji-picker", e.currentTarget, () => $("#comment-text"), async em => {
      hideEl($("#comment-emoji-picker"));
      const reply = state.commentReplyTo;
      await sendQuickCommentContent({ text:em, parentId:reply?.id || null, replyTarget:reply, isAnonymous:!!state.commentAnonymous });
    });
  });
  $("#comment-sticker-btn")?.addEventListener("click", e => {
    e.stopPropagation();
    const reply = state.commentReplyTo;
    const context = [reply?.text || "", stickerById(reply?.stickerId)?.mg || "", currentPostStickerContext()].join(" ");
    toggleCommentStickerPicker("comment-sticker-picker", e.currentTarget, context, async stickerId => {
      await sendQuickCommentContent({ stickerId, parentId:reply?.id || null, replyTarget:reply, isAnonymous:!!state.commentAnonymous });
    });
  });
  $("#comment-image-btn")?.addEventListener("click", () => { const input=$("#comment-image-input"); if(input){ input.accept="image/*"; input.click(); } });
  $("#comment-gif-btn")?.addEventListener("click", () => { const input=$("#comment-image-input"); if(input){ input.accept="image/gif"; input.click(); } });
  $("#comment-mention-btn")?.addEventListener("click", () => {
    const ta = $("#comment-text");
    if (!ta) return;
    const pos = Number.isFinite(ta.selectionStart) ? ta.selectionStart : ta.value.length;
    const before = ta.value.slice(0, pos);
    const after = ta.value.slice(pos);
    const spacer = before && !/\s$/.test(before) ? " " : "";
    ta.value = before + spacer + "@" + after;
    const next = before.length + spacer.length + 1;
    ta.setSelectionRange(next, next);
    ta.focus();
    updateCommentSubmitState();
  });
  $("#comment-image-input")?.addEventListener("change", e => onCommentMediaChosen(e.target.files?.[0], "image", e.target));
  $("#comment-video-btn")?.addEventListener("click", () => $("#comment-video-input")?.click());
  $("#comment-video-input")?.addEventListener("change", e => onCommentMediaChosen(e.target.files?.[0], "video", e.target));
  $("#comment-audio-btn")?.addEventListener("click", () => $("#comment-audio-input")?.click());
  $("#comment-audio-input")?.addEventListener("change", e => onCommentMediaChosen(e.target.files?.[0], "audio", e.target));
  $("#comment-image-remove")?.addEventListener("click", removeCommentImage);
  $("#comment-text")?.addEventListener("input", e => {
    updateCommentSubmitState();
    refreshCommentMentionSuggestions(e.target, state.commentMentionSelections);
  });
  $("#comments-toggle")?.addEventListener("click", () => {
    state.commentsExpanded = !state.commentsExpanded;
    applyCommentsVisibility();
    updateCommentsToggle();
  });
  renderCommentImagePreview();
  updateCommentSubmitState();

  /* RÉACTIONS (délégation) */
  document.addEventListener("click", e => {
    const opt = e.target.closest("#reaction-picker [data-reaction]");
    if (!opt) return;
    e.stopPropagation();
    const postId = state.activeReactionPostId;
    closeReactionPicker();
    if (postId) toggleReaction(postId, opt.dataset.reaction);
  });

  /* NOTIFICATIONS */
  $("#notifications-toggle")?.addEventListener("click", () => {
    state.notificationsExpanded = !state.notificationsExpanded;
    applyNotificationsVisibility();
    updateNotificationsToggle();
  });

  /* MESSAGES */
  $("#messages-create-group-btn")?.addEventListener("click", () => showScreen("create-group"));
  $("#conv-form")?.addEventListener("submit", handleSendMessage);

  $("#conv-text")?.addEventListener(
    "input",
    handleConversationTyping
  );

  $("#conv-reply-cancel-btn")?.addEventListener(
    "click",
    clearMessageReply
  );

  $("#conv-emoji-btn")?.addEventListener("click", e => {
    e.stopPropagation();
    toggleEmojiPicker(
      "conv-emoji-picker",
      e.currentTarget,
      () => $("#conv-text")
    );
  });

  $("#conv-image-btn")?.addEventListener(
    "click",
    () => $("#conv-image-input")?.click()
  );

  $("#conv-video-btn")?.addEventListener(
    "click",
    () => $("#conv-video-input")?.click()
  );

  $("#conv-audio-btn")?.addEventListener(
    "click",
    startVoiceRecording
  );

  $("#voice-recorder-preview-btn")?.addEventListener("click", toggleVoicePreview);
  $("#voice-recorder-stop-btn")?.addEventListener("click", stopVoiceRecording);
  $("#voice-recorder-delete-btn")?.addEventListener("click", deleteVoiceRecording);
  $("#voice-recorder-send-btn")?.addEventListener("click", sendRecordedVoice);
  $("#conv-audio-call-btn")?.addEventListener("click", () => startOutgoingCall("audio"));
  $("#conv-video-call-btn")?.addEventListener("click", () => startOutgoingCall("video"));

  [
    ["#conv-image-input", "image"],
    ["#conv-video-input", "video"],
    ["#conv-audio-input", "audio"]
  ].forEach(([sel, kind]) => {
    $(sel)?.addEventListener("change", async e => {
      const input = e.target;
      const file = input.files && input.files[0];

      try {
        await handleSendMedia(file, kind);
      } finally {
        input.value = "";
      }
    });
  });

  /*
    INFORMATIONS CONVERSATION

    Groupe:
    -> ouvre screen-group-info

    Message direct:
    -> ouvre le profil de l'autre utilisateur
  */
  const openActiveConversationInfo = async () => {
    const conv = state.activeConv;

    if (!conv || !state.currentUser) return;

    if (conv.isGroup) {
      renderGroupInfo(conv);
      showScreen("group-info");
      return;
    }

    try {
      const info = await resolveConversationInfo(conv);

      if (info?.otherUid) {
        openOtherProfile(info.otherUid);
      }
    } catch (err) {
      logError("[conversation info]", err);
    }
  };

  $("#conv-info-btn")?.addEventListener(
    "click",
    openConversationSettings
  );

  $("#conv-header-info")?.addEventListener(
    "click",
    openActiveConversationInfo
  );

  $("#conv-profile-btn")?.addEventListener(
    "click",
    openActiveConversationInfo
  );

  /* GROUPES */
  $("#create-group-submit")?.addEventListener("click", handleCreateGroup);
  $("#create-group-cover-btn")?.addEventListener("click", () => $("#create-group-photo")?.click());
  $("#create-group-photo")?.addEventListener("change", e => onGroupCoverChosen(e.target.files[0], e.target));
  $("#create-group-cover-remove-btn")?.addEventListener("click", removeGroupCover);
  $("#create-group-member-search")?.addEventListener("input", renderGroupCandidates);
  $("#group-edit-btn")?.addEventListener("click", () => showScreen("group-edit"));
  $("#group-manage-members-btn")?.addEventListener("click", handleAddGroupMember);
  $("#group-add-member-btn")?.addEventListener("click", handleAddGroupMember);
  $("#group-leave-btn")?.addEventListener("click", handleLeaveGroup);
  $("#group-edit-cover-btn")?.addEventListener("click", () => $("#group-edit-cover-input")?.click());
  $("#group-edit-cover-input")?.addEventListener("change", e => onGroupEditCoverChosen(e.target.files[0], e.target));
  $("#group-edit-save-btn")?.addEventListener("click", handleGroupEditSave);

  /* MODAL DE CONFIRMATION */
  $("#confirm-modal-cancel")?.addEventListener("click", () => resolveConfirm(false));
  $("#confirm-modal-confirm")?.addEventListener("click", () => resolveConfirm(true));
  $("#confirm-modal")?.addEventListener("click", e => {
    if (e.target === e.currentTarget) resolveConfirm(false);
  });

  /* Un seul bouton Modifier le profil, directement visible. */
  $("#profile-me-edit-btn")?.addEventListener("click", () => showScreen("edit-profile"));
  bindTabs("#screen-profile-me");
  bindTabs("#screen-profile-other");

  /* PROFIL AUTRE */
  $("#profile-other-follow-btn")?.addEventListener("click", toggleFollow);
  $("#profile-other-friend-btn")?.addEventListener("click", handleFriendButtonClick);
  $("#profile-other-message-btn")?.addEventListener("click", () => {
    if (state.profileViewUid) openDirectMessageWith(state.profileViewUid);
  });

  /* MODIFIER PROFIL */
  $("#edit-profile-save")?.addEventListener("click", handleSaveProfile);
  $("#edit-cover-change-btn")?.addEventListener("click", () => $("#edit-cover-input")?.click());
  $("#edit-cover-history-btn")?.addEventListener("click", event => {
    event.stopPropagation();
    openProfileMediaHistory("cover");
  });
  $("#edit-avatar-change-btn")?.addEventListener("click", () => $("#edit-avatar-input")?.click());
  $("#edit-avatar-preview")?.addEventListener("click", event => {
    if (event.target.closest(".media-edit-btn")) return;
    openProfileMediaHistory("avatar");
  });
  $("#edit-avatar-preview")?.addEventListener("keydown", event => {
    if (event.target.closest(".media-edit-btn")) return;
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      openProfileMediaHistory("avatar");
    }
  });
  $("#edit-cover-input")?.addEventListener("change", e => onProfileMediaChosen("cover", e.target.files[0], e.target));
  $("#edit-avatar-input")?.addEventListener("change", e => onProfileMediaChosen("avatar", e.target.files[0], e.target));
  $("#edit-avatar-remove-btn")?.addEventListener("click", () => removeProfileMedia("avatar"));
  $("#edit-cover-remove-btn")?.addEventListener("click", () => removeProfileMedia("cover"));
  $("#edit-birthdate")?.addEventListener("change", e => {
    if (!isValidBirthdate(e.target.value)) { toast(t("err_birthdate")); e.target.value = ""; }
  });
  $("#edit-birthdate-privacy")?.addEventListener("change", e => {
    if (!POST_PRIVACY_VALUES.includes(e.target.value)) e.target.value = "private";
  });
  $("#edit-show-online-status")?.addEventListener("change", () => { /* appliqué à l'enregistrement */ });

  /* PARAMÈTRES */
  $("#settings-report-btn")?.addEventListener("click", () => {
    showScreen("report-problem");
  });

  $("#report-add-screenshot-btn")?.addEventListener("click", () => {
    $("#report-screenshot-input")?.click();
  });

  $("#report-screenshot-input")?.addEventListener("change", event => {
    handleReportScreenshot(event.target.files?.[0]);
  });

  $("#report-remove-screenshot-btn")?.addEventListener("click", clearReportScreenshot);
  $("#report-problem-form")?.addEventListener("submit", handleReportSubmit);

  $("#settings-account-btn")?.addEventListener("click", () => {
    renderAccountSettings();
    showScreen("account");
  });

  $("#account-add-phone-btn")?.addEventListener("click", openAccountPhoneLinker);

  $("#account-change-password-btn")?.addEventListener("click", () => {
    if (!state.currentUser?.email) {
      toast(t("phone_account_no_password"));
      return;
    }
    handleChangePassword();
  });

  $("#settings-find-account-btn")?.addEventListener("click", () => showScreen("search"));
  $("#settings-security-btn")?.addEventListener("click", () => showScreen("security"));
  $("#settings-language-btn")?.addEventListener("click", () => showScreen("languages"));
  $("#settings-clear-cache-btn")?.addEventListener("click", () => {
    profileCache.clear();
    profilePending.clear();
    toast(t("msg_cache_cleared"));
  });
  $("#settings-clear-data-btn")?.addEventListener("click", () => {
    /* Les données durables du compte restent dans Firestore : ce bouton ne détruit que la mémoire temporaire. */
    profileCache.clear();
    profilePending.clear();
    toast(t("msg_data_cleared"));
  });
  $("#settings-about-btn")?.addEventListener("click", () => showScreen("about"));
  $("#link-test-form")?.addEventListener("submit", handleLinkTestSubmit);
  $("#link-test-input")?.addEventListener("input", () => {
    $("#link-test-result")?.classList.add("hidden");
    $("#link-test-open-btn")?.classList.add("hidden");
    lastVerifiedPublicLink="";
  });
  $("#link-test-open-btn")?.addEventListener("click", () => {
    if(!lastVerifiedPublicLink)return;
    window.open(lastVerifiedPublicLink,"_blank","noopener,noreferrer");
  });
  $("#settings-logout-btn")?.addEventListener("click", handleLogout);

  /* SÉCURITÉ */
  $("#security-change-password-btn")?.addEventListener("click", handleChangePassword);

  /* LANGUES */
  document.addEventListener("click", e => {
    const item = e.target.closest(".lang-item");
    if (!item) return;
    setLang(item.dataset.lang);
  });

  /* RECHERCHE */
  $("#search-input")?.addEventListener("input", onSearchInput);

  /* CLIC EXTÉRIEUR : menus, pickers, menus propriétaire */
  document.addEventListener("click", e => {
    const target = e.target;
    if (!target.closest("#reaction-picker, [data-act='react']")) closeReactionPicker();
    if (!target.closest("#comment-emoji-picker, #comment-emoji-btn")) hideEl($("#comment-emoji-picker"));
    if (!target.closest(".comment-sticker-picker, #comment-sticker-btn, [data-thread-sticker]")) hideCommentStickerPickers();
    if (!target.closest("#conv-emoji-picker, #conv-emoji-btn")) hideEl($("#conv-emoji-picker"));
    if (!target.closest(".post-owner-menu")) closeOwnerMenus();
  });

  /* ESCAPE : ferme ce qui est ouvert, sans gêner la saisie */
  document.addEventListener("keydown", e => {
    if (e.key !== "Escape") return;
    if (confirmResolver) { resolveConfirm(false); return; }
    if (dynamicModals.length) { dynamicModals[dynamicModals.length - 1].close(); return; }
    if (anyPopupOpen()) closeAllPopups();
  });

  /* Navigation native Android et retour navigateur : aucun bouton écran ajouté. */
  window.addEventListener("popstate", lyrameAndroidOnPopState);

  /* PRÉSENCE */
  document.addEventListener("visibilitychange", onVisibilityChange);
  window.addEventListener("beforeunload", onBeforeUnload);
  window.addEventListener("pagehide", onBeforeUnload);

  /* AUTH PHONE — binding idempotent déjà installé au début de init */
  bindAuthMethodSwitches();
  $("#login-send-code-btn")?.addEventListener("click", sendLoginPhoneVerificationCode);
  $("#login-verify-code-btn")?.addEventListener("click", verifyLoginPhoneCode);
  $("#register-send-code-btn")?.addEventListener("click", sendPhoneVerificationCode);
  $("#register-verify-code-btn")?.addEventListener("click", verifyPhoneCode);

  configureCallButtons();

  /* V61 — Les contrôles de connexion sont liés avant Firebase.
     Le filet de sécurité HTML n'intervient plus si le module s'est lancé. */
  window.__lyrameAuthEventsReady = true;

  /* AUTH — la persistance AVANT l'observer */
  await configureAuthPersistence();
  onAuthStateChanged(auth, handleAuthState, err => {
    console.error("[AUTH OBSERVER ERROR]", err);
  });
}


/* ------------------------------------------------------------
   49B. SPLASH LYRAME — Orbit + étoile énergétique
   ------------------------------------------------------------ */
function initSplashAnimation() {
  const splash=document.getElementById('lyrame-splash');
  if(!splash)return;
  let closed=false;
  const close=()=>{if(closed)return;closed=true;splash.classList.add('is-done');splash.style.pointerEvents='none';splash.setAttribute('aria-hidden','true');setTimeout(()=>splash.remove(),700)};
  const ms=window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 500 : 2150;
  window.setTimeout(close,ms);
  window.setTimeout(close,3000); // filet de sécurité
}

/* ------------------------------------------------------------
   50. LANCEMENT
   ------------------------------------------------------------ */
window.addEventListener("unhandledrejection", ev => {
  console.error("[unhandled rejection]", ev.reason);
});

document.addEventListener("DOMContentLoaded", () => {
  init().catch(err => {
    console.error("[INIT FATAL]", err);
  });
});

window.addEventListener("DOMContentLoaded", initSplashAnimation, { once: true });

/* ------------------------------------------------------------
   LYRAME CLOUD ACCOUNT PREFERENCES
   Firestore is the source of truth for account-scoped UI data.
   No app feature relies on localStorage for durable persistence.
   ------------------------------------------------------------ */
async function saveAccountUiPreferences(patch = {}) {
  if (!state.currentUser || !patch || typeof patch !== "object") return;
  const clean = {};
  if (patch.uiTheme !== undefined) clean.uiTheme = patch.uiTheme === "dark" ? "dark" : "light";
  if (patch.uiLang !== undefined) clean.uiLang = SUPPORTED_UI_LANGS.has(patch.uiLang) ? patch.uiLang : "fr";
  if (patch.searchRecents !== undefined) clean.searchRecents = (Array.isArray(patch.searchRecents) ? patch.searchRecents : []).slice(0, 12).map(x => ({
    type: String(x?.type || "").slice(0, 30),
    id: String(x?.id || "").slice(0, 160),
    label: String(x?.label || "").slice(0, 180)
  })).filter(x => x.id && x.type);
  if (patch.hiddenSuggestionIds !== undefined) clean.hiddenSuggestionIds = [...new Set(Array.isArray(patch.hiddenSuggestionIds) ? patch.hiddenSuggestionIds : [])].map(String).filter(Boolean).slice(0, 250);
  if (!Object.keys(clean).length) return;
  try {
    await setDoc(doc(db, "users", state.currentUser.uid), { ...clean, updatedAt: serverTimestamp() }, { merge: true });
    state.currentProfile = { ...(state.currentProfile || {}), ...clean };
  } catch (err) { console.warn("[cloud ui prefs]", err); }
}

function hydrateAccountUiPreferences(profile = {}) {
  const nextTheme = profile.uiTheme === "dark" ? "dark" : "light";
  const nextLang = SUPPORTED_UI_LANGS.has(profile.uiLang) ? profile.uiLang : "fr";
  if (state.theme !== nextTheme) applyTheme(nextTheme, { persist: false });
  if (state.lang !== nextLang) {
    state.lang = nextLang;
    applyTranslations();
  }
  state.recentSearches = Array.isArray(profile.searchRecents) ? profile.searchRecents.slice(0, 12) : [];
  state.suggestionsHidden = new Set(Array.isArray(profile.hiddenSuggestionIds) ? profile.hiddenSuggestionIds.map(String) : []);
}

function persistSearchRecentsCloud() {
  if (state.currentUser) void saveAccountUiPreferences({ searchRecents: state.recentSearches });
}
function persistHiddenSuggestionsCloud() {
  if (state.currentUser) void saveAccountUiPreferences({ hiddenSuggestionIds: [...state.suggestionsHidden] });
}

/* ============================================================
   51. FINAL INTEGRATED FEATURES — Cahier des charges LYRAME
   ============================================================ */
Object.assign(state, {
  selectedPostPhotos: [],
  mediaViewerItems: [], mediaViewerIndex: 0,
  activePageId: "", activeListingId: "",
  storyTimer: null,
  suggestionsHidden: new Set(),
  recentSearches: []
});

function openHeaderInlineSearch() {
  const header = document.querySelector(".app-header");
  header?.classList.add("searching");
  showEl($("#header-inline-search"));
  window.setTimeout(() => $("#header-search-input")?.focus(), 0);
}
function closeHeaderInlineSearch() {
  document.querySelector(".app-header")?.classList.remove("searching");
  hideEl($("#header-inline-search"));
}

function finalSvgIcon(kind) {
  const icons = {
    react:'<svg class="action-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M7 10v11H3V10h4Zm4 11h7.3a2 2 0 0 0 2-1.6l1.4-7A2 2 0 0 0 19.7 10H15l.7-3.5A2.5 2.5 0 0 0 13.2 3L9 10v11h2Z"/></svg>',
    comment:'<svg class="action-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a3 3 0 0 1-3 3H8l-5 4V6a3 3 0 0 1 3-3h12a3 3 0 0 1 3 3Z"/></svg>',
    share:'<svg class="action-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="m8.6 10.5 6.8-4M8.6 13.5l6.8 4"/></svg>'
  };
  return icons[kind] || "";
}

/* ---------- multi-photos publication ---------- */
onPostMediaChosen = async function(fileOrFiles, kind, input) {
  const files = Array.from(fileOrFiles?.length !== undefined && !fileOrFiles?.name ? fileOrFiles : (fileOrFiles ? [fileOrFiles] : []));
  if (!files.length) return;
  if (kind === "image") {
    const accepted = [];
    for (const file of files.slice(0, 10)) {
      const check = await validateMedia(file, "image");
      if (!check.ok) { toast(check.msg); continue; }
      accepted.push({ file, kind:"image", url:URL.createObjectURL(file) });
    }
    state.selectedPostPhotos.forEach(x => revokeUrl(x.url));
    state.selectedPostPhotos = accepted;
    state.selectedPostMedia = accepted.length === 1 ? accepted[0] : null;
    state.selectedPostBackground = null;
    const v = $("#create-video-input"); if (v) v.value = "";
  } else {
    const file = files[0];
    const check = await validateMedia(file, kind);
    if (!check.ok) { toast(check.msg); if (input) input.value=""; return; }
    state.selectedPostPhotos.forEach(x => revokeUrl(x.url)); state.selectedPostPhotos=[];
    if (state.selectedPostMedia) revokeUrl(state.selectedPostMedia.url);
    state.selectedPostBackground = null;
    state.selectedPostMedia = { file, kind, url:URL.createObjectURL(file) };
    const p = $("#create-photo-input"); if (p) p.value="";
  }
  renderPostMediaPreview(); updatePublishState();
};

const _baseRenderPostMediaPreview = renderPostMediaPreview;
renderPostMediaPreview = function() {
  if (!state.selectedPostPhotos?.length || state.selectedPostPhotos.length === 1) {
    if (state.selectedPostPhotos?.length === 1) state.selectedPostMedia = state.selectedPostPhotos[0];
    return _baseRenderPostMediaPreview();
  }
  const box=$("#create-preview"); if(!box) return;
  box.innerHTML=""; box.className="create-preview multi-photo"; box.dataset.ratio=state.selectedImageRatio||"original";
  hideEl($("#create-video-ratio-wrap")); hideEl($("#create-background-ratio-wrap")); showEl($("#create-image-ratio-wrap"));
  state.selectedPostPhotos.forEach((m,i)=>{
    const wrap=document.createElement("div"); wrap.className="multi-photo-item";
    const img=document.createElement("img"); img.src=safeUrl(m.url,{allowBlob:true}); img.alt="";
    const rm=document.createElement("button"); rm.type="button"; rm.textContent="×"; rm.setAttribute("aria-label","Retirer la photo");
    rm.addEventListener("click",()=>{ revokeUrl(m.url); state.selectedPostPhotos.splice(i,1); if(state.selectedPostPhotos.length===1) state.selectedPostMedia=state.selectedPostPhotos[0]; renderPostMediaPreview(); updatePublishState(); });
    wrap.append(img,rm); box.appendChild(wrap);
  });
  showEl(box);
};
const _baseClearSelectedPostMedia = clearSelectedPostMedia;
clearSelectedPostMedia = function(){ state.selectedPostPhotos?.forEach(x=>revokeUrl(x.url)); state.selectedPostPhotos=[]; _baseClearSelectedPostMedia(); };
const _baseUpdatePublishState = updatePublishState;
updatePublishState = function(){
  const btn=$("#create-publish-btn"); if(!btn) return;
  const title=($("#create-title")?.value||"").trim(); const text=(state.richEditorEnabled?richEditorPlainText():($("#create-text")?.value||"").trim());
  const hasMedia=!!state.selectedPostMedia || !!state.selectedPostPhotos?.length || !!state.selectedPostBackground;
  const empty=!title || (!text && !hasMedia); btn.disabled=state.uploading||empty; btn.classList.toggle("hidden",empty);
};

handlePublishPost = async function() {
  if (!state.currentUser || state.uploading) return;
  const title=($("#create-title")?.value||"").trim().slice(0,TITLE_MAX);
  const text=(state.richEditorEnabled?richEditorPlainText():($("#create-text")?.value||"").trim()).slice(0,TEXT_MAX);
  const richTextHtml=state.richEditorEnabled&&$("#create-rich-editor")?sanitizeRichHtml($("#create-rich-editor").innerHTML):"";
  const category=$("#create-category")?.value||"poesie"; const privacy=privacyOf($("#create-privacy")?.value,"public");
  const formatting=sanitizeFormatting(state.postFormat); const photos=state.selectedPostPhotos||[]; const media=photos.length?null:state.selectedPostMedia;
  if(!title||(!text&&!media&&!photos.length&&!state.selectedPostBackground)){toast(t("err_empty_post"));return;}
  const btn=$("#create-publish-btn"); state.uploading=true; setBusy(btn,true,"..."); let publishedIds=[];
  try{
    let mediaURL="",mediaPublicId="",mediaType="",mediaResourceType="",mediaMeta=null,mediaItems=[];
    let publishedBackground=state.selectedPostBackground?{...state.selectedPostBackground}:null;
    if(publishedBackground?.kind==="upload"&&publishedBackground.file){const up=await uploadMedia(publishedBackground.file,{folder:`lyrame/posts/${state.currentUser.uid}/backgrounds`,resourceType:"image",onProgress:setUploadProgress}); publishedIds.push(up.publicId); publishedBackground={kind:"remote",url:up.url,publicId:up.publicId,ratio:state.selectedBackgroundRatio||"original"};}
    if(photos.length){
      for(let i=0;i<photos.length;i++){
        const up=await uploadMedia(photos[i].file,{folder:`lyrame/posts/${state.currentUser.uid}`,resourceType:"image",onProgress:p=>setUploadProgress(Math.round(((i+p/100)/photos.length)*100))});
        publishedIds.push(up.publicId); mediaItems.push({url:up.url,publicId:up.publicId,type:"image",ratio:state.selectedImageRatio||"original",width:up.width,height:up.height,bytes:up.bytes});
      }
      mediaType="images";
    } else if(media){
      const check=await validateMedia(media.file,media.kind); if(!check.ok){toast(check.msg);return;}
      const up=await uploadMedia(media.file,{folder:`lyrame/posts/${state.currentUser.uid}`,resourceType:media.kind==="video"?"video":"image",onProgress:setUploadProgress});
      publishedIds.push(up.publicId); mediaURL=up.url; mediaPublicId=up.publicId; mediaType=media.kind; mediaResourceType=up.resourceType; mediaMeta={format:up.format,bytes:up.bytes,width:up.width,height:up.height,duration:up.duration};
    }
    await ensureUserDocument(); const p=state.currentProfile||{}; const bg=publishedBackground?{...publishedBackground,ratio:state.selectedBackgroundRatio||"original"}:null; if(bg){delete bg.file;delete bg.localUrl;}
    const editing=!!state.editingPostId; const postRef=editing?doc(db,"posts",state.editingPostId):doc(collection(db,"posts")); const batch=writeBatch(db);
    const payload={authorId:state.currentUser.uid,authorName:p.fullname||state.currentUser.displayName||"",authorUsername:p.username||"",authorPhotoURL:p.photoURL||"",authorBadgeType:badgeTypeOf(p),title,text,richTextHtml,formatting,category,privacy,countryCode:String(p.countryCode||"").toUpperCase().slice(0,2),imageRatio:state.selectedImageRatio||"original",videoRatio:media?.kind==="video"?(state.selectedVideoRatio||"original"):"original",background:bg,mediaURL,mediaPublicId,mediaType,mediaResourceType,mediaMeta,mediaItems,reactionsCount:editing?undefined:0,commentsCount:editing?undefined:0,updatedAt:serverTimestamp()};
    Object.keys(payload).forEach(k=>payload[k]===undefined&&delete payload[k]);
    if(editing) batch.update(postRef,payload); else {payload.createdAt=serverTimestamp();batch.set(postRef,payload);batch.set(doc(db,"users",state.currentUser.uid),{uid:state.currentUser.uid,postsCount:increment(1),updatedAt:serverTimestamp()},{merge:true});}
    await batch.commit(); publishedIds=[]; resetCreateForm(); state.selectedPostPhotos=[]; toast(editing?uiText("Publication mise à jour.","Voavao ny publication.","Post updated."):t("msg_post_created")); showScreen("home");
  }catch(err){logError("[publish post final]",err);toast(t("err_generic"));}
  finally{setUploadProgress(null);setBusy(btn,false);state.uploading=false;updatePublishState();}
};

function viewerActionButtons(post){
  if(!post) return null;
  const row=document.createElement("div");
  row.className="media-viewer-actions";
  const react=document.createElement("button"); react.type="button"; react.className="media-viewer-action"; react.innerHTML=`${finalSvgIcon("react")}<span>${escapeHtml(uiText("J’aime","Tiako","Like"))}</span>`;
  const comment=document.createElement("button"); comment.type="button"; comment.className="media-viewer-action"; comment.innerHTML=`${finalSvgIcon("comment")}<span>${escapeHtml(uiText("Commentaires","Hevitra","Comments"))}</span>`;
  const share=document.createElement("button"); share.type="button"; share.className="media-viewer-action"; share.innerHTML=`${finalSvgIcon("share")}<span>${escapeHtml(uiText("Partager","Hizara","Share"))}</span>`;
  react.addEventListener("click",e=>{e.stopPropagation(); if(state.activeReactionPostId===post.id&&isShown($("#reaction-picker"))) closeReactionPicker(); else openReactionPicker(post.id,react);});
  comment.addEventListener("click",e=>{e.stopPropagation(); hideEl($("#media-viewer")); openPostDetail(post.id);});
  share.addEventListener("click",e=>{e.stopPropagation(); sharePost(post);});
  row.append(react,comment,share);
  return row;
}

function renderMediaViewerMenu(post){
  const menu=$("#media-viewer-menu"); const btn=$("#media-viewer-menu-btn"); if(!menu||!btn)return;
  menu.innerHTML="";
  btn.classList.toggle("hidden",!post);
  if(!post){hideEl(menu);return;}
  const add=(label,fn,danger=false)=>{const b=document.createElement("button");b.type="button";b.textContent=label;if(danger)b.classList.add("danger");b.addEventListener("click",async e=>{e.stopPropagation();hideEl(menu);await fn();});menu.appendChild(b);};
  add(uiText("Enregistrer","Hitahiry","Save"),async()=>{const fake=document.createElement("button");await toggleSavePost(post,fake);});
  add(uiText("Copier le lien","Handika rohy","Copy link"),()=>sharePost(post,{copyOnly:true}));
  if(state.currentUser?.uid===post.authorId){
    add(uiText("Modifier la publication","Hanova publication","Edit post"),()=>{hideEl($("#media-viewer"));beginEditPost(post);});
    add(uiText("Supprimer la publication","Hamafa publication","Delete post"),()=>{hideEl($("#media-viewer"));return deletePost(post);},true);
  }else{
    add(uiText("Je ne veux pas voir ça","Tsy te hahita an’ity aho","I don’t want to see this"),()=>{hideEl($("#media-viewer"));});
    add(uiText("Signaler la photo","Hitatitra ny sary","Report photo"),()=>reportPost(post),true);
  }
}

function openMediaViewer(items,index=0,post=null,options={}){
  state.mediaViewerItems=(items||[]).filter(Boolean);
  state.mediaViewerIndex=Math.max(0,Math.min(index,state.mediaViewerItems.length-1));
  state.mediaViewerPost=post||null;
  state.mediaViewerGallery=!!options.gallery;
  renderMediaViewer();
  showEl($("#media-viewer"));
}

function renderMediaViewer(){
  const stage=$("#media-viewer-stage"); const footer=$("#media-viewer-footer"); if(!stage)return;
  stage.innerHTML=""; footer&&(footer.innerHTML="");
  const items=state.mediaViewerItems||[]; const post=state.mediaViewerPost||null;
  renderMediaViewerMenu(post);
  const prev=$("#media-viewer-prev"),next=$("#media-viewer-next"),counter=$("#media-viewer-counter");
  stage.classList.toggle("gallery-scroll-mode",!!state.mediaViewerGallery);
  if(state.mediaViewerGallery){
    prev?.classList.add("hidden"); next?.classList.add("hidden"); counter?.classList.add("hidden"); footer?.classList.add("hidden");
    items.forEach((item,i)=>{
      const card=document.createElement("article");card.className="media-gallery-card";
      if(post){
        const head=document.createElement("div");head.className="media-gallery-head";
        head.innerHTML=`<span class="avatar">${avatarMarkup(post.authorPhotoURL,post.authorName)}</span><span class="grow"><strong>${escapeHtml(post.authorName||"")}${identityBadgeMarkup({badgeType:post.authorBadgeType})}</strong><small>${escapeHtml(timeAgo(post.createdAt)||"")}</small></span>`;
        card.appendChild(head);
      }
      const node=document.createElement(item.type==="video"?"video":"img");node.src=safeUrl(item.url)||"";node.className="media-gallery-image"; if(item.type==="video"){node.controls=true;node.playsInline=true;}
      node.addEventListener("click",()=>{state.mediaViewerIndex=i;state.mediaViewerGallery=false;renderMediaViewer();});
      card.appendChild(node);
      if(post){
        const stats=document.createElement("div");stats.className="media-gallery-stats";stats.innerHTML=`<span>${escapeHtml(postReactionCountLabel(post.reactionsCount)||"")}</span><span>${escapeHtml(postCommentCountLabel(post.commentsCount)||"")}</span>`;card.appendChild(stats);
        const actions=viewerActionButtons(post); if(actions)card.appendChild(actions);
      }
      stage.appendChild(card);
    });
    return;
  }
  const item=items[state.mediaViewerIndex]; if(!item)return;
  const node=document.createElement(item.type==="video"?"video":"img");node.src=safeUrl(item.url)||"";node.className="media-viewer-single";if(item.type==="video"){node.controls=true;node.autoplay=true;node.playsInline=true;}stage.appendChild(node);
  setText("media-viewer-counter",`${state.mediaViewerIndex+1} / ${items.length}`);counter?.classList.remove("hidden");prev?.classList.toggle("hidden",items.length<2);next?.classList.toggle("hidden",items.length<2);
  if(footer&&post){
    footer.classList.remove("hidden");
    const info=document.createElement("div");info.className="media-viewer-info";info.innerHTML=`<span class="avatar">${avatarMarkup(post.authorPhotoURL,post.authorName)}</span><span class="grow"><strong>${escapeHtml(post.authorName||"")}${identityBadgeMarkup({badgeType:post.authorBadgeType})}</strong><small>${escapeHtml(timeAgo(post.createdAt)||"")}</small></span><span class="media-viewer-reaction-summary">${escapeHtml(postReactionCountLabel(post.reactionsCount)||"")}</span>`;
    footer.appendChild(info); const actions=viewerActionButtons(post);if(actions)footer.appendChild(actions);
  }else footer?.classList.add("hidden");
}
const _baseRenderPostCard=renderPostCard;
renderPostCard=function(post){
  const hasMulti=Array.isArray(post.mediaItems)&&post.mediaItems.length>0;
  const card=_baseRenderPostCard(hasMulti?{...post,mediaURL:"",mediaType:""}:post);
  if(hasMulti){
    const content=card.querySelector(".post-content");
    const grid=document.createElement("div");
    grid.className="post-media-collage";
    const total=post.mediaItems.length;
    const layoutCount=Math.min(total,5);
    grid.dataset.count=String(layoutCount);
    const ratioCandidate=post.imageRatio || post.mediaItems[0]?.ratio || "original";
    const allowedRatios=["1:1","4:5","3:4","16:9","9:16"];
    grid.dataset.ratio=allowedRatios.includes(ratioCandidate)?ratioCandidate:"original";
    const visible=post.mediaItems.slice(0,layoutCount);
    visible.forEach((m,i)=>{
      const item=document.createElement("div");
      item.className="collage-item";
      const img=document.createElement("img");
      img.src=safeUrl(m.url)||"";
      img.alt="";
      item.appendChild(img);
      if(i===visible.length-1 && total>layoutCount){
        const more=document.createElement("button");
        more.type="button";
        more.className="collage-more";
        more.textContent=`+${total-layoutCount}`;
        more.setAttribute("aria-label",uiText("Voir toutes les photos","Hijery ny sary rehetra","View all photos"));
        more.addEventListener("click",e=>{e.stopPropagation();openMediaViewer(post.mediaItems,0,post,{gallery:true});});
        item.appendChild(more);
      }
      item.addEventListener("click",()=>openMediaViewer(post.mediaItems,i,post));
      grid.appendChild(item);
    });
    content?.after(grid);
  }
  const actions=card.querySelector(".post-actions"); if(actions){const a=actions.querySelector('[data-act="react"]');const c=actions.querySelector('[data-act="comment"]');const sh=actions.querySelector('[data-act="share"]');if(a&&!a.querySelector("svg"))a.innerHTML=`${finalSvgIcon("react")}<span class="action-label">${escapeHtml(uiText("Réagir","Fihetseham-po","React"))}</span>`;if(c)c.innerHTML=`${finalSvgIcon("comment")}<span class="action-label">${escapeHtml(uiText("Commentaires","Hevitra","Comments"))}</span>`;if(sh)sh.innerHTML=`${finalSvgIcon("share")}<span class="action-label">${escapeHtml(uiText("Partager","Hizara","Share"))}</span>`;}
  const body=card.querySelector(".post-body"); if(body){let pressTimer=null;const start=()=>{pressTimer=setTimeout(async()=>{try{await navigator.clipboard.writeText(body.innerText||"");toast(uiText("Texte copié.","Voadika ny lahatsoratra.","Text copied."));}catch(_){}},650)};const cancel=()=>clearTimeout(pressTimer);body.addEventListener("pointerdown",start);["pointerup","pointercancel","pointerleave"].forEach(e=>body.addEventListener(e,cancel));}
  if(!hasMulti && post.mediaURL && post.mediaType==="image"){
    const mediaBox=card.querySelector(".post-media"); const img=mediaBox?.querySelector("img");
    if(mediaBox&&img){
      img.addEventListener("click",e=>{e.stopPropagation();openMediaViewer([{url:post.mediaURL,type:"image",ratio:post.imageRatio||"original"}],0,post);});
      if((post.imageRatio||"original")==="original"){
        const applyOriginalLimit=()=>{if(img.naturalWidth&&img.naturalHeight){const ratio=img.naturalWidth/img.naturalHeight;mediaBox.classList.toggle("original-story-max",ratio<(9/16));}};
        if(img.complete)applyOriginalLimit();else img.addEventListener("load",applyOriginalLimit,{once:true});
      }
    }
  }
  return card;
};

/* ---------- search: recents + users/pages/groups ---------- */
function saveSearchRecent(item){const arr=state.recentSearches.filter(x=>!(x.type===item.type&&x.id===item.id));arr.unshift(item);state.recentSearches=arr.slice(0,12);persistSearchRecentsCloud();renderSearchRecents();}
function renderSearchRecents(){const box=$("#search-recents");if(!box)return;box.innerHTML="";if(!state.recentSearches.length){box.innerHTML=`<p class="muted small">${escapeHtml(uiText("Aucune recherche récente.","Tsy misy fikarohana vao haingana.","No recent searches."))}</p>`;return;}state.recentSearches.slice(0,6).forEach(r=>{const row=document.createElement("div");row.className="search-recent-row";row.innerHTML=`<span class="grow"><strong>${escapeHtml(r.label||"")}</strong><small>${escapeHtml(r.type||"")}</small></span><button class="icon-btn sm" type="button" aria-label="Options">⋯</button>`;row.addEventListener("click",e=>{if(e.target.closest("button")){state.recentSearches=state.recentSearches.filter(x=>x!==r);persistSearchRecentsCloud();renderSearchRecents();return;}openSearchEntity(r)});box.appendChild(row);});}
async function openGroupDiscoveryItem(id){
  if(!id)return;
  try{const snap=await getDoc(doc(db,"conversations",id));if(!snap.exists())return;const c={id:snap.id,...snap.data()};state.activeConvId=id;state.activeConv=c;renderGroupInfo(c);showScreen("group-info");}catch(err){logError("[open group discovery]",err);}
}
function openSearchEntity(r){if(r.type==="user"){if(r.id===state.currentUser?.uid)showScreen("profile-me");else openOtherProfile(r.id);}else if(r.type==="page"){state.activePageId=r.id;showScreen("page-detail");}else if(r.type==="group"){state.activeConvId=r.id;openGroupDiscoveryItem(r.id);}}
runSearch=async function(term){const list=$("#search-results");if(!list)return;list.innerHTML="";term=String(term||"").trim().toLowerCase().replace(/^@+/,"");if(!term){renderSearchRecents();list.innerHTML='<div class="empty-state" id="search-empty"><p class="empty-title">Rechercher sur LYRAME</p><p class="empty-text">Personnes, Pages et Groupes.</p></div>';return;}try{const [us,ps,gs]=await Promise.all([getDocs(query(collection(db,"users"),limit(100))),getDocs(query(collection(db,"pages"),limit(100))).catch(()=>null),getDocs(query(collection(db,"conversations"),where("type","==","group"),limit(100))).catch(()=>null)]);const groups=[];const addGroup=(title,docs,type)=>{const matches=(docs||[]).filter(x=>{const d=x.data();return String(d.fullname||d.username||d.name||d.title||"").toLowerCase().includes(term)||String(d.description||"").toLowerCase().includes(term)}).slice(0,20);if(!matches.length)return;const h=document.createElement("h3");h.className="search-group-title";h.textContent=title;list.appendChild(h);matches.forEach(x=>{const d=x.data();const label=d.fullname||d.name||d.title||d.username||uiSomeone();const row=document.createElement("button");row.type="button";row.className="search-result-row";row.innerHTML=`<span class="avatar">${avatarMarkup(d.photoURL||d.avatarURL||d.coverURL||"",label)}</span><span class="grow"><strong>${escapeHtml(label)}${type==="user"?identityBadgeMarkup(d):""}</strong><small>${escapeHtml(type==="user"?(d.username?"@"+d.username:""):type)}</small></span>`;row.addEventListener("click",()=>{saveSearchRecent({id:x.id,type,label});openSearchEntity({id:x.id,type,label});});list.appendChild(row);});};addGroup(uiText("Personnes","Olona","People"),us.docs,"user");addGroup("Pages",ps?.docs||[],"page");addGroup(uiText("Groupes","Vondrona","Groups"),gs?.docs||[],"group");if(!list.children.length)list.innerHTML=`<div class="empty-state"><p class="empty-title">${escapeHtml(uiText("Aucun résultat","Tsy misy valiny","No results"))}</p></div>`;}catch(err){logError("[mixed search]",err);}};

/* ---------- Stories ---------- */
async function loadStories(){const box=$("#stories-list");if(!box||!state.currentUser)return;box.innerHTML="";try{const snap=await getDocs(query(collection(db,"stories"),orderBy("createdAt","desc"),limit(60)));const now=Date.now();snap.docs.map(d=>({id:d.id,...d.data()})).filter(s=>{const t=toDate(s.createdAt)?.getTime()||now;return now-t<24*60*60*1000;}).forEach(st=>{const b=document.createElement("button");b.type="button";b.className="story-card";const url=safeUrl(st.mediaURL);b.innerHTML=`${st.mediaType==="video"?`<video src="${escapeHtml(url)}" muted playsinline></video>`:`<img src="${escapeHtml(url)}" alt=""/>`}<span class="story-ring">${avatarMarkup(st.authorPhotoURL,st.authorName)}</span><span class="story-owner">${escapeHtml(st.authorName||"")}</span>`;b.addEventListener("click",()=>openStory(st));box.appendChild(b);});}catch(err){console.warn("[stories]",err);}}
async function createStory(file){if(!state.currentUser||!file)return;const kind=file.type.startsWith("video/")?"video":"image";const check=await validateMedia(file,kind);if(!check.ok){toast(check.msg);return;}try{toast(uiText("Envoi de la story…","Mandefa story…","Uploading story…"));const up=await uploadMedia(file,{folder:`lyrame/stories/${state.currentUser.uid}`,resourceType:kind==="video"?"video":"image"});const p=state.currentProfile||{};await addDoc(collection(db,"stories"),{authorId:state.currentUser.uid,authorName:p.fullname||state.currentUser.displayName||"",authorPhotoURL:p.photoURL||"",mediaURL:up.url,mediaPublicId:up.publicId,mediaType:kind,createdAt:serverTimestamp()});await loadStories();toast(uiText("Story publiée.","Navoaka ny story.","Story published."));}catch(err){logError("[create story]",err);toast(t("err_generic"));}}
function openStory(st){const stage=$("#story-viewer-stage"),bar=$("#story-progress-bar");if(!stage)return;stage.innerHTML="";clearTimeout(state.storyTimer);const node=document.createElement(st.mediaType==="video"?"video":"img");node.src=safeUrl(st.mediaURL)||"";if(st.mediaType==="video"){node.autoplay=true;node.controls=true;node.playsInline=true;}stage.appendChild(node);showEl($("#story-viewer"));if(bar){bar.style.transition="none";bar.style.width="0";requestAnimationFrame(()=>{bar.style.transition=`width ${st.mediaType==="video"?15:6}s linear`;bar.style.width="100%";});}state.storyTimer=setTimeout(()=>hideEl($("#story-viewer")),st.mediaType==="video"?15000:6000);}

/* ---------- Suggestions ---------- */
async function loadSuggestions(){const list=$("#suggestions-list");if(!list||!state.currentUser)return;list.innerHTML="";try{const snap=await getDocs(query(collection(db,"users"),limit(100)));const me=state.currentUser.uid;/* V95.1 suggestions: hide profiles without a displayable identity; never alter database records. */
const candidates=snap.docs.map(d=>{
  const u={uid:d.id,...d.data()};
  const handle=String(u.username||u.handle||"").trim().replace(/^@+/,"");
  const personName=String(u.fullname||u.displayName||u.name||[u.firstName||u.prenom,u.lastName||u.nom].filter(Boolean).join(" ")||"").trim();
  u.username=handle;
  u.fullname=personName || (handle?"@"+handle:"");
  u.photoURL=u.photoURL||u.avatarURL||"";
  return u;
}).filter(u=>u.uid!==me&&!state.friendIds.has(u.uid)&&!state.suggestionsHidden.has(u.uid)&&u.fullname!==""&&!/^\?+$/.test(u.fullname));candidates.slice(0,40).forEach(u=>{const row=buildUserRow(u,[]);const actions=document.createElement("div");actions.className="row-actions";const add=makeSmallButton(uiText("Ajouter","Hanampy","Add"),"primary",async()=>{await sendFriendRequest(u.uid);row.remove();});const rm=makeSmallButton(uiText("Supprimer","Esory","Remove"),"ghost",()=>{state.suggestionsHidden.add(u.uid);persistHiddenSuggestionsCloud();row.remove();});actions.append(add,rm);row.appendChild(actions);list.appendChild(row);});if(!list.children.length)list.innerHTML=`<div class="empty-state"><p class="empty-title">${escapeHtml(uiText("Aucune suggestion pour le moment.","Tsy misy soso-kevitra aloha.","No suggestions right now."))}</p></div>`;}catch(err){logError("[suggestions]",err);}}

/* ---------- Dashboard ---------- */
async function loadDashboard(){const grid=$("#dashboard-grid"),trends=$("#dashboard-trends"),tips=$("#dashboard-tips");if(!grid||!state.currentUser)return;grid.innerHTML='<div class="feed-loading">Chargement…</div>';try{const snap=await getDocs(query(collection(db,"posts"),where("authorId","==",state.currentUser.uid),limit(100)));const posts=snap.docs.map(d=>({id:d.id,...d.data()}));let reactions=0,comments=0,views=0;for(const p of posts){reactions+=Number(p.reactionsCount||0);comments+=Number(p.commentsCount||0);try{const vs=await getDocs(query(collection(db,"posts",p.id,"views"),limit(1000)));views+=vs.size;}catch(_){}}const engagement=reactions+comments;const cards=[[uiText("Publications","Publication","Posts"),posts.length],[uiText("Vues","Fijerena","Views"),views],[uiText("Engagement","Fandraisana anjara","Engagement"),engagement],[uiText("Abonnés","Mpanaraka","Followers"),Number(state.currentProfile?.followersCount||0)]];grid.innerHTML=cards.map(([l,v])=>`<div class="metric-card"><small>${escapeHtml(l)}</small><strong>${v}</strong></div>`).join("");const ranked=[...posts].sort((a,b)=>(Number(b.reactionsCount||0)+Number(b.commentsCount||0))-(Number(a.reactionsCount||0)+Number(a.commentsCount||0))).slice(0,5);trends.innerHTML=`<h3>${escapeHtml(uiText("Performance des publications","Fahombiazan'ny publication","Post performance"))}</h3><div class="trend-list">${ranked.map((p,i)=>{const score=Number(p.reactionsCount||0)+Number(p.commentsCount||0);const max=Math.max(1,...ranked.map(x=>Number(x.reactionsCount||0)+Number(x.commentsCount||0)));return `<div class="trend-row"><span>${escapeHtml((p.title||"Publication").slice(0,24))}</span><span class="trend-bar"><span style="width:${Math.round(score/max*100)}%"></span></span><strong>${score}</strong></div>`}).join("")||`<p class="muted">${escapeHtml(uiText("Publiez pour voir vos tendances.","Mamoaha publication hahitana ny fironana.","Publish to see trends."))}</p>`}</div>`;const tip=posts.length<3?uiText("Publiez régulièrement et complétez votre profil pour améliorer votre visibilité.","Mamoaha matetika ary fenoy ny profil mba hampitombo ny fahitana.","Post regularly and complete your profile to improve visibility."):engagement===0?uiText("Essayez des publications plus interactives et répondez aux commentaires.","Andramo publication mampandray anjara kokoa ary valio ny commentaires.","Try more interactive posts and reply to comments."):uiText("Continuez à répondre aux commentaires et observez les publications qui génèrent le plus d'engagement.","Tohizo ny famaliana commentaires ary jereo izay publication mahazo fandraisana anjara betsaka.","Keep replying to comments and watch which posts drive the most engagement.");tips.innerHTML=`<h3>${escapeHtml(uiText("Suggestions","Soso-kevitra","Suggestions"))}</h3><p>${escapeHtml(tip)}</p>`;}catch(err){logError("[dashboard]",err);grid.innerHTML=`<div class="empty-state"><p>${escapeHtml(t("err_generic"))}</p></div>`;}}

/* ---------- Pages ---------- */
async function loadPages(term=""){const list=$("#pages-list");if(!list)return;list.innerHTML="";try{const snap=await getDocs(query(collection(db,"pages"),limit(100)));const q=term.trim().toLowerCase();snap.docs.map(d=>({id:d.id,...d.data()})).filter(p=>!q||String(p.name||"").toLowerCase().includes(q)||String(p.description||"").toLowerCase().includes(q)).forEach(p=>{const card=document.createElement("button");card.type="button";card.className="entity-card";card.innerHTML=`<div class="cover">${p.coverURL?`<img src="${escapeHtml(safeUrl(p.coverURL))}" alt="">`:""}</div><div class="body"><h3>${escapeHtml(p.name||"Page")}</h3><p>${escapeHtml(String(p.description||"").slice(0,100))}</p><p>${Number(p.followersCount||0)} ${escapeHtml(uiText("abonnés","mpanaraka","followers"))}</p></div>`;card.addEventListener("click",()=>{state.activePageId=p.id;showScreen("page-detail");});list.appendChild(card);});if(!list.children.length)list.innerHTML='<div class="empty-state"><p class="empty-title">Aucune Page</p></div>';}catch(err){logError("[pages]",err);}}
async function handlePageCreate(e){e.preventDefault();if(!state.currentUser)return;if(!state.profileExists){toast(uiText("Créez d’abord votre profil.","Mamoròna profil aloha.","Create your profile first."));return;}const name=($("#page-name")?.value||"").trim(),description=($("#page-description")?.value||"").trim();if(!name)return;const submit=e.submitter||e.target.querySelector('button[type="submit"]');setBusy(submit,true,"...");try{let avatarURL="",coverURL="",avatarPublicId="",coverPublicId="";const av=$("#page-avatar-input")?.files?.[0],cv=$("#page-cover-input")?.files?.[0];if(av){const up=await uploadMedia(av,{folder:`lyrame/pages/${state.currentUser.uid}`,resourceType:"image"});avatarURL=up.url;avatarPublicId=up.publicId;}if(cv){const up=await uploadMedia(cv,{folder:`lyrame/pages/${state.currentUser.uid}`,resourceType:"image"});coverURL=up.url;coverPublicId=up.publicId;}const ref=await addDoc(collection(db,"pages"),{name,description,avatarURL,avatarPublicId,coverURL,coverPublicId,ownerId:state.currentUser.uid,adminIds:[state.currentUser.uid],followersCount:0,createdAt:serverTimestamp(),updatedAt:serverTimestamp()});state.activePageId=ref.id;e.target.reset();toast(uiText("Page créée.","Vita ny Page.","Page created."));showScreen("page-detail");}catch(err){logError("[page create]",err);toast(t("err_generic"));}finally{setBusy(submit,false);}}
async function loadPageDetail(){const root=$("#page-detail-content");if(!root||!state.activePageId)return;root.innerHTML='<div class="feed-loading">Chargement…</div>';try{const ref=doc(db,"pages",state.activePageId),snap=await getDoc(ref);if(!snap.exists()){root.innerHTML='<div class="empty-state"><p>Page introuvable.</p></div>';return;}const p={id:snap.id,...snap.data()};setText("page-detail-title",p.name||"Page");let following=false;if(state.currentUser){following=(await getDoc(doc(db,"pages",p.id,"followers",state.currentUser.uid))).exists();}const isAdmin=p.adminIds?.includes(state.currentUser?.uid);root.innerHTML=`<article class="page-hero"><div class="page-cover" style="${p.coverURL?`background-image:url('${escapeHtml(safeUrl(p.coverURL))}')`:""}"></div><div class="page-main"><div class="page-avatar-large">${avatarMarkup(p.avatarURL,p.name)}</div><h2>${escapeHtml(p.name||"")}</h2><p>${escapeHtml(p.description||"")}</p><p class="muted">${Number(p.followersCount||0)} ${escapeHtml(uiText("abonnés","mpanaraka","followers"))}</p><div class="page-actions">${isAdmin?'<span class="badge">Admin</span>':`<button class="btn btn-primary" id="page-follow-btn">${escapeHtml(following?uiText("Suivi","Araho","Following"):uiText("Suivre","Hanaraka","Follow"))}</button>`}</div></div></article><div id="page-posts" class="feed-list"></div>`;$("#page-follow-btn")?.addEventListener("click",async()=>{const fref=doc(db,"pages",p.id,"followers",state.currentUser.uid);await runTransaction(db,async tx=>{const fs=await tx.get(fref),ps=await tx.get(ref);if(fs.exists()){tx.delete(fref);tx.update(ref,{followersCount:Math.max(0,Number(ps.data()?.followersCount||1)-1),updatedAt:serverTimestamp()});}else{tx.set(fref,{userId:state.currentUser.uid,createdAt:serverTimestamp()});tx.update(ref,{followersCount:Number(ps.data()?.followersCount||0)+1,updatedAt:serverTimestamp()});}});loadPageDetail();});}catch(err){logError("[page detail]",err);}}

/* ---------- Marketplace ---------- */
async function loadMarketplace(){const list=$("#marketplace-list");if(!list)return;list.innerHTML="";const term=($("#marketplace-search")?.value||"").trim().toLowerCase(),cat=$("#marketplace-category")?.value||"",status=$("#marketplace-status")?.value||"";try{const snap=await getDocs(query(collection(db,"marketplaceListings"),orderBy("createdAt","desc"),limit(100)));snap.docs.map(d=>({id:d.id,...d.data()})).filter(x=>(!term||String(x.title||"").toLowerCase().includes(term)||String(x.description||"").toLowerCase().includes(term))&&(!cat||x.category===cat)&&(!status||x.status===status)).forEach(x=>{const c=document.createElement("button");c.type="button";c.className="market-card";const first=x.photos?.[0]?.url||"";c.innerHTML=`<div class="cover">${first?`<img src="${escapeHtml(safeUrl(first))}" alt="">`:""}</div><div class="body"><h3>${escapeHtml(x.title||"")}</h3><strong>${Number(x.price||0).toLocaleString()} Ar</strong><p>${escapeHtml(x.location||"")}</p><p>${escapeHtml(x.status==="sold"?uiText("Vendu","Lafo","Sold"):uiText("Disponible","Misy","Available"))}</p></div>`;c.addEventListener("click",()=>{state.activeListingId=x.id;showScreen("listing-detail");});list.appendChild(c);});if(!list.children.length)list.innerHTML='<div class="empty-state"><p class="empty-title">Aucune annonce</p></div>';}catch(err){logError("[marketplace]",err);}}
async function handleListingCreate(e){e.preventDefault();if(!state.currentUser)return;const files=Array.from($("#listing-photos")?.files||[]).slice(0,10);if(!files.length){toast(uiText("Ajoutez au moins une photo.","Ampio sary iray farafahakeliny.","Add at least one photo."));return;}const submit=e.submitter||e.target.querySelector('button[type="submit"]');setBusy(submit,true,"...");try{const photos=[];for(let i=0;i<files.length;i++){const check=await validateMedia(files[i],"image");if(!check.ok)continue;const up=await uploadMedia(files[i],{folder:`lyrame/marketplace/${state.currentUser.uid}`,resourceType:"image",onProgress:p=>{const wrap=$("#listing-progress");showEl(wrap);const pct=Math.round(((i+p/100)/files.length)*100);const bar=wrap?.querySelector("span");const sm=wrap?.querySelector("small");if(bar)bar.style.width=pct+"%";if(sm)sm.textContent=pct+"%";}});photos.push({url:up.url,publicId:up.publicId});}const data={sellerId:state.currentUser.uid,sellerName:state.currentProfile?.fullname||state.currentUser.displayName||"",sellerUsername:state.currentProfile?.username||"",title:($("#listing-title")?.value||"").trim(),price:Number($("#listing-price")?.value||0),category:$("#listing-category")?.value||"Autres",condition:$("#listing-condition")?.value||"",location:($("#listing-location")?.value||"").trim(),description:($("#listing-description")?.value||"").trim(),contact:($("#listing-contact")?.value||"").trim(),delivery:($("#listing-delivery")?.value||"").trim(),availability:true,status:"available",photos,createdAt:serverTimestamp(),updatedAt:serverTimestamp()};const ref=await addDoc(collection(db,"marketplaceListings"),data);state.activeListingId=ref.id;e.target.reset();$("#listing-preview").innerHTML="";hideEl($("#listing-progress"));toast(uiText("Annonce publiée.","Navoaka ny entana.","Listing published."));showScreen("listing-detail");}catch(err){logError("[listing create]",err);toast(t("err_generic"));}finally{setBusy(submit,false);}}
async function loadListingDetail(){const root=$("#listing-detail-content");if(!root||!state.activeListingId)return;try{const snap=await getDoc(doc(db,"marketplaceListings",state.activeListingId));if(!snap.exists()){root.innerHTML='<div class="empty-state"><p>Annonce introuvable.</p></div>';return;}const x={id:snap.id,...snap.data()},photos=x.photos||[];root.innerHTML=`<article class="listing-hero"><div class="listing-gallery">${photos.map((p,i)=>`<img data-listing-photo="${i}" src="${escapeHtml(safeUrl(p.url))}" alt="">`).join("")}</div><div class="listing-main"><h2>${escapeHtml(x.title||"")}</h2><div class="listing-price">${Number(x.price||0).toLocaleString()} Ar</div><p>${escapeHtml(x.description||"")}</p><p><strong>${escapeHtml(uiText("État","Toetry","Condition"))}:</strong> ${escapeHtml(x.condition||"")}</p><p><strong>${escapeHtml(uiText("Lieu","Toerana","Location"))}:</strong> ${escapeHtml(x.location||"")}</p><p><strong>${escapeHtml(uiText("Vendeur","Mpivarotra","Seller"))}:</strong> ${escapeHtml(x.sellerName||"")}</p><p><strong>${escapeHtml(uiText("Contact","Fifandraisana","Contact"))}:</strong> ${escapeHtml(x.contact||"")}</p><p><strong>${escapeHtml(uiText("Remise/livraison","Fanaterana","Delivery"))}:</strong> ${escapeHtml(x.delivery||"")}</p><div class="page-actions"><button class="btn btn-primary" id="listing-contact-btn">${escapeHtml(uiText("Contacter le vendeur","Hifandray amin'ny mpivarotra","Contact seller"))}</button><button class="btn btn-ghost" id="listing-share-btn">${escapeHtml(uiText("Partager","Hizara","Share"))}</button>${x.sellerId===state.currentUser?.uid?`<button class="btn btn-ghost" id="listing-sold-btn">${escapeHtml(x.status==="sold"?uiText("Marquer disponible","Atao misy","Mark available"):uiText("Marquer vendu","Atao lafo","Mark sold"))}</button>`:""}</div></div></article>`;root.querySelectorAll("[data-listing-photo]").forEach(img=>img.addEventListener("click",()=>openMediaViewer(photos.map(p=>({url:p.url,type:"image"})),Number(img.dataset.listingPhoto))));$("#listing-share-btn")?.addEventListener("click",async()=>{const url=publicAppUrl(`#marketplace=${x.id}`);if(navigator.share)await navigator.share({title:x.title,text:x.description,url});else{await navigator.clipboard.writeText(url);toast(uiText("Lien copié.","Voadika ny rohy.","Link copied."));}});$("#listing-contact-btn")?.addEventListener("click",()=>{if(x.sellerId===state.currentUser?.uid){toast(uiText("C'est votre annonce.","Anao ity entana ity.","This is your listing."));return;}openDirectMessageWith(x.sellerId);});$("#listing-sold-btn")?.addEventListener("click",async()=>{await updateDoc(doc(db,"marketplaceListings",x.id),{status:x.status==="sold"?"available":"sold",availability:x.status==="sold",updatedAt:serverTimestamp()});loadListingDetail();});}catch(err){logError("[listing detail]",err);}}

/* ---------- Testeur de liens LYRAME ---------- */
let lastVerifiedPublicLink="";

function normalizeLinkTestValue(value){
  let raw=String(value||"").trim();
  if(!raw)return "";
  if(!/^https?:\/\//i.test(raw))raw="https://"+raw;
  const url=new URL(raw);
  if(!["http:","https:"].includes(url.protocol))throw new Error("BAD_PROTOCOL");
  return url.toString();
}
function canonicalLinkForCompare(value){
  try{
    const url=new URL(value);
    url.hash="";
    if(url.pathname!=="/")url.pathname=url.pathname.replace(/\/+$/,"");
    return url.toString().replace(/\/$/,"").toLowerCase();
  }catch(_){return "";}
}
function sameLinkHost(a,b){
  try{return new URL(a).hostname.toLowerCase()===new URL(b).hostname.toLowerCase();}catch(_){return false;}
}
function linkTestSetResult(kind,title,detail="",meta=null){
  const box=$("#link-test-result"), titleEl=$("#link-test-result-title"), detailEl=$("#link-test-result-detail"), metaEl=$("#link-test-meta"), openBtn=$("#link-test-open-btn");
  if(!box)return;
  box.classList.remove("hidden","is-ok","is-warn","is-error","is-loading");
  if(kind)box.classList.add("is-"+kind);
  if(titleEl)titleEl.textContent=title||"";
  if(detailEl)detailEl.textContent=detail||"";
  if(meta&&meta.finalUrl){
    if($("#link-test-http"))$("#link-test-http").textContent=meta.verification||"—";
    if($("#link-test-final-url"))$("#link-test-final-url").textContent=meta.finalUrl;
    metaEl?.classList.remove("hidden");
    lastVerifiedPublicLink=meta.openUrl||meta.finalUrl;
    openBtn?.classList.remove("hidden");
  }else{
    metaEl?.classList.add("hidden");
    lastVerifiedPublicLink="";
    openBtn?.classList.add("hidden");
  }
}

async function handleLinkTestSubmit(event){
  event?.preventDefault?.();
  const input=$("#link-test-input"), btn=$("#link-test-btn");
  const value=String(input?.value||"").trim();
  if(!value){
    linkTestSetResult("error",uiText("Entrez un lien à tester.","Ampidiro ny rohy hotsapaina.","Enter a link to test."));
    input?.focus();
    return;
  }
  let requestedUrl="";
  try{
    requestedUrl=normalizeLinkTestValue(value);
  }catch(_){
    linkTestSetResult("error",uiText("Lien invalide.","Tsy marina ny endriky ny rohy.","Invalid link."),uiText("Utilisez une adresse http:// ou https://.","Mampiasà adiresy http:// na https://.","Use an http:// or https:// address."));
    return;
  }
  if(btn)btn.disabled=true;
  linkTestSetResult("loading",uiText("Vérification en cours…","Eo am-panamarinana…","Checking…"));
  try{
    const response=await fetch(LYRAME_ASSISTANT_ENDPOINT,{
      method:"POST",
      headers:{"Content-Type":"text/plain;charset=UTF-8"},
      body:JSON.stringify({
        message:"Vérifie ce lien exact sur le web. Cherche cette URL précise et privilégie la page exacte : "+requestedUrl,
        language:state.lang||"fr",
        userId:state.currentUser?.uid||null,
        history:[]
      })
    });
    const data=await response.json().catch(()=>({}));
    if(!response.ok)throw new Error(data?.error||("HTTP_"+response.status));
    const sources=Array.isArray(data?.sources)?data.sources.filter(s=>s&&s.url):[];
    const wanted=canonicalLinkForCompare(requestedUrl);
    const exact=sources.find(s=>canonicalLinkForCompare(s.url)===wanted);
    const sameDomain=sources.find(s=>sameLinkHost(s.url,requestedUrl));
    if(exact){
      linkTestSetResult("ok",uiText("Lien vérifié.","Mandeha tsara ilay rohy.","Link verified."),uiText("La page exacte apparaît dans les résultats web vérifiés.","Hita ao amin'ny valin'ny fikarohana voamarina ilay pejy marina.","The exact page appears in verified web results."),{verification:uiText("Page exacte trouvée","Pejy marina hita","Exact page found"),finalUrl:exact.url,openUrl:requestedUrl});
    }else if(sameDomain){
      linkTestSetResult("warn",uiText("Domaine trouvé, page exacte non confirmée.","Hita ilay domaine fa tsy mbola voamarina ilay pejy marina.","Domain found, exact page not confirmed."),uiText("Le site existe dans les résultats, mais cette adresse précise n'a pas été retrouvée.","Hita amin'ny valin'ny fikarohana ilay tranonkala, fa tsy hita mazava ilay adiresy marina.","The site appears in results, but this exact address was not found."),{verification:uiText("Domaine trouvé","Domaine hita","Domain found"),finalUrl:requestedUrl,openUrl:requestedUrl});
    }else{
      linkTestSetResult("error",uiText("Lien non vérifié.","Tsy voamarina ilay rohy.","Link not verified."),uiText("Aucun résultat vérifié ne correspond à cette adresse pour le moment.","Tsy misy valin'ny fikarohana voamarina mifanaraka amin'io adiresy io aloha.","No verified web result matches this address right now."));
    }
  }catch(err){
    console.warn("[link tester]",err);
    linkTestSetResult("error",uiText("Impossible de vérifier ce lien.","Tsy afaka manamarina ilay rohy.","Could not verify this link."),uiText("Vérifiez votre connexion puis réessayez.","Jereo ny connexion dia andramo indray.","Check your connection and try again."));
  }finally{
    if(btn)btn.disabled=false;
  }
}

/* ---------- Assistant LYRAME ---------- */
const LYRAME_ASSISTANT_ENDPOINT="https://lyrame-assistant-backend.floot.app/_api/assistant";
const ASSISTANT_HISTORY_KEY="lyrame-assistant-history-v1";
const ASSISTANT_CHATS_KEY="lyrame-assistant-chats-v2";
const ASSISTANT_ACTIVE_CHAT_KEY="lyrame-assistant-active-chat-v2";
const ASSISTANT_CLOUD_MIGRATION_KEY="lyrame-assistant-cloud-migrated-v1";
const ASSISTANT_MAX_CHATS=25;
const ASSISTANT_MAX_MESSAGES=30;
let assistantBusy=false;
let assistantPendingImage=null;
let assistantCloudSyncPromise=null;
let assistantCloudSyncedUid="";

function assistantCopyLabel(kind="block"){
  if(kind==="all")return uiText("Copier tout","Adika rehetra","Copy all");
  return uiText("Copier","Adika","Copy");
}
async function assistantCopyText(text,button){
  const value=String(text||"");
  if(!value)return;
  try{
    if(navigator.clipboard?.writeText)await navigator.clipboard.writeText(value);
    else{
      const ta=document.createElement("textarea");ta.value=value;ta.setAttribute("readonly","");ta.style.position="fixed";ta.style.opacity="0";document.body.appendChild(ta);ta.select();document.execCommand("copy");ta.remove();
    }
    const old=button?.dataset?.label||button?.textContent||"";
    if(button){button.dataset.label=old;button.textContent=uiText("Copié ✓","Voadika ✓","Copied ✓");setTimeout(()=>{button.textContent=old||assistantCopyLabel();},1200);}
  }catch(err){console.warn("[assistant copy]",err);toast(uiText("Impossible de copier.","Tsy afaka mandika.","Unable to copy."));}
}
function assistantAppend(role,text,{pending=false,segments=null,imageDataUrl=null,imageURL=null,sources=null,autoScroll=true}={}){
  const box=$("#assistant-messages");if(!box)return null;
  const m=document.createElement("div");
  m.className=`assistant-msg ${role}${pending?" pending":""}`;
  const fullText=String(text||"");
  const imageSrc=String(imageDataUrl||imageURL||"").trim();
  if(imageSrc){const img=document.createElement("img");img.className="assistant-msg-image";img.src=imageSrc;img.alt=uiText("Image jointe","Sary nampiarahana","Attached image");m.appendChild(img);}
  if(role==="bot"&&!pending&&Array.isArray(segments)&&segments.length){
    const content=document.createElement("div");content.className="assistant-msg-content";
    segments.forEach(seg=>{
      if(!seg||!seg.text)return;
      if(seg.type==="copy"){
        const block=document.createElement("div");block.className="assistant-copy-block";
        const body=document.createElement("div");body.className="assistant-copy-text";body.textContent=String(seg.text);
        const btn=document.createElement("button");btn.type="button";btn.className="assistant-copy-btn";btn.textContent=assistantCopyLabel();btn.setAttribute("aria-label",assistantCopyLabel());
        btn.addEventListener("click",()=>assistantCopyText(seg.text,btn));
        block.append(body,btn);content.appendChild(block);
      }else{
        const part=document.createElement("div");part.className="assistant-text-part";part.textContent=String(seg.text);content.appendChild(part);
      }
    });
    m.appendChild(content);
  }else{
    const content=document.createElement("div");content.className="assistant-msg-content";content.textContent=fullText;m.appendChild(content);
  }
  if(role==="bot"&&!pending&&Array.isArray(sources)&&sources.length){
    const sourceList=document.createElement("div");sourceList.className="assistant-source-list";
    const sourceTitle=document.createElement("div");sourceTitle.className="assistant-source-title";sourceTitle.textContent=uiText("Sources vérifiées","Loharano voamarina","Verified sources");sourceList.appendChild(sourceTitle);
    sources.slice(0,5).forEach((src,index)=>{
      const url=String(src?.url||"").trim();
      if(!/^https?:\/\//i.test(url))return;
      const a=document.createElement("a");a.className="assistant-source-link";a.href=url;a.target="_blank";a.rel="noopener noreferrer";
      const label=String(src?.title||url).trim();a.textContent=`${index+1}. ${label}`;sourceList.appendChild(a);
    });
    if(sourceList.children.length>1)m.appendChild(sourceList);
  }
  if(role==="bot"&&!pending&&fullText){
    const actions=document.createElement("div");actions.className="assistant-msg-actions";
    const copyAll=document.createElement("button");copyAll.type="button";copyAll.className="assistant-copy-all";copyAll.textContent=assistantCopyLabel("all");copyAll.setAttribute("aria-label",assistantCopyLabel("all"));
    copyAll.addEventListener("click",()=>assistantCopyText(fullText,copyAll));
    actions.appendChild(copyAll);m.appendChild(actions);
  }
  box.appendChild(m);
  if(autoScroll)requestAnimationFrame(()=>m.scrollIntoView({behavior:"smooth",block:"end"}));
  assistantUpdateJumpLatest();
  return m;
}
function assistantNewMessageId(){return `msg-${Date.now()}-${Math.random().toString(36).slice(2,9)}`;}
function assistantSanitizeHistory(raw){
  return Array.isArray(raw)?raw.filter(x=>x&&["user","assistant"].includes(x.role)&&typeof x.text==="string").slice(-ASSISTANT_MAX_MESSAGES).map(x=>({
    ...(x.id?{id:String(x.id).slice(0,100)}:{}),
    role:x.role,
    text:String(x.text||"").slice(0,4000),
    ...(x.role==="user"&&/^https:\/\//i.test(String(x.imageURL||""))?{imageURL:String(x.imageURL).slice(0,1200),imagePublicId:String(x.imagePublicId||"").slice(0,300)}:{}),
    ...(x.role==="assistant"&&Array.isArray(x.segments)?{segments:x.segments.slice(0,12).map(seg=>({type:seg?.type==="copy"?"copy":"text",text:String(seg?.text||"").slice(0,4000),...(seg?.type==="copy"?{label:String(seg?.label||"Copier").slice(0,60)}:{})})).filter(seg=>seg.text)}:{}),
    ...(x.role==="assistant"&&Array.isArray(x.sources)?{sources:x.sources.slice(0,5).map(src=>({title:String(src?.title||"").slice(0,180),url:String(src?.url||"").slice(0,1000)})).filter(src=>/^https?:\/\//i.test(src.url))}:{})
  })):[];
}
function assistantNewChatId(){return `chat-${Date.now()}-${Math.random().toString(36).slice(2,8)}`;}
function assistantDefaultChatTitle(){return uiText("Nouvelle discussion","Resaka vaovao","New chat");}
function assistantTitleFromHistory(history){
  const first=assistantSanitizeHistory(history).find(x=>x.role==="user"&&String(x.text||"").trim());
  const raw=String(first?.text||assistantDefaultChatTitle()).replace(/\s+/g," ").trim();
  return raw.length>46?raw.slice(0,45).trim()+"…":raw;
}
function assistantCurrentUid(){return String(state.currentUser?.uid||auth.currentUser?.uid||"").trim();}
function assistantScopedKey(base){const uid=assistantCurrentUid();return uid?`${base}:${uid}`:base;}
let assistantMemoryChats = [];
let assistantMemoryActiveChatId = "";
function assistantReadLegacyHistory(){ return []; }
function assistantNormalizeChats(raw){
  return (Array.isArray(raw)?raw:[]).map(chat=>({
    id:String(chat?.id||"").trim(),
    title:String(chat?.title||"").trim().slice(0,80),
    createdAt:Number(chat?.createdAt)||Date.now(),
    updatedAt:Number(chat?.updatedAt)||Number(chat?.createdAt)||Date.now(),
    history:assistantSanitizeHistory(chat?.history)
  })).filter(chat=>chat.id).sort((a,b)=>b.updatedAt-a.updatedAt).slice(0,ASSISTANT_MAX_CHATS);
}
function assistantReadChats(){ return assistantNormalizeChats(assistantMemoryChats); }
function assistantWriteChats(chats){
  assistantMemoryChats = assistantNormalizeChats(chats);
  return assistantMemoryChats;
}
function assistantGetActiveChatId(){ return assistantMemoryActiveChatId || ""; }
function assistantCloudMetaRef(uid=assistantCurrentUid()){return uid?doc(db,"users",uid,"assistantMeta","state"):null;}
async function assistantCloudSetActive(id){
  const uid=assistantCurrentUid(),ref=assistantCloudMetaRef(uid);if(!uid||!ref)return;
  try{await setDoc(ref,{ownerId:uid,activeChatId:String(id||""),updatedAt:serverTimestamp()},{merge:true});}catch(err){console.warn("[assistant cloud active]",err);}
}
function assistantSetActiveChatId(id,{syncCloud=true}={}){
  assistantMemoryActiveChatId = String(id||"");
  if(syncCloud&&assistantCurrentUid())void assistantCloudSetActive(id);
}
function assistantCloudChatData(chat){
  const uid=assistantCurrentUid();
  return {ownerId:uid,title:String(chat?.title||assistantDefaultChatTitle()).slice(0,80),createdAtMs:Number(chat?.createdAt)||Date.now(),updatedAtMs:Number(chat?.updatedAt)||Date.now(),history:assistantSanitizeHistory(chat?.history),deleted:false,updatedAt:serverTimestamp()};
}
async function assistantCloudSaveChat(chat){
  const uid=assistantCurrentUid();if(!uid||!chat?.id)return;
  try{await setDoc(doc(db,"users",uid,"assistantChats",String(chat.id)),assistantCloudChatData(chat),{merge:true});}catch(err){console.warn("[assistant cloud save]",err);}
}
async function assistantCloudDeleteChat(id){
  const uid=assistantCurrentUid();if(!uid||!id)return;
  try{await setDoc(doc(db,"users",uid,"assistantChats",String(id)),{ownerId:uid,deleted:true,history:[],updatedAtMs:Date.now(),updatedAt:serverTimestamp(),deletedAt:serverTimestamp()},{merge:true});}catch(err){console.warn("[assistant cloud delete]",err);}
}
function assistantCloudChatFromDoc(d){
  const x=d?.data?.()||{};return {id:d.id,title:String(x.title||assistantDefaultChatTitle()).slice(0,80),createdAt:Number(x.createdAtMs)||Date.now(),updatedAt:Number(x.updatedAtMs)||Number(x.createdAtMs)||Date.now(),history:assistantSanitizeHistory(x.history),deleted:x.deleted===true};
}
async function assistantSyncFromCloud({force=false}={}){
  const uid=assistantCurrentUid();if(!uid)return;
  if(!force&&assistantCloudSyncedUid===uid)return;
  if(assistantCloudSyncPromise)return assistantCloudSyncPromise;
  assistantCloudSyncPromise=(async()=>{
    const [chatSnap,metaSnap]=await Promise.all([
      getDocs(query(collection(db,"users",uid,"assistantChats"),limit(200))),
      getDoc(doc(db,"users",uid,"assistantMeta","state"))
    ]);
    const remoteMap=new Map(),deletedIds=new Set();
    chatSnap.docs.forEach(d=>{const c=assistantCloudChatFromDoc(d);if(c.deleted)deletedIds.add(c.id);else remoteMap.set(c.id,c);});
    const local=assistantReadChats(),merged=new Map(remoteMap);
    const uploads=[];
    local.forEach(chat=>{
      if(deletedIds.has(chat.id))return;
      const remote=remoteMap.get(chat.id);
      if(!remote||chat.updatedAt>remote.updatedAt){merged.set(chat.id,chat);uploads.push(assistantCloudSaveChat(chat));}
    });
    const safe=assistantWriteChats([...merged.values()]);
    if(uploads.length)await Promise.allSettled(uploads);
    let active=String(metaSnap.exists()?metaSnap.data()?.activeChatId||"":"");
    if(!safe.some(c=>c.id===active))active=safe[0]?.id||"";
    assistantSetActiveChatId(active,{syncCloud:false});
    assistantCloudSyncedUid=uid;
    assistantRenderChatList();
    const screen=$("#screen-assistant");if(screen&&!screen.classList.contains("hidden"))assistantRenderActiveChat({scrollToTop:false});
  })().catch(err=>{console.warn("[assistant cloud sync]",err);}).finally(()=>{assistantCloudSyncPromise=null;});
  return assistantCloudSyncPromise;
}
function assistantEnsureActiveChat({createIfMissing=true}={}){
  let chats=assistantReadChats();
  let id=assistantGetActiveChatId();
  let chat=chats.find(x=>x.id===id)||null;
  if(!chat&&chats.length){chat=chats[0];assistantSetActiveChatId(chat.id);}
  if(!chat&&createIfMissing){
    const now=Date.now();chat={id:assistantNewChatId(),title:assistantDefaultChatTitle(),createdAt:now,updatedAt:now,history:[]};chats=[chat,...chats];assistantWriteChats(chats);assistantSetActiveChatId(chat.id);void assistantCloudSaveChat(chat);
  }
  return chat;
}
function assistantReadHistory(){return assistantEnsureActiveChat({createIfMissing:true})?.history||[];}
function assistantSaveHistory(history){
  const chats=assistantReadChats();
  let id=assistantGetActiveChatId();
  let index=chats.findIndex(x=>x.id===id);
  if(index<0){const now=Date.now();const chat={id:assistantNewChatId(),title:assistantDefaultChatTitle(),createdAt:now,updatedAt:now,history:[]};chats.unshift(chat);id=chat.id;index=0;assistantSetActiveChatId(id);}
  const clean=assistantSanitizeHistory(history);
  chats[index]={...chats[index],history:clean,title:assistantTitleFromHistory(clean),updatedAt:Date.now()};
  assistantWriteChats(chats);
  void assistantCloudSaveChat(chats[index]);
  assistantRenderChatList();
  assistantUpdateJumpLatest();
}
function assistantPushHistory(role,text,segments=null,sources=null,extra={}){
  const history=assistantReadHistory();
  const item={id:assistantNewMessageId(),role,text:String(text||"").slice(0,4000)};
  if(role==="user"&&/^https:\/\//i.test(String(extra?.imageURL||""))){item.imageURL=String(extra.imageURL).slice(0,1200);item.imagePublicId=String(extra.imagePublicId||"").slice(0,300);}
  if(role==="assistant"&&Array.isArray(segments)){
    item.segments=segments.slice(0,12).map(seg=>({type:seg?.type==="copy"?"copy":"text",text:String(seg?.text||"").slice(0,4000),...(seg?.type==="copy"?{label:String(seg?.label||"Copier").slice(0,60)}:{})})).filter(seg=>seg.text);
  }
  if(role==="assistant"&&Array.isArray(sources)){
    item.sources=sources.slice(0,5).map(src=>({title:String(src?.title||"").slice(0,180),url:String(src?.url||"").slice(0,1000)})).filter(src=>/^https?:\/\//i.test(src.url));
  }
  history.push(item);
  assistantSaveHistory(history);
  return item.id;
}
function assistantAttachImageToMessage(messageId,imageURL,imagePublicId=""){
  if(!messageId||!/^https:\/\//i.test(String(imageURL||"")))return;
  const history=assistantReadHistory();const item=history.find(x=>x.id===messageId&&x.role==="user");if(!item)return;
  item.imageURL=String(imageURL).slice(0,1200);item.imagePublicId=String(imagePublicId||"").slice(0,300);assistantSaveHistory(history);
}
function assistantDataUrlFile(dataUrl){
  const match=String(dataUrl||"").match(/^data:(image\/[^;]+);base64,(.+)$/i);if(!match)return null;
  try{const bin=atob(match[2]);const bytes=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)bytes[i]=bin.charCodeAt(i);return new File([bytes],`assistant-${Date.now()}.jpg`,{type:match[1]||"image/jpeg"});}catch{return null;}
}
function assistantGreeting(){return uiText("Bonjour, je suis l'Assistant LYRAME. Comment puis-je vous aider ?","Manahoana, Assistant LYRAME aho. Inona no azoko anampiana anao?","Hello, I'm the LYRAME Assistant. How can I help you?");}
function assistantRenderActiveChat({scrollToTop=false}={}){
  const box=$("#assistant-messages");if(!box)return;
  box.innerHTML="";
  const history=assistantReadHistory();
  const intro=document.createElement('div');
  intro.className='rylam-assistant-intro';
  intro.innerHTML=`<img class="rylam-assistant-hero" src="/icons/lyrame-v69-icon-512.png" alt="" /><h2>RYLAME <span class="rylam-ai-badge" aria-label="Assistant IA">✦</span></h2><p>${uiText("Les réponses sont générées par l'IA et peuvent contenir des erreurs.","Ny valiny dia vokarin'ny AI ary mety ahitana fahadisoana.","Answers are generated by AI and may be inaccurate.")}</p><small>${new Date().toLocaleDateString(state.lang==='mg'?'fr-FR':state.lang==='en'?'en-US':'fr-FR',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'})}</small>`;
  box.append(intro);
  if(history.length){
    history.forEach(x=>assistantAppend(x.role==="assistant"?"bot":"user",x.text,{segments:x.role==="assistant"?x.segments:null,sources:x.role==="assistant"?x.sources:null,imageURL:x.role==="user"?x.imageURL:null,autoScroll:false}));
  }else assistantAppend("bot",assistantGreeting(),{autoScroll:false});
  requestAnimationFrame(()=>{if(scrollToTop)$("#screen-assistant")?.scrollIntoView({block:"start"});assistantUpdateJumpLatest();});
}
function assistantRestoreHistory(){
  const box=$("#assistant-messages");if(!box)return;
  assistantUpdateStaticLabels();
  void assistantSyncFromCloud().finally(()=>{
    assistantEnsureActiveChat({createIfMissing:true});
    assistantRenderActiveChat({scrollToTop:true});
    assistantRenderChatList();
    assistantUpdateJumpLatest();
  });
}
function assistantStartNewChat(){
  if(assistantBusy){toast(uiText("Attendez la réponse en cours.","Andraso aloha ny valiny mandeha.","Wait for the current reply."));return;}
  let chats=assistantReadChats();
  const active=assistantEnsureActiveChat({createIfMissing:false});
  if(active&&!active.history.length){assistantSetActiveChatId(active.id);}
  else{
    const now=Date.now();const chat={id:assistantNewChatId(),title:assistantDefaultChatTitle(),createdAt:now,updatedAt:now,history:[]};chats=[chat,...chats];assistantWriteChats(chats);assistantSetActiveChatId(chat.id);void assistantCloudSaveChat(chat);
  }
  assistantClearImage();const input=$("#assistant-input");if(input){input.value="";input.style.height="";}
  assistantRenderActiveChat({scrollToTop:true});assistantCloseHistory();assistantRenderChatList();input?.focus();
}
function assistantOpenChat(id){
  if(assistantBusy)return;
  const chat=assistantReadChats().find(x=>x.id===id);if(!chat)return;
  assistantSetActiveChatId(chat.id);assistantClearImage();assistantRenderActiveChat({scrollToTop:true});assistantCloseHistory();
}
function assistantDeleteChat(id){
  if(assistantBusy)return;
  const chats=assistantReadChats();const target=chats.find(x=>x.id===id);if(!target)return;
  if(!confirm(uiText("Supprimer cette discussion ?","Hofafana ve ity resaka ity?","Delete this chat?")))return;
  const wasActive=assistantGetActiveChatId()===id;let next=chats.filter(x=>x.id!==id);assistantWriteChats(next);void assistantCloudDeleteChat(id);
  if(wasActive){if(next.length)assistantSetActiveChatId(next[0].id);else assistantSetActiveChatId("");assistantEnsureActiveChat({createIfMissing:true});assistantRenderActiveChat({scrollToTop:true});}
  assistantRenderChatList();
}
function assistantFormatChatTime(ts){
  try{return new Intl.DateTimeFormat(state.lang==="mg"?"mg-MG":state.lang==="en"?"en":"fr",{day:"2-digit",month:"short",hour:"2-digit",minute:"2-digit"}).format(new Date(ts));}catch{return "";}
}
function assistantRenderChatList(){
  const list=$("#assistant-chat-list");if(!list)return;
  const chats=assistantReadChats();const activeId=assistantGetActiveChatId();list.innerHTML="";
  if(!chats.length){const empty=document.createElement("div");empty.className="assistant-history-empty";empty.textContent=uiText("Aucune discussion enregistrée.","Tsy mbola misy resaka voatahiry.","No saved chats yet.");list.appendChild(empty);return;}
  chats.forEach(chat=>{
    const row=document.createElement("div");row.className="assistant-chat-row"+(chat.id===activeId?" active":"");
    const open=document.createElement("button");open.type="button";open.className="assistant-chat-open";open.addEventListener("click",()=>assistantOpenChat(chat.id));
    const title=document.createElement("strong");title.textContent=chat.title||assistantDefaultChatTitle();
    const meta=document.createElement("small");meta.textContent=assistantFormatChatTime(chat.updatedAt);
    open.append(title,meta);
    const del=document.createElement("button");del.type="button";del.className="assistant-chat-delete";del.setAttribute("aria-label",uiText("Supprimer la discussion","Fafao ny resaka","Delete chat"));del.innerHTML='<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6M10 11v5M14 11v5"/></svg>';del.addEventListener("click",()=>assistantDeleteChat(chat.id));
    row.append(open,del);list.appendChild(row);
  });
}
function assistantOpenHistory(){const sheet=$("#assistant-history-sheet");if(!sheet)return;assistantRenderChatList();assistantUpdateStaticLabels();showEl(sheet);sheet.setAttribute("aria-hidden","false");}
function assistantCloseHistory(){const sheet=$("#assistant-history-sheet");if(!sheet)return;hideEl(sheet);sheet.setAttribute("aria-hidden","true");}
function assistantScrollToLatest(){const box=$("#assistant-messages");if(!box)return;const last=box.lastElementChild;if(last)last.scrollIntoView({behavior:"smooth",block:"end"});else $("#assistant-form")?.scrollIntoView({behavior:"smooth",block:"end"});}
function assistantUpdateJumpLatest(){const btn=$("#assistant-jump-latest");if(!btn)return;const hasHistory=assistantReadHistory().length>0;btn.classList.toggle("hidden",!hasHistory);}
function assistantUpdateStaticLabels(){
  const historyBtn=$("#assistant-history-btn"),newBtn=$("#assistant-new-chat-btn"),jump=$("#assistant-jump-latest"),close=$("#assistant-history-close"),backdrop=$("#assistant-history-backdrop");
  const setLabel=(el,text)=>{if(el){el.setAttribute("aria-label",text);el.setAttribute("title",text);}};
  setLabel(historyBtn,uiText("Historique des discussions","Tantaran'ny resaka","Chat history"));setLabel(newBtn,uiText("Nouvelle discussion","Resaka vaovao","New chat"));setLabel(jump,uiText("Aller au dernier message","Mankanesa amin'ny hafatra farany","Go to latest message"));setLabel(close,uiText("Fermer","Hidio","Close"));setLabel(backdrop,uiText("Fermer","Hidio","Close"));
  setText("assistant-history-title",uiText("Discussions","Resaka","Chats"));setText("assistant-history-subtitle",uiText("Vos discussions récentes","Ireo resaka nataonao teo aloha","Your recent chats"));
}
function assistantClearImage(){
  assistantPendingImage=null;
  const input=$("#assistant-image-input");if(input)input.value="";
  const preview=$("#assistant-image-preview"),img=$("#assistant-image-preview-img");
  if(img)img.removeAttribute("src");hideEl(preview);
}
async function assistantPrepareImage(file){
  if(!file||!String(file.type||"").startsWith("image/"))throw new Error("ASSISTANT_IMAGE_TYPE");
  if(file.size>15*1024*1024)throw new Error("ASSISTANT_IMAGE_SIZE");
  const src=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(String(r.result||""));r.onerror=reject;r.readAsDataURL(file);});
  const image=await new Promise((resolve,reject)=>{const im=new Image();im.onload=()=>resolve(im);im.onerror=reject;im.src=src;});
  const maxSide=1280,scale=Math.min(1,maxSide/Math.max(image.naturalWidth||1,image.naturalHeight||1));
  const w=Math.max(1,Math.round((image.naturalWidth||1)*scale)),h=Math.max(1,Math.round((image.naturalHeight||1)*scale));
  const canvas=document.createElement("canvas");canvas.width=w;canvas.height=h;const ctx=canvas.getContext("2d");ctx.drawImage(image,0,0,w,h);
  let out=canvas.toDataURL("image/jpeg",.82);
  if(out.length>3200000)out=canvas.toDataURL("image/jpeg",.66);
  return out;
}
async function handleAssistantImageChange(){
  const file=$("#assistant-image-input")?.files?.[0];if(!file)return;
  const btn=$("#assistant-image-btn");btn?.classList.add("is-loading");
  try{
    const dataUrl=await assistantPrepareImage(file);assistantPendingImage=dataUrl;
    const img=$("#assistant-image-preview-img");if(img)img.src=dataUrl;showEl($("#assistant-image-preview"));
  }catch(err){console.warn("[assistant image]",err);assistantClearImage();toast(uiText("Image impossible à charger.","Tsy afaka mampakatra ilay sary.","Unable to load the image."));}
  finally{btn?.classList.remove("is-loading");}
}
async function handleAssistantSubmit(e){
  e.preventDefault();
  if(assistantBusy)return;
  const input=$("#assistant-input");
  const q=(input?.value||"").trim();
  const imageDataUrl=assistantPendingImage;
  if(!q&&!imageDataUrl)return;
  const historyBefore=assistantReadHistory();
  const displayQ=q||uiText("Image jointe","Sary nampiarahana","Attached image");
  assistantAppend("user",displayQ,{imageDataUrl});
  const userMessageId=assistantPushHistory("user",displayQ);
  if(imageDataUrl){
    const imageFile=assistantDataUrlFile(imageDataUrl);
    if(imageFile)void uploadMedia(imageFile,{folder:`lyrame/assistant/${assistantCurrentUid()||"user"}`,resourceType:"image"}).then(upload=>{if(upload?.url)assistantAttachImageToMessage(userMessageId,upload.url,upload.publicId||"");}).catch(err=>console.warn("[assistant image history upload]",err));
  }
  input.value="";
  input.style.height="";
  assistantClearImage();
  assistantBusy=true;
  const submit=$("#assistant-form")?.querySelector('button[type="submit"]');
  if(submit)submit.disabled=true;
  const pending=assistantAppend("bot","…",{pending:true});
  try{
    const r=await fetch(LYRAME_ASSISTANT_ENDPOINT,{
      method:"POST",
      headers:{"Content-Type":"text/plain;charset=UTF-8"},
      body:JSON.stringify({
        message:q||uiText("Analyse cette image et réponds à ce que tu y vois.","Diniho ity sary ity ary valio araka izay hitanao.","Analyze this image and respond based on what you see."),
        ...(imageDataUrl?{imageDataUrl}:{}),
        language:state.lang||"fr",
        userId:state.currentUser?.uid||null,
        history:historyBefore.slice(-20)
      })
    });
    const data=await r.json().catch(()=>({}));
    if(!r.ok){
      const err=new Error(data?.error||("ASSISTANT_HTTP_"+r.status));
      err.code=data?.code||"";
      throw err;
    }
    const reply=String(data?.reply||"").trim();
    if(!reply)throw new Error("ASSISTANT_EMPTY_REPLY");
    pending?.remove();
    const segments=Array.isArray(data?.segments)?data.segments:null;
    const sources=Array.isArray(data?.sources)?data.sources:null;
    assistantAppend("bot",reply,{segments,sources});
    assistantPushHistory("assistant",reply,segments,sources);
  }catch(err){
    console.warn("[assistant backend]",err);
    pending?.remove();
    assistantAppend("bot",err?.code==="GEMINI_RATE_LIMIT"
      ?uiText("L'Assistant reçoit beaucoup de demandes. Réessayez dans un instant.","Betsaka ny fangatahana alefa amin'ny Assistant izao. Andramo indray afaka kelikely.","The Assistant is receiving many requests. Please retry shortly.")
      :uiText("Impossible de joindre l'Assistant pour le moment. Vérifiez votre connexion puis réessayez.","Tsy afaka mifandray amin'ny Assistant izao. Jereo ny internet dia andramo indray.","The Assistant can't be reached right now. Check your connection and try again."));
  }finally{
    assistantBusy=false;
    if(submit)submit.disabled=false;
    input?.focus();
  }
}

/* ============================================================
   LYRAME PUSH NOTIFICATIONS — Firebase Cloud Messaging (Web/TWA)
   Version 36: VAPID + FCM token privé par utilisateur.
   Le backend Cloud Functions envoie les notifications lorsque
   l'application est en arrière-plan ou fermée.
   ============================================================ */
async function getLyrameMessaging() {
  if (lyrameMessagingPromise) return lyrameMessagingPromise;
  lyrameMessagingPromise = (async () => {
    if (typeof window === "undefined" || !("serviceWorker" in navigator) || typeof Notification === "undefined") return null;
    try {
      if (!(await isMessagingSupported())) return null;
      return getMessaging(app);
    } catch (err) {
      console.warn("[LYRAME push] messaging unavailable", err);
      return null;
    }
  })();
  return lyrameMessagingPromise;
}

function registerLyrameServiceWorker() {
  if (!("serviceWorker" in navigator) || window.location.protocol !== "https:") return Promise.resolve(null);
  if (!lyrameSwRegistrationPromise) {
    lyrameSwRegistrationPromise = navigator.serviceWorker.register(LYRAME_SW_URL, { scope: "/" })
      .then(reg => navigator.serviceWorker.ready.then(() => reg))
      .catch(err => {
        lyrameSwRegistrationPromise = null;
        console.warn("[LYRAME PWA] Service worker registration failed:", err);
        return null;
      });
  }
  return lyrameSwRegistrationPromise;
}

async function lyramePushTokenId(token) {
  try {
    const bytes = new TextEncoder().encode(String(token || ""));
    const digest = await crypto.subtle.digest("SHA-256", bytes);
    return Array.from(new Uint8Array(digest)).map(b => b.toString(16).padStart(2, "0")).join("");
  } catch (_) {
    return String(token || "").replace(/[^A-Za-z0-9_-]/g, "_").slice(-180);
  }
}

function lyramePushPermissionLabel() {
  if (typeof Notification === "undefined") return uiText("Non pris en charge", "Tsy tohanan'ny fitaovana", "Not supported");
  if (Notification.permission === "granted") return uiText("Activées sur cet appareil", "Mandeha amin'ity fitaovana ity", "Enabled on this device");
  if (Notification.permission === "denied") return uiText("Bloquées dans les réglages du téléphone/navigateur", "Voasakana ao amin'ny réglage téléphone/navigateur", "Blocked in phone/browser settings");
  return uiText("Pas encore activées sur cet appareil", "Mbola tsy alefa amin'ity fitaovana ity", "Not enabled on this device yet");
}

function renderLyramePushStatus() {
  const status = $("#settings-push-status");
  const btn = $("#settings-enable-push-btn");
  if (status) status.textContent = lyramePushPermissionLabel();
  if (btn) {
    const granted = typeof Notification !== "undefined" && Notification.permission === "granted";
    btn.textContent = granted
      ? uiText("Synchroniser cet appareil", "Ampifandraiso indray ity fitaovana ity", "Sync this device")
      : uiText("Activer sur cet appareil", "Alefaso amin'ity fitaovana ity", "Enable on this device");
    btn.disabled = typeof Notification === "undefined" || Notification.permission === "denied";
  }
}

async function saveLyramePushToken(token) {
  if (!state.currentUser?.uid || !token) return false;
  const uid = state.currentUser.uid;
  const tokenDocId = await lyramePushTokenId(token);
  if (!tokenDocId) return false;
  await setDoc(doc(db, "users", uid, "pushTokens", tokenDocId), {
    ownerId: uid,
    token,
    platform: navigator.userAgentData?.platform || navigator.platform || "web",
    userAgent: String(navigator.userAgent || "").slice(0, 500),
    lastSeenAt: serverTimestamp(),
    updatedAt: serverTimestamp()
  }, { merge: true });
  lyramePushRuntime.token = token;
  lyramePushRuntime.tokenDocId = tokenDocId;
  lyramePushRuntime.registeredUid = uid;
  return true;
}

async function syncLyramePushRegistration({ requestPermission = false } = {}) {
  if (!state.currentUser?.uid) return false;
  if (state.currentProfile?.notificationsEnabled === false) {
    renderLyramePushStatus();
    return false;
  }
  if (typeof Notification === "undefined") {
    renderLyramePushStatus();
    return false;
  }
  let permission = Notification.permission;
  if (permission === "default" && requestPermission) permission = await Notification.requestPermission();
  if (permission !== "granted") {
    renderLyramePushStatus();
    return false;
  }
  const [messaging, registration] = await Promise.all([getLyrameMessaging(), registerLyrameServiceWorker()]);
  if (!messaging || !registration) {
    renderLyramePushStatus();
    return false;
  }
  try {
    const token = await getToken(messaging, {
      vapidKey: LYRAME_VAPID_PUBLIC_KEY,
      serviceWorkerRegistration: registration
    });
    if (!token) throw new Error("FCM_TOKEN_EMPTY");
    await saveLyramePushToken(token);
    if (!lyrameForegroundMessageUnsubscribe) {
      lyrameForegroundMessageUnsubscribe = onMessage(messaging, payload => {
        console.debug("[LYRAME push foreground]", payload?.data?.type || "notification");
      });
    }
    renderLyramePushStatus();
    return true;
  } catch (err) {
    console.warn("[LYRAME push registration]", err);
    renderLyramePushStatus();
    return false;
  }
}

async function unregisterLyramePushForCurrentDevice() {
  const uid = state.currentUser?.uid || lyramePushRuntime.registeredUid;
  try {
    if (uid && lyramePushRuntime.tokenDocId) {
      await deleteDoc(doc(db, "users", uid, "pushTokens", lyramePushRuntime.tokenDocId));
    }
  } catch (err) {
    console.warn("[LYRAME push token doc delete]", err);
  }
  try {
    const messaging = await getLyrameMessaging();
    if (messaging) await deleteToken(messaging);
  } catch (err) {
    console.warn("[LYRAME push token delete]", err);
  }
  lyramePushRuntime.token = "";
  lyramePushRuntime.tokenDocId = "";
  lyramePushRuntime.registeredUid = "";
}

async function handleLyramePushEnableClick() {
  if (!state.currentUser) return;
  if (typeof Notification !== "undefined" && Notification.permission === "denied") {
    toast(uiText("Autorisez les notifications de LYRAME dans les réglages du téléphone ou de Chrome.", "Omeo alalana ao amin'ny réglage téléphone na Chrome ny notification LYRAME.", "Allow LYRAME notifications in your phone or Chrome settings."));
    renderLyramePushStatus();
    return;
  }
  const ok = await syncLyramePushRegistration({ requestPermission: true });
  toast(ok
    ? uiText("Notifications téléphone activées.", "Mandeha ny notification amin'ny téléphone.", "Phone notifications enabled.")
    : uiText("Impossible d'activer les notifications sur cet appareil.", "Tsy afaka nampandeha notification tamin'ity fitaovana ity.", "Could not enable notifications on this device."));
}

if (typeof navigator !== "undefined" && "serviceWorker" in navigator) {
  navigator.serviceWorker.addEventListener("message", event => {
    if (event?.data?.type !== "LYRAME_PUSH_OPEN" || !event.data.url) return;
    try { location.assign(new URL(event.data.url, location.origin).href); } catch (_) {}
  });
}

/* ---------- message privacy ---------- */
async function loadMessagePrivacy(){if(!state.currentUser)return;const sel=$("#settings-message-privacy"),notif=$("#settings-notifications-enabled");if(sel)sel.value=state.currentProfile?.messagePrivacy||"everyone";if(notif)notif.checked=state.currentProfile?.notificationsEnabled!==false;setText("settings-theme-current",state.theme==="dark"?uiText("Sombre","Maizina","Dark"):uiText("Clair","Mazava","Light"));renderLyramePushStatus();}
async function saveSettingPatch(patch){if(!state.currentUser)return;try{await setDoc(doc(db,"users",state.currentUser.uid),{...patch,updatedAt:serverTimestamp()},{merge:true});}catch(err){logError("[settings patch]",err);}}

/* ---------- menu profile ---------- */
function renderMainMenu(){
  const box = $("#menu-profile-summary");
  if (!box) return;
  const profile = state.currentProfile || {};
  const name = profile.fullname || state.currentUser?.displayName || uiSomeone();
  const username = profile.username ? `@${escapeHtml(profile.username)}` : "";
  const photo = profile.photoURL || state.currentUser?.photoURL;
  box.innerHTML = `<span class="avatar lyr-v965-avatar">${avatarMarkup(photo,name)}</span>`+
    `<span class="lyr-v965-profile-copy"><strong class="lyr-v965-profile-name">${escapeHtml(name)}${identityBadgeMarkup(profile)}</strong><small class="lyr-v965-handle">${username}</small></span>`+
    `<button type="button" class="btn lyr-v965-profile-action" id="menu-open-profile"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="8" r="3.5"/><path d="M5 20c0-4 2.8-6 7-6s7 2 7 6"/></svg><span>${escapeHtml(uiText("Profil","Profil","Profile"))}</span></button>`;
  $("#menu-open-profile")?.addEventListener("click", () => showScreen("profile-me"));
  lyrV965TranslateMenu();
}
const LYR_V965_MENU_LABELS = Object.freeze({
  dashboard: ["Tableau de bord", "Tabilao", "Dashboard"],
  messages: ["Messages", "Hafatra", "Messages"],
  groups: ["Groupes", "Vondrona", "Groups"],
  friends: ["Ami(e)s", "Namana", "Friends"],
  suggestions: ["Découvrir des ami(e)s", "Hitady namana", "Discover friends"],
  invite: ["Inviter des ami(e)s", "Manasa namana", "Invite friends"],
  marketplace: ["Marketplace", "Tsena", "Marketplace"],
  pages: ["Pages", "Pejy", "Pages"],
  "saved-posts": ["Enregistrements", "Voatahiry", "Saved"],
  home: ["Fils", "Fahita vaovao", "Feed"],
  help: ["Aide et assistance", "Fanampiana", "Help and support"]
});
function lyrV965TranslateMenu(){
  const idx = state.lang === "mg" ? 1 : state.lang === "en" ? 2 : 0;
  document.querySelectorAll("#screen-menu [data-lyr-v965-label]").forEach(label => {
    const names = LYR_V965_MENU_LABELS[label.dataset.lyrV965Label];
    if (!names) return;
    label.textContent = names[idx];
    label.closest("button")?.setAttribute("aria-label", names[idx]);
  });
  lyrV966TranslateNavigation();
}
const LYR_V966_TEXT = {
  fr: {community:"Communauté",spaces:"Vos espaces",support:"Assistance",admin:"Administration LYRAME",adminDesc:"Gestion de la plateforme",requests:"Demandes d'amis"},
  mg: {community:"Fiarahamonina",spaces:"Ny sehatrao",support:"Fanampiana",admin:"Fitantanana LYRAME",adminDesc:"Fitantanana ny sehatra",requests:"Fangatahana finamanana"},
  en: {community:"Community",spaces:"Your spaces",support:"Support",admin:"LYRAME Administration",adminDesc:"Manage the platform",requests:"Friend requests"}
};
function lyrV966TranslateNavigation(){
  const lex=LYR_V966_TEXT[state.lang]||LYR_V966_TEXT.fr;
  document.querySelectorAll('[data-lyr-v966]').forEach(el=>{
    const content=lex[el.dataset.lyrV966]; if(content)el.textContent=content;
  });
}
function lyrV966RenderPendingRequests(){
  const badge=document.getElementById('friends-requests-pending');
  if(!badge)return;
  const count=state.incomingRequests?.length||0;
  badge.textContent=String(count);
  badge.classList.toggle('hidden',count===0);
  badge.hidden=count===0;
}

/* enrich showScreen with final modules */
const _baseShowScreen=showScreen;
showScreen=function(name,opts={}){_baseShowScreen(name,opts);closeHeaderInlineSearch();if(name!=="assistant")assistantCloseHistory();if(name==="search")renderSearchRecents();if(name==="suggestions")loadSuggestions();if(name==="dashboard")loadDashboard();if(name==="pages")loadPages();if(name==="page-detail")loadPageDetail();if(name==="marketplace")loadMarketplace();if(name==="listing-detail")loadListingDetail();if(name==="settings"){
  loadMessagePrivacy();
  lyrV964TranslateSettings();
}if(name==="menu")renderMainMenu();if(name==="friends")lyrV966RenderPendingRequests();if(name==="assistant")assistantRestoreHistory();};

function initFinalFeatures(){
  $("#header-search-close")?.addEventListener("click",closeHeaderInlineSearch);
  $("#header-inline-search")?.addEventListener("submit",e=>{e.preventDefault();const q=($("#header-search-input")?.value||"").trim();showScreen("search");const input=$("#search-input");if(input){input.value=q;runSearch(q);}});
  $("#header-search-input")?.addEventListener("input",e=>{ if(e.target.value.trim().length>=2){const input=$("#search-input");if(input)input.value=e.target.value;} });
  $("#search-form")?.addEventListener("submit",e=>{e.preventDefault();runSearch($("#search-input")?.value||"");});
  $("#search-clear-recents")?.addEventListener("click",()=>{state.recentSearches=[];persistSearchRecentsCloud();renderSearchRecents();});
  renderSearchRecents();
  $("#story-create-btn")?.addEventListener("click",e=>{const plus=e.target?.closest?.(".story-plus");if(!plus&&(lyrameStoryV37.myStories||[]).length){lyrameOpenStoryQueue(lyrameStoryV37.myStories,0);return;}$("#story-file-input")?.click();});
  $("#story-file-input")?.addEventListener("change",async e=>{const f=e.target.files?.[0];e.target.value="";if(f)await createStory(f);});
  $("#story-viewer-close")?.addEventListener("click",()=>{clearTimeout(state.storyTimer);hideEl($("#story-viewer"));});
  $("#media-viewer-close")?.addEventListener("click",()=>{hideEl($("#media-viewer"));hideEl($("#media-viewer-menu"));state.mediaViewerGallery=false;});
  $("#media-viewer-menu-btn")?.addEventListener("click", e => {
    e.stopPropagation();
    const menu = $("#media-viewer-menu");
    if (!menu) return;
    const opening = menu.classList.contains("hidden");
    menu.classList.toggle("hidden");
    if (opening) lyrameAndroidPushOverlay(menu);
    else lyrameAndroidOverlayClosed("media-viewer-menu");
  });
  $("#media-viewer-prev")?.addEventListener("click",()=>{state.mediaViewerIndex=(state.mediaViewerIndex-1+state.mediaViewerItems.length)%state.mediaViewerItems.length;renderMediaViewer();});
  $("#media-viewer-next")?.addEventListener("click",()=>{state.mediaViewerIndex=(state.mediaViewerIndex+1)%state.mediaViewerItems.length;renderMediaViewer();});
  // Keep the existing Create Group action reachable while matching the compact reference header.
  const createGroupBtn=$("#messages-create-group-btn"),searchZone=$("#screen-messages .messages-search-wrap");
  if(createGroupBtn && searchZone){
    createGroupBtn.classList.add('messages-create-group-search');
    createGroupBtn.insertAdjacentText('beforeend',uiText('Créer un groupe','Hamorona vondrona','Create group'));
    searchZone.appendChild(createGroupBtn);
  }
  $("#messages-assistant-entry")?.addEventListener("click",()=>showScreen("assistant"));
  $("#conversation-assistant-fab")?.addEventListener("click",()=>showScreen("assistant"));
  $("#messages-search-toggle")?.addEventListener("click",()=>{
    const screen=$("#screen-messages"), field=$("#messages-search");
    screen?.classList.toggle("is-searching");
    if(screen?.classList.contains("is-searching"))field?.focus();
    else {if(field)field.value="";hideEl($("#messages-search-results"));}
  });
  $("#messages-new-message")?.addEventListener("click",()=>{
    $("#screen-messages")?.classList.add("is-searching");
    const search=$("#messages-search"); search?.focus();
    search?.scrollIntoView({block:"nearest",behavior:"smooth"});
  });
  $("#assistant-form")?.addEventListener("submit",handleAssistantSubmit);
  $("#assistant-image-btn")?.addEventListener("click",()=>$("#assistant-image-input")?.click());
  $("#assistant-image-input")?.addEventListener("change",handleAssistantImageChange);
  $("#assistant-image-remove")?.addEventListener("click",assistantClearImage);
  $("#assistant-new-chat-btn")?.addEventListener("click",assistantStartNewChat);
  $("#assistant-history-btn")?.addEventListener("click",assistantOpenHistory);
  $("#assistant-history-close")?.addEventListener("click",assistantCloseHistory);
  $("#assistant-history-backdrop")?.addEventListener("click",assistantCloseHistory);
  $("#assistant-jump-latest")?.addEventListener("click",assistantScrollToLatest);
  $("#page-create-open")?.addEventListener("click",()=>{if(!state.profileExists){toast(uiText("Créez d’abord votre profil.","Mamoròna profil aloha.","Create your profile first."));return;}showScreen("page-create");});
  $("#page-create-form")?.addEventListener("submit",handlePageCreate);
  $("#pages-search")?.addEventListener("input",e=>loadPages(e.target.value));
  $("#listing-create-open")?.addEventListener("click",()=>showScreen("listing-create"));
  $("#listing-create-form")?.addEventListener("submit",handleListingCreate);
  $("#listing-photos")?.addEventListener("change",e=>{const box=$("#listing-preview");if(!box)return;box.innerHTML="";Array.from(e.target.files||[]).slice(0,10).forEach(f=>{const img=document.createElement("img");img.src=URL.createObjectURL(f);img.onload=()=>URL.revokeObjectURL(img.src);box.appendChild(img);});});
  ["#marketplace-search","#marketplace-category","#marketplace-status"].forEach(sel=>$(sel)?.addEventListener(sel.includes("search")?"input":"change",loadMarketplace));
  $("#settings-message-privacy")?.addEventListener("change",e=>saveSettingPatch({messagePrivacy:e.target.value}));
  $("#settings-notifications-enabled")?.addEventListener("change",async e=>{
    const enabled=!!e.target.checked;
    state.currentProfile={...(state.currentProfile||{}),notificationsEnabled:enabled};
    await saveSettingPatch({notificationsEnabled:enabled});
    if(enabled) await syncLyramePushRegistration({requestPermission:true});
    renderLyramePushStatus();
  });
  $("#settings-enable-push-btn")?.addEventListener("click",handleLyramePushEnableClick);
  $("#settings-theme-row")?.addEventListener("click",()=>{toggleTheme();setText("settings-theme-current",state.theme==="dark"?uiText("Sombre","Maizina","Dark"):uiText("Clair","Mazava","Light"));});
  $("#menu-logout-btn")?.addEventListener("click",handleLogout);
  loadStories();
  const avatar=$("#story-create-avatar");if(avatar){const p=state.currentProfile||{};avatar.innerHTML=avatarMarkup(p.photoURL||state.currentUser?.photoURL,p.fullname||state.currentUser?.displayName||"");}
}

/* Wait until the original init has bound its controls, then add final modules. */
document.addEventListener("DOMContentLoaded",()=>window.setTimeout(initFinalFeatures,0),{once:true});

/* ---------- Message reactions / long press / forward ---------- */
async function setMessageReaction(message, emoji){
  if(!state.currentUser||!state.activeConvId||!message?.id)return;
  const ref=doc(db,"conversations",state.activeConvId,"messages",message.id);
  const snap=await getDoc(ref); if(!snap.exists())return;
  const reactions={...(snap.data().reactions||{})};
  if(reactions[state.currentUser.uid]===emoji) delete reactions[state.currentUser.uid]; else reactions[state.currentUser.uid]=emoji;
  await updateDoc(ref,{reactions,updatedAt:serverTimestamp()});
}
async function forwardMessage(message){
  if(!state.currentUser||!message)return;
  const modal=openDynamicModal(uiText("Transférer","Handefa indray","Forward"));
  try{
    const snap=await getDocs(query(collection(db,"conversations"),where("memberIds","array-contains",state.currentUser.uid),limit(100))).catch(()=>getDocs(query(collection(db,"conversations"),where("members","array-contains",state.currentUser.uid),limit(100))));
    const wrap=document.createElement("div");
    snap.docs.filter(d=>d.id!==state.activeConvId).forEach(d=>{const c=d.data();const b=document.createElement("button");b.type="button";b.className="forward-conv-row";const title=c.name||c.title||uiConversation();b.innerHTML=`<span class="avatar">${avatarMarkup(c.photoURL||c.coverURL||"",title)}</span><span>${escapeHtml(title)}</span>`;b.addEventListener("click",async()=>{const ref=doc(collection(db,"conversations",d.id,"messages"));const batch=writeBatch(db);batch.set(ref,{senderId:state.currentUser.uid,senderName:state.currentProfile?.fullname||"",text:message.text||"",mediaURL:message.mediaURL||"",mediaPublicId:"",mediaType:message.mediaType||"",replyTo:null,forwardedFrom:{conversationId:state.activeConvId,messageId:message.id},readBy:[state.currentUser.uid],deletedFor:[],deletedForEveryone:false,createdAt:serverTimestamp()});batch.update(doc(db,"conversations",d.id),{lastMessage:(message.text||`[${message.mediaType||"message"}]`).slice(0,120),lastMessageAt:serverTimestamp(),updatedAt:serverTimestamp()});await batch.commit();modal.close();toast(uiText("Message transféré.","Nalefa indray ny hafatra.","Message forwarded."));});wrap.appendChild(b);});if(!wrap.children.length)wrap.innerHTML=`<p class="muted">${escapeHtml(uiText("Aucune autre conversation.","Tsy misy conversation hafa.","No other conversation."))}</p>`;modal.body.appendChild(wrap);
  }catch(err){logError("[forward]",err);modal.body.textContent=t("err_generic");}
}
function openMessageActionSheet(message){
  const modal=openDynamicModal(uiText("Message","Hafatra","Message"));
  const wrap=document.createElement("div");wrap.className="message-action-sheet";
  const rp=document.createElement("div");rp.className="message-reaction-picker";["👍","❤️","😇","🤗","🤣","😀"].forEach(emoji=>{const b=document.createElement("button");b.type="button";b.textContent=emoji;b.addEventListener("click",async()=>{await setMessageReaction(message,emoji);modal.close();});rp.appendChild(b);});wrap.appendChild(rp);
  const addAction=(label,fn,kind="secondary")=>{const b=styledButton(label,kind);b.addEventListener("click",()=>{modal.close();fn();});wrap.appendChild(b);};
  if(message.text)addAction(uiText("Copier le texte","Handika lahatsoratra","Copy text"),async()=>{try{await navigator.clipboard.writeText(message.text);toast(uiText("Texte copié.","Voadika ny lahatsoratra.","Text copied."));}catch(_){}});
  addAction(uiText("Répondre","Hamaly","Reply"),()=>{setMessageReply(message);$("#conv-text")?.focus();});
  addAction(uiText("Transférer","Handefa indray","Forward"),()=>forwardMessage(message));
  addAction(uiText("Supprimer","Hamafa","Delete"),()=>openMessageDeleteActions(message),message.senderId===state.currentUser?.uid?"danger":"secondary");
  modal.body.appendChild(wrap);
}
const _baseRenderMessage=renderMessage;
renderMessage=function(m){
  const el=_baseRenderMessage(m); if(m.deletedForEveryone)return el;

  /* Les réactions restent visuellement hors de la bulle, à la manière d'un badge. */
  const reactions=m.reactions&&typeof m.reactions==="object"?m.reactions:{};
  const counts={};
  Object.entries(reactions).forEach(([uid,e])=>{if(e)counts[e]=(counts[e]||0)+1;});
  if(Object.keys(counts).length){
    const line=document.createElement("div");
    line.className="message-reaction-line";
    Object.entries(counts).forEach(([e,n])=>{
      const b=document.createElement("button");
      b.type="button";
      b.className="message-reaction-pill"+(reactions[state.currentUser?.uid]===e?" mine":"");
      b.textContent=n>1?`${e} ${n}`:e;
      b.setAttribute("aria-label",`${e} ${n}`);
      b.addEventListener("click",ev=>{ev.preventDefault();ev.stopPropagation();setMessageReaction(m,e);});
      line.appendChild(b);
    });
    el.classList.add("has-message-reactions");
    el.appendChild(line);
  }

  /* Date/heure masquée par défaut : un tap sur CETTE bulle seulement l'affiche / la masque. */
  let timer=null;
  el.addEventListener("click",e=>{
    if(e.target.closest("button,audio,video,a,.message-reaction-line"))return;
    el.classList.toggle("is-meta-open");
  });
  el.addEventListener("pointerdown",e=>{
    if(e.target.closest("button,audio,video,a,.message-reaction-line"))return;
    timer=setTimeout(()=>openMessageActionSheet(m),620);
  });
  ["pointerup","pointerleave","pointercancel"].forEach(ev=>el.addEventListener(ev,()=>clearTimeout(timer)));
  return el;
};

/* ---------- Group discovery / membership / admin requests ---------- */
state.groupDiscoveryTab = "mine";
async function loadGroupsDiscovery(){
  const list=$("#groups-discovery-list"); if(!list||!state.currentUser)return; list.innerHTML="";
  const term=($("#groups-search")?.value||"").trim().toLowerCase();
  try{
    let snap;
    if(state.groupDiscoveryTab==="mine") snap=await getDocs(query(collection(db,"conversations"),where("memberIds","array-contains",state.currentUser.uid),limit(100)));
    else snap=await getDocs(query(collection(db,"conversations"),where("type","==","group"),limit(100)));
    let groups=snap.docs.map(d=>({id:d.id,...d.data()})).filter(c=>(c.type==="group"||c.isGroup===true)&&(!term||String(c.name||"").toLowerCase().includes(term)||String(c.description||"").toLowerCase().includes(term)));
    if(state.groupDiscoveryTab!=="mine")groups=groups.filter(c=>c.privacy!=="private"||c.memberIds?.includes(state.currentUser.uid));
    if(state.groupDiscoveryTab==="top")groups.sort((a,b)=>(Number(b.visitsCount||0)+(b.memberIds?.length||0))-(Number(a.visitsCount||0)+(a.memberIds?.length||0)));
    groups.forEach(c=>{
      const member=c.memberIds?.includes(state.currentUser.uid); const card=document.createElement("article"); card.className="entity-card";
      const cover=groupCover(c); card.innerHTML=`<div class="cover">${cover?`<img src="${escapeHtml(safeUrl(cover))}" alt="">`:""}</div><div class="body"><h3>${escapeHtml(c.name||uiGroup())}</h3><p>${escapeHtml(String(c.description||"").slice(0,120))}</p><p>${c.memberIds?.length||0} ${escapeHtml(uiText("membres","mpikambana","members"))} · ${escapeHtml(c.privacy==="private"?uiText("Privé","Manokana","Private"):uiText("Public","Ho an'ny rehetra","Public"))}</p><div class="group-card-actions"></div></div>`;
      const actions=card.querySelector(".group-card-actions"); const open=document.createElement("button");open.type="button";open.className="btn btn-ghost btn-sm";open.textContent=uiText("Voir","Hijery","View");open.addEventListener("click",()=>openGroupDiscoveryItem(c.id));actions.appendChild(open);
      if(!member){const join=document.createElement("button");join.type="button";join.className="btn btn-primary btn-sm";join.textContent=uiText("Rejoindre","Hiditra","Join");join.addEventListener("click",async()=>{await requestJoinGroup(c);});actions.appendChild(join);}
      list.appendChild(card);
    });
    if(!list.children.length)list.innerHTML=`<div class="empty-state"><p class="empty-title">${escapeHtml(uiText("Aucun groupe","Tsy misy vondrona","No groups"))}</p></div>`;
  }catch(err){logError("[groups discovery]",err);}
}
async function requestJoinGroup(c){
  if(!state.currentUser||!c?.id)return;
  try{
    if(c.privacy!=="private"){
      await updateDoc(doc(db,"conversations",c.id),{memberIds:arrayUnion(state.currentUser.uid),updatedAt:serverTimestamp()});
      toast(uiText("Vous avez rejoint le groupe.","Tafiditra ao amin'ny vondrona ianao.","You joined the group.")); loadGroupsDiscovery(); return;
    }
    const id=`${c.id}_${state.currentUser.uid}`;
    await setDoc(doc(db,"groupJoinRequests",id),{groupId:c.id,userId:state.currentUser.uid,userName:state.currentProfile?.fullname||state.currentUser.displayName||"",userPhotoURL:state.currentProfile?.photoURL||"",status:"pending",createdAt:serverTimestamp(),updatedAt:serverTimestamp()},{merge:true});
    toast(uiText("Demande envoyée aux administrateurs.","Nalefa amin'ny admin ny fangatahana.","Request sent to the admins."));
  }catch(err){logError("[group join]",err);toast(t("err_generic"));}
}
async function renderGroupJoinRequests(c){
  if(!canManageGroup(c,state.currentUser?.uid))return;
  const host=$("#group-owner-settings"); if(!host)return; let box=$("#group-join-requests"); if(!box){box=document.createElement("div");box.id="group-join-requests";box.className="group-request-list";host.appendChild(box);} box.innerHTML="";
  try{const snap=await getDocs(query(collection(db,"groupJoinRequests"),where("groupId","==",c.id),where("status","==","pending"),limit(100)));if(snap.empty)return;const title=document.createElement("h4");title.textContent=uiText("Demandes d'adhésion","Fangatahana hiditra","Join requests");box.appendChild(title);snap.docs.forEach(d=>{const r=d.data();const row=document.createElement("div");row.className="group-request-row";row.innerHTML=`<span class="avatar">${avatarMarkup(r.userPhotoURL,r.userName)}</span><span class="grow">${escapeHtml(r.userName||uiSomeone())}</span>`;const accept=makeSmallButton(uiText("Accepter","Ekeo","Accept"),"primary",async()=>{await updateDoc(doc(db,"conversations",c.id),{memberIds:arrayUnion(r.userId),updatedAt:serverTimestamp()});await updateDoc(d.ref,{status:"accepted",updatedAt:serverTimestamp()});renderGroupJoinRequests({...c,memberIds:[...(c.memberIds||[]),r.userId]});});const reject=makeSmallButton(uiText("Refuser","Lavina","Reject"),"ghost",async()=>{await updateDoc(d.ref,{status:"rejected",updatedAt:serverTimestamp()});row.remove();});row.append(accept,reject);box.appendChild(row);});}catch(err){console.warn("[group requests]",err);}
}
async function ensureGroupPostsPanel(c){
  const info=$("#group-info-content"); if(!info||!c?.id)return; let panel=$("#group-posts-panel"); if(!panel){panel=document.createElement("section");panel.id="group-posts-panel";panel.className="dashboard-panel";info.after(panel);} panel.innerHTML="";
  const member=c.memberIds?.includes(state.currentUser?.uid); if(member){const form=document.createElement("form");form.className="page-composer";form.innerHTML=`<strong>${escapeHtml(uiText("Publier dans le groupe","Hamoaka ao amin'ny vondrona","Post in group"))}</strong><textarea maxlength="3000" placeholder="${escapeHtml(uiText("Écrivez quelque chose…","Manorata zavatra…","Write something…"))}"></textarea><button class="btn btn-primary btn-sm" type="submit">${escapeHtml(uiText("Publier","Hamoaka","Post"))}</button>`;form.addEventListener("submit",async e=>{e.preventDefault();const text=form.querySelector("textarea").value.trim();if(!text)return;await addDoc(collection(db,"conversations",c.id,"posts"),{authorId:state.currentUser.uid,authorName:state.currentProfile?.fullname||"",authorUsername:state.currentProfile?.username||"",authorPhotoURL:state.currentProfile?.photoURL||"",authorBadgeType:badgeTypeOf(state.currentProfile||{}),text,createdAt:serverTimestamp(),updatedAt:serverTimestamp()});form.reset();ensureGroupPostsPanel(c);});panel.appendChild(form);}
  try{const snap=await getDocs(query(collection(db,"conversations",c.id,"posts"),orderBy("createdAt","desc"),limit(50)));snap.docs.forEach(d=>{const p={id:d.id,...d.data()};const a=document.createElement("article");a.className="page-post-card";a.innerHTML=`<div class="post-head"><span class="avatar">${avatarMarkup(p.authorPhotoURL,p.authorName)}</span><div><strong>${escapeHtml(p.authorName||uiSomeone())}${identityBadgeMarkup({badgeType:p.authorBadgeType})}</strong><small class="muted">${escapeHtml(formatTime(p.createdAt))}</small></div></div><p>${escapeHtml(p.text||"")}</p>`;if(p.authorId===state.currentUser?.uid||canManageGroup(c,state.currentUser?.uid)){const del=makeSmallButton(uiText("Supprimer","Hamafa","Delete"),"ghost",async()=>{await deleteDoc(doc(db,"conversations",c.id,"posts",p.id));a.remove();});a.appendChild(del);}panel.appendChild(a);});}catch(err){console.warn("[group posts]",err);}
}
const _baseRenderGroupInfo=renderGroupInfo;
renderGroupInfo=function(c){_baseRenderGroupInfo(c);renderGroupJoinRequests(c);ensureGroupPostsPanel(c);if(c?.id&&state.currentUser&&c.memberIds?.includes(state.currentUser.uid)){updateDoc(doc(db,"conversations",c.id),{visitsCount:increment(1),updatedAt:serverTimestamp()}).catch(()=>{});}};

/* ---------- Page publications ---------- */
async function loadPagePosts(p,isAdmin){
  const root=$("#page-posts"); if(!root)return; root.innerHTML="";
  if(isAdmin){const form=document.createElement("form");form.className="page-composer";form.innerHTML=`<strong>${escapeHtml(uiText("Publier en tant que Page","Hamoaka amin'ny anaran'ny Page","Post as Page"))}</strong><textarea maxlength="3000" placeholder="${escapeHtml(uiText("Écrivez une publication…","Manorata publication…","Write a post…"))}"></textarea><button type="submit" class="btn btn-primary btn-sm">${escapeHtml(uiText("Publier","Hamoaka","Post"))}</button>`;form.addEventListener("submit",async e=>{e.preventDefault();const text=form.querySelector("textarea").value.trim();if(!text)return;await addDoc(collection(db,"pages",p.id,"posts"),{pageId:p.id,pageName:p.name,pageAvatarURL:p.avatarURL||"",authorAdminId:state.currentUser.uid,text,createdAt:serverTimestamp(),updatedAt:serverTimestamp()});form.reset();loadPagePosts(p,isAdmin);});root.appendChild(form);}
  try{const snap=await getDocs(query(collection(db,"pages",p.id,"posts"),orderBy("createdAt","desc"),limit(50)));snap.docs.forEach(d=>{const post={id:d.id,...d.data()};const a=document.createElement("article");a.className="page-post-card";a.innerHTML=`<div class="post-head"><span class="avatar">${avatarMarkup(p.avatarURL,p.name)}</span><div><strong>${escapeHtml(p.name||"Page")}</strong><small class="muted">${escapeHtml(formatTime(post.createdAt))}</small></div></div><p>${escapeHtml(post.text||"")}</p>`;if(isAdmin){const del=makeSmallButton(uiText("Supprimer","Hamafa","Delete"),"ghost",async()=>{await deleteDoc(doc(db,"pages",p.id,"posts",post.id));a.remove();});a.appendChild(del);}root.appendChild(a);});}catch(err){console.warn("[page posts]",err);}
}
const _baseLoadPageDetail=loadPageDetail;
loadPageDetail=async function(){
  const root=$("#page-detail-content");if(!root||!state.activePageId)return;root.innerHTML='<div class="feed-loading">Chargement…</div>';
  try{const ref=doc(db,"pages",state.activePageId),snap=await getDoc(ref);if(!snap.exists()){root.innerHTML='<div class="empty-state"><p>Page introuvable.</p></div>';return;}const p={id:snap.id,...snap.data()};setText("page-detail-title",p.name||"Page");let following=false;if(state.currentUser)following=(await getDoc(doc(db,"pages",p.id,"followers",state.currentUser.uid))).exists();const isAdmin=p.adminIds?.includes(state.currentUser?.uid)||p.ownerId===state.currentUser?.uid;root.innerHTML=`<article class="page-hero"><div class="page-cover" style="${p.coverURL?`background-image:url('${escapeHtml(safeUrl(p.coverURL))}')`:""}"></div><div class="page-main"><div class="page-avatar-large">${avatarMarkup(p.avatarURL,p.name)}</div><h2>${escapeHtml(p.name||"")}</h2><p>${escapeHtml(p.description||"")}</p><p class="muted">${Number(p.followersCount||0)} ${escapeHtml(uiText("abonnés","mpanaraka","followers"))}</p><div class="page-actions">${isAdmin?'<span class="badge">Admin</span>':`<button class="btn btn-primary" id="page-follow-btn">${escapeHtml(following?uiText("Suivi","Araho","Following"):uiText("Suivre","Hanaraka","Follow"))}</button>`}</div></div></article><div id="page-posts" class="feed-list"></div>`;$("#page-follow-btn")?.addEventListener("click",async()=>{const fref=doc(db,"pages",p.id,"followers",state.currentUser.uid);await runTransaction(db,async tx=>{const fs=await tx.get(fref),ps=await tx.get(ref);if(fs.exists()){tx.delete(fref);tx.update(ref,{followersCount:Math.max(0,Number(ps.data()?.followersCount||1)-1),updatedAt:serverTimestamp()});}else{tx.set(fref,{userId:state.currentUser.uid,createdAt:serverTimestamp()});tx.update(ref,{followersCount:Number(ps.data()?.followersCount||0)+1,updatedAt:serverTimestamp()});}});loadPageDetail();});await loadPagePosts(p,isAdmin);}catch(err){logError("[page detail final]",err);}
};

/* ---------- Marketplace saved + related ---------- */
const _baseLoadListingDetail=loadListingDetail;
loadListingDetail=async function(){
  const root=$("#listing-detail-content");if(!root||!state.activeListingId)return;
  try{const snap=await getDoc(doc(db,"marketplaceListings",state.activeListingId));if(!snap.exists()){root.innerHTML='<div class="empty-state"><p>Annonce introuvable.</p></div>';return;}const x={id:snap.id,...snap.data()},photos=x.photos||[];const saveRef=doc(db,"marketplaceListings",x.id,"savedBy",state.currentUser.uid);let saved=(await getDoc(saveRef)).exists();root.innerHTML=`<article class="listing-hero"><div class="listing-gallery">${photos.map((p,i)=>`<img data-listing-photo="${i}" src="${escapeHtml(safeUrl(p.url))}" alt="">`).join("")}</div><div class="listing-main"><h2>${escapeHtml(x.title||"")}</h2><div class="listing-price">${Number(x.price||0).toLocaleString()} Ar</div><p class="muted">${escapeHtml(formatTime(x.createdAt))} · ${escapeHtml(x.location||"")}</p><p>${escapeHtml(x.description||"")}</p><p><strong>${escapeHtml(uiText("État","Toetry","Condition"))}:</strong> ${escapeHtml(x.condition||"")}</p><p><strong>${escapeHtml(uiText("Vendeur","Mpivarotra","Seller"))}:</strong> ${escapeHtml(x.sellerName||"")}</p><p><strong>${escapeHtml(uiText("Contact","Fifandraisana","Contact"))}:</strong> ${escapeHtml(x.contact||"")}</p><p><strong>${escapeHtml(uiText("Remise/livraison","Fanaterana","Delivery"))}:</strong> ${escapeHtml(x.delivery||"")}</p><div class="page-actions"><button class="btn btn-primary" id="listing-contact-btn">${escapeHtml(uiText("Contacter le vendeur","Hifandray amin'ny mpivarotra","Contact seller"))}</button><button class="saved-pill" id="listing-save-btn">${escapeHtml(saved?uiText("Enregistré","Voatahiry","Saved"):uiText("Enregistrer","Hitahiry","Save"))}</button><button class="btn btn-ghost" id="listing-share-btn">${escapeHtml(uiText("Partager","Hizara","Share"))}</button>${x.sellerId===state.currentUser?.uid?`<button class="btn btn-ghost" id="listing-sold-btn">${escapeHtml(x.status==="sold"?uiText("Marquer disponible","Atao misy","Mark available"):uiText("Marquer vendu","Atao lafo","Mark sold"))}</button>`:""}</div></div></article><section class="dashboard-panel"><h3>${escapeHtml(uiText("Produits similaires","Entana mitovitovy","Related products"))}</h3><div id="related-products" class="market-grid"></div></section>`;
    root.querySelectorAll("[data-listing-photo]").forEach(img=>img.addEventListener("click",()=>openMediaViewer(photos.map(p=>({url:p.url,type:"image"})),Number(img.dataset.listingPhoto))));
    $("#listing-save-btn")?.addEventListener("click",async()=>{if(saved){await deleteDoc(saveRef);saved=false;}else{await setDoc(saveRef,{userId:state.currentUser.uid,createdAt:serverTimestamp()});saved=true;}$("#listing-save-btn").textContent=saved?uiText("Enregistré","Voatahiry","Saved"):uiText("Enregistrer","Hitahiry","Save");});
    $("#listing-share-btn")?.addEventListener("click",async()=>{const url=publicAppUrl(`#marketplace=${x.id}`);if(navigator.share)await navigator.share({title:x.title,text:x.description,url});else{await navigator.clipboard.writeText(url);toast(uiText("Lien copié.","Voadika ny rohy.","Link copied."));}});
    $("#listing-contact-btn")?.addEventListener("click",()=>{if(x.sellerId===state.currentUser?.uid){toast(uiText("C'est votre annonce.","Anao ity entana ity.","This is your listing."));return;}openDirectMessageWith(x.sellerId);});
    $("#listing-sold-btn")?.addEventListener("click",async()=>{await updateDoc(doc(db,"marketplaceListings",x.id),{status:x.status==="sold"?"available":"sold",availability:x.status==="sold",updatedAt:serverTimestamp()});loadListingDetail();});
    try{const rs=await getDocs(query(collection(db,"marketplaceListings"),where("category","==",x.category),limit(12)));const rel=$("#related-products");rs.docs.filter(d=>d.id!==x.id).slice(0,6).forEach(d=>{const y={id:d.id,...d.data()};const b=document.createElement("button");b.type="button";b.className="market-card";b.innerHTML=`<div class="cover">${y.photos?.[0]?.url?`<img src="${escapeHtml(safeUrl(y.photos[0].url))}" alt="">`:""}</div><div class="body"><h3>${escapeHtml(y.title||"")}</h3><strong>${Number(y.price||0).toLocaleString()} Ar</strong></div>`;b.addEventListener("click",()=>{state.activeListingId=y.id;loadListingDetail();window.scrollTo(0,0);});rel.appendChild(b);});}catch(_){}
  }catch(err){logError("[listing detail final]",err);}
};

/* ---------- Strict i18n for final modules ---------- */
const FINAL_I18N={
  fr:{groups:"Groupes",mine:"Vos groupes",discover:"Découvrir",top:"Les plus visités",suggestions:"Suggestions",dashboard:"Tableau de bord",pages:"Pages",marketplace:"Marketplace",assistant:"Assistant LYRAME",menu:"Menu",settings:"Paramètres",search:"Rechercher sur LYRAME…",recent:"Récentes",seeall:"Voir tout",createStory:"Créer une story"},
  mg:{groups:"Vondrona",mine:"Ny vondrona misy anao",discover:"Hitady",top:"Be mpitsidika indrindra",suggestions:"Soso-kevitra",dashboard:"Tabilao",pages:"Pejy",marketplace:"Tsena",assistant:"Mpanampy LYRAME",menu:"Menu",settings:"Fikirana",search:"Hikaroka ao amin'ny LYRAME…",recent:"Vao haingana",seeall:"Hijery rehetra",createStory:"Hamorona story"},
  en:{groups:"Groups",mine:"Your groups",discover:"Discover",top:"Most visited",suggestions:"Suggestions",dashboard:"Dashboard",pages:"Pages",marketplace:"Marketplace",assistant:"LYRAME Assistant",menu:"Menu",settings:"Settings",search:"Search LYRAME…",recent:"Recent",seeall:"See all",createStory:"Create a story"}
};
function applyFinalTranslations(){const L=FINAL_I18N[state.lang]||FINAL_I18N.fr;const set=(sel,txt)=>{const el=document.querySelector(sel);if(el)el.textContent=txt;};set('#screen-groups .screen-title',L.groups);set('[data-group-tab="mine"]',L.mine);set('[data-group-tab="discover"]',L.discover);set('[data-group-tab="top"]',L.top);set('#screen-suggestions .screen-title',L.suggestions);set('#screen-dashboard .screen-title',L.dashboard);set('#screen-pages .screen-title',L.pages);set('#screen-marketplace .screen-title',L.marketplace);set('#screen-assistant .screen-title','RYLAME');set('#assistant-image-label',uiText('Photo','Sary','Image'));assistantUpdateStaticLabels();assistantRenderChatList();set('#screen-menu .screen-title',L.menu);lyrV965TranslateMenu();const h=$("#header-search-input");if(h)h.placeholder=L.search;const q=$("#search-input");if(q)q.placeholder=L.search;set('#search-recents-section h3',L.recent);set('#search-clear-recents',L.seeall);set('[data-i18n-dynamic="create-story"]',L.createStory);document.querySelectorAll('.nav-btn[data-nav="settings"] span').forEach(x=>x.textContent=L.settings);document.querySelectorAll('.nav-btn[data-nav="menu"] span').forEach(x=>x.textContent=L.menu);const chatOptions=$("#conv-info-btn");if(chatOptions){const label=uiText("Options de la discussion","Safidin’ny resaka","Conversation options");chatOptions.title=label;chatOptions.setAttribute("aria-label",label);}}

/* LYRAME V96.4 — textes propres à l'habillage des paramètres. Sans appel réseau. */
const LYR_V964_TEXT = {
  fr: {heroTitle:"Vos réglages, à votre image",heroText:"Compte, confidentialité et application réunis au même endroit.",footer:"LYRAME · Les mots qui viennent du cœur."},
  mg: {heroTitle:"Ny fikiranao, araka izay tianao",heroText:"Kaonty, tsiambaratelo ary fikirana rehetra eto amin’ny toerana iray.",footer:"LYRAME · Ireo teny avy ao am-po."},
  en: {heroTitle:"Settings that feel like yours",heroText:"Account, privacy and app preferences in one place.",footer:"LYRAME · Words from the heart."}
};
/* Entrée fondateur : traductions UI, sans nouveau service d'automatisation. */
const LYR_V969_TEXT = {
  fr: { ownerTitle:"Espace propriétaire", ownerDesc:"Réglages réservés au compte fondateur", ownerEntryDesc:"Gestion des fonctionnalités, comptes et offres", ownerVerify:"Validez votre adresse e-mail pour accéder à l'administration." },
  mg: { ownerTitle:"Sehatry ny tompony", ownerDesc:"Fikirana natokana ho an'ny kaonty mpanorina", ownerEntryDesc:"Fitantanana ny fonctionnalités, kaonty ary tolotra", ownerVerify:"Hamarino aloha ny adiresy mailaka vao mahazo miditra amin'ny fitantanana." },
  en: { ownerTitle:"Owner space", ownerDesc:"Settings reserved for the founder account", ownerEntryDesc:"Manage features, accounts and plans", ownerVerify:"Verify your email address to access administration." }
};
function lyrV969TranslateOwnerSettings() {
  const lex = LYR_V969_TEXT[state.lang] || LYR_V969_TEXT.fr;
  document.querySelectorAll('#screen-settings [data-lyr-v969]').forEach(el => {
    if (lex[el.dataset.lyrV969]) el.textContent = lex[el.dataset.lyrV969];
  });
}
function lyrV964TranslateSettings(){
  const lex = LYR_V964_TEXT[state.lang] || LYR_V964_TEXT.fr;
  lyrV969TranslateOwnerSettings();
  document.querySelectorAll('#screen-settings [data-lyr-v964]').forEach(el=>{
    const value=lex[el.dataset.lyrV964]; if(value) el.textContent=value;
  });
}

const _baseApplyTranslations=applyTranslations;
applyTranslations=function(){_baseApplyTranslations();applyFinalTranslations();lyrV964TranslateSettings();};

/* extend screen loader and final event bindings */
const _showScreenV2=showScreen;
showScreen=function(name,opts={}){_showScreenV2(name,opts);if(name==="groups")loadGroupsDiscovery();};
document.addEventListener("DOMContentLoaded",()=>window.setTimeout(()=>{
  applyFinalTranslations();
  $("#groups-create-open")?.addEventListener("click",()=>showScreen("create-group"));
  $("#groups-search")?.addEventListener("input",loadGroupsDiscovery);
  document.querySelectorAll("[data-group-tab]").forEach(b=>b.addEventListener("click",()=>{state.groupDiscoveryTab=b.dataset.groupTab;document.querySelectorAll("[data-group-tab]").forEach(x=>x.classList.toggle("active",x===b));loadGroupsDiscovery();}));
  const seeAll=$("#search-clear-recents"); if(seeAll){const clone=seeAll.cloneNode(true);seeAll.replaceWith(clone);clone.addEventListener("click",()=>{const box=$("#search-recents");if(!box)return;box.innerHTML="";state.recentSearches.forEach(r=>{const row=document.createElement("div");row.className="search-recent-row";row.innerHTML=`<span class="grow"><strong>${escapeHtml(r.label||"")}</strong><small>${escapeHtml(r.type||"")}</small></span><button class="icon-btn sm" type="button" aria-label="Retirer">×</button>`;row.addEventListener("click",e=>{if(e.target.closest("button")){state.recentSearches=state.recentSearches.filter(x=>x!==r);persistSearchRecentsCloud();row.remove();return;}openSearchEntity(r);});box.appendChild(row);});});}
},20),{once:true});

/* ---------- Message search + request/privacy ---------- */
async function canMessageUser(targetUid){
  if(!state.currentUser||!targetUid||targetUid===state.currentUser.uid)return {ok:false,reason:"self"};
  const [target,friend]=await Promise.all([getUserProfile(targetUid),areFriends(state.currentUser.uid,targetUid)]);
  const mine=state.currentProfile||{};
  if(target?.blockedUsers?.includes(state.currentUser.uid)||mine?.blockedUsers?.includes(targetUid))return {ok:false,reason:"blocked"};
  const privacy=target?.messagePrivacy||"everyone";
  if(privacy==="nobody")return {ok:false,reason:"nobody"};
  if(privacy==="friends"&&!friend)return {ok:false,reason:"friends"};
  return {ok:true,request:!friend&&privacy==="everyone",target};
}
const _baseGetOrCreateDirectConversation=getOrCreateDirectConversation;
getOrCreateDirectConversation=async function(otherUid){
  if(!state.currentUser||!otherUid||otherUid===state.currentUser.uid)return null;
  const check=await canMessageUser(otherUid);
  if(!check.ok){toast(check.reason==="friends"?uiText("Cette personne accepte uniquement les messages de ses amis.","Namana ihany no azon'ity olona ity mandefa hafatra.","This person only accepts messages from friends."):check.reason==="blocked"?uiText("La messagerie n'est pas disponible pour ce compte.","Tsy azo ampiasaina amin'ity kaonty ity ny hafatra.","Messaging is unavailable for this account."):uiText("Cette personne n'accepte pas de messages.","Tsy mandray hafatra ity olona ity.","This person doesn't accept messages."));return null;}

  const myUid=state.currentUser.uid;
  const pairKey=pairKeyOf(myUid,otherUid);
  const deterministicRef=doc(db,"conversations",pairKey);

  // 1) Chemin moderne : accès direct au document déterministe.
  // Cela respecte les rules et évite la requête interdite `where(pairKey == ...)`.
  const directSnap=await getDoc(deterministicRef);
  if(directSnap.exists()){
    const data=directSnap.data()||{};
    const members=Array.isArray(data.memberIds)?data.memberIds:[];
    if(members.includes(myUid)&&members.includes(otherUid))return deterministicRef.id;
    const err=new Error("DIRECT_CONVERSATION_MEMBERS_MISMATCH");
    err.code="lyrame/direct-members-mismatch";
    throw err;
  }

  // 2) Compatibilité avec les anciennes conversations à ID aléatoire.
  // On requête UNIQUEMENT les conversations dont l'utilisateur courant est membre;
  // ce prédicat correspond aux Firestore Rules, puis on filtre le second membre côté client.
  try{
    const mine=await getDocs(query(collection(db,"conversations"),where("memberIds","array-contains",myUid),limit(200)));
    const legacy=mine.docs.find(d=>{
      const c=d.data()||{};
      const members=Array.isArray(c.memberIds)?c.memberIds:[];
      return (c.type==="direct"||c.isGroup===false) && members.includes(otherUid);
    });
    if(legacy)return legacy.id;
  }catch(err){
    console.warn("[legacy direct lookup]",err);
  }

  // 3) Création uniquement si aucune conversation directe n'existe.
  await setDoc(deterministicRef,{
    type:"direct",
    isGroup:false,
    pairKey,
    memberIds:[myUid,otherUid],
    createdBy:myUid,
    requestedBy:check.request?myUid:"",
    requestStatus:check.request?"pending":"accepted",
    createdAt:serverTimestamp(),
    updatedAt:serverTimestamp(),
    lastMessage:"",
    lastMessageAt:serverTimestamp()
  });
  return deterministicRef.id;
};
function updateMessageRequestBanner(c){
  const banner=$("#message-request-banner"),form=$("#conv-form");if(!banner)return;
  const me=state.currentUser?.uid;const pending=c?.requestStatus==="pending";const recipient=pending&&c.requestedBy&&c.requestedBy!==me;
  if(recipient){showEl(banner);setText("message-request-title",uiText("Demande de message","Fangatahana hafatra","Message request"));setText("message-request-text",uiText("Acceptez pour continuer la conversation.","Ekeo vao tohizana ny resaka.","Accept to continue the conversation."));if(form)form.classList.add("hidden");}
  else{hideEl(banner);if(form)form.classList.remove("hidden");}
}
const _baseStartConversationDocListener=startConversationDocListener;
startConversationDocListener=function(convId){
  _baseStartConversationDocListener(convId);
  const extra=onSnapshot(doc(db,"conversations",convId),snap=>{if(state.activeConvId!==convId||!snap.exists())return;updateMessageRequestBanner({id:snap.id,...snap.data()});},()=>{});
  const prev=listeners.conversationRequest;listeners.conversationRequest=()=>{try{extra();}catch(_){};try{prev?.();}catch(_){}};
};
async function acceptMessageRequest(){if(!state.currentUser||!state.activeConvId||!state.activeConv)return;if(state.activeConv.requestedBy===state.currentUser.uid)return;await updateDoc(doc(db,"conversations",state.activeConvId),{requestStatus:"accepted",requestRespondedAt:serverTimestamp(),updatedAt:serverTimestamp()});toast(uiText("Demande acceptée.","Nekena ny fangatahana.","Request accepted."));}
async function declineMessageRequest(){if(!state.currentUser||!state.activeConvId||!state.activeConv)return;if(state.activeConv.requestedBy===state.currentUser.uid)return;await updateDoc(doc(db,"conversations",state.activeConvId),{requestStatus:"rejected",requestRespondedAt:serverTimestamp(),updatedAt:serverTimestamp()});toast(uiText("Demande refusée.","Nolavina ny fangatahana.","Request declined."));showScreen("messages");}
let messageSearchTimer=null;
async function runMessageSearch(term){const box=$("#messages-search-results");if(!box)return;term=String(term||"").trim().toLowerCase();box.innerHTML="";if(term.length<2){hideEl(box);return;}showEl(box);try{const [us,ps,gs]=await Promise.all([getDocs(query(collection(db,"users"),limit(80))),getDocs(query(collection(db,"pages"),limit(50))).catch(()=>null),getDocs(query(collection(db,"conversations"),where("privacy","==","public"),limit(80))).catch(()=>null)]);const add=(docs,type)=>{(docs||[]).map(d=>({id:d.id,...d.data()})).filter(x=>{const label=x.fullname||x.username||x.name||x.title||"";return label.toLowerCase().includes(term)&&!(type==="user"&&x.id===state.currentUser?.uid);}).slice(0,8).forEach(x=>{const label=x.fullname||x.name||x.title||x.username||uiSomeone();const b=document.createElement("button");b.type="button";b.className="search-result-row";b.innerHTML=`<span class="avatar">${avatarMarkup(x.photoURL||x.avatarURL||x.coverURL||"",label)}</span><span class="grow"><strong>${escapeHtml(label)}${type==="user"?identityBadgeMarkup(x):""}</strong><small>${escapeHtml(type)}</small></span>`;b.addEventListener("click",()=>{hideEl(box);if(type==="user")openDirectMessageWith(x.id);else if(type==="page"){state.activePageId=x.id;showScreen("page-detail");}else openGroupDiscoveryItem(x.id);});box.appendChild(b);});};add(us.docs,"user");add(ps?.docs||[],"page");add(gs?.docs?.filter(d=>d.data().type==="group"||d.data().isGroup),"group");if(!box.children.length)box.innerHTML=`<p class="muted small">${escapeHtml(uiText("Aucun résultat","Tsy misy valiny","No results"))}</p>`;}catch(err){console.warn("[messages search]",err);}}
document.addEventListener("DOMContentLoaded",()=>window.setTimeout(()=>{
  $("#message-request-accept")?.addEventListener("click",acceptMessageRequest);
  $("#message-request-decline")?.addEventListener("click",declineMessageRequest);
  $("#messages-search")?.addEventListener("input",e=>{
    lyrameMessagesFilterConversations();
    clearTimeout(messageSearchTimer);
    messageSearchTimer=setTimeout(()=>runMessageSearch(e.target.value),240);
  });
},30),{once:true});

/* ---------- Saved posts / follow in post header / reporting ---------- */
async function toggleFollowUid(targetUid,btn){
  if(!state.currentUser||!targetUid||targetUid===state.currentUser.uid)return;
  if(btn?.disabled)return;
  if(btn)setBusy(btn,true,"...");
  try{
    const current=(await getDoc(doc(db,"users",state.currentUser.uid,"following",targetUid))).exists();
    const now=await applyFollowState(targetUid,!current);
    if(btn)btn.textContent=now?uiText("Suivi","Manaraka","Following"):uiText("Suivre","Hanaraka","Follow");
    toast(now?t("msg_followed"):t("msg_unfollowed"));
    if(now){
      createNotification({id:`follow_${state.currentUser.uid}_${targetUid}`,userId:targetUid,actorId:state.currentUser.uid,type:"follow",title:uiText("Nouvel abonné","Mpanaraka vaovao","New follower"),preview:`${state.currentProfile?.fullname||uiSomeone()} ${uiText("vous suit maintenant.","manaraka anao izao.","is now following you.")}`}).catch(err=>console.warn("[post follow notification]",err));
    }
  }catch(err){
    logError("[post follow]",err);
    toast(followErrorMessage(err));
  }finally{if(btn)setBusy(btn,false);}
}
async function isPostSaved(postId){if(!state.currentUser)return false;return (await getDoc(doc(db,"users",state.currentUser.uid,"savedPosts",postId))).exists();}
async function toggleSavePost(post,btn){if(!state.currentUser||!post?.id)return;const ref=doc(db,"users",state.currentUser.uid,"savedPosts",post.id);const s=await getDoc(ref);if(s.exists()){await deleteDoc(ref);if(btn)btn.textContent=uiText("Enregistrer","Hitahiry","Save");toast(uiText("Retiré des enregistrements.","Nesorina tamin'ny tahiry.","Removed from saved."));}else{await setDoc(ref,{postId:post.id,authorId:post.authorId,savedAt:serverTimestamp()});if(btn)btn.textContent=uiText("Enregistré","Voatahiry","Saved");toast(uiText("Publication enregistrée.","Voatahiry ny publication.","Post saved."));}}
async function reportPost(post){if(!state.currentUser||!post?.id)return;const modal=openDynamicModal(uiText("Signaler la publication","Hitatitra publication","Report post"));const reason=styledInput("text",uiText("Motif du signalement","Antony itaterana","Reason for report"));const send=styledButton(uiText("Envoyer","Handefa","Send"),"danger");send.addEventListener("click",async()=>{const text=reason.value.trim();if(!text)return;await addDoc(collection(db,"contentReports"),{targetType:"post",targetId:post.id,targetOwnerId:post.authorId,reporterUid:state.currentUser.uid,reason:text,status:"open",createdAt:serverTimestamp()});modal.close();toast(uiText("Signalement envoyé.","Nalefa ny tatitra.","Report sent."));});modal.body.append(reason,send);}
async function loadSavedPosts(){const root=$("#saved-posts-list");if(!root||!state.currentUser)return;root.innerHTML='<div class="feed-loading">Chargement…</div>';try{const snap=await getDocs(query(collection(db,"users",state.currentUser.uid,"savedPosts"),orderBy("savedAt","desc"),limit(100)));root.innerHTML="";for(const d of snap.docs){const ps=await getDoc(doc(db,"posts",d.id));if(ps.exists())root.appendChild(renderPostCard({id:ps.id,...ps.data()}));}if(!root.children.length)root.innerHTML=`<div class="empty-state"><p class="empty-title">${escapeHtml(uiText("Aucune publication enregistrée.","Tsy misy publication voatahiry.","No saved posts."))}</p></div>`;}catch(err){logError("[saved posts]",err);}}
const _renderPostCardV2=renderPostCard;
renderPostCard=function(post){
  const card=_renderPostCardV2(post); const isOwner=post.authorId===state.currentUser?.uid; const head=card.querySelector(".post-head"); if(!head)return card;
  if(!isOwner){
    const actions=document.createElement("div");actions.className="post-head-actions";
    const follow=document.createElement("button");follow.type="button";follow.className="post-follow-btn";follow.textContent=uiText("Suivre","Hanaraka","Follow");getDoc(doc(db,"users",state.currentUser.uid,"following",post.authorId)).then(s=>{if(s.exists())follow.textContent=uiText("Suivi","Manaraka","Following");}).catch(()=>{});follow.addEventListener("click",e=>{e.stopPropagation();toggleFollowUid(post.authorId,follow);});
    const menuWrap=document.createElement("div");menuWrap.className="post-other-menu";const dots=document.createElement("button");dots.type="button";dots.className="icon-btn sm";dots.setAttribute("aria-label","Options");dots.innerHTML='<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="5" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="12" cy="19" r="1.5"/></svg>';const menu=document.createElement("div");menu.className="owner-menu hidden";const save=document.createElement("button");save.type="button";save.textContent=uiText("Enregistrer","Hitahiry","Save");isPostSaved(post.id).then(v=>{if(v)save.textContent=uiText("Enregistré","Voatahiry","Saved");}).catch(()=>{});save.addEventListener("click",e=>{e.stopPropagation();toggleSavePost(post,save);menu.classList.add("hidden");});const not=document.createElement("button");not.type="button";not.textContent=uiText("Ça ne m'intéresse pas","Tsy mahaliana ahy","Not interested");not.addEventListener("click",()=>card.remove());const report=document.createElement("button");report.type="button";report.textContent=uiText("Signaler","Hitatitra","Report");report.addEventListener("click",()=>{menu.classList.add("hidden");reportPost(post);});menu.append(save,not,report);dots.addEventListener("click",e=>{e.stopPropagation();menu.classList.toggle("hidden");});menuWrap.append(dots,menu);
    const hide=document.createElement("button");hide.type="button";hide.className="post-hide-btn";hide.setAttribute("aria-label",uiText("Masquer","Afeno","Hide"));hide.textContent="×";hide.addEventListener("click",()=>card.remove());actions.append(follow,menuWrap,hide);head.appendChild(actions);
  }
  const headPress=()=>{let timer=null;head.addEventListener("pointerdown",e=>{if(e.target.closest("button"))return;timer=setTimeout(async()=>{const text=[post.authorName,post.title,post.text].filter(Boolean).join("\n");try{await navigator.clipboard.writeText(text);toast(uiText("Texte copié.","Voadika ny lahatsoratra.","Text copied."));}catch(_){}},650);});["pointerup","pointerleave","pointercancel"].forEach(ev=>head.addEventListener(ev,()=>clearTimeout(timer)));};headPress();return card;
};
const _showScreenV3=showScreen;
showScreen=function(name,opts={}){_showScreenV3(name,opts);if(name==="saved-posts")loadSavedPosts();if(name==="home")loadStories();};
document.addEventListener("DOMContentLoaded",()=>window.setTimeout(()=>{document.querySelector('[data-menu-action="invite"]')?.addEventListener("click",async()=>{const url=publicAppUrl("");const data={title:"LYRAME",text:uiText("Rejoignez-moi sur LYRAME.","Andao hiaraka ao amin'ny LYRAME.","Join me on LYRAME."),url};if(navigator.share)await navigator.share(data).catch(()=>{});else{await navigator.clipboard.writeText(url);toast(uiText("Lien copié.","Voadika ny rohy.","Link copied."));}});},40),{once:true});

/* ============================================================
   LYRAME — MESSAGERIE POLIE + NAVIGATION AUTO (2026-10-09)
   - UI bulles proche Assistant LYRAME
   - actions uniquement par appui long
   - bottom sheet actions/suppression
   - présence réelle isOnline + lastSeen, point grenat
   - indicateur de saisie dans le flux + son optionnel
   - reçu vu/non-vu uniquement sur le dernier message sortant
   - date/heure centrée par message
   - auto-scroll haut/bas avec vitesse + stop
   ============================================================ */

state.messageUiSettings = {
  scrollSpeed: "normal",
  typingSound: true,
  scrollControlsVisible: false,
  sendTypingIndicator: true,
  sendReadReceipts: true,
  messageNotificationsEnabled: true,
  messageNotificationSound: "lyrame",
  ...(state.currentProfile?.messageUi || {})
};
state.conversationAutoScroll = { timer: 0, direction: 0 };
state.conversationTypingSoundTimer = null;
state.conversationAudioContext = null;
state.conversationTypingVisible = false;
state.conversationMessagesLoadedFor = "";
state.suppressTypingUntil = 0;

function isProfileActuallyOnline(profile) {
  if (!profile || profile.showOnlineStatus === false || profile.isOnline !== true) return false;
  const last = toDate(profile.lastSeen);
  return !!last && (Date.now() - last.getTime()) < ONLINE_FRESH_MS;
}

function formatConversationPresence(profile) {
  if (!profile || profile.showOnlineStatus === false) return { text: "", online: false };
  if (isProfileActuallyOnline(profile)) return { text: t("online"), online: true };
  const last = toDate(profile.lastSeen);
  if (!last) return { text: "", online: false };
  const diffSec = Math.max(0, (Date.now() - last.getTime()) / 1000);
  if (diffSec < 3600) return { text: `il y a ${Math.max(1, Math.floor(diffSec / 60))} min`, online: false };
  if (diffSec < 86400) return { text: `il y a ${Math.floor(diffSec / 3600)} h`, online: false };
  const yesterday = new Date(); yesterday.setDate(yesterday.getDate() - 1);
  if (last.toDateString() === yesterday.toDateString()) return { text: t("yesterday"), online: false };
  return { text: last.toLocaleDateString(), online: false };
}

listenConversationPresence = function(uid) {
  if (listeners.presence) { listeners.presence(); listeners.presence = null; }
  if (listeners.presenceRefresh) { clearInterval(listeners.presenceRefresh); listeners.presenceRefresh = null; }
  const el = $("#conv-presence");
  if (el) { el.textContent = ""; el.classList.remove("online"); }
  if (!uid) return;
  let latest = null;
  const paint = () => {
    if (!el || !latest) return;
    const p = formatConversationPresence(latest);
    el.textContent = p.text;
    el.classList.toggle("online", p.online);
  };
  listeners.presence = onSnapshot(doc(db, "users", uid), snap => {
    latest = snap.exists() ? snap.data() : null;
    paint();
  }, err => console.warn("[conv presence]", err));
  listeners.presenceRefresh = setInterval(paint, 30000);
};

function formatMessageStamp(value) {
  const d = toDate(value);
  if (!d) return uiText("Envoi…", "Alefa…", "Sending…");
  const now = new Date();
  const time = d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  if (d.toDateString() === now.toDateString()) return time;
  const y = new Date(now); y.setDate(y.getDate() - 1);
  if (d.toDateString() === y.toDateString()) return `${uiText("Hier", "Omaly", "Yesterday")} · ${time}`;
  return `${d.toLocaleDateString()} · ${time}`;
}

function receiptSvg(seen) {
  if (seen) {
    return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12Z"/><circle cx="12" cy="12" r="2.5"/></svg>`;
  }
  return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M3 3l18 18" class="receipt-slash"/><path d="M10.6 6.1A11 11 0 0 1 12 6c6.5 0 10 6 10 6a16.5 16.5 0 0 1-3.1 3.7M6.3 6.3C3.6 8.1 2 12 2 12s3.5 6 10 6a10.7 10.7 0 0 0 3-.4"/></svg>`;
}

function refreshConversationVisualState() {
  const box = $("#conv-messages");
  if (!box) return;
  box.querySelectorAll(".message-opposite-receipt").forEach(n => n.remove());
  const rows = Array.from(box.querySelectorAll(".msg[data-sender-id]"));
  const latest = rows.at(-1);
  if (!latest || latest.dataset.senderId !== state.currentUser?.uid) return;
  const seen = latest.dataset.receipt === "seen";
  const r = document.createElement("span");
  r.className = `message-opposite-receipt ${seen ? "seen" : "unseen"}`;
  r.innerHTML = receiptSvg(seen);
  const label = seen
    ? uiText("Vu", "Hita", "Seen")
    : uiText("Pas encore vu", "Mbola tsy hita", "Not seen yet");
  r.setAttribute("aria-label", label); r.title = label;
  latest.appendChild(r);
}

const _messageUxRenderBase = renderMessage;
renderMessage = function(m) {
  const el = _messageUxRenderBase(m);
  const me = state.currentUser?.uid || "";
  const isMe = m.senderId === me;
  el.dataset.senderId = m.senderId || "";
  el.querySelector(".message-actions")?.remove();
  const stamp = el.querySelector(".message-status span:first-child, .msg-status span:first-child");
  if (stamp) {
    stamp.textContent = formatMessageStamp(m.createdAt);
    const d = toDate(m.createdAt); if (d) stamp.title = d.toLocaleString();
  }
  if (isMe) {
    const members = Array.isArray(state.activeConv?.memberIds) ? state.activeConv.memberIds : [];
    const others = members.filter(uid => uid !== me);
    const readBy = Array.isArray(m.readBy) ? m.readBy : [];
    const seen = others.length > 0 && others.every(uid => readBy.includes(uid));
    el.dataset.receipt = seen ? "seen" : "unseen";
  }
  return el;
};

function closeLyrMessageSheet() {
  document.querySelector(".lyr-sheet-backdrop")?.remove();
}

function makeSheetAction(label, icon, onClick, danger = false) {
  const b = document.createElement("button");
  b.type = "button";
  b.className = `lyr-message-action-row${danger ? " danger" : ""}`;
  b.innerHTML = `<span class="lyr-message-action-icon" aria-hidden="true">${icon}</span><span>${escapeHtml(label)}</span>`;
  b.addEventListener("click", () => { closeLyrMessageSheet(); onClick(); });
  return b;
}

function openLyrMessageSheet(title = "") {
  closeLyrMessageSheet();
  const backdrop = document.createElement("div");
  backdrop.className = "lyr-sheet-backdrop";
  const sheet = document.createElement("section");
  sheet.className = "lyr-message-sheet";
  sheet.setAttribute("role", "dialog");
  sheet.setAttribute("aria-modal", "true");
  sheet.innerHTML = `<div class="lyr-sheet-handle"></div>${title ? `<p class="lyr-sheet-title">${escapeHtml(title)}</p>` : ""}`;
  backdrop.appendChild(sheet);
  backdrop.addEventListener("click", e => { if (e.target === backdrop) closeLyrMessageSheet(); });
  document.body.appendChild(backdrop);
  return sheet;
}

openMessageDeleteActions = function(message) {
  if (!message) return;
  const sheet = openLyrMessageSheet(uiText("Supprimer le message", "Hamafa hafatra", "Delete message"));
  const p = document.createElement("p"); p.className = "lyr-delete-explain";
  p.textContent = uiText("Choisissez où supprimer ce message.", "Safidio hoe aiza no hamafana ity hafatra ity.", "Choose where to delete this message.");
  sheet.appendChild(p);
  sheet.appendChild(makeSheetAction(uiText("Supprimer pour moi", "Hamafa ho ahy", "Delete for me"), "🗑", async () => {
    try { await deleteMessageForMe(message); } catch (err) { logError("[delete message me]", err); toast(t("err_generic")); }
  }, true));
  if (message.senderId === state.currentUser?.uid) {
    sheet.appendChild(makeSheetAction(uiText("Supprimer pour tout le monde", "Hamafa ho an’ny rehetra", "Delete for everyone"), "⚠", async () => {
      const ok = await showConfirm({
        title: uiText("Supprimer le message", "Hamafa hafatra", "Delete message"),
        message: uiText("Supprimer ce message pour tout le monde ?", "Hofafana ho an’ny rehetra ve ity hafatra ity?", "Delete this message for everyone?"),
        confirmText: t("delete"), danger: true
      });
      if (!ok) return;
      try { await deleteMessageForEveryone(message); } catch (err) { logError("[delete message all]", err); toast(t("err_generic")); }
    }, true));
  }
  sheet.appendChild(makeSheetAction(uiText("Annuler", "Ajanony", "Cancel"), "✕", () => {}));
};

openMessageActionSheet = function(message) {
  if (!message) return;
  try { navigator.vibrate?.(18); } catch (_) {}
  const sheet = openLyrMessageSheet(uiText("Message", "Hafatra", "Message"));
  const reactions = document.createElement("div"); reactions.className = "lyr-message-reactions";
  ["❤️","😆","😮","😢","😠","👍"].forEach(emoji => {
    const b = document.createElement("button"); b.type = "button"; b.textContent = emoji;
    b.addEventListener("click", async () => { closeLyrMessageSheet(); await setMessageReaction(message, emoji); });
    reactions.appendChild(b);
  });
  sheet.appendChild(reactions);
  if (message.text) {
    sheet.appendChild(makeSheetAction(uiText("Copier", "Handika", "Copy"), "▣", async () => {
      try { await navigator.clipboard.writeText(message.text); toast(uiText("Texte copié.", "Voadika ny lahatsoratra.", "Text copied.")); } catch (_) {}
    }));

  }
  sheet.appendChild(makeSheetAction(uiText("Transférer", "Handefa indray", "Forward"), "➤", () => forwardMessage(message)));
  sheet.appendChild(makeSheetAction(uiText("Répondre", "Hamaly", "Reply"), "↩", () => { setMessageReply(message); $("#conv-text")?.focus(); }));
  sheet.appendChild(makeSheetAction(uiText("Supprimer", "Hamafa", "Delete"), "🗑", () => openMessageDeleteActions(message), true));
};

function ensureConversationAudioContext() {
  if (state.conversationAudioContext) {
    if (state.conversationAudioContext.state === "suspended") state.conversationAudioContext.resume().catch(() => {});
    return state.conversationAudioContext;
  }
  const Ctx = window.AudioContext || window.webkitAudioContext;
  if (!Ctx) return null;
  try { state.conversationAudioContext = new Ctx(); } catch (_) { return null; }
  return state.conversationAudioContext;
}

document.addEventListener("pointerdown", ensureConversationAudioContext, { once: true, passive: true });

function playMessageNotificationSound(kind = "lyrame", force = false) {
  if (!force && state.messageUiSettings?.messageNotificationsEnabled === false) return;
  const sound = String(kind || state.messageUiSettings?.messageNotificationSound || "lyrame");
  if (sound === "silent") return;
  const ctx = ensureConversationAudioContext();
  if (!ctx || ctx.state !== "running") return;
  const patterns = {
    lyrame: [[660,0,.07],[880,.09,.09],[1040,.19,.10]],
    soft: [[520,0,.10],[620,.12,.12]],
    crystal: [[980,0,.06],[1320,.08,.08],[1560,.17,.10]],
    pulse: [[440,0,.055],[440,.10,.055],[740,.20,.08]],
    bell: [[784,0,.16],[1176,.06,.22]]
  };
  const notes = patterns[sound] || patterns.lyrame;
  const start = ctx.currentTime + 0.01;
  notes.forEach(([freq, delay, duration], index) => {
    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = sound === "bell" || sound === "crystal" ? "sine" : (sound === "pulse" ? "square" : "triangle");
      osc.frequency.setValueAtTime(freq, start + delay);
      gain.gain.setValueAtTime(0.0001, start + delay);
      gain.gain.exponentialRampToValueAtTime(index === 0 ? 0.055 : 0.04, start + delay + 0.012);
      gain.gain.exponentialRampToValueAtTime(0.0001, start + delay + duration);
      osc.connect(gain); gain.connect(ctx.destination);
      osc.start(start + delay); osc.stop(start + delay + duration + 0.02);
    } catch (_) {}
  });
}

function playTypingTick() {
  if (state.messageUiSettings?.typingSound === false || document.visibilityState !== "visible") return;
  const ctx = ensureConversationAudioContext(); if (!ctx || ctx.state !== "running") return;
  try {
    const osc = ctx.createOscillator(); const gain = ctx.createGain();
    osc.type = "sine"; osc.frequency.value = 650 + Math.random() * 90;
    gain.gain.setValueAtTime(0.0001, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.018, ctx.currentTime + 0.006);
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.045);
    osc.connect(gain); gain.connect(ctx.destination); osc.start(); osc.stop(ctx.currentTime + 0.05);
  } catch (_) {}
}

function stopConversationTypingSound() {
  clearInterval(state.conversationTypingSoundTimer);
  state.conversationTypingSoundTimer = null;
}

function startConversationTypingSound() {
  if (state.messageUiSettings?.typingSound === false || state.conversationTypingSoundTimer) return;
  playTypingTick();
  state.conversationTypingSoundTimer = setInterval(playTypingTick, 480);
}

function renderConversationTypingLane(typing) {
  const box = $("#conv-messages"); if (!box) return;
  box.querySelector(".conv-typing-lane")?.remove();
  const visible = !!typing && Date.now() >= Number(state.suppressTypingUntil || 0);
  state.conversationTypingVisible = visible;
  if (!visible) { stopConversationTypingSound(); return; }
  const lane = document.createElement("div"); lane.className = "conv-typing-lane";
  lane.setAttribute("aria-label", uiText("Écrit…", "Manoratra…", "Typing…"));
  lane.innerHTML = "<span></span><span></span><span></span>";
  box.appendChild(lane);
  startConversationTypingSound();
  if (isConversationNearBottom(box, 110)) box.scrollTop = box.scrollHeight;
}

const _messageUxStartConversationDoc = startConversationDocListener;
startConversationDocListener = function(convId) {
  _messageUxStartConversationDoc(convId);
  if (listeners.conversationUx) { listeners.conversationUx(); listeners.conversationUx = null; }
  listeners.conversationUx = onSnapshot(doc(db, "conversations", convId), snap => {
    if (state.activeConvId !== convId || !snap.exists()) return;
    const c = { id: snap.id, ...snap.data() };
    renderConversationTypingLane(typingDataFromConversation(c));
  }, () => {});
};

function getConversationScroller() {
  const box = $("#conv-messages");
  if (box && box.scrollHeight > box.clientHeight + 4) return box;
  const screen = $("#screen-conversation");
  if (screen && screen.scrollHeight > screen.clientHeight + 4) return screen;
  const root = document.scrollingElement || document.documentElement;
  return root || box || screen;
}

function isConversationNearBottom(box = getConversationScroller(), threshold = 80) {
  if (!box) return true;
  return (box.scrollHeight - box.scrollTop - box.clientHeight) <= threshold;
}

function updateConversationScrollControls() {
  const box = getConversationScroller(); if (!box) return;
  const up = $("#conv-auto-up"), down = $("#conv-auto-down");
  const atTop = box.scrollTop <= 2;
  const atBottom = box.scrollTop + box.clientHeight >= box.scrollHeight - 2;
  if (up) { up.disabled = false; up.setAttribute("aria-disabled", atTop ? "true" : "false"); up.classList.toggle("is-boundary", atTop); }
  if (down) { down.disabled = false; down.setAttribute("aria-disabled", atBottom ? "true" : "false"); down.classList.toggle("is-boundary", atBottom); }
}

function stopConversationAutoScroll() {
  const a = state.conversationAutoScroll || {};
  if (a.timer) clearInterval(a.timer);
  state.conversationAutoScroll = { timer: 0, direction: 0 };
  $("#conv-auto-up")?.classList.remove("is-active");
  $("#conv-auto-down")?.classList.remove("is-active");
}

function conversationScrollPixelsPerTick() {
  return { slow: 4, normal: 9, fast: 17 }[state.messageUiSettings?.scrollSpeed] || 9;
}

function startConversationAutoScroll(direction) {
  const box = getConversationScroller();
  if (!box || !direction) return;
  stopConversationAutoScroll();
  const dir = direction < 0 ? -1 : 1;
  state.conversationAutoScroll.direction = dir;
  (dir < 0 ? $("#conv-auto-up") : $("#conv-auto-down"))?.classList.add("is-active");

  const tick = () => {
    const current = getConversationScroller();
    if (!current || !state.conversationAutoScroll?.direction) {
      stopConversationAutoScroll();
      return;
    }
    const before = current.scrollTop;
    const delta = state.conversationAutoScroll.direction * conversationScrollPixelsPerTick();
    try {
      current.scrollBy({ top: delta, left: 0, behavior: "auto" });
    } catch (_) {
      try { current.scrollTop = before + delta; } catch (_) {}
    }
    if (Math.abs(current.scrollTop - before) < 0.5) {
      try { current.scrollTop = before + delta; } catch (_) {}
    }
    updateConversationScrollControls();
    const hitTop = current.scrollTop <= 1;
    const hitBottom = current.scrollTop + current.clientHeight >= current.scrollHeight - 1;
    if ((dir < 0 && hitTop) || (dir > 0 && hitBottom)) stopConversationAutoScroll();
  };

  tick();
  state.conversationAutoScroll.timer = setInterval(tick, 28);
}

function setConversationScrollControlsVisible(visible, { persist = true } = {}) {
  const panel = $("#conv-scroll-controls");
  const toggle = $("#conv-scroll-toggle");
  const next = !!visible;
  state.messageUiSettings.scrollControlsVisible = next;
  panel?.classList.toggle("is-hidden", !next);
  panel?.classList.toggle("is-collapsed", !next);
  if (toggle) {
    toggle.setAttribute("aria-expanded", next ? "true" : "false");
    toggle.classList.toggle("is-open", next);
    toggle.title = next
      ? uiText("Masquer le défilement", "Afeno ny scroll", "Hide scroll controls")
      : uiText("Afficher le défilement", "Asehoy ny scroll", "Show scroll controls");
  }
  if (!next) stopConversationAutoScroll();
  if (persist) saveMessageUiSettings();
}

function handleConversationScrollButton(id) {
  if (id === "conv-auto-up") startConversationAutoScroll(-1);
  else if (id === "conv-auto-down") startConversationAutoScroll(1);
  else if (id === "conv-auto-stop") stopConversationAutoScroll();
  else if (id === "conv-typing-sound") {
    state.messageUiSettings.typingSound = !state.messageUiSettings.typingSound;
    if (!state.messageUiSettings.typingSound) stopConversationTypingSound();
    else if (state.conversationTypingVisible) startConversationTypingSound();
    syncMessageUiControls();
    saveMessageUiSettings();
  }
}

async function saveMessageUiSettings() {
  if (!state.currentUser) return;
  try {
    const allowedSounds = ["lyrame","soft","crystal","pulse","bell","silent"];
    const clean = {
      scrollSpeed: ["slow","normal","fast"].includes(state.messageUiSettings.scrollSpeed) ? state.messageUiSettings.scrollSpeed : "normal",
      typingSound: state.messageUiSettings.typingSound !== false,
      scrollControlsVisible: state.messageUiSettings.scrollControlsVisible === true,
      sendTypingIndicator: state.messageUiSettings.sendTypingIndicator !== false,
      sendReadReceipts: state.messageUiSettings.sendReadReceipts !== false,
      messageNotificationsEnabled: state.messageUiSettings.messageNotificationsEnabled !== false,
      messageNotificationSound: allowedSounds.includes(state.messageUiSettings.messageNotificationSound) ? state.messageUiSettings.messageNotificationSound : "lyrame"
    };
    state.messageUiSettings = clean;
    state.currentProfile = { ...(state.currentProfile || {}), messageUi: clean };
    await setDoc(doc(db, "users", state.currentUser.uid), { messageUi: clean, updatedAt: serverTimestamp() }, { merge: true });
  } catch (err) { console.warn("[message ui settings]", err); }
}

function syncMessageUiControls() {
  const saved = state.currentProfile?.messageUi || {};
  const allowedSounds = ["lyrame","soft","crystal","pulse","bell","silent"];
  state.messageUiSettings = {
    scrollSpeed: ["slow","normal","fast"].includes(saved.scrollSpeed) ? saved.scrollSpeed : (state.messageUiSettings?.scrollSpeed || "normal"),
    typingSound: saved.typingSound !== undefined ? saved.typingSound !== false : state.messageUiSettings?.typingSound !== false,
    scrollControlsVisible: saved.scrollControlsVisible !== undefined ? saved.scrollControlsVisible === true : state.messageUiSettings?.scrollControlsVisible === true,
    sendTypingIndicator: saved.sendTypingIndicator !== undefined ? saved.sendTypingIndicator !== false : state.messageUiSettings?.sendTypingIndicator !== false,
    sendReadReceipts: saved.sendReadReceipts !== undefined ? saved.sendReadReceipts !== false : state.messageUiSettings?.sendReadReceipts !== false,
    messageNotificationsEnabled: saved.messageNotificationsEnabled !== undefined ? saved.messageNotificationsEnabled !== false : state.messageUiSettings?.messageNotificationsEnabled !== false,
    messageNotificationSound: allowedSounds.includes(saved.messageNotificationSound) ? saved.messageNotificationSound : (allowedSounds.includes(state.messageUiSettings?.messageNotificationSound) ? state.messageUiSettings.messageNotificationSound : "lyrame")
  };
  const speed = $("#conv-scroll-speed"); if (speed) speed.value = state.messageUiSettings.scrollSpeed;
  const sound = $("#conv-typing-sound");
  if (sound) {
    sound.textContent = state.messageUiSettings.typingSound ? "🔊" : "🔇";
    sound.setAttribute("aria-pressed", state.messageUiSettings.typingSound ? "true" : "false");
    sound.title = state.messageUiSettings.typingSound ? uiText("Couper le son de saisie", "Vonoy ny feo manoratra", "Mute typing sound") : uiText("Activer le son de saisie", "Alefaso ny feo manoratra", "Enable typing sound");
  }
  const label = $("#conv-scroll-speed-label"); if (label) label.textContent = uiText("Vitesse", "Hafainganam-pandeha", "Speed");
  if (speed) {
    const labels = state.lang === "mg" ? ["Miadana","Antonony","Haingana"] : state.lang === "en" ? ["Slow","Normal","Fast"] : ["Lente","Normale","Rapide"];
    Array.from(speed.options).forEach((o, i) => { if (labels[i]) o.textContent = labels[i]; });
  }
  setConversationScrollControlsVisible(state.messageUiSettings.scrollControlsVisible === true, { persist: false });
}

startMessagesListener = function(convId) {
  if (listeners.messages) listeners.messages();
  const box = $("#conv-messages");
  if (!box) return;
  box.querySelectorAll(".msg").forEach(n => n.remove());
  box.querySelector(".conv-typing-lane")?.remove();
  toggleEmpty("conv-empty", true);
  const q = query(collection(db, "conversations", convId, "messages"), orderBy("createdAt", "asc"), limit(100));
  listeners.messages = onSnapshot(q, snap => {
    const current = $("#conv-messages"); if (!current) return;
    const initial = state.conversationMessagesLoadedFor !== convId;
    const nearBottom = isConversationNearBottom(current);
    const oldHeight = current.scrollHeight, oldTop = current.scrollTop;
    current.querySelectorAll(".msg").forEach(n => n.remove());
    current.querySelector(".conv-typing-lane")?.remove();
    if (snap.empty) { toggleEmpty("conv-empty", false); updateConversationScrollControls(); return; }
    toggleEmpty("conv-empty", true);
    const me = state.currentUser?.uid || "";
    let latestVisible = null;
    snap.forEach(d => {
      const msg = { id: d.id, ...d.data() };
      if ((Array.isArray(msg.deletedFor) ? msg.deletedFor : []).includes(me)) return;
      latestVisible = msg;
      current.appendChild(renderMessage(msg));
    });
    state.conversationMessagesLoadedFor = convId;
    if (latestVisible && latestVisible.senderId !== me) {
      state.suppressTypingUntil = Date.now() + 1200;
      stopConversationTypingSound();
    }
    markVisibleMessagesRead(convId, snap.docs);
    refreshConversationVisualState();
    if (initial || nearBottom || latestVisible?.senderId === me) current.scrollTop = current.scrollHeight;
    else current.scrollTop = Math.max(0, oldTop + (current.scrollHeight - oldHeight));
    updateConversationScrollControls();
  }, err => logError("[messages]", err));
};

const _messageUxOpenConversation = openConversation;
openConversation = async function(convId) {
  stopConversationAutoScroll();
  stopConversationTypingSound();
  state.conversationMessagesLoadedFor = "";
  syncMessageUiControls();
  return _messageUxOpenConversation(convId);
};

function activateConversationScrollControl(btn, event) {
  if (!btn) return;
  const now = Date.now();
  const previous = Number(btn.dataset.lastScrollActivation || 0);
  if (now - previous < 320) return;
  btn.dataset.lastScrollActivation = String(now);
  event?.preventDefault?.();
  event?.stopPropagation?.();
  handleConversationScrollButton(btn.id);
}

function bindConversationScrollControls() {
  const box = $("#conv-messages");
  box?.addEventListener("scroll", updateConversationScrollControls, { passive: true });

  ["conv-auto-up","conv-auto-down","conv-auto-stop","conv-typing-sound"].forEach(id => {
    const btn = document.getElementById(id);
    if (!btn || btn.dataset.boundScrollControl === "1") return;
    btn.dataset.boundScrollControl = "1";
    btn.addEventListener("click", e => activateConversationScrollControl(btn, e));
    btn.addEventListener("touchend", e => activateConversationScrollControl(btn, e), { passive: false });
  });

  const toggle = $("#conv-scroll-toggle");
  if (toggle && toggle.dataset.boundScrollToggle !== "1") {
    toggle.dataset.boundScrollToggle = "1";
    const runToggle = e => {
      const now=Date.now();
      const previous=Number(toggle.dataset.lastScrollActivation||0);
      if(now-previous<320)return;
      toggle.dataset.lastScrollActivation=String(now);
      e.preventDefault(); e.stopPropagation();
      setConversationScrollControlsVisible(!state.messageUiSettings.scrollControlsVisible);
    };
    toggle.addEventListener("click", runToggle);
    toggle.addEventListener("touchend", runToggle, { passive:false });
  }

  const speed = $("#conv-scroll-speed");
  if (speed && speed.dataset.boundScrollSpeed !== "1") {
    speed.dataset.boundScrollSpeed = "1";
    speed.addEventListener("change", e => {
      state.messageUiSettings.scrollSpeed = e.target.value;
      saveMessageUiSettings();
    });
  }

  syncMessageUiControls();
  updateConversationScrollControls();
}
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", bindConversationScrollControls, { once: true });
} else {
  bindConversationScrollControls();
}

/* ============================================================
   LYRAME — CONVERSATION THEME + SCROLL TOUCH FIX (2026-10-09)
   - réglages de thème partagés par conversation directe
   - 10 arrière-plans distants prédéfinis
   - bulles + opacité + overlay
   - paramètres ergonomiques (scroll/son) accessibles via ⚙️
   - boutons scroll utilisables sur écran tactile via délégation capture
   ============================================================ */

const LYRAME_CONVERSATION_BACKGROUNDS = [
  { id:"g1", group:"soft", label:"Grenat soyeux", css:"radial-gradient(circle at 18% 15%,rgba(255,255,255,.34),transparent 30%),linear-gradient(155deg,#f8e8ee 0%,#d98ca7 48%,#7a1831 100%)" },
  { id:"g2", group:"soft", label:"Aube rose", css:"radial-gradient(circle at 82% 12%,rgba(255,255,255,.55),transparent 26%),linear-gradient(165deg,#fff6f8 0%,#f7c7d5 42%,#c55f82 100%)" },
  { id:"g3", group:"soft", label:"Ciel calme", css:"radial-gradient(circle at 72% 22%,rgba(255,255,255,.60),transparent 24%),linear-gradient(160deg,#dff4ff 0%,#9bd0e8 50%,#5c7eab 100%)" },
  { id:"g4", group:"soft", label:"Sauge", css:"radial-gradient(circle at 22% 18%,rgba(255,255,255,.42),transparent 25%),linear-gradient(150deg,#edf6ee 0%,#b8d3b7 48%,#6b9272 100%)" },
  { id:"g5", group:"soft", label:"Lavande", css:"radial-gradient(circle at 78% 18%,rgba(255,255,255,.42),transparent 27%),linear-gradient(155deg,#f7f1ff 0%,#d7c0ec 50%,#8664a8 100%)" },
  { id:"g6", group:"bold", label:"Nuit grenat", css:"radial-gradient(circle at 18% 12%,rgba(211,98,133,.42),transparent 28%),radial-gradient(circle at 82% 88%,rgba(92,44,120,.38),transparent 30%),linear-gradient(165deg,#190910 0%,#421126 50%,#741b3a 100%)" },
  { id:"g7", group:"bold", label:"Océan profond", css:"radial-gradient(circle at 78% 16%,rgba(84,214,255,.30),transparent 28%),linear-gradient(165deg,#061622 0%,#0f4760 48%,#167e91 100%)" },
  { id:"g8", group:"bold", label:"Forêt nocturne", css:"radial-gradient(circle at 20% 18%,rgba(117,209,151,.26),transparent 28%),linear-gradient(160deg,#07150e 0%,#194a32 52%,#3f7955 100%)" },
  { id:"g9", group:"bold", label:"Or & grenat", css:"radial-gradient(circle at 78% 15%,rgba(255,218,126,.46),transparent 25%),linear-gradient(160deg,#2b1115 0%,#7a1831 52%,#c28b42 100%)" },
  { id:"g10", group:"bold", label:"Minuit violet", css:"radial-gradient(circle at 22% 14%,rgba(190,150,255,.30),transparent 27%),linear-gradient(160deg,#100a1c 0%,#34205d 52%,#6d4d96 100%)" }
];

const DEFAULT_CONVERSATION_THEME = {
  backgroundId: "",
  backgroundUrl: "",
  backgroundOverlay: 0.18,
  bubbleColor: "#8b1538",
  otherBubbleColor: "#f1f1f3",
  bubbleOpacity: 0.96
};

function sanitizeConversationTheme(raw = {}) {
  const legacyId = /^p([1-9]|10)$/.test(String(raw.backgroundId || "")) ? `g${String(raw.backgroundId).slice(1)}` : String(raw.backgroundId || "");
  const bg = LYRAME_CONVERSATION_BACKGROUNDS.find(x => x.id === legacyId);
  const validColor = v => /^#[0-9a-f]{6}$/i.test(String(v || ""));
  const clamp = (n, min, max) => Math.min(max, Math.max(min, Number(n) || 0));
  return {
    backgroundId: bg?.id || "",
    backgroundUrl: "",
    backgroundCss: bg?.css || "",
    backgroundOverlay: clamp(raw.backgroundOverlay ?? DEFAULT_CONVERSATION_THEME.backgroundOverlay, 0, 0.7),
    bubbleColor: validColor(raw.bubbleColor) ? raw.bubbleColor : DEFAULT_CONVERSATION_THEME.bubbleColor,
    otherBubbleColor: validColor(raw.otherBubbleColor) ? raw.otherBubbleColor : DEFAULT_CONVERSATION_THEME.otherBubbleColor,
    bubbleOpacity: clamp(raw.bubbleOpacity ?? DEFAULT_CONVERSATION_THEME.bubbleOpacity, 0.45, 1),
    bubbleStyle: ["rounded","soft","compact"].includes(String(raw.bubbleStyle || "")) ? String(raw.bubbleStyle) : "rounded"
  };
}

function applyConversationTheme(raw) {
  const tme = sanitizeConversationTheme(raw || {});
  const screen = $("#screen-conversation");
  const box = $("#conv-messages");
  const layer = $("#conv-background-layer");
  if (!screen || !box || !layer) return;
  const rgba = (hex, alpha) => {
    const v = String(hex || "#000000").replace("#", "");
    const n = parseInt(v, 16);
    const r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
    return `rgba(${r},${g},${b},${Math.min(1,Math.max(0,Number(alpha)||0))})`;
  };
  screen.style.setProperty("--conv-bubble-me", tme.bubbleColor);
  screen.style.setProperty("--conv-bubble-them", tme.otherBubbleColor);
  screen.style.setProperty("--conv-bubble-me-rgba", rgba(tme.bubbleColor, tme.bubbleOpacity));
  screen.style.setProperty("--conv-bubble-them-rgba", rgba(tme.otherBubbleColor, tme.bubbleOpacity));
  screen.style.setProperty("--conv-bubble-opacity", String(tme.bubbleOpacity));
  screen.style.setProperty("--conv-bg-overlay", String(tme.backgroundOverlay));
  screen.classList.remove("conv-bubble-style-rounded","conv-bubble-style-soft","conv-bubble-style-compact");
  screen.classList.add(`conv-bubble-style-${tme.bubbleStyle || "rounded"}`);
  if (tme.backgroundCss) {
    const overlayAlpha = Math.max(0, Math.min(0.7, Number(tme.backgroundOverlay) || 0));
    const overlayColor = state.theme === "dark" ? `rgba(0,0,0,${overlayAlpha})` : `rgba(255,255,255,${overlayAlpha})`;
    layer.style.backgroundImage = `linear-gradient(${overlayColor},${overlayColor}),${tme.backgroundCss}`;
    layer.classList.add("is-visible");
    screen.classList.add("has-conversation-background");
    box.style.backgroundImage = "none";
    box.classList.remove("has-conversation-background");
  } else {
    layer.style.backgroundImage = "none";
    layer.classList.remove("is-visible");
    screen.classList.remove("has-conversation-background");
    box.style.backgroundImage = "none";
    box.classList.remove("has-conversation-background");
  }
}

async function saveConversationTheme(theme) {
  if (!state.currentUser || !state.activeConvId || !state.activeConv || state.activeConv.isGroup) return;
  const clean = sanitizeConversationTheme(theme);
  await updateDoc(doc(db,"conversations",state.activeConvId), {
    messageTheme: clean,
    updatedAt: serverTimestamp()
  });
}

function settingsFieldLabel(text) {
  const el = document.createElement("div");
  el.className = "conv-settings-label";
  el.textContent = text;
  return el;
}

function createConversationToggle(labelText, checked, description = "") {
  const label = document.createElement("label");
  label.className = "conv-settings-toggle conv-settings-toggle-card";
  const text = document.createElement("span");
  text.className = "conv-settings-toggle-copy";
  const strong = document.createElement("strong");
  strong.textContent = labelText;
  text.appendChild(strong);
  if (description) {
    const small = document.createElement("small");
    small.textContent = description;
    text.appendChild(small);
  }
  const input = document.createElement("input");
  input.type = "checkbox";
  input.checked = !!checked;
  label.append(text, input);
  return { label, input };
}

function messageSoundOptionsMarkup(selected) {
  const options = [
    ["lyrame", uiText("LYRAME", "LYRAME", "LYRAME")],
    ["soft", uiText("Doux", "Malefaka", "Soft")],
    ["crystal", uiText("Cristal", "Kristaly", "Crystal")],
    ["pulse", uiText("Pulse", "Pulse", "Pulse")],
    ["bell", uiText("Cloche", "Lakolosy", "Bell")],
    ["silent", uiText("Silencieux", "Mangina", "Silent")]
  ];
  return options.map(([value,label]) => `<option value="${value}"${value===selected?" selected":""}>${escapeHtml(label)}</option>`).join("");
}

function openConversationSettings() {
  const conv = state.activeConv;
  if (!conv || !state.currentUser) return;
  if (conv.isGroup) {
    renderGroupInfo(conv);
    showScreen("group-info");
    return;
  }
  syncMessageUiControls();
  const modal = openDynamicModal(uiText("Paramètres de la conversation","Fikirana resaka","Conversation settings"));
  modal.body.classList.add("conversation-settings-body");
  const theme = sanitizeConversationTheme(conv.messageTheme || {});

  const bgTitle = settingsFieldLabel(uiText("Arrière-plan partagé","Background iarahana","Shared background"));
  const hint = document.createElement("p");
  hint.className = "conv-settings-hint";
  hint.textContent = uiText("L'arrière-plan reste fixe pendant le défilement et l'image entière reste visible.","Mijanona tsy mihetsika ny background rehefa manao scroll ary hita manontolo ilay sary.","The background stays fixed while messages scroll and the full image remains visible.");
  const grid = document.createElement("div"); grid.className = "conv-background-grid";
  const none = document.createElement("button"); none.type="button"; none.className="conv-bg-choice conv-bg-none"; none.textContent=uiText("Aucun","Tsy misy","None"); none.dataset.id="";
  grid.appendChild(none);
  LYRAME_CONVERSATION_BACKGROUNDS.forEach(bg=>{
    const b=document.createElement("button"); b.type="button"; b.className="conv-bg-choice"; b.dataset.id=bg.id; b.title=bg.label;
    b.style.backgroundImage=bg.css; b.innerHTML=`<span>${escapeHtml(bg.label)}</span>`; grid.appendChild(b);
  });
  const paintSelected=id=>grid.querySelectorAll(".conv-bg-choice").forEach(b=>b.classList.toggle("active",b.dataset.id===id));
  paintSelected(theme.backgroundId);

  const colorRow=document.createElement("div"); colorRow.className="conv-settings-row";
  const meWrap=document.createElement("label"); meWrap.className="conv-color-field"; meWrap.append(settingsFieldLabel(uiText("Ma bulle","Bubble-ko","My bubble")));
  const meColor=document.createElement("input"); meColor.type="color"; meColor.value=theme.bubbleColor; meWrap.appendChild(meColor);
  const themWrap=document.createElement("label"); themWrap.className="conv-color-field"; themWrap.append(settingsFieldLabel(uiText("Autre bulle","Bubble hafa","Other bubble")));
  const themColor=document.createElement("input"); themColor.type="color"; themColor.value=theme.otherBubbleColor; themWrap.appendChild(themColor);
  colorRow.append(meWrap,themWrap);

  const bubbleStyleLabel=settingsFieldLabel(uiText("Style des bulles","Endriky ny bubble","Bubble style"));
  const bubbleStyle=document.createElement("select");
  bubbleStyle.className="conv-settings-select";
  bubbleStyle.innerHTML=`<option value="rounded">${escapeHtml(uiText("Arrondi","Boribory","Rounded"))}</option><option value="soft">${escapeHtml(uiText("Doux","Malefaka","Soft"))}</option><option value="compact">${escapeHtml(uiText("Compact","Mifintina","Compact"))}</option>`;
  bubbleStyle.value=theme.bubbleStyle||"rounded";

  const opacityLabel=settingsFieldLabel(uiText("Opacité des bulles","Opacity bubble","Bubble opacity"));
  const opacity=document.createElement("input"); opacity.type="range"; opacity.min="0.45"; opacity.max="1"; opacity.step="0.05"; opacity.value=String(theme.bubbleOpacity); opacity.className="conv-settings-range";
  const overlayLabel=settingsFieldLabel(uiText("Voile de l'arrière-plan","Fahamaivan'ny background","Background overlay"));
  const overlay=document.createElement("input"); overlay.type="range"; overlay.min="0"; overlay.max="0.7"; overlay.step="0.05"; overlay.value=String(theme.backgroundOverlay); overlay.className="conv-settings-range";

  const privacyTitle=settingsFieldLabel(uiText("Confidentialité et confirmations","Tsiambaratelo sy fanamafisana","Privacy and confirmations"));
  const typingToggle=createConversationToggle(
    uiText("Afficher mon indicateur de saisie","Asehoy rehefa manoratra aho","Show my typing indicator"),
    state.messageUiSettings?.sendTypingIndicator !== false,
    uiText("Désactivez pour que l'autre personne ne voie pas que vous écrivez.","Vonoy raha tsy tianao ho hitan'ilay olona hoe manoratra ianao.","Turn off so the other person cannot see when you are typing.")
  );
  const readToggle=createConversationToggle(
    uiText("Envoyer les confirmations de lecture","Alefaso ny fanamafisana hoe hita","Send read receipts"),
    state.messageUiSettings?.sendReadReceipts !== false,
    uiText("Désactivez pour ne pas signaler que vous avez vu les nouveaux messages.","Vonoy raha tsy tianao ho fantatr'ilay olona fa efa hitanao ny hafatra vaovao.","Turn off so others are not told when you read new messages.")
  );

  const notifTitle=settingsFieldLabel(uiText("Notifications des messages","Fampandrenesana hafatra","Message notifications"));
  const notifToggle=createConversationToggle(
    uiText("Activer les notifications de messages","Alefaso ny notification hafatra","Enable message notifications"),
    state.messageUiSettings?.messageNotificationsEnabled !== false,
    uiText("Contrôle les notifications de message et leur son dans LYRAME.","Mifehy ny notification hafatra sy ny feony ao amin'ny LYRAME.","Controls message notifications and their sound inside LYRAME.")
  );
  const soundRow=document.createElement("div"); soundRow.className="conv-settings-sound-row";
  const soundWrap=document.createElement("label"); soundWrap.className="conv-settings-sound-field";
  soundWrap.append(settingsFieldLabel(uiText("Son de notification","Feo notification","Notification sound")));
  const soundSelect=document.createElement("select"); soundSelect.className="conv-settings-select";
  soundSelect.innerHTML=messageSoundOptionsMarkup(state.messageUiSettings?.messageNotificationSound || "lyrame");
  soundWrap.appendChild(soundSelect);
  const previewSound=styledButton(uiText("Tester le son","Andramo ny feo","Test sound"),"ghost");
  previewSound.type="button"; previewSound.classList.add("conv-sound-test-btn");
  soundRow.append(soundWrap,previewSound);

  const actions=document.createElement("div"); actions.className="conv-settings-actions";
  const save=styledButton(uiText("Enregistrer","Hitahiry","Save"));
  const reset=styledButton(uiText("Réinitialiser le thème","Avereno ny endrika","Reset theme"),"ghost");
  actions.append(save,reset);

  let selectedId=theme.backgroundId;
  grid.addEventListener("click",e=>{const b=e.target.closest(".conv-bg-choice"); if(!b)return; selectedId=b.dataset.id||""; paintSelected(selectedId);});
  previewSound.addEventListener("click",()=>playMessageNotificationSound(soundSelect.value,true));
  soundSelect.addEventListener("change",()=>{ if(soundSelect.value!=="silent") playMessageNotificationSound(soundSelect.value,true); });

  save.addEventListener("click",async()=>{
    const bg=LYRAME_CONVERSATION_BACKGROUNDS.find(x=>x.id===selectedId);
    const next={backgroundId:bg?.id||"",backgroundUrl:"",backgroundOverlay:Number(overlay.value),bubbleColor:meColor.value,otherBubbleColor:themColor.value,bubbleOpacity:Number(opacity.value),bubbleStyle:bubbleStyle.value||"rounded"};
    applyConversationTheme(next);
    const wasTypingVisible = state.messageUiSettings?.sendTypingIndicator !== false;
    state.messageUiSettings.sendTypingIndicator=typingToggle.input.checked;
    state.messageUiSettings.sendReadReceipts=readToggle.input.checked;
    state.messageUiSettings.messageNotificationsEnabled=notifToggle.input.checked;
    state.messageUiSettings.messageNotificationSound=soundSelect.value;
    if (wasTypingVisible && !typingToggle.input.checked && state.typingActive) await writeTypingState(false).catch(()=>{});
    if (!readToggle.input.checked) lyrameClearReadQueue();
    await Promise.all([saveConversationTheme(next),saveMessageUiSettings()]);
    syncMessageUiControls();
    startNotificationsListener();
    modal.close();
    showScreen("conversation");
    requestAnimationFrame(()=>$("#conv-text")?.focus());
  });
  reset.addEventListener("click",async()=>{
    applyConversationTheme(DEFAULT_CONVERSATION_THEME);
    await saveConversationTheme(DEFAULT_CONVERSATION_THEME);
    modal.close();
    showScreen("conversation");
  });

  modal.body.append(bgTitle,hint,grid,colorRow,bubbleStyleLabel,bubbleStyle,opacityLabel,opacity,overlayLabel,overlay,privacyTitle,typingToggle.label,readToggle.label,notifTitle,notifToggle.label,soundRow,actions);
}

/* Android/WebView fallback: capture click/touch even if a floating layer changes bubbling. */
document.addEventListener("click", e => {
  const btn=e.target.closest?.("#conv-auto-up,#conv-auto-down,#conv-auto-stop,#conv-typing-sound");
  if(btn) activateConversationScrollControl(btn,e);
}, true);
document.addEventListener("touchend", e => {
  const btn=e.target.closest?.("#conv-auto-up,#conv-auto-down,#conv-auto-stop,#conv-typing-sound");
  if(btn) activateConversationScrollControl(btn,e);
}, {capture:true,passive:false});
document.addEventListener("pointerup", e => {
  const btn=e.target.closest?.("#conv-auto-up,#conv-auto-down,#conv-auto-stop,#conv-typing-sound");
  if(btn) activateConversationScrollControl(btn,e);
}, true);

const _messageUxApplyTranslations = applyTranslations;
applyTranslations = function() {
  _messageUxApplyTranslations();
  syncMessageUiControls();
  lyrameMessagesTranslateHeader();
};

/* 2026-10-09 — le bouton ↕ est géré uniquement par bindConversationScrollControls(). */


/* ============================================================
   LYRAME — NAVIGATION CHAT SIMPLE (2026-10-09)
   Aucun auto-scroll, vitesse, stop ou son dans ce contrôle.
   Un appui = aller en haut / aller au dernier message.
   ============================================================ */
function lyrameConversationJump(direction) {
  const messages = document.querySelector('#conv-messages');
  const screen = document.querySelector('#screen-conversation');
  if (!messages || !screen) return;

  if (direction === 'up') {
    const firstMessage = messages.querySelector('.msg:not(.hidden), .conv-message:not(.hidden)');
    if (firstMessage) {
      try { firstMessage.scrollIntoView({ behavior: 'smooth', block: 'start' }); return; } catch (_) {}
    }
    try { screen.scrollIntoView({ behavior: 'smooth', block: 'start' }); } catch (_) { window.scrollTo(0, 0); }
    return;
  }

  const all = messages.querySelectorAll('.msg:not(.hidden), .conv-message:not(.hidden)');
  const lastMessage = all.length ? all[all.length - 1] : null;
  if (lastMessage) {
    try { lastMessage.scrollIntoView({ behavior: 'smooth', block: 'end' }); return; } catch (_) {}
  }
  try { document.querySelector('#conv-form')?.scrollIntoView({ behavior: 'smooth', block: 'end' }); } catch (_) { window.scrollTo(0, document.body.scrollHeight); }
}

function bindLyrameSimpleConversationScroll() {
  const up = document.querySelector('#conv-jump-up');
  const down = document.querySelector('#conv-jump-down');
  const bind = (el, dir) => {
    if (!el || el.dataset.lyrameSimpleScrollBound === '1') return;
    el.dataset.lyrameSimpleScrollBound = '1';
    let last = 0;
    const run = (event) => {
      const now = Date.now();
      if (now - last < 220) return;
      last = now;
      event?.preventDefault?.();
      event?.stopPropagation?.();
      lyrameConversationJump(dir);
    };
    el.addEventListener('click', run);
    el.addEventListener('pointerup', run, { passive:false });
    el.addEventListener('touchend', run, { passive:false });
  };
  bind(up, 'up');
  bind(down, 'down');
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', bindLyrameSimpleConversationScroll, { once:true });
} else {
  bindLyrameSimpleConversationScroll();
}


/* ============================================================
   LYRAME — COMMENT COMPOSER STABLE + MENTIONS (2026-10-09)
   - Un seul comportement de saisie pour commentaire et réponses.
   - Photo + emoji uniquement dans le composeur.
   - @ tapé au clavier ouvre uniquement amis + Pages suivies.
   - Le @ n'est pas affiché après publication; la mention est grenat + bold.
   ============================================================ */
state.commentMentionSelections = new Map();
state.messageSending = false;

let commentMentionCache = { at: 0, items: [] };
let activeCommentMentionPopup = null;

function commentMentionToken(value) {
  return String(value || "")
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[^A-Za-z0-9_.-]+/g, "_")
    .replace(/^_+|_+$/g, "")
    .slice(0, 40);
}

async function loadEligibleCommentMentions() {
  const now = Date.now();
  if (commentMentionCache.items.length && now - commentMentionCache.at < 300000) return commentMentionCache.items;
  if (!state.currentUser) return [];
  const items = [];
  const friendIds = Array.from(state.friendIds || []);
  const friends = await Promise.all(friendIds.map(uid => getUserProfile(uid).catch(() => null)));
  friends.forEach((profile, i) => {
    if (!profile) return;
    const token = commentMentionToken(profile.username || profile.fullname || friendIds[i]);
    if (!token) return;
    items.push({
      type: "user", id: friendIds[i], token,
      label: profile.username || profile.fullname || token,
      subtitle: profile.fullname || "",
      username: profile.username || "",
      photoURL: profile.photoURL || ""
    });
  });

  try {
    const snap = await getDocs(query(collection(db, "pages"), limit(100)));
    const pages = snap.docs.map(d => ({ id:d.id, ...d.data() }));
    const followed = await Promise.all(pages.map(async page => {
      try {
        const f = await getDoc(doc(db, "pages", page.id, "followers", state.currentUser.uid));
        return f.exists() ? page : null;
      } catch (_) { return null; }
    }));
    followed.filter(Boolean).forEach(page => {
      const token = commentMentionToken(page.username || page.name || page.id);
      if (!token) return;
      items.push({ type:"page", id:page.id, token, label:page.name || token, username:"", photoURL:page.avatarURL || "" });
    });
  } catch (err) {
    console.warn("[comment mentions pages]", err);
  }

  const seen = new Set();
  commentMentionCache = {
    at: now,
    items: items.filter(item => {
      const key = `${item.type}:${item.id}`;
      if (seen.has(key)) return false;
      seen.add(key); return true;
    })
  };
  return commentMentionCache.items;
}

function hideCommentMentionSuggestions() {
  if (activeCommentMentionPopup) {
    activeCommentMentionPopup.remove();
    activeCommentMentionPopup = null;
  }
}

function currentMentionFragment(input) {
  if (!input) return null;
  const caret = Number.isFinite(input.selectionStart) ? input.selectionStart : input.value.length;
  const before = input.value.slice(0, caret);
  const match = before.match(/(^|\s)@([A-Za-z0-9_.-]{0,40})$/);
  if (!match) return null;
  return { fragment: match[2] || "", start: caret - (match[2] || "").length - 1, end: caret };
}

async function refreshCommentMentionSuggestions(input, store) {
  const fragmentInfo = currentMentionFragment(input);
  if (!fragmentInfo) { hideCommentMentionSuggestions(); return; }
  const requestKey = `${fragmentInfo.start}:${fragmentInfo.fragment}:${Date.now()}`;
  input.dataset.mentionRequestKey = requestKey;
  const items = await loadEligibleCommentMentions();
  if (!input.isConnected || input.dataset.mentionRequestKey !== requestKey) return;
  const q = fragmentInfo.fragment.toLowerCase();
  const matches = items.filter(item => !q || item.token.toLowerCase().includes(q) || item.label.toLowerCase().includes(q)).slice(0, 8);
  hideCommentMentionSuggestions();
  if (!matches.length) return;

  const pop = document.createElement("div");
  pop.className = "comment-mention-suggestions";
  matches.forEach(item => {
    const row = document.createElement("button");
    row.type = "button";
    row.className = "comment-mention-suggestion";
    const kindLabel = item.type === "page" ? uiText("Page suivie", "Page arahina", "Followed Page") : uiText("Ami", "Namana", "Friend");
    const secondary = item.subtitle && item.subtitle !== item.label ? `${item.subtitle} · ${kindLabel}` : kindLabel;
    row.innerHTML = `<span class="avatar">${avatarMarkup(item.photoURL, item.label)}</span><span class="grow"><strong>${escapeHtml(item.label)}</strong><small>${escapeHtml(secondary)}</small></span>`;
    row.addEventListener("mousedown", e => e.preventDefault());
    row.addEventListener("click", e => {
      e.preventDefault(); e.stopPropagation();
      const info = currentMentionFragment(input);
      if (!info) return;
      const replacement = `@${item.token} `;
      input.value = input.value.slice(0, info.start) + replacement + input.value.slice(info.end);
      const pos = info.start + replacement.length;
      try { input.setSelectionRange(pos, pos); } catch (_) {}
      store.set(`${item.type}:${item.id}`, { type:item.type, id:item.id, token:item.token, label:item.label });
      hideCommentMentionSuggestions();
      input.focus();
      input.dispatchEvent(new Event("input", { bubbles:true }));
    });
    pop.appendChild(row);
  });
  document.body.appendChild(pop);
  activeCommentMentionPopup = pop;
  positionFixedNear(pop, input);
}

function bindCommentMentionInput(input, store) {
  if (!input || input.dataset.commentMentionBound === "1") return;
  input.dataset.commentMentionBound = "1";
  input.addEventListener("keyup", () => refreshCommentMentionSuggestions(input, store));
  input.addEventListener("click", () => refreshCommentMentionSuggestions(input, store));
  input.addEventListener("blur", () => setTimeout(() => {
    if (!activeCommentMentionPopup?.matches(":hover")) hideCommentMentionSuggestions();
  }, 140));
}

function collectCommentMentions(text, store) {
  const value = String(text || "");
  return Array.from(store?.values?.() || []).filter(item => value.includes(`@${item.token}`)).map(item => ({
    type:item.type, id:item.id, token:item.token, label:item.label
  }));
}

function commentTextWithMentions(text, mentions) {
  const raw = String(text || "");
  const list = Array.isArray(mentions) ? mentions.filter(m => m?.token) : [];
  if (!list.length) return escapeHtml(raw);
  const byLength = [...list].sort((a,b) => String(b.token).length - String(a.token).length);
  let out = "";
  for (let i = 0; i < raw.length;) {
    let hit = null;
    if (raw[i] === "@") {
      hit = byLength.find(m => raw.startsWith(`@${m.token}`, i));
    }
    if (hit) {
      const end = i + hit.token.length + 1;
      const next = raw[end] || "";
      if (!next || /[\s.,!?;:()\[\]{}'"\-]/.test(next)) {
        out += `<strong class="comment-mention" data-mention-type="${escapeHtml(hit.type || "")}" data-mention-id="${escapeHtml(hit.id || "")}">${escapeHtml(hit.label || hit.token)}</strong>`;
        i = end;
        continue;
      }
    }
    out += escapeHtml(raw[i]);
    i += 1;
  }
  return out;
}

async function notifyCommentMentions(mentions, { postId, commentId, actorName } = {}) {
  if (!state.currentUser || !Array.isArray(mentions) || !mentions.length) return;
  const recipients = new Set();
  for (const mention of mentions) {
    if (mention.type === "user" && mention.id) recipients.add(mention.id);
    if (mention.type === "page" && mention.id) {
      try {
        const snap = await getDoc(doc(db, "pages", mention.id));
        if (snap.exists()) {
          const page = snap.data() || {};
          (Array.isArray(page.adminIds) ? page.adminIds : []).forEach(uid => recipients.add(uid));
          if (page.ownerId) recipients.add(page.ownerId);
        }
      } catch (err) { console.warn("[page mention recipients]", err); }
    }
  }
  recipients.delete(state.currentUser.uid);
  await Promise.all(Array.from(recipients).map(userId => createNotification({
    id: `mention_${postId}_${commentId}_${userId}`,
    userId,
    actorId: state.currentUser.uid,
    type: "mention",
    title: uiText("Vous avez été mentionné", "Voatonona ianao", "You were mentioned"),
    preview: `${actorName || state.currentProfile?.fullname || uiSomeone()} ${uiText("vous a mentionné dans un commentaire.", "nanonona anao tao amin’ny commentaire.", "mentioned you in a comment.")}`,
    extra: { postId, commentId }
  })));
}

function resizeUnifiedCommentTextarea(input) {
  if (!input) return;
  const maxHeight = window.matchMedia?.("(max-width: 430px)")?.matches ? 118 : 126;
  if (!(input.value || "").trim()) {
    input.style.height = "38px";
    input.classList.remove("is-scrollable");
    input.scrollTop = 0;
    return;
  }
  input.style.height = "38px";
  const measured = Math.max(38, input.scrollHeight || 38);
  input.style.height = `${Math.min(measured, maxHeight)}px`;
  input.classList.toggle("is-scrollable", measured > maxHeight);
}

function bindMainCommentMentionController() {
  const input = $("#comment-text");
  if (!input) return;
  bindCommentMentionInput(input, state.commentMentionSelections);
}
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", bindMainCommentMentionController, { once:true });
} else {
  bindMainCommentMentionController();
}
document.addEventListener("click", e => {
  if (activeCommentMentionPopup && !activeCommentMentionPopup.contains(e.target) && e.target !== $("#comment-text")) hideCommentMentionSuggestions();
});


/* ============================================================
   LYRAME — MESSAGE ENGINE STABLE + PERFORMANCE (2026-10-09)
   Objectifs :
   - une seule écoute du document conversation actif ;
   - une seule écoute des messages ;
   - rendu incrémental via docChanges() au lieu de reconstruire 100 bulles ;
   - dernières 100 bulles (limitToLast) au lieu des 100 plus anciennes ;
   - envoi texte atomique, sans verrou réseau bloquant le message suivant ;
   - accusés de lecture regroupés ;
   - arrêt propre des listeners/timers quand on quitte ou change de conversation.
   ============================================================ */
state.messageReadQueue = state.messageReadQueue instanceof Map ? state.messageReadQueue : new Map();
state.messageReadTimer = state.messageReadTimer || null;
state.activeConversationGeneration = Number(state.activeConversationGeneration || 0);

function lyrameFindMessageNode(box, messageId) {
  if (!box || !messageId) return null;
  return Array.from(box.querySelectorAll('.msg[data-message-id]')).find(n => n.dataset.messageId === messageId) || null;
}

function lyrameIsMessageVisibleForMe(data, me = state.currentUser?.uid || '') {
  const deletedFor = Array.isArray(data?.deletedFor) ? data.deletedFor : [];
  return !deletedFor.includes(me);
}

function lyrameLastVisibleMessage(snapshot, me) {
  for (let i = snapshot.docs.length - 1; i >= 0; i--) {
    const d = snapshot.docs[i];
    const data = d.data();
    if (lyrameIsMessageVisibleForMe(data, me)) return { id: d.id, ...data };
  }
  return null;
}

function lyramePlaceMessageNode(box, node, snapshot, messageId, me) {
  if (!box || !node) return;
  const docs = snapshot.docs;
  const idx = docs.findIndex(d => d.id === messageId);
  if (idx >= 0) {
    for (let i = idx + 1; i < docs.length; i++) {
      const d = docs[i];
      if (!lyrameIsMessageVisibleForMe(d.data(), me)) continue;
      const next = lyrameFindMessageNode(box, d.id);
      if (next && next !== node) {
        box.insertBefore(node, next);
        return;
      }
    }
  }
  const typingLane = box.querySelector('.conv-typing-lane');
  if (typingLane) box.insertBefore(node, typingLane);
  else box.appendChild(node);
}

function lyrameClearReadQueue() {
  if (state.messageReadTimer) {
    clearTimeout(state.messageReadTimer);
    state.messageReadTimer = null;
  }
  state.messageReadQueue?.clear?.();
}

function lyrameQueueReadReceipts(convId, docs) {
  if (state.messageUiSettings?.sendReadReceipts === false) { lyrameClearReadQueue(); return; }
  if (!state.currentUser || !convId || !Array.isArray(docs) || !docs.length) return;
  const me = state.currentUser.uid;
  docs.forEach(d => {
    const data = d.data();
    if (data.senderId === me) return;
    if (!lyrameIsMessageVisibleForMe(data, me)) return;
    const readBy = Array.isArray(data.readBy) ? data.readBy : [];
    if (readBy.includes(me)) return;
    state.messageReadQueue.set(d.id, { ref: d.ref, convId });
  });
  if (state.messageReadTimer || !state.messageReadQueue.size) return;
  state.messageReadTimer = setTimeout(async () => {
    state.messageReadTimer = null;
    if (!state.currentUser) { state.messageReadQueue.clear(); return; }
    const uid = state.currentUser.uid;
    const entries = Array.from(state.messageReadQueue.values()).filter(x => x.convId === state.activeConvId).slice(0, 400);
    state.messageReadQueue.clear();
    if (!entries.length) return;
    try {
      const batch = writeBatch(db);
      entries.forEach(x => batch.update(x.ref, { readBy: arrayUnion(uid) }));
      await batch.commit();
    } catch (err) {
      console.warn('[read receipts optimized]', err);
    }
  }, 180);
}

function lyrameStopOldTypingBestEffort() {
  const uid = state.currentUser?.uid;
  const convId = state.activeConvId;
  if (!uid || !convId || !state.typingActive) return;
  updateDoc(doc(db, 'conversations', convId), {
    [`typing.${uid}`]: {
      active: false,
      name: state.currentProfile?.fullname || '',
      updatedAt: serverTimestamp()
    }
  }).catch(() => {});
}

function lyrameCleanupConversationRuntime() {
  ['messages','conversationDoc','conversationRequest','conversationUx','presence'].forEach(key => {
    const unsub = listeners[key];
    if (typeof unsub === 'function') {
      try { unsub(); } catch (_) {}
    }
    listeners[key] = null;
  });
  if (listeners.presenceRefresh) {
    clearInterval(listeners.presenceRefresh);
    listeners.presenceRefresh = null;
  }
  clearTimeout(state.typingTimer);
  state.typingTimer = null;
  state.typingActive = false;
  try { stopConversationTypingSound?.(); } catch (_) {}
  try { stopConversationAutoScroll?.(); } catch (_) {}
  lyrameClearReadQueue();
}

function lyramePaintHeaderTyping(typing) {
  const typingEl = $('#conv-typing');
  if (!typingEl) return;
  if (typing) {
    typingEl.innerHTML = '<span></span><span></span><span></span>';
    typingEl.setAttribute('aria-label', state.lang === 'mg' ? 'Manoratra' : state.lang === 'en' ? 'Typing' : 'Écrit');
    showEl(typingEl);
  } else {
    typingEl.innerHTML = '';
    hideEl(typingEl);
  }
}

/* Remplace tous les wrappers précédents par UN SEUL listener conversation. */
startConversationDocListener = function(convId) {
  if (!convId) return;
  ['conversationDoc','conversationRequest','conversationUx'].forEach(key => {
    const unsub = listeners[key];
    if (typeof unsub === 'function') { try { unsub(); } catch (_) {} }
    listeners[key] = null;
  });

  const generation = state.activeConversationGeneration;
  let lastIdentityKey = '';
  let lastThemeKey = '';
  let lastOtherUid = null;
  let lastGroupRenderKey = '';

  listeners.conversationDoc = onSnapshot(doc(db, 'conversations', convId), async snap => {
    if (generation !== state.activeConversationGeneration || state.activeConvId !== convId) return;
    if (!snap.exists()) {
      state.activeConv = null;
      return;
    }

    const c = { id: snap.id, ...snap.data() };
    const uid = state.currentUser?.uid || '';
    const members = Array.isArray(c.memberIds) ? c.memberIds : [];

    if (uid && members.length && !members.includes(uid)) {
      state.activeConv = null;
      if (listeners.messages) { try { listeners.messages(); } catch (_) {} listeners.messages = null; }
      state.activeConvId = null;
      showScreen('messages');
      return;
    }

    state.activeConv = c;
    updateMessageRequestBanner(c);

    const typing = typingDataFromConversation(c);
    lyramePaintHeaderTyping(typing);
    renderConversationTypingLane(typing);

    const themeKey = JSON.stringify(c.messageTheme || null);
    if (themeKey !== lastThemeKey) {
      lastThemeKey = themeKey;
      applyConversationTheme(c.messageTheme || null);
    }

    const identityKey = c.isGroup || c.type === 'group'
      ? `g|${c.name || ''}|${groupCover(c)}|${members.join(',')}`
      : `d|${members.join(',')}`;

    if (identityKey !== lastIdentityKey) {
      lastIdentityKey = identityKey;
      try {
        const info = await resolveConversationInfo(c);
        if (generation !== state.activeConversationGeneration || state.activeConvId !== convId) return;
        const avatar = $('#conv-profile-avatar');
        if (avatar) avatar.innerHTML = avatarMarkup(info.photoURL, info.name);
        const box = $('#conv-header-info');
        if (box) box.innerHTML = `<div class="name">${escapeHtml(info.name)}${identityBadgeMarkup(info.badgeProfile)}</div><div class="sub">${escapeHtml(info.sub)}</div>`;

        if (c.isGroup || c.type === 'group') {
          if (listeners.presence) { try { listeners.presence(); } catch (_) {} listeners.presence = null; }
          if (listeners.presenceRefresh) { clearInterval(listeners.presenceRefresh); listeners.presenceRefresh = null; }
          lastOtherUid = null;
          setText('conv-presence', `${members.length} ${t('group_members_count')}`);
        } else if (info.otherUid !== lastOtherUid) {
          lastOtherUid = info.otherUid;
          listenConversationPresence(info.otherUid);
        }
      } catch (err) {
        console.warn('[conversation identity]', err);
      }
    }

    if (c.isGroup || c.type === 'group') {
      const groupKey = `${c.name || ''}|${c.description || ''}|${c.privacy || ''}|${(c.adminIds || []).join(',')}|${members.join(',')}|${groupCover(c)}`;
      if (groupKey !== lastGroupRenderKey) {
        lastGroupRenderKey = groupKey;
        renderGroupInfo(c);
      }
    }
  }, err => logError('[conversation doc stable]', err));
};

/* Remplace le full re-render par des modifications ciblées. */
startMessagesListener = function(convId) {
  if (listeners.messages) { try { listeners.messages(); } catch (_) {} listeners.messages = null; }
  lyrameClearReadQueue();

  const box = $('#conv-messages');
  if (!box) return;
  box.querySelectorAll('.msg').forEach(n => n.remove());
  box.querySelector('.conv-typing-lane')?.remove();
  toggleEmpty('conv-empty', true);

  const generation = state.activeConversationGeneration;
  const q = query(
    collection(db, 'conversations', convId, 'messages'),
    orderBy('createdAt', 'asc'),
    limitToLast(100)
  );
  let initialized = false;

  listeners.messages = onSnapshot(q, snap => {
    if (generation !== state.activeConversationGeneration || state.activeConvId !== convId) return;
    const current = $('#conv-messages');
    if (!current) return;
    const me = state.currentUser?.uid || '';
    const nearBottom = isConversationNearBottom(current);
    const oldHeight = current.scrollHeight;
    const oldTop = current.scrollTop;

    if (!initialized) {
      current.querySelectorAll('.msg').forEach(n => n.remove());
      const typingLane = current.querySelector('.conv-typing-lane');
      const frag = document.createDocumentFragment();
      snap.docs.forEach(d => {
        const data = d.data();
        if (!lyrameIsMessageVisibleForMe(data, me)) return;
        frag.appendChild(renderMessage({ id: d.id, ...data }));
      });
      if (typingLane) current.insertBefore(frag, typingLane); else current.appendChild(frag);
      initialized = true;
      state.conversationMessagesLoadedFor = convId;
      lyrameQueueReadReceipts(convId, snap.docs);
    } else {
      const changedForRead = [];
      let incomingNewMessage = false;
      snap.docChanges().forEach(change => {
        const d = change.doc;
        const data = d.data();
        const existing = lyrameFindMessageNode(current, d.id);

        if (change.type === 'removed' || !lyrameIsMessageVisibleForMe(data, me)) {
          existing?.remove();
          return;
        }

        const nextNode = renderMessage({ id: d.id, ...data });
        if (existing) existing.replaceWith(nextNode);
        lyramePlaceMessageNode(current, nextNode, snap, d.id, me);
        changedForRead.push(d);
        if (change.type === 'added' && data.senderId !== me) incomingNewMessage = true;
      });
      if (changedForRead.length) lyrameQueueReadReceipts(convId, changedForRead);
      if (incomingNewMessage) {
        state.suppressTypingUntil = Date.now() + 1200;
        stopConversationTypingSound();
      }
    }

    const latestVisible = lyrameLastVisibleMessage(snap, me);
    toggleEmpty('conv-empty', !!latestVisible);
    refreshConversationVisualState();

    if (!latestVisible) {
      current.scrollTop = 0;
    } else if (!state.conversationMessagesLoadedFor || nearBottom || latestVisible.senderId === me) {
      current.scrollTop = current.scrollHeight;
    } else if (current.scrollHeight !== oldHeight) {
      current.scrollTop = Math.max(0, oldTop + (current.scrollHeight - oldHeight));
    }
    state.conversationMessagesLoadedFor = convId;
    updateConversationScrollControls();
  }, err => logError('[messages stable]', err));
};

/* Le formulaire reste disponible immédiatement après chaque envoi.
   Les écritures sont atomiques mais ne bloquent plus le message suivant. */
handleSendMessage = function(e) {
  e?.preventDefault?.();
  if (!state.currentUser || !state.activeConvId) return;
  const input = $('#conv-text');
  const text = (input?.value || '').trim().slice(0, 4000);
  if (!text) return;

  const convId = state.activeConvId;
  const user = state.currentUser;
  const replyTo = state.messageReplyTo ? { ...state.messageReplyTo } : null;
  const msgRef = doc(collection(db, 'conversations', convId, 'messages'));
  const btn = e?.submitter || e?.target?.querySelector?.('button[type="submit"]') || $('#conv-form button[type="submit"]');

  /* Libère l'UI AVANT l'acquittement réseau : un deuxième message peut partir immédiatement. */
  if (input) input.value = '';
  clearMessageReply();
  clearTimeout(state.typingTimer);
  state.typingTimer = null;
  state.typingActive = false;
  if (btn) {
    btn.classList.add('is-sending-pulse');
    setTimeout(() => btn.classList.remove('is-sending-pulse'), 220);
  }
  input?.focus();

  const batch = writeBatch(db);
  batch.set(msgRef, {
    senderId: user.uid,
    senderName: state.currentProfile?.fullname || '',
    text,
    mediaURL: '',
    mediaPublicId: '',
    mediaType: '',
    replyTo,
    readBy: [user.uid],
    deletedFor: [],
    deletedForEveryone: false,
    createdAt: serverTimestamp(),
    clientCreatedAt: Date.now()
  });
  batch.update(doc(db, 'conversations', convId), {
    lastMessage: text.slice(0, 120),
    lastMessageAt: serverTimestamp(),
    updatedAt: serverTimestamp()
  });

  /* Chaque submit possède sa propre promesse : aucun state.messageSending global ne peut bloquer le suivant. */
  batch.commit().then(() => {
    notifyConversationMembers(convId, text, null).catch?.(err => console.warn('[message notification]', err));
    // Assistant IA : l'expéditeur déclenche le traitement sécurisé du serveur.
    // Le compte destinataire peut être déconnecté ou son téléphone éteint.
    void lyrAutoTriggerAfterMessage(convId, msgRef.id, user, state.activeConv);

  }).catch(err => {
    logError('[send message stable]', err);
    toast(firestoreWriteErrorLabel(err, t('err_generic')));
    /* Ne pas écraser un nouveau texte déjà tapé pendant l'échec. */
    if (input && !input.value.trim()) input.value = text;
  });

  writeTypingState(false).catch?.(() => {});
};

/* Ouverture propre : aucun listener de l'ancienne conversation ne survit. */
openConversation = async function(convId) {
  if (!convId) return;
  lyrameStopOldTypingBestEffort();
  lyrameCleanupConversationRuntime();
  state.activeConversationGeneration += 1;
  state.conversationMessagesLoadedFor = '';
  clearMessageReply();
  state.activeConvId = convId;
  state.activeConv = null;
  showScreen('conversation');
  closeEmojiPickers();
  setText('conv-presence', '');
  hideEl($('#message-request-banner'));
  $('#conv-form')?.classList.remove('hidden');
  try { syncMessageUiControls?.(); } catch (_) {}
  startConversationDocListener(convId);
  startMessagesListener(convId);
};

/* Quand on quitte le chat, arrêter les flux lourds au lieu de les laisser vivre en arrière-plan. */
const _lyrameStableShowScreen = showScreen;
showScreen = function(name, opts = {}) {
  const prev = currentScreenName();
  if (prev === 'conversation' && name !== 'conversation') {
    lyrameStopOldTypingBestEffort();
    lyrameCleanupConversationRuntime();
    state.activeConversationGeneration += 1;
  }
  return _lyrameStableShowScreen(name, opts);
};

/* clearListeners() original ne savait pas arrêter presenceRefresh (setInterval). */
const _lyrameStableClearListeners = clearListeners;
clearListeners = function() {
  lyrameCleanupConversationRuntime();
  return _lyrameStableClearListeners();
};

/* Média dans le chat : ne jamais charger lourdement 100 vidéos/images hors écran. */
const _lyrameStableRenderMessage = renderMessage;
renderMessage = function(message) {
  const el = _lyrameStableRenderMessage(message);
  el.querySelectorAll('img').forEach(img => {
    img.loading = 'lazy';
    img.decoding = 'async';
  });
  el.querySelectorAll('video').forEach(video => {
    video.preload = 'metadata';
  });
  return el;
};

/* Si l'onglet passe en arrière-plan, couper les effets périodiques du chat. */
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState !== 'visible') {
    try { stopConversationTypingSound?.(); } catch (_) {}
    try { stopConversationAutoScroll?.(); } catch (_) {}
  }
}, { passive: true });

/* ============================================================
   LYRAME PWA production bootstrap — v36
   Network-only service worker + Firebase Cloud Messaging.
   No posts/messages/profile data are stored by the service worker.
   ============================================================ */
if (typeof window !== "undefined" && "serviceWorker" in navigator && window.location.protocol === "https:") {
  window.addEventListener("load", () => { void registerLyrameServiceWorker(); }, { once: true });
}


/* ============================================================
   LYRAME 37 — CHAT FIXE, FONDS PHOTO PARTAGÉS, STORIES 15s,
   FOLLOW UI, DESCRIPTION 3 LIGNES
   ============================================================ */

/* 10 vrais fonds photo distants : 5 tonalités masculines, 5 féminines.
   Seul l'id est stocké dans la conversation Firestore : même rendu sur
   tous les appareils, sans alourdir l'APK. */
LYRAME_CONVERSATION_BACKGROUNDS.splice(0, LYRAME_CONVERSATION_BACKGROUNDS.length,
  {id:"m1",group:"men",label:"Homme · Montagne",css:'url("https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=1080&q=82")'},
  {id:"m2",group:"men",label:"Homme · Ville de nuit",css:'url("https://images.unsplash.com/photo-1519501025264-65ba15a82390?auto=format&fit=crop&w=1080&q=82")'},
  {id:"m3",group:"men",label:"Homme · Océan",css:'url("https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1080&q=82")'},
  {id:"m4",group:"men",label:"Homme · Forêt",css:'url("https://images.unsplash.com/photo-1441974231531-c6227db76b6e?auto=format&fit=crop&w=1080&q=82")'},
  {id:"m5",group:"men",label:"Homme · Route",css:'url("https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1080&q=82")'},
  {id:"f1",group:"women",label:"Femme · Fleurs",css:'url("https://images.unsplash.com/photo-1490750967868-88aa4486c946?auto=format&fit=crop&w=1080&q=82")'},
  {id:"f2",group:"women",label:"Femme · Coucher de soleil",css:'url("https://images.unsplash.com/photo-1490730141103-6cac27aaab94?auto=format&fit=crop&w=1080&q=82")'},
  {id:"f3",group:"women",label:"Femme · Lavande",css:'url("https://images.unsplash.com/photo-1499002238440-d264edd596ec?auto=format&fit=crop&w=1080&q=82")'},
  {id:"f4",group:"women",label:"Femme · Lumières",css:'url("https://images.unsplash.com/photo-1513151233558-d860c5398176?auto=format&fit=crop&w=1080&q=82")'},
  {id:"f5",group:"women",label:"Femme · Rose douce",css:'url("https://images.unsplash.com/photo-1497250681960-ef046c08a56e?auto=format&fit=crop&w=1080&q=82")'}
);

/* Compatibilité des anciens ids g1..g10 vers les nouveaux fonds photo. */
const _sanitizeConversationThemeV37 = sanitizeConversationTheme;
sanitizeConversationTheme = function(raw = {}) {
  const map = {g1:"f1",g2:"f2",g3:"m3",g4:"m4",g5:"f3",g6:"m2",g7:"m3",g8:"m4",g9:"m1",g10:"f4",p1:"f1",p2:"f2",p3:"m3",p4:"m4",p5:"f3",p6:"m2",p7:"m3",p8:"m4",p9:"m1",p10:"f4"};
  const incoming={...(raw||{})};
  if(map[String(incoming.backgroundId||"")]) incoming.backgroundId=map[String(incoming.backgroundId||"")];
  const clean=_sanitizeConversationThemeV37(incoming);
  const bg=LYRAME_CONVERSATION_BACKGROUNDS.find(x=>x.id===String(incoming.backgroundId||""));
  clean.backgroundId=bg?.id||"";
  clean.backgroundCss=bg?.css||"";
  clean.bubbleStyle=["rounded","soft","compact"].includes(String(incoming.bubbleStyle||""))?String(incoming.bubbleStyle):"rounded";
  return clean;
};

/* FOLLOW : setBusy() restaurait l'ancien libellé après succès. On réapplique
   l'état réel après la fin du busy et on synchronise toutes les cartes. */
toggleFollowUid = async function(targetUid, btn) {
  if(!state.currentUser||!targetUid||targetUid===state.currentUser.uid)return;
  if(btn?.disabled)return;
  let nextFollowing=null;
  if(btn)setBusy(btn,true,"...");
  try{
    const current=(await getDoc(doc(db,"users",state.currentUser.uid,"following",targetUid))).exists();
    nextFollowing=await applyFollowState(targetUid,!current);
    toast(nextFollowing?t("msg_followed"):t("msg_unfollowed"));
    if(nextFollowing){
      createNotification({id:`follow_${state.currentUser.uid}_${targetUid}`,userId:targetUid,actorId:state.currentUser.uid,type:"follow",title:uiText("Nouvel abonné","Mpanaraka vaovao","New follower"),preview:`${state.currentProfile?.fullname||uiSomeone()} ${uiText("vous suit maintenant.","manaraka anao izao.","is now following you.")}`}).catch(err=>console.warn("[post follow notification]",err));
    }
  }catch(err){
    logError("[post follow]",err);
    toast(followErrorMessage(err));
  }finally{
    if(btn)setBusy(btn,false);
    if(nextFollowing!==null){
      document.querySelectorAll(".post-follow-btn[data-follow-uid]").forEach(b=>{ if(b.dataset.followUid!==String(targetUid)) return;
        b.dataset.following=nextFollowing?"1":"0";
        b.textContent=nextFollowing?uiText("Suivi","Manaraka","Following"):uiText("Suivre","Hanaraka","Follow");
      });
      if(btn){
        btn.dataset.following=nextFollowing?"1":"0";
        btn.textContent=nextFollowing?uiText("Suivi","Manaraka","Following"):uiText("Suivre","Hanaraka","Follow");
      }
    }
  }
};

/* Description 3 lignes + Voir plus / Voir moins. Toute carte qui quitte
   le viewport se replie automatiquement. Le titre reste hors du fond image. */
let lyramePostDescObserver=null;
function lyrameEnsurePostDescObserver(){
  if(lyramePostDescObserver||!("IntersectionObserver" in window)) return;
  lyramePostDescObserver=new IntersectionObserver(entries=>{
    entries.forEach(entry=>{
      if(entry.isIntersecting && entry.intersectionRatio>=0.22) return;
      const card=entry.target;
      const body=card.querySelector(".post-body");
      const btn=card.querySelector(".post-description-toggle");
      if(body&&btn&&body.classList.contains("is-expanded")){
        body.classList.remove("is-expanded");
        btn.textContent=uiText("Voir plus","Hijery fanampiny","See more");
      }
    });
  },{threshold:[0,.22,.55]});
}
function lyrameEnhancePostCard(card,post){
  if(!card)return card;
  const follow=card.querySelector(".post-follow-btn");
  if(follow&&post?.authorId) follow.dataset.followUid=String(post.authorId);
  const content=card.querySelector(".post-content");
  const title=content?.querySelector(":scope > .post-title");
  if(post?.background&&content&&title){ content.before(title); title.classList.add("post-title-outside-background"); }
  const body=content?.querySelector(".post-body");
  if(body&&!card.querySelector(".post-description-toggle")){
    body.classList.add("post-description-clamp");
    const toggle=document.createElement("button");
    toggle.type="button"; toggle.className="post-description-toggle";
    toggle.textContent=uiText("Voir plus","Hijery fanampiny","See more");
    toggle.hidden=true;
    toggle.addEventListener("click",e=>{
      e.stopPropagation();
      const expanded=body.classList.toggle("is-expanded");
      toggle.textContent=expanded?uiText("Voir moins","Hijery kely","See less"):uiText("Voir plus","Hijery fanampiny","See more");
    });
    content?.insertAdjacentElement("afterend",toggle);
    requestAnimationFrame(()=>{
      const lh=parseFloat(getComputedStyle(body).lineHeight)||24;
      toggle.hidden=body.scrollHeight<=lh*3+4;
    });
  }
  lyrameEnsurePostDescObserver();
  lyramePostDescObserver?.observe(card);
  return card;
}
const _renderPostCardV37=renderPostCard;
renderPostCard=function(post){ return lyrameEnhancePostCard(_renderPostCardV37(post),post); };

/* Bouton scroll chat : un seul bouton, centré, visible uniquement pendant
   un mouvement réel dans la direction correspondante. */
function bindLyrameDirectionalConversationScroll(){
  const box=document.querySelector("#conv-messages");
  const up=document.querySelector("#conv-jump-up");
  const down=document.querySelector("#conv-jump-down");
  if(!box||!up||!down||box.dataset.v37DirectionalScroll==="1")return;
  box.dataset.v37DirectionalScroll="1";
  let lastTop=box.scrollTop,hideTimer=null;
  const hide=()=>{up.classList.remove("is-visible");down.classList.remove("is-visible");};
  const show=dir=>{
    clearTimeout(hideTimer);hide();
    const atTop=box.scrollTop<=3;
    const atBottom=box.scrollTop+box.clientHeight>=box.scrollHeight-4;
    if(dir==="up"&&!atTop)up.classList.add("is-visible");
    if(dir==="down"&&!atBottom)down.classList.add("is-visible");
    hideTimer=setTimeout(hide,1450);
  };
  box.addEventListener("scroll",()=>{
    const now=box.scrollTop,delta=now-lastTop;
    if(Math.abs(delta)>2)show(delta>0?"down":"up");
    lastTop=now;
    if(now<=3||now+box.clientHeight>=box.scrollHeight-4)hide();
  },{passive:true});
  hide();
}
if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",bindLyrameDirectionalConversationScroll,{once:true});else bindLyrameDirectionalConversationScroll();

/* ---------------- STORIES 15 SECONDES + EDITEUR PHOTO ---------------- */
function lyrameFormatStorySeconds(value){const n=Math.max(0,Math.floor(Number(value)||0));return `${String(Math.floor(n/60)).padStart(2,"0")}:${String(n%60).padStart(2,"0")}`;}
const LYRAME_STORY_COLORS=["#1e88e5","#ffd600","#e53935","#111111","#ffffff","#1faa59"];
const LYRAME_STORY_EMOJIS=["❤️","😍","😂","🔥","✨","🥰","🎉","💯","🌹","👏","😎","💫","😘","🙏","🎵","🌟"];
const LYRAME_STORY_MUSIC=[
  ["Synth 01","https://samplelib.com/mp3/sample-3s.mp3","music"],
  ["Synth 02","https://samplelib.com/mp3/sample-6s.mp3","music"],
  ["Beat 03","https://samplelib.com/mp3/sample-9s.mp3","music"],
  ["Flûte 04","https://samplelib.com/mp3/sample-12s.mp3","music"],
  ["Mélodie 05","https://samplelib.com/mp3/sample-15s.mp3","music"],
  ["Loop 06","https://samplelib.com/mp3/sample-5s.mp3","music"],
  ["Loop 07","https://samplelib.com/mp3/sample-10s.mp3","music"],
  ["Loop 08","https://samplelib.com/mp3/sample-20s.mp3","music"],
  ["Loop 09","https://samplelib.com/mp3/sample-25s.mp3","music"],
  ["Loop 10","https://samplelib.com/mp3/sample-30s.mp3","music"],
  ["Ambiance 11","https://samplelib.com/mp3/sample-35s.mp3","music"],
  ["Ambiance 12","https://samplelib.com/mp3/sample-40s.mp3","music"],
  ["Ambiance 13","https://samplelib.com/mp3/sample-45s.mp3","music"],
  ["Ambiance 14","https://samplelib.com/mp3/sample-50s.mp3","music"],
  ["Ambiance 15","https://samplelib.com/mp3/sample-55s.mp3","music"],
  ["Voix 16","https://samplelib.com/mp3/sample-speech-1m.mp3","voice"],
  ["Voix 17","https://samplelib.com/mp3/sample-speech-5m.mp3","voice"],
  ["Voix 18","https://samplelib.com/mp3/sample-speech-10m.mp3","voice"],
  ["Voix 19","https://samplelib.com/mp3/sample-speech-20m.mp3","voice"],
  ["Voix 20","https://samplelib.com/mp3/sample-speech-30m.mp3","voice"]
].map((x,i)=>({id:`online-${i+1}`,label:x[0],url:x[1],kind:x[2]}));


const lyrameStoryV37={queue:[],index:-1,audio:null,timer:null,editorUrl:"",cards:[],ownerQueues:new Map(),myStories:[],recentPublished:[],requestId:0,userUid:""};
function lyrameStopStoryPlayback(){
  clearTimeout(lyrameStoryV37.timer);lyrameStoryV37.timer=null;
  if(lyrameStoryV37.audio){try{lyrameStoryV37.audio.pause();lyrameStoryV37.audio.currentTime=0;}catch(_){}lyrameStoryV37.audio=null;}
}
function lyrameStoryAudioUrl(url){
  try{const u=new URL(String(url||""),location.href);if(u.protocol!=="https:")return "";if(u.hostname==="samplelib.com"||u.hostname.endsWith(".cloudinary.com")||u.hostname==="res.cloudinary.com")return u.href;return "";}catch(_){return "";}
}
function lyrameStoryDecorationMarkup(dec,{preview=false}={}){
  if(!dec||typeof dec!=="object")return "";
  if(dec.kind==="sticker"&&dec.stickerId){
    return `<div class="story-decoration story-decoration-sticker${preview?" is-preview":""}">${renderCommentStickerMarkup(dec.stickerId,{compact:true})}</div>`;
  }
  if(dec.kind==="photo"&&dec.url){
    const src=safeUrl(dec.url,{allowBlob:preview});
    return src?`<div class="story-decoration story-decoration-photo"><img src="${escapeHtml(src)}" alt=""/></div>`:"";
  }
  if(dec.kind==="badge"){
    const icon=String(dec.icon||"").trim();
    const label=String(dec.text||"").trim().slice(0,40);
    if(!icon&&!label)return "";
    return `<div class="story-decoration story-decoration-badge${preview?" is-preview":""}">${icon?`<span class="story-decoration-icon">${escapeHtml(icon)}</span>`:""}<span>${escapeHtml(label)}</span></div>`;
  }
  return "";
}
function lyrameStoryOverlayMarkup(st){
  const color=LYRAME_STORY_COLORS.includes(String(st?.textOverlay?.color||""))?st.textOverlay.color:"#ffffff";
  const text=String(st?.textOverlay?.text||"").slice(0,180);
  const emojis=Array.isArray(st?.emojis)?st.emojis.slice(0,12):[];
  const decorations=Array.isArray(st?.decorations)?st.decorations.slice(0,24):[];
  const strokes=Array.isArray(st?.doodlePaths)?st.doodlePaths.slice(0,12):[];
  const drawing=strokes.map(s=>{
    const points=(Array.isArray(s.points)?s.points:[]).slice(0,220).map(p=>`${Math.round(Math.max(0,Math.min(1,Number(p?.[0])||0))*1000)},${Math.round(Math.max(0,Math.min(1,Number(p?.[1])||0))*1000)}`).join(' ');
    return points?`<polyline points="${points}" stroke="${escapeHtml(LYRAME_STORY_COLORS.includes(s.color)?s.color:'#ffffff')}" stroke-width="${Math.max(3,Math.min(16,Number(s.width)||6))}" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`:'';
  }).join('');
  return `<div class="story-overlay-layer">${text?`<div class="story-view-text" style="color:${color}">${escapeHtml(text)}</div>`:""}${emojis.length?`<div class="story-view-emojis">${emojis.map(e=>`<span>${escapeHtml(String(e))}</span>`).join("")}</div>`:""}${decorations.length?`<div class="story-view-decorations">${decorations.map(dec=>lyrameStoryDecorationMarkup(dec)).join("")}</div>`:""}</div>${drawing?`<svg class="story-doodle-display" viewBox="0 0 1000 1000" preserveAspectRatio="none" aria-hidden="true">${drawing}</svg>`:""}`;
}
function lyrameStoryOwnerKey(st){
  const id=String(st?.pageId||st?.authorId||"").trim();
  if(!id)return "";
  return `${st?.pageId?"page":"user"}:${id}`;
}
function lyrameStoryTimestamp(st){
  return toDate(st?.createdAt)?.getTime()||Number(st?.createdAtMs||st?.createdAtClientMs||0)||0;
}
function lyrameSortStoryList(list){
  return [...(Array.isArray(list)?list:[])].sort((a,b)=>lyrameStoryTimestamp(b)-lyrameStoryTimestamp(a));
}
function lyrameStoryPrimaryProfile(st){
  return {
    id:String(st?.pageId||st?.authorId||""),
    type:st?.pageId?"page":"user",
    name:String(st?.authorName||st?.pageName||""),
    photoURL:String(st?.authorPhotoURL||st?.pagePhotoURL||"")
  };
}
function lyrameSyncStoryCreateCard(){
  const avatarBox=$("#story-create-avatar"),btn=$("#story-create-btn");
  const meName=state.currentProfile?.fullname||state.currentUser?.displayName||uiText("Moi","Izaho","Me");
  const mePhoto=state.currentProfile?.photoURL||state.currentUser?.photoURL||"";
  if(avatarBox)avatarBox.innerHTML=avatarMarkup(mePhoto,meName);
  const label=btn?.querySelector?.('[data-i18n-dynamic="create-story"]');
  if(label)label.textContent=meName;
  if(btn){
    const count=(lyrameStoryV37.myStories||[]).length;
    btn.classList.toggle("has-story",count>0);
    let badge=btn.querySelector(".story-count-badge");
    if(count>0){
      if(!badge){badge=document.createElement("span");badge.className="story-count-badge";btn.appendChild(badge);}
      badge.textContent=String(count);
    }else if(badge)badge.remove();
    btn.title=count>0?uiText("Touchez la carte pour voir vos stories, ou le + pour en ajouter.","Tsindrio ny karatra hijerena ny stories-nao, na ny + mba hanampiana.","Tap the card to view your stories, or + to add one."):uiText("Ajouter une story","Hanampy story","Add a story");
  }
}
function lyrameOpenStoryQueue(stories,startIndex=0){
  const queue=lyrameSortStoryList(stories);
  if(!queue.length){toast(uiText("Aucune story disponible.","Tsy misy story hita.","No story available."));return;}
  lyrameStoryV37.queue=queue;
  const safeIndex=Math.max(0,Math.min(Number(startIndex)||0,queue.length-1));
  lyrameOpenStoryIndex(safeIndex);
}
async function lyrameFollowedPageIdsForStories(stories){
  const uid=state.currentUser?.uid;if(!uid)return new Set();
  const ids=[...new Set(stories.map(x=>x.pageId).filter(Boolean))].slice(0,30);
  const out=new Set();
  await Promise.all(ids.map(async id=>{try{if((await getDoc(doc(db,"pages",id,"followers",uid))).exists())out.add(id);}catch(_){}}));
  return out;
}
loadStories=async function(){
  const box=$("#stories-list");if(!box||!state.currentUser)return;
  const uid=state.currentUser.uid;
  if(lyrameStoryV37.userUid!==uid){
    lyrameStoryV37.userUid=uid;
    lyrameStoryV37.recentPublished=[];
    lyrameStoryV37.myStories=[];
    lyrameStoryV37.cards=[];
    lyrameStoryV37.ownerQueues=new Map();
  }
  const requestId=++lyrameStoryV37.requestId;
  const col=collection(db,"stories");
  // Requêtes distinctes : la liste générale peut être tronquée ;
  // la requête par auteur garantit que nos stories ne sont pas écartées.
  const [recentResult,mineResult]=await Promise.allSettled([
    getDocs(query(col,orderBy("createdAt","desc"),limit(120))),
    getDocs(query(col,where("authorId","==",uid),limit(80)))
  ]);
  if(requestId!==lyrameStoryV37.requestId||state.currentUser?.uid!==uid)return;
  const byId=new Map();
  for(const result of [recentResult,mineResult]){
    if(result.status==="fulfilled")result.value.docs.forEach(d=>byId.set(d.id,{id:d.id,...d.data()}));
    else console.warn("[stories read]",result.reason);
  }
  // Après addDoc réussi, afficher immédiatement la story dans ce navigateur.
  // Les résultats Firestore, s'ils existent, prennent toujours la priorité.
  (lyrameStoryV37.recentPublished||[]).filter(st=>st.authorId===uid).forEach(st=>{
    if(!byId.has(st.id))byId.set(st.id,st);
  });
  if(recentResult.status==="rejected"&&mineResult.status==="rejected"&&byId.size===0){
    box.innerHTML=`<div class="stories-read-error" role="status">${escapeHtml(uiText("Impossible de charger les stories. Vérifiez votre connexion ou les autorisations Firestore.","Tsy voavaky ny stories. Jereo ny connexion sy ny fahazoan-dàlana Firestore.","Unable to load stories. Check your connection or Firestore permissions."))}</div>`;
    lyrameStoryV37.myStories=[];lyrameSyncStoryCreateCard();
    return;
  }
  const now=Date.now();
  const all=[...byId.values()].filter(st=>{
    const t=lyrameStoryTimestamp(st);
    return t>0 && now-t<24*60*60*1000 && now-t>-(5*60*1000);
  });
  const followedPages=await lyrameFollowedPageIdsForStories(all);
  if(requestId!==lyrameStoryV37.requestId||state.currentUser?.uid!==uid)return;
  const friends=state.friendIds instanceof Set?state.friendIds:new Set(state.friendIds||[]);
  const visible=all.filter(st=>st.authorId===uid||friends.has(st.authorId)||(Array.isArray(st.audienceIds)&&st.audienceIds.includes(uid))||(st.pageId&&followedPages.has(st.pageId)));
  const grouped=new Map();
  visible.forEach(st=>{const key=lyrameStoryOwnerKey(st);if(!key)return;if(!grouped.has(key))grouped.set(key,[]);grouped.get(key).push(st);});
  const cards=[...grouped.entries()].map(([key,stories])=>{
    const ordered=lyrameSortStoryList(stories),head=ordered[0];
    return {key,stories:ordered,head,profile:lyrameStoryPrimaryProfile(head),count:ordered.length};
  }).sort((a,b)=>lyrameStoryTimestamp(b.head)-lyrameStoryTimestamp(a.head));
  lyrameStoryV37.cards=cards;
  lyrameStoryV37.ownerQueues=new Map(cards.map(card=>[card.key,card.stories]));
  lyrameStoryV37.myStories=lyrameStoryV37.ownerQueues.get(`user:${uid}`)||[];
  lyrameSyncStoryCreateCard();
  const fragment=document.createDocumentFragment();
  // Ne pas exclure l'auteur connecté : c'était la raison principale pour laquelle
  // une story publiée n'apparaissait jamais à côté de sa photo de profil.
  cards.forEach(card=>{
    const b=document.createElement("button");b.type="button";
    b.className="story-card story-published-card";
    const cover=safeUrl(card.head.mediaURL);
    const media=cover
      ? card.head.mediaType==="video"
        ? `<video src="${escapeHtml(cover)}" muted playsinline preload="metadata"></video>`
        : `<img src="${escapeHtml(cover)}" alt="" loading="lazy"/>`
      : `<span class="story-published-fallback">${avatarMarkup(card.profile.photoURL,card.profile.name)}</span>`;
    b.innerHTML=`<span class="story-published-media">${media}</span><span class="story-count-badge">${card.count}</span><span class="story-ring">${avatarMarkup(card.profile.photoURL,card.profile.name)}</span><span class="story-owner">${escapeHtml(card.profile.name||"")}</span>${card.head?.musicURL?'<span class="story-music-badge">♫</span>':''}`;
    b.addEventListener("click",()=>lyrameOpenStoryQueue(card.stories,0));
    fragment.appendChild(b);
  });
  box.replaceChildren(fragment);
};

function lyrameEnsureStoryViewerControls(){
  const viewer=$("#story-viewer");if(!viewer)return;
  if(!$("#story-viewer-prev")){
    const prev=document.createElement("button");prev.type="button";prev.id="story-viewer-prev";prev.className="story-viewer-prev";prev.setAttribute("aria-label",uiText("Story précédente","Story teo aloha","Previous story"));prev.textContent="←";prev.addEventListener("click",e=>{e.stopPropagation();if(lyrameStoryV37.index>0)lyrameOpenStoryIndex(lyrameStoryV37.index-1);});viewer.appendChild(prev);
  }
}
function lyrameOpenStoryIndex(index){
  const queue=lyrameStoryV37.queue||[];if(index<0||index>=queue.length){lyrameStopStoryPlayback();hideEl($("#story-viewer"));return;}
  lyrameStopStoryPlayback();lyrameStoryV37.index=index;lyrameEnsureStoryViewerControls();
  const st=queue[index],stage=$("#story-viewer-stage"),bar=$("#story-progress-bar");if(!stage)return;
  const url=safeUrl(st.mediaURL);const mediaMarkup=st.mediaType==="video"?`<video src="${escapeHtml(url)}" autoplay playsinline controls></video>`:`<img src="${escapeHtml(url)}" alt=""/>`;
  stage.innerHTML=`<div class="story-photo-stage">${mediaMarkup}${lyrameStoryOverlayMarkup(st)}<div class="story-view-owner">${avatarMarkup(st.authorPhotoURL,st.authorName)}<span>${escapeHtml(st.authorName||"")}</span></div></div>`;
  showEl($("#story-viewer"));
  const prev=$("#story-viewer-prev");if(prev)prev.classList.toggle("hidden",index<=0);
  const duration=Math.max(6,Math.min(15,Number(st.mediaType==="video"?15:15)||15));
  if(bar){bar.style.transition="none";bar.style.width="0";requestAnimationFrame(()=>{bar.style.transition=`width ${duration}s linear`;bar.style.width="100%";});}
  const audioUrl=lyrameStoryAudioUrl(st.musicURL);
  if(audioUrl){
    const a=new Audio(audioUrl);a.preload="auto";a.loop=String(st.musicSource||"")==="online";lyrameStoryV37.audio=a;
    const start=Math.max(0,Number(st.musicStart)||0);
    const play=()=>{try{a.currentTime=Math.min(start,Math.max(0,(a.duration||start+1)-.1));}catch(_){}a.play().catch(()=>{});};
    if(Number.isFinite(a.duration)&&a.duration>0)play();else a.addEventListener("loadedmetadata",play,{once:true});
  }
  lyrameStoryV37.timer=setTimeout(()=>{if(index+1<queue.length)lyrameOpenStoryIndex(index+1);else{lyrameStopStoryPlayback();hideEl($("#story-viewer"));}},duration*1000);
}
openStory=function(st){
  const key=lyrameStoryOwnerKey(st);
  const queue=(key&&lyrameStoryV37.ownerQueues.get(key))||lyrameStoryV37.queue||[];
  const idx=Math.max(0,queue.findIndex(x=>x.id===st?.id));
  lyrameOpenStoryQueue(queue,idx>=0?idx:0);
};

function lyrameOpenStoryEditor(file){
  if(!state.currentUser||!file)return;
  if(!String(file.type||"").startsWith("image/")){toast(uiText("Choisissez une photo.","Misafidiana sary.","Choose a photo."));return;}
  if(file.size>MAX_IMAGE_BYTES){toast(t("err_file_too_large"));return;}
  if(lyrameStoryV37.editorUrl)revokeUrl(lyrameStoryV37.editorUrl);
  const localUrl=URL.createObjectURL(file);lyrameStoryV37.editorUrl=localUrl;
  const extraUrls=[localUrl];
  const draft={file,previewUrl:localUrl,text:"",color:"#ffffff",emojis:[],decorations:[],doodlePaths:[],music:null,musicStart:0,musicDuration:15};
  const quickEmojis=["❤️","🙏","😎","💖","😂"];
  const modal=openDynamicModal(uiText("Modifier la story","Hanova story","Edit story"));
  modal.overlay.classList.add("story-editor-overlay");modal.panel.classList.add("story-editor-panel");modal.body.classList.add("story-editor-modal");
  const titleEl=modal.panel.querySelector("h3");if(titleEl){
    titleEl.classList.add("story-editor-title");
    const exit=document.createElement('button');exit.type='button';exit.className='story-editor-exit';exit.textContent='×';
    exit.setAttribute('aria-label',uiText('Fermer','Hidio','Close'));exit.addEventListener('click',()=>modal.close());
    titleEl.appendChild(exit);
  }
  Object.assign(modal.overlay.style,{background:"rgba(0,0,0,.96)",padding:"0",alignItems:"stretch",justifyContent:"stretch"});
  Object.assign(modal.panel.style,{width:"100vw",maxWidth:"100vw",height:"100dvh",maxHeight:"100dvh",borderRadius:"0",padding:"12px",display:"flex",flexDirection:"column",overflow:"hidden"});
  Object.assign(modal.body.style,{flex:"1",minHeight:"0",overflowY:"auto"});
  modal.onClose=()=>{stopStoryMusicPreview();extraUrls.forEach(u=>{try{revokeUrl(u);}catch(_){}});lyrameStoryV37.editorUrl="";};

  function askStoryText(title,placeholder,initial,done){
    closeMoreSheet();
    // Texte et mentions sont édités DANS l'écran story, sans seconde popup.
    const panel=document.createElement("div");panel.className="story-inline-input-sheet";
    panel.innerHTML=`<div class="story-inline-input-head"><strong>${escapeHtml(title||"")}</strong><button type="button" class="story-inline-input-close" aria-label="${escapeHtml(uiText("Fermer","Hidio","Close"))}">×</button></div>`;
    const input=document.createElement("input");input.type="text";input.maxLength=40;input.value=initial||"";input.placeholder=placeholder||"";input.className="story-inline-input";
    const row=document.createElement("div");row.className="story-inline-input-actions";
    const cancel=styledButton(uiText("Annuler","Ajanona","Cancel"),"ghost");
    const ok=styledButton(uiText("Valider","Hamarino","Apply"));
    const dismiss=()=>panel.remove();
    cancel.addEventListener("click",dismiss);panel.querySelector('.story-inline-input-close').addEventListener('click',dismiss);
    const apply=()=>{const val=String(input.value||"").trim();if(val&&typeof done==="function")done(val);dismiss();};
    ok.addEventListener("click",apply);input.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();apply();}});
    row.append(cancel,ok);panel.append(input,row);modal.panel.appendChild(panel);setTimeout(()=>input.focus(),20);
  }
  function addDecoration(dec){
    if(!dec)return;
    draft.decorations=(draft.decorations||[]).concat([dec]).slice(0,24);
    render();
  }
  function openMoreSheet(){sheet.classList.remove("hidden");sheetBackdrop.classList.remove("hidden");}
  function closeMoreSheet(){sheet.classList.add("hidden");sheetBackdrop.classList.add("hidden");}
  const shell=document.createElement("div");shell.className="story-editor-shell";
  const stageWrap=document.createElement("div");stageWrap.className="story-editor-canvas-wrap";
  const stage=document.createElement("div");stage.className="story-editor-stage story-editor-stage-rich";stage.innerHTML=`<img src="${escapeHtml(localUrl)}" alt=""><div class="story-editor-live"><div class="story-editor-text"></div><div class="story-editor-emojis"></div><div class="story-editor-decorations"></div></div><svg class="story-doodle-preview" viewBox="0 0 1000 1000" preserveAspectRatio="none" aria-hidden="true"></svg><div class="story-doodle-controls hidden"><button type="button" data-doodle-undo>↶</button><button type="button" data-doodle-done>✓</button></div>`;
  const stageImg=stage.querySelector("img");
  const sideTools=document.createElement("div");sideTools.className="story-side-tools";
  const makeSideTool=(icon,label,handler)=>{const b=document.createElement("button");b.type="button";b.className="story-side-tool";b.innerHTML=`<span class="story-side-tool-icon">${icon}</span><span class="story-side-tool-label">${escapeHtml(label)}</span>`;b.addEventListener("click",handler);return b;};
  const textPanel=document.createElement("div");textPanel.className="story-tool-panel hidden";const ti=document.createElement("textarea");ti.rows=2;ti.maxLength=180;ti.placeholder=uiText("Votre texte…","Soraty eto…","Your text…");ti.className="story-text-input";ti.addEventListener("input",()=>{draft.text=ti.value;render();});const colors=document.createElement("div");colors.className="story-color-row";LYRAME_STORY_COLORS.forEach(c=>{const b=document.createElement("button");b.type="button";b.className="story-color-dot";b.style.background=c;b.setAttribute("aria-label",c);b.addEventListener("click",()=>{draft.color=c;colors.querySelectorAll("button").forEach(x=>x.classList.toggle("active",x===b));render();});colors.appendChild(b);});textPanel.append(ti,colors);
  const emojiPanel=document.createElement("div");emojiPanel.className="story-tool-panel story-emoji-grid hidden";LYRAME_STORY_EMOJIS.forEach(e=>{const b=document.createElement("button");b.type="button";b.textContent=e;b.addEventListener("click",()=>{if(draft.emojis.length<12)draft.emojis.push(e);render();});emojiPanel.appendChild(b);});const clearEmoji=styledButton(uiText("Effacer les emojis","Hamafa emoji","Clear emojis"),"ghost");clearEmoji.addEventListener("click",()=>{draft.emojis=[];render();});emojiPanel.appendChild(clearEmoji);
  // V63 : écouter le passage sélectionné AVANT d'envoyer la story.
  // Un seul élément audio par éditeur : arrêt sur changement, fermeture ou publication.
  const musicPanel=document.createElement("div");
  musicPanel.className="story-tool-panel story-music-panel hidden";
  const localLabel=document.createElement("label");localLabel.className="story-local-music";
  localLabel.innerHTML=`<span>${escapeHtml(uiText("Musique du téléphone","Hira ao amin'ny finday","Music from phone"))}</span>`;
  const localInput=document.createElement("input");localInput.type="file";localInput.accept="audio/*,.mp3,.m4a,.aac,.wav,.ogg,.webm";
  localLabel.appendChild(localInput);
  const trim=document.createElement("div");trim.className="story-trim hidden";
  trim.innerHTML=`<label>${escapeHtml(uiText("Début du passage de 15 s","Fiandohan'ny ampahany 15 segondra","Start of the 15-second clip"))}<input type="range" min="0" max="0" value="0" step="1"></label><span>00:00 → 00:15</span>`;
  const trimRange=trim.querySelector("input"),trimText=trim.querySelector("span");
  const onlineTitle=document.createElement("strong");onlineTitle.textContent=uiText("Sons disponibles en ligne","Hira azo isafidianana an-tserasera","Online sound choices");
  const catalog=document.createElement("div");catalog.className="story-music-catalog";
  const previewBox=document.createElement("div");previewBox.className="story-music-preview";
  const previewTitle=document.createElement("div");previewTitle.className="story-music-preview-title";
  previewTitle.textContent=uiText("Choisissez une musique pour l'écouter.","Misafidiana hira dia henoy alohan'ny hamoahana azy.","Choose a track and listen before sharing.");
  const previewRow=document.createElement("div");previewRow.className="story-music-preview-row";
  const previewButton=document.createElement("button");previewButton.type="button";previewButton.className="story-music-preview-play";
  const previewClock=document.createElement("span");previewClock.className="story-music-preview-clock";previewClock.textContent="00:00 / 00:15";
  const previewStatus=document.createElement("small");previewStatus.className="story-music-preview-status";
  previewStatus.setAttribute("aria-live","polite");
  previewRow.append(previewButton,previewClock);
  previewBox.append(previewTitle,previewRow,previewStatus);
  const previewAudio=new Audio();previewAudio.preload="metadata";
  let previewSrc="",previewElapsed=0,previewStartTime=0,previewInterval=null,previewGeneration=0,localPickToken=0;
  const previewButtonText=(playing=false)=>playing?uiText("⏸ Pause","⏸ Atsaharo","⏸ Pause"):uiText("▶ Écouter 15 s","▶ Henoy 15 seg","▶ Listen 15 s");
  const previewHint=()=>uiText("Appuyez pour écouter avant de publier.","Tsindrio raha hihaino alohan'ny hamoahana.","Tap to listen before publishing.");
  function updatePreviewClock(seconds=0){
    const max=Math.max(1,Number(draft.musicDuration)||15);
    previewClock.textContent=`${lyrameFormatStorySeconds(Math.min(max,seconds))} / ${lyrameFormatStorySeconds(max)}`;
  }
  function previewSeconds(){
    return previewElapsed+(previewStartTime&&!previewAudio.paused?(performance.now()-previewStartTime)/1000:0);
  }
  function stopStoryMusicPreview(reset=true){
    ++previewGeneration;
    try{previewAudio.pause();}catch(_){}
    if(previewInterval){clearInterval(previewInterval);previewInterval=null;}
    previewStartTime=0;
    if(reset){previewElapsed=0;updatePreviewClock();}
    previewButton.textContent=previewButtonText();
  }
  function resetStoryMusicPreview(){
    stopStoryMusicPreview();
    previewSrc="";
    previewAudio.removeAttribute("src");
    previewAudio.load();
    previewTitle.textContent=draft.music?.label||uiText("Aucune musique sélectionnée","Tsy misy hira voafidy","No track selected");
    previewButton.disabled=!draft.music;
    previewStatus.textContent=draft.music?previewHint():"";
    updatePreviewClock();
  }
  function tickMusicPreview(){
    const seconds=previewSeconds();updatePreviewClock(seconds);
    const max=Math.max(1,Number(draft.musicDuration)||15);
    // Empêcher que l'extrait local continue après 15 s, même si l'audio ne se termine pas.
    const localEnd=draft.music?.source==="local"&&Number.isFinite(previewAudio.duration)
      && previewAudio.duration>0&&previewAudio.currentTime>=(Number(draft.musicStart)||0)+max-0.05;
    if(seconds>=max||localEnd){
      stopStoryMusicPreview();
      previewStatus.textContent=uiText("Extrait terminé. Vous pouvez le réécouter.","Vita ny fihainoana. Afaka averinao.","Preview finished. You can play it again.");
    }
  }
  previewAudio.addEventListener("ended",()=>{
    stopStoryMusicPreview();
    previewStatus.textContent=uiText("Fin de la musique.","Tapitra ilay hira.","End of track.");
  });
  previewAudio.addEventListener("error",()=>{
    if(!draft.music||!previewSrc)return;
    stopStoryMusicPreview();
    previewStatus.textContent=uiText("Son indisponible. Vérifiez la connexion ou choisissez un autre titre.","Tsy azo alefa ilay hira. Jereo ny internet na mifidiana hira hafa.","Audio unavailable. Check connection or select another track.");
  });
  previewAudio.addEventListener("loadedmetadata",()=>{
    if(!previewSrc||!draft.music)return;
    if(previewElapsed===0){
      const start=Math.max(0,Number(draft.musicStart)||0);
      try{previewAudio.currentTime=Math.min(start,Math.max(0,(previewAudio.duration||start+1)-0.1));}catch(_){}
    }
  });
  previewButton.addEventListener("click",()=>{
    if(!draft.music)return;
    if(!previewAudio.paused){
      previewElapsed=previewSeconds();
      stopStoryMusicPreview(false);
      previewStatus.textContent=uiText("En pause. Appuyez pour reprendre.","Miato. Tsindrio raha hanohy.","Paused. Tap to resume.");
      return;
    }
    const src=draft.music.source==="local"?draft.music.localUrl:draft.music.url;
    if(!src){previewStatus.textContent=uiText("Sélectionnez une musique.","Misafidiana hira aloha.","Select a track first.");return;}
    const fresh=previewSrc!==src;
    if(fresh){
      previewSrc=src;previewElapsed=0;
      previewAudio.src=src;previewAudio.loop=draft.music.source==="online";
      try{previewAudio.currentTime=Math.max(0,Number(draft.musicStart)||0);}catch(_){}
    }else if(previewElapsed===0){
      try{previewAudio.currentTime=Math.max(0,Number(draft.musicStart)||0);}catch(_){}
    }
    const request=++previewGeneration;
    previewStartTime=performance.now();
    previewButton.textContent=previewButtonText(true);
    previewStatus.textContent=uiText("Chargement du son…","Miandry ny hira…","Loading audio…");
    if(previewInterval)clearInterval(previewInterval);
    previewInterval=setInterval(tickMusicPreview,120);
    // play() est appelé directement pendant le clic pour respecter l'activation Android.
    const started=previewAudio.play();
    Promise.resolve(started).then(()=>{
      if(request!==previewGeneration)return;
      previewStartTime=performance.now();
      previewStatus.textContent=uiText("Vous écoutez l'extrait avant publication.","Mihaino ilay hira alohan'ny hamoahana ianao.","Listening to the preview before publishing.");
    }).catch(()=>{
      if(request!==previewGeneration)return;
      stopStoryMusicPreview();
      previewStatus.textContent=uiText("Lecture impossible. Réessayez ou choisissez une autre musique.","Tsy mandeha ilay hira. Andramo indray na mifidiana hafa.","Can't play audio. Retry or choose another track.");
    });
  });
  localInput.addEventListener("change",()=>{
    const f=localInput.files?.[0];if(!f)return;
    const isAudio=String(f.type||"").startsWith("audio/")||/\.(mp3|m4a|aac|wav|ogg|oga|webm)$/i.test(f.name);
    if(!isAudio){toast(t("err_file_type"));localInput.value="";return;}
    if(f.size>25*1024*1024){toast(uiText("Audio trop volumineux (25 Mo max).","Lehibe loatra ny audio (25 Mo max).","Audio too large (25 MB max)."));localInput.value="";return;}
    const token=++localPickToken;
    const u=URL.createObjectURL(f);extraUrls.push(u);
    const a=new Audio();a.preload="metadata";
    // Sélection visible dès le choix du fichier ; le bouton marche même sans métadonnées.
    draft.music={source:"local",file:f,label:f.name,localUrl:u};
    draft.musicStart=0;draft.musicDuration=15;trimRange.value="0";trimRange.max="0";
    trim.classList.remove("hidden");trimText.textContent="00:00 → 00:15";
    catalog.querySelectorAll("button").forEach(x=>x.classList.remove("active"));
    resetStoryMusicPreview();
    a.addEventListener("loadedmetadata",()=>{
      if(token!==localPickToken)return;
      const d=Number(a.duration);
      if(!Number.isFinite(d)||d<=0)return;
      trimRange.max=String(Math.max(0,Math.floor(d-15)));
      draft.musicDuration=Math.min(15,d);
      trimText.textContent=`00:00 → ${lyrameFormatStorySeconds(draft.musicDuration)}`;
      updatePreviewClock();
    },{once:true});
    a.addEventListener("error",()=>{
      if(token!==localPickToken)return;
      previewStatus.textContent=uiText("Fichier audio non pris en charge.","Tsy tohanan'ny finday ilay rakitra audio.","This audio format is not supported.");
    },{once:true});
    a.src=u;
  });
  trimRange.addEventListener("input",()=>{
    draft.musicStart=Number(trimRange.value)||0;
    trimText.textContent=`${lyrameFormatStorySeconds(draft.musicStart)} → ${lyrameFormatStorySeconds(draft.musicStart+Math.max(1,draft.musicDuration||15))}`;
    resetStoryMusicPreview();
  });
  LYRAME_STORY_MUSIC.forEach(track=>{
    const b=document.createElement("button");b.type="button";b.className="story-music-choice";
    b.innerHTML=`<span>${track.kind==="voice"?"🎤":"🎵"}</span><small>${escapeHtml(track.label)}</small>`;
    b.addEventListener("click",()=>{
      ++localPickToken;
      draft.music={source:"online",url:track.url,label:track.label};draft.musicStart=0;draft.musicDuration=15;
      catalog.querySelectorAll("button").forEach(x=>x.classList.toggle("active",x===b));
      trim.classList.add("hidden");localInput.value="";
      resetStoryMusicPreview();
      // L'utilisateur peut immédiatement utiliser ▶ Henoy 15 seg, sans publier.
    });
    catalog.appendChild(b);
  });
  const noMusic=styledButton(uiText("Sans musique","Tsy misy hira","No music"),"ghost");
  noMusic.addEventListener("click",()=>{
    ++localPickToken;draft.music=null;draft.musicStart=0;draft.musicDuration=15;
    trim.classList.add("hidden");catalog.querySelectorAll("button").forEach(x=>x.classList.remove("active"));
    localInput.value="";resetStoryMusicPreview();
  });
  previewButton.disabled=true;previewButton.textContent=previewButtonText();
  musicPanel.append(localLabel,trim,previewBox,onlineTitle,catalog,noMusic);
  const panels=document.createElement("div");panels.className="story-editor-panels hidden";
  const panelClose=document.createElement('button');panelClose.type='button';panelClose.className='story-panel-close';panelClose.textContent=uiText('Fermer','Hidio','Close');
  panelClose.addEventListener('click',()=>{stopStoryMusicPreview();panels.classList.add('hidden');});
  panels.append(panelClose,textPanel,emojiPanel,musicPanel);
  const showPanel=panel=>{if(panel!==musicPanel)stopStoryMusicPreview();[textPanel,emojiPanel,musicPanel].forEach(p=>p.classList.toggle("hidden",p!==panel));panels.classList.toggle('hidden',!panel);if(panel)closeMoreSheet();};

  const replaceInput=document.createElement("input");replaceInput.type="file";replaceInput.accept="image/*";replaceInput.hidden=true;replaceInput.addEventListener("change",async()=>{const next=replaceInput.files?.[0];replaceInput.value="";if(!next)return;if(!String(next.type||"").startsWith("image/")){toast(uiText("Choisissez une photo.","Misafidiana sary.","Choose a photo."));return;}if(next.size>MAX_IMAGE_BYTES){toast(t("err_file_too_large"));return;}const nextUrl=URL.createObjectURL(next);extraUrls.push(nextUrl);draft.file=next;draft.previewUrl=nextUrl;if(stageImg)stageImg.src=nextUrl;render();});

  // Écriture manuscrite sur story : tracés conservés dans Firestore.
  const drawSvg=stage.querySelector('.story-doodle-preview');
  const drawControls=stage.querySelector('.story-doodle-controls');
  let drawing=false,activeStroke=null;
  function renderDoodles(){
    const strokes=(draft.doodlePaths||[]).map(s=>{
      const pts=(s.points||[]).map(v=>`${Math.round(v[0]*1000)},${Math.round(v[1]*1000)}`).join(' ');
      return `<polyline points="${pts}" fill="none" stroke="${escapeHtml(s.color)}" stroke-width="${s.width}" stroke-linecap="round" stroke-linejoin="round"/>`;
    }).join('');
    drawSvg.innerHTML=strokes;
  }
  function enableDoodle(){
    drawing=true;stage.classList.add('story-is-drawing');drawControls.classList.remove('hidden');closeMoreSheet();showPanel(null);
  }
  function disableDoodle(){drawing=false;activeStroke=null;stage.classList.remove('story-is-drawing');drawControls.classList.add('hidden');}
  function doodlePoint(e){const rect=drawSvg.getBoundingClientRect();return [Math.round(Math.max(0,Math.min(1,(e.clientX-rect.left)/rect.width))*1000)/1000,Math.round(Math.max(0,Math.min(1,(e.clientY-rect.top)/rect.height))*1000)/1000];}
  drawSvg.addEventListener('pointerdown',e=>{
    if(!drawing)return;e.preventDefault();e.stopPropagation();if(draft.doodlePaths.length>=12){toast(uiText('Maximum 12 dessins.','Sary tanana 12 ihany.','Maximum 12 drawings.'));return;}
    activeStroke={color:draft.color,width:6,points:[doodlePoint(e)]};draft.doodlePaths.push(activeStroke);drawSvg.setPointerCapture(e.pointerId);renderDoodles();
  });
  drawSvg.addEventListener('pointermove',e=>{
    if(!drawing||!activeStroke)return;e.preventDefault();e.stopPropagation();if(activeStroke.points.length<220){activeStroke.points.push(doodlePoint(e));renderDoodles();}
  });
  const endDoodle=()=>{activeStroke=null;};drawSvg.addEventListener('pointerup',endDoodle);drawSvg.addEventListener('pointercancel',endDoodle);
  drawControls.querySelector('[data-doodle-undo]').addEventListener('click',()=>{draft.doodlePaths.pop();renderDoodles();});
  drawControls.querySelector('[data-doodle-done]').addEventListener('click',disableDoodle);
  // Une photo ajoutée dans "Sary" est un sticker indépendant de la photo de fond.
  const photoStickerInput=document.createElement('input');photoStickerInput.type='file';photoStickerInput.accept='image/*';photoStickerInput.hidden=true;
  photoStickerInput.addEventListener('change',async()=>{const f=photoStickerInput.files?.[0];photoStickerInput.value='';if(!f)return;const valid=await validateMedia(f,'image');if(!valid.ok){toast(valid.msg);return;}const url=URL.createObjectURL(f);extraUrls.push(url);addDecoration({kind:'photo',url,file:f});closeMoreSheet();});
  stageWrap.appendChild(photoStickerInput);
  sideTools.append(
    makeSideTool("🎟️",uiText("Stickers","Petatsary","Stickers"),()=>openMoreSheet()),
    makeSideTool("Aa",uiText("Texte","Lahatsoratra","Text"),()=>showPanel(textPanel)),
    makeSideTool("🎵",uiText("Musique","Mozika","Music"),()=>showPanel(musicPanel)),
    makeSideTool("@",uiText("Mention","Manonona","Mention"),()=>askStoryText(uiText("Ajouter une mention","Manampy fanononana","Add mention"),uiText("Nom ou pseudo","Anarana na pseudo","Name or username"),"",val=>addDecoration({kind:"badge",icon:"@",text:val.startsWith("@")?val:`@${val}`}))),
    makeSideTool("✨",uiText("Étiquette","Etikety","Label"),()=>askStoryText(uiText("Ajouter une étiquette","Manampy etikety","Add label"),uiText("Ex: Bonne humeur","Ohatra: Tsiky","Example: Good vibes"),"",val=>addDecoration({kind:"badge",icon:"✨",text:val}))),
    makeSideTool("〰",uiText("Dessiner","Doodle","Draw"),enableDoodle)
  );
  stageWrap.append(stage,sideTools,replaceInput);

  const quickBar=document.createElement("div");quickBar.className="story-quick-bar";
  const quickLeft=document.createElement("div");quickLeft.className="story-quick-emojis";
  quickEmojis.forEach(em=>{const b=document.createElement("button");b.type="button";b.className="story-quick-emoji";b.textContent=em;b.addEventListener("click",()=>{if(draft.emojis.length<12)draft.emojis.push(em);render();});quickLeft.appendChild(b);});
  const moreBtn=document.createElement("button");moreBtn.type="button";moreBtn.className="story-more-trigger";moreBtn.textContent=uiText("Voir plus","Bebe kokoa","See more");moreBtn.addEventListener("click",openMoreSheet);
  quickBar.append(quickLeft,moreBtn);

  const sheetBackdrop=document.createElement("button");sheetBackdrop.type="button";sheetBackdrop.className="story-more-sheet-backdrop hidden";sheetBackdrop.addEventListener("click",closeMoreSheet);
  const sheet=document.createElement("div");sheet.className="story-more-sheet hidden";
  const now=new Date();
  const timeText=now.toLocaleTimeString(state.lang==="fr"?"fr-FR":state.lang==="en"?"en-US":"mg-MG",{hour:"2-digit",minute:"2-digit"});
  sheet.innerHTML=`<div class="story-more-handle"></div><div class="story-more-head"><strong>${escapeHtml(uiText("Ajouter un sticker","Manampy petatsary iray","Add a sticker"))}</strong><button type="button" class="story-more-close">${escapeHtml(uiText("Fermer","Manakatona","Close"))}</button></div><div class="story-more-chips"></div><div class="story-more-stickers"></div><div class="story-more-emoji-title">${escapeHtml(uiText("Emojis","Emojis","Emojis"))}</div><div class="story-more-emojis"></div>`;
  sheet.querySelector(".story-more-close")?.addEventListener("click",closeMoreSheet);
  const chips=sheet.querySelector(".story-more-chips");
  const addChip=(icon,label,handler)=>{const b=document.createElement("button");b.type="button";b.className="story-more-chip";b.innerHTML=`<span>${icon}</span><b>${escapeHtml(label)}</b>`;b.addEventListener("click",()=>{handler?.();});chips.appendChild(b);};
  addChip("📍",uiText("Lieu","Toerana","Location"),()=>askStoryText(uiText("Ajouter un lieu","Manampy toerana","Add location"),uiText("Nom du lieu","Anaran'ny toerana","Location name"),"",val=>{addDecoration({kind:"badge",icon:"📍",text:val});closeMoreSheet();}));
  addChip("🎵",uiText("Musique","Mozika","Music"),()=>{closeMoreSheet();showPanel(musicPanel);});
  addChip("@",uiText("Mention","Manondro","Mention"),()=>askStoryText(uiText("Ajouter une mention","Manampy fanononana","Add mention"),uiText("Nom ou pseudo","Anarana na pseudo","Name or username"),"",val=>{addDecoration({kind:"badge",icon:"@",text:val.startsWith("@")?val:`@${val}`});closeMoreSheet();}));
  addChip("🕒",timeText,()=>{addDecoration({kind:"badge",icon:"🕒",text:timeText});closeMoreSheet();});
  addChip("🖼️",uiText("Photo","Sary","Photo"),()=>{closeMoreSheet();photoStickerInput.click();});
  const stickerGrid=sheet.querySelector(".story-more-stickers");
  COMMENT_STICKERS.slice(0,24).forEach(sticker=>{const b=document.createElement("button");b.type="button";b.className="story-more-sticker";b.innerHTML=renderCommentStickerMarkup(sticker.id,{compact:true});b.addEventListener("click",()=>{addDecoration({kind:"sticker",stickerId:sticker.id});closeMoreSheet();});stickerGrid.appendChild(b);});
  const emojiGrid=sheet.querySelector(".story-more-emojis");
  EMOJIS.slice(0,48).forEach(em=>{const b=document.createElement("button");b.type="button";b.className="story-more-emoji";b.textContent=em;b.addEventListener("click",()=>{if(draft.emojis.length<12)draft.emojis.push(em);render();});emojiGrid.appendChild(b);});

  const actionBar=document.createElement("div");actionBar.className="story-editor-actions";
  const clearDecorBtn=styledButton(uiText("Effacer les ajouts","Hamafa ireo fanampiny","Clear extras"),"ghost");clearDecorBtn.addEventListener("click",()=>{draft.emojis=[];draft.decorations=[];render();});
  const publish=styledButton(uiText("Publier la story","Hizara izao","Share now"));publish.classList.add("story-publish-btn");publish.addEventListener("click",async()=>{if(publish.disabled)return;stopStoryMusicPreview();setBusy(publish,true,uiText("Publication…","Mamoaka…","Publishing…"));try{const up=await uploadMedia(draft.file,{folder:`lyrame/stories/${state.currentUser.uid}`,resourceType:"image"});let musicURL="",musicPublicId="",musicSource="";if(draft.music?.source==="online"){musicURL=draft.music.url;musicSource="online";}else if(draft.music?.source==="local"&&draft.music.file){const mup=await uploadMedia(draft.music.file,{folder:`lyrame/stories/${state.currentUser.uid}/music`,resourceType:"video"});musicURL=mup.url;musicPublicId=mup.publicId;musicSource="local";}const decorations=[];for(const item of draft.decorations.slice(0,24)){
      if(item.kind==='photo'&&item.file){const checked=await validateMedia(item.file,'image');if(!checked.ok)throw new Error(checked.msg);const media=await uploadMedia(item.file,{folder:`lyrame/stories/${state.currentUser.uid}/stickers`,resourceType:'image'});decorations.push({kind:'photo',url:media.url});}
      else if(item.kind==='sticker')decorations.push({kind:'sticker',stickerId:item.stickerId});
      else if(item.kind==='badge')decorations.push({kind:'badge',icon:item.icon,text:item.text});
    }
    const p=state.currentProfile||{};const audienceIds=[...new Set([state.currentUser.uid,...Array.from(state.friendIds||[])])];const createdAtMs=Date.now();const storyData={authorId:state.currentUser.uid,authorName:p.fullname||state.currentUser.displayName||"",authorPhotoURL:p.photoURL||"",mediaURL:up.url,mediaPublicId:up.publicId,mediaType:"image",storyVersion:3,textOverlay:{text:draft.text.trim().slice(0,180),color:draft.color,bold:true,align:"center"},emojis:draft.emojis.slice(0,12),decorations,doodlePaths:draft.doodlePaths.slice(0,12),musicURL,musicPublicId,musicSource,musicLabel:draft.music?.label||"",musicStart:Number(draft.musicStart)||0,musicDuration:15,audienceIds,createdAtMs,createdAt:serverTimestamp()};const savedRef=await addDoc(collection(db,"stories"),storyData);lyrameStoryV37.recentPublished=[{...storyData,id:savedRef.id,createdAtMs,createdAt:new Date(createdAtMs)},...(lyrameStoryV37.recentPublished||[])].filter((v,i,arr)=>arr.findIndex(x=>x.id===v.id)===i).slice(0,25);modal.close();await loadStories();toast(uiText("Story publiée.","Navoaka ny story.","Story published."));}catch(err){logError("[story publish v55]",err);toast(t("err_generic"));}finally{setBusy(publish,false);}});
  actionBar.append(clearDecorBtn,publish);

  function render(){
    const tx=stage.querySelector(".story-editor-text"),em=stage.querySelector(".story-editor-emojis"),deco=stage.querySelector(".story-editor-decorations");
    if(tx){tx.textContent=draft.text;tx.style.color=draft.color;tx.hidden=!draft.text;}
    if(em){em.innerHTML=draft.emojis.map(e=>`<span>${escapeHtml(e)}</span>`).join("");em.hidden=!draft.emojis.length;}
    if(deco){deco.innerHTML=draft.decorations.map(item=>lyrameStoryDecorationMarkup(item,{preview:true})).join("");deco.hidden=!draft.decorations.length;}
  }
  shell.append(stageWrap,quickBar,sheetBackdrop,sheet,panels,actionBar);
  modal.body.append(shell);render();
}
createStory=async function(file){lyrameOpenStoryEditor(file);};


/* Fermeture viewer = arrêt immédiat du son. */
document.addEventListener("click",e=>{if(e.target.closest?.("#story-viewer-close")){lyrameStopStoryPlayback();hideEl($("#story-viewer"));}},true);


/* LYRAME 37 — aucune musique story lorsque l'app n'est plus visible. */
document.addEventListener("visibilitychange",()=>{if(document.hidden)lyrameStopStoryPlayback();});

/* ============================================================
   LYRAME 38 — PETITS GARDE-FOUS UI
   ============================================================ */

/* Une seule description de publication peut rester développée à la fois.
   En ouvrant une autre publication, les précédentes se replient sans
   obliger l'utilisateur à appuyer sur « Voir moins ». */
function lyrameCollapseOtherExpandedDescriptions(currentCard){
  document.querySelectorAll('.post-card').forEach(card=>{
    if(card===currentCard)return;
    const body=card.querySelector('.post-body.post-description-clamp.is-expanded');
    const btn=card.querySelector('.post-description-toggle');
    if(body){
      body.classList.remove('is-expanded');
      if(btn)btn.textContent=uiText('Voir plus','Hijery fanampiny','See more');
    }
  });
}

document.addEventListener('click',e=>{
  const btn=e.target.closest?.('.post-description-toggle');
  if(!btn)return;
  const card=btn.closest('.post-card');
  if(card)lyrameCollapseOtherExpandedDescriptions(card);
},true);

/* Quand un autre post devient réellement le post regardé, replier les
   descriptions ouvertes des autres cartes, même si elles sont encore
   partiellement visibles. */
if('IntersectionObserver' in window){
  const lyrameV38FocusObserver=new IntersectionObserver(entries=>{
    const focused=entries
      .filter(x=>x.isIntersecting&&x.intersectionRatio>=0.55)
      .sort((a,b)=>b.intersectionRatio-a.intersectionRatio)[0];
    if(focused?.target)lyrameCollapseOtherExpandedDescriptions(focused.target);
  },{threshold:[0.55]});
  const observeV38Posts=()=>document.querySelectorAll('.post-card').forEach(c=>lyrameV38FocusObserver.observe(c));
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>setTimeout(observeV38Posts,100),{once:true});
  else setTimeout(observeV38Posts,100);
  const feedRoot=document.querySelector('#feed-list');
  if(feedRoot&&'MutationObserver' in window)new MutationObserver(observeV38Posts).observe(feedRoot,{childList:true});
}


/* ================================================================
   LYRAME WEB V41 — PUBLICATIONS ET GALERIE (12/10/2026)
   Référence : écran de publication fourni par l'utilisateur.
   Toutes les interactions ci-dessous utilisent le vrai post Firebase.
   Les anciennes publications, conversations et fonctions restent intactes.
   ================================================================ */
function lyrV41PhotoItems(post) {
  if (Array.isArray(post?.mediaItems) && post.mediaItems.length)
    return post.mediaItems.filter(m => safeUrl(m?.url)).map(m => ({ url: m.url, type: m.type || "image", ratio: m.ratio || "original" }));
  if (post?.mediaType === "image" && safeUrl(post.mediaURL))
    return [{ url: post.mediaURL, type: "image", ratio: post.imageRatio || "original" }];
  return [];
}

function lyrV41ToastError(err, label) {
  console.warn('[LYRAME V41]', label, err);
  toast(uiText("Action indisponible. Réessayez.", "Tsy mandeha aloha io. Andramo indray.", "Action unavailable. Try again."));
}

async function lyrV41CopyText(value) {
  if (!value) return false;
  try {
    if (navigator.clipboard?.writeText) await navigator.clipboard.writeText(value);
    else {
      const ta=document.createElement('textarea');
      ta.value=value;ta.style.cssText='position:fixed;left:-10000px;top:0';document.body.appendChild(ta);
      ta.select();const ok=document.execCommand('copy');ta.remove();if(!ok)throw new Error('COPY_BLOCKED');
    }
    toast(uiText("Lien copié.", "Voakopia ny rohy.", "Link copied."));
    return true;
  } catch(err) { lyrV41ToastError(err, 'copy'); return false; }
}

/** Télécharge seulement quand le serveur média autorise un fetch CORS.
    Sinon, ouvre un lien réellement utilisable, sans annoncer un faux succès. */
async function lyrV41DownloadPhoto(item,index) {
  const url=safeUrl(item?.url);
  if (!url) { toast(uiText("Photo indisponible.", "Tsy hita ny sary.", "Photo unavailable."));return; }
  try {
    const response=await fetch(url,{mode:'cors',credentials:'omit'});
    if (!response.ok || response.type==='opaque') throw new Error('PHOTO_DOWNLOAD_HTTP_'+response.status);
    const blob=await response.blob();
    if (!blob || !blob.size) throw new Error('EMPTY_MEDIA');
    const mime=blob.type||'image/jpeg';
    const ext=mime.includes('png')?'png':mime.includes('webp')?'webp':mime.includes('gif')?'gif':mime.includes('avif')?'avif':mime.startsWith('video/')?'mp4':'jpg';
    const objectUrl=URL.createObjectURL(blob);
    const anchor=document.createElement('a');
    anchor.href=objectUrl;anchor.download=`LYRAME-photo-${index+1}.${ext}`;anchor.style.display='none';
    document.body.appendChild(anchor);anchor.click();anchor.remove();
    setTimeout(()=>URL.revokeObjectURL(objectUrl),60000);
    toast(uiText("Téléchargement lancé.", "Manomboka ny fisintomana.", "Download started."));
  } catch(err) {
    console.warn('[LYRAME V41 photo download fallback]',err);
    const modal=openDynamicModal(uiText("Télécharger la photo", "Hisintona sary", "Download photo"));
    modal.overlay.style.zIndex='10030';
    const note=document.createElement('p');
    note.textContent=uiText("Le serveur ne permet pas le téléchargement direct ici. Ouvrez la photo dans le navigateur puis utilisez Enregistrer l’image.", "Tsy avelan'ny serveur ny fisintomana mivantana. Sokafy amin'ny navigateur ny sary dia fidio Enregistrer l’image.", "Direct download is blocked by the media server. Open the photo in the browser to save it.");
    const link=document.createElement('a');
    link.href=url;link.target='_blank';link.rel='noopener noreferrer';link.className='btn btn-primary';
    link.textContent=uiText('Ouvrir la photo originale','Sokafy ny sary original','Open original photo');
    modal.body.append(note,link);
  }
}

function lyrV41SetGalleryLikes(post) {
  const liked=!!reactionCache.get(post.id);
  document.querySelectorAll('#media-viewer-stage .lyr-v41-like-btn').forEach(b=>{
    b.classList.toggle('is-liked',liked);
    b.setAttribute('aria-pressed',String(liked));
    const label=b.querySelector('.lyr-v41-button-label');
    if(label)label.textContent=liked?reactionLabel(reactionCache.get(post.id)):uiText("J’aime", "Tiako", "Like");
  });
}

function lyrV41GalleryButtons(post) {
  const row=document.createElement('div');row.className='lyr-v41-gallery-actions';
  const action=(kind,label,fn)=>{
    const btn=document.createElement('button');btn.type='button';btn.className='lyr-v41-gallery-action'+(kind==='like'?' lyr-v41-like-btn':'');
    btn.innerHTML=finalSvgIcon(kind)+`<span class="lyr-v41-button-label">${escapeHtml(label)}</span>`;
    btn.addEventListener('click',async e=>{e.stopPropagation();if(btn.disabled)return;btn.disabled=true;
      try{await fn(btn);}catch(err){lyrV41ToastError(err,kind);}finally{btn.disabled=false;}
    });
    row.appendChild(btn);
  };
  action('react',uiText("J’aime","Tiako","Like"),async()=>{
    if (!state.currentUser) { toast(uiText('Connectez-vous pour réagir.','Midira aloha vao manao réaction.','Sign in to react.'));return; }
    await toggleReaction(post.id,'like');
    lyrV41SetGalleryLikes(post);
  });
  row.lastChild.classList.add('lyr-v41-like-btn');
  action('comment',uiText("Commenter","Hevitra","Comment"),()=>{
    hideEl($('#media-viewer'));hideEl($('#media-viewer-menu'));state.mediaViewerGallery=false;
    openPostDetail(post.id);
  });
  action('share',uiText("Partager","Hizara","Share"),()=>sharePost(post));
  return row;
}

// Même comportement opérationnel dans le mode photo isolée.
viewerActionButtons=function(post){return lyrV41GalleryButtons(post);};

function lyrV41GalleryOptions(post,item,index) {
  const zone=document.createElement('div');zone.className='lyr-v41-photo-options';
  const opener=document.createElement('button');opener.type='button';opener.className='lyr-v41-photo-dots';
  opener.textContent='⋮';opener.setAttribute('aria-label',uiText('Options de la photo','Safidin’ny sary','Photo options'));
  const menu=document.createElement('div');menu.className='lyr-v41-photo-options-menu hidden';
  const add=(label,run)=>{
    const b=document.createElement('button');b.type='button';b.textContent=label;
    b.addEventListener('click',async e=>{e.stopPropagation();menu.classList.add('hidden');try{await run();}catch(err){lyrV41ToastError(err,'photo option');}});
    menu.appendChild(b);
  };
  add(uiText('Télécharger cette photo','Hisintona ity sary ity','Download this photo'),()=>lyrV41DownloadPhoto(item,index));
  add(uiText('Copier le lien de la photo','Handika rohy sary','Copy photo link'),()=>lyrV41CopyText(safeUrl(item.url)));
  add(uiText('Ouvrir en plein écran','Hampiseho plein écran','Open full screen'),()=>{
    state.mediaViewerIndex=index;state.mediaViewerGallery=false;renderMediaViewer();
  });
  if(post) add(uiText('Enregistrer la publication','Hitahiry publication','Save post'),()=>toggleSavePost(post,null));
  opener.addEventListener('click',e=>{
    e.stopPropagation();
    zone.closest('#media-viewer-stage')?.querySelectorAll('.lyr-v41-photo-options-menu').forEach(m=>{if(m!==menu)m.classList.add('hidden')});
    menu.classList.toggle('hidden');
  });
  const download=document.createElement('button');download.type='button';download.className='lyr-v41-photo-download';
  download.textContent='⬇';download.setAttribute('aria-label',uiText('Télécharger cette photo','Hisintona ity sary ity','Download photo'));
  download.addEventListener('click',async e=>{e.stopPropagation();if(download.disabled)return;download.disabled=true;try{await lyrV41DownloadPhoto(item,index);}finally{download.disabled=false;}});
  zone.append(download,opener,menu);
  return zone;
}

const lyrV41BaseViewer=renderMediaViewer;
renderMediaViewer=function() {
  const stage=$('#media-viewer-stage'),footer=$('#media-viewer-footer');
  const items=state.mediaViewerItems||[],post=state.mediaViewerPost;
  if (!stage || !state.mediaViewerGallery || !post || !items.length) {
    stage?.classList.remove('lyr-v41-gallery-scroll');
    lyrV41BaseViewer();
    if(post && items.length) lyrV41AddViewerDownload();
    return;
  }
  stage.replaceChildren();
  footer?.replaceChildren();footer?.classList.add('hidden');
  stage.classList.add('gallery-scroll-mode','lyr-v41-gallery-scroll');
  $('#media-viewer-prev')?.classList.add('hidden');
  $('#media-viewer-next')?.classList.add('hidden');
  $('#media-viewer-counter')?.classList.add('hidden');
  renderMediaViewerMenu(post);
  const title=document.createElement('div');title.className='lyr-v41-gallery-intro';
  title.textContent=uiText(`${items.length} photos · Faites défiler`,`${items.length} sary · Scroll midina`,`${items.length} photos · Scroll down`);
  stage.appendChild(title);
  items.forEach((item,i)=>{
    const src=safeUrl(item.url);if(!src)return;
    const card=document.createElement('article');card.className='lyr-v41-gallery-card';card.dataset.galleryIndex=String(i);
    const head=document.createElement('div');head.className='lyr-v41-gallery-head';
    head.innerHTML=`<span class="avatar">${avatarMarkup(post.authorPhotoURL,post.authorName)}</span><span class="lyr-v41-gallery-author"><strong>${escapeHtml(post.authorName||'')}${identityBadgeMarkup({badgeType:post.authorBadgeType})}</strong><small>${escapeHtml(timeAgo(post.createdAt)||'')}</small></span><span class="lyr-v41-photo-index">${i+1}/${items.length}</span>`;
    head.appendChild(lyrV41GalleryOptions(post,item,i));
    const media=document.createElement('div');media.className='lyr-v41-gallery-photo';
    const el=document.createElement(item.type==='video'?'video':'img');el.src=src;el.alt=uiText(`Photo ${i+1}`,`Sary ${i+1}`,`Photo ${i+1}`);el.loading=i<2?'eager':'lazy';
    if(item.type==='video'){el.controls=true;el.playsInline=true;el.preload='metadata';}
    else {el.addEventListener('click',()=>{state.mediaViewerIndex=i;state.mediaViewerGallery=false;renderMediaViewer();});el.style.cursor='zoom-in';}
    media.appendChild(el);
    const stats=document.createElement('div');stats.className='lyr-v41-gallery-stats';
    stats.innerHTML=`<span>${post.reactionsCount?escapeHtml(String(post.reactionsCount)):''}</span><span>${post.commentsCount?escapeHtml(String(post.commentsCount))+' '+escapeHtml(uiText('commentaires','hevitra','comments')):''}</span>`;
    const actions=lyrV41GalleryButtons(post);
    card.append(head,media,stats,actions);
    stage.appendChild(card);
  });
  lyrV41SetGalleryLikes(post);
  // Le scroll démarre au début de la liste, jamais au milieu d'une image.
  stage.scrollTop=0;
};

function lyrV41AddViewerDownload() {
  const post=state.mediaViewerPost;
  const item=state.mediaViewerItems?.[state.mediaViewerIndex];
  const menu=$('#media-viewer-menu');
  if(!post||!item||!menu||menu.querySelector('[data-v41-download]'))return;
  const b=document.createElement('button');b.type='button';b.dataset.v41Download='1';
  b.textContent=uiText('⬇ Télécharger cette photo','⬇ Hisintona ity sary ity','⬇ Download this photo');
  b.addEventListener('click',async e=>{e.stopPropagation();hideEl(menu);await lyrV41DownloadPhoto(item,state.mediaViewerIndex);});
  menu.insertBefore(b,menu.firstChild);
}

// Un clic sur "+N" ouvre TOUTES les photos sous forme de liste verticale.
// La carte reste cliquable pour le plein écran, sans masquer le compteur.
const lyrV41BasePost=renderPostCard;
renderPostCard=function(post) {
  const card=lyrV41BasePost(post);
  if (!card) return card;
  card.classList.add('lyr-v41-post');
  const grid=card.querySelector('.post-media-collage');
  const photos=lyrV41PhotoItems(post);
  if(grid) {
    grid.dataset.count=String(Math.min(photos.length,5));
    grid.setAttribute('aria-label',uiText('Photos de la publication','Sary ao amin’ny publication','Post photos'));
    grid.querySelectorAll('.collage-item').forEach((tile,index)=>{
      tile.setAttribute('role','button');tile.setAttribute('tabindex','0');
      tile.setAttribute('aria-label',uiText(`Ouvrir la photo ${index+1}`,`Sokafy ny sary ${index+1}`,`Open photo ${index+1}`));
      const openTilePhoto=e=>{
        if(e?.target?.closest?.('.collage-more')) return;
        e?.preventDefault?.();
        e?.stopPropagation?.();
        e?.stopImmediatePropagation?.();
        openMediaViewer(photos,index,post);
      };
      tile.addEventListener('click',openTilePhoto,true);
      tile.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){openTilePhoto(e);}});
      // +N reste une action séparée : il ouvre toutes les photos en galerie verticale.
      const more=tile.querySelector('.collage-more');
      if(more) {
        more.addEventListener('click',e=>{
          e.preventDefault();e.stopPropagation();e.stopImmediatePropagation();
          openMediaViewer(photos,0,post,{gallery:true});
        },true);
      }
    });

  }
  // Une publication avec une seule photo doit aussi s'ouvrir en grand au toucher.
  if(!grid && photos.length===1){
    const single=card.querySelector('.post-media img');
    if(single){
      single.setAttribute('role','button');
      single.setAttribute('tabindex','0');
      single.setAttribute('aria-label',uiText('Voir la photo en grand','Hijery ny sary lehibe','View photo full size'));
      const openSingle=e=>{
        e?.preventDefault?.();e?.stopPropagation?.();e?.stopImmediatePropagation?.();
        openMediaViewer(photos,0,post);
      };
      single.addEventListener('click',openSingle,true);
      single.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' ')openSingle(e);});
    }
  }
  // Statistiques et boutons proches de la référence (réactions réelles Firebase).
  const stats=card.querySelector('.post-stats');
  if(stats && !stats.querySelector('.lyr-v41-reaction-icons')){
    const hearts=document.createElement('span');hearts.className='lyr-v41-reaction-icons';hearts.setAttribute('aria-hidden','true');
    hearts.innerHTML='<span>👍</span><span>❤️</span>';hearts.hidden=!post.reactionsCount;
    const count=stats.querySelector('.post-reaction-count');if(count)stats.insertBefore(hearts,count);
  }
  const actionRow=card.querySelector('.post-actions');
  if(actionRow){
    const b=actionRow.querySelector('[data-act="react"]');
    if(b) {b.innerHTML=`${finalSvgIcon('react')}<span class="action-label">${escapeHtml(uiText('J’aime','Tiako','Like'))}</span>`;}
    const c=actionRow.querySelector('[data-act="comment"]');
    if(c)c.innerHTML=`${finalSvgIcon('comment')}<span class="action-label">${escapeHtml(uiText('Commenter','Hevitra','Comment'))}</span>`;
    const s=actionRow.querySelector('[data-act="share"]');
    if(s)s.innerHTML=`${finalSvgIcon('share')}<span class="action-label">${escapeHtml(uiText('Partager','Hizara','Share'))}</span>`;
  }
  return card;
};


/* ================================================================
   LYRAME WEB V45 — PHOTO TAP ROBUSTE
   - compatibilité avec les anciennes publications où mediaType n'était
     pas toujours exactement "image" ;
   - interception globale en phase capture : le tap sur une photo arrive
     toujours à la visionneuse, même si un ancien handler de carte bloque
     ensuite la propagation ;
   - +N ouvre la galerie complète, une photo ouvre directement le plein écran.
   ================================================================ */
function lyrV45PhotoItems(post) {
  const items = Array.isArray(post?.mediaItems)
    ? post.mediaItems
        .filter(m => m && safeUrl(m.url) && (m.type || 'image') !== 'video')
        .map(m => ({ url: m.url, type: 'image', ratio: m.ratio || post?.imageRatio || 'original' }))
    : [];
  if (items.length) return items;

  // Anciennes publications : mediaURL existe mais mediaType peut être vide,
  // "images", "photo" ou une ancienne valeur. Si ce n'est pas une vidéo,
  // l'élément rendu est une image et doit donc rester ouvrable.
  const direct = safeUrl(post?.mediaURL);
  if (direct && String(post?.mediaType || '').toLowerCase() !== 'video') {
    return [{ url: direct, type: 'image', ratio: post?.imageRatio || 'original' }];
  }
  return [];
}

function lyrV45OpenPhotoViewer(items, index, post, options = {}) {
  if (!Array.isArray(items) || !items.length) return;
  openMediaViewer(items, Math.max(0, Math.min(Number(index) || 0, items.length - 1)), post, options);
  const viewer = document.getElementById('media-viewer');
  if (viewer) {
    viewer.classList.remove('hidden');
    viewer.removeAttribute('hidden');
    viewer.setAttribute('aria-hidden', 'false');
  }
}

// Mémorise le vrai objet Firebase sur chaque carte : aucun JSON dans le DOM,
// aucune donnée supplémentaire persistée.
const lyrV45BasePost = renderPostCard;
renderPostCard = function(post) {
  const card = lyrV45BasePost(post);
  if (!card) return card;
  card.__lyrameV45Post = post;
  const photos = lyrV45PhotoItems(post);
  if (photos.length) {
    card.classList.add('lyr-v45-photo-enabled');
    card.querySelectorAll('.post-media img, .post-media-collage img').forEach(img => {
      img.style.cursor = 'zoom-in';
      img.setAttribute('draggable', 'false');
    });
  }
  return card;
};

// IMPORTANT : capture=true. Le document reçoit le tap AVANT les anciens
// listeners de la publication. C'est ce qui rend le comportement fiable sur
// Android/TWA, y compris sur les anciennes cartes et le bouton +N.
document.addEventListener('click', e => {
  const target = e.target;
  if (!(target instanceof Element)) return;
  // V46 utilise de vrais boutons tactiles au-dessus des photos.
  // On laisse ces boutons gérer le tap eux-mêmes, sans interception V45.
  if (target.closest('.lyr-v46-photo-hit')) return;
  const card = target.closest('.post-card.lyr-v45-photo-enabled');
  if (!card) return;

  const post = card.__lyrameV45Post;
  const photos = lyrV45PhotoItems(post);
  if (!post || !photos.length) return;

  const more = target.closest('.collage-more');
  if (more && card.contains(more)) {
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
    lyrV45OpenPhotoViewer(photos, 0, post, { gallery: true });
    return;
  }

  const tile = target.closest('.post-media-collage .collage-item');
  if (tile && card.contains(tile)) {
    const tiles = Array.from(tile.parentElement?.querySelectorAll('.collage-item') || []);
    const index = Math.max(0, tiles.indexOf(tile));
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
    lyrV45OpenPhotoViewer(photos, index, post);
    return;
  }

  const singleImage = target.closest('.post-media img');
  if (singleImage && card.contains(singleImage)) {
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
    lyrV45OpenPhotoViewer(photos, 0, post);
  }
}, true);

// Fermer le menu ⋮ après une interaction extérieure sans fermer la galerie.
document.addEventListener('click',e=>{
  if(!e.target.closest?.('.lyr-v41-photo-options'))
    document.querySelectorAll('.lyr-v41-photo-options-menu:not(.hidden)').forEach(m=>m.classList.add('hidden'));
});


/* ================================================================
   LYRAME WEB V43 — LOGIN TELEPHONE / GALERIE / HEADER FIXE
   - reCAPTCHA registration duplicate invisible removed
   - single & multi-photo tap opens full viewer; +N opens vertical gallery
   - image upload/provider code intentionally unchanged
   ================================================================ */


/* ================================================================
   LYRAME WEB V46 — PHOTO VIEWER / VRAI HIT-TARGET MOBILE
   - chaque photo du feed reçoit un vrai bouton transparent au-dessus;
   - un tap ouvre une visionneuse dédiée, attachée directement à <body>;
   - +N ouvre toutes les photos en galerie verticale;
   - ne dépend pas du scroll du feed ni de l'ancienne visionneuse V41/V45.
   ================================================================ */
function lyrV46EnsureViewer(){
  let root=document.getElementById('lyr-v46-photo-viewer');
  if(root) return root;
  root=document.createElement('div');
  root.id='lyr-v46-photo-viewer';
  root.className='lyr-v46-viewer hidden';
  root.setAttribute('role','dialog');
  root.setAttribute('aria-modal','true');
  root.setAttribute('aria-label',uiText('Photo en grand','Sary lehibe','Full size photo'));
  root.innerHTML=`
    <div class="lyr-v46-viewer-bar">
      <button type="button" class="lyr-v46-viewer-close" aria-label="${escapeHtml(uiText('Fermer','Hidio','Close'))}">×</button>
      <div class="lyr-v46-viewer-count"></div>
    </div>
    <button type="button" class="lyr-v46-viewer-prev" aria-label="${escapeHtml(uiText('Photo précédente','Sary teo aloha','Previous photo'))}">‹</button>
    <div class="lyr-v46-viewer-stage"></div>
    <button type="button" class="lyr-v46-viewer-next" aria-label="${escapeHtml(uiText('Photo suivante','Sary manaraka','Next photo'))}">›</button>`;
  document.body.appendChild(root);
  root.querySelector('.lyr-v46-viewer-close')?.addEventListener('click',lyrV46CloseViewer);
  root.querySelector('.lyr-v46-viewer-prev')?.addEventListener('click',e=>{e.stopPropagation();lyrV46Move(-1);});
  root.querySelector('.lyr-v46-viewer-next')?.addEventListener('click',e=>{e.stopPropagation();lyrV46Move(1);});
  root.addEventListener('click',e=>{if(e.target===root)lyrV46CloseViewer();});
  return root;
}

const lyrV46ViewerState={items:[],index:0,post:null,gallery:false};

function lyrV46CloseViewer(){
  const root=document.getElementById('lyr-v46-photo-viewer');
  if(root) root.classList.add('hidden');
  document.documentElement.classList.remove('lyr-v46-viewer-open');
}

function lyrV46RenderViewer(){
  const root=lyrV46EnsureViewer();
  const stage=root.querySelector('.lyr-v46-viewer-stage');
  const count=root.querySelector('.lyr-v46-viewer-count');
  const prev=root.querySelector('.lyr-v46-viewer-prev');
  const next=root.querySelector('.lyr-v46-viewer-next');
  const items=lyrV46ViewerState.items;
  if(!stage||!items.length) return;
  stage.replaceChildren();
  root.classList.toggle('is-gallery',!!lyrV46ViewerState.gallery);
  if(lyrV46ViewerState.gallery){
    if(count) count.textContent=uiText(`${items.length} photos`,`${items.length} sary`,`${items.length} photos`);
    prev?.classList.add('hidden');next?.classList.add('hidden');
    items.forEach((item,i)=>{
      const src=safeUrl(item?.url); if(!src)return;
      const wrap=document.createElement('button');
      wrap.type='button';wrap.className='lyr-v46-gallery-photo';
      wrap.setAttribute('aria-label',uiText(`Ouvrir la photo ${i+1}`,`Sokafy ny sary ${i+1}`,`Open photo ${i+1}`));
      const img=document.createElement('img');img.src=src;img.alt='';img.loading=i<2?'eager':'lazy';
      wrap.appendChild(img);
      wrap.addEventListener('click',e=>{e.stopPropagation();lyrV46ViewerState.index=i;lyrV46ViewerState.gallery=false;lyrV46RenderViewer();});
      stage.appendChild(wrap);
    });
    stage.scrollTop=0;
    return;
  }
  const index=Math.max(0,Math.min(lyrV46ViewerState.index,items.length-1));
  lyrV46ViewerState.index=index;
  const item=items[index];
  const src=safeUrl(item?.url);
  if(count) count.textContent=`${index+1} / ${items.length}`;
  prev?.classList.toggle('hidden',items.length<2);
  next?.classList.toggle('hidden',items.length<2);
  if(src){
    const img=document.createElement('img');
    img.className='lyr-v46-viewer-image';img.src=src;img.alt='';img.draggable=false;
    stage.appendChild(img);
  }
}

function lyrV46OpenViewer(items,index=0,post=null,options={}){
  const clean=(Array.isArray(items)?items:[])
    .filter(x=>x&&safeUrl(x.url)&&String(x.type||'image').toLowerCase()!=='video')
    .map(x=>({url:x.url,type:'image',ratio:x.ratio||'original'}));
  if(!clean.length)return;
  lyrV46ViewerState.items=clean;
  lyrV46ViewerState.index=Math.max(0,Math.min(Number(index)||0,clean.length-1));
  lyrV46ViewerState.post=post||null;
  lyrV46ViewerState.gallery=!!options.gallery;
  const root=lyrV46EnsureViewer();
  root.classList.remove('hidden');
  document.documentElement.classList.add('lyr-v46-viewer-open');
  lyrV46RenderViewer();
}

function lyrV46Move(delta){
  const n=lyrV46ViewerState.items.length;if(n<2)return;
  lyrV46ViewerState.index=(lyrV46ViewerState.index+delta+n)%n;
  lyrV46RenderViewer();
}

function lyrV46BindTap(button,openFn){
  let down=null,lastPointerOpen=0;
  button.addEventListener('pointerdown',e=>{down={x:e.clientX,y:e.clientY,id:e.pointerId};},{passive:true});
  button.addEventListener('pointerup',e=>{
    if(!down||down.id!==e.pointerId)return;
    const moved=Math.hypot(e.clientX-down.x,e.clientY-down.y);
    down=null;
    if(moved<=10){
      e.preventDefault();e.stopPropagation();
      lastPointerOpen=Date.now();openFn();
    }
  });
  button.addEventListener('pointercancel',()=>{down=null;});
  button.addEventListener('click',e=>{
    e.preventDefault();e.stopPropagation();e.stopImmediatePropagation();
    if(Date.now()-lastPointerOpen<500)return;
    openFn();
  });
}

const lyrV46BasePost=renderPostCard;
renderPostCard=function(post){
  const card=lyrV46BasePost(post);
  if(!card)return card;
  const photos=lyrV45PhotoItems(post);
  if(!photos.length)return card;
  card.classList.add('lyr-v46-photo-enabled');

  const grid=card.querySelector('.post-media-collage');
  if(grid){
    const tiles=Array.from(grid.querySelectorAll('.collage-item'));
    tiles.forEach((tile,index)=>{
      const oldMore=tile.querySelector('.collage-more');
      if(oldMore){
        // Remplacement du +N pour retirer les anciens listeners concurrents.
        const more=oldMore.cloneNode(true);
        more.classList.add('lyr-v46-photo-hit');
        oldMore.replaceWith(more);
        lyrV46BindTap(more,()=>lyrV46OpenViewer(photos,0,post,{gallery:true}));
        return;
      }
      const hit=document.createElement('button');
      hit.type='button';hit.className='lyr-v46-photo-hit lyr-v46-tile-hit';
      hit.setAttribute('aria-label',uiText(`Voir la photo ${index+1} en grand`,`Hijery ny sary ${index+1} lehibe`,`View photo ${index+1} full size`));
      tile.appendChild(hit);
      lyrV46BindTap(hit,()=>lyrV46OpenViewer(photos,index,post));
    });
  }else{
    const media=card.querySelector('.post-media');
    const img=media?.querySelector('img');
    if(media&&img){
      const hit=document.createElement('button');
      hit.type='button';hit.className='lyr-v46-photo-hit lyr-v46-single-hit';
      hit.setAttribute('aria-label',uiText('Voir la photo en grand','Hijery ny sary lehibe','View photo full size'));
      media.appendChild(hit);
      lyrV46BindTap(hit,()=>lyrV46OpenViewer(photos,0,post));
    }
  }
  return card;
};

document.addEventListener('keydown',e=>{
  const root=document.getElementById('lyr-v46-photo-viewer');
  if(!root||root.classList.contains('hidden'))return;
  if(e.key==='Escape')lyrV46CloseViewer();
  else if(e.key==='ArrowLeft'&&!lyrV46ViewerState.gallery)lyrV46Move(-1);
  else if(e.key==='ArrowRight'&&!lyrV46ViewerState.gallery)lyrV46Move(1);
});


/* ================================================================
   LYRAME WEB V47 — ACTIONS ET COMMENTAIRES PROPRES A CHAQUE PHOTO
   - chaque photo possède son propre Like / Commentaires / Partage;
   - les compteurs et commentaires photo sont séparés de la publication;
   - le bouton Commentaires ouvre directement une feuille de commentaires;
   - le bouton Commentaires de la publication ouvre aussi directement la feuille,
     sans forcer l'ouverture de l'écran détail publication;
   - aucune modification du routeur média / ImageKit.
   ================================================================ */

function lyrV47Hash(value) {
  let h = 2166136261;
  const s = String(value || '');
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0).toString(36);
}

function lyrV47MediaKey(item, index = 0) {
  const url = safeUrl(item?.url) || `index:${index}`;
  return `photo_${lyrV47Hash(url)}`;
}

function lyrV47MediaRef(post, item, index = 0) {
  return doc(db, 'posts', post.id, 'media', lyrV47MediaKey(item, index));
}

function lyrV47MediaReactionRef(post, item, index = 0) {
  if (!state.currentUser) return null;
  return doc(db, 'posts', post.id, 'media', lyrV47MediaKey(item, index), 'reactions', state.currentUser.uid);
}

function lyrV47PhotoShare(post, item, index = 0) {
  const url = safeUrl(item?.url);
  if (!url) return Promise.resolve(false);
  const title = post?.title || uiText(`Photo ${index + 1} sur LYRAME`, `Sary ${index + 1} ao LYRAME`, `Photo ${index + 1} on LYRAME`);
  if (navigator.share) {
    return navigator.share({ title: 'LYRAME', text: title, url }).then(() => true).catch(err => {
      if (err?.name === 'AbortError') return false;
      console.warn('[V47 photo share]', err);
      return lyrV41CopyText(url);
    });
  }
  return lyrV41CopyText(url);
}

function lyrV47EnsurePhotoMenu(host, post, item, index) {
  if (!host || host.querySelector('.lyr-v47-photo-menu')) return;
  const zone = document.createElement('div');
  zone.className = 'lyr-v47-photo-menu';
  const open = document.createElement('button');
  open.type = 'button';
  open.className = 'lyr-v47-photo-menu-btn';
  open.textContent = '⋮';
  open.setAttribute('aria-label', uiText('Options de la photo', 'Safidin’ny sary', 'Photo options'));
  const menu = document.createElement('div');
  menu.className = 'lyr-v47-photo-menu-list hidden';
  const add = (label, fn) => {
    const b = document.createElement('button');
    b.type = 'button'; b.textContent = label;
    b.addEventListener('click', async e => {
      e.stopPropagation(); menu.classList.add('hidden');
      try { await fn(); } catch (err) { console.warn('[V47 photo menu]', err); }
    });
    menu.appendChild(b);
  };
  add(uiText('Télécharger la photo', 'Hisintona sary', 'Download photo'), () => lyrV41DownloadPhoto(item, index));
  add(uiText('Copier le lien', 'Handika rohy', 'Copy link'), () => lyrV41CopyText(safeUrl(item?.url)));
  open.addEventListener('click', e => {
    e.stopPropagation();
    document.querySelectorAll('.lyr-v47-photo-menu-list:not(.hidden)').forEach(x => { if (x !== menu) x.classList.add('hidden'); });
    menu.classList.toggle('hidden');
  });
  zone.append(open, menu);
  host.appendChild(zone);
}

async function lyrV47ReadPhotoState(post, item, index) {
  const mediaRef = lyrV47MediaRef(post, item, index);
  const reactionRef = lyrV47MediaReactionRef(post, item, index);
  try {
    const reads = [getDoc(mediaRef)];
    if (reactionRef) reads.push(getDoc(reactionRef));
    const result = await Promise.all(reads);
    const media = result[0]?.exists() ? result[0].data() : {};
    const liked = !!(result[1]?.exists?.());
    return {
      reactionsCount: Math.max(0, Number(media?.reactionsCount || 0)),
      commentsCount: Math.max(0, Number(media?.commentsCount || 0)),
      liked
    };
  } catch (err) {
    console.warn('[V47 photo state]', err);
    return { reactionsCount: 0, commentsCount: 0, liked: false };
  }
}

function lyrV47ApplyPhotoState(row, data) {
  if (!row) return;
  row.dataset.liked = data?.liked ? '1' : '0';
  const like = row.querySelector('[data-v47-photo-like]');
  const likeCount = row.querySelector('[data-v47-like-count]');
  const commentCount = row.querySelector('[data-v47-comment-count]');
  if (like) {
    like.classList.toggle('is-active', !!data?.liked);
    like.setAttribute('aria-pressed', String(!!data?.liked));
  }
  if (likeCount) likeCount.textContent = Number(data?.reactionsCount || 0) ? String(data.reactionsCount) : '';
  if (commentCount) commentCount.textContent = Number(data?.commentsCount || 0) ? String(data.commentsCount) : '';
}

async function lyrV47TogglePhotoLike(post, item, index, row) {
  if (!state.currentUser) {
    toast(uiText('Connectez-vous pour réagir.', 'Midira aloha vao manao réaction.', 'Sign in to react.'));
    return;
  }
  const uid = state.currentUser.uid;
  const mediaRef = lyrV47MediaRef(post, item, index);
  const reactionRef = doc(db, 'posts', post.id, 'media', lyrV47MediaKey(item, index), 'reactions', uid);
  const profile = state.currentProfile || {};
  const result = await runTransaction(db, async tx => {
    const mediaSnap = await tx.get(mediaRef);
    const reactionSnap = await tx.get(reactionRef);
    const current = Math.max(0, Number(mediaSnap.exists() ? mediaSnap.data().reactionsCount || 0 : 0));
    const base = {
      postId: post.id,
      url: safeUrl(item?.url),
      index: Number(index) || 0,
      updatedAt: serverTimestamp()
    };
    if (reactionSnap.exists()) {
      tx.delete(reactionRef);
      tx.set(mediaRef, { ...base, reactionsCount: Math.max(0, current - 1) }, { merge: true });
      return { liked: false, reactionsCount: Math.max(0, current - 1) };
    }
    tx.set(reactionRef, {
      userId: uid,
      type: 'like',
      authorName: profile.fullname || state.currentUser.displayName || '',
      createdAt: serverTimestamp()
    });
    tx.set(mediaRef, { ...base, reactionsCount: current + 1 }, { merge: true });
    return { liked: true, reactionsCount: current + 1 };
  });
  const oldComments = Number(row?.querySelector('[data-v47-comment-count]')?.textContent || 0);
  lyrV47ApplyPhotoState(row, { ...result, commentsCount: oldComments });
}

function lyrV47CreatePhotoActions(post, item, index) {
  const box = document.createElement('div');
  box.className = 'lyr-v47-photo-interactions';
  box.dataset.mediaKey = lyrV47MediaKey(item, index);
  box.innerHTML = `
    <div class="lyr-v47-photo-stats">
      <span><span aria-hidden="true">👍</span> <b data-v47-like-count></b></span>
      <span><b data-v47-comment-count></b> <span>${escapeHtml(uiText('commentaires','hevitra','comments'))}</span></span>
    </div>
    <div class="lyr-v47-photo-actions">
      <button type="button" data-v47-photo-like aria-pressed="false">${finalSvgIcon('react')}<span>${escapeHtml(uiText("J’aime",'Tiako','Like'))}</span></button>
      <button type="button" data-v47-photo-comment>${finalSvgIcon('comment')}<span>${escapeHtml(uiText('Commenter','Hevitra','Comment'))}</span></button>
      <button type="button" data-v47-photo-share>${finalSvgIcon('share')}<span>${escapeHtml(uiText('Partager','Hizara','Share'))}</span></button>
    </div>`;
  box.querySelector('[data-v47-photo-like]')?.addEventListener('click', async e => {
    e.stopPropagation();
    const btn = e.currentTarget; if (btn.disabled) return; btn.disabled = true;
    try { await lyrV47TogglePhotoLike(post, item, index, box); }
    catch (err) { console.warn('[V47 photo like]', err); toast(uiText('Réessayez.', 'Andramo indray.', 'Try again.')); }
    finally { btn.disabled = false; }
  });
  box.querySelector('[data-v47-photo-comment]')?.addEventListener('click', e => {
    e.stopPropagation();
    lyrV47OpenCommentsSheet({ kind: 'photo', post, item, index });
  });
  box.querySelector('[data-v47-photo-share]')?.addEventListener('click', async e => {
    e.stopPropagation();
    const btn = e.currentTarget; if (btn.disabled) return; btn.disabled = true;
    try { await lyrV47PhotoShare(post, item, index); }
    finally { btn.disabled = false; }
  });
  lyrV47ReadPhotoState(post, item, index).then(data => lyrV47ApplyPhotoState(box, data));
  return box;
}

let lyrV47CommentsUnsub = null;
let lyrV47CommentTarget = null;

function lyrV47EnsureCommentsSheet() {
  let root = document.getElementById('lyr-v47-comments-overlay');
  if (root) return root;
  root = document.createElement('div');
  root.id = 'lyr-v47-comments-overlay';
  root.className = 'lyr-v47-comments-overlay hidden';
  root.innerHTML = `
    <section class="lyr-v47-comments-sheet" role="dialog" aria-modal="true" aria-label="Commentaires">
      <div class="lyr-v47-sheet-handle" aria-hidden="true"></div>
      <header class="lyr-v47-comments-head">
        <div>
          <strong class="lyr-v47-comments-title"></strong>
          <small class="lyr-v47-comments-subtitle"></small>
        </div>
        <button type="button" class="lyr-v47-comments-close" aria-label="${escapeHtml(uiText('Fermer','Hidio','Close'))}">×</button>
      </header>
      <div class="lyr-v47-comments-list"></div>
      <form class="lyr-v47-comments-composer">
        <span class="lyr-v47-comments-avatar"></span>
        <textarea rows="1" maxlength="2000" placeholder="${escapeHtml(uiText('Écrivez un commentaire…','Soraty ny hevitrao…','Write a comment…'))}"></textarea>
        <button type="submit" class="lyr-v47-comments-send" aria-label="${escapeHtml(uiText('Envoyer','Alefa','Send'))}">➤</button>
      </form>
    </section>`;
  document.body.appendChild(root);
  root.querySelector('.lyr-v47-comments-close')?.addEventListener('click', lyrV47CloseCommentsSheet);
  root.addEventListener('click', e => { if (e.target === root) lyrV47CloseCommentsSheet(); });
  root.querySelector('.lyr-v47-comments-composer')?.addEventListener('submit', lyrV47SubmitComment);
  return root;
}

function lyrV47CloseCommentsSheet() {
  if (lyrV47CommentsUnsub) { try { lyrV47CommentsUnsub(); } catch (_) {} lyrV47CommentsUnsub = null; }
  lyrV47CommentTarget = null;
  const root = document.getElementById('lyr-v47-comments-overlay');
  root?.classList.add('hidden');
  document.documentElement.classList.remove('lyr-v47-comments-open');
}

function lyrV47CommentRow(comment) {
  const row = document.createElement('article');
  row.className = 'lyr-v47-comment-row' + (comment.parentId ? ' is-reply' : '');
  const name = comment.isAnonymous
    ? uiText('Anonyme','Tsy mitonona anarana','Anonymous')
    : (comment.authorName || comment.authorUsername || uiText('Utilisateur','Mpampiasa','User'));
  row.innerHTML = `
    <span class="lyr-v47-comment-avatar">${comment.isAnonymous ? '?' : avatarMarkup(comment.authorPhotoURL, name)}</span>
    <div class="lyr-v47-comment-main">
      <div class="lyr-v47-comment-bubble">
        <strong>${escapeHtml(name)}${comment.isAnonymous ? '' : identityBadgeMarkup({badgeType: comment.authorBadgeType})}</strong>
        <div>${comment.deleted ? escapeHtml(uiText('Commentaire supprimé','Hevitra voafafa','Comment deleted')) : commentTextWithMentions(comment.text || '', comment.mentions || [])}</div>
      </div>
      <small>${escapeHtml(formatTime(comment.createdAt))}</small>
    </div>`;
  return row;
}

function lyrV47WatchComments(target) {
  if (lyrV47CommentsUnsub) { try { lyrV47CommentsUnsub(); } catch (_) {} lyrV47CommentsUnsub = null; }
  const root = lyrV47EnsureCommentsSheet();
  const list = root.querySelector('.lyr-v47-comments-list');
  if (!list) return;
  list.innerHTML = `<div class="lyr-v47-comments-loading">${escapeHtml(uiText('Chargement…','Miandry…','Loading…'))}</div>`;
  let col;
  if (target.kind === 'photo') {
    col = collection(db, 'posts', target.post.id, 'media', lyrV47MediaKey(target.item, target.index), 'comments');
  } else {
    col = collection(db, 'posts', target.post.id, 'comments');
  }
  const q = query(col, orderBy('createdAt', 'asc'), limit(200));
  lyrV47CommentsUnsub = onSnapshot(q, snap => {
    list.replaceChildren();
    if (snap.empty) {
      const empty = document.createElement('div');
      empty.className = 'lyr-v47-comments-empty';
      empty.textContent = uiText('Aucun commentaire pour le moment.', 'Mbola tsy misy hevitra.', 'No comments yet.');
      list.appendChild(empty);
    } else {
      snap.docs.forEach(d => list.appendChild(lyrV47CommentRow({ id: d.id, ...d.data() })));
    }
    requestAnimationFrame(() => { list.scrollTop = list.scrollHeight; });
    if (target.kind === 'photo') {
      document.querySelectorAll(`.lyr-v47-photo-interactions[data-media-key="${CSS.escape(lyrV47MediaKey(target.item,target.index))}"]`).forEach(row => {
        const c = row.querySelector('[data-v47-comment-count]'); if (c) c.textContent = snap.size ? String(snap.size) : '';
      });
    }
  }, err => {
    console.warn('[V47 comments listener]', err);
    list.textContent = uiText('Impossible de charger les commentaires.', 'Tsy afaka mampiseho hevitra.', 'Unable to load comments.');
  });
}

function lyrV47OpenCommentsSheet(target) {
  if (!target?.post?.id) return;
  lyrV47CommentTarget = target;
  const root = lyrV47EnsureCommentsSheet();
  const title = root.querySelector('.lyr-v47-comments-title');
  const subtitle = root.querySelector('.lyr-v47-comments-subtitle');
  if (target.kind === 'photo') {
    if (title) title.textContent = uiText('Commentaires de la photo', 'Hevitra amin’ity sary ity', 'Photo comments');
    if (subtitle) subtitle.textContent = uiText(`Photo ${Number(target.index)+1}`, `Sary ${Number(target.index)+1}`, `Photo ${Number(target.index)+1}`);
  } else {
    if (title) title.textContent = uiText('Commentaires', 'Hevitra rehetra', 'Comments');
    if (subtitle) subtitle.textContent = uiText('Publication', 'Publication', 'Post');
  }
  const avatar = root.querySelector('.lyr-v47-comments-avatar');
  const me = state.currentProfile || {};
  if (avatar) avatar.innerHTML = avatarMarkup(me.photoURL || state.currentUser?.photoURL || '', me.fullname || state.currentUser?.displayName || '');
  const input = root.querySelector('textarea'); if (input) input.value = '';
  root.classList.remove('hidden');
  document.documentElement.classList.add('lyr-v47-comments-open');
  lyrV47WatchComments(target);
  setTimeout(() => input?.focus(), 120);
}

async function lyrV47SubmitComment(e) {
  e.preventDefault();
  const target = lyrV47CommentTarget;
  if (!target?.post?.id || !state.currentUser) return;
  const form = e.currentTarget;
  const input = form.querySelector('textarea');
  const send = form.querySelector('.lyr-v47-comments-send');
  const text = String(input?.value || '').trim().slice(0, 2000);
  if (!text) return;
  if (send) send.disabled = true;
  try {
    const uid = state.currentUser.uid;
    const p = state.currentProfile || {};
    const common = {
      authorId: uid,
      authorName: p.fullname || state.currentUser.displayName || '',
      authorUsername: p.username || '',
      authorPhotoURL: p.photoURL || '',
      authorBadgeType: badgeTypeOf(p),
      isAnonymous: false,
      text,
      mentions: [],
      parentId: null,
      createdAt: serverTimestamp()
    };
    if (target.kind === 'photo') {
      const key = lyrV47MediaKey(target.item, target.index);
      const mediaRef = doc(db, 'posts', target.post.id, 'media', key);
      const newRef = doc(collection(db, 'posts', target.post.id, 'media', key, 'comments'));
      await runTransaction(db, async tx => {
        const mediaSnap = await tx.get(mediaRef);
        const current = Math.max(0, Number(mediaSnap.exists() ? mediaSnap.data().commentsCount || 0 : 0));
        tx.set(newRef, common);
        tx.set(mediaRef, {
          postId: target.post.id,
          url: safeUrl(target.item?.url),
          index: Number(target.index) || 0,
          commentsCount: current + 1,
          updatedAt: serverTimestamp()
        }, { merge: true });
      });
    } else {
      const postRef = doc(db, 'posts', target.post.id);
      const newRef = doc(collection(db, 'posts', target.post.id, 'comments'));
      await setDoc(newRef, {
        ...common,
        imageURL: '', imagePublicId: '', mediaURL: '', mediaPublicId: '', mediaType: '', stickerId: '', stickerTone: ''
      });
      await updateDoc(postRef, { commentsCount: increment(1) });
    }
    if (input) input.value = '';
  } catch (err) {
    console.warn('[V47 send comment]', err);
    toast(firestoreWriteErrorLabel(err, uiText('Impossible d’envoyer.', 'Tsy afaka alefa.', 'Unable to send.')));
  } finally {
    if (send) send.disabled = false;
  }
}

// V47 remplace le rendu de la visionneuse V46 afin que CHAQUE photo garde
// sa propre barre d'actions et son propre compteur.
lyrV46RenderViewer = function() {
  const root = lyrV46EnsureViewer();
  const stage = root.querySelector('.lyr-v46-viewer-stage');
  const count = root.querySelector('.lyr-v46-viewer-count');
  const prev = root.querySelector('.lyr-v46-viewer-prev');
  const next = root.querySelector('.lyr-v46-viewer-next');
  const items = lyrV46ViewerState.items;
  const post = lyrV46ViewerState.post;
  if (!stage || !items.length) return;
  stage.replaceChildren();
  root.classList.toggle('is-gallery', !!lyrV46ViewerState.gallery);

  if (lyrV46ViewerState.gallery) {
    if (count) count.textContent = uiText(`${items.length} photos`, `${items.length} sary`, `${items.length} photos`);
    prev?.classList.add('hidden'); next?.classList.add('hidden');
    items.forEach((item, i) => {
      const src = safeUrl(item?.url); if (!src) return;
      const card = document.createElement('article');
      card.className = 'lyr-v47-gallery-card';
      const media = document.createElement('div');
      media.className = 'lyr-v47-gallery-media';
      const open = document.createElement('button');
      open.type = 'button'; open.className = 'lyr-v47-gallery-open';
      open.setAttribute('aria-label', uiText(`Ouvrir la photo ${i+1}`, `Sokafy ny sary ${i+1}`, `Open photo ${i+1}`));
      const img = document.createElement('img'); img.src = src; img.alt = ''; img.loading = i < 2 ? 'eager' : 'lazy';
      open.appendChild(img); media.appendChild(open);
      lyrV47EnsurePhotoMenu(media, post, item, i);
      open.addEventListener('click', e => {
        e.stopPropagation(); lyrV46ViewerState.index = i; lyrV46ViewerState.gallery = false; lyrV46RenderViewer();
      });
      card.append(media);
      if (post) card.appendChild(lyrV47CreatePhotoActions(post, item, i));
      stage.appendChild(card);
    });
    stage.scrollTop = 0;
    return;
  }

  const index = Math.max(0, Math.min(lyrV46ViewerState.index, items.length - 1));
  lyrV46ViewerState.index = index;
  const item = items[index];
  const src = safeUrl(item?.url);
  if (count) count.textContent = `${index + 1} / ${items.length}`;
  prev?.classList.toggle('hidden', items.length < 2);
  next?.classList.toggle('hidden', items.length < 2);
  const wrap = document.createElement('div'); wrap.className = 'lyr-v47-single-wrap';
  const media = document.createElement('div'); media.className = 'lyr-v47-single-media';
  if (src) {
    const img = document.createElement('img');
    img.className = 'lyr-v46-viewer-image'; img.src = src; img.alt = ''; img.draggable = false;
    media.appendChild(img);
    lyrV47EnsurePhotoMenu(media, post, item, index);
  }
  wrap.appendChild(media);
  if (post) wrap.appendChild(lyrV47CreatePhotoActions(post, item, index));
  stage.appendChild(wrap);
};

// Le bouton Commentaires d'une publication ne navigue plus vers l'écran détail.
// Il ouvre directement TOUS les commentaires dans la feuille, comme demandé.
document.addEventListener('click', e => {
  const target = e.target;
  if (!(target instanceof Element)) return;
  const card = target.closest('.post-card');
  if (!card) return;
  const isCommentAction = target.closest('.post-action[data-act="comment"]');
  const isCommentCount = target.closest('.post-comment-count');
  const isPreview = target.closest('.feed-comment-one, .feed-comment-input');
  if (!isCommentAction && !isCommentCount && !isPreview) return;
  const post = card.__lyrameV45Post;
  if (!post?.id) return;
  e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
  lyrV47OpenCommentsSheet({ kind: 'post', post });
}, true);

document.addEventListener('click', e => {
  if (!e.target.closest?.('.lyr-v47-photo-menu')) {
    document.querySelectorAll('.lyr-v47-photo-menu-list:not(.hidden)').forEach(m => m.classList.add('hidden'));
  }
});


/* ================================================================
   LYRAME WEB V48 — COMMENTAIRES COMPLETS PAR PHOTO
   Correction de V47 : on réutilise le vrai système commentaires LYRAME
   (Répondre, réactions, emoji, stickers, image, mentions) dans une feuille
   directe, sans rouvrir la publication. Chaque photo garde son espace logique.
   ================================================================ */

let lyrV48SheetState = null;

function lyrV48PhotoContext() {
  return state.activePhotoCommentContext && state.activePhotoCommentContext.postId === state.activePostId
    ? state.activePhotoCommentContext
    : null;
}

function lyrV48ActiveMediaKey() {
  return lyrV48PhotoContext()?.mediaKey || '';
}

function lyrV48IsRootForActiveContext(comment) {
  if (!comment || comment.parentId) return false;
  const wanted = lyrV48ActiveMediaKey();
  const own = String(comment.mediaKey || '');
  return wanted ? own === wanted : !own;
}

async function lyrV48BumpCommentCount(delta, diagnosticLabel = '[comment counter]') {
  const postId = state.activePostId;
  if (!postId || !delta) return;
  const ctx = lyrV48PhotoContext();
  try {
    if (!ctx) {
      await updateDoc(doc(db, 'posts', postId), { commentsCount: increment(delta) });
      return;
    }
    const mediaRef = doc(db, 'posts', postId, 'media', ctx.mediaKey);
    const next = await runTransaction(db, async tx => {
      const snap = await tx.get(mediaRef);
      const current = Math.max(0, Number(snap.exists() ? snap.data().commentsCount || 0 : 0));
      const value = Math.max(0, current + Number(delta || 0));
      tx.set(mediaRef, {
        postId,
        url: ctx.url || '',
        index: Number(ctx.index) || 0,
        commentsCount: value,
        updatedAt: serverTimestamp()
      }, { merge:true });
      return value;
    });
    document.querySelectorAll(`.lyr-v47-photo-interactions[data-media-key="${CSS.escape(ctx.mediaKey)}"]`).forEach(row => {
      const el = row.querySelector('[data-v47-comment-count]');
      if (el) el.textContent = next ? String(next) : '';
    });
  } catch (err) {
    console.warn(diagnosticLabel, err);
  }
}

function lyrV48EnsureFullCommentsOverlay() {
  let root = document.getElementById('lyr-v48-comments-overlay');
  if (root) return root;
  root = document.createElement('div');
  root.id = 'lyr-v48-comments-overlay';
  root.className = 'lyr-v48-comments-overlay hidden';
  root.innerHTML = `
    <section class="lyr-v48-comments-sheet" role="dialog" aria-modal="true" aria-label="Commentaires">
      <div class="lyr-v48-sheet-handle" aria-hidden="true"></div>
      <header class="lyr-v48-comments-head">
        <div>
          <strong data-v48-title>${escapeHtml(uiText('Commentaires','Hevitra','Comments'))}</strong>
          <small data-v48-subtitle></small>
        </div>
        <button type="button" data-v48-close class="lyr-v48-comments-close" aria-label="${escapeHtml(uiText('Fermer','Hidio','Close'))}">×</button>
      </header>
      <div class="lyr-v48-comments-slot" data-v48-slot></div>
    </section>`;
  document.body.appendChild(root);
  root.querySelector('[data-v48-close]')?.addEventListener('click', () => lyrV48CloseCommentsSheet());
  root.addEventListener('click', e => { if (e.target === root) lyrV48CloseCommentsSheet(); });
  return root;
}

function lyrV48MountNativeComments(root) {
  const section = document.querySelector('#screen-post-detail .comments-section') || document.querySelector('.comments-section');
  const slot = root?.querySelector('[data-v48-slot]');
  if (!section || !slot) return null;
  if (!lyrV48SheetState?.homeParent) {
    const homeParent = section.parentNode;
    const homeNext = section.nextSibling;
    lyrV48SheetState = { ...(lyrV48SheetState || {}), homeParent, homeNext };
  }
  slot.appendChild(section);
  section.classList.add('lyr-v48-native-comments');
  return section;
}

function lyrV48RestoreNativeComments() {
  const section = document.querySelector('.comments-section.lyr-v48-native-comments');
  const parent = lyrV48SheetState?.homeParent;
  if (!section || !parent) return;
  section.classList.remove('lyr-v48-native-comments');
  const next = lyrV48SheetState?.homeNext;
  if (next && next.parentNode === parent) parent.insertBefore(section, next);
  else parent.appendChild(section);
}

function lyrV48CloseCommentsSheet({ restoreState = true } = {}) {
  if (listeners.comments) { try { listeners.comments(); } catch (_) {} listeners.comments = null; }
  closeCommentThread();
  closeEmojiPickers();
  document.getElementById('comment-sticker-picker')?.classList.add('hidden');
  hideCommentMentionSuggestions();
  resetCommentComposer();
  lyrV48RestoreNativeComments();
  document.getElementById('lyr-v48-comments-overlay')?.classList.add('hidden');
  document.documentElement.classList.remove('lyr-v48-comments-open');
  if (restoreState && lyrV48SheetState) {
    state.activePostId = lyrV48SheetState.previousActivePostId || null;
    state.activePostAuthorId = lyrV48SheetState.previousPostAuthorId || '';
  }
  state.activePhotoCommentContext = null;
  const homeParent = lyrV48SheetState?.homeParent || null;
  const homeNext = lyrV48SheetState?.homeNext || null;
  lyrV48SheetState = homeParent ? { homeParent, homeNext } : null;
}

async function lyrV48OpenFullComments(target) {
  if (!target?.post?.id) return;
  // Close the simplified V47 sheet if it had ever been created.
  const old = document.getElementById('lyr-v47-comments-overlay');
  old?.classList.add('hidden');
  document.documentElement.classList.remove('lyr-v47-comments-open');
  if (lyrV47CommentsUnsub) { try { lyrV47CommentsUnsub(); } catch (_) {} lyrV47CommentsUnsub = null; }

  const previousActivePostId = state.activePostId || null;
  const previousPostAuthorId = state.activePostAuthorId || '';
  const root = lyrV48EnsureFullCommentsOverlay();
  const section = document.querySelector('.comments-section');
  const homeParent = section?.parentNode || lyrV48SheetState?.homeParent || null;
  const homeNext = section?.nextSibling || lyrV48SheetState?.homeNext || null;
  lyrV48SheetState = { homeParent, homeNext, previousActivePostId, previousPostAuthorId };

  state.activePostId = target.post.id;
  state.activePostAuthorId = target.post.authorId || '';
  state.activePhotoCommentContext = target.kind === 'photo' ? {
    postId: target.post.id,
    mediaKey: lyrV47MediaKey(target.item, target.index),
    url: safeUrl(target.item?.url),
    index: Number(target.index) || 0
  } : null;
  state.commentsExpanded = true;
  state.commentsCollapsed = false;
  resetCommentComposer();

  const title = root.querySelector('[data-v48-title]');
  const subtitle = root.querySelector('[data-v48-subtitle]');
  if (target.kind === 'photo') {
    if (title) title.textContent = uiText('Commentaires de la photo','Hevitra amin’ity sary ity','Photo comments');
    if (subtitle) subtitle.textContent = uiText(`Photo ${Number(target.index)+1}`, `Sary ${Number(target.index)+1}`, `Photo ${Number(target.index)+1}`);
  } else {
    if (title) title.textContent = uiText('Commentaires','Hevitra rehetra','Comments');
    if (subtitle) subtitle.textContent = uiText('Publication','Publication','Post');
  }

  lyrV48MountNativeComments(root);
  root.classList.remove('hidden');
  document.documentElement.classList.add('lyr-v48-comments-open');
  startCommentsListener(target.post.id);
  applyFullCommentsCollapse();
  updateCommentSubmitState();
  // V50: montrer d'abord les commentaires; le clavier ne s'ouvre que si l'utilisateur touche le champ.
}

// Replace the V47 simplified sheet with the complete native LYRAME comment system.
lyrV47OpenCommentsSheet = function(target) {
  lyrV48OpenFullComments(target).catch(err => {
    console.warn('[V48 open comments]', err);
    toast(uiText('Impossible d’ouvrir les commentaires.','Tsy afaka manokatra hevitra.','Unable to open comments.'));
  });
};

lyrV47CloseCommentsSheet = function() {
  lyrV48CloseCommentsSheet();
};

// Full listener, but roots are isolated by mediaKey when a photo is active.
startCommentsListener = function(postId) {
  if (listeners.comments) listeners.comments();
  toggleEmpty('comments-empty', true);
  const q = query(collection(db, 'posts', postId, 'comments'), orderBy('createdAt', 'asc'), limit(COMMENTS_LIMIT));
  listeners.comments = onSnapshot(q, snap => {
    const commentsList = $('#comments-list');
    if (!commentsList) return;
    commentsList.querySelectorAll('.comment').forEach(n => n.remove());
    const all = snap.docs.map(d => ({ id:d.id, ...d.data() }));
    const roots = all.filter(lyrV48IsRootForActiveContext);
    const rootIds = new Set(roots.map(c => c.id));
    const replies = all.filter(c => c.parentId && rootIds.has(c.parentId));
    if (!roots.length) {
      toggleEmpty('comments-empty', false);
      updateCommentsToggle();
    } else {
      toggleEmpty('comments-empty', true);
      roots.forEach(c => commentsList.appendChild(renderComment(c, replies.filter(r => r.parentId === c.id))));
      applyCommentsVisibility();
      updateCommentsToggle();
    }
    const ctx = lyrV48PhotoContext();
    if (ctx) {
      const visibleCount = roots.length + replies.length;
      document.querySelectorAll(`.lyr-v47-photo-interactions[data-media-key="${CSS.escape(ctx.mediaKey)}"]`).forEach(row => {
        const c = row.querySelector('[data-v47-comment-count]');
        if (c) c.textContent = visibleCount ? String(visibleCount) : '';
      });
    }
  }, err => logError('[comments listener]', err));
};

sendQuickCommentContent = async function({ text = '', stickerId = '', parentId = null, replyTarget = null, isAnonymous = false } = {}) {
  if (!state.currentUser || !state.activePostId || commentQuickSendBusy) return false;
  const cleanText = String(text || '').trim().slice(0, 2000);
  const sticker = stickerById(stickerId);
  if (!cleanText && !sticker) return false;
  commentQuickSendBusy = true;
  try {
    const postId = state.activePostId;
    const uid = state.currentUser.uid;
    const p = state.currentProfile || {};
    const postRef = doc(db, 'posts', postId);
    const newRef = doc(collection(db, 'posts', postId, 'comments'));
    const postSnap = await getDoc(postRef);
    if (!postSnap.exists()) throw new Error('POST_NOT_FOUND');
    const postAuthorId = postSnap.data().authorId || '';
    await setDoc(newRef, {
      authorId:uid,
      authorName:p.fullname || state.currentUser.displayName || '',
      authorUsername:p.username || '',
      authorPhotoURL:p.photoURL || '',
      authorBadgeType:badgeTypeOf(p),
      isAnonymous:!!isAnonymous,
      text:cleanText,
      mentions:[], imageURL:'', imagePublicId:'', mediaURL:'', mediaPublicId:'', mediaType:'',
      stickerId:sticker?.id || '', stickerTone:sticker?.tone || '',
      mediaKey:lyrV48ActiveMediaKey(),
      parentId:parentId || null,
      replyToUsername:replyTarget?.authorUsername || replyTarget?.username || '',
      createdAt:serverTimestamp()
    });
    await lyrV48BumpCommentCount(1, '[quick comment counter]');
    const who = p.fullname || uiSomeone();
    if (postAuthorId && postAuthorId !== uid) {
      createNotification({
        id:`comment_${postId}_${newRef.id}`, userId:postAuthorId, actorId:uid, type:'comment',
        title:uiText('Nouveau commentaire','Hevitra vaovao','New comment'),
        preview:`${who} ${lyrV48PhotoContext() ? uiText('a commenté votre photo.','nametraka hevitra tamin’ny sarinao.','commented on your photo.') : uiText('a commenté votre publication.','nametraka hevitra tamin’ny publication-nao.','commented on your post.')}`,
        extra:{postId}
      }).catch(err => console.warn('[quick comment notification]', err));
    }
    const parentAuthorId = replyTarget?.authorId || '';
    if (parentAuthorId && parentAuthorId !== uid && parentAuthorId !== postAuthorId) {
      createNotification({
        id:`reply_${postId}_${newRef.id}`, userId:parentAuthorId, actorId:uid, type:'reply',
        title:uiText('Nouvelle réponse','Valiny vaovao','New reply'),
        preview:`${who} ${uiText('a répondu à votre commentaire.','namaly ny hevitrao.','replied to your comment.')}`,
        extra:{postId}
      }).catch(err => console.warn('[quick reply notification]', err));
    }
    return true;
  } catch (err) {
    logError('[quick comment]', err);
    toast(firestoreWriteErrorLabel(err, t('err_generic')));
    return false;
  } finally { commentQuickSendBusy = false; }
};

const lyrV48OldHandleCommentSubmit = handleCommentSubmit;
handleCommentSubmit = async function(e) {
  e.preventDefault();
  if (!state.currentUser || !state.activePostId || state.uploading) return;
  const ta = $('#comment-text');
  const text = (ta?.value || '').trim().slice(0,2000);
  const mediaFile = state.commentImageFile;
  if (!text && !mediaFile) { toast(t('err_empty_comment')); return; }
  const postId = state.activePostId;
  const uid = state.currentUser.uid;
  const reply = state.commentReplyTo;
  const parentId = reply ? reply.id : null;
  const mentions = collectCommentMentions(text, state.commentMentionSelections);
  const btn = e.target?.querySelector?.('button[type="submit"]') || $('#comment-submit-btn');
  state.uploading = true; updateCommentSubmitState(); setBusy(btn,true,'...');
  try {
    let mediaURL='', mediaPublicId='';
    if (mediaFile) {
      try {
        const up = await uploadMedia(mediaFile,{folder:`lyrame/comments/${uid}`,resourceType:'image'});
        mediaURL=up.url; mediaPublicId=up.publicId;
      } catch (upErr) { logError('[comment upload]',upErr); toast(t('err_image_upload')); return; }
    }
    const p=state.currentProfile || {};
    const postRef=doc(db,'posts',postId);
    const newRef=doc(collection(db,'posts',postId,'comments'));
    const postSnap=await getDoc(postRef);
    if(!postSnap.exists()) throw new Error('POST_NOT_FOUND');
    const postAuthorId=postSnap.data().authorId || '';
    await setDoc(newRef,{
      authorId:uid, authorName:p.fullname || state.currentUser.displayName || '', authorUsername:p.username || '',
      authorPhotoURL:p.photoURL || '', authorBadgeType:badgeTypeOf(p), isAnonymous:!!state.commentAnonymous,
      text, mentions, imageURL:mediaURL, imagePublicId:mediaPublicId, mediaURL, mediaPublicId,
      mediaType:mediaFile ? 'image' : '', mediaKey:lyrV48ActiveMediaKey(), parentId:parentId || null,
      replyToUsername:reply?.username || '', createdAt:serverTimestamp()
    });
    await lyrV48BumpCommentCount(1,'[comment counter]');
    const who=p.fullname || uiSomeone();
    resetCommentComposer(); toast(t('msg_comment_added'));
    if(postAuthorId && postAuthorId !== uid){
      createNotification({id:`comment_${postId}_${newRef.id}`,userId:postAuthorId,actorId:uid,type:'comment',
        title:uiText('Nouveau commentaire','Hevitra vaovao','New comment'),
        preview:`${who} ${lyrV48PhotoContext() ? uiText('a commenté votre photo.','nametraka hevitra tamin’ny sarinao.','commented on your photo.') : uiText('a commenté votre publication.','nametraka hevitra tamin’ny publication-nao.','commented on your post.')}`,
        extra:{postId}}).catch(err=>console.warn('[comment notification]',err));
    }
    const parentAuthorId=reply?.authorId || '';
    if(parentAuthorId && parentAuthorId !== uid && parentAuthorId !== postAuthorId){
      createNotification({id:`reply_${postId}_${newRef.id}`,userId:parentAuthorId,actorId:uid,type:'reply',
        title:uiText('Nouvelle réponse','Valiny vaovao','New reply'),
        preview:`${who} ${uiText('a répondu à votre commentaire.','namaly ny hevitrao.','replied to your comment.')}`,
        extra:{postId}}).catch(err=>console.warn('[reply notification]',err));
    }
    notifyCommentMentions(mentions,{postId,commentId:newRef.id,actorName:who}).catch(err=>console.warn('[mention notification]',err));
  } catch(err){ logError('[comment]',err); toast(firestoreWriteErrorLabel(err,t('err_generic'))); }
  finally { state.uploading=false; setBusy(btn,false); updateCommentSubmitState(); }
};

// The submit listener was registered before this V48 override; replace that captured V46 handler.
const lyrV48CommentForm = document.getElementById('comment-form');
if (lyrV48CommentForm) {
  lyrV48CommentForm.removeEventListener('submit', lyrV48OldHandleCommentSubmit);
  lyrV48CommentForm.addEventListener('submit', handleCommentSubmit);
}

deleteComment = async function(comment, hasReplies = false) {
  if (!state.currentUser || !state.activePostId || !comment?.id) return;
  const uid=state.currentUser.uid;
  try {
    const postRef=doc(db,'posts',state.activePostId);
    const postSnap=await getDoc(postRef);
    if(!postSnap.exists()) return;
    const post=postSnap.data();
    const allowed=comment.authorId===uid || post.authorId===uid;
    if(!allowed){ toast(t('err_no_permission')); return; }
    const ok=await showConfirm({
      title:uiText('Supprimer le commentaire','Hamafa hevitra','Delete comment'),
      message:uiText('Supprimer ce commentaire ?','Hofafana ve ity hevitra ity?','Delete this comment?'),
      confirmText:t('delete'), danger:true
    });
    if(!ok) return;
    const commentRef=doc(db,'posts',state.activePostId,'comments',comment.id);
    if(hasReplies){
      await updateDoc(commentRef,{deleted:true,text:'',imageURL:'',imagePublicId:'',mediaURL:'',mediaPublicId:'',mediaType:'',updatedAt:serverTimestamp()});
      return;
    }
    await deleteDoc(commentRef);
    await lyrV48BumpCommentCount(-1,'[delete comment counter]');
  } catch(err){ logError('[delete comment]',err); toast(t('err_generic')); }
};

// If a true post-detail screen is opened elsewhere, restore the native section first.
const lyrV48OriginalOpenPostDetail = openPostDetail;
openPostDetail = async function(postId) {
  if (document.documentElement.classList.contains('lyr-v48-comments-open')) lyrV48CloseCommentsSheet();
  state.activePhotoCommentContext = null;
  return lyrV48OriginalOpenPostDetail(postId);
};

window.addEventListener('keydown', e => {
  if (e.key === 'Escape' && document.documentElement.classList.contains('lyr-v48-comments-open')) lyrV48CloseCommentsSheet();
});

/* ================================================================
   LYRAME WEB V49 — MENTIONS + VIEWPORT COMMENTAIRES
   Conserve toutes les fonctions V48 (réponses, réactions, emoji, stickers,
   image, suppression) et corrige uniquement les deux points demandés.
   ================================================================ */

function lyrV49EnsureMentionChipbar() {
  const form = document.getElementById('comment-form');
  if (!form) return null;
  let bar = form.querySelector('.lyr-v49-mention-chipbar');
  if (!bar) {
    bar = document.createElement('div');
    bar.className = 'lyr-v49-mention-chipbar';
    bar.setAttribute('aria-label', uiText('Personnes et Pages mentionnées','Olona sy Page voatonona','Mentioned people and Pages'));
    const composer = form.querySelector('.comment-composer');
    if (composer) form.insertBefore(bar, composer);
    else form.prepend(bar);
  }
  return bar;
}

function lyrV49RenderMentionChips() {
  const bar = lyrV49EnsureMentionChipbar();
  if (!bar) return;
  const values = Array.from(state.commentMentionSelections?.entries?.() || []);
  bar.replaceChildren();
  bar.classList.toggle('has-items', values.length > 0);
  values.forEach(([key, item]) => {
    const chip = document.createElement('span');
    chip.className = 'lyr-v49-mention-chip';
    chip.dataset.mentionKey = key;
    const label = document.createElement('span');
    label.textContent = item.label || item.token || '';
    const remove = document.createElement('button');
    remove.type = 'button';
    remove.setAttribute('aria-label', uiText('Retirer la mention','Esory ny mention','Remove mention'));
    remove.textContent = '×';
    remove.addEventListener('click', e => {
      e.preventDefault(); e.stopPropagation();
      state.commentMentionSelections?.delete?.(key);
      lyrV49RenderMentionChips();
      updateCommentSubmitState();
      document.getElementById('comment-text')?.focus();
    });
    chip.append(label, remove);
    bar.appendChild(chip);
  });
}

const lyrV49BaseResetCommentComposer = resetCommentComposer;
resetCommentComposer = function() {
  lyrV49BaseResetCommentComposer();
  lyrV49RenderMentionChips();
};

// Dans le composeur principal, le @ sert uniquement à ouvrir le choix.
// Une fois sélectionné, le @ disparaît et le nom devient une pastille distincte.
const lyrV49BaseRefreshCommentMentionSuggestions = refreshCommentMentionSuggestions;
refreshCommentMentionSuggestions = async function(input, store) {
  if (!input || input.id !== 'comment-text') {
    return lyrV49BaseRefreshCommentMentionSuggestions(input, store);
  }
  const fragmentInfo = currentMentionFragment(input);
  if (!fragmentInfo) { hideCommentMentionSuggestions(); return; }
  const requestKey = `${fragmentInfo.start}:${fragmentInfo.fragment}:${Date.now()}`;
  input.dataset.mentionRequestKey = requestKey;
  const items = await loadEligibleCommentMentions();
  if (!input.isConnected || input.dataset.mentionRequestKey !== requestKey) return;
  const q = fragmentInfo.fragment.toLowerCase();
  const matches = items.filter(item => !q || item.token.toLowerCase().includes(q) || item.label.toLowerCase().includes(q)).slice(0, 10);
  hideCommentMentionSuggestions();
  if (!matches.length) return;

  const pop = document.createElement('div');
  pop.className = 'comment-mention-suggestions';
  matches.forEach(item => {
    const row = document.createElement('button');
    row.type = 'button';
    row.className = 'comment-mention-suggestion';
    const kindLabel = item.type === 'page' ? uiText('Page suivie','Page arahina','Followed Page') : uiText('Ami','Namana','Friend');
    const secondary = item.subtitle && item.subtitle !== item.label ? `${item.subtitle} · ${kindLabel}` : kindLabel;
    row.innerHTML = `<span class="avatar">${avatarMarkup(item.photoURL,item.label)}</span><span class="grow"><strong>${escapeHtml(item.label)}</strong><small>${escapeHtml(secondary)}</small></span>`;
    row.addEventListener('mousedown', e => e.preventDefault());
    row.addEventListener('click', e => {
      e.preventDefault(); e.stopPropagation();
      const info = currentMentionFragment(input);
      if (!info) return;
      // Supprime complètement @fragment du texte visible.
      let left = input.value.slice(0, info.start);
      let right = input.value.slice(info.end);
      if (left && right && !/\s$/.test(left) && !/^\s/.test(right)) left += ' ';
      input.value = (left + right).replace(/ {2,}/g,' ');
      const pos = Math.min(left.length, input.value.length);
      try { input.setSelectionRange(pos,pos); } catch (_) {}
      store.set(`${item.type}:${item.id}`, { type:item.type,id:item.id,token:item.token,label:item.label,chip:true });
      hideCommentMentionSuggestions();
      lyrV49RenderMentionChips();
      input.focus();
      resizeUnifiedCommentTextarea(input);
      updateCommentSubmitState();
      input.dispatchEvent(new Event('input',{bubbles:true}));
    });
    pop.appendChild(row);
  });
  document.body.appendChild(pop);
  activeCommentMentionPopup = pop;
  positionFixedNear(pop,input);
};

// Toutes les mentions sélectionnées sous forme de pastille sont de vraies mentions,
// même si leur @ n'est plus conservé dans le texte visible.
collectCommentMentions = function(text, store) {
  const value = String(text || '');
  return Array.from(store?.values?.() || []).filter(item => item?.chip || value.includes(`@${item.token}`)).map(item => ({
    type:item.type,id:item.id,token:item.token,label:item.label,chip:!!item.chip
  }));
};

const lyrV49BaseCommentTextWithMentions = commentTextWithMentions;
commentTextWithMentions = function(text, mentions) {
  const list = Array.isArray(mentions) ? mentions.filter(m => m?.token || m?.label) : [];
  const chips = list.filter(m => m.chip);
  const legacy = list.filter(m => !m.chip);
  const normal = lyrV49BaseCommentTextWithMentions(text, legacy);
  const prefix = chips.map(m => `<strong class="comment-mention" data-mention-type="${escapeHtml(m.type||'')}" data-mention-id="${escapeHtml(m.id||'')}">${escapeHtml(m.label||m.token||'')}</strong>`).join(' ');
  return `${prefix}${prefix && normal ? ' ' : ''}${normal}`;
};

// Le bouton @ doit ouvrir immédiatement amis + Pages suivies.
document.addEventListener('click', e => {
  const btn = e.target?.closest?.('#comment-mention-btn');
  if (!btn) return;
  setTimeout(() => {
    const input = document.getElementById('comment-text');
    if (input) refreshCommentMentionSuggestions(input,state.commentMentionSelections);
  },0);
});

// Permet un commentaire composé uniquement d'une mention sélectionnée.
const lyrV49OldHandleCommentSubmit = handleCommentSubmit;
handleCommentSubmit = async function(e) {
  const ta = document.getElementById('comment-text');
  const hasMention = !!state.commentMentionSelections?.size;
  if (hasMention && ta && !(ta.value || '').trim() && !state.commentImageFile) {
    // Espace non significatif : V48 continuera, puis collectCommentMentions fournira la mention.
    ta.value = ' ';
    try { await lyrV49OldHandleCommentSubmit(e); }
    finally { if ((ta.value || '') === ' ') ta.value = ''; }
    return;
  }
  return lyrV49OldHandleCommentSubmit(e);
};
const lyrV49CommentForm = document.getElementById('comment-form');
if (lyrV49CommentForm) {
  // V48 avait attaché exactement la fonction capturée ci-dessus : on la remplace proprement.
  lyrV49CommentForm.removeEventListener('submit', lyrV49OldHandleCommentSubmit);
  lyrV49CommentForm.addEventListener('submit', handleCommentSubmit);
}

function lyrV49SyncCommentsViewport() {
  const root = document.getElementById('lyr-v48-comments-overlay');
  if (!root || root.classList.contains('hidden')) return;
  root.classList.add('lyr-v49-comments-viewport');
  const vv = window.visualViewport;
  const top = vv ? vv.offsetTop : 0;
  const left = vv ? vv.offsetLeft : 0;
  const width = vv ? vv.width : window.innerWidth;
  const height = vv ? vv.height : window.innerHeight;
  root.style.setProperty('--lyr-v49-vv-top',`${Math.max(0,top)}px`);
  root.style.setProperty('--lyr-v49-vv-left',`${Math.max(0,left)}px`);
  root.style.setProperty('--lyr-v49-vv-width',`${Math.max(1,width)}px`);
  root.style.setProperty('--lyr-v49-vv-height',`${Math.max(1,height)}px`);
}

const lyrV49BaseOpenFullComments = lyrV48OpenFullComments;
lyrV48OpenFullComments = async function(target) {
  await lyrV49BaseOpenFullComments(target);
  const root = document.getElementById('lyr-v48-comments-overlay');
  root?.classList.add('lyr-v49-comments-viewport');
  lyrV49RenderMentionChips();
  lyrV49SyncCommentsViewport();
  requestAnimationFrame(() => {
    lyrV49SyncCommentsViewport();
    const list = document.getElementById('comments-list');
    if (list) list.scrollTop = list.scrollHeight;
  });
};

const lyrV49BaseCloseCommentsSheet = lyrV48CloseCommentsSheet;
lyrV48CloseCommentsSheet = function(options) {
  const root = document.getElementById('lyr-v48-comments-overlay');
  root?.classList.remove('lyr-v49-comments-viewport');
  return lyrV49BaseCloseCommentsSheet(options);
};

window.visualViewport?.addEventListener('resize',lyrV49SyncCommentsViewport);
window.visualViewport?.addEventListener('scroll',lyrV49SyncCommentsViewport);
window.addEventListener('resize',lyrV49SyncCommentsViewport);

// Chaque nouvelle arrivée garde le dernier commentaire accessible au-dessus du composeur.
const lyrV49BaseStartCommentsListener = startCommentsListener;
startCommentsListener = function(postId) {
  lyrV49BaseStartCommentsListener(postId);
  setTimeout(() => {
    const list = document.getElementById('comments-list');
    if (list && document.documentElement.classList.contains('lyr-v48-comments-open')) {
      list.scrollTop = list.scrollHeight;
    }
  },120);
};


/* ================================================================
   LYRAME WEB V50 — PHOTO COMMENTS AU-DESSUS DU VIEWER + MENTIONS INLINE
   - Le panneau commentaires d'une photo passe réellement au-dessus du viewer.
   - Pas d'ouverture automatique du clavier : les commentaires sont visibles d'abord.
   - Pendant la saisie : "Ianao @rakoto dia tsotra".
   - Après publication : "Ianao rakoto dia tsotra", rakoto garde la couleur mention.
   - La mention reste une vraie mention et conserve la notification.
   ================================================================ */

// V49 avait transformé la mention choisie en pastille séparée. V50 rétablit
// la mention à sa place exacte dans la phrase : @token dans le textarea,
// puis rendu coloré sans @ après publication.
refreshCommentMentionSuggestions = async function(input, store) {
  const fragmentInfo = currentMentionFragment(input);
  if (!fragmentInfo) { hideCommentMentionSuggestions(); return; }
  const requestKey = `${fragmentInfo.start}:${fragmentInfo.fragment}:${Date.now()}`;
  input.dataset.mentionRequestKey = requestKey;
  const items = await loadEligibleCommentMentions();
  if (!input.isConnected || input.dataset.mentionRequestKey !== requestKey) return;
  const q = fragmentInfo.fragment.toLowerCase();
  const matches = items.filter(item => !q || item.token.toLowerCase().includes(q) || String(item.label||'').toLowerCase().includes(q)).slice(0,10);
  hideCommentMentionSuggestions();
  if (!matches.length) return;

  const pop = document.createElement('div');
  pop.className = 'comment-mention-suggestions lyr-v50-mention-suggestions';
  matches.forEach(item => {
    const row = document.createElement('button');
    row.type = 'button';
    row.className = 'comment-mention-suggestion';
    const kindLabel = item.type === 'page' ? uiText('Page suivie','Page arahina','Followed Page') : uiText('Ami','Namana','Friend');
    const secondary = item.subtitle && item.subtitle !== item.label ? `${item.subtitle} · ${kindLabel}` : kindLabel;
    row.innerHTML = `<span class="avatar">${avatarMarkup(item.photoURL,item.label)}</span><span class="grow"><strong>${escapeHtml(item.label)}</strong><small>${escapeHtml(secondary)}</small></span>`;
    row.addEventListener('mousedown', e => e.preventDefault());
    row.addEventListener('click', e => {
      e.preventDefault(); e.stopPropagation();
      const info = currentMentionFragment(input);
      if (!info) return;
      const replacement = `@${item.token} `;
      input.value = input.value.slice(0,info.start) + replacement + input.value.slice(info.end);
      const pos = info.start + replacement.length;
      try { input.setSelectionRange(pos,pos); } catch (_) {}
      store.set(`${item.type}:${item.id}`, { type:item.type,id:item.id,token:item.token,label:item.label,chip:false });
      hideCommentMentionSuggestions();
      const chipbar = document.querySelector('.lyr-v49-mention-chipbar');
      if (chipbar) { chipbar.replaceChildren(); chipbar.classList.remove('has-items'); chipbar.style.display='none'; }
      input.focus();
      resizeUnifiedCommentTextarea(input);
      updateCommentSubmitState();
      input.dispatchEvent(new Event('input',{bubbles:true}));
    });
    pop.appendChild(row);
  });
  document.body.appendChild(pop);
  activeCommentMentionPopup = pop;
  positionFixedNear(pop,input);
};

collectCommentMentions = function(text, store) {
  const value = String(text || '');
  return Array.from(store?.values?.() || []).filter(item => item?.token && value.includes(`@${item.token}`)).map(item => ({
    type:item.type,id:item.id,token:item.token,label:item.label,chip:false
  }));
};

commentTextWithMentions = function(text, mentions) {
  const raw = String(text || '');
  const list = Array.isArray(mentions) ? mentions.filter(m => m?.token) : [];
  if (!list.length) return escapeHtml(raw);
  const byLength = [...list].sort((a,b) => String(b.token).length - String(a.token).length);
  let out = '';
  for (let i=0;i<raw.length;) {
    let hit = null;
    if (raw[i] === '@') hit = byLength.find(m => raw.startsWith(`@${m.token}`,i));
    if (hit) {
      const end = i + String(hit.token).length + 1;
      const next = raw[end] || '';
      if (!next || /[\s.,!?;:()\[\]{}'"\-]/.test(next)) {
        out += `<strong class="comment-mention" data-mention-type="${escapeHtml(hit.type||'')}" data-mention-id="${escapeHtml(hit.id||'')}">${escapeHtml(hit.label||hit.token)}</strong>`;
        i = end;
        continue;
      }
    }
    out += escapeHtml(raw[i]);
    i += 1;
  }
  return out;
};

// Plus de pastille de mention séparée dans le composeur V50.
const lyrV50OldRenderMentionChips = lyrV49RenderMentionChips;
lyrV49RenderMentionChips = function() {
  const bar = document.querySelector('.lyr-v49-mention-chipbar');
  if (bar) { bar.replaceChildren(); bar.classList.remove('has-items'); bar.style.display='none'; }
};

// Les commentaires photo doivent être devant le viewer, pas derrière lui.
const lyrV50BaseOpenFullComments = lyrV48OpenFullComments;
lyrV48OpenFullComments = async function(target) {
  await lyrV50BaseOpenFullComments(target);
  const root = document.getElementById('lyr-v48-comments-overlay');
  if (root) {
    root.classList.add('lyr-v50-comments-above-viewer');
    root.setAttribute('aria-hidden','false');
  }
  const input = document.getElementById('comment-text');
  try { input?.blur(); } catch (_) {}
  const list = document.getElementById('comments-list');
  requestAnimationFrame(() => { if (list) list.scrollTop = list.scrollHeight; });
};

const lyrV50BaseCloseComments = lyrV48CloseCommentsSheet;
lyrV48CloseCommentsSheet = function(options) {
  document.getElementById('lyr-v48-comments-overlay')?.classList.remove('lyr-v50-comments-above-viewer');
  return lyrV50BaseCloseComments(options);
};

// Si le thread Répondre s'ouvre depuis les commentaires d'une photo, il reste
// lui aussi au-dessus du viewer.
const lyrV50ThreadObserver = new MutationObserver(() => {
  document.querySelectorAll('.comment-thread-overlay').forEach(el => el.classList.add('lyr-v50-thread-above-viewer'));
  document.getElementById('comment-sticker-picker')?.classList.add('lyr-v50-sticker-above-viewer');
});
if (document.body) lyrV50ThreadObserver.observe(document.body,{childList:true,subtree:true});

/* ================================================================
   LYRAME WEB V51 — PROFILS CLIQUABLES PARTOUT
   - avatar + nom d'un utilisateur ouvrent son profil partout où l'identité
     est affichée sans remplacer l'action principale du contenu ;
   - conversation directe : avatar/nom ouvrent le profil, le reste de la
     ligne continue d'ouvrir la conversation ;
   - mentions publiées : le nom coloré ouvre le profil ou la Page ;
   - stories : avatar/nom ouvrent le profil/Page, le média garde l'ouverture
     normale de la story ;
   - notifications : le nom de l'acteur devient cliquable quand il est connu.
   ================================================================ */

function lyrV51OpenEntityProfile(type, id) {
  id = String(id || '').trim();
  if (!id) return;
  if (type === 'page') {
    state.activePageId = id;
    showScreen('page-detail');
    return;
  }
  if (state.currentUser?.uid === id) {
    state.profileViewUid = null;
    showScreen('profile-me');
  } else {
    openOtherProfile(id);
  }
}

function lyrV51MarkProfileTarget(el, id, type = 'user') {
  if (!el || !id) return el;
  el.dataset.lyrProfileId = String(id);
  el.dataset.lyrProfileType = type === 'page' ? 'page' : 'user';
  el.classList.add('lyr-v51-profile-link');
  if (!/^(A|BUTTON|INPUT|TEXTAREA|SELECT)$/.test(el.tagName || '')) {
    el.setAttribute('role', 'button');
    if (!el.hasAttribute('tabindex')) el.tabIndex = 0;
  }
  return el;
}

// Posts du fil : l'avatar et le nom ouvrent le profil auteur.
const lyrV51BaseRenderPostCard = renderPostCard;
renderPostCard = function(post) {
  const card = lyrV51BaseRenderPostCard(post);
  if (card && post?.authorId) {
    lyrV51MarkProfileTarget(card.querySelector('.post-head .avatar'), post.authorId, 'user');
    lyrV51MarkProfileTarget(card.querySelector('.post-author-name'), post.authorId, 'user');
  }
  return card;
};

// Commentaires + réponses : avatar et nom ouvrent le profil auteur.
const lyrV51BaseRenderComment = renderComment;
renderComment = function(c, replies, parentId) {
  const row = lyrV51BaseRenderComment(c, replies, parentId);
  if (row && c?.authorId && !c?.isAnonymous) {
    lyrV51MarkProfileTarget(row.querySelector('.avatar'), c.authorId, 'user');
    lyrV51MarkProfileTarget(row.querySelector('.comment-name'), c.authorId, 'user');
  }
  return row;
};

// Cartes utilisateurs standard (recherche, amis, abonnés, demandes...).
const lyrV51BaseRenderUserCard = renderUserCard;
renderUserCard = function(u) {
  const row = lyrV51BaseRenderUserCard(u);
  if (row && u?.uid) {
    lyrV51MarkProfileTarget(row.querySelector('.avatar'), u.uid, 'user');
    lyrV51MarkProfileTarget(row.querySelector('.name'), u.uid, 'user');
  }
  return row;
};

// V57: Dans Messages, toucher l'avatar/le nom ouvre le CHAT, jamais le profil.
// Aucune cible de profil n'est attachée aux lignes de conversations.
const lyrV51BaseRenderConversationItem = renderConversationItem;
renderConversationItem = function(c) {
  const row = lyrV51BaseRenderConversationItem(c);
  row?.querySelectorAll('[data-lyr-profile-id]').forEach(el=>{
    delete el.dataset.lyrProfileId;delete el.dataset.lyrProfileType;
    el.classList.remove('lyr-v51-profile-link');
  });
  return row;
};

// Notifications : rend uniquement le nom de l'acteur cliquable sans casser la cible normale de la notification.
const lyrV51BaseRenderNotification = renderNotification;
renderNotification = function(n) {
  const row = lyrV51BaseRenderNotification(n);
  if (!row || !n?.actorId || !n?.actorName) return row;
  const preview = row.querySelector('.preview');
  if (!preview) return row;
  const full = preview.textContent || '';
  const who = String(n.actorName || '');
  if (!full.startsWith(who)) return row;
  preview.replaceChildren();
  const actor = document.createElement('strong');
  actor.textContent = who;
  actor.className = 'lyr-v51-notif-actor';
  lyrV51MarkProfileTarget(actor, n.actorId, 'user');
  preview.append(actor, document.createTextNode(full.slice(who.length)));
  return row;
};

// Galerie du viewer historique : avatar + nom de l'auteur.
const lyrV51BaseRenderMediaViewer = renderMediaViewer;
renderMediaViewer = function() {
  const out = lyrV51BaseRenderMediaViewer();
  const post = state.mediaViewerPost;
  if (post?.authorId) {
    document.querySelectorAll('#media-viewer-stage .lyr-v41-gallery-head').forEach(head => {
      lyrV51MarkProfileTarget(head.querySelector('.avatar'), post.authorId, 'user');
      lyrV51MarkProfileTarget(head.querySelector('.lyr-v41-gallery-author strong'), post.authorId, 'user');
    });
    lyrV51MarkProfileTarget(document.querySelector('#media-viewer-stage .media-viewer-info .avatar'), post.authorId, 'user');
    lyrV51MarkProfileTarget(document.querySelector('#media-viewer-stage .media-viewer-info strong'), post.authorId, 'user');
  }
  return out;
};

// Stories : la photo de profil et le nom sont distincts du média de la story.
const lyrV51BaseLoadStories = loadStories;
loadStories = async function() {
  const out = await lyrV51BaseLoadStories();
  const cards = Array.from(document.querySelectorAll('#stories-list .story-card'));
  cards.forEach((card, i) => {
    const meta = lyrameStoryV37?.cards?.[i];
    const st = meta?.head || lyrameStoryV37?.queue?.[i];
    if (!st) return;
    const type = meta?.profile?.type || (st.pageId ? 'page' : 'user');
    const id = meta?.profile?.id || st.pageId || st.authorId;
    if (!id) return;
    // V57 : toute la carte story ouvre le viewer, pas le profil.
    card.querySelectorAll('[data-lyr-profile-id]').forEach(el => {
      delete el.dataset.lyrProfileId;delete el.dataset.lyrProfileType;
      el.classList.remove('lyr-v51-profile-link');
    });
  });
  return out;
};

const lyrV51BaseOpenStoryIndex = lyrameOpenStoryIndex;
lyrameOpenStoryIndex = function(index) {
  const out = lyrV51BaseOpenStoryIndex(index);
  const st = lyrameStoryV37?.queue?.[Number(index)];
  const owner = document.querySelector('#story-viewer .story-view-owner');
  if (st && owner) {
    const type = st.pageId ? 'page' : 'user';
    const id = st.pageId || st.authorId;
    if (id) lyrV51MarkProfileTarget(owner, id, type);
  }
  return out;
};

// Page publications : l'identité de la Page reste cliquable.
document.addEventListener('click', e => {
  const pageIdentity = e.target?.closest?.('#page-posts .post-head .avatar, #page-posts .post-head strong');
  if (!pageIdentity || !state.activePageId) return;
  e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
  lyrV51OpenEntityProfile('page', state.activePageId);
}, true);

// Header d'une conversation directe : profil de l'autre utilisateur.
document.addEventListener('click', async e => {
  const hit = e.target?.closest?.('#conv-profile-avatar, #conv-header-info .name');
  if (!hit || !state.activeConv || state.activeConv.isGroup) return;
  e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
  try {
    const info = await resolveConversationInfo(state.activeConv);
    if (info?.otherUid) lyrV51OpenEntityProfile('user', info.otherUid);
  } catch (_) {}
}, true);

// Un seul gestionnaire capture pour toutes les cibles explicitement marquées
// et pour les mentions colorées publiées.
document.addEventListener('click', e => {
  // Les raccourcis dans Messages ouvrent la conversation même si un ancien
  // composant contient encore data-lyr-profile-id.
  if(e.target?.closest?.('#conversations-list .conv-item, #messages-stories .messages-story-person, #stories-list .story-card')) return;
  let target = e.target?.closest?.('[data-lyr-profile-id]');
  let id = target?.dataset?.lyrProfileId || '';
  let type = target?.dataset?.lyrProfileType || 'user';
  if (!target) {
    target = e.target?.closest?.('.comment-mention[data-mention-id]');
    if (target) {
      id = target.dataset.mentionId || '';
      type = target.dataset.mentionType === 'page' ? 'page' : 'user';
    }
  }
  if (!target || !id) return;
  e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
  lyrV51OpenEntityProfile(type, id);
}, true);

document.addEventListener('keydown', e => {
  if (e.key !== 'Enter' && e.key !== ' ') return;
  if(e.target?.closest?.('#conversations-list .conv-item, #messages-stories .messages-story-person, #stories-list .story-card')) return;
  const target = e.target?.closest?.('[data-lyr-profile-id], .comment-mention[data-mention-id]');
  if (!target) return;
  const id = target.dataset.lyrProfileId || target.dataset.mentionId || '';
  const type = (target.dataset.lyrProfileType || target.dataset.mentionType) === 'page' ? 'page' : 'user';
  if (!id) return;
  e.preventDefault(); e.stopPropagation();
  lyrV51OpenEntityProfile(type, id);
});

// Le viewer V46/V47 est construit séparément : si une identité auteur y apparaît,
// on la rend aussi cliquable après chaque rendu.
if (typeof lyrV46RenderViewer === 'function') {
  const lyrV51BaseV46RenderViewer = lyrV46RenderViewer;
  lyrV46RenderViewer = function() {
    const out = lyrV51BaseV46RenderViewer();
    const post = lyrV46ViewerState?.post;
    if (post?.authorId) {
      document.querySelectorAll('#lyr-v46-viewer .lyr-v41-gallery-head, #lyr-v46-viewer .post-head').forEach(head => {
        lyrV51MarkProfileTarget(head.querySelector('.avatar'), post.authorId, 'user');
        lyrV51MarkProfileTarget(head.querySelector('strong'), post.authorId, 'user');
      });
    }
    return out;
  };
}

/* ================================================================
   LYRAME WEB V52 — PROFILS COMMENTAIRES + LISTE DES RÉACTIONS
   - toute identité non anonyme dans les commentaires/réponses est cliquable ;
   - l'aperçu commentaire du fil garde l'ouverture des commentaires, mais son
     avatar/nom ouvre le profil ;
   - résumé des réactions : maximum 3 icônes + compteur ; seul le compteur
     ouvre la liste ;
   - liste filtrable par type, avec profil cliquable et bouton ami/suivre.
   ================================================================ */

// Réactions supplémentaires demandées, sans retirer les réactions existantes.
if (!REACTIONS.some(r => r.type === 'angry')) REACTIONS.push({ type:'angry', emoji:'😡', label:'Grr' });
if (!REACTIONS.some(r => r.type === 'cry')) REACTIONS.push({ type:'cry', emoji:'😭', label:'Pleure' });
const lyrV52BaseReactionLabel = reactionLabel;
reactionLabel = function(type) {
  if (type === 'angry') return uiText('En colère','Tezitra','Angry');
  if (type === 'cry') return uiText('Pleure','Mitomany','Crying');
  return lyrV52BaseReactionLabel(type);
};

function lyrV52ProfileOpen(uid) {
  uid = String(uid || '').trim();
  if (!uid) return;
  lyrV51OpenEntityProfile('user', uid);
}

// Renforce le rendu de TOUS les commentaires et réponses, y compris ceux
// reconstruits plus tard par les listeners photo/commentaires.
const lyrV52BaseRenderComment = renderComment;
renderComment = function(c, replies = [], rootId = null) {
  const row = lyrV52BaseRenderComment(c, replies, rootId);
  if (row && c?.authorId && !c?.isAnonymous) {
    row.dataset.lyrCommentAuthorId = String(c.authorId);
    const targets = [row.querySelector(':scope > .avatar'), row.querySelector(':scope > .comment-content .comment-name')].filter(Boolean);
    targets.forEach(el => lyrV51MarkProfileTarget(el, c.authorId, 'user'));
  }
  return row;
};

// Les aperçus de commentaire dans le fil sont créés hors de renderComment.
// L'avatar et le nom ouvrent le profil ; le reste du bloc ouvre toujours la publication/commentaires.
const lyrV52BaseHydrateFeedCommentPreview = hydrateFeedCommentPreview;
hydrateFeedCommentPreview = async function(card, post) {
  const out = await lyrV52BaseHydrateFeedCommentPreview(card, post);
  const row = card?.querySelector?.('.feed-comment-one');
  if (!row) return out;
  // L'aperçu V52 utilisait auparavant une seconde requête Firestore par
  // publication, pouvant produire un profil différent si un commentaire
  // arrivait entre les 2 requêtes. L'auteur est déjà connu de la ligne.
  const uid = row.dataset.lyrPreviewAuthorId || '';
  if (uid) {
    lyrV51MarkProfileTarget(row.querySelector('.feed-comment-avatar'), uid, 'user');
    lyrV51MarkProfileTarget(row.querySelector('.feed-comment-bubble strong'), uid, 'user');
  }
  return out;
};

// Filet de sécurité : toute identité de commentaire possédant un authorId est cliquable,
// même si le DOM provient d'un ancien renderer.
document.addEventListener('click', e => {
  const hit = e.target?.closest?.('.comment .avatar, .comment .comment-name, .thread-root .avatar, .thread-root .comment-name, .thread-reply .avatar, .thread-reply .comment-name');
  if (!hit) return;
  const row = hit.closest('.comment');
  const uid = row?.dataset?.lyrCommentAuthorId || hit.dataset?.lyrProfileId || '';
  if (!uid || row?.classList?.contains('comment-anonymous')) return;
  e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
  lyrV52ProfileOpen(uid);
}, true);

function lyrV52ReactionEmoji(type) {
  return REACTIONS.find(r => r.type === type)?.emoji || '👍';
}
function lyrV52ReactionTime(r) {
  return timestampMs(r.updatedAt || r.createdAt || 0);
}

async function lyrV52GetReactions(postId) {
  if (!postId) return [];
  try {
    const snap = await getDocs(query(collection(db,'posts',postId,'reactions'), limit(500)));
    return snap.docs.map(d => ({ id:d.id, ...d.data() })).sort((a,b)=>lyrV52ReactionTime(b)-lyrV52ReactionTime(a));
  } catch (err) {
    console.warn('[V52 reactions]', err);
    return [];
  }
}

async function lyrV52HydrateReactionSummary(card, post) {
  if (!card || !post?.id) return;
  const sequence = (card._lyrV53SummarySequence || 0) + 1;
  card._lyrV53SummarySequence = sequence;
  const count = Math.max(0, Number(post?.reactionsCount || 0) || 0);
  const countEl = card?.querySelector?.('.post-reaction-count');
  if (!countEl) return;
  countEl.classList.add('lyr-v52-reaction-count');
  countEl.dataset.v52ReactionPost = post.id;
  countEl.textContent = count ? postReactionCountLabel(count) : '';
  countEl.setAttribute('role','button');
  countEl.tabIndex = count ? 0 : -1;

  let icons = card.querySelector('.lyr-v52-reaction-icons');
  if (!icons) {
    icons = document.createElement('span');
    icons.className = 'lyr-v52-reaction-icons';
    countEl.before(icons);
  }
  icons.replaceChildren();
  if (!count) return;
  const rows = await lyrV52GetReactions(post.id);
  // Ne pas écraser l'interface avec la réponse d'une requête précédente.
  if (card._lyrV53SummarySequence !== sequence) return;
  const picked = [];
  for (const r of rows) {
    const type = r.type || 'like';
    if (!picked.includes(type)) picked.push(type);
    if (picked.length === 3) break;
  }
  picked.forEach(type => {
    const s = document.createElement('span');
    s.textContent = lyrV52ReactionEmoji(type);
    s.setAttribute('aria-hidden','true');
    icons.appendChild(s);
  });
}

const lyrV52BaseRenderPostCard = renderPostCard;
renderPostCard = function(post) {
  const card = lyrV52BaseRenderPostCard(post);
  Promise.resolve().then(()=>lyrV52HydrateReactionSummary(card,post)).catch(()=>{});
  return card;
};

// Chaque ouverture/filtre invalide les anciens résultats asynchrones.
let lyrV53ReactionViewRequest = 0;
function lyrV52EnsureReactionViewer() {
  let root = document.getElementById('lyr-v52-reactions');
  if (root) return root;
  root = document.createElement('section');
  root.id = 'lyr-v52-reactions';
  root.className = 'lyr-v52-reactions hidden';
  root.innerHTML = `
    <div class="lyr-v52-reaction-sheet" role="dialog" aria-modal="true" aria-label="Réactions">
      <header class="lyr-v52-reaction-head">
        <button type="button" class="icon-btn" data-v52-react-close aria-label="${escapeHtml(t('back'))}">←</button>
        <strong>${escapeHtml(uiText('Personnes ayant réagi','Olona naneho fihetseham-po','People who reacted'))}</strong>
      </header>
      <nav class="lyr-v52-reaction-tabs" data-v52-react-tabs></nav>
      <div class="lyr-v52-reaction-list" data-v52-react-list></div>
    </div>`;
  document.body.appendChild(root);
  root.querySelector('[data-v52-react-close]')?.addEventListener('click',()=>{ ++lyrV53ReactionViewRequest; root.classList.add('hidden'); });
  root.addEventListener('click', event => {
    if (event.target === root) { ++lyrV53ReactionViewRequest; root.classList.add('hidden'); }
  });
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape' && !root.classList.contains('hidden')) {
      ++lyrV53ReactionViewRequest;
      root.classList.add('hidden');
    }
  });
  return root;
}

async function lyrV52ReactionActionButton(uid) {
  if (!state.currentUser || !uid || uid === state.currentUser.uid) return null;
  const btn = document.createElement('button');
  btn.type = 'button';
  btn.className = 'lyr-v52-connect-btn';
  const sync = () => {
    const st = getFriendshipStatus(uid);
    btn.dataset.status = st.status;
    btn.textContent = st.status === 'friends' ? uiText('Amis','Namana','Friends')
      : st.status === 'request_sent' ? uiText('Envoyée','Nalefa','Sent')
      : st.status === 'request_received' ? uiText('Accepter','Ekeo','Accept')
      : uiText('Ajouter ami','Hanampy namana','Add friend');
  };
  sync();
  btn.addEventListener('click', async e => {
    e.preventDefault(); e.stopPropagation();
    if (btn.disabled) return;
    btn.disabled = true;
    try {
      const st = getFriendshipStatus(uid);
      if (st.status === 'none') await sendFriendRequest(uid);
      else if (st.status === 'request_sent') await cancelFriendRequest(st.requestId);
      else if (st.status === 'request_received') await acceptFriendRequest(st.requestId);
      else if (st.status === 'friends') await removeFriend(uid);
    } finally { btn.disabled = false; sync(); }
  });
  return btn;
}

async function lyrV52RenderReactionRows(postId, filter='all') {
  const request = ++lyrV53ReactionViewRequest;
  const root = lyrV52EnsureReactionViewer();
  const list = root.querySelector('[data-v52-react-list]');
  if (!list || root.classList.contains('hidden')) return;
  list.innerHTML = `<div class="feed-loading">${escapeHtml(uiText('Chargement…','Miandry…','Loading…'))}</div>`;
  const all = await lyrV52GetReactions(postId);
  if (request !== lyrV53ReactionViewRequest || root.classList.contains('hidden')) return;
  const rows = filter === 'all' ? all : all.filter(r => (r.type || 'like') === filter);
  list.replaceChildren();
  if (!rows.length) {
    const empty = document.createElement('div'); empty.className='empty-state';
    empty.textContent = uiText('Aucune réaction.','Tsy misy reaction.','No reactions.'); list.appendChild(empty); return;
  }
  // Batchs de 10 : les profils étaient lus un par un, ce qui bloquait
  // l'affichage des réactions sur les connexions mobiles lentes.
  let shown = 0;
  for (let offset = 0; offset < rows.length; offset += 10) {
    const batch = rows.slice(offset, offset + 10);
    const resolved = await Promise.all(batch.map(async r => {
      const uid = String(r.userId || r.id || '');
      if (!uid) return null;
      const profile = await getUserProfile(uid).catch(() => null);
      return profile ? { uid, profile, reaction:r } : null;
    }));
    if (request !== lyrV53ReactionViewRequest || root.classList.contains('hidden')) return;
    const frag = document.createDocumentFragment();
    for (const entry of resolved) {
      if (!entry) continue;
      const { uid, profile:p, reaction:r } = entry;
      const item = document.createElement('article');
      item.className = 'lyr-v52-reaction-person';
      item.innerHTML = `<button type="button" class="lyr-v52-reaction-person-main"><span class="avatar">${avatarMarkup(p.photoURL,p.fullname)}</span><span class="grow"><strong>${escapeHtml(p.fullname || p.username || uiSomeone())}${identityBadgeMarkup(p)}</strong>${p.username?`<small>@${escapeHtml(p.username)}</small>`:''}</span></button><span class="lyr-v52-person-emoji">${escapeHtml(lyrV52ReactionEmoji(r.type || 'like'))}</span>`;
      item.querySelector('.lyr-v52-reaction-person-main')?.addEventListener('click',()=>lyrV52ProfileOpen(uid));
      const action = await lyrV52ReactionActionButton(uid);
      if (action) item.appendChild(action);
      frag.appendChild(item);
      shown++;
    }
    if (request !== lyrV53ReactionViewRequest || root.classList.contains('hidden')) return;
    list.appendChild(frag);
  }
  if (!shown) {
    const empty = document.createElement('div'); empty.className='empty-state';
    empty.textContent = uiText('Profils indisponibles.','Tsy azo aseho ny profil.','Profiles unavailable.');
    list.appendChild(empty);
  }
}

async function lyrV52OpenReactions(postId) {
  const request = ++lyrV53ReactionViewRequest;
  const root = lyrV52EnsureReactionViewer();
  root.classList.remove('hidden');
  const tabs = root.querySelector('[data-v52-react-tabs]');
  const list = root.querySelector('[data-v52-react-list]');
  list.textContent = uiText('Chargement…','Miandry…','Loading…');
  tabs.replaceChildren();
  const all = await lyrV52GetReactions(postId);
  if (request !== lyrV53ReactionViewRequest || root.classList.contains('hidden')) return;
  const counts = new Map();
  all.forEach(r=>counts.set(r.type||'like',(counts.get(r.type||'like')||0)+1));
  const specs = [{type:'all',emoji:'',label:uiText('Toutes','Rehetra','All')}, ...REACTIONS.map(r=>({type:r.type,emoji:r.emoji,label:reactionLabel(r.type)}))];
  tabs.replaceChildren();
  specs.forEach((s,idx)=>{
    const n = s.type === 'all' ? all.length : (counts.get(s.type)||0);
    if (s.type !== 'all' && !n) return;
    const b = document.createElement('button'); b.type='button'; b.className='lyr-v52-reaction-tab' + (idx===0?' active':'');
    b.dataset.type=s.type; b.innerHTML=`${s.emoji?`<span>${s.emoji}</span>`:''}<span>${escapeHtml(s.label)}</span><b>${n}</b>`;
    b.addEventListener('click',()=>{
      tabs.querySelectorAll('.lyr-v52-reaction-tab').forEach(x=>x.classList.toggle('active',x===b));
      lyrV52RenderReactionRows(postId,s.type).catch(err=>console.warn('[V53 reaction rows]',err));
    });
    tabs.appendChild(b);
  });
  await lyrV52RenderReactionRows(postId,'all');
}

// SEUL le texte/compteur ouvre la liste. Les 3 icônes restent décoratives.
document.addEventListener('click', e => {
  const count = e.target?.closest?.('.post-reaction-count[data-v52-reaction-post]');
  if (!count || !count.textContent.trim()) return;
  e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
  lyrV52OpenReactions(count.dataset.v52ReactionPost).catch(err=>console.warn('[V53 reactions viewer]',err));
}, true);

document.addEventListener('keydown', e => {
  if (e.key !== 'Enter' && e.key !== ' ') return;
  const count = e.target?.closest?.('.post-reaction-count[data-v52-reaction-post]');
  if (!count || !count.textContent.trim()) return;
  e.preventDefault(); lyrV52OpenReactions(count.dataset.v52ReactionPost).catch(err=>console.warn('[V53 reactions viewer]',err));
});

// Après une réaction locale, rafraîchir aussi les 3 icônes du résumé.
const lyrV52BaseUpdateReactionUI = updateReactionUI;
updateReactionUI = function(postId,type,count) {
  const out = lyrV52BaseUpdateReactionUI(postId,type,count);
  cardsFor(postId).forEach(card => {
    const post = { id:postId, reactionsCount: typeof count === 'number' ? count : Number(card.querySelector('.post-reaction-count')?.textContent?.match(/\d+/)?.[0] || 0) };
    lyrV52HydrateReactionSummary(card,post).catch(()=>{});
  });
  return out;
};


/* ============== LYRAME V57: file inputs + previews sans débordement ============== */
function lyrV57SetupUploadPickers(){
  const definitions=[
    ['#page-avatar-input',true],['#page-cover-input',false],
    ['#listing-photos',false]
  ];
  definitions.forEach(([selector,circle])=>{
    const input=document.querySelector(selector);if(!input||input.dataset.lyrV57Enhanced)return;
    input.dataset.lyrV57Enhanced='1';
    const host=input.closest('label')||input.parentElement;
    if(!host)return;
    host.classList.add('lyr-v57-file-card');
    const gallery=document.createElement('div');gallery.className='lyr-v57-file-gallery';
    const title=document.createElement('span');title.className='lyr-v57-file-action';title.textContent=uiText('📷 Choisir une photo','📷 Hisafidy sary','📷 Choose photo');
    host.insertBefore(title,input);host.appendChild(gallery);
    let urls=[];
    const clear=()=>{urls.forEach(u=>URL.revokeObjectURL(u));urls=[];gallery.replaceChildren();};
    input.addEventListener('change',()=>{
      clear();const files=[...input.files||[]].slice(0,10);
      files.forEach(file=>{
        if(!file.type.startsWith('image/'))return;
        const url=URL.createObjectURL(file);urls.push(url);
        const img=document.createElement('img');img.src=url;img.alt=file.name;img.className=circle?'is-circle':'';
        gallery.appendChild(img);
      });
      if(files.length){const count=document.createElement('small');count.className='lyr-v57-file-name';count.textContent=files.length===1?files[0].name:`${files.length} ${uiText('photos','sary','photos')}`;gallery.appendChild(count);}
    });
    input.form?.addEventListener('reset',()=>{clear();});
  });
  // La photo du groupe dispose déjà d'un aperçu et d'un bouton pour la retirer.
  document.querySelector('#create-group-cover-btn')?.setAttribute('title',uiText('Choisir la photo du groupe','Hisafidy sarin’ny groupe','Choose group photo'));
  document.querySelector('#create-add-photo')?.setAttribute('title',uiText('Ajouter des photos','Hanampy sary','Add photos'));
  document.querySelector('#story-create-btn .story-plus')?.setAttribute('title',uiText('Ajouter une story','Hanampy story','Add story'));
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',lyrV57SetupUploadPickers,{once:true});
else lyrV57SetupUploadPickers();

/* LYRAME V90 — Inscription 2 étapes */


/* LYRAME V92 — Administration dynamique sécurisée, au sein du module ES Firebase existant.
 * Le pilotage des boutons est une préférence d'interface, PAS une barrière d'autorisation
 * pour l'accès aux données ou les paiements. Les écritures sont protégées par Firestore Rules.
 */
const LYR_V92_OWNER_EMAIL = 'christionalain1@gmail.com';
const LYR_V92_FEATURES = Object.freeze([
  ['search','Recherche'], ['create','Créer une publication'],
  ['messages','Messagerie'], ['assistant','Assistant LYRAME'],
  ['groups','Groupes'], ['marketplace','Marketplace'],
  ['pages','Pages'], ['notifications','Notifications'],
  ['saved-posts','Enregistrements'], ['dashboard','Tableau de bord']
]);
const LYR_V92_SET = new Set(LYR_V92_FEATURES.map(row=>row[0]));
const LYR_V92_GLOBAL_REF = doc(db,'lyrameV92Config','global');
let lyrV92Global = {features:{},appearance:{}};
let lyrV92Mine = {features:{},appearance:{},tier:'free'};
let lyrV92SignedUid='';
let lyrV92GlobalUnsub=null;
let lyrV92MineUnsub=null;
let lyrV92TargetUnsub=null;
let lyrV92Target=null;
let lyrV92TargetControl={features:{},appearance:{},tier:'free'};
let lyrV92UsersCursor=null;
let lyrV92UserRows=[];
let lyrV92AllUsersLoaded=false;
let lyrV92Saving=false;

function lyrV92Owner(){
  const u=auth.currentUser;
  return !!u && u.email?.toLowerCase()===LYR_V92_OWNER_EMAIL && u.emailVerified===true;
}
function lyrV92Allowed(feature){
  if(lyrV92Owner())return true; // l'administrateur ne peut pas se bloquer lui-même
  const per=lyrV92Mine.features?.[feature];
  if(typeof per==='boolean')return per;
  const global=lyrV92Global.features?.[feature];
  return typeof global==='boolean' ? global : true;
}
function lyrV92MayEnter(screen){
  if(screen==='admin') return lyrV92Owner();
  return !LYR_V92_SET.has(screen)||lyrV92Allowed(screen);
}
function lyrV92Apply(){
  const founderEmailMatches = String(auth.currentUser?.email || '').trim().toLowerCase() === LYR_V92_OWNER_EMAIL;
  const founderAuthorized = lyrV92Owner(); // Email + vérification exigés : sécurité inchangée.
  const ownerPanel = document.getElementById('lyr-v969-owner-panel');
  if (ownerPanel) ownerPanel.hidden = !founderEmailMatches;
  const entry = document.getElementById('lyr-v92-admin-entry');
  if (entry) {
    entry.hidden = !founderEmailMatches;
    entry.classList.toggle('hidden', !founderEmailMatches);
    entry.disabled = !founderAuthorized;
    entry.setAttribute('aria-disabled', founderAuthorized ? 'false' : 'true');
  }
  const verifyNote = document.getElementById('lyr-v969-owner-note');
  if (verifyNote) verifyNote.hidden = !founderEmailMatches || founderAuthorized;
  document.querySelectorAll('#app-shell [data-goto], #app-shell [data-nav]').forEach(el=>{
    const target=el.getAttribute('data-goto')||el.getAttribute('data-nav');
    if(!LYR_V92_SET.has(target))return;
    const visible=lyrV92Allowed(target);
    el.classList.toggle('lyr-v92-hidden-entry',!visible);
    if(!visible){ el.dataset.lyrV92Hidden='1'; el.setAttribute('aria-hidden','true'); }
    else if(el.dataset.lyrV92Hidden==='1'){ delete el.dataset.lyrV92Hidden; el.removeAttribute('aria-hidden'); }
  });
  for (const [id,feature] of [['header-search-btn','search'],['header-inline-search','search'],['header-notifications-btn','notifications']]) {
    const el=document.getElementById(id);
    if(el)el.classList.toggle('lyr-v92-hidden-entry',!lyrV92Allowed(feature));
  }
  const appearance={...lyrV92Global.appearance,...lyrV92Mine.appearance};
  document.body.dataset.lyrV92Density=appearance.density==='compact'?'compact':'normal';
  document.body.dataset.lyrV92Accent=['violet','cyan','rose'].includes(appearance.accent)?appearance.accent:'violet';
  const badge=document.getElementById('lyr-v92-plan-badge');
  if(badge)badge.textContent='Offre : '+({premium:'Premium',vip:'VIP'}[lyrV92Mine.tier]||'Gratuit');
  // Si une fonction se ferme depuis un autre appareil, revenir à l'accueil.
  const active=document.querySelector('#app-shell .screen.active')?.dataset.screen;
  if(active && LYR_V92_SET.has(active) && !lyrV92Allowed(active))showScreen('home');
}
function lyrV92Reset(){
  for(const key of ['lyrV92GlobalUnsub','lyrV92MineUnsub','lyrV92TargetUnsub']){
    const fn=({lyrV92GlobalUnsub,lyrV92MineUnsub,lyrV92TargetUnsub})[key];
    if(fn)try{fn();}catch(_){}
  }
  lyrV92GlobalUnsub=null;lyrV92MineUnsub=null;lyrV92TargetUnsub=null;
  lyrV92Global={features:{},appearance:{}};lyrV92Mine={features:{},appearance:{},tier:'free'};
  lyrV92Target=null;lyrV92UsersCursor=null;lyrV92UserRows=[];lyrV92AllUsersLoaded=false;
  lyrV92Apply();
}
function lyrV92OnAuth(user){
  const uid=user?.uid||'';
  if(uid===lyrV92SignedUid){lyrV92Apply();return;}
  lyrV92SignedUid=uid;
  lyrV92Reset();
  if(!uid)return;
  lyrV92GlobalUnsub=onSnapshot(LYR_V92_GLOBAL_REF,snap=>{
    lyrV92Global=snap.exists()?snap.data():{features:{},appearance:{}};
    lyrV92Apply();if(lyrV92Owner())lyrV92RenderGlobal();
  },err=>{console.warn('[V92 config globale]',err?.code);lyrV92Note('Règles Firestore V92 non actives / lecture indisponible.',true);});
  lyrV92MineUnsub=onSnapshot(doc(db,'lyrameV92Config','global','users',uid),snap=>{
    lyrV92Mine=snap.exists()?snap.data():{features:{},appearance:{},tier:'free'};
    lyrV92Apply();
  },err=>console.warn('[V92 config compte]',err?.code));
  lyrV92Apply();
}
function lyrV92Note(msg,isError=false){
  const el=document.getElementById('lyr-v92-status');
  if(!el)return;
  el.textContent=msg;
  el.classList.toggle('lyr-v92-error',isError);
}
function lyrV92FeatureForm(hostId,current,perUser=false){
  const host=document.getElementById(hostId);
  if(!host)return;
  host.replaceChildren();
  LYR_V92_FEATURES.forEach(([key,label])=>{
    const row=document.createElement('label');row.className='lyr-v92-option';
    const name=document.createElement('span');name.textContent=label;
    const input=document.createElement('select');input.dataset.lyrFeature=key;
    const choices=perUser
      ? [['inherit','Hériter de la règle générale'],['on','Afficher'],['off','Masquer']]
      : [['on','Afficher'],['off','Masquer']];
    for(const [value,text] of choices){const opt=document.createElement('option');opt.value=value;opt.textContent=text;input.append(opt);}
    const cur=current?.[key];input.value=typeof cur==='boolean'?(cur?'on':'off'):(perUser?'inherit':'on');
    row.append(name,input);host.append(row);
  });
}
function lyrV92AppearanceForm(prefix,appearance,perUser){
  const den=document.getElementById(prefix+'-density'),acc=document.getElementById(prefix+'-accent');
  if(den)den.value=appearance?.density||(perUser?'inherit':'normal');
  if(acc)acc.value=appearance?.accent||(perUser?'inherit':'violet');
}
function lyrV92ReadFeatures(hostId,perUser){
  const features={};document.getElementById(hostId)?.querySelectorAll('[data-lyr-feature]').forEach(el=>{
    if(el.value==='on')features[el.dataset.lyrFeature]=true;
    if(el.value==='off')features[el.dataset.lyrFeature]=false;
  });
  return features;
}
function lyrV92ReadAppearance(prefix,perUser){
  const ret={};
  for(const key of ['density','accent']){
    const val=document.getElementById(prefix+'-'+key)?.value;
    if(val && (!perUser||val!=='inherit'))ret[key]=val;
  }
  return ret;
}
function lyrV92RenderGlobal(){
  if(!lyrV92Owner())return;
  lyrV92FeatureForm('lyr-v92-global-features',lyrV92Global.features,false);
  lyrV92AppearanceForm('lyr-v92-global',lyrV92Global.appearance,false);
}
function lyrV92RenderTarget(){
  const box=document.getElementById('lyr-v92-target-editor');
  if(box)box.hidden=!lyrV92Target;
  if(!lyrV92Target)return;
  const name=lyrV92Target.profile.fullname||lyrV92Target.profile.username||lyrV92Target.uid;
  const el=document.getElementById('lyr-v92-target-name');if(el)el.textContent=name+' — '+lyrV92Target.uid;
  lyrV92FeatureForm('lyr-v92-user-features',lyrV92TargetControl.features,true);
  lyrV92AppearanceForm('lyr-v92-user',lyrV92TargetControl.appearance,true);
  const tier=document.getElementById('lyr-v92-user-tier');if(tier)tier.value=['free','premium','vip'].includes(lyrV92TargetControl.tier)?lyrV92TargetControl.tier:'free';
}
async function lyrV92Select(uid,profile={}){
  if(!lyrV92Owner()||!/^[A-Za-z0-9_-]{6,128}$/.test(uid))return lyrV92Note('UID tsy manankery.',true);
  lyrV92TargetUnsub?.();lyrV92TargetUnsub=null;
  try{
    const snap=await getDoc(doc(db,'users',uid));
    if(!snap.exists())return lyrV92Note('Tsy hita io compte io.',true);
    lyrV92Target={uid,profile:snap.data()};
    void lyrAdminAutomationLoad(uid);
    lyrV92TargetUnsub=onSnapshot(doc(db,'lyrameV92Config','global','users',uid),docSnap=>{
      if(lyrV92Target?.uid!==uid)return;
      lyrV92TargetControl=docSnap.exists()?docSnap.data():{features:{},appearance:{},tier:'free'};
      lyrV92RenderTarget();
    },err=>lyrV92Note('Tsy afaka mamaky réglage: '+(err?.code||'erreur'),true));
    lyrV92Note('Compte voafidy: '+uid);
  }catch(err){lyrV92Note('Tsy afaka mamaky compte: '+(err?.code||'erreur'),true);}
}
function lyrV92RenderUsers(){
  const list=document.getElementById('lyr-v92-user-list');if(!list)return;
  list.replaceChildren();
  const needle=(document.getElementById('lyr-v92-user-filter')?.value||'').trim().toLowerCase();
  const rows=lyrV92UserRows.filter(({uid,profile})=>{
    const s=[uid,profile.fullname,profile.username,profile.email].filter(Boolean).join(' ').toLowerCase();
    return !needle||s.includes(needle);
  });
  for(const {uid,profile} of rows){
    const btn=document.createElement('button');btn.type='button';btn.className='lyr-v92-user-item';
    const title=document.createElement('strong');title.textContent=profile.fullname||profile.username||'Compte';
    const sub=document.createElement('small');sub.textContent=(profile.username?'@'+profile.username+' • ':'')+uid;
    btn.append(title,sub);btn.addEventListener('click',()=>void lyrV92Select(uid,profile));list.append(btn);
  }
  if(!rows.length){const empty=document.createElement('p');empty.textContent='Tsy misy compte hita amin’ireo chargés.';list.append(empty);}
  const load=document.getElementById('lyr-v92-next-users');if(load)load.disabled=lyrV92AllUsersLoaded;
}
async function lyrV92LoadUsers(reset=false){
  if(!lyrV92Owner())return;
  const btn=document.getElementById('lyr-v92-next-users');if(btn)btn.disabled=true;
  try{
    if(reset){lyrV92UsersCursor=null;lyrV92UserRows=[];lyrV92AllUsersLoaded=false;}
    if(lyrV92AllUsersLoaded)return;
    const q=lyrV92UsersCursor
      ? query(collection(db,'users'),startAfter(lyrV92UsersCursor),limit(30))
      : query(collection(db,'users'),limit(30));
    const snap=await getDocs(q);
    lyrV92UserRows.push(...snap.docs.map(x=>({uid:x.id,profile:x.data()})));
    lyrV92UsersCursor=snap.docs.at(-1)||null;
    lyrV92AllUsersLoaded=snap.docs.length<30;
    lyrV92RenderUsers();
    lyrV92Note(lyrV92UserRows.length+' compte(s) chargés — recherche dans les comptes chargés.');
  }catch(err){lyrV92Note('Chargement utilisateurs refusé: '+(err?.code||'erreur'),true);}
  finally{if(btn)btn.disabled=lyrV92AllUsersLoaded;}
}
async function lyrV92Save(kind){
  if(!lyrV92Owner()||lyrV92Saving)return;
  const uid=auth.currentUser.uid;
  const isGlobal=kind==='global';
  if(!isGlobal&&!lyrV92Target)return;
  const ref=isGlobal?LYR_V92_GLOBAL_REF:doc(db,'lyrameV92Config','global','users',lyrV92Target.uid);
  const features=lyrV92ReadFeatures(isGlobal?'lyr-v92-global-features':'lyr-v92-user-features',!isGlobal);
  const appearance=lyrV92ReadAppearance(isGlobal?'lyr-v92-global':'lyr-v92-user',!isGlobal);
  const tier=document.getElementById('lyr-v92-user-tier')?.value||'free';
  const data={features,appearance,updatedBy:uid,updatedAt:serverTimestamp()};
  if(!isGlobal)data.tier=['free','premium','vip'].includes(tier)?tier:'free';
  lyrV92Saving=true;lyrV92Note('Enregistrement...');
  try{await setDoc(ref,data,{merge:!isGlobal});
    lyrV92Note(isGlobal?'Configuration générale enregistrée ✅':'Configuration du compte enregistrée ✅');
  }catch(err){lyrV92Note('Enregistrement refusé ('+(err?.code||'erreur')+'). Vérifiez Firestore Rules V92.',true);}
  finally{lyrV92Saving=false;}
}
function lyrV92RenderAdmin(){
  if(!lyrV92Owner()){lyrV92Note('Accès réservé au propriétaire.',true);return;}
  lyrV92RenderGlobal();
  if(!lyrV92UserRows.length)void lyrV92LoadUsers(true);
  if(lyrV92Target)lyrV92RenderTarget();
}
function lyrV92Bind(){
  document.getElementById('lyr-v92-save-global')?.addEventListener('click',()=>void lyrV92Save('global'));
  document.getElementById('lyr-v92-save-user')?.addEventListener('click',()=>void lyrV92Save('user'));
  document.getElementById('lyr-v92-next-users')?.addEventListener('click',()=>void lyrV92LoadUsers());
  document.getElementById('lyr-v92-user-filter')?.addEventListener('input',lyrV92RenderUsers);
  document.getElementById('lyr-v92-load-uid')?.addEventListener('click',()=>{
    const uid=document.getElementById('lyr-v92-uid')?.value.trim()||'';
    void lyrV92Select(uid);
  });
  document.getElementById('lyr-v92-admin-entry')?.addEventListener('click',()=>{
    if(lyrV92Owner())setTimeout(lyrV92RenderAdmin,0);
  });
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',lyrV92Bind,{once:true});
else lyrV92Bind();
onAuthStateChanged(auth,lyrV92OnAuth);

window.__lyrV92Ready=true;

/* Pilotage de l'automatisation IA par compte (administration propriétaire).
   Les permissions, les utilisateurs et les écritures sont vérifiés sur le serveur
   Floot avec un ID token Firebase : pas de règles Firestore ni de secret client. */
const LYR_ADMIN_AI_API = 'https://lyrame-assistant-backend.floot.app/_api/automation_manage';
let lyrAdminAutomationBusy = false;
let lyrAdminAutomationSelected = '';
const lyrAdminAutomationField = id => document.getElementById(id);
function lyrAdminAutomationStatus(message,isError=false){
  const el=lyrAdminAutomationField('lyr-ai-admin-status');
  if(el){el.textContent=message;el.dataset.error=isError?'true':'false';}
}
async function lyrAdminAutomationRequest(action,targetUid,settings){
  if(!lyrV92Owner() || !auth.currentUser)throw new Error('owner_required');
  const idToken=await auth.currentUser.getIdToken();
  const response=await fetch(LYR_ADMIN_AI_API,{
    method:'POST',headers:{'Content-Type':'text/plain;charset=UTF-8'},
    body:JSON.stringify({idToken,targetUid,action,...(settings?{settings}:{})}),
    cache:'no-store'
  });
  const data=await response.json();
  if(!response.ok || !data?.success)throw new Error(data?.error||'service_unavailable');
  return data.data;
}
function lyrAdminAutomationDisplay(value){
  const set=(id, v)=>{const el=lyrAdminAutomationField(id);if(el)el.value=v;};
  const visible=lyrAdminAutomationField('lyr-ai-admin-visible');if(visible)visible.checked=value.visible===true;
  const active=lyrAdminAutomationField('lyr-ai-admin-enabled');if(active)active.checked=value.enabled===true;
  set('lyr-ai-admin-tone',value.tone||'natural');
  set('lyr-ai-admin-language',value.language||'auto');
  set('lyr-ai-admin-length',value.length||'normal');
  set('lyr-ai-admin-instructions',value.instructions||'');
  const panel=lyrAdminAutomationField('lyr-ai-admin-form');if(panel)panel.hidden=false;
  lyrAdminAutomationStatus((value.visible ? '● Option visible' : '○ Option masquée') + ' · ' + (value.enabled && value.visible ? 'IA active' : 'IA inactive'));
}
async function lyrAdminAutomationLoad(uid){
  if(!lyrV92Owner() || !uid)return;
  lyrAdminAutomationSelected=uid;
  const form=lyrAdminAutomationField('lyr-ai-admin-form');if(form)form.hidden=true;
  lyrAdminAutomationStatus('Chargement des réglages IA…');
  try{
    const data=await lyrAdminAutomationRequest('get',uid);
    if(uid===lyrAdminAutomationSelected && uid===lyrV92Target?.uid)lyrAdminAutomationDisplay(data);
  }catch(error){
    if(uid===lyrAdminAutomationSelected){
      console.warn('[LYRAME admin automation] failed:',String(error?.message||error));
      lyrAdminAutomationStatus('Impossible de charger les réglages. Vérifiez le service Floot ou les autorisations.',true);
    }
  }
}
async function lyrAdminAutomationSave(){
  if(!lyrV92Owner()||lyrAdminAutomationBusy||!lyrV92Target)return;
  const uid=lyrV92Target.uid;
  const read=id=>lyrAdminAutomationField(id)?.value||'';
  const settings={
    visible:lyrAdminAutomationField('lyr-ai-admin-visible')?.checked===true,
    enabled:lyrAdminAutomationField('lyr-ai-admin-enabled')?.checked===true,
    tone:read('lyr-ai-admin-tone'),language:read('lyr-ai-admin-language'),
    length:read('lyr-ai-admin-length'),instructions:read('lyr-ai-admin-instructions').slice(0,500)
  };
  lyrAdminAutomationBusy=true;
  const button=lyrAdminAutomationField('lyr-ai-admin-save');if(button)button.disabled=true;
  lyrAdminAutomationStatus('Enregistrement des réglages sur le serveur…');
  try{
    const saved=await lyrAdminAutomationRequest('save',uid,settings);
    if(uid===lyrV92Target?.uid){
      lyrAdminAutomationDisplay(saved);
      lyrAdminAutomationStatus('✓ Modifications enregistrées immédiatement, sans déploiement.');
    }
  }catch(error){
    console.warn('[LYRAME admin automation save]',String(error?.message||error));
    lyrAdminAutomationStatus('Enregistrement impossible. Réessayez ou vérifiez le service IA.',true);
  }finally{lyrAdminAutomationBusy=false;if(button)button.disabled=false;}
}
function lyrAdminAutomationBind(){
  lyrAdminAutomationField('lyr-ai-admin-save')?.addEventListener('click',()=>void lyrAdminAutomationSave());
  lyrAdminAutomationField('lyr-ai-admin-refresh')?.addEventListener('click',()=>{
    if(lyrV92Target?.uid)void lyrAdminAutomationLoad(lyrV92Target.uid);
  });
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',lyrAdminAutomationBind,{once:true});
else lyrAdminAutomationBind();



/* LYRAME V93 — Paramètres de tarification dynamiques.
 * AUCUN PAIEMENT : afficher un tarif ne crée aucun droit d'accès premium.
 * Seul le fondateur (Auth + emailVerified + règles Firestore) peut sauvegarder.
 */
const LYR_V93_PRODUCTS = Object.freeze([
  ['premium','day','Premium','1 andro'],
  ['premium','month','Premium','1 volana'],
  ['premium','year','Premium','1 taona'],
  ['vip','day','VIP','1 andro'],
  ['vip','month','VIP','1 volana'],
  ['vip','year','VIP','1 taona']
]);
const LYR_V93_CATALOG_REF=doc(db,'lyrameV93Pricing','catalog');
let lyrV93Catalog=null;
let lyrV93PricingUnsub=null;
let lyrV93EditDirty=false;
let lyrV93Ready=false;
let lyrV93Saving=false;
function lyrV93SetStatus(message,isError=false){
  const status=document.getElementById('lyr-v93-status');
  if(status){status.textContent=message;status.classList.toggle('error',isError);}
}
function lyrV93Amount(n){
  return new Intl.NumberFormat('fr-FR',{maximumFractionDigits:0}).format(n)+' Ar';
}
function lyrV93DrawEditor(){
  const root=document.getElementById('lyr-v93-pricing-editor');
  if(!root || !lyrV92Owner() || !lyrV93Ready || lyrV93EditDirty)return;
  root.replaceChildren();
  for(const [tier,period,tierLabel,duration] of LYR_V93_PRODUCTS){
    const current=lyrV93Catalog?.[tier]?.[period]||{amount:0,enabled:false};
    const row=document.createElement('div');row.className='lyr-v93-row';
    const label=document.createElement('strong');label.textContent=tierLabel+' · '+duration;
    const priceLabel=document.createElement('label');priceLabel.textContent='Prix (Ar)';
    const price=document.createElement('input');price.type='number';price.min='0';price.max='100000000';price.step='1';price.inputMode='numeric';
    price.required=true;price.value=String(current.amount ?? 0);price.dataset.price=tier+'-'+period;
    price.addEventListener('input',()=>{lyrV93EditDirty=true;});
    priceLabel.append(price);
    const toggleLabel=document.createElement('label');toggleLabel.className='lyr-v93-toggle';
    const toggle=document.createElement('input');toggle.type='checkbox';toggle.checked=current.enabled===true;toggle.dataset.enabled=tier+'-'+period;
    toggle.addEventListener('change',()=>{lyrV93EditDirty=true;});
    const text=document.createElement('span');text.textContent='Afficher cette offre';toggleLabel.append(toggle,text);
    row.append(label,priceLabel,toggleLabel);root.append(row);
  }
}
function lyrV93DrawOffers(){
  const root=document.getElementById('lyr-v93-offers-list');if(!root)return;
  root.replaceChildren();
  if(!lyrV93Ready){root.textContent='Chargement…';return;}
  let count=0;
  for(const [tier,period,tierLabel,duration] of LYR_V93_PRODUCTS){
    const rec=lyrV93Catalog?.[tier]?.[period];
    if(!rec||rec.enabled!==true||!Number.isSafeInteger(rec.amount)||rec.amount<=0)continue;
    const row=document.createElement('div');row.className='lyr-v93-offer';
    const title=document.createElement('strong');title.textContent=tierLabel+' — '+duration;
    const amt=document.createElement('span');amt.textContent=lyrV93Amount(rec.amount);
    const hint=document.createElement('small');hint.textContent='Paiement bientôt disponible';
    row.append(title,amt,hint);root.append(row);count++;
  }
  if(!count)root.textContent='Aucune offre publiée pour le moment.';
}
async function lyrV93SavePrices(){
  if(!lyrV92Owner()||lyrV93Saving||!lyrV93Ready)return;
  const data={currency:'MGA',premium:{},vip:{},updatedBy:auth.currentUser.uid,updatedAt:serverTimestamp()};
  for(const [tier,period,tierLabel,duration] of LYR_V93_PRODUCTS){
    const key=tier+'-'+period;
    const value=document.querySelector('#lyr-v93-pricing-editor [data-price="'+key+'"]')?.value;
    const checked=document.querySelector('#lyr-v93-pricing-editor [data-enabled="'+key+'"]')?.checked===true;
    if(value==null||!/^\d+$/.test(value.trim())){lyrV93SetStatus('Prix invalide : '+tierLabel+' · '+duration,true);return;}
    const amount=Number(value);
    if(!Number.isSafeInteger(amount)||amount<0||amount>100000000||(checked&&amount===0)){
      lyrV93SetStatus('Prix non autorisé : '+tierLabel+' · '+duration,true);return;
    }
    data[tier][period]={amount,enabled:checked};
  }
  const button=document.getElementById('lyr-v93-save-prices');
  lyrV93Saving=true;if(button)button.disabled=true;
  lyrV93SetStatus('Enregistrement en cours…');
  try{
    await setDoc(LYR_V93_CATALOG_REF,data);
    lyrV93EditDirty=false;
    lyrV93SetStatus('✅ Tarifs enregistrés. Mise à jour en temps réel.');
  }catch(err){lyrV93SetStatus('❌ Firestore : '+(err?.code||'erreur')+'. Vérifiez les règles V93.',true);}
  finally{lyrV93Saving=false;if(button)button.disabled=!lyrV92Owner();}
}
function lyrV93WatchPricing(user){
  if(lyrV93PricingUnsub){lyrV93PricingUnsub();lyrV93PricingUnsub=null;}
  lyrV93Catalog=null;lyrV93Ready=false;lyrV93EditDirty=false;
  document.getElementById('lyr-v93-save-prices')?.setAttribute('disabled','');
  lyrV93DrawOffers();
  if(!user)return;
  lyrV93PricingUnsub=onSnapshot(LYR_V93_CATALOG_REF,snap=>{
    lyrV93Catalog=snap.exists()?snap.data():null;
    lyrV93Ready=true;
    const button=document.getElementById('lyr-v93-save-prices');
    if(button)button.disabled=!lyrV92Owner();
    lyrV93DrawEditor();lyrV93DrawOffers();
    if(lyrV92Owner()&&!lyrV93EditDirty)lyrV93SetStatus(snap.exists()?'✅ Tarifs synchronisés.':'Aucun tarif enregistré. Entrez vos prix puis Enregistrer.');
  },err=>{
    lyrV93Ready=false;lyrV93DrawOffers();
    const button=document.getElementById('lyr-v93-save-prices');if(button)button.disabled=true;
    lyrV93SetStatus('Lecture des prix impossible : '+(err?.code||'erreur'),true);
  });
}
function lyrV93Init(){
  document.getElementById('lyr-v93-save-prices')?.addEventListener('click',()=>void lyrV93SavePrices());
  onAuthStateChanged(auth,lyrV93WatchPricing);
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',lyrV93Init,{once:true});else lyrV93Init();

/* Messaging mobile: native Android selection toolbar is replaced by the
   LYRAME message actions on long press. Inputs remain fully selectable. */
function lyrameDisableNativeChatSelection() {
  const box = document.getElementById("conv-messages");
  if (!box || box.dataset.lyrSelectionSafe === "1") return;
  box.dataset.lyrSelectionSafe = "1";
  const isChatText = target => {
    const node = target instanceof Element ? target : target?.parentElement;
    return !!node?.closest?.(".msg-text, .msg-reply-quote, .message-status, .msg-deleted");
  };
  box.addEventListener("selectstart", event => {
    if (isChatText(event.target)) event.preventDefault();
  }, { capture: true });
  box.addEventListener("contextmenu", event => {
    const node = event.target instanceof Element ? event.target : event.target?.parentElement;
    if (node?.closest?.(".msg") && !node.closest("audio, video, input, textarea, button, a")) {
      event.preventDefault();
    }
  }, { capture: true });
}
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", lyrameDisableNativeChatSelection, { once: true });
} else {
  lyrameDisableNativeChatSelection();
}


/* LYRAME — IA de messagerie. Configuration dans Paramètres du propriétaire uniquement.
   Authentification et règles Firebase inchangées. Exécution IA côté Floot uniquement. */
const LYR_AUTO_ENDPOINT = 'https://lyrame-assistant-backend.floot.app/_api/auto_reply';
const LYR_AUTO_HEALTH_ENDPOINT = 'https://lyrame-assistant-backend.floot.app/_api/auto_reply_status';
const LYR_AUTO_OWNER_EMAIL = 'christionalain1@gmail.com';
let lyrAutoUnsubscribe = null;
let lyrAutoBackendReady = false;
let lyrAutoBusy = false;
let lyrAutoRenderedUid = '';
let lyrAutoVisibleForAccount = false;
function lyrAutoCanUse(){return lyrAutoIsOwner() || lyrAutoVisibleForAccount;}
const LYR_AUTO_TONES = new Set(['natural','professional','warm']);
const LYR_AUTO_LANGS = new Set(['auto','mg','fr','en']);
const LYR_AUTO_LENGTHS = new Set(['short','normal','detailed']);
const lyrAutoEl = id => document.getElementById(id);
function lyrAutoIsOwner(){
  const u=auth.currentUser;
  return !!u && String(u.email||'').toLowerCase()===LYR_AUTO_OWNER_EMAIL && u.emailVerified===true;
}
function lyrAutoFeedback(msg, error=false){
  const el=lyrAutoEl('lyr-ai-auto-feedback');if(!el)return;
  el.textContent=msg;el.classList.toggle('is-error',error);
}
function lyrAutoRenderSettings(data={}){
  if(!lyrAutoCanUse())return;
  const toggle=lyrAutoEl('lyr-ai-auto-enabled');
  if(toggle && !lyrAutoBusy){toggle.checked=data.lyrameAiAutoReplyEnabled===true; toggle.disabled=!lyrAutoBackendReady && !toggle.checked;}
  const values=[
    ['lyr-ai-auto-tone',data.lyrameAiAutoReplyTone,LYR_AUTO_TONES,'natural'],
    ['lyr-ai-auto-language',data.lyrameAiAutoReplyLanguage,LYR_AUTO_LANGS,'auto'],
    ['lyr-ai-auto-length',data.lyrameAiAutoReplyLength,LYR_AUTO_LENGTHS,'normal']
  ];
  for(const [id,raw,allowed,fallback] of values){const el=lyrAutoEl(id);if(el&&document.activeElement!==el)el.value=allowed.has(raw)?raw:fallback;}
  const instructions=lyrAutoEl('lyr-ai-auto-instructions');
  if(instructions&&document.activeElement!==instructions)instructions.value=String(data.lyrameAiAutoReplyInstructions||'').slice(0,500);
  lyrAutoRenderedUid=auth.currentUser.uid;
}
async function lyrAutoCheckBackend(){
  const status=lyrAutoEl('lyr-ai-auto-health');
  if(!lyrAutoCanUse()){lyrAutoBackendReady=false;return;}
  if(status){status.textContent='Connexion au service IA…';status.dataset.health='loading';}
  try {
    const response=await fetch(LYR_AUTO_HEALTH_ENDPOINT,{method:'GET',cache:'no-store'});
    const data=await response.json();
    lyrAutoBackendReady=response.ok && data.ready===true;
    if(status){status.textContent=lyrAutoBackendReady?'● Assistant IA prêt : disponible sur le serveur':'● Service IA non configuré ou indisponible';status.dataset.health=lyrAutoBackendReady?'ready':'error';}
  } catch(err){
    lyrAutoBackendReady=false;
    if(status){status.textContent='● Impossible de vérifier le service pour le moment';status.dataset.health='error';}
  }
  const toggle=lyrAutoEl('lyr-ai-auto-enabled');if(toggle)toggle.disabled=!lyrAutoBackendReady && !toggle.checked;
}
async function lyrAutoUpdateSettings(payload, toggleOnly=false){
  if(!lyrAutoCanUse()||lyrAutoBusy)return;
  if(!lyrAutoBackendReady&&payload.lyrameAiAutoReplyEnabled===true){lyrAutoFeedback('Le service IA est indisponible. Impossible de l’activer.',true);return;}
  lyrAutoBusy=true;
  const toggle=lyrAutoEl('lyr-ai-auto-enabled'); const save=lyrAutoEl('lyr-ai-auto-save');
  if(toggle)toggle.disabled=true;if(save)save.disabled=true;
  lyrAutoFeedback('Enregistrement…');
  try {
    await updateDoc(doc(db,'users',auth.currentUser.uid),payload);
    lyrAutoFeedback(toggleOnly?(payload.lyrameAiAutoReplyEnabled?'Automatisation IA activée.':'Automatisation IA désactivée.'):'Préférences enregistrées.');
  }catch(err){
    console.warn('[auto settings]',err?.code||err);
    lyrAutoFeedback('Enregistrement impossible. Vérifiez votre connexion et vos droits de compte.',true);
    if(toggle && toggleOnly)toggle.checked=!payload.lyrameAiAutoReplyEnabled;
  }finally{
    lyrAutoBusy=false;
    if(toggle)toggle.disabled=!lyrAutoBackendReady && !toggle.checked;
    if(save)save.disabled=false;
  }
}
function lyrAutoBindSettings(){
  lyrAutoEl('lyr-ai-auto-enabled')?.addEventListener('change',e=>{
    if(!lyrAutoCanUse()){e.target.checked=false;return;}
    void lyrAutoUpdateSettings({lyrameAiAutoReplyEnabled:e.target.checked},true);
  });
  lyrAutoEl('lyr-ai-auto-save')?.addEventListener('click',()=>{
    if(!lyrAutoCanUse())return;
    const raw=id=>lyrAutoEl(id)?.value||'';
    const tone=raw('lyr-ai-auto-tone');const language=raw('lyr-ai-auto-language');const length=raw('lyr-ai-auto-length');
    void lyrAutoUpdateSettings({
      lyrameAiAutoReplyTone:LYR_AUTO_TONES.has(tone)?tone:'natural',
      lyrameAiAutoReplyLanguage:LYR_AUTO_LANGS.has(language)?language:'auto',
      lyrameAiAutoReplyLength:LYR_AUTO_LENGTHS.has(length)?length:'normal',
      lyrameAiAutoReplyInstructions:raw('lyr-ai-auto-instructions').slice(0,500)
    });
  });
}
function lyrAutoOnAccount(user){
  if(lyrAutoUnsubscribe){try{lyrAutoUnsubscribe();}catch(_){ }lyrAutoUnsubscribe=null;}
  lyrAutoVisibleForAccount=false;
  lyrAutoBackendReady=false;
  const panel=lyrAutoEl('lyr-ai-auto-panel');
  const section=lyrAutoEl('lyr-ai-user-area');
  if(panel)panel.hidden=true;
  if(section)section.hidden=true;
  if(!user)return;
  // Visibility is assigned by the administrator and updates live, no redeploy.
  lyrAutoUnsubscribe=onSnapshot(doc(db,'users',user.uid),snap=>{
    if(auth.currentUser?.uid!==user.uid)return;
    const profile=snap.exists()?snap.data():{};
    const wasAllowed=lyrAutoCanUse();
    lyrAutoVisibleForAccount=profile.lyrameAiAutoReplyVisible===true;
    const allowed=lyrAutoCanUse();
    if(panel)panel.hidden=!allowed;
    if(section)section.hidden=!allowed;
    if(!allowed){
      lyrAutoBackendReady=false;
      return;
    }
    lyrAutoRenderSettings(profile);
    if(!wasAllowed)void lyrAutoCheckBackend();
  },err=>{
    lyrAutoVisibleForAccount=false;
    if(panel)panel.hidden=!lyrAutoIsOwner();
    if(section)section.hidden=!lyrAutoIsOwner();
    lyrAutoFeedback('Lecture des préférences refusée.',true);
  });
  if(lyrAutoIsOwner()){
    if(panel)panel.hidden=false;
    if(section)section.hidden=false;
    void lyrAutoCheckBackend();
  }
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',lyrAutoBindSettings,{once:true});
else lyrAutoBindSettings();
onAuthStateChanged(auth,lyrAutoOnAccount);

/* Chaque message texte privé envoyé depuis LYRAME appelle le backend.
   Ne donne au serveur QUE l'ID du message et l'ID token Firebase de l'expéditeur.
   Le backend valide conversation, expéditeur, destinataire et activation avant de répondre.
   Aucun secret Gemini ou Firebase Service Account n'est présent dans l'APK. */
async function lyrAutoTriggerAfterMessage(convId,messageId,user,conv){
  if(!user || !convId || !messageId)return;
  if(conv?.isGroup===true || conv?.type==='group')return;
  if(!navigator.onLine)return; // Service distant indisponible pendant une vraie déconnexion réseau.
  try{
    const idToken=await user.getIdToken();
    const response=await fetch(LYR_AUTO_ENDPOINT,{
      method:'POST',
      headers:{'Content-Type':'text/plain;charset=UTF-8'},
      body:JSON.stringify({conversationId:convId,messageId,idToken}),
      keepalive:true
    });
    if(!response.ok)console.info('[LYRAME AI reply] Server status',response.status);
  }catch(err){ console.info('[LYRAME AI reply] Deferred/failed request'); }
}
