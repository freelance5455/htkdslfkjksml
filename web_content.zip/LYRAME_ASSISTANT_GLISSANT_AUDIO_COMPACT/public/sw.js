/* ============================================================
   LYRAME service worker — v36
   - Network-only for application content (no post/message/profile cache)
   - Firebase Cloud Messaging background push
   ============================================================ */
importScripts("https://www.gstatic.com/firebasejs/12.4.0/firebase-app-compat.js");
importScripts("https://www.gstatic.com/firebasejs/12.4.0/firebase-messaging-compat.js");

firebase.initializeApp({
  apiKey: "AIzaSyDjusjiXUXFqVJLrEwYTobdP1oKxguTHl4",
  authDomain: "rinix-ai-22f55.firebaseapp.com",
  projectId: "rinix-ai-22f55",
  storageBucket: "rinix-ai-22f55.firebasestorage.app",
  messagingSenderId: "1055181730802",
  appId: "1:1055181730802:web:383b06489ff3b12283716b"
});

const messaging = firebase.messaging();

self.addEventListener("install", () => self.skipWaiting());
self.addEventListener("activate", event => event.waitUntil(self.clients.claim()));

/* Keep LYRAME content network-only: Firestore/Auth remain the source of truth. */
self.addEventListener("fetch", event => {
  if (event.request.method !== "GET") return;
  event.respondWith(fetch(event.request));
});

messaging.onBackgroundMessage(payload => {
  const data = payload?.data || {};
  const title = String(data.title || "LYRAME").slice(0, 120);
  const body = String(data.body || data.preview || "Nouvelle notification").slice(0, 240);
  const url = data.url || "/?screen=notifications";
  const tag = data.tag || data.notificationId || data.messageId || `lyrame-${Date.now()}`;

  return self.registration.showNotification(title, {
    body,
    icon: "/icons/lyrame-v69-icon-192.png",
    badge: "/icons/lyrame-v69-icon-96.png",
    tag,
    renotify: true,
    data: { url, type: data.type || "generic" }
  });
});

self.addEventListener("notificationclick", event => {
  event.notification.close();
  const relative = event.notification?.data?.url || "/?screen=notifications";
  // Une notification distante ne doit pas rediriger hors de LYRAME.
  let targetUrl = new URL('/?screen=notifications', self.location.origin).href;
  try {
    const proposed = new URL(String(relative), self.location.origin);
    if (proposed.origin === self.location.origin && /^https?:$/.test(proposed.protocol)) {
      targetUrl = proposed.href;
    }
  } catch (_) { /* conserver la destination sûre */ }

  event.waitUntil((async () => {
    const windows = await self.clients.matchAll({ type: "window", includeUncontrolled: true });
    for (const client of windows) {
      try {
        if (new URL(client.url).origin !== self.location.origin) continue;
        client.postMessage({ type: "LYRAME_PUSH_OPEN", url: targetUrl });
        await client.focus();
        return;
      } catch (_) { /* continue */ }
    }
    return self.clients.openWindow(targetUrl);
  })());
});
