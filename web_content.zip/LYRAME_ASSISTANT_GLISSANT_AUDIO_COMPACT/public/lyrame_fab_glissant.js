/* LYRAME — Déplacement tactile de l'assistant dans la conversation.
   Un clic ouvre l'assistant ; un glissement déplace l'icône et l'aimante
   au bord gauche ou droit. Préférence de position conservée sur l'appareil. */
(function () {
  'use strict';
  const KEY = 'lyrame-conversation-assistant-position-v1';
  const btn = document.getElementById('conversation-assistant-fab');
  const screen = document.getElementById('screen-conversation');
  const messages = document.getElementById('conv-messages');
  if (!btn || !screen || !messages) return;

  const safeClamp = (v, lo, hi) => Math.min(Math.max(v, lo), Math.max(lo, hi));
  let saved = null;
  try {
    const v = JSON.parse(localStorage.getItem(KEY) || 'null');
    if (v && (v.side === 'left' || v.side === 'right') && Number.isFinite(v.y)) {
      saved = { side: v.side, y: safeClamp(v.y, 0, 1) };
    }
  } catch (_) { /* Le stockage privé peut être bloqué. */ }

  let gesture = null;
  let ignoreNextClick = false;
  let ignoreTimer = 0;
  let layoutQueued = false;
  const pixel = n => `${Math.round(n * 10) / 10}px`;

  function bounds() {
    if (!screen.classList.contains('active')) return null;
    const sr = screen.getBoundingClientRect();
    const mr = messages.getBoundingClientRect();
    const bw = btn.offsetWidth || 51;
    const bh = btn.offsetHeight || 51;
    if (sr.width <= bw + 24 || sr.height <= bh + 24) return null;
    const minX = 12;
    const maxX = Math.max(minX, sr.width - bw - 12);
    const minY = Math.max(10, mr.top - sr.top + 8);
    const maxY = Math.max(minY, mr.bottom - sr.top - bh - 8);
    return { minX, maxX, minY, maxY, width: sr.width, height: sr.height, bw, bh };
  }

  function draw(x, y, b) {
    btn.style.setProperty('--lyr-fab-left', pixel(safeClamp(x, b.minX, b.maxX)));
    btn.style.setProperty('--lyr-fab-top', pixel(safeClamp(y, b.minY, b.maxY)));
    btn.classList.add('lyr-fab-positioned');
  }

  function position() {
    if (gesture) return;
    const b = bounds();
    if (!b) return;
    const side = saved?.side || 'right';
    const x = side === 'left' ? b.minX : b.maxX;
    const y = saved ? b.minY + saved.y * (b.maxY - b.minY)
                    : safeClamp(b.height - b.bh - 88, b.minY, b.maxY);
    draw(x, y, b);
  }

  function queuePosition() {
    if (layoutQueued) return;
    layoutQueued = true;
    requestAnimationFrame(() => { layoutQueued = false; position(); });
  }

  function endGesture(e) {
    const g = gesture;
    if (!g || e.pointerId !== g.id) return;
    gesture = null;
    btn.classList.remove('lyr-fab-dragging');
    try { if (btn.hasPointerCapture(g.id)) btn.releasePointerCapture(g.id); } catch (_) {}
    if (!g.moved) return; // Un appui normal ouvre l'assistant.

    const b = bounds();
    if (b) {
      const x = safeClamp(g.lastX, b.minX, b.maxX);
      const y = safeClamp(g.lastY, b.minY, b.maxY);
      const side = x + b.bw / 2 < b.width / 2 ? 'left' : 'right';
      const snappedX = side === 'left' ? b.minX : b.maxX;
      const ratio = b.maxY > b.minY ? (y - b.minY) / (b.maxY - b.minY) : 0;
      saved = { side, y: safeClamp(ratio, 0, 1) };
      draw(snappedX, y, b);
      try { localStorage.setItem(KEY, JSON.stringify(saved)); } catch (_) {}
    }

    // Empêcher le clic synthétique déclenché à la fin d'un glissement.
    ignoreNextClick = true;
    clearTimeout(ignoreTimer);
    ignoreTimer = window.setTimeout(() => { ignoreNextClick = false; }, 650);
  }

  btn.addEventListener('pointerdown', e => {
    if (gesture || (e.pointerType === 'mouse' && e.button !== 0) || !e.isPrimary) return;
    const b = bounds();
    if (!b) return;
    position();
    const sr = screen.getBoundingClientRect();
    const br = btn.getBoundingClientRect();
    gesture = {
      id: e.pointerId, startClientX: e.clientX, startClientY: e.clientY,
      startX: br.left - sr.left, startY: br.top - sr.top,
      lastX: br.left - sr.left, lastY: br.top - sr.top, moved: false
    };
    try { btn.setPointerCapture(e.pointerId); } catch (_) {}
  });

  btn.addEventListener('pointermove', e => {
    const g = gesture;
    if (!g || e.pointerId !== g.id) return;
    const dx = e.clientX - g.startClientX;
    const dy = e.clientY - g.startClientY;
    if (!g.moved && Math.hypot(dx, dy) < 7) return;
    g.moved = true;
    e.preventDefault();
    const b = bounds();
    if (!b) return;
    btn.classList.add('lyr-fab-dragging');
    g.lastX = safeClamp(g.startX + dx, b.minX, b.maxX);
    g.lastY = safeClamp(g.startY + dy, b.minY, b.maxY);
    draw(g.lastX, g.lastY, b);
  }, { passive: false });

  btn.addEventListener('pointerup', endGesture);
  btn.addEventListener('pointercancel', endGesture);
  btn.addEventListener('click', e => {
    if (!ignoreNextClick) return;
    ignoreNextClick = false;
    clearTimeout(ignoreTimer);
    e.preventDefault();
    e.stopImmediatePropagation();
  }, true);
  btn.addEventListener('dragstart', e => e.preventDefault());

  window.addEventListener('resize', queuePosition, { passive: true });
  window.visualViewport?.addEventListener('resize', queuePosition, { passive: true });
  if (typeof ResizeObserver !== 'undefined') {
    const ro = new ResizeObserver(queuePosition);
    ro.observe(screen);
    ro.observe(messages);
  }
  const mo = new MutationObserver(queuePosition);
  mo.observe(screen, { attributes: true, attributeFilter: ['class'] });
  queuePosition();
})();
