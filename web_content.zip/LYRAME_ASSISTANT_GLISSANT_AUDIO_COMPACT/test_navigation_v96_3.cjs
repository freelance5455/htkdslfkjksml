#!/usr/bin/env node
'use strict';
/* Test navigation SPA sans accès Firebase/Firestore/réseau. */
const fs = require('fs');
const vm = require('vm');
const assert = require('assert').strict;
const source = fs.readFileSync(__dirname + '/public/script.js', 'utf8');
const begin = source.indexOf('/* V96.3 — Navigation Android');
const end = source.indexOf('\nfunction currentScreenName() {', begin);
assert(begin !== -1 && end > begin, 'Bloc navigation introuvable.');
const nav = source.slice(begin, end);
const routeNames = new Set(['home','messages','conversation','settings','profile-me','post-detail','create','notifications']);
const elements = new Map();
for (const id of ['app-shell','media-viewer','media-viewer-menu','story-viewer','assistant-history-sheet','confirm-modal','header-inline-search']) {
  elements.set(id, { id, hidden: id !== 'app-shell', classList: {
    contains(cls) {return cls === 'hidden' && elements.get(id).hidden;},
    add(cls) {if (cls === 'hidden') elements.get(id).hidden = true;},
    remove(cls) {if (cls === 'hidden') elements.get(id).hidden = false;}
  }, querySelectorAll: () => [] });
}
const stack = [{ state: null }];
let index = 0;
let current = 'home';
let auth = 'login';
const timers = [];
const ctx = {
  console,
  location:{href:'https://example.invalid/',pathname:'/'},
  state: {currentUser:null,screenStack:[], storyTimer:null,mediaViewerGallery:false},
  dynamicModals:[], confirmResolver:null,
  setTimeout:fn=>{timers.push(fn);return timers.length;}, clearTimeout:()=>{},
  lyrameStopStoryPlayback:()=>{},assistantCloseHistory:()=>{elements.get('assistant-history-sheet').hidden=true;},
  closeHeaderInlineSearch:()=>{elements.get('header-inline-search').hidden=true;},
  resolveConfirm:()=>{elements.get('confirm-modal').hidden=true;},
  hideEl:el=>{if (el) el.hidden=true;},
  isShown:el=>!!el&&!el.hidden,
  $:sel=>{
    if(sel.startsWith('#app-shell .screen[data-screen=')) {
      const match = sel.match(/data-screen="([^"]+)"/);
      return match && routeNames.has(match[1]) ? {dataset:{screen:match[1]}}:null;
    }
    return elements.get(sel.replace(/^#/,''))||null;
  },
  document:{getElementById:id=>elements.get(id)||null},
  currentScreenName:()=>current,
  showScreen:(name,opts={})=>{current=name;if(!ctx.lyrameAndroidApplyingHistory)ctx.lyrameAndroidRememberScreen(name,opts.push!==false);},
  showAuthPanel:(name,opts={})=>{auth=name;if(!ctx.lyrameAndroidApplyingHistory)ctx.lyrameAndroidRememberScreen('auth:'+name,opts.push!==false);}
};
ctx.history={
  get state(){return stack[index].state;},
  pushState(state){stack.splice(index+1);stack.push({state:structuredClone(state)});index++;},
  replaceState(state){stack[index]={state:structuredClone(state)};},
  back(){if(index>0){index--;ctx.lyrameAndroidOnPopState({state:stack[index].state});}}
};
vm.createContext(ctx);
vm.runInContext(nav,ctx);
function run(code){return vm.runInContext(code,ctx);}
function flush(){let steps=0;while(timers.length&&steps++<50){timers.shift()();}assert(steps<50,'Too many timers');}
function test(label,func){func();console.log('OK:',label);}

test('Auth login/register + bouton Retour Android',()=>{
  run('lyrameAndroidRememberScreen("auth:login", false)');
  run('showAuthPanel("register")');
  assert.equal(index,1);assert.equal(auth,'register');
  ctx.history.back(); assert.equal(auth,'login');
  // Return to registration via UI to continue testing authenticated transition.
  run('showAuthPanel("register")');
});
test('Utilisateur connecté : accueil → messages → conversation → Retour → Retour',()=>{
  ctx.state.currentUser={uid:'test'};
  ctx.state.screenStack=['home'];
  run('lyrameAndroidRememberScreen("home", false)');
  current='home';
  ctx.state.screenStack.push('messages');run('showScreen("messages")');
  ctx.state.screenStack.push('conversation');run('showScreen("conversation")');
  assert.equal(current,'conversation');
  ctx.history.back();assert.equal(current,'messages');
  ctx.history.back();assert.equal(current,'home');
});
test('Miverina amin’ny efijery efa eo tsy mamorona entrée vaovao',()=>{
  const before=index;
  run('showScreen("home")');
  assert.equal(index,before);
});
test('Overlay plein écran : bouton Retour manidy aloha fa tsy miala amin’ny Accueil',()=>{
  elements.get('media-viewer').hidden=false;
  run('lyrameAndroidPushOverlayId("media-viewer")');
  assert.equal(ctx.history.state.__lyrame_v963_overlay,'media-viewer');
  ctx.history.back();
  assert.equal(elements.get('media-viewer').hidden,true);
  assert.equal(current,'home');
});
test('Fermer avec X : tsy miteraka retour écran roa',()=>{
  elements.get('media-viewer').hidden=false;
  run('lyrameAndroidPushOverlayId("media-viewer")');
  elements.get('media-viewer').hidden=true;
  run('lyrameAndroidOverlayClosed("media-viewer")');
  flush();
  assert.equal(ctx.history.state.__lyrame_v963_overlay,undefined);
  assert.equal(current,'home');
});
test('Aucune entrée écran voaforona amin’ny popstate tsy fantatra',()=>{
  const previous=current;
  run('lyrameAndroidOnPopState({state:null})');
  assert.equal(current,previous);
});
console.log('✅ Fitsapana 6/6 : tantanan’ny History API ny Retour Android.');
