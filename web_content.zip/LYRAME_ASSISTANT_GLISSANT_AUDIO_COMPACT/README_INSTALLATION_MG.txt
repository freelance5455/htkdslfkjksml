LYRAME — Automatisation IA : droits d'affichage par compte

Administration LYRAME > Comptes utilisateurs > sélectionner un utilisateur > Automatisation IA :
- Afficher l'automatisation dans les Paramètres du membre : autorise à VOIR la fonction.
- Activer réellement la réponse IA : permet au serveur de répondre aux messages (si l'accès est accordé).
- Deux boutons INDEPENDANTS : Afficher ne met pas automatiquement l'IA en marche.

Le membre autorisé retrouvera l'option dans Paramètres > Messagerie intelligente,
en dehors de l'Espace propriétaire. Les changements admin se reflètent
avec Firestore onSnapshot sans devoir refaire un déploiement pour chaque compte.

Limitation: la demande au backend IA est déclenchée par une app LYRAME
récente au moment où l'expéditeur envoie un message. Le propriétaire
peut être déconnecté. Il ne s'agit pas d'un déclencheur Firestore natif
pour tous les clients historiques.

Firebase et Firestore Rules : aucun changement. Hébergement uniquement.

Commande Termux après téléchargement depuis Google Drive :
cd ~ && unzip -o /sdcard/Download/LYRAME_AUTOMATION_VISIBILITE.zip -d ~ && cd ~/LYRAME_AUTOMATION_VISIBILITE && node --check public/script.js && node verify_automation_access.cjs && firebase deploy --only hosting --project rinix-ai-22f55
