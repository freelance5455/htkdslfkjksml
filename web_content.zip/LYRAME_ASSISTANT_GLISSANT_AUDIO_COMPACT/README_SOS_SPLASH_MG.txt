LYRAME — FAMERENANA NY SPLASH ANIMÉ (HTML)

Naverina ilay animation LYRAME Signature Motion rehefa nosorina tamin'ny andrana PWABuilder teo aloha.

Naverina ihany:
- ilay rafitra splash ao amin'ny public/index.html sy lien CSS;
- ilay fonction initSplashAnimation ao amin'ny public/script.js;
- ilay style LYRAME Signature mitazona ny background logo ORIGINAL.

Tsy novaina: Firebase, .firebaserc, firebase.json, Firestore rules, API, Floot, Cloudinary, logo original, na ireo pejy hafa.

IMPORTANT: Tsy manaisotra ny splash natif PWABuilder/Android ity ZIP ity. Ho an'ny Android 12+, ny rafitra Android mihitsy no mety mampiseho splash fohy. Ilay animation HTML manokana dia miverina rehefa tafiditra ny app. Raha hialana amin'ny effet splash indroa dia tsara alamina ny logo/background natif amin'ny PWABuilder rehefa hanamboatra APK vaovao.

Commande Termux:
cd ~ && unzip -o /sdcard/Download/LYRAME_RESTAURATION_SPLASH_ANIME.zip -d ~ && cd ~/LYRAME_RESTAURATION_SPLASH_ANIME && node --check public/script.js && node verify_splash.cjs && firebase deploy --only hosting --project rinix-ai-22f55

Fanamarihana: tsy natao deploy ho azy ity fichier ity.
