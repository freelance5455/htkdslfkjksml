const fs=require('fs'),crypto=require('crypto');
const html=fs.readFileSync('public/index.html','utf8'),js=fs.readFileSync('public/script.js','utf8');
const css=fs.readFileSync('public/owner-settings.css','utf8');
function requireCheck(value,msg){if(!value){console.error('ERROR:',msg);process.exitCode=1;} else console.log('OK:',msg)}
requireCheck((html.match(/id="lyr-v92-admin-entry"/g)||[]).length===1,'single Administration button');
const settings=html.slice(html.indexOf('id="screen-settings"'),html.indexOf('data-screen="account"'));
requireCheck(settings.includes('id="lyr-v92-admin-entry"'),'Admin button in Paramètres');
const menu=html.slice(html.indexOf('id="screen-menu"'),html.indexOf('id="screen-settings"'));
requireCheck(!menu.includes('id="lyr-v92-admin-entry"'),'No admin button in Menu');
requireCheck(js.includes('founderAuthorized = lyrV92Owner()'),'Owner verification preserved');
requireCheck(js.includes("entry.disabled = !founderAuthorized"),'Unverified founder disabled');
requireCheck(html.includes('owner-settings.css?v=969') && css.length>200,'Owner visual CSS linked');
for(const file of ['firebase.json','.firebaserc','public/sw.js']){
 const reference=JSON.parse(fs.readFileSync('protected_v968.json','utf8'));
 const hash=crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
 const key=Object.keys(reference).find(k=>k.endsWith('/'+file)||k===file);
 if(key)requireCheck(hash===reference[key],'Protected bytes unchanged '+file);
}
if(process.exitCode)process.exit(process.exitCode);
