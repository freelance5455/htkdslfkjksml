const fs=require('fs');const crypto=require('crypto');
const h=JSON.parse(fs.readFileSync('splash_protected_hashes.json','utf8'));
for(const [p,sha] of Object.entries(h)){
  const b=fs.readFileSync(p);const got=crypto.createHash('sha256').update(b).digest('hex');
  if(got!==sha)throw Error('Fichier arovana niova: '+p);
}
const html=fs.readFileSync('public/index.html','utf8');
const css=fs.readFileSync('public/lyrame_splash_signature.css','utf8');
const js=fs.readFileSync('public/script.js','utf8');
for(const x of ['lyr-signature-splash','lyr-sig-logo','lyr-sig-spark','lyr-sig-word','lyr-sig-tagline','/lyrame_splash_signature.css?v=sig1']){
 if(!html.includes(x))throw Error('Missing splash element '+x);
}
if((html.match(/id="lyrame-splash"/g)||[]).length!==1)throw Error('Duplicate splash');
if(!css.includes('overflow:hidden')||!css.includes('border-radius:22%'))throw Error('Logo clipping missing');
if(!js.includes('2150')||!js.includes('initSplashAnimation'))throw Error('Splash lifecycle missing');
console.log('OK: splash signature + original logo + protected files + JS syntax (separate node --check).');
