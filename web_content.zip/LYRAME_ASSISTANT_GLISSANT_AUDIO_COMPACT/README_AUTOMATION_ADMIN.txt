LYRAME — Gestion IA par utilisateur

Admin > Comptes utilisateurs > sélectionner une personne > Automatisation IA du compte.
Activer ou désactiver, choisir langue, ton, longueur, consignes puis Enregistrer.
Après CE déploiement initial, les changements administratifs suivants se font sans deploy : Floot persiste les paramètres dans users/{uid}.
Le backend vérifie systématiquement le compte fondateur via Firebase ID token (adresse et emailVerified).
Seul le backend Floot écrit les paramètres des autres utilisateurs, pas le navigateur.
Assistant IA = système distinct du compte humain, messages marqués.
Limites: les réponses dépendent d'un message déclenché par un client LYRAME moderne, de la disponibilité du serveur et de Gemini. Un traitement événementiel entièrement indépendant des clients nécessiterait un trigger backend supplémentaire.
Firebase configuration / firestore.rules non modifiés. Firebase deploy --only hosting.
