LYRAME — AUTOMATISATION INTELLIGENTE DES MESSAGES

Paramètres > Espace propriétaire > Réponse automatique IA
Compte: christionalain1@gmail.com (Firebase Auth, adresse vérifiée).

Lorsqu'elle est activée, la valeur users/{UID}/lyrameAiAutoReplyEnabled=true est enregistrée dans Firestore. Aucun changement de Firebase config ou firestore.rules.
Le backend Floot existant (lyrame-assistant-backend.floot.app) valide l'expéditeur et la conversation, lit l'indicateur, puis interroge Gemini et écrit une réponse signée Assistant LYRAME.
L'expéditeur déclenche le backend après l'envoi d'un message texte privé depuis cette nouvelle version web.
Limite: si l'expéditeur envoie depuis une ancienne version sans déclenchement, un appareil hors ligne, ou si le serveur/API Gemini échoue, la réponse n'est pas garantie. Le téléphone du propriétaire peut être fermé.
Non pris en charge: conversations de groupe, médias sans texte, réponse autonome à des messages qui n'ont pas été signalés au backend.

DÉPLOIEMENT TERMUX (Hosting seulement):
cd ~ && unzip -o /sdcard/Download/LYRAME_V96_10_AUTOMATION_IA.zip -d ~ && cd ~/LYRAME_V96_10_AUTOMATION_IA && node --check public/script.js && node verify_automation.cjs && firebase deploy --only hosting --project rinix-ai-22f55

ATTENTION: L'AI requiert des secrets stockés SUR LE SERVEUR Floot. Ne jamais coller de clé privée dans les fichiers publics.
