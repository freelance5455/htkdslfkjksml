const fs=require('node:fs'),crypto=require('node:crypto');
const assert=require('node:assert/strict');
const h=fs.readFileSync('public/index.html','utf8');
const j=fs.readFileSync('public/script.js','utf8');
const css=fs.readFileSync('public/messages-modern.css','utf8');
const count=(str,s)=>(str.match(new RegExp(s,'g'))||[]).length;
for (const id of ['messages-new-message','messages-assistant-entry','messages-search','messages-create-group-btn','conversations-list']) {
 assert.equal(count(h,`id="${id}"`),1,'ID unique: '+id);
}
assert(!h.includes('id="messages-stories"'),'No duplicate conversation strip');
assert(h.includes('href="/messages-modern.css?v=968"'));
assert(css.includes('html[data-theme="dark"]'));
assert(j.includes('lyrameMessagesUpdateCount(items.length)'));
assert(j.includes('lyrameMessagesFilterConversations()'));
assert(j.includes('lyrameMessagesTranslateHeader()'));
assert(j.includes('renderConversationItem(c)'));
assert(j.includes('openConversation(c.id)'));
assert(j.includes('showScreen("assistant")'));
assert(h.indexOf('id="messages-new-message"')<h.indexOf('id="conversations-list"'));
// Config unchanged from original ZIP's deploy requirements
const checksums=JSON.parse(fs.readFileSync('protected_v968.json','utf8'));
for(const [p,v] of Object.entries(checksums)){
  const actual=crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
  assert.equal(actual,v,`Protected file changed: ${p}`);
}
console.log('OK: Messages UI, unique actions, dark mode, original data wiring, protected configs');
