LYRAME - Fanatsarana Messages

- Lisitra tokana ho an'ny discussions; nesorina ny cartes miverimberina teo ambony.
- Search bar hita mandrakariva (afaka mitady olona/vondrona ary manivana ny discussions eto amin'ny pejy).
- Nouveau message sy assistant ao amin'ny lohan'ny pejy (tsy misy boutons lehibe mitsingevana).
- Créer un groupe azo jerena eo akaikin'ny fikarohana.
- Cartes conversations, couleurs, mode sombre, tailles téléphone nalamina.
- Firebase, Firestore Rules sy données tsy novaina. Tsy manao deploy mihitsy ny Firestore Rules.
- Tsy misy numéro de version na fanazavana fanamboarana aseho ao amin'ny app.

TERMUX :
cd ~ && unzip -o /sdcard/Download/LYRAME_V96_8_MESSAGES_MODERNES.zip -d ~ && cd ~/LYRAME_V96_8_MESSAGES_MODERNES && node --check public/script.js && node verify_messages.cjs && firebase deploy --only hosting --project rinix-ai-22f55
