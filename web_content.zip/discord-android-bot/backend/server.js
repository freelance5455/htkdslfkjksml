import express from 'express';
import { Client, GatewayIntentBits, ChannelType } from 'discord.js';
import crypto from 'node:crypto';

const { DISCORD_BOT_TOKEN, APP_PASSWORD } = process.env;
if (!DISCORD_BOT_TOKEN || !APP_PASSWORD || APP_PASSWORD.length < 16) {
  console.error('Set DISCORD_BOT_TOKEN and APP_PASSWORD (at least 16 characters).');
  process.exit(1);
}
const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '16kb' }));
app.get('/', (_req, res) => res.sendFile(new URL('./index.html', import.meta.url).pathname));
const client = new Client({ intents: [GatewayIntentBits.Guilds] });
const sessions = new Map();
const SESSION_MS = 12 * 60 * 60 * 1000;
const secureEqual = (a, b) => {
  const aa = Buffer.from(String(a)); const bb = Buffer.from(String(b));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
};

app.post('/api/login', (req, res) => {
  if (!secureEqual(req.body?.password ?? '', APP_PASSWORD)) return res.status(401).json({ error: 'Incorrect password.' });
  const token = crypto.randomBytes(32).toString('base64url');
  sessions.set(token, Date.now() + SESSION_MS);
  res.json({ token, expiresInSeconds: SESSION_MS / 1000 });
});
function auth(req, res, next) {
  const token = req.get('authorization')?.replace(/^Bearer\s+/i, '');
  const expires = token && sessions.get(token);
  if (!expires || expires < Date.now()) { if (token) sessions.delete(token); return res.status(401).json({ error: 'Session expired. Sign in again.' }); }
  next();
}
app.get('/api/guilds', auth, async (_req, res) => {
  try {
    await client.guilds.fetch();
    res.json([...client.guilds.cache.values()].map(g => ({ id: g.id, name: g.name })).sort((a,b) => a.name.localeCompare(b.name)));
  } catch { res.status(503).json({ error: 'Could not load servers from Discord yet.' }); }
});
app.get('/api/guilds/:guildId/channels', auth, async (req, res) => {
  try {
    const guild = await client.guilds.fetch(req.params.guildId);
    const channels = await guild.channels.fetch();
    res.json([...channels.values()].filter(c => c && [ChannelType.GuildText, ChannelType.GuildAnnouncement].includes(c.type))
      .map(c => ({ id: c.id, name: c.name, parentName: c.parent?.name ?? '' }))
      .sort((a,b) => a.name.localeCompare(b.name)));
  } catch { res.status(404).json({ error: 'Could not load channels. Check bot membership and permissions.' }); }
});
app.post('/api/channels/:channelId/messages', auth, async (req, res) => {
  const content = typeof req.body?.content === 'string' ? req.body.content.trim() : '';
  if (!content || content.length > 2000) return res.status(400).json({ error: 'Message must be between 1 and 2000 characters.' });
  try {
    const channel = await client.channels.fetch(req.params.channelId);
    if (!channel?.isTextBased() || !('send' in channel)) return res.status(400).json({ error: 'That is not a sendable text channel.' });
    const sent = await channel.send({ content });
    res.json({ ok: true, messageId: sent.id });
  } catch { res.status(502).json({ error: 'Discord did not accept the message. Check channel permissions.' }); }
});
app.get('/health', (_req, res) => res.json({ ok: true, discordReady: client.isReady() }));
const port = Number(process.env.PORT || 8787);
app.listen(port, () => console.log(`API listening on ${port}`));
client.once('ready', c => console.log(`Discord bot connected as ${c.user.tag}`));
client.login(DISCORD_BOT_TOKEN).catch(err => { console.error('Discord bot login failed:', err.message); process.exit(1); });
