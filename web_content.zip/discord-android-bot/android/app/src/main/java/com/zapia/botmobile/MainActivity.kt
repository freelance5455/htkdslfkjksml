package com.zapia.botmobile

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private data class Item(val id: String, val name: String, val extra: String = "")

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContent { MaterialTheme { BotApp() } }
  }
}

@Composable
private fun BotApp() {
  val scope = rememberCoroutineScope()
  var base by remember { mutableStateOf("") }
  var password by remember { mutableStateOf("") }
  var session by remember { mutableStateOf<String?>(null) }
  var guilds by remember { mutableStateOf(listOf<Item>()) }
  var channels by remember { mutableStateOf(listOf<Item>()) }
  var selectedGuild by remember { mutableStateOf<Item?>(null) }
  var selectedChannel by remember { mutableStateOf<Item?>(null) }
  var message by remember { mutableStateOf("") }
  var status by remember { mutableStateOf("Enter your secure backend URL to connect.") }
  var busy by remember { mutableStateOf(false) }

  fun request(method: String, path: String, body: JSONObject? = null, token: String? = session): String {
    val root = base.trim().removeSuffix("/")
    require(root.startsWith("https://")) { "Use an HTTPS backend URL." }
    val conn = (URL(root + path).openConnection() as HttpURLConnection).apply {
      requestMethod = method; connectTimeout = 12000; readTimeout = 20000
      setRequestProperty("Accept", "application/json")
      if (token != null) setRequestProperty("Authorization", "Bearer $token")
      if (body != null) { doOutput = true; setRequestProperty("Content-Type", "application/json; charset=utf-8") }
    }
    if (body != null) conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
    val code = conn.responseCode
    val raw = (if (code in 200..299) conn.inputStream else conn.errorStream)?.bufferedReader()?.use { it.readText() } ?: "{}"
    conn.disconnect()
    val json = JSONObject(raw)
    if (code !in 200..299) error(json.optString("error", "Request failed ($code)."))
    return raw
  }
  fun launchRequest(action: suspend () -> Unit) {
    scope.launch { busy = true; try { action() } catch (e: Exception) { status = e.message ?: "Something went wrong." } finally { busy = false } }
  }

  Surface(modifier = Modifier.fillMaxSize()) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
      Text("Discord Bot Mobile", style = MaterialTheme.typography.headlineSmall)
      Text("Use your bot through Discord's API. The bot token stays on your backend.", style = MaterialTheme.typography.bodyMedium)
      OutlinedTextField(base, { base = it }, label = { Text("Backend HTTPS URL") }, placeholder = { Text("https://your-server.example") }, singleLine = true, modifier = Modifier.fillMaxWidth())
      if (session == null) {
        OutlinedTextField(password, { password = it }, label = { Text("Backend password") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Button(enabled = !busy && password.isNotBlank(), onClick = { launchRequest {
          val resp = withContext(Dispatchers.IO) { request("POST", "/api/login", JSONObject().put("password", password), null) }
          session = JSONObject(resp).getString("token")
          val list = withContext(Dispatchers.IO) { request("GET", "/api/guilds") }
          guilds = parseItems(list); status = "Connected. Choose a server."
        } }) { Text(if (busy) "Connecting…" else "Sign in") }
      } else {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Button(enabled = !busy, onClick = { launchRequest {
            val list = withContext(Dispatchers.IO) { request("GET", "/api/guilds") }; guilds = parseItems(list); status = "Choose a server."
          } }) { Text("Servers") }
          TextButton(onClick = { session = null; guilds = emptyList(); channels = emptyList(); selectedGuild = null; selectedChannel = null; status = "Signed out." }) { Text("Sign out") }
        }
        if (selectedGuild == null) {
          Text("Servers", style = MaterialTheme.typography.titleMedium)
          LazyColumn(Modifier.weight(1f)) { items(guilds) { item -> ListItem(headlineContent = { Text(item.name) }, modifier = Modifier.clickable {
            selectedGuild = item; selectedChannel = null
            launchRequest { val list = withContext(Dispatchers.IO) { request("GET", "/api/guilds/${item.id}/channels") }; channels = parseItems(list); status = "Choose a text channel in ${item.name}." }
          }) } }
        } else {
          TextButton(onClick = { selectedGuild = null; selectedChannel = null; channels = emptyList() }) { Text("← Servers · ${selectedGuild!!.name}") }
          if (selectedChannel == null) {
            Text("Text channels", style = MaterialTheme.typography.titleMedium)
            LazyColumn(Modifier.weight(1f)) { items(channels) { item -> ListItem(headlineContent = { Text("# ${item.name}") }, modifier = Modifier.clickable { selectedChannel = item; status = "Ready to send in #${item.name}." }) } }
          } else {
            Text("Selected: #${selectedChannel!!.name}")
            OutlinedTextField(message, { message = it }, label = { Text("Message as bot") }, modifier = Modifier.fillMaxWidth(), minLines = 2, maxLines = 5)
            Button(enabled = !busy && message.isNotBlank(), onClick = { launchRequest {
              val target = selectedChannel!!; val payload = JSONObject().put("content", message)
              withContext(Dispatchers.IO) { request("POST", "/api/channels/${target.id}/messages", payload) }
              message = ""; status = "Message sent to #${target.name}."
            } }) { Text(if (busy) "Sending…" else "Send") }
          }
        }
      }
      Text(status, style = MaterialTheme.typography.bodySmall)
    }
  }
}

private fun parseItems(raw: String): List<Item> {
  val arr = JSONArray(raw)
  return (0 until arr.length()).map { i -> val o = arr.getJSONObject(i); Item(o.getString("id"), o.getString("name"), o.optString("parentName")) }
}
