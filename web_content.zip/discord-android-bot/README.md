# Discord Bot Mobile — Android starter

A small Android dashboard for a Discord bot, using Discord's supported bot API via a companion backend. This is **not** a modified Discord client and does not log in as a human user.

## What it does
- Sign in to your private backend.
- List servers the bot has joined and channels it can view.
- Select a text channel and send a message as the bot.

## Security model
The Discord bot token is held only in the backend's `DISCORD_BOT_TOKEN` environment variable; never paste it into Android or commit it. The Android app holds a short-lived backend session only in memory. The included backend is a starter: deploy it behind HTTPS, set a strong unique `APP_PASSWORD`, and restrict who can reach it before using it beyond a private test. Sessions are in-memory and expire after 12 hours.

## 1) Create and invite a Discord bot
1. Create an application and bot in the [Discord Developer Portal](https://discord.com/developers/applications).
2. Copy the bot token into the backend environment (not into the app).
3. Invite the bot to your server with `bot` scope and the minimum permissions it needs: View Channels, Read Message History, and Send Messages.
4. The backend needs outbound internet access to Discord's Gateway and REST API.

## 2) Run the backend
Requires Node.js 20 or newer.

```sh
cd backend
npm install
DISCORD_BOT_TOKEN='your-bot-token' APP_PASSWORD='choose-a-long-unique-password' npm start
```

By default the API and browser dashboard (`/`) listen on port 8787. Open the backend root URL in a browser to use `index.html`; for an Android phone or remote browser to reach it, deploy it to a host with HTTPS and set `PORT` as needed. Do not expose the starter over plain public HTTP.

## 3) Build and run Android app
Open the `android` folder in Android Studio. Set the backend URL to your HTTPS API base (for example `https://your-host.example`) in the app, sign in with `APP_PASSWORD`, then choose a server and channel.

Build with Android Studio / Gradle. This source bundle does not include a prebuilt APK or Gradle wrapper.

## Notes
- The app sends a message only when you tap **Send**.
- This MVP lists text-based channels the bot can access. Discord permissions and bot membership still apply.
- The server uses Discord.js Gateway to discover guilds; keep its process running.
