DZ Code web version — how to use on Android

1. Download DZ_Code_Web_Version.zip.
2. Open your phone's Files app and find the ZIP in Downloads.
3. Tap it and choose Extract.
4. Open the extracted folder and tap index.html.
5. Choose Chrome if Android asks which app to use.
6. Test each COPY button. If copying is blocked in a file preview, open index.html
   directly in Chrome rather than a file manager's preview.

Optional home screen shortcut:
- To make it easier to open, host the HTML on a static website (for example,
  GitHub Pages) and open that site in Chrome.
- In Chrome, tap ⋮ > Add to Home screen.

This is a web app, not an APK. It copies the three snippets as text; it does not
inject a mod menu into a game.
