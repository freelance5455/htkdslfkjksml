मतदाता पर्ची ऐप — लॉगिन और APK पैकेज
======================================

क्या शामिल है
- web/index.html : आपका मौजूदा ऐप, परिवार फिल्टर और हिंदी रास्टर प्रिंटिंग सहित
- web/config.js : सर्वर का HTTPS पता सेट करने की जगह
- server/ : लॉगिन API और SQLite यूजर डेटाबेस

लॉगिन सिस्टम
1. मुख्य एडमिन मोबाइल नंबर + पासवर्ड से लॉगिन करेगा।
2. मुख्य एडमिन ऐप में “यूजर मैनेजमेंट” से दूसरे मोबाइल नंबर और पासवर्ड बनाएगा।
3. मुख्य एडमिन यूजर का पासवर्ड बदल सकता है और यूजर को बंद/चालू कर सकता है।
4. एक मोबाइल ID का एक ही सक्रिय सेशन रहेगा। वही ID दूसरे फोन में लॉगिन होते ही पहले फोन का सेशन अमान्य हो जाएगा (अगली सर्वर जाँच अधिकतम लगभग 12 सेकंड में लॉगआउट कर देगी)।
5. पासवर्ड सर्वर पर scrypt hash के रूप में रखे जाते हैं; plain text में नहीं।

जरूरी: यह केवल HTML फाइल से सुरक्षित रूप से संभव नहीं है। इसलिए सर्वर को इंटरनेट पर HTTPS के साथ चालू रखना होगा। APK में भी वही सर्वर पता इस्तेमाल होगा।

सर्वर सेटअप (Node.js 18+)
1. server/.env.example की कॉपी server/.env नाम से बनाएँ।
2. ADMIN_MOBILE और ADMIN_PASSWORD को अपने मुख्य एडमिन के मोबाइल और मजबूत पासवर्ड से बदलें। पासवर्ड कम से कम 10 अक्षर रखें।
3. server फोल्डर में टर्मिनल खोलें और चलाएँ: npm install
4. फिर चलाएँ: npm start
5. इस सर्वर को HTTPS डोमेन वाले VPS/hosting पर deploy करें। डेटा सुरक्षित रखने के लिए server/data.sqlite का persistent backup रखें।
6. web/config.js में window.APP_API_BASE को अपने सर्वर के HTTPS URL से बदलें, जैसे https://app.example.in (अंत में / न लगाएँ)।
7. web फोल्डर को सर्वर के साथ deploy करें; सर्वर वही वेब ऐप भी serve करता है।

APK बनाने का रास्ता
यह ZIP source package है, बनी हुई APK नहीं। Android Studio में Capacitor wrapper बनाकर APK बनाई जा सकती है।
1. कंप्यूटर में Node.js और Android Studio/Android SDK लगाएँ।
2. इस project के root में npm install चलाएँ (Capacitor dependencies package.json में शामिल हैं)।
   npx cap add android
   npx cap sync android
   npx cap open android
3. Android Studio में Build > Build Bundle(s) / APK(s) > Build APK(s)।

ध्यान दें: सामान्य Android WebView में Web Bluetooth सपोर्ट डिवाइस के अनुसार उपलब्ध नहीं होता। यदि APK के अंदर से थर्मल प्रिंटर का ब्लूटूथ प्रिंट जरूरी है, तो अगला चरण native Bluetooth plugin/Android integration जोड़ना होगा। Chrome में वेबसाइट चलाकर Web Bluetooth प्रिंट का विकल्प उपलब्ध रह सकता है।

सुरक्षा नोट
- सर्वर को HTTPS पर ही चलाएँ।
- .env, data.sqlite और admin password किसी के साथ साझा न करें।
- पहली बार admin बनाने के बाद admin mobile/password सुरक्षित रखें।
- यह package किसी hosting account में अपने आप deploy नहीं होता।
