require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const Database = require('better-sqlite3');
const crypto = require('crypto');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const DB_FILE = process.env.DB_FILE || path.join(__dirname, 'data.sqlite');
const db = new Database(DB_FILE);
db.pragma('journal_mode = WAL');
db.exec(`CREATE TABLE IF NOT EXISTS users (
 id TEXT PRIMARY KEY, mobile TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'user', active INTEGER NOT NULL DEFAULT 1,
 session_hash TEXT, last_login TEXT, created_at TEXT NOT NULL
)`);
app.use(helmet({contentSecurityPolicy:false}));
app.use(cors({origin:true, methods:['GET','POST','PUT','OPTIONS'], allowedHeaders:['Content-Type','Authorization']}));
app.use(express.json({limit:'100kb'}));
app.use('/api/login', rateLimit({windowMs:15*60*1000, max:12, standardHeaders:true, legacyHeaders:false}));
const hashPassword = (password, salt=crypto.randomBytes(16).toString('hex')) => ({salt, hash:crypto.scryptSync(password,salt,64).toString('hex')});
function verifyPassword(password, stored){try{const [salt,hash]=stored.split(':');const actual=crypto.scryptSync(password,salt,64);return crypto.timingSafeEqual(actual,Buffer.from(hash,'hex'));}catch{return false;}}
const tokenHash = token => crypto.createHash('sha256').update(token).digest('hex');
const cleanMobile = m => String(m||'').replace(/[\s-]/g,'');
function createAdmin(){
 const mobile=cleanMobile(process.env.ADMIN_MOBILE), password=process.env.ADMIN_PASSWORD;
 if(!mobile || !password){console.warn('ADMIN_MOBILE/ADMIN_PASSWORD missing. Configure .env before first start.');return;}
 const existing=db.prepare('SELECT id FROM users WHERE role=?').get('admin');
 if(existing) return;
 if(password.length<8) throw new Error('ADMIN_PASSWORD must be at least 8 characters');
 const p=hashPassword(password);
 db.prepare('INSERT INTO users(id,mobile,password_hash,role,active,created_at) VALUES(?,?,?,?,1,?)').run(crypto.randomUUID(),mobile,p.salt+':'+p.hash,'admin',new Date().toISOString());
 console.log('Main admin account initialized:',mobile);
}
createAdmin();
function auth(req,res,next){
 const token=(req.headers.authorization||'').replace(/^Bearer\s+/i,'');
 if(!token)return res.status(401).json({message:'लॉगिन समाप्त। फिर से लॉगिन करें।'});
 const user=db.prepare('SELECT id,mobile,role,active,session_hash FROM users WHERE session_hash=?').get(tokenHash(token));
 if(!user || !user.active)return res.status(401).json({message:'यह ID किसी दूसरे फोन पर लॉगिन हो चुकी है या खाता बंद है।'});
 req.user=user; next();
}
const adminOnly=(req,res,next)=>req.user.role==='admin'?next():res.status(403).json({message:'केवल मुख्य एडमिन यह काम कर सकता है।'});
app.post('/api/login',(req,res)=>{
 const mobile=cleanMobile(req.body.mobile), password=String(req.body.password||'');
 const user=db.prepare('SELECT * FROM users WHERE mobile=?').get(mobile);
 if(!user || !user.active || !verifyPassword(password,user.password_hash))return res.status(401).json({message:'मोबाइल नंबर या पासवर्ड गलत है।'});
 const token=crypto.randomBytes(32).toString('base64url');
 // Unique current session per account: logging in on a second phone replaces this token.
 db.prepare('UPDATE users SET session_hash=?,last_login=? WHERE id=?').run(tokenHash(token),new Date().toISOString(),user.id);
 res.json({token,user:{id:user.id,mobile:user.mobile,role:user.role}});
});
app.get('/api/me',auth,(req,res)=>res.json({user:{id:req.user.id,mobile:req.user.mobile,role:req.user.role}}));
app.post('/api/logout',auth,(req,res)=>{db.prepare('UPDATE users SET session_hash=NULL WHERE id=?').run(req.user.id);res.json({ok:true});});
app.get('/api/admin/users',auth,adminOnly,(req,res)=>{
 const users=db.prepare("SELECT id,mobile,role,active,last_login FROM users ORDER BY role DESC,created_at DESC").all();res.json({users});
});
app.post('/api/admin/users',auth,adminOnly,(req,res)=>{
 const mobile=cleanMobile(req.body.mobile),password=String(req.body.password||'');
 if(!/^\+?[0-9]{10,15}$/.test(mobile))return res.status(400).json({message:'सही मोबाइल नंबर दर्ज करें।'});
 if(password.length<8)return res.status(400).json({message:'पासवर्ड कम से कम 8 अक्षर का होना चाहिए।'});
 const p=hashPassword(password);
 try{db.prepare("INSERT INTO users(id,mobile,password_hash,role,active,created_at) VALUES(?,?,?,'user',1,?)").run(crypto.randomUUID(),mobile,p.salt+':'+p.hash,new Date().toISOString());res.json({ok:true});}
 catch(e){res.status(409).json({message:'यह मोबाइल नंबर पहले से मौजूद है।'});}
});
app.put('/api/admin/users/:id/password',auth,adminOnly,(req,res)=>{
 const password=String(req.body.password||'');if(password.length<8)return res.status(400).json({message:'पासवर्ड कम से कम 8 अक्षर का होना चाहिए।'});
 const p=hashPassword(password);const r=db.prepare("UPDATE users SET password_hash=?,session_hash=NULL WHERE id=? AND role='user'").run(p.salt+':'+p.hash,req.params.id);
 if(!r.changes)return res.status(404).json({message:'यूजर नहीं मिला।'});res.json({ok:true});
});
app.put('/api/admin/users/:id/active',auth,adminOnly,(req,res)=>{
 const active=req.body.active?1:0;const r=db.prepare("UPDATE users SET active=?,session_hash=NULL WHERE id=? AND role='user'").run(active,req.params.id);
 if(!r.changes)return res.status(404).json({message:'यूजर नहीं मिला।'});res.json({ok:true});
});
app.use(express.static(path.join(__dirname,'..','web')));
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'..','web','index.html')));
app.listen(PORT,()=>console.log(`Voter app server listening on ${PORT}`));
