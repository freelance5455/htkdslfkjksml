// APK/web app API endpoint. Set this to the HTTPS address where server/ is deployed.
window.APP_API_BASE = "https://YOUR-SERVER-DOMAIN";
