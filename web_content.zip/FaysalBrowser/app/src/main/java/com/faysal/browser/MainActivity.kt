package com.faysal.browser

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.io.ByteArrayInputStream

class MainActivity : AppCompatActivity() {

    private val homeUrl = "file:///android_asset/index.html"
    private val searchUrl = "https://www.google.com/search?q="
    private val desktopUa =
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"
    private val tabs = mutableListOf<WebView>()
    private val desktopTabs = mutableSetOf<WebView>()
    private var current = -1

    // ---- Shields (ad / tracker blocking, HTTPS upgrade, cookie blocking) ----
    private var shieldsOn = true
    private val blockedCount = mutableMapOf<WebView, Int>()
    private val upgraded = mutableSetOf<String>()
    private val blockedHosts = setOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "googletagservices.com",
        "googletagmanager.com", "google-analytics.com", "adservice.google.com", "pagead2.googlesyndication.com",
        "2mdn.net", "adnxs.com", "adsrvr.org", "amazon-adsystem.com", "criteo.com", "criteo.net",
        "taboola.com", "outbrain.com", "scorecardresearch.com", "quantserve.com", "quantcount.com",
        "moatads.com", "pubmatic.com", "rubiconproject.com", "openx.net", "casalemedia.com",
        "advertising.com", "adform.net", "smartadserver.com", "bidswitch.net", "contextweb.com",
        "hotjar.com", "mixpanel.com", "segment.io", "segment.com", "fullstory.com", "mouseflow.com",
        "crazyegg.com", "clarity.ms", "chartbeat.com", "newrelic.com", "branch.io", "appsflyer.com",
        "adjust.com", "app-measurement.com", "connect.facebook.net", "analytics.twitter.com",
        "ads-twitter.com", "ads.linkedin.com", "analytics.tiktok.com", "ads.tiktok.com",
        "popads.net", "popcash.net", "propellerads.com", "exoclick.com", "juicyads.com", "mgid.com",
        "revcontent.com", "zedo.com", "yieldmo.com", "media.net", "adsterra.com", "adcolony.com",
        "applovin.com", "unityads.unity3d.com", "ads.yahoo.com", "ads.pinterest.com", "bat.bing.com"
    )

    private lateinit var btnShield: Button
    private lateinit var urlBar: EditText
    private lateinit var progress: ProgressBar
    private lateinit var container: FrameLayout

    private val prefs by lazy { getSharedPreferences("faysal_browser", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        urlBar = findViewById(R.id.urlBar)
        btnShield = findViewById(R.id.btnShield)
        shieldsOn = prefs.getBoolean("shields", true)
        btnShield.setOnClickListener { showShield() }
        progress = findViewById(R.id.progress)
        container = findViewById(R.id.webContainer)

        findViewById<Button>(R.id.btnBack).setOnClickListener { web()?.let { if (it.canGoBack()) it.goBack() } }
        findViewById<Button>(R.id.btnForward).setOnClickListener { web()?.let { if (it.canGoForward()) it.goForward() } }
        findViewById<Button>(R.id.btnReload).setOnClickListener { web()?.reload() }
        findViewById<Button>(R.id.btnMenu).setOnClickListener { showMenu(it) }

        urlBar.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_GO ||
                (event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)
            ) {
                load(urlBar.text.toString())
                hideKeyboard()
                true
            } else false
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val w = web()
                when {
                    w != null && w.canGoBack() -> w.goBack()
                    tabs.size > 1 -> closeTab(current)
                    else -> finish()
                }
            }
        })

        newTab(intent?.data?.toString() ?: homeUrl)
    }

    // ---------- Tabs ----------

    private fun web(): WebView? = tabs.getOrNull(current)

    private fun isBlocked(host: String) =
        blockedHosts.any { host == it || host.endsWith(".$it") }

    private fun isLocal(host: String?): Boolean {
        if (host == null) return true
        return host == "localhost" || host.endsWith(".local") ||
            Regex("^\\d{1,3}(\\.\\d{1,3}){3}$").matches(host)
    }

    private fun upgrade(url: String): String {
        if (!shieldsOn || !url.startsWith("http://")) return url
        val host = Uri.parse(url).host
        if (isLocal(host)) return url
        val https = "https://" + url.removePrefix("http://")
        upgraded.add(https)
        return https
    }

    private fun updateShield() {
        val n = blockedCount[web()] ?: 0
        btnShield.text = if (shieldsOn) "🛡$n" else "🛡off"
    }

    private fun showShield() {
        val n = blockedCount[web()] ?: 0
        val msg = if (shieldsOn)
            "Shields are ON.\n\nBlocked on this page: $n ads/trackers\n\n• Ads and trackers blocked\n• Websites upgraded to HTTPS\n• Third-party cookies blocked"
        else "Shields are OFF. Ads, trackers and third-party cookies are allowed."
        AlertDialog.Builder(this).setTitle("Faysal Shields")
            .setMessage(msg)
            .setPositiveButton(if (shieldsOn) "Turn off" else "Turn on") { _, _ -> setShields(!shieldsOn) }
            .setNegativeButton("Close", null).show()
    }

    private fun setShields(on: Boolean) {
        shieldsOn = on
        prefs.edit().putBoolean("shields", on).apply()
        tabs.forEach { CookieManager.getInstance().setAcceptThirdPartyCookies(it, !on) }
        updateShield()
        web()?.reload()
    }

    private fun shown(u: String) = if (u.startsWith("file:///android_asset")) "" else u

    @SuppressLint("SetJavaScriptEnabled")
    private fun newTab(url: String?) {
        val w = WebView(this)
        w.layoutParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT
        )
        w.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            builtInZoomControls = true
            displayZoomControls = false
            setSupportZoom(true)
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, !shieldsOn)

        w.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView, u: String?, favicon: Bitmap?) {
                blockedCount[view] = 0
                if (view === web()) {
                    updateShield()
                    progress.visibility = View.VISIBLE
                    if (u != null && !urlBar.hasFocus()) urlBar.setText(shown(u))
                }
            }

            override fun onPageFinished(view: WebView, u: String?) {
                if (view === web()) {
                    progress.visibility = View.GONE
                    if (u != null && !urlBar.hasFocus()) urlBar.setText(shown(u))
                }
            }

            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                if (!shieldsOn) return null
                val host = request.url.host ?: return null
                if (!isBlocked(host)) return null
                runOnUiThread {
                    blockedCount[view] = (blockedCount[view] ?: 0) + 1
                    if (view === web()) updateShield()
                }
                return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                val u = request.url.toString()
                if (request.isForMainFrame && upgraded.remove(u)) {
                    view.loadUrl("http://" + u.removePrefix("https://"))
                }
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val scheme = request.url.scheme ?: return false
                if (scheme == "http" && request.isForMainFrame) {
                    val up = upgrade(request.url.toString())
                    if (up != request.url.toString()) { view.loadUrl(up); return true }
                }
                if (scheme == "http" || scheme == "https") return false
                return try {
                    startActivity(Intent(Intent.ACTION_VIEW, request.url)); true
                } catch (e: Exception) { true }
            }
        }

        w.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                if (view === web()) progress.progress = newProgress
            }
        }

        w.setDownloadListener { dlUrl, userAgent, contentDisposition, mimeType, _ ->
            try {
                val req = DownloadManager.Request(Uri.parse(dlUrl))
                req.setMimeType(mimeType)
                req.addRequestHeader("User-Agent", userAgent)
                req.addRequestHeader("Cookie", CookieManager.getInstance().getCookie(dlUrl) ?: "")
                req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                req.setDestinationInExternalPublicDir(
                    Environment.DIRECTORY_DOWNLOADS,
                    URLUtil.guessFileName(dlUrl, contentDisposition, mimeType)
                )
                (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
                Toast.makeText(this, "Downloading…", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Download failed", Toast.LENGTH_SHORT).show()
            }
        }

        tabs.add(w)
        switchTab(tabs.size - 1)
        w.loadUrl(url ?: homeUrl)
    }

    private fun switchTab(index: Int) {
        if (index !in tabs.indices) return
        container.removeAllViews()
        current = index
        val w = tabs[index]
        container.addView(w)
        urlBar.setText(shown(w.url ?: ""))
        progress.visibility = View.GONE
        updateShield()
    }

    private fun closeTab(index: Int) {
        if (index !in tabs.indices) return
        if (tabs.size == 1) { web()?.loadUrl(homeUrl); return }
        val w = tabs.removeAt(index)
        desktopTabs.remove(w)
        blockedCount.remove(w)
        container.removeView(w)
        w.destroy()
        switchTab(minOf(index, tabs.size - 1))
    }

    private fun showTabList() {
        val titles = tabs.mapIndexed { i, w ->
            val t = w.title?.takeIf { it.isNotBlank() } ?: w.url ?: "New tab"
            (if (i == current) "● " else "") + t
        }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Tabs (${tabs.size})")
            .setItems(titles) { _, which -> switchTab(which) }
            .setNegativeButton("Close", null).show()
    }

    // ---------- Navigation ----------

    private fun load(input: String) {
        val text = input.trim()
        if (text.isEmpty()) return
        val url = when {
            text.startsWith("http://") || text.startsWith("https://") -> text
            text.contains(" ") || !text.contains(".") -> searchUrl + Uri.encode(text)
            else -> "https://$text"
        }
        web()?.loadUrl(upgrade(url))
    }

    private fun hideKeyboard() {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(urlBar.windowToken, 0)
        urlBar.clearFocus()
    }

    // ---------- Menu ----------

    private fun showMenu(anchor: View) {
        val pm = PopupMenu(this, anchor)
        pm.menuInflater.inflate(R.menu.main_menu, pm.menu)
        pm.menu.findItem(R.id.menu_desktop).isChecked = web() in desktopTabs
        pm.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.menu_new_tab -> newTab(homeUrl)
                R.id.menu_tabs -> showTabList()
                R.id.menu_close_tab -> closeTab(current)
                R.id.menu_home -> web()?.loadUrl(homeUrl)
                R.id.menu_add_bookmark -> addBookmark()
                R.id.menu_bookmarks -> showBookmarks()
                R.id.menu_desktop -> toggleDesktop(!item.isChecked)
                R.id.menu_share -> sharePage()
                R.id.menu_clear -> clearData()
            }
            true
        }
        pm.show()
    }

    private fun toggleDesktop(enable: Boolean) {
        val w = web() ?: return
        if (enable) desktopTabs.add(w) else desktopTabs.remove(w)
        w.settings.userAgentString = if (enable) desktopUa else null
        w.reload()
    }

    private fun sharePage() {
        val u = web()?.url ?: return
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"; putExtra(Intent.EXTRA_TEXT, u)
        }, "Share page"))
    }

    private fun clearData() {
        web()?.clearCache(true)
        web()?.clearHistory()
        CookieManager.getInstance().removeAllCookies(null)
        WebStorage.getInstance().deleteAllData()
        Toast.makeText(this, "Browsing data cleared", Toast.LENGTH_SHORT).show()
    }

    // ---------- Bookmarks ----------

    private fun bookmarks(): MutableList<Pair<String, String>> {
        val raw = prefs.getString("bookmarks", "") ?: ""
        return raw.split("\n").filter { it.contains("\t") }.map {
            val p = it.split("\t", limit = 2); p[0] to p[1]
        }.toMutableList()
    }

    private fun saveBookmarks(list: List<Pair<String, String>>) {
        prefs.edit().putString(
            "bookmarks",
            list.joinToString("\n") { "${it.first.replace("\t", " ").replace("\n", " ")}\t${it.second}" }
        ).apply()
    }

    private fun addBookmark() {
        val w = web() ?: return
        val url = w.url ?: return
        val list = bookmarks()
        if (list.any { it.second == url }) {
            Toast.makeText(this, "Already bookmarked", Toast.LENGTH_SHORT).show(); return
        }
        list.add((w.title?.takeIf { it.isNotBlank() } ?: url) to url)
        saveBookmarks(list)
        Toast.makeText(this, "Bookmark added", Toast.LENGTH_SHORT).show()
    }

    private fun showBookmarks() {
        val list = bookmarks()
        if (list.isEmpty()) {
            Toast.makeText(this, "No bookmarks yet", Toast.LENGTH_SHORT).show(); return
        }
        AlertDialog.Builder(this).setTitle("Bookmarks")
            .setItems(list.map { it.first }.toTypedArray()) { _, i -> web()?.loadUrl(list[i].second) }
            .setNeutralButton("Delete…") { _, _ -> showDeleteBookmarks() }
            .setNegativeButton("Close", null).show()
    }

    private fun showDeleteBookmarks() {
        val list = bookmarks()
        AlertDialog.Builder(this).setTitle("Delete which bookmark?")
            .setItems(list.map { it.first }.toTypedArray()) { _, i ->
                list.removeAt(i); saveBookmarks(list)
            }.setNegativeButton("Cancel", null).show()
    }

    override fun onDestroy() {
        tabs.forEach { it.destroy() }
        super.onDestroy()
    }
}
