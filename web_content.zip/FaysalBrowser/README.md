# Faysal Browser
A simple Android browser built on the system WebView.

## Build
1. Open this folder in Android Studio (Koala or newer). Let Gradle sync.
2. Run on a device/emulator, or Build > Build APK(s).
3. Release APK: Build > Generate Signed Bundle / APK.

## Features
Local start page (app/src/main/assets/index.html), address bar with search, back/forward/reload, multiple tabs, bookmarks,
downloads, desktop-site mode, share page, clear data, opens http/https links.

## Customize
App name: app/src/main/res/values/strings.xml
Package ID: app/build.gradle.kts (applicationId)
Icon: app/src/main/res/drawable/ic_launcher.xml
Colors: app/src/main/res/values/colors.xml
Home page: app/src/main/assets/index.html
