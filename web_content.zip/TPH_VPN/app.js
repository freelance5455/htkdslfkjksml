document.addEventListener('DOMContentLoaded', () => {
    const powerBtn = document.getElementById('power-btn');
    const powerRing = document.getElementById('power-ring');
    const powerIcon = document.getElementById('power-icon');
    const powerLbl = document.getElementById('power-lbl');
    const statusDot = document.getElementById('status-dot');
    const statusText = document.getElementById('status-text');
    const vipDisplay = document.getElementById('vip-display');
    const pingDisplay = document.getElementById('ping-display');
    const terminalBody = document.getElementById('terminal-body');
    const dlSpeed = document.getElementById('dl-speed');
    const ulSpeed = document.getElementById('ul-speed');
    const nodeItems = document.querySelectorAll('.node-item');

    let isConnected = false;
    let dataInterval = null;
    let activeNodePing = 12;
    let totalDl = 0.0;
    let totalUl = 0.0;

    // Log terminal message utilities
    function logTerm(msg, type = 'info') {
        const p = document.createElement('p');
        const timestamp = new Date().toISOString().slice(11, 19);
        p.className = type === 'error' ? 'text-red-400' : type === 'success' ? 'text-emerald-400' : type === 'warn' ? 'text-amber-400' : 'text-slate-400';
        p.innerHTML = `<span class="text-slate-600">[${timestamp}]</span> [${type.toUpperCase()}] ${msg}`;
        terminalBody.appendChild(p);
        terminalBody.scrollTop = terminalBody.scrollHeight;
    }

    // Node selection
    nodeItems.forEach(item => {
        item.addEventListener('click', () => {
            if (isConnected) {
                logTerm('Cannot change route parameters while active channel is open.', 'warn');
                return;
            }
            nodeItems.forEach(i => {
                i.classList.remove('bg-slate-900', 'border-slate-800/50');
                i.classList.add('bg-slate-950/40', 'border-slate-900');
                i.querySelector('p').classList.remove('text-slate-200');
                i.querySelector('p').classList.add('text-slate-400');
            });
            item.classList.remove('bg-slate-950/40', 'border-slate-900');
            item.classList.add('bg-slate-900', 'border-slate-800/50');
            item.querySelector('p').classList.add('text-slate-200');
            
            activeNodePing = parseInt(item.getAttribute('data-ping'));
            logTerm(`Switched configuration endpoint sequence to: ${item.querySelector('p').innerText}`);
        });
    });

    // Connection process mechanics
    powerBtn.addEventListener('click', () => {
        if (!isConnected) {
            // Trigger Handshake Sequence
            isConnected = true;
            logTerm('Executing secure virtual binding daemon handshake...');
            powerBtn.style.pointerEvents = 'none';
            powerLbl.innerText = 'Binding...';
            
            setTimeout(() => {
                logTerm('Diffie-Hellman Ephemeral (X25519) keys successfully exchanged.', 'success');
                logTerm('Configuring encapsulation tunnels (AES-256-GCM cipher structure)...');
                
                setTimeout(() => {
                    // Update state UI to Connected
                    powerBtn.style.pointerEvents = 'auto';
                    powerBtn.classList.add('border-emerald-500/40', 'connected-glow');
                    powerBtn.classList.remove('border-slate-800');
                    powerRing.classList.remove('border-red-500/20');
                    powerRing.classList.add('border-emerald-500/20');
                    powerIcon.classList.remove('text-red-500');
                    powerIcon.classList.add('text-emerald-400');
                    powerLbl.innerText = 'Disconnect';
                    powerLbl.classList.remove('text-slate-500');
                    powerLbl.classList.add('text-emerald-500');
                    
                    statusDot.classList.remove('bg-red-500');
                    statusDot.classList.add('bg-emerald-400');
                    statusText.innerText = 'Protected';
                    statusText.classList.remove('text-slate-400');
                    statusText.classList.add('text-emerald-400');
                    
                    const simulatedIP = `10.8.0.${Math.floor(Math.random() * 254) + 1}`;
                    vipDisplay.innerText = simulatedIP;
                    pingDisplay.innerHTML = `${activeNodePing} <span class="text-xs font-normal text-slate-500">ms</span>`;
                    pingDisplay.classList.remove('text-slate-500');
                    pingDisplay.classList.add('text-emerald-400');
                    
                    logTerm(`Secure link established successfully. Node boundary IP assigned: ${simulatedIP}`, 'success');
                    
                    // Fire up traffic data simulation loop
                    dataInterval = setInterval(() => {
                        const dlDelta = Math.random() * 2.4;
                        const ulDelta = Math.random() * 0.6;
                        totalDl += dlDelta;
                        totalUl += ulDelta;
                        dlSpeed.innerHTML = `${totalDl.toFixed(2)} <span class="text-xs font-normal text-slate-500">MB</span>`;
                        ulSpeed.innerHTML = `${totalUl.toFixed(2)} <span class="text-xs font-normal text-slate-500">MB</span>`;
                    }, 1000);

                }, 1000);
            }, 800);

        } else {
            // Teardown interface allocation
            clearInterval(dataInterval);
            isConnected = false;
            logTerm('Sending terminating payload block packet signatures to socket daemon...');
            
            powerBtn.classList.remove('border-emerald-500/40', 'connected-glow');
            powerBtn.classList.add('border-slate-800');
            powerRing.classList.remove('border-emerald-500/20');
            powerRing.classList.add('border-red-500/20');
            powerIcon.classList.remove('text-emerald-400');
            powerIcon.classList.add('text-red-500');
            powerLbl.innerText = 'Connect';
            powerLbl.classList.remove('text-emerald-500');
            powerLbl.classList.add('text-slate-500');
            
            statusDot.classList.remove('bg-emerald-400');
            statusDot.classList.add('bg-red-500');
            statusText.innerText = 'Disconnected';
            statusText.classList.remove('text-emerald-400');
            statusText.classList.add('text-slate-400');
            
            vipDisplay.innerText = '---.---.---.---';
            pingDisplay.innerHTML = `-- <span class="text-xs font-normal text-slate-600">ms</span>`;
            pingDisplay.classList.remove('text-emerald-400');
            pingDisplay.classList.add('text-slate-500');
            
            logTerm('Secure routing interface torn down. Local adapter disconnected.', 'error');
        }
    });
});
