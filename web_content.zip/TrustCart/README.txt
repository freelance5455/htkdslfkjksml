TRUSTCART - Shop Smart. Shop Safe.
==================================

WHAT'S INSIDE
  www/index.html        The whole app (one file, all photos and logo embedded)
  capacitor.config.json Settings for turning the app into an Android APK
  package.json          Tools needed for the APK build

1) JUST OPEN IT (no install)
   Double-click www/index.html. It opens in your browser.
   Tip: press F12 and choose the phone view to see it at phone size.

2) PUT IT ON A PHONE AS AN APP (no APK)
   Upload www/index.html to any web host, open the link in Chrome on Android,
   then tap  Add to Home screen.

3) BUILD A REAL ANDROID APK
   You need: Node.js (nodejs.org) and Android Studio (developer.android.com/studio)

   Open a terminal in this folder, then run:
     npm install
     npx cap add android
     npx cap sync
     npx cap open android

   In Android Studio:  Build > Build Bundle(s) / APK(s) > Build APK(s)
   The APK appears in  android/app/build/outputs/apk/debug/

   After you change www/index.html, run  npx cap sync  again and rebuild.

NOTES
   - This is a front-end prototype: login, cart and receipts are kept only
     while the app is open and reset when it closes. Saved accounts and orders
     need a backend.
   - App name: TrustCart    Package ID: com.trustcart.app (change it in
     capacitor.config.json before publishing).
