# Truck Rush: Himalayan Run — Android project

This is a native Android WebView wrapper for the Truck Rush Himalayan Run HTML game. It includes:
- immersive full-screen gameplay (hides status/navigation bars during play)
- touch steering controls inside the game
- Android launcher icon assets (vector drawable)
- portrait/landscape orientation support (landscape is recommended)
- offline game assets bundled in the APK
- Gradle project files and build instructions

## Requirements
- Android Studio (current stable version)
- Android SDK Platform 35 (or the SDK version Android Studio suggests)
- JDK 17 (bundled with Android Studio is fine)
- Internet connection for the first Gradle sync

## Build an APK
1. Extract the ZIP.
2. Open the `TruckRushAndroid` folder in Android Studio.
3. Wait for Gradle sync. If prompted, install the Android SDK Platform / Build Tools suggested by Android Studio.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. When finished, click **Locate** in the notification. The APK will be under:
   `app/build/outputs/apk/debug/app-debug.apk`
6. Transfer the APK to your Android phone and open it. If Android asks, allow installing unknown apps for the app you used to open the APK.

## Build from terminal
From the project folder:
```bash
gradle assembleDebug
```
or, if Android Studio has generated the wrapper:
```bash
./gradlew assembleDebug
```
The first command requires Gradle installed locally. The project includes Android Gradle Plugin configuration and can be opened in Android Studio without a wrapper script.

## Create a signed release APK
In Android Studio choose **Build > Generate Signed Bundle / APK > APK**, create or select a keystore, and follow the wizard. Keep the keystore and passwords private. Do not share them.

## Project structure
- `app/src/main/assets/game.html` — complete game, bundled for offline play
- `app/src/main/java/com/truckrush/himalayan/MainActivity.java` — full-screen WebView activity
- `app/src/main/AndroidManifest.xml` — app entry point and orientation settings
- `app/src/main/res/drawable/` and `mipmap-anydpi-v26/` — vector launcher icon
- `app/build.gradle` — app build configuration

## Notes
- The game is a 2D canvas game with simulated 3D-style perspective, not a full 3D engine.
- No internet permission is required; the game runs locally.
- The app is an unsigned debug build until you build it in Android Studio. This ZIP is the project source, not a compiled APK.
