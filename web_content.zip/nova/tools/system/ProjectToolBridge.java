package tools.system;

public class ProjectToolBridge {

    public static void main(String[] args) {
        if (args.length == 0) {
            System.out.println("ERROR: Falta el nombre del proyecto.");
            return;
        }

        String name = String.join(" ", args);
        String result = ProjectTool.createProject(name);

        System.out.println(result);
    }
}
