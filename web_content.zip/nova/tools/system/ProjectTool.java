package tools.system;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class ProjectTool {

    public static String createProject(String name) {
        if (name == null || name.isBlank()) {
            return "ERROR: El nombre del proyecto está vacío.";
        }

        String safeName = name.trim().replaceAll("[^a-zA-Z0-9_-]", "_");
        Path projectPath = Path.of("projects", safeName);

        try {
            Files.createDirectories(projectPath);
            Files.createDirectories(projectPath.resolve("src"));
            Files.createDirectories(projectPath.resolve("assets"));

            Files.writeString(
                projectPath.resolve("README.md"),
                "# " + safeName + "\n\nProyecto creado por N.O.V.A.\n"
            );

            if (Files.exists(projectPath.resolve("README.md"))) {
                return "Proyecto creado correctamente: " + projectPath;
            }

            return "ERROR: No se pudo verificar el proyecto.";

        } catch (IOException e) {
            return "ERROR: " + e.getMessage();
        }
    }
}
