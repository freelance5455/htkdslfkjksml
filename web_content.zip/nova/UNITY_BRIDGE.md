# Puente N.O.V.A. ↔ Unity

## Preparar un proyecto

N.O.V.A. puede crear el esqueleto de un proyecto Unity dentro de `projects/`.

El puente usa `127.0.0.1:17890`, por lo que no expone el servidor a la red local.

## Acciones iniciales

- `ping`: comprobar conexión.
- `create_scene`: crear y guardar `Assets/NovaGeneratedScene.unity`.
- `create_primitive`: crear Cube, Sphere, Capsule, Cylinder, Plane, etc., y colocarlo en una posición.

El editor Unity debe estar abierto para que el script editor reciba comandos.

Esta primera capa es un puente de automatización. Sobre ella se puede construir generación de escenas, prefabs, scripts, materiales, cámaras, iluminación y pruebas de proyectos 2D/3D.

## Acciones ampliadas
`ping`, `create_scene`, `create_primitive` y preparación de proyectos Unity desde N.O.V.A.
