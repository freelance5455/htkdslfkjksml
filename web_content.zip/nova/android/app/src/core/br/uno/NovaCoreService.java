package core.br.uno;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.res.AssetManager;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Arranca el "cerebro" real de N.O.V.A. (core/ + bridge/nova_bridge_server.py)
 * DENTRO del proceso de la app, usando Chaquopy como intérprete de Python
 * embebido. Esto reemplaza la dependencia de tener Termux corriendo
 * `./start_nova.sh` por separado: mientras este servicio esté vivo,
 * http://127.0.0.1:8787/ responde con el núcleo cognitivo completo
 * (memoria, autonomía, objetivos, conectores, seguridad...), tal cual lo
 * expone bridge/nova_bridge_server.py.
 *
 * Rutas de datos protegidas (core/memory, core/state, config, logs): si ya
 * existen en el almacenamiento interno de la app, NUNCA se pisan al volver
 * a extraer el paquete de código — así una actualización de la app no borra
 * la memoria/autobiografía ya acumulada por N.O.V.A.
 */
public class NovaCoreService extends Service {

    public static final String CHANNEL_ID = "nova_core";
    public static final String ACTION_BOOT_ERROR = "core.br.uno.NOVA_BOOT_ERROR";
    public static final String EXTRA_ERROR = "error";
    private static final String TAG = "NovaCoreService";
    private static final String ASSET_ZIP = "nova_src.zip";

    private static final String[] PROTECTED_PREFIXES = {
            "core/memory/", "core/state/", "config/", "logs/"
    };

    private Thread coreThread;
    private volatile boolean started = false;

    @Override
    public void onCreate() {
        super.onCreate();
        startForeground(1, buildNotification("Iniciando el núcleo…"));
        launchCore();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // Sticky: si el sistema mata el proceso por memoria, intenta revivirlo.
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private synchronized void launchCore() {
        if (started) return;
        started = true;
        coreThread = new Thread(this::runCore, "nova-core");
        coreThread.setDaemon(true);
        coreThread.start();
    }

    private File novaRoot() {
        return new File(getFilesDir(), "nova");
    }

    private void runCore() {
        try {
            File root = novaRoot();
            extractAssetsIfNeeded(root);

            if (!Python.isStarted()) {
                Python.start(new AndroidPlatform(getApplicationContext()));
            }
            Python py = Python.getInstance();

            // Hace que el paquete extraído (nova/core, nova/bridge, nova/ui)
            // sea importable, igual que "PYTHONPATH=." en Termux.
            PyObject sys = py.getModule("sys");
            sys.get("path").callAttr("insert", 0, root.getAbsolutePath());

            updateNotification("Núcleo activo en 127.0.0.1:8787");

            // bridge/nova_bridge_server.py ya calcula su propio ROOT a partir
            // de __file__, hace os.chdir(ROOT) y sirve ui/index.html — exactamente
            // el mismo comportamiento que "PYTHONPATH=. python bridge/nova_bridge_server.py".
            PyObject bridgeModule = py.getModule("bridge.nova_bridge_server");
            bridgeModule.callAttr("main"); // bloquea en serve_forever(): correcto, este hilo es exclusivo para esto.
        } catch (Throwable t) {
            Log.e(TAG, "No se pudo iniciar el núcleo de N.O.V.A.", t);
            String detail = describe(t);
            writeBootError(detail);
            updateNotification("N.O.V.A.: error al iniciar núcleo");
            Intent broadcast = new Intent(ACTION_BOOT_ERROR);
            broadcast.putExtra(EXTRA_ERROR, detail);
            sendBroadcast(broadcast);
        }
    }

    private String describe(Throwable t) {
        StringWriter sw = new StringWriter();
        t.printStackTrace(new PrintWriter(sw));
        return sw.toString();
    }

    private void writeBootError(String detail) {
        try {
            File f = new File(novaRoot(), "BOOT_ERROR.txt");
            try (FileOutputStream fos = new FileOutputStream(f)) {
                fos.write(detail.getBytes("UTF-8"));
            }
        } catch (IOException ignored) {
        }
    }

    private boolean isProtected(String entryName) {
        for (String prefix : PROTECTED_PREFIXES) {
            if (entryName.startsWith(prefix)) return true;
        }
        return false;
    }

    private void extractAssetsIfNeeded(File root) throws IOException {
        root.mkdirs();
        AssetManager am = getAssets();
        byte[] buffer = new byte[8192];
        try (InputStream rawIn = am.open(ASSET_ZIP);
             ZipInputStream zis = new ZipInputStream(new BufferedInputStream(rawIn))) {
            ZipEntry entry;
            while ((entry = zis.getNextEntry()) != null) {
                String name = entry.getName();
                File outFile = new File(root, name);

                if (entry.isDirectory()) {
                    outFile.mkdirs();
                    continue;
                }

                // No pisar memoria/estado/config/logs ya generados por el propio
                // núcleo en ejecuciones anteriores (persisten entre actualizaciones
                // de la app).
                if (isProtected(name) && outFile.exists()) {
                    continue;
                }

                File parent = outFile.getParentFile();
                if (parent != null) parent.mkdirs();

                try (FileOutputStream fos = new FileOutputStream(outFile)) {
                    int len;
                    while ((len = zis.read(buffer)) > 0) {
                        fos.write(buffer, 0, len);
                    }
                }
            }
        }
    }

    private Notification buildNotification(String text) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "N.O.V.A. núcleo", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Mantiene activo el cerebro de N.O.V.A. en segundo plano.");
            if (nm != null) nm.createNotificationChannel(channel);
        }
        Notification.Builder builder = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        builder.setContentTitle("N.O.V.A.")
                .setContentText(text)
                .setOngoing(true)
                .setSmallIcon(android.R.drawable.ic_menu_info_details);
        return builder.build();
    }

    private void updateNotification(String text) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(1, buildNotification(text));
    }
}
