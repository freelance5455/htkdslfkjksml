package core.br.uno;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Locale;

/**
 * N.O.V.A. ya no es una interfaz de chat aparte: esta actividad muestra
 * DIRECTAMENTE el HUD completo (ui/index.html) — Cognición, Memoria,
 * Autonomía, Seguridad, Conectores, todo — servido por el núcleo Python
 * embebido que arranca NovaCoreService. Antes esta pantalla era un chat
 * plano que ni siquiera cargaba esa interfaz.
 */
public class MainActivity extends Activity implements TextToSpeech.OnInitListener {

    private static final String PREFS = "nova_settings";
    private static final String DEFAULT_URL = "http://127.0.0.1:8787/";
    private static final int RECORD_AUDIO_REQUEST = 7001;
    private static final int NOTIF_PERMISSION_REQUEST = 7002;
    private static final int MAX_RETRIES = 45;   // ~45 * 700ms ≈ 30s de margen para que el núcleo arranque
    private static final long RETRY_DELAY_MS = 700;

    private WebView webView;
    private FrameLayout loadingOverlay;
    private TextView loadingText;
    private SharedPreferences prefs;
    private String targetUrl;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private int retryCount = 0;
    private boolean pageLoadedOnce = false;

    private SpeechRecognizer speechRecognizer;
    private Intent speechIntent;
    private TextToSpeech tts;
    private boolean listening = false;

    private final BroadcastReceiver bootErrorReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String detail = intent.getStringExtra(NovaCoreService.EXTRA_ERROR);
            showLoading("El núcleo de N.O.V.A. no pudo iniciar.\n" +
                    (detail != null ? firstLine(detail) : "Error desconocido") +
                    "\n\nToca para reintentar.");
            loadingOverlay.setOnClickListener(v -> {
                retryCount = 0;
                attemptLoad();
            });
        }
    };

    private String firstLine(String s) {
        int idx = s.indexOf('\n');
        return idx > 0 ? s.substring(0, Math.min(idx, 220)) : s.substring(0, Math.min(s.length(), 220));
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(5, 10, 16));
        getWindow().setNavigationBarColor(Color.BLACK);

        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        targetUrl = prefs.getString("bridge_url", DEFAULT_URL);

        requestRuntimePermissions();

        // El núcleo corre como servicio en primer plano: sigue vivo (autonomía
        // incluida) aunque la app pase a segundo plano.
        Intent serviceIntent = new Intent(this, NovaCoreService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent);
        } else {
            startService(serviceIntent);
        }

        tts = new TextToSpeech(this, this);
        setupVoiceRecognizer();

        buildLayout();
        showLoading("Iniciando el núcleo de N.O.V.A.…");
        attemptLoad();
    }

    private void requestRuntimePermissions() {
        ArrayList<String> toRequest = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            toRequest.add(Manifest.permission.RECORD_AUDIO);
        }
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            toRequest.add("android.permission.POST_NOTIFICATIONS");
        }
        if (!toRequest.isEmpty()) {
            requestPermissions(toRequest.toArray(new String[0]), RECORD_AUDIO_REQUEST);
        }
    }

    private void buildLayout() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        webView = new WebView(this);
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        ws.setLoadWithOverviewMode(true);
        ws.setUseWideViewPort(true);
        ws.setMediaPlaybackRequiresUserGesture(false);
        webView.addJavascriptInterface(new NovaVoiceBridge(), "Android");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                pageLoadedOnce = true;
                hideLoading();
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame() && !pageLoadedOnce) {
                    scheduleRetry();
                }
            }
        });
        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        loadingOverlay = new FrameLayout(this);
        loadingOverlay.setBackgroundColor(Color.rgb(4, 8, 13));
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        ProgressBar spinner = new ProgressBar(this);
        loadingText = new TextView(this);
        loadingText.setTextColor(Color.rgb(0xdf, 0xf6, 0xff));
        loadingText.setTextSize(15);
        loadingText.setGravity(Gravity.CENTER);
        loadingText.setPadding(dp(24), dp(18), dp(24), 0);
        box.addView(spinner);
        box.addView(loadingText);
        loadingOverlay.addView(box, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER));
        root.addView(loadingOverlay, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        setContentView(root);
    }

    private void showLoading(String text) {
        loadingText.setText(text);
        loadingOverlay.setVisibility(View.VISIBLE);
    }

    private void hideLoading() {
        loadingOverlay.setVisibility(View.GONE);
        loadingOverlay.setOnClickListener(null);
    }

    private void attemptLoad() {
        webView.loadUrl(targetUrl);
    }

    private void scheduleRetry() {
        if (pageLoadedOnce) return;
        retryCount++;
        if (retryCount > MAX_RETRIES) {
            showLoading("N.O.V.A. no responde en " + targetUrl +
                    "\n\nToca para reintentar, o revisa ⚙ para apuntar a otro bridge.");
            loadingOverlay.setOnClickListener(v -> {
                retryCount = 0;
                attemptLoad();
            });
            return;
        }
        showLoading("Iniciando el núcleo de N.O.V.A.…\n(" + retryCount + "/" + MAX_RETRIES + ")");
        mainHandler.postDelayed(this::attemptLoad, RETRY_DELAY_MS);
    }

    private void showSettings() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), dp(4));
        EditText url = new EditText(this);
        url.setText(targetUrl);
        url.setHint("URL del bridge (por defecto: núcleo local)");
        box.addView(url);
        TextView hint = new TextView(this);
        hint.setText("Déjalo en " + DEFAULT_URL + " para usar el cerebro embebido en esta app. Solo cámbialo si quieres apuntar a un bridge externo (por ejemplo, corriendo en Termux en otro dispositivo).");
        hint.setTextSize(11);
        hint.setPadding(0, dp(10), 0, 0);
        box.addView(hint);
        new AlertDialog.Builder(this).setTitle("N.O.V.A. · Bridge")
                .setView(box)
                .setPositiveButton("Guardar y recargar", (d, w) -> {
                    String value = url.getText().toString().trim();
                    if (value.isEmpty()) value = DEFAULT_URL;
                    if (!value.endsWith("/")) value = value + "/";
                    targetUrl = value;
                    prefs.edit().putString("bridge_url", targetUrl).apply();
                    retryCount = 0;
                    pageLoadedOnce = false;
                    showLoading("Cargando " + targetUrl + "…");
                    attemptLoad();
                })
                .setNeutralButton("Restablecer al núcleo local", (d, w) -> {
                    targetUrl = DEFAULT_URL;
                    prefs.edit().putString("bridge_url", DEFAULT_URL).apply();
                    retryCount = 0;
                    pageLoadedOnce = false;
                    showLoading("Cargando " + targetUrl + "…");
                    attemptLoad();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    @Override
    public boolean onKeyDown(int keyCode, android.view.KeyEvent event) {
        if (keyCode == android.view.KeyEvent.KEYCODE_MENU) {
            showSettings();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    // -----------------------------------------------------------------
    // Puente de voz nativo: expone SpeechRecognizer/TTS a ui/index.html
    // vía window.Android.*, para que el botón de micrófono del HUD
    // (antes solo mostraba un toast) funcione de verdad.
    // -----------------------------------------------------------------
    private class NovaVoiceBridge {
        @JavascriptInterface
        public boolean isAvailable() {
            return SpeechRecognizer.isRecognitionAvailable(MainActivity.this);
        }

        @JavascriptInterface
        public void startListening() {
            mainHandler.post(() -> {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, RECORD_AUDIO_REQUEST);
                    return;
                }
                if (speechRecognizer != null && !listening) {
                    listening = true;
                    speechRecognizer.startListening(speechIntent);
                }
            });
        }

        @JavascriptInterface
        public void stopListening() {
            mainHandler.post(() -> {
                listening = false;
                if (speechRecognizer != null) speechRecognizer.stopListening();
            });
        }

        @JavascriptInterface
        public void speak(String text) {
            mainHandler.post(() -> {
                if (tts != null && text != null && !text.isEmpty()) {
                    tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nova-response");
                }
            });
        }
    }

    private void emitVoiceEvent(String jsFunction, String jsonArg) {
        if (webView == null) return;
        String script = "window." + jsFunction + " && window." + jsFunction + "(" + jsonArg + ");";
        mainHandler.post(() -> webView.evaluateJavascript(script, null));
    }

    private void setupVoiceRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return;
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) {
                emitVoiceEvent("onNovaVoiceState", "\"listening\"");
            }
            @Override public void onBeginningOfSpeech() {}
            @Override public void onRmsChanged(float rmsdB) {}
            @Override public void onBufferReceived(byte[] buffer) {}
            @Override public void onEndOfSpeech() {
                emitVoiceEvent("onNovaVoiceState", "\"processing\"");
            }
            @Override public void onError(int error) {
                listening = false;
                emitVoiceEvent("onNovaVoiceState", "\"idle\"");
            }
            @Override public void onResults(Bundle results) {
                listening = false;
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null && !matches.isEmpty()) {
                    emitVoiceEvent("onNovaVoiceResult", org.json.JSONObject.quote(matches.get(0)));
                }
                emitVoiceEvent("onNovaVoiceState", "\"idle\"");
            }
            @Override public void onPartialResults(Bundle partialResults) {}
            @Override public void onEvent(int eventType, Bundle params) {}
        });
        speechIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-MX");
        speechIntent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
        speechIntent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS && tts != null) {
            tts.setLanguage(new Locale("es", "MX"));
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        IntentFilter filter = new IntentFilter(NovaCoreService.ACTION_BOOT_ERROR);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(bootErrorReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(bootErrorReceiver, filter);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        try {
            unregisterReceiver(bootErrorReceiver);
        } catch (IllegalArgumentException ignored) {
        }
    }

    @Override
    protected void onDestroy() {
        if (speechRecognizer != null) speechRecognizer.destroy();
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        // El servicio del núcleo se queda vivo a propósito: N.O.V.A. sigue
        // corriendo (autonomía incluida) aunque se cierre la pantalla.
        super.onDestroy();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        // No se requiere acción especial: la interfaz web vuelve a intentar
        // el micrófono la próxima vez que el usuario lo toque.
    }
}
