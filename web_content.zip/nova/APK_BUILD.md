# N.O.V.A. 4.1 — APK

## Estado

El proyecto Android está preparado (`android/`), pero este teléfono es Linux ARMv7/32-bit.
La cadena moderna de Android Gradle Plugin/AAPT2 requiere un entorno Linux 64-bit para compilar la APK.

## Compilación recomendada

Usar una PC/VM/CI Linux x86_64 o ARM64 con:

- JDK compatible con el proyecto
- Android SDK
- Build-tools
- Gradle/Gradle Wrapper

Desde `nova/android`:

```bash
./gradlew assembleDebug
```

La APK queda normalmente en:

```text
android/app/build/outputs/apk/debug/app-debug.apk
```

## Prueba local del núcleo

En Termux:

```bash
cd ~/storage/downloads/"N.O.V.A (2)"
PYTHONPATH=. python scripts/start_android_bridge.py
```

La app Android usa:

```text
http://127.0.0.1:8765/command
```

y ahora el bridge utiliza una instancia persistente de `CognitiveRuntime`.

## Importante

No se debe presentar una APK vieja/reempaquetada como una compilación nueva del código actual.
