# N.O.V.A. 4.1

Cambios finales:
- Panel Unity integrado a la interfaz.
- Unity usa el conector real y no simula conexión.
- Acciones UI: ping, crear proyecto y crear Cube.
- Bridge Android corregido para usar un CognitiveRuntime persistente real.
- Guía de compilación APK incluida.
- Se conserva la arquitectura cognitiva, seguridad, SelfRepair y conectores existentes.
