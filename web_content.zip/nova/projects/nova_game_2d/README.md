# N.O.V.A. — Black Hole Survivor

Juego 2D generado por N.O.V.A.

Controles: WASD o flechas. Evita asteroides y consigue puntos.
