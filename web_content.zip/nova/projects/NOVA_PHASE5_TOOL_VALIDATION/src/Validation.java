public class Validation { public static int sum(int a, int b) { return a + b; } }
