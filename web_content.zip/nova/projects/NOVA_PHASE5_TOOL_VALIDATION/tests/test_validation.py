assert 2 + 3 == 5
print('PYTHON_TEST_OK')
