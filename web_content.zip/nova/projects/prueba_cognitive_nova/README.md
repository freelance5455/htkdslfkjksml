# prueba_cognitive_nova

Proyecto creado por N.O.V.A.
