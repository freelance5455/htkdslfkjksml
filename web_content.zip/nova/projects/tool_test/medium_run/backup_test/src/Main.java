public class Main { public static void main(String[] args) { System.out.println("N.O.V.A. COMPILE TEST OK"); } }
