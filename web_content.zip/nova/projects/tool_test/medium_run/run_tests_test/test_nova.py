assert 2 + 2 == 4
print("N.O.V.A. TEST OK")
