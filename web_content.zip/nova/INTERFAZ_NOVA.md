# Interfaz N.O.V.A. — puente real

Esta interfaz **no es una maqueta**. `bridge/nova_bridge_server.py` importa
directamente las clases reales de `core/` (el mismo `CognitiveRuntime` que
usa `core/brain/nova.py`) y las expone como endpoints JSON. `ui/index.html`
consume esos endpoints y muestra lo que el núcleo reporta de verdad —
incluidos sus errores reales (por ejemplo, el conector de Unity muestra
`ConnectionRefusedError` cuando no hay editor de Unity escuchando en
`127.0.0.1:17890`, tal cual lo devuelve `UnityBridge`).

## Cómo ejecutarla

Desde la raíz del proyecto (Termux, Linux o cualquier entorno con Python 3):

```bash
PYTHONPATH=. python bridge/nova_bridge_server.py 8787
```

Luego abre `http://127.0.0.1:8787/` en el navegador (en el mismo
dispositivo, o en el navegador del teléfono si corres el bridge en el PC de
la misma red y usas la IP en vez de 127.0.0.1). El propio servidor sirve la
interfaz, así que no hay problemas de CORS ni pasos extra.

No requiere `pip install`: usa solo la librería estándar de Python
(`http.server`), igual que el bridge de Android que ya existía en el
proyecto (`core/android/bridge_server.py`).

## Qué está realmente conectado

| Panel de la interfaz        | Fuente real                                                              |
|------------------------------|---------------------------------------------------------------------------|
| Núcleo cognitivo              | `core/cognition/cognitive_cycle.py`, `cognitive_state.py`                |
| Modelo de sí mismo / meta     | `core/cognition/self_model.py`, `core/self/metacognition.py`             |
| Memoria                       | `core/memory/learning_memory.py` (`core/memory/knowledge.json`)          |
| Memoria autobiográfica        | `core/cognition/autobiographical_memory.py` (`autobiography.json`)       |
| Objetivos / planificación     | `core/goals/goal_manager.py`, `core/planner/planner.py`                  |
| Autonomía                     | `core/autonomy/autonomous_loop.py`, `initiative.py`                      |
| Herramientas                  | `core/runtime/tool_catalog.py` (56 herramientas reales registradas)      |
| Conectores (Unity/Unity Cloud)| `core/connectors/*`, `core/engines/unity_bridge.py`                      |
| SelfRepair                    | `core/self_repair/self_repair.py` (diagnóstico real vía `py_compile`)    |
| Self-Improvement              | `core/self_improvement/improvement_lab.py`                               |
| Seguridad                     | `core/security/*` (permisos, política, auditoría en `logs/security_audit.jsonl`) |
| Voz                           | `core/voice/voice_pipeline.py` (reporta si STT/TTS están disponibles)    |
| Chat                          | `CognitiveRuntime.process()` — el mismo motor que usa la CLI             |

El núcleo visual central (IDLE / LISTENING / THINKING / PLANNING /
EXECUTING / VERIFYING / LEARNING / REFLECTING / ERROR) se calcula en
`derive_core_state()` a partir de señales reales (`status`, `mode` del
ciclo cognitivo, estado de voz, tipo del último resultado). Cuando no hay
una señal real para un estado concreto, la interfaz cae a IDLE en vez de
inventarlo.

## Subsistemas que el propio README de N.O.V.A. ya marca como pendientes de
validación física o de servicios externos (Android nativo, voz con
micrófono real, Unity Editor, compilación de APK, Unity Cloud, internet)
se muestran en la interfaz con su estado real reportado — "no conectado",
"no disponible en este entorno", etc. — en vez de simularse como activos.

## Pruebas realizadas en este entorno

- Arranque del servidor y `GET /api/health`, `/api/snapshot`, `/api/tools`.
- `POST /api/command` contra el runtime cognitivo real (respuesta y
  ejecución verificadas).
- Creación de objetivo real vía `POST /api/goals/create`.
- Diagnóstico real de un subpaquete con `POST /api/self_repair/diagnose`.
- Autorización de una acción bloqueada (`delete_files`) verificando que la
  política de seguridad la deniega correctamente.
- Propuesta de experimento en el laboratorio de automejora.
- Manejo de errores: JSON inválido → 400, ruta inexistente → 404, cuerpo
  vacío en `/api/command` → 400.
- Servido de la interfaz (`GET /`) desde el propio bridge.

Los datos de prueba generados durante esta validación (un objetivo llamado
"Probar dashboard" y un experimento "Test UI") fueron eliminados antes de
entregar este paquete, para no ensuciar tu memoria/objetivos reales.

## Qué falta y por qué

- **Unity / Android nativo / voz con micrófono real / build de APK**: estos
  subsistemas dependen de un editor de Unity abierto, hardware físico o
  toolchain de compilación — exactamente lo que el propio
  `RELEASE_STATUS.json` ya documentaba. La interfaz refleja su estado real
  (no conectado) en vez de fingir que funcionan.
- **Eventos en tiempo real por WebSocket**: el bridge usa *polling* HTTP
  cada ~1.5–15 s (con backoff si se pierde la conexión) en vez de
  WebSockets, para mantener cero dependencias externas y máxima
  compatibilidad con Termux/Android. Si quieres WebSockets reales, es un
  cambio localizado en `bridge/nova_bridge_server.py`.
