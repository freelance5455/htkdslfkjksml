from core.android.bridge_server import AndroidBridgeServer
from core.runtime.cognitive_runtime import CognitiveRuntime


def main():
    runtime = CognitiveRuntime()

    def handle(payload):
        action = payload.get("action")
        if action == "command":
            text = str(payload.get("text", "")).strip()
            if not text:
                return {"success": False, "error": "Falta el comando."}
            return runtime.process(text)

        if action in {"start_listening", "stop_listening", "speak", "set_state"}:
            return {"success": True, "action": action, "payload": payload}

        return {"success": False, "error": "Acción Android desconocida."}

    server = AndroidBridgeServer(command_handler=handle)
    print(
        "N.O.V.A. Android bridge activo en "
        f"http://{server.address[0]}:{server.address[1]}/command"
    )
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.shutdown()


if __name__ == "__main__":
    main()
