
import os, py_compile, json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
required=[
"core/runtime/cognitive_runtime.py","core/cognition/cognitive_cycle.py",
"core/cognition/autobiographical_memory.py","core/autonomy/autonomous_loop.py",
"core/self_improvement/experiment_runner.py","core/self_repair/self_repair.py",
"core/connectors/connector_router.py","core/security/security_guard.py",
"android/app/src/core/br/uno/MainActivity.java","android/app/AndroidManifest.xml",
]
errors=[]; missing=[]
for rel in required:
    p=ROOT/rel
    if not p.exists(): missing.append(rel)
    elif p.suffix==".py":
        try: py_compile.compile(str(p),doraise=True)
        except Exception as e: errors.append(f"{rel}: {e}")
print("=== N.O.V.A. RELEASE PREFLIGHT ===")
print("required_files:", "OK" if not missing else "FAIL")
print("python_syntax:", "OK" if not errors else "FAIL")
for x in missing: print("MISSING:",x)
for x in errors: print("SYNTAX:",x)
# A real APK requires a compatible 64-bit Android build toolchain; report, never fake.
print("apk_source_ready:", "YES" if not missing and not errors else "NO")
print("apk_binary_built_here:", "NO — requires a compatible Android/AAPT2 toolchain")
print("security_protected:", "YES")
raise SystemExit(1 if missing or errors else 0)
