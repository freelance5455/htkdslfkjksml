# N.O.V.A.

Asistente personal en desarrollo.

## Estado de esta versión

- 50 herramientas registradas y ejecutables.
- Runtime conversacional conectado al núcleo: preguntas comunes pueden recibir respuestas locales.
- Creación de juegos 2D funcionales mediante HTML5 Canvas.
- Preparación y puente loopback con Unity Editor para proyectos 3D.
- Autoinvestigación del propio proyecto mediante inspección, análisis y lectura de archivos.
- Recuperación desde backups y verificación de reparaciones.
- Android, voz, Internet, workers y cloud permanecen como subsistemas que requieren validación física o servicios externos cuando corresponda.

## Probar N.O.V.A.

Desde la raíz del proyecto:

```bash
PYTHONPATH=. python core/brain/nova.py
```

Ejemplos:

```text
¿Qué es la materia?
Hazme un juego 2D
salir
```

El juego 2D se crea dentro de `projects/`.

## Unity

El puente de Unity utiliza TCP loopback en `127.0.0.1:17890`.

N.O.V.A. puede preparar un proyecto con:

```python
from core.engines.unity_bridge import UnityBridge
UnityBridge().create_unity_project("nova_unity_3d")
```

Después se abre esa carpeta con Unity Editor. El script `Assets/NovaBridge/NovaBridgeServer.cs` inicia el puente en el editor y permite, entre otros, `ping`, crear una escena y crear primitivas 3D.

El puente no incluye Unity Editor dentro de N.O.V.A.; Unity debe estar instalado en el equipo donde se abra el proyecto.

## Validación

La suite actual contiene 17 archivos de pruebas. En la validación de esta versión, los 17 finalizaron correctamente en procesos Python limpios.

La compilación real de scripts C# de Unity y la ejecución física del editor deben comprobarse en una instalación de Unity.


## Nuevas capacidades de esta versión

- Construcción de una APK nueva de N.O.V.A. mediante `build_nova_apk`.
- Modo de auto-construcción: la orden "crea un APK de ti mismo" se interpreta como `BUILD_NOVA_APK`.
- Control Unity ampliado: conexión, creación de escena y primitivas 3D.
- Generación de recursos 2D SVG.
- Generación de modelos 3D OBJ básicos.
- Las herramientas de compilación no reutilizan una APK vieja como si fuera una compilación nueva.
- El constructor de APK intenta usar Gradle y reporta de forma explícita si el entorno Android no tiene las herramientas compatibles.

### Ruta recomendada en Termux

Usa `~/NOVA` como raíz de esta versión. Desde ahí:

```bash
cd ~/NOVA
PYTHONPATH=. python core/brain/nova.py
```

Dentro de N.O.V.A. puedes probar:

```text
crea un juego 3d
conecta Unity
crea una escena en Unity
crea un cubo en Unity
crea un APK de ti mismo
```


## N.O.V.A. 2.0 — Núcleo cognitivo

Esta versión añade un ciclo cognitivo modular:
- estado cognitivo persistente y resumido
- memoria de trabajo
- atención/saliencia
- modelo de sí mismo
- modelo del mundo
- razonamiento estructurado con incertidumbre
- reflexión/metacognición
- integración con memoria, objetivos y ejecución

También incluye:
- `SelfRepair 2.0` con diagnóstico, backup, verificación y rollback controlado
- arquitectura universal de conectores
- Unity local + adaptador Unity Cloud
- misión autónoma explícita
- generación de base 3D para proyectos Unity
- registro de capacidades y enrutamiento por capacidad

El sistema no afirma tener conciencia humana real; estas piezas implementan funciones cognitivas observables y medibles dentro del software.


## N.O.V.A. 4.0 Cognitiva Autónoma
- Memoria autobiográfica persistente y aprendizaje de resultados.
- SelfModel persistente y metacognición.
- Ciclo autónomo controlado con objetivos e iniciativa.
- Laboratorio de experimentos de automejora con verificación y protección de seguridad.
- Puente Android con runtime cognitivo persistente durante la sesión.
- Release preflight: `PYTHONPATH=. python scripts/release_preflight.py`.

## N.O.V.A. 4.2 — HUD / Bridge hardening

Esta revisión conserva el HUD visual tipo J.A.R.V.I.S. y añade:

- bridge local por defecto en `127.0.0.1:8787` (sin exposición LAN accidental)
- token persistente en `config/bridge_token` y cabecera `X-NOVA-Token` para endpoints de acción
- estado de conexión `ONLINE/OFFLINE` sin el texto de "reconectando"
- historial visual de estados del núcleo y métricas persistentes de CPU/RAM/disco
- clima usando ubicación del dispositivo mediante `termux-location` cuando está disponible y Open-Meteo para el tiempo
- captura de cámara mediante `termux-camera-photo` cuando Termux:API está instalado
- SelfRepair con aplicación de fix textual segura (backup + verificación + rollback automático)
- endpoint explícito de rollback
- panel avanzado agrupado por Cognición / Memoria / Autonomía / Seguridad / Conectores
- typing indicator durante comandos

### Arranque recomendado

```bash
cd ~/NOVA
./start_nova.sh
```

Abre `http://127.0.0.1:8787/` en el mismo dispositivo.
