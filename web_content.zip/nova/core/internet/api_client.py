from core.internet.internet_client import InternetClient


class ApiClient:
    """Capa de APIs externas con HTTP reutilizable."""

    def __init__(self, client=None):
        self.client = client or InternetClient()

    def request(self, url, method="GET", data=None, headers=None):
        return self.client.request(url, method=method, data=data, headers=headers)
