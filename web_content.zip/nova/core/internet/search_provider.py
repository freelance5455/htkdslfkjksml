import html
import re
import urllib.parse
import urllib.request


class WebSearchProvider:
    """Búsqueda web sin credenciales mediante un proveedor HTTP intercambiable."""

    def __init__(self, opener=None, timeout=15):
        self.opener = opener or urllib.request.urlopen
        self.timeout = int(timeout)

    def search(self, query, limit=5):
        if not isinstance(query, str) or not query.strip():
            return {"success": False, "error": "Falta la consulta."}
        limit = max(1, min(int(limit), 10))
        url = "https://html.duckduckgo.com/html/?" + urllib.parse.urlencode(
            {"q": query.strip()}
        )
        request = urllib.request.Request(
            url,
            headers={"User-Agent": "NOVA/1.0"},
        )
        try:
            with self.opener(request, timeout=self.timeout) as response:
                page = response.read(300_000).decode("utf-8", errors="replace")
            pattern = re.compile(
                r'<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>(.*?)</a>',
                re.I | re.S,
            )
            results = []
            for href, title in pattern.findall(page):
                clean_title = html.unescape(re.sub("<.*?>", "", title)).strip()
                href = html.unescape(href)
                if clean_title and href:
                    results.append({"title": clean_title, "url": href})
                    if len(results) >= limit:
                        break
            return {
                "success": True,
                "query": query.strip(),
                "results": results,
                "count": len(results),
            }
        except Exception as exc:
            return {
                "success": False,
                "query": query.strip(),
                "results": [],
                "error": f"{type(exc).__name__}: {exc}",
            }
