import json
import urllib.request
import urllib.error


class InternetClient:
    """Cliente HTTP pequeño, seguro y reutilizable para N.O.V.A."""

    def __init__(self, opener=None, timeout=20, max_bytes=200_000):
        self.opener = opener or urllib.request.urlopen
        self.timeout = max(1, int(timeout))
        self.max_bytes = max(1024, int(max_bytes))

    def request(self, url, method="GET", data=None, headers=None):
        if not isinstance(url, str) or not url.startswith(("http://", "https://")):
            return {"success": False, "error": "URL no válida."}

        body = None
        request_headers = dict(headers or {})
        if data is not None:
            body = json.dumps(data, ensure_ascii=False).encode("utf-8")
            request_headers.setdefault("Content-Type", "application/json")

        request = urllib.request.Request(
            url,
            data=body,
            headers={"User-Agent": "NOVA/1.0", **request_headers},
            method=str(method).upper(),
        )
        try:
            response = self.opener(request, timeout=self.timeout)
            raw = response.read(self.max_bytes + 1)
            if len(raw) > self.max_bytes:
                return {
                    "success": False,
                    "url": url,
                    "error": "La respuesta excede el límite de bytes permitido.",
                    "max_bytes": self.max_bytes,
                }
            text = raw.decode("utf-8", errors="replace")
            try:
                parsed = json.loads(text)
            except (json.JSONDecodeError, TypeError):
                parsed = text
            return {
                "success": True,
                "status": getattr(response, "status", None),
                "url": url,
                "data": parsed,
            }
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            return {"success": False, "error": f"{type(exc).__name__}: {exc}"}
        except Exception as exc:
            return {"success": False, "error": f"{type(exc).__name__}: {exc}"}
