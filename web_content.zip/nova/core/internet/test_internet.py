from io import BytesIO
from core.internet.internet_client import InternetClient
from core.internet.api_client import ApiClient


class FakeResponse:
    status = 200
    def __init__(self, payload):
        self.payload = payload
    def read(self, limit):
        return self.payload


def fake_opener(request, timeout=20):
    return FakeResponse(b'{"ok": true}')


def test_http_client():
    result = InternetClient(opener=fake_opener).request("https://example.test")
    assert result["success"] is True
    assert result["data"]["ok"] is True


def test_api_client():
    result = ApiClient(InternetClient(opener=fake_opener)).request(
        "https://example.test/api",
        method="POST",
        data={"x": 1},
    )
    assert result["success"] is True
    assert result["status"] == 200


if __name__ == "__main__":
    test_http_client()
    test_api_client()
    print("Internet tests passed.")
