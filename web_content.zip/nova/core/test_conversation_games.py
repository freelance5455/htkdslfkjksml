from pathlib import Path
import json

from core.conversation.conversation_engine import ConversationEngine
from core.game.game_builder import GameBuilder
from core.engines.unity_bridge import UnityBridge
from core.interpreter.intent_interpreter import IntentInterpreter
from core.interpreter.intent_executor import IntentExecutor
from core.runtime.tool_catalog import build_tool_registry


def test_conversation_materia():
    result = ConversationEngine().answer("¿Qué es la materia?")
    assert result["success"] is True
    assert result["answered"] is True
    assert "masa" in result["answer"].lower()


def test_game_2d():
    result = GameBuilder().build_2d("test_nova_game_2d")
    assert result["success"] is True
    assert result["playable"] is True
    assert Path(result["entry"]).is_file()
    content = Path(result["entry"]).read_text(encoding="utf-8")
    assert "<canvas" in content
    assert "GAME OVER" in content


def test_interpreter_game_and_conversation():
    interpreter = IntentInterpreter()
    assert interpreter.interpret("Hazme un juego 2D")["intent"] == "CREATE_GAME"
    assert interpreter.interpret("¿Qué es la materia?")["intent"] == "CONVERSATION"


def test_executor_game():
    result = IntentExecutor().execute({
        "intent": "CREATE_GAME",
        "parameters": {"dimension": "2d", "project": "test_executor_game"},
    })
    assert result["success"] is True
    assert result["result"]["playable"] is True


def test_unity_project_bridge_scaffold():
    result = UnityBridge().create_unity_project("test_nova_unity")
    assert result["success"] is True
    bridge = Path(result["bridge"])
    assert bridge.is_file()
    text = bridge.read_text(encoding="utf-8")
    assert "NovaBridgeServer" in text
    assert "17890" in text
    assert "create_scene" in text
    assert "create_primitive" in text


def test_runtime_responses():
    from core.runtime.cognitive_runtime import CognitiveRuntime
    runtime = CognitiveRuntime()
    answer = runtime.process("¿Qué es la materia?")
    assert "masa" in answer["response"].lower()
    game = runtime.process("Hazme un juego 2D")
    assert "juego" in game["response"].lower()

def test_tool_registry_new_capabilities():
    registry = build_tool_registry()
    assert registry.get("create_game") is not None
    assert registry.get("unity_bridge") is not None


if __name__ == "__main__":
    test_conversation_materia()
    test_game_2d()
    test_interpreter_game_and_conversation()
    test_executor_game()
    test_unity_project_bridge_scaffold()
    test_runtime_responses()
    test_tool_registry_new_capabilities()
    print("CONVERSATION/GAME/UNITY TESTS OK")
