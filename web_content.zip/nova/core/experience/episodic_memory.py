import json
from datetime import datetime, timezone
from pathlib import Path

class EpisodicMemory:
    """Memoria autobiográfica de experiencias resumidas, no cadena privada de razonamiento."""
    def __init__(self, path="core/memory/episodes.json", limit=2000):
        self.path=Path(path); self.limit=limit
        self.episodes=[]; self.load()
    def now(self): return datetime.now(timezone.utc).isoformat()
    def load(self):
        try:
            if self.path.exists():
                data=json.loads(self.path.read_text(encoding="utf-8"))
                self.episodes=data if isinstance(data,list) else data.get("episodes",[])
        except (OSError,json.JSONDecodeError): self.episodes=[]
    def save(self):
        self.path.parent.mkdir(parents=True,exist_ok=True)
        tmp=self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.episodes[-self.limit:],ensure_ascii=False,indent=2),encoding="utf-8")
        tmp.replace(self.path)
    def record(self,event_type,summary,context=None,outcome=None,importance=0.5):
        item={"id":len(self.episodes)+1,"timestamp":self.now(),"type":str(event_type),
              "summary":str(summary),"context":dict(context or {}),"outcome":outcome,
              "importance":max(0,min(1,float(importance)))}
        self.episodes.append(item); self.save(); return item
    def recent(self,limit=20): return self.episodes[-max(1,int(limit)):]
    def search(self,query,limit=10):
        q=set(str(query).lower().split())
        scored=[]
        for e in self.episodes:
            text=(e.get("summary","")+" "+" ".join(map(str,e.get("context",{}).values()))).lower()
            score=sum(1 for token in q if token in text)
            if score: scored.append((score,e))
        scored.sort(key=lambda x:(x[0],x[1].get("importance",0)),reverse=True)
        return [e for _,e in scored[:limit]]
