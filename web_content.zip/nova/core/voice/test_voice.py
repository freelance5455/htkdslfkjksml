from core.voice.voice_control import VoiceControl
from core.voice.voice_pipeline import VoicePipeline
from core.voice.speech_to_text import SpeechToText
from core.voice.text_to_speech import TextToSpeech
from core.voice.voice_state import VoiceState


def test_voice_control():
    voice = VoiceControl()
    result = voice.enable()
    assert result["success"] is True
    assert voice.enabled is True


def test_voice_state():
    state = VoiceState()
    result = state.set(VoiceState.LISTENING)
    assert result["success"] is True
    assert state.current == VoiceState.LISTENING


def test_voice_backends():
    spoken = []
    stt = SpeechToText(lambda: "hola nova")
    tts = TextToSpeech(lambda text: spoken.append(text))
    pipeline = VoicePipeline(stt=stt, tts=tts)
    voice = VoiceControl(pipeline)
    voice.enable()
    result = voice.run_once(lambda text: "respuesta a " + text)
    assert result["success"] is True
    assert result["heard"] == "hola nova"
    assert spoken == ["respuesta a hola nova"]


def test_voice_failure_is_explicit():
    result = SpeechToText().listen()
    assert result["success"] is False
    assert result["available"] is False


if __name__ == "__main__":
    test_voice_control()
    test_voice_state()
    test_voice_backends()
    test_voice_failure_is_explicit()
    print("Voice tests passed.")
