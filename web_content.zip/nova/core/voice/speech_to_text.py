class SpeechToText:
    """Capa STT de N.O.V.A. con backend intercambiable."""

    def __init__(self, backend=None):
        self.backend = backend
        self.available = callable(backend)

    def set_backend(self, backend):
        self.backend = backend
        self.available = callable(backend)
        return {"success": True, "available": self.available}

    def listen(self):
        if not self.available:
            return {
                "success": False,
                "available": False,
                "error": "No hay un backend STT conectado.",
            }

        try:
            result = self.backend()
            if result is None:
                return {
                    "success": False,
                    "available": True,
                    "error": "El backend STT no devolvió texto.",
                }
            return {
                "success": True,
                "available": True,
                "text": str(result),
            }
        except Exception as exc:
            return {
                "success": False,
                "available": True,
                "error": f"{type(exc).__name__}: {exc}",
            }
