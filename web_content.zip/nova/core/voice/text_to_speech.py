class TextToSpeech:
    """Capa TTS de N.O.V.A. con backend intercambiable."""

    def __init__(self, backend=None):
        self.backend = backend
        self.available = callable(backend)

    def set_backend(self, backend):
        self.backend = backend
        self.available = callable(backend)
        return {
            "success": True,
            "available": self.available,
        }

    def speak(self, text):
        if not self.available:
            return {
                "success": False,
                "available": False,
                "text": text,
                "error": "No hay un backend TTS conectado.",
            }

        try:
            result = self.backend(text)
            return {
                "success": True,
                "available": True,
                "text": text,
                "backend_result": result,
            }
        except Exception as exc:
            return {
                "success": False,
                "available": True,
                "text": text,
                "error": f"{type(exc).__name__}: {exc}",
            }
