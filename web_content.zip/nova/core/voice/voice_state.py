class VoiceState:
    """Estados principales del sistema de voz de N.O.V.A."""

    LISTENING = "listening"
    PROCESSING = "processing"
    RESPONDING = "responding"
    IDLE = "idle"

    def __init__(self):
        self.current = self.IDLE

    def set(self, state):
        if state not in {
            self.LISTENING,
            self.PROCESSING,
            self.RESPONDING,
            self.IDLE,
        }:
            return {
                "success": False,
                "error": "Estado de voz inválido.",
            }

        self.current = state

        return {
            "success": True,
            "state": self.current,
        }
