from core.voice.voice_pipeline import VoicePipeline


class VoiceControl:
    """Control de alto nivel de voz, listo para recibir backends reales."""

    def __init__(self, pipeline=None):
        self.pipeline = pipeline or VoicePipeline()
        self.enabled = False

    def enable(self):
        self.enabled = True
        return {"success": True, "enabled": True, "status": self.pipeline.status()}

    def disable(self):
        self.enabled = False
        return {"success": True, "enabled": False, "status": self.pipeline.status()}

    def status(self):
        return {
            "success": True,
            "enabled": self.enabled,
            **self.pipeline.status(),
        }

    def run_once(self, processor):
        if not self.enabled:
            return {"success": False, "error": "El control de voz está desactivado."}
        return self.pipeline.run_once(processor)
