from core.voice.speech_to_text import SpeechToText
from core.voice.text_to_speech import TextToSpeech
from core.voice.voice_state import VoiceState


class VoicePipeline:
    """Coordina STT, procesamiento y TTS con estados observables."""

    def __init__(self, stt=None, tts=None, state=None):
        self.stt = stt or SpeechToText()
        self.tts = tts or TextToSpeech()
        self.state = state or VoiceState()

    def status(self):
        return {
            "success": True,
            "state": self.state.current,
            "stt_available": self.stt.available,
            "tts_available": self.tts.available,
        }

    def listen(self):
        self.state.set(VoiceState.LISTENING)
        result = self.stt.listen()
        if not result.get("success"):
            self.state.set(VoiceState.IDLE)
            return result
        self.state.set(VoiceState.PROCESSING)
        return result

    def respond(self, text):
        self.state.set(VoiceState.RESPONDING)
        try:
            return self.tts.speak(str(text))
        finally:
            self.state.set(VoiceState.IDLE)

    def run_once(self, processor):
        heard = self.listen()
        if not heard.get("success"):
            return heard

        text = str(heard.get("text", ""))
        try:
            response = processor(text)
        except Exception as exc:
            self.state.set(VoiceState.IDLE)
            return {
                "success": False,
                "stage": "processor",
                "error": f"{type(exc).__name__}: {exc}",
                "text": text,
            }

        spoken = self.respond(response)
        return {
            "success": bool(spoken.get("success")),
            "heard": text,
            "response": response,
            "spoken": spoken,
        }
