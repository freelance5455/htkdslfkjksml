from core.memory.learning_memory import LearningMemory


class Metacognition:
    def __init__(self, memory=None):
        self.memory = memory or LearningMemory()

    def evaluate(self, query):
        query = query.strip()

        if not query:
            return {
                "status": "unknown",
                "confidence": 0.0,
                "reason": "No hay una consulta que evaluar.",
                "memories": []
            }

        memories = self.memory.search(query)

        if not memories:
            return {
                "status": "unknown",
                "confidence": 0.0,
                "reason": "No encontré conocimiento relacionado en mi memoria.",
                "memories": []
            }

        highest = max(
            memories,
            key=lambda entry: (
                entry.get("match_score", 1.0),
                entry.get("confidence", 0.0)
            )
        )

        memory_confidence = highest.get("confidence", 0.0)
        match_score = highest.get("match_score", 1.0)
        confidence = round(memory_confidence * match_score, 2)

        if confidence >= 0.80:
            status = "known"
            reason = "Tengo conocimiento relacionado con confianza alta."
        elif confidence >= 0.4:
            status = "uncertain"
            reason = "Tengo conocimiento relacionado, pero mi confianza es limitada."
        else:
            status = "uncertain"
            reason = "Existe información relacionada, pero no es suficientemente confiable."

        return {
            "status": status,
            "confidence": confidence,
            "reason": reason,
            "memories": memories
        }
