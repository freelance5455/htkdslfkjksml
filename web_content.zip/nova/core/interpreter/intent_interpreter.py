import re
import unicodedata


class IntentInterpreter:
    """Interpreta lenguaje humano y lo convierte en intenciones estructuradas."""

    PROJECT_ACTIONS = {
        "crear",
        "crea",
        "creame",
        "hacer",
        "haz",
        "hazme",
        "construir",
        "construye",
        "construyeme",
        "generar",
        "genera",
        "generame",
        "desarrollar",
        "desarrolla",
        "desarrollame",
        "implementar",
        "implementa",
        "implementame",
        "disenar",
        "disena",
        "disename",
        "armar",
        "arma",
        "armame",
        "preparar",
        "prepara",
        "preparame",
        "iniciar",
        "inicia",
        "iniciame",
        "empezar",
        "empieza",
        "comenzar",
        "comienza",
    }

    PROJECT_WORDS = {
        "proyecto",
        "project",
    }

    CONDITIONAL_IF_WORDS = {
        "si",
    }

    CONDITIONAL_ELSE_WORDS = {
        "sino",
        "si no",
    }

    ANALYZE_ACTIONS = {
        "analizar",
        "analiza",
        "analizarlo",
        "analizalo",
        "inspeccionar",
        "inspecciona",
        "revisar",
        "revisa",
        "comprobar",
        "comprueba",
    }

    def _normalize(self, text):
        text = text.lower().strip()
        text = unicodedata.normalize("NFD", text)
        text = "".join(
            char
            for char in text
            if unicodedata.category(char) != "Mn"
        )
        text = re.sub(r"\s+", " ", text)
        return text

    def _clean_name(self, name):
        if not name:
            return None

        name = name.strip()
        name = name.strip(" .,:;!?¿¡\"'")

        return name or None

    def _action_pattern(self):
        actions = sorted(
            (re.escape(action) for action in self.PROJECT_ACTIONS),
            key=len,
            reverse=True,
        )
        return rf"(?:{'|'.join(actions)})"

    def _extract_project_name(self, original, normalized):
        action = self._action_pattern()

        # Acción + proyecto + descriptor + nombre
        patterns = [
            rf"^\s*{action}\s+(?:un|una|el|la)?\s*"
            rf"(?:proyecto|project)\s+"
            rf"(?:llamado|llamada|de\s+nombre|con\s+el\s+nombre)\s+(.+?)\s*$",

            # Acción + proyecto + nombre
            rf"^\s*{action}\s+(?:un|una|el|la)?\s*"
            rf"(?:proyecto|project)\s+(.+?)\s*$",

            # Acción + nombre
            rf"^\s*{action}\s+(.+?)\s*$",
        ]

        for pattern in patterns:
            match = re.match(
                pattern,
                normalized,
                flags=re.IGNORECASE,
            )

            if not match:
                continue

            normalized_name = match.group(1).strip()

            if not normalized_name:
                continue

            # Buscamos la posición del nombre normalizado dentro
            # del texto normalizado y usamos esa misma posición
            # para recuperar el texto original.
            start = match.start(1)
            original_name = original[start:]

            original_name = self._clean_name(original_name)

            # Si la forma "acción + nombre" realmente contiene
            # la palabra proyecto al principio del nombre,
            # la retiramos.
            normalized_original_name = self._normalize(original_name)

            words = normalized_original_name.split()

            if words and words[0] in self.PROJECT_WORDS:
                parts = original_name.split(None, 1)
                original_name = (
                    parts[1]
                    if len(parts) > 1
                    else None
                )

            if original_name:
                return original_name

        return None

    def _create_game(self, original, normalized):
        if any(word in normalized for word in (
            "juego 2d", "juego en 2d", "videojuego 2d", "juego 2-d",
            "game 2d", "juego 3d", "juego en 3d", "videojuego 3d",
        )):
            is_3d = any(word in normalized for word in ("juego 3d", "juego en 3d", "videojuego 3d"))
            return {
                "intent": "CREATE_GAME",
                "confidence": 0.98,
                "parameters": {
                    "dimension": "3d" if is_3d else "2d",
                    "instruction": original,
                    "project": "nova_game_3d" if is_3d else "nova_game_2d",
                },
                "original_text": original,
            }
        return None

    def _conversation(self, original, normalized):
        if normalized.endswith("?") or any(normalized.startswith(prefix) for prefix in (
            "que es ", "qué es ", "que son ", "qué son ",
            "explicame ", "explícame ", "como funciona ", "cómo funciona ",
            "por que ", "por qué ", "quien es ", "quién es ",
            "dime que ", "dime qué ",
        )):
            return {
                "intent": "CONVERSATION",
                "confidence": 0.80,
                "parameters": {"text": original},
                "original_text": original,
            }
        return None

    def _develop_project(self, original, normalized):
        """Detecta una misión explícita para desarrollar una capacidad del propio proyecto."""
        action_words = (
            "desarrolla", "desarrollar",
            "implementa", "implementar",
            "prepara", "preparar",
        )

        if not normalized.startswith(action_words):
            return None

        mission_markers = (
            "fase ",
            "voz",
            "n.o.v.a",
            "nova",
            "este proyecto",
            "tu propio proyecto",
            "propio proyecto",
        )

        if not any(marker in normalized for marker in mission_markers):
            return None

        return {
            "intent": "DEVELOP_PROJECT",
            "confidence": 0.95,
            "parameters": {
                "project": "NOVA",
                "instruction": original,
            },
            "original_text": original,
        }

    def _create_project(self, original, normalized):
        action = self._action_pattern()

        # Primero comprobamos que la orden comience con una
        # acción conocida.
        if not re.match(
            rf"^\s*{action}\b",
            normalized,
            flags=re.IGNORECASE,
        ):
            return None

        name = self._extract_project_name(
            original,
            normalized,
        )

        if not name:
            return None

        return {
            "intent": "CREATE_PROJECT",
            "confidence": 0.95,
            "parameters": {
                "name": name,
            },
            "original_text": original,
        }

    def _analyze_project(self, original, normalized):
        action = sorted(
            (re.escape(item) for item in self.ANALYZE_ACTIONS),
            key=len,
            reverse=True,
        )
        action_pattern = rf"(?:{"|".join(action)})"

        pattern = (
            rf"^\s*{action_pattern}\s+"
            rf"(?:el\s+|un\s+|una\s+)?"
            rf"(?:proyecto|project)"
            rf"(?:\s+(.+?))?\s*$"
        )

        match = re.match(
            pattern,
            normalized,
            flags=re.IGNORECASE,
        )

        if not match:
            return None

        project = match.group(1).strip() if match.group(1) else None

        if project:
            project = re.split(
                r"\s+y\s+(?:determina|dime|di|explica|indica|muestra|revisa|comprueba|analiza)\b",
                project,
                maxsplit=1,
                flags=re.IGNORECASE,
            )[0].strip()

        return {
            "intent": "ANALYZE_PROJECT",
            "confidence": 0.95,
            "parameters": {
                "project": project,
                "read_only": True,
            },
            "original_text": original,
        }

    def _parse_conditional(self, original):
        """
        Detecta una orden condicional con la forma:
        SI <paso>; <paso_si_exito>; SINO; <paso_si_fallo>

        La condición se interpreta como éxito de la tarea anterior.
        """

        normalized = self._normalize(original)

        if not re.match(r"^si(?:\s*;|\s+)", normalized):
            return None

        body = re.sub(
            r"^si\s*;?\s*",
            "",
            original,
            count=1,
            flags=re.IGNORECASE,
        ).strip()

        else_match = re.search(
            r"\s*(?:;\s*)?(?:sino|si\s+no)\s*(?:;\s*)?",
            body,
            flags=re.IGNORECASE,
        )

        if else_match:
            true_text = body[:else_match.start()].strip(" ;")
            false_text = body[else_match.end():].strip(" ;")

            if not true_text or not false_text:
                return None

            true_steps = [
                part.strip()
                for part in re.split(r"\s*;\s*", true_text)
                if part.strip()
            ]

            false_steps = [
                part.strip()
                for part in re.split(r"\s*;\s*", false_text)
                if part.strip()
            ]

            return {
                "intent": "CONDITIONAL",
                "confidence": 0.90,
                "parameters": {
                    "condition": {
                        "type": "result_success",
                        "equals": True,
                    },
                    "true_text": true_steps,
                    "false_text": false_steps,
                },
                "original_text": original,
            }

        steps = [
            part.strip()
            for part in re.split(r"\s*;\s*", body)
            if part.strip()
        ]

        if not steps:
            return None

        return {
            "intent": "CONDITIONAL",
            "confidence": 0.90,
            "parameters": {
                "condition": {
                    "type": "result_success",
                    "equals": True,
                },
                "true_text": steps,
                "false_text": [],
            },
            "original_text": original,
        }

    def _split_compound(self, original):
        """
        Divide una orden compuesta en instrucciones secuenciales.
        Conserva las órdenes simples sin modificarlas.
        """
        normalized = self._normalize(original)

        separators = [
            r"\s+y\s+despues\s+",
            r"\s+y\s+después\s+",
            r"\s+y\s+luego\s+",
            r"\s+despues\s+",
            r"\s+después\s+",
            r"\s+luego\s+",
            r"\s*;\s*",
        ]

        parts = [original]

        for separator in separators:
            new_parts = []
            for part in parts:
                chunks = re.split(separator, part, flags=re.IGNORECASE)
                new_parts.extend(chunk.strip() for chunk in chunks if chunk.strip())
            parts = new_parts

        if len(parts) <= 1:
            return None

        return parts

    def _autonomous_mission(self, original, normalized):
        markers = (
            "mision autonoma", "misión autónoma", "trabajo autonomo",
            "trabajo autónomo", "hazlo autonomamente", "hazlo de forma autonoma",
            "encargate de todo", "encárgate de todo",
        )
        if not any(marker in normalized for marker in markers):
            return None
        return {
            "intent": "AUTONOMOUS_MISSION",
            "confidence": 0.94,
            "parameters": {"project": "NOVA", "instruction": original},
            "original_text": original,
        }

    def _build_nova_apk(self, original, normalized):
        markers = (
            "crea un apk de ti mismo", "hazte un apk", "haz un apk de ti mismo",
            "crea tu propio apk", "construye tu propio apk", "genera tu propio apk",
            "crea una apk de ti mismo", "haz una apk de ti mismo",
            "construye una apk de ti mismo", "compila tu apk",
        )
        if any(marker in normalized for marker in markers):
            return {
                "intent": "BUILD_NOVA_APK",
                "confidence": 0.99,
                "parameters": {"project": "NOVA", "self_build": True},
                "original_text": original,
            }
        return None

    def _unity_action(self, original, normalized):
        if "unity" not in normalized:
            return None
        if any(x in normalized for x in ("conecta", "conectar", "comprueba", "ping")):
            action = "ping"
        elif "escena" in normalized:
            action = "create_scene"
        elif any(x in normalized for x in ("cubo", "esfera", "capsula", "cilindro", "objeto 3d")):
            action = "create_primitive"
        else:
            return None
        return {
            "intent": "UNITY_ACTION",
            "confidence": 0.94,
            "parameters": {"action": action, "project": "nova_unity_3d"},
            "original_text": original,
        }

    def interpret(self, text):
        if not isinstance(text, str):
            raise TypeError("text debe ser una cadena")

        original = text.strip()

        if not original:
            return {
                "intent": "UNKNOWN",
                "confidence": 0.0,
                "parameters": {},
                "original_text": original,
            }

        normalized = self._normalize(original)

        result = self._autonomous_mission(original, normalized)
        if result:
            return result

        result = self._build_nova_apk(original, normalized)
        if result:
            return result

        result = self._unity_action(original, normalized)
        if result:
            return result

        result = self._create_game(original, normalized)
        if result:
            return result

        conditional = self._parse_conditional(original)
        if conditional:
            return conditional

        # Detectar una misión compuesta antes de interpretar
        # la orden completa como una sola intención.
        parts = self._split_compound(original)

        if parts:
            interpretations = []

            for part in parts:
                part_normalized = self._normalize(part)

                result = self._create_project(
                    part,
                    part_normalized,
                )

                if not result:
                    result = self._analyze_project(
                        part,
                        part_normalized,
                    )

                if not result:
                    result = {
                        "intent": "UNKNOWN",
                        "confidence": 0.0,
                        "parameters": {},
                        "original_text": part,
                    }

                interpretations.append(result)

            return {
                "intent": "COMPOUND",
                "confidence": min(
                    item.get("confidence", 0.0)
                    for item in interpretations
                ),
                "parameters": {
                    "steps": interpretations,
                },
                "original_text": original,
            }

        result = self._develop_project(
            original,
            normalized,
        )
        if result:
            return result

        result = self._create_project(
            original,
            normalized,
        )

        if result:
            return result

        result = self._analyze_project(
            original,
            normalized,
        )

        if result:
            return result

        result = self._conversation(original, normalized)
        if result:
            return result

        return {
            "intent": "UNKNOWN",
            "confidence": 0.0,
            "parameters": {},
            "original_text": original,
        }
