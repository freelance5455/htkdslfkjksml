from core.interpreter.intent_interpreter import IntentInterpreter
from core.interpreter.intent_to_goal import IntentToGoal
from core.interpreter.intent_executor import IntentExecutor
from core.interpreter.autonomous_executor import AutonomousExecutor
from core.goals.goal_manager import GoalManager
from core.planner.planner import Planner


class AutonomousOrchestrator:
    """Conecta órdenes humanas con planificación y ejecución real."""

    def __init__(self):
        self.interpreter = IntentInterpreter()
        self.converter = IntentToGoal()
        self.intent_executor = IntentExecutor()
        self.manager = GoalManager()

    def run(self, text):
        interpretation = self.interpreter.interpret(text)

        if interpretation.get("intent") == "UNKNOWN":
            return {
                "success": False,
                "stage": "interpretation",
                "interpretation": interpretation,
                "result": "ERROR: No pude interpretar la orden.",
            }

        goal_data = self.converter.convert(interpretation)

        goal = self.manager.create(
            goal_data["description"],
            priority=5,
        )

        planner = Planner(self.manager.all())

        plan_result = planner.create_plan(goal)
        plan = (
            plan_result["plan"]
            if "plan" in plan_result
            else plan_result
        )

        if interpretation.get("intent") == "CONDITIONAL":
            parameters = interpretation.get("parameters", {})
            condition = parameters.get("condition", {})

            true_text = parameters.get("true_text", [])
            false_text = parameters.get("false_text", [])

            if isinstance(true_text, str):
                true_text = [true_text]

            if isinstance(false_text, str):
                false_text = [false_text]

            if not true_text and not false_text:
                return {
                    "success": False,
                    "stage": "planning",
                    "interpretation": interpretation,
                    "goal": goal,
                    "plan": plan,
                    "result": "ERROR: La misión condicional no contiene ramas.",
                }

            # La condición se evalúa sobre la tarea anterior.
            # Para una misión independiente, usamos la primera
            # instrucción de la rama verdadera como tarea base.
            branch_source = true_text[0] if true_text else false_text[0]

            source_interpretation = self.interpreter.interpret(
                branch_source
            )

            if source_interpretation.get("intent") == "UNKNOWN":
                return {
                    "success": False,
                    "stage": "interpretation",
                    "interpretation": interpretation,
                    "goal": goal,
                    "result": "ERROR: No pude interpretar la tarea base de la condición.",
                }

            source_goal = self.converter.convert(
                source_interpretation
            )

            source_result = planner.add_task(
                plan,
                source_goal["description"],
                priority=5,
            )

            if not source_result.get("success"):
                return {
                    "success": False,
                    "stage": "planning",
                    "interpretation": interpretation,
                    "goal": goal,
                    "plan": plan,
                    "result": source_result,
                }

            source_task = source_result["task"]
            source_task["inputs"] = dict(
                source_interpretation.get("parameters", {})
            )
            source_task["context"] = {
                "intent": source_interpretation.get("intent"),
                "confidence": source_interpretation.get(
                    "confidence",
                    0.0,
                ),
                "original_text": source_interpretation.get(
                    "original_text",
                    branch_source,
                ),
                "conditional_source": True,
            }

            source_task_id = source_task["id"]

            created_tasks = [source_task]

            # Rama verdadera: se ejecuta cuando la tarea fuente tiene éxito.
            for branch_text in true_text[1:]:
                branch_interpretation = self.interpreter.interpret(
                    branch_text
                )

                branch_goal = self.converter.convert(
                    branch_interpretation
                )

                if branch_goal is None:
                    continue

                task_result = planner.add_task(
                    plan,
                    branch_goal["description"],
                    priority=5,
                )

                if not task_result.get("success"):
                    return {
                        "success": False,
                        "stage": "planning",
                        "interpretation": interpretation,
                        "goal": goal,
                        "plan": plan,
                        "result": task_result,
                    }

                task = task_result["task"]
                task["depends_on"] = [source_task_id]
                task["inputs"] = dict(
                    branch_interpretation.get("parameters", {})
                )
                task["condition"] = {
                    "type": "result_success",
                    "equals": True,
                }
                task["context"] = {
                    "intent": branch_interpretation.get("intent"),
                    "confidence": branch_interpretation.get(
                        "confidence",
                        0.0,
                    ),
                    "original_text": branch_interpretation.get(
                        "original_text",
                        branch_text,
                    ),
                    "conditional_branch": "true",
                }

                created_tasks.append(task)

            # Rama falsa: se ejecuta cuando la tarea fuente falla.
            for branch_text in false_text:
                branch_interpretation = self.interpreter.interpret(
                    branch_text
                )

                branch_goal = self.converter.convert(
                    branch_interpretation
                )

                if branch_goal is None:
                    continue

                task_result = planner.add_task(
                    plan,
                    branch_goal["description"],
                    priority=5,
                )

                if not task_result.get("success"):
                    return {
                        "success": False,
                        "stage": "planning",
                        "interpretation": interpretation,
                        "goal": goal,
                        "plan": plan,
                        "result": task_result,
                    }

                task = task_result["task"]
                task["depends_on"] = [source_task_id]
                task["inputs"] = dict(
                    branch_interpretation.get("parameters", {})
                )
                task["condition"] = {
                    "type": "result_success",
                    "equals": False,
                }
                task["context"] = {
                    "intent": branch_interpretation.get("intent"),
                    "confidence": branch_interpretation.get(
                        "confidence",
                        0.0,
                    ),
                    "original_text": branch_interpretation.get(
                        "original_text",
                        branch_text,
                    ),
                    "conditional_branch": "false",
                }

                created_tasks.append(task)

            executor = AutonomousExecutor(
                planner,
                self.intent_executor,
            )

            execution = executor.run_plan(plan)

            return {
                "success": execution["success"],
                "interpretation": interpretation,
                "goal": goal,
                "plan": plan,
                "execution": execution,
                "plan_status": planner.plan_status(plan),
            }

        # Una misión compuesta se convierte en varias tareas
        # encadenadas mediante dependencias.
        if interpretation.get("intent") == "COMPOUND":
            steps = interpretation.get(
                "parameters", {}
            ).get("steps", [])

            if not steps:
                return {
                    "success": False,
                    "stage": "planning",
                    "interpretation": interpretation,
                    "goal": goal,
                    "result": "ERROR: La misión compuesta no contiene pasos.",
                }

            previous_task_id = None
            created_tasks = []

            for index, step in enumerate(steps, start=1):
                step_goal = self.converter.convert(step)

                task_result = planner.add_task(
                    plan,
                    step_goal["description"],
                    priority=5,
                )

                if not task_result.get("success"):
                    return {
                        "success": False,
                        "stage": "planning",
                        "interpretation": interpretation,
                        "goal": goal,
                        "plan": plan,
                        "result": task_result,
                    }

                task = task_result["task"]

                if previous_task_id is not None:
                    task["depends_on"] = [previous_task_id]

                task["inputs"] = dict(
                    step.get("parameters", {})
                )

                if step.get("condition") is not None:
                    task["condition"] = step.get("condition")

                task["context"] = {
                    "intent": step.get("intent"),
                    "confidence": step.get(
                        "confidence",
                        0.0
                    ),
                    "original_text": step.get(
                        "original_text",
                        "",
                    ),
                    "compound_step": index,
                }

                created_tasks.append(task)
                previous_task_id = task["id"]

            executor = AutonomousExecutor(
                planner,
                self.intent_executor,
            )

            execution = executor.run_plan(plan)

            return {
                "success": execution["success"],
                "interpretation": interpretation,
                "goal": goal,
                "plan": plan,
                "execution": execution,
                "plan_status": planner.plan_status(plan),
            }

        # Mantener exactamente el flujo existente para órdenes simples.
        task_result = planner.add_task(
            plan,
            goal_data["description"],
            priority=5,
        )

        if not task_result.get("success"):
            return {
                "success": False,
                "stage": "planning",
                "interpretation": interpretation,
                "goal": goal,
                "result": task_result,
            }

        task = task_result["task"]

        task["inputs"] = interpretation.get(
            "parameters",
            {}
        )

        task["context"] = {
            "intent": interpretation.get("intent"),
            "confidence": interpretation.get(
                "confidence",
                0.0
            ),
            "original_text": interpretation.get(
                "original_text",
                text
            ),
        }

        executor = AutonomousExecutor(
            planner,
            self.intent_executor,
        )

        execution = executor.run_plan(plan)

        return {
            "success": execution["success"],
            "interpretation": interpretation,
            "goal": goal,
            "plan": plan,
            "execution": execution,
            "plan_status": planner.plan_status(plan),
        }

