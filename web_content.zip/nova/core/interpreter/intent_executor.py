from core.interpreter.tool_bridge import ToolBridge


class IntentExecutor:
    """Ejecuta intenciones conocidas mediante las herramientas disponibles."""

    def __init__(self):
        self.tool_bridge = ToolBridge()

    def execute(self, interpretation):
        if not isinstance(interpretation, dict):
            raise TypeError("interpretation debe ser un diccionario")

        intent = interpretation.get("intent")
        parameters = interpretation.get("parameters", {})

        if intent == "AUTONOMOUS_MISSION":
            from core.runtime.advanced_tool_handlers import autonomous_project_tool
            result = autonomous_project_tool(
                parameters.get("project", "NOVA"),
                parameters.get("instruction", interpretation.get("original_text", "")),
            )
            return {
                "success": bool(result.get("success")),
                "intent": intent,
                "result": result,
            }

        if intent == "BUILD_NOVA_APK":
            from core.runtime.advanced_tool_handlers import build_nova_apk_tool
            result = build_nova_apk_tool()
            return {
                "success": bool(result.get("success")),
                "intent": intent,
                "result": result,
            }

        if intent == "UNITY_ACTION":
            from core.runtime.advanced_tool_handlers import unity_action_tool
            result = unity_action_tool(
                action=parameters.get("action", "ping"),
                project=parameters.get("project"),
            )
            return {
                "success": bool(result.get("success")),
                "intent": intent,
                "result": result,
            }

        if intent == "CREATE_GAME":
            dimension = parameters.get("dimension", "2d")
            project = parameters.get("project", "nova_game_2d")
            if dimension == "2d":
                from core.game.game_builder import GameBuilder
                result = GameBuilder().build_2d(project)
                return {
                    "success": bool(result.get("success")),
                    "intent": intent,
                    "dimension": dimension,
                    "result": result,
                }
            from core.engines.unity_bridge import UnityBridge
            result = UnityBridge().create_unity_project(project)
            return {
                "success": bool(result.get("success")),
                "intent": intent,
                "dimension": dimension,
                "result": result,
            }

        if intent == "CONVERSATION":
            from core.conversation.conversation_engine import ConversationEngine
            result = ConversationEngine().answer(parameters.get("text", interpretation.get("original_text", "")))
            return {
                "success": bool(result.get("success")),
                "intent": intent,
                "result": result,
            }


        if intent == "DEVELOP_PROJECT":
            project = parameters.get("project")
            instruction = parameters.get("instruction")

            if not project:
                return {
                    "success": False,
                    "intent": intent,
                    "result": "ERROR: Falta el proyecto para la misión de desarrollo.",
                }

            if not instruction:
                return {
                    "success": False,
                    "intent": intent,
                    "result": "ERROR: Falta la instrucción de desarrollo.",
                }

            from core.development.development_engine import DevelopmentEngine

            development_result = DevelopmentEngine().develop(
                project,
                instruction,
            )

            return {
                "success": bool(development_result.get("success")),
                "intent": intent,
                "project": project,
                "instruction": instruction,
                "development": development_result,
                "result": (
                    "La misión de desarrollo fue ejecutada por el motor "
                    "de desarrollo autónomo."
                    if development_result.get("success")
                    else "La misión de desarrollo terminó con errores."
                ),
            }

        if intent == "CREATE_PROJECT":
            name = parameters.get("name")

            if not name:
                return {
                    "success": False,
                    "intent": intent,
                    "result": "ERROR: Falta el nombre del proyecto.",
                }

            result = self.tool_bridge.run_project_tool(name)

            response = {
                "success": result["success"],
                "intent": intent,
                "result": result["result"],
            }

            if result["success"]:
                response["outputs"] = {
                    "project": f"projects/{name.strip()}",
                }

            return response

        if intent == "ANALYZE_PROJECT":
            project = parameters.get("project")

            if not project:
                return {
                    "success": False,
                    "intent": intent,
                    "result": "ERROR: Falta el proyecto a analizar.",
                }

            result = self.tool_bridge.run_analyze_codebase_tool(project)

            response = {
                "success": result["success"],
                "intent": intent,
                "result": result["result"],
            }

            if result["success"]:
                response["outputs"] = {
                    "project": project,
                }

            return response

        return {
            "success": False,
            "intent": intent,
            "result": "ERROR: Intención no soportada.",
        }
