import subprocess


class ToolBridge:
    """Puente entre el núcleo Python de N.O.V.A. y herramientas Java."""

    def run_analyze_codebase_tool(self, project):
        from core.runtime.advanced_tool_handlers import analyze_codebase_tool

        if not isinstance(project, str) or not project.strip():
            return {
                "success": False,
                "result": "ERROR: El proyecto está vacío.",
            }

        result = analyze_codebase_tool(project.strip())

        return {
            "success": result.get("success", False),
            "result": result,
        }

    def run_project_tool(self, name):
        if not isinstance(name, str) or not name.strip():
            return {
                "success": False,
                "result": "ERROR: El nombre del proyecto está vacío.",
            }

        process = subprocess.run(
            [
                "java",
                "-cp",
                ".",
                "tools.system.ProjectToolBridge",
                name.strip(),
            ],
            capture_output=True,
            text=True,
            cwd=".",
        )

        output = process.stdout.strip()

        if process.returncode != 0:
            return {
                "success": False,
                "result": process.stderr.strip() or output,
            }

        return {
            "success": output.startswith("Proyecto creado correctamente:"),
            "result": output,
        }
