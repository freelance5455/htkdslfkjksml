class IntentToGoal:
    """Convierte una intención interpretada en un objetivo estructurado."""

    def convert(self, interpretation):
        if not isinstance(interpretation, dict):
            raise TypeError("interpretation debe ser un diccionario")

        intent = interpretation.get("intent")
        parameters = interpretation.get("parameters", {})

        if intent == "COMPOUND":
            steps = parameters.get("steps", [])

            goals = []

            for step in steps:
                goal = self.convert(step)

                if goal is not None:
                    goals.append(goal)

            return {
                "goal_type": "COMPOUND",
                "description": interpretation.get(
                    "original_text",
                    "Misión compuesta",
                ),
                "parameters": {
                    "steps": goals,
                },
            }

        if intent == "CONDITIONAL":
            condition = parameters.get("condition", {})
            true_text = parameters.get("true_text", [])
            false_text = parameters.get("false_text", [])

            if isinstance(true_text, str):
                true_text = [true_text]

            if isinstance(false_text, str):
                false_text = [false_text]

            return {
                "goal_type": "CONDITIONAL",
                "description": interpretation.get(
                    "original_text",
                    "Misión condicional",
                ),
                "parameters": {
                    "condition": condition,
                    "true_steps": true_text,
                    "false_steps": false_text,
                },
            }

        if intent == "DEVELOP_PROJECT":
            project = parameters.get("project")
            instruction = parameters.get("instruction") or interpretation.get(
                "original_text",
                "Misión de desarrollo",
            )

            return {
                "goal_type": "DEVELOP_PROJECT",
                "description": (
                    f"Desarrollar en el proyecto '{project}': {instruction}"
                    if project
                    else f"Desarrollar: {instruction}"
                ),
                "parameters": {
                    "project": project,
                    "instruction": instruction,
                },
            }

        if intent == "CREATE_GAME":
            dimension = parameters.get("dimension", "2d")
            project = parameters.get("project", "nova_game_2d")
            return {
                "goal_type": "CREATE_GAME",
                "description": f"Crear juego {dimension.upper()} '{project}'",
                "parameters": {
                    "dimension": dimension,
                    "project": project,
                    "instruction": parameters.get("instruction", interpretation.get("original_text", "")),
                },
            }

        if intent == "CONVERSATION":
            text = parameters.get("text") or interpretation.get("original_text", "")
            return {
                "goal_type": "CONVERSATION",
                "description": f"Responder la pregunta: {text}",
                "parameters": {"text": text},
            }

        if intent == "CREATE_PROJECT":
            name = parameters.get("name")

            return {
                "goal_type": "CREATE_PROJECT",
                "description": (
                    f"Crear el proyecto '{name}'"
                    if name
                    else "Crear un proyecto"
                ),
                "parameters": {
                    "name": name,
                },
            }

        if intent == "ANALYZE_PROJECT":
            project = parameters.get("project")
            return {
                "goal_type": "ANALYZE_PROJECT",
                "description": (
                    f"Analizar el proyecto '{project}'"
                    if project
                    else "Analizar el proyecto"
                ),
                "parameters": {
                    "project": project,
                    "read_only": parameters.get("read_only", True),
                },
            }

        return None
