from core.runtime.task_verifier import TaskVerifier
class AutonomousExecutor:
    """Ejecuta automáticamente tareas mediante ejecutores reales."""

    def __init__(self, planner, intent_executor=None, verifier=None):
        self.planner = planner
        self.intent_executor = intent_executor
        self.verifier = verifier or TaskVerifier()

    def run_task(self, plan, task):
        intent = task.get("context", {}).get("intent")

        if self.intent_executor is None:
            return {
                "success": False,
                "task_id": task["id"],
                "message": "ERROR: IntentExecutor no disponible.",
            }

        interpretation = {
            "intent": intent,
            "confidence": task.get("context", {}).get("confidence", 0.0),
            "parameters": task.get("inputs", {}),
            "original_text": task.get("context", {}).get("original_text", ""),
        }

        result = self.intent_executor.execute(interpretation)

        response = {
            "success": result.get("success", False),
            "task_id": task["id"],
            "message": result.get(
                "result",
                result.get("error", "Sin resultado."),
            ),
            "result": result,
        }

        if result.get("outputs"):
            response["outputs"] = result["outputs"]

        return response

    def run_plan(self, plan):
        results = []

        while True:
            current = next(
                (
                    task for task in plan["tasks"]
                    if task["status"] == "running"
                ),
                None,
            )

            # Si ya existe una tarea en ejecución, continuar con ella.
            # No volver a llamar start_next_task(), porque
            # complete_current_task() puede haber iniciado la siguiente.
            if current is None:
                current = self.planner.next_task(plan)

                if current is None:
                    break

                started = self.planner.start_next_task(plan)

                if not started.get("success"):
                    return {
                        "success": False,
                        "status": self.planner.plan_status(plan),
                        "results": results,
                        "error": started,
                    }

                current = started["task"]

            result = self.run_task(plan, current)

            verification = self.verifier.verify(current, result)
            result["verification"] = verification

            if not verification["verified"]:
                self.planner.set_task_result(
                    plan,
                    current["id"],
                    result,
                )

                failure = self.planner.fail_task(
                    plan,
                    current["id"],
                    verification["reason"],
                )

                if failure.get("retry"):
                    retry = self.planner.retry_task(
                        plan,
                        current["id"],
                    )

                    if retry.get("success"):
                        results.append({
                            "task_id": current["id"],
                            "description": current["description"],
                            "result": result,
                            "recovery": {
                                "action": "retry",
                                "attempts": retry["task"].get(
                                    "attempts",
                                    0,
                                ),
                            },
                        })
                        continue

                return {
                    "success": False,
                    "status": self.planner.plan_status(plan),
                    "results": results,
                    "error": result,
                }

            saved = self.planner.set_task_result(
                plan,
                current["id"],
                result,
            )

            if not saved.get("success"):
                return {
                    "success": False,
                    "status": self.planner.plan_status(plan),
                    "results": results,
                    "error": saved,
                }

            completed = self.planner.complete_current_task(
                plan,
                result=result,
            )

            if not completed.get("success"):
                return {
                    "success": False,
                    "status": self.planner.plan_status(plan),
                    "results": results,
                    "error": completed,
                }

            results.append({
                "task_id": current["id"],
                "description": current["description"],
                "result": result,
                "verification": verification,
            })

        status = self.planner.plan_status(plan)

        return {
            "success": status == "completed",
            "status": status,
            "results": results,
        }

