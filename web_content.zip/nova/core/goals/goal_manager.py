import json
from pathlib import Path
from datetime import datetime, timezone


class GoalManager:
    def __init__(self, path="core/goals/goals.json"):
        self.path = Path(path)
        self.goals = []
        self.load()

    def _now(self):
        return datetime.now(timezone.utc).isoformat()

    def load(self):
        if not self.path.exists():
            return

        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            if isinstance(data, list):
                self.goals = data
        except (json.JSONDecodeError, OSError):
            self.goals = []

    def save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)

        temp = self.path.with_suffix(".tmp")
        temp.write_text(
            json.dumps(self.goals, ensure_ascii=False, indent=2),
            encoding="utf-8"
        )
        temp.replace(self.path)

    def create(self, name, priority=0, parent_id=None):
        try:
            priority = int(priority)
        except (TypeError, ValueError):
            raise ValueError("La prioridad debe ser un número entero.")

        goal = {
            "id": len(self.goals) + 1,
            "name": name,
            "priority": priority,
            "parent_id": parent_id,
            "status": "active",
            "progress": 0.0,
            "created_at": self._now(),
            "updated_at": self._now()
        }

        self.goals.append(goal)
        self.save()
        return goal

    def update(self, goal_id, progress=None, status=None, priority=None):
        for goal in self.goals:
            if goal["id"] == goal_id:
                if progress is not None:
                    goal["progress"] = max(0.0, min(100.0, float(progress)))

                    if goal["progress"] >= 100.0:
                        goal["progress"] = 100.0
                        goal["status"] = "completed"

                if status is not None:
                    valid_statuses = {
                        "active",
                        "paused",
                        "completed",
                        "cancelled"
                    }

                    if status not in valid_statuses:
                        raise ValueError(
                            "Estado de objetivo no válido."
                        )

                    goal["status"] = status

                if priority is not None:
                    goal["priority"] = int(priority)

                goal["updated_at"] = self._now()
                self.save()
                return goal

        return None

    def sync_progress(self, goal_id):
        goal = next(
            (item for item in self.goals if item["id"] == goal_id),
            None
        )

        if goal is None:
            return None

        children = self.children_of(goal_id)

        if not children:
            return goal.get("progress", 0.0)

        progress = self.progress_of(goal_id)

        goal["progress"] = progress

        if progress >= 100.0:
            goal["progress"] = 100.0
            goal["status"] = "completed"

        goal["updated_at"] = self._now()
        self.save()

        return goal

    def progress_of(self, goal_id):
        goal = next(
            (item for item in self.goals if item["id"] == goal_id),
            None
        )

        if goal is None:
            return None

        children = self.children_of(goal_id)

        if not children:
            return goal.get("progress", 0.0)

        total = sum(
            float(child.get("progress", 0.0))
            for child in children
        )

        return round(total / len(children), 2)

    def cancel(self, goal_id):
        return self.update(goal_id, status="cancelled")

    def pause(self, goal_id):
        return self.update(goal_id, status="paused")

    def resume(self, goal_id):
        return self.update(goal_id, status="active")

    def get(self, goal_id):
        for goal in self.goals:
            if goal["id"] == goal_id:
                return dict(goal)

        return None

    def children_of(self, parent_id):
        return [
            goal for goal in self.goals
            if goal.get("parent_id") == parent_id
        ]

    def active(self):
        return [
            dict(goal)
            for goal in self.goals
            if goal.get("status") == "active"
        ]

    def next_active(self):
        active = [
            goal for goal in self.goals
            if goal.get("status") == "active"
        ]

        if not active:
            return None

        return max(
            active,
            key=lambda goal: (
                goal.get("priority", 0),
                -goal.get("progress", 0.0)
            )
        )


    def next_pending(self):
        pending = [
            goal for goal in self.goals
            if goal.get("status") in {"active", "paused"}
        ]

        if not pending:
            return None

        return max(
            pending,
            key=lambda goal: (
                goal.get("priority", 0),
                -goal.get("progress", 0.0)
            )
        )

    def summary(self):
        total = len(self.goals)

        active = sum(
            1 for goal in self.goals
            if goal.get("status") == "active"
        )

        paused = sum(
            1 for goal in self.goals
            if goal.get("status") == "paused"
        )

        completed = sum(
            1 for goal in self.goals
            if goal.get("status") == "completed"
        )

        cancelled = sum(
            1 for goal in self.goals
            if goal.get("status") == "cancelled"
        )

        average_progress = round(
            sum(float(goal.get("progress", 0.0)) for goal in self.goals)
            / total,
            2
        ) if total else 0.0

        next_goal = self.next_active()

        return {
            "total": total,
            "active": active,
            "paused": paused,
            "completed": completed,
            "cancelled": cancelled,
            "average_progress": average_progress,
            "next_goal": dict(next_goal) if next_goal else None
        }

    def all(self):
        return list(self.goals)
