import re
import unicodedata

class ConversationEngine:
    KNOWLEDGE = {
        "materia": "La materia es todo lo que tiene masa y ocupa un lugar en el espacio. Está formada por átomos y puede presentarse como sólido, líquido, gas y plasma.",
        "energia": "La energía es la capacidad de producir cambios o realizar trabajo. Puede manifestarse como energía cinética, potencial, térmica, eléctrica, química y otras formas.",
        "atomo": "Un átomo es la unidad básica de un elemento químico. Tiene un núcleo con protones y neutrones y electrones alrededor.",
        "gravedad": "La gravedad es la interacción por la que los cuerpos con masa se atraen. En la superficie de la Tierra hace que los objetos aceleren hacia el suelo.",
        "celula": "La célula es la unidad estructural y funcional básica de los seres vivos. Algunas formas de vida tienen una sola célula y otras están formadas por muchas.",
        "internet": "Internet es una red mundial de redes que permite intercambiar datos y utilizar servicios como la web, correo y APIs.",
        "programacion": "La programación consiste en escribir instrucciones que una computadora puede interpretar o ejecutar para realizar tareas.",
    }
    def _normalize(self, text):
        text = unicodedata.normalize("NFD", str(text).lower().strip())
        text = "".join(c for c in text if unicodedata.category(c) != "Mn")
        return re.sub(r"\s+", " ", text)
    def _extract_topic(self, normalized):
        for pattern in (
            r"^(?:que es|qué es|que son|qué son)\s+(.+?)[?.!]*$",
            r"^(?:explicame|explícame|explica)\s+(?:que es|qué es)?\s*(.+?)[?.!]*$",
            r"^(?:dime|dime que es|dime qué es)\s+(.+?)[?.!]*$",
        ):
            m = re.match(pattern, normalized, re.IGNORECASE)
            if m: return m.group(1).strip()
        return None
    def answer(self, text):
        if not isinstance(text, str) or not text.strip():
            return {"success": False, "answered": False, "error": "La pregunta está vacía."}
        normalized = self._normalize(text).strip("¿¡")
        topic = self._extract_topic(normalized)
        if topic:
            key = topic.strip(" .?!")
            key = re.sub(r"^(?:la|el|los|las|un|una)\s+", "", key)
            if key in self.KNOWLEDGE:
                return {"success": True, "answered": True, "source": "local_knowledge", "topic": key, "answer": self.KNOWLEDGE[key]}
        return {"success": True, "answered": False, "needs_external_knowledge": True, "source": "unresolved", "query": text.strip(), "answer": "No tengo una respuesta local suficientemente confiable para esa pregunta."}
