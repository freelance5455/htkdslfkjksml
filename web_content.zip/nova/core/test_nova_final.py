
import tempfile
from pathlib import Path

from core.cognition.autobiographical_memory import AutobiographicalMemory
from core.cognition.self_model import SelfModel
from core.self_improvement.improvement_lab import ImprovementLab
from core.self_improvement.experiment_runner import ExperimentRunner
from core.runtime.cognitive_runtime import CognitiveRuntime

with tempfile.TemporaryDirectory() as d:
    p=Path(d)
    mem=AutobiographicalMemory(p/"bio.json")
    mem.remember("test","experiencia",lesson="verificar",outcome=True)
    assert mem.recall("experiencia")

    sm=SelfModel(p/"self.json")
    sm.register_capabilities(["reasoning"])
    sm.reflect(True,.9,"ok")
    sm2=SelfModel(p/"self.json")
    assert sm2.knows_capability("reasoning")
    assert sm2.snapshot()["internal_drives"]["confidence"] >= .9

    lab=ImprovementLab(p/"lab.json")
    exp=lab.propose("safe","mejorar",["core/cognition/test.py"])
    out=ExperimentRunner(lab).run(exp["id"],{"verification_passed":True,"score":1.0})
    assert out["success"] and out["decision"]=="keep"

runtime=CognitiveRuntime()
a=runtime.process("estado cognitivo")
assert a["success"] and "cognitive_status" in a
b=runtime.process("iniciativa")
assert b["success"] and "initiative" in b
c=runtime.process("modo autónomo")
assert c["success"] and "autonomy" in c
print("NOVA FINAL COGNITIVE TEST: OK")
