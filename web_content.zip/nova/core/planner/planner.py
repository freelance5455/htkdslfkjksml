class Planner:
    def __init__(self, goals):
        self.goals = goals

    def create_plan(self, goal):
        if not goal:
            return {
                "success": False,
                "reason": "No se proporcionó ningún objetivo.",
                "plan": None
            }

        return {
            "success": True,
            "goal": goal,
            "tasks": [],
            "status": "planned"
        }







    def finish_plan(self, plan):
        if not plan:
            return {
                "success": False,
                "reason": "No se proporcionó un plan.",
                "status": "failed"
            }

        status = self.plan_status(plan)

        if status == "completed":
            plan["status"] = "completed"

            return {
                "success": True,
                "status": "completed"
            }

        return {
            "success": False,
            "reason": "El plan todavía tiene tareas pendientes o en ejecución.",
            "status": status
        }

    def propagate_task_outputs(self, plan, completed_task_id):
        if not plan:
            return {
                "success": False,
                "reason": "No se proporcionó un plan.",
                "updated_tasks": []
            }

        completed_task = next(
            (
                task for task in plan.get("tasks", [])
                if task.get("id") == completed_task_id
            ),
            None
        )

        if completed_task is None:
            return {
                "success": False,
                "reason": "No encontré la tarea completada.",
                "updated_tasks": []
            }

        outputs = completed_task.get("outputs", {})

        if not isinstance(outputs, dict):
            outputs = {}

        result = completed_task.get("result")

        if isinstance(result, dict):
            result_outputs = result.get("outputs", {})
            if isinstance(result_outputs, dict):
                outputs = {**outputs, **result_outputs}

        updated_tasks = []

        for task in plan.get("tasks", []):
            if task.get("id") == completed_task_id:
                continue

            if completed_task_id not in task.get("depends_on", []):
                continue

            task_inputs = task.get("inputs")

            if not isinstance(task_inputs, dict):
                task_inputs = {}
                task["inputs"] = task_inputs

            task_inputs.update(outputs)

            updated_tasks.append(dict(task))

        return {
            "success": True,
            "updated_tasks": updated_tasks
        }

    def transfer_task_outputs(self, plan, completed_task_id):
        if not plan:
            return {
                "success": False,
                "reason": "No se proporcionó un plan.",
                "updated_tasks": []
            }

        completed_task = None

        for task in plan.get("tasks", []):
            if task.get("id") == completed_task_id:
                completed_task = task
                break

        if completed_task is None:
            return {
                "success": False,
                "reason": "No encontré la tarea completada.",
                "updated_tasks": []
            }

        outputs = completed_task.get("outputs", {})
        updated_tasks = []

        for task in plan.get("tasks", []):
            if completed_task_id in task.get("depends_on", []):
                inputs = task.setdefault("inputs", {})
                inputs.update(outputs)

                updated_tasks.append({
                    "id": task.get("id"),
                    "inputs": dict(inputs)
                })

        return {
            "success": True,
            "updated_tasks": updated_tasks
        }

    def complete_current_task(self, plan, result=None):
        if not plan:
            return {
                "success": False,
                "reason": "No se proporcionó un plan.",
                "completed": None,
                "next_task": None
            }

        current = next(
            (
                task for task in plan.get("tasks", [])
                if task.get("status") == "running"
            ),
            None
        )

        if current is None:
            return {
                "success": False,
                "reason": "No hay una tarea en ejecución.",
                "completed": None,
                "next_task": None
            }

        completed = self.update_task(
            plan,
            current["id"],
            "completed"
        )["task"]

        if result is not None:
            saved_result = self.set_task_result(
                plan,
                current["id"],
                result
            )

            completed = saved_result["task"]

        propagation = self.propagate_task_outputs(
            plan,
            current["id"]
        )

        next_task = self.start_next_task(plan)

        return {
            "success": True,
            "completed": completed,
            "next_task": (
                next_task["task"]
                if next_task["success"]
                else None
            )
        }

    def start_next_task(self, plan):
        validation = self.validate_dependencies(plan)

        if not validation["valid"]:
            return {
                "success": False,
                "reason": "El plan contiene dependencias inválidas.",
                "errors": validation["errors"],
                "task": None
            }

        if self.has_dependency_cycle(plan):
            return {
                "success": False,
                "reason": "El plan contiene un ciclo de dependencias.",
                "task": None
            }

        task = self.next_task(plan)

        if task is None:
            return {
                "success": False,
                "reason": "No hay tareas pendientes.",
                "task": None
            }

        task_result = self.update_task(
            plan,
            task["id"],
            "running"
        )

        if task_result["success"]:
            for item in plan.get("tasks", []):
                if item.get("id") == task["id"]:
                    item["attempts"] = item.get("attempts", 0) + 1
                    task_result["task"] = dict(item)
                    break

        return task_result

    def evaluate_condition(self, task, plan):
        """
        Evalúa la condición opcional de una tarea.

        Condiciones soportadas:
        - result_success: comprueba el éxito de una dependencia.
        - output_exists: comprueba que exista un output.
        - output_equals: compara un output con un valor esperado.
        """
        condition = task.get("condition")

        if not condition:
            return {
                "success": True,
                "met": True,
                "reason": "La tarea no tiene condición.",
            }

        if not isinstance(condition, dict):
            return {
                "success": False,
                "met": False,
                "reason": "La condición debe ser un diccionario.",
            }

        condition_type = condition.get("type")

        dependencies = task.get("depends_on", [])
        source_task = None

        if dependencies:
            source_id = dependencies[-1]
            source_task = next(
                (
                    item
                    for item in plan.get("tasks", [])
                    if item.get("id") == source_id
                ),
                None,
            )

        if source_task is None:
            return {
                "success": False,
                "met": False,
                "reason": "No se encontró la tarea de la que depende la condición.",
            }

        if condition_type == "result_success":
            expected = condition.get("equals", True)
            actual_result = source_task.get("result")

            if isinstance(actual_result, dict):
                actual = actual_result.get("success", False)
            else:
                actual = False

            return {
                "success": True,
                "met": actual == expected,
                "reason": f"result_success={actual}",
            }

        if condition_type == "output_exists":
            output_name = condition.get("name")

            if not output_name:
                return {
                    "success": False,
                    "met": False,
                    "reason": "Falta el nombre del output.",
                }

            outputs = source_task.get("outputs", {})

            return {
                "success": True,
                "met": output_name in outputs,
                "reason": f"output_exists({output_name})={output_name in outputs}",
            }

        if condition_type == "output_equals":
            output_name = condition.get("name")
            expected = condition.get("equals")

            if not output_name:
                return {
                    "success": False,
                    "met": False,
                    "reason": "Falta el nombre del output.",
                }

            outputs = source_task.get("outputs", {})
            actual = outputs.get(output_name)

            return {
                "success": True,
                "met": actual == expected,
                "reason": f"output_equals({output_name})={actual == expected}",
            }

        return {
            "success": False,
            "met": False,
            "reason": f"Tipo de condición no soportado: {condition_type}",
        }

    def skip_task(self, plan, task_id, reason="Condición no cumplida."):
        """
        Marca una tarea como omitida sin considerarla un fallo.
        """
        if not plan:
            return {
                "success": False,
                "reason": "No se proporcionó un plan.",
                "task": None,
            }

        for task in plan.get("tasks", []):
            if task.get("id") == task_id:
                if task.get("status") != "pending":
                    return {
                        "success": False,
                        "reason": "Solo se pueden omitir tareas pendientes.",
                        "task": None,
                    }

                task["status"] = "skipped"
                task["result"] = {
                    "success": True,
                    "skipped": True,
                    "reason": reason,
                }

                return {
                    "success": True,
                    "task": dict(task),
                }

        return {
            "success": False,
            "reason": "No encontré esa tarea.",
            "task": None,
        }

    def plan_status(self, plan):
        if not plan:
            return "pending"

        tasks = plan.get("tasks", [])

        if not tasks:
            return "pending"

        if any(
            task.get("status") == "failed"
            and int(task.get("attempts", 0)) >= int(task.get("max_attempts", 3))
            for task in tasks
        ):
            return "failed"

        if any(
            task.get("status") == "running"
            for task in tasks
        ):
            return "running"

        if all(
            task.get("status") in {"completed", "skipped"}
            for task in tasks
        ):
            return "completed"

        return "pending"
    def pass_task_result(self, plan, source_task_id, target_task_id):
        if not plan:
            return {
                "success": False,
                "reason": "No se proporcionó un plan.",
                "task": None
            }

        tasks = plan.get("tasks", [])

        source = next(
            (
                task for task in tasks
                if task.get("id") == source_task_id
            ),
            None
        )

        target = next(
            (
                task for task in tasks
                if task.get("id") == target_task_id
            ),
            None
        )

        if source is None:
            return {
                "success": False,
                "reason": "No encontré la tarea de origen.",
                "task": None
            }

        if target is None:
            return {
                "success": False,
                "reason": "No encontré la tarea de destino.",
                "task": None
            }

        target["inputs"]["from_task"] = {
            "task_id": source["id"],
            "result": source.get("result")
        }

        return {
            "success": True,
            "task": dict(target)
        }

    def set_task_context(self, plan, task_id, context):
        if not plan:
            return {
                "success": False,
                "reason": "No se proporcionó un plan.",
                "task": None
            }

        if not isinstance(context, dict):
            return {
                "success": False,
                "reason": "El contexto debe ser un diccionario.",
                "task": None
            }

        for task in plan.get("tasks", []):
            if task.get("id") == task_id:
                task["context"] = dict(context)
                return {
                    "success": True,
                    "task": dict(task)
                }

        return {
            "success": False,
            "reason": "No encontré esa tarea.",
            "task": None
        }

    def set_task_outputs(self, plan, task_id, outputs):
        if not plan:
            return {
                "success": False,
                "reason": "No se proporcionó un plan.",
                "task": None
            }

        if not isinstance(outputs, dict):
            return {
                "success": False,
                "reason": "Los outputs deben ser un diccionario.",
                "task": None
            }

        for task in plan.get("tasks", []):
            if task.get("id") == task_id:
                task["outputs"] = dict(outputs)
                return {
                    "success": True,
                    "task": dict(task)
                }

        return {
            "success": False,
            "reason": "No encontré esa tarea.",
            "task": None
        }

    def set_task_inputs(self, plan, task_id, inputs):
        if not plan:
            return {
                "success": False,
                "reason": "No se proporcionó un plan.",
                "task": None
            }

        if not isinstance(inputs, dict):
            return {
                "success": False,
                "reason": "Los inputs deben ser un diccionario.",
                "task": None
            }

        for task in plan.get("tasks", []):
            if task.get("id") == task_id:
                task["inputs"] = dict(inputs)
                return {
                    "success": True,
                    "task": dict(task)
                }

        return {
            "success": False,
            "reason": "No encontré esa tarea.",
            "task": None
        }

    def set_task_result(self, plan, task_id, result):
        if not plan:
            return {
                "success": False,
                "reason": "No se proporcionó un plan.",
                "task": None
            }

        for task in plan.get("tasks", []):
            if task.get("id") == task_id:
                task["result"] = result

                return {
                    "success": True,
                    "task": dict(task)
                }

        return {
            "success": False,
            "reason": "No encontré esa tarea.",
            "task": None
        }

    def retry_task(self, plan, task_id):
        if not plan:
            return {
                "success": False,
                "reason": "No se proporcionó un plan.",
                "task": None
            }

        if not self.can_retry(plan, task_id):
            return {
                "success": False,
                "reason": "La tarea alcanzó el máximo de intentos.",
                "task": None
            }

        for task in plan.get("tasks", []):
            if task.get("id") == task_id:
                task["attempts"] = int(task.get("attempts", 0)) + 1
                task["status"] = "pending"
                task.pop("error", None)

                return {
                    "success": True,
                    "task": dict(task)
                }

        return {
            "success": False,
            "reason": "No encontré esa tarea.",
            "task": None
        }

    def fail_task(self, plan, task_id, reason=""):
        if not plan:
            return {
                "success": False,
                "reason": "No se proporcionó un plan.",
                "task": None,
                "retry": False
            }

        for task in plan.get("tasks", []):
            if task.get("id") == task_id:
                task["status"] = "failed"
                task["error"] = str(reason)

                retry = self.can_retry(plan, task_id)

                return {
                    "success": True,
                    "task": dict(task),
                    "retry": retry
                }

        return {
            "success": False,
            "reason": "No encontré esa tarea.",
            "task": None,
            "retry": False
        }

    def can_retry(self, plan, task_id):
        if not plan:
            return False

        for task in plan.get("tasks", []):
            if task.get("id") == task_id:
                attempts = int(task.get("attempts", 0))
                max_attempts = int(task.get("max_attempts", 3))

                return attempts < max_attempts

        return False

    def validate_dependencies(self, plan):
        if not plan:
            return {
                "valid": False,
                "errors": ["No se proporcionó un plan."]
            }

        tasks = plan.get("tasks", [])
        task_ids = {task.get("id") for task in tasks}
        errors = []

        for task in tasks:
            for dependency_id in task.get("depends_on", []):
                if dependency_id not in task_ids:
                    errors.append(
                        f"La tarea {task.get('id')} depende de "
                        f"una tarea inexistente: {dependency_id}."
                    )

                if dependency_id == task.get("id"):
                    errors.append(
                        f"La tarea {task.get('id')} no puede depender de sí misma."
                    )

        return {
            "valid": len(errors) == 0,
            "errors": errors
        }


    def has_dependency_cycle(self, plan):
        if not plan:
            return False

        tasks = {
            task.get("id"): task
            for task in plan.get("tasks", [])
        }

        visiting = set()
        visited = set()

        def visit(task_id):
            if task_id in visiting:
                return True

            if task_id in visited:
                return False

            task = tasks.get(task_id)

            if task is None:
                return False

            visiting.add(task_id)

            for dependency_id in task.get("depends_on", []):
                if visit(dependency_id):
                    return True

            visiting.remove(task_id)
            visited.add(task_id)

            return False

        return any(
            visit(task_id)
            for task_id in tasks
        )

    def next_task(self, plan):
        if not plan:
            return None

        tasks = plan.get("tasks", [])

        available = []

        for task in tasks:
            if task.get("status") != "pending":
                continue

            dependencies = task.get("depends_on", [])

            dependencies_completed = all(
                any(
                    other.get("id") == dependency_id
                    and other.get("status") == "completed"
                    for other in tasks
                )
                for dependency_id in dependencies
            )

            if dependencies_completed:
                condition_result = self.evaluate_condition(task, plan)

                if condition_result.get("success") and condition_result.get("met"):
                    available.append(task)

                elif condition_result.get("success") and not condition_result.get("met"):
                    self.skip_task(
                        plan,
                        task["id"],
                        condition_result.get(
                            "reason",
                            "Condición no cumplida."
                        )
                    )

        if not available:
            return None

        selected = max(
            available,
            key=lambda task: (
                int(task.get("priority", 0)),
                -int(task.get("id", 0))
            )
        )

        return dict(selected)

    def update_task_context(self, plan, task_id, context=None, inputs=None, outputs=None):
        if not plan:
            return {
                "success": False,
                "reason": "No se proporcionó un plan.",
                "task": None
            }

        for task in plan.get("tasks", []):
            if task.get("id") == task_id:
                if context is not None:
                    if not isinstance(context, dict):
                        return {
                            "success": False,
                            "reason": "El contexto debe ser un diccionario.",
                            "task": None
                        }
                    task["context"] = dict(context)

                if inputs is not None:
                    if not isinstance(inputs, dict):
                        return {
                            "success": False,
                            "reason": "Los inputs deben ser un diccionario.",
                            "task": None
                        }
                    task["inputs"] = dict(inputs)

                if outputs is not None:
                    if not isinstance(outputs, dict):
                        return {
                            "success": False,
                            "reason": "Los outputs deben ser un diccionario.",
                            "task": None
                        }
                    task["outputs"] = dict(outputs)

                return {
                    "success": True,
                    "task": dict(task)
                }

        return {
            "success": False,
            "reason": "No encontré esa tarea.",
            "task": None
        }

    def update_task_priority(self, plan, task_id, priority):
        if not plan:
            return {
                "success": False,
                "reason": "No se proporcionó un plan.",
                "task": None
            }

        try:
            priority = int(priority)
        except (TypeError, ValueError):
            return {
                "success": False,
                "reason": "La prioridad debe ser un número entero.",
                "task": None
            }

        for task in plan.get("tasks", []):
            if task.get("id") == task_id:
                task["priority"] = priority

                return {
                    "success": True,
                    "task": dict(task)
                }

        return {
            "success": False,
            "reason": "No encontré esa tarea.",
            "task": None
        }

    def update_task(self, plan, task_id, status):
        valid_statuses = {
            "pending",
            "running",
            "completed",
            "failed",
            "skipped"
        }

        if not plan:
            return {
                "success": False,
                "reason": "No se proporcionó un plan."
            }

        if status not in valid_statuses:
            return {
                "success": False,
                "reason": "Estado de tarea no válido."
            }

        for task in plan.get("tasks", []):
            if task.get("id") == task_id:
                task["status"] = status

                return {
                    "success": True,
                    "task": dict(task)
                }

        return {
            "success": False,
            "reason": "No encontré esa tarea."
        }

    def add_task(self, plan, description, priority=0):
        if not plan or not description:
            return {
                "success": False,
                "reason": "Se necesita un plan y una descripción de tarea.",
                "plan": plan
            }

        try:
            priority = int(priority)
        except (TypeError, ValueError):
            return {
                "success": False,
                "reason": "La prioridad debe ser un número entero.",
                "plan": plan
            }

        task = {
            "id": len(plan["tasks"]) + 1,
            "description": description,
            "priority": priority,
            "status": "pending",
            "depends_on": [],
            "inputs": {},
            "outputs": {},
            "context": {},
            "condition": None,
            "attempts": 0,
            "max_attempts": 3,
            "result": None
        }

        plan["tasks"].append(task)

        return {
            "success": True,
            "task": task,
            "plan": plan
        }
