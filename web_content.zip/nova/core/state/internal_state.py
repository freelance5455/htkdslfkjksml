import json
from pathlib import Path
from datetime import datetime, timezone
from core.affect.affective_state import AffectiveState


class InternalState:
    def __init__(self, path="core/state/state.json"):
        self.path = Path(path)

        self.data = {
            "version": 1,
            "created_at": self._now(),
            "updated_at": self._now(),
            "cycle": 0,
            "status": "idle",
            "current_goal": None,
            "current_task": None,
            "confidence": 0.0,
            "affect": {
                "valence": 0.0,
                "arousal": 0.0,
                "stability": 1.0
            },
            "last_input": None,
            "last_output": None,
            "last_result": None
        }

        self.load()
        affect_data = self.data.get("affect", {})
        self.affect = AffectiveState(
            valence=affect_data.get("valence", 0.0),
            arousal=affect_data.get("arousal", 0.0),
            stability=affect_data.get("stability", 1.0)
        )

    def _now(self):
        return datetime.now(timezone.utc).isoformat()

    def load(self):
        if self.path.exists():
            try:
                saved = json.loads(self.path.read_text(encoding="utf-8"))
                self.data.update(saved)
            except (json.JSONDecodeError, OSError):
                pass

    def save(self):
        self.data["affect"] = self.affect.snapshot()
        self.data["updated_at"] = self._now()
        self.path.parent.mkdir(parents=True, exist_ok=True)

        temp = self.path.with_suffix(".tmp")
        temp.write_text(
            json.dumps(self.data, ensure_ascii=False, indent=2),
            encoding="utf-8"
        )
        temp.replace(self.path)

    def update(self, **values):
        self.data.update(values)
        if "confidence" in self.data:
            self.data["confidence"] = round(float(self.data["confidence"]), 2)
        self.save()

    def next_cycle(self):
        self.data["cycle"] += 1
        self.save()
        return self.data["cycle"]

    def set_goal(self, goal):
        self.data["current_goal"] = goal
        self.save()

    def set_task(self, task):
        self.data["current_task"] = task
        self.save()

    def set_status(self, status):
        self.data["status"] = status
        self.save()

    def set_context(self, context):
        self.data["context"] = context
        self.save()

    def set_result(self, result):
        self.data["last_result"] = result
        self.save()

    def set_error(self, error):
        self.data["last_result"] = {
            "success": False,
            "type": "error",
            "message": str(error)
        }
        self.save()

    def cognitive_summary(self):
        return {
            "cycle": self.data["cycle"],
            "status": self.data["status"],
            "goal": self.data["current_goal"],
            "task": self.data["current_task"],
            "confidence": self.data["confidence"],
            "affect": self.affect.snapshot(),
            "last_result": self.data["last_result"]
        }

    def snapshot(self):
        return dict(self.data)
