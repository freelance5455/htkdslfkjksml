
from datetime import datetime, timezone
from pathlib import Path
import json

class AutonomousLoop:
    """Ciclo persistente de agencia: observa objetivos, propone acciones y registra resultados.
    No ejecuta acciones sensibles sin pasar por el sistema normal de permisos.
    """
    def __init__(self, runtime, path="core/state/autonomous_loop.json"):
        self.runtime=runtime; self.path=Path(path); self.state={"enabled":False,"ticks":0,"last_tick":None,"history":[]}; self.load()
    def _now(self): return datetime.now(timezone.utc).isoformat()
    def load(self):
        try:
            if self.path.exists(): self.state=json.loads(self.path.read_text(encoding="utf8"))
        except (OSError,json.JSONDecodeError): pass
    def save(self):
        self.path.parent.mkdir(parents=True,exist_ok=True)
        tmp=self.path.with_suffix(".tmp"); tmp.write_text(json.dumps(self.state,ensure_ascii=False,indent=2),encoding="utf8"); tmp.replace(self.path)
    def enable(self): self.state["enabled"]=True; self.save(); return self.status()
    def disable(self): self.state["enabled"]=False; self.save(); return self.status()
    def tick(self, execute=False):
        goal=self.runtime.goals.next_active()
        initiative=self.runtime.initiative.evaluate()
        item={"timestamp":self._now(),"goal":goal,"initiative":initiative,"executed":False}
        if execute and goal:
            # Only run through the ordinary orchestrator, which retains permission boundaries.
            result=self.runtime.execute_command(goal["name"])
            item["executed"]=True; item["result"]=result
        self.state["ticks"]=int(self.state.get("ticks",0))+1
        self.state["last_tick"]=item["timestamp"]
        self.state.setdefault("history",[]).append(item)
        self.state["history"]=self.state["history"][-100:]
        self.save()
        return {"success":True,"tick":item,"status":self.status()}
    def status(self):
        return {"enabled":bool(self.state.get("enabled")),"ticks":self.state.get("ticks",0),
                "last_tick":self.state.get("last_tick"),"history":self.state.get("history",[])[-5:]}
