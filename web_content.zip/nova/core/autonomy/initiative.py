from datetime import datetime, timezone

class InitiativeEngine:
    """Iniciativa controlada: propone acciones a partir de objetivos, nunca ejecuta por sí sola acciones sensibles."""
    def __init__(self, goals=None):
        self.goals=goals
    def candidates(self):
        if not self.goals: return []
        out=[]
        for g in self.goals.active():
            out.append({"goal_id":g.get("id"),"goal":g.get("name"),"reason":"objetivo activo",
                        "safe":True,"requires_confirmation":False})
        return out
    def evaluate(self):
        c=self.candidates()
        return {"timestamp":datetime.now(timezone.utc).isoformat(),"candidates":c,
                "recommended":c[:3],"execution_policy":"propose_then_authorize"}
