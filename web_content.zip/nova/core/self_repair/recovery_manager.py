from pathlib import Path


class RecoveryManager:
    """Restaura un proyecto desde un backup sin sobrescribir destinos."""

    def recover(self, backup=None, destination=None):
        if not isinstance(backup, (str, Path)) or not str(backup).strip():
            return {
                "success": False,
                "recovered": False,
                "error": "Falta el backup de recuperación.",
            }

        if not isinstance(destination, (str, Path)) or not str(destination).strip():
            return {
                "success": False,
                "recovered": False,
                "backup": str(backup),
                "error": "Falta el destino de recuperación.",
            }

        from core.runtime.advanced_tool_handlers import restore_project_tool

        result = restore_project_tool(str(backup), str(destination))
        success = bool(result.get("success", False))

        return {
            "success": success,
            "recovered": success,
            "backup": str(backup),
            "destination": str(destination),
            "result": result,
            "message": (
                "Proyecto recuperado correctamente desde el backup."
                if success
                else result.get("error", "No se pudo recuperar el proyecto.")
            ),
        }
