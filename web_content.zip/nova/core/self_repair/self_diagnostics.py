class SelfDiagnostics:
    """Detecta fallos y determina dónde ocurrieron."""

    def diagnose(self, result):
        if not isinstance(result, dict):
            return {
                "success": False,
                "stage": "unknown",
                "error": "Resultado inválido.",
            }

        return {
            "success": True,
            "failed": not bool(result.get("success", False)),
            "stage": result.get("stage", "unknown"),
            "error": result.get("error"),
        }
