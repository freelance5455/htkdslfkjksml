from pathlib import Path
import tempfile
from core.self_repair.self_diagnostics import SelfDiagnostics
from core.self_repair.retry_manager import RetryManager
from core.self_repair.repair_verifier import RepairVerifier
from core.self_repair.recovery_manager import RecoveryManager
from core.runtime.advanced_tool_handlers import backup_project_tool

def test_diagnostics():
    result = SelfDiagnostics().diagnose({"success": False, "stage": "tests"})
    assert result["success"] is True
    assert result["failed"] is True

def test_retry_manager():
    manager = RetryManager(3)
    assert manager.should_retry(0) is True
    assert manager.should_retry(3) is False

def test_repair_verifier():
    result = RepairVerifier().verify({"success": True})
    assert result["success"] is True
    assert result["verified"] is True

def test_recovery_manager():
    with tempfile.TemporaryDirectory(dir=str(Path("projects").resolve())) as tmp:
        root = Path(tmp)
        source = root / "source"
        backup = root / "backup"
        destination = root / "destination"
        source.mkdir()
        (source / "data.txt").write_text("original", encoding="utf-8")
        backup_result = backup_project_tool(str(source), str(backup))
        assert backup_result["success"] is True
        (source / "data.txt").write_text("corrupted", encoding="utf-8")
        recovered = RecoveryManager().recover(str(backup), str(destination))
        assert recovered["success"] is True
        assert recovered["recovered"] is True
        assert (destination / "data.txt").read_text(encoding="utf-8") == "original"

if __name__ == "__main__":
    test_diagnostics()
    test_retry_manager()
    test_repair_verifier()
    test_recovery_manager()
    print("SELF_REPAIR TESTS OK")
