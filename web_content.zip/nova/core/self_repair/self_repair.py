from pathlib import Path
import py_compile
import shutil
import time

class SelfRepair:
    """Diagnóstico y reparación controlada con backup, verificación y rollback."""
    name = "NOVA-SelfRepair"
    version = "2.0"

    PROTECTED = {
        "core/security/security_policy.py",
        "core/security/permission_manager.py",
        "core/security/security_guard.py",
    }

    def __init__(self, root=None):
        self.root = Path(root or ".").resolve()
        self.backup_dir = self.root / "logs" / "self_repair_backups"
        self.backup_dir.mkdir(parents=True, exist_ok=True)

    def _path(self, relative):
        path = (self.root / relative).resolve()
        if path != self.root and self.root not in path.parents:
            raise ValueError("Ruta fuera del proyecto.")
        return path

    def diagnose_python(self, relative):
        try:
            path = self._path(relative)
        except ValueError as exc:
            return {"success": False, "error": str(exc)}
        if not path.exists():
            return {"success": False, "file": relative, "error": "Archivo no encontrado."}
        try:
            py_compile.compile(str(path), doraise=True)
            return {"success": True, "file": relative, "status": "healthy"}
        except Exception as exc:
            return {"success": False, "file": relative, "status": "syntax_error",
                    "error": str(exc), "error_type": type(exc).__name__}

    def diagnose(self, files=None):
        if files is None:
            files = ["core"]
        results = []
        for item in files:
            path = self._path(item)
            if path.is_file() and path.suffix == ".py":
                results.append(self.diagnose_python(item))
            elif path.is_dir():
                for py in sorted(path.rglob("*.py")):
                    rel = str(py.relative_to(self.root))
                    results.append(self.diagnose_python(rel))
        return {
            "success": all(item.get("success") for item in results),
            "checked": len(results), "results": results,
        }

    def backup(self, relative):
        if relative in self.PROTECTED:
            return {"success": False, "error": "Archivo protegido: requiere flujo de seguridad específico."}
        source = self._path(relative)
        if not source.exists():
            return {"success": False, "error": "Archivo no encontrado."}
        stamp = time.strftime("%Y%m%d_%H%M%S")
        destination = self.backup_dir / f"{source.name}.{stamp}.backup"
        shutil.copy2(source, destination)
        return {"success": True, "source": relative, "backup": str(destination)}

    def verify_python(self, relative):
        return self.diagnose_python(relative)

    def apply_text_fix(self, relative, content):
        """Aplica un cambio textual con backup + verificación + rollback automático."""
        if relative in self.PROTECTED:
            return {"success": False, "error": "Archivo protegido: no se modifica desde este endpoint."}
        if not isinstance(content, str):
            return {"success": False, "error": "El contenido del fix debe ser texto."}
        try:
            target = self._path(relative)
        except ValueError as exc:
            return {"success": False, "error": str(exc)}
        if target.suffix != ".py":
            return {"success": False, "error": "El endpoint aplica fixes solo a archivos Python."}
        backup = self.backup(relative)
        if not backup.get("success"):
            return backup
        target.write_text(content, encoding="utf-8")
        verification = self.verify_python(relative)
        if not verification.get("success"):
            self.rollback(backup["backup"], relative)
            return {
                "success": False,
                "repaired": False,
                "rolled_back": True,
                "backup": backup["backup"],
                "verification": verification,
                "error": "El fix introdujo un error y fue revertido automáticamente.",
            }
        return {
            "success": True,
            "repaired": True,
            "rolled_back": False,
            "backup": backup["backup"],
            "verification": verification,
            "file": relative,
        }

    def rollback(self, backup, destination):
        target = self._path(destination)
        if destination in self.PROTECTED:
            return {"success": False, "error": "No se puede revertir directamente un archivo de seguridad."}
        source = Path(backup).resolve()
        if not source.is_file():
            return {"success": False, "error": "Backup no encontrado."}
        if target != self.root and self.root not in target.parents:
            return {"success": False, "error": "Destino fuera del proyecto."}
        shutil.copy2(source, target)
        return {"success": True, "destination": str(target)}

    def status(self):
        return {
            "success": True, "name": self.name, "version": self.version,
            "root": str(self.root), "backup_dir": str(self.backup_dir),
            "protected_files": sorted(self.PROTECTED),
        }
