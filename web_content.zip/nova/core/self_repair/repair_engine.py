class RepairEngine:
    """Gestiona propuestas estructuradas de reparación."""

    def repair(self, failure, strategy=None):
        if not isinstance(failure, dict):
            return {
                "success": False,
                "repaired": False,
                "error": "El diagnóstico de fallo es inválido.",
            }

        diagnosis = failure.get("failure", failure)

        if not isinstance(diagnosis, dict):
            return {
                "success": False,
                "repaired": False,
                "error": "No existe un diagnóstico estructurado.",
            }

        error_type = diagnosis.get("error_type")
        file_path = diagnosis.get("file")
        line = diagnosis.get("line")
        message = diagnosis.get("message")

        if not error_type and not message:
            return {
                "success": False,
                "repaired": False,
                "error": "No se pudo identificar el tipo o mensaje del fallo.",
            }

        selected_strategy = strategy or self._select_strategy(
            error_type,
            message,
        )

        return {
            "success": True,
            "repaired": False,
            "status": "repair_proposed",
            "strategy": selected_strategy,
            "failure": {
                "file": file_path,
                "line": line,
                "error_type": error_type,
                "message": message,
            },
            "proposal": self._build_proposal(
                selected_strategy,
                file_path,
                line,
                error_type,
                message,
            ),
        }

    def _select_strategy(self, error_type, message):
        if error_type == "SyntaxError":
            return "inspect_syntax_error"

        if error_type and error_type.endswith("Error"):
            return "inspect_error"

        return "inspect_failure"

    def _build_proposal(
        self,
        strategy,
        file_path,
        line,
        error_type,
        message,
    ):
        return {
            "action": "analyze_and_prepare_fix",
            "strategy": strategy,
            "file": file_path,
            "line": line,
            "error_type": error_type,
            "message": message,
        }
