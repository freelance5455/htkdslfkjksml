class RetryManager:
    """Controla reintentos limitados."""

    def __init__(self, max_retries=3):
        self.max_retries = max(0, int(max_retries))

    def should_retry(self, attempt):
        return int(attempt) < self.max_retries
