class RepairVerifier:
    """Verifica si una reparación resolvió el fallo."""

    def verify(self, result):
        verified = isinstance(result, dict) and bool(result.get("success", False))
        return {
            "success": True,
            "verified": verified,
            "result": result,
        }
