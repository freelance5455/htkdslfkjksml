from core.runtime.cognitive_runtime import CognitiveRuntime
from core.experience import EpisodicMemory
from core.self_improvement import ImprovementLab

def main():
    rt=CognitiveRuntime()
    result=rt.process("hola N.O.V.A.")
    assert result.get("success") is True
    status=rt.cognitive_status()
    assert "self_model" in status and "recent_experiences" in status
    exp=rt.propose_improvement("test", "mejorar verificación", ["core/cognition/reasoning_engine.py"])
    assert exp["status"]=="proposed"
    blocked=rt.propose_improvement("security", "cambiar seguridad", ["core/security/security_policy.py"])
    assert blocked["protected"] is True
    print("COGNITIVE 3 TEST: OK")
    print("cycle:", status["cognitive_state"]["cycle"])
    print("episodes:", len(status["recent_experiences"]))
if __name__=="__main__": main()
