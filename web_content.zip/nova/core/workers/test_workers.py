import time
from core.workers.worker_manager import WorkerManager


def test_worker_lifecycle():
    manager = WorkerManager(1)
    try:
        queued = manager.dispatch("sum", lambda: 2 + 3)
        assert queued["success"] is True
        task_id = queued["task_id"]
        for _ in range(20):
            status = manager.status(task_id)
            if status.get("status") == "completed":
                break
            time.sleep(0.01)
        assert status["status"] == "completed"
        assert status["result"] == 5
    finally:
        manager.shutdown()


if __name__ == "__main__":
    test_worker_lifecycle()
    print("Worker tests passed.")
