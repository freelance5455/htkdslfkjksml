from core.workers.worker_manager import WorkerManager


def test_worker_cancel_unknown():
    manager = WorkerManager(1)
    try:
        result = manager.cancel("missing")
        assert result["success"] is False
    finally:
        manager.shutdown()


if __name__ == "__main__":
    test_worker_cancel_unknown()
    print("WORKER ADVANCED TESTS OK")
