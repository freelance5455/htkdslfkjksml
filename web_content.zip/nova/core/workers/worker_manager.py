from concurrent.futures import ThreadPoolExecutor
import threading
import uuid


class WorkerManager:
    """Ejecutor local de tareas con estado, cancelación y límites."""

    def __init__(self, max_workers=2, max_tasks=1000):
        self.executor = ThreadPoolExecutor(max_workers=max(1, int(max_workers)))
        self.tasks = {}
        self.max_tasks = max(1, int(max_tasks))
        self.lock = threading.Lock()

    def dispatch(self, task, function=None, *args, **kwargs):
        if function is None or not callable(function):
            return {"success": False, "error": "Falta una función ejecutable."}

        with self.lock:
            if len(self.tasks) >= self.max_tasks:
                return {"success": False, "error": "Límite de tareas alcanzado."}

        task_id = uuid.uuid4().hex[:12]
        record = {"id": task_id, "task": str(task), "status": "queued"}

        def runner():
            with self.lock:
                self.tasks[task_id]["status"] = "running"
            try:
                value = function(*args, **kwargs)
                with self.lock:
                    self.tasks[task_id].update(
                        status="completed",
                        result=value,
                    )
                return value
            except Exception as exc:
                with self.lock:
                    self.tasks[task_id].update(
                        status="failed",
                        error=f"{type(exc).__name__}: {exc}",
                    )
                raise

        with self.lock:
            self.tasks[task_id] = record

        try:
            future = self.executor.submit(runner)
        except Exception as exc:
            with self.lock:
                self.tasks.pop(task_id, None)
            return {"success": False, "error": f"{type(exc).__name__}: {exc}"}

        with self.lock:
            self.tasks[task_id]["future"] = future

        return {"success": True, "task_id": task_id, "status": "queued"}

    def status(self, task_id):
        with self.lock:
            record = self.tasks.get(task_id)
            if record is None:
                return {"success": False, "error": "Tarea no encontrada."}
            return {
                k: v for k, v in record.items()
                if k != "future"
            } | {"success": True}

    def cancel(self, task_id):
        with self.lock:
            record = self.tasks.get(task_id)
            if record is None:
                return {"success": False, "error": "Tarea no encontrada."}
            future = record.get("future")
            if future is None:
                return {"success": False, "error": "La tarea todavía no tiene futuro asociado."}
            cancelled = future.cancel()
            if cancelled:
                record["status"] = "cancelled"
            return {
                "success": cancelled,
                "task_id": task_id,
                "status": record.get("status"),
            }

    def list(self):
        with self.lock:
            return {
                "success": True,
                "tasks": [
                    {k: v for k, v in item.items() if k != "future"}
                    for item in self.tasks.values()
                ],
            }

    def shutdown(self, wait=True):
        self.executor.shutdown(wait=wait)


def run_callable(function, *args, **kwargs):
    manager = WorkerManager(max_workers=1)
    try:
        return manager.dispatch("one-shot", function, *args, **kwargs)
    finally:
        manager.shutdown(wait=False)
