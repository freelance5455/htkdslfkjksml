from core.security.security_policy import SecurityPolicy
from core.security.audit_log import SecurityAuditLog


class SecurityGuard:
    """Comprueba acciones y registra decisiones de seguridad."""

    def __init__(self, policy=None, audit_log=None):
        self.policy = policy or SecurityPolicy()
        self.audit_log = audit_log or SecurityAuditLog()

    def authorize(self, action, context=None):
        result = self.policy.check(action)
        self.audit_log.record(
            action,
            result["allowed"],
            result["reason"],
            context=context,
        )
        return {
            "authorized": result["allowed"],
            "action": result["action"],
            "reason": result["reason"],
        }

    def require(self, action, context=None):
        result = self.authorize(action, context=context)
        if not result["authorized"]:
            raise PermissionError(result["reason"])
        return result
