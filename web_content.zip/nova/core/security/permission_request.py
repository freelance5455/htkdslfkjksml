class PermissionRequest:
    """Representa una solicitud temporal de permiso."""

    def __init__(self, permission, reason="", context=None):
        self.permission = permission
        self.reason = reason
        self.context = context or {}
        self.status = "pending"

    def approve(self):
        if self.status != "pending":
            return {
                "success": False,
                "error": "La solicitud ya fue resuelta.",
            }

        self.status = "approved"

        return {
            "success": True,
            "permission": self.permission,
            "status": self.status,
        }

    def deny(self):
        if self.status != "pending":
            return {
                "success": False,
                "error": "La solicitud ya fue resuelta.",
            }

        self.status = "denied"

        return {
            "success": True,
            "permission": self.permission,
            "status": self.status,
        }

    def consume(self):
        if self.status != "approved":
            return {
                "success": False,
                "error": "La solicitud no está aprobada.",
            }

        self.status = "consumed"

        return {
            "success": True,
            "permission": self.permission,
            "status": self.status,
        }

    def to_dict(self):
        return {
            "permission": self.permission,
            "reason": self.reason,
            "context": self.context,
            "status": self.status,
        }
