class PermissionManager:
    """Gestiona permisos con niveles libres, confirmables e inmutables bloqueados."""

    FREE = "free"
    CONFIRM = "confirm"
    BLOCKED = "blocked"

    DEFAULT_LEVELS = {
        "read_memory": FREE,
        "read_state": FREE,
        "write_memory": FREE,
        "write_state": FREE,
        "execute_tools": FREE,
        "build_capability": CONFIRM,
        "create_projects": FREE,
        "modify_project_files": FREE,
        "network_access": CONFIRM,
        "api_access": CONFIRM,
        "execute_external": CONFIRM,
        "change_permissions": CONFIRM,
        "delete_files": BLOCKED,
        "self_modify": BLOCKED,
        "modify_security": BLOCKED,
    }

    IMMUTABLE_BLOCKED = {
        "delete_files",
        "self_modify",
        "modify_security",
    }

    def __init__(self, levels=None):
        self.levels = dict(self.DEFAULT_LEVELS)
        if levels:
            for name, value in levels.items():
                if name not in self.levels or name in self.IMMUTABLE_BLOCKED:
                    continue
                if value in {self.FREE, self.CONFIRM, self.BLOCKED}:
                    self.levels[name] = value

    def check(self, permission):
        if permission not in self.levels:
            return {
                "allowed": False,
                "requires_confirmation": False,
                "blocked": True,
                "permission": permission,
                "level": self.BLOCKED,
                "reason": "Permiso desconocido.",
            }

        level = self.levels[permission]

        if level == self.FREE:
            return {
                "allowed": True,
                "requires_confirmation": False,
                "blocked": False,
                "permission": permission,
                "level": level,
                "reason": "Acción permitida automáticamente.",
            }

        if level == self.CONFIRM:
            return {
                "allowed": False,
                "requires_confirmation": True,
                "blocked": False,
                "permission": permission,
                "level": level,
                "reason": "Se requiere confirmación del usuario.",
            }

        return {
            "allowed": False,
            "requires_confirmation": False,
            "blocked": True,
            "permission": permission,
            "level": self.BLOCKED,
            "reason": "Acción bloqueada por seguridad.",
        }

    def grant(self, permission):
        if permission not in self.levels:
            return {"success": False, "permission": permission, "error": "Permiso desconocido."}
        if permission in self.IMMUTABLE_BLOCKED:
            return {
                "success": False,
                "permission": permission,
                "error": "El permiso está bloqueado de forma inmutable.",
            }
        self.levels[permission] = self.FREE
        return {"success": True, "permission": permission, "level": self.FREE}

    def revoke(self, permission):
        if permission not in self.levels:
            return {"success": False, "permission": permission, "error": "Permiso desconocido."}
        self.levels[permission] = self.BLOCKED
        return {"success": True, "permission": permission, "level": self.BLOCKED}

    def status(self):
        return dict(self.levels)
