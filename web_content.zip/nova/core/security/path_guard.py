from pathlib import Path


class PathGuard:
    """Controla las rutas que N.O.V.A. puede utilizar."""

    def __init__(self, allowed_roots=None):
        base = Path.cwd().resolve()

        self.allowed_roots = [
            Path(root).resolve()
            for root in (
                allowed_roots
                or [
                    base,
                    base / "projects",
                ]
            )
        ]

    def check(self, path):
        target = Path(path).resolve()

        # El proyecto puede ejecutarse desde una ruta distinta a la usada
        # al importar el módulo. La raíz de trabajo actual debe seguir
        # siendo válida, especialmente para el autoinspector de N.O.V.A.
        roots = list(self.allowed_roots)
        current = Path.cwd().resolve()
        if current not in roots:
            roots.append(current)
        current_projects = current / "projects"
        if current_projects not in roots:
            roots.append(current_projects)

        for root in roots:
            try:
                target.relative_to(root)
                return {
                    "allowed": True,
                    "path": target,
                    "root": root,
                }
            except ValueError:
                continue

        return {
            "allowed": False,
            "path": target,
            "reason": "La ruta está fuera de las zonas permitidas.",
        }
