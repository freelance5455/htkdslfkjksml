class SecurityPolicy:
    """Política básica de seguridad para N.O.V.A."""

    DEFAULT_ALLOWED = {
        "read_state",
        "read_memory",
        "plan",
        "verify",
    }

    DEFAULT_DELEGATED = {
        "network_access",
        "api_access",
        "execute_external",
        "change_permissions",
    }

    DEFAULT_BLOCKED = {
        "self_modify",
        "delete_files",
    }

    def __init__(self, allowed=None, delegated=None, blocked=None):
        self.allowed = set(allowed or self.DEFAULT_ALLOWED)
        self.delegated = set(delegated or self.DEFAULT_DELEGATED)
        self.blocked = set(blocked or self.DEFAULT_BLOCKED)

    def check(self, action):
        if not isinstance(action, str) or not action.strip():
            return {
                "allowed": False,
                "action": action,
                "reason": "Acción inválida.",
            }

        action = action.strip()

        if action in self.blocked:
            return {
                "allowed": False,
                "action": action,
                "reason": "Acción bloqueada por política de seguridad.",
            }

        if action in self.allowed:
            return {
                "allowed": True,
                "action": action,
                "reason": "Acción autorizada por política.",
            }

        if action in self.delegated:
            return {
                "allowed": True,
                "action": action,
                "reason": "Acción delegada al sistema de permisos.",
            }

        return {
            "allowed": False,
            "action": action,
            "reason": "Acción no autorizada por defecto.",
        }
