import json
import threading
from datetime import datetime, timezone
from pathlib import Path


class SecurityAuditLog:
    """Registro local de decisiones de seguridad sin secretos sensibles."""

    SENSITIVE_KEYS = {
        "password", "token", "authorization", "api_key",
        "secret", "cookie", "credential",
    }

    def __init__(self, path="logs/security_audit.jsonl", max_entries=5000):
        self.path = Path(path)
        self.max_entries = max(100, int(max_entries))
        self.lock = threading.Lock()

    def _now(self):
        return datetime.now(timezone.utc).isoformat()

    def _sanitize(self, value):
        if isinstance(value, dict):
            return {
                str(k): (
                    "[REDACTED]"
                    if str(k).lower() in self.SENSITIVE_KEYS
                    else self._sanitize(v)
                )
                for k, v in value.items()
            }
        if isinstance(value, (list, tuple)):
            return [self._sanitize(v) for v in value]
        if isinstance(value, Path):
            return str(value)
        return value

    def record(self, action, allowed, reason="", context=None):
        entry = {
            "timestamp": self._now(),
            "action": str(action),
            "allowed": bool(allowed),
            "reason": str(reason),
            "context": self._sanitize(context or {}),
        }
        self.path.parent.mkdir(parents=True, exist_ok=True)
        line = json.dumps(entry, ensure_ascii=False)

        with self.lock:
            with self.path.open("a", encoding="utf-8") as handle:
                handle.write(line + "\n")

            lines = self.path.read_text(encoding="utf-8").splitlines()
            if len(lines) > self.max_entries:
                self.path.write_text(
                    "\n".join(lines[-self.max_entries:]) + "\n",
                    encoding="utf-8",
                )
        return entry

    def read(self, limit=100):
        limit = max(1, min(int(limit), self.max_entries))
        if not self.path.exists():
            return []
        lines = self.path.read_text(encoding="utf-8").splitlines()
        result = []
        for line in lines[-limit:]:
            try:
                result.append(json.loads(line))
            except json.JSONDecodeError:
                continue
        return result
