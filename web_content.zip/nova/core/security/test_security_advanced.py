from pathlib import Path
import tempfile
from core.security.permission_manager import PermissionManager
from core.security.audit_log import SecurityAuditLog
from core.security.security_guard import SecurityGuard


def test_immutable_blocked_permissions():
    manager = PermissionManager()
    result = manager.grant("self_modify")
    assert result["success"] is False
    assert manager.check("self_modify")["blocked"] is True


def test_confirm_permission():
    manager = PermissionManager()
    result = manager.check("network_access")
    assert result["requires_confirmation"] is True
    assert result["allowed"] is False


def test_audit_redacts_secret():
    with tempfile.TemporaryDirectory() as tmp:
        log = SecurityAuditLog(Path(tmp) / "audit.jsonl")
        guard = SecurityGuard(audit_log=log)
        result = guard.authorize(
            "network_access",
            context={"token": "super-secret", "operation": "test"},
        )
        assert result["authorized"] is True
        entries = log.read()
        assert entries[-1]["context"]["token"] == "[REDACTED]"
        assert entries[-1]["context"]["operation"] == "test"


if __name__ == "__main__":
    test_immutable_blocked_permissions()
    test_confirm_permission()
    test_audit_redacts_secret()
    print("SECURITY ADVANCED TESTS OK")
