from core.security.permission_manager import PermissionManager
from core.security.permission_request import PermissionRequest


class PermissionGuard:
    """Controla acciones libres, delicadas y bloqueadas."""

    def __init__(self, manager=None):
        self.manager = manager or PermissionManager()

    def check(self, permission, reason="", context=None):
        result = self.manager.check(permission)
        result_reason = result.get("reason", "Permiso no especificado.")

        if result.get("allowed", False):
            return {
                "authorized": True,
                "allowed": True,
                "requires_confirmation": False,
                "reason": result_reason,
                "request": None,
                "result": result,
            }

        if result.get("requires_confirmation", False):
            request = PermissionRequest(
                permission=permission,
                reason=reason or result_reason,
                context=context,
            )
            return {
                "authorized": False,
                "allowed": False,
                "requires_confirmation": True,
                "reason": result_reason,
                "request": request,
                "result": result,
            }

        return {
            "authorized": False,
            "allowed": False,
            "requires_confirmation": False,
            "reason": result_reason,
            "request": None,
            "result": result,
        }

    def approve(self, request):
        if not isinstance(request, PermissionRequest):
            return {
                "success": False,
                "error": "Solicitud de permiso inválida.",
            }

        return request.approve()

    def deny(self, request):
        if not isinstance(request, PermissionRequest):
            return {
                "success": False,
                "error": "Solicitud de permiso inválida.",
            }

        return request.deny()
