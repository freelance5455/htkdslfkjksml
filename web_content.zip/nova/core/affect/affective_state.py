class AffectiveState:
    def __init__(self, valence=0.0, arousal=0.0, stability=1.0):
        self.valence = float(valence)
        self.arousal = float(arousal)
        self.stability = float(stability)

    def update(self, valence_delta=0.0, arousal_delta=0.0):
        self.valence = self._clamp(self.valence + valence_delta)
        self.arousal = self._clamp(self.arousal + arousal_delta)

    def _clamp(self, value):
        return max(-1.0, min(1.0, value))

    def label(self):
        if self.valence > 0.5 and self.arousal > 0.3:
            return "positive_high_energy"

        if self.valence > 0.5:
            return "positive_calm"

        if self.valence < -0.5 and self.arousal > 0.3:
            return "negative_high_energy"

        if self.valence < -0.5:
            return "negative_calm"

        return "neutral"

    def snapshot(self):
        return {
            "valence": round(self.valence, 2),
            "arousal": round(self.arousal, 2),
            "stability": round(self.stability, 2),
            "label": self.label()
        }
