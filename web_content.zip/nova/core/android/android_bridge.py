import json
import os
import urllib.error
import urllib.request


class AndroidBridge:
    """Puente estructurado entre el núcleo Python y la app Android."""

    ACTIONS = {
        "start_listening",
        "stop_listening",
        "speak",
        "set_state",
        "command",
    }

    def __init__(self, endpoint=None, timeout=5):
        self.endpoint = endpoint or os.environ.get(
            "NOVA_ANDROID_BRIDGE_URL",
            "http://127.0.0.1:8765/command",
        )
        self.timeout = max(1, int(timeout))

    def command(self, action, **kwargs):
        if action not in self.ACTIONS:
            return {"success": False, "error": "Acción Android no soportada."}
        payload = {"action": action, **kwargs}
        return {
            "success": True,
            "action": action,
            "payload": payload,
            "json": json.dumps(payload, ensure_ascii=False),
        }

    def send(self, action, **kwargs):
        prepared = self.command(action, **kwargs)
        if not prepared.get("success"):
            return prepared

        body = prepared["json"].encode("utf-8")
        request = urllib.request.Request(
            self.endpoint,
            data=body,
            headers={
                "Content-Type": "application/json; charset=utf-8",
                "User-Agent": "NOVA-AndroidBridge/1.0",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                raw = response.read(200_001)
                if len(raw) > 200_000:
                    return {"success": False, "error": "Respuesta Android demasiado grande."}
                decoded = raw.decode("utf-8", errors="replace")
                data = json.loads(decoded)
                return {
                    "success": bool(data.get("success", False)),
                    "transport": "http",
                    "endpoint": self.endpoint,
                    "response": data,
                }
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            return {
                "success": False,
                "transport": "http",
                "endpoint": self.endpoint,
                "error": f"{type(exc).__name__}: {exc}",
            }
        except (json.JSONDecodeError, TypeError) as exc:
            return {
                "success": False,
                "transport": "http",
                "endpoint": self.endpoint,
                "error": f"{type(exc).__name__}: respuesta inválida.",
            }
