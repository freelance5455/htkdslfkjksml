import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


class _BridgeHandler(BaseHTTPRequestHandler):
    server_version = "NOVA-Bridge/1.0"

    def log_message(self, format, *args):
        return

    def do_POST(self):
        if self.path != "/command":
            self.send_error(404)
            return

        length = int(self.headers.get("Content-Length", "0"))
        if length <= 0 or length > 200_000:
            self.send_error(413)
            return

        try:
            payload = json.loads(self.rfile.read(length).decode("utf-8"))
            if not isinstance(payload, dict):
                raise ValueError("El comando debe ser un objeto JSON.")

            handler = getattr(self.server, "command_handler", None)
            if handler is None:
                result = {
                    "success": False,
                    "error": "No hay un manejador de comandos configurado.",
                }
            else:
                result = handler(payload)
                if not isinstance(result, dict):
                    result = {"success": False, "error": "El manejador devolvió un resultado inválido."}
        except Exception as exc:
            result = {
                "success": False,
                "error": f"{type(exc).__name__}: {exc}",
            }

        body = json.dumps(result, ensure_ascii=False).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


class AndroidBridgeServer:
    """Servidor IPC local para conectar Android con el núcleo Python."""

    def __init__(self, host="127.0.0.1", port=8765, command_handler=None):
        self.host = host
        self.port = int(port)
        self.command_handler = command_handler or self.default_handler
        self.server = ThreadingHTTPServer((host, self.port), _BridgeHandler)
        self.server.command_handler = self.command_handler

    @staticmethod
    def default_handler(payload):
        action = payload.get("action")
        if action in {"start_listening", "stop_listening", "speak", "set_state"}:
            return {
                "success": True,
                "action": action,
                "payload": payload,
            }

        if action == "command":
            text = str(payload.get("text", "")).strip()
            if not text:
                return {"success": False, "error": "Falta el comando."}
            runtime = getattr(payload, "_nova_runtime", None)
            # Payloads are plain dicts, so the server stores the singleton runtime instead.
            raise RuntimeError("El servidor debe recibir el runtime persistente.")

        return {"success": False, "error": "Acción Android desconocida."}

    @property
    def address(self):
        return self.server.server_address

    def serve_forever(self):
        self.server.serve_forever()

    def shutdown(self):
        self.server.shutdown()
        self.server.server_close()
