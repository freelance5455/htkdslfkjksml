import json
import threading
import urllib.request
from core.android.android_bridge import AndroidBridge
from core.android.bridge_server import AndroidBridgeServer


def test_command_serialization():
    bridge = AndroidBridge()
    result = bridge.command("speak", text="Hola")
    assert result["success"] is True
    assert json.loads(result["json"])["action"] == "speak"


def test_local_ipc_roundtrip():
    seen = []

    def handler(payload):
        seen.append(payload)
        return {"success": True, "echo": payload}

    server = AndroidBridgeServer(port=0, command_handler=handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        host, port = server.address
        bridge = AndroidBridge(endpoint=f"http://{host}:{port}/command")
        result = bridge.send("command", text="hola nova")
        assert result["success"] is True
        assert seen[0]["text"] == "hola nova"
        assert result["response"]["echo"]["action"] == "command"
    finally:
        server.shutdown()
        thread.join(timeout=2)


if __name__ == "__main__":
    test_command_serialization()
    test_local_ipc_roundtrip()
    print("ANDROID BRIDGE TESTS OK")
