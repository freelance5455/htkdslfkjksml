
from datetime import datetime, timezone

class ExperimentRunner:
    """Ejecuta experimentos de automejora en modo seguro.
    Solo registra y mide; no modifica core/security ni aplica código arbitrario.
    """
    PROTECTED=("core/security/",)
    def __init__(self, lab):
        self.lab=lab
    def run(self, experiment_id, measurements=None, passed=None):
        experiment=next((x for x in self.lab.list() if x.get("id")==experiment_id),None)
        if not experiment:
            return {"success":False,"error":"Experimento no encontrado."}
        if experiment.get("protected"):
            return {"success":False,"error":"El experimento apunta a una zona protegida."}
        metrics=dict(measurements or {})
        if passed is None:
            passed=bool(metrics.get("verification_passed",False))
        result=self.lab.record_result(experiment_id,bool(passed),metrics)
        return {"success":True,"experiment":result,
                "decision":"keep" if passed else "rollback_required",
                "timestamp":datetime.now(timezone.utc).isoformat()}
