import json
from datetime import datetime, timezone
from pathlib import Path
import hashlib

class ImprovementLab:
    """Laboratorio de automejora controlada: experimenta con métricas, no altera seguridad."""
    PROTECTED_PREFIXES=("core/security/",)
    def __init__(self, path="core/state/improvement_lab.json"):
        self.path=Path(path); self.data={"experiments":[]}; self.load()
    def load(self):
        try:
            if self.path.exists(): self.data=json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError,json.JSONDecodeError): self.data={"experiments":[]}
    def save(self):
        self.path.parent.mkdir(parents=True,exist_ok=True)
        tmp=self.path.with_suffix(".tmp"); tmp.write_text(json.dumps(self.data,ensure_ascii=False,indent=2),encoding="utf-8"); tmp.replace(self.path)
    def propose(self,title,hypothesis,targets=None):
        exp={"id":hashlib.sha256(f"{title}{hypothesis}{datetime.now().isoformat()}".encode()).hexdigest()[:12],
             "title":str(title),"hypothesis":str(hypothesis),"targets":list(targets or []),
             "status":"proposed","created_at":datetime.now(timezone.utc).isoformat(),
             "protected":any(str(x).startswith(self.PROTECTED_PREFIXES) for x in (targets or []))}
        self.data["experiments"].append(exp); self.save(); return exp
    def record_result(self,experiment_id,passed,metrics=None):
        for e in self.data["experiments"]:
            if e["id"]==experiment_id:
                e.update(status="passed" if passed else "failed",metrics=dict(metrics or {}),
                         finished_at=datetime.now(timezone.utc).isoformat())
                self.save(); return e
        return None
    def list(self): return list(self.data["experiments"])
