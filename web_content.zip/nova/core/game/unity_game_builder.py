from pathlib import Path

class UnityGameBuilder:
    """Genera lógica base de un juego 3D para un proyecto Unity."""
    def build(self, project="nova_game_3d", title="N.O.V.A. 3D Game"):
        root = Path("projects") / project
        scripts = root / "Assets" / "Scripts"
        scripts.mkdir(parents=True, exist_ok=True)
        safe_title = str(title).replace('"', '')
        code = {}
        code["GameManager.cs"] = (
            'using UnityEngine;\n'
            'public class GameManager : MonoBehaviour {\n'
            f'    public string GameTitle = "{safe_title}";\n'
            '}\n'
        )
        code["PlayerController.cs"] = (
            'using UnityEngine;\n'
            'public class PlayerController : MonoBehaviour {\n'
            '    public float speed = 5f;\n'
            '    void Update() {\n'
            '        float x = Input.GetAxis("Horizontal");\n'
            '        float z = Input.GetAxis("Vertical");\n'
            '        transform.Translate(new Vector3(x, 0, z) * speed * Time.deltaTime);\n'
            '    }\n'
            '}\n'
        )
        code["CameraFollow.cs"] = (
            'using UnityEngine;\n'
            'public class CameraFollow : MonoBehaviour {\n'
            '    public Transform target;\n'
            '    public Vector3 offset = new Vector3(0, 5, -7);\n'
            '    void LateUpdate() {\n'
            '        if (target) transform.position = target.position + offset;\n'
            '    }\n'
            '}\n'
        )
        code["EnemyController.cs"] = (
            'using UnityEngine;\n'
            'public class EnemyController : MonoBehaviour {\n'
            '    public Transform target;\n'
            '    public float speed = 2f;\n'
            '    void Update() {\n'
            '        if (target) transform.position = Vector3.MoveTowards(transform.position, target.position, speed * Time.deltaTime);\n'
            '    }\n'
            '}\n'
        )
        for name, source in code.items():
            (scripts / name).write_text(source, encoding="utf-8")
        (root / "NOVA_GAME_GENERATED.md").write_text(
            f"# {safe_title}\n\nProyecto 3D generado por N.O.V.A.\n",
            encoding="utf-8",
        )
        return {"success": True, "project": str(root), "scripts": sorted(code)}
