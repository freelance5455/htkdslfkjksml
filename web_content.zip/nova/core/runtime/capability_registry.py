import importlib


class CapabilityRegistry:
    """Registro de capacidades disponibles de N.O.V.A."""

    CAPABILITIES = {
        "memory": {"module": "core.memory.learning_memory", "status": "verified"},
        "learning": {"module": "core.learning.learning_engine", "status": "verified"},
        "internal_state": {"module": "core.state.internal_state", "status": "verified"},
        "affect": {"module": "core.affect.affective_state", "status": "verified"},
        "metacognition": {"module": "core.self.metacognition", "status": "verified"},
        "goals": {"module": "core.goals.goal_manager", "status": "verified"},
        "planning": {"module": "core.planner.planner", "status": "verified"},
        "interpreter": {"module": "core.interpreter.intent_interpreter", "status": "verified"},
        "execution": {"module": "core.interpreter.autonomous_executor", "status": "verified"},
        "orchestration": {"module": "core.interpreter.autonomous_orchestrator", "status": "verified"},
        "security": {"module": "core.security", "status": "available"},
        "permissions": {"module": None, "status": "missing"},
        "autonomy": {"module": None, "status": "missing"},
        "apis": {"module": "core.internet.api_client", "status": "integrated"},
        "internet": {"module": "core.internet.internet_client", "status": "integrated"},
        "voice": {"module": "core.voice.voice_pipeline", "status": "integrated"},
        "android": {"module": "core.android.android_bridge", "status": "integrated"},
        "workers": {"module": "core.workers.worker_manager", "status": "integrated"},
        "cloud": {"module": "core.cloud.cloud_client", "status": "integrated"},
    }

    def inspect(self):
        result = {}

        for name, info in self.CAPABILITIES.items():
            module_name = info["module"]
            if module_name is None:
                result[name] = {"available": False, "module": None, "status": info["status"]}
                continue
            try:
                importlib.import_module(module_name)
                result[name] = {
                    "available": True,
                    "module": module_name,
                    "status": info["status"],
                }
            except Exception as exc:
                result[name] = {
                    "available": False,
                    "module": module_name,
                    "error": str(exc),
                }

        return result

    def maturity_summary(self):
        inspected = self.inspect()
        return {
            "verified": [n for n, d in inspected.items() if d.get("status") == "verified"],
            "integrated": [n for n, d in inspected.items() if d.get("status") == "integrated"],
            "available": [n for n, d in inspected.items() if d.get("status") == "available"],
            "missing": [n for n, d in inspected.items() if d.get("status") == "missing"],
        }

    def summary(self):
        inspected = self.inspect()

        available = [
            name for name, data in inspected.items()
            if data["available"]
        ]

        unavailable = [
            name for name, data in inspected.items()
            if not data["available"]
        ]

        return {
            "available": available,
            "unavailable": unavailable,
            "total": len(inspected),
        }
