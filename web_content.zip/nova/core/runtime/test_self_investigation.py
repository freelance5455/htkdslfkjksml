from core.runtime.integration_supervisor import IntegrationSupervisor
from core.runtime.integration_executor import IntegrationExecutor
from core.runtime.supervisor_runner import SupervisorRunner


def test_self_investigation_plan():
    supervisor = IntegrationSupervisor()
    result = supervisor.create_work_plan(
        "Investiga autónomamente por qué el supervisor de N.O.V.A. "
        "clasifica incorrectamente misiones de autoinvestigación como android."
    )

    assert result["success"] is True
    assert result["analysis"]["requested"] == ["self_investigation"]
    assert len(result["plan"]["tasks"]) == 3
    assert all(
        task["context"]["action"] == "investigate"
        for task in result["plan"]["tasks"]
    )


def test_self_investigation_executor_reads_project():
    task = {
        "context": {
            "capability": "self_investigation",
            "action": "investigate",
            "tool": "read_relevant_files",
            "project": "NOVA",
        }
    }

    result = IntegrationExecutor().execute(task)

    assert result["success"] is True
    assert result["tool"] == "read_relevant_files"
    assert result["result"]["success"] is True
    assert len(result["result"]["files"]) == 3


def test_supervisor_runs_self_investigation():
    result = SupervisorRunner().run(
        "Investiga autónomamente por qué el supervisor de N.O.V.A. "
        "clasifica incorrectamente misiones de autoinvestigación como android."
    )

    assert result["success"] is True
    assert result["total"] == 3
    assert result["completed"] == 3
    assert len(result["results"]) == 3
    assert all(
        item["result"]["success"]
        for item in result["results"]
    )


if __name__ == "__main__":
    test_self_investigation_plan()
    test_self_investigation_executor_reads_project()
    test_supervisor_runs_self_investigation()
    print("SELF_INVESTIGATION TESTS OK")
