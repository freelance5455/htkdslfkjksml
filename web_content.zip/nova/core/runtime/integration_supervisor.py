from core.runtime.capability_registry import CapabilityRegistry
from core.goals.goal_manager import GoalManager
from core.planner.planner import Planner


class IntegrationSupervisor:
    """Analiza órdenes de integración y crea planes de trabajo."""

    CAPABILITY_ALIASES = {
        "memoria": "memory",
        "aprendizaje": "learning",
        "estado interno": "internal_state",
        "estado": "internal_state",
        "afecto": "affect",
        "afecto computacional": "affect",
        "metacognición": "metacognition",
        "autorreferencia": "metacognition",
        "seguridad": "security",
        "permisos": "permissions",
        "autonomía": "autonomy",
        "internet": "internet",
        "api": "apis",
        "apis": "apis",
        "autoinvestigación": "self_investigation",
        "autoinvestigacion": "self_investigation",
        "investigación autónoma": "self_investigation",
        "investigacion autonoma": "self_investigation",
        "investiga autónomamente": "self_investigation",
        "investiga autonomamente": "self_investigation",
        "investiga tu propio código": "self_investigation",
        "investiga tu propio codigo": "self_investigation",
        "investiga tu propio proyecto": "self_investigation",
        "analiza tu propio código": "self_investigation",
        "analiza tu propio codigo": "self_investigation",
        "analiza tu propio proyecto": "self_investigation",
        "diagnóstico autónomo": "self_investigation",
        "diagnostico autonomo": "self_investigation",
    }

    def __init__(self, registry=None, goal_manager=None):
        self.registry = registry or CapabilityRegistry()
        self.goal_manager = goal_manager or GoalManager()

    def analyze(self, instruction):
        if not isinstance(instruction, str):
            return {
                "success": False,
                "error": "La orden debe ser texto.",
            }

        text = instruction.lower().strip()

        if not text:
            return {
                "success": False,
                "error": "La orden está vacía.",
            }

        requested = []

        # La autoinvestigación es una capacidad transversal del supervisor:
        # no depende de que exista una capacidad registrada como módulo.
        # Se detecta primero para evitar que una palabra secundaria como
        # "android", "voz" o "api" desvíe una misión de investigación.
        self_investigation_markers = (
            "autoinvestigación",
            "autoinvestigacion",
            "investigación autónoma",
            "investigacion autonoma",
            "investiga autónomamente",
            "investiga autonomamente",
            "investiga tu propio código",
            "investiga tu propio codigo",
            "investiga tu propio proyecto",
            "analiza tu propio código",
            "analiza tu propio codigo",
            "analiza tu propio proyecto",
            "diagnóstico autónomo",
            "diagnostico autonomo",
        )

        if any(marker in text for marker in self_investigation_markers):
            requested.append("self_investigation")
        else:
            for phrase, capability in self.CAPABILITY_ALIASES.items():
                if phrase in text and capability not in requested:
                    requested.append(capability)

        available = self.registry.summary()["available"]

        plan = []

        for capability in requested:
            if capability == "self_investigation":
                plan.append({
                    "capability": capability,
                    "status": "available",
                    "action": "investigate",
                })
                continue

            plan.append({
                "capability": capability,
                "status": (
                    "available"
                    if capability in available
                    else "missing"
                ),
                "action": (
                    "integrate"
                    if capability in available
                    else "build"
                ),
            })

        return {
            "success": True,
            "instruction": instruction,
            "requested": requested,
            "plan": plan,
        }

    def create_work_plan(self, instruction):
        analysis = self.analyze(instruction)

        if not analysis["success"]:
            return analysis

        goal = self.goal_manager.create(
            "Construir Núcleo de Vida Controlada",
            priority=10,
        )

        planner = Planner(self.goal_manager.all())

        plan_result = planner.create_plan(goal)

        if not plan_result.get("success"):
            return {
                "success": False,
                "stage": "planning",
                "error": plan_result,
            }

        plan = plan_result

        for item in analysis["plan"]:
            action = item["action"]

            if item["capability"] == "self_investigation":
                investigation_tasks = [
                    (
                        "inspect_project",
                        "Inspeccionar la estructura completa del propio proyecto.",
                    ),
                    (
                        "analyze_codebase",
                        "Analizar la composición del código del propio proyecto.",
                    ),
                    (
                        "read_relevant_files",
                        "Leer los archivos del supervisor, ejecutor y registro de capacidades.",
                    ),
                ]
            else:
                investigation_tasks = [
                    (
                        None,
                        f"{action.capitalize()} capacidad: {item['capability']}",
                    )
                ]

            for tool_name, purpose in investigation_tasks:
                description = purpose

                task_result = planner.add_task(
                    plan,
                    description,
                    priority=5,
                )

                if not task_result.get("success"):
                    return {
                        "success": False,
                        "stage": "task_creation",
                        "error": task_result,
                    }

                task = task_result["task"]

                task["context"] = {
                    "capability": item["capability"],
                    "status": item["status"],
                    "action": item["action"],
                    "tool": tool_name,
                    "project": "NOVA",
                    "instruction": instruction,
                }

        return {
            "success": True,
            "analysis": analysis,
            "goal": goal,
            "plan": plan,
            "plan_status": planner.plan_status(plan),
        }
