from core.runtime.integration_supervisor import IntegrationSupervisor
from core.runtime.integration_executor import IntegrationExecutor
from core.security.security_guard import SecurityGuard
from core.security.permission_guard import PermissionGuard


class SupervisorRunner:
    """Ejecuta planes de N.O.V.A. con seguridad y permisos controlados."""

    def __init__(
        self,
        supervisor=None,
        executor=None,
        security_guard=None,
        permission_guard=None,
    ):
        self.supervisor = supervisor or IntegrationSupervisor()
        self.executor = executor or IntegrationExecutor()
        self.security_guard = security_guard or SecurityGuard()
        self.permission_guard = permission_guard or PermissionGuard()

    def approve_and_resume(self, request, task):
        """Aprueba una solicitud puntual y ejecuta la tarea asociada."""
        if request is None:
            return {
                "success": False,
                "message": "No existe una solicitud de permiso."
            }

        approval = self.permission_guard.approve(request)

        if not approval.get("success"):
            return {
                "success": False,
                "message": approval.get("message", "No se pudo aprobar el permiso.")
            }

        if request.status != "approved":
            return {
                "success": False,
                "message": "La solicitud no quedó aprobada."
            }

        result = self.executor.execute(task)

        if result.get("success"):
            request.consume()

        return {
            "success": result.get("success", False),
            "approved": True,
            "consumed": request.status == "consumed",
            "task_id": task.get("id"),
            "capability": task.get("context", {}).get("capability"),
            "result": result,
        }

    def run(self, instruction):
        work = self.supervisor.create_work_plan(instruction)

        if not work.get("success"):
            return work

        plan = work["plan"]
        results = []

        for task in plan.get("tasks", []):
            action = task.get("context", {}).get("action", "")
            security_action = {
                "integrate": "verify",
                "build": "execute_external",
                # La investigación autónoma es de solo lectura.
                "investigate": "verify",
            }.get(action, action)

            security = self.security_guard.authorize(security_action)

            if not security["authorized"]:
                result = {
                    "success": False,
                    "blocked_by_security": True,
                    "capability": task.get("context", {}).get("capability"),
                    "action": action,
                    "message": security["reason"],
                }
            else:
                permission_action = {
                    "integrate": "execute_tools",
                    "build": "build_capability",
                    # La investigación usa únicamente herramientas de lectura.
                    "investigate": "execute_tools",
                }.get(action, action)

                permission = self.permission_guard.check(
                    permission_action,
                    reason=f"La tarea requiere: {action}.",
                    context={
                        "task_id": task.get("id"),
                        "capability": task.get("context", {}).get(
                            "capability"
                        ),
                    },
                )

                if permission["requires_confirmation"]:
                    result = {
                        "success": False,
                        "requires_confirmation": True,
                        "permission_request": (
                            permission["request"].to_dict()
                        ),
                        "capability": task.get("context", {}).get(
                            "capability"
                        ),
                        "action": action,
                        "message": permission["result"]["reason"],
                    }
                elif permission["result"].get("blocked", False):
                    result = {
                        "success": False,
                        "blocked_by_permission": True,
                        "capability": task.get("context", {}).get(
                            "capability"
                        ),
                        "action": action,
                        "message": permission["result"]["reason"],
                    }
                else:
                    result = self.executor.execute(task)

            results.append({
                "task_id": task.get("id"),
                "description": task.get("description"),
                "result": result,
            })

        completed = sum(
            1
            for item in results
            if item["result"].get("success")
        )

        total = len(results)

        # El supervisor no debe reportar éxito si alguna tarea falló.
        # "success=True" significa que la misión completa terminó
        # correctamente, no solo que el plan pudo ejecutarse.
        mission_success = bool(total) and completed == total

        return {
            "success": mission_success,
            "instruction": instruction,
            "goal": work["goal"],
            "plan": plan,
            "results": results,
            "completed": completed,
            "total": total,
            "progress": (
                round((completed / total) * 100, 2)
                if total
                else 0
            ),
        }
