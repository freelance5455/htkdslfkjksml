from pathlib import Path
import json
import shutil
import subprocess
import urllib.request

from core.security.path_guard import PathGuard
from core.security.security_guard import SecurityGuard
from core.security.permission_guard import PermissionGuard


PATH_GUARD = PathGuard()
SECURITY_GUARD = SecurityGuard()
PERMISSION_GUARD = PermissionGuard()

from core.workers.worker_manager import WorkerManager
WORKER_MANAGER = WorkerManager(max_workers=2)

from core.voice.voice_control import VoiceControl
VOICE_CONTROL = VoiceControl()


def execute_command_tool(command, timeout=60):
    security = SECURITY_GUARD.authorize("execute_external")
    if not security["authorized"]:
        return {"success": False, "error": security["reason"]}

    permission = PERMISSION_GUARD.check("execute_external")
    if not permission["authorized"]:
        if permission["requires_confirmation"]:
            return {
                "success": False,
                "requires_confirmation": True,
                "error": "Se requiere confirmación para ejecutar comandos externos.",
            }
        return {"success": False, "error": "Permiso no autorizado."}

    if not isinstance(command, str) or not command.strip():
        return {"success": False, "error": "Falta el comando."}

    try:
        result = subprocess.run(
            command,
            shell=True,
            cwd=".",
            capture_output=True,
            text=True,
            timeout=int(timeout),
        )
        return {
            "success": result.returncode == 0,
            "returncode": result.returncode,
            "stdout": result.stdout,
            "stderr": result.stderr,
        }
    except Exception as exc:
        return {"success": False, "error": f"{type(exc).__name__}: {exc}"}


def build_project_tool(project):
    compile_result = _call_project_compile(project)
    if not compile_result.get("success"):
        return compile_result

    test_result = _call_project_tests(project)
    return {
        "success": bool(test_result.get("success")),
        "project": project,
        "compile": compile_result,
        "tests": test_result,
    }


def debug_project_tool(project):
    inspection = _call_project_inspect(project)
    tests = _call_project_tests(project)
    return {
        "success": True,
        "project": project,
        "inspection": inspection,
        "tests": tests,
        "diagnosis": "Inspección y pruebas ejecutadas.",
    }


def analyze_codebase_tool(project):
    if not isinstance(project, str) or not project.strip():
        return {"success": False, "error": "El proyecto está vacío."}

    project = project.strip()
    base = Path.cwd().resolve()

    if project.lower() in {"nova", "n.o.v.a.", "self", "este proyecto"}:
        candidate = base
    elif project.startswith("projects/"):
        candidate = base / project
    else:
        candidate = base / "projects" / project

    access = PATH_GUARD.check(candidate)
    if not access["allowed"]:
        return {"success": False, "error": access["reason"]}

    root = Path(access["path"])
    if not root.is_dir():
        return {"success": False, "error": "El proyecto no existe."}

    files = []
    extensions = {}
    for item in root.rglob("*"):
        if item.is_file():
            suffix = item.suffix.lower() or "[sin_extension]"
            extensions[suffix] = extensions.get(suffix, 0) + 1
            files.append(str(item.relative_to(root)))

    return {
        "success": True,
        "project": str(root),
        "file_count": len(files),
        "extensions": dict(sorted(extensions.items())),
        "files": sorted(files) if len(files) <= 50 else [],
        "files_truncated": len(files) > 50,
    }


def refactor_code_tool(project, source=None, destination=None, content=None):
    project_root = Path(project).resolve()

    project_access = PATH_GUARD.check(project_root)
    if not project_access["allowed"]:
        return {"success": False, "error": project_access["reason"]}

    if source and destination:
        src = PATH_GUARD.check(project_root / source)
        dst = PATH_GUARD.check(project_root / destination)

        if not src["allowed"] or not dst["allowed"]:
            return {"success": False, "error": "Ruta fuera de las zonas permitidas."}

        dst["path"].parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src["path"], dst["path"])

        return {
            "success": True,
            "message": "Copia preparada para refactorización.",
            "source": str(src["path"]),
            "destination": str(dst["path"]),
        }

    if source and content is not None:
        target = PATH_GUARD.check(project_root / source)

        if not target["allowed"]:
            return {"success": False, "error": target["reason"]}

        target["path"].write_text(str(content), encoding="utf-8")
        return {"success": True, "path": str(target["path"])}

    return {
        "success": False,
        "error": "Se requiere source+destination o source+content.",
    }


def generate_code_tool(path, content, overwrite=False):
    access = PATH_GUARD.check(path)
    if not access["allowed"]:
        return {"success": False, "error": access["reason"]}

    target = Path(access["path"])
    if target.exists() and not overwrite:
        return {"success": False, "error": "El archivo ya existe."}

    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(str(content), encoding="utf-8")
    return {"success": True, "path": str(target)}


def run_integration_tests_tool(project):
    return _call_project_tests(project)


def manage_dependencies_tool(project, action="inspect", dependency=None):
    access = PATH_GUARD.check(project)
    if not access["allowed"]:
        return {"success": False, "error": access["reason"]}

    root = Path(access["path"])
    manifests = [
        p.name
        for p in root.iterdir()
        if p.is_file()
        and p.name in {
            "requirements.txt",
            "pyproject.toml",
            "package.json",
            "build.gradle",
            "settings.gradle",
            "pom.xml",
        }
    ]

    if action == "inspect":
        return {"success": True, "project": str(root), "manifests": manifests}

    return {
        "success": False,
        "error": "La modificación automática de dependencias requiere una acción específica.",
        "manifests": manifests,
        "dependency": dependency,
    }


def backup_project_tool(project, destination=None):
    access = PATH_GUARD.check(project)
    if not access["allowed"]:
        return {"success": False, "error": access["reason"]}

    source = Path(access["path"])
    if not source.is_dir():
        return {"success": False, "error": "El proyecto no existe."}

    if destination is None:
        destination = str(source.parent / f"{source.name}_backup")

    dest_access = PATH_GUARD.check(destination)
    if not dest_access["allowed"]:
        return {"success": False, "error": dest_access["reason"]}

    destination_path = Path(dest_access["path"])
    if destination_path.exists():
        return {"success": False, "error": "El destino de backup ya existe."}

    shutil.copytree(source, destination_path)
    return {
        "success": True,
        "source": str(source),
        "destination": str(destination_path),
    }


def restore_project_tool(backup, destination):
    src = PATH_GUARD.check(backup)
    dst = PATH_GUARD.check(destination)

    if not src["allowed"] or not dst["allowed"]:
        return {"success": False, "error": "Ruta fuera de las zonas permitidas."}

    source = Path(src["path"])
    target = Path(dst["path"])

    if not source.is_dir():
        return {"success": False, "error": "El backup no existe."}
    if target.exists():
        return {"success": False, "error": "El destino ya existe; no se sobrescribe."}

    shutil.copytree(source, target)
    return {"success": True, "destination": str(target)}


def web_search_tool(query, limit=5):
    permission = PERMISSION_GUARD.check("network_access")
    if not permission["authorized"]:
        return {
            "success": False,
            "requires_confirmation": permission["requires_confirmation"],
            "error": permission["reason"],
        }
    from core.internet.search_provider import WebSearchProvider
    return WebSearchProvider().search(query, limit=limit)


def web_fetch_tool(url):
    permission = PERMISSION_GUARD.check("network_access")
    if not permission["authorized"]:
        return {
            "success": False,
            "requires_confirmation": permission["requires_confirmation"],
            "error": permission["reason"],
        }
    from core.internet.internet_client import InternetClient
    result = InternetClient().request(url)
    return {
        "success": result.get("success", False),
        "url": url,
        "status": result.get("status"),
        "content": result.get("data"),
        **({"error": result["error"]} if "error" in result else {}),
    }


def api_request_tool(url, method="GET", data=None, headers=None):
    permission = PERMISSION_GUARD.check("api_access")
    if not permission["authorized"]:
        return {
            "success": False,
            "requires_confirmation": permission["requires_confirmation"],
            "error": permission["reason"],
        }
    from core.internet.api_client import ApiClient
    result = ApiClient().request(url, method=method, data=data, headers=headers)
    return result


def android_control_tool(action, **kwargs):
    permission = PERMISSION_GUARD.check("execute_tools")
    if not permission["authorized"]:
        return {
            "success": False,
            "requires_confirmation": permission["requires_confirmation"],
            "error": permission["reason"],
            "action": action,
        }
    from core.android.android_bridge import AndroidBridge
    return AndroidBridge().command(action, **kwargs)


def voice_control_tool(action, **kwargs):
    if action == "enable":
        return VOICE_CONTROL.enable()
    if action == "disable":
        return VOICE_CONTROL.disable()
    if action == "status":
        return VOICE_CONTROL.status()
    if action in {"start_listening", "listen"}:
        return VOICE_CONTROL.pipeline.listen()
    if action == "speak":
        return VOICE_CONTROL.pipeline.respond(str(kwargs.get("text", "")))
    return {
        "success": False,
        "action": action,
        "error": "Acción de voz no soportada.",
    }


def worker_dispatch_tool(task=None, **kwargs):
    permission = PERMISSION_GUARD.check("execute_external")
    if not permission["authorized"]:
        return {
            "success": False,
            "requires_confirmation": permission["requires_confirmation"],
            "pending": True,
            "error": permission["reason"],
        }
    action = str(kwargs.get("action", "dispatch")).lower()
    if action == "status":
        return WORKER_MANAGER.status(kwargs.get("task_id"))
    if action == "list":
        return WORKER_MANAGER.list()
    if action == "cancel":
        return WORKER_MANAGER.cancel(kwargs.get("task_id"))

    function = kwargs.get("function")
    if function is None:
        return {
            "success": False,
            "pending": True,
            "task": task,
            "error": "Worker local listo; falta una función ejecutable.",
        }
    return WORKER_MANAGER.dispatch(
        task,
        function,
        *kwargs.get("args", ()),
        **kwargs.get("call_kwargs", {}),
    )


def cloud_task_tool(task, **kwargs):
    permission = PERMISSION_GUARD.check("network_access")
    if not permission["authorized"]:
        return {
            "success": False,
            "requires_confirmation": permission["requires_confirmation"],
            "pending": True,
            "error": permission["reason"],
        }
    from core.cloud.cloud_client import CloudClient
    client = CloudClient(endpoint=kwargs.get("endpoint"))
    return client.submit(task, headers=kwargs.get("headers"))


def autonomous_project_tool(project, instruction=None):
    from core.interpreter.autonomous_orchestrator import AutonomousOrchestrator

    if instruction is None:
        instruction = f"Trabajar en el proyecto {project}"

    try:
        if project and instruction:
            normalized_instruction = instruction.strip()
            normalized = normalized_instruction.lower()

            analyze_actions = (
                "analiza",
                "analizar",
                "inspecciona",
                "inspeccionar",
                "revisa",
                "revisar",
                "comprueba",
                "comprobar",
            )

            if normalized.startswith(analyze_actions):
                project_normalized = project.strip().lower()

                if project_normalized not in normalized:
                    instruction = f"{normalized_instruction} {project}"
                else:
                    instruction = normalized_instruction

        result = AutonomousOrchestrator().run(instruction)

        response = {
            "success": bool(result.get("success")),
            "result": result,
        }

        for key in (
            "plan_status",
            "execution",
            "plan",
            "interpretation",
            "goal",
        ):
            if key in result:
                response[key] = result[key]

        return response
    except Exception as exc:
        return {"success": False, "error": f"{type(exc).__name__}: {exc}"}


def phase_manager_tool(action, phase=None, **kwargs):
    from core.goals.goal_manager import GoalManager

    manager = GoalManager()
    action = str(action).lower()

    if action == "summary":
        return {"success": True, "summary": manager.summary()}

    if action == "create":
        if phase is None:
            return {"success": False, "error": "Falta la fase."}
        goal = manager.create(str(phase), priority=kwargs.get("priority", 0))
        return {"success": True, "goal": goal}

    return {
        "success": False,
        "error": f"Acción de fase no soportada: {action}",
    }


def long_task_manager_tool(action, task=None, **kwargs):
    from core.state.internal_state import InternalState

    state = InternalState()

    if action == "status":
        return {"success": True, "state": state.snapshot()}

    if action == "set":
        state.set_task(task)
        return {"success": True, "task": task}

    return {"success": False, "error": f"Acción no soportada: {action}"}


def permission_manager_tool(action, permission=None):
    from core.security.permission_manager import PermissionManager

    manager = PermissionManager()

    if action == "status":
        return {"success": True, "permissions": manager.status()}

    if action == "grant":
        if not permission:
            return {"success": False, "error": "Falta el permiso."}
        return {"success": True, "permission": manager.grant(permission)}

    if action == "revoke":
        if not permission:
            return {"success": False, "error": "Falta el permiso."}
        return {"success": True, "permission": manager.revoke(permission)}

    return {"success": False, "error": f"Acción no soportada: {action}"}


def recovery_manager_tool(action, **kwargs):
    from core.runtime.cognitive_runtime import CognitiveRuntime

    runtime = CognitiveRuntime()

    if action == "status":
        return {"success": True, "state": runtime.state.snapshot()}

    if action == "error":
        message = kwargs.get("message", "Error no especificado.")
        runtime.handle_error(message)
        return {"success": True, "error": message}

    return {"success": False, "error": f"Acción no soportada: {action}"}


def system_orchestrator_tool(action, **kwargs):
    from core.runtime.supervisor_runner import SupervisorRunner

    runner = SupervisorRunner()

    if action == "status":
        return {"success": True, "result": runner.supervisor.analyze([])}

    if action == "run":
        instruction = kwargs.get("instruction")
        if not instruction:
            return {"success": False, "error": "Falta instruction."}
        return runner.run(instruction)

    return {"success": False, "error": f"Acción no soportada: {action}"}


def _call_project_inspect(project):
    from core.runtime.tool_catalog import inspect_project_tool
    return inspect_project_tool(project)


def _call_project_compile(project):
    from core.runtime.tool_catalog import compile_project_tool
    return compile_project_tool(project)


def _call_project_tests(project):
    from core.runtime.tool_catalog import run_tests_tool
    return run_tests_tool(project)


def build_nova_apk_tool(output=None):
    from core.engines.android_apk_builder import NovaApkBuilder
    return NovaApkBuilder().build(output)


def unity_action_tool(action="ping", project=None, payload=None):
    from core.engines.unity_bridge import UnityBridge
    bridge = UnityBridge()
    if action == "ping":
        return bridge.ping()
    if action == "create_project":
        return bridge.create_unity_project(project or "nova_unity_3d")
    if action == "create_scene":
        return bridge.create_scene()
    if action == "create_primitive":
        payload = payload or {}
        return bridge.create_primitive(
            payload.get("primitive", "Cube"),
            payload.get("name", "NOVA_Object"),
            payload.get("position", (0, 0, 0)),
        )
    if action == "send":
        return bridge.send(payload or {})
    return {"success": False, "error": "Acción Unity no soportada."}


def create_2d_asset_tool(path, width=512, height=512, shapes=None):
    from core.engines.asset_builder import AssetBuilder
    return AssetBuilder().svg(path, width, height, shapes)


def create_3d_asset_tool(path, size=1.0):
    from core.engines.asset_builder import AssetBuilder
    return AssetBuilder().cube_obj(path, size)
