from core.runtime.capability_registry import CapabilityRegistry


class SupervisorReport:
    """Genera un informe estructurado del estado de N.O.V.A."""

    def __init__(self, registry=None):
        self.registry = registry or CapabilityRegistry()

    def generate(self):
        inspected = self.registry.inspect()
        maturity = self.registry.maturity_summary()

        capabilities = []

        for name, data in inspected.items():
            status = data.get("status", "unknown")

            if status == "verified":
                action = "ready"
            elif status == "integrated":
                action = "ready"
            elif status == "available":
                action = "verify"
            elif status == "missing":
                action = "build"
            else:
                action = "review"

            capabilities.append({
                "name": name,
                "status": status,
                "available": data.get("available", False),
                "module": data.get("module"),
                "recommended_action": action,
            })

        total = len(capabilities)
        ready = sum(
            1 for item in capabilities
            if item["status"] in {"verified", "integrated"}
        )

        return {
            "success": True,
            "summary": {
                "total_capabilities": total,
                "ready": ready,
                "available": len(maturity["available"]),
                "missing": len(maturity["missing"]),
                "integration_progress": (
                    round((ready / total) * 100, 2)
                    if total else 0
                ),
            },
            "maturity": maturity,
            "capabilities": capabilities,
            "security": {
                "default_policy": "deny",
                "protected_actions": [
                    "self_modify",
                    "delete_files",
                    "execute_external",
                    "network_access",
                    "change_permissions",
                ],
            },
            "next_actions": [
                "verify security",
                "build permissions",
                "build autonomy",
                "build internet",
                "build apis",
            ],
        }
