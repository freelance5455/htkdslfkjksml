class ToolExecutor:
    """Ejecutor central de herramientas registradas en N.O.V.A."""

    def __init__(self, registry):
        self.registry = registry

    def execute(self, name, *args, **kwargs):
        if not isinstance(name, str) or not name.strip():
            return {
                "success": False,
                "error": "El nombre de la herramienta es inválido.",
            }

        tool = self.registry.get(name.strip())

        if tool is None:
            return {
                "success": False,
                "tool": name.strip(),
                "error": "La herramienta no está registrada.",
            }

        handler = tool.get("handler")

        if handler is None:
            return {
                "success": False,
                "tool": name.strip(),
                "level": tool["level"],
                "error": "La herramienta está registrada pero todavía no tiene ejecutor.",
            }

        try:
            result = handler(*args, **kwargs)

            return {
                "success": True,
                "tool": name.strip(),
                "level": tool["level"],
                "result": result,
            }

        except Exception as exc:
            return {
                "success": False,
                "tool": name.strip(),
                "level": tool["level"],
                "error": f"{type(exc).__name__}: {exc}",
            }
