import json
from collections import deque
from datetime import datetime, timezone
from pathlib import Path


class StateTimeline:
    """Historial persistente de transiciones de estado del núcleo."""

    def __init__(self, path="logs/state_timeline.jsonl", max_entries=60):
        self.path = Path(path)
        self.max_entries = max(20, int(max_entries))
        self._items = deque(self._load(), maxlen=self.max_entries)
        self._last = None

    def _load(self):
        if not self.path.exists():
            return []
        result = []
        try:
            for line in self.path.read_text(encoding="utf-8").splitlines()[-self.max_entries:]:
                result.append(json.loads(line))
        except Exception:
            return []
        return result

    def record(self, state, detail=""):
        state = str(state or "IDLE")
        if state == self._last:
            return False
        self._last = state
        item = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "state": state,
            "detail": str(detail or ""),
        }
        self._items.append(item)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        try:
            with self.path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(item, ensure_ascii=False) + "\n")
            lines = self.path.read_text(encoding="utf-8").splitlines()
            if len(lines) > self.max_entries:
                self.path.write_text("\n".join(lines[-self.max_entries:]) + "\n", encoding="utf-8")
        except OSError:
            pass
        return True

    def recent(self, limit=15):
        return list(self._items)[-max(1, int(limit)):][::-1]
