class ToolRegistry:
    """Registro central de las herramientas de N.O.V.A."""

    LEVELS = {
        "simple": 17,
        "medium": 10,
        "powerful": 10,
        "very_powerful": 13,
    }

    def __init__(self):
        self.tools = {}

    def register(self, name, level, description, handler=None):
        if level not in self.LEVELS:
            raise ValueError(f"Nivel de herramienta inválido: {level}")

        if name in self.tools:
            raise ValueError(f"La herramienta ya existe: {name}")

        self.tools[name] = {
            "name": name,
            "level": level,
            "description": description,
            "handler": handler,
        }

    def get(self, name):
        return self.tools.get(name)

    def all(self):
        return list(self.tools.values())

    def by_level(self, level):
        return [
            tool for tool in self.tools.values()
            if tool["level"] == level
        ]

    def summary(self):
        return {
            level: len(self.by_level(level))
            for level in self.LEVELS
        }

    def count(self):
        return len(self.tools)
