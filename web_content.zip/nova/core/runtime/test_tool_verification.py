from core.runtime.tool_catalog import verify_result_tool


def test_nested_failure_is_not_verified():
    result = verify_result_tool({
        "compile": {"success": True},
        "tests": {"success": False},
    })
    assert result["success"] is True
    assert result["verified"] is False


def test_nested_success_is_verified():
    result = verify_result_tool({
        "compile": {"success": True},
        "tests": {"success": True},
    })
    assert result["success"] is True
    assert result["verified"] is True


if __name__ == "__main__":
    test_nested_failure_is_not_verified()
    test_nested_success_is_verified()
    print("TOOL VERIFICATION TESTS OK")
