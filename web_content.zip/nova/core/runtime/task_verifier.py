from pathlib import Path


class TaskVerifier:
    """Verifica resultados de N.O.V.A. con comprobaciones reales cuando es posible."""

    def verify(self, task, result):
        if not isinstance(task, dict):
            return {
                "success": False,
                "verified": False,
                "reason": "La tarea no es válida.",
            }

        if not isinstance(result, dict):
            return {
                "success": False,
                "verified": False,
                "reason": "El resultado no es válido.",
            }

        if result.get("success") is not True:
            return {
                "success": True,
                "verified": False,
                "reason": result.get(
                    "message",
                    result.get("error", "La tarea no terminó correctamente.")
                ),
            }

        context = task.get("context", {})
        intent = context.get("intent")

        if intent == "CREATE_PROJECT":
            inputs = task.get("inputs", {})
            name = inputs.get("name")

            if not isinstance(name, str) or not name.strip():
                name = context.get("name")

            if not isinstance(name, str) or not name.strip():
                return {
                    "success": False,
                    "verified": False,
                    "reason": "CREATE_PROJECT no especifica un nombre válido.",
                }

            project_path = Path("projects") / name.strip()

            if not project_path.is_dir():
                return {
                    "success": True,
                    "verified": False,
                    "reason": f"No existe el proyecto esperado: {project_path}",
                }

            required = [
                project_path / "src",
                project_path / "assets",
                project_path / "README.md",
            ]

            missing = [str(path) for path in required if not path.exists()]

            if missing:
                return {
                    "success": True,
                    "verified": False,
                    "reason": "Faltan elementos del proyecto: " + ", ".join(missing),
                }

            return {
                "success": True,
                "verified": True,
                "reason": "Proyecto creado y estructura verificada correctamente.",
            }

        return {
            "success": True,
            "verified": True,
            "reason": "El resultado indica ejecución exitosa.",
        }
