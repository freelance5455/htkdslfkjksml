from core.state.internal_state import InternalState
from core.memory.learning_memory import LearningMemory
from core.self.metacognition import Metacognition
from core.learning.learning_engine import LearningEngine
from core.goals.goal_manager import GoalManager
from core.interpreter.autonomous_orchestrator import AutonomousOrchestrator
from core.cognition import CognitiveCycle, CognitiveState
from core.experience import EpisodicMemory
from core.autonomy import InitiativeEngine
from core.self_improvement import ImprovementLab
from core.self_improvement.experiment_runner import ExperimentRunner
from core.cognition.autobiographical_memory import AutobiographicalMemory
from core.autonomy.autonomous_loop import AutonomousLoop


class CognitiveRuntime:
    """Runtime cognitivo: memoria + atención + razonamiento + ejecución + reflexión."""
    def __init__(self):
        self.state = InternalState()
        self.memory = LearningMemory()
        self.metacognition = Metacognition(self.memory)
        self.learning = LearningEngine(self.memory)
        self.goals = GoalManager()
        self.orchestrator = AutonomousOrchestrator()
        self.cognitive_state = CognitiveState()
        self.episodes = EpisodicMemory()
        self.initiative = InitiativeEngine(self.goals)
        self.improvement_lab = ImprovementLab()
        self.experiment_runner = ExperimentRunner(self.improvement_lab)
        self.autobiography = AutobiographicalMemory()
        self.autonomous_loop = AutonomousLoop(self)
        self.cycle = CognitiveCycle(
            state=self.cognitive_state,
            memory=self.memory,
            goals=self.goals,
        )

    def execute_command(self, user_input):
        try:
            return self.orchestrator.run(user_input)
        except Exception as exc:
            return {"success": False, "stage": "orchestration",
                    "error": f"{type(exc).__name__}: {exc}"}

    def select_next_goal(self):
        goal = self.goals.next_active()
        if goal is None:
            self.state.set_goal(None)
            return None
        self.state.set_goal(goal["name"])
        return goal

    def confirm_knowledge(self, entry_id):
        result = self.learning.confirm_knowledge(entry_id)
        if result.get("confirmed"):
            self.state.update(confidence=result["entry"]["confidence"])
        return result

    def complete_cycle(self, result_type, message):
        self.state.set_status("idle")
        self.state.set_result({"success": True, "type": result_type, "message": message})
        return self.state.snapshot()

    def handle_error(self, error):
        self.state.set_status("error")
        self.state.set_error(error)
        self.cognitive_state.update(mode="error", last_error=str(error))
        return {"success": False, "error": str(error), "state": self.state.snapshot()}

    def correct_knowledge(self, entry_id, new_knowledge):
        entry = self.memory.correct(entry_id, new_knowledge)
        if entry is None:
            return {"corrected": False, "reason": "No encontré esa memoria."}
        self.state.update(confidence=entry["confidence"])
        return {"corrected": True, "entry": entry}

    def process(self, user_input):
        user_input = str(user_input).strip()
        if not user_input:
            return {"success": False, "response": "No recibí ninguna orden."}

        cycle_number = self.state.next_cycle()
        self.state.set_status("processing")
        self.state.update(last_input=user_input)

        cognition = self.cycle.begin(user_input)
        self.episodes.record('input', user_input, {'cycle': cycle_number}, importance=0.6)
        learning_result = self.learning.learn_from_conversation(user_input)

        if learning_result.get("learned"):
            response = (
                "Información incorporada a la memoria "
                f"con ID {learning_result['entry']['id']}."
            )
            self.state.affect.update(valence_delta=0.05, arousal_delta=0.05)
            self.state.set_status("idle")
            self.state.update(last_output=response, confidence=learning_result["entry"]["confidence"])
            self.state.set_result({"success": True, "type": "learning", "message": response})
            cognitive = self.cycle.finish(True, response)
            return {
                "success": True, "cycle": cycle_number, "response": response,
                "learning": learning_result, "cognition": cognitive,
                "affect": self.state.affect.snapshot(), "state": self.state.snapshot(),
            }

        low = user_input.lower()
        if low in {'estado cognitivo','estado de nova','como estás','cómo estás'}:
            return {'success': True, 'cycle': cycle_number, 'response': 'Estado cognitivo disponible.', 'cognitive_status': self.cognitive_status()}
        if low in {'iniciativa','qué puedo hacer','que puedo hacer'}:
            result = self.initiative.evaluate(); self.autobiography.remember('initiative', 'Evaluación de iniciativa', outcome=True, context={'candidates': len(result.get('candidates', []))}, importance=.5)
            return {'success': True, 'cycle': cycle_number, 'response': 'Evalué mis objetivos activos y generé propuestas seguras.', 'initiative': result}
        if low in {'modo autónomo','modo autonomo'}:
            return {'success': True, 'cycle': cycle_number, 'response': 'Modo autónomo preparado. Las acciones sensibles siguen requiriendo autorización.', 'autonomy': self.autonomous_loop.status()}
        if low in {'activar autonomía','activar autonomia'}:
            return {'success': True, 'cycle': cycle_number, 'response': 'Autonomía controlada activada.', 'autonomy': self.autonomous_loop.enable()}
        if low in {'detener autonomía','detener autonomia'}:
            return {'success': True, 'cycle': cycle_number, 'response': 'Autonomía controlada detenida.', 'autonomy': self.autonomous_loop.disable()}

        memories = self.memory.search(user_input)
        evaluation = self.metacognition.evaluate(user_input)
        interpretation = self.orchestrator.interpreter.interpret(user_input)
        intent = interpretation.get("intent", "UNKNOWN")

        if intent != "UNKNOWN":
            execution = self.execute_command(user_input)
            success = bool(execution.get("success"))
            response = self._response_for(intent, execution)
            self.state.affect.update(
                valence_delta=0.15 if success else -0.05,
                arousal_delta=0.05,
            )
            self.state.set_status("idle")
            self.state.update(
                last_output=response,
                confidence=interpretation.get("confidence", evaluation.get("confidence", 0.0)),
            )
            self.state.set_result({
                "success": success, "type": "command_execution",
                "intent": intent, "message": response,
            })
            self.episodes.record('action_result', response, {'intent': intent, 'cycle': cycle_number}, outcome=success, importance=0.7)
            lesson = 'La estrategia produjo un resultado verificable.' if success else 'La estrategia falló; requiere diagnóstico antes de repetirla.'
            self.autobiography.learn_from_outcome(user_input, success, lesson, {'intent': intent, 'cycle': cycle_number})
            self.cycle.self_model.reflect(success, interpretation.get('confidence', 0.0))
            cognitive = self.cycle.finish(success, response)
            return {
                "success": success, "cycle": cycle_number, "response": response,
                "intent": intent, "interpretation": interpretation,
                "execution": execution, "memories_found": len(memories),
                "learning": learning_result, "metacognition": evaluation,
                "cognition": cognitive, "affect": self.state.affect.snapshot(),
                "state": self.state.snapshot(),
            }

        if memories:
            response = f"Recuerdo relacionado encontrado ({len(memories)}): {memories[0]['knowledge']}"
            self.state.affect.update(valence_delta=0.1, arousal_delta=0.05)
        else:
            response = (
                "No tengo evidencia suficiente para ejecutar esa orden. "
                "Puedo pedir más contexto o usar una herramienta si la intención se aclara."
            )
            self.state.affect.update(valence_delta=0.0, arousal_delta=0.02)

        self.state.set_status("idle")
        self.state.update(last_output=response, confidence=evaluation.get("confidence", 0.0))
        self.state.set_result({"success": True, "type": "cognitive_cycle", "message": response})
        cognitive = self.cycle.finish(True, response)
        return {
            "success": True, "cycle": cycle_number, "response": response,
            "memories_found": len(memories), "learning": learning_result,
            "metacognition": evaluation, "cognition": cognitive,
            "affect": self.state.affect.snapshot(), "state": self.state.snapshot(),
        }

    def cognitive_status(self):
        return {"cognitive_state": self.cognitive_state.snapshot(),
                "self_model": self.cycle.self_model.snapshot(),
                "recent_experiences": self.episodes.recent(10),
                "initiative": self.initiative.evaluate(),
                "improvement_experiments": self.improvement_lab.list()[-10:]}

    def propose_improvement(self, title, hypothesis, targets=None):
        return self.improvement_lab.propose(title, hypothesis, targets)

    def record_experience(self, event_type, summary, context=None, outcome=None, importance=0.5):
        return self.episodes.record(event_type, summary, context, outcome, importance)

    def _response_for(self, intent, execution):
        if not execution.get("success"):
            error = execution.get("error") or execution.get("result")
            return f"La orden fue interpretada, pero la ejecución terminó con errores: {error}"
        result = execution.get("result", {})
        if intent == "CONVERSATION":
            def find_answer(node, depth=0):
                if depth > 8: return None
                if isinstance(node, dict):
                    answer = node.get("answer")
                    if isinstance(answer, str) and answer.strip(): return answer
                    for value in node.values():
                        found = find_answer(value, depth + 1)
                        if found: return found
                elif isinstance(node, list):
                    for value in node:
                        found = find_answer(value, depth + 1)
                        if found: return found
                return None
            answer = find_answer(execution)
            if answer: return answer
        if intent == "CREATE_GAME" and isinstance(result, dict):
            project = result.get("project") or result.get("result", {}).get("project")
            return f"Listo. Preparé el proyecto del juego en {project or 'projects/nova_game'}."
        if intent == "BUILD_NOVA_APK":
            return "La solicitud de APK de N.O.V.A. fue procesada por el constructor; el resultado real queda registrado en la ejecución."
        return f"Orden ejecutada correctamente. Intención: {intent}."
