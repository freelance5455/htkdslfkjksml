from core.runtime.tool_registry import ToolRegistry
from core.security.path_guard import PathGuard

PATH_GUARD = PathGuard()


def read_state_tool():
    from core.state.internal_state import InternalState
    state = InternalState()
    return state.snapshot()


def read_memory_tool():
    from core.memory.learning_memory import LearningMemory
    memory = LearningMemory()
    return memory.all()


def write_memory_tool(knowledge, source="tool", confidence=0.7):
    from core.learning.learning_engine import LearningEngine

    engine = LearningEngine()
    result = engine.learn_fact(
        knowledge,
        source=source,
        confidence=confidence,
    )
    return result


def read_file_tool(path):
    from pathlib import Path

    guard = PATH_GUARD
    access = guard.check(path)

    if not access["allowed"]:
        return {
            "success": False,
            "path": str(access["path"]),
            "error": access["reason"],
        }

    target = Path(access["path"])

    if not target.is_file():
        return {
            "success": False,
            "error": f"El archivo no existe: {target}",
        }

    try:
        return {
            "success": True,
            "path": str(target),
            "content": target.read_text(encoding="utf-8"),
        }
    except Exception as exc:
        return {
            "success": False,
            "path": str(target),
            "error": f"{type(exc).__name__}: {exc}",
        }


def add_medium_tools(registry):
    medium_tools = [
        ("copy_files", "Copiar archivos entre ubicaciones permitidas."),
        ("move_files", "Mover archivos entre ubicaciones permitidas."),
        ("organize_files", "Organizar archivos según reglas definidas."),
        ("analyze_file", "Analizar el contenido y estructura de un archivo."),
        ("edit_project", "Modificar archivos de un proyecto."),
        ("run_tests", "Ejecutar pruebas de un proyecto."),
        ("compile_project", "Compilar un proyecto."),
        ("inspect_project", "Inspeccionar la estructura de un proyecto."),
        ("manage_goal", "Crear, actualizar y gestionar objetivos."),
        ("manage_plan", "Crear y gestionar planes de tareas."),
    ]

    for name, description in medium_tools:
        registry.register(
            name=name,
            level="medium",
            description=description,
            handler=TOOL_HANDLERS.get(name),
        )

    return registry


def add_powerful_tools(registry):
    powerful_tools = [
        ("execute_command", "Ejecutar comandos permitidos dentro del entorno controlado."),
        ("build_project", "Construir un proyecto completo."),
        ("debug_project", "Analizar y corregir errores de un proyecto."),
        ("analyze_codebase", "Analizar una base de código completa."),
        ("refactor_code", "Refactorizar código manteniendo las pruebas."),
        ("generate_code", "Generar código para una tarea definida."),
        ("run_integration_tests", "Ejecutar pruebas de integración."),
        ("manage_dependencies", "Gestionar dependencias de un proyecto."),
        ("backup_project", "Crear una copia de recuperación de un proyecto."),
        ("restore_project", "Restaurar un proyecto desde una copia autorizada."),
    ]

    for name, description in powerful_tools:
        registry.register(
            name=name,
            level="powerful",
            description=description,
            handler=TOOL_HANDLERS.get(name),
        )

    return registry


def add_very_powerful_tools(registry):
    very_powerful_tools = [
        ("web_search", "Buscar información en Internet."),
        ("web_fetch", "Obtener y analizar contenido de una fuente web."),
        ("api_request", "Interactuar con APIs externas autorizadas."),
        ("android_control", "Controlar funciones de Android mediante permisos autorizados."),
        ("voice_control", "Gestionar entrada y salida de voz."),
        ("worker_dispatch", "Delegar tareas pesadas a workers."),
        ("cloud_task", "Enviar y gestionar tareas en servicios cloud autorizados."),
        ("autonomous_project", "Gestionar autónomamente un proyecto completo."),
        ("phase_manager", "Gestionar fases completas del proyecto de N.O.V.A."),
        ("long_task_manager", "Gestionar tareas largas y persistentes."),
        ("permission_manager", "Solicitar y gestionar permisos de acciones delicadas."),
        ("recovery_manager", "Gestionar recuperación ante errores y fallos."),
        ("system_orchestrator", "Coordinar múltiples herramientas y subsistemas."),
        ("build_nova_apk", "Construir una APK nueva de N.O.V.A. desde su proyecto Android."),
        ("unity_action", "Controlar Unity: conexión, escenas y objetos 3D."),
        ("create_2d_asset", "Crear recursos 2D SVG para juegos y aplicaciones."),
        ("create_3d_asset", "Crear modelos 3D OBJ básicos para Unity y otros motores."),
    ]

    for name, description in very_powerful_tools:
        registry.register(
            name=name,
            level="very_powerful",
            description=description,
            handler=TOOL_HANDLERS.get(name),
        )

    return registry


def write_file_tool(path, content):
    from pathlib import Path
    from core.security.path_guard import PathGuard

    guard = PathGuard()
    access = guard.check(path)

    if not access["allowed"]:
        return {
            "success": False,
            "path": str(access["path"]),
            "error": access["reason"],
        }

    target = Path(access["path"])

    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(str(content), encoding="utf-8")
        return {
            "success": True,
            "path": str(target),
            "message": "Archivo escrito correctamente.",
        }
    except Exception as exc:
        return {
            "success": False,
            "path": str(target),
            "error": f"{type(exc).__name__}: {exc}",
        }


def list_files_tool(path="."):
    from pathlib import Path

    target = Path(path)

    if not target.is_dir():
        return {
            "success": False,
            "error": f"El directorio no existe: {target}",
        }

    try:
        return {
            "success": True,
            "path": str(target),
            "files": sorted(item.name for item in target.iterdir()),
        }
    except Exception as exc:
        return {
            "success": False,
            "path": str(target),
            "error": f"{type(exc).__name__}: {exc}",
        }


def create_directory_tool(path):
    from pathlib import Path

    target = Path(path)

    try:
        target.mkdir(parents=True, exist_ok=True)
        return {
            "success": True,
            "path": str(target),
            "message": "Directorio creado correctamente.",
        }
    except Exception as exc:
        return {
            "success": False,
            "path": str(target),
            "error": f"{type(exc).__name__}: {exc}",
        }


def check_file_tool(path):
    from pathlib import Path

    target = Path(path)

    return {
        "success": True,
        "path": str(target),
        "exists": target.is_file(),
    }

def build_tool_registry():
    registry = ToolRegistry()

    simple_tools = [
        ("read_state", "Leer el estado interno de N.O.V.A."),
        ("read_memory", "Consultar la memoria de N.O.V.A."),
        ("write_memory", "Guardar información autorizada en memoria."),
        ("read_file", "Leer un archivo permitido."),
        ("write_file", "Escribir un archivo permitido."),
        ("list_files", "Listar archivos de una ubicación permitida."),
        ("create_directory", "Crear un directorio permitido."),
        ("create_project", "Crear un proyecto."),
        ("check_file", "Comprobar si existe un archivo."),
        ("check_directory", "Comprobar si existe un directorio."),
        ("get_time", "Obtener la fecha y hora actual."),
        ("calculate", "Realizar cálculos."),
        ("text_process", "Procesar texto."),
        ("search_memory", "Buscar información almacenada."),
        ("verify_result", "Verificar el resultado de una tarea."),
        ("create_game", "Crear un juego 2D o preparar un proyecto 3D con Unity."),
        ("unity_bridge", "Conectar N.O.V.A. con un editor Unity local."),
        ("connector_status", "Consultar el estado de los conectores disponibles."),
        ("self_repair", "Diagnosticar y reparar N.O.V.A. de forma controlada."),
    ]

    for name, description in simple_tools:
        registry.register(
            name=name,
            level="simple",
            description=description,
            handler=TOOL_HANDLERS.get(name),
        )

    add_medium_tools(registry)
    add_powerful_tools(registry)
    registry = add_very_powerful_tools(registry)
    return registry

def create_project_tool(name):
    from core.interpreter.tool_bridge import ToolBridge

    if not isinstance(name, str) or not name.strip():
        return {
            "success": False,
            "error": "El nombre del proyecto está vacío.",
        }

    bridge = ToolBridge()
    result = bridge.run_project_tool(name.strip())

    response = {
        "success": result["success"],
        "result": result["result"],
    }

    if response["success"]:
        response["outputs"] = {
            "project": f"projects/{name.strip()}",
        }

    return response


def check_directory_tool(path):
    from pathlib import Path
    from core.security.path_guard import PathGuard

    access = PathGuard().check(path)
    if not access["allowed"]:
        return {
            "success": False,
            "path": str(access["path"]),
            "error": access["reason"],
        }

    target = Path(access["path"])
    return {
        "success": True,
        "path": str(target),
        "exists": target.is_dir(),
    }


def get_time_tool():
    from datetime import datetime

    now = datetime.now().astimezone()
    return {
        "success": True,
        "datetime": now.isoformat(),
        "date": now.strftime("%Y-%m-%d"),
        "time": now.strftime("%H:%M:%S"),
        "timezone": now.strftime("%z"),
    }


def calculate_tool(expression):
    import ast
    import operator

    operations = {
        ast.Add: operator.add,
        ast.Sub: operator.sub,
        ast.Mult: operator.mul,
        ast.Div: operator.truediv,
        ast.FloorDiv: operator.floordiv,
        ast.Mod: operator.mod,
        ast.Pow: operator.pow,
        ast.USub: operator.neg,
        ast.UAdd: operator.pos,
    }

    def evaluate(node):
        if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
            return node.value

        if isinstance(node, ast.BinOp) and type(node.op) in operations:
            left = evaluate(node.left)
            right = evaluate(node.right)

            if isinstance(node.op, ast.Pow) and abs(right) > 100:
                raise ValueError("Exponente demasiado grande.")

            return operations[type(node.op)](left, right)

        if isinstance(node, ast.UnaryOp) and type(node.op) in operations:
            return operations[type(node.op)](evaluate(node.operand))

        raise ValueError("Expresión no permitida.")

    if not isinstance(expression, str) or not expression.strip():
        return {
            "success": False,
            "error": "La expresión está vacía.",
        }

    try:
        tree = ast.parse(expression.strip(), mode="eval")
        result = evaluate(tree.body)

        return {
            "success": True,
            "expression": expression.strip(),
            "result": result,
        }
    except Exception as exc:
        return {
            "success": False,
            "expression": expression.strip(),
            "error": f"{type(exc).__name__}: {exc}",
        }


def text_process_tool(text, operation="strip"):
    if not isinstance(text, str):
        return {
            "success": False,
            "error": "El texto debe ser una cadena.",
        }

    operations = {
        "strip": lambda value: value.strip(),
        "upper": lambda value: value.upper(),
        "lower": lambda value: value.lower(),
        "length": lambda value: len(value),
        "words": lambda value: len(value.split()),
        "reverse": lambda value: value[::-1],
    }

    operation = str(operation).lower()

    if operation not in operations:
        return {
            "success": False,
            "error": f"Operación no soportada: {operation}",
            "available": sorted(operations),
        }

    return {
        "success": True,
        "operation": operation,
        "result": operations[operation](text),
    }


def search_memory_tool(query):
    from core.memory.learning_memory import LearningMemory

    if not isinstance(query, str) or not query.strip():
        return {
            "success": False,
            "error": "La búsqueda está vacía.",
        }

    memory = LearningMemory()
    results = memory.search(query.strip())

    return {
        "success": True,
        "query": query.strip(),
        "results": results,
        "count": len(results),
    }


def verify_result_tool(result, expected=None):
    """Verifica resultados sin confundir un diccionario no vacío con éxito."""
    if expected is None:
        if isinstance(result, dict):
            if "verified" in result:
                verified = bool(result.get("verified"))
            elif "success" in result:
                verified = bool(result.get("success"))
            else:
                # Para resultados compuestos, todos los bloques con estado
                # explícito deben haber terminado correctamente.
                statuses = []
                for value in result.values():
                    if isinstance(value, dict) and "success" in value:
                        statuses.append(bool(value.get("success")))
                    elif isinstance(value, dict) and "verified" in value:
                        statuses.append(bool(value.get("verified")))
                verified = bool(statuses) and all(statuses)
        else:
            verified = bool(result)
    elif isinstance(result, dict) and isinstance(expected, dict):
        verified = all(result.get(key) == value for key, value in expected.items())
    else:
        verified = result == expected

    return {
        "success": True,
        "verified": verified,
        "result": result,
        "expected": expected,
    }



def copy_files_tool(source, destination):
    src_check = PATH_GUARD.check(source)
    dst_check = PATH_GUARD.check(destination)

    if not src_check["allowed"]:
        return {"success": False, "error": src_check["reason"]}
    if not dst_check["allowed"]:
        return {"success": False, "error": dst_check["reason"]}

    src = src_check["path"]
    dst = dst_check["path"]

    if not src.is_file():
        return {"success": False, "error": "El archivo origen no existe."}

    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_bytes(src.read_bytes())

    return {
        "success": True,
        "source": str(src),
        "destination": str(dst),
    }


def move_files_tool(source, destination):
    src_check = PATH_GUARD.check(source)
    dst_check = PATH_GUARD.check(destination)

    if not src_check["allowed"]:
        return {"success": False, "error": src_check["reason"]}
    if not dst_check["allowed"]:
        return {"success": False, "error": dst_check["reason"]}

    src = src_check["path"]
    dst = dst_check["path"]

    if not src.is_file():
        return {"success": False, "error": "El archivo origen no existe."}

    dst.parent.mkdir(parents=True, exist_ok=True)
    src.replace(dst)

    return {
        "success": True,
        "source": str(src),
        "destination": str(dst),
    }


def organize_files_tool(directory, extension=None):
    check = PATH_GUARD.check(directory)

    if not check["allowed"]:
        return {"success": False, "error": check["reason"]}

    root = check["path"]

    if not root.is_dir():
        return {"success": False, "error": "El directorio no existe."}

    moved = []

    for item in root.iterdir():
        if not item.is_file():
            continue

        if extension and item.suffix.lower() != str(extension).lower():
            continue

        folder_name = item.suffix.lower().replace(".", "") or "sin_extension"
        target_dir = root / folder_name
        target_dir.mkdir(exist_ok=True)

        target = target_dir / item.name

        if target.exists():
            continue

        item.replace(target)
        moved.append(str(target))

    return {
        "success": True,
        "directory": str(root),
        "organized": len(moved),
        "files": moved,
    }


def analyze_file_tool(path):
    check = PATH_GUARD.check(path)

    if not check["allowed"]:
        return {"success": False, "error": check["reason"]}

    target = check["path"]

    if not target.is_file():
        return {"success": False, "error": "El archivo no existe."}

    data = target.read_bytes()

    try:
        content = data.decode("utf-8")
        encoding = "utf-8"
        lines = len(content.splitlines())
        words = len(content.split())
        characters = len(content)
    except UnicodeDecodeError:
        content = None
        encoding = "binary"
        lines = None
        words = None
        characters = None

    return {
        "success": True,
        "path": str(target),
        "name": target.name,
        "suffix": target.suffix,
        "size_bytes": len(data),
        "encoding": encoding,
        "lines": lines,
        "words": words,
        "characters": characters,
    }


def edit_project_tool(project, path, content):
    project_check = PATH_GUARD.check(project)

    if not project_check["allowed"]:
        return {"success": False, "error": project_check["reason"]}

    project_root = project_check["path"]

    if not project_root.is_dir():
        return {"success": False, "error": "El proyecto no existe."}

    target = project_root / str(path)

    target_check = PATH_GUARD.check(target)

    if not target_check["allowed"]:
        return {"success": False, "error": target_check["reason"]}

    target = target_check["path"]

    try:
        target.relative_to(project_root)
    except ValueError:
        return {
            "success": False,
            "error": "La ruta queda fuera del proyecto.",
        }

    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(str(content), encoding="utf-8")

    return {
        "success": True,
        "project": str(project_root),
        "path": str(target),
        "bytes": target.stat().st_size,
    }

def run_tests_tool(project):
    import subprocess

    project_check = PATH_GUARD.check(project)
    if not project_check["allowed"]:
        return {"success": False, "error": project_check["reason"]}

    project_root = project_check["path"]
    if not project_root.is_dir():
        return {"success": False, "error": "El proyecto no existe."}

    tests = []
    tests_dir = project_root / "tests"
    if tests_dir.is_dir():
        tests.extend(tests_dir.rglob("test_*.py"))
        tests.extend(tests_dir.rglob("*_test.py"))

    tests.extend(project_root.glob("test_*.py"))
    tests.extend(project_root.glob("*_test.py"))

    # Buscar pruebas también dentro de todos los subdirectorios.
    tests.extend(project_root.rglob("test_*.py"))
    tests.extend(project_root.rglob("*_test.py"))

    tests = sorted(set(tests))

    if not tests:
        return {
            "success": True,
            "project": str(project_root),
            "tests_found": 0,
            "message": "No se encontraron pruebas Python para ejecutar.",
        }

    results = []
    all_passed = True

    for test in tests:
        test_check = PATH_GUARD.check(test)
        if not test_check["allowed"]:
            all_passed = False
            results.append({"test": str(test), "success": False, "error": test_check["reason"]})
            continue

        import os

        env = os.environ.copy()
        existing_pythonpath = env.get("PYTHONPATH", "")
        env["PYTHONPATH"] = str(project_root) + (
            os.pathsep + existing_pythonpath
            if existing_pythonpath
            else ""
        )

        completed = subprocess.run(
            ["python", str(test_check["path"])],
            cwd=str(project_root),
            env=env,
            capture_output=True,
            text=True,
            timeout=60,
        )
        passed = completed.returncode == 0
        all_passed = all_passed and passed
        results.append({
            "test": str(test_check["path"]),
            "success": passed,
            "returncode": completed.returncode,
            "stdout": completed.stdout,
            "stderr": completed.stderr,
        })

    return {
        "success": all_passed,
        "project": str(project_root),
        "tests_found": len(tests),
        "passed": all_passed,
        "results": results,
    }


def compile_project_tool(project):
    import subprocess

    project_check = PATH_GUARD.check(project)
    if not project_check["allowed"]:
        return {"success": False, "error": project_check["reason"]}

    project_root = project_check["path"]
    if not project_root.is_dir():
        return {"success": False, "error": "El proyecto no existe."}

    # N.O.V.A. puede venir dentro de carpetas como "NOVA(Copy)" o con
    # otro nombre. Detectamos su estructura real para no intentar compilar
    # APKs, proyectos de prueba y backups Java como si fueran un solo proyecto.
    is_nova_project = (
        project_root.name.lower() == "nova"
        or (
            (project_root / "core").is_dir()
            and (project_root / "tools").is_dir()
            and (project_root / "core/brain/NOVA.java").is_file()
        )
    )

    if is_nova_project:
        java_roots = [
            project_root / "core",
            project_root / "tools",
        ]
        java_files = []
        for java_root in java_roots:
            if java_root.is_dir():
                java_files.extend(java_root.rglob("*.java"))
        java_files = sorted(set(java_files))
    else:
        java_files = sorted(project_root.rglob("*.java"))

    java_files = [
        path for path in java_files
        if PATH_GUARD.check(path)["allowed"]
    ]

    if not java_files:
        return {
            "success": False,
            "project": str(project_root),
            "error": "No se encontraron archivos Java para compilar.",
        }

    output_dir = project_root / "build" / "classes"
    output_check = PATH_GUARD.check(output_dir)
    if not output_check["allowed"]:
        return {"success": False, "error": output_check["reason"]}

    output_dir.mkdir(parents=True, exist_ok=True)

    completed = subprocess.run(
        ["javac", "-d", str(output_dir)] + [str(path) for path in java_files],
        cwd=str(project_root),
        capture_output=True,
        text=True,
        timeout=60,
    )

    return {
        "success": completed.returncode == 0,
        "project": str(project_root),
        "compiler": "javac",
        "source_files": len(java_files),
        "output": str(output_dir),
        "returncode": completed.returncode,
        "stdout": completed.stdout,
        "stderr": completed.stderr,
    }


def inspect_project_tool(project):
    project_check = PATH_GUARD.check(project)
    if not project_check["allowed"]:
        return {"success": False, "error": project_check["reason"]}

    project_root = project_check["path"]
    if not project_root.is_dir():
        return {"success": False, "error": "El proyecto no existe."}

    files = []
    directories = []

    for item in sorted(project_root.rglob("*")):
        if not PATH_GUARD.check(item)["allowed"]:
            continue
        relative = item.relative_to(project_root)
        if item.is_dir():
            directories.append(str(relative))
        elif item.is_file():
            files.append({
                "path": str(relative),
                "size_bytes": item.stat().st_size,
                "suffix": item.suffix,
            })

    return {
        "success": True,
        "project": str(project_root),
        "directories": directories,
        "files": files,
        "directory_count": len(directories),
        "file_count": len(files),
    }


def manage_goal_tool(action, **kwargs):
    from core.goals.goal_manager import GoalManager

    manager = GoalManager()

    try:
        action = str(action).strip().lower()

        if action == "create":
            name = kwargs.get("name")
            if not name:
                return {"success": False, "error": "Falta el nombre del objetivo."}
            goal = manager.create(
                name=name,
                priority=kwargs.get("priority", 0),
                parent_id=kwargs.get("parent_id"),
            )
            return {"success": True, "action": action, "goal": goal}

        goal_id = kwargs.get("goal_id")
        if goal_id is not None:
            goal_id = int(goal_id)

        if action == "update":
            goal = manager.update(
                goal_id,
                progress=kwargs.get("progress"),
                status=kwargs.get("status"),
                priority=kwargs.get("priority"),
            )
            return {"success": goal is not None, "action": action, "goal": goal}

        if action == "get":
            goal = manager.get(goal_id)
            return {"success": goal is not None, "action": action, "goal": goal}

        if action == "cancel":
            goal = manager.cancel(goal_id)
            return {"success": goal is not None, "action": action, "goal": goal}

        if action == "pause":
            goal = manager.pause(goal_id)
            return {"success": goal is not None, "action": action, "goal": goal}

        if action == "resume":
            goal = manager.resume(goal_id)
            return {"success": goal is not None, "action": action, "goal": goal}

        if action == "active":
            return {"success": True, "action": action, "goals": manager.active()}

        if action == "next_active":
            return {"success": True, "action": action, "goal": manager.next_active()}

        if action == "next_pending":
            return {"success": True, "action": action, "goal": manager.next_pending()}

        if action == "summary":
            return {"success": True, "action": action, "summary": manager.summary()}

        if action == "all":
            return {"success": True, "action": action, "goals": manager.all()}

        return {"success": False, "error": f"Acción de objetivo no soportada: {action}"}

    except Exception as exc:
        return {"success": False, "action": action, "error": f"{type(exc).__name__}: {exc}"}


def manage_plan_tool(action, plan=None, **kwargs):
    from core.goals.goal_manager import GoalManager
    from core.planner.planner import Planner

    planner = Planner(GoalManager())

    try:
        action = str(action).strip().lower()

        if action == "create":
            goal = kwargs.get("goal")
            return planner.create_plan(goal)

        if action == "add_task":
            description = kwargs.get("description")
            priority = kwargs.get("priority", 0)
            return planner.add_task(plan, description, priority)

        if action == "status":
            return {
                "success": True,
                "status": planner.plan_status(plan),
            }

        if action == "next_task":
            return {
                "success": True,
                "task": planner.next_task(plan),
            }

        if action == "start_next_task":
            return planner.start_next_task(plan)

        if action == "complete_current_task":
            return planner.complete_current_task(
                plan,
                result=kwargs.get("result"),
            )

        if action == "finish":
            return planner.finish_plan(plan)

        if action == "fail_task":
            return planner.fail_task(
                plan,
                kwargs.get("task_id"),
                kwargs.get("reason", ""),
            )

        if action == "retry_task":
            return planner.retry_task(
                plan,
                kwargs.get("task_id"),
            )

        if action == "can_retry":
            return {
                "success": True,
                "can_retry": planner.can_retry(
                    plan,
                    kwargs.get("task_id"),
                ),
            }

        if action == "validate_dependencies":
            return planner.validate_dependencies(plan)

        if action == "has_dependency_cycle":
            return {
                "success": True,
                "has_cycle": planner.has_dependency_cycle(plan),
            }

        return {
            "success": False,
            "error": f"Acción de plan no soportada: {action}",
        }

    except Exception as exc:
        return {
            "success": False,
            "action": action,
            "error": f"{type(exc).__name__}: {exc}",
        }



def create_game_tool(dimension="2d", project="nova_game_2d", title=None):
    dimension = str(dimension or "2d").lower()
    if dimension == "2d":
        from core.game.game_builder import GameBuilder
        return GameBuilder().build_2d(project, title or "N.O.V.A. — Black Hole Survivor")
    if dimension == "3d":
        from core.engines.unity_bridge import UnityBridge
        project_result = UnityBridge().create_unity_project(project)
        if not project_result.get("success"):
            return project_result
        from core.game.unity_game_builder import UnityGameBuilder
        game_result = UnityGameBuilder().build(
            project=project,
            title=title or "N.O.V.A. — 3D Game",
        )
        return {
            "success": bool(game_result.get("success")),
            "project": project_result.get("project"),
            "unity_project": project_result,
            "game": game_result,
        }
    return {"success": False, "error": "Dimensión no soportada."}


def unity_bridge_tool(action="ping", project=None, payload=None):
    from core.engines.unity_bridge import UnityBridge
    bridge = UnityBridge()
    if action == "ping":
        return bridge.ping()
    if action == "create_project":
        return bridge.create_unity_project(project or "nova_unity_project")
    if action == "create_bridge":
        if not project:
            return {"success": False, "error": "Falta el proyecto Unity."}
        return bridge.create_bridge_script(project)
    if action == "send":
        return bridge.send(payload or {})
    return {"success": False, "error": "Acción Unity no soportada."}

def connector_status_tool():
    from core.connectors import create_default_manager
    return {"success": True, "connectors": create_default_manager().list_connectors()}

def self_repair_tool(action="status", files=None, path=None, backup=None, destination=None):
    from core.self_repair import SelfRepair
    repair = SelfRepair()
    if action == "status":
        return repair.status()
    if action == "diagnose":
        return repair.diagnose(files)
    if action == "backup":
        if not path:
            return {"success": False, "error": "Falta path."}
        return repair.backup(path)
    if action == "verify":
        if not path:
            return {"success": False, "error": "Falta path."}
        return repair.verify_python(path)
    if action == "rollback":
        if not backup or not destination:
            return {"success": False, "error": "Faltan backup y destination."}
        return repair.rollback(backup, destination)
    return {"success": False, "error": f"Acción SelfRepair no soportada: {action}"}

TOOL_HANDLERS = {
    "read_state": read_state_tool,
    "read_memory": read_memory_tool,
    "write_memory": write_memory_tool,
    "read_file": read_file_tool,
    "write_file": write_file_tool,
    "list_files": list_files_tool,
    "create_directory": create_directory_tool,
    "check_file": check_file_tool,
    "create_project": create_project_tool,
    "check_directory": check_directory_tool,
    "get_time": get_time_tool,
    "calculate": calculate_tool,
    "text_process": text_process_tool,
    "search_memory": search_memory_tool,
    "verify_result": verify_result_tool,
    "create_game": create_game_tool,
    "unity_bridge": unity_bridge_tool,
    "connector_status": connector_status_tool,
    "self_repair": self_repair_tool,
    "copy_files": copy_files_tool,
    "move_files": move_files_tool,
    "organize_files": organize_files_tool,
    "analyze_file": analyze_file_tool,
    "edit_project": edit_project_tool,
    "run_tests": run_tests_tool,
    "compile_project": compile_project_tool,
    "inspect_project": inspect_project_tool,
    "manage_goal": manage_goal_tool,
    "manage_plan": manage_plan_tool,
}

from core.runtime.advanced_tool_handlers import (
    execute_command_tool,
    build_project_tool,
    debug_project_tool,
    analyze_codebase_tool,
    refactor_code_tool,
    generate_code_tool,
    run_integration_tests_tool,
    manage_dependencies_tool,
    backup_project_tool,
    restore_project_tool,
    web_search_tool,
    web_fetch_tool,
    api_request_tool,
    android_control_tool,
    voice_control_tool,
    worker_dispatch_tool,
    cloud_task_tool,
    autonomous_project_tool,
    phase_manager_tool,
    long_task_manager_tool,
    permission_manager_tool,
    recovery_manager_tool,
    system_orchestrator_tool,
    build_nova_apk_tool,
    unity_action_tool,
    create_2d_asset_tool,
    create_3d_asset_tool,
)

TOOL_HANDLERS.update({
    "execute_command": execute_command_tool,
    "build_project": build_project_tool,
    "debug_project": debug_project_tool,
    "analyze_codebase": analyze_codebase_tool,
    "refactor_code": refactor_code_tool,
    "generate_code": generate_code_tool,
    "run_integration_tests": run_integration_tests_tool,
    "manage_dependencies": manage_dependencies_tool,
    "backup_project": backup_project_tool,
    "restore_project": restore_project_tool,
    "web_search": web_search_tool,
    "web_fetch": web_fetch_tool,
    "api_request": api_request_tool,
    "android_control": android_control_tool,
    "voice_control": voice_control_tool,
    "worker_dispatch": worker_dispatch_tool,
    "cloud_task": cloud_task_tool,
    "autonomous_project": autonomous_project_tool,
    "phase_manager": phase_manager_tool,
    "long_task_manager": long_task_manager_tool,
    "permission_manager": permission_manager_tool,
    "recovery_manager": recovery_manager_tool,
    "system_orchestrator": system_orchestrator_tool,
    "build_nova_apk": build_nova_apk_tool,
    "unity_action": unity_action_tool,
    "create_2d_asset": create_2d_asset_tool,
    "create_3d_asset": create_3d_asset_tool,
})
