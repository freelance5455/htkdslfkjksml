from core.runtime.capability_registry import CapabilityRegistry


class IntegrationExecutor:
    """Ejecuta comprobaciones controladas de integración."""

    def __init__(self, registry=None):
        self.registry = registry or CapabilityRegistry()

    def execute(self, task):
        if not isinstance(task, dict):
            return {
                "success": False,
                "error": "La tarea debe ser un diccionario.",
            }

        context = task.get("context", {})
        capability = context.get("capability")
        action = context.get("action")

        if not capability:
            return {
                "success": False,
                "error": "La tarea no especifica una capacidad.",
            }

        if action == "investigate":
            tool_name = context.get("tool")
            project = context.get("project", "NOVA")

            from pathlib import Path
            project_path = Path(str(project))
            if project_path.is_absolute() and project_path.is_dir():
                project_root = project_path.resolve()
            elif project_path.is_dir():
                project_root = project_path.resolve()
            elif Path.cwd().joinpath("core").is_dir():
                project_root = Path.cwd().resolve()
            else:
                project_root = project_path.resolve()

            project = str(project_root)

            from core.runtime.tool_catalog import build_tool_registry
            from core.runtime.tool_executor import ToolExecutor

            executor = ToolExecutor(build_tool_registry())

            if tool_name == "inspect_project":
                result = executor.execute("inspect_project", project)
            elif tool_name == "analyze_codebase":
                result = executor.execute("analyze_codebase", project)
            elif tool_name == "read_relevant_files":
                files = [
                    "core/runtime/integration_supervisor.py",
                    "core/runtime/integration_executor.py",
                    "core/runtime/capability_registry.py",
                ]
                file_results = []
                for path in files:
                    file_results.append(
                        executor.execute("read_file", str(Path(project_root) / path))
                    )
                result = {
                    "success": all(
                        item.get("success", False)
                        for item in file_results
                    ),
                    "files": file_results,
                }
            else:
                return {
                    "success": False,
                    "capability": capability,
                    "action": action,
                    "error": "Herramienta de investigación no reconocida.",
                }

            # ToolExecutor.success solo indica que el handler no lanzó
            # una excepción. Para una investigación debemos respetar también
            # el éxito real devuelto por la herramienta.
            if isinstance(result, dict) and isinstance(result.get("result"), dict):
                result_success = bool(result["result"].get("success", False))
            else:
                result_success = bool(result.get("success", False))

            return {
                "success": result_success,
                "capability": capability,
                "action": action,
                "tool": tool_name,
                "project": project,
                "result": result,
            }

        if action != "integrate":
            return {
                "success": False,
                "capability": capability,
                "action": action,
                "message": (
                    "Esta capacidad requiere construcción; "
                    "todavía no se permite ejecución automática."
                ),
            }

        inspected = self.registry.inspect()
        data = inspected.get(capability)

        if data is None:
            return {
                "success": False,
                "capability": capability,
                "message": "Capacidad no registrada.",
            }

        if not data["available"]:
            return {
                "success": False,
                "capability": capability,
                "message": "La capacidad no está disponible.",
                "error": data.get("error"),
            }

        return {
            "success": True,
            "capability": capability,
            "action": "integrate",
            "message": (
                f"Capacidad {capability} disponible "
                "y lista para integración."
            ),
            "module": data["module"],
        }
