import json
import os
import subprocess
import urllib.parse
import urllib.request
from pathlib import Path


class WeatherService:
    """Obtiene ubicación del dispositivo vía Termux y clima vía Open-Meteo."""

    def __init__(self, cache_path="core/state/weather.json"):
        self.cache_path = Path(cache_path)

    def _termux_location(self):
        try:
            proc = subprocess.run(
                ["termux-location", "-p", "network", "-r", "once"],
                capture_output=True, text=True, timeout=8,
            )
            if proc.returncode == 0 and proc.stdout.strip():
                data = json.loads(proc.stdout)
                if data.get("latitude") is not None and data.get("longitude") is not None:
                    return data
        except Exception:
            pass
        return None

    def _cached(self):
        try:
            return json.loads(self.cache_path.read_text(encoding="utf-8"))
        except Exception:
            return None

    def get(self):
        location = self._termux_location()
        if not location:
            cached = self._cached()
            if cached:
                cached["source"] = "cache"
                return cached
            return {"available": False, "source": "unavailable", "message": "Ubicación del dispositivo no disponible."}

        lat = float(location["latitude"])
        lon = float(location["longitude"])
        params = urllib.parse.urlencode({
            "latitude": lat, "longitude": lon,
            "current": "temperature_2m,relative_humidity_2m,apparent_temperature,wind_speed_10m,weather_code",
            "timezone": "auto",
        })
        try:
            url = "https://api.open-meteo.com/v1/forecast?" + params
            req = urllib.request.Request(url, headers={"User-Agent": "NOVA/4.2"})
            with urllib.request.urlopen(req, timeout=8) as response:
                data = json.loads(response.read(100_000).decode("utf-8"))
            current = data.get("current", {})
            result = {
                "available": True,
                "source": "device+open-meteo",
                "latitude": lat,
                "longitude": lon,
                "timezone": data.get("timezone"),
                "temperature_c": current.get("temperature_2m"),
                "humidity": current.get("relative_humidity_2m"),
                "feels_like_c": current.get("apparent_temperature"),
                "wind_mps": current.get("wind_speed_10m"),
                "weather_code": current.get("weather_code"),
            }
            self.cache_path.parent.mkdir(parents=True, exist_ok=True)
            self.cache_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
            return result
        except Exception as exc:
            cached = self._cached()
            if cached:
                cached["source"] = "cache"
                cached["warning"] = f"No se pudo actualizar el clima: {type(exc).__name__}"
                return cached
            return {"available": False, "source": "error", "message": f"Clima no disponible: {type(exc).__name__}"}
