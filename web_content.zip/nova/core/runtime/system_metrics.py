import json
import os
import shutil
import time
from collections import deque
from pathlib import Path


class SystemMetrics:
    """Métricas locales ligeras, sin dependencias externas."""

    def __init__(self, path="logs/system_metrics.jsonl", max_points=30):
        self.path = Path(path)
        self.max_points = max(10, int(max_points))
        self._prev_cpu = self._read_cpu_times()
        self._points = deque(self._load(), maxlen=self.max_points)

    def _read_cpu_times(self):
        try:
            line = Path("/proc/stat").read_text(encoding="utf-8").splitlines()[0]
            parts = line.split()[1:]
            values = [int(x) for x in parts]
            idle = values[3] + (values[4] if len(values) > 4 else 0)
            total = sum(values)
            return total, idle
        except Exception:
            return None

    def _cpu_percent(self):
        current = self._read_cpu_times()
        previous = self._prev_cpu
        self._prev_cpu = current
        if not current or not previous:
            return None
        total_delta = current[0] - previous[0]
        idle_delta = current[1] - previous[1]
        if total_delta <= 0:
            return 0.0
        return round(max(0.0, min(100.0, (1 - idle_delta / total_delta) * 100)), 1)

    def _ram(self):
        try:
            info = {}
            for line in Path("/proc/meminfo").read_text(encoding="utf-8").splitlines():
                key, value = line.split(":", 1)
                info[key] = int(value.strip().split()[0]) * 1024
            total = info.get("MemTotal", 0)
            available = info.get("MemAvailable", info.get("MemFree", 0))
            used = max(0, total - available)
            return used, total, round((used / total * 100) if total else 0, 1)
        except Exception:
            return 0, 0, 0.0

    def sample(self):
        used, total, percent = self._ram()
        disk = shutil.disk_usage(Path.cwd())
        point = {
            "timestamp": time.time(),
            "cpu_percent": self._cpu_percent(),
            "ram_percent": percent,
            "ram_used": used,
            "ram_total": total,
            "disk_used": disk.used,
            "disk_total": disk.total,
        }
        self._points.append(point)
        self._persist()
        return point

    def _load(self):
        if not self.path.exists():
            return []
        rows = []
        try:
            for line in self.path.read_text(encoding="utf-8").splitlines()[-self.max_points:]:
                rows.append(json.loads(line))
        except Exception:
            return []
        return rows

    def _persist(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        try:
            with self.path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(self._points[-1], ensure_ascii=False) + "\n")
            lines = self.path.read_text(encoding="utf-8").splitlines()
            if len(lines) > self.max_points:
                self.path.write_text("\n".join(lines[-self.max_points:]) + "\n", encoding="utf-8")
        except OSError:
            pass

    def snapshot(self):
        current = self.sample()
        return {
            "current": current,
            "history": list(self._points),
        }
