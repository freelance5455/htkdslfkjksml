class KnowledgeValidator:
    """Valida conocimiento y evita estados de aprendizaje incoherentes."""

    def validate(
        self,
        knowledge,
        confidence=0.5,
        source="conversation",
        importance=0.5,
    ):
        if not isinstance(knowledge, str) or not knowledge.strip():
            return {"valid": False, "reason": "El conocimiento está vacío."}
        try:
            confidence = float(confidence)
            importance = float(importance)
        except (TypeError, ValueError):
            return {"valid": False, "reason": "Confianza/importancia deben ser numéricas."}
        if not 0.0 <= confidence <= 1.0:
            return {"valid": False, "reason": "La confianza debe estar entre 0 y 1."}
        if not 0.0 <= importance <= 1.0:
            return {"valid": False, "reason": "La importancia debe estar entre 0 y 1."}
        if not isinstance(source, str) or not source.strip():
            return {"valid": False, "reason": "La fuente es obligatoria."}
        return {
            "valid": True,
            "knowledge": knowledge.strip(),
            "confidence": round(confidence, 3),
            "importance": round(importance, 3),
            "source": source.strip(),
        }
