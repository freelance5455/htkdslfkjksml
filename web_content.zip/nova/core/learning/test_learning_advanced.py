from pathlib import Path
import tempfile
from core.learning.learning_engine import LearningEngine
from core.memory.learning_memory import LearningMemory


def make_engine(tmp):
    return LearningEngine(memory=LearningMemory(Path(tmp) / "knowledge.json"))


def test_learning_deduplicates_and_reinforces():
    with tempfile.TemporaryDirectory() as tmp:
        memory = LearningMemory(Path(tmp) / "knowledge.json")
        engine = LearningEngine(memory=memory)
        first = engine.learn_fact("N.O.V.A. usa memoria persistente", confidence=0.6)
        second = engine.learn_fact("N.O.V.A. usa memoria persistente", confidence=0.9)
        assert first["success"] is True
        assert second["success"] is True
        assert len(memory.all()) == 1
        assert memory.all()[0]["confidence"] == 0.9


def test_learning_confirmation_and_correction():
    with tempfile.TemporaryDirectory() as tmp:
        memory = LearningMemory(Path(tmp) / "knowledge.json")
        engine = LearningEngine(memory=memory)
        entry = engine.learn_fact("Dato inicial", confidence=0.5)["entry"]
        confirmed = engine.confirm_knowledge(entry["id"], evidence="usuario confirmó")
        assert confirmed["confirmed"] is True
        assert confirmed["entry"]["confidence"] == 0.6
        corrected = engine.correct_knowledge(entry["id"], "Dato corregido")
        assert corrected["corrected"] is True
        assert corrected["entry"]["confidence"] == 0.5
        assert corrected["entry"]["history"]


def test_learning_evaluation():
    with tempfile.TemporaryDirectory() as tmp:
        engine = make_engine(tmp)
        engine.learn_fact("N.O.V.A. puede aprender conocimiento estructurado", confidence=1.0, importance=0.9)
        result = engine.evaluate("N.O.V.A. aprender conocimiento")
        assert result["success"] is True
        assert result["known"] is True
        assert result["confidence"] > 0


def test_advanced_recall_metadata_and_tags():
    with tempfile.TemporaryDirectory() as tmp:
        e = make_engine(tmp)
        learned = e.learn_fact(
            "N.O.V.A. usa un puente Android para comunicarse con el teléfono",
            source="verified",
            confidence=0.9,
            importance=0.95,
            evidence="prueba IPC",
        )
        entry = learned["entry"]
        assert "android" in entry["tags"]
        assert entry["importance"] == 0.95
        result = e.recall("puente Android teléfono")
        assert result["matches"]
        assert result["matches"][0]["effective_confidence"] > 0
        assert result["matches"][0]["retrieval_score"] > 0


def test_associations_and_related_recall():
    with tempfile.TemporaryDirectory() as tmp:
        e = make_engine(tmp)
        a = e.learn_fact("N.O.V.A. tiene voz", source="verified")["entry"]
        b = e.learn_fact("N.O.V.A. tiene memoria", source="verified")["entry"]
        association = e.associate(a["id"], b["id"], "depends_on", 0.8)
        assert association["success"] is True
        related = e.related(a["id"])
        assert related["entries"][0]["id"] == b["id"]


def test_contradiction_tracking():
    with tempfile.TemporaryDirectory() as tmp:
        e = make_engine(tmp)
        a = e.learn_fact("N.O.V.A. tiene voz activa", confidence=0.8)["entry"]
        result = e.detect_contradiction(
            a["id"],
            "N.O.V.A. no tiene voz activa",
            confidence=0.7,
            evidence="prueba contraria",
        )
        assert result["success"] is True
        assert result["conflict"]["id"] in result["original"]["contradicts_ids"]
        assert result["original"]["id"] in result["conflict"]["contradicts_ids"]


def test_archive_and_forget():
    with tempfile.TemporaryDirectory() as tmp:
        e = make_engine(tmp)
        entry = e.learn_fact("Dato que ya no debe recuperarse")["entry"]
        forgotten = e.forget(entry["id"])
        assert forgotten["success"] is True
        assert not e.recall("Dato ya no debe recuperarse")["matches"]
        assert e.stats()["memory"]["archived"] == 1


def test_persistence_and_migration():
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "knowledge.json"
        first = LearningMemory(path)
        entry = first.learn(
            "Memoria persistente de larga duración",
            source="system",
            confidence=1.0,
            importance=1.0,
        )
        second = LearningMemory(path)
        loaded = second.get(entry["id"])
        assert loaded is not None
        assert loaded["fingerprint"]
        assert loaded["status"] == "active"
        assert second.stats()["total"] == 1


def test_validator_rejects_bad_importance():
    with tempfile.TemporaryDirectory() as tmp:
        e = make_engine(tmp)
        result = e.learn_fact("dato", importance=2.0)
        assert result["success"] is False



def test_episodic_context_and_decay():
    with tempfile.TemporaryDirectory() as tmp:
        e = make_engine(tmp)
        a = e.learn_fact("N.O.V.A. usa planificación avanzada", confidence=0.9, importance=0.9)["entry"]
        b = e.learn_fact("N.O.V.A. usa memoria avanzada", confidence=0.8, importance=0.8)["entry"]
        e.associate(a["id"], b["id"], "supports", 0.7)
        episode = e.learn_experience(
            "task_completed",
            "Se completó una prueba de memoria",
            context={"test": "learning"},
            importance=0.8,
        )
        assert episode["success"] is True
        context = e.recall_context("N.O.V.A. memoria planificación")
        assert context["context"]["relevant"]
        assert context["context"]["recent_episodes"]
        assert e.decay_report()["memories"]


def test_memory_merge():
    with tempfile.TemporaryDirectory() as tmp:
        e = make_engine(tmp)
        a = e.learn_fact("Memoria principal de NOVA", confidence=0.7, importance=0.8)["entry"]
        b = e.learn_fact("Memoria secundaria de NOVA", confidence=0.9, importance=0.6)["entry"]
        result = e.merge_memories(a["id"], b["id"])
        assert result["success"] is True
        assert e.get_memory(a["id"])["entry"]["confidence"] == 0.9
        assert not e.get_memory(b["id"])["success"]

if __name__ == "__main__":
    test_learning_deduplicates_and_reinforces()
    test_learning_confirmation_and_correction()
    test_learning_evaluation()
    test_advanced_recall_metadata_and_tags()
    test_associations_and_related_recall()
    test_contradiction_tracking()
    test_archive_and_forget()
    test_persistence_and_migration()
    test_validator_rejects_bad_importance()
    test_episodic_context_and_decay()
    test_memory_merge()
    print("LEARNING ADVANCED TESTS OK")
