from core.memory.learning_memory import LearningMemory
from core.learning.knowledge_validator import KnowledgeValidator


class LearningEngine:
    """Motor de aprendizaje avanzado y controlado de N.O.V.A."""

    def __init__(self, memory=None, validator=None):
        self.memory = memory or LearningMemory()
        self.validator = validator or KnowledgeValidator()

    def learn_fact(
        self,
        knowledge,
        source="conversation",
        confidence=0.7,
        evidence=None,
        importance=0.5,
        category=None,
        tags=None,
        valid_from=None,
        valid_until=None,
    ):
        validation = self.validator.validate(
            knowledge, confidence, source,
            importance=importance,
        )
        if not validation["valid"]:
            return {"success": False, "learned": False, "error": validation["reason"]}

        entry = self.memory.learn(
            knowledge=validation["knowledge"],
            source=validation["source"],
            confidence=validation["confidence"],
            evidence=evidence,
            importance=validation["importance"],
            category=category,
            tags=tags,
            valid_from=valid_from,
            valid_until=valid_until,
        )
        return {"success": True, "learned": True, "entry": entry}

    def learn_from_conversation(self, text, confidence=0.7):
        text = str(text).strip()
        prefixes = ("aprende:", "aprende esto:", "recuerda:", "recuerda esto:")
        knowledge = None
        for prefix in prefixes:
            if text.lower().startswith(prefix):
                knowledge = text[len(prefix):].strip()
                break
        if not knowledge:
            return {"learned": False, "reason": "No se detectó una instrucción de aprendizaje."}
        result = self.learn_fact(
            knowledge, source="conversation", confidence=confidence, evidence=text
        )
        return {"learned": bool(result.get("success")), **result}

    def confirm_knowledge(self, entry_id, evidence=None):
        entry = self.memory.confirm(entry_id, evidence=evidence)
        return (
            {"confirmed": True, "entry": entry}
            if entry else {"confirmed": False, "reason": "No encontré esa memoria."}
        )

    def correct_knowledge(self, entry_id, new_knowledge, evidence=None):
        entry = self.memory.correct(entry_id, new_knowledge, evidence=evidence)
        return (
            {"corrected": True, "entry": entry}
            if entry else {"corrected": False, "reason": "No encontré esa memoria."}
        )

    def reinforce_knowledge(self, entry_id, amount=0.05, evidence=None):
        entry = self.memory.reinforce(entry_id, amount, evidence=evidence)
        return (
            {"reinforced": True, "entry": entry}
            if entry else {"reinforced": False, "reason": "No encontré esa memoria."}
        )

    def evaluate(self, query, threshold=0.65, limit=10):
        matches = self.memory.search(query, limit=limit)
        if not matches:
            return {"success": True, "known": False, "confidence": 0.0, "matches": []}
        best = matches[0]
        confidence = round(float(best.get("retrieval_score", 0.0)), 3)
        return {
            "success": True,
            "known": confidence >= float(threshold),
            "confidence": confidence,
            "matches": matches,
        }

    def recall(self, query, limit=10, tags=None, category=None):
        return {
            "success": True,
            "query": query,
            "matches": self.memory.search(
                query, limit=limit, tags=tags, category=category
            ),
        }

    def associate(self, entry_a, entry_b, relation="related", strength=0.5):
        return self.memory.associate(entry_a, entry_b, relation, strength)

    def detect_contradiction(self, entry_id, knowledge, source="inference", confidence=0.5, evidence=None):
        return self.memory.contradict(
            entry_id, knowledge, source=source,
            confidence=confidence, evidence=evidence,
        )

    def forget(self, entry_id, reason="forgotten"):
        return self.memory.archive_entry(entry_id, reason=reason)

    def get_memory(self, entry_id):
        entry = self.memory.get(entry_id)
        return {"success": bool(entry), "entry": entry}

    def related(self, entry_id, limit=10):
        return {"success": True, "entries": self.memory.recall_related(entry_id, limit)}

    def stats(self):
        return {"success": True, "memory": self.memory.stats()}

    def learn_experience(self, event_type, content, context=None, importance=0.5):
        episode = self.memory.record_episode(
            event_type, content, context=context, importance=importance
        )
        return {"success": True, "episode": episode}

    def recall_context(self, query, limit=5):
        return {"success": True, "context": self.memory.build_context(query, limit=limit)}

    def merge_memories(self, primary_id, secondary_id):
        return self.memory.merge(primary_id, secondary_id)

    def decay_report(self):
        return {"success": True, "memories": self.memory.decay_report()}

    def recent_experiences(self, limit=20):
        return {"success": True, "episodes": self.memory.recent_episodes(limit)}

    def consolidate(self):
        """Consolida métricas sin destruir información.
        Las memorias activas se mantienen; la confianza efectiva considera recencia.
        """
        entries = self.memory.all()
        high = [e for e in entries if e.get("confidence", 0.0) >= 0.8]
        uncertain = [e for e in entries if 0.0 < e.get("confidence", 0.0) < 0.8]
        return {
            "success": True,
            "total": len(entries),
            "high_confidence": len(high),
            "uncertain": len(uncertain),
            "stats": self.memory.stats(),
            "entries": entries,
        }
