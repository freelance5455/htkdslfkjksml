
import json
from datetime import datetime, timezone
from pathlib import Path

class AutobiographicalMemory:
    """Memoria persistente de experiencias relevantes y aprendizajes resumidos."""
    def __init__(self, path="core/memory/autobiography.json", limit=5000):
        self.path=Path(path); self.limit=int(limit); self.items=[]; self.load()
    def _now(self): return datetime.now(timezone.utc).isoformat()
    def load(self):
        try:
            if self.path.exists():
                data=json.loads(self.path.read_text(encoding="utf-8"))
                self.items=data if isinstance(data,list) else data.get("items",[])
        except (OSError,json.JSONDecodeError):
            self.items=[]
    def save(self):
        self.path.parent.mkdir(parents=True,exist_ok=True)
        tmp=self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.items[-self.limit:],ensure_ascii=False,indent=2),encoding="utf-8")
        tmp.replace(self.path)
    def remember(self, kind, summary, *, context=None, outcome=None, lesson=None, importance=.5, confidence=.5):
        item={"id":len(self.items)+1,"timestamp":self._now(),"kind":str(kind),
              "summary":str(summary),"context":dict(context or {}),"outcome":outcome,
              "lesson":lesson,"importance":max(0,min(1,float(importance))),
              "confidence":max(0,min(1,float(confidence)))}
        self.items.append(item); self.save(); return item
    def recall(self, query="", limit=10):
        tokens=[x for x in str(query).lower().split() if x]
        scored=[]
        for item in self.items:
            text=(item["summary"]+" "+str(item.get("lesson") or "")+" "+json.dumps(item.get("context",{}),ensure_ascii=False)).lower()
            score=sum(1 for t in tokens if t in text) if tokens else 0
            score += item.get("importance",.5)*.1
            if score>0 or not tokens: scored.append((score,item))
        scored.sort(key=lambda x:(x[0],x[1]["timestamp"]),reverse=True)
        return [dict(x, relevance=round(score,3)) for score,x in scored[:max(1,int(limit))]]
    def learn_from_outcome(self, goal, success, lesson, context=None):
        return self.remember("learning", f"Resultado de objetivo: {goal}", context=context,
                             outcome=bool(success), lesson=lesson, importance=.8,
                             confidence=.8 if success else .6)
    def snapshot(self):
        return {"count":len(self.items),"recent":self.items[-10:]}
