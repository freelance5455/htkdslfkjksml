from datetime import datetime, timezone

class WorldModel:
    """Modelo ligero y explícito del entorno conocido por N.O.V.A."""
    def __init__(self):
        self.entities = {}
        self.events = []

    def observe(self, entity, attributes=None, source="internal"):
        key = str(entity).strip()
        if not key:
            return None
        self.entities[key] = {
            "attributes": dict(attributes or {}),
            "source": str(source),
            "updated_at": datetime.now(timezone.utc).isoformat(),
        }
        return self.entities[key]

    def event(self, event_type, data=None):
        item = {
            "type": str(event_type),
            "data": dict(data or {}),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        self.events.append(item)
        self.events = self.events[-64:]
        return item

    def get(self, entity):
        return self.entities.get(str(entity))

    def snapshot(self):
        return {"entities": dict(self.entities), "recent_events": list(self.events[-16:])}
