import json
from datetime import datetime, timezone
from pathlib import Path

class CognitiveState:
    """Estado cognitivo persistente y resumido; no almacena cadenas privadas de razonamiento."""
    def __init__(self, path="core/state/cognitive_state.json"):
        self.path = Path(path)
        self.data = {
            "cycle": 0, "mode": "idle", "focus": None,
            "uncertainty": 1.0, "confidence": 0.0,
            "active_intentions": [], "last_event": None,
            "learned_count": 0, "reflection_count": 0,
        }
        self.load()

    def _now(self):
        return datetime.now(timezone.utc).isoformat()

    def load(self):
        try:
            if self.path.exists():
                value = json.loads(self.path.read_text(encoding="utf-8"))
                if isinstance(value, dict):
                    self.data.update(value)
        except (OSError, json.JSONDecodeError):
            pass

    def save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.data, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(self.path)

    def begin(self, focus=None):
        self.data["cycle"] = int(self.data.get("cycle", 0)) + 1
        self.data["mode"] = "thinking"
        self.data["focus"] = focus
        self.data["last_event"] = self._now()
        self.save()
        return self.snapshot()

    def update(self, **values):
        self.data.update(values)
        self.data["last_event"] = self._now()
        self.save()
        return self.snapshot()

    def reflect(self, confidence, uncertainty):
        self.data["confidence"] = max(0.0, min(1.0, float(confidence)))
        self.data["uncertainty"] = max(0.0, min(1.0, float(uncertainty)))
        self.data["reflection_count"] = int(self.data.get("reflection_count", 0)) + 1
        self.data["mode"] = "reflecting"
        self.data["last_event"] = self._now()
        self.save()
        return self.snapshot()

    def snapshot(self):
        return dict(self.data)
