class AttentionSystem:
    """Selecciona el foco cognitivo sin pretender ser atención humana real."""
    PRIORITY_WORDS = {
        "urgente": 1.0, "error": 0.95, "fallo": 0.95,
        "seguridad": 0.95, "importante": 0.8, "ahora": 0.75,
        "necesito": 0.7, "objetivo": 0.7,
    }

    def focus(self, text, memories=None, goals=None):
        text = str(text)
        low = text.lower()
        score = 0.1
        reasons = []
        for word, value in self.PRIORITY_WORDS.items():
            if word in low:
                score = max(score, value)
                reasons.append(word)
        if memories:
            score = max(score, min(0.9, 0.3 + 0.05 * len(memories)))
            reasons.append("memoria_relevante")
        if goals:
            score = max(score, 0.6)
            reasons.append("objetivo_activo")
        return {
            "focus": text[:300],
            "salience": round(min(1.0, score), 3),
            "reasons": reasons,
        }
