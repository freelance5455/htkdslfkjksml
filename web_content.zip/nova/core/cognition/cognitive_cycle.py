from .cognitive_state import CognitiveState
from .working_memory import WorkingMemory
from .attention import AttentionSystem
from .self_model import SelfModel
from .world_model import WorldModel
from .reasoning_engine import ReasoningEngine
from .reflection import ReflectionEngine
from .affective_appraisal import AffectiveAppraisal

class CognitiveCycle:
    """Integra percepción, memoria de trabajo, atención, razonamiento y reflexión."""
    def __init__(self, state=None, memory=None, goals=None):
        self.state = state or CognitiveState()
        self.working = WorkingMemory()
        self.attention = AttentionSystem()
        self.self_model = SelfModel()
        self.world = WorldModel()
        self.reasoning = ReasoningEngine()
        self.reflection = ReflectionEngine()
        self.appraisal = AffectiveAppraisal()
        self.memory = memory
        self.goals = goals

    def begin(self, user_input):
        self.state.begin(user_input)
        self.self_model.update(state="thinking")
        self.working.push("input", user_input, importance=0.8)
        memories = self.memory.search(user_input, limit=8) if self.memory else []
        active_goals = self.goals.active() if self.goals else []
        attention = self.attention.focus(user_input, memories, active_goals)
        reasoning = self.reasoning.infer(
            user_input, memories=memories,
            context={"active_goals": active_goals},
        )
        self.working.push("attention", attention["focus"], attention["salience"], attention)
        self.working.push("reasoning_summary", reasoning["hypothesis"], reasoning["confidence"], {
            "uncertainty": reasoning["uncertainty"],
        })
        self.world.event("cognitive_cycle_started", {"focus": attention["focus"]})
        self.state.reflect(reasoning["confidence"], reasoning["uncertainty"])
        return {
            "cycle": self.state.data["cycle"],
            "attention": attention,
            "reasoning": reasoning,
            "working_memory": self.working.recent(8),
            "self_model": self.self_model.snapshot(),
        }

    def finish(self, success, response):
        self.working.push("result", response, 0.7, {"success": bool(success)})
        self.self_model.update(state="idle")
        reflection=self.reflection.reflect(self.state.data.get('focus'), success, self.state.data.get('confidence',0.0))
        appraisal=self.appraisal.evaluate(success, novelty=0.2, uncertainty=self.state.data.get('uncertainty',0.5))
        self.self_model.reflect(success, self.state.data.get('confidence',0.0))
        self.world.event("cognitive_cycle_finished", {"success": bool(success), "reflection": reflection})
        self.state.update(mode="idle", last_result=bool(success))
        return self.snapshot()

    def snapshot(self):
        return {
            "state": self.state.snapshot(),
            "working_memory": self.working.recent(8),
            "self_model": self.self_model.snapshot(),
            "world_model": self.world.snapshot(),
            "reflection": reflection if "reflection" in locals() else None,
            "appraisal": appraisal if "appraisal" in locals() else None,
        }
