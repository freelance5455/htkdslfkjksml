from collections import deque
from datetime import datetime, timezone

class WorkingMemory:
    """Memoria de trabajo limitada para mantener el contexto inmediato."""
    def __init__(self, capacity=16):
        self.capacity = max(4, int(capacity))
        self.items = deque(maxlen=self.capacity)

    def _now(self):
        return datetime.now(timezone.utc).isoformat()

    def push(self, kind, content, importance=0.5, metadata=None):
        item = {
            "kind": str(kind),
            "content": str(content),
            "importance": max(0.0, min(1.0, float(importance))),
            "metadata": dict(metadata or {}),
            "timestamp": self._now(),
        }
        self.items.append(item)
        return dict(item)

    def recent(self, limit=8):
        return list(self.items)[-max(1, int(limit)):]

    def relevant(self, query, limit=6):
        tokens = set(str(query).lower().split())
        scored = []
        for item in self.items:
            text = item["content"].lower()
            overlap = sum(1 for token in tokens if token and token in text)
            score = overlap + item["importance"] * 0.25
            if score > 0:
                scored.append((score, item))
        scored.sort(key=lambda pair: pair[0], reverse=True)
        return [dict(item, relevance=round(score, 3)) for score, item in scored[:limit]]

    def clear(self):
        self.items.clear()
