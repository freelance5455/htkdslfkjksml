import re

class ReasoningEngine:
    """Razonamiento estructurado con hipótesis, alternativas, supuestos y verificación."""
    def infer(self,query,memories=None,context=None):
        query=str(query).strip(); memories=list(memories or []); context=dict(context or {})
        evidence=[{"source":i.get("source","memory"),"text":i.get("knowledge",""),
                   "confidence":float(i.get("confidence",0.0))} for i in memories[:8] if i.get("knowledge")]
        best=max(evidence,key=lambda x:x["confidence"],default=None)
        confidence=max(0.15,min(0.95,best["confidence"] if best else 0.15))
        hypothesis=("La evidencia almacenada es relevante." if best else
                    "No hay evidencia suficiente; hace falta contexto, observación o herramienta.")
        alternatives=["pedir contexto","buscar evidencia adicional","verificar el resultado"]
        if best: alternatives=["comparar recuerdos","buscar contradicciones","verificar fuente"]
        return {"query":query,"hypothesis":hypothesis,"evidence":evidence,
                "confidence":round(confidence,3),"uncertainty":round(1-confidence,3),
                "assumptions":self._assumptions(query),
                "alternatives":alternatives,
                "decision_rule":"usar la opción con mejor evidencia y verificar antes de afirmar",
                "next_steps":alternatives}
    def _assumptions(self,q):
        a=[]
        if len(q.split())<3:a.append("La intención puede requerir contexto adicional.")
        if re.search(r"\b(hoy|ahora|actual|último|ultimo|reciente)\b",q.lower()):
            a.append("La información temporal debe verificarse con una fuente actual.")
        return a
