class AffectiveAppraisal:
    """Variables funcionales de estado; no afirma emociones humanas."""
    def evaluate(self, success, novelty=0.0, uncertainty=0.5, goal_relevance=0.5):
        return {
            "valence": round((0.6 if success else -0.4) + 0.2*float(goal_relevance),3),
            "arousal": round(max(0,min(1,0.3+float(novelty)*0.4+float(uncertainty)*0.3)),3),
            "curiosity": round(max(0,min(1,float(novelty)*(1-float(uncertainty))+0.2)),3),
            "label":"positive-progress" if success else "error-learning"
        }
