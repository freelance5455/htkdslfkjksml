class ReflectionEngine:
    """Reflexión resumida sobre resultados; almacena conclusiones, no cadenas privadas de pensamiento."""
    def reflect(self, goal, success, confidence, errors=None):
        errors=list(errors or [])
        lessons=[]
        if success: lessons.append("La estrategia produjo un resultado exitoso; puede reutilizarse tras verificar el contexto.")
        else: lessons.append("La estrategia no produjo el resultado esperado; debe diagnosticarse antes de repetirla.")
        if confidence < 0.5: lessons.append("La confianza era baja; conviene obtener evidencia adicional.")
        return {"goal":goal,"success":bool(success),"confidence":float(confidence),
                "lessons":lessons,"errors":errors,"next_action":"verify" if success else "diagnose"}
