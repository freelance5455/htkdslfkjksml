
import json
from pathlib import Path
from datetime import datetime, timezone

class SelfModel:
    """Modelo operativo persistente de identidad, capacidades, límites y estado."""
    def __init__(self, path="core/state/self_model.json"):
        self.path=Path(path)
        self.identity={"name":"N.O.V.A.","role":"asistente cognitivo autónomo","version":"4.0-cognitive"}
        self.capabilities=set()
        self.limitations={"conciencia humana no demostrada","acceso externo requiere autorización"}
        self.current_state="idle"; self.last_goal=None
        self.internal_drives={"curiosity":.5,"confidence":.5,"uncertainty":.5,"urgency":0.0,"satisfaction":.5}
        self.self_assessment={"strengths":[],"weaknesses":[],"last_reflection":None,"history":[]}
        self.load()
    def _now(self): return datetime.now(timezone.utc).isoformat()
    def load(self):
        try:
            if self.path.exists():
                d=json.loads(self.path.read_text(encoding="utf8"))
                self.identity.update(d.get("identity",{})); self.capabilities=set(d.get("capabilities",[]))
                self.limitations.update(d.get("limitations",[])); self.current_state=d.get("current_state","idle")
                self.last_goal=d.get("last_goal"); self.internal_drives.update(d.get("internal_drives",{}))
                self.self_assessment.update(d.get("self_assessment",{}))
        except (OSError,json.JSONDecodeError): pass
    def save(self):
        self.path.parent.mkdir(parents=True,exist_ok=True)
        tmp=self.path.with_suffix(".tmp"); tmp.write_text(json.dumps(self.snapshot(),ensure_ascii=False,indent=2),encoding="utf8"); tmp.replace(self.path)
    def register_capabilities(self,names): self.capabilities.update(str(x) for x in names if x); self.save(); return self.snapshot()
    def register_limitations(self,names): self.limitations.update(str(x) for x in names if x); self.save(); return self.snapshot()
    def update(self,state=None,goal=None):
        if state is not None:self.current_state=str(state)
        if goal is not None:self.last_goal=str(goal)
        self.save(); return self.snapshot()
    def update_drive(self,name,value):
        self.internal_drives[str(name)]=max(0,min(1,float(value))); self.save(); return self.snapshot()
    def reflect(self,success,confidence,lesson=None):
        confidence=max(0,min(1,float(confidence)))
        self.internal_drives["confidence"]=confidence; self.internal_drives["uncertainty"]=1-confidence
        self.internal_drives["satisfaction"]=.75 if success else .3
        item={"timestamp":self._now(),"success":bool(success),"confidence":confidence,"lesson":lesson}
        self.self_assessment["last_reflection"]=item
        self.self_assessment.setdefault("history",[]).append(item); self.self_assessment["history"]=self.self_assessment["history"][-50:]
        self.save(); return self.snapshot()
    def knows_capability(self,name): return str(name) in self.capabilities
    def snapshot(self):
        return {**self.identity,"current_state":self.current_state,"last_goal":self.last_goal,
                "capabilities":sorted(self.capabilities),"limitations":sorted(self.limitations),
                "internal_drives":dict(self.internal_drives),"self_assessment":dict(self.self_assessment)}
