from core.runtime.cognitive_runtime import CognitiveRuntime


class NOVA:
    def __init__(self):
        self.name = "N.O.V.A."
        self.version = "4.0-cognitive"
        self.runtime = CognitiveRuntime()

    def respond(self, command):
        result = self.runtime.process(command)
        return result.get("response", "No pude generar una respuesta.")


def main():
    nova = NOVA()
    print(f"{nova.name} v{nova.version}")
    print("Núcleo conversacional y autónomo iniciado.")
    print("Puedes preguntarme cosas o darme órdenes. Escribe 'salir' para terminar.")
    while True:
        try:
            command = input("> ")
        except (EOFError, KeyboardInterrupt):
            print("\nN.O.V.A.: Núcleo detenido.")
            break
        if command.strip().lower() in ("salir", "exit", "quit"):
            print("N.O.V.A.: Núcleo detenido.")
            break
        print(f"N.O.V.A.: {nova.respond(command)}")


if __name__ == "__main__":
    main()
