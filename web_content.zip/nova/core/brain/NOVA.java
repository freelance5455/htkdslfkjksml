package core.brain;

import tools.system.ProjectTool;
import java.util.Scanner;

public class NOVA {
    private final String name = "N.O.V.A.";
    private final String version = "0.2.0";

    public String respond(String command) {
        command = command.trim();

        if (command.isEmpty()) {
            return "No recibí ninguna orden.";
        }

        String lower = command.toLowerCase();

        if (lower.startsWith("crea un proyecto")) {
            String projectName = command.substring("crea un proyecto".length()).trim();

            if (projectName.isEmpty()) {
                return "Necesito un nombre para el proyecto.";
            }

            return ProjectTool.createProject(projectName);
        }

        return "Todavía no sé ejecutar esa orden: " + command;
    }

    public static void main(String[] args) {
        NOVA nova = new NOVA();
        Scanner scanner = new Scanner(System.in);

        System.out.println(nova.name + " v" + nova.version);
        System.out.println("Núcleo iniciado.");
        System.out.println("Escribe una orden o 'salir' para terminar.");

        while (true) {
            System.out.print("> ");
            String command = scanner.nextLine();

            if (command.equalsIgnoreCase("salir") ||
                command.equalsIgnoreCase("exit") ||
                command.equalsIgnoreCase("quit")) {
                System.out.println("N.O.V.A.: Núcleo detenido.");
                break;
            }

            System.out.println("N.O.V.A.: " + nova.respond(command));
        }

        scanner.close();
    }
}
