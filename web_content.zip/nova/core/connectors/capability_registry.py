class CapabilityRegistry:
    def __init__(self):
        self._items = {}

    def register_connector(self, connector):
        self._items[connector.name] = {
            "version": connector.version,
            "capabilities": list(connector.capabilities()),
        }

    def register_manager(self, manager):
        for connector in manager._connectors.values():
            self.register_connector(connector)

    def list_all(self):
        return {name: dict(value) for name, value in self._items.items()}

    def find(self, capability):
        found = []
        for name, data in self._items.items():
            if capability in data["capabilities"]:
                found.append({"connector": name, "capability": capability})
        return found
