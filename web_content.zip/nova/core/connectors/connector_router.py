class ConnectorRouter:
    def __init__(self, manager, registry):
        self.manager = manager
        self.registry = registry

    def find_connector(self, capability):
        matches = self.registry.find(capability)
        if not matches:
            return {"success": False, "error": f"No existe un conector para: {capability}"}
        return {"success": True, **matches[0]}

    def execute(self, capability, **kwargs):
        route = self.find_connector(capability)
        if not route.get("success"):
            return route
        return self.manager.execute(route["connector"], capability, **kwargs)
