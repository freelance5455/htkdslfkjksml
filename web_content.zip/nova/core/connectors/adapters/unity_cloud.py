from core.connectors.base_connector import BaseConnector

class UnityCloudConnector(BaseConnector):
    """Adaptador seguro; requiere credenciales configuradas por el usuario."""
    name = "unity_cloud"
    version = "1.0"

    def capabilities(self):
        return ["cloud_status","list_builds","start_build","build_status","cancel_build","download_build"]

    def status(self):
        return {
            "name": self.name, "version": self.version,
            "connected": False, "authenticated": False,
            "provider": "Unity Build Automation",
            "capabilities": self.capabilities(),
        }

    def execute(self, action, **kwargs):
        return {
            "success": False, "connected": False, "authenticated": False,
            "connector": self.name, "action": action,
            "error": "Unity Cloud aún no está autenticado. Configura credenciales mediante el flujo de permisos.",
            "requires_authorization": True,
        }
