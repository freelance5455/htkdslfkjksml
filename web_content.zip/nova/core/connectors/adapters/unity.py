from core.connectors.base_connector import BaseConnector
from core.engines.unity_bridge import UnityBridge

class UnityConnector(BaseConnector):
    name = "unity"
    version = "1.0"

    def __init__(self, bridge=None):
        self.bridge = bridge or UnityBridge()

    def capabilities(self):
        return [
            "ping", "create_project", "create_scene", "create_primitive",
            "create_gameobject", "set_transform", "delete_object",
        ]

    def status(self):
        result = self.bridge.ping()
        return {
            "name": self.name, "version": self.version,
            "connected": bool(result.get("connected") or result.get("success")),
            "capabilities": self.capabilities(), "bridge": result,
        }

    def execute(self, action, **kwargs):
        if action == "ping":
            return self.bridge.ping()
        if action == "create_project":
            return self.bridge.create_unity_project(kwargs.get("project", "nova_unity_3d"))
        if action == "create_scene":
            return self.bridge.create_scene()
        if action == "create_primitive":
            return self.bridge.create_primitive(
                kwargs.get("primitive", "Cube"),
                kwargs.get("name", "NOVA_Object"),
                kwargs.get("position", (0,0,0)),
            )
        if action in {"create_gameobject", "set_transform", "delete_object"}:
            payload = dict(kwargs)
            payload["action"] = action
            return self.bridge.send(payload)
        return {"success": False, "error": f"Acción Unity no soportada: {action}"}
