class ConnectorManager:
    def __init__(self):
        self._connectors = {}

    def register(self, connector):
        name = getattr(connector, "name", None)
        if not name:
            raise ValueError("El conector necesita un nombre.")
        self._connectors[name] = connector
        return connector

    def unregister(self, name):
        return self._connectors.pop(name, None)

    def get(self, name):
        return self._connectors.get(name)

    def list_connectors(self):
        return [connector.status() for connector in self._connectors.values()]

    def execute(self, connector_name, action, **kwargs):
        connector = self.get(connector_name)
        if connector is None:
            return {"success": False, "error": f"Conector no registrado: {connector_name}"}
        try:
            result = connector.execute(action, **kwargs)
            return result if isinstance(result, dict) else {"success": True, "result": result}
        except Exception as exc:
            return {"success": False, "connector": connector_name, "action": action,
                    "error": f"{type(exc).__name__}: {exc}"}
