class BaseConnector:
    name = "unknown"
    version = "1.0"

    def capabilities(self):
        return []

    def status(self):
        return {
            "name": self.name,
            "version": self.version,
            "connected": False,
            "capabilities": self.capabilities(),
        }

    def execute(self, action, **kwargs):
        raise NotImplementedError(f"Connector {self.name} no implementa {action}")
