from .connector_manager import ConnectorManager
from .capability_registry import CapabilityRegistry
from .connector_router import ConnectorRouter
from .base_connector import BaseConnector

def create_default_manager():
    from .adapters.unity import UnityConnector
    from .adapters.unity_cloud import UnityCloudConnector
    manager = ConnectorManager()
    manager.register(UnityConnector())
    manager.register(UnityCloudConnector())
    return manager
