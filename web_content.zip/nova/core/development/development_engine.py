from pathlib import Path

class DevelopmentEngine:
    """Motor de desarrollo autónomo de N.O.V.A."""

    DEVELOPMENT_TOOLS = (
        "inspect_project",
        "analyze_codebase",
        "read_file",
        "generate_code",
        "edit_project",
        "compile_project",
        "run_tests",
        "debug_project",
        "build_project",
        "verify_result",
    )

    def __init__(self, executor=None):
        self.executor = executor

    def create_plan(self, project, instruction):
        if not isinstance(project, str) or not project.strip():
            return {"success": False, "error": "Falta el proyecto."}

        if not isinstance(instruction, str) or not instruction.strip():
            return {"success": False, "error": "Falta la instrucción de desarrollo."}

        return {
            "success": True,
            "project": project.strip(),
            "instruction": instruction.strip(),
            "status": "planned",
            "steps": [
                {"order": 1, "tool": "inspect_project", "purpose": "Conocer la estructura actual del proyecto."},
                {"order": 2, "tool": "analyze_codebase", "purpose": "Analizar el código existente."},
                {"order": 3, "tool": "read_file", "purpose": "Leer los archivos relevantes antes de modificarlos."},
                {"order": 4, "tool": "edit_project", "purpose": "Aplicar los cambios necesarios."},
                {"order": 5, "tool": "compile_project", "purpose": "Comprobar que el proyecto compila."},
                {"order": 6, "tool": "run_tests", "purpose": "Ejecutar las pruebas disponibles."},
                {"order": 7, "tool": "verify_result", "purpose": "Verificar el resultado final."},
            ],
        }

    def inspect(self, project):
        if not isinstance(project, str) or not project.strip():
            return {
                "success": False,
                "error": "Falta el proyecto.",
            }

        from core.runtime.tool_catalog import inspect_project_tool

        project_name = project.strip()
        project_path = Path(project_name)

        if not project_path.exists():
            current_project = Path.cwd().resolve()
            if project_name.lower() == current_project.name.lower():
                project_path = current_project

        result = inspect_project_tool(str(project_path))

        return {
            "success": bool(result.get("success")),
            "project": project.strip(),
            "inspection": result,
        }

    def analyze(self, project):
        if not isinstance(project, str) or not project.strip():
            return {
                "success": False,
                "error": "Falta el proyecto.",
            }

        from core.runtime.advanced_tool_handlers import analyze_codebase_tool

        project_name = project.strip()
        project_path = Path(project_name)

        if not project_path.exists():
            current_project = Path.cwd().resolve()
            if project_name.lower() == current_project.name.lower():
                project_path = current_project

        result = analyze_codebase_tool(str(project_path))

        return {
            "success": bool(result.get("success")),
            "project": project_name,
            "analysis": result,
        }

    def diagnose(self, project, instruction=None):
        if not isinstance(project, str) or not project.strip():
            return {
                "success": False,
                "error": "Falta el proyecto.",
            }

        inspection = self.inspect(project)

        if not inspection.get("success"):
            return {
                "success": False,
                "stage": "inspection",
                "error": inspection["inspection"].get("error"),
            }

        analysis = self.analyze(project)

        if not analysis.get("success"):
            return {
                "success": False,
                "stage": "analysis",
                "error": analysis["analysis"].get("error"),
            }

        plan = self.create_plan(
            project,
            instruction or "Diagnóstico y preparación del proyecto",
        )

        from core.development.change_planner import ChangePlanner

        change_plan = ChangePlanner().create_change_plan(
            project,
            instruction or "Diagnóstico y preparación del proyecto",
            analysis=analysis["analysis"],
        )

        from core.development.change_generator import ChangeGenerator

        generated_changes = ChangeGenerator().generate(
            project,
            change_plan,
        )

        return {
            "success": True,
            "project": project.strip(),
            "inspection": inspection["inspection"],
            "analysis": analysis["analysis"],
            "plan": plan,
            "change_plan": change_plan,
            "generated_changes": generated_changes,
            "status": "diagnosed",
        }

    def execute_tool(self, tool_name, *args, **kwargs):
        if tool_name not in self.DEVELOPMENT_TOOLS:
            return {
                "success": False,
                "tool": tool_name,
                "error": "Herramienta no autorizada por el motor de desarrollo.",
            }

        if self.executor is None:
            return {
                "success": False,
                "tool": tool_name,
                "error": "El ejecutor central todavía no está conectado.",
            }

        return self.executor.execute(tool_name, *args, **kwargs)

    def execute_step(self, step, project, authorization=None):
        if not isinstance(step, dict):
            return {
                "success": False,
                "error": "El paso de desarrollo es inválido.",
            }

        tool_name = step.get("tool")

        read_only_tools = {
            "inspect_project",
            "analyze_codebase",
            "read_file",
            "verify_result",
        }

        write_tools = {
            "edit_project",
            "generate_code",
        }

        if tool_name in write_tools:
            if not isinstance(authorization, dict):
                return {
                    "success": False,
                    "tool": tool_name,
                    "blocked": True,
                    "error": "Se requiere autorización de escritura.",
                }

            if not authorization.get("authorized"):
                return {
                    "success": False,
                    "tool": tool_name,
                    "blocked": True,
                    "error": "La autorización de escritura no es válida.",
                }

            if tool_name not in authorization.get("allowed_tools", set()):
                return {
                    "success": False,
                    "tool": tool_name,
                    "blocked": True,
                    "error": "La herramienta no está autorizada.",
                }

            if authorization.get("scope") != "project_only":
                return {
                    "success": False,
                    "tool": tool_name,
                    "blocked": True,
                    "error": "El alcance de escritura no es válido.",
                }

            if tool_name == "edit_project":
                relative_path = step.get("path")
                content = step.get("content")

                project_path = Path(project)

                if not project_path.exists():
                    current_project = Path.cwd().resolve()
                    if project.strip().lower() == current_project.name.lower():
                        project_path = current_project

                project = str(project_path)

                if not isinstance(relative_path, str) or not relative_path.strip():
                    return {
                        "success": False,
                        "tool": tool_name,
                        "error": "Falta la ruta del archivo a editar.",
                    }

                if content is None:
                    return {
                        "success": False,
                        "tool": tool_name,
                        "error": "Falta el contenido del archivo.",
                    }

                return self.execute_tool(
                    tool_name,
                    project,
                    relative_path,
                    content,
                )

            if tool_name == "generate_code":
                target_path = step.get("path")
                content = step.get("content")

                if not isinstance(target_path, str) or not target_path.strip():
                    return {
                        "success": False,
                        "tool": tool_name,
                        "error": "Falta la ruta del archivo a generar.",
                    }

                if content is None:
                    return {
                        "success": False,
                        "tool": tool_name,
                        "error": "Falta el contenido del código.",
                    }

                return self.execute_tool(
                    tool_name,
                    target_path,
                    content,
                    overwrite=bool(step.get("overwrite", False)),
                )

        if tool_name not in read_only_tools:
            return {
                "success": False,
                "tool": tool_name,
                "blocked": True,
                "error": "Este paso requiere autorización adicional.",
            }

        if tool_name == "inspect_project":
            return self.execute_tool(
                tool_name,
                project,
            )

        if tool_name == "analyze_codebase":
            project_path = Path(project)

            if not project_path.exists():
                current_project = Path.cwd().resolve()
                if project.lower() == current_project.name.lower():
                    project_path = current_project

            return self.execute_tool(
                tool_name,
                str(project_path),
            )

        return {
            "success": False,
            "tool": tool_name,
            "error": "El paso todavía no tiene parámetros automáticos.",
        }

    def authorize_write(self, project, instruction):
        if not isinstance(project, str) or not project.strip():
            return {
                "success": False,
                "authorized": False,
                "error": "Falta el proyecto.",
            }

        if not isinstance(instruction, str) or not instruction.strip():
            return {
                "success": False,
                "authorized": False,
                "error": "Falta la instrucción.",
            }

        return {
            "success": True,
            "authorized": True,
            "project": project.strip(),
            "instruction": instruction.strip(),
            "allowed_tools": {
                "generate_code",
                "edit_project",
            },
            "scope": "project_only",
        }
    def _resolve_project(self, project):
        """Resuelve el nombre del proyecto sin duplicar la ruta."""
        project_path = Path(project)

        if project_path.is_dir():
            return project_path.resolve()

        current_project = Path.cwd().resolve()

        if project_path.name.lower() == current_project.name.lower():
            return current_project

        return project_path.resolve()

    def apply_generated_changes(self, project, diagnosis):
        """Aplica únicamente las propuestas producidas por el diagnóstico."""
        if not isinstance(diagnosis, dict) or not diagnosis.get("success"):
            return {
                "success": False,
                "error": "El diagnóstico no es válido.",
            }

        generated = diagnosis.get("generated_changes", {})

        if not generated.get("success"):
            return {
                "success": False,
                "error": "La generación de cambios no fue exitosa.",
            }

        proposals = generated.get("proposals", [])

        from core.development.change_applier import ChangeApplier

        instruction = (
            diagnosis.get("instruction")
            or diagnosis.get("change_plan", {}).get("instruction")
            or ""
        )

        authorization = self.authorize_write(
            project,
            instruction,
        )

        if not authorization.get("authorized"):
            return {
                "success": False,
                "error": "Los cambios no fueron autorizados.",
                "authorization": authorization,
            }

        result = ChangeApplier().apply(
            project,
            proposals,
            authorization=authorization,
        )

        proposal_count = len(proposals)
        applied_count = int(result.get("applied_count", 0))
        application_success = bool(
            result.get("success")
            and applied_count == proposal_count
        )

        return {
            "success": application_success,
            "application": result,
            "proposals": proposal_count,
            "applied": applied_count,
        }

    def develop(self, project, instruction):
        """Ejecuta una misión completa de desarrollo de forma controlada."""
        if self.executor is None:
            from core.runtime.tool_catalog import build_tool_registry
            from core.runtime.tool_executor import ToolExecutor

            self.executor = ToolExecutor(build_tool_registry())

        project = str(self._resolve_project(project))
        diagnosis = self.diagnose(project, instruction)

        if not diagnosis.get("success"):
            return {
                "success": False,
                "stage": "diagnosis",
                "result": diagnosis,
            }

        plan = diagnosis["plan"]
        authorization = self.authorize_write(project, instruction)

        if not authorization.get("success"):
            return {
                "success": False,
                "stage": "authorization",
                "result": authorization,
            }

        application = self.apply_generated_changes(
            project,
            diagnosis,
        )

        if not application.get("success"):
            return {
                "success": False,
                "stage": "change_application",
                "result": application,
                "diagnosis": diagnosis,
                "authorization": authorization,
            }

        planned_changes = [
            change for change in diagnosis.get("change_plan", {}).get("changes", [])
            if change.get("action") in {"create", "update"}
        ]

        steps = plan.get("steps", [])
        execution = []

        for step in steps:
            tool_name = step.get("tool")

            if tool_name in {"inspect_project", "analyze_codebase"}:
                result = self.execute_step(
                    step,
                    project,
                    authorization,
                )
                execution.append({
                    "order": step.get("order"),
                    "tool": tool_name,
                    "result": result,
                })

        compile_result = self.execute_tool(
            "compile_project",
            project,
        )

        test_result = self.execute_tool(
            "run_tests",
            project,
        )

        compile_ok = bool(
            compile_result.get("success")
            and isinstance(compile_result.get("result"), dict)
            and compile_result["result"].get("success")
        )

        test_data = test_result.get("result", test_result)
        tests_ok = bool(
            test_result.get("success")
            and isinstance(test_data, dict)
            and test_data.get("success")
            and int(test_data.get("tests_found", 0)) > 0
        )

        verification_input = {
            "compile": compile_result.get("result", compile_result),
            "tests": test_data,
            "execution": execution,
            "application": application,
            "planned_changes": planned_changes,
        }

        verification = self.execute_tool(
            "verify_result",
            verification_input,
        )

        verification_ok = bool(
            verification.get("success")
            and isinstance(verification.get("result"), dict)
            and verification["result"].get("verified")
        )

        application_ok = bool(
            application.get("success")
            and application.get("applied", 0) == application.get("proposals", 0)
        )

        return {
            "success": bool(
                compile_ok
                and tests_ok
                and verification_ok
                and application_ok
            ),
            "project": str(Path(project).resolve()),
            "instruction": instruction,
            "status": "development_completed",
            "diagnosis": diagnosis,
            "authorization": authorization,
            "application": application,
            "execution": execution,
            "compile": compile_result,
            "tests": test_result,
            "verification": verification,
        }
