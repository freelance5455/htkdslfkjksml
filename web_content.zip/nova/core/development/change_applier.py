from pathlib import Path


class ChangeApplier:
    """Aplica de forma controlada las propuestas generadas por N.O.V.A."""

    def __init__(self, tool_executor=None):
        self.tool_executor = tool_executor

    def apply(self, project, proposals, authorization=None):
        if not isinstance(project, str) or not project.strip():
            return {
                "success": False,
                "error": "Falta el proyecto.",
            }

        if not isinstance(proposals, list):
            return {
                "success": False,
                "error": "Las propuestas son inválidas.",
            }

        if not isinstance(authorization, dict) or not authorization.get("authorized"):
            return {
                "success": False,
                "error": "Los cambios requieren autorización.",
            }

        if authorization.get("scope") != "project_only":
            return {
                "success": False,
                "error": "La autorización no permite modificar fuera del proyecto.",
            }

        project_path = Path(project)

        if (
            not project_path.is_absolute()
            and project_path.name.lower() == Path.cwd().name.lower()
            and Path.cwd().is_dir()
        ):
            project_root = Path.cwd().resolve()
        else:
            project_root = project_path.resolve()

        if not project_root.is_dir():
            return {
                "success": False,
                "error": "El proyecto no existe.",
            }

        applied = []
        rejected = []

        for proposal in proposals:
            path_value = proposal.get("path")
            content = proposal.get("content")

            if not path_value or content is None:
                rejected.append({
                    "proposal": proposal,
                    "error": "Propuesta incompleta.",
                })
                continue

            target = (project_root / str(path_value)).resolve()

            try:
                target.relative_to(project_root)
            except ValueError:
                rejected.append({
                    "path": str(target),
                    "error": "La ruta queda fuera del proyecto.",
                })
                continue

            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(str(content), encoding="utf-8")

            applied.append({
                "component": proposal.get("component"),
                "path": str(target),
                "action": proposal.get("action"),
                "bytes": target.stat().st_size,
            })

        return {
            "success": len(rejected) == 0,
            "project": str(project_root),
            "status": "changes_applied" if not rejected else "changes_partial",
            "applied": applied,
            "rejected": rejected,
            "applied_count": len(applied),
            "rejected_count": len(rejected),
        }
