from pathlib import Path
class ChangeGenerator:
    """Genera propuestas de archivos para los cambios planificados por N.O.V.A."""

    def generate(self, project, change_plan):
        if not isinstance(project, str) or not project.strip():
            return {
                "success": False,
                "error": "Falta el proyecto.",
            }

        if not isinstance(change_plan, dict):
            return {
                "success": False,
                "error": "El plan de cambios es inválido.",
            }

        changes = change_plan.get("changes", [])
        instruction = change_plan.get("instruction", "").strip()

        if not isinstance(changes, list):
            return {
                "success": False,
                "error": "La lista de cambios es inválida.",
            }

        proposals = []

        for change in changes:
            component = change.get("component")

            generators = {
                "voice_control": (
                    "core/voice/voice_control.py",
                    self._voice_control,
                ),
                "speech_to_text": (
                    "core/voice/speech_to_text.py",
                    self._speech_to_text,
                ),
                "text_to_speech": (
                    "core/voice/text_to_speech.py",
                    self._text_to_speech,
                ),
                "voice_state": (
                    "core/voice/voice_state.py",
                    self._voice_state,
                ),
                "voice_tests": (
                    "core/voice/test_voice.py",
                    self._voice_tests,
                ),
                "self_diagnostics": (
                    "core/self_repair/self_diagnostics.py",
                    self._self_diagnostics,
                ),
                "repair_engine": (
                    "core/self_repair/repair_engine.py",
                    self._repair_engine,
                ),
                "retry_manager": (
                    "core/self_repair/retry_manager.py",
                    self._retry_manager,
                ),
                "recovery_manager": (
                    "core/self_repair/recovery_manager.py",
                    self._recovery_manager,
                ),
                "repair_verifier": (
                    "core/self_repair/repair_verifier.py",
                    self._repair_verifier,
                ),
                "self_repair_tests": (
                    "core/self_repair/test_self_repair.py",
                    self._self_repair_tests,
                ),
            }

            if component == "self_diagnostics" and any(
                marker in instruction.lower()
                for marker in (
                    "mejora el autodiagnóstico",
                    "mejora el autodiagnostico",
                    "extraer automáticamente archivo",
                    "extraer automaticamente archivo",
                    "archivo, línea, tipo de error y mensaje",
                    "archivo, linea, tipo de error y mensaje",
                )
            ):
                generators[component] = (
                    "core/self_repair/self_diagnostics.py",
                    self._evolved_self_diagnostics,
                )

            if component == "repair_verifier" and any(
                marker in instruction.lower()
                for marker in (
                    "mejora el verificador de reparaciones",
                    "mejora el verificador",
                    "comparar el diagnóstico del fallo original",
                    "comparar el diagnostico del fallo original",
                    "resultado posterior a la reparación",
                    "resultado posterior a la reparacion",
                    "fallo original desapareció",
                    "fallo original desaparecio",
                    "verificación estructurada",
                    "verificacion estructurada",
                )
            ):
                generators[component] = (
                    "core/self_repair/repair_verifier.py",
                    self._evolved_repair_verifier,
                )

            if component == "self_repair_tests" and any(
                marker in instruction.lower()
                for marker in (
                    "repairverifier.verify",
                    "repairverifier",
                    "verify(original, repaired)",
                    "verify(original,repaired)",
                    "test_self_repair",
                    "test de self-repair",
                    "test de self_repair",
                )
            ):
                generators[component] = (
                    "core/self_repair/test_self_repair.py",
                    self._self_repair_tests,
                )

            if component == "recovery_manager" and any(
                marker in instruction.lower()
                for marker in (
                    "backup_project_tool",
                    "restore_project_tool",
                    "recuperación funcional",
                    "recuperacion funcional",
                    "recuperación real",
                    "recuperacion real",
                    "recuperar un proyecto",
                    "recover(",
                )
            ):
                generators[component] = (
                    "core/self_repair/recovery_manager.py",
                    self._evolved_recovery_manager,
                )

            if component in generators:
                relative_path, generator = generators[component]
                project_path = Path(project)

                if (
                    not project_path.is_absolute()
                    and project_path.name.lower() == Path.cwd().name.lower()
                ):
                    project_root = Path.cwd()
                else:
                    project_root = project_path

                target = project_root / relative_path
                content = generator()

                if target.is_file():
                    existing = target.read_text(encoding="utf-8")

                    if existing == content:
                        continue

                    action = "update"
                else:
                    action = "create"

                proposals.append({
                    "component": component,
                    "path": relative_path,
                    "action": action,
                    "content": content,
                })

        return {
            "success": True,
            "project": project.strip(),
            "status": "changes_generated",
            "proposals": proposals,
            "message": "Propuestas de código generadas sin escribir archivos.",
        }


    def _evolved_self_diagnostics(self):
        return 'import re\n\n\nclass SelfDiagnostics:\n    """Diagnóstico estructurado de fallos de N.O.V.A."""\n\n    def diagnose(self, result):\n        if not isinstance(result, dict):\n            return {\n                "success": False,\n                "stage": "unknown",\n                "error": "Resultado inválido.",\n            }\n\n        failed = not bool(result.get("success", False))\n        stage = result.get("stage", "unknown")\n        error = result.get("error")\n        failure = {\n            "file": None,\n            "line": None,\n            "error_type": None,\n            "message": error,\n        }\n\n        results = result.get("tests", {}).get("results", [])\n        if isinstance(results, list):\n            for item in results:\n                if not isinstance(item, dict) or item.get("success", False):\n                    continue\n\n                failure["file"] = item.get("test")\n                stderr = str(item.get("stderr", ""))\n\n                match = re.search(\n                    r\'File "([^"]+)", line (\\d+)\',\n                    stderr,\n                )\n                if match:\n                    failure["file"] = match.group(1)\n                    failure["line"] = int(match.group(2))\n\n                syntax = re.search(\n                    r\'([A-Za-z_]+Error): (.+)\',\n                    stderr,\n                )\n                if syntax:\n                    failure["error_type"] = syntax.group(1)\n                    failure["message"] = syntax.group(2)\n                elif stderr.strip():\n                    failure["message"] = stderr.strip().splitlines()[-1]\n\n                break\n\n        return {\n            "success": True,\n            "failed": failed,\n            "stage": stage,\n            "error": error,\n            "failure": failure,\n        }\n'

    def _evolved_repair_verifier(self):
        content = [
            "class RepairVerifier:",
            "    \"\"\"Verifica automáticamente si una reparación resolvió el fallo original.\"\"\"",
            "",
            "    def verify(self, original, repaired):",
            "        if not isinstance(original, dict):",
            "            return {",
            "                \"success\": False,",
            "                \"verified\": False,",
            "                \"error\": \"El diagnóstico original es inválido.\",",
            "            }",
            "",
            "        if not isinstance(repaired, dict):",
            "            return {",
            "                \"success\": False,",
            "                \"verified\": False,",
            "                \"error\": \"El resultado posterior a la reparación es inválido.\",",
            "            }",
            "",
            "        original_failure = original.get(\"failure\", original)",
            "        if not isinstance(original_failure, dict):",
            "            original_failure = {}",
            "",
            "        post_success = bool(repaired.get(\"success\", False))",
            "        post_failure = repaired.get(\"failure\")",
            "        if not isinstance(post_failure, dict):",
            "            post_failure = {}",
            "",
            "        original_error = original_failure.get(\"error_type\")",
            "        original_file = original_failure.get(\"file\")",
            "        original_line = original_failure.get(\"line\")",
            "        original_message = original_failure.get(\"message\")",
            "",
            "        remaining_error = post_failure.get(\"error_type\")",
            "        remaining_file = post_failure.get(\"file\")",
            "        remaining_line = post_failure.get(\"line\")",
            "        remaining_message = post_failure.get(\"message\")",
            "",
            "        same_failure = (",
            "            original_error is not None",
            "            and remaining_error == original_error",
            "            and remaining_file == original_file",
            "            and remaining_line == original_line",
            "            and remaining_message == original_message",
            "        )",
            "",
            "        failure_disappeared = not same_failure",
            "        verified = post_success and failure_disappeared",
            "",
            "        return {",
            "            \"success\": True,",
            "            \"verified\": verified,",
            "            \"post_success\": post_success,",
            "            \"failure_disappeared\": failure_disappeared,",
            "            \"original_failure\": {",
            "                \"file\": original_file,",
            "                \"line\": original_line,",
            "                \"error_type\": original_error,",
            "                \"message\": original_message,",
            "            },",
            "            \"remaining_failure\": post_failure,",
            "        }",
            "",
        ]
        return "\n".join(content)
    def _self_diagnostics(self):
        content = [
            "class SelfDiagnostics:",
            "    \"\"\"Detecta fallos y determina dónde ocurrieron.\"\"\"",
            "",
            "    def diagnose(self, result):",
            "        if not isinstance(result, dict):",
            "            return {",
            "                \"success\": False,",
            "                \"stage\": \"unknown\",",
            "                \"error\": \"Resultado inválido.\",",
            "            }",
            "",
            "        return {",
            "            \"success\": True,",
            "            \"failed\": not bool(result.get(\"success\", False)),",
            "            \"stage\": result.get(\"stage\", \"unknown\"),",
            "            \"error\": result.get(\"error\"),",
            "        }",
            "",
        ]
        return "\n".join(content)


    def _repair_engine(self):
        content = [
            "class RepairEngine:",
            "    \"\"\"Gestiona propuestas estructuradas de reparación.\"\"\"",
            "",
            "    def repair(self, failure, strategy=None):",
            "        if not isinstance(failure, dict):",
            "            return {",
            "                \"success\": False,",
            "                \"repaired\": False,",
            "                \"error\": \"El diagnóstico de fallo es inválido.\",",
            "            }",
            "",
            "        diagnosis = failure.get(\"failure\", failure)",
            "",
            "        if not isinstance(diagnosis, dict):",
            "            return {",
            "                \"success\": False,",
            "                \"repaired\": False,",
            "                \"error\": \"No existe un diagnóstico estructurado.\",",
            "            }",
            "",
            "        error_type = diagnosis.get(\"error_type\")",
            "        file_path = diagnosis.get(\"file\")",
            "        line = diagnosis.get(\"line\")",
            "        message = diagnosis.get(\"message\")",
            "",
            "        if not error_type and not message:",
            "            return {",
            "                \"success\": False,",
            "                \"repaired\": False,",
            "                \"error\": \"No se pudo identificar el tipo o mensaje del fallo.\",",
            "            }",
            "",
            "        selected_strategy = strategy or self._select_strategy(",
            "            error_type,",
            "            message,",
            "        )",
            "",
            "        return {",
            "            \"success\": True,",
            "            \"repaired\": False,",
            "            \"status\": \"repair_proposed\",",
            "            \"strategy\": selected_strategy,",
            "            \"failure\": {",
            "                \"file\": file_path,",
            "                \"line\": line,",
            "                \"error_type\": error_type,",
            "                \"message\": message,",
            "            },",
            "            \"proposal\": self._build_proposal(",
            "                selected_strategy,",
            "                file_path,",
            "                line,",
            "                error_type,",
            "                message,",
            "            ),",
            "        }",
            "",
            "    def _select_strategy(self, error_type, message):",
            "        if error_type == \"SyntaxError\":",
            "            return \"inspect_syntax_error\"",
            "",
            "        if error_type and error_type.endswith(\"Error\"):",
            "            return \"inspect_error\"",
            "",
            "        return \"inspect_failure\"",
            "",
            "    def _build_proposal(",
            "        self,",
            "        strategy,",
            "        file_path,",
            "        line,",
            "        error_type,",
            "        message,",
            "    ):",
            "        return {",
            "            \"action\": \"analyze_and_prepare_fix\",",
            "            \"strategy\": strategy,",
            "            \"file\": file_path,",
            "            \"line\": line,",
            "            \"error_type\": error_type,",
            "            \"message\": message,",
            "        }",
            "",
        ]

        return "\n".join(content)
    def _retry_manager(self):
        content = [
            "class RetryManager:",
            "    \"\"\"Controla reintentos limitados.\"\"\"",
            "",
            "    def __init__(self, max_retries=3):",
            "        self.max_retries = max(0, int(max_retries))",
            "",
            "    def should_retry(self, attempt):",
            "        return int(attempt) < self.max_retries",
            "",
        ]
        return "\n".join(content)


    def _recovery_manager(self):
        """Generador canónico de recuperación funcional."""
        return self._evolved_recovery_manager()


    def _repair_verifier(self):
        content = [
            "class RepairVerifier:",
            "    \"\"\"Verifica si una reparación resolvió el fallo.\"\"\"",
            "",
            "    def verify(self, result):",
            "        verified = isinstance(result, dict) and bool(result.get(\"success\", False))",
            "        return {",
            "            \"success\": True,",
            "            \"verified\": verified,",
            "            \"result\": result,",
            "        }",
            "",
        ]
        return "\n".join(content)


    def _self_repair_tests(self):
        content = [
            "from pathlib import Path",
            "import tempfile",
            "from core.self_repair.self_diagnostics import SelfDiagnostics",
            "from core.self_repair.retry_manager import RetryManager",
            "from core.self_repair.repair_verifier import RepairVerifier",
            "from core.self_repair.recovery_manager import RecoveryManager",
            "from core.runtime.advanced_tool_handlers import backup_project_tool",
            "",
            "def test_diagnostics():",
            "    result = SelfDiagnostics().diagnose({\"success\": False, \"stage\": \"tests\"})",
            "    assert result[\"success\"] is True",
            "    assert result[\"failed\"] is True",
            "",
            "def test_retry_manager():",
            "    manager = RetryManager(3)",
            "    assert manager.should_retry(0) is True",
            "    assert manager.should_retry(3) is False",
            "",
            "def test_repair_verifier():",
            "    result = RepairVerifier().verify({\"success\": True})",
            "    assert result[\"success\"] is True",
            "    assert result[\"verified\"] is True",
            "",
            "def test_recovery_manager():",
            '    with tempfile.TemporaryDirectory(dir=str(Path("projects").resolve())) as tmp:',
            "        root = Path(tmp)",
            "        source = root / \"source\"",
            "        backup = root / \"backup\"",
            "        destination = root / \"destination\"",
            "        source.mkdir()",
            "        (source / \"data.txt\").write_text(\"original\", encoding=\"utf-8\")",
            "        backup_result = backup_project_tool(str(source), str(backup))",
            "        assert backup_result[\"success\"] is True",
            "        (source / \"data.txt\").write_text(\"corrupted\", encoding=\"utf-8\")",
            "        recovered = RecoveryManager().recover(str(backup), str(destination))",
            "        assert recovered[\"success\"] is True",
            "        assert recovered[\"recovered\"] is True",
            "        assert (destination / \"data.txt\").read_text(encoding=\"utf-8\") == \"original\"",
            "",
            "if __name__ == \"__main__\":",
            "    test_diagnostics()",
            "    test_retry_manager()",
            "    test_repair_verifier()",
            "    test_recovery_manager()",
            "    print(\"SELF_REPAIR TESTS OK\")",
            "",
        ]
        return "\n".join(content)


    def _voice_control(self):
        return '''class VoiceControl:
    """Control base de las operaciones de voz de N.O.V.A."""

    def __init__(self):
        self.enabled = False

    def enable(self):
        self.enabled = True
        return {"success": True, "enabled": True}

    def disable(self):
        self.enabled = False
        return {"success": True, "enabled": False}
'''

    def _speech_to_text(self):
        return '''class SpeechToText:
    """Capa STT de N.O.V.A. con backend intercambiable."""

    def __init__(self, backend=None):
        self.backend = backend
        self.available = callable(backend)

    def set_backend(self, backend):
        self.backend = backend
        self.available = callable(backend)
        return {
            "success": True,
            "available": self.available,
        }

    def listen(self):
        if not self.available:
            return {
                "success": False,
                "available": False,
                "error": "No hay un backend STT conectado.",
            }

        try:
            result = self.backend()
            return {
                "success": True,
                "available": True,
                "text": result,
            }
        except Exception as exc:
            return {
                "success": False,
                "available": True,
                "error": f"{type(exc).__name__}: {exc}",
            }
'''

    def _text_to_speech(self):
        return '''class TextToSpeech:
    """Capa TTS de N.O.V.A. con backend intercambiable."""

    def __init__(self, backend=None):
        self.backend = backend
        self.available = callable(backend)

    def set_backend(self, backend):
        self.backend = backend
        self.available = callable(backend)
        return {
            "success": True,
            "available": self.available,
        }

    def speak(self, text):
        if not self.available:
            return {
                "success": False,
                "available": False,
                "text": text,
                "error": "No hay un backend TTS conectado.",
            }

        try:
            result = self.backend(text)
            return {
                "success": True,
                "available": True,
                "text": text,
                "backend_result": result,
            }
        except Exception as exc:
            return {
                "success": False,
                "available": True,
                "text": text,
                "error": f"{type(exc).__name__}: {exc}",
            }
'''

    def _voice_state(self):
        return '''class VoiceState:
    """Estados principales del sistema de voz de N.O.V.A."""

    LISTENING = "listening"
    PROCESSING = "processing"
    RESPONDING = "responding"
    IDLE = "idle"

    def __init__(self):
        self.current = self.IDLE

    def set(self, state):
        if state not in {
            self.LISTENING,
            self.PROCESSING,
            self.RESPONDING,
            self.IDLE,
        }:
            return {
                "success": False,
                "error": "Estado de voz inválido.",
            }

        self.current = state

        return {
            "success": True,
            "state": self.current,
        }
'''

    def _voice_tests(self):
        return '''from core.voice.voice_control import VoiceControl
from core.voice.voice_state import VoiceState


def test_voice_control():
    voice = VoiceControl()
    result = voice.enable()
    assert result["success"] is True
    assert voice.enabled is True


def test_voice_state():
    state = VoiceState()
    result = state.set(VoiceState.LISTENING)
    assert result["success"] is True
    assert state.current == VoiceState.LISTENING


if __name__ == "__main__":
    test_voice_control()
    test_voice_state()
    print("Voice tests passed.")
'''
