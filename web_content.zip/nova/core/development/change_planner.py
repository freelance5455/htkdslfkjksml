from pathlib import Path


class ChangePlanner:
    """Convierte una misión de desarrollo en un plan estructurado de cambios."""

    def create_change_plan(self, project, instruction, analysis=None):
        if not isinstance(project, str) or not project.strip():
            return {
                "success": False,
                "error": "Falta el proyecto.",
            }

        if not isinstance(instruction, str) or not instruction.strip():
            return {
                "success": False,
                "error": "Falta la instrucción.",
            }

        analysis = analysis or {}
        project_root = self._resolve_project(project.strip())
        normalized = instruction.strip().lower()

        capability = self._detect_capability(normalized)
        self._current_instruction = normalized
        changes = self._build_changes(
            capability,
            project_root,
        )

        return {
            "success": True,
            "project": project.strip(),
            "instruction": instruction.strip(),
            "status": "changes_planned",
            "analysis_used": bool(analysis),
            "capability": capability,
            "changes": changes,
            "message": "Plan de cambios concretos generado según el estado actual del proyecto.",
        }

    def _resolve_project(self, project):
        project_path = Path(project)

        if (
            not project_path.is_absolute()
            and project_path.name.lower() == Path.cwd().name.lower()
        ):
            return Path.cwd()

        return project_path

    def _component_path(self, project_root, component):
        paths = {
            "voice_control": "core/voice/voice_control.py",
            "speech_to_text": "core/voice/speech_to_text.py",
            "text_to_speech": "core/voice/text_to_speech.py",
            "voice_state": "core/voice/voice_state.py",
            "voice_tests": "core/voice/test_voice.py",
        }

        relative_path = paths.get(component)

        if relative_path is None:
            return None

        return project_root / relative_path

    def _self_repair_changes(self, project_root):
        components = [
            (
                1,
                "self_diagnostics",
                "Detectar fallos y determinar la etapa en la que ocurren.",
                "core/self_repair/self_diagnostics.py",
            ),
            (
                2,
                "repair_engine",
                "Proponer y aplicar correcciones controladas.",
                "core/self_repair/repair_engine.py",
            ),
            (
                3,
                "retry_manager",
                "Gestionar reintentos limitados con estrategias alternativas.",
                "core/self_repair/retry_manager.py",
            ),
            (
                4,
                "recovery_manager",
                "Recuperar un estado funcional después de una modificación fallida.",
                "core/self_repair/recovery_manager.py",
            ),
            (
                5,
                "repair_verifier",
                "Verificar que una reparación realmente resolvió el problema.",
                "core/self_repair/repair_verifier.py",
            ),
            (
                6,
                "self_repair_tests",
                "Probar diagnóstico, reparación, reintentos y recuperación.",
                "core/self_repair/test_self_repair.py",
            ),
        ]

        changes = []

        for order, component, purpose, relative_path in components:
            target = project_root / relative_path
            exists = target.is_file()

            changes.append({
                "order": order,
                "component": component,
                "action": "update" if exists else "create",
                "path": relative_path,
                "exists": exists,
                "reason": (
                    "El componente existe y debe evaluarse para evolución."
                    if exists
                    else "El componente todavía no existe."
                ),
                "purpose": purpose,
            })

        return changes

    def _build_changes(self, capability, project_root):
        if capability == "self_repair":
            instruction = getattr(self, "_current_instruction", "").lower()

            if any(marker in instruction for marker in (
                "recoverymanager",
                "recovery_manager",
                "backup_project_tool",
                "restore_project_tool",
                "recuperación funcional",
                "recuperacion funcional",
                "recuperación real",
                "recuperacion real",
                "recuperar un proyecto",
                "recover(",
            )):
                recovery_target = project_root / "core/self_repair/recovery_manager.py"
                tests_target = project_root / "core/self_repair/test_self_repair.py"
                return [
                    {
                        "order": 1,
                        "component": "recovery_manager",
                        "action": "update" if recovery_target.is_file() else "create",
                        "path": "core/self_repair/recovery_manager.py",
                        "exists": recovery_target.is_file(),
                        "reason": "El RecoveryManager debe tener recuperación funcional y verificable.",
                        "purpose": "Restaurar un proyecto desde un backup sin sobrescribir el destino.",
                    },
                    {
                        "order": 2,
                        "component": "self_repair_tests",
                        "action": "update" if tests_target.is_file() else "create",
                        "path": "core/self_repair/test_self_repair.py",
                        "exists": tests_target.is_file(),
                        "reason": "Se requieren pruebas funcionales de recuperación.",
                        "purpose": "Demostrar que backup y recuperación realmente restauran el contenido.",
                    },
                ]

            if any(marker in instruction for marker in (
                "motor de reparación",
                "motor de reparacion",
                "repair engine",
                "repair_engine",
                "estrategia de reparación",
                "estrategia de reparacion",
            )):
                target = project_root / "core/self_repair/repair_engine.py"
                exists = target.is_file()

                return [{
                    "order": 1,
                    "component": "repair_engine",
                    "action": "update" if exists else "create",
                    "path": "core/self_repair/repair_engine.py",
                    "exists": exists,
                    "reason": (
                        "El componente existe y debe evolucionar."
                        if exists
                        else "El componente todavía no existe."
                    ),
                    "purpose": (
                        "Convertir diagnósticos de fallos en propuestas "
                        "estructuradas de reparación."
                    ),
                }]

            return self._self_repair_changes(project_root)

        if capability == "voice":
            components = [
                (
                    1,
                    "voice_control",
                    "Controlar el estado y las operaciones de voz de N.O.V.A.",
                ),
                (
                    2,
                    "speech_to_text",
                    "Recibir comandos hablados del usuario.",
                ),
                (
                    3,
                    "text_to_speech",
                    "Permitir que N.O.V.A. responda mediante voz.",
                ),
                (
                    4,
                    "voice_state",
                    "Representar los estados listening, processing y responding.",
                ),
                (
                    5,
                    "voice_tests",
                    "Probar la integración de los componentes de voz.",
                ),
            ]

            changes = []

            for order, component, purpose in components:
                target = self._component_path(
                    project_root,
                    component,
                )

                exists = bool(target and target.is_file())

                if not exists:
                    action = "create"
                    reason = "El componente todavía no existe."
                elif self._requires_backend_update(
                    target,
                    component,
                ):
                    action = "update"
                    reason = "El componente existe, pero su backend todavía no está conectado."
                else:
                    action = "skip"
                    reason = "El componente existe y no requiere actualización según las comprobaciones actuales."

                changes.append({
                    "order": order,
                    "component": component,
                    "action": action,
                    "path": (
                        str(target.relative_to(project_root))
                        if target
                        else None
                    ),
                    "exists": exists,
                    "reason": reason,
                    "purpose": purpose,
                })

            return changes

        return [
            {
                "order": 1,
                "component": capability,
                "action": "analyze",
                "purpose": (
                    "Analizar los componentes existentes relacionados "
                    "con la capacidad."
                ),
            }
        ]

    def _requires_backend_update(self, target, component):
        """Detecta componentes de voz que siguen siendo solo andamiaje."""
        if component not in {
            "speech_to_text",
            "text_to_speech",
        }:
            return False

        try:
            content = target.read_text(encoding="utf-8")
        except OSError:
            return True

        scaffold_markers = (
            "available = False",
            "Backend STT todavía no conectado.",
            "Backend TTS todavía no conectado.",
        )

        return any(marker in content for marker in scaffold_markers)

    def _detect_capability(self, instruction):
        if any(word in instruction for word in (
            "autodiagnóstico",
            "autodiagnostico",
            "autocorrección",
            "autocorreccion",
            "autorreparación",
            "autorreparacion",
            "reparación automática",
            "reparacion automatica",
            "reintento",
            "reintentar",
            "reintentos",
            "recuperación",
            "recuperacion",
            "self repair",
            "self-repair",
            "self_repair",
            "verificador de reparaciones",
            "verificador de reparación",
            "repair verifier",
            "repair_verifier",
        )):
            return "self_repair"

        if any(word in instruction for word in (
            "voz",
            "voice",
            "hablar",
            "escuchar",
            "micrófono",
            "microfono",
            "audio",
            "tts",
            "stt",
        )):
            return "voice"

        if any(word in instruction for word in (
            "android",
            "aplicación",
            "app",
            "apk",
        )):
            return "android"

        if any(word in instruction for word in (
            "internet",
            "web",
            "api",
            "http",
        )):
            return "internet"

        if any(word in instruction for word in (
            "memoria",
            "recordar",
            "recuerda",
        )):
            return "memory"

        return "general"
