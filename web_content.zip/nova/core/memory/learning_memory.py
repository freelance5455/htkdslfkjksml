import json
import math
import re
import hashlib
from pathlib import Path
from datetime import datetime, timezone


class LearningMemory:
    """Memoria persistente avanzada de N.O.V.A.

    Mantiene conocimiento semántico aproximado sin dependencias externas:
    confianza, importancia, evidencia, confirmaciones, correcciones, uso,
    recencia, etiquetas, categorías, relaciones, contradicciones, historial
    y recuerdos archivados.
    """

    VERSION = 3
    DEFAULT_DECAY_DAYS = 90
    SOURCE_RELIABILITY = {
        "system": 1.0,
        "tool": 0.9,
        "verified": 0.95,
        "test": 0.9,
        "conversation": 0.65,
        "user": 0.8,
        "inference": 0.45,
        "unknown": 0.4,
    }

    STOPWORDS = {
        "para", "como", "esta", "este", "esto", "desde", "sobre", "entre",
        "puede", "tiene", "tienen", "que", "una", "uno", "los", "las", "del",
        "por", "con", "sin", "sus", "son", "ser", "más", "muy", "hay", "es",
        "de", "la", "el", "y", "o", "un", "en", "se", "al", "lo", "ya",
    }

    def __init__(self, path="core/memory/knowledge.json"):
        self.path = Path(path)
        self.entries = []
        self.archive = []
        self.associations = []
        self.events = []
        self.load()
        self._migrate()

    def _now(self):
        return datetime.now(timezone.utc).isoformat()

    def _parse_time(self, value):
        try:
            return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        except (TypeError, ValueError):
            return None

    def _tokens(self, text):
        raw = re.findall(r"[a-záéíóúüñ0-9][a-záéíóúüñ0-9._-]*", str(text).lower())
        return {x for x in raw if len(x) >= 3 and x not in self.STOPWORDS}

    def _fingerprint(self, knowledge):
        tokens = sorted(self._tokens(knowledge))
        base = " ".join(tokens) or str(knowledge).strip().casefold()
        return hashlib.sha256(base.encode("utf-8")).hexdigest()[:16]

    def _infer_tags(self, knowledge, source):
        tags = set()
        low = str(knowledge).lower()
        for tag, words in {
            "nova": ("n.o.v.a", "nova"),
            "proyecto": ("proyecto", "código", "codigo", "software"),
            "voz": ("voz", "audio", "habla", "micrófono", "microfono"),
            "memoria": ("memoria", "recuerdo", "recordar"),
            "seguridad": ("seguridad", "permiso", "autorización", "autorizacion"),
            "aprendizaje": ("aprender", "aprendizaje", "conocimiento"),
            "android": ("android", "apk", "teléfono", "telefono"),
            "internet": ("internet", "web", "http", "api"),
        }.items():
            if any(word in low for word in words):
                tags.add(tag)
        if source:
            tags.add(str(source).strip().lower())
        return sorted(tags)

    def _migrate_entry(self, entry):
        now = self._now()
        entry.setdefault("id", 0)
        entry.setdefault("knowledge", "")
        entry.setdefault("source", "unknown")
        entry["confidence"] = round(max(0.0, min(1.0, float(entry.get("confidence", 0.5))),), 3)
        entry.setdefault("confirmations", 0)
        entry.setdefault("corrections", 0)
        entry.setdefault("evidence", [])
        entry.setdefault("last_confirmed_at", None)
        entry.setdefault("created_at", now)
        entry.setdefault("updated_at", now)
        entry.setdefault("last_accessed_at", None)
        entry.setdefault("access_count", 0)
        entry.setdefault("importance", 0.5)
        entry.setdefault("stability", 1.0)
        entry.setdefault("status", "active")
        entry.setdefault("tags", self._infer_tags(entry["knowledge"], entry["source"]))
        entry.setdefault("category", entry["tags"][0] if entry["tags"] else "general")
        entry.setdefault("fingerprint", self._fingerprint(entry["knowledge"]))
        entry.setdefault("related_ids", [])
        entry.setdefault("contradicts_ids", [])
        entry.setdefault("supersedes_id", None)
        entry.setdefault("valid_from", None)
        entry.setdefault("valid_until", None)
        entry.setdefault("history", [])
        return entry

    def _migrate(self):
        changed = False
        normalized = []
        for entry in self.entries:
            before = json.dumps(entry, sort_keys=True, ensure_ascii=False)
            self._migrate_entry(entry)
            after = json.dumps(entry, sort_keys=True, ensure_ascii=False)
            changed |= before != after
            normalized.append(entry)
        self.entries = normalized
        if changed:
            self.save()

    def load(self):
        if not self.path.exists():
            return
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            if isinstance(data, list):
                self.entries = data
            elif isinstance(data, dict):
                self.entries = data.get("entries", [])
                self.archive = data.get("archive", [])
                self.associations = data.get("associations", [])
                self.events = data.get("events", [])
        except (json.JSONDecodeError, OSError):
            self.entries, self.archive, self.associations, self.events = [], [], [], []

    def save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "version": self.VERSION,
            "entries": self.entries,
            "archive": self.archive,
            "associations": self.associations,
            "events": self.events[-500:],
        }
        temp = self.path.with_suffix(".tmp")
        temp.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        temp.replace(self.path)

    def _next_id(self):
        ids = [e.get("id", 0) for e in self.entries + self.archive]
        return max(ids + [0]) + 1

    def _source_reliability(self, source):
        return self.SOURCE_RELIABILITY.get(
            str(source).lower().strip(),
            self.SOURCE_RELIABILITY["unknown"],
        )

    def _decayed_confidence(self, entry, now=None):
        confidence = float(entry.get("confidence", 0.0))
        if confidence <= 0:
            return 0.0
        stamp = entry.get("last_confirmed_at") or entry.get("updated_at") or entry.get("created_at")
        dt = self._parse_time(stamp)
        if dt is None:
            return confidence
        now = now or datetime.now(timezone.utc)
        age = max(0.0, (now - dt).total_seconds() / 86400.0)
        stability = max(0.1, float(entry.get("stability", 1.0)))
        decay = math.exp(-age / (self.DEFAULT_DECAY_DAYS * stability))
        # Never decay verified/system memories below a useful floor.
        floor = 0.5 if self._source_reliability(entry.get("source")) >= 0.9 else 0.0
        return round(max(floor, confidence * decay), 3)

    def _similarity(self, query, knowledge):
        a = self._tokens(query)
        b = self._tokens(knowledge)
        if not a or not b:
            return 0.0
        overlap = len(a & b) / max(1, len(a | b))
        # Character trigram-like containment catches inflections/phrasing.
        q = " ".join(sorted(a))
        k = " ".join(sorted(b))
        from difflib import SequenceMatcher
        fuzzy = SequenceMatcher(None, q, k).ratio()
        return round((overlap * 0.7) + (fuzzy * 0.3), 3)

    def _record_event(self, event, **data):
        self.events.append({
            "event": event,
            "timestamp": self._now(),
            **data,
        })

    def _find_duplicate(self, knowledge, source):
        fingerprint = self._fingerprint(knowledge)
        exact = str(knowledge).strip().casefold()
        for entry in self.entries:
            if entry.get("status") == "archived":
                continue
            if entry.get("fingerprint") == fingerprint:
                return entry
            if (
                entry.get("knowledge", "").strip().casefold() == exact
                and entry.get("source", "").strip().casefold() == str(source).strip().casefold()
            ):
                return entry
        return None

    def learn(
        self,
        knowledge,
        source="conversation",
        confidence=0.5,
        evidence=None,
        importance=0.5,
        category=None,
        tags=None,
        valid_from=None,
        valid_until=None,
    ):
        knowledge = str(knowledge).strip()
        source = str(source).strip() or "unknown"
        confidence = max(0.0, min(1.0, float(confidence)))
        importance = max(0.0, min(1.0, float(importance)))
        evidence_items = [] if evidence is None else (
            list(evidence) if isinstance(evidence, (list, tuple)) else [str(evidence)]
        )

        duplicate = self._find_duplicate(knowledge, source)
        if duplicate:
            duplicate["confidence"] = round(max(
                duplicate.get("confidence", 0.0), confidence
            ), 3)
            duplicate["importance"] = round(max(
                duplicate.get("importance", 0.5), importance
            ), 3)
            duplicate.setdefault("evidence", []).extend(
                x for x in evidence_items if x not in duplicate.get("evidence", [])
            )
            duplicate["tags"] = sorted(set(duplicate.get("tags", [])) | set(
                tags or self._infer_tags(knowledge, source)
            ))
            duplicate["updated_at"] = self._now()
            duplicate["stability"] = min(5.0, float(duplicate.get("stability", 1.0)) + 0.1)
            self._record_event("reinforce_duplicate", entry_id=duplicate["id"])
            self.save()
            return duplicate

        entry = {
            "id": self._next_id(),
            "knowledge": knowledge,
            "source": source,
            "confidence": round(confidence, 3),
            "confirmations": 0,
            "corrections": 0,
            "evidence": evidence_items,
            "last_confirmed_at": None,
            "created_at": self._now(),
            "updated_at": self._now(),
            "last_accessed_at": None,
            "access_count": 0,
            "importance": round(importance, 3),
            "stability": 1.0,
            "status": "active",
            "tags": sorted(set(tags or self._infer_tags(knowledge, source))),
            "category": category or (tags[0] if tags else (self._infer_tags(knowledge, source) or ["general"])[0]),
            "fingerprint": self._fingerprint(knowledge),
            "related_ids": [],
            "contradicts_ids": [],
            "supersedes_id": None,
            "valid_from": valid_from,
            "valid_until": valid_until,
            "history": [],
        }
        self.entries.append(entry)
        self._record_event("learn", entry_id=entry["id"], source=source)
        self.save()
        return entry

    def confirm(self, entry_id, evidence=None):
        entry = self.get(entry_id)
        if entry is None:
            return None
        entry["confirmations"] = int(entry.get("confirmations", 0)) + 1
        entry["confidence"] = round(min(1.0, entry.get("confidence", 0.0) + 0.1), 3)
        entry["stability"] = min(5.0, float(entry.get("stability", 1.0)) + 0.5)
        entry["last_confirmed_at"] = self._now()
        if evidence:
            entry.setdefault("evidence", []).append(str(evidence))
        entry["updated_at"] = self._now()
        self._record_event("confirm", entry_id=entry_id)
        self.save()
        return entry

    def correct(self, entry_id, new_knowledge, evidence=None):
        entry = self.get(entry_id)
        if entry is None:
            return None
        old = entry["knowledge"]
        entry["history"].append({
            "knowledge": old,
            "confidence": entry.get("confidence", 0.0),
            "timestamp": self._now(),
        })
        entry["knowledge"] = str(new_knowledge).strip()
        entry["fingerprint"] = self._fingerprint(entry["knowledge"])
        entry["corrections"] = int(entry.get("corrections", 0)) + 1
        entry["confidence"] = 0.5
        entry["stability"] = 1.0
        entry["last_confirmed_at"] = None
        entry["tags"] = self._infer_tags(entry["knowledge"], entry["source"])
        entry["category"] = entry["tags"][0] if entry["tags"] else "general"
        if evidence:
            entry.setdefault("evidence", []).append(str(evidence))
        entry["updated_at"] = self._now()
        self._record_event("correct", entry_id=entry_id)
        self.save()
        return entry

    def reinforce(self, entry_id, amount=0.05, evidence=None):
        entry = self.get(entry_id)
        if entry is None:
            return None
        entry["confidence"] = round(
            min(1.0, max(0.0, entry.get("confidence", 0.0) + float(amount))), 3
        )
        entry["stability"] = min(5.0, float(entry.get("stability", 1.0)) + abs(float(amount)))
        if evidence:
            entry.setdefault("evidence", []).append(str(evidence))
        entry["updated_at"] = self._now()
        self._record_event("reinforce", entry_id=entry_id)
        self.save()
        return entry

    def get(self, entry_id):
        try:
            target = int(entry_id)
        except (TypeError, ValueError):
            return None
        for entry in self.entries:
            if int(entry.get("id", -1)) == target:
                return entry
        return None

    def search(self, text, minimum_score=0.0, limit=10, tags=None, category=None):
        query = str(text).strip()
        if not query:
            return []
        tag_filter = set(str(x).lower() for x in (tags or []))
        now = datetime.now(timezone.utc)
        results = []
        for entry in self.entries:
            if entry.get("status") != "active":
                continue
            if category and entry.get("category") != category:
                continue
            if tag_filter and not tag_filter.intersection(
                set(str(x).lower() for x in entry.get("tags", []))
            ):
                continue
            similarity = self._similarity(query, entry.get("knowledge", ""))
            if similarity <= 0:
                continue
            confidence = self._decayed_confidence(entry, now)
            importance = float(entry.get("importance", 0.5))
            reliability = self._source_reliability(entry.get("source"))
            usage = min(1.0, math.log1p(int(entry.get("access_count", 0))) / 5)
            score = (
                similarity * 0.50
                + confidence * 0.25
                + importance * 0.12
                + reliability * 0.08
                + usage * 0.05
            )
            if score < minimum_score:
                continue
            copy = dict(entry)
            copy["match_score"] = round(similarity, 3)
            copy["retrieval_score"] = round(score, 3)
            copy["effective_confidence"] = confidence
            results.append(copy)

        results.sort(
            key=lambda e: (
                e["retrieval_score"],
                e.get("confidence", 0.0),
                e.get("confirmations", 0),
            ),
            reverse=True,
        )
        results = results[:max(1, int(limit))]
        for result in results:
            entry = self.get(result["id"])
            if entry:
                entry["access_count"] = int(entry.get("access_count", 0)) + 1
                entry["last_accessed_at"] = self._now()
        if results:
            self._record_event("recall", query=query, count=len(results))
            self.save()
        return results

    def associate(self, entry_a, entry_b, relation="related", strength=0.5):
        a, b = self.get(entry_a), self.get(entry_b)
        if not a or not b or a["id"] == b["id"]:
            return {"success": False, "error": "Memoria no encontrada o inválida."}
        strength = max(0.0, min(1.0, float(strength)))
        if b["id"] not in a["related_ids"]:
            a["related_ids"].append(b["id"])
        if a["id"] not in b["related_ids"]:
            b["related_ids"].append(a["id"])
        record = {
            "from": a["id"], "to": b["id"], "relation": relation,
            "strength": strength, "updated_at": self._now(),
        }
        self.associations = [
            x for x in self.associations
            if not (x.get("from") == a["id"] and x.get("to") == b["id"])
        ]
        self.associations.append(record)
        self._record_event("associate", entry_id=a["id"], related_id=b["id"])
        self.save()
        return {"success": True, "association": record}

    def contradict(self, entry_id, conflicting_knowledge, source="inference", confidence=0.5, evidence=None):
        entry = self.get(entry_id)
        if not entry:
            return {"success": False, "error": "Memoria no encontrada."}
        new_entry = self.learn(
            conflicting_knowledge, source=source, confidence=confidence,
            evidence=evidence, importance=entry.get("importance", 0.5),
        )
        entry["contradicts_ids"].append(new_entry["id"])
        new_entry.setdefault("contradicts_ids", []).append(entry["id"])
        self.save()
        return {"success": True, "original": entry, "conflict": new_entry}

    def archive_entry(self, entry_id, reason="archived"):
        entry = self.get(entry_id)
        if not entry:
            return {"success": False, "error": "Memoria no encontrada."}
        entry["status"] = "archived"
        entry["archive_reason"] = reason
        entry["updated_at"] = self._now()
        self.archive.append(dict(entry))
        self.entries = [x for x in self.entries if x["id"] != entry["id"]]
        self._record_event("archive", entry_id=entry_id, reason=reason)
        self.save()
        return {"success": True, "entry": entry}

    def forget(self, entry_id):
        return self.archive_entry(entry_id, reason="forgotten")

    def recall_related(self, entry_id, limit=10):
        entry = self.get(entry_id)
        if not entry:
            return []
        ids = set(entry.get("related_ids", []))
        results = [dict(x) for x in self.entries if x.get("id") in ids]
        return results[:max(1, int(limit))]

    def stats(self):
        active = [x for x in self.entries if x.get("status") == "active"]
        return {
            "version": self.VERSION,
            "total": len(active),
            "archived": len(self.archive),
            "categories": len({x.get("category", "general") for x in active}),
            "tags": len({tag for x in active for tag in x.get("tags", [])}),
            "evidence": sum(len(x.get("evidence", [])) for x in active),
            "confirmations": sum(int(x.get("confirmations", 0)) for x in active),
            "corrections": sum(int(x.get("corrections", 0)) for x in active),
            "associations": len(self.associations),
            "events": len(self.events),
        }

    def record_episode(self, event_type, content, context=None, importance=0.5):
        episode = {
            "id": self._next_id(),
            "event_type": str(event_type),
            "content": str(content),
            "context": dict(context or {}),
            "importance": max(0.0, min(1.0, float(importance))),
            "timestamp": self._now(),
        }
        self.events.append({"event": "episode", **episode})
        self.save()
        return episode

    def recent_episodes(self, limit=20):
        episodes = [e for e in self.events if e.get("event") == "episode"]
        return list(reversed(episodes[-max(1, int(limit)):])) 

    def build_context(self, query, limit=5):
        relevant = self.search(query, limit=limit)
        recent = self.recent_episodes(limit=5)
        related = []
        seen = {x.get("id") for x in relevant}
        for entry in relevant:
            for item in self.recall_related(entry["id"], limit=5):
                if item.get("id") not in seen:
                    related.append(item)
                    seen.add(item.get("id"))
        return {
            "query": query,
            "relevant": relevant,
            "related": related[:limit],
            "recent_episodes": recent,
        }

    def merge(self, primary_id, secondary_id):
        primary = self.get(primary_id)
        secondary = self.get(secondary_id)
        if not primary or not secondary or primary["id"] == secondary["id"]:
            return {"success": False, "error": "Memorias inválidas."}
        primary["confidence"] = round(max(primary["confidence"], secondary["confidence"]), 3)
        primary["importance"] = round(max(primary["importance"], secondary["importance"]), 3)
        primary["confirmations"] += secondary.get("confirmations", 0)
        primary["corrections"] += secondary.get("corrections", 0)
        primary["evidence"] = list(dict.fromkeys(
            primary.get("evidence", []) + secondary.get("evidence", [])
        ))
        primary["tags"] = sorted(set(primary.get("tags", [])) | set(secondary.get("tags", [])))
        primary["related_ids"] = sorted(set(
            primary.get("related_ids", []) + secondary.get("related_ids", [])
        ) - {primary["id"], secondary["id"]})
        primary["history"].append({
            "merged_id": secondary["id"],
            "knowledge": secondary["knowledge"],
            "timestamp": self._now(),
        })
        self.archive_entry(secondary["id"], reason=f"merged_into:{primary['id']}")
        self._record_event("merge", primary_id=primary["id"], secondary_id=secondary["id"])
        self.save()
        return {"success": True, "entry": primary}

    def decay_report(self):
        now = datetime.now(timezone.utc)
        report = []
        for entry in self.entries:
            report.append({
                "id": entry["id"],
                "knowledge": entry["knowledge"],
                "stored_confidence": entry.get("confidence", 0.0),
                "effective_confidence": self._decayed_confidence(entry, now),
                "stability": entry.get("stability", 1.0),
                "importance": entry.get("importance", 0.5),
            })
        report.sort(key=lambda x: x["effective_confidence"])
        return report

    def all(self):
        return list(self.entries)
