import os
import shutil
import subprocess
from pathlib import Path


class NovaApkBuilder:
    """Construye una APK de N.O.V.A. usando el proyecto Android incluido."""

    def __init__(self, root=None):
        self.root = Path(root or Path.cwd()).resolve()

    def _run(self, cmd, cwd, timeout=180):
        try:
            p = subprocess.run(cmd, cwd=str(cwd), capture_output=True, text=True, timeout=timeout)
            return {"success": p.returncode == 0, "returncode": p.returncode,
                    "stdout": p.stdout[-12000:], "stderr": p.stderr[-12000:]}
        except Exception as exc:
            return {"success": False, "error": f"{type(exc).__name__}: {exc}"}

    def build(self, output=None):
        android = self.root / "android"
        if not android.is_dir():
            return {"success": False, "error": "No existe el proyecto Android en ./android."}

        out = Path(output) if output else self.root / "build-nova" / "NOVA-self.apk"
        out.parent.mkdir(parents=True, exist_ok=True)

        # Primero usa un Gradle disponible en el entorno.
        gradle_candidates = [
            shutil.which("gradle"),
            str(self.root / "gradlew") if (self.root / "gradlew").exists() else None,
        ]
        for gradle in gradle_candidates:
            if not gradle:
                continue
            result = self._run([gradle, ":app:assembleDebug", "--no-daemon"], android, timeout=240)
            if result["success"]:
                candidates = [
                    android / "app" / "build" / "outputs" / "apk" / "debug" / "app-debug.apk",
                    android / "app" / "build" / "outputs" / "apk" / "release" / "app-release.apk",
                ]
                built = next((x for x in candidates if x.exists()), None)
                if built:
                    shutil.copy2(built, out)
                    return {"success": True, "apk": str(out), "builder": "gradle", "source": str(built)}

        return {
            "success": False,
            "apk": str(out),
            "builder": "gradle",
            "error": (
                "No fue posible construir una APK nueva en este entorno. "
                "N.O.V.A. necesita Gradle/Android build tools compatibles. "
                "El sistema no reutiliza una APK anterior como si fuera una compilación nueva."
            ),
            "android_project": str(android),
        }
