from pathlib import Path
import math


class AssetBuilder:
    """Genera recursos ligeros y portables para proyectos de N.O.V.A."""

    def svg(self, path, width=512, height=512, shapes=None):
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        shapes = shapes or [{"type":"circle","cx":width/2,"cy":height/2,"r":100}]
        body=[]
        for s in shapes:
            t=s.get("type")
            if t=="circle":
                body.append(f'<circle cx="{s.get("cx",0)}" cy="{s.get("cy",0)}" r="{s.get("r",10)}" fill="{s.get("fill","white")}"/>')
            elif t=="rect":
                body.append(f'<rect x="{s.get("x",0)}" y="{s.get("y",0)}" width="{s.get("width",100)}" height="{s.get("height",100)}" fill="{s.get("fill","white")}"/>')
            elif t=="text":
                body.append(f'<text x="{s.get("x",0)}" y="{s.get("y",30)}" font-size="{s.get("size",32)}" fill="{s.get("fill","white")}">{s.get("text","NOVA")}</text>')
        target.write_text(f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">{"".join(body)}</svg>', encoding="utf-8")
        return {"success": True, "path": str(target), "format": "SVG"}

    def cube_obj(self, path, size=1.0):
        target=Path(path); target.parent.mkdir(parents=True, exist_ok=True)
        h=float(size)/2
        verts=[(-h,-h,-h),(h,-h,-h),(h,h,-h),(-h,h,-h),(-h,-h,h),(h,-h,h),(h,h,h),(-h,h,h)]
        faces=[(1,2,3,4),(5,8,7,6),(1,5,6,2),(2,6,7,3),(3,7,8,4),(5,1,4,8)]
        text=["# N.O.V.A. generated OBJ"]
        text += [f"v {x} {y} {z}" for x,y,z in verts]
        text += [f"f {' '.join(map(str,f))}" for f in faces]
        target.write_text("\n".join(text)+"\n",encoding="utf-8")
        return {"success":True,"path":str(target),"format":"OBJ","vertices":8,"faces":6}
