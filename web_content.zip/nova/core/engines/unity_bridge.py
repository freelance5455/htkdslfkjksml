import json
import socket
from pathlib import Path

UNITY_BRIDGE_SCRIPT = '#if UNITY_EDITOR\nusing System;\nusing System.Net;\nusing System.Net.Sockets;\nusing System.Text;\nusing UnityEditor;\nusing UnityEditor.SceneManagement;\nusing UnityEngine;\nusing UnityEngine.SceneManagement;\n\n[InitializeOnLoad]\npublic static class NovaBridgeServer\n{\n    [Serializable] private class Command\n    {\n        public string action;\n        public string name;\n        public string primitive;\n        public float x;\n        public float y;\n        public float z;\n    }\n\n    static TcpListener listener;\n    static bool running;\n\n    static NovaBridgeServer()\n    {\n        EditorApplication.update += Update;\n        Start();\n    }\n\n    public static void Start()\n    {\n        if (running) return;\n        try\n        {\n            listener = new TcpListener(IPAddress.Loopback, 17890);\n            listener.Start();\n            running = true;\n            Debug.Log("N.O.V.A. Unity Bridge activo en 127.0.0.1:17890");\n        }\n        catch (Exception e)\n        {\n            Debug.LogError("N.O.V.A. Unity Bridge: " + e.Message);\n        }\n    }\n\n    static void Update()\n    {\n        if (!running || listener == null || !listener.Pending()) return;\n        try\n        {\n            using (TcpClient client = listener.AcceptTcpClient())\n            using (NetworkStream stream = client.GetStream())\n            {\n                byte[] buffer = new byte[1024 * 1024];\n                int count = stream.Read(buffer, 0, buffer.Length);\n                string request = Encoding.UTF8.GetString(buffer, 0, count).Trim();\n                string response = Handle(request);\n                byte[] output = Encoding.UTF8.GetBytes(response + "\\n");\n                stream.Write(output, 0, output.Length);\n            }\n        }\n        catch (Exception e)\n        {\n            Debug.LogError("N.O.V.A. Unity Bridge: " + e.Message);\n        }\n    }\n\n    static string Handle(string request)\n    {\n        try\n        {\n            Command command = JsonUtility.FromJson<Command>(request);\n            if (command == null || string.IsNullOrEmpty(command.action))\n                return "{\\"success\\":false,\\"error\\":\\"Comando inválido.\\"}";\n\n            if (command.action == "ping")\n                return "{\\"success\\":true,\\"connected\\":true,\\"engine\\":\\"Unity\\"}";\n\n            if (command.action == "create_scene")\n            {\n                Scene scene = EditorSceneManager.NewScene(\n                    NewSceneSetup.DefaultGameObjects,\n                    NewSceneMode.Single\n                );\n                string path = "Assets/NovaGeneratedScene.unity";\n                EditorSceneManager.SaveScene(scene, path);\n                return "{\\"success\\":true,\\"action\\":\\"create_scene\\",\\"path\\":\\"Assets/NovaGeneratedScene.unity\\"}";\n            }\n\n            if (command.action == "create_primitive")\n            {\n                PrimitiveType type;\n                if (!Enum.TryParse(command.primitive, true, out type))\n                    return "{\\"success\\":false,\\"error\\":\\"Primitive no soportada.\\"}";\n\n                GameObject obj = GameObject.CreatePrimitive(type);\n                obj.name = string.IsNullOrEmpty(command.name) ? command.primitive : command.name;\n                obj.transform.position = new Vector3(command.x, command.y, command.z);\n                EditorUtility.SetDirty(obj);\n                return "{\\"success\\":true,\\"action\\":\\"create_primitive\\",\\"name\\":\\"" + obj.name + "\\"}";\n            }\n\n            return "{\\"success\\":false,\\"error\\":\\"Acción Unity no soportada.\\"}";\n        }\n        catch (Exception e)\n        {\n            return "{\\"success\\":false,\\"error\\":\\"" + Escape(e.Message) + "\\"}";\n        }\n    }\n\n    static string Escape(string value)\n    {\n        return (value ?? "").Replace("\\\\", "\\\\\\\\").Replace("\\"", "\\\\\\"");\n    }\n}\n#endif\n'

class UnityBridge:
    """Puente loopback para controlar el Unity Editor desde N.O.V.A."""
    DEFAULT_HOST = "127.0.0.1"
    DEFAULT_PORT = 17890

    def __init__(self, host=None, port=None, timeout=3.0):
        self.host = host or self.DEFAULT_HOST
        self.port = int(port or self.DEFAULT_PORT)
        self.timeout = float(timeout)

    def send(self, payload):
        if not isinstance(payload, dict):
            return {"success": False, "error": "El comando Unity debe ser un objeto."}
        try:
            data = (json.dumps(payload, ensure_ascii=False) + "\n").encode("utf-8")
            with socket.create_connection((self.host, self.port), timeout=self.timeout) as sock:
                sock.sendall(data)
                response = sock.recv(1024 * 1024).decode("utf-8").strip()
            result = json.loads(response) if response else {}
            return result if isinstance(result, dict) else {
                "success": False, "error": "Respuesta Unity inválida."
            }
        except Exception as exc:
            return {
                "success": False, "connected": False,
                "error": f"{type(exc).__name__}: {exc}",
                "host": self.host, "port": self.port,
            }

    def ping(self):
        return self.send({"action": "ping"})

    def create_scene(self):
        return self.send({"action": "create_scene"})

    def create_primitive(self, primitive="Cube", name="NOVA_Object", position=(0, 0, 0)):
        x, y, z = [float(v) for v in position]
        return self.send({
            "action": "create_primitive",
            "primitive": primitive,
            "name": name,
            "x": x, "y": y, "z": z,
        })

    def create_bridge_script(self, project):
        root = Path(project)
        target = root / "Assets" / "NovaBridge" / "NovaBridgeServer.cs"
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(UNITY_BRIDGE_SCRIPT, encoding="utf-8")
        return {"success": True, "path": str(target), "host": self.host, "port": self.port}

    def create_unity_project(self, project):
        root = Path("projects") / str(project).strip()
        root.mkdir(parents=True, exist_ok=True)
        self.create_bridge_script(root)
        (root / "README.md").write_text(
            "# Proyecto Unity controlado por N.O.V.A.\n\n"
            "Abre esta carpeta en Unity. El puente editor escucha en "
            "127.0.0.1:17890.\n"
            "Comandos iniciales: ping, create_scene y create_primitive.\n",
            encoding="utf-8",
        )
        return {
            "success": True,
            "project": str(root),
            "bridge": str(root / "Assets" / "NovaBridge" / "NovaBridgeServer.cs"),
            "transport": "TCP loopback",
            "requires_unity_editor": True,
        }
