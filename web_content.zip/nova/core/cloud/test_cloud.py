from core.cloud.cloud_client import CloudClient


class FakeClient:
    def request(self, url, method="GET", data=None, headers=None):
        return {"success": True, "status": 202, "data": {"accepted": True}}


def test_cloud_submission():
    result = CloudClient(
        endpoint="https://cloud.example/tasks",
        client=FakeClient(),
    ).submit("build")
    assert result["success"] is True
    assert result["status"] == 202


def test_cloud_missing_endpoint():
    result = CloudClient().submit("build")
    assert result["success"] is False
    assert result["pending"] is True


if __name__ == "__main__":
    test_cloud_submission()
    test_cloud_missing_endpoint()
    print("Cloud tests passed.")
