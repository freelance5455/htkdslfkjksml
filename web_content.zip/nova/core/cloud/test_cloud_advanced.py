from core.cloud.cloud_client import CloudClient


def test_cloud_rejects_missing_endpoint():
    result = CloudClient().submit("build")
    assert result["success"] is False
    assert result["pending"] is True


def test_cloud_rejects_missing_task():
    result = CloudClient(endpoint="https://example.test").submit(None)
    assert result["success"] is False
    assert result["pending"] is False


if __name__ == "__main__":
    test_cloud_rejects_missing_endpoint()
    test_cloud_rejects_missing_task()
    print("CLOUD ADVANCED TESTS OK")
