from core.internet.internet_client import InternetClient


class CloudClient:
    """Adaptador cloud HTTP con endpoint explícito y respuesta acotada."""

    def __init__(self, endpoint=None, client=None):
        self.endpoint = endpoint
        self.client = client or InternetClient()

    def submit(self, task, endpoint=None, headers=None):
        target = endpoint or self.endpoint
        if not isinstance(target, str) or not target.startswith(("http://", "https://")):
            return {
                "success": False,
                "pending": True,
                "error": "No hay un endpoint cloud HTTP/HTTPS válido.",
            }

        if task is None:
            return {
                "success": False,
                "pending": False,
                "error": "Falta la tarea cloud.",
            }

        return self.client.request(
            target,
            method="POST",
            data={"task": task},
            headers=headers,
        )
