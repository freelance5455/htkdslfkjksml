"""
Puente HTTP real de N.O.V.A.
=============================

Este servidor NO simula nada: importa las clases reales del núcleo
(core/...) y expone su estado y sus acciones como endpoints JSON para
que la interfaz (ui/index.html) los consuma.

No usa dependencias externas (solo librería estándar), así funciona
igual en Termux/Android que en un escritorio, sin `pip install`.

Ejecutar desde la raíz del proyecto:

    PYTHONPATH=. python bridge/nova_bridge_server.py [puerto]

Por defecto sirve en http://127.0.0.1:8787/
Abrir esa URL en el navegador muestra la interfaz (ui/index.html) que
ya viene servida por este mismo proceso, así que no hay problemas de
CORS ni configuración adicional.
"""

import json
import os
import sys
import threading
import traceback
import secrets
import subprocess
from pathlib import Path
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)
os.chdir(ROOT)  # todas las rutas relativas del núcleo (core/state/*.json, etc.) cuelgan de la raíz

UI_DIR = os.path.join(ROOT, "ui")

from core.runtime.cognitive_runtime import CognitiveRuntime
from core.runtime.tool_catalog import build_tool_registry
from core.security.security_guard import SecurityGuard
from core.security.permission_manager import PermissionManager
from core.security.audit_log import SecurityAuditLog
from core.self_repair.self_repair import SelfRepair
from core.connectors.connector_manager import ConnectorManager
from core.connectors.adapters.unity import UnityConnector
from core.connectors.adapters.unity_cloud import UnityCloudConnector
from core.voice.voice_pipeline import VoicePipeline
from core.runtime.system_metrics import SystemMetrics
from core.runtime.state_timeline import StateTimeline
from core.runtime.weather_service import WeatherService

# ---------------------------------------------------------------------------
# Núcleo real: una sola instancia compartida por todas las peticiones.
# ---------------------------------------------------------------------------
LOCK = threading.RLock()

runtime = CognitiveRuntime()
tool_registry = build_tool_registry()
permission_manager = PermissionManager()
security_guard = SecurityGuard()
audit_log = SecurityAuditLog()
self_repair = SelfRepair(root=ROOT)
voice = VoicePipeline()

connectors = ConnectorManager()
connectors.register(UnityConnector())
connectors.register(UnityCloudConnector())

BOOT_TIME = datetime.now(timezone.utc).isoformat()
CONFIG_DIR = Path(ROOT) / "config"
TOKEN_PATH = CONFIG_DIR / "bridge_token"
CONFIG_DIR.mkdir(parents=True, exist_ok=True)

def _load_token():
    env_token = os.environ.get("NOVA_BRIDGE_TOKEN", "").strip()
    if env_token:
        return env_token
    try:
        if TOKEN_PATH.exists():
            token = TOKEN_PATH.read_text(encoding="utf-8").strip()
            if token:
                return token
    except OSError:
        pass
    token = secrets.token_urlsafe(32)
    try:
        TOKEN_PATH.write_text(token + "\n", encoding="utf-8")
        try:
            TOKEN_PATH.chmod(0o600)
        except OSError:
            pass
    except OSError:
        pass
    return token

BRIDGE_TOKEN = _load_token()
metrics = SystemMetrics()
timeline = StateTimeline()
weather = WeatherService()
LAST_SNAPSHOT = {}


def now():
    return datetime.now(timezone.utc).isoformat()


def safe(fn, fallback=None):
    """Ejecuta fn() y nunca deja que un subsistema roto tumbe todo el snapshot."""
    try:
        return fn()
    except Exception as exc:  # noqa: BLE001 - queremos capturar cualquier fallo de un subsistema
        return {
            "success": False,
            "error": f"{type(exc).__name__}: {exc}",
        } if fallback is None else fallback


def derive_core_state():
    """
    Traduce el estado REAL de los distintos subsistemas al vocabulario de
    estados que pide la interfaz (IDLE / LISTENING / THINKING / PLANNING /
    EXECUTING / VERIFYING / LEARNING / REFLECTING / ERROR).

    No inventa un estado si no hay una señal real que lo respalde: cuando no
    hay evidencia, cae a IDLE.
    """
    state_snapshot = runtime.state.snapshot()
    cognitive_mode = runtime.cycle.state.data.get("mode", "idle")
    voice_state = voice.state.current

    if state_snapshot.get("status") == "error":
        return "ERROR"
    if voice_state == "listening":
        return "LISTENING"
    if voice_state in ("processing", "responding"):
        return "THINKING"
    if cognitive_mode == "reflecting":
        return "REFLECTING"
    if cognitive_mode == "thinking":
        return "THINKING"
    last_result = state_snapshot.get("last_result") or {}
    if last_result.get("type") == "learning":
        return "LEARNING"
    if state_snapshot.get("status") == "processing":
        return "EXECUTING"
    return "IDLE"


def build_snapshot():
    with LOCK:
        state_snapshot = safe(runtime.state.snapshot, {})
        cognitive = safe(lambda: runtime.cycle.state.snapshot(), {})
        self_model = safe(lambda: runtime.cycle.self_model.snapshot(), {})
        working_memory = safe(lambda: runtime.cycle.working.recent(8), [])
        affect = safe(lambda: runtime.state.affect.snapshot(), {})
        memory_entries = safe(lambda: runtime.memory.entries, [])
        autobiography = safe(runtime.autobiography.snapshot, {"count": 0, "recent": []})
        episodes = safe(lambda: runtime.episodes.recent(10), [])
        goals_active = safe(runtime.goals.active, [])
        next_goal = safe(runtime.goals.next_active, None)
        autonomy = safe(runtime.autonomous_loop.status, {})
        initiative = safe(runtime.initiative.evaluate, {})
        improvement = safe(lambda: runtime.improvement_lab.list()[-10:], [])
        permissions = safe(permission_manager.status, {})
        audit = safe(lambda: audit_log.read(20), [])
        repair_status = safe(self_repair.status, {})
        voice_status = safe(voice.status, {})
        connector_list = safe(connectors.list_connectors, [])
        tools_summary = safe(tool_registry.summary, {})
        system_metrics = safe(metrics.snapshot, {"current": {}, "history": []})
        state_name = derive_core_state()
        timeline.record(state_name, state_snapshot.get("last_result", {}).get("message", "") if isinstance(state_snapshot.get("last_result"), dict) else "")
        weather_snapshot = safe(weather.get, {"available": False, "source": "error"})

        return {
            "timestamp": now(),
            "boot_time": BOOT_TIME,
            "core_state": derive_core_state(),
            "state": state_snapshot,
            "cognition": {
                "state": cognitive,
                "self_model": self_model,
                "working_memory": working_memory,
                "affect": affect,
            },
            "memory": {
                "total_entries": len(memory_entries) if isinstance(memory_entries, list) else 0,
                "recent": [
                    {
                        "id": e.get("id"),
                        "knowledge": e.get("knowledge"),
                        "confidence": e.get("confidence"),
                        "tags": e.get("tags"),
                        "source": e.get("source"),
                        "updated_at": e.get("updated_at"),
                    }
                    for e in (memory_entries[-8:] if isinstance(memory_entries, list) else [])
                ][::-1],
            },
            "autobiography": autobiography,
            "episodes": episodes,
            "goals": {"active": goals_active, "next": next_goal},
            "autonomy": autonomy,
            "initiative": initiative,
            "improvement": improvement,
            "security": {
                "permissions": permissions,
                "recent_audit": audit,
            },
            "self_repair": repair_status,
            "voice": voice_status,
            "connectors": connector_list,
            "tools": {"summary": tools_summary, "total": tool_registry.count()},
            "system": system_metrics,
            "state_timeline": timeline.recent(15),
            "weather": weather_snapshot,
            "server": {"host": os.environ.get("NOVA_BRIDGE_HOST", "127.0.0.1"), "port": int(os.environ.get("NOVA_BRIDGE_PORT", "8787"))},
        }


# ---------------------------------------------------------------------------
# Rutas
# ---------------------------------------------------------------------------

def route_command(payload):
    text = str(payload.get("text", "")).strip()
    if not text:
        return 400, {"success": False, "error": "Falta 'text'."}
    with LOCK:
        result = runtime.process(text)
    return 200, result


def route_autonomy_enable(payload):
    with LOCK:
        return 200, {"success": True, "autonomy": runtime.autonomous_loop.enable()}


def route_autonomy_disable(payload):
    with LOCK:
        return 200, {"success": True, "autonomy": runtime.autonomous_loop.disable()}


def route_autonomy_tick(payload):
    execute = bool(payload.get("execute", False))
    with LOCK:
        return 200, runtime.autonomous_loop.tick(execute=execute)


def route_goals_create(payload):
    name = str(payload.get("name", "")).strip()
    if not name:
        return 400, {"success": False, "error": "Falta 'name'."}
    priority = payload.get("priority", 0)
    with LOCK:
        goal = runtime.goals.create(name, priority=priority)
    return 200, {"success": True, "goal": goal}


def route_goals_update(payload):
    goal_id = payload.get("id")
    if goal_id is None:
        return 400, {"success": False, "error": "Falta 'id'."}
    with LOCK:
        goal = runtime.goals.update(
            int(goal_id),
            progress=payload.get("progress"),
            status=payload.get("status"),
            priority=payload.get("priority"),
        )
    if goal is None:
        return 404, {"success": False, "error": "Objetivo no encontrado."}
    return 200, {"success": True, "goal": goal}


def route_self_repair_diagnose(payload):
    files = payload.get("files")
    with LOCK:
        return 200, self_repair.diagnose(files)


def route_self_repair_backup(payload):
    relative = str(payload.get("file", "")).strip()
    if not relative:
        return 400, {"success": False, "error": "Falta 'file'."}
    with LOCK:
        return 200, self_repair.backup(relative)


def route_security_authorize(payload):
    action = str(payload.get("action", "")).strip()
    if not action:
        return 400, {"success": False, "error": "Falta 'action'."}
    context = payload.get("context") or {}
    with LOCK:
        return 200, security_guard.authorize(action, context=context)


def route_security_permission(payload):
    action = payload.get("action")
    permission = payload.get("permission")
    if action not in {"grant", "revoke"} or not permission:
        return 400, {"success": False, "error": "Se requiere 'permission' y action grant/revoke."}
    with LOCK:
        if action == "grant":
            result = permission_manager.grant(permission)
        else:
            result = permission_manager.revoke(permission)
    return 200, result


def route_improvement_propose(payload):
    title = str(payload.get("title", "")).strip()
    hypothesis = str(payload.get("hypothesis", "")).strip()
    if not title or not hypothesis:
        return 400, {"success": False, "error": "Se requieren 'title' e 'hypothesis'."}
    with LOCK:
        return 200, runtime.propose_improvement(title, hypothesis, payload.get("targets"))


def route_connectors_execute(payload):
    connector = str(payload.get("connector", "")).strip()
    action = str(payload.get("action", "")).strip()
    if not connector or not action:
        return 400, {"success": False, "error": "Se requieren 'connector' y 'action'."}
    kwargs = {k: v for k, v in payload.items() if k not in ("connector", "action")}
    with LOCK:
        return 200, connectors.execute(connector, action, **kwargs)


def route_voice_set(payload):
    state = str(payload.get("state", "")).strip()
    with LOCK:
        return 200, voice.state.set(state)


def route_self_repair_apply(payload):
    relative = str(payload.get("file", "")).strip()
    content = payload.get("content")
    if not relative or content is None:
        return 400, {"success": False, "error": "Se requieren 'file' y 'content'."}
    permission = permission_manager.check("modify_project_files")
    if not permission.get("allowed"):
        return 403, {"success": False, "error": permission.get("reason")}
    with LOCK:
        return 200, self_repair.apply_text_fix(relative, str(content))


def route_self_repair_rollback(payload):
    backup = str(payload.get("backup", "")).strip()
    destination = str(payload.get("destination", "")).strip()
    if not backup or not destination:
        return 400, {"success": False, "error": "Se requieren 'backup' y 'destination'."}
    with LOCK:
        return 200, self_repair.rollback(backup, destination)


def route_camera_capture(payload):
    requested = str(payload.get("path", "")).strip()
    target = requested or str(Path(ROOT) / "logs" / "camera_latest.jpg")
    target_path = Path(target).resolve()
    try:
        target_path.relative_to(Path(ROOT).resolve())
    except ValueError:
        return 400, {"success": False, "error": "Ruta de cámara fuera del proyecto."}
    target_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        proc = subprocess.run(["termux-camera-photo", "-c", "0", str(target_path)], capture_output=True, text=True, timeout=20)
    except FileNotFoundError:
        return 503, {"success": False, "error": "termux-camera-photo no está instalado en este entorno."}
    except Exception as exc:
        return 500, {"success": False, "error": f"{type(exc).__name__}: {exc}"}
    if proc.returncode != 0 or not target_path.exists():
        return 500, {"success": False, "error": (proc.stderr or proc.stdout or "La cámara no devolvió una captura.").strip()}
    return 200, {"success": True, "path": str(target_path.relative_to(Path(ROOT))), "size": target_path.stat().st_size}


POST_ROUTES = {
    "/api/command": route_command,
    "/api/autonomy/enable": route_autonomy_enable,
    "/api/autonomy/disable": route_autonomy_disable,
    "/api/autonomy/tick": route_autonomy_tick,
    "/api/goals/create": route_goals_create,
    "/api/goals/update": route_goals_update,
    "/api/self_repair/diagnose": route_self_repair_diagnose,
    "/api/self_repair/backup": route_self_repair_backup,
    "/api/self_repair/apply": route_self_repair_apply,
    "/api/self_repair/rollback": route_self_repair_rollback,
    "/api/camera/capture": route_camera_capture,
    "/api/security/authorize": route_security_authorize,
    "/api/security/permission": route_security_permission,
    "/api/improvement/propose": route_improvement_propose,
    "/api/connectors/execute": route_connectors_execute,
    "/api/voice/set": route_voice_set,
}


def route_get_snapshot(_qs):
    return 200, build_snapshot()


def route_get_health(_qs):
    return 200, {"success": True, "status": "ok", "boot_time": BOOT_TIME, "time": now()}


def route_get_session_token(handler):
    client = handler.client_address[0] if handler.client_address else ""
    if client not in {"127.0.0.1", "::1"}:
        return 403, {"success": False, "error": "El token de sesión solo se entrega a clientes locales."}
    return 200, {"success": True, "token": BRIDGE_TOKEN}


def route_get_tools(_qs):
    tools = [
        {"name": t["name"], "level": t["level"], "description": t["description"]}
        for t in tool_registry.all()
    ]
    return 200, {"total": len(tools), "summary": tool_registry.summary(), "tools": tools}


def route_get_audit(qs):
    limit = int((qs.get("limit") or ["50"])[0])
    return 200, {"entries": audit_log.read(limit)}


def route_get_memory(qs):
    query = (qs.get("query") or [""])[0]
    limit = int((qs.get("limit") or ["10"])[0])
    with LOCK:
        if query:
            return 200, {"results": runtime.memory.search(query, limit=limit)}
        entries = sorted(runtime.memory.entries, key=lambda e: e.get("updated_at", ""), reverse=True)
        return 200, {"results": entries[:limit]}


def route_get_autobiography(qs):
    query = (qs.get("query") or [""])[0]
    limit = int((qs.get("limit") or ["10"])[0])
    with LOCK:
        return 200, {"results": runtime.autobiography.recall(query, limit=limit)}


GET_ROUTES = {
    "/api/health": route_get_health,
    "/api/snapshot": route_get_snapshot,
    "/api/tools": route_get_tools,
    "/api/security/audit": route_get_audit,
    "/api/memory": route_get_memory,
    "/api/autobiography": route_get_autobiography,
}


class Handler(BaseHTTPRequestHandler):
    server_version = "NOVA-Bridge/2.0"

    def log_message(self, fmt, *args):
        return

    def _send_json(self, status, payload):
        body = json.dumps(payload, ensure_ascii=False, default=str).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", self.headers.get("Origin", "http://127.0.0.1:8787"))
        self.send_header("Vary", "Origin")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-NOVA-Token")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _send_file(self, path, content_type):
        try:
            with open(path, "rb") as fh:
                data = fh.read()
        except OSError:
            self.send_error(404)
            return
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", self.headers.get("Origin", "http://127.0.0.1:8787"))
        self.send_header("Vary", "Origin")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-NOVA-Token")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.end_headers()

    def _authorized(self):
        supplied = self.headers.get("X-NOVA-Token", "").strip()
        return bool(supplied) and secrets.compare_digest(supplied, BRIDGE_TOKEN)

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        qs = parse_qs(parsed.query)

        if path in ("/", "/ui", "/ui/", "/index.html"):
            self._send_file(os.path.join(UI_DIR, "index.html"), "text/html; charset=utf-8")
            return

        if path == "/media/camera_latest.jpg":
            client = self.client_address[0] if self.client_address else ""
            if client not in {"127.0.0.1", "::1"} and not self._authorized():
                self._send_json(401, {"success": False, "error": "Token de puente requerido."})
                return
            self._send_file(os.path.join(ROOT, "logs", "camera_latest.jpg"), "image/jpeg")
            return

        if path == "/api/session-token":
            status, payload = route_get_session_token(self)
            self._send_json(status, payload)
            return

        if path != "/api/health" and not self._authorized():
            self._send_json(401, {"success": False, "error": "Token de puente requerido."})
            return

        handler = GET_ROUTES.get(path)
        if handler is None:
            self._send_json(404, {"success": False, "error": f"Ruta no encontrada: {path}"})
            return
        try:
            status, payload = handler(qs)
        except Exception as exc:
            status, payload = 500, {
                "success": False,
                "error": f"{type(exc).__name__}: {exc}",
                "trace": traceback.format_exc(limit=3),
            }
        self._send_json(status, payload)

    def do_POST(self):
        parsed = urlparse(self.path)
        if not self._authorized():
            self._send_json(401, {"success": False, "error": "Token de puente requerido."})
            return
        path = parsed.path
        handler = POST_ROUTES.get(path)
        if handler is None:
            self._send_json(404, {"success": False, "error": f"Ruta no encontrada: {path}"})
            return

        length = int(self.headers.get("Content-Length", "0") or "0")
        if length < 0 or length > 500_000:
            self._send_json(413, {"success": False, "error": "Cuerpo demasiado grande."})
            return

        raw = self.rfile.read(length) if length else b"{}"
        try:
            payload = json.loads(raw.decode("utf-8") or "{}")
            if not isinstance(payload, dict):
                raise ValueError("El cuerpo debe ser un objeto JSON.")
        except Exception as exc:
            self._send_json(400, {"success": False, "error": f"JSON inválido: {exc}"})
            return

        try:
            status, result = handler(payload)
        except Exception as exc:
            status, result = 500, {
                "success": False,
                "error": f"{type(exc).__name__}: {exc}",
                "trace": traceback.format_exc(limit=3),
            }
        self._send_json(status, result)


def main():
    port = int(sys.argv[1]) if len(sys.argv) > 1 else int(os.environ.get("NOVA_BRIDGE_PORT", "8787"))
    host = os.environ.get("NOVA_BRIDGE_HOST", "127.0.0.1")
    server = ThreadingHTTPServer((host, port), Handler)
    print(f"N.O.V.A. bridge real activo en http://{host}:{port}/")
    print("Token local persistente en config/bridge_token; endpoints de acción protegidos.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.shutdown()


if __name__ == "__main__":
    main()
