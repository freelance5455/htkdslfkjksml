#!/data/data/com.termux/files/usr/bin/bash
set -e
cd "$(dirname "$0")"
export PYTHONPATH=.
export NOVA_BRIDGE_HOST="${NOVA_BRIDGE_HOST:-127.0.0.1}"
export NOVA_BRIDGE_PORT="${NOVA_BRIDGE_PORT:-8787}"
python bridge/nova_bridge_server.py "$NOVA_BRIDGE_PORT"
