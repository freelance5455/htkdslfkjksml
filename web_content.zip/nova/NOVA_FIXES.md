# N.O.V.A. — Correcciones para que el APK conecte con el cerebro

## Causas encontradas
1. `MainActivity.java` no compilaba: `disableContinuousListening()` usaba una variable `response` inexistente (código duplicado de `respond()`).
2. `network_security_config.xml` solo permitía cleartext a `localhost`; la app usa `127.0.0.1` (Android los trata como dominios distintos).
3. El APK era solo un cliente HTTP: no llevaba el cerebro Python ni cargaba `ui/index.html`. Sin Termux corriendo el bridge, quedaba "reconectando/OFFLINE" para siempre.
4. El botón de micrófono del HUD solo mostraba un toast.

## Solución
- Chaquopy 17.0.0 (Python 3.11, ABIs armeabi-v7a + arm64-v8a) embebe el intérprete.
- `assets/nova_src.zip` = core/ + bridge/ + ui/ (limpios). `NovaCoreService` lo extrae a `filesDir/nova` y ejecuta `bridge.nova_bridge_server.main()` (mismo código que en Termux).
- Memoria/estado/config/logs ya existentes NUNCA se sobrescriben al actualizar la app.
- `MainActivity` = WebView con reintentos que carga el HUD completo; puente de voz `window.Android` (STT/TTS reales).
- Si el núcleo falla al arrancar se muestra el error real (y queda en `filesDir/nova/BOOT_ERROR.txt`) en vez de un spinner infinito.
- ⚙: en el menú (tecla Menú) se puede apuntar a otro bridge externo.

## Compilar
Requiere Android SDK + JDK 17 + Python 3.11 + Gradle 9.1+ en máquina **64-bit** (AAPT2 no corre en Termux 32-bit).
    cd android && gradle assembleDebug
o sube el proyecto a GitHub y ejecuta el workflow `.github/workflows/build-apk.yml` (descarga el APK como artefacto).
Si tu Termux dice `uname -m` = armv7l en un teléfono de 64-bit, reinstala Termux arm64.
Si actualizas el código Python, regenera el zip: `cd <raiz> && zip -r -X android/app/assets/nova_src.zip core bridge ui` (excluye __pycache__ y backups).

## Verificado aquí
Zip extraído en otra ruta + import de `bridge.nova_bridge_server` + `main()`: UI 200, snapshot con 56 herramientas, `/api/command` responde. Sintaxis Python compatible con 3.11. JS del HUD válido.
## NO verificado
La compilación del APK y la ejecución en el teléfono (sin Android SDK/red en este entorno). Versión de Gradle 9.1.0 en el workflow: confirma que sea la que pide tu AGP 9.0.1.
