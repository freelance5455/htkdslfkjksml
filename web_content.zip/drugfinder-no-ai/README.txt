DrugFinder — No-AI version

This version removes the AI tutor, chat history, memory controls, OpenAI API calls, and AI branding. It keeps medicine search using public sources, medicine profiles, safety/dose reference links, saved medicines, study tools, and country preferences.

Run: open index.html in a modern browser. Internet access is needed for live public-source searches. No API key or backend server is required.

Note: this is an educational prototype, not a diagnostic or prescribing tool. Dose Reference opens official databases and does not calculate a dose.
