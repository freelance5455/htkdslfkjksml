ANSAR CRICKET - Android web-app project
Created for Ansarullah Zaheer.

This ZIP contains a mobile-friendly cricket game project.
It is NOT an APK file.

To use:
1. Extract this ZIP.
2. Upload the folder to a secure HTTPS static website host.
3. Open the hosted page in Chrome on Android.
4. Use Chrome menu > Add to Home screen / Install app.

The service worker caches the game for offline use after the first successful load.
To create a true Android APK, this web project must be wrapped/built with an Android app builder or Android Studio.
