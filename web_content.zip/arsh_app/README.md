# ARSH.Ai VIP — Cyber Toolbox v1.5 (Android wrapper)

این پوشه یک پروژه‌ی آماده‌ی **Capacitor** است که اپ وب شما (`www/index.html`) را
به یک اپلیکیشن اندرویدی تبدیل می‌کند. چون محیط من (Claude) دسترسی به اینترنت و
Android SDK ندارد، نمی‌توانم خودِ فایل APK را همین‌جا بسازم — اما این پروژه
۱۰۰٪ آماده‌ی ساخت است و فقط چند دستور ساده روی سیستم خودتان لازم دارد.

## پیش‌نیازها (روی کامپیوتر خودتان)
1. [Node.js](https://nodejs.org) نسخه ۱۸ به بالا
2. [Android Studio](https://developer.android.com/studio) (شامل Android SDK)
3. JDK 17

## مراحل ساخت APK

```bash
# 1) وارد پوشه پروژه شوید
cd arsh_app

# 2) نصب وابستگی‌ها
npm install

# 3) افزودن پلتفرم اندروید (یک‌بار، پوشه android/ را می‌سازد)
npx cap add android

# 4) همگام‌سازی فایل‌های وب با پروژه اندروید
npx cap sync android

# 5) ساخت APK (نسخه debug، برای تست سریع)
cd android
./gradlew assembleDebug
```

فایل خروجی اینجا قرار می‌گیرد:
```
android/app/build/outputs/apk/debug/app-debug.apk
```

### ساخت نسخه release (امضا‌شده، برای انتشار)
```bash
cd android
./gradlew assembleRelease
```
برای release باید یک keystore بسازید و در `android/app/build.gradle` تنظیم امضا را اضافه کنید
(راهنمای رسمی: https://developer.android.com/studio/publish/app-signing).

### جایگزین سریع‌تر: باز کردن در Android Studio
```bash
npx cap open android
```
سپس از داخل Android Studio روی Run بزنید یا از منوی Build > Build APK(s) استفاده کنید.

## ساختار پروژه
```
arsh_app/
├── package.json          ← وابستگی‌ها و اسکریپت‌ها
├── capacitor.config.json ← تنظیمات Capacitor (appId, appName, webDir)
├── www/
│   └── index.html        ← کل اپ شما (HTML+CSS+JS در یک فایل)
└── README.md              ← همین فایل
```

پس از اجرای `npx cap add android`، یک پوشه‌ی کامل `android/` (پروژه‌ی نیتیو Gradle)
به‌صورت خودکار توسط Capacitor ساخته می‌شود — همان چیزی که برای کامپایل APK لازم است.

## نکته درباره قابلیت‌های اپ
بخش «CYBER LAB» در این نسخه کاملاً نمایشی (sandbox) است: ابزارهایی مثل
Base64، Hash، UUID، Regex Tester و... فقط روی داده‌ای که خودتان وارد می‌کنید
در همان صفحه اجرا می‌شوند و هیچ دسترسی پنهانی به شبکه، دوربین یا فایل‌های
دستگاه ندارند.
