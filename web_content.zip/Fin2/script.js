/**
 * التفوق في الباك - التطبيق الرئيسي
 * واجهتان: الرئيسية + المشغل
 * تنقل هرمي + مشغل PDF ذكي + إعدادات كاملة
 * v1.1 - إصلاح زر الرجوع + تنزيل متقدم + مشاركة
 */

import * as pdfjsLib from 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.4.168/pdf.min.mjs';

pdfjsLib.GlobalWorkerOptions.workerSrc =
  'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.4.168/pdf.worker.min.mjs';

// ===================== الثوابت =====================
const STORAGE_KEYS = {
  settings: 'tafaouq_settings',
  stats: 'tafaouq_stats',
};

const DEFAULT_SETTINGS = {
  theme: 'light',
  primaryColor: '#2563eb',
  font: 'Cairo',
  icons: 'emoji',
  viewMode: 'grid',
  version: '1.1',
  releaseDate: '2026-09-24',
};

const PRIMARY_COLORS = [
  { name: 'أزرق', value: '#2563eb' },
  { name: 'بنفسجي', value: '#7c3aed' },
  { name: 'أخضر', value: '#059669' },
  { name: 'برتقالي', value: '#ea580c' },
  { name: 'وردي', value: '#db2777' },
  { name: 'سماوي', value: '#0891b2' },
];

const FONTS = [
  { name: 'القاهرة', value: 'Cairo' },
  { name: 'أميري', value: 'Amiri' },
  { name: 'نوتو نسخ', value: 'Noto Naskh Arabic' },
  { name: 'تجوال', value: 'Tajawal' },
];

const STREAM_EMOJIS = {
  mathematics: '🧮',
  'experimental-sciences': '🧪',
  'tech-math': '⚙️',
  'gestion-economy': '📊',
  'literature-philosophy': '📚',
  'foreign-languages': '🌍',
};

const SUBJECT_EMOJIS = {
  mathematics: '🔢',
  physics: '⚛️',
  arabic: '📖',
  english: '🇬🇧',
  french: '🇫🇷',
  'natural-sciences': '🧬',
  'islamic-edu': '🕌',
  'history-geography': '🗺️',
  philosophy: '💭',
  'mechanical-engineering': '🔧',
  'electrical-engineering': '⚡',
  'civil-engineering': '🏗️',
  'process-engineering': '🏭',
  economy: '💹',
  accounting: '📒',
  law: '⚖️',
  italian: '🇮🇹',
  german: '🇩🇪',
  spanish: '🇪🇸',
};

// ===================== الحالة =====================
let data = null;
let currentView = 'home';
let navStack = [{ type: 'streams' }];
let currentDoc = null;

// سجل الطبقات (Overlays) لربط زر الرجوع
// كل عنصر: { type: 'sheet' | 'search' | 'sidebar' | 'download', closeFn }
let layerStack = [];

// PDF engine state
let currentPdf = null;
let currentPage = 1;
let totalPages = 0;
let currentScale = 1.0;
let baseScale = 1.0;
let currentFileName = '';
let currentFileUrl = null;

const pageStates = new Map();
let renderQueue = [];
let renderQueueRunning = false;
let pageObserver = null;
let renderGeneration = 0;
let loadGeneration = 0;

const NEXT_PRELOAD = 4;
const PREVIOUS_CACHE = 4;
const OBSERVER_MARGIN = '120% 0px 120% 0px';
const MAX_ZOOM = 3;
const DOUBLE_TAP_DELAY = 320;

let suppressBrowserDoubleClickUntil = 0;

// ===================== حالة التنزيل =====================
let downloadController = null;
let isDownloading = false;
let downloadIndicatorEl = null;

// ===================== العناصر =====================
const $ = (id) => document.getElementById(id);

const headerTitle = $('headerTitle');
const customBtn = $('customBtn');
const customBtnIcon = $('customBtnIcon');
const menuBtn = $('menuBtn');
const sidebar = $('sidebar');
const sidebarOverlay = $('sidebarOverlay');
const sidebarClose = $('sidebarClose');
const homeView = $('homeView');
const playerView = $('playerView');
const homeContainer = $('homeContainer');
const pdfContainer = $('pdfContainer');
const prevPageBtn = $('prevPageBtn');
const nextPageBtn = $('nextPageBtn');
const pageInfo = $('pageInfo');
const zoomInBtn = $('zoomInBtn');
const zoomOutBtn = $('zoomOutBtn');
const zoomInfo = $('zoomInfo');
const closePlayerBtn = $('closePlayerBtn');
const sharePlayerBtn = $('sharePlayerBtn');
const searchModal = $('searchModal');
const loadingOverlay = $('loadingOverlay');
const toast = $('toast');
const appError = $('appError');
const appErrorMessage = $('appErrorMessage');
const retryDataBtn = $('retryDataBtn');
const bottomSheet = $('bottomSheet');
const sheetContent = $('sheetContent');
const sheetTitle = $('sheetTitle');
const sheetBody = $('sheetBody');
const sheetClose = $('sheetClose');
const sheetBackdrop = $('sheetBackdrop');

// عناصر بطاقة التنزيل
const downloadSheet = $('downloadSheet');
const downloadBackdrop = $('downloadBackdrop');
const downloadClose = $('downloadClose');
const downloadFileNameEl = $('downloadFileName');
const downloadFileMetaEl = $('downloadFileMeta');
const downloadProgressWrapper = $('downloadProgressWrapper');
const downloadProgressFill = $('downloadProgressFill');
const downloadProgressText = $('downloadProgressText');
const downloadStats = $('downloadStats');
const downloadSpeed = $('downloadSpeed');
const downloadTime = $('downloadTime');
const downloadSize = $('downloadSize');
const downloadState = $('downloadState');
const downloadStartBtn = $('downloadStartBtn');
const downloadCancelBtn = $('downloadCancelBtn');
const downloadShareBtn = $('downloadShareBtn');

// ===================== التهيئة =====================
document.addEventListener('DOMContentLoaded', async () => {
  applySettings(loadSettings());
  setupEventListeners();
  updateVersionBadge();
  detectShareSupport();

  const loaded = await loadData();

  if (loaded) {
    renderHome();
  }
});

async function loadData() {
  hideAppError();

  try {
    const res = await fetch('document.json', {
      cache: 'no-store',
      credentials: 'same-origin',
    });

    if (!res.ok) {
      throw new Error(`HTTP ${res.status}`);
    }

    const json = await res.json();

    if (!json || !Array.isArray(json.streams)) {
      throw new Error('Invalid document.json structure');
    }

    data = json;
    return true;
  } catch (err) {
    console.error('document.json load failed:', err);
    data = null;
    showAppError('تعذر تحميل بيانات الموقع. تحقق من الاتصال ثم حاول مرة أخرى.');
    return false;
  }
}

function showAppError(message) {
  if (appErrorMessage) appErrorMessage.textContent = message;
  if (appError) appError.hidden = false;
}

function hideAppError() {
  if (appError) appError.hidden = true;
}

function detectShareSupport() {
  // Web Share API يدعم مشاركة الملفات أو الروابط
  if (typeof navigator.share === 'function') {
    if (sharePlayerBtn) sharePlayerBtn.hidden = false;
  }
}

// ===================== الإعدادات =====================
function loadSettings() {
  try {
    const stored = JSON.parse(localStorage.getItem(STORAGE_KEYS.settings) || '{}');
    const merged = {
      ...DEFAULT_SETTINGS,
      ...(stored && typeof stored === 'object' ? stored : {}),
    };

    merged.version = DEFAULT_SETTINGS.version;
    merged.releaseDate = DEFAULT_SETTINGS.releaseDate;

    if (!['light', 'dark'].includes(merged.theme)) merged.theme = DEFAULT_SETTINGS.theme;
    if (!PRIMARY_COLORS.some((c) => c.value === merged.primaryColor)) merged.primaryColor = DEFAULT_SETTINGS.primaryColor;
    if (!FONTS.some((f) => f.value === merged.font)) merged.font = DEFAULT_SETTINGS.font;
    if (!['emoji', 'fontawesome'].includes(merged.icons)) merged.icons = DEFAULT_SETTINGS.icons;
    if (!['grid', 'list'].includes(merged.viewMode)) merged.viewMode = DEFAULT_SETTINGS.viewMode;

    return merged;
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}

function saveSettings(settings) {
  try {
    localStorage.setItem(STORAGE_KEYS.settings, JSON.stringify(settings));
    return true;
  } catch (err) {
    console.warn('Settings could not be saved:', err);
    return false;
  }
}

function applySettings(settings) {
  document.documentElement.setAttribute('data-theme', settings.theme);
  document.documentElement.style.setProperty('--primary', settings.primaryColor);
  document.documentElement.style.setProperty('--primary-dark', shadeColor(settings.primaryColor, -20));
  document.documentElement.style.setProperty('--primary-light', shadeColor(settings.primaryColor, 20));

  const rgb = hexToRgb(settings.primaryColor);
  if (rgb) {
    document.documentElement.style.setProperty('--primary-rgb', `${rgb.r}, ${rgb.g}, ${rgb.b}`);
  }

  document.querySelector('meta[name="theme-color"]')?.setAttribute('content', settings.primaryColor);
  document.documentElement.style.setProperty('--font', `'${settings.font}', sans-serif`);
  document.body.style.fontFamily = `'${settings.font}', sans-serif`;
  document.body.classList.toggle('icons-emoji', settings.icons === 'emoji');
  document.body.classList.toggle('view-list', settings.viewMode === 'list');
  document.body.classList.toggle('view-grid', settings.viewMode !== 'list');
}

function shadeColor(hex, percent) {
  const rgb = hexToRgb(hex);
  if (!rgb) return hex;
  const t = percent < 0 ? 0 : 255;
  const p = Math.abs(percent) / 100;
  const r = Math.round((t - rgb.r) * p + rgb.r);
  const g = Math.round((t - rgb.g) * p + rgb.g);
  const b = Math.round((t - rgb.b) * p + rgb.b);
  return `#${((1 << 24) | (r << 16) | (g << 8) | b).toString(16).slice(1)}`;
}

function hexToRgb(hex) {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result
    ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16),
      }
    : null;
}

// ===================== الإحصائيات =====================
function loadStats() {
  const empty = { docs: {}, subjects: {}, streams: {}, totalOpens: 0 };
  try {
    const stored = JSON.parse(
      localStorage.getItem(STORAGE_KEYS.stats) ||
        '{"docs":{},"subjects":{},"streams":{},"totalOpens":0}'
    );
    const stats = stored && typeof stored === 'object' ? stored : {};
    return {
      docs: stats.docs && typeof stats.docs === 'object' ? stats.docs : {},
      subjects: stats.subjects && typeof stats.subjects === 'object' ? stats.subjects : {},
      streams: stats.streams && typeof stats.streams === 'object' ? stats.streams : {},
      totalOpens: Number.isFinite(Number(stats.totalOpens)) ? Number(stats.totalOpens) : 0,
    };
  } catch {
    return empty;
  }
}

function saveStats(stats) {
  try {
    localStorage.setItem(STORAGE_KEYS.stats, JSON.stringify(stats));
    return true;
  } catch (err) {
    console.warn('Stats could not be saved:', err);
    return false;
  }
}

function recordOpen(streamId, subjectId, docKey) {
  const stats = loadStats();
  stats.totalOpens = (stats.totalOpens || 0) + 1;
  stats.streams[streamId] = (stats.streams[streamId] || 0) + 1;
  stats.subjects[subjectId] = (stats.subjects[subjectId] || 0) + 1;
  stats.docs[docKey] = (stats.docs[docKey] || 0) + 1;
  saveStats(stats);
}

// ===================== نظام الطبقات (Overlays) =====================
/**
 * يضيف طبقة جديدة (overlay) إلى السجل ويربطها بزر الرجوع
 */
function pushLayer(type, closeFn) {
  layerStack.push({ type, closeFn });
  history.pushState(
    {
      ...history.state,
      overlay: type,
      overlayDepth: layerStack.length,
    },
    ''
  );
}

/**
 * إزالة الطبقة العلوية بدون استدعاء history.back()
 * (تُستخدم داخل handlePopState)
 */
function popLayerSilently() {
  if (layerStack.length) {
    layerStack.pop();
  }
}

/**
 * إغلاق الطبقة العلوية بشكل برمجي (يستدعي history.back)
 */
function popLayerWithHistory() {
  if (layerStack.length) {
    history.back();
  }
}

/**
 * إغلاق جميع الطبقات (للتنظيف عند الخروج)
 */
function clearAllLayers() {
  layerStack = [];
}

// ===================== الأحداث =====================
function setupEventListeners() {
  menuBtn.addEventListener('click', openSidebar);
  sidebarClose.addEventListener('click', closeSidebar);
  sidebarOverlay.addEventListener('click', closeSidebar);

  document.querySelectorAll('.sidebar-item').forEach((item) => {
    item.addEventListener('click', () => {
      const action = item.dataset.action;
      closeSidebar();
      handleSidebarAction(action);
    });
  });

  customBtn.addEventListener('click', () => {
    if (currentView === 'player') {
      openDownloadSheet();
    } else {
      openSearchModal();
    }
  });

  closePlayerBtn.addEventListener('click', () => closePlayer());

  // زر مشاركة المشغل
  sharePlayerBtn?.addEventListener('click', shareCurrentPdf);

  prevPageBtn.addEventListener('click', () => goToPage(currentPage - 1));
  nextPageBtn.addEventListener('click', () => goToPage(currentPage + 1));
  zoomInBtn.addEventListener('click', () => changeZoom(0.15));
  zoomOutBtn.addEventListener('click', () => changeZoom(-0.15));

  pdfContainer.addEventListener('dblclick', handleDoubleTapZoom, { passive: false });

  let lastTouchTap = 0;
  let lastTouchPoint = null;

  pdfContainer.addEventListener(
    'touchend',
    (e) => {
      if (e.changedTouches.length !== 1) return;
      const touch = e.changedTouches[0];
      const now = Date.now();
      const point = { x: touch.clientX, y: touch.clientY };

      if (now - lastTouchTap <= DOUBLE_TAP_DELAY && lastTouchPoint) {
        const distance = Math.hypot(point.x - lastTouchPoint.x, point.y - lastTouchPoint.y);
        if (distance < 36) {
          e.preventDefault();
          suppressBrowserDoubleClickUntil = Date.now() + 500;
          handlePointZoom(point.x, point.y);
          lastTouchTap = 0;
          lastTouchPoint = null;
          return;
        }
      }
      lastTouchTap = now;
      lastTouchPoint = point;
    },
    { passive: false }
  );

  retryDataBtn?.addEventListener('click', async () => {
    showLoading(true);
    const loaded = await loadData();
    showLoading(false);
    if (loaded) {
      renderHome();
      showToast('تم تحميل البيانات بنجاح', 'success');
    }
  });

  $('searchModalClose').addEventListener('click', closeSearchModal);
  searchModal.addEventListener('click', (e) => {
    if (e.target === searchModal) closeSearchModal();
  });
  $('doSearchBtn').addEventListener('click', performSearch);
  $('searchStream').addEventListener('change', onSearchStreamChange);

  sheetClose.addEventListener('click', closeSheet);
  sheetBackdrop.addEventListener('click', closeSheet);

  // أحداث بطاقة التنزيل
  downloadClose?.addEventListener('click', closeDownloadSheet);
  downloadBackdrop?.addEventListener('click', closeDownloadSheet);
  downloadStartBtn?.addEventListener('click', startDownloadFromSheet);
  downloadCancelBtn?.addEventListener('click', cancelDownload);
  downloadShareBtn?.addEventListener('click', shareCurrentPdf);

  window.addEventListener(
    'resize',
    debounce(async () => {
      if (currentPdf && currentView === 'player') {
        await calculateBaseScale();
        await reRenderPages();
      }
    }, 300)
  );

  window.addEventListener('popstate', handlePopState);

  history.replaceState(
    {
      view: 'home',
      stack: JSON.stringify(navStack),
      overlay: null,
      overlayDepth: 0,
    },
    ''
  );
}

function handleSidebarAction(action) {
  switch (action) {
    case 'home':
      navStack = [{ type: 'streams' }];
      renderHome();
      switchView('home');
      break;
    case 'about':
      openSheet('من نحن', getAboutContent());
      break;
    case 'privacy':
      openSheet('سياسة الخصوصية', getPrivacyContent());
      break;
    case 'contact':
      openSheet('اتصل بنا', getContactContent());
      break;
    case 'values':
      openSheet('قيمنا', getValuesContent());
      break;
    case 'settings':
      openSheet('الإعدادات', getSettingsContent());
      bindSettingsEvents();
      break;
  }
}

// ===================== التنقل الهرمي =====================
function pushNav(state) {
  navStack.push(state);
  history.pushState(
    {
      view: 'home',
      stack: JSON.stringify(navStack),
      overlay: null,
      overlayDepth: 0,
    },
    '',
    window.location.href
  );
  renderHome();
}

function popNav() {
  if (navStack.length <= 1) return false;
  history.back();
  return true;
}

/**
 * معالج زر الرجوع الموحّد
 * الأولوية للطبقات (Overlays) ثم التنقل العادي
 */
function handlePopState(e) {
  const state = e.state || {};

  // ===== 1. إغلاق أي طبقة مفتوحة =====
  // نتحقق من الطبقة العلوية في السجل
  if (layerStack.length) {
    const topLayer = layerStack[layerStack.length - 1];

    // استدعاء دالة الإغلاق الخاصة بالطبقة (بدون history.back)
    try {
      if (typeof topLayer.closeFn === 'function') {
        topLayer.closeFn();
      }
    } catch (err) {
      console.warn('Layer close failed:', err);
    }

    popLayerSilently();
  }

  // ===== 2. إذا كان المشغل مفتوحاً، أغلقه =====
  if (currentView === 'player') {
    // نتحقق إذا كنا لا نزال في المشغل (لم يكن هناك طبقة)
    // لكن لا نغلق المشغل إذا كانت الطبقة هي ما أُغلق للتو
    if (!layerStack.length && state.view !== 'player') {
      closePlayerSilently();
    }
  }

  // ===== 3. استعادة التنقل =====
  if (state.stack) {
    try {
      const restored = JSON.parse(state.stack);
      if (Array.isArray(restored) && restored.length) {
        navStack = restored;
      }
    } catch (err) {
      console.warn('Invalid navigation history state:', err);
      navStack = [{ type: 'streams' }];
    }
  } else if (state.view === 'home') {
    navStack = [{ type: 'streams' }];
  }

  renderHome();
}

function renderHome() {
  if (!data) return;

  const state = navStack[navStack.length - 1];
  homeContainer.innerHTML = '';

  if (state.type === 'subjects' || state.type === 'years') {
    const subNav = document.createElement('div');
    subNav.className = 'sub-nav';
    subNav.id = 'subNav';

    let titleText = state.streamName || '';
    if (state.type === 'years' && state.subjectName) {
      titleText = `${state.streamName || ''} · ${state.subjectName}`;
    }

    subNav.innerHTML = `
      <button type="button" class="sub-nav-back" id="subNavBack" aria-label="رجوع">
        <i class="fas fa-arrow-right"></i>
      </button>
      <div class="sub-nav-title" title="${titleText}">${titleText}</div>
    `;

    homeContainer.appendChild(subNav);
    subNav.querySelector('#subNavBack')?.addEventListener('click', () => popNav());
  }

  if (state.type === 'streams') {
    const hero = document.createElement('div');
    hero.className = 'hero-card';
    hero.innerHTML = `
      <h2>التفوق في الباك 🎓</h2>
      <p>
        مواضيع البكالوريا الجزائرية من 2008 إلى 2026 —
        منظمة حسب الشعب والمواد والسنوات.
        اختر شعبتك وابدأ التحضير بثقة.
      </p>
      <div class="hero-hashtags">
        <span>#التفوق_في_الباك</span>
        <span>#باك_2027</span>
      </div>
    `;
    homeContainer.appendChild(hero);
  }

  if (state.type === 'streams') {
    renderStreams();
  } else if (state.type === 'subjects') {
    renderSubjects(state.streamId);
  } else if (state.type === 'years') {
    renderYears(state.streamId, state.subjectId);
  }
}

function renderStreams() {
  const grid = document.createElement('div');
  grid.className = 'cards-grid';

  data.streams.forEach((stream) => {
    const card = document.createElement('div');
    card.className = 'card';
    const emoji = STREAM_EMOJIS[stream.id] || '📁';

    card.innerHTML = `
      <div class="card-icon">
        <span class="emoji-icon">${emoji}</span>
        <i class="${stream.icon || 'fas fa-folder'}"></i>
      </div>
      <div class="card-title">${stream.name}</div>
      <div class="card-sub">${stream.subjects.length} مواد</div>
    `;

    card.addEventListener('click', () => {
      pushNav({
        type: 'subjects',
        streamId: stream.id,
        streamName: stream.name,
      });
    });

    grid.appendChild(card);
  });

  homeContainer.appendChild(grid);
}

function renderSubjects(streamId) {
  const stream = data.streams.find((s) => s.id === streamId);
  if (!stream) return;

  const grid = document.createElement('div');
  grid.className = 'cards-grid';

  stream.subjects.forEach((subject) => {
    const card = document.createElement('div');
    card.className = 'card';
    const emoji = SUBJECT_EMOJIS[subject.id] || '📘';

    card.innerHTML = `
      <div class="card-icon">
        <span class="emoji-icon">${emoji}</span>
        <i class="fas fa-book"></i>
      </div>
      <div class="card-title">${subject.name}</div>
      <div class="card-sub">${subject.documents.length} موضوع</div>
    `;

    card.addEventListener('click', () => {
      pushNav({
        type: 'years',
        streamId: stream.id,
        streamName: stream.name,
        subjectId: subject.id,
        subjectName: subject.name,
      });
    });

    grid.appendChild(card);
  });

  homeContainer.appendChild(grid);
}

function renderYears(streamId, subjectId) {
  const stream = data.streams.find((s) => s.id === streamId);
  const subject = stream?.subjects.find((s) => s.id === subjectId);
  if (!subject) return;

  const list = document.createElement('div');
  list.className = 'years-list';

  const docs = [...subject.documents].sort((a, b) => {
    const yearDiff = Number(b.year) - Number(a.year);
    if (yearDiff !== 0) return yearDiff;
    const aExceptional = isExceptionalSession(a.session) ? 1 : 0;
    const bExceptional = isExceptionalSession(b.session) ? 1 : 0;
    return aExceptional - bExceptional;
  });

  docs.forEach((doc) => {
    const card = document.createElement('div');
    card.className = 'year-card';

    card.innerHTML = `
      <div class="year-badge">
        ${doc.year}
        <small>${isExceptionalSession(doc.session) ? 'استثنائية' : 'عادية'}</small>
      </div>
      <div class="year-info">
        <h4>${doc.title}</h4>
        <span>${doc.session}</span>
      </div>
      <i class="fas fa-chevron-left year-arrow"></i>
    `;

    card.addEventListener('click', () => openDocument(stream, subject, doc));
    list.appendChild(card);
  });

  homeContainer.appendChild(list);
}

function isExceptionalSession(session) {
  const value = String(session || '').trim().toLowerCase();
  return (
    value === 'exceptional' ||
    value === 'استثنائية' ||
    value === 'استثنائي' ||
    value.includes('استثن')
  );
}

// ===================== فتح الملف =====================
async function openDocument(stream, subject, doc) {
  if (!doc.url) {
    showToast('رابط الملف غير متوفر', 'error');
    return;
  }

  const docKey = `${stream.id}_${subject.id}_${doc.year}_${doc.session}`;

  currentDoc = { stream, subject, doc };
  currentFileName = doc.title;
  currentFileUrl = doc.url;

  const thisLoad = ++loadGeneration;

  resetRenderEngine();
  currentPdf = null;
  totalPages = 0;
  currentPage = 1;
  currentScale = 1.0;

  switchView('player');
  history.pushState(
    {
      view: 'player',
      stack: JSON.stringify(navStack),
      overlay: null,
      overlayDepth: 0,
    },
    '',
    window.location.href
  );

  pdfContainer.innerHTML = `
    <div class="pdf-loading-state" id="pdfLoadingState">
      <div class="spinner"></div>
      <p>جاري معاينة الملف...</p>
      <p class="pdf-loading-hint">يمكنك الإغلاق في أي وقت</p>
    </div>
  `;

  pageInfo.textContent = '— / —';
  prevPageBtn.disabled = true;
  nextPageBtn.disabled = true;
  zoomInfo.textContent = '100%';

  try {
    const loadingTask = pdfjsLib.getDocument(
      createPdfLoadingOptions({ url: doc.url, withCredentials: false })
    );

    const pdf = await loadingTask.promise;

    if (thisLoad !== loadGeneration || currentView !== 'player') {
      try {
        if (pdf && typeof pdf.destroy === 'function') await pdf.destroy();
      } catch (_) {}
      return;
    }

    if (!pdf || !Number.isInteger(pdf.numPages) || pdf.numPages < 1) {
      throw new Error('Invalid PDF document');
    }

    currentPdf = pdf;
    totalPages = pdf.numPages;
    currentPage = 1;
    currentScale = 1.0;

    await calculateBaseScale();

    if (thisLoad !== loadGeneration || currentView !== 'player') {
      await destroyCurrentPdf();
      return;
    }

    await initializeSmartViewer();

    if (thisLoad !== loadGeneration || currentView !== 'player') {
      return;
    }

    recordOpen(stream.id, subject.id, docKey);
    updateControls();
    showToast('تم فتح الملف', 'success');
  } catch (err) {
    if (thisLoad !== loadGeneration || currentView !== 'player') return;

    console.error('PDF open failed:', err);
    resetRenderEngine();
    await destroyCurrentPdf();

    pdfContainer.innerHTML = `
      <div class="pdf-loading-state pdf-error-state">
        <div class="app-error-icon" style="margin:0 auto 12px">
          <i class="fas fa-triangle-exclamation"></i>
        </div>
        <p>تعذر تحميل الملف</p>
        <p class="pdf-loading-hint">تحقق من الاتصال ثم أعد المحاولة</p>
      </div>
    `;

    showToast('فشل تحميل الملف. تحقق من الرابط والاتصال', 'error');
  }
}

async function destroyCurrentPdf() {
  const pdf = currentPdf;
  currentPdf = null;
  if (pdf && typeof pdf.destroy === 'function') {
    try {
      await pdf.destroy();
    } catch (err) {
      console.warn('PDF destroy failed:', err);
    }
  }
}

/**
 * إغلاق المشغل بشكل صامت (بدون history.back)
 * يُستخدم داخل handlePopState
 */
async function closePlayerSilently() {
  loadGeneration++;
  resetRenderEngine();
  await destroyCurrentPdf();
  currentDoc = null;
  currentFileUrl = null;
  currentFileName = '';
  switchView('home');
}

/**
 * إغلاق المشغل مع الرجوع في history
 */
async function closePlayer() {
  if (history.state?.view === 'player') {
    history.back();
    return;
  }
  await closePlayerSilently();
}

// ===================== التنقل بين الواجهات =====================
function switchView(view) {
  currentView = view;
  homeView.classList.toggle('active', view === 'home');
  playerView.classList.toggle('active', view === 'player');
  document.body.classList.toggle('player-open', view === 'player');

  if (view === 'home') {
    headerTitle.textContent = 'التفوق في الباك';
    customBtnIcon.className = 'fas fa-search';
    customBtn.setAttribute('aria-label', 'بحث');
  } else {
    headerTitle.textContent = currentFileName || 'ملف PDF';
    customBtnIcon.className = 'fas fa-download';
    customBtn.setAttribute('aria-label', 'تنزيل');
  }
}

// ===================== القائمة الجانبية =====================
function openSidebar() {
  sidebar.classList.add('open');
  sidebarOverlay.classList.add('show');

  // ربط بزر الرجوع
  pushLayer('sidebar', () => {
    sidebar.classList.remove('open');
    sidebarOverlay.classList.remove('show');
  });
}

function closeSidebar() {
  // إذا كانت القائمة مفتوحة كطبقة، ارجع في السجل
  if (layerStack.length && layerStack[layerStack.length - 1].type === 'sidebar') {
    popLayerWithHistory();
    return;
  }

  sidebar.classList.remove('open');
  sidebarOverlay.classList.remove('show');
}

// ===================== البحث =====================
function openSearchModal() {
  if (!data) return;

  const streamSelect = $('searchStream');
  const yearSelect = $('searchYear');

  streamSelect.innerHTML = '<option value="">كل الشعب</option>';
  data.streams.forEach((s) => {
    streamSelect.innerHTML += `<option value="${s.id}">${s.name}</option>`;
  });

  yearSelect.innerHTML = '<option value="">كل السنوات</option>';
  for (let y = 2026; y >= 2008; y--) {
    yearSelect.innerHTML += `<option value="${y}">${y}</option>`;
  }

  $('searchSubject').innerHTML = '<option value="">كل المواد</option>';
  $('searchSubject').disabled = true;
  $('searchResults').innerHTML = '';

  searchModal.classList.add('show');

  // ربط بزر الرجوع
  pushLayer('search', () => {
    searchModal.classList.remove('show');
  });
}

function closeSearchModal() {
  if (layerStack.length && layerStack[layerStack.length - 1].type === 'search') {
    popLayerWithHistory();
    return;
  }
  searchModal.classList.remove('show');
}

function onSearchStreamChange() {
  const streamId = $('searchStream').value;
  const subjectSelect = $('searchSubject');
  subjectSelect.innerHTML = '<option value="">كل المواد</option>';

  if (!streamId) {
    subjectSelect.disabled = true;
    return;
  }

  const stream = data.streams.find((s) => s.id === streamId);
  if (stream) {
    stream.subjects.forEach((sub) => {
      subjectSelect.innerHTML += `<option value="${sub.id}">${sub.name}</option>`;
    });
    subjectSelect.disabled = false;
  }
}

function performSearch() {
  const streamId = $('searchStream').value;
  const subjectId = $('searchSubject').value;
  const year = $('searchYear').value;

  const results = [];

  data.streams.forEach((stream) => {
    if (streamId && stream.id !== streamId) return;

    stream.subjects.forEach((subject) => {
      if (subjectId && subject.id !== subjectId) return;

      subject.documents.forEach((doc) => {
        if (year && String(doc.year) !== year) return;
        results.push({ stream, subject, doc });
      });
    });
  });

  const container = $('searchResults');
  container.innerHTML = '';

  if (results.length === 0) {
    container.innerHTML = '<li class="empty-msg">لا توجد نتائج</li>';
    return;
  }

  results
    .sort((a, b) => b.doc.year - a.doc.year)
    .slice(0, 50)
    .forEach(({ stream, subject, doc }) => {
      const li = document.createElement('li');
      li.className = 'search-result-item';
      li.innerHTML = `
        <h4>${doc.title}</h4>
        <span>${stream.name} • ${subject.name} • ${doc.session}</span>
      `;

      li.addEventListener('click', () => {
        closeSearchModal();
        // انتظر إغلاق النافذة ثم افتح الملف
        setTimeout(() => openDocument(stream, subject, doc), 250);
      });

      container.appendChild(li);
    });
}

// ===================== البطاقات المنبثقة =====================
function openSheet(title, htmlContent) {
  sheetTitle.textContent = title;
  sheetBody.innerHTML = htmlContent;
  bottomSheet.classList.add('show');

  pushLayer('sheet', () => {
    bottomSheet.classList.remove('show');
  });
}

function closeSheet() {
  if (layerStack.length && layerStack[layerStack.length - 1].type === 'sheet') {
    popLayerWithHistory();
    return;
  }
  bottomSheet.classList.remove('show');
}

function getAboutContent() {
  return `
    <div class="info-content">
      <p><strong>التفوق في الباك</strong> منصة تعليمية مجانية تهدف إلى مساعدة طلاب البكالوريا في الجزائر على التحضير الأمثل للامتحان.</p>
      <h4>ماذا نوفر؟</h4>
      <p>مواضيع البكالوريا الرسمية من دورة 2008 إلى 2026 لجميع الشعب والمواد، مع عرض عالي الجودة وتنظيم سهل.</p>
      <h4>رؤيتنا</h4>
      <p>أن نكون المرجع الأول لكل طالب يسعى للتفوق في امتحان البكالوريا.</p>
    </div>
  `;
}

function getPrivacyContent() {
  return `
    <div class="info-content">
      <p>نحترم خصوصيتك. الموقع يعمل بالكامل من جهازك ولا يجمع أي بيانات شخصية.</p>
      <h4>البيانات المحلية</h4>
      <p>نحفظ فقط تفضيلاتك (الثيم، اللون، الخط) والإحصائيات على جهازك عبر localStorage. لا يتم إرسالها لأي خادم.</p>
      <h4>الملفات</h4>
      <p>ملفات PDF مستضافة على شبكة توصيل محتوى آمنة ولا تتطلب تسجيل دخول.</p>
    </div>
  `;
}

function getContactContent() {
  return `
    <div class="info-content">
      <p>للاثتراحات أو الإبلاغ عن روابط معطلة أو أي ملاحظات:</p>
      <h4>البريد الإلكتروني</h4>
      <p style="direction:ltr;text-align:left;">support@tafaouq-bac.dz</p>
      <h4>ملاحظة</h4>
      <p>هذا مشروع تعليمي غير رسمي. المواضيع مستمدة من المصادر الرسمية لوزارة التربية الوطنية.</p>
    </div>
  `;
}

function getValuesContent() {
  return `
    <div class="info-content">
      <h4>🎯 التميز</h4>
      <p>نسعى لتقديم أفضل تجربة تحضير للطلاب.</p>
      <h4>🤝 الإتاحة</h4>
      <p>كل المحتوى مجاني ومتاح للجميع دون قيود.</p>
      <h4>🔒 الخصوصية</h4>
      <p>لا نتتبعك ولا نبيع بياناتك.</p>
      <h4>⚡ الجودة</h4>
      <p>عرض عالي الدقة وأداء سريع حتى على الهواتف المتوسطة.</p>
    </div>
  `;
}

function getSettingsContent() {
  const s = loadSettings();
  const stats = loadStats();

  const topStreams =
    Object.entries(stats.streams || {})
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([id, count]) => {
        const name = data?.streams.find((st) => st.id === id)?.name || id;
        return `<div class="stat-item"><span>${name}</span><strong>${count}</strong></div>`;
      })
      .join('') || '<div class="stat-item">لا توجد بيانات بعد</div>';

  const topDocs =
    Object.entries(stats.docs || {})
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([key, count]) => {
        return `<div class="stat-item"><span style="font-size:0.78rem">${key.replace(/_/g, ' • ')}</span><strong>${count}</strong></div>`;
      })
      .join('') || '<div class="stat-item">لا توجد بيانات بعد</div>';

  return `
    <div class="settings-section">
      <h4>المظهر</h4>
      <div class="setting-row">
        <span class="setting-label">الثيم</span>
        <div class="setting-options">
          <button class="option-btn ${s.theme === 'light' ? 'active' : ''}" data-setting="theme" data-value="light">فاتح</button>
          <button class="option-btn ${s.theme === 'dark' ? 'active' : ''}" data-setting="theme" data-value="dark">داكن</button>
        </div>
      </div>
      <div class="setting-row">
        <span class="setting-label">اللون الرئيسي</span>
        <div class="setting-options">
          ${PRIMARY_COLORS.map(
            (c) =>
              `<button class="color-swatch ${s.primaryColor === c.value ? 'active' : ''}" data-setting="primaryColor" data-value="${c.value}" style="background:${c.value}" title="${c.name}"></button>`
          ).join('')}
        </div>
      </div>
    </div>

    <div class="settings-section">
      <h4>العرض والخط</h4>
      <div class="setting-row">
        <span class="setting-label">نوع العرض</span>
        <div class="setting-options">
          <button class="option-btn ${s.viewMode === 'grid' ? 'active' : ''}" data-setting="viewMode" data-value="grid">جريد</button>
          <button class="option-btn ${s.viewMode === 'list' ? 'active' : ''}" data-setting="viewMode" data-value="list">قائمة</button>
        </div>
      </div>
      <div class="setting-row">
        <span class="setting-label">نوع الخط</span>
        <div class="setting-options">
          ${FONTS.map(
            (f) =>
              `<button class="option-btn ${s.font === f.value ? 'active' : ''}" data-setting="font" data-value="${f.value}" style="font-family:'${f.value}'">${f.name}</button>`
          ).join('')}
        </div>
      </div>
      <div class="setting-row">
        <span class="setting-label">الرموز</span>
        <div class="setting-options">
          <button class="option-btn ${s.icons === 'emoji' ? 'active' : ''}" data-setting="icons" data-value="emoji">إيموجي</button>
          <button class="option-btn ${s.icons === 'fontawesome' ? 'active' : ''}" data-setting="icons" data-value="fontawesome">مكتبية</button>
        </div>
      </div>
    </div>

    <div class="settings-section">
      <h4>الإحصائيات</h4>
      <div class="stats-box">
        <h5>إجمالي الفتحات: ${stats.totalOpens || 0}</h5>
        <h5 style="margin-top:8px">أكثر الشعب استخداماً</h5>
        ${topStreams}
        <h5 style="margin-top:8px">أكثر الملفات فتحاً</h5>
        ${topDocs}
      </div>
      <button class="btn-danger" id="clearStatsBtn">محو الإحصائيات</button>
    </div>

    <div class="settings-section">
      <h4>عام</h4>
      <button class="btn-secondary" id="resetSettingsBtn">إعادة التعيين الافتراضي</button>
      <div style="margin-top:14px;font-size:0.8rem;color:var(--text-muted);text-align:center;line-height:1.7">
        <div>النوع: ويب</div>
        <div>رقم الإصدار: ${s.version}</div>
        <div>تاريخ الإصدار: ${s.releaseDate}</div>
      </div>
    </div>
  `;
}

function bindSettingsEvents() {
  sheetBody.querySelectorAll('[data-setting]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const key = btn.dataset.setting;
      const value = btn.dataset.value;

      const settings = loadSettings();
      settings[key] = value;
      saveSettings(settings);
      applySettings(settings);

      if (key === 'primaryColor') {
        sheetBody.querySelectorAll('.color-swatch').forEach((el) => el.classList.remove('active'));
        btn.classList.add('active');
      } else {
        const group = btn.parentElement;
        group.querySelectorAll('.option-btn').forEach((el) => el.classList.remove('active'));
        btn.classList.add('active');
      }

      if (key === 'viewMode') renderHome();

      showToast('تم حفظ الإعداد', 'success');
    });
  });

  $('clearStatsBtn')?.addEventListener('click', () => {
    localStorage.removeItem(STORAGE_KEYS.stats);
    showToast('تم محو الإحصائيات', 'success');
    openSheet('الإعدادات', getSettingsContent());
    bindSettingsEvents();
  });

  $('resetSettingsBtn')?.addEventListener('click', () => {
    saveSettings({ ...DEFAULT_SETTINGS });
    applySettings(DEFAULT_SETTINGS);
    showToast('تم إعادة التعيين', 'success');
    openSheet('الإعدادات', getSettingsContent());
    bindSettingsEvents();
    renderHome();
  });
}

function updateVersionBadge() {
  const s = loadSettings();
  const el = $('versionText');
  if (el) el.textContent = `v${s.version}`;
}

// ===================== مشغل PDF =====================
function createPdfLoadingOptions(source) {
  return {
    ...source,
    cMapUrl: 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.4.168/cmaps/',
    cMapPacked: true,
    standardFontDataUrl: 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.4.168/standard_fonts/',
    useSystemFonts: true,
    enableXfa: true,
    isOffscreenCanvasSupported: true,
    isImageDecoderSupported: true,
    verbosity: 0,
  };
}

function resetRenderEngine() {
  renderGeneration++;
  renderQueue.length = 0;
  renderQueueRunning = false;

  if (pageObserver) {
    pageObserver.disconnect();
    if (pageObserver._pageTracker) pageObserver._pageTracker.disconnect();
    pageObserver = null;
  }

  for (const state of pageStates.values()) {
    if (state.renderTask) {
      try { state.renderTask.cancel(); } catch (_) {}
    }
    if (state.page) {
      try { state.page.cleanup(); } catch (_) {}
    }
  }

  pageStates.clear();
  pdfContainer.innerHTML = '';
}

async function calculateBaseScale() {
  if (!currentPdf) return;

  const page = await currentPdf.getPage(1);
  const viewport = page.getViewport({ scale: 1 });
  const containerWidth = Math.max(1, pdfContainer.clientWidth || window.innerWidth);
  const availableWidth = Math.max(1, containerWidth - 4);
  baseScale = Math.max(availableWidth / viewport.width, 0.5);
}

function getCssViewport(page) {
  return page.getViewport({ scale: baseScale * currentScale });
}

function getOutputScale(viewport = null) {
  const deviceScale = Math.min(Math.max(window.devicePixelRatio || 1, 1), 3);
  if (!viewport) return deviceScale;

  const maxPixels = 12000000;
  const pixelsAtDeviceScale = viewport.width * viewport.height * deviceScale * deviceScale;
  if (pixelsAtDeviceScale <= maxPixels) return deviceScale;
  return Math.max(1, Math.sqrt(maxPixels / (viewport.width * viewport.height)));
}

function createPageShell(pageNum, estimatedHeight) {
  const pageDiv = document.createElement('div');
  pageDiv.className = 'pdf-page';
  pageDiv.dataset.page = pageNum;
  pageDiv.style.width = '100%';
  pageDiv.style.scrollSnapAlign = 'start';
  pageDiv.style.scrollSnapStop = 'always';
  pageDiv.style.height = `${Math.max(100, estimatedHeight)}px`;
  pageDiv.style.minHeight = `${Math.max(100, estimatedHeight)}px`;
  pageDiv.setAttribute('aria-label', `صفحة ${pageNum}`);

  const state = {
    pageNum,
    div: pageDiv,
    page: null,
    canvas: null,
    renderTask: null,
    renderedKey: '',
    queued: false,
    failed: false,
    generation: renderGeneration,
  };

  pageStates.set(pageNum, state);
  pdfContainer.appendChild(pageDiv);
  return state;
}

async function initializeSmartViewer() {
  if (!currentPdf) return;
  resetRenderEngine();

  const generation = renderGeneration;
  const firstPage = await currentPdf.getPage(1);

  if (generation !== renderGeneration || !currentPdf) return;

  const firstViewport = getCssViewport(firstPage);
  const estimatedHeight = firstViewport.height;

  for (let i = 1; i <= totalPages; i++) {
    createPageShell(i, estimatedHeight);
  }

  pageStates.get(1).page = firstPage;
  await renderPage(1, true);
  updateControls();
  setupPageObserver();
  queueNearbyPages(1);
  preparePageDimensions(generation, 1);
}

async function preparePageDimensions(generation, centerPage = 1) {
  if (!currentPdf) return;

  const firstState = pageStates.get(1);
  const firstHeight = firstState?.div?.offsetHeight || 300;

  const from = Math.max(1, centerPage - PREVIOUS_CACHE);
  const to = Math.min(totalPages, centerPage + NEXT_PRELOAD);

  const jobs = [];

  for (let i = from; i <= to; i++) {
    jobs.push(
      (async () => {
        try {
          if (generation !== renderGeneration || !pageStates.has(i)) return;
          const state = pageStates.get(i);
          const page = state.page || (await currentPdf.getPage(i));
          if (generation !== renderGeneration || !pageStates.has(i)) return;

          state.page = page;
          const viewport = getCssViewport(page);
          const height = Math.max(100, viewport.height || firstHeight);

          state.div.style.height = `${height}px`;
          state.div.style.minHeight = `${height}px`;
        } catch (error) {
          console.warn(`تعذر تجهيز أبعاد الصفحة ${i}`, error);
        }
      })()
    );
  }

  await Promise.all(jobs);
}

function setupPageObserver() {
  if (pageObserver) pageObserver.disconnect();

  pageObserver = new IntersectionObserver(
    (entries) => {
      for (const entry of entries) {
        if (!entry.isIntersecting) continue;
        const pageNum = Number(entry.target.dataset.page);
        if (!Number.isInteger(pageNum)) continue;
        queueNearbyPages(pageNum);
      }
    },
    {
      root: pdfContainer,
      rootMargin: OBSERVER_MARGIN,
      threshold: 0.01,
    }
  );

  for (const state of pageStates.values()) {
    pageObserver.observe(state.div);
  }

  const pageTracker = new IntersectionObserver(
    (entries) => {
      let best = null;
      for (const entry of entries) {
        if (!entry.isIntersecting) continue;
        const topDistance = Math.abs(entry.boundingClientRect.top - 70);
        if (!best || topDistance < best.distance) {
          best = {
            page: Number(entry.target.dataset.page),
            distance: topDistance,
          };
        }
      }

      if (best && best.page >= 1 && best.page <= totalPages) {
        if (best.page !== currentPage) {
          currentPage = best.page;
          updateControls();
          queueNearbyPages(currentPage);
        }
      }
    },
    {
      root: pdfContainer,
      rootMargin: '-10% 0px -75% 0px',
      threshold: [0, 0.01],
    }
  );

  for (const state of pageStates.values()) {
    pageTracker.observe(state.div);
  }

  pageObserver._pageTracker = pageTracker;
}

function queueNearbyPages(centerPage) {
  const from = Math.max(1, centerPage - PREVIOUS_CACHE);
  const to = Math.min(totalPages, centerPage + NEXT_PRELOAD);

  for (let pageNum = from; pageNum <= to; pageNum++) {
    const state = pageStates.get(pageNum);
    if (!state || state.renderedKey === renderKey()) continue;

    if (!state.queued) {
      state.queued = true;
      const distance = Math.abs(pageNum - centerPage);
      const priority = pageNum < centerPage ? 0.2 : 0;
      renderQueue.push({ pageNum, distance: distance + priority });
    }
  }

  renderQueue.sort((a, b) => a.distance - b.distance);
  processRenderQueue();
  trimRenderedCache(centerPage);
}

function trimRenderedCache(centerPage) {
  const minKeep = Math.max(1, centerPage - PREVIOUS_CACHE);
  const maxKeep = Math.min(totalPages, centerPage + NEXT_PRELOAD);

  for (const [pageNum, state] of pageStates) {
    if (pageNum >= minKeep && pageNum <= maxKeep) continue;

    if (state.renderTask) {
      try { state.renderTask.cancel(); } catch (_) {}
      state.renderTask = null;
    }

    if (state.canvas) {
      state.canvas.width = 1;
      state.canvas.height = 1;
      state.canvas.remove();
      state.canvas = null;
    }

    state.renderedKey = '';
  }
}

function renderKey() {
  return `${baseScale.toFixed(5)}|${currentScale.toFixed(2)}|${Math.min(
    Math.max(window.devicePixelRatio || 1, 1),
    3
  )}`;
}

async function processRenderQueue() {
  if (renderQueueRunning) return;
  renderQueueRunning = true;

  while (renderQueue.length) {
    renderQueue.sort((a, b) => a.distance - b.distance);
    const job = renderQueue.shift();
    const state = pageStates.get(job.pageNum);

    if (!state) continue;
    state.queued = false;

    try {
      await renderPage(job.pageNum, false);
    } catch (error) {
      console.warn(`Render page ${job.pageNum} failed`, error);
    }

    await new Promise((resolve) => requestAnimationFrame(resolve));
  }

  renderQueueRunning = false;
}

async function renderPage(pageNum, force = false) {
  const state = pageStates.get(pageNum);
  if (!state || !currentPdf) return;

  const key = renderKey();
  if (!force && state.renderedKey === key && state.canvas) return;

  if (state.renderTask) {
    try { state.renderTask.cancel(); } catch (_) {}
    state.renderTask = null;
  }

  const page = state.page || (await currentPdf.getPage(pageNum));
  state.page = page;

  const cssViewport = getCssViewport(page);
  const outputScale = getOutputScale(cssViewport);

  const renderViewport = page.getViewport({
    scale: baseScale * currentScale * outputScale,
  });

  const isZoomed = currentScale > 1;

  state.div.style.width = isZoomed ? `${cssViewport.width}px` : '100%';
  state.div.style.maxWidth = isZoomed ? 'none' : '100%';
  state.div.style.height = `${cssViewport.height}px`;
  state.div.style.minHeight = `${cssViewport.height}px`;

  const canvas = document.createElement('canvas');
  canvas.className = 'pdf-canvas';

  const context = canvas.getContext('2d', { alpha: false, willReadFrequently: false });
  if (!context) throw new Error('Canvas 2D context unavailable');

  canvas.width = Math.max(1, Math.floor(renderViewport.width));
  canvas.height = Math.max(1, Math.floor(renderViewport.height));
  canvas.style.width = `${Math.floor(cssViewport.width)}px`;
  canvas.style.height = `${Math.floor(cssViewport.height)}px`;

  context.imageSmoothingEnabled = true;
  context.imageSmoothingQuality = 'high';

  const transform = outputScale !== 1 ? [outputScale, 0, 0, outputScale, 0, 0] : null;

  const task = page.render({
    canvasContext: context,
    viewport: cssViewport,
    transform,
    intent: 'display',
    background: 'white',
  });

  state.renderTask = task;

  try {
    await task.promise;

    if (state.renderTask !== task) return;
    state.renderTask = null;

    const oldCanvas = state.canvas;
    state.canvas = canvas;
    state.renderedKey = key;
    state.failed = false;
    state.div.replaceChildren(canvas);

    if (oldCanvas) {
      oldCanvas.width = oldCanvas.height = 1;
    }
  } catch (error) {
    if (state.renderTask === task) state.renderTask = null;
    if (error?.name !== 'RenderingCancelledException') {
      state.failed = true;
      throw error;
    }
  }
}

async function reRenderPages() {
  if (!currentPdf) return;

  const pageToRestore = Math.max(1, Math.min(totalPages, currentPage));
  resetRenderEngine();
  await initializeSmartViewer();
  queueNearbyPages(pageToRestore);
  updateControls();

  requestAnimationFrame(() => {
    const el = pdfContainer.querySelector(`[data-page="${pageToRestore}"]`);
    if (el) el.scrollIntoView({ behavior: 'auto', block: 'start', inline: 'nearest' });
  });
}

function scrollToPage(pageNum) {
  const el = pdfContainer.querySelector(`[data-page="${pageNum}"]`);
  if (!el) return;
  el.scrollIntoView({ behavior: 'smooth', block: 'start', inline: 'nearest' });
  queueNearbyPages(pageNum);
}

function goToPage(pageNum) {
  if (pageNum < 1 || pageNum > totalPages) return;
  currentPage = pageNum;
  scrollToPage(currentPage);
  updateControls();
}

async function handlePointZoom(clientX, clientY) {
  if (!currentPdf) return;

  const hit = document.elementFromPoint(clientX, clientY);
  const pageEl = hit?.closest('.pdf-page');
  if (!pageEl || !pdfContainer.contains(pageEl)) return;

  const pageNum = Number(pageEl.dataset.page);
  if (!pageNum) return;

  const targetScale = currentScale === 1 ? MAX_ZOOM : 1;
  const oldScale = currentScale;

  const rectBefore = pageEl.getBoundingClientRect();
  const containerRect = pdfContainer.getBoundingClientRect();

  const localX = Math.max(0, clientX - rectBefore.left);
  const localY = Math.max(0, clientY - rectBefore.top);
  const ratio = targetScale / oldScale;

  currentScale = targetScale;
  updateControls();

  try {
    await renderPage(pageNum, true);
  } catch (error) {
    currentScale = oldScale;
    updateControls();
    return;
  }

  const targetScrollTop =
    pdfContainer.scrollTop +
    (rectBefore.top - containerRect.top) +
    localY * ratio -
    (clientY - containerRect.top);

  pdfContainer.scrollTop = Math.max(0, targetScrollTop);

  const xDelta = localX * (ratio - 1);
  if (Math.abs(xDelta) > 0.5) {
    try { pdfContainer.scrollLeft += xDelta; } catch (_) {}
  }

  queueNearbyPages(pageNum);
}

function handleDoubleTapZoom(e) {
  if (Date.now() < suppressBrowserDoubleClickUntil) {
    e.preventDefault();
    return;
  }
  e.preventDefault();
  handlePointZoom(e.clientX, e.clientY);
}

function changeZoom(delta) {
  const newScale = Math.max(0.5, Math.min(MAX_ZOOM, +(currentScale + delta).toFixed(2)));
  if (newScale === currentScale) return;
  currentScale = newScale;
  reRenderPages();
}

function updateControls() {
  pageInfo.textContent = `${currentPage} / ${totalPages}`;
  zoomInfo.textContent = `${Math.round(currentScale * 100)}%`;
  prevPageBtn.disabled = currentPage <= 1;
  nextPageBtn.disabled = currentPage >= totalPages;
  pdfContainer.classList.toggle('zoomed', currentScale > 1);
}

// ===================== نظام التنزيل المتقدم =====================

/**
 * فتح بطاقة التنزيل
 */
function openDownloadSheet() {
  if (!currentFileUrl) {
    showToast('لا يوجد ملف للتنزيل', 'error');
    return;
  }

  // إعادة تعيين الواجهة
  downloadFileNameEl.textContent = currentFileName || 'document.pdf';
  downloadFileMetaEl.textContent = 'PDF • جاهز للتنزيل';
  downloadProgressWrapper.hidden = true;
  downloadStats.hidden = true;
  downloadProgressFill.style.width = '0%';
  downloadProgressFill.classList.remove('complete', 'error');
  downloadProgressText.textContent = '0%';
  downloadState.className = 'download-state';
  downloadState.innerHTML = '<p>اضغط على "بدء التنزيل" لتحميل الملف</p>';
  downloadStartBtn.hidden = false;
  downloadStartBtn.disabled = false;
  downloadCancelBtn.hidden = true;
  downloadShareBtn.hidden = !navigator.share;

  downloadSheet.classList.add('show');

  pushLayer('download', () => {
    downloadSheet.classList.remove('show');
    // إذا كان التنزيل جارياً، اسأل المستخدم
    if (isDownloading) {
      cancelDownload();
    }
  });
}

function closeDownloadSheet() {
  if (layerStack.length && layerStack[layerStack.length - 1].type === 'download') {
    popLayerWithHistory();
    return;
  }
  downloadSheet.classList.remove('show');
}

/**
 * بدء التنزيل من داخل البطاقة
 */
async function startDownloadFromSheet() {
  if (isDownloading) return;

  const filename = sanitizeDownloadName(currentFileName || 'document.pdf');
  const url = currentFileUrl;

  if (!url) {
    showToast('رابط الملف غير متوفر', 'error');
    return;
  }

  isDownloading = true;
  downloadController = new AbortController();

  // تحديث الواجهة
  downloadStartBtn.hidden = true;
  downloadCancelBtn.hidden = false;
  downloadProgressWrapper.hidden = false;
  downloadStats.hidden = false;
  downloadProgressFill.classList.remove('complete', 'error');
  downloadProgressFill.style.width = '0%';
  downloadProgressText.textContent = '0%';
  downloadState.className = 'download-state';
  downloadState.innerHTML = '<p>جاري التنزيل...</p>';
  downloadSpeed.textContent = '—';
  downloadTime.textContent = '—';
  downloadSize.textContent = '—';

  // إظهار المؤشر العائم
  showDownloadIndicator(filename);

  const startTime = Date.now();

  try {
    const response = await fetch(url, {
      method: 'GET',
      mode: 'cors',
      credentials: 'omit',
      cache: 'no-store',
      signal: downloadController.signal,
      headers: { Accept: 'application/pdf,*/*' },
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    const contentLength = response.headers.get('content-length');
    const totalBytes = contentLength ? parseInt(contentLength, 10) : 0;

    // عرض حجم الملف إذا كان معروفاً
    if (totalBytes > 0) {
      downloadSize.textContent = formatBytes(totalBytes);
      downloadFileMetaEl.textContent = `PDF • ${formatBytes(totalBytes)}`;
    } else {
      downloadSize.textContent = '—';
      downloadFileMetaEl.textContent = 'PDF • جاهز للتنزيل';
    }

    // قراءة الملف كـ Stream مع تتبع التقدم
    const reader = response.body.getReader();
    const chunks = [];
    let receivedBytes = 0;
    let lastUpdate = 0;

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      chunks.push(value);
      receivedBytes += value.length;

      // تحديث الواجهة كل 100ms لتقليل الضغط
      const now = Date.now();
      if (now - lastUpdate > 100 || !totalBytes) {
        lastUpdate = now;
        updateDownloadProgress({
          receivedBytes,
          totalBytes,
          startTime,
        });
      }
    }

    // اكتمل التحميل
    updateDownloadProgress({
      receivedBytes,
      totalBytes: receivedBytes,
      startTime,
      complete: true,
    });

    // تجميع الأجزاء في Blob
    const pdfBlob = new Blob(chunks, { type: 'application/pdf' });

    // حفظ الملف
    await saveBlobToDevice(pdfBlob, filename);

    // واجهة النجاح
    downloadProgressFill.classList.add('complete');
    downloadProgressText.textContent = '100%';
    downloadState.className = 'download-state success';
    downloadState.innerHTML = `<p><i class="fas fa-check-circle"></i> تم التنزيل بنجاح</p>`;

    showToast(`تم تنزيل: ${filename}`, 'success');

    // إخفاء زر الإلغاء بعد فترة
    downloadCancelBtn.hidden = true;
    downloadStartBtn.hidden = false;
    downloadStartBtn.innerHTML = '<i class="fas fa-download"></i> تنزيل مرة أخرى';

    // إخفاء المؤشر العائم
    hideDownloadIndicator();
  } catch (error) {
    if (error?.name === 'AbortError') {
      downloadState.className = 'download-state';
      downloadState.innerHTML = '<p>تم إلغاء التنزيل</p>';
      downloadProgressFill.classList.add('error');
      downloadProgressText.textContent = 'ملغى';
      showToast('تم إلغاء التنزيل', '');
    } else {
      console.error('Download failed:', error);
      downloadState.className = 'download-state error';
      downloadState.innerHTML = `<p><i class="fas fa-exclamation-triangle"></i> فشل التنزيل</p>`;
      downloadProgressFill.classList.add('error');
      downloadProgressText.textContent = 'خطأ';
      showToast('فشل التنزيل. حاول مرة أخرى', 'error');
    }

    downloadCancelBtn.hidden = true;
    downloadStartBtn.hidden = false;
    downloadStartBtn.innerHTML = '<i class="fas fa-redo"></i> إعادة المحاولة';

    hideDownloadIndicator();
  } finally {
    isDownloading = false;
    downloadController = null;
  }
}

/**
 * إلغاء التنزيل الجاري
 */
function cancelDownload() {
  if (downloadController) {
    downloadController.abort();
    downloadController = null;
  }
  isDownloading = false;
  hideDownloadIndicator();
}

/**
 * تحديث شريط التقدم والإحصائيات
 */
function updateDownloadProgress({ receivedBytes, totalBytes, startTime, complete = false }) {
  const percent = totalBytes > 0 ? (receivedBytes / totalBytes) * 100 : 0;
  const displayPercent = complete ? 100 : Math.min(99.9, percent);

  downloadProgressFill.style.width = `${displayPercent}%`;
  downloadProgressText.textContent = `${displayPercent.toFixed(1)}%`;

  // الإحصائيات
  const elapsedSeconds = (Date.now() - startTime) / 1000;
  if (elapsedSeconds > 0.5) {
    const speed = receivedBytes / elapsedSeconds;
    downloadSpeed.textContent = `${formatBytes(speed)}/s`;

    if (totalBytes > 0 && !complete) {
      const remaining = (totalBytes - receivedBytes) / speed;
      downloadTime.textContent = remaining > 0 ? formatTime(remaining) : '—';
    } else {
      downloadTime.textContent = '—';
    }
  }

  downloadSize.textContent = totalBytes > 0
    ? `${formatBytes(receivedBytes)} / ${formatBytes(totalBytes)}`
    : formatBytes(receivedBytes);

  // تحديث المؤشر العائم
  updateDownloadIndicator(displayPercent);
}

/**
 * حفظ Blob على الجهاز (يستخدم native picker على الحاسوب + a.download على الهاتف)
 */
async function saveBlobToDevice(blob, filename) {
  const isTouchDevice =
    'ontouchstart' in window ||
    navigator.maxTouchPoints > 0 ||
    /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent || '');

  // على الحاسوب: استخدام native picker
  if (!isTouchDevice && typeof window.showSaveFilePicker === 'function') {
    try {
      const handle = await window.showSaveFilePicker({
        suggestedName: filename,
        types: [{ description: 'PDF', accept: { 'application/pdf': ['.pdf'] } }],
      });
      const writable = await handle.createWritable();
      await writable.write(blob);
      await writable.close();
      return;
    } catch (err) {
      if (err?.name === 'AbortError') {
        // المستخدم أغلق النافذة - نستخدم الطريقة البديلة
      } else {
        console.warn('showSaveFilePicker failed, falling back', err);
      }
    }
  }

  // على الهاتف أو كخطة بديلة: a.download
  const objectUrl = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = objectUrl;
  a.download = filename;
  a.rel = 'noopener noreferrer';
  a.style.display = 'none';
  a.setAttribute('download', filename);
  if (isTouchDevice) a.target = '_blank';

  document.body.appendChild(a);
  a.click();

  setTimeout(() => {
    a.remove();
    try { URL.revokeObjectURL(objectUrl); } catch (_) {}
  }, 30000);
}

/**
 * مشاركة الملف عبر Web Share API
 */
async function shareCurrentPdf() {
  if (!currentFileUrl) {
    showToast('لا يوجد ملف للمشاركة', 'error');
    return;
  }

  // مشاركة الملف نفسه (إذا كان مدعوماً)
  const shareData = {
    title: currentFileName || 'موضوع البكالوريا',
    text: `موضوع من منصة التفوق في الباك`,
    url: currentFileUrl,
  };

  try {
    await navigator.share(shareData);
    showToast('تمت المشاركة', 'success');
  } catch (err) {
    if (err?.name === 'AbortError') {
      // المستخدم أغلق نافذة المشاركة
      return;
    }
    // خطة بديلة: نسخ الرابط
    try {
      await navigator.clipboard.writeText(currentFileUrl);
      showToast('تم نسخ الرابط', 'success');
    } catch (_) {
      showToast('تعذرت المشاركة', 'error');
    }
  }
}

/**
 * المؤشر العائم أثناء التنزيل
 */
function showDownloadIndicator(filename) {
  hideDownloadIndicator();

  downloadIndicatorEl = document.createElement('div');
  downloadIndicatorEl.className = 'download-active-indicator';
  downloadIndicatorEl.innerHTML = `
    <div class="mini-spinner"></div>
    <div class="indicator-text">${filename}</div>
    <div class="indicator-percent" id="indicatorPercent">0%</div>
  `;

  document.body.appendChild(downloadIndicatorEl);
}

function updateDownloadIndicator(percent) {
  if (!downloadIndicatorEl) return;
  const el = downloadIndicatorEl.querySelector('#indicatorPercent');
  if (el) el.textContent = `${Math.floor(percent)}%`;
}

function hideDownloadIndicator() {
  if (downloadIndicatorEl) {
    downloadIndicatorEl.remove();
    downloadIndicatorEl = null;
  }
}

/**
 * أدوات مساعدة للتنزيل
 */
function formatBytes(bytes) {
  if (!Number.isFinite(bytes) || bytes <= 0) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  const value = bytes / Math.pow(1024, i);
  return `${value.toFixed(i === 0 ? 0 : value >= 10 ? 1 : 2)} ${units[i]}`;
}

function formatTime(seconds) {
  if (!Number.isFinite(seconds) || seconds <= 0) return '—';
  if (seconds < 60) return `${Math.ceil(seconds)} ث`;
  const mins = Math.floor(seconds / 60);
  const secs = Math.ceil(seconds % 60);
  return `${mins} د ${secs} ث`;
}

function sanitizeDownloadName(name) {
  let filename = String(name || 'document.pdf').trim();
  filename = filename
    .replace(/[\\/:*?"<>|]+/g, '_')
    .replace(/\s+/g, ' ')
    .trim();

  if (!filename) filename = 'document';
  if (!/\.pdf$/i.test(filename)) filename += '.pdf';
  if (filename.length > 120) filename = filename.slice(0, 116) + '.pdf';

  return filename;
}

// ===================== اختصارات لوحة المفاتيح =====================
document.addEventListener('keydown', (event) => {
  if (currentView !== 'player' || !currentPdf) return;

  const target = event.target;
  const typing =
    target instanceof HTMLInputElement ||
    target instanceof HTMLTextAreaElement ||
    target instanceof HTMLSelectElement ||
    target.isContentEditable;

  if (typing) return;

  if (event.key === 'ArrowRight') {
    event.preventDefault();
    goToPage(currentPage - 1);
  } else if (event.key === 'ArrowLeft') {
    event.preventDefault();
    goToPage(currentPage + 1);
  } else if (event.key === '+' || event.key === '=') {
    event.preventDefault();
    changeZoom(0.15);
  } else if (event.key === '-' || event.key === '_') {
    event.preventDefault();
    changeZoom(-0.15);
  } else if (event.key === 'Escape') {
    event.preventDefault();
    closePlayer();
  }
});

// ===================== أدوات مساعدة =====================
function showLoading(show) {
  loadingOverlay.classList.toggle('show', show);
}

function showToast(msg, type = '') {
  toast.textContent = msg;
  toast.className = 'toast show' + (type ? ` ${type}` : '');

  clearTimeout(toast._timer);
  toast._timer = setTimeout(() => toast.classList.remove('show'), 2800);
}

function debounce(fn, delay) {
  let timer;
  return function (...args) {
    clearTimeout(timer);
    timer = setTimeout(() => fn.apply(this, args), delay);
  };
}

