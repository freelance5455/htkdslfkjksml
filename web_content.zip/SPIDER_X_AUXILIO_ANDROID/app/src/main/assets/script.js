const config = {
    aimlock: false,
    norecoil: false,
    aimassist: false,
    regedit: false
};

function log(msg, type = 'info') {
    const console = document.getElementById('console');
    const time = new Date().toLocaleTimeString();
    const cls = type === 'success' ? 'log-success' : 'log-info';
    const linea = document.createElement('div');
    linea.className = `log-line ${cls}`;
    linea.textContent = `[${time}] ${msg}`;
    console.appendChild(linea);
    console.scrollTop = console.scrollHeight;
}

function toggleOption(name) {
    config[name] = !config[name];
    const el = document.getElementById(`opt_${name}`);
    const stat = document.getElementById(`stat_${name}`);
    
    if (config[name]) {
        el.classList.add('active');
        stat.textContent = 'ON';
        stat.style.color = '#00ff41';
        log(`${name.toUpperCase()} → ACTIVADO AUX†`, 'success');
    } else {
        el.classList.remove('active');
        stat.textContent = 'OFF';
        stat.style.color = '#555';
        log(`${name.toUpperCase()} → DESACTIVADO`);
    }
}

function aplicar() {
    log('⚙️ Guardando selección del panel...');
    
    setTimeout(() => {
        const activos = Object.entries(config).filter(([k, v]) => v);
        
        if (activos.length === 0) {
            log('⚠️ No hay módulos activos');
            return;
        }
        
        activos.forEach(([nombre]) => {
            log(`✓ ${nombre.toUpperCase()} — selección guardada en el panel`, 'success');
        });
        
        log(`✅ ${activos.length} opciones seleccionadas. Esto no modifica Free Fire.`, 'success');
    }, 600);
}

function abrirJuego(version = 'normal') {
    const nombre = version === 'max' ? 'Free Fire MAX' : 'Free Fire';
    log(`🎮 Abriendo ${nombre}...`);
    if (window.Android && Android.openGame) {
        Android.openGame(version);
    } else {
        log('Esta función está disponible dentro de la aplicación Android.');
    }
}

window.onload = () => {
    log('✅ Sistema SPIDER X inicializado AUX†');
    log('> Activa opciones y abre la versión de Free Fire instalada');
};
