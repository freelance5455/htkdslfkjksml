# V3H audit (summary)
Used only as read-only reference: square indexing 0=a8…63=h1, piece letters, card/relic/enchant ids snapshotted by `tools/snapshot-v3h.js` into `mock/mock-v3h-content.js`. No gameplay file is edited; `vendor/chess.v3h.js` is a verbatim copy for the demo.
