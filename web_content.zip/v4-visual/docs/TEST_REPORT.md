# Test report (honest)
**Method:** headless Chromium (Playwright) with emulated viewports/touch; screenshots reviewed by eye. **No physical Android device, no real touch latency, no WebView test, no performance profiling.**
Viewports run: 640×360, 800×360, 854×480, 960×540, 1280×720 (EN); 640×360 (PT-BR); portrait 360×640 (rotate screen).
Scenes: desk (stage 1–4), menu, appointment book, catalog, parcel/booster, album, deck, relic case, enchant kit, ledger, mail, intro, settings, match.
Interaction (mouse-driven Pointer Events at 640×360): drag over board, open folder tray, drag item into open folder (store), long-press action bar, inspect.
No JS errors in scripted scenes. **Not tested:** real multi-touch, drag-out-of-tray by touch, move-then-tap path, keyboard nudging, reduced-motion visuals, screen readers, 1920×1080, pt-BR on desk stages 2–4, long-run memory.
Known issues: object hit areas overlap by design (top object wins); at 800×360 system buttons can overlap a few right-side objects; tray header truncates long names; piece reference row 4 (39 px) not usable (sheet not integer-scaled); mock letters/calendar label are English-only.
