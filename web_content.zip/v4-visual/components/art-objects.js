/* Progressive desk equipment — extension art (Prompt 3). Strict 90° top-down, light from top-left, 1px K[0] outline, baked hard shadow.
   Naming: cav.o.<family>.<variant>[.<state>]   states: (none)=resting/closed, .open, .empty, .full
   Selected / dragging / inspection are NOT separate bitmaps: they are CSS state classes (lift + hard pixel shadow + outline) so every sprite
   gets them for free and the pixel grid stays intact (see styles/cav-freedesk.css).  Text-bearing sprites leave CLEAN rectangles (see C.objects.meta[*].text). */
(function(){
var C=window.CAV, P=C.pal, Px=C.Px, A=C.art, SH='#00000066';
function fin(p,s){ p.outline(P.K[0]); p.shadow(SH,s||1,s||1); return p; }
function disc(p,cx,cy,r,ramp){ p.shadeDisc(cx,cy,r,ramp,{dither:false}); }
function wood(p,x,y,w,h,ramp,seed){ var r=C.rng(seed||4); p.rect(x,y,w,h,ramp[2]);
  for(var i=0;i<w*h/7;i++){ var gx=x+r.int(0,w-2), gy=y+r.int(0,h-1); p.hline(gx,gy,r.int(2,6),r()<.5?ramp[1]:ramp[3]); }
  p.hline(x,y,w,ramp[4]); p.vline(x,y,h,ramp[4]); p.hline(x,y+h-1,w,ramp[0]); p.vline(x+w-1,y,h,ramp[0]); }
function paper(p,x,y,w,h,tone){ var t=tone||P.paper; p.rect(x,y,w,h,t[3]); p.hline(x,y,w,t[4]); p.vline(x,y,h,t[4]); p.hline(x,y+h-1,w,t[1]); p.vline(x+w-1,y,h,t[1]); }
function lines(p,x,y,w,n,gap,c){ for(var i=0;i<n;i++) p.hline(x,y+i*gap,w,c); }
function def(k,fn){ A.define('cav.o.'+k,fn); }

/* ================= STATIONERY ================= */
def('stationery.pencil',function(){ var p=new Px(26,4);
  p.rect(5,0,19,3,P.amber[3]); p.hline(5,0,19,P.amber[4]); p.hline(5,2,19,P.amber[1]); p.rect(0,0,5,3,P.parch[3]); p.poly([[0,1],[2,0],[2,3]],P.K[1]); p.rect(22,0,2,3,P.silver[2]); p.rect(24,0,2,3,P.wax[3]);
  p.rect(4,0,1,3,P.parch[1]); return fin(p,1); });
def('stationery.inkwell',function(){ var p=new Px(16,18);
  p.rect(2,8,11,9,P.iron[1]); disc(p,7.5,12.5,6,P.navy); p.ring(7.5,12.5,6,1,P.silver[1]); p.ring(7.5,12.5,2.8,1,P.K[0]); disc(p,7.5,12.5,2.4,P.ebony);
  p.line(10,10,15,1,P.parch[4]); p.line(11,10,15,2,P.parch[2]); p.line(9,10,14,1,P.parch[1]); p.set(15,0,P.brass[4]);                    /* quill */
  return fin(p,1); });
def('stationery.notepad',function(){ var p=new Px(24,30);
  p.rect(2,2,22,27,P.paper[1]); paper(p,0,0,22,28,P.paper); p.rect(0,0,22,4,P.wax[2]); p.hline(0,0,22,P.wax[4]); p.hline(0,3,22,P.wax[1]);          /* glued head */
  lines(p,3,8,16,5,4,P.steel[3]); p.vline(5,5,22,P.wax[3]);                                                                                        /* ruled lines: clean area x3..19,y6..26 */
  return fin(p,1); });
def('stationery.blotter',function(){ var p=new Px(36,26); p.rect(0,0,34,24,P.leather[1]); p.dither(0,0,34,24,P.leather[1],P.leather[2],.3);
  p.frame(0,0,34,24,P.leather[0]); [[0,0],[32,0],[0,22],[32,22]].forEach(function(q){ p.rect(q[0],q[1],2,2,P.brass[3]); }); p.hline(1,1,32,P.leather[3]); p.vline(1,1,22,P.leather[3]);
  return fin(p,1); });

/* ================= CLOCKS (family: wood -> brass -> ... ) ================= */
A.clockWood=function(h,m){ var k='cav.o.clock.wood@'+h+':'+m; if(!A.has(k)) A.define(k,function(){ var p=new Px(26,26), cx=12.5, cy=12.5;
  wood(p,0,0,24,24,P.walnut,17); p.frame(0,0,24,24,P.walnut[0]); p.ellipse(cx,cy,9.6,9.6,P.ivory[3]); p.ring(cx,cy,9.6,1,P.walnut[0]); p.ring(cx,cy,8.6,1,P.ivory[1]); p.hline(8,5,5,P.ivory[4]);
  for(var i=0;i<12;i++){ var a=i*Math.PI/6; p.set(Math.round(cx+Math.sin(a)*7),Math.round(cy-Math.cos(a)*7),i%3===0?P.K[0]:P.ivory[0]); }
  var ma=m/60*2*Math.PI, ha=((h%12)+m/60)/12*2*Math.PI, X=Math.round(cx), Y=Math.round(cy);
  p.line(X,Y,Math.round(X+Math.sin(ha)*4),Math.round(Y-Math.cos(ha)*4),P.K[0]); p.line(X,Y,Math.round(X+Math.sin(ma)*7),Math.round(Y-Math.cos(ma)*7),P.K[1]); p.set(X,Y,P.wax[3]);
  p.rect(1,1,2,2,P.brass[2]); p.rect(21,1,2,2,P.brass[2]); p.rect(1,21,2,2,P.brass[2]); p.rect(21,21,2,2,P.brass[2]);   /* worn screws */
  return fin(p,1); }); return k; };

/* ================= STORAGE ================= */
/* card case: closed 30x22; open 30x38 (lid hinged back above the box; anchor = bottom edge); .empty = open with nothing inside */
function caseBox(open,full){ var H=open?38:22, p=new Px(30,H), oy=open?16:0;
  if(open){ wood(p,1,0,28,15,P.walnut,3); p.frame(3,2,24,11,P.felt[1]); p.rect(4,3,22,9,P.felt[2]); p.hline(4,3,22,P.felt[3]); p.rect(12,4,6,5,P.brass[3]); p.hline(12,4,6,P.brass[4]); }   /* inside of the lid, felt lined */
  wood(p,0,oy,30,22,P.walnut,5); p.frame(0,oy,30,22,P.walnut[0]);
  if(!open){ p.frame(2,oy+2,26,18,P.walnut[1]); p.rect(12,oy+9,6,8,P.brass[3]); p.hline(12,oy+9,6,P.brass[4]); p.rect(14,oy+12,2,3,P.K[0]); p.rect(11,oy+3,8,4,P.parch[3]); p.frame(11,oy+3,8,4,P.brass[2]); p.hline(12,oy+5,6,P.K[1]); }
  else { p.rect(2,oy+2,26,18,P.felt[1]); p.frame(2,oy+2,26,18,P.felt[0]); p.rect(3,oy+3,24,16,P.felt[2]);
    if(full){ for(var i=0;i<5;i++){ var b=A.px(A.cardBack(11,16)); p.blit(b,4+i*4,oy+3+(i%2)); } p.rect(4,oy+17,22,2,P.felt[0]); } else { p.dither(3,oy+3,24,16,P.felt[2],P.felt[1],.4); } }
  return fin(p,1); }
def('storage.cardcase',function(){ return caseBox(false); });
def('storage.cardcase.open',function(){ return caseBox(true,true); });
def('storage.cardcase.empty',function(){ return caseBox(true,false); });

/* document folder: closed 22x30 (manila, tab on the top edge); open 44x30 (two leaves, clean paper areas) */
def('storage.folder',function(){ var p=new Px(24,32), M=P.parch;
  p.rect(0,3,22,27,M[2]); p.hline(0,3,22,M[4]); p.vline(0,3,27,M[3]); p.hline(0,29,22,M[0]); p.vline(21,3,27,M[1]);
  p.rect(2,0,9,5,M[2]); p.hline(2,0,9,M[4]); p.vline(2,0,5,M[3]); p.vline(10,1,4,M[1]); p.rect(3,2,6,1,P.K[1]);                       /* tab */
  p.rect(1,29,20,1,P.paper[3]); p.hline(3,28,16,P.paper[2]);                                                                       /* papers poke out */
  p.rect(6,12,10,6,M[3]); p.frame(6,12,10,6,M[1]); p.hline(8,15,6,P.K[1]);                                                         /* label */
  return fin(p,1); });
def('storage.folder.open',function(){ var p=new Px(46,32), M=P.parch;
  p.rect(0,3,22,27,M[2]); p.hline(0,3,22,M[4]); p.vline(0,3,27,M[3]); p.rect(2,0,9,4,M[2]); p.hline(2,0,9,M[4]);
  p.rect(22,3,22,27,M[1]); p.hline(22,3,22,M[3]); p.vline(43,3,27,M[0]); p.hline(22,29,22,M[0]); p.vline(22,3,27,M[0]);
  paper(p,3,6,16,21,P.paper); paper(p,25,6,16,21,P.paper); p.rect(5,9,12,1,P.steel[3]); p.rect(27,9,12,1,P.steel[3]);                    /* contents: clean areas (3..18,8..26) & (25..40,8..26) */
  return fin(p,1); });
/* document organizer (stage II): 3 slots with paper edges */
def('storage.organizer',function(){ var p=new Px(38,26);
  wood(p,0,0,36,24,P.walnut,7); p.frame(0,0,36,24,P.walnut[0]);
  [[2,2],[14,2],[26,2]].forEach(function(q,i){ p.rect(q[0],q[1],8,20,P.walnut[0]); p.rect(q[0]+1,q[1]+1,7,19,P.walnut[1]); for(var k=0;k<3+i%2;k++) { p.rect(q[0]+1,q[1]+1+k*2,6,2,k%2?P.paper[2]:P.paper[3]); } });
  p.rect(0,22,36,2,P.walnut[3]); p.hline(0,22,36,P.walnut[4]); return fin(p,1); });
/* equipment box (stage III): closed 34x24 with brass fittings; open 34x42 with contents tray */
function chest(open){ var H=open?42:24, oy=open?18:0, p=new Px(34,H);
  if(open){ wood(p,1,0,32,17,P.leather,9); p.frame(4,3,26,11,P.leather[0]); p.rect(5,4,24,9,P.leather[1]); disc(p,17,8.5,3.2,P.brass); p.set(16,7,P.brass[4]); }
  wood(p,0,oy,34,24,P.leather,2); p.frame(0,oy,34,24,P.leather[0]);
  [4,28].forEach(function(x){ p.rect(x,oy,3,24,P.brass[2]); p.vline(x,oy,24,P.brass[4]); p.vline(x+2,oy,24,P.brass[1]); });
  if(!open){ p.rect(14,oy+8,6,8,P.brass[3]); p.hline(14,oy+8,6,P.brass[4]); p.rect(16,oy+11,2,3,P.K[0]); p.rect(2,oy+22,30,1,P.leather[0]); }
  else { p.rect(8,oy+3,18,18,P.leather[0]); p.rect(9,oy+4,16,16,P.felt[1]); p.rect(9,oy+4,16,2,P.felt[0]); p.rect(11,oy+8,5,5,P.brass[2]); p.hline(11,oy+8,5,P.brass[4]); p.rect(18,oy+9,5,8,P.wax[2]); p.hline(18,oy+9,5,P.wax[4]); }
  return fin(p,1); }
def('storage.chest',function(){ return chest(false); }); def('storage.chest.open',function(){ return chest(true); });

/* ================= BOOKS (reference / lore; family of cloth covers) ================= */
function bookCover(ramp,w,h,seed,band){ var p=new Px(w+2,h+2); p.rect(0,0,w,h,ramp[2]); var r=C.rng(seed); for(var i=0;i<w*h/6;i++){ var x=r.int(0,w-1), y=r.int(0,h-1); p.set(x,y,r()<.5?ramp[1]:ramp[3]); }
  p.hline(0,0,w,ramp[4]); p.vline(0,0,h,ramp[4]); p.hline(0,h-1,w,ramp[0]); p.vline(w-1,0,h,ramp[0]); p.rect(0,0,4,h,ramp[1]); p.vline(4,0,h,ramp[0]);
  p.rect(7,5,w-11,8,P.parch[2]); p.frame(7,5,w-11,8,P.brass[2]); p.hline(9,9,w-15,P.K[1]); if(band){ p.rect(0,h-5,w,2,P.brass[3]); } return fin(p,1); }
def('book.manual',function(){ return bookCover(P.steel,24,32,31,true); });
def('book.opening',function(){ return bookCover(P.oxblood,22,30,32,false); });
def('book.field',function(){ return bookCover(P.forest,26,34,33,true); });
def('book.arcane',function(){ var p=bookCover(P.violet,24,32,34,true); return p; });

/* ================= DECOR / TROPHIES ================= */
def('decor.mug',function(){ var p=new Px(14,12); disc(p,5.5,6.5,5,P.ivory); p.ring(5.5,6.5,5,1,P.silver[1]); disc(p,5.5,6.5,3.2,P.walnut); p.rect(10,4,3,5,P.ivory[2]); p.rect(11,5,1,3,null); return fin(p,1); });
def('decor.lamp',function(){ var p=new Px(26,26); disc(p,12.5,12.5,12,P.tarnish); p.ring(12.5,12.5,12,1,P.tarnish[0]); p.ring(12.5,12.5,8,1,P.tarnish[1]); disc(p,12.5,12.5,4.5,P.brass); p.set(11,11,P.brass[4]); p.dither(2,2,20,20,null,P.amber[3]+'55',.25); return fin(p,1); });
def('trophy.cup',function(){ var p=new Px(26,20); disc(p,11.5,10.5,7.6,P.brass); p.ring(11.5,10.5,7.6,1,P.brass[1]); disc(p,11.5,10.5,4.4,P.brass); p.ring(11.5,10.5,4.4,1,P.brass[1]); p.set(10,9,P.brass[4]); p.set(9,10,P.brass[4]);
  p.rect(0,7,4,6,null); p.ring(2.5,10.5,2.4,1,P.brass[3]); p.ring(20.5,10.5,2.4,1,P.brass[2]); p.rect(19,17,6,3,P.parch[3]); p.frame(19,17,6,3,P.brass[1]); return fin(p,1); });
def('trophy.medal',function(){ var p=new Px(16,24); p.rect(6,0,4,10,P.navy[3]); p.vline(6,0,10,P.navy[4]); p.vline(9,0,10,P.navy[1]); p.rect(6,3,4,1,P.wax[3]); disc(p,8,16,6.4,P.brass); p.ring(8,16,6.4,1,P.brass[1]); p.ring(8,16,4,1,P.brass[1]); p.set(7,15,P.brass[4]); p.rect(7,13,2,6,P.brass[1]); p.rect(5,15,6,2,P.brass[1]); return fin(p,1); });
def('decor.candle',function(){ var p=new Px(12,12); disc(p,5.5,6.5,5,P.ivory); p.ring(5.5,6.5,5,1,P.tarnish[1]); disc(p,5.5,6.5,2.2,P.ivory); p.rect(5,5,2,2,P.amber[4]); p.set(5,4,P.glow[4]); p.set(6,4,P.glow[3]); return fin(p,1); });

/* ================= RELIC CONTAINERS (stage IV) ================= */
def('relic.casket',function(){ var p=new Px(34,26); p.bevel(0,0,32,24,P.iron,{fill:P.iron[1],hi:3,lo:0}); p.dither(1,1,30,22,P.iron[1],P.iron[2],.3); p.frame(3,3,26,18,P.violet[2]);
  p.frame(4,4,24,16,P.violet[1]); disc(p,16,12,5,P.violet); p.ring(16,12,5,1,P.violet[4]); p.rect(15,9,2,6,P.glow[4]); p.rect(13,11,6,2,P.glow[4]); [[1,1],[29,1],[1,21],[29,21]].forEach(function(q){ p.rect(q[0],q[1],2,2,P.silver[3]); });
  p.rect(14,22,4,2,P.silver[3]); return fin(p,1); });
def('relic.orrery',function(){ var p=new Px(30,30); disc(p,14.5,14.5,14,P.steel); p.ring(14.5,14.5,14,1,P.steel[0]); p.ring(14.5,14.5,10,1,P.silver[2]); p.ring(14.5,14.5,6,1,P.violet[3]); disc(p,14.5,14.5,2.4,P.glow);
  disc(p,24,9,2,P.silver); disc(p,5,19,1.6,P.violet); disc(p,13,24,1.6,P.brass); return fin(p,1); });
def('relic.moonglass',function(){ var p=new Px(16,16); disc(p,7.5,7.5,7,P.silver); p.ring(7.5,7.5,7,1,P.silver[0]); disc(p,9,7.5,5,P.violet); p.set(5,4,P.silver[4]); p.set(6,4,P.silver[4]); return fin(p,1); });

/* ================= CORRESPONDENCE (closed 24x16 + open sheet 28x36 per kind) =================
   kinds: ordinary | invite | official | clipping | personal | merchant | mystery
   open sheets leave a CLEAN text rectangle: C.objects.letterText[kind] = {x,y,w,h}; the host draws localized text there (DOM). */
var LK={ ordinary:{env:P.paper,edge:P.parch[1],seal:null,stamp:P.wax}, invite:{env:P.ivory,edge:P.brass[2],seal:P.wax,stamp:null}, official:{env:P.steel,edge:P.steel[1],seal:null,stamp:P.navy},
  clipping:{env:P.silver,edge:P.silver[1],seal:null,stamp:null}, personal:{env:P.steel,edge:P.wax[3],seal:null,stamp:P.wax}, merchant:{env:P.amber,edge:P.amber[1],seal:null,stamp:null}, mystery:{env:P.ebony,edge:P.violet[3],seal:P.violet,stamp:null} };
C.objects=C.objects||{}; C.objects.letterKinds=Object.keys(LK);
C.objects.letterText={ ordinary:{x:3,y:6,w:22,h:26}, invite:{x:4,y:9,w:20,h:21}, official:{x:3,y:9,w:22,h:22}, clipping:{x:3,y:11,w:22,h:21}, personal:{x:3,y:4,w:22,h:28}, merchant:{x:3,y:9,w:22,h:22}, mystery:{x:4,y:7,w:20,h:24} };
A.letter=function(kind,open){ var k='cav.o.mail.'+kind+(open?'.open':''); if(!A.has(k)) A.define(k,function(){ return open?letterOpen(kind):letterClosed(kind); }); return k; };
function letterClosed(kind){ var L=LK[kind], p=new Px(26,18), E=L.env; p.rect(0,0,24,16,E[3]); p.hline(0,0,24,E[4]); p.vline(0,0,16,E[4]); p.hline(0,15,24,E[1]); p.vline(23,0,16,E[1]);
  for(var x=0;x<12;x++){ var y=Math.round(x*8.5/12); p.set(x,y,E[1]); p.set(23-x,y,E[1]); }                                      /* flap */
  if(kind==='clipping'){ p.rect(0,0,24,16,P.silver[3]); p.dither(0,0,24,16,P.silver[3],P.silver[2],.3); p.rect(2,2,20,3,P.ebony[2]); lines(p,2,7,10,3,3,P.ebony[3]); p.rect(14,7,8,7,P.silver[1]); p.dither(14,7,8,7,P.silver[1],P.ebony[3],.4); }
  if(kind==='merchant'){ disc(p,12,9,3.4,P.brass); p.set(11,8,P.brass[4]); p.hline(2,2,20,E[2]); }
  if(kind==='official'){ p.rect(3,9,9,5,P.paper[4]); p.frame(3,9,9,5,E[1]); p.rect(15,2,6,4,P.navy[3]); p.frame(15,2,6,4,P.navy[1]); lines(p,0,13,24,1,1,E[2]); }
  if(kind==='personal'){ for(var i=0;i<24;i+=3){ p.rect(i,0,2,1,P.wax[3]); p.rect(i+1,15,2,1,P.steel[2]); } p.rect(16,2,5,5,P.paper[3]); p.frame(16,2,5,5,P.wax[2]); }
  if(kind==='ordinary') { p.rect(17,2,5,6,P.paper[4]); p.frame(17,2,5,6,L.stamp[3]); p.rect(19,4,2,2,L.stamp[3]); p.hline(3,10,10,E[1]); p.hline(3,12,7,E[1]); }
  if(kind==='mystery'){ p.hline(0,0,24,E[3]); p.frame(1,1,22,14,P.violet[2]); }
  if(L.seal){ var cx=12, cy=kind==='mystery'?9:9; disc(p,cx,cy,3.3,L.seal); p.ring(cx,cy,2.4,1,L.seal[kind==='mystery'?4:1]); p.set(cx-1,cy-1,L.seal[4]); if(kind==='invite'){ p.rect(0,7,24,2,P.brass[3]); p.hline(0,7,24,P.brass[4]); disc(p,cx,cy,3.3,L.seal); p.set(cx-1,cy-1,L.seal[4]); } }
  return fin(p,1); }
function letterOpen(kind){ var L=LK[kind], p=new Px(30,38), E=L.env, paperTone=(kind==='clipping')?P.silver:(kind==='mystery'?P.ebony:(kind==='merchant'?P.parch:P.paper));
  p.rect(0,0,28,36,paperTone[3]); p.hline(0,0,28,paperTone[4]); p.vline(0,0,36,paperTone[4]); p.hline(0,35,28,paperTone[1]); p.vline(27,0,36,paperTone[1]);
  var T=C.objects.letterText[kind];
  if(kind==='invite'){ p.frame(1,1,26,34,P.brass[2]); p.frame(2,2,24,32,P.brass[1]); p.rect(10,3,8,4,P.brass[3]); disc(p,14,5,2,P.wax); }
  if(kind==='official'){ p.rect(0,0,28,6,P.navy[2]); p.hline(0,0,28,P.navy[4]); p.rect(11,1,6,4,P.silver[3]); p.frame(11,1,6,4,P.navy[0]); p.rect(3,32,10,1,P.navy[3]); }
  if(kind==='clipping'){ p.rect(2,2,24,7,P.ebony[2]); p.rect(3,3,14,2,P.silver[4]); p.rect(3,6,9,1,P.silver[3]); p.dither(18,3,7,5,P.ebony[2],P.silver[2],.5); p.vline(14,10,24,P.silver[1]); }
  if(kind==='personal'){ for(var y=6;y<34;y+=4) p.hline(3,y,22,P.steel[3]); p.vline(5,2,32,P.wax[3]); }
  if(kind==='merchant'){ p.frame(1,1,26,34,P.amber[1]); p.rect(2,2,24,5,P.amber[2]); disc(p,14,4.5,2,P.brass); }
  if(kind==='mystery'){ p.frame(1,1,26,34,P.violet[2]); disc(p,14,34,2.5,P.violet); p.ring(14,34,2.5,1,P.violet[4]); p.set(4,4,P.silver[4]); p.set(24,30,P.silver[3]); p.set(22,6,P.violet[4]); }
  if(kind==='ordinary'){ p.hline(2,3,8,P.paper[1]); }
  /* leave text area clean (pixel-flat) so the host's DOM text reads at any language */
  if(kind==='mystery'){ p.rect(T.x,T.y,T.w,T.h,P.ebony[1]); } else { p.rect(T.x,T.y,T.w,T.h,paperTone[3]); }
  return fin(p,1); }

/* ================= BASIC TOOLS ================= */
def('tool.magnifier',function(){ var p=new Px(24,24); p.ring(9.5,9.5,8,2,P.brass[3]); p.ring(9.5,9.5,8,1,P.brass[1]); p.dither(2,2,15,15,null,P.steel[4]+'55',.35); p.line(15,15,22,22,P.walnut[2]); p.line(16,15,22,21,P.walnut[3]); p.line(15,16,21,22,P.walnut[1]); return fin(p,1); });
def('tool.sealwax',function(){ var p=new Px(20,10); p.rect(0,0,16,5,P.wax[2]); p.hline(0,0,16,P.wax[4]); p.hline(0,4,16,P.wax[1]); p.rect(16,0,3,5,P.tarnish[2]); disc(p,10,8,2.2,P.wax); return fin(p,1); });

/* Parametric opened sheet for INSPECTION (any size): decoration only, the text rectangle stays clean. */
C.objects.sheetText=function(kind,w,h){ var m={ordinary:[8,8],invite:[12,24],official:[10,20],clipping:[10,22],personal:[12,8],merchant:[10,20],mystery:[12,16]}[kind]||[8,8]; return {x:m[0],y:m[1],w:w-m[0]-8,h:h-m[1]-8,dark:kind==='mystery'}; };
A.letterSheet=function(kind,w,h){ var k='cav.o.mail.sheet.'+kind+'@'+w+'x'+h; if(!A.has(k)) A.define(k,function(){ var p=new Px(w,h), tone=(kind==='clipping')?P.silver:(kind==='mystery'?P.ebony:(kind==='merchant'?P.parch:P.paper));
  paper(p,0,0,w-2,h-2,tone); var T=C.objects.sheetText(kind,w,h);
  if(kind==='invite'){ p.frame(2,2,w-6,h-6,P.brass[2]); p.frame(3,3,w-8,h-8,P.brass[1]); p.rect(Math.floor(w/2)-9,4,18,6,P.brass[3]); p.hline(Math.floor(w/2)-9,4,18,P.brass[4]); disc(p,Math.floor(w/2),7,3,P.wax); }
  if(kind==='official'){ p.rect(0,0,w-2,12,P.navy[2]); p.hline(0,0,w-2,P.navy[4]); p.rect(Math.floor(w/2)-5,2,10,8,P.silver[3]); p.frame(Math.floor(w/2)-5,2,10,8,P.navy[0]); p.rect(6,h-9,22,1,P.navy[3]); }
  if(kind==='clipping'){ p.rect(3,3,w-8,12,P.ebony[2]); p.rect(5,5,Math.floor((w-8)*.6),3,P.silver[4]); p.rect(5,10,Math.floor((w-8)*.35),2,P.silver[3]); p.dither(w-30,5,22,8,P.ebony[2],P.silver[2],.5); p.vline(Math.floor(w/2),T.y,T.h,P.silver[1]); }
  if(kind==='personal'){ p.vline(8,2,h-6,P.wax[3]); }
  if(kind==='merchant'){ p.frame(2,2,w-6,h-6,P.amber[1]); p.rect(3,3,w-8,10,P.amber[2]); disc(p,Math.floor(w/2),8,3,P.brass); }
  if(kind==='mystery'){ p.frame(2,2,w-6,h-6,P.violet[2]); p.frame(4,4,w-10,h-10,P.violet[1]); disc(p,Math.floor(w/2),h-9,4,P.violet); p.ring(Math.floor(w/2),h-9,4,1,P.violet[4]); p.set(7,7,P.silver[4]); p.set(w-10,12,P.violet[4]); }
  if(kind==='ordinary'){ p.hline(6,5,14,P.paper[1]); }
  p.rect(T.x,T.y,T.w,T.h,tone[3]); if(kind==='mystery') p.rect(T.x,T.y,T.w,T.h,P.ebony[1]);
  return p.outline(P.K[0]).shadow(SH,1,1); }); return k; };
})();
