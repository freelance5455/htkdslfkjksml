/* CAV.ui: small DOM kit shared by all components — sprites, buttons, panels, overlays (with Android Back support), toasts. */
(function(){
var C=window.CAV, h=C.h, A=C.art, ui=C.ui=C.ui||{};
function T(k,v){ return C.t(k,v); }

ui.spr=function(key,cls){ return A.el(key,cls); };
ui.icon=function(name,cls){ return A.el(A.icon(name),'cav-icon '+(cls||'')); };
ui.text=function(txt,cls){ return h('span',{class:'cav-txt '+(cls||''),text:txt}); };
ui.btn=function(o){ o=o||{}; var kids=[]; if(o.icon) kids.push(ui.icon(o.icon)); if(o.label!=null) kids.push(h('span',{text:o.label,class:'cav-nowrap'}));
  var b=h('button',{type:'button',class:'cav-btn '+(o.kind||'')+(o.label==null?' icon':'')+(o.big?' big':'')+' '+(o.cls||''),'aria-label':o.aria||o.label||o.icon},kids);
  if(o.disabled) b.disabled=true; if(o.onClick) b.addEventListener('click',function(e){ if(b.disabled) return; C.sfx('ui.click'); o.onClick(e); }); return b; };
ui.panel=function(kind,kids,cls,attrs){ var a=Object.assign({class:'cav-panel '+kind+' '+(cls||'')},attrs||{}); return h('div',a,kids); };
ui.root=function(){ return document.getElementById('cav-root'); };

/* ---------- overlay manager: stack, Esc, Android Back (history), focus restore ---------- */
var stack=[], useHistory=true;
ui.overlay={
  setHistory:function(v){ useHistory=!!v; },
  depth:function(){ return stack.length; },
  /* open({title, content:Element, kind:'paper'|'wood'|..., cls, onClose, noClose, bare}) -> {el, panel, close(), setTitle()} */
  open:function(o){ o=o||{}; var prev=document.activeElement, closed=false;
    var titleEl=h('h2',{text:o.title||'',class:'cav-up'});
    var closeBtn=ui.btn({icon:'close',kind:o.closeKind||'wood',aria:T('cav.close'),onClick:function(){ api.close('button'); }});
    var bar=o.bare?null:h('div',{class:'cav-titlebar'},[o.icon?ui.icon(o.icon):null,titleEl,o.headerExtra||null,o.noClose?null:closeBtn]);
    var panel=o.bare?o.content:ui.panel(o.kind||'wood',[bar,o.content],'cav-ov-panel '+(o.cls||''));
    if(o.bare){ panel.classList.add('cav-ov-panel'); }
    var el=h('div',{class:'cav-ov'+(stack.length?' cav-ov-top':''),role:'dialog','aria-modal':'true','aria-label':o.title||''},[panel]);
    el.addEventListener('pointerdown',function(e){ if(e.target===el && !o.noClose && !o.modal) api.close('scrim'); });
    var api={ el:el, panel:panel, setTitle:function(t){ titleEl.textContent=t; },
      close:function(why){ if(closed) return; closed=true; var i=stack.indexOf(api); if(i>=0) stack.splice(i,1); el.remove(); document.removeEventListener('keydown',key,true);
        if(useHistory && why!=='history' && history.state && history.state.cav===api._id){ try{ history.back(); }catch(e){} }
        try{ prev&&prev.focus&&prev.focus(); }catch(e){} if(o.onClose) o.onClose(why||'api'); C.bus.emit('overlay:close',{id:o.id}); } };
    function key(e){ if(e.key==='Escape' && stack[stack.length-1]===api && !o.noClose){ e.stopPropagation(); api.close('esc'); } }
    document.addEventListener('keydown',key,true);
    ui.root().appendChild(el); stack.push(api);
    if(useHistory){ api._id=Date.now()+Math.random(); try{ history.pushState({cav:api._id},''); }catch(e){} }
    setTimeout(function(){ var f=el.querySelector('[data-autofocus]')||closeBtn; try{ f.focus({preventScroll:true}); }catch(e){} },0);
    C.sfx('ui.open',{id:o.id}); C.bus.emit('overlay:open',{id:o.id});
    return api; },
  closeAll:function(){ stack.slice().reverse().forEach(function(a){ a.close('closeAll'); }); }
};
window.addEventListener('popstate',function(){ if(stack.length){ var top=stack[stack.length-1]; top.close('history'); } });

ui.toast=function(msg,ms){ var t=ui.panel('plaque',[h('span',{text:msg,class:'cav-ink'})],'cav-toast'); ui.root().appendChild(t); setTimeout(function(){ t.remove(); },ms||1800); };

/* round brass counter used for costs / numbers */
ui.num=function(n,cls){ return h('span',{class:'cav-num '+(cls||''),text:String(n)}); };

/* Phone sprite for the rotate-device screen */
A.define('cav.ui.phone',function(){ var P=C.pal, p=new C.Px(30,52); p.bevel(0,0,30,52,P.iron,{fill:P.iron[1],hi:3,lo:0}); p.rect(3,5,24,42,P.navy[2]); p.dither(3,5,24,42,P.navy[1],P.navy[3],.3);
  p.rect(10,2,10,1,P.iron[4]); p.ellipse(15,49.5,2,2,P.iron[3]);
  var k=A.px(A.piece('n',true,22)); p.blit(k,4,15); return p.outline(P.K[0]).shadow('#00000066',1,1); });
})();
