/* CAV.cards — card presentation. Reusable templates (full 72x104, thumbnail 24x34, hand strip) driven by plain data.
   No rules live here: the host says what a card IS (cost, rarity, chips...) and what STATE it is in. */
(function(){
var C=window.CAV, h=C.h, A=C.art, ui=C.ui, T=C.t;
var cards=C.cards={};
var RARITY_ORDER=['common','rare','epic','legendary'];
cards.RARITY_ORDER=RARITY_ORDER;

/* Presentation-only mapping of V3H effect ops -> language-independent chips. Host may supply its own chips instead. */
cards.chipsFromDef=function(d){ var chips=[], q=function(i,n,k){ chips.push({icon:i,n:n,key:k}); };
  (d.effects||[]).forEach(function(e){ if(e.op==='draw'||e.op==='drawCaptured') q('draw',e.n||e.max,'draw'); else if(e.op==='doubloons') q('coin',e.n,'coin'); else if(e.op==='energy') q('energy',e.n,'energy'); else if(e.op==='queue') q('target',null,'target'); else if(e.op==='if'){ q('energy',null,'energy'); } });
  if(d.type==='passive') q('star',null,'power'); if(d.type==='modifier') q('gear',null,'rule');
  if(d.cooldown) q('hourglass',d.cooldown,'cooldown'); if(d.exhaust) q('flame',null,'exhaust'); if(d.check==='onlyInCheck') q('shield',null,'check');
  var seen={}; return chips.filter(function(c){ var k=c.icon+c.n; if(seen[k]) return false; seen[k]=1; return true; }).slice(0,4); };

function chipsEl(chips){ var w=h('div',{class:'cc-chips'}); (chips||[]).forEach(function(c){ var e=h('span',{class:'cc-chip',title:T('cav.chip.'+(c.key||c.icon))},[ui.icon(c.icon)]); if(c.n!=null) e.appendChild(h('span',{class:'cc-n',text:String(c.n)})); w.appendChild(e); }); return w; }

/* ---------- full card ----------
   opts: {id,name,cost,rarity,type,arch:[ids],motif,chips,enchant,count,selected,disabled,locked,isNew,onTap,label} */
cards.create=function(o){ var K=A.CARD, el, parts={};
  function build(){ el.innerHTML=''; var face=A.cardFace({rarity:o.rarity,arch:o.arch&&o.arch.length?o.arch:null,motif:o.motif}); var locked=o.locked;
    var cv=A.el(locked?A.cardBack(72,104):face,'cc-face'); el.appendChild(cv);
    if(locked){ el.appendChild(h('div',{class:'cc-lockmark'},[ui.icon('lock')])); return; }
    el.appendChild(h('span',{class:'cc-cost',text:String(o.cost!=null?o.cost:'')}));
    el.appendChild(h('div',{class:'cc-name'},[h('span',{text:o.name||'',class:'cav-ink'})]));
    el.appendChild(h('div',{class:'cc-type',text:(o.typeLabel||T('cav.typeShort.'+(o.type||'active'))).toUpperCase()}));
    el.appendChild(chipsEl(o.chips));
    if(o.enchant){ var sl=h('div',{class:'cc-ench',title:o.enchant},[A.el(A.seal(o.enchant))]); el.appendChild(sl); }
    if(o.count>1) el.appendChild(h('span',{class:'cc-count',text:'x'+o.count}));
    if(o.isNew) el.appendChild(h('span',{class:'cc-new'},[ui.icon('star')]));
    if(o.rarity==='legendary') el.appendChild(h('span',{class:'cc-foil','aria-hidden':'true'}));
  }
  el=h('button',{type:'button',class:'cav-card','data-rarity':o.rarity||'common','aria-label':(o.name||'')+(o.cost!=null?', '+T('cav.match.energy')+' '+o.cost:'')});
  function flags(){ el.classList.toggle('is-selected',!!o.selected); el.classList.toggle('is-disabled',!!o.disabled); el.classList.toggle('is-locked',!!o.locked); el.setAttribute('aria-pressed',o.selected?'true':'false'); if(o.disabled) el.setAttribute('aria-disabled','true'); else el.removeAttribute('aria-disabled'); }
  build(); flags();
  el.addEventListener('click',function(e){ if(o.onTap) o.onTap(o,e); });
  el._cav={ update:function(p){ Object.assign(o,p); build(); flags(); }, setState:function(p){ Object.assign(o,p); flags(); }, opts:o };
  return el; };

/* ---------- thumbnail (binder pockets, reveal trays) ---------- */
cards.thumb=function(o){ var el=h('button',{type:'button',class:'cav-thumb','aria-label':o.locked?T('cav.album.undiscovered'):(o.name||'')});
  el.appendChild(A.el(A.cardThumb({rarity:o.rarity,arch:o.arch,motif:o.motif,locked:o.locked}),'ct-face'));
  if(o.count>1) el.appendChild(h('span',{class:'ct-count',text:o.count}));
  if(o.isNew) el.appendChild(h('span',{class:'ct-new'},[ui.icon('star')]));
  if(o.inDeck) el.appendChild(h('span',{class:'ct-deck'},[ui.icon('check')]));
  el.classList.toggle('is-selected',!!o.selected); el.classList.toggle('is-dim',!!o.dim);
  if(o.onTap) el.addEventListener('click',function(e){ o.onTap(o,e); }); return el; };

/* ---------- hand strip (match). 76-100 art-px wide, 19 high ---------- */
cards.strip=function(o){ var dis=!!o.disabled;
  var el=h('button',{type:'button',class:'cav-strip'+(o.selected?' is-selected':'')+(dis?' is-disabled':''),'data-rarity':o.rarity||'common','aria-pressed':o.selected?'true':'false','aria-label':(o.name||'')+', '+T('cav.match.energy')+' '+o.cost+(dis&&o.why?' — '+o.why:'')});
  var badge=h('span',{class:'cs-cost'},[A.el(A.has('cav.ui.costbadge')?(dis?'cav.ui.costbadge.dis':'cav.ui.costbadge'):'cav.ui.costbadge'),h('b',{text:String(o.cost)})]);
  el.appendChild(badge); el.appendChild(h('span',{class:'cs-name cav-ell',text:o.name||''}));
  var ic=(o.chips&&o.chips[0]); if(ic) el.appendChild(h('span',{class:'cs-ic'},[ui.icon(ic.icon)]));
  if(o.enchant) el.appendChild(h('span',{class:'cs-seal'},[A.el(A.seal(o.enchant))]));
  if(o.onTap) el.addEventListener('click',function(e){ o.onTap(o,e); }); return el; };

/* ---------- inspector: big card + readable text. Used by album, catalog, booster reveal, hand selection. ----------
   inspect({card:{...cardopts}, description, flavor, tags:[...], actions:[{label,kind,onClick,disabled}], note}) -> Element */
cards.inspector=function(o){ var c=o.card, card=cards.create(Object.assign({},c,{onTap:null,selected:false,disabled:false}));
  var rar=T('cav.rarity.'+(c.rarity||'common')), ty=T('cav.type.'+(c.type||'active')), ar=(c.arch&&c.arch.length)?c.arch.map(function(a){return T('cav.arch.'+a)}).join(' + '):T('cav.arch.neutral');
  var legend=h('div',{class:'ci-legend'}); (c.chips||[]).forEach(function(ch){ legend.appendChild(h('div',{class:'ci-lg'},[ui.icon(ch.icon),h('span',{text:T('cav.chip.'+(ch.key||ch.icon))+(ch.n!=null?' '+ch.n:'')})])); });
  var acts=h('div',{class:'ci-actions'}); (o.actions||[]).forEach(function(a){ acts.appendChild(ui.btn({label:a.label,kind:a.kind||'brass',icon:a.icon,disabled:a.disabled,onClick:a.onClick})); });
  var txt=ui.panel('paper',[ h('div',{class:'ci-name',text:c.name||''}), h('div',{class:'ci-tags'},[h('span',{text:rar,class:'ci-tag r-'+(c.rarity||'common')}),h('span',{text:ty,class:'ci-tag'}),h('span',{text:ar,class:'ci-tag'})]),
    h('div',{class:'ci-desc cav-scroll',text:o.description||''}), o.note?h('div',{class:'ci-note',text:o.note}):null, legend ],'ci-text');
  return h('div',{class:'cav-inspector'},[h('div',{class:'ci-cardcol'},[card, c.enchant?h('div',{class:'ci-ench cav-ink',text:(o.enchantName||c.enchant)}):null]), h('div',{class:'ci-col'},[txt,acts])]); };
})();
