/* CAV.catalog — the Merchant's catalog: an old book lying open on the desk (top-down, spine vertical).
   Shows ONE fixed daily inventory (same before and after the workday — reopening never changes stock). Orders arrive the next morning.
   props: {inventory:{day,products:[{id,kind:'booster'|'card'|'ench',arch|card|ench,price,stock,name?}]}, balance, ordered:{[productId]:n}, resolve:{card(id),ench(id)}, tab, onOrder(productId,qty), onClose()} */
(function(){
var C=window.CAV, h=C.h, A=C.art, ui=C.ui, T=C.t;
var TABS=[['booster','cav.cat.boosters','navy','book'],['card','cav.cat.cards','brass','draw'],['ench','cav.cat.ench','wax','star']];
C.catalog={ create:function(props){
  var P=Object.assign({inventory:{day:1,products:[]},balance:0,ordered:{},resolve:{}},props), S={tab:P.tab||'booster',page:{booster:0,card:0,ench:0}};
  var el=h('div',{class:'cav-book cat'}), spread=null, L=h('div',{class:'bk-page cat-page cat-left'}), R=h('div',{class:'bk-page cat-page cat-right'}), tabs=h('div',{class:'bk-tabs'});
  function size(){ var st=C.stage.get(); return {w:Math.min(400,st.vw-Math.max(6,st.safe.l+st.safe.r)-22), h:Math.min(224,st.vh-Math.max(6,st.safe.t+st.safe.b)-6)}; }
  function place(e,x,y,w,hh){ e.style.cssText='left:calc(var(--u)*'+x+');top:calc(var(--u)*'+y+');width:calc(var(--u)*'+w+');height:calc(var(--u)*'+hh+')'; }
  function layout(){ var s=size(); el.style.width='calc(var(--u)*'+s.w+')'; el.style.height='calc(var(--u)*'+s.h+')'; if(spread) spread.remove(); spread=A.el(A.bookSpread(s.w,s.h,'catalog'),'bk-spread'); el.insertBefore(spread,el.firstChild);
    var mid=Math.floor(s.w/2), m=8; place(L,m,m,mid-m-8,s.h-2*m); place(R,mid+8,m,s.w-m-(mid+8),s.h-2*m); }
  function name(p){ if(p.name) return p.name; if(p.kind==='booster') return T('cav.arch.'+p.arch); if(p.kind==='card') return (P.resolve.card(p.card)||{}).name||p.card; return (P.resolve.ench(p.ench)||{}).name||p.ench; }
  function list(){ return P.inventory.products.filter(function(p){ return p.kind===S.tab; }); }
  function sprite(p){ if(p.kind==='booster') return A.el(A.packMini(p.arch)); if(p.kind==='card'){ var d=P.resolve.card(p.card)||{}; return A.el(A.cardThumb({rarity:d.rarity,arch:d.arch,motif:d.motif})); }
    return h('span',{class:'cat-seal'},[A.el(A.seal(p.ench))]); }
  function tile(p){ var ordered=P.ordered[p.id]||0, sold=p.stock<=0, poor=P.balance<p.price;
    var b=h('button',{type:'button',class:'cat-tile'+(sold?' is-sold':'')+(poor&&!sold?' is-poor':''),'aria-label':name(p)+', '+p.price+' '+T('cav.doubloons')+(sold?', '+T('cav.cat.sold'):'')});
    b.appendChild(h('span',{class:'cat-art'},[sprite(p)])); b.appendChild(h('span',{class:'cat-name cav-ell',text:name(p)}));
    b.appendChild(h('span',{class:'cat-price'},[ui.icon('coin'),h('span',{class:poor?'cav-wax':'',text:String(p.price)}),h('span',{class:'cat-stock cav-dim',text:'×'+Math.max(0,p.stock-ordered)})]));
    if(sold) b.appendChild(h('span',{class:'cat-stamp wax'},[A.el(A.stampFrame(52,16,'wax')),h('span',{text:T('cav.cat.sold')})]));
    else if(ordered) b.appendChild(h('span',{class:'cat-stamp forest'},[A.el(A.stampFrame(52,16,'forest')),h('span',{text:T('cav.cat.ordered')+(ordered>1?' ×'+ordered:'')})]));
    b.addEventListener('click',function(){ C.sfx('book.tap'); detail(p); }); return b; }
  function render(flip){ var items=list(), per=8, pages=Math.max(1,Math.ceil(items.length/per)), pg=Math.min(S.page[S.tab],pages-1); S.page[S.tab]=pg; var slice=items.slice(pg*per,pg*per+per);
    L.innerHTML=''; R.innerHTML='';
    L.appendChild(h('div',{class:'cat-head'},[h('span',{class:'cav-up cav-ell',text:T('cav.cat.title')})]));
    var gl=h('div',{class:'cat-grid'}), gr=h('div',{class:'cat-grid'}); slice.slice(0,4).forEach(function(p){ gl.appendChild(tile(p)); }); slice.slice(4).forEach(function(p){ gr.appendChild(tile(p)); });
    L.appendChild(gl); R.appendChild(h('div',{class:'cat-head'},[h('span',{class:'cav-up',text:T(TABS.filter(function(t){return t[0]===S.tab})[0][1])}),h('span',{class:'cat-bal'},[ui.icon('coin'),h('span',{text:String(P.balance)})])])); R.appendChild(gr);
    var foot=h('div',{class:'cat-foot'},[ui.btn({icon:'left',kind:'wood',aria:T('cav.back'),disabled:pg===0,onClick:function(){ S.page[S.tab]--; C.sfx('book.page'); render(true); }}),h('span',{class:'cav-fill cav-c cav-dim cav-ell',text:T('cav.cat.page',{a:pg+1,b:pages})}),ui.btn({icon:'right',kind:'wood',aria:T('cav.next'),disabled:pg>=pages-1,onClick:function(){ S.page[S.tab]++; C.sfx('book.page'); render(true); }})]);
    R.appendChild(foot);
    tabs.innerHTML=''; TABS.forEach(function(t){ var on=S.tab===t[0], b=h('button',{type:'button',class:'bk-tab'+(on?' on':''),'aria-label':T(t[1]),'aria-selected':on?'true':'false'}); b.appendChild(A.el(A.tab(t[2],on))); b.appendChild(h('span',{class:'bk-tabic'},[ui.icon(t[3])]));
      b.addEventListener('click',function(){ S.tab=t[0]; C.sfx('book.page'); render(true); }); tabs.appendChild(b); });
    if(flip&&!C.reducedMotion()){ R.classList.remove('bk-flip'); void R.offsetWidth; R.classList.add('bk-flip'); } }
  /* ---- product details + purchase confirmation ---- */
  function detail(p){ var ordered=P.ordered[p.id]||0, left=p.stock-ordered, can=left>0&&P.balance>=p.price, body, ov, why=left<=0?T('cav.cat.sold'):(P.balance<p.price?T('cav.cat.noFunds'):'');
    var order=function(){ confirm(p,ov); };
    if(p.kind==='card'){ var d=P.resolve.card(p.card)||{}; body=C.cards.inspector({card:Object.assign({},d),description:d.description,note:why,actions:[{label:T('cav.cat.buy')+' · '+p.price,icon:'coin',kind:'brass',disabled:!can,onClick:order}]}); }
    else { var d2=p.kind==='booster'?{name:name(p),description:T('cav.cat.contents')}:(P.resolve.ench(p.ench)||{}); var ar=p.kind==='booster'?C.archetype(p.arch):null;
      body=h('div',{class:'cav-inspector'},[h('div',{class:'ci-cardcol'},[p.kind==='booster'?A.el(A.pack(p.arch,'sealed')):h('span',{class:'cat-seal big'},[A.el(A.seal(p.ench))])]),
        h('div',{class:'ci-col'},[ui.panel('paper',[h('div',{class:'ci-name',text:name(p)}),h('div',{class:'ci-desc cav-scroll',text:d2.description||''}),ar?h('div',{class:'ci-tags'},[h('span',{class:'ci-tag',text:T('cav.arch.'+ar.id)})]):null,why?h('div',{class:'ci-note',text:why}):null],'ci-text'),
          h('div',{class:'ci-actions'},[ui.btn({label:T('cav.cat.buy')+' · '+p.price,icon:'coin',disabled:!can,onClick:order})])])]); }
    ov=ui.overlay.open({id:'catalog.product',title:name(p),content:body,kind:'wood',icon:p.kind==='booster'?'parcel':'book'}); }
  function confirm(p,parentOv){ var after=P.balance-p.price, panel=h('div',{class:'cat-confirm'},[h('div',{class:'cav-c',text:name(p)}),h('div',{class:'cat-conf-row'},[h('span',{text:T('cav.doubloons')}),h('span',{class:'cav-fill'}),ui.icon('coin'),h('span',{text:String(p.price)})]),
      h('div',{class:'cat-conf-row'},[h('span',{text:T('cav.cat.after')}),h('span',{class:'cav-fill'}),ui.icon('coin'),h('span',{text:String(after)})]),h('div',{class:'cav-c cav-brass',text:T('cav.cat.arrive')}),
      h('div',{class:'ci-actions'},[ui.btn({label:T('cav.cancel'),kind:'wood',onClick:function(){ ov.close('cancel'); }}),ui.btn({label:T('cav.confirm'),kind:'forest',icon:'check',onClick:function(){ ov.close('ok'); if(parentOv) parentOv.close('ok'); if(P.onOrder) P.onOrder(p.id,1); C.sfx('shop.order'); }})])]);
    var ov=ui.overlay.open({id:'catalog.confirm',title:T('cav.cat.confirm'),content:panel,kind:'paper',closeKind:'wax'}); }
  var close=ui.btn({icon:'close',kind:'wax',aria:T('cav.close'),cls:'bk-close',onClick:function(){ if(P.onClose) P.onClose(); }});
  el.appendChild(L); el.appendChild(R); el.appendChild(tabs); el.appendChild(close); layout(); render();
  var unsub=C.stage.on('resize',function(){ layout(); render(); });
  return { el:el, update:function(p){ Object.assign(P,p); render(); }, destroy:function(){ unsub(); el.remove(); } }; },
 open:function(props){ var cat, ov, orig=props.onClose; props=Object.assign({},props,{onClose:function(){ ov.close('x'); if(orig) orig(); }}); cat=C.catalog.create(props); ov=ui.overlay.open({id:'catalog',bare:true,content:cat.el,onClose:function(){ cat.destroy(); }}); cat.overlay=ov; return cat; } };
})();
