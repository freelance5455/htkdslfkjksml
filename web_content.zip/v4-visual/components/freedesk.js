/* CAV.freeDesk — freeform physical desk layer (presentation only).
   Objects are independent sprites: no grid, no slots, no snapping, no forced alignment.  Pointer Events drag (mouse + touch + pen); everything that can be
   dragged also has a tap path (select -> action bar -> Move / Front / Store / Open / Inspect; or "Move" then tap the target spot) and a keyboard path.
   The host owns the instance list (what exists, what is stored); this layer reports changes via callbacks and never decides game rules.

   create({ insts, area():{l,t,r,b}, home(inst):{x,y}, ctx:{minutes}, badges(inst):number, caption(text),
            onTap(inst,def), onInspect(inst,def), onChange(insts), onStore(inst,container), onRetrieve(inst,container) }) -> api
   instance: { uid, id, kind?, variant?, seed?, open?, in?:containerUid, nx?,ny? (normalised, set once the player moves it), z?, ring?, data? } */
(function(){
var C=window.CAV, h=C.h, A=C.art, ui=C.ui, T=C.t, O=C.objects;
var DRAG_PX=6, LONG_MS=450;
function S(){ return C.stage.get(); }

C.freeDesk={ create:function(o){
  var L=o.insts, ctx=o.ctx||{minutes:570}, layer=h('div',{class:'fd'}), top=h('div',{class:'fd fd-top'}), tray=null, bar=null, hint=null, catcher=null;
  var els={}, sel=null, moveFor=null, down=null, topZ=1000, vis=true, offs=[];
  function def(i){ return O.defs[i.id]; }
  function byUid(u){ for(var k=0;k<L.length;k++) if(L[k].uid===u) return L[k]; return null; }
  function onDesk(i){ return !i.in; }
  function contents(c){ return L.filter(function(i){ return i.in===c.uid; }); }
  function key(i){ return O.spriteKey(i,ctx); }
  function closedKey(i){ var d=def(i); if(!d.storage) return key(i); return d.sprite(Object.assign({},i,{open:false,contents:[]}),'rest',ctx); }
  function size(i){ return A.size(key(i)); }
  function area(){ var a=o.area(); return a; }
  function pos(i){ var st=S(); if(i.nx!=null) return {x:Math.round(i.nx*st.vw),y:Math.round(i.ny*st.vh)}; var p=o.home?o.home(i):null; return p||{x:Math.round(st.vw/2),y:Math.round(st.vh/2)}; }
  function clamp(i,x,y){ var a=area(), sz=size(i), off=anchorOff(i); return { x:Math.max(a.l,Math.min(a.r-sz.w,Math.round(x))), y:Math.max(a.t-off,Math.min(a.b-sz.h-off,Math.round(y))) }; }
  /* open storage sprites grow upward (anchor 'bottom'): the CLOSED footprint stays put */
  function anchorOff(i){ var d=def(i); if(d.anchor!=='bottom') return 0; return A.size(closedKey(i)).h-size(i).h; }
  function rect(i){ var p=pos(i), sz=size(i), off=anchorOff(i); return {x:p.x,y:p.y+off,w:sz.w,h:sz.h}; }
  function hitPad(w,hh){ return O.hit(w,hh); }

  /* ---------- rendering ---------- */
  function setPos(i,e){ var p=pos(i), off=anchorOff(i); e.style.left='calc(var(--u)*'+p.x+')'; e.style.top='calc(var(--u)*'+(p.y+off)+')'; }
  function build(i){ var d=def(i), e=els[i.uid]; var k=key(i), sz=A.size(k), hp=hitPad(sz.w,sz.h);
    if(!e){ e=h('div',{class:'fd-o fd-f-'+d.family,role:'button',tabindex:'0','data-uid':String(i.uid),'data-obj':i.id}); els[i.uid]=e; layer.appendChild(e); wire(i,e); }
    if(e.dataset.k!==k){ e.dataset.k=k; var old=e.querySelector('.cav-spr'); var n=A.el(k); if(old) e.replaceChild(n,old); else e.insertBefore(n,e.firstChild); }
    e.style.setProperty('--hx',hp.padX); e.style.setProperty('--hy',hp.padY); e.style.width='calc(var(--u)*'+sz.w+')'; e.style.height='calc(var(--u)*'+sz.h+')';
    e.style.zIndex=i.z!=null?i.z:(O.LAYER[d.layer]||200);
    var label=o.label?o.label(i):T('cav.obj.'+(i.id==='letter'?'letter':i.id)); e.setAttribute('aria-label',label); e.classList.toggle('is-open',!!i.open); e.classList.toggle('is-sel',sel===i.uid); e.classList.toggle('is-ring',!!i.ring);
    var bd=o.badges?o.badges(i):0; var b=e.querySelector('.cav-badge'); if(bd){ if(!b){ b=h('span',{class:'cav-badge'}); e.appendChild(b); } b.textContent=String(bd); } else if(b) b.remove();
    if(o.decorate) o.decorate(i,e);
    setPos(i,e); return e; }
  function render(){ L.forEach(function(i){ if(onDesk(i)) build(i); else if(els[i.uid]){ els[i.uid].remove(); delete els[i.uid]; } }); renderTray(); placeBar(); }

  /* ---------- storage tray (the open container's contents, tactile: tap or drag out) ---------- */
  function openContainer(){ for(var k=0;k<L.length;k++){ var i=L[k]; if(onDesk(i)&&def(i).storage&&(i.open||def(i).storage.alwaysOpen)&&i.trayShown) return i; } return null; }
  function renderTray(){ if(tray){ tray.remove(); tray=null; } var c=openContainer(); if(!c) return; var d=def(c), items=contents(c), r=rect(c), st=S(), a=area();
    var w=Math.min(132,a.r-a.l-4), t=h('div',{class:'fd-tray cav-panel paper'}); t.style.width='calc(var(--u)*'+w+')';
    var head=h('div',{class:'fd-th'},[h('span',{class:'cav-fill cav-ell',text:T('cav.obj.'+c.id)}),h('span',{class:'cav-dim',text:items.length+'/'+d.storage.capacity}),ui.btn({icon:'close',kind:'wax',aria:T('cav.close'),cls:'fd-x',onClick:function(){ c.trayShown=false; if(!d.storage.alwaysOpen) c.open=false; build(c); renderTray(); placeBar(); changed(); }})]); t.appendChild(head);
    var row=h('div',{class:'fd-trow cav-scroll'}); if(!items.length) row.appendChild(h('div',{class:'cav-dim cav-c fd-empty',text:T('cav.fd.empty')}));
    items.forEach(function(it){ var b=h('button',{type:'button',class:'fd-ti','aria-label':T('cav.fd.retrieve')+': '+(o.label?o.label(it):T('cav.obj.'+(it.id==='letter'?'letter':it.id)))}); var sp=A.el(key(it)); b.appendChild(sp);
      var sx,sy,mv=false; b.addEventListener('pointerdown',function(e){ sx=e.clientX; sy=e.clientY; mv=false; b.setPointerCapture(e.pointerId); });
      b.addEventListener('pointermove',function(e){ if(sx==null||mv) return; if(Math.hypot(e.clientX-sx,e.clientY-sy)>DRAG_PX){ mv=true; var lp=toVirt(e); retrieve(it,c,lp.x-size(it).w/2,lp.y-size(it).h/2,true); var el=els[it.uid]; if(el){ try{ b.releasePointerCapture(e.pointerId); }catch(x){} startDrag(it,el,e,true); } } });
      b.addEventListener('pointerup',function(){ if(!mv&&sx!=null){ retrieve(it,c,null,null,false); } sx=null; }); b.addEventListener('pointercancel',function(){ sx=null; });
      row.appendChild(b); }); t.appendChild(row); top.appendChild(t); tray=t; t.style.zIndex=8000;
    /* below the container if it fits, else above */
    var th=Math.min(70,22+(items.length?Math.max.apply(null,items.map(function(it){return size(it).h;}))+6:14)), y=r.y+r.h+2; if(y+th>a.b) y=Math.max(a.t,r.y-th-2); var x=Math.max(a.l,Math.min(a.r-w,r.x+Math.round(r.w/2-w/2)));
    t.style.left='calc(var(--u)*'+x+')'; t.style.top='calc(var(--u)*'+y+')'; }
  function retrieve(it,c,x,y,dragging){ it.in=null; var r=rect(c); var p=x==null?{x:r.x+r.w+3,y:r.y+r.h-size(it).h}:{x:x,y:y}; var q=clamp(it,p.x,p.y); it.nx=q.x/S().vw; it.ny=q.y/S().vh; it.z=++topZ; it.arrive=!dragging; render(); var e=els[it.uid]; if(e&&!dragging&&!C.reducedMotion()){ e.classList.add('is-arrive'); setTimeout(function(){ e.classList.remove('is-arrive'); },300); } C.sfx('desk.retrieve'); if(o.onRetrieve) o.onRetrieve(it,c); changed(); }
  function store(it,c,viaDrop){ var d=def(c); if(contents(c).length>=d.storage.capacity){ ui.toast(T('cav.fd.full')); return false; }
    var e=els[it.uid]; it.in=c.uid; C.sfx('desk.store'); var fin=function(){ sel=null; render(); changed(); if(o.onStore) o.onStore(it,c); };
    if(e&&!C.reducedMotion()){ var r=rect(c); e.classList.add('is-tuck'); e.style.left='calc(var(--u)*'+(r.x+Math.round(r.w/2-size(it).w/2))+')'; e.style.top='calc(var(--u)*'+(r.y+Math.round(r.h/2-size(it).h/2))+')'; setTimeout(fin,200); } else fin(); return true; }
  function accepts(c,it){ var s=def(c).storage, d=def(it); return s&&!d.storage&&(s.accepts.indexOf(d.layer)>=0||s.accepts.indexOf(d.family)>=0); }
  function containerAt(vx,vy,self){ var best=null; L.forEach(function(c){ if(c===self||!onDesk(c)||!def(c).storage||!(c.open||def(c).storage.alwaysOpen)) return; if(!accepts(c,self)) return; var r=rect(c); if(vx>=r.x&&vx<=r.x+r.w&&vy>=r.y&&vy<=r.y+r.h){ if(!best||(c.z||0)>(best.z||0)) best=c; } }); return best; }

  /* ---------- pointer handling ---------- */
  function toVirt(e){ var r=layer.getBoundingClientRect(), s=S().s; return {x:(e.clientX-r.left)/s,y:(e.clientY-r.top)/s}; }
  function wire(i,e){
    e.addEventListener('pointerdown',function(ev){ if(ev.button>0||!vis) return; if(moveFor){ return; } var lp=toVirt(ev), p=pos(i), off=anchorOff(i); down={i:i,e:e,sx:ev.clientX,sy:ev.clientY,gx:lp.x-p.x,gy:lp.y-(p.y+off),moved:false,long:false,pid:ev.pointerId};
      try{ e.setPointerCapture(ev.pointerId); }catch(x){} down.t=setTimeout(function(){ if(down&&!down.moved){ down.long=true; select(i); C.sfx('desk.select'); } },LONG_MS); });
    e.addEventListener('pointermove',function(ev){ if(!down||down.i!==i) return; if(!down.moved){ if(Math.hypot(ev.clientX-down.sx,ev.clientY-down.sy)<DRAG_PX) return; startDrag(i,e,ev,false); } dragTo(ev); });
    e.addEventListener('pointerup',function(ev){ if(!down||down.i!==i) return; clearTimeout(down.t); var d0=down; down=null; if(d0.moved){ endDrag(i,e,ev); } else if(!d0.long){ tap(i); } });
    e.addEventListener('pointercancel',function(){ if(down){ clearTimeout(down.t); if(down.moved) endDrag(down.i,down.e,null,true); down=null; } });
    e.addEventListener('keydown',function(ev){ var step=ev.shiftKey?8:2;
      if(ev.key==='Enter'||ev.key===' '){ ev.preventDefault(); tap(i); }
      else if(ev.key==='Escape'){ select(null); }
      else if({ArrowLeft:1,ArrowRight:1,ArrowUp:1,ArrowDown:1}[ev.key]&&sel===i.uid){ ev.preventDefault(); var p=pos(i), q=clamp(i,p.x+(ev.key==='ArrowRight'?step:ev.key==='ArrowLeft'?-step:0),p.y+(ev.key==='ArrowDown'?step:ev.key==='ArrowUp'?-step:0)); i.nx=q.x/S().vw; i.ny=q.y/S().vh; build(i); placeBar(); changed(); } });
  }
  function startDrag(i,e,ev,fromTray){ down=down||{}; down.i=i; down.e=e; down.moved=true; down.pid=ev.pointerId; var lp=toVirt(ev), p=pos(i), off=anchorOff(i); down.gx=fromTray?size(i).w/2:lp.x-p.x; down.gy=fromTray?size(i).h/2:lp.y-(p.y+off); clearTimeout(down.t);
    i.z=++topZ; e.style.zIndex=i.z; e.classList.add('is-drag'); e.classList.remove('is-drop'); select(null,true); C.sfx('desk.pick'); if(fromTray){ down.sx=ev.clientX; down.sy=ev.clientY; e.setPointerCapture&&0; bindTrayDrag(i,e); } }
  /* when a drag starts from the tray the original element is gone: listen on window until release */
  function bindTrayDrag(i,e){ function mv(ev){ if(ev.pointerId===down.pid) dragTo(ev); } function up(ev){ window.removeEventListener('pointermove',mv); window.removeEventListener('pointerup',up); window.removeEventListener('pointercancel',up); if(down&&down.i===i){ var d0=down; down=null; endDrag(i,e,ev,ev.type==='pointercancel'); } }
    window.addEventListener('pointermove',mv); window.addEventListener('pointerup',up); window.addEventListener('pointercancel',up); }
  function dragTo(ev){ var i=down.i, e=down.e, lp=toVirt(ev), off=anchorOff(i), q=clamp(i,lp.x-down.gx,lp.y-down.gy-off); i.nx=q.x/S().vw; i.ny=q.y/S().vh; e.style.left='calc(var(--u)*'+q.x+')'; e.style.top='calc(var(--u)*'+(q.y+off)+')';
    var c=containerAt(lp.x,lp.y,i); layer.querySelectorAll('.is-target').forEach(function(n){ n.classList.remove('is-target'); }); if(c&&els[c.uid]) els[c.uid].classList.add('is-target'); down.target=c; }
  function endDrag(i,e,ev,cancel){ e.classList.remove('is-drag'); layer.querySelectorAll('.is-target').forEach(function(n){ n.classList.remove('is-target'); }); var c=down&&down.target;
    var tgt=null; if(ev&&!cancel){ var lp=toVirt(ev); tgt=containerAt(lp.x,lp.y,i); } C.sfx('desk.drop');
    if(tgt){ store(i,tgt,true); return; }
    if(!C.reducedMotion()){ e.classList.add('is-drop'); setTimeout(function(){ e.classList.remove('is-drop'); },170); }
    changed(); renderTray(); }
  function tap(i){ var d=def(i); C.sfx('desk.tap');
    if(d.action==='toggle'){ toggleOpen(i); return; }
    if(d.action==='letter'){ i.open=!i.open; i.z=++topZ; build(i); if(i.open&&o.onRead) o.onRead(i); changed(); if(i.open) select(i); else select(null); return; }
    if(d.openable&&o.onTap){ o.onTap(i,d); return; }
    select(sel===i.uid?null:i); }
  function toggleOpen(c){ var d=def(c); if(d.storage.alwaysOpen){ c.trayShown=!c.trayShown; } else { c.open=!c.open; c.trayShown=c.open; } c.z=++topZ; if(!C.reducedMotion()&&els[c.uid]){ var e0=els[c.uid]; e0.classList.add('is-pop'); setTimeout(function(){ e0.classList.remove('is-pop'); },160); }
    build(c); renderTray(); placeBar(); C.sfx(c.open?'desk.drawer.open':'desk.drawer.close'); changed(); }

  /* ---------- selection + action bar (tap alternative to dragging) ---------- */
  function select(i,silent){ var u=i?i.uid:null; if(sel!==u){ var prev=sel&&els[sel]; if(prev) prev.classList.remove('is-sel'); sel=u; if(i&&els[u]) els[u].classList.add('is-sel'); } if(!i){ cancelMove(); } placeBar(); if(!silent&&o.caption) o.caption(i?(o.label?o.label(i):T('cav.obj.'+(i.id==='letter'?'letter':i.id))):''); }
  function placeBar(){ if(bar){ bar.remove(); bar=null; } var i=sel&&byUid(sel); if(!i||!onDesk(i)||(down&&down.moved)) return; var d=def(i), btns=[];
    if(d.openable&&d.action!=='toggle'&&d.action!=='letter') btns.push(ui.btn({icon:'right',kind:'brass',aria:T('cav.fd.open'),onClick:function(){ select(null); o.onTap&&o.onTap(i,d); }}));
    if(d.action==='toggle') btns.push(ui.btn({icon:'box',kind:'brass',aria:i.open||d.storage.alwaysOpen&&i.trayShown?T('cav.fd.closeBox'):T('cav.fd.openBox'),onClick:function(){ toggleOpen(i); }}));
    if(d.inspect||d.action==='letter') btns.push(ui.btn({icon:'eye',kind:'wood',aria:T('cav.fd.inspect'),onClick:function(){ api.inspect(i); }}));
    btns.push(ui.btn({icon:'up',kind:'wood',aria:T('cav.fd.front'),onClick:function(){ i.z=++topZ; build(i); changed(); }}));
    var cont=!d.storage&&L.filter(function(c){ return onDesk(c)&&def(c).storage&&accepts(c,i); }); if(cont&&cont.length) btns.push(ui.btn({icon:'box',kind:'wood',aria:T('cav.fd.store'),cls:'fd-store',onClick:function(){ var tgt=cont.filter(function(c){return c.open||def(c).storage.alwaysOpen;})[0]||cont[0]; if(!(tgt.open||def(tgt).storage.alwaysOpen)){ tgt.open=true; tgt.trayShown=true; build(tgt); } store(i,tgt); }}));
    btns.push(ui.btn({icon:'move',kind:'wood',aria:T('cav.fd.move'),onClick:function(){ startMove(i); }}));
    bar=h('div',{class:'fd-bar'},btns); top.appendChild(bar); bar.style.zIndex=9000;
    var r=rect(i), a=area(), bw=btns.length*26+6, x=Math.max(a.l,Math.min(a.r-bw,r.x+Math.round(r.w/2-bw/2))), y=r.y-25; if(y<a.t) y=r.y+r.h+2; bar.style.left='calc(var(--u)*'+x+')'; bar.style.top='calc(var(--u)*'+y+')'; }
  function startMove(i){ moveFor=i.uid; if(bar){ bar.remove(); bar=null; } layer.classList.add('fd-moving'); catcher=h('div',{class:'fd-catch'}); top.appendChild(catcher); catcher.style.zIndex=8500;
    hint=ui.panel('plaque',[h('span',{text:T('cav.fd.moveHint')})],'fd-hint'); top.appendChild(hint); hint.style.zIndex=9100;
    catcher.addEventListener('pointerup',function(ev){ var lp=toVirt(ev), sz=size(i), q=clamp(i,lp.x-sz.w/2,lp.y-sz.h/2); i.nx=q.x/S().vw; i.ny=q.y/S().vh; i.z=++topZ; cancelMove(); build(i); if(!C.reducedMotion()){ var e=els[i.uid]; e.classList.add('is-drop'); setTimeout(function(){ e.classList.remove('is-drop'); },170); } changed(); select(i,true); C.sfx('desk.drop'); }); }
  function cancelMove(){ moveFor=null; layer.classList.remove('fd-moving'); if(catcher){ catcher.remove(); catcher=null; } if(hint){ hint.remove(); hint=null; } }
  function outside(ev){ var t=ev.target; if(t&&t.closest&&(t.closest('.fd-o')||t.closest('.fd-bar')||t.closest('.fd-tray')||t.closest('.cav-overlay'))) return; if(moveFor) return; if(sel){ select(null); } }
  document.addEventListener('pointerdown',outside,true); offs.push(function(){ document.removeEventListener('pointerdown',outside,true); });
  function changed(){ if(o.onChange) o.onChange(L); }

  /* ---------- inspection: bigger, still pixel-crisp (integer multiples of the UI scale) ---------- */
  function inspect(i){ if(o.onInspect&&o.onInspect(i,def(i))===true) return; var d=def(i), st=S(), body, ov;
    if(i.id==='letter'){ var dim={w:Math.min(200,st.vw-24),h:Math.min(130,st.vh-44)}, k=A.letterSheet(i.kind||'ordinary',dim.w,dim.h), tx=O.sheetText(i.kind||'ordinary',dim.w,dim.h), dat=i.data||{};
      var txt=h('div',{class:'fd-lt cav-scroll'+(tx.dark?' dark':'')},[h('div',{class:'ci-name',text:dat.title||''}),h('div',{class:'cav-dim',text:dat.from||''}),h('div',{class:'fd-lbody',text:dat.body||''})]);
      txt.style.cssText='left:calc(var(--u)*'+tx.x+');top:calc(var(--u)*'+tx.y+');width:calc(var(--u)*'+tx.w+');height:calc(var(--u)*'+tx.h+')';
      body=h('div',{class:'fd-sheet'},[A.el(k),txt]); body.style.width='calc(var(--u)*'+dim.w+')'; body.style.height='calc(var(--u)*'+dim.h+')'; }
    else { var k2=key(i), sz=A.size(k2), mult=Math.max(2,Math.min(5,Math.floor(Math.min((st.vh-60)/sz.h,(st.vw-40)/sz.w)))), sp=A.el(k2); sp.style.width='calc(var(--u)*'+(sz.w*mult)+')'; sp.style.height='calc(var(--u)*'+(sz.h*mult)+')';
      body=h('div',{class:'fd-insp'},[h('div',{class:'fd-insp-spr'},[sp]),h('div',{class:'cav-dim cav-c',text:(i.data&&i.data.note)||T('cav.fd.note.'+i.id)})]); }
    ov=ui.overlay.open({id:'fd.inspect',title:o.label?o.label(i):T('cav.obj.'+(i.id==='letter'?'letter':i.id)),content:body,kind:i.id==='letter'?'wood':'leather',icon:'eye'}); }

  var api={ el:layer, insts:L, render:render, select:function(u){ select(u?byUid(u):null); }, selected:function(){ return sel; }, inspect:inspect, topZ:function(){ return topZ; },
    add:function(inst,opt){ L.push(inst); inst.z=++topZ; render(); if(opt&&opt.arrive&&!C.reducedMotion()&&els[inst.uid]){ var e=els[inst.uid]; e.classList.add('is-arrive'); setTimeout(function(){ e.classList.remove('is-arrive'); },320); } changed(); return inst; },
    remove:function(u){ var k=L.findIndex?L.findIndex(function(i){return i.uid===u;}):-1; if(k>=0) L.splice(k,1); if(els[u]){ els[u].remove(); delete els[u]; } renderTray(); changed(); },
    front:function(u){ var i=byUid(u); if(i){ i.z=++topZ; build(i); } },
    relayout:function(){ L.forEach(function(i){ if(onDesk(i)&&els[i.uid]){ var q=i.nx!=null?clamp(i,pos(i).x,pos(i).y):null; if(q){ i.nx=q.x/S().vw; i.ny=q.y/S().vh; } setPos(i,els[i.uid]); } }); renderTray(); placeBar(); },
    refreshSprites:function(c){ if(c) ctx=c; L.forEach(function(i){ if(onDesk(i)) build(i); }); },
    top:top, setVisible:function(v){ vis=v; layer.style.display=v?'':'none'; top.style.display=v?'':'none'; }, acquire:function(inst){ return api.add(inst,{arrive:true}); },
    reset:function(){ L.forEach(function(i){ i.nx=null; i.ny=null; i.z=null; i.open=false; i.in=i.homeIn||null; }); topZ=1000; render(); changed(); },
    destroy:function(){ offs.forEach(function(f){ f(); }); layer.remove(); top.remove(); } };
  render(); return api; } };
})();
