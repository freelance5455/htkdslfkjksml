/* CAV.album — the card binder (collection) + deck editor + deck statistics. Presentation only: it reports onAdd/onRemove, the host decides
   whether the deck allows it and re-renders with update().
   props: {cards:[{id,name,description,cost,rarity,type,arch,motif,chips}], owned:{id:n}, deck:{id:n}, seen:{id:bool}, deckRange:{min,max}, tab, onAdd(id), onRemove(id), onClose()} */
(function(){
var C=window.CAV, h=C.h, A=C.art, ui=C.ui, T=C.t;
var RAR=['common','rare','epic','legendary'];
C.album={ create:function(props){ var P=Object.assign({cards:[],owned:{},deck:{},seen:{},deckRange:{min:5,max:30},tab:'collection'},props), S={tab:P.tab,rar:null,arch:null,page:0,sel:null};
  var el=h('div',{class:'cav-book al'}), spread=null, L=h('div',{class:'bk-page al-page'}), R=h('div',{class:'bk-page al-page'}), tabs=h('div',{class:'bk-tabs'});
  function size(){ var st=C.stage.get(); return {w:Math.min(400,st.vw-Math.max(6,st.safe.l+st.safe.r)-22), h:Math.min(224,st.vh-Math.max(6,st.safe.t+st.safe.b)-6)}; }
  function place(e,x,y,w,hh){ e.style.cssText='left:calc(var(--u)*'+x+');top:calc(var(--u)*'+y+');width:calc(var(--u)*'+w+');height:calc(var(--u)*'+hh+')'; }
  function layout(){ var s=size(); S.size=s; el.style.width='calc(var(--u)*'+s.w+')'; el.style.height='calc(var(--u)*'+s.h+')'; if(spread) spread.remove(); spread=A.el(A.bookSpread(s.w,s.h,'binder'),'bk-spread'); el.insertBefore(spread,el.firstChild);
    var mid=Math.floor(s.w/2), m=8; place(L,m,m,mid-m-9,s.h-2*m); place(R,mid+9,m,s.w-m-(mid+9),s.h-2*m); }
  function deckCount(){ var n=0; for(var k in P.deck) n+=P.deck[k]; return n; }
  function filtered(){ return P.cards.filter(function(c){ return (!S.rar||c.rarity===S.rar)&&(!S.arch||(S.arch==='neutral'?!(c.arch&&c.arch.length):(c.arch&&c.arch.indexOf(S.arch)>=0))); }); }
  function openInspect(c){ var seen=P.seen[c.id]!==false&&(P.seen[c.id]||P.owned[c.id]>0), own=P.owned[c.id]||0, inDeck=P.deck[c.id]||0; if(!seen) return;
    var ov, can=own>inDeck, full=deckCount()>=P.deckRange.max;
    var render=function(){ own=P.owned[c.id]||0; inDeck=P.deck[c.id]||0; can=own>inDeck; full=deckCount()>=P.deckRange.max; wrap.innerHTML=''; wrap.appendChild(C.cards.inspector({card:Object.assign({},c,{count:null}),description:c.description,note:full&&can?T('cav.album.cards',{n:deckCount()}):'',
      actions:[{label:T('cav.album.add')+' ('+inDeck+'/'+own+')',icon:'plus',kind:'forest',disabled:!can||full||!P.onAdd,onClick:function(){ P.onAdd(c.id); setTimeout(render,0); }},{label:T('cav.album.remove'),icon:'minus',kind:'wax',disabled:inDeck<1||!P.onRemove,onClick:function(){ P.onRemove(c.id); setTimeout(render,0); }}]})); };
    var wrap=h('div',{}); ov=ui.overlay.open({id:'album.inspect',title:c.name,content:wrap,kind:'wood',onClose:function(){ api.update({}); }}); render(); S.inspectRender=render; }
  function pocket(c){ var seen=P.seen[c.id], own=P.owned[c.id]||0, locked=!seen&&own<1; return C.cards.thumb({name:c.name,rarity:c.rarity,arch:c.arch,motif:c.motif,locked:locked,count:own,inDeck:(P.deck[c.id]||0)>0,dim:!locked&&own<1,onTap:function(){ openInspect(c); }}); }
  function filters(){ var row=h('div',{class:'al-filters'}), cyc=function(list,cur){ var i=list.indexOf(cur); return list[(i+1)%list.length]; };
    var rl=[null].concat(RAR), al=[null].concat(C.archetypes.slice(0,6).map(function(a){return a.id;})); var ar=S.arch&&C.archetypes.filter(function(a){return a.id===S.arch;})[0];
    var br=h('button',{type:'button',class:'cav-btn al-f '+(S.rar?'':'wood'),'aria-label':T('cav.album.rarity')+': '+(S.rar?T('cav.rarity.'+S.rar):T('cav.album.all'))},[S.rar?rarGem(S.rar):null,h('span',{text:S.rar?T('cav.rarity.'+S.rar):T('cav.album.all')})]);
    br.addEventListener('click',function(){ S.rar=cyc(rl,S.rar); S.page=0; render(); });
    var ba=h('button',{type:'button',class:'cav-btn al-f '+(S.arch?'':'wood'),'aria-label':T('cav.album.arch')+': '+(S.arch?T('cav.arch.'+S.arch):T('cav.album.all'))},[ar?A.el(A.emblem(ar.emblem,ar.pri,ar.sec)):null,h('span',{text:S.arch?T('cav.arch.'+S.arch):T('cav.album.all')})]);
    ba.addEventListener('click',function(){ S.arch=cyc(al,S.arch); S.page=0; render(); });
    row.appendChild(br); row.appendChild(ba); return row; }
  function rarGem(r){ var k='cav.gem.'+r; if(!A.has(k)) A.define(k,function(){ var g={common:C.pal.silver,rare:C.pal.brass,epic:C.pal.wax,legendary:C.pal.glow}[r], p=new C.Px(9,9); p.shadeDisc(4.5,4.5,3.6,g,{dither:false}); return p.outline(C.pal.K[0]); }); return A.el(k); }
  function renderCollection(){ var list=filtered(), per=24, pages=Math.max(1,Math.ceil(list.length/per)); S.page=Math.min(S.page,pages-1); var slice=list.slice(S.page*per,S.page*per+per);
    var head=function(t,extra){ return h('div',{class:'cat-head'},[h('span',{class:'cav-up',text:t}),extra||null]); };
    L.appendChild(head(T('cav.album.title'),h('span',{class:'cav-dim',text:list.filter(function(c){return P.owned[c.id]>0}).length+'/'+P.cards.length}))); R.appendChild(head(T('cav.album.collection'),h('span',{class:'cav-dim',text:T('cav.cat.page',{a:S.page+1,b:pages})})));
    var gl=h('div',{class:'al-grid'}), gr=h('div',{class:'al-grid'}); slice.slice(0,12).forEach(function(c){ gl.appendChild(pocket(c)); }); slice.slice(12).forEach(function(c){ gr.appendChild(pocket(c)); });
    L.appendChild(gl); R.appendChild(gr); L.appendChild(filters());
    R.appendChild(h('div',{class:'cat-foot'},[ui.btn({icon:'left',kind:'wood',aria:T('cav.back'),disabled:S.page===0,onClick:function(){ S.page--; render(true); }}),h('span',{class:'cav-fill cav-c cav-dim cav-ell',text:T('cav.album.owned',{n:P.cards.reduce(function(a,c){return a+(P.owned[c.id]||0)},0)})}),ui.btn({icon:'right',kind:'wood',aria:T('cav.next'),disabled:S.page>=pages-1,onClick:function(){ S.page++; render(true); }})])); }
  function renderDeck(){ var rows=P.cards.filter(function(c){ return P.deck[c.id]>0; }).sort(function(a,b){ return a.cost-b.cost||a.name.localeCompare(b.name); }), n=deckCount();
    L.appendChild(h('div',{class:'cat-head'},[h('span',{class:'cav-up',text:T('cav.deck.title')}),h('span',{class:(n<P.deckRange.min||n>P.deckRange.max)?'cav-wax':'cav-dim',text:n+'/'+P.deckRange.max})]));
    var list=h('div',{class:'al-deck cav-scroll'}); rows.forEach(function(c){ var s=C.cards.strip({name:c.name,cost:c.cost,rarity:c.rarity,chips:c.chips,enchant:c.enchant,onTap:function(){ openInspect(c); }}); var n2=h('span',{class:'al-n',text:'×'+P.deck[c.id]}); var r=h('div',{class:'al-drow'},[s,n2]); list.appendChild(r); }); L.appendChild(list);
    /* stats: cost curve, types, rarity */
    R.appendChild(h('div',{class:'cat-head'},[h('span',{class:'cav-up',text:T('cav.album.stats')}),h('span',{class:'cav-dim',text:T('cav.album.cards',{n:n})})]));
    var curve=[0,0,0,0,0,0]; rows.forEach(function(c){ curve[Math.min(5,c.cost)]+=P.deck[c.id]; }); var mx=Math.max(1,Math.max.apply(null,curve));
    var bars=h('div',{class:'al-curve',role:'img','aria-label':T('cav.album.cost')}); curve.forEach(function(v,i){ bars.appendChild(h('div',{class:'al-col'},[h('span',{class:'al-v',text:String(v)}),h('span',{class:'al-bar',style:'height:calc(var(--u)*'+Math.round(v/mx*36)+')'}),h('span',{class:'al-x',text:i===5?'5+':String(i)})])); });
    R.appendChild(h('div',{class:'al-statbox'},[h('div',{class:'cav-dim',text:T('cav.album.cost')}),bars]));
    var by={}, ty={}; rows.forEach(function(c){ by[c.rarity]=(by[c.rarity]||0)+P.deck[c.id]; ty[c.type]=(ty[c.type]||0)+P.deck[c.id]; });
    var chips=h('div',{class:'al-chips'}); RAR.forEach(function(r){ if(by[r]) chips.appendChild(h('span',{class:'al-chip'},[rarGem(r),h('span',{text:String(by[r])})])); }); Object.keys(ty).forEach(function(t){ chips.appendChild(h('span',{class:'al-chip'},[h('span',{text:T('cav.typeShort.'+t)+' '+ty[t]})])); });
    R.appendChild(chips); }
  function render(flip){ L.innerHTML=''; R.innerHTML=''; if(S.tab==='collection') renderCollection(); else renderDeck();
    tabs.innerHTML=''; [['collection','cav.album.collection','forest','book'],['deck','cav.album.deck','brass','draw']].forEach(function(t){ var on=S.tab===t[0], b=h('button',{type:'button',class:'bk-tab'+(on?' on':''),'aria-label':T(t[1]),'aria-selected':on?'true':'false'}); b.appendChild(A.el(A.tab(t[2],on))); b.appendChild(h('span',{class:'bk-tabic'},[ui.icon(t[3])])); b.addEventListener('click',function(){ S.tab=t[0]; C.sfx('book.page'); render(true); }); tabs.appendChild(b); });
    if(flip&&!C.reducedMotion()){ R.classList.remove('bk-flip'); void R.offsetWidth; R.classList.add('bk-flip'); } }
  var close=ui.btn({icon:'close',kind:'wax',aria:T('cav.close'),cls:'bk-close',onClick:function(){ if(P.onClose) P.onClose(); }});
  el.appendChild(L); el.appendChild(R); el.appendChild(tabs); el.appendChild(close); layout(); render();
  var unsub=C.stage.on('resize',function(){ layout(); render(); });
  var api={ el:el, update:function(p){ Object.assign(P,p); render(); if(S.inspectRender) try{ S.inspectRender(); }catch(e){} }, destroy:function(){ unsub(); el.remove(); } }; return api; },
 open:function(props){ var al, ov, orig=props.onClose; props=Object.assign({},props,{onClose:function(){ ov.close('x'); if(orig) orig(); }}); al=C.album.create(props); ov=ui.overlay.open({id:'album',bare:true,content:al.el,onClose:function(){ al.destroy(); }}); al.overlay=ov; return al; } };
})();
