/* CAV.matchUI — in-match presentation on the desk: opponent plate, energy, piles, hand strips, card inspection, results.
   attach(ws, handlers) -> view {setState(), detach()}.  The host owns ALL rules; this only draws what it is told.
   state: {opponent:{name,portrait,diff}, energy, maxEnergy, drawCount, discardCount, status, statusTone, thinking, canEndTurn, selected:uid|null, targeting:bool,
           hand:[{uid, def:{id,name,description,cost,rarity,type,arch,motif,chips}, enchant, playable, why}]} */
(function(){
var C=window.CAV, h=C.h, A=C.art, ui=C.ui, T=C.t;
function portraitFrame(id){ var k='cav.portrait.full.'+id; return C.portraitKey(id); }
C.matchUI={
 attach:function(ws,H){ var S={hand:[],energy:0,maxEnergy:3,selected:null}, rails=ws.rails, side=C.settings.get('hand')==='left';
   ws.setState({mode:'match'}); var handRail=side?rails.left:rails.right, infoRail=side?rails.right:rails.left; handRail.classList.add('ws-match-right'); infoRail.classList.add('ws-match-left'); [rails.left,rails.right].forEach(function(r){ r.classList.add('single'); });
   function render(){ infoRail.innerHTML=''; handRail.innerHTML='';
     var sel=S.hand.filter(function(c){ return c.uid===S.selected; })[0];
     /* ---- hand rail: energy + piles + strips ---- */
     var en=h('div',{class:'m-energy','aria-label':T('cav.match.energy')+' '+S.energy+'/'+S.maxEnergy}); for(var i=0;i<S.maxEnergy;i++){ var ic=ui.icon('energy'); if(i>=S.energy) ic.style.opacity='.25'; en.appendChild(ic); }
     var piles=h('div',{class:'m-pile'},[A.el(A.cardBack(12,16)),h('span',{text:String(S.drawCount||0),'aria-label':T('cav.match.draw')}),A.el(A.cardBack(12,16),'m-disc'),h('span',{text:String(S.discardCount||0),'aria-label':T('cav.match.discard')})]);
     handRail.appendChild(ui.panel('wood',[h('div',{class:'cav-row',style:'justify-content:space-between;gap:calc(var(--u)*2)'},[en,piles])],'m-hdr'));
     var hand=h('div',{class:'m-hand'}); S.hand.forEach(function(c){ var d=c.def; hand.appendChild(C.cards.strip({name:d.name,cost:d.cost,rarity:d.rarity,chips:d.chips,enchant:c.enchant,selected:c.uid===S.selected,disabled:!c.playable,why:c.why,onTap:function(){ if(H.onSelect) H.onSelect(c.uid); }})); });
     if(!S.hand.length) hand.appendChild(h('div',{class:'cav-dim cav-c',text:'—'})); handRail.appendChild(hand);
     /* ---- info rail ---- */
     if(sel&&!S.targeting){ var d2=sel.def, box=h('div',{class:'m-sel'}); var cd=C.cards.create(Object.assign({},d2,{enchant:sel.enchant,onTap:function(){ if(H.onInspect) H.onInspect(sel); }})); box.appendChild(cd);
       box.appendChild(h('div',{class:'m-btns'},[ui.btn({label:T('cav.match.play'),kind:'forest',disabled:!sel.playable,onClick:function(){ if(H.onPlay) H.onPlay(sel.uid); }}),ui.btn({icon:'close',kind:'wood',aria:T('cav.match.cancel'),onClick:function(){ if(H.onSelect) H.onSelect(null); }})]));
       if(!sel.playable&&sel.why) box.appendChild(h('div',{class:'m-status cav-wax',text:sel.why})); infoRail.appendChild(box); }
     else { var o=S.opponent||{name:'?',portrait:'clerk',diff:1};
       var pf=ui.panel('ink',[h('div',{class:'m-opp'},[A.el(C.portraitKey(o.portrait)),h('div',{class:'m-name'},[h('div',{text:o.name,class:'m-nm'}),h('div',{class:'bk-meta'},[(function(){ var w=h('span',{class:'bk-stars'}); for(var i=0;i<4;i++){ var s=ui.icon('star'); if(i>=o.diff) s.style.opacity='.25'; w.appendChild(s); } return w; })()])])])],'');
       infoRail.appendChild(pf);
       infoRail.appendChild(ui.panel('plaque',[h('div',{class:'m-status',text:S.thinking?T('cav.match.thinking'):(S.status||'')})],'m-st '+(S.statusTone||'')));
       if(S.targeting) infoRail.appendChild(ui.btn({label:T('cav.match.cancel'),kind:'wax',icon:'close',onClick:function(){ if(H.onCancel) H.onCancel(); }}));
       else infoRail.appendChild(ui.btn({label:T('cav.match.endTurn'),kind:'brass',icon:'right',disabled:!S.canEndTurn,onClick:function(){ if(H.onEndTurn) H.onEndTurn(); }}));
       infoRail.appendChild(h('div',{class:'cav-row',style:'gap:calc(var(--u)*2)'},[ui.btn({icon:'gear',kind:'wood',aria:T('cav.match.menu'),onClick:function(){ if(H.onMenu) H.onMenu(); }}),ui.btn({label:T('cav.match.resign'),kind:'wood',cls:'cav-fill',onClick:function(){ if(H.onResign) H.onResign(); }})])); } }
   var view={ setState:function(p){ Object.assign(S,p); render(); }, state:function(){ return S; }, detach:function(){ unsub(); rails.left.classList.remove('single','ws-match-left','ws-match-right'); rails.right.classList.remove('single','ws-match-left','ws-match-right'); ws.setState({mode:'desk'}); } };
   var unsub=C.stage.on('resize',function(){ handRail.classList.add('ws-match-right'); infoRail.classList.add('ws-match-left'); [rails.left,rails.right].forEach(function(r){ r.classList.add('single'); }); render(); });
   render(); return view; },
 /* opponent introduction */
 intro:function(o){ var op=o.opponent, body=h('div',{class:'mi-intro'},[ui.panel('ink',[A.el(C.portraitKey(op.portrait))],'mi-pt'),h('div',{class:'mi-tx'},[h('div',{class:'cav-t2 cav-brass',text:op.name}),h('div',{class:'cav-dim',text:op.title||''}),h('div',{class:'bk-meta'},[T('cav.book.diff')+' ',(function(){ var w=h('span',{class:'bk-stars'}); for(var i=0;i<4;i++){ var s=ui.icon('star'); if(i>=op.diff) s.style.opacity='.25'; w.appendChild(s); } return w; })()]),h('div',{class:'bk-meta'},[T('cav.book.reward')+' ',ui.icon('coin'),h('span',{text:String(op.reward)})]),h('div',{class:'ci-actions'},[ui.btn({label:T('cav.obj.start'),kind:'forest',big:true,icon:'check',cls:'bo-primary',onClick:function(){ ov.close('go'); if(o.onStart) o.onStart(); }}),ui.btn({label:T('cav.cancel'),kind:'wood',onClick:function(){ ov.close('x'); if(o.onCancel) o.onCancel(); }})])])]);
   var ov=ui.overlay.open({id:'intro',title:T('cav.obj.start'),content:body,kind:'wood',icon:'star',noClose:true,modal:true}); return ov; },
 /* match results: o={won, draw, opponent, gain, onContinue} */
 result:function(o){ var tone=o.won?'forest':'wax', body=h('div',{class:'mi-res'},[h('div',{class:'mi-stamp '+tone},[A.el(A.stampFrame(110,28,tone)),h('span',{class:'cav-t2',text:(o.won?T('cav.ledger.win'):(o.draw?T('cav.ledger.draw'):T('cav.ledger.loss')))})]),
   h('div',{class:'cav-row',style:'gap:calc(var(--u)*4)'},[A.el(C.portraitKey(o.opponent.portrait)),h('div',{},[h('div',{text:o.opponent.name}),h('div',{class:'bk-meta'},[ui.icon('coin'),h('span',{text:'+'+o.gain})])])]),
   ui.btn({label:T('cav.match.back'),kind:'brass',big:true,icon:'right',cls:'bo-primary',onClick:function(){ ov.close('ok'); if(o.onContinue) o.onContinue(); }})]);
   var ov=ui.overlay.open({id:'result',title:o.won?T('cav.match.won'):T('cav.match.lost'),content:body,kind:'leather',noClose:true,modal:true}); return ov; }
};
})();
