/* CAV.delivery + CAV.booster — parcels arriving the morning after an order, and the booster-pack opening ceremony.
   Visual only: contents are ALWAYS supplied by the engine up-front; nothing here rolls, weights or hides outcomes (no near-miss effects).
   Every step is tap/click, skippable ("Reveal all", "Skip"), and collapses to instant swaps when reduced-motion is on. */
(function(){
var C=window.CAV, h=C.h, A=C.art, ui=C.ui, T=C.t;

/* ============ BOOSTER OPENING ============
   C.booster.open({packs:[{arch, cards:[{card:<id>|def, isNew}]}], resolve:{card(id)->cardDef}, onPackDone(i,cards), onDone(), onInspect}) */
C.booster={ open:function(o){ var packs=o.packs||[], pi=0, ov, body=h('div',{class:'bo'}), S={phase:'sealed',revealed:[],cur:0}, defs=[];
  function def(c){ return typeof c.card==='string'?(o.resolve.card(c.card)||{id:c.card,name:c.card,rarity:'common'}):c.card; }
  function start(){ var pk=packs[pi]; defs=pk.cards.map(def); S={phase:'sealed',revealed:defs.map(function(){return false;}),cur:0,flip:false}; render(); }
  function allRevealed(){ return S.revealed.every(Boolean); }
  function nextIdx(){ for(var i=0;i<S.revealed.length;i++) if(!S.revealed[i]) return i; return -1; }
  function reveal(i,instant){ if(S.revealed[i]) return; S.revealed[i]=true; C.sfx('card.reveal',{rarity:defs[i].rarity}); }
  function tear(){ if(S.phase!=='sealed') return; S.phase='open'; C.sfx('pack.tear'); S.tearAnim=!C.reducedMotion(); render(); setTimeout(function(){ S.tearAnim=false; },C.reducedMotion()?0:260); }
  function finishPack(){ if(o.onPackDone) o.onPackDone(pi,packs[pi].cards); if(pi<packs.length-1){ pi++; start(); } else { ov.close('done'); if(o.onDone) o.onDone(); } }
  function flipCurrent(){ var i=S.cur; if(S.revealed[i]) return; var card=body.querySelector('.bo-main .cav-card, .bo-main .bo-back'); if(C.reducedMotion()||!card){ reveal(i); advance(); render(); return; }
    card.classList.add('is-flipping'); setTimeout(function(){ reveal(i); render(true); },110); }
  function advance(){ var n=nextIdx(); if(n>=0) S.cur=n; }
  function revealAll(){ S.revealed=S.revealed.map(function(){ return true; }); S.cur=0; render(); }
  function cardEl(i){ var d=defs[i]; return C.cards.create({id:d.id,name:d.name,cost:d.cost,rarity:d.rarity,type:d.type,arch:d.arch,motif:d.motif,chips:d.chips,isNew:packs[pi].cards[i].isNew}); }
  function render(flipIn){ body.innerHTML=''; var pk=packs[pi], ar=C.archetype(pk.arch), title=T('cav.boost.title');
    var head=h('div',{class:'bo-head'},[h('span',{class:'cav-up',text:(ar?T('cav.arch.'+ar.id)+' · ':'')+title}),packs.length>1?h('span',{class:'cav-dim',text:T('cav.boost.pack',{a:pi+1,b:packs.length})}):null]); body.appendChild(head);
    if(S.phase==='sealed'){ var pack=A.el(A.pack(pk.arch,'sealed'),'bo-pack'); var btn=h('button',{type:'button',class:'bo-packbtn','aria-label':T('cav.boost.tear')},[pack]); btn.addEventListener('click',tear);
      body.appendChild(h('div',{class:'bo-stage'},[btn,h('div',{class:'ci-actions'},[ui.btn({label:T('cav.boost.tear'),big:true,icon:'star',onClick:tear,cls:'bo-primary'}),ui.btn({label:T('cav.skip'),kind:'wood',onClick:function(){ tear(); revealAll(); }})])]));
      return; }
    var done=allRevealed(), i=S.cur, d=defs[i], revealed=S.revealed[i];
    var main=h('div',{class:'bo-main'+(flipIn?' flip-in':'')}); 
    if(revealed){ var c=cardEl(i); c.classList.add('bo-face'); main.appendChild(c); main.addEventListener('click',function(){ inspect(i); }); }
    else { var back=h('button',{type:'button',class:'bo-back','aria-label':T('cav.boost.reveal')},[A.el(A.cardBack(72,104))]); back.addEventListener('click',flipCurrent); main.appendChild(back); }
    var tray=h('div',{class:'bo-tray'}); defs.forEach(function(dd,k){ var rv=S.revealed[k], t=C.cards.thumb({name:dd.name,rarity:dd.rarity,arch:dd.arch,motif:dd.motif,locked:!rv,selected:k===S.cur,isNew:rv&&packs[pi].cards[k].isNew,onTap:function(){ S.cur=k; render(); }});
      if(!rv){ t.firstChild.remove(); t.insertBefore(A.el(A.cardBack(24,34),'ct-face'),t.firstChild); } tray.appendChild(t); });
    var info=h('div',{class:'bo-info'}); if(revealed){ info.appendChild(h('div',{class:'bo-rar r-'+d.rarity,text:T('cav.rarity.'+d.rarity)})); if(packs[pi].cards[i].isNew) info.appendChild(h('div',{class:'bo-new',text:T('cav.boost.new')})); info.appendChild(h('div',{class:'bo-nm',text:d.name})); }
    else info.appendChild(h('div',{class:'cav-dim',text:T('cav.boost.tapReveal')}));
    var acts=h('div',{class:'ci-actions'}); if(!done){ acts.appendChild(ui.btn({label:T('cav.boost.revealAll'),icon:'eye',onClick:revealAll,cls:'bo-primary'})); acts.appendChild(ui.btn({label:T('cav.skip'),kind:'wood',onClick:function(){ revealAll(); }})); if(revealed&&nextIdx()>=0) acts.insertBefore(ui.btn({label:T('cav.boost.next'),kind:'forest',icon:'right',onClick:function(){ advance(); render(); }}),acts.firstChild); }
    else { acts.appendChild(ui.btn({label:pi<packs.length-1?T('cav.boost.next'):T('cav.continue'),kind:'forest',icon:'check',big:true,onClick:finishPack,cls:'bo-primary'})); }
    var side=h('div',{class:'bo-side'},[tray,done?h('div',{class:'cav-brass',text:T('cav.boost.added')}):null,info,acts]);
    body.appendChild(h('div',{class:'bo-row'},[main,side])); }
  function inspect(i){ var d=defs[i]; var ins=C.cards.inspector({card:{id:d.id,name:d.name,cost:d.cost,rarity:d.rarity,type:d.type,arch:d.arch,motif:d.motif,chips:d.chips},description:d.description}); ui.overlay.open({id:'booster.inspect',title:d.name,content:ins,kind:'wood'}); if(o.onInspect) o.onInspect(d); }
  ov=ui.overlay.open({id:'booster',title:'',bare:false,content:body,kind:'felt'===0?'wood':'leather',noClose:true,modal:true,cls:'bo-panel',headerExtra:null,icon:'parcel'});
  ov.setTitle(T('cav.boost.title')); start(); return ov; } };

/* ============ DELIVERY (parcels) ============
   C.delivery.open({parcels:[{id,items:[{kind:'booster'|'card'|'ench',arch|card|ench,n}]}], resolve:{card,ench}, onOpenParcel(id), onOpenPack(parcelId,itemIndex)->{cards:[{card,isNew}]}|undefined, onTakeAll(id), onClose()}) */
C.delivery={ open:function(o){ var parcels=o.parcels.slice(), S={sel:0,opened:{},packsOpened:{}}, ov, body=h('div',{class:'dl'});
  function nm(it){ if(it.kind==='booster') return T('cav.arch.'+it.arch)+' · '+T('cav.boost.title'); if(it.kind==='card') return (o.resolve.card(it.card)||{}).name; return (o.resolve.ench(it.ench)||{}).name; }
  function itemEl(p,it,idx){ var key=p.id+':'+idx, used=S.packsOpened[key]; var w=h('div',{class:'dl-item'+(used?' is-used':'')}), art;
    if(it.kind==='booster') art=A.el(A.pack(it.arch,used?'open':'sealed')); else if(it.kind==='card'){ var d=o.resolve.card(it.card)||{}; art=A.el(A.cardThumb({rarity:d.rarity,arch:d.arch,motif:d.motif})); } else art=h('span',{class:'cat-seal'},[A.el(A.seal(it.ench))]);
    w.appendChild(h('div',{class:'dl-slot'},[art])); w.appendChild(h('div',{class:'dl-nm cav-ell',text:nm(it)}));
    if(it.kind==='booster'&&!used) w.appendChild(ui.btn({label:T('cav.parcel.openPack'),icon:'star',onClick:function(){ var r=o.onOpenPack&&o.onOpenPack(p.id,idx); S.packsOpened[key]=true; if(r&&r.cards) C.booster.open({packs:[{arch:it.arch,cards:r.cards}],resolve:o.resolve,onDone:function(){ render(); }}); else render(); }}));
    return w; }
  function render(){ body.innerHTML=''; if(!parcels.length){ body.appendChild(h('div',{class:'bk-empty',text:T('cav.desk.noParcels')})); return; }
    var p=parcels[S.sel], open=!!S.opened[p.id];
    var list=h('div',{class:'dl-list'}); parcels.forEach(function(q,i){ var b=h('button',{type:'button',class:'dl-pick'+(i===S.sel?' is-sel':''),'aria-label':T('cav.parcel.title')+' '+(i+1)},[A.el(A.parcel(S.opened[q.id]?'open':'closed',i+1))]); b.addEventListener('click',function(){ S.sel=i; render(); }); list.appendChild(b); });
    var center=h('div',{class:'dl-center'}); var big=A.el(A.parcel(open?'open':'closed',S.sel+1,open?44:60,open?34:46),'dl-big'+(open?' is-open':'')); center.appendChild(big);
    center.appendChild(h('div',{class:'cav-c cav-dim',text:T('cav.parcel.from')+' · '+T('cav.parcel.items',{n:p.items.length})}));
    if(!open) center.appendChild(ui.btn({label:T('cav.parcel.open'),big:true,icon:'star',cls:'bo-primary',onClick:function(){ S.opened[p.id]=true; C.sfx('parcel.open'); if(o.onOpenParcel) o.onOpenParcel(p.id); render(); if(!C.reducedMotion()){ var b=body.querySelector('.dl-big'); if(b){ b.classList.add('is-bursting'); } } }}));
    var items=h('div',{class:'dl-items'}); if(open) p.items.forEach(function(it,i){ items.appendChild(itemEl(p,it,i)); });
    if(open){ var rest=p.items.every(function(it,i){ return it.kind!=='booster'||S.packsOpened[p.id+':'+i]; }); center.appendChild(ui.btn({label:T('cav.parcel.takeAll'),kind:'forest',icon:'check',disabled:false,onClick:function(){ if(o.onTakeAll) o.onTakeAll(p.id); parcels.splice(S.sel,1); S.sel=0; if(!parcels.length){ ov.close('done'); } else render(); }})); }
    body.appendChild(h('div',{class:'dl-row'},[parcels.length>1?list:null,center,items])); }
  ov=ui.overlay.open({id:'delivery',title:T('cav.parcel.title'),content:body,kind:'wood',icon:'parcel',cls:'dl-panel',onClose:function(){ if(o.onClose) o.onClose(); }}); render(); return ov; } };
})();
