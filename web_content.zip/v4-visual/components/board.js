/* CAV.board — top-down chessboard presenter. Pure view: the host owns the position, legality and turn.
   Square index = V3H convention: 0 = a8 ... 63 = h1 (row*8+file, row 0 = rank 8). Pieces: 'PNBRQK' white, 'pnbrqk' black, null empty. */
(function(){
var C=window.CAV, h=C.h, A=C.art, ui=C.ui, T=C.t;
var FILES='abcdefgh';
C.board={ create:function(opts){
  opts=opts||{}; var S={pos:new Array(64).fill(null),sel:null,targets:{},last:null,check:null,targeting:null,flipped:!!opts.flipped,coords:opts.coords!==false,interactive:true,tile:0};
  var el=h('div',{class:'cav-board',role:'grid','aria-label':T('cav.obj.board')}), frame=h('div',{class:'cb-frame'}), grid=h('div',{class:'cb-grid'}), fx=h('div',{class:'cb-fx'});
  el.appendChild(frame); el.appendChild(grid); el.appendChild(fx);
  var cells=[];
  function sqAt(i){ return S.flipped?63-i:i; }
  function build(){ var tile=C.stage.get().tile; S.tile=tile; var t=4;
    el.style.setProperty('--bt',tile); el.style.width='calc(var(--u)*'+(tile*8+t*2)+')'; el.style.height=el.style.width;
    frame.style.backgroundImage='url('+A.url(A.boardFrame(tile,t))+')'; grid.innerHTML=''; cells=[];
    grid.style.cssText='left:calc(var(--u)*'+t+');top:calc(var(--u)*'+t+');width:calc(var(--u)*'+tile*8+');height:calc(var(--u)*'+tile*8+')';
    for(var i=0;i<64;i++){ var sq=sqAt(i), r=sq>>3, f=sq&7, light=((r+f)&1)===0;
      var b=h('button',{type:'button',class:'cb-sq',role:'gridcell','data-sq':sq,'aria-label':FILES[f]+(8-r)}); b.style.backgroundImage='url('+A.url(A.square(light,tile,(r*3+f)%4))+')';
      var pc=h('span',{class:'cb-pc'}), ov=h('span',{class:'cb-ov'}), co=null;
      if(S.coords){ if((S.flipped?r===0:r===7)) co=h('i',{class:'cb-file',text:FILES[f]}); if((S.flipped?f===7:f===0)) { var rk=h('i',{class:'cb-rank',text:String(8-r)}); b.appendChild(rk); } }
      b.appendChild(ov); b.appendChild(pc); if(co) b.appendChild(co);
      b.addEventListener('click',function(e){ if(!S.interactive) return; var q=+this.getAttribute('data-sq'); C.sfx('board.tap',{sq:q}); if(opts.onSquare) opts.onSquare(q,e); });
      grid.appendChild(b); cells[sq]={b:b,pc:pc,ov:ov}; }
    render(); }
  function pieceUrl(p){ return 'url('+A.url(A.piece(p,p===p.toUpperCase(),S.tile))+')'; }
  function render(){ for(var sq=0;sq<64;sq++){ var c=cells[sq]; if(!c) continue; var p=S.pos[sq], cls=[];
      c.pc.style.backgroundImage=p?pieceUrl(p):'none'; c.pc.setAttribute('data-p',p||'');
      var ovs=[]; if(S.last&&(S.last.from===sq||S.last.to===sq)) ovs.push('last'); if(S.check===sq) ovs.push('check');
      if(S.targeting){ if(S.targeting.valid.indexOf(sq)>=0) ovs.push('target'); else if(S.targeting.dim) ovs.push('badtarget'); }
      if(S.sel===sq) ovs.push('select'); var tg=S.targets[sq]; if(tg) ovs.push(tg.capture?'ring':'dot');
      c.ov.style.backgroundImage=ovs.map(function(k){ return 'url('+A.url(A.overlay(k,S.tile))+')'; }).join(',');
      c.ov.style.backgroundSize='100% 100%'; c.b.classList.toggle('is-sel',S.sel===sq); c.b.classList.toggle('is-target',!!tg); c.b.setAttribute('aria-selected',S.sel===sq?'true':'false');
      var label=FILES[sq&7]+(8-(sq>>3))+(p?' '+pname(p):''); c.b.setAttribute('aria-label',label); } }
  function pname(p){ return ({p:'pawn',n:'knight',b:'bishop',r:'rook',q:'queen',k:'king'})[p.toLowerCase()]+' '+(p===p.toUpperCase()?'white':'black'); }
  var api={ el:el,
    setPosition:function(b){ S.pos=b.slice(); render(); },
    setSelected:function(sq){ S.sel=sq==null?null:sq; render(); },
    setTargets:function(list){ S.targets={}; (list||[]).forEach(function(t){ S.targets[t.sq]=t; }); render(); },
    setLastMove:function(m){ S.last=m||null; render(); }, setCheck:function(sq){ S.check=sq==null?null:sq; render(); },
    setTargeting:function(t){ S.targeting=t||null; el.classList.toggle('is-targeting',!!t); render(); },
    setInteractive:function(v){ S.interactive=!!v; el.classList.toggle('is-locked',!v); },
    setFlipped:function(v){ S.flipped=!!v; build(); }, setCoords:function(v){ S.coords=!!v; build(); },
    /* visual-only slide from->to; call AFTER setPosition(new) so the piece is already at `to`. */
    animateMove:function(from,to,o){ if(C.reducedMotion()) return; var a=cells[from],b=cells[to]; if(!a||!b) return; var ra=a.b.getBoundingClientRect(), rb=b.b.getBoundingClientRect();
      var dx=Math.round(ra.left-rb.left), dy=Math.round(ra.top-rb.top), steps=4; b.pc.style.setProperty('--dx',dx+'px'); b.pc.style.setProperty('--dy',dy+'px'); b.pc.classList.remove('cb-slide'); void b.pc.offsetWidth; b.pc.classList.add('cb-slide');
      if(o&&o.capture) { b.b.classList.remove('cb-hit'); void b.b.offsetWidth; b.b.classList.add('cb-hit'); } C.sfx(o&&o.capture?'board.capture':'board.move'); },
    /* promotion picker: tap-only, 4 big buttons. cb(pieceLetter) */
    showPromotion:function(white,cb){ var panel=ui.panel('wood',[h('div',{class:'cav-c',text:T('cav.match.pickPromo')}),h('div',{class:'cb-promo-row'},['q','r','b','n'].map(function(p){ var L=white?p.toUpperCase():p;
        var b=h('button',{type:'button',class:'cav-btn big','aria-label':pname(L)},[A.el(A.piece(L,white,Math.max(18,S.tile)))]); b.addEventListener('click',function(){ ov.close('pick'); cb(p); }); return b; }))],'cb-promo');
      var ov=ui.overlay.open({id:'promotion',title:T('cav.match.pickPromo'),content:panel,noClose:true,modal:true,kind:'ink'}); return ov; },
    destroy:function(){ unsub(); el.remove(); } };
  var unsub=C.stage.on('resize',function(){ if(C.stage.get().tile!==S.tile) build(); });
  build(); return api; } };
})();
