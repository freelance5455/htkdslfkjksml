/* CAV.ledger + CAV.mail — paper documents: the match ledger and the correspondence tray with openable envelopes. */
(function(){
var C=window.CAV, h=C.h, A=C.art, ui=C.ui, T=C.t;
function portrait(id){ var k='cav.portrait.crop.'+id; if(!A.has(k)) A.define(k,function(){ var q=A.px(C.portraitKey(id)).crop(6,4,16,16).clone(); return q.pad(1,1,1,1).outline(C.pal.K[0]).crop(0,0,18,18); }); return A.el(k); }
/* ledger props: {rows:[{day,opponent:{name,portrait},result:'win'|'loss'|'draw',gain}], reputation:0..100, total, onClose} */
C.ledger={ open:function(p){ var rows=p.rows||[], body=h('div',{class:'pd-ledger'});
  var tbl=h('div',{class:'pd-rows cav-scroll'}); rows.forEach(function(r){ var tone=r.result==='win'?'forest':(r.result==='loss'?'wax':'iron'); tbl.appendChild(h('div',{class:'pd-row'},[h('span',{class:'pd-d',text:T('cav.day',{n:r.day})}),portrait(r.opponent.portrait),h('span',{class:'cav-fill cav-ell',text:r.opponent.name}),
      h('span',{class:'pd-res '+r.result,text:T('cav.ledger.'+r.result)}),h('span',{class:'pd-g'},[ui.icon('coin'),h('span',{text:String(r.gain)})])])); });
  var rep=h('div',{class:'pd-rep'},[h('span',{text:T('cav.ledger.rep')}),h('span',{class:'pd-bar'},[h('i',{style:'width:'+Math.max(0,Math.min(100,p.reputation||0))+'%'})]),h('span',{text:String(p.reputation||0)})]);
  body.appendChild(tbl); body.appendChild(h('div',{class:'pd-foot'},[rep,h('span',{class:'pd-tot'},[h('span',{text:T('cav.ledger.total')}),ui.icon('coin'),h('b',{text:String(p.total!=null?p.total:rows.reduce(function(a,r){return a+r.gain},0))})])]));
  return ui.overlay.open({id:'ledger',title:T('cav.ledger.title'),content:ui.panel('paper',[body],'pd-paper'),kind:'leather',icon:'book',onClose:p.onClose}); } };
/* mail props: {letters:[{id,kind:'invite'|'bill'|'notice',from,title,body,seal,read}], onRead(id), onReply(id,choice), onClose} */
C.mail={ open:function(p){ var letters=p.letters.slice(), S={sel:null}, ov, body=h('div',{class:'pd-mail'});
  function render(){ body.innerHTML=''; if(!letters.length){ body.appendChild(h('div',{class:'bk-empty',text:T('cav.mail.empty')})); return; }
    var list=h('div',{class:'pd-list cav-scroll'}); letters.forEach(function(l){ var b=h('button',{type:'button',class:'pd-env'+(S.sel===l.id?' is-sel':'')+(l.read?' is-read':''),'aria-label':l.title+' — '+l.from}); b.appendChild(A.el(A.envelope(18,12,!!l.seal,l.kind==='bill'?'blue':'')));
      b.appendChild(h('span',{class:'pd-et'},[h('span',{class:'cav-ell',text:l.title}),h('span',{class:'cav-ell cav-dim',text:l.from})])); if(!l.read) b.appendChild(h('span',{class:'pd-new'})); b.addEventListener('click',function(){ S.sel=l.id; if(!l.read){ l.read=true; if(p.onRead) p.onRead(l.id); } render(); C.sfx('mail.open'); }); list.appendChild(b); });
    var sel=letters.filter(function(l){return l.id===S.sel})[0], paper;
    if(sel){ paper=ui.panel('paper',[h('div',{class:'pd-kind',text:T('cav.mail.'+sel.kind)}),h('div',{class:'ci-name',text:sel.title}),h('div',{class:'cav-dim',text:sel.from}),h('div',{class:'pd-body cav-scroll',text:sel.body}),
        h('div',{class:'ci-actions'},[sel.kind==='invite'?ui.btn({label:T('cav.book.accept'),kind:'forest',icon:'check',onClick:function(){ if(p.onReply) p.onReply(sel.id,'accept'); ui.toast(T('cav.book.accepted')); }}):null,sel.kind==='invite'?ui.btn({label:T('cav.book.decline'),kind:'wax',icon:'close',onClick:function(){ if(p.onReply) p.onReply(sel.id,'decline'); }}):null])],'pd-letter cav-env-open'); }
    else paper=h('div',{class:'cav-dim cav-c pd-letter',text:T('cav.desk.hint')});
    body.appendChild(list); body.appendChild(paper); }
  ov=ui.overlay.open({id:'mail',title:T('cav.mail.title'),content:body,kind:'wood',icon:'mail',onClose:p.onClose}); render(); return ov; } };
})();
