/* Relics: 20x20 top-down collectibles. They read as physical, handcrafted chess-club objects — medals, instruments, tokens. */
(function(){
var C=window.CAV, P=C.pal, Px=C.Px, A=C.art, K=P.K;
var R={};
R.merchants_ring=function(p){ p.ring(10,12,6.5,3,P.brass[3]); p.ring(10,12,6.5,1,P.brass[4]); p.ring(10,12,4,1,P.brass[1]); p.shadeDisc(10,5,3,P.wax,{dither:false}); p.rect(8,5,1,1,P.wax[4]); };
R.iron_reliquary=function(p){ p.bevel(2,4,16,13,P.iron,{fill:P.iron[2],hi:4,lo:0}); p.rect(2,8,16,2,P.iron[1]); p.hline(2,8,16,P.iron[3]); [[4,6],[15,6],[4,14],[15,14]].forEach(function(q){ p.set(q[0],q[1],P.brass[4]); }); p.rect(9,9,3,3,P.brass[3]); p.set(9,9,P.brass[4]); p.rect(10,11,1,2,K[0]); };
R.obsidian_hourglass=function(p){ p.rect(3,2,14,2,P.brass[3]); p.rect(3,16,14,2,P.brass[3]); p.hline(3,2,14,P.brass[4]); p.poly([[4,4],[16,4],[11,10],[9,10]],P.ebony[3]); p.poly([[9,10],[11,10],[16,16],[4,16]],P.ebony[2]); p.poly([[5,5],[8,5],[10,9]],P.ebony[4]); p.rect(9,10,2,3,P.violet[4]); p.poly([[6,15],[14,15],[11,12],[9,12]],P.violet[3]); p.vline(3,4,12,P.brass[1]); p.vline(16,4,12,P.brass[1]); };
R.sacrificial_censer=function(p){ p.shadeDisc(10,11,6.5,P.brass,{dither:false}); p.ring(10,11,6,1,P.brass[1]); p.hline(5,11,10,P.brass[1]); for(var i=0;i<3;i++){ p.set(7+i*3,8,K[1]); p.set(7+i*3,14,K[1]); } p.rect(9,2,2,3,P.brass[3]); p.line(10,2,13,0,P.iron[3]); p.ellipse(15,2,1.4,1.4,P.silver[2]); p.set(16,1,P.silver[3]); };
R.vault_key=function(p){ p.shadeDisc(6,6,4.5,P.brass,{dither:false}); p.ellipse(6,6,1.6,1.6,K[1]); p.rect(9,9,3,2,P.brass[3]); p.line(9,9,17,17,P.brass[3]); p.line(10,9,18,17,P.brass[2]); p.rect(14,14,4,2,P.brass[3]); p.rect(16,16,3,2,P.brass[3]); p.set(2,3,P.brass[4]); };
R.crowned_pawn=function(p){ p.line(7,0,7,6,P.wax[3]); p.line(13,0,13,6,P.wax[2]); p.rect(7,0,7,3,P.wax[3]); p.shadeDisc(10,12,7,P.brass,{dither:false}); p.ring(10,12,6,1,P.brass[1]);
  p.shadeDisc(10,11,2.4,P.ivory,{dither:false}); p.rect(8,14,5,3,P.ivory[3]); p.poly([[7,8],[8,6],[10,8],[12,6],[13,8],[13,9],[7,9]],P.glow[3]); };
R.warders_mark=function(p){ p.poly([[3,2],[17,2],[17,11],[10,18],[3,11]],P.iron[2]); p.poly([[4,3],[16,3],[16,10],[10,16],[4,10]],P.steel[2]); p.poly([[4,3],[10,3],[10,16],[4,10]],P.steel[3]); p.rect(9,5,2,9,P.wax[3]); p.rect(6,8,8,2,P.wax[3]); p.hline(3,2,14,P.iron[4]); };
R.duelists_glove=function(p){ var l=P.leather; p.rect(5,12,10,6,l[2]); p.rect(4,14,12,2,P.brass[2]); [[5,3,2,10],[7,1,2,12],[9,2,2,11],[11,4,2,9]].forEach(function(q){ p.rect(q[0],q[1],q[2],q[3],l[3]); p.vline(q[0],q[1],q[3],l[4]); }); p.rect(2,9,4,2,l[3]); p.rect(5,10,9,4,l[3]); p.hline(5,10,9,l[4]); };
R.scribes_quill=function(p){ p.poly([[17,1],[19,3],[10,14],[6,16],[5,15],[8,11]],P.ivory[3]); p.poly([[17,1],[19,3],[15,7],[13,6]],P.ivory[4]); p.line(18,2,7,15,P.ivory[1]); p.rect(5,15,3,2,P.K[1]); p.shadeDisc(5,16,3.2,P.navy,{dither:false}); p.set(4,15,P.silver[4]); };
R.generic=function(p){ p.shadeDisc(10,10,7,P.brass,{dither:false}); p.ring(10,10,5,1,P.brass[1]); p.rect(9,7,2,6,P.K[1]); };
A.relic=function(id){ var k='cav.relic.'+id; if(!A.has(k)) A.define(k,function(){ var p=new Px(20,20); (R[id]||R.generic)(p); return p.outline(K[0]).shadow('#00000066',1,1).pad(0,0,0,0); }); return k; };
A.relicIds=Object.keys(R).filter(function(k){return k!=='generic'});
})();
