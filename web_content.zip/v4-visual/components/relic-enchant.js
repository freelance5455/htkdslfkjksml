/* CAV.relicCase + CAV.enchantKit — two small physical workspaces. Presentation only; compatibility/preview data come from the host.
   relicCase props: {slots:[relicId|null,...], stored:[relicId], resolve(id)->{name,description,rarity}, onEquip(id,slotIndex), onUnequip(slotIndex), onClose()}
   enchantKit props: {cards:[{def}], enchants:[{id,name,description}], isCompatible(cardId,enchId)->{ok,reason}, preview(cardId,enchId)->[{label,from,to}], onApply(cardId,enchId), onClose()} */
(function(){
var C=window.CAV, h=C.h, A=C.art, ui=C.ui, T=C.t;

/* ---------------- relic case ---------------- */
C.relicCase={ open:function(props){ var P=Object.assign({slots:[null,null,null],stored:[],resolve:function(id){return{name:id};}},props), S={sel:null,pickSlot:false}, ov, body=h('div',{class:'rc'});
  function relicEl(id,cls){ var b=h('button',{type:'button',class:'rc-relic '+(cls||''),'aria-label':P.resolve(id).name}); b.appendChild(A.el(A.relic(id))); return b; }
  function render(){ body.innerHTML='';
    var slots=h('div',{class:'rc-slots'}); P.slots.forEach(function(id,i){ var s=h('button',{type:'button',class:'rc-slot cav-panel slot'+(S.pickSlot?' is-pick':'')+(id?' is-full':''),'aria-label':T('cav.relic.equipped')+' '+(i+1)+': '+(id?P.resolve(id).name:T('cav.relic.empty'))});
      if(id){ s.appendChild(A.el(A.relic(id))); s.appendChild(h('span',{class:'rc-tag',text:'✓'})); } else s.appendChild(h('span',{class:'cav-dim',text:'+'}));
      s.addEventListener('click',function(){ C.sfx('relic.tap'); if(S.sel&&S.pickSlot||(S.sel&&!id)){ var rid=S.sel; S.sel=null; S.pickSlot=false; if(P.onEquip) P.onEquip(rid,i); return; } if(id){ S.sel={slot:i,id:id}; S.pickSlot=false; render(); } }); slots.appendChild(s); });
    var stored=h('div',{class:'rc-stored'}); P.stored.forEach(function(id){ var b=relicEl(id,(S.sel&&S.sel===id)?'is-sel':''); b.addEventListener('click',function(){ C.sfx('relic.tap'); S.sel=(S.sel===id?null:id); S.pickSlot=false; render(); }); stored.appendChild(b); });
    if(!P.stored.length) stored.appendChild(h('span',{class:'cav-dim',text:T('cav.relic.empty')}));
    var selId=S.sel&&(S.sel.id||S.sel), info=h('div',{class:'rc-info'}); var rd=selId?P.resolve(selId):null;
    if(rd){ var eq=!!(S.sel&&S.sel.slot!=null), full=P.slots.every(Boolean);
      info.appendChild(ui.panel('paper',[h('div',{class:'ci-name',text:rd.name}),h('span',{class:'ci-tag r-'+(rd.rarity||'common'),text:T('cav.rarity.'+(rd.rarity||'common'))}),h('div',{class:'ci-desc cav-scroll',text:rd.description||''})],'ci-text'));
      var acts=h('div',{class:'ci-actions'}); if(eq) acts.appendChild(ui.btn({label:T('cav.relic.unequip'),kind:'wax',onClick:function(){ var i=S.sel.slot; S.sel=null; if(P.onUnequip) P.onUnequip(i); }}));
      else if(!full){ acts.appendChild(ui.btn({label:T('cav.relic.equip'),kind:'forest',icon:'check',onClick:function(){ var i=P.slots.indexOf(null), rid=S.sel; S.sel=null; if(P.onEquip) P.onEquip(rid,i); }})); }
      else { acts.appendChild(ui.btn({label:S.pickSlot?T('cav.relic.pickSlot'):T('cav.relic.replace'),kind:'brass',onClick:function(){ S.pickSlot=true; render(); }})); }
      info.appendChild(acts); } else info.appendChild(h('div',{class:'cav-dim cav-c',text:T('cav.desk.hint')}));
    body.appendChild(h('div',{class:'rc-row'},[h('div',{class:'rc-case cav-panel leather'},[h('div',{class:'rc-lab',text:T('cav.relic.equipped')}),slots,h('div',{class:'rc-lab',text:T('cav.relic.stored')}),stored]),info])); }
  ov=ui.overlay.open({id:'relics',title:T('cav.relic.title'),content:body,kind:'wood',icon:'star',onClose:function(){ if(P.onClose) P.onClose(); }}); render();
  return { update:function(p){ Object.assign(P,p); render(); }, overlay:ov }; } };

/* ---------------- enchantment kit ---------------- */
C.enchantKit={ open:function(props){ var P=Object.assign({cards:[],enchants:[],isCompatible:function(){return{ok:true};},preview:function(){return[];}},props), S={card:null,ench:null,done:false}, ov, body=h('div',{class:'ek'});
  function render(){ body.innerHTML='';
    var cl=h('div',{class:'ek-cards cav-scroll'}); P.cards.forEach(function(c){ var comp=S.ench?P.isCompatible(c.id,S.ench):{ok:true}, st=C.cards.strip({name:c.name,cost:c.cost,rarity:c.rarity,enchant:c.enchant,chips:c.chips,selected:S.card===c.id,disabled:!comp.ok||c.onlyActive===false,why:comp.reason&&T(comp.reason),onTap:function(){ if(!comp.ok){ ui.toast(T(comp.reason||'cav.ench.incompatible')); return; } S.card=S.card===c.id?null:c.id; S.done=false; render(); }}); cl.appendChild(st); });
    var sl=h('div',{class:'ek-seals'}); P.enchants.forEach(function(e){ var on=S.ench===e.id, comp=S.card?P.isCompatible(S.card,e.id):{ok:true}; var b=h('button',{type:'button',class:'ek-seal'+(on?' is-sel':'')+(comp.ok?'':' is-bad'),'aria-pressed':on?'true':'false','aria-label':e.name},[A.el(A.seal(e.id)),h('span',{class:'ek-sn cav-ell',text:e.name})]);
      b.addEventListener('click',function(){ S.ench=on?null:e.id; S.done=false; render(); }); sl.appendChild(b); });
    var pv=h('div',{class:'ek-prev'}); var card=P.cards.filter(function(c){return c.id===S.card})[0], en=P.enchants.filter(function(e){return e.id===S.ench})[0];
    if(card&&en){ var comp2=P.isCompatible(card.id,en.id), lines=P.preview(card.id,en.id)||[];
      var cc=C.cards.create(Object.assign({},card,{enchant:S.done||false?en.id:null})); if(!S.done) cc._cav.update({enchant:en.id}); cc.classList.add('ek-card'); if(!S.done) cc.style.opacity='.9';
      pv.appendChild(cc);
      var tx=h('div',{class:'ek-lines'},[h('div',{class:'ci-name cav-wax',text:en.name}),h('div',{class:'ci-desc',text:en.description||''})]); lines.forEach(function(l){ tx.appendChild(h('div',{class:'ek-line'},[h('span',{text:l.label}),h('span',{class:'cav-fill'}),h('span',{class:'cav-dim',text:String(l.from)}),ui.icon('right'),h('b',{text:String(l.to)})])); }); if(!lines.length) tx.appendChild(h('div',{class:'cav-dim',text:T('cav.ench.none')}));
      var apply=ui.btn({label:S.done?T('cav.ench.done'):T('cav.ench.apply'),kind:S.done?'forest':'wax',icon:'star',disabled:!comp2.ok||S.done,onClick:function(){ stampAnim(cc,function(){ S.done=true; if(P.onApply) P.onApply(card.id,en.id); render(); }); }}); tx.appendChild(apply); pv.appendChild(tx); }
    else pv.appendChild(h('div',{class:'cav-dim cav-c',text:!S.card?T('cav.ench.pickCard'):T('cav.ench.pickSeal')}));
    body.appendChild(h('div',{class:'ek-row'},[h('div',{class:'ek-left'},[h('div',{class:'cat-head cav-brass',text:T('cav.ench.pickCard')}),cl]),h('div',{class:'ek-right'},[h('div',{class:'cat-head cav-brass',text:T('cav.ench.pickSeal')}),sl,h('div',{class:'cat-head cav-brass',text:T('cav.ench.preview')}),pv])])); }
  function stampAnim(cc,done){ if(C.reducedMotion()){ done(); return; } var s=h('div',{class:'ek-press'},[A.el(A.seal(S.ench))]); cc.appendChild(s); C.sfx('ench.press'); setTimeout(function(){ s.remove(); done(); },320); }
  ov=ui.overlay.open({id:'enchant',title:T('cav.ench.title'),content:body,kind:'wood',icon:'star',cls:'ek-panel',onClose:function(){ if(P.onClose) P.onClose(); }}); render();
  return { update:function(p){ Object.assign(P,p); render(); }, overlay:ov }; } };
})();
