/* Top-down chess piece sprites (strict 90° orthographic view).  Procedural but pixel-exact: drawn at any tile size n.
   Silhouettes are chosen to be readable from above:  pawn = ball · rook = notched square · bishop = ball with mitre slit ·
   knight = horse head with ears + mane · queen = coronet of 8 points · king = cross on a dome.
   White pieces face up the board, black pieces face down (knight snout direction). */
(function(){
var C=window.CAV, P=C.pal, Px=C.Px;
var BLK=['#12101a','#24222e','#3a3846','#55536a','#807e9a'];
function piece(type, white, n){
  var p=new Px(n,n), ramp=white?P.ivory:BLK, c=n/2, R=(n-4)/2, lo=ramp.slice(0,3), cy=c+.0;
  var accent = white? P.brass : P.silver;
  function base(r){ p.shadeDisc(c,cy,r,[ramp[0],ramp[1],ramp[1],ramp[2]]); }
  var t=type.toLowerCase();
  if(t==='p'){
    base(R*.9); p.shadeDisc(c,cy-.5,R*.5,ramp,{dither:false});
  }else if(t==='r'){
    var s=Math.round(R*.92); var x0=Math.round(c-s), w=s*2;
    p.bevel(x0,x0,w,w,ramp,{fill:ramp[2],hi:3,lo:1});
    var g=Math.max(2,Math.round(s*.45)), mid=Math.round(c-g/2);
    p.rect(mid,x0,g,2,ramp[0]); p.rect(mid,x0+w-2,g,2,ramp[0]); p.rect(x0,mid,2,g,ramp[0]); p.rect(x0+w-2,mid,2,g,ramp[0]);
    var ir=Math.max(2,Math.round(s*.5)); p.shadeDisc(c,cy,ir,[ramp[1],ramp[1],ramp[2],ramp[3]]);
    p.set(x0+1,x0+1,ramp[4]);
  }else if(t==='b'){
    base(R*.9); p.shadeDisc(c,cy-.5,R*.7,ramp);
    var a=R*.62, x0=Math.round(c+a*.75), y0=Math.round(cy-a*.95), x1=Math.round(c-a*.55), y1=Math.round(cy+a*.35);
    p.line(x0,y0,x1,y1,ramp[0]); p.line(x0-1,y0,x1-1,y1,ramp[0]); p.line(x0+1,y0+1,x1+1,y1+1,ramp[1]);
    p.rect(Math.round(c-R*.35),Math.round(cy-R*.45),2,2,ramp[4]);
  }else if(t==='n'){
    var up=white?1:-1, bx=Math.round(c), by=cy+up*R*.28, hy=cy-up*R*.38;
    p.shadeDisc(c,by,R*.68,ramp,{dither:false});                                  /* neck / withers */
    p.ellipse(c,hy,R*.4,R*.62,ramp[3]); p.ellipse(c-.6,hy-up*.4,R*.26,R*.46,ramp[4]);      /* head, lit from top-left */
    p.ellipse(c,cy-up*R*.95,R*.26,R*.2,ramp[2]);                                  /* muzzle */
    var ex=Math.max(2,Math.round(R*.46)), ey=Math.round(cy-up*R*.05);
    p.rect(bx-ex-1,ey-(up>0?1:0),2,2,ramp[3]); p.rect(bx+ex-1,ey-(up>0?1:0),2,2,ramp[2]);   /* ears */
    var ee=Math.max(1,Math.round(R*.3)), eyy=Math.round(hy-up*R*.1);
    p.set(bx-ee,eyy,ramp[0]); p.set(bx+ee-1,eyy,ramp[0]);                         /* eyes */
    for(var i=0;i<Math.round(R*.95);i++){ p.set(bx,Math.round(cy+up*(i-R*.05)),ramp[1]); p.set(bx-1,Math.round(cy+up*(i-R*.05)),ramp[2]); } /* mane */
  }else if(t==='q'){
    base(R*.95); p.shadeDisc(c,cy,R*.62,ramp);
    for(var k=0;k<8;k++){ var ang=k*Math.PI/4+Math.PI/8, px=c+Math.cos(ang)*R*.84, py=cy+Math.sin(ang)*R*.84;
      p.rect(Math.round(px-.5),Math.round(py-.5),Math.max(1,Math.round(R*.2)),Math.max(1,Math.round(R*.2)),white?ramp[4]:ramp[3]); }
    p.rect(Math.round(c-1),Math.round(cy-1),2,2,P.wax[3]); p.set(Math.round(c-1),Math.round(cy-1),P.wax[4]);
  }else if(t==='k'){
    base(R*.95); p.shadeDisc(c,cy,R*.6,ramp);
    var L=Math.round(R*.95), th=Math.max(2,Math.round(R*.26)), x=Math.round(c-th/2), y=Math.round(cy-L/2);
    p.rect(x,y,th,L,accent[3]); p.rect(Math.round(c-L/2),Math.round(cy-th/2),L,th,accent[3]);
    p.rect(x,y,1,L,accent[4]); p.rect(Math.round(c-L/2),Math.round(cy-th/2),L,1,accent[4]);
    p.rect(x+th-1,y+1,1,L-1,accent[1]); p.rect(Math.round(c-L/2)+1,Math.round(cy+th/2)-1,L-1,1,accent[1]);
  }
  p.outline(P.K[0]); p.shadow('#00000066',1,1); return p;
}
/* Default set = the approved reference set (front-view pixel pieces, sizes 20/27/34); the procedural top-down set stays as 'topdown' (and for tiles < 19 px). */
function refPiece(type,white,n){ var R=C.refPieces, sz=[34,27,20].filter(function(x){ return x<=n; })[0]; if(!sz) return null; var rows=R.sizes[sz][white?type.toUpperCase():type.toLowerCase()], p=new C.Px(n,n);
  var ox=Math.floor((n-sz)/2), oy=n-sz-(n>sz?Math.min(1,n-sz):0); for(var y=0;y<sz;y++) for(var x=0;x<sz;x++){ var c=rows[y][x]; if(c!=='.') p.set(ox+x,oy+y,R.pal[c.charCodeAt(0)-48]); } return p; }
C.art.pieceSet='ref';
C.art.piece=function(type,white,n){ var set=C.art.pieceSet, k='cav.chess.piece.'+set+'.'+(white?'w':'b')+type.toLowerCase()+'@'+n; if(!C.art.has(k)) C.art.define(k,function(){ var p=(set==='ref'&&C.refPieces)?refPiece(type,white,n):null; return p||piece(type,white,n); }); return k; };
C.art._piece=piece;

/* board squares: light maple / dark rosewood with hand-placed grain (deterministic per square) */
function square(light,n,seed){
  var p=new Px(n,n), r=C.rng(seed), ramp=light?P.maple:P.rosewood, base=light?ramp[3]:ramp[2], hi=light?ramp[4]:ramp[3], lo=light?ramp[2]:ramp[1];
  p.rect(0,0,n,n,base);
  for(var i=0;i<Math.ceil(n/3);i++){ var y=r.int(1,n-2), x=r.int(0,n-6), len=r.int(3,Math.max(4,n-4)); p.hline(x,y,Math.min(len,n-x),i%2?lo:hi); }
  for(var j=0;j<n*n/60;j++) p.set(r.int(0,n-1),r.int(0,n-1),r()<.5?hi:lo);
  p.hline(0,0,n,hi); p.vline(0,0,n,hi);                   /* square bevel catches the light on its top-left edges */
  p.hline(0,n-1,n,lo); p.vline(n-1,0,n,lo);
  return p; }
C.art.square=function(light,n,v){ var k='cav.chess.sq.'+(light?'l':'d')+'@'+n+'.'+v; if(!C.art.has(k)) C.art.define(k,function(){return square(light,n,v*7+(light?1:2))}); return k; };

/* board frame: walnut rails with brass corner studs; returns a 9-slice-able strip set via one sprite (frame only, transparent centre) */
function boardFrame(n,thick){ var W=n*8+thick*2, p=new Px(W,W);
  p.bevel(0,0,W,W,P.walnut,{fill:P.walnut[2],hi:4,lo:0});
  p.rect(thick-1,thick-1,n*8+2,n*8+2,P.K[0]);                    /* inner shadow line */
  for(var i=0;i<W;i+=3){ p.set(i,1+(i%2),P.walnut[3]); p.set(i,W-2-(i%2),P.walnut[1]); p.set(1+(i%2),i,P.walnut[3]); p.set(W-2-(i%2),i,P.walnut[1]); }
  [[1,1],[W-3,1],[1,W-3],[W-3,W-3]].forEach(function(q){ p.rect(q[0],q[1],2,2,P.brass[3]); p.set(q[0],q[1],P.brass[4]); p.set(q[0]+1,q[1]+1,P.brass[1]); });
  /* punch out the playing area */
  for(var y=thick;y<thick+n*8;y++) for(var x=thick;x<thick+n*8;x++){ var o=(y*W+x)*4; p.d[o+3]=0; }
  p.rect(thick,thick,n*8,1,P.K[0]); p.rect(thick,thick,1,n*8,P.K[0]);
  return p; }
C.art.boardFrame=function(n,t){ var k='cav.chess.frame@'+n+'x'+t; if(!C.art.has(k)) C.art.define(k,function(){return boardFrame(n,t)}); return k; };

/* overlays drawn at tile size n */
C.art.overlay=function(kind,n){ var k='cav.chess.ov.'+kind+'@'+n; if(C.art.has(k)) return k;
  C.art.define(k,function(){ var p=new Px(n,n), b=P.brass, w=P.wax, t=P.teal, m=Math.max(3,Math.round(n/4));
    if(kind==='dot'){ var r=Math.max(2,Math.round(n/7)); p.ellipse(n/2,n/2,r,r,'#1a0f0bcc'); p.ellipse(n/2-.5,n/2-.5,r-1,r-1,b[4]); }
    else if(kind==='ring'){ /* capture: 4 corner brackets in wax red */ [[0,0,1,1],[n-m,0,-1,1],[0,n-m,1,-1],[n-m,n-m,-1,-1]].forEach(function(q){ p.rect(q[0],q[1]+(q[3]<0?m-2:0),m,2,w[3]); p.rect(q[0]+(q[2]<0?m-2:0),q[1],2,m,w[3]); }); p.frame(0,0,n,n,'#cf455855'); }
    else if(kind==='select'){ p.frame(0,0,n,n,b[4]); p.frame(1,1,n-2,n-2,b[2]); p.rect(0,0,m,2,b[4]); }
    else if(kind==='last'){ p.rect(0,0,n,n,'#f2cc5855'); p.frame(0,0,n,n,'#f2cc58aa'); }
    else if(kind==='check'){ p.rect(0,0,n,n,'#cf455866'); p.frame(0,0,n,n,w[4]); p.frame(1,1,n-2,n-2,w[3]); p.dither(2,2,n-4,n-4,null,'#cf4558aa',.25); }
    else if(kind==='target'){ var tm=P.teal; p.frame(0,0,n,n,tm[4]); p.frame(1,1,n-2,n-2,tm[3]); p.rect(n/2-1,1,2,3,tm[4]); p.rect(n/2-1,n-4,2,3,tm[4]); p.rect(1,n/2-1,3,2,tm[4]); p.rect(n-4,n/2-1,3,2,tm[4]); p.dither(2,2,n-4,n-4,null,'#62a89c88',.18); }
    else if(kind==='badtarget'){ p.dither(0,0,n,n,null,'#0d080788',.5); }
    return p; }); return k; };
})();
