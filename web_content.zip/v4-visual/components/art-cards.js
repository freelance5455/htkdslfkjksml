/* Card art: archetype emblems, illustration motifs, the reusable card-face template (72x104), booster packs.
   Card illustrations are FRONTAL 2D (allowed exception to the top-down rule); everything is built from pixel primitives,
   outlined and lit from the top-left, so they match the rest of the package. */
(function(){
var C=window.CAV, P=C.pal, Px=C.Px, A=C.art;
var K=P.K;

/* ================= EMBLEMS (11x11) ================= */
function emblem(id,pri,sec){ var p=new Px(11,11), a=P[pri], b=P[sec];
  switch(id){
  case 'die': p.bevel(1,1,9,9,b,{fill:b[3],hi:4,lo:1}); [[3,3],[7,3],[5,5],[3,7],[7,7]].forEach(function(q){ p.rect(q[0],q[1],2,2,a[0]); }); break;
  case 'hourglass': p.rect(1,0,9,2,b[3]); p.rect(1,9,9,2,b[3]); p.poly([[2,2],[9,2],[6,5],[5,5]],b[4]); p.poly([[5,6],[6,6],[9,9],[2,9]],a[3]); p.rect(5,5,1,2,a[4]); p.hline(1,0,9,b[4]); break;
  case 'flame': p.poly([[5,0],[8,4],[9,7],[7,10],[3,10],[1,7],[3,4],[4,5]],b[3]); p.poly([[5,4],[7,7],[6,10],[4,10],[3,7]],a[4]); p.set(5,8,b[4]); break;
  case 'eye': p.ellipse(5.5,5.5,5,3,b[4]); p.ellipse(5.5,5.5,2.4,2.4,a[3]); p.rect(5,5,2,2,K[0]); p.set(4,4,b[4]); break;
  case 'shield': p.poly([[1,0],[10,0],[10,5],[5.5,11],[1,5]],b[3]); p.poly([[2,1],[5,1],[5,9],[2,5]],b[4]); p.poly([[6,1],[9,1],[9,5],[6,9]],a[3]); break;
  case 'scroll': p.rect(2,2,7,7,b[4]); p.ellipse(2,5.5,1.8,4,b[3]); p.ellipse(9,5.5,1.8,4,b[2]); p.rect(4,4,4,1,a[1]); p.rect(4,6,3,1,a[1]); p.rect(4,8,2,1,a[1]); break;
  case 'blade': p.line(1,9,9,1,b[4]); p.line(2,9,9,2,b[3]); p.rect(2,6,4,2,a[3]); p.set(1,9,a[4]); p.line(4,4,6,6,a[4]); break;
  case 'flask': p.rect(4,0,3,4,b[4]); p.poly([[4,4],[7,4],[10,10],[1,10]],a[3]); p.poly([[3,8],[8,8],[9,10],[2,10]],b[3]); p.set(4,0,b[4]); break;
  case 'compass': p.ring(5.5,5.5,5.2,1,b[4]); p.ellipse(5.5,5.5,4.4,4.4,a[2]); p.poly([[5,1],[7,5],[5,10],[4,5]],b[4]); p.poly([[5,1],[6,5],[5,5]],P.crimson[3]); p.set(5,5,K[0]); break;
  case 'horn': p.poly([[0,6],[2,3],[6,2],[10,0],[10,5],[7,8],[3,10],[1,9]],b[3]); p.poly([[2,5],[5,3],[9,2],[9,3],[5,5],[3,7]],b[4]); p.rect(8,2,3,4,a[3]); break;
  default: p.ellipse(5.5,5.5,4,4,b[3]);
  }
  return p.outline(K[0]); }
A.emblem=function(id,pri,sec){ var k='cav.emblem.'+id+'.'+pri+'.'+sec; if(!A.has(k)) A.define(k,function(){ return emblem(id,pri,sec); }); return k; };

/* ================= MOTIFS (30x30 painters) ================= */
var M={};
function pieceFront(m,t,col){ var r=col||P.ivory, c=15;
  m.ellipse(c,26,9,2.5,r[1]); m.rect(c-9,24,18,2,r[2]); m.hline(c-9,24,18,r[3]);
  if(t==='p'){ m.poly([[c-5,23],[c+5,23],[c+3,15],[c-3,15]],r[2]); m.shadeDisc(c,11,5,r); m.rect(c-6,15,12,2,r[3]); }
  if(t==='k'){ m.poly([[c-8,24],[c+8,24],[c+5,11],[c-5,11]],r[2]); m.vline(c-5,12,12,r[4]); m.rect(c-7,9,14,3,r[3]); m.hline(c-7,9,14,r[4]);
    m.rect(c-1,2,3,8,P.brass[3]); m.rect(c-3,4,7,2,P.brass[3]); m.vline(c-1,2,8,P.brass[4]); m.hline(c-3,4,7,P.brass[4]); }
  if(t==='r'){ m.poly([[c-7,24],[c+7,24],[c+5,11],[c-5,11]],r[2]); m.vline(c-5,12,12,r[4]); m.rect(c-8,6,16,5,r[3]); for(var i=0;i<3;i++) m.rect(c-8+i*6,2,4,5,r[3]); m.hline(c-8,6,16,r[4]); m.rect(c-8,2,2,2,r[4]); m.rect(c-2,2,2,2,r[4]); m.rect(c+4,2,2,2,r[4]); m.rect(c-2,14,4,6,K[1]); }
}
M.book=function(m,A){ m.poly([[2,10],[15,7],[15,24],[2,26]],P.paper[3]); m.poly([[28,10],[15,7],[15,24],[28,26]],P.paper[2]); m.vline(15,7,18,P.leather[1]);
  for(var i=0;i<4;i++){ m.line(4,13+i*3,13,11+i*3,P.parch[1]); m.line(17,11+i*3,26,13+i*3,P.parch[1]); } m.rect(14,23,3,6,P.wax[3]); m.line(1,11,1,27,P.leather[2]); m.line(29,11,29,27,P.leather[2]); m.line(2,27,28,27,P.leather[1]); };
M.coins=function(m,A){ for(var i=0;i<4;i++){ var y=24-i*4; m.rect(6,y-1,18,3,P.brass[2]); m.ellipse(15,y+1,9,3.2,P.brass[1]); m.ellipse(15,y-1,9,3.2,P.brass[3]); m.ellipse(14,y-1.5,6,1.8,P.brass[4]); } m.ellipse(15,7,5,5,P.brass[3]); m.ring(15,7,4,1,P.brass[1]); m.rect(14,5,2,5,P.brass[1]); m.set(13,5,P.brass[4]); };
M.eye=function(m,A){ m.poly([[1,15],[8,8],[22,8],[29,15],[22,22],[8,22]],P.ivory[4]); m.poly([[1,15],[8,8],[22,8],[29,15]],P.ivory[3]); m.shadeDisc(15,15,6.5,P[A.pri.id]||P.violet,{dither:false}); m.ellipse(15,15,3,3,K[0]); m.rect(12,11,3,3,P.ivory[4]);
  m.line(1,15,8,22,P.K[1]); m.line(29,15,22,22,P.K[1]); for(var i=0;i<5;i++) m.line(6+i*4,6-(i%2),6+i*4,3,P.K[0]); };
M.chalice=function(m,A){ m.poly([[6,6],[24,6],[22,16],[18,19],[12,19],[8,16]],P.brass[3]); m.poly([[6,6],[10,6],[11,18],[8,16]],P.brass[4]); m.ellipse(15,6,9,2,P.wax[2]); m.ellipse(15,6,7,1,P.wax[4]);
  m.rect(13,19,4,6,P.brass[2]); m.ellipse(15,26,8,2.5,P.brass[3]); m.rect(7,25,16,2,P.brass[2]); m.poly([[26,10],[28,14],[26,17],[24,14]],P.wax[3]); };
M.kingFront=function(m){ pieceFront(m,'k'); };
M.pawnFront=function(m){ pieceFront(m,'p'); };
M.tower=function(m){ pieceFront(m,'r'); };
M.purse=function(m,A){ m.shadeDisc(15,19,10,P.leather,{dither:false}); m.rect(10,8,10,5,P.leather[2]); m.hline(10,8,10,P.leather[4]); m.rect(9,12,12,3,P.brass[3]); m.hline(9,12,12,P.brass[4]);
  m.poly([[8,4],[12,9],[18,9],[22,4],[19,6],[15,3],[11,6]],P.leather[3]); m.ellipse(23,22,3,3,P.brass[3]); m.set(22,21,P.brass[4]); };
M.bell=function(m,A){ m.poly([[6,22],[8,13],[11,7],[19,7],[22,13],[24,22]],P.brass[3]); m.poly([[8,22],[9,13],[12,8],[14,8],[12,22]],P.brass[4]); m.rect(4,22,22,3,P.brass[2]); m.hline(4,22,22,P.brass[4]);
  m.ellipse(15,5,3,3,P.brass[2]); m.ellipse(15,26,3,2.5,P.brass[1]); m.set(14,4,P.brass[4]); m.line(1,14,3,16,P.brass[4]); m.line(29,14,27,16,P.brass[4]); };
M.rings=function(m,A){ var s=A.sec; m.ring(15,15,14,2,s[2]); m.ring(15,15,10,2,s[3]); m.ring(15,15,6,2,s[4]); m.shadeDisc(15,15,3,P.brass,{dither:false}); [[2,15],[28,15],[15,2],[15,28]].forEach(function(q){ m.set(q[0],q[1],s[4]); }); };
M.knightFront=function(m){ var r=P.ivory;
  m.poly([[8,26],[22,26],[22,20],[20,12],[24,10],[26,14],[27,17],[22,19],[17,5],[13,6],[11,3],[9,6],[6,12],[3,18],[6,20],[10,17],[9,21],[7,22]],r[2]);
  m.poly([[8,26],[22,26],[22,20],[20,12],[17,5],[13,6],[11,3],[9,6],[6,12],[10,17],[9,21],[7,22]],r[3]); m.poly([[13,6],[17,5],[19,10],[16,14],[14,9]],r[4]);
  m.line(17,5,22,14,P.K[1]); m.line(18,5,23,14,P.ebony[3]); m.rect(10,10,2,2,K[0]); m.set(9,9,r[4]); m.rect(4,17,3,2,P.K[1]); m.rect(6,26,18,2,P.ivory[1]); };
M.shield=function(m,A){ m.poly([[4,3],[26,3],[26,15],[15,28],[4,15]],P.iron[2]); m.poly([[6,5],[24,5],[24,14],[15,25],[6,14]],P.steel[2]); m.poly([[6,5],[15,5],[15,25],[6,14]],P.steel[3]); m.poly([[7,6],[10,6],[10,14],[7,12]],P.steel[4]);
  m.shadeDisc(15,13,4,P.brass,{dither:false}); m.hline(4,3,22,P.iron[4]); m.vline(4,3,12,P.iron[4]); };
M.dice=function(m,A){ m.bevel(2,10,14,14,P.ivory,{fill:P.ivory[3],hi:4,lo:1}); [[5,13],[11,13],[8,16],[5,19],[11,19]].forEach(function(q){ m.rect(q[0],q[1],2,2,K[0]); });
  m.poly([[16,4],[26,6],[24,17],[14,15]],P.wax[3]); m.poly([[16,4],[26,6],[25,8],[16,6]],P.wax[4]); [[18,8],[22,12],[20,10]].forEach(function(q){ m.rect(q[0],q[1],2,2,P.ivory[4]); }); m.ellipse(24,24,4,3,P.brass[3]); m.set(22,23,P.brass[4]); };
M.scroll=function(m,A){ m.rect(6,6,18,18,P.parch[4]); m.rect(6,6,18,2,P.parch[3]); m.ellipse(6,15,3,10,P.parch[3]); m.ellipse(24,15,3,10,P.parch[2]); m.ellipse(6,15,1.2,7,P.parch[1]);
  for(var i=0;i<4;i++) m.rect(9,10+i*3,12-(i%2)*4,1,P.K[1]); m.shadeDisc(20,22,3.5,P.wax,{dither:false}); m.line(23,24,26,28,P.wax[2]); m.line(18,25,16,28,P.wax[2]); };
M.pawnCrown=function(m,A){ pieceFront(m,'p'); m.poly([[8,0],[10,4],[13,1],[15,4],[17,1],[20,4],[22,0],[22,6],[8,6]],P.brass[3]); m.hline(8,5,14,P.brass[1]); m.set(8,0,P.brass[4]); m.set(15,3,P.wax[3]); };
M.glove=function(m,A){ var l=P.leather; m.rect(8,19,14,9,l[1]); m.hline(8,19,14,l[3]); m.rect(7,20,16,3,P.brass[2]);
  [[8,5,3,14],[11,3,3,16],[14,4,3,15],[17,6,3,13]].forEach(function(q){ m.rect(q[0],q[1],q[2],q[3],l[3]); m.vline(q[0],q[1],q[3],l[4]); m.vline(q[0]+q[2]-1,q[1],q[3],l[1]); });
  m.rect(4,13,5,3,l[3]); m.rect(8,15,13,5,l[3]); m.hline(8,15,13,l[4]); };
M.scales=function(m,A){ m.rect(14,4,3,22,P.brass[3]); m.vline(14,4,22,P.brass[4]); m.rect(9,26,13,2,P.brass[2]); m.rect(3,5,25,2,P.brass[3]); m.hline(3,5,25,P.brass[4]); m.shadeDisc(15.5,4,2.4,P.brass,{dither:false});
  m.line(4,7,2,18,P.iron[3]); m.line(4,7,9,18,P.iron[3]); m.line(27,7,22,18,P.iron[3]); m.line(27,7,29,18,P.iron[3]); m.ellipse(5.5,19,5,2,P.brass[3]); m.ellipse(25.5,19,5,2,P.brass[3]); m.ellipse(5.5,17.5,4,1.2,P.brass[4]); m.ellipse(25.5,17.5,4,1.2,P.brass[4]); m.ellipse(5.5,17,2,1.5,P.brass[4]); m.shadeDisc(26,16,2.2,P.wax,{dither:false}); };
M.candle=function(m,A){ m.rect(11,11,8,15,P.ivory[3]); m.vline(11,11,15,P.ivory[4]); m.vline(18,11,15,P.ivory[1]); m.poly([[11,11],[19,11],[17,14],[15,12],[13,15]],P.ivory[4]); m.rect(18,14,2,5,P.ivory[3]);
  m.ellipse(15,27,10,2.5,P.brass[2]); m.ellipse(15,26,8,2,P.brass[3]); m.rect(15,6,1,5,K[0]); m.poly([[15,0],[18,5],[17,9],[13,9],[12,5]],P.amber[3]); m.poly([[15,3],[17,6],[16,9],[14,9],[13,6]],P.amber[4]); m.set(15,7,'#fff6d0'); };
M.key=function(m,A){ m.shadeDisc(9,9,6,P.brass,{dither:false}); m.ellipse(9,9,2.4,2.4,K[1]); m.rect(13,13,3,2,P.brass[3]); m.line(13,13,26,26,P.brass[3]); m.line(14,13,27,26,P.brass[2]); m.rect(21,22,5,2,P.brass[3]); m.rect(24,25,4,2,P.brass[3]); };
M.generic=M.rings;
A.motifs=Object.keys(M);

function illustration(motif,arche,w,h){ var p=new Px(w,h), r=C.rng(C.hash(motif)), pri=P[arche.pri]||P.iron, sec=P[arche.sec]||P.ivory, ac=P[arche.accent]||sec;
  p.gradient(0,0,w,h,[pri[0],pri[1],pri[2],pri[3]],{});
  for(var rr=22;rr>4;rr-=3){ p.ring(w/2,h/2+1,rr,2,sec[(rr>14?1:2)]+'55'); }                               /* radial glow rings, translucent */
  p.dither(0,h-8,w,8,null,P.K[0],.5); p.hline(0,h-8,w,pri[4]);                                                 /* desk-edge band */
  for(var i=0;i<9;i++) p.set(r.int(2,w-3),r.int(2,h-12),sec[4]);                                              /* dust motes */
  var m=new Px(30,30); (M[motif]||M.generic)(m,{pri:Object.assign({id:arche.pri},pri),sec:sec,accent:ac}); m.outline(K[0]); m.shadow('#00000077',1,1);
  p.blit(m,Math.floor((w-m.w)/2),Math.floor((h-m.h)/2)-1);
  p.frame(0,0,w,h,K[0]); p.hline(1,1,w-2,pri[4]+'88'); p.vline(1,1,h-2,pri[4]+'55'); p.frame(1,h-2,w-2,1,K[0]);
  return p; }
A.illustration=function(motif,archId){ var k='cav.illus.'+motif+'.'+archId; if(!A.has(k)) A.define(k,function(){ return illustration(motif,C.archetype(archId)||{pri:'iron',sec:'ivory',accent:'ivory'},62,42); }); return k; };

/* ================= CARD FACE (72x104) =================
   Geometry (virtual px) — host DOM overlays text at these rects (see styles/cav-cards.css):
     art window  x4 y4  w64 h44    cost medallion centre (11,11) r8    archetype plate x54 y5 w14 h14
     name plaque x4 y50 w64 h19     type strip   x4 y71 w64 h9        chips band x4 y82 w64 h18      */
var CW=72, CH=104;
function frameFor(rarity,priRamp){ var R=C.rarities[rarity]||C.rarities.common, p=new Px(CW,CH), fr=P[R.ramp], trim=R.trim?P[R.trim]:null;
  p.bevel(0,0,CW,CH,fr,{fill:fr[2],hi:4,lo:0}); p.frame(0,0,CW,CH,K[0]); p.set(0,0,null); p.set(CW-1,0,null); p.set(0,CH-1,null); p.set(CW-1,CH-1,null);
  p.rect(2,2,CW-4,CH-4,priRamp[1]); p.frame(2,2,CW-4,CH-4,K[0]);                                               /* inner field in archetype colour */
  if(trim){ p.frame(1,1,CW-2,CH-2,trim[3]); }
  /* rivets */ [[2,2],[CW-4,2],[2,CH-4],[CW-4,CH-4]].forEach(function(q){ p.rect(q[0],q[1],2,2,fr[4]); p.set(q[0]+1,q[1]+1,fr[1]); });
  if(R.corners>=1){ [[0,0,0,0],[CW-1,0,1,0],[0,CH-1,0,1],[CW-1,CH-1,1,1]].forEach(function(q){ for(var i=0;i<6;i++){ p.set(q[2]?q[0]-i:q[0]+i,q[3]?q[1]-1:q[1]+1,P.brass[4]); p.set(q[2]?q[0]-1:q[0]+1,q[3]?q[1]-i:q[1]+i,P.brass[4]); } }); }
  if(R.corners>=2){ [[3,3,1,1],[CW-4,3,-1,1],[3,CH-4,1,-1],[CW-4,CH-4,-1,-1]].forEach(function(q){ for(var i=0;i<5;i++){ p.set(q[0]+q[2]*i,q[1]+q[3]*(i>2?i-2:0),P.brass[3]); } }); }
  if(R.corners>=3){ for(var x=10;x<CW-10;x+=4){ p.set(x,1,P.glow[4]); p.set(x+2,CH-2,P.glow[4]); } }
  return p; }
function inset(p,x,y,w,h,fill){ p.rect(x,y,w,h,fill); p.frame(x,y,w,h,K[0]); }
function cardBase(opts){ var arche=C.archetype(opts.arch&&opts.arch[0])||null, arch2=opts.arch&&opts.arch[1]?C.archetype(opts.arch[1]):null;
  var priRamp=arche?P[arche.pri]:P.iron, secRamp=arche?P[arche.sec]:P.silver;
  var p=frameFor(opts.rarity||'common',priRamp);
  /* art window */
  var il=A.px(A.illustration(opts.motif||'generic', arche?arche.id:'guardian')); if(!arche) { il=il.clone(); il.recolor({}); }
  p.blit(il,4,4);
  /* name plaque (parchment, brass rails) */
  var plq=arche2color(arche,arch2);
  p.rect(4,50,64,19,P.parch[3]); p.frame(4,50,64,19,K[0]); p.hline(5,51,62,P.parch[4]); p.hline(5,67,62,P.parch[1]);
  if(arch2){ p.rect(5,68,31,1,P[arche.pri][3]); p.rect(36,68,31,1,P[arch2.pri][3]); } else p.rect(5,68,62,1,priRamp[3]);
  /* type strip */
  p.rect(4,71,64,9,priRamp[0]); p.frame(4,71,64,9,K[0]); p.hline(5,72,62,priRamp[2]);
  /* chips band: dark inset with parchment ticks */
  inset(p,4,82,64,18,K[1]); p.hline(5,83,62,priRamp[1]); p.dither(5,84,62,15,null,priRamp[0],.35);
  /* cost medallion */
  p.shadeDisc(11,11,8,P.brass,{dither:false}); p.ring(11,11,7,1,P.brass[1]); p.outline(K[0]);
  /* archetype plate */
  p.rect(53,4,15,15,K[0]); p.bevel(54,5,13,13,secRamp,{fill:secRamp[1],hi:4,lo:0});
  if(arche){ p.blit(A.px(A.emblem(arche.emblem,arche.pri,arche.sec)),55,6); if(arch2){ p.blit(A.px(A.emblem(arch2.emblem,arch2.pri,arch2.sec)).crop(0,0,11,11),55,6); } }
  else { p.ellipse(60.5,11.5,3,3,P.iron[3]); p.ellipse(60,11,1.5,1.5,P.iron[4]); }
  /* rarity gems (bottom-right of type strip) */
  var n={common:1,rare:2,epic:3,legendary:4}[opts.rarity||'common']||1, gem={common:P.silver,rare:P.brass,epic:P.wax,legendary:P.glow}[opts.rarity||'common'];
  for(var i=0;i<n;i++){ var gx=64-i*6; p.rect(gx-1,73,5,5,K[0]); p.rect(gx,74,3,3,gem[3]); p.set(gx,74,gem[4]); p.set(gx+2,76,gem[1]); }
  return p; }
function arche2color(){ return null; }
A.cardFace=function(opts){ var k='cav.card.face.'+(opts.rarity||'common')+'.'+(opts.arch||[]).join('+')+'.'+(opts.motif||'generic'); if(!A.has(k)) A.define(k,function(){ return cardBase(opts); }); return k; };
A.CARD={w:CW,h:CH,art:{x:4,y:4,w:64,h:44},name:{x:4,y:50,w:64,h:19},type:{x:4,y:71,w:64,h:9},chips:{x:4,y:82,w:64,h:18},cost:{cx:11,cy:11,r:8}};

/* ================= CARD THUMBNAIL (24x34): frame + cropped art + rarity gem; used in binders and reveal trays ================= */
A.cardThumb=function(opts){ var k='cav.card.thumb.'+(opts.rarity||'common')+'.'+(opts.arch&&opts.arch[0]||'none')+'.'+(opts.motif||'generic')+(opts.locked?'.locked':''); if(!A.has(k)) A.define(k,function(){
  var ar=C.archetype(opts.arch&&opts.arch[0]), fr=P[(C.rarities[opts.rarity||'common']||C.rarities.common).ramp], p=new Px(24,34);
  p.bevel(0,0,24,34,fr,{fill:fr[2],hi:4,lo:0}); p.frame(0,0,24,34,K[0]);
  if(opts.locked){ p.rect(2,2,20,30,K[1]); p.dither(2,2,20,30,K[1],P.iron[0],.4); p.rect(10,10,4,3,P.iron[3]); p.rect(11,13,2,3,P.iron[3]); p.rect(11,18,2,2,P.iron[3]); return p; }
  var il=A.px(A.illustration(opts.motif||'generic', ar?ar.id:'guardian')); p.blit(il.crop(21,3,20,24),2,2); p.frame(2,2,20,24,K[0]);
  p.rect(2,27,20,5,P[ar?ar.pri:'iron'][1]); p.frame(2,27,20,5,K[0]);
  var n={common:1,rare:2,epic:3,legendary:4}[opts.rarity||'common']||1, gem={common:P.silver,rare:P.brass,epic:P.wax,legendary:P.glow}[opts.rarity||'common'];
  for(var i=0;i<n;i++){ p.rect(4+i*4,29,3,2,gem[3]); p.set(4+i*4,29,gem[4]); }
  return p.shadow('#00000066',1,1); }); return k; };

/* ================= BOOSTER PACKS (30x44, top-down flat) ================= */
function pack(archId,state){ var ar=C.archetype(archId)||C.archetype('guardian'), pri=P[ar.pri], sec=P[ar.sec], W=30, H=44, p=new Px(W,H), r=C.rng(C.hash(archId));
  var top=state==='open'?7:3;
  /* foil body with crimped (zig-zag) top & bottom seals */
  p.rect(0,top,W,H-top-3,pri[2]); p.gradient(1,top,W-2,H-top-3,[pri[1],pri[2],pri[3]],{horizontal:true});
  for(var x=0;x<W;x+=2){ if(state!=='open'){ p.rect(x,0,2,3,pri[3]); p.set(x,0,pri[4]); p.rect(x+(x/2%2),1,1,2,pri[1]); } p.rect(x,H-3,2,3,pri[3]); p.set(x,H-3,pri[4]); p.set(x+1,H-1,pri[1]); }
  p.hline(0,top,W,pri[4]); p.vline(0,top,H-top-3,pri[4]); p.vline(W-1,top,H-top-3,pri[1]);
  /* merchant band top + bottom */
  p.rect(0,top+2,W,4,P.brass[2]); p.hline(0,top+2,W,P.brass[4]); p.hline(0,top+5,W,P.brass[1]); for(var bx=2;bx<W;bx+=4) p.set(bx,top+3,P.brass[4]);
  p.rect(0,H-10,W,3,P.brass[2]); p.hline(0,H-10,W,P.brass[4]);
  /* illustration plate */
  p.shadeDisc(15,22,10,sec,{dither:false}); p.ring(15,22,9,1,pri[1]); p.ring(15,22,10,1,K[0]);
  var em=A.px(A.emblem(ar.emblem,ar.pri,ar.sec)); p.blit(em,Math.floor(15-em.w/2)+0,Math.floor(22-em.h/2));
  /* foil streak */ for(var y=top+7;y<H-11;y++){ var sx=(y*0.6+4)|0; if(sx%30<3 && ((y&1)===0)) p.set(sx%W,y,pri[4]); }
  /* pips = rarity guarantee (3) */ for(var i=0;i<3;i++){ p.rect(11+i*4,H-8,3,3,K[0]); p.rect(12+i*4,H-7,1,1,P.brass[4]); }
  if(state==='open'){ p.poly([[0,top],[3,top-4],[7,top-1],[11,top-5],[15,top-1],[20,top-4],[24,top-1],[30,top-3],[30,top]],pri[3]); p.rect(2,top-3,26,2,P.K[1]); }
  return p.outline(K[0]).shadow('#00000066',1,1); }
/* compact pack (22x32) for catalogue thumbnails */
A.packMini=function(archId){ var k='cav.pack.mini.'+archId; if(!A.has(k)) A.define(k,function(){ var ar=C.archetype(archId)||C.archetype('guardian'), pri=P[ar.pri], sec=P[ar.sec], p=new Px(22,32);
  p.rect(0,2,22,28,pri[2]); p.gradient(1,2,20,28,[pri[1],pri[2],pri[3]],{horizontal:true}); p.hline(0,2,22,pri[4]); p.vline(0,2,28,pri[4]);
  for(var x=0;x<22;x+=2){ p.rect(x,0,2,2,pri[3]); p.set(x,0,pri[4]); p.rect(x,30,2,2,pri[3]); p.set(x,30,pri[4]); }
  p.rect(0,4,22,3,P.brass[2]); p.hline(0,4,22,P.brass[4]); p.rect(0,25,22,2,P.brass[2]);
  p.shadeDisc(11,16,7,sec,{dither:false}); p.ring(11,16,6.5,1,pri[1]); p.blit(A.px(A.emblem(ar.emblem,ar.pri,ar.sec)),Math.floor(11-5.5),Math.floor(16-5.5));
  return p.outline(K[0]).shadow('#00000066',1,1); }); return k; };
A.pack=function(archId,state){ var k='cav.pack.'+archId+'.'+(state||'sealed'); if(!A.has(k)) A.define(k,function(){ return pack(archId,state||'sealed'); }); return k; };
})();
