/* CAV.objects — registry of every physical desk object: sprite keys per state, bounds, layer, behaviour flags.
   This registry IS the integration contract for desk objects (exported to contracts/objects.json by tools/export-contracts.js).
   A host owns WHICH objects exist and WHERE they are (instances); this file only says what each id looks like and how it may be handled.
   state keys: rest | open | empty | full.  sprite(inst,state,ctx) may be dynamic (clock hands, parcel state). */
(function(){
var C=window.CAV, A=C.art, O=C.objects=C.objects||{};
/* z bands: default stacking before the player moves anything */
O.LAYER={ flat:10, paper:100, cards:140, book:200, storage:250, prop:300, tall:400 };
var D=O.defs={};
function reg(id,o){ o.id=id; D[id]=o; return o; }
function S(k){ return function(){ return k; }; }
/* ---- existing core objects (ids kept from the rail desk so hosts keep working) ---- */
reg('appointment',{family:'book',layer:'book',sprite:S('cav.obj.appointment'),openable:true,action:'appointment',stage:1});
reg('catalog',{family:'book',layer:'book',sprite:S('cav.obj.catalog'),openable:true,action:'catalog',stage:1});
reg('album',{family:'album',layer:'book',sprite:S('cav.obj.album'),openable:true,action:'album',stage:2});
reg('deck',{family:'cards',layer:'cards',sprite:S('cav.obj.deck'),openable:true,action:'deck',stage:1});
reg('relic',{family:'relicContainer',layer:'storage',sprite:S('cav.obj.relic'),openable:true,action:'relic',stage:2});
reg('enchant',{family:'enchantTool',layer:'prop',sprite:S('cav.obj.enchant'),openable:true,action:'enchant',stage:3});
reg('ledger',{family:'book',layer:'book',sprite:S('cav.obj.ledger'),openable:true,action:'ledger',stage:1});
reg('mail',{family:'correspondence',layer:'storage',sprite:S('cav.obj.mail'),openable:true,action:'mail',stage:1});
reg('calendar',{family:'paper',layer:'paper',sprite:S('cav.obj.calendar'),openable:true,action:'calendar',stage:1});
reg('clock',{family:'clock',layer:'prop',sprite:function(inst,st,ctx){ var m=(ctx&&ctx.minutes)||570, h=Math.floor(m/60), mm=Math.floor(m%60/10)*10; return inst.variant==='brass'?A.clock(h,mm):A.clockWood(h,mm); },openable:true,action:'clock',stage:1,variants:['wood','brass']});
reg('parcel',{family:'delivery',layer:'storage',sprite:function(inst){ return A.parcel(inst.open?'open':'closed',inst.seed||1); },openable:true,action:'parcel',stage:1});
/* ---- stationery (stage I) ---- */
reg('pencil',{family:'stationery',layer:'prop',sprite:S('cav.o.stationery.pencil'),stage:1,inspect:true});
reg('inkwell',{family:'stationery',layer:'prop',sprite:S('cav.o.stationery.inkwell'),stage:1,inspect:true});
reg('notepad',{family:'stationery',layer:'paper',sprite:S('cav.o.stationery.notepad'),stage:1,inspect:true,text:{x:3,y:6,w:16,h:21}});
reg('blotter',{family:'stationery',layer:'flat',sprite:S('cav.o.stationery.blotter'),stage:2});
reg('magnifier',{family:'tool',layer:'prop',sprite:S('cav.o.tool.magnifier'),stage:2,inspect:true});
reg('sealwax',{family:'tool',layer:'prop',sprite:S('cav.o.tool.sealwax'),stage:2,inspect:true});
/* ---- storage ---- */
function store(id,closed,open,empty,cap,stage,w){ reg(id,{family:'storage',layer:'storage',storage:{capacity:cap,accepts:['paper','cards','correspondence','prop']},
  sprite:function(inst){ var n=(inst.contents||[]).length; return !inst.open?closed:(n?open:(empty||open)); },anchor:'bottom',stage:stage,openable:true,action:'toggle'}); }
store('cardcase','cav.o.storage.cardcase','cav.o.storage.cardcase.open','cav.o.storage.cardcase.empty',8,1);
store('folder','cav.o.storage.folder','cav.o.storage.folder.open','cav.o.storage.folder.open',6,2);
store('chest','cav.o.storage.chest','cav.o.storage.chest.open','cav.o.storage.chest.open',12,3);
reg('organizer',{family:'storage',layer:'storage',storage:{capacity:9,accepts:['paper','correspondence'],alwaysOpen:true},sprite:S('cav.o.storage.organizer'),stage:2,openable:true,action:'toggle'});
/* ---- books ---- */
reg('book_manual',{family:'book',layer:'book',sprite:S('cav.o.book.manual'),stage:2,inspect:true});
reg('book_opening',{family:'book',layer:'book',sprite:S('cav.o.book.opening'),stage:2,inspect:true});
reg('book_field',{family:'book',layer:'book',sprite:S('cav.o.book.field'),stage:3,inspect:true});
reg('book_arcane',{family:'book',layer:'book',sprite:S('cav.o.book.arcane'),stage:4,inspect:true});
/* ---- decor, trophies, relic containers ---- */
reg('mug',{family:'decor',layer:'prop',sprite:S('cav.o.decor.mug'),stage:2});
reg('lamp',{family:'decor',layer:'tall',sprite:S('cav.o.decor.lamp'),stage:3});
reg('candle',{family:'decor',layer:'prop',sprite:S('cav.o.decor.candle'),stage:4});
reg('trophy_cup',{family:'trophy',layer:'tall',sprite:S('cav.o.trophy.cup'),stage:2,inspect:true});
reg('medal',{family:'trophy',layer:'prop',sprite:S('cav.o.trophy.medal'),stage:3,inspect:true});
reg('casket',{family:'relicContainer',layer:'storage',sprite:S('cav.o.relic.casket'),stage:4,openable:true,action:'relic'});
reg('orrery',{family:'relicContainer',layer:'tall',sprite:S('cav.o.relic.orrery'),stage:4,inspect:true});
reg('moonglass',{family:'relicContainer',layer:'prop',sprite:S('cav.o.relic.moonglass'),stage:4,inspect:true});
/* ---- correspondence: one def, instance.kind selects the family member ---- */
reg('letter',{family:'correspondence',layer:'paper',kinds:O.letterKinds,sprite:function(inst){ return A.letter(inst.kind||'ordinary',!!inst.open); },text:null,stage:1,openable:true,action:'letter',inspect:true});

/* ---- helpers shared by engine + contract export ---- */
O.def=function(id){ return D[id]; };
O.spriteKey=function(inst,ctx,state){ var d=D[inst.id]; return d.sprite(inst,state||'rest',ctx); };
O.size=function(inst,ctx){ return A.size(O.spriteKey(inst,ctx)); };
O.hit=function(w,h){ var MIN=22; return {padX:Math.max(0,Math.ceil((MIN-w)/2)),padY:Math.max(0,Math.ceil((MIN-h)/2))}; };   /* >= 22 virtual px = 44 CSS px at 2x: comfortable touch target */
O.contract=function(){ var out={ version:'v4-visual/objects@1', layers:O.LAYER, letterText:O.letterText, objects:[] };
  Object.keys(D).forEach(function(id){ var d=D[id], states={}, inst, variants=[];
    var probe=function(i,tag){ var k=d.sprite(i,'rest',{minutes:570}); var s=A.size(k); states[tag]={sprite:k,w:s.w,h:s.h}; };
    if(id==='letter'){ d.kinds.forEach(function(kd){ probe({id:id,kind:kd},'closed:'+kd); probe({id:id,kind:kd,open:true},'open:'+kd); }); }
    else if(d.storage&&!d.storage.alwaysOpen){ probe({id:id},'closed'); probe({id:id,open:true,contents:[1]},'open'); probe({id:id,open:true,contents:[]},'empty'); }
    else if(id==='clock'){ probe({id:id,variant:'wood'},'wood'); probe({id:id,variant:'brass'},'brass'); }
    else if(id==='parcel'){ probe({id:id},'closed'); probe({id:id,open:true},'open'); }
    else probe({id:id},'rest');
    var first=states[Object.keys(states)[0]], hit=O.hit(first.w,first.h);
    out.objects.push({id:id,family:d.family,layer:d.layer,layerZ:O.LAYER[d.layer],states:states,hitPadding:hit,anchor:d.anchor||'topleft',openable:!!d.openable,storage:d.storage||null,inspect:!!d.inspect,textArea:d.text||null,minStage:d.stage,
      interactionStates:['rest','selected','dragging','dropped','inspect'].concat(d.storage?['open','empty']:[])}); });
  return out; };
})();
