/* Top-down desk art: the walnut desk surface and every physical object that sits on it.
   Strict 90° orthographic view: no visible front faces. Light from the TOP-LEFT, hard 1px outline K0, baked hard shadow. */
(function(){
var C=window.CAV, P=C.pal, Px=C.Px, A=C.art;
var SH='#00000066';
function finish(p,sh){ p.outline(P.K[0]); p.shadow(SH,sh||1,sh||1); return p; }
function leather(p,x,y,w,h,ramp,seed){ var r=C.rng(seed||3); p.rect(x,y,w,h,ramp[2]);
  for(var i=0;i<w*h/9;i++){ var px=x+r.int(0,w-1), py=y+r.int(0,h-1); p.set(px,py,r()<.5?ramp[1]:ramp[3]); }
  p.hline(x,y,w,ramp[3]); p.vline(x,y,h,ramp[3]); p.hline(x,y+h-1,w,ramp[1]); p.vline(x+w-1,y,h,ramp[1]); p.set(x,y,ramp[4]); }
function brassCorner(p,x,y,s,fx,fy){ for(var j=0;j<s;j++) for(var i=0;i<s;i++){ if(i+j>s+1) continue; var X=fx?x-i:x+i, Y=fy?y-j:y+j;
    p.set(X,Y,(i===0||j===0)?P.brass[4]:(i+j>=s+1?P.brass[1]:P.brass[3])); } p.set(fx?x-1:x+1,fy?y-1:y+1,P.brass[2]); }
function rectCorners(p,x,y,w,h,s){ brassCorner(p,x,y,s,0,0); brassCorner(p,x+w-1,y,s,1,0); brassCorner(p,x,y+h-1,s,0,1); brassCorner(p,x+w-1,y+h-1,s,1,1); }
function disc(p,cx,cy,r,ramp,o){ p.shadeDisc(cx,cy,r,ramp,o); }

/* ============ DESK SURFACE (walnut planks, top-down) ============ */
A.desk=function(vw,vh){ var k='cav.desk@'+vw+'x'+vh; if(!A.has(k)) A.define(k,function(){
  var p=new Px(vw,vh), r=C.rng(11), W=P.walnut, ph=30, y=0, row=0;
  while(y<vh){ var h=Math.min(ph,vh-y), off=(row*37)%90, base=[W[2],W[3],W[2],W[1]][row%4];
    p.rect(0,y,vw,h,base);
    for(var g=0;g<h*vw/38;g++){ var gx=r.int(0,vw-1), gy=y+r.int(1,h-2), len=r.int(6,26); p.hline(gx,gy,Math.min(len,vw-gx),r()<.55?W[1]:W[3]); }
    for(var g2=0;g2<4;g2++){ var kx=r.int(10,vw-10), ky=y+r.int(7,h-8); if(r()<.4){ p.ellipse(kx,ky,3,2,W[1]); p.ellipse(kx-.5,ky-.5,2,1,W[0]); p.hline(kx-6,ky-3,12,W[3]); p.hline(kx-7,ky+3,14,W[1]); } }
    /* plank seam: dark groove + light lip */
    p.hline(0,y,vw,W[0]); p.hline(0,y+1,vw,W[3]);
    for(var j=off;j<vw;j+=r.int(140,230)){ p.vline(j,y+1,h-1,W[0]); p.vline(j+1,y+1,h-1,W[3]); }
    y+=h; row++; }
  /* wear + ink stains + vignette via sparse dithering */
  for(var s=0;s<3;s++){ var sx=r.int(20,vw-30), sy=r.int(20,vh-30), rad=r.int(5,9); p.dither(sx-rad,sy-rad,rad*2,rad*2,null,W[0],.0); for(var yy=-rad;yy<=rad;yy++) for(var xx=-rad;xx<=rad;xx++){ var d=Math.hypot(xx,yy); if(d<rad && r()<.25*(1-d/rad)) p.set(sx+xx,sy+yy,P.navy[1]+'99'); } }
  var vg=Math.round(Math.min(vw,vh)*.16);
  for(var i=0;i<vg;i++){ var d=.5*(1-i/vg); p.dither(i,i,vw-2*i,1,null,'#000',d); p.dither(i,vh-1-i,vw-2*i,1,null,'#000',d); p.dither(i,i,1,vh-2*i,null,'#000',d); p.dither(vw-1-i,i,1,vh-2*i,null,'#000',d); }
  return p; }); return k; };

/* ============ OBJECTS ============ */
A.define('cav.obj.appointment',function(){ var p=new Px(28,36), O=P.oxblood;
  leather(p,0,0,26,34,O,5); p.rect(0,0,5,34,O[1]); p.vline(5,0,34,O[0]); p.vline(0,0,34,O[3]);
  [5,12,19,26].forEach(function(y){ p.rect(0,y,5,2,P.brass[3]); p.hline(0,y,5,P.brass[4]); p.hline(0,y+1,5,P.brass[1]); });
  p.frame(8,3,15,28,P.brass[2]); p.frame(9,4,13,26,P.brass[1]);
  /* tiny calendar emblem: header bar + 3x3 cells */
  p.rect(11,8,10,9,P.paper[3]); p.rect(11,8,10,2,P.brass[3]); p.hline(11,8,10,P.brass[4]);
  for(var j=0;j<3;j++) for(var i=0;i<3;i++) p.rect(12+i*3,11+j*2,2,1,(i+j)%4===1?P.wax[3]:P.paper[0]);
  p.frame(11,8,10,9,P.K[0]);
  p.rect(12,21,8,1,P.brass[3]); p.rect(14,23,4,1,P.brass[2]);
  rectCorners(p,0,0,26,34,3);
  /* ribbon */ p.rect(16,34,3,5,P.wax[3]); p.vline(16,34,5,P.wax[4]); p.vline(18,34,5,P.wax[1]); p.set(17,38,null); p.set(17,37,P.K[0]);
  return finish(p,1); });

A.define('cav.obj.catalog',function(){ var p=new Px(34,38), L=P.leather;
  p.rect(2,2,31,35,P.parch[2]); p.rect(2,2,31,1,P.parch[4]);                      /* pages peek out right + bottom */
  for(var i=0;i<35;i+=2) p.set(32,2+i,P.parch[1]);
  leather(p,0,0,31,35,L,9); p.rect(0,0,4,35,L[1]); p.vline(4,0,35,L[0]);
  [5,12,19,26,32].forEach(function(y){ p.hline(0,y,4,P.brass[3]); p.hline(0,y+1,4,P.brass[1]); });
  p.frame(7,3,21,29,P.brass[2]);
  /* merchant insignia: coin + scales + star points */
  disc(p,18,17,7,P.brass,{dither:false}); p.ring(18,17,5.5,1,P.brass[1]); p.ring(18,17,3,1,P.brass[4]);
  p.rect(17,14,2,7,P.brass[1]); p.hline(14,15,8,P.brass[1]); p.rect(14,16,2,2,P.brass[1]); p.rect(20,16,2,2,P.brass[1]);
  [[18,8],[18,26],[10,17],[26,17]].forEach(function(q){ p.set(q[0],q[1],P.brass[4]); });
  rectCorners(p,0,0,31,35,3);
  /* strap + clasp across the fore-edge */
  p.rect(26,13,7,6,L[0]); p.rect(27,14,5,4,L[3]); p.rect(29,15,2,2,P.brass[4]);
  return finish(p,1); });

function cardBack(w,h,seed){ var p=new Px(w,h); p.bevel(0,0,w,h,P.navy,{fill:P.navy[2],hi:3,lo:1});
  p.frame(2,2,w-4,h-4,P.brass[3]); p.frame(3,3,w-6,h-6,P.brass[1]);
  for(var y=5;y<h-5;y++) for(var x=5;x<w-5;x++){ if(((x+y)%4===0)||((x-y+64)%4===0)) p.set(x,y,P.navy[3]); }
  var cx=Math.floor(w/2), cy=Math.floor(h/2); disc(p,cx,cy,5,P.brass,{dither:false}); p.ring(cx,cy,4,1,P.brass[1]);
  p.rect(cx-1,cy-2,2,4,P.navy[1]); p.rect(cx-2,cy-1,4,2,P.navy[1]); p.set(cx-1,cy-2,P.brass[4]);
  return p; }
A.cardBack=function(w,h){ var k='cav.card.back@'+w+'x'+h; if(!A.has(k)) A.define(k,function(){return cardBack(w,h)}); return k; };
A.define('cav.obj.deck',function(){ var p=new Px(26,34);
  for(var i=3;i>=0;i--){ var b=cardBack(22,30); p.blit(b,i*1,i*1); if(i>0){ p.rect(i+21,i+2,1,28,P.paper[2]); p.rect(i+2,i+29,20,1,P.paper[1]); } }
  return finish(p,1); });

A.define('cav.obj.album',function(){ var p=new Px(32,36), F=P.forest;
  p.rect(0,0,30,34,F[2]); for(var y=0;y<34;y++) for(var x=0;x<30;x++){ if(((x+y*2)%5===0)) p.set(x,y,F[1]); if(((x*2+y)%7===0)) p.set(x,y,F[3]); }   /* cloth weave */
  p.hline(0,0,30,F[4]); p.vline(0,0,34,F[4]); p.hline(0,33,30,F[0]); p.vline(29,0,34,F[0]);
  p.rect(0,0,6,34,P.leather[2]); p.vline(6,0,34,P.K[0]); p.vline(0,0,34,P.leather[4]);             /* leather spine */
  [4,11,18,25,31].forEach(function(y){ disc(p,3,y,2.2,P.brass,{dither:false}); });                 /* binder rings */
  p.rect(10,4,16,9,P.tarnish[2]); p.frame(10,4,16,9,P.tarnish[4]); p.hline(10,12,16,P.tarnish[0]);   /* label plate */
  p.rect(12,7,12,1,P.K[0]); p.rect(14,9,8,1,P.K[1]);
  var cb=cardBack(10,14); p.blit(cb,16,17); p.blit(cb,13,19);                                       /* two cards poking out */
  rectCorners(p,6,0,24,34,2);
  return finish(p,1); });

A.define('cav.obj.relic',function(){ var p=new Px(36,26), W=P.walnut;
  p.bevel(0,0,34,24,P.leather,{fill:P.leather[2],hi:4,lo:0});
  for(var i=0;i<24;i+=2) p.hline(1,i,32,i%4?P.leather[3]:P.leather[1]);
  p.frame(3,3,28,18,P.brass[2]); p.frame(4,4,26,16,P.brass[1]);
  disc(p,17,12,6,P.brass,{dither:false}); p.ring(17,12,4.5,1,P.brass[1]);
  p.rect(16,9,2,6,P.K[1]); p.rect(14,11,6,2,P.K[1]); p.set(16,9,P.brass[4]);                         /* medallion with a tiny pawn-cross */
  p.rect(0,3,3,5,P.brass[3]); p.rect(0,16,3,5,P.brass[3]); p.rect(31,3,3,5,P.brass[2]); p.rect(31,16,3,5,P.brass[2]);   /* hinges (top edge = back) */
  p.rect(14,22,6,3,P.brass[3]); p.hline(14,22,6,P.brass[4]); p.rect(16,23,2,1,P.K[0]);                /* clasp */
  return finish(p,1); });

A.define('cav.obj.enchant',function(){ var p=new Px(34,30);
  p.bevel(0,0,32,28,P.leather,{fill:P.leather[1],hi:3,lo:0}); p.dither(2,2,28,24,P.leather[1],P.leather[2],.35);
  p.frame(2,2,28,24,P.brass[1]);
  /* wax stick */ p.poly([[4,6],[7,4],[22,18],[19,20]],P.wax[2]); p.poly([[4,6],[7,4],[9,6],[6,8]],P.wax[4]); p.line(7,5,20,18,P.wax[3]); p.line(5,8,18,20,P.wax[1]);
  /* seal stamp */ disc(p,22,8,5,P.brass,{dither:false}); p.ring(22,8,3.5,1,P.brass[1]); p.rect(20,7,5,1,P.brass[1]); p.rect(22,5,1,6,P.brass[1]);
  /* wax puddle with imprint */ disc(p,10,21,4,P.wax,{dither:false}); p.ring(10,21,2.5,1,P.wax[1]); p.set(10,21,P.wax[4]);
  /* ink pot (top view) */ disc(p,26,21,4,P.navy,{dither:false}); p.ring(26,21,3,1,P.navy[4]); p.ring(26,21,4,1,P.silver[1]); p.set(25,20,P.silver[4]);
  return finish(p,1); });

A.define('cav.obj.ledger',function(){ var p=new Px(28,36), F=P.forest;
  p.rect(0,0,26,34,F[2]); for(var y=0;y<34;y++) for(var x=0;x<26;x++){ if((x*3+y)%6===0) p.set(x,y,F[1]); }
  p.hline(0,0,26,F[4]); p.vline(0,0,34,F[3]); p.hline(0,33,26,F[0]); p.vline(25,0,34,F[0]);
  p.rect(0,0,5,34,P.leather[2]); p.vline(5,0,34,P.K[0]); p.vline(0,0,34,P.leather[4]);
  p.rect(9,6,13,10,P.parch[3]); p.frame(9,6,13,10,P.bronze[2]); p.rect(11,9,9,1,P.K[1]); p.rect(11,12,6,1,P.K[1]);   /* label */
  p.rect(0,0,26,3,P.leather[2]); p.hline(0,0,26,P.leather[4]); p.rect(0,31,26,3,P.leather[1]); p.hline(0,31,26,P.leather[3]);   /* leather head/tail */
  rectCorners(p,0,0,26,34,2);
  return finish(p,1); });

function envelope(w,h,seal,seed){ var p=new Px(w,h); p.rect(0,0,w,h,P.paper[3]); p.hline(0,0,w,P.paper[4]); p.hline(0,h-1,w,P.paper[1]); p.vline(w-1,0,h,P.paper[1]);
  for(var x=0;x<w/2;x++){ var y=Math.round(x*(h*.55)/(w/2)); p.set(x,y,P.paper[1]); p.set(w-1-x,y,P.paper[1]); }
  if(seal){ disc(p,Math.floor(w/2),Math.round(h*.55),2.2,P.wax,{dither:false}); }
  return p.outline(P.K[0]); }
A.envelope=function(w,h,seal,tint){ var k='cav.env@'+w+'x'+h+(seal?'s':'')+(tint||''); if(!A.has(k)) A.define(k,function(){ var p=envelope(w,h,seal); if(tint==='blue') p.recolor({'#e1d9c3':P.steel[4],'#f3eddc':P.steel[4],'#fffcf0':'#c8dcea','#c2b79c':P.steel[2]}); return p; }); return k; };
A.define('cav.obj.mail',function(){ var p=new Px(34,28);
  p.bevel(0,0,32,26,P.walnut,{fill:P.walnut[2],hi:4,lo:0}); p.rect(2,2,28,22,P.walnut[1]); p.frame(2,2,28,22,P.walnut[0]);
  p.blit(A.px(A.envelope(18,12,false)),4,10,{}); p.blit(A.px(A.envelope(18,12,true,'blue')),10,6); p.blit(A.px(A.envelope(18,12,true)),7,12);
  p.rect(0,22,32,4,P.walnut[3]); p.hline(0,22,32,P.walnut[4]);                                       /* tray lip */
  return finish(p,1); });

A.define('cav.obj.calendar',function(){ var p=new Px(26,30);
  p.rect(0,0,24,28,P.paper[3]); p.hline(0,0,24,P.paper[4]); p.vline(0,0,28,P.paper[4]); p.hline(0,27,24,P.paper[1]); p.vline(23,0,28,P.paper[1]);
  p.rect(0,0,24,7,P.wax[2]); p.hline(0,0,24,P.wax[4]); p.hline(0,6,24,P.wax[1]);
  [4,11,18].forEach(function(x){ p.rect(x,-0+1,2,4,P.K[0]); p.rect(x,2,2,1,P.silver[3]); });         /* binding rings */
  p.rect(0,24,24,4,P.parch[2]); p.hline(0,24,24,P.parch[1]);                                          /* stacked sheets below */
  for(var i=0;i<4;i++) p.set(2+i*6,25+(i%2),P.parch[0]);
  p.hline(3,26,18,P.parch[0]);
  return finish(p,1); });

A.clock=function(h,m){ var k='cav.obj.clock@'+h+':'+m; if(!A.has(k)) A.define(k,function(){ var p=new Px(32,32), cx=15.5, cy=15.5;
  disc(p,cx+.5,cy+.5,15.5,P.brass,{dither:false}); p.ring(cx+.5,cy+.5,13.2,1,P.brass[1]); disc(p,cx+.5,cy+.5,12,P.ivory,{dither:false});
  p.ring(cx+.5,cy+.5,12,1,P.ivory[1]);
  for(var i=0;i<12;i++){ var a=i*Math.PI/6, r1=i%3===0?9.2:10.4, r2=11.2; p.line(Math.round(cx+.5+Math.sin(a)*r1),Math.round(cy+.5-Math.cos(a)*r1),Math.round(cx+.5+Math.sin(a)*r2),Math.round(cy+.5-Math.cos(a)*r2),i%3===0?P.K[0]:P.ivory[0]); }
  var ma=m/60*2*Math.PI, ha=((h%12)+m/60)/12*2*Math.PI, X=Math.round(cx+.5), Y=Math.round(cy+.5);
  p.line(X,Y,Math.round(X+Math.sin(ha)*6),Math.round(Y-Math.cos(ha)*6),P.K[0]); p.line(X+1,Y,Math.round(X+1+Math.sin(ha)*6),Math.round(Y-Math.cos(ha)*6),P.K[0]);
  p.line(X,Y,Math.round(X+Math.sin(ma)*10),Math.round(Y-Math.cos(ma)*10),P.K[1]);
  p.rect(X-1,Y-1,2,2,P.wax[3]);
  /* twin bells on top edge */ p.rect(7,0,5,2,P.brass[3]); p.rect(20,0,5,2,P.brass[3]);
  return finish(p,1); }); return k; };

/* parcels: brown paper + twine + wax seal + label; state 'closed' | 'open'; size parametric (default 34x28) */
A.parcel=function(state,seed,W,H){ W=W||34; H=H||28; var k='cav.obj.parcel.'+state+'.'+(seed||0)+'@'+W+'x'+H; if(!A.has(k)) A.define(k,function(){ var p=new Px(W,H), r=C.rng(40+(seed||0)), w=W-2, h=H-2, cx=Math.floor(w/2), cy=Math.floor(h/2);
  var paper=[P.parch[0],'#9b7a4e','#b8935f','#cfa974','#e2c18c'];
  p.rect(0,0,w,h,paper[2]); for(var i=0;i<w*h/12;i++) p.set(r.int(1,w-2),r.int(1,h-2),r()<.5?paper[1]:paper[3]);
  p.hline(0,0,w,paper[4]); p.vline(0,0,h,paper[3]); p.hline(0,h-1,w,paper[0]); p.vline(w-1,0,h,paper[1]);
  if(state==='closed'){
    p.vline(cx,0,h,P.parch[4]); p.vline(cx+1,0,h,P.parch[1]); p.hline(0,cy,w,P.parch[4]); p.hline(0,cy+1,w,P.parch[1]);
    var lw=Math.max(10,Math.floor(w*.32)), lh=Math.max(7,Math.floor(h*.26)); p.rect(w-lw-3,h-lh-3,lw,lh,P.paper[3]); p.frame(w-lw-3,h-lh-3,lw,lh,P.bronze[1]); p.rect(w-lw-1,h-lh-1,lw-4,1,P.K[1]); p.rect(w-lw-1,h-lh+2,lw-6,1,P.K[1]);
    disc(p,cx+.5,cy+.5,Math.max(3.5,w/10),P.wax,{dither:false}); p.ring(cx+.5,cy+.5,Math.max(2,w/16),1,P.wax[1]);
  } else {
    p.poly([[0,0],[cx,cy],[0,h]],paper[3]); p.poly([[w,0],[cx,cy],[w,h]],paper[1]); p.line(0,0,cx,cy,paper[0]); p.line(0,h,cx,cy,paper[0]);
    var iw=Math.floor(w*.45), ih=Math.floor(h*.5); p.rect(cx-iw/2,cy-ih/2,iw,ih,P.felt[1]); p.frame(cx-iw/2,cy-ih/2,iw,ih,P.felt[0]); p.rect(cx-iw/2+2,cy-ih/2+2,iw-4,ih-4,P.felt[2]);
  }
  return finish(p,1); }); return k; };

/* wall-less top-down items for overlays */
A.define('cav.obj.inkwell',function(){ var p=new Px(12,12); disc(p,6,6,5.5,P.navy,{dither:false}); p.ring(6,6,3.5,1,P.silver[1]); p.set(5,4,P.silver[4]); return finish(p,1); });
A.define('cav.obj.coin',function(){ var p=new Px(10,10); disc(p,5,5,4.5,P.brass,{dither:false}); p.ring(5,5,3.2,1,P.brass[1]); p.rect(4,3,2,4,P.brass[1]); p.set(4,3,P.brass[4]); return finish(p,0).outline(P.K[0]); });
})();
