/* CAV.appointmentBook — physical, top-down open diary. Pure view: it never decides whether a match can be accepted or moved;
   it reports the player's intent through callbacks and re-renders from the props the host passes to update().
   props: see contracts/CONTRACTS.md §AppointmentBook */
(function(){
var C=window.CAV, h=C.h, A=C.art, ui=C.ui, T=C.t;
function pad(n){ return (n<10?'0':'')+n; }
function wk(lang){ var f=new Intl.DateTimeFormat(lang,{weekday:'narrow',timeZone:'UTC'}), o=[]; for(var i=0;i<7;i++) o.push(f.format(new Date(Date.UTC(2026,0,4+i)))); return o; }
function wkLong(lang,i){ return new Intl.DateTimeFormat(lang,{weekday:'long',timeZone:'UTC'}).format(new Date(Date.UTC(2026,0,4+i))); }
function portraitCrop(id){ var k='cav.portrait.crop.'+id; if(!A.has(k)) A.define(k,function(){ var q=A.px(C.portraitKey(id)).crop(6,4,16,16).clone(); return q.pad(1,1,1,1).outline(C.pal.K[0]).crop(0,0,18,18); }); return k; }
function stars(n){ var w=h('span',{class:'bk-stars','aria-label':T('cav.book.diff')+' '+n}); for(var i=0;i<4;i++){ var s=ui.icon('star'); if(i>=n) s.style.opacity='.25'; w.appendChild(s); } return w; }
C.appointmentBook={
 create:function(props){ var P=Object.assign({appointments:[],proposals:[],availableSlots:[10,11,12,13,14,15],selectedDate:null,calendar:null,opponents:{},canPlayNow:function(){return false;}},props), S={tab:'day',sel:null,placing:null,flash:null,date:null};
  S.date=P.selectedDate||(P.calendar&&P.calendar.today)||1;
  var el=h('div',{class:'cav-book'}), spreadEl=null, L=h('div',{class:'bk-page bk-left'}), R=h('div',{class:'bk-page bk-right'}), tabs=h('div',{class:'bk-tabs'}), closeBtn;
  function size(){ var st=C.stage.get(), w=Math.min(400,st.vw-Math.max(6,st.safe.l+st.safe.r)-22), hh=Math.min(224,st.vh-Math.max(6,st.safe.t+st.safe.b)-6); return {w:w,h:hh}; }
  function opp(id){ return P.opponents[id]||{name:id,portrait:'clerk',diff:1,reward:0}; }
  function apptsOn(d){ return P.appointments.filter(function(a){ return a.date===d; }); }
  function slotList(d){ var s=P.availableSlots; if(s&&!Array.isArray(s)) s=s.byDate&&s.byDate[d]||s.default; return s||[]; }
  function layout(){ var sz=size(), W=sz.w, H=sz.h; el.style.setProperty('--bw',W); el.style.setProperty('--bh',H); el.style.width='calc(var(--u)*'+W+')'; el.style.height='calc(var(--u)*'+H+')';
    if(spreadEl) spreadEl.remove(); spreadEl=A.el(A.bookSpread(W,H,'appointment'),'bk-spread'); el.insertBefore(spreadEl,el.firstChild);
    var mid=Math.floor(W/2), m=8; place(L,m,m,mid-m-8,H-2*m); place(R,mid+8,m,W-m-(mid+8),H-2*m); }
  function place(e,x,y,w,hh){ e.style.cssText='left:calc(var(--u)*'+x+');top:calc(var(--u)*'+y+');width:calc(var(--u)*'+w+');height:calc(var(--u)*'+hh+')'; }
  /* ---- left page: month calendar ---- */
  function renderLeft(){ L.innerHTML=''; var cal=P.calendar||{label:'',firstWeekday:0,daysInMonth:30,today:1}, lang=C.i18n.lang();
    var head=h('div',{class:'bk-calhead'},[ui.btn({icon:'left',kind:'wood',aria:T('cav.book.prev'),disabled:!P.onChangeMonth,onClick:function(){ P.onChangeMonth&&P.onChangeMonth(-1); }}),h('div',{class:'bk-month cav-fill cav-c cav-up',text:cal.label}),ui.btn({icon:'right',kind:'wood',aria:T('cav.book.next'),disabled:!P.onChangeMonth,onClick:function(){ P.onChangeMonth&&P.onChangeMonth(1); }})]);
    var wd=h('div',{class:'bk-wd'}); (cal.weekdays||wk(lang)).forEach(function(d){ wd.appendChild(h('span',{text:d})); });
    var g=h('div',{class:'bk-days',role:'grid'}); for(var i=0;i<cal.firstWeekday;i++) g.appendChild(h('span',{class:'bk-day empty'}));
    for(var d=1;d<=cal.daysInMonth;d++){ (function(d){ var as=apptsOn(d), conflict=as.some(function(a){return a.status==='conflict'}), closed=(cal.closedDays||[]).indexOf(d)>=0, past=d<cal.today;
      var b=h('button',{type:'button',class:'bk-day'+(d===S.date?' is-sel':'')+(d===cal.today?' is-today':'')+(past?' is-past':'')+(closed?' is-closed':'')+(S.placing&&!past&&!closed?' is-place':''),role:'gridcell','aria-label':T('cav.day',{n:d})+(as.length?', '+as.length:'')+(conflict?', '+T('cav.book.conflict'):'')+(closed?', '+T('cav.book.closed'):'')},[h('span',{class:'bk-dn',text:String(d)})]);
      var dots=h('span',{class:'bk-dots'}); as.slice(0,3).forEach(function(a){ dots.appendChild(h('i',{class:'bk-dot '+(a.status==='conflict'?'c':'')})); }); if(as.length) b.appendChild(dots);
      if(d===S.date) b.insertBefore(A.el(A.stampFrame(20,16,'wax'),'bk-ring'),b.firstChild);
      b.addEventListener('click',function(){ C.sfx('book.page'); S.date=d; S.sel=null; S.tab='day'; if(P.onSelectDate) P.onSelectDate(d); render(); }); g.appendChild(b); })(d); }
    var leg=h('div',{class:'bk-legend'},[h('span',{class:'bk-dot'}),h('span',{text:T('cav.book.accepted').toLowerCase()}),h('span',{class:'bk-dot c'}),h('span',{text:T('cav.book.conflict').toLowerCase()})]);
    L.appendChild(head); L.appendChild(wd); L.appendChild(g); L.appendChild(leg); }
  /* ---- right page ---- */
  function rowAppt(a,slot){ var o=opp(a.opponent||a.opp), row=h('button',{type:'button',class:'bk-row appt s-'+a.status+(S.sel===a.id?' is-sel':'')+(S.placing&&S.placing.id===a.id?' is-moving':''),'aria-label':o.name+' '+pad(slot)+':00'});
    row.appendChild(h('span',{class:'bk-time',text:pad(slot)+':00'})); row.appendChild(A.el(portraitCrop(o.portrait),'bk-pt'));
    row.appendChild(h('span',{class:'bk-info'},[h('span',{class:'bk-name cav-ell',text:o.name}),h('span',{class:'bk-meta'},[stars(o.diff),ui.icon('coin'),h('span',{text:String(o.reward)})])]));
    if(a.status==='conflict') row.appendChild(h('span',{class:'bk-flag c',title:T('cav.book.conflict')},[ui.icon('close')])); else if(a.status==='accepted') row.appendChild(h('span',{class:'bk-flag ok'},[ui.icon('check')]));
    row.addEventListener('click',function(){ C.sfx('book.tap'); S.sel=(S.sel===a.id?null:a.id); render(); }); return row; }
  function rowFree(slot,d){ var pl=!!S.placing, row=h('button',{type:'button',class:'bk-row free'+(pl?' is-place':''),'aria-label':T('cav.book.free')+' '+pad(slot)+':00'});
    row.appendChild(h('span',{class:'bk-time',text:pad(slot)+':00'})); row.appendChild(h('span',{class:'bk-freetxt cav-fill',text:pl?T('cav.book.pickSlot'):T('cav.book.free')}));
    row.addEventListener('click',function(){ if(!pl) return; var pc=S.placing; S.placing=null; S.flash={id:pc.id,kind:'accept'}; if(pc.kind==='accept'&&P.onAccept) P.onAccept(pc.id,{date:d,slot:slot}); else if(pc.kind==='move'&&P.onReschedule) P.onReschedule(pc.id,{date:d,slot:slot}); stamp(pc.kind==='accept'?'accepted':'accepted'); render(); }); return row; }
  function stamp(kind){ S.stamp=kind; setTimeout(function(){ S.stamp=null; var s=el.querySelector('.bk-stamp'); if(s) s.remove(); },1100); }
  function renderDay(){ var cal=P.calendar||{today:1}, d=S.date, as=apptsOn(d), wdn=((P.calendar?P.calendar.firstWeekday:0)+d-1)%7, lang=C.i18n.lang();
    var hd=h('div',{class:'bk-dayhead'},[h('span',{class:'cav-up',text:wkLong(lang,wdn)+' '+d}),h('span',{class:'cav-dim',text:d===cal.today?T('cav.today'):''})]);
    var list=h('div',{class:'bk-slots'}); var closed=(cal.closedDays||[]).indexOf(d)>=0;
    if(closed) list.appendChild(h('div',{class:'bk-empty',text:T('cav.book.closed')})); else slotList(d).forEach(function(s){ var a=as.filter(function(x){return x.slot===s;}); if(a.length){ a.forEach(function(x){ list.appendChild(rowAppt(x,s)); }); } else list.appendChild(rowFree(s,d)); });
    var bar=h('div',{class:'bk-bar'}); var selA=S.sel&&P.appointments.filter(function(x){return x.id===S.sel})[0];
    if(S.placing){ bar.appendChild(h('span',{class:'cav-fill cav-ell',text:T('cav.book.pickSlot')})); bar.appendChild(ui.btn({label:T('cav.book.cancelMove'),kind:'wood',onClick:function(){ S.placing=null; render(); }})); }
    else if(selA){ bar.appendChild(ui.btn({label:T('cav.book.move'),kind:'wood',icon:'right',onClick:function(){ S.placing={kind:'move',id:selA.id}; render(); }}));
      if(P.canPlayNow(selA)&&P.onPlay) bar.appendChild(ui.btn({label:T('cav.book.play'),kind:'forest',icon:'check',onClick:function(){ P.onPlay(selA.id); }})); }
    else if(!as.length&&!closed) bar.appendChild(h('span',{class:'cav-dim',text:T('cav.book.noMatches')}));
    R.appendChild(hd); R.appendChild(list); R.appendChild(bar); }
  function renderReq(){ var hd=h('div',{class:'bk-dayhead'},[h('span',{class:'cav-up',text:T('cav.book.requests')}),h('span',{class:'cav-dim',text:String(P.proposals.length)})]), list=h('div',{class:'bk-reqs cav-scroll'});
    if(!P.proposals.length) list.appendChild(h('div',{class:'bk-empty',text:T('cav.book.noRequests')}));
    P.proposals.forEach(function(p){ var o=opp(p.opponent||p.opp), conflict=apptsOn(p.date).some(function(a){return a.slot===p.slot;});
      var row=h('div',{class:'bk-req'+(conflict?' has-conflict':'')},[A.el(portraitCrop(o.portrait),'bk-pt'),
        h('span',{class:'bk-info'},[h('span',{class:'bk-name cav-ell',text:o.name}),h('span',{class:'bk-meta'},[h('span',{text:T('cav.day',{n:p.date})+' · '+pad(p.slot)+':00'})]),h('span',{class:'bk-meta'},[stars(o.diff),ui.icon('coin'),h('span',{text:String(o.reward)}),conflict?h('span',{class:'cav-wax',text:' '+T('cav.book.conflict')}):null])]),
        h('span',{class:'bk-acts'},[ui.btn({icon:'check',kind:'forest',aria:T('cav.book.accept')+' '+o.name,onClick:function(){ if(conflict){ S.date=p.date; S.tab='day'; S.placing={kind:'accept',id:p.id}; render(); } else { S.flash={id:p.id}; if(P.onAccept) P.onAccept(p.id,{date:p.date,slot:p.slot}); stamp('accepted'); render(); } }}),
          ui.btn({icon:'close',kind:'wax',aria:T('cav.book.decline')+' '+o.name,onClick:function(){ if(P.onDecline) P.onDecline(p.id); stamp('declined'); render(); }})])]); list.appendChild(row); });
    R.appendChild(hd); R.appendChild(list); }
  function renderTabs(){ tabs.innerHTML=''; [['day','cav.book.day','navy'],['req','cav.book.requests','wax']].forEach(function(t){ var on=S.tab===t[0], b=h('button',{type:'button',class:'bk-tab'+(on?' on':''),'aria-label':T(t[1]),'aria-selected':on?'true':'false'});
      b.appendChild(A.el(A.tab(t[2],on))); b.appendChild(h('span',{class:'bk-tabic'},[ui.icon(t[0]==='day'?'book':'mail')])); if(t[0]==='req'&&P.proposals.length) b.appendChild(h('span',{class:'cav-badge',text:String(P.proposals.length)}));
      b.addEventListener('click',function(){ S.tab=t[0]; S.placing=null; C.sfx('book.page'); render(true); }); tabs.appendChild(b); }); }
  function render(flip){ renderLeft(); R.innerHTML=''; if(S.tab==='day') renderDay(); else renderReq(); renderTabs();
    if(S.stamp){ var st=h('div',{class:'bk-stamp '+S.stamp},[A.el(A.stampFrame(70,22,S.stamp==='accepted'?'forest':'wax')),h('span',{text:T('cav.book.'+S.stamp)})]); R.appendChild(st); }
    if(flip&&!C.reducedMotion()){ R.classList.remove('bk-flip'); void R.offsetWidth; R.classList.add('bk-flip'); } }
  closeBtn=ui.btn({icon:'close',kind:'wax',aria:T('cav.close'),cls:'bk-close',onClick:function(){ if(P.onClose) P.onClose(); }});
  el.appendChild(L); el.appendChild(R); el.appendChild(tabs); el.appendChild(closeBtn);
  layout(); render();
  var unsub=C.stage.on('resize',function(){ layout(); render(); });
  return { el:el, update:function(p){ Object.assign(P,p); if(p.selectedDate!=null) S.date=p.selectedDate; render(); }, state:function(){ return S; }, destroy:function(){ unsub(); el.remove(); } }; },
 open:function(props){ var book, ov, orig=props.onClose; props=Object.assign({},props,{onClose:function(){ ov.close('book'); if(orig) orig(); }}); book=C.appointmentBook.create(props);
   ov=ui.overlay.open({id:'appointment',bare:true,content:book.el,noClose:false,onClose:function(){ book.destroy(); }}); book.overlay=ov; return book; }
};
})();
