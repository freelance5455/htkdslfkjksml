/* UI art: 9-slice frames (paper, wood, brass plaque, buttons), tiled textures, 9x9 icons, enchantment seals.
   Frames are exported to CSS custom properties (--cav-img-*) so plain CSS can use border-image with integer slicing. */
(function(){
var C=window.CAV, P=C.pal, Px=C.Px, A=C.art, K=P.K;

/* ---- frames: size 12x12, 4px slice ---- */
function frame9(o){ var n=12, p=new Px(n,n), k=P.K[0];
  p.rect(0,0,n,n,o.fill||o.ramp[2]);
  p.frame(0,0,n,n,k);
  p.frame(1,1,n-2,n-2,o.ramp[o.rim||3]);                                  /* lit rim */
  p.hline(1,n-2,n-2,o.ramp[1]); p.vline(n-2,1,n-2,o.ramp[1]);             /* shaded bottom/right rim */
  p.frame(2,2,n-4,n-4,o.ramp[o.inner!=null?o.inner:0]);                   /* inner line */
  if(o.studs){ [[1,1],[n-2,1],[1,n-2],[n-2,n-2]].forEach(function(q){ p.set(q[0],q[1],o.studs[3]); }); p.set(1,1,o.studs[4]); }
  p.set(0,0,null); p.set(n-1,0,null); p.set(0,n-1,null); p.set(n-1,n-1,null);   /* notched corners = pixel-rounded */
  return p; }
function buttonFrame(ramp,state){ var n=12, p=new Px(n,n), k=P.K[0];
  var down=state==='down', dis=state==='dis', fill=dis?P.iron[1]:(down?ramp[2]:ramp[3]), hi=dis?P.iron[2]:(down?ramp[1]:ramp[4]), lo=dis?P.iron[0]:(down?ramp[4]:ramp[1]);
  p.rect(0,0,n,n,fill); p.frame(0,0,n,n,k); p.hline(1,1,n-2,hi); p.vline(1,1,n-2,hi); p.hline(1,n-2,n-2,lo); p.vline(n-2,1,n-2,lo);
  if(!down&&!dis){ p.hline(2,2,n-4,ramp[4]); } 
  p.set(0,0,null); p.set(n-1,0,null); p.set(0,n-1,null); p.set(n-1,n-1,null); return p; }
A.define('cav.ui.frame.paper',function(){ return frame9({ramp:P.parch,fill:P.parch[3],rim:4,inner:1,studs:null}); });
A.define('cav.ui.frame.paperDark',function(){ return frame9({ramp:P.parch,fill:P.parch[2],rim:3,inner:0}); });
A.define('cav.ui.frame.wood',function(){ return frame9({ramp:P.walnut,fill:P.walnut[1],rim:3,inner:0,studs:P.brass}); });
A.define('cav.ui.frame.leather',function(){ return frame9({ramp:P.leather,fill:P.leather[1],rim:3,inner:0,studs:P.brass}); });
A.define('cav.ui.frame.plaque',function(){ return frame9({ramp:P.brass,fill:P.brass[2],rim:4,inner:1}); });
A.define('cav.ui.frame.ink',function(){ return frame9({ramp:P.navy,fill:P.navy[1],rim:3,inner:0}); });
A.define('cav.ui.frame.slot',function(){ var p=frame9({ramp:P.walnut,fill:P.K[1],rim:1,inner:0}); p.frame(1,1,10,10,P.K[0]); p.hline(1,10,10,P.walnut[3]); p.vline(10,1,10,P.walnut[3]); return p; });
['brass','wood','wax','forest'].forEach(function(nm){ var r={brass:P.brass,wood:P.walnut,wax:P.wax,forest:P.forest}[nm]; ['up','down','dis'].forEach(function(s){ A.define('cav.ui.btn.'+nm+'.'+s,function(){ return buttonFrame(r,s); }); }); });

/* ---- tiled textures (16x16) ---- */
function tile(fill,a,b,seed,dens){ var p=new Px(16,16), r=C.rng(seed); p.rect(0,0,16,16,fill); for(var i=0;i<(dens||18);i++) p.set(r.int(0,15),r.int(0,15),r()<.5?a:b); return p; }
A.define('cav.ui.tile.paper',function(){ var p=tile(P.parch[3],P.parch[2],P.parch[4],1,22); for(var i=0;i<3;i++) p.set(i*5+2,(i*7)%16,P.parch[1]); return p; });
A.define('cav.ui.tile.paperDark',function(){ return tile(P.parch[2],P.parch[1],P.parch[3],2,22); });
A.define('cav.ui.tile.wood',function(){ var p=tile(P.walnut[1],P.walnut[0],P.walnut[2],3,14); p.hline(0,5,10,P.walnut[2]); p.hline(5,11,11,P.walnut[0]); return p; });
A.define('cav.ui.tile.leather',function(){ return tile(P.leather[1],P.leather[0],P.leather[2],4,26); });
A.define('cav.ui.tile.felt',function(){ return tile(P.felt[1],P.felt[0],P.felt[2],5,30); });
A.define('cav.ui.tile.ink',function(){ return tile(P.navy[1],P.navy[0],P.navy[2],6,16); });
A.define('cav.ui.scrim',function(){ var p=new Px(4,4); p.dither(0,0,4,4,null,'#0d0807',.6); return p; });

/* ---- 9x9 icons ---- */
var ICON={
 coin:    ['..ooooo..','.occcccco','occhcsscs','occhsccsc','occhccscc','occhsccsc','occhcsscs','.occccsso','..ooooo..'],
 energy:  ['....o....','...ogo...','..ogggo..','.ogghggo.','ogghgggso','.ogggsso.','..ogsso..','...oso...','....o....'],
 draw:['.ooooo...','.owwwo...','.owwwoooo','.owwwowwo','.ooooowwo','....owwwo','....owwwo','....owwwo','....ooooo'],
 target:  ['...ooo...','.oo.t.oo.','o..ttt..o','o.t.t.t.o','otttotttto','o.t.t.t.o','o..ttt..o','.oo.t.oo.','...ooo...'],
 hourglass:['.ooooooo.','.ogggggo.','..ogggo..','...ogo...','....o....','...osso...','..osssso..','.osssssso.','.ooooooo.'],
 flame:   ['....o....','...oro...','...orro..','..orryro.','.orryyyro','.orryyyro','.orryyyro','..orrrro.','...oooo..'],
 shield:  ['.ooooooo.','oglllllso','ogllllsso','oglllssso','.oglsssso.','.ogssssso','..ogsso..','...oso...','....o....'],
 move:['....o....','...ogo...','.o..g..o.','og..g..go','ogggggggo','og..g..go','.o..g..o.','...ogo...','....o....'],
 up:['....o....','...ogo...','..ogggo..','.ogggggo.','ooogggooo','..ogggo..','..ogggo..','..ogggo..','..ooooo..'],
 box:['....o....','...ogo...','..og.go..','....g....','ooooooooo','osccccsso','osccccsso','osccccsso','ooooooooo'],
 lock:    ['..oooo...','.ogggso..','.og..so..','oooooooo.','ogggggsso','ogggkgsso','ogggkgsso','osssssss.','.oooooooo'],
 check:   ['.........','.......ok','......oko','.....oko.','o...oko..','oko.oko..','.okoko...','..oko....','...o.....'],
 close:   ['.........','.oo...oo.','.owo.owo.','..owowo..','...owo...','..owowo..','.owo.owo.','.oo...oo.','.........'],
 left:['.....oo..','....owwo.','...owwwwo','..owwwwwo','.owwwwwwo','..owwwwwo','...owwwwo','....owwo.','.....oo..'],
 right:['..oo.....','.owwo....','owwwwo...','owwwwwo..','owwwwwwo.','owwwwwo..','owwwwo...','.owwo....','..oo.....'],
 gear:    ['...ooo...','o.ogggo.o','.oggsggo.','oggo.oggo','ogs...sgo','oggo.oggo','.oggsggo.','o.ogggo.o','...ooo...'],
 parcel:  ['.ooooooo.','oppppppwo','oppppwppo','owwwwwwwo','oppppwppo','oppppwppo','oppppwppo','oppppwppo','.ooooooo.'],
 star:    ['....o....','...oyo...','...oyo...','ooooyoooo','oyyyyyyyo','.oyyyyyo.','..oyyyo..','.oyyoyyo.','.ooo.ooo.'],
 eye:     ['.........','..ooooo..','.owwwwwo.','owwoiowwo','owwiiiwwo','owwoiowwo','.owwwwwo.','..ooooo..','.........'],
 book:    ['.ooooooo.','obbbobbbo','obwbobwbo','obbbobbbo','obwbobwbo','obbbobbbo','obwbobwbo','obbbobbbo','.ooooooo.'],
 funnel:  ['ooooooooo','owwwwwwwo','.owwwwwo.','..owwwo..','...owo...','...owo...','...owo...','...ooo...','.........'],
 skull:   ['..ooooo..','.owwwwwo.','owwwwwwwo','owooowoo.','owooowoow','.owwwwwo.','..owowo..','..owwwo..','...ooo...'],
 plus:    ['.........','...ooo...','...owo...','.ooowooo.','.owwwwwo.','.ooowooo.','...owo...','...ooo...','.........'],
 minus:   ['.........','.........','.........','.ooooooo.','.owwwwwo.','.ooooooo.','.........','.........','.........'],
 mail:    ['.........','ooooooooo','owwwwwwwo','owowwwowo','owwowowwo','owwwowwwo','owwwwwwwo','ooooooooo','.........'],
 sort:    ['.........','.owwwwwo.','.ooooooo.','.owwwwo..','.oooooo..','.owwwo...','.ooooo...','.........','.........'],
 dot:     ['.........','.........','..ooo....','.owwwo...','.owwwo...','.owwwo...','..ooo....','.........','.........']
};
var ICOL={ o:P.K[0], w:P.ivory[3], g:P.brass[3], l:P.steel[3], s:P.brass[1], c:P.brass[3], h:P.brass[4], t:P.teal[4], r:P.crimson[3], y:P.amber[4], k:P.felt[4], p:P.leather[3], b:P.parch[3], i:P.violet[3], f:P.steel[2] };
A.icon=function(name,tint){ var k='cav.icon.'+name+(tint?'.'+tint:''); if(!A.has(k)) A.define(k,function(){ var rows=ICON[name]; if(!rows) throw new Error('icon '+name);
  var map=Object.assign({},ICOL); if(name==='coin'){ map.s=P.brass[1]; map.c=P.brass[3]; map.h=P.brass[4]; }
  if(name==='energy'){ map.g=P.teal[4]; map.h=P.ivory[4]; map.s=P.teal[2]; }
  if(name==='shield'){ map.g=P.steel[4]; map.l=P.steel[3]; map.s=P.steel[1]; }
  if(name==='lock'){ map.g=P.iron[4]; map.s=P.iron[2]; map.k=P.K[0]; }
  if(name==='flame'){ map.r=P.crimson[3]; map.y=P.amber[4]; }
  if(name==='draw'){ map.w=P.paper[3]; }
  if(name==='hourglass'){ map.g=P.silver[3]; map.s=P.brass[3]; }
  if(name==='check'){ map.k=P.felt[4]; }
  if(name==='gear'){ map.g=P.brass[3]; map.s=P.brass[1]; }
  if(name==='parcel'){ map.p=P.bronze[3]; map.w=P.parch[4]; }
  if(tint){ var T={ink:P.K[1],paper:P.parch[4],brass:P.brass[4],wax:P.wax[4]}[tint]; if(T){ map.w=T; map.g=T; map.o=P.K[0]; } }
  return Px.fromRows(rows,map); }); return k; };
A.icons=Object.keys(ICON);

/* ---- enchantment seals (13x13): wax disc + glyph; colour family + glyph shape both carry meaning ---- */
var SEAL={
 honed:     {r:'steel',  g:function(p,c){ p.line(c,3,c,9,'#eef1f7'); p.line(c-2,7,c,9,'#eef1f7'); p.line(c+2,7,c,9,'#eef1f7'); }},                    /* ↓ cost */
 gilded:    {r:'brass',  g:function(p,c){ p.ellipse(c+.5,c+.5,3.2,3.2,P.brass[4]); p.ring(c+.5,c+.5,3.2,1,P.brass[1]); p.rect(c,c-1,2,4,P.brass[1]); }},
 swift:     {r:'teal',   g:function(p,c){ p.line(c-3,3,c,6,'#e0f2ee'); p.line(c,6,c-3,9,'#e0f2ee'); p.line(c,3,c+3,6,'#e0f2ee'); p.line(c+3,6,c,9,'#e0f2ee'); }},        /* » */
 echoing:   {r:'violet', g:function(p,c){ p.ring(c+.5,c+.5,2.2,1,'#e6d8ff'); p.ring(c+.5,c+.5,4.2,1,'#c3a5f0'); p.set(c,c,'#fff'); }},
 unburdened:{r:'forest', g:function(p,c){ p.ring(c+.5,c+.5,3.4,1,'#d6efe0'); p.set(c+3,c-1,null); p.set(c+3,c,null); p.set(c+3,c+1,null); p.line(c+3,c-1,c+5,c-3,'#d6efe0'); }},
 volatile:  {r:'crimson',g:function(p,c){ p.poly([[c+1,2],[c-3,c+1],[c,c+1],[c-2,11],[c+3,c-1],[c,c-1]],'#ffd9a0'); }},
 charged:   {r:'amber',  g:function(p,c){ p.poly([[c,2],[c-3,c],[c,c],[c,11],[c+3,c-1],[c,c-1]],'#fff3c4'); p.set(c,c-1,'#fff3c4'); }},
 warding:   {r:'iron',   g:function(p,c){ p.poly([[c-3,3],[c+4,3],[c+4,c+1],[c+.5,10],[c-3,c+1]],'#dfe5ec'); p.line(c+.5,4,c+.5,9,P.iron[2]); }}
};
A.seal=function(id){ var k='cav.seal.'+id; if(!A.has(k)) A.define(k,function(){ var d=SEAL[id]||SEAL.honed, p=new Px(13,13), ramp=P[d.r]; p.shadeDisc(6.5,6.5,6,ramp.length?[ramp[0],ramp[1],ramp[2],ramp[3],ramp[3]]:ramp,{dither:false});
  p.ring(6.5,6.5,5,1,ramp[1]); d.g(p,6); p.outline(P.K[0]); return p; }); return k; };
A.sealIds=Object.keys(SEAL);
A.sealFamily=function(id){ return (SEAL[id]||{}).r; };


/* ---- hand-strip frames (8x8, 2px border) per rarity + cost badge ---- */
['common','rare','epic','legendary'].forEach(function(r){ A.define('cav.ui.frame.strip.'+r,function(){ var R=C.rarities[r], fr=P[R.ramp], p=new Px(8,8);
  p.rect(0,0,8,8,P.walnut[1]); p.frame(0,0,8,8,K[0]); p.frame(1,1,6,6,fr[3]); p.set(1,1,fr[4]); p.set(6,6,fr[1]); p.set(0,0,null); p.set(7,0,null); p.set(0,7,null); p.set(7,7,null); return p; }); });
A.define('cav.ui.costbadge',function(){ var p=new Px(11,11); p.shadeDisc(5.5,5.5,5,P.brass,{dither:false}); p.ring(5.5,5.5,4.2,1,P.brass[1]); return p.outline(K[0]); });
A.define('cav.ui.costbadge.dis',function(){ var p=new Px(11,11); p.shadeDisc(5.5,5.5,5,P.iron,{dither:false}); return p.outline(K[0]); });

/* ---- export frames/tiles as CSS vars ---- */
C.ui={ exportCSS:function(){ var r=document.documentElement.style;
  ['paper','paperDark','wood','leather','plaque','ink','slot'].forEach(function(n){ r.setProperty('--cav-f-'+n,'url('+A.url('cav.ui.frame.'+n)+')'); });
  ['brass','wood','wax','forest'].forEach(function(n){ ['up','down','dis'].forEach(function(s){ r.setProperty('--cav-b-'+n+'-'+s,'url('+A.url('cav.ui.btn.'+n+'.'+s)+')'); }); });
  ['paper','paperDark','wood','leather','felt','ink'].forEach(function(n){ r.setProperty('--cav-t-'+n,'url('+A.url('cav.ui.tile.'+n)+')'); });
  ['common','rare','epic','legendary'].forEach(function(n){ r.setProperty('--cav-f-strip-'+n,'url('+A.url('cav.ui.frame.strip.'+n)+')'); });
  r.setProperty('--cav-scrim','url('+A.url('cav.ui.scrim')+')'); } };
})();
