/* Open-book spreads, index tabs and ink stamps, generated at the exact virtual size needed (always integer-aligned).
   Strictly top-down: the SPINE RUNS VERTICALLY through the middle; pages are flat rectangles. */
(function(){
var C=window.CAV, P=C.pal, Px=C.Px, A=C.art, K=P.K;
var STYLE={ appointment:{cover:'oxblood',trim:'brass'}, catalog:{cover:'leather',trim:'brass'}, binder:{cover:'forest',trim:'brass'}, ledger:{cover:'forest',trim:'bronze'}, mail:{cover:'walnut',trim:'brass'} };
function spread(w,h,style){ var S=STYLE[style]||STYLE.appointment, cv=P[S.cover], tr=P[S.trim], p=new Px(w,h), r=C.rng(C.hash(style)+w);
  p.bevel(0,0,w,h,cv,{fill:cv[2],hi:3,lo:0}); for(var i=0;i<w*h/14;i++) p.set(r.int(1,w-2),r.int(1,h-2),r()<.5?cv[1]:cv[3]);
  p.frame(0,0,w,h,K[0]); p.set(0,0,null); p.set(w-1,0,null); p.set(0,h-1,null); p.set(w-1,h-1,null);
  var m=5, pw=(w-2*m), mid=Math.floor(w/2);
  /* page blocks: stacked edges to suggest thickness */
  p.rect(m,m,pw,h-2*m,P.parch[3]); p.frame(m-1,m-1,pw+2,h-2*m+2,K[0]);
  for(var e=0;e<3;e++){ p.vline(m+e,m+1,h-2*m-2,e%2?P.parch[2]:P.parch[1]); p.vline(w-m-1-e,m+1,h-2*m-2,e%2?P.parch[2]:P.parch[1]); }
  p.hline(m,h-m-1,pw,P.parch[1]); p.hline(m,h-m-2,pw,P.parch[2]);
  /* paper speckle */ for(var s=0;s<pw*h/30;s++) p.set(r.int(m+3,w-m-4),r.int(m+1,h-m-3),r()<.5?P.parch[4]:P.parch[2]);
  /* gutter: dark dithered fold */
  var g=7; for(var gx=0;gx<g;gx++){ var d=(g-gx)/g; p.dither(mid-1-gx,m,1,h-2*m,null,P.parch[0],d*.8); p.dither(mid+gx,m,1,h-2*m,null,P.parch[0],d*.8); }
  p.vline(mid-1,m,h-2*m,P.parch[0]); p.vline(mid,m,h-2*m,P.K[1]);
  if(style==='binder'){ for(var y=10;y<h-8;y+=Math.floor((h-16)/4)) { p.shadeDisc(mid-.5,y,3.2,P.brass,{dither:false}); p.ring(mid-.5,y,3.2,1,K[0]); } }
  /* corner trims */ [[0,0,0,0],[w-1,0,1,0],[0,h-1,0,1],[w-1,h-1,1,1]].forEach(function(q){ for(var i=0;i<7;i++){ p.set(q[2]?q[0]-i:q[0]+i,q[3]?q[1]-1:q[1]+1,tr[4]); p.set(q[2]?q[0]-1:q[0]+1,q[3]?q[1]-i:q[1]+i,tr[4]); p.set(q[2]?q[0]-i:q[0]+i,q[3]?q[1]-2:q[1]+2,tr[2]); p.set(q[2]?q[0]-2:q[0]+2,q[3]?q[1]-i:q[1]+i,tr[2]); } });
  /* page curl bottom-right */ for(var c=0;c<6;c++){ p.hline(w-m-1-c,h-m-1-(5-c),c+1,c<5?P.parch[4]:P.parch[1]); } p.line(w-m-6,h-m-1,w-m-1,h-m-6,P.parch[0]);
  /* ribbon marker in gutter */ if(style==='appointment'){ p.rect(mid-2,h-m,4,5,P.wax[3]); p.vline(mid-2,h-m,5,P.wax[4]); p.set(mid-1,h-m+4,null); p.set(mid,h-m+4,null); }
  return p.shadow('#00000088',2,2); }
A.bookSpread=function(w,h,style){ var k='cav.book.'+style+'@'+w+'x'+h; if(!A.has(k)) A.define(k,function(){ return spread(w,h,style); }); return k; };
A.BOOK={ margin:5, gutter:8 };   /* content insets used by CSS: page content begins margin+3 from the outer edge, 8px from the centre */

/* index tab: 14x24 coloured flap sticking out of the right edge (rounded outer corners) */
A.tab=function(ramp,on){ var k='cav.book.tab.'+ramp+(on?'.on':''); if(!A.has(k)) A.define(k,function(){ var r=P[ramp], p=new Px(on?16:13,24); p.rect(0,0,p.w,24,r[on?3:2]); p.hline(0,0,p.w,r[4]); p.hline(0,23,p.w,r[0]); p.vline(p.w-1,0,24,r[1]); p.set(p.w-1,0,null); p.set(p.w-1,23,null);
  p.dither(2,2,p.w-4,20,null,r[on?4:1],.15); p.outline(K[0]); return p.shadow('#00000066',1,1); }); return k; };
/* ink stamp frames (rectangular, double border). tone: forest | wax | iron */
A.stampFrame=function(w,h,tone){ var k='cav.stamp.'+tone+'@'+w+'x'+h; if(!A.has(k)) A.define(k,function(){ var r=P[tone]||P.wax, p=new Px(w,h), c=r[3]; p.frame(0,0,w,h,c); p.frame(2,2,w-4,h-4,c); p.set(0,0,null); p.set(w-1,0,null); p.set(0,h-1,null); p.set(w-1,h-1,null);
  var rr=C.rng(w*h); for(var i=0;i<w*h/10;i++){ var x=rr.int(0,w-1), y=rr.int(0,h-1); if(rr()<.5) p.set(x,y,null); } return p; }); return k; };
/* wax-sealed envelope + folded letter used by correspondence */
A.define('cav.obj.letter',function(){ var p=new Px(60,44); p.rect(0,0,60,44,P.paper[3]); p.hline(0,0,60,P.paper[4]); p.vline(0,0,44,P.paper[4]); p.hline(0,43,60,P.paper[1]); p.vline(59,0,44,P.paper[1]);
  for(var i=0;i<4;i++) p.hline(6,10+i*8,48-(i%2)*10,P.K[1]+'99'); return p.outline(K[0]).shadow('#00000066',1,1); });
})();
