/* People: one parametric frontal portrait composer (28x32) so every character shares proportions, lighting and outline.
   Add a character = add a spec object. Expressions: neutral | smile | frown | shock | sleepy.  Frontal 2D is an allowed exception to the top-down rule. */
(function(){
var C=window.CAV, P=C.pal, Px=C.Px, A=C.art, K=P.K;
var SKIN={ fair:['#7a4a3a','#a86d55','#cf9578','#e8b898','#f6d3b8'], tan:['#6d3f2a','#97593a','#bd7d52','#dba073','#efc196'],
           brown:['#3b2118','#5f3a28','#85543a','#a8704c','#c68e66'], deep:['#241410','#3d241a','#5a3828','#7a4f38','#98684c'] };
var HAIR={ black:['#0c0a0c','#1a171c','#2a2630','#3c3744','#554f5f'], brown:['#1d110a','#32200f','#4c3018','#6b4524','#8c5f35'], grey:['#4c4e55','#757882','#9a9da8','#bcc0c8','#dde0e6'],
           white:['#8a8c94','#b2b4bc','#d2d4da','#ebecf0','#fafafc'], red:['#3a140c','#5e2412','#8a3a1c','#b25a2a','#d98a4a'], blonde:['#6a4e1c','#94722a','#bf9a42','#dcbc66','#f1d78c'] };
var SUIT={ navy:P.navy, forest:P.forest, oxblood:P.oxblood, charcoal:P.iron, brown:P.leather, steel:P.steel, violet:P.violet, bronze:P.bronze };

function portrait(s){ var p=new Px(28,32), sk=SKIN[s.skin||'fair'], hr=HAIR[s.hair||'brown'], su=SUIT[s.suit||'navy'], child=s.age==='child', elder=s.age==='elder';
  var hx=14, hy=child?15:13, hr_=child?7:8;
  /* backdrop: dithered wall */
  p.rect(0,0,28,32,s.bg?P[s.bg][1]:P.ink?P.navy[1]:P.navy[1]); p.dither(0,0,28,32,s.bg?P[s.bg][1]:P.navy[1],s.bg?P[s.bg][2]:P.navy[2],.35); p.hline(0,31,28,K[0]);
  /* shoulders + shirt */
  var sy=child?25:23;
  p.poly([[1,32],[3,sy+1],[9,sy-1],[19,sy-1],[25,sy+1],[27,32]],su[2]); p.poly([[3,sy+1],[9,sy-1],[12,sy-1],[8,32],[1,32]],su[3]); p.poly([[19,sy-1],[25,sy+1],[27,32],[20,32]],su[1]);
  p.poly([[11,sy-1],[17,sy-1],[14,sy+6]],P.paper[3]); p.line(11,sy-1,14,sy+6,P.paper[1]);
  if(s.tie){ var tc=P[s.tie]||P.wax; p.rect(13,sy,2,2,tc[3]); p.poly([[13,sy+2],[15,sy+2],[16,32],[12,32]],tc[2]); p.vline(13,sy+2,6,tc[4]); }
  if(s.bowtie){ var bc=P[s.bowtie]; p.rect(11,sy,6,3,bc[3]); p.rect(13,sy,2,3,bc[1]); p.hline(11,sy,6,bc[4]); }
  if(s.medal){ p.shadeDisc(21,sy+4,2.2,P.brass,{dither:false}); p.rect(20,sy,2,2,P.wax[3]); }
  /* neck */
  p.rect(12,hy+hr_-2,5,sy-hy-hr_+3,sk[1]); p.rect(12,hy+hr_-2,5,2,sk[0]);
  /* head */
  p.shadeDisc(hx,hy,hr_,sk,{dither:false}); p.rect(hx-hr_+1,hy+1,hr_*2-2,hr_-2,sk[3]); p.shadeDisc(hx,hy+1,hr_-.5,sk,{dither:false});
  p.rect(hx-hr_,hy-1,2,3,sk[2]); p.rect(hx+hr_-2,hy-1,2,3,sk[1]);                                                     /* ears */
  /* hair */
  var hs=s.hairStyle||'short';
  if(hs==='short'||hs==='parted'){ p.poly([[hx-hr_-.5,hy+1],[hx-hr_,hy-3],[hx-3,hy-hr_-1],[hx+4,hy-hr_-1],[hx+hr_,hy-3],[hx+hr_+.5,hy+1],[hx+hr_-2,hy-2],[hx+2,hy-4],[hx-3,hy-3],[hx-hr_+2,hy-1]],hr[2]);
    p.hline(hx-4,hy-hr_,9,hr[4]); p.line(hx-hr_+1,hy-4,hx-2,hy-hr_,hr[3]); if(hs==='parted') p.line(hx-2,hy-hr_,hx-1,hy-3,hr[0]); }
  if(hs==='bob'||hs==='long'){ var ln=hs==='long'?9:5; p.poly([[hx-hr_-1,hy+ln],[hx-hr_-1,hy-3],[hx-3,hy-hr_-2],[hx+4,hy-hr_-2],[hx+hr_+1,hy-3],[hx+hr_+1,hy+ln],[hx+hr_-1,hy+ln-1],[hx+hr_-1,hy-2],[hx+2,hy-4],[hx-3,hy-3],[hx-hr_+1,hy-2],[hx-hr_+1,hy+ln-1]],hr[2]);
    p.hline(hx-4,hy-hr_-1,9,hr[4]); p.vline(hx-hr_-1,hy-2,ln+1,hr[3]); }
  if(hs==='bun'){ p.poly([[hx-hr_-.5,hy+1],[hx-hr_,hy-3],[hx-3,hy-hr_-1],[hx+4,hy-hr_-1],[hx+hr_,hy-3],[hx+hr_+.5,hy+1],[hx+hr_-2,hy-2],[hx+2,hy-4],[hx-3,hy-3],[hx-hr_+2,hy-1]],hr[2]); p.shadeDisc(hx,hy-hr_-2,3,hr,{dither:false}); p.hline(hx-4,hy-hr_,9,hr[4]); }
  if(hs==='bald'){ p.rect(hx-hr_,hy-1,2,4,hr[1]); p.rect(hx+hr_-2,hy-1,2,4,hr[1]); p.hline(hx-2,hy-hr_+1,4,sk[4]); }
  if(hs==='curls'){ for(var i=0;i<7;i++) p.shadeDisc(hx-6+i*2,hy-hr_+1+((i%2)?-1:0),2.4,hr,{dither:false}); p.rect(hx-hr_-1,hy-2,2,5,hr[2]); p.rect(hx+hr_-1,hy-2,2,5,hr[1]); }
  /* hat */
  if(s.hat==='fedora'){ p.ellipse(hx,hy-hr_+2,12,3,P.leather[1]); p.rect(hx-6,hy-hr_-4,12,6,P.leather[2]); p.rect(hx-6,hy-hr_-1,12,2,P.K[1]); p.hline(hx-5,hy-hr_-4,10,P.leather[4]); p.ellipse(hx-2,hy-hr_+1,8,1.6,P.leather[3]); }
  if(s.hat==='cap'){ p.ellipse(hx,hy-hr_+1,8.5,4,su[2]); p.rect(hx-9,hy-hr_+2,18,2,su[1]); p.hline(hx-6,hy-hr_-2,12,su[4]); }
  /* face */
  var ey=hy+(child?0:0), ex=child?3:3.5, wide=child?2:1.5;
  [-1,1].forEach(function(d){ var x=Math.round(hx+d*ex-(d>0?0:1)); p.rect(x-1,ey,3,2,P.paper[4]); p.rect(x+(d>0?0:0),ey,2,2,P.K[0]); p.set(x,ey,P.ebony[4]); });
  var br=s.brow||'flat'; [-1,1].forEach(function(d){ var x=Math.round(hx+d*ex-(d>0?0:1)); var by=ey-2;
     if(s.expr==='frown') { p.line(x-1+(d>0?0:0),by+(d>0?0:1),x+2,by+(d>0?1:0),hr[0]); } else if(s.expr==='shock'||s.expr==='sleepy'===false&&false){ p.hline(x-1,by-1,3,hr[0]); } else p.hline(x-1,by,3,hr[1]); });
  if(s.expr==='sleepy'){ [-1,1].forEach(function(d){ var x=Math.round(hx+d*ex-(d>0?0:1)); p.rect(x-1,ey,3,1,sk[2]); }); }
  p.rect(hx,ey+2,1,3,sk[1]); p.set(hx,ey+4,sk[0]);                                                                          /* nose */
  var my=hy+hr_-3, ex2=s.expr||'neutral';
  if(ex2==='smile'){ p.hline(hx-2,my,5,P.wax[1]); p.set(hx-3,my-1,P.wax[1]); p.set(hx+3,my-1,P.wax[1]); p.hline(hx-1,my+1,3,P.paper[4]); }
  else if(ex2==='frown'){ p.hline(hx-2,my,5,P.wax[0]); p.set(hx-3,my+1,P.wax[0]); p.set(hx+3,my+1,P.wax[0]); }
  else if(ex2==='shock'){ p.rect(hx-1,my,3,2,P.K[0]); } else p.hline(hx-2,my,4,P.wax[1]);
  if(elder){ p.hline(hx-5,ey-3,3,sk[1]); p.hline(hx+2,ey-3,3,sk[1]); p.set(hx-4,my-2,sk[1]); p.set(hx+4,my-2,sk[1]); }
  /* beard / moustache */
  var bd=s.beard; if(bd==='mustache'||bd==='full'||bd==='goatee'){ if(bd!=='goatee') p.poly([[hx-4,my-1],[hx,my-2],[hx+4,my-1],[hx+3,my+1],[hx,my],[hx-3,my+1]],hr[2]);
    if(bd==='full'){ p.poly([[hx-hr_+1,my-2],[hx-hr_+1,my+3],[hx-3,hy+hr_+1],[hx+3,hy+hr_+1],[hx+hr_-1,my+3],[hx+hr_-1,my-2],[hx+4,my+1],[hx-4,my+1]],hr[2]); p.hline(hx-3,hy+hr_,6,hr[1]); }
    if(bd==='goatee'){ p.rect(hx-1,my+2,3,3,hr[2]); p.hline(hx-3,my-1,7,hr[2]); } }
  if(s.glasses){ [-1,1].forEach(function(d){ var x=hx+d*ex+(d>0?0:-1); p.ring(x+1,ey+1,2.6,1,s.glasses==='gold'?P.brass[3]:P.K[0]); }); p.hline(hx-1,ey,2,P.K[0]); p.hline(hx-hr_,ey,2,P.K[0]); }
  if(s.blush) { p.set(hx-5,hy+3,P.wax[3]+'99'); p.set(hx+5,hy+3,P.wax[3]+'99'); }
  p.outline(K[0]); p.frame(0,0,28,32,K[0]); return p; }
A.portrait=function(spec,name){ var k='cav.portrait.'+(name||C.hash(JSON.stringify(spec))); if(!A.has(k)) A.define(k,function(){ return portrait(spec); }); return k; };

/* provisional cast (roles may be renamed by the gameplay dev). Opponents are ordinary human players in Acts I–II. */
C.people={
 protagonist:{skin:'tan',   hair:'brown',  hairStyle:'parted',suit:'brown', tie:'wax',   expr:'neutral',bg:'forest'},
 spouse:     {skin:'fair',  hair:'brown',  hairStyle:'bun',   suit:'steel', expr:'smile', bg:'amber', blush:true},
 child:      {skin:'tan',   hair:'brown',  hairStyle:'short', suit:'forest',expr:'smile', age:'child', bg:'teal'},
 parent:     {skin:'fair',  hair:'white',  hairStyle:'bald',  suit:'charcoal',beard:'mustache',glasses:'gold',expr:'sleepy',age:'elder',bg:'leather'},
 clerk:      {skin:'brown', hair:'black',  hairStyle:'short', suit:'forest',bowtie:'wax',expr:'neutral',bg:'navy'},
 opp_aldren: {skin:'fair',  hair:'grey',   hairStyle:'parted',suit:'navy',  tie:'brass', beard:'mustache',medal:true,expr:'neutral',bg:'oxblood'},
 opp_marta:  {skin:'brown', hair:'black',  hairStyle:'bob',   suit:'oxblood',glasses:'ink',expr:'smile',bg:'forest'},
 opp_teodoro:{skin:'tan',   hair:'red',    hairStyle:'short', suit:'charcoal',hat:'fedora',beard:'goatee',expr:'frown',bg:'navy'},
 opp_ines:   {skin:'deep',  hair:'black',  hairStyle:'curls', suit:'violet',expr:'neutral',bg:'amber'},
 opp_bruno:  {skin:'fair',  hair:'blonde', hairStyle:'bald',  suit:'brown', beard:'full',expr:'shock',bg:'leather'},
 opp_helena: {skin:'tan',   hair:'grey',   hairStyle:'bun',   suit:'steel', glasses:'gold',medal:true,expr:'neutral',bg:'navy'}
};
C.portraitKey=function(id){ return A.portrait(C.people[id]||C.people.clerk,id); };
})();
