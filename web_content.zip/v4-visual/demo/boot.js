/* CAV.boot: loads font, exports CSS art, starts stage + root. */
(function(){
var C=window.CAV;
C.boot=function(cb){
  var root=document.getElementById('cav-root'); if(!root){ root=C.h('div',{id:'cav-root'}); document.body.appendChild(root); }
  var go=function(){
    C.ui.exportCSS(); C.stage.init(); C.i18n.setLang(C.i18n.detect());
    if(C.reducedMotion()) root.classList.add('cav-rm');
    var rot=C.h('div',{id:'cav-rotate'},[C.art.el('cav.ui.phone','phone'),C.h('div',{class:'cav-t2 cav-brass',text:C.t('cav.rotate.title')}),C.h('div',{text:C.t('cav.rotate.body')})]);
    C.bus.on&&0; root.appendChild(rot); C.stage.on('resize',function(){ rot.children[1].textContent=C.t('cav.rotate.title'); rot.children[2].textContent=C.t('cav.rotate.body'); });
    C.settings.on('change',function(e){ if(e.key==='reducedMotion') root.classList.toggle('cav-rm',C.reducedMotion()); });
    cb(root); };
  if(document.fonts&&document.fonts.load){ Promise.race([document.fonts.load("11px 'CAV Pixel'"),new Promise(function(r){setTimeout(r,1500)})]).then(go,go); } else go();
};
})();
