/* Standalone demo wiring. Everything here is MOCK: it stands in for the real game host. The visual components never decide rules. */
(function(){
var C=window.CAV, M=C.mock, ui=C.ui, T=C.t, h=C.h;
var root, ws, menu, view=null, G=null, STAGE=1, INSTS=null;
function lsGet(k){ try{ return JSON.parse(localStorage.getItem(k)); }catch(e){ return null; } } function lsSet(k,v){ try{ localStorage.setItem(k,JSON.stringify(v)); }catch(e){} }
function loadInsts(){ INSTS=M.deckInstances(STAGE); var sv=lsGet('cav.demo.layout.'+STAGE)||{}; INSTS.forEach(function(i){ var q=sv[i.uid]; if(q){ i.nx=q.nx; i.ny=q.ny; i.z=q.z; i.open=q.open; if(q.in!==undefined) i.in=q.in; } }); }
function saveInsts(){ var o={}; INSTS.forEach(function(i){ if(i.nx!=null||i.open||i.in!==i.homeIn) o[i.uid]={nx:i.nx,ny:i.ny,z:i.z,open:!!i.open,in:i.in||null}; }); lsSet('cav.demo.layout.'+STAGE,o); }
function openSettings(){ C.screens.settings.open({stage:STAGE,onStage:function(n){ STAGE=n; INSTS=null; rebuild2(); },onReset:function(){ if(ws&&ws.free()) { ws.free().reset(); saveInsts(); } },onChange:function(){ if(ws) ws.refresh(); }, onLang:function(){ rebuild(); }}); }
function rebuild(){ if(ws){ var st=ws.state(); ws.destroy(); mountDesk(st); } }
function badges(){ return {appointment:M.proposals.length,mail:M.letters.filter(function(l){return!l.read}).length,parcel:M.parcels.length}; }
function rebuild2(){ if(ws){ var st=ws.state(); ws.destroy(); ws=null; mountDesk(st); } }
function clockTick(){ if(ws&&!G) ws.setMinutes(M.state.minutes); }

function mountDesk(prev){
  if(!INSTS) loadInsts();
  ws=C.screens.workstation.create({freeform:{insts:INSTS,onChange:saveInsts},state:Object.assign({day:M.state.day,minutes:M.state.minutes,doubloons:M.state.doubloons,badges:badges()},prev||{}),
    onObject:onObject,onSettings:openSettings,onHelp:function(){ C.screens.guide.open(); }});
  root.appendChild(ws.el); idleBoard(); }
function idleBoard(){ var s=fromFEN(START); ws.board.setPosition(s.b); ws.board.setSelected(null); ws.board.setTargets([]); ws.board.setLastMove(null); ws.board.setCheck(null); ws.onSquare=null; }

function resolve(){ return { card:function(id){ return M.cardDef(id); }, ench:function(id){ return M.enchDef(id); } }; }
function onObject(id){ if(id==='letter') return;
  if(G&&id!=='clock'&&id!=='calendar') return;
  switch(id){
  case 'appointment': C.appointmentBook.open({appointments:M.appointments,proposals:M.proposals,opponents:M.opponents,calendar:{label:'OCT 2026',firstWeekday:4,daysInMonth:31,today:M.state.day},selectedDate:M.state.day,
      canPlayNow:function(){return true;},onPlay:function(a){ startMatch(M.opponents[a.opp||a.opponent]||M.opponents.marta); },onAccept:function(){},onDecline:function(){},onReschedule:function(){}}); break;
  case 'catalog': C.catalog.open({inventory:M.catalog,balance:M.state.doubloons,ordered:{},resolve:resolve(),onOrder:function(){}}); break;
  case 'parcel': C.delivery.open({parcels:M.parcels,resolve:resolve(),onOpenParcel:function(){},onOpenPack:function(pid,idx){ var it=M.parcels.filter(function(q){return q.id===pid;})[0].items[idx]; return {cards:M.packCards(it.arch,7+idx)}; },onTakeAll:function(){}}); break;
  case 'album': case 'deck': C.album.open({cards:M.cardIds.map(M.cardDef),owned:M.state.owned,deck:M.state.deck,seen:M.state.seen,deckRange:{min:5,max:30},tab:id==='deck'?'deck':'collection',onAdd:function(c){ M.state.deck[c]=(M.state.deck[c]||0)+1; },onRemove:function(c){ M.state.deck[c]=Math.max(0,(M.state.deck[c]||0)-1); }}); break;
  case 'relic': C.relicCase.open({slots:M.state.relicsEquipped,stored:M.state.relicsStored,resolve:function(r){ return M.relicDef(r); }}); break;
  case 'enchant': C.enchantKit.open({cards:Object.keys(M.state.deck).filter(function(k){return M.state.deck[k];}).map(function(k){ return Object.assign(M.cardDef(k),{enchant:M.state.enchants[k]}); }),enchants:['honed','swift','charged','warding','echoing','gilded'].map(M.enchDef),isCompatible:function(){ return {ok:true}; },preview:function(){ return []; }}); break;
  case 'ledger': C.ledger.open({rows:M.ledger.map(function(r){ return {day:r.day,opponent:M.opponents[r.opp],result:r.res,gain:r.gain}; }),reputation:M.state.reputation}); break;
  case 'mail': C.mail.open({letters:M.letters,onRead:function(){ ws.setState({badges:badges()}); },onReply:function(){}}); break;
  case 'calendar': ui.toast(T('cav.day',{n:M.state.day})); break;
  case 'clock': ui.toast(Math.floor(M.state.minutes/60)+':'+('0'+M.state.minutes%60).slice(-2)); break;
  } }

/* ---------- mock match (random-move opponent, ordinary chess via the unmodified V3H engine) ---------- */
function startMatch(op){ var ov=C.matchUI.intro({opponent:Object.assign({title:'Club regular'},op),onStart:function(){ beginMatch(op); }}); }
function beginMatch(op){
  G={op:op,s:fromFEN(START),sel:null,energy:3,hand:[],uid:1,moves:[]};
  var ids=['quick_study','bulwark','foresight','castle_ward','gilded_reserve'];
  ids.slice(0,4).forEach(function(id){ G.hand.push({uid:G.uid++,def:M.cardDef(id),enchant:M.state.enchants[id]||null,playable:true}); });
  view=C.matchUI.attach(ws,{onSelect:function(u){ G.card=u; push(); },onPlay:function(u){ G.hand=G.hand.filter(function(c){return c.uid!==u;}); G.energy=Math.max(0,G.energy-1); G.card=null; ui.toast(T('cav.match.play')); push(); },
    onInspect:function(){},onCancel:function(){ G.card=null; push(); },onEndTurn:function(){ if(G.s.turn==='w') aiMove(); },onMenu:openSettings,
    onResign:function(){ endMatch(false); }});
  ws.onSquare=onSquare; ws.board.setPosition(G.s.b); push(); }
function push(){ var s=G.s, own=s.turn==='w';
  view.setState({opponent:G.op,energy:G.energy,maxEnergy:3,drawCount:12,discardCount:G.moves.length>>1,selected:G.card||null,
    status:own?T('cav.match.yourTurn'):'',thinking:!own,canEndTurn:own,hand:G.hand.map(function(c){ return Object.assign({},c,{playable:G.energy>=c.def.cost}); })}); }
function onSquare(sq){ if(!G||G.s.turn!=='w') return; var s=G.s, L=legal(s), p=s.b[sq];
  if(G.sel!=null){ var mv=L.filter(function(m){ return m.from===G.sel&&m.to===sq&&(!m.promo||m.promo==='q'); })[0]; if(mv){ play(mv); return; } }
  if(p&&p===p.toUpperCase()){ G.sel=sq; ws.board.setSelected(sq); ws.board.setTargets(L.filter(function(m){return m.from===sq&&(!m.promo||m.promo==='q');}).map(function(m){ return {sq:m.to,capture:!!s.b[m.to]}; })); }
  else { G.sel=null; ws.board.setSelected(null); ws.board.setTargets([]); } }
function play(mv){ G.sel=null; G.s=make(G.s,mv); G.moves.push(mv); ws.board.setSelected(null); ws.board.setTargets([]); ws.board.setPosition(G.s.b); ws.board.setLastMove({from:mv.from,to:mv.to}); after(); if(G&&G.s.turn==='b'){ push(); setTimeout(aiMove,500); } }
function aiMove(){ if(!G) return; var L=legal(G.s); if(!L.length) return after(); if(G.s.turn==='w'){ return; } var mv=L[Math.floor(Math.random()*L.length)]; if(mv.promo&&mv.promo!=='q'){ mv=L.filter(function(m){return m.from===mv.from&&m.to===mv.to&&m.promo==='q';})[0]||mv; }
  G.s=make(G.s,mv); G.moves.push(mv); ws.board.setPosition(G.s.b); ws.board.setLastMove({from:mv.from,to:mv.to}); after(); if(G) { G.energy=3; push(); } }
function after(){ var s=G.s, w=s.turn==='w', L=legal(s); ws.board.setCheck(inCheck(s,w)?kingSq(s,w):null); if(!L.length) endMatch(!w&&inCheck(s,w)?true:(w&&inCheck(s,w)?false:null)); }
function endMatch(won){ var op=G.op; var res={won:won===true,draw:won===null,opponent:op,gain:won===true?op.reward:(won===null?Math.round(op.reward/2):3),onContinue:function(){ M.state.doubloons+=res.gain; G=null; view.detach(); view=null; ws.setState({doubloons:M.state.doubloons}); idleBoard(); }}; C.matchUI.result(res); }

C.boot(function(r){ root=r; var q=new URLSearchParams(location.search);
  if(q.get('lang')) C.i18n.setLang(q.get('lang'));
  STAGE=parseInt(q.get('stage'),10)||1; window.DEMO={ stage:function(n){ STAGE=n; INSTS=null; rebuild2(); }, reset:function(){ ws.free().reset(); saveInsts(); }, open:onObject, startMatch:startMatch, settings:openSettings, ws:function(){return ws;}, rebuild:rebuild, M:M };
  if(q.get('go')==='desk'){ mountDesk(); } else {
    menu=C.screens.menu.create({onStart:function(){ menu.destroy(); mountDesk(); },onSettings:openSettings}); root.appendChild(menu.el); } });
})();
