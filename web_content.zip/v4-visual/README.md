# Chess Ascension V4 — Visual Package (Checkpoint 2)

Offline, classic-script, 100% pixel-art UI layer for Chess Ascension V4. **Presentation only** — no rules, economy, AI or persistence. Open `demo/index.html` (file://) — no server, no CDN.
URL flags: `?go=desk` skip menu · `?stage=1..4` desk evolution preview · `?lang=pt-BR`.

Android-landscape first (integer pixel scale, safe areas, rotate screen), desktop secondary. Namespace `CAV` / `cav-`. Never touches V3H files (`vendor/chess.v3h.js` is an unmodified copy used by the demo only).

## What is in this checkpoint
| Area | Status |
|---|---|
| Design system, font, palette, 9-slice frames, overlays/Back handling | Implemented |
| Chess board + reference piece set (supplied sheet, sizes 20/27/34; legacy top-down set kept) | Implemented |
| Appointment book, merchant catalog, delivery + booster opening, album/deck, relic case, enchant kit, ledger, mail | Implemented (visually checked, emulated viewports) |
| Match UI (intro, hand, energy, result), menu, settings, guide | Implemented |
| **Free desk (Prompt 3, phases A+B)**: freeform draggable objects, z-order, select/long-press action bar, Move-then-tap, keyboard nudge, storage with open/empty states + tray, inspection, letters open/closed | Implemented (vertical slice) |
| Stage I–IV desk compositions (mock) | Implemented as presets |
| Progressive equipment families (stationery, storage, books, trophies, relic containers, 7 correspondence kinds) | In progress — one or two variants per family |
| Dedicated chess table + customization layers (Phase E) | Not started |
| Living-club visitor scenes & interaction states (Phase D) | Not started (portraits exist for 6 opponents) |
| Home/club/family/finances/career/tournament/closing/save-load screens | Not started |
| Animations: pick/drop/arrive/tuck/pop, page flip, parcel burst | Implemented basic; others not started |
Nothing here is Integration-ready or Polished; see `docs/TEST_REPORT.md`.

## Layout
`core/` engine (stage, px kit, palette, art registry) · `components/` art + UI components · `screens/` workstation/menu · `styles/` · `mock/` mock data + i18n · `demo/` · `contracts/` (objects.json, CONTRACTS.md) · `assets/export/sprites/` PNG export · `tools/` (shot/scenes/interact/export-contracts, build-font).
