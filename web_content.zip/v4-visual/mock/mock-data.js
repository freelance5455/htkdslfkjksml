/* Mock game state for the STANDALONE demo only. Shapes here ARE the data contracts the components expect (see contracts/). */
(function(){
var C=window.CAV, V=window.CAV_V3H;
Object.keys(V.names).forEach(function(l){ C.i18n.add(l,V.names[l]); });
var ARCH={quick_study:['oracle'],gilded_reserve:['gambler'],foresight:['oracle'],blood_offering:['martyr'],last_stand:['guardian'],scavengers_purse:['gambler'],resonant_bell:['chronomancer'],echo_loop:['chronomancer'],knights_oath:['pactmaker'],
  bulwark:['guardian'],gambit_reserve:['gambler','pactmaker'],ruinous_debt:['pactmaker'],promotion_oath:[],castle_ward:['guardian'],checking_hand:['martyr'],value_exchange:['gambler'],martyrdom:['martyr'],underdog:['martyr','guardian']};
var MOTIF={quick_study:'book',gilded_reserve:'coins',foresight:'eye',blood_offering:'chalice',last_stand:'kingFront',scavengers_purse:'purse',resonant_bell:'bell',echo_loop:'rings',knights_oath:'knightFront',bulwark:'shield',gambit_reserve:'dice',ruinous_debt:'scroll',promotion_oath:'pawnCrown',castle_ward:'tower',checking_hand:'glove',value_exchange:'scales',martyrdom:'candle',underdog:'pawnFront'};
var M=C.mock={ V3H:V };
M.cardDef=function(id){ var d=V.cards[id]; return { id:id, name:C.t('v3h.card.'+id+'.name'), description:C.t('v3h.card.'+id+'.desc'), cost:d.cost, rarity:d.rarity, type:d.type, arch:ARCH[id]||[], motif:MOTIF[id]||'generic', chips:C.cards.chipsFromDef(d), token:!!d.token, raw:d }; };
M.cardIds=Object.keys(V.cards).filter(function(k){ return !V.cards[k].token; });
M.relicDef=function(id){ var d=V.relics[id]; return { id:id, name:C.t('v3h.relic.'+id+'.name'), description:C.t('v3h.relic.'+id+'.desc'), rarity:d.rarity }; };
M.enchDef=function(id){ var d=V.ench[id]; return { id:id, name:C.t('v3h.ench.'+id+'.name'), description:C.t('v3h.ench.'+id+'.desc'), rarity:d.rarity }; };
M.relicIds=Object.keys(V.relics); M.enchIds=Object.keys(V.ench);

/* player state (mock) */
M.state={ day:3, minutes:9*60+30, doubloons:64, owned:{}, deck:{}, relicsEquipped:['merchants_ring','vault_key',null], relicsStored:['iron_reliquary','crowned_pawn','duelists_glove','scribes_quill','warders_mark','obsidian_hourglass'],
  enchants:{ quick_study:null }, seen:{}, reputation:42 };
M.cardIds.forEach(function(id,i){ M.state.owned[id]=(i%4===0?2:(i%7===6?0:1)); M.state.seen[id]=M.state.owned[id]>0||i%5===0; });
['quick_study','gilded_reserve','foresight','bulwark','castle_ward','checking_hand','knights_oath','martyrdom','scavengers_purse','underdog'].forEach(function(id){ M.state.deck[id]=1; }); M.state.deck.quick_study=2;
M.state.enchants.gilded_reserve='gilded';

/* opponents (ordinary humans for Act I) */
M.opponents={ aldren:{id:'aldren',portrait:'opp_aldren',name:'Sir Aldren',diff:3,reward:24}, marta:{id:'marta',portrait:'opp_marta',name:'Marta Vilaça',diff:1,reward:9}, teodoro:{id:'teodoro',portrait:'opp_teodoro',name:'Teodoro Reis',diff:2,reward:14},
  ines:{id:'ines',portrait:'opp_ines',name:'Inês Carvalho',diff:2,reward:13}, bruno:{id:'bruno',portrait:'opp_bruno',name:'Bruno Falk',diff:1,reward:8}, helena:{id:'helena',portrait:'opp_helena',name:'Helena Moura',diff:4,reward:30} };
/* appointments: date is a day number (1-based, 30-day month); slot = hour (10..15) */
M.appointments=[ {id:'a1',date:3,slot:10,opp:'marta',status:'accepted'}, {id:'a2',date:3,slot:14,opp:'teodoro',status:'accepted'}, {id:'a3',date:4,slot:11,opp:'ines',status:'accepted'}, {id:'a4',date:6,slot:10,opp:'bruno',status:'accepted'},{id:'a5',date:6,slot:10,opp:'aldren',status:'conflict'},{id:'a6',date:9,slot:15,opp:'helena',status:'accepted'} ];
M.proposals=[ {id:'p1',opp:'aldren',date:3,slot:12,expires:5}, {id:'p2',opp:'bruno',date:3,slot:14,expires:4}, {id:'p3',opp:'helena',date:5,slot:13,expires:7} ];
M.slots=[10,11,12,13,14,15];
M.ledger=[ {day:2,opp:'bruno',res:'win',gain:8},{day:2,opp:'marta',res:'loss',gain:2},{day:1,opp:'teodoro',res:'win',gain:14},{day:1,opp:'ines',res:'draw',gain:6},{day:0,opp:'aldren',res:'loss',gain:3} ];
M.letters=[ {id:'l1',kind:'invite',from:'Regional Chess Federation',title:'Invitation',body:'You are invited to the Autumn Open. Entry fee 12 Doubloons. Reply before the 10th.',seal:true},
  {id:'l2',kind:'bill',from:'Casa Albuquerque',title:'Rent notice',body:'Monthly rent due on the 5th: 30 Doubloons. Thank you for your punctuality.'},{id:'l3',kind:'notice',from:'Club Secretary',title:'Club notice',body:'The back room will be closed for varnishing on Saturday.'} ];
/* merchant: ONE fixed daily inventory (same before and after the workday) */
M.catalog={ day:3, products:[
 {id:'pk_gambler',kind:'booster',arch:'gambler',price:18,stock:3},{id:'pk_oracle',kind:'booster',arch:'oracle',price:18,stock:2},{id:'pk_martyr',kind:'booster',arch:'martyr',price:18,stock:1},{id:'pk_guardian',kind:'booster',arch:'guardian',price:18,stock:4},
 {id:'pk_chrono',kind:'booster',arch:'chronomancer',price:22,stock:0},{id:'pk_pact',kind:'booster',arch:'pactmaker',price:22,stock:2},{id:'pk_duel',kind:'booster',arch:'duelist',price:16,stock:3},{id:'pk_herald',kind:'booster',arch:'herald',price:16,stock:2},
 {id:'cd_bulwark',kind:'card',card:'bulwark',price:9,stock:2},{id:'cd_echo',kind:'card',card:'echo_loop',price:30,stock:1},{id:'cd_value',kind:'card',card:'value_exchange',price:14,stock:2},{id:'cd_castle',kind:'card',card:'castle_ward',price:8,stock:3},
 {id:'cd_oath',kind:'card',card:'promotion_oath',price:15,stock:1},{id:'cd_bell',kind:'card',card:'resonant_bell',price:16,stock:1},{id:'cd_mart',kind:'card',card:'martyrdom',price:6,stock:4},{id:'cd_last',kind:'card',card:'last_stand',price:13,stock:0},{id:'cd_quick',kind:'card',card:'quick_study',price:6,stock:5},{id:'cd_know',kind:'card',card:'knights_oath',price:34,stock:1},{id:'cd_gil',kind:'card',card:'gilded_reserve',price:7,stock:3},{id:'cd_fore',kind:'card',card:'foresight',price:8,stock:2},{id:'cd_under',kind:'card',card:'underdog',price:15,stock:1},{id:'cd_check',kind:'card',card:'checking_hand',price:8,stock:2},
 {id:'en_honed',kind:'ench',ench:'honed',price:10,stock:2},{id:'en_swift',kind:'ench',ench:'swift',price:16,stock:1},{id:'en_charged',kind:'ench',ench:'charged',price:28,stock:1},{id:'en_warding',kind:'ench',ench:'warding',price:17,stock:2},
 {id:'en_echoing',kind:'ench',ench:'echoing',price:15,stock:2},{id:'en_unb',kind:'ench',ench:'unburdened',price:26,stock:1},{id:'en_vol',kind:'ench',ench:'volatile',price:12,stock:2},{id:'en_gild',kind:'ench',ench:'gilded',price:9,stock:3} ] };
M.parcels=[ {id:'pc1',items:[{kind:'booster',arch:'gambler',n:1},{kind:'ench',ench:'honed',n:1}]}, {id:'pc2',items:[{kind:'booster',arch:'oracle',n:1}]} ];
/* deterministic mock pack contents (engine decides this in the real game) */
M.packCards=function(arch,seed){ var r=C.rng(C.hash(arch)+seed), ids=M.cardIds, out=[]; for(var i=0;i<5;i++){ var id=ids[Math.floor(r()*ids.length)]; out.push({card:id,isNew:!M.state.seen[id]||r()<.25}); } out.sort(function(a,b){ return C.RARITY_RANK(M.cardDef(a.card).rarity)-C.RARITY_RANK(M.cardDef(b.card).rarity); }); return out; };
C.RARITY_RANK=function(r){ return ['common','rare','epic','legendary'].indexOf(r); };
})();
