/* MOCK desk compositions for the standalone demo.  The REAL game decides what the player owns (flags) and persists layout;
   these presets only show how the same instance format grows from a bare starter desk to a supernatural master's desk.
   Row: [id, side 'L'|'R', u 0..1, v 0..1, extra]  -> default home inside that side area; extra may hold kind/variant/in/data. */
(function(){
var C=window.CAV, M=C.mock||(C.mock={});
var LET={ ordinary:{title:'A note from Marta',from:'Marta Vilaça',body:'Dear friend, the back room is free on Thursday if you want a proper game. Bring your own tea.'},
  invite:{title:'Autumn Open',from:'Regional Chess Federation',body:'You are cordially invited to the Autumn Open. Entry fee 12 Doubloons. Kindly reply before the 10th.'},
  official:{title:'Club notice',from:'The Secretary',body:'The back room will be closed for varnishing on Saturday. Members are asked to use the front tables.'},
  clipping:{title:'Local Hope Takes The Board',from:'The Evening Courier',body:'A young player from the old quarter has stunned the regional circuit with three wins in a week.'},
  personal:{title:'From home',from:'Mother',body:'I hope the club is treating you kindly. There is soup on the stove whenever you visit. Do not forget your scarf.'},
  merchant:{title:'Fine boards & clocks',from:'Albuquerque & Son',body:'New stock of walnut boards and brass clocks has arrived. Members receive a small discount this month.'},
  mystery:{title:'—',from:'Unsigned',body:'The next game is not played at the club. Come when the bell stops. Bring nothing that can be counted.'} };
function L(kind,side,u,v,extra){ return ['letter',side,u,v,Object.assign({kind:kind,data:LET[kind]},extra||{})]; }
var S1=[ ['appointment','L',.04,.04], ['catalog','L',.95,.1], ['ledger','L',.08,.42], ['deck','L',.9,.5], ['cardcase','L',.45,.84,{id2:'case1'}],
  ['calendar','R',.1,.04], ['clock','R',.95,.08,{variant:'wood'}], ['mail','R',.08,.42], L('ordinary','R',.85,.5), ['notepad','R',.3,.8], ['pencil','R',.8,.74], ['inkwell','R',.9,.9], ['parcel','R',.2,.9,{seed:2}] ];
var S2=S1.filter(function(r){ return r[0]!=='blotter'&&r[0]!=='clock'; }).concat([ ['blotter','R',.4,.6], ['clock','R',.95,.08,{variant:'brass'}], ['album','L',.1,.2], ['relic','L',.9,.28], ['organizer','R',.5,.34], ['folder','L',.1,.7,{id2:'f1'}],
  ['book_manual','L',.5,.6], ['book_opening','R',.3,.5], ['trophy_cup','R',.9,.62], ['mug','L',.95,.9], ['magnifier','R',.5,.9], L('invite','R',.6,.2), L('official','L',.6,.45,{in:'f1'}), L('merchant','L',.4,.92,{in:'f1'}) ]);
var S3=S2.concat([ ['chest','L',.5,.92,{id2:'c1'}], ['enchant','R',.1,.62], ['lamp','L',.02,.96], ['medal','R',.7,.46], ['book_field','R',.6,.62], ['sealwax','R',.75,.95], L('clipping','R',.3,.28), L('personal','R',.8,.35,{in:'c1'}), L('ordinary','L',.8,.8,{in:'c1'}) ]);
var S4=S3.concat([ ['casket','L',.2,.45], ['orrery','R',.92,.7], ['moonglass','R',.55,.7], ['candle','L',.7,.05], ['book_arcane','L',.05,.55], L('mystery','R',.5,.55) ]);
var PRE={1:S1,2:S2,3:S3,4:S4}; M.deckStages=[1,2,3,4];
M.deckInstances=function(stage){ var rows=PRE[stage]||S1, n=0, byAlias={}, out=[];
  rows.forEach(function(r){ var x=r[4]||{}, inst={uid:'o'+(++n),id:r[0],home:{side:r[1],u:r[2],v:r[3]}}; ['kind','variant','seed','data'].forEach(function(k){ if(x[k]!=null) inst[k]=x[k]; }); if(x.id2) byAlias[x.id2]=inst.uid; inst._in=x.in||null; out.push(inst); });
  out.forEach(function(i){ if(i._in){ i.in=byAlias[i._in]||null; i.homeIn=i.in; } delete i._in; });
  /* stage I: the card case already holds one letter */
  if(stage===1){ var c=out.filter(function(i){return i.id==='cardcase';})[0]; if(c){ var lt={uid:'o99',id:'letter',kind:'personal',data:LET.personal,home:{side:'L',u:.5,v:.9},in:c.uid,homeIn:c.uid}; out.push(lt); } }
  return out; };
M.letterData=LET;
})();
