const {chromium}=require('playwright');
(async()=>{ const S=process.argv[2]; const b=await chromium.launch(); const c=await b.newContext({viewport:{width:640,height:360},hasTouch:false}); const p=await c.newPage(); const errs=[];
 p.on('pageerror',e=>errs.push(e.message)); p.on('console',m=>m.type()==='error'&&errs.push(m.text()));
 await p.goto('file://'+process.cwd()+'/demo/index.html?go=desk&stage=2'); await p.waitForTimeout(800);
 const box=async sel=>await p.evaluate(s=>{const r=document.querySelector(s).getBoundingClientRect();return {x:r.x+r.width/2,y:r.y+r.height/2}},sel);
 // drag notepad over board
 let n=await box('[data-obj=notepad]'); await p.mouse.move(n.x,n.y); await p.mouse.down(); await p.mouse.move(n.x+60,n.y-20,{steps:6}); await p.mouse.move(330,200,{steps:8}); await p.screenshot({path:S+'/i-drag.png'}); await p.mouse.up();
 await p.waitForTimeout(300);
 // open folder (tap)
 let f=await box('[data-obj=folder]'); await p.mouse.click(f.x,f.y); await p.waitForTimeout(400); await p.screenshot({path:S+'/i-folder.png'});
 // drag pencil into the open folder
 let pc=await box('[data-obj=pencil]'); let fo=await box('[data-obj=folder]'); await p.mouse.move(pc.x,pc.y); await p.mouse.down(); await p.mouse.move(fo.x,fo.y,{steps:10}); await p.screenshot({path:S+'/i-target.png'}); await p.mouse.up(); await p.waitForTimeout(500); await p.screenshot({path:S+'/i-stored.png'});
 // long press on inkwell -> action bar
 let ik=await box('[data-obj=inkwell]'); await p.mouse.move(ik.x,ik.y); await p.mouse.down(); await p.waitForTimeout(600); await p.mouse.up(); await p.waitForTimeout(200); await p.screenshot({path:S+'/i-bar.png'});
 // inspect via bar eye
 await p.evaluate(()=>document.querySelector('.fd-bar .cav-btn[aria-label=Inspect]').click()); await p.waitForTimeout(400); await p.screenshot({path:S+'/i-inspect.png'});
 console.log(errs.join('\n')||'ok'); await b.close(); })();
