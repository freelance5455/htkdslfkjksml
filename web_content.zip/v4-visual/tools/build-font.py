#!/usr/bin/env python3
"""CAV Pixel — original 5x7 bitmap font for Chess Ascension V4.
Builds a real TTF/WOFF whose every pixel is a 100-unit square, so text is crisp when
font-size = 11 * k px (k = integer).  Output: assets/fonts/cav-pixel.ttf, styles/cav-font.css (base64, offline-safe),
docs/font-specimen.html.  Needs: fontTools.  License: part of the Chess Ascension V4 visual package (original work)."""
import base64, io, os, sys
from fontTools.fontBuilder import FontBuilder
from fontTools.pens.ttGlyphPen import TTGlyphPen

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PX = 100; UPM = 1100; ASC = 900; DESC = 200

def G(s):  # multiline string -> list of rows
    return [r for r in s.strip("\n").split("\n")]

# Each glyph: rows from row 7 (top of capitals) downward to row 1 (baseline row); optional descender rows (-1,-2) after a '--' line.
RAW = {
'A':".###.\n#...#\n#...#\n#####\n#...#\n#...#\n#...#",
'B':"####.\n#...#\n#...#\n####.\n#...#\n#...#\n####.",
'C':".###.\n#...#\n#....\n#....\n#....\n#...#\n.###.",
'D':"####.\n#...#\n#...#\n#...#\n#...#\n#...#\n####.",
'E':"#####\n#....\n#....\n####.\n#....\n#....\n#####",
'F':"#####\n#....\n#....\n####.\n#....\n#....\n#....",
'G':".###.\n#...#\n#....\n#.###\n#...#\n#...#\n.###.",
'H':"#...#\n#...#\n#...#\n#####\n#...#\n#...#\n#...#",
'I':"###\n.#.\n.#.\n.#.\n.#.\n.#.\n###",
'J':"..###\n...#.\n...#.\n...#.\n...#.\n#..#.\n.##..",
'K':"#...#\n#..#.\n#.#..\n##...\n#.#..\n#..#.\n#...#",
'L':"#....\n#....\n#....\n#....\n#....\n#....\n#####",
'M':"#...#\n##.##\n#.#.#\n#.#.#\n#...#\n#...#\n#...#",
'N':"#...#\n##..#\n#.#.#\n#..##\n#...#\n#...#\n#...#",
'O':".###.\n#...#\n#...#\n#...#\n#...#\n#...#\n.###.",
'P':"####.\n#...#\n#...#\n####.\n#....\n#....\n#....",
'Q':".###.\n#...#\n#...#\n#...#\n#.#.#\n#..#.\n.##.#",
'R':"####.\n#...#\n#...#\n####.\n#.#..\n#..#.\n#...#",
'S':".####\n#....\n#....\n.###.\n....#\n....#\n####.",
'T':"#####\n..#..\n..#..\n..#..\n..#..\n..#..\n..#..",
'U':"#...#\n#...#\n#...#\n#...#\n#...#\n#...#\n.###.",
'V':"#...#\n#...#\n#...#\n#...#\n#...#\n.#.#.\n..#..",
'W':"#...#\n#...#\n#...#\n#.#.#\n#.#.#\n##.##\n#...#",
'X':"#...#\n#...#\n.#.#.\n..#..\n.#.#.\n#...#\n#...#",
'Y':"#...#\n#...#\n.#.#.\n..#..\n..#..\n..#..\n..#..",
'Z':"#####\n....#\n...#.\n..#..\n.#...\n#....\n#####",
'a':".....\n.....\n.###.\n....#\n.####\n#...#\n.####",
'b':"#....\n#....\n####.\n#...#\n#...#\n#...#\n####.",
'c':".....\n.....\n.###.\n#...#\n#....\n#...#\n.###.",
'd':"....#\n....#\n.####\n#...#\n#...#\n#...#\n.####",
'e':".....\n.....\n.###.\n#...#\n#####\n#....\n.###.",
'f':"..##\n.#..\n###.\n.#..\n.#..\n.#..\n.#..",
'g':".....\n.....\n.####\n#...#\n#...#\n#...#\n.####\n--\n....#\n.###.",
'h':"#....\n#....\n####.\n#...#\n#...#\n#...#\n#...#",
'i':"#\n.\n#\n#\n#\n#\n#",
'j':"..#\n...\n..#\n..#\n..#\n..#\n..#\n--\n..#\n##.",
'k':"#...\n#...\n#..#\n#.#.\n##..\n#.#.\n#..#",
'l':"##.\n.#.\n.#.\n.#.\n.#.\n.#.\n.##",
'm':".....\n.....\n##.#.\n#.#.#\n#.#.#\n#...#\n#...#",
'n':".....\n.....\n####.\n#...#\n#...#\n#...#\n#...#",
'o':".....\n.....\n.###.\n#...#\n#...#\n#...#\n.###.",
'p':".....\n.....\n####.\n#...#\n#...#\n#...#\n####.\n--\n#....\n#....",
'q':".....\n.....\n.####\n#...#\n#...#\n#...#\n.####\n--\n....#\n....#",
'r':"....\n....\n#.##\n##..\n#...\n#...\n#...",
's':".....\n.....\n.####\n#....\n.###.\n....#\n####.",
't':".#..\n.#..\n###.\n.#..\n.#..\n.#..\n..##",
'u':".....\n.....\n#...#\n#...#\n#...#\n#..##\n.##.#",
'v':".....\n.....\n#...#\n#...#\n#...#\n.#.#.\n..#..",
'w':".....\n.....\n#...#\n#...#\n#.#.#\n#.#.#\n.#.#.",
'x':".....\n.....\n#...#\n.#.#.\n..#..\n.#.#.\n#...#",
'y':".....\n.....\n#...#\n#...#\n#...#\n#...#\n.####\n--\n....#\n.###.",
'z':".....\n.....\n#####\n...#.\n..#..\n.#...\n#####",
'0':".###.\n#...#\n#..##\n#.#.#\n##..#\n#...#\n.###.",
'1':"..#..\n.##..\n..#..\n..#..\n..#..\n..#..\n.###.",
'2':".###.\n#...#\n....#\n...#.\n..#..\n.#...\n#####",
'3':"####.\n....#\n....#\n.###.\n....#\n....#\n####.",
'4':"...#.\n..##.\n.#.#.\n#..#.\n#####\n...#.\n...#.",
'5':"#####\n#....\n####.\n....#\n....#\n#...#\n.###.",
'6':".###.\n#....\n#....\n####.\n#...#\n#...#\n.###.",
'7':"#####\n....#\n...#.\n..#..\n.#...\n.#...\n.#...",
'8':".###.\n#...#\n#...#\n.###.\n#...#\n#...#\n.###.",
'9':".###.\n#...#\n#...#\n.####\n....#\n....#\n.###.",
' ':"...\n...\n...\n...\n...\n...\n...",
'.':".\n.\n.\n.\n.\n.\n#",
',':".\n.\n.\n.\n.\n.\n#\n--\n#\n.",
':':".\n.\n#\n.\n.\n#\n.",
';':".\n.\n#\n.\n.\n#\n.\n--\n#\n.",
'!':"#\n#\n#\n#\n#\n.\n#",
'?':".###.\n#...#\n....#\n...#.\n..#..\n.....\n..#..",
'-':".....\n.....\n.....\n.###.\n.....\n.....\n.....",
'+':".....\n..#..\n..#..\n#####\n..#..\n..#..\n.....",
'=':".....\n.....\n#####\n.....\n#####\n.....\n.....",
'/':"....#\n....#\n...#.\n..#..\n.#...\n#....\n#....",
'\\':"#....\n#....\n.#...\n..#..\n...#.\n....#\n....#",
'(':"..#\n.#.\n#..\n#..\n#..\n.#.\n..#",
')':"#..\n.#.\n..#\n..#\n..#\n.#.\n#..",
'[':"###\n#..\n#..\n#..\n#..\n#..\n###",
']':"###\n..#\n..#\n..#\n..#\n..#\n###",
'%':"##..#\n##.#.\n..#..\n..#..\n.#.##\n#..##\n.....",
"'":"#\n#\n.\n.\n.\n.\n.",
'"':"#.#\n#.#\n...\n...\n...\n...\n...",
'*':".....\n#.#.#\n.###.\n#####\n.###.\n#.#.#\n.....",
'#':".#.#.\n#####\n.#.#.\n.#.#.\n.#.#.\n#####\n.#.#.",
'&':".##..\n#..#.\n#.#..\n.#...\n#.#.#\n#..#.\n.##.#",
'$':"..#..\n.####\n#.#..\n.###.\n..#.#\n####.\n..#..",
'@':".###.\n#...#\n#.###\n#.#.#\n#.###\n#....\n.####",
'_':".....\n.....\n.....\n.....\n.....\n.....\n#####",
'<':"...#\n..#.\n.#..\n#...\n.#..\n..#.\n...#",
'>':"#...\n.#..\n..#.\n...#\n..#.\n.#..\n#...",
'|':"#\n#\n#\n#\n#\n#\n#",
'~':".....\n.....\n.#...\n#.#.#\n...#.\n.....\n.....",
'…':".....\n.....\n.....\n.....\n.....\n.....\n#.#.#",
'·':"...\n...\n...\n.#.\n...\n...\n...",
'•':".....\n.....\n.###.\n.###.\n.###.\n.....\n.....",
'–':".....\n.....\n.....\n.###.\n.....\n.....\n.....",
'—':"......\n......\n......\n######\n......\n......\n......",
'×':".....\n.....\n#...#\n.#.#.\n..#..\n.#.#.\n#...#",
'°':".##\n#.#\n.##\n...\n...\n...\n...",
'ª':".##.\n...#\n.###\n#..#\n.###\n....\n.###",
'º':".##.\n#..#\n#..#\n.##.\n....\n....\n.###",
'‘':".#\n#.\n.\n.\n.\n.\n.",
'’':"#.\n.#\n.\n.\n.\n.\n.",
'“':".#.#\n#.#.\n....\n....\n....\n....\n....",
'”':"#.#.\n.#.#\n....\n....\n....\n....\n....",
'→':".....\n..#..\n...#.\n#####\n...#.\n..#..\n.....",
'←':".....\n..#..\n.#...\n#####\n.#...\n..#..\n.....",
'↑':"..#..\n.###.\n#.#.#\n..#..\n..#..\n..#..\n.....",
'↓':".....\n..#..\n..#..\n..#..\n#.#.#\n.###.\n..#..",
'★':"..#..\n..#..\n#####\n.###.\n.###.\n.#.#.\n#...#",
'♦':"..#..\n.###.\n#####\n.###.\n..#..\n.....\n.....",
'✓':".....\n....#\n...#.\n#.#..\n.#...\n.....\n.....",
'✕':".....\n#...#\n.#.#.\n..#..\n.#.#.\n#...#\n.....",
}

def parse(raw):
    parts = raw.split("\n--\n") if "\n--\n" in raw else [raw]
    top = parts[0].split("\n"); desc = parts[1].split("\n") if len(parts) > 1 else []
    return top, desc

MARKS = {  # (dx from centre, row-kind) ; kinds: 'T' top row, 'B' bottom row, 'D' single dots row
 'acute': [(1,'T'),(0,'B')], 'grave': [(-1,'T'),(0,'B')], 'circ': [(0,'T'),(-1,'B'),(1,'B')],
 'diae': [(-1,'D'),(1,'D')],
}
TILDE_TOP = (1,2,4); TILDE_BOT = (0,3)

def gl_to_pixels(raw):
    top, desc = parse(raw)
    w = max(len(r) for r in top + desc)
    px = set()
    for i, r in enumerate(top):
        row = 7 - i
        for x, ch in enumerate(r):
            if ch == '#': px.add((x, row))
    for i, r in enumerate(desc):
        row = -1 - i
        for x, ch in enumerate(r):
            if ch == '#': px.add((x, row))
    return px, w

def is_upper(ch): return ch.isupper()

def compose(base, mark, widthpad=None):
    px, w = gl_to_pixels(RAW[base])
    px = set(px)
    if base == 'ı':  # not used
        pass
    upper = base.isupper()
    if base == 'i':  # dotless, widened to 3 with stem at col 1
        px = {(1, r) for r in range(1, 6)}; w = 3
    c = (w - 1) // 2
    if upper: rowB, rowT, rowD = 8, 9, 9
    else:     rowB, rowT, rowD = 7, 8, 7
    if mark in MARKS:
        for dx, k in MARKS[mark]:
            px.add((c + dx, {'T': rowT, 'B': rowB, 'D': rowD}[k]))
    elif mark == 'tilde':
        for x in TILDE_TOP: px.add((x, rowT))
        for x in TILDE_BOT: px.add((x, rowB))
    elif mark == 'cedilla':
        px.add((c, -1)); px.add((c - 1, -2))
    return px, w

ACC = {'a':'áàâãä','e':'éèêë','i':'íìîï','o':'óòôõö','u':'úùûüÿ'}
MARK_OF = {'á':'acute','à':'grave','â':'circ','ã':'tilde','ä':'diae','é':'acute','è':'grave','ê':'circ','ë':'diae',
           'í':'acute','ì':'grave','î':'circ','ï':'diae','ó':'acute','ò':'grave','ô':'circ','õ':'tilde','ö':'diae',
           'ú':'acute','ù':'grave','û':'circ','ü':'diae','ÿ':'diae'}
glyphs = {}
for ch, raw in RAW.items(): glyphs[ch] = gl_to_pixels(raw)
for b, chars in ACC.items():
    for a in chars:
        if a == 'ÿ': glyphs[a] = compose('y', 'diae'); continue
        glyphs[a] = compose(b, MARK_OF[a])
        glyphs[a.upper()] = compose(b.upper(), MARK_OF[a])
glyphs['ç'] = compose('c', 'cedilla'); glyphs['Ç'] = compose('C', 'cedilla')
glyphs['ñ'] = compose('n', 'tilde');   glyphs['Ñ'] = compose('N', 'tilde')
glyphs['Ÿ'] = compose('Y', 'diae')
glyphs['ß'] = gl_to_pixels(".###.\n#...#\n#..#.\n#.##.\n#...#\n#...#\n#.##.")
glyphs['€'] = gl_to_pixels("..##.\n.#..#\n####.\n.#...\n####.\n.#..#\n..##.")
glyphs['£'] = gl_to_pixels("..##.\n.#..#\n.#...\n####.\n.#...\n.#...\n#####")
glyphs['¡'] = gl_to_pixels("#\n.\n#\n#\n#\n#\n#")
glyphs['¿'] = gl_to_pixels("..#..\n.....\n..#..\n.#...\n#....\n#...#\n.###.")
glyphs['\u00a0'] = glyphs[' ']

def build():
    order = [".notdef"]; cmap = {}; gs = {}
    def rect_glyph(px):
        pen = TTGlyphPen(None)
        # merge horizontal runs per row
        rows = {}
        for x, r in px: rows.setdefault(r, []).append(x)
        for r, xs in rows.items():
            xs.sort(); start = prev = xs[0]
            for x in xs[1:] + [None]:
                if x is not None and x == prev + 1: prev = x; continue
                x0, x1, y0, y1 = start*PX, (prev+1)*PX, (r-1)*PX, r*PX
                pen.moveTo((x0, y0)); pen.lineTo((x0, y1)); pen.lineTo((x1, y1)); pen.lineTo((x1, y0)); pen.closePath()
                if x is not None: start = prev = x
        return pen.glyph()
    adv = {}
    nd = TTGlyphPen(None); nd.moveTo((0,0)); nd.lineTo((0,700)); nd.lineTo((400,700)); nd.lineTo((400,0)); nd.closePath()
    nd.moveTo((100,100)); nd.lineTo((300,100)); nd.lineTo((300,600)); nd.lineTo((100,600)); nd.closePath()
    gs[".notdef"] = nd.glyph(); adv[".notdef"] = 500
    for ch, (px, w) in glyphs.items():
        name = "uni%04X" % ord(ch)
        order.append(name); cmap[ord(ch)] = name
        gs[name] = rect_glyph(px) if px else TTGlyphPen(None).glyph()
        adv[name] = (w + 1) * PX
    fb = FontBuilder(UPM, isTTF=True)
    fb.setupGlyphOrder(order); fb.setupCharacterMap(cmap); fb.setupGlyf(gs)
    fb.setupHorizontalMetrics({n: (adv[n], 0) for n in order})
    fb.setupHorizontalHeader(ascent=ASC, descent=-DESC, lineGap=0)
    fb.setupNameTable({"familyName": "CAV Pixel", "styleName": "Regular",
                       "copyright": "Chess Ascension V4 visual package - original bitmap font", "uniqueFontIdentifier": "CAVPixel-1.0",
                       "fullName": "CAV Pixel Regular", "psName": "CAVPixel-Regular", "version": "Version 1.0"})
    fb.setupOS2(sTypoAscender=ASC, sTypoDescender=-DESC, usWinAscent=ASC, usWinDescent=DESC, sxHeight=500, sCapHeight=700)
    fb.setupPost(isFixedPitch=0)
    buf = io.BytesIO(); fb.save(buf); return buf.getvalue()

if __name__ == "__main__":
    ttf = build()
    open(os.path.join(ROOT, "assets/fonts/cav-pixel.ttf"), "wb").write(ttf)
    b64 = base64.b64encode(ttf).decode()
    css = ("/* GENERATED by tools/build-font.py — do not edit. Embedded so it works from file:// with no network. */\n"
           "@font-face{font-family:'CAV Pixel';font-style:normal;font-weight:400;font-display:block;"
           "src:url(data:font/ttf;base64,%s) format('truetype')}\n" % b64)
    open(os.path.join(ROOT, "styles/cav-font.css"), "w").write(css)
    print("glyphs:", len(glyphs), "ttf bytes:", len(ttf))
