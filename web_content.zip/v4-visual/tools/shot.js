// usage: node tools/shot.js WxH outdir "<js to run after load>" name [lang]
const {chromium}=require('playwright');
(async()=>{
 const [,, vp, out, steps, name, lang]=process.argv; const [w,h]=vp.split('x').map(Number);
 const b=await chromium.launch(); const ctx=await b.newContext({viewport:{width:w,height:h},hasTouch:true,isMobile:w<1000,deviceScaleFactor:1});
 const p=await ctx.newPage(); const errs=[]; p.on('pageerror',e=>errs.push('PAGEERR '+e.message)); p.on('console',m=>{ if(m.type()==='error') errs.push('CONSOLE '+m.text()); });
 await p.goto('file://'+process.cwd()+'/demo/index.html?go=desk'+(lang?'&lang='+lang:'')); await p.waitForTimeout(900);
 if(steps){ await p.evaluate(steps); await p.waitForTimeout(700); }
 await p.screenshot({path:`${out}/${name}-${vp}.png`}); console.log(name,vp,errs.join('\n')||'ok'); await b.close();
})();
