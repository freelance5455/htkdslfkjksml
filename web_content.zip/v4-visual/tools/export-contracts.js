// Exports contracts/objects.json + sprite PNGs (assets/export/) using the real sprite generators in headless Chromium.
const {chromium}=require('playwright'); const fs=require('fs'), path=require('path');
(async()=>{ const b=await chromium.launch(); const p=await b.newPage(); const errs=[]; p.on('pageerror',e=>errs.push(e.message));
 await p.goto('file://'+process.cwd()+'/demo/index.html?go=desk'); await p.waitForTimeout(800);
 const data=await p.evaluate(()=>{ const O=CAV.objects, c=O.contract(), png={};
   const add=(k)=>{ if(!png[k]) png[k]=CAV.art.url(k); };
   c.objects.forEach(o=>Object.keys(o.states).forEach(s=>add(o.states[s].sprite)));
   ['K','Q','R','B','N','P'].forEach(t=>[true,false].forEach(w=>[20,27,34].forEach(n=>add(CAV.art.piece(t,w,n)))));
   return {c,png}; });
 fs.mkdirSync('contracts',{recursive:true}); fs.writeFileSync('contracts/objects.json',JSON.stringify(data.c,null,1));
 fs.mkdirSync('assets/export/sprites',{recursive:true}); let n=0;
 for(const k in data.png){ fs.writeFileSync(path.join('assets/export/sprites',k.replace(/[^a-z0-9._@-]/gi,'_')+'.png'),Buffer.from(data.png[k].split(',')[1],'base64')); n++; }
 console.log('objects',data.c.objects.length,'sprites',n,errs.join('|')||'ok'); await b.close(); })();
