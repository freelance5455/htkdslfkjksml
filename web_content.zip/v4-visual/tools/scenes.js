const {chromium}=require('playwright');
const OUT=process.argv[2]; const VPS=(process.argv[3]||'640x360,800x360,854x480,960x540,1280x720').split(','); const lang=process.argv[4]||''; const only0=process.argv[5];
const SC={
 desk:"",
 menu:null,
 appointment:"DEMO.open('appointment')",
 catalog:"DEMO.open('catalog')",
 parcel:"DEMO.open('parcel');document.querySelector('.dl button.bo-primary').click()",
 revealed:"DEMO.open('parcel');document.querySelector('.dl button.bo-primary').click();[...document.querySelectorAll('.dl-item .cav-btn')][0].click();document.querySelector('.bo .bo-primary').click();document.querySelector('.bo .bo-primary, .bo button').click()",
 album:"DEMO.open('album')", deck:"DEMO.open('deck')", relic:"DEMO.open('relic')", enchant:"DEMO.open('enchant')",
 ledger:"DEMO.open('ledger')", mail:"DEMO.open('mail');document.querySelector('.pd-env').click()",
 intro:"DEMO.startMatch(DEMO.M.opponents.aldren)", settings:"DEMO.settings()",
 match:"DEMO.startMatch(DEMO.M.opponents.marta);document.querySelector('.mi-tx .bo-primary').click();document.querySelectorAll('.m-hand button')[0]&&document.querySelectorAll('.m-hand button')[0].click()"
};
(async()=>{ const b=await chromium.launch(); const only=only0?only0.split(','):Object.keys(SC);
 for(const vp of VPS){ const [w,h]=vp.split('x').map(Number);
  for(const k of only){ const ctx=await b.newContext({viewport:{width:w,height:h},hasTouch:true,isMobile:w<1000}); const p=await ctx.newPage(); const errs=[];
   p.on('pageerror',e=>errs.push(e.message)); p.on('console',m=>{ if(m.type()==='error') errs.push(m.text()); });
   const q=[]; if(k!=='menu') q.push('go=desk'); if(lang) q.push('lang='+lang);
   await p.goto('file://'+process.cwd()+'/demo/index.html'+(q.length?'?'+q.join('&'):'')); await p.waitForTimeout(800);
   if(SC[k]) { try{ await p.evaluate(SC[k]); }catch(e){ errs.push('EVAL '+e.message); } await p.waitForTimeout(600); }
   await p.screenshot({path:`${OUT}/${k}-${vp}${lang?'-'+lang:''}.png`}); if(errs.length) console.log(k,vp,errs.join(' | ')); await ctx.close(); } }
 await b.close(); console.log('done'); })();
