/* CAV art registry: sprites are generated once (lazily) from code and cached as Px + canvas + data-URL.
   Keys are namespaced 'cav.<group>.<name>'.  Sprite builders live in components/art-*.js. */
(function(){
var C=window.CAV, defs={}, cache={};
C.art = {
  define:function(key, build){ defs[key]=build; delete cache[key]; },
  has:function(key){ return !!defs[key] || !!cache[key]; },
  px:function(key){ var c=cache[key]; if(!c){ if(!defs[key]) throw new Error('CAV.art: unknown sprite '+key); c={px:defs[key]()}; cache[key]=c; } return c.px; },
  canvas:function(key){ var c=cache[key]; this.px(key); c=cache[key]; return c.cv||(c.cv=c.px.toCanvas()); },
  url:function(key){ var c; this.px(key); c=cache[key]; return c.url||(c.url=c.px.toURL()); },
  size:function(key){ var p=this.px(key); return {w:p.w,h:p.h}; },
  /* <img>/<canvas> element at native virtual size; CSS scales it by --u with image-rendering:pixelated */
  el:function(key, cls){ var p=this.px(key), cv=C.art.canvas(key), e=document.createElement('canvas'); e.width=p.w; e.height=p.h; e.getContext('2d').drawImage(cv,0,0);
    e.className='cav-spr '+(cls||''); e.style.width='calc(var(--u)*'+p.w+')'; e.style.height='calc(var(--u)*'+p.h+')'; e.setAttribute('aria-hidden','true'); e.dataset.spr=key; return e; },
  keys:function(){ return Object.keys(defs); },
  /* sized-by-parameter sprites (pieces at tile size etc.) */
  param:function(prefix, args, build){ var k=prefix+'@'+args.join('x'); if(!defs[k]) this.define(k,build); return k; }
};
})();
