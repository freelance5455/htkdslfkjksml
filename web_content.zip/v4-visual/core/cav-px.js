/* CAV Px: a tiny pixel-art drawing kit. Every sprite in the package is authored with this, so all art shares one grid,
   one outline rule, one light direction (top-left) and one palette.  No smoothing is ever applied. */
(function(){
'use strict';
var C = window.CAV;
var cc = {};
function rgba(hex){ if(cc[hex]) return cc[hex]; var h=hex.replace('#',''); if(h.length===3) h=h[0]+h[0]+h[1]+h[1]+h[2]+h[2];
  var v=[parseInt(h.slice(0,2),16),parseInt(h.slice(2,4),16),parseInt(h.slice(4,6),16),h.length>=8?parseInt(h.slice(6,8),16):255]; return cc[hex]=v; }

function Px(w,h){ this.w=w; this.h=h; this.d=new Uint8ClampedArray(w*h*4); }
Px.prototype = {
  inb:function(x,y){ return x>=0&&y>=0&&x<this.w&&y<this.h; },
  set:function(x,y,c){ x|=0; y|=0; if(!this.inb(x,y)||c==null) return this; var o=(y*this.w+x)*4, v=rgba(c);
    if(v[3]===255||this.d[o+3]===0){ this.d[o]=v[0];this.d[o+1]=v[1];this.d[o+2]=v[2];this.d[o+3]=v[3]; }
    else { var a=v[3]/255; this.d[o]=v[0]*a+this.d[o]*(1-a); this.d[o+1]=v[1]*a+this.d[o+1]*(1-a); this.d[o+2]=v[2]*a+this.d[o+2]*(1-a); this.d[o+3]=Math.min(255,this.d[o+3]+v[3]); }
    return this; },
  get:function(x,y){ if(!this.inb(x,y)) return null; var o=(y*this.w+x)*4; return [this.d[o],this.d[o+1],this.d[o+2],this.d[o+3]]; },
  solid:function(x,y){ return this.inb(x,y) && this.d[(y*this.w+x)*4+3]>0; },
  clear:function(){ this.d.fill(0); return this; },
  rect:function(x,y,w,h,c){ for(var j=0;j<h;j++) for(var i=0;i<w;i++) this.set(x+i,y+j,c); return this; },
  frame:function(x,y,w,h,c){ this.rect(x,y,w,1,c).rect(x,y+h-1,w,1,c).rect(x,y,1,h,c).rect(x+w-1,y,1,h,c); return this; },
  hline:function(x,y,w,c){ return this.rect(x,y,w,1,c); }, vline:function(x,y,h,c){ return this.rect(x,y,1,h,c); },
  line:function(x0,y0,x1,y1,c){ x0|=0;y0|=0;x1|=0;y1|=0; var dx=Math.abs(x1-x0),dy=-Math.abs(y1-y0),sx=x0<x1?1:-1,sy=y0<y1?1:-1,e=dx+dy;
    for(;;){ this.set(x0,y0,c); if(x0===x1&&y0===y1)break; var e2=2*e; if(e2>=dy){e+=dy;x0+=sx} if(e2<=dx){e+=dx;y0+=sy} } return this; },
  /* filled ellipse (pixel-exact: centre at cx,cy in pixel coords, radii rx,ry may be fractional like 4.5) */
  ellipse:function(cx,cy,rx,ry,c){ ry=ry==null?rx:ry; for(var y=Math.floor(cy-ry);y<=Math.ceil(cy+ry);y++) for(var x=Math.floor(cx-rx);x<=Math.ceil(cx+rx);x++){
      var dx=(x+.5-cx)/rx, dy=(y+.5-cy)/ry; if(dx*dx+dy*dy<=1) this.set(x,y,c); } return this; },
  ring:function(cx,cy,r,t,c){ for(var y=Math.floor(cy-r);y<=Math.ceil(cy+r);y++) for(var x=Math.floor(cx-r);x<=Math.ceil(cx+r);x++){
      var d=Math.hypot(x+.5-cx,y+.5-cy); if(d<=r&&d>r-t) this.set(x,y,c); } return this; },
  /* banded sphere/disc shading, light from top-left. ramp = [darkest..lightest] */
  shadeDisc:function(cx,cy,r,ramp,o){ o=o||{}; var n=ramp.length, B=[[0,8,2,10],[12,4,14,6],[3,11,1,9],[15,7,13,5]];
    for(var y=Math.floor(cy-r);y<=Math.ceil(cy+r);y++) for(var x=Math.floor(cx-r);x<=Math.ceil(cx+r);x++){
      var dx=(x+.5-cx)/r, dy=(y+.5-cy)/r, d2=dx*dx+dy*dy; if(d2>1) continue;
      var nz=Math.sqrt(1-d2), lam=-.5*dx-.6*dy+.62*nz;            /* lambert vs light from top-left */
      var t=Math.max(0,Math.min(.999,(lam+.35)/1.35)), f=t*(n-1), k=Math.floor(f), fr=f-k;
      if(o.dither && fr>(B[y&3][x&3]+.5)/16) k++;
      this.set(x,y,ramp[Math.max(0,Math.min(n-1,k))]); } return this; },
  /* bevelled rectangle: light edge top/left, dark edge bottom/right */
  bevel:function(x,y,w,h,ramp,o){ o=o||{}; var fill=o.fill!=null?o.fill:ramp[2], hi=ramp[o.hi!=null?o.hi:3], lo=ramp[o.lo!=null?o.lo:1], dk=ramp[0];
    this.rect(x,y,w,h,fill);
    this.hline(x,y,w,hi); this.vline(x,y,h,hi); this.hline(x,y+h-1,w,lo); this.vline(x+w-1,y,h,lo);
    if(o.edge!==false){ this.set(x,y+h-1,lo); this.set(x+w-1,y,hi); }
    if(o.outline) this.frame(x-1,y-1,w+2,h+2,o.outline); return this; },
  /* vertical / horizontal banded gradient with optional ordered dither between bands */
  gradient:function(x,y,w,h,ramp,o){ o=o||{}; var n=ramp.length, horiz=o.horizontal, dith=o.dither!==false;
    var B=[[0,8,2,10],[12,4,14,6],[3,11,1,9],[15,7,13,5]];
    for(var j=0;j<h;j++) for(var i=0;i<w;i++){ var t=horiz?i/(w-1||1):j/(h-1||1); var f=t*(n-1), k=Math.floor(f), fr=f-k;
        var idx = k + ((dith && fr > (B[(j)&3][(i)&3]+.5)/16)?1:0); this.set(x+i,y+j,ramp[Math.min(n-1,idx)]); } return this; },
  /* checker / bayer dither fill of a rect with two colours at density 0..1 */
  dither:function(x,y,w,h,c1,c2,dens){ var B=[[0,8,2,10],[12,4,14,6],[3,11,1,9],[15,7,13,5]]; dens=dens==null?.5:dens;
    for(var j=0;j<h;j++) for(var i=0;i<w;i++){ var on=(B[(y+j)&3][(x+i)&3]+.5)/16 < dens; var c=on?c2:c1; if(c) this.set(x+i,y+j,c); } return this; },
  /* scanline polygon fill, pts=[[x,y],...] */
  poly:function(pts,c){ var minY=1e9,maxY=-1e9; pts.forEach(function(p){minY=Math.min(minY,p[1]);maxY=Math.max(maxY,p[1])});
    for(var y=Math.floor(minY);y<=Math.ceil(maxY);y++){ var xs=[]; for(var i=0;i<pts.length;i++){ var a=pts[i], b=pts[(i+1)%pts.length];
        var y0=a[1],y1=b[1]; if(y0===y1) continue; var yy=y+.5; if((yy>=Math.min(y0,y1))&&(yy<Math.max(y0,y1))) xs.push(a[0]+(yy-y0)/(y1-y0)*(b[0]-a[0])); }
      xs.sort(function(a,b){return a-b}); for(var k=0;k+1<xs.length;k+=2){ for(var x=Math.round(xs[k]);x<Math.round(xs[k+1]);x++) this.set(x,y,c); } } return this; },
  /* 1px outline around all non-transparent pixels (4-neighbour; diag:true -> 8-neighbour) */
  outline:function(c,diag){ var src=new Uint8ClampedArray(this.d), w=this.w, h=this.h, self=this;
    function s(x,y){ return x>=0&&y>=0&&x<w&&y<h&&src[(y*w+x)*4+3]>0 }
    for(var y=-0;y<h;y++) for(var x=0;x<w;x++){ if(s(x,y)) continue;
      if(s(x-1,y)||s(x+1,y)||s(x,y-1)||s(x,y+1)||(diag&&(s(x-1,y-1)||s(x+1,y-1)||s(x-1,y+1)||s(x+1,y+1)))) self.set(x,y,c); }
    return this; },
  /* hard drop-shadow baked into the sprite (light is top-left, so shadow falls down-right) */
  shadow:function(c,dx,dy){ dx=dx==null?1:dx; dy=dy==null?1:dy; var src=new Uint8ClampedArray(this.d), w=this.w, h=this.h, out=new Uint8ClampedArray(this.d);
    var v=rgba(c); for(var y=0;y<h;y++) for(var x=0;x<w;x++){ var o=(y*w+x)*4; if(src[o+3]>0) continue; var sx=x-dx, sy=y-dy;
      if(sx>=0&&sy>=0&&sx<w&&sy<h&&src[(sy*w+sx)*4+3]>0){ out[o]=v[0];out[o+1]=v[1];out[o+2]=v[2];out[o+3]=v[3]; } } this.d=out; return this; },
  blit:function(src,x,y,o){ o=o||{}; for(var j=0;j<src.h;j++) for(var i=0;i<src.w;i++){ var sx=o.flipX?src.w-1-i:i, sy=o.flipY?src.h-1-j:j; var p=(sy*src.w+sx)*4; if(src.d[p+3]===0) continue;
      var tx=x+i, ty=y+j; if(!this.inb(tx,ty)) continue; var q=(ty*this.w+tx)*4;
      if(src.d[p+3]===255){ this.d[q]=src.d[p];this.d[q+1]=src.d[p+1];this.d[q+2]=src.d[p+2];this.d[q+3]=255; } else this.set(tx,ty,'#'+[0,1,2].map(function(k){return ('0'+src.d[p+k].toString(16)).slice(-2)}).join('')+('0'+src.d[p+3].toString(16)).slice(-2)); } return this; },
  /* swap colours: map {'#aabbcc':'#112233'} */
  recolor:function(map){ var m={}; for(var k in map){ m[rgba(k).slice(0,3).join(',')]=rgba(map[k]); } for(var i=0;i<this.d.length;i+=4){ if(!this.d[i+3]) continue; var r=m[this.d[i]+','+this.d[i+1]+','+this.d[i+2]]; if(r){this.d[i]=r[0];this.d[i+1]=r[1];this.d[i+2]=r[2];} } return this; },
  crop:function(x,y,w,h){ var o=new Px(w,h); o.blit(this,-x,-y); return o; },
  clone:function(){ var o=new Px(this.w,this.h); o.d.set(this.d); return o; },
  pad:function(l,t,r,b){ var o=new Px(this.w+l+r,this.h+t+b); o.blit(this,l,t); return o; },
  toCanvas:function(){ var cv=document.createElement('canvas'); cv.width=this.w; cv.height=this.h; var x=cv.getContext('2d'); x.putImageData(new ImageData(this.d,this.w,this.h),0,0); return cv; },
  toURL:function(){ return this.toCanvas().toDataURL('image/png'); }
};

/* ASCII sprite: rows of chars; map = {char: colour}; '.' or ' ' transparent */
Px.fromRows = function(rows, map){ var w=0; rows.forEach(function(r){w=Math.max(w,r.length)}); var p=new Px(w,rows.length);
  rows.forEach(function(r,y){ for(var x=0;x<r.length;x++){ var ch=r[x]; if(ch==='.'||ch===' ') continue; var c=map[ch]; if(c) p.set(x,y,c); } }); return p; };
/* ASCII with ramp digits: char '0'..'4' index into ramp; letters via map */
Px.fromRamp = function(rows, ramp, map){ var m=Object.assign({}, map||{}); ramp.forEach(function(c,i){ m[String(i)]=c; }); return Px.fromRows(rows,m); };

C.Px = Px;
})();
