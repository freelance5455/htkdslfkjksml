/* CAV palette — 'Club at dusk'.  Every colour is a 5-step ramp [0 darkest .. 4 lightest]; light comes from the TOP-LEFT.
   Rule: sprites may only use these ramps (+ K outlines).  ~120 colours total, grouped by material. */
(function(){
var C=window.CAV;
var P = C.pal = {
  K:   ['#0d0807','#1a0f0b','#2a1a12'],                     /* outlines: K[0] hard outline, K[1] soft, K[2] cast shadow base */
  walnut:  ['#24150d','#38200f','#4d2c16','#673b1e','#824c27'],  /* desk top */
  maple:   ['#9a6f3e','#b78a52','#d1a769','#e6c58a','#f4deaa'],  /* light squares */
  rosewood:['#3a1f16','#4f2a1c','#693824','#83472d','#9c5a38'],  /* dark squares */
  parch:   ['#8a7550','#ad9669','#c9b283','#e0cd9f','#f2e6c3'],
  leather: ['#26140d','#3d2217','#58301f','#763f29','#955236'],
  oxblood: ['#26090e','#3e1017','#5a1822','#7a232e','#9a3340'],
  brass:   ['#33230c','#5f4217','#8d6a22','#bd9535','#ecc864'],
  tarnish: ['#2a2511','#4b421c','#706429','#968a3c','#bdb066'],
  ivory:   ['#6f6552','#a69b82','#d2c8ad','#ede5cd','#fbf7e6'],
  ebony:   ['#0c0a10','#1a1820','#2a2832','#3d3b4a','#585668'],
  iron:    ['#1c1f24','#343a42','#4f5761','#737c88','#a0a9b4'],
  wax:     ['#340a10','#541019','#78192a','#a22838','#cf4558'],
  navy:    ['#080d1c','#101834','#1a2752','#2d3f80','#566bb0'],
  silver:  ['#464b58','#767d8d','#a3aabb','#ccd2de','#eef1f7'],
  violet:  ['#190d2b','#2d1749','#472674','#6a3ba0','#9a6dd0'],
  forest:  ['#0a1c13','#133022','#1e4636','#306450','#52866b'],
  crimson: ['#2a090b','#4c0f14','#761a1e','#a62b2d','#d44c46'],
  bronze:  ['#37200e','#5c391a','#85562a','#b27738','#dba55c'],
  steel:   ['#172230','#27384f','#3f5a7a','#6182a2','#8fb0ca'],
  teal:    ['#0b2224','#143a3c','#215a58','#38807a','#62a89c'],
  amber:   ['#3a1c08','#693110','#a2501a','#d67b2c','#f2b050'],
  felt:    ['#10281c','#18402b','#235a3c','#31784d','#4a9a68'],
  paper:   ['#9c9078','#c2b79c','#e1d9c3','#f3eddc','#fffcf0'],
  glow:    ['#5a3b10','#9b6a1c','#d4a02f','#f2cc58','#fff0a8']
};
/* archetypes: primary / secondary ramps + emblem id.  First six come from the art brief; the last four are PROVISIONAL
   (the brief mentions "ten archetypes" but lists six palettes) — gameplay dev may rename/replace them. */
C.archetypes = [
  {id:'gambler',     pri:'brass',  sec:'oxblood', emblem:'die',      accent:'amber'},
  {id:'chronomancer',pri:'navy',   sec:'silver',  emblem:'hourglass',accent:'silver'},
  {id:'martyr',      pri:'crimson',sec:'bronze',  emblem:'flame',    accent:'bronze'},
  {id:'oracle',      pri:'violet', sec:'ivory',   emblem:'eye',      accent:'ivory'},
  {id:'guardian',    pri:'iron',   sec:'steel',   emblem:'shield',   accent:'steel'},
  {id:'pactmaker',   pri:'forest', sec:'tarnish', emblem:'scroll',   accent:'tarnish'},
  {id:'duelist',     pri:'wax',    sec:'silver',  emblem:'blade',    accent:'silver',  provisional:true},
  {id:'alchemist',   pri:'teal',   sec:'brass',   emblem:'flask',    accent:'brass',   provisional:true},
  {id:'cartographer',pri:'leather',sec:'parch',   emblem:'compass',  accent:'parch',   provisional:true},
  {id:'herald',      pri:'amber',  sec:'ebony',   emblem:'horn',     accent:'amber',   provisional:true}
];
C.archetype = function(id){ for(var i=0;i<C.archetypes.length;i++) if(C.archetypes[i].id===id) return C.archetypes[i]; return null; };
/* rarity treatment: frame ramp, ornament level, foil */
C.rarities = {
  common:   {ramp:'iron',   corners:0, studs:2, label:'rarity.common'},
  rare:     {ramp:'brass',  corners:1, studs:4, label:'rarity.rare'},
  epic:     {ramp:'oxblood',corners:2, studs:4, label:'rarity.epic', trim:'brass'},
  legendary:{ramp:'glow',   corners:3, studs:4, label:'rarity.legendary', foil:true, trim:'brass'}
};
})();
