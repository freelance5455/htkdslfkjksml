/* CAV core: namespace, events, RNG, scaler (integer pixel scale), safe areas, motion prefs, i18n-lite.
   Classic script (works from file://). Everything lives under window.CAV — nothing else is global. */
(function(){
'use strict';
var C = window.CAV = window.CAV || {};
C.version = '4.0.0-visual-cp1';

/* ---------- tiny event emitter ---------- */
C.emitter = function(){ var m={}; return {
  on:function(e,f){(m[e]=m[e]||[]).push(f);return function(){m[e]=(m[e]||[]).filter(function(x){return x!==f})}},
  emit:function(e,a){(m[e]||[]).slice().forEach(function(f){try{f(a)}catch(x){console.error('[CAV]',e,x)}})}}};
C.bus = C.emitter();

/* ---------- seeded RNG (mulberry32) — visual only, never touches gameplay RNG ---------- */
C.rng = function(seed){ var t = (seed|0)>>>0;
  var f = function(){ t=(t+0x6D2B79F5)>>>0; var r=Math.imul(t^t>>>15,1|t); r^=r+Math.imul(r^r>>>7,61|r); return((r^r>>>14)>>>0)/4294967296 };
  f.int=function(a,b){return a+Math.floor(f()*(b-a+1))}; f.pick=function(a){return a[Math.floor(f()*a.length)]}; return f; };
C.hash = function(s){ var h=2166136261; for(var i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)} return h>>>0; };

/* ---------- DOM helper ---------- */
C.h = function(tag, attrs, kids){
  var e = document.createElement(tag); attrs = attrs||{};
  for (var k in attrs){ var v=attrs[k]; if(v==null||v===false) continue;
    if(k==='class') e.className=v; else if(k==='text') e.textContent=v; else if(k==='html') e.innerHTML=v;
    else if(k==='style') e.style.cssText=v; else if(k.slice(0,2)==='on') e.addEventListener(k.slice(2),v);
    else e.setAttribute(k, v===true?'':v); }
  (kids||[]).forEach(function(c){ if(c==null||c===false) return; e.appendChild(typeof c==='string'?document.createTextNode(c):c); });
  return e; };

/* ---------- settings (visual only; host can override via CAV.settings.set) ---------- */
C.settings = (function(){
  var s = { lang:'auto', reducedMotion:null, uiScale:'auto', audioHooks:true, hand:'right' }, em=C.emitter();
  try{ var saved=JSON.parse(localStorage.getItem('cav_visual_settings')||'null'); if(saved) for(var k in saved) s[k]=saved[k]; }catch(e){}
  return { get:function(k){return s[k]}, all:function(){return s},
    set:function(k,v){ s[k]=v; try{localStorage.setItem('cav_visual_settings',JSON.stringify(s))}catch(e){} em.emit('change',{key:k,value:v}); C.bus.emit('settings',{key:k,value:v}); },
    on:em.on };
})();
C.reducedMotion = function(){ var v=C.settings.get('reducedMotion'); if(v===null||v===undefined) return !!(window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches); return !!v; };

/* ---------- i18n-lite (host should pass its own t(); this is only for the standalone demo) ---------- */
C.i18n = (function(){
  var dict = {}, lang = 'en';
  function detect(){ var l=C.settings.get('lang'); if(l&&l!=='auto') return l; var n=(navigator.language||'en'); return /^pt/i.test(n)?'pt-BR':'en'; }
  return {
    add:function(l,obj){ dict[l]=Object.assign(dict[l]||{},obj) },
    setLang:function(l){ lang = l||detect(); document.documentElement.setAttribute('lang',lang); C.bus.emit('lang',lang); },
    lang:function(){ return lang }, detect:detect,
    t:function(k,vars){ var s=(dict[lang]&&dict[lang][k]); if(s==null) s=(dict.en&&dict.en[k]); if(s==null) s=k;
      if(vars) s=s.replace(/\{(\w+)\}/g,function(_,n){return vars[n]!=null?vars[n]:''}); return s; },
    has:function(k){ return !!(dict[lang]&&dict[lang][k]) || !!(dict.en&&dict.en[k]); }
  };
})();
C.t = C.i18n.t;

/* ---------- text metrics (bitmap font) ---------- */
C.textWidth = function(str){ var w=0, a=C.fontAdv||{}; for(var i=0;i<str.length;i++) w += (a[str[i]]||6); return Math.max(0,w-1); };

/* ---------- Stage scaler: integer pixel scale, virtual viewport, safe areas ---------- */
/* Virtual px = one art pixel. CSS px = virtual * s.  s is ALWAYS an integer so art stays crisp. */
C.stage = (function(){
  var em = C.emitter(), st = {s:2, vw:320, vh:180, tile:20, portrait:false, density:'compact', safe:{l:0,r:0,t:0,b:0}}, root=null, probe=null;
  function measureSafe(s){
    if(!probe){ probe=document.createElement('div'); probe.style.cssText='position:fixed;left:0;top:0;width:0;height:0;visibility:hidden;pointer-events:none;'+
      'padding:env(safe-area-inset-top,0px) env(safe-area-inset-right,0px) env(safe-area-inset-bottom,0px) env(safe-area-inset-left,0px)'; document.body.appendChild(probe); }
    var cs=getComputedStyle(probe); function v(p){return Math.ceil((parseFloat(cs[p])||0)/s)}
    return {t:v('paddingTop'),r:v('paddingRight'),b:v('paddingBottom'),l:v('paddingLeft')};
  }
  /* pick integer scale: virtual viewport must stay >= 320x176 when possible and <= ~ 480x270 on big screens */
  function pickScale(W,H){
    var ov=C.settings.get('uiScale'); if(ov && ov!=='auto') return Math.max(1,parseInt(ov,10)||2);
    var s = Math.floor(Math.min(W/400, H/225)); if (s<2) s=2;
    if (W/s < 300 || H/s < 150) s = Math.max(1, s-1);   /* tiny phones: fall back to 1x rather than clip */
    return s;
  }
  function boardTile(vw,vh,safe){
    /* board is square: height-limited in landscape.  8 tiles + 2*frame(4) + margins */
    var availH = vh - safe.t - safe.b - 6, t = Math.floor((availH-8)/8);
    return Math.max(14, Math.min(34, t));
  }
  function apply(){
    var W=window.innerWidth, H=window.innerHeight, portrait = H > W && W < 760;
    var s=pickScale(W,H), vw=Math.floor(W/s), vh=Math.floor(H/s), safe=measureSafe(s);
    var density = vh < 200 ? 'compact' : vh < 250 ? 'regular' : 'roomy';
    st = {s:s, vw:vw, vh:vh, W:W, H:H, portrait:portrait, density:density, safe:safe, tile:boardTile(vw,vh,safe)};
    var r=document.documentElement.style;
    r.setProperty('--s', s); r.setProperty('--u', s+'px'); r.setProperty('--vw', vw); r.setProperty('--vh', vh);
    r.setProperty('--tile', st.tile); r.setProperty('--sat', safe.t); r.setProperty('--sab', safe.b); r.setProperty('--sal', safe.l); r.setProperty('--sar', safe.r);
    document.documentElement.setAttribute('data-density', density);
    document.documentElement.setAttribute('data-portrait', portrait?'1':'0');
    em.emit('resize', st); C.bus.emit('resize', st);
  }
  var tm=null;
  function sched(){ clearTimeout(tm); tm=setTimeout(apply, 60); }
  return { init:function(){ apply(); window.addEventListener('resize',sched); window.addEventListener('orientationchange',sched);
      if(window.visualViewport) window.visualViewport.addEventListener('resize',sched); },
    get:function(){return st}, on:em.on, refresh:apply };
})();

/* ---------- px helper for CSS calc in JS ---------- */
C.px = function(n){ return (n*C.stage.get().s)+'px'; };

/* ---------- audio hooks: the visual layer only *announces* sounds; host maps them to its audio ---------- */
C.sfx = function(name, data){ if(C.settings.get('audioHooks')) C.bus.emit('sfx', {name:name, data:data}); };
})();
