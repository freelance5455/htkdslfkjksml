# Art direction (short)
Integer pixel scale, light top-left, 1px dark outline, baked hard shadow, ~120-colour ramps (`core/cav-palette.js`), selective dither, original bitmap font. Desk objects: strict top-down; board pieces: approved reference set (front-view) supplied by art direction. States are CSS lifts/outlines (no smoothing). Stage I sparse → IV supernatural via composition only.
