/* CAV.screens: title menu, settings, desk guide. */
(function(){
var C=window.CAV, h=C.h, A=C.art, ui=C.ui, T=C.t; C.screens=C.screens||{};
C.screens.menu={ create:function(o){ var st=C.stage.get(), el=h('div',{class:'cav-menu'}), deck=h('div',{class:'ws-deskh'});
  function build(){ var s=C.stage.get(); deck.innerHTML=''; deck.appendChild(A.el(A.desk(s.vw,s.vh),'ws-desk')); }
  build(); var pieces=h('div',{class:'mn-pieces'}); ['r','n','b','q','k','b','n','r'].forEach(function(t,i){ pieces.appendChild(A.el(A.piece(t,i%2===0,28))); });
  var box=h('div',{class:'mn-box'},[h('div',{class:'cav-t2 cav-brass cav-shadow-text cav-c mn-title',text:T('cav.title')}),pieces,
    h('div',{class:'mn-btns'},[ui.btn({label:T('cav.menu.start'),big:true,kind:'brass',icon:'right',cls:'bo-primary',onClick:function(){ o.onStart&&o.onStart(); }}),ui.btn({label:T('cav.menu.settings'),kind:'wood',icon:'gear',onClick:function(){ o.onSettings&&o.onSettings(); }})]),h('div',{class:'cav-dim cav-c',text:T('cav.menu.credits')})]);
  el.appendChild(deck); el.appendChild(box); var un=C.stage.on('resize',build); return { el:el, destroy:function(){ un(); el.remove(); } }; } };
C.screens.settings={ open:function(o){ o=o||{}; var body=h('div',{class:'st'});
  function row(label,ctrl){ return h('div',{class:'st-row'},[h('span',{class:'cav-fill',text:label}),ctrl]); }
  function seg(opts,cur,fn){ var w=h('div',{class:'st-seg'}); opts.forEach(function(op){ var b=ui.btn({label:op[1],kind:String(cur)===String(op[0])?'brass':'wood',onClick:function(){ fn(op[0]); render(); }}); w.appendChild(b); }); return w; }
  function render(){ body.innerHTML='';
    body.appendChild(row(T('cav.set.lang'),seg([['auto',T('cav.set.auto')],['en','EN'],['pt-BR','PT']],C.settings.get('lang'),function(v){ C.settings.set('lang',v); C.i18n.setLang(v==='auto'?C.i18n.detect():v); if(o.onLang) o.onLang(); })));
    body.appendChild(row(T('cav.set.motion'),seg([[true,T('cav.on')],[false,T('cav.off')]],C.reducedMotion(),function(v){ C.settings.set('reducedMotion',v); })));
    body.appendChild(row(T('cav.set.labels'),seg([['auto',T('cav.set.auto')],['on',T('cav.on')],['off',T('cav.off')]],C.settings.get('labels')||'auto',function(v){ C.settings.set('labels',v); o.onChange&&o.onChange(); })));
    body.appendChild(row(T('cav.set.hand'),seg([['left',T('cav.set.left')],['right',T('cav.set.right')]],C.settings.get('hand'),function(v){ C.settings.set('hand',v); o.onChange&&o.onChange(); })));
    body.appendChild(row(T('cav.set.coords'),seg([[true,T('cav.on')],[false,T('cav.off')]],C.settings.get('coords')!==false,function(v){ C.settings.set('coords',v); o.onChange&&o.onChange(); })));
    if(o.onStage){ body.appendChild(row(T('cav.fd.stage'),seg([[1,'I'],[2,'II'],[3,'III'],[4,'IV']],o.stage||1,function(v){ o.stage=v; o.onStage(v); }))); body.appendChild(row(T('cav.fd.reset'),ui.btn({label:'↺',kind:'wood',onClick:function(){ o.onReset&&o.onReset(); }}))); }
    body.appendChild(row(T('cav.set.scale'),seg([['auto',T('cav.set.auto')],['1','1×'],['2','2×'],['3','3×']],C.settings.get('uiScale')||'auto',function(v){ C.settings.set('uiScale',v); C.stage.refresh(); }))); }
  render(); return ui.overlay.open({id:'settings',title:T('cav.set.title'),content:body,kind:'wood',icon:'gear'}); } };
C.screens.guide={ open:function(){ var objs=C.screens.workstation.objects.left.concat(C.screens.workstation.objects.right), g=h('div',{class:'gd-grid'});
  objs.forEach(function(id){ var spr=id==='clock'?A.clock(9,30):id==='parcel'?A.parcel('closed',1):({appointment:'cav.obj.appointment',catalog:'cav.obj.catalog',album:'cav.obj.album',deck:'cav.obj.deck',relic:'cav.obj.relic',enchant:'cav.obj.enchant',ledger:'cav.obj.ledger',mail:'cav.obj.mail',calendar:'cav.obj.calendar'})[id]; g.appendChild(h('div',{class:'gd-it'},[h('span',{class:'gd-ic'},[A.el(spr)]),h('span',{text:T('cav.obj.'+id)})])); });
  return ui.overlay.open({id:'guide',title:T('cav.guide.title'),content:h('div',{class:'gd'},[h('div',{class:'cav-dim',text:T('cav.guide.tip')}),g]),kind:'wood',icon:'eye'}); } };
})();
