/* CAV.screens.workstation — the top-down desk. Presentation only.
   createWorkstation({ state, onObject(id), onSettings(), onHelp() }) -> { el, board, setState(patch), setMode(), rails }
   state: {day, minutes, doubloons, badges:{appointment,mail,parcel,catalog}, ringing, labels, handSide} */
(function(){
var C=window.CAV, h=C.h, A=C.art, ui=C.ui, T=C.t;
var LEFT=['appointment','catalog','album','deck','relic','enchant'], RIGHT=['ledger','mail','calendar','clock','parcel'];
var SPR={appointment:'cav.obj.appointment',catalog:'cav.obj.catalog',album:'cav.obj.album',deck:'cav.obj.deck',relic:'cav.obj.relic',enchant:'cav.obj.enchant',ledger:'cav.obj.ledger',mail:'cav.obj.mail',calendar:'cav.obj.calendar'};
C.screens=C.screens||{};
C.screens.workstation={ objects:{left:LEFT,right:RIGHT},
 create:function(o){ o=o||{}; var S=Object.assign({day:1,minutes:9*60,doubloons:0,badges:{},ringing:false,labels:'auto',mode:'desk'},o.state||{});
  var el=h('div',{class:'cav-ws'}), deskHolder=h('div',{class:'ws-deskh'}), grid=h('div',{class:'ws-grid'}), left=h('div',{class:'ws-rail ws-left'}), right=h('div',{class:'ws-rail ws-right'}), center=h('div',{class:'ws-center'});
  var caption=h('div',{class:'ws-caption'}), objEls={}, free=null, board=C.board.create({coords:C.settings.get('coords')!==false,onSquare:function(sq,e){ if(api.onSquare) api.onSquare(sq,e); }});
  center.appendChild(board.el); grid.appendChild(left); grid.appendChild(center); grid.appendChild(right); el.appendChild(deskHolder); el.appendChild(grid); el.appendChild(caption);
  function setCaption(t){ caption.innerHTML=''; if(t) caption.appendChild(ui.panel('plaque',[h('span',{text:t})],'')); }
  function objBtn(id){ var b=h('button',{type:'button',class:'ws-obj','data-obj':id,'aria-label':T('cav.obj.'+id)}), sp;
    if(id==='clock') sp=A.el(A.clock(Math.floor(S.minutes/60),Math.floor(S.minutes%60/10)*10)); else if(id==='parcel') sp=A.el(A.parcel('closed',1)); else sp=A.el(SPR[id]);
    b.appendChild(sp); b.appendChild(h('span',{class:'ws-lab',text:T('cav.obj.'+id)}));
    if(id==='calendar') b.appendChild(h('span',{class:'ws-dayno',text:String(S.day)}));
    var bd=S.badges&&S.badges[id]; if(bd) b.appendChild(h('span',{class:'cav-badge',text:String(bd)}));
    if(S.ringing&&id==='appointment') b.classList.add('is-ring');
    if(id==='parcel'&&!(S.badges&&S.badges.parcel)) b.classList.add('is-locked');
    ['pointerenter','focus'].forEach(function(ev){ b.addEventListener(ev,function(){ setCaption(T('cav.obj.'+id)); }); }); ['pointerleave','blur'].forEach(function(ev){ b.addEventListener(ev,function(){ setCaption(''); }); });
    b.addEventListener('pointerdown',function(){ setCaption(T('cav.obj.'+id)); }); b.addEventListener('click',function(){ C.sfx('desk.object',{id:id}); if(o.onObject) o.onObject(id); setTimeout(function(){ setCaption(''); },600); });
    objEls[id]=b; return b; }
  function hud(){ var coin=h('div',{class:'ws-hud'},[A.el('cav.obj.coin'),h('span',{text:String(S.doubloons)}),h('span',{class:'cav-dim',text:' · '+T('cav.day',{n:S.day})})]); return ui.panel('plaque',[coin.children[0],coin.children[1]],'ws-hud ws-coinhud'); }
  function sysCell(){ var w=h('div',{class:'ws-sys-cell cav-col',style:'gap:calc(var(--u)*2);align-items:center'},[ui.btn({icon:'gear',kind:'wood',aria:T('cav.settings'),onClick:function(){ o.onSettings&&o.onSettings(); }}),ui.btn({icon:'eye',kind:'wood',aria:T('cav.help'),onClick:function(){ o.onHelp&&o.onHelp(); }})]); w.style.flexDirection='row'; return w; }
  function geo(){ var st=C.stage.get(), bw=st.tile*8+8, bl=Math.round((st.vw-bw)/2), l=st.safe.l+2, r=st.vw-st.safe.r-2, t=st.safe.t+2, b=st.vh-st.safe.b-2;
    return { vw:st.vw, vh:st.vh, L:{l:l,t:t,r:bl-2,b:b}, R:{l:bl+bw+2,t:t+20,r:r,b:b-22}, all:{l:l,t:t,r:r,b:b} }; }
  function home(inst){ var g=geo(), hm=inst.home||{side:'L',u:.5,v:.5}, a=g[hm.side]||g.L, sz=C.objects.size(inst,{minutes:S.minutes}), off=0;
    return { x:Math.round(a.l+hm.u*Math.max(0,a.r-a.l-sz.w)), y:Math.round(a.t+hm.v*Math.max(0,a.b-a.t-sz.h)) }; }
  function mountFree(){ var F=o.freeform; if(free&&free.insts!==F.insts){ free.destroy(); free=null; }
    if(!free){ free=C.freeDesk.create({ insts:F.insts, ctx:{minutes:S.minutes}, area:function(){ return geo().all; }, home:home,
      badges:function(i){ return (S.badges&&S.badges[i.id])||0; }, caption:setCaption,
      decorate:function(i,e){ if(i.id==='calendar'){ var d=e.querySelector('.ws-dayno'); if(!d){ d=h('span',{class:'ws-dayno'}); e.appendChild(d); } d.textContent=String(S.day); } },
      label:F.label, onTap:function(i,d){ C.sfx('desk.object',{id:d.action}); if(o.onObject) o.onObject(d.action,i); }, onInspect:F.onInspect, onChange:F.onChange, onRead:F.onRead });
      el.appendChild(free.el); el.appendChild(free.top); }
    else { free.setVisible(true); free.relayout(); free.refreshSprites({minutes:S.minutes}); } }
  function layout(){ var st=C.stage.get(); var w=st.vw, hh=st.vh;
    /* desk surface */
    deskHolder.innerHTML=''; var d=A.el(A.desk(w,hh),'ws-desk'); deskHolder.appendChild(d);
    left.innerHTML=''; right.innerHTML=''; objEls={};
    if(S.mode==='match'){ left.classList.remove('free-l'); right.classList.remove('free-r'); if(free) free.setVisible(false); }
    else if(o.freeform){ left.classList.add('free-l'); right.classList.add('free-r'); right.appendChild(hud()); right.appendChild(h('span')); right.appendChild(sysCell()); mountFree(); }
    else {
    var side=C.settings.get('hand')==='left'; var L=side?RIGHT.slice():LEFT.slice(), R=side?LEFT.slice():RIGHT.slice();
    L.forEach(function(id){ left.appendChild(objBtn(id)); });
    right.appendChild(S.mode==='desk'?hud():h('div')); R.forEach(function(id){ right.appendChild(objBtn(id)); }); right.appendChild(sysCell()); }
    var lab=C.settings.get('labels'); var railW=(w-(st.tile*8+8))/2-4-Math.max(2,st.safe.l); var on=lab==='on'||(lab!=='off'&&railW/2>=46);
    document.documentElement.setAttribute('data-labels',on?'1':'0'); }
  var api={ el:el, board:board, setCaption:setCaption, objects:function(){ return objEls; },
    setState:function(p){ Object.assign(S,p); layout(); }, state:function(){ return S; },
    setMinutes:function(m){ S.minutes=m; if(free) free.refreshSprites({minutes:m}); var b=objEls.clock; if(b){ b.replaceChild(A.el(A.clock(Math.floor(m/60),Math.floor(m%60/10)*10)),b.firstChild); } },
    refresh:layout, free:function(){ return free; }, rails:{left:left,right:right,center:center,grid:grid}, destroy:function(){ unsub(); el.remove(); } };
  var unsub=C.stage.on('resize',function(){ layout(); });
  layout(); return api; } };
})();
