DOSTGRAM — Offline demo app

WHAT'S INCLUDED
- index.html: complete offline app
- Login with username and profile photo
- Instagram-inspired dark home screen branded DOSTGRAM / by Anshuman Jat
- Only your own story bubble; no other users' stories
- Reels, Search and Messages show Coming Soon
- Add photo posts; posts appear in your home feed and profile grid
- Three sample/fake feed posts
- Profile and posts are saved locally in this browser/device (localStorage)

HOW TO RUN
1. Extract this ZIP.
2. Open index.html in Chrome or another modern browser.
3. On first launch, enter a username, choose a profile photo, and tap Continue.

IMPORTANT
This is an offline front-end prototype, not a published Android APK. Data stays on the same browser/device and is not synced between devices. Clearing browser data can erase saved profile/posts. For an installable APK, this project can be wrapped in an Android WebView project.
