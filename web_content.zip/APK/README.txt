यहाँ तैयार APK रखा जाएगा.
इस प्रोजेक्ट को Android Studio में Build APK करने के बाद:
app/build/outputs/apk/debug/app-debug.apk
को इस APK/ folder में कॉपी करें.
