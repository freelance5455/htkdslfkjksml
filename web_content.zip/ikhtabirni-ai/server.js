import express from "express";
import rateLimit from "express-rate-limit";
import OpenAI from "openai";
import dotenv from "dotenv";
import path from "node:path";
import { fileURLToPath } from "node:url";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const port = Number(process.env.PORT || 3000);

app.disable("x-powered-by");
app.use(express.json({ limit: "12kb" }));
app.use(express.static(path.join(__dirname, "public"), {
  extensions: ["html"],
  dotfiles: "deny",
  index: "index.html"
}));

const limiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 5,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "طلبات كثيرة خلال دقيقة واحدة. انتظر قليلًا ثم حاول مجددًا." }
});

const quizSchema = {
  type: "object",
  additionalProperties: false,
  properties: {
    questions: {
      type: "array",
      minItems: 1,
      maxItems: 20,
      items: {
        type: "object",
        additionalProperties: false,
        properties: {
          q: { type: "string" },
          opts: {
            type: "array",
            minItems: 4,
            maxItems: 4,
            items: { type: "string" }
          },
          correct: { type: "integer", minimum: 0, maximum: 3 },
          explain: { type: "string" }
        },
        required: ["q", "opts", "correct", "explain"]
      }
    }
  },
  required: ["questions"]
};

app.post("/api/generate-quiz", limiter, async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return res.status(503).json({
        error: "الخادم غير مُعدّ بعد: أضف OPENAI_API_KEY في إعدادات البيئة على الخادم."
      });
    }

    const { subject, level, lesson, count, difficulty } = req.body ?? {};
    const allowedSubjects = new Set([
      "الرياضيات", "العلوم الطبيعية", "الفيزياء", "اللغة العربية",
      "اللغة الفرنسية", "اللغة الإنجليزية", "التاريخ والجغرافيا",
      "التربية الإسلامية", "التربية المدنية", "موضوع آخر"
    ]);
    const allowedLevels = new Set([
      "السنة الأولى متوسط", "السنة الثانية متوسط",
      "السنة الثالثة متوسط", "السنة الرابعة متوسط"
    ]);
    const allowedDifficulties = new Set(["سهل", "متوسط", "صعب", "متدرج"]);
    const n = Number(count);

    if (!allowedSubjects.has(subject) || !allowedLevels.has(level) ||
        !allowedDifficulties.has(difficulty) || !Number.isInteger(n) ||
        n < 5 || n > 20 || ![5, 10, 15, 20].includes(n) ||
        typeof lesson !== "string" || lesson.trim().length < 2 ||
        lesson.length > 160) {
      return res.status(400).json({ error: "المعلومات غير مكتملة أو غير صالحة. راجع المادة والمستوى والدرس وعدد الأسئلة." });
    }

    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const prompt = [
      "أنشئ اختبارًا مدرسيًا باللغة العربية وفق المستوى الدراسي والمنهاج الجزائري قدر الإمكان.",
      "لا تدّعِ أنك تحققت من كتاب مدرسي بعينه إذا لم يُرفق نصه. استخدم معلومات تعليمية مستقرة، وتجنب اختلاق حقائق.",
      "اكتب بالضبط العدد المطلوب من أسئلة الاختيار من متعدد.",
      "لكل سؤال أربعة خيارات مختلفة ومعقولة، وإجابة صحيحة واحدة فقط، ورقم correct هو فهرس الإجابة الصحيحة من 0 إلى 3.",
      "اكتب شرحًا عربيًا قصيرًا يوضح سبب صحة الإجابة. اجعل الأسئلة متنوعة ولا تكرر الفكرة نفسها.",
      "إذا كان عنوان الدرس غامضًا جدًا، أنشئ أسئلة عامة آمنة حول ما يمكن استنتاجه فقط، ولا تخترع تفاصيل.",
      `المادة: ${subject}`,
      `المستوى: ${level}`,
      `الدرس: ${lesson.trim()}`,
      `عدد الأسئلة: ${n}`,
      `الصعوبة: ${difficulty}`,
      "أعد النتيجة فقط وفق مخطط JSON المطلوب."
    ].join("\n");

    const result = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
      input: prompt,
      max_output_tokens: 6000,
      text: {
        format: {
          type: "json_schema",
          name: "school_quiz",
          strict: true,
          schema: quizSchema
        }
      }
    });

    const raw = result.output_text;
    if (!raw) throw new Error("لم تُرجع الخدمة نصًا.");
    const parsed = JSON.parse(raw);
    const questions = parsed.questions;

    if (!Array.isArray(questions) || questions.length !== n) {
      throw new Error("عدد الأسئلة المُرجع لا يطابق العدد المطلوب.");
    }
    for (const q of questions) {
      if (typeof q.q !== "string" || !q.q.trim() ||
          !Array.isArray(q.opts) || q.opts.length !== 4 ||
          q.opts.some(o => typeof o !== "string" || !o.trim()) ||
          new Set(q.opts.map(o => o.trim())).size !== 4 ||
          !Number.isInteger(q.correct) || q.correct < 0 || q.correct > 3 ||
          typeof q.explain !== "string") {
        throw new Error("تحتوي النتيجة على سؤال غير صالح.");
      }
    }

    res.json({ questions });
  } catch (error) {
    console.error("Quiz generation failed:", error?.status || error?.message || "unknown error");
    if (error?.status === 401) {
      return res.status(502).json({ error: "رفضت الخدمة مفتاح API. تحقق منه في إعدادات الخادم دون إرساله لأحد." });
    }
    if (error?.status === 429) {
      return res.status(429).json({ error: "بلغت الخدمة حد الاستخدام أو لا تتوفر حصة كافية. راجع إعدادات الاستخدام والفوترة." });
    }
    return res.status(502).json({ error: "تعذّر توليد الأسئلة الآن. تحقق من اتصال الخادم وإعدادات الخدمة ثم حاول مجددًا." });
  }
});

app.get("/api/health", (_req, res) => res.json({ ok: true }));

app.listen(port, () => {
  console.log(`Ikhtabirni is running on http://localhost:${port}`);
});
