package eu.lindus.navigation

import java.util.concurrent.CopyOnWriteArraySet

/**
 * In-memory bridge for the latest device location and motion values.
 * Data is runtime-only and is not persisted.
 */
object LindUsLocationState {
    data class Position(
        val latitude: Double,
        val longitude: Double,
        val bearingDegrees: Float?,
        val speedMetersPerSecond: Float?,
        val accuracyMeters: Float?
    )

    @Volatile var current: Position? = null
        private set

    private val listeners = CopyOnWriteArraySet<() -> Unit>()

    fun update(
        latitude: Double,
        longitude: Double,
        bearingDegrees: Float?,
        speedMetersPerSecond: Float?,
        accuracyMeters: Float?
    ) {
        current = Position(latitude, longitude, bearingDegrees, speedMetersPerSecond, accuracyMeters)
        // Ignore inaccurate GPS samples for off-route decisions.
        if (accuracyMeters == null || accuracyMeters <= 35f) {
            if (LindUsRouteState.navigationActive) {
                val progress = LindUsRouteState.updateProgress(latitude, longitude)
                if (progress?.offRoute == true) LindUsRoutePlanner.rerouteCurrentRoute()
                LindUsSpeedLimitProvider.updateLocation(latitude, longitude)
            }
        }
        listeners.forEach { listener -> try { listener() } catch (_: Exception) {} }
    }

    fun addListener(listener: () -> Unit) { listeners.add(listener) }
    fun removeListener(listener: () -> Unit) { listeners.remove(listener) }
}
