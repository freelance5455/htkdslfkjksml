package eu.lindus.navigation

import android.net.Uri
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

object LindUsRoutePlanner {
    private val executor = Executors.newSingleThreadExecutor()
    private val rerouteInProgress = AtomicBoolean(false)
    @Volatile private var lastRerouteAt = 0L

    fun handleNavigationUri(uri: Uri?) {
        if (uri == null) return
        val destination = when (uri.scheme?.lowercase()) {
            "google.navigation" -> uri.getQueryParameter("q")
            "geo" -> uri.getQueryParameter("q")?.substringBefore("(")?.trim()
            else -> uri.getQueryParameter("q")
        }?.takeIf { it.isNotBlank() } ?: return
        plan(destination)
    }

    fun plan(destination: String) {
        LindUsRouteState.setStatus("Úti cél keresése: $destination")
        executor.execute {
            try {
                val origin = LindUsLocationState.current
                    ?: throw IllegalStateException("A telefon GPS-pozíciója még nem érhető el.")
                val encoded = URLEncoder.encode(destination, "UTF-8")
                val geocode = getJson("https://nominatim.openstreetmap.org/search?q=$encoded&format=jsonv2&limit=1")
                val places = geocode as? org.json.JSONArray ?: throw IllegalStateException("Érvénytelen geokódolási válasz.")
                if (places.length() == 0) throw IllegalStateException("Az úti cél nem található.")
                val place = places.getJSONObject(0)
                requestRoute(
                    origin.latitude, origin.longitude,
                    place.getDouble("lat"), place.getDouble("lon"),
                    place.optString("display_name", destination).substringBefore(","),
                    "Útvonaltervezés"
                )
            } catch (e: Exception) {
                LindUsRouteState.clear()
                LindUsRouteState.setStatus(e.message ?: "Útvonaltervezési hiba.")
            }
        }
    }

    /** Called after several consecutive GPS samples show the vehicle away from the route. */
    fun rerouteCurrentRoute() {
        val route = LindUsRouteState.current ?: return
        val now = System.currentTimeMillis()
        if (now - lastRerouteAt < 20000L || !rerouteInProgress.compareAndSet(false, true)) return
        val origin = LindUsLocationState.current ?: run { rerouteInProgress.set(false); return }
        lastRerouteAt = now
        LindUsRouteState.setStatus("Letérés észlelve – új útvonal keresése…")
        executor.execute {
            try {
                requestRoute(
                    origin.latitude, origin.longitude,
                    route.destinationLatitude, route.destinationLongitude,
                    route.destinationName,
                    "Újratervezés"
                )
            } catch (e: Exception) {
                LindUsRouteState.setStatus("Újratervezés sikertelen: ${e.message ?: "hálózati hiba"}")
            } finally {
                rerouteInProgress.set(false)
            }
        }
    }

    private fun requestRoute(
        originLat: Double, originLon: Double,
        destLat: Double, destLon: Double,
        destinationName: String,
        label: String
    ) {
        LindUsRouteState.setStatus("$label: $destinationName")
        val url = "https://router.project-osrm.org/route/v1/driving/$originLon,$originLat;$destLon,$destLat?overview=full&geometries=geojson&steps=true"
        val routeJson = getJson(url) as? JSONObject ?: throw IllegalStateException("Érvénytelen útvonalválasz.")
        if (routeJson.optString("code") != "Ok") throw IllegalStateException("Nem található autós útvonal.")
        val route = routeJson.getJSONArray("routes").getJSONObject(0)
        val coords = route.getJSONObject("geometry").getJSONArray("coordinates")
        val points = ArrayList<Pair<Double, Double>>(coords.length())
        for (i in 0 until coords.length()) {
            val coord = coords.getJSONArray(i)
            points.add(coord.getDouble(1) to coord.getDouble(0))
        }
        val maneuvers = ArrayList<LindUsRouteState.Maneuver>()
        val legs = route.optJSONArray("legs")
        if (legs != null && legs.length() > 0) {
            val steps = legs.getJSONObject(0).optJSONArray("steps")
            if (steps != null) for (i in 0 until steps.length()) {
                val step = steps.getJSONObject(i)
                val maneuver = step.optJSONObject("maneuver") ?: continue
                val location = maneuver.optJSONArray("location") ?: continue
                if (location.length() < 2) continue
                val type = maneuver.optString("type", "continue")
                val modifier = maneuver.optString("modifier", "")
                val road = step.optString("name", "")
                maneuvers.add(
                    LindUsRouteState.Maneuver(
                        hungarianInstruction(type, modifier, road), road,
                        step.optDouble("distance", 0.0),
                        location.getDouble(1), location.getDouble(0)
                    )
                )
            }
        }
        LindUsRouteState.setRoute(
            LindUsRouteState.Route(
                destinationName, points, route.getDouble("distance"), route.getDouble("duration"),
                maneuvers, destLat, destLon
            )
        )
    }

    private fun hungarianInstruction(type: String, modifier: String, road: String): String {
        val direction = when (modifier.lowercase()) {
            "uturn" -> "Fordulj vissza"
            "sharp right", "right" -> "Fordulj jobbra"
            "slight right" -> "Tarts enyhén jobbra"
            "sharp left", "left" -> "Fordulj balra"
            "slight left" -> "Tarts enyhén balra"
            "straight" -> "Haladj egyenesen"
            else -> ""
        }
        val base = when (type.lowercase()) {
            "depart" -> "Indulj el"
            "arrive" -> "Megérkeztél"
            "roundabout", "rotary" -> "Hajts be a körforgalomba"
            "merge" -> "Csatlakozz"
            "on ramp" -> "Hajts fel a felhajtón"
            "off ramp" -> "Hajts le a lehajtón"
            "fork" -> if (direction.isNotEmpty()) direction else "Válassz elágazást"
            "end of road" -> if (direction.isNotEmpty()) direction else "Az út végén fordulj"
            "new name", "continue" -> if (direction.isNotEmpty()) direction else "Haladj tovább"
            else -> if (direction.isNotEmpty()) direction else "Haladj tovább"
        }
        return if (road.isNotBlank()) "$base erre: $road" else base
    }

    private fun getJson(address: String): Any {
        var connection: HttpURLConnection? = null
        return try {
            connection = URL(address).openConnection() as HttpURLConnection
            connection.connectTimeout = 8000
            connection.readTimeout = 12000
            connection.setRequestProperty("User-Agent", "LIND-US-Navigation/2.0 (Android prototype)")
            connection.connect()
            if (connection.responseCode !in 200..299) throw IllegalStateException("Hálózati hiba: ${connection.responseCode}")
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            val trimmed = body.trim()
            if (trimmed.startsWith("[")) org.json.JSONArray(trimmed) else JSONObject(trimmed)
        } finally {
            connection?.disconnect()
        }
    }
}
