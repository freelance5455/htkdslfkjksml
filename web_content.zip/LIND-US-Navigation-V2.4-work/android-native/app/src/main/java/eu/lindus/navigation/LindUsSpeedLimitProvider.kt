package eu.lindus.navigation

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.util.concurrent.Executors
import kotlin.math.*

/**
 * Best-effort OSM maxspeed lookup. The closest tagged road geometry is selected;
 * this remains advisory and is not a legal source of speed limits.
 */
object LindUsSpeedLimitProvider {
    @Volatile var currentLabel: String = "—"
        private set
    @Volatile var currentKmh: Int? = null
        private set
    @Volatile var lastUpdatedAt: Long = 0L
        private set
    @Volatile private var lastLookupAt = 0L
    private val executor = Executors.newSingleThreadExecutor()

    fun updateLocation(latitude: Double, longitude: Double) {
        val now = System.currentTimeMillis()
        if (now - lastLookupAt < 30000L) return
        lastLookupAt = now
        executor.execute {
            try {
                val query = "[out:json][timeout:10];way(around:30,$latitude,$longitude)[highway][maxspeed];out tags geom;"
                val encoded = URLEncoder.encode(query, "UTF-8")
                val connection = URL("https://overpass-api.de/api/interpreter?data=$encoded").openConnection() as HttpURLConnection
                try {
                    connection.connectTimeout = 7000
                    connection.readTimeout = 11000
                    connection.setRequestProperty("User-Agent", "LIND-US-Navigation/2.0 (Android prototype)")
                    val body = connection.inputStream.bufferedReader().use { it.readText() }
                    val elements = JSONObject(body).optJSONArray("elements")
                    var selected: String? = null
                    var closest = Double.MAX_VALUE
                    if (elements != null) {
                        for (i in 0 until elements.length()) {
                            val element = elements.getJSONObject(i)
                            val tags = element.optJSONObject("tags") ?: continue
                            val raw = tags.optString("maxspeed", "").trim()
                            if (raw.isBlank()) continue
                            val geometry = element.optJSONArray("geometry") ?: continue
                            var wayDistance = Double.MAX_VALUE
                            for (j in 0 until geometry.length()) {
                                val point = geometry.getJSONObject(j)
                                val d = distanceMeters(latitude, longitude, point.optDouble("lat"), point.optDouble("lon"))
                                if (d < wayDistance) wayDistance = d
                            }
                            if (wayDistance < closest) {
                                closest = wayDistance
                                selected = raw
                            }
                        }
                    }
                    // Reject a tagged way if its geometry is not close enough to the current GPS fix.
                    val parsed = if (closest <= 30.0) parseKmh(selected) else null
                    currentKmh = parsed
                    currentLabel = parsed?.let { "$it km/h" } ?: "Nincs adat"
                    lastUpdatedAt = System.currentTimeMillis()
                    LindUsRouteState.notifyExternalChange()
                } finally {
                    connection.disconnect()
                }
            } catch (_: Exception) {
                currentLabel = "Nem elérhető"
                currentKmh = null
                lastUpdatedAt = System.currentTimeMillis()
                LindUsRouteState.notifyExternalChange()
            }
        }
    }

    private fun parseKmh(raw: String?): Int? {
        if (raw == null) return null
        val value = raw.lowercase().replace(",", ".")
        val number = Regex("\\d+(?:\\.\\d+)?").find(value)?.value?.toDoubleOrNull() ?: return null
        return if (value.contains("mph")) (number * 1.60934).roundToInt() else number.toInt()
    }

    private fun distanceMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val earth = 6371000.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2).pow(2.0) + cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2).pow(2.0)
        return earth * 2.0 * atan2(sqrt(a), sqrt(1.0 - a))
    }
}
