package eu.lindus.navigation.car

import android.graphics.Paint
import android.view.View
import android.view.TextureView
import android.widget.FrameLayout
import androidx.car.app.CarContext
import eu.lindus.navigation.LindUsRouteState
import eu.lindus.navigation.LindUsLocationState
import org.maplibre.android.MapLibre
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapLibreMapOptions
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style
import org.maplibre.android.style.layers.CircleLayer
import org.maplibre.android.style.layers.LineLayer
import org.maplibre.android.style.layers.PropertyFactory.circleColor
import org.maplibre.android.style.layers.PropertyFactory.circleRadius
import org.maplibre.android.style.layers.PropertyFactory.lineCap
import org.maplibre.android.style.layers.PropertyFactory.lineColor
import org.maplibre.android.style.layers.PropertyFactory.lineJoin
import org.maplibre.android.style.layers.PropertyFactory.lineWidth
import org.maplibre.android.style.sources.GeoJsonSource
import org.maplibre.geojson.Feature
import org.maplibre.geojson.FeatureCollection
import org.maplibre.geojson.LineString
import org.maplibre.geojson.Point

/**
 * MapLibre Native map engine for the Android Auto renderer migration.
 * The host must attach this MapView to a rendering window before its TextureView
 * can be captured and copied to Android Auto's Surface.
 */
class LindUsMapLibreNativeAdapter(private val carContext: CarContext) {
    var mapView: MapView? = null
        private set
    var map: MapLibreMap? = null
        private set
    var textureView: TextureView? = null
        private set
    var ready: Boolean = false
        private set

    private var routeSource: GeoJsonSource? = null
    private var vehicleSource: GeoJsonSource? = null
    private val routeListener: () -> Unit = { refreshRoute() }
    private val locationListener: () -> Unit = {
        val position = LindUsLocationState.current
        if (position != null) {
            mapView?.post { updateCamera(position.latitude, position.longitude, position.bearingDegrees) }
        }
    }

    fun create(onReady: () -> Unit = {}) {
        if (mapView != null) return
        MapLibre.getInstance(carContext)
        LindUsRouteState.addListener(routeListener)
        LindUsLocationState.addListener(locationListener)
        val options = MapLibreMapOptions.createFromAttributes(carContext).textureMode(true)
        val view = MapView(carContext, options).apply {
            setLayerType(View.LAYER_TYPE_HARDWARE, Paint())
            onCreate(null)
            onStart()
            onResume()
        }
        mapView = view
        view.getMapAsync { nativeMap ->
            map = nativeMap
            nativeMap.setStyle(Style.Builder().fromUri("https://tiles.openfreemap.org/styles/positron")) { style ->
                routeSource = GeoJsonSource(ROUTE_SOURCE, FeatureCollection.fromFeatures(arrayOf()))
                vehicleSource = GeoJsonSource(VEHICLE_SOURCE, FeatureCollection.fromFeatures(arrayOf()))
                style.addSource(routeSource!!)
                style.addSource(vehicleSource!!)
                style.addLayer(LineLayer(ROUTE_CASING, ROUTE_SOURCE).withProperties(
                    lineColor("#FFFFFF"), lineWidth(10f), lineCap("round"), lineJoin("round")
                ))
                style.addLayer(LineLayer(ROUTE_LAYER, ROUTE_SOURCE).withProperties(
                    lineColor("#8756D6"), lineWidth(6f), lineCap("round"), lineJoin("round")
                ))
                style.addLayer(CircleLayer(VEHICLE_LAYER, VEHICLE_SOURCE).withProperties(
                    circleColor("#20C7C7"), circleRadius(8f)
                ))
                nativeMap.cameraPosition = CameraPosition.Builder()
                    .target(LatLng(48.1372, 11.5756)).zoom(14.5).tilt(58.0).bearing(0.0).build()
                textureView = findTextureView(view)
                ready = true
                refreshRoute()
                onReady()
            }
        }
    }

    fun resize(width: Int, height: Int) {
        if (width <= 0 || height <= 0) return
        mapView?.layoutParams = FrameLayout.LayoutParams(width, height)
        mapView?.requestLayout()
    }

    fun updateCamera(latitude: Double, longitude: Double, bearing: Double? = null) {
        val current = map ?: return
        current.cameraPosition = CameraPosition.Builder()
            .target(LatLng(latitude, longitude)).zoom(16.0).tilt(58.0)
            .bearing(bearing ?: 0.0).build()
        vehicleSource?.setGeoJson(Feature.fromGeometry(Point.fromLngLat(longitude, latitude)))
        refreshRoute()
    }

    /** Updates the native vector route overlay from the shared OSRM route state. */
    fun refreshRoute() {
        val points = LindUsRouteState.current?.points.orEmpty()
        val coordinates = points.map { Point.fromLngLat(it.second, it.first) }
        val collection = if (coordinates.size >= 2) {
            FeatureCollection.fromFeatures(arrayOf(Feature.fromGeometry(LineString.fromLngLats(coordinates))))
        } else FeatureCollection.fromFeatures(arrayOf())
        routeSource?.setGeoJson(collection)
    }

    fun captureTextureBitmap() = textureView?.bitmap

    fun destroy() {
        LindUsRouteState.removeListener(routeListener)
        LindUsLocationState.removeListener(locationListener)
        ready = false
        textureView = null
        routeSource = null
        vehicleSource = null
        map = null
        mapView?.run {
            onPause()
            onStop()
            onDestroy()
        }
        mapView = null
    }

    private fun findTextureView(view: View): TextureView? {
        if (view is TextureView) return view
        if (view is android.view.ViewGroup) {
            for (index in 0 until view.childCount) {
                findTextureView(view.getChildAt(index))?.let { return it }
            }
        }
        return null
    }

    companion object {
        private const val ROUTE_SOURCE = "lindus-route-source"
        private const val ROUTE_CASING = "lindus-route-casing"
        private const val ROUTE_LAYER = "lindus-route-line"
        private const val VEHICLE_SOURCE = "lindus-vehicle-source"
        private const val VEHICLE_LAYER = "lindus-vehicle-marker"
    }
}
