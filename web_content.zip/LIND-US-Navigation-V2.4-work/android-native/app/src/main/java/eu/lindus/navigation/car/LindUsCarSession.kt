package eu.lindus.navigation.car

import android.content.Intent
import androidx.car.app.Screen
import androidx.car.app.Session

class LindUsCarSession : Session() {
    override fun onCreateScreen(intent: Intent): Screen = LindUsCarScreen(carContext)
}
