package eu.lindus.navigation.car

import android.Manifest
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import androidx.car.app.CarAppService
import androidx.car.app.Session
import androidx.car.app.validation.HostValidator
import androidx.core.content.ContextCompat
import eu.lindus.navigation.LindUsLocationState

class LindUsCarAppService : CarAppService(), LocationListener {
    private var locationManager: LocationManager? = null

    override fun onCreate() {
        super.onCreate()
        startLocationUpdates()
    }

    private fun startLocationUpdates() {
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine && !coarse) return

        try {
            locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
            val providers = locationManager?.getProviders(true).orEmpty()
            for (provider in providers) {
                try {
                    locationManager?.requestLocationUpdates(provider, 2000L, 5f, this)
                    locationManager?.getLastKnownLocation(provider)?.let { onLocationChanged(it) }
                } catch (_: SecurityException) { }
            }
        } catch (_: Exception) { }
    }

    override fun onLocationChanged(location: Location) {
        LindUsLocationState.update(
            location.latitude,
            location.longitude,
            if (location.hasBearing()) location.bearing else null,
            if (location.hasSpeed()) location.speed else null,
            if (location.hasAccuracy()) location.accuracy else null
        )
    }

    @Deprecated("Deprecated in Android API")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}

    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}

    override fun onDestroy() {
        try { locationManager?.removeUpdates(this) } catch (_: Exception) { }
        locationManager = null
        super.onDestroy()
    }

    override fun createHostValidator(): HostValidator = HostValidator.ALLOW_ALL_HOSTS_VALIDATOR
    override fun onCreateSession(): Session = LindUsCarSession()
}
