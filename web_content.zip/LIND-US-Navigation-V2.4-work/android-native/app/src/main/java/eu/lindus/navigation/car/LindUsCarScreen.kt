package eu.lindus.navigation.car

import androidx.car.app.CarContext
import androidx.car.app.Screen
import androidx.car.app.model.Action
import androidx.car.app.model.ActionStrip
import androidx.car.app.model.MapWithContentTemplate
import androidx.car.app.model.MessageTemplate
import androidx.car.app.model.Template
import eu.lindus.navigation.LindUsLocationState
import eu.lindus.navigation.LindUsRouteState
import eu.lindus.navigation.LindUsSpeedLimitProvider
import eu.lindus.navigation.LindUsVoiceGuidance

class LindUsCarScreen(carContext: CarContext) : Screen(carContext) {
    private val mapSurface = LindUsMapSurface()
    private val voice = LindUsVoiceGuidance(carContext)
    private val stateListener: () -> Unit = {
        voice.update()
        invalidate()
    }

    init {
        carContext.getCarService(androidx.car.app.AppManager::class.java).setSurfaceCallback(mapSurface)
        LindUsRouteState.addListener(stateListener)
        LindUsLocationState.addListener(stateListener)
    }

    override fun onGetTemplate(): Template {
        val route = LindUsRouteState.current
        val builder = MapWithContentTemplate.Builder()
        if (route == null) {
            val action = Action.Builder()
                .setTitle("Bezárás")
                .setOnClickListener { screenManager.pop() }
                .build()
            return builder
                .setContentTemplate(MessageTemplate.Builder(LindUsRouteState.status).setTitle("LIND-US Navigation").build())
                .setActionStrip(ActionStrip.Builder().addAction(action).build())
                .build()
        }

        val position = LindUsLocationState.current
        val next = LindUsRouteState.nextManeuver(route, position?.latitude, position?.longitude)
        val progress = LindUsRouteState.progress
        val active = LindUsRouteState.navigationActive
        val km = route.distanceMeters / 1000.0
        val mins = (route.durationSeconds / 60.0).toInt()
        val nextText = next?.let { (maneuver, distance) ->
            val distanceText = when {
                distance >= 1000 -> String.format("%.1f km", distance / 1000.0)
                distance >= 100 -> "${(distance / 10).toInt() * 10} m"
                else -> "${distance.toInt()} m"
            }
            "${maneuver.instruction}\n$distanceText múlva"
        } ?: "Fordulóadatok betöltése…"
        val remainingKm = progress?.remainingDistanceMeters?.div(1000.0)
        val remainingText = remainingKm?.let { "Hátralévő: ${"%.1f".format(it)} km" } ?: "Hátralévő: GPS-adat szükséges"
        val speedText = "Sebességhatár: ${LindUsSpeedLimitProvider.currentLabel}"
        val speedAge = if (LindUsSpeedLimitProvider.lastUpdatedAt > 0L) {
            val seconds = ((System.currentTimeMillis() - LindUsSpeedLimitProvider.lastUpdatedAt) / 1000L).coerceAtLeast(0)
            "Adatfrissítés: ${seconds} mp"
        } else "Sebességhatár-adat keresése…"
        val stateText = when {
            progress?.offRoute == true -> "Letérés észlelve – újratervezés…"
            active -> "Navigáció aktív · hangutasítás bekapcsolva"
            else -> "Útvonal készen áll"
        }
        val message = "Cél: ${route.destinationName}\n${"%.1f".format(km)} km · ${mins / 60} ó ${mins % 60} perc\n\nKÖVETKEZŐ MANŐVER\n$nextText\n\n$remainingText\n$speedText\n$speedAge\n$stateText"
        val action = if (active) {
            Action.Builder().setTitle("Leállítás").setOnClickListener { LindUsRouteState.stopNavigation() }.build()
        } else {
            Action.Builder().setTitle("Indítás").setOnClickListener { LindUsRouteState.startNavigation() }.build()
        }
        val clearAction = Action.Builder()
            .setTitle("Útvonal törlése")
            .setOnClickListener { LindUsRouteState.clear() }
            .build()
        val stripBuilder = ActionStrip.Builder().addAction(action).addAction(clearAction)

        return builder
            .setContentTemplate(MessageTemplate.Builder(message).setTitle("LIND-US Navigation").build())
            .setActionStrip(stripBuilder.build())
            .build()
    }

    override fun onDestroy() {
        LindUsRouteState.removeListener(stateListener)
        LindUsLocationState.removeListener(stateListener)
        voice.shutdown()
        super.onDestroy()
    }
}
