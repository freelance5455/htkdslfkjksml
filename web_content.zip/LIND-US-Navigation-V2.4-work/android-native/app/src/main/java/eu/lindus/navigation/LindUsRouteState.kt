package eu.lindus.navigation

import java.util.concurrent.CopyOnWriteArraySet
import kotlin.math.*

object LindUsRouteState {
    data class Maneuver(
        val instruction: String,
        val roadName: String,
        val distanceMeters: Double,
        val latitude: Double,
        val longitude: Double
    )
    data class Route(
        val destinationName: String,
        val points: List<Pair<Double, Double>>,
        val distanceMeters: Double,
        val durationSeconds: Double,
        val maneuvers: List<Maneuver> = emptyList(),
        val destinationLatitude: Double = points.lastOrNull()?.first ?: 0.0,
        val destinationLongitude: Double = points.lastOrNull()?.second ?: 0.0
    )
    data class Progress(val distanceFromRouteMeters: Double, val remainingDistanceMeters: Double, val offRoute: Boolean)

    @Volatile var current: Route? = null
        private set
    @Volatile var status: String = "Adj meg úti célt a telefonon."
        private set
    @Volatile var progress: Progress? = null
        private set
    @Volatile var navigationActive: Boolean = false
        private set
    @Volatile private var nearestRoutePointIndex: Int = 0
    private val listeners = CopyOnWriteArraySet<() -> Unit>()
    private var offRouteSamples = 0

    fun setStatus(value: String) { status = value; notifyChanged() }
    fun setRoute(route: Route) {
        current = route
        progress = null
        nearestRoutePointIndex = 0
        offRouteSamples = 0
        navigationActive = false
        status = route.destinationName
        notifyChanged()
    }
    fun startNavigation() {
        if (current == null) return
        navigationActive = true
        status = "Navigáció aktív"
        notifyChanged()
    }
    fun stopNavigation() {
        navigationActive = false
        status = "Navigáció leállítva."
        notifyChanged()
    }
    fun clear() {
        current = null
        progress = null
        navigationActive = false
        nearestRoutePointIndex = 0
        offRouteSamples = 0
        status = "Útvonal nem található."
        notifyChanged()
    }

    fun updateProgress(latitude: Double, longitude: Double): Progress? {
        val route = current ?: return null
        if (route.points.isEmpty()) return null
        var nearestIndex = nearestRoutePointIndex.coerceIn(0, route.points.lastIndex)
        var nearestDistance = Double.MAX_VALUE
        // Search locally ahead and slightly behind to prevent jumping to a distant parallel road.
        val from = (nearestRoutePointIndex - 12).coerceAtLeast(0)
        val to = (nearestRoutePointIndex + 180).coerceAtMost(route.points.lastIndex)
        for (i in from..to) {
            val p = route.points[i]
            val d = distanceMeters(latitude, longitude, p.first, p.second)
            if (d < nearestDistance) { nearestDistance = d; nearestIndex = i }
        }
        if (nearestDistance < 100.0) nearestRoutePointIndex = max(nearestRoutePointIndex, nearestIndex)
        var remaining = 0.0
        for (i in nearestRoutePointIndex until route.points.lastIndex) {
            val a = route.points[i]; val b = route.points[i + 1]
            remaining += distanceMeters(a.first, a.second, b.first, b.second)
        }
        val isOffRoute = nearestDistance > 75.0
        offRouteSamples = if (isOffRoute) (offRouteSamples + 1).coerceAtMost(5) else 0
        val result = Progress(nearestDistance, remaining, offRouteSamples >= 3)
        progress = result
        return result
    }

    /** Returns the first not-yet-passed maneuver and distance measured along route geometry. */
    fun nextManeuver(route: Route, latitude: Double?, longitude: Double?): Pair<Maneuver, Double>? {
        if (route.maneuvers.isEmpty() || route.points.isEmpty()) return null
        if (latitude == null || longitude == null) return route.maneuvers.first().let { it to it.distanceMeters }
        val currentIndex = nearestRoutePointIndex
        for (maneuver in route.maneuvers) {
            val maneuverIndex = nearestPointIndex(route.points, maneuver.latitude, maneuver.longitude)
            if (maneuverIndex < currentIndex) continue
            var distance = 0.0
            for (i in currentIndex until maneuverIndex) {
                val a = route.points[i]; val b = route.points[i + 1]
                distance += distanceMeters(a.first, a.second, b.first, b.second)
            }
            if (distance > 18.0 || maneuver.instruction.contains("Megérkeztél")) return maneuver to distance
        }
        val last = route.maneuvers.last()
        return last to distanceMeters(latitude, longitude, last.latitude, last.longitude)
    }

    private fun nearestPointIndex(points: List<Pair<Double, Double>>, lat: Double, lon: Double): Int {
        var best = 0; var bestDistance = Double.MAX_VALUE
        for (i in points.indices) {
            val p = points[i]
            val d = distanceMeters(lat, lon, p.first, p.second)
            if (d < bestDistance) { bestDistance = d; best = i }
        }
        return best
    }
    fun distanceMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val earth = 6371000.0
        val dLat = Math.toRadians(lat2 - lat1); val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2).pow(2.0) + cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2).pow(2.0)
        return earth * 2.0 * atan2(sqrt(a), sqrt(1.0 - a))
    }
    fun addListener(listener: () -> Unit) { listeners.add(listener) }
    fun removeListener(listener: () -> Unit) { listeners.remove(listener) }
    fun notifyExternalChange() { listeners.forEach { try { it() } catch (_: Exception) {} } }
    private fun notifyChanged() = notifyExternalChange()
}
