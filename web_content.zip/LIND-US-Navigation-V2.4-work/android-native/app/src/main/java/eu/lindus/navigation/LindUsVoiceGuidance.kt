package eu.lindus.navigation

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

/**
 * Hungarian spoken maneuver prompts. Prompts are emitted once at 500m, 150m and
 * near the maneuver; the class is runtime-only and never stores location data.
 */
class LindUsVoiceGuidance(context: Context) : TextToSpeech.OnInitListener {
    private val tts = TextToSpeech(context.applicationContext, this)
    @Volatile private var ready = false
    private var lastManeuverKey = ""
    private var announcedStage = 0

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale("hu", "HU"))
            ready = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
        }
    }

    fun update() {
        if (!ready || !LindUsRouteState.navigationActive) return
        val route = LindUsRouteState.current ?: return
        val position = LindUsLocationState.current ?: return
        val next = LindUsRouteState.nextManeuver(route, position.latitude, position.longitude) ?: return
        val maneuver = next.first
        val distance = next.second
        val key = "${maneuver.latitude}:${maneuver.longitude}:${maneuver.instruction}"
        if (key != lastManeuverKey) {
            lastManeuverKey = key
            announcedStage = 0
        }
        val stage = when {
            distance <= 45.0 -> 3
            distance <= 160.0 -> 2
            distance <= 520.0 -> 1
            else -> 0
        }
        if (stage <= announcedStage || stage == 0) return
        announcedStage = stage
        val speech = when (stage) {
            1 -> "Ötszáz méter múlva. ${maneuver.instruction}."
            2 -> "Százötven méter múlva. ${maneuver.instruction}."
            else -> if (maneuver.instruction.contains("Megérkeztél")) {
                "Megérkeztél az úti célodhoz."
            } else {
                "Most. ${maneuver.instruction}."
            }
        }
        tts.speak(speech, TextToSpeech.QUEUE_FLUSH, null, "lindus-$key-$stage")
    }

    fun shutdown() {
        ready = false
        tts.stop()
        tts.shutdown()
    }
}
