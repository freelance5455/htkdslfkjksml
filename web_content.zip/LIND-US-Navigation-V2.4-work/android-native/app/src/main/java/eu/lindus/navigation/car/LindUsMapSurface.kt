package eu.lindus.navigation.car

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.view.Surface
import androidx.car.app.SurfaceCallback
import androidx.car.app.SurfaceContainer
import eu.lindus.navigation.LindUsLocationState
import eu.lindus.navigation.LindUsRouteState
import eu.lindus.navigation.LindUsSpeedLimitProvider
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import kotlin.math.floor
import kotlin.math.pow
import kotlin.math.max

/** OSM raster map preview on the Android Auto host Surface.
 * The native OSRM route geometry is drawn over the OSM raster map.
 */
class LindUsMapSurface : SurfaceCallback {
    @Volatile private var surface: Surface? = null
    @Volatile private var width = 0
    @Volatile private var height = 0
    @Volatile private var generation = 0
    private val worker = Executors.newSingleThreadExecutor()
    private val zoom = 14
    private val cache = object : android.util.LruCache<String, Bitmap>(36) {}

    override fun onSurfaceAvailable(surfaceContainer: SurfaceContainer) {
        surface = surfaceContainer.surface
        width = surfaceContainer.width
        height = surfaceContainer.height
        generation++
        LindUsLocationState.addListener(locationListener)
        LindUsRouteState.addListener(routeListener)
        render(generation)
    }

    override fun onSurfaceDestroyed(surfaceContainer: SurfaceContainer) {
        generation++
        LindUsLocationState.removeListener(locationListener)
        LindUsRouteState.removeListener(routeListener)
        val old = surface
        surface = null
        try { old?.release() } catch (_: Exception) {}
    }

    private val routeListener: () -> Unit = { generation++; render(generation) }

    private val locationListener: () -> Unit = {
        generation++
        render(generation)
    }

    private fun render(id: Int) {
        val w = width
        val h = height
        if (w <= 0 || h <= 0) return
        worker.execute {
            val n = 2.0.pow(zoom.toDouble())
            val position = LindUsLocationState.current
            // If permission has not yet produced a fix, show Munich as a neutral fallback.
            val centerLat = position?.latitude ?: 48.1372
            val centerLon = position?.longitude ?: 11.5756
            val lat = Math.toRadians(centerLat.coerceIn(-85.0, 85.0))
            val cx = (centerLon + 180.0) / 360.0 * n * 256.0
            val cy = (1.0 - kotlin.math.ln(kotlin.math.tan(lat) + 1.0 / kotlin.math.cos(lat)) / Math.PI) / 2.0 * n * 256.0
            val left = cx - w / 2.0
            val top = cy - h / 2.0
            val minX = floor(left / 256.0).toInt()
            val minY = floor(top / 256.0).toInt()
            val maxX = floor((left + w) / 256.0).toInt()
            val maxY = floor((top + h) / 256.0).toInt()
            val tiles = mutableListOf<Triple<Bitmap, Float, Float>>()
            for (ty in minY..maxY) for (tx in minX..maxX) {
                if (id != generation) return@execute
                val key = "$zoom/$tx/$ty"
                val bmp = cache.get(key) ?: fetchTile(zoom, tx, ty)?.also { cache.put(key, it) }
                if (bmp != null) tiles.add(Triple(bmp, (tx * 256.0 - left).toFloat(), (ty * 256.0 - top).toFloat()))
            }
            if (id == generation) draw(tiles, w, h)
        }
    }

    private fun fetchTile(z: Int, x: Int, y: Int): Bitmap? {
        val count = 2.0.pow(z.toDouble()).toInt()
        if (y !in 0 until count) return null
        val wrappedX = ((x % count) + count) % count
        var conn: HttpURLConnection? = null
        return try {
            conn = URL("https://tile.openstreetmap.org/$z/$wrappedX/$y.png").openConnection() as HttpURLConnection
            conn.connectTimeout = 5000
            conn.readTimeout = 7000
            conn.setRequestProperty("User-Agent", "LIND-US-Navigation/2.2 (Android Auto prototype)")
            conn.setRequestProperty("Accept", "image/png")
            conn.connect()
            if (conn.responseCode == 200) conn.inputStream.use { BitmapFactory.decodeStream(it) } else null
        } catch (_: Exception) { null } finally { conn?.disconnect() }
    }

    private fun carContextDensity(): Float = 1f

    private fun draw(tiles: List<Triple<Bitmap, Float, Float>>, w: Int, h: Int) {
        val target = surface ?: return
        var canvas: Canvas? = null
        try {
            canvas = target.lockCanvas(null)
            canvas.drawColor(Color.rgb(244, 242, 248))
            val position = LindUsLocationState.current
            val bearing = position?.bearingDegrees
            val mapSave = canvas.save()
            if (bearing != null) canvas.rotate(-bearing, w / 2f, h / 2f)
            val dst = Rect()
            for ((bmp, x, y) in tiles) {
                dst.set(x.toInt(), y.toInt(), x.toInt() + bmp.width, y.toInt() + bmp.height)
                canvas.drawBitmap(bmp, null, dst, null)
            }
            // Project route geometry into the current Web Mercator tile pixel space.
            val activeRoute = LindUsRouteState.current
            if (activeRoute != null && activeRoute.points.isNotEmpty()) {
                val routeCasing = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.WHITE
                    style = Paint.Style.STROKE
                    strokeWidth = 19f
                    strokeCap = Paint.Cap.ROUND
                    strokeJoin = Paint.Join.ROUND
                }
                val routePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.rgb(125, 75, 205)
                    style = Paint.Style.STROKE
                    strokeWidth = 12f
                    strokeCap = Paint.Cap.ROUND
                    strokeJoin = Paint.Join.ROUND
                }
                val nRoute = 2.0.pow(zoom.toDouble())
                val path = android.graphics.Path()
                activeRoute.points.forEachIndexed { index, point ->
                    val latRad = Math.toRadians(point.first.coerceIn(-85.0, 85.0))
                    val px = (point.second + 180.0) / 360.0 * nRoute * 256.0
                    val py = (1.0 - kotlin.math.ln(kotlin.math.tan(latRad) + 1.0 / kotlin.math.cos(latRad)) / Math.PI) / 2.0 * nRoute * 256.0
                    val current = LindUsLocationState.current
                    val centerLat = current?.latitude ?: 48.1372
                    val centerLon = current?.longitude ?: 11.5756
                    val centerRad = Math.toRadians(centerLat.coerceIn(-85.0, 85.0))
                    val centerPx = (centerLon + 180.0) / 360.0 * nRoute * 256.0
                    val centerPy = (1.0 - kotlin.math.ln(kotlin.math.tan(centerRad) + 1.0 / kotlin.math.cos(centerRad)) / Math.PI) / 2.0 * nRoute * 256.0
                    val sx = (px - centerPx).toFloat() + w / 2f
                    val sy = (py - centerPy).toFloat() + h / 2f
                    if (index == 0) path.moveTo(sx, sy) else path.lineTo(sx, sy)
                }
                canvas.drawPath(path, routeCasing)
                canvas.drawPath(path, routePaint)
            }

            canvas.restoreToCount(mapSave)

            // Heading-up vehicle marker: arrow points to the top of the display.
            val markerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(137, 86, 214)
                style = Paint.Style.FILL
                setShadowLayer(8f, 0f, 0f, Color.BLACK)
            }
            val markerPath = android.graphics.Path().apply {
                moveTo(w / 2f, h / 2f - 22f)
                lineTo(w / 2f - 13f, h / 2f + 15f)
                lineTo(w / 2f, h / 2f + 8f)
                lineTo(w / 2f + 13f, h / 2f + 15f)
                close()
            }
            canvas.drawPath(markerPath, markerPaint)
            val attribution = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.DKGRAY; textSize = 19f; setShadowLayer(2f,1f,1f,Color.WHITE)
            }
            canvas.drawText("© OpenStreetMap contributors", 12f, h-14f, attribution)

            // Automotive navigation HUD: dark maneuver card, ETA strip and speed-limit badge.
            val density = carContextDensity()
            val margin = 18f * density
            val panel = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.argb(242, 18, 17, 23)
                style = Paint.Style.FILL
            }
            val panelStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.argb(90, 255, 255, 255)
                style = Paint.Style.STROKE
                strokeWidth = 1f * density
            }
            val primaryText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = 17f * density
                typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            }
            val secondaryText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(218, 214, 225)
                textSize = 12f * density
            }
            val smallText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(190, 181, 204)
                textSize = 10f * density
            }
            val route = LindUsRouteState.current
            val next = route?.let { LindUsRouteState.nextManeuver(it, position?.latitude, position?.longitude) }
            val cardWidth = minOf(w * 0.43f, 330f * density)
            val cardHeight = 104f * density
            val card = RectF(margin, margin, margin + cardWidth, margin + cardHeight)
            canvas.drawRoundRect(card, 15f * density, 15f * density, panel)
            canvas.drawRoundRect(card, 15f * density, 15f * density, panelStroke)
            canvas.drawText("KÖVETKEZŐ MANŐVER", card.left + 13f * density, card.top + 20f * density, smallText)
            val instruction = next?.first?.instruction ?: if (route == null) "Útvonaltervezés" else "Haladj tovább"
            val instructionShort = if (instruction.length > 30) instruction.take(27) + "…" else instruction
            canvas.drawText(instructionShort, card.left + 13f * density, card.top + 48f * density, primaryText)
            val distance = next?.second
            val distanceLabel = distance?.let {
                if (it >= 1000) String.format("%.1f km múlva", it / 1000.0) else "${it.toInt()} m múlva"
            } ?: "—"
            canvas.drawText(distanceLabel, card.left + 13f * density, card.top + 75f * density, secondaryText)

            val bottomWidth = minOf(w * 0.48f, 355f * density)
            val bottomHeight = 58f * density
            val bottom = RectF(margin, h - margin - bottomHeight, margin + bottomWidth, h - margin)
            canvas.drawRoundRect(bottom, 16f * density, 16f * density, panel)
            canvas.drawRoundRect(bottom, 16f * density, 16f * density, panelStroke)
            val remaining = LindUsRouteState.progress?.remainingDistanceMeters
                ?: route?.distanceMeters
            val remainingKm = remaining?.div(1000.0)
            val remainingLabel = remainingKm?.let { String.format("%.1f km", it) } ?: "— km"
            val speed = position?.speedMetersPerSecond?.let { (it * 3.6f).toInt() }
            val speedLabel = speed?.let { "$it km/h" } ?: "— km/h"
            val remainingDurationMin = if (route != null && remaining != null && route.distanceMeters > 0.0) {
                (route.durationSeconds * (remaining / route.distanceMeters)).toInt()
            } else route?.durationSeconds?.div(60.0)?.toInt()
            val eta = remainingDurationMin?.let {
                val cal = java.util.Calendar.getInstance()
                cal.add(java.util.Calendar.MINUTE, it)
                String.format("%02d:%02d", cal.get(java.util.Calendar.HOUR_OF_DAY), cal.get(java.util.Calendar.MINUTE))
            } ?: "--:--"
            canvas.drawText(eta, bottom.left + 15f * density, bottom.top + 25f * density, primaryText)
            canvas.drawText("ÉRKEZÉS", bottom.left + 15f * density, bottom.top + 43f * density, smallText)
            canvas.drawText(remainingLabel, bottom.left + 110f * density, bottom.top + 25f * density, primaryText)
            canvas.drawText("HÁTRALÉVŐ TÁV", bottom.left + 110f * density, bottom.top + 43f * density, smallText)
            canvas.drawText(speedLabel, bottom.left + bottomWidth - 92f * density, bottom.top + 25f * density, primaryText)

            val limitValue = LindUsSpeedLimitProvider.currentKmh
            val badgeRadius = 25f * density
            val badgeCx = w - margin - badgeRadius
            val badgeCy = margin + badgeRadius
            val badgeFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.FILL }
            val badgeRing = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(205, 54, 58); style = Paint.Style.STROKE; strokeWidth = 4f * density
            }
            canvas.drawCircle(badgeCx, badgeCy, badgeRadius, badgeFill)
            canvas.drawCircle(badgeCx, badgeCy, badgeRadius - 1f * density, badgeRing)
            val limitPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(25, 24, 29); textAlign = Paint.Align.CENTER
                textSize = if (limitValue == null) 12f * density else 19f * density
                typeface = android.graphics.Typeface.create("sans-serif-bold", android.graphics.Typeface.NORMAL)
            }
            canvas.drawText(limitValue?.toString() ?: "—", badgeCx, badgeCy + 6f * density, limitPaint)
            val kmhPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.DKGRAY; textAlign = Paint.Align.CENTER; textSize = 7f * density
            }
            canvas.drawText("km/h", badgeCx, badgeCy + 16f * density, kmhPaint)
            canvas.drawText("Sebesség: $speedLabel", w - margin - 95f * density, h - margin, secondaryText)

        } catch (_: Exception) {
        } finally {
            if (canvas != null) try { target.unlockCanvasAndPost(canvas) } catch (_: Exception) {}
        }
    }
}
