# LIND-US Native Android / Android Auto – V2.0

## V2.0 – első natív útvonalátadás
- A telefonos Activity fogad `geo:` és `google.navigation:` célátadási intenteket.
- A natív útvonaltervező Nominatim segítségével feloldja a cél nevét/címét.
- A kiindulási pontot az aktuális telefonos helyadatból veszi.
- OSRM autós útvonalat kér, és a GeoJSON útvonalpontokat közös memóriás RouteState-ben tárolja.
- Az Android Auto Surface a route geometriát türkiz vonallal rárajzolja az OSM térképre.
- Az autós tartalmi panel megjeleníti a célt, távolságot és becsült menetidőt.

## Korlátok / fontos
- Ez egy kezdeti intent-alapú natív útvonalátadás, nem teljes telefonos útvonaltervező UI.
- Az Android Auto szolgáltatás és a telefonos Activity folyamat-/életciklus-megosztása nincs még teljes körűen megoldva; tesztelni kell, hogy a route state átadása autócsatlakozás közben megbízható-e.
- A route polyline jelenleg egyszerű Web Mercator vetítéssel jelenik meg; heading-up forgatás és útvonal-vetítés még nem teljesen összehangolt, ezért ez fejlesztői prototípus.
- Nincs manőverlista, hangutasítás, off-route detektálás vagy automatikus újratervezés a natív rétegben.
- Nominatim és OSRM nyilvános szolgáltatások: használati szabályaikat be kell tartani.
- ZIP forráscsomag; Android Studio/Gradle build és Android Auto DHU teszt nem történt.


## V2.0 – következő manőver és térkép-illesztés

- Az OSRM `steps=true` válaszából a natív útvonaltervező feldolgozza az első útvonal-láb manővereit.
- Az Android Auto térképes tartalmi paneljén megjelenik a következő manőver magyar szövege és a GPS-pozíciótól légvonalban mért becsült távolsága.
- A következő manőver kijelzése GPS-helyzetváltozáskor frissül.
- A cyan útvonalvonal ugyanazt a heading-up forgatást kapja, mint az OSM térképcsempék, így a két réteg együtt mozog.

Fontos korlátok:
- Ez még nem teljes, hitelesített turn-by-turn navigáció: a manőver-távolság egyenes vonalú becslés, nem az útvonal mentén számolt távolság.
- A manőver kiválasztása a legközelebbi OSRM manőverpontra épül; összetett csomópontoknál vagy pontatlan GPS-nél tévesen válthat.
- Nincs még automatikus letérésfelismerés, újratervezés, hangutasítás, sávasszisztens vagy NavigationTemplate-alapú aktív navigáció.
- A projekt továbbra sincs Android APK-vá lefordítva vagy valódi Android Auto fejegységen tesztelve. A Kotlin/Gradle kódot builddel ellenőrizni kell.


## V2.0 – GPS útvonalkövetés és letérés utáni újratervezés

- A natív GPS-helyzetfrissítések alapján a rendszer megkeresi az útvonal geometria legközelebbi pontját.
- Becsüli az útvonalról való eltérést és a hátralévő távolságot az útvonal pontjai mentén.
- Ha a GPS legalább három egymást követő, megfelelő pontosságú mintában 75 méternél nagyobb eltérést jelez, automatikus OSRM újratervezést indít.
- Az újratervezés az eredeti úti cél koordinátáit használja, így nem kell újra geokódolni a cél nevét.
- Az ismételt újratervezés ellen 20 másodperces korlátozás és párhuzamos kérés elleni védelem került be.
- Az Android Auto panel megjeleníti a becsült hátralévő útvonal-távolságot.

Korlátok és biztonság:
- A 75 méteres küszöb és a három GPS-minta prototípus-beállítás; városi környezetben a GPS-visszaverődés téves letérést okozhat.
- A hátralévő távolság az útvonal geometriájának legközelebbi pontjától számolt becslés, nem az útvonalon végzett pontos map-matching.
- A GPS frissítés és az újratervezés működése valós eszközön még nincs ellenőrizve.
- Ez nem helyettesít teljes értékű navigációs rendszert; nincs még hitelesített aktív navigációs sablon, útvonalon követett manőver-sorrend, hangutasítás vagy valós idejű forgalmi újratervezés.
- Az Android projekt továbbra sincs APK-vá lefordítva, és Android Auto fejegységen nincs tesztelve.


## V2.0 – manőverkövetés, sebességhatár és navigációvezérlés

A felhasználó által kért 2, 3, 4 és 5. pont:

- A következő manőver kiválasztása az útvonal geometriáján haladó GPS-progressz alapján történik; a távolságot az útvonal pontjai mentén számolja, nem légvonalban.
- A GPS-progressz lokális, előre irányuló keresést használ, és normál haladás közben nem engedi visszafelé ugrani a követett útvonalpontot.
- Kísérleti sebességhatár-kijelzés készült: az Overpass API-ból a közelben található, `maxspeed` címkével rendelkező OSM útszakasz adatait próbálja lekérni, 30 másodperces lekérdezési korláttal.
- Az Android Auto panel külön „KÖVETKEZŐ MANŐVER” részt mutat, alatta a becsült távolsággal, a hátralévő útvonallal és a sebességhatár-adattal.
- Android Auto műveletek: Navigáció indítása, leállítása (az útvonal megmarad), illetve útvonal törlése.

Fontos korlátok:
- Az OSM sebességhatár-adat nem minden úton érhető el, és a környékbeli Overpass találat nem garantáltan a jármű aktuális útszakaszához tartozik. A kijelzés tájékoztató jellegű; mindig a kihelyezett közúti jelzést kell követni.
- A sebességhatár lekérdezése hálózati hozzáférést igényel, és az Overpass szerver terheltségétől függ.
- A manőver-sorrend és távolság OSRM útvonalgeometriából becsült; összetett csomópontoknál a GPS map-matching még pontatlan lehet.
- A Car App ActionStrip és a MapWithContentTemplate futásidejű kompatibilitását még nem ellenőriztük tényleges Android Auto hoston.
- A projekt nincs APK-vá fordítva vagy valódi autós környezetben tesztelve.


## V2.0 – magyar hangnavigáció és pontosított sebességhatár-keresés

- Android TextToSpeech alapú magyar (hu-HU) hangutasítás került be.
- A következő manőverhez 500 m, 150 m és kb. 45 m környékén ad egyszeri figyelmeztetést; új manővernél újraindul a jelzési ciklus.
- A hangutasítás csak akkor aktív, ha a felhasználó elindította a navigációt Android Auto felületen.
- A sebességhatár-lekérdezés már az Overpassból visszakért útszakasz-geometriák alapján a GPS-pozícióhoz legközelebbi, `maxspeed` címkével ellátott útszakaszt választja.
- A sebességhatár-panel jelzi az adatfrissítés óta eltelt időt.
- A natív Android projekt verziószáma 2.0-ra frissült, a Gradle-függőségek sorai javítva lettek.

Korlátok:
- A hangutasítás Android TTS-motor és magyar nyelvi adatcsomag meglétét igényli. Ha a készüléken nincs magyar TTS-hang, a hangos navigáció nem fog megszólalni.
- A manőverek 500/150/45 méteres jelzései a GPS-pozíció és útvonalgeometria becslésein alapulnak; nem gyártói minőségű navigációs map-matching.
- Az OSM sebességhatár-adatok hiányosak lehetnek, a közeli útszakasz kiválasztása párhuzamos utaknál továbbra is tévedhet. A közúti jelzések az irányadók.
- A sebességhatár-kijelzés és hangutasítás működését valós készüléken még tesztelni kell.
- Ebben a környezetben nem állt rendelkezésre Gradle/Android SDK build eszköz, ezért APK nem készült, és a projekt fordítása nem lett ellenőrizve.
