# LIND-US Navigation V2.4

## V2.4 – natív MapLibre Android alap
- Hozzáadva a MapLibre Native Android SDK (`org.maplibre.gl:android-sdk:13.5.4`) Maven Central függőségként.
- Elkészült az izolált `LindUsMapLibreNativeAdapter.kt` kísérleti adapter.
- Az adapter inicializálja a MapLibre MapView-t TextureView módban, betölti az OpenFreeMap Positron stílust, 58°-os döntött kamerát állít be, kezeli a kamera frissítését, és hozzáférést ad a TextureView bitmapjéhez.
- Android verzió: 2.4 (versionCode 24).

## Miért nincs még bekötve az Android Auto Surface-be?
Az Android Auto navigációs alkalmazás nem tetszőleges Android View-t jelenít meg: a host egy külön Surface-t ad. A MapLibre hivatalos Android Auto mintája ezért offscreen TextureView-t használ, majd annak bitmapjét másolja a host Surface-re. A minta ezt a folyamatot kb. 30 fps-sel ismétli, és maga a projekt is jelzi, hogy ez teljesítmény szempontjából nem ideális. A MapLibre dokumentációja szintén figyelmeztet, hogy a TextureView mód jelentős teljesítményveszteséggel járhat.

A V2.4-ben a natív MapLibre térkép létrehozása és kezelése külön adapterbe került, de a WindowManager-es rejtett nézetcsatolás, a képkocka-másolás, az útvonal GeoJSON réteg és a lifecycle összekötése még nincs bekapcsolva. Ezt nem jelöljük késznek addig, amíg Android Auto hoston nincs tesztelve.

## Változatlan funkciók
- A telefonos webes térkép MapLibre GL JS + OpenFreeMap Positron 3D épületmegjelenítéssel működik.
- Az Android Auto Surface jelenlegi aktív megjelenítője továbbra is a V2.3-as raszteres térkép és navigációs HUD.
- Az OSRM útvonal, magyar TTS, GPS, sebességhatár-lekérdezés és manőverpanel korábbi korlátai változatlanok.

## Fontos korlátok
- Ez forráscsomag, nem APK.
- A Gradle/Android SDK fordítás nem futott le ebben a környezetben.
- A MapLibre SDK függőség és az adapter Kotlin API-kompatibilitása fordításkor ellenőrzendő.
- Az Android Auto Surface-re történő tényleges MapLibre rajzolás még nincs bekötve.


## V2.5 – MapLibre Native route layer
The experimental native MapLibre adapter now defines the same automotive route treatment as the phone map: a white route casing, lilac route core, turquoise vehicle marker, 3D-tilted camera, and updates from the shared OSRM route/location state. The currently active Android Auto Surface renderer remains the stable raster implementation. The native MapView is not yet attached to the host WindowManager and its TextureView is not yet copied into the Android Auto Surface; therefore this release does not claim that MapLibre Native is already displayed in the car.
