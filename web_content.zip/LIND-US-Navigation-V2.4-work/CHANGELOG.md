
## V2.3
- Automotive-style Android Auto HUD: next maneuver, ETA, remaining distance, speed and speed-limit badge.
- White route casing with lilac route core.
- Native Android versionCode 23 / versionName 2.3.

## V2.4
- Added MapLibre Native Android SDK dependency.
- Added experimental texture-backed MapLibre adapter for the upcoming Android Auto Surface integration.
- Adapter is not yet wired to the active car Surface; build and host testing remain required.


## V2.5
- Expanded the MapLibre Native adapter with native GeoJSON route overlays (white casing + lilac route) and a turquoise vehicle marker.
- Added camera-follow updates and route refresh from the shared OSRM route state.
- Kept the proven raster Surface renderer active as a fallback: the MapLibre view still needs a host WindowManager attachment and Surface frame-copy integration before it can replace that renderer.
- Native Android versionCode 25 / versionName 2.5.
