# LIND-US – Android Auto előkészítési terv

Ez a dokumentum a V1.0 webes prototípushoz tartozó natív Android/Android Auto migrációs terv. **Ez még nem Android Auto-kompatibilis alkalmazás és nem APK.**

## Miért kell natív Android-réteg?
Az Android Auto navigációs alkalmazásokhoz a Google Android for Cars App Library (`androidx.car.app`) könyvtárát írja elő. A navigációs alkalmazásnak `CarAppService` szolgáltatást, `androidx.car.app.category.NAVIGATION` kategóriát, `androidx.car.app.NAVIGATION_TEMPLATES` jogosultságot és a navigációs sablonokhoz illeszkedő képernyőket kell biztosítania.

## Tervezett architektúra
1. **Android host (Kotlin):** normál telefonos Activity, helyengedélyek, háttérben futó helyfrissítés és értesítések.
2. **Car App Library réteg:** `CarAppService`, `Session`, vezetés közben használható `NavigationTemplate` / `MapWithContentTemplate`.
3. **Navigációs motor:** útvonal, manőver, ETA, GPS és újratervezés közös adatrétege. A webes prototípus jelenlegi JavaScript logikáját fokozatosan natív Kotlin modulba kell átemelni vagy stabil API mögé tenni.
4. **Térképfelület:** autós kijelzőre külön, vezetésbiztos rajzolási felület és a Car App Library által támogatott map surface. A telefonos Leaflet képernyő közvetlen tükrözése nem megfelelő Android Auto-integráció.
5. **Tesztelés:** Android Auto Desktop Head Unit (DHU), majd kompatibilis autóban teszt; Google autós alkalmazásminőségi ellenőrzőlista.

## Fejlesztési sorrend
- A: natív Android projekt és CarAppService alap.
- B: úticél-átadás (`geo:` / NAVIGATE intent), útvonal és manőveradatok átadása.
- C: autós térkép surface, fordulójelzések, ETA és hangutasítás.
- D: Android Auto DHU tesztelés és minőségi követelmények.
- E: kiadásra előkészítés és Google Play autós alkalmazás-felülvizsgálat.

## V1.0 állapot
- A webes prototípus útvonal-alternatíváit távolság, menetidő, energia/üzemanyag-igény és – ha ismert az ár – becsült költség szerint hasonlítja össze.
- Az elektromos autókhoz jelenleg kWh-becslés látható, de nincs eurós költség, mert külön áramtarifa mező még nincs.
- Az alternatív útvonalak az OSRM szolgáltatás válaszától függenek; a költségbecslés nem tartalmaz útdíjat és forgalmi késést.
