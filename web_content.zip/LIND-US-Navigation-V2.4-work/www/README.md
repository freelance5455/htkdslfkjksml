# LIND-US Navigation V2.2 – Web map

A phone web prototype now uses MapLibre GL JS with the OpenFreeMap Positron light style, a tilted 3D camera and extruded building footprints from OpenFreeMap vector tiles. The route is rendered as a lilac line with a white casing.

Map data attribution remains visible in the map controls. OpenFreeMap is a third-party tile service; availability and terms may change.

The native Android Auto Surface is not yet using the MapLibre 3D renderer. That integration is a separate next step.
