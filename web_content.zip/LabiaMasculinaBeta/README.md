# Lábia Masculina — Beta Android

Projeto Android da versão beta do Lábia Masculina.

## O que está incluído

- Interface mobile em HTML/CSS/JavaScript dentro de uma WebView.
- Identidade visual preta, roxa e amarela.
- Tela inicial, login de demonstração, módulos, lições e progresso.
- Persistência do progresso no armazenamento local do WebView.
- Certificado ao concluir a trilha.
- IA Dogzera com upload de print e campo de situação.
- Ícone da Dogzera em formato de rosto de pug, nas cores do app.
- Seleção de imagens pelo armazenamento do Android.
- Permissão de internet para futura API da IA.

## Abrir no Android Studio

1. Abra a pasta `LabiaMasculinaBeta` no Android Studio.
2. Aguarde a sincronização do Gradle.
3. Conecte um aparelho Android ou crie um emulador.
4. Execute o módulo `app`.
5. Para gerar o APK: `Build > Build APK(s)`.

## Observação sobre a IA Dogzera

O aplicativo beta possui a interface e a chamada preparada para:

- `POST /api/dogzera/analisar` para prints.
- `POST /api/dogzera/analisar-texto` para situações digitadas.

Esses endpoints ainda precisam existir em um servidor. A chave de qualquer modelo de IA deve ficar somente no servidor, nunca no APK.

O login, pagamento PIX e armazenamento em nuvem também são protótipos nesta versão. Para produção, use autenticação segura e confirmação de pagamento no servidor.
