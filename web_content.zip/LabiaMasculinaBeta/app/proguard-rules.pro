# Beta build: no custom ProGuard rules.
