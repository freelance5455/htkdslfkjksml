O Android Studio pode gerar o Gradle Wrapper para este projeto em Gradle > Generate Gradle Wrapper.
O projeto foi mantido sem o binário gradle-wrapper.jar para evitar incluir um binário não verificado.
