Click Bazar24 - Android Studio project

ئەمە پرۆژەی Android Studio ـە کە وێبسایتی HTML/CSS/JS ـەکەت لە ناو WebView دەخاتە ناو ئەپی Android.

چۆنیەتی دروستکردنی APK:
1. ZIP ـەکە بکەرەوە.
2. Android Studio دابەزێنە و پرۆژەکە بە Open بکەرەوە (فۆڵدەری ClickBazar24).
3. چاوەڕێ بکە Gradle Sync تەواو ببێت و SDK ـی پێویست دابەزێنە.
4. لە مێنیو Build هەڵبژێرە: Build Bundle(s) / APK(s) > Build APK(s).
5. APK ـەکە لە app/build/outputs/apk/debug/app-debug.apk دەبێت.

تێبینی:
- ئەم ZIP ـە APK ـی ئامادە نییە؛ سەرچاوەی پرۆژەیە بۆ دروستکردنی APK.
- ناو فایلە HTML ـە سەرەتاییەکاندا هەندێک HTML ـی هەڵە و وێنەی نەبوو وەک controller.jpg و gaming-bg.jpg هەیە؛ پێویستە پێش بڵاوکردنەوە چاک بکرێن.
- بۆ پارەدان و فرۆشتنی ڕاستەقینە، پێویستە سیستەمی پارەدان/داواکاری و سێرڤەر بە شێوەیەکی جیاواز زیاد بکرێت.
