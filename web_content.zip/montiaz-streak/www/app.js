(() => {
  'use strict';
  const KEY = 'montiaz_streak_v1';
  const NAME = 'منتصر';
  const DEFAULTS = {
    habit: 'عادتي',
    checkins: [],            // أيام التسجيل في الجولة الحالية (YYYY-MM-DD)
    history: [],             // الجولات المؤرشفة بعد التصفير
    settings: { notif: true, from: 8, to: 23 }
  };

  /* ---------- أدوات ---------- */
  const $ = (s) => document.querySelector(s);
  const pad = (n) => String(n).padStart(2, '0');
  const dkey = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const parse = (k) => { const [y, m, d] = k.split('-').map(Number); return new Date(y, m - 1, d); };
  const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
  const gap = (a, b) => Math.round((parse(b) - parse(a)) / 864e5);
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  const clone = (o) => JSON.parse(JSON.stringify(o));

  function load() {
    try {
      const r = JSON.parse(localStorage.getItem(KEY));
      if (!r) return clone(DEFAULTS);
      return { ...clone(DEFAULTS), ...r, settings: { ...DEFAULTS.settings, ...(r.settings || {}) } };
    } catch (e) { return clone(DEFAULTS); }
  }
  let S = load();
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} };

  /* ---------- حساب السلسلة ---------- */
  const todayKey = () => dkey(new Date());
  const doneToday = () => S.checkins.includes(todayKey());

  function streakOf(list) {
    const set = new Set(list);
    let cur = new Date();
    if (!set.has(dkey(cur))) cur = addDays(cur, -1);   // السلسلة تبقى حيّة حتى نهاية اليوم
    let n = 0;
    while (set.has(dkey(cur))) { n++; cur = addDays(cur, -1); }
    return n;
  }
  function bestOf(list) {
    const s = [...new Set(list)].sort();
    let best = 0, run = 0;
    s.forEach((k, i) => {
      run = i > 0 && gap(s[i - 1], k) === 1 ? run + 1 : 1;
      if (run > best) best = run;
    });
    return best;
  }
  function lastWeekCount(list) {
    const set = new Set(list);
    let c = 0;
    for (let i = 0; i < 7; i++) if (set.has(dkey(addDays(new Date(), -i)))) c++;
    return c;
  }
  const fmtDate = (k) => parse(k).toLocaleDateString('ar', { day: 'numeric', month: 'long', year: 'numeric' });

  /* ---------- الرسائل التحفيزية ---------- */
  const pick = (a) => a[Math.floor(Math.random() * a.length)];
  function greet() {
    const h = new Date().getHours();
    if (h < 5) return 'ما زلت صاحيًا';
    if (h < 12) return 'صباح القوة';
    if (h < 17) return 'نهارك أقوى';
    if (h < 21) return 'مساء الإصرار';
    return 'ليلة الأبطال';
  }
  function message(st, done) {
    if (done) {
      return pick([
        `أنجزت اليوم يا ${NAME}. هذا ما يفعله من لا يتراجع. 🔥`,
        `يوم آخر في جيبك. السلسلة تكبر وأنت تكبر معها.`,
        `الانضباط يصنع الأبطال، وأنت تثبت ذلك يوميًا يا ${NAME}.`
      ]);
    }
    if (st === 0) {
      if (S.checkins.length) return `انقطعت السلسلة، لكن البطل لا يتوقف عند السقطة. سجّل اليوم وابدأ من جديد يا ${NAME}!`;
      return `ابدأ الآن يا ${NAME}. اليوم الأول هو الأصعب، وأنت أقوى منه.`;
    }
    if (st < 3) return `بداية رائعة! لا تدع الشرارة تنطفئ يا ${NAME}.`;
    if (st < 7) return `${st} أيام متتالية! الزخم معك، لا تكسره الآن.`;
    if (st < 14) return `أسبوع كامل وأكثر! أنت تتحول إلى شخص آخر يا ${NAME}.`;
    if (st < 30) return `${st} يومًا من الحديد. السلسلة صارت جزءًا من هويتك.`;
    if (st < 100) return `شهر وأكثر! قليلون جدًا يصلون إلى هنا. أنت منهم يا ${NAME}.`;
    return `أسطورة! ${st} يومًا. لا شيء يوقفك.`;
  }
  function levelOf(st) { return st >= 30 ? 3 : st >= 7 ? 2 : st >= 1 ? 1 : 0; }

  /* ---------- الواجهة ---------- */
  let tab = 'home';
  const view = $('#view');

  function toast(t) {
    const el = document.createElement('div');
    el.className = 'toast'; el.textContent = t;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 2200);
  }
  function burst() {
    const em = ['🔥', '⚡', '💪', '🏆', '✨'];
    for (let i = 0; i < 22; i++) {
      const s = document.createElement('span');
      s.className = 'burst';
      s.textContent = pick(em);
      s.style.left = (30 + Math.random() * 40) + 'vw';
      s.style.top = '55vh';
      s.style.setProperty('--dx', (Math.random() * 200 - 100) + 'px');
      s.style.animationDelay = (Math.random() * .25) + 's';
      document.body.appendChild(s);
      setTimeout(() => s.remove(), 1700);
    }
    if (navigator.vibrate) navigator.vibrate([40, 30, 80]);
  }

  function renderHome() {
    const st = streakOf(S.checkins);
    const best = bestOf(S.checkins);
    const done = doneToday();
    const lvl = levelOf(st);
    const now = new Date();
    const atRisk = !done && st > 0 && now.getHours() >= 18;

    let cells = '';
    for (let i = 29; i >= 0; i--) {
      const k = dkey(addDays(now, -i));
      const on = S.checkins.includes(k);
      cells += `<div class="cell${on ? ' on' : ''}${i === 0 ? ' today' : ''}" title="${k}"></div>`;
    }

    view.innerHTML = `
      <div class="top"><div class="brand">🔥 مونتياز</div><div class="hello">${greet()} يا <b>${NAME}</b></div></div>
      ${atRisk ? `<div class="warn">⚠️ سلسلتك في خطر! سجّل قبل منتصف الليل يا ${NAME}</div>` : ''}
      <section class="hero ${done ? 'done' : ''} ${lvl >= 2 ? 'hot' : ''} ${st === 0 ? 'cold' : ''}">
        ${best > 0 ? `<span class="badge">🏆 الأفضل ${best}</span>` : ''}
        <div class="flame">${st > 0 ? '🔥' : '🕯️'}</div>
        <div class="num">${st}</div>
        <div class="unit">يوم متتالي</div>
        <div class="habit">${esc(S.habit)}</div>
      </section>
      <p class="msg">${message(st, done)}</p>
      <button class="cta ${done ? 'done' : ''}" data-act="check">${done ? '✅ أنجزت اليوم' : '🔥 سجّلت اليوم'}</button>
      ${done ? '<button class="link" data-act="undo">تراجع عن تسجيل اليوم</button>' : ''}
      <div class="stats">
        <div class="stat"><b>${S.checkins.length}</b><span>إجمالي الأيام</span></div>
        <div class="stat"><b>${lastWeekCount(S.checkins)}/7</b><span>آخر أسبوع</span></div>
        <div class="stat"><b>${S.history.length}</b><span>جولات سابقة</span></div>
      </div>
      <h3>آخر 30 يومًا</h3>
      <div class="grid">${cells}</div>
      <button class="link red" data-act="reset" style="margin-top:22px">تصفير التقدم (مع حفظه في السجل)</button>
    `;
  }

  function renderHistory() {
    const cur = S.checkins.length
      ? `<div class="card"><div class="row"><div><div class="big">الجولة الحالية</div>
          <small>${S.checkins.length} يوم · أفضل سلسلة ${bestOf(S.checkins)}</small></div><span class="pill">جارية 🔥</span></div></div>`
      : '';
    const items = S.history.slice().sort((a, b) => b.resetAt.localeCompare(a.resetAt)).map((h) => {
      const sorted = [...h.checkins].sort();
      return `<div class="card">
        <div class="row"><div><div class="big">${h.total} يوم</div>
          <small>${fmtDate(sorted[0])} ← ${fmtDate(sorted[sorted.length - 1])}</small></div>
          <span class="pill">🏆 ${h.best}</span></div>
        <div style="margin-top:8px"><span class="pill">${esc(h.habit || '')}</span><span class="pill">صُفِّرت ${fmtDate(h.resetAt)}</span></div>
        <div class="days" id="d-${h.id}" hidden>${sorted.map((k) => `<i>${k.slice(5)}</i>`).join('')}</div>
        <div class="row" style="margin-top:12px;justify-content:flex-start">
          <button class="btn" data-act="toggle" data-id="${h.id}">عرض الأيام</button>
          <button class="btn fire" data-act="restore" data-id="${h.id}">↩︎ الرجوع إليها</button>
          <button class="btn red" data-act="del" data-id="${h.id}">حذف</button>
        </div></div>`;
    }).join('');
    view.innerHTML = `
      <div class="top"><div class="brand">📜 سجل التقدم</div></div>
      ${cur}
      ${items || `<div class="empty">لا توجد جولات سابقة بعد.<br>عندما تصفّر تقدمك تُحفظ الجولة هنا ويمكنك الرجوع إليها في أي وقت.</div>`}
    `;
  }

  function renderSettings() {
    const hrs = (sel) => Array.from({ length: 24 }, (_, h) => `<option value="${h}"${sel === h ? ' selected' : ''}>${pad(h)}:00</option>`).join('');
    const perm = ('Notification' in window) ? Notification.permission : 'unsupported';
    view.innerHTML = `
      <div class="top"><div class="brand">⚙️ الإعدادات</div></div>
      <div class="card">
        <label style="margin-top:0">اسم العادة</label>
        <input type="text" id="habit" value="${esc(S.habit)}" maxlength="40">
        <div class="switch" style="margin-top:16px"><span>تذكير كل ساعة</span><input type="checkbox" id="notif" ${S.settings.notif ? 'checked' : ''}></div>
        <div class="two">
          <div><label>من الساعة</label><select id="from">${hrs(S.settings.from)}</select></div>
          <div><label>إلى الساعة</label><select id="to">${hrs(S.settings.to)}</select></div>
        </div>
        <p class="note">التذكيرات تتوقف تلقائيًا بعد تسجيل اليوم، وتعود صباح اليوم التالي.</p>
        <div style="display:flex;gap:8px;margin-top:10px"><button class="btn fire" data-act="saveset">حفظ</button><button class="btn" data-act="testnotif">جرّب إشعارًا</button></div>
        ${perm === 'denied' ? '<p class="note">⚠️ الإشعارات محظورة. فعّلها من إعدادات الهاتف.</p>' : ''}
      </div>
      <div class="card">
        <div class="big" style="margin-bottom:8px">نسخة احتياطية</div>
        <div style="display:flex;gap:8px"><button class="btn" data-act="export">تصدير</button><button class="btn" data-act="import">استيراد</button></div>
        <input type="file" id="file" accept="application/json" hidden>
        <p class="note">البيانات محفوظة داخل التطبيق فقط. احتفظ بنسخة احتياطية قبل حذف التطبيق.</p>
      </div>`;
  }

  function render() {
    document.querySelectorAll('#nav button').forEach((b) => b.classList.toggle('active', b.dataset.tab === tab));
    ({ home: renderHome, history: renderHistory, settings: renderSettings }[tab])();
  }

  /* ---------- الإجراءات ---------- */
  function check() {
    if (doneToday()) return;
    S.checkins.push(todayKey());
    save(); render(); burst(); scheduleAll();
  }
  function undo() {
    S.checkins = S.checkins.filter((k) => k !== todayKey());
    save(); render(); scheduleAll();
  }
  function archiveCurrent() {
    if (!S.checkins.length) return;
    S.history.push({
      id: uid(), habit: S.habit, checkins: [...S.checkins],
      total: new Set(S.checkins).size, best: bestOf(S.checkins), resetAt: todayKey()
    });
    S.checkins = [];
  }
  function reset() {
    if (!S.checkins.length) return toast('لا يوجد تقدم لتصفيره');
    if (!confirm(`تصفير التقدم يا ${NAME}؟\nسيُحفظ كل ما أنجزته في السجل ويمكنك الرجوع إليه.`)) return;
    archiveCurrent(); save(); render(); scheduleAll();
    toast('تم الحفظ في السجل. ابدأ من جديد 💪');
  }
  function restore(id) {
    const h = S.history.find((x) => x.id === id);
    if (!h) return;
    const msg = S.checkins.length
      ? 'سيتم حفظ التقدم الحالي في السجل ثم استرجاع هذه الجولة. متابعة؟'
      : 'استرجاع هذه الجولة كتقدم حالي؟';
    if (!confirm(msg)) return;
    S.history = S.history.filter((x) => x.id !== id);
    archiveCurrent();
    S.checkins = [...h.checkins];
    if (h.habit) S.habit = h.habit;
    save(); tab = 'home'; render(); scheduleAll();
    toast('رجعت الجولة. أكمل الطريق! 🔥');
  }
  function del(id) {
    if (!confirm('حذف هذه الجولة نهائيًا؟')) return;
    S.history = S.history.filter((x) => x.id !== id);
    save(); render();
  }
  function saveSettings() {
    S.habit = ($('#habit').value || '').trim() || 'عادتي';
    S.settings.notif = $('#notif').checked;
    S.settings.from = +$('#from').value;
    S.settings.to = +$('#to').value;
    if (S.settings.to < S.settings.from) { const t = S.settings.from; S.settings.from = S.settings.to; S.settings.to = t; }
    save(); render(); toast('تم الحفظ ✅');
    if (S.settings.notif) enableNotifications().then(scheduleAll); else scheduleAll();
  }
  function exportData() {
    const blob = new Blob([JSON.stringify(S, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `montiaz-backup-${todayKey()}.json`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  }
  function importData(file) {
    const r = new FileReader();
    r.onload = () => {
      try {
        const d = JSON.parse(r.result);
        if (!Array.isArray(d.checkins) || !Array.isArray(d.history)) throw 0;
        if (!confirm('سيتم استبدال البيانات الحالية بالنسخة المستوردة. متابعة؟')) return;
        S = { ...clone(DEFAULTS), ...d, settings: { ...DEFAULTS.settings, ...(d.settings || {}) } };
        save(); render(); scheduleAll(); toast('تم الاستيراد ✅');
      } catch (e) { toast('ملف غير صالح'); }
    };
    r.readAsText(file);
  }

  /* ---------- الإشعارات ---------- */
  const LN = () => (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.LocalNotifications) || null;

  function notifText() {
    const st = streakOf(S.checkins);
    const list = st > 0 ? [
      [`🔥 سلسلتك ${st} يوم!`, `لا تدعها تنطفئ يا ${NAME}. سجّل "${S.habit}" الآن.`],
      [`⚡ ${st} يومًا من القوة`, `الأبطال لا يؤجلون. أنجز "${S.habit}" وأبقِ النار مشتعلة.`],
      [`💪 يا ${NAME}!`, `سلسلة ${st} يوم تنتظرك. دقيقة واحدة وتنتهي.`],
      [`⏰ تذكير الإصرار`, `أنت أقوى من الكسل. "${S.habit}" الآن!`]
    ] : [
      [`🔥 ابدأ اليوم يا ${NAME}`, `أول يوم يصنع الفارق. سجّل "${S.habit}".`],
      [`💪 لحظة القرار`, `لا شيء يتغير بالانتظار. ابدأ سلسلتك الآن.`]
    ];
    return pick(list);
  }

  async function enableNotifications() {
    const ln = LN();
    try {
      if (ln) {
        const p = await ln.checkPermissions();
        if (p.display !== 'granted') {
          const r = await ln.requestPermissions();
          return r.display === 'granted';
        }
        return true;
      }
      if ('Notification' in window) {
        if (Notification.permission === 'default') await Notification.requestPermission();
        return Notification.permission === 'granted';
      }
    } catch (e) {}
    return false;
  }

  // يجدول إشعارات الساعات القادمة (3 أيام) ويلغي القديمة. يُعاد استدعاؤه عند كل تغيير أو فتح للتطبيق.
  async function scheduleAll() {
    const ln = LN();
    if (!ln) return;
    try {
      const pend = await ln.getPending();
      if (pend.notifications.length) await ln.cancel({ notifications: pend.notifications.map((n) => ({ id: n.id })) });
      if (!S.settings.notif) return;
      if (!(await enableNotifications())) return;
      try { await ln.createChannel({ id: 'streak', name: 'تذكير السلسلة', importance: 5, vibration: true, visibility: 1 }); } catch (e) {}
      const now = new Date();
      const out = [];
      let id = 1;
      for (let d = 0; d < 3; d++) {
        if (d === 0 && doneToday()) continue;
        const day = addDays(now, d);
        for (let h = S.settings.from; h <= S.settings.to; h++) {
          const at = new Date(day.getFullYear(), day.getMonth(), day.getDate(), h, 0, 0);
          if (at <= now) continue;
          const [title, body] = notifText();
          out.push({ id: id++, title, body, schedule: { at, allowWhileIdle: true }, channelId: 'streak' });
        }
      }
      if (out.length) await ln.schedule({ notifications: out });
    } catch (e) { console.warn('schedule failed', e); }
  }

  async function testNotif() {
    const ok = await enableNotifications();
    if (!ok) return toast('لم يتم منح إذن الإشعارات');
    const [title, body] = notifText();
    const ln = LN();
    if (ln) {
      try { await ln.createChannel({ id: 'streak', name: 'تذكير السلسلة', importance: 5, vibration: true }); } catch (e) {}
      await ln.schedule({ notifications: [{ id: 9999, title, body, schedule: { at: new Date(Date.now() + 2000) }, channelId: 'streak' }] });
    } else if ('serviceWorker' in navigator && navigator.serviceWorker.ready) {
      const reg = await navigator.serviceWorker.ready;
      reg.showNotification(title, { body, icon: 'icon-192.png' });
    } else new Notification(title, { body });
    toast('سيصلك إشعار بعد ثانيتين');
  }

  // نسخة المتصفح فقط: تذكير كل ساعة طالما الصفحة مفتوحة
  let lastHourFired = -1;
  function webTick() {
    if (LN() || !S.settings.notif || !('Notification' in window) || Notification.permission !== 'granted') return;
    const n = new Date(), h = n.getHours();
    if (n.getMinutes() !== 0 || h === lastHourFired) return;
    if (h < S.settings.from || h > S.settings.to || doneToday()) return;
    lastHourFired = h;
    const [title, body] = notifText();
    try { new Notification(title, { body }); } catch (e) {}
  }
  setInterval(webTick, 20000);

  /* ---------- الأحداث ---------- */
  document.addEventListener('click', (e) => {
    const nav = e.target.closest('#nav button');
    if (nav) { tab = nav.dataset.tab; return render(); }
    const el = e.target.closest('[data-act]');
    if (!el) return;
    const id = el.dataset.id;
    switch (el.dataset.act) {
      case 'check': check(); break;
      case 'undo': undo(); break;
      case 'reset': reset(); break;
      case 'restore': restore(id); break;
      case 'del': del(id); break;
      case 'toggle': { const d = document.getElementById('d-' + id); d.hidden = !d.hidden; el.textContent = d.hidden ? 'عرض الأيام' : 'إخفاء الأيام'; break; }
      case 'saveset': saveSettings(); break;
      case 'testnotif': testNotif(); break;
      case 'export': exportData(); break;
      case 'import': $('#file').click(); break;
    }
  });
  document.addEventListener('change', (e) => {
    if (e.target.id === 'file' && e.target.files[0]) importData(e.target.files[0]);
  });
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) { render(); scheduleAll(); }
  });

  /* ---------- تشغيل ---------- */
  if ('serviceWorker' in navigator && !window.Capacitor && location.protocol.startsWith('http')) {
    navigator.serviceWorker.register('sw.js').catch(() => {});
  }
  render();
  scheduleAll();
})();
