# OPERATION SHADOW — Test Report

Environment: Node 20 sandbox, no browser and no GPU, so rendering was **not** pixel-verified.
Two automated suites were run against the real source code:

* `node tests/run.mjs` builds all three maps and tests collision, stairs, raycasts, nav/A*, AI perception, weapon stats and save validation.
* `node tests/ui.mjs` renders all 20 UI screens/variants with React SSR.
* `node tests/game.mjs` runs the **real `Game` class** with a faked WebGL renderer. It plays every mode end to end with scripted input: aiming, firing, reloading, switching, looting, zone, TDM, waves and restarts.

## Verified (automated)
| # | Requirement | Result |
|---|---|---|
| 3 | New match starts (all 4 modes) | ✔ |
| 4 | Movement/collision: no wall clipping, stair climbing, landing, 30 s random walks on every map | ✔ |
| 5 | All 20 weapons selectable and fired in gameplay | ✔ |
| 6 | Reload arithmetic: exact transfer, no negatives, no duplication; no firing while reloading | ✔ |
| 7 | Hit detection (head sphere + body cylinder), damage, range targets | ✔ |
| 8 | AI does not see through walls, detects visible player, engages, hears gunfire, reacts to damage, eliminates others | ✔ |
| 9 | Player death → defeat (Combat/BR), respawn (TDM) | ✔ |
| 10 | Victory/defeat: Combat waves, BR last-standing, TDM score limit | ✔ |
| 15 | Save/load: defaults on corrupt data, clamping, invalid loadout repair, XP + high scores persist | ✔ |
| 16 | Restarting doesn't duplicate enemies or leak listeners | ✔ |
| — | Loot: pickup, swap-drop conservation, inventory limits, crates open once, plates → armor | ✔ |
| — | BR zone shrinks and damages players outside | ✔ |
| — | Pause freezes local simulation | ✔ |
| — | Game-logic CPU: about 0.1 ms/frame with 21 AI | ✔ |

## Not verified (needs real hardware/browser)
* 1, 2, 11–14, 17: visual menu rendering, button clicks in a real DOM, real multitouch, real keyboard/mouse with pointer lock, visual graphics changes, audible volume changes. These are implemented and type-checked but were not observed.
* 18: Android install/launch. **No APK was built**, because no Android SDK is available.
* 19: Frame rate and memory on target phones.

## Bugs found and fixed during testing
1. The nav grid blocked 1.8 m doorways, so AI couldn't leave buildings and one Dust Frontier spawn was enclosed. Fixed with centre-point tests on a 1 m grid.
2. The fire-rate cooldown carried over between weapons, so a newly equipped weapon could be locked out. Fixed.
3. Combat waves could stall if a straggler never found the player. Hostiles now get an approximate-position radio alert after 40 s.
4. Taking damage cancelled armor plating. Plating now continues, matching genre expectations; healing is still interruptible.

## UI render smoke test — `node tests/ui.mjs`
Every menu screen, HUD variant and touch layout is server-rendered with React to catch render-time crashes. Visuals are still not inspected.
```
  ✔ Splash (1729 chars)
  ✔ MainMenu (11839 chars)
  ✔ ModeSelect BR (6389 chars)
  ✔ ModeSelect Range (4948 chars)
  ✔ Multiplayer (5157 chars)
  ✔ Operators (5999 chars)
  ✔ Missions (14319 chars)
  ✔ Progression (9194 chars)
  ✔ Credits (2571 chars)
  ✔ Loadout (19517 chars)
  ✔ Armory (22047 chars)
  ✔ RangeArmory (18640 chars)
  ✔ Settings graphics (8527 chars)
  ✔ Settings audio (4414 chars)
  ✔ Settings controls (10869 chars)
  ✔ Settings gameplay (4487 chars)
  ✔ HUD (BR, desktop) (4996 chars)
  ✔ HUD (TDM, touch) (3423 chars)
  ✔ TouchControls BR (3800 chars)
  ✔ TouchControls Range (3512 chars)

UI RESULT: 20 passed, 0 failed
```

## Raw output — tests/run.mjs
```
WEAPONS
  ✔ at least 20 weapons defined — 20
  ✔ weapon ids unique
  ✔ every weapon has a distinct stat/model signature
  ✔ all weapons × all compatible attachments produce valid stats
  ✔ extended mag increases capacity — 30 → 45
  ✔ compensator reduces vertical recoil
  ✔ invalid/incompatible attachments are stripped — {}
  ✔ attachment ids unique
  ✔ reload never exceeds mag, never negative, never duplicates ammo (2000 random cases)
SAVE SYSTEM
  ✔ defaults used when settings data missing/corrupt
  ✔ out-of-range values clamped — master=1
  ✔ invalid types replaced by defaults
  ✔ invalid loadout weapons repaired
  ✔ match result grants XP and persists — +1354 XP
  ✔ high score recorded
  ✔ tampered/corrupted save detected by checksum
MAP: IRON
  ✔ map builds — 1271 colliders, 172 draw objects, 125ms
  ✔ nav grid has walkable area — 84% walkable
  ✔ all spawns are on walkable cells — 63 spawns
  ✔ player lands on ground at spawn — y=0.00
  ✔ 30s random walk never clips into geometry — 0 violations
  ✔ A* path exists between team spawns — 12 waypoints, 17ms
  ✔ loot spots & crates generated — 52 loot / 16 crates
MAP: DUST
  ✔ map builds — 675 colliders, 113 draw objects, 189ms
  ✔ nav grid has walkable area — 95% walkable
  ✔ all spawns are on walkable cells — 31 spawns
  ✔ player lands on ground at spawn — y=0.12
  ✔ 30s random walk never clips into geometry — 0 violations
  ✔ A* path exists between team spawns — 13 waypoints, 25ms
  ✔ loot spots & crates generated — 34 loot / 9 crates
MAP: RANGE
  ✔ map builds — 18 colliders, 20 draw objects, 5ms
  ✔ nav grid has walkable area — 94% walkable
  ✔ all spawns are on walkable cells — 4 spawns
  ✔ player lands on ground at spawn — y=0.00
  ✔ 30s random walk never clips into geometry — 0 violations
  ✔ range targets present (static + moving + dummy) — 14 targets
PHYSICS & RAYCAST
  ✔ cannot walk through a wall (fast sprint for 3s) — z=4.45
  ✔ can climb stairs onto an upper floor — y=3.40 z=8.33
  ✔ raycast hits wall at correct distance — d=4.800
  ✔ line of sight blocked by wall
  ✔ line of sight clear in the open
  ✔ A* routes around the wall — 4 pts
  ✔ A* paths out through a 1.8m doorway — 3 pts
ENEMY AI
  ✔ AI does NOT see or shoot the player through a wall — shots=0, state=patrol
  ✔ AI detects visible player and engages — state=engage, shots=17
  ✔ AI ammo decreases and reload keeps mag valid — mag=13
  ✔ AI investigates gunfire it hears (approximate position) — state=investigate
  ✔ AI reacts to damage (searches toward attacker) — state=search

RESULT: 48 passed, 0 failed
```

## Raw output — tests/game.mjs
```
PRACTICE RANGE
  ✔ range starts with targets — 14 targets
  ✔ shots register hits on range target — hits=13 shots=51
  ✔ targets go down and are counted — targets=2
  ✔ ammo invariant held while firing
  ✔ all 20 weapons can be selected and fired in gameplay
  ✔ cannot fire while reloading — mag 3 → 3
  ✔ reload fills magazine (range: unlimited reserve) — mag=30 reserve=90
  ✔ weapon switching to slot 2 — active=1 (P-01 Sidekick)
  ✔ pause freezes local simulation
  ✔ range session ends with results — score=481
OFFLINE COMBAT
  ✔ reload transfers exactly the missing rounds (no duplication) — mag=30 reserve=73
  ✔ empty weapon with no reserve cannot fire or go negative
  ✔ enemy waves spawn and progress — reached wave 5, peak alive 10
  ✔ player eliminations counted with score — kills=45 score=33500 hs=10
  ✔ ammo invariant held for 4 minutes of combat
  ✔ enemies engaged and damaged the player — last hurt at t=62.6s
  ✔ combat victory after final wave — OPERATION COMPLETE
  ✔ player death → defeat screen — KIA
BATTLE ROYALE
  ✔ BR spawns AI opponents + loot — 13 bots, 64 loot, 9 crates
  ✔ player starts parachuting with a sidearm only
  ✔ player lands from parachute — y=5.0
  ✔ weapon pickup fills empty primary slot & item removed — AR-05 Phantom
  ✔ weapon swap drops old weapon (count conserved) — loot 63 → 63
  ✔ inventory limit: plate stays on ground when full
  ✔ plate picked up when space available
  ✔ applying plate consumes plate and grants armor — armor=50
  ✔ supply crate opens once and drops loot — +3 items
  ✔ crate cannot be looted twice
  ✔ safe zone shrinks over time — r 180 → 99
  ✔ player outside zone takes damage — 99.96666666666663 → 96
  ✔ AI opponents are eliminated (by each other / zone) — 4 → 0 alive
  ✔ BR victory when last operator standing — VICTORY · #1
TEAM DEATHMATCH
  ✔ two teams spawned — allies 5+you vs enemies 6
  ✔ player death awards enemy team point
  ✔ player respawns after delay
  ✔ teams score eliminations over time — score 28–30
  ✔ match ends at score limit or timer with a winner — ENEMY TEAM WINS (28,30)
  ✔ bots respawn in TDM
LIFECYCLE
  ✔ restarting 3× leaks no window/document listeners — window Δ0, document Δ0
  ✔ restart does not duplicate enemies — 11 → 11
PERFORMANCE (CPU only — rendering excluded)
  ✔ BR low (9 AI) game-logic CPU per frame < 4ms — 0.08 ms/frame
  ✔ BR ultra (21 AI) game-logic CPU per frame < 4ms — 0.21 ms/frame
  ✔ no runtime errors logged during simulations — 0 errors

RESULT: 43 passed, 0 failed
```
