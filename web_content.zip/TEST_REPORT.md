# WhatsApp Ledger — pre-delivery QA report

## Checks performed

- JavaScript syntax check (`node --check`): PASS.
- HTML parsing: PASS.
- Duplicate HTML element IDs: none found.
- File input association: the actual `<input type="file">` is directly inside a visible `<label for="zip">` tap target; no JavaScript `.click()` is required to open the picker.
- Date parsing tests: PASS for Nigerian day/month/year with AM/PM, midnight/noon conversion, and rejection of impossible dates.
- WhatsApp text parsing tests: PASS for a two-message multiline sample.
- NGN amount extraction tests: PASS for `₦`, `NGN`, and `Naira` examples; no amount returned for unrelated text.
- Month bucketing and media filename date extraction tests: PASS.
- Transaction keyword filter test: PASS.
- Mocked end-to-end chat ZIP import test: PASS for one TXT conversation, group ledger creation, two extracted transaction rows, and local persistence.
- ZIP archive integrity and root layout: checked during packaging.

## Known items that cannot be certified in this environment

- The actual APKForge build and its Android WebView implementation were not available for execution here.
- Android file selection depends on APKForge's native WebView file chooser implementation. The HTML now uses a direct, user-tappable file input, but if APKForge does not implement the native chooser callback, no HTML-only change can force Android's picker to open.
- Device-specific download behavior for XLSX/JSON exports must be tested in the APKForge-generated APK.
- Tesseract OCR was not run against a representative set of the user's actual Nigerian bank receipts on the target phone. OCR accuracy varies by receipt layout, image quality, language, and device memory.
- No software audit can honestly guarantee zero defects or 100% correct accounting extraction. Every detected transaction remains unverified until a person checks the original message/receipt.

## Risk controls added

- Import size/file-count/expanded-size guardrails.
- ZIP CRC checking.
- One-conversation-file validation.
- Strict calendar-date validation and no automatic assignment of unknown dates to the current month.
- Stable local calendar dates to avoid UTC timezone month/day shifts.
- Per-group identity for separate ledgers.
- Duplicate filtering and possible-duplicate review status.
- Storage-write failure handling and rollback of an uncommitted import.
- OCR startup failure no longer prevents chat-text import; it is reported to the user.
- Receipt images too large or unreadable are surfaced for manual review rather than silently treated as successful payments.
- User must explicitly confirm a transaction before it is marked verified.
