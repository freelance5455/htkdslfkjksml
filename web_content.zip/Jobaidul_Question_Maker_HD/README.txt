জোবাইদুল প্রশ্ন মেকার HD

ব্যবহার:
1. এই ফোল্ডারের index.html এবং font ফাইলগুলো একই জায়গায় রাখুন।
2. index.html Chrome/যেকোনো আধুনিক ব্রাউজারে খুলুন।
3. মাদ্রাসার নাম → প্রশ্ন যোগ → Save Question → Save Paper।
4. Preview থেকে PDF/Print, PNG ও JPG export করুন।
5. Save অংশ থেকে Backup/Restore ব্যবহার করে ডাটা অন্য ফোনেও নিতে পারবেন।

নোট:
- PDF Save ব্রাউজারের Print → Save as PDF দিয়ে করা হয়।
- PNG/JPG export-এর জন্য প্রথমবার ইন্টারনেট প্রয়োজন হতে পারে, কারণ html2canvas লাইব্রেরি CDN থেকে লোড হয়।
- আপলোড করা বাংলা ফন্টগুলো প্যাকেজে রাখা হয়েছে।
