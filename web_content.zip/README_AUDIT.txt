SHAIKH Box ERP source ZIP - Premium Invoice + Quick PIN Access

Included updates:
- Premium branded invoice styling and print/PDF-oriented layout retained.
- Multi-item invoice cart: add/remove lines, per-line qty/rate/discount/GST, aggregate totals, stock OUT per line, and multi-item print/share summary.
- After first successful password login/profile setup, user is prompted to create and confirm a 4-digit quick-access PIN.
- On subsequent app starts, the PIN unlock screen appears; user can alternatively choose password login.
- Fingerprint button attempts to call Android.authenticateBiometric() if the native APK wrapper exposes that bridge.

Important biometric limitation:
- A ZIP/HTML-only update cannot add Android's native fingerprint permission/implementation to an APK wrapper. If the converter's wrapper does not expose Android.authenticateBiometric(), fingerprint unlock will show a clear message and PIN/password remain available. True fingerprint support requires the native Android wrapper to implement and expose a biometric bridge.
- PIN is a convenience lock within the WebView app, not a substitute for Android device security or encrypted database storage. Browser local storage can be cleared by app data reset/reinstall.
- Default login credentials in this source remain the existing values unless changed in Login/Profile settings. Change them before real use.

Validation performed:
- ZIP archive integrity test.
- Inline JavaScript syntax checks and duplicate HTML ID scan.
- No live Android device or biometric sensor test performed.

Still requires real-world configuration/testing:
- GST auto-fetch and government E-Way Bill generation require authorized API credentials/integration.
- Test sample invoices and print/PDF output on the target Android converter/WebView; export a backup before entering live business records.


INVOICE TOTAL FIX (2026-10-10)
- Invoice preview now sums every saved cart line plus the currently edited line.
- Save invoice recalculates totals from the exact lines being saved, including each line's tax mode, discount and GST.
- Grand Total is the sum of item line amounts plus invoice round-off; the saved invoice and print/PDF use the same stored total.
- Sales list shows each line and the aggregate grand total instead of displaying a zero rate for multi-item bills.
- Re-test on Android with different quantities/rates/GST. This ZIP has source-level checks only; no Android end-to-end test was performed.


REPORT CENTRE UPDATE (2026-10-10)
- Added a dedicated Reports & Export Centre in the existing Reports tab.
- Supports overall, day-wise, week-wise, month-wise, year-wise, and custom date-range reports.
- Supports party/name filtering and transaction scope filters for sales, purchase, cash work, expenses, payments, khata, stock, returns, journals, payroll, attendance, costing, and e-way entries.
- Shows record count, sales, purchases, cash work income, expenses, selected total, and a detailed table.
- Added print/save-as-PDF and Excel-compatible .xls plus CSV exports. Excel exports contain all matching rows; on-screen table is capped at 1000 rows for mobile performance.
- Excel output is an HTML table file with .xls extension (opens in Excel-compatible spreadsheet apps); this is not a native binary .xlsx file.
- Source-level syntax and archive checks performed; report accuracy/export rendering still needs testing on target Android WebView with actual company data.


V18 SWIPE-INSPIRED FAST BILLING WORKSPACE
- Billing page UI reorganized into customer/product entry and invoice-cart/payment panels.
- Added item search filter, quick payment mode chips, clearer multi-line cart, live total panel, save, print/PDF and share actions.
- Preserved existing SHAIKH Box ERP navigation and non-billing modules; this is an original workflow inspired by common fast-billing patterns, not a copy of Swipe's proprietary UI.
- This is a source ZIP, not a signed APK. HTML/JavaScript static syntax and ZIP integrity checks pass; actual Android end-to-end tests are still required.


CORRUGATED COSTING WORKSPACE UPDATE (2026-10-10)
- Reorganized the costing section with a factory workflow header (Box Spec → Paper Recipe → Charges → Rate & Quote), preserving the existing app navigation and modules.
- Added manufacturing analysis for calculated total board GSM, estimated board weight per box, blank area, total paper material cost per order, and layer-wise paper/flute GSM, take-up multiplier, estimated grams, and cost per box.
- Dimension unit selection now triggers recalculation and converts MM/CM/Inch/Feet input dimensions into mm before automatic cutting-size/deckle calculations. Manual cut/deckle overrides remain available.
- Existing paper quality/GSM/rate recipe, flute multipliers, optional printing/lamination/die, waste, labour, profit, GST, save costing, quotation, and print/PDF controls are retained.
- Inspired by general corrugated costing workflows described by public Play Store listings; no proprietary screens/assets were copied.
- Source-level syntax/archive checks only. Calculations and output need verification against the user's plant-specific formulas and actual Android/WebView operation before production use.

BIOMETRIC + SMS / WHATSAPP SHARING UPDATE (2026-10-10)
- Added direct WhatsApp sharing actions for the latest saved invoice and quotation; prefilled message includes company, customer, multi-item summary when available, amount, due date, payment terms and footer.
- Added SMS draft actions for the latest invoice, quotation, and payment/receipt voucher. SMS opens the phone's messaging app with a prefilled draft; the user must press Send. Mobile number is read from the party record; add a valid mobile number first.
- Added sharing shortcuts to Billing, Quotation, Payment, and Reminders sections. WhatsApp/SMS availability depends on installed apps and Android WebView link handling. SMS length and charges depend on carrier; long messages may be split into multiple SMS.
- Added a fingerprint setup action and a native biometric result callback (`window.onBiometricAuthResult(success, message)`). The APK wrapper must expose `Android.authenticateBiometric()` or `Android.enableBiometric()` and call the callback with success/failure after Android BiometricPrompt completes.
- Important: HTML/ZIP alone cannot implement Android's native fingerprint sensor. If the selected converter does not support a native BiometricPrompt bridge, PIN/password remains the working fallback and fingerprint will show a clear support message. Do not treat the fingerprint button as confirmed working until tested on the final APK/device.
- No messages are sent automatically without user action; the user reviews the prepared draft and presses Send.
- Source-level syntax/archive checks only. Actual WhatsApp/SMS handoff and fingerprint sensor tests on the target APK remain required.


SMS HANDOFF RELIABILITY PATCH (2026-10-10)
- SMS sharing now first attempts the Android wrapper's openUrl bridge, then an external WebView window, then the sms: URI navigation.
- If the wrapper blocks SMS intents, the app offers a manual fallback with the recipient and prepared message instead of silently failing.
- SMS messages are drafts only; the user must press Send.
- IMPORTANT: This source does not implement actual OTP delivery/verification. OTP requires a configured SMS gateway/provider and server-side verification (or a supported native service). A local HTML ZIP cannot securely generate and deliver a real OTP by itself.
- The current environment cannot confirm the final APK wrapper's handling of sms: intents or diagnose a converter-specific startup error without the exact error screenshot/log.


ONLINE/OFFLINE MODE UPDATE (2026-10-10)
- Existing ERP records continue to save to local device storage (localStorage), allowing core data entry and reports to work offline in the installed app.
- Added an online/offline connection indicator to the existing Offline Data & Backup section; it listens for browser connectivity changes.
- Internet-dependent features such as GST lookup, real OTP/SMS delivery, cloud sync, and government e-way bill generation still require their respective configured API/provider/backend. This ZIP does not claim cloud synchronization.
- Data is stored on this device. Export a backup regularly; uninstalling/clearing app data may remove locally stored records.
