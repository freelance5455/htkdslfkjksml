# Math Symbols APK

## Tarika 1: Phone/PC se, bina Android Studio (GitHub)
1. Github par naya repo banao aur is poore folder ki files upload karo.
2. Repo me Actions tab -> "Build APK" -> Run workflow.
3. 3-5 minute baad run ke andar Artifacts me `Math-Symbols-APK` download karo.
4. Zip kholo, `app-debug.apk` phone me install karo (Unknown sources allow karna padega).

## Tarika 2: PC par
Chahiye: Node 18+, Java 17, Android Studio (SDK).
```
npm install
npx cap add android
npx cap sync android
cd android && ./gradlew assembleDebug
```
APK: `android/app/build/outputs/apk/debug/app-debug.apk`

## Notes
- App ki file `www/index.html` hai. Badlav karke `npx cap sync android` chalao.
- PNG/PDF download app me Share sheet se khulta hai (Save to Files / WhatsApp etc.).
