# Genius Bharat AI — Vercel Backend

## What this adds
- `api/chat.js` — secure server-side AI endpoint
- Uses the `OPENAI_API_KEY` Vercel Environment Variable
- Does NOT contain an API key in the app files
- Returns `{ "reply": "..." }` for the existing app frontend

## Deploy
1. Upload/push this project to a Git repository and import it into Vercel.
2. In Vercel Project Settings → Environment Variables, add:
   - Name: `OPENAI_API_KEY`
   - Value: your OpenAI API key
3. Redeploy.
4. Your backend endpoint will be:
   `https://YOUR-PROJECT.vercel.app/api/chat`

## Connect the app
In the app's `config.js`, set:
`window.GBA_CONFIG = { API_URL: "https://YOUR-PROJECT.vercel.app/api/chat" };`

Never put the OpenAI API key in `config.js`, HTML, JavaScript frontend code, or the APK.
