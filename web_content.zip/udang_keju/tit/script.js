const $ = id => document.getElementById(id);
const STORAGE_KEY = 'smartMathHistory_v1';
let historyData = loadHistory();
let selectedShape = 'square';
let geometryMode = 'area';

function loadHistory(){try{return JSON.parse(localStorage.getItem(STORAGE_KEY)) || []}catch{return []}}
function saveHistory(){try{localStorage.setItem(STORAGE_KEY,JSON.stringify(historyData))}catch{console.warn('Penyimpanan lokal tidak tersedia.')}}
function fmt(n){if(!Number.isFinite(n))throw Error('Hasil tidak valid atau di luar batas perhitungan.');return Number(n.toPrecision(12)).toLocaleString('id-ID',{maximumFractionDigits:10})}
function read(id,label){const raw=$(id).value.trim().replace(',','.');if(raw==='')throw Error(label+' belum diisi.');const n=Number(raw);if(!Number.isFinite(n))throw Error(label+' harus berupa angka valid.');return n}
function record(type,expression,result){historyData.unshift({id:Date.now()+Math.random(),type,expression,result:fmt(result),time:new Date().toLocaleString('id-ID',{dateStyle:'medium',timeStyle:'short'})});historyData=historyData.slice(0,100);saveHistory();renderHistory()}
function renderHistory(){
  $('historyCount').textContent=historyData.length;
  const list=$('historyList');list.innerHTML='';
  if(!historyData.length){list.innerHTML='<div class="history-empty"><span>◷</span><strong>Belum ada perhitungan</strong><p>Hasil hitunganmu akan tersimpan di sini.</p></div>';return}
  historyData.forEach(item=>{const row=document.createElement('div');row.className='history-item';
    const icon=document.createElement('div');icon.className='history-type';icon.textContent=item.type==='Geometri'?'◇':item.type==='Trigonometri'?'∠':'∑';
    const main=document.createElement('div');main.className='history-main';const title=document.createElement('strong');title.textContent=item.expression;const time=document.createElement('small');time.textContent=item.time+' · '+item.type;main.append(title,time);
    const result=document.createElement('div');result.className='history-result';result.textContent=item.result;
    row.append(icon,main,result);list.append(row);
  });
}
function showOutput(output,placeholder,value,formula,result){$(placeholder).hidden=true;$(output).hidden=false;$(value).textContent=fmt(result);$(formula).textContent=formulaText(formula)}
function formulaText(s){return s}
document.querySelectorAll('.nav-tab').forEach(btn=>btn.addEventListener('click',()=>{document.querySelectorAll('.nav-tab').forEach(b=>b.classList.toggle('active',b===btn));document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active',p.id==='page-'+btn.dataset.page))}));

const operationInfo={
 add:{title:'Penjumlahan',icon:'＋',symbol:'+'},sub:{title:'Pengurangan',icon:'−',symbol:'−'},mul:{title:'Perkalian',icon:'×',symbol:'×'},div:{title:'Pembagian',icon:'÷',symbol:'÷'},pow:{title:'Pangkat',icon:'xʸ',symbol:'^'},mod:{title:'Modulus',icon:'%',symbol:'%'},sqrt:{title:'Akar kuadrat',icon:'√',symbol:'√'},circle:{title:'Luas lingkaran',icon:'○',symbol:'πr²'}
};
let currentOperation='add';
function openArithmeticDetail(op){currentOperation=op;const info=operationInfo[op];$('arithHome').hidden=true;$('standardCalculator').hidden=true;$('arithDetail').hidden=false;$('arithTitle').textContent=info.title;$('arithIndex').textContent='01 / 04';$('detailOperationTitle').textContent=info.title;$('detailOperationIcon').textContent=info.icon;$('numALabel').textContent=op==='circle'?'Jari-jari':'Data 1';$('numA').placeholder=op==='circle'?'Masukkan jari-jari':'Masukkan data 1';$('secondWrap').classList.toggle('hidden',['sqrt','circle'].includes(op));$('numB').value='';$('numA').value='';$('calcError').textContent='';$('calcResult').hidden=true;window.scrollTo({top:0,behavior:'smooth'});}
function showArithmeticHome(){$('arithDetail').hidden=true;$('standardCalculator').hidden=true;$('arithHome').hidden=false;$('arithTitle').textContent='Pilih operasi aritmetika';$('numA').value='';$('numB').value='';window.scrollTo({top:0,behavior:'smooth'});}
document.querySelectorAll('[data-operation]').forEach(btn=>btn.addEventListener('click',()=>openArithmeticDetail(btn.dataset.operation)));
$('backOperations').addEventListener('click',showArithmeticHome);
$('calcBtn').addEventListener('click',()=>{try{$('calcError').textContent='';const op=currentOperation,a=read('numA',op==='circle'?'Jari-jari':'Data 1');let b=0,r,expr;
 if(op==='sqrt'){if(a<0)throw Error('Data tidak boleh negatif untuk akar kuadrat.');r=Math.sqrt(a);expr=`√${fmt(a)}`}
 else if(op==='circle'){if(a<=0)throw Error('Jari-jari harus lebih besar dari nol.');r=Math.PI*a*a;expr=`π × ${fmt(a)}²`}
 else{b=read('numB','Data 2');if(op==='add'){r=a+b;expr=`${fmt(a)} + ${fmt(b)}`}if(op==='sub'){r=a-b;expr=`${fmt(a)} − ${fmt(b)}`}if(op==='mul'){r=a*b;expr=`${fmt(a)} × ${fmt(b)}`}if(op==='div'){if(b===0)throw Error('Pembagian dengan nol tidak diperbolehkan.');r=a/b;expr=`${fmt(a)} ÷ ${fmt(b)}`}if(op==='pow'){r=a**b;expr=`${fmt(a)} ^ ${fmt(b)}`}if(op==='mod'){if(b===0)throw Error('Modulus dengan nol tidak diperbolehkan.');r=a%b;expr=`${fmt(a)} % ${fmt(b)}`}}
 if(!Number.isFinite(r))throw Error('Hasil tidak valid atau di luar batas perhitungan.');$('calcResult').hidden=false;$('calcValue').textContent=fmt(r);$('calcFormula').textContent=expr;record('Aritmetika',expr,r);
 }catch(e){$('calcError').textContent=e.message}});
$('calcClear').addEventListener('click',()=>{$('numA').value='';$('numB').value='';$('calcError').textContent='';$('calcResult').hidden=true});

// Kalkulator standar: pertahankan seluruh ekspresi sampai tombol '=' ditekan.
let stdTokens=[], stdInput='0', stdFresh=false, stdJustEvaluated=false;
function standardFormat(value){
  if(!Number.isFinite(value)) throw Error('Hasil tidak valid.');
  return Number(value.toPrecision(12)).toLocaleString('id-ID',{maximumFractionDigits:10});
}
function standardExpressionText(includeInput=true){
  const parts=stdTokens.slice();
  if(includeInput && stdInput!=='' && (!stdFresh || parts.length===0)) parts.push(stdInput);
  return parts.join(' ');
}
function standardEvaluate(tokens){
  if(!tokens.length || ['+','−','×','÷'].includes(tokens[tokens.length-1])) throw Error('Ekspresi belum lengkap.');
  const values=[], ops=[];
  const precedence=op=>(op==='×'||op==='÷'?2:1);
  const apply=()=>{
    const op=ops.pop(), b=values.pop(), a=values.pop();
    if(a===undefined||b===undefined) throw Error('Ekspresi belum lengkap.');
    let r;
    if(op==='+')r=a+b;
    else if(op==='−')r=a-b;
    else if(op==='×')r=a*b;
    else if(op==='÷'){if(b===0)throw Error('Tidak bisa membagi dengan nol.');r=a/b;}
    if(!Number.isFinite(r))throw Error('Hasil tidak valid.');
    values.push(r);
  };
  tokens.forEach((token,index)=>{
    if(index%2===0){const n=Number(token);if(!Number.isFinite(n))throw Error('Angka tidak valid.');values.push(n);}
    else{
      if(!['+','−','×','÷'].includes(token))throw Error('Operator tidak valid.');
      while(ops.length && precedence(ops[ops.length-1])>=precedence(token))apply();
      ops.push(token);
    }
  });
  while(ops.length)apply();
  if(values.length!==1)throw Error('Ekspresi belum lengkap.');
  return values[0];
}
function renderStandard(){
  $('standardExpression').textContent=stdTokens.length?standardExpressionText(true):' ';
  let display=stdInput||'0';
  if(stdTokens.length){
    try{display=standardFormat(standardEvaluate([...stdTokens, ...(stdFresh?[]:[stdInput])]))}
    catch{display=stdInput||standardTokensLastNumber()||'0';}
  }
  $('standardValue').textContent=display;
}
function standardTokensLastNumber(){return stdTokens.length?stdTokens[stdTokens.length-1]:'0'}
function standardReset(){stdTokens=[];stdInput='0';stdFresh=false;stdJustEvaluated=false;renderStandard()}
$('openStandardCalc').addEventListener('click',()=>{$('arithHome').hidden=true;$('arithDetail').hidden=true;$('standardCalculator').hidden=false;standardReset();window.scrollTo({top:0,behavior:'smooth'})});
$('backStandard').addEventListener('click',showArithmeticHome);
$('standardKeys').addEventListener('click',e=>{
  const btn=e.target.closest('button[data-key]');if(!btn)return;
  const k=btn.dataset.key;
  if(k==='AC'){standardReset();return;}
  if(k==='±'){
    if(stdJustEvaluated){stdInput=String(-Number(stdInput));stdJustEvaluated=false;stdTokens=[];}
    else stdInput=String(-Number(stdInput||'0'));
    renderStandard();return;
  }
  if(k==='%'){
    stdInput=String(Number(stdInput||'0')/100);stdFresh=false;stdJustEvaluated=false;renderStandard();return;
  }
  if('0123456789'.includes(k)){
    if(stdJustEvaluated){stdTokens=[];stdInput=k;stdJustEvaluated=false;stdFresh=false;}
    else if(stdFresh){stdInput=k;stdFresh=false;}
    else stdInput=stdInput==='0'?k:stdInput+k;
    renderStandard();return;
  }
  if(k==='.'){
    if(stdJustEvaluated){stdTokens=[];stdInput='0.';stdJustEvaluated=false;stdFresh=false;}
    else if(stdFresh){stdInput='0.';stdFresh=false;}
    else if(!stdInput.includes('.'))stdInput+='.';
    renderStandard();return;
  }
  if(['+','−','×','÷'].includes(k)){
    if(stdJustEvaluated)stdJustEvaluated=false;
    if(!stdFresh){
      if(stdInput===''||stdInput==='-')return;
      stdTokens.push(stdInput);
    }
    if(stdTokens.length && ['+','−','×','÷'].includes(stdTokens[stdTokens.length-1]))stdTokens[stdTokens.length-1]=k;
    else stdTokens.push(k);
    stdInput='';stdFresh=true;renderStandard();return;
  }
  if(k==='='){
    if(!stdTokens.length||stdFresh||!stdInput)return;
    const expression=standardExpressionText(true);
    try{
      const result=standardEvaluate([...stdTokens,stdInput]);
      stdInput=String(Number(result.toPrecision(12)));
      stdTokens=[];stdFresh=false;stdJustEvaluated=true;
      $('standardExpression').textContent=expression+' =';
      $('standardValue').textContent=standardFormat(result);
      record('Kalkulator HP',expression,result);
    }catch(err){$('standardExpression').textContent=expression;$('standardValue').textContent='undefined';}
  }
});

const shapes={
 square:{name:'Persegi',area:'sisi × sisi',perimeter:'4 × sisi',areaFields:[['s','Sisi']],perimeterFields:[['s','Sisi']]},
 rectangle:{name:'Persegi panjang',area:'panjang × lebar',perimeter:'2 × (panjang + lebar)',areaFields:[['p','Panjang'],['l','Lebar']],perimeterFields:[['p','Panjang'],['l','Lebar']]},
 triangle:{name:'Segitiga',area:'½ × alas × tinggi',perimeter:'sisi A + sisi B + sisi C',areaFields:[['alas','Alas'],['tinggi','Tinggi']],perimeterFields:[['a','Sisi A'],['b','Sisi B'],['c','Sisi C']]},
 circle:{name:'Lingkaran',area:'π × r²',perimeter:'2 × π × r',areaFields:[['r','Jari-jari']],perimeterFields:[['r','Jari-jari']]},
 parallelogram:{name:'Jajar genjang',area:'alas × tinggi',perimeter:'2 × (alas + sisi miring)',areaFields:[['alas','Alas'],['tinggi','Tinggi']],perimeterFields:[['alas','Alas'],['sisi','Sisi miring']]},
 trapezoid:{name:'Trapesium',area:'½ × (a + b) × tinggi',perimeter:'a + b + c + d',areaFields:[['a','Sisi sejajar A'],['b','Sisi sejajar B'],['tinggi','Tinggi']],perimeterFields:[['a','Sisi A'],['b','Sisi B'],['c','Sisi C'],['d','Sisi D']]},
 rhombus:{name:'Belah ketupat',area:'½ × diagonal 1 × diagonal 2',perimeter:'4 × sisi',areaFields:[['d1','Diagonal 1'],['d2','Diagonal 2']],perimeterFields:[['s','Sisi']]},
 kite:{name:'Layang-layang',area:'½ × diagonal 1 × diagonal 2',perimeter:'2 × (a + b)',areaFields:[['d1','Diagonal 1'],['d2','Diagonal 2']],perimeterFields:[['a','Sisi pendek'],['b','Sisi panjang']]}
};
function renderGeo(){const d=shapes[selectedShape],fields=d[geometryMode+'Fields'];$('geoShapeTitle')&&($('geoShapeTitle').textContent=d.name);$('geoFormula').textContent=d[geometryMode];$('geoInputs').innerHTML='';fields.forEach(([key,label])=>{const wrap=document.createElement('div'),lab=document.createElement('label'),input=document.createElement('input');lab.className='field-label';lab.htmlFor='geo_'+key;lab.textContent=label;input.id='geo_'+key;input.type='number';input.step='any';input.placeholder=label;wrap.append(lab,input);$('geoInputs').append(wrap)});$('geoResult').hidden=true;$('geoError').textContent=''}
document.querySelectorAll('.shape-btn').forEach(btn=>btn.addEventListener('click',()=>{
  selectedShape=btn.dataset.shape;
  $('shapeMenu').hidden=true;
  $('geometryDetail').hidden=false;
  renderGeo();
  window.scrollTo({top:0,behavior:'smooth'});
}));
$('backShapes').addEventListener('click',()=>{
  $('geometryDetail').hidden=true;
  $('shapeMenu').hidden=false;
  $('geoResult').hidden=true;
  window.scrollTo({top:0,behavior:'smooth'});
});
document.querySelectorAll('.mode-btn').forEach(btn=>btn.addEventListener('click',()=>{geometryMode=btn.dataset.mode;document.querySelectorAll('.mode-btn').forEach(b=>b.classList.toggle('selected',b===btn));renderGeo()}));
$('geoBtn').addEventListener('click',()=>{try{$('geoError').textContent='';const d=shapes[selectedShape],fields=d[geometryMode+'Fields'],v={};fields.forEach(([key,label])=>{v[key]=read('geo_'+key,label);if(v[key]<=0)throw Error(label+' harus lebih besar dari nol.')});let r;
 switch(selectedShape){
 case'square':r=geometryMode==='area'?v.s**2:4*v.s;break;
 case'rectangle':r=geometryMode==='area'?v.p*v.l:2*(v.p+v.l);break;
 case'triangle':if(geometryMode==='area')r=.5*v.alas*v.tinggi;else{if(v.a+v.b<=v.c||v.a+v.c<=v.b||v.b+v.c<=v.a)throw Error('Ketiga sisi tidak memenuhi syarat segitiga.');r=v.a+v.b+v.c}break;
 case'circle':r=geometryMode==='area'?Math.PI*v.r**2:2*Math.PI*v.r;break;
 case'parallelogram':r=geometryMode==='area'?v.alas*v.tinggi:2*(v.alas+v.sisi);break;
 case'trapezoid':if(geometryMode==='area'){r=.5*(v.a+v.b)*v.tinggi}else{if(v.a+v.b<=Math.abs(v.c-v.d)||Math.abs(v.c-v.d)>=v.a+v.b)throw Error('Ukuran sisi tidak membentuk trapesium yang valid.');r=v.a+v.b+v.c+v.d}break;
 case'rhombus':r=geometryMode==='area'?.5*v.d1*v.d2:4*v.s;break;
 case'kite':r=geometryMode==='area'?.5*v.d1*v.d2:2*(v.a+v.b);break;
 }
 if(!Number.isFinite(r))throw Error('Hasil tidak valid.');$('geoResult').hidden=false;$('geoValue').textContent=fmt(r);$('geoSummary').textContent=d.name+' · '+(geometryMode==='area'?'Luas':'Keliling');record('Geometri',d.name+' — '+(geometryMode==='area'?'Luas':'Keliling'),r);
 }catch(e){$('geoError').textContent=e.message}});
const trigNames={sin:'Sinus',cos:'Cosinus',tan:'Tangen',csc:'Cosecan',sec:'Secan',cot:'Cotangen'};
const trigDescriptions={
 sin:'Sinus adalah perbandingan sisi depan terhadap sisi miring pada segitiga siku-siku.',
 cos:'Cosinus adalah perbandingan sisi samping terhadap sisi miring pada segitiga siku-siku.',
 tan:'Tangen adalah perbandingan sisi depan terhadap sisi samping pada segitiga siku-siku.',
 csc:'Cosecan merupakan kebalikan dari sinus.',sec:'Secan merupakan kebalikan dari cosinus.',cot:'Cotangen merupakan kebalikan dari tangen.'
};
function trigValue(fn,angle){
 const rad=angle*Math.PI/180,s=Math.sin(rad),c=Math.cos(rad),eps=1e-10;
 let value;
 if(fn==='sin')value=s; if(fn==='cos')value=c;
 if(fn==='tan'){if(Math.abs(c)<eps)throw Error('Tangen tidak terdefinisi pada sudut ini.');value=s/c;}
 if(fn==='csc'){if(Math.abs(s)<eps)throw Error('Cosecan tidak terdefinisi karena sinus bernilai 0.');value=1/s;}
 if(fn==='sec'){if(Math.abs(c)<eps)throw Error('Secan tidak terdefinisi karena cosinus bernilai 0.');value=1/c;}
 if(fn==='cot'){if(Math.abs(s)<eps)throw Error('Cotangen tidak terdefinisi karena sinus bernilai 0.');value=c/s;}
 return Math.abs(value)<eps?0:value;
}
function trigHeader(title,desc){return `<h3>${title}</h3><p class="trig-description">${desc}</p>`}
function trigResult(value,label,formula=''){return `<div class="trig-tool-result"><small>${label||'HASIL PERHITUNGAN'}</small><strong>${value}</strong>${formula?`<p>${formula}</p>`:''}</div>`}
function openTrigTool(tool){
 $('trigHome').hidden=true;$('trigDetail').hidden=false;$('trigToolContent').innerHTML='';
 const root=$('trigToolContent');
 if(trigNames[tool]){
  root.innerHTML=trigHeader(`${trigNames[tool]} (${tool})`,trigDescriptions[tool])+`<label class="field-label" for="trigAngleInput">Masukkan sudut</label><div class="angle-input"><input id="trigAngleInput" type="number" step="any" placeholder="Contoh: 45"><span>DERAJAT °</span></div><button class="primary-btn full" id="trigCalculateBtn">Hitung ${trigNames[tool].toLowerCase()} <span>↗</span></button><p class="error" id="trigToolError" role="alert"></p><div id="trigFunctionResult"></div>`;
  $('trigCalculateBtn').addEventListener('click',()=>{try{const a=Number($('trigAngleInput').value);if($('trigAngleInput').value.trim()===''||!Number.isFinite(a))throw Error('Masukkan sudut yang valid.');const r=trigValue(tool,a),v=fmt(r),expr=`${tool}(${fmt(a)}°)`;$('trigFunctionResult').innerHTML=trigResult(v,'HASIL '+trigNames[tool].toUpperCase(),expr);record('Trigonometri',expr,r);$('trigToolError').textContent=''}catch(e){$('trigToolError').textContent=e.message;$('trigFunctionResult').innerHTML=''}});
 }
 if(tool==='unit'){
  root.innerHTML=trigHeader('Lingkaran satuan','Jelajahi hubungan sudut dengan koordinat x (cos θ) dan y (sin θ).')+`<label class="field-label" for="unitAngle">Sudut: <strong id="unitAngleLabel">45°</strong></label><input id="unitAngle" type="range" min="0" max="360" value="45"><div class="unit-circle-wrap"><svg class="unit-circle-svg" viewBox="0 0 260 260" role="img" aria-label="Lingkaran satuan"><circle cx="130" cy="130" r="95" fill="none" stroke="#77647f" stroke-width="1.5"/><line x1="20" y1="130" x2="240" y2="130" stroke="#5c4c66"/><line x1="130" y1="20" x2="130" y2="240" stroke="#5c4c66"/><line id="unitRadius" x1="130" y1="130" x2="197" y2="63" stroke="#f39ac2" stroke-width="3"/><circle id="unitPoint" cx="197" cy="63" r="6" fill="#a5e5d2"/><text x="242" y="145" fill="#a5e5d2" font-size="10">x</text><text x="139" y="17" fill="#a5e5d2" font-size="10">y</text><text x="136" y="145" fill="#9e91a9" font-size="9">0</text></svg><div class="unit-circle-info" id="unitCircleInfo"></div></div><button class="primary-btn full" id="unitRecordBtn">Simpan nilai ke riwayat</button>`;
  const update=()=>{const a=Number($('unitAngle').value),r=a*Math.PI/180,x=Math.cos(r),y=Math.sin(r),px=130+95*x,py=130-95*y;$('unitAngleLabel').textContent=a+'°';$('unitRadius').setAttribute('x2',px);$('unitRadius').setAttribute('y2',py);$('unitPoint').setAttribute('cx',px);$('unitPoint').setAttribute('cy',py);$('unitCircleInfo').innerHTML=`<strong>cos ${a}°</strong> = ${fmt(x)}<br><strong>sin ${a}°</strong> = ${fmt(y)}<br><strong>Koordinat</strong> = (${fmt(x)}, ${fmt(y)})`;};
  $('unitAngle').addEventListener('input',update);update();$('unitRecordBtn').addEventListener('click',()=>{const a=Number($('unitAngle').value),r=Math.cos(a*Math.PI/180);record('Trigonometri',`Lingkaran satuan ${a}° · cos`,r)});
 }
 if(tool==='identity'){
  root.innerHTML=trigHeader('Identitas trigonometri','Identitas adalah persamaan yang benar untuk semua sudut pada domainnya.')+`<div class="trig-formula-list"><div class="trig-formula"><strong>Identitas Pythagoras</strong><span>sin² θ + cos² θ = 1</span></div><div class="trig-formula"><strong>Identitas tangen</strong><span>tan θ = sin θ / cos θ</span></div><div class="trig-formula"><strong>Identitas kebalikan</strong><span>csc θ = 1 / sin θ<br>sec θ = 1 / cos θ<br>cot θ = 1 / tan θ</span></div><div class="trig-formula"><strong>Identitas Pythagoras lainnya</strong><span>1 + tan² θ = sec² θ<br>1 + cot² θ = csc² θ</span></div></div><div class="tip-strip"><span>✦</span><p>Identitas membantu menyederhanakan bentuk aljabar trigonometri dan membuktikan persamaan.</p></div>`;
 }
 if(tool==='graph'){
  root.innerHTML=trigHeader('Grafik trigonometri','Bandingkan bentuk grafik sinus, cosinus, dan tangen pada rentang −360° hingga 360°.')+`<div class="graph-legend"><span>Sinus</span><span>Cosinus</span><span>Tangen (dipotong di ±2)</span></div><div class="trig-canvas-wrap"><canvas id="trigGraphCanvas" width="760" height="280"></canvas></div><p class="trig-description">Sumbu mendatar menunjukkan sudut dalam derajat. Grafik tangen dibatasi agar asimtotnya tidak memenuhi tampilan.</p>`;
  drawTrigGraph();
 }
 if(tool==='convert'){
  root.innerHTML=trigHeader('Konversi derajat dan radian','Ubah ukuran sudut dari derajat ke radian atau sebaliknya.')+`<label class="field-label" for="convertDirection">Jenis konversi</label><select class="trig-select" id="convertDirection"><option value="deg">Derajat → Radian</option><option value="rad">Radian → Derajat</option></select><label class="field-label" for="convertInput" id="convertInputLabel">Sudut dalam derajat (°)</label><input id="convertInput" type="number" step="any" placeholder="Masukkan nilai sudut"><button class="primary-btn full" id="convertBtn">Konversi <span>↗</span></button><div id="convertResult"></div>`;
  $('convertDirection').addEventListener('change',()=>{$('convertInputLabel').textContent=$('convertDirection').value==='deg'?'Sudut dalam derajat (°)':'Sudut dalam radian';$('convertInput').value='';$('convertResult').innerHTML=''});
  $('convertBtn').addEventListener('click',()=>{const raw=$('convertInput').value;if(raw.trim()===''){ $('convertResult').innerHTML=trigResult('Masukkan nilai sudut','PERHATIAN');return;}const n=Number(raw),deg=$('convertDirection').value==='deg',r=deg?n*Math.PI/180:n*180/Math.PI,out=fmt(r),unit=deg?'radian':'derajat';$('convertResult').innerHTML=trigResult(out+' '+(deg?'rad':'°'),'HASIL KONVERSI',`${fmt(n)} ${deg?'°':'rad'} = ${out} ${unit}`);record('Trigonometri',`Konversi ${fmt(n)} ${deg?'°':'rad'} ke ${unit}`,r)});
 }
 if(tool==='inverse'){
  root.innerHTML=trigHeader('Invers trigonometri','Cari besar sudut dari nilai sinus, cosinus, atau tangen yang diketahui.')+`<label class="field-label" for="inverseFunction">Pilih fungsi invers</label><select class="trig-select" id="inverseFunction"><option value="asin">arcsin (sin⁻¹)</option><option value="acos">arccos (cos⁻¹)</option><option value="atan">arctan (tan⁻¹)</option></select><label class="field-label" for="inverseInput">Masukkan nilai</label><input id="inverseInput" type="number" step="any" placeholder="Contoh: 0,5"><button class="primary-btn full" id="inverseBtn">Cari sudut <span>↗</span></button><p class="error" id="inverseError" role="alert"></p><div id="inverseResult"></div>`;
  $('inverseBtn').addEventListener('click',()=>{try{const raw=$('inverseInput').value;if(raw.trim()==='')throw Error('Masukkan nilai terlebih dahulu.');const n=Number(raw),fn=$('inverseFunction').value;if(!Number.isFinite(n))throw Error('Nilai harus berupa angka.');if(fn!=='atan'&&(n< -1||n>1))throw Error('Untuk arcsin dan arccos, nilai harus berada antara −1 dan 1.');const rad=fn==='asin'?Math.asin(n):fn==='acos'?Math.acos(n):Math.atan(n),deg=rad*180/Math.PI,expr=`${fn}(${fmt(n)})`;$('inverseResult').innerHTML=trigResult(fmt(deg)+'°','HASIL SUDUT',`${fmt(deg)}° · ${fmt(rad)} radian`);$('inverseError').textContent='';record('Trigonometri',expr,deg)}catch(e){$('inverseError').textContent=e.message;$('inverseResult').innerHTML=''}});
 }
 window.scrollTo({top:0,behavior:'smooth'});
}
function drawTrigGraph(){
 const canvas=$('trigGraphCanvas');if(!canvas)return;const ctx=canvas.getContext('2d'),w=canvas.width,h=canvas.height,pad=35,xMin=-360,xMax=360,yMin=-2.5,yMax=2.5;
 const X=x=>pad+(x-xMin)/(xMax-xMin)*(w-2*pad),Y=y=>pad+(yMax-y)/(yMax-yMin)*(h-2*pad);
 ctx.clearRect(0,0,w,h);ctx.strokeStyle='#493b53';ctx.lineWidth=1;
 for(let y=-2;y<=2;y++){ctx.beginPath();ctx.moveTo(pad,Y(y));ctx.lineTo(w-pad,Y(y));ctx.stroke()}
 for(let x=-360;x<=360;x+=90){ctx.beginPath();ctx.moveTo(X(x),pad);ctx.lineTo(X(x),h-pad);ctx.stroke();ctx.fillStyle='#a99bb2';ctx.font='11px Arial';ctx.textAlign='center';ctx.fillText(x+'°',X(x),h-10)}
 const series=[{fn:x=>Math.sin(x*Math.PI/180),color:'#f39ac2'},{fn:x=>Math.cos(x*Math.PI/180),color:'#a5e5d2'},{fn:x=>Math.tan(x*Math.PI/180),color:'#b9a3ff',tan:true}];
 series.forEach(s=>{ctx.strokeStyle=s.color;ctx.lineWidth=2;ctx.beginPath();let drawing=false,last=null;for(let x=xMin;x<=xMax;x+=2){let y=s.fn(x);if(s.tan&&(Math.abs(y)>2.4||!Number.isFinite(y))){drawing=false;last=null;continue}if(Math.abs(y)>2.5){drawing=false;last=null;continue}if(last&&Math.abs(y-last)>1.2){drawing=false}if(!drawing){ctx.moveTo(X(x),Y(y));drawing=true}else ctx.lineTo(X(x),Y(y));last=y}ctx.stroke()});
 ctx.fillStyle='#9e91a9';ctx.font='11px Arial';ctx.textAlign='right';ctx.fillText('0',pad-8,Y(0)+4);
}
$('backTrig').addEventListener('click',()=>{$('trigDetail').hidden=true;$('trigHome').hidden=false;window.scrollTo({top:0,behavior:'smooth'})});
document.querySelectorAll('[data-trig-tool]').forEach(btn=>btn.addEventListener('click',()=>openTrigTool(btn.dataset.trigTool)));

$('clearHistory').addEventListener('click',()=>{if(!historyData.length)return;if(confirm('Hapus seluruh riwayat perhitungan?')){historyData=[];saveHistory();renderHistory()}});
renderGeo();renderHistory();renderStandard();
