UDANG KEJU — PERSONAL MATH STUDIO

Isi folder:
- index.html : halaman utama aplikasi
- style.css  : tampilan dan desain
- script.js  : logika kalkulator dan fitur matematika
- assets/udang-keju.jpg : ikon/foto aplikasi

Fitur:
1. Aritmetika: operasi dasar, operasi lanjutan, dan kalkulator standar.
2. Geometri: luas dan keliling 8 bangun datar.
3. Trigonometri: sin, cos, tan, csc, sec, cot; lingkaran satuan interaktif; identitas; grafik; konversi derajat-radian; dan invers trigonometri.
4. Riwayat: menyimpan hasil perhitungan di penyimpanan lokal browser.

Cara menjalankan:
Ekstrak folder, lalu buka index.html menggunakan browser. Untuk penggunaan terbaik, buka melalui server lokal/editor HTML yang biasa digunakan.
