# Topper Manoj — starter web app

This is a working front-end prototype for the Topper Manoj Class 10 Telangana study companion.

## Features in this starter
- Responsive home dashboard and six subject cards
- Starter chapter lists with local completion tracking
- Personal notes saved in browser localStorage
- JSON export backup
- Simple study-task checklist and editable exam countdown
- Three sample quiz questions with answer feedback
- Light/dark theme
- PWA manifest and service worker for caching when served from a local web server/HTTPS

## Run it
For a quick preview, open `index.html` in a browser. For service-worker/offline-install support, serve this folder through localhost or HTTPS, for example:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000` in a browser on the same device.

## Important limitations
- This is a prototype, not a completed official syllabus app.
- Chapter lists and quiz questions are starter/demo content. Verify against the current official Telangana SCERT textbooks before exam use.
- It does not include full textbook PDFs, copyrighted textbook reproductions, official past papers, cloud AI, or an offline AI model.
- No Android APK is built by this project. An Android wrapper/build and device testing are separate steps.
- Local browser data is not encrypted or synchronised. Export a backup before clearing browser data.
