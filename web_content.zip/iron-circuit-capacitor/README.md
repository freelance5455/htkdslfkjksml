# Iron Circuit Wrestling — Android app project

This is a [Capacitor](https://capacitorjs.com/) project that wraps the Iron Circuit
Wrestling web game (`www/index.html`) in a native Android shell, so it builds to a
real installable `.apk` (or `.aab` for the Play Store).

I can't compile or sign the app from inside this chat — that step needs the Android
SDK and Gradle running on your own computer. Everything below is what to run there.

## What you need installed first

- [Node.js](https://nodejs.org/) (LTS version)
- [Android Studio](https://developer.android.com/studio) (this also installs the
  Android SDK you need)

## 1. Install dependencies

Unzip this project, open a terminal in its folder, then run:

```bash
npm install
```

## 2. Add the Android platform

This downloads and scaffolds the native Android project (needs internet access):

```bash
npx cap add android
```

## 3. Generate app icons and splash screen (optional but recommended)

Source images are already included in `resources/icon.png` (1024×1024) and
`resources/splash.png` (2732×2732). Generate the full Android icon/splash set from
them with:

```bash
npx capacitor-assets generate --android
```

## 4. Sync the web app into the native project

Run this any time you change `www/index.html`:

```bash
npx cap sync android
```

## 5. Open in Android Studio and build

```bash
npx cap open android
```

This opens the native project in Android Studio. From there:

- Click the green **Run** button to install it on a connected device or emulator, or
- Use **Build → Generate Signed Bundle / APK** to produce a release `.apk` or `.aab`
  you can share or upload to the Play Store (you'll need to create a signing key —
  Android Studio walks you through this the first time).

## Project structure

```
iron-circuit-capacitor/
├── capacitor.config.json   — app id, name, and web folder
├── package.json            — Capacitor dependencies
├── resources/
│   ├── icon.png            — 1024×1024 source app icon
│   └── splash.png          — 2732×2732 source splash screen
└── www/
    └── index.html          — the game itself (self-contained, no build step needed)
```

## Updating the game later

Just replace `www/index.html` with a newer version of the game, then re-run:

```bash
npx cap sync android
npx cap open android
```
