"use strict";

const jobs = [
  { name: "الطبيب", emoji: "🧑‍⚕️", desc: "يعالج المرضى ويساعدهم على استعادة صحتهم.", place: "المستشفى" },
  { name: "المعلّم", emoji: "🧑‍🏫", desc: "يعلّم الأطفال القراءة والكتابة والعلوم.", place: "المدرسة" },
  { name: "رجل الإطفاء", emoji: "🧑‍🚒", desc: "يطفئ الحرائق ويساعد الناس وقت الخطر.", place: "محطة الإطفاء" },
  { name: "الشرطي", emoji: "👮", desc: "يحافظ على الأمن ويساعد الناس.", place: "مركز الشرطة" },
  { name: "الطباخ", emoji: "🧑‍🍳", desc: "يحضّر أطعمة لذيذة وصحية.", place: "المطبخ" },
  { name: "الفلاح", emoji: "🧑‍🌾", desc: "يزرع الخضروات والفواكه ويعتني بالنباتات.", place: "المزرعة" },
  { name: "الطيّار", emoji: "🧑‍✈️", desc: "يقود الطائرة وينقل المسافرين.", place: "المطار" },
  { name: "البنّاء", emoji: "👷", desc: "يبني البيوت والمباني.", place: "ورشة البناء" },
  { name: "الخبّاز", emoji: "🥖", desc: "يخبز الخبز والحلويات.", place: "المخبزة" },
  { name: "رائد الفضاء", emoji: "🧑‍🚀", desc: "يسافر إلى الفضاء لاستكشافه.", place: "الفضاء" }
];

let selectedJob = jobs[0];
let correctCount = 0;
let questionIndex = 0;
let answered = false;

const byId = (id) => document.getElementById(id);

function speak(text) {
  if (!("speechSynthesis" in window) || !("SpeechSynthesisUtterance" in window)) {
    byId("jobFeedback").textContent = "ميزة النطق غير متاحة في هذا المتصفح أو الجهاز.";
    return;
  }
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = "ar-SA";
  utterance.rate = 0.82;
  utterance.pitch = 1.12;
  window.speechSynthesis.speak(utterance);
}

function playTone(frequency = 660, duration = 0.18) {
  try {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (!AudioContextClass) return;
    const context = new AudioContextClass();
    const oscillator = context.createOscillator();
    const gain = context.createGain();
    oscillator.type = "sine";
    oscillator.frequency.value = frequency;
    gain.gain.setValueAtTime(0.12, context.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, context.currentTime + duration);
    oscillator.connect(gain);
    gain.connect(context.destination);
    oscillator.start();
    oscillator.stop(context.currentTime + duration);
    oscillator.onended = () => context.close();
  } catch (_) {
    // الصوت اختياري؛ يستمر التطبيق بالعمل إذا لم يدعمه الجهاز.
  }
}

function renderJobs() {
  const host = byId("jobs");
  host.replaceChildren();

  jobs.forEach((job) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "job-card";
    button.setAttribute("aria-label", `تعلّم مهنة ${job.name}`);

    const emoji = document.createElement("span");
    emoji.className = "job-emoji";
    emoji.textContent = job.emoji;

    const name = document.createElement("span");
    name.className = "job-name";
    name.textContent = job.name;

    const description = document.createElement("p");
    description.className = "job-desc";
    description.textContent = job.desc;

    button.append(emoji, name, description);
    button.addEventListener("click", () => {
      selectedJob = job;
      document.querySelectorAll(".job-card").forEach((card) => card.classList.remove("selected"));
      button.classList.add("selected");
      byId("jobFeedback").textContent = `${job.emoji} أنا ${job.name}. ${job.desc}`;
      speak(`${job.name}. ${job.desc}`);
      playTone(740, 0.12);
    });
    host.appendChild(button);
  });

  host.firstElementChild?.classList.add("selected");
}

function showPage(pageName) {
  ["learn", "quiz", "stars"].forEach((name) => {
    byId(`${name}Page`).classList.toggle("hidden", name !== pageName);
  });
  if (pageName === "stars") updateStars();
}

function makeQuestion() {
  answered = false;
  const correctJob = jobs[questionIndex % jobs.length];
  byId("quizQuestion").textContent = `من يعمل في ${correctJob.place}؟`;
  byId("quizFeedback").textContent = "";

  const wrongJobs = jobs
    .filter((job) => job.name !== correctJob.name)
    .sort(() => Math.random() - 0.5)
    .slice(0, 3);
  const choices = [correctJob, ...wrongJobs].sort(() => Math.random() - 0.5);
  const host = byId("quizOptions");
  host.replaceChildren();

  choices.forEach((choice) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "quiz-option";
    button.textContent = `${choice.emoji} ${choice.name}`;
    button.addEventListener("click", () => {
      if (answered) return;
      answered = true;

      if (choice.name === correctJob.name) {
        correctCount += 1;
        byId("quizFeedback").textContent = "رائع! إجابة صحيحة! ⭐";
        playTone(880, 0.2);
      } else {
        byId("quizFeedback").textContent = `محاولة جميلة! الإجابة الصحيحة هي ${correctJob.name}.`;
        playTone(240, 0.25);
      }

      byId("score").textContent = `الإجابات الصحيحة: ${correctCount}`;
      updateStars();
      host.querySelectorAll("button").forEach((option) => { option.disabled = true; });
    });
    host.appendChild(button);
  });
}

function updateStars() {
  const starCount = Math.min(5, correctCount);
  byId("stars").textContent = "★".repeat(starCount) + "☆".repeat(5 - starCount);
}

document.querySelectorAll(".nav-btn").forEach((button) => {
  button.addEventListener("click", () => showPage(button.dataset.page));
});

byId("speakBtn").addEventListener("click", () => {
  speak(`${selectedJob.name}. ${selectedJob.desc}`);
});

byId("soundBtn").addEventListener("click", () => {
  playTone(660, 0.14);
  window.setTimeout(() => playTone(880, 0.18), 150);
  byId("jobFeedback").textContent = "أحسنت! أنت تتعلّم بشكل رائع! ⭐";
});

byId("nextQuestion").addEventListener("click", () => {
  questionIndex += 1;
  makeQuestion();
});

byId("backToLearn").addEventListener("click", () => showPage("learn"));

renderJobs();
makeQuestion();
