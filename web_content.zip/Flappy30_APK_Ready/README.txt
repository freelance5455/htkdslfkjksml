FLAPPY 30 - APK READY ANDROID STUDIO PROJECT

This is an Android Studio project containing the working Flappy 30 HTML game.

Package:
com.nostalgia.flappy30

App name:
Flappy 30

How to build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Select Build > Build APK(s).
4. The APK will be created under:
   app/build/outputs/apk/debug/

The game is bundled locally in:
app/src/main/assets/index.html

Internet permission is included because the current HTML may use remote web content.
