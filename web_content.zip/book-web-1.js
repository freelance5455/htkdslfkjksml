/* JOSTECH — CHAPITRE COMPLET FORMAT LIVRE : WEB-1-1-1 */
registerLessonDetail(3, 1, "web-1-1-1", {
  title: "Leçon 1 : Architecture du Web, URL et HTML5 Sémantique",
  duration: "45 min (Manuel universitaire complet)",
  objectives: [
    "Distinguer Internet (infrastructure réseau) du World Wide Web (service applicatif).",
    "Tracer le parcours d'une requête Web (DNS → TCP/TLS → HTTP → HTML/DOM).",
    "Décomposer techniquement chaque segment d'une URL.",
    "Construire des documents HTML5 sémantiques, accessibles et optimisés SEO."
  ],
  prerequisites: ["Notions de fichiers et d'arborescence informatique."],
  sections: [
    {
      type: "theory",
      title: "1. Internet vs Web : que se passe-t-il quand vous ouvrez un site ?",
      text: "Internet est le réseau mondial physique de câbles, fibres optiques, routeurs et antennes 4G/5G qui transportent des paquets IP. Le World Wide Web (inventé en 1989 au CERN par Tim Berners-Lee) est un service circulant SUR Internet, au même titre que les e-mails.\n\nQuand vous ouvrez un site sur votre téléphone, quatre étapes s'enchaînent en quelques millisecondes :",
      bullets: [
        "1) Résolution DNS : l'annuaire DNS traduit le nom humain (jostech.edu) en adresse IP du serveur.",
        "2) Connexion TCP/TLS : établissement d'un tunnel sécurisé chiffré (HTTPS).",
        "3) Requête/Réponse HTTP : le navigateur demande « GET /index.html » et reçoit le code HTML.",
        "4) Rendu (Parsing) : le navigateur bâtit l'arbre DOM à l'écran puis charge CSS et JS."
      ]
    },
    {
      type: "definition",
      term: "Anatomie complète d'une URL",
      text: "Une URL (Uniform Resource Locator) identifie une ressource unique sur le Web. Exemple : https://jostech.edu:443/cours/web?niveau=1#chapitre2\n• https:// → Protocole chiffré.\n• jostech.edu → Nom de domaine (traduit en IP par le DNS).\n• :443 → Port réseau (443 pour HTTPS, 80 pour HTTP).\n• /cours/web → Chemin de la ressource sur le serveur.\n• ?niveau=1 → Paramètres de requête (Query String).\n• #chapitre2 → Ancre interne pointant vers une section de la page."
    },
    {
      type: "theory",
      title: "2. HTML5 : pourquoi la sémantique est-elle exigée ?",
      text: "HTML (HyperText Markup Language) est un langage de balisage structurel. Empiler des balises neutres <div> partout (« divitis ») rend la page aveugle aux outils d'analyse. Utiliser des balises sémantiques apporte trois bénéfices majeurs : Accessibilité (lecteurs d'écran pour malvoyants), Référencement SEO (Google comprend les titres <h1> et les <article>), et Maintenabilité du code."
    },
    {
      type: "table",
      title: "3. Balises sémantiques majeures de HTML5",
      headers: ["Balise HTML5", "Rôle structurel précis"],
      rows: [
        ["<header>", "En-tête d'une page ou section (logo, titre, recherche)."],
        ["<nav>", "Liens de navigation principaux du site."],
        ["<main>", "Contenu principal et unique de la page."],
        ["<article>", "Contenu autonome et réutilisable (ex: une leçon JOSTECH)."],
        ["<section>", "Regroupement thématique possédant son propre titre."],
        ["<aside>", "Contenu complémentaire (encadré, glossaire)."],
        ["<footer>", "Pied de page (mentions légales, copyright, auteur)."]
      ]
    },
    {
      type: "code",
      lang: "HTML5 — Page universitaire sémantique et accessible",
      code: [
        "<!DOCTYPE html>",
        "<html lang='fr'>",
        "<head>",
        "  <meta charset='UTF-8'>",
        "  <meta name='viewport' content='width=device-width, initial-scale=1.0'>",
        "  <title>JOSTECH — Inscription Cours</title>",
        "</head>",
        "<body>",
        "  <header>",
        "    <h1>JOSTECH Université Numérique</h1>",
        "    <nav aria-label='Menu principal'><a href='#cours'>Cours</a></nav>",
        "  </header>",
        "  <main>",
        "    <article id='cours'>",
        "      <h2>Introduction au Web</h2>",
        "      <p>Apprendre, comprendre, innover.</p>",
        "    </article>",
        "    <section>",
        "      <h2>Inscription</h2>",
        "      <form>",
        "        <label for='email-etu'>E-mail :</label>",
        "        <input id='email-etu' type='email' required placeholder='nom@jostech.edu'>",
        "        <button type='submit'>Valider</button>",
        "      </form>",
        "    </section>",
        "  </main>",
        "  <footer><p>© JOSTECH — Tous droits réservés</p></footer>",
        "</body>",
        "</html>"
      ].join("\n")
    },
    {
      type: "warning",
      title: "Pièges fréquents à éviter en HTML5",
      text: "1) Oublier <meta name='viewport' content='width=device-width, initial-scale=1.0'> : sans cela, le mobile affiche la page minuscule.\n2) Sauter des niveaux de titres (passer de <h1> à <h4>) : gardez h1 → h2 → h3, réglez la taille en CSS.\n3) Oublier l'attribut alt sur les images (<img src='...' alt='Schéma'>).\n4) Oublier de lier <label for='id'> à <input id='id'>."
    }
  ],
  exercises: [
    {
      title: "Exercice 1 — Décomposition d'URL et DNS",
      question: "Analysez : https://api.jostech.org/v1/examens?discipline=2#reglement\n1) Quel service traduit « api.jostech.org » en IP ?\n2) Que représentent « ?discipline=2 » et « #reglement » ?",
      solution: "1) Le DNS (Domain Name System).\n2) « ?discipline=2 » = paramètre de requête envoyé au serveur ; « #reglement » = ancre locale de la page."
    },
    {
      title: "Exercice 2 — Corriger une page non sémantique",
      question: "Corrigez ce code amateur :\n<div class='haut'><div class='gros-titre'>Site</div></div>\n<div class='contenu'><img src='logo.png'><div class='petit-titre'>Chapitre 1</div></div>",
      solution: "1) <div class='haut'> → <header>\n2) <div class='gros-titre'> → <h1>\n3) <div class='contenu'> → <main> et <div class='petit-titre'> → <h2>\n4) Ajouter alt='Logo officiel' dans <img>."
    },
    {
      title: "Exercice 3 — Formulaire accessible",
      question: "Écrivez un champ mot de passe obligatoire de 8 caractères minimum avec un label lié.",
      solution: "<form>\n  <label for='mdp'>Mot de passe :</label>\n  <input id='mdp' type='password' minlength='8' required>\n  <button type='submit'>Valider</button>\n</form>"
    }
  ],
  summary: "Le Web circule sur Internet via le DNS et HTTPS. En HTML5, les balises sémantiques (<header>, <nav>, <main>, <article>, <footer>), l'ordre des titres et l'attribut alt rendent vos sites accessibles, rapides et bien référencés.",
  references: [
    "W3C / WHATWG — HTML Living Standard Specification.",
    "MDN Web Docs — Introduction à HTML5 et à l'accessibilité."
  ]
});