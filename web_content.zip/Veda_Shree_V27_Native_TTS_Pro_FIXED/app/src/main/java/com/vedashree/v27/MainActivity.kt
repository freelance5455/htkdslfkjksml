package com.vedashree.v27

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var web: WebView
    private lateinit var tts: TextToSpeech
    @Volatile private var ready = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/web/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(
                    view: WebView,
                    request: android.webkit.WebResourceRequest
                ): android.webkit.WebResourceResponse? {
                    return assetLoader.shouldInterceptRequest(request.url)
                }

                @Suppress("DEPRECATION")
                override fun shouldInterceptRequest(
                    view: WebView,
                    url: String
                ): android.webkit.WebResourceResponse? {
                    return assetLoader.shouldInterceptRequest(android.net.Uri.parse(url))
                }
            }
            addJavascriptInterface(NativeTtsBridge(), "AndroidTTS")
            loadUrl("https://appassets.androidplatform.net/web/index.html")
        }
        setContentView(web)
        tts = TextToSpeech(this, this)
    }

    override fun onInit(status: Int) {
        ready = status == TextToSpeech.SUCCESS
        runOnUiThread { web.evaluateJavascript("window.onNativeTTSReady && window.onNativeTTSReady();", null) }
    }

    private fun localeFor(code: String): Locale =
        if (code.lowercase().startsWith("hi")) Locale("hi", "IN") else Locale("mr", "IN")

    private fun chooseVoice(locale: Locale): Voice? {
        if (!ready) return null
        val voices = tts.voices ?: return null
        val candidates = voices.filter {
            it.locale.language == locale.language &&
                it.locale.country.equals(locale.country, true) &&
                !it.isNetworkConnectionRequired
        }
        if (candidates.isEmpty()) return null
        return candidates.firstOrNull { v ->
            val s = (v.name + " " + v.features.joinToString(" ")).lowercase()
            Regex("\\b(male|man|masculine|purush|पुरुष)\\b").containsMatchIn(s)
        } ?: candidates.sortedByDescending { it.quality }.firstOrNull()
    }

    inner class NativeTtsBridge {
        @JavascriptInterface
        fun speak(text: String?, language: String?) {
            if (!ready || text.isNullOrBlank()) return
            val loc = localeFor(language ?: "mr-IN")
            val result = tts.setLanguage(loc)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) return
            chooseVoice(loc)?.let { tts.voice = it }
            val clean = text.replace(Regex("<[^>]*>"), " ")
                .replace(Regex("\\s+"), " ").trim()
            tts.stop()
            tts.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "VEDA_V27")
        }

        @JavascriptInterface fun stop() { if (ready) tts.stop() }

        @JavascriptInterface
        fun status(language: String?): String {
            if (!ready) return "TTS_NOT_READY"
            return chooseVoice(localeFor(language ?: "mr-IN"))?.name ?: "VOICE_NOT_FOUND"
        }

        @JavascriptInterface
        fun openTtsSettings() {
            try { startActivity(Intent("com.android.settings.TTS_SETTINGS")) }
            catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) tts.shutdown()
        web.destroy()
        super.onDestroy()
    }
}
