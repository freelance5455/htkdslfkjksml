# Veda Shree V27 Native TTS Pro

Marathi-first Veda Shree Android project with Native Android Text-to-Speech bridge.

## Build

### Android Studio
Open this folder as a Gradle project. The project uses Gradle 8.10.2.

### Command line
Linux/macOS:
`./gradlew assembleDebug`

Windows:
`gradlew.bat assembleDebug`

The included bootstrap wrapper downloads Gradle 8.10.2 automatically if it is not already available.

APK output:
`app/build/outputs/apk/debug/app-debug.apk`


## APK WebView fix
The web application is packaged at `app/src/main/assets/web/index.html` and loaded through AndroidX `WebViewAssetLoader` at `https://appassets.androidplatform.net/web/index.html`. This fixes the previous local WebView asset path failure.
