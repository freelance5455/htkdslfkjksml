// Function to calculate time remaining until October 2nd
function getCountdownText() {
  const now = new Date();
  const currentYear = now.getFullYear();

  let targetDate = new Date(currentYear, 9, 2, 0, 0, 0);

  if (now >= targetDate) {
    targetDate = new Date(currentYear + 1, 9, 2, 0, 0, 0);
  }

  const diff = targetDate - now;

  const days = String(Math.floor(diff / (1000 * 60 * 60 * 24))).padStart(2, '0');
  const hours = String(Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))).padStart(2, '0');
  const minutes = String(Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))).padStart(2, '0');
  const seconds = String(Math.floor((diff % (1000 * 60)) / 1000)).padStart(2, '0');

  return `${days}:${hours}:${minutes}:${seconds}`;
}

const button = document.getElementById('notifyBtn');

button.addEventListener('click', async () => {
  if (!('Notification' in window) || !('serviceWorker' in navigator)) {
    alert('Browser does not support push notifications.');
    return;
  }

  const permission = await Notification.requestPermission();

  if (permission === 'granted') {
    try {
      // Register with a relative scope/path
      await navigator.serviceWorker.register('./sw.js');
      const registration = await navigator.serviceWorker.ready;

      const waveEmoji = '\u{1F44B}';  // 👋
      const timerEmoji = '\u{23F3}'; // ⏳
      const tvEmoji = '\u{1F4FA}';    // 📺

      const websiteUrl = new URL('WEBSITE.png', window.location.href).href;

      const updateNotification = () => {
        const countdown = getCountdownText();

        registration.showNotification(`Welcome! ${waveEmoji} ${timerEmoji} ${countdown}`, {
          body: 'Check out my channel',
          tag: 'oct2-timer',
          renotify: false,
          silent: true,
          icon: websiteUrl,
          image: websiteUrl,
          badge: websiteUrl,
          actions: [
            {
              action: 'open_app',
              title: `${tvEmoji} Visit Channel`
            }
          ]
        });
      };

      updateNotification();
      setInterval(updateNotification, 1000);
    } catch (err) {
      console.error('Service Worker registration failed:', err);
    }
  }
});
