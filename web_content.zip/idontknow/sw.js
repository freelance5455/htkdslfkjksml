const CACHE_NAME = 'karthik-gaming-v1';
const ASSETS_TO_CACHE = [
  './index.html',
  './app.js',
  './style.css',
  './manifest.json',
  './WEBSITE.png'
];

// Install event: cache all local assets
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(ASSETS_TO_CACHE);
    })
  );
  self.skipWaiting();
});

// Activate event: clean up old caches
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME) {
            return caches.delete(key);
          }
        })
      );
    })
  );
  self.clients.claim();
});

// Fetch event: serve from cache if offline, fallback to network
self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      return cachedResponse || fetch(event.request).catch(() => {
        // Optional fallback for navigation requests when totally offline
        if (event.request.mode === 'navigate') {
          return caches.match('./index.html');
        }
      });
    })
  );
});

// Push notification handling
self.addEventListener('push', (event) => {
  const payload = event.data ? event.data.text() : 'Welcome to KARTHIK GAMING 28!';

  event.waitUntil(
    self.registration.showNotification('KARTHIK GAMING 28', {
      body: payload,
      icon: 'WEBSITE.png',
      image: 'WEBSITE.png'
    })
  );
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil(
    clients.openWindow('https://youtube.com/@KARTHIKGAMING28')
  );
});
