DONUT BROWSER MOBILE v0.1 — HTML starter for APKForge

Entry file: index.html
Other files: style.css, app.js

Import the ZIP into APKForge if it supports HTML/ZIP web app projects, and set index.html as the entry page.
Enable internet access in the app's settings, if required.

IMPORTANT LIMITATION: This HTML project is a WebView wrapper prototype, not a full browser engine. Some websites refuse to load inside iframes due to security restrictions. The "Open in browser" button can be used as a fallback. A fully featured browser with reliable site navigation would need native Android WebView code.

Features: dark purple homepage, URL/search input, multiple tabs (session only), bookmarks stored locally, basic back/forward/reload, settings and Studio Helper placeholder.
No AI service is connected. No incognito feature is implemented.
