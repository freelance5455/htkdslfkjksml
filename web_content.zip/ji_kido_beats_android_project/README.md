# Ji Kido Beats — Android project

This is an Android Studio project wrapping the Ji Kido Beats mobile app prototype in an Android WebView. It includes the current black-and-gold UI and opens offline from the app's bundled assets.

## Build an APK

1. Install Android Studio on a computer (Windows, macOS, or Linux).
2. Open Android Studio and choose **Open**.
3. Select this `ji_kido_beats_android_project` folder.
4. Allow Gradle sync and install any SDK components Android Studio requests (Android SDK Platform 35; JDK 17).
5. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. When it finishes, choose **locate**. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.
7. Transfer `app-debug.apk` to your Android phone and open it. If Android asks, allow installation from that file manager/browser, then install.

## Important

- This is a project ready to build, not a precompiled APK.
- Music buttons currently show preview-status messages because real audio files have not been supplied.
- The contact form saves a text file locally; it does not send enquiries to a label inbox until a contact service is connected.
- Before public release, update the catalogue with final music, add real video/audio links, and review app signing/privacy details.
