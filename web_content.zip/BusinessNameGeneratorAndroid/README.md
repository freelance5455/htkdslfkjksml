# Business Name Generator Android project

This Android Studio project wraps the HTML app supplied in `BusinessNameGenerator (1).apk` inside an Android WebView. The uploaded file itself was only a ZIP containing `assets/index.html` and `README.txt`, not a compiled Android APK.

## Build APK and AAB
1. Install Android Studio and an Android SDK (API 35 or a compatible installed SDK).
2. Open this folder (`BusinessNameGeneratorAndroid`) in Android Studio and allow Gradle sync/downloads.
3. For an APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. For an AAB: **Build → Generate Signed Bundle / APK → Android App Bundle**. Create and securely keep your signing key; use the same key for future updates.

The generated debug APK is for testing. For Play Store distribution, create a signed release AAB and complete Play Console requirements. The app currently preserves the supplied HTML as-is; it has not been independently tested on a device.
