STUDY NOTES - Android project (Kotlin + WebView + HTML/CSS/JavaScript)

BUILD THE APK
1. Install Android Studio (free): https://developer.android.com/studio
2. File > Open > select this StudyNotesApp folder. Wait for Gradle sync to finish.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Click "locate" in the popup. The file is app/build/outputs/apk/debug/app-debug.apk
5. Copy the APK to your phone and install it (allow "Install unknown apps" if asked).

The app UI lives in app/src/main/assets/index.html

NO ANDROID STUDIO? BUILD ONLINE WITH GITHUB (free)
1. Create a free GitHub account and a new repository.
2. Upload ALL files from this folder (including the hidden .github folder).
3. Open the Actions tab > "Build APK" > wait about 5 minutes for the green tick.
4. Open the finished run and download the "StudyNotes-APK" artifact. Unzip it to get app-debug.apk.
