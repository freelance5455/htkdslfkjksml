"use strict";

/*
    ============================================
       SNAKE 3D ADVENTURE - V3.2
       Compatible Acode / Android
    ============================================
*/


/* ==================================================
   CANVAS
   ================================================== */

var canvas =
    document.getElementById("gameCanvas");

var ctx =
    canvas.getContext("2d");

var GRID = 20;

var CELL =
    canvas.width / GRID;


/* ==================================================
   INTERFACE
   ================================================== */

var homeScreen =
    document.getElementById("homeScreen");

var gameScreen =
    document.getElementById("gameScreen");

var gameOverScreen =
    document.getElementById("gameOverScreen");

var worldList =
    document.getElementById("worldList");

var startButton =
    document.getElementById("startButton");

var scoreElement =
    document.getElementById("score");

var highScoreElement =
    document.getElementById("highScore");

var levelElement =
    document.getElementById("level");

var worldNameElement =
    document.getElementById("worldName");

var finalScoreElement =
    document.getElementById("finalScore");

var unlockMessageElement =
    document.getElementById("unlockMessage");

var powerFill =
    document.getElementById("powerFill");

var pauseButton =
    document.getElementById("pauseButton");


/* ==================================================
   MONDES
   ================================================== */

var worlds = [

    {
        id: 0,
        name: "Prairie",
        icon: "🌿",
        difficulty: "Facile",
        unlock: 0,
        speed: 150,
        obstacles: 0,
        type: "rock"
    },

    {
        id: 1,
        name: "Désert",
        icon: "🏜️",
        difficulty: "Normal",
        unlock: 5,
        speed: 130,
        obstacles: 8,
        type: "wall"
    },

    {
        id: 2,
        name: "Forêt",
        icon: "🌲",
        difficulty: "Normal +",
        unlock: 10,
        speed: 115,
        obstacles: 10,
        type: "tree"
    },

    {
        id: 3,
        name: "Volcan",
        icon: "🌋",
        difficulty: "Difficile",
        unlock: 20,
        speed: 100,
        obstacles: 12,
        type: "lava"
    },

    {
        id: 4,
        name: "Glacier",
        icon: "☆",
        difficulty: "Très difficile",
        unlock: 35,
        speed: 90,
        obstacles: 15,
        type: "ice"
    },

    {
        id: 5,
        name: "Espace",
        icon: "🌌",
        difficulty: "Extrême",
        unlock: 50,
        speed: 80,
        obstacles: 17,
        type: "asteroid"
    }

];


/* ==================================================
   VARIABLES
   ================================================== */

var selectedWorld = 0;

var snake = [];

var direction = {
    x: 1,
    y: 0
};

var nextDirection = {
    x: 1,
    y: 0
};

var food = null;

var bonus = null;

var obstacles = [];

var score = 0;

var highScore =
    parseInt(
        localStorage.getItem(
            "snake3DHighScore"
        ),
        10
    ) || 0;

var running = false;

var paused = false;

var timer = null;


/* ==================================================
   OUTILS
   ================================================== */

function getWorld() {

    return worlds[selectedWorld];

}


function samePosition(a, b) {

    return (
        a.x === b.x &&
        a.y === b.y
    );

}


function isSnakePosition(x, y) {

    var i;

    for (
        i = 0;
        i < snake.length;
        i++
    ) {

        if (
            snake[i].x === x &&
            snake[i].y === y
        ) {

            return true;

        }

    }

    return false;

}


function isObstaclePosition(x, y) {

    var i;

    for (
        i = 0;
        i < obstacles.length;
        i++
    ) {

        if (
            obstacles[i].x === x &&
            obstacles[i].y === y
        ) {

            return true;

        }

    }

    return false;

}


function freePosition(x, y) {

    if (
        isSnakePosition(x, y)
    ) {

        return false;

    }


    if (
        isObstaclePosition(x, y)
    ) {

        return false;

    }


    if (
        food &&
        food.x === x &&
        food.y === y
    ) {

        return false;

    }


    if (
        bonus &&
        bonus.x === x &&
        bonus.y === y
    ) {

        return false;

    }


    return true;

}


/* ==================================================
   POSITION ALEATOIRE
   ================================================== */

function randomFreePosition() {

    var attempt;
    var x;
    var y;

    for (
        attempt = 0;
        attempt < 1000;
        attempt++
    ) {

        x =
            Math.floor(
                Math.random() * GRID
            );

        y =
            Math.floor(
                Math.random() * GRID
            );

        if (
            freePosition(x, y)
        ) {

            return {
                x: x,
                y: y
            };

        }

    }


    /*
       Sécurité si aucune position
       n'est disponible.
    */

    return {
        x: 18,
        y: 18
    };

}


/* ==================================================
   MONDES
   ================================================== */

function worldUnlocked(world) {

    return highScore >= world.unlock;

}


function nextLockedWorld() {

    var i;

    for (
        i = 0;
        i < worlds.length;
        i++
    ) {

        if (
            !worldUnlocked(
                worlds[i]
            )
        ) {

            return worlds[i];

        }

    }

    return null;

}


/* ==================================================
   MENU MONDES
   ================================================== */

function renderWorlds() {

    worldList.innerHTML = "";

    var i;

    for (
        i = 0;
        i < worlds.length;
        i++
    ) {

        createWorldButton(
            worlds[i],
            i
        );

    }

}


function createWorldButton(
    world,
    index
) {

    var button =
        document.createElement("button");

    var unlocked =
        worldUnlocked(world);


    button.className =
        "worldButton";


    if (
        index === selectedWorld
    ) {

        button.className +=
            " selected";

    }


    if (!unlocked) {

        button.className +=
            " locked";

    }


    button.innerHTML =

        '<span class="worldIcon">' +
        world.icon +
        '</span>' +

        '<span class="worldTitle">' +
        world.name +
        '</span>' +

        '<span class="worldDifficulty">' +
        (
            unlocked
                ? world.difficulty
                : "🔒 Score " +
                  world.unlock
        ) +
        '</span>';


    button.onclick =
        function () {

            if (!unlocked) {

                alert(
                    "🔒 Monde verrouillé !\n\n" +
                    "Atteins " +
                    world.unlock +
                    " points."
                );

                return;

            }


            selectedWorld =
                index;

            renderWorlds();

        };


    worldList.appendChild(button);

}


/* ==================================================
   CREATION DES OBSTACLES
   ================================================== */

function createObstacles() {

    obstacles = [];

    var world =
        getWorld();

    var attempts = 0;

    while (
        obstacles.length <
        world.obstacles &&
        attempts < 5000
    ) {

        attempts++;


        var x =
            Math.floor(
                Math.random() * GRID
            );

        var y =
            Math.floor(
                Math.random() * GRID
            );


        /*
           Zone centrale protégée
        */

        if (
            x >= 7 &&
            x <= 12 &&
            y >= 7 &&
            y <= 12
        ) {

            continue;

        }


        /*
           Bordure libre
        */

        if (
            x <= 1 ||
            y <= 1 ||
            x >= GRID - 2 ||
            y >= GRID - 2
        ) {

            continue;

        }


        if (
            isObstaclePosition(x, y)
        ) {

            continue;

        }


        if (
            isSnakePosition(x, y)
        ) {

            continue;

        }


        obstacles.push({

            x: x,
            y: y,
            type: world.type

        });

    }

}


/* ==================================================
   NOURRITURE
   ================================================== */

function createFood() {

    food =
        randomFreePosition();

}


/* ==================================================
   BONUS
   ================================================== */

function createBonus() {

    bonus = null;


    /*
       25% de chance
    */

    if (
        Math.random() > 0.25
    ) {

        return;

    }


    bonus =
        randomFreePosition();

}


/* ==================================================
   DEMARRER
   ================================================== */

function startGame() {

    if (timer !== null) {

        clearInterval(timer);

        timer = null;

    }


    var world =
        getWorld();


    score = 0;

    paused = false;

    running = true;


    /*
       Serpent de départ
    */

    snake = [

        {
            x: 10,
            y: 10
        },

        {
            x: 9,
            y: 10
        },

        {
            x: 8,
            y: 10
        }

    ];


    direction = {
        x: 1,
        y: 0
    };


    nextDirection = {
        x: 1,
        y: 0
    };


    food = null;

    bonus = null;


    /*
       Réinitialisation
    */

    powerFill.style.width =
        "0%";


    pauseButton.textContent =
        "❚❚";


    /*
       Obstacles
    */

    createObstacles();


    /*
       Nourriture
    */

    createFood();


    /*
       Interface
    */

    scoreElement.textContent =
        "0";


    levelElement.textContent =
        "Niveau 1";


    worldNameElement.textContent =
        world.icon +
        " " +
        world.name;


    highScoreElement.textContent =
        highScore;


    /*
       Affichage
    */

    homeScreen.className =
        "screen hidden";

    gameOverScreen.className =
        "screen hidden";

    gameScreen.className =
        "screen";


    /*
       Premier dessin
    */

    draw();


    /*
       Boucle
    */

    timer =
        setInterval(
            update,
            world.speed
        );

}


/* ==================================================
   UPDATE
   ================================================== */

function update() {

    if (!running) {
        return;
    }

    if (paused) {
        return;
    }


    direction = {
        x: nextDirection.x,
        y: nextDirection.y
    };


    var head = {

        x:
            snake[0].x +
            direction.x,

        y:
            snake[0].y +
            direction.y

    };


    /*
       Mur extérieur
    */

    if (
        head.x < 0 ||
        head.x >= GRID ||
        head.y < 0 ||
        head.y >= GRID
    ) {

        endGame();

        return;

    }


    /*
       Obstacle
    */

    if (
        isObstaclePosition(
            head.x,
            head.y
        )
    ) {

        endGame();

        return;

    }


    /*
       Corps
    */

    var i;

    for (
        i = 0;
        i < snake.length - 1;
        i++
    ) {

        if (
            snake[i].x === head.x &&
            snake[i].y === head.y
        ) {

            endGame();

            return;

        }

    }


    /*
       Ajouter tête
    */

    snake.unshift(head);


    /*
       Manger
    */

    if (
        food &&
        samePosition(
            head,
            food
        )
    ) {

        score++;

        createFood();

        createBonus();

    } else {

        snake.pop();

    }


    /*
       Bonus
    */

    if (
        bonus &&
        samePosition(
            head,
            bonus
        )
    ) {

        score += 3;

        bonus = null;

    }


    updateInterface();

    draw();

}


/* ==================================================
   INTERFACE
   ================================================== */

function updateInterface() {

    scoreElement.textContent =
        score;


    /*
       Nouveau record
    */

    if (
        score > highScore
    ) {

        highScore =
            score;


        localStorage.setItem(
            "snake3DHighScore",
            highScore
        );

    }


    highScoreElement.textContent =
        highScore;


    levelElement.textContent =
        "Niveau " +
        (
            1 +
            Math.floor(
                score / 5
            )
        );


    worldNameElement.textContent =
        getWorld().icon +
        " " +
        getWorld().name;


    /*
       Barre de pouvoir
    */

    var power =
        (score % 10) * 10;


    powerFill.style.width =
        power + "%";

}


/* ==================================================
   GAME OVER
   ================================================== */

function endGame() {

    running = false;

    paused = false;


    if (timer !== null) {

        clearInterval(timer);

        timer = null;

    }


    finalScoreElement.textContent =
        score;


    var next =
        nextLockedWorld();


    if (next === null) {

        unlockMessageElement.textContent =
            "🏆 Tous les mondes sont débloqués !";

    } else {

        var remaining =
            next.unlock -
            highScore;


        if (remaining <= 0) {

            unlockMessageElement.textContent =
                "🎉 " +
                next.name +
                " est débloqué !";

        } else {

            unlockMessageElement.textContent =
                "🔒 " +
                next.name +
                " : encore " +
                remaining +
                " point(s).";

        }

    }


    gameScreen.className =
        "screen hidden";

    gameOverScreen.className =
        "screen";

    renderWorlds();

}


/* ==================================================
   RECTANGLE ARRONDI COMPATIBLE
   ================================================== */

function roundedRect(
    x,
    y,
    width,
    height,
    radius
) {

    if (
        radius >
        width / 2
    ) {

        radius =
            width / 2;

    }


    if (
        radius >
        height / 2
    ) {

        radius =
            height / 2;

    }


    ctx.beginPath();


    ctx.moveTo(
        x + radius,
        y
    );


    ctx.lineTo(
        x + width - radius,
        y
    );


    ctx.quadraticCurveTo(
        x + width,
        y,
        x + width,
        y + radius
    );


    ctx.lineTo(
        x + width,
        y + height - radius
    );


    ctx.quadraticCurveTo(
        x + width,
        y + height,
        x + width - radius,
        y + height
    );


    ctx.lineTo(
        x + radius,
        y + height
    );


    ctx.quadraticCurveTo(
        x,
        y + height,
        x,
        y + height - radius
    );


    ctx.lineTo(
        x,
        y + radius
    );


    ctx.quadraticCurveTo(
        x,
        y,
        x + radius,
        y
    );


    ctx.closePath();

}


/* ==================================================
   DESSIN
   ================================================== */

function draw() {

    drawBackground();

    drawObstacles();

    drawFood();

    drawBonus();

    drawSnake();

}


/* ==================================================
   FOND
   ================================================== */

function drawBackground() {

    var world =
        getWorld();


    var gradient =
        ctx.createLinearGradient(
            0,
            0,
            0,
            canvas.height
        );


    if (
        world.type === "rock"
    ) {

        gradient.addColorStop(
            0,
            "#75c95b"
        );

        gradient.addColorStop(
            1,
            "#204d2c"
        );

    }

    else if (
        world.type === "wall"
    ) {

        gradient.addColorStop(
            0,
            "#e8bd67"
        );

        gradient.addColorStop(
            1,
            "#85512a"
        );

    }

    else if (
        world.type === "tree"
    ) {

        gradient.addColorStop(
            0,
            "#397c40"
        );

        gradient.addColorStop(
            1,
            "#102b18"
        );

    }

    else if (
        world.type === "lava"
    ) {

        gradient.addColorStop(
            0,
            "#65170d"
        );

        gradient.addColorStop(
            1,
            "#160606"
        );

    }

    else if (
        world.type === "ice"
    ) {

        gradient.addColorStop(
            0,
            "#a9edff"
        );

        gradient.addColorStop(
            1,
            "#3d7694"
        );

    }

    else {

        gradient.addColorStop(
            0,
            "#121e43"
        );

        gradient.addColorStop(
            1,
            "#02040b"
        );

    }


    ctx.fillStyle =
        gradient;


    ctx.fillRect(
        0,
        0,
        canvas.width,
        canvas.height
    );


    /*
       Grille
    */

    ctx.strokeStyle =
        "rgba(255,255,255,.06)";

    ctx.lineWidth = 1;


    var i;

    for (
        i = 0;
        i <= GRID;
        i++
    ) {

        ctx.beginPath();

        ctx.moveTo(
            i * CELL,
            0
        );

        ctx.lineTo(
            i * CELL,
            canvas.height
        );

        ctx.stroke();


        ctx.beginPath();

        ctx.moveTo(
            0,
            i * CELL
        );

        ctx.lineTo(
            canvas.width,
            i * CELL
        );

        ctx.stroke();

    }

}


/* ==================================================
   OBSTACLES
   ================================================== */

function drawObstacles() {

    var i;

    for (
        i = 0;
        i < obstacles.length;
        i++
    ) {

        var o =
            obstacles[i];


        var x =
            o.x * CELL;

        var y =
            o.y * CELL;


        if (
            o.type === "rock"
        ) {

            drawRock(x, y);

        }

        else if (
            o.type === "wall"
        ) {

            drawWall(x, y);

        }

        else if (
            o.type === "tree"
        ) {

            drawTree(x, y);

        }

        else if (
            o.type === "lava"
        ) {

            drawLava(x, y);

        }

        else if (
            o.type === "ice"
        ) {

            drawIce(x, y);

        }

        else {

            drawAsteroid(x, y);

        }

    }

}


/* ==================================================
   ROCHER
   ================================================== */

function drawRock(x, y) {

    ctx.fillStyle =
        "#4d5755";

    ctx.beginPath();

    ctx.moveTo(
        x + 4,
        y + 26
    );

    ctx.lineTo(
        x + 8,
        y + 8
    );

    ctx.lineTo(
        x + 20,
        y + 4
    );

    ctx.lineTo(
        x + 29,
        y + 13
    );

    ctx.lineTo(
        x + 25,
        y + 28
    );

    ctx.closePath();

    ctx.fill();


    ctx.fillStyle =
        "#7d8783";

    ctx.beginPath();

    ctx.moveTo(
        x + 9,
        y + 9
    );

    ctx.lineTo(
        x + 20,
        y + 6
    );

    ctx.lineTo(
        x + 16,
        y + 13
    );

    ctx.closePath();

    ctx.fill();

}


/* ==================================================
   MUR DESERT
   ================================================== */

function drawWall(x, y) {

    ctx.fillStyle =
        "#78482d";

    ctx.fillRect(
        x + 2,
        y + 3,
        CELL - 4,
        CELL - 6
    );


    ctx.fillStyle =
        "#bf7846";

    ctx.fillRect(
        x + 3,
        y + 4,
        CELL - 6,
        5
    );


    ctx.strokeStyle =
        "#492719";

    ctx.strokeRect(
        x + 2,
        y + 3,
        CELL - 4,
        CELL - 6
    );

}


/* ==================================================
   ARBRE
   ================================================== */

function drawTree(x, y) {

    ctx.fillStyle =
        "#704529";

    ctx.fillRect(
        x + 10,
        y + 13,
        7,
        13
    );


    ctx.fillStyle =
        "#174f29";

    ctx.beginPath();

    ctx.arc(
        x + 13,
        y + 9,
        11,
        0,
        Math.PI * 2
    );

    ctx.fill();


    ctx.fillStyle =
        "#338943";

    ctx.beginPath();

    ctx.arc(
        x + 9,
        y + 6,
        7,
        0,
        Math.PI * 2
    );

    ctx.fill();

}


/* ==================================================
   LAVE
   ================================================== */

function drawLava(x, y) {

    ctx.fillStyle =
        "#ff3416";

    ctx.fillRect(
        x + 2,
        y + 2,
        CELL - 4,
        CELL - 4
    );


    ctx.fillStyle =
        "#ffc000";


    ctx.beginPath();

    ctx.arc(
        x + 8,
        y + 10,
        3,
        0,
        Math.PI * 2
    );

    ctx.fill();


    ctx.beginPath();

    ctx.arc(
        x + 20,
        y + 18,
        3,
        0,
        Math.PI * 2
    );

    ctx.fill();

}


/* ==================================================
   GLACE
   ================================================== */

function drawIce(x, y) {

    ctx.fillStyle =
        "#d9f9ff";

    ctx.beginPath();

    ctx.moveTo(
        x + 3,
        y + 27
    );

    ctx.lineTo(
        x + 7,
        y + 5
    );

    ctx.lineTo(
        x + 20,
        y + 2
    );

    ctx.lineTo(
        x + 28,
        y + 10
    );

    ctx.lineTo(
        x + 25,
        y + 27
    );

    ctx.closePath();

    ctx.fill();


    ctx.strokeStyle =
        "#68c9e5";

    ctx.stroke();

}


/* ==================================================
   ASTEROÏDE
   ================================================== */

function drawAsteroid(x, y) {

    ctx.fillStyle =
        "#626b85";

    ctx.beginPath();

    ctx.moveTo(
        x + 4,
        y + 19
    );

    ctx.lineTo(
        x + 8,
        y + 7
    );

    ctx.lineTo(
        x + 19,
        y + 3
    );

    ctx.lineTo(
        x + 28,
        y + 10
    );

    ctx.lineTo(
        x + 24,
        y + 25
    );

    ctx.lineTo(
        x + 11,
        y + 28
    );

    ctx.closePath();

    ctx.fill();


    ctx.fillStyle =
        "#949bb0";

    ctx.beginPath();

    ctx.arc(
        x + 12,
        y + 11,
        3,
        0,
        Math.PI * 2
    );

    ctx.fill();

}


/* ==================================================
   NOURRITURE
   ================================================== */

function drawFood() {

    if (!food) {
        return;
    }


    var x =
        food.x * CELL;

    var y =
        food.y * CELL;


    var cx =
        x + CELL / 2;

    var cy =
        y + CELL / 2;


    ctx.shadowBlur = 14;

    ctx.shadowColor =
        "#ff3333";


    ctx.fillStyle =
        "#ff3040";


    ctx.beginPath();

    ctx.arc(
        cx,
        cy,
        CELL * .34,
        0,
        Math.PI * 2
    );

    ctx.fill();


    ctx.shadowBlur = 0;


    ctx.fillStyle =
        "#6dff70";


    ctx.fillRect(
        cx - 2,
        cy - 14,
        4,
        6
    );

}


/* ==================================================
   BONUS
   ================================================== */

function drawBonus() {

    if (!bonus) {
        return;
    }


    var cx =
        bonus.x * CELL +
        CELL / 2;

    var cy =
        bonus.y * CELL +
        CELL / 2;


    var pulse =
        1 +
        Math.sin(
            Date.now() / 120
        ) * .08;


    ctx.save();


    ctx.translate(
        cx,
        cy
    );


    ctx.scale(
        pulse,
        pulse
    );


    ctx.rotate(
        Math.PI / 4
    );


    ctx.shadowBlur = 18;

    ctx.shadowColor =
        "#00ffff";


    ctx.fillStyle =
        "#00eaff";


    ctx.fillRect(
        -8,
        -8,
        16,
        16
    );


    ctx.restore();


    ctx.shadowBlur = 0;

}


/* ==================================================
   SERPENT
   ================================================== */

function drawSnake() {

    var i;

    for (
        i = snake.length - 1;
        i >= 0;
        i--
    ) {

        var part =
            snake[i];


        var x =
            part.x * CELL;

        var y =
            part.y * CELL;


        var head =
            i === 0;


        var gradient =
            ctx.createLinearGradient(
                x,
                y,
                x,
                y + CELL
            );


        if (head) {

            gradient.addColorStop(
                0,
                "#d2ff62"
            );

            gradient.addColorStop(
                1,
                "#29a33d"
            );

        } else {

            gradient.addColorStop(
                0,
                "#5be95f"
            );

            gradient.addColorStop(
                1,
                "#14762d"
            );

        }


        ctx.fillStyle =
            gradient;


        roundedRect(
            x + 2,
            y + 2,
            CELL - 4,
            CELL - 4,
            6
        );


        ctx.fill();


        /*
           Contour
        */

        ctx.strokeStyle =
            "rgba(0,0,0,.25)";

        ctx.lineWidth = 1;

        ctx.stroke();


        if (head) {

            drawEyes(
                x,
                y
            );

        }

    }

}


/* ==================================================
   YEUX
   ================================================== */

function drawEyes(x, y) {

    var e1;
    var e2;


    if (
        direction.x === 1
    ) {

        e1 = {
            x: x + 16,
            y: y + 7
        };

        e2 = {
            x: x + 16,
            y: y + 17
        };

    }

    else if (
        direction.x === -1
    ) {

        e1 = {
            x: x + 6,
            y: y + 7
        };

        e2 = {
            x: x + 6,
            y: y + 17
        };

    }

    else if (
        direction.y === -1
    ) {

        e1 = {
            x: x + 7,
            y: y + 6
        };

        e2 = {
            x: x + 17,
            y: y + 6
        };

    }

    else {

        e1 = {
            x: x + 7,
            y: y + 16
        };

        e2 = {
            x: x + 17,
            y: y + 16
        };

    }


    ctx.fillStyle =
        "white";


    ctx.beginPath();

    ctx.arc(
        e1.x,
        e1.y,
        3,
        0,
        Math.PI * 2
    );

    ctx.fill();


    ctx.beginPath();

    ctx.arc(
        e2.x,
        e2.y,
        3,
        0,
        Math.PI * 2
    );

    ctx.fill();


    ctx.fillStyle =
        "#111";


    ctx.beginPath();

    ctx.arc(
        e1.x,
        e1.y,
        1.3,
        0,
        Math.PI * 2
    );

    ctx.fill();


    ctx.beginPath();

    ctx.arc(
        e2.x,
        e2.y,
        1.3,
        0,
        Math.PI * 2
    );

    ctx.fill();

}


/* ==================================================
   DIRECTION
   ================================================== */

function changeDirection(
    x,
    y
) {

    if (!running) {
        return;
    }


    /*
       Interdit le demi-tour
    */

    if (
        x === -direction.x &&
        y === -direction.y
    ) {

        return;

    }


    nextDirection = {
        x: x,
        y: y
    };

}


/* ==================================================
   BOUTONS
   ================================================== */

document
    .getElementById("upButton")
    .onclick =
    function () {

        changeDirection(
            0,
            -1
        );

    };


document
    .getElementById("downButton")
    .onclick =
    function () {

        changeDirection(
            0,
            1
        );

    };


document
    .getElementById("leftButton")
    .onclick =
    function () {

        changeDirection(
            -1,
            0
        );

    };


document
    .getElementById("rightButton")
    .onclick =
    function () {

        changeDirection(
            1,
            0
        );

    };


/* ==================================================
   PAUSE
   ================================================== */

pauseButton.onclick =
    function () {

        if (!running) {
            return;
        }


        paused =
            !paused;


        if (paused) {

            pauseButton.textContent =
                "▶";

        } else {

            pauseButton.textContent =
                "❚❚";

        }

    };


/* ==================================================
   RESTART
   ================================================== */

document
    .getElementById("restartButton")
    .onclick =
    function () {

        startGame();

    };


document
    .getElementById("playAgainButton")
    .onclick =
    function () {

        startGame();

    };


/* ==================================================
   MENU
   ================================================== */

function goHome() {

    running = false;

    paused = false;


    if (timer !== null) {

        clearInterval(timer);

        timer = null;

    }


    gameScreen.className =
        "screen hidden";

    gameOverScreen.className =
        "screen hidden";

    homeScreen.className =
        "screen";


    renderWorlds();

}


document
    .getElementById("homeButton")
    .onclick =
    function () {

        goHome();

    };


document
    .getElementById("gameOverHomeButton")
    .onclick =
    function () {

        goHome();

    };


/* ==================================================
   START
   ================================================== */

startButton.onclick =
    function () {

        startGame();

    };


/* ==================================================
   CLAVIER
   ================================================== */

document.onkeydown =
    function (event) {

        var key =
            event.key;


        if (
            key === "ArrowUp" ||
            key === "w" ||
            key === "W"
        ) {

            changeDirection(
                0,
                -1
            );

        }


        else if (
            key === "ArrowDown" ||
            key === "s" ||
            key === "S"
        ) {

            changeDirection(
                0,
                1
            );

        }


        else if (
            key === "ArrowLeft" ||
            key === "a" ||
            key === "A"
        ) {

            changeDirection(
                -1,
                0
            );

        }


        else if (
            key === "ArrowRight" ||
            key === "d" ||
            key === "D"
        ) {

            changeDirection(
                1,
                0
            );

        }


        else if (
            key === " "
        ) {

            if (running) {

                paused =
                    !paused;

                pauseButton.textContent =
                    paused
                        ? "▶"
                        : "❚❚";

            }

        }

    };


/* ==================================================
   SWIPE ANDROID
   ================================================== */

var touchStartX = 0;
var touchStartY = 0;


canvas.addEventListener(
    "touchstart",
    function (event) {

        if (
            !event.changedTouches ||
            !event.changedTouches.length
        ) {

            return;

        }


        var touch =
            event.changedTouches[0];


        touchStartX =
            touch.clientX;

        touchStartY =
            touch.clientY;

    },
    false
);


canvas.addEventListener(
    "touchend",
    function (event) {

        if (
            !event.changedTouches ||
            !event.changedTouches.length
        ) {

            return;

        }


        var touch =
            event.changedTouches[0];


        var dx =
            touch.clientX -
            touchStartX;

        var dy =
            touch.clientY -
            touchStartY;


        var minimum =
            25;


        if (
            Math.abs(dx) < minimum &&
            Math.abs(dy) < minimum
        ) {

            return;

        }


        if (
            Math.abs(dx) >
            Math.abs(dy)
        ) {

            if (dx > 0) {

                changeDirection(
                    1,
                    0
                );

            } else {

                changeDirection(
                    -1,
                    0
                );

            }

        } else {

            if (dy > 0) {

                changeDirection(
                    0,
                    1
                );

            } else {

                changeDirection(
                    0,
                    -1
                );

            }

        }

    },
    false
);


/* ==================================================
   INITIALISATION
   ================================================== */

highScoreElement.textContent =
    highScore;

renderWorlds();


/*
   Dessin initial du terrain.
   Cela permet de vérifier que le Canvas fonctionne
   même avant de commencer une partie.
*/

draw();