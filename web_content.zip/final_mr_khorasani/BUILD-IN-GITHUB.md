# Build in GitHub Actions

1. Upload/push this project to a GitHub repository.
2. Open **Actions**.
3. Select **Build MR KHORASANI Android APK**.
4. Run **workflow_dispatch**.
5. After a successful run, download the artifact named:
   `MR-KHORASANI-Finance-v1.1.0-APK`
6. The artifact contains:
   - `MR-KHORASANI-Finance-v1.1.0-debug.apk`
   - `MR-KHORASANI-Finance-v1.1.0-debug.apk.sha256`

The workflow uses the Android project under:
`android_src/Newfoam-Android-APK-Ready/android`
