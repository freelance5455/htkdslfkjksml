import{T as e}from"./books-store-DBns008h.js";function t(e,t,n=`text/plain;charset=utf-8`){let r=new Blob([t],{type:n}),i=URL.createObjectURL(r),a=document.createElement(`a`);a.href=i,a.download=e,a.click(),URL.revokeObjectURL(i)}function n(e,t){let n=e=>{let t=String(e??``);return/[",\n]/.test(t)?`"${t.replace(/"/g,`""`)}"`:t};return`\uFEFF${[e,...t].map(e=>e.map(n).join(`,`)).join(`
`)}`}function r(t,n,r,i,a){let o=window.open(``,`_blank`,`noopener,noreferrer,width=900,height=1200`);o&&(o.document.write(`<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"/><title>${t}</title>
  <style>
    body{font-family:Tahoma,Vazirmatn,sans-serif;color:#121820;padding:32px;background:#fff}
    h1{font-size:18px;margin:0 0 4px}
    .meta{color:#5e6670;font-size:12px;margin-bottom:18px}
    table{width:100%;border-collapse:collapse;font-size:12px}
    th,td{border:1px solid #d9d2c3;padding:6px 8px;text-align:right}
    th{background:#0b1f3a;color:#e8d5a8}
    tfoot td{font-weight:700;background:#f3efe4}
    @page{margin:16mm}
  </style></head><body>
  <h1>${t}</h1>
  <div class="meta">${n} · ${r} · ${e(new Date().toISOString().slice(0,10))} · تهیه توسط ${a}</div>
  ${i}
  </body></html>`),o.document.close(),o.focus(),o.print())}export{r as n,n as r,t};