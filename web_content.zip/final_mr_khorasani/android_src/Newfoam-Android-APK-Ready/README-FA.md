# Newfoam / MR KHORASANI Finance — بسته آماده ساخت APK

این بسته برای تبدیل مستقیم پروژه به APK اندروید آماده شده است.

## نکته مهم
رابط وب برنامه از قبل داخل این پروژه در مسیر زیر قرار گرفته و برای ساخت APK نیازی به اجرای Node/Vite نیست:

`android/app/src/main/assets/www/`

## ساده‌ترین روش با Android Studio

1. Android Studio را نصب کنید.
2. همین پوشه را با گزینه **Open** باز کنید و پوشه `android` را انتخاب کنید.
3. منتظر بمانید Gradle Sync کامل شود.
4. از منوی **Build → Build APK(s)** استفاده کنید.
5. APK نهایی در این مسیر ساخته می‌شود:

`android/app/build/outputs/apk/debug/app-debug.apk`

## مشخصات

- Application ID: `com.mrkhrasani.finance`
- Version: `1.0.0`
- Minimum Android: 7.0 / API 24
- Target SDK: 35
- اجرای رابط به‌صورت آفلاین داخل APK
- ذخیره داده‌های WebView روی خود دستگاه
- پشتیبانی از Backup/Restore JSON

## ساخت با ترمینال

### Windows
فایل `android/build-apk.bat` را اجرا کنید.

### Linux / macOS
```bash
cd android
./build-apk.sh
```

## GitHub Actions

در `.github/workflows/android-debug.yml` گردش‌کار ساخت APK وجود دارد. با اجرای workflow، APK به‌صورت Artifact تولید می‌شود.

## وضعیت Build اصلاح‌شده
پروژه در نسخه فعلی Package ID و MainActivity یکسان دارد و Workflow واقعی Android Build در `.github/workflows/android-build.yml` اضافه شده است. این Workflow وابستگی به `npm` و `package-lock.json` ندارد و Android SDK 35 و Build Tools 35.0.0 را قبل از Build نصب می‌کند.
