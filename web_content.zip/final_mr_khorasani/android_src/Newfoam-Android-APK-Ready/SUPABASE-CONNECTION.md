# MR,KHORASANI — Supabase Connection

Project: `mr-khorasani-finance`
Supabase URL: `https://klomsegarpfdkhkmoazy.supabase.co`

The Android WebView loads `android/app/src/main/assets/www/supabase-client.js` before the application bundle.

The client exposes:
- `window.MR_SUPABASE.request(path, options)`
- `window.MR_SUPABASE.rpc(name, args)`
- `window.MR_SUPABASE.setAccessToken(token)`
- `window.MR_SUPABASE.health()`

Only the Supabase publishable key is embedded in the Android client. A service-role/secret key is not embedded.

The current build performs a read-only connectivity check against `/rest/v1/companies` and stores the result in `localStorage` as `mr_supabase_status`.

Full authenticated business-operation wiring requires the Android UI/source layer to pass a signed-in user's access token and then call the RPCs. The current binary bundle is an existing WebView application, so the connection layer is isolated and ready for that integration without exposing privileged credentials.


## v1.0.4
- Supabase Auth helpers added: signIn, signUp, signOut.
- A small in-app cloud console is included for connection/auth verification.
- Backend RPCs added for receipt, payment, sale, purchase, check lifecycle, day close/reopen, and trial balance.
- The production accounting screens still require final field-to-RPC mapping; this console is diagnostic, not the final accounting UI.
