create table if not exists books_snapshots (
  user_id text primary key,
  payload jsonb not null,
  version integer not null default 1,
  updated_at timestamptz not null default now()
);

create table if not exists books_backups (
  id text primary key,
  user_id text not null,
  name text not null,
  day_key text,
  payload jsonb not null,
  created_at timestamptz not null default now()
);

create index if not exists books_backups_user_idx on books_backups (user_id, created_at desc);
