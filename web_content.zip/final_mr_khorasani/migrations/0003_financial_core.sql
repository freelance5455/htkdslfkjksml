create table if not exists fiscal_years (
  id text primary key,
  user_id text not null,
  jalali_year integer not null,
  name text not null,
  start_date date not null,
  end_date date not null,
  status text not null default 'open' check (status in ('open','closed')),
  is_current boolean not null default false,
  created_at timestamptz not null default now(),
  unique (user_id, jalali_year)
);

create table if not exists account_groups (
  id text primary key,
  user_id text not null,
  code text not null,
  name text not null,
  level smallint not null check (level between 1 and 4),
  parent_id text references account_groups(id),
  unique (user_id, code)
);

create table if not exists accounts (
  id text primary key,
  user_id text not null,
  fiscal_year_id text references fiscal_years(id),
  code text not null,
  name text not null,
  level smallint not null check (level between 1 and 4),
  parent_id text references accounts(id),
  nature text not null check (nature in ('debit','credit')),
  class text not null,
  floating_kind text not null default 'none',
  postable boolean not null default false,
  active boolean not null default true,
  unique (user_id, fiscal_year_id, code)
);

create table if not exists parties (
  id text primary key,
  user_id text not null,
  code text not null,
  name text not null,
  trade_name text,
  national_id text,
  phone text,
  mobile text,
  address text,
  city text,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  unique (user_id, code)
);

create table if not exists party_roles (
  party_id text not null references parties(id) on delete restrict,
  role text not null,
  primary key (party_id, role)
);

create table if not exists items (
  id text primary key,
  user_id text not null,
  sku text not null,
  barcode text,
  name text not null,
  unit text,
  category text,
  subcategory text,
  default_buy_price numeric(20,0) not null default 0,
  default_sale_price numeric(20,0) not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  unique (user_id, sku),
  unique (user_id, barcode)
);

create table if not exists financial_sources (
  id text primary key,
  user_id text not null,
  name text not null,
  kind text not null check (kind in ('cash','bank','petty')),
  account_id text references accounts(id),
  bank_name text,
  branch_name text,
  account_no text,
  iban text,
  card_no text,
  active boolean not null default true,
  opened_at date,
  created_at timestamptz not null default now(),
  unique (user_id, name)
);

create table if not exists operations (
  id text primary key,
  user_id text not null,
  fiscal_year_id text not null references fiscal_years(id),
  operation_no text not null,
  kind text not null,
  operation_date date not null,
  party_id text references parties(id),
  financial_source_id text references financial_sources(id),
  amount numeric(20,0) not null check (amount >= 0),
  paid_amount numeric(20,0) not null default 0 check (paid_amount >= 0),
  discount_amount numeric(20,0) not null default 0 check (discount_amount >= 0),
  discount_mode text check (discount_mode in ('percent','amount')),
  discount_percent numeric(10,4) not null default 0 check (discount_percent >= 0 and discount_percent <= 100),
  shipping_amount numeric(20,0) not null default 0 check (shipping_amount >= 0),
  description text not null default '',
  status text not null default 'posted',
  version integer not null default 1,
  sync_status text not null default 'pending',
  created_by text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  deleted_by text,
  delete_reason text,
  unique (user_id, operation_no)
);

create table if not exists journals (
  id text primary key,
  user_id text not null,
  fiscal_year_id text not null references fiscal_years(id),
  journal_no text not null,
  journal_date date not null,
  kind text not null,
  operation_id text references operations(id),
  original_journal_id text references journals(id),
  adjustment_of_id text references journals(id),
  description text not null default '',
  status text not null default 'posted',
  locked boolean not null default false,
  created_by text not null,
  created_at timestamptz not null default now(),
  unique (user_id, journal_no)
);

create table if not exists journal_lines (
  id text primary key,
  journal_id text not null references journals(id) on delete restrict,
  line_no integer not null,
  account_id text not null references accounts(id),
  party_id text references parties(id),
  financial_source_id text references financial_sources(id),
  debit numeric(20,0) not null default 0 check (debit >= 0),
  credit numeric(20,0) not null default 0 check (credit >= 0),
  description text not null default '',
  check ((debit = 0 and credit > 0) or (credit = 0 and debit > 0)),
  unique (journal_id, line_no)
);

create index if not exists operations_user_date_idx on operations(user_id, operation_date);
create index if not exists journals_user_date_idx on journals(user_id, journal_date);
create index if not exists journal_lines_account_idx on journal_lines(account_id, journal_id);

create or replace function assert_journal_balanced() returns trigger language plpgsql as $$
declare
  v_journal text;
  v_dr numeric(20,0);
  v_cr numeric(20,0);
begin
  v_journal := coalesce(new.journal_id, old.journal_id);
  select coalesce(sum(debit),0), coalesce(sum(credit),0) into v_dr, v_cr from journal_lines where journal_id = v_journal;
  if v_dr <> v_cr then
    raise exception 'UNBALANCED_JOURNAL:%:debit=% credit=%', v_journal, v_dr, v_cr;
  end if;
  return null;
end $$;

drop trigger if exists journal_balance_guard on journal_lines;
create constraint trigger journal_balance_guard
after insert or update or delete on journal_lines
initially deferred
for each row execute function assert_journal_balanced();

create table if not exists daily_closings (
  id text primary key,
  user_id text not null,
  fiscal_year_id text not null references fiscal_years(id),
  day_key date not null,
  status text not null check (status in ('open','closed','reopened')),
  closed_by text,
  closed_at timestamptz,
  backup_id text,
  unique (user_id, day_key)
);

create table if not exists audit_logs (
  id text primary key,
  user_id text not null,
  actor_user_id text not null,
  actor_name text,
  action text not null,
  entity text not null,
  entity_id text not null,
  day_key date,
  old_value jsonb,
  new_value jsonb,
  reason text,
  device_id text,
  ip_address inet,
  created_at timestamptz not null default now()
);

create index if not exists audit_logs_user_time_idx on audit_logs(user_id, created_at desc);

create table if not exists sync_queue (
  id text primary key,
  user_id text not null,
  entity text not null,
  entity_id text not null,
  version integer not null,
  operation text not null,
  payload jsonb not null,
  status text not null default 'pending',
  created_at timestamptz not null default now(),
  synced_at timestamptz
);
