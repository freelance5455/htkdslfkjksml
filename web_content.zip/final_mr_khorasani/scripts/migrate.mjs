#!/usr/bin/env node
/**
 * Deploy-time database migrator (node-postgres, `pg`).
 *
 * Runs during `npm run build` — on every Vercel deploy — applying pending files
 * in ../migrations to DATABASE_URL. Each file is applied in one transaction and
 * recorded in a `_migrations` table, so it runs once and is safe to re-run.
 *
 * The read is non-recursive, so the opt-in auth schema under migrations/auth/
 * is not applied to an app that never asked for sign-in.
 *
 * No DATABASE_URL (local / preview builds) -> skip; the PGLite fallback applies
 * the same files at startup instead (see src/lib/db.ts).
 */
import { readdir, readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import pg from "pg";
import { pendingMigrations } from "./migration-plan.mjs";

const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) {
  console.log(
    "[migrate] DATABASE_URL not set — skipping (the PGLite fallback migrates itself).",
  );
  process.exit(0);
}

const migrationsDir = join(dirname(fileURLToPath(import.meta.url)), "..", "migrations");

async function main() {
  let entries;
  try {
    entries = await readdir(migrationsDir);
  } catch {
    console.log("[migrate] no migrations/ directory — nothing to do.");
    return;
  }
  // An app with no schema of its own must not pay for a database connection.
  if (pendingMigrations(entries, []).length === 0) {
    console.log("[migrate] no migrations — nothing to do.");
    return;
  }

  const pool = new pg.Pool({ connectionString: databaseUrl, max: 1 });
  const client = await pool.connect();
  try {
    // Safety preflight: this app's migrations were authored for its own schema.
    // The linked Supabase project already has a different accounting schema in
    // public (e.g. accounts, journals, parties). CREATE TABLE IF NOT EXISTS
    // would silently preserve those incompatible tables, then later migrations
    // could fail or the app could query the wrong columns. Detect collisions
    // before creating even the migration ledger; never mutate existing tables.
    const migrationSql = await Promise.all(
      (await readdir(migrationsDir))
        .filter((name) => name.endsWith(".sql"))
        .sort()
        .map((name) => readFile(join(migrationsDir, name), "utf8")),
    );
    const appTables = new Set();
    for (const text of migrationSql) {
      const pattern = /create\s+table\s+if\s+not\s+exists\s+(?:public\.)?(?:"([^"]+)"|([a-zA-Z_][\w$]*))/gi;
      for (const match of text.matchAll(pattern)) appTables.add(match[1] ?? match[2]);
    }
    const existingRows = await client.query(
      "SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' AND table_type = 'BASE TABLE'",
    );
    const existing = new Set(existingRows.rows.map((row) => row.table_name));
    const collisions = [...appTables].filter((name) => existing.has(name) && name !== "_migrations");
    if (collisions.length) {
      throw new Error(
        "SUPABASE_SCHEMA_COLLISION: refusing to apply app migrations to public. " +
        "Existing tables overlap with this app's schema: " + collisions.sort().join(", ") +
        ". No schema changes were made. Use a dedicated schema/connection search_path " +
        "or create an explicit schema mapping before retrying.",
      );
    }

    await client.query(
      "CREATE TABLE IF NOT EXISTS _migrations (name TEXT PRIMARY KEY, applied_at TIMESTAMPTZ NOT NULL DEFAULT now())",
    );
    const applied = (await client.query("SELECT name FROM _migrations")).rows.map(
      (r) => r.name,
    );

    let count = 0;
    for (const { name } of pendingMigrations(entries, applied)) {
      const text = await readFile(join(migrationsDir, name), "utf8");
      try {
        await client.query("BEGIN");
        // pg's simple-query protocol runs a whole multi-statement file at once.
        await client.query(text);
        await client.query("INSERT INTO _migrations (name) VALUES ($1)", [name]);
        await client.query("COMMIT");
      } catch (err) {
        console.error(`[migrate] error applying ${name}`);
        try {
          await client.query("ROLLBACK");
        } catch {
          // ROLLBACK fails when the connection died — keep the original error.
        }
        throw err;
      }
      console.log(`[migrate] applied ${name}`);
      count += 1;
    }
    console.log(count ? `[migrate] done — ${count} migration(s) applied.` : "[migrate] up to date.");
  } finally {
    client.release();
    await pool.end();
  }
}

main().catch((err) => {
  console.error("[migrate] failed:", err?.message || err);
  // pg errors carry the context needed to debug a bad SQL file.
  for (const key of ["code", "detail", "hint", "position", "where"]) {
    if (err?.[key] != null) console.error(`[migrate]   ${key}: ${err[key]}`);
  }
  process.exit(1);
});
