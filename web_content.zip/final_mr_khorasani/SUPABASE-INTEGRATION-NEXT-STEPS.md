# MR,KHORASANI — Supabase integration status and next steps

## Implemented in this patch

` scripts/migrate.mjs` now performs a read-only preflight before creating the `_migrations` ledger. It extracts table names from top-level app migrations, checks for same-named base tables in `public`, and stops with `SUPABASE_SCHEMA_COLLISION` if any overlap exists. The guard intentionally does not alter existing data or tables.

## Why this is necessary

The app migrations define a user-scoped schema (for example `accounts`, `journals`, `journal_lines`, `parties`, `daily_closings`). The connected Supabase project already contains company-scoped tables with several of the same names. `CREATE TABLE IF NOT EXISTS` does not reconcile column differences; without a guard, migrations could appear to succeed partially while app queries target incompatible tables.

## Current scope / limitations

- This is a **safety guard**, not the completed data-layer migration.
- It does not change the current Supabase schema.
- It does not yet map app `user_id` data to `company_id` / `company_members`.
- It does not convert the web app's Better Auth identity to Supabase Auth.
- It does not wire all accounting screens to the existing Supabase RPCs.
- No APK is built by this patch.

## Safe continuation plan

1. Decide whether the web app will use the existing company-scoped Supabase schema or an isolated app schema. Do not point the current migrations at `public`.
2. If reusing the existing schema, implement explicit repository/query mappings and migrate authentication/authorization to the existing membership model.
3. If isolating the web schema, configure a dedicated PostgreSQL schema and `search_path` for **every** connection used by runtime and migrations; verify Better Auth and migration-ledger placement.
4. Add integration tests against a disposable database before production.
5. Build web and Android in CI; only call the APK installable after signing and device/emulator install tests.

## Validation

The patch was reviewed against the source migration pattern and the live table-name inventory. A full npm test/build was not run in this environment because dependencies are not installed and the environment previously lacked outbound access for Gradle downloads.
