# MR,KHORASANI — Architecture

## Runtime chain
`User Action → Validation → Operation → Accounting Engine → Journal → Journal Lines → Ledger/Reports → KPI/Cash Flow → Audit Trail`

## Android
Kotlin/Java WebView wrapper with secure `WebViewAssetLoader`. Android minimum API 24, target/compile SDK 35. The production accounting UI is the source in `src/` and is packaged into the Android `assets/www` directory after the web build.

## Offline-first
The current application persists the working book locally, queues changes for sync, and synchronizes against the authenticated backend. A relational PostgreSQL-compatible schema is provided in `migrations/0003_financial_core.sql` for the cloud data model.

## Accounting core
All accounting scenarios use `src/lib/accounting/engine.ts`. UI components do not create journal lines directly. Journal balance is checked before posting and the cloud schema also includes a deferred database constraint trigger for journal balance.

## Dates
Canonical persisted dates remain ISO/Gregorian database dates. The UI uses Jalali/Persian date presentation and a dedicated `JalaliDateInput` for entry and filtering.

## Master data
Parties have a stable Party ID and can carry multiple roles. Items have a stable Item ID, SKU and optional barcode. Financial sources map to accounting accounts and may represent cash, banks or petty cash.
