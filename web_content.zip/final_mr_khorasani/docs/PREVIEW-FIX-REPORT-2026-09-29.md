# MR,KHORASANI — Preview Fix Report

## Observed problem
The attached ZIP preview was not showing the accounting application. It was opening the platform's iOS Home Screen tutorial page. The tutorial page showed:

- broken image placeholders for the Grok logo and tutorial graphics;
- missing tutorial styling;
- the literal `{{APP_NAME}}` placeholder;
- a black, generic Grok tutorial layout instead of the MR,KHORASANI application UI.

## Root cause
The project's Grok PWA middleware treated every `?install=1&platform=ios` document request as an iOS install-tutorial request, including generic preview hosts used by ZIP-to-APK/conversion services. Those preview hosts do not necessarily expose the `/__grok/install/*` static assets used by the tutorial page.

## Fix
The install-tutorial interception is now restricted to published `*.grok.me` hosts in both:

- the Vite development/preview middleware;
- the Nitro deployed middleware.

On generic preview/converter hosts, the same query parameters now fall through to the actual MR,KHORASANI application instead of replacing it with the tutorial page.

## Regression coverage
Added a host-gating regression test confirming:

- `wild-race.grok.me` → install tutorial;
- `preview.example.com` → actual app;
- `localhost:8080` → actual app;
- `172.17.154.217:8080` → actual app.

## Verification
Syntax checks for the modified JavaScript/TypeScript PWA files passed. A direct runtime check of the host-gating function passed for all four cases.

The broader legacy `grok-pwa-plugin.test.mjs` suite still contains pre-existing unrelated identity/card expectation failures in this workspace; those failures are outside this preview fix.

## APK status
This change fixes the web-project preview behavior. It does not claim that an Android APK has been successfully built or device-tested; that still requires a real Android SDK/Gradle build environment.
