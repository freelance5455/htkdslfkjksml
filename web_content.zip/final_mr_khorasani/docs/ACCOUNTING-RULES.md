# MR,KHORASANI — Accounting Rules

## Double entry invariant
Every posted journal must satisfy `SUM(debit) = SUM(credit)` and must contain a non-zero amount.

## Sales
- Cash/bank sale: financial source is debited; sales is credited.
- Credit sale: customer receivable is debited; sales is credited.
- Mixed sale: cash/bank is debited for the paid amount; customer receivable is debited for the balance; sales is credited.
- Permanent inventory mode adds COGS debit and inventory credit.

## Purchases
- Cash/bank purchase: inventory/purchase account is debited; financial source is credited.
- Credit purchase: inventory/purchase account is debited; supplier payable is credited.
- Shipping and discount are represented as invoice-level values and enter the Accounting Engine rather than being posted by UI code.

## Discounts
Only one discount input mode is primary:
- `percent`: discount amount = gross × percent / 100
- `amount`: percentage is derived from gross and amount

The UI does not accept two independent discount inputs as competing sources of truth.

## Shipping
Invoice final amount uses the base rule:
`Final = Gross - Discount + Shipping`

The accounting mapping for shipping remains centralized in the Accounting Engine and can be changed without changing the UI form.

## Closed days
A closed day cannot accept direct modification. Correction must be recorded through a reversal or adjustment journal linked to the original journal.

## Soft deletion
Physical deletion is not used for posted business records. Deleted records retain status, actor, timestamp and reason in the audit trail.
