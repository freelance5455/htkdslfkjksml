# MR,KHORASANI — Final Build Status

## Source package
Version: 1.1.0
Android application ID: `com.mrkhrasani.finance`
Minimum Android: API 24
Target/Compile SDK: 35
Java: 17

## Build verification performed in this environment
- Android source structure inspected.
- `MainActivity.java` and `BackupBridge.java` inspected.
- Manifest and Gradle configuration inspected.
- GitHub Actions workflow corrected to the actual Android project path.
- Local Gradle build was attempted.

## Current blocker
The execution environment does not contain the Android SDK/Build Tools and does not have network access to download Gradle 8.13. The local build therefore stops before compilation with an inability to resolve `services.gradle.org`.

## Important
No APK is represented as final until a real Android build produces the APK successfully. This package includes a root-level GitHub Actions workflow that builds the installable debug APK on a GitHub runner with Java 17, Android SDK 35 and Gradle 8.13, then publishes the APK and SHA-256 checksum as Actions artifacts.

## Preview fix — 2026-09-29
- Root cause of the broken ZIP-to-APK preview identified: the Grok iOS Home Screen tutorial middleware intercepted `?install=1&platform=ios` on generic preview hosts. Those hosts do not serve the `/__grok/install/*` tutorial assets, producing broken images, missing CSS, and the unresolved `{{APP_NAME}}` placeholder shown in the screenshot.
- Fixed both the Vite preview middleware and deployed Nitro middleware so the iOS install tutorial is served only on published `*.grok.me` hosts. Generic preview/converter hosts now render the actual MR,KHORASANI application instead of the tutorial page.
- Added a regression test for published-vs-preview host detection.
- Syntax checks pass for the modified PWA files. The full legacy PWA test file contains pre-existing unrelated identity/card test failures in this workspace; those were not introduced by this preview fix.
