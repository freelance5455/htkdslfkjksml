import { createFileRoute, Navigate } from "@tanstack/react-router";
import { useState } from "react";
import { GROK_PROVIDERS, authClient, authEnabled, signIn } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { Mark } from "@/components/logo";
import { Button } from "@/components/ui/button";
import { Input, Label } from "@/components/ui/field";
import { Splash } from "@/components/splash";

export const Route = createFileRoute("/login")({ component: Login });

function normalizeEmail(raw: string) {
  const v = raw.trim();
  if (!v) return "";
  if (v.includes("@")) return v;
  const digits = v.replace(/\D/g, "");
  return `${digits || v}@mrkhorasani.app`;
}

function Login() {
  const { user, isPending } = useCurrentUserState();
  const [mode, setMode] = useState<"in" | "up">("in");
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (isPending) return <Splash label="در حال بررسی نشست…" />;
  if (user) return <Navigate to="/" />;

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      const email = normalizeEmail(identifier);
      if (!email || password.length < 6) {
        setError("ایمیل/موبایل و رمز حداقل ۶ کاراکتر لازم است.");
        return;
      }
      if (mode === "up") {
        const { error: err } = await authClient.signUp.email({
          email,
          password,
          name: name.trim() || "کاربر",
        });
        if (err) throw new Error(err.message);
      } else {
        const { error: err } = await authClient.signIn.email({ email, password });
        if (err) throw new Error(err.message);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "ورود ناموفق بود.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="relative min-h-dvh overflow-hidden bg-navy text-paper">
      <div className="pointer-events-none absolute inset-0 opacity-40" style={{ background: "radial-gradient(1200px 500px at 80% -10%, #c4a35a33, transparent)" }} />
      <div className="mx-auto grid min-h-dvh max-w-6xl lg:grid-cols-[1.1fr_0.9fr]">
        <section className="hidden flex-col justify-between p-10 lg:flex">
          <Mark className="size-14" />
          <div>
            <p className="font-display text-5xl leading-tight text-gold-soft">MR,KHORASANI</p>
            <p className="mt-3 max-w-md text-sm leading-7 text-gold-soft/70">
              سامانه حرفه‌ای حسابداری دوبل، خزانه، عملیات روزانه، گزارش‌های مدیریتی و کنترل داخلی. هر رویداد مالی یک سند متوازن می‌سازد.
            </p>
            <div className="gold-rule mt-8 w-48" />
            <p className="mt-4 text-xs tracking-[0.2em] text-gold/60 uppercase">Professional Accounting System</p>
          </div>
          <p className="text-xs text-gold/40">ثبت آفلاین · همگام‌سازی ابری · مسیر حسابرسی کامل</p>
        </section>
        <section className="flex items-center justify-center p-5 sm:p-10">
          <div className="w-full max-w-md rounded-xl bg-paper p-6 text-ink shadow-[0_24px_80px_-32px_rgba(0,0,0,0.5)] sm:p-8">
            <div className="mb-6 flex justify-center lg:hidden">
              <Mark className="size-14" />
            </div>
            <h1 className="text-center font-display text-2xl text-navy">ورود به دفتر</h1>
            <p className="mt-1 text-center text-sm text-muted">Financial Management & Accounting</p>
            <div className="mt-5 grid grid-cols-2 rounded-lg bg-paper-2 p-1">
              <button type="button" className={`h-10 rounded-md text-sm ${mode === "in" ? "bg-navy text-gold-soft" : "text-muted"}`} onClick={() => setMode("in")}>ورود</button>
              <button type="button" className={`h-10 rounded-md text-sm ${mode === "up" ? "bg-navy text-gold-soft" : "text-muted"}`} onClick={() => setMode("up")}>ثبت‌نام</button>
            </div>
            <form className="mt-5 space-y-3" onSubmit={onSubmit}>
              {mode === "up" && (
                <div>
                  <Label>نام</Label>
                  <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="نام نمایشی" />
                </div>
              )}
              <div>
                <Label>ایمیل یا موبایل</Label>
                <Input value={identifier} onChange={(e) => setIdentifier(e.target.value)} autoComplete="username" dir="ltr" placeholder="email@domain.com" />
              </div>
              <div>
                <Label>رمز عبور</Label>
                <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete={mode === "up" ? "new-password" : "current-password"} dir="ltr" />
              </div>
              {error && <p className="text-sm text-danger">{error}</p>}
              <Button className="w-full" disabled={busy || !authEnabled} type="submit">
                {busy ? "لطفاً صبر کنید…" : mode === "up" ? "ایجاد حساب" : "ورود"}
              </Button>
            </form>
            {authEnabled && (
              <>
                <div className="my-5 flex items-center gap-3 text-xs text-muted">
                  <span className="h-px flex-1 bg-line" />
                  ورود با حساب دیگر
                  <span className="h-px flex-1 bg-line" />
                </div>
                <div className="space-y-2">
                  {GROK_PROVIDERS.map((p) => (
                    <Button key={p.providerId} type="button" variant="outline" className="w-full" onClick={() => signIn(p.providerId, { callbackURL: "/" })}>
                      ادامه با {p.label}
                    </Button>
                  ))}
                </div>
              </>
            )}
          </div>
        </section>
      </div>
    </main>
  );
}
