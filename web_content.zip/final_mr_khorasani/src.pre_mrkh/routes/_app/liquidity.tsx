import { createFileRoute } from "@tanstack/react-router";
import { LiquidityPage } from "@/pages/liquidity";

export const Route = createFileRoute("/_app/liquidity")({ component: LiquidityPage });
