import { createFileRoute } from "@tanstack/react-router";
import { KpiPage } from "@/pages/kpi";

export const Route = createFileRoute("/_app/kpi")({ component: KpiPage });
