import { createFileRoute } from "@tanstack/react-router";
import { JournalsPage } from "@/pages/journals";

export const Route = createFileRoute("/_app/journals")({ component: JournalsPage });
