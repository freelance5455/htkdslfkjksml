import { createFileRoute } from "@tanstack/react-router";
import { BackupPage } from "@/pages/backup";

export const Route = createFileRoute("/_app/backup")({ component: BackupPage });
