import { createFileRoute } from "@tanstack/react-router";
import { PartiesPage } from "@/pages/parties";

export const Route = createFileRoute("/_app/parties")({ component: PartiesPage });
