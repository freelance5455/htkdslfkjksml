import { createFileRoute } from "@tanstack/react-router";
import { ChecksPage } from "@/pages/checks";

export const Route = createFileRoute("/_app/checks")({ component: ChecksPage });
