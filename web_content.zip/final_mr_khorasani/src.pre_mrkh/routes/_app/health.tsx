import { createFileRoute } from "@tanstack/react-router";
import { HealthPage } from "@/pages/health";

export const Route = createFileRoute("/_app/health")({ component: HealthPage });
