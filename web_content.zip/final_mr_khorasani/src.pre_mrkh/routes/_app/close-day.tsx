import { createFileRoute } from "@tanstack/react-router";
import { CloseDayPage } from "@/pages/close-day";

export const Route = createFileRoute("/_app/close-day")({ component: CloseDayPage });
