import { createFileRoute } from "@tanstack/react-router";
import { OpsPage } from "@/pages/ops";

export const Route = createFileRoute("/_app/ops")({ component: OpsPage });
