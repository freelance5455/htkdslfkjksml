import { createFileRoute } from "@tanstack/react-router";
import { CrmPage } from "@/pages/crm";

export const Route = createFileRoute("/_app/crm")({ component: CrmPage });
