import { formatJalali } from "@/lib/accounting/jalali";
import { Card, PageHeader } from "@/components/page";
import { useBooks } from "@/lib/store/books-store";

export function AuditPage() {
  const books = useBooks((s) => s.books)!;
  return (
    <div>
      <PageHeader title="مسیر حسابرسی" kicker="چه کسی · چه چیزی · چه زمانی" />
      <Card className="overflow-x-auto p-0">
        <table className="w-full min-w-[800px] text-sm">
          <thead className="bg-navy text-gold-soft">
            <tr>{["زمان","کاربر","عملیات","موجودیت","شناسه","روز","توضیح"].map((h) => <th key={h} className="px-3 py-2 text-right">{h}</th>)}</tr>
          </thead>
          <tbody>
            {books.auditLogs.slice(0, 200).map((e) => (
              <tr key={e.id} className="border-t border-line">
                <td className="px-3 py-2">{e.at.slice(0, 19).replace("T", " ")}</td>
                <td className="px-3 py-2">{e.userName}</td>
                <td className="px-3 py-2">{e.action}</td>
                <td className="px-3 py-2">{e.entity}</td>
                <td className="px-3 py-2 text-xs">{e.entityId.slice(0, 12)}</td>
                <td className="px-3 py-2">{e.dayKey ? formatJalali(e.dayKey) : "—"}</td>
                <td className="px-3 py-2">{e.reason ?? ""}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
}
