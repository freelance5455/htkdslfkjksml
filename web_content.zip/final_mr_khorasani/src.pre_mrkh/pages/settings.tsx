import { toast } from "sonner";
import { ROLE_LABEL } from "@/lib/accounting/format";
import { Card, PageHeader } from "@/components/page";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/field";
import { useBooks } from "@/lib/store/books-store";
import type { RoleId } from "@/lib/accounting/types";

export function SettingsPage() {
  const books = useBooks((s) => s.books)!;
  const patch = useBooks((s) => s.patch);
  const resetDemo = useBooks((s) => s.resetDemo);
  const resetEmpty = useBooks((s) => s.resetEmpty);
  const fy = books.fiscalYears.find((y) => y.isCurrent);

  return (
    <div>
      <PageHeader title="تنظیمات" kicker="شرکت، سال مالی، دسترسی" />
      <div className="grid gap-3 lg:grid-cols-2">
        <Card>
          <h2 className="mb-3 font-medium">شرکت</h2>
          <div className="space-y-3">
            <Field label="نام"><Input value={books.company.name} onChange={(e) => patch((b) => { b.company.name = e.target.value; b.settings.company.name = e.target.value; }, "ModifyAccount")} /></Field>
            <Field label="شناسه ملی"><Input value={books.company.nationalId} onChange={(e) => patch((b) => { b.company.nationalId = e.target.value; }, "ModifyAccount")} /></Field>
            <Field label="تلفن"><Input value={books.company.phone} onChange={(e) => patch((b) => { b.company.phone = e.target.value; }, "ModifyAccount")} /></Field>
          </div>
        </Card>
        <Card>
          <h2 className="mb-3 font-medium">نمایش و نقش</h2>
          <label className="flex min-h-11 items-center gap-2 text-sm">
            <input type="checkbox" checked={books.settings.persianDigits} onChange={(e) => patch((b) => { b.settings.persianDigits = e.target.checked; }, "ModifyAccount")} />
            ارقام فارسی
          </label>
          <label className="flex min-h-11 items-center gap-2 text-sm">
            <input type="checkbox" checked={books.settings.displayToman} onChange={(e) => patch((b) => { b.settings.displayToman = e.target.checked; }, "ModifyAccount")} />
            نمایش به تومان
          </label>
          <label className="flex min-h-11 items-center gap-2 text-sm">
            <input type="checkbox" checked={books.settings.perpetualInventory} onChange={(e) => patch((b) => { b.settings.perpetualInventory = e.target.checked; }, "ModifyAccount")} />
            موجودی دائمی (بهای تمام‌شده خودکار)
          </label>
          <Field label="نقش جاری این نشست">
            <Select value={books.settings.role} onChange={(e) => patch((b) => { b.settings.role = e.target.value as RoleId; }, "ChangePermission")}>
              {Object.entries(ROLE_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
            </Select>
          </Field>
        </Card>
        <Card>
          <h2 className="mb-3 font-medium">سال مالی</h2>
          <p className="text-sm">{fy?.name}</p>
          <p className="text-sm text-muted">{fy?.startDate} تا {fy?.endDate} · {fy?.status === "open" ? "باز" : "بسته"}</p>
        </Card>
        <Card>
          <h2 className="mb-3 font-medium">داده‌ها</h2>
          <p className="text-sm text-muted">بازنشانی، دفتر نمونه را دوباره می‌سازد. این کار روی دستگاه شما اثر می‌گذارد.</p>
          <div className="mt-3 flex flex-wrap gap-2">
            <Button onClick={() => { resetDemo(); toast.success("دفتر نمونه بارگذاری شد"); }}>بارگذاری داده نمونه</Button>
            <Button variant="outline" onClick={() => { resetEmpty(); toast.success("شرکت خالی ایجاد شد"); }}>شروع با شرکت خالی</Button>
          </div>
        </Card>
      </div>
    </div>
  );
}
