import { useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import { OP_LABEL } from "@/lib/accounting/format";
import { formatJalali } from "@/lib/accounting/jalali";
import { Card, PageHeader } from "@/components/page";
import { Input } from "@/components/ui/field";
import { useBooks } from "@/lib/store/books-store";

export function SearchPage() {
  const books = useBooks((s) => s.books)!;
  const [q, setQ] = useState("");
  const hits = useMemo(() => {
    const s = q.trim();
    if (s.length < 2) return [];
    const out: { type: string; title: string; sub: string; to: string }[] = [];
    for (const p of books.parties) if (`${p.name}${p.phone}${p.code}`.includes(s)) out.push({ type: "شخص", title: p.name, sub: p.code, to: "/parties" });
    for (const o of books.operations) if (`${o.number}${o.description}${o.amount}`.includes(s)) out.push({ type: "عملیات", title: `${o.number} ${OP_LABEL[o.kind]}`, sub: formatJalali(o.date), to: "/ops" });
    for (const j of books.journals) if (`${j.number}${j.description}`.includes(s)) out.push({ type: "سند", title: j.number, sub: j.description, to: "/journals" });
    for (const a of books.accounts) if (`${a.code}${a.name}`.includes(s)) out.push({ type: "حساب", title: `${a.code} ${a.name}`, sub: a.class, to: "/accounts" });
    for (const c of books.checks) if (`${c.number}${c.bankName}${c.amount}`.includes(s)) out.push({ type: "چک", title: c.number, sub: String(c.amount), to: "/checks" });
    return out.slice(0, 40);
  }, [books, q]);

  return (
    <div>
      <PageHeader title="جستجوی سراسری" kicker="شخص، سند، مبلغ، چک، حساب" />
      <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="حداقل دو نویسه…" autoFocus />
      <div className="mt-4 space-y-2">
        {hits.map((h, i) => (
          <Link key={i} to={h.to} className="block">
            <Card>
              <div className="text-xs text-gold">{h.type}</div>
              <div className="text-navy">{h.title}</div>
              <div className="text-xs text-muted">{h.sub}</div>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  );
}
