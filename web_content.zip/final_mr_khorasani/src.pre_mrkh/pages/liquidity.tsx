import { todayIso } from "@/lib/accounting/jalali";
import { liquidity } from "@/lib/accounting/reports";
import { moneyBalance } from "@/lib/accounting/engine";
import { Money } from "@/components/money";
import { Card, PageHeader, Stat } from "@/components/page";
import { useBooks } from "@/lib/store/books-store";
import { useState } from "react";

export function LiquidityPage() {
  const books = useBooks((s) => s.books)!;
  const [h, setH] = useState(7);
  const l = liquidity(books, todayIso(), h);
  return (
    <div>
      <PageHeader title="مدیریت نقدینگی" kicker="صندوق · بانک · تنخواه · تعهدات" />
      <div className="mb-3 flex gap-2">
        {[1, 7, 30].map((n) => (
          <button key={n} type="button" onClick={() => setH(n)} className={`h-11 rounded-md px-4 text-sm ${h === n ? "bg-navy text-gold-soft" : "bg-card"}`}>{n === 1 ? "امروز" : `${n} روز`}</button>
        ))}
      </div>
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="موجودی نقد"><Money value={l.total} /></Stat>
        <Stat label="صندوق"><Money value={l.cash} /></Stat>
        <Stat label="بانک"><Money value={l.bank} /></Stat>
        <Stat label="تنخواه"><Money value={l.petty} /></Stat>
        <Stat label="دریافت امروز"><Money value={l.receiptsToday} /></Stat>
        <Stat label="پرداخت امروز"><Money value={l.paymentsToday} /></Stat>
        <Stat label="خالص جریان امروز"><Money value={l.netToday} signed /></Stat>
        <Stat label="چک دریافتی"><Money value={l.recChecks} /></Stat>
        <Stat label="چک پرداختی"><Money value={l.issChecks} /></Stat>
        <Stat label="مطالبات"><Money value={l.ar} /></Stat>
        <Stat label="بدهی‌ها"><Money value={l.ap} /></Stat>
        <Stat label="پیش‌بینی افق"><Money value={l.forecast} /></Stat>
      </div>
      <Card className="mt-4">
        <h2 className="mb-2 text-sm font-medium">منابع مالی</h2>
        {books.moneyAccounts.map((m) => (
          <div key={m.id} className="flex justify-between border-b border-line py-2 text-sm">
            <span>{m.name}{m.accountNo ? ` · ${m.accountNo}` : ""}</span>
            <Money value={moneyBalance(books, m.id)} />
          </div>
        ))}
      </Card>
    </div>
  );
}
