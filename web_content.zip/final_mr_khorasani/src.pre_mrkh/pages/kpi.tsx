import { currentFy } from "@/lib/accounting/engine";
import { todayIso } from "@/lib/accounting/jalali";
import { kpi } from "@/lib/accounting/reports";
import { Money } from "@/components/money";
import { Card, PageHeader, Stat } from "@/components/page";
import { useBooks } from "@/lib/store/books-store";

export function KpiPage() {
  const books = useBooks((s) => s.books)!;
  const fy = currentFy(books);
  const k = kpi(books, fy?.startDate ?? "2026-03-21", todayIso());
  return (
    <div>
      <PageHeader title="شاخص‌های مدیریتی" kicker="KPI" />
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="فروش دوره"><Money value={k.sales} /></Stat>
        <Stat label="تعداد فروش">{k.saleCount}</Stat>
        <Stat label="متوسط فروش"><Money value={k.avgSale} /></Stat>
        <Stat label="وصول"><Money value={k.collection} /></Stat>
        <Stat label="درصد وصول">{k.collectionRate}٪</Stat>
        <Stat label="مطالبات باز"><Money value={k.openAr} /></Stat>
        <Stat label="بدهی باز"><Money value={k.openAp} /></Stat>
        <Stat label="هزینه"><Money value={k.expense} /></Stat>
        <Stat label="هزینه به فروش">{k.expenseToSales}٪</Stat>
        <Stat label="موجودی نقد"><Money value={k.cash} /></Stat>
        <Stat label="سود ناخالص"><Money value={k.pnl.gross} /></Stat>
        <Stat label="سود خالص"><Money value={k.pnl.net} /></Stat>
      </div>
      <div className="mt-4 grid gap-3 lg:grid-cols-2">
        <Card>
          <h2 className="mb-2 text-sm font-medium">بزرگ‌ترین بدهکاران</h2>
          {k.topDebtors.map((x) => (
            <div key={x.p.id} className="flex justify-between border-b border-line py-2 text-sm"><span>{x.p.name}</span><Money value={x.b} /></div>
          ))}
        </Card>
        <Card>
          <h2 className="mb-2 text-sm font-medium">بزرگ‌ترین بستانکاران</h2>
          {k.topCreditors.map((x) => (
            <div key={x.p.id} className="flex justify-between border-b border-line py-2 text-sm"><span>{x.p.name}</span><Money value={x.b} /></div>
          ))}
        </Card>
      </div>
    </div>
  );
}
