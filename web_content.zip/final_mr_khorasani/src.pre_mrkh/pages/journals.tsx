import { useState } from "react";
import { liveJournals, sumLines } from "@/lib/accounting/engine";
import { formatJalali } from "@/lib/accounting/jalali";
import { Money } from "@/components/money";
import { Card, PageHeader } from "@/components/page";
import { Input } from "@/components/ui/field";
import { useBooks } from "@/lib/store/books-store";

export function JournalsPage() {
  const books = useBooks((s) => s.books)!;
  const [q, setQ] = useState("");
  const [open, setOpen] = useState<string | null>(null);
  const rows = liveJournals(books).filter((j) => !q || `${j.number}${j.description}`.includes(q));
  const selected = books.journals.find((j) => j.id === open);
  const lines = selected ? books.journalLines.filter((l) => l.journalId === selected.id) : [];
  const tot = sumLines(lines);

  return (
    <div>
      <PageHeader title="دفتر روزنامه / اسناد" kicker="هر سند متوازن است" />
      <Input className="mb-3" value={q} onChange={(e) => setQ(e.target.value)} placeholder="شماره سند یا شرح" />
      <div className="grid gap-3 lg:grid-cols-[1fr_0.9fr]">
        <Card className="p-0 overflow-x-auto">
          <table className="w-full min-w-[560px] text-sm">
            <thead className="bg-navy text-gold-soft">
              <tr>{["شماره", "تاریخ", "شرح", "وضعیت"].map((h) => <th key={h} className="px-3 py-2 text-right font-medium">{h}</th>)}</tr>
            </thead>
            <tbody>
              {rows.map((j) => (
                <tr key={j.id} className="cursor-pointer border-t border-line hover:bg-paper-2" onClick={() => setOpen(j.id)}>
                  <td className="px-3 py-2">{j.number}</td>
                  <td className="px-3 py-2">{formatJalali(j.date)}</td>
                  <td className="px-3 py-2">{j.description}</td>
                  <td className="px-3 py-2">{j.locked ? "قفل" : "باز"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
        <Card>
          {!selected ? <p className="text-sm text-muted">یک سند را انتخاب کنید.</p> : (
            <>
              <h2 className="font-medium text-navy">{selected.number}</h2>
              <p className="text-sm text-muted">{selected.description} · {selected.kind}</p>
              <table className="mt-3 w-full text-sm">
                <thead><tr className="text-muted"><th className="text-right">حساب</th><th className="text-right">بدهکار</th><th className="text-right">بستانکار</th></tr></thead>
                <tbody>
                  {lines.map((l) => {
                    const a = books.accounts.find((x) => x.id === l.accountId);
                    const p = l.partyId ? books.parties.find((x) => x.id === l.partyId) : undefined;
                    return (
                      <tr key={l.id} className="border-t border-line">
                        <td className="py-1">{a?.code} {a?.name}{p ? ` / ${p.name}` : ""}</td>
                        <td><Money value={l.debit} /></td>
                        <td><Money value={l.credit} /></td>
                      </tr>
                    );
                  })}
                </tbody>
                <tfoot>
                  <tr className="border-t border-navy/20 font-medium">
                    <td className="py-2">جمع</td>
                    <td><Money value={tot.debit} /></td>
                    <td><Money value={tot.credit} /></td>
                  </tr>
                </tfoot>
              </table>
              <p className={`mt-2 text-sm ${tot.diff === 0 ? "text-ok" : "text-danger"}`}>اختلاف: {tot.diff}</p>
            </>
          )}
        </Card>
      </div>
    </div>
  );
}
