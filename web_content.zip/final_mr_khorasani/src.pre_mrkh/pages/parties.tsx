import { useState } from "react";
import { toast } from "sonner";
import { partyBalance } from "@/lib/accounting/engine";
import { nid } from "@/lib/accounting/format";
import { PARTY_LABEL } from "@/lib/accounting/format";
import { Money } from "@/components/money";
import { Card, PageHeader } from "@/components/page";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/field";
import { useBooks } from "@/lib/store/books-store";
import type { PartyKind } from "@/lib/accounting/types";

export function PartiesPage() {
  const books = useBooks((s) => s.books)!;
  const patch = useBooks((s) => s.patch);
  const [q, setQ] = useState("");
  const [kind, setKind] = useState<PartyKind | "all">("all");
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [nk, setNk] = useState<PartyKind>("customer");

  const rows = books.parties.filter((p) => {
    if (kind !== "all" && p.kind !== kind) return false;
    if (q && !`${p.name}${p.phone}${p.code}`.includes(q)) return false;
    return p.active;
  });

  return (
    <div>
      <PageHeader title="اشخاص" kicker="مشتری، تأمین‌کننده، کارمند" action={<Button onClick={() => setOpen(true)}>شخص جدید</Button>} />
      <div className="mb-3 flex gap-2">
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="جستجو" />
        <Select value={kind} onChange={(e) => setKind(e.target.value as PartyKind | "all")} className="max-w-40">
          <option value="all">همه</option>
          {Object.entries(PARTY_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
        </Select>
      </div>
      <Card className="overflow-x-auto p-0">
        <table className="w-full min-w-[640px] text-sm">
          <thead className="bg-navy text-gold-soft">
            <tr>{["کد", "نام", "نوع", "تلفن", "مانده"].map((h) => <th key={h} className="px-3 py-2 text-right font-medium">{h}</th>)}</tr>
          </thead>
          <tbody>
            {rows.map((p) => (
              <tr key={p.id} className="border-t border-line">
                <td className="px-3 py-2">{p.code}</td>
                <td className="px-3 py-2">{p.name}</td>
                <td className="px-3 py-2">{PARTY_LABEL[p.kind]}</td>
                <td className="px-3 py-2 dir-ltr">{p.phone}</td>
                <td className="px-3 py-2"><Money value={partyBalance(books, p.id)} signed /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
      {open && (
        <div className="fixed inset-0 z-40 grid place-items-center bg-navy/40 p-4">
          <Card className="w-full max-w-md">
            <h2 className="mb-3 font-medium">شخص جدید</h2>
            <div className="space-y-3">
              <Field label="نام"><Input value={name} onChange={(e) => setName(e.target.value)} /></Field>
              <Field label="نوع"><Select value={nk} onChange={(e) => setNk(e.target.value as PartyKind)}>{Object.entries(PARTY_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</Select></Field>
              <Field label="تلفن"><Input value={phone} onChange={(e) => setPhone(e.target.value)} /></Field>
              <div className="flex gap-2">
                <Button className="flex-1" onClick={() => {
                  if (!name.trim()) return toast.error("نام لازم است");
                  patch((b) => {
                    b.counters.party += 1;
                    b.parties.push({
                      id: nid("pty"),
                      code: `P-${String(b.counters.party).padStart(3, "0")}`,
                      name: name.trim(),
                      kind: nk,
                      phone,
                      address: "",
                      city: "",
                      active: true,
                      note: "",
                      createdAt: new Date().toISOString(),
                    });
                  }, "Create");
                  setOpen(false); setName(""); toast.success("ثبت شد");
                }}>ذخیره</Button>
                <Button variant="outline" onClick={() => setOpen(false)}>انصراف</Button>
              </div>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}
