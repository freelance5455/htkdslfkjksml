import { useMemo, useState } from "react";
import { toast } from "sonner";
import { liveOperations } from "@/lib/accounting/engine";
import { OP_LABEL, parseAmount } from "@/lib/accounting/format";
import { formatJalali, todayIso } from "@/lib/accounting/jalali";
import { Money } from "@/components/money";
import { PageHeader, Card } from "@/components/page";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Textarea } from "@/components/ui/field";
import { useBooks } from "@/lib/store/books-store";
import type { InvoiceLine, OpKind, OperationInput, PayMethod } from "@/lib/accounting/types";

const GROUPS: { title: string; items: OpKind[] }[] = [
  { title: "نقد و خزانه", items: ["receipt", "payment", "transfer", "petty_fund", "petty_settle"] },
  { title: "خرید و فروش", items: ["sale", "sale_return", "purchase", "purchase_return"] },
  { title: "هزینه و درآمد", items: ["expense", "income", "payroll", "depreciation"] },
  { title: "چک", items: ["check_receive", "check_issue", "check_clear", "check_bounce"] },
  { title: "سرمایه و تعدیل", items: ["capital", "draw", "prepaid", "unearned", "manual", "adjustment"] },
];

export function OpsPage() {
  const books = useBooks((s) => s.books)!;
  const post = useBooks((s) => s.post);
  const reverse = useBooks((s) => s.reverse);
  const [kind, setKind] = useState<OpKind | null>(null);
  const [reason, setReason] = useState("");
  const ops = liveOperations(books).slice(0, 30);

  return (
    <div>
      <PageHeader title="عملیات روزانه" kicker="ثبت رویداد مالی" />
      {!kind ? (
        <div className="space-y-5">
          {GROUPS.map((g) => (
            <div key={g.title}>
              <h2 className="mb-2 text-xs text-muted">{g.title}</h2>
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-4">
                {g.items.map((k) => (
                  <button key={k} type="button" onClick={() => setKind(k)} className="min-h-16 rounded-lg bg-card px-3 text-right text-sm text-navy shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-ink)_8%,transparent)] hover:bg-paper-2">
                    {OP_LABEL[k]}
                  </button>
                ))}
              </div>
            </div>
          ))}
          <Card>
            <h2 className="mb-3 text-sm font-medium">آخرین عملیات</h2>
            <div className="space-y-2">
              {ops.map((o) => (
                <div key={o.id} className="flex items-center justify-between gap-3 rounded-md bg-paper px-3 py-2 text-sm">
                  <div>
                    <div className="text-navy">{OP_LABEL[o.kind]} · {o.number}</div>
                    <div className="text-xs text-muted">{formatJalali(o.date)} — {o.description}</div>
                  </div>
                  <div className="text-left">
                    <Money value={o.amount} />
                    <button className="mt-1 block text-xs text-danger" type="button" onClick={() => {
                      const r = reverse(o.id, reason || "حذف منطقی قبل از بستن روز");
                      if (r.error) toast.error(r.error);
                      else toast.success("عملیات با سند برگشت حذف شد");
                    }}>حذف منطقی</button>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      ) : (
        <OpForm
          kind={kind}
          onCancel={() => setKind(null)}
          onSave={(input) => {
            const r = post(input);
            if (r.error) {
              toast.error(r.error);
              return;
            }
            toast.success(`ثبت شد · ${r.number} · سند ${r.journal}`);
            setKind(null);
          }}
        />
      )}
      <input className="sr-only" aria-hidden value={reason} onChange={(e) => setReason(e.target.value)} />
    </div>
  );
}

function OpForm({ kind, onCancel, onSave }: { kind: OpKind; onCancel: () => void; onSave: (i: OperationInput) => void }) {
  const books = useBooks((s) => s.books)!;
  const [date, setDate] = useState(todayIso());
  const [amount, setAmount] = useState("");
  const [desc, setDesc] = useState(OP_LABEL[kind]);
  const [partyId, setPartyId] = useState("");
  const [moneyAccountId, setMoneyAccountId] = useState(books.moneyAccounts[0]?.id ?? "");
  const [destMoneyAccountId, setDestMoneyAccountId] = useState(books.moneyAccounts[1]?.id ?? "");
  const [accountId, setAccountId] = useState("");
  const [method, setMethod] = useState<PayMethod>(kind === "sale" || kind === "purchase" ? "cash" : kind.includes("check") || kind === "manual" || kind === "transfer" ? "none" : "cash");
  const [paidAmount, setPaidAmount] = useState("");
  const [checkNumber, setCheckNumber] = useState("");
  const [checkBank, setCheckBank] = useState("");
  const [checkDue, setCheckDue] = useState(todayIso());
  const [checkId, setCheckId] = useState("");
  const [qty, setQty] = useState("1");
  const [productId, setProductId] = useState(books.products[0]?.id ?? "");
  const [lines, setLines] = useState([{ accountId: books.accounts.find((a) => a.code === "1101")?.id ?? "", debit: "", credit: "", description: "" }]);

  const parties = useMemo(() => {
    if (["sale", "sale_return", "receipt", "check_receive", "unearned"].includes(kind)) return books.parties.filter((p) => p.kind === "customer");
    if (["purchase", "purchase_return", "payment", "check_issue", "prepaid"].includes(kind)) return books.parties.filter((p) => p.kind === "supplier");
    if (kind === "payroll") return books.parties.filter((p) => p.kind === "employee");
    return books.parties;
  }, [books.parties, kind]);

  const expenses = books.accounts.filter((a) => a.class === "expense" && a.isPostable);
  const incomes = books.accounts.filter((a) => (a.class === "income" || a.code === "4101") && a.isPostable);
  const postable = books.accounts.filter((a) => a.isPostable);

  function submit(e: React.FormEvent) {
    e.preventDefault();
    const amt = parseAmount(amount);
    const invoiceLines: InvoiceLine[] | undefined = ["sale", "purchase", "sale_return", "purchase_return"].includes(kind)
      ? [
          {
            productId: productId || undefined,
            description: books.products.find((p) => p.id === productId)?.name ?? desc,
            qty: Number(qty) || 1,
            unitPrice: amt || books.products.find((p) => p.id === productId)?.salePrice || 0,
            discount: 0,
          },
        ]
      : undefined;
    onSave({
      kind,
      method,
      date,
      amount: invoiceLines ? 0 : amt,
      description: desc,
      partyId: partyId || undefined,
      moneyAccountId: moneyAccountId || undefined,
      destMoneyAccountId: destMoneyAccountId || undefined,
      accountId: accountId || undefined,
      paidAmount: parseAmount(paidAmount) || undefined,
      checkNumber: checkNumber || undefined,
      checkBank: checkBank || undefined,
      checkDue: checkDue || undefined,
      checkId: checkId || undefined,
      invoiceLines,
      lines: kind === "manual" || kind === "adjustment"
        ? lines.map((l) => ({ accountId: l.accountId, debit: parseAmount(l.debit), credit: parseAmount(l.credit), description: l.description }))
        : undefined,
    });
  }

  const showMoney = !["manual", "adjustment", "depreciation", "check_receive", "check_issue", "check_bounce"].includes(kind) && method !== "credit";
  const showDest = kind === "transfer" || kind === "petty_fund";
  const showParty = !["transfer", "petty_fund", "depreciation", "manual"].includes(kind);
  const showAccount = ["expense", "income", "payment", "petty_settle", "purchase"].includes(kind);
  const showInvoice = ["sale", "purchase", "sale_return", "purchase_return"].includes(kind);
  const showCheckNew = kind === "check_receive" || kind === "check_issue";
  const showCheckPick = kind === "check_clear" || kind === "check_bounce";

  return (
    <Card>
      <div className="mb-4 flex items-center justify-between">
        <h2 className="font-medium text-navy">{OP_LABEL[kind]}</h2>
        <Button variant="ghost" type="button" onClick={onCancel}>بازگشت</Button>
      </div>
      <form className="grid gap-3 sm:grid-cols-2" onSubmit={submit}>
        <Field label="تاریخ">
          <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
        </Field>
        {["sale", "purchase"].includes(kind) && (
          <Field label="روش تسویه">
            <Select value={method} onChange={(e) => setMethod(e.target.value as PayMethod)}>
              <option value="cash">نقدی (صندوق)</option>
              <option value="bank">بانکی</option>
              <option value="credit">نسیه</option>
              <option value="mixed">ترکیبی</option>
            </Select>
          </Field>
        )}
        {["receipt", "payment", "expense", "income"].includes(kind) && (
          <Field label="منبع">
            <Select value={method} onChange={(e) => setMethod(e.target.value as PayMethod)}>
              <option value="cash">صندوق</option>
              <option value="bank">بانک</option>
              {kind !== "receipt" && kind !== "income" ? <option value="credit">نسیه / پرداختنی</option> : null}
            </Select>
          </Field>
        )}
        {showParty && (
          <Field label="شخص">
            <Select value={partyId} onChange={(e) => setPartyId(e.target.value)}>
              <option value="">— انتخاب —</option>
              {parties.map((p) => (
                <option key={p.id} value={p.id}>{p.name}</option>
              ))}
            </Select>
          </Field>
        )}
        {showMoney && (
          <Field label="صندوق / بانک">
            <Select value={moneyAccountId} onChange={(e) => setMoneyAccountId(e.target.value)}>
              {books.moneyAccounts.filter((m) => method === "bank" ? m.kind === "bank" : method === "cash" ? m.kind !== "bank" : true).map((m) => (
                <option key={m.id} value={m.id}>{m.name}</option>
              ))}
            </Select>
          </Field>
        )}
        {showDest && (
          <Field label="مقصد">
            <Select value={destMoneyAccountId} onChange={(e) => setDestMoneyAccountId(e.target.value)}>
              {books.moneyAccounts.map((m) => (
                <option key={m.id} value={m.id}>{m.name}</option>
              ))}
            </Select>
          </Field>
        )}
        {showAccount && (
          <Field label="حساب">
            <Select value={accountId} onChange={(e) => setAccountId(e.target.value)}>
              <option value="">پیش‌فرض</option>
              {(kind === "income" ? incomes : kind === "purchase" ? postable : expenses).map((a) => (
                <option key={a.id} value={a.id}>{a.code} — {a.name}</option>
              ))}
            </Select>
          </Field>
        )}
        {showInvoice && (
          <>
            <Field label="کالا">
              <Select value={productId} onChange={(e) => setProductId(e.target.value)}>
                {books.products.map((p) => (
                  <option key={p.id} value={p.id}>{p.name}</option>
                ))}
              </Select>
            </Field>
            <Field label="تعداد">
              <Input value={qty} onChange={(e) => setQty(e.target.value)} inputMode="numeric" />
            </Field>
          </>
        )}
        <Field label={showInvoice ? "فی (خالی = قیمت کالا)" : "مبلغ"}>
          <Input value={amount} onChange={(e) => setAmount(e.target.value)} inputMode="numeric" dir="ltr" />
        </Field>
        {method === "mixed" && (
          <Field label="مبلغ نقد دریافت‌شده">
            <Input value={paidAmount} onChange={(e) => setPaidAmount(e.target.value)} inputMode="numeric" dir="ltr" />
          </Field>
        )}
        {showCheckNew && (
          <>
            <Field label="شماره چک"><Input value={checkNumber} onChange={(e) => setCheckNumber(e.target.value)} /></Field>
            <Field label="بانک"><Input value={checkBank} onChange={(e) => setCheckBank(e.target.value)} /></Field>
            <Field label="سررسید"><Input type="date" value={checkDue} onChange={(e) => setCheckDue(e.target.value)} /></Field>
          </>
        )}
        {showCheckPick && (
          <Field label="چک">
            <Select value={checkId} onChange={(e) => setCheckId(e.target.value)}>
              <option value="">— انتخاب —</option>
              {books.checks.filter((c) => c.status === "pending").map((c) => (
                <option key={c.id} value={c.id}>{c.number} — {c.amount.toLocaleString("en-US")}</option>
              ))}
            </Select>
          </Field>
        )}
        {(kind === "manual" || kind === "adjustment") && (
          <div className="sm:col-span-2 space-y-2">
            {lines.map((l, i) => (
              <div key={i} className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                <Select value={l.accountId} onChange={(e) => setLines((xs) => xs.map((x, n) => n === i ? { ...x, accountId: e.target.value } : x))}>
                  {postable.map((a) => <option key={a.id} value={a.id}>{a.code} {a.name}</option>)}
                </Select>
                <Input placeholder="بدهکار" value={l.debit} onChange={(e) => setLines((xs) => xs.map((x, n) => n === i ? { ...x, debit: e.target.value } : x))} />
                <Input placeholder="بستانکار" value={l.credit} onChange={(e) => setLines((xs) => xs.map((x, n) => n === i ? { ...x, credit: e.target.value } : x))} />
                <Input placeholder="شرح" value={l.description} onChange={(e) => setLines((xs) => xs.map((x, n) => n === i ? { ...x, description: e.target.value } : x))} />
              </div>
            ))}
            <Button type="button" variant="outline" onClick={() => setLines((xs) => [...xs, { accountId: postable[0]?.id ?? "", debit: "", credit: "", description: "" }])}>ردیف جدید</Button>
          </div>
        )}
        <div className="sm:col-span-2">
          <Field label="شرح">
            <Textarea value={desc} onChange={(e) => setDesc(e.target.value)} />
          </Field>
        </div>
        <div className="sm:col-span-2">
          <Button className="w-full" type="submit">ثبت عملیات</Button>
        </div>
      </form>
    </Card>
  );
}
