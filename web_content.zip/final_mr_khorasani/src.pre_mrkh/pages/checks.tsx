import { formatJalali } from "@/lib/accounting/jalali";
import { Money } from "@/components/money";
import { Card, PageHeader } from "@/components/page";
import { useBooks } from "@/lib/store/books-store";

const ST: Record<string, string> = { pending: "در جریان", cleared: "وصول", bounced: "برگشت", transferred: "واگذار" };

export function ChecksPage() {
  const books = useBooks((s) => s.books)!;
  return (
    <div>
      <PageHeader title="مدیریت چک‌ها" kicker="دریافتی و پرداختی" />
      <Card className="overflow-x-auto p-0">
        <table className="w-full min-w-[720px] text-sm">
          <thead className="bg-navy text-gold-soft">
            <tr>{["شماره","نوع","بانک","مبلغ","صدور","سررسید","شخص","وضعیت"].map((h) => <th key={h} className="px-3 py-2 text-right">{h}</th>)}</tr>
          </thead>
          <tbody>
            {books.checks.map((c) => {
              const p = c.partyId ? books.parties.find((x) => x.id === c.partyId) : undefined;
              return (
                <tr key={c.id} className="border-t border-line">
                  <td className="px-3 py-2">{c.number}</td>
                  <td className="px-3 py-2">{c.kind === "received" ? "دریافتی" : "پرداختی"}</td>
                  <td className="px-3 py-2">{c.bankName}</td>
                  <td className="px-3 py-2"><Money value={c.amount} /></td>
                  <td className="px-3 py-2">{formatJalali(c.issueDate)}</td>
                  <td className="px-3 py-2">{formatJalali(c.dueDate)}</td>
                  <td className="px-3 py-2">{p?.name ?? "—"}</td>
                  <td className="px-3 py-2">{ST[c.status]}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </Card>
    </div>
  );
}
