import { useState } from "react";
import { toast } from "sonner";
import { closeDayChecks, isDayClosed } from "@/lib/accounting/engine";
import { formatJalali, todayIso } from "@/lib/accounting/jalali";
import { Card, PageHeader } from "@/components/page";
import { Button } from "@/components/ui/button";
import { Field, Input, Textarea } from "@/components/ui/field";
import { useBooks } from "@/lib/store/books-store";

export function CloseDayPage() {
  const books = useBooks((s) => s.books)!;
  const close = useBooks((s) => s.close);
  const amend = useBooks((s) => s.amend);
  const [day, setDay] = useState(todayIso());
  const [confirm, setConfirm] = useState(false);
  const [reason, setReason] = useState("");
  const checks = closeDayChecks(books, day);
  const closed = isDayClosed(books, day);
  const allOk = checks.every((c) => c.ok);

  return (
    <div>
      <PageHeader title="بستن روز" kicker="کنترل داخلی و قفل اسناد" />
      <Field label="روز"><Input type="date" value={day} onChange={(e) => setDay(e.target.value)} /></Field>
      <p className="mt-2 text-sm text-muted">{formatJalali(day)}</p>
      <div className="mt-4 space-y-2">
        {checks.map((c) => (
          <Card key={c.key} className={c.ok ? "" : "shadow-[0_0_0_1px_var(--color-danger)]"}>
            <div className="flex justify-between text-sm">
              <span>{c.detail}</span>
              <span className={c.ok ? "text-ok" : "text-danger"}>{c.ok ? "قبول" : "رد"}</span>
            </div>
          </Card>
        ))}
      </div>
      {!closed ? (
        <div className="mt-5 rounded-xl bg-navy p-5 text-gold-soft">
          <p className="text-sm leading-7">پس از بستن روز، اطلاعات این روز قابل ویرایش مستقیم نخواهد بود. اصلاح فقط از طریق سند اصلاحی / برگشت انجام می‌شود.</p>
          <label className="mt-3 flex items-center gap-2 text-sm">
            <input type="checkbox" checked={confirm} onChange={(e) => setConfirm(e.target.checked)} />
            تأیید می‌کنم و مسئولیت قفل روز را می‌پذیرم.
          </label>
          <Button className="mt-4 w-full" variant="gold" disabled={!allOk || !confirm} onClick={() => {
            const r = close(day);
            if (r.error) toast.error(r.error);
            else toast.success("روز بسته شد. پشتیبان روزانه تولید شد.");
          }}>بستن روز</Button>
        </div>
      ) : (
        <Card className="mt-5">
          <p className="text-sm">این روز بسته است. برای اصلاح، درخواست ثبت کنید. مدیر پس از بررسی می‌تواند روز را برای سند اصلاحی باز کند.</p>
          <Textarea className="mt-3" value={reason} onChange={(e) => setReason(e.target.value)} placeholder="دلیل درخواست اصلاح" />
          <Button className="mt-3" onClick={() => {
            const r = amend(day, reason || "درخواست اصلاح روز بسته");
            if (r.error) toast.error(r.error);
            else toast.success("درخواست ثبت شد");
          }}>ثبت درخواست اصلاح</Button>
          <div className="mt-4 space-y-2 text-sm">
            {books.amendmentRequests.filter((a) => a.dayKey === day).map((a) => (
              <div key={a.id} className="rounded-md bg-paper px-3 py-2">{a.status} — {a.reason}</div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}
