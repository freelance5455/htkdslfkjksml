import { useState } from "react";
import { toast } from "sonner";
import { formatJalali } from "@/lib/accounting/jalali";
import { downloadText } from "@/lib/accounting/export";
import { Card, PageHeader } from "@/components/page";
import { Button } from "@/components/ui/button";
import { useBooks } from "@/lib/store/books-store";

export function BackupPage() {
  const books = useBooks((s) => s.books)!;
  const backupNow = useBooks((s) => s.backupNow);
  const restoreBackup = useBooks((s) => s.restoreBackup);
  const replace = useBooks((s) => s.replace);
  const syncNow = useBooks((s) => s.syncNow);
  const cloud = useBooks((s) => s.cloud);
  const lastSync = useBooks((s) => s.lastSync);
  const [busy, setBusy] = useState(false);

  return (
    <div>
      <PageHeader title="پشتیبان و فضای ابری" kicker="Offline-first · Sync" />
      <div className="grid gap-3 sm:grid-cols-2">
        <Card>
          <h2 className="font-medium">وضعیت ابر</h2>
          <p className="mt-2 text-sm text-muted">{cloud === "ok" ? "متصل" : cloud === "syncing" ? "در حال همگام‌سازی" : cloud === "offline" ? "آفلاین — داده‌ها روی دستگاه است" : "آماده"}</p>
          {lastSync && <p className="text-xs text-muted">آخرین همگام‌سازی: {lastSync}</p>}
          <Button className="mt-4" onClick={() => void syncNow()}>همگام‌سازی اکنون</Button>
        </Card>
        <Card>
          <h2 className="font-medium">خروجی فایل</h2>
          <p className="mt-2 text-sm text-muted">یک نسخه کامل JSON از دفتر برای بازیابی آفلاین.</p>
          <div className="mt-4 flex flex-wrap gap-2">
            <Button onClick={() => downloadText(`MR-KHORASANI-Backup-${new Date().toISOString().slice(0,10)}.json`, JSON.stringify(books, null, 2), "application/json")}>دانلود JSON</Button>
            <Button variant="outline" onClick={async () => {
              setBusy(true);
              const r = await backupNow();
              setBusy(false);
              if ("error" in r) toast.error(r.error);
              else toast.success(r.name);
            }} disabled={busy}>پشتیبان ابری</Button>
          </div>
          <label className="mt-3 block text-sm">
            بازیابی از فایل
            <input type="file" accept="application/json" className="mt-1 block w-full text-xs" onChange={async (e) => {
              const f = e.target.files?.[0];
              if (!f) return;
              try {
                const data = JSON.parse(await f.text());
                if (!data.accounts || !data.journals) throw new Error("invalid");
                replace(data);
                toast.success("بازیابی شد");
              } catch {
                toast.error("فایل نامعتبر است");
              }
            }} />
          </label>
        </Card>
      </div>
      <Card className="mt-4">
        <h2 className="mb-2 font-medium">نسخه‌های محلی</h2>
        {books.backups.length === 0 && <p className="text-sm text-muted">هنوز پشتیبانی ثبت نشده. بستن روز به‌صورت خودکار نسخه می‌سازد.</p>}
        {books.backups.map((b) => (
          <div key={b.id} className="flex items-center justify-between border-b border-line py-2 text-sm">
            <div>{b.name}<div className="text-xs text-muted">{formatJalali(b.createdAt.slice(0,10))}</div></div>
            <Button variant="outline" size="sm" onClick={async () => {
              const r = await restoreBackup(b.id);
              if (r.error) toast.error(r.error);
              else toast.success("بازیابی ابری انجام شد");
            }}>بازیابی</Button>
          </div>
        ))}
      </Card>
    </div>
  );
}
