import { useState } from "react";
import { booksHealth, runSelfTests, type TestResult } from "@/lib/accounting/selftest";
import { Card, PageHeader, Stat } from "@/components/page";
import { Button } from "@/components/ui/button";
import { useBooks } from "@/lib/store/books-store";

export function HealthPage() {
  const books = useBooks((s) => s.books)!;
  const cloud = useBooks((s) => s.cloud);
  const lastSync = useBooks((s) => s.lastSync);
  const h = booksHealth(books);
  const [tests, setTests] = useState<TestResult[] | null>(null);

  return (
    <div>
      <PageHeader title="سلامت سیستم" kicker="کنترل تراز، همگام‌سازی، آزمون موتور" />
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="عملیات امروز">{h.opsToday}</Stat>
        <Stat label="اسناد">{h.journals}</Stat>
        <Stat label="اسناد نامتوازن">{h.unbalanced}</Stat>
        <Stat label="اختلاف تراز">{h.tbDiff}</Stat>
        <Stat label="رویداد حسابرسی">{h.audit}</Stat>
        <Stat label="روزهای بسته‌شده">{h.closedDays}</Stat>
        <Stat label="وضعیت ابر">{cloud}</Stat>
        <Stat label="آخرین همگام‌سازی">{lastSync ? lastSync.slice(11, 19) : "—"}</Stat>
      </div>
      <Card className="mt-4">
        <h2 className="font-medium">آزمون‌های حسابداری</h2>
        <p className="mt-1 text-sm text-muted">روی یک نسخه حافظه‌ای اجرا می‌شود و دفتر فعلی را تغییر نمی‌دهد.</p>
        <Button className="mt-3" onClick={() => setTests(runSelfTests())}>اجرای آزمون‌ها</Button>
        {tests && (
          <ul className="mt-4 space-y-2 text-sm">
            {tests.map((t) => (
              <li key={t.name} className="flex justify-between gap-3 rounded-md bg-paper px-3 py-2">
                <span>{t.name}<div className="text-xs text-muted">{t.detail}</div></span>
                <span className={t.ok ? "text-ok" : "text-danger"}>{t.ok ? "قبول" : "رد"}</span>
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
}
