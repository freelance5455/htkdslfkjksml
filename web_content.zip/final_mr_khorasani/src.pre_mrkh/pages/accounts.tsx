import { accountBalance } from "@/lib/accounting/engine";
import { Money } from "@/components/money";
import { Card, PageHeader } from "@/components/page";
import { useBooks } from "@/lib/store/books-store";

export function AccountsPage() {
  const books = useBooks((s) => s.books)!;
  return (
    <div>
      <PageHeader title="کدینگ حساب‌ها" kicker="چهار سطحی · تفصیلی شناور" />
      <Card className="overflow-x-auto p-0">
        <table className="w-full min-w-[720px] text-sm">
          <thead className="bg-navy text-gold-soft">
            <tr>{["کد", "نام", "سطح", "ماهیت", "مانده"].map((h) => <th key={h} className="px-3 py-2 text-right font-medium">{h}</th>)}</tr>
          </thead>
          <tbody>
            {books.accounts.map((a) => (
              <tr key={a.id} className="border-t border-line">
                <td className="px-3 py-2 tabular">{a.code}</td>
                <td className="px-3 py-2" style={{ paddingRight: `${8 + (a.level - 1) * 16}px` }}>{a.name}</td>
                <td className="px-3 py-2">{a.level}</td>
                <td className="px-3 py-2">{a.nature === "debit" ? "بدهکار" : "بستانکار"}</td>
                <td className="px-3 py-2">{a.isPostable ? <Money value={accountBalance(books, a.id)} /> : "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
}
