import { crmRows } from "@/lib/accounting/reports";
import { formatJalali, todayIso } from "@/lib/accounting/jalali";
import { Money } from "@/components/money";
import { Card, PageHeader } from "@/components/page";
import { useBooks } from "@/lib/store/books-store";

const SEG: Record<string, string> = {
  new: "جدید",
  active: "فعال",
  inactive: "غیرفعال",
  high_balance: "مانده بالا",
  risk: "ریسک وصول",
  rising: "صعودی",
};

export function CrmPage() {
  const books = useBooks((s) => s.books)!;
  const rows = crmRows(books, todayIso());
  const counts = rows.reduce<Record<string, number>>((s, r) => { s[r.segment] = (s[r.segment] ?? 0) + 1; return s; }, {});
  return (
    <div>
      <PageHeader title="CRM مشتریان" kicker="ارزش، مانده، رفتار پرداخت" />
      <div className="mb-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
        {Object.entries(SEG).map(([k, v]) => (
          <Card key={k}><div className="text-xs text-muted">{v}</div><div className="mt-1 text-2xl text-navy">{counts[k] ?? 0}</div></Card>
        ))}
      </div>
      <Card className="overflow-x-auto p-0">
        <table className="w-full min-w-[800px] text-sm">
          <thead className="bg-navy text-gold-soft">
            <tr>{["مشتری","آخرین خرید","تعداد","جمع فروش","متوسط","وصول","مانده","بخش"].map((h) => <th key={h} className="px-3 py-2 text-right">{h}</th>)}</tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.party.id} className="border-t border-line">
                <td className="px-3 py-2">{r.party.name}<div className="text-xs text-muted">{r.party.phone}</div></td>
                <td className="px-3 py-2">{r.lastDate ? formatJalali(r.lastDate) : "—"}</td>
                <td className="px-3 py-2">{r.count}</td>
                <td className="px-3 py-2"><Money value={r.total} /></td>
                <td className="px-3 py-2"><Money value={r.avg} /></td>
                <td className="px-3 py-2"><Money value={r.received} /></td>
                <td className="px-3 py-2"><Money value={r.balance} signed /></td>
                <td className="px-3 py-2">{SEG[r.segment]}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
}
