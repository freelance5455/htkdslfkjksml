import { Link } from "@tanstack/react-router";
import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis } from "recharts";
import { formatJalali, todayIso, toJalali } from "@/lib/accounting/jalali";
import { liveOperations, moneyBalance, partyBalance } from "@/lib/accounting/engine";
import { incomeStatement } from "@/lib/accounting/reports";
import { Money } from "@/components/money";
import { Card, PageHeader } from "@/components/page";
import { useBooks } from "@/lib/store/books-store";

export function DashboardPage() {
  const books = useBooks((s) => s.books)!;
  const today = todayIso();
  const ops = liveOperations(books);
  const todayOps = ops.filter((o) => o.dayKey === today);
  const cash = books.moneyAccounts.filter((m) => m.kind === "cash").reduce((s, m) => s + moneyBalance(books, m.id), 0);
  const bank = books.moneyAccounts.filter((m) => m.kind === "bank").reduce((s, m) => s + moneyBalance(books, m.id), 0);
  const petty = books.moneyAccounts.filter((m) => m.kind === "petty").reduce((s, m) => s + moneyBalance(books, m.id), 0);
  const ar = books.parties.filter((p) => p.kind === "customer").reduce((s, p) => s + Math.max(0, partyBalance(books, p.id)), 0);
  const ap = books.parties.filter((p) => p.kind === "supplier").reduce((s, p) => s + Math.max(0, -partyBalance(books, p.id)), 0);
  const salesToday = todayOps.filter((o) => o.kind === "sale").reduce((s, o) => s + o.amount, 0);
  const recToday = todayOps.filter((o) => o.kind === "receipt").reduce((s, o) => s + o.amount, 0);
  const payToday = todayOps.filter((o) => o.kind === "payment").reduce((s, o) => s + o.amount, 0);
  const expToday = todayOps.filter((o) => o.kind === "expense").reduce((s, o) => s + o.amount, 0);
  const fy = books.fiscalYears.find((y) => y.isCurrent)!;
  const pnl = incomeStatement(books, fy.startDate, today);

  const byDay = new Map<string, { sales: number; rec: number; pay: number }>();
  for (const o of ops) {
    const row = byDay.get(o.date) ?? { sales: 0, rec: 0, pay: 0 };
    if (o.kind === "sale") row.sales += o.amount;
    if (o.kind === "receipt") row.rec += o.amount;
    if (o.kind === "payment") row.pay += o.amount;
    byDay.set(o.date, row);
  }
  const chart = [...byDay.entries()]
    .sort((a, b) => a[0].localeCompare(b[0]))
    .slice(-14)
    .map(([d, v]) => ({ d: formatJalali(d).slice(-5), sales: v.sales / 1_000_000, rec: v.rec / 1_000_000 }));

  const closed = books.dailyClosings.find((d) => d.dayKey === today)?.status === "closed";

  return (
    <div>
      <PageHeader title="داشبورد مدیریتی" kicker={books.company.name} />
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatLink to="/liquidity" label="موجودی نقد" value={cash + bank + petty} />
        <StatLink to="/liquidity" label="بانک" value={bank} />
        <StatLink to="/liquidity" label="صندوق" value={cash} />
        <StatLink to="/crm" label="مطالبات" value={ar} />
        <StatLink to="/parties" label="بدهی‌ها" value={ap} />
        <StatLink to="/ops" label="فروش امروز" value={salesToday} />
        <StatLink to="/ops" label="دریافت امروز" value={recToday} />
        <StatLink to="/ops" label="پرداخت امروز" value={payToday} />
        <StatLink to="/ops" label="هزینه امروز" value={expToday} />
        <StatLink to="/kpi" label="سود تقریبی دوره" value={pnl.net} />
      </div>

      <div className="mt-4 grid gap-3 lg:grid-cols-[1.4fr_0.8fr]">
        <Card>
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-sm font-medium text-navy">روند فروش و دریافت (میلیون ریال)</h2>
            <span className="text-xs text-muted">۱۴ روز</span>
          </div>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chart}>
                <defs>
                  <linearGradient id="g1" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#0b1f3a" stopOpacity={0.35} />
                    <stop offset="100%" stopColor="#0b1f3a" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="d" tick={{ fontSize: 11, fill: "#5e6670" }} axisLine={false} tickLine={false} />
                <Tooltip />
                <Area type="monotone" dataKey="sales" name="فروش" stroke="#0b1f3a" fill="url(#g1)" strokeWidth={2} />
                <Area type="monotone" dataKey="rec" name="دریافت" stroke="#c4a35a" fill="transparent" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>
        <Card>
          <h2 className="text-sm font-medium text-navy">وضعیت امروز</h2>
          <p className="mt-2 text-sm text-muted">{formatJalali(today)} · {toJalali(today).jy}</p>
          <div className={`mt-4 rounded-lg px-3 py-2 text-sm ${closed ? "bg-ok/10 text-ok" : "bg-gold/15 text-navy"}`}>
            {closed ? "روز بسته شده است" : "روز باز است — عملیات قابل ثبت"}
          </div>
          <div className="mt-4 space-y-2 text-sm">
            <Row k="تعداد عملیات امروز" v={String(todayOps.length)} />
            <Row k="اسناد فعال" v={String(books.journals.filter((j) => j.status === "posted").length)} />
            <Row k="چک در جریان" v={String(books.checks.filter((c) => c.status === "pending").length)} />
          </div>
          <Link to="/ops" className="mt-5 flex h-11 items-center justify-center rounded-md bg-navy text-sm text-gold-soft">ثبت عملیات جدید</Link>
        </Card>
      </div>
    </div>
  );
}

function StatLink({ to, label, value }: { to: string; label: string; value: number }) {
  return (
    <Link to={to} className="block">
      <Card>
        <div className="text-xs text-muted">{label}</div>
        <div className="mt-2">
          <Money value={value} className="text-lg font-medium text-navy" />
        </div>
      </Card>
    </Link>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex justify-between gap-3">
      <span className="text-muted">{k}</span>
      <span className="tabular text-navy">{v}</span>
    </div>
  );
}
