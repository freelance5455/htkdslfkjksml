import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { authMiddleware } from "@/lib/auth/middleware";
import { getSql } from "@/lib/db";

function parsePayload(value: unknown) {
  if (value == null) return null;
  if (typeof value === "string") {
    try {
      return JSON.parse(value);
    } catch {
      return null;
    }
  }
  return value;
}

export const pullBooks = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const rows = await sql<{ payload: unknown; version: number; updated_at: string }>`
      select payload, version, updated_at from books_snapshots where user_id = ${context.userId}
    `;
    const row = rows[0];
    if (!row) return null;
    return { payload: parsePayload(row.payload), version: Number(row.version), updatedAt: row.updated_at };
  });

export const pushBooks = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: unknown) => z.object({ payload: z.unknown(), version: z.number() }).parse(data))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const payload = JSON.stringify(data.payload);
    await sql.query(
      `insert into books_snapshots (user_id, payload, version, updated_at)
       values ($1, $2::jsonb, $3, now())
       on conflict (user_id) do update set payload = excluded.payload, version = excluded.version, updated_at = now()`,
      [context.userId, payload, data.version],
    );
    return { ok: true, version: data.version };
  });

export const saveCloudBackup = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: unknown) =>
    z.object({ id: z.string(), name: z.string(), dayKey: z.string().optional(), payload: z.unknown() }).parse(data),
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql.query(
      `insert into books_backups (id, user_id, name, day_key, payload, created_at)
       values ($1, $2, $3, $4, $5::jsonb, now())
       on conflict (id) do nothing`,
      [data.id, context.userId, data.name, data.dayKey ?? null, JSON.stringify(data.payload)],
    );
    return { ok: true };
  });

export const listCloudBackups = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    return sql<{ id: string; name: string; day_key: string | null; created_at: string }>`
      select id, name, day_key, created_at from books_backups
      where user_id = ${context.userId}
      order by created_at desc
      limit 40
    `;
  });

export const loadCloudBackup = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: unknown) => z.object({ id: z.string() }).parse(data))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const rows = await sql<{ payload: unknown }>`
      select payload from books_backups where id = ${data.id} and user_id = ${context.userId}
    `;
    return rows[0] ? parsePayload(rows[0].payload) : null;
  });
