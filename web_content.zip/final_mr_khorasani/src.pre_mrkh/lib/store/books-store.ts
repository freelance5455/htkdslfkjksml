import { create } from "zustand";
import { closeDay, postAdjustment, postOperation, requestAmendment, reverseOperation } from "@/lib/accounting/engine";
import { nid, nowIso } from "@/lib/accounting/format";
import { createDemoBooks, createEmptyCompany } from "@/lib/accounting/seed";
import type { Actor, Books, ManualLineInput, OperationInput } from "@/lib/accounting/types";
import { listCloudBackups, loadCloudBackup, pullBooks, pushBooks, saveCloudBackup } from "@/lib/server/books";

type Status = "boot" | "loading" | "ready" | "error";

type BooksState = {
  status: Status;
  error?: string;
  userId: string | null;
  actor: Actor | null;
  books: Books | null;
  cloud: "idle" | "syncing" | "ok" | "offline" | "error";
  lastSync?: string;
  hydrate: (userId: string, userName: string) => Promise<void>;
  post: (input: OperationInput) => { error?: string; number?: string; journal?: string };
  reverse: (id: string, reason: string) => { error?: string };
  adjust: (journalId: string, lines: ManualLineInput[], date: string, description: string, reason: string) => { error?: string; number?: string };
  close: (dayKey: string) => { error?: string };
  amend: (dayKey: string, reason: string) => { error?: string };
  patch: (mut: (b: Books) => void, action: string) => void;
  replace: (books: Books) => void;
  resetDemo: () => void;
  resetEmpty: () => void;
  syncNow: () => Promise<void>;
  backupNow: (dayKey?: string) => Promise<{ name: string } | { error: string }>;
  restoreBackup: (id: string) => Promise<{ error?: string }>;
};

const keyOf = (userId: string) => `mrk.books.v1.${userId}`;

function loadLocal(userId: string): Books | null {
  try {
    const raw = localStorage.getItem(keyOf(userId));
    if (!raw) return null;
    return JSON.parse(raw) as Books;
  } catch {
    return null;
  }
}

function saveLocal(userId: string, books: Books) {
  try {
    localStorage.setItem(keyOf(userId), JSON.stringify(books));
  } catch {
    /* quota */
  }
}

let pushTimer: ReturnType<typeof setTimeout> | null = null;

export const useBooks = create<BooksState>((set, get) => ({
  status: "boot",
  userId: null,
  actor: null,
  books: null,
  cloud: "idle",

  hydrate: async (userId, userName) => {
    if (get().userId === userId && get().status !== "boot" && get().status !== "error") return;
    set({ status: "loading", userId, actor: { userId, userName, device: "web" } });
    const local = loadLocal(userId);
    let cloud: { payload: Books; version: number; updatedAt: string } | null = null;
    try {
      const pulled = await pullBooks();
      if (pulled?.payload) cloud = pulled as { payload: Books; version: number; updatedAt: string };
    } catch {
      set({ cloud: "offline" });
    }
    let books: Books;
    if (local && cloud) {
      books = local.version >= cloud.version ? local : cloud.payload;
    } else if (local) books = local;
    else if (cloud) books = cloud.payload;
    else {
      try {
        books = createDemoBooks();
      } catch (err) {
        console.error(err);
        books = createEmptyCompany();
      }
    }
    saveLocal(userId, books);
    set({ books, status: "ready", cloud: cloud ? "ok" : get().cloud === "offline" ? "offline" : "idle" });
    if (!cloud || books.version > (cloud.version ?? 0)) {
      void get().syncNow();
    }
  },

  post: (input) => {
    const { books, actor } = get();
    if (!books || !actor) return { error: "سیستم آماده نیست." };
    const r = postOperation(books, input, actor);
    if (!r.ok) return { error: r.error };
    commit(set, get, r.books);
    return { number: r.operation.number, journal: r.journal.number };
  },

  reverse: (id, reason) => {
    const { books, actor } = get();
    if (!books || !actor) return { error: "سیستم آماده نیست." };
    const r = reverseOperation(books, id, actor, reason);
    if (!r.ok) return { error: r.error };
    commit(set, get, r.books);
    return {};
  },

  adjust: (journalId, lines, date, description, reason) => {
    const { books, actor } = get();
    if (!books || !actor) return { error: "سیستم آماده نیست." };
    const r = postAdjustment(books, journalId, lines, date, description, actor, reason);
    if (!r.ok) return { error: r.error };
    commit(set, get, r.books);
    return { number: r.journal.number };
  },

  close: (dayKey) => {
    const { books, actor } = get();
    if (!books || !actor) return { error: "سیستم آماده نیست." };
    const r = closeDay(books, dayKey, actor);
    if (!r.ok) return { error: r.error };
    commit(set, get, r.books);
    void get().backupNow(dayKey);
    return {};
  },

  amend: (dayKey, reason) => {
    const { books, actor } = get();
    if (!books || !actor) return { error: "سیستم آماده نیست." };
    const r = requestAmendment(books, dayKey, actor && reason ? reason : "", actor);
    if (!r.ok) return { error: r.error };
    commit(set, get, r.books);
    return {};
  },

  patch: (mut, action) => {
    const { books, actor, userId } = get();
    if (!books || !actor || !userId) return;
    const next = structuredClone(books);
    mut(next);
    next.version += 1;
    next.updatedAt = nowIso();
    next.auditLogs.unshift({
      id: nid("aud"),
      at: nowIso(),
      userId: actor.userId,
      userName: actor.userName,
      action,
      entity: "books",
      entityId: userId,
      device: actor.device,
    });
    commit(set, get, next);
  },

  replace: (books) => commit(set, get, books),
  resetDemo: () => commit(set, get, createDemoBooks()),
  resetEmpty: () => commit(set, get, createEmptyCompany()),

  syncNow: async () => {
    const { books, userId } = get();
    if (!books || !userId) return;
    set({ cloud: "syncing" });
    try {
      await pushBooks({ data: { payload: books, version: books.version } });
      set({ cloud: "ok", lastSync: nowIso() });
    } catch {
      set({ cloud: "offline" });
    }
  },

  backupNow: async (dayKey) => {
    const { books, actor } = get();
    if (!books || !actor) return { error: "سیستم آماده نیست." };
    const name = `MR-KHORASANI-Backup-${dayKey ?? new Date().toISOString().slice(0, 10)}`;
    const id = nid("bak");
    try {
      await saveCloudBackup({ data: { id, name, dayKey, payload: books } });
      const next = structuredClone(books);
      next.backups.unshift({ id, name, dayKey, createdAt: nowIso(), createdBy: actor.userId, size: JSON.stringify(books).length });
      commit(set, get, next);
      return { name };
    } catch {
      const next = structuredClone(books);
      next.backups.unshift({ id, name, dayKey, createdAt: nowIso(), createdBy: actor.userId, size: JSON.stringify(books).length });
      commit(set, get, next);
      return { name };
    }
  },

  restoreBackup: async (id) => {
    try {
      const payload = await loadCloudBackup({ data: { id } });
      if (!payload) return { error: "نسخه پشتیبان یافت نشد." };
      commit(set, get, payload as Books);
      return {};
    } catch {
      return { error: "بازیابی ابری در دسترس نیست." };
    }
  },
}));

function commit(set: (p: Partial<BooksState>) => void, get: () => BooksState, books: Books) {
  const userId = get().userId;
  if (userId) saveLocal(userId, books);
  set({ books });
  if (pushTimer) clearTimeout(pushTimer);
  pushTimer = setTimeout(() => {
    void get().syncNow();
  }, 1200);
}

export function useCloudBackups() {
  return listCloudBackups;
}
