import { formatJalali, toFaDigits } from "./jalali";
import { formatRial } from "./format";

export function downloadText(filename: string, content: string, mime = "text/plain;charset=utf-8") {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export function toCsv(headers: string[], rows: (string | number)[][]) {
  const esc = (v: string | number) => {
    const s = String(v ?? "");
    if (/[",\n]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
    return s;
  };
  return `\uFEFF${[headers, ...rows].map((r) => r.map(esc).join(",")).join("\n")}`;
}

export function printReport(title: string, company: string, fy: string, bodyHtml: string, user: string) {
  const w = window.open("", "_blank", "noopener,noreferrer,width=900,height=1200");
  if (!w) return;
  w.document.write(`<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"/><title>${title}</title>
  <style>
    body{font-family:Tahoma,Vazirmatn,sans-serif;color:#121820;padding:32px;background:#fff}
    h1{font-size:18px;margin:0 0 4px}
    .meta{color:#5e6670;font-size:12px;margin-bottom:18px}
    table{width:100%;border-collapse:collapse;font-size:12px}
    th,td{border:1px solid #d9d2c3;padding:6px 8px;text-align:right}
    th{background:#0b1f3a;color:#e8d5a8}
    tfoot td{font-weight:700;background:#f3efe4}
    @page{margin:16mm}
  </style></head><body>
  <h1>${title}</h1>
  <div class="meta">${company} · ${fy} · ${formatJalali(new Date().toISOString().slice(0,10))} · تهیه توسط ${user}</div>
  ${bodyHtml}
  </body></html>`);
  w.document.close();
  w.focus();
  w.print();
}

export function faNum(n: number, persian = true) {
  return formatRial(n, persian, false);
}

export { toFaDigits };
