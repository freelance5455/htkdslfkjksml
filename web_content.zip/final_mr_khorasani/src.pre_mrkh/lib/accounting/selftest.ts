import { closeDay, isDayClosed, postAdjustment, postOperation, reverseOperation, trialBalanceDiff } from "./engine";
import { createDemoBooks } from "./seed";
import type { Actor, Books, OperationInput } from "./types";

const actor: Actor = { userId: "qa", userName: "آزمون", device: "test" };

export type TestResult = { name: string; ok: boolean; detail: string };

export function runSelfTests(): TestResult[] {
  const out: TestResult[] = [];
  const push = (name: string, ok: boolean, detail: string) => out.push({ name, ok, detail });

  try {
    let books = createDemoBooks();
    const diff0 = trialBalanceDiff(books);
    push("تراز آزمایشی پس از داده نمونه", diff0 === 0, `اختلاف = ${diff0}`);

    const today = new Date().toISOString().slice(0, 10);
    const cash = books.moneyAccounts.find((m) => m.kind === "cash")!;
    const party = books.parties.find((p) => p.kind === "customer")!;
    const bank = books.moneyAccounts.find((m) => m.kind === "bank")!;
    const rent = books.accounts.find((a) => a.code === "6102")!;

    const kinds: OperationInput[] = [];
    for (let i = 0; i < 25; i++) {
      kinds.push({
        kind: "receipt",
        method: "cash",
        date: today,
        partyId: party.id,
        moneyAccountId: cash.id,
        amount: 100_000 + i * 1000,
        description: `آزمون دریافت ${i}`,
      });
      kinds.push({
        kind: "expense",
        method: "bank",
        date: today,
        moneyAccountId: bank.id,
        accountId: rent.id,
        amount: 50_000 + i * 500,
        description: `آزمون هزینه ${i}`,
      });
      kinds.push({
        kind: "transfer",
        method: "none",
        date: today,
        moneyAccountId: bank.id,
        destMoneyAccountId: cash.id,
        amount: 20_000 + i * 200,
        description: `آزمون انتقال ${i}`,
      });
      kinds.push({
        kind: "sale",
        method: "credit",
        date: today,
        partyId: party.id,
        amount: 0,
        description: `آزمون فروش ${i}`,
        invoiceLines: [{ description: "کالا", qty: 1, unitPrice: 800_000 + i * 1000, discount: 0 }],
      });
    }
    let failed: string | null = null;
    for (const k of kinds) {
      const r = postOperation(books, k, actor);
      if (!r.ok) {
        failed = r.error;
        break;
      }
      books = r.books;
    }
    push("ثبت ۱۰۰ تراکنش متنوع", !failed && kinds.length === 100, failed ?? `${kinds.length} تراکنش ثبت شد`);
    const diff1 = trialBalanceDiff(books);
    push("تراز پس از ۱۰۰ تراکنش", diff1 === 0, `اختلاف = ${diff1}`);

    const live = books.operations.find((o) => o.status === "posted" && o.dayKey === today && o.kind === "receipt");
    if (live) {
      const rev = reverseOperation(books, live.id, actor, "آزمون حذف منطقی");
      push("حذف منطقی قبل از بستن روز", rev.ok, rev.ok ? "عملیات با سند برگشت حذف شد" : rev.error);
      if (rev.ok) books = rev.books;
    } else push("حذف منطقی قبل از بستن روز", false, "عملیات پیدا نشد");

    const closed = closeDay(books, today, actor);
    push("بستن روز", closed.ok, closed.ok ? `روز ${today} بسته شد` : closed.error);
    if (closed.ok) books = closed.books;

    const blocked = postOperation(books, {
      kind: "receipt",
      method: "cash",
      date: today,
      partyId: party.id,
      moneyAccountId: cash.id,
      amount: 1_000_000,
      description: "تلاش غیرمجاز پس از بستن",
    }, actor);
    push("قفل پس از بستن روز", !blocked.ok && blocked.code === "DAY_CLOSED", blocked.ok ? "سیستم اجازه ثبت داد (خطا)" : blocked.error);

    const orig = books.journals.find((j) => j.locked && j.status === "posted");
    if (orig) {
      const adj = postAdjustment(
        books,
        orig.id,
        [
          { accountId: cash.id ? books.accounts.find((a) => a.code === "1101")!.id : books.accounts[0].id, debit: 1_000_000, credit: 0, description: "اصلاح", moneyAccountId: cash.id },
          { accountId: books.accounts.find((a) => a.code === "4103")!.id, debit: 0, credit: 1_000_000, description: "اصلاح" },
        ],
        today,
        "سند اصلاحی آزمون",
        actor,
        "آزمون اصلاحیه",
      );
      push("سند اصلاحی روی روز بسته", adj.ok, adj.ok ? adj.journal.number : adj.error);
      if (adj.ok) books = adj.books;
    } else push("سند اصلاحی روی روز بسته", false, "سند قفل یافت نشد");

    push("روز بسته شده است", isDayClosed(books, today), isDayClosed(books, today) ? "وضعیت Closed" : "روز باز است");
    const diff2 = trialBalanceDiff(books);
    push("تراز نهایی", diff2 === 0, `اختلاف = ${diff2}`);
  } catch (err) {
    push("اجرای مجموعه آزمون", false, err instanceof Error ? err.message : String(err));
  }
  return out;
}

export function booksHealth(books: Books) {
  const today = new Date().toISOString().slice(0, 10);
  const unbalanced = books.journals.filter((j) => {
    if (j.status !== "posted") return false;
    const lines = books.journalLines.filter((l) => l.journalId === j.id);
    const d = lines.reduce((s, l) => s + l.debit, 0);
    const c = lines.reduce((s, l) => s + l.credit, 0);
    return d !== c;
  });
  return {
    opsToday: books.operations.filter((o) => o.dayKey === today && o.status === "posted").length,
    journals: books.journals.filter((j) => j.status === "posted").length,
    unbalanced: unbalanced.length,
    pendingSync: books.operations.filter((o) => o.syncStatus === "pending").length,
    lastBackup: books.backups[0]?.createdAt ?? null,
    openDays: 1,
    closedDays: books.dailyClosings.filter((d) => d.status === "closed").length,
    audit: books.auditLogs.length,
    tbDiff: trialBalanceDiff(books),
  };
}
