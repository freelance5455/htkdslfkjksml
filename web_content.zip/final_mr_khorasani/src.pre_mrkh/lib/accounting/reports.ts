import { liveLines, liveOperations, moneyBalance, partyBalance } from "./engine";
import type { Account, Books } from "./types";

function inRange(date: string, from?: string, to?: string) {
  if (from && date < from) return false;
  if (to && date > to) return false;
  return true;
}

export type TbRow = {
  id: string;
  code: string;
  name: string;
  level: number;
  openingDr: number;
  openingCr: number;
  turnoverDr: number;
  turnoverCr: number;
  remainDr: number;
  remainCr: number;
};

export function trialBalance(books: Books, from: string, to: string, maxLevel = 3): TbRow[] {
  const map = new Map<string, TbRow>();
  const ensure = (a: Account) => {
    if (!map.has(a.id)) {
      map.set(a.id, {
        id: a.id,
        code: a.code,
        name: a.name,
        level: a.level,
        openingDr: 0,
        openingCr: 0,
        turnoverDr: 0,
        turnoverCr: 0,
        remainDr: 0,
        remainCr: 0,
      });
    }
    return map.get(a.id)!;
  };
  for (const line of liveLines(books)) {
    const j = books.journals.find((x) => x.id === line.journalId);
    if (!j) continue;
    const a = books.accounts.find((x) => x.id === line.accountId);
    if (!a) continue;
    const row = ensure(a);
    if (from && j.date < from) {
      row.openingDr += line.debit;
      row.openingCr += line.credit;
    } else if (inRange(j.date, from, to)) {
      row.turnoverDr += line.debit;
      row.turnoverCr += line.credit;
    }
  }
  const rows = [...map.values()].filter((r) => r.level <= maxLevel);
  for (const r of rows) {
    const net = r.openingDr + r.turnoverDr - r.openingCr - r.turnoverCr;
    if (net >= 0) r.remainDr = net;
    else r.remainCr = -net;
  }
  rows.sort((a, b) => a.code.localeCompare(b.code, "en", { numeric: true }));
  return rows;
}

export function tbTotals(rows: TbRow[]) {
  return rows.reduce(
    (s, r) => {
      s.openingDr += r.openingDr;
      s.openingCr += r.openingCr;
      s.turnoverDr += r.turnoverDr;
      s.turnoverCr += r.turnoverCr;
      s.remainDr += r.remainDr;
      s.remainCr += r.remainCr;
      return s;
    },
    { openingDr: 0, openingCr: 0, turnoverDr: 0, turnoverCr: 0, remainDr: 0, remainCr: 0 },
  );
}

export function classNet(books: Books, cls: Account["class"], from?: string, to?: string) {
  let n = 0;
  for (const a of books.accounts.filter((x) => x.class === cls && x.isPostable)) {
    let dr = 0;
    let cr = 0;
    for (const line of liveLines(books)) {
      if (line.accountId !== a.id) continue;
      const j = books.journals.find((x) => x.id === line.journalId);
      if (!j) continue;
      if (!inRange(j.date, from, to)) continue;
      dr += line.debit;
      cr += line.credit;
    }
    n += a.nature === "debit" ? dr - cr : cr - dr;
  }
  return n;
}

export function incomeStatement(books: Books, from: string, to: string) {
  const sales = classNet(books, "income", from, to);
  const cogs = classNet(books, "cogs", from, to);
  const expense = classNet(books, "expense", from, to);
  const gross = sales - cogs;
  const operating = gross - expense;
  return { sales, cogs, expense, gross, operating, net: operating };
}

export function balanceSheet(books: Books, asOf: string) {
  const assets = classNet(books, "asset", undefined, asOf) - classNet(books, "contra", undefined, asOf);
  const liabilities = classNet(books, "liability", undefined, asOf);
  const equity = classNet(books, "equity", undefined, asOf);
  const pnl = incomeStatement(books, "0000-01-01", asOf).net;
  return { assets, liabilities, equity: equity + pnl, pnl };
}

export function cashFlow(books: Books, from: string, to: string) {
  let inflows = 0;
  let outflows = 0;
  for (const line of liveLines(books)) {
    if (!line.moneyAccountId) continue;
    const j = books.journals.find((x) => x.id === line.journalId);
    if (!j || !inRange(j.date, from, to)) continue;
    inflows += line.debit;
    outflows += line.credit;
  }
  return { inflows, outflows, net: inflows - outflows };
}

export function ledger(books: Books, accountId: string, from: string, to: string) {
  const rows = [];
  let run = 0;
  const acc = books.accounts.find((a) => a.id === accountId);
  for (const line of liveLines(books)) {
    if (line.accountId !== accountId) continue;
    const j = books.journals.find((x) => x.id === line.journalId);
    if (!j) continue;
    if (j.date < from) {
      run += acc?.nature === "debit" ? line.debit - line.credit : line.credit - line.debit;
      continue;
    }
    if (j.date > to) continue;
    const party = line.partyId ? books.parties.find((p) => p.id === line.partyId) : undefined;
    run += acc?.nature === "debit" ? line.debit - line.credit : line.credit - line.debit;
    rows.push({
      date: j.date,
      journal: j.number,
      description: line.description || j.description,
      party: party?.name,
      debit: line.debit,
      credit: line.credit,
      balance: run,
      operationId: j.operationId,
    });
  }
  rows.sort((a, b) => a.date.localeCompare(b.date) || a.journal.localeCompare(b.journal));
  return { opening: 0, rows };
}

export function dayBook(books: Books, from: string, to: string) {
  const rows = [];
  for (const j of liveJournalsSorted(books)) {
    if (!inRange(j.date, from, to)) continue;
    const lines = books.journalLines.filter((l) => l.journalId === j.id);
    for (const line of lines) {
      const acc = books.accounts.find((a) => a.id === line.accountId);
      const party = line.partyId ? books.parties.find((p) => p.id === line.partyId) : undefined;
      const op = j.operationId ? books.operations.find((o) => o.id === j.operationId) : undefined;
      rows.push({
        journal: j.number,
        date: j.date,
        description: line.description || j.description,
        code: acc?.code ?? "",
        account: acc?.name ?? "",
        detail: party?.name ?? "",
        debit: line.debit,
        credit: line.credit,
        user: j.createdBy,
        source: op?.kind ?? j.kind,
        reference: op?.number ?? j.number,
      });
    }
  }
  return rows;
}

function liveJournalsSorted(books: Books) {
  return books.journals.filter((j) => j.status === "posted").sort((a, b) => a.date.localeCompare(b.date) || a.number.localeCompare(b.number));
}

export function partyCard(books: Books, partyId: string, from: string, to: string) {
  const ops = liveOperations(books).filter((o) => o.partyId === partyId && inRange(o.date, from, to));
  const purchase = ops.filter((o) => o.kind === "purchase").reduce((s, o) => s + o.amount, 0);
  const sale = ops.filter((o) => o.kind === "sale").reduce((s, o) => s + o.amount, 0);
  const receipt = ops.filter((o) => o.kind === "receipt" || o.kind === "check_receive").reduce((s, o) => s + o.amount, 0);
  const payment = ops.filter((o) => o.kind === "payment" || o.kind === "check_issue").reduce((s, o) => s + o.amount, 0);
  const ret = ops.filter((o) => o.kind === "sale_return" || o.kind === "purchase_return").reduce((s, o) => s + o.amount, 0);
  const discount = ops.reduce((s, o) => s + o.discount, 0);
  const checks = books.checks.filter((c) => c.partyId === partyId);
  return {
    opening: partyBalance(books, partyId, from ? undefined : undefined),
    purchase,
    sale,
    receipt,
    payment,
    ret,
    discount,
    checkCount: checks.length,
    balance: partyBalance(books, partyId, to),
    ops,
  };
}

export function kpi(books: Books, from: string, to: string) {
  const ops = liveOperations(books).filter((o) => inRange(o.date, from, to));
  const sales = ops.filter((o) => o.kind === "sale").reduce((s, o) => s + o.amount, 0);
  const saleCount = ops.filter((o) => o.kind === "sale").length;
  const collection = ops.filter((o) => o.kind === "receipt" || o.kind === "check_clear").reduce((s, o) => s + o.amount, 0);
  const expense = ops.filter((o) => o.kind === "expense" || o.kind === "payroll").reduce((s, o) => s + o.amount, 0);
  const payments = ops.filter((o) => o.kind === "payment").reduce((s, o) => s + o.amount, 0);
  const pnl = incomeStatement(books, from, to);
  const cash = books.moneyAccounts.reduce((s, m) => s + moneyBalance(books, m.id, to), 0);
  const ar = books.parties.filter((p) => p.kind === "customer").map((p) => ({ p, b: partyBalance(books, p.id, to) }));
  const ap = books.parties.filter((p) => p.kind === "supplier").map((p) => ({ p, b: -partyBalance(books, p.id, to) }));
  const openAr = ar.filter((x) => x.b > 0).reduce((s, x) => s + x.b, 0);
  const openAp = ap.filter((x) => x.b > 0).reduce((s, x) => s + x.b, 0);
  return {
    sales,
    saleCount,
    avgSale: saleCount ? Math.round(sales / saleCount) : 0,
    collection,
    collectionRate: sales ? Math.round((collection / sales) * 100) : 0,
    openAr,
    openAp,
    expense,
    payments,
    cash,
    expenseToSales: sales ? Math.round((expense / sales) * 100) : 0,
    pnl,
    topDebtors: ar.filter((x) => x.b > 0).sort((a, b) => b.b - a.b).slice(0, 5),
    topCreditors: ap.filter((x) => x.b > 0).sort((a, b) => b.b - a.b).slice(0, 5),
  };
}

export function liquidity(books: Books, asOf: string, horizonDays: number) {
  const cash = books.moneyAccounts.filter((m) => m.kind === "cash").reduce((s, m) => s + moneyBalance(books, m.id, asOf), 0);
  const bank = books.moneyAccounts.filter((m) => m.kind === "bank").reduce((s, m) => s + moneyBalance(books, m.id, asOf), 0);
  const petty = books.moneyAccounts.filter((m) => m.kind === "petty").reduce((s, m) => s + moneyBalance(books, m.id, asOf), 0);
  const todayOps = liveOperations(books).filter((o) => o.dayKey === asOf);
  const receiptsToday = todayOps.filter((o) => o.kind === "receipt").reduce((s, o) => s + o.amount, 0);
  const paymentsToday = todayOps.filter((o) => o.kind === "payment").reduce((s, o) => s + o.amount, 0);
  const until = new Date(`${asOf}T12:00:00`);
  until.setDate(until.getDate() + horizonDays);
  const untilIso = until.toISOString().slice(0, 10);
  const recChecks = books.checks.filter((c) => c.kind === "received" && c.status === "pending");
  const issChecks = books.checks.filter((c) => c.kind === "issued" && c.status === "pending");
  const dueIn = recChecks.filter((c) => c.dueDate >= asOf && c.dueDate <= untilIso).reduce((s, c) => s + c.amount, 0);
  const payIn = issChecks.filter((c) => c.dueDate >= asOf && c.dueDate <= untilIso).reduce((s, c) => s + c.amount, 0);
  const ar = books.parties.filter((p) => p.kind === "customer").reduce((s, p) => s + Math.max(0, partyBalance(books, p.id, asOf)), 0);
  const ap = books.parties.filter((p) => p.kind === "supplier").reduce((s, p) => s + Math.max(0, -partyBalance(books, p.id, asOf)), 0);
  return {
    cash,
    bank,
    petty,
    total: cash + bank + petty,
    receiptsToday,
    paymentsToday,
    netToday: receiptsToday - paymentsToday,
    recChecks: recChecks.reduce((s, c) => s + c.amount, 0),
    issChecks: issChecks.reduce((s, c) => s + c.amount, 0),
    dueIn,
    payIn,
    ar,
    ap,
    forecast: cash + bank + petty + dueIn - payIn,
  };
}

export function crmRows(books: Books, asOf: string) {
  return books.parties
    .filter((p) => p.kind === "customer")
    .map((p) => {
      const sales = liveOperations(books).filter((o) => o.partyId === p.id && o.kind === "sale");
      const receipts = liveOperations(books).filter((o) => o.partyId === p.id && o.kind === "receipt");
      const last = [...sales].sort((a, b) => b.date.localeCompare(a.date))[0];
      const total = sales.reduce((s, o) => s + o.amount, 0);
      const rec = receipts.reduce((s, o) => s + o.amount, 0);
      const bal = partyBalance(books, p.id, asOf);
      const daysSince = last ? Math.round((Date.parse(`${asOf}T12:00:00`) - Date.parse(`${last.date}T12:00:00`)) / 86400000) : 999;
      let segment: "new" | "active" | "inactive" | "high_balance" | "risk" | "rising" = "active";
      if (sales.length <= 1) segment = "new";
      else if (daysSince > 45) segment = "inactive";
      if (bal > 50_000_000) segment = "high_balance";
      if (bal > 80_000_000 && daysSince > 20) segment = "risk";
      return {
        party: p,
        lastDate: last?.date,
        count: sales.length,
        total,
        avg: sales.length ? Math.round(total / sales.length) : 0,
        received: rec,
        balance: bal,
        daysSince,
        segment,
      };
    })
    .sort((a, b) => b.total - a.total);
}
