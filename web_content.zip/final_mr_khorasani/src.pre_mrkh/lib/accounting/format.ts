import { toFaDigits } from "./jalali";
import type { Books, OpKind, PartyKind, RoleId } from "./types";

export const OP_LABEL: Record<OpKind, string> = {
  receipt: "دریافت",
  payment: "پرداخت",
  transfer: "انتقال",
  sale: "فروش",
  sale_return: "برگشت از فروش",
  purchase: "خرید",
  purchase_return: "برگشت از خرید",
  expense: "هزینه",
  income: "درآمد",
  check_receive: "دریافت چک",
  check_issue: "پرداخت چک",
  check_clear: "وصول چک",
  check_bounce: "برگشت چک",
  petty_fund: "تخصیص تنخواه",
  petty_settle: "تسویه تنخواه",
  capital: "واریز سرمایه",
  draw: "برداشت مالک",
  payroll: "حقوق و دستمزد",
  depreciation: "استهلاک",
  prepaid: "پیش‌پرداخت",
  unearned: "پیش‌دریافت",
  manual: "سند دستی",
  adjustment: "سند اصلاحی",
};

export const PARTY_LABEL: Record<PartyKind, string> = {
  customer: "مشتری",
  supplier: "تأمین‌کننده",
  employee: "کارمند",
  shareholder: "سهام‌دار",
  bank: "بانک",
  government: "دولتی",
  other: "سایر",
};

export const ROLE_LABEL: Record<RoleId, string> = {
  admin: "مدیر سیستم",
  finance_manager: "مدیر مالی",
  accountant: "حسابدار",
  cashier: "صندوقدار",
  sales: "کاربر فروش",
  warehouse: "مدیر انبار",
  auditor: "ناظر",
};

export function formatRial(amount: number, persianDigits = true, toman = false) {
  const n = toman ? Math.round(amount / 10) : amount;
  const grouped = Math.abs(n).toLocaleString("en-US");
  const signed = n < 0 ? `-${grouped}` : grouped;
  return persianDigits ? toFaDigits(signed) : signed;
}

export function moneyUnit(toman: boolean) {
  return toman ? "تومان" : "ریال";
}

export function formatMoney(amount: number, books: Books) {
  return `${formatRial(amount, books.settings.persianDigits, books.settings.displayToman)} ${moneyUnit(books.settings.displayToman)}`;
}

export function parseAmount(raw: string) {
  const cleaned = raw.replace(/[۰-۹]/g, (d) => "۰۱۲۳۴۵۶۷۸۹".indexOf(d).toString()).replace(/[^\d.-]/g, "");
  if (!cleaned) return 0;
  const n = Number(cleaned);
  return Number.isFinite(n) ? Math.round(n) : 0;
}

export function nid(prefix: string) {
  const id =
    typeof crypto !== "undefined" && crypto.randomUUID
      ? crypto.randomUUID().replace(/-/g, "").slice(0, 16)
      : `${Date.now().toString(16)}${Math.random().toString(16).slice(2, 10)}`;
  return `${prefix}_${id}`;
}

export function nowIso() {
  return new Date().toISOString();
}

export function padN(n: number, w = 6) {
  return String(n).padStart(w, "0");
}
