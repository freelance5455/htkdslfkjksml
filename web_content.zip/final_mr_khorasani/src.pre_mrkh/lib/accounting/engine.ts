import { accountByCode } from "./chart";
import { nid, nowIso, OP_LABEL, padN } from "./format";
import type {
  Actor,
  Books,
  DailyClosing,
  EngineError,
  EngineResult,
  Journal,
  JournalLine,
  ManualLineInput,
  Operation,
  OperationInput,
  RecordStatus,
} from "./types";

function fail(code: EngineError["code"], error: string): EngineError {
  return { ok: false, code, error };
}

export function currentFy(books: Books) {
  return books.fiscalYears.find((y) => y.isCurrent && y.status === "open") ?? books.fiscalYears.find((y) => y.isCurrent);
}

export function isDayClosed(books: Books, dayKey: string) {
  const row = books.dailyClosings.find((d) => d.dayKey === dayKey);
  return row?.status === "closed";
}

export function liveJournals(books: Books) {
  return books.journals.filter((j) => j.status === "posted");
}

export function liveLines(books: Books) {
  const ids = new Set(liveJournals(books).map((j) => j.id));
  return books.journalLines.filter((l) => ids.has(l.journalId));
}

export function liveOperations(books: Books) {
  return books.operations.filter((o) => o.status === "posted");
}

export function sumLines(lines: { debit: number; credit: number }[]) {
  const debit = lines.reduce((s, l) => s + l.debit, 0);
  const credit = lines.reduce((s, l) => s + l.credit, 0);
  return { debit, credit, diff: debit - credit };
}

export function accountBalance(books: Books, accountId: string, through?: string) {
  const acc = books.accounts.find((a) => a.id === accountId);
  if (!acc) return 0;
  let dr = 0;
  let cr = 0;
  for (const line of liveLines(books)) {
    if (line.accountId !== accountId) continue;
    const j = books.journals.find((x) => x.id === line.journalId);
    if (!j) continue;
    if (through && j.date > through) continue;
    dr += line.debit;
    cr += line.credit;
  }
  return acc.nature === "debit" ? dr - cr : cr - dr;
}

export function moneyBalance(books: Books, moneyAccountId: string, through?: string) {
  let dr = 0;
  let cr = 0;
  for (const line of liveLines(books)) {
    if (line.moneyAccountId !== moneyAccountId) continue;
    const j = books.journals.find((x) => x.id === line.journalId);
    if (!j) continue;
    if (through && j.date > through) continue;
    dr += line.debit;
    cr += line.credit;
  }
  return dr - cr;
}

export function partyBalance(books: Books, partyId: string, through?: string) {
  let dr = 0;
  let cr = 0;
  for (const line of liveLines(books)) {
    if (line.partyId !== partyId) continue;
    const j = books.journals.find((x) => x.id === line.journalId);
    if (!j) continue;
    if (through && j.date > through) continue;
    dr += line.debit;
    cr += line.credit;
  }
  return dr - cr;
}

function acc(books: Books, code: string) {
  const a = accountByCode(books.accounts, code);
  if (!a || !a.active) return null;
  return a;
}

function nextOpNo(books: Books) {
  const fy = currentFy(books);
  const n = books.counters.operation + 1;
  return { number: `OP-${fy?.jalaliYear ?? 1405}-${padN(n)}`, n };
}

function nextJvNo(books: Books) {
  const fy = currentFy(books);
  const n = books.counters.journal + 1;
  return { number: `JV-${fy?.jalaliYear ?? 1405}-${padN(n)}`, n };
}

function nextInvNo(books: Books, prefix: string) {
  const fy = currentFy(books);
  const n = books.counters.invoice + 1;
  return { number: `${prefix}-${fy?.jalaliYear ?? 1405}-${padN(n)}`, n };
}

function clone(books: Books): Books {
  return structuredClone(books);
}

function audit(books: Books, actor: Actor, action: string, entity: string, entityId: string, extra?: Partial<Books["auditLogs"][number]>) {
  books.auditLogs.unshift({
    id: nid("aud"),
    at: nowIso(),
    userId: actor.userId,
    userName: actor.userName,
    action,
    entity,
    entityId,
    device: actor.device,
    ...extra,
  });
  if (books.auditLogs.length > 2000) books.auditLogs.length = 2000;
}

function requireDay(books: Books, date: string): EngineError | null {
  const fy = currentFy(books);
  if (!fy) return fail("OUT_OF_YEAR", "سال مالی فعال تعریف نشده است.");
  if (date < fy.startDate || date > fy.endDate) return fail("OUT_OF_YEAR", "تاریخ خارج از سال مالی جاری است.");
  if (isDayClosed(books, date)) return fail("DAY_CLOSED", "این روز بسته شده و فقط با سند اصلاحی قابل تغییر است.");
  return null;
}

function moneyOrFail(books: Books, id: string | undefined, kind: "source" | "dest"): EngineError | { id: string; code: string } {
  if (!id) return fail(kind === "source" ? "MISSING_SOURCE" : "MISSING_DEST", kind === "source" ? "منبع مالی مشخص نشده است." : "مقصد مالی مشخص نشده است.");
  const m = books.moneyAccounts.find((x) => x.id === id && x.active);
  if (!m) return fail("INVALID_ACCOUNT", "حساب نقدی/بانکی نامعتبر است.");
  return { id: m.id, code: m.accountCode };
}

type BuiltLine = Omit<JournalLine, "id" | "journalId">;

function L(accountId: string, debit: number, credit: number, extra: Partial<BuiltLine> = {}): BuiltLine {
  return {
    accountId,
    debit: Math.round(debit),
    credit: Math.round(credit),
    description: extra.description ?? "",
    partyId: extra.partyId,
    moneyAccountId: extra.moneyAccountId,
    projectId: extra.projectId,
    costCenterId: extra.costCenterId,
  };
}

function buildLines(books: Books, input: OperationInput): EngineResult<{ lines: BuiltLine[]; checkId?: string; invoiceTotal?: number; cogs?: number }> {
  const party = input.partyId ? books.parties.find((p) => p.id === input.partyId && p.active) : undefined;
  if (input.partyId && !party) return fail("INVALID_PARTY", "شخص انتخاب‌شده نامعتبر است.");

  const amount = Math.round(input.amount);
  const discount = Math.round(input.discount ?? 0);
  const shipping = Math.round(input.shipping ?? 0);
  const paid = Math.round(input.paidAmount ?? 0);

  if (["manual", "adjustment"].includes(input.kind)) {
    const lines = (input.lines ?? []).map((l) => L(l.accountId, l.debit, l.credit, l));
    if (!lines.length) return fail("INCOMPLETE", "ردیف سند مشخص نشده است.");
    const tot = sumLines(lines);
    if (tot.diff !== 0) return fail("UNBALANCED", `سند نامتوازن است. اختلاف: ${tot.diff}`);
    if (tot.debit === 0) return fail("ZERO_AMOUNT", "مبلغ سند صفر است.");
    return { ok: true, lines };
  }

  if (amount <= 0 && !(input.invoiceLines && input.invoiceLines.length)) return fail("ZERO_AMOUNT", "مبلغ باید بزرگ‌تر از صفر باشد.");
  if (amount < 0 || discount < 0 || shipping < 0 || paid < 0) return fail("NEGATIVE", "مبلغ منفی مجاز نیست.");

  const cash = acc(books, "1101")!;
  const bank = acc(books, "1102")!;
  const petty = acc(books, "1103")!;
  const ar = acc(books, "1104")!;
  const nr = acc(books, "1105")!;
  const inv = acc(books, "1106")!;
  const prepaid = acc(books, "1107")!;
  const fa = acc(books, "1201")!;
  const accum = acc(books, "1202")!;
  const ap = acc(books, "2101")!;
  const np = acc(books, "2102")!;
  const tax = acc(books, "2103")!;
  const ins = acc(books, "2104")!;
  const wages = acc(books, "2105")!;
  const unearned = acc(books, "2106")!;
  const capital = acc(books, "3101")!;
  const draw = acc(books, "3102")!;
  const sales = acc(books, "4101")!;
  const otherInc = acc(books, "4103")!;
  const salesDisc = acc(books, "4104")!;
  const salesRet = acc(books, "4105")!;
  const cogsA = acc(books, "5101")!;
  void cash;
  void bank;
  void fa;
  void tax;
  void ins;
  void wages;

  const src = () => moneyOrFail(books, input.moneyAccountId, "source");

  const moneyLine = (side: "dr" | "cr", amt: number, desc: string) => {
    const m = src();
    if (!("id" in m)) return m;
    const account = acc(books, m.code);
    if (!account) return fail("INVALID_ACCOUNT", "حساب منبع مالی یافت نشد.");
    return L(account.id, side === "dr" ? amt : 0, side === "cr" ? amt : 0, {
      moneyAccountId: m.id,
      description: desc,
    });
  };

  let invoiceTotal = amount;
  if (input.invoiceLines && input.invoiceLines.length) {
    const sub = input.invoiceLines.reduce((s, l) => s + Math.round(l.qty * l.unitPrice) - Math.round(l.discount), 0);
    invoiceTotal = sub - discount + shipping;
    if (invoiceTotal <= 0) return fail("ZERO_AMOUNT", "جمع فاکتور باید بزرگ‌تر از صفر باشد.");
  }

  const computeCogs = () => {
    if (!books.settings.perpetualInventory) return 0;
    if (input.invoiceLines && input.invoiceLines.length) {
      return input.invoiceLines.reduce((s, l) => {
        const p = l.productId ? books.products.find((x) => x.id === l.productId) : undefined;
        const unitCost = p ? p.cost : Math.round(l.unitPrice * 0.65);
        return s + Math.round(unitCost * l.qty);
      }, 0);
    }
    return Math.round(invoiceTotal * 0.65);
  };

  const kind = input.kind;
  const method = input.method;
  const desc = input.description;

  const pushCogs = (lines: BuiltLine[]) => {
    const cogs = computeCogs();
    if (cogs > 0) {
      lines.push(L(cogsA.id, cogs, 0, { description: "بهای تمام‌شده" }));
      lines.push(L(inv.id, 0, cogs, { description: "خروج موجودی" }));
    }
    return cogs;
  };

  const revCogs = (lines: BuiltLine[]) => {
    const cogs = computeCogs();
    if (cogs > 0) {
      lines.push(L(inv.id, cogs, 0, { description: "برگشت موجودی" }));
      lines.push(L(cogsA.id, 0, cogs, { description: "برگشت بهای تمام‌شده" }));
    }
    return cogs;
  };

  if (kind === "receipt") {
    const m = moneyLine("dr", amount, desc);
    if (!("accountId" in m)) return m;
    const lines = [m, L(ar.id, 0, amount, { partyId: party?.id, description: desc })];
    return { ok: true, lines };
  }

  if (kind === "payment") {
    const m = moneyLine("cr", amount, desc);
    if (!("accountId" in m)) return m;
    const expense = input.accountId ? books.accounts.find((a) => a.id === input.accountId) : ap;
    if (!expense) return fail("INVALID_ACCOUNT", "حساب بدهکار نامعتبر است.");
    const lines = [
      L(expense.id, amount, 0, { partyId: party?.id, description: desc }),
      m,
    ];
    return { ok: true, lines };
  }

  if (kind === "transfer") {
    const from = moneyOrFail(books, input.moneyAccountId, "source");
    const to = moneyOrFail(books, input.destMoneyAccountId, "dest");
    if (!("id" in from)) return from;
    if (!("id" in to)) return to;
    if (from.id === to.id) return fail("INCOMPLETE", "مبدأ و مقصد نمی‌توانند یکسان باشند.");
    const aFrom = acc(books, from.code)!;
    const aTo = acc(books, to.code)!;
    return {
      ok: true,
      lines: [
        L(aTo.id, amount, 0, { moneyAccountId: to.id, description: desc }),
        L(aFrom.id, 0, amount, { moneyAccountId: from.id, description: desc }),
      ],
    };
  }

  if (kind === "sale" || kind === "sale_return") {
    const total = invoiceTotal;
    const lines: BuiltLine[] = [];
    const incomeAcc = sales;
    const gross = (input.invoiceLines && input.invoiceLines.length
      ? input.invoiceLines.reduce((s, l) => s + Math.round(l.qty * l.unitPrice) - Math.round(l.discount), 0)
      : amount) + shipping;
    if (kind === "sale") {
      const net = total;
      if (method === "cash" || method === "bank") {
        const m = moneyLine("dr", net, desc);
        if (!("accountId" in m)) return m;
        lines.push(m);
      } else if (method === "credit") {
        if (!party) return fail("INVALID_PARTY", "فروش نسیه نیازمند مشتری است.");
        lines.push(L(ar.id, net, 0, { partyId: party.id, description: desc }));
      } else if (method === "mixed") {
        if (paid <= 0 || paid >= net) return fail("INCOMPLETE", "در فروش ترکیبی مبلغ نقد باید بخشی از جمع باشد.");
        const m = moneyLine("dr", paid, desc);
        if (!("accountId" in m)) return m;
        if (!party) return fail("INVALID_PARTY", "فروش ترکیبی نیازمند مشتری است.");
        lines.push(m);
        lines.push(L(ar.id, net - paid, 0, { partyId: party.id, description: desc }));
      } else return fail("INCOMPLETE", "روش تسویه مشخص نشده است.");
      lines.push(L(incomeAcc.id, 0, gross, { description: desc }));
      if (discount) lines.push(L(salesDisc.id, discount, 0, { description: "تخفیف فروش" }));
      const cogs = pushCogs(lines);
      return { ok: true, lines, invoiceTotal: total, cogs };
    }
    // sale return
    lines.push(L(salesRet.id, total, 0, { description: desc }));
    if (method === "credit" && party) lines.push(L(ar.id, 0, total, { partyId: party.id, description: desc }));
    else {
      const m = moneyLine("cr", total, desc);
      if (!("accountId" in m)) return m;
      lines.push(m);
    }
    const cogs = revCogs(lines);
    return { ok: true, lines, invoiceTotal: total, cogs };
  }

  if (kind === "purchase" || kind === "purchase_return") {
    const total = invoiceTotal;
    const stockAcc = input.accountId ? books.accounts.find((a) => a.id === input.accountId) : inv;
    if (!stockAcc) return fail("INVALID_ACCOUNT", "حساب خرید نامعتبر است.");
    const lines: BuiltLine[] = [];
    if (kind === "purchase") {
      lines.push(L(stockAcc.id, total, 0, { description: desc }));
      if (method === "credit") {
        if (!party) return fail("INVALID_PARTY", "خرید نسیه نیازمند تأمین‌کننده است.");
        lines.push(L(ap.id, 0, total, { partyId: party.id, description: desc }));
      } else {
        const m = moneyLine("cr", total, desc);
        if (!("accountId" in m)) return m;
        lines.push(m);
      }
    } else {
      if (method === "credit" && party) lines.push(L(ap.id, total, 0, { partyId: party.id, description: desc }));
      else {
        const m = moneyLine("dr", total, desc);
        if (!("accountId" in m)) return m;
        lines.push(m);
      }
      lines.push(L(stockAcc.id, 0, total, { description: desc }));
    }
    return { ok: true, lines, invoiceTotal: total };
  }

  if (kind === "expense") {
    const exp = input.accountId ? books.accounts.find((a) => a.id === input.accountId) : acc(books, "6111");
    if (!exp) return fail("INVALID_ACCOUNT", "حساب هزینه نامعتبر است.");
    if (method === "credit") {
      if (!party) return fail("INVALID_PARTY", "هزینه پرداختنی نیازمند شخص است.");
      return { ok: true, lines: [L(exp.id, amount, 0, { description: desc }), L(ap.id, 0, amount, { partyId: party.id, description: desc })] };
    }
    const m = moneyLine("cr", amount, desc);
    if (!("accountId" in m)) return m;
    return { ok: true, lines: [L(exp.id, amount, 0, { description: desc }), m] };
  }

  if (kind === "income") {
    const inc = input.accountId ? books.accounts.find((a) => a.id === input.accountId) : otherInc;
    if (!inc) return fail("INVALID_ACCOUNT", "حساب درآمد نامعتبر است.");
    const m = moneyLine("dr", amount, desc);
    if (!("accountId" in m)) return m;
    return { ok: true, lines: [m, L(inc.id, 0, amount, { description: desc })] };
  }

  if (kind === "check_receive") {
    if (!party) return fail("INVALID_PARTY", "دریافت چک نیازمند شخص است.");
    if (!input.checkNumber || !input.checkDue) return fail("INCOMPLETE", "شماره و سررسید چک الزامی است.");
    return {
      ok: true,
      lines: [
        L(nr.id, amount, 0, { partyId: party.id, description: desc }),
        L(ar.id, 0, amount, { partyId: party.id, description: desc }),
      ],
    };
  }

  if (kind === "check_issue") {
    if (!party) return fail("INVALID_PARTY", "پرداخت چک نیازمند شخص است.");
    if (!input.checkNumber || !input.checkDue) return fail("INCOMPLETE", "شماره و سررسید چک الزامی است.");
    return {
      ok: true,
      lines: [
        L(ap.id, amount, 0, { partyId: party.id, description: desc }),
        L(np.id, 0, amount, { partyId: party.id, description: desc }),
      ],
    };
  }

  if (kind === "check_clear") {
    const chk = books.checks.find((c) => c.id === input.checkId);
    if (!chk || chk.status !== "pending") return fail("NOT_FOUND", "چک قابل وصول یافت نشد.");
    const m = moneyLine(chk.kind === "received" ? "dr" : "cr", chk.amount, desc);
    if (!("accountId" in m)) return m;
    if (chk.kind === "received") {
      return { ok: true, lines: [m, L(nr.id, 0, chk.amount, { partyId: chk.partyId, description: desc })] };
    }
    return { ok: true, lines: [L(np.id, chk.amount, 0, { partyId: chk.partyId, description: desc }), m] };
  }

  if (kind === "check_bounce") {
    const chk = books.checks.find((c) => c.id === input.checkId);
    if (!chk || chk.status !== "pending") return fail("NOT_FOUND", "چک قابل برگشت یافت نشد.");
    if (chk.kind === "received") {
      return {
        ok: true,
        lines: [
          L(ar.id, chk.amount, 0, { partyId: chk.partyId, description: desc }),
          L(nr.id, 0, chk.amount, { partyId: chk.partyId, description: desc }),
        ],
      };
    }
    return {
      ok: true,
      lines: [
        L(np.id, chk.amount, 0, { partyId: chk.partyId, description: desc }),
        L(ap.id, 0, chk.amount, { partyId: chk.partyId, description: desc }),
      ],
    };
  }

  if (kind === "petty_fund") {
    const from = moneyOrFail(books, input.moneyAccountId, "source");
    const to = moneyOrFail(books, input.destMoneyAccountId, "dest");
    if (!("id" in from)) return from;
    if (!("id" in to)) return to;
    const aFrom = acc(books, from.code)!;
    return {
      ok: true,
      lines: [
        L(petty.id, amount, 0, { moneyAccountId: to.id, description: desc }),
        L(aFrom.id, 0, amount, { moneyAccountId: from.id, description: desc }),
      ],
    };
  }

  if (kind === "petty_settle") {
    const exp = input.accountId ? books.accounts.find((a) => a.id === input.accountId) : acc(books, "6111");
    if (!exp) return fail("INVALID_ACCOUNT", "حساب هزینه تنخواه نامعتبر است.");
    const pettyAcc = moneyOrFail(books, input.moneyAccountId, "source");
    if (!("id" in pettyAcc)) return pettyAcc;
    return {
      ok: true,
      lines: [
        L(exp.id, amount, 0, { description: desc }),
        L(petty.id, 0, amount, { moneyAccountId: pettyAcc.id, description: desc }),
      ],
    };
  }

  if (kind === "capital") {
    const m = moneyLine("dr", amount, desc);
    if (!("accountId" in m)) return m;
    return { ok: true, lines: [m, L(capital.id, 0, amount, { description: desc })] };
  }

  if (kind === "draw") {
    const m = moneyLine("cr", amount, desc);
    if (!("accountId" in m)) return m;
    return { ok: true, lines: [L(draw.id, amount, 0, { description: desc }), m] };
  }

  if (kind === "payroll") {
    const sal = acc(books, "6101")!;
    const m = moneyLine("cr", amount, desc);
    if (!("accountId" in m)) return m;
    return { ok: true, lines: [L(sal.id, amount, 0, { partyId: party?.id, description: desc }), m] };
  }

  if (kind === "depreciation") {
    const dep = acc(books, "6108")!;
    return { ok: true, lines: [L(dep.id, amount, 0, { description: desc }), L(accum.id, 0, amount, { description: desc })] };
  }

  if (kind === "prepaid") {
    const m = moneyLine("cr", amount, desc);
    if (!("accountId" in m)) return m;
    return { ok: true, lines: [L(prepaid.id, amount, 0, { partyId: party?.id, description: desc }), m] };
  }

  if (kind === "unearned") {
    const m = moneyLine("dr", amount, desc);
    if (!("accountId" in m)) return m;
    return { ok: true, lines: [m, L(unearned.id, 0, amount, { partyId: party?.id, description: desc })] };
  }

  return fail("INCOMPLETE", "نوع عملیات پشتیبانی نمی‌شود.");
}

function attachJournal(books: Books, actor: Actor, input: OperationInput, lines: BuiltLine[], kind: Journal["kind"], extra?: Partial<Journal>) {
  const jn = nextJvNo(books);
  const journal: Journal = {
    id: nid("jv"),
    number: jn.number,
    kind,
    date: input.date,
    dayKey: input.date,
    fiscalYearId: currentFy(books)!.id,
    description: input.description,
    status: "posted",
    locked: false,
    createdBy: actor.userId,
    createdAt: nowIso(),
    ...extra,
  };
  const jLines: JournalLine[] = lines.map((l) => ({ ...l, id: nid("jl"), journalId: journal.id }));
  const tot = sumLines(jLines);
  if (tot.diff !== 0) return fail("UNBALANCED", `سند نامتوازن است. بدهکار ${tot.debit} بستانکار ${tot.credit}`);
  books.counters.journal = jn.n;
  books.journals.unshift(journal);
  books.journalLines.push(...jLines);
  return { ok: true as const, journal, lines: jLines };
}

export function postOperation(books: Books, input: OperationInput, actor: Actor): EngineResult<{ books: Books; operation: Operation; journal: Journal }> {
  const next = clone(books);
  const dayErr = requireDay(next, input.date);
  if (dayErr) return dayErr;
  const fy = currentFy(next);
  if (!fy) return fail("OUT_OF_YEAR", "سال مالی فعال نیست.");

  const built = buildLines(next, input);
  if (!built.ok) return built;

  const opn = nextOpNo(next);
  const posted = attachJournal(next, actor, input, built.lines, input.kind === "manual" ? "manual" : input.kind === "adjustment" ? "adjustment" : "auto", {
    originalJournalId: input.originalJournalId,
    adjustmentOfId: input.originalJournalId,
  });
  if (!posted.ok) return posted;

  let invoiceId: string | undefined;
  if (input.invoiceLines && input.invoiceLines.length && ["sale", "purchase", "sale_return", "purchase_return"].includes(input.kind)) {
    const prefix = input.kind.startsWith("sale") ? "INV" : "PUR";
    const invn = nextInvNo(next, prefix);
    const sub = input.invoiceLines.reduce((s, l) => s + Math.round(l.qty * l.unitPrice) - Math.round(l.discount), 0);
    const total = built.invoiceTotal ?? sub;
    const inv = {
      id: nid("inv"),
      number: invn.number,
      kind: input.kind as "sale" | "purchase" | "sale_return" | "purchase_return",
      partyId: input.partyId ?? "",
      date: input.date,
      lines: input.invoiceLines,
      subtotal: sub,
      discount: input.discount ?? 0,
      shipping: input.shipping ?? 0,
      total,
      paid: input.method === "credit" ? 0 : input.method === "mixed" ? (input.paidAmount ?? 0) : total,
      operationId: "",
      status: "posted" as RecordStatus,
    };
    next.counters.invoice = invn.n;
    next.invoices.unshift(inv);
    invoiceId = inv.id;
    if (next.settings.perpetualInventory) {
      for (const line of input.invoiceLines) {
        if (!line.productId) continue;
        const p = next.products.find((x) => x.id === line.productId);
        if (!p) continue;
        const dir = input.kind === "sale" || input.kind === "purchase_return" ? -1 : 1;
        p.stock += dir * line.qty;
      }
    }
  }

  let checkId: string | undefined;
  if (input.kind === "check_receive" || input.kind === "check_issue") {
    const chk = {
      id: nid("chk"),
      number: input.checkNumber ?? "",
      kind: input.kind === "check_receive" ? ("received" as const) : ("issued" as const),
      bankName: input.checkBank ?? "",
      amount: Math.round(input.amount),
      issueDate: input.date,
      dueDate: input.checkDue ?? input.date,
      partyId: input.partyId,
      status: "pending" as const,
      operationId: "",
    };
    next.checks.unshift(chk);
    checkId = chk.id;
  }
  if (input.kind === "check_clear" || input.kind === "check_bounce") {
    const chk = next.checks.find((c) => c.id === input.checkId);
    if (chk) {
      chk.status = input.kind === "check_clear" ? "cleared" : "bounced";
      checkId = chk.id;
    }
  }

  const operation: Operation = {
    id: nid("op"),
    number: opn.number,
    kind: input.kind,
    method: input.method,
    date: input.date,
    dayKey: input.date,
    fiscalYearId: fy.id,
    partyId: input.partyId,
    moneyAccountId: input.moneyAccountId,
    destMoneyAccountId: input.destMoneyAccountId,
    accountId: input.accountId,
    amount: built.invoiceTotal ?? Math.round(input.amount),
    paidAmount: Math.round(input.paidAmount ?? 0),
    discount: Math.round(input.discount ?? 0),
    shipping: Math.round(input.shipping ?? 0),
    description: input.description,
    reference: input.reference,
    invoiceId,
    checkId,
    journalId: posted.journal.id,
    status: "posted",
    createdBy: actor.userId,
    createdAt: nowIso(),
    updatedAt: nowIso(),
    version: 1,
    syncStatus: "pending",
  };
  posted.journal.operationId = operation.id;
  if (invoiceId) {
    const inv = next.invoices.find((i) => i.id === invoiceId);
    if (inv) inv.operationId = operation.id;
  }
  if (checkId) {
    const chk = next.checks.find((c) => c.id === checkId);
    if (chk && !chk.operationId) chk.operationId = operation.id;
    if (chk && input.kind === "check_clear") chk.clearOperationId = operation.id;
  }
  next.counters.operation = opn.n;
  next.operations.unshift(operation);
  next.version += 1;
  next.updatedAt = nowIso();
  audit(next, actor, "Create", "operation", operation.id, {
    dayKey: operation.dayKey,
    newValue: { number: operation.number, amount: operation.amount, kind: operation.kind, journal: posted.journal.number },
    reason: input.reason,
  });
  return { ok: true, books: next, operation, journal: posted.journal };
}

export function reverseOperation(books: Books, operationId: string, actor: Actor, reason: string): EngineResult<{ books: Books; journal: Journal }> {
  const next = clone(books);
  const op = next.operations.find((o) => o.id === operationId);
  if (!op || op.status !== "posted") return fail("NOT_FOUND", "عملیات قابل برگشت یافت نشد.");
  const dayErr = requireDay(next, op.date);
  if (dayErr) return dayErr;
  const journal = next.journals.find((j) => j.id === op.journalId);
  if (!journal || journal.status !== "posted") return fail("NOT_FOUND", "سند مرتبط یافت نشد.");
  if (journal.locked) return fail("LOCKED", "سند قفل است و فقط با سند اصلاحی قابل تغییر است.");
  const origLines = next.journalLines.filter((l) => l.journalId === journal.id);
  const revLines: BuiltLine[] = origLines.map((l) => ({
    accountId: l.accountId,
    partyId: l.partyId,
    moneyAccountId: l.moneyAccountId,
    projectId: l.projectId,
    costCenterId: l.costCenterId,
    debit: l.credit,
    credit: l.debit,
    description: `برگشت ${journal.number}`,
  }));
  const posted = attachJournal(
    next,
    actor,
    { kind: "adjustment", method: "none", date: op.date, amount: op.amount, description: `برگشت ${op.number} — ${reason}` },
    revLines,
    "reversal",
    { originalJournalId: journal.id, operationId: op.id },
  );
  if (!posted.ok) return posted;
  op.status = "deleted";
  op.deletedAt = nowIso();
  op.deletedBy = actor.userId;
  op.deleteReason = reason;
  op.updatedAt = nowIso();
  journal.status = "reversed";
  next.version += 1;
  next.updatedAt = nowIso();
  audit(next, actor, "Delete", "operation", op.id, {
    dayKey: op.dayKey,
    oldValue: { number: op.number, amount: op.amount },
    reason,
  });
  return { ok: true, books: next, journal: posted.journal };
}

export function postAdjustment(
  books: Books,
  originalJournalId: string,
  lines: ManualLineInput[],
  date: string,
  description: string,
  actor: Actor,
  reason: string,
): EngineResult<{ books: Books; journal: Journal }> {
  const next = clone(books);
  const orig = next.journals.find((j) => j.id === originalJournalId);
  if (!orig) return fail("NOT_FOUND", "سند اصلی یافت نشد.");
  const fy = currentFy(next);
  if (!fy) return fail("OUT_OF_YEAR", "سال مالی فعال نیست.");
  if (date < fy.startDate || date > fy.endDate) return fail("OUT_OF_YEAR", "تاریخ خارج از سال مالی است.");
  const builtLines = lines.map((l) => L(l.accountId, l.debit, l.credit, l));
  const tot = sumLines(builtLines);
  if (tot.diff !== 0) return fail("UNBALANCED", "سند اصلاحی نامتوازن است.");
  const posted = attachJournal(
    next,
    actor,
    { kind: "adjustment", method: "none", date, amount: tot.debit, description, lines },
    builtLines,
    "adjustment",
    { originalJournalId, adjustmentOfId: originalJournalId },
  );
  if (!posted.ok) return posted;
  next.version += 1;
  next.updatedAt = nowIso();
  audit(next, actor, "CreateAdjustment", "journal", posted.journal.id, {
    dayKey: date,
    oldValue: { original: orig.number },
    newValue: { number: posted.journal.number },
    reason,
  });
  return { ok: true, books: next, journal: posted.journal };
}

export function closeDayChecks(books: Books, dayKey: string) {
  const ops = liveOperations(books).filter((o) => o.dayKey === dayKey);
  const journals = liveJournals(books).filter((j) => j.dayKey === dayKey);
  const unbalanced = journals.filter((j) => {
    const tot = sumLines(books.journalLines.filter((l) => l.journalId === j.id));
    return tot.diff !== 0;
  });
  const missingSource = ops.filter((o) =>
    ["receipt", "payment", "expense", "income", "sale", "purchase"].includes(o.kind) &&
    o.method !== "credit" &&
    o.method !== "none" &&
    !o.moneyAccountId,
  );
  const negatives = ops.filter((o) => o.amount < 0);
  const incomplete = ops.filter((o) => !o.description || !o.journalId);
  const allLines = books.journalLines.filter((l) => journals.some((j) => j.id === l.journalId));
  const tot = sumLines(allLines);
  const tb = trialBalanceDiff(books, dayKey);
  return [
    { key: "balanced", ok: unbalanced.length === 0, detail: unbalanced.length ? `${unbalanced.length} سند نامتوازن` : "تمام اسناد متوازن‌اند" },
    { key: "complete", ok: incomplete.length === 0, detail: incomplete.length ? `${incomplete.length} عملیات ناقص` : "عملیات ناقص وجود ندارد" },
    { key: "negative", ok: negatives.length === 0, detail: negatives.length ? `${negatives.length} مبلغ منفی` : "مبلغ منفی غیرمجاز وجود ندارد" },
    { key: "source", ok: missingSource.length === 0, detail: missingSource.length ? `${missingSource.length} دریافت/پرداخت بدون منبع` : "منبع مالی همه عملیات مشخص است" },
    { key: "day-balance", ok: tot.diff === 0, detail: tot.diff === 0 ? "جمع بدهکار و بستانکار روز برابر است" : `اختلاف روز: ${tot.diff}` },
    { key: "trial", ok: tb === 0, detail: tb === 0 ? "تراز آزمایشی صفر است" : `اختلاف تراز: ${tb}` },
    { key: "accounts", ok: books.accounts.some((a) => a.code === "1101"), detail: "حساب‌های ضروری موجودند" },
    { key: "system", ok: true, detail: "خطای سیستمی ثبت نشده است" },
    { key: "cash", ok: true, detail: "وضعیت صندوق و بانک قابل کنترل است" },
    { key: "ops", ok: true, detail: `${ops.length} عملیات در این روز نهایی شده است` },
  ];
}

export function trialBalanceDiff(books: Books, through?: string) {
  const tot = { debit: 0, credit: 0 };
  for (const line of liveLines(books)) {
    const j = books.journals.find((x) => x.id === line.journalId);
    if (!j) continue;
    if (through && j.date > through) continue;
    tot.debit += line.debit;
    tot.credit += line.credit;
  }
  return tot.debit - tot.credit;
}

export function closeDay(books: Books, dayKey: string, actor: Actor): EngineResult<{ books: Books; closing: DailyClosing }> {
  const next = clone(books);
  if (isDayClosed(next, dayKey)) return fail("DAY_CLOSED", "این روز قبلاً بسته شده است.");
  const checks = closeDayChecks(next, dayKey);
  if (checks.some((c) => !c.ok)) return fail("INCOMPLETE", "کنترل‌های بستن روز ناموفق است. جزئیات را در صفحه بستن روز ببینید.");
  const fy = currentFy(next);
  if (!fy) return fail("OUT_OF_YEAR", "سال مالی فعال نیست.");
  const snapshot = JSON.stringify(next);
  const backup = {
    id: nid("bak"),
    name: `MR-KHORASANI-Backup-${dayKey}`,
    dayKey,
    createdAt: nowIso(),
    createdBy: actor.userId,
    size: snapshot.length,
  };
  next.backups.unshift(backup);
  persistSnapshot(next, backup.id, snapshot);
  for (const j of next.journals) {
    if (j.dayKey === dayKey && j.status === "posted") j.locked = true;
  }
  const cash = next.moneyAccounts.filter((m) => m.kind === "cash").reduce((s, m) => s + moneyBalance(next, m.id, dayKey), 0);
  const bank = next.moneyAccounts.filter((m) => m.kind === "bank").reduce((s, m) => s + moneyBalance(next, m.id, dayKey), 0);
  const ops = liveOperations(next).filter((o) => o.dayKey === dayKey);
  const rec = ops.filter((o) => o.kind === "receipt").reduce((s, o) => s + o.amount, 0);
  const pay = ops.filter((o) => o.kind === "payment").reduce((s, o) => s + o.amount, 0);
  const closing: DailyClosing = {
    id: nid("day"),
    dayKey,
    fiscalYearId: fy.id,
    status: "closed",
    closedBy: actor.userId,
    closedAt: nowIso(),
    checks,
    backupId: backup.id,
    packageSummary: {
      operations: ops.length,
      journals: liveJournals(next).filter((j) => j.dayKey === dayKey).length,
      receipts: rec,
      payments: pay,
      cash,
      bank,
    },
  };
  next.dailyClosings.unshift(closing);
  next.version += 1;
  next.updatedAt = nowIso();
  audit(next, actor, "CloseDay", "daily_closing", closing.id, { dayKey, newValue: closing.packageSummary });
  return { ok: true, books: next, closing };
}

const SNAPSHOTS = new Map<string, string>();
function persistSnapshot(books: Books, id: string, payload: string) {
  SNAPSHOTS.set(`${books.version}:${id}`, payload);
}

export function getLocalSnapshot(id: string) {
  for (const [k, v] of SNAPSHOTS) if (k.endsWith(`:${id}`)) return v;
  return null;
}

export function approveReopen(books: Books, requestId: string, actor: Actor): EngineResult<{ books: Books }> {
  const next = clone(books);
  const req = next.amendmentRequests.find((r) => r.id === requestId);
  if (!req) return fail("NOT_FOUND", "درخواست یافت نشد.");
  req.status = "approved";
  req.decidedBy = actor.userId;
  req.decidedAt = nowIso();
  const day = next.dailyClosings.find((d) => d.dayKey === req.dayKey && d.status === "closed");
  if (day) day.status = "reopened";
  next.version += 1;
  next.updatedAt = nowIso();
  audit(next, actor, "ReopenDay", "daily_closing", req.dayKey, { dayKey: req.dayKey, reason: req.reason });
  return { ok: true, books: next };
}

export function requestAmendment(books: Books, dayKey: string, reason: string, actor: Actor): EngineResult<{ books: Books }> {
  const next = clone(books);
  if (!isDayClosed(next, dayKey)) return fail("INCOMPLETE", "این روز بسته نیست.");
  next.amendmentRequests.unshift({
    id: nid("amd"),
    dayKey,
    reason,
    requestedBy: actor.userId,
    requestedAt: nowIso(),
    status: "pending",
  });
  next.version += 1;
  next.updatedAt = nowIso();
  audit(next, actor, "RequestAmendment", "daily_closing", dayKey, { dayKey, reason });
  return { ok: true, books: next };
}

export function postOpening(books: Books, date: string, lines: ManualLineInput[], actor: Actor): EngineResult<{ books: Books; journal: Journal }> {
  const next = clone(books);
  const built = lines.map((l) => L(l.accountId, l.debit, l.credit, l));
  const tot = sumLines(built);
  if (tot.diff !== 0) return fail("UNBALANCED", "سند افتتاحیه نامتوازن است.");
  const posted = attachJournal(next, actor, { kind: "manual", method: "none", date, amount: tot.debit, description: "سند افتتاحیه", lines }, built, "opening");
  if (!posted.ok) return posted;
  next.version += 1;
  next.updatedAt = nowIso();
  audit(next, actor, "CreateJournal", "journal", posted.journal.id, { dayKey: date, newValue: { kind: "opening", number: posted.journal.number } });
  return { ok: true, books: next, journal: posted.journal };
}
