export type AccountNature = "debit" | "credit";
export type AccountClass =
  | "asset"
  | "liability"
  | "equity"
  | "income"
  | "cogs"
  | "expense"
  | "contra"
  | "control";

export type FloatingKind =
  | "none"
  | "party"
  | "project"
  | "cost_center"
  | "employee"
  | "bank";

export type PartyKind =
  | "customer"
  | "supplier"
  | "employee"
  | "shareholder"
  | "bank"
  | "government"
  | "other";

export type OpKind =
  | "receipt"
  | "payment"
  | "transfer"
  | "sale"
  | "sale_return"
  | "purchase"
  | "purchase_return"
  | "expense"
  | "income"
  | "check_receive"
  | "check_issue"
  | "check_clear"
  | "check_bounce"
  | "petty_fund"
  | "petty_settle"
  | "capital"
  | "draw"
  | "payroll"
  | "depreciation"
  | "prepaid"
  | "unearned"
  | "manual"
  | "adjustment";

export type PayMethod = "cash" | "bank" | "credit" | "mixed" | "none";
export type RecordStatus = "draft" | "posted" | "deleted" | "reversed";
export type DayStatus = "open" | "closed" | "reopened";
export type SyncStatus = "synced" | "pending" | "conflict";
export type JournalKind =
  | "auto"
  | "manual"
  | "opening"
  | "closing"
  | "adjustment"
  | "reversal";
export type RoleId =
  | "admin"
  | "finance_manager"
  | "accountant"
  | "cashier"
  | "sales"
  | "warehouse"
  | "auditor";
export type CheckStatus = "pending" | "cleared" | "bounced" | "transferred";

export type Account = {
  id: string;
  code: string;
  name: string;
  class: AccountClass;
  nature: AccountNature;
  level: 1 | 2 | 3 | 4;
  parentId: string | null;
  floating: FloatingKind;
  isPostable: boolean;
  isCash: boolean;
  isBank: boolean;
  isPetty: boolean;
  active: boolean;
};

export type Party = {
  id: string;
  code: string;
  name: string;
  kind: PartyKind;
  phone: string;
  address: string;
  city: string;
  active: boolean;
  note: string;
  createdAt: string;
};

export type MoneyAccount = {
  id: string;
  name: string;
  kind: "cash" | "bank" | "petty";
  accountCode: string;
  bankName?: string;
  accountNo?: string;
  active: boolean;
};

export type Product = {
  id: string;
  sku: string;
  name: string;
  salePrice: number;
  cost: number;
  stock: number;
  active: boolean;
};

export type InvoiceLine = {
  productId?: string;
  description: string;
  qty: number;
  unitPrice: number;
  discount: number;
};

export type Invoice = {
  id: string;
  number: string;
  kind: "sale" | "purchase" | "sale_return" | "purchase_return";
  partyId: string;
  date: string;
  lines: InvoiceLine[];
  subtotal: number;
  discount: number;
  shipping: number;
  total: number;
  paid: number;
  operationId: string;
  status: RecordStatus;
};

export type Operation = {
  id: string;
  number: string;
  kind: OpKind;
  method: PayMethod;
  date: string;
  dayKey: string;
  fiscalYearId: string;
  partyId?: string;
  moneyAccountId?: string;
  destMoneyAccountId?: string;
  accountId?: string;
  amount: number;
  paidAmount: number;
  discount: number;
  shipping: number;
  description: string;
  reference?: string;
  invoiceId?: string;
  checkId?: string;
  journalId: string;
  status: RecordStatus;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  deletedAt?: string;
  deletedBy?: string;
  deleteReason?: string;
  version: number;
  syncStatus: SyncStatus;
};

export type Journal = {
  id: string;
  number: string;
  kind: JournalKind;
  date: string;
  dayKey: string;
  fiscalYearId: string;
  description: string;
  operationId?: string;
  originalJournalId?: string;
  adjustmentOfId?: string;
  status: RecordStatus;
  locked: boolean;
  createdBy: string;
  createdAt: string;
};

export type JournalLine = {
  id: string;
  journalId: string;
  accountId: string;
  partyId?: string;
  moneyAccountId?: string;
  projectId?: string;
  costCenterId?: string;
  debit: number;
  credit: number;
  description: string;
};

export type CheckItem = {
  id: string;
  number: string;
  kind: "received" | "issued";
  bankName: string;
  amount: number;
  issueDate: string;
  dueDate: string;
  partyId?: string;
  status: CheckStatus;
  operationId?: string;
  clearOperationId?: string;
};

export type FiscalYear = {
  id: string;
  name: string;
  jalaliYear: number;
  startDate: string;
  endDate: string;
  status: "open" | "closed";
  isCurrent: boolean;
};

export type DailyClosing = {
  id: string;
  dayKey: string;
  fiscalYearId: string;
  status: DayStatus;
  closedBy: string;
  closedAt: string;
  checks: { key: string; ok: boolean; detail: string }[];
  backupId?: string;
  packageSummary: Record<string, number | string>;
};

export type AmendmentRequest = {
  id: string;
  dayKey: string;
  reason: string;
  requestedBy: string;
  requestedAt: string;
  status: "pending" | "approved" | "rejected";
  decidedBy?: string;
  decidedAt?: string;
};

export type AuditEvent = {
  id: string;
  at: string;
  userId: string;
  userName: string;
  action: string;
  entity: string;
  entityId: string;
  dayKey?: string;
  oldValue?: unknown;
  newValue?: unknown;
  reason?: string;
  device: string;
};

export type BackupRecord = {
  id: string;
  name: string;
  dayKey?: string;
  createdAt: string;
  createdBy: string;
  size: number;
};

export type Company = {
  name: string;
  legalName: string;
  nationalId: string;
  phone: string;
  address: string;
  city: string;
};

export type AppSettings = {
  currency: "IRR";
  displayToman: boolean;
  persianDigits: boolean;
  perpetualInventory: boolean;
  role: RoleId;
  company: Company;
};

export type StaffUser = {
  id: string;
  name: string;
  role: RoleId;
  active: boolean;
};

export type Books = {
  schemaVersion: 1;
  version: number;
  updatedAt: string;
  companySeeded: boolean;
  company: Company;
  settings: AppSettings;
  fiscalYears: FiscalYear[];
  accounts: Account[];
  parties: Party[];
  moneyAccounts: MoneyAccount[];
  products: Product[];
  operations: Operation[];
  journals: Journal[];
  journalLines: JournalLine[];
  invoices: Invoice[];
  checks: CheckItem[];
  dailyClosings: DailyClosing[];
  amendmentRequests: AmendmentRequest[];
  auditLogs: AuditEvent[];
  backups: BackupRecord[];
  staff: StaffUser[];
  counters: { operation: number; journal: number; invoice: number; party: number };
};

export type ManualLineInput = {
  accountId: string;
  partyId?: string;
  moneyAccountId?: string;
  debit: number;
  credit: number;
  description: string;
};

export type OperationInput = {
  kind: OpKind;
  method: PayMethod;
  date: string;
  partyId?: string;
  moneyAccountId?: string;
  destMoneyAccountId?: string;
  accountId?: string;
  amount: number;
  paidAmount?: number;
  discount?: number;
  shipping?: number;
  description: string;
  reference?: string;
  invoiceLines?: InvoiceLine[];
  checkNumber?: string;
  checkBank?: string;
  checkDue?: string;
  checkId?: string;
  lines?: ManualLineInput[];
  originalJournalId?: string;
  reason?: string;
};

export type Actor = {
  userId: string;
  userName: string;
  device: string;
};

export type EngineError = {
  ok: false;
  error: string;
  code:
    | "UNBALANCED"
    | "DAY_CLOSED"
    | "ZERO_AMOUNT"
    | "INVALID_ACCOUNT"
    | "INVALID_PARTY"
    | "MISSING_SOURCE"
    | "MISSING_DEST"
    | "OUT_OF_YEAR"
    | "LOCKED"
    | "INACTIVE"
    | "INCOMPLETE"
    | "NEGATIVE"
    | "NOT_FOUND"
    | "FORBIDDEN";
};

export type EngineOk<T> = { ok: true } & T;
export type EngineResult<T> = EngineOk<T> | EngineError;
