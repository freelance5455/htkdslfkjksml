import type { OpKind, RoleId } from "./types";

const ALL: RoleId[] = [
  "admin",
  "finance_manager",
  "accountant",
  "cashier",
  "sales",
  "warehouse",
  "auditor",
];

export type Perm =
  | "ops.create"
  | "ops.edit"
  | "ops.delete"
  | "journal.manual"
  | "close.day"
  | "close.reopen"
  | "reports.view"
  | "crm.view"
  | "settings"
  | "backup"
  | "users"
  | "accounts.edit"
  | "parties.edit"
  | "audit.view";

const MATRIX: Record<Perm, RoleId[]> = {
  "ops.create": ["admin", "finance_manager", "accountant", "cashier", "sales", "warehouse"],
  "ops.edit": ["admin", "finance_manager", "accountant", "cashier", "sales"],
  "ops.delete": ["admin", "finance_manager", "accountant"],
  "journal.manual": ["admin", "finance_manager", "accountant"],
  "close.day": ["admin", "finance_manager"],
  "close.reopen": ["admin"],
  "reports.view": ALL,
  "crm.view": ["admin", "finance_manager", "accountant", "sales", "auditor"],
  settings: ["admin", "finance_manager"],
  backup: ["admin", "finance_manager"],
  users: ["admin"],
  "accounts.edit": ["admin", "finance_manager"],
  "parties.edit": ["admin", "finance_manager", "accountant", "sales"],
  "audit.view": ["admin", "finance_manager", "auditor"],
};

export function can(role: RoleId, perm: Perm) {
  return MATRIX[perm].includes(role);
}

export function canPostKind(role: RoleId, kind: OpKind) {
  if (role === "admin" || role === "finance_manager" || role === "accountant") return true;
  if (role === "auditor") return false;
  if (role === "cashier") {
    return ["receipt", "payment", "transfer", "petty_fund", "petty_settle", "check_receive", "check_issue", "check_clear"].includes(kind);
  }
  if (role === "sales") return ["sale", "sale_return", "receipt", "check_receive"].includes(kind);
  if (role === "warehouse") return ["purchase", "purchase_return", "payment"].includes(kind);
  return false;
}
