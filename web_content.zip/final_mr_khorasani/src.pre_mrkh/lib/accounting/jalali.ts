const FA_DIGITS = "۰۱۲۳۴۵۶۷۸۹";
const MONTHS = [
  "فروردین",
  "اردیبهشت",
  "خرداد",
  "تیر",
  "مرداد",
  "شهریور",
  "مهر",
  "آبان",
  "آذر",
  "دی",
  "بهمن",
  "اسفند",
];
const WEEKDAYS = ["یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه"];

function div(a: number, b: number) {
  return Math.trunc(a / b);
}
function mod(a: number, b: number) {
  return a - Math.trunc(a / b) * b;
}

function g2d(gy: number, gm: number, gd: number) {
  const d =
    div((gy + div(gm - 8, 6) + 100100) * 1461, 4) +
    div(153 * mod(gm + 9, 12) + 2, 5) +
    gd -
    34840408;
  return d - div(div(gy + 100100 + div(gm - 8, 6), 100) * 3, 4) + 752;
}

function d2g(jdn: number) {
  let j = 4 * jdn + 139361631;
  j = j + div(div(4 * jdn + 183187720, 146097) * 3, 4) * 4 - 3908;
  const i = div(mod(j, 1461), 4) * 5 + 308;
  const gd = div(mod(i, 153), 5) + 1;
  const gm = mod(div(i, 153), 12) + 1;
  const gy = div(j, 1461) - 100100 + div(8 - gm, 6);
  return { gy, gm, gd };
}

function jalCal(jdn: number) {
  const gy = d2g(jdn).gy;
  let jy = gy - 621;
  const r = jalCalLeap(jy);
  const jdn1f = g2d(gy, 3, r.march);
  let k = jdn - jdn1f;
  let jm: number;
  let jd: number;
  if (k >= 0) {
    if (k <= 185) {
      jm = 1 + div(k, 31);
      jd = mod(k, 31) + 1;
    } else {
      k -= 186;
      jm = 7 + div(k, 30);
      jd = mod(k, 30) + 1;
    }
  } else {
    jy -= 1;
    k += 179;
    if (r.leap === 1) k += 1;
    jm = 1 + div(k, 31);
    jd = mod(k, 31) + 1;
  }
  return { jy, jm, jd };
}

function jalCalLeap(jy: number) {
  const breaks = [
    -61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635, 2060, 2292, 2491, 2606,
    2809, 2957, 3110, 3322, 3597, 3730, 3985, 4089, 4273, 4392, 4479, 4534, 4700, 4783,
    4805, 4952, 5000,
  ];
  const bl = breaks.length;
  const gy = jy + 621;
  let leapJ = -14;
  let jp = breaks[0];
  let jump = 0;
  for (let i = 1; i < bl; i += 1) {
    const jm = breaks[i];
    jump = jm - jp;
    if (jy < jm) break;
    leapJ = leapJ + div(jump, 33) * 8 + div(mod(jump, 33), 4);
    jp = jm;
  }
  let n = jy - jp;
  leapJ = leapJ + div(n, 33) * 8 + div(mod(n, 33) + 3, 4);
  if (mod(jump, 33) === 4 && jump - n === 4) leapJ += 1;
  const leapG = div(gy, 4) - div((div(gy, 100) + 1) * 3, 4) - 150;
  const march = 20 + leapJ - leapG;
  if (jump - n < 6) n = n - jump + div(jump + 4, 33) * 33;
  let leap = mod(mod(n + 1, 33) - 1, 4);
  if (leap === -1) leap = 4;
  return { leap, gy, march };
}

export function toJalali(iso: string) {
  const [y, m, d] = iso.slice(0, 10).split("-").map(Number);
  return jalCal(g2d(y, m, d));
}

export function toGregorian(jy: number, jm: number, jd: number) {
  const r = jalCalLeap(jy);
  const jdn =
    g2d(r.gy, 3, r.march) + (jm - 1) * 31 - div(jm, 7) * (jm - 7) + jd - 1;
  const g = d2g(jdn);
  return `${pad(g.gy)}-${pad(g.gm)}-${pad(g.gd)}`;
}

export function todayIso() {
  const n = new Date();
  return `${n.getFullYear()}-${pad(n.getMonth() + 1)}-${pad(n.getDate())}`;
}

export function pad(n: number) {
  return n < 10 ? `0${n}` : String(n);
}

export function toFaDigits(value: string | number) {
  return String(value).replace(/\d/g, (d) => FA_DIGITS[Number(d)] ?? d);
}

export function fromFaDigits(value: string) {
  return value.replace(/[۰-۹]/g, (d) => String(FA_DIGITS.indexOf(d)));
}

export function formatJalali(iso: string, digits = true) {
  const { jy, jm, jd } = toJalali(iso);
  const s = `${jy}/${pad(jm)}/${pad(jd)}`;
  return digits ? toFaDigits(s) : s;
}

export function formatJalaliLong(iso: string, digits = true) {
  const { jy, jm, jd } = toJalali(iso);
  const dt = new Date(`${iso}T12:00:00`);
  const w = WEEKDAYS[dt.getDay()];
  const s = `${w} ${jd} ${MONTHS[jm - 1]} ${jy}`;
  return digits ? toFaDigits(s) : s;
}

export function jalaliMonthName(jm: number) {
  return MONTHS[jm - 1] ?? "";
}

export function addDays(iso: string, days: number) {
  const d = new Date(`${iso}T12:00:00`);
  d.setDate(d.getDate() + days);
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

export function isoRangeInclusive(from: string, to: string) {
  const out: string[] = [];
  let cur = from;
  while (cur <= to) {
    out.push(cur);
    cur = addDays(cur, 1);
  }
  return out;
}
