import { buildChart } from "./chart";
import { closeDay, postOpening, postOperation } from "./engine";
import { nid, nowIso } from "./format";
import { addDays, todayIso } from "./jalali";
import type { Actor, Books, ManualLineInput, OperationInput, Party } from "./types";

const ACTOR: Actor = { userId: "seed", userName: "سیستم", device: "seed" };

function emptyBooks(): Books {
  return {
    schemaVersion: 1,
    version: 1,
    updatedAt: nowIso(),
    companySeeded: true,
    company: {
      name: "بازرگانی خراسانی",
      legalName: "شرکت بازرگانی آقای خراسانی",
      nationalId: "14005789123",
      phone: "021-91001234",
      address: "تهران، خیابان کریمخان",
      city: "تهران",
    },
    settings: {
      currency: "IRR",
      displayToman: false,
      persianDigits: true,
      perpetualInventory: true,
      role: "admin",
      company: {
        name: "بازرگانی خراسانی",
        legalName: "شرکت بازرگانی آقای خراسانی",
        nationalId: "14005789123",
        phone: "021-91001234",
        address: "تهران، خیابان کریمخان",
        city: "تهران",
      },
    },
    fiscalYears: [
      {
        id: nid("fy"),
        name: "سال مالی ۱۴۰۵",
        jalaliYear: 1405,
        startDate: "2026-03-21",
        endDate: "2027-03-20",
        status: "open",
        isCurrent: true,
      },
    ],
    accounts: buildChart(),
    parties: [],
    moneyAccounts: [],
    products: [],
    operations: [],
    journals: [],
    journalLines: [],
    invoices: [],
    checks: [],
    dailyClosings: [],
    amendmentRequests: [],
    auditLogs: [],
    backups: [],
    staff: [
      { id: nid("st"), name: "مدیر سیستم", role: "admin", active: true },
      { id: nid("st"), name: "حسابدار ارشد", role: "accountant", active: true },
      { id: nid("st"), name: "صندوقدار", role: "cashier", active: true },
    ],
    counters: { operation: 0, journal: 0, invoice: 0, party: 0 },
  };
}

function party(books: Books, code: string, name: string, kind: Party["kind"], phone: string, city: string): Party {
  const p: Party = {
    id: nid("pty"),
    code,
    name,
    kind,
    phone,
    address: city,
    city,
    active: true,
    note: "",
    createdAt: nowIso(),
  };
  books.parties.push(p);
  books.counters.party += 1;
  return p;
}

export function createDemoBooks(): Books {
  let books = emptyBooks();
  const byCode = (c: string) => books.accounts.find((a) => a.code === c)!;

  const cash = { id: nid("ma"), name: "صندوق مرکزی", kind: "cash" as const, accountCode: "1101", active: true };
  const mellat = { id: nid("ma"), name: "بانک ملت — جاری", kind: "bank" as const, accountCode: "1102", bankName: "ملت", accountNo: "1289-774", active: true };
  const melli = { id: nid("ma"), name: "بانک ملی — جاری", kind: "bank" as const, accountCode: "1102", bankName: "ملی", accountNo: "0100-332", active: true };
  const petty = { id: nid("ma"), name: "تنخواه فروشگاه", kind: "petty" as const, accountCode: "1103", active: true };
  books.moneyAccounts = [cash, mellat, melli, petty];

  const c1 = party(books, "C-001", "فروشگاه نور", "customer", "09121234567", "تهران");
  const c2 = party(books, "C-002", "شرکت آریا پخش", "customer", "09129876543", "کرج");
  const c3 = party(books, "C-003", "سوپرمارکت میلاد", "customer", "09351230011", "اصفهان");
  const c4 = party(books, "C-004", "بازرگانی سپهر", "customer", "09121112233", "مشهد");
  const c5 = party(books, "C-005", "هلدینگ پارس", "customer", "02188001122", "تهران");
  const s1 = party(books, "S-001", "تأمین کالای شرق", "supplier", "02144556677", "تهران");
  const s2 = party(books, "S-002", "صنایع غذایی کاسپین", "supplier", "0133332211", "رشت");
  const s3 = party(books, "S-003", "پخش البرز", "supplier", "0263440001", "کرج");
  const e1 = party(books, "E-001", "علی رضایی", "employee", "09120000001", "تهران");
  party(books, "E-002", "مریم حسینی", "employee", "09120000002", "تهران");
  party(books, "SH-001", "آقای خراسانی", "shareholder", "09121000000", "تهران");

  books.products = [
    { id: nid("prd"), sku: "P-01", name: "برنج طارم ۱۰ کیلویی", salePrice: 2_450_000, cost: 1_820_000, stock: 80, active: true },
    { id: nid("prd"), sku: "P-02", name: "روغن ۵ لیتری", salePrice: 980_000, cost: 720_000, stock: 120, active: true },
    { id: nid("prd"), sku: "P-03", name: "چای ممتاز ۵۰۰ گرم", salePrice: 640_000, cost: 410_000, stock: 60, active: true },
    { id: nid("prd"), sku: "P-04", name: "قند کله‌ای", salePrice: 310_000, cost: 210_000, stock: 200, active: true },
  ];

  const openLines: ManualLineInput[] = [
    { accountId: byCode("1101").id, debit: 80_000_000, credit: 0, description: "افتتاح صندوق", moneyAccountId: cash.id },
    { accountId: byCode("1102").id, debit: 400_000_000, credit: 0, description: "افتتاح ملت", moneyAccountId: mellat.id },
    { accountId: byCode("1102").id, debit: 150_000_000, credit: 0, description: "افتتاح ملی", moneyAccountId: melli.id },
    { accountId: byCode("1103").id, debit: 10_000_000, credit: 0, description: "افتتاح تنخواه", moneyAccountId: petty.id },
    { accountId: byCode("1104").id, debit: 55_000_000, credit: 0, description: "مانده مشتری نور", partyId: c1.id },
    { accountId: byCode("1104").id, debit: 40_000_000, credit: 0, description: "مانده آریا پخش", partyId: c2.id },
    { accountId: byCode("1106").id, debit: 180_000_000, credit: 0, description: "موجودی کالا" },
    { accountId: byCode("1201").id, debit: 250_000_000, credit: 0, description: "دارایی ثابت" },
    { accountId: byCode("1202").id, debit: 0, credit: 40_000_000, description: "استهلاک انباشته" },
    { accountId: byCode("2101").id, debit: 0, credit: 42_000_000, description: "بدهی تأمین شرق", partyId: s1.id },
    { accountId: byCode("2101").id, debit: 0, credit: 20_000_000, description: "بدهی کاسپین", partyId: s2.id },
    { accountId: byCode("2102").id, debit: 0, credit: 30_000_000, description: "اسناد پرداختنی" },
    { accountId: byCode("3101").id, debit: 0, credit: 1_033_000_000, description: "سرمایه" },
  ];
  const opening = postOpening(books, "2026-03-21", openLines, ACTOR);
  if (!opening.ok) throw new Error(opening.error);
  books = opening.books;

  const today = todayIso();
  const d = (offset: number) => addDays(today, offset);

  const run = (input: OperationInput) => {
    const r = postOperation(books, input, ACTOR);
    if (!r.ok) throw new Error(`${input.kind} ${input.date}: ${r.error}`);
    books = r.books;
  };

  const p1 = books.products[0];
  const p2 = books.products[1];
  const p3 = books.products[2];

  run({
    kind: "sale",
    method: "cash",
    date: d(-12),
    partyId: c3.id,
    moneyAccountId: cash.id,
    amount: 0,
    description: "فروش نقدی به سوپرمارکت میلاد",
    invoiceLines: [
      { productId: p1.id, description: p1.name, qty: 4, unitPrice: p1.salePrice, discount: 0 },
      { productId: p4(books).id, description: p4(books).name, qty: 10, unitPrice: p4(books).salePrice, discount: 0 },
    ],
  });
  run({
    kind: "sale",
    method: "bank",
    date: d(-11),
    partyId: c4.id,
    moneyAccountId: mellat.id,
    amount: 0,
    description: "فروش بانکی بازرگانی سپهر",
    invoiceLines: [{ productId: p2.id, description: p2.name, qty: 20, unitPrice: p2.salePrice, discount: 1_000_000 }],
  });
  run({
    kind: "sale",
    method: "credit",
    date: d(-10),
    partyId: c5.id,
    amount: 0,
    description: "فروش نسیه هلدینگ پارس",
    invoiceLines: [
      { productId: p1.id, description: p1.name, qty: 12, unitPrice: p1.salePrice, discount: 0 },
      { productId: p3.id, description: p3.name, qty: 8, unitPrice: p3.salePrice, discount: 0 },
    ],
  });
  run({
    kind: "sale",
    method: "mixed",
    date: d(-9),
    partyId: c2.id,
    moneyAccountId: cash.id,
    amount: 0,
    paidAmount: 8_000_000,
    description: "فروش ترکیبی آریا پخش",
    invoiceLines: [{ productId: p2.id, description: p2.name, qty: 15, unitPrice: p2.salePrice, discount: 0 }],
  });
  run({
    kind: "purchase",
    method: "credit",
    date: d(-11),
    partyId: s1.id,
    amount: 0,
    description: "خرید نسیه از تأمین شرق",
    invoiceLines: [{ productId: p1.id, description: p1.name, qty: 30, unitPrice: p1.cost, discount: 0 }],
  });
  run({
    kind: "purchase",
    method: "bank",
    date: d(-8),
    partyId: s2.id,
    moneyAccountId: melli.id,
    amount: 0,
    description: "خرید بانکی از کاسپین",
    invoiceLines: [{ productId: p2.id, description: p2.name, qty: 40, unitPrice: p2.cost, discount: 0 }],
  });
  run({ kind: "receipt", method: "bank", date: d(-8), partyId: c1.id, moneyAccountId: mellat.id, amount: 18_000_000, description: "دریافت از فروشگاه نور بابت فاکتور" });
  run({ kind: "receipt", method: "cash", date: d(-7), partyId: c2.id, moneyAccountId: cash.id, amount: 12_000_000, description: "دریافت نقدی آریا پخش" });
  run({ kind: "payment", method: "bank", date: d(-7), partyId: s1.id, moneyAccountId: mellat.id, amount: 22_000_000, description: "پرداخت به تأمین شرق" });
  run({ kind: "expense", method: "bank", date: d(-6), moneyAccountId: mellat.id, accountId: byCode("6102").id, amount: 45_000_000, description: "اجاره شهریور فروشگاه" });
  run({ kind: "expense", method: "cash", date: d(-6), moneyAccountId: cash.id, accountId: byCode("6103").id, amount: 4_800_000, description: "قبض برق و گاز" });
  run({ kind: "payroll", method: "bank", date: d(-5), partyId: e1.id, moneyAccountId: mellat.id, amount: 38_000_000, description: "حقوق شهریور" });
  run({ kind: "transfer", method: "none", date: d(-5), moneyAccountId: mellat.id, destMoneyAccountId: cash.id, amount: 20_000_000, description: "انتقال بانک ملت به صندوق" });
  run({ kind: "petty_fund", method: "none", date: d(-5), moneyAccountId: cash.id, destMoneyAccountId: petty.id, amount: 5_000_000, description: "تخصیص تنخواه" });
  run({ kind: "check_receive", method: "none", date: d(-4), partyId: c5.id, amount: 25_000_000, description: "دریافت چک هلدینگ پارس", checkNumber: "884512", checkBank: "صادرات", checkDue: addDays(today, 12) });
  run({ kind: "check_issue", method: "none", date: d(-4), partyId: s3.id, amount: 14_000_000, description: "صدور چک به پخش البرز", checkNumber: "102331", checkBank: "ملت", checkDue: addDays(today, 7) });
  run({ kind: "expense", method: "bank", date: d(-3), moneyAccountId: mellat.id, accountId: byCode("6105").id, amount: 7_500_000, description: "هزینه بازاریابی" });
  run({ kind: "income", method: "bank", date: d(-3), moneyAccountId: melli.id, accountId: byCode("4103").id, amount: 3_200_000, description: "سود سپرده کوتاه‌مدت" });
  run({ kind: "sale", method: "cash", date: d(-2), partyId: c1.id, moneyAccountId: cash.id, amount: 0, description: "فروش نقدی نور", invoiceLines: [{ productId: p3.id, description: p3.name, qty: 6, unitPrice: p3.salePrice, discount: 200_000 }] });
  run({ kind: "receipt", method: "bank", date: d(-2), partyId: c4.id, moneyAccountId: mellat.id, amount: 9_500_000, description: "وصول مطالبات سپهر" });
  run({ kind: "payment", method: "bank", date: d(-2), partyId: s2.id, moneyAccountId: melli.id, amount: 8_000_000, description: "پرداخت کاسپین" });
  run({ kind: "expense", method: "cash", date: d(-1), moneyAccountId: petty.id, accountId: byCode("6111").id, amount: 1_200_000, description: "هزینه تنخواه — ایاب و ذهاب" });
  run({ kind: "depreciation", method: "none", date: d(-1), amount: 4_000_000, description: "استهلاک ماهانه تجهیزات" });

  // close older days except today and yesterday-wait: close all before today
  const start = d(-12);
  for (let i = 0; i < 12; i++) {
    const day = addDays(start, i);
    if (day >= today) break;
    const closed = closeDay(books, day, ACTOR);
    if (closed.ok) books = closed.books;
  }

  run({
    kind: "sale",
    method: "bank",
    date: today,
    partyId: c3.id,
    moneyAccountId: mellat.id,
    amount: 0,
    description: "فروش امروز به سوپرمارکت میلاد",
    invoiceLines: [{ productId: p2.id, description: p2.name, qty: 8, unitPrice: p2.salePrice, discount: 0 }],
  });
  run({ kind: "receipt", method: "cash", date: today, partyId: c2.id, moneyAccountId: cash.id, amount: 6_500_000, description: "دریافت امروز از آریا پخش" });
  run({ kind: "expense", method: "cash", date: today, moneyAccountId: cash.id, accountId: byCode("6104").id, amount: 850_000, description: "هزینه حمل امروز" });

  return books;
}

function p4(books: Books) {
  return books.products[3];
}

export function createEmptyCompany(): Books {
  const b = emptyBooks();
  b.companySeeded = false;
  b.moneyAccounts = [
    { id: nid("ma"), name: "صندوق مرکزی", kind: "cash", accountCode: "1101", active: true },
  ];
  return b;
}
