import { nid } from "./format";
import type { Account, AccountClass, AccountNature, FloatingKind } from "./types";

type Spec = {
  code: string;
  name: string;
  class: AccountClass;
  nature: AccountNature;
  level: 1 | 2 | 3 | 4;
  parent?: string;
  floating?: FloatingKind;
  postable?: boolean;
  cash?: boolean;
  bank?: boolean;
  petty?: boolean;
};

const SPECS: Spec[] = [
  { code: "1", name: "دارایی‌ها", class: "asset", nature: "debit", level: 1, postable: false },
  { code: "2", name: "بدهی‌ها", class: "liability", nature: "credit", level: 1, postable: false },
  { code: "3", name: "سرمایه", class: "equity", nature: "credit", level: 1, postable: false },
  { code: "4", name: "درآمدها", class: "income", nature: "credit", level: 1, postable: false },
  { code: "5", name: "بهای تمام‌شده", class: "cogs", nature: "debit", level: 1, postable: false },
  { code: "6", name: "هزینه‌ها", class: "expense", nature: "debit", level: 1, postable: false },

  { code: "11", name: "دارایی‌های جاری", class: "asset", nature: "debit", level: 2, parent: "1", postable: false },
  { code: "12", name: "دارایی‌های غیرجاری", class: "asset", nature: "debit", level: 2, parent: "1", postable: false },
  { code: "21", name: "بدهی‌های جاری", class: "liability", nature: "credit", level: 2, parent: "2", postable: false },
  { code: "31", name: "حقوق صاحبان سرمایه", class: "equity", nature: "credit", level: 2, parent: "3", postable: false },
  { code: "41", name: "درآمد عملیاتی", class: "income", nature: "credit", level: 2, parent: "4", postable: false },
  { code: "42", name: "سایر درآمدها", class: "income", nature: "credit", level: 2, parent: "4", postable: false },
  { code: "51", name: "بهای تمام‌شده فروش", class: "cogs", nature: "debit", level: 2, parent: "5", postable: false },
  { code: "61", name: "هزینه‌های عملیاتی", class: "expense", nature: "debit", level: 2, parent: "6", postable: false },

  { code: "1101", name: "صندوق", class: "asset", nature: "debit", level: 3, parent: "11", cash: true },
  { code: "1102", name: "بانک‌ها", class: "asset", nature: "debit", level: 3, parent: "11", bank: true, floating: "bank" },
  { code: "1103", name: "تنخواه", class: "asset", nature: "debit", level: 3, parent: "11", petty: true },
  { code: "1104", name: "حساب‌های دریافتنی", class: "asset", nature: "debit", level: 3, parent: "11", floating: "party" },
  { code: "1105", name: "اسناد دریافتنی", class: "asset", nature: "debit", level: 3, parent: "11", floating: "party" },
  { code: "1106", name: "موجودی کالا", class: "asset", nature: "debit", level: 3, parent: "11" },
  { code: "1107", name: "پیش‌پرداخت‌ها", class: "asset", nature: "debit", level: 3, parent: "11", floating: "party" },
  { code: "1108", name: "سپرده‌ها", class: "asset", nature: "debit", level: 3, parent: "11" },
  { code: "1201", name: "دارایی ثابت", class: "asset", nature: "debit", level: 3, parent: "12" },
  { code: "1202", name: "استهلاک انباشته", class: "contra", nature: "credit", level: 3, parent: "12" },

  { code: "2101", name: "حساب‌های پرداختنی", class: "liability", nature: "credit", level: 3, parent: "21", floating: "party" },
  { code: "2102", name: "اسناد پرداختنی", class: "liability", nature: "credit", level: 3, parent: "21", floating: "party" },
  { code: "2103", name: "مالیات پرداختنی", class: "liability", nature: "credit", level: 3, parent: "21" },
  { code: "2104", name: "بیمه پرداختنی", class: "liability", nature: "credit", level: 3, parent: "21" },
  { code: "2105", name: "حقوق پرداختنی", class: "liability", nature: "credit", level: 3, parent: "21" },
  { code: "2106", name: "پیش‌دریافت‌ها", class: "liability", nature: "credit", level: 3, parent: "21", floating: "party" },
  { code: "2107", name: "سایر بدهی‌ها", class: "liability", nature: "credit", level: 3, parent: "21" },

  { code: "3101", name: "سرمایه", class: "equity", nature: "credit", level: 3, parent: "31" },
  { code: "3102", name: "برداشت", class: "equity", nature: "debit", level: 3, parent: "31" },
  { code: "3103", name: "سود و زیان انباشته", class: "equity", nature: "credit", level: 3, parent: "31" },
  { code: "3104", name: "سود و زیان جاری", class: "equity", nature: "credit", level: 3, parent: "31" },

  { code: "4101", name: "فروش", class: "income", nature: "credit", level: 3, parent: "41" },
  { code: "4102", name: "درآمد خدمات", class: "income", nature: "credit", level: 3, parent: "41" },
  { code: "4103", name: "سایر درآمدها", class: "income", nature: "credit", level: 3, parent: "42" },
  { code: "4104", name: "تخفیفات فروش", class: "contra", nature: "debit", level: 3, parent: "41" },
  { code: "4105", name: "برگشت از فروش", class: "contra", nature: "debit", level: 3, parent: "41" },

  { code: "5101", name: "بهای تمام‌شده کالای فروش‌رفته", class: "cogs", nature: "debit", level: 3, parent: "51" },
  { code: "5102", name: "بهای خدمات ارائه‌شده", class: "cogs", nature: "debit", level: 3, parent: "51" },

  { code: "6101", name: "حقوق و دستمزد", class: "expense", nature: "debit", level: 3, parent: "61" },
  { code: "6102", name: "اجاره", class: "expense", nature: "debit", level: 3, parent: "61" },
  { code: "6103", name: "آب و برق و گاز", class: "expense", nature: "debit", level: 3, parent: "61" },
  { code: "6104", name: "حمل", class: "expense", nature: "debit", level: 3, parent: "61" },
  { code: "6105", name: "بازاریابی", class: "expense", nature: "debit", level: 3, parent: "61" },
  { code: "6106", name: "تبلیغات", class: "expense", nature: "debit", level: 3, parent: "61" },
  { code: "6107", name: "تعمیرات", class: "expense", nature: "debit", level: 3, parent: "61" },
  { code: "6108", name: "استهلاک", class: "expense", nature: "debit", level: 3, parent: "61" },
  { code: "6109", name: "هزینه بانکی", class: "expense", nature: "debit", level: 3, parent: "61" },
  { code: "6110", name: "هزینه مالی", class: "expense", nature: "debit", level: 3, parent: "61" },
  { code: "6111", name: "سایر هزینه‌ها", class: "expense", nature: "debit", level: 3, parent: "61" },
];

export function buildChart(): Account[] {
  const byCode = new Map<string, Account>();
  for (const s of SPECS) {
    const parent = s.parent ? byCode.get(s.parent) : undefined;
    const a: Account = {
      id: nid("acc"),
      code: s.code,
      name: s.name,
      class: s.class,
      nature: s.nature,
      level: s.level,
      parentId: parent?.id ?? null,
      floating: s.floating ?? "none",
      isPostable: s.postable ?? s.level >= 3,
      isCash: !!s.cash,
      isBank: !!s.bank,
      isPetty: !!s.petty,
      active: true,
    };
    byCode.set(s.code, a);
  }
  return [...byCode.values()];
}

export function accountByCode(accounts: Account[], code: string) {
  return accounts.find((a) => a.code === code);
}

export function postableAccounts(accounts: Account[]) {
  return accounts.filter((a) => a.isPostable && a.active);
}
