import { Mark } from "./logo";

export function Splash({ label = "در حال آماده‌سازی دفتر…" }: { label?: string }) {
  return (
    <div className="flex min-h-dvh flex-col items-center justify-center bg-navy px-6 text-center">
      <Mark className="size-20" />
      <div className="mt-6 font-display text-3xl tracking-tight text-gold-soft">MR,KHORASANI</div>
      <div className="mt-1 text-xs tracking-[0.22em] text-gold/70 uppercase">Professional Accounting System</div>
      <div className="gold-rule mt-8 w-40" />
      <p className="mt-6 text-sm text-gold-soft/80">{label}</p>
    </div>
  );
}
