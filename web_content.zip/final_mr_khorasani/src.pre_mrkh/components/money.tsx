import { formatRial, moneyUnit } from "@/lib/accounting/format";
import { cn } from "@/lib/cn";
import { useBooks } from "@/lib/store/books-store";

export function Money({
  value,
  className,
  signed = false,
}: {
  value: number;
  className?: string;
  signed?: boolean;
}) {
  const books = useBooks((s) => s.books);
  const persian = books?.settings.persianDigits ?? true;
  const toman = books?.settings.displayToman ?? false;
  const n = signed ? value : value;
  const color = signed ? (n > 0 ? "text-ok" : n < 0 ? "text-danger" : "text-ink") : undefined;
  return (
    <span className={cn("tabular inline-flex items-baseline gap-1", color, className)}>
      <span>{formatRial(n, persian, toman)}</span>
      <span className="text-[0.7em] text-muted">{moneyUnit(toman)}</span>
    </span>
  );
}
