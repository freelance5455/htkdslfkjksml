import { cn } from "@/lib/cn";

export function Mark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 64" className={cn("block", className)} aria-hidden="true">
      <rect width="64" height="64" rx="14" fill="#0B1F3A" />
      <rect x="5.5" y="5.5" width="53" height="53" rx="10" fill="none" stroke="#C4A35A" strokeWidth="1.25" />
      <path d="M16 46V18h6.2l7.1 14.8L36.4 18H42v28h-5.4V28.6L30.4 42h-4.2l-6.2-13.4V46H16z" fill="#F4F0E6" />
      <path d="M46 18h4.2v11.2h.2L56 18h5.2l-7.1 13.6L62 46h-5.4l-5.1-12.2h-.2V46H46V18z" fill="#C4A35A" />
      <rect x="16" y="49.5" width="32" height="1" fill="#C4A35A" opacity="0.85" />
    </svg>
  );
}

export function Wordmark({ light = false, compact = false }: { light?: boolean; compact?: boolean }) {
  return (
    <div className="flex items-center gap-3">
      <Mark className={compact ? "size-9" : "size-11"} />
      <div className="leading-tight">
        <div className={cn("font-display tracking-tight", compact ? "text-lg" : "text-xl", light ? "text-gold-soft" : "text-navy")}>
          MR,KHORASANI
        </div>
        {!compact && (
          <div className={cn("text-[0.7rem] tracking-[0.14em] uppercase", light ? "text-gold/80" : "text-muted")}>
            Financial Management
          </div>
        )}
      </div>
    </div>
  );
}
