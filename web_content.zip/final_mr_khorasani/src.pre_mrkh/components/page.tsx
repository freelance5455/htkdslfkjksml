export function PageHeader({ title, kicker, action }: { title: string; kicker?: string; action?: React.ReactNode }) {
  return (
    <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
      <div>
        {kicker && <div className="text-xs tracking-[0.16em] text-gold uppercase">{kicker}</div>}
        <h1 className="font-display text-3xl text-navy">{title}</h1>
      </div>
      {action}
    </div>
  );
}

export function Card({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return <section className={`rounded-xl bg-card p-4 shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-ink)_8%,transparent)] ${className}`}>{children}</section>;
}

export function Stat({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <Card>
      <div className="text-xs text-muted">{label}</div>
      <div className="mt-2 text-xl font-medium text-navy">{children}</div>
    </Card>
  );
}
