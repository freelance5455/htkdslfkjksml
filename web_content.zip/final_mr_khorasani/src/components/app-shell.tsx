import { Link, Outlet, useRouterState } from "@tanstack/react-router";
import {
  Activity,
  BookOpen,
  CalendarCheck,
  CircleDollarSign,
  ClipboardList,
  Gauge,
  Landmark,
  LayoutDashboard,
  MoreHorizontal,
  Search,
  Settings,
  Shield,
  Users,
  Wallet,
} from "lucide-react";
import { useEffect, useState } from "react";
import { UserButton } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { formatJalaliLong } from "@/lib/accounting/jalali";
import { cn } from "@/lib/cn";
import { useBooks } from "@/lib/store/books-store";
import { Wordmark } from "./logo";
import { Splash } from "./splash";

const NAV = [
  { to: "/", label: "خانه", icon: LayoutDashboard, group: "اصلی" },
  { to: "/ops", label: "عملیات روزانه", icon: ClipboardList, group: "اصلی" },
  { to: "/journals", label: "اسناد", icon: BookOpen, group: "اصلی" },
  { to: "/liquidity", label: "نقدینگی", icon: Wallet, group: "خزانه" },
  { to: "/checks", label: "چک‌ها", icon: Landmark, group: "خزانه" },
  { to: "/close-day", label: "بستن روز", icon: CalendarCheck, group: "خزانه" },
  { to: "/parties", label: "اشخاص", icon: Users, group: "اشخاص" },
  { to: "/products", label: "کالاها", icon: ClipboardList, group: "اشخاص" },
  { to: "/crm", label: "CRM", icon: Users, group: "اشخاص" },
  { to: "/accounts", label: "حساب‌ها", icon: BookOpen, group: "حسابداری" },
  { to: "/reports", label: "گزارش‌ها", icon: ClipboardList, group: "حسابداری" },
  { to: "/kpi", label: "KPI", icon: Gauge, group: "حسابداری" },
  { to: "/health", label: "سلامت سیستم", icon: Activity, group: "سیستم" },
  { to: "/backup", label: "پشتیبان", icon: Shield, group: "سیستم" },
  { to: "/audit", label: "حسابرسی", icon: Shield, group: "سیستم" },
  { to: "/search", label: "جستجو", icon: Search, group: "سیستم" },
  { to: "/settings", label: "تنظیمات", icon: Settings, group: "سیستم" },
];

const MOBILE = [
  { to: "/", label: "خانه", icon: LayoutDashboard },
  { to: "/ops", label: "عملیات", icon: CircleDollarSign },
  { to: "/parties", label: "اشخاص", icon: Users },
  { to: "/reports", label: "گزارش", icon: BookOpen },
];

export function AppShell() {
  const { user, isPending } = useCurrentUserState();
  const hydrate = useBooks((s) => s.hydrate);
  const status = useBooks((s) => s.status);
  const books = useBooks((s) => s.books);
  const cloud = useBooks((s) => s.cloud);
  const path = useRouterState({ select: (s) => s.location.pathname });
  const [more, setMore] = useState(false);

  useEffect(() => {
    if (user) void hydrate(user.id, user.displayName ?? user.primaryEmail ?? "کاربر");
  }, [user?.id, user?.displayName, user?.primaryEmail, hydrate]);

  if (isPending || status === "boot" || status === "loading") return <Splash />;
  if (!books) return <Splash label="دفتر بارگذاری نشد." />;

  const groups = [...new Set(NAV.map((n) => n.group))];

  return (
    <div className="min-h-dvh bg-paper text-ink">
      <aside className="fixed inset-y-0 right-0 z-30 hidden w-64 flex-col border-l border-navy/10 bg-navy text-gold-soft lg:flex">
        <div className="p-5">
          <Wordmark light compact />
        </div>
        <nav className="flex-1 overflow-y-auto px-3 pb-6">
          {groups.map((g) => (
            <div key={g} className="mb-4">
              <div className="px-3 pb-1 text-[10px] tracking-[0.18em] text-gold/50 uppercase">{g}</div>
              {NAV.filter((n) => n.group === g).map((n) => {
                const active = n.to === "/" ? path === "/" : path.startsWith(n.to);
                const Icon = n.icon;
                return (
                  <Link
                    key={n.to}
                    to={n.to}
                    className={cn(
                      "mb-0.5 flex min-h-11 items-center gap-2 rounded-md px-3 text-sm transition-colors",
                      active ? "bg-gold/15 text-gold-soft" : "text-gold-soft/70 hover:bg-white/5 hover:text-gold-soft",
                    )}
                  >
                    <Icon className="size-4 shrink-0" />
                    {n.label}
                  </Link>
                );
              })}
            </div>
          ))}
        </nav>
        <div className="border-t border-white/10 p-4 text-xs text-gold/60">
          همگام‌سازی: {cloud === "ok" ? "ابر متصل" : cloud === "syncing" ? "در حال ارسال" : cloud === "offline" ? "آفلاین" : "آماده"}
        </div>
      </aside>

      <div className="lg:pr-64">
        <header className="sticky top-0 z-20 flex items-center justify-between gap-3 border-b border-line bg-paper/90 px-4 py-3 backdrop-blur">
          <div className="lg:hidden">
            <Wordmark compact />
          </div>
          <div className="hidden text-sm text-muted lg:block">{formatJalaliLong(new Date().toISOString().slice(0, 10))}</div>
          <div className="flex items-center gap-2">
            <Link to="/search" className="inline-flex size-11 items-center justify-center rounded-md hover:bg-paper-2" aria-label="جستجو">
              <Search className="size-4" />
            </Link>
            <UserButton />
          </div>
        </header>
        <main className="px-4 pb-28 pt-4 sm:px-6 lg:pb-10">
          <Outlet />
        </main>
      </div>

      <nav className="fixed inset-x-0 bottom-0 z-30 grid grid-cols-5 border-t border-line bg-card pb-[env(safe-area-inset-bottom)] lg:hidden">
        {MOBILE.map((n) => {
          const Icon = n.icon;
          const active = n.to === "/" ? path === "/" : path.startsWith(n.to);
          return (
            <Link key={n.to} to={n.to} className={cn("flex min-h-14 flex-col items-center justify-center gap-1 text-[11px]", active ? "text-navy" : "text-muted")}>
              <Icon className="size-5" />
              {n.label}
            </Link>
          );
        })}
        <button type="button" onClick={() => setMore(true)} className="flex min-h-14 flex-col items-center justify-center gap-1 text-[11px] text-muted">
          <MoreHorizontal className="size-5" />
          بیشتر
        </button>
      </nav>

      {more && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <button className="absolute inset-0 bg-navy/50" type="button" onClick={() => setMore(false)} aria-label="بستن" />
          <div className="absolute inset-x-0 bottom-0 rounded-t-xl bg-card p-4 pb-8">
            <div className="mx-auto mb-4 h-1 w-10 rounded-full bg-line" />
            <div className="grid grid-cols-3 gap-2">
              {NAV.map((n) => (
                <Link key={n.to} to={n.to} onClick={() => setMore(false)} className="flex min-h-16 flex-col items-center justify-center rounded-lg bg-paper px-2 text-center text-xs">
                  {n.label}
                </Link>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
