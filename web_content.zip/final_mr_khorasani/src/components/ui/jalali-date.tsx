import { useEffect, useState } from "react";
import { formatJalali, fromFaDigits, toGregorian } from "@/lib/accounting/jalali";
import { Input } from "./field";

function normalize(v: string) {
  return fromFaDigits(v).replace(/[-.]/g, "/").trim();
}

function validJalali(v: string) {
  const m = /^(\d{4})\/(\d{1,2})\/(\d{1,2})$/.exec(normalize(v));
  if (!m) return false;
  const jy = Number(m[1]); const jm = Number(m[2]); const jd = Number(m[3]);
  return jy >= 1300 && jy <= 1600 && jm >= 1 && jm <= 12 && jd >= 1 && jd <= 31;
}

export function JalaliDateInput({ value, onChange, className, disabled, ariaLabel }: {
  value: string;
  onChange: (iso: string) => void;
  className?: string;
  disabled?: boolean;
  ariaLabel?: string;
}) {
  const [text, setText] = useState(value ? formatJalali(value) : "");
  useEffect(() => {
    setText(value ? formatJalali(value) : "");
  }, [value]);

  function commit(v: string) {
    const n = normalize(v);
    if (!validJalali(n)) return;
    const [jy, jm, jd] = n.split("/").map(Number);
    try {
      onChange(toGregorian(jy, jm, jd));
      setText(formatJalali(toGregorian(jy, jm, jd)));
    } catch {
      // leave the editable text as-is until corrected
    }
  }

  return (
    <Input
      type="text"
      inputMode="numeric"
      dir="ltr"
      value={text}
      className={className}
      disabled={disabled}
      aria-label={ariaLabel}
      placeholder="۱۴۰۵/۰۶/۳۱"
      onChange={(e) => setText(e.target.value)}
      onBlur={(e) => commit(e.target.value)}
      onKeyDown={(e) => { if (e.key === "Enter") commit(text); }}
    />
  );
}
