import { useMemo, useState } from "react";
import { balanceSheet, cashFlow, dayBook, incomeStatement, tbTotals, trialBalance } from "@/lib/accounting/reports";
import { currentFy } from "@/lib/accounting/engine";
import { formatJalali, todayIso } from "@/lib/accounting/jalali";
import { downloadText, printReport, toCsv } from "@/lib/accounting/export";
import { Money } from "@/components/money";
import { Card, PageHeader } from "@/components/page";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/field";
import { JalaliDateInput } from "@/components/ui/jalali-date";
import { useBooks } from "@/lib/store/books-store";
import { useCurrentUser } from "@/lib/auth/use-current-user";

const KINDS = [
  ["tb6", "تراز آزمایشی ۶ ستونی"],
  ["tb4", "تراز آزمایشی ۴ ستونی"],
  ["tb2", "تراز آزمایشی ۲ ستونی"],
  ["pl", "سود و زیان"],
  ["bs", "ترازنامه"],
  ["cf", "جریان وجوه نقد"],
  ["dj", "دفتر روزنامه"],
] as const;

export function ReportsPage() {
  const books = useBooks((s) => s.books)!;
  const user = useCurrentUser();
  const fy = currentFy(books);
  const [kind, setKind] = useState<(typeof KINDS)[number][0]>("tb6");
  const [from, setFrom] = useState(fy?.startDate ?? "2026-03-21");
  const [to, setTo] = useState(todayIso());
  const [level, setLevel] = useState(3);

  const tb = useMemo(() => trialBalance(books, from, to, level), [books, from, to, level]);
  const tot = tbTotals(tb);
  const pl = incomeStatement(books, from, to);
  const bs = balanceSheet(books, to);
  const cf = cashFlow(books, from, to);
  const dj = dayBook(books, from, to);

  function exportCsv() {
    if (kind.startsWith("tb")) {
      downloadText(`trial-balance.csv`, toCsv(["کد","نام","بدهکار اول","بستانکار اول","گردش بد","گردش بس","مانده بد","مانده بس"], tb.map((r) => [r.code, r.name, r.openingDr, r.openingCr, r.turnoverDr, r.turnoverCr, r.remainDr, r.remainCr])));
    } else if (kind === "dj") {
      downloadText("daybook.csv", toCsv(["سند","تاریخ","شرح","کد","حساب","تفصیلی","بدهکار","بستانکار"], dj.map((r) => [r.journal, r.date, r.description, r.code, r.account, r.detail, r.debit, r.credit])));
    }
  }

  function pdf() {
    const title = KINDS.find((k) => k[0] === kind)?.[1] ?? "گزارش";
    let html = "";
    if (kind.startsWith("tb")) {
      html = `<table><thead><tr><th>کد</th><th>نام</th><th>مانده بد</th><th>مانده بس</th></tr></thead><tbody>${tb.map((r) => `<tr><td>${r.code}</td><td>${r.name}</td><td>${r.remainDr}</td><td>${r.remainCr}</td></tr>`).join("")}</tbody><tfoot><tr><td colspan="2">جمع</td><td>${tot.remainDr}</td><td>${tot.remainCr}</td></tr></tfoot></table>`;
    } else if (kind === "pl") {
      html = `<table><tbody><tr><td>فروش</td><td>${pl.sales}</td></tr><tr><td>بهای تمام‌شده</td><td>${pl.cogs}</td></tr><tr><td>سود ناخالص</td><td>${pl.gross}</td></tr><tr><td>هزینه‌ها</td><td>${pl.expense}</td></tr><tr><td>سود خالص</td><td>${pl.net}</td></tr></tbody></table>`;
    }
    printReport(title, books.company.name, fy?.name ?? "", html, user?.displayName ?? "کاربر");
  }

  return (
    <div>
      <PageHeader title="گزارش‌ها" kicker={`${formatJalali(from)} تا ${formatJalali(to)}`} action={<div className="flex gap-2"><Button variant="outline" onClick={exportCsv}>Excel/CSV</Button><Button variant="gold" onClick={pdf}>PDF</Button></div>} />
      <div className="mb-4 grid gap-2 sm:grid-cols-4">
        <Field label="نوع"><Select value={kind} onChange={(e) => setKind(e.target.value as typeof kind)}>{KINDS.map((k) => <option key={k[0]} value={k[0]}>{k[1]}</option>)}</Select></Field>
        <Field label="از تاریخ"><JalaliDateInput value={from} onChange={setFrom} /></Field>
        <Field label="تا تاریخ"><JalaliDateInput value={to} onChange={setTo} /></Field>
        <Field label="سطح"><Select value={String(level)} onChange={(e) => setLevel(Number(e.target.value))}><option value="2">کل</option><option value="3">معین</option><option value="4">تفصیلی</option></Select></Field>
      </div>

      {kind.startsWith("tb") && (
        <Card className="overflow-x-auto p-0">
          <table className="w-full min-w-[800px] text-sm">
            <thead className="bg-navy text-gold-soft">
              <tr>
                <th className="px-3 py-2 text-right">کد</th>
                <th className="px-3 py-2 text-right">نام</th>
                {kind === "tb6" && <><th className="px-3 py-2">اول دوره بد</th><th className="px-3 py-2">اول دوره بس</th></>}
                {(kind === "tb6" || kind === "tb4") && <><th className="px-3 py-2">گردش بد</th><th className="px-3 py-2">گردش بس</th></>}
                <th className="px-3 py-2">مانده بد</th>
                <th className="px-3 py-2">مانده بس</th>
              </tr>
            </thead>
            <tbody>
              {tb.map((r) => (
                <tr key={r.id} className="border-t border-line">
                  <td className="px-3 py-1.5">{r.code}</td>
                  <td className="px-3 py-1.5">{r.name}</td>
                  {kind === "tb6" && <><td className="px-3 py-1.5"><Money value={r.openingDr} /></td><td className="px-3 py-1.5"><Money value={r.openingCr} /></td></>}
                  {(kind === "tb6" || kind === "tb4") && <><td className="px-3 py-1.5"><Money value={r.turnoverDr} /></td><td className="px-3 py-1.5"><Money value={r.turnoverCr} /></td></>}
                  <td className="px-3 py-1.5"><Money value={r.remainDr} /></td>
                  <td className="px-3 py-1.5"><Money value={r.remainCr} /></td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="border-t-2 border-navy bg-paper-2 font-medium">
                <td className="px-3 py-2" colSpan={2}>جمع · اختلاف {tot.remainDr - tot.remainCr}</td>
                {kind === "tb6" && <><td className="px-3 py-2"><Money value={tot.openingDr} /></td><td className="px-3 py-2"><Money value={tot.openingCr} /></td></>}
                {(kind === "tb6" || kind === "tb4") && <><td className="px-3 py-2"><Money value={tot.turnoverDr} /></td><td className="px-3 py-2"><Money value={tot.turnoverCr} /></td></>}
                <td className="px-3 py-2"><Money value={tot.remainDr} /></td>
                <td className="px-3 py-2"><Money value={tot.remainCr} /></td>
              </tr>
            </tfoot>
          </table>
        </Card>
      )}

      {kind === "pl" && (
        <Card>
          <Line k="فروش / درآمد" v={pl.sales} />
          <Line k="بهای تمام‌شده" v={pl.cogs} />
          <Line k="سود ناخالص" v={pl.gross} strong />
          <Line k="هزینه‌ها" v={pl.expense} />
          <Line k="سود عملیاتی / خالص" v={pl.net} strong />
        </Card>
      )}
      {kind === "bs" && (
        <Card>
          <Line k="دارایی‌ها" v={bs.assets} />
          <Line k="بدهی‌ها" v={bs.liabilities} />
          <Line k="سرمایه + سود دوره" v={bs.equity} />
          <p className="mt-3 text-sm text-muted">دارایی باید برابر بدهی + سرمایه باشد. اختلاف: {bs.assets - (bs.liabilities + bs.equity)}</p>
        </Card>
      )}
      {kind === "cf" && (
        <Card>
          <Line k="ورود وجه" v={cf.inflows} />
          <Line k="خروج وجه" v={cf.outflows} />
          <Line k="خالص جریان نقدی" v={cf.net} strong />
        </Card>
      )}
      {kind === "dj" && (
        <Card className="overflow-x-auto p-0">
          <table className="w-full min-w-[900px] text-sm">
            <thead className="bg-navy text-gold-soft"><tr>{["سند","تاریخ","شرح","کد","حساب","تفصیلی","بدهکار","بستانکار"].map((h) => <th key={h} className="px-2 py-2 text-right">{h}</th>)}</tr></thead>
            <tbody>{dj.map((r, i) => <tr key={i} className="border-t border-line"><td className="px-2 py-1">{r.journal}</td><td className="px-2 py-1">{formatJalali(r.date)}</td><td className="px-2 py-1">{r.description}</td><td className="px-2 py-1">{r.code}</td><td className="px-2 py-1">{r.account}</td><td className="px-2 py-1">{r.detail}</td><td className="px-2 py-1"><Money value={r.debit} /></td><td className="px-2 py-1"><Money value={r.credit} /></td></tr>)}</tbody>
          </table>
        </Card>
      )}
    </div>
  );
}

function Line({ k, v, strong }: { k: string; v: number; strong?: boolean }) {
  return (
    <div className={`flex items-center justify-between border-b border-line py-2 ${strong ? "font-medium" : ""}`}>
      <span>{k}</span>
      <Money value={v} />
    </div>
  );
}
