import { useMemo, useState } from "react";
import { toast } from "sonner";
import { OP_LABEL } from "@/lib/accounting/format";
import { todayIso } from "@/lib/accounting/jalali";
import { useBooks } from "@/lib/store/books-store";
import type { InvoiceLine, OpKind, PayMethod } from "@/lib/accounting/types";
import { Button } from "@/components/ui/button";
import { Card, PageHeader } from "@/components/page";
import { Field, Input, Select, Textarea } from "@/components/ui/field";
import { JalaliDateInput } from "@/components/ui/jalali-date";
import { Money } from "@/components/money";

const GROUPS: { title: string; items: OpKind[] }[] = [
  { title: "نقد و خزانه", items: ["receipt", "payment", "transfer", "petty_fund", "petty_settle"] },
  { title: "خرید و فروش", items: ["sale", "sale_return", "purchase", "purchase_return"] },
  { title: "هزینه و درآمد", items: ["expense", "income", "payroll", "depreciation"] },
  { title: "چک", items: ["check_receive", "check_issue", "check_clear", "check_bounce"] },
  { title: "سرمایه و تعدیل", items: ["capital", "draw", "prepaid", "unearned", "manual", "adjustment"] },
];

export function OpsPage() {
  const books = useBooks((s) => s.books)!;
  const post = useBooks((s) => s.post);
  const [kind, setKind] = useState<OpKind | null>(null);
  const [q, setQ] = useState("");
  const recent = books.operations.slice(0, 30);
  return (
    <div>
      <PageHeader title="عملیات روزانه" kicker="ثبت رویداد مالی با تولید خودکار سند دوبل" />
      {kind ? <OperationForm kind={kind} onCancel={() => setKind(null)} onSave={(input) => { const r = post(input); if (r.error) { toast.error(r.error); return; } toast.success(`ثبت شد · ${r.number} · سند ${r.journal}`); setKind(null); }} /> : (
        <div className="space-y-5">
          <div className="flex gap-2"><Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="جستجوی عملیات، سند یا شرح" /></div>
          {GROUPS.map((g) => <div key={g.title}><h2 className="mb-2 text-xs text-muted">{g.title}</h2><div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-4">{g.items.map((k) => <button key={k} type="button" onClick={() => setKind(k)} className="rounded-lg border border-line bg-card px-3 py-4 text-right text-sm font-medium shadow-sm transition hover:border-gold">{OP_LABEL[k]}</button>)}</div></div>)}
          <Card className="overflow-x-auto p-0"><table className="w-full min-w-[900px] text-sm"><thead className="bg-navy text-gold-soft"><tr>{["عملیات","تاریخ","شماره","مبلغ","وضعیت","شرح"].map((h) => <th key={h} className="px-3 py-2 text-right">{h}</th>)}</tr></thead><tbody>{recent.filter((o) => !q || `${o.number}${o.description}${o.journalId}`.includes(q)).map((o) => <tr key={o.id} className="border-t border-line"><td className="px-3 py-2">{OP_LABEL[o.kind]}</td><td className="px-3 py-2">{o.date}</td><td className="px-3 py-2">{o.number}</td><td className="px-3 py-2"><Money value={o.amount} /></td><td className="px-3 py-2">{o.status}</td><td className="px-3 py-2">{o.description}</td></tr>)}</tbody></table></Card>
        </div>
      )}
    </div>
  );
}

function OperationForm({ kind, onCancel, onSave }: { kind: OpKind; onCancel: () => void; onSave: (input: any) => void }) {
  const books = useBooks((s) => s.books)!;
  const today = todayIso();
  const [date, setDate] = useState(today);
  const [partyId, setPartyId] = useState("");
  const [moneyAccountId, setMoneyAccountId] = useState(books.moneyAccounts[0]?.id ?? "");
  const [destMoneyAccountId, setDestMoneyAccountId] = useState(books.moneyAccounts[1]?.id ?? books.moneyAccounts[0]?.id ?? "");
  const [accountId, setAccountId] = useState("");
  const [method, setMethod] = useState<PayMethod>(kind === "sale" || kind === "purchase" ? "cash" : kind.includes("check") || kind === "manual" || kind === "transfer" ? "none" : "cash");
  const [amount, setAmount] = useState("");
  const [paidAmount, setPaidAmount] = useState("");
  const [discountMode, setDiscountMode] = useState<"percent" | "amount">("amount");
  const [discountValue, setDiscountValue] = useState("");
  const [shipping, setShipping] = useState("");
  const [description, setDescription] = useState("");
  const [checkNumber, setCheckNumber] = useState("");
  const [checkBank, setCheckBank] = useState("");
  const [checkDue, setCheckDue] = useState(today);
  const [checkId, setCheckId] = useState("");
  const [lines, setLines] = useState<InvoiceLine[]>([{ productId: books.products[0]?.id, description: books.products[0]?.name ?? "", qty: 1, unitPrice: books.products[0]?.salePrice ?? 0, discount: 0 }]);

  const isInvoice = ["sale", "purchase", "sale_return", "purchase_return"].includes(kind);
  const parties = useMemo(() => {
    const role = ["sale", "sale_return"].includes(kind) ? "customer" : ["purchase", "purchase_return"].includes(kind) ? "supplier" : kind === "payroll" ? "employee" : null;
    return books.parties.filter((p) => p.active && (!role || p.kind === role || p.roles?.includes(role as any) || p.roles?.includes("both_customer_supplier")));
  }, [books.parties, kind]);
  const banks = books.moneyAccounts.filter((m) => m.active);
  const postable = books.accounts.filter((a) => a.isPostable && a.active);
  const subtotal = lines.reduce((s, l) => s + Math.round(l.qty * l.unitPrice), 0);
  const discountAmount = discountMode === "percent" ? Math.round(subtotal * (Number(discountValue) || 0) / 100) : Math.round(Number(discountValue) || 0);
  const finalTotal = subtotal - discountAmount + (Number(shipping) || 0);

  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (isInvoice && (!partyId || lines.some((l) => !l.productId || l.qty <= 0 || l.unitPrice <= 0))) { toast.error("شخص و تمام اقلام فاکتور باید معتبر باشند."); return; }
    if (isInvoice && discountAmount > subtotal) { toast.error("تخفیف بیشتر از مبلغ ناخالص است."); return; }
    const numeric = Number(String(amount).replace(/[^0-9]/g, ""));
    onSave({
      kind, method, date, partyId: partyId || undefined, moneyAccountId: moneyAccountId || undefined, destMoneyAccountId: destMoneyAccountId || undefined, accountId: accountId || undefined,
      amount: isInvoice ? 0 : numeric, paidAmount: Number(paidAmount) || undefined, discount: discountAmount, discountMode, discountPercent: discountMode === "percent" ? Number(discountValue) || 0 : subtotal > 0 ? Number(((discountAmount / subtotal) * 100).toFixed(4)) : 0, shipping: Number(shipping) || 0, description,
      checkNumber: checkNumber || undefined, checkBank: checkBank || undefined, checkDue, checkId: checkId || undefined, invoiceLines: isInvoice ? lines : undefined,
      lines: kind === "manual" || kind === "adjustment" ? [] : undefined,
    });
  }

  return <Card><div className="mb-4 flex items-center justify-between"><h2 className="font-medium text-navy">{OP_LABEL[kind]}</h2><Button variant="ghost" type="button" onClick={onCancel}>بازگشت</Button></div>
    <form className="grid gap-3 sm:grid-cols-2" onSubmit={submit}>
      <Field label="تاریخ شمسی"><JalaliDateInput value={date} onChange={setDate} /></Field>
      {(isInvoice || ["receipt", "payment", "check_receive", "check_issue", "prepaid", "unearned", "payroll"].includes(kind)) && <Field label="شخص"><Select value={partyId} onChange={(e) => setPartyId(e.target.value)}><option value="">— انتخاب —</option>{parties.map((p) => <option key={p.id} value={p.id}>{p.code} — {p.name}</option>)}</Select></Field>}
      {isInvoice && <Field label="نحوه تسویه"><Select value={method} onChange={(e) => setMethod(e.target.value as PayMethod)}><option value="cash">نقدی</option><option value="bank">بانکی</option><option value="credit">نسیه</option><option value="mixed">ترکیبی</option></Select></Field>}
      {!["manual", "adjustment", "depreciation", "check_receive", "check_issue", "check_bounce"].includes(kind) && method !== "credit" && <Field label="منبع مالی"><Select value={moneyAccountId} onChange={(e) => setMoneyAccountId(e.target.value)}>{banks.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}</Select></Field>}
      {["transfer", "petty_fund"].includes(kind) && <Field label="مقصد مالی"><Select value={destMoneyAccountId} onChange={(e) => setDestMoneyAccountId(e.target.value)}>{banks.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}</Select></Field>}
      {["expense", "income", "payment", "petty_settle", "purchase"].includes(kind) && <Field label="حساب"><Select value={accountId} onChange={(e) => setAccountId(e.target.value)}><option value="">پیش‌فرض</option>{postable.map((a) => <option key={a.id} value={a.id}>{a.code} — {a.name}</option>)}</Select></Field>}
      {isInvoice && <div className="sm:col-span-2"><div className="mb-2 flex items-center justify-between"><span className="text-sm font-medium">اقلام فاکتور</span><Button type="button" variant="outline" onClick={() => setLines((x) => [...x, { productId: books.products[0]?.id, description: books.products[0]?.name ?? "", qty: 1, unitPrice: books.products[0]?.salePrice ?? 0, discount: 0 }])}>+ ردیف</Button></div>{lines.map((l, i) => <div key={i} className="mb-2 grid gap-2 sm:grid-cols-6"><Select value={l.productId ?? ""} onChange={(e) => { const p = books.products.find((x) => x.id === e.target.value); setLines(xs => xs.map((row, n) => n === i ? { ...row, productId: e.target.value, description: p?.name ?? "", unitPrice: p?.salePrice ?? 0 } : row)); }}><option value="">کالا</option>{books.products.filter(p => p.active).map(p => <option key={p.id} value={p.id}>{p.sku} — {p.name}</option>)}</Select><Input inputMode="numeric" value={l.qty} onChange={(e) => setLines(xs => xs.map((row,n) => n===i?{...row,qty:Number(e.target.value)||0}:row))} /><Input inputMode="numeric" value={l.unitPrice} onChange={(e) => setLines(xs => xs.map((row,n) => n===i?{...row,unitPrice:Number(e.target.value)||0}:row))} /><div className="rounded-md bg-paper px-3 py-2 text-sm"><Money value={l.qty*l.unitPrice} /></div><div className="rounded-md bg-paper px-3 py-2 text-sm"><Money value={l.qty*l.unitPrice-l.discount} /></div><Button type="button" variant="ghost" onClick={() => setLines(xs => xs.length > 1 ? xs.filter((_,n)=>n!==i) : xs)}>حذف</Button></div>)}</div>}
      {isInvoice ? <><Field label="نوع تخفیف"><Select value={discountMode} onChange={(e) => setDiscountMode(e.target.value as any)}><option value="amount">مبلغ تخفیف</option><option value="percent">درصد تخفیف</option></Select></Field><Field label={discountMode === "percent" ? "درصد تخفیف" : "مبلغ تخفیف"}><Input inputMode="decimal" value={discountValue} onChange={(e) => setDiscountValue(e.target.value)} placeholder={discountMode === "percent" ? "مثلاً ۵" : "مثلاً ۵۰۰۰۰۰۰"} /></Field><Field label="هزینه حمل"><Input inputMode="numeric" value={shipping} onChange={(e)=>setShipping(e.target.value)} /></Field><div className="rounded-md bg-paper p-3 text-sm"><div className="flex justify-between"><span>ناخالص</span><Money value={subtotal} /></div><div className="flex justify-between"><span>تخفیف</span><Money value={discountAmount} /></div><div className="flex justify-between"><span>نهایی</span><Money value={finalTotal} /></div></div></> : <Field label="مبلغ"><Input inputMode="numeric" value={amount} onChange={(e)=>setAmount(e.target.value)} /></Field>}
      {method === "mixed" && <Field label="مبلغ تسویه اولیه"><Input inputMode="numeric" value={paidAmount} onChange={(e)=>setPaidAmount(e.target.value)} /></Field>}
      {["check_receive", "check_issue"].includes(kind) && <><Field label="شماره چک"><Input value={checkNumber} onChange={e=>setCheckNumber(e.target.value)} /></Field><Field label="بانک چک"><Input value={checkBank} onChange={e=>setCheckBank(e.target.value)} /></Field><Field label="سررسید شمسی"><JalaliDateInput value={checkDue} onChange={setCheckDue} /></Field></>}
      {["check_clear", "check_bounce"].includes(kind) && <Field label="چک"><Select value={checkId} onChange={e=>setCheckId(e.target.value)}><option value="">— انتخاب —</option>{books.checks.filter(c=>c.status==="pending").map(c=><option key={c.id} value={c.id}>{c.number} — {c.amount.toLocaleString("fa-IR")}</option>)}</Select></Field>}
      <div className="sm:col-span-2"><Field label="شرح"><Textarea value={description} onChange={(e)=>setDescription(e.target.value)} /></Field></div>
      <div className="sm:col-span-2"><Button className="w-full" type="submit">ثبت عملیات و تولید سند</Button></div>
    </form>
  </Card>;
}
