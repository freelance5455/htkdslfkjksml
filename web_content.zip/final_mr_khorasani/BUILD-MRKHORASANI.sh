#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

echo "1) Install dependencies: npm ci"
echo "2) Build web: npm run build"
echo "3) Sync the production web bundle into android/app/src/main/assets/www"
echo "4) Android: cd android_src/Newfoam-Android-APK-Ready/android && ./gradlew :app:assembleDebug"
echo "5) Release: ./gradlew :app:bundleRelease with a real release keystore"
