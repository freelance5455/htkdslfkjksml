FF PRO TRAINING — TRIK FLUTUANTE (Android)

O projeto inclui o site de sensibilidade e um serviço Android que desenha o botão TRIK sobre outros apps.

Para compilar: abra a pasta FFPRO-Android no Android Studio e gere o APK (Build > Build APK(s)).
Não há APK compilado neste ZIP.

Como usar:
1. Instale o APK compilado.
2. Abra FF PRO Training e toque ATIVAR TRIK FLUTUANTE.
3. Nas configurações Android, permita 'Exibir sobre outros aplicativos'.
4. Volte ao aplicativo e toque ATIVAR novamente.
5. Abra Free Fire. Arraste TRIK para a posição desejada.
6. Ajuste tamanho/transparência no app. Desative pelo app ou pela notificação.

O TRIK é um marcador visual. Não simula toques, não controla a mira, não altera o Free Fire e não garante capas.
A disponibilidade da sobreposição depende das restrições do Android e do jogo.
