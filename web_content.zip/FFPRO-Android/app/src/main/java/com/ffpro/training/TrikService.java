package com.ffpro.training;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.view.*;
import android.widget.TextView;

public class TrikService extends Service {
  public static boolean running = false;
  private WindowManager wm;
  private TextView bubble;
  private WindowManager.LayoutParams params;
  private float startX, startY;
  private int originX, originY;
  private int dp(int v) { return (int)(v*getResources().getDisplayMetrics().density + .5f); }
  @Override public void onCreate() {
    super.onCreate(); running = true;
    NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
    nm.createNotificationChannel(new NotificationChannel("trik", "TRIK flutuante", NotificationManager.IMPORTANCE_LOW));
    Intent stop = new Intent(this, TrikService.class); stop.setAction("STOP");
    PendingIntent stopPi = PendingIntent.getService(this, 0, stop, PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
    PendingIntent openPi = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
    Notification notification = new Notification.Builder(this, "trik")
      .setSmallIcon(android.R.drawable.ic_menu_compass).setContentTitle("TRIK flutuante ativo")
      .setContentText("Toque para ajustar; desative pelo botão abaixo")
      .setContentIntent(openPi).addAction(new Notification.Action.Builder(null, "Desativar", stopPi).build()).build();
    startForeground(10, notification);
    if (android.provider.Settings.canDrawOverlays(this)) showBubble(); else stopSelf();
  }
  private void showBubble() {
    wm = (WindowManager)getSystemService(WINDOW_SERVICE);
    bubble = new TextView(this);
    bubble.setText("TRIK"); bubble.setGravity(Gravity.CENTER); bubble.setTextSize(12);
    bubble.setTextColor(Color.WHITE); bubble.setTypeface(null, 1);
    GradientDrawable bg = new GradientDrawable(); bg.setColor(0xfff05b29);
    bg.setCornerRadius(dp(100)); bg.setStroke(dp(2), 0xffffc179);
    bubble.setBackground(bg);
    int size = dp(getPreferences(0).getInt("size", 64));
    params = new WindowManager.LayoutParams(size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
      WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
      PixelFormat.TRANSLUCENT);
    params.gravity = Gravity.TOP | Gravity.LEFT;
    params.x = getResources().getDisplayMetrics().widthPixels - size - dp(16);
    params.y = getResources().getDisplayMetrics().heightPixels / 2;
    bubble.setOnTouchListener((v, event) -> {
      switch(event.getActionMasked()) {
        case MotionEvent.ACTION_DOWN:
          startX=event.getRawX(); startY=event.getRawY(); originX=params.x; originY=params.y; return true;
        case MotionEvent.ACTION_MOVE:
          params.x = originX + (int)(event.getRawX()-startX);
          params.y = originY + (int)(event.getRawY()-startY);
          wm.updateViewLayout(bubble, params); return true;
        case MotionEvent.ACTION_UP: return true;
      }
      return false;
    });
    wm.addView(bubble, params); refresh();
  }
  private void refresh() {
    if (bubble == null || params == null) return;
    int size = dp(getPreferences(0).getInt("size", 64));
    params.width=size; params.height=size;
    bubble.setAlpha(getPreferences(0).getInt("opacity", 85)/100f);
    wm.updateViewLayout(bubble, params);
  }
  @Override public int onStartCommand(Intent intent, int flags, int id) {
    if (intent != null && "STOP".equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
    if (intent != null && "REFRESH".equals(intent.getAction())) refresh();
    return START_STICKY;
  }
  @Override public void onDestroy() {
    running=false;
    if (wm != null && bubble != null) { try { wm.removeView(bubble); } catch(Exception ignored) {} }
    super.onDestroy();
  }
  @Override public IBinder onBind(Intent intent) { return null; }
}
