package com.ffpro.training;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.WebView;
import android.widget.*;
import android.view.*;

public class MainActivity extends Activity {
  private void startTrik() {
    if (!Settings.canDrawOverlays(this)) {
      Toast.makeText(this, "Permita 'Exibir sobre outros aplicativos' e volte para ativar", Toast.LENGTH_LONG).show();
      startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
      return;
    }
    try { startForegroundService(new Intent(this, TrikService.class)); }
    catch (Exception e) { Toast.makeText(this, "Não foi possível ativar: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
  }
  @Override public void onCreate(Bundle saved) {
    super.onCreate(saved);
    LinearLayout root = new LinearLayout(this);
    root.setOrientation(LinearLayout.VERTICAL);
    root.setPadding(16, 16, 16, 8);
    root.setBackgroundColor(0xff10131d);
    setContentView(root);
    Button start = new Button(this); start.setText("ATIVAR TRIK FLUTUANTE"); root.addView(start);
    Button stop = new Button(this); stop.setText("DESATIVAR TRIK"); root.addView(stop);
    TextView label = new TextView(this); label.setTextColor(-1);
    label.setText("Tamanho do TRIK (40–110 dp)"); root.addView(label);
    SeekBar size = new SeekBar(this); size.setMax(70); size.setProgress(getPreferences(0).getInt("size", 64)-40); root.addView(size);
    TextView opacityLabel = new TextView(this); opacityLabel.setTextColor(-1);
    opacityLabel.setText("Transparência (30%–100%)"); root.addView(opacityLabel);
    SeekBar opacity = new SeekBar(this); opacity.setMax(70); opacity.setProgress(getPreferences(0).getInt("opacity", 85)-30); root.addView(opacity);
    TextView note = new TextView(this); note.setTextColor(-1);
    note.setText("TRIK é um marcador visual arrastável sobre outros apps. Não dispara, não altera a mira e não automatiza o jogo."); root.addView(note);
    WebView web = new WebView(this); root.addView(web, new LinearLayout.LayoutParams(-1, 0, 1));
    web.getSettings().setJavaScriptEnabled(true);
    web.getSettings().setDomStorageEnabled(true);
    web.loadUrl("file:///android_asset/index.html");
    start.setOnClickListener(v -> startTrik());
    stop.setOnClickListener(v -> stopService(new Intent(this, TrikService.class)));
    size.setOnSeekBarChangeListener(listener("size", 40));
    opacity.setOnSeekBarChangeListener(listener("opacity", 30));
  }
  private SeekBar.OnSeekBarChangeListener listener(String key, int min) {
    return new SeekBar.OnSeekBarChangeListener() {
      public void onProgressChanged(SeekBar bar, int value, boolean fromUser) {
        if (fromUser) {
          getPreferences(0).edit().putInt(key, min+value).apply();
          Intent refresh = new Intent(MainActivity.this, TrikService.class);
          refresh.setAction("REFRESH");
          // Update the existing service only; don't start it from a slider.
          if (TrikService.running) startService(refresh);
        }
      }
      public void onStartTrackingTouch(SeekBar bar) {}
      public void onStopTrackingTouch(SeekBar bar) {}
    };
  }
}
