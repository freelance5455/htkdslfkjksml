package com.term4h.app

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import org.json.JSONObject
import java.io.File
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private var llm: LlmInference? = null
    private val modelFile get() = File(filesDir, "model.task")

    // Modelldatei (.task) aus den Dateien waehlen und in den App-Speicher kopieren
    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@registerForActivityResult
        js("window.onAiStatus('Copying model, please wait...')")
        thread {
            try {
                contentResolver.openInputStream(uri)!!.use { i ->
                    modelFile.outputStream().use { o -> i.copyTo(o, 1 shl 20) }
                }
                llm?.close(); llm = null
                js("window.onAiStatus('Model ready. You can chat now.')")
            } catch (e: Exception) {
                js("window.onAiStatus(${JSONObject.quote("Error: ${e.message}")})")
            }
        }
    }

    inner class Bridge {
        @JavascriptInterface fun hasModel() = modelFile.exists() && modelFile.length() > 0
        @JavascriptInterface fun pickModel() { runOnUiThread { picker.launch(arrayOf("*/*")) } }
        @JavascriptInterface fun generate(prompt: String) {
            thread {
                try {
                    val m = llm ?: LlmInference.createFromOptions(
                        this@MainActivity,
                        LlmInference.LlmInferenceOptions.builder()
                            .setModelPath(modelFile.absolutePath)
                            .setMaxTokens(2048)
                            .build()
                    ).also { llm = it }
                    m.generateResponseAsync(prompt) { part, done ->
                        js("window.onAiToken(${JSONObject.quote(part ?: "")})")
                        if (done) js("window.onAiDone()")
                    }
                } catch (e: Throwable) {
                    js("window.onAiError(${JSONObject.quote(e.message ?: "Unknown error")})")
                }
            }
        }
    }

    private fun js(code: String) = runOnUiThread { web.evaluateJavascript(code, null) }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }
}
