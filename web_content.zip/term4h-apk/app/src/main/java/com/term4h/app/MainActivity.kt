package com.term4h.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.app.DownloadManager
import android.content.ContentValues
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import androidx.activity.result.contract.ActivityResultContracts
import android.widget.Toast
import java.io.File
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private var filePathCb: ValueCallback<Array<Uri>>? = null
    private val chooser = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        filePathCb?.onReceiveValue(if (uri != null) arrayOf(uri) else null); filePathCb = null
    }

    private fun canNotify() = Build.VERSION.SDK_INT < 33 ||
        ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    // Called from the web page: real Android notification while the model downloads in the background.
    inner class Bridge {
        private var started = false
        @JavascriptInterface fun notify(pct: Int, text: String) {
            if (!started) {
                started = true
                ContextCompat.startForegroundService(
                    this@MainActivity,
                    Intent(this@MainActivity, DownloadService::class.java).putExtra("text", text).putExtra("pct", pct)
                )
            } else if (canNotify()) {
                getSystemService(NotificationManager::class.java)
                    .notify(1, DownloadService.build(this@MainActivity, text, pct, false))
            }
        }
        private fun toast(msg: String) = runOnUiThread { Toast.makeText(this@MainActivity, msg, Toast.LENGTH_LONG).show() }

        // Save any file (zip, exe, apk, txt...) into Downloads - every call creates a new file, so unlimited saves
        @JavascriptInterface fun saveFile(name: String, mime: String, b64: String) {
            try {
                val bytes = Base64.decode(b64, Base64.DEFAULT)
                val safe = name.replace(Regex("[\\\\/:*?\"<>|]"), "_")
                if (Build.VERSION.SDK_INT >= 29) {
                    val cv = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, safe)
                        put(MediaStore.Downloads.MIME_TYPE, mime)
                        put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                    }
                    val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)!!
                    contentResolver.openOutputStream(uri)!!.use { it.write(bytes) }
                } else {
                    val dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)!!
                    var f = File(dir, safe); if (f.exists()) f = File(dir, "${System.currentTimeMillis()}_$safe")
                    f.writeBytes(bytes)
                }
                toast("Saved to Downloads: $safe")
            } catch (e: Exception) { toast("Save failed: ${e.message}") }
        }

        // Download any link with the Android download manager (notification, works for every site)
        @JavascriptInterface fun downloadUrl(url: String, name: String) {
            try {
                val req = DownloadManager.Request(Uri.parse(url)).setTitle(name)
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                if (Build.VERSION.SDK_INT >= 29) req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
                else req.setDestinationInExternalFilesDir(this@MainActivity, Environment.DIRECTORY_DOWNLOADS, name)
                getSystemService(DownloadManager::class.java).enqueue(req)
                toast("Download started: $name")
            } catch (e: Exception) { toast("Download failed: ${e.message}") }
        }

        @JavascriptInterface fun stopNotify(text: String) {
            stopService(Intent(this@MainActivity, DownloadService::class.java))
            started = false
            if (canNotify()) getSystemService(NotificationManager::class.java)
                .notify(2, DownloadService.build(this@MainActivity, text, 100, true))
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33)
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        // https://appassets.androidplatform.net gives the page a secure origin (needed for storage + workers)
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val r = loader.shouldInterceptRequest(request.url) ?: return null
                return if (request.url.path?.endsWith(".wasm") == true)
                    WebResourceResponse("application/wasm", null, r.data) else r
            }
        }
        // lets the page open the Android file picker (model file)
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(v: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                filePathCb?.onReceiveValue(null); filePathCb = cb; chooser.launch(arrayOf("*/*")); return true
            }
        }
        web.addJavascriptInterface(Bridge(), "Android")
        setContentView(web)
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }
}
