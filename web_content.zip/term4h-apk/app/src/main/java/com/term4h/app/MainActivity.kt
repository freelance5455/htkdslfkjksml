package com.term4h.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView

    private fun canNotify() = Build.VERSION.SDK_INT < 33 ||
        ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    // Called from the web page: real Android notification while the model downloads in the background.
    inner class Bridge {
        private var started = false
        @JavascriptInterface fun notify(pct: Int, text: String) {
            if (!started) {
                started = true
                ContextCompat.startForegroundService(
                    this@MainActivity,
                    Intent(this@MainActivity, DownloadService::class.java).putExtra("text", text).putExtra("pct", pct)
                )
            } else if (canNotify()) {
                getSystemService(NotificationManager::class.java)
                    .notify(1, DownloadService.build(this@MainActivity, text, pct, false))
            }
        }
        @JavascriptInterface fun stopNotify(text: String) {
            stopService(Intent(this@MainActivity, DownloadService::class.java))
            started = false
            if (canNotify()) getSystemService(NotificationManager::class.java)
                .notify(2, DownloadService.build(this@MainActivity, text, 100, true))
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33)
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        // https://appassets.androidplatform.net gives the page a secure origin (needed for storage + workers)
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val r = loader.shouldInterceptRequest(request.url) ?: return null
                return if (request.url.path?.endsWith(".wasm") == true)
                    WebResourceResponse("application/wasm", null, r.data) else r
            }
        }
        web.addJavascriptInterface(Bridge(), "Android")
        setContentView(web)
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }
}
