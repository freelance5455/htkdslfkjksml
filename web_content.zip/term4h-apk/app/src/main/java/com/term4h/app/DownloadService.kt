package com.term4h.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

// Foreground service: keeps the app process alive while the AI model downloads in the background.
class DownloadService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n = build(this, intent?.getStringExtra("text") ?: "Downloading AI model...", intent?.getIntExtra("pct", -1) ?: -1, false)
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else startForeground(1, n)
        return START_NOT_STICKY
    }

    companion object {
        private const val CH = "term4h_download"
        fun build(ctx: Context, text: String, pct: Int, done: Boolean): Notification {
            if (Build.VERSION.SDK_INT >= 26)
                ctx.getSystemService(NotificationManager::class.java)
                    .createNotificationChannel(NotificationChannel(CH, "Model download", NotificationManager.IMPORTANCE_LOW))
            val open = PendingIntent.getActivity(
                ctx, 0, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE)
            val b = NotificationCompat.Builder(ctx, CH)
                .setContentTitle("term4h")
                .setContentText(text)
                .setContentIntent(open)
                .setOnlyAlertOnce(true)
            if (done) b.setSmallIcon(android.R.drawable.stat_sys_download_done).setAutoCancel(true)
            else b.setSmallIcon(android.R.drawable.stat_sys_download).setOngoing(true).setProgress(100, pct.coerceAtLeast(0), pct < 0)
            return b.build()
        }
    }
}
