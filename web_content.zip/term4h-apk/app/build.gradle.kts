plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.term4h.app"
    compileSdk = 34
    defaultConfig { applicationId = "com.term4h.app"; minSdk = 26; targetSdk = 34; versionCode = 1; versionName = "1.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    androidResources { noCompress += "gguf" }
}
dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.webkit:webkit:1.11.0")
}
