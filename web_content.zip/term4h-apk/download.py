# Laedt wllama + KI-Modell einmalig in den Projektordner (braucht Internet, Python 3).
# Danach: im Ordner app/src/main/assets  ->  python3 -m http.server 8000  ->  http://localhost:8000
import io, os, tarfile, urllib.request
A = os.path.join(os.path.dirname(os.path.abspath(__file__)), "app", "src", "main", "assets")
def get(url): 
    print("Lade", url); return urllib.request.urlopen(url).read()
if not os.path.exists(os.path.join(A, "wllama", "esm", "index.js")):
  tgz = get("https://registry.npmjs.org/@wllama/wllama/-/wllama-3.8.1.tgz")
  with tarfile.open(fileobj=io.BytesIO(tgz)) as t:
    for m in t.getmembers():
        if m.name.startswith("package/esm/") and m.isfile():
            p = os.path.join(A, "wllama", m.name[len("package/"):])
            os.makedirs(os.path.dirname(p), exist_ok=True)
            open(p, "wb").write(t.extractfile(m).read())
os.makedirs(os.path.join(A, "models"), exist_ok=True)
urllib.request.urlretrieve(
  "https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/qwen2.5-0.5b-instruct-q4_k_m.gguf",
  os.path.join(A, "models", "model.gguf"))
print("Fertig.")
