# term4h Offline-KI (APK)

Alles laeuft in einer WebView: Webseite (index.html) + KI-Engine wllama (liegt in assets/wllama) + Modell Qwen2.5 0.5B.

1. Android Studio -> Ordner `term4h-apk` oeffnen -> Gradle Sync.
2. Build > Build APK(s).
3. App starten, mit Google anmelden. Das Modell (ca. 500 MB) wird einmal schnell (6 Verbindungen) geladen,
   mit Benachrichtigung im Hintergrund, bei Abbruch/ohne Internet gespeichert und automatisch fortgesetzt.
4. Danach laeuft die KI ohne Internet.

Google-Login: eigene OAuth-Client-ID in index.html bei GOOGLE_CLIENT_ID eintragen.
Hinweis: Google blockiert Anmeldung in eingebetteten WebViews - in der APK braucht es dafuer eine native Anmeldung.

Optional (PC): `python3 download.py` legt das Modell als assets/models/model.gguf ab (nur fuer den lokalen Server-Test).
