# term4h Offline-KI (APK)

1. Android Studio oeffnen -> Ordner `term4h-apk` oeffnen -> Gradle Sync abwarten.
2. Build > Build APK(s). Die APK liegt in app/build/outputs/apk/debug/.
3. Modell holen (einmalig, ca. 500 MB-1 GB), z. B. "Gemma3-1B-IT" als .task (int4)
   von huggingface.co/litert-community (Lizenz muss ggf. akzeptiert werden).
4. Modell aufs Handy legen. App starten -> Dateiauswahl -> .task waehlen.
   Danach laeuft die KI komplett lokal: kein API-Key, kein Internet.

Hinweis: Der Prompt nutzt das Gemma-Format. Fuer andere Modelle `buildPrompt()` in index.html anpassen.

## Browser/PC-Variante komplett lokal
`python3 download.py` (einmalig, Internet) legt das Modell (wllama liegt schon im Projekt) nach app/src/main/assets.
Dann in diesem Ordner `python3 -m http.server 8000` starten und http://localhost:8000 oeffnen.
