ମୋ ଡ୍ରାଇଭର ଲଗ୍‌ବୁକ୍ — Android Studio ପ୍ରୋଜେକ୍ଟ

ଏହି ZIP ଭିତରେ Android app ପ୍ରୋଜେକ୍ଟ ଓ ଆପଣଙ୍କ ଲଗ୍‌ବୁକ୍ ଅଛି।
ଏହା APK ଫାଇଲ୍ ନୁହେଁ; APK ବନାଇବା ପାଇଁ Android Studio ଦରକାର।

APK ବନାଇବା ପଦକ୍ଷେପ:
1. କମ୍ପ୍ୟୁଟରରେ Android Studio ଇନ୍‌ଷ୍ଟଲ୍ କରନ୍ତୁ।
2. ZIP ଫାଇଲ୍‌କୁ Extract କରନ୍ତୁ।
3. Android Studio ଖୋଲି "Open" ଦବାଇ MyDriverLogbook ଫୋଲ୍ଡର ବାଛନ୍ତୁ।
4. Gradle sync ସମ୍ପୂର୍ଣ୍ଣ ହେବାକୁ ଦିଅନ୍ତୁ (Android SDK 35 ଇନ୍‌ଷ୍ଟଲ୍ କରିବାକୁ ପଡ଼ିପାରେ)।
5. Build > Build Bundle(s) / APK(s) > Build APK(s) ବାଛନ୍ତୁ।
6. ବନିଥିବା APK ସାଧାରଣତଃ app/build/outputs/apk/debug/app-debug.apk ରେ ମିଳିବ।

ସୁବିଧା:
- ଦୈନିକ ଓ ମାସିକ ଆୟ, ଖର୍ଚ୍ଚ ଓ ବାକି
- ଗ୍ରାହକଙ୍କ ନାମ ଓ ଫୋନ୍
- ଯାତ୍ରା ସ୍ଥାନ ଓ କି.ମି. ରେକର୍ଡ
- ଇଣ୍ଟରନେଟ୍ ବିନା ମଧ୍ୟ app ର ମୂଳ ଫର୍ମ ଚାଲିବ

ଗୁରୁତ୍ୱପୂର୍ଣ୍ଣ:
- ରେକର୍ଡ ଫୋନ୍‌ରେ ସ୍ଥାନୀୟ ଭାବେ ରହିବ; ଆପ୍ ଡାଟା clear/uninstall କଲେ ରେକର୍ଡ ହଜିପାରେ।
- ଏହି ପ୍ରୋଜେକ୍ଟ ଏଠାରେ Android SDK ଦ୍ୱାରା compile/test କରାଯାଇନାହିଁ।
