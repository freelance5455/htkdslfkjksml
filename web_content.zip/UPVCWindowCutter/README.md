# Om Window Optimize (Android project)

Offline-first Android WebView app with local persistence. Open this folder in Android Studio and sync Gradle.

## App icon
- Launcher icon uses the supplied Om Window Optimize artwork in all standard Android launcher densities.
- App display name: Om Window Optimize.

## Features
- Add/edit/delete window designs with photo thumbnails (Gallery / file picker).
- Separate Frame, Sash, Glass, Mesh and Panel/Part design profile fields.
- Eight independent editable formulas with W, H, SW and SH variables.
- Multiple windows per job, edit/delete, individual results and combined cutting list.
- Material quantity summary, CSV export, share/copy list, JSON backup/restore.

## Build APK
1. Install Android Studio with Android SDK Platform 35 and JDK 17+.
2. Open this folder as a project and let Gradle sync (internet is needed for first dependency download).
3. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Debug APK output is normally `app/build/outputs/apk/debug/app-debug.apk`.

## Important
- This source package has not been built or device-tested in this environment.
- Default example formulas are illustrative only. Verify every deduction against your exact UPVC profile system before production.
- The app saves data locally on the device. Export a JSON backup before clearing app data or uninstalling.
- The cutting list groups matching cut type and length in its material summary; it does not optimize saw-bar nesting.
