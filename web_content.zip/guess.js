/* Marvel Mega Games: games hub + "Guess the Character".
   Uses globals from the main script (PL, app, esc, tn, pic, BROKERS, uid, myName, readName, sh, home, stopBrowse...).
   Multiplayer: host-authoritative over MQTT, same idea as the auction (topics: mcguess1/...). */
const GMIN_R=5,GMAX_R=20,GMAXP=4,GCLUE_T=15,GREVEAL_T=7,GPTS=5;
const GLEVEL=["HARD","TOUGH","MEDIUM","EASY","VERY EASY"];
let gmq=null,ghb=null,gjoinBeat=null,gjoined=false,gcode=null,G=null,gIsHost=false,gSolo=false,gTimer=null,gseen={},glastN=0,gAns=null,gPlan=[],gKey="",gbq=null,gbrowseGen=0,gPub={},gNotice="",gpv=null,gFlash=null;

/* ---------- sounds (no narration) ---------- */
const sRight=()=>{[523,659,784,1047,1319].forEach((f,k)=>tn(f,k*.09,.3,"triangle",.14));tn(110,0,.25,"sine",.3)};
const sWrong=()=>{tn(180,0,.18,"sawtooth",.08);tn(140,.15,.25,"sawtooth",.08)};

/* ---------- smart name matching ---------- */
function gnorm(s){let x=String(s||"").normalize("NFD").replace(/[̀-ͯ]/g,"").toLowerCase().replace(/&/g," and ").replace(/[^a-z0-9]+/g," ").trim();
 x=x.replace(/\bdr\b/g,"doctor");
 const fill=/^(it s|it is|is it|i think it s|i think|i guess|maybe|probably|that s|that is|its|the)\s+/;
 let p;do{p=x;x=x.replace(fill,"")}while(x!==p);
 return x}
function glev(a,b){if(a===b)return 0;const m=a.length,n=b.length;if(!m)return n;if(!n)return m;let prev=[];for(let j=0;j<=n;j++)prev[j]=j;
 for(let i=1;i<=m;i++){const cur=[i];for(let j=1;j<=n;j++)cur[j]=Math.min(prev[j]+1,cur[j-1]+1,prev[j-1]+(a[i-1]===b[j-1]?0:1));prev=cur}
 return prev[n]}
const gAliasCache={};
function gAliases(name){return gAliasCache[name]||(gAliasCache[name]=[...new Set([name,...(GCHARS[name].a||[])].map(a=>gnorm(a).replace(/ /g,"")).filter(Boolean))])}
// smallest edit distance between the guess and any accepted name of `name` (Infinity when too far)
function gBest(gc,name){let best=Infinity;
 for(const ac of gAliases(name)){const d=glev(gc,ac),L=ac.length;
  const tol=L<=3?0:L==4?(gc[0]===ac[0]?1:0):L<=9?1:2;
  if(d<=tol&&d<best)best=d}
 return best}
function gMatch(guess,name){const g=gnorm(guess).replace(/ /g,"");if(g.length<2)return false;
 const mine=gBest(g,name);if(mine===Infinity)return false;
 for(const n of GNAMES){if(n!==name&&gBest(g,n)<mine)return false}
 return true}

/* ---------- planning rounds (random characters, clue versions never repeat back to back) ---------- */
function gLoad(k,def){try{const v=JSON.parse(localStorage.getItem(k));return v==null?def:v}catch(e){return def}}
function gStoreSet(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}
function gPlanRounds(n){
 const recent=gLoad("ma_g_recent",[]),used=gLoad("ma_g_used",{}),all=GNAMES.slice();
 const fresh=sh(all.filter(x=>!recent.includes(x)));
 const old=all.filter(x=>recent.includes(x)).sort((a,b)=>recent.indexOf(b)-recent.indexOf(a));
 const pick=fresh.concat(old).slice(0,Math.min(n,all.length));
 const plan=pick.map(name=>{const clues=[];
  for(let L=0;L<5;L++){const key=name+"|"+L,last=used[key];const v=(last===0||last===1)?1-last:(Math.random()<.5?0:1);used[key]=v;clues.push(GCHARS[name].c[L*2+v])}
  return{name,clues}});
 gStoreSet("ma_g_used",used);gStoreSet("ma_g_recent",pick.concat(recent.filter(x=>!pick.includes(x))).slice(0,GNAMES.length));
 return plan}

/* ---------- state ---------- */
const gClamp=v=>Math.max(GMIN_R,Math.min(GMAX_R,Math.round(+v)||10));
function gNew(rounds){return{host:uid,phase:"lobby",rounds:gClamp(rounds),pub:false,members:[],kicked:[],players:[],r:0,ci:0,clues:[],t:0,feed:[],fseq:0,res:null,ans:null,hist:[],gameId:""}}
const gTS=()=>"mcguess1/"+gcode+"/s",gTA=()=>"mcguess1/"+gcode+"/a";
const gMe=()=>G?G.players.find(p=>p.u===uid):null;
function gset(key,html){if(gKey===key)return false;gKey=key;app.innerHTML=html;return true}
function gdyn(id,html){const el=document.getElementById(id);if(el&&el.innerHTML!==html)el.innerHTML=html}

/* ---------- hub (game chooser) ---------- */
function hub(){const h=(location.hash||"").slice(1);
 if(/^G_/i.test(h))return guessHome(h.slice(2).toUpperCase());
 if(/^M_/i.test(h))return makeHome(h.slice(2).toUpperCase());
 if(h)return home();
 gKey="";
 app.innerHTML=`<div class="marvel-lobby"><div class="marvel-mark">MARVEL</div><h1>MEGA GAMES</h1><p class="lobby-tagline">An unofficial marvel fan game. Made by a 16yo 🥸</p></div>
 <h2>Choose a game</h2>
 <button class="gamecard" onclick="home()"><span class="gi">🔨</span><b>Marvel Auction</b><small>Bid on characters, build your squad and win the AI battle ranking.</small></button>
 <button class="gamecard alt" onclick="guessHome()"><span class="gi">🕵️</span><b>Guess the Character</b><small>5 clues per round, from hard to easy. Name the hero or villain first to score!</small></button>
 <button class="gamecard" style="background:#6ff0a0" onclick="makeHome()"><span class="gi">🧩</span><b>Make Your Player</b><small>Get random characters and place each one in a category. Build the strongest team in 7 rounds!</small></button>`}
function toHub(){try{stopBrowse()}catch(e){}try{gStopBrowse()}catch(e){}try{mkStopBrowse()}catch(e){}try{history.replaceState(null,"",location.pathname+location.search)}catch(e){}hub()}

/* ---------- guess home ---------- */
function guessHome(pre){gKey="";const ok=typeof mqtt!=="undefined",h=(typeof pre==="string"?pre:"").toUpperCase(),nt=gNotice;gNotice="";
 app.innerHTML=`<button class="g" onclick="toHub()">← All games</button><h1 style="margin-top:10px">Guess the Character</h1><p>An unofficial marvel fan game. Made by a 16yo 🥸</p>
 <div class="box"><label>Your name<input type="text" id="nm" maxlength="16" value="${esc(myName)}"></label><label>Total rounds (${GMIN_R}–${GMAX_R})<input type="number" id="grounds" min="${GMIN_R}" max="${GMAX_R}" step="1" value="10"></label>
 ${ok?`<label>Room type<select id="grt"><option value="0">Private (friends join with the code)</option><option value="1">Public (listed for everyone)</option></select></label><div class="bar" style="margin-top:10px"><button onclick="gCreate()">Create room</button></div>
 <label>Room code<input type="text" id="grc" maxlength="6" value="${esc(h)}" placeholder="ABCDE"></label><button class="alt" onclick="gJoin()">Join room</button>`:`<p>Multiplayer could not load. Check your internet and reload.</p>`}
 <div style="margin-top:10px"><button class="g" onclick="gPlaySolo()">Play solo</button></div></div>
 ${ok?`<div class="box"><h2>Public rooms</h2><div id="gpubList">Looking for rooms…</div></div>`:""}<p>${esc(nt)}</p>
 <div class="box"><h2>Rules</h2><p>1 to ${GMAXP} players. Every round a random Marvel character is picked and you get 5 clues, one every ${GCLUE_T} seconds, going from very hard to easy. Type your guess at any time: the first player to name the character scores points depending on the clue: clue 1 = 5 points, clue 2 = 4, clue 3 = 3, clue 4 = 2, clue 5 = 1. Then a new round starts. If nobody guesses after all 5 clues, the answer is revealed. You do not need the exact name, "doom" works for Doctor Doom and small typos are fine. After the last round the player with the most points wins.</p></div>`;
 if(ok){gBrowse();gRenderPub()}}
function gPlaySolo(){readName();gStopBrowse();gIsHost=true;gSolo=true;gjoined=false;gseen={};G=gNew(gClamp((document.getElementById("grounds")||{}).value));G.members=[{u:uid,n:myName,t:Date.now()}];gStart()}

/* ---------- connection ---------- */
function gconnect(cb,fail,k,ns){k=k||0;if(k>=BROKERS.length)return fail();let done=false;
 const c=mqtt.connect(BROKERS[k],{connectTimeout:6000,reconnectPeriod:3000,clientId:"mg"+Math.random().toString(16).slice(2,12)});
 const bad=()=>{if(done)return;done=true;clearTimeout(t);try{c.end(true)}catch(e){}gconnect(cb,fail,k+1,ns)};
 const t=setTimeout(bad,7000);
 c.on("connect",()=>{if(!done){done=true;clearTimeout(t);if(!ns)gmq=c;cb(c)}else if(gjoined&&!gIsHost)ghello()});
 c.on("error",bad)}
function gSetHash(){try{history.replaceState(null,"","#G_"+gcode)}catch(e){try{location.hash="G_"+gcode}catch(x){}}}
function gCreate(){readName();gStopBrowse();const rounds=gClamp((document.getElementById("grounds")||{}).value),pubSel=(document.getElementById("grt")||{}).value=="1";
 gKey="";app.innerHTML="<p>Creating room…</p>";gcode=Math.random().toString(36).slice(2,7).toUpperCase().replace(/[^A-Z0-9]/g,"X");gseen={};
 gconnect(c=>{gIsHost=true;gSolo=false;G=gNew(rounds);G.pub=pubSel;G.members=[{u:uid,n:myName,t:Date.now()}];gSetHash();c.subscribe(gTA());
  c.on("message",(tp,pl)=>{let m;try{m=JSON.parse(pl)}catch(e){return}if(!m)return;if(m.kind=="hello"){gRegister(m.u,m.name);gSave();grender()}else gApply(m.u,m)});
  ghb=setInterval(()=>{gSave();grender()},4000);grender();gSave()},()=>{gNotice="Could not reach the game server. Check your internet and try again.";guessHome()})}
function ghello(){if(gmq&&gmq.connected)gmq.publish(gTA(),JSON.stringify({kind:"hello",u:uid,name:myName}))}
function gJoin(pc){readName();const c0=(typeof pc==="string"&&pc)||((document.getElementById("grc")||{}).value||"").trim().toUpperCase();if(!c0)return;gStopBrowse();
 gcode=c0;gKey="";app.innerHTML="<p>Joining room "+esc(c0)+"…</p>";let ok=false,tries=0,iv=null;
 const stop=()=>{clearTimeout(t);clearInterval(iv)};
 const t=setTimeout(()=>{if(!ok){stop();clearInterval(gjoinBeat);gCleanup();gNotice="Host is offline or the code is wrong.";guessHome()}},12000);
 gconnect(c=>{gjoined=true;c.subscribe(gTS());
  c.on("message",(tp,pl)=>{let d;try{d=JSON.parse(pl)}catch(e){return}if(!d)return;if(!ok){ok=true;stop();gSetHash()}
   const bye=m=>{stop();gCleanup();gNotice=m;guessHome()};
   if(d.closed||d.phase==="closed")return bye("The host disbanded this room.");
   if((d.kicked||[]).includes(uid))return bye("The host removed you from this room.");
   const isM=(d.members||[]).some(m=>m.u===uid)||(d.players||[]).some(p=>p.u===uid);
   if(d.phase==="lobby"&&!isM&&(d.members||[]).length>=GMAXP)return bye("This room is full ("+GMAXP+"/"+GMAXP+" players).");
   if(d.phase!=="lobby"&&!isM)return bye("This game has already started.");
   G=d;grender()});
  ghello();iv=setInterval(()=>{if(!ok&&tries++<5)ghello()},2000);gjoinBeat=setInterval(ghello,4000)},()=>{clearTimeout(t);gNotice="Could not reach the game server. Check your internet and try again.";guessHome()})}
function gact(kind,x){const n=Math.max(Date.now(),glastN+1);glastN=n;if(gmq&&gmq.connected)gmq.publish(gTA(),JSON.stringify(Object.assign({u:uid,kind,n,name:myName},x||{})))}
function gSave(){if(!gIsHost||gSolo||!gmq||!gmq.connected)return;gRefresh();gmq.publish(gTS(),JSON.stringify(G));gpubBeat()}
function gRefresh(){if(!G||G.phase!=="lobby")return;const now=Date.now();G.members=G.members.filter(m=>now-(m.t||0)<14000||m.u===uid);const me=G.members.find(m=>m.u===uid);if(me){me.n=myName;me.t=now}}
function gRegister(u,n){if(!u||!G||G.phase!=="lobby"||(G.kicked||[]).includes(u))return;const now=Date.now();
 G.members=G.members.filter(m=>now-(m.t||0)<14000||m.u===uid);let m=G.members.find(x=>x.u===u);
 if(!m){if(G.members.length>=GMAXP)return;G.members.push(m={u,n:"Player",t:now})}
 m.n=String(n||m.n||"Player").slice(0,16);m.t=now}
function gApply(u,a){if(!gIsHost||!G||!a||!(a.n>(gseen[u]||0)))return;gseen[u]=a.n;
 if(a.kind==="guess")gHandleGuess(u,a.g,a.r);else if(a.kind==="leave")gRemoveLeaver(u)}
function gRemoveLeaver(u){if(!G)return;G.members=(G.members||[]).filter(m=>m.u!==u);gSave();grender()}
function gKick(target){if(!gIsHost||!G||G.phase!=="lobby"||!target||target===uid)return;if(!confirm("Remove this player from the room?"))return;
 if(!G.kicked.includes(target))G.kicked.push(target);G.members=G.members.filter(m=>m.u!==target);gSave();grender()}
function gCleanup(){clearInterval(ghb);clearInterval(gjoinBeat);clearInterval(gTimer);ghb=null;gjoinBeat=null;gTimer=null;try{if(gmq)gmq.end(true)}catch(e){}gmq=null;gjoined=false;gIsHost=false;gSolo=false;G=null;gcode=null;gAns=null;gPlan=[];gpv=null;gKey="";try{history.replaceState(null,"",location.pathname+location.search)}catch(e){}}
function gLeave(){if(!G)return;if(!confirm(gSolo?"Quit this game?":"Leave this room?"))return;
 if(gSolo||gIsHost){gCleanup();gNotice="";return guessHome()}
 let fin=false;const finish=()=>{if(fin)return;fin=true;gCleanup();gNotice="You left the room.";guessHome()};
 if(gmq&&gmq.connected){const n=Math.max(Date.now(),glastN+1);glastN=n;gmq.publish(gTA(),JSON.stringify({u:uid,kind:"leave",n}),{qos:1},finish);setTimeout(finish,1800)}else finish()}
function gDisband(){if(!G||!gIsHost||gSolo)return;if(!confirm("Disband this room for everyone?"))return;
 let fin=false;const finish=()=>{if(fin)return;fin=true;gCleanup();gNotice="Room disbanded.";guessHome()};
 if(gmq&&gmq.connected){const code=gcode;gmq.publish(gTS(),JSON.stringify({closed:true,host:uid,phase:"closed",members:[]}),{qos:1},()=>{if(!gmq||!gmq.connected)return finish();gmq.publish("mcguess1/pub/"+code,JSON.stringify({c:code,x:1}),{qos:1},finish)});setTimeout(finish,2500)}else finish()}
function gSetRounds(v){if(!gIsHost||G.phase!=="lobby")return;G.rounds=gClamp(v);gSave();grender()}
function gTogglePub(){if(!gIsHost||G.phase!=="lobby")return;G.pub=!G.pub;if(!G.pub)gpubClose();gSave();grender()}

/* ---------- game flow (host only) ---------- */
function gStart(){if(!gIsHost||!G||G.phase!=="lobby")return;if(G.pub)gpubClose();
 gRefresh();G.players=G.members.slice(0,GMAXP).map(m=>({u:m.u,n:m.n,pts:0}));if(!G.players.length)return;
 G.gameId="g"+Date.now().toString(36);G.hist=[];G.r=0;G.fseq=0;gPlan=gPlanRounds(G.rounds);gNextRound();clearInterval(gTimer);gTimer=setInterval(gTick,1000)}
function gNextRound(){G.r++;
 if(G.r>G.rounds){G.phase="done";G.cur=null;G.t=0;clearInterval(gTimer)}
 else{const p=gPlan[G.r-1];gAns=p.name;G.phase="round";G.ci=0;G.clues=[p.clues[0]];G.t=GCLUE_T;G.res=null;G.ans=null;G.feed=[];
  try{pic(PL.findIndex(x=>x.n===p.name))}catch(e){}}
 gSave();grender()}
function gTick(){if(!gIsHost||!G)return;
 if(G.phase==="round"){G.t--;if(G.t<=0){if(G.ci<4){G.ci++;G.clues.push(gPlan[G.r-1].clues[G.ci]);G.t=GCLUE_T}else{gEndRound(null)}}}
 else if(G.phase==="reveal"){G.t--;if(G.t<=0){gNextRound();return}}
 else return;
 gSave();grender()}
function gEndRound(winner,pts){G.phase="reveal";G.ans=PL.findIndex(x=>x.n===gAns);G.t=GREVEAL_T;
 G.res=winner?{u:winner.u,n:winner.n,ci:G.ci+1,pts:pts}:{u:null,n:"",ci:0,pts:0};
 G.hist.push({r:G.r,ch:gAns,n:winner?winner.n:"",ci:winner?G.ci+1:0,pts:winner?pts:0})}
function gHandleGuess(u,text,r){if(!G||G.phase!=="round"||r!==G.r)return;const pl=G.players.find(p=>p.u===u);if(!pl)return;
 text=String(text||"").slice(0,40);if(!text.trim())return;
 const ok=gMatch(text,gAns);G.fseq++;G.feed.unshift({k:G.fseq,u,n:pl.n,ok});G.feed=G.feed.slice(0,5);
 if(ok){const pts=GPTS-G.ci;pl.pts+=pts;gEndRound(pl,pts)}
 gSave();grender()}
function gSubmit(){const inp=document.getElementById("gin");if(!inp||!G||G.phase!=="round")return;const text=inp.value.trim();if(!text)return;inp.value="";sClick();
 if(gIsHost)gHandleGuess(uid,text,G.r);else gact("guess",{g:text,r:G.r})}
function gRematch(){if(!gIsHost||!G||G.phase!=="done")return;if(!confirm("Back to the lobby with the same players?"))return;
 const n=gNew(G.rounds),now=Date.now();n.pub=G.pub;n.kicked=G.kicked||[];n.members=(G.members||[]).map(m=>({u:m.u,n:m.n,t:now}));
 G=n;gseen={};gpv=null;gKey="";
 if(gSolo){gStart()}else{gSave();grender();if(G.pub)gpubBeat()}}

/* ---------- sounds on state changes (all players) ---------- */
function gfx(){const g=G,p=gpv;if(!g)return;
 if(g.phase==="round"){
  if(!p||p.ph!=="round"||p.r!==g.r)sNew();else if(p.ci!==g.ci)sNew();else if(g.t<=3&&p.t!==g.t)sTick();
  const base=p&&p.r===g.r?p.fseq:(g.fseq||0);
  (g.feed||[]).filter(f=>f.k>base&&!f.ok&&f.u===uid).forEach(()=>{sWrong();gFlash={txt:"❌ Not it, try again!",ts:Date.now()}})}
 else if(g.phase==="reveal"){if(!p||p.ph!=="reveal"||p.r!==g.r){if(g.res&&g.res.u)sRight();else sUn()}}
 else if(g.phase==="done"){if(!p||p.ph!=="done")sEnd()}
 gpv={ph:g.phase,r:g.r,ci:g.ci,t:g.t,fseq:g.fseq||0}}

/* ---------- views ---------- */
function grender(){if(!G||!app)return;gfx();
 if(G.phase==="lobby")return gLobby();if(G.phase==="round")return gRound();if(G.phase==="reveal")return gRevealView();if(G.phase==="done")return gDone()}
const gScoreHtml=()=>`<div class="chips">${G.players.map(p=>`<span class="chip" style="${p.u===uid?"border-color:var(--y);color:var(--y)":""}">${esc(p.n)}${p.u===uid?" (you)":""} · <b>${p.pts}</b></span>`).join("")}</div>`;
const gLeaveBtn=()=>gSolo?`<button class="no" onclick="gLeave()">Quit game</button>`:gIsHost?`<button class="no" onclick="gDisband()">Disband room</button>`:`<button class="no" onclick="gLeave()">Leave room</button>`;
function gLobby(){const mem=G.members||[],key="L"+JSON.stringify([mem.map(m=>m.u+m.n),G.rounds,!!G.pub,gIsHost]);
 const html=`<div class="marvel-lobby"><div class="marvel-mark">MARVEL</div><h1>GUESS THE CHARACTER</h1><p class="lobby-tagline">An unofficial marvel fan game. Made by a 16yo 🥸</p></div>
 <div class="box lobby-room"><p>Room code</p><div class="code">${esc(gcode||"")}</div><p>Send your friends this website's link and this code. Up to ${GMAXP} players can join. Keep this screen open until the game ends.</p>
 <h2 style="margin-top:8px">Players (${mem.length}/${GMAXP})</h2>${mem.map(m=>`<div class="row" style="margin:5px 0"><span>${esc(m.n||"Player")}${m.u===G.host?" · Host":""}</span>${gIsHost&&m.u!==uid?`<button class="no" style="padding:5px 9px" onclick="gKick('${esc(m.u)}')">Remove</button>`:""}</div>`).join("")||"<small>No players yet</small>"}</div>
 ${gIsHost?`<div class="box"><h2>Room settings</h2><label>Total rounds (${GMIN_R} to ${GMAX_R})<input type="number" min="${GMIN_R}" max="${GMAX_R}" value="${G.rounds}" onchange="gSetRounds(this.value)"></label>
 <label><input type="checkbox" ${G.pub?"checked":""} onchange="gTogglePub()"> Public room (listed for everyone)</label></div><button onclick="gStart()">Start game</button>`
 :`<p>Waiting for the host to start. The game has ${G.rounds} rounds.</p>`}<div style="margin-top:10px">${gLeaveBtn()}</div>`;
 gset(key,html)}
function gRound(){const me=gMe(),key=`R${G.r}:${G.ci}:${me?1:0}:${gIsHost}`;
 const old=document.getElementById("gin"),keep=old?old.value:"",foc=old&&document.activeElement===old;
 const clueList=G.clues.map((c,i)=>({c,i})).reverse().map(({c,i})=>i===G.ci?`<div class="gclue cur"><span class="tag" style="background:${i>=3?"#6ff0a0":i==2?"var(--y)":"#ff8a8a"}">${GLEVEL[i]}</span><div class="gq">❓ ${esc(c)} <b style="color:var(--y);white-space:nowrap">Who am I?</b></div></div>`:`<div class="gclue old"><small>Clue ${i+1}</small><div>${esc(c)}</div></div>`).join("");
 const html=`<div class="row"><small>Round ${G.r} of ${G.rounds}</small><small>${gSolo?"Solo":"Room "+esc(gcode||"")}</small></div><div style="margin:8px 0" id="gscore"></div>
 <div class="box"><div class="row"><h2>Clue ${G.ci+1} of 5</h2><div class="big" id="gt">${G.t}</div></div><div class="gbar"><i id="gbarf"></i></div><p style="margin:8px 0 2px">Guess the Marvel character</p>${clueList}</div>
 ${me?`<div class="box"><label>Your guess<input type="text" id="gin" maxlength="40" autocomplete="off" autocorrect="off" spellcheck="false" placeholder="Type a character name" onkeydown="if(event.key==='Enter')gSubmit()"></label><div class="bar"><button onclick="gSubmit()">Guess</button></div><p id="gmsg" style="min-height:20px"></p></div>`:`<p>You are watching.</p>`}
 <div class="box log" id="gfeed"></div><div>${gLeaveBtn()}</div>`;
 if(gset(key,html)){const n=document.getElementById("gin");if(n){n.value=keep;if(foc)n.focus()}}
 gdyn("gscore",gScoreHtml());
 const tt=document.getElementById("gt");if(tt){tt.textContent=G.t;tt.style.color=G.t<=3?"var(--r)":"var(--c)"}
 const bf=document.getElementById("gbarf");if(bf){bf.style.width=Math.max(0,G.t/GCLUE_T*100)+"%";bf.style.background=G.t<=3?"var(--r)":"var(--c)"}
 gdyn("gfeed",(G.feed||[]).map(f=>`<div>${f.ok?"✅":"❌"} ${esc(f.n)}${f.u===uid?" (you)":""} ${f.ok?"got it!":"guessed wrong"}</div>`).join("")||"<div>No guesses yet. Be the first!</div>");
 gdyn("gmsg",gFlash&&Date.now()-gFlash.ts<2500?esc(gFlash.txt):"")}
function gRevealView(){const r=G.res||{},key="V"+G.r,ch=PL[G.ans],last=G.r>=G.rounds,me=gMe();
 const html=`<div class="row"><small>Round ${G.r} of ${G.rounds}</small><small>${gSolo?"Solo":"Room "+esc(gcode||"")}</small></div>
 <div class="box ${r.u?"g2":""}" style="text-align:center"><p>${r.u?(r.u===uid?"🎉 You got it!":"🎉 "+esc(r.n)+" got it!"):"😶 Nobody guessed it"}</p>
 ${r.u?`<p>on clue ${r.ci} · +${r.pts} point${r.pts==1?"":"s"}</p>`:`<p>The answer was</p>`}
 <div class="gbig"><div id="gpic"></div></div><div class="hero" style="color:var(--y);margin-top:8px">${esc(ch?ch.n:"?")}</div>
 <p id="gnext" style="margin-top:10px"></p></div><div class="box"><h2>Scores</h2><div id="gscore"></div></div><div>${gLeaveBtn()}</div>`;
 if(gset(key,html)){const sl=document.getElementById("gpic");if(sl)sl.replaceWith(pic(G.ans))}
 gdyn("gscore",gScoreHtml());gdyn("gnext",last?"Final results in "+G.t+"s":"Next round in "+G.t+"s")}
function gDone(){const key="D"+G.gameId;
 const rank=G.players.slice().sort((a,b)=>b.pts-a.pts),top=rank[0]?rank[0].pts:0,winners=top>0?rank.filter(p=>p.pts===top):[];
 const medal=n=>n===1?"🥇":n===2?"🥈":n===3?"🥉":"#"+n;let pos=0,prev=-1;
 const rows=rank.map((p,i)=>{if(p.pts!==prev){pos=i+1;prev=p.pts}return `<tr class="${p.u===uid?"me":""}"><td>${medal(pos)}</td><td>${esc(p.n)}</td><td>${p.pts}</td></tr>`}).join("");
 const html=`<h1>Game over</h1><div class="box g2" style="text-align:center"><p>Final winner</p><div class="hero" style="color:var(--y)">${winners.length?winners.map(w=>esc(w.n)).join(" & "):"Nobody scored"}</div>${winners.length?`<p>${winners.length>1?"Tie with":"with"} ${top} points${winners.some(w=>w.u===uid)?" · That is you, congratulations!":""}</p>`:""}</div>
 <div class="box"><h2>Final scores</h2><table><tr><th>#</th><th>Player</th><th>Points</th></tr>${rows}</table></div>
 <div class="box"><h2>Round recap</h2><table><tr><th>Round</th><th>Character</th><th>Solved by</th></tr>${(G.hist||[]).map(h=>`<tr><td>${h.r}</td><td>${esc(h.ch)}</td><td>${h.n?esc(h.n)+" · clue "+h.ci+" (+"+(h.pts||0)+")":"<span class=\"un\">Nobody</span>"}</td></tr>`).join("")}</table></div>
 ${gIsHost?`<button onclick="gRematch()">Play again</button> ${gSolo?"":'<button class="no" onclick="gDisband()">Disband room</button>'}`:`<p>Waiting for the host to start a rematch.</p><button class="no" onclick="gLeave()">Leave room</button>`} <button class="alt" onclick="${gSolo||!gIsHost?"gLeaveQuiet()":"gLeaveQuiet()"}">Back to Guess the Character</button>`;
 gset(key,html)}
function gLeaveQuiet(){if(gIsHost&&!gSolo&&!confirm("This will close the room for everyone. Leave?"))return;if(gIsHost&&!gSolo&&gmq&&gmq.connected){const code=gcode;try{gmq.publish(gTS(),JSON.stringify({closed:true,host:uid,phase:"closed",members:[]}));gmq.publish("mcguess1/pub/"+code,JSON.stringify({c:code,x:1}))}catch(e){}}
 setTimeout(()=>{gCleanup();gNotice="";guessHome()},gIsHost&&!gSolo?400:0)}

/* ---------- public rooms ---------- */
function gpubBeat(){if(!gIsHost||gSolo||!G||!G.pub||G.phase!="lobby"||!gmq||!gmq.connected)return;gmq.publish("mcguess1/pub/"+gcode,JSON.stringify({c:gcode,h:myName,n:(G.members||[]).length,cnt:G.rounds}))}
function gpubClose(){if(gIsHost&&!gSolo&&gmq&&gmq.connected)gmq.publish("mcguess1/pub/"+gcode,JSON.stringify({c:gcode,x:1}))}
function gBrowse(){if(gbq||typeof mqtt==="undefined")return;const g=++gbrowseGen;
 gconnect(c=>{if(g!==gbrowseGen){try{c.end(true)}catch(e){}return}gbq=c;c.subscribe("mcguess1/pub/#");
  c.on("message",(tp,pl)=>{let m;try{m=JSON.parse(pl)}catch(e){return}if(!m)return;
   const k=String(m.c||"").replace(/[^A-Z0-9]/g,"").slice(0,6);if(!k)return;
   if(m.x)delete gPub[k];else gPub[k]={c:k,h:String(m.h||"Player").slice(0,16),n:Math.max(0,Math.min(GMAXP,+m.n||0)),cnt:+m.cnt||0,t:Date.now()};gRenderPub()})},()=>{},0,true)}
function gStopBrowse(){gbrowseGen++;if(gbq){try{gbq.end(true)}catch(e){}gbq=null}gPub={}}
function gRenderPub(){const el=document.getElementById("gpubList");if(!el)return;const now=Date.now();
 for(const k in gPub)if(now-gPub[k].t>12000)delete gPub[k];
 const l=Object.values(gPub).filter(r=>r.n<GMAXP).sort((a,b)=>b.n-a.n);
 el.innerHTML=l.length?l.map(r=>`<div class="row" style="margin:8px 0;gap:10px"><span>${esc(r.h)}’s room · ${r.n}/${GMAXP} players · ${r.cnt} rounds</span><button class="alt" onclick="gJoin('${r.c}')">Join</button></div>`).join(""):"<p>No public rooms right now. Create one to start!</p>"}
setInterval(gRenderPub,3000);
