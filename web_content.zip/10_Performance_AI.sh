#!/bin/bash
# Performance-AI v2.1 AxManager - Comandos limpos com 2>/dev/null || true
echo "Aplicando Performance-AI..."

settings put global window_animation_scale 0 2>/dev/null || true
settings put global transition_animation_scale 0 2>/dev/null || true
settings put global animator_duration_scale 0 2>/dev/null || true
settings put system peak_refresh_rate 120 2>/dev/null || true
settings put system min_refresh_rate 120 2>/dev/null || true
settings put global force_gpu_rendering 1 2>/dev/null || true
settings put global disable_hw_overlays 1 2>/dev/null || true
setprop debug.performance.tuning 1 2>/dev/null || true
setprop debug.hwui.renderer skiagl 2>/dev/null || true
setprop persist.sys.ui.hw 1 2>/dev/null || true
cmd power set-fixed-performance-mode-enabled true 2>/dev/null || true
pm trim-caches 999G 2>/dev/null || true

echo "Performance-AI aplicado!"
