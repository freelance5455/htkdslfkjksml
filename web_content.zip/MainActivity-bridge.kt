// MainActivity.kt — Android WebView integration (Kotlin)
// Merge these parts into your existing Activity; do not create a second WebView.
// Requires Android API 29+ for the MediaStore Downloads implementation below.

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import android.provider.MediaStore
import android.util.Base64
import java.io.OutputStream

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Keep your existing layout if you already have one.
        webView = WebView(this)
        setContentView(webView)

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.addJavascriptInterface(AndroidBridge(this, webView), "Android")

        // Load the same local HTML asset your APK currently uses:
        webView.loadUrl("file:///android_asset/web/Question_Paper_Generator_Pattern_First_Centered-1.html")
    }
}

class AndroidBridge(
    private val activity: AppCompatActivity,
    private val webView: WebView
) {
    @JavascriptInterface
    fun printPage() {
        activity.runOnUiThread {
            val printManager = activity.getSystemService(Context.PRINT_SERVICE) as PrintManager
            val adapter = webView.createPrintDocumentAdapter("EasyQuestionMaker")
            printManager.print(
                "EasyQuestionMaker",
                adapter,
                PrintAttributes.Builder()
                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                    .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                    .build()
            )
        }
    }

    @JavascriptInterface
    fun downloadFile(fileName: String, mimeType: String, base64Data: String) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            activity.runOnUiThread {
                Toast.makeText(activity, "ডাউনলোডের জন্য Android 10 বা নতুন সংস্করণ প্রয়োজন", Toast.LENGTH_LONG).show()
            }
            return
        }
        try {
            val bytes = Base64.decode(base64Data, Base64.DEFAULT)
            val resolver = activity.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                put(MediaStore.Downloads.MIME_TYPE, mimeType)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Could not create download entry")
            resolver.openOutputStream(uri).use { out: OutputStream? ->
                requireNotNull(out) { "Could not open output stream" }
                out.write(bytes)
                out.flush()
            }
            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            activity.runOnUiThread {
                Toast.makeText(activity, "Downloads ফোল্ডারে সংরক্ষিত হয়েছে", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            activity.runOnUiThread {
                Toast.makeText(activity, "ডাউনলোড ব্যর্থ: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }
}
