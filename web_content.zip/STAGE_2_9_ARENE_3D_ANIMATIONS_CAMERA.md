# Socle 2.9 — Arènes 3D, animations de coups et caméra libre

## Objectif
Poursuivre le moteur WebGL du Socle 2.8 sans toucher aux règlements, au calendrier ni aux moteurs des huit compétitions.

## Éléments ajoutés
- Enceinte tridimensionnelle autour du damier : socle, quatre tribunes à plusieurs niveaux et bandeaux périphériques.
- Public stylisé composé de silhouettes géométriques réparties dans les gradins.
- Pylônes et projecteurs d'éclairage aux angles de l'arène.
- Caméra orbitale manipulable par glissement du pointeur ; zoom à la molette ou au geste équivalent du pavé tactile.
- Animation interpolée des déplacements des damistes, segment par segment pour les prises multiples.
- La couche canvas ne bloque pas les cases HTML qui transmettent les coups au moteur réglementaire.
- Réduction du facteur de densité du rendu pour limiter le coût GPU sur les appareils mobiles.

## Préservation
Le moteur de règles des dames, le calendrier central, les huit moteurs de compétition, les contrats, les transferts et les identités visuelles ne sont pas modifiés. `match-ui.js` ne fait qu'appeler l'animation après l'application d'un coup légal.

## Vérifications
- 170 tests automatisés réussis.
- Syntaxe JavaScript contrôlée avec `node --check` sur `src/` et `tests/`.
- Contrôle de non-modification des huit moteurs de compétition par comparaison des empreintes avec le Socle 2.8.
- La tentative de validation navigateur Chromium/Playwright a été bloquée par la politique d'exécution de l'environnement (`ERR_BLOCKED_BY_ADMINISTRATOR`). Le rendu GPU réel et les interactions tactiles restent donc à valider sur un navigateur/appareil cible.

## Limites restantes
Cette étape ajoute un décor 3D géométrique et des animations de déplacement. Le public n'est pas encore constitué de modèles humains détaillés ; il n'y a pas encore de personnages animés avec squelettes, de textures PBR, de son spatialisé, de foule animée, ni de séquences cinématiques avancées. Le rendu n'est pas présenté comme photoréaliste.
