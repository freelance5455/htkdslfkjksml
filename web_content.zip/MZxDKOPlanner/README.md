# MZxDKO Planner - Android project
WebView wrapper around the planner (app/src/main/assets/index.html). PNG/CSV exports save to Downloads.

## Option A - Android Studio
File > Open this folder, let Gradle sync, then Build > Build APK(s).
Output: app/build/outputs/apk/debug/app-debug.apk

## Option B - GitHub (no installs)
Push this folder to a GitHub repo (branch main). Actions > "Build APK" builds it.
Download app-debug.apk from the run's Artifacts.

## Install
Copy the APK to the phone, open it, allow "install unknown apps" when asked.
Note: styling loads Tailwind and Inter from the internet, so the app needs a connection.
