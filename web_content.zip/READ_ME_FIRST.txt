RAJA TRAVEL MULTI-AGENCY MANAGER

INSTALL / RUN:
1. Extract this ZIP on your laptop or Android phone.
2. Open Raja_Travel_Multi_Agency.html in Chrome or Edge.
3. Press + Add Agency to create more agencies.
4. Use the agency selector at the top to switch between agencies.
5. Each agency has separate bookings, customers, income and expenses.
6. Use Backup to download all agencies and their records.

This is an offline browser app. Data is stored in the browser on this device.
Back up regularly. It does not include cloud sync, shared multi-user login,
airline/GDS integration or APK/EXE installer yet.
