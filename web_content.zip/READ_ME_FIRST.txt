SOUNDS LIKE IT! — 30 sounds, single Captain Sound intro, player setup and scroll fixes.

Extract ZIP in Samsung My Files and open index.html.

Changes:
- Large visible 2–6 player selector.
- Setup order: number of players -> names -> game mode -> start.
- After Captain Sound's intro scene is closed, scroll to player count.
- After player count, scroll to names.
- After the final player name, scroll to game mode.
- After game mode selection, scroll to the Start Game button.
- Starting the game scrolls to categories; category -> difficulty -> start turn.
- Correct/wrong board reveal and three-second pause retained.
- 30 original approved sounds retained; previous game ZIP remains a backup.

This ZIP has been checked for integrity and JavaScript syntax, but please test
these interactions on your Android phone before treating this as final.
