@echo off
REM Ejecutar desde esta carpeta con Android SDK y Gradle instalados.
gradle :app:assembleDebug
if errorlevel 1 exit /b %errorlevel%
echo APK: %CD%\app\build\outputs\apk\debug\app-debug.apk
