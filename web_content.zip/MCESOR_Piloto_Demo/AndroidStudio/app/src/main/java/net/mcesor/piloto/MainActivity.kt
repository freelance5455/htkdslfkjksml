package net.mcesor.piloto

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        enterImmersiveMode()

        webView = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = false
            settings.setSupportMultipleWindows(false)
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val uri = request.url
                    if (uri.scheme == "file" && uri.path?.contains("/android_asset/") == true) return false
                    openExternal(uri.toString())
                    return true
                }
            }
            addJavascriptInterface(ExternalLinkBridge(), "Android")
        }
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    private inner class ExternalLinkBridge {
        @JavascriptInterface
        fun openExternal(rawUrl: String) {
            runOnUiThread { this@MainActivity.openExternal(rawUrl) }
        }
    }

    private fun openExternal(rawUrl: String) {
        val uri = runCatching { Uri.parse(rawUrl) }.getOrNull() ?: return
        val scheme = uri.scheme?.lowercase()
        val host = uri.host?.lowercase()

        // Accept only the official Google Play listing URL, including an Android
        // intent:// redirect that may be emitted by the Play Store website.
        if (scheme !in setOf("https", "intent") || host != "play.google.com" ||
            uri.path != "/store/apps/details") {
            Toast.makeText(this, "Enlace externo no reconocido", Toast.LENGTH_SHORT).show()
            return
        }

        val packageId = uri.getQueryParameter("id")
        val allowedPackages = setOf(
            "com.google.android.apps.bard",
            "com.anthropic.claude",
            "ai.perplexity.app.android",
            "com.openai.chatgpt",
            "com.facebook.stella"
        )
        if (packageId == null || packageId !in allowedPackages) {
            Toast.makeText(this, "Enlace no autorizado para esta demo", Toast.LENGTH_SHORT).show()
            return
        }

        // Prefer opening the installed AI app. If it is not installed, open its
        // listing directly in the Play Store rather than loading intent:// in WebView.
        val launchIntent = runCatching { packageManager.getLaunchIntentForPackage(packageId) }.getOrNull()
        if (launchIntent != null) {
            try {
                startActivity(launchIntent)
                return
            } catch (_: ActivityNotFoundException) {
                // Fall through to its official Play Store listing.
            }
        }

        val marketIntent = Intent(
            Intent.ACTION_VIEW,
            Uri.parse("market://details?id=$packageId")
        ).setPackage("com.android.vending")

        try {
            startActivity(marketIntent)
        } catch (_: ActivityNotFoundException) {
            // Devices without a Play Store app can still use the official HTTPS page.
            try {
                startActivity(
                    Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse("https://play.google.com/store/apps/details?id=$packageId")
                    )
                )
            } catch (_: ActivityNotFoundException) {
                Toast.makeText(this, "No hay una aplicación disponible para abrir Google Play", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun enterImmersiveMode() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            )
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enterImmersiveMode()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        webView.evaluateJavascript(
            "(function(){var d=document.getElementById('chatOverlay'); if(d && d.classList.contains('open')) { document.getElementById('closeChat').click(); return 'closed'; } return 'exit'; })();"
        ) { result ->
            if (result == "\"exit\"") finish()
        }
    }
}
