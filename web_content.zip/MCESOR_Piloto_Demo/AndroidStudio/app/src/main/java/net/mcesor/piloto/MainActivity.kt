package net.mcesor.piloto

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        enterImmersiveMode()

        webView = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = false
            settings.setSupportMultipleWindows(false)
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val uri = request.url
                    if (uri.scheme == "file" && uri.path?.contains("/android_asset/") == true) return false
                    openExternal(uri.toString())
                    return true
                }
            }
            addJavascriptInterface(ExternalLinkBridge(), "Android")
        }
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    private inner class ExternalLinkBridge {
        @JavascriptInterface
        fun openExternal(rawUrl: String) {
            runOnUiThread { this@MainActivity.openExternal(rawUrl) }
        }
    }

    private fun openExternal(rawUrl: String) {
        val uri = runCatching { Uri.parse(rawUrl) }.getOrNull() ?: return
        val host = uri.host?.lowercase() ?: return
        val packageId = uri.getQueryParameter("id")
        val allowedPackages = setOf(
            "com.google.android.apps.bard",
            "com.anthropic.claude",
            "ai.perplexity.app.android",
            "com.openai.chatgpt",
            "com.facebook.stella"
        )
        if (uri.scheme != "https" || host != "play.google.com" || uri.path != "/store/apps/details" || packageId !in allowedPackages) {
            Toast.makeText(this, "Enlace no autorizado para esta demo", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "No se encontró una aplicación para abrir Google Play", Toast.LENGTH_LONG).show()
        }
    }

    private fun enterImmersiveMode() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            )
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enterImmersiveMode()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        webView.evaluateJavascript(
            "(function(){var d=document.getElementById('chatOverlay'); if(d && d.classList.contains('open')) { document.getElementById('closeChat').click(); return 'closed'; } return 'exit'; })();"
        ) { result ->
            if (result == "\"exit\"") finish()
        }
    }
}
