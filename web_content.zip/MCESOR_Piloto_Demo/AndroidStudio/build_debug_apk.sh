#!/usr/bin/env bash
set -euo pipefail
# Run from the AndroidStudio directory in an environment with Android SDK + Gradle installed.
gradle :app:assembleDebug
printf "APK: %s\n" "$PWD/app/build/outputs/apk/debug/app-debug.apk"
