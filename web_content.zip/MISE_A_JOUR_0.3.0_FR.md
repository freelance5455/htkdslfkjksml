# SKYNET V2 — mise à jour 0.3.0

## Objectif
Renforcer le socle serveur du Module 16 sans supprimer ni remplacer l'interface HTML existante.

## Ajouts
1. Migrations de base de données versionnées avec Alembic.
2. Révocation des jetons de session de l'utilisateur via `POST /auth/logout`.
3. Limitation basique des tentatives sur l'authentification et l'initialisation initiale.
4. Scripts de sauvegarde PostgreSQL et de restauration avec confirmation destructive.
5. Démarrage du conteneur après application des migrations.

## Tests effectués
- Compilation syntaxique des fichiers Python.
- Tests unitaires du moteur de détection conservé.
- Vérification de l'archive ZIP et des fichiers historiques HTML.

## Limites restantes
- Le limiteur d'essais est en mémoire et ne coordonne pas plusieurs instances.
- MFA non implémentée.
- Aucun audit de sécurité indépendant ni déploiement de production réalisé.
- Le frontend HTML historique n'est toujours pas relié à l'API.
- Les scripts de sauvegarde/restauration doivent être testés sur une copie avant usage réel.
