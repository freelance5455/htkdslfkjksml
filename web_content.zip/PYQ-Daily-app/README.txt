PYQ Daily: installable app (PWA)
================================

What is in this folder
  index.html               the whole app
  manifest.webmanifest     name, colours and icons for installing
  sw.js                    service worker, makes it work offline after the first visit
  icon-*.png               app icons

Install on your phone
  1. Upload this folder to any static host that serves HTTPS, for example
     GitHub Pages, Netlify (drag and drop the folder), or Cloudflare Pages.
  2. Open the site's address on your phone.
  3. Android (Chrome): menu, then Install app.
     iPhone (Safari): Share, then Add to Home Screen.
  It then opens full screen like any other app and works offline.

Try it on a computer first
  Open a terminal in this folder and run:  python3 -m http.server 8000
  Then open http://localhost:8000 in Chrome or Edge.
  (Opening index.html by double-click also works, but without offline install.)

Your data
  Progress, history and imported questions are stored in the browser on the
  device you use. They are not synced between devices. Use Settings, then
  Export backup, to keep a copy, and Restore to bring it back.

Updating
  Replace index.html, then change VERSION in sw.js (for example to
  'pyq-daily-v3') so installed copies refresh.

Question bank
  The built-in 24 questions are original practice questions, not official papers.
  Load real PYQs from Settings, then Question bank, using JSON. The format, with
  year, shift, date and topic fields, is shown on that screen.
