# ChatOnline — Android Studio

هذا مشروع Android Studio مبني على ملفات ChatOnline الأصلية المرفوعة في المحادثة.

## ماذا يفعل؟
- يفتح ChatOnline داخل WebView Android بدلاً من Chrome.
- لا يعرض شريط عنوان Chrome أو أزرار المتصفح.
- يدعم JavaScript وFirebase وDOM Storage وملفات الرفع واختيار الملفات.
- يحافظ على موقع ChatOnline وFirebase كما هما.
- توجد نسخة الويب الأصلية داخل `app/src/main/assets/web/` كنسخة مرفقة داخل APK.

## الرابط المستخدم افتراضياً
`https://jolly-kitten-6cee38.netlify.app/`

يمكن تغييره في `MainActivity.java` عبر `REMOTE_URL`.

## البناء
1. افتح المجلد في Android Studio.
2. انتظر Sync/Gradle.
3. Build > Build APK(s).
4. ملف الاختبار سيكون في `app/build/outputs/apk/debug/`.

## ملاحظة مهمة
هذا المشروع يستخدم WebView للوصول إلى الموقع. إشعارات Firebase Web/Service Worker الموجودة في المشروع قد تحتاج طبقة Android Native FCM لاحقاً إذا أردت إشعارات Push موثوقة حتى عندما يكون التطبيق مغلقاً.

## التوقيع
للنشر في Google Play استخدم keystore خاصاً بك ولا تضعه داخل المشروع أو Git.
