# ChatOnline currently does not require custom R8 rules.
