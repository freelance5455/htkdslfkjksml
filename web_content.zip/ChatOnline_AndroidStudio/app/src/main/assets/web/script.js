
// @ts-nocheck
"use strict";

/*
=========================================================
 ChatOnline
 Firebase Authentication
 Cloud Firestore
 Realtime Database
 Online / Offline
 Typing
 Messages
 ✓ Sent
 ✓✓ Delivered
 ✓✓ Read
=========================================================
*/

const firebaseConfig = {
    apiKey: "AIzaSyC4BfwWPmRZ9uQejbUjyFNJmPsbYbBqfmE",
    authDomain: "chatonline-web.firebaseapp.com",
    databaseURL: "https://chatonline-web-default-rtdb.firebaseio.com",
    projectId: "chatonline-web",
    messagingSenderId: "969074888995",
    appId: "1:969074888995:web:6f14ec058d62a677fcbc96",
    measurementId: "G-PMJ0ZDNFX7"
};

/* =========================================================
   Profile Photo Upload - Cloudinary (Free unsigned upload)
   ضع Cloud Name و Upload Preset الخاصين بك هنا.
========================================================= */
const CLOUDINARY_CLOUD_NAME = "depleh68";
const CLOUDINARY_UPLOAD_PRESET = "chatonline_profiles";
const CLOUDINARY_AUDIO_UPLOAD_PRESET = "chatonline_audio";
const CLOUDINARY_FILE_UPLOAD_PRESET = "chatonline_files";

const FIREBASE_VERSION = "12.16.0";

/* =========================================================
   Firebase Cloud Messaging (FCM) — Real push notifications
   IMPORTANT: Replace the placeholder with the public VAPID key
   generated in Firebase Console > Project settings > Cloud Messaging.
========================================================= */
const FCM_VAPID_KEY = "BFTzxlAfQocmkYgsMXvFZI4BYPPyCLKcIWwQ-TR2n0B7Y8PbLp_NFtZIeOjVWuLqzuci-7z8ALpvGhnYNl70bog";
let fcmMessaging = null;
let fcmServiceWorkerRegistration = null;
let fcmToken = null;

let auth = null;
let db = null;
let rtdb = null;

let currentUser = null;
let activeChatUser = null;

let unsubscribeUsers = null;
let unsubscribeMessages = null;
let currentMessagesSnapshot = null;
let messageSearchQuery = "";

let connectedRef = null;
let myStatusRef = null;

let chatStatusRef = null;
let chatStatusListener = null;

let statusListeners = {};

let typingWriteRef = null;
let typingListenRef = null;
let typingListener = null;
let typingTimer = null;
let chatInfoStatusRef = null;
let chatInfoStatusListener = null;


/* =========================================================
   Browser + Firebase Cloud Messaging Notifications
========================================================= */
let unsubscribeChatNotifications = null;
let notificationBaselineReady = false;
let notificationSeen = {};
let notificationNameCache = {};

function getNotificationPermission() {
    return ("Notification" in window) ? Notification.permission : "unsupported";
}

function updateNotificationButton() {
    const btn = $("notificationBtn");
    if (!btn) return;
    const permission = getNotificationPermission();
    const fcmReady = !!fcmToken;
    if (permission === "granted" && fcmReady) {
        btn.textContent = "🔔";
        btn.classList.add("notifications-on");
        btn.classList.remove("notifications-off");
        btn.title = "الإشعارات الفعلية مفعّلة";
    } else {
        btn.textContent = "🔕";
        btn.classList.add("notifications-off");
        btn.classList.remove("notifications-on");
        btn.title = permission === "denied" ? "الإشعارات محظورة من المتصفح" : "تفعيل الإشعارات";
    }
}

function hasFCMConfiguration() {
    return !!FCM_VAPID_KEY && FCM_VAPID_KEY !== "PASTE_YOUR_PUBLIC_VAPID_KEY_HERE";
}

async function getNotificationTokenDocId(token) {
    if (window.crypto && crypto.subtle && typeof TextEncoder !== "undefined") {
        const data = new TextEncoder().encode(String(token));
        const digest = await crypto.subtle.digest("SHA-256", data);
        return Array.from(new Uint8Array(digest)).map(b => b.toString(16).padStart(2, "0")).join("");
    }
    return btoa(unescape(encodeURIComponent(String(token)))).replace(/[^a-zA-Z0-9_-]/g, "").slice(0, 120);
}

async function saveFCMToken(token) {
    if (!currentUser || !db || !token) return false;
    try {
        const tokenId = await getNotificationTokenDocId(token);
        await db.collection("users").doc(currentUser.uid)
            .collection("notificationTokens").doc(tokenId).set({
                token: token,
                platform: "web",
                userAgent: navigator.userAgent || "",
                updatedAt: firebase.firestore.FieldValue.serverTimestamp()
            }, { merge: true });
        return true;
    } catch (error) {
        console.error("FCM token save error:", error);
        return false;
    }
}

async function registerFCMServiceWorker() {
    if (!("serviceWorker" in navigator)) return null;
    try {
        return await navigator.serviceWorker.register("./firebase-messaging-sw.js", { scope: "./" });
    } catch (error) {
        console.error("FCM service worker registration error:", error);
        return null;
    }
}

async function initializeFCM() {
    if (!currentUser || !db) return false;
    if (!hasFCMConfiguration()) {
        updateNotificationButton();
        return false;
    }
    if (!("Notification" in window) || !("serviceWorker" in navigator)) return false;
    try {
        if (Notification.permission !== "granted") return false;
        fcmServiceWorkerRegistration = await registerFCMServiceWorker();
        if (!fcmServiceWorkerRegistration) return false;
        if (!window.firebase || typeof firebase.messaging !== "function") return false;
        fcmMessaging = fcmMessaging || firebase.messaging();
        fcmToken = await fcmMessaging.getToken({
            vapidKey: FCM_VAPID_KEY,
            serviceWorkerRegistration: fcmServiceWorkerRegistration
        });
        if (!fcmToken) return false;
        await saveFCMToken(fcmToken);

        if (!fcmMessaging.__chatOnlineBound) {
            fcmMessaging.__chatOnlineBound = true;
            fcmMessaging.onMessage(async function(payload) {
                // Foreground messages are already handled by the Firestore listener.
                // Keep this handler for FCM-only events and avoid duplicate popups.
                if (document.hidden) {
                    const data = payload && payload.data ? payload.data : {};
                    const title = data.title || (payload.notification && payload.notification.title) || "ChatOnline";
                    const body = data.body || (payload.notification && payload.notification.body) || "رسالة جديدة";
                    try {
                        const n = new Notification(title, { body, tag: data.chatId ? "chatonline-" + data.chatId : "chatonline-fcm", renotify: true });
                        n.onclick = function() { try { window.focus(); } catch (_) {} n.close(); };
                    } catch (error) { console.error("FCM foreground notification error:", error); }
                }
            });
        }
        updateNotificationButton();
        return true;
    } catch (error) {
        console.error("FCM initialization error:", error);
        updateNotificationButton();
        return false;
    }
}

async function enableBrowserNotifications() {
    if (!("Notification" in window)) {
        showMessage("هذا المتصفح لا يدعم إشعارات المتصفح.", "error");
        updateNotificationButton();
        return false;
    }
    if (Notification.permission === "denied") {
        showMessage("الإشعارات محظورة من إعدادات المتصفح. فعّلها من إعدادات الموقع.", "error");
        updateNotificationButton();
        return false;
    }
    try {
        const result = Notification.permission === "granted"
            ? "granted"
            : await Notification.requestPermission();
        if (result !== "granted") {
            showMessage("لم يتم السماح بالإشعارات.", "error");
            updateNotificationButton();
            return false;
        }
        if (!hasFCMConfiguration()) {
            showMessage("الإذن تم، لكن يلزم إضافة مفتاح VAPID من Firebase لتفعيل Push الحقيقي.", "info");
            updateNotificationButton();
            return false;
        }
        const ready = await initializeFCM();
        if (ready) {
            showMessage("تم تفعيل الإشعارات الفعلية 🔔", "success");
            return true;
        }
        showMessage("تعذر تجهيز إشعارات Push. تحقق من HTTPS وVAPID وFirebase Messaging.", "error");
        return false;
    } catch (error) {
        console.error("Notification permission error:", error);
        return false;
    }
}

function playMessageNotificationSound() {
    try {
        const AudioContextClass = window.AudioContext || window.webkitAudioContext;
        if (!AudioContextClass) return;
        const ctx = new AudioContextClass();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sine";
        osc.frequency.setValueAtTime(880, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(660, ctx.currentTime + 0.12);
        gain.gain.setValueAtTime(0.0001, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.08, ctx.currentTime + 0.01);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.18);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.2);
        setTimeout(() => { try { ctx.close(); } catch (_) {} }, 300);
    } catch (_) {}
}

function notificationPreview(lastMessage) {
    const text = String(lastMessage || "رسالة جديدة");
    return text.length > 90 ? text.slice(0, 87) + "…" : text;
}

async function getNotificationSenderName(uid) {
    uid = String(uid || "");
    if (!uid) return "رسالة جديدة";
    if (notificationNameCache[uid]) return notificationNameCache[uid];
    if (activeChatUser && String(activeChatUser.uid) === uid) {
        notificationNameCache[uid] = activeChatUser.name || "مستخدم";
        return notificationNameCache[uid];
    }
    try {
        const snap = await db.collection("users").doc(uid).get();
        const data = snap.exists ? (snap.data() || {}) : {};
        notificationNameCache[uid] = data.name || data.email || "مستخدم";
    } catch (_) {
        notificationNameCache[uid] = "مستخدم";
    }
    return notificationNameCache[uid];
}

async function showIncomingBrowserNotification(chat) {
    if (!currentUser || !chat || String(chat.lastMessageSenderId || "") === String(currentUser.uid)) return;
    if (getNotificationPermission() !== "granted") return;
    const senderId = String(chat.lastMessageSenderId || "");
    const isCurrentChat = activeChatUser && String(activeChatUser.uid) === senderId;
    const shouldNotify = document.hidden || !isCurrentChat;
    if (!shouldNotify) return;
    const name = await getNotificationSenderName(senderId);
    const body = notificationPreview(chat.lastMessage);
    playMessageNotificationSound();
    try {
        const n = new Notification("ChatOnline — " + name, {
            body,
            tag: "chatonline-" + chat.id,
            renotify: true
        });
        n.onclick = function () { try { window.focus(); } catch (_) {} n.close(); };
    } catch (error) {
        console.error("Browser notification error:", error);
    }
}

function startChatNotifications() {
    if (!currentUser || !db) return;
    if (unsubscribeChatNotifications) {
        unsubscribeChatNotifications();
        unsubscribeChatNotifications = null;
    }
    notificationBaselineReady = false;
    notificationSeen = {};
    unsubscribeChatNotifications = db.collection("chats")
        .where("participants", "array-contains", currentUser.uid)
        .onSnapshot(function (snapshot) {
            snapshot.forEach(function (doc) {
                const chat = doc.data() || {};
                const stamp = chat.lastMessageAt && typeof chat.lastMessageAt.toMillis === "function"
                    ? chat.lastMessageAt.toMillis()
                    : Number(chat.lastMessageAt || 0);
                const key = doc.id;
                const previous = notificationSeen[key];
                notificationSeen[key] = stamp;
                if (notificationBaselineReady && stamp && stamp !== previous && String(chat.lastMessageSenderId || "") !== String(currentUser.uid)) {
                    showIncomingBrowserNotification({ id: key, ...chat });
                }
            });
            notificationBaselineReady = true;
        }, function (error) {
            console.error("Chat notification listener error:", error);
        });
}

function setupBrowserNotifications() {
    updateNotificationButton();
    const btn = $("notificationBtn");
    if (btn && btn.dataset.bound !== "1") {
        btn.dataset.bound = "1";
        btn.addEventListener("click", enableBrowserNotifications);
    }
}

let mediaRecorder = null;
let voiceRecordingChunks = [];
let voiceRecordingStartedAt = 0;
let voiceRecordingTimer = null;
let voiceRecordingStream = null;
let pendingVoiceBlob = null;
let pendingChatFile = null;
let pendingChatFileObjectUrl = null;
let pendingReply = null;


/* =========================================================
   Helper
========================================================= */

function $(id) {
    return document.getElementById(id);
}


/* =========================================================
   Dynamic UI Elements
========================================================= */

function ensureAccountStatusElement() {

    if ($("accountOnlineStatus")) {
        return $("accountOnlineStatus");
    }

    const accountEmail = $("accountEmail");

    if (!accountEmail || !accountEmail.parentNode) {
        return null;
    }

    const element = document.createElement("div");

    element.id = "accountOnlineStatus";
    element.className = "account-online-status offline";
    element.innerHTML = "<span>●</span> غير متصل";

    accountEmail.parentNode.insertBefore(
        element,
        accountEmail.nextSibling
    );

    return element;
}


function ensureChatStatusElements() {

    if (!$("chatUserName")) {
        return;
    }

    let status = $("chatUserStatus");

    if (!status) {

        status = document.createElement("div");

        status.id = "chatUserStatus";
        status.className =
            "chat-user-status offline";

        status.innerHTML =
            "<span>●</span> غير متصل";

        const name = $("chatUserName");

        if (name.parentNode) {
            name.parentNode.insertBefore(
                status,
                name.nextSibling
            );
        }
    }

    let typing = $("typingStatus");

    if (!typing) {

        typing = document.createElement("div");

        typing.id = "typingStatus";
        typing.className =
            "typing-status hidden";

        typing.textContent =
            "يكتب الآن...";

        status.parentNode.insertBefore(
            typing,
            status.nextSibling
        );
    }
}


/* =========================================================
   Message Box
========================================================= */

function showMessage(text, type) {

    let box = $("messageBox");

    if (!box) {

        box = document.createElement("div");

        box.id = "messageBox";
        box.className = "message-box";

        document.body.appendChild(box);
    }

    box.textContent = text;

    box.className =
        "message-box " +
        (type || "info");

    box.classList.remove("hidden");

    clearTimeout(box._timer);

    box._timer = setTimeout(
        function() {

            box.classList.add("hidden");

        },
        4000
    );
}


/* =========================================================
   Page Navigation
========================================================= */

function showPage(pageId) {

    document
        .querySelectorAll(".page")
        .forEach(
            function(page) {

                page.classList.add(
                    "hidden"
                );

            }
        );

    const page = $(pageId);

    if (page) {

        page.classList.remove(
            "hidden"
        );
    }
}


/* =========================================================
   Header
========================================================= */

function updateHeader() {

    const loginButton =
        $("topLoginBtn");

    const logoutButton =
        $("logoutBtn");

    if (currentUser) {

        if (loginButton) {
            loginButton.classList.add(
                "hidden"
            );
        }

        if (logoutButton) {
            logoutButton.classList.remove(
                "hidden"
            );
        }

    } else {

        if (loginButton) {
            loginButton.classList.remove(
                "hidden"
            );
        }

        if (logoutButton) {
            logoutButton.classList.add(
                "hidden"
            );
        }
    }
}


/* =========================================================
   Chat ID
========================================================= */

function getChatId(user1, user2) {

    return [
        String(user1),
        String(user2)
    ]
        .sort()
        .join("_");
}


/* =========================================================
   Format Time
========================================================= */

function formatTime(value) {

    if (!value) {
        return "";
    }

    try {

        let date = null;

        if (
            value &&
            typeof value.toDate === "function"
        ) {

            date = value.toDate();

        } else if (
            value &&
            typeof value.seconds === "number"
        ) {

            date = new Date(
                value.seconds * 1000
            );

        } else if (
            value instanceof Date
        ) {

            date = value;

        } else {

            date = new Date(value);
        }

        if (
            !date ||
            isNaN(date.getTime())
        ) {
            return "";
        }

        return date.toLocaleTimeString(
            "ar-MA",
            {
                hour: "2-digit",
                minute: "2-digit"
            }
        );

    } catch (error) {

        console.error(
            "Time format error:",
            error
        );

        return "";
    }
}


/* =========================================================
   Message Status
========================================================= */

function getMessageStatus(message) {

    if (
        message &&
        message.read === true
    ) {
        return "read";
    }

    if (
        message &&
        message.delivered === true
    ) {
        return "delivered";
    }

    return "sent";
}


function createStatusElement(message) {

    const status =
        getMessageStatus(message);

    const element =
        document.createElement("span");

    element.className =
        "message-status " +
        status;

    if (
        status === "read" ||
        status === "delivered"
    ) {

        element.textContent = "✓✓";

    } else {

        element.textContent = "✓";
    }

    return element;
}


/* =========================================================
   Firebase SDK Loader
========================================================= */

function loadFirebaseDatabaseSDK() {

    return new Promise(
        function(resolve, reject) {

            if (
                window.firebase &&
                typeof firebase.database ===
                    "function"
            ) {

                resolve();
                return;
            }

            const src =
                "https://www.gstatic.com/firebasejs/" +
                FIREBASE_VERSION +
                "/firebase-database-compat.js";

            const existing =
                document.querySelector(
                    'script[src="' + src + '"]'
                );

            if (existing) {

                if (
                    window.firebase &&
                    typeof firebase.database ===
                        "function"
                ) {

                    resolve();
                    return;
                }

                existing.addEventListener(
                    "load",
                    function() {

                        if (
                            window.firebase &&
                            typeof firebase.database ===
                                "function"
                        ) {

                            resolve();

                        } else {

                            reject(
                                new Error(
                                    "Firebase Realtime Database لم يتم تحميله."
                                )
                            );
                        }

                    },
                    { once: true }
                );

                existing.addEventListener(
                    "error",
                    function() {

                        reject(
                            new Error(
                                "فشل تحميل Firebase Realtime Database."
                            )
                        );

                    },
                    { once: true }
                );

                return;
            }

            const script =
                document.createElement("script");

            script.src = src;
            script.async = true;

            script.onload =
                function() {

                    if (
                        window.firebase &&
                        typeof firebase.database ===
                            "function"
                    ) {

                        resolve();

                    } else {

                        reject(
                            new Error(
                                "Firebase Database غير متاح."
                            )
                        );
                    }
                };

            script.onerror =
                function() {

                    reject(
                        new Error(
                            "فشل تحميل Firebase Database."
                        )
                    );
                };

            document.head.appendChild(
                script
            );
        }
    );
}


/* =========================================================
   Initialize Firebase
========================================================= */

async function initializeFirebase() {

    try {

        if (!window.firebase) {

            throw new Error(
                "Firebase SDK غير موجود."
            );
        }

        if (!firebase.apps.length) {

            firebase.initializeApp(
                firebaseConfig
            );
        }

        auth =
            firebase.auth();

        db =
            firebase.firestore();

        /*
         * HTML الحالي لا يحتوي على
         * firebase-database-compat.js
         *
         * لذلك نحمله هنا تلقائيًا.
         */

        await loadFirebaseDatabaseSDK();

        rtdb =
            firebase.database();

        ensureAccountStatusElement();
        ensureChatStatusElements();

        console.log(
            "ChatOnline Firebase جاهز."
        );

        setupBrowserNotifications();
        setupAuthListener();

    } catch (error) {

        console.error(
            "Firebase initialization error:",
            error
        );

        showMessage(
            "تعذر تشغيل Firebase: " +
            (
                error.message ||
                "خطأ غير معروف"
            ),
            "error"
        );
    }
}


/* =========================================================
   Authentication
========================================================= */

function setupAuthListener() {

    if (!auth) {
        return;
    }

    auth.onAuthStateChanged(
        async function(user) {

            try {

                cleanupAll();

                currentUser =
                    user || null;

                if (currentUser) {
                    startChatNotifications();
                    // Silent initialization only if the user already granted notification permission.
                    if (getNotificationPermission() === "granted") initializeFCM();
                }

                updateHeader();

                if (!user) {

                    showPage(
                        "homePage"
                    );

                    return;
                }

                await loadCurrentUser();

                ensureAccountStatusElement();
                ensureChatStatusElements();

                showPage(
                    "accountPage"
                );

                setupPresence();

                loadUsers();

            } catch (error) {

                console.error(
                    "Auth state error:",
                    error
                );

                showMessage(
                    "حدث خطأ أثناء تحميل الحساب.",
                    "error"
                );
            }
        }
    );
}


/* =========================================================
   Create Account
========================================================= */

async function createAccount() {

    try {

        if (!auth || !db) {

            showMessage(
                "Firebase غير جاهزة بعد.",
                "error"
            );

            return;
        }

        const nameInput =
            $("registerName");

        const emailInput =
            $("registerEmail");

        const passwordInput =
            $("registerPassword");

        const password2Input =
            $("registerPassword2");

        if (
            !nameInput ||
            !emailInput ||
            !passwordInput ||
            !password2Input
        ) {

            showMessage(
                "حقول التسجيل غير موجودة.",
                "error"
            );

            return;
        }

        const name =
            nameInput.value.trim();

        const email =
            emailInput.value.trim();

        const password =
            passwordInput.value;

        const password2 =
            password2Input.value;

        if (!name) {

            showMessage(
                "اكتب اسم المستخدم.",
                "error"
            );

            return;
        }

        if (!email) {

            showMessage(
                "اكتب البريد الإلكتروني.",
                "error"
            );

            return;
        }

        if (password.length < 6) {

            showMessage(
                "كلمة المرور يجب أن تكون 6 أحرف على الأقل.",
                "error"
            );

            return;
        }

        if (password !== password2) {

            showMessage(
                "كلمتا المرور غير متطابقتين.",
                "error"
            );

            return;
        }

        showMessage(
            "جاري إنشاء الحساب...",
            "info"
        );

        const result =
            await auth
                .createUserWithEmailAndPassword(
                    email,
                    password
                );

        const user =
            result.user;

        if (!user) {

            throw new Error(
                "لم يتم إنشاء المستخدم."
            );
        }

        await db
            .collection("users")
            .doc(user.uid)
            .set({

                uid:
                    user.uid,

                name:
                    name,

                email:
                    email,

                createdAt:
                    firebase.firestore
                        .FieldValue
                        .serverTimestamp(),

                updatedAt:
                    firebase.firestore
                        .FieldValue
                        .serverTimestamp()

            });

        clearRegisterForm();

        showMessage(
            "تم إنشاء الحساب بنجاح ✅",
            "success"
        );

    } catch (error) {

        handleFirebaseError(
            error
        );
    }
}


/* =========================================================
   Login
========================================================= */

async function loginUser() {

    try {

        if (!auth) {

            showMessage(
                "Firebase غير جاهزة بعد.",
                "error"
            );

            return;
        }

        const emailInput =
            $("loginEmail");

        const passwordInput =
            $("loginPassword");

        if (
            !emailInput ||
            !passwordInput
        ) {

            showMessage(
                "حقول تسجيل الدخول غير موجودة.",
                "error"
            );

            return;
        }

        const email =
            emailInput.value.trim();

        const password =
            passwordInput.value;

        if (
            !email ||
            !password
        ) {

            showMessage(
                "أدخل البريد وكلمة المرور.",
                "error"
            );

            return;
        }

        showMessage(
            "جاري تسجيل الدخول...",
            "info"
        );

        await auth
            .signInWithEmailAndPassword(
                email,
                password
            );

        clearLoginForm();

        showMessage(
            "تم تسجيل الدخول بنجاح ✅",
            "success"
        );

    } catch (error) {

        handleFirebaseError(
            error
        );
    }
}


/* =========================================================
   Logout
========================================================= */

async function logoutUser() {

    try {

        if (!auth) {
            return;
        }

        await auth.signOut();

        showMessage(
            "تم تسجيل الخروج.",
            "success"
        );

    } catch (error) {

        console.error(
            "Logout error:",
            error
        );

        showMessage(
            "حدث خطأ أثناء تسجيل الخروج.",
            "error"
        );
    }
}


/* =========================================================
   Profile Photo - Cloudinary
========================================================= */

function setProfileAvatar(photoURL) {
    const avatar = $("profileAvatar");
    if (!avatar) return;

    const url = typeof photoURL === "string" ? photoURL.trim() : "";

    // Keep the real profile image independent from the selected app theme.
    // The theme only controls the avatar background when no image exists.
    avatar.style.backgroundImage = "";

    if (url) {
        avatar.classList.add("has-photo");
        avatar.textContent = "";

        let image = avatar.querySelector("img.profile-avatar-image");

        if (!image) {
            image = document.createElement("img");
            image.className = "profile-avatar-image";
            image.alt = "صورة الملف الشخصي";
            image.decoding = "async";
            image.loading = "eager";
            avatar.appendChild(image);
        }

        image.src = url;
        image.hidden = false;
    } else {
        avatar.classList.remove("has-photo");

        const image = avatar.querySelector("img.profile-avatar-image");
        if (image) {
            image.hidden = true;
            image.removeAttribute("src");
        }

        avatar.textContent = "👤";
    }
}

function setupProfilePhotoUpload() {
    const button = $("changeProfilePhotoBtn");
    const textButton = $("changeProfilePhotoTextBtn");
    const input = $("profilePhotoInput");
    if (!button || !input || button.dataset.bound === "1") return;

    button.dataset.bound = "1";

    const openPicker = function () {
        if (!currentUser) {
            showMessage("سجل الدخول أولاً.", "error");
            return;
        }
        input.click();
    };

    button.addEventListener("click", openPicker);
    if (textButton) textButton.addEventListener("click", openPicker);

    input.addEventListener("change", async function () {
        const file = input.files && input.files[0];
        input.value = "";
        if (!file) return;

        if (!/^image\/(jpeg|png|webp)$/.test(file.type)) {
            showMessage("اختر صورة JPG أو PNG أو WEBP.", "error");
            return;
        }

        if (file.size > 5 * 1024 * 1024) {
            showMessage("حجم الصورة يجب ألا يتجاوز 5MB.", "error");
            return;
        }

        if (CLOUDINARY_CLOUD_NAME === "YOUR_CLOUD_NAME" || CLOUDINARY_UPLOAD_PRESET === "YOUR_UNSIGNED_UPLOAD_PRESET") {
            showMessage("أضف Cloud Name و Upload Preset في script.js أولاً.", "error");
            return;
        }

        try {
            button.disabled = true;
            showMessage("جاري رفع صورة البروفايل...", "info");

            const formData = new FormData();
            formData.append("file", file);
            formData.append("upload_preset", CLOUDINARY_UPLOAD_PRESET);

            const response = await fetch(
                "https://api.cloudinary.com/v1_1/" +
                encodeURIComponent(CLOUDINARY_CLOUD_NAME) +
                "/image/upload",
                { method: "POST", body: formData }
            );

            const result = await response.json();
            if (!response.ok || !result.secure_url) {
                throw new Error(result.error && result.error.message ? result.error.message : "فشل رفع الصورة.");
            }

            const photoURL = result.secure_url;

            // Save the URL locally as a fast fallback and persist it in Firestore.
            localStorage.setItem("chatOnline.profilePhotoURL", photoURL);

            await db.collection("users").doc(currentUser.uid).set(
                {
                    photoURL: photoURL,
                    updatedAt: firebase.firestore.FieldValue.serverTimestamp()
                },
                { merge: true }
            );

            // Also keep Firebase Auth in sync when supported.
            if (
                currentUser &&
                typeof currentUser.updateProfile === "function"
            ) {
                try {
                    await currentUser.updateProfile({
                        photoURL: photoURL
                    });
                } catch (profileError) {
                    console.warn(
                        "Firebase Auth photoURL sync skipped:",
                        profileError
                    );
                }
            }

            setProfileAvatar(photoURL);
            showMessage("تم تغيير صورة البروفايل بنجاح ✅", "success");
        } catch (error) {
            console.error("Profile photo upload error:", error);
            showMessage("تعذر رفع صورة البروفايل: " + (error.message || "خطأ غير معروف"), "error");
        } finally {
            button.disabled = false;
        }
    });
}

/* =========================================================
   Current User
========================================================= */

async function loadCurrentUser() {

    if (
        !currentUser ||
        !db
    ) {
        return;
    }

    const snapshot =
        await db
            .collection("users")
            .doc(currentUser.uid)
            .get();

    const data =
        snapshot.exists
            ? snapshot.data()
            : {};

    const name =
        data.name ||
        currentUser.displayName ||
        currentUser.email ||
        "المستخدم";

    const email =
        data.email ||
        currentUser.email ||
        "";

    const photoURL =
        data.photoURL ||
        currentUser.photoURL ||
        localStorage.getItem("chatOnline.profilePhotoURL") ||
        "";

    if (photoURL) {
        localStorage.setItem(
            "chatOnline.profilePhotoURL",
            photoURL
        );
    }

    setProfileAvatar(photoURL);
    setupProfilePhotoUpload();

    if ($("accountName")) {

        $("accountName")
            .textContent =
            name;
    }

    if ($("accountEmail")) {

        $("accountEmail")
            .textContent =
            email;
    }

    if ($("profileName")) {

        $("profileName")
            .textContent =
            name;
    }

    if ($("profileEmail")) {

        $("profileEmail")
            .textContent =
            email;
    }

    ensureAccountStatusElement();
}


/* =========================================================
   Users
========================================================= */

function loadUsers() {

    if (
        !currentUser ||
        !db
    ) {
        return;
    }

    if (unsubscribeUsers) {

        unsubscribeUsers();

        unsubscribeUsers =
            null;
    }

    cleanupUserStatusListeners();

    unsubscribeUsers =
        db
            .collection("users")
            .orderBy("name")
            .onSnapshot(

                function(snapshot) {

                    const users = [];

                    snapshot.forEach(
                        function(
                            documentSnapshot
                        ) {

                            if (
                                documentSnapshot.id ===
                                currentUser.uid
                            ) {
                                return;
                            }

                            const data =
                                documentSnapshot.data();

                            users.push({

                                uid:
                                    documentSnapshot.id,

                                name:
                                                                 data.name ||
                                    "مستخدم",

                                email:
                                    data.email ||
                                    "",

                                photoURL:
                                    data.photoURL ||
                                    ""
                            });
                        }
                    );

                    renderUsers(
                        users
                    );
                },

                function(error) {

                    handleFirestoreError(
                        error,
                        "تعذر تحميل المستخدمين."
                    );
                }
            );
}


function renderUsers(users) {

    const list =
        $("usersList");

    if (!list) {
        return;
    }

    list.textContent = "";

    if (!users.length) {

        list.innerHTML =
            '<p class="empty">' +
            'لا يوجد مستخدمون آخرون حاليًا.' +
            '</p>';

        return;
    }

    users.forEach(
        function(user) {

            const card =
                document.createElement(
                    "div"
                );

            card.className =
                "user-card";

            card.dataset.uid =
                user.uid;

            const avatar =
                document.createElement(
                    "div"
                );

            avatar.className =
                "user-avatar";

            if (user.photoURL) {
                avatar.style.backgroundImage =
                    'url("' + String(user.photoURL).replace(/"/g, "&quot;") + '")';
                avatar.style.backgroundSize = "cover";
                avatar.style.backgroundPosition = "center";
                avatar.style.backgroundRepeat = "no-repeat";
                avatar.textContent = "";
            } else {
                avatar.textContent =
                    "👤";
            }

            const info =
                document.createElement(
                    "div"
                );

            info.className =
                "user-info";

            const name =
                document.createElement(
                    "h3"
                );

            name.textContent =
                user.name;

            const email =
                document.createElement(
                    "p"
                );

            email.textContent =
                user.email;

            const status =
                document.createElement(
                    "div"
                );

            status.className =
                "user-status offline";

            status.id =
                "user-status-" +
                user.uid;

            status.innerHTML =
                '<span class="status-dot offline-dot">' +
                '●' +
                '</span> غير متصل';

            info.appendChild(
                name
            );

            info.appendChild(
                email
            );

            info.appendChild(
                status
            );

            const actions = document.createElement("div");
            actions.className = "user-card-actions";

            const button = document.createElement("button");
            button.className = "primary-btn user-chat-btn";
            button.type = "button";
            button.textContent = "💬 محادثة";
            button.addEventListener("click", function(event) {
                event.preventDefault();
                event.stopPropagation();
                openChat(user);
            });

            const followButton = document.createElement("button");
            followButton.className = "follow-card-btn";
            followButton.type = "button";
            followButton.textContent = "＋ متابعة";
            followButton.title = "متابعة هذا الحساب";
            followButton.addEventListener("click", function(event) {
                event.preventDefault();
                event.stopPropagation();
                if (window.ChatOnlineFollow && typeof window.ChatOnlineFollow.openProfile === "function") {
                    window.ChatOnlineFollow.openProfile(user);
                }
            });

            actions.appendChild(button);
            actions.appendChild(followButton);

            [avatar, info].forEach(function(node) {
                node.style.cursor = "pointer";
                node.addEventListener("click", function(event) {
                    event.preventDefault();
                    event.stopPropagation();
                    if (window.ChatOnlineFollow && typeof window.ChatOnlineFollow.openProfile === "function") {
                        window.ChatOnlineFollow.openProfile(user);
                    }
                });
            });

            card.appendChild(avatar);
            card.appendChild(info);
            card.appendChild(actions);

            list.appendChild(
                card
            );

            watchUserStatus(
                user.uid,
                status
            );
        }
    );
}


/* =========================================================
   Search
========================================================= */

function searchUsers() {

    const input =
        $("userSearch");

    if (!input) {
        return;
    }

    const query =
        input.value
            .trim()
            .toLowerCase();

    document
        .querySelectorAll(
            ".user-card"
        )
        .forEach(
            function(card) {

                const text =
                    card.textContent
                        .toLowerCase();

                card.style.display =
                    !query ||
                    text.includes(
                        query
                    )
                        ? ""
                        : "none";
            }
        );
}


/* =========================================================
   User Online Status
========================================================= */

function watchUserStatus(
    uid,
    element
) {

    if (!rtdb) {
        return;
    }

    const ref =
        rtdb.ref(
            "status/" +
            uid
        );

    const listener =
        function(snapshot) {

            const data =
                snapshot.val() || {};

            const online =
                data.state ===
                "online";

            if (!element) {
                return;
            }

            element.className =
                "user-status " +
                (
                    online
                        ? "online"
                        : "offline"
                );

            if (online) {

                element.innerHTML =
                    '<span class="status-dot online-dot">' +
                    '●' +
                    '</span> متصل الآن';

            } else {

                element.innerHTML =
                    '<span class="status-dot offline-dot">' +
                    '●' +
                    '</span> غير متصل';
            }
        };

    ref.on(
        "value",
        listener
    );

    statusListeners[uid] = {
        ref:
            ref,
        listener:
            listener
    };
}


function cleanupUserStatusListeners() {

    Object
        .keys(statusListeners)
        .forEach(
            function(uid) {

                const item =
                    statusListeners[uid];

                if (
                    item &&
                    item.ref &&
                    item.listener
                ) {

                    item.ref.off(
                        "value",
                        item.listener
                    );
                }
            }
        );

    statusListeners = {};
}


/* =========================================================
   Presence
========================================================= */

function setupPresence() {

    if (
        !rtdb ||
        !currentUser
    ) {
        return;
    }

    ensureAccountStatusElement();

    connectedRef =
        rtdb.ref(
            ".info/connected"
        );

    myStatusRef =
        rtdb.ref(
            "status/" +
            currentUser.uid
        );

    connectedRef.on(
        "value",
        function(snapshot) {

            if (
                snapshot.val() !==
                true
            ) {
                return;
            }

            const onlineState = {

                state:
                    "online",

                lastSeen:
                    firebase.database
                        .ServerValue
                        .TIMESTAMP
            };

            const offlineState = {

                state:
                    "offline",

                lastSeen:
                    firebase.database
                        .ServerValue
                        .TIMESTAMP
            };

            myStatusRef
                .onDisconnect()
                .set(
                    offlineState
                )
                .then(
                    function() {

                        return myStatusRef
                            .set(
                                onlineState
                            );
                    }
                )
                .then(
                    function() {

                        setOwnStatusUI(
                            true
                        );
                    }
                )
                .catch(
                    function(error) {

                        console.error(
                            "Presence error:",
                            error
                        );
                    }
                );
        }
    );

    myStatusRef.on(
        "value",
        function(snapshot) {

            const data =
                snapshot.val() || {};

            setOwnStatusUI(
                data.state ===
                "online"
            );
        }
    );
}


function setOwnStatusUI(online) {

    const element =
        ensureAccountStatusElement();

    if (!element) {
        return;
    }

    element.className =
        "account-online-status " +
        (
            online
                ? "online"
                : "offline"
        );

    if (online) {

        element.innerHTML =
            "<span>●</span> متصل الآن";

    } else {

        element.innerHTML =
            "<span>●</span> غير متصل";
    }
}


function cleanupPresence() {

    try {

        if (connectedRef) {

            connectedRef.off();
        }

        if (myStatusRef) {

            myStatusRef
                .onDisconnect()
                .cancel();

            myStatusRef.off();
        }

    } catch (error) {

        console.error(
            "Presence cleanup error:",
            error
        );
    }

    connectedRef = null;
    myStatusRef = null;
}


/* =========================================================
   Profile
========================================================= */

function openProfile() {

    const profile =
        $("profileSection");

    const chat =
        $("chatSection");

    if (profile) {

        profile.classList.remove(
            "hidden"
        );
    }

    if (chat) {

        chat.classList.add(
            "hidden"
        );
    }

    loadOwnFollowStats();
}

async function loadOwnFollowStats() {
    const followersEl = $("profileFollowersCount");
    const followingEl = $("profileFollowingCount");
    if (!followersEl || !followingEl || !currentUser || !db) return;

    followersEl.textContent = "…";
    followingEl.textContent = "…";

    try {
        if (window.ChatOnlineFollow && typeof window.ChatOnlineFollow.getFollowStats === "function") {
            const stats = await window.ChatOnlineFollow.getFollowStats(currentUser.uid);
            followersEl.textContent = stats.followers === null ? "—" : String(stats.followers);
            followingEl.textContent = stats.following === null ? "—" : String(stats.following);
        } else {
            const [followersSnap, followingSnap] = await Promise.all([
                db.collection("follows").where("followingUid", "==", String(currentUser.uid)).get(),
                db.collection("follows").where("followerUid", "==", String(currentUser.uid)).get()
            ]);
            followersEl.textContent = String(followersSnap.size);
            followingEl.textContent = String(followingSnap.size);
        }
    } catch (error) {
        console.warn("Profile follow stats unavailable:", error);
        followersEl.textContent = "—";
        followingEl.textContent = "—";
    }
}


function closeProfile() {

    const profile =
        $("profileSection");

    if (profile) {

        profile.classList.add(
            "hidden"
        );
    }
}


/* =========================================================
   Open Chat
========================================================= */

async function ensureDirectChatDocument(user) {

    if (!currentUser || !user || !user.uid || !db) {
        throw new Error("بيانات المحادثة غير مكتملة.");
    }

    const chatId =
        getChatId(
            currentUser.uid,
            user.uid
        );

    const chatRef =
        db
            .collection("chats")
            .doc(chatId);

    /*
     * إنشاء مستند المحادثة عند أول فتح لها.
     * لا نغيّر قواعد Firestore؛ ننشئ المستند الذي تعتمد
     * عليه القواعد للتحقق من participants قبل قراءة messages.
     */
    await chatRef.set(
        {
            participants: [
                currentUser.uid,
                user.uid
            ],
            type: "direct",
            chatType: "direct"
        },
        { merge: true }
    );

    return chatRef;
}


async function openChat(user) {

    if (
        !currentUser ||
        !user ||
        !user.uid
    ) {
        return;
    }

    activeChatUser =
        user;

    closeChatUserInfo();
    setupChatUserInfo();
    ensureChatStatusElements();

    const profile =
        $("profileSection");

    const chat =
        $("chatSection");

    if (profile) {

        profile.classList.add(
            "hidden"
        );
    }

    if (chat) {

        chat.classList.remove(
            "hidden"
        );
    }

    document.body.classList.add("chat-view-open");

    if ($("chatUserName")) {

        $("chatUserName")
            .textContent =
            user.name ||
            "مستخدم";
    }

    setChatUserAvatar(user);
    clearPendingChatImage();

    ensureChatStatusElements();

    cleanupChatUserStatus();

    setupChatUserStatus(
        user.uid
    );

    cleanupTyping();

    setupTyping(
        user.uid
    );

    const input =
        $("messageInput");

    if (input) {

        input.value = "";

        setTimeout(
            function() {

                input.focus();

            },
            100
        );
    }

    try {
        await ensureDirectChatDocument(user);
        loadMessages();
    } catch (error) {
        console.error("Open chat error:", error);
        handleFirestoreError(
            error,
            "تعذر فتح المحادثة. حاول مرة أخرى."
        );
    }
}


/* =========================================================
   Close Chat
========================================================= */

function closeChat() {

    stopTyping();

    cleanupTyping();

    if (unsubscribeMessages) {

        unsubscribeMessages();

        unsubscribeMessages =
            null;
    }

    cleanupChatUserStatus();

    activeChatUser =
        null;

    const chat =
        $("chatSection");

    if (chat) {

        chat.classList.add(
            "hidden"
        );
    }

    document.body.classList.remove("chat-view-open");

    const messages =
        $("messagesContainer");

    if (messages) {

        messages.textContent =
            "";
    }
}


/* =========================================================
   Chat User Status
========================================================= */

function setupChatUserStatus(uid) {

    if (!rtdb) {
        return;
    }

    ensureChatStatusElements();

    chatStatusRef =
        rtdb.ref(
            "status/" +
            uid
        );

    chatStatusListener =
        function(snapshot) {

            const data =
                snapshot.val() || {};

            const online =
                data.state ===
                "online";

            const element =
                $("chatUserStatus");

            if (!element) {
                return;
            }

            element.className =
                "chat-user-status " +
                (
                    online
                        ? "online"
                        : "offline"
                );

            if (online) {

                element.innerHTML =
                    "<span>●</span> متصل الآن";

            } else {

                element.innerHTML =
                    "<span>●</span> غير متصل";
            }
        };

    chatStatusRef.on(
        "value",
        chatStatusListener
    );
}


function cleanupChatUserStatus() {

    if (
        chatStatusRef &&
        chatStatusListener
    ) {

        chatStatusRef.off(
            "value",
            chatStatusListener
        );
    }

    chatStatusRef = null;
    chatStatusListener = null;
}


/* =========================================================
   Typing
========================================================= */

function setupTyping(uid) {

    if (
        !rtdb ||
        !currentUser
    ) {
        return;
    }

    const chatId =
        getChatId(
            currentUser.uid,
            uid
        );

    typingWriteRef =
        rtdb.ref(
            "typing/" +
            chatId +
            "/" +
            currentUser.uid
        );

    typingListenRef =
        rtdb.ref(
            "typing/" +
            chatId +
            "/" +
            uid
        );

    typingListener =
        function(snapshot) {

            const element =
                $("typingStatus");

            if (!element) {
                return;
            }

            element.classList.toggle(
                "hidden",
                snapshot.val() !== true
            );
        };

    typingListenRef.on(
        "value",
        typingListener
    );
}


function startTyping() {

    if (!typingWriteRef) {
        return;
    }

    clearTimeout(
        typingTimer
    );

    typingWriteRef
        .set(true)
        .catch(
            console.error
        );

    typingTimer =
        setTimeout(
            stopTyping,
            1800
        );
}


function stopTyping() {

    clearTimeout(
        typingTimer
    );

    typingTimer =
        null;

    if (typingWriteRef) {

        typingWriteRef
            .set(false)
            .catch(
                function() {}
            );
    }
}


function cleanupTyping() {

    stopTyping();

    if (
        typingListenRef &&
        typingListener
    ) {

        typingListenRef.off(
            "value",
            typingListener
        );
    }

    typingWriteRef = null;
    typingListenRef = null;
    typingListener = null;

    const element =
        $("typingStatus");

    if (element) {

        element.classList.add(
            "hidden"
        );
    }
}


/* =========================================================
   Load Messages
========================================================= */

function loadMessages() {

    if (
        !currentUser ||
        !activeChatUser ||
        !db
    ) {
        return;
    }

    if (unsubscribeMessages) {

        unsubscribeMessages();

        unsubscribeMessages =
            null;
    }

    const chatId =
        getChatId(
            currentUser.uid,
            activeChatUser.uid
        );

    unsubscribeMessages =
        db
            .collection("chats")
            .doc(chatId)
            .collection("messages")
            .orderBy(
                "createdAt",
                "asc"
            )
            .onSnapshot(

                async function(snapshot) {

                    renderMessages(
                        snapshot
                    );

                    await updateIncomingStatuses(
                        snapshot
                    );
                },

                function(error) {

                    handleFirestoreError(
                        error,
                        "تعذر تحميل الرسائل."
                    );
                }
            );
}


/* =========================================================
   Chat User Info
========================================================= */

function formatLastSeenValue(value) {
    if (!value) return "غير متوفر";
    let time = value;
    if (typeof value === "object" && typeof value.toMillis === "function") time = value.toMillis();
    if (typeof value === "object" && typeof value.seconds === "number") time = value.seconds * 1000;
    const date = new Date(time);
    if (isNaN(date.getTime())) return "غير متوفر";
    return date.toLocaleString("ar-MA", { dateStyle: "medium", timeStyle: "short" });
}

function setChatInfoAvatar(user) {
    const avatar = $("chatInfoAvatar");
    if (!avatar) return;
    const url = user && user.photoURL ? String(user.photoURL) : "";
    if (url) {
        avatar.style.backgroundImage = 'url("' + url.replace(/"/g, "&quot;") + '")';
        avatar.style.backgroundSize = "cover";
        avatar.style.backgroundPosition = "center";
        avatar.textContent = "";
    } else {
        avatar.style.backgroundImage = "";
        avatar.textContent = ((user && user.name) || "مستخدم").trim().charAt(0).toUpperCase() || "👤";
    }
}

function updateChatInfoStatus(data) {
    const status = $("chatInfoStatus");
    const lastSeen = $("chatInfoLastSeen");
    if (!status) return;
    const online = data && data.state === "online";
    status.className = "chat-info-status " + (online ? "online" : "offline");
    status.innerHTML = online ? "<span>●</span> متصل الآن" : "<span>●</span> غير متصل";
    if (lastSeen && data && data.lastSeen) lastSeen.textContent = formatLastSeenValue(data.lastSeen);
}

function cleanupChatInfoStatus() {
    if (chatInfoStatusRef && chatInfoStatusListener) chatInfoStatusRef.off("value", chatInfoStatusListener);
    chatInfoStatusRef = null;
    chatInfoStatusListener = null;
}

function openChatUserInfo() {
    if (!activeChatUser) return;
    const modal = $("chatUserInfoModal");
    if (!modal) return;
    const title = $("chatUserInfoTitle");
    const email = $("chatInfoEmail");
    const photoBtn = $("chatInfoOpenPhotoBtn");
    const followBtn = $("chatInfoFollowBtn");
    if (title) title.textContent = activeChatUser.name || "مستخدم";
    if (email) email.textContent = activeChatUser.email || "غير متوفر";
    setChatInfoAvatar(activeChatUser);
    if (photoBtn) {
        photoBtn.classList.toggle("hidden", !activeChatUser.photoURL);
        photoBtn.onclick = function () { if (activeChatUser.photoURL) window.open(activeChatUser.photoURL, "_blank"); };
    }
    if (followBtn) {
        followBtn.classList.remove("hidden");
        followBtn.disabled = false;
        followBtn.textContent = "＋ متابعة";
        followBtn.classList.remove("is-following");
        if (window.ChatOnlineFollow && typeof window.ChatOnlineFollow.isFollowing === "function") {
            followBtn.disabled = true;
            followBtn.textContent = "جاري التحقق…";
            window.ChatOnlineFollow.isFollowing(activeChatUser.uid).then(function(following) {
                followBtn.disabled = false;
                followBtn.textContent = following ? "✓ متابَع" : "＋ متابعة";
                followBtn.classList.toggle("is-following", following);
            }).catch(function() {
                followBtn.disabled = false;
                followBtn.textContent = "＋ متابعة";
            });
            followBtn.onclick = function() {
                if (!window.ChatOnlineFollow || typeof window.ChatOnlineFollow.openProfile !== "function") return;
                window.ChatOnlineFollow.openProfile(activeChatUser);
            };
        } else {
            followBtn.classList.add("hidden");
        }
    }
    modal.classList.remove("hidden");
    cleanupChatInfoStatus();
    if (rtdb && activeChatUser.uid) {
        chatInfoStatusRef = rtdb.ref("status/" + activeChatUser.uid);
        chatInfoStatusListener = function(snapshot) { updateChatInfoStatus(snapshot.val() || {}); };
        chatInfoStatusRef.on("value", chatInfoStatusListener);
    } else {
        updateChatInfoStatus({});
    }
}

function closeChatUserInfo() {
    const modal = $("chatUserInfoModal");
    if (modal) modal.classList.add("hidden");
    cleanupChatInfoStatus();
}

function setupChatUserInfo() {
    const btn = $("chatUserHeaderBtn");
    if (btn && btn.dataset.bound !== "1") {
        btn.dataset.bound = "1";
        btn.addEventListener("click", openChatUserInfo);
    }
    const close = $("closeChatUserInfoBtn");
    if (close && close.dataset.bound !== "1") {
        close.dataset.bound = "1";
        close.addEventListener("click", closeChatUserInfo);
    }
    const backdrop = $("chatUserInfoBackdrop");
    if (backdrop && backdrop.dataset.bound !== "1") {
        backdrop.dataset.bound = "1";
        backdrop.addEventListener("click", closeChatUserInfo);
    }
}

/* =========================================================
   Chat Images - Cloudinary
========================================================= */

let pendingChatImage = null;
let pendingChatImageObjectUrl = null;

function setChatUserAvatar(user) {
    const avatar = $("chatUserAvatar");
    if (!avatar) return;

    const photoURL = user && user.photoURL ? String(user.photoURL) : "";
    if (photoURL) {
        avatar.style.backgroundImage = 'url("' + photoURL.replace(/"/g, "&quot;") + '")';
        avatar.style.backgroundSize = "cover";
        avatar.style.backgroundPosition = "center";
        avatar.style.backgroundRepeat = "no-repeat";
        avatar.textContent = "";
    } else {
        avatar.style.backgroundImage = "";
        avatar.textContent = ((user && user.name) || "مستخدم").trim().charAt(0).toUpperCase() || "👤";
    }
}

function clearPendingChatImage() {
    pendingChatImage = null;

    if (pendingChatImageObjectUrl) {
        URL.revokeObjectURL(pendingChatImageObjectUrl);
        pendingChatImageObjectUrl = null;
    }

    const bar = $("imagePreviewBar");
    const preview = $("imagePreview");
    const name = $("imagePreviewName");

    if (preview) preview.removeAttribute("src");
    if (name) name.textContent = "الصورة";
    if (bar) bar.classList.add("hidden");

    const input = $("chatImageInput");
    if (input) input.value = "";
}

function showPendingChatImage(file) {
    pendingChatImage = file;

    if (pendingChatImageObjectUrl) {
        URL.revokeObjectURL(pendingChatImageObjectUrl);
    }

    pendingChatImageObjectUrl = URL.createObjectURL(file);

    const bar = $("imagePreviewBar");
    const preview = $("imagePreview");
    const name = $("imagePreviewName");

    if (preview) preview.src = pendingChatImageObjectUrl;
    if (name) name.textContent = file.name || "الصورة";
    if (bar) bar.classList.remove("hidden");
}

async function uploadChatImage(file) {
    if (
        CLOUDINARY_CLOUD_NAME === "YOUR_CLOUD_NAME" ||
        CLOUDINARY_UPLOAD_PRESET === "YOUR_UNSIGNED_UPLOAD_PRESET"
    ) {
        throw new Error("أضف Cloud Name و Upload Preset في script.js أولاً.");
    }

    const formData = new FormData();
    formData.append("file", file);
    formData.append("upload_preset", CLOUDINARY_UPLOAD_PRESET);

    const response = await fetch(
        "https://api.cloudinary.com/v1_1/" +
        encodeURIComponent(CLOUDINARY_CLOUD_NAME) +
        "/image/upload",
        {
            method: "POST",
            body: formData
        }
    );

    const result = await response.json();

    if (!response.ok || !result.secure_url) {
        throw new Error(
            result.error && result.error.message
                ? result.error.message
                : "فشل رفع الصورة."
        );
    }

    return result.secure_url;
}

async function uploadChatFile(file) {
    if (
        CLOUDINARY_CLOUD_NAME === "YOUR_CLOUD_NAME" ||
        CLOUDINARY_FILE_UPLOAD_PRESET === "YOUR_FILE_UPLOAD_PRESET"
    ) {
        throw new Error("أضف Cloud Name و File Upload Preset في script.js أولاً.");
    }

    const formData = new FormData();
    formData.append("file", file, file.name || ("file-" + Date.now()));
    formData.append("upload_preset", CLOUDINARY_FILE_UPLOAD_PRESET);

    const response = await fetch(
        "https://api.cloudinary.com/v1_1/" +
        encodeURIComponent(CLOUDINARY_CLOUD_NAME) +
        "/raw/upload",
        { method: "POST", body: formData }
    );

    const result = await response.json();

    if (!response.ok || !result.secure_url) {
        throw new Error(
            result.error && result.error.message
                ? result.error.message
                : "فشل رفع الملف."
        );
    }

    return result.secure_url;
}

function clearPendingChatFile() {
    if (pendingChatFileObjectUrl) {
        URL.revokeObjectURL(pendingChatFileObjectUrl);
        pendingChatFileObjectUrl = null;
    }

    pendingChatFile = null;
    const bar = $("filePreviewBar");
    const name = $("filePreviewName");
    const size = $("filePreviewSize");
    if (name) name.textContent = "ملف";
    if (size) size.textContent = "";
    if (bar) bar.classList.add("hidden");
    const input = $("chatFileInput");
    if (input) input.value = "";
}

function formatFileSize(bytes) {
    if (!bytes || bytes < 1024) return (bytes || 0) + " B";
    const units = ["KB", "MB", "GB"];
    let value = bytes / 1024;
    let unit = units[0];
    for (let i = 0; i < units.length - 1 && value >= 1024; i++) {
        value /= 1024;
        unit = units[i + 1];
    }
    return value.toFixed(value >= 10 ? 0 : 1) + " " + unit;
}

function showPendingChatFile(file) {
    pendingChatFile = file;
    const bar = $("filePreviewBar");
    const name = $("filePreviewName");
    const size = $("filePreviewSize");
    if (name) name.textContent = file.name || "ملف";
    if (size) size.textContent = formatFileSize(file.size);
    if (bar) bar.classList.remove("hidden");
}

function setupChatFileUpload() {
    const button = $("fileSendBtn");
    const input = $("chatFileInput");
    const remove = $("removeFilePreviewBtn");
    if (!button || !input || button.dataset.bound === "1") return;
    button.dataset.bound = "1";

    button.addEventListener("click", function () {
        if (!currentUser || !activeChatUser) {
            showMessage("افتح محادثة أولًا.", "error");
            return;
        }
        input.click();
    });

    input.addEventListener("change", function () {
        const file = input.files && input.files[0];
        if (!file) return;

        const maxSize = 20 * 1024 * 1024;
        const allowed = /^(application\/pdf|application\/zip|application\/x-zip-compressed|application\/msword|application\/vnd\.openxmlformats-officedocument\.(wordprocessingml\.document|spreadsheetml\.sheet|presentationml\.presentation)|application\/vnd\.ms-excel|application\/vnd\.ms-powerpoint|text\/plain|text\/csv)$/i.test(file.type) || /\.(pdf|zip|doc|docx|xls|xlsx|ppt|pptx|txt|csv)$/i.test(file.name || "");

        if (!allowed) {
            clearPendingChatFile();
            showMessage("هذا النوع من الملفات غير مدعوم. استخدم PDF أو Word أو Excel أو PowerPoint أو TXT أو CSV أو ZIP.", "error");
            return;
        }

        if (file.size > maxSize) {
            clearPendingChatFile();
            showMessage("حجم الملف يجب ألا يتجاوز 20MB.", "error");
            return;
        }

        showPendingChatFile(file);
    });

    if (remove) remove.addEventListener("click", clearPendingChatFile);
}

function appendFileMessage(wrapper, message) {
    if (!message.fileUrl) return false;

    const card = document.createElement("a");
    card.className = "message-file-card";
    card.href = String(message.fileUrl);
    card.target = "_blank";
    card.rel = "noopener noreferrer";
    card.download = message.fileName || "";

    const icon = document.createElement("span");
    icon.className = "message-file-icon";
    icon.textContent = "📎";

    const info = document.createElement("span");
    info.className = "message-file-info";

    const name = document.createElement("strong");
    name.textContent = message.fileName || "ملف مرفق";

    const meta = document.createElement("small");
    meta.textContent = message.fileSize ? formatFileSize(Number(message.fileSize)) : "ملف";

    info.appendChild(name);
    info.appendChild(meta);
    card.appendChild(icon);
    card.appendChild(info);
    wrapper.appendChild(card);
    return true;
}

async function uploadVoiceMessage(blob) {
    if (CLOUDINARY_CLOUD_NAME === "YOUR_CLOUD_NAME" || CLOUDINARY_AUDIO_UPLOAD_PRESET === "YOUR_AUDIO_UPLOAD_PRESET") {
        throw new Error("أضف Cloud Name و Audio Upload Preset في script.js أولاً.");
    }
    const formData = new FormData();
    const extension = blob.type && blob.type.includes("ogg") ? "ogg" : (blob.type && blob.type.includes("mp4") ? "m4a" : "webm");
    formData.append("file", blob, "voice-" + Date.now() + "." + extension);
    formData.append("upload_preset", CLOUDINARY_AUDIO_UPLOAD_PRESET);
    const response = await fetch("https://api.cloudinary.com/v1_1/" + encodeURIComponent(CLOUDINARY_CLOUD_NAME) + "/video/upload", { method: "POST", body: formData });
    const result = await response.json();
    if (!response.ok || !result.secure_url) throw new Error(result.error && result.error.message ? result.error.message : "فشل رفع الرسالة الصوتية.");
    return result.secure_url;
}
function formatRecordingTime(seconds) { const m=Math.floor(seconds/60).toString().padStart(2,"0"); const s=Math.floor(seconds%60).toString().padStart(2,"0"); return m+":"+s; }
function stopVoiceStream(){ if(voiceRecordingStream){voiceRecordingStream.getTracks().forEach(t=>t.stop());voiceRecordingStream=null;} }
function resetVoiceRecordingUI(){ if(voiceRecordingTimer){clearInterval(voiceRecordingTimer);voiceRecordingTimer=null;} stopVoiceStream();mediaRecorder=null;voiceRecordingChunks=[];voiceRecordingStartedAt=0;pendingVoiceBlob=null;const b=$("voiceRecordingBar");if(b)b.classList.add("hidden");const t=$("voiceRecordingTime");if(t)t.textContent="00:00";const btn=$("voiceMessageBtn");if(btn){btn.classList.remove("recording");btn.textContent="🎤";}}
function cancelVoiceRecording(){ if(mediaRecorder&&mediaRecorder.state!=="inactive"){try{mediaRecorder.stop();}catch(e){}} resetVoiceRecordingUI(); }
async function startVoiceRecording(){
    if(!currentUser||!activeChatUser||!db){showMessage("افتح محادثة أولًا.","error");return;}
    if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia||typeof MediaRecorder==="undefined"){showMessage("التسجيل الصوتي غير مدعوم في هذا المتصفح.","error");return;}
    try{
        resetVoiceRecordingUI(); voiceRecordingStream=await navigator.mediaDevices.getUserMedia({audio:true});
        const candidates=["audio/webm;codecs=opus","audio/webm","audio/ogg;codecs=opus","audio/mp4"]; const mime=candidates.find(x=>MediaRecorder.isTypeSupported(x))||"";
        mediaRecorder=mime?new MediaRecorder(voiceRecordingStream,{mimeType:mime}):new MediaRecorder(voiceRecordingStream); voiceRecordingChunks=[];
        mediaRecorder.ondataavailable=e=>{if(e.data&&e.data.size)voiceRecordingChunks.push(e.data);};
        mediaRecorder.onstop=()=>{const type=mediaRecorder&&mediaRecorder.mimeType?mediaRecorder.mimeType:(mime||"audio/webm");pendingVoiceBlob=voiceRecordingChunks.length?new Blob(voiceRecordingChunks,{type}):null;stopVoiceStream();};
        mediaRecorder.start(); voiceRecordingStartedAt=Date.now(); const bar=$("voiceRecordingBar");if(bar)bar.classList.remove("hidden");const btn=$("voiceMessageBtn");if(btn){btn.classList.add("recording");btn.textContent="⏹️";}
        voiceRecordingTimer=setInterval(()=>{const elapsed=Math.floor((Date.now()-voiceRecordingStartedAt)/1000);const t=$("voiceRecordingTime");if(t)t.textContent=formatRecordingTime(elapsed);if(elapsed>=120)stopVoiceRecording(true);},250);
    }catch(e){console.error("Voice recording error:",e);resetVoiceRecordingUI();showMessage("تعذر تشغيل الميكروفون. اسمح بالوصول إلى الميكروفون ثم حاول مرة أخرى.","error");}
}
async function stopVoiceRecording(sendAfterStop){
    if(!mediaRecorder)return; const recorder=mediaRecorder; if(recorder.state!=="inactive")recorder.stop(); if(voiceRecordingTimer){clearInterval(voiceRecordingTimer);voiceRecordingTimer=null;} stopVoiceStream(); const btn=$("voiceMessageBtn");if(btn){btn.classList.remove("recording");btn.textContent="🎤";}const bar=$("voiceRecordingBar");if(bar)bar.classList.add("hidden");
    if(sendAfterStop){await new Promise(r=>setTimeout(r,80));if(pendingVoiceBlob)await sendVoiceMessage(pendingVoiceBlob);} resetVoiceRecordingUI();
}
async function sendVoiceMessage(blob){
    if(!currentUser||!activeChatUser||!db||!blob)return; if(blob.size>15*1024*1024){showMessage("الرسالة الصوتية كبيرة جدًا. الحد الأقصى 15MB.","error");return;}
    const btn=$("voiceMessageBtn");if(btn)btn.disabled=true;
    try{showMessage("جاري رفع الرسالة الصوتية...","info");const audioUrl=await uploadVoiceMessage(blob);const chatId=getChatId(currentUser.uid,activeChatUser.uid);const now=firebase.firestore.Timestamp.now();const chatRef=db.collection("chats").doc(chatId);const messageRef=chatRef.collection("messages").doc();const batch=db.batch();batch.set(chatRef,{participants:[currentUser.uid,activeChatUser.uid],type:"direct",chatType:"direct",lastMessage:"🎤 رسالة صوتية",lastMessageAt:now,updatedAt:now,lastMessageSenderId:currentUser.uid,[`unreadCounts.${currentUser.uid}`]:0,[`unreadCounts.${activeChatUser.uid}`]:firebase.firestore.FieldValue.increment(1)},{merge:true});batch.set(messageRef,{senderId:currentUser.uid,receiverId:activeChatUser.uid,text:"",type:"audio",audioUrl:audioUrl,delivered:false,read:false,createdAt:now,createdAtClient:now});await batch.commit();}catch(e){console.error("Send voice message error:",e);handleFirebaseError(e);}finally{if(btn)btn.disabled=false;}
}
function setupVoiceMessageUI(){const btn=$("voiceMessageBtn");const cancel=$("cancelVoiceRecordingBtn");if(!btn||btn.dataset.bound==="1")return;btn.dataset.bound="1";btn.addEventListener("click",async()=>{if(mediaRecorder&&mediaRecorder.state!=="inactive")await stopVoiceRecording(true);else await startVoiceRecording();});if(cancel)cancel.addEventListener("click",cancelVoiceRecording);}

function setupVoiceCallUI() {
    const button = $("voiceCallBtn");
    const endButton = $("endCallBtn");
    const panel = $("callPanel");
    const name = $("callPanelName");
    const status = $("callPanelStatus");
    const avatar = $("callPanelAvatar");

    if (button && button.dataset.bound !== "1") {
        button.dataset.bound = "1";
        button.addEventListener("click", async function () {
            if (!currentUser || !activeChatUser) {
                showMessage("افتح محادثة أولًا.", "error");
                return;
            }

            if (panel) panel.classList.remove("hidden");
            if (name) name.textContent = activeChatUser.name || "مستخدم";
            if (status) status.textContent = "جاري الاتصال...";
            if (avatar) {
                const photo = activeChatUser.photoURL || "";
                if (photo) {
                    avatar.style.backgroundImage = 'url("' + String(photo).replace(/"/g, "&quot;") + '")';
                    avatar.style.backgroundSize = "cover";
                    avatar.style.backgroundPosition = "center";
                    avatar.textContent = "";
                } else {
                    avatar.style.backgroundImage = "";
                    avatar.textContent = String(activeChatUser.name || "مستخدم").trim().charAt(0).toUpperCase() || "👤";
                }
            }

            // Microphone permission makes the control functional while the full WebRTC signaling is added later.
            try {
                if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
                    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                    stream.getTracks().forEach(track => track.stop());
                    if (status) status.textContent = "تم تجهيز الميكروفون — في انتظار الطرف الآخر";
                } else if (status) {
                    status.textContent = "المكالمات الصوتية غير مدعومة في هذا المتصفح";
                }
            } catch (error) {
                console.warn("Microphone permission:", error);
                if (status) status.textContent = "لم يتم السماح بالميكروفون";
            }
        });
    }

    if (endButton && endButton.dataset.bound !== "1") {
        endButton.dataset.bound = "1";
        endButton.addEventListener("click", function () {
            if (panel) panel.classList.add("hidden");
        });
    }

    const more = $("chatMoreBtn");
    if (more && more.dataset.bound !== "1") {
        more.dataset.bound = "1";
        more.addEventListener("click", function () {
            showMessage("يمكنك إرسال الصور أو بدء مكالمة من أعلى المحادثة.", "info");
        });
    }
}

function setupChatImageUpload() {
    const button = $("imageSendBtn");
    const input = $("chatImageInput");
    const remove = $("removeImagePreviewBtn");

    if (!button || !input || button.dataset.bound === "1") return;
    button.dataset.bound = "1";

    button.addEventListener("click", function () {
        if (!currentUser || !activeChatUser) {
            showMessage("افتح محادثة أولًا.", "error");
            return;
        }
        input.click();
    });

    input.addEventListener("change", function () {
        const file = input.files && input.files[0];
        if (!file) return;

        if (!/^image\/(jpeg|png|webp)$/.test(file.type)) {
            clearPendingChatImage();
            showMessage("اختر صورة JPG أو PNG أو WEBP.", "error");
            return;
        }

        if (file.size > 5 * 1024 * 1024) {
            clearPendingChatImage();
            showMessage("حجم الصورة يجب ألا يتجاوز 5MB.", "error");
            return;
        }

        showPendingChatImage(file);
    });

    if (remove) {
        remove.addEventListener("click", clearPendingChatImage);
    }
}

function appendImageMessage(wrapper, message) {
    if (!message.imageUrl) return false;

    const link = document.createElement("a");
    link.className = "message-image-link";
    link.href = String(message.imageUrl);
    link.target = "_blank";
    link.rel = "noopener noreferrer";

    const image = document.createElement("img");
    image.className = "message-image";
    image.src = String(message.imageUrl);
    image.alt = "صورة مرسلة";
    image.loading = "lazy";
    image.referrerPolicy = "no-referrer";

    link.appendChild(image);
    wrapper.appendChild(link);
    return true;
}

/* =========================================================
   Delete Message
   يحذف الرسالة من Firestore، لذلك تختفي من الطرفين.
========================================================= */
function getMessagePreviewText(message) {
    const text = message && typeof message.text === "string"
        ? message.text.trim()
        : "";

    if (message && message.fileUrl) {
        return text ? "📎 " + text : "📎 " + (message.fileName || "ملف");
    }

    if (message && message.imageUrl) {
        return text ? "📷 " + text : "📷 صورة";
    }

    if (message && message.audioUrl) {
        return "🎤 رسالة صوتية";
    }

    return text || "";
}

async function refreshChatLastMessage(chatId) {
    if (!db || !chatId) return;

    const chatRef = db.collection("chats").doc(chatId);
    const latest = await chatRef.collection("messages")
        .orderBy("createdAt", "desc")
        .limit(1)
        .get();

    if (latest.empty) {
        await chatRef.set({
            lastMessage: "",
            lastMessageAt: null,
            lastMessageSenderId: "",
            updatedAt: firebase.firestore.Timestamp.now()
        }, { merge: true });
        return;
    }

    const doc = latest.docs[0];
    const message = doc.data();

    await chatRef.set({
        lastMessage: getMessagePreviewText(message),
        lastMessageAt: message.createdAt || firebase.firestore.Timestamp.now(),
        lastMessageSenderId: message.senderId || "",
        updatedAt: firebase.firestore.Timestamp.now()
    }, { merge: true });
}

async function deleteMessage(messageId, message) {
    if (!currentUser || !activeChatUser || !db || !messageId) return;

    if (!message || message.senderId !== currentUser.uid) {
        showMessage("يمكنك حذف رسائلك فقط.", "error");
        return;
    }

    const confirmed = window.confirm("هل تريد حذف هذه الرسالة؟\\nستختفي من المحادثة عندك وعند الطرف الآخر.");
    if (!confirmed) return;

    try {
        const chatId = getChatId(currentUser.uid, activeChatUser.uid);
        const messageRef = db.collection("chats").doc(chatId)
            .collection("messages").doc(messageId);

        await messageRef.delete();
        await refreshChatLastMessage(chatId);
        showMessage("تم حذف الرسالة.", "success");
    } catch (error) {
        console.error("Delete message error:", error);
        handleFirebaseError(error, "تعذر حذف الرسالة.");
    }
}

function createMessageActionButton(className, title, label, onClick) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = className;
    button.title = title;
    button.setAttribute("aria-label", title);
    button.textContent = label;
    button.addEventListener("click", function (event) {
        event.preventDefault();
        event.stopPropagation();
        onClick(event);
    });
    return button;
}

function createDeleteMessageButton(messageId, message) {
    return createMessageActionButton(
        "delete-message-btn",
        "حذف الرسالة",
        "🗑️",
        function () {
            deleteMessage(messageId, message);
        }
    );
}

async function editMessage(messageId, message) {
    if (!currentUser || !activeChatUser || !db || !messageId) return;

    if (!message || message.senderId !== currentUser.uid) {
        showMessage("يمكنك تعديل رسائلك فقط.", "error");
        return;
    }

    const isPlainText =
        !message.imageUrl &&
        !message.audioUrl &&
        !message.fileUrl &&
        typeof message.text === "string";

    if (!isPlainText) {
        showMessage("يمكن تعديل الرسائل النصية فقط.", "error");
        return;
    }

    const currentText = message.text.trim();
    const editedText = window.prompt("عدّل رسالتك:", currentText);

    if (editedText === null) return;

    const nextText = editedText.trim();

    if (!nextText) {
        showMessage("لا يمكن أن تكون الرسالة فارغة.", "error");
        return;
    }

    if (nextText.length > 2000) {
        showMessage("الرسالة طويلة جدًا. الحد الأقصى 2000 حرف.", "error");
        return;
    }

    if (nextText === currentText) return;

    try {
        const chatId = getChatId(currentUser.uid, activeChatUser.uid);
        const messageRef = db.collection("chats").doc(chatId)
            .collection("messages").doc(messageId);

        await messageRef.update({
            text: nextText,
            edited: true,
            editedAt: firebase.firestore.Timestamp.now()
        });

        await refreshChatLastMessage(chatId);
        showMessage("تم تعديل الرسالة.", "success");
    } catch (error) {
        console.error("Edit message error:", error);
        handleFirebaseError(error, "تعذر تعديل الرسالة.");
    }
}

function createEditMessageButton(messageId, message) {
    return createMessageActionButton(
        "edit-message-btn",
        "تعديل الرسالة",
        "✏️",
        function () {
            editMessage(messageId, message);
        }
    );
}

function getReplyPreviewText(message) {
    if (!message) return "رسالة";
    const text = typeof message.text === "string" ? message.text.trim() : "";
    if (message.imageUrl) return text ? "📷 " + text : "📷 صورة";
    if (message.audioUrl) return "🎤 رسالة صوتية";
    if (message.fileUrl) return "📎 " + (message.fileName || "ملف");
    return text || "رسالة";
}

function clearPendingReply() {
    pendingReply = null;
    const bar = $("replyPreviewBar");
    if (bar) bar.classList.add("hidden");
    const text = $("replyPreviewText");
    if (text) text.textContent = "رسالة";
}

function setPendingReply(messageId, message) {
    if (!messageId || !message) return;
    pendingReply = {
        messageId: String(messageId),
        senderId: String(message.senderId || ""),
        senderName: message.senderName || (message.senderId === currentUser.uid ? "أنت" : (activeChatUser && activeChatUser.name) || "مستخدم"),
        text: getReplyPreviewText(message)
    };
    const bar = $("replyPreviewBar");
    const title = $("replyPreviewTitle");
    const text = $("replyPreviewText");
    if (title) title.textContent = "الرد على " + pendingReply.senderName;
    if (text) text.textContent = pendingReply.text;
    if (bar) bar.classList.remove("hidden");
    const input = $("messageInput");
    if (input) input.focus();
}

function createReplyMessageButton(messageId, message) {
    return createMessageActionButton(
        "reply-message-btn",
        "الرد على الرسالة",
        "↩️",
        function () { setPendingReply(messageId, message); }
    );
}

function appendReplyQuote(wrapper, message) {
    if (!message || !message.replyTo) return;
    const quote = document.createElement("div");
    quote.className = "message-reply-quote";
    const name = document.createElement("strong");
    name.textContent = message.replyTo.senderName || "مستخدم";
    const text = document.createElement("span");
    text.textContent = message.replyTo.text || "رسالة";
    quote.appendChild(name);
    quote.appendChild(text);
    wrapper.appendChild(quote);
}

function createMessageActions(messageId, message) {
    const actions = document.createElement("div");
    actions.className = "message-actions";

    actions.appendChild(createReplyMessageButton(messageId, message));

    const canEdit =
        message &&
        message.senderId === currentUser.uid &&
        !message.imageUrl &&
        !message.audioUrl &&
        !message.fileUrl &&
        typeof message.text === "string" &&
        message.text.trim();

    if (canEdit) actions.appendChild(createEditMessageButton(messageId, message));
    if (message.senderId === currentUser.uid) actions.appendChild(createDeleteMessageButton(messageId, message));
    return actions;
}

/* =========================================================
   Render Messages
========================================================= */

function appendAudioMessage(wrapper, message) {
    if (!message.audioUrl) return false;
    const audio = document.createElement("audio");
    audio.className = "message-audio";
    audio.controls = true;
    audio.preload = "metadata";
    audio.src = String(message.audioUrl);
    audio.setAttribute("aria-label", "رسالة صوتية");
    wrapper.appendChild(audio);
    return true;
}

function getSearchableMessageText(message) {
    if (!message) return "";
    const parts = [
        message.text,
        message.fileName,
        message.fileType,
        message.replyTo && message.replyTo.text,
        message.replyTo && message.replyTo.fileName
    ];
    if (message.imageUrl) parts.push("صورة image photo");
    if (message.audioUrl) parts.push("صوت رسالة صوتية audio voice");
    if (message.fileUrl) parts.push("ملف file");
    return parts.filter(Boolean).join(" ").toLocaleLowerCase("ar");
}

function applyMessageSearch(snapshot) {
    const query = String(messageSearchQuery || "").trim().toLocaleLowerCase("ar");
    if (!query) return snapshot;
    const terms = query.split(/\s+/).filter(Boolean);
    const docs = snapshot.docs.filter(function(doc) {
        const text = getSearchableMessageText(doc.data());
        return terms.every(function(term) { return text.includes(term); });
    });
    return { empty: docs.length === 0, docs: docs, forEach: function(cb) { docs.forEach(cb); } };
}

function updateMessageSearchCount(total, visible, active) {
    const el = $("messageSearchCount");
    if (!el) return;
    if (!active) { el.textContent = ""; return; }
    el.textContent = visible ? (visible + " / " + total) : "لا توجد نتائج";
}

function renderMessages(snapshot) {

    currentMessagesSnapshot = snapshot;
    const filteredSnapshot = applyMessageSearch(snapshot);

    const container =
        $("messagesContainer");

    if (!container) {
        return;
    }

    container.textContent =
        "";

    if (filteredSnapshot.empty) {
        container.innerHTML = messageSearchQuery
            ? '<div class="empty">لا توجد رسائل مطابقة 🔍</div>'
            : '<div class="empty">ابدأ المحادثة الآن 💬</div>';
        updateMessageSearchCount(snapshot.size || snapshot.docs.length || 0, 0, !!messageSearchQuery);
        return;
    }

    updateMessageSearchCount(snapshot.size || snapshot.docs.length || 0, filteredSnapshot.docs.length, !!messageSearchQuery);

    filteredSnapshot.forEach(
        function(documentSnapshot) {

            const message =
                documentSnapshot.data();

            const messageId = documentSnapshot.id;

            const mine =
                message.senderId ===
                currentUser.uid;

            const wrapper =
                document.createElement(
                    "div"
                );

            wrapper.className =
                "message " +
                (
                    mine
                        ? "mine"
                        : "other"
                );

            appendReplyQuote(wrapper, message);

            const hasImage =
                appendImageMessage(
                    wrapper,
                    message
                );

            const hasAudio =
                appendAudioMessage(
                    wrapper,
                    message
                );

            const hasFile =
                appendFileMessage(
                    wrapper,
                    message
                );

            if (message.text && message.text.trim()) {
                const text =
                    document.createElement(
                        "div"
                    );

                text.className =
                    "message-text";

                text.textContent =
                    message.text;

                wrapper.appendChild(text);

                if (message.edited === true) {
                    const editedLabel = document.createElement("span");
                    editedLabel.className = "message-edited-label";
                    editedLabel.textContent = "(تم التعديل)";
                    wrapper.appendChild(editedLabel);
                }
            } else if (!hasImage && !hasAudio && !hasFile) {
                const text =
                    document.createElement(
                        "div"
                    );

                text.className =
                    "message-text";

                text.textContent = "";
                wrapper.appendChild(text);
            }

            const meta =
                document.createElement(
                    "div"
                );

            meta.className =
                "message-meta";

            const time =
                document.createElement(
                    "span"
                );

            time.className =
                "message-time";

            /*
             * createdAt يتم تخزينه الآن
             * كـ Timestamp.now()
             * لذلك الوقت يظهر فورًا.
             */

            time.textContent =
                formatTime(
                    message.createdAt
                );

            meta.appendChild(
                time
            );

            if (mine) {

                meta.appendChild(
                    createStatusElement(
                        message
                    )
                );
            }

            wrapper.appendChild(
                meta
            );

            /*
             * إجراءات الرسالة تكون مخفية افتراضيًا داخل قائمة صغيرة،
             * ولا نضعها فوق النص حتى لا تتداخل مع الفقاعة على الهاتف.
             */
            const moreButton = document.createElement("button");
            moreButton.type = "button";
            moreButton.className = "message-more-btn";
            moreButton.textContent = "⋯";
            moreButton.setAttribute("aria-label", "إجراءات الرسالة");
            moreButton.title = "إجراءات الرسالة";

            const actions = createMessageActions(messageId, message);
            actions.classList.add("message-actions-collapsed");

            moreButton.addEventListener("click", function(event) {
                event.preventDefault();
                event.stopPropagation();
                document.querySelectorAll(".message-actions.message-actions-open").forEach(function(openActions) {
                    if (openActions !== actions) openActions.classList.remove("message-actions-open");
                });
                document.querySelectorAll(".message-more-btn.active").forEach(function(activeButton) {
                    if (activeButton !== moreButton) activeButton.classList.remove("active");
                });
                actions.classList.toggle("message-actions-open");
                moreButton.classList.toggle("active", actions.classList.contains("message-actions-open"));
            });

            meta.appendChild(moreButton);
            wrapper.appendChild(meta);
            wrapper.appendChild(actions);

            /* الضغط المطوّل على الفقاعة يفتح نفس القائمة، خصوصًا على الهاتف. */
            let pressTimer = null;
            wrapper.addEventListener("pointerdown", function(event) {
                if (event.target.closest("button, a, input, textarea")) return;
                clearTimeout(pressTimer);
                pressTimer = setTimeout(function() {
                    actions.classList.add("message-actions-open");
                    moreButton.classList.add("active");
                }, 480);
            });
            ["pointerup", "pointercancel", "pointerleave"].forEach(function(type) {
                wrapper.addEventListener(type, function() {
                    clearTimeout(pressTimer);
                    pressTimer = null;
                });
            });

            container.appendChild(
                wrapper
            );
        }
    );

    container.scrollTop =
        container.scrollHeight;
}


/* =========================================================
   Delivered + Read
========================================================= */

async function updateIncomingStatuses(
    snapshot
) {

    if (
        !currentUser ||
        !activeChatUser ||
        !db
    ) {
        return;
    }

    const batch =
        db.batch();

    const chatId =
        getChatId(
            currentUser.uid,
            activeChatUser.uid
        );

    const chatRef =
        db
            .collection("chats")
            .doc(chatId);

    let count =
        0;

    snapshot.forEach(
        function(documentSnapshot) {

            const message =
                documentSnapshot.data();

            /*
             * الرسائل الموجهة للمستخدم الحالي
             * تصبح Delivered + Read عندما
             * تكون المحادثة مفتوحة.
             */

            if (
                message.receiverId ===
                    currentUser.uid &&
                (
                    message.delivered !==
                        true ||
                    message.read !==
                        true
                )
            ) {

                batch.update(
                    documentSnapshot.ref,
                    {

                        delivered:
                            true,

                        read:
                            true,

                        deliveredAt:
                            firebase.firestore
                                .Timestamp
                                .now(),

                        readAt:
                            firebase.firestore
                                .Timestamp
                                .now()
                    }
                );

                count++;
                 }
        }
    );

    /*
     * بمجرد فتح المستقبل للمحادثة تصبح رسائل هذه المحادثة
     * مقروءة، ونصفر عدادها في مستند المحادثة حتى تختفي من
     * تبويب "غير مقروء" وتبقى قائمة المحادثات متزامنة.
     */
    batch.set(
        chatRef,
        {
            participants: [
                currentUser.uid,
                activeChatUser.uid
            ],
            type: "direct",
            chatType: "direct",
            [`unreadCounts.${currentUser.uid}`]: 0
        },
        { merge: true }
    );

    try {

        await batch.commit();

    } catch (error) {

        console.error(
            "Read status update error:",
            error
        );
    }
}


/* =========================================================
   Send Message
========================================================= */

async function sendMessage() {

    try {

        if (!currentUser || !activeChatUser || !db) {
            showMessage("افتح محادثة أولًا.", "error");
            return;
        }

        const input = $("messageInput");
        const imageFile = pendingChatImage;
        const fileAttachment = pendingChatFile;
        const text = input ? input.value.trim() : "";

        if (!text && !imageFile && !fileAttachment) {
            return;
        }

        if (text.length > 2000) {
            showMessage("الرسالة طويلة جدًا.", "error");
            return;
        }

        if (fileAttachment) {
            if (fileAttachment.size > 20 * 1024 * 1024) {
                showMessage("حجم الملف يجب ألا يتجاوز 20MB.", "error");
                return;
            }
        }

        if (imageFile) {
            if (!/^image\/(jpeg|png|webp)$/.test(imageFile.type)) {
                showMessage("اختر صورة JPG أو PNG أو WEBP.", "error");
                return;
            }
            if (imageFile.size > 5 * 1024 * 1024) {
                showMessage("حجم الصورة يجب ألا يتجاوز 5MB.", "error");
                return;
            }
        }

        stopTyping();

        const sendButton = $("sendMessageBtn");
        const imageButton = $("imageSendBtn");
        const fileButton = $("fileSendBtn");
        if (sendButton) sendButton.disabled = true;
        if (imageButton) imageButton.disabled = true;
        if (fileButton) fileButton.disabled = true;

        const chatId = getChatId(
            currentUser.uid,
            activeChatUser.uid
        );

        const now = firebase.firestore.Timestamp.now();
        let imageUrl = "";
        let fileUrl = "";

        if (imageFile) {
            showMessage("جاري رفع الصورة...", "info");
            imageUrl = await uploadChatImage(imageFile);
        }

        if (fileAttachment) {
            showMessage("جاري رفع الملف...", "info");
            fileUrl = await uploadChatFile(fileAttachment);
        }

        const chatRef = db.collection("chats").doc(chatId);
        const messageRef = chatRef.collection("messages").doc();
        const lastMessageText = fileUrl
            ? (text ? "📎 " + text : "📎 " + (fileAttachment.name || "ملف"))
            : (imageUrl
                ? (text ? "📷 " + text : "📷 صورة")
                : text);

        const sendBatch = db.batch();

        sendBatch.set(
            chatRef,
            {
                participants: [
                    currentUser.uid,
                    activeChatUser.uid
                ],
                type: "direct",
                chatType: "direct",
                lastMessage: lastMessageText,
                lastMessageAt: now,
                updatedAt: now,
                lastMessageSenderId: currentUser.uid,
                [`unreadCounts.${currentUser.uid}`]: 0,
                [`unreadCounts.${activeChatUser.uid}`]:
                    firebase.firestore.FieldValue.increment(1)
            },
            { merge: true }
        );

        sendBatch.set(
            messageRef,
            {
                senderId: currentUser.uid,
                receiverId: activeChatUser.uid,
                text: text,
                type: fileUrl ? "file" : (imageUrl ? "image" : "text"),
                imageUrl: imageUrl || "",
                fileUrl: fileUrl || "",
                fileName: fileUrl ? (fileAttachment.name || "ملف مرفق") : "",
                fileSize: fileUrl ? Number(fileAttachment.size || 0) : 0,
                fileType: fileUrl ? (fileAttachment.type || "application/octet-stream") : "",
                replyTo: pendingReply ? { ...pendingReply } : null,
                delivered: false,
                read: false,
                createdAt: now,
                createdAtClient: now
            }
        );

        await sendBatch.commit();

        if (input) {
            input.value = "";
            input.focus();
        }

        if (imageUrl) {
            clearPendingChatImage();
        }
        if (fileUrl) {
            clearPendingChatFile();
        }
        clearPendingReply();

    } catch (error) {

        console.error("Send message error:", error);

        handleFirebaseError(error);

    } finally {

        const sendButton = $("sendMessageBtn");
        const imageButton = $("imageSendBtn");
        const fileButton = $("fileSendBtn");

        if (sendButton) sendButton.disabled = false;
        if (imageButton) imageButton.disabled = false;
        if (fileButton) fileButton.disabled = false;
    }
}

function setupReplyUI() {
    const cancel = $("cancelReplyBtn");
    if (cancel && cancel.dataset.bound !== "1") {
        cancel.dataset.bound = "1";
        cancel.addEventListener("click", clearPendingReply);
    }
}

/* =========================================================
   Clear Forms
========================================================= */

function clearRegisterForm() {

    [
        "registerName",
        "registerEmail",
        "registerPassword",
        "registerPassword2"
    ].forEach(
        function(id) {

            const element =
                $(id);

            if (element) {

                element.value =
                    "";
            }
        }
    );
}


function clearLoginForm() {

    [
        "loginEmail",
        "loginPassword"
    ].forEach(
        function(id) {

            const element =
                $(id);

            if (element) {

                element.value =
                    "";
            }
        }
    );
}


/* =========================================================
   Firebase Error
========================================================= */

function handleFirebaseError(
    error
) {

    console.error(
        "Firebase error:",
        error
    );

    const messages = {

        "auth/email-already-in-use":
            "هذا البريد الإلكتروني مستخدم بالفعل.",

        "auth/invalid-email":
            "البريد الإلكتروني غير صحيح.",

        "auth/weak-password":
            "كلمة المرور ضعيفة. استخدم 6 أحرف على الأقل.",

        "auth/user-not-found":
            "لا يوجد حساب بهذا البريد الإلكتروني.",

        "auth/wrong-password":
            "البريد الإلكتروني أو كلمة المرور غير صحيحة.",

        "auth/invalid-credential":
            "البريد الإلكتروني أو كلمة المرور غير صحيحة.",

        "auth/too-many-requests":
            "محاولات كثيرة. حاول لاحقًا.",

        "auth/network-request-failed":
            "فشل الاتصال بالإنترنت.",

        "auth/operation-not-allowed":
            "Email/Password غير مفعلة في Firebase Authentication.",

        "permission-denied":
            "ليس لديك صلاحية لتنفيذ العملية."
    };

    let message =
        messages[
            error &&
            error.code
        ];

    if (!message) {

        if (
            error &&
            error.message &&
            error.message.length < 200
        ) {

            message =
                error.message;

        } else {

            message =
                "حدث خطأ غير متوقع.";
        }
    }

    showMessage(
        message,
        "error"
    );
}


/* =========================================================
   Firestore Error
========================================================= */

function handleFirestoreError(
    error,
    defaultMessage
) {

    console.error(
        "Firestore error:",
        error
    );

    let message =
        defaultMessage ||
        "حدث خطأ في Firestore.";

    if (
        error &&
        error.code ===
            "permission-denied"
    ) {

        message =
            "ليس لديك صلاحية للوصول إلى Firestore.";

    } else if (
        error &&
        error.code ===
            "failed-precondition"
    ) {

        message =
            "Firestore يحتاج إلى Index أو إعداد إضافي.";

    } else if (
        error &&
        error.code ===
            "unavailable"
    ) {

        message =
            "Firestore غير متاح حاليًا. تحقق من الإنترنت.";
    }

    showMessage(
        message,
        "error"
    );
}


/* =========================================================
   Cleanup
========================================================= */

function cleanupAll() {

    if (unsubscribeChatNotifications) {
        unsubscribeChatNotifications();
        unsubscribeChatNotifications = null;
    }

    if (unsubscribeUsers) {

        unsubscribeUsers();

        unsubscribeUsers =
            null;
    }

    if (unsubscribeMessages) {

        unsubscribeMessages();

        unsubscribeMessages =
            null;
    }

    cleanupPresence();

    cleanupTyping();

    cleanupUserStatusListeners();

    cleanupChatUserStatus();

    activeChatUser =
        null;
}


/* =========================================================
   Events
========================================================= */

function setupMessageSearch() {
    const searchBtn = $("chatSearchBtn");
    const bar = $("messageSearchBar");
    const input = $("messageSearchInput");
    const clearBtn = $("clearMessageSearchBtn");

    if (!searchBtn || !bar || !input || searchBtn.dataset.bound === "1") return;
    searchBtn.dataset.bound = "1";

    function closeSearch() {
        messageSearchQuery = "";
        input.value = "";
        bar.classList.add("hidden");
        updateMessageSearchCount(0, 0, false);
        if (currentMessagesSnapshot) renderMessages(currentMessagesSnapshot);
    }

    searchBtn.addEventListener("click", function() {
        const wasHidden = bar.classList.contains("hidden");
        bar.classList.toggle("hidden");
        if (wasHidden) {
            setTimeout(function() { input.focus(); }, 50);
        } else {
            closeSearch();
        }
    });

    input.addEventListener("input", function() {
        messageSearchQuery = input.value.trim();
        if (currentMessagesSnapshot) renderMessages(currentMessagesSnapshot);
    });

    clearBtn.addEventListener("click", function() {
        input.value = "";
        messageSearchQuery = "";
        input.focus();
        if (currentMessagesSnapshot) renderMessages(currentMessagesSnapshot);
    });

    input.addEventListener("keydown", function(event) {
        if (event.key === "Escape") {
            event.preventDefault();
            closeSearch();
        }
    });
}

function setupEvents() {
    setupMessageSearch();

    const startBtn =
        $("startBtn");

    if (startBtn) {

        startBtn.addEventListener(
            "click",
            function() {

                showPage(
                    currentUser
                        ? "accountPage"
                        : "loginPage"
                );
            }
        );
    }


    const topLoginBtn =
        $("topLoginBtn");

    if (topLoginBtn) {

        topLoginBtn.addEventListener(
            "click",
            function() {

                showPage(
                    currentUser
                        ? "accountPage"
                        : "loginPage"
                );
            }
        );
    }


    const createAccountBtn =
        $("createAccountBtn");

    if (createAccountBtn) {

        createAccountBtn.addEventListener(
            "click",
            createAccount
        );
    }


    const loginSubmitBtn =
        $("loginSubmitBtn");

    if (loginSubmitBtn) {

        loginSubmitBtn.addEventListener(
            "click",
            loginUser
        );
    }


    const goRegisterBtn =
        $("goRegisterBtn");

    if (goRegisterBtn) {

        goRegisterBtn.addEventListener(
            "click",
            function() {

                clearLoginForm();

                showPage(
                    "registerPage"
                );
            }
        );
    }


    const goLoginBtn =
        $("goLoginBtn");

    if (goLoginBtn) {

        goLoginBtn.addEventListener(
            "click",
            function() {

                clearRegisterForm();

                showPage(
                    "loginPage"
                );
            }
        );
    }


    const backHomeFromLogin =
        $("backHomeFromLogin");

    if (backHomeFromLogin) {

        backHomeFromLogin.addEventListener(
            "click",
            function() {

                showPage(
                    "homePage"
                );
            }
        );
    }


    const backHomeFromRegister =
        $("backHomeFromRegister");

    if (backHomeFromRegister) {

        backHomeFromRegister.addEventListener(
            "click",
            function() {

                showPage(
                    "homePage"
                );
            }
        );
    }


    const logoutBtn =
        $("logoutBtn");

    if (logoutBtn) {

        logoutBtn.addEventListener(
            "click",
            logoutUser
        );
    }


    const profileBtn =
        $("profileBtn");

    if (profileBtn) {

        profileBtn.addEventListener(
            "click",
            openProfile
        );
    }


    const userSearch =
        $("userSearch");

    if (userSearch) {

        userSearch.addEventListener(
            "input",
            searchUsers
        );
    }


    const closeChatBtn =
        $("closeChatBtn");

    if (closeChatBtn) {

        closeChatBtn.addEventListener(
            "click",
            closeChat
        );
    }


    setupChatImageUpload();
    setupReplyUI();
    setupChatFileUpload();
    setupVoiceMessageUI();
    setupVoiceCallUI();

    const sendMessageBtn =
        $("sendMessageBtn");

    if (sendMessageBtn) {

        sendMessageBtn.addEventListener(
            "click",
            sendMessage
        );
    }


    const messageInput =
        $("messageInput");

    if (messageInput) {

        messageInput.addEventListener(
            "input",
            function() {

                if (
                    messageInput.value
                        .trim()
                        .length > 0
                ) {

                    startTyping();

                } else {

                    stopTyping();
                }
            }
        );


        messageInput.addEventListener(
            "blur",
            function() {

                stopTyping();
            }
        );


        messageInput.addEventListener(
            "keydown",
            function(event) {

                if (
                    event.key === "Enter" &&
                    !event.shiftKey
                ) {

                    event.preventDefault();

                    sendMessage();
                }
            }
        );
    }
}


/* =========================================================
   Start
========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    function() {

        setupEvents();

        showPage(
            "homePage"
        );

        updateHeader();

        initializeFirebase();
    }
);


/* =========================================================
   ChatOnline — SEARCH / USERS COMPATIBILITY FIX
   يحافظ على المحادثة الحالية ويجعل المستخدمين يظهرون
   فقط بعد كتابة بحث فعلي.
   ========================================================= */

(function () {
    "use strict";

    window.chatOnlineUsers = window.chatOnlineUsers || [];

    function getEl(id) {
        return document.getElementById(id);
    }

    function clearUserResults() {
        const list = getEl("usersList");
        if (!list) return;

        if (typeof cleanupUserStatusListeners === "function") {
            cleanupUserStatusListeners();
        }

        list.innerHTML = "";
        list.classList.add("users-results-hidden");
        list.style.display = "none";
    }

    function showUserResults() {
        const list = getEl("usersList");
        if (!list) return;

        list.classList.remove("users-results-hidden");
        list.style.display = "";
    }

    /*
      نسخة آمنة من renderUsers:
      - لا تعرض شيئًا قبل البحث.
      - زر المحادثة يستدعي openChat مباشرة.
      - لا نغيّر نظام Firebase أو الرسائل.
    */
    window.renderUsers = function (users) {
        const list = getEl("usersList");
        if (!list) return;

        if (typeof cleanupUserStatusListeners === "function") {
            cleanupUserStatusListeners();
        }

        list.innerHTML = "";

        if (!users || !users.length) {
            showUserResults();

            list.innerHTML =
                '<p class="users-search-empty">' +
                'لم يتم العثور على مستخدم مطابق للبحث.' +
                '</p>';

            return;
        }

        showUserResults();

        users.forEach(function (user) {
            const card = document.createElement("div");
            card.className = "user-card";
            card.dataset.uid = user.uid;

            const avatar = document.createElement("div");
            avatar.className = "user-avatar";
            if (user.photoURL) {
                avatar.style.backgroundImage =
                    'url("' + String(user.photoURL).replace(/"/g, "&quot;") + '")';
                avatar.style.backgroundSize = "cover";
                avatar.style.backgroundPosition = "center";
                avatar.style.backgroundRepeat = "no-repeat";
                avatar.textContent = "";
            } else {
                avatar.textContent = "👤";
            }

            const info = document.createElement("div");
            info.className = "user-info";

            const name = document.createElement("h3");
            name.textContent = user.name || "مستخدم";

            const email = document.createElement("p");
            email.textContent = user.email || "";

            const status = document.createElement("div");
            status.className = "user-status offline";
            status.id = "user-status-" + user.uid;
            status.innerHTML =
                '<span class="status-dot offline-dot">●</span> غير متصل';

            info.appendChild(name);
            info.appendChild(email);
            info.appendChild(status);

            /* =====================================================
               أزرار المستخدم العامة — تُبنى هنا مباشرةً.
               لا نعتمد على مؤقتات أو مراقبة DOM حتى لا تختفي
               المتابعة عند تحديث نتائج البحث.
               ===================================================== */
            const actions = document.createElement("div");
            actions.className = "user-card-actions";

            const button = document.createElement("button");
            button.className = "primary-btn user-chat-btn";
            button.type = "button";
            button.textContent = "💬 محادثة";

            button.addEventListener("click", function (event) {
                event.preventDefault();
                event.stopPropagation();
                if (typeof openChat === "function") openChat(user);
            });

            const followButton = document.createElement("button");
            followButton.className = "follow-card-btn";
            followButton.type = "button";
            followButton.textContent = "＋ متابعة";
            followButton.title = "متابعة هذا الحساب";

            followButton.addEventListener("click", function (event) {
                event.preventDefault();
                event.stopPropagation();
                if (window.ChatOnlineFollow && typeof window.ChatOnlineFollow.openProfile === "function") {
                    window.ChatOnlineFollow.openProfile(user);
                } else {
                    window.__pendingFollowProfile = user;
                }
            });

            actions.appendChild(button);
            actions.appendChild(followButton);

            /* الضغط على صورة/معلومات المستخدم يفتح الملف العام */
            [avatar, info].forEach(function (node) {
                node.style.cursor = "pointer";
                node.addEventListener("click", function (event) {
                    event.preventDefault();
                    event.stopPropagation();
                    if (window.ChatOnlineFollow && typeof window.ChatOnlineFollow.openProfile === "function") {
                        window.ChatOnlineFollow.openProfile(user);
                    }
                });
            });

            card.appendChild(avatar);
            card.appendChild(info);
            card.appendChild(actions);
            list.appendChild(card);

            /* تحديث حالة المتابعة من Firebase بعد ظهور البطاقة */
            if (window.ChatOnlineFollow && typeof window.ChatOnlineFollow.isFollowing === "function") {
                window.ChatOnlineFollow.isFollowing(user.uid).then(function (following) {
                    followButton.textContent = following ? "✓ متابَع" : "＋ متابعة";
                    followButton.classList.toggle("is-following", following);
                }).catch(function () {});
            }

            if (typeof watchUserStatus === "function") {
                watchUserStatus(user.uid, status);
            }
        });
    };

    /*
      البحث:
      - فارغ = إخفاء النتائج بالكامل.
      - كتابة اسم/بريد = إظهار المطابقين فقط.
    */
    window.searchUsers = function () {
        const input = getEl("userSearch");
        const list = getEl("usersList");

        if (!input || !list) return;

        const query = input.value.trim().toLowerCase();

        if (!query) {
            clearUserResults();
            return;
        }

        const users = Array.isArray(window.chatOnlineUsers)
            ? window.chatOnlineUsers
            : [];

        const results = users.filter(function (user) {
            const name = String(user.name || "").toLowerCase();
            const email = String(user.email || "").toLowerCase();

            return (
                name.includes(query) ||
                email.includes(query)
            );
        });

        window.renderUsers(results);
    };

    /*
      تحميل المستخدمين:
      نخزنهم فقط، ولا نرسم البطاقات عند فتح الحساب.
    */
    window.loadUsers = function () {
        if (!currentUser || !db) return;

        if (unsubscribeUsers) {
            unsubscribeUsers();
            unsubscribeUsers = null;
        }

        if (typeof cleanupUserStatusListeners === "function") {
            cleanupUserStatusListeners();
        }

        window.chatOnlineUsers = [];
        clearUserResults();

        unsubscribeUsers = db
            .collection("users")
            .orderBy("name")
            .onSnapshot(
                function (snapshot) {
                    const users = [];

                    snapshot.forEach(function (documentSnapshot) {
                        if (
                            currentUser &&
                            documentSnapshot.id === currentUser.uid
                        ) {
                            return;
                        }

                        const data =
                            documentSnapshot.data() || {};

                        users.push({
                            uid: documentSnapshot.id,
                            name: data.name || "مستخدم",
                            email: data.email || "",
                          photoURL: data.photoURL ||""
                        });
                    });

                    window.chatOnlineUsers = users;

                    /*
                      إذا كان المستخدم قد كتب شيئًا بالفعل،
                      نعيد البحث تلقائيًا.
                    */
                    window.searchUsers();
                },
                function (error) {
                    if (typeof handleFirestoreError === "function") {
                        handleFirestoreError(
                            error,
                            "تعذر تحميل المستخدمين."
                        );
                    }
                }
            );
    };

    /*
      نضمن أن حقل البحث يعمل حتى لو كان setupEvents
      من نسخة قديمة من السكربت.
    */
    function bindSearchFix() {
        const input = getEl("userSearch");
        if (!input || input.dataset.searchFixBound === "1") {
            return;
        }

        input.dataset.searchFixBound = "1";

        input.addEventListener("input", function () {
            window.searchUsers();
        });

        input.addEventListener("search", function () {
            window.searchUsers();
        });

        clearUserResults();
    }

    /*
      نضمن أن زر المحادثة الناتج من البحث يعمل.
      نستخدم delegation كشبكة أمان إضافية.
    */
    function bindChatDelegation() {
        const list = getEl("usersList");
        if (!list || list.dataset.chatDelegationBound === "1") {
            return;
        }

        list.dataset.chatDelegationBound = "1";

        list.addEventListener("click", function (event) {
            const button =
                event.target.closest(".user-card button");

            if (!button) return;

            const card = button.closest(".user-card");
            if (!card) return;

            const uid = card.dataset.uid;
            if (!uid) return;

            const users = Array.isArray(window.chatOnlineUsers)
                ? window.chatOnlineUsers
                : [];

            const user = users.find(function (item) {
                return item.uid === uid;
            });

            if (!user) return;

            event.preventDefault();
            event.stopPropagation();

            if (typeof openChat === "function") {
                openChat(user);
            }
        });
    }

    function initializeSearchCompatibility() {
        bindSearchFix();
        bindChatDelegation();

        /*
          إذا كان الحساب مفتوحًا والمستخدمون محمّلون بالفعل،
          لا نعرضهم إلا إذا كان هناك بحث.
        */
        const input = getEl("userSearch");
        if (input && !input.value.trim()) {
            clearUserResults();
        }
    }

    /*
      هذا يعمل بعد تحميل DOM، ولا يغيّر بقية وظائف التطبيق.
    */
    document.addEventListener(
        "DOMContentLoaded",
        initializeSearchCompatibility
    );

    /*
      إذا كان DOMContentLoaded قد حدث قبل هذا الجزء لأي سبب،
      نهيئ مباشرة أيضًا.
    */
    if (document.readyState !== "loading") {
        initializeSearchCompatibility();
    }
})();
// =========================================================
// [REF-02-A] USER SEARCH BUBBLES
// المستخدمون يظهرون كفقاعات بعد البحث فقط
// =========================================================

(function () {
    "use strict";

    function getUsersList() {
        return document.getElementById("usersList");
    }

    function getSearchInput() {
        return document.getElementById("userSearch");
    }

    function hideUserBubbles() {
        const list = getUsersList();

        if (!list) {
            return;
        }

        list.innerHTML = "";
        list.style.display = "none";
        list.classList.add("users-results-hidden");

        if (typeof cleanupUserStatusListeners === "function") {
            cleanupUserStatusListeners();
        }
    }

    function createAvatar(user) {

        const avatar = document.createElement("div");

        avatar.className = "chat-user-bubble-avatar";

        const name =
            String(user.name || "مستخدم").trim();

        const firstLetter =
            name.charAt(0).toUpperCase();

        avatar.textContent =
            firstLetter || "👤";

        return avatar;
    }

    function renderUserBubbles(users) {

        const list = getUsersList();

        if (!list) {
            return;
        }

        list.innerHTML = "";

        list.classList.remove(
            "users-results-hidden"
        );

        list.style.display = "";

        if (!users || !users.length) {

            const empty =
                document.createElement("div");

            empty.className =
                "chat-users-empty";

            empty.textContent =
                "لم يتم العثور على مستخدم";

            list.appendChild(empty);

            return;
        }

        const container =
            document.createElement("div");

        container.className =
            "chat-users-bubbles";

        users.forEach(function (user) {

            const bubble =
                document.createElement("button");

            bubble.type =
                "button";

            bubble.className =
                "chat-user-bubble";

            bubble.dataset.uid =
                user.uid;

            const avatar =
                createAvatar(user);

            const status =
                document.createElement("span");

            status.className =
                "chat-user-bubble-status offline";

            status.id =
                "bubble-status-" +
                user.uid;

            const name =
                document.createElement("span");

            name.className =
                "chat-user-bubble-name";

            name.textContent =
                user.name ||
                "مستخدم";

            bubble.appendChild(
                avatar
            );

            bubble.appendChild(
                status
            );

            bubble.appendChild(
                name
            );

            bubble.addEventListener(
                "click",
                function (event) {

                    event.preventDefault();
                    event.stopPropagation();

                    if (
                        typeof openChat ===
                        "function"
                    ) {
                        openChat(user);
                    }
                }
            );

            container.appendChild(
                bubble
            );

            if (
                typeof watchUserStatus ===
                "function"
            ) {

                watchUserStatus(
                    user.uid,
                    status
                );
            }
        });

        list.appendChild(
            container
        );
    }

    function searchUserBubbles() {

        const input =
            getSearchInput();

        const list =
            getUsersList();

        if (!input || !list) {
            return;
        }

        const query =
            input.value
                .trim()
                .toLowerCase();

        if (!query) {

            hideUserBubbles();

            return;
        }

        const users =
            Array.isArray(
                window.chatOnlineUsers
            )
                ? window.chatOnlineUsers
                : [];

        const results =
            users.filter(function (user) {

                const name =
                    String(
                        user.name || ""
                    ).toLowerCase();

                const email =
                    String(
                        user.email || ""
                    ).toLowerCase();

                return (
                    name.includes(query) ||
                    email.includes(query)
                );
            });

        if (
            typeof cleanupUserStatusListeners ===
            "function"
        ) {
            cleanupUserStatusListeners();
        }

        renderUserBubbles(
            results
        );
    }

    function initializeBubbleSearch() {

        const input =
            getSearchInput();

        if (!input) {
            return;
        }

        if (
            input.dataset.bubbleSearchBound ===
            "1"
        ) {
            return;
        }

        input.dataset.bubbleSearchBound =
            "1";

        input.addEventListener(
            "input",
            searchUserBubbles
        );

        input.addEventListener(
            "search",
            searchUserBubbles
        );

        /*
         * البحث فارغ عند البداية
         */
        if (
            !input.value.trim()
        ) {
            hideUserBubbles();
        }
    }

    /*
     * ننتظر تحميل الصفحة
     */
    document.addEventListener(
        "DOMContentLoaded",
        initializeBubbleSearch
    );

    /*
     * احتياط إذا كان DOM محمّلًا
     */
    if (
        document.readyState !==
        "loading"
    ) {
        initializeBubbleSearch();
    }

})();
/* =========================================================
   [REF-03-A]
   ChatOnline — واجهة الدردشات الاحترافية
   المستخدمون + فقاعات + بحث + زر الدردشة
   ========================================================= */

(function () {

    "use strict";

    function createChatUI() {

        const usersCard =
            document.querySelector(".users-card");

        if (!usersCard) {
            return;
        }

        /* منع إنشاء الواجهة مرتين */
        if (document.getElementById("professionalChatUI")) {
            return;
        }

        const wrapper =
            document.createElement("div");

        wrapper.id =
            "professionalChatUI";

        wrapper.innerHTML = `

            <div class="chat-list-top">

                <button
                    id="openChatsBtn"
                    class="professional-chat-btn"
                    type="button">

                    <span class="chat-btn-icon">💬</span>

                    <span>
                        الدردشات
                    </span>

                    <span
                        id="chatCountBadge"
                        class="chat-count-badge">
                        0
                    </span>

                </button>

            </div>


            <div class="chat-users-section">

                <div class="chat-section-title">

                    <div>
                        <h3>
                            المستخدمون
                        </h3>

                        <p>
                            اختر شخصًا لبدء محادثة
                        </p>
                    </div>

                    <span class="chat-users-icon">
                        👥
                    </span>

                </div>


                <div
                    id="chatUsersBubbles"
                    class="chat-users-bubbles">

                </div>

            </div>

        `;

        /*
         * نضع الواجهة الجديدة في أعلى بطاقة المستخدمين
         */
        usersCard.insertBefore(
            wrapper,
            usersCard.firstChild
        );


        /* =====================================================
           زر الدردشات
           ===================================================== */

        const openChatsBtn =
            document.getElementById(
                "openChatsBtn"
            );

        if (openChatsBtn) {

            openChatsBtn.addEventListener(
                "click",
                function () {

                    const search =
                        document.getElementById(
                            "userSearch"
                        );

                    if (search) {

                        search.scrollIntoView({
                            behavior: "smooth",
                            block: "center"
                        });

                        setTimeout(
                            function () {
                                search.focus();
                            },
                            350
                        );

                    }

                }
            );

        }

    }


    /* =========================================================
       رسم فقاعات المستخدمين
       ========================================================= */

    function renderChatUserBubbles() {

        const container =
            document.getElementById(
                "chatUsersBubbles"
            );

        if (!container) {
            return;
        }

        const users =
            Array.isArray(
                window.chatOnlineUsers
            )
                ? window.chatOnlineUsers
                : [];

        container.innerHTML = "";


        if (!users.length) {

            container.innerHTML = `
                <div class="chat-bubbles-empty">
                    لا يوجد مستخدمون حاليًا
                </div>
            `;

            updateChatCount(0);

            return;
        }


        /*
         * نعرض أول 8 مستخدمين في الفقاعات
         */
        const visibleUsers =
            users.slice(0, 8);


        visibleUsers.forEach(
            function (user) {

                const bubble =
                    document.createElement("button");

                bubble.type = "button";

                bubble.className =
                    "chat-user-bubble";


                const avatar =
                    document.createElement("div");

                avatar.className =
                    "chat-bubble-avatar";


                /*
                 * صورة المستخدم إن كانت موجودة
                 */
                if (user.photoURL) {

                    avatar.style.backgroundImage =
                        "url('" +
                        user.photoURL +
                        "')";

                    avatar.style.backgroundSize =
                        "cover";

                    avatar.style.backgroundPosition =
                        "center";

                    avatar.textContent = "";

                } else {

                    avatar.textContent =
                        (
                            user.name ||
                            "مستخدم"
                        )
                            .charAt(0)
                            .toUpperCase();

                }


                const name =
                    document.createElement("span");

                name.className =
                    "chat-bubble-name";

                name.textContent =
                    user.name ||
                    "مستخدم";


                const online =
                    document.createElement("span");

                online.className =
                    "chat-bubble-status";

                online.textContent =
                    "●";


                bubble.appendChild(avatar);
                bubble.appendChild(name);
                bubble.appendChild(online);


                bubble.addEventListener(
                    "click",
                    function () {

                        if (
                            typeof openChat ===
                            "function"
                        ) {

                            openChat(user);

                        }

                    }
                );


                container.appendChild(
                    bubble
                );

            }
        );


        updateChatCount(
            users.length
        );

    }


    /* =========================================================
       عداد المستخدمين
       ========================================================= */

    function updateChatCount(count) {

        const badge =
            document.getElementById(
                "chatCountBadge"
            );

        if (!badge) {
            return;
        }

        badge.textContent =
            String(count);

    }


    /* =========================================================
       البحث — لا نكسر البحث الموجود
       ========================================================= */

    function setupProfessionalSearch() {

        const input =
            document.getElementById(
                "userSearch"
            );

        if (!input) {
            return;
        }


        /*
         * نضيف عنوانًا فوق البحث
         * إذا لم يكن موجودًا
         */

        if (
            !document.getElementById(
                "professionalSearchTitle"
            )
        ) {

            const title =
                document.createElement("div");

            title.id =
                "professionalSearchTitle";

            title.className =
                "professional-search-title";

            title.innerHTML = `
                <span>🔎</span>
                <span>البحث عن مستخدم</span>
            `;

            input.parentNode.insertBefore(
                title,
                input
            );

        }

    }


    /* =========================================================
       مراقبة وصول المستخدمين من Firebase
       ========================================================= */

    function watchUsersData() {

        let lastUsers = "";

        setInterval(
            function () {

                const users =
                    Array.isArray(
                        window.chatOnlineUsers
                    )
                        ? window.chatOnlineUsers
                        : [];

                const signature =
                    users
                        .map(
                            function (user) {
                                return (
                                    user.uid +
                                    "|" +
                                    user.name +
                                    "|" +
                                    user.photoURL
                                );
                            }
                        )
                        .join(",");


                if (
                    signature !== lastUsers
                ) {

                    lastUsers =
                        signature;

                    renderChatUserBubbles();

                }

            },
            500
        );

    }


    /* =========================================================
       التشغيل
       ========================================================= */

    function initProfessionalChatUI() {

        createChatUI();

        setupProfessionalSearch();

        renderChatUserBubbles();

        watchUsersData();

    }


    if (
        document.readyState ===
        "loading"
    ) {

        document.addEventListener(
            "DOMContentLoaded",
            initProfessionalChatUI
        );

    } else {

        initProfessionalChatUI();

    }

})();

/* =========================================================
   ChatOnline — Reference UI FINAL
   طبقة بصرية فقط + قائمة المحادثات من Firestore
   لا تحذف وظائف المستخدمين الأصلية.
   ========================================================= */
(function () {
    "use strict";

    let referenceChats = [];
    let referenceUsers = {};
    let referenceUnsub = null;
    let referenceUsersUnsub = null;
    let referenceSearchTimer = null;
    let referenceSearchRequest = 0;
    let activeReferenceTab = "all";

    function ts(value) {
        if (!value) return 0;
        try {
            if (typeof value.toMillis === "function") return value.toMillis();
            if (typeof value.toDate === "function") return value.toDate().getTime();
            if (value instanceof Date) return value.getTime();
            const n = new Date(value).getTime();
            return Number.isNaN(n) ? 0 : n;
        } catch (_) {
            return 0;
        }
    }

    function timeLabel(value) {
        const n = ts(value);
        if (!n) return "";
        try {
            return new Intl.DateTimeFormat("ar", {
                hour: "2-digit",
                minute: "2-digit"
            }).format(new Date(n));
        } catch (_) {
            return "";
        }
    }

    function chatActivityTime(chat) {
        if (!chat) return 0;
        return Math.max(
            ts(chat.lastMessageAt),
            ts(chat.updatedAt),
            ts(chat.lastActivityAt),
            ts(chat.createdAt)
        );
    }

    function chatSearchText(chat) {
        const user = otherUser(chat);
        return [
            user && user.name,
            user && user.username,
            user && user.email,
            user && user.uid,
            chat && chat.lastMessage,
            chat && chat.name,
            chat && chat.otherUserName,
            chat && chat.peerName,
            chat && chat.id
        ].filter(Boolean).join(" ").toLowerCase();
    }

    function mergeReferenceUsers(users) {
        (users || []).forEach(function (user) {
            if (!user || !user.uid) return;
            referenceUsers[String(user.uid)] = { ...referenceUsers[String(user.uid)], ...user, uid: String(user.uid) };
        });
    }

    function unreadCount(chat) {
        const me = window.currentUser || (typeof currentUser !== "undefined" ? currentUser : null);
        if (!chat || !me) return 0;

        // الحساب الحالي له أولوية دائمًا. لا نستخدم unreadCount العام
        // إذا كانت هناك قيمة خاصة بالمستخدم، لأن كل طرف له حالة قراءة مستقلة.
        const uid = String(me.uid);
        const candidates = [
            chat.unreadCounts && chat.unreadCounts[uid],
            chat.unread && chat.unread[uid],
            chat.unreadCountByUser && chat.unreadCountByUser[uid],
            chat.unreadCount
        ];

        for (const value of candidates) {
            const n = Number(value);
            if (Number.isFinite(n)) return Math.max(0, n);
        }
        return 0;
    }

    function participantUid(value) {
        if (!value) return "";
        if (typeof value === "string" || typeof value === "number") return String(value);
        if (typeof value === "object") {
            return String(
                value.uid || value.id || value.userId || value.userID || value.participantId || ""
            );
        }
        return "";
    }

    function otherUser(chat) {
        const me = window.currentUser || referenceDataUser || (typeof currentUser !== "undefined" ? currentUser : null);
        if (!chat || !me) return null;
        const myUid = String(me.uid);
        let otherId = "";

        const participantSources = [
            chat.participants,
            chat.participantIds,
            chat.members,
            chat.users
        ];

        for (const source of participantSources) {
            if (!Array.isArray(source)) continue;
            for (const entry of source) {
                const id = participantUid(entry);
                if (id && id !== myUid) { otherId = id; break; }
            }
            if (otherId) break;
        }

        const directFields = [
            chat.otherUserId, chat.otherUid, chat.peerUid, chat.peerId,
            chat.receiverId, chat.recipientId, chat.userId, chat.userUid
        ];
        if (!otherId) {
            for (const value of directFields) {
                const id = participantUid(value);
                if (id && id !== myUid) { otherId = id; break; }
            }
        }

        if (!otherId && chat.id) {
            const parts = String(chat.id).split("_");
            if (parts.length >= 2) {
                const ids = parts.filter(Boolean);
                const candidate = ids.find(id => id !== myUid);
                if (candidate) otherId = candidate;
            }
        }

        // بيانات الطرف الآخر إن كانت محفوظة داخل مستند المحادثة.
        const embedded = chat.otherUser || chat.peer || chat.otherParticipant;
        if (embedded && typeof embedded === "object") {
            const embeddedId = participantUid(embedded);
            if (embeddedId && (!otherId || embeddedId === otherId)) {
                otherId = embeddedId;
                return { uid: otherId, name: embedded.name || embedded.username || "مستخدم", email: embedded.email || "", photoURL: embedded.photoURL || embedded.avatar || "", online: !!embedded.online };
            }
        }

        if (!otherId) return null;
        if (referenceUsers[otherId]) return referenceUsers[otherId];

        const liveUsers = Array.isArray(window.chatOnlineUsers) ? window.chatOnlineUsers : [];
        const live = liveUsers.find(u => String(u.uid) === otherId);
        if (live) return live;

        // لا نخفي المحادثة إذا تأخر تحميل users. نعرضها فورًا ونملأ بياناتها لاحقًا.
        return {
            uid: otherId,
            name: chat.otherUserName || chat.peerName || chat.participantName || "مستخدم",
            email: chat.otherUserEmail || chat.peerEmail || "",
            photoURL: chat.otherUserPhotoURL || chat.peerPhotoURL || "",
            online: false,
            _fallback: true
        };
    }

    function isGroup(chat) {
        return !!(
            chat &&
            (
                chat.isGroup === true ||
                chat.type === "group" ||
                chat.chatType === "group" ||
                (Array.isArray(chat.participants) && chat.participants.length > 2)
            )
        );
    }

    function createShell() {
        const professionalUI = document.getElementById("professionalChatUI");
        const usersCard = document.querySelector(".users-card");

        if (!usersCard) return null;

        let shell = document.getElementById("referenceChatShell");
        if (shell) return shell;

        if (!professionalUI) {
            shell = document.createElement("div");
            shell.id = "referenceChatShell";
            usersCard.appendChild(shell);
        } else {
            shell = document.createElement("div");
            shell.id = "referenceChatShell";
            professionalUI.appendChild(shell);
        }

        shell.innerHTML = `
            <div class="reference-search-wrap">
                <span class="reference-search-icon">⌕</span>
                <input
                    id="referenceSearch"
                    class="reference-search"
                    type="search"
                    autocomplete="off"
                    placeholder="ابحث عن مستخدم...">
            </div>

            <div id="referenceStories" class="reference-stories"></div>

            <div class="reference-tabs" role="tablist">
                <button class="reference-tab active" data-ref-tab="all" type="button">
                    الكل <span class="tab-badge" id="referenceAllCount">0</span>
                </button>
                <button class="reference-tab" data-ref-tab="unread" type="button">
                    غير مقروء <span class="tab-badge" id="referenceUnreadCount">0</span>
                </button>
                <button class="reference-tab" data-ref-tab="groups" type="button">
                    المجموعات
                </button>
            </div>

            <section class="reference-chat-card">
                <div class="reference-chat-heading">
                    <div>
                        <h3>المحادثات</h3>
                        <p>محادثاتك الأخيرة</p>
                    </div>
                    <span class="reference-chat-heading-icon">💬</span>
                </div>
                <div id="referenceChatItems" class="reference-chat-items"></div>
            </section>

            <div class="reference-bottom-nav" aria-label="التنقل">
                <button class="reference-nav-item active" type="button" data-nav="chats">
                    <span class="reference-nav-icon">💬</span>
                    <span>الدردشات</span>
                </button>
                <button class="reference-nav-item" type="button" data-nav="calls">
                    <span class="reference-nav-icon">☎</span>
                    <span>المكالمات</span>
                </button>
                <button class="reference-nav-item" type="button" data-nav="favorites">
                    <span class="reference-nav-icon">☆</span>
                    <span>المفضلة</span>
                </button>
                <button class="reference-nav-item" type="button" data-nav="settings">
                    <span class="reference-nav-icon">⚙</span>
                    <span>الإعدادات</span>
                </button>
            </div>
            <button class="reference-fab" type="button" aria-label="بدء محادثة جديدة">+</button>
        `;

        return shell;
    }

    function renderStories() {
        const box = document.getElementById("referenceStories");
        if (!box) return;

        const users = Array.isArray(window.chatOnlineUsers)
            ? window.chatOnlineUsers
            : [];

        box.innerHTML = "";

        const start = document.createElement("button");
        start.type = "button";
        start.className = "reference-story reference-story-start";
        start.innerHTML = `
            <div class="reference-story-avatar">+</div>
            <div class="reference-story-name">بدء دردشة</div>
        `;
        start.addEventListener("click", function () {
            const input = document.getElementById("referenceSearch");
            if (input) input.focus();
        });
        box.appendChild(start);

        users.slice(0, 8).forEach(function (user) {
            const item = document.createElement("button");
            item.type = "button";
            item.className = "reference-story";

            const avatar = document.createElement("div");
            avatar.className = "reference-story-avatar";

            if (user.photoURL) {
                avatar.style.backgroundImage = `url("${user.photoURL}")`;
                avatar.style.backgroundSize = "cover";
                avatar.style.backgroundPosition = "center";
            } else {
                avatar.textContent = String(user.name || "مستخدم").charAt(0).toUpperCase();
            }

            const name = document.createElement("div");
            name.className = "reference-story-name";
            name.textContent = user.name || "مستخدم";

            item.appendChild(avatar);
            item.appendChild(name);

            item.addEventListener("click", function () {
                if (user._fallback && String(user.uid).startsWith("chat:")) return;
                if (typeof openChat === "function") openChat(user);
            });

            box.appendChild(item);
        });
    }

    function createReferenceChatItem(chat) {
        const user = otherUser(chat) || {
            uid: String(chat.otherUserId || chat.peerUid || "chat:" + String(chat.id || "unknown")),
            name: chat.otherUserName || chat.peerName || "محادثة",
            email: chat.otherUserEmail || "",
            photoURL: chat.otherUserPhotoURL || "",
            online: false,
            _fallback: true
        };

        const item = document.createElement("button");
        item.type = "button";
        item.className = "reference-chat-item";
        item.dataset.chatId = String(chat.id || "");
        item.dataset.uid = String(user.uid || "");

        const avatar = document.createElement("div");
        avatar.className = "reference-chat-avatar";
        if (user.photoURL) {
            avatar.style.backgroundImage = `url("${user.photoURL}")`;
            avatar.style.backgroundSize = "cover";
            avatar.style.backgroundPosition = "center";
        } else {
            avatar.textContent = String(user.name || "مستخدم").trim().charAt(0).toUpperCase() || "👤";
        }

        const info = document.createElement("div");
        info.className = "reference-chat-info";

        const top = document.createElement("div");
        top.className = "reference-chat-top";
        const name = document.createElement("strong");
        name.className = "reference-chat-name";
        name.textContent = isGroup(chat) ? (chat.name || "مجموعة") : (user.name || "مستخدم");
        const time = document.createElement("span");
        time.className = "reference-chat-time";
        time.textContent = timeLabel(chat.lastMessageAt || chat.updatedAt || chat.createdAt);
        top.append(name, time);

        const bottom = document.createElement("div");
        bottom.className = "reference-chat-bottom";
        const last = document.createElement("span");
        last.className = "reference-chat-last";
        last.textContent = chat.lastMessage || "ابدأ المحادثة الآن";
        bottom.appendChild(last);

        const unread = unreadCount(chat);
        if (unread > 0) {
            const badge = document.createElement("span");
            badge.className = "reference-unread";
            badge.textContent = unread > 99 ? "99+" : String(unread);
            bottom.appendChild(badge);
        }

        info.append(top, bottom);
        item.append(avatar, info);
        item.addEventListener("click", function () {
            if (typeof openChat === "function" && !String(user.uid).startsWith("chat:")) openChat(user);
        });
        return item;
    }

    function createReferenceUserResult(user, hasChat) {
        const item = document.createElement("button");
        item.type = "button";
        item.className = "reference-user-result";
        item.dataset.uid = String(user.uid);

        const avatar = document.createElement("div");
        avatar.className = "reference-search-avatar";
        if (user.photoURL) {
            avatar.style.backgroundImage = `url("${user.photoURL}")`;
            avatar.style.backgroundSize = "cover";
            avatar.style.backgroundPosition = "center";
        } else {
            avatar.textContent = String(user.name || "مستخدم").trim().charAt(0).toUpperCase() || "👤";
        }

        const info = document.createElement("div");
        info.className = "reference-search-user-info";
        const name = document.createElement("strong");
        name.textContent = user.name || user.username || "مستخدم";
        const meta = document.createElement("span");
        meta.textContent = user.email || (hasChat ? "محادثة موجودة" : "مستخدم جديد");
        info.append(name, meta);

        const action = document.createElement("span");
        action.className = "reference-search-action";
        action.textContent = hasChat ? "فتح" : "محادثة";

        item.append(avatar, info, action);
        item.addEventListener("click", function () {
            if (typeof openChat === "function") openChat(user);
        });
        return item;
    }

    function renderSearchShell(query, users) {
        const box = document.getElementById("referenceChatItems");
        const shell = document.getElementById("referenceChatShell");
        if (!box) return;
        if (shell) shell.classList.add("reference-searching");
        box.innerHTML = "";

        const normalized = String(query || "").trim().toLowerCase();
        const matchingChats = referenceChats.filter(function (chat) {
            return chatSearchText(chat).includes(normalized);
        });

        const knownUsers = [];
        const seen = new Set();
        (users || []).forEach(function (user) {
            if (!user || !user.uid || String(user.uid) === String((window.currentUser || {}).uid || "")) return;
            const text = [user.name, user.username, user.email, user.uid].filter(Boolean).join(" ").toLowerCase();
            if (!text.includes(normalized) || seen.has(String(user.uid))) return;
            seen.add(String(user.uid));
            knownUsers.push(user);
        });

        const chatUids = new Set();
        matchingChats.forEach(function (chat) {
            const u = otherUser(chat);
            if (u && u.uid) chatUids.add(String(u.uid));
        });

        if (matchingChats.length) {
            const title = document.createElement("div");
            title.className = "reference-search-section-title";
            title.textContent = "المحادثات المطابقة";
            box.appendChild(title);
            matchingChats.forEach(function (chat) { box.appendChild(createReferenceChatItem(chat)); });
        }

        const newUsers = knownUsers.filter(function (u) { return !chatUids.has(String(u.uid)); });
        if (newUsers.length) {
            const title = document.createElement("div");
            title.className = "reference-search-section-title";
            title.textContent = matchingChats.length ? "مستخدمون" : "نتائج البحث";
            box.appendChild(title);
            newUsers.slice(0, 20).forEach(function (user) { box.appendChild(createReferenceUserResult(user, false)); });
        }

        if (!matchingChats.length && !newUsers.length) {
            box.innerHTML = `
                <div class="reference-search-empty">
                    <div class="reference-search-empty-icon">⌕</div>
                    <strong>لا توجد نتائج</strong>
                    <span>جرّب الاسم أو البريد الإلكتروني.</span>
                </div>`;
        }
    }

    async function searchReferenceUsers(query) {
        const firestore = window.db || (typeof db !== "undefined" ? db : null);
        const me = window.currentUser || (typeof currentUser !== "undefined" ? currentUser : null);
        if (!firestore || !me || !query) return;
        const request = ++referenceSearchRequest;
        try {
            const snap = await firestore.collection("users").get();
            if (request !== referenceSearchRequest) return;
            const users = [];
            snap.forEach(function (doc) {
                if (String(doc.id) === String(me.uid)) return;
                users.push({ uid: doc.id, ...(doc.data() || {}) });
            });
            mergeReferenceUsers(users);
            const live = Array.isArray(window.chatOnlineUsers) ? window.chatOnlineUsers : [];
            mergeReferenceUsers(live);
            renderSearchShell(query, users.concat(live));
        } catch (error) {
            console.warn("Reference search users error:", error);
            const live = Array.isArray(window.chatOnlineUsers) ? window.chatOnlineUsers : [];
            mergeReferenceUsers(live);
            renderSearchShell(query, live);
        }
    }

    function renderChats() {
        const box = document.getElementById("referenceChatItems");
        const shell = document.getElementById("referenceChatShell");
        if (!box) return;

        const queryEl = document.getElementById("referenceSearch");
        const query = queryEl ? queryEl.value.trim().toLowerCase() : "";

        if (query) {
            renderSearchShell(query, Object.values(referenceUsers));
            clearTimeout(referenceSearchTimer);
            referenceSearchTimer = setTimeout(function () { searchReferenceUsers(query); }, 120);
            return;
        }

        if (shell) shell.classList.remove("reference-searching");
        let list = referenceChats.slice();
        if (activeReferenceTab === "unread") list = list.filter(function (chat) { return unreadCount(chat) > 0; });
        else if (activeReferenceTab === "groups") list = list.filter(isGroup);

        list.sort(function (a, b) { return chatActivityTime(b) - chatActivityTime(a); });
        box.innerHTML = "";

        if (!list.length) {
            box.innerHTML = `<div class="reference-empty"><div class="reference-empty-icon">💬</div><strong>لا توجد محادثات بعد</strong><span>ابحث عن مستخدم لبدء محادثة جديدة.</span></div>`;
            return;
        }
        const frag = document.createDocumentFragment();
        list.forEach(function (chat) { frag.appendChild(createReferenceChatItem(chat)); });
        box.appendChild(frag);
    }

    async function loadUsers() {
        const firestore = window.db || (typeof db !== "undefined" ? db : null);
        const me = window.currentUser || (typeof currentUser !== "undefined" ? currentUser : null);
        if (!firestore || !me) return;

        try {
            const snap = await firestore.collection("users").get();
            referenceUsers = {};
            snap.forEach(function (doc) {
                referenceUsers[String(doc.id)] = {
                    uid: doc.id,
                    ...doc.data()
                };
            });
        } catch (error) {
            console.error("Reference UI users error:", error);
        }
    }

    async function hydrateReferenceChatUsers(chats) {
        const firestore = window.db || (typeof db !== "undefined" ? db : null);
        if (!firestore || !Array.isArray(chats)) return;
        const ids = new Set();
        chats.forEach(function (chat) {
            const user = otherUser(chat);
            if (user && user._fallback && user.uid && !String(user.uid).startsWith("chat:")) ids.add(String(user.uid));
        });
        for (const uid of ids) {
            if (referenceUsers[uid]) continue;
            try {
                const snap = await firestore.collection("users").doc(uid).get();
                if (snap.exists) referenceUsers[uid] = { uid: snap.id, ...(snap.data() || {}) };
            } catch (error) {
                console.warn("Reference UI user hydrate skipped:", uid, error);
            }
        }
        renderChats();
    }

    function listenChats() {
        const firestore = window.db || (typeof db !== "undefined" ? db : null);
        const me = window.currentUser || (typeof currentUser !== "undefined" ? currentUser : null);
        if (!firestore || !me) return;

        if (referenceUnsub) {
            referenceUnsub();
            referenceUnsub = null;
        }

        referenceUnsub = firestore
            .collection("chats")
            .where("participants", "array-contains", me.uid)
            .onSnapshot(function (snapshot) {
                referenceChats = [];

                snapshot.forEach(function (doc) {
                    const data = doc.data() || {};
                    const participants = Array.isArray(data.participants)
                        ? data.participants
                        : [];

                    if (!participants.map(String).includes(String(me.uid))) return;

                    referenceChats.push({
                        id: doc.id,
                        ...data,
                        participants
                    });
                });

                referenceChats.sort(function (a, b) {
                    return chatActivityTime(b) - chatActivityTime(a);
                });

                const totalUnread = referenceChats.reduce(function (sum, chat) {
                    return sum + unreadCount(chat);
                }, 0);

                const all = document.getElementById("referenceAllCount");
                const unread = document.getElementById("referenceUnreadCount");

                if (all) all.textContent = String(referenceChats.length);
                if (unread) unread.textContent = String(totalUnread);

                renderChats();
                // إذا كانت بيانات users لم تصل بعد، لا نخفي المحادثة؛ نحمّل أصحابها ثم نعيد الرسم.
                hydrateReferenceChatUsers(referenceChats).catch(function (error) {
                    console.warn("Reference UI hydrate error:", error);
                });
            }, function (error) {
                console.error("Reference UI chats error:", error);
                // لا نمسح القائمة عند خطأ مؤقت؛ نحتفظ بآخر حالة صحيحة.
                renderChats();
                const shell = document.getElementById("referenceChatShell");
                if (shell) shell.dataset.syncError = "1";
            });
    }

    function bindEvents() {
        const input = document.getElementById("referenceSearch");
        const original = document.getElementById("userSearch");

        if (input) {
            input.addEventListener("input", function () {
                // البحث الاحترافي مستقل عن بحث المستخدم القديم حتى لا يمسح
                // قائمة المحادثات أو يخفي محادثة جديدة أثناء الكتابة.
                renderChats();
            });
            input.addEventListener("search", function () { renderChats(); });
        }

        document.querySelectorAll(".reference-tab").forEach(function (tab) {
            tab.addEventListener("click", function () {
                activeReferenceTab = tab.dataset.refTab || "all";

                document.querySelectorAll(".reference-tab").forEach(function (x) {
                    x.classList.toggle("active", x === tab);
                });

                renderChats();
            });
        });

        document.querySelectorAll(".reference-nav-item").forEach(function (nav) {
            nav.addEventListener("click", function () {
                document.querySelectorAll(".reference-nav-item").forEach(function (x) {
                    x.classList.toggle("active", x === nav);
                });

                const target = nav.dataset.nav;

                if (target === "settings") {
                    const profileBtn = document.getElementById("profileBtn");
                    if (profileBtn) profileBtn.click();
                } else if (target === "calls") {
                    if (typeof closeChat === "function") closeChat();
                    const shell = document.getElementById("referenceChatShell");
                    if (shell) {
                        const list = document.getElementById("referenceChatItems");
                        if (list) {
                            list.innerHTML = `
                                <div class="reference-calls-panel">
                                    <div class="reference-calls-icon">☎</div>
                                    <h3>المكالمات</h3>
                                    <p>ابدأ مكالمة صوتية من داخل أي محادثة باستخدام زر الهاتف.</p>
                                    <button type="button" class="reference-calls-action" id="openCallsChatBtn">فتح الدردشات</button>
                                </div>`;
                            const openChats = document.getElementById("openCallsChatBtn");
                            if (openChats) openChats.addEventListener("click", function () {
                                const chatNav = document.querySelector('.reference-nav-item[data-nav="chats"]');
                                if (chatNav) chatNav.click();
                                renderChats();
                            });
                        }
                    }
                } else if (target === "chats") {
                    renderChats();
                }
            });
        });

        const fab = document.querySelector(".reference-fab");
        if (fab) {
            fab.addEventListener("click", function () {
                const input = document.getElementById("referenceSearch");
                if (input) {
                    input.focus();
                    input.scrollIntoView({ behavior: "smooth", block: "center" });
                }
            });
        }
    }

    let referenceAuthStarted = false;
    let referenceDataUser = null;

    async function startReferenceData(user) {
        if (!user) {
            referenceChats = [];

            const all = document.getElementById("referenceAllCount");
            const unread = document.getElementById("referenceUnreadCount");

            if (all) all.textContent = "0";
            if (unread) unread.textContent = "0";

            renderChats();
            return;
        }

        referenceDataUser = user;

        /*
         * مهم:
         * واجهة المحادثات كانت تُنشأ عند DOMContentLoaded فقط.
         * في تلك اللحظة قد لا يكون Firebase Auth قد أعاد المستخدم
         * بعد، وبالتالي كانت listenChats() تتوقف ولا تعاود التشغيل.
         *
         * الآن ننتظر حالة Firebase Auth ثم نبدأ الاستماع فعليًا.
         */
        await loadUsers();
        listenChats();
    }

    function watchReferenceAuth() {
        if (referenceAuthStarted) {
            return;
        }

        referenceAuthStarted = true;

        if (
            typeof firebase === "undefined" ||
            !firebase.auth
        ) {
            return;
        }

        try {
            firebase.auth().onAuthStateChanged(function (user) {
                startReferenceData(user).catch(function (error) {
                    console.error(
                        "Reference UI auth startup error:",
                        error
                    );
                });
            });
        } catch (error) {
            console.error(
                "Reference UI Firebase Auth error:",
                error
            );
        }
    }

    async function initReferenceUI() {
        const shell = createShell();
        if (!shell) return;

        renderStories();
        bindEvents();

        /*
         * لا نستدعي listenChats هنا مباشرة.
         * Firebase Auth قد لا يكون جاهزًا بعد.
         */
        watchReferenceAuth();

        // تحديث فقاعات القصص عند وصول المستخدمين من Firebase.
        let signature = "";
        setInterval(function () {
            const users = Array.isArray(window.chatOnlineUsers)
                ? window.chatOnlineUsers
                : [];

            const next = users.map(function (u) {
                return String(u.uid) + "|" + String(u.name) + "|" + String(u.photoURL);
            }).join(",");

            if (next !== signature) {
                signature = next;
                renderStories();

                /*
                 * إذا أصبحت هوية المستخدم متاحة بعد إنشاء الواجهة،
                 * نضمن أن المستمع يعمل حتى لو فات حدث Auth الأول.
                 */
                const me =
                    window.currentUser ||
                    (typeof currentUser !== "undefined"
                        ? currentUser
                        : null);

                if (
                    me &&
                    (!referenceDataUser ||
                        String(referenceDataUser.uid) !== String(me.uid))
                ) {
                    startReferenceData(me).catch(function (error) {
                        console.error(
                            "Reference UI refresh error:",
                            error
                        );
                    });
                }
            }
        }, 800);
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", initReferenceUI);
    } else {
        initReferenceUI();
    }
})();


document.addEventListener("DOMContentLoaded", function () { setupChatUserInfo(); });
/* =========================================================
   ChatOnline v33 — Account Follow System
   - Follow state belongs to Firebase account UID, not device.
   - Public profile preview for searched users.
   - Follow -> saves the relationship only; chat opens only from the Chat button.
   ========================================================= */
(function () {
    "use strict";

    function el(id) { return document.getElementById(id); }
    function firestore() { return window.db || (typeof db !== "undefined" ? db : null); }
    function me() { return window.currentUser || (typeof currentUser !== "undefined" ? currentUser : null); }

    function followId(followerUid, followingUid) {
        return String(followerUid) + "_" + String(followingUid);
    }

    function followRef(followerUid, followingUid) {
        const fs = firestore();
        return fs.collection("follows").doc(followId(followerUid, followingUid));
    }

    async function isFollowing(uid) {
        const user = me();
        const fs = firestore();
        if (!user || !fs || !uid || String(user.uid) === String(uid)) return false;
        try {
            const snap = await followRef(user.uid, uid).get();
            return snap.exists;
        } catch (error) {
            console.warn("Follow state read failed:", error);
            return false;
        }
    }

    async function setFollowing(target, shouldFollow) {
        const user = me();
        const fs = firestore();
        if (!user || !fs || !target || !target.uid || String(user.uid) === String(target.uid)) {
            throw new Error("بيانات المتابعة غير مكتملة.");
        }

        const ref = followRef(user.uid, target.uid);
        if (shouldFollow) {
            await ref.set({
                followerUid: user.uid,
                followingUid: target.uid,
                createdAt: firebase.firestore.FieldValue.serverTimestamp(),
                updatedAt: firebase.firestore.FieldValue.serverTimestamp()
            }, { merge: true });
        } else {
            await ref.delete();
        }
        return shouldFollow;
    }

    async function countFollowers(uid) {
        const fs = firestore();
        if (!fs || !uid) return 0;
        try {
            const snap = await fs.collection("follows")
                .where("followingUid", "==", String(uid))
                .get();
            return snap.size;
        } catch (error) {
            console.warn("Followers count unavailable:", error);
            return null;
        }
    }

    async function countFollowing(uid) {
        const fs = firestore();
        if (!fs || !uid) return 0;
        try {
            const snap = await fs.collection("follows")
                .where("followerUid", "==", String(uid))
                .get();
            return snap.size;
        } catch (error) {
            console.warn("Following count unavailable:", error);
            return null;
        }
    }

    async function getFollowStats(uid) {
        const [followers, following] = await Promise.all([
            countFollowers(uid),
            countFollowing(uid)
        ]);
        return { followers: followers, following: following };
    }

    function ensureFollowModal() {
        let modal = el("followProfileModal");
        if (modal) return modal;

        modal = document.createElement("div");
        modal.id = "followProfileModal";
        modal.className = "follow-profile-modal hidden";
        modal.innerHTML = `
            <div class="follow-profile-backdrop" data-follow-close="1"></div>
            <section class="follow-profile-card" role="dialog" aria-modal="true" aria-labelledby="followProfileName">
                <button class="follow-profile-close" type="button" aria-label="إغلاق" data-follow-close="1">×</button>
                <div id="followProfileAvatar" class="follow-profile-avatar">👤</div>
                <div class="follow-profile-public">حساب عام</div>
                <h2 id="followProfileName">المستخدم</h2>
                <p id="followProfileEmail"></p>
                <div class="follow-profile-meta">
                    <span><strong id="followProfileFollowers">—</strong> متابع</span>
                    <span id="followProfileState">غير متابَع</span>
                </div>
                <div class="follow-profile-actions">
                    <button id="followProfileBtn" class="follow-primary-btn" type="button">＋ متابعة</button>
                    <button id="followProfileChatBtn" class="follow-secondary-btn" type="button">💬 محادثة</button>
                </div>
            </section>
        `;
        document.body.appendChild(modal);

        modal.querySelectorAll("[data-follow-close]").forEach(function (button) {
            button.addEventListener("click", closePublicProfile);
        });
        document.addEventListener("keydown", function (event) {
            if (event.key === "Escape" && !modal.classList.contains("hidden")) closePublicProfile();
        });
        return modal;
    }

    let publicProfileUser = null;

    async function openPublicProfile(user) {
        const current = me();
        if (!current || !user || !user.uid || String(current.uid) === String(user.uid)) return;

        publicProfileUser = user;
        const modal = ensureFollowModal();
        const avatar = el("followProfileAvatar");
        const name = el("followProfileName");
        const email = el("followProfileEmail");
        const followBtn = el("followProfileBtn");
        const chatBtn = el("followProfileChatBtn");
        const state = el("followProfileState");

        name.textContent = user.name || "مستخدم";
        email.textContent = user.email || "";
        if (user.photoURL) {
            avatar.style.backgroundImage = 'url("' + String(user.photoURL).replace(/"/g, "&quot;") + '")';
            avatar.style.backgroundSize = "cover";
            avatar.style.backgroundPosition = "center";
            avatar.textContent = "";
        } else {
            avatar.style.backgroundImage = "";
            avatar.textContent = String(user.name || "مستخدم").trim().charAt(0).toUpperCase() || "👤";
        }

        modal.classList.remove("hidden");
        document.body.classList.add("public-profile-open");
        followBtn.disabled = true;
        followBtn.textContent = "جاري التحقق…";
        state.textContent = "جاري التحقق…";

        const [following, followers, followingCount] = await Promise.all([
            isFollowing(user.uid),
            countFollowers(user.uid),
            countFollowing(user.uid)
        ]);

        if (publicProfileUser !== user) return;
        followBtn.disabled = false;
        followBtn.dataset.following = following ? "1" : "0";
        followBtn.textContent = following ? "✓ متابَع" : "＋ متابعة";
        followBtn.classList.toggle("is-following", following);
        state.textContent = following ? "أنت تتابع هذا الحساب" : "يمكنك متابعة هذا الحساب";
        el("followProfileFollowers").textContent = followers === null ? "—" : String(followers);
        el("followProfileFollowing").textContent = followingCount === null ? "—" : String(followingCount);

        followBtn.onclick = async function () {
            if (!publicProfileUser || followBtn.disabled) return;
            const next = followBtn.dataset.following !== "1";
            followBtn.disabled = true;
            followBtn.textContent = next ? "جاري المتابعة…" : "جاري الإلغاء…";
            try {
                await setFollowing(publicProfileUser, next);
                followBtn.dataset.following = next ? "1" : "0";
                followBtn.textContent = next ? "✓ متابَع" : "＋ متابعة";
                followBtn.classList.toggle("is-following", next);
                state.textContent = next ? "أنت تتابع هذا الحساب" : "يمكنك متابعة هذا الحساب";

                const [freshCount, freshFollowingCount] = await Promise.all([
                    countFollowers(publicProfileUser.uid),
                    countFollowing(publicProfileUser.uid)
                ]);
                el("followProfileFollowers").textContent = freshCount === null ? "—" : String(freshCount);
                el("followProfileFollowing").textContent = freshFollowingCount === null ? "—" : String(freshFollowingCount);
                followBtn.disabled = false;
            } catch (error) {
                console.error("Follow action failed:", error);
                followBtn.disabled = false;
                followBtn.dataset.following = next ? "0" : "1";
                followBtn.textContent = next ? "＋ متابعة" : "✓ متابَع";
                followBtn.classList.toggle("is-following", !next);
                if (typeof showMessage === "function") {
                    const code = error && error.code ? String(error.code) : "";
                    const text = code.indexOf("permission-denied") !== -1
                        ? "تم رفض حفظ المتابعة من Firestore. انشر قواعد firestore.rules المرفقة مع v37 ثم أعد المحاولة."
                        : "تعذر حفظ المتابعة. تحقق من اتصال Firebase ثم حاول مرة أخرى.";
                    showMessage(text, "error");
                }
            }
        };

        chatBtn.onclick = async function () {
            if (!publicProfileUser) return;
            closePublicProfile();
            if (typeof openChat === "function") await openChat(publicProfileUser);
        };
    }

    function closePublicProfile() {
        const modal = el("followProfileModal");
        if (modal) modal.classList.add("hidden");
        document.body.classList.remove("public-profile-open");
        publicProfileUser = null;
    }

    function enhanceUserCards() {
        const list = el("usersList");
        if (!list) return;
        list.querySelectorAll(".user-card").forEach(function (card) {
            const uid = card.dataset.uid;
            if (!uid || card.dataset.followEnhanced === "1") return;
            const user = (window.chatOnlineUsers || []).find(function (item) {
                return String(item.uid) === String(uid);
            });
            if (!user) return;

            /* renderUsers الحديثة تبني أزرار المتابعة مباشرةً. */
            if (card.querySelector(".user-card-actions")) {
                card.dataset.followEnhanced = "1";
                return;
            }

            card.dataset.followEnhanced = "1";
            const info = card.querySelector(".user-info");
            const avatar = card.querySelector(".user-avatar");
            const existingChat = card.querySelector("button");
            const actions = document.createElement("div");
            actions.className = "user-card-actions";

            if (existingChat) {
                existingChat.classList.add("user-chat-btn");
                existingChat.parentNode.removeChild(existingChat);
                actions.appendChild(existingChat);
            }

            const follow = document.createElement("button");
            follow.type = "button";
            follow.className = "follow-card-btn";
            follow.textContent = "＋ متابعة";
            follow.addEventListener("click", function (event) {
                event.preventDefault();
                event.stopPropagation();
                openPublicProfile(user);
            });
            actions.appendChild(follow);
            card.appendChild(actions);

            [avatar, info].forEach(function (node) {
                if (!node) return;
                node.style.cursor = "pointer";
                node.addEventListener("click", function (event) {
                    event.preventDefault();
                    event.stopPropagation();
                    openPublicProfile(user);
                });
            });

            isFollowing(uid).then(function (following) {
                follow.textContent = following ? "✓ متابَع" : "＋ متابعة";
                follow.classList.toggle("is-following", following);
            });
        });
    }

    function enhanceRenderedUsers() {
        setTimeout(enhanceUserCards, 0);
        setTimeout(enhanceUserCards, 250);
        setTimeout(enhanceUserCards, 800);
    }

    function install() {
        ensureFollowModal();
        if (typeof window.renderUsers === "function" && !window.renderUsers.__followEnhanced) {
            const original = window.renderUsers;
            const wrapped = (...args) => {
                const result = original.apply(null, args);
                enhanceRenderedUsers();
                return result;
            };
            wrapped.__followEnhanced = true;
            window.renderUsers = wrapped;
        }
        enhanceRenderedUsers();
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", function () {
            setTimeout(install, 50);
            setTimeout(install, 500);
            setTimeout(install, 1500);
        });
    } else {
        setTimeout(install, 50);
        setTimeout(install, 500);
        setTimeout(install, 1500);
    }

    if (window.__pendingFollowProfile) {
        const pending = window.__pendingFollowProfile;
        window.__pendingFollowProfile = null;
        setTimeout(function () { openPublicProfile(pending); }, 0);
    }

    window.ChatOnlineFollow = {
        openProfile: openPublicProfile,
        closeProfile: closePublicProfile,
        isFollowing: isFollowing,
        getFollowStats: getFollowStats,
        follow: function (user) { return setFollowing(user, true); },
        unfollow: function (user) { return setFollowing(user, false); }
    };
})();
