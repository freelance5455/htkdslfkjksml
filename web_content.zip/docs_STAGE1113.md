# CPLS Stage 1113 — Futures Trade-Chart Fix

- Futures chart size is aligned with the Trade chart (mobile 255px, 220px on very small screens).
- Futures candlestick rendering now uses the same visual geometry: grid, candles, volume strip, current-price guide, price scale and EMA7.
- Futures no longer falls back to fabricated candles or Spot K-Line data.
- It first attempts the existing LBank contract K-Line path; when unavailable, it builds candles only from real Futures price samples received from the documented Futures market-data endpoint.
- Futures page reads `symbol` from the URL and no longer mixes the Spot WebSocket ticker into the Futures price feed.
- Timeframe switching rebuilds the live session candles from real Futures samples.
