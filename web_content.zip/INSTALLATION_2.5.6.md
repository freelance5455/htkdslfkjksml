# ANONYMOUX STUDIO 2.5.7 — deployment and administrator setup

1. Back up the existing site files, `storage/` directory and SQLite database before replacing any files.
2. Extract the ZIP into the application directory. Preserve the production `config.local.php`, `storage/` contents and `storage/workspace.sqlite`; never replace them with example files.
3. Enable PHP 8+, PDO, **PDO_SQLite (`pdo_sqlite`)**, cURL, OpenSSL, JSON and fileinfo. This build uses SQLite; do not configure MySQL as the application database. Use HTTPS.
4. Configure the private `config.local.php` and verify that `storage/` is outside public access or denied by the web server. Apache deployments should retain the supplied `.htaccess`; Nginx deployments must add equivalent deny rules for `/storage/`, `config.local.php` and private files.
5. On a new installation, create the first administrator from the hosting shell. Set the password in the environment rather than placing it in shell history:

   ```sh
   export ANONYMOUX_ADMIN_PASSWORD='use-a-unique-password-of-at-least-12-characters'
   php tools-create-admin.php admin@example.com "Site Administrator"
   unset ANONYMOUX_ADMIN_PASSWORD
   ```

   This script is CLI-only and refuses to create a second administrator. Public signups always receive the `member` role. For a verified existing account that has lost admin access, use `php tools-recover-admin.php admin@example.com` from the hosting shell.
6. In Admin → Voice AI, confirm at least one encrypted Fish Audio API key is active. Configure conversation USD/minute and ANON credits per USD only after verifying provider pricing, exchange rate and markup. A value of 0 records usage without wallet debits.
7. Create a draft agent, select a voice, save its instructions, publish it, then test text and microphone sessions. Browser microphone access requires HTTPS and a user click.
8. End a test session and inspect usage reconciliation. Repeat reconciliation only when provider usage has not finalized.
9. In Admin → Payments, verify Flutterwave in test mode, test checkout and signed webhook handling, then switch to live only after staging acceptance.
10. Verify Dashboard, Explore, Tools & Tutorials, Credits, Voice Studio, Agent Studio and existing creative workspaces on mobile and desktop. In Admin → Tools & Tutorials, test tool creation, logo upload, draft/publish, search, categories, bulk actions and tutorial relations.

Do not copy API keys into HTML or JavaScript. Never overwrite the production database or uploaded storage. Do not expose the CLI administrator scripts through a web server; they return 404 to HTTP requests, but should still be removed from the web root after setup if your hosting policy requires it.
