alter table public.properties drop constraint properties_description_check;
alter table public.properties add constraint properties_description_check check (char_length(description) between 10 and 3000);
