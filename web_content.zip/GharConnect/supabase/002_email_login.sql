-- Email login + compulsory contact phone (schema.sql ke baad run hota hai; GharConnect project par pehle se apply hai)
alter table public.profiles add column email text;
update public.profiles p set email=u.email from auth.users u where u.id=p.id;
alter table public.profiles add constraint profiles_phone_fmt check (phone is null or phone ~ '^\+923[0-9]{9}$');

create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into profiles(id,full_name,email,role) values (new.id, left(new.raw_user_meta_data->>'full_name',80), new.email,
    case when new.raw_user_meta_data->>'role'='owner' then 'owner' else 'tenant' end);
  return new;
end $$;

create or replace function public.guard_profile() returns trigger language plpgsql security definer set search_path=public as $$
begin
  if auth.uid() is not null and not is_admin() then
    new.id:=old.id; new.role:=old.role; new.is_suspended:=old.is_suspended; new.email:=old.email;
  end if; return new;
end $$;

drop policy props_insert on public.properties;
create policy props_insert on public.properties for insert to authenticated
  with check (owner_id=(select auth.uid()) and is_active_user()
    and exists(select 1 from profiles pr where pr.id=(select auth.uid()) and pr.phone is not null)
    and exists(select 1 from cities c where c.name=city and c.is_active));

alter table public.rental_requests add column contact_phone text not null check (contact_phone ~ '^\+923[0-9]{9}$');
