-- Sab naye accounts "user" role se bante hain (rent bhi, listing bhi). Admin sirf SQL se banta hai.
alter table public.profiles drop constraint profiles_role_check;
update public.profiles set role='user' where role in ('tenant','owner');
alter table public.profiles alter column role set default 'user';
alter table public.profiles add constraint profiles_role_check check (role in ('user','admin'));
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into profiles(id,full_name,email) values (new.id, left(new.raw_user_meta_data->>'full_name',80), new.email);
  return new;
end $$;
