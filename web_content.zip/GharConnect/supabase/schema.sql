-- GharConnect schema. Supabase Dashboard > SQL Editor mein poora run karein.
create table public.cities(name text primary key, is_active boolean not null default true);
insert into public.cities(name) values ('Lahore'),('Islamabad'),('Karachi'),('Rawalpindi'),('Faisalabad'),('Multan');

create table public.profiles(
  id uuid primary key references auth.users on delete cascade,
  full_name text, phone text,
  role text not null default 'tenant' check (role in ('tenant','owner','admin')),
  is_suspended boolean not null default false,
  created_at timestamptz not null default now());

create function public.is_admin() returns boolean language sql stable security definer set search_path=public as
$$ select exists(select 1 from profiles where id=(select auth.uid()) and role='admin' and not is_suspended) $$;
create function public.is_active_user() returns boolean language sql stable security definer set search_path=public as
$$ select exists(select 1 from profiles where id=(select auth.uid()) and not is_suspended) $$;

create function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into profiles(id,full_name,phone,role) values (new.id, left(new.raw_user_meta_data->>'full_name',80),
    case when new.phone is not null then '+'||new.phone end,
    case when new.raw_user_meta_data->>'role'='owner' then 'owner' else 'tenant' end);
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

create function public.guard_profile() returns trigger language plpgsql security definer set search_path=public as $$
begin
  if auth.uid() is not null and not is_admin() then
    new.id:=old.id; new.role:=old.role; new.is_suspended:=old.is_suspended; new.phone:=old.phone;
  end if; return new;
end $$;
create trigger guard_profile before update on public.profiles for each row execute function public.guard_profile();

create table public.properties(
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null default auth.uid() references public.profiles(id) on delete cascade,
  title text not null check (char_length(title) between 5 and 120),
  property_type text not null check (property_type in ('House','Flat','Apartment','Portion','Room','Hostel','Other')),
  city text not null references public.cities(name) on update cascade,
  area text not null check (char_length(area) between 2 and 80),
  monthly_rent integer not null check (monthly_rent between 1000 and 10000000),
  security_deposit integer check (security_deposit >= 0),
  bedrooms smallint not null default 1 check (bedrooms between 0 and 10),
  bathrooms smallint not null default 1 check (bathrooms between 1 and 10),
  covered_area text, available_from date,
  description text not null check (char_length(description) between 20 and 3000),
  status text not null default 'pending' check (status in ('pending','published','rejected','hidden')),
  tag text, rejection_reason text, published_at timestamptz,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now());
create index on public.properties(status, city, monthly_rent);
create index on public.properties(owner_id);

create function public.guard_property() returns trigger language plpgsql security definer set search_path=public as $$
begin
  new.updated_at := now();
  if auth.uid() is not null and not is_admin() then
    if tg_op='INSERT' then
      if (select count(*) from properties where owner_id=auth.uid() and status='pending')>=10 then raise exception 'Bohat saari pending listings hain'; end if;
      new.status:='pending'; new.owner_id:=auth.uid(); new.tag:=null; new.rejection_reason:=null;
    else
      new.owner_id:=old.owner_id; new.tag:=old.tag; new.rejection_reason:=old.rejection_reason;
      if new.status<>old.status and not (new.status='hidden' and old.status in ('published','pending'))
         and not (new.status='pending' and old.status in ('hidden','rejected')) then new.status:=old.status; end if;
      if old.status='published' and new.status='published' and
         (new.title,new.description,new.monthly_rent,new.city,new.area) is distinct from (old.title,old.description,old.monthly_rent,old.city,old.area)
      then new.status:='pending'; end if;
    end if;
  end if;
  if new.status='published' and (tg_op='INSERT' or old.status<>'published') then new.published_at:=now(); end if;
  return new;
end $$;
create trigger guard_property before insert or update on public.properties for each row execute function public.guard_property();

create table public.property_images(
  id uuid primary key default gen_random_uuid(),
  property_id uuid not null references public.properties on delete cascade,
  storage_path text not null, sort_order smallint not null default 0);
create index on public.property_images(property_id);

create table public.favorites(
  user_id uuid not null default auth.uid() references public.profiles on delete cascade,
  property_id uuid not null references public.properties on delete cascade,
  primary key(user_id, property_id));

create sequence public.rr_seq;
create table public.rental_requests(
  id uuid primary key default gen_random_uuid(),
  request_code text not null unique default 'GC-'||extract(year from now())::int||'-'||lpad(nextval('public.rr_seq')::text,4,'0'),
  property_id uuid not null references public.properties on delete cascade,
  tenant_id uuid not null default auth.uid() references public.profiles(id) on delete cascade,
  preferred_visit_date date, message text check (char_length(message)<=500),
  status text not null default 'new' check (status in ('new','in_review','visit_scheduled','completed','rejected','cancelled')),
  created_at timestamptz not null default now());
create unique index on public.rental_requests(tenant_id, property_id) where status in ('new','in_review','visit_scheduled');

create table public.audit_logs(
  id bigint generated always as identity primary key,
  actor_id uuid, action text, entity text, entity_id text, details jsonb,
  created_at timestamptz not null default now());

create function public.log_admin_change() returns trigger language plpgsql security definer set search_path=public as $$
begin
  if is_admin() then
    insert into audit_logs(actor_id,action,entity,entity_id,details)
    values (auth.uid(), tg_op||' '||tg_table_name, tg_table_name, coalesce(to_jsonb(new)->>'id', to_jsonb(new)->>'name'), to_jsonb(new)-'description');
  end if; return new;
end $$;
create trigger audit after update on public.properties for each row execute function public.log_admin_change();
create trigger audit after update on public.rental_requests for each row execute function public.log_admin_change();
create trigger audit after update on public.profiles for each row execute function public.log_admin_change();
create trigger audit after update on public.cities for each row execute function public.log_admin_change();

create function public.admin_stats() returns json language plpgsql stable security definer set search_path=public as $$
begin
  if not is_admin() then raise exception 'forbidden'; end if;
  return json_build_object('users',(select count(*) from profiles),'properties',(select count(*) from properties),
    'pending',(select count(*) from properties where status='pending'),
    'requests',(select count(*) from rental_requests where status='new'));
end $$;
revoke execute on function public.admin_stats() from public, anon;
revoke execute on function public.handle_new_user(), public.guard_profile(), public.guard_property(), public.log_admin_change() from public, anon, authenticated;

-- RLS
alter table public.cities enable row level security;
alter table public.profiles enable row level security;
alter table public.properties enable row level security;
alter table public.property_images enable row level security;
alter table public.favorites enable row level security;
alter table public.rental_requests enable row level security;
alter table public.audit_logs enable row level security;

create policy cities_read on public.cities for select using (true);
create policy cities_admin on public.cities for update to authenticated using (is_admin()) with check (is_admin());

create policy profiles_read on public.profiles for select to authenticated using (id=(select auth.uid()) or is_admin());
create policy profiles_update on public.profiles for update to authenticated using (id=(select auth.uid()) or is_admin());

create policy props_read on public.properties for select using (status='published' or owner_id=(select auth.uid()) or is_admin());
create policy props_insert on public.properties for insert to authenticated
  with check (owner_id=(select auth.uid()) and is_active_user() and exists(select 1 from cities c where c.name=city and c.is_active));
create policy props_update on public.properties for update to authenticated using (owner_id=(select auth.uid()) or is_admin()) with check (owner_id=(select auth.uid()) or is_admin());
create policy props_delete on public.properties for delete to authenticated using (owner_id=(select auth.uid()) or is_admin());

create policy img_read on public.property_images for select using (exists(select 1 from properties p where p.id=property_id));
create policy img_insert on public.property_images for insert to authenticated
  with check (exists(select 1 from properties p where p.id=property_id and p.owner_id=(select auth.uid())));
create policy img_delete on public.property_images for delete to authenticated
  using (exists(select 1 from properties p where p.id=property_id and (p.owner_id=(select auth.uid()) or is_admin())));

create policy fav_all on public.favorites for all to authenticated using (user_id=(select auth.uid())) with check (user_id=(select auth.uid()));

create policy rr_read on public.rental_requests for select to authenticated using (tenant_id=(select auth.uid()) or is_admin());
create policy rr_insert on public.rental_requests for insert to authenticated
  with check (tenant_id=(select auth.uid()) and status='new' and is_active_user()
    and exists(select 1 from properties p where p.id=property_id and p.status='published'));
create policy rr_admin_update on public.rental_requests for update to authenticated using (is_admin()) with check (is_admin());

create policy audit_read on public.audit_logs for select to authenticated using (is_admin());

-- Storage
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values ('property-images','property-images',true,5242880,array['image/jpeg','image/png','image/webp']) on conflict (id) do nothing;
create policy "pi_insert" on storage.objects for insert to authenticated
  with check (bucket_id='property-images' and (storage.foldername(name))[1]=(select auth.uid())::text and public.is_active_user());
create policy "pi_select" on storage.objects for select to authenticated
  using (bucket_id='property-images' and ((storage.foldername(name))[1]=(select auth.uid())::text or public.is_admin()));
create policy "pi_delete" on storage.objects for delete to authenticated
  using (bucket_id='property-images' and ((storage.foldername(name))[1]=(select auth.uid())::text or public.is_admin()));
