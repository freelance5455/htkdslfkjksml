// App download strip: site khulte hi top par aata hai, ✕ se band hota hai, 2 minute baad dobara aata hai.
// Test ke liye site ke link ke aakhir mein ?apk=1 lagayein: strip foran dikhegi, aur hidden hone ki wajah console mein likhi aayegi.
(()=>{
 const MS=(window.GC_CONFIG&&window.GC_CONFIG.APK_REAPPEAR_MS)||120000;
 const ua=navigator.userAgent;
 const force=/[?&]apk=1/.test(location.search);
 const skip=location.protocol==='file:'||location.hostname==='appassets.androidplatform.net'||(window.matchMedia&&matchMedia('(display-mode: standalone)').matches);
 if(skip&&!force){console.info('[gc-install] hidden: local file / app ke andar chal rahi site');return}
 // Download click counter: har device din mein ek dafa ginta hai (Supabase apk_downloads).
 function track(){
  try{
   const c=window.GC_CONFIG||{};if(!c.SUPABASE_URL||!c.SUPABASE_ANON_KEY)return;
   let id=localStorage.getItem('gc_device_id');
   if(!id){id=(crypto.randomUUID?crypto.randomUUID():String(Date.now())+Math.random().toString(16).slice(2));localStorage.setItem('gc_device_id',id)}
   fetch(c.SUPABASE_URL+'/rest/v1/apk_downloads',{method:'POST',keepalive:true,headers:{apikey:c.SUPABASE_ANON_KEY,Authorization:'Bearer '+c.SUPABASE_ANON_KEY,'Content-Type':'application/json',Prefer:'return=minimal'},body:JSON.stringify({device_id:id})}).catch(()=>{});
  }catch(e){}
 }
 const KEY='gc_apk_closed_at';
 const store={get(){try{return +localStorage.getItem(KEY)||0}catch(e){return 0}},set(v){try{localStorage.setItem(KEY,String(v))}catch(e){}}};
 let bar=null,timer=null;
 function hide(){if(bar){bar.remove();bar=null}store.set(Date.now());clearTimeout(timer);timer=setTimeout(show,MS)}
 function show(){
  clearTimeout(timer);if(bar)return;
  bar=document.createElement('div');bar.id='gcInstallBar';
  bar.style.cssText='display:flex;align-items:center;gap:10px;flex-wrap:wrap;justify-content:center;padding:9px 44px 9px 14px;background:#0b2e2a;color:#fff;font:600 14px/1.3 system-ui,sans-serif;position:relative;z-index:9999';
  const t=document.createElement('span');t.textContent='📱 GharConnect Android app download karein';
  const a=document.createElement('a');a.href='GharConnect.apk';a.setAttribute('download','GharConnect.apk');a.textContent='Download APK';
  a.style.cssText='background:#16c79a;color:#06231f;padding:7px 14px;border-radius:999px;text-decoration:none;font-weight:700';
  const x=document.createElement('button');x.type='button';x.setAttribute('aria-label','Close');x.textContent='✕';
  x.style.cssText='position:absolute;right:8px;top:50%;transform:translateY(-50%);width:30px;height:30px;border:0;border-radius:50%;background:rgba(255,255,255,.15);color:#fff;font-size:16px;cursor:pointer';
  a.addEventListener('click',track);
  x.onclick=hide;bar.append(t,a,x);document.body.insertBefore(bar,document.body.firstChild);
 }
 if(force)store.set(0);
 const left=MS-(Date.now()-store.get());
 const go=()=>{if(left<=0)show();else{console.info('[gc-install] 2 minute ke wait mein, '+Math.ceil(left/1000)+'s baad dikhegi');timer=setTimeout(show,left)}};
 if(document.body)go();else document.addEventListener('DOMContentLoaded',go);
})();
