// GharConnect Supabase project. Sirf anon key (public) yahan hai; service_role key kabhi nahi.
window.GC_CONFIG = {
  SUPABASE_URL: "https://ouutxfflvhamhhwrrvnb.supabase.co",
  SUPABASE_ANON_KEY: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im91dXR4ZmZsdmhhbWhod3Jydm5iIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTE5Njk3NjIsImV4cCI6MjEwNzU0NTc2Mn0.S5c70mQBFC2PzkdTOsxZOfc0jN0oX9_Ins2cznPxQNs"
};
