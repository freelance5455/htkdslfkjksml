# GharConnect + Supabase (backend already applied)

Project "GharConnect" (ouutxfflvhamhhwrrvnb) mein schema apply ho chuka hai aur `config.js` mein URL/anon key bhari hui hai. Aap ko sirf neeche ke steps 3-5 karne hain.
3. **Authentication > Sign In / Providers > Email**: "Confirm email" OFF karein (taake bina verification ke login ho). Phone provider ki zaroorat nahi.
4. Pehla admin: app mein email se register karein, phir SQL Editor mein:
   `update public.profiles set role='admin' where email='aap@example.com';`
5. `index.html` kisi bhi static host (Netlify, Vercel, Cloudflare Pages) par deploy karein, ya local server se kholen. Authentication > URL Configuration mein apna site URL add karein.

Privacy: public queries sirf `published` listings dekhti hain, phone numbers sirf owner/admin tak (RLS). Role, suspend aur listing status server-side triggers se protected hain.

Abhi shamil nahi: listing edit, "My requests" page.

Login email + password se hota hai (koi OTP ya SMS nahi). Mobile number sirf tab lazmi hai jab user listing submit kare ya rental request bheje; wo sirf admin ko nazar aata hai. `supabase/002_email_login.sql` ye tabdeeli karti hai (schema.sql ke baad).

Admin system: main admin (is_super_admin) sab kuch kar sakta hai aur Users tab se kisi user ko admin bana kar usay sirf chuni hui permissions de sakta hai. Second admin sirf wahi badal sakta hai jo main admin ne tick ki ho (DB level par enforce). Property owner apni listing hide / rented / delete kar sakta hai ("My listings").

Locations: listing submit aur signup/login par browser location mangta hai. Property ki exact location (property_locations) aur user ki location (user_locations) sirf admin ko nazar aati hai (Admin > Map, OpenStreetMap + Leaflet). Off ki hui city dropdown, popular cities aur public listings se hat jati hai.

App download banner: `gc-install.js` site khulte hi top par "Download APK" strip dikhata hai (✕ se band, 2 minute baad dobara). APK file `GharConnect.apk` hai; `_headers` file Cloudflare Pages/Netlify par APK ko sahi download type deti hai. Test ke liye site ke link ke aakhir mein `?apk=1` lagayein. Dobara dikhne ka waqt config.js mein `APK_REAPPEAR_MS` (milliseconds) se badal sakte hain.

APK download counter: "Download APK" button dabane par `apk_downloads` table mein ek entry jati hai (ek device din mein ek dafa). Admin > "App Downloads" tab mein total clicks, alag devices, aaj aur pichle 14 din dikhte hain. Ye button ke clicks hain, asal install nahi.

App-style UI: phone ya installed app (aur APK) mein `app-ui.css` + `app-ui.js` "app mode" laga dete hain (compact home, bottom tab bar, bottom-sheet login, horizontal chips aur cities, loading skeleton). Desktop par website jaisa hi rehta hai. `manifest.webmanifest` + icons ki wajah se Chrome mein "Add to Home screen" se ye app ki tarah full-screen khulti hai. Search tab ab apne filters se real listings dikhata hai.

Change password: login ke baad Account (ya navbar "My listings") sheet mein "🔑 Change password". Naya password 2 dafa likhna hota hai, eye button se dekh sakte hain.
