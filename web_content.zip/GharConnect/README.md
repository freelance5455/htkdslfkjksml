# GharConnect + Supabase (backend already applied)

Project "GharConnect" (ouutxfflvhamhhwrrvnb) mein schema apply ho chuka hai aur `config.js` mein URL/anon key bhari hui hai. Aap ko sirf neeche ke steps 3-5 karne hain.
3. **Authentication > Sign In / Providers > Email**: "Confirm email" OFF karein (taake bina verification ke login ho). Phone provider ki zaroorat nahi.
4. Pehla admin: app mein email se register karein, phir SQL Editor mein:
   `update public.profiles set role='admin' where email='aap@example.com';`
5. `index.html` kisi bhi static host (Netlify, Vercel, Cloudflare Pages) par deploy karein, ya local server se kholen. Authentication > URL Configuration mein apna site URL add karein.

Privacy: public queries sirf `published` listings dekhti hain, phone numbers sirf owner/admin tak (RLS). Role, suspend aur listing status server-side triggers se protected hain.

Abhi shamil nahi: listing edit, "My requests" page.

Login email + password se hota hai (koi OTP ya SMS nahi). Mobile number sirf tab lazmi hai jab user listing submit kare ya rental request bheje; wo sirf admin ko nazar aata hai. `supabase/002_email_login.sql` ye tabdeeli karti hai (schema.sql ke baad).

Admin system: main admin (is_super_admin) sab kuch kar sakta hai aur Users tab se kisi user ko admin bana kar usay sirf chuni hui permissions de sakta hai. Second admin sirf wahi badal sakta hai jo main admin ne tick ki ho (DB level par enforce). Property owner apni listing hide / rented / delete kar sakta hai ("My listings").

Locations: listing submit aur signup/login par browser location mangta hai. Property ki exact location (property_locations) aur user ki location (user_locations) sirf admin ko nazar aati hai (Admin > Map, OpenStreetMap + Leaflet). Off ki hui city dropdown, popular cities aur public listings se hat jati hai.
