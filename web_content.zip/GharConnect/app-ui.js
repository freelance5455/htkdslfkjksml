// App-style UI: phone / installed app / APK par "app" mode (bottom tabs, bottom sheets, compact home). Desktop par website jaisa rehta hai.
(()=>{
 const d=document.documentElement,mq=matchMedia('(max-width:820px)');
 const std=matchMedia('(display-mode: standalone)').matches||navigator.standalone===true||location.hostname==='appassets.androidplatform.net';
 const set=()=>d.classList.toggle('app',mq.matches||std);
 set();mq.addEventListener?mq.addEventListener('change',set):mq.addListener(set);
 // card ki photo par tap = details khulein (app jaisa)
 document.addEventListener('click',e=>{
  const ph=e.target.closest('.photo-wrap');if(!ph||e.target.closest('.heart'))return;
  const b=ph.closest('.property')&&ph.closest('.property').querySelector('.details-btn');if(b)b.click();
 });
})();
