(()=>{
const cfg=window.GC_CONFIG||{};
const LIVE=!!(cfg.SUPABASE_URL&&cfg.SUPABASE_ANON_KEY&&window.supabase);
if(!LIVE){document.body.insertAdjacentHTML('afterbegin','<div style="background:#a36b08;color:#fff;padding:8px;text-align:center;font-size:12px">Supabase config missing: config.js mein URL aur anon key daalein</div>');return}
const sb=supabase.createClient(cfg.SUPABASE_URL,cfg.SUPABASE_ANON_KEY);
const $=id=>document.getElementById(id);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const e164=v=>{v=v.replace(/[\s-]/g,'');return /^03\d{9}$/.test(v)?'+92'+v.slice(1):/^\+923\d{9}$/.test(v)?v:null};
const friendly=e=>{const m=(e&&e.message)||String(e),k={properties_description_check:'Description kam az kam 10 characters ki likhein.',properties_title_check:'Title kam az kam 5 characters ka likhein.',properties_monthly_rent_check:'Rent 1,000 se 10,000,000 ke darmiyan likhein.',properties_area_check:'Area ka naam likhein.'};
 for(const c in k)if(m.includes(c))return k[c];if(/row-level security/i.test(m))return 'Permission nahi mili. Dobara login karke try karein.';return m};
let S={listings_open:true,requests_open:true,max_images:8};
async function loadSettings(){const{data}=await sb.from('app_settings').select('key,value');(data||[]).forEach(r=>{S[r.key]=r.value})}
const can=p=>!!profile&&(profile.is_super_admin||(profile.role==='admin'&&(profile.permissions||[]).includes(p)));
const PERMS={manage_properties:'Properties: approve / reject / hide / rented',delete_properties:'Properties delete karna',manage_users:'Users suspend / reactivate karna',delete_users:'Users delete karna',manage_requests:'Rental requests handle karna',manage_reports:'Reports & complaints handle karna',manage_cities:'Cities on/off karna',manage_settings:'Settings badalna',view_audit:'Audit logs dekhna'};
let UC=[],LOC=null,MAP=null,LAY=null;
const getPos=()=>new Promise(r=>{if(!navigator.geolocation)return r(null);navigator.geolocation.getCurrentPosition(p=>r({lat:p.coords.latitude,lng:p.coords.longitude,acc:p.coords.accuracy}),()=>r(null),{enableHighAccuracy:true,timeout:12000,maximumAge:60000})});
async function getLoc(){const s=$('locStatus');s.textContent='Location le raha hoon...';LOC=await getPos();s.textContent=LOC?'✓ Location mil gayi (±'+Math.round(LOC.acc)+'m)':'Location nahi mili. Browser mein location allow karein.'}
async function saveMyLoc(pos){if(!pos)return;const{data:{user}}=await sb.auth.getUser();if(!user)return;await sb.from('user_locations').upsert({user_id:user.id,lat:pos.lat,lng:pos.lng,accuracy:pos.acc,updated_at:new Date().toISOString()})}
async function loadCities(){
 const{data}=await sb.from('cities').select('name').eq('is_active',true).order('name');const C=(data||[]).map(c=>c.name);
 const fill=(el,ph)=>{if(!el)return;const cur=el.value;el.innerHTML='<option value="">'+ph+'</option>'+C.map(c=>'<option>'+esc(c)+'</option>').join('');if(C.includes(cur))el.value=cur};
 fill($('cityFilter'),'All cities');fill($('cityFilter2'),'All cities');fill($('listCity'),'Choose city');
 document.querySelectorAll('.cities a.city').forEach(a=>{a.style.display=C.includes(a.querySelector('strong').textContent)?'':'none'});
}
async function showMap(){
 $('adminTableWrap').style.display='none';$('adminMap').style.display='block';$('adminHint').textContent='Blue = users ki location, Green = properties ki exact location. Marker par click karein.';$('adminHint').style.display='';
 if(!window.L)return toast('Map library load nahi hui.');
 if(!MAP){MAP=L.map('adminMap').setView([30.3753,69.3451],5);L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:18,attribution:'© OpenStreetMap'}).addTo(MAP);LAY=L.layerGroup().addTo(MAP)}
 setTimeout(()=>MAP.invalidateSize(),60);LAY.clearLayers();
 const[u,pr]=await Promise.all([sb.from('user_locations').select('lat,lng,updated_at,profiles!user_id(full_name,email,phone,role)'),sb.from('property_locations').select('lat,lng,properties!property_id(title,city,area,monthly_rent,status,profiles!owner_id(full_name,phone))')]);
 if(u.error)return toast(u.error.message);if(pr.error)return toast(pr.error.message);
 u.data.forEach(r=>{const p=r.profiles||{};L.circleMarker([r.lat,r.lng],{radius:8,color:'#0b3d91',fillColor:'#2b6cff',fillOpacity:.85,weight:2}).bindPopup('<b>'+esc(p.full_name)+'</b> ('+esc(p.role)+')<br>'+esc(p.email)+'<br>'+esc(p.phone||'Phone nahi diya')+'<br><small>'+esc(new Date(r.updated_at).toLocaleString('en-PK'))+'</small>').addTo(LAY)});
 pr.data.forEach(r=>{const p=r.properties||{},o=p.profiles||{};L.circleMarker([r.lat,r.lng],{radius:8,color:'#0a6b4d',fillColor:'#16c79a',fillOpacity:.85,weight:2}).bindPopup('<b>'+esc(p.title)+'</b><br>'+esc(p.area)+', '+esc(p.city)+' · '+money(p.monthly_rent)+' · '+esc(p.status)+'<br>Owner: '+esc(o.full_name)+' '+esc(o.phone)+'<br><small>Property ki exact location</small>').addTo(LAY)});
}
async function removeProperty(id){
 const{data:im}=await sb.from('property_images').select('storage_path').eq('property_id',id);
 const{data,error}=await sb.from('properties').delete().eq('id',id).select('id');
 if(error)return toast(friendly(error));
 if(!data||!data.length)return toast('Permission nahi hai ya property pehle hi delete ho chuki hai.');
 if(im&&im.length)await sb.storage.from('property-images').remove(im.map(r=>r.storage_path));
 toast('Property delete ho gayi.');
}
async function removeUser(id){
 const{data:im}=await sb.from('property_images').select('storage_path,properties!inner(owner_id)').eq('properties.owner_id',id);
 const{error}=await sb.rpc('admin_delete_user',{target:id});
 if(error)return toast(error.message);
 if(im&&im.length)await sb.storage.from('property-images').remove(im.map(r=>r.storage_path));
 toast('User delete ho gaya.');
}
function openPerms(id){
 const u=UC.find(x=>x.id===id);if(!u||!profile?.is_super_admin)return;
 $('modalTitle').textContent='Admin permissions: '+(u.full_name||u.email);
 $('modalDesc').innerHTML='<div style="font-size:13px;margin-bottom:8px">Jo cheezein tick hongi sirf wahi ye admin badal sakega. Baqi sab wo sirf dekh sakega.</div>'+Object.entries(PERMS).map(([k,l])=>`<label style="display:flex;gap:8px;align-items:center;margin:6px 0"><input type="checkbox" class="permBox" value="${k}" ${(u.permissions||[]).includes(k)?'checked':''}> ${esc(l)}</label>`).join('')+`<button class="btn btn-green" style="margin-top:12px" data-a="saveperms" data-id="${esc(id)}">Save as admin</button>`;
 $('modalForm').style.display='none';$('modalBackdrop').classList.add('show');
}
function gcEye(id,b){const i=document.getElementById(id),h=i.type==='password';i.type=h?'text':'password';b.textContent=h?'🙈':'👁'}
function openPw(){
 const f=(id,l)=>`<div class="field"><label>${l}</label><div style="position:relative"><input id="${id}" type="password" minlength="8" autocomplete="new-password" style="padding-right:48px"><button type="button" aria-label="Show or hide password" style="position:absolute;right:6px;top:50%;transform:translateY(-50%);border:0;background:none;font-size:18px;cursor:pointer;padding:6px" onclick="gcEye('${id}',this)">👁</button></div></div>`;
 $('modalTitle').textContent='Change password';
 $('modalDesc').innerHTML=f('pw1','Naya password (kam az kam 8 characters)')+f('pw2','Dobara likhein')+'<button class="btn btn-green" style="margin-top:6px" onclick="savePw()">Password save karein</button>';
 $('modalForm').style.display='none';$('modalBackdrop').classList.add('show');
}
async function savePw(){
 const a=$('pw1').value,b=$('pw2').value;
 if(a.length<8)return toast('Password kam az kam 8 characters ka rakhein.');
 if(a!==b)return toast('Dono password same likhein.');
 const{error}=await sb.auth.updateUser({password:a});
 if(error)return toast(/reauth|recent|session/i.test(error.message)?'Pehle logout karke dobara login karein, phir password badlein.':error.message);
 closeModal();toast('Password badal gaya.');
}
async function openMine(){
 if(!me)return openModal('login');
 const{data,error}=await sb.from('properties').select('id,title,city,area,monthly_rent,status').eq('owner_id',me.id).order('created_at',{ascending:false});
 if(error)return toast(error.message);
 const lab={pending:'Review mein',published:'Live',rejected:'Rejected',hidden:'Hidden',rented:'Rented'};
 const btn=(t,id,v)=>`<button class="details-btn" data-a="mine" data-id="${esc(id)}" data-v="${v}">${t}</button>`;
 const acts=p=>(({published:[btn('Hide',p.id,'hidden'),btn('Mark rented',p.id,'rented')],pending:[btn('Hide',p.id,'hidden')],hidden:[btn('Resubmit',p.id,'pending'),btn('Mark rented',p.id,'rented')],rejected:[btn('Resubmit',p.id,'pending')],rented:[btn('Re-list',p.id,'pending')]})[p.status]||[]).concat(btn('Delete',p.id,'delete')).join(' · ');
 $('modalTitle').textContent='My listings';
 $('modalDesc').innerHTML=`<div style="max-height:55vh;overflow:auto">${(data||[]).map(p=>`<div style="padding:10px 0;border-bottom:1px solid #e6edf0"><b>${esc(p.title)}</b><br><small>${esc(p.area)}, ${esc(p.city)} · ${money(p.monthly_rent)} · ${esc(lab[p.status]||p.status)}</small><br>${acts(p)}</div>`).join('')||'Abhi aap ne koi property list nahi ki.'}</div><div style="display:flex;gap:8px;margin-top:12px"><button class="btn btn-outline" style="flex:1" onclick="openPw()">🔑 Change password</button><button class="btn btn-outline" style="flex:1" onclick="gcLogout()">Log out</button></div>`;
 $('modalForm').style.display='none';$('modalBackdrop').classList.add('show');
}
const PH="data:image/svg+xml,"+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="900" height="600"><rect width="100%" height="100%" fill="#dce6eb"/></svg>');
let me=null,profile=null,favs=new Set(),current=[],mode='login',tab='Overview';

function fromRow(r){const im=(r.property_images||[]).sort((a,b)=>a.sort_order-b.sort_order)[0];
 return{id:r.id,title:r.title,city:r.city,area:r.area,type:r.property_type,rent:r.monthly_rent,beds:r.bedrooms,baths:r.bathrooms,size:r.covered_area||'',
 img:im?sb.storage.from('property-images').getPublicUrl(im.storage_path).data.publicUrl:PH,tag:r.tag||'NEW',desc:r.description}}
function card(p){const s=favs.has(p.id);return `<article class="property"><div class="photo-wrap"><img src="${esc(p.img)}" alt="${esc(p.title)}" loading="lazy"><span class="tag">${esc(p.tag)}</span><button class="heart ${s?'saved':''}" aria-label="Save property" onclick="toggleSave('${p.id}',this)">${s?'♥':'♡'}</button></div><div class="property-body"><div class="rent">${money(p.rent)} <small>/ month</small></div><h3>${esc(p.title)}</h3><div class="loc">⌖ ${esc(p.area)}, ${esc(p.city)}</div><div class="features"><span>🛏 ${p.beds===0?'Studio':p.beds+' beds'}</span><span>▱ ${p.baths} baths</span>${p.size?`<span>⌂ ${esc(p.size)}</span>`:''}</div></div><div class="property-foot"><span>✓ Admin-reviewed</span><button class="details-btn" onclick="showProperty('${p.id}')">View details →</button></div></article>`}

async function applySearch(scroll=true){
 const on=$('browsePage').classList.contains('active'),v=i=>$(i).value,fc=on?'cityFilter2':'cityFilter',fa=on?'areaFilter2':'areaFilter',ft=on?'typeFilter2':'typeFilter';
 let b=null;if(on){const m=+v('maxRent2');if(m>0)b=[0,m]}else if(v('rentFilter'))b=v('rentFilter').split('-').map(Number);
 ['propertyCards','browseCards'].forEach(id=>{const c=$(id);if(c&&!c.children.length)c.innerHTML='<div class="skel"></div><div class="skel"></div>'});$('noResults').style.display='none';
 let q=sb.from('properties').select('*,property_images(storage_path,sort_order)').eq('status','published').order('published_at',{ascending:false}).limit(60);
 if(v(fc))q=q.eq('city',v(fc));
 if(v(fa).trim())q=q.ilike('area','%'+v(fa).trim().replace(/[%_,()]/g,'')+'%');
 if(v(ft))q=q.eq('property_type',v(ft));
 if(activeType!=='all')q=q.eq('property_type',activeType);
 if(b)q=q.gte('monthly_rent',b[0]).lte('monthly_rent',b[1]);
 const{data,error}=await q;if(error)return toast(error.message);
 current=data.map(fromRow);render(current);
 if(scroll)$('properties').scrollIntoView({behavior:'smooth'});
}
async function toggleSave(id,el){
 if(!me){openModal('login');return}
 if(favs.has(id)){const{error}=await sb.from('favorites').delete().eq('property_id',id);if(error)return toast(error.message);favs.delete(id);el.classList.remove('saved');el.textContent='♡'}
 else{const{error}=await sb.from('favorites').insert({property_id:id});if(error)return toast(error.message);favs.add(id);el.classList.add('saved');el.textContent='♥'}
}
function showProperty(id){
 const p=current.find(x=>x.id===id);if(!p)return;
 $('modalTitle').textContent=p.title;
 $('modalDesc').innerHTML=`<img src="${esc(p.img)}" style="width:100%;height:180px;object-fit:cover;border-radius:12px;margin:5px 0 12px"><b style="color:#0d9b72;font-size:18px">${money(p.rent)} / month</b><br>⌖ ${esc(p.area)}, ${esc(p.city)}<br><br>${esc(p.desc)}<br><br><div class="field"><label>Your mobile number *</label><input id="reqPhone" inputmode="tel" required placeholder="03XXXXXXXXX" value="${esc((profile?.phone||'').replace('+92','0'))}"></div><div class="field"><label>Preferred visit date</label><input type="date" id="reqDate"></div><div class="field"><label>Message (optional)</label><textarea id="reqMsg" maxlength="500" style="width:100%;padding:10px;border:1px solid #dfe7eb;border-radius:10px"></textarea></div><button class="btn btn-green" onclick="sendRequest('${p.id}')">Send rental request</button><details style="margin-top:14px"><summary style="cursor:pointer;color:#9a3b3b">⚑ Report this listing</summary><div class="field"><label>Reason</label><select id="repReason"><option>Wrong information</option><option>Fake listing</option><option>Already rented</option><option>Spam or scam</option><option>Other</option></select></div><div class="field"><label>Details (optional)</label><textarea id="repMsg" maxlength="1000" style="width:100%;padding:10px;border:1px solid #dfe7eb;border-radius:10px"></textarea></div><button class="btn btn-outline" onclick="sendReport('${p.id}')">Submit report</button></details>`;
 $('modalForm').style.display='none';$('modalBackdrop').classList.add('show');
}
async function sendReport(pid){
 if(!me){openModal('login');return}
 const{error}=await sb.from('reports').insert({property_id:pid,reason:$('repReason').value,details:$('repMsg').value.trim()||null});
 if(error)return toast(error.code==='23505'?'Aap is listing ko pehle hi report kar chuke hain.':friendly(error));
 closeModal();toast('Report bhej di gayi. Admin check karega.');
}
async function sendRequest(pid){
 if(!me){openModal('login');return}
 await loadSettings();if(!S.requests_open)return toast('Abhi nayi requests band hain.');
 const phone=e164($('reqPhone').value);if(!phone)return toast('Apna sahi mobile number likhein (03XXXXXXXXX).');
 const{error}=await sb.from('rental_requests').insert({property_id:pid,contact_phone:phone,preferred_visit_date:$('reqDate').value||null,message:$('reqMsg').value.trim()||null});
 if(error)return toast(error.code==='23505'?'Is property ki request pehle se maujood hai.':friendly(error));
 sb.from('profiles').update({phone}).eq('id',me.id).then(()=>{if(profile)profile.phone=phone});
 closeModal();toast('Request bhej di gayi. Admin aap se rabta karega.');
}

function openModal(t){
 mode=t;const reg=t==='register',d=on=>on?'block':'none';
 $('authPw').type='password';$('pwEye').textContent='👁';$('modalForm').style.display='block';$('nameField').style.display=d(reg);$('regName').required=reg;
 $('modalTitle').textContent=reg?'Create your account':'Welcome back';
 $('modalDesc').textContent=reg?'Join GharConnect to find a home or list a property.':'Log in to continue your rental journey.';
 $('modalSubmit').textContent=reg?'Create account':'Log in';$('modalBackdrop').classList.add('show');
}
async function authSubmit(ev){
 ev.preventDefault();const email=$('authEmail').value.trim().toLowerCase(),password=$('authPw').value;
 if(mode==='login'){const r=await sb.auth.signInWithPassword({email,password});if(r.error)return toast(r.error.message);closeModal();getPos().then(saveMyLoc);return}
 const r=await sb.auth.signUp({email,password,options:{data:{full_name:$('regName').value.trim()}}});
 if(r.error)return toast(r.error.message);
 if(!r.data.session){const l=await sb.auth.signInWithPassword({email,password});if(l.error)return toast('Account ban gaya, lekin login nahi hua: '+l.error.message)}
 closeModal();toast('Account ban gaya!');getPos().then(saveMyLoc);
}
function acctClick(){me?openMine():openModal('login')}
function paintNav(){
 const L=$('navLogin'),R=$('navReg'),M=$('navMy');M.style.display=me?'':'none';M.onclick=openMine;
 if(me){L.textContent='Log out';L.onclick=()=>sb.auth.signOut();
  R.textContent=(profile?.full_name||'Account').split(' ')[0]+(profile?.role==='admin'?' · Admin':'');
  R.onclick=()=>profile?.role==='admin'?showPage('admin'):openMine()}
 else{L.textContent='Log in';L.onclick=()=>openModal('login');R.innerHTML='Get Started <span>↗</span>';R.onclick=()=>openModal('register')}
}
async function refreshUser(){
 profile=null;favs=new Set();
 if(me){const[p,f]=await Promise.all([sb.from('profiles').select('*').eq('id',me.id).single(),sb.from('favorites').select('property_id')]);
  profile=p.data;favs=new Set((f.data||[]).map(x=>x.property_id))}
 paintNav();if(profile?.phone&&$('ownerPhone')&&!$('ownerPhone').value)$('ownerPhone').value=profile.phone.replace('+92','0');render(current);
}

function shrink(file){return new Promise((ok,no)=>{const i=new Image();i.onload=()=>{const s=Math.min(1,1600/Math.max(i.width,i.height)),c=document.createElement('canvas');c.width=i.width*s;c.height=i.height*s;c.getContext('2d').drawImage(i,0,0,c.width,c.height);c.toBlob(b=>b?ok(b):no(new Error('Image process nahi hui')),'image/jpeg',.85)};i.onerror=()=>no(new Error('Image format support nahi'));i.src=URL.createObjectURL(file)})}
async function submitListing(ev){
 ev.preventDefault();if(!me){openModal('login');return}
 const f=ev.target,el=f.elements,btn=f.querySelector('button.btn-green');btn.disabled=true;
 try{
  await loadSettings();if(!S.listings_open)throw new Error('Abhi nayi listings band hain.');
  const phone=e164($('ownerPhone').value);if(!phone)throw new Error('Apna sahi mobile number likhein (03XXXXXXXXX).');
  const u=await sb.from('profiles').update({phone}).eq('id',me.id);if(u.error)throw u.error;if(profile)profile.phone=phone;
  const n=s=>s==='Studio'?0:parseInt(s)||0;
  const pos=LOC||await getPos();
  const{data:p,error}=await sb.from('properties').insert({title:$('listTitle').value.trim(),property_type:$('listType').value,city:$('listCity').value,area:$('listArea').value.trim(),monthly_rent:+$('listRent').value,bedrooms:n($('listBeds').value),bathrooms:n($('listBaths').value),description:$('listDesc').value.trim()||null}).select().single();
  if(error)throw error;
  if(pos){await sb.from('property_locations').insert({property_id:p.id,lat:pos.lat,lng:pos.lng,accuracy:pos.acc});saveMyLoc(pos)}
  let i=0;for(const file of[...$('listFiles').files].slice(0,S.max_images||8)){
   const path=`${me.id}/${p.id}/${Date.now()}_${i}.jpg`,up=await sb.storage.from('property-images').upload(path,await shrink(file),{contentType:'image/jpeg'});
   if(up.error)throw up.error;const r=await sb.from('property_images').insert({property_id:p.id,storage_path:path,sort_order:i++});if(r.error)throw r.error}
  toast('Listing review ke liye submit ho gayi!'+(pos?'':' (Location nahi mili)'));f.reset();LOC=null;$('locStatus').textContent='Submit par bhi location li jayegi.';
 }catch(e){toast(friendly(e))}
 btn.disabled=false;
}

async function loadStats(){const{data}=await sb.rpc('admin_stats');if(!data)return;const s=document.querySelectorAll('.metric strong');[data.users,data.properties,data.pending,data.requests].forEach((v,i)=>s[i].textContent=v)}
async function adminTab(name,el){
 tab=name;if(el){document.querySelectorAll('.side-nav button').forEach(b=>b.classList.remove('active'));el.classList.add('active')}
 $('adminHeading').textContent=name==='Overview'?'Pending property review':name;
 $('adminMap').style.display='none';$('adminTableWrap').style.display='';$('adminHint').style.display='';$('adminHint').textContent='Changes are saved to the database and logged in Audit Logs.';
 if(name==='Map'){$('adminHeading').textContent='Users & properties map';return showMap()}
 const T=$('adminTable'),cls=s=>['published','active','completed','visit_scheduled'].includes(s)?'ok':['rejected','suspended','cancelled'].includes(s)?'bad':'';
 const st=s=>`<span class="status ${cls(s)}">${esc(s)}</span>`;
 const b=(t,a,id,v)=>`<button class="details-btn" data-a="${a}" data-id="${esc(id)}" data-v="${v}">${t}</button>`;
 const propActs=p=>{const a=[];if(can('manage_properties')){if(p.status==='pending')a.push(b('Approve','properties',p.id,'published'),b('Reject','properties',p.id,'rejected'));else if(p.status==='published')a.push(b('Hide','properties',p.id,'hidden'),b('Rented','properties',p.id,'rented'));else a.push(b('Publish','properties',p.id,'published'))}if(can('delete_properties'))a.push(b('Delete','delprop',p.id,''));return a.join(' · ')||'—'};
 const table=(h,rows)=>T.innerHTML=`<thead><tr>${h.map(x=>`<th>${x}</th>`).join('')}</tr></thead><tbody>${rows.map(r=>`<tr>${r.map(c=>`<td>${c}</td>`).join('')}</tr>`).join('')||`<tr><td colspan="${h.length}">Kuch nahi mila</td></tr>`}</tbody>`;
 let d,e;
 if(name==='Overview'||name==='Properties'){
  let q=sb.from('properties').select('id,title,city,area,monthly_rent,status,profiles!owner_id(full_name,phone)').order('created_at',{ascending:false}).limit(100);if(name==='Overview')q=q.eq('status','pending');
  ({data:d,error:e}=await q);if(e)return toast(e.message);
  table(['Property','City / Area','Owner contact','Rent / month','Status','Action'],d.map(p=>[esc(p.title),esc(p.city)+' · '+esc(p.area),esc(p.profiles?.full_name)+'<br><small>'+esc(p.profiles?.phone)+'</small>',money(p.monthly_rent),st(p.status),
   propActs(p)]))}
 else if(name==='Users'){
  ({data:d,error:e}=await sb.from('profiles').select('id,full_name,email,phone,role,is_suspended,is_super_admin,permissions').order('created_at',{ascending:false}).limit(100));if(e)return toast(e.message);
  UC=d;
  table(['Name','Role','Email / Phone','Status','Action'],d.map(u=>{const a=[],isA=u.role==='admin',sup=u.is_super_admin,sa=profile.is_super_admin,other=u.id!==me.id;
   if(!sup){if(can('manage_users')&&(!isA||sa)&&other)a.push(b(u.is_suspended?'Reactivate':'Suspend','profiles',u.id,!u.is_suspended));
    if(can('delete_users')&&(!isA||sa)&&other)a.push(b('Delete','deluser',u.id,''));
    if(sa){a.push(b(isA?'Permissions':'Make admin','perms',u.id,''));if(isA)a.push(b('Remove admin','unadmin',u.id,''))}}
   return[esc(u.full_name),esc(sup?'main admin':u.role),esc(u.email)+'<br><small>'+esc(u.phone)+'</small>',st(u.is_suspended?'suspended':'active'),a.join(' · ')||'—']}))}
 else if(name==='Rental Requests'){
  ({data:d,error:e}=await sb.from('rental_requests').select('id,request_code,status,preferred_visit_date,contact_phone,properties!property_id(title),profiles!tenant_id(full_name)').order('created_at',{ascending:false}).limit(100));if(e)return toast(e.message);
  const nx={new:'in_review',in_review:'visit_scheduled',visit_scheduled:'completed'};
  table(['Request','Tenant','Property','Status','Action'],d.map(r=>[esc(r.request_code),esc(r.profiles?.full_name)+'<br><small>'+esc(r.contact_phone)+'</small>',esc(r.properties?.title),st(r.status),
   can('manage_requests')&&nx[r.status]?b('→ '+nx[r.status],'rental_requests',r.id,nx[r.status])+' · '+b('Reject','rental_requests',r.id,'rejected'):'—']))}
 else if(name==='Cities & Areas'){
  ({data:d,error:e}=await sb.from('cities').select('*').order('name'));if(e)return toast(e.message);
  table(['City','Availability','Action'],d.map(c=>[esc(c.name),st(c.is_active?'active':'suspended'),can('manage_cities')?b('Toggle','cities',c.name,!c.is_active):'—']))}
 else if(name==='App Downloads'){
  const{data:s,error:er}=await sb.rpc('apk_stats');if(er)return toast(er.message);
  $('adminHint').textContent='Ye "Download APK" button ke clicks hain (ek device din mein ek dafa). Asal install nahi, cancel hone wale download bhi shamil hain.';
  table(['Din (UTC)','Clicks'],[['<b>Total clicks</b>','<b>'+esc(s.total)+'</b>'],['Alag devices',esc(s.devices)],['Aaj',esc(s.today)],...(s.days||[]).map(r=>[esc(r.day),esc(r.count)])])}
 else if(name==='Audit Logs'){
  if(!can('view_audit'))return table(['Audit Logs'],[['Is ke liye main admin ki permission chahiye.']]);
  ({data:d,error:e}=await sb.from('audit_logs').select('*').order('created_at',{ascending:false}).limit(50));if(e)return toast(e.message);
  table(['When','Action','Entity ID'],d.map(l=>[new Date(l.created_at).toLocaleString('en-PK'),esc(l.action),esc(l.entity_id)]))}

 else if(name==='Reports & Complaints'){
  ({data:d,error:e}=await sb.from('reports').select('id,reason,details,status,created_at,properties!property_id(title),profiles!reporter_id(full_name,email)').order('created_at',{ascending:false}).limit(100));if(e)return toast(e.message);
  table(['Listing','Reason','Reported by','Status','Action'],d.map(r=>[esc(r.properties?.title||'(deleted)'),esc(r.reason)+(r.details?'<br><small>'+esc(r.details)+'</small>':''),esc(r.profiles?.full_name)+'<br><small>'+esc(r.profiles?.email)+'</small>',st(r.status==='open'?'new':r.status),can('manage_reports')&&r.status==='open'?b('Resolve','reports',r.id,'resolved')+' · '+b('Dismiss','reports',r.id,'dismissed'):'—']))}
 else if(name==='Settings'){
  ({data:d,error:e}=await sb.from('app_settings').select('key,value').order('key'));if(e)return toast(e.message);
  const L={listings_open:'New listings allowed',requests_open:'New rental requests allowed',max_images:'Max images per listing'};
  table(['Setting','Value','Action'],d.map(r=>typeof r.value==='boolean'?[esc(L[r.key]||r.key),`<span class="status ${r.value?'ok':'bad'}">${r.value?'On':'Off'}</span>`,can('manage_settings')?b(r.value?'Turn off':'Turn on','settings',r.key,!r.value):'—']:[esc(L[r.key]||r.key),esc(r.value),can('manage_settings')?b('Change','setnum',r.key,r.value):'—']))}
 else table([name],[['Is section ka data nahi mila.']]);
}
document.addEventListener('click',async ev=>{
 const x=ev.target.closest('[data-a]');if(!x)return;
 const t=x.dataset.a,v=x.dataset.v==='true'?true:x.dataset.v==='false'?false:x.dataset.v,col=t==='profiles'?'is_suspended':t==='cities'?'is_active':'status';
 if(t==='delprop'){if(!confirm('Ye property hamesha ke liye delete ho jayegi. Pakka?'))return;await removeProperty(x.dataset.id);adminTab(tab);loadStats();return}
 if(t==='deluser'){if(!confirm('Ye user, uski properties aur requests sab delete ho jayengi. Pakka?'))return;await removeUser(x.dataset.id);adminTab(tab);loadStats();return}
 if(t==='perms'){openPerms(x.dataset.id);return}
 if(t==='saveperms'){const perms=[...document.querySelectorAll('.permBox:checked')].map(i=>i.value);const{error}=await sb.from('profiles').update({role:'admin',permissions:perms}).eq('id',x.dataset.id);if(error)return toast(error.message);closeModal();toast('Admin permissions save ho gayi.');adminTab(tab);return}
 if(t==='unadmin'){if(!confirm('Is user se admin ka role wapas le lein?'))return;const{error}=await sb.from('profiles').update({role:'user',permissions:[]}).eq('id',x.dataset.id);if(error)return toast(error.message);toast('Updated.');adminTab(tab);return}
 if(t==='mine'){const id=x.dataset.id;if(v==='delete'){if(!confirm('Ye property hamesha ke liye delete ho jayegi. Pakka?'))return;await removeProperty(id)}else{const{error}=await sb.from('properties').update({status:v}).eq('id',id);if(error)return toast(friendly(error))}openMine();return}
 let q;
 if(t==='settings'||t==='setnum'){let val=v;if(t==='setnum'){const n=parseInt(prompt('Max images per listing (1-12):',x.dataset.v));if(!(n>=1&&n<=12))return;val=n}q=sb.from('app_settings').update({value:val,updated_at:new Date().toISOString()}).eq('key',x.dataset.id)}
 else q=sb.from(t).update({[col]:v}).eq(t==='cities'?'name':'id',x.dataset.id);
 const{error}=await q;
 if(error)return toast(error.message);toast('Updated.');if(t==='cities')loadCities();adminTab(tab);loadStats();
});

const _show=showPage;
function guardedShow(n){
 if(n==='admin'&&profile?.role!=='admin'){toast('Admin access zaroori hai.');return}
 if(n==='owner'&&!me){toast('Pehle login karein.');openModal('login');return}
 _show(n);if(n==='browse')applySearch(false);if(n==='admin'){loadStats();adminTab('Overview',document.querySelector('.side-nav button'))}
}
Object.assign(window,{gcEye,openPw,savePw,getLoc,gcLogout:()=>{closeModal();sb.auth.signOut()},sendReport,card,applySearch,toggleSave,showProperty,sendRequest,openModal,authSubmit,acctClick,submitListing,adminTab,showPage:guardedShow});
sb.auth.onAuthStateChange((_e,s)=>{me=s?.user||null;setTimeout(refreshUser,0)});
loadCities();applySearch(false);loadSettings();
})();
