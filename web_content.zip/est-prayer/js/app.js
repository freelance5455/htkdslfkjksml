// Mihrab — Advanced Main Application
// Premium Islamic PWA

let userLat = null, userLon = null;
let qiblaDirection = null;
let currentTimings = null;
let nextPrayerName = null;
let nextPrayerTime = null;
let tasbihCount = Number(localStorage.getItem('mihrab-tasbih-count')) || 0;
let tasbihTarget = Number(localStorage.getItem('mihrab-tasbih-target')) || 33;
let adhanEnabled = localStorage.getItem('mihrab-adhan') !== '0';
let notifEnabled = localStorage.getItem('mihrab-notif') === '1';
let adhanAudio = null;
let countdownInterval = null;
let deferredInstallPrompt = null;

// ========== UTILITIES ==========
function showToast(msg, ms = 2500) {
  let t = document.querySelector('.toast');
  if (!t) {
    t = document.createElement('div');
    t.className = 'toast';
    document.body.appendChild(t);
  }
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), ms);
}

function formatCountdown(ms) {
  if (ms <= 0) return 'الآن';
  const h = Math.floor(ms / 3600000);
  const m = Math.floor((ms % 3600000) / 60000);
  const s = Math.floor((ms % 60000) / 1000);
  if (h > 0) return `${h}<small>س</small> ${m}<small>د</small> ${s}<small>ث</small>`;
  return `${m}<small>د</small> ${s}<small>ث</small>`;
}

function getHijriDate() {
  try {
    return new Intl.DateTimeFormat('ar-SA-u-ca-islamic', {
      day: 'numeric', month: 'long', year: 'numeric'
    }).format(new Date());
  } catch {
    return '—';
  }
}

function getGregDate() {
  return new Intl.DateTimeFormat('ar-EG', {
    weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'
  }).format(new Date());
}

// لا يوجد تسجيل دخول وهمي؛ التطبيق يعمل مباشرة دون طلب بيانات شخصية.

// ========== THEME ==========
const themeToggle = document.getElementById('theme-toggle');
const themeIcon = document.getElementById('theme-icon');

function setThemeIcon(isDark) {
  if (isDark) {
    themeIcon.innerHTML = '<circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>';
  } else {
    themeIcon.innerHTML = '<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>';
  }
}

themeToggle.addEventListener('click', () => {
  const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
  const next = isDark ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', next === 'dark' ? 'dark' : '');
  setThemeIcon(next === 'dark');
  localStorage.setItem('mihrab-theme', next);
});

if (localStorage.getItem('mihrab-theme') === 'dark') {
  document.documentElement.setAttribute('data-theme', 'dark');
  setThemeIcon(true);
}

// ========== NAV ==========
function showSection(name) {
  document.querySelectorAll('.section').forEach(s => s.classList.add('hidden'));
  const section = document.getElementById('section-' + name);
  if (section) section.classList.remove('hidden');
  document.querySelectorAll('.nav-item').forEach(b => {
    b.classList.toggle('active', b.dataset.section === name || (name === 'tasbih' || name === 'qibla' || name === 'names') && b.dataset.section === 'more');
  });
  if (name === 'names') renderNames();
  if (name === 'hadith') renderHadiths();
  if (name === 'prophets') renderProphetsList();
  if (name === 'seerah') renderSeerahList();
  if (name === 'qibla' && typeof loadQibla === 'function') loadQibla();
  if (name === 'quran' && typeof renderSurahList === 'function') { /* existing */ }
}

document.querySelectorAll('.nav-item').forEach(btn => {
  btn.addEventListener('click', () => {
    const sec = btn.dataset.section;
    if (sec === 'more') {
      document.getElementById('more-sheet')?.classList.remove('hidden');
      return;
    }
    showSection(sec);
  });
});

document.getElementById('more-close')?.addEventListener('click', () => {
  document.getElementById('more-sheet')?.classList.add('hidden');
});
document.querySelectorAll('.more-item[data-go]').forEach(btn => {
  btn.addEventListener('click', () => {
    document.getElementById('more-sheet')?.classList.add('hidden');
    showSection(btn.dataset.go);
  });
});
document.getElementById('more-sheet')?.addEventListener('click', (e) => {
  if (e.target.id === 'more-sheet') e.target.classList.add('hidden');
});

// ========== INIT ==========
let appInitialized = false;
async function initApp() {
  if (appInitialized) return;
  appInitialized = true;
  document.getElementById('app').style.display = 'flex';
  document.getElementById('hijri-date').textContent = getHijriDate();
  document.getElementById('greg-date').textContent = getGregDate();

  const dayIndex = Math.floor(Date.now() / 86400000) % DAILY_AYAHS.length;
  const ayah = DAILY_AYAHS[dayIndex];
  document.getElementById('daily-ayah-text').textContent = ayah.text;
  document.getElementById('daily-ayah-ref').textContent = ayah.ref;

  if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol)) {
    try { await navigator.serviceWorker.register('./sw.js'); }
    catch (e) { console.warn('Service worker registration failed:', e); }
  }

  getLocation();
  setupAdhkar();
  setupTasbih();
  setupQuranUI();
  setupSettings();
  updateOfflineStatus();
  renderNames();
}

// Capture the install event as early as possible (before app initialization).
window.addEventListener('beforeinstallprompt', (event) => {
  event.preventDefault();
  deferredInstallPrompt = event;
  const banner = document.getElementById('install-banner');
  if (banner && !localStorage.getItem('mihrab-install-dismissed')) banner.classList.remove('hidden');
});

document.getElementById('install-btn')?.addEventListener('click', async () => {
  if (!deferredInstallPrompt) {
    showToast('يمكنك تثبيت التطبيق من قائمة المتصفح');
    return;
  }
  deferredInstallPrompt.prompt();
  const choice = await deferredInstallPrompt.userChoice;
  if (choice?.outcome === 'accepted') showToast('تم إرسال طلب التثبيت');
  deferredInstallPrompt = null;
  document.getElementById('install-banner')?.classList.add('hidden');
});
document.getElementById('install-close')?.addEventListener('click', () => {
  document.getElementById('install-banner')?.classList.add('hidden');
  localStorage.setItem('mihrab-install-dismissed', '1');
});

// ========== LOCATION & PRAYER ==========
function useCairoFallback() {
  userLat = 30.0444;
  userLon = 31.2357;
  const display = document.getElementById('location-display');
  display.textContent = 'القاهرة (موقع افتراضي) — قد تختلف المواقيت عن موقعك';
  loadPrayerTimes();
  loadQibla();
}

function showLocationPermissionFallback(message) {
  const display = document.getElementById('location-display');
  display.innerHTML = '';
  const text = document.createElement('span');
  text.textContent = message;
  const retry = document.createElement('button');
  retry.type = 'button'; retry.className = 'btn btn-outline btn-sm'; retry.textContent = 'إعادة تحديد الموقع';
  retry.addEventListener('click', getLocation, { once: true });
  const fallback = document.createElement('button');
  fallback.type = 'button'; fallback.className = 'btn btn-outline btn-sm'; fallback.textContent = 'استخدام القاهرة مؤقتاً';
  fallback.addEventListener('click', useCairoFallback, { once: true });
  display.append(text, retry, fallback);
}

function getLocation() {
  const display = document.getElementById('location-display');
  if (!navigator.geolocation) {
    showLocationPermissionFallback('الموقع الجغرافي غير مدعوم في هذا المتصفح.');
    return;
  }
  display.textContent = 'جارٍ تحديد موقعك...';
  navigator.geolocation.getCurrentPosition(
    (pos) => {
      userLat = pos.coords.latitude;
      userLon = pos.coords.longitude;
      display.textContent = 'تم تحديد موقعك بنجاح';
      loadPrayerTimes();
      loadQibla();
    },
    (error) => {
      userLat = null; userLon = null;
      const message = error.code === 1 ? 'لم تسمح بالوصول إلى الموقع.' : 'تعذر تحديد موقعك حالياً.';
      showLocationPermissionFallback(message + ' المواقيت لن تُحسب من موقع غير مؤكد.');
    },
    { enableHighAccuracy: true, timeout: 15000, maximumAge: 300000 }
  );
}

document.getElementById('method-select').addEventListener('change', loadPrayerTimes);

function parsePrayerTime(value) {
  if (!value) return null;
  const match = String(value).match(/(\d{1,2}):(\d{2})/);
  if (!match) return null;
  const hours = Number(match[1]), minutes = Number(match[2]);
  if (hours > 23 || minutes > 59) return null;
  return { hours, minutes, label: `${String(hours).padStart(2,'0')}:${String(minutes).padStart(2,'0')}` };
}

async function loadPrayerTimes() {
  const container = document.getElementById('prayer-times');
  if (userLat == null || userLon == null) return;
  if (notifCheckInterval) { clearInterval(notifCheckInterval); notifCheckInterval = null; }
  container.innerHTML = '<div class="loading"><div class="spinner"></div>جاري تحميل المواقيت...</div>';
  const method = document.getElementById('method-select').value;
  try {
    const zone = Intl.DateTimeFormat().resolvedOptions().timeZone || 'Africa/Cairo';
    const url = `https://api.aladhan.com/v1/timings?latitude=${encodeURIComponent(userLat)}&longitude=${encodeURIComponent(userLon)}&method=${encodeURIComponent(method)}&timezonestring=${encodeURIComponent(zone)}`;
    const res = await fetch(url, { headers: { Accept: 'application/json' }, cache: 'no-cache' });
    if (!res.ok) throw new Error(`Prayer API HTTP ${res.status}`);
    const data = await res.json();
    if (data.code !== 200 || !data.data?.timings) throw new Error('Invalid prayer API response');
    currentTimings = data.data.timings;
    const prayers = [
      { name: 'الفجر', key: 'Fajr' }, { name: 'الشروق', key: 'Sunrise', sunrise: true },
      { name: 'الظهر', key: 'Dhuhr' }, { name: 'العصر', key: 'Asr' },
      { name: 'المغرب', key: 'Maghrib' }, { name: 'العشاء', key: 'Isha' }
    ];
    const now = new Date();
    const nowMinutes = now.getHours() * 60 + now.getMinutes();
    const prayerEntries = prayers.map(p => ({ ...p, parsed: parsePrayerTime(currentTimings[p.key]) })).filter(p => p.parsed);
    const upcoming = prayerEntries.filter(p => !p.sunrise).find(p => p.parsed.hours * 60 + p.parsed.minutes > nowMinutes);
    const next = upcoming || prayerEntries.find(p => p.key === 'Fajr');
    nextPrayerName = next?.name || null;
    nextPrayerTime = null;
    if (next) {
      nextPrayerTime = new Date(now);
      nextPrayerTime.setHours(next.parsed.hours, next.parsed.minutes, 0, 0);
      if (!upcoming || nextPrayerTime <= now) nextPrayerTime.setDate(nextPrayerTime.getDate() + 1);
    }
    container.innerHTML = prayerEntries.map(p => {
      const mins = p.parsed.hours * 60 + p.parsed.minutes;
      const passed = !p.sunrise && mins <= nowMinutes;
      const isNext = p === next;
      return `<div class="prayer-item ${isNext ? 'next' : ''} ${passed ? 'passed' : ''}"><div class="name"><span class="dot"></span>${p.name}</div><div class="time">${p.parsed.label}</div></div>`;
    }).join('');
    document.getElementById('next-prayer-name').textContent = nextPrayerName || '—';
    startCountdown();
    scheduleAdhanNotifications();
  } catch (err) {
    console.error('Prayer times error:', err);
    currentTimings = null; nextPrayerName = null; nextPrayerTime = null;
    if (countdownInterval) clearInterval(countdownInterval);
    if (notifCheckInterval) clearInterval(notifCheckInterval);
    document.getElementById('next-prayer-name').textContent = '—';
    document.getElementById('next-countdown').textContent = '--';
    container.innerHTML = '<div class="empty-state">تعذر تحميل المواقيت حالياً. تحقق من الإنترنت أو أعد المحاولة.</div><button class="btn btn-outline btn-sm" id="retry-prayer-times">إعادة المحاولة</button>';
    document.getElementById('retry-prayer-times')?.addEventListener('click', loadPrayerTimes, { once: true });
  }
}

function startCountdown() {
  if (countdownInterval) clearInterval(countdownInterval);
  const el = document.getElementById('next-countdown');
  function tick() {
    if (!nextPrayerTime) {
      el.textContent = '--';
      return;
    }
    const ms = nextPrayerTime - new Date();
    el.innerHTML = formatCountdown(ms);
    if (ms <= 0) {
      clearInterval(countdownInterval);
      loadPrayerTimes();
    }
  }
  tick();
  countdownInterval = setInterval(tick, 1000);
}

// ========== ADHAN & NOTIFICATIONS ==========
function setupSettings() {
  const adhanT = document.getElementById('adhan-toggle');
  const notifT = document.getElementById('notif-toggle');
  const syncToggle = (el, value) => {
    el.classList.toggle('active', value);
    el.setAttribute('aria-checked', String(value));
    el.setAttribute('tabindex', '0');
  };
  syncToggle(adhanT, adhanEnabled);
  syncToggle(notifT, notifEnabled);
  adhanT.addEventListener('click', () => {
    adhanEnabled = !adhanEnabled;
    syncToggle(adhanT, adhanEnabled);
    localStorage.setItem('mihrab-adhan', adhanEnabled ? '1' : '0');
    showToast(adhanEnabled ? 'تم تفعيل محاولة تشغيل الأذان عند فتح التطبيق' : 'تم إيقاف الأذان');
  });
  notifT.addEventListener('click', async () => {
    if (!notifEnabled) {
      if (!('Notification' in window)) { showToast('الإشعارات غير مدعومة في هذا المتصفح'); return; }
      if (Notification.permission !== 'granted') {
        const permission = await Notification.requestPermission();
        if (permission !== 'granted') { showToast('لم يتم السماح بالإشعارات'); return; }
      }
    }
    notifEnabled = !notifEnabled;
    syncToggle(notifT, notifEnabled);
    localStorage.setItem('mihrab-notif', notifEnabled ? '1' : '0');
    if (notifEnabled) scheduleAdhanNotifications();
    else if (notifCheckInterval) clearInterval(notifCheckInterval);
    showToast(notifEnabled ? 'الإشعارات مفعلة أثناء تشغيل التطبيق' : 'تم إيقاف الإشعارات');
  });
  [adhanT, notifT].forEach(el => el.addEventListener('keydown', e => {
    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); el.click(); }
  }));
  document.getElementById('test-adhan-btn').addEventListener('click', playAdhan);
}

function playAdhan() {
  if (adhanAudio) { adhanAudio.pause(); adhanAudio.currentTime = 0; }
  adhanAudio = new Audio(ADHAN_URL);
  adhanAudio.preload = 'none';
  adhanAudio.play().catch(() => showToast('تعذر تشغيل الصوت؛ تحقق من الاتصال واضغط تجربة الأذان'));
}

let notifCheckInterval = null;
const notifiedPrayers = new Set();
function scheduleAdhanNotifications() {
  if (notifCheckInterval) clearInterval(notifCheckInterval);
  if (!currentTimings || !notifEnabled) return;
  const check = async () => {
    if (!notifEnabled || !currentTimings) return;
    const now = new Date();
    const dayKey = now.toLocaleDateString('en-CA');
    for (const p of [{name:'الفجر',key:'Fajr'},{name:'الظهر',key:'Dhuhr'},{name:'العصر',key:'Asr'},{name:'المغرب',key:'Maghrib'},{name:'العشاء',key:'Isha'}]) {
      const parsed = parsePrayerTime(currentTimings[p.key]);
      if (!parsed) continue;
      const target = new Date(now);
      target.setHours(parsed.hours, parsed.minutes, 0, 0);
      const elapsed = now.getTime() - target.getTime();
      if (elapsed < 0 || elapsed > 60000) continue;
      const key = `${dayKey}-${p.key}`;
      if (notifiedPrayers.has(key) || localStorage.getItem('mihrab-notified-' + key)) continue;
      notifiedPrayers.add(key);
      localStorage.setItem('mihrab-notified-' + key, '1');
      if (adhanEnabled && document.visibilityState === 'visible') playAdhan();
      if ('serviceWorker' in navigator && Notification.permission === 'granted') {
        try {
          const registration = await navigator.serviceWorker.ready;
          await registration.showNotification('محراب — حان وقت الصلاة', {
            body: `حان الآن وقت صلاة ${p.name}`,
            icon: './icons/icon-192.png', badge: './icons/icon-192.png',
            tag: `mihrab-prayer-${p.key}`, renotify: false
          });
        } catch (error) { console.warn('Notification failed:', error); }
      }
      showToast(`حان وقت صلاة ${p.name}`);
    }
  };
  check();
  notifCheckInterval = setInterval(check, 15000);
}

// ========== ADHKAR ==========
function setupAdhkar() {
  let currentType = 'morning';
  const list = document.getElementById('adhkar-list');
  const stateKey = type => `mihrab-adhkar-${new Date().toLocaleDateString('en-CA')}-${type}`;
  function render() {
    const items = ADHKAR[currentType] || [];
    let progress = {};
    try { progress = JSON.parse(localStorage.getItem(stateKey(currentType)) || '{}'); } catch {}
    list.innerHTML = items.map((item, i) => {
      const count = Math.max(1, Number(item.count) || 1);
      const current = Math.min(count, Math.max(0, Number(progress[i]) || 0));
      return `<div class="adhkar-item" data-idx="${i}"><div class="text"></div><div class="meta"><span class="count-badge"></span><button type="button" class="counter-btn ${current >= count ? 'done' : ''}" data-count="${count}" data-current="${current}">${current >= count ? 'تم ✓' : `<span class="cur">${current}</span> / ${count}`}</button></div></div>`;
    }).join('');
    list.querySelectorAll('.adhkar-item').forEach((el, i) => {
      el.querySelector('.text').textContent = items[i].ar || '';
      el.querySelector('.count-badge').textContent = `${items[i].count || 1}× · ${items[i].source || 'ذكر'}`;
    });
    list.querySelectorAll('.counter-btn').forEach(btn => btn.addEventListener('click', () => {
      const idx = Number(btn.closest('.adhkar-item').dataset.idx);
      const max = Number(btn.dataset.count);
      const current = Math.min(max, Number(btn.dataset.current || 0) + 1);
      btn.dataset.current = String(current);
      btn.classList.toggle('done', current >= max);
      btn.innerHTML = current >= max ? 'تم ✓' : `<span class="cur">${current}</span> / ${max}`;
      let saved = {};
      try { saved = JSON.parse(localStorage.getItem(stateKey(currentType)) || '{}'); } catch {}
      saved[idx] = current;
      localStorage.setItem(stateKey(currentType), JSON.stringify(saved));
      if (current >= max) showToast('أحسنت، أتممت هذا الذكر');
    }));
  }
  document.querySelectorAll('.adhkar-tabs .tab-btn').forEach(btn => btn.addEventListener('click', () => {
    document.querySelectorAll('.adhkar-tabs .tab-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active'); currentType = btn.dataset.type; render();
  }));
  render();
}

// ========== TASBIH ==========
function setupTasbih() {
  const countEl = document.getElementById('tasbih-count');
  const targetEl = document.getElementById('tasbih-target');
  const btn = document.getElementById('tasbih-btn');

  function update() {
    countEl.textContent = tasbihCount;
    targetEl.textContent = tasbihTarget;
    localStorage.setItem('mihrab-tasbih-count', String(tasbihCount));
    localStorage.setItem('mihrab-tasbih-target', String(tasbihTarget));
  }

  btn.addEventListener('click', () => {
    tasbihCount++;
    countEl.classList.add('bump');
    setTimeout(() => countEl.classList.remove('bump'), 120);
    update();
    if (navigator.vibrate) navigator.vibrate(15);
    if (tasbihCount >= tasbihTarget) {
      showToast('أحسنت! أكملت الهدف');
    }
  });

  document.getElementById('reset-tasbih').addEventListener('click', () => {
    tasbihCount = 0;
    update();
  });
  document.getElementById('set-33').addEventListener('click', () => { tasbihTarget = 33; update(); });
  document.getElementById('set-99').addEventListener('click', () => { tasbihTarget = 99; update(); });
  document.getElementById('set-100').addEventListener('click', () => { tasbihTarget = 100; update(); });
  update();
}

// ========== QIBLA ==========
async function loadQibla() {
  if (userLat == null) return;
  const infoEl = document.getElementById('qibla-info');
  const degreeEl = document.getElementById('qibla-degree');
  const needleEl = document.getElementById('qibla-needle');
  const innerEl = document.getElementById('compass-inner');

  try {
    const res = await fetch(`https://api.aladhan.com/v1/qibla/${userLat}/${userLon}`);
    const data = await res.json();
    if (data.code === 200 && data.data) {
      qiblaDirection = Number(data.data.direction);
      degreeEl.textContent = Math.round(qiblaDirection) + '°';
      infoEl.textContent = 'اتجاه القبلة من موقعك: ' + Math.round(qiblaDirection) + '° — وجّه الجهاز نحو السهم';
      if (needleEl) needleEl.style.transform = 'rotate(' + qiblaDirection + 'deg)';
    } else {
      // Local calculation fallback (Kaaba approx 21.4225, 39.8262)
      qiblaDirection = computeQiblaBearing(userLat, userLon);
      degreeEl.textContent = Math.round(qiblaDirection) + '°';
      infoEl.textContent = 'اتجاه القبلة (محسوب محلياً): ' + Math.round(qiblaDirection) + '°';
      if (needleEl) needleEl.style.transform = 'rotate(' + qiblaDirection + 'deg)';
    }
  } catch (err) {
    qiblaDirection = computeQiblaBearing(userLat, userLon);
    degreeEl.textContent = Math.round(qiblaDirection) + '°';
    infoEl.textContent = 'اتجاه القبلة (محسوب محلياً): ' + Math.round(qiblaDirection) + '°';
    if (needleEl) needleEl.style.transform = 'rotate(' + qiblaDirection + 'deg)';
  }

  startCompassListener();
}

function computeQiblaBearing(lat, lon) {
  // Kaaba coordinates
  const kLat = 21.4225 * Math.PI / 180;
  const kLon = 39.8262 * Math.PI / 180;
  const uLat = lat * Math.PI / 180;
  const uLon = lon * Math.PI / 180;
  const dLon = kLon - uLon;
  const y = Math.sin(dLon);
  const x = Math.cos(uLat) * Math.tan(kLat) - Math.sin(uLat) * Math.cos(dLon);
  let brng = Math.atan2(y, x) * 180 / Math.PI;
  return (brng + 360) % 360;
}

let compassStarted = false;
function startCompassListener() {
  const innerEl = document.getElementById('compass-inner');
  const infoEl = document.getElementById('qibla-info');

  function onOrient(e) {
    if (qiblaDirection == null) return;
    let heading = null;
    if (typeof e.webkitCompassHeading === 'number') {
      heading = e.webkitCompassHeading; // iOS absolute
    } else if (e.absolute && e.alpha != null) {
      heading = (360 - e.alpha) % 360;
    } else if (e.alpha != null) {
      heading = (360 - e.alpha) % 360;
    }
    if (heading == null) return;
    const screenAngle = Number(window.screen?.orientation?.angle ?? window.orientation ?? 0);
    const rotation = -heading + screenAngle;
    if (innerEl) innerEl.style.transform = `rotate(${rotation}deg)`;
  }

  // iOS 13+ requires permission
  if (typeof DeviceOrientationEvent !== 'undefined' && typeof DeviceOrientationEvent.requestPermission === 'function') {
    const btn = document.createElement('button');
    btn.className = 'btn btn-outline btn-sm';
    btn.textContent = 'تفعيل البوصلة';
    btn.style.marginTop = '8px';
    btn.onclick = async () => {
      try {
        const perm = await DeviceOrientationEvent.requestPermission();
        if (perm === 'granted') {
          if (!compassStarted) { window.addEventListener('deviceorientation', onOrient, true); compassStarted = true; }
          btn.remove();
          showToast('تم تفعيل البوصلة');
        } else {
          showToast('لم يتم السماح بالبوصلة');
        }
      } catch (err) {
        showToast('البوصلة غير متاحة');
      }
    };
    const container = document.querySelector('.qibla-container');
    if (container && !container.querySelector('.btn-outline')) container.appendChild(btn);
  } else if (window.DeviceOrientationEvent && !compassStarted) {
    window.addEventListener('deviceorientation', onOrient, true);
    compassStarted = true;
  }
}

// ========== QURAN UI ==========
function setupQuranUI() {
  const list = document.getElementById('surah-list');
  const search = document.getElementById('surah-search');

  function renderSurahs(filter = '') {
    const q = filter.trim().toLowerCase();
    const filtered = SURAH_NAMES.filter(s =>
      !q || s.ar.includes(q) || s.en.toLowerCase().includes(q) || String(s.n).includes(q)
    );
    list.innerHTML = filtered.map(s => `
      <div class="surah-item" data-n="${s.n}">
        <div class="num">${s.n}</div>
        <div class="info">
          <div class="ar">${s.ar}</div>
          <div class="en">${s.en}</div>
        </div>
        <div class="ayahs">${s.ayahs} آية</div>
      </div>
    `).join('');

    list.querySelectorAll('.surah-item').forEach(el => {
      el.addEventListener('click', () => openSurah(parseInt(el.dataset.n)));
    });
  }

  search?.addEventListener('input', () => renderSurahs(search.value));
  renderSurahs();

  document.getElementById('back-to-surahs')?.addEventListener('click', () => {
    document.getElementById('quran-reader').classList.add('hidden');
    document.getElementById('surah-list-card').classList.remove('hidden');
  });

  document.getElementById('download-quran-btn')?.addEventListener('click', downloadFullQuran);
  document.getElementById('clear-quran-btn')?.addEventListener('click', clearQuranStorage);
}

let currentAyahs = [];
let currentPage = 0;
const AYAH_PER_PAGE = 8;
let currentSurahNum = null;

async function openSurah(n) {
  const surah = SURAH_NAMES.find(s => s.n === n);
  if (!surah) return;
  currentSurahNum = n;
  document.getElementById('surah-list-card').classList.add('hidden');
  const reader = document.getElementById('quran-reader');
  reader.classList.remove('hidden');
  document.getElementById('reader-title').textContent = surah.ar;
  const container = document.getElementById('ayahs-container');
  container.innerHTML = '<div class="loading"><div class="spinner"></div>جاري التحميل...</div>';

  try {
    currentAyahs = await getSurahAyahs(n);
    currentPage = 0;
    renderQuranPage();
  } catch {
    container.innerHTML = '<div class="empty-state">تعذر تحميل السورة. حاول مرة أخرى أو فعّل التحميل دون نت.</div>';
  }
}

function escapeHTML(value) {
  return String(value ?? '').replace(/[&<>\"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[ch]));
}

function renderQuranPage() {
  const container = document.getElementById('ayahs-container');
  const totalPages = Math.max(1, Math.ceil(currentAyahs.length / AYAH_PER_PAGE));
  if (currentPage >= totalPages) currentPage = totalPages - 1;
  if (currentPage < 0) currentPage = 0;
  const start = currentPage * AYAH_PER_PAGE;
  const pageAyahs = currentAyahs.slice(start, start + AYAH_PER_PAGE);
  container.innerHTML = pageAyahs.map((a, i) =>
    `<div class="ayah">${escapeHTML(a.text)} <span class="ayah-num">${start + i + 1}</span></div>`
  ).join('');
  const info = document.getElementById('page-info');
  if (info) info.textContent = `صفحة ${currentPage + 1} / ${totalPages}`;
  const prev = document.getElementById('prev-page');
  const next = document.getElementById('next-page');
  if (prev) prev.disabled = currentPage <= 0;
  if (next) next.disabled = currentPage >= totalPages - 1;
}

document.getElementById('prev-page')?.addEventListener('click', () => {
  if (currentPage > 0) { currentPage--; renderQuranPage(); }
});
document.getElementById('next-page')?.addEventListener('click', () => {
  const totalPages = Math.ceil(currentAyahs.length / AYAH_PER_PAGE);
  if (currentPage < totalPages - 1) { currentPage++; renderQuranPage(); }
});

// ========== NAMES OF ALLAH ==========
function renderNames(filter = '') {
  const grid = document.getElementById('names-grid');
  if (!grid) return;
  const q = filter.trim();
  const list = ALLAH_NAMES.filter(n => !q || n.ar.includes(q) || String(n.n).includes(q));
  grid.innerHTML = list.map(n => `
    <div class="name-card">
      <div class="ar">${n.ar}</div>
      <div class="num">${n.n}</div>
    </div>
  `).join('');
}

document.getElementById('names-search')?.addEventListener('input', (e) => {
  renderNames(e.target.value);
});

// ========== OFFLINE STATUS ==========
function updateOfflineStatus() {
  const el = document.getElementById('offline-status');
  if (!el) return;
  if (typeof getQuranStorageInfo === 'function') {
    getQuranStorageInfo().then(info => {
      if (info && info.count > 0) {
        el.textContent = `متوفر دون نت: ${info.count} سورة`;
      } else {
        el.textContent = 'غير محمّل — يمكنك التحميل للعمل دون نت';
      }
    }).catch(() => {
      el.textContent = 'جاهز للتحميل';
    });
  } else {
    el.textContent = 'جاهز';
  }
}


// ========== HADITH / PROPHETS / SEERAH ==========
function renderHadiths() {
  const list = document.getElementById('hadith-list');
  if (!list || typeof HADITHS_40 === 'undefined') return;
  list.innerHTML = HADITHS_40.map(h => `
    <div class="content-item">
      <div class="item-n">حديث ${h.n}</div>
      <div class="item-text">${h.text}</div>
      <div class="item-source">${h.source}</div>
    </div>
  `).join('');
}

function renderProphetsList() {
  const list = document.getElementById('prophets-list');
  const detail = document.getElementById('prophet-detail');
  const listCard = document.getElementById('prophets-list-card');
  if (!list || typeof PROPHETS_STORIES === 'undefined') return;
  if (listCard) listCard.classList.remove('hidden');
  if (detail) detail.classList.add('hidden');
  list.innerHTML = PROPHETS_STORIES.map(p => `
    <div class="content-item" data-id="${p.id}">
      <div class="item-text">${p.title}</div>
      <div class="item-source">اضغط للقراءة</div>
    </div>
  `).join('');
  list.querySelectorAll('.content-item').forEach(el => {
    el.addEventListener('click', () => {
      const p = PROPHETS_STORIES.find(x => x.id === el.dataset.id);
      if (!p) return;
      if (listCard) listCard.classList.add('hidden');
      if (detail) {
        detail.classList.remove('hidden');
        document.getElementById('prophet-title').textContent = p.title;
        document.getElementById('prophet-body').textContent = p.body;
      }
    });
  });
}

document.getElementById('back-prophets')?.addEventListener('click', () => {
  document.getElementById('prophet-detail')?.classList.add('hidden');
  document.getElementById('prophets-list-card')?.classList.remove('hidden');
});

function renderSeerahList() {
  const list = document.getElementById('seerah-list');
  const detail = document.getElementById('seerah-detail');
  const listCard = document.getElementById('seerah-list-card');
  if (!list || typeof SEERAH_STORIES === 'undefined') return;
  if (listCard) listCard.classList.remove('hidden');
  if (detail) detail.classList.add('hidden');
  list.innerHTML = SEERAH_STORIES.map(s => `
    <div class="content-item" data-id="${s.id}">
      <div class="item-text">${s.title}</div>
      <div class="item-source">اضغط للقراءة</div>
    </div>
  `).join('');
  list.querySelectorAll('.content-item').forEach(el => {
    el.addEventListener('click', () => {
      const s = SEERAH_STORIES.find(x => x.id === el.dataset.id);
      if (!s) return;
      if (listCard) listCard.classList.add('hidden');
      if (detail) {
        detail.classList.remove('hidden');
        document.getElementById('seerah-title').textContent = s.title;
        document.getElementById('seerah-body').textContent = s.body;
      }
    });
  });
}

document.getElementById('back-seerah')?.addEventListener('click', () => {
  document.getElementById('seerah-detail')?.classList.add('hidden');
  document.getElementById('seerah-list-card')?.classList.remove('hidden');
});

// Start once; no fake sign-in screen or repeated initialization.
initApp();
