// EST-PRAYER — Advanced Main Application
// Premium Islamic PWA

let userLat = null, userLon = null;
let qiblaDirection = null;
let currentTimings = null;
let nextPrayerName = null;
let nextPrayerTime = null;
let tasbihCount = 0;
let tasbihTarget = 33;
let adhanEnabled = localStorage.getItem('est-adhan') !== '0';
let notifEnabled = localStorage.getItem('est-notif') !== '0';
let adhanAudio = null;
let countdownInterval = null;
let deferredInstallPrompt = null;

// ========== UTILITIES ==========
function showToast(msg, ms = 2500) {
  let t = document.querySelector('.toast');
  if (!t) {
    t = document.createElement('div');
    t.className = 'toast';
    document.body.appendChild(t);
  }
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), ms);
}

function formatCountdown(ms) {
  if (ms <= 0) return 'الآن';
  const h = Math.floor(ms / 3600000);
  const m = Math.floor((ms % 3600000) / 60000);
  const s = Math.floor((ms % 60000) / 1000);
  if (h > 0) return `${h}<small>س</small> ${m}<small>د</small> ${s}<small>ث</small>`;
  return `${m}<small>د</small> ${s}<small>ث</small>`;
}

function getHijriDate() {
  try {
    return new Intl.DateTimeFormat('ar-SA-u-ca-islamic', {
      day: 'numeric', month: 'long', year: 'numeric'
    }).format(new Date());
  } catch {
    return '—';
  }
}

function getGregDate() {
  return new Intl.DateTimeFormat('ar-EG', {
    weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'
  }).format(new Date());
}

// ========== AUTH ==========
document.getElementById('login-form').addEventListener('submit', (e) => {
  e.preventDefault();
  document.getElementById('auth-screen').style.display = 'none';
  document.getElementById('app').style.display = 'flex';
  initApp();
});

document.getElementById('logout-btn').addEventListener('click', () => {
  document.getElementById('app').style.display = 'none';
  document.getElementById('auth-screen').style.display = 'flex';
});

// ========== THEME ==========
const themeToggle = document.getElementById('theme-toggle');
const themeIcon = document.getElementById('theme-icon');

function setThemeIcon(isDark) {
  if (isDark) {
    themeIcon.innerHTML = '<circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>';
  } else {
    themeIcon.innerHTML = '<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>';
  }
}

themeToggle.addEventListener('click', () => {
  const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
  const next = isDark ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', next === 'dark' ? 'dark' : '');
  setThemeIcon(next === 'dark');
  localStorage.setItem('est-theme', next);
});

if (localStorage.getItem('est-theme') === 'dark') {
  document.documentElement.setAttribute('data-theme', 'dark');
  setThemeIcon(true);
}

// ========== NAV ==========
document.querySelectorAll('.nav-item').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    document.querySelectorAll('.section').forEach(s => s.classList.add('hidden'));
    const section = document.getElementById('section-' + btn.dataset.section);
    if (section) {
      section.classList.remove('hidden');
      if (btn.dataset.section === 'names') renderNames();
    }
  });
});

// ========== INIT ==========
async function initApp() {
  // Dates
  document.getElementById('hijri-date').textContent = getHijriDate();
  document.getElementById('greg-date').textContent = getGregDate();

  // Daily ayah
  const dayIndex = Math.floor(Date.now() / 86400000) % DAILY_AYAHS.length;
  const ayah = DAILY_AYAHS[dayIndex];
  document.getElementById('daily-ayah-text').textContent = ayah.text;
  document.getElementById('daily-ayah-ref').textContent = ayah.ref;

  // Service Worker
  if ('serviceWorker' in navigator) {
    try {
      await navigator.serviceWorker.register('./sw.js');
    } catch (e) { console.warn('SW failed', e); }
  }

  // Notifications
  if (notifEnabled && 'Notification' in window && Notification.permission === 'default') {
    Notification.requestPermission();
  }

  // Install prompt
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredInstallPrompt = e;
    const banner = document.getElementById('install-banner');
    if (banner && !localStorage.getItem('est-install-dismissed')) {
      banner.classList.remove('hidden');
    }
  });

  document.getElementById('install-btn')?.addEventListener('click', async () => {
    if (!deferredInstallPrompt) return;
    deferredInstallPrompt.prompt();
    const { outcome } = await deferredInstallPrompt.userChoice;
    if (outcome === 'accepted') showToast('تم التثبيت بنجاح');
    deferredInstallPrompt = null;
    document.getElementById('install-banner')?.classList.add('hidden');
  });

  document.getElementById('install-close')?.addEventListener('click', () => {
    document.getElementById('install-banner')?.classList.add('hidden');
    localStorage.setItem('est-install-dismissed', '1');
  });

  getLocation();
  setupAdhkar();
  setupTasbih();
  setupQuranUI();
  setupSettings();
  updateOfflineStatus();
  renderNames();
}

// ========== LOCATION & PRAYER ==========
function getLocation() {
  const display = document.getElementById('location-display');
  if (!navigator.geolocation) {
    display.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg><span>استخدام القاهرة (افتراضي)</span>`;
    userLat = 30.0444; userLon = 31.2357;
    loadPrayerTimes();
    loadQibla();
    return;
  }
  navigator.geolocation.getCurrentPosition(
    (pos) => {
      userLat = pos.coords.latitude;
      userLon = pos.coords.longitude;
      display.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg><span>${userLat.toFixed(3)}, ${userLon.toFixed(3)}</span>`;
      loadPrayerTimes();
      loadQibla();
    },
    () => {
      display.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg><span>القاهرة (تعذر الموقع)</span>`;
      userLat = 30.0444; userLon = 31.2357;
      loadPrayerTimes();
      loadQibla();
    },
    { enableHighAccuracy: true, timeout: 12000 }
  );
}

document.getElementById('method-select').addEventListener('change', loadPrayerTimes);

async function loadPrayerTimes() {
  const container = document.getElementById('prayer-times');
  container.innerHTML = '<div class="loading"><div class="spinner"></div>جاري التحميل...</div>';
  const method = document.getElementById('method-select').value;
  try {
    const res = await fetch(`https://api.aladhan.com/v1/timings?latitude=${userLat}&longitude=${userLon}&method=${method}`);
    const data = await res.json();
    if (data.code !== 200) throw new Error('API');
    currentTimings = data.data.timings;
    const t = currentTimings;
    const prayers = [
      { name: 'الفجر', key: 'Fajr' },
      { name: 'الشروق', key: 'Sunrise' },
      { name: 'الظهر', key: 'Dhuhr' },
      { name: 'العصر', key: 'Asr' },
      { name: 'المغرب', key: 'Maghrib' },
      { name: 'العشاء', key: 'Isha' }
    ];

    const now = new Date();
    const nowMin = now.getHours() * 60 + now.getMinutes();
    nextPrayerName = null;
    nextPrayerTime = null;

    let html = '';
    for (const p of prayers) {
      const timeStr = t[p.key];
      if (!timeStr) continue;
      const [h, m] = timeStr.split(':').map(Number);
      const pMin = h * 60 + m;
      const isPassed = pMin < nowMin && p.key !== 'Sunrise';
      const isNext = !nextPrayerName && !isPassed && p.key !== 'Sunrise';

      if (isNext) {
        nextPrayerName = p.name;
        nextPrayerTime = new Date();
        nextPrayerTime.setHours(h, m, 0, 0);
        if (nextPrayerTime <= now) nextPrayerTime.setDate(nextPrayerTime.getDate() + 1);
      }

      // If all passed, next is Fajr tomorrow
      html += `
        <div class="prayer-item ${isNext ? 'next' : ''} ${isPassed ? 'passed' : ''}">
          <div class="name"><span class="dot"></span>${p.name}</div>
          <div class="time">${timeStr}</div>
        </div>`;
    }

    // Fallback next prayer
    if (!nextPrayerName) {
      const fajr = t.Fajr;
      if (fajr) {
        const [h, m] = fajr.split(':').map(Number);
        nextPrayerName = 'الفجر';
        nextPrayerTime = new Date();
        nextPrayerTime.setDate(nextPrayerTime.getDate() + 1);
        nextPrayerTime.setHours(h, m, 0, 0);
      }
    }

    container.innerHTML = html;
    document.getElementById('next-prayer-name').textContent = nextPrayerName || '—';
    startCountdown();
    scheduleAdhanNotifications();
  } catch (err) {
    container.innerHTML = '<div class="empty-state">تعذر تحميل الأوقات. تحقق من الاتصال.</div>';
    console.error(err);
  }
}

function startCountdown() {
  if (countdownInterval) clearInterval(countdownInterval);
  const el = document.getElementById('next-countdown');
  function tick() {
    if (!nextPrayerTime) {
      el.textContent = '--';
      return;
    }
    const ms = nextPrayerTime - new Date();
    el.innerHTML = formatCountdown(ms);
    if (ms <= 0) {
      clearInterval(countdownInterval);
      loadPrayerTimes();
    }
  }
  tick();
  countdownInterval = setInterval(tick, 1000);
}

// ========== ADHAN & NOTIFICATIONS ==========
function setupSettings() {
  const adhanT = document.getElementById('adhan-toggle');
  const notifT = document.getElementById('notif-toggle');
  if (adhanEnabled) adhanT.classList.add('active');
  if (notifEnabled) notifT.classList.add('active');

  adhanT.addEventListener('click', () => {
    adhanEnabled = !adhanEnabled;
    adhanT.classList.toggle('active', adhanEnabled);
    adhanT.setAttribute('aria-checked', adhanEnabled);
    localStorage.setItem('est-adhan', adhanEnabled ? '1' : '0');
    showToast(adhanEnabled ? 'تم تفعيل الأذان' : 'تم إيقاف الأذان');
  });

  notifT.addEventListener('click', async () => {
    if (!notifEnabled && 'Notification' in window && Notification.permission !== 'granted') {
      const perm = await Notification.requestPermission();
      if (perm !== 'granted') {
        showToast('يرجى السماح بالإشعارات');
        return;
      }
    }
    notifEnabled = !notifEnabled;
    notifT.classList.toggle('active', notifEnabled);
    notifT.setAttribute('aria-checked', notifEnabled);
    localStorage.setItem('est-notif', notifEnabled ? '1' : '0');
    showToast(notifEnabled ? 'تم تفعيل الإشعارات' : 'تم إيقاف الإشعارات');
  });

  document.getElementById('test-adhan-btn').addEventListener('click', playAdhan);
}

function playAdhan() {
  try {
    if (adhanAudio) {
      adhanAudio.pause();
      adhanAudio = null;
    }
    adhanAudio = new Audio(ADHAN_URL);
    adhanAudio.play().catch(() => showToast('تعذر تشغيل الصوت'));
  } catch {
    showToast('تعذر تشغيل الأذان');
  }
}

function scheduleAdhanNotifications() {
  // Simple in-page check (full offline scheduling needs Push API + server)
  if (!currentTimings || !notifEnabled) return;
}

// ========== ADHKAR ==========
function setupAdhkar() {
  let currentType = 'morning';
  const list = document.getElementById('adhkar-list');

  function render() {
    const items = ADHKAR[currentType] || [];
    list.innerHTML = items.map((item, i) => `
      <div class="adhkar-item" data-idx="${i}">
        <div class="text">${item.ar}</div>
        <div class="meta">
          <span class="count-badge">${item.count}× · ${item.source || ''}</span>
          <button class="counter-btn" data-count="${item.count}" data-current="0">
            <span class="cur">0</span> / ${item.count}
          </button>
        </div>
      </div>
    `).join('');

    list.querySelectorAll('.counter-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        let cur = parseInt(btn.dataset.current) || 0;
        const max = parseInt(btn.dataset.count);
        cur = Math.min(cur + 1, max);
        btn.dataset.current = cur;
        btn.querySelector('.cur').textContent = cur;
        if (cur >= max) {
          btn.classList.add('done');
          btn.textContent = 'تم ✓';
        }
      });
    });
  }

  document.querySelectorAll('.adhkar-tabs .tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.adhkar-tabs .tab-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentType = btn.dataset.type;
      render();
    });
  });
  render();
}

// ========== TASBIH ==========
function setupTasbih() {
  const countEl = document.getElementById('tasbih-count');
  const targetEl = document.getElementById('tasbih-target');
  const btn = document.getElementById('tasbih-btn');

  function update() {
    countEl.textContent = tasbihCount;
    targetEl.textContent = tasbihTarget;
  }

  btn.addEventListener('click', () => {
    tasbihCount++;
    countEl.classList.add('bump');
    setTimeout(() => countEl.classList.remove('bump'), 120);
    update();
    if (navigator.vibrate) navigator.vibrate(15);
    if (tasbihCount >= tasbihTarget) {
      showToast('أحسنت! أكملت الهدف');
    }
  });

  document.getElementById('reset-tasbih').addEventListener('click', () => {
    tasbihCount = 0;
    update();
  });
  document.getElementById('set-33').addEventListener('click', () => { tasbihTarget = 33; update(); });
  document.getElementById('set-99').addEventListener('click', () => { tasbihTarget = 99; update(); });
  document.getElementById('set-100').addEventListener('click', () => { tasbihTarget = 100; update(); });
  update();
}

// ========== QIBLA ==========
async function loadQibla() {
  if (userLat == null) return;
  try {
    const res = await fetch(`https://api.aladhan.com/v1/qibla/${userLat}/${userLon}`);
    const data = await res.json();
    if (data.code === 200) {
      qiblaDirection = data.data.direction;
      document.getElementById('qibla-degree').textContent = Math.round(qiblaDirection) + '°';
      document.getElementById('qibla-info').textContent = `اتجاه القبلة من موقعك: ${Math.round(qiblaDirection)}°`;
      document.getElementById('qibla-needle').style.transform = `rotate(${qiblaDirection}deg)`;
    }
  } catch {
    document.getElementById('qibla-info').textContent = 'تعذر حساب القبلة';
  }

  // Device orientation if available
  if (window.DeviceOrientationEvent) {
    window.addEventListener('deviceorientation', (e) => {
      if (qiblaDirection == null || e.alpha == null) return;
      const heading = e.webkitCompassHeading || (360 - e.alpha);
      const rotation = qiblaDirection - heading;
      document.getElementById('compass-inner').style.transform = `rotate(${rotation}deg)`;
    }, true);
  }
}

// ========== QURAN UI ==========
function setupQuranUI() {
  const list = document.getElementById('surah-list');
  const search = document.getElementById('surah-search');

  function renderSurahs(filter = '') {
    const q = filter.trim().toLowerCase();
    const filtered = SURAH_NAMES.filter(s =>
      !q || s.ar.includes(q) || s.en.toLowerCase().includes(q) || String(s.n).includes(q)
    );
    list.innerHTML = filtered.map(s => `
      <div class="surah-item" data-n="${s.n}">
        <div class="num">${s.n}</div>
        <div class="info">
          <div class="ar">${s.ar}</div>
          <div class="en">${s.en}</div>
        </div>
        <div class="ayahs">${s.ayahs} آية</div>
      </div>
    `).join('');

    list.querySelectorAll('.surah-item').forEach(el => {
      el.addEventListener('click', () => openSurah(parseInt(el.dataset.n)));
    });
  }

  search?.addEventListener('input', () => renderSurahs(search.value));
  renderSurahs();

  document.getElementById('back-to-surahs')?.addEventListener('click', () => {
    document.getElementById('quran-reader').classList.add('hidden');
    document.getElementById('surah-list-card').classList.remove('hidden');
  });

  document.getElementById('download-quran-btn')?.addEventListener('click', downloadFullQuran);
  document.getElementById('clear-quran-btn')?.addEventListener('click', clearQuranStorage);
}

async function openSurah(n) {
  const surah = SURAH_NAMES.find(s => s.n === n);
  if (!surah) return;
  document.getElementById('surah-list-card').classList.add('hidden');
  const reader = document.getElementById('quran-reader');
  reader.classList.remove('hidden');
  document.getElementById('reader-title').textContent = surah.ar;
  const container = document.getElementById('ayahs-container');
  container.innerHTML = '<div class="loading"><div class="spinner"></div>جاري التحميل...</div>';

  try {
    const ayahs = await getSurahAyahs(n);
    container.innerHTML = ayahs.map((a, i) =>
      `<span class="ayah">${a.text} <span class="ayah-num">${i + 1}</span></span> `
    ).join('');
  } catch {
    container.innerHTML = '<div class="empty-state">تعذر تحميل السورة. حاول مرة أخرى أو فعّل التحميل دون نت.</div>';
  }
}

// ========== NAMES OF ALLAH ==========
function renderNames(filter = '') {
  const grid = document.getElementById('names-grid');
  if (!grid) return;
  const q = filter.trim();
  const list = ALLAH_NAMES.filter(n => !q || n.ar.includes(q) || String(n.n).includes(q));
  grid.innerHTML = list.map(n => `
    <div class="name-card">
      <div class="ar">${n.ar}</div>
      <div class="num">${n.n}</div>
    </div>
  `).join('');
}

document.getElementById('names-search')?.addEventListener('input', (e) => {
  renderNames(e.target.value);
});

// ========== OFFLINE STATUS ==========
function updateOfflineStatus() {
  const el = document.getElementById('offline-status');
  if (!el) return;
  if (typeof getQuranStorageInfo === 'function') {
    getQuranStorageInfo().then(info => {
      if (info && info.count > 0) {
        el.textContent = `متوفر دون نت: ${info.count} سورة`;
      } else {
        el.textContent = 'غير محمّل — يمكنك التحميل للعمل دون نت';
      }
    }).catch(() => {
      el.textContent = 'جاهز للتحميل';
    });
  } else {
    el.textContent = 'جاهز';
  }
}
