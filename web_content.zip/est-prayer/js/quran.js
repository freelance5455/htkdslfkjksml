// Quran module - load, cache offline, render

const QURAN_CDN = 'https://cdn.jsdelivr.net/gh/fawazahmed0/quran-api@1/editions/ara-quranuthmanihaf';

async function fetchSurahFromNetwork(num) {
  const res = await fetch(`${QURAN_CDN}/${num}.json`);
  if (!res.ok) throw new Error('Network error');
  const data = await res.json();
  return data.chapter || data;
}

async function loadSurah(num, { forceNetwork = false } = {}) {
  if (!forceNetwork) {
    const cached = await getSurah(num);
    if (cached) return { verses: cached, fromCache: true };
  }
  const verses = await fetchSurahFromNetwork(num);
  await saveSurah(num, verses);
  return { verses, fromCache: false };
}

async function downloadAllQuran(onProgress) {
  const cached = await getCachedSurahs();
  const total = 114;
  let done = cached.length;
  if (onProgress) onProgress(done, total);

  for (let i = 1; i <= 114; i++) {
    if (cached.includes(i)) continue;
    try {
      const verses = await fetchSurahFromNetwork(i);
      await saveSurah(i, verses);
      done++;
      if (onProgress) onProgress(done, total);
      // Small delay to avoid overwhelming the browser
      await new Promise(r => setTimeout(r, 80));
    } catch (e) {
      console.warn('Failed surah', i, e);
    }
  }
  await setMeta('quranFullyCached', done === total);
  return done;
}

function renderSurahList(container, cachedSet) {
  container.innerHTML = SURAH_NAMES.map(s => `
    <div class="surah-item ${cachedSet.has(s.n) ? 'cached' : ''}" data-surah="${s.n}">
      <div class="surah-number">${s.n}</div>
      <div class="surah-info">
        <div class="ar">${s.ar}</div>
        <div class="en">${s.en}</div>
      </div>
      <div class="surah-ayahs">${s.ayahs} آية</div>
    </div>
  `).join('');
}

function escapeQuranText(value) {
  return String(value ?? '').replace(/[&<>\"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[ch]));
}

function renderAyahs(container, verses) {
  container.innerHTML = verses.map(v => `
    <div class="ayah">
      <span class="ayah-number">${Number(v.verse) || ''}</span>
      ${escapeQuranText(v.text)}
    </div>
  `).join('');
}

// Helpers used by app.js
async function getSurahAyahs(num) {
  const result = await loadSurah(num);
  const verses = result.verses;
  // Normalize the common Quran CDN response shapes.
  let rows = Array.isArray(verses) ? verses :
    Array.isArray(verses?.verses) ? verses.verses :
    Array.isArray(verses?.chapter) ? verses.chapter : null;
  if (rows) {
    return rows.map((v, i) => ({
      text: String(v?.text ?? v?.arabic ?? v?.verse_text ?? (typeof v === 'string' ? v : '')),
      verse: Number(v?.verse_number ?? v?.number ?? v?.id ?? (typeof v?.verse === 'number' ? v.verse : i + 1))
    })).filter(v => v.text);
  }
  if (verses && verses.verse && typeof verses.verse === 'object') {
    return Object.keys(verses.verse).map(k => ({ text: String(verses.verse[k]), verse: Number(k) }));
  }
  return [];
}

async function downloadFullQuran() {
  const progress = document.getElementById('download-progress');
  const fill = document.getElementById('download-fill');
  const status = document.getElementById('offline-status');
  if (progress) progress.classList.remove('hidden');
  try {
    const downloaded = await downloadAllQuran((done, total) => {
      if (fill) fill.style.width = ((done / total) * 100) + '%';
      if (status) status.textContent = `جاري التحميل... ${done}/${total}`;
    });
    if (downloaded === 114) {
      if (status) status.textContent = 'تم تحميل المصحف بالكامل — جاهز دون إنترنت';
      showToast('تم تحميل المصحف بالكامل');
    } else {
      if (status) status.textContent = `تم تحميل ${downloaded} من 114 سورة؛ أعد المحاولة لإكمال الباقي`;
      showToast('اكتمل التحميل جزئياً؛ بعض السور لم تُحمّل');
    }
  } catch (e) {
    showToast('حدث خطأ أثناء التحميل');
  } finally {
    if (progress) setTimeout(() => progress.classList.add('hidden'), 1500);
    updateOfflineStatus();
  }
}

async function clearQuranStorage() {
  await clearQuranCache();
  await setMeta('quranFullyCached', false);
  showToast('تم مسح التخزين');
  updateOfflineStatus();
}

async function getQuranStorageInfo() {
  const keys = await getCachedSurahs();
  return { count: keys.length };
}
