const CACHE_NAME = 'mihrab-v10';
const ASSETS = [
  './', './index.html', './manifest.json',
  './css/style.css', './css/variables.css', './css/base.css', './css/components.css',
  './css/layout.css', './css/prayer.css', './css/features.css', './css/advanced.css',
  './js/data.js', './js/content.js', './js/storage.js', './js/quran.js', './js/app.js',
  './icons/icon-192.png', './icons/icon-512.png', './icons/apple-touch-icon.png'
];
self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE_NAME).then((c) => c.addAll(ASSETS)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;
  const requestURL = new URL(event.request.url);
  const isRemoteData = requestURL.hostname === 'api.aladhan.com' ||
    requestURL.hostname === 'cdn.jsdelivr.net' || requestURL.hostname === 'cdn.aladhan.com' ||
    requestURL.hostname === 'fonts.googleapis.com' || requestURL.hostname === 'fonts.gstatic.com';

  if (isRemoteData) {
    event.respondWith((async () => {
      try {
        const response = await fetch(event.request);
        if (response && (response.ok || response.type === 'opaque')) {
          const cache = await caches.open(CACHE_NAME);
          await cache.put(event.request, response.clone()).catch(() => {});
        }
        return response;
      } catch {
        const cached = await caches.match(event.request);
        if (cached) return cached;
        return new Response(JSON.stringify({ code: 503, message: 'Offline and no cached response' }), {
          status: 503, headers: { 'Content-Type': 'application/json; charset=utf-8' }
        });
      }
    })());
    return;
  }

  if (event.request.mode === 'navigate') {
    event.respondWith((async () => {
      try {
        const response = await fetch(event.request);
        const cache = await caches.open(CACHE_NAME);
        cache.put('./index.html', response.clone()).catch(() => {});
        return response;
      } catch {
        return (await caches.match(event.request)) || (await caches.match('./index.html')) || Response.error();
      }
    })());
    return;
  }

  event.respondWith((async () => {
    const cached = await caches.match(event.request);
    if (cached) return cached;
    try {
      const response = await fetch(event.request);
      if (response && response.ok) {
        const cache = await caches.open(CACHE_NAME);
        cache.put(event.request, response.clone()).catch(() => {});
      }
      return response;
    } catch { return cached || Response.error(); }
  })());
});

self.addEventListener('notificationclick', (e) => {
  e.notification.close();
  e.waitUntil((async () => {
    const windows = await clients.matchAll({ type: 'window', includeUncontrolled: true });
    for (const client of windows) { if ('focus' in client) return client.focus(); }
    if (clients.openWindow) return clients.openWindow('./');
  })());
});
