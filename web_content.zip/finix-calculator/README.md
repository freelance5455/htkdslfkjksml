# FINIX Calculator

**FINIX CALCULATOR — Planeie • Calcule • Construa** é um protótipo web responsivo, em português, para planeamento inicial de obras, estimativas de materiais e custos, e cálculos práticos de negócio e finanças. A moeda inicial é Kz (AOA).

## Como executar

A aplicação usa módulos JavaScript e recursos PWA; não deve ser aberta directamente como ficheiro (`file://`). Serve a pasta por HTTP local num navegador moderno. A partir da pasta pai, executa:

```bash
python3 -m http.server 8000
```

Depois abre `http://localhost:8000/finix-calculator/`. A instalação da PWA e o service worker normalmente exigem HTTPS ou localhost. O modo offline pode ser testado após uma primeira visita bem-sucedida através do servidor.

## Conteúdo

- Painel inicial, navegação por áreas, pesquisa de materiais/ferramentas/calculadoras e favoritos locais.
- Catálogo de demonstração com cerca de 70 materiais, 27 ferramentas manuais, 20 ferramentas eléctricas e 18 equipamentos para consulta/aluguer. Inclui imagens locais para obra, materiais, ferramentas e equipamentos.
- Materiais: ver lista completa, consultar detalhes, calcular custo e desperdício, alterar preços de referência e criar itens personalizados.
- Construção: área, paredes, blocos, betão/concreto com parâmetros ajustáveis, pisos/revestimentos, pintura, telhado com opções de cobertura, piscina com formatos, planeamento preliminar de casa e volumes.
- Outras áreas: canalização/tubagens, estimativa de carga e consumo eléctrico, mão de obra, comparação de compra e aluguer, margem/preço de venda, custos comerciais, ponto de equilíbrio, ROI, custos de importação de automóvel, juros compostos, empréstimos, perímetro, idade, horas de trabalho e conversões de unidades (incluindo temperatura, velocidade e tempo).
- Orçamento: itens editáveis, duplicáveis e removíveis; mão de obra, transporte, desperdício e custos adicionais; guardar versões localmente; imprimir ou usar “Guardar como PDF” do navegador; exportar CSV separado por ponto e vírgula, compatível com Excel.
- Assistente de estimativas FINIX AI local baseado em regras para algumas perguntas; entrada de voz depende do suporte do navegador.
- Interface adaptável a ecrãs móveis, armazenamento local e shell PWA básico.

## Dados, privacidade e limitações

Esta versão é um protótipo de front-end, não um serviço de produção. Os preços e alguns parâmetros iniciais são **demonstrativos**, não são cotações actuais de fornecedores. Altera-os e confirma valores, disponibilidade, impostos, desperdícios e unidades na tua região antes de tomar decisões.

Os cálculos são estimativas indicativas; não substituem medições, projecto, normas aplicáveis ou validação por profissionais. Em particular, estimativas estruturais, de betão, electricidade, canalização e piscinas não fazem dimensionamento executivo. As notas de segurança na aplicação devem ser observadas.

A FINIX AI é uma interpretação simples por regras executada localmente, **não está ligada a um modelo/serviço de IA**. Não existe backend, conta, colaboração, sincronização na nuvem, consulta de preços a fornecedores nem câmbio em tempo real. Os dados do orçamento, preferências, histórico, preços alterados, materiais personalizados e favoritos ficam no `localStorage` deste navegador/dispositivo; não são sincronizados e podem ser apagados ao limpar os dados do navegador.

A exportação é CSV (não cria um ficheiro `.xlsx` nativo). A função imprimir abre a impressão do navegador, onde podes seleccionar “Guardar como PDF”; não existe um serviço próprio de geração de PDF. A disponibilidade offline depende do suporte do navegador e de uma visita inicial com o service worker instalado.

## Estrutura

- `index.html` — aplicação e layout principal
- `css/styles.css` — identidade visual e responsividade
- `js/app.js` — navegação, pesquisa, orçamento, armazenamento e interface
- `data/catalog.js` — materiais, ferramentas, equipamentos, módulos e categorias
- `calculators/formulas.js` — fórmulas e estimativas isoladas
- `assets/` — imagem de obra, folhas visuais de produtos e ícone
- `manifest.webmanifest` e `sw.js` — configuração PWA e cache inicial
