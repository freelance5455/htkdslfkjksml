# Wearday (Android app)

Plan outfits by date. Import photos from your gallery or camera, group them into a look for a day,
and get a notification the evening before, even when the app is closed.

## What you need once
- Node.js 20 or newer: https://nodejs.org
- Android Studio (includes the Android SDK and the right Java): https://developer.android.com/studio

## Build the APK
1. Unzip this folder and open a terminal inside it.
2. `npm install`
3. `npm run setup`   (creates the Android project, adds camera + notification permissions)
4. `npm run open`   (opens Android Studio; let Gradle finish syncing)
5. In Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s).
   The APK is at `android/app/build/outputs/apk/debug/app-debug.apk`. Copy it to your phone and install it.

Command-line alternative to steps 4-5 (needs Android SDK + JDK 21 set up): `npm run apk`

## Changing the app later
Edit `www/index.html`, then run `npm run sync` and rebuild.

## Notes
- Gallery uses the Android photo picker; Camera opens your camera app.
- Reminders are scheduled on the phone for the time you set the evening before. On first launch allow
  Notifications. On some phones (Xiaomi, Oppo, Vivo, Samsung) also set Wearday's battery to
  "Unrestricted" so reminders are not delayed.
- Looks and photos are stored on the phone inside the app. Uninstalling the app removes them.
- Fonts load from Google Fonts when online; offline the app falls back to system fonts.
