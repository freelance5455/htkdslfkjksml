// Creates the Android project, adds the permissions Wearday needs, and syncs the web app into it.
// Run with:  npm run setup      (add --apk to also build a debug APK from the command line)
const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const run = c => { console.log('\n> ' + c); execSync(c, { stdio: 'inherit', shell: true }); };

if (!fs.existsSync('android')) run('npx cap add android');

const mf = path.join('android', 'app', 'src', 'main', 'AndroidManifest.xml');
let x = fs.readFileSync(mf, 'utf8');
const perms = [
  'android.permission.CAMERA',
  'android.permission.POST_NOTIFICATIONS',
  'android.permission.SCHEDULE_EXACT_ALARM',
  'android.permission.RECEIVE_BOOT_COMPLETED'
];
let add = '';
for (const p of perms) if (!x.includes(p)) add += `    <uses-permission android:name="${p}" />\n`;
if (!x.includes('android.hardware.camera'))
  add += '    <uses-feature android:name="android.hardware.camera" android:required="false" />\n';
if (add) { x = x.replace('</manifest>', add + '</manifest>'); fs.writeFileSync(mf, x); console.log('Permissions added to AndroidManifest.xml'); }

run('npx cap sync android');

if (process.argv.includes('--apk')) {
  const gw = process.platform === 'win32' ? 'gradlew.bat' : './gradlew';
  execSync(`${gw} assembleDebug`, { cwd: 'android', stdio: 'inherit', shell: true });
  console.log('\nAPK: android/app/build/outputs/apk/debug/app-debug.apk');
} else {
  console.log('\nDone. Now run:  npm run open   (opens Android Studio), then Build > Build APK(s).');
}
