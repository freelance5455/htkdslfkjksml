YAWMI | يومي — حزمة تجهيز Firebase
====================================

المشروع المستهدف: yawmi-e530d

محتويات الحزمة:
- index.html: واجهة التطبيق وربط Firebase Auth وFirestore وتهيئة Analytics الاختيارية.
- firestore.rules: قواعد تحصر بيانات كل مستخدم في حسابه.
- firebase.json و .firebaserc: إعدادات Firebase CLI للمشروع الحالي.

مهم قبل التشغيل:
لم يتم تسجيل Web App أو قراءة مفاتيح إعداداته من حساب Firebase الخاص بك من داخل هذه المحادثة.
تم ضبط projectId وauthDomain المعروفين فقط. يجب نسخ بقية القيم من Firebase Console وعدم تخمينها.

الخطوات:
1) افتح Firebase Console واختر المشروع yawmi-e530d نفسه، ولا تنشئ مشروعاً جديداً.
2) Project settings (⚙) > General > Your apps.
3) إذا لم يوجد تطبيق ويب، اضغط </> لإضافة Web App، وسمّه YAWMI Web. لا تحتاج Firebase Hosting لتسجيل التطبيق.
4) انسخ كائن إعدادات SDK (firebaseConfig) وأدخل القيم في نهاية index.html مكان:
   YOUR_API_KEY, YOUR_STORAGE_BUCKET, YOUR_MESSAGING_SENDER_ID, YOUR_APP_ID, YOUR_MEASUREMENT_ID.
   اترك projectId وauthDomain كما هما ما داما مطابقين لمشروع yawmi-e530d.
5) من Authentication > Get started > Sign-in method فعّل Email/Password وGoogle. الهاتف اختياري وقد تترتب عليه رسوم رسائل.
6) من Authentication > Settings > Authorized domains أضف نطاق الموقع الذي ستستضيف عليه التطبيق.
7) من Firestore Database أنشئ قاعدة البيانات، ثم انشر محتوى firestore.rules.
8) افتح index.html عبر استضافة HTTPS للاختبار. تسجيل Google المنبثق وPhone Auth قد لا يعملان عند فتح الملف مباشرة file://.

النشر عبر Firebase CLI (من جهاز كمبيوتر مع Node.js وFirebase CLI):
  npm install -g firebase-tools
  firebase login
  firebase use yawmi-e530d
  firebase deploy --only firestore:rules,hosting

قبل النشر: تأكد أن إعدادات Web App مكتملة داخل index.html. إذا لم تكن مستعداً للنشر، لا تنفذ firebase deploy.

حول الميزات:
- حفظ البيانات المحلي يعمل عبر المتصفح.
- المزامنة السحابية تعمل بعد استكمال إعدادات Firebase وتفعيل Auth وFirestore.
- Google Analytics اختياري ويحتاج measurementId من Web App config.
- Gemini لا يتم استدعاؤه من هذا الملف؛ تفعيل Gemini داخل Firebase Console لا يضيف ذكاءً اصطناعياً تلقائياً إلى التطبيق.
- تنبيهات الموقع في الخلفية عند إغلاق التطبيق غير مدعومة في نسخة HTML؛ تتطلب تطبيق Android أصلياً وصلاحيات مناسبة.
- هذه الحزمة لم تُختبر على مشروع Firebase الفعلي لأن بيانات Web App وصلاحيات الحساب غير متاحة هنا.
