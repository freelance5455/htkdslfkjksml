# ANONYMOUX STUDIO 2.4.7 — Voice Agent Integration & Resources Rebuild

## Source

- Based on the supplied ANONYMOUX STUDIO 2.4.6 updated project archive.
- Existing application structure and server-side integration points were retained.

## Voice Studio / Voice Agent

- Added `app/agent_workspace.php` as a shared workspace partial used by both `voice-studio.php` and the existing `agent-studio.php` route.
- Embedded the complete agent workflow inside Voice Studio: list, create, edit, publish, test and delete agents; knowledge-source management; and agent configuration.
- Reused existing authenticated `api/agent/*` endpoints and the shared `api/voice/voices.php` Fish Audio catalogue.
- Kept provider credentials server-side and retained the existing Fish Audio provider integration.
- Preserved the shared selected-voice browser key so a voice selected in Voice Studio can be preselected during agent creation.
- Fixed the create-dialog initialization bug that cleared the shared selected voice before the form opened.
- Kept agent voice IDs and provider association in the existing `agents.config_json` configuration; no new database schema was introduced.
- Preserved the standalone AI Agent Studio route for backwards compatibility.

## Resources catalogue rebuild

- Rebuilt `resources.php` around a reusable database-backed query service, `resources_catalog_page()` in `app/resources.php`.
- Added prepared search and category filtering, result counts and bounded pagination.
- Rebuilt the public catalogue cards for tools and tutorials with responsive layouts, media, official provider links, pricing/platform metadata, tutorial reading information and compatibility/setup details.
- Retained the existing published/draft behavior, categories, resource-media routes and tutorial detail route.
- No sample/fake resource records were introduced.

## Admin resource management

- Added searchable, paginated resource lists (50 records per page) rather than limiting management to the first 200 records.
- Added bulk publish, move-to-draft and delete operations for tools and tutorials (maximum 100 selected records per request).
- Added safe category deletion, blocked while resources remain assigned; existing activate/deactivate and edit functionality remains.
- Kept single-record create/edit/delete, tutorial steps, related resources, media uploads/removal, provider URL validation, CSRF validation, admin authentication and audit logging.
- Added cleanup of tutorial relation references when tools or tutorials are deleted.

## Files changed

- `resources.php`
- `app/resources.php`
- `app/resource_admin.php`
- `admin_resources_view.php`
- `voice-studio.php`
- `agent-studio.php`
- `app/agent_workspace.php` (new shared partial)
- `assets/resources.css`
- `assets/agent-studio.js`
- `assets/voice-studio.css`
- `app/platform_header.php`
- `tests/resource_admin_regression_check.py`
- `tests/branding_voice_integration_check.py`

## Verification

- PHP syntax check: all 76 PHP files passed `php -l`.
- JavaScript syntax check: all 12 top-level asset JS files passed `node --check`.
- `tests/resource_admin_regression_check.py`: passed; validates Resources query/filter/pagination wiring, admin search, bulk operations, safe category deletion, tutorial editor state, history polling and range-media checks.
- `tests/resource_migration_check.py`: passed; SQLite migration remains repeatable and preserves the expected resource tables/indexes and foreign-key behavior.
- `tests/branding_voice_integration_check.py`: passed; validates retained branding assets, dashboard contrast/responsiveness, shared Fish Audio voice wiring, Voice Agent inclusion in Voice Studio and database-backed Resources wiring.
- ZIP archive integrity check: passed after packaging.

## Not verified in this environment

- Live database-backed browser rendering and write operations could not be run because this environment does not have a configured production database connection/PDO driver.
- Live Fish Audio catalogue responses, remote agent creation/update, provider voice sample playback and real speech generation require the deployment server's cURL/OpenSSL support and valid Fish Audio credentials.
- Mobile/tablet/desktop browser visual testing was not available; responsive CSS was added and statically checked.
- Existing API contracts, auth, payment, credit and database structures were not intentionally changed. No database migration is included or required by this build.

## Deployment notes

- Deploy the full archive as a replacement of the application code while preserving private config and storage directories.
- Keep `ANONYMOUX_KEY_ENCRYPTION_SECRET` stable and configured; configure Fish Audio through Admin → Voice AI or `FISH_AUDIO_API_KEY` server-side.
- Verify the Resources page, Admin → Resources, Voice Studio agent creation/editing, and a Fish Audio preview on the production host before announcing the build.
