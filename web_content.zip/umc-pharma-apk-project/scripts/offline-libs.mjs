// Télécharge les bibliothèques JS dans www/libs et remplace les liens CDN de index.html
// => l'APK fonctionne 100 % hors ligne.  (nécessite Node 18+ et internet, une seule fois)
import { readFileSync, writeFileSync, mkdirSync, existsSync, statSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const www = join(root, 'www');
const LIBS = [
  ['https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js', 'chart.umd.min.js'],
  ['https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js', 'xlsx.full.min.js'],
  ['https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js', 'jspdf.umd.min.js'],
  ['https://cdn.jsdelivr.net/npm/docx@8.5.0/build/index.js', 'docx.min.js'],
  ['https://cdn.jsdelivr.net/npm/@zxing/library@0.21.3/umd/index.min.js', 'zxing.min.js'],
];

mkdirSync(join(www, 'libs'), { recursive: true });
const htmlPath = join(www, 'index.html');
let html = readFileSync(htmlPath, 'utf8');

for (const [url, name] of LIBS) {
  const dest = join(www, 'libs', name);
  if (!existsSync(dest) || statSync(dest).size < 5000) {
    process.stdout.write('↓ ' + name + ' … ');
    const r = await fetch(url);
    if (!r.ok) throw new Error('HTTP ' + r.status + ' pour ' + url);
    const txt = await r.text();
    if (txt.length < 5000 || /^\s*<!doctype html/i.test(txt)) throw new Error('Contenu invalide pour ' + url);
    writeFileSync(dest, txt);
    console.log('ok (' + Math.round(txt.length / 1024) + ' Ko)');
  } else console.log('✓ ' + name + ' déjà présent');
  html = html.split(url).join('libs/' + name);
}
writeFileSync(htmlPath, html);
const left = html.match(/https?:\/\/[^"'\s)]+\.js/g);
console.log(left ? 'Attention, liens restants : ' + left.join(', ') : 'index.html : tous les scripts sont maintenant locaux.');
