// Ajoute la permission CAMERA (scan code-barres) dans AndroidManifest.xml après "cap add android"
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = process.env.UMC_ROOT || join(dirname(fileURLToPath(import.meta.url)), '..');
const f = join(root, 'android/app/src/main/AndroidManifest.xml');
if (!existsSync(f)) { console.error('AndroidManifest.xml introuvable : lancez d’abord "npx cap add android".'); process.exit(1); }
let x = readFileSync(f, 'utf8');
const add = [];
if (!x.includes('android.permission.CAMERA')) add.push('    <uses-permission android:name="android.permission.CAMERA" />');
if (!x.includes('android.hardware.camera"')) add.push('    <uses-feature android:name="android.hardware.camera" android:required="false" />');
if (add.length) {
  x = x.replace(/<\/manifest>\s*$/, add.join('\n') + '\n</manifest>');
  writeFileSync(f, x);
  console.log('AndroidManifest.xml : permission caméra ajoutée.');
} else console.log('AndroidManifest.xml : déjà à jour.');

// ---- Module natif « SaveFile » : choisir l'emplacement d'enregistrement (PDF, Excel, Word, CSV, JSON) ----
import { mkdirSync } from 'node:fs';
const cfg = JSON.parse(readFileSync(join(root, 'capacitor.config.json'), 'utf8'));
const pkg = cfg.appId;
const jdir = join(root, 'android/app/src/main/java', ...pkg.split('.'));
mkdirSync(jdir, { recursive: true });
writeFileSync(join(jdir, 'SaveFilePlugin.java'), `package ${pkg};

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.util.Base64;
import androidx.activity.result.ActivityResult;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.OutputStream;

@CapacitorPlugin(name = "SaveFile")
public class SaveFilePlugin extends Plugin {
    @PluginMethod
    public void save(PluginCall call) {
        if (call.getString("data") == null) { call.reject("no data"); return; }
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(call.getString("mimeType", "application/octet-stream"));
        i.putExtra(Intent.EXTRA_TITLE, call.getString("filename", "document"));
        startActivityForResult(call, i, "onSaved");
    }

    @ActivityCallback
    private void onSaved(PluginCall call, ActivityResult result) {
        if (call == null) return;
        JSObject o = new JSObject();
        if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null || result.getData().getData() == null) {
            o.put("saved", false);
            call.resolve(o);
            return;
        }
        Uri uri = result.getData().getData();
        try (OutputStream os = getContext().getContentResolver().openOutputStream(uri, "w")) {
            os.write(Base64.decode(call.getString("data"), Base64.DEFAULT));
            os.flush();
            o.put("saved", true);
            o.put("uri", uri.toString());
            call.resolve(o);
        } catch (Exception e) {
            call.reject("Écriture impossible : " + e.getMessage());
        }
    }
}
`);
writeFileSync(join(jdir, 'MainActivity.java'), `package ${pkg};

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(SaveFilePlugin.class);
        super.onCreate(savedInstanceState);
    }
}
`);
console.log('Module natif SaveFile ajouté (sélecteur d’emplacement).');
