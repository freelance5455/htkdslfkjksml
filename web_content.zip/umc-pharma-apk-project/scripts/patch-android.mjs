// Ajoute la permission CAMERA (scan code-barres) dans AndroidManifest.xml après "cap add android"
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = process.env.UMC_ROOT || join(dirname(fileURLToPath(import.meta.url)), '..');
const f = join(root, 'android/app/src/main/AndroidManifest.xml');
if (!existsSync(f)) { console.error('AndroidManifest.xml introuvable : lancez d’abord "npx cap add android".'); process.exit(1); }
let x = readFileSync(f, 'utf8');
const add = [];
if (!x.includes('android.permission.CAMERA')) add.push('    <uses-permission android:name="android.permission.CAMERA" />');
if (!x.includes('android.hardware.camera"')) add.push('    <uses-feature android:name="android.hardware.camera" android:required="false" />');
if (add.length) {
  x = x.replace(/<\/manifest>\s*$/, add.join('\n') + '\n</manifest>');
  writeFileSync(f, x);
  console.log('AndroidManifest.xml : permission caméra ajoutée.');
} else console.log('AndroidManifest.xml : déjà à jour.');

// ---- Module natif « SaveFile » : emplacement d'enregistrement, impression, envoi e-mail / WhatsApp ----
import { mkdirSync } from 'node:fs';
const cfg = JSON.parse(readFileSync(join(root, 'capacitor.config.json'), 'utf8'));
const pkg = cfg.appId;
const jdir = join(root, 'android/app/src/main/java', ...pkg.split('.'));
mkdirSync(jdir, { recursive: true });
writeFileSync(join(jdir, 'SaveFilePlugin.java'), `package ${pkg};

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.util.Base64;
import androidx.activity.result.ActivityResult;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Context;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

@CapacitorPlugin(name = "SaveFile")
public class SaveFilePlugin extends Plugin {
    private WebView printView;

    /** Impression native (dialogue Android : imprimante ou « Enregistrer au format PDF »). */
    @PluginMethod
    public void printHtml(final PluginCall call) {
        final String html = call.getString("html");
        final String name = call.getString("name", "UMC PHARMA");
        final boolean land = Boolean.TRUE.equals(call.getBoolean("landscape", false));
        if (html == null) { call.reject("no html"); return; }
        getActivity().runOnUiThread(() -> {
            try {
                printView = new WebView(getActivity());
                printView.setWebViewClient(new WebViewClient() {
                    @Override public void onPageFinished(WebView v, String u) {
                        PrintManager pm = (PrintManager) getActivity().getSystemService(Context.PRINT_SERVICE);
                        PrintAttributes.MediaSize ms = land ? PrintAttributes.MediaSize.ISO_A4.asLandscape() : PrintAttributes.MediaSize.ISO_A4;
                        pm.print(name, v.createPrintDocumentAdapter(name), new PrintAttributes.Builder().setMediaSize(ms).build());
                        call.resolve();
                    }
                });
                printView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
            } catch (Exception e) { call.reject("Impression impossible : " + e.getMessage()); }
        });
    }

    /** Envoi du fichier par e-mail ou WhatsApp (pièce jointe). */
    @PluginMethod
    public void sendFile(PluginCall call) {
        try {
            String data = call.getString("data");
            if (data == null) { call.reject("no data"); return; }
            String fn = call.getString("filename", "document").replaceAll("[^A-Za-z0-9._-]", "_");
            String mime = call.getString("mimeType", "application/octet-stream");
            String target = call.getString("target", "email");
            String subject = call.getString("subject", "");
            String text = call.getString("text", "");
            String email = call.getString("email", "");
            String phone = call.getString("phone", "");
            File dir = new File(getContext().getCacheDir(), "share");
            dir.mkdirs();
            File f = new File(dir, fn);
            try (FileOutputStream os = new FileOutputStream(f)) { os.write(Base64.decode(data, Base64.DEFAULT)); }
            Uri uri = FileProvider.getUriForFile(getContext(), getContext().getPackageName() + ".fileprovider", f);
            Intent i;
            if ("whatsapp".equals(target)) {
                i = new Intent(Intent.ACTION_SEND);
                i.setType(mime);
                i.putExtra(Intent.EXTRA_STREAM, uri);
                i.putExtra(Intent.EXTRA_TEXT, text);
                if (!phone.isEmpty()) i.putExtra("jid", phone + "@s.whatsapp.net");
                i.setClipData(ClipData.newRawUri("", uri));
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                for (String pk : new String[]{"com.whatsapp", "com.whatsapp.w4b"}) {
                    try { i.setPackage(pk); getActivity().startActivity(i); call.resolve(); return; }
                    catch (ActivityNotFoundException ignored) { }
                }
                i.setPackage(null);
                getActivity().startActivity(Intent.createChooser(i, "WhatsApp"));
            } else {
                i = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + Uri.encode(email)));
                i.putExtra(Intent.EXTRA_SUBJECT, subject);
                i.putExtra(Intent.EXTRA_TEXT, text);
                i.putExtra(Intent.EXTRA_STREAM, uri);
                i.setClipData(ClipData.newRawUri("", uri));
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                getActivity().startActivity(Intent.createChooser(i, "E-mail"));
            }
            call.resolve();
        } catch (Exception e) { call.reject("Envoi impossible : " + e.getMessage()); }
    }

    @PluginMethod
    public void save(PluginCall call) {
        if (call.getString("data") == null) { call.reject("no data"); return; }
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(call.getString("mimeType", "application/octet-stream"));
        i.putExtra(Intent.EXTRA_TITLE, call.getString("filename", "document"));
        startActivityForResult(call, i, "onSaved");
    }

    @ActivityCallback
    private void onSaved(PluginCall call, ActivityResult result) {
        if (call == null) return;
        JSObject o = new JSObject();
        if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null || result.getData().getData() == null) {
            o.put("saved", false);
            call.resolve(o);
            return;
        }
        Uri uri = result.getData().getData();
        try (OutputStream os = getContext().getContentResolver().openOutputStream(uri, "w")) {
            os.write(Base64.decode(call.getString("data"), Base64.DEFAULT));
            os.flush();
            o.put("saved", true);
            o.put("uri", uri.toString());
            call.resolve(o);
        } catch (Exception e) {
            call.reject("Écriture impossible : " + e.getMessage());
        }
    }
}
`);
writeFileSync(join(jdir, 'MainActivity.java'), `package ${pkg};

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(SaveFilePlugin.class);
        super.onCreate(savedInstanceState);
    }
}
`);
console.log('Module natif SaveFile ajouté (sélecteur d’emplacement).');
