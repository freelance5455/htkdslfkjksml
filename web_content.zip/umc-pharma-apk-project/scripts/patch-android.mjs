// Ajoute la permission CAMERA (scan code-barres) dans AndroidManifest.xml après "cap add android"
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = process.env.UMC_ROOT || join(dirname(fileURLToPath(import.meta.url)), '..');
const f = join(root, 'android/app/src/main/AndroidManifest.xml');
if (!existsSync(f)) { console.error('AndroidManifest.xml introuvable : lancez d’abord "npx cap add android".'); process.exit(1); }
let x = readFileSync(f, 'utf8');
const add = [];
if (!x.includes('android.permission.CAMERA')) add.push('    <uses-permission android:name="android.permission.CAMERA" />');
if (!x.includes('android.hardware.camera"')) add.push('    <uses-feature android:name="android.hardware.camera" android:required="false" />');
if (add.length) {
  x = x.replace(/<\/manifest>\s*$/, add.join('\n') + '\n</manifest>');
  writeFileSync(f, x);
  console.log('AndroidManifest.xml : permission caméra ajoutée.');
} else console.log('AndroidManifest.xml : déjà à jour.');
