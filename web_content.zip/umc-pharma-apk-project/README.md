# UMC PHARMA — حزمة تحويل التطبيق إلى APK

الحزمة تحتوي كل ما يلزم: التطبيق (`www/`)، إعدادات Capacitor، الأيقونة وشاشة البداية (`resources/`)، سكربتات البناء، وملف بناء سحابي (GitHub Actions).
الناتج: ملف `app-debug.apk` قابل للتثبيت مباشرة على الهاتف. يعمل دون إنترنت: السكربت يحمّل المكتبات داخل `www/libs` مرة واحدة.

## الطريقة 1 — بدون كمبيوتر قوي (GitHub Actions، مجاني)
1. أنشئ مستودعاً جديداً على github.com وارفع محتوى هذا المجلد كما هو (مع المجلد المخفي `.github`).
2. افتح تبويب **Actions** ← **Build APK** ← **Run workflow**.
3. بعد نحو 5 إلى 10 دقائق، نزّل `UMC-PHARMA-apk` من قسم Artifacts، وفيه `app-debug.apk`.

## الطريقة 2 — على الكمبيوتر
المتطلبات: Node.js 18 أو أحدث، وJava 17، وAndroid Studio (لتثبيت Android SDK).
- Windows: انقر مرتين على `build-apk.bat`
- Linux / macOS: `./build-apk.sh`

الملف الناتج: `android/app/build/outputs/apk/debug/app-debug.apk`

الخطوات اليدوية المكافئة:
```
npm install
node scripts/offline-libs.mjs
npx cap add android
node scripts/patch-android.mjs
npx capacitor-assets generate --android
npx cap sync android
cd android && ./gradlew assembleDebug
```

## تثبيت APK على الهاتف
انسخ الملف إلى الهاتف وافتحه، وفعّل "التثبيت من مصادر غير معروفة" إذا طُلب. عند أول مسح بالكاميرا اقبل إذن الكاميرا.

## ما الذي تم تجهيزه
- إذن الكاميرا يُضاف تلقائياً إلى `AndroidManifest.xml` (`scripts/patch-android.mjs`).
- التصدير والنسخ الاحتياطي (Excel / PDF / Word / CSV / JSON): تظهر نافذة اختيار مكان الحفظ (مجلد التنزيلات، المستندات، البطاقة...) عبر وحدة SaveFile الأصلية التي يضيفها scripts/patch-android.mjs تلقائياً. في حال تعذّرها تُستعمل قائمة المشاركة.
- PDF: جدول منظم بأعمدة متناسبة، رأس مكرر في كل صفحة، تذييل مع ترقيم الصفحات.
- معرّف التطبيق: `dz.djebaili.umcpharma`، والاسم: UMC PHARMA.

## سندات الطلب (جديد)
قسم "Bons de commande" في القائمة: إنشاء سند يدوياً (منتج + كمية، مع المسح بالكاميرا) أو تلقائياً من المنتجات الأقل من الحد الأدنى، ثم حفظه وطباعته أو تصديره PDF / Word / Excel / CSV.

## ملاحظات
- لتغيير الأيقونة: بدّل `resources/icon.png` (1024×1024) و`resources/splash.png` (2732×2732) ثم أعد البناء.
- النسخة الناتجة (debug) موقّعة بمفتاح تجريبي وتصلح للاستخدام الداخلي. للنشر على Google Play تحتاج نسخة release موقّعة (Android Studio ← Build ← Generate Signed Bundle / APK).
- محوّلات "HTML إلى APK" على الإنترنت قد لا تدعم الكاميرا وحفظ الملفات، فالأفضل الطريقتان أعلاه.

---
## FR (résumé)
Projet Capacitor complet. Voie 1 : poussez ce dossier sur GitHub → Actions → « Build APK » → téléchargez `app-debug.apk`.
Voie 2 : `build-apk.bat` (Windows) ou `./build-apk.sh` (Node 18+, Java 17, Android SDK). Les bibliothèques sont téléchargées dans `www/libs` (usage hors ligne), la permission caméra est ajoutée automatiquement, et les exports passent par la feuille de partage Android.
