#!/usr/bin/env bash
# Linux / macOS : génère l'APK (nécessite Node 18+, Java 17, Android SDK / Android Studio)
set -e
cd "$(dirname "$0")"
npm install
node scripts/offline-libs.mjs
[ -d android ] || npx cap add android
node scripts/patch-android.mjs
npx capacitor-assets generate --android || echo "(icônes : étape ignorée)"
npx cap sync android
(cd android && chmod +x gradlew && ./gradlew assembleDebug)
echo
echo "APK prêt : android/app/build/outputs/apk/debug/app-debug.apk"
