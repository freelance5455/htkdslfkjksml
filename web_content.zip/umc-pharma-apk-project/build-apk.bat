@echo off
REM Windows : genere l'APK (necessite Node 18+, Java 17, Android Studio / SDK)
cd /d "%~dp0"
call npm install || goto :err
call node scripts\offline-libs.mjs || goto :err
if not exist android call npx cap add android || goto :err
call node scripts\patch-android.mjs || goto :err
call npx capacitor-assets generate --android
call npx cap sync android || goto :err
cd android
call gradlew.bat assembleDebug || goto :err
cd ..
echo.
echo APK pret : android\app\build\outputs\apk\debug\app-debug.apk
pause
exit /b 0
:err
echo ERREUR - voir les messages ci-dessus.
pause
exit /b 1
