# تحويل الشات لتطبيق أندرويد (APK)

التطبيق عبارة عن واجهة الشات (`public/index.html`) داخل غلاف Capacitor.
التطبيق بيكلّم **السيرفر بتاعك** عن طريق الإنترنت، فالسيرفر لازم يكون شغّال ومنشور على عنوان يوصله الموبايل.

## 1) نشر السيرفر (مرة واحدة)
شغّل مجلد المشروع الرئيسي على أي استضافة Node.js (Render / Railway / VPS) وخليه على HTTPS.
اضبط المتغيرات: `JWT_SECRET` و `INVITE_CODE`.
عنوانه هيبقى مثلًا `https://chat.example.com`، وده اللي هتكتبه في التطبيق عند أول دخول.

## 2) المتطلبات على جهازك
- Node.js 20 أو أحدث
- JDK 17
- Android Studio (معاه Android SDK)

## 3) بناء الـ APK
افتح الترمينال داخل فولدر `mobile`:

```
npm install
npm run add-android      # مرة واحدة: بينشئ مشروع android
npm run sync             # بينسخ الواجهة ويحدّث مشروع الأندرويد
```

**الطريقة الأسهل (Android Studio):**
```
npm run open
```
من Android Studio: `Build` > `Build Bundle(s) / APK(s)` > `Build APK(s)`.

**أو من الأوامر:**
```
cd android
./gradlew assembleDebug        # على ويندوز: gradlew.bat assembleDebug
```
الملف بيطلع في:
`mobile/android/app/build/outputs/apk/debug/app-debug.apk`

انقله للموبايل وثبّته (فعّل "التثبيت من مصادر غير معروفة").

## 4) نسخة للنشر (Release)
من Android Studio: `Build` > `Generate Signed App Bundle / APK`، وأنشئ keystore واحفظه في مكان آمن.

## بعد أي تعديل في الواجهة
عدّل `public/index.html` ثم شغّل `npm run sync` تاني وابنِ الـ APK من جديد.

## ملاحظات
- أول مرة افتح التطبيق: اكتب عنوان السيرفر في خانة "عنوان السيرفر" ثم سجّل الدخول.
- الإشعارات شغّالة والتطبيق مفتوح بس. الإشعارات والتطبيق مقفول محتاجة Firebase (FCM) وتُضاف في مرحلة تانية.
- الخطوط بتتحمّل من Google Fonts، فبتحتاج إنترنت (والشات نفسه محتاج إنترنت أصلًا). لو عايز الخطوط داخل التطبيق نفسه، نزّل ملفات الخط وحطها في `public/fonts` واستخدم `@font-face`.
- أيقونة التطبيق: استبدل ملفات `mobile/android/app/src/main/res/mipmap-*` أو استخدم Android Studio > `New` > `Image Asset`.
