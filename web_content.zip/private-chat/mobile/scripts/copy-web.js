// ينسخ واجهة الشات من ../public إلى ./www (مصدر واحد للويب والتطبيق)
const fs = require('fs');
const path = require('path');

const src = path.join(__dirname, '..', '..', 'public');
const dst = path.join(__dirname, '..', 'www');

fs.rmSync(dst, { recursive: true, force: true });
fs.cpSync(src, dst, { recursive: true });
console.log('تم النسخ: ' + src + ' -> ' + dst);
