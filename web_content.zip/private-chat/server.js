const express = require('express');
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { Server } = require('socket.io');
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const multer = require('multer');

const SECRET = process.env.JWT_SECRET || 'change-me-please';
const INVITE = process.env.INVITE_CODE || 'team123'; // كود الدعوة: بس اللي معاه الكود يسجل
const PORT = process.env.PORT || 3000;

const db = new Database('chat.db');
db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE, pass TEXT);
CREATE TABLE IF NOT EXISTS messages(
  id INTEGER PRIMARY KEY, from_id INTEGER, to_id INTEGER, body TEXT, file TEXT, ts INTEGER
);`);
fs.mkdirSync('uploads', { recursive: true });

const app = express();

// CORS: لازم عشان تطبيق الأندرويد (APK) يكلم السيرفر من أصل مختلف
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

app.use(express.json());
app.use(express.static('public'));
app.use('/uploads', express.static('uploads'));

const storage = multer.diskStorage({
  destination: 'uploads/',
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase().replace(/[^.a-z0-9]/g, '').slice(0, 8);
    cb(null, Date.now() + '-' + crypto.randomBytes(8).toString('hex') + ext);
  }
});
const upload = multer({ storage, limits: { fileSize: 10 * 1024 * 1024 } });

const sign = (u) => jwt.sign({ id: u.id, username: u.username }, SECRET, { expiresIn: '30d' });
const auth = (req, res, next) => {
  try {
    req.user = jwt.verify((req.headers.authorization || '').replace('Bearer ', ''), SECRET);
    next();
  } catch { res.status(401).json({ error: 'غير مصرح' }); }
};

app.get('/api/ping', (req, res) => res.json({ ok: true }));

app.post('/api/register', (req, res) => {
  const { username, password, invite } = req.body || {};
  if (invite !== INVITE) return res.status(403).json({ error: 'كود الدعوة غلط' });
  if (!username || !password || password.length < 6) return res.status(400).json({ error: 'بيانات ناقصة' });
  try {
    const r = db.prepare('INSERT INTO users(username,pass) VALUES(?,?)')
      .run(username.trim(), bcrypt.hashSync(password, 10));
    const u = { id: r.lastInsertRowid, username: username.trim() };
    res.json({ token: sign(u), user: u });
  } catch { res.status(409).json({ error: 'الاسم مستخدم' }); }
});

app.post('/api/login', (req, res) => {
  const { username, password } = req.body || {};
  const u = db.prepare('SELECT * FROM users WHERE username=?').get(username);
  if (!u || !bcrypt.compareSync(password || '', u.pass)) return res.status(401).json({ error: 'بيانات غلط' });
  res.json({ token: sign(u), user: { id: u.id, username: u.username } });
});

app.get('/api/users', auth, (req, res) => {
  res.json(db.prepare('SELECT id, username FROM users WHERE id != ?').all(req.user.id));
});

// peer = 0 يعني الجروب العام
app.get('/api/messages/:peer', auth, (req, res) => {
  const me = req.user.id, peer = Number(req.params.peer);
  const rows = peer === 0
    ? db.prepare('SELECT * FROM messages WHERE to_id=0 ORDER BY id DESC LIMIT 100').all()
    : db.prepare(`SELECT * FROM messages WHERE (from_id=? AND to_id=?) OR (from_id=? AND to_id=?)
                  ORDER BY id DESC LIMIT 100`).all(me, peer, peer, me);
  res.json(rows.reverse());
});

app.post('/api/upload', auth, upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'مفيش ملف' });
  res.json({ file: '/uploads/' + req.file.filename, name: req.file.originalname });
});

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });
const online = new Map(); // userId -> عدد الاتصالات

io.use((socket, next) => {
  try { socket.user = jwt.verify(socket.handshake.auth.token, SECRET); next(); }
  catch { next(new Error('unauthorized')); }
});

io.on('connection', (socket) => {
  const me = socket.user.id;
  socket.join('u:' + me);
  online.set(me, (online.get(me) || 0) + 1);
  io.emit('presence', [...online.keys()]);

  socket.on('msg', ({ to, body, file }) => {
    if (!body && !file) return;
    to = Number(to) || 0;
    const ts = Date.now();
    const r = db.prepare('INSERT INTO messages(from_id,to_id,body,file,ts) VALUES(?,?,?,?,?)')
      .run(me, to, body || null, file || null, ts);
    const m = { id: r.lastInsertRowid, from_id: me, to_id: to, body, file, ts };
    if (to === 0) io.emit('msg', m);
    else io.to('u:' + to).to('u:' + me).emit('msg', m);
  });

  socket.on('typing', ({ to }) => {
    if (to === 0) socket.broadcast.emit('typing', { from: me, to });
    else io.to('u:' + to).emit('typing', { from: me, to });
  });

  socket.on('disconnect', () => {
    const n = (online.get(me) || 1) - 1;
    n ? online.set(me, n) : online.delete(me);
    io.emit('presence', [...online.keys()]);
  });
});

server.listen(PORT, () => console.log('Chat running on http://localhost:' + PORT));
