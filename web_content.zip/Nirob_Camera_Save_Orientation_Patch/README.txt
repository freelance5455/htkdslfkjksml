NIROB CAMERA / SAVE PATCH

This is an updated HTML prototype ZIP, not an installable APK.

Changes:
- Removed the automatic 90-degree video rotation based on sensor width/height. Preview and capture now use the same native video frame to avoid the previous sideways/rotated mismatch.
- Improved browser save behavior: uses Android share/save sheet when supported, requests a browser download, and provides a fallback to open the generated file.
- Existing Import, manual rotate, small-angle deskew, watermark/footer, PDF/JPG export remain in the prototype.

Important Android limitation:
A plain HTML page inside a WebView cannot guarantee saving files unless the APK implements a native DownloadListener / file-writing bridge and WebChromeClient.onShowFileChooser. Camera access also requires camera permission and a WebView/browser context that supports getUserMedia. If the download still does not work in the current APK, its native WebView wrapper must be changed; HTML alone cannot override that limitation.

Camera note:
The preview/capture no longer forcibly rotates the video. If the phone's camera provider itself reports incorrectly oriented frames, a native CameraX implementation is needed to guarantee correct orientation across devices.

How to test:
1. Extract the ZIP.
2. Open web/index.html in Chrome or a WebView that supports camera and file selection.
3. Test Import, Capture, JPG, and PDF.
4. Check Downloads / Android Share sheet for saved files.
