SkyCrash shared-round demo

Deploy the contents of this ZIP to your existing Netlify site. It includes index.html and admin.html.

Changes: new local game session starts at zero demo balance; Firebase Email/Password signup/login writes/updates the user's profile under users/{uid}; rounds are synchronized through sharedGame/current so connected clients can see the same round phase, start time, and crash point.

Important limitations: this is still a browser-based demo, not a secure real-money game backend. Player balances/bets are not authoritative server-side. Do not accept real deposits or withdrawals. Firebase Authentication must have Email/Password and Anonymous sign-in enabled. Realtime Database rules must allow authenticated clients to access sharedGame, and allow each signed-in user to read/write only their own users/{uid} record. Never enable public read/write rules. Test on a separate demo deployment first.

\n\nCOMPLETE ADMIN UPLOAD PACKAGE - IMPORTANT\n
This package includes the existing SkyCrash game frontend and admin dashboard, plus a manual balance adjustment panel.
Upload/extract the ZIP contents to your hosting site root (so index.html is at the root). The admin page is admin.html.
Admin sign-in requires the configured Firebase admin account and matching UID.

MANUAL BALANCE PANEL:
- Writes balance to users/{uid}/balance using a Realtime Database transaction.
- Writes an audit entry to transactions.
- IMPORTANT: The game's actual balance schema must match users/{uid}/balance. If index.html uses another path/field, the game balance will not update until that path is aligned.
- The browser admin panel alone is not a security boundary. Keep Realtime Database rules restricted to the verified admin UID for balance/transaction writes and allow only appropriate user reads. Never use public read/write rules.

NOT A FULL BACKEND:
This is a static hosting package. Static hosting alone does not provide a 24/7 server process. Shared round controller logic that runs in a browser stops when no browser is open. Real unattended 24/7 round processing, secure deposit/withdrawal processing, and server-authoritative game outcomes require a trusted backend/server or equivalent managed service. The existing rounds/bets are labelled as simulation; do not use this package to represent them as a verified real-money engine.
Before production use, test signup/login, actual game balance path, admin adjustment, deposit/withdrawal flows, round progression, and Firebase rules in a test account.
