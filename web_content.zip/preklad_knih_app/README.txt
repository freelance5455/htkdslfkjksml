PŘEKLAD KNIH DO ČEŠTINY – ZIP PRO WEBVIEW / APK BUILDER

Obsah:
- index.html – aplikace
- manifest.json – PWA metadata
- sw.js – základní cache pro offline otevření rozhraní

FORMÁTY:
EPUB, PDF s textovou vrstvou, DOCX a TXT.
Výstup: TXT v UTF-8 s českou diakritikou.

DŮLEŽITÉ:
Aplikace používá LibreTranslate API. Výchozí endpoint je https://libretranslate.com/translate,
ale veřejný server může vyžadovat API klíč, omezovat požadavky nebo být nedostupný.
V nastavení aplikace lze změnit URL serveru a vložit API klíč.
Překlad vyžaduje internet. Samotné rozhraní lze po prvním načtení částečně otevřít offline,
ale překlad offline nefunguje.

POUŽITÍ:
1. Rozbalte ZIP nebo nahrajte ZIP do nástroje pro sestavení Android aplikace, který přijímá webové/PWA soubory.
2. Jako vstupní stránku nastavte index.html.
3. Spusťte aplikaci, vyberte knihu a klepněte na Načíst knihu.
4. Nastavte překladový server a případný API klíč.
5. Spusťte překlad. Při chybě lze pokračovat od poslední dokončené části.
6. Uložte výsledek jako TXT.

OMEZENÍ TÉTO VERZE:
- Naskenované PDF bez textové vrstvy vyžaduje OCR a není zde podporováno.
- Zachovává se text a odstavce, nikoli původní sazba, obrázky, poznámky pod čarou ani přesné rozložení EPUB/PDF.
- EPUB kapitoly se načítají podle pořadí ve spine; ne všechny nestandardní EPUB soubory musí být kompatibilní.
- Kvalita překladu, limity, cena a dostupnost závisejí na zvoleném serveru.
- API klíč je uložen pouze dočasně v poli stránky; po zavření aplikace jej bude třeba zadat znovu.

Knihy překládejte pouze tehdy, pokud k tomu máte příslušná práva.
