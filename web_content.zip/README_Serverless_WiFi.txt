Hunters of the New World — Serverless Wi-Fi Multiplayer

This version removes the QR-code display and uses a shared room password instead.

SETUP
1. Open the HTML game on each device.
2. On the LAN Multiplayer screen, choose a Shared room password. Enter exactly the same password on the GM and every player device.
3. The password is saved locally on each device, so it stays the same the next time that device opens the game. It is not automatically transferred to other devices.
4. The GM creates an invitation and sends the generated text to the player.
5. The player pastes the invitation, creates a response, and sends that generated text back.
6. The GM pastes the response and accepts it.

IMPORTANT TECHNICAL LIMITATION
The shared room password remains the same, but the invitation and response text still have to be generated for each new WebRTC connection. WebRTC needs a fresh offer/answer handshake for each connection; a fixed room password alone cannot establish the direct connection. No QR codes are used in this version.

NETWORK NOTES
- Devices must be on the same Wi-Fi network.
- Guest Wi-Fi or access-point/client isolation can prevent direct device-to-device connections.
- Keep both game pages open while connecting and playing.
- No game server, Node.js, Termux, STUN, or TURN server is used.
