# PS ROYAL Work Manager – Android Studio

Android Studio project wrapping the PS ROYAL Work Manager HTML app in a native WebView.

## Features
- Work, customer, products/services, billing, reports, settings
- Local app data via localStorage
- JSON backup/restore
- Native Google Sign-In + Google Drive backup/restore
- Drive backup file: `WorkBookManager-backup.json`

## Google Drive setup
1. In Google Cloud Console create a project.
2. Enable Google Drive API.
3. Create an Android OAuth client for package `com.psroyal.workmanager`.
4. Add your debug/release SHA-1 fingerprints.
5. Build/install the app and sign in with Google.

No Google password or client secret is stored in this app.

## Build
Open this folder in Android Studio, let Gradle sync, then Build > Build APK(s).
