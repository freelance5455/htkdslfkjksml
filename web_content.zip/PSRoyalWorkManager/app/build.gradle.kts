plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace = "com.psroyal.workmanager"; compileSdk = 35
    defaultConfig { applicationId = "com.psroyal.workmanager"; minSdk = 23; targetSdk = 35; versionCode = 1; versionName = "1.0" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.gms:play-services-auth:21.3.0")
    implementation("com.google.api-client:google-api-client-android:2.7.0")
    implementation("com.google.http-client:google-http-client-gson:1.45.0")
}
