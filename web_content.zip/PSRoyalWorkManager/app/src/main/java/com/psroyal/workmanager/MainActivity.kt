package com.psroyal.workmanager

import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.common.api.Scope
import com.google.android.gms.tasks.Task
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential
import com.google.api.client.http.javanet.NetHttpTransport
import com.google.api.client.json.gson.GsonFactory
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var account: GoogleSignInAccount? = null
    private val driveScope = "https://www.googleapis.com/auth/drive.file"
    private val signInCode = 7001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(DriveBridge(), "AndroidDrive")
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class DriveBridge {
        @JavascriptInterface fun connectDrive() {
            runOnUiThread {
                val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                    .requestEmail().requestScopes(Scope(driveScope)).build()
                startActivityForResult(GoogleSignIn.getClient(this@MainActivity, gso).signInIntent, signInCode)
            }
        }
        @JavascriptInterface fun isConnected(): Boolean = account != null
        @JavascriptInterface fun backup(json: String) {
            val acc = account ?: run { toast("पहले Google Drive Connect करें"); return }
            thread { try { val id = uploadBackup(acc, json); ui("window.androidDriveBackupResult(true,'Backup saved ✓')") } catch (e: Exception) { ui("window.androidDriveBackupResult(false,${JSONObject.quote(e.message ?: "Backup failed")})") } }
        }
        @JavascriptInterface fun restore() {
            val acc = account ?: run { toast("पहले Google Drive Connect करें"); return }
            thread { try { val json = downloadBackup(acc); ui("window.androidDriveRestoreResult(${JSONObject.quote(json)})") } catch (e: Exception) { ui("window.androidDriveRestoreResult('')"); toast(e.message ?: "Restore failed") } }
        }
        @JavascriptInterface fun disconnect() { account = null; ui("window.androidDriveDisconnected && window.androidDriveDisconnected()") }
    }

    private fun credential(acc: GoogleSignInAccount): GoogleAccountCredential =
        GoogleAccountCredential.usingOAuth2(this, listOf(driveScope)).also { it.selectedAccount = acc.account }

    private fun authHeader(acc: GoogleSignInAccount): String = "Bearer " + credential(acc).token

    private fun uploadBackup(acc: GoogleSignInAccount, json: String): String {
        val query = java.net.URLEncoder.encode("name='WorkBookManager-backup.json' and trashed=false", "UTF-8")
        val search = request("https://www.googleapis.com/drive/v3/files?q=$query&pageSize=1&fields=files(id,name,modifiedTime)", "GET", null, authHeader(acc))
        val files = JSONObject(search).optJSONArray("files")
        val existingId = if (files != null && files.length() > 0) files.getJSONObject(0).getString("id") else null
        val boundary = "----PSRoyal${UUID.randomUUID()}"
        val metadata = JSONObject().put("name", "WorkBookManager-backup.json").put("mimeType", "application/json").toString()
        val body = "--$boundary\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n$metadata\r\n--$boundary\r\nContent-Type: application/json\r\n\r\n$json\r\n--$boundary--"
        val url = if (existingId == null) "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart" else "https://www.googleapis.com/upload/drive/v3/files/$existingId?uploadType=multipart"
        val method = if (existingId == null) "POST" else "PATCH"
        val result = request(url, method, body.toByteArray(Charsets.UTF_8), authHeader(acc), "multipart/related; boundary=$boundary")
        return JSONObject(result).optString("id", existingId ?: "")
    }

    private fun downloadBackup(acc: GoogleSignInAccount): String {
        val query = java.net.URLEncoder.encode("name='WorkBookManager-backup.json' and trashed=false", "UTF-8")
        val search = request("https://www.googleapis.com/drive/v3/files?q=$query&pageSize=1&orderBy=modifiedTime desc&fields=files(id,name)", "GET", null, authHeader(acc))
        val files = JSONObject(search).optJSONArray("files") ?: throw Exception("Drive backup नहीं मिला")
        if (files.length() == 0) throw Exception("Drive में backup file नहीं मिली")
        val id = files.getJSONObject(0).getString("id")
        return request("https://www.googleapis.com/drive/v3/files/$id?alt=media", "GET", null, authHeader(acc))
    }

    private fun request(urlString: String, method: String, body: ByteArray?, auth: String, contentType: String = "application/json"): String {
        val c = URL(urlString).openConnection() as HttpURLConnection
        c.requestMethod = method; c.connectTimeout = 20000; c.readTimeout = 30000
        c.setRequestProperty("Authorization", auth); c.setRequestProperty("Accept", "application/json")
        if (body != null) { c.doOutput = true; c.setRequestProperty("Content-Type", contentType); c.outputStream.use { it.write(body) } }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val text = BufferedReader(InputStreamReader(stream)).use { it.readText() }
        if (code !in 200..299) throw Exception("Google Drive error $code: $text")
        return text
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != signInCode) return
        try {
            account = GoogleSignIn.getSignedInAccountFromIntent(data).getResult(ApiException::class.java)
            ui("window.androidDriveConnected && window.androidDriveConnected(${JSONObject.quote(account?.email ?: "Google account")})")
            toast("Google Drive connected ✓")
        } catch (e: ApiException) { toast("Google login failed: ${e.statusCode}") }
    }

    private fun ui(js: String) { runOnUiThread { web.evaluateJavascript(js, null) } }
    private fun toast(msg: String) { runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() } }
}
