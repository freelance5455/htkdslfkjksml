BOLO SERVICE - Cloudflare Pages package

1. Upload this folder to Cloudflare Pages as a static site.
2. The entry file is index.html.
3. Domain target: boloservice.online
4. WhatsApp booking number: +91 7860493175

IMPORTANT:
This source contains the existing browser/localStorage implementation. A real multi-device system (secure customer/technician accounts, shared bookings, admin-only service management, verified-email registration, assignment, status updates, and automatic WhatsApp Cloud API messages) requires a backend such as Supabase plus WhatsApp Cloud API credentials. Do not put service-role secrets or WhatsApp API secrets in index.html.
