# STUDY VERSE

Student study companion.

## Use

1. Open `index.html` in a browser.
2. Optional: add your own AI key under Settings if you want enhanced assistant answers.

## Notes

- Study data stays on the device where you use the app.
- For personal / educational use.
- Developed by Mehedi Atik.

## IHT Admission Quiz

Quiz Arena now includes a dedicated IHT Admission MCQ Bank with 320 practice questions across 8 subjects, subject-wise 40-question quizzes, and a full 320-question mock test. Answers and short explanations appear after each selection.


## Bengali IHT Admission MCQs
Added 315 additional Bengali practice MCQs across 7 subjects, with a full Bengali mock test and subject-wise quizzes. These are practice questions, not official or guaranteed exam questions.


## Additional Bengali IHT Practice and Revision Tests
Added 315 additional Bengali quiz entries across 7 subjects (built from 105 key facts with varied question wording), a full new Bengali mock test, and 5 revision model tests (matching the earlier set sizes) 45, 50, 60, 60, and 60 questions. Revision tests draw from the app's existing Bengali question bank and new practice bank. They are not verified official past-paper reproductions.


## Varsity Admission B-Unit (DU / RU / JU / GST)

- Added four university-specific practice panels in Quiz Arena: DU, RU, JU and GST.
- Each panel offers Bangla (45), English (40), GK (45), and a 130-question full practice test.
- The current build reuses a shared 130-question core bank across the four panels; the 520 total refers to university-specific practice entries, not 520 unique questions.
- These are practice questions based on recurring admission-question topics, not verified verbatim official past-paper reproductions. Reference links are provided in the app.

## National University Admission Section
- Added a dedicated National University (NU) section with three streams: Science, Humanities, and Commerce.
- Each stream includes a full mock test and subject-wise MCQ buttons.
- Stream question totals: Science 827, Humanities 644, Commerce 655.
- Includes a locally embedded NU crest-style SVG emblem at `assets/nu-logo.svg`.
- The general-knowledge bank is shared with Science and Commerce as an additional admission-preparation subject.


## Professional UI and reliability update

- Replaced the generic folder mark with a custom Study Verse SVG brand icon and browser favicon.
- Improved focus states, button feedback, card consistency, mobile bottom-navigation safe-area spacing, and reduced-motion support.
- Fixed date-only tracking to use the device's local calendar date instead of UTC, preventing study streak/progress day shifts in Bangladesh.
- Added a visible warning if browser storage is unavailable or full.
- Improved imported-data settings merging so missing optional settings retain safe defaults.
- Preserved the existing admission question banks, university logos, notes, cards, planner, progress, and AI assistant.
- The optional AI key is stored in browser local storage, not an encrypted vault; use it only on a trusted device.


## Official brand logo
The official transparent STUDY VERSE logo supplied by the owner is used for the desktop header, mobile header, and browser favicon (`assets/study-verse-official-logo.png`).
