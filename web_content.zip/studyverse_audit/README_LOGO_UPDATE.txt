Logo update (professional pass) — all university logos fixed:

DU (Dhaka University):
- Replaced with high-quality transparent PNG from 4K reference image.
- Black background removed via flood-fill, preserving all interior elements
  (gold shield, red flame, lotus, eye motif, Bengali text).
- 512x512, true alpha transparency.

NU (National University):
- Replaced with high-quality transparent PNG from reference image.
- White background removed via flood-fill, preserving interior white elements
  (open book, lotus, atom symbol, plant, colored quadrants).
- 512x512, true alpha transparency.

RU (Rajshahi University):
- Replaced with high-quality transparent PNG from user-provided reference.
- Circular book-and-sunburst emblem matching RU's official design.
- Checkerboard background removed, 512x512, true alpha transparency.

JU (Jahangirnagar University):
- Replaced with verified official Jahangirnagar University logo
  (জাহাঙ্গীরনগর বিশ্ববিদ্যালয় — green variant with three shapla motifs).
- Previous logo was incorrectly a Dhaka University blue-line drawing; now corrected.
- 512x512, transparent background.

GST (গুচ্ছ admission test):
- Replaced with user-provided GST app icon (black rounded square with
  university emblem collage and orange "GST" text).
- White background removed via flood-fill; 512x512, true alpha transparency.

IHT (Institute of Health Technology):
- Existing caduceus emblem cleaned up: alpha channel refined,
  stray artifacts removed, upscaled to 512x512.

All logos are now uniform 512x512 transparent PNGs that render crisply
in the white rounded card containers on both standard and retina displays.

Original Study Verse branding (study-verse-official-logo.png, study-verse-logo.svg),
quiz banks, and app functionality are preserved.
