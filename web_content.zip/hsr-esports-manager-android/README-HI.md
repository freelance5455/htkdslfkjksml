# HSR ESPORTS Manager — Android project

## Important: current status
Yeh Android-compatible Capacitor project starter hai. Is ZIP se APK automatically ready nahi hota. APK build karne se pehle Firebase project/configuration aur Android build workflow complete karna hoga. Is version mein login, scrim records, QR gallery picker/upload, payment submission aur staff application ka initial Firebase flow diya hai. Owner approval UI, granular permissions, salary ledger, ownership transfer aur full audit reports abhi additional development hain. Isse real payments ya production business records ke liye bina testing deploy na karein.

## 1. Firebase setup (phone browser se)
1. `https://console.firebase.google.com` kholen aur Google account se sign in karein.
2. New project banayein: `hsr-esports-manager`.
3. Authentication → Sign-in method → Email/Password enable karein.
4. Firestore Database create karein (production mode).
5. Storage enable karein.
6. Project settings → Your apps → Web app add karein.
7. Firebase web config copy karke `www/app.js` ke `firebaseConfig` placeholders mein paste karein.
8. Firestore Rules tab mein `firestore.rules` ka content paste/publish karein.
9. Storage Rules tab mein `storage.rules` ka content paste/publish karein.

## 2. Owner account ko securely bootstrap karna
- Owner Gmail ko chat ya source code mein hard-code na karein.
- Pehle Owner ke liye Firebase Authentication account create karein.
- Firestore `users` collection mein us UID ka document manually Firebase Console se banayein:
  `{ "email": "OWNER_EMAIL", "role": "owner", "status": "approved" }`
- Is initial setup ko sirf trusted project owner kare. Kisi user ko client app se Owner banane ka option nahi hai.
- Staff accounts ko manually review/approve karne ke liye Owner workflow abhi add karna baaki hai.

## 3. APK build — Android phone friendly route
Is project mein GitHub Actions workflow diya gaya hai:
1. GitHub par new **private** repository banayein.
2. ZIP extract karke project ke saare files repository mein upload karein.
3. GitHub repository → Actions tab → `Build Android APK` workflow run karein.
4. Build complete hone par workflow run ke Artifacts section se `hsr-esports-debug-apk` download karein.
5. ZIP artifact extract karein; `app-debug.apk` Android phone par install karein.
6. Install se pehle Android Settings mein browser/files app ke liye “Install unknown apps” permission ki zarurat ho sakti hai. Sirf apne trusted build ka APK install karein.

## 4. Local build (computer required)
```bash
npm install
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```
APK path: `android/app/build/outputs/apk/debug/app-debug.apk`

## 5. Gallery QR upload
QR & Payments tab → Choose QR image → Android gallery/photo picker se image choose karein → Upload QR. Android WebView/Capacitor browser file picker ko trigger karega. Firebase Storage config/rules required hain.

## 6. Security notes
- UPI payment app ke andar process nahi hota. QR sirf payment details dikhata hai; payment verification Owner ko independently karni hogi.
- UTR/screenshot ko payment proof ka automatic substitute na maanein.
- Firestore rules ko test karein; real production ke liye server-side validation/Cloud Functions, audit logs, role-specific permissions, backups, rate limits, and admin approval screens required hain.
- Firebase config mein API key app identifier hoti hai, secret password nahi; actual security Firestore/Storage Rules se enforce hoti hai.
