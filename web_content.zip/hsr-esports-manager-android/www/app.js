import { initializeApp } from "https://www.gstatic.com/firebasejs/11.10.0/firebase-app.js";
import { getAuth, onAuthStateChanged, signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut } from "https://www.gstatic.com/firebasejs/11.10.0/firebase-auth.js";
import { getFirestore, collection, addDoc, getDocs, query, orderBy, serverTimestamp, doc, getDoc, setDoc } from "https://www.gstatic.com/firebasejs/11.10.0/firebase-firestore.js";
import { getStorage, ref, uploadBytes, getDownloadURL } from "https://www.gstatic.com/firebasejs/11.10.0/firebase-storage.js";

// Paste your Firebase web-app configuration here after creating a Firebase project.
const firebaseConfig = {
  apiKey: "PASTE_FIREBASE_API_KEY",
  authDomain: "PASTE_PROJECT_ID.firebaseapp.com",
  projectId: "PASTE_PROJECT_ID",
  storageBucket: "PASTE_PROJECT_ID.firebasestorage.app",
  messagingSenderId: "PASTE_SENDER_ID",
  appId: "PASTE_APP_ID"
};
const configured = !Object.values(firebaseConfig).some(v => String(v).startsWith("PASTE_"));
let auth, db, storage, currentUser=null, currentRole="unapproved";
const $ = id => document.getElementById(id);
const rupees = n => "₹" + Number(n||0).toLocaleString("en-IN");
function message(id, value){ $(id).textContent=value; }
if(configured){
  const app=initializeApp(firebaseConfig); auth=getAuth(app); db=getFirestore(app); storage=getStorage(app);
  onAuthStateChanged(auth, async user=>{
    currentUser=user;
    $("setup").classList.toggle("hidden",!!user); $("app").classList.toggle("hidden",!user); $("logout").classList.toggle("hidden",!user);
    if(user) await loadProfile();
  });
} else {
  message("authmsg","Firebase setup pending. Complete the setup guide, then add your Firebase web config in www/app.js.");
}
$("login").onclick=async()=>{if(!configured)return message("authmsg","Firebase setup pending.");try{await signInWithEmailAndPassword(auth,$("email").value,$("password").value)}catch(e){message("authmsg",e.message)}};
$("signup").onclick=async()=>{if(!configured)return message("authmsg","Firebase setup pending.");try{const credential=await createUserWithEmailAndPassword(auth,$("email").value,$("password").value);await setDoc(doc(db,"users",credential.user.uid),{email:credential.user.email,role:"unapproved",status:"pending",createdAt:serverTimestamp()});message("authmsg","Account created. Owner must approve and assign a role before access.")}catch(e){message("authmsg",e.message)}};
$("logout").onclick=()=>signOut(auth);
async function loadProfile(){
  const snap=await getDoc(doc(db,"users",currentUser.uid));
  currentRole=snap.exists()?snap.data().role:"unapproved";
  $("hello").textContent=currentUser.email||"Member"; $("role").textContent=currentRole;
  $("ownerTools").classList.toggle("hidden",currentRole!=="owner");
  await loadScrims();
}
function calc(){const v=Number($("slots").value||0)*Number($("entry").value||0);$("calc").textContent=rupees(v)}
["slots","entry"].forEach(id=>$(id).addEventListener("input",calc));
$("addScrim").onclick=async()=>{
 if(!configured||!currentUser)return;
 const slots=Number($("slots").value||0), entry=Number($("entry").value||0), prize=Number($("prize").value||0), other=Number($("other").value||0), share=Number($("share").value||0);
 const collectionAmount=slots*entry, profit=collectionAmount-prize-other;
 if(! $("scrimName").value.trim())return message("scrimmsg","Scrim name is required.");
 if([slots,entry,prize,other,share].some(x=>x<0)||share>Math.max(0,profit))return message("scrimmsg","Please check amounts and HSR share.");
 try{await addDoc(collection(db,"scrims"),{name:$("scrimName").value.trim(),slots,entry,collection:collectionAmount,prize,expenses:other,profit,hsrShare:share,createdBy:currentUser.uid,createdAt:serverTimestamp()});message("scrimmsg","Saved.");await loadScrims()}catch(e){message("scrimmsg",e.message)}
};
async function loadScrims(){
 try{const q=query(collection(db,"scrims"),orderBy("createdAt","desc"));const snap=await getDocs(q);let total=0,expenses=0,profit=0,pending=0;const rows=[];
 snap.forEach(d=>{const x=d.data();total+=x.collection||0;expenses+=(x.prize||0)+(x.expenses||0);profit+=x.profit||0;pending+=x.hsrShare||0;rows.push(`<div class="item"><b>${escapeHtml(x.name||"Scrim")}</b><br><small>${x.slots||0} slots · ${rupees(x.collection)} collection · ${rupees(x.profit)} profit</small></div>`)});
 $("collection").textContent=rupees(total);$("expenses").textContent=rupees(expenses);$("profit").textContent=rupees(profit);$("pending").textContent=rupees(pending);$("scrimList").innerHTML=rows.join("")||'<p class="muted">No scrims yet.</p>';
 }catch(e){$("scrimList").textContent=e.message}
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
let qrFile=null,payFile=null;
$("qrFile").onchange=e=>{qrFile=e.target.files[0];if(qrFile){$("qrPreview").src=URL.createObjectURL(qrFile);$("qrPreview").classList.remove("hidden")}};
$("payFile").onchange=e=>payFile=e.target.files[0];
async function upload(file,path){const r=ref(storage,path);await uploadBytes(r,file);return await getDownloadURL(r)}
$("uploadQr").onclick=async()=>{
 if(!configured||!currentUser)return;
 if(!qrFile)return message("qrmsg","Select QR image from gallery first.");
 if($("qrType").value==="official"&&currentRole!=="owner")return message("qrmsg","Only Owner can upload official HSR QR.");
 try{const url=await upload(qrFile,`qr/${currentUser.uid}/${Date.now()}-${qrFile.name}`);await addDoc(collection(db,"qrSubmissions"),{uid:currentUser.uid,type:$("qrType").value,url,status:"pending",createdAt:serverTimestamp()});message("qrmsg","QR uploaded and sent for review.");}catch(e){message("qrmsg",e.message)}
};
$("submitPayment").onclick=async()=>{
 if(!configured||!currentUser)return;
 const amount=Number($("payAmount").value||0),utr=$("utr").value.trim();if(amount<=0||!utr)return message("qrmsg","Enter amount and UTR.");
 try{let proofUrl="";if(payFile)proofUrl=await upload(payFile,`paymentProof/${currentUser.uid}/${Date.now()}-${payFile.name}`);await addDoc(collection(db,"payments"),{uid:currentUser.uid,amount,utr,proofUrl,status:"pending_verification",createdAt:serverTimestamp()});message("qrmsg","Payment submitted. Owner must manually verify it.");}catch(e){message("qrmsg",e.message)}
};
$("apply").onclick=async()=>{
 if(!configured||!currentUser)return message("appmsg","Create an account or login first.");
 try{await addDoc(collection(db,"applications"),{uid:currentUser.uid,name:$("appName").value.trim(),contact:$("appContact").value.trim(),requestedRole:$("appRole").value,experience:$("appExperience").value.trim(),status:"pending",createdAt:serverTimestamp()});message("appmsg","Application submitted for Owner review.");}catch(e){message("appmsg",e.message)}
};
document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>{document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x===b));document.querySelectorAll(".tabpanel").forEach(x=>x.classList.toggle("hidden",x.id!=="tab-"+b.dataset.tab))});
