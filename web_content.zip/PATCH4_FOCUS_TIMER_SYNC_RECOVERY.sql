-- Patch 4.6: recover server checkpoints after Android suspends WebView timers.
-- Long heartbeat gaps receive no credit. Move the server checkpoint forward so
-- subsequent normal pulses can be recorded; timer completion remains bounded
-- by the server-stored planned duration.
create or replace function public.competition_shadow_timer_session(
  p_action text,
  p_source text,
  p_session_id text,
  p_planned_seconds integer
)
returns boolean
language plpgsql
security definer
set search_path to ''
as $function$
declare
  v_uid uuid := (select auth.uid());
  v_now timestamptz := clock_timestamp();
  v_session private.competition_time_sessions%rowtype;
  v_existing_seconds bigint;
  v_remaining_seconds integer;
  v_credit_limit integer;
  v_max_seconds integer;
  v_delta interval;
  v_end timestamptz;
begin
  if v_uid is null then raise exception 'Authentication required'; end if;
  if p_source is null or p_source not in ('home','focus') then raise exception 'Invalid timer source'; end if;
  v_max_seconds := case when p_source='focus' then 28800 else 43200 end;
  if p_session_id is null or length(p_session_id) < 1 or length(p_session_id) > 160 then
    raise exception 'Invalid session id';
  end if;
  if p_planned_seconds is null or p_planned_seconds < 1 or p_planned_seconds > v_max_seconds then
    raise exception 'Timer duration is outside the allowed limit';
  end if;
  if p_action is null or p_action not in ('start','resume','pulse','pause','complete','abandon') then
    raise exception 'Invalid action';
  end if;

  if p_action='start' then
    insert into private.competition_time_sessions(
      user_id,source,client_session_id,started_at,last_heartbeat_at,planned_seconds
    ) values (v_uid,p_source,p_session_id,v_now,v_now,p_planned_seconds)
    on conflict(user_id,source,client_session_id) do nothing;

    select * into v_session from private.competition_time_sessions
      where user_id=v_uid and source=p_source and client_session_id=p_session_id for update;
    if v_session.is_closed then raise exception 'Session is already closed'; end if;
    if v_session.planned_seconds is null then
      update private.competition_time_sessions set
        planned_seconds=p_planned_seconds,started_at=v_now,last_heartbeat_at=v_now,is_paused=false
      where user_id=v_uid and source=p_source and client_session_id=p_session_id;
    elsif v_session.planned_seconds<>p_planned_seconds then
      raise exception 'Timer length does not match the server session';
    end if;
    return true;
  end if;

  select * into v_session from private.competition_time_sessions
    where user_id=v_uid and source=p_source and client_session_id=p_session_id for update;
  if not found then raise exception 'Session not found'; end if;
  if v_session.is_closed then return true; end if;
  if v_session.planned_seconds is null then raise exception 'Timer was not initialized'; end if;
  if v_session.planned_seconds<>p_planned_seconds then
    raise exception 'Timer length does not match the server session';
  end if;

  if p_action='resume' and v_session.is_paused then
    update private.competition_time_sessions set is_paused=false,last_heartbeat_at=v_now
    where user_id=v_uid and source=p_source and client_session_id=p_session_id;
    return true;
  end if;
  if v_session.is_paused then
    if p_action in ('complete','abandon') then
      update private.competition_time_sessions set is_closed=true,ended_at=v_now
      where user_id=v_uid and source=p_source and client_session_id=p_session_id;
    end if;
    return true;
  end if;

  v_delta := v_now-v_session.last_heartbeat_at;

  -- Android may suspend WebView JavaScript for minutes. Never credit that
  -- unobserved gap from a pulse, but re-anchor the checkpoint so later pulses
  -- are not discarded forever. A server-timed complete can still close the
  -- session and credit only up to its server-stored planned_seconds limit.
  if p_action='pulse' and v_delta>interval '75 seconds' then
    update private.competition_time_sessions set
      last_heartbeat_at=v_now,
      heartbeat_sequence=heartbeat_sequence+1
    where user_id=v_uid and source=p_source and client_session_id=p_session_id;
    return true;
  end if;

  select coalesce(sum(extract(epoch from (i.ended_at-i.started_at)))::bigint,0)
    into v_existing_seconds
  from private.competition_time_intervals i
  where i.user_id=v_uid and i.source=p_source and i.client_session_id=p_session_id;

  v_remaining_seconds := greatest(0,v_session.planned_seconds-v_existing_seconds)::integer;
  if p_action in ('pulse','abandon') then
    v_credit_limit := case when v_delta<=interval '75 seconds'
      then least(v_remaining_seconds,75) else 0 end;
  else
    v_credit_limit := v_remaining_seconds;
  end if;

  if v_credit_limit>0 and v_delta>interval '0 seconds' then
    v_end := least(v_now,v_session.last_heartbeat_at+make_interval(secs=>v_credit_limit));
    if v_end>v_session.last_heartbeat_at then
      insert into private.competition_time_intervals(
        user_id,source,client_session_id,sequence,started_at,ended_at
      ) values (
        v_uid,p_source,p_session_id,v_session.heartbeat_sequence+1,
        v_session.last_heartbeat_at,v_end
      ) on conflict(user_id,source,client_session_id,sequence) do nothing;
    end if;
  end if;

  update private.competition_time_sessions set
    last_heartbeat_at=v_now,
    heartbeat_sequence=heartbeat_sequence+1,
    is_paused=(p_action='pause'),
    is_closed=(p_action in ('complete','abandon')),
    ended_at=case when p_action in ('complete','abandon') then v_now else ended_at end
  where user_id=v_uid and source=p_source and client_session_id=p_session_id;
  return true;
end;
$function$;

revoke all on function public.competition_shadow_timer_session(text,text,text,integer) from public,anon;
grant execute on function public.competition_shadow_timer_session(text,text,text,integer) to authenticated;
