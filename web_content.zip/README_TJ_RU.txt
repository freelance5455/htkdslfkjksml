ATLAS ONE — Android project (WebView)

Муҳим / Важно:
Ин архив ҳоло APK-и тайёр нест. Дар муҳити сохтани файл Android SDK ва пайвасти интернет барои гирифтани асбобҳои Android мавҷуд набуд, бинобар ин APK-ро дар ин ҷо компилятсия карда натавонистам.

Как собрать APK на компьютере:
1. Установите Android Studio с официального сайта Android Developers.
2. Распакуйте архив.
3. Откройте папку AtlasOne в Android Studio как проект.
4. Дождитесь синхронизации Gradle и установки Android SDK Platform 35.
5. Выберите Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK обычно появится в app/build/outputs/apk/debug/app-debug.apk.

Приложение открывает встроенный файл app/src/main/assets/index.html. Для онлайн-данных и внешних текстур потребуется интернет. Локальный HTML включён в архив.
