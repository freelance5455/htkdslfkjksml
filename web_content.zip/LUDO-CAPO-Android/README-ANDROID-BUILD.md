# LUDO CAPO — Android APK & AAB Build Guide

## Project Identification
- **App Name**: `LUDO CAPO`
- **Package ID**: `com.ludocapo.game`
- **Orientation**: Portrait (`android:screenOrientation="portrait"`)
- **Features Included**:
  - Immersive Full-Screen Mode (`WindowInsetsController` / `SYSTEM_UI_FLAG_IMMERSIVE_STICKY`)
  - Hardware-Accelerated HTML5 Canvas + Web Audio API + Haptic Vibration (`android.permission.VIBRATE`)
  - Persistent `localStorage` (`setDomStorageEnabled(true)`)
  - Native Android Back-Button handling (`OnBackPressedCallback`)
  - Custom App Icons (`mipmap-*`) and Portrait Splash Screen (`drawable/splash_logo.png`)

## Building `LUDO-CAPO.apk` and `LUDO-CAPO-release.aab`

### Prerequisite
Ensure Android Studio (Hedgehog / Iguana or newer) or the Android SDK Command-Line Tools with JDK 17 are installed on your machine, and set `ANDROID_HOME` to your SDK path.

### 1. Build Installable APK (`LUDO-CAPO.apk`)
Run from the project root directory:
```bash
gradle assembleDebug
# Or for a signed release APK:
gradle assembleRelease
```
The compiled APK is output to:
`app/build/outputs/apk/debug/LUDO-CAPO.apk` (or `app/build/outputs/apk/release/LUDO-CAPO.apk`)

### 2. Build Google Play App Bundle (`LUDO-CAPO-release.aab`)
Run from the project root directory:
```bash
gradle bundleRelease
cp app/build/outputs/bundle/release/app-release.aab ./LUDO-CAPO-release.aab
```

### 3. Install & Verify on Connected Android Device
```bash
adb install -r app/build/outputs/apk/debug/LUDO-CAPO.apk
adb shell am start -n com.ludocapo.game.debug/com.ludocapo.game.MainActivity
```
