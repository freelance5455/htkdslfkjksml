import React from "react";
import { createRoot } from "react-dom/client";
import { flushSync } from "react-dom";
import { GlowBorderCard } from "./components/ui/glow-border-card";
import { RadialGlowButton } from "./components/ui/radial-glow-button";
import "./index.css";
import "./dashboard.css";

function openTab(panelId: string) {
  document.querySelector<HTMLButtonElement>(`#tabs [data-panel="${panelId}"]`)?.click();
}

function Dashboard() {
  return (
    <main className="sd-dashboard">
      <section className="sd-welcome" aria-labelledby="sdWelcomeTitle">
        <div className="sd-welcome-copy">
          <div className="sd-kicker"><span className="sd-kicker-mark">S</span> CBSE CLASS 12 · COMMERCE</div>
          <h2 id="sdWelcomeTitle">Make today count.</h2>
          <p>Build a steady study routine, practise by subject and keep your progress in view.</p>
          <div className="sd-welcome-actions">
            <button className="sd-primary-action" type="button" onClick={() => openTab("hubPanel")}>Open study planner <span aria-hidden="true">↗</span></button>
            <button className="sd-secondary-action" type="button" onClick={() => openTab("progressPanel")}>View progress</button>
          </div>
        </div>
        <div className="sd-welcome-art" aria-hidden="true"><div className="sd-art-orbit sd-orbit-one"/><div className="sd-art-orbit sd-orbit-two"/><div className="sd-art-book">✦</div><span className="sd-art-spark sd-spark-one">✳</span><span className="sd-art-spark sd-spark-two">✧</span></div>
      </section>

      <section className="sd-timer-section" aria-labelledby="sdTimerHeading">
        <div className="sd-section-heading"><div><div className="sd-section-overline">FOCUS MODE</div><h2 id="sdTimerHeading">Your study timer</h2></div><span className="sd-live-tag"><span/> SESSION TRACKING</span></div>
        <GlowBorderCard className="sd-timer-glow" width="100%" height="auto" aspectRatio="unset" borderRadius="26px" borderWidth="1.15em" blurAmount="1.1em" inset="-0.35em" animationDuration={7} gradientColors={["#2F716C", "#54857E", "#CB806B", "#D1B06A", "#2F716C"]} colorPreset="custom">
          <div className="sd-timer-content">
            <div className="sd-timer-main">
              <label className="sd-field-label" htmlFor="homeTimerLabel">What are you studying?</label>
              <input id="homeTimerLabel" type="text" maxLength={48} defaultValue="Study session" aria-label="Timer activity" />
              <div className="sd-clock-wrap"><span className="sd-clock-icon" aria-hidden="true">◷</span><div id="mockClock" className="sd-clock" role="timer" aria-live="off">00:30:00</div></div>
              <div className="sd-timer-controls">
                <RadialGlowButton id="homeTimerStart" className="sd-timer-start">Start timer</RadialGlowButton>
                <button id="homeTimerPause" className="sd-timer-secondary" type="button">Pause</button>
                <button id="homeTimerReset" className="sd-timer-reset" type="button" aria-label="Reset timer">Reset</button>
              </div>
            </div>
            <aside className="sd-timer-side">
              <div className="sd-timer-side-icon" aria-hidden="true">✦</div>
              <h3>A little focus goes a long way.</h3>
              <p>Choose a session length. Your study time is tracked with the rest of ScoreDeck.</p>
              <label className="sd-duration-label" htmlFor="homeTimerMinutes">Session length</label>
              <div className="sd-duration-input"><input id="homeTimerMinutes" type="number" min={1} max={720} defaultValue={30} aria-label="Timer minutes"/><span>minutes</span></div>
              <span className="sd-timer-note">The Sample Paper itself has no separate timer.</span>
            </aside>
          </div>
        </GlowBorderCard>
      </section>

      <div className="sd-dynamic-stack"><div id="practiceResumeCard"/><div id="hubHome"/></div>

      <section className="sd-progress-section" aria-label="Practice progress">
        <div className="sd-section-heading"><div><div className="sd-section-overline">YOUR WORKSPACE</div><h2>Progress at a glance</h2></div><button className="sd-text-link" type="button" onClick={() => openTab("progressPanel")}>All progress <span aria-hidden="true">→</span></button></div>
        <div className="sd-metrics-grid stats home-stats">
          <article className="sd-metric-card stat"><div className="sd-metric-icon sd-icon-violet" aria-hidden="true">▦</div><div className="sd-metric-label label">Subjects</div><div className="sd-metric-value num">5</div><div className="sd-metric-foot">Core commerce subjects</div></article>
          <article className="sd-metric-card stat"><div className="sd-metric-icon sd-icon-blue" aria-hidden="true">✎</div><div className="sd-metric-label label">Questions loaded</div><div className="sd-metric-value num" id="qTotal">0</div><div className="sd-metric-foot">Ready for practice</div></article>
          <article className="sd-metric-card stat sd-metric-progress"><div className="sd-metric-icon sd-icon-green" aria-hidden="true">↗</div><div className="sd-metric-label label">Progress tracked</div><div className="sd-metric-value num" id="done">0%</div><div className="sd-progress-track progress"><div id="bar" className="bar"/></div><div className="sd-metric-foot">Your saved practice progress</div></article>
          <article className="sd-metric-card stat"><div className="sd-metric-icon sd-icon-amber" aria-hidden="true">◎</div><div className="sd-metric-label label">Practice model</div><div className="sd-metric-value num">15+</div><div className="sd-metric-foot">Questions per chapter / section</div></article>
        </div>
      </section>

      <section className="sd-subject-section" aria-labelledby="sdSubjectsHeading">
        <div className="sd-section-heading"><div><div className="sd-section-overline">PICK UP WHERE YOU WANT</div><h2 id="sdSubjectsHeading">Choose a subject</h2></div><span className="sd-section-note">Practice and Blueprint tools</span></div>
        <div className="subject-grid" id="subjectGrid"/>
      </section>

      <section className="sd-tools-grid" aria-label="Study tools">
        <article className="sd-tool-card sd-mastery-card"><div className="sd-tool-icon" aria-hidden="true">✧</div><div className="sd-tool-copy"><div className="sd-section-overline">KEEP BUILDING</div><h3>Progress &amp; Mastery</h3><div id="masteryHomeSummary" className="small">Practice records, mistake recovery and Sample Paper results.</div></div><button className="sd-tool-button" type="button" onClick={() => openTab("progressPanel")}>View progress <span aria-hidden="true">→</span></button></article>
        <details className="sd-diagnostics"><summary><span><b>Developer diagnostics</b><small>Question bank quality validator</small></span><span aria-hidden="true">＋</span></summary><div className="sd-diagnostic-note">Internal validation for question-bank integrity and coverage.</div><div id="validationSummary" className="devbox"/></details>
      </section>

      <section className="sd-score-section" aria-labelledby="sdScoreHeading">
        <div className="sd-score-heading"><div className="sd-tool-icon" aria-hidden="true">∑</div><div><div className="sd-section-overline">PLAN YOUR GOAL</div><h2 id="sdScoreHeading">Score calculator</h2><p>Enter your expected marks to see your total.</p></div></div>
        <div className="sd-score-inputs">
          <label>English<input id="scoreEnglish" type="number" min="0" max="80" placeholder="0–80"/></label>
          <label>Accountancy<input id="scoreAccounts" type="number" min="0" max="80" placeholder="0–80"/></label>
          <label>Business Studies<input id="scoreBST" type="number" min="0" max="80" placeholder="0–80"/></label>
          <label>Economics<input id="scoreEco" type="number" min="0" max="80" placeholder="0–80"/></label>
          <label>Applied Maths<input id="scoreMaths" type="number" min="0" max="80" placeholder="0–80"/></label>
        </div>
        <div id="scoreResult" className="sd-score-result">Total: 0 / 400 • 0%</div>
      </section>
    </main>
  );
}

const mount = document.getElementById("scoreDeckDashboardRoot");
if (mount) {
  flushSync(() => createRoot(mount).render(<Dashboard />));
}
