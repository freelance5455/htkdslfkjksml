# ScoreDeck dashboard UI

VengeanceUI registry components are installed under src/components/ui and adapted into ScoreDeck's existing static HTML/CSS dashboard. The Home page uses the Glow Border Card treatment for the focus timer and the Radial Glow Button styling for its existing timer action. The page stays self-contained for local-file and APK WebView use; its timer, practice, storage and Supabase behavior remains owned by the existing ScoreDeck scripts.

The shared teal, terracotta and brass theme is defined in index.html and applies to the existing Practice, Sample Papers, Results/Review, Progress and Competition panels.

The Vite source in this folder is retained for future component work. The APK source ZIP needs index.html, app.js, and paper_images; it does not need this build folder or node_modules.
