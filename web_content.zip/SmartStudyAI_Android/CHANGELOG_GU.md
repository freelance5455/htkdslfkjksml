# આવૃત્તિ 2.2 માં સુધારા
- Dark Neon Navy/Cyan/Purple ડિઝાઇન અને ✦ icon જાળવ્યા.
- Quiz માં દરેક અધ્યાય માટે 25 પ્રશ્નોનું level split યથાવત્.
- પહેલાં ન પૂછાયેલા પ્રશ્નોને પ્રાથમિકતા આપતું rotation ઉમેર્યું.
- Android WebView માં JSON file picker સપોર્ટ ઉમેર્યો.
- Android launcher icon અને ગુજરાતી build માર્ગદર્શિકા ઉમેર્યાં.
