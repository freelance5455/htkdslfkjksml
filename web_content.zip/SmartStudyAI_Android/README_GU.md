# Smart Study AI – Android Studio Source (v2.2)

## ડિઝાઇન
- પહેલાની Dark Neon ડિઝાઇન જાળવેલી: Navy Blue + Cyan + Purple.
- એ જ glowing ✦ ઓળખ સાથે Android launcher icon ઉમેરેલું.
- ધોરણ 9 ગુજરાતી માધ્યમ માટે mobile-first interface.

## ફીચર્સ
- Notes: શીર્ષક અને વિગત સાચવો.
- Homework: due date, બાકી/પૂર્ણ સ્થિતિ અને delete.
- Class Work: ક્લાસમાં કરાવેલી નોંધો સાચવો.
- Chapter Quiz: દરેક પ્રયાસમાં 25 પ્રશ્નો — 10 સરળ, 10 મધ્યમ, 5 અઘરા.
- પ્રશ્નો અને વિકલ્પો shuffle થાય છે. અગાઉ પૂછાયેલા પ્રશ્નોને ટાળીને બાકી નવા પ્રશ્નો પહેલા લેવાય છે; બેંકના બધા પ્રશ્નો વપરાઈ જાય પછી જ ચક્ર ફરી શરૂ થાય છે.
- Automatic Report Card: કુલ ગુણ, ટકા, તારીખ અને લેવલ પ્રમાણે સ્કોર.
- Question bank JSON import/export અને report export.
- Offline-first: Notes, homework, classwork, quiz bank અને reports આ ડિવાઇસમાં જ રહે છે.

## Android Studio માં ચલાવવું
1. ZIP extract કરો.
2. `SmartStudyAI_Android` ફોલ્ડર Android Studio માં Open કરો.
3. Gradle Sync કરો (JDK 17 જરૂરી; Android Gradle Plugin 8.7.3).
4. Build > Build Bundle(s) / APK(s) > Build APK(s).

## દરેક અધ્યાય માટે પ્રશ્નબેંક
ક્વિઝ શરૂ કરવા માટે તે અધ્યાયમાં ઓછામાં ઓછા 10 સરળ, 10 મધ્યમ અને 5 અઘરા પ્રશ્નો હોવા જોઈએ. પ્રશ્નબેંક મેનેજરમાં પ્રશ્નો ઉમેરો અથવા `question_bank_template.json` ને ભરીને JSON Import કરો.

JSON format:
```json
{
  "0": [
    {"q":"પ્રશ્ન લખો","opts":["વિકલ્પ A","વિકલ્પ B","વિકલ્પ C","વિકલ્પ D"],"level":"સરળ","correct":0}
  ]
}
```
- `0` એટલે અધ્યાય 1, `1` એટલે અધ્યાય 2 વગેરે.
- `level`: `સરળ`, `મધ્યમ`, અથવા `અઘરા`.
- `correct`: સાચા વિકલ્પનો index 0 થી 3.
- અલગ પ્રશ્નો ઉમેરશો તો નવી Quiz માં પ્રશ્નો ફરી વપરાય તે પહેલાં અન્ય પ્રશ્નો પસંદ થશે. જો બેંકમાં બરાબર 25 પ્રશ્નો જ હશે તો પ્રશ્નો એ જ રહેશે, પરંતુ ક્રમ અને વિકલ્પો બદલાશે.

## મહત્વની નોંધ
આ source project છે, તૈયાર APK નથી. તેમાં textbook-verified બધા 12 અધ્યાયોના 25-25 તૈયાર પ્રશ્નો સામેલ નથી; ખોટા/બનાવટી પાઠ્યપુસ્તક પ્રશ્નો ન આવે તે માટે પોતાની અથવા શિક્ષક દ્વારા ચકાસેલી પ્રશ્નબેંક ઉમેરવાની સુવિધા છે. Firebase/backend અથવા online sync આ આવૃત્તિમાં નથી.
