# V — Full Cloud V3

הגרסה הזו היא גרסת HTML מוכנה לחיבור ל-Supabase.

## מה יש כאן
- התחברות והרשמה עם Supabase Auth
- פרופילים
- פיד "עבורך" ו"עוקב"
- העלאת סרטונים ל-Supabase Storage
- שמירת metadata במסד הנתונים
- לייקים
- תגובות
- Repost
- שמירה
- Follow
- חיפוש
- צ'אטים ושמירת הודעות
- Realtime בסיסי לצ'אטים
- פרופילים וגריד סרטונים
- עיצוב כהה ואנכי בסגנון V/TikTok

## חשוב
הקובץ לא יכול לדעת מה ה-Supabase שלך. בתוך index.html נמצאים:
YOUR_SUPABASE_URL
YOUR_SUPABASE_PUBLISHABLE_KEY

מותר לשים בקוד את ה-Publishable Key. אסור לשים בקוד Secret / service_role key.

## הגדרה
1. צור Project ב-Supabase.
2. ב-Storage צור Bucket בשם `videos` וסמן Public.
3. פתח SQL Editor והרץ את כל הקובץ `supabase_schema.sql`.
4. ב-Supabase קבל Project URL ו-Publishable Key.
5. ב-index.html החלף:
   YOUR_SUPABASE_URL
   YOUR_SUPABASE_PUBLISHABLE_KEY
6. פתח את index.html בדפדפן ובדוק הרשמה, העלאה וצ'אט.
7. רק אחרי שהכל עובד, עטוף את index.html ב-APK.

## סרטונים גדולים
הקוד משתמש כרגע ב-standard upload כדי לשמור על התקנה פשוטה. Supabase ממליצה על TUS/resumable uploads לסרטונים מעל 6MB. לשלב הבא אפשר להחליף את פונקציית ההעלאה ל-TUS עם progress מלא.

## מה עדיין דורש backend נוסף לגרסת Production
- Live אמיתי בקנה מידה גדול
- Push notifications
- מערכת moderation מלאה
- Admin server-side עם הרשאות
- אימות 2FA
- transcoding/HLS/CDN מתקדם
- חסימות ודיווחים מתקדמים
- privacy controls מלאים
- rate limiting ואנטי-ספאם

אל תכניס secret/service_role key ל-index.html.
