తెలంగాణ ప్లాట్స్ - Admin version

ఈ వెర్షన్‌లో:
- కొత్త వెంచర్ Add
- Venture Edit
- Venture Delete
- Photos add
- Phone/WhatsApp
- Approval/RERA details
- Search
- Verified status data field

ముఖ్యం: ఈ వెర్షన్ డేటాను అదే ఫోన్‌లో browser/app local storageలో ఉంచుతుంది. వేరే ఫోన్లలో ఆటోమేటిక్‌గా కనిపించదు. నిజమైన online admin panel కోసం database/server అవసరం.

APK కోసం మొత్తం folder/ZIP ను HTML-to-APK Builder వంటి converterలో upload చేయండి.
