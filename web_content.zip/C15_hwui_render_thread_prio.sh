#!/system/bin/sh
# C15_hwui_render_thread_prio — hwui render thread prio
# Boost HWUI RenderThread nice level via device_config — smoother scrolling under load.
MODULE_ID="C15_hwui_render_thread_prio"
. "$(dirname "$0")/../lib/core.sh"
vcg_init
apply() {
    vcg_apply_or_skip C15_ENABLED || return 0
    vcg_dc_put graphics render_thread_priority -8
        vcg_dc_put surface_flinger vsync_reactor_enabled true
}
revert() {
    vcg_dc_del graphics render_thread_priority
        vcg_dc_del surface_flinger vsync_reactor_enabled
}
case "${1:-apply}" in apply) apply ;; revert) revert ;; *) exit 1 ;; esac
