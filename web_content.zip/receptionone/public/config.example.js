// Copy to config.js and replace with your Supabase project values.
// The anon key is public; the service-role key must NEVER be placed here.
window.RECEPTIONONE_CONFIG = {
  SUPABASE_URL: "https://YOUR-PROJECT.supabase.co",
  SUPABASE_ANON_KEY: "YOUR_SUPABASE_ANON_KEY"
};
