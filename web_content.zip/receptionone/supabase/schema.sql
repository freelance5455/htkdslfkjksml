-- Run in Supabase SQL Editor. Enable RLS; server uses service role only after verifying the user's JWT.
create table if not exists public.billing_customers (
 user_id uuid primary key references auth.users(id) on delete cascade,
 stripe_customer_id text unique not null,
 created_at timestamptz default now()
);
create table if not exists public.subscriptions (
 user_id uuid primary key references auth.users(id) on delete cascade,
 stripe_customer_id text not null,
 stripe_subscription_id text unique not null,
 status text not null,
 plan text not null,
 current_period_end timestamptz,
 updated_at timestamptz default now()
);
create table if not exists public.business_settings (
 user_id uuid primary key references auth.users(id) on delete cascade,
 business_name text not null default '',
 phone text not null default '',
 business_hours text not null default '',
 voice text not null default 'female' check (voice in ('female','male')),
 greeting text not null default '',
 greeting_preset integer not null default 0,
 knowledge text not null default '',
 updated_at timestamptz default now()
);
alter table public.billing_customers enable row level security;
alter table public.subscriptions enable row level security;
alter table public.business_settings enable row level security;
-- No direct client write policies. The backend service role performs writes.
create policy "users read own billing" on public.subscriptions for select to authenticated using (auth.uid()=user_id);
create policy "users read own settings" on public.business_settings for select to authenticated using (auth.uid()=user_id);
