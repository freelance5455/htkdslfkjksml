# ReceptionOne — app starter

This package contains:
- Responsive mobile-first ReceptionOne dashboard/PWA shell with the supplied logo.
- Account sign-up/sign-in using Supabase Auth.
- A hard subscription gate: the dashboard is unavailable unless the server verifies a Stripe subscription in `active` or `trialing` status.
- Stripe Checkout subscription creation and Stripe Billing Portal.
- Server-side Stripe webhook synchronization.
- Receptionist setup: male/female voice preference, 10 ready-made greetings, custom greeting, business details, approved FAQ/knowledge text.
- Supabase SQL schema with row-level security.

## Important: what is and is not live
This is a deployable application foundation, not a finished live AI phone service. Real incoming calls, conversational AI audio, actual voice rendering, SMS delivery, calendar booking, and production call/lead records still require telephony/voice/SMS/calendar providers and credentials. Do not advertise live answering until those integrations are implemented and tested. The male/female selection is a saved preference until a voice provider is connected.

## Requirements
- Node.js 20+
- Supabase project
- Stripe account with four recurring monthly prices (Solo $19.99, Growth $29.99, Team $59.99, Business $99.99)
- HTTPS hosting (Render, Railway, Fly.io, or another Node host)

## Setup
1. Create a Supabase project. In Authentication settings, enable email/password sign-in and set your site URL/redirect URLs.
2. Run `supabase/schema.sql` in Supabase SQL Editor.
3. In Stripe, create four recurring monthly prices: Solo $19.99, Growth $29.99, Team $59.99, Business $99.99. Copy each `price_...` ID into the matching environment variable.
4. Copy `.env.example` to `.env` and fill in values. Never expose the Supabase service role key or Stripe secret key in browser code.
5. Install dependencies with `npm install`.
6. Start locally with `npm start`.
7. In Stripe Developers → Webhooks, add `https://YOUR_HOST/api/stripe/webhook` and subscribe to:
   - `checkout.session.completed`
   - `customer.subscription.updated`
   - `customer.subscription.deleted`
   Put the signing secret in `STRIPE_WEBHOOK_SECRET`.
8. Configure Supabase Auth's allowed redirect URLs for your deployed domain.

## Payment lock behavior
- Signup alone does not unlock the dashboard.
- Checkout is created by the server with a specific Stripe price.
- The Stripe webhook writes subscription status to Supabase.
- Every protected business settings route checks the signed-in user and active subscription on the server.
- Cancelled, unpaid, past-due, incomplete, or deleted subscriptions do not pass the gate. Stripe status is rechecked by webhook; configure retries and billing emails in Stripe.
- Never add a client-side "isPaid" override.

## Configuration
`public/config.js` is intentionally not included with secrets. Create it from `public/config.example.js` and set the Supabase project URL and anon key. The anon key is designed for browser use when RLS is correctly configured.

## Pricing
| Plan | Monthly price | AI minutes | Phone lines | Team members |\n|---|---:|---:|---:|---:|\n| Solo | $19.99 | 150 | 1 | 1 |\n| Growth | $29.99 | 400 | 2 | 3 |\n| Team | $59.99 | 900 | 5 | 10 |\n| Business | $99.99 | 1,400 | 10 | 15 |\n\nConfigure four separate recurring Stripe Price IDs. Verify actual voice-provider costs, included minutes, overage rules, and fair-use terms before selling these limits.

## Run
`npm install && npm start`

## Before launch
- Add rate limiting, request validation, CSRF/origin controls where applicable, structured audit logs, error monitoring, backups, and tests.
- Verify webhook signatures and idempotency; persist Stripe event IDs to prevent duplicate processing.
- Add a secure phone provider and real-time AI voice integration.
- Add phone-number ownership verification, business-specific routing, call transfer, usage metering, SMS consent/STOP handling, calendar authorization, and tenant-isolation tests.
- Add Terms, Privacy Policy, cancellation/refund policy, support contact, and legal review for AI disclosure and call recording laws.
- Complete security review and real-device testing before accepting customers.
