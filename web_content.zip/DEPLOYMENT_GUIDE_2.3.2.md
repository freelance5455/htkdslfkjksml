# ANONYMOUX STUDIO 2.3.2 — Deployment & Installation

## Release target

**ANONYMOUX STUDIO 2.3.2 — Creator Dashboard & Resource Centre** is an additive extension of the supplied 2.3.1 production source. Deploy it over the existing application. Do not install it as a new empty application and do not reset or replace the production database.

## 1. Back up first

Before uploading any files:

1. Export/backup the live SQLite database (`storage/workspace.sqlite`) or make a full MySQL database backup.
2. Download the complete existing `storage/` directory, including platform inputs/outputs, references, voice audio and private configuration files held there.
3. Save the current server-side `config.local.php` and any hosting environment variables / API keys securely outside the public web root.
4. Keep a copy of the current 2.3.1 application ZIP and note your live application URL.

The supplied ZIP includes `config.local.example.php`, not a replacement live credential file. **Do not overwrite the production `config.local.php` with the example file.** Keep Decart, Fish Audio and encryption values unchanged on the server.

## 2. Hosting requirements

- PHP 8.1 or newer (PHP 8.2/8.3 recommended where available).
- PDO plus either `pdo_sqlite` or `pdo_mysql`.
- `fileinfo` for upload MIME inspection.
- OpenSSL for encrypted API-key storage and HTTPS/TLS.
- `curl` for Decart and Fish Audio provider requests.
- PHP sessions enabled.
- Writable private application `storage/` folder.
- Upload limits (`upload_max_filesize`, `post_max_size`) appropriate for your configured media limits.
- A valid HTTPS certificate for camera/microphone and secure sign-in.

Shared-host PHP/runtime restrictions still apply. If the host does not provide the configured PDO driver or cURL, the corresponding persistence/provider functions will not run. Do not assume an extension exists based on local development.

## 3. Upload the release

1. Upload `ANONYMOUX_STUDIO_2.3.2_CREATOR_DASHBOARD_RESOURCE_CENTRE.zip` to the same application directory as the current 2.3.1 PHP files.
2. Extract and allow the release files to replace the matching application source files.
3. Preserve the live `config.local.php`, the existing database file and all existing user storage.
4. Confirm `.htaccess` protection files remain present in `storage/`, `storage/platform/`, `storage/references/`, `storage/voice-audio/` and the newly created `storage/resources/` directory.
5. Ensure PHP can write to `storage/` and create `storage/resources/`. Do not make the entire web root world-writable.

The release retains the existing authentication, workspace, provider, wallet and history source. There is no new public installer or default admin password.

## 4. Database migration

The application invokes the idempotent `resources_schema()` helper on authenticated pages. It creates the resource-centre tables using `CREATE TABLE IF NOT EXISTS`; the first visit to the Tools & Tutorials page seeds categories, tools and the ten initial tutorials.

For a manual DBA migration instead, run **one** file matching your configured database:

- SQLite: `migrations/002_resources_centre_sqlite.sql`
- MySQL: `migrations/002_resources_centre_mysql.sql`

Do not run both dialects. These scripts create only the resource/dashboard tables and indexes. They do not drop tables, reinitialize users, adjust wallet balances or delete platform job/asset records. The Python SQLite migration check is `python tests/resource_migration_check.py`.

## 5. Administrator setup

1. Sign in with an existing administrator account.
2. Open **Admin console → Resources**.
3. Use the Tools, Tutorials and Categories sections to create/edit records.
4. Review seeded official links and current provider requirements before publishing. Seeded version data and official URLs should be checked periodically because third-party software changes.
5. Upload tool logos/tutorial thumbnails/screenshots/GIFs as JPEG, PNG, WebP or GIF. Each file is limited to 5 MB; a tutorial submission accepts up to eight media files.
6. Add external video URLs only from supported YouTube/Vimeo destinations if you expect an embedded player. The original external video link is also offered.
7. Publish only after verifying the instructions and links. Draft items remain hidden to ordinary members; administrators can preview drafts.

The directory does not host third-party executable installers. Platform download links should point to the official vendor's own pages.

## 6. User acceptance checks

After the migration is available and an authenticated member signs in:

- Open the dashboard and compare wallet balance / recent transactions with the existing admin wallet ledger.
- Compare generation counts and history with the user's real Image, Video, Voice and Realtime records.
- Confirm recent output View/Download links work only for the owning account.
- Confirm storage numbers reflect actual files; upload a small test file and verify quota totals update.
- Confirm Notifications show only actual completed/failed job, voice, realtime, low-wallet, storage and sign-in events.
- Open Tools & Tutorials and test both tabs, search and category filters.
- Open a published tutorial, verify step order and media links, then test a draft as an ordinary member (it should be unavailable).
- Test the resource manager as an administrator; create, edit, unpublish, republish and delete a test tool/tutorial/category.
- Test that a normal member cannot POST resource-management actions or retrieve draft media.
- Test responsive layouts at 320, 360, 390, 430, 768, 1024 and 1440 CSS pixels.

Use a non-production test account/resources where possible. Remove test content and files afterward.

## 7. Existing provider acceptance

Decart and Fish Audio integrations are retained, not mocked or replaced. Test them separately on the deployed host after confirming the current server-side keys and model entitlements. This build environment lacked PHP cURL and a live database connection, so provider tests are **NOT TESTED** in this release build. Do not interpret PHP syntax tests as live provider verification.

## 8. Troubleshooting

- **Dashboard database error:** verify the existing PDO DSN and driver, database permissions and backup. Do not delete the database to “fix” a migration error.
- **Resource page shows no tools/tutorials:** ensure the database account can create tables and that the first authenticated resource-page request completed. Inspect the PHP error log and run the matching migration manually if your deployment blocks runtime DDL.
- **Admin Resources tab absent:** sign in using an account whose stored `role` is `admin`; do not promote users by editing frontend values.
- **Image/GIF upload rejected:** use JPEG, PNG, WebP or GIF, max 5 MB, with valid image signature/dimensions. SVG is intentionally disabled.
- **Media shows 404:** confirm `storage/resources/` exists, PHP can read the file, and `.htaccess` denies direct access while requests use `resource-media.php`.
- **Quota exceeded:** remove unneeded assets through the app's existing asset/history tools or have an administrator review the private storage; quota includes source/reference/output and voice audio files.
- **Decart/Fish Audio unavailable:** verify PHP cURL, TLS, API key, provider access and model entitlements. Do not paste API keys into browser code or public reports.

## 9. Verification commands

```bash
find . -type f -name '*.php' -print0 | xargs -0 -n1 php -l
find assets -type f -name '*.js' -print0 | xargs -0 -n1 node --check
python tests/resource_migration_check.py
php tests/smoke.php
```

The PHP smoke test requires `pdo_sqlite` or a working MySQL PDO DSN. It skipped in the build environment because neither PDO database driver was installed. The SQLite migration check passed using Python's SQLite engine but does not replace PHP/PDO integration testing.

## 10. Release package contents

This ZIP includes the updated application source, explicit SQLite/MySQL migrations, the source audit, dashboard/resource/security reports, test results and deployment notes. It does not include a live server database or a replacement production `config.local.php`.
