RunWait ('C:\Games\FuturePinball\FuturePinball.exe -arcaderender /open "C:\Games\FuturePinball\Tables\Supermanv3.fpt" /play /Exit')
