MR,KHORASANI v1.6.5 — Android Build

1) پوشه android/ را در Android Studio باز کنید یا Workflow GitHub Actions را با tag نسخه اجرا کنید.
2) API 36 SDK، Build Tools 36.0.0 و Java 17 در محیط CI نصب می‌شوند.
3) Workflow هم assembleDebug و هم assembleRelease را اجرا می‌کند.
4) فایل `MR-KHORASANI-v1.6.5-installable-debug.apk` با debug keystore پیش‌فرض Android ساخته می‌شود و برای نصب مستقیم روی گوشی مناسب است.
5) فایل `MR-KHORASANI-v1.6.5-APK.zip` شامل APK قابل نصب و SHA-256 آن است.
6) Release خروجی `MR-KHORASANI-v1.6.5-universal-release-unsigned.apk` برای انتشار نهایی است و برای توزیع عمومی باید با کلید مالک محصول امضا شود.

در محیط ساخت فعلی ChatGPT، Android SDK و Gradle موجود نیست؛ بنابراین APK باینری در این محیط کامپایل نشده و این بسته، سورس + Workflow آماده ساخت را ارائه می‌کند.
