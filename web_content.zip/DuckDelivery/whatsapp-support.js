(() => {
    // Replace with the WhatsApp number in international format, digits only (DDI + DDD + number).
    const WHATSAPP_PHONE = '5511999999999';
    const SUPPORT_MESSAGE = 'Olá, preciso de suporte com a minha entrega!';

    const style = document.createElement('style');
    style.textContent = `
        .whatsapp-support-button {
            position: fixed;
            right: 1.25rem;
            bottom: 1.25rem;
            z-index: 40;
            display: inline-flex;
            align-items: center;
            gap: 0.625rem;
            padding: 0.875rem 1.125rem;
            border-radius: 9999px;
            background: #25d366;
            color: #fff;
            font: 600 0.9375rem/1.25rem Inter, sans-serif;
            text-decoration: none;
            box-shadow: 0 8px 20px rgb(15 23 42 / 22%);
            transition: background-color 150ms ease, transform 150ms ease;
        }
        .whatsapp-support-button:hover {
            background: #1ebe5d;
            transform: translateY(-2px);
        }
        .whatsapp-support-button:focus-visible {
            outline: 3px solid #0c4a6e;
            outline-offset: 3px;
        }
        .whatsapp-support-button svg {
            width: 1.25rem;
            height: 1.25rem;
            flex: none;
        }
        @media (max-width: 480px) {
            .whatsapp-support-button {
                right: 1rem;
                bottom: 1rem;
                padding: 0.875rem;
            }
            .whatsapp-support-button span {
                position: absolute;
                width: 1px;
                height: 1px;
                padding: 0;
                margin: -1px;
                overflow: hidden;
                clip: rect(0, 0, 0, 0);
                white-space: nowrap;
                border: 0;
            }
        }
    `;
    document.head.appendChild(style);

    const supportButton = document.createElement('a');
    const message = new URLSearchParams({ text: SUPPORT_MESSAGE });
    supportButton.className = 'whatsapp-support-button';
    supportButton.href = `https://wa.me/${WHATSAPP_PHONE}?${message.toString()}`;
    supportButton.target = '_blank';
    supportButton.rel = 'noopener noreferrer';
    supportButton.setAttribute('aria-label', 'Falar com o suporte pelo WhatsApp');
    supportButton.innerHTML = `
        <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
            <path d="M20 11.5a8.4 8.4 0 0 1-12.4 7.4L4 20l1.2-3.5A8.4 8.4 0 1 1 20 11.5Z" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M9 8.5c.2-.4.4-.4.7-.4h.5c.2 0 .4.1.5.4l.7 1.6c.1.2 0 .4-.1.6l-.5.6c-.2.2-.2.4 0 .6.5.9 1.2 1.6 2.1 2.1.2.1.4.1.6-.1l.6-.7c.2-.2.4-.2.6-.1l1.5.7c.3.1.4.3.4.5 0 .3-.1 1.1-.7 1.6-.5.5-1.3.7-2 .5-1.1-.3-2.5-.9-3.9-2.3-1.4-1.4-2-2.8-2.3-3.9-.2-.7 0-1.5.5-2Z" fill="currentColor"/>
        </svg>
        <span>Suporte WhatsApp</span>
    `;
    document.body.appendChild(supportButton);
})();
