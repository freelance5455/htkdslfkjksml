SHEECALC

This ZIP contains the SheeCalc offline-ready app project.

CONTENTS
- index.html: app screen
- style.css: dark interface with warm amber/orange accents inspired by the reference image
- app.js: keypad and payout-based recovery calculation
- manifest.json: app metadata

USE
Extract the ZIP and open index.html in a browser. The project is designed to work offline once its files are on the device. This is a web-app project ZIP, not an APK.

CALCULATION
Required stake = (target profit + accumulated losses) / payout rate.
The required stake is rounded UP to the nearest cent.
Record Loss adds the current calculated stake to accumulated losses.
Record Win resets accumulated losses to zero.

IMPORTANT
This tool calculates stake amounts only. It cannot predict trade outcomes or guarantee recovery. Martingale strategies can increase losses rapidly.
