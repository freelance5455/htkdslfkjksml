const $=id=>document.getElementById(id);
let selected="target";
const fields=["target","payout","losses"];
function selectField(id){selected=id;document.querySelectorAll(".field").forEach(x=>x.classList.toggle("active",x.dataset.field===id));$("notice").textContent="Editing "+({target:"target profit",payout:"payout percentage",losses:"accumulated losses"}[id])+"."}
document.querySelectorAll(".field").forEach(el=>el.addEventListener("click",()=>selectField(el.dataset.field)));
function n(id){return Number($(id).value)}
function fmt(x){return "$"+(Number.isFinite(x)?x:0).toFixed(2)}
function calc(){
 const target=n("target"),payout=n("payout"),losses=n("losses");
 if(!(target>0)||!(payout>0&&payout<=100)||!(losses>=0)){
  $("stake").textContent="—";$("profit").textContent="—";$("net").textContent="—";
  $("notice").textContent="Enter a target above $0 and payout between 0 and 100%.";
  return null;
 }
 const stake=Math.ceil(((target+losses)/(payout/100))*100-1e-9)/100;
 const profit=stake*payout/100;
 $("stake").textContent=fmt(stake);$("profit").textContent=fmt(profit);$("net").textContent=fmt(profit-losses);
 $("notice").textContent=stake>100?"Warning: required stake is very high. Martingale can rapidly increase losses.":"Stake recalculates automatically when values change.";
 return {target,payout,losses,stake,profit};
}
function setValue(v){$(selected).value=v;calc()}
document.querySelectorAll("[data-key]").forEach(btn=>btn.addEventListener("click",()=>{
 let v=$(selected).value||"";
 const k=btn.dataset.key;
 if(k==="back")v=v.slice(0,-1);
 else if(k==="."){if(!v.includes("."))v+=(v?"": "0")+ ".";}
 else {if(v==="0")v=k;else v+=k;}
 setValue(v);
}));
$("clear").addEventListener("click",()=>setValue(""));
$("enter").addEventListener("click",()=>{const i=fields.indexOf(selected);selectField(fields[(i+1)%fields.length]);});
$("lost").addEventListener("click",()=>{const v=calc();if(!v)return;$("losses").value=(v.losses+v.stake).toFixed(2);selectField("losses");calc();$("notice").textContent="Loss recorded. Accumulated losses updated.";});
$("won").addEventListener("click",()=>{const v=calc();if(!v)return;$("losses").value="0.00";selectField("target");calc();$("notice").textContent="Win recorded. Recovery losses reset for the next cycle.";});
fields.forEach(id=>$(id).addEventListener("input",calc));
calc();selectField("target");
