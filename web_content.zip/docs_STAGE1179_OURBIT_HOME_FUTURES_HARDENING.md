# CryptoPulse Stage 1179 — Ourbit Home + Futures Hardening

Observed in Stage 1178 test screenshots:
- Home still showed many stale symbols with `—` (e.g. BULLY/BUNKER/BUZZ/CA/CANDLE), proving the Home universe was still coming from the older LBank/CoinPaprika catalogue rather than Ourbit.
- Futures page still showed CONNECTING/blank chart, so the response parser needed to accept the array/object shapes used by Ourbit/MEXC-style contract endpoints.

Changes:
1. Android native market-universe discovery is now Ourbit-first using the public 24h ticker endpoint. Only pairs actually returned by Ourbit are promoted to the Home universe. Existing LBank universe discovery remains a provider fallback.
2. Native Ourbit 24h ticker rows are cached into the shared market cache, so Home gets prices at the same time the universe arrives.
3. Ourbit K-line normalization now accepts:
   - normal array-of-arrays K-lines;
   - object rows;
   - `{data:[...]}` / `{result:[...]}` / `{rows:[...]}` wrappers;
   - MEXC-style `{data:{time:[...],open:[...],high:[...],low:[...],close:[...],vol:[...]}}` column arrays.
4. Futures depth parser now unwraps `data:[{asks,bids,...}]` as well as direct `data:{asks,bids}`.
5. Futures ticker parser now tolerates `data` wrappers and arrays.
6. No synthetic market prices or synthetic historical candles are created.

Official Ourbit documentation confirms the public `/api/v3/ticker/24hr`, `/api/v3/klines`, `/api/v3/defaultSymbols`, and `/api/v3/exchangeInfo` endpoints for Spot, and the contract Kline endpoint shape under `contract.ourbit.com/api/v1/contract/kline/{symbol}`. See official docs: https://ourbitdevelop.github.io/apidocs/spot_v3_en/ and Ourbit's published API collections.
