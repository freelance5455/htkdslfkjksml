/*
 * PENGGILAS — RESULT TEMPLATE DISPLAY FORMATTER
 *
 * IMPORTANT:
 * - Does NOT modify masterResult.
 * - Does NOT calculate BaZi.
 * - Does NOT change data-value / data-field contracts.
 * - Only changes the text presented to the user.
 *
 * Flow:
 *   BAZI_MASTER_RESULT -> resolvePath -> formatForDisplay -> textContent
 */

(function () {
  'use strict';

  function ruleMeaning(id) {
    const reg = (typeof window !== 'undefined' && window.PENGGILAS_BC_RULES) ? window.PENGGILAS_BC_RULES : null;
    if (!reg) return null;
    const all = Object.keys(reg.B || {}).concat(Object.keys(reg.C || {}));
    for (const key of all) {
      const r = reg.B[key] || reg.C[key];
      if (r && r.id === id) return r.hanzi ? (r.english || r.pinyin || r.hanzi) + ' (' + r.hanzi + ')' : (r.english || r.pinyin || null);
    }
    return null;
  }

  function sourceMeaning(id) {
    const srcs = (typeof window !== 'undefined' && window.PENGGILAS_BC_SOURCES && Array.isArray(window.PENGGILAS_BC_SOURCES.sources)) ? window.PENGGILAS_BC_SOURCES.sources : [];
    const hit = srcs.find(s => s && s.id === id);
    if (hit) return hit.hanzi ? hit.english + ' (' + hit.hanzi + ')' : hit.english;
    return ({
      ZPZQ: 'Zi Ping Zhen Quan (子平真诠)',
      QTBJ: 'Qiong Tong Bao Jian (穷通宝鉴)',
      DTT: 'Di Tian Sui (滴天髓)',
      SMTH: 'San Ming Tong Hui (三命通会)',
      YHZP: 'Yuan Hai Zi Ping (渊海子平)'
    })[id] || null;
  }

  function compactWhitespace(text) {
    return String(text)
      .replace(/\s+/g, ' ')
      .replace(/\s*;\s*/g, ' · ')
      .replace(/\s*\|\s*/g, ' · ')
      .trim();
  }

  function compactByGrammar(text) {
    let s = compactWhitespace(text);

    // Presentation-only cleanup. Keep facts, values, and status meaning;
    // remove implementation prose that is not useful in the displayed result.
    const replacements = [
      [/\bPROJECT METRIC\b/gi, ''],
      [/\bSOURCE-SCREENED\b/gi, 'Source-based'],
      [/\bRULE-STATUS DRIVEN\b/gi, 'Condition-dependent'],
      [/\bRULE GAP\b/gi, 'Rule gap'],
      [/\bconfigured\s+/gi, ''],
      [/\bPENGGILAS Registry\b/gi, 'Reference registry'],
      [/\blunar-javascript\b/gi, ''],
      [/\bEightChar\.getYun\b/gi, 'getYun'],
      [/\bgetYun\(\)/gi, ''],
      [/\bInternal dependency consistency checked\b/gi, 'Dependency check: Passed'],
      [/\bindependent cross-source verification not performed\b/gi, 'External cross-source verification: Not performed'],
      [/\bfinal school-specific confirmation remains\s+/gi, 'Final confirmation: '],
      [/\bNo universal school variant is assumed;\s*/gi, ''],
      [/\bexternal rule reconciliation preserves conflicting methods\b/gi, 'Different methods are preserved'],
      [/\bno silent winner is selected\b/gi, 'No single method selected'],
      [/\bThe current evidence does not establish\b/gi, 'Evidence does not establish'],
      [/\bTemporal presence alone does not prove a new final pattern\b/gi, 'Temporal presence alone: no final pattern'],
      [/\bTen-God matching alone is insufficient\b/gi, 'Ten-God matching alone: insufficient'],
      [/\bElement-presence continuity is not by itself a complete receiver\/blockage determination\b/gi, 'Element continuity alone: insufficient for receiver/blockage determination'],
      [/\bThis is not a complete\b/gi, 'Incomplete:'],
      [/\bcomplete 成格\/败格\/救应 remains source-status dependent\b/gi, '成格/败格/救应: source-dependent'],
      [/\bcomplete 成格\/败格\/救应 remains provisional or rule-status dependent\b/gi, '成格/败格/救应: provisional / condition-dependent'],
      [/\bfinal 化格 remains rule-status dependent until the selected profile is satisfied\b/gi, '化格: condition-dependent'],
      [/\bSource-screened qualitative hierarchy only; no numeric root bonus is applied\.?/gi, 'Source-based hierarchy · No numeric root bonus'],
      [/\bBranch-position priority is descriptive and does not alter B1 weights\.?/gi, 'Branch-position priority is descriptive · B1 weights unchanged'],
      [/\bDo not convert the evidence into a universal numeric Classical strength score\.?/gi, 'No universal Classical strength score'],
      [/\bUse Month Command as the primary coordinate, then evaluate roots, visible\/hidden support, and counter-forces\.?/gi, 'Month Command first · roots, visible/hidden support, and counter-forces'],
      [/\bIdentify the month branch and its Main Qi first;\s*/gi, 'Month Branch + Main Qi first · '],
      [/\bMiddle\/Residual Qi and day-precise Ren Yuan are supporting evidence and do not replace the Month Command identity\.?/gi, 'Middle/Residual Qi + Ren Yuan: supporting evidence · Month Command remains primary'],
      [/\bNatal chart establishes the initial structure; Da Yun\/Liu Nian are 后天 factors that can supplement, drain, restrain, activate, complete or disrupt an established structure\.?/gi, 'Natal chart: initial structure · Da Yun/Liu Nian: may support, drain, restrain, activate, complete, or disrupt'],
      [/\bReport generation\/draining\/control channels only where the configured evidence exists\.?/gi, 'Generation/drain/control: shown where evidence exists'],
      [/\bA10\.4 frequency distribution \+ A7 Month Command Main Qi; B3\/A12\.9 intentionally excluded\b/gi, 'A10.4 frequency + A7 Main Qi · B3/A12.9 excluded'],
      [/\bB3 is the authoritative Ge Ju candidate\/determination source; B9 consumes B3 without independent re-calculation\.?/gi, 'B3: Ge Ju determination source · B9: follows B3'],
      [/\bProject-rule temporal response; Cheng Ge\/Bian Ge remain provisional unless complete source-locked conditions are satisfied\b/gi, 'Temporal response · Cheng Ge/Bian Ge: provisional until conditions are met'],
      [/\bTrue Solar Time and the early-Zi sect are locked project parameters\.?/gi, 'True Solar Time + early-Zi sect: fixed parameters'],
      [/\bAdjusted seasonal weight and element\/ten-god ratios are project metrics\.?/gi, 'Seasonal weights + element/Ten-God ratios'],
      [/\bThey are not presented as complete Classical 旺衰 strength calculations\.?/gi, 'Not a complete Classical 旺衰 assessment'],
      [/\bOnly the displayed age number is adjusted — Starting\/Ending Year, the Gan-Zhi assigned to each period, and the precise transition date\/time are untouched by this conversion\.?/gi, 'Display age only · Years, Gan-Zhi, and transition time unchanged'],
      [/\bAge figures in A14\.2 .*?\./gi, 'Age: Actual/Elapsed (Zhou Sui).'],
      [/\bthe underlying lunar-javascript library natively computes Nominal Age .*? display so that comparisons against elapsed-age software match directly\.?/gi, 'Xu Sui (+1) → display −1.'],
      [/\bPrecise \(sect 2\): minutes from birth to reference Jie Qi ÷ 4320 = years \(lunar-javascript EightChar\.getYun\)/gi, 'Sect 2 · Birth → Jie Qi: minutes ÷ 4320 = years'],
      [/\bGregorian \(Civil Calendar\) input, converted to Chinese Lunar Calendar\b/gi, 'Gregorian Civil → Chinese Lunar Calendar'],
      [/\s*;\s*$/g, ''],
      [/\s*·\s*·/g, ' · '],
      [/\s{2,}/g, ' ']
    ];

    replacements.forEach(function ([pattern, replacement]) {
      s = s.replace(pattern, replacement);
    });

    // Canonical bilingual terminology: English first, Hanzi in parentheses.
    // Presentation-only; no calculation, determination, or source rule is changed.
    const bilingual = [
      [/\bSupport-Suppress\b(?! \(扶抑\))/gi, 'Support & Suppression (扶抑)'],
      [/\bSupport & Suppression\b(?! \(扶抑\))/gi, 'Support & Suppression (扶抑)'],
      [/\bClimate Regulation\b(?! \(调候\))/gi, 'Climate Regulation (调候)'],
      [/\bDisease(?:\/| &)Medicine\b(?! \(病药\))/gi, 'Disease & Medicine (病药)'],
      [/\bCommunication(?: \/ |\/)Bridging\b(?! \(通关\))/gi, 'Communication / Bridging (通关)'],
      [/\bFollowing the Dominant Qi\b(?! \(专旺\))/gi, 'Following the Dominant Qi (专旺)'],
      [/\bStrength & Weakness\b(?! \(旺衰\))/gi, 'Strength & Weakness (旺衰)'],
      [/\bYong Shen\b(?! \(用神\))/gi, 'Yong Shen / Useful God (用神)'],
      [/\bXi Shen\b(?! \(喜神\))/gi, 'Xi Shen / Favorable God (喜神)'],
      [/\bJi Shen\b(?! \(忌神\))/gi, 'Ji Shen / Unfavorable God (忌神)'],
      [/\bYang Ren\b(?! \(阳刃\))/gi, 'Yang Ren (阳刃)'],
      [/\bYang Ren Ge\b(?! \(阳刃格\))/gi, 'Yang Ren Pattern (阳刃格)'],
      [/\bFormation \/ Breaking \/ Rescue\b(?! \(成格\/败格\/救应\))/gi, 'Formation / Breaking / Rescue (成格/败格/救应)'],
      [/\bDay-Precise Seasonal Qi\b(?! \(人元司令分野\))/gi, 'Day-Precise Seasonal Qi (人元司令分野)'],
      [/\bMonth Command\b(?! \(月令\))/gi, 'Month Command (月令)'],
      [/\bMain Qi\b(?! \(本气\))/gi, 'Main Qi (本气)'],
      [/\bMiddle Qi\b(?! \(中气\))/gi, 'Middle Qi (中气)'],
      [/\bResidual Qi\b(?! \(余气\))/gi, 'Residual Qi (余气)'],
      [/\bStem Exposure\b(?! \(透干\))/gi, 'Stem Exposure (透干)']
    ];
    bilingual.forEach(function ([pattern, replacement]) { s = s.replace(pattern, replacement); });

    return s.replace(/^\s*[·|;,]+\s*|\s*[·|;,]+\s*$/g, '').trim();
  }

  function formatForDisplay(path, value) {
    if (value === undefined || value === null || value === '') return value;
    if (typeof value !== 'string') return value;

    let s = value;

    // A1: each field has its own header, so return the finding without engine metadata.
    if (path === 'A1.dataSource') {
      s = s.replace(/Reference registry\s*\([^)]*\)\s*\+\s*EightChar Engine/gi,
        'Classical reference framework + chart calculation');
      s = s.replace(/EightChar Engine/gi, 'chart calculation framework');
      s = s.replace(/.*?(Gregorian.*?Chinese Lunar Calendar|Gregorian Civil.*?Chinese Lunar Calendar).*/i,
        'Gregorian Civil → Chinese Lunar Calendar');
    }
    if (path === 'A1.verifyMethod') {
      s = s.replace(/.*?(astronomical.*?reference data|cross-reference).*$/i,
        'Cross-check · Astronomical data ↔ reference data');
    }
    if (path === 'A1.completenessStatus') {
      s = s.replace(/.*?FOUNDATION DATA COMPLETE\s*\(A1[–-]A17\).*?CLASSICAL RULE COMPLETENESS\s*([^.;]+).*$/i,
        'Foundation: Complete (A1–A17) · Classical Rules: $1');
    }

    // A8 seasonal state: the header already defines the state names.
    if (/^A8\.[^.]+\.seasonal$/.test(path)) {
      s = s.replace(/\s*\([^)]*\)/g, '').replace(/\s*[—-]\s*PROJECT METRIC/gi, '');
    }

    // A9: compact calculation method trace.
    if (path === 'A9.method') {
      s = s.replace(/^Visible\s*=\s*/i, 'Visible: ')
        .replace(/\.\s*Hidden\s*=\s*/i, ' · Hidden: ')
        .replace(/\.\s*Ratio\s*=\s*/i, ' · Ratio: ')
        .replace(/Heavenly Stems/gi, 'Stems')
        .replace(/all Cang Gan in the 4 Earthly Branches/gi, 'all Cang Gan');
    }

    // A12.4: extract rule, expected, and actual; remove engine syntax.
    if (/^A12_4\..+\.(result|source)$/.test(path)) {
      s = s.replace(/\bRule\s*=\s*/gi, '')
        .replace(/\bCondition\s*=\s*/gi, 'Condition: ')
        .replace(/\bExpected\s*=\s*/gi, 'Expected: ')
        .replace(/\bActual\s*=\s*/gi, 'Actual: ')
        .replace(/\s*·\s*Condition:/i, ' · Condition:');
    }

    if (/^A12_4\..+\.source$/.test(path)) {
      const expected = s.match(/Expected(?: Branch)?\s*[=:]\s*([^;·]+)/i);
      const actual = s.match(/Actual\s*[=:]\s*([^;·]+)/i);
      const rule = s.match(/^([^;·]+?)(?:;|·)/);
      const parts = [];
      if (rule) parts.push(rule[1].trim().replace(/\btriplet registry\b/i, '').trim());
      if (expected) parts.push('Expected: ' + expected[1].trim());
      if (actual) parts.push('Actual: ' + actual[1].trim());
      if (parts.length) s = parts.join(' · ');
    }

    // A12.7: preserve the transformation finding, not its internal status code.
    if (path === 'A12_7.row1.status') {
      s = s.replace(/\s*\|\s*/g, ' · ')
        .replace(/Gui\s*\+\s*Wu\s*\(→\s*Fire\)/i, 'Gui + Wu → Fire')
        .replace(/Hua Screen:\s*/i, 'Support: ')
        .replace(/Month Commands? target element/i, 'Month Command')
        .replace(/(?:but )?a sitting-branch clash is present/i, 'Obstruction: Sitting-branch clash')
        .replace(/Stage:\s*HUA_BLOCKED_BY_CONFIGURED_OBSTRUCTION/i, 'Status: Blocked')
        .replace(/Stage:\s*HUA_[A-Z_]+/i, 'Status: Blocked')
        .replace(/SOURCE-SCREENED/i, 'Source-based')
        .replace(/final school-specific confirmation remains rule-status dependent/i, 'Final: Condition-dependent');
    }

    // A12.9: candidate + status only.
    if (path === 'A12_9.alt.elem') {
      s = s.replace(/^Mechanical candidate\(s\):\s*/i, '')
        .replace(/\s*(?:—|·)\s*final Alternative Ge Ju NOT DETERMINED/i, ' · Ge Ju: Not determined');
    }

    // A13: keep the calculation basis, but make it explicitly machine-readable:
    // Inputs -> method -> intermediate -> result. This is evidence, not the result field.
    if (path === 'A13.mingGong.basis' || path === 'A13.taiYuan.basis') {
      s = s.replace(/Year Stem=/g, 'Year Stem: ')
        .replace(/Month Branch=/g, 'Month Branch: ')
        .replace(/Hour Branch=/g, 'Hour Branch: ')
        .replace(/Month No=/g, 'Month No: ')
        .replace(/Hour No=/g, 'Hour No: ')
        .replace(/Distance Yin→Ming=/g, 'Distance: ')
        .replace(/\s*→\s*安命宫/g, ' → Ming Gong')
        .replace(/\s*→\s*五虎遁/g, ' → 五虎遁')
        .replace(/Input:\s*/i, 'Inputs: ')
        .replace(/Formula:\s*/i, 'Method: ')
        .replace(/Intermediate:\s*/i, 'Intermediate: ')
        .replace(/Final:\s*/i, 'Result: ');
    }

    // A14.1: show the rule and displayed-age convention, not library mechanics.
    if (path === 'A14_1.transRule') {
      s = s.replace(/3 Days = 1 Year → 1 Day = 4 Months; 1 Hour = 5 Days \(exact minute-based conversion\)\.?/i,
          '3 Days = 1 Year · 1 Day = 4 Months · 1 Hour = 5 Days')
        .replace(/NOTE:\s*/i, '')
        .replace(/Age figures in A14\.2 .*?\./i, 'Age: Actual/Elapsed (Zhou Sui).')
        .replace(/The underlying lunar-javascript library .*?display.*?\./i, 'Xu Sui (+1) → display −1.')
        .replace(/Only the displayed age number is adjusted .*?conversion\./i, 'Display age only · Years, Gan-Zhi, and transition time unchanged.');
    }
    if (path === 'A14_1.calcMethod') {
      s = s.replace(/Precise \(sect 2\): minutes from birth to reference Jie Qi ÷ 4320 = years \(lunar-javascript EightChar\.getYun\)/i,
        'Sect 2 · Birth → Jie Qi: minutes ÷ 4320 = years');
    }

    // A14.3: merge repeated relation labels without changing the relations.
    if (/^A14_3\.\d+\.interactions$/.test(path)) {
      s = s.replace(/\bPo:\s*/gi, 'Po: ')
        .replace(/\bXing:\s*/gi, 'Xing: ')
        .replace(/\bBan He:\s*/gi, 'Ban He: ')
        .replace(/\bPo:\s*([^·]+)\s*·\s*Po:\s*/i, 'Po: $1 · ');
    }

    // A13: remove implementation/audit suffixes from the derivation trace.
    if (path === 'A13.mingGong.basis' || path === 'A13.taiYuan.basis') {
      s = s.replace(/\s*→\s*Library=[^·]+/i, '')
        .replace(/\s*→\s*Internal derivation check\b/i, '')
        .replace(/\s*\([^)]*re-derived within Core A[^)]*\)/i, '')
        .replace(/\s*\([^)]*cross-checked at engine\/library level[^)]*\)/i, '')
        .replace(/\s*\([^)]*not independent external verification[^)]*\)/i, '');
    }

    // A14.1: remove project-history wording; keep the display rule itself.
    if (path === 'A14_1.transRule') {
      s = s.replace(/\s*This is a LOCKED display decision \(confirmed with project owner\):/i, '')
        .replace(/\s*Display age only\s*·\s*/i, ' · ');
    }

    // B1: keep source and decisive signals, not implementation disclaimers.
    if (/^B1\..+\.evidence$/.test(path)) {
      s = s.replace(/Signals:\s*/i, '')
        .replace(/Month Command support: YES/gi, 'Month Command: Yes')
        .replace(/Month Command support: NO/gi, 'Month Command: No')
        .replace(/day-precise commander support: YES/gi, 'Day-precise: Yes')
        .replace(/day-precise commander support: NO/gi, 'Day-precise: No')
        .replace(/primary root: YES/gi, 'Primary Root: Yes')
        .replace(/primary root: NO/gi, 'Primary Root: No')
        .replace(/印\/比 support presence: YES/gi, 'Resource/Companion: Yes')
        .replace(/印\/比 support presence: NO/gi, 'Resource/Companion: No')
        .replace(/counter-evidence: PRESENT/gi, 'Counter-evidence: Present')
        .replace(/counter-evidence: ABSENT/gi, 'Counter-evidence: None')
        .replace(/Classical score:\s*Not claimed/gi, 'Classical score: Not assigned')
        .replace(/Project:\s*support=/i, 'Project: Support ')
        .replace(/\s+vs\s+drain=/i, ' · Drain ')
        .replace(/,\s*/g, ' · ');
    }

    if (/^B1\..+\.evidence$/.test(path)) {
      s = s.replace(/\s*Classical screen is independent of the project Support-Suppress numeric comparison;?\s*/i, ' · ')
        .replace(/\s*no source-locked quantitative 旺衰 score is claimed\.?/i, '')
        .replace(/\s*Project metric:\s*/i, 'Project: ')
        .replace(/\bSupport\s*=/i, 'Support:')
        .replace(/\bDrain\s*=/i, 'Drain:');
    }

    // B4: direct finding only; use the Month Command field, not the frequency tie list.
    if (path === 'B4.row1.yueLing') {
      const m = s.match(/Month Command Main Qi\s*=\s*([^;·]+)/i);
      if (m) s = 'Month Command Main Qi: ' + m[1].trim();
    }
    if (path === 'B4.row1.god') {
      s = s.split(';')[0].trim();
    }

    // B6/B7: concise method/effect status.
    if (/^B[67]\.row\d+\.(rel|effect|cond)$/.test(path)) {
      s = s.replace(/Mechanical branch-interaction evidence retained/gi, 'Mechanical branch evidence')
        .replace(/Mechanical Evidence/gi, 'Mechanical Evidence')
        .replace(/Not Source-Locked/gi, 'Source status: Not locked')
        .replace(/School-Sensitive/gi, 'School-sensitive')
        .replace(/Combination\/Hua:\s*Separate/gi, 'Hua: Separate');
    }

    // B8: summarize the transformation status instead of duplicating A12.7.
    if (path === 'B8.status.result') {
      s = s.replace(/\s*\|\s*/g, ' · ')
        .replace(/Hua Screen:\s*Month Commands? target element,?\s*but a sitting-branch clash is present/i,
          'Support: Month Command · Obstruction: Sitting-branch clash')
        .replace(/Stage:\s*HUA_[A-Z_]+/i, 'Status: Blocked')
        .replace(/SOURCE-SCREENED/i, 'Source-based')
        .replace(/final school-specific confirmation remains rule-status dependent/i, 'Final: Condition-dependent');
    }

    // B11: direct finding first; methodology is secondary.
    if (/^B11\.row\d+\.finding$/.test(path)) {
      s = s.replace(/Element Presence \/ Sheng-Cycle Continuity Indicator/gi, 'Element Continuity')
        .replace(/receiver\/blockage determination/gi, 'receiver/blockage assessment');
    }

    // B12: numeric result first; evidence remains formula-level only.
    if (/^B12\..+\.result$/.test(path)) {
      s = s.replace(/\s*·\s*Project metric/gi, '');
    }
    if (/^B12\..+\.evidence$/.test(path)) {
      s = s.replace(/Support = Day Master element aggregate weight/gi, 'Support = Day Master weight')
        .replace(/Drain = Output\+Wealth\+Officer/gi, 'Drain = Output + Wealth + Officer')
        .replace(/No root bonus applied \(Rule gap: no explicit root-weighting rule exists in bazi-data\.js\)/gi, 'Root bonus: None')
        .replace(/A8 aggregate weight already includes root · no double-count/gi, 'A8 includes root · No double-count');
    }

    // B13.1/B13.2: preserve the conflict; remove implementation disclaimers.
    if (/^B13_1\..+\.(result|status)$/.test(path)) {
      s = s.replace(/SOURCE-SCREENED/gi, 'Source-based')
        .replace(/RULE-STATUS DRIVEN/gi, 'Condition-dependent');
    }
    if (path === 'B13_2.yongShen.evidence') {
      s = s.replace(/External rule reconciliation preserves conflicting methods · no silent winner is selected\.?/i,
        'Different methods are preserved · No single method selected');
    }

    // B16: summary only; detailed candidates stay in B13.2.
    if (/^B16\..+\.result$/.test(path)) {
      s = s.replace(/Yong Shen\s*=\s*CONFLICTING METHOD CANDIDATES/gi, 'Yong Shen: Conflicting method candidates')
        .replace(/CONFLICTING METHOD CANDIDATES/gi, 'Conflicting method candidates');
    }

    // B17: keep verification meaning, remove implementation narration.
    if (/^B17\..+\.result$/.test(path)) {
      s = s.replace(/Section A → B derivation chain executed \(A8\/A11\/A7\/A12 → B1–B16\)\.?\s*/i, 'A → B derivation: Passed · ')
        .replace(/Internal dependency consistency checked/gi, 'Dependency check: Passed')
        .replace(/independent cross-source verification not performed/gi, 'External cross-source verification: Not performed');
    }

    // C1: current-period summary only.
    if (path === 'C1.godDynamics') {
      s = s.replace(/Stem brings\s*/i, 'Stem: ')
        .replace(/ · Branch Main Qi brings\s*/i, ' · Branch Main Qi: ')
        .replace(/relative to Day Master [^.]+\.?/i, '');
    }

    // C2: summarize temporal transformation without reprinting A12.7 methodology.
    if (path === 'C2.transformation') {
      s = s.replace(/Natal Hua \(化\) status propagated from A12\.7:\s*/i, 'Natal Hua: ')
        .replace(/\. Da Yun interaction candidate\(s\):/i, ' · Da Yun Candidate:')
        .replace(/\. No unsupported temporal transformation is produced by C2\./i, ' · Unsupported Temporal Hua: None')
        .replace(/Source-screened/gi, 'Source-based')
        .replace(/Month Commands? target element,?\s*but a sitting-branch clash is present/i, 'Month Command · Obstruction: Sitting-branch clash')
        .replace(/Stage:\s*HUA_[A-Z_]+/i, 'Status: Blocked')
        .replace(/Final:\s*rule-status dependent/i, 'Final: Condition-dependent');
    }

    // C5/C6: concise temporal balance and structural assessment.
    if (path === 'C5.balance') {
      s = s.replace(/Mixed temporal influence — both support and drain\/control evidence are present/i,
        'Temporal Support: Mixed · Support + Drain/Control: Both Present');
    }
    if (path === 'C6.overall') {
      s = s.replace(/Conflict · method-specific Yong\/Xi\/Ji candidates are preserved/i, 'Method Conflict: Preserved')
        .replace(/temporal composition contains both support-side and drain\/control-side elements for project strength indicator/i, 'Support/Drain-Control: Both Present')
        .replace(/Da Yun Gan \+ Zhi \+ Hidden Stems · presence-based temporal screen only · natal strength basis: Source-screened/i,
          'Basis: Da Yun Gan + Zhi + Hidden Stems · Screen: Presence-based · Natal basis: Source-based')
        .replace(/Evidence:\s*CONFLICT — method-specific Yong\/Xi\/Ji candidates are preserved/i, 'Method Conflict: Preserved')
        .replace(/Structural Effect:\s*Mixed — temporal composition contains both support-side and drain\/control-side elements for the project strength indicator\./i, 'Structural Effect: Mixed')
        .replace(/Evidence:\s*Da Yun Gan \+ Zhi \+ Hidden Stems \· presence-based temporal screen only \· natal strength basis: Source-based\.?/i, 'Basis: Da Yun Gan + Zhi + Hidden Stems · Screen: Presence-based · Natal basis: Source-based')
        .replace(/\.\s*No deterministic life prediction is generated by Core C\.?/i, '')
        .replace(/Assessment:\s*No significant structural shift detected/i, 'Assessment: No Significant Structural Shift');
    }

    // C7: keep evidence but remove propagation/implementation phrasing.
    if (/^C7\.row\d+\.(evidence|finding)$/.test(path)) {
      s = s.replace(/rule propagation/gi, 'rule effect')
        .replace(/dependency chain/gi, 'dependency');
    }

    // Human-facing normalization: preserve useful audit/status information, but remove machine syntax.
    // IMPORTANT: status values are information, not noise. Only normalize their wording/case.
    if (/Status$|\.status$|Status\./i.test(path)) {
      const statusMap = {
        'CALCULATED': 'Calculated',
        'COMPILED': 'Compiled',
        'VALID': 'Valid',
        'VERIFIED': 'Verified',
        'PRESENT': 'Present',
        'ABSENT': 'Absent',
        'RESOLVED': 'Resolved',
        'PROVISIONAL': 'Provisional',
        'INCOMPLETE': 'Incomplete',
        'UNRESOLVED': 'Unresolved',
        'NOT PERFORMED': 'Not performed',
        'NONE DETECTED': 'None detected',
        'SAME_DATE': 'Same date',
        'DST INACTIVE': 'DST inactive'
      };
      Object.keys(statusMap).forEach(function (key) {
        s = s.replace(new RegExp('^' + key + '$', 'i'), statusMap[key]);
      });
    }

    // ISO timestamps are valid data, but the raw machine form is not human-facing.
    // Preserve the instant and timezone while making the value readable.
    if (/^(?:A1|A2)\..*(?:Date|Time|Timestamp|DateTime|verifyDate)$/i.test(path) &&
        /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?Z$/.test(s)) {
      const d = new Date(s);
      if (!Number.isNaN(d.getTime())) {
        s = d.toISOString().replace('T', ' · ').replace(/\.\d{3}Z$/, ' UTC').replace(/Z$/, ' UTC');
      }
    }

    // Keep useful technical/audit identifiers, but remove implementation syntax around them.
    if (path === 'A1.analysisVersion') {
      s = s.replace(/\bPENGGILAS\s+BaZi\s+Engine\b/i, 'PENGGILAS Engine');
    }
    if (path === 'A1.chartId' || path === 'A1.subjectId') {
      s = s.replace(/\s*\/\s*/g, ' · ');
    }
    if (path === 'A1.compilationStatus' || path === 'A1.validityStatus') {
      s = s.replace(/^COMPILED$/i, 'Compiled').replace(/^VALID$/i, 'Valid');
    }
    if (path === 'A2.dstStatus') {
      s = s.replace(/^DST Inactive$/i, 'DST inactive');
    }
    if (path === 'A2.coordSource') {
      s = s.replace(/\bAPI\b/g, 'source');
    }
    if (path === 'A3.dateBoundary') {
      s = s.replace(/^SAME_DATE$/i, 'Same date');
    }
    if (/^A[367]\..*\.(calcStatus|verifyStatus|status|dataStatus|calConvStatus|monthCmdStatus)$/.test(path)) {
      s = s.replace(/^CALCULATED$/i, 'Calculated')
        .replace(/^VERIFIED$/i, 'Verified')
        .replace(/^RESOLVED$/i, 'Resolved');
    }

    // Calculation traces are useful when they explain the result; hide only implementation/audit suffixes.
    if (/^A13\..+\.(basis|verify)$/.test(path)) {
      s = s.replace(/\bCALCULATED\s*[—-]\s*INTERNAL CHECK\b/gi, 'Calculated')
        .replace(/\bCALCULATED\s*[—-]\s*ENGINE\/LIBRARY CROSS-CHECK\b/gi, 'Calculated · Cross-check')
        .replace(/\bINTERNAL CHECK\b/gi, 'Internal check')
        .replace(/\bENGINE\/LIBRARY CROSS-CHECK\b/gi, 'Cross-check');
    }

    // A16/A17: audit meaning is retained; only internal implementation labels are humanized.
    if (/^A1[67]\./.test(path)) {
      s = s.replace(/\bBAZI_DATA stem\+branch registry\b/gi, 'Stem/branch reference data')
        .replace(/\bA15 format checks\b/gi, 'A15 format checks')
        .replace(/\bInternal integrity verified\b/gi, 'Integrity: Verified')
        .replace(/\bInternal calculation retained\b/gi, 'Calculation retained')
        .replace(/\bNo external verification claimed\b/gi, 'External verification: Not claimed')
        .replace(/\bCross-check is engine\/library-level\b/gi, 'Cross-check level: Engine/reference')
        .replace(/\bsource-locked\b/gi, 'source-specific')
        .replace(/\bproject parameters\b/gi, 'fixed parameters');
    }

    // B6/B7: the evidence type is useful, but implementation phrasing is not.
    if (/^B[67]\./.test(path)) {
      s = s.replace(/Mechanical (?:branch-)?interaction evidence/gi, 'Interaction evidence')
        .replace(/Mechanical branch evidence/gi, 'Branch interaction evidence')
        .replace(/effect precedence is NOT universally source-locked/gi, 'Effect precedence: not universally source-specific')
        .replace(/simultaneous-relation precedence remains School-sensitive/gi, 'Simultaneous-relation precedence: school-sensitive')
        .replace(/not silently collapsed/gi, 'not collapsed');
    }

    // B3/B8/B13/B16/B17/C2/C4/C5/C6: retain source/condition caveats without exposing engine internals.
    s = s.replace(/\bB3 authority\b/gi, 'Ge Ju determination')
      .replace(/\bconsumed from B3 authority\b/gi, 'follows Ge Ju determination')
      .replace(/\bA12\.7\b/gi, 'the natal Hua result')
      .replace(/\bA12\.5\/A12\.6\/A12\.7\b/gi, 'natal interaction results')
      .replace(/\bBAZI_DATA registry\b/gi, 'reference data')
      .replace(/\bproject rules\b/gi, 'defined rules')
      .replace(/\bsystem clock\b/gi, 'current date/time')
      .replace(/\bsource-locked\b/gi, 'source-specific')
      .replace(/\bPENGGILAS Structural Priority Model\b/gi, 'Structural priority model')
      .replace(/\bproject synthesis only\b/gi, 'Project synthesis')
      .replace(/\bproject strength indicator\b/gi, 'strength indicator');

    // C7 is provenance/audit information: preserve what was checked and its source, but make it readable.
    if (/^C7\.row\d+\./.test(path)) {
      s = s.replace(/Derived from /gi, 'Basis: ')
        .replace(/interval-membership check executed/gi, 'Period membership checked')
        .replace(/rule effect/gi, 'Rule effect')
        .replace(/propagated from /gi, 'Based on ')
        .replace(/consume /gi, 'Use ')
        .replace(/remain separate/gi, 'remain separate')
        .replace(/Project-rule temporal response/gi, 'Temporal response')
        .replace(/Project-rule/gi, 'Defined-rule')
        .replace(/source-specific conditions/gi, 'source-specific conditions');
    }

    // Final field-specific audit cleanup: preserve provenance, but present it as provenance.
    if (path === 'A15.source') {
      s = s.replace(/^Core A \(A2–A7\) — chart calculation framework$/i,
        'Calculation source: Core A (A2–A7) · chart calculation framework');
    }
    if (path === 'A17.row1.field') {
      s = s.replace(/^A3\.baziTime \/ EightChar sect \/ A14\.startAge$/i,
        'Basis: A3 BaZi time · EightChar sect · A14 start age');
    }
    if (path === 'A17.row3.note') {
      if (s.length > 280) {
        s = 'Implemented: day-precise seasonal Qi (人元司令分野), root hierarchy, Hua obstruction screening, and Yang Ren (阳刃) screening. Remaining: universal-school Hua variants, complete 从格/化格 evaluation, full 格局成败/救应 reconciliation, and quantitative Classical 旺衰 scoring. Dependent outputs: provisional / condition-dependent.';
      }
    }
    if (path === 'A17.row3.status') {
      s = s.replace(/^SCOPED \/ RULE-STATUS$/i, 'Scoped / Condition-dependent');
    }
    if (path === 'B13_1.method.result') {
      s = s.replace(/\bCONFIGURED\b/i, 'Configured');
    }
    if (path === 'C7.row2.source') {
      s = s.replace(/^C1 \/ BAZI_DATA$/i, 'C1 · Reference data');
    }

    // Fresh HTML audit cleanup: convert source/engine identifiers into human-readable
    // provenance while preserving the underlying rule, status, and evidence.
    // This layer is intentionally presentation-only; it does not alter masterResult.
    if (/^B2\..*\.evidence$/.test(path)) {
      s = s.replace(/ZPZQ-REN-YUAN-001\s*·\s*/i, 'Ren Yuan source table · ')
        .replace(/selected source table is not blended with 三命通会's different day-allocation table/i,
          'Uses the selected Ren Yuan day-allocation table · not blended with 三命通会')
        .replace(/selected source table/i, 'Selected source table');
    }
    if (/^B3\..*\.evidence$/.test(path)) {
      s = s.replace(/ZPZQ-YANGREN-001\s*:\s*/i, 'Yang Ren source rule: ')
        .replace(/ZPZQ-YANGREN-001\s*\+\s*/i, 'Yang Ren source rule + ')
        .replace(/ZPZQ-REN-YUAN-001\s+is supporting temporal-Qi evidence/i,
          'Ren Yuan timing evidence is supporting evidence')
        .replace(/A12\.9 Middle\/Residual Qi candidate source/i,
          'Middle/Residual Qi candidate')
        .replace(/A12\.9 Middle\/Residual Qi of Month Branch/i,
          'Middle/Residual Qi of Month Branch')
        .replace(/B3 Ge Ju primary determination/i, 'Primary Ge Ju determination')
        .replace(/B3 Pattern Integrity/i, 'Pattern integrity')
        .replace(/Source-based\s+Yang Ren factors/i, 'Yang Ren factors');
    }
    if (/^B[23]_?\..*\.(result|evidence)$/.test(path)) {
      s = s.replace(/\bsource-specific\b/gi, 'source-based')
        .replace(/\bsource-status dependent\b/gi, 'source-dependent');
    }

    // Global human-facing cleanup for registry/audit identifiers and machine-style metrics.
    // If a provenance identifier must remain visible, render its source-backed meaning instead of the ID.
    s = s.replace(/\bBC-[A-Z0-9_-]+\b/gi, function(id) { return ruleMeaning(id) || 'Classical rule reference'; });
    s = s.replace(/\b(?:ZPZQ|QTBJ|DTT|SMTH|YHZP)(?:-[A-Z0-9_-]+)?\b/gi, function(id) {
      return sourceMeaning(id.split('-')[0].toUpperCase()) || 'Classical source';
    });
    s = s.replace(/\bN-[TBC][0-9]+\b/gi, '');
    // Kode tetap ada di Master Result; hanya bentuk tampilannya yang diubah di sini.
    s = s.replace(/\bZPZQ-[A-Z0-9-]+\b\s*[:·-]?\s*/gi, 'Classical source rule · ')
      .replace(/\bZP-[A-Z0-9-]+\b\s*[:·-]?\s*/gi, 'Classical source rule · ')
      .replace(/\bDY-AUDIT-\d+\b/gi, 'Da Yun audit')
      .replace(/\bVER-A-\d+\b/gi, 'Verification item')
      .replace(/\bNOTE-A-\d+\b/gi, 'Note')
      .replace(/\braw\s*=\s*([0-9.]+)\s*,\s*weight\s*=\s*([0-9.]+)/gi, 'Raw: $1 · Weight: $2')
      .replace(/\braw\s*=\s*([0-9.]+)\b/gi, 'Raw: $1')
      .replace(/\bweight\s*=\s*([0-9.]+)\b/gi, 'Weight: $1');

    // Final pass for machine-style key: value phrasing that is still useful as evidence.
    s = s.replace(/\bReference Point=/gi, 'Reference Point: ')
      .replace(/\bDay Branch=/gi, 'Day Branch: ')
      .replace(/\bYear Branch=/gi, 'Year Branch: ')
      .replace(/\bInput:/gi, 'Input:')
      .replace(/\bMonth Pillar=/gi, 'Month Pillar: ')
      .replace(/\bMonth Command Main Qi \/ 月令本气 =/gi, 'Month Command Main Qi / 月令本气:')
      .replace(/\brelation=/gi, 'Relation: ')
      .replace(/\bvisible=/gi, 'Visible: ')
      .replace(/\bhidden=/gi, 'Hidden: ')
      .replace(/\bfreq=/gi, 'Frequency: ')
      .replace(/\btie=/gi, 'Tie: ')
      .replace(/\bindicator: STRONG/gi, 'indicator: Strong')
      .replace(/\braw count =/gi, 'Raw count:')
      .replace(/\braw count=/gi, 'Raw count:')
      .replace(/\bA14_2 startAge\/endAge contiguity/gi, 'Da Yun age-range continuity')
      .replace(/\bDa Yun sequence \(A14_2\)/gi, 'Da Yun sequence')
      .replace(/\bA8\.weight \/ A9\.ratio \/ A10/gi, 'Element weights · Yin/Yang ratio · Ten Gods')
      .replace(/\bEngine version:/gi, 'Calculation version:')
      .replace(/\bMechanical hidden-stem candidates/gi, 'Hidden-stem candidates')
      .replace(/\bMechanical candidate\(s\)/gi, 'Candidate(s)');

    // Source/provenance fields: retain what was checked, but remove code-like IDs,
    // object paths, and implementation ownership from the human-facing value.
    if (/\.(source|verifier)$/.test(path)) {
      s = s.replace(/\bZPZQ-[A-Z0-9-]+\b\s*[:·-]?\s*/gi, '')
        .replace(/\bA\d+(?:\.\d+)?(?:\/[A-Z0-9_.]+)?\b/g, '')
        .replace(/\bB\d+(?:\.\d+)?(?:\/[A-Z0-9_.]+)?\b/g, '')
        .replace(/\bC\d+(?:\.\d+)?(?:\/[A-Z0-9_.]+)?\b/g, '')
        .replace(/\bBAZI_DATA\b/gi, 'reference data')
        .replace(/\bPenggilasCoreA\b/gi, 'Core A')
        .replace(/\bautomated internal integrity check\b/gi, 'integrity check')
        .replace(/\bautomated contiguity check\b/gi, 'contiguity check')
        .replace(/\bthe natal Hua result\b/gi, 'natal Hua result')
        .replace(/\bdefined rules\b/gi, 'defined rule set');
    }

    if (path === 'A3.baziTime') {
      s = s.replace(/\s*\(True Solar Time\s*[—-]\s*locked rule\)/i, ' (True Solar Time)');
    }
    if (path === 'A12_4.tianyi.source' || path === 'A12_4.lushen.source') {
      s = s.replace(/\btable registry\b/gi, 'reference table');
    }
    if (path === 'A12_7.row1.type' || path === 'B8.candidate.cond') {
      s = s.replace(/Hua status NOT confirmed by this engine/i, 'Hua: Not confirmed');
    }
    if (path === 'A15.lockStatus') {
      s = s.replace(/LOCKED\s*\(permanent chart fields pass internal integrity checks\)/i,
        'Locked · Permanent chart fields: integrity verified');
    }
    if (path === 'A15.verifyStatus') {
      s = s.replace(/INTERNAL VERIFIED\s*·\s*INDEPENDENT VERIFICATION NOT PERFORMED/i,
        'Verified · Independent verification: Not performed');
    }
    if (/^A16\..*/.test(path)) {
      s = s.replace(/\bPenggilasCoreA\b/gi, 'Core A')
        .replace(/\bStem\/branch reference data\s*\+\s*A15 format checks/i, 'Stem/branch reference data · A15 format checks')
        .replace(/\bLibrary cross-check retained as calculation provenance\b/i, 'Reference cross-check retained as calculation provenance');
    }
    if (path === 'A17.row1.note') {
      s = s.replace(/the library's Nominal Age \(虚岁\) is not exposed as the display convention/i,
        'Nominal Age (虚岁) is not used as the display convention');
    }
    if (path === 'A17.row4.note') {
      s = s.replace(/VERIFIED means an internal or explicitly identified check passed/i,
        'Verified means the identified check passed');
    }

    // Remove code-style field references when the surrounding section already identifies them.
    if (/^B(6|7)\..*/.test(path)) {
      s = s.replace(/\(see the natal Hua result\/B8\)/i, '(see Hua result)')
        .replace(/\(see A12\.7\/B8\)/i, '(see Hua result)')
        .replace(/from A12\.5/i, '')
        .replace(/from A12\.6/i, '');
    }
    if (path === 'B11.row1.receiver') {
      s = s.replace(/no explicit Qi Flow receiver-derivation rule exists in the project registry/i,
        'No explicit Qi Flow receiver rule is defined');
    }
    if (/^B13_1\..*\.result$/.test(path)) {
      s = s.replace(/\bRULE-DRIVEN\b/gi, 'Rule-driven')
        .replace(/no central engine blocker\s*·\s*downstream sections consume rule status and preserve conflicts/i,
          'No central blocker · conflicts preserved')
        .replace(/External Classical Rule Layer\s*·\s*/i, '')
        .replace(/Yong-Shen multi-method reconciliation:\s*/i, 'Yong Shen methods: ');
    }
    if (path === 'B13_2.method.evidence') {
      s = s.replace(/\s*·\s*see Classical Rule Registry/i, '');
    }
    if (/^B14\..*\.(type|req)$/.test(path)) {
      s = s.replace(/Yong Shen dependency candidate/gi, 'Yong Shen dependency')
        .replace(/Xi Shen dependency candidate/gi, 'Xi Shen dependency')
        .replace(/Ji Shen vulnerability candidate/gi, 'Ji Shen vulnerability');
    }
    if (/^B15\..*\.reason$/.test(path)) {
      s = s.replace(/Structural priority model\s*—\s*Project synthesis\s*·\s*not a universal Classical ranking/i,
          'Project synthesis · not a universal Classical ranking')
        .replace(/Structural priority model\s*—\s*project priority once strength is known/i,
          'Project priority once strength is known')
        .replace(/Structural priority model\s*—\s*project priority\s*·\s*not a universal Classical hierarchy claim/i,
          'Project priority · not a universal Classical hierarchy claim');
    }
    if (/^B16\..*\.result$/.test(path)) {
      s = s.replace(/\s*\[consumed from Ge Ju determination\]/i, '')
        .replace(/\s*\[Ge Ju determination · B9 does not independently re-determine\]/i, '')
        .replace(/\s*via Support-Suppress project indicator plus Source-based qualitative evidence/i, ' · Source-based qualitative evidence')
        .replace(/\s*\(Yong Shen\) \/\s*/i, ' · ')
        .replace(/\s*\(Xi Shen\) \/\s*/i, ' · ')
        .replace(/\s*\(Ji Shen\)/i, '')
        .replace(/\bRULE STATUS CONFLICT\b/gi, 'Method conflict');
    }
    if (/^B17\..*\.result$/.test(path)) {
      s = s.replace(/B3 is the authoritative Ge Ju candidate\/determination source\s*·\s*B9 consumes B3 without independent re-calculation\./i,
          'Ge Ju determination: B3 · Formation status remains source-dependent.')
        .replace(/\s*via Support-Suppress project indicator plus Source-based qualitative evidence/i, ' · Source-based qualitative evidence')
        .replace(/\s*via rule profile/i, '')
        .replace(/\s*·\s*independent source verification was not performed/i, '')
        .replace(/\s*·\s*no independent Classical source verification performed/i, '');
    }

    // C-section provenance: preserve evidence, remove pipeline references.
    if (/^C7\..*\.(source|finding|evidence)$/.test(path)) {
      s = s.replace(/\bA14\.2 transition timestamps and current date\/time\b/i, 'Transition timing and current date/time')
        .replace(/\bC1 \/ Reference data\b/i, 'Reference data')
        .replace(/\bC2 \/ A12\.5 \/ A12\.6 \/ natal Hua result \/ defined rule set\b/i, 'Combination/conflict and Hua rules')
        .replace(/\bC2 \/ A12\.5 \/ A12\.6 \/ the natal Hua result \/ defined rules\b/i, 'Combination/conflict and Hua rules')
        .replace(/\bC3 \/ C4 \/ B1 \/ B13_2\b/i, 'Temporal structure and rule assessment')
        .replace(/\bC5 \/ C6 \/ B12 \/ B13_2\b/i, 'Temporal balance and rule assessment')
        .replace(/\bTemporal response · Cheng Ge\/Bian Ge remain provisional unless complete source-specific conditions are satisfied/i,
          'Temporal response · Cheng Ge/Bian Ge remain provisional until conditions are satisfied')
        .replace(/\bYong\/Xi\/Ji relations Use B13 rule status\b/i, 'Yong/Xi/Ji relations use the current rule status');
    }
    if (path === 'C6.overall') {
      s = s.replace(/Structural Effect:\s*Mixed\s*Basis:/i, 'Structural Effect: Mixed · Basis:')
        .replace(/\bMethod Conflict: Preserved\s*·\s*Structural Effect: Mixed\s*·?\s*/i, 'Method Conflict: Preserved · Structural Effect: Mixed · ');
    }

    // Second-pass cleanup from the rendered DK audit: internal field coordinates,
    // source codes, and pipeline references are not user-facing evidence.
    // Keep named classical sources/rules; remove only implementation identifiers.
    if (path === 'A1.analysisVersion') {
      const m = s.match(/V[0-9.]+/i);
      s = m ? 'Engine version: ' + m[0] : 'Engine version';
    }
    if (path === 'A12_4.lushen.source') {
      s = s.replace(/Chang Sheng registry/i, 'Chang Sheng reference table');
    }
    if (path === 'A15.source') {
      s = 'Core A calculation · EightChar';
    }
    if (path === 'A16.row3.issue') {
      s = 'Calculation derivation check only · independent cross-source verification not performed';
    }
    if (path === 'A16.row4.issue') {
      s = 'Reference cross-check level · independent external verification not performed';
    }
    if (path === 'A17.row3.type') {
      s = 'Rule scope / resolution status';
    }
    if (path === 'A17.row3.field') {
      s = 'Month Command · Root · Hua · Ge Ju · Yong Shen · Temporal response';
    }
    if (path === 'A17.row4.field') {
      s = 'Foundation checks · B-section verification · Temporal verification';
    }

    if (path === 'B1.yueLing.evidence') {
      s = s.replace(/B2 Month Command Main Qi \/ 月令本气/i, 'Month Command Main Qi / 月令本气')
        .replace(/A8 seasonal state is a and is not used as the Classical relation label/i,
          'Seasonal state is separate from the Classical relation label');
    }
    if (path === 'B1.root.evidence') {
      s = s.replace(/A11 Core Root Foundation/i, 'Root foundation')
        .replace(/Rule note: no explicit root-weighting rule exists/i, 'Root weighting: no separate bonus')
        .replace(/Root evidence is already included in the aggregate weight \(\) and is not counted a second time/i,
          'Root evidence is included in the aggregate weight · No double-count');
    }
    if (path === 'B1.determination.result') {
      s = s.replace(/\s*project Support-Suppress indicator remains STRONG/i, ' · Support-Suppress indicator: Strong')
        .replace(/\s*no source-specific quantitative Classical 旺衰 score is claimed/i, '');
    }
    if (path === 'B3.integrity.evidence') {
      s = 'Yang Ren source rule';
    }
    if (path === 'B4.row1.vis') {
      s = 'Visible Shi Shen by pillar';
    }
    if (path === 'B4.row1.root') {
      s = 'Hidden-stem root support';
    }
    if (path === 'B5.contrib.evidence') {
      s = 'Root evidence contributes to Day-Master assessment · No second numeric root bonus';
    }
    if (path === 'B6.row1.cond') {
      s = 'All detected stem interactions';
    }
    if (path === 'B7.row1.cond') {
      s = 'All detected branch interactions';
    }
    if (path === 'B8.condition.cond') {
      s = s.replace(/^source-screen:\s*/i, 'Condition: ');
    }
    if (path === 'B8.obstruct.evidence') {
      s = 'Branch interaction evidence + Hua obstruction screen';
    }
    if (path === 'B9.config.evidence') {
      s = 'Primary Ge Ju determination';
    }
    if (path === 'B9.factors.evidence') {
      s = 'Month Command, Ge Ju factors, root quality, and day-precise Ren Yuan evidence';
    }
    if (path === 'B9.status.evidence') {
      s = 'Pattern integrity';
    }
    if (path === 'B11.row1.receiver') {
      s = 'Not determined · No explicit Qi Flow receiver rule is defined';
    }
    if (path === 'B12.drain.result') {
      s = 'Output + Wealth + Officer combined weight vs Support side';
    }
    if (path === 'B12.drain.evidence') {
      s = 'Support-side comparison';
    }
    if (path === 'B12.control.result') {
      s = 'Per-element control relations';
    }
    if (path === 'B13_1.geJu.result') {
      s = s.replace(/B3 rule stage:\s*/i, 'Ge Ju status: ');
    }
    if (path === 'B13_1.conflict.result') {
      s = s.replace(/EFFECT REQUIRES RULE EVALUATION/i, 'Effect: Rule-dependent');
    }
    if (path === 'B13_1.special.result') {
      s = s.replace(/source conditions:/i, 'conditions:')
        .replace(/Cong Ge \/ Hua Ge are separate rule profiles/i, 'Cong Ge / Hua Ge: separate rule conditions');
    }
    if (path === 'B13_1.method.result') {
      // 'Configured' is engine configuration metadata, not an analytical finding.
      s = 'Defined rule set';
    }
    if (path === 'B13_1.determinationStatus.result') {
      s = 'Rule-driven · No central blocker · Conflicts preserved';
    }
    if (path === 'B13_2.method.evidence') {
      s = 'Zi Ping Zhen Quan (子平真诠) framework';
    }
    if (path === 'B16.geJu.result') {
      s = s.replace(/\s*\[.*?\]/g, '');
    }
    if (path === 'B16.overall.result') {
      s = s.replace(/RULE STATUS CONFLICT/i, 'Method conflict')
        .replace(/preserve method candidates\./i, 'Method candidates preserved.');
    }
    if (path === 'B17.geJu.result') {
      s = s.replace(/Ge Ju determination: B3 · Formation status remains source-dependent\./i,
        'Ge Ju determination · Formation status remains source-dependent.');
    }
    if (path === 'B17.yongShen.result') {
      s = s.replace(/\s*via rule profile/i, '')
        .replace(/\s*·\s*independent source verification was not performed/i, '');
    }
    if (path === 'C5.repeated') {
      s = 'Yes · Temporal elements include the natal highest-weight element';
    }
    if (path === 'C7.row1.finding') {
      s = 'Transition timing + current date/time · Period membership checked';
    }
    if (path === 'C7.row1.source') {
      s = 'Transition timing';
    }
    if (path === 'C7.row2.evidence') {
      s = 'Stem/Branch dynamics';
    }
    if (path === 'C7.row2.source') {
      s = 'Reference data';
    }
    if (path === 'C7.row3.evidence') {
      s = 'Combination / Conflict scan';
    }
    if (path === 'C7.row3.finding') {
      s = 'Natal Hua status is based on the natal Hua result · Temporal He candidates remain separate';
    }
    if (path === 'C7.row3.source') {
      s = 'Combination/conflict and Hua rules';
    }
    if (path === 'C7.row4.evidence') {
      s = 'Qi Flow & Structural Response';
    }
    if (path === 'C7.row4.source') {
      s = 'Temporal structure and rule assessment';
    }
    if (path === 'C7.row5.evidence') {
      s = 'Temporal Balance & Determination';
    }
    if (path === 'C7.row5.source') {
      s = 'Temporal balance and rule assessment';
    }

    // Remove residual internal section coordinates from values where the field's
    // own position already supplies that context.
    if (/^(B[1-9]|B1[0-7])\..*/.test(path)) {
      s = s.replace(/\b(?:A|B|C)\d+(?:_\d+)?(?:\.\d+)?(?:\/[A-Za-z0-9_.]+)?\b(?:\s*\/\s*)?/g, '')
        .replace(/\bsee\s+the\s+natal\s+Hua\s+result\/B8\b/gi, 'see Hua result')
        .replace(/\bsee\s+B1\b/gi, '')
        .replace(/\bSee\s+B10\s+for\s+/gi, '');
    }
    if (/^C7\./.test(path)) {
      s = s.replace(/\b(?:A|B|C)\d+(?:_\d+)?(?:\.\d+)?\b(?:\s*\/\s*)?/g, '')
        .replace(/\s*\/\s*$/, '');
    }
    s = s.replace(/\s{2,}/g, ' ').replace(/\s*·\s*·\s*/g, ' · ')
      .replace(/^\s*[·|/,]+\s*|\s*[·|/,]+\s*$/g, '').trim();

    if (path === 'A15.source') s = 'Calculation basis: Four Pillars';
    if (/^A16\..*\.verifier$/.test(path)) s = s.replace(/^Core A.*$/i, 'Internal check');
    if (path === 'A16.row3.source') s = 'Ming Gong calculation';
    if (path === 'A16.row4.source') s = 'Tai Yuan derivation + cross-check';
    if (path === 'A16.row4.verifier') s = 'Internal check';
    if (path === 'A17.row1.field') s = 'Basis: True Solar Time · Early-Zi sect · Da Yun start age';
    if (path === 'B2.priority.evidence') {
      s = 'Ren Yuan timing table · Selected day-allocation table is used separately from 三命通会';
    }
    if (/^B3\.(candidate|type)\.evidence$/.test(path)) {
      s = s.replace(/Yang Ren source rule/i, 'Classical Yang Ren rule');
    }
    if (path === 'B3.integrity.evidence') s = 'Classical Yang Ren rule';
    if (path === 'B6.row1.effect') {
      s = s.replace(/not universally source-specific/i, 'school-dependent');
    }
    if (/^B15\..*\.reason$/.test(path)) {
      s = s.replace(/Project synthesis/i, 'Project-level synthesis')
        .replace(/Project priority/i, 'Project-level priority');
    }
    if (path === 'C7.row1.finding') s = 'Transition timing + current date/time · Period membership checked';

    // FINAL HUMAN + AI PRESENTATION PASS (A1–C7 only)
    // Presentation-only: preserves facts, evidence, uncertainty and provenance;
    // removes implementation ownership, engine internals and audit-log phrasing.
    if (path === 'A1.analysisVersion') {
      const m = s.match(/V[0-9.]+/i);
      s = m ? 'Calculation framework: Version ' + m[0].replace(/^V/i, '') : 'Calculation framework';
    }
    if (path === 'A2.coordSource') {
      s = s.replace(/Open-Meteo Geocoding source/i, 'Geocoded location data')
        .replace(/Geocoding API source/i, 'Geocoded location data');
    }
    if (path === 'A15.source') {
      s = 'Calculation basis: Four Pillars';
    }
    if (/^A16\..*\.id$/.test(path)) {
      s = s.replace(/^Verification item$/i, 'Check');
    }
    if (/^A16\..*\.verifier$/.test(path)) {
      s = s.replace(/^Internal check$/i, 'Calculation integrity check');
    }
    if (/^A16\..*\.issue$/.test(path)) {
      s = s.replace(/^Calculation derivation check only · External cross-source verification: Not performed$/i,
        'Calculation derivation checked · Independent cross-source verification: Not performed')
        .replace(/^Reference cross-check level · independent external verification not performed$/i,
          'Reference cross-check recorded · Independent external verification: Not performed');
    }
    if (/^A16\..*\.action$/.test(path)) {
      s = s.replace(/^External verification: Not claimed$/i, 'Independent verification: Not performed');
    }
    if (path === 'A15.lockStatus') {
      s = s.replace(/Permanent chart fields: integrity verified/gi, 'Permanent chart fields: integrity verified');
    }
    if (path === 'A15.verificationStatus') {
      s = s.replace(/^INTERNAL VERIFIED\s*·\s*INDEPENDENT VERIFICATION NOT PERFORMED$/i,
        'Verified · Independent cross-source verification: Not performed');
    }

    if (/^A16\..*\.resolution$/.test(path)) {
      s = s.replace(/^Calculation retained · independent verification not performed$/i,
        'Calculation retained · Independent verification: Not performed')
        .replace(/^Reference cross-check retained as calculation provenance$/i,
        'Reference cross-check retained as evidence');
    }
    if (/^A16\..*\.source$/.test(path)) {
      s = s.replace(/^Ming Gong calculation$/i, 'Ming Gong calculation basis')
        .replace(/^Tai Yuan derivation \+ cross-check$/i, 'Tai Yuan calculation basis + reference cross-check');
    }
    if (path === 'A16.row1.verifier' || path === 'A16.row2.verifier' || path === 'A16.row3.verifier' || path === 'A16.row4.verifier') {
      s = 'Calculation integrity check';
    }
    if (path === 'A16.row3.issue') {
      s = 'Calculation derivation checked · Independent cross-source verification: Not performed';
    }
    if (path === 'A16.row4.issue') {
      s = 'Reference cross-check recorded · Independent external verification: Not performed';
    }

    if (/^B[67]\..*/.test(path)) {
      s = s.replace(/Interaction evidence: mechanical/gi, 'Interaction evidence')
        .replace(/Mechanical branch evidence/gi, 'Branch interaction evidence')
        .replace(/school-sensitive/gi, 'school-dependent');
    }
    if (/^B15\..*\.reason$/.test(path)) {
      s = s.replace(/Structural priority model\s*[—-]\s*Project-level synthesis\s*·\s*not a universal Classical ranking/i,
        'Project synthesis; not presented as a universal Classical ranking.')
        .replace(/Structural priority model\s*[—-]\s*Project-level priority once strength is known/i,
        'Project-level priority is considered after strength is established.')
        .replace(/Structural priority model\s*[—-]\s*Project-level priority\s*·\s*not presented as a universal Classical hierarchy\.?/i,
        'Project-level priority; not presented as a universal Classical hierarchy.');
    }
    if (path === 'C7.row5.finding') {
      s = s.replace(/Yong\/Xi\/Ji relations use the current rule status · conflicts and unresolved states are preserved explicitly/i,
        'Yong/Xi/Ji assessment follows the current rule status; conflicting and unresolved states are retained.');
    }

    if (/^B(13_1|13_2|14|15|16|17)\..*/.test(path)) {
      s = s.replace(/Rule-driven · No central blocker · Conflicts preserved/gi,
        'Assessment follows the defined rule set; conflicting methods are preserved.')
        .replace(/Project-level priority · not a universal Classical hierarchy claim/gi,
        'Project-level priority; not presented as a universal Classical hierarchy.')
        .replace(/Project synthesis · not a universal Classical ranking/gi,
        'Project synthesis; not presented as a universal Classical ranking.')
        .replace(/Source-based Yang Ren factors/gi, 'Yang Ren factors from the selected source framework')
        .replace(/Formation status remains source-dependent/gi, 'Formation status depends on the applicable source conditions');
    }
    if (/^B17\..*\.result$/.test(path)) {
      s = s.replace(/independent source verification was not performed/gi,
        'independent source verification was not performed');
    }
    if (/^C[1-7]\..*/.test(path)) {
      s = s.replace(/Project-rule/gi, 'Defined-rule')
        .replace(/rule propagation/gi, 'rule effect')
        .replace(/dependency chain/gi, 'dependency')
        .replace(/pipeline/gi, 'calculation process');
    }
    if (/^C7\..*\.(source|finding|evidence|provenanceStatus)$/.test(path)) {
      s = s.replace(/^Defined-rule$/i, 'Defined rule')
        .replace(/^CALCULATED$/i, 'Calculated')
        .replace(/^SOURCE-SCREENED$/i, 'Source-screened')
        .replace(/^PROJECT-RULE$/i, 'Defined rule');
    }

    // Remove explicit implementation names from human-facing A1–C7 values.
    s = s.replace(/\bPENGGILAS\s+BaZi\s+Engine\b/gi, 'calculation framework')
      .replace(/\bPENGGILAS\s+Engine\b/gi, 'calculation framework')
      .replace(/\bBAZI_DATA\b/gi, 'reference data')
      .replace(/\bbazi-data\.js\b/gi, 'reference data')
      .replace(/\bCore A \(A2–A7\) — chart calculation framework\b/gi, 'EightChar calculation basis')
      .replace(/\bCore A calculation · EightChar\b/gi, 'EightChar calculation basis')
      .replace(/\bCore A\b/gi, 'calculation foundation')
      .replace(/\bOpen-Meteo Geocoding source\b/gi, 'Geocoded location data');

    // Avoid dangling punctuation created by the presentation cleanup above.
    s = s.replace(/\s+([,.;:])/g, '$1').replace(/\s*·\s*·\s*/g, ' · ');

    // Final value cleanup for evidence fields that still contain implementation references.
    if (/^B1\..+\.evidence$/.test(path) || /^B12\..+\.evidence$/.test(path)) {
      s = s.replace(/\bRULE GAP\s*[—-]?\s*/gi, 'Rule note: ')
        .replace(/\bbobot Day Master\b/gi, 'Day Master weight')
        .replace(/\bvia A8\.[A-Za-z0-9_.]+\b/gi, '')
        .replace(/\bin bazi-data\.js\b/gi, '')
        .replace(/\broot evidence is already reflected inside the Day Master element's aggregate weight\b/gi, 'Root evidence is already included in the aggregate weight')
        .replace(/\s*\(via\.[A-Za-z0-9_]+\.hidden\)\s*/gi, ' ')
        .replace(/\bvia\.[A-Za-z0-9_]+\.hidden\b/gi, '')
        .replace(/\s*\(Rule note:\s*[^)]*\)/gi, '');
    }
    if (/^B8\.(condition|status)\.(evidence|result)$/.test(path) || path === 'C2.transformation') {
      s = s.replace(/Hua Screen:\s*Month Commands? target element,?\s*but a sitting-branch clash is present/i,
          'Support: Month Command · Obstruction: Sitting-branch clash')
        .replace(/Month Commands? target element,?\s*but a sitting-branch clash is present/i,
          'Month Command · Obstruction: Sitting-branch clash')
        .replace(/Stage:\s*HUA_[A-Z_]+/i, 'Status: Blocked')
        .replace(/final school-specific confirmation remains rule-status dependent/i, 'Final: Condition-dependent')
        .replace(/source-status dependent/i, 'source-dependent');
    }
    if (/^B3\..+\.evidence$/.test(path)) {
      s = s.replace(/final formation remains source-status dependent/i, 'Final formation: Source-dependent');
    }

    // Global leak cleanup: engine artifacts must never reach the human-facing result.
    // Keep analytical values/statuses; remove only empty markers and implementation tokens.
    s = s.replace(/\[\s*\]/g, '')
      .replace(/<PARSED TEXT FOR PAGE:\s*[^>]+>/gi, '')
      .replace(/\bHE_DETECTED_NOT_TRANSFORMED\b/gi, 'Hua not confirmed')
      .replace(/\bHUA_BLOCKED_BY_CONFIGURED_OBSTRUCTION\b/gi, 'Blocked')
      .replace(/\bHUA_[A-Z_]+\b/gi, 'Blocked')
      .replace(/\bStage:\s*Hua not confirmed\b/gi, 'Hua: Not confirmed')
      .replace(/\bStage:\s*Blocked\b/gi, 'Status: Blocked')
      .replace(/\bYong Shen methods:\s*Configured\b/gi, 'Yong Shen method: Defined rule set')
      .replace(/\bMethodology Resolved\s+Yong Shen method:\s*Defined rule set/gi, 'Methodology: Defined rule set')
      .replace(/\bproject Support-Suppress indicator\s*=\s*(STRONG|WEAK)\b/gi, function (_, v) {
        return 'Support-Suppress indicator: ' + v.charAt(0).toUpperCase() + v.slice(1).toLowerCase();
      })
      .replace(/\bProject:\s*support\s*=\s*([0-9.]+)\s*·\s*Drain\s*([0-9.]+)/gi, 'Support: $1 · Drain: $2')
      .replace(/\bProject:\s*Support\s+([0-9.]+)\s*·\s*Drain\s*([0-9.]+)/gi, 'Support: $1 · Drain: $2')
      .replace(/\bMechanical Pattern Candidate\b/gi, 'Main Qi-based candidate')
      .replace(/\bMechanical candidate\(s\)\b/gi, 'Candidate(s)')
      .replace(/\bMechanical\b/gi, 'Pattern-rule basis')
      .replace(/\bMain Qi → Ten God · Mechanical · not Tou Gan\/penetration\b/gi, 'Main Qi → Ten God · Tou Gan/penetration: No')
      .replace(/\bMechanical\s*·\s*not Tou Gan\/penetration\b/gi, 'Tou Gan/penetration: No')
      .replace(/\bConfigured\b/gi, 'Defined')
      .replace(/\bSupport-Suppress project indicator\b/gi, 'Support-Suppress indicator')
      .replace(/\bproject Support-Suppress indicator\b/gi, 'Support-Suppress indicator')
      .replace(/\s{2,}/g, ' ')
      .trim();

    s = applyBCPresentationGrammar(path, s);

    // MASTER SEMANTIC CONTRACT PATCH — Round 2.
    // These are presentation-only field-role corrections confirmed by
    // template-driven audit. They do not alter masterResult.
    if (path === 'A15.verifyStatus') {
      s = 'Verified · Independent cross-source verification: Not performed';
    }
    if (path === 'A16.row2.source') {
      s = 'Da Yun calculation output';
    }
    if (path === 'A16.row3.issue') {
      s = 'Calculation derivation check';
    }
    if (path === 'A16.row4.issue') {
      s = 'Reference cross-check';
    }
    if (path === 'A16.row3.action' || path === 'A16.row4.action') {
      s = 'None required';
    }
    if (path === 'A17.row1.type') {
      s = 'Calculation Parameter';
    }

    // B1/B12: remove empty interpolation fragments without changing the finding.
    if (path === 'B1.yueLing.evidence') {
      const idx = s.search(/seasonal state is a(?: project metric)? and is not used as the Classical relation label/i);
      if (idx >= 0) {
        s = s.slice(0, idx).replace(/[. ]+$/, '. ') +
          'Seasonal state is descriptive only; not used as the Classical relation label.';
      }
    }
    if (path === 'B1.determination.result') {
      const m = s.match(/Support-Suppress indicator(?: remains|:)\s*(Strong|Weak)/i);
      s = 'BALANCED / MIXED EVIDENCE · no final Classical 旺衰 label · Support-Suppress indicator: ' +
        (m ? m[1].charAt(0).toUpperCase() + m[1].slice(1).toLowerCase() : 'Not determined');
    }
    if (path === 'B12.support.result') {
      s = s.replace(/\s*\[(?:PROJECT METRIC)?\]\s*$/i, '').replace(/\s*\[\s*\]\s*$/g, '');
    }
    if (path === 'B12.excess.evidence') {
      s = 'Adjusted-weight comparison · Highest adjusted-weight element; not automatically 太过 / absolute excess.';
    }

    // B4: the template column is Position, but the engine value is a frequency
    // distribution. Make the mismatch explicit instead of making the AI infer it.
    if (path === 'B4.row1.pos') {
      s = 'Not a single position · frequency distribution only';
    }

    // B8: keep one compact evidence home per semantic role.
    if (path === 'B8.condition.evidence') {
      if (/No combination/i.test(s) || /N\/A/i.test(s)) {
        s = 'No stem combination detected.';
      } else {
        const support = /Month Command supports target element/i.test(s)
          ? 'Month Command supports target element'
          : /Month Command does not support target element/i.test(s)
            ? 'Month Command does not support target element'
            : 'Month Command support screened';
        const obstruction = /sitting-branch clash is present/i.test(s)
          ? 'Sitting-branch clash present'
          : /Hua: Not confirmed/i.test(s)
            ? 'Hua not confirmed'
            : 'Obstruction screened';
        s = support + ' · ' + obstruction;
      }
    }
    if (path === 'B8.status.evidence') {
      if (/No Combination Present/i.test(s) || /N\/A/i.test(s)) {
        s = 'No combination detected.';
      } else if (/BLOCKED/i.test(s)) {
        s = 'Hua condition screen indicates obstruction.';
      } else {
        s = 'Hua condition screen does not establish transformation.';
      }
    }

    // B6/B7: structural effect is the finding; precedence policy is a qualification.
    if (path === 'B6.row1.effect') {
      s = 'School-dependent effect precedence · He/Hua distinction preserved';
    }
    if (path === 'B7.row1.effect') {
      s = 'School-dependent relation precedence · Combination and transformation remain separate';
    }

    // B13.1: the determination gate reports its state, not pipeline governance prose.
    if (path === 'B13_1.determinationStatus.result') {
      s = 'Method conflict preserved';
    }

    // B13.2: remove pipeline ownership wording from evidence.
    if (path === 'B13_2.yongShen.evidence') {
      s = 'Other methods (调候 / 病药 / 通关 / 专旺) are reported separately.';
    }

    // B15: compact, field-specific reasons; preserve the non-universal Classical caveat.
    if (/^B15\.1\.reason$/.test(path) || /^B15\.2\.reason$/.test(path)) {
      s = 'Defined structural priority; not a universal Classical ranking.';
    }
    if (path === 'B15.3.reason') {
      s = 'Defined structural priority after strength is known.';
    }
    if (path === 'B15.4.reason') {
      s = 'Defined structural priority; not a universal Classical hierarchy.';
    }

    // B17: one semantic role per result field.
    if (path === 'B17.consistency.result') {
      s = 'Consistent · External cross-source verification not performed.';
    }
    if (path === 'B17.geJu.result') {
      s = 'Ge Ju determination follows B3 · Formation remains source-dependent.';
    }
    if (path === 'B17.strength.result') {
      const m = s.match(/Support-Suppress indicator:\s*(Strong|Weak)/i);
      s = 'BALANCED / MIXED EVIDENCE · no final Classical 旺衰 label · Support-Suppress indicator: ' +
        (m ? m[1].charAt(0).toUpperCase() + m[1].slice(1).toLowerCase() : 'Not determined') +
        ' · Independent Classical source verification not performed.';
    }
    if (path === 'B17.yongShen.result') {
      s = s.replace(/CONFLICTING METHOD CANDIDATES/gi, 'Conflicting methods')
        .replace(/\s*via Defined rule profile/gi, '')
        .replace(/\s*·\s*independent source verification was not performed/gi, '')
        .trim();
    }
    if (path === 'B17.unresolved.result') {
      s = 'Independent cross-source verification not performed.';
    }

    // B16 synthesis: keep the primary determination compact; detailed candidates remain in B13.2.
    if (path === 'B16.yongShen.result') {
      s = s.replace(/\s*·\s*candidate Favorable Supports \(喜神\)/gi, '')
        .replace(/\s*·\s*candidate Unfavorable Factors \(忌神\)/gi, '')
        .trim();
    }

    // Final C6 grammar guard: keep the structural finding, drop engine narration.
    if (path === 'C6.overall') {
      const assessment = /No significant structural shift/i.test(s);
      const parts = ['Method conflict: Preserved', 'Structural effect: Mixed', 'Support/Drain-Control: Both Present', 'Basis: Da Yun Gan + Zhi + Hidden Stems', 'Screen: Presence-based', 'Natal basis: Source-based'];
      if (assessment) parts.push('Assessment: No Significant Structural Shift');
      return compactByGrammar(parts.join(' · '));
    }
    if (path === 'C6.overall__legacy_guard') {
      s = s.replace(/temporal composition contains both support-side and drain\/control-side elements for (?:the )?(?:configured project )?strength indicator/ig, 'Support/Drain-Control: Both Present')
        .replace(/temporal composition contains both support-side and drain\/control-side elements for (?:the )?strength indicator/ig, 'Support/Drain-Control: Both Present');
    }

    return compactByGrammar(s);
  }


  // B/C presentation grammar: one fact, one home.
  // Keep this generic: regression cases are not presentation rules.
  function applyBCPresentationGrammar(path, text) {
    let s = text;
    if (!/^B\d|^C[1-7]\./.test(path)) return s;

    // RESULT = finding. STATUS = determination state. EVIDENCE = why.
    if (/^B(?:1|13_1|13_2|16)\..+\.result$/.test(path)) {
      s = s.replace(/\s*[-—]\s*source[- ]screened/ig, '')
        .replace(/\s*[-—]\s*source-based/ig, '')
        .replace(/\s*\[.*?\]/g, '')
        .replace(/\bRULE STATUS CONFLICT\b/ig, 'Method conflict')
        .replace(/\bCONFLICTING METHOD CANDIDATES\b/ig, 'Conflicting methods')
        .replace(/\bno unique 用神 selected\b/ig, 'No unique Yong Shen')
        .replace(/\bno unique Yong Shen selected\b/ig, 'No unique Yong Shen')
        .replace(/\bYang Ren Ge \(阳刃格\) Candidate\b/ig, 'Yang Ren Ge')
        .replace(/\bFire Day Master\b/ig, 'Day Master: Fire')
        .replace(/\bWood Day Master\b/ig, 'Day Master: Wood')
        .replace(/\bWater Day Master\b/ig, 'Day Master: Water')
        .replace(/\bEarth Day Master\b/ig, 'Day Master: Earth')
        .replace(/\bMetal Day Master\b/ig, 'Day Master: Metal')
        .replace(/\bStrength Determination:\s*/ig, 'Strength: ');
    }

    if (/^B13_2\.(yongShen|xiShen|jiShen)\.evidence$/.test(path)) {
      s = s.replace(/External rule reconciliation preserves conflicting methods\s*[·—-]?\s*/i, '')
        .replace(/Different methods are preserved\s*[·—-]?\s*/i, '')
        .replace(/No single method selected\.?/i, 'No unique selection')
        .replace(/Support-Suppress:\s*/i, 'Support-Suppress: ')
        .replace(/Climate Regulation:\s*/i, 'Climate: ');
    }

    if (path === 'B16.overall.result') {
      const dm = s.match(/Day Master:\s*([^;·]+)/i);
      const ge = s.match(/Yang Ren Ge[^;·]*/i);
      const ys = s.match(/(?:Conflicting methods|Yong Shen:\s*Conflicting methods)[^;·]*/i);
      const parts = [];
      if (dm) parts.push('Day Master: ' + dm[1].trim());
      if (ge) parts.push(ge[0].trim().replace(/\s*[-—]\s*Incomplete.*$/i, ' · Incomplete'));
      if (/Conflicting methods/i.test(s)) parts.push('Yong Shen: Conflicting methods');
      return parts.join(' · ') || s;
    }

    if (/^B17\..+\.result$/.test(path)) {
      s = s.replace(/Section A → B derivation chain executed.*?\.?\s*/i, 'Structural derivation: Passed · ')
        .replace(/Internal dependency consistency checked/ig, 'Dependency check: Passed')
        .replace(/independent cross-source verification not performed/ig, 'External cross-source verification: Not performed');
    }

    if (/^B12\..+\.result$/.test(path)) {
      s = s.replace(/^—\s*/,'')
        .replace(/PROJECT METRIC\s*[—-]?\s*/i,'')
        .replace(/Support side higher/i, 'Support > Drain')
        .replace(/Support > Drain\s*\(([^)]+)\)/i, 'Support > Drain · $1');
    }

    if (path === 'C1.godDynamics') {
      s = s.replace(/Stem brings\s*/i, 'Stem: ')
        .replace(/\s*·\s*Branch Main Qi brings\s*/i, ' · Branch Main Qi: ');
    }

    if (path === 'C2.transformation') {
      s = s.replace(/Natal Hua \(化\) status propagated from A12\.7:\s*/i, 'Natal Hua: ')
        .replace(/\.\s*Da Yun interaction candidate\(s\):/i, ' · Da Yun Candidate:')
        .replace(/\.\s*No unsupported temporal transformation is produced by C2\.?/i, '')
        .replace(/Hua Screen:\s*Month Command support/i, 'Support: Month Command')
        .replace(/\.?\s*Source-screened/ig, '')
        .replace(/Final:\s*rule-status dependent/i, 'Final: Condition-dependent');
    }

    if (path === 'C5.balance') {
      if (/Mixed/i.test(s) && /Support/i.test(s) && /Drain\/Control/i.test(s)) {
        s = 'Mixed · Support + Drain/Control Present';
      }
    }

    if (path === 'C6.overall') {
      s = s.replace(/Evidence:\s*CONFLICT\s*—\s*method-specific Yong\/Xi\/Ji candidates are preserved/ig, 'Method conflict: Preserved')
        .replace(/Evidence:\s*CONFLICT\s*—/ig, 'Method conflict:')
        .replace(/Structural Effect:\s*/i, 'Structural effect: ')
        .replace(/—\s*temporal composition contains both support-side and drain\/control-side elements for the (?:configured project )?strength indicator/ig, 'Support/Drain-Control: Both Present')
        .replace(/temporal composition contains both support-side and drain\/control-side elements for the (?:configured project )?strength indicator/ig, 'Support/Drain-Control: Both Present')
        .replace(/Evidence:\s*Da Yun Gan \+ Zhi \+ Hidden Stems[^·.]*\.?/i, 'Basis: Da Yun Gan + Zhi + Hidden Stems')
        .replace(/presence-based temporal screen only/ig, 'Presence-based screen')
        .replace(/natal strength basis=Source-screened/ig, 'Natal basis: Source-based')
        .replace(/\s*No deterministic life prediction is generated by Core C\.?/ig, '')
        .replace(/temporal composition contains both support-side and drain\/control-side elements for (?:the )?(?:configured project )?strength indicator/ig, 'Support/Drain-Control: Both Present')
        .replace(/\s*\.\s*/g, ' · ')
        .replace(/\s*—\s*/g, ' · ');
    }

    if (/^B12\..+\.result$/.test(path)) {
      s = s.replace(/\s*\[\s*\]/g, '');
    }

    if (/^C7\..*/.test(path)) {
      s = s.replace(/Derived from A14\.2 transition timestamps and system clock · interval-membership check executed/i,
        'Transition timing + current date/time · Period membership checked')
        .replace(/Derived from BAZI_DATA registry · Tou Qing is only an elemental-alignment indicator/i,
        'Stem/Branch dynamics · Reference data')
        .replace(/Project-rule temporal response ·/i, 'Temporal response ·');
    }

    return s;
  }

  function resolvePath(obj, path) {
    return path.split('.').reduce(function (acc, key) {
      return (acc && acc[key] !== undefined) ? acc[key] : undefined;
    }, obj);
  }

  function bindMasterResult(masterResult) {
    if (!masterResult) return;

    document.querySelectorAll('[data-value]').forEach(function (el) {
      const path = el.getAttribute('data-value');
      const value = resolvePath(masterResult, path);

      if (value === undefined || value === null || value === '') return;

      // IMPORTANT: only the displayed text is transformed.
      // masterResult itself remains untouched.
      el.textContent = formatForDisplay(path, value);
    });
  }

  window.PENGGILAS_RESULT_TEMPLATE = {
    resolvePath: resolvePath,
    formatForDisplay: formatForDisplay,
    bindMasterResult: bindMasterResult
  };

  window.addEventListener('message', function (event) {
    if (event.data && event.data.type === 'BAZI_MASTER_RESULT') {
      bindMasterResult(event.data.payload);
    }
  });

  window.addEventListener('DOMContentLoaded', function () {
    // Static labels belong to result-template.html. Do not translate or rewrite them here.
    window.parent.postMessage({ type: 'REQUEST_BAZI_MASTER_RESULT' }, '*');

    var backButton = document.getElementById('back-to-report-button');
    if (backButton) {
      backButton.addEventListener('click', function () {
        window.parent.postMessage({ type: 'BAZI_RETURN_TO_REPORT' }, '*');
      });
    }
  });
})();
