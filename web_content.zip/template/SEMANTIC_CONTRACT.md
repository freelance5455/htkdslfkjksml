# PENGGILAS — Template Semantic Contract (Current)

## 1. Authority
The template defines the ordered presentation contract. `result-template.html` and `result-template.js` are human-facing rendering layers; `template/ai-result-template.json` is the AI-facing structural projection contract.

`MASTER RESULT` remains the analytical source of truth.

## 2. Locked analytical order
The established classification is preserved exactly:

```text
A1 → A17 → B1 → B17 → C1 → C7
```

Nested subsections remain in their existing positions. The classification is not cosmetic; it describes the analytical flow.

## 3. BAZI DATA TREE

```text
BAZI CHART DATA
│
├── A. FOUNDATION MASTER
│   └── What is here?
│
├── B. PROFILE & STRUCTURE / GE JU
│   └── What structure does it form?
│
└── C. TEMPORAL DYNAMICS
    └── How does it respond over time?
```

Semantic relationship:

> **A builds foundational facts → B builds structural interpretation from those facts → C applies temporal dynamics to that established structure.**

A establishes what is present. B builds the structural interpretation from that foundation. C describes temporal interaction, activation, or change of the established structure. C is not an alternate engine for rewriting B.

The tree is a reading/projection model only. It is not a new calculation layer.

## 4. Semantic field roles
Where supplied by the template, preserve the distinction between:

- **Result / Finding** — supplied finding or value.
- **Evidence** — supplied chart, interaction, calculation, or temporal evidence.
- **Source / Basis** — supplied source, method, rule basis, or derivation basis.
- **Condition** — supplied prerequisite, blocker, or formation condition.
- **Qualification** — supplied scope, limitation, or methodological boundary.
- **Status** — supplied state; never inferred or upgraded.
- **Verification** — supplied verification claim and its scope.

Do not compress separate semantic roles into one long sentence when the template already provides distinct fields.

## 5. State boundaries

```text
Determination: FINAL / PROVISIONAL / CANDIDATE / UNRESOLVED / MULTI_METHOD / CONFLICT
Computation:   CALCULATED
Verification:  VERIFIED (scope-bound)
```

`CALCULATED` is not independent Classical verification. Generic `VERIFIED` is not automatically cross-source verification. Open states remain open.

## 6. Null boundary
A null or omitted field means no value was supplied for that field. Do not silently translate null into unresolved, not applicable, false, or verified.

## 7. AI-facing hygiene
The AI-facing JSON must not expose implementation identifiers as BaZi concepts. Table IDs, binding IDs, audit IDs, source-record IDs, legacy semantic-record structures, and internal rule handles are implementation metadata only and are not AI vocabulary.

## 8. Cross-section consistency
Repeated information is allowed when the same supplied fact is intentionally represented in different analytical contexts. Repetition must not be used to create a new determination.

Examples include Transformation / Hua across foundation, structure, and temporal response; Ge Ju foundation versus structural determination; and Useful God foundation versus structural determination and temporal response.

When context differs, preserve the context rather than forcing one universal sentence.

## 9. Human report boundary
Human presentation and AI projection are separate views of the same MasterResult. Human-facing cleanup does not authorize internal implementation identifiers to enter the AI payload.

## 10. Maintenance rule
Do not change Core A/B/C calculation logic to repair an AI projection defect. Fix the mapper, template projection contract, or presentation layer at the appropriate boundary. When classification changes, rerun structural and field-binding validation before release.
