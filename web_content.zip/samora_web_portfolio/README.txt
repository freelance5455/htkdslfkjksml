SAMORA WEB WEBSITE

Pages: index.html (Home), services.html, about.html, contact.html.
No sample portfolio projects are included. Your supplied logo is in assets/samora-web-logo.png.

PREVIEW: Extract the ZIP and open index.html in a modern browser. For public access, upload the complete folder to a static hosting service such as Netlify, GitHub Pages or Cloudflare Pages. Keep the assets folder beside the HTML files.

WHATSAPP: Service enquiry links open https://wa.me/2348131802910 with a pre-filled message naming the selected service. The number is not printed visibly on the pages.

This is a responsive front-end website; real e-commerce payment processing, backend functionality, forms, CMS, domain and hosting require separate setup.
