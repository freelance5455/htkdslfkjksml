CHATCƏBİ Game Creator - düzəldilmiş versiya. HTML to App > Zipped site seçib bu ZIP-i yükləyin.
