CHATCEBI veb layihəsi. APK builder saytında bu ZIP-i yüklə. Giriş faylı index.html-dir. Bu ilkin offline versiyadır; həqiqi AI modeli deyil.
