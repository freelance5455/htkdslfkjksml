TAXI AZ — Tam sistem üçün başlanğıc layihə
==========================================
Bu ZIP tam taksi platformasının ilkin mənbə layihəsidir. Hazır, yayımlanmış xidmət və ya quraşdırıla bilən APK deyil. APK bu mühitdə qurulmayıb və telefonda sınaqdan keçirilməyib.

DAXİLDƏ
- public/: müştəri/sürücü bölməli mobil veb tətbiq
- Firebase Authentication e-poçt/şifrə girişi və qeydiyyatı
- Firestore sifariş yaratma, sifariş siyahısı və status yeniləmələri
- Xəritə (OpenStreetMap), ünvan axtarışı (Nominatim), marşrut/məsafə (OSRM)
- functions/: ən yaxın təsdiqlənmiş onlayn sürücünü tapmaq və FCM varsa push bildirişinə cəhd
- firestore.rules: ilkin təhlükəsizlik qaydaları
- android-wrapper/: Android WebView qabığı layihəsi
- Firebase Hosting quruluşu

ƏVVƏL OXU
Müştəri/sürücü canlı sinxronizasiyası Firebase layihəsi konfiqurasiya olunub yayımlandıqdan sonra işləməlidir. Bu ZIP daxilində heç bir Firebase açarı yoxdur. “Tam sistem” kommersiya üçün hazır demək deyil: real telefon nömrəsi OTP, sürücü sənədinin admin yoxlanması, canlı GPS-in davamlı paylaşılması, FCM Android push setup, admin paneli, tarif siyasəti, ödəniş, təhlükəsizlik auditi, testlər və hüquqi uyğunluq əlavə edilməlidir.

FIREBASE QURAŞDIRILMASI
1. Firebase Console-da layihə yarat və Web App əlavə et.
2. Authentication -> Sign-in method -> Email/Password aktiv et.
3. Firestore Database yarat.
4. Project settings -> Web app config dəyərlərini public/app.js içində firebaseConfig-a daxil et.
5. Firestore qaydalarını firestore.rules faylından Firebase Console-a yayımla.
6. Kompüterdə Node.js və Firebase CLI qur: npm install -g firebase-tools
7. Layihə qovluğunda `firebase login`, `.firebaserc.example` faylını `.firebaserc` adı ilə köçürüb project ID-ni yaz.
8. `firebase deploy --only hosting,firestore:rules` ilə veb tətbiqi yayımla.
9. Backend funksiyaları üçün functions qovluğunda `npm install`, sonra `firebase deploy --only functions`. Cloud Functions üçün layihədə billing planı tələb oluna bilər.

SÜRÜCÜ TƏSDİQİ
Sürücü qeydiyyatdan keçəndə rolunu “Sürücü” seçir, lakin backend onu avtomatik təsdiqlənmiş etmir. Admin konsolundan drivers/{uid}.approved = true yazılmalıdır. İstehsalda bu sahəyə yalnız admin/Cloud Function yazmağa icazə verən daha sərt qaydalar qurun. Bu ZIP-dəki qaydalar başlanğıc nümunəsidir və audit edilməlidir.

APK
android-wrapper/ Android Studio üçün sadə WebView qabığıdır. Android Studio-da qovluğu açın, Gradle sync edin, sonra Build > Build APK(s). Bunun üçün Android SDK, Gradle və şəbəkə asılılıqları lazımdır. APK bu mühitdə yaradılmayıb və quraşdırılma testi aparılmayıb.
İstifadə üçün əvvəlcə Firebase Hosting HTTPS ünvanını əldə edib AndroidManifest.xml-də TAXI_WEB_URL dəyərinə yerləşdirin.
