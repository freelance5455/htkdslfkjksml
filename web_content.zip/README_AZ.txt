CHATCƏBİ AI-Ready layihəsi

1) index.html ZIP-in içindəki əsas tətbiqdir. HTML-to-App builder-in "Zipped site" bölməsinə yüklə.
2) Bu tətbiq offline fallback verir. AI serveri olmadan tam generativ AI deyil.
3) worker-template.js təhlükəsiz server şablonudur. API açarı APK-da deyil, server secret kimi saxlanmalıdır.
4) Serveri böyüklərin köməyi ilə deploy edin. AI provider endpoint/model/API key əldə etmədən online AI aktiv olmaz.
5) Server hazır olanda onun POST URL-i tətbiqdə "AI bağlantısı" bölməsinə yazılır.
Server cavab formatı: JSON { "reply": "AI cavabı" }.
Server POST request body: { "message": "...", "history": [{"text":"...","who":"user|bot"}] }.
