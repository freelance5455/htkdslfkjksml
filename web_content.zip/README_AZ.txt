NOONROOT – OXIDE LAUNCHER PATCH

Bu patch Noonroot-un WebView interfeysinə GAME bölməsi əlavə edir. KEY təsdiqindən sonra istifadəçi Oxide tətbiqini açmağa cəhd edə bilər.

DƏYİŞİKLİK:
- assets/web/index.html yenilənib
- GAME bölməsi və Android intent ilə oyunu açma düyməsi əlavə edilib
- Play Store səhifəsinə keçid düyməsi əlavə edilib

VACİB MƏHDUDİYYƏT:
Bu, oyunun prosesinə qoşulmur, yaddaş oxumur, ESP/Skeleton göstərmir və ETA-nın gizli Hook/anti-cheat müdaxiləsini təkrarlamır. WebView xarici intent-i bloklasa, Android wrapper-in Java/Kotlin tərəfində ayrıca, adi package-launch bridge tələb olunur.

QURAŞDIRMA:
Layihədə assets/web/index.html faylını bu ZIP-dəki eyni yolla əvəz et və Android layihəsini yenidən build/sign et. Bu ZIP özü APK deyil.
