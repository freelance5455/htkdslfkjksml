Bu ilkin offline demo-dur, tam AI modeli deyil. Söhbət localStorage ilə cihazda saxlanılır. HTML-to-App builder-də Zipped site seçib ZIP yüklə.
