DS BREEDER APP

આ પેકેજમાં DS BREEDER ની મોબાઇલ-ફ્રેન્ડલી એપ, લોગો અને PWA ફાઇલો છે.

ચાલુ કરવા: index.html ફાઇલ Chrome માં ખોલો. ઓનલાઇન વેબ-હોસ્ટિંગ પર HTTPS દ્વારા મૂક્યા પછી Chrome menu માંથી Install app / Add to Home screen પસંદ કરી શકાય છે.

મહત્વપૂર્ણ: આ ZIP છે, Android APK નથી. APK બનાવવા Android Studio માં WebView wrapper build કરવો પડશે.

સુવિધાઓ: AI Entry, AI પછી 21 દિવસ Heat reminder, 60 દિવસ PD, 285 દિવસ Expected Calving, Farmer/Mobile/Tag, Semen/Bull & Batch, Records search, SMS/WhatsApp draft, Camp, Tasks, Semen Stock, Transfer/Retagging/Abortion/False PD/Sold/Dead event log, JSON Backup/Restore.

SMS/WhatsApp બટન ફોનની messaging app ખોલે છે; મોકલવા માટે Send દબાવવું પડે છે. રેકોર્ડ આ ફોનના browser storage માં રહે છે. Backup નિયમિત Export કરો.
