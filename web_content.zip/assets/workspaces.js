
(() => {
 const $=id=>document.getElementById(id), csrf=window.PLATFORM_CSRF||'';
 const headers={'X-CSRF-Token':csrf};
 const setStatus=(node,msg,type='')=>{if(!node)return;node.textContent=msg;node.className='form-status'+(type?' is-'+type:'');};
 const preview=(input,img,empty,video=false)=>{const el=$(input);if(!el)return;el.addEventListener('change',()=>{const f=el.files?.[0];if(!f)return;const url=URL.createObjectURL(f);const target=$(img);target.src=url;target.hidden=false;$(empty).hidden=true;if(video)target.load();});};
 preview('imageSource','imageSourcePreview','imageSourceEmpty');
 preview('imageReference','imageReferencePreview','imageReferenceEmpty');
 preview('videoSource','videoSourcePreview','videoSourceEmpty',true);
 preview('videoReference','videoReferencePreview','videoReferenceEmpty');
 const imageForm=$('imageForm');
 if(imageForm) imageForm.addEventListener('submit',async e=>{
   e.preventDefault();const btn=$('imageGenerate'),status=$('imageStatus'),result=$('imageResult'),actions=$('imageResultActions');
   if(!imageForm.reportValidity())return;
   btn.disabled=true;btn.textContent='Processing image…';setStatus(status,'Uploading source and sending request to Lucy Image 2.','');
   result.hidden=true;actions.hidden=true;
   try{
     const fd=new FormData(imageForm);fd.set('enhance_prompt',imageForm.elements.enhance_prompt.checked?'true':'false');
     const res=await fetch('api/image-generate.php',{method:'POST',headers,body:fd,credentials:'same-origin'});
     const data=await res.json();if(!res.ok||!data.ok)throw new Error(data.error||'Image generation failed.');
     result.src=data.outputUrl;result.hidden=false;result.onload=()=>setStatus(status,`Completed · ${data.width} × ${data.height}px · Original source preserved.`,'success');
     result.onerror=()=>setStatus(status,'The generated output could not be displayed. Use the download action to retry.','error');
     $('imageDownload').href=data.outputUrl+'&download=1';$('imageDownload').setAttribute('download','anonymous-studio-image.png');actions.hidden=false;
     $('imageResultMeta').textContent=`${data.width} × ${data.height}px · PNG`;
     $('imageOpenFull').onclick=()=>window.open(data.outputUrl,'_blank','noopener');
   }catch(err){setStatus(status,err.message||'Request failed.','error');}
   finally{btn.disabled=false;btn.innerHTML='Generate image <span>↗</span>';}
 });
 const videoForm=$('videoForm');
 if(videoForm) videoForm.addEventListener('submit',async e=>{
   e.preventDefault();if(!videoForm.reportValidity())return;
   const btn=$('videoGenerate'),status=$('videoStatus');btn.disabled=true;btn.textContent='Submitting job…';setStatus(status,'Uploading video and submitting to the selected batch model.');
   $('videoResult').hidden=true;$('videoResultActions').hidden=true;
   try{
     const fd=new FormData(videoForm);fd.set('enhance_prompt',videoForm.elements.enhance_prompt.checked?'true':'false');fd.set('self_anchor',videoForm.elements.self_anchor.checked?'true':'false');
     const res=await fetch('api/video-jobs.php',{method:'POST',headers,body:fd,credentials:'same-origin'});const data=await res.json();if(!res.ok||!data.ok)throw new Error(data.error||'Video submission failed.');
     setStatus(status,`Job submitted · Local ID ${data.jobId}. Provider status will be checked automatically.`,'success');
     pollVideo(data.jobId);
   }catch(err){setStatus(status,err.message||'Video submission failed.','error');}
   finally{btn.disabled=false;btn.innerHTML='Submit video edit <span>↗</span>';}
 });

 // Video Edit Studio mode switch
 const modeTabs=[...document.querySelectorAll('[data-video-mode]')];
 const modePanels=[...document.querySelectorAll('[data-video-mode-panel]')];
 modeTabs.forEach(tab=>tab.addEventListener('click',()=>{
   const mode=tab.dataset.videoMode;
   modeTabs.forEach(t=>{const active=t===tab;t.classList.toggle('is-active',active);t.setAttribute('aria-selected',active?'true':'false');});
   modePanels.forEach(panel=>panel.hidden=panel.dataset.videoModePanel!==mode);
 }));
 const mhVideo=$('mhVideoFile'),mhAudio=$('mhAudioFile');
 if(mhVideo)mhVideo.addEventListener('change',()=>{const f=mhVideo.files?.[0];if(!f)return;const v=$('mhVideoPreview');v.src=URL.createObjectURL(f);v.hidden=false;$('mhVideoEmpty').hidden=true;v.load();});
 if(mhAudio)mhAudio.addEventListener('change',()=>{const f=mhAudio.files?.[0];if(!f)return;const a=$('mhAudioPreview');a.src=URL.createObjectURL(f);a.hidden=false;$('mhAudioEmpty').hidden=true;a.load();});
 const mhForm=$('magicHourForm');
 if(mhForm)mhForm.addEventListener('submit',async e=>{
   e.preventDefault();if(!mhForm.reportValidity())return;
   const btn=$('mhGenerate'),status=$('mhStatus');btn.disabled=true;btn.textContent='Uploading media…';
   setStatus(status,'PHP is validating and forwarding your video and audio to Magic Hour. Keep this page open until submission is confirmed.');
   $('mhResultVideo').hidden=true;$('mhResultActions').hidden=true;$('mhResultEmpty').hidden=false;
   try{
     const fd=new FormData(mhForm);
     const endpoint=new URL('api/magichour.php',document.baseURI).toString();
     try{
       const lr=await fetch(endpoint+'?limits=1',{credentials:'same-origin',cache:'no-store'});
       const ld=await lr.json();
       if(lr.ok&&ld.ok){
         const vf=mhForm.elements.video.files[0],af=mhForm.elements.audio.files[0];
         if(vf&&ld.videoMaxBytes>0&&vf.size>ld.videoMaxBytes)throw new Error('Source video exceeds this server’s upload limit ('+Math.round(ld.videoMaxBytes/1048576)+' MB). Reduce the file size or increase PHP upload_max_filesize/post_max_size.');
         if(af&&ld.audioMaxBytes>0&&af.size>ld.audioMaxBytes)throw new Error('Replacement audio exceeds this server’s upload limit ('+Math.round(ld.audioMaxBytes/1048576)+' MB). Reduce the file size or increase PHP upload_max_filesize/post_max_size.');
       }
     }catch(limitError){if(limitError.message&&limitError.message.includes('exceeds this server'))throw limitError;}

     const controller=new AbortController();const timeout=setTimeout(()=>controller.abort(),15*60*1000);
     let res,data;
     try{
       res=await fetch(endpoint,{method:'POST',headers,body:fd,credentials:'same-origin',cache:'no-store',signal:controller.signal});
       const raw=await res.text();try{data=JSON.parse(raw)}catch(_){throw new Error('The server returned a non-JSON response (HTTP '+res.status+'). This usually means the hosting upload limit or PHP configuration rejected the media. Check post_max_size, upload_max_filesize and the PHP error log.')}
     }finally{clearTimeout(timeout)}
     if(!res.ok||!data.ok)throw new Error(data.error||('Lip Sync request failed with HTTP '+res.status+'.'));
     setStatus(status,data.duplicate?'This Lip Sync request was already submitted. No additional credits were charged. Checking its status…':`Lip Sync submitted · ${data.creditsCharged} Anonymoux credits charged. Checking provider status…`,'success');
     if(window.crypto&&window.crypto.getRandomValues){const bytes=window.crypto.getRandomValues(new Uint8Array(16));mhForm.elements.request_key.value=Array.from(bytes,b=>b.toString(16).padStart(2,'0')).join('');}
     pollMagicHour(data.jobId);
   }catch(err){
     const message=err&&err.name==='AbortError'?'The upload took too long and was stopped by the browser. Reduce the video/audio size or increase the hosting request timeout.':(err&&err.message==='Failed to fetch'?'The browser could not reach the Lip Sync endpoint. Check HTTPS, the deployed api/magichour.php path, hosting upload limits and server error logs.':(err.message||'Magic Hour submission failed.'));
     setStatus(status,message,'error');
   }
   finally{btn.disabled=false;btn.innerHTML='Generate Lip Sync <span>↗</span>';}
 });
 let mhPollTimer=null;
 async function pollMagicHour(id){
   const box=$('mhJobState'),label=$('mhJobLabel'),detail=$('mhJobDetail');box.hidden=false;
   const names={submitted:'Queued',processing:'Rendering',completed:'Complete',failed:'Failed',expired:'Expired'};
   const poll=async()=>{
     try{
       const pollUrl=new URL('api/magichour.php?id='+encodeURIComponent(id),document.baseURI).toString();
       const res=await fetch(pollUrl,{credentials:'same-origin',cache:'no-store'});
       const raw=await res.text();let d;try{d=JSON.parse(raw)}catch(_){throw new Error('The Lip Sync status endpoint returned an invalid response (HTTP '+res.status+').')}if(!res.ok||!d.ok)throw new Error(d.error||'Could not check Magic Hour status.');
       label.textContent=names[d.status]||d.status;detail.textContent=d.providerStatus?`Magic Hour status: ${d.providerStatus}`:'Waiting for provider status.';
       if(d.status==='completed'&&d.outputUrl){
         const v=$('mhResultVideo');v.src=d.outputUrl;v.hidden=false;$('mhResultEmpty').hidden=true;
         $('mhDownload').href=d.outputUrl+'&download=1';$('mhDownload').setAttribute('download','anonymoux-lipsync.mp4');$('mhResultActions').hidden=false;
         setStatus($('mhStatus'),'Lip Sync completed. The synchronized video is saved in shared Video Edit Studio history.','success');return;
       }
       if(d.status==='failed'||d.status==='expired'){setStatus($('mhStatus'),d.error||'Magic Hour reported a failed job. Any eligible credit refund has been recorded.','error');return;}
       mhPollTimer=setTimeout(poll,8000);
     }catch(err){detail.textContent=err.message;mhPollTimer=setTimeout(poll,15000);}
   };
   if(mhPollTimer)clearTimeout(mhPollTimer);poll();
 }

 let pollTimer=null;
 async function pollVideo(id){
   const box=$('videoJobState'),label=$('videoJobLabel'),detail=$('videoJobDetail');box.hidden=false;
   const names={submitted:'Submitted',processing:'Processing',completed:'Completed',failed:'Failed',expired:'Expired'};
   const poll=async()=>{
     try{
       const res=await fetch('api/video-jobs.php?id='+encodeURIComponent(id),{credentials:'same-origin',cache:'no-store'});const d=await res.json();if(!res.ok||!d.ok)throw new Error(d.error||'Could not check job status.');
       label.textContent=names[d.status]||d.status;detail.textContent=d.status==='completed'?'Provider confirmed completion; output retrieved.':d.status==='failed'?(d.error||'Provider reported failure.'):'Waiting for provider update. No percentage is inferred.';
       if(d.status==='completed'&&d.outputUrl){const v=$('videoResult');v.src=d.outputUrl;v.hidden=false;$('videoDownload').href=d.outputUrl+'&download=1';$('videoDownload').setAttribute('download','anonymous-studio-video.mp4');$('videoResultActions').hidden=false;setStatus($('videoStatus'),'Video edit completed and output saved.','success');return;}
       if(d.status==='failed'){setStatus($('videoStatus'),d.error||'Provider reported failure.','error');return;}
       pollTimer=setTimeout(poll,6000);
     }catch(err){detail.textContent=err.message;pollTimer=setTimeout(poll,12000);}
   };
   if(pollTimer)clearTimeout(pollTimer);poll();
 }
 window.addEventListener('beforeunload',()=>{if(pollTimer)clearTimeout(pollTimer);if(mhPollTimer)clearTimeout(mhPollTimer);});
})();
