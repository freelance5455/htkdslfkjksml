(() => {
  'use strict';
  const cards = [...document.querySelectorAll('[data-history-job][data-poll="1"]')];
  if (!cards.length) return;
  let stopped = false;
  let refreshed = false;
  const terminal = new Set(['completed', 'failed', 'expired']);
  const sleep = (ms) => new Promise((resolve) => window.setTimeout(resolve, ms));
  async function poll(card) {
    const id = card.dataset.historyJob;
    const model = card.dataset.model || '';
    const endpoint = model === 'magic-hour-lip-sync'
      ? `api/magichour.php?id=${encodeURIComponent(id)}`
      : `api/video-jobs.php?id=${encodeURIComponent(id)}`;
    const statusNode = card.querySelector('[data-history-status]');
    const messageNode = card.querySelector('[data-history-message]');
    try {
      const response = await fetch(endpoint, { credentials: 'same-origin', cache: 'no-store', headers: { Accept: 'application/json' } });
      const data = await response.json();
      if (!response.ok || !data || data.ok !== true) throw new Error(data && data.error ? data.error : 'Status update unavailable.');
      const status = String(data.status || card.dataset.status || 'processing').toLowerCase();
      card.dataset.status = status;
      if (statusNode) {
        statusNode.textContent = status.charAt(0).toUpperCase() + status.slice(1);
        statusNode.className = `history-status status-${status}`;
      }
      if (messageNode) messageNode.textContent = data.error || (status === 'completed' ? 'Your result is ready.' : status === 'failed' ? 'The provider could not complete this job.' : 'The provider is still processing this job.');
      if (terminal.has(status)) { card.removeAttribute('data-poll'); return true; }
      return false;
    } catch (error) {
      if (messageNode) messageNode.textContent = 'Status check temporarily unavailable. Your job record is safe; checking again shortly.';
      return false;
    }
  }
  async function cycle() {
    while (!stopped) {
      if (document.visibilityState === 'visible') {
        let finished = false;
        for (const card of cards) {
          if (!card.isConnected || card.dataset.poll !== '1') continue;
          if (await poll(card)) finished = true;
          await sleep(250);
        }
        if (finished && !refreshed) { refreshed = true; window.location.reload(); return; }
      }
      await sleep(9000);
      if (![...document.querySelectorAll('[data-history-job][data-poll="1"]')].length) return;
    }
  }
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') stopped = false; });
  cycle();
})();
