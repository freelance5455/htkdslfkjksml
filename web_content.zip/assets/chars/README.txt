立绘放这里：assets/chars/<角色id>/<表情>.png
