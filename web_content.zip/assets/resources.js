(() => {
  'use strict';
  document.querySelectorAll('[data-insert]').forEach((button) => {
    button.addEventListener('click', () => {
      const editor = document.getElementById('tutorialMarkdownEditor');
      if (!editor) return;
      const token = button.getAttribute('data-insert') || '';
      const start = Number.isInteger(editor.selectionStart) ? editor.selectionStart : editor.value.length;
      const end = Number.isInteger(editor.selectionEnd) ? editor.selectionEnd : start;
      const prefix = start > 0 && editor.value[start - 1] !== '\n' ? '\n' : '';
      const suffix = end < editor.value.length && editor.value[end] !== '\n' ? '\n' : '';
      editor.value = editor.value.slice(0, start) + prefix + token + suffix + editor.value.slice(end);
      const caret = start + prefix.length + token.length;
      editor.focus();
      editor.setSelectionRange(caret, caret);
      editor.dispatchEvent(new Event('input', { bubbles: true }));
    });
  });
})();
