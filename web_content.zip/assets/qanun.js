const app=document.getElementById("app"),PORTAL="index.html",CA=CONST.a,CH=CONST.h,CP=CONST.pre,AMP=Object.fromEntries(CA.map((a,i)=>[a.n,i]));
const cnt=CH.map(()=>0);const anc=k=>{const r=[k];let l=CH[k].l;for(let i=k-1;i>=0&&l>1;i--)if(CH[i].l<l){r.unshift(i);l=CH[i].l}return r};
CA.forEach(a=>anc(a.k).forEach(i=>cnt[i]++));
const IX=CA.map(a=>norm(a.n+" "+a.x)),IP=CP.map(s=>norm(s.t+" "+s.x));let q="";
const st=(k,v)=>{try{if(v===undefined)return JSON.parse(localStorage.getItem(k)||"[]");localStorage.setItem(k,JSON.stringify(v))}catch(e){return[]}};
const chip=n=>AMP[n]!==undefined?`<a class="cp" href="#p${n}">اصل ${fa(n)}</a>`:"";
const hdr=(t,p,b)=>`<div class="nav"><button class="back" id="hb">‹ ${b||"بازگشت"}</button></div><header class="ph">${ROS}<h1 class="grad">${t}</h1><p>${p}</p></header>`;
const paras=x=>x.split("\n").map(l=>`<p>${esc(l).replace(/^([۰-۹]+\s*[-ـ]\s*)/,"<b>$1</b>")}</p>`).join("");
function tree(){let o="",stk=[];const cl=l=>{while(stk.length&&stk[stk.length-1]>=l){o+="</div></details>";stk.pop()}};
CH.forEach((h,i)=>{cl(h.l);o+=`<details class="tn l${h.l}"${h.l===1&&i<1?" open":""}><summary>${h.t} <span class="tag">${fa(cnt[i])} اصل</span></summary><div>${CA.filter(a=>a.k===i).map(a=>chip(a.n)).join("")}`;stk.push(h.l)});cl(0);return o}
function home(){const s=q.trim();let body;
if(s){const nq=norm(s);const hits=[];if(/^\d+$/.test(nq)&&AMP[nq]!==undefined)hits.push(AMP[nq]);IX.forEach((x,i)=>{if(x.includes(nq)&&!hits.includes(i))hits.push(i)});const ph=IP.map((x,i)=>x.includes(nq)?i:-1).filter(i=>i>=0);
body=`<p class="sub">${fa(hits.length+ph.length)} نتیجه</p><div class="res">${ph.map(i=>`<a href="#pre"><b>مقدمه${CP[i].t?" - "+CP[i].t:""}</b></a>`).join("")}${hits.slice(0,40).map(i=>{const a=CA[i],p=norm(a.x),j=p.indexOf(nq);return`<a href="#p${a.n}"><b>اصل ${fa(a.n)}</b><small>${CH[anc(a.k)[0]].t}</small>${esc(j<0?a.x.slice(0,110):a.x.slice(Math.max(0,j-40),j+90))}…</a>`}).join("")}</div>`}
else{const rc=st("qn_rec").filter(n=>AMP[n]!==undefined).slice(0,5),bm=st("qn_bm").filter(n=>AMP[n]!==undefined);
body=`<div class="tools"><a class="pill on" href="#pre">📜 مقدمه‌ی قانون اساسی</a><a class="pill" href="ayin.html">📖 آیین‌نامه داخلی مجلس</a><a class="pill" href="sahn.html">📊 احکام کاربردی صحن</a></div>${bm.length?`<h3>⭐ نشان‌شده‌ها</h3>${bm.map(chip).join("")}`:""}${rc.length?`<h3>🕘 اخیراً دیده‌شده</h3>${rc.map(chip).join("")}`:""}<h3>فهرست فصل‌ها</h3>${tree()}`}
app.innerHTML=`<div class="nav"><a class="pill" href="${PORTAL}">‹ صفحه‌ی اصلی سامانه</a></div><header class="ph">${ROS}<h1 class="grad">قانون اساسی جمهوری اسلامی ایران</h1><p>مقدمه، ۱۴ فصل و ۱۷۷ اصل</p><small style="color:var(--mut)">${CONST.v}</small></header><input id="q" placeholder="جستجو: شماره‌ی اصل (مثلاً ۸۷) یا هر عبارت (مثلاً رأی اعتماد)" value="${esc(q)}" aria-label="جستجو">${body}${foot()}`;
const i=document.getElementById("q");i.oninput=e=>{q=e.target.value;home();const n=document.getElementById("q");n.focus();n.setSelectionRange(q.length,q.length)}}
function preface(){app.innerHTML=hdr("مقدمه‌ی قانون اساسی","متن رسمی","بازگشت به قانون اساسی")+`<div class="box ap" style="text-align:center">${CONST.top.map(x=>`<p><b>${esc(x)}</b></p>`).join("")}</div>${CP.map(s=>`<div class="box ap">${s.t?`<h3>${esc(s.t)}</h3>`:""}${paras(s.x)}</div>`).join("")}${foot()}`;document.getElementById("hb").onclick=()=>go("")}
function section(k){const e=CH.findIndex((h,i)=>i>k&&h.l<=CH[k].l),r=[];for(let i=k;i<(e<0?CH.length:e);i++)r.push(i);
app.innerHTML=hdr(CH[k].t,`${fa(cnt[k])} اصل`,"بازگشت به فهرست")+r.map(i=>`<h3>${CH[i].t}</h3>${CA.filter(a=>a.k===i).map(a=>chip(a.n)).join("")}`).join("")+foot();document.getElementById("hb").onclick=()=>go("")}
function principle(n){const i=AMP[n];if(i===undefined)return home();const a=CA[i],ch=anc(a.k),bm=st("qn_bm").includes(String(n));st("qn_rec",[String(n),...st("qn_rec").filter(x=>x!==String(n))].slice(0,5));
const x=CONST.xl[n]||{a:[],t:[]},ttl=`اصل ${fa(n)}`,ref=`${ttl} قانون اساسی جمهوری اسلامی ایران`,pv_=CA[i-1],nx=CA[i+1];
app.innerHTML=`<div><div class="nav"><button class="back" id="hb">‹ بازگشت</button></div><header class="ph">${ROS}<h1 class="grad">${ttl}</h1><div class="crumb">${ch.map(c=>`<a href="#s${c}">${CH[c].t}</a>`).join(" › ")}</div></header>
<div class="tools" style="justify-content:flex-start"><button class="pill" id="c1">📋 کپی ارجاع</button><button class="pill" id="c2">📄 کپی متن</button><button class="pill" id="bk">${bm?"⭐ نشان‌شده":"☆ نشان‌گذاری"}</button><button class="pill" id="pr">🖨 چاپ</button></div>
<div class="box ap"><small style="color:var(--mut)">متن رسمی</small>${paras(a.x)}</div>
${a.a.length?`<div class="box note"><b>سوابق:</b> ${a.a.map(t=>`<span class="tag">${t}</span>`).join(" ")}</div>`:""}
${a.o.length?`<details class="tn"><summary>متن پیش از بازنگری ۱۳۶۸ (اصل سابق)</summary><div class="ap">${a.o.map(paras).join("<hr>")}</div></details>`:""}
${x.a.length?`<h3>مواد مرتبط در آیین‌نامه داخلی مجلس</h3>${x.a.map(m=>`<a class="cp" href="ayin.html#m${m}">ماده ${fa(m)}</a>`).join("")}`:""}
${x.t.length?`<h3>موضوعات مرتبط در احکام کاربردی صحن</h3>${x.t.map(t=>`<a class="cp t" href="sahn.html#t${t.id}">${t.t}</a>`).join("")}`:""}
${x.a.length||x.t.length?`<p class="sub"><small>پیوندهای میان‌بخشی پیش‌نویس است و نیاز به تأیید دارد.</small></p>`:""}
<div class="box"><b>توضیح ساده:</b> در دست تدوین.</div>
<div class="tools">${pv_?`<a class="pill" href="#p${pv_.n}">› اصل قبل</a>`:""}${nx?`<a class="pill" href="#p${nx.n}">اصل بعد ‹</a>`:""}</div>
<div class="po"><h1>${ref}</h1>${paras(a.x)}<p><small>${CONST.v}</small></p></div></div>${foot()}`;
const $=id=>document.getElementById(id),cpy=(t,b,l)=>navigator.clipboard?navigator.clipboard.writeText(t).then(()=>{b.textContent="✓ کپی شد"},()=>prompt(l,t)):prompt(l,t);
$("hb").onclick=()=>go("s"+ch[ch.length-1]);$("c1").onclick=e=>cpy(ref,e.target,"ارجاع:");$("c2").onclick=e=>cpy(ref+"\n"+a.x,e.target,"متن:");$("pr").onclick=()=>window.print();
$("bk").onclick=()=>{const b=st("qn_bm"),s=String(n);st("qn_bm",b.includes(s)?b.filter(y=>y!==s):[...b,s]);principle(n)}}
function route(){const h=decodeURIComponent(location.hash.slice(1));let m;
if(m=h.match(/^p(\d+)$/))principle(+m[1]);else if(h==="pre")preface();else if((m=h.match(/^s(\d+)$/))&&CH[+m[1]])section(+m[1]);else home();scrollTo(0,0)}
function go(h){if(location.hash.slice(1)===h)route();else location.hash=h}
window.addEventListener("hashchange",route);route();
