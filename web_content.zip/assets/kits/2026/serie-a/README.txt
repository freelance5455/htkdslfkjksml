Diretório reservado para imagens de camisas 2026 com permissão/licença de uso confirmada. Não adicionar imagens sem verificar a licença e registrar a origem no catálogo.
