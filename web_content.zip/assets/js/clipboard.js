/**
 * Name Tools - Clipboard Helper
 */
window.copyToClipboard = async function (text, customMessage = 'Copied to clipboard!') {
  if (!text) return false;
  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
    } else {
      const textArea = document.createElement('textarea');
      textArea.value = text;
      textArea.style.position = 'fixed';
      textArea.style.left = '-999999px';
      textArea.style.top = '-999999px';
      document.body.appendChild(textArea);
      textArea.focus();
      textArea.select();
      document.execCommand('copy');
      textArea.remove();
    }
    if (window.showToast) {
      window.showToast(customMessage, 'success');
    }
    return true;
  } catch (err) {
    console.error('Failed to copy text: ', err);
    if (window.showToast) {
      window.showToast('Failed to copy', 'error');
    }
    return false;
  }
};
