// Safe storage for local HTML files (some Android browsers restrict store on file://)
const store=(()=>{try{const t='__aa_test__';localStorage.setItem(t,'1');localStorage.removeItem(t);return localStorage}catch(e){const mem={};return {getItem:k=>Object.prototype.hasOwnProperty.call(mem,k)?mem[k]:null,setItem:(k,v)=>{mem[k]=String(v)},removeItem:k=>{delete mem[k]}}}})();
const logoData=document.querySelector('.brand img')?.src||''; function applyBrandIdentity(){document.querySelectorAll('.page').forEach(p=>{if(!p.querySelector('.brandPage')){const b=document.createElement('div');b.className='brandPage';b.innerHTML='<img src="'+logoData+'" alt="عالم عنترة"><div><b>عالم عنترة</b><span>هوية المتجر وخدمة موحدة في جميع الصفحات</span></div>';p.prepend(b);}})} applyBrandIdentity();
const cats=[['الأرز','🍚'],['الدقيق','🌾'],['البيض','🥚'],['معلبات','🥫'],['تونه','🐟'],['سمن والزبده','🧈'],['والزيت','🫒'],['القشطة','🥛'],['الخبز والمعجنات','🥐'],['الصوصات','🫙'],['معجون الطماط','🍅'],['المخبز','🥖'],['دجاج مجمد','🍗'],['مجمدات','❄️'],['العصائر','🧃'],['الحليب والزبادي البان','🥛'],['منظفات','🧴']];
const products=[
['أرز أبوكاس 5 كيلو','36.75','الأرز','🍚','كيس'],
['أبو بنت أرز بسمتي سيلا هندي 10 كجم','69.95','الأرز','🍚','كيس'],
['أرز بسمتي أبيض فايف ستار 1 كيلو','7.25','الأرز','🍚','كيس'],
['أرز ابنت الخليج بسمتي مزة كريمي 5 كيلو','30.07','الأرز','🍚','كيس'],
['أرز أبو بنت 1 كجم','9.50','الأرز','🍚','كيس'],
['دقيق فاخر 10 كيلو','21.50','الدقيق','🌾','كيس'],
['دقيق أبيض 1 كيلو','5.75','الدقيق','🌾','كيس'],
['بيض طازج 30 حبة','17.95','البيض','🥚','كرتون'],
['بيض أبيض 15 حبة','9.95','البيض','🥚','كرتون'],
['معلبات مشكلة','8.95','معلبات','🥫','حبة'],
['فاصوليا معلبة 400 جم','4.50','معلبات','🥫','حبة'],
['تونة قطع 170 جم','6.50','تونه','🐟','حبة'],
['تونة خفيفة 185 جم','7.25','تونه','🐟','حبة'],
['سمن نباتي 1 كيلو','18.50','سمن والزبده','🧈','حبة'],
['زبدة 400 جم','15.95','سمن والزبده','🧈','حبة'],
['زيت دوار الشمس 1.8 لتر','12.95','والزيت','🫒','حبة'],
['زيت نباتي 1.5 لتر','11.50','والزيت','🫒','حبة'],
['قشطة 170 جم','4.75','القشطة','🥛','حبة'],
['قشطة 125 جم','3.95','القشطة','🥛','حبة'],
['خبز عربي','2.50','الخبز والمعجنات','🥖','ربطة'],
['معجنات مشكلة','12.95','الخبز والمعجنات','🥐','علبة'],
['فطائر جبن','11.50','الخبز والمعجنات','🥐','علبة'],
['خبز بر 600 جم','4.75','الخبز والمعجنات','🥖','ربطة'],
['صوص طماطم','7.25','الصوصات','🫙','حبة'],
['مايونيز 500 مل','10.95','الصوصات','🫙','حبة'],
['كاتشب 500 جم','8.50','الصوصات','🫙','حبة'],
['معجون طماطم 135 جم','5.75','معجون الطماط','🍅','حبة'],
['معجون طماطم 400 جم','8.95','معجون الطماط','🍅','حبة'],
['خبز صامولي','4.50','المخبز','🥖','كيس'],
['كيك فانيلا','18.95','المخبز','🍰','علبة'],
['دجاج مجمد 1 كجم','15.95','دجاج مجمد','🍗','حبة'],
['دجاج مجمد 2 كجم','28.50','دجاج مجمد','🍗','حبة'],
['خضار مجمدة مشكلة','9.50','مجمدات','❄️','كيس'],
['بطاطس مجمدة 1 كجم','8.95','مجمدات','❄️','كيس'],
['عصير برتقال','9.50','العصائر','🧃','عبوة'],
['عصير تفاح','8.95','العصائر','🧃','عبوة'],
['حليب كامل الدسم','8.95','الحليب والزبادي البان','🥛','عبوة'],
['حليب قليل الدسم','8.50','الحليب والزبادي البان','🥛','عبوة'],
['زبادي طبيعي','5.95','الحليب والزبادي البان','🥛','علبة'],
['زبادي فراولة','6.50','الحليب والزبادي البان','🥛','علبة'],
['منظف متعدد الاستخدام','14.25','منظفات','🧴','عبوة'],
['منظف ملابس 2 لتر','18.95','منظفات','🧴','عبوة'],
['منظف أرضيات','12.50','منظفات','🧴','عبوة']];
let cart=JSON.parse(store.getItem('aa_cart')||'[]');
let orders=JSON.parse(store.getItem('aa_orders')||'[]').filter(o=>Number(o.sub||0)>60);
store.setItem('aa_orders',JSON.stringify(orders));
let users=JSON.parse(store.getItem('aa_users')||'[]');
let user=JSON.parse(store.getItem('aa_user')||'null');
if(user){
  const saved=users.find(u=>u.id===user.id);
  if(saved) user={...saved};
}
let currentCat='';
try{
  if(user && Array.isArray(users) && !users.some(u=>u.id===user.id)){
    users.push({...user});
    store.setItem('aa_users',JSON.stringify(users));
  }
}catch(e){}


function persistUsers(){
  if(!Array.isArray(users)) users=[];
  if(user){
    const i=users.findIndex(u=>u.id===user.id);
    if(i>=0) users[i]={...users[i],...user};
    else users.push({...user});
    store.setItem('aa_users',JSON.stringify(users));
    store.setItem('aa_user',JSON.stringify(user));
  }
}
function saveUserOnly(){persistUsers();}
if(user){
  user.visits=Number(user.visits||0)+1;
  persistUsers();
}
function userOrders(){if(!user)return [];return orders.filter(o=>Number(o.sub||0)>60 && (o.userId===user.id || (!o.userId && ((o.phone&&o.phone===user.phone)||(o.email&&o.email===user.email)))));}
function userStats(){const os=userOrders();const spent=os.reduce((s,o)=>s+Number(o.total||0),0);const points=os.reduce((s,o)=>s+Number(o.points||Math.floor(Number(o.total||0))),0);return {orders:os.length,spent,points};}
function renderDashboard(){updateAccountHeader();const guest=document.getElementById('accountGuest'),member=document.getElementById('accountMember');if(!user){guest.style.display='block';member.style.display='none';return;}guest.style.display='none';member.style.display='block';const st=userStats();document.getElementById('accountName').textContent='مرحبًا '+(user.name||'عميل عالم عنترة');document.getElementById('memberSince').textContent='عضو منذ '+(user.createdAt?new Date(user.createdAt).toLocaleDateString('ar-SA'):'اليوم');document.getElementById('statVisits').textContent=Number(user.visits||1);document.getElementById('statOrders').textContent=st.orders;document.getElementById('statSpent').textContent=money(st.spent);document.getElementById('statPoints').textContent=st.points.toLocaleString('ar-SA');document.getElementById('welcomePoints').textContent=st.points.toLocaleString('ar-SA');document.getElementById('accountDetails').textContent=(user.phone||'')+' • '+(user.email||'');document.getElementById('savedAddressText').textContent=user.address?((user.city?user.city+' — ':'')+user.address+(user.location?' • 📍 موقع GPS محفوظ':'')):'لم يتم حفظ عنوان بعد.';const recent=document.getElementById('accountRecentOrders');recent.innerHTML=st.orders?userOrders().slice(0,4).map(o=>'<div class="orderMini"><span><strong>'+o.id+'</strong><br>'+o.date+'</span><span>'+money(o.total)+'<br><small>'+o.status+'</small></span></div>').join(''):'<div class="empty" style="padding:25px">لا توجد طلبات بعد.</div>';}


// Keep only valid orders for the minimum-order rule.
try{orders=orders.filter(o=>Number(o.sub||0)>60)}catch(e){orders=[]}
const money=n=>Number(n).toFixed(2)+' ر.س';
function save(){
  updateAccountHeader();
  store.setItem('aa_cart',JSON.stringify(cart));
  store.setItem('aa_orders',JSON.stringify(orders));
  if(user) persistUsers();
  else store.removeItem('aa_user');
  updateBadge();
}
function updateBadge(){document.getElementById('cartBadge').textContent=cart.reduce((s,x)=>s+x.qty,0)}
function catHTML(c){return `<div class="cat" onclick="openCategory('${c[0].replace(/'/g,"\'")}')"><div class="icon">${c[1]}</div><b>${c[0]}</b></div>`}
function renderCats(){
const hc=document.getElementById('homeCats'),ac=document.getElementById('allCats');
if(hc) hc.innerHTML=cats.map(catHTML).join('');
if(ac) ac.innerHTML=cats.map(catHTML).join('');
}

function productHTML(p,i){const fav=JSON.parse(store.getItem('aa_favs')||'[]').includes(p[0]);return `<article class="card"><button class="fav ${fav?'on':''}" onclick="toggleFav(event,'${p[0].replace(/'/g,"\'")}')">${fav?'♥':'♡'}</button><div class="productPic">${p[3]}</div><div class="cardBody"><div class="catName">${p[2]}</div><h3>${p[0]}</h3><div class="priceRow"><span class="price">${money(p[1])}</span><span class="unit">/${p[4]}</span></div><button class="addBtn" onclick="addToCart(${i})">أضف إلى السلة</button></div></article>`}
function renderProducts(el,list){document.getElementById(el).innerHTML=list.map((p)=>productHTML(p,products.indexOf(p))).join('')||'<div class="empty">لا توجد منتجات مطابقة.</div>'}
function addToCart(i){const p=products[i],x=cart.find(a=>a.name===p[0]);if(x)x.qty++;else cart.push({name:p[0],price:Number(p[1]),icon:p[3],qty:1,unit:p[4]});save();toast('تمت إضافة المنتج إلى السلة');}
function toggleFav(e,name){e.stopPropagation();let f=JSON.parse(store.getItem('aa_favs')||'[]');f=f.includes(name)?f.filter(x=>x!==name):[...f,name];store.setItem('aa_favs',JSON.stringify(f));renderHome()}
function renderHome(){renderProducts('homeProducts',products);renderProducts('offerProducts',products.filter((_,i)=>[0,3,5,7,10,13,16,20].includes(i)))}
function openAccountOrAuth(){
  if(user){
    showPage('account');
  }else{
    openAuth();
  }
}
function updateAccountHeader(){
  const btn=document.getElementById('accountHeaderBtn');
  const label=document.getElementById('accountHeaderLabel');
  if(!btn||!label)return;
  if(user){
    label.textContent='لوحة العميل';
    btn.title='فتح لوحة تحكم العميل';
  }else{
    label.textContent='تسجيل الدخول';
    btn.title='تسجيل الدخول أو إنشاء حساب';
  }
}
function showPage(id){document.querySelectorAll('.page').forEach(x=>x.classList.remove('active'));document.getElementById(id).classList.add('active');window.scrollTo({top:0,behavior:'smooth'});if(id==='orders')renderOrders();if(id==='account')renderDashboard();}
function openCategory(cat){currentCat=cat;document.getElementById('categoryTitle').textContent=cat;document.getElementById('categorySub').textContent='منتجات قسم '+cat;document.getElementById('catSearch').value='';document.getElementById('sortSelect').value='default';showPage('categoryView');filterCategoryProducts()}
function filterCategoryProducts(){let list=products.filter(p=>p[2]===currentCat);let q=document.getElementById('catSearch').value.trim();if(q)list=list.filter(p=>p[0].includes(q));const s=document.getElementById('sortSelect').value;if(s==='low')list.sort((a,b)=>a[1]-b[1]);if(s==='high')list.sort((a,b)=>b[1]-a[1]);if(s==='name')list.sort((a,b)=>a[0].localeCompare(b[0],'ar'));renderProducts('categoryProducts',list)}
function searchProducts(){const q=document.getElementById('searchInput').value.trim();if(!q){showPage('home');return}currentCat='';document.getElementById('categoryTitle').textContent='نتائج البحث';document.getElementById('categorySub').textContent='نتائج البحث عن: '+q;document.getElementById('catSearch').value=q;showPage('categoryView');let list=products.filter(p=>p[0].includes(q)||p[2].includes(q));renderProducts('categoryProducts',list)}
function openCart(){renderCart();document.getElementById('cartDrawer').classList.add('show')}function closeCart(){document.getElementById('cartDrawer').classList.remove('show')}
function renderCart(){const box=document.getElementById('cartItems'),foot=document.getElementById('cartFooter');if(!cart.length){box.innerHTML='<div class="empty">🛒<h3>السلة فارغة</h3><p>أضف المنتجات التي تريدها ثم عد لإتمام الطلب.</p></div>';foot.innerHTML='';return}box.innerHTML=cart.map((x,i)=>`<div class="cartItem"><div class="cartThumb">${x.icon}</div><div class="cartInfo"><b>${x.name}</b><span>${money(x.price)} / ${x.unit}</span><div class="qty"><button onclick="changeQty(${i},-1)">−</button><b>${x.qty}</b><button onclick="changeQty(${i},1)">+</button><button style="margin-right:auto;border:0;background:none;color:var(--danger)" onclick="removeCart(${i})">حذف</button></div></div><strong>${money(x.price*x.qty)}</strong></div>`).join('');const sub=cart.reduce((s,x)=>s+x.price*x.qty,0),eligible=sub>60,ship=eligible?9:0,remaining=Math.max(0,60.01-sub);foot.innerHTML=`<div class="sum"><span>المجموع الفرعي</span><b>${money(sub)}</b></div><div class="sum"><span>التوصيل</span><b>${eligible?money(ship):'غير متاح'}</b></div>${eligible?'<div class="deliveryReady">🚚 التوصيل مفعل لهذا الطلب — رسوم التوصيل 9 ر.س.</div>':`<div class="cartThreshold">🔒 <strong>إتمام الطلب غير متاح حاليًا</strong><br>يجب أن يكون إجمالي المنتجات في السلة <b>أعلى من 60 ر.س</b> لتفعيل التوصيل وإتمام الطلب.<br>أضف منتجات بقيمة <b>${money(remaining)}</b> أو أكثر لتجاوز الحد الأدنى وإتمام طلبك.</div>`}<div class="sum total"><span>الإجمالي</span><b>${money(sub+ship)}</b></div><button class="primary ${eligible?'':'checkoutDisabled'}" style="width:100%;margin-top:12px" ${eligible?'':'disabled aria-disabled="true"'} onclick="${eligible?'openCheckout()':'showThresholdMessage()'}">${eligible?'إتمام الطلب':'إتمام الطلب — غير متاح'}</button>`}
function showThresholdMessage(){const sub=cart.reduce((s,x)=>s+x.price*x.qty,0),need=Math.max(0,60.01-sub);toast('إتمام الطلب غير متاح. يجب أن يكون إجمالي المنتجات أعلى من 60 ر.س. المتبقي: '+money(need));}
function changeQty(i,d){cart[i].qty+=d;if(cart[i].qty<=0)cart.splice(i,1);save();renderCart()}function removeCart(i){cart.splice(i,1);save();renderCart()}
function openCheckout(){
const sub=cart.reduce((s,x)=>s+x.price*x.qty,0);
if(!cart.length){toast('السلة فارغة');return}
if(!(sub>60)){showThresholdMessage();return}
closeCart();
if(!user){openAuth();toast('أنشئ حسابًا أولًا لحفظ طلبك ومتابعة نقاطك');return}
document.getElementById('coName').value=user.name||'';
document.getElementById('coPhone').value=user.phone||'';
document.getElementById('coCity').value=user.city||'';
window.checkoutLocation=user.location||null;

const oldAddress=(user.address||'').trim();
document.getElementById('coNeighborhood').value='';
document.getElementById('coStreet').value='';
document.getElementById('coNationalAddress').value='';
if(oldAddress){
  document.getElementById('coNationalAddress').value=oldAddress;
}

if(user.location){
  document.querySelector('input[name=locationMode][value=gps]').checked=true;
  selectLocationMode('gps');
}else{
  document.querySelector('input[name=locationMode][value=manual]').checked=true;
  selectLocationMode('manual');
}
document.querySelector('input[name=pay][value=cash]').checked=true;
selectPayment('cash');
renderCheckoutSummary();
document.getElementById('checkoutModal').classList.add('show')
}function closeCheckout(){document.getElementById('checkoutModal').classList.remove('show')}
function selectPayment(type){const card=type==='card';document.getElementById('cardPayment').classList.toggle('show',card);document.getElementById('cashChoice').classList.toggle('active',!card);document.getElementById('cardChoice').classList.toggle('active',card);document.getElementById('paymentStatus').textContent=card?'سيتم تسجيل الطلب كـ «دفع إلكتروني» في النسخة التجريبية بعد التحقق من بيانات البطاقة.':'سيتم تسجيل الطلب كـ «الدفع عند الاستلام» في النسخة التجريبية.';}
function formatCardNumber(el){let v=el.value.replace(/\D/g,'').slice(0,16);el.value=v.replace(/(.{4})/g,'$1 ').trim()}function formatExpiry(el){let v=el.value.replace(/\D/g,'').slice(0,4);el.value=v.length>2?v.slice(0,2)+'/'+v.slice(2):v}
function validateCard(){const name=document.getElementById('cardName').value.trim(),num=document.getElementById('cardNumber').value.replace(/\s/g,''),exp=document.getElementById('cardExpiry').value.trim(),cvv=document.getElementById('cardCvv').value.trim();if(!name||num.length!==16||!/^(0[1-9]|1[0-2])\/\d{2}$/.test(exp)||!/^\d{3,4}$/.test(cvv)){toast('أكمل بيانات البطاقة بشكل صحيح');return false}return true}
function renderCheckoutSummary(){const sub=cart.reduce((s,x)=>s+x.price*x.qty,0),eligible=sub>60,ship=eligible?9:0;const status=document.getElementById('deliveryStatus');if(status){status.className=eligible?'deliveryReady':'deliveryLocked';status.innerHTML=eligible?'<strong>🚚 التوصيل مفعل:</strong> رسوم التوصيل <b>9.00 ر.س</b>.':'<strong>🔒 الطلب غير متاح:</strong> يجب أن يكون إجمالي المنتجات <b>أعلى من 60 ر.س</b> لتفعيل التوصيل وإتمام الطلب.';}document.getElementById('checkoutSummary').innerHTML='<div class="sum" style="margin-top:18px"><span>المجموع</span><b>'+money(sub)+'</b></div><div class="sum"><span>التوصيل</span><b>'+(eligible?money(ship):'غير متاح')+'</b></div><div class="sum total"><span>الإجمالي النهائي</span><b>'+money(sub+(eligible?ship:0))+'</b></div>'}
function placeOrder(){
if(!user){toast('يرجى تسجيل الدخول أولًا');return}
const name=document.getElementById('coName').value.trim();
const phone=document.getElementById('coPhone').value.trim();
const city=document.getElementById('coCity').value.trim();
const notes=document.getElementById('coNotes').value.trim();
const payment=document.querySelector('input[name=pay]:checked')?.value||'cash';
const mode=document.querySelector('input[name=locationMode]:checked')?.value||'manual';
const finalLocation=window.checkoutLocation||null;

if(!name||!phone){toast('أكمل الاسم ورقم الجوال');return}

let finalAddress='';
if(mode==='gps'){
  if(!finalLocation){toast('اختر «تحديد الموقع عبر GPS» ثم اضغط «تحديد موقعي الحالي».');return}
  finalAddress='تم تحديد الموقع عبر GPS: '+finalLocation.lat+', '+finalLocation.lng;
}else{
  const neighborhood=document.getElementById('coNeighborhood').value.trim();
  const street=document.getElementById('coStreet').value.trim();
  const national=document.getElementById('coNationalAddress').value.trim();
  if(!neighborhood&&!street&&!national){
    toast('أدخل الحي أو الشارع أو العنوان الوطني لإكمال الطلب.');
    return
  }
  finalAddress=[neighborhood&&('الحي: '+neighborhood),street&&('الشارع: '+street),national&&('العنوان الوطني: '+national)].filter(Boolean).join(' — ');
}

const sub=cart.reduce((s,x)=>s+x.price*x.qty,0);
if(!(sub>60)){toast('لا يمكن إنشاء الطلب. يجب أن يكون إجمالي المنتجات أعلى من 60 ر.س.');return}
if(payment==='card'&&!validateCard())return;

const ship=9,total=sub+ship;
const finalCity=city;
user.name=name;user.email=user.email||'';user.city=finalCity;user.address=finalAddress;user.location=(mode==='gps'?finalLocation:null);
const earnedPoints=Math.floor(sub),now=Date.now();
const order={id:'AA-'+now.toString().slice(-7),date:new Date(now).toLocaleString('ar-SA'),name,email:user.email||'',city:finalCity,address:finalAddress,notes,total,sub,shipping:ship,payment,points:earnedPoints,userId:user.id,items:cart.map(x=>({name:x.name,price:x.price,icon:x.icon,qty:x.qty,unit:x.unit})),status:'تم استلام الطلب',stage:0,stageStartedAt:now,stages:['تم استلام الطلب','جاري التنفيذ','قيد المراجعة','اكتمل','قيد التوصيل','تم التسليم بنجاح']};
orders.unshift(order);
cart=[];
save();
closeCheckout();
renderDashboard();
showPage('orders');
toast('تم استلام طلبك بنجاح 🎉 رقم الطلب '+order.id);
resumeOrderProgress(order)
}
function resumeOrderProgress(order){if(!order||order.stage>=order.stages.length-1)return;const delay=5000;const elapsed=Date.now()-Number(order.stageStartedAt||Date.now());const wait=Math.max(500,delay-elapsed);clearTimeout(order._timer);order._timer=setTimeout(()=>{const live=orders.find(x=>x.id===order.id);if(!live)return;live.stage=Math.min(Number(live.stage||0)+1,live.stages.length-1);live.status=live.stages[live.stage];live.stageStartedAt=Date.now();save();renderOrders();renderDashboard();if(live.stage<live.stages.length-1){resumeOrderProgress(live)}else{toast('🎉 تم تسليم الطلب بنجاح — '+live.id)}},wait)}
function resumeAllOrderProgress(){userOrders().forEach(resumeOrderProgress)}
function renderOrders(){const box=document.getElementById('ordersList'),os=userOrders();if(!os.length){box.innerHTML='<div class="empty">📦<h3>لا توجد طلبات بعد</h3><p>عند إتمام أول طلب سيظهر هنا رقم الطلب وحالته.</p><button class="primary" onclick="showPage(\'home\')">ابدأ التسوق</button></div>';return}box.innerHTML=os.map(o=>{const stages=o.stages||['تم استلام الطلب','جاري التنفيذ','قيد المراجعة','اكتمل','قيد التوصيل','تم التسليم بنجاح'];const idx=Math.min(Number(o.stage||0),stages.length-1);return `<div class="box" style="margin-bottom:12px"><div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap"><div><b>رقم الطلب: ${o.id}</b><div style="color:var(--muted);font-size:12px;margin-top:5px">${o.date}</div></div><span style="background:#e6f5ee;color:var(--green);padding:7px 11px;border-radius:20px;font-size:12px;font-weight:900">${stages[idx]}</span></div><div class="tracking"><div class="trackingLine">${stages.map((st,i)=>`<div class="trackStep ${i<idx?'done':''} ${i===idx?'current':''}"><div class="trackDot">${i<idx?'✓':i===idx?'●':i+1}</div><span>${st}</span></div>`).join('')}</div><div class="trackingHint">حالة الطلب الحالية: <b>${stages[idx]}</b></div><div class="gpsNote" style="margin-top:8px">⏱️ النسخة التجريبية: تنتقل الحالة تلقائيًا كل 5 ثوانٍ حتى «تم التسليم بنجاح».</div></div><hr style="border:0;border-top:1px solid var(--line);margin:14px 0"><div>${(o.items||[]).map(x=>`<div style="display:flex;justify-content:space-between;margin:7px 0"><span>${x.icon||'🛒'} ${x.name} × ${x.qty}</span><b>${money(x.price*x.qty)}</b></div>`).join('')}</div><div class="sum"><span>التوصيل</span><b>${money(o.shipping||0)}</b></div><div class="sum total"><span>الإجمالي</span><b>${money(o.total)}</b></div><div class="notice" style="margin-top:12px;margin-bottom:0">⭐ نقاط هذه العملية: <b>${Number(o.points||0).toLocaleString('ar-SA')} نقطة</b></div></div>`}).join('');resumeAllOrderProgress()}
function openAuth(){
  document.getElementById('authModal').classList.add('show');
  if(!user){
    authTab('login');
  }else{
    editSavedAddress();
  }
}function closeAuth(){document.getElementById('authModal').classList.remove('show')}function authTab(t){document.getElementById('loginBox').style.display=t==='login'?'block':'none';document.getElementById('regBox').style.display=t==='reg'?'block':'none';document.getElementById('tabLogin').classList.toggle('active',t==='login');document.getElementById('tabReg').classList.toggle('active',t==='reg')}
function focusRegisterAddress(){document.getElementById('regNationalAddress').focus();toast('أدخل الحي أو الشارع أو العنوان الوطني');}
function selectRegisterLocationMode(){ return; }

function selectLocationMode(mode){
  const gps=document.getElementById('gpsLocationPanel');
  const manual=document.getElementById('manualLocationPanel');
  const gpsChoice=document.getElementById('gpsModeChoice');
  const manualChoice=document.getElementById('manualModeChoice');
  if(!gps||!manual)return;
  const isGps=mode==='gps';
  gps.style.display=isGps?'block':'none';
  manual.style.display=isGps?'none':'block';
  gpsChoice.classList.toggle('selected',isGps);
  manualChoice.classList.toggle('selected',!isGps);
  const radio=document.querySelector('input[name=locationMode][value='+mode+']');
  if(radio)radio.checked=true;
  if(!isGps){
    window.checkoutLocation=null;
    const status=document.getElementById('coLocationStatus');
    const map=document.getElementById('coMapPreview');
    if(status)status.textContent='🏠 الإدخال اليدوي مفعل — اكتب الحي أو الشارع أو العنوان الوطني.';
    if(map){map.classList.remove('show');map.innerHTML='';}
  }
}
async function reverseGeocode(lat,lng){
  try{
    const url='https://api.bigdatacloud.net/data/reverse-geocode-client?latitude='+encodeURIComponent(lat)+'&longitude='+encodeURIComponent(lng)+'&localityLanguage=ar';
    const r=await fetch(url,{headers:{'Accept':'application/json'}});
    if(!r.ok) throw new Error('geocode');
    const d=await r.json();
    const parts=[d.locality,d.city,d.principalSubdivision,d.countryName].filter(Boolean);
    return {address:parts.join('، '),city:d.city||d.locality||d.principalSubdivision||''};
  }catch(e){return {address:'',city:''};}
}
async function requestLocation(context){
  if(!navigator.geolocation){toast('المتصفح لا يدعم تحديد الموقع GPS');return;}
  toast('يرجى السماح بالوصول إلى موقعك لتحديد مكان التوصيل');
  navigator.geolocation.getCurrentPosition(async pos=>{
    const lat=Number(pos.coords.latitude.toFixed(6)),lng=Number(pos.coords.longitude.toFixed(6));
    const loc={lat,lng};
    const geo=await reverseGeocode(lat,lng);
    const readable=geo.address||('الموقع الحالي GPS: '+lat+', '+lng);
    if(context==='register'){
      toast('تسجيل الحساب يعتمد على العنوان اليدوي. يمكنك استخدام GPS لاحقًا عند إتمام الطلب إذا رغبت.');
      return;
    }else{
      selectLocationMode('gps');
      window.checkoutLocation=loc;
      const addressEl=document.getElementById('coAddress'),cityEl=document.getElementById('coCity');
      if(!addressEl.value.trim() || addressEl.value.includes('الموقع الحالي GPS')) addressEl.value=readable;
      if(!cityEl.value.trim() && geo.city) cityEl.value=geo.city;
      document.getElementById('coLocationStatus').innerHTML='✅ تم تحديد الموقع وجلب العنوان التقريبي تلقائيًا. يمكنك فتح خرائط Google للتأكد ثم الرجوع وإكمال الطلب.';
      document.getElementById('coMapPreview').classList.add('show');
      document.getElementById('coMapPreview').innerHTML='<iframe loading="lazy" src="https://www.google.com/maps?q='+lat+','+lng+'&output=embed"></iframe>';
    }
    toast('تم تحديد موقعك بنجاح 📍');
  },err=>{
    let msg='تعذر تحديد الموقع. يمكنك إدخال العنوان الوطني يدويًا.';
    if(err&&err.code===1) msg='لم يتم السماح بالموقع. فعّل إذن الموقع للمتصفح ثم حاول مرة أخرى، أو أدخل العنوان الوطني.';
    else if(err&&err.code===2) msg='تعذر الوصول إلى GPS. تأكد من تشغيل الموقع ثم حاول مرة أخرى.';
    else if(err&&err.code===3) msg='انتهت مهلة تحديد الموقع. حاول مرة أخرى أو أدخل العنوان الوطني.';
    toast(msg+' يمكنك إكمال الطلب مباشرةً بكتابة العنوان الوطني.');
  },{enableHighAccuracy:true,timeout:15000,maximumAge:30000});
}
function openMapsLocation(){
  const loc=window.checkoutLocation||user?.location;
  const url=loc?'https://www.google.com/maps?q='+encodeURIComponent(loc.lat+','+loc.lng):'https://www.google.com/maps';
  window.open(url,'_blank','noopener');
  toast(loc?'تم فتح موقعك في خرائط Google — الرجوع للصفحة وإكمال الطلب اختياري.':'تم فتح خرائط Google بشكل اختياري. يمكنك الرجوع وكتابة العنوان الوطني وإكمال الطلب.');
}
function getRegisterAddress(){
  const neighborhood=document.getElementById('regNeighborhood').value.trim();
  const street=document.getElementById('regStreet').value.trim();
  const national=document.getElementById('regNationalAddress').value.trim();
  const city=document.getElementById('regCity').value.trim();
  if(!neighborhood&&!street&&!national&&!city)return null;
  if(!neighborhood&&!street&&!national){return null;}
  return {
    mode:'manual',
    address:[neighborhood&&('الحي: '+neighborhood),street&&('الشارع: '+street),national&&('العنوان الوطني: '+national)].filter(Boolean).join(' — '),
    location:null
  };
}

function handleRegisterSubmit(){
  if(user){ updateRegisteredAccount(); } else { register(); }
}
function register(){
  const name=document.getElementById('regName').value.trim();
  const email=document.getElementById('regEmail').value.trim().toLowerCase();
  const pass=document.getElementById('regPass').value;
  const pass2=document.getElementById('regPass2').value;
  const city=document.getElementById('regCity').value.trim();
  if(!name||!email||!pass||!pass2){toast('أكمل الاسم والبريد الإلكتروني وكلمة المرور');return}
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){toast('أدخل بريدًا إلكترونيًا صحيحًا');return}
  if(pass.length<6){toast('كلمة المرور يجب أن تكون 6 أحرف أو أرقام على الأقل');return}
  if(pass!==pass2){toast('كلمتا المرور غير متطابقتين');return}
  const duplicate=users.find(u=>u.email && u.email.toLowerCase()===email);
  if(duplicate){toast('هذا البريد الإلكتروني مسجل مسبقًا. استخدم تسجيل الدخول بالبريد وكلمة المرور.');authTab('login');document.getElementById('loginEmail').value=email;return}
  const loc=getRegisterAddress();
  if(!loc){toast('أدخل الحي أو الشارع أو العنوان الوطني لإكمال التسجيل');return}
  user={
    id:'U-'+Date.now().toString(36),
    name,email,password:pass,city,
    address:loc.address,location:null,
    locationMode:'manual',
    createdAt:new Date().toISOString(),
    visits:1
  };
  users.push({...user});
  store.setItem('aa_users',JSON.stringify(users));
  store.setItem('aa_user',JSON.stringify(user));
  closeAuth();
  renderDashboard();
  showPage('account');
  toast('تم إنشاء الحساب بنجاح 🎉 يمكنك تسجيل الدخول لاحقًا بنفس البريد الإلكتروني وكلمة المرور');
}
function login(){
  const email=document.getElementById('loginEmail').value.trim().toLowerCase();
  const pass=document.getElementById('loginPass').value;
  if(!email||!pass){toast('أدخل البريد الإلكتروني وكلمة المرور');return}
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){toast('أدخل بريدًا إلكترونيًا صحيحًا');return}
  const existing=users.find(u=>u.email && u.email.toLowerCase()===email);
  if(!existing){
    toast('لا يوجد حساب بهذا البريد. اختر «إنشاء حساب» أولًا.');
    return
  }
  if(existing.password!==pass){
    toast('كلمة المرور غير صحيحة');
    return
  }
  user={...existing,visits:Number(existing.visits||0)+1};
  store.setItem('aa_user',JSON.stringify(user));
  const idx=users.findIndex(u=>u.id===user.id);
  if(idx>=0)users[idx]={...users[idx],...user};
  store.setItem('aa_users',JSON.stringify(users));
  closeAuth();
  renderDashboard();
  showPage('account');
  toast('مرحبًا بك '+(user.name||'في عالم عنترة')+' 👋');
}
function editSavedAddress(){
  if(!user){openAuth();return}
  document.getElementById('regName').value=user.name||'';
    document.getElementById('regEmail').value=user.email||'';
  document.getElementById('regCity').value=user.city||'';
  document.getElementById('regPass').value=user.password||'';
  document.getElementById('regPass2').value=user.password||'';
  selectRegisterLocationMode('manual');
  const a=user.address||'';
  const parts=a.split(' — ');
  const getPart=(label)=>{const x=parts.find(v=>v.startsWith(label));return x?x.slice(label.length).trim():''};
  document.getElementById('regNeighborhood').value=getPart('الحي:');
  document.getElementById('regStreet').value=getPart('الشارع:');
  document.getElementById('regNationalAddress').value=getPart('العنوان الوطني:') || (a && !a.includes('الحي:') && !a.includes('الشارع:') ? a : '');
  document.getElementById('regCity').value=user.city||'';
  authTab('reg');
  openAuth();
  toast('عدّل بياناتك أو عنوانك ثم احفظ الحساب');
}
function updateRegisteredAccount(){
  /* زر التسجيل في وضع التعديل يحفظ التغييرات بدل إنشاء حساب جديد */
  if(!user)return false;
  const name=document.getElementById('regName').value.trim();
  const email=document.getElementById('regEmail').value.trim();
  const pass=document.getElementById('regPass').value;
  const pass2=document.getElementById('regPass2').value;
  const city=document.getElementById('regCity').value.trim();
  if(!name||!email||!pass||!pass2){toast('أكمل بيانات الحساب');return true}
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){toast('أدخل بريدًا إلكترونيًا صحيحًا');return true}
  if(email!==String(user.email||'').toLowerCase() && users.some(u=>(u.email||'').toLowerCase()===email && u.id!==user.id)){toast('البريد الإلكتروني مستخدم لحساب آخر');return true}
  if(pass.length<6){toast('كلمة المرور يجب أن تكون 6 أحرف أو أرقام على الأقل');return true}
  if(pass!==pass2){toast('كلمتا المرور غير متطابقتين');return true}
  const loc=getRegisterAddress();
  if(!loc){toast('اختر GPS وحدد الموقع أو أدخل الحي/الشارع/العنوان الوطني');return true}
  user={...user,name,email,password:pass,city,address:loc.address,location:loc.location,locationMode:loc.mode};
  persistUsers();
  closeAuth();
  renderDashboard();
  toast('تم حفظ بيانات حسابك بنجاح');
  return true
}
function logoutUser(){
  if(!user)return;
  persistUsers();
  user=null;
  store.removeItem('aa_user');
  renderDashboard();
  updateAccountHeader();
  showPage('home');
  toast('تم تسجيل الخروج. حسابك وطلباتك محفوظة ويمكنك تسجيل الدخول لاحقًا.');
}
function socialNotice(name){toast('سيتم ربط حساب '+name+' الرسمي من إعدادات المتجر قبل الإطلاق.')}
function toast(t){const x=document.getElementById('toast'),tx=document.getElementById('toastText');if(tx)tx.textContent=t;else x.textContent=t;x.classList.remove('show');void x.offsetWidth;x.classList.add('show')}
document.getElementById('year').textContent=new Date().getFullYear();renderCats();renderHome();updateBadge();renderDashboard();

(function(){
  function initAntraAnnouncement(){
    const slides=[...document.querySelectorAll('.antra-announcement-slide')];
    if(!slides.length)return;
    let i=0;
    setInterval(()=>{
      const cur=slides[i];
      cur.classList.remove('active');
      cur.classList.add('exit-left');
      i=(i+1)%slides.length;
      const next=slides[i];
      next.classList.remove('exit-left');
      next.classList.add('active');
      setTimeout(()=>cur.classList.remove('exit-left'),750);
    },4000);
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initAntraAnnouncement);
  else initAntraAnnouncement();
})();
// Optional PWA cache. Android WebView/file:// may not support Service Workers; ignore safely.
try { if ("serviceWorker" in navigator && location.protocol !== "file:") { navigator.serviceWorker.register("./sw.js").catch(() => {}); } } catch (e) {}
