/* LAMSA store — catalog rendering, search & filters, product page, cart, wishlist, WhatsApp ordering, i18n */
(() => {
'use strict';
const C = window.CATALOG, WA = '213550856709';
const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
const RM = matchMedia('(prefers-reduced-motion: reduce)').matches;
const LS = {
  get(k, d) { try { const v = JSON.parse(localStorage.getItem('lamsa:' + k)); return v == null ? d : v; } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem('lamsa:' + k, JSON.stringify(v)); } catch (e) {} }
};
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const P = id => C.products.find(p => p.id === id);
const CAT = id => C.categories.find(c => c.id === id);

/* ---------- strings ---------- */
const U = {
  ar: {
    ask: 'اسأل عن السعر', cur: 'دج', all: 'الكل', results: n => n + (n === 1 ? ' منتج' : ' منتجات'), items: n => n + ' منتجات',
    addCart: 'أضف إلى السلة', quick: 'إضافة سريعة', orderWa: 'اطلب عبر واتساب', orderNow: 'اطلب الآن', view: 'عرض المنتج',
    added: 'أُضيف إلى السلة', viewCart: 'عرض السلة', wishAdd: 'أُضيف إلى المفضلة', wishRm: 'أُزيل من المفضلة',
    wish: 'المفضلة', cart: 'السلة', menu: 'القائمة', colour: 'اللون / الموديل', size: 'المقاس', qty: 'الكمية', sizeAsk: 'غير متأكد',
    sizeNote: 'المقاسات حسب التوفر — نؤكدها معك عبر واتساب قبل الإرسال.', colours: n => n + (n === 1 ? ' لون' : ' ألوان'),
    real: 'صورة حقيقية', vid: 'فيديو حقيقي', ill: 'رسم توضيحي',
    realNote: 'صورة حقيقية للقطعة المتوفرة في المحل. نُظّفت الخلفية بأداة ذكاء اصطناعي دون تعديل القطعة.',
    vidNote: 'فيديو حقيقي مصوَّر داخل المحل.',
    illNote: 'رسم توضيحي فقط — ليس صورة حقيقية. هذا اللون متوفر، واطلب صورته الحقيقية عبر واتساب.',
    illFig: 'رسم توضيحي — ليس صورة حقيقية',
    details: 'التفاصيل', delivery: 'التوصيل والدفع', deliveryText: 'توصيل لجميع الولايات. الدفع عند الاستلام أو عبر بريدي موب / CCP. نؤكد معك التوفر والمقاس وتكلفة التوصيل عبر واتساب قبل إرسال الطلب.',
    share: 'مشاركة', copied: 'تم نسخ الرابط', related: 'قد يعجبك أيضًا', home: 'الرئيسية', close: 'إغلاق', prev: 'السابق', next: 'التالي',
    cartEmpty: 'سلتك فارغة', cartEmptyP: 'أضف منتجاتك المفضلة ثم أرسل الطلب كاملًا عبر واتساب.', wishEmpty: 'لا توجد منتجات في المفضلة', wishEmptyP: 'اضغط على القلب في أي منتج لحفظه هنا.',
    shop: 'تسوّق الآن', subtotal: 'المجموع', plusAsk: 'منتجات أخرى: السعر عند الاستفسار', noShip: 'تكلفة التوصيل تُحدَّد عند تأكيد الطلب.',
    yourInfo: 'معلوماتك (اختياري — لتسريع الطلب)', name: 'الاسم', city: 'الولاية / المدينة', phone: 'الهاتف', address: 'العنوان', payM: 'طريقة الدفع',
    cod: 'الدفع عند الاستلام', ccp: 'بريدي موب / CCP', note: 'ملاحظة', send: 'أرسل الطلب عبر واتساب', remove: 'حذف', toCart: 'أضف للسلة', moveAll: 'أضف الكل إلى السلة',
    searchAll: q => 'عرض كل النتائج لـ «' + q + '»', noMatch: 'لا توجد نتائج — جرّب كلمة أخرى', soon: 'قريبًا',
    msgHi: 'مرحبًا LAMSA 👋، أريد طلب:', msgAsk: 'مرحبًا LAMSA 👋، أريد الاستفسار عن:', msgRef: 'المرجع', msgLink: 'الرابط', msgPrice: 'السعر', msgTotal: 'المجموع التقديري',
    msgCust: 'معلوماتي:', msgEnd: 'هل المنتج متوفر؟ شكرًا.', newTag: 'جديد'
  },
  fr: {
    ask: 'Prix sur demande', cur: 'DA', all: 'Tout', results: n => n + ' produit' + (n > 1 ? 's' : ''), items: n => n + ' produits',
    addCart: 'Ajouter au panier', quick: 'Ajout rapide', orderWa: 'Commander sur WhatsApp', orderNow: 'Commander', view: 'Voir le produit',
    added: 'Ajouté au panier', viewCart: 'Voir le panier', wishAdd: 'Ajouté aux favoris', wishRm: 'Retiré des favoris',
    wish: 'Favoris', cart: 'Panier', menu: 'Menu', colour: 'Couleur / modèle', size: 'Taille', qty: 'Quantité', sizeAsk: 'Je ne sais pas',
    sizeNote: 'Tailles selon disponibilité — confirmées avec vous sur WhatsApp avant l’envoi.', colours: n => n + ' couleur' + (n > 1 ? 's' : ''),
    real: 'Photo réelle', vid: 'Vidéo réelle', ill: 'Illustration',
    realNote: 'Photo réelle de l’article disponible en boutique. Fond nettoyé par IA, article non modifié.',
    vidNote: 'Vidéo réelle filmée en boutique.',
    illNote: 'Illustration uniquement — pas une vraie photo. Cette couleur est disponible ; demandez la photo réelle sur WhatsApp.',
    illFig: 'Illustration — pas une vraie photo',
    details: 'Détails', delivery: 'Livraison & paiement', deliveryText: 'Livraison dans toutes les wilayas. Paiement à la livraison ou via BaridiMob / CCP. Nous confirmons disponibilité, taille et frais de livraison sur WhatsApp avant l’envoi.',
    share: 'Partager', copied: 'Lien copié', related: 'Vous aimerez aussi', home: 'Accueil', close: 'Fermer', prev: 'Précédent', next: 'Suivant',
    cartEmpty: 'Votre panier est vide', cartEmptyP: 'Ajoutez vos articles puis envoyez la commande complète sur WhatsApp.', wishEmpty: 'Aucun favori', wishEmptyP: 'Touchez le cœur d’un produit pour l’enregistrer ici.',
    shop: 'Découvrir', subtotal: 'Sous-total', plusAsk: 'Autres articles : prix sur demande', noShip: 'Frais de livraison précisés à la confirmation.',
    yourInfo: 'Vos informations (facultatif — pour aller plus vite)', name: 'Nom', city: 'Wilaya / ville', phone: 'Téléphone', address: 'Adresse', payM: 'Mode de paiement',
    cod: 'Paiement à la livraison', ccp: 'BaridiMob / CCP', note: 'Remarque', send: 'Envoyer la commande sur WhatsApp', remove: 'Retirer', toCart: 'Au panier', moveAll: 'Tout ajouter au panier',
    searchAll: q => 'Voir tous les résultats pour « ' + q + ' »', noMatch: 'Aucun résultat — essayez un autre mot', soon: 'Bientôt',
    msgHi: 'Bonjour LAMSA 👋, je souhaite commander :', msgAsk: 'Bonjour LAMSA 👋, je voudrais me renseigner sur :', msgRef: 'Réf.', msgLink: 'Lien', msgPrice: 'Prix', msgTotal: 'Total estimé',
    msgCust: 'Mes informations :', msgEnd: 'L’article est-il disponible ? Merci.', newTag: 'NOUVEAU'
  },
  en: {
    ask: 'Ask for price', cur: 'DA', all: 'All', results: n => n + ' product' + (n === 1 ? '' : 's'), items: n => n + ' products',
    addCart: 'Add to bag', quick: 'Quick add', orderWa: 'Order on WhatsApp', orderNow: 'Order now', view: 'View product',
    added: 'Added to bag', viewCart: 'View bag', wishAdd: 'Saved to wishlist', wishRm: 'Removed from wishlist',
    wish: 'Wishlist', cart: 'Bag', menu: 'Menu', colour: 'Colour / model', size: 'Size', qty: 'Quantity', sizeAsk: 'Not sure',
    sizeNote: 'Sizes subject to availability — we confirm with you on WhatsApp before shipping.', colours: n => n + ' colour' + (n === 1 ? '' : 's'),
    real: 'Real photo', vid: 'Real video', ill: 'Illustration',
    realNote: 'Real photo of the item available in our shop. Background cleaned with AI; the garment itself is unchanged.',
    vidNote: 'Real video filmed in our shop.',
    illNote: 'Illustration only — not a real photo. This colour is available; ask for the real photo on WhatsApp.',
    illFig: 'Illustration — not a real photo',
    details: 'Details', delivery: 'Delivery & payment', deliveryText: 'Delivery to all wilayas. Cash on delivery or BaridiMob / CCP. We confirm availability, size and delivery cost with you on WhatsApp before shipping.',
    share: 'Share', copied: 'Link copied', related: 'You may also like', home: 'Home', close: 'Close', prev: 'Previous', next: 'Next',
    cartEmpty: 'Your bag is empty', cartEmptyP: 'Add your favourite pieces, then send the complete order on WhatsApp.', wishEmpty: 'Your wishlist is empty', wishEmptyP: 'Tap the heart on any product to save it here.',
    shop: 'Shop now', subtotal: 'Subtotal', plusAsk: 'Other items: price on request', noShip: 'Delivery cost is confirmed with your order.',
    yourInfo: 'Your details (optional — speeds up your order)', name: 'Name', city: 'Wilaya / city', phone: 'Phone', address: 'Address', payM: 'Payment method',
    cod: 'Cash on delivery', ccp: 'BaridiMob / CCP', note: 'Note', send: 'Send order on WhatsApp', remove: 'Remove', toCart: 'Add to bag', moveAll: 'Add all to bag',
    searchAll: q => 'See all results for “' + q + '”', noMatch: 'No results — try another word', soon: 'Coming soon',
    msgHi: 'Hello LAMSA 👋, I would like to order:', msgAsk: 'Hello LAMSA 👋, I would like to ask about:', msgRef: 'Ref', msgLink: 'Link', msgPrice: 'Price', msgTotal: 'Estimated total',
    msgCust: 'My details:', msgEnd: 'Is it available? Thank you.', newTag: 'NEW'
  }
};
/* static page text (Arabic is read from the HTML itself) */
const S = {
  fr: { skip: 'Aller aux produits', top: 'Bienvenue chez LAMSA — tout ce que vous aimez en une seule touche', top2: 'Paiement à la livraison · Livraison dans toutes les wilayas', nHome: 'Accueil', nCats: 'Catégories', nProducts: 'Produits', nPay: 'Paiement', nAbout: 'À propos', nContact: 'Contact', searchPh: 'Rechercher une veste, un sweat, une couleur…', search: 'Rechercher', menu: 'Menu', wish: 'Favoris', cart: 'Panier', heroAlt: 'Veste en fausse fourrure à capuche — noire',
    kicker: 'Découvrez l’univers LAMSA', h1: 'Tout ce que vous aimez...<br>en une seule touche', intro: 'Une sélection variée qui allie élégance et praticité. Découvrez nos produits, choisissez ce qui vous plaît et commandez facilement sur WhatsApp.', explore: 'Découvrir les produits', reach: 'Nous contacter', badgeReal: 'Photo réelle', badgeVid: 'Vidéo réelle', badgeIll: 'Illustration',
    trust1: 'Livraison 58 wilayas — paiement à la livraison', trust2: 'Commande facile sur WhatsApp', trust3: 'Conseil avant confirmation', trust4: 'Vraies photos de nos articles',
    catKicker: 'Achetez par catégorie', catTitle: 'Les catégories LAMSA', catSub: 'Trouvez ce qui correspond à votre style', soonTitle: 'Bientôt disponibles',
    prodKicker: 'Notre sélection', productTitle: 'Produits sélectionnés', productSub: 'Vraies photos d’articles disponibles en boutique. Choisissez couleur et taille, puis confirmez la disponibilité sur WhatsApp.',
    fColor: 'Couleur', fPriced: 'Avec prix affiché', sortBy: 'Trier :', sFeat: 'Sélection', sNew: 'Nouveautés', sPrice: 'Prix croissant', sName: 'Nom', clear: 'Effacer les filtres',
    emptyH: 'Aucun résultat', emptyP: 'Essayez un autre mot ou effacez les filtres. Vous pouvez aussi nous demander n’importe quel article sur WhatsApp.', askWa: 'Demander sur WhatsApp',
    legTitle: 'À propos des photos', legReal: 'Photo réelle de l’article disponible en boutique. Seul le fond a été nettoyé par une IA ; l’article n’a pas été modifié.', legVid: 'Vidéo filmée en boutique, sans retouche.', legIll: 'Dessin simplifié d’une couleur disponible sans photo pour l’instant — pas une vraie photo. Demandez la photo réelle sur WhatsApp.',
    looksKicker: 'Inspiration LAMSA', looksTitle: 'Composez votre look', look1h: 'Un look d’hiver complet', look1p: 'Doudoune avec sweat ou tricot — chaleur et élégance au quotidien.', look1c: 'Voir les vestes', look2h: 'Un cadeau avec une touche spéciale', look2p: 'Choisissez une pièce, nous vous aidons pour la taille et la couleur.', look2c: 'Voir la veste fourrure',
    payKicker: 'Payez en toute simplicité', payTitle: 'Modes de paiement', paySub: 'Choisissez le mode qui vous convient lors de la confirmation sur WhatsApp', pay1tag: 'Le plus choisi', pay1h: 'Paiement à la livraison', pay1p: 'Payez en espèces au livreur à la réception de votre commande.', pay1l1: 'Aucun paiement à l’avance', pay1l2: 'Vérifiez votre commande avant de payer', pay2h: 'BaridiMob / Virement CCP', pay2p: 'Transférez le montant via l’application BaridiMob ou sur un compte CCP.', pay2l1: 'Nous vous envoyons le numéro de compte (RIP / CCP) sur WhatsApp', pay2l2: 'Envoyez-nous la photo du reçu pour confirmer la commande',
    step1: 'Choisissez l’article et ajoutez-le au panier, ou écrivez-nous directement', step2: 'Envoyez la commande sur WhatsApp et indiquez le paiement', step3: 'Nous confirmons disponibilité et taille, puis expédions',
    aboutKicker: 'Notre histoire', aboutTitle: 'Une touche, plus de choix', aboutText: 'LAMSA est une boutique multi-catégories qui rassemble une sélection variée dans une expérience simple et claire. Nous donnons des informations exactes sur nos produits et vous aidons avant la confirmation de la commande.',
    contactTitle: 'Vous cherchez un produit précis ?', contactText: 'Contactez-nous pour vérifier sa disponibilité et son prix.', footTag: 'Tout ce que vous aimez en une seule touche', rights: 'Tous droits réservés', bSearch: 'Recherche', bWish: 'Favoris', bCart: 'Panier' },
  en: { skip: 'Skip to products', top: 'Welcome to LAMSA — everything you love in one touch', top2: 'Cash on delivery · Delivery to every wilaya', nHome: 'Home', nCats: 'Categories', nProducts: 'Products', nPay: 'Payment', nAbout: 'About', nContact: 'Contact', searchPh: 'Search jackets, hoodies, colours…', search: 'Search', menu: 'Menu', wish: 'Wishlist', cart: 'Bag', heroAlt: 'Hooded faux-fur jacket — black',
    kicker: 'Discover the LAMSA world', h1: 'Everything you love...<br>in one touch', intro: 'A varied selection combining style and practicality. Explore our products, pick what suits you and order easily on WhatsApp.', explore: 'Explore products', reach: 'Contact us', badgeReal: 'Real photo', badgeVid: 'Real video', badgeIll: 'Illustration',
    trust1: 'Delivery to all 58 wilayas — cash on delivery', trust2: 'Easy ordering on WhatsApp', trust3: 'Help before you confirm', trust4: 'Real photos of our items',
    catKicker: 'Shop by category', catTitle: 'LAMSA Categories', catSub: 'Find what fits your style and needs', soonTitle: 'Coming soon',
    prodKicker: 'Our selection', productTitle: 'Selected products', productSub: 'Real photos of pieces available in our shop. Pick a colour and size, then confirm availability on WhatsApp.',
    fColor: 'Colour', fPriced: 'Price shown only', sortBy: 'Sort:', sFeat: 'Featured', sNew: 'Newest', sPrice: 'Price: low to high', sName: 'Name', clear: 'Clear filters',
    emptyH: 'No matching products', emptyP: 'Try another word or clear the filters. You can also ask us about any item on WhatsApp.', askWa: 'Ask us on WhatsApp',
    legTitle: 'About our product images', legReal: 'Actual photo of the item in our shop. Only the background was cleaned with an AI tool; the garment itself was not altered.', legVid: 'Video filmed in our shop, unedited.', legIll: 'Simple drawing of an available colour that has no photo yet — not a real photo. Ask for the real photo on WhatsApp.',
    looksKicker: 'LAMSA inspiration', looksTitle: 'Style your look', look1h: 'A complete winter look', look1p: 'A padded jacket with a hoodie or knit — warm and polished every day.', look1c: 'Discover jackets', look2h: 'A gift with a special touch', look2p: 'Pick a piece and let us help with the right size and colour.', look2c: 'See the faux-fur jacket',
    payKicker: 'Pay your way', payTitle: 'Payment methods', paySub: 'Choose the option that suits you when confirming your order on WhatsApp', pay1tag: 'Most popular', pay1h: 'Cash on delivery', pay1p: 'Pay in cash to the courier when you receive your order.', pay1l1: 'No upfront payment', pay1l2: 'Check your order before paying', pay2h: 'BaridiMob / CCP transfer', pay2p: 'Transfer the amount via the BaridiMob app or to a CCP account.', pay2l1: 'We send you the account number (RIP / CCP) on WhatsApp', pay2l2: 'Send us a photo of the transfer receipt to confirm your order',
    step1: 'Pick a product and add it to your bag, or message us directly', step2: 'Send the order on WhatsApp and choose how to pay', step3: 'We confirm availability and size, then ship your order',
    aboutKicker: 'Our story', aboutTitle: 'One touch, more choices', aboutText: 'LAMSA is a multi-category store bringing together a varied selection in a simple, clear shopping experience. We give accurate product information and help you before you confirm your order.',
    contactTitle: 'Looking for something specific?', contactText: 'Contact us to ask about availability and price.', footTag: 'Everything you love in one touch', rights: 'All rights reserved', bSearch: 'Search', bWish: 'Wishlist', bCart: 'Bag' }
};
const PR = {
  fr: { tag: 'Tout ce que vous aimez... en une seule touche', new1: 'Nouvelle', new2: 'saison', newSub: 'Vestes, sweats à capuche, pulls et tricots aux couleurs choisies', spark: 'NEW<br>NOUVEAU', c0: 'Doudoune d’hiver', c1: 'Blouson bomber léger', c2: 'Sweat zippé à capuche', c3: 'Sweat rayé col rond', c4: 'Chemise imprimée', h4: 'Plein de couleurs...<br><em>une seule touche</em>', p4: 'Choisissez votre couleur et votre modèle, commandez en une minute', tricot: 'Tricot coton', price: '3 800 DA', h5: 'Commandez<br>sur WhatsApp', p5: 'Paiement à la livraison · BaridiMob / CCP', wa: 'WhatsApp · Commander', shop: 'Voir les produits', shopNow: 'Acheter ↓', label: 'Vidéo promotionnelle LAMSA', play: 'Pause / lecture' },
  en: { tag: 'Everything you love... in one touch', new1: 'New', new2: 'season', newSub: 'Jackets, hoodies, sweatshirts and knitwear in hand-picked colours', spark: 'NEW<br>IN', c0: 'Padded winter jacket', c1: 'Lightweight bomber', c2: 'Zip-up hoodie', c3: 'Striped crew-neck sweatshirt', c4: 'Long-sleeve printed shirt', h4: 'So many colours...<br><em>one touch</em>', p4: 'Pick your colour and style, order in a minute', tricot: 'Cotton knit sweater', price: '3 800 DA', h5: 'Order now<br>on WhatsApp', p5: 'Cash on delivery · BaridiMob / CCP', wa: 'WhatsApp · Order now', shop: 'Explore products', shopNow: 'Shop now ↓', label: 'LAMSA promotional video', play: 'Pause / play' }
};
/* capture Arabic originals from the markup */
S.ar = {}; PR.ar = {};
$$('[data-i]').forEach(el => { S.ar[el.dataset.i] = S.ar[el.dataset.i] ?? el.innerHTML; });
$$('[data-ip]').forEach(el => { S.ar[el.dataset.ip] = el.getAttribute('placeholder'); });
$$('[data-ia]').forEach(el => { S.ar[el.dataset.ia] = S.ar[el.dataset.ia] ?? (el.getAttribute('aria-label') || el.getAttribute('alt')); });
const promo = $('#promo');
if (promo) { $$('[data-pr]', promo).forEach(el => PR.ar[el.dataset.pr] = el.innerHTML); PR.ar.label = promo.getAttribute('aria-label'); const pb = $('.pr-play', promo); if (pb) PR.ar.play = pb.getAttribute('aria-label'); }

/* ---------- state ---------- */
let lang = LS.get('lang', 'ar'); if (!U[lang]) lang = 'ar';
const t = () => U[lang];
let cart = LS.get('cart', []).filter(it => P(it.id) && P(it.id).variants[it.v]);
let wish = LS.get('wish', []).filter(id => P(id));
let cust = LS.get('cust', {});
const F = { q: '', cat: 'all', colors: new Set(), priced: false, sort: 'featured' };
const cardVar = {}; // product id -> selected variant index on its card

/* ---------- helpers ---------- */
const fmt = n => lang === 'en' ? n.toLocaleString('en-US') + ' DA' : String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + ' ' + t().cur;
const priceHTML = p => p.price ? `<span class="price">${fmt(p.price)}</span>` : `<span class="price ask">${t().ask}</span>`;
const img = (src, w) => /^https?:\/\//i.test(src || '') ? src : String(src || '').replace(/^\//, '');
const srcset = src => [360, 560, 900].map(w => img(src, w) + ' ' + w + 'w').join(',');
const badge = type => type === 'illus' ? `<span class="mbadge ill"><svg><use href="#i-pen"/></svg>${t().ill}</span>` : type === 'video' ? `<span class="mbadge vid"><svg><use href="#i-play"/></svg>${t().vid}</span>` : `<span class="mbadge real"><svg><use href="#i-cam"/></svg>${t().real}</span>`;
const HOODIE = '<path d="M38 14q12-8 24 0l20 10 12 30-12 5-6-14v45H24V45l-6 14-12-5 12-30z" fill="currentColor"/><path d="M38 14q12 14 24 0" fill="none" stroke="#fff6" stroke-width="2"/><path d="M36 70h28v12H36z" fill="#0002"/>';
function media(p, v, { sizes = '(max-width:720px) 50vw,(max-width:1100px) 33vw,300px', cls = '', lazy = true, controls = false } = {}) {
  const alt = esc(p.name[lang] + ' — ' + v.name[lang]);
  if (v.type === 'illus') return `<div class="fig ${cls}" role="img" aria-label="${alt} (${esc(t().ill)})" style="color:${v.color}"><svg viewBox="0 0 100 100" aria-hidden="true">${HOODIE}</svg><em>${t().illFig}</em></div>`;
  if (v.type === 'video') return `<video class="${cls}" muted loop playsinline ${controls ? 'controls autoplay' : 'data-auto'} preload="none" poster="${img(v.poster, 560)}" data-src="${v.src}" aria-label="${alt}"></video>`;
  return `<img class="${cls}" src="${img(v.src, 560)}" srcset="${srcset(v.src)}" sizes="${sizes}" data-o="${v.src}" alt="${alt}" width="900" height="1205" ${lazy ? 'loading="lazy"' : ''} decoding="async">`;
}
const thumb = (p, v) => v.type === 'illus' ? media(p, v) : `<img src="${img(v.type === 'video' ? v.poster : v.src, 200)}" data-o="${v.type === 'video' ? v.poster : v.src}" alt="" loading="lazy" decoding="async">`;
const link = (id, v) => location.origin + location.pathname + '#product/' + id + (v ? '/' + v : '');
const waURL = text => 'https://wa.me/' + WA + '?text=' + encodeURIComponent(text);
// fall back to the original file when the image CDN is unavailable (e.g. plain local preview)
document.addEventListener('error', e => { const el = e.target; if (el.tagName === 'IMG' && el.dataset.o && el.src.includes('/.netlify/images')) { el.removeAttribute('srcset'); el.src = el.dataset.o; } if (el.tagName === 'VIDEO' && el.poster.includes('/.netlify/images')) el.poster = el.poster.replace(/.*url=([^&]+).*/, (m, u) => decodeURIComponent(u)); }, true);

function toast(msg, action) {
  const el = $('#toast'); el.innerHTML = '<span>' + esc(msg) + '</span>' + (action ? `<button type="button">${esc(action.label)}</button>` : '');
  if (action) el.querySelector('button').onclick = () => { el.classList.remove('on'); action.fn(); };
  el.classList.add('on'); clearTimeout(toast.t); toast.t = setTimeout(() => el.classList.remove('on'), 3200);
}

/* ---------- search ---------- */
const norm = s => String(s).toLowerCase().normalize('NFD').replace(/[̀-ًͯ-ٰٟـ]/g, '').replace(/[أإآ]/g, 'ا').replace(/ة/g, 'ه').replace(/ى/g, 'ي').replace(/[’'`]/g, '');
const IDX = {};
C.products.forEach(p => {
  const c = CAT(p.cat);
  IDX[p.id] = norm([...Object.values(p.name), ...Object.values(p.desc), ...Object.values(c.name), p.kw, ...p.variants.flatMap(v => [...Object.values(v.name), ...v.fam.flatMap(f => Object.values(C.colors[f].name))])].join(' '));
});
const match = (p, q) => { const n = norm(q).trim(); return !n || n.split(/\s+/).every(w => IDX[p.id].includes(w)); };

/* ---------- reveal on scroll ---------- */
const io = 'IntersectionObserver' in window && !RM ? new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } }), { rootMargin: '0px 0px -8% 0px' }) : null;
const reveal = root => $$('.rv:not(.in)', root).forEach((el, k) => { if (!io) { el.classList.add('in'); return; } if (el.classList.contains('pc')) el.style.setProperty('--d', (k % 4) * 0.07 + 's'); io.observe(el); });
// autoplay muted card videos only while visible
const vio = 'IntersectionObserver' in window ? new IntersectionObserver(es => es.forEach(e => { const v = e.target; if (e.isIntersecting) { if (!v.src) v.src = v.dataset.src; if (!RM) v.play().catch(() => {}); } else v.pause(); }), { threshold: .3 }) : null;
const watchVideos = root => $$('video[data-auto]', root).forEach(v => vio ? vio.observe(v) : (v.src = v.dataset.src));

/* ---------- categories ---------- */
function renderCats() {
  $('#catGrid').innerHTML = C.categories.map(c => {
    const n = C.products.filter(p => p.cat === c.id).length;
    return `<a class="cat rv" href="#products" data-cat="${c.id}"><img src="${img(c.cover, 560)}" srcset="${srcset(c.cover)}" sizes="(max-width:900px) 46vw, 300px" data-o="${c.cover}" alt="" width="900" height="1205" loading="lazy" decoding="async"><span class="cat-t"><span><b>${esc(c.name[lang])}</b><small>${t().items(n)}</small></span><span class="go"><svg><use href="#i-chev"/></svg></span></span></a>`;
  }).join('');
  $('#soonList').innerHTML = C.soon.map(s => `<span><svg><use href="#i-${s.icon === 'home' ? 'house' : s.icon}"/></svg>${esc(s.name[lang])}</span>`).join('');
  reveal($('#catGrid'));
}

/* ---------- filters ---------- */
function renderFilters() {
  const count = id => id === 'all' ? C.products.length : C.products.filter(p => p.cat === id).length;
  $('#catChips').innerHTML = [{ id: 'all', name: { [lang]: t().all } }, ...C.categories].map(c => `<button class="chip" type="button" role="tab" data-cat="${c.id}" aria-selected="${F.cat === c.id}">${esc(c.name[lang])}<small>${count(c.id)}</small></button>`).join('');
  const fams = [...new Set(C.products.flatMap(p => p.variants.flatMap(v => v.fam)))];
  $('#colorFilter').innerHTML = fams.map(f => `<button type="button" data-col="${f}" aria-pressed="${F.colors.has(f)}" style="background:${C.colors[f].sw}" title="${esc(C.colors[f].name[lang])}" aria-label="${esc(C.colors[f].name[lang])}"></button>`).join('');
}
function filtered() {
  let list = C.products.filter(p => (F.cat === 'all' || p.cat === F.cat) && (!F.priced || p.price) && (!F.colors.size || p.variants.some(v => v.fam.some(f => F.colors.has(f)))) && match(p, F.q));
  if (F.sort === 'new') list.sort((a, b) => b.added - a.added);
  else if (F.sort === 'price') list.sort((a, b) => (a.price ?? 1e12) - (b.price ?? 1e12));
  else if (F.sort === 'name') list.sort((a, b) => a.name[lang].localeCompare(b.name[lang], lang));
  return list;
}
// when a colour filter is on, show the matching variant first on each card
const firstVar = p => { if (F.colors.size) { const k = p.variants.findIndex(v => v.fam.some(f => F.colors.has(f))); if (k >= 0) return k; } return cardVar[p.id] || 0; };

/* ---------- product card ---------- */
const newest = Math.max(...C.products.map(p => p.added));
function card(p, { rv = true } = {}) {
  const k = firstVar(p), v = p.variants[k], alt = p.variants.find((x, j) => j !== k && x.type === 'photo');
  const sw = p.variants.length > 1 ? `<span class="sw">${p.variants.map((x, j) => `<button type="button" data-sw="${j}" aria-pressed="${j === k}" style="background:${x.sw}" aria-label="${esc(x.name[lang])}" title="${esc(x.name[lang])}"></button>`).join('')}</span>` : '';
  const wished = wish.includes(p.id);
  return `<article class="pc${rv ? ' rv' : ''}" data-id="${p.id}" data-v="${k}">
<a class="pc-media" href="#product/${p.id}/${k}" aria-label="${esc(p.name[lang])}">${media(p, v)}${alt && v.type !== 'video' ? media(p, alt, { cls: 'alt' }) : ''}${p.added === newest ? `<span class="pc-tag">${t().newTag}</span>` : ''}${badge(v.type)}${p.variants.length > 1 ? `<span class="pc-dots" aria-hidden="true">${p.variants.map((x, j) => `<i class="${j === k ? 'on' : ''}"></i>`).join('')}</span>` : ''}</a>
<button class="pc-wish" type="button" data-wish="${p.id}" aria-pressed="${wished}" aria-label="${esc(t().wish)}"><svg><use href="#i-heart"/></svg></button>
<button class="pc-quick" type="button" data-quick="${p.id}"><svg><use href="#i-plus"/></svg>${t().quick}</button>
<div class="pc-info"><span class="pc-cat">${esc(CAT(p.cat).name[lang])}</span><h3 class="pc-name"><a href="#product/${p.id}/${k}">${esc(p.name[lang])}</a></h3><span class="pc-var">${esc(v.name[lang])}</span><div class="pc-row">${priceHTML(p)}${sw}</div><a class="pc-wa" href="${waURL(itemMsg(p, k, '', 1, true))}" target="_blank" rel="noopener" data-wa="${p.id}"><svg><use href="#i-wa"/></svg>${t().orderWa}</a></div></article>`;
}
function setCardVar(el, k) {
  const p = P(el.dataset.id), n = p.variants.length; k = (k + n) % n; cardVar[p.id] = k; el.dataset.v = k;
  const v = p.variants[k], m = $('.pc-media', el);
  $$('img:not(.alt),.fig:not(.alt),video', m).forEach(x => x.remove());
  m.insertAdjacentHTML('afterbegin', media(p, v)); $('.mbadge', m).outerHTML = badge(v.type);
  m.href = '#product/' + p.id + '/' + k; $('.pc-name a', el).href = m.href;
  $$('.pc-dots i', m).forEach((d, j) => d.classList.toggle('on', j === k));
  $$('[data-sw]', el).forEach((b, j) => b.setAttribute('aria-pressed', j === k));
  $('.pc-var', el).textContent = v.name[lang];
  $('.pc-wa', el).href = waURL(itemMsg(p, k, '', 1, true));
}
function renderGrid() {
  const list = filtered();
  $('#grid').innerHTML = list.map(p => card(p)).join('');
  $('#empty').hidden = list.length > 0;
  $('#resCount').textContent = t().results(list.length);
  const active = F.q || F.cat !== 'all' || F.colors.size || F.priced;
  $('#clearF').hidden = !active;
  $$('#catChips .chip').forEach(c => c.setAttribute('aria-selected', c.dataset.cat === F.cat));
  $$('#colorFilter button').forEach(b => b.setAttribute('aria-pressed', F.colors.has(b.dataset.col)));
  reveal($('#grid')); watchVideos($('#grid'));
}
function clearFilters() { F.q = ''; F.cat = 'all'; F.colors.clear(); F.priced = false; $('#q').value = ''; $('#fPriced').checked = false; renderGrid(); }

/* grid & related-products interactions (event delegation) */
function cardEvents(root) {
  root.addEventListener('click', e => {
    const sw = e.target.closest('[data-sw]'); if (sw) { setCardVar(sw.closest('.pc'), +sw.dataset.sw); return; }
    const w = e.target.closest('[data-wish]'); if (w) { toggleWish(w.dataset.wish, w); return; }
    const q = e.target.closest('[data-quick]'); if (q) { const el = q.closest('.pc'); addToCart(q.dataset.quick, +el.dataset.v, '', 1); return; }
  });
  let x0 = null, y0 = null;
  root.addEventListener('touchstart', e => { if (e.target.closest('.pc-media')) { x0 = e.touches[0].clientX; y0 = e.touches[0].clientY; } }, { passive: true });
  root.addEventListener('touchend', e => {
    if (x0 === null) return; const m = e.target.closest('.pc-media'); const dx = e.changedTouches[0].clientX - x0, dy = e.changedTouches[0].clientY - y0; x0 = null;
    if (!m || Math.abs(dx) < 35 || Math.abs(dy) > Math.abs(dx)) return;
    const el = m.closest('.pc'); if (P(el.dataset.id).variants.length < 2) return;
    e.preventDefault(); setCardVar(el, +el.dataset.v + ((dx < 0) !== (document.dir === 'rtl') ? 1 : -1));
    m.dataset.swiped = '1'; setTimeout(() => delete m.dataset.swiped, 400);
  });
  root.addEventListener('click', e => { const m = e.target.closest('.pc-media'); if (m && m.dataset.swiped) e.preventDefault(); }, true);
}

/* ---------- WhatsApp messages ---------- */
function itemLines(p, v, size, qty, i) {
  const T = t(), va = p.variants[v], L = [];
  L.push((i ? i + '. ' : '• ') + p.name[lang]);
  L.push('   ' + T.colour + ': ' + va.name[lang] + (va.type === 'illus' ? ' (' + T.ill + ')' : ''));
  L.push('   ' + T.size + ': ' + (size || T.sizeAsk));
  L.push('   ' + T.qty + ': ' + qty);
  L.push('   ' + T.msgPrice + ': ' + (p.price ? fmt(p.price) + (qty > 1 ? ' × ' + qty + ' = ' + fmt(p.price * qty) : '') : T.ask));
  L.push('   ' + T.msgRef + ': ' + p.id.toUpperCase() + '-' + (v + 1));
  L.push('   ' + T.msgLink + ': ' + link(p.id, v));
  return L;
}
function itemMsg(p, v, size, qty, ask) { return [ask ? t().msgAsk : t().msgHi, '', ...itemLines(p, v, size, qty), '', t().msgEnd].join('\n'); }
function cartMsg() {
  const T = t(), L = [T.msgHi, ''];
  let total = 0, unknown = 0;
  cart.forEach((it, k) => { const p = P(it.id); L.push(...itemLines(p, it.v, it.size, it.qty, k + 1), ''); if (p.price) total += p.price * it.qty; else unknown++; });
  if (total) L.push(T.msgTotal + ': ' + fmt(total) + (unknown ? ' (+ ' + T.plusAsk + ')' : ''));
  const c = cust, info = [[T.name, c.name], [T.phone, c.phone], [T.city, c.city], [T.address, c.address], [T.payM, c.pay ? T[c.pay] : ''], [T.note, c.note]].filter(x => x[1]);
  if (info.length) L.push('', T.msgCust, ...info.map(x => '   ' + x[0] + ': ' + x[1]));
  return L.join('\n');
}

/* ---------- cart & wishlist ---------- */
function saveCart() { LS.set('cart', cart); counts(); }
function counts(bump) {
  const nc = cart.reduce((s, x) => s + x.qty, 0);
  $$('[data-cnt=cart]').forEach(b => { b.textContent = nc; b.hidden = !nc; if (bump === 'cart') { b.classList.remove('bump'); void b.offsetWidth; b.classList.add('bump'); } });
  $$('[data-cnt=wish]').forEach(b => { b.textContent = wish.length; b.hidden = !wish.length; if (bump === 'wish') { b.classList.remove('bump'); void b.offsetWidth; b.classList.add('bump'); } });
}
function addToCart(id, v, size, qty) {
  const ex = cart.find(x => x.id === id && x.v === v && x.size === size);
  if (ex) ex.qty = Math.min(20, ex.qty + qty); else cart.push({ id, v, size, qty });
  saveCart(); counts('cart'); toast(t().added + ' — ' + P(id).name[lang], { label: t().viewCart, fn: () => openDrawer('cart') });
  if (drawer.open) renderDrawer();
}
function toggleWish(id, btn) {
  const on = !wish.includes(id);
  wish = on ? [...wish, id] : wish.filter(x => x !== id); LS.set('wish', wish); counts('wish');
  $$(`[data-wish="${id}"]`).forEach(b => { b.setAttribute('aria-pressed', on); b.classList.remove('pop'); void b.offsetWidth; if (on) b.classList.add('pop'); });
  toast(on ? t().wishAdd : t().wishRm);
  if (drawer.open && drawerMode === 'wish') renderDrawer();
}

/* ---------- drawer (cart / wishlist / menu) ---------- */
const drawer = $('#drawer'); let drawerMode = 'cart';
function openDrawer(mode) { drawerMode = mode; renderDrawer(); if (!drawer.open) drawer.showModal(); }
function renderDrawer() {
  const T = t(), m = drawerMode, box = $('#drIn');
  if (m === 'menu') {
    box.innerHTML = `<div class="dr-h"><h2>LAMSA360 <small>لمسة 360</small></h2><button class="xbtn" type="button" data-close aria-label="${T.close}"><svg><use href="#i-x"/></svg></button></div><div class="dr-body"><nav class="menu-links">${$$('.links a').map(a => `<a href="${a.getAttribute('href')}" data-close>${a.innerHTML}<svg><use href="#i-chev"/></svg></a>`).join('')}</nav><div class="menu-cats">${C.categories.map(c => `<a href="#products" data-cat="${c.id}" data-close><img src="${img(c.cover, 360)}" data-o="${c.cover}" alt="" loading="lazy"><span>${esc(c.name[lang])}</span></a>`).join('')}</div></div><div class="dr-foot"><a class="btn waBtn" href="https://wa.me/${WA}" target="_blank" rel="noopener"><svg><use href="#i-wa"/></svg>WhatsApp · <span dir="ltr">+213 550 856 709</span></a></div>`;
    return;
  }
  const nc = cart.reduce((s, x) => s + x.qty, 0);
  let html = `<div class="dr-h"><h2>${m === 'cart' ? T.cart : T.wish}</h2><button class="xbtn" type="button" data-close aria-label="${T.close}"><svg><use href="#i-x"/></svg></button></div>
<div class="dr-tabs" role="tablist"><button type="button" role="tab" data-tab="cart" aria-selected="${m === 'cart'}">${T.cart} (${nc})</button><button type="button" role="tab" data-tab="wish" aria-selected="${m === 'wish'}">${T.wish} (${wish.length})</button></div><div class="dr-body">`;
  if (m === 'cart') {
    if (!cart.length) html += `<div class="dr-empty"><svg><use href="#i-bag"/></svg><h3>${T.cartEmpty}</h3><p>${T.cartEmptyP}</p><a class="btn dark" href="#products" data-close>${T.shop}</a></div></div>`;
    else {
      html += '<ul style="list-style:none;margin:0;padding:0">' + cart.map((it, k) => { const p = P(it.id), v = p.variants[it.v]; return `<li class="cl" data-k="${k}"><a class="cl-img" href="#product/${p.id}/${it.v}" data-close>${thumb(p, v)}</a><div><h4>${esc(p.name[lang])}</h4><div class="cl-meta">${esc(v.name[lang])}${v.type === 'illus' ? ' · ' + T.ill : ''}</div><div class="cl-row"><select class="cl-size" data-size aria-label="${T.size}"><option value="">${T.size}: ${T.sizeAsk}</option>${C.sizes.map(s => `<option ${s === it.size ? 'selected' : ''}>${s}</option>`).join('')}</select><span class="qty sm"><button type="button" data-dq="-1" aria-label="-"><svg><use href="#i-minus"/></svg></button><output>${it.qty}</output><button type="button" data-dq="1" aria-label="+"><svg><use href="#i-plus"/></svg></button></span></div><div class="cl-row" style="margin-top:6px">${p.price ? `<span class="price">${fmt(p.price * it.qty)}</span>` : `<span class="price ask">${T.ask}</span>`}<button class="cl-rm" type="button" data-rm><svg><use href="#i-trash"/></svg>${T.remove}</button></div></div></li>`; }).join('') + '</ul>';
      const c = cust;
      html += `<form class="co" id="co"><h3>${T.yourInfo}</h3><div class="two"><label>${T.name}<input name="name" autocomplete="name" value="${esc(c.name || '')}"></label><label>${T.phone}<input name="phone" type="tel" autocomplete="tel" inputmode="tel" value="${esc(c.phone || '')}"></label></div><label>${T.city}<input name="city" autocomplete="address-level1" value="${esc(c.city || '')}"></label><label>${T.address}<input name="address" autocomplete="street-address" value="${esc(c.address || '')}"></label><label>${T.payM}<select name="pay"><option value="cod" ${c.pay !== 'ccp' ? 'selected' : ''}>${T.cod}</option><option value="ccp" ${c.pay === 'ccp' ? 'selected' : ''}>${T.ccp}</option></select></label><label>${T.note}<textarea name="note" rows="2">${esc(c.note || '')}</textarea></label></form></div>`;
      const total = cart.reduce((s, x) => s + (P(x.id).price || 0) * x.qty, 0), unknown = cart.some(x => !P(x.id).price);
      html += `<div class="dr-foot"><div class="sum"><span>${T.subtotal}</span><span>${total ? fmt(total) : T.ask}</span></div><p class="sum-note">${total && unknown ? T.plusAsk + ' · ' : ''}${T.noShip}</p><a class="btn waBtn" id="sendWA" href="#" target="_blank" rel="noopener"><svg><use href="#i-wa"/></svg>${T.send}</a></div>`;
    }
  } else {
    if (!wish.length) html += `<div class="dr-empty"><svg><use href="#i-heart"/></svg><h3>${T.wishEmpty}</h3><p>${T.wishEmptyP}</p><a class="btn dark" href="#products" data-close>${T.shop}</a></div></div>`;
    else html += '<ul style="list-style:none;margin:0;padding:0">' + wish.map(id => { const p = P(id), k = cardVar[id] || 0, v = p.variants[k]; return `<li class="cl" data-id="${id}"><a class="cl-img" href="#product/${id}/${k}" data-close>${thumb(p, v)}</a><div><h4>${esc(p.name[lang])}</h4><div class="cl-meta">${t().colours(p.variants.length)}</div><div class="cl-row">${priceHTML(p)}</div><div class="cl-row" style="margin-top:8px"><button class="btn dark" type="button" data-w2c>${T.toCart}</button><button class="cl-rm" type="button" data-wrm><svg><use href="#i-trash"/></svg>${T.remove}</button></div></div></li>`; }).join('') + `</ul></div><div class="dr-foot"><button class="btn line" type="button" data-wall>${T.moveAll}</button></div>`;
  }
  box.innerHTML = html;
  const send = $('#sendWA'); if (send) send.href = waURL(cartMsg());
}
drawer.addEventListener('click', e => {
  if (e.target === drawer) { drawer.close(); return; }
  const tab = e.target.closest('[data-tab]'); if (tab) { drawerMode = tab.dataset.tab; renderDrawer(); return; }
  const li = e.target.closest('.cl');
  if (e.target.closest('[data-dq]') && li) { const it = cart[+li.dataset.k]; it.qty = Math.max(1, Math.min(20, it.qty + +e.target.closest('[data-dq]').dataset.dq)); saveCart(); renderDrawer(); return; }
  if (e.target.closest('[data-rm]') && li) { cart.splice(+li.dataset.k, 1); saveCart(); renderDrawer(); return; }
  if (e.target.closest('[data-w2c]') && li) { addToCart(li.dataset.id, cardVar[li.dataset.id] || 0, '', 1); return; }
  if (e.target.closest('[data-wrm]') && li) { toggleWish(li.dataset.id); return; }
  if (e.target.closest('[data-wall]')) { wish.forEach(id => { if (!cart.some(x => x.id === id)) cart.push({ id, v: cardVar[id] || 0, size: '', qty: 1 }); }); saveCart(); counts('cart'); drawerMode = 'cart'; renderDrawer(); return; }
  const cat = e.target.closest('[data-cat]'); if (cat) { F.cat = cat.dataset.cat; renderGrid(); }
  if (e.target.closest('[data-close]')) drawer.close();
});
drawer.addEventListener('change', e => {
  if (e.target.matches('[data-size]')) { cart[+e.target.closest('.cl').dataset.k].size = e.target.value; saveCart(); }
  if (e.target.closest('#co')) syncCust();
  const s = $('#sendWA'); if (s) s.href = waURL(cartMsg());
});
drawer.addEventListener('input', e => { if (e.target.closest('#co')) { syncCust(); const s = $('#sendWA'); if (s) s.href = waURL(cartMsg()); } });
// Save the same WhatsApp cart as an online order in Supabase. WhatsApp still opens normally.
drawer.addEventListener('click', e => {
  if (!e.target.closest('#sendWA')) return;
  if (!cust.name || !cust.phone) {
    toast(lang === 'ar' ? 'أدخل الاسم ورقم الهاتف لتسجيل الطلب في الموقع؛ يمكنك متابعة الطلب عبر واتساب.' : lang === 'fr' ? 'Ajoutez votre nom et téléphone pour enregistrer la commande.' : 'Add your name and phone to save the order online.');
    return;
  }
  const payload = {
    customer_name: cust.name,
    phone: cust.phone,
    wilaya: cust.city || '',
    address: cust.address || '',
    notes: [cust.pay ? 'Payment: ' + cust.pay : '', cust.note || ''].filter(Boolean).join(' | '),
    website: '',
    items: cart.map(it => {
      const p = P(it.id), v = p && p.variants[it.v];
      return { product_id: it.id, quantity: it.qty, variant_name: v ? v.name.ar : '', size: it.size || '' };
    })
  };
  fetch(window.LAMSA_CONFIG.url + '/functions/v1/create-order', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'apikey': window.LAMSA_CONFIG.publishableKey },
    body: JSON.stringify(payload),
    keepalive: true
  }).then(r => r.json().then(d => ({ok:r.ok,data:d}))).then(result => {
    if (!result.ok || !result.data.ok) throw new Error(result.data.error || 'Order save failed');
    LS.set('lastOrderId', result.data.order_id);
    toast(lang === 'ar' ? 'تم تسجيل طلبك رقم ' + result.data.order_id.slice(0,8) + ' — أكمل التأكيد عبر واتساب.' : lang === 'fr' ? 'Commande enregistrée. Confirmez sur WhatsApp.' : 'Order saved. Complete confirmation on WhatsApp.');
  }).catch(() => toast(lang === 'ar' ? 'تعذر تسجيل الطلب بالموقع؛ أكمل طلبك عبر واتساب.' : lang === 'fr' ? 'Enregistrement impossible. Continuez sur WhatsApp.' : 'Could not save online; continue on WhatsApp.'));
});
function syncCust() { const f = $('#co'); if (!f) return; cust = Object.fromEntries(new FormData(f)); Object.keys(cust).forEach(k => cust[k] = String(cust[k]).trim()); LS.set('cust', cust); }

/* ---------- product page ---------- */
const pd = $('#pd'); let cur = null, fromApp = false;
function openProduct(id, v, push) {
  const p = P(id); if (!p) return;
  cur = { id, v: Math.min(Math.max(+v || 0, 0), p.variants.length - 1), size: '', qty: 1 };
  renderPD();
  if (!pd.open) { pd.showModal(); $('#pdIn').scrollTop = 0; }
  document.title = p.name[lang] + ' — LAMSA360 | لمسة 360';
  if (push) fromApp = true;
}
function renderPD() {
  const p = P(cur.id), T = t(), v = p.variants[cur.v], c = CAT(p.cat), wished = wish.includes(p.id);
  const note = v.type === 'illus' ? `<p class="pd-note ill"><svg><use href="#i-pen"/></svg>${T.illNote}</p>` : `<p class="pd-note"><svg><use href="#i-${v.type === 'video' ? 'play' : 'cam'}"/></svg>${v.type === 'video' ? T.vidNote : T.realNote}</p>`;
  const rel = C.products.filter(x => x.id !== p.id).sort((a, b) => (b.cat === p.cat) - (a.cat === p.cat)).slice(0, 4);
  $('#pdIn').innerHTML = `<button class="xbtn" type="button" data-pclose aria-label="${T.close}"><svg><use href="#i-x"/></svg></button>
<nav class="pd-crumb" aria-label="breadcrumb"><button type="button" data-pclose>${T.home}</button>›<button type="button" data-pcat="${c.id}">${esc(c.name[lang])}</button>›<span>${esc(p.name[lang])}</span></nav>
<div class="pd-main"><div class="pd-gal"><div class="pd-stage" id="pdStage">${media(p, v, { sizes: '(max-width:900px) 92vw, 560px', lazy: false, controls: true })}${badge(v.type)}${p.variants.length > 1 ? `<div class="pd-arrows"><button type="button" class="prv" data-step="-1" aria-label="${T.prev}"><svg><use href="#i-chev"/></svg></button><button type="button" class="nxt" data-step="1" aria-label="${T.next}"><svg><use href="#i-chev"/></svg></button></div>` : ''}</div>
${p.variants.length > 1 ? `<div class="pd-thumbs">${p.variants.map((x, j) => `<button type="button" data-pv="${j}" aria-pressed="${j === cur.v}" aria-label="${esc(x.name[lang])}">${thumb(p, x)}<i class="${x.type === 'illus' ? 'ill' : ''}"><svg><use href="#i-${x.type === 'illus' ? 'pen' : 'cam'}"/></svg></i></button>`).join('')}</div>` : ''}${note}</div>
<div class="pd-info"><span class="pd-cat">${esc(c.name[lang])}</span><h1 id="pdTitle">${esc(p.name[lang])}</h1><div class="pd-price">${priceHTML(p)}<small>${T.noShip}</small></div><p class="pd-desc">${esc(p.desc[lang])}</p>
<div><div class="pd-lbl">${T.colour}<span>${esc(v.name[lang])}</span></div><div class="pd-vars">${p.variants.map((x, j) => `<button type="button" data-pv="${j}" aria-pressed="${j === cur.v}"><i style="background:${x.sw}"></i>${esc(x.name[lang])}${x.type === 'illus' ? ' ✎' : ''}</button>`).join('')}</div></div>
<div><div class="pd-lbl">${T.size}<span>${cur.size || T.sizeAsk}</span></div><div class="pd-sizes">${C.sizes.map(s => `<button type="button" data-ps="${s}" aria-pressed="${cur.size === s}">${s}</button>`).join('')}<button type="button" data-ps="" aria-pressed="${!cur.size}">${T.sizeAsk}</button></div><p class="pd-sub">${T.sizeNote}</p></div>
<div class="pd-buy"><span class="qty" aria-label="${T.qty}"><button type="button" data-pq="-1" aria-label="-"><svg><use href="#i-minus"/></svg></button><output>${cur.qty}</output><button type="button" data-pq="1" aria-label="+"><svg><use href="#i-plus"/></svg></button></span><button class="btn dark" type="button" data-padd><svg><use href="#i-bag"/></svg>${T.addCart}</button><button class="pd-wish" type="button" data-wish="${p.id}" aria-pressed="${wished}" aria-label="${T.wish}"><svg><use href="#i-heart"/></svg></button></div>
<a class="btn waBtn" data-pwa href="${waURL(itemMsg(p, cur.v, cur.size, cur.qty))}" target="_blank" rel="noopener"><svg><use href="#i-wa"/></svg>${T.orderWa}</a>
<div class="pd-acc"><details open><summary>${T.details}</summary><ul>${p.details[lang].map(d => `<li>${esc(d)}</li>`).join('')}</ul></details><details><summary>${T.delivery}</summary><p>${T.deliveryText}</p></details></div>
<div class="pd-share"><button type="button" data-share><svg><use href="#i-share"/></svg>${T.share}</button></div></div></div>
<div class="pd-rel"><div class="pd-rel-h"><h2>${T.related}</h2></div><div class="pgrid" id="pdRel">${rel.map(x => card(x, { rv: false })).join('')}</div></div>
<div class="pd-sticky"><button class="btn dark" type="button" data-padd>${T.addCart}</button><a class="btn waBtn" data-pwa href="${waURL(itemMsg(p, cur.v, cur.size, cur.qty))}" target="_blank" rel="noopener"><svg><use href="#i-wa"/></svg>${T.orderNow}</a></div>`;
  watchVideos($('#pdRel'));
}
function pdUpdateWA() { const p = P(cur.id); $$('[data-pwa]', pd).forEach(a => a.href = waURL(itemMsg(p, cur.v, cur.size, cur.qty))); }
function closeProduct() {
  if (!pd.open) return; pd.close(); cur = null; document.title = 'LAMSA | لمسة';
  if (/^#product\//.test(location.hash)) { if (fromApp) history.back(); else history.replaceState(null, '', location.pathname + location.search + '#products'); }
  fromApp = false;
}
pd.addEventListener('cancel', e => { e.preventDefault(); closeProduct(); });
pd.addEventListener('click', e => {
  if (e.target === pd) { closeProduct(); return; }
  const g = e.target.closest.bind(e.target);
  if (g('[data-pclose]')) { closeProduct(); return; }
  if (g('[data-pcat]')) { F.cat = g('[data-pcat]').dataset.pcat; closeProduct(); renderGrid(); setTimeout(() => $('#products').scrollIntoView(), 60); return; }
  if (g('#pdRel')) { const a = g('a[href^="#product/"]'); if (a) { e.preventDefault(); const [, id, v] = a.getAttribute('href').split('/'); history.replaceState(null, '', a.getAttribute('href')); openProduct(id, v); $('#pdIn').scrollTo({ top: 0, behavior: RM ? 'auto' : 'smooth' }); } return; }
  const pv = g('[data-pv]'); if (pv) { cur.v = +pv.dataset.pv; history.replaceState(null, '', '#product/' + cur.id + '/' + cur.v); renderPDKeep(); return; }
  const st = g('[data-step]'); if (st) { const n = P(cur.id).variants.length; cur.v = (cur.v + +st.dataset.step + n) % n; history.replaceState(null, '', '#product/' + cur.id + '/' + cur.v); renderPDKeep(); return; }
  const ps = g('[data-ps]'); if (ps) { cur.size = ps.dataset.ps; $$('[data-ps]', pd).forEach(b => b.setAttribute('aria-pressed', b === ps)); ps.closest('div').previousElementSibling.querySelector('span').textContent = cur.size || t().sizeAsk; pdUpdateWA(); return; }
  const pq = g('[data-pq]'); if (pq) { cur.qty = Math.max(1, Math.min(20, cur.qty + +pq.dataset.pq)); $('.pd-buy output', pd).textContent = cur.qty; pdUpdateWA(); return; }
  if (g('[data-padd]')) { addToCart(cur.id, cur.v, cur.size, cur.qty); return; }
  if (g('[data-wish]')) { toggleWish(cur.id); return; }
  if (g('[data-share]')) { const u = link(cur.id, cur.v), p = P(cur.id); if (navigator.share) navigator.share({ title: p.name[lang] + ' — LAMSA', url: u }).catch(() => {}); else navigator.clipboard?.writeText(u).then(() => toast(t().copied)); return; }
  if (g('.pd-stage>img')) { g('.pd-stage').classList.toggle('zoom'); return; }
});
pd.addEventListener('mousemove', e => { const s = e.target.closest('.pd-stage.zoom'); if (!s) return; const r = s.getBoundingClientRect(); s.firstElementChild.style.transformOrigin = ((e.clientX - r.left) / r.width * 100) + '% ' + ((e.clientY - r.top) / r.height * 100) + '%'; });
function renderPDKeep() { const sc = $('#pdIn').scrollTop; renderPD(); $('#pdIn').scrollTop = sc; }
cardEvents(pd);
{ let x0 = null; pd.addEventListener('touchstart', e => { if (e.target.closest('.pd-stage')) x0 = e.touches[0].clientX; }, { passive: true }); pd.addEventListener('touchend', e => { if (x0 === null || !cur) return; const dx = e.changedTouches[0].clientX - x0; x0 = null; const n = P(cur.id).variants.length; if (Math.abs(dx) > 40 && n > 1) { cur.v = (cur.v + ((dx < 0) !== (document.dir === 'rtl') ? 1 : -1) + n) % n; history.replaceState(null, '', '#product/' + cur.id + '/' + cur.v); renderPDKeep(); } }); }

/* routing: #product/<id>/<variant>  (legacy #<id> links still work) */
function route() {
  const h = decodeURIComponent(location.hash.slice(1)); const m = h.match(/^product\/([\w-]+)(?:\/(\d+))?/);
  if (m && P(m[1])) openProduct(m[1], m[2]);
  else if (P(h)) { history.replaceState(null, '', '#product/' + h); openProduct(h, 0); }
  else if (pd.open) { pd.close(); cur = null; fromApp = false; document.title = 'LAMSA | لمسة'; }
}
addEventListener('hashchange', route);
document.addEventListener('click', e => {
  const a = e.target.closest('a[href^="#product/"]'); if (a && !pd.contains(a)) { fromApp = true; if (drawer.open) drawer.close(); }
}, true);

/* ---------- header search with suggestions ---------- */
const q = $('#q'), sug = $('#sug'); let sugI = -1;
function renderSug() {
  const v = q.value.trim(); if (!v) { sug.hidden = true; return; }
  const list = C.products.filter(p => match(p, v)).slice(0, 5); sugI = -1;
  sug.innerHTML = list.length ? list.map(p => { const k = F.colors.size ? firstVar(p) : 0, va = p.variants[k]; return `<a href="#product/${p.id}/${k}" role="option">${va.type === 'illus' ? '<span class="sg-ph"></span>' : `<img src="${img(va.type === 'video' ? va.poster : va.src, 120)}" data-o="${va.type === 'video' ? va.poster : va.src}" alt="">`}<span>${esc(p.name[lang])}<small>${esc(CAT(p.cat).name[lang])} · ${p.price ? fmt(p.price) : t().ask}</small></span></a>`; }).join('') + `<button type="button" class="sug-all" data-all>${esc(t().searchAll(v))}</button>` : `<div class="sug-none">${t().noMatch}</div>`;
  sug.hidden = false;
}
function runSearch() { F.q = q.value.trim(); sug.hidden = true; renderGrid(); $('#products').scrollIntoView({ behavior: RM ? 'auto' : 'smooth' }); q.blur(); }
q.addEventListener('input', () => { renderSug(); if (!q.value.trim() && F.q) { F.q = ''; renderGrid(); } });
q.addEventListener('focus', renderSug);
q.addEventListener('keydown', e => {
  const opts = $$('a', sug); if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { if (!opts.length) return; e.preventDefault(); sugI = (sugI + (e.key === 'ArrowDown' ? 1 : -1) + opts.length) % opts.length; opts.forEach((o, j) => o.classList.toggle('on', j === sugI)); }
  else if (e.key === 'Escape') sug.hidden = true;
  else if (e.key === 'Enter' && sugI >= 0 && opts[sugI]) { e.preventDefault(); opts[sugI].click(); }
});
$('#srch').addEventListener('submit', e => { e.preventDefault(); runSearch(); });
sug.addEventListener('click', e => { if (e.target.closest('[data-all]')) runSearch(); else if (e.target.closest('a')) { sug.hidden = true; q.blur(); } });
document.addEventListener('click', e => { if (!e.target.closest('#srch')) sug.hidden = true; });

/* ---------- language ---------- */
function applyLang(l, first) {
  lang = U[l] ? l : 'ar'; LS.set('lang', lang);
  const h = document.documentElement; h.lang = lang; h.dir = lang === 'ar' ? 'rtl' : 'ltr';
  $('#lang').value = lang;
  const D = S[lang];
  if (!(first && lang === 'ar')) {
    $$('[data-i]').forEach(el => { const v = D[el.dataset.i]; if (v != null) el.innerHTML = v; });
    $$('[data-ip]').forEach(el => { const v = D[el.dataset.ip]; if (v != null) el.placeholder = v; });
    $$('[data-ia]').forEach(el => { const v = D[el.dataset.ia]; if (v == null) return; if (el.tagName === 'IMG') el.alt = v; else el.setAttribute('aria-label', v); });
    if (promo) { const pt = PR[lang]; $$('[data-pr]', promo).forEach(el => { const v = pt[el.dataset.pr]; if (v != null) el.innerHTML = v; }); promo.setAttribute('aria-label', pt.label); const pb = $('.pr-play', promo); if (pb) pb.setAttribute('aria-label', pt.play); }
  }
  renderCats(); renderFilters(); renderGrid();
  if (pd.open && cur) renderPDKeep();
  if (drawer.open) renderDrawer();
  if (!sug.hidden) renderSug();
}
$('#lang').addEventListener('change', e => applyLang(e.target.value));

/* ---------- wiring ---------- */
cardEvents($('#grid'));
$('#catChips').addEventListener('click', e => { const c = e.target.closest('[data-cat]'); if (c) { F.cat = c.dataset.cat; renderGrid(); } });
$('#colorFilter').addEventListener('click', e => { const b = e.target.closest('[data-col]'); if (!b) return; const f = b.dataset.col; F.colors.has(f) ? F.colors.delete(f) : F.colors.add(f); renderGrid(); });
$('#fPriced').addEventListener('change', e => { F.priced = e.target.checked; renderGrid(); });
$('#sort').addEventListener('change', e => { F.sort = e.target.value; renderGrid(); });
$('#clearF').addEventListener('click', clearFilters); $('#emptyClear').addEventListener('click', clearFilters);
$('#catGrid').addEventListener('click', e => { const c = e.target.closest('[data-cat]'); if (c) { F.cat = c.dataset.cat; renderGrid(); } });
$$('[data-open]').forEach(b => b.addEventListener('click', () => openDrawer(b.dataset.open)));
$$('[data-focus-search]').forEach(b => b.addEventListener('click', () => { scrollTo({ top: 0, behavior: RM ? 'auto' : 'smooth' }); setTimeout(() => q.focus(), RM ? 0 : 350); }));
{ const hdr = $('#hdr'); const onS = () => hdr.classList.toggle('sc', scrollY > 10); addEventListener('scroll', onS, { passive: true }); onS(); }
$('#year').textContent = new Date().getFullYear();

applyLang(lang, true);
counts();
reveal(document);
route();
})();
