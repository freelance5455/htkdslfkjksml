/* ScreenSaathi browser companion: manual entries and focus tracking only.
 * Android UsageStatsManager is NOT available to web pages or PWAs. */
(() => {
  'use strict';
  const root = document.getElementById('ss-companion');
  if (!root) return;
  const prefix = root.dataset.storagePrefix || 'screensaathi-companion-v1';
  const $ = id => document.getElementById(id);
  const defaults = { entries: [], sessions: [], goalMinutes: 120, selectedMinutes: 25,
    sound: true, alerts: false, timer: null, lang: 'en' };
  let state = load();
  let installedPrompt = null;
  function load() {
    try {
      const data = JSON.parse(localStorage.getItem(prefix) || '{}');
      return {
        ...defaults, ...data,
        entries: Array.isArray(data.entries) ? data.entries.slice(-1000) : [],
        sessions: Array.isArray(data.sessions) ? data.sessions.slice(-1000) : [],
      };
    } catch (_) { return {...defaults}; }
  }
  function save() {
    try { localStorage.setItem(prefix, JSON.stringify(state)); }
    catch (_) { notify('ss-settings-status', 'Browser storage is unavailable. Your changes may not persist.'); }
  }
  function notify(id, message) { const n=$(id); if(n)n.textContent=message; }
  function todayStr(date = new Date()) {
    const year = date.getFullYear(), month = String(date.getMonth()+1).padStart(2,'0'), day = String(date.getDate()).padStart(2,'0');
    return `${year}-${month}-${day}`;
  }
  function dayOf(ms) { return todayStr(new Date(ms)); }
  function minsLabel(n) { n=Math.max(0,Math.round(n)); return n>=60 ? `${Math.floor(n/60)}h ${String(n%60).padStart(2,'0')}m` : `${n} min`; }
  function fmtCountdown(ms) { let secs=Math.max(0,Math.ceil(ms/1000)); return `${String(Math.floor(secs/60)).padStart(2,'0')}:${String(secs%60).padStart(2,'0')}`; }
  function elem(tag, className, text) { const e=document.createElement(tag); if(className)e.className=className; if(text!==undefined)e.textContent=text; return e; }
  function tab(name) {
    document.querySelectorAll('#ss-companion [data-tab]').forEach(button => {
      const active=button.dataset.tab===name;
      button.setAttribute('aria-selected',String(active)); button.tabIndex = active ? 0 : -1;
    });
    document.querySelectorAll('#ss-companion [data-panel]').forEach(panel => {
      panel.hidden=panel.dataset.panel!==name;
    });
    if(name==='reports') renderChart();
    if(name==='focus') tick();
  }
  root.querySelectorAll('[data-tab]').forEach(button=>button.addEventListener('click',()=>tab(button.dataset.tab)));
  root.querySelectorAll('[data-goto]').forEach(button=>button.addEventListener('click',()=>tab(button.dataset.goto)));
  const current = todayStr();
  function renderHome() {
    const sessions=state.sessions.filter(s=>dayOf(s.endAt)===todayStr());
    $('ss-home-focus').textContent=minsLabel(sessions.reduce((total,s)=>total + s.duration,0));
    $('ss-home-sessions').textContent=String(sessions.length);
    $('ss-home-goal').textContent=minsLabel(state.goalMinutes);
  }
  function renderEntries() {
    const list=$('ss-entry-list'); list.replaceChildren();
    const entries=state.entries.filter(e=>dayOf(e.createdAt)===todayStr()).slice().reverse();
    if(!entries.length) { list.append(elem('p','ss-empty','No manual entries today.')); return; }
    entries.forEach(entry=>{
      const item=elem('div','ss-entry');
      const body=elem('div');
      body.append(elem('strong','',entry.title), elem('small','',`${entry.category} · ${minsLabel(entry.minutes)}`));
      const button=elem('button','ss-remove','Remove');button.type='button';button.setAttribute('aria-label',`Remove ${entry.title}`);
      button.addEventListener('click',()=> { state.entries=state.entries.filter(e=>e.id!==entry.id);save();renderEntries(); });
      item.append(body,button);list.append(item);
    });
  }
  $('ss-manual-form').addEventListener('submit',event=>{
    event.preventDefault();
    const title=$('ss-manual-title').value.trim(), minutes=Number($('ss-manual-minutes').value), category=$('ss-manual-category').value;
    if(!title || title.length>60 || !Number.isSafeInteger(minutes) || minutes<1 || minutes>1440) {
      notify('ss-entry-status','Enter a valid activity and 1–1440 minutes.');return;
    }
    state.entries.push({id:`${Date.now()}-${Math.random().toString(36).slice(2)}`, title,minutes,category,createdAt:Date.now()});
    state.entries=state.entries.slice(-1000);save();renderEntries();$('ss-manual-title').value='';
    notify('ss-entry-status','Manual entry saved on this device.');
  });
  function remaining() {
    const t=state.timer;
    if(!t)return state.selectedMinutes*60*1000;
    return t.pausedRemaining !== null ? t.pausedRemaining : Math.max(0,t.endAt-Date.now());
  }
  function completeTimer() {
    const t=state.timer;if(!t || t.pausedRemaining!==null || Date.now()<t.endAt)return;
    const end=Date.now();
    state.sessions.push({id:`focus-${t.startedAt}`,duration:t.duration,endAt:end});
    state.sessions=state.sessions.slice(-1000);state.timer=null;save();
    notify('ss-focus-status','Focus session complete! Nice work.');
    if(state.sound)playBeep();
    if(state.alerts && 'Notification' in window && Notification.permission==='granted') {
      const options={body:'Focus session complete. Time for a short break.',icon:window.ScreenSaathiConfig?.icon || undefined};
      if('serviceWorker' in navigator && navigator.serviceWorker.controller) {
        navigator.serviceWorker.ready.then(reg=>reg.showNotification('ScreenSaathi',options)).catch(()=>{});
      } else {
        try { new Notification('ScreenSaathi',options); } catch (_) {}
      }
    }
  }
  function playBeep() {
    try { const Ctx=window.AudioContext||window.webkitAudioContext;if(!Ctx)return;const ctx=new Ctx();const oscillator=ctx.createOscillator(),gain=ctx.createGain();oscillator.type='sine';oscillator.frequency.value=650;gain.gain.value=.06;oscillator.connect(gain);gain.connect(ctx.destination);oscillator.start();oscillator.stop(ctx.currentTime+.22);oscillator.onended=()=>ctx.close(); } catch(_) {}
  }
  function tick() {
    completeTimer();
    $('ss-timer').textContent=fmtCountdown(remaining());
    const t=state.timer;
    const running=Boolean(t && t.pausedRemaining===null),paused=Boolean(t && t.pausedRemaining!==null);
    $('ss-focus-start').disabled=running;
    $('ss-focus-start').textContent=paused?'Resume Focus':'Start Focus';
    $('ss-focus-pause').disabled=!running;
    $('ss-focus-state').textContent=running?'FOCUS IN PROGRESS':paused?'PAUSED':'READY WHEN YOU ARE';
    $('ss-focus-description').textContent=running?'One task. One step at a time.':paused?'Resume whenever you are ready.':'Select a duration and press Start';
    root.querySelectorAll('[data-duration]').forEach(button=>{
      const selected=Number(button.dataset.duration)===state.selectedMinutes;
      button.setAttribute('aria-pressed',String(selected));button.disabled=Boolean(t);
    });
    renderHome();
  }
  root.querySelectorAll('[data-duration]').forEach(button=>button.addEventListener('click',()=>{
    if(state.timer)return;
    state.selectedMinutes=Number(button.dataset.duration);save();tick();
  }));
  $('ss-focus-start').addEventListener('click',()=>{
    if(state.timer && state.timer.pausedRemaining===null)return;
    if(state.timer){state.timer.endAt=Date.now()+state.timer.pausedRemaining;state.timer.pausedRemaining=null;}
    else {const ms=state.selectedMinutes*60000;state.timer={startedAt:Date.now(),endAt:Date.now()+ms,pausedRemaining:null,duration:state.selectedMinutes};}
    save();tick();notify('ss-focus-status','Focus timer active.');
  });
  $('ss-focus-pause').addEventListener('click',()=>{
    if(!state.timer || state.timer.pausedRemaining!==null)return;
    state.timer.pausedRemaining=Math.max(0,state.timer.endAt-Date.now());save();tick();notify('ss-focus-status','Timer paused.');
  });
  $('ss-focus-reset').addEventListener('click',()=>{state.timer=null;save();tick();notify('ss-focus-status','Timer reset.');});
  function renderHistory() {
    const list=$('ss-focus-history');list.replaceChildren();
    const records=state.sessions.slice(-12).reverse();
    if(!records.length){list.append(elem('p','ss-empty','No focus sessions completed yet.'));return;}
    records.forEach(s=>{
      const row=elem('div','ss-entry');row.append(elem('span','',new Date(s.endAt).toLocaleDateString()),elem('strong','',minsLabel(s.duration)));list.append(row);
    });
  }
  function renderChart() {
    const chart=$('ss-week-chart');chart.replaceChildren();
    const days=Array.from({length:7},(_,i)=>{const d=new Date();d.setHours(12,0,0,0);d.setDate(d.getDate()-6+i);return {key:todayStr(d),display:d.toLocaleDateString(undefined,{weekday:'short'})};});
    const values=days.map(d=>state.sessions.filter(s=>dayOf(s.endAt)===d.key).reduce((n,s)=>n+s.duration,0));
    const max=Math.max(30,...values);
    days.forEach((d,i)=>{
      const barWrap=elem('div','ss-chart-column');
      const height=Math.max(2,Math.round(values[i]/max*100));
      const bar=elem('div','ss-chart-bar');bar.style.height=`${height}%`;
      bar.title=`${d.display}: ${minsLabel(values[i])}`;
      barWrap.append(elem('strong','',values[i] ? minsLabel(values[i]):'0'),bar,elem('small','',d.display));chart.append(barWrap);
    });
    chart.setAttribute('aria-label',days.map((d,i)=>`${d.display}: ${minsLabel(values[i])}`).join(', '));
  }
  function renderSettings() {
    $('ss-daily-goal').value=state.goalMinutes;
    $('ss-timer-sound').checked=Boolean(state.sound);
    $('ss-browser-alert').checked=Boolean(state.alerts);
  }
  $('ss-settings-form').addEventListener('submit',async event=>{
    event.preventDefault();
    const goal=Number($('ss-daily-goal').value);
    if(!Number.isSafeInteger(goal)||goal<15||goal>1440){notify('ss-settings-status','Choose a goal between 15 and 1440 minutes.');return;}
    const alertWanted=$('ss-browser-alert').checked;
    state.goalMinutes=goal;state.sound=$('ss-timer-sound').checked;
    if(alertWanted && 'Notification' in window && Notification.permission !== 'granted') {
      try {await Notification.requestPermission();}catch(_){}
    }
    state.alerts=alertWanted && 'Notification' in window && Notification.permission==='granted';
    $('ss-browser-alert').checked=state.alerts;
    save();renderHome();notify('ss-settings-status','Saved on this device.'+(alertWanted&&!state.alerts?' Browser alerts not authorized.':''));
  });
  $('ss-clear-data').addEventListener('click',()=>{
    if(!window.confirm('Delete all locally saved ScreenSaathi companion history and preferences?'))return;
    state={...defaults,entries:[],sessions:[],timer:null};save();draw();notify('ss-clear-status','All companion data cleared.');
  });
  $('ss-export').addEventListener('click',()=>{
    const rows=[['Record type','Date/time','Title','Category','Minutes']];
    state.entries.forEach(e=>rows.push(['Manual entry',new Date(e.createdAt).toISOString(),e.title,e.category,String(e.minutes)]));
    state.sessions.forEach(s=>rows.push(['Focus session',new Date(s.endAt).toISOString(),'Focus','Focus',String(s.duration)]));
    const quote=value=>'"'+String(value).replace(/"/g,'""')+'"';
    const text='\uFEFF'+rows.map(r=>r.map(quote).join(',')).join('\r\n');
    const blob=new Blob([text],{type:'text/csv;charset=utf-8'}),url=URL.createObjectURL(blob);
    const a=document.createElement('a');a.href=url;a.download=`screensaathi-companion-${todayStr()}.csv`;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),3000);
    notify('ss-export-status','Your locally saved CSV is ready.');
  });
  $('ss-lang').addEventListener('click',()=>{
    state.lang=state.lang==='en'?'hi':'en';save();
    $('ss-native-title').textContent=state.lang==='hi'?'ब्राउज़र में असली स्क्रीन टाइम उपलब्ध नहीं':'Browser mode — native Android usage not available';
    $('ss-native-desc').textContent=state.lang==='hi'?'वेबसाइट Android Usage Access नहीं ले सकती और दूसरे ऐप का समय नहीं पढ़ सकती। यहाँ फोकस टाइमर और आपके अपने लिखे हुए रिकॉर्ड काम करते हैं। असली स्क्रीन टाइम के लिए नेटिव APK जरूरी है।':"This website cannot request Android Usage Access or read other apps’ screen time. Focus sessions and manually entered habits work on this phone. For real app statistics, a separately built Android APK is required.";
    notify('ss-settings-status',state.lang==='hi'?'मुख्य अनुमति जानकारी हिन्दी में है।':'Permission explanation is in English.');
  });
  const installBtn=$('ss-install');
  window.addEventListener('beforeinstallprompt',event=>{event.preventDefault();installedPrompt=event;installBtn.hidden=false;});
  installBtn.addEventListener('click',async()=>{
    if(!installedPrompt)return;
    installedPrompt.prompt();await installedPrompt.userChoice;installedPrompt=null;installBtn.hidden=true;
  });
  window.addEventListener('appinstalled',()=>{installedPrompt=null;installBtn.hidden=true;});
  if('serviceWorker' in navigator && window.isSecureContext && window.ScreenSaathiConfig?.worker) {
    window.addEventListener('load',()=>navigator.serviceWorker.register(window.ScreenSaathiConfig.worker,{scope:window.ScreenSaathiConfig.scope}).catch(()=>{}));
  }
  function draw(){renderHome();renderEntries();renderHistory();renderSettings();renderChart();tick();}
  draw();setInterval(()=>{tick();renderHistory();},1000);
})();
