(function (g) {
  const sma = (a, n) => a.length < n ? null : a.slice(-n).reduce((x, y) => x + y, 0) / n;
  function rsi(a, n = 14) {
    if (a.length <= n) return null;
    let u = 0, d = 0;
    for (let i = 1; i <= n; i++) { const x = a[i] - a[i - 1]; x >= 0 ? u += x : d -= x; }
    u /= n; d /= n;
    for (let i = n + 1; i < a.length; i++) { const x = a[i] - a[i - 1]; u = (u * (n - 1) + (x > 0 ? x : 0)) / n; d = (d * (n - 1) + (x < 0 ? -x : 0)) / n; }
    return d === 0 ? 100 : 100 - 100 / (1 + u / d);
  }
  function vol(a) {
    if (a.length < 3) return null;
    const r = []; for (let i = 1; i < a.length; i++) r.push(Math.log(a[i] / a[i - 1]));
    const m = r.reduce((x, y) => x + y, 0) / r.length;
    return Math.sqrt(r.reduce((x, y) => x + (y - m) ** 2, 0) / (r.length - 1)) * 100;
  }
  function summary(k) {
    const c = k.map(x => x.c), p = c[c.length - 1], s20 = sma(c, 20), s50 = sma(c, 50), last = k.slice(-48);
    return { price: p, sma20: s20, sma50: s50, rsi: rsi(c), vol: vol(c.slice(-48)),
      support: Math.min(...last.map(x => x.l)), resist: Math.max(...last.map(x => x.h)),
      trend: s50 === null ? null : (p > s50 && s20 > s50 ? 'up' : p < s50 && s20 < s50 ? 'dn' : 'side') };
  }
  g.Ind = { sma, rsi, vol, summary };
  if (typeof module !== 'undefined') module.exports = g.Ind;
})(typeof window !== 'undefined' ? window : globalThis);
