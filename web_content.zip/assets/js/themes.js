(function(){
  const palettes=[
    ['#1c1024','#2a1d31','#ff2f63','#2da8df','#c26ba7'],
    ['#071b29','#102e42','#00d7ff','#795cff','#78e2ff'],
    ['#251108','#382015','#ff7a18','#ffd166','#ffb45c'],
    ['#0d1d16','#183326','#22d37c','#00b8a9','#6ee7b7'],
    ['#21112c','#351a41','#e83e8c','#8b5cf6','#d8a4ff'],
    ['#141414','#282828','#ff3b30','#ff9500','#ffd60a']
  ];
  let index=0, auto=true, timer;
  const $=id=>document.getElementById(id);
  function apply(p){
    document.documentElement.style.setProperty('--bg',p[0]);
    document.documentElement.style.setProperty('--surface',p[1]);
    document.documentElement.style.setProperty('--primary',p[2]);
    document.documentElement.style.setProperty('--secondary',p[3]);
    document.documentElement.style.setProperty('--heading',p[4]);
  }
  function next(){index=(index+1)%palettes.length;apply(palettes[index]);}
  function start(){clearInterval(timer);if(auto)timer=setInterval(next,15000)}

  const cycle=$('themeCycle');
  const autoToggle=$('autoTheme');
  const soundToggle=$('soundToggle');
  const mode=$('modeBtn');

  try{auto=localStorage.getItem('autoColor')!=='0'}catch(e){}
  if(autoToggle)autoToggle.checked=auto;
  try{
    const soundOn=localStorage.getItem('soundEnabled')!=='0';
    if(soundToggle)soundToggle.checked=soundOn;
  }catch(e){}

  cycle && (cycle.onclick=()=>{next();start();});
  autoToggle && (autoToggle.onchange=()=>{
    auto=!!autoToggle.checked;
    try{localStorage.setItem('autoColor',auto?'1':'0')}catch(e){}
    start();
  });
  soundToggle && (soundToggle.onchange=()=>{
    try{localStorage.setItem('soundEnabled',soundToggle.checked?'1':'0')}catch(e){}
    if(window.showToast)window.showToast(soundToggle.checked?'Sound enabled':'Sound disabled');
  });
  mode && (mode.onclick=()=>{
    document.body.classList.toggle('light');
    mode.textContent=document.body.classList.contains('light')?'☀ Light':'☾ Dark';
    try{localStorage.setItem('lightMode',document.body.classList.contains('light')?'1':'0')}catch(e){}
  });
  try{
    if(localStorage.getItem('lightMode')==='1'){
      document.body.classList.add('light');
      if(mode)mode.textContent='☀ Light';
    }
  }catch(e){}
  start();
})();
