window.LAMSA_CONFIG = {
  url: 'https://aodnfamemzijwzargrvv.supabase.co',
  publishableKey: 'sb_publishable_y-stDGhWBjKCQQI1SZj-ag_q05ZMzvI'
};
