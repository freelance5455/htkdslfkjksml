/**
 * Name Tools - Favorites Management
 */
(function () {
  const STORAGE_KEY = 'name_tools_favorites';

  window.FavoritesManager = {
    getAll: function () {
      try {
        const data = localStorage.getItem(STORAGE_KEY);
        return data ? JSON.parse(data) : [];
      } catch (e) {
        console.error('Error reading favorites:', e);
        return [];
      }
    },

    isFavorite: function (name) {
      const items = this.getAll();
      return items.some(item => item.name.toLowerCase() === name.trim().toLowerCase());
    },

    toggle: function (name, category = 'General', tool = 'Name Generator') {
      let items = this.getAll();
      const trimmed = name.trim();
      const existingIndex = items.findIndex(item => item.name.toLowerCase() === trimmed.toLowerCase());

      let added = false;
      if (existingIndex > -1) {
        items.splice(existingIndex, 1);
        if (window.showToast) window.showToast(`Removed "${trimmed}" from favorites`, 'success');
      } else {
        items.unshift({
          name: trimmed,
          category,
          tool,
          date: new Date().toISOString()
        });
        added = true;
        if (window.showToast) window.showToast(`Saved "${trimmed}" to favorites!`, 'success');
      }

      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
        window.dispatchEvent(new CustomEvent('favoritesupdated', { detail: { items, count: items.length } }));
        this.updateBadges();
      } catch (e) {
        console.error('Error saving favorites:', e);
      }

      return added;
    },

    remove: function (name) {
      let items = this.getAll();
      items = items.filter(item => item.name.toLowerCase() !== name.trim().toLowerCase());
      localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
      window.dispatchEvent(new CustomEvent('favoritesupdated', { detail: { items, count: items.length } }));
      this.updateBadges();
    },

    clearAll: function () {
      localStorage.removeItem(STORAGE_KEY);
      window.dispatchEvent(new CustomEvent('favoritesupdated', { detail: { items: [], count: 0 } }));
      this.updateBadges();
      if (window.showToast) window.showToast('Cleared all favorites', 'success');
    },

    updateBadges: function () {
      const count = this.getAll().length;
      document.querySelectorAll('.favorites-count-badge').forEach(badge => {
        badge.textContent = count;
        if (count > 0) {
          badge.classList.remove('hidden');
        } else {
          badge.classList.add('hidden');
        }
      });
    }
  };

  document.addEventListener('DOMContentLoaded', () => {
    window.FavoritesManager.updateBadges();
  });
})();
