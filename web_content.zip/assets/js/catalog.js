/* LAMSA catalog — single source of truth for products.
 * Every product here is a real item in the shop. Media "type":
 *   photo  = real photo of the actual item (background cleaned with AI, garment unchanged)
 *   video  = real video filmed in the shop
 *   illus  = drawn illustration of an available colour (no real photo yet)
 * price: number in DZD, or null = "ask for price".
 * To add a product: copy one block, add photos to /assets/products/ and translate the texts.
 */
window.CATALOG = {
  categories: [
    { id: 'jackets', cover: 'assets/products/fur-jacket-black.jpg', name: { ar: 'جاكيتات', fr: 'Vestes & blousons', en: 'Jackets' } },
    { id: 'hoodies', cover: 'assets/products/zip-hoodie-cream.jpg', name: { ar: 'هوديات وسويتات', fr: 'Sweats & hoodies', en: 'Hoodies & sweatshirts' } },
    { id: 'knit', cover: 'assets/products/tricot-cotton.jpg', name: { ar: 'تريكو', fr: 'Tricots', en: 'Knitwear' } },
    { id: 'shirts', cover: 'assets/products/shirt-blue.jpg', name: { ar: 'قمصان', fr: 'Chemises', en: 'Shirts' } }
  ],
  soon: [
    { id: 'bags', icon: 'bag', name: { ar: 'الحقائب والإكسسوارات', fr: 'Sacs & accessoires', en: 'Bags & accessories' } },
    { id: 'watches', icon: 'watch', name: { ar: 'الساعات والهدايا', fr: 'Montres & cadeaux', en: 'Watches & gifts' } },
    { id: 'perfume', icon: 'drop', name: { ar: 'العطور والعناية', fr: 'Parfums & soins', en: 'Fragrance & care' } },
    { id: 'home', icon: 'home', name: { ar: 'المنزل ونمط الحياة', fr: 'Maison & art de vivre', en: 'Home & lifestyle' } }
  ],
  colors: {
    white: { sw: '#f4f2ec', name: { ar: 'أبيض', fr: 'Blanc', en: 'White' } },
    black: { sw: '#1f2321', name: { ar: 'أسود', fr: 'Noir', en: 'Black' } },
    grey: { sw: '#a7a8a4', name: { ar: 'رمادي', fr: 'Gris', en: 'Grey' } },
    blue: { sw: '#5f7896', name: { ar: 'أزرق', fr: 'Bleu', en: 'Blue' } },
    beige: { sw: '#e6dcc6', name: { ar: 'بيج وكريمي', fr: 'Beige & crème', en: 'Beige & cream' } },
    green: { sw: '#2f5d46', name: { ar: 'أخضر', fr: 'Vert', en: 'Green' } },
    multi: { sw: 'conic-gradient(#e9e4da 0 25%,#5b4a63 0 50%,#3f6a66 0 75%,#1f2321 0)', name: { ar: 'ألوان متعددة', fr: 'Multicolore', en: 'Multicolour' } }
  },
  sizes: ['S', 'M', 'L', 'XL', 'XXL'],
  products: [
    {
      id: 'jacket', cat: 'jackets', added: 1, price: null,
      name: { ar: 'جاكيت شتوي مبطّن', fr: 'Doudoune d’hiver', en: 'Padded winter jacket' },
      desc: {
        ar: 'جاكيت شتوي مبطّن متوفر بثلاثة موديلات: أبيض منقوش، أسود مخملي، وأسود لامع ومخمل.',
        fr: 'Doudoune d’hiver rembourrée, disponible en trois modèles : blanc à motifs, noir velours et noir brillant & velours.',
        en: 'Padded winter jacket available in three models: patterned white, black velvet, and glossy black & velvet.'
      },
      details: {
        ar: ['مبطّن للشتاء', '3 موديلات متوفرة', 'المقاسات حسب التوفر — اسأل عبر واتساب'],
        fr: ['Rembourrée pour l’hiver', '3 modèles disponibles', 'Tailles selon disponibilité — demandez sur WhatsApp'],
        en: ['Padded for winter', '3 models available', 'Sizes subject to availability — ask on WhatsApp']
      },
      kw: 'doudoune puffer coat manteau جاكيت معطف',
      variants: [
        { type: 'photo', src: 'assets/products/jacket-white.jpg', fam: ['white'], sw: '#f3f1ea', name: { ar: 'أبيض منقوش', fr: 'Blanc à motifs', en: 'Patterned white' } },
        { type: 'photo', src: 'assets/products/jacket-black-velvet.jpg', fam: ['black'], sw: 'radial-gradient(circle at 35% 35%,#555,#0b0b0b)', name: { ar: 'أسود مخملي', fr: 'Noir velours', en: 'Black velvet' } },
        { type: 'photo', src: 'assets/products/jacket-black-mixed.jpg', fam: ['black'], sw: 'linear-gradient(135deg,#3a3d40 50%,#0b0b0b 50%)', name: { ar: 'أسود لامع ومخمل', fr: 'Noir brillant & velours', en: 'Glossy black & velvet' } }
      ]
    },
    {
      id: 'bomber', cat: 'jackets', added: 2, price: null,
      name: { ar: 'جاكيت بومبر خفيف', fr: 'Blouson bomber léger', en: 'Lightweight bomber jacket' },
      desc: {
        ar: 'جاكيت بومبر خفيف، مثالي للربيع والخريف، متوفر بثلاثة موديلات.',
        fr: 'Blouson bomber léger, idéal pour le printemps et l’automne, disponible en trois modèles.',
        en: 'Lightweight bomber jacket, perfect for spring and autumn, available in three models.'
      },
      details: {
        ar: ['خفيف — للربيع والخريف', '3 موديلات متوفرة', 'المقاسات حسب التوفر — اسأل عبر واتساب'],
        fr: ['Léger — printemps et automne', '3 modèles disponibles', 'Tailles selon disponibilité — demandez sur WhatsApp'],
        en: ['Lightweight — spring and autumn', '3 models available', 'Sizes subject to availability — ask on WhatsApp']
      },
      kw: 'bomber blouson veste jacket بومبر',
      variants: [
        { type: 'photo', src: 'assets/products/bomber-striped.jpg', fam: ['white', 'grey'], sw: 'repeating-linear-gradient(90deg,#f4f4f2 0 3px,#6d7378 3px 5px)', name: { ar: 'مقلّم أبيض ورمادي', fr: 'Rayé blanc et gris', en: 'White & grey stripes' } },
        { type: 'photo', src: 'assets/products/bomber-grey.jpg', fam: ['grey'], sw: 'radial-gradient(circle at 35% 35%,#8a8a8a,#3e3f41)', name: { ar: 'رمادي منسوج', fr: 'Gris chiné', en: 'Heather grey' } },
        { type: 'photo', src: 'assets/products/bomber-blue.jpg', fam: ['blue'], sw: 'linear-gradient(135deg,#b9c8dc 50%,#1f2f4d 50%)', name: { ar: 'أزرق فاتح مربعات', fr: 'Bleu clair à carreaux', en: 'Light blue check' } }
      ]
    },
    {
      id: 'hoodie', cat: 'hoodies', added: 3, price: null,
      name: { ar: 'سويت بقبعة (هودي)', fr: 'Sweat à capuche', en: 'Hooded sweatshirt' },
      desc: {
        ar: 'سويت بقبعة بقماش ناعم وجيب أمامي. متوفر بالأبيض (بخطوط على الأكمام) وبالأخضر والأزرق.',
        fr: 'Sweat à capuche en tissu doux avec poche kangourou. Disponible en blanc (bandes sur les manches), vert et bleu.',
        en: 'Hooded sweatshirt in soft fabric with a front pocket. Available in white (striped sleeves), green and blue.'
      },
      details: {
        ar: ['قماش ناعم', 'جيب أمامي', '3 ألوان: أبيض، أخضر، أزرق', 'صورة الأخضر والأزرق متوفرة عبر واتساب'],
        fr: ['Tissu doux', 'Poche kangourou', '3 couleurs : blanc, vert, bleu', 'Photos du vert et du bleu sur WhatsApp'],
        en: ['Soft fabric', 'Front pocket', '3 colours: white, green, blue', 'Photos of green and blue on WhatsApp']
      },
      kw: 'hoodie sweat capuche هودي سويت',
      variants: [
        { type: 'photo', src: 'assets/products/hoodie-white.jpg', fam: ['white'], sw: '#f4f2ec', name: { ar: 'أبيض', fr: 'Blanc', en: 'White' } },
        { type: 'illus', color: '#2f5d46', fam: ['green'], sw: '#2f5d46', name: { ar: 'أخضر', fr: 'Vert', en: 'Green' } },
        { type: 'illus', color: '#1f3a5f', fam: ['blue'], sw: '#1f3a5f', name: { ar: 'أزرق', fr: 'Bleu', en: 'Blue' } }
      ]
    },
    {
      id: 'sweater', cat: 'hoodies', added: 4, price: null,
      name: { ar: 'سويت مقلّم برقبة دائرية', fr: 'Sweat rayé col rond', en: 'Striped crew-neck sweatshirt' },
      desc: {
        ar: 'سويت قطني بخطوط عريضة، رقبة دائرية وأكمام طويلة، متوفر بثلاثة ألوان.',
        fr: 'Sweat en coton à larges rayures, col rond et manches longues, disponible en trois couleurs.',
        en: 'Cotton sweatshirt with wide stripes, a crew neck and long sleeves, available in three colours.'
      },
      details: {
        ar: ['قطن', 'خطوط عريضة', 'رقبة دائرية وأكمام طويلة', '3 ألوان متوفرة'],
        fr: ['Coton', 'Larges rayures', 'Col rond, manches longues', '3 couleurs disponibles'],
        en: ['Cotton', 'Wide stripes', 'Crew neck, long sleeves', '3 colours available']
      },
      kw: 'sweatshirt pull rayé stripes سويت مقلم',
      variants: [
        { type: 'photo', src: 'assets/products/sweater-cream-navy.jpg', fam: ['beige', 'blue'], sw: 'repeating-linear-gradient(0deg,#f3efe4 0 4px,#1d2b4a 4px 7px)', name: { ar: 'كريمي وكحلي', fr: 'Crème et marine', en: 'Cream & navy' } },
        { type: 'photo', src: 'assets/products/sweater-sky-blue.jpg', fam: ['blue', 'white'], sw: 'repeating-linear-gradient(0deg,#8fb0c8 0 4px,#fbfaf5 4px 7px)', name: { ar: 'أزرق سماوي وأبيض', fr: 'Bleu ciel et blanc', en: 'Sky blue & white' } },
        { type: 'photo', src: 'assets/products/sweater-slate-blue.jpg', fam: ['blue', 'white'], sw: 'repeating-linear-gradient(0deg,#6b809b 0 4px,#fbfaf5 4px 7px)', name: { ar: 'أزرق رمادي وأبيض', fr: 'Bleu ardoise et blanc', en: 'Slate blue & white' } }
      ]
    },
    {
      id: 'tricot', cat: 'knit', added: 5, price: 3800,
      name: { ar: 'تريكو قطني', fr: 'Tricot coton', en: 'Cotton knit sweater' },
      desc: {
        ar: 'تشكيلة واسعة من الألوان والموديلات — قطن ناعم وأكمام طويلة. شاهد الفيديو واذكر اللون الذي يعجبك في رسالتك.',
        fr: 'Large choix de couleurs et de modèles — coton doux, manches longues. Regardez la vidéo et indiquez la couleur souhaitée dans votre message.',
        en: 'Wide choice of colours and styles — soft cotton, long sleeves. Watch the video and mention the colour you like in your message.'
      },
      details: {
        ar: ['قطن ناعم', 'أكمام طويلة', 'ألوان وموديلات متعددة', 'السعر: 3 800 دج'],
        fr: ['Coton doux', 'Manches longues', 'Nombreuses couleurs et modèles', 'Prix : 3 800 DA'],
        en: ['Soft cotton', 'Long sleeves', 'Many colours and styles', 'Price: 3,800 DA']
      },
      kw: 'tricot knit pull sweater maille تريكو',
      variants: [
        { type: 'video', src: 'assets/products/tricot-cotton.mp4', poster: 'assets/products/tricot-cotton.jpg', fam: ['multi'], sw: 'conic-gradient(#e9e4da 0 25%,#5b4a63 0 50%,#3f6a66 0 75%,#1f2321 0)', name: { ar: 'ألوان متعددة — حدّد اللون في الرسالة', fr: 'Plusieurs couleurs — précisez dans le message', en: 'Several colours — specify in your message' } }
      ]
    },
    {
      id: 'shirt', cat: 'shirts', added: 6, price: null,
      name: { ar: 'قميص بنقشة بأكمام طويلة', fr: 'Chemise imprimée manches longues', en: 'Long-sleeve printed shirt' },
      desc: {
        ar: 'قميص قطني بياقة كلاسيكية وجيب أمامي وأكمام طويلة، متوفر بثلاثة موديلات.',
        fr: 'Chemise en coton à col classique, poche poitrine et manches longues, disponible en trois modèles.',
        en: 'Cotton shirt with a classic collar, chest pocket and long sleeves, available in three models.'
      },
      details: {
        ar: ['قطن', 'ياقة كلاسيكية', 'جيب أمامي', 'أكمام طويلة'],
        fr: ['Coton', 'Col classique', 'Poche poitrine', 'Manches longues'],
        en: ['Cotton', 'Classic collar', 'Chest pocket', 'Long sleeves']
      },
      kw: 'chemise shirt قميص',
      variants: [
        { type: 'photo', src: 'assets/products/shirt-white-grey.jpg', fam: ['white', 'grey'], sw: 'radial-gradient(circle at 35% 35%,#f4f3ef,#a9a9a6)', name: { ar: 'أبيض ورمادي', fr: 'Blanc et gris', en: 'White & grey' } },
        { type: 'photo', src: 'assets/products/shirt-beige-grey.jpg', fam: ['beige', 'grey'], sw: 'radial-gradient(circle at 35% 35%,#e9e3d4,#a8a59c)', name: { ar: 'بيج ورمادي', fr: 'Beige et gris', en: 'Beige & grey' } },
        { type: 'photo', src: 'assets/products/shirt-blue.jpg', fam: ['blue'], sw: 'radial-gradient(circle at 50% 50%,#fff 0 18%,#4d5f7d 22%)', name: { ar: 'أزرق بنقشة بيضاء', fr: 'Bleu à motifs blancs', en: 'Blue with white print' } }
      ]
    },
    {
      id: 'fur', cat: 'jackets', added: 7, price: null,
      name: { ar: 'جاكيت فرو ناعم بقبعة', fr: 'Veste en fausse fourrure à capuche', en: 'Hooded faux-fur jacket' },
      desc: {
        ar: 'جاكيت فرو ناعم ودافئ بقبعة وسحّاب وجيبين، متوفر بموديلين.',
        fr: 'Veste en fausse fourrure douce et chaude, avec capuche, zip et deux poches, disponible en deux modèles.',
        en: 'Soft, warm faux-fur jacket with a hood, zip and two pockets, available in two models.'
      },
      details: {
        ar: ['فرو ناعم ودافئ', 'قبعة وسحّاب', 'جيبان', 'موديلان متوفران'],
        fr: ['Fausse fourrure douce et chaude', 'Capuche et zip', 'Deux poches', '2 modèles disponibles'],
        en: ['Soft, warm faux fur', 'Hood and zip', 'Two pockets', '2 models available']
      },
      kw: 'fourrure fur fourrure veste فرو جاكيت',
      variants: [
        { type: 'photo', src: 'assets/products/fur-jacket-white.jpg', fam: ['white'], sw: 'radial-gradient(circle at 50% 50%,#222 0 18%,#f4f3ef 22%)', name: { ar: 'أبيض بكتابة سوداء', fr: 'Blanc à lettrage noir', en: 'White with black lettering' } },
        { type: 'photo', src: 'assets/products/fur-jacket-black.jpg', fam: ['black'], sw: 'radial-gradient(circle at 50% 50%,#fff 0 18%,#22252c 22%)', name: { ar: 'أسود بكتابة بيضاء', fr: 'Noir à lettrage blanc', en: 'Black with white lettering' } }
      ]
    },
    {
      id: 'ziphoodie', cat: 'hoodies', added: 8, price: null,
      name: { ar: 'سويت بقبعة وسحّاب', fr: 'Sweat zippé à capuche', en: 'Zip-up hoodie' },
      desc: {
        ar: 'سويت بقبعة بقماش ناعم ودافئ، سحّاب كامل وجيبين، متوفر بثلاثة ألوان.',
        fr: 'Sweat à capuche en tissu doux et chaud, zip intégral et deux poches, disponible en trois couleurs.',
        en: 'Hoodie in soft, warm fabric with a full zip and two pockets, available in three colours.'
      },
      details: {
        ar: ['قماش ناعم ودافئ', 'سحّاب كامل', 'جيبان', '3 ألوان متوفرة'],
        fr: ['Tissu doux et chaud', 'Zip intégral', 'Deux poches', '3 couleurs disponibles'],
        en: ['Soft, warm fabric', 'Full zip', 'Two pockets', '3 colours available']
      },
      kw: 'zip hoodie sweat zippé capuche هودي سحاب',
      variants: [
        { type: 'photo', src: 'assets/products/zip-hoodie-grey.jpg', fam: ['grey'], sw: '#bcbcb7', name: { ar: 'رمادي فاتح', fr: 'Gris clair', en: 'Light grey' } },
        { type: 'photo', src: 'assets/products/zip-hoodie-cream.jpg', fam: ['beige'], sw: '#f1eee3', name: { ar: 'كريمي', fr: 'Crème', en: 'Cream' } },
        { type: 'photo', src: 'assets/products/zip-hoodie-black.jpg', fam: ['black'], sw: '#212524', name: { ar: 'أسود فحمي', fr: 'Noir anthracite', en: 'Charcoal black' } }
      ]
    }
  ]
};
