(function(){
  const state={coins:'200K',recipient:'Guest',username:'@guest',method:'Visa Card',txn:'',date:''};
  const defaultPackages=[
    ['10K','10K TikTok Coins','3,000 PKR'],['25K','25K TikTok Coins','5,000 PKR'],['50K','50K TikTok Coins','7,000 PKR'],['75K','75K TikTok Coins','10,500 PKR'],
    ['100K','100K TikTok Coins','14,000 PKR'],['200K','200K TikTok Coins','28,000 PKR'],['300K','300K TikTok Coins','42,000 PKR'],['400K','400K TikTok Coins','56,000 PKR'],
    ['500K','500K TikTok Coins','70,000 PKR'],['600K','600K TikTok Coins','84,000 PKR'],['700K','700K TikTok Coins','98,000 PKR'],['800K','800K TikTok Coins','112,000 PKR'],
    ['900K','900K TikTok Coins','126,000 PKR'],['1000K','1000K TikTok Coins','140,000 PKR']
  ];
  let packages=loadPackages();
  function loadPackages(){
    try{
      const raw=localStorage.getItem('ucPackages');
      if(raw){
        const parsed=JSON.parse(raw);
        if(Array.isArray(parsed)) return parsed.filter(x=>Array.isArray(x)&&x[0]);
      }
    }catch(e){}
    return defaultPackages.map(x=>x.slice());
  }
  function savePackages(){try{localStorage.setItem('ucPackages',JSON.stringify(packages))}catch(e){}}
  const $=id=>document.getElementById(id);
  const modal=id=>$(id);
  function show(id){modal(id).classList.add('show');modal(id).setAttribute('aria-hidden','false')}
  function hide(id){modal(id).classList.remove('show');modal(id).setAttribute('aria-hidden','true')}
  window.showToast=function(msg){const t=$('toast');t.textContent=msg;t.classList.add('show');clearTimeout(window.__toast);window.__toast=setTimeout(()=>t.classList.remove('show'),2800)};
  function makeTxn(){return 'TT-COINS-SIM-SUCCESSFUL-'+Math.random().toString(36).slice(2,8).toUpperCase()+'-'+Date.now().toString().slice(-4)}
  const txnDateFmt=new Intl.DateTimeFormat('en-PK',{timeZone:'Asia/Karachi',day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:true});
  function now(){return txnDateFmt.format(new Date())}
  function esc(v){return String(v??'').replace(/[&<>'"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;',"\"":'&quot;'}[m]))}
  function renderPackages(){
    const grid=$('packageGrid');
    grid.innerHTML=packages.map(([amount,label,price])=>{
      const priceHtml=price?`<div class="label">${esc(price)}</div>`:'';
      return `<article class="card package-card"><div class="coin coin-stack" aria-hidden="true"><div class="coin-art"><span class="silver-sheet"></span><span class="dp-badge tiktok-dp"><img src="assets/tiktok-dp.jpg" alt="TikTok DP" loading="lazy" decoding="async"></span><span class="dp-shine"></span></div></div><div class="amount">${esc(amount)}</div><div class="label">${esc(label||amount+' TikTok Coins')}</div>${priceHtml}<button class="buy" data-coins="${esc(amount)}" type="button">ACTIVATE COINS</button></article>`;
    }).join('');
    grid.querySelectorAll('.buy').forEach(b=>b.addEventListener('click',()=>openCheckout(b.dataset.coins)));
  }
  function renderPackManager(){
    const list=$('packManagerList');
    if(!list)return;
    list.innerHTML=packages.map(([amount,label,price],i)=>`<div class="pack-row" data-index="${i}"><input class="pack-coins" value="${esc(amount)}" placeholder="TikTok Coins amount"><input class="pack-price" value="${esc(price||'')}" placeholder="Price (optional)"><button class="pack-delete" type="button" data-delete="${i}">DELETE</button></div>`).join('');
    list.querySelectorAll('[data-delete]').forEach(btn=>btn.onclick=()=>{
      const i=Number(btn.dataset.delete); packages.splice(i,1); renderPackManager(); renderPackages();
    });
  }
  function readPackManager(){
    const rows=[...document.querySelectorAll('#packManagerList .pack-row')];
    const next=[];
    for(const row of rows){
      const amount=row.querySelector('.pack-coins').value.trim();
      const price=row.querySelector('.pack-price').value.trim();
      if(!amount)continue;
      next.push([amount,amount+' TikTok Coins',price]);
    }
    packages=next;
  }
  function fill(){
    $('checkoutCoins').textContent=state.coins;$('recipientPreview').textContent=state.recipient;$('usernamePreview').textContent=state.username;
    $('confirmName').textContent=state.recipient;$('confirmUser').textContent=state.username;$('confirmMethod').textContent=state.method;$('confirmCoins').textContent=state.coins;$('confirmDate').textContent=state.date;$('confirmTxn').textContent=state.txn;
    $('processingCoins').textContent=state.coins;$('processingUser').textContent=state.recipient;$('processingHandle').textContent=state.username;
    $('successName').textContent=state.recipient;$('successCoins').textContent=state.coins;$('successMethod').textContent=state.method;$('successDate').textContent=state.date;$('successTxn').textContent=state.txn;
  }
  function openCheckout(coins){state.coins=coins;state.recipient=state.username.replace(/^@/,'')||'Guest';$('recipient').value=state.recipient;fill();show('checkoutModal')}
  window.openCheckout=openCheckout;
  renderPackages();
  renderPackManager();
  $('addPackBtn')?.addEventListener('click',()=>{
    if(packages.length>=200){window.showToast('Maximum 200 TikTok Coin packs allowed.');return;}
    packages.push(['','New TikTok Coins','']);
    renderPackManager();
    const rows=document.querySelectorAll('#packManagerList .pack-row');
    rows[rows.length-1]?.querySelector('.pack-coins')?.focus();
  });
  $('addManyPackBtn')?.addEventListener('click',()=>{
    const input=$('packCountInput');
    let count=Math.max(1,Math.min(200,Number(input?.value)||10));
    const room=200-packages.length;
    count=Math.min(count,room);
    if(count<=0){window.showToast('Maximum 200 TikTok Coin packs allowed.');return;}
    for(let i=0;i<count;i++) packages.push(['','New TikTok Coins','']);
    renderPackManager();
    const rows=document.querySelectorAll('#packManagerList .pack-row');
    rows[rows.length-count]?.querySelector('.pack-coins')?.focus();
    window.showToast(count+' packs added.');
  });
  $('savePacksBtn')?.addEventListener('click',()=>{
    readPackManager();
    savePackages();
    renderPackages();
    renderPackManager();
    window.showToast('TikTok Coin packs saved.');
  });
  document.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>{hide('checkoutModal');hide('confirmModal');hide('processingModal');hide('successModal')});
  document.querySelectorAll('.pay-card').forEach(b=>b.onclick=()=>{document.querySelectorAll('.pay-card').forEach(x=>x.classList.remove('selected'));b.classList.add('selected');state.method=b.dataset.method;window.showToast('Selected '+state.method)});
  document.querySelectorAll('.virtual-card[data-demo-method]').forEach(card=>card.addEventListener('click',()=>{
    const method=card.dataset.demoMethod;
    document.querySelectorAll('.pay-card').forEach(x=>x.classList.toggle('selected',x.dataset.method===method));
    document.querySelectorAll('.virtual-card[data-demo-method]').forEach(x=>x.classList.remove('card-clicked'));
    card.classList.add('card-clicked');
    state.method=method;
    window.showToast('Selected '+method+' demo card');
  }));
  $('profileForm').addEventListener('submit',async e=>{
    e.preventDefault();
    const u=$('username').value.trim().replace(/^@/,'');
    if(!u){window.showToast('Enter a username first.');return}
    state.username='@'+u;state.recipient=u;
    $('profileResult').hidden=false;
    $('tokenlessMiniName').textContent=u;
    $('tokenlessMiniHandle').textContent='@'+u;
    $('profileStatus').textContent='TikTok profile • ONLINE COINS • displayed inside TikTok Coins Dealer';
    try{
      const r=await fetch('/api/tiktok-user?username='+encodeURIComponent(u),{headers:{'Accept':'application/json'}});
      if(!r.ok) throw new Error('lookup unavailable');
      const data=await r.json();
      const p=data.user||data.data?.user||data.data;
      if(!p) throw new Error('not found');
      $('tokenlessMiniName').textContent=(p.display_name||u)+(p.is_verified?' ✓':'');
      $('tokenlessMiniHandle').textContent='@'+(p.username||u);
      $('profileStatus').textContent='TikTok profile • ONLINE COINS • displayed inside TikTok Coins Dealer';
      window.showToast('TikTok profile loaded for @'+(p.username||u));
    }catch(err){
      $('profileStatus').textContent='TikTok profile lookup unavailable right now • ONLINE COINS';
      window.showToast('Username loaded. ONLINE COINS is active.');
    }
  });
  function fmt(v){return typeof v==='number'?new Intl.NumberFormat().format(v):'—'}
  $('checkoutBtn').onclick=()=>{
    const r=$('recipient').value.trim();
    if(!r){window.showToast('Enter a recipient name.');return}
    state.recipient=r;state.date=now();state.txn=makeTxn();fill();hide('checkoutModal');show('confirmModal');
  };
  let processingTimers=[];
  let countdownTimer=null;
  function clearProcessingTimers(){processingTimers.forEach(clearTimeout);processingTimers=[];if(countdownTimer){clearInterval(countdownTimer);countdownTimer=null}}
  function startActivationCountdown(seconds){
    const el=$('activationCountdown');
    if(!el)return;
    let left=seconds; el.textContent=left;
    if(countdownTimer)clearInterval(countdownTimer);
    countdownTimer=setInterval(()=>{left=Math.max(0,left-1);el.textContent=left;if(left===0){clearInterval(countdownTimer);countdownTimer=null}},1000);
  }
  function resetPaymentErrorUI(){
    const box=$('paymentErrorBox'), close=$('paymentErrorClose');
    if(box){box.hidden=true;box.textContent=''}
    if(close){close.hidden=true}
  }
  function stopWithPaymentError(){
    const box=$('paymentErrorBox'), close=$('paymentErrorClose'), text=$('processingText'), bar=$('progressBar');
    const message=window.getPaymentErrorMessage?window.getPaymentErrorMessage():'Demo payment failed. TikTok Coins activation stopped before completion.';
    bar.style.width='68%';
    text.textContent='Demo purchase stopped — payment error.';
    if(box){box.textContent=message;box.hidden=false}
    if(close){close.hidden=false;close.onclick=()=>hide('processingModal')}
    if(window.showToast)window.showToast('Demo payment error: purchase stopped.');
  }
  function paymentErrorIsOn(){return !!(window.isPaymentErrorEnabled&&window.isPaymentErrorEnabled())}
  function pieceFindIsOn(){
    const on=!!(window.isPieceFindEnabled&&window.isPieceFindEnabled());
    if(!on){
      const e=document.getElementById('pfFindError');
      const i=document.getElementById('pfInlineError');
      if(e)e.classList.remove('show');
      if(i)i.hidden=true;
    }
    return on;
  }
  function getPieceFindMessage(){
    const el=document.getElementById('pfErrorMessage');
    return (el&&el.value.trim())||'Piece Find नहीं हुआ। कृपया दोबारा कोशिश करें।';
  }
  function stopWithPieceFindError(){
    const box=$('paymentErrorBox'), close=$('paymentErrorClose'), text=$('processingText'), bar=$('progressBar');
    const message=getPieceFindMessage();
    bar.style.width='68%';
    text.textContent='Demo purchase stopped — Piece Find error.';
    if(box){box.textContent=message;box.hidden=false}
    if(close){close.hidden=false;close.onclick=()=>hide('processingModal')}
    if(window.showToast)window.showToast('Piece Find error: purchase stopped.');
  }
  window.stopPaymentProcessingWithPieceFindError=()=>{
    if($('processingModal')?.classList.contains('show')){
      clearProcessingTimers();
      stopWithPieceFindError();
    }
  };
  window.stopPaymentProcessingWithError=()=>{
    if($('processingModal')?.classList.contains('show')){
      clearProcessingTimers();
      stopWithPaymentError();
    }
  };
  $('confirmBtn').onclick=()=>{
    clearProcessingTimers();resetPaymentErrorUI();
    hide('confirmModal');show('processingModal');
    const bar=$('progressBar'), text=$('processingText');
    bar.style.width='4%';text.textContent='Preparing demo transaction…';
    startActivationCountdown(14);

    // If Payment Error is already ON, keep the purchase inside this processing
    // screen and stop it here instead of ever reaching the success screen.
    if(paymentErrorIsOn() || pieceFindIsOn()){
      processingTimers.push(setTimeout(()=>{
        bar.style.width='68%';
        if(paymentErrorIsOn()){
          clearProcessingTimers();
          text.textContent='TikTok Coins activation verification stopped — demo error.';
          stopWithPaymentError();
        }else{
          clearProcessingTimers();
          stopWithPieceFindError();
        }
      },3000));
      return;
    }

    processingTimers.push(setTimeout(()=>{
      if(paymentErrorIsOn()){ stopWithPaymentError(); clearProcessingTimers(); return; }
      if(pieceFindIsOn()){ stopWithPieceFindError(); clearProcessingTimers(); return; }
      bar.style.width='40%';text.textContent='Checking selected demo payment method…';
    },1800));
    processingTimers.push(setTimeout(()=>{
      if(paymentErrorIsOn()){ stopWithPaymentError(); clearProcessingTimers(); return; }
      if(pieceFindIsOn()){ stopWithPieceFindError(); clearProcessingTimers(); return; }
      bar.style.width='68%';text.textContent='Creating TikTok Coins activation order…';
    },5200));
    processingTimers.push(setTimeout(()=>{
      if(paymentErrorIsOn()){ stopWithPaymentError(); clearProcessingTimers(); return; }
      if(pieceFindIsOn()){ stopWithPieceFindError(); clearProcessingTimers(); return; }
      bar.style.width='88%';text.textContent='Finalizing TikTok Coins activation…';
    },8600));
    processingTimers.push(setTimeout(()=>{
      if(paymentErrorIsOn()){ stopWithPaymentError(); clearProcessingTimers(); return; }
      if(pieceFindIsOn()){ stopWithPieceFindError(); clearProcessingTimers(); return; }
      bar.style.width='100%';text.textContent='TikTok Coins activation completed…';
    },11200));
    processingTimers.push(setTimeout(()=>{
      if(paymentErrorIsOn()){ stopWithPaymentError(); clearProcessingTimers(); return; }
      if(pieceFindIsOn()){ stopWithPieceFindError(); clearProcessingTimers(); return; }
      hide('processingModal');fill();show('successModal');
      clearProcessingTimers();
    },14000));
  };
  $('homeBtn').onclick=()=>{hide('successModal');document.getElementById('packages').scrollIntoView({behavior:'smooth'});};
  window.addEventListener('keydown',e=>{if(e.key==='Escape'){hide('checkoutModal');hide('confirmModal');hide('processingModal');hide('successModal')}});
})();
