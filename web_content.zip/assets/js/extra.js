/* Analyse automatique, assistant IA (via proxy) et chat (via Supabase). Dépend de app.js (t, $, esc, api, gs, ss, N, fmt, data, COINS, toast). */
let aiH = [], room = gs('room', 'general');
const ROOMS = ['general', 'BTC', 'ETH', 'SOL'];

function rAi() {
  const u = gs('aiurl', '');
  $('#m').innerHTML = '<div class="card"><div class="big">' + t('aiAn') + '</div><div class="chips" style="margin:8px 0">' +
    COINS.slice(0, 8).map(c => '<button class="chip n" onclick="runAi(\'' + c + '\')">' + c + '</button>').join('') +
    '</div><div id="ao"></div><div class="lb">' + t('aiNote') + '</div></div>' +
    '<div class="card"><div class="big">' + t('aiChat') + '</div>' +
    (u ? '<div id="am" style="max-height:36vh;overflow-y:auto;margin:8px 0"></div><input id="ai" maxlength="500" placeholder="' + t('aiPh') + '"><button class="btn" onclick="sendAi()">' + t('send') + '</button>'
       : '<div class="lb" style="margin:8px 0">' + t('aiOff') + '</div>') +
    '<input id="au" type="url" style="margin-top:8px" placeholder="https://…" value="' + esc(u) + '"><button class="btn s" onclick="saveAi()">' + t('save') + '</button></div>';
  drawAm();
}
async function runAi(sym) {
  const o = $('#ao'); o.innerHTML = '<div class="lb">' + t('aiRun') + '</div>';
  try {
    const r = await api('/api/v3/klines?symbol=' + sym + 'USDT&interval=1h&limit=200');
    const s = Ind.summary(r.map(k => ({ h: +k[2], l: +k[3], c: +k[4] })));
    const tr = { up: t('trUp'), dn: t('trDn'), side: t('trSide') }[s.trend] || '—';
    const rs = s.rsi === null ? '—' : s.rsi > 70 ? t('rsiOb') : s.rsi < 30 ? t('rsiOs') : t('rsiNe');
    o.innerHTML = '<div class="card" style="margin:0 0 8px"><b>' + sym + '/USDT</b> ' + N('$' + fmt(s.price)) +
      '<br>' + t('trend') + ': <b>' + tr + '</b><br>RSI(14): ' + N(s.rsi === null ? '—' : s.rsi.toFixed(1)) + ' — ' + rs +
      '<br>SMA20 / SMA50: ' + N(fmt(s.sma20)) + ' / ' + N(s.sma50 === null ? '—' : fmt(s.sma50)) +
      '<br>' + t('supp') + ': ' + N(fmt(s.support)) + ' · ' + t('res') + ': ' + N(fmt(s.resist)) +
      '<br>' + t('volat') + ': ' + N(s.vol === null ? '—' : s.vol.toFixed(2) + '%') + '</div>';
  } catch (e) { o.innerHTML = '<div class="msg">' + t('anErr') + '</div>'; }
}
function saveAi() {
  const u = $('#au').value.trim();
  if (u && !/^https:\/\//.test(u)) return toast(t('httpsOnly'));
  ss('aiurl', u); aiH = []; rAi();
}
function drawAm() {
  const b = $('#am'); if (!b) return;
  b.innerHTML = aiH.map(m => '<div class="bub ' + (m.role === 'user' ? 'me' : '') + '">' + esc(m.content) + '</div>').join('');
  b.scrollTop = b.scrollHeight;
}
async function sendAi() {
  const i = $('#ai'), v = i.value.trim(); if (!v) return;
  i.value = ''; aiH.push({ role: 'user', content: v }); drawAm();
  const ctx = data.slice(0, 15).map(x => x.s + ' ' + fmt(x.p) + ' (' + x.c.toFixed(1) + '%)').join(', ');
  try {
    const ac = new AbortController(), to = setTimeout(() => ac.abort(), 30000);
    const r = await fetch(gs('aiurl', ''), { method: 'POST', headers: { 'Content-Type': 'application/json' }, signal: ac.signal,
      body: JSON.stringify({ messages: aiH.slice(-10), context: ctx, lang }) });
    clearTimeout(to); if (!r.ok) throw r.status;
    const d = await r.json(); aiH.push({ role: 'assistant', content: String(d.reply || '').slice(0, 4000) || t('aiErr') });
  } catch (e) { aiH.push({ role: 'assistant', content: t('aiErr') }); }
  drawAm();
}

/* ---- Chat (Supabase REST, interrogation toutes les 5 s) ---- */
const sb = () => { const u = gs('sbu', ''), k = gs('sbk', ''); return u && k ? { u: u.replace(/\/$/, ''), k } : null; };
async function sbf(path, opt) {
  const c = sb(), r = await fetch(c.u + '/rest/v1/' + path, Object.assign({}, opt, { headers: { apikey: c.k, Authorization: 'Bearer ' + c.k, 'Content-Type': 'application/json', Prefer: 'return=minimal' } }));
  if (!r.ok) throw r.status; return r.status === 201 || r.status === 204 ? null : r.json();
}
function rChat() {
  if (!sb()) {
    $('#m').innerHTML = '<div class="card"><div class="big">' + t('chat') + '</div><div class="lb" style="margin:8px 0">' + t('chatOff') + '</div><input id="su" type="url" placeholder="' + t('sbu') + '"><input id="sk" placeholder="' + t('sbk') + '"><button class="btn" onclick="saveSb()">' + t('save') + '</button></div>';
    return;
  }
  $('#m').innerHTML = '<div class="card"><select id="rm" onchange="room=this.value;ss(\'room\',room);loadMsgs()">' + ROOMS.map(r => '<option' + (r === room ? ' selected' : '') + '>' + r + '</option>').join('') +
    '</select><div id="cm" style="height:42vh;overflow-y:auto;margin-bottom:8px"></div><input id="cn" maxlength="20" placeholder="' + t('nick') + '" value="' + esc(gs('nick', '')) + '"><input id="cb" maxlength="500" placeholder="' + t('msgPh') + '"><button class="btn" onclick="sendMsg()">' + t('send') + '</button><div class="lb" style="margin-top:8px">' + t('chatNote') + '</div><button class="chip" style="margin-top:8px" onclick="ss(\'sbu\',\'\');ss(\'sbk\',\'\');rChat()">' + t('disc') + '</button></div>';
  loadMsgs(); window.chatT = setInterval(loadMsgs, 5000);
}
function saveSb() {
  const u = $('#su').value.trim(), k = $('#sk').value.trim();
  if (!/^https:\/\//.test(u) || !k) return toast(t('httpsOnly'));
  ss('sbu', u); ss('sbk', k); rChat();
}
async function loadMsgs() {
  const b = $('#cm'); if (!b) return;
  try {
    const r = await sbf('messages?room=eq.' + encodeURIComponent(room) + '&order=created_at.desc&limit=50&select=id,nick,body,created_at');
    b.innerHTML = r.length ? r.reverse().map(m => '<div class="bub ' + (m.nick === gs('nick', '') ? 'me' : '') + '"><small>' + esc(m.nick) + ' · ' + N(new Date(m.created_at).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })) + ' <a style="cursor:pointer" onclick="reportMsg(' + (+m.id) + ')">⚑</a></small>' + esc(m.body) + '</div>').join('') : '<div class="empty">' + t('noMsg') + '</div>';
    b.scrollTop = b.scrollHeight;
  } catch (e) { b.innerHTML = '<div class="msg">' + t('chatErr') + ' (' + esc(e) + ')</div>'; }
}
async function sendMsg() {
  const n = $('#cn').value.trim(), v = $('#cb').value.trim();
  if (n.length < 2) return toast(t('nickErr')); if (!v) return;
  ss('nick', n);
  try { await sbf('messages', { method: 'POST', body: JSON.stringify({ room, nick: n, body: v }) }); $('#cb').value = ''; loadMsgs(); }
  catch (e) { toast(t('chatErr') + ' (' + e + ')'); }
}
async function reportMsg(id) { try { await sbf('reports', { method: 'POST', body: JSON.stringify({ message_id: id }) }); toast(t('reported')); } catch (e) { toast(t('chatErr')); } }
