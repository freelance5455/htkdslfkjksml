/* Analyse automatique, assistant IA (via proxy) et chat (via Supabase). Dépend de app.js (t, $, esc, api, gs, ss, N, fmt, data, COINS, toast). */
let aiH = [], room = 'general';
const ROOMS = ['general', 'BTC', 'ETH', 'SOL'];

let aiSym = 'BTC', aiLast = null;
const aiUrl = () => gs('aiurl', '') || (window.APP_CONFIG && APP_CONFIG.AI_ENDPOINT) || '';
const aiChips = () => COINS.slice(0, 8).map(c => '<button class="chip n ' + (c === aiSym ? 'on' : '') + '" onclick="runAi(\'' + c + '\')">' + c + '</button>').join('');
function rAi() {
  const u = aiUrl();
  $('#m').innerHTML = '<div class="card"><div class="big">' + t('aiAn') + '</div><div class="chips" id="ac" style="margin:8px 0">' + aiChips() + '</div><div id="ao"></div><div class="lb">' + t('aiNote') + '</div></div>' +
    '<div class="card"><div class="big">' + t('cl') + '</div><div class="lb" style="margin:6px 0 10px">' + t('clNote') + '</div><input id="cq" maxlength="300" placeholder="' + t('clQ') + '"><button class="btn" onclick="consult()">' + t('clBtn') + '</button><div id="cp"></div></div>' +
    '<div class="card"><div class="big">' + t('aiChat') + '</div>' +
    (u ? '<div id="am" style="max-height:36vh;overflow-y:auto;margin:8px 0"></div><input id="ai" maxlength="500" placeholder="' + t('aiPh') + '"><button class="btn" onclick="sendAi()">' + t('send') + '</button>' : '<div class="lb" style="margin-top:6px">' + t('aiOff') + '</div>') +
    '<details style="margin-top:10px"><summary class="lb" style="cursor:pointer">' + t('adv') + '</summary><input id="au" type="url" style="margin-top:8px" placeholder="https://…" value="' + esc(gs('aiurl', '')) + '"><button class="btn s" onclick="saveAi()">' + t('save') + '</button></details></div>';
  drawAm(); runAi(aiSym);
}
const kv = (l, v) => '<div class="kv"><span class="lb">' + l + '</span><span>' + v + '</span></div>';
async function runAi(sym) {
  aiSym = sym; const ch = $('#ac'); if (ch) ch.innerHTML = aiChips();
  const o = $('#ao'); if (!o) return; o.innerHTML = '<div class="sk"></div>';
  try {
    const r = await api('/api/v3/klines?symbol=' + sym + 'USDT&interval=1h&limit=200');
    if (sym !== aiSym) return;
    const s = Ind.summary(r.map(k => ({ h: +k[2], l: +k[3], c: +k[4] })));
    const tr = { up: t('trUp'), dn: t('trDn'), side: t('trSide') }[s.trend] || '—';
    const rs = s.rsi === null ? '—' : s.rsi > 70 ? t('rsiOb') : s.rsi < 30 ? t('rsiOs') : t('rsiNe');
    aiLast = { sym, s, tr, rs };
    const f = v => v === null ? '—' : fmt(v);
    o.innerHTML = '<div style="margin-bottom:6px"><b>' + sym + '/USDT</b> ' + N('$' + fmt(s.price)) + ' <span class="pill ' + (s.trend === 'up' ? 'up' : s.trend === 'dn' ? 'dn' : '') + '">' + tr + '</span></div>' +
      (s.rsi === null ? '' : '<div class="rsi"><i style="left:' + s.rsi.toFixed(0) + '%"></i></div>') +
      kv('RSI(14)', N(s.rsi === null ? '—' : s.rsi.toFixed(1)) + ' · ' + rs) + kv('SMA20 / SMA50', N(f(s.sma20) + ' / ' + f(s.sma50))) +
      kv(t('supp'), N(f(s.support))) + kv(t('res'), N(f(s.resist))) + kv(t('volat'), N(s.vol === null ? '—' : s.vol.toFixed(2) + '%'));
  } catch (e) { if (sym === aiSym) o.innerHTML = '<div class="msg">' + t('anErr') + '</div>'; }
}
function buildPrompt(q) {
  const f = v => v === null ? '—' : fmt(v), L = [t('pIntro')];
  if (aiLast) { const a = aiLast, s = a.s;
    L.push(a.sym + '/USDT — $' + fmt(s.price), t('trend') + ': ' + a.tr, 'RSI(14): ' + (s.rsi === null ? '—' : s.rsi.toFixed(1)) + ' (' + a.rs + ')',
      'SMA20 / SMA50: ' + f(s.sma20) + ' / ' + f(s.sma50), t('supp') + ': ' + f(s.support) + ' · ' + t('res') + ': ' + f(s.resist), t('volat') + ': ' + (s.vol === null ? '—' : s.vol.toFixed(2) + '%'));
  } else if (data.length) L.push(data.slice(0, 8).map(x => x.s + ' ' + fmt(x.p) + ' (' + x.c.toFixed(1) + '%)').join(', '));
  L.push(t('pQ') + ' ' + (q || t('pDef')));
  return L.join('\n');
}
async function consult() {
  const p = buildPrompt($('#cq').value.trim()); let ok = false;
  try { await navigator.clipboard.writeText(p); ok = true; } catch (e) {}
  $('#cp').innerHTML = '<div class="lb" style="margin:10px 0 6px">' + t(ok ? 'cpOk' : 'cpManual') + '</div><textarea id="ct" readonly rows="7" onclick="this.select()">' + esc(p) + '</textarea>' +
    '<a class="btn" style="display:block;text-align:center;text-decoration:none;margin-top:8px" href="https://claude.ai/new" target="_blank" rel="noopener">' + t('clOpen') + '</a>';
}
function saveAi() {
  const u = $('#au').value.trim();
  if (u && !/^https:\/\//.test(u)) return toast(t('httpsOnly'));
  ss('aiurl', u); aiH = []; rAi();
}
function drawAm() {
  const b = $('#am'); if (!b) return;
  b.innerHTML = aiH.map(m => '<div class="bub ' + (m.role === 'user' ? 'me' : '') + '">' + esc(m.content) + '</div>').join('');
  b.scrollTop = b.scrollHeight;
}
async function sendAi() {
  const i = $('#ai'), v = i.value.trim(); if (!v) return;
  i.value = ''; aiH.push({ role: 'user', content: v }); drawAm();
  const ctx = data.slice(0, 15).map(x => x.s + ' ' + fmt(x.p) + ' (' + x.c.toFixed(1) + '%)').join(', ');
  try {
    const ac = new AbortController(), to = setTimeout(() => ac.abort(), 30000);
    const r = await fetch(aiUrl(), { method: 'POST', headers: { 'Content-Type': 'application/json' }, signal: ac.signal,
      body: JSON.stringify({ messages: aiH.slice(-10), context: ctx, lang }) });
    clearTimeout(to); if (!r.ok) throw r.status;
    const d = await r.json(); aiH.push({ role: 'assistant', content: String(d.reply || '').slice(0, 4000) || t('aiErr') });
  } catch (e) { aiH.push({ role: 'assistant', content: t('aiErr') }); }
  drawAm();
}

/* ---- Chat (Supabase REST, interrogation toutes les 5 s) ---- */
const sb = () => { const u = gs('sbu', ''), k = gs('sbk', ''); return u && k ? { u: u.replace(/\/$/, ''), k } : null; };
async function sbf(path, opt) {
  const c = sb(), r = await fetch(c.u + '/rest/v1/' + path, Object.assign({}, opt, { headers: { apikey: c.k, Authorization: 'Bearer ' + c.k, 'Content-Type': 'application/json', Prefer: 'return=minimal' } }));
  if (!r.ok) throw r.status; return r.status === 201 || r.status === 204 ? null : r.json();
}
function rChat() {
  room = gs('room', 'general');
  if (!sb()) {
    $('#m').innerHTML = '<div class="card"><div class="big">' + t('chat') + '</div><div class="lb" style="margin:8px 0">' + t('chatOff') + '</div><input id="su" type="url" placeholder="' + t('sbu') + '"><input id="sk" placeholder="' + t('sbk') + '"><button class="btn" onclick="saveSb()">' + t('save') + '</button></div>';
    return;
  }
  $('#m').innerHTML = '<div class="card"><select id="rm" onchange="room=this.value;ss(\'room\',room);loadMsgs()">' + ROOMS.map(r => '<option' + (r === room ? ' selected' : '') + '>' + r + '</option>').join('') +
    '</select><div id="cm" style="height:42vh;overflow-y:auto;margin-bottom:8px"></div><input id="cn" maxlength="20" placeholder="' + t('nick') + '" value="' + esc(gs('nick', '')) + '"><input id="cb" maxlength="500" placeholder="' + t('msgPh') + '"><button class="btn" onclick="sendMsg()">' + t('send') + '</button><div class="lb" style="margin-top:8px">' + t('chatNote') + '</div><button class="chip" style="margin-top:8px" onclick="ss(\'sbu\',\'\');ss(\'sbk\',\'\');rChat()">' + t('disc') + '</button></div>';
  loadMsgs(); window.chatT = setInterval(loadMsgs, 5000);
}
function saveSb() {
  const u = $('#su').value.trim(), k = $('#sk').value.trim();
  if (!/^https:\/\//.test(u) || !k) return toast(t('httpsOnly'));
  ss('sbu', u); ss('sbk', k); rChat();
}
async function loadMsgs() {
  const b = $('#cm'); if (!b) return;
  try {
    const r = await sbf('messages?room=eq.' + encodeURIComponent(room) + '&order=created_at.desc&limit=50&select=id,nick,body,created_at');
    b.innerHTML = r.length ? r.reverse().map(m => '<div class="bub ' + (m.nick === gs('nick', '') ? 'me' : '') + '"><small>' + esc(m.nick) + ' · ' + N(new Date(m.created_at).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })) + ' <a style="cursor:pointer" onclick="reportMsg(' + (+m.id) + ')">⚑</a></small>' + esc(m.body) + '</div>').join('') : '<div class="empty">' + t('noMsg') + '</div>';
    b.scrollTop = b.scrollHeight;
  } catch (e) { b.innerHTML = '<div class="msg">' + t('chatErr') + ' (' + esc(e) + ')</div>'; }
}
async function sendMsg() {
  const n = $('#cn').value.trim(), v = $('#cb').value.trim();
  if (n.length < 2) return toast(t('nickErr')); if (!v) return;
  ss('nick', n);
  try { await sbf('messages', { method: 'POST', body: JSON.stringify({ room, nick: n, body: v }) }); $('#cb').value = ''; loadMsgs(); }
  catch (e) { toast(t('chatErr') + ' (' + e + ')'); }
}
async function reportMsg(id) { try { await sbf('reports', { method: 'POST', body: JSON.stringify({ message_id: id }) }); toast(t('reported')); } catch (e) { toast(t('chatErr')); } }

/* ---- Graphique de l'accueil, menu ☰, bienvenue ---- */
let hs = 'BTC', hp = '1D', hm = 'c', hk = [], hT = 0;
function homeChart() {
  const ch = (on, fn, l, n) => '<button class="chip ' + (n ? 'n ' : '') + (on ? 'on' : '') + '" onclick="' + fn + '">' + l + '</button>';
  return '<div class="card"><div class="chips">' + ['BTC', 'ETH', 'BNB', 'SOL'].map(c => ch(hs === c, "hs='" + c + "';hload()", c, 1)).join('') + '</div><div class="chips">' +
    Object.keys(PER).map(k => ch(hp === k, "hp='" + k + "';hload()", k, 1)).join('') + ch(hm === 'c', "hm='c';rHome()", t('candle')) + ch(hm === 'l', "hm='l';rHome()", t('line')) +
    '</div><canvas id="hcv" style="height:220px"></canvas><div id="hce" class="msg" style="display:none;margin-top:10px">' + t('chartErr') + '</div></div>';
}
function hdraw() { drawOn($('#hcv'), hk, hm); }
async function hload() {
  const s = hs, p = hp; hT = Date.now(); hk = [];
  if (tab === 'home') rHome();
  try {
    const [i, l] = PER[p], r = await api('/api/v3/klines?symbol=' + s + 'USDT&interval=' + i + '&limit=' + l);
    if (s !== hs || p !== hp) return;
    hk = r.map(k => ({ t: k[0], o: +k[1], h: +k[2], l: +k[3], c: +k[4] })); hdraw();
  } catch (e) { const c = $('#hce'); if (c && s === hs) c.style.display = 'block'; }
}
function menu() {
  let m = $('#mn');
  if (!m) { m = document.createElement('div'); m.id = 'mn'; m.onclick = e => { if (e.target === m) closeMenu(); }; document.body.appendChild(m); }
  m.innerHTML = '<div class="dr"><div class="big" style="margin-bottom:8px">Crypto Max <b style="color:var(--ct)">PRO</b></div>' +
    [['rewards', '✦'], ['alerts', '◔'], ['settings', '⚙']].map(x => '<button onclick="go(\'' + x[0] + '\')"><span>' + x[1] + '</span>' + t(x[0]) + '</button>').join('') +
    '<button onclick="toggleTheme()"><span>◐</span>' + t('themeT') + '</button><button onclick="closeMenu();welcome(0)"><span>?</span>' + t('how') + '</button></div>';
  m.classList.add('on');
}
function closeMenu() { const m = $('#mn'); if (m) m.classList.remove('on'); }
function setLang(l) { lang = l; ss('lang', l); applyLang(); nav(); status(); render(); }
function welcome(i) {
  let w = $('#wl');
  if (!w) { w = document.createElement('div'); w.id = 'wl'; document.body.appendChild(w); }
  w.classList.add('on');
  const ic = ['◆', '◈', '✧', '☰'], last = i === 3;
  w.innerHTML = '<div class="wi"><div class="ic">' + ic[i] + '</div><h2>' + t('w' + (i + 1) + 't') + '</h2><p class="lb" style="font-size:15px;line-height:1.9">' + t('w' + (i + 1) + 'b') + '</p>' +
    (i === 0 ? '<div class="chips" style="justify-content:center">' + [['ar', 'العربية'], ['fr', 'Français'], ['en', 'English']].map(l => '<button class="chip ' + (lang === l[0] ? 'on' : '') + '" onclick="setLang(\'' + l[0] + '\');welcome(0)">' + l[1] + '</button>').join('') + '</div>' : '') +
    '</div><div class="dots" style="text-align:center;margin-bottom:14px">' + [0, 1, 2, 3].map(k => '<span class="' + (k === i ? 'on' : '') + '"></span>').join('') + '</div>' +
    '<button class="btn" onclick="' + (last ? 'endWelcome()' : 'welcome(' + (i + 1) + ')') + '">' + t(last ? 'start' : 'next') + '</button>' +
    (last ? '' : '<button class="btn s" style="margin-top:8px" onclick="endWelcome()">' + t('skip') + '</button>');
}
function endWelcome() { ss('welcomed', '1'); const w = $('#wl'); if (w) w.classList.remove('on'); }

/* ---- Thème jour / nuit ---- */
function effTheme() {
  const v = gs('theme', 'dark');
  return v === 'auto' ? (typeof matchMedia === 'function' && matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark') : v;
}
function applyTheme() {
  const e = effTheme(); document.documentElement.setAttribute('data-theme', e);
  const m = document.querySelector('meta[name=theme-color]'); if (m) m.setAttribute('content', e === 'light' ? '#FFFFFF' : '#0B0E11');
}
function setTheme(v) { ss('theme', v); applyTheme(); render(); if (cur) draw(); }
function toggleTheme() { setTheme(effTheme() === 'light' ? 'dark' : 'light'); closeMenu(); }
