const COINS=['BTC','ETH','BNB','SOL','XRP','ADA','DOGE','TRX','AVAX','LINK','DOT','LTC','TON','BCH','SHIB'];
const HOSTS=['https://api.binance.com','https://data-api.binance.vision'];
const T=window.LOCALES;
const $=s=>document.querySelector(s);
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const gs=(k,d)=>{try{const v=localStorage.getItem(k);return v===null?d:v}catch(e){return d}};
const ss=(k,v)=>{try{localStorage.setItem(k,v)}catch(e){}};
const js=(k,d)=>{try{return JSON.parse(gs(k,''))||d}catch(e){return d}};
let lang=gs('lang','ar'),tab='home',filt='all',q='',data=[],host=HOSTS[0],loading=false,errKey='',upd=null,
favs=js('favs',[]),al=js('al',[]),rw=js('rw',[]),cur=null,per='1D',mode='c',ks=[];
const t=k=>T[lang][k]||T.en[k]||k;
const fmt=n=>n>=1?n.toLocaleString('en-US',{maximumFractionDigits:2}):Number(n).toPrecision(4);
const N=x=>'<span class="n">'+x+'</span>';
const pct=c=>'<span class="pill n '+(c>=0?'up':'dn')+'">'+(c>=0?'+':'')+c.toFixed(2)+'%</span>';
function applyLang(){document.documentElement.lang=lang;document.documentElement.dir=lang==='ar'?'rtl':'ltr'}
async function api(p){let last;for(const h of [host,...HOSTS.filter(x=>x!==host)]){try{const r=await fetch(h+p,{cache:'no-store'});if(r.status==429||r.status==418)throw 'rate';if(!r.ok)throw r.status;host=h;return await r.json()}catch(e){last=e;if(last==='rate')break}}throw last}
async function load(){if(loading)return;loading=true;errKey='';status();
try{const d=await api('/api/v3/ticker/24hr?symbols='+encodeURIComponent(JSON.stringify(COINS.map(c=>c+'USDT'))));
data=d.map(x=>({s:x.symbol.slice(0,-4),p:+x.lastPrice,c:+x.priceChangePercent,h:+x.highPrice,l:+x.lowPrice,v:+x.quoteVolume}));upd=new Date();checkAlerts()}
catch(e){errKey=e==='rate'?'rate':'err'}
loading=false;status();if(tab==='home')render();if(cur)head()}
function status(){const s=$('#st');s.className=errKey?'bad':'';
s.innerHTML=loading?t('loading'):errKey?'⚠ '+t(errKey):upd?t('updated')+' '+N(upd.toLocaleTimeString('en-GB')):''}
function nav(){const ic={home:'◈',ai:'✧',chat:'✉',rewards:'✦',alerts:'◔',settings:'⚙'};
$('#nav').innerHTML=Object.keys(ic).map(k=>'<button class="'+(tab===k?'on':'')+'" onclick="go(\''+k+'\')"><div>'+ic[k]+'</div>'+t(k)+'</button>').join('')}
function go(k){clearInterval(window.chatT);tab=k;nav();render();$('#m').scrollTop=0}
function render(){({home:rHome,ai:rAi,chat:rChat,rewards:rRew,alerts:rAl,settings:rSet})[tab]()}
function rHome(){
let h='';
if(errKey)h+='<div class="msg">'+t(errKey)+(data.length?'<br>'+t('stale'):'')+'<br><button class="btn s" onclick="load()">'+t('retry')+'</button></div>';
if(!data.length&&!errKey){h+='<div class="sk"></div>'.repeat(6)}
else if(data.length){
const by=[...data].sort((a,b)=>b.c-a.c),btc=data.find(x=>x.s==='BTC'),eth=data.find(x=>x.s==='ETH');
const sm=(x,l)=>x?'<div class="card"><div class="lb">'+l+'</div><div class="big">'+esc(x.s)+'</div>'+N('$'+fmt(x.p))+' '+pct(x.c)+'</div>':'';
h+='<div class="grid">'+sm(btc,'BTC')+sm(eth,'ETH')+sm(by[0],t('top'))+sm(by[by.length-1],t('bot'))+'</div>';
h+='<input id="q" type="search" placeholder="'+t('search')+'" value="'+esc(q)+'" oninput="q=this.value;list()">';
h+='<div class="chips"><button class="chip '+(filt==='all'?'on':'')+'" onclick="filt=\'all\';render()">'+t('all')+'</button><button class="chip '+(filt==='fav'?'on':'')+'" onclick="filt=\'fav\';render()">★ '+t('favs')+'</button></div><div class="card" id="ls"></div>'}
$('#m').innerHTML=h;if(data.length)list()}
function list(){let a=data.filter(x=>x.s.toLowerCase().includes(q.trim().toLowerCase()));if(filt==='fav')a=a.filter(x=>favs.includes(x.s));
$('#ls').innerHTML=a.length?a.map(x=>'<div class="row" onclick="openDet(\''+x.s+'\')"><button class="star '+(favs.includes(x.s)?'on':'')+'" onclick="event.stopPropagation();fav(\''+x.s+'\')" aria-label="★">★</button><div class="sy">'+esc(x.s)+'<small>USDT</small></div><div class="pr">'+N('$'+fmt(x.p))+'<br>'+pct(x.c)+'</div></div>').join(''):'<div class="empty">'+(filt==='fav'&&!favs.length?t('noFav'):t('noData'))+'</div>'}
function fav(s){favs=favs.includes(s)?favs.filter(x=>x!==s):[...favs,s];ss('favs',JSON.stringify(favs));list()}
const PER={'1H':['1m',60],'1D':['15m',96],'1W':['1h',168],'1M':['4h',180],'1Y':['1d',365]};
function openDet(s){cur=s;$('#det').classList.add('on');head();chart()}
function closeDet(){cur=null;$('#det').classList.remove('on')}
function head(){const x=data.find(d=>d.s===cur);if(!x)return;
$('#det').innerHTML='<button class="chip" style="align-self:flex-start;margin-bottom:10px" onclick="closeDet()">'+(lang==='ar'?'→ ':'← ')+t('close')+'</button><div class="card"><div class="lb">'+esc(cur)+'/USDT</div><div class="big">'+N('$'+fmt(x.p))+'</div>'+pct(x.c)+'<div class="lb" style="margin-top:8px">'+t('high')+' '+N(fmt(x.h))+' · '+t('low')+' '+N(fmt(x.l))+'<br>'+t('vol')+' '+N(Math.round(x.v).toLocaleString('en-US'))+'</div></div><div class="chips">'+Object.keys(PER).map(k=>'<button class="chip n '+(per===k?'on':'')+'" onclick="per=\''+k+'\';head();chart()">'+k+'</button>').join('')+'<button class="chip '+(mode==='c'?'on':'')+'" onclick="mode=\'c\';head();draw()">'+t('candle')+'</button><button class="chip '+(mode==='l'?'on':'')+'" onclick="mode=\'l\';head();draw()">'+t('line')+'</button></div><div class="lb n" id="oh" style="min-height:22px">&nbsp;</div><canvas id="cv"></canvas><div id="ce" class="msg" style="display:none;margin-top:10px">'+t('chartErr')+'</div>';bind()}
async function chart(){ks=[];try{const[i,l]=PER[per];const r=await api('/api/v3/klines?symbol='+cur+'USDT&interval='+i+'&limit='+l);ks=r.map(k=>({t:k[0],o:+k[1],h:+k[2],l:+k[3],c:+k[4]}));draw()}catch(e){const c=$('#ce');if(c)c.style.display='block'}}
function draw(){const cv=$('#cv');if(!cv||!ks.length)return;const d=window.devicePixelRatio||1,w=cv.clientWidth,h=cv.clientHeight;cv.width=w*d;cv.height=h*d;const x=cv.getContext('2d');x.scale(d,d);
const hi=Math.max(...ks.map(a=>a.h)),lo=Math.min(...ks.map(a=>a.l)),P=8,Y=v=>P+(hi-v)/(hi-lo||1)*(h-2*P),bw=w/ks.length;
x.strokeStyle='#2B3139';x.fillStyle='#848E9C';x.font='10px sans-serif';
for(let i=0;i<5;i++){const y=P+i*(h-2*P)/4;x.beginPath();x.moveTo(0,y);x.lineTo(w,y);x.stroke();x.fillText(fmt(hi-(hi-lo)*i/4),4,y-2)}
if(mode==='c')ks.forEach((k,i)=>{const cx=(i+.5)*bw,u=k.c>=k.o;x.strokeStyle=x.fillStyle=u?'#0ECB81':'#F6465D';x.beginPath();x.moveTo(cx,Y(k.h));x.lineTo(cx,Y(k.l));x.stroke();const a=Y(Math.max(k.o,k.c)),b=Math.max(1,Math.abs(Y(k.o)-Y(k.c)));x.fillRect(cx-Math.max(.6,bw*.32),a,Math.max(1.2,bw*.64),b)});
else{x.beginPath();ks.forEach((k,i)=>{const cx=(i+.5)*bw;i?x.lineTo(cx,Y(k.c)):x.moveTo(cx,Y(k.c))});x.strokeStyle='#F0B90B';x.lineWidth=2;x.stroke();x.lineTo(w,h);x.lineTo(0,h);const g=x.createLinearGradient(0,0,0,h);g.addColorStop(0,'rgba(240,185,11,.25)');g.addColorStop(1,'rgba(240,185,11,0)');x.fillStyle=g;x.fill()}}
function bind(){const cv=$('#cv'),f=e=>{if(!ks.length)return;const r=cv.getBoundingClientRect(),i=Math.min(ks.length-1,Math.max(0,Math.floor((e.clientX-r.left)/r.width*ks.length))),k=ks[i];$('#oh').textContent=new Date(k.t).toLocaleString('en-GB',{dateStyle:'short',timeStyle:'short'})+'  O '+fmt(k.o)+'  H '+fmt(k.h)+'  L '+fmt(k.l)+'  C '+fmt(k.c)};cv.addEventListener('pointermove',f);cv.addEventListener('pointerdown',f)}
window.addEventListener('resize',()=>{if(cur)draw()});
function toast(m){const e=$('#toast');e.textContent=m;e.style.display='block';clearTimeout(toast.i);toast.i=setTimeout(()=>e.style.display='none',5000)}
function checkAlerts(){let ch=false;al.forEach(a=>{if(a.done)return;const c=data.find(d=>d.s===a.s);if(!c)return;if((a.t==='a'&&c.p>=a.p)||(a.t==='b'&&c.p<=a.p)){a.done=true;ch=true;const m='🔔 '+t('hit')+' '+a.s+' '+fmt(a.p)+' USDT';toast(m);try{if(window.Notification&&Notification.permission==='granted')new Notification('Crypto Max PRO',{body:m})}catch(e){}}});if(ch){ss('al',JSON.stringify(al));if(tab==='alerts')rAl()}}
function rAl(){$('#m').innerHTML='<div class="card"><select id="as">'+COINS.map(c=>'<option>'+c+'</option>').join('')+'</select><select id="at"><option value="a">'+t('above')+'</option><option value="b">'+t('below')+'</option></select><input id="ap" type="number" inputmode="decimal" step="any" min="0" placeholder="'+t('price')+'"><button class="btn" onclick="addAl()">'+t('add')+'</button><div class="lb" style="margin-top:8px">'+t('alNote')+'</div></div><div class="card">'+(al.length?al.map((a,i)=>'<div class="row" style="cursor:default"><div class="sy">'+esc(a.s)+'<small>'+(a.t==='a'?t('above'):t('below'))+' '+N(fmt(a.p))+(a.done?' ✓':'')+'</small></div><button class="chip" onclick="al.splice('+i+',1);ss(\'al\',JSON.stringify(al));rAl()">'+t('del')+'</button></div>').join(''):'<div class="empty">'+t('noAl')+'</div>')+'</div>'}
function addAl(){const p=parseFloat($('#ap').value);if(!(p>0))return;al.push({s:$('#as').value,t:$('#at').value,p,done:false});ss('al',JSON.stringify(al));rAl();checkAlerts()}
function rRew(){$('#m').innerHTML='<div class="card"><div class="lb" style="margin-bottom:8px">'+t('rwNote')+'</div><input id="rn" maxlength="80" placeholder="'+t('name')+'"><input id="rc" maxlength="200" placeholder="'+t('cond')+'"><input id="rm" maxlength="40" placeholder="'+t('minW')+'"><button class="btn" onclick="addRw()">'+t('add')+'</button></div><div class="card">'+(rw.length?rw.map((r,i)=>'<div class="row" style="cursor:default;align-items:flex-start"><div class="sy">'+esc(r.n)+'<small>'+esc(r.c)+(r.m?' · '+esc(r.m):'')+'</small></div><select style="width:auto;margin:0" onchange="rw['+i+'].s=this.value;ss(\'rw\',JSON.stringify(rw))">'+[1,2,3].map(k=>'<option value="'+k+'"'+(r.s==k?' selected':'')+'>'+t('s'+k)+'</option>').join('')+'</select><button class="chip" onclick="rw.splice('+i+',1);ss(\'rw\',JSON.stringify(rw));rRew()">'+t('del')+'</button></div>').join(''):'<div class="empty">'+t('noRw')+'</div>')+'</div>'}
function addRw(){const n=$('#rn').value.trim();if(!n)return;rw.push({n,c:$('#rc').value.trim(),m:$('#rm').value.trim(),s:1});ss('rw',JSON.stringify(rw));rRew()}
function rSet(){const np=window.Notification?Notification.permission:'none';
$('#m').innerHTML='<div class="card"><div class="lb">'+t('lang')+'</div><select onchange="lang=this.value;ss(\'lang\',lang);applyLang();nav();status();rSet()">'+[['ar','العربية'],['fr','Français'],['en','English']].map(l=>'<option value="'+l[0]+'"'+(lang===l[0]?' selected':'')+'>'+l[1]+'</option>').join('')+'</select></div><div class="card"><button class="btn s" onclick="askN()">'+(np==='granted'?'✓ '+t('notifOk'):t('notif'))+'</button>'+(np==='denied'||np==='none'?'<div class="lb" style="margin-top:8px">'+t('notifNo')+'</div>':'')+'</div><div class="card"><div class="big">'+t('about')+'</div><p style="margin-top:6px">Crypto Max PRO</p><div class="lb">'+t('author')+': Bilel Fridhi<br>'+t('ver')+': '+N('1.1.0')+'</div><p class="lb" style="margin-top:10px">'+t('data')+'</p><div class="sig" style="margin-top:8px">Crypto Max PRO <b>By Bilel Fridhi</b></div></div>'}
async function askN(){try{if(window.Notification)await Notification.requestPermission()}catch(e){}rSet()}
applyLang();nav();render();status();load();
setInterval(()=>{if(!document.hidden)load()},30000);
window.addEventListener('online',load);
