/* LUMAY BUSINESS — protótipo de loja. Dados de demonstração; sem backend. */
'use strict';

const DEFAULT_PRODUCTS = [
  {id:1,name:'Notebook HP 15',price:72000,category:'Computadores',icon:'💻'},
  {id:2,name:'Smartphone 128GB',price:125000,category:'Telefones',icon:'📱'},
  {id:3,name:'Fone Bluetooth JBL',price:8500,category:'Áudio',icon:'🎧'},
  {id:4,name:'Tênis desportivo',price:12000,category:'Calçados',icon:'👟'},
  {id:5,name:'Relógio Smart',price:95000,category:'Relógios',icon:'⌚'},
  {id:6,name:'Peruca Premium',price:18000,category:'Beleza',icon:'💇'},
  {id:7,name:'Mochila Executiva',price:6500,category:'Pastas',icon:'🎒'},
  {id:8,name:'Camiseta Casual',price:3500,category:'Roupas',icon:'👕'}
];
const PRODUCT_KEY = 'lumay_products_v1';
const CART_KEY = 'lumay_cart_v1';
const WA_NUMBER = '244926247359';
let activeCategory = 'Todos';
let products = readStorage(PRODUCT_KEY, DEFAULT_PRODUCTS);
let cart = readStorage(CART_KEY, []);

function readStorage(key, fallback) {
  try {
    const value = localStorage.getItem(key);
    return value ? JSON.parse(value) : structuredClone(fallback);
  } catch (error) {
    console.warn('Não foi possível ler os dados locais:', key, error);
    return structuredClone(fallback);
  }
}
function writeStorage(key, value) {
  try { localStorage.setItem(key, JSON.stringify(value)); return true; }
  catch (error) { console.error('Não foi possível guardar os dados:', error); showToast('Não foi possível guardar os dados neste dispositivo.'); return false; }
}
function money(value) {
  return new Intl.NumberFormat('pt-AO', {maximumFractionDigits:0}).format(value) + ' Kz';
}
function showToast(message) {
  const toast = document.getElementById('toast');
  if (!toast) return;
  toast.textContent = message;
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => { toast.textContent = ''; }, 2600);
}
function saveCart() {
  writeStorage(CART_KEY, cart);
  const count = document.getElementById('cart-count');
  if (count) count.textContent = cart.reduce((sum, item) => sum + item.quantity, 0);
}
function renderCategories() {
  const target = document.getElementById('categories');
  const categories = ['Todos', ...new Set(products.map(p => p.category))];
  target.innerHTML = categories.map(category =>
    `<button class="category-chip ${activeCategory === category ? 'active' : ''}" data-category="${escapeHTML(category)}">${category === 'Todos' ? '🛍️ ' : ''}${escapeHTML(category)}</button>`
  ).join('');
}
function renderProducts() {
  const query = document.getElementById('search').value.trim().toLocaleLowerCase('pt-AO');
  const list = products.filter(p =>
    (activeCategory === 'Todos' || p.category === activeCategory) &&
    p.name.toLocaleLowerCase('pt-AO').includes(query)
  );
  const target = document.getElementById('products');
  if (!list.length) {
    target.innerHTML = '<div class="empty-state">Não encontrámos produtos para esta pesquisa.</div>';
    return;
  }
  target.innerHTML = list.map(p => `
    <article class="product-card">
      <div class="product-image" aria-hidden="true">${escapeHTML(p.icon || '📦')}</div>
      <div class="product-body">
        <p class="product-category">${escapeHTML(p.category)}</p>
        <h3>${escapeHTML(p.name)}</h3>
        <div class="product-price">${money(p.price)}</div>
        <button class="button button-primary" data-add="${Number(p.id)}">Adicionar ao carrinho</button>
      </div>
    </article>`).join('');
}
function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
}
function addToCart(id) {
  const product = products.find(p => p.id === Number(id));
  if (!product) return;
  const item = cart.find(p => p.id === product.id);
  if (item) item.quantity += 1;
  else cart.push({id:product.id, name:product.name, price:product.price, icon:product.icon, quantity:1});
  saveCart();
  showToast('Produto adicionado ao carrinho.');
}
function renderCart() {
  const target = document.getElementById('cart-items');
  if (!cart.length) target.innerHTML = '<div class="empty-state">O carrinho está vazio.</div>';
  else target.innerHTML = cart.map(item => `
    <div class="cart-line">
      <div><strong>${escapeHTML(item.icon || '📦')} ${escapeHTML(item.name)}</strong><small>${money(item.price)} por unidade</small></div>
      <div class="quantity-controls">
        <button data-change="${item.id}" data-delta="-1" aria-label="Diminuir quantidade">−</button>
        <span>${item.quantity}</span>
        <button data-change="${item.id}" data-delta="1" aria-label="Aumentar quantidade">+</button>
      </div>
    </div>`).join('');
  document.getElementById('cart-total').textContent = money(cart.reduce((sum, item) => sum + item.price * item.quantity, 0));
}
function openCart() {
  renderCart();
  document.getElementById('cart-overlay').hidden = false;
  document.body.style.overflow = 'hidden';
}
function closeCart() {
  document.getElementById('cart-overlay').hidden = true;
  document.body.style.overflow = '';
}
function changeQuantity(id, delta) {
  const item = cart.find(p => p.id === Number(id));
  if (!item) return;
  item.quantity += Number(delta);
  if (item.quantity <= 0) cart = cart.filter(p => p.id !== Number(id));
  saveCart();
  renderCart();
}
function sendWhatsApp(event) {
  event.preventDefault();
  if (!cart.length) { showToast('Adicione pelo menos um produto.'); return; }
  const form = new FormData(event.currentTarget);
  const name = String(form.get('name') || '').trim();
  const phone = String(form.get('phone') || '').trim();
  const address = String(form.get('address') || '').trim();
  if (!name || !phone || !address) { showToast('Preencha todos os campos.'); return; }
  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const lines = cart.map(item => `• ${item.name} x${item.quantity} — ${money(item.price * item.quantity)}`);
  const message = [
    'Olá, LUMAY BUSINESS! Quero fazer um pedido:',
    '',
    ...lines,
    '',
    `Total estimado: ${money(total)}`,
    `Nome: ${name}`,
    `Telefone: ${phone}`,
    `Endereço: ${address}`,
    '',
    'Por favor, confirmem a disponibilidade e a entrega.'
  ].join('\n');
  const url = `https://wa.me/${WA_NUMBER}?text=${encodeURIComponent(message)}`;
  window.open(url, '_blank', 'noopener,noreferrer');
}
document.addEventListener('click', event => {
  const category = event.target.closest('[data-category]');
  if (category) {
    activeCategory = category.dataset.category;
    renderCategories(); renderProducts();
  }
  const add = event.target.closest('[data-add]');
  if (add) addToCart(add.dataset.add);
  const change = event.target.closest('[data-change]');
  if (change) changeQuantity(change.dataset.change, change.dataset.delta);
});
document.getElementById('search').addEventListener('input', renderProducts);
document.getElementById('cart-open').addEventListener('click', openCart);
document.getElementById('cart-open-bottom').addEventListener('click', openCart);
document.getElementById('cart-close').addEventListener('click', closeCart);
document.getElementById('cart-overlay').addEventListener('click', event => {
  if (event.target.id === 'cart-overlay') closeCart();
});
document.getElementById('checkout-form').addEventListener('submit', sendWhatsApp);
document.getElementById('year').textContent = new Date().getFullYear();
renderCategories(); renderProducts(); saveCart();
