// Proves scripts execute inside the packaged WebView, and that relative asset
// paths still resolve once the ZIP has been unpacked by the app.
document.addEventListener('DOMContentLoaded', function () {
  var n = document.querySelectorAll('img').length;
  var el = document.getElementById('imgcount');
  if (el) el.textContent = n;
  var b = document.getElementById('ping');
  if (b) b.addEventListener('click', function () {
    document.getElementById('out').textContent =
      'JS OK · ' + n + ' images on this screen · ' + new Date().toLocaleTimeString();
  });
  var bad = 0;
  document.querySelectorAll('img').forEach(function (i) {
    i.addEventListener('error', function () {
      bad++;
      var s = document.getElementById('broken');
      if (s) s.textContent = bad;
    });
  });
});
