/**
 * Name Tools - Responsive Navigation & Menu Controls
 * Handles the mobile menu and desktop mega-menu dropdowns with full
 * keyboard support (Enter/Space/Escape/Arrow keys), aria-expanded state,
 * and outside-click / link-click dismissal.
 */
document.addEventListener('DOMContentLoaded', () => {
  const mobileMenuBtn = document.getElementById('mobile-menu-button');
  const mobileMenu = document.getElementById('mobile-menu');

  function closeMobileMenu() {
    if (!mobileMenuBtn || !mobileMenu) return;
    mobileMenuBtn.setAttribute('aria-expanded', 'false');
    mobileMenu.classList.add('hidden');
  }

  function openMobileMenu() {
    if (!mobileMenuBtn || !mobileMenu) return;
    mobileMenuBtn.setAttribute('aria-expanded', 'true');
    mobileMenu.classList.remove('hidden');
  }

  if (mobileMenuBtn && mobileMenu) {
    mobileMenuBtn.addEventListener('click', () => {
      const isExpanded = mobileMenuBtn.getAttribute('aria-expanded') === 'true';
      if (isExpanded) {
        closeMobileMenu();
      } else {
        openMobileMenu();
      }
    });

    // Close the mobile menu whenever a link inside it is activated.
    mobileMenu.addEventListener('click', (e) => {
      if (e.target.closest('a')) {
        closeMobileMenu();
      }
    });

    // Close on outside click/tap.
    document.addEventListener('click', (e) => {
      const isOpen = mobileMenuBtn.getAttribute('aria-expanded') === 'true';
      if (!isOpen) return;
      if (!mobileMenu.contains(e.target) && !mobileMenuBtn.contains(e.target)) {
        closeMobileMenu();
      }
    });

    // Close on Escape, return focus to the toggle button.
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && mobileMenuBtn.getAttribute('aria-expanded') === 'true') {
        closeMobileMenu();
        mobileMenuBtn.focus();
      }
    });
  }

  // ---- Desktop mega-menu dropdowns ----
  const dropdownToggles = Array.from(document.querySelectorAll('.dropdown-toggle'));

  function getMenuFor(toggle) {
    const id = toggle.getAttribute('aria-controls');
    return id ? document.getElementById(id) : toggle.nextElementSibling;
  }

  function closeDropdown(toggle) {
    const menu = getMenuFor(toggle);
    toggle.setAttribute('aria-expanded', 'false');
    if (menu) menu.classList.add('hidden');
  }

  function openDropdown(toggle) {
    // Only one dropdown open at a time.
    dropdownToggles.forEach(closeDropdown);
    const menu = getMenuFor(toggle);
    toggle.setAttribute('aria-expanded', 'true');
    if (menu) menu.classList.remove('hidden');
  }

  dropdownToggles.forEach(toggle => {
    toggle.addEventListener('click', (e) => {
      e.stopPropagation();
      const isOpen = toggle.getAttribute('aria-expanded') === 'true';
      if (isOpen) {
        closeDropdown(toggle);
      } else {
        openDropdown(toggle);
      }
    });

    // Keyboard support: ArrowDown opens the menu and focuses the first link.
    toggle.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        openDropdown(toggle);
        const menu = getMenuFor(toggle);
        const firstLink = menu && menu.querySelector('a');
        if (firstLink) firstLink.focus();
      } else if (e.key === 'Escape') {
        closeDropdown(toggle);
      }
    });

    // Arrow-key navigation between links inside an open dropdown panel.
    const menu = getMenuFor(toggle);
    if (menu) {
      menu.addEventListener('keydown', (e) => {
        const links = Array.from(menu.querySelectorAll('a'));
        const idx = links.indexOf(document.activeElement);
        if (e.key === 'ArrowDown') {
          e.preventDefault();
          const next = links[idx + 1] || links[0];
          next.focus();
        } else if (e.key === 'ArrowUp') {
          e.preventDefault();
          const prev = links[idx - 1] || links[links.length - 1];
          prev.focus();
        } else if (e.key === 'Escape') {
          e.preventDefault();
          closeDropdown(toggle);
          toggle.focus();
        }
      });
    }
  });

  // Close all dropdowns on outside click.
  document.addEventListener('click', (e) => {
    dropdownToggles.forEach(toggle => {
      const menu = getMenuFor(toggle);
      const clickedInside = toggle.contains(e.target) || (menu && menu.contains(e.target));
      if (!clickedInside) closeDropdown(toggle);
    });
  });

  // Close all dropdowns on Escape from anywhere, and on focus leaving the nav entirely.
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      dropdownToggles.forEach(closeDropdown);
    }
  });

  document.addEventListener('focusin', (e) => {
    dropdownToggles.forEach(toggle => {
      const menu = getMenuFor(toggle);
      const withinThisDropdown = toggle.contains(e.target) || (menu && menu.contains(e.target));
      if (!withinThisDropdown) closeDropdown(toggle);
    });
  });
});
