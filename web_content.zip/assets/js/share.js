/**
 * Name Tools - Web Share Helper
 */
window.shareName = async function (name, toolTitle = 'Name Tools') {
  const shareData = {
    title: `${name} | ${toolTitle}`,
    text: `Check out this generated name: "${name}" created on Name Tools!`,
    url: window.location.href
  };

  if (navigator.share && navigator.canShare && navigator.canShare(shareData)) {
    try {
      await navigator.share(shareData);
      return;
    } catch (err) {
      if (err.name !== 'AbortError') {
        console.log('Share canceled or failed', err);
      }
    }
  }

  // Fallback: copy link to clipboard
  if (window.copyToClipboard) {
    window.copyToClipboard(window.location.href, 'Tool link copied to clipboard!');
  }
};
