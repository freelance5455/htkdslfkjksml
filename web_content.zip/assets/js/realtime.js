(function(){
  const timeFmt=new Intl.DateTimeFormat('en-PK',{timeZone:'Asia/Karachi',hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:true});
  const dateFmt=new Intl.DateTimeFormat('en-PK',{timeZone:'Asia/Karachi',day:'2-digit',month:'2-digit',year:'numeric'});
  // 120 generated HSL colors, rotated automatically for a continuous colorful effect.
  const colors=Array.from({length:120},(_,i)=>{
    const h=Math.round((i*360)/120);
    return {main:`hsl(${h} 95% 68%)`, soft:`hsl(${h} 90% 62% / .16)`, border:`hsl(${h} 95% 60% / .78)`};
  });
  let colorIndex=0;
  function tick(){
    const d=new Date();
    const time=timeFmt.format(d);
    const date=dateFmt.format(d);
    const clock=document.getElementById('clock');
    const liveTime=document.getElementById('liveTime');
    const liveDate=document.getElementById('liveDate');
    if(clock) clock.textContent=time;
    if(liveTime) liveTime.textContent=time;
    if(liveDate) liveDate.textContent=date;
  }
  function animateOnlineTime(){
    const pill=document.querySelector('.demo-pill');
    if(!pill) return;
    pill.classList.add('online-time-active');
    const c=colors[colorIndex++ % colors.length];
    pill.style.color=c.main;
    pill.style.borderColor=c.border;
    pill.style.background=`linear-gradient(135deg, ${c.soft}, rgba(255,255,255,.045))`;
    pill.style.boxShadow=`0 0 10px ${c.soft}, inset 0 0 18px ${c.soft}`;
    const clock=document.getElementById('clock');
    if(clock){
      clock.style.color=c.main;
      clock.style.textShadow=`0 0 8px ${c.soft}`;
    }
  }
  tick();
  animateOnlineTime();
  setInterval(tick,1000);
  setInterval(animateOnlineTime,120);
})();
