/**
 * Name Tools - Master Directory of 100 Tools, Search Engine & Toast System
 *
 * Tool metadata lives in /tools_data.json (single source of truth).
 * This file loads it once, normalizes it for the search/directory UI,
 * and dispatches a `nt:tools-ready` event other scripts can listen for.
 */

// Populated asynchronously from tools_data.json (fetched immediately below).
window.ALL_TOOLS = [];

(function () {
  const isSubdir = window.location.pathname.includes('/tools/');
  const dataUrl = isSubdir ? '../../tools_data.json' : './tools_data.json';

  fetch(dataUrl)
    .then(res => {
      if (!res.ok) throw new Error(`Failed to load tool directory (${res.status})`);
      return res.json();
    })
    .then(data => {
      window.ALL_TOOLS = data.map(t => ({
        id: t.id,
        name: t.title,
        category: t.category,
        desc: t.desc,
        url: `/tools/${t.id}/`
      }));
      window.dispatchEvent(new CustomEvent('nt:tools-ready', { detail: window.ALL_TOOLS }));
    })
    .catch(err => {
      console.error('Name Tools: could not load tool directory JSON.', err);
    });
})();

// Escape untrusted text before interpolating into innerHTML.
function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}

// Global Toast System
window.showToast = function (message, type = 'success') {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = `toast-message ${type === 'error' ? 'toast-error' : 'toast-success'}`;
  
  const icon = type === 'error' ? 
    '<svg class="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>' :
    '<svg class="w-4 h-4 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>';

  toast.innerHTML = `${icon} <span>${message}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    setTimeout(() => toast.remove(), 300);
  }, 3000);
};

// Global Quick Search Setup
document.addEventListener('DOMContentLoaded', () => {
  const searchInputs = document.querySelectorAll('.site-search-input');
  const searchResultsContainers = document.querySelectorAll('.site-search-results');

  // Fix relative URLs if in subdirectory
  const isSubdir = window.location.pathname.includes('/tools/');

  function runSearch(rawQuery) {
    const q = rawQuery.toLowerCase().trim();
    searchResultsContainers.forEach(container => {
      if (!q) {
        container.classList.add('hidden');
        container.innerHTML = '';
        return;
      }

      const matches = (window.ALL_TOOLS || []).filter(t =>
        t.name.toLowerCase().includes(q) ||
        t.category.toLowerCase().includes(q) ||
        t.desc.toLowerCase().includes(q)
      );

      if (matches.length === 0) {
        container.innerHTML = `<div class="p-4 text-sm text-slate-500 text-center">No tools found matching "${escapeHtml(rawQuery.trim())}"</div>`;
        container.classList.remove('hidden');
        return;
      }

      container.innerHTML = matches.map(t => {
        const targetUrl = isSubdir ? `../../tools/${t.id}/index.html` : `tools/${t.id}/index.html`;
        return `
          <a href="${targetUrl}" class="flex items-start gap-3 p-3 hover:bg-slate-50 dark:hover:bg-slate-700/60 transition rounded-xl group border-b border-slate-100 dark:border-slate-800 last:border-0">
            <div class="p-2 rounded-lg bg-indigo-50 dark:bg-indigo-900/40 text-indigo-600 dark:text-indigo-400 group-hover:bg-indigo-600 group-hover:text-white transition shrink-0">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
            </div>
            <div class="truncate">
              <div class="text-sm font-semibold text-slate-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 flex items-center gap-2">
                <span>${escapeHtml(t.name)}</span>
                <span class="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400">${escapeHtml(t.category)}</span>
              </div>
              <div class="text-xs text-slate-500 dark:text-slate-400 mt-0.5 truncate">${escapeHtml(t.desc)}</div>
            </div>
          </a>
        `;
      }).join('');
      container.classList.remove('hidden');
    });
  }

  searchInputs.forEach(input => {
    input.addEventListener('input', (e) => runSearch(e.target.value));

    // If the tool directory finishes loading after the user already typed
    // something (slow connection), refresh whichever input has focus.
    window.addEventListener('nt:tools-ready', () => {
      if (document.activeElement === input && input.value.trim()) {
        runSearch(input.value);
      }
    });

    // Close on click outside
    document.addEventListener('click', (e) => {
      if (!input.contains(e.target)) {
        searchResultsContainers.forEach(container => {
          if (!container.contains(e.target)) {
            container.classList.add('hidden');
          }
        });
      }
    });

    // Close on Escape
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        searchResultsContainers.forEach(container => {
          container.classList.add('hidden');
        });
        input.blur();
      }
    });
  });
});
