/* Demonstração local. NÃO é um painel seguro para publicação. */
'use strict';
const KEY = 'lumay_products_v1';
const defaults = [
  {id:1,name:'Notebook HP 15',price:72000,category:'Computadores',icon:'💻'},
  {id:2,name:'Smartphone 128GB',price:125000,category:'Telefones',icon:'📱'},
  {id:3,name:'Fone Bluetooth JBL',price:8500,category:'Áudio',icon:'🎧'},
  {id:4,name:'Tênis desportivo',price:12000,category:'Calçados',icon:'👟'},
  {id:5,name:'Relógio Smart',price:95000,category:'Relógios',icon:'⌚'},
  {id:6,name:'Peruca Premium',price:18000,category:'Beleza',icon:'💇'},
  {id:7,name:'Mochila Executiva',price:6500,category:'Pastas',icon:'🎒'},
  {id:8,name:'Camiseta Casual',price:3500,category:'Roupas',icon:'👕'}
];
function loadProducts() {
  try { return JSON.parse(localStorage.getItem(KEY)) || defaults.slice(); }
  catch { return defaults.slice(); }
}
let products = loadProducts();
function saveProducts() { localStorage.setItem(KEY, JSON.stringify(products)); }
function esc(value) {
  return String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
function renderAdmin() {
  document.getElementById('admin-product-count').textContent = products.length;
  const list = document.getElementById('admin-product-list');
  list.innerHTML = products.length ? products.map(p => `
    <div class="admin-product-row">
      <div><strong>${esc(p.icon || '📦')} ${esc(p.name)}</strong><small>${esc(p.category)} · ${new Intl.NumberFormat('pt-AO').format(p.price)} Kz</small></div>
      <button class="delete-button" data-delete="${Number(p.id)}">Eliminar</button>
    </div>`).join('') : '<p>Ainda não há produtos.</p>';
}
document.getElementById('product-form').addEventListener('submit', event => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const name = String(form.get('name')).trim();
  const price = Number(form.get('price'));
  const category = String(form.get('category'));
  const icon = String(form.get('icon') || '📦').trim();
  if (!name || !Number.isFinite(price) || price <= 0) return;
  products.push({id:Date.now(),name,price,category,icon});
  saveProducts(); renderAdmin(); event.currentTarget.reset();
});
document.addEventListener('click', event => {
  const button = event.target.closest('[data-delete]');
  if (!button) return;
  products = products.filter(p => p.id !== Number(button.dataset.delete));
  saveProducts(); renderAdmin();
});
renderAdmin();
