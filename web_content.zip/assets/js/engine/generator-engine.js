/**
 * Generator Engine: Semantic, Thematic, & Dictionary-Driven Name Generation
 * Powers Baby, Gaming, Social Media, Business/Brand, Nicknames, and Creative generators.
 */
(function () {
  const Generator = {
    clean(str) {
      return (str || '').trim();
    },

    capitalize(str) {
      if (!str) return '';
      return str.charAt(0).toUpperCase() + str.slice(1);
    },

    pickRandom(arr, seedOffset = 0) {
      if (!arr || arr.length === 0) return '';
      const idx = Math.floor(Math.abs(Math.sin(Date.now() + seedOffset) * 10000)) % arr.length;
      return arr[idx];
    },

    shuffle(array, seed = 1) {
      const arr = [...array];
      for (let i = arr.length - 1; i > 0; i--) {
        const j = Math.floor(Math.abs(Math.sin(seed * (i + 1)) * 10000)) % (i + 1);
        [arr[i], arr[j]] = [arr[j], arr[i]];
      }
      return arr;
    },

    generate(keyword, options = {}) {
      const data = window.NameData || {};
      const type = options.type || 'general';
      const category = options.category || 'general';
      const count = parseInt(options.count, 10) || 12;
      const seed = options.seed || Math.random();
      const rawKeyword = this.clean(keyword);

      const results = [];

      // 1. BABY NAME GENERATORS
      if (type.startsWith('baby-') || category === 'Baby Names') {
        const babyDb = data.babyNames || {};
        let pool = [];

        if (type === 'baby-boy-name-generator' || options.gender === 'boy') {
          pool = [...(babyDb.boy || [])];
        } else if (type === 'baby-girl-name-generator' || options.gender === 'girl') {
          pool = [...(babyDb.girl || [])];
        } else if (type === 'unisex-baby-name-generator' || options.gender === 'unisex') {
          pool = [...(babyDb.unisex || [])];
        } else if (type === 'indian-baby-name-generator') {
          pool = [...(babyDb.boy || []).filter(b => b.origin === 'Indian'), ...(babyDb.girl || []).filter(g => g.origin === 'Indian')];
        } else if (type === 'twin-baby-name-generator') {
          const twins = babyDb.twins || [];
          return twins.map((t, idx) => ({
            name: `${t.pair[0]} & ${t.pair[1]}`,
            desc: `${t.theme}`,
            score: t.score - (idx % 3)
          })).slice(0, count);
        } else {
          pool = [...(babyDb.boy || []), ...(babyDb.girl || []), ...(babyDb.unisex || [])];
        }

        // Filter by initial if specified
        if (options.initial) {
          const initUpper = options.initial.toUpperCase();
          const filtered = pool.filter(b => b.name.toUpperCase().startsWith(initUpper));
          if (filtered.length > 0) pool = filtered;
        }

        // Filter by short if specified
        if (type === 'short-baby-name-generator' || options.shortOnly) {
          pool = pool.filter(b => b.name.length <= 5);
        }

        // Shuffle with seed
        const shuffled = this.shuffle(pool, seed * 100);
        shuffled.slice(0, count).forEach((b, idx) => {
          results.push({
            name: b.name,
            desc: b.meaning ? `${b.meaning} (${b.origin})` : `${b.origin} Origin`,
            score: 98 - (idx % 6)
          });
        });

        if (results.length > 0) return results;
      }

      // 2. GAMING, ESPORTS, & CLAN GENERATORS
      if (type.startsWith('gaming-') || type.startsWith('gamer-') || type.includes('clan') || type.includes('gamertag') || category === 'Gaming') {
        const g = data.gaming || {};
        const prefixes = g.tacticalPrefixes || ['Shadow', 'Vortex', 'Apex', 'Phantom', 'Cyber', 'Frost'];
        const nouns = g.warriorNouns || ['Reaper', 'Slayer', 'Ghost', 'Knight', 'Blade', 'Viper'];
        const esportsTags = g.esportsTags || ['FAZE', 'OPTIC', 'NAVI', 'TSM', 'AURA'];

        for (let i = 0; i < count * 2; i++) {
          const p = prefixes[(i + Math.floor(seed * 20)) % prefixes.length];
          const n = nouns[(i * 3 + Math.floor(seed * 15)) % nouns.length];
          const tag = esportsTags[i % esportsTags.length];

          let genName = '';
          if (type === 'gaming-clan-tag-generator') {
            genName = `[${tag}] ${rawKeyword || p}`;
          } else if (type === 'clan-name-generator' || type === 'esports-team-name-generator') {
            const clanNoun = (g.clanNouns || ['Vanguard', 'Order', 'Legion'])[i % 15];
            genName = rawKeyword ? `${this.capitalize(rawKeyword)} ${clanNoun}` : `${p} ${clanNoun}`;
          } else if (type === 'gaming-team-name-generator') {
            const teamNouns = ['Squad', 'Wolves', 'Force', 'Fireteam', 'Crew', 'Syndicate'];
            genName = rawKeyword ? `${this.capitalize(rawKeyword)} ${teamNouns[i % teamNouns.length]}` : `Team ${p}`;
          } else if (type === 'discord-username-generator') {
            const dStyles = [
              `${(rawKeyword || p).toLowerCase()}_`,
              `.${(rawKeyword || p).toLowerCase()}.`,
              `${(rawKeyword || p).toLowerCase()}${Math.floor(seed * 89 + 10)}`,
              `! ${(rawKeyword || p).toLowerCase()}`
            ];
            genName = dStyles[i % dStyles.length];
          } else if (type === 'twitch-username-generator') {
            const tStyles = [
              `${this.capitalize(rawKeyword || p)}Live`,
              `TTV_${this.capitalize(rawKeyword || p)}`,
              `${this.capitalize(rawKeyword || p)}Streams`,
              `Its${this.capitalize(rawKeyword || p)}TV`
            ];
            genName = tStyles[i % tStyles.length];
          } else if (type === 'gaming-alias-generator') {
            const aStyles = [
              `Agent_${this.capitalize(rawKeyword || p)}`,
              `Ghost_${this.capitalize(rawKeyword || n)}`,
              `Zero_${this.capitalize(rawKeyword || p)}`,
              `Viper_${this.capitalize(rawKeyword || n)}`
            ];
            genName = aStyles[i % aStyles.length];
          } else if (type === 'roblox-username-generator') {
            const robloxWord = (g.robloxWords || ['Blox', 'Pixel', 'Spark'])[i % 12];
            genName = `${rawKeyword || p}_${robloxWord}${Math.floor(seed * 90 + 10)}`;
          } else if (type === 'minecraft-name-generator') {
            const mc = (g.minecraftWords || ['Miner', 'Craft', 'Redstone'])[i % 12];
            genName = `${rawKeyword || mc}Craft_${p}`;
          } else if (type === 'fortnite-name-generator') {
            const fn = (g.fortniteWords || ['Sniper', 'Royale', 'Victory'])[i % 12];
            genName = `${p}_${rawKeyword || fn}`;
          } else {
            // Default gamertag / gamer username / pro nickname
            genName = rawKeyword ? `${p}${this.capitalize(rawKeyword)}` : `${p}${n}`;
            if (i % 3 === 0) genName = `xX_${genName}_Xx`;
            else if (i % 4 === 0) genName = `${genName}_${Math.floor(seed * 89 + 10)}`;
          }

          results.push({
            name: genName,
            score: 95 - (i % 8)
          });
        }

        const unique = Array.from(new Set(results.map(r => r.name)))
          .map(name => results.find(r => r.name === name));
        return unique.slice(0, count);
      }

      // 3. SOCIAL MEDIA & USERNAMES
      if (type.includes('username') || type.includes('tiktok') || type.includes('instagram') || type.includes('youtube') || category === 'Social Media') {
        const s = data.social || {};
        const adj = s.aestheticAdjectives || ['velvet', 'golden', 'cosmic', 'honey', 'dreamy'];
        const nouns = s.nouns || ['vibes', 'studio', 'aura', 'muse', 'haven'];
        const base = rawKeyword.toLowerCase().replace(/\s+/g, '') || 'luxe';

        for (let i = 0; i < count * 2; i++) {
          const a = adj[(i + Math.floor(seed * 10)) % adj.length];
          const n = nouns[(i * 2) % nouns.length];

          let handle = '';
          if (type === 'youtube-channel-name-generator') {
            const categoryWords = (s.youtubeCategories?.tech || ['Lab', 'Central', 'Zone', 'Hub', 'TV', 'Show']);
            handle = `${this.capitalize(base)} ${categoryWords[i % categoryWords.length]}`;
          } else if (type === 'aesthetic-username-generator') {
            const astStyles = [`${a}.${base}.${n}`, `˚₊· ͟͟͞͞➳❥ ${base}`, `⋆｡°✩ ${base} ✩°｡⋆`, `.${a}.${base}.`, `cloudy.${base}`];
            handle = astStyles[i % astStyles.length];
          } else if (type === 'tiktok-username-generator') {
            const tikStyles = [`the.${base}._`, `${base}.tok`, `its.${base}`, `${base}.pov`, `not.${base}`, `${base}_vibes`];
            handle = tikStyles[i % tikStyles.length];
          } else if (type === 'pinterest-username-generator') {
            const pinStyles = [`${base}.pins`, `${a}.${base}.aesthetic`, `curated.${base}`, `${base}.moods`, `${base}.boards`];
            handle = pinStyles[i % pinStyles.length];
          } else if (type === 'snapchat-username-generator') {
            const snapStyles = [`snap.${base}`, `${base}.streaks`, `real.${base}99`, `hey.${base}.xo`, `${base}.snap`];
            handle = snapStyles[i % snapStyles.length];
          } else if (type === 'x-username-generator') {
            const xStyles = [`the${this.capitalize(base)}`, `${base}_hq`, `${base}Daily`, `ask${this.capitalize(base)}`, `${base}Post`];
            handle = xStyles[i % xStyles.length];
          } else if (type === 'facebook-username-generator') {
            const fbStyles = [`${this.capitalize(base)} Official`, `${this.capitalize(base)} Community`, `${this.capitalize(base)} Network`, `${this.capitalize(base)} Club`];
            handle = fbStyles[i % fbStyles.length];
          } else {
            const formats = [
              `${a}.${base}`,
              `its${this.capitalize(base)}`,
              `${base}.${n}`,
              `${base}_official`,
              `real.${base}`,
              `hey.${base}`,
              `${base}vibes`,
              `daily.${base}`
            ];
            handle = formats[i % formats.length];
          }

          results.push({
            name: handle,
            score: 96 - (i % 7)
          });
        }

        const unique = Array.from(new Set(results.map(r => r.name)))
          .map(name => results.find(r => r.name === name));
        return unique.slice(0, count);
      }

      // 4. BUSINESS, BRAND, & STORE GENERATORS
      if (type.includes('business') || type.includes('brand') || type.includes('startup') || type.includes('store') || type.includes('shop') || type.includes('app') || type.includes('domain') || category === 'Business & Brand') {
        const b = data.business || {};
        const prefixes = b.prefixes || ['Omni', 'Nova', 'Apex', 'Aero', 'Syn', 'Meta'];
        const suffixes = b.suffixes || ['ify', 'ly', 'io', 'lab', 'hub', 'forge', 'stack'];
        const base = this.capitalize(rawKeyword) || 'Venture';

        for (let i = 0; i < count * 2; i++) {
          const p = prefixes[(i + Math.floor(seed * 10)) % prefixes.length];
          const s = suffixes[(i * 2) % suffixes.length];

          let bizName = '';
          if (type === 'domain-name-ideas-generator') {
            const ext = (b.domains || ['.com', '.io', '.ai', '.co'])[i % 4];
            bizName = `${base.toLowerCase()}${s}${ext}`;
          } else if (type === 'cafe-name-generator') {
            const cafeWord = (b.cafeKeywords || ['Brew', 'Roast', 'Mocha', 'Bean'])[i % 10];
            bizName = `${base} ${cafeWord}`;
          } else if (type === 'clothing-brand-name-generator') {
            const clothWord = (b.clothingKeywords || ['Atelier', 'Threads', 'Apparel', 'Wear'])[i % 10];
            bizName = `${base} ${clothWord}`;
          } else if (type === 'restaurant-name-generator') {
            const restWord = (b.restaurantKeywords || ['Bistro', 'Table', 'Kitchen', 'Palate'])[i % 10];
            bizName = `The ${base} ${restWord}`;
          } else if (type === 'company-name-generator') {
            const corpStyles = [`${base} Global`, `${base} Group`, `${base} Holdings`, `${p} ${base} Industries`, `${base} Capital`];
            bizName = corpStyles[i % corpStyles.length];
          } else if (type === 'startup-name-generator') {
            const startStyles = [`${base}${s}`, `${p}${base}`, `${base} AI`, `${base}HQ`, `${base} Labs`];
            bizName = startStyles[i % startStyles.length];
          } else if (type === 'shop-name-generator' || type === 'store-name-generator') {
            const shopStyles = [`${base} Boutique`, `${base} Corner`, `The ${base} Shop`, `${base} Emporium`, `${base} Market`];
            bizName = shopStyles[i % shopStyles.length];
          } else if (type === 'online-store-name-generator') {
            const ecomStyles = [`${base} Direct`, `${base} Cart`, `Shop ${base}`, `${base} Express`, `${base} Vault`];
            bizName = ecomStyles[i % ecomStyles.length];
          } else if (type === 'product-name-generator') {
            const prodStyles = [`${base}Pro`, `${base}Go`, `${base}Flow`, `${base}Pulse`, `${base}OS`];
            bizName = prodStyles[i % prodStyles.length];
          } else if (type === 'blog-name-generator') {
            const blogStyles = [`The ${base} Journal`, `${base} Chronicles`, `Beyond ${base}`, `${base} Digest`, `${base} Diaries`];
            bizName = blogStyles[i % blogStyles.length];
          } else if (type === 'website-name-generator') {
            const webStyles = [`${base} Hub`, `${base} Central`, `${base} Insider`, `${base} Portal`, `${base} Network`];
            bizName = webStyles[i % webStyles.length];
          } else if (type === 'app-name-generator') {
            bizName = `${base}${s}`;
          } else {
            const styles = [
              `${p} ${base}`,
              `${base}${s}`,
              `${p}${base}`,
              `${base} Labs`,
              `${base} Sync`,
              `${base} Stack`
            ];
            bizName = styles[i % styles.length];
          }

          results.push({
            name: bizName,
            score: 97 - (i % 6)
          });
        }

        const unique = Array.from(new Set(results.map(r => r.name)))
          .map(name => results.find(r => r.name === name));
        return unique.slice(0, count);
      }

      // 5. NICKNAME GENERATORS
      if (type.includes('nickname') || category === 'Nickname') {
        const nDb = data.nicknames || {};
        let list = [];

        if (type === 'cute-nickname-generator') list = nDb.cute || [];
        else if (type === 'funny-nickname-generator') list = nDb.funny || [];
        else if (type === 'attitude-nickname-generator') list = nDb.attitude || [];
        else if (type === 'best-friend-nickname-generator') list = nDb.bestFriend || [];
        else if (type === 'boy-nickname-generator') list = nDb.boy || [];
        else if (type === 'girl-nickname-generator') list = nDb.girl || [];
        else if (type === 'instagram-nickname-generator') list = nDb.instagram || [];
        else if (type === 'gaming-nickname-generator') list = nDb.gaming || [];
        else list = [...(nDb.cute || []), ...(nDb.cool || []), ...(nDb.attitude || [])];

        const base = this.capitalize(rawKeyword) || 'Buddy';
        list.forEach((nick, idx) => {
          results.push({
            name: rawKeyword ? `${base} the ${nick}` : nick,
            score: 95 - (idx % 6)
          });
        });

        // Add suffix nicknames
        ['y', 'ie', 'bear', 'kins', 'ster', 'boo'].forEach((suf, idx) => {
          results.push({
            name: `${base}${suf}`,
            score: 92 - idx
          });
        });

        return this.shuffle(results, seed * 100).slice(0, count);
      }

      // 6. CREATIVE, FANTASY, BAND, & PODCAST
      if (category === 'Stylish & Creative' || type.includes('fantasy') || type.includes('band') || type.includes('podcast')) {
        const c = data.creative || {};
        const base = this.capitalize(rawKeyword) || 'Echo';

        if (type === 'band-name-generator') {
          const vibes = c.bandVibes || ['The Electric', 'Velvet', 'Midnight', 'Neon'];
          const nouns = c.bandNouns || ['Echoes', 'Mirage', 'Wolves', 'Tides'];
          for (let i = 0; i < count; i++) {
            results.push({
              name: `${vibes[i % vibes.length]} ${nouns[(i * 2) % nouns.length]}`,
              score: 96 - (i % 5)
            });
          }
          return results;
        }

        if (type === 'podcast-name-generator') {
          const kw = c.podcastKeywords || ['Deep Dive', 'Uncut', 'Sessions', 'Hour'];
          for (let i = 0; i < count; i++) {
            results.push({
              name: `The ${base} ${kw[i % kw.length]}`,
              score: 95 - (i % 5)
            });
          }
          return results;
        }

        if (type === 'fantasy-name-generator') {
          const p = c.fantasyPrefixes || ['Ael', 'Dra', 'Syl', 'Val'];
          const s = c.fantasySuffixes || ['dor', 'ryn', 'ion', 'riel'];
          for (let i = 0; i < count; i++) {
            results.push({
              name: `${p[i % p.length]}${s[(i * 3) % s.length]}`,
              score: 94 - (i % 5)
            });
          }
          return results;
        }

        if (type === 'character-name-generator' || type === 'book-character-name-generator') {
          const firsts = ['Julian', 'Cassian', 'Aurelia', 'Seraphina', 'Dante', 'Evangeline', 'Lucian', 'Genevieve', 'Rowan', 'Valerie', 'Gideon', 'Thalia'];
          const lasts = ['Blackwood', 'Sterling', 'Vance', 'Thorne', 'Cross', 'Holloway', 'Sinclair', 'Fairchild', 'Winter', 'Nightshade', 'Mercer', 'Ravenscroft'];
          for (let i = 0; i < count; i++) {
            const f = rawKeyword ? this.capitalize(rawKeyword) : firsts[(i + Math.floor(seed * 7)) % firsts.length];
            const l = lasts[(i * 3 + Math.floor(seed * 11)) % lasts.length];
            results.push({
              name: `${f} ${l}`,
              score: 95 - (i % 5)
            });
          }
          return results;
        }

        if (type === 'unique-name-generator') {
          const uniqueList = ['Zephyr', 'Vesper', 'Solas', 'Caelum', 'Elysian', 'Astral', 'Nyx', 'Thalor', 'Aethel', 'Kaelen', 'Soren', 'Orion', 'Lyra', 'Valen', 'Zarek'];
          for (let i = 0; i < count; i++) {
            results.push({
              name: rawKeyword ? `${this.capitalize(rawKeyword)} ${uniqueList[i % uniqueList.length]}` : uniqueList[i % uniqueList.length],
              score: 97 - (i % 5)
            });
          }
          return results;
        }
      }

      // Default Fallback
      for (let i = 1; i <= count; i++) {
        results.push({
          name: `${this.capitalize(rawKeyword || 'Name')} ${i}`,
          score: 90
        });
      }
      return results;
    }
  };

  window.GeneratorEngine = Generator;
})();
