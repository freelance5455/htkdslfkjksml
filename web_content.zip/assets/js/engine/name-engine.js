/**
 * Master Name Engine: Unified Hub
 * Routes requests to CombinerEngine, GeneratorEngine, or FormatterEngine based on tool configuration.
 */
(function () {
  const NameEngine = {
    combiner: window.CombinerEngine,
    generator: window.GeneratorEngine,
    formatter: window.FormatterEngine,

    execute(config, inputs) {
      const engineType = (config.engineType || 'combiner').toLowerCase();

      if (engineType === 'combiner') {
        const names = [inputs.name1, inputs.name2, inputs.name3].filter(Boolean);
        return window.CombinerEngine.combine(names, {
          mode: config.mode || 'couple',
          style: inputs.style || 'creative',
          count: inputs.count || 12,
          seed: inputs.seed || Math.random()
        });
      }

      if (engineType === 'generator') {
        const keyword = inputs.keyword || inputs.name || inputs.name1 || '';
        return window.GeneratorEngine.generate(keyword, {
          type: config.id,
          category: config.category,
          gender: inputs.gender,
          initial: inputs.initial,
          shortOnly: inputs.shortOnly,
          count: inputs.count || 12,
          seed: inputs.seed || Math.random()
        });
      }

      if (engineType === 'formatter') {
        const text = inputs.name || inputs.name1 || inputs.keyword || 'Name';
        return window.FormatterEngine.format(text, {
          type: config.id,
          name1: inputs.name1,
          name2: inputs.name2,
          count: inputs.count || 12
        });
      }

      return [];
    }
  };

  window.NameEngine = NameEngine;
})();
