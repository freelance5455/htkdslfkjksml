/**
 * Central Name Engine Data Repository
 * Provides rich phonetic dictionaries, vocabulary pools, roots, affixes, unicode maps, and meanings.
 */
(function () {
  const NameData = {
    // Unicode Font Maps for Formatter Engine
    unicodeFonts: {
      boldSerif: {
        a: '𝐚', b: '𝐛', c: '𝐜', d: '𝐝', e: '𝐞', f: '𝐟', g: '𝐠', h: '𝐡', i: '𝐢', j: '𝐣', k: '𝐤', l: '𝐥', m: '𝐦', n: '𝐧', o: '𝐨', p: '𝐩', q: '𝐪', r: '𝐫', s: '𝐬', t: '𝐭', u: '𝐮', v: '𝐯', w: '𝐰', x: '𝐱', y: '𝐲', z: '𝐳',
        A: '𝐀', B: '𝐁', C: '𝐂', D: '𝐃', E: '𝐄', F: '𝐅', G: '𝐆', H: '𝐇', I: '𝐈', J: '𝐉', K: '𝐊', L: '𝐋', M: '𝐌', N: '𝐍', O: '𝐎', P: '𝐏', Q: '𝐐', R: '𝐑', S: '𝐒', T: '𝐓', U: '𝐔', V: '𝐕', W: '𝐖', X: '𝐗', Y: '𝐘', Z: '𝐙',
        '0': '𝟎', '1': '𝟏', '2': '𝟐', '3': '𝟑', '4': '𝟒', '5': '𝟓', '6': '𝟔', '7': '𝟕', '8': '𝟖', '9': '𝟗'
      },
      boldSans: {
        a: '𝗮', b: '𝗯', c: '𝗰', d: '𝗱', e: '𝗲', f: '𝗳', g: '𝗴', h: '𝗵', i: '𝗶', j: '𝗷', k: '𝗸', l: '𝗹', m: '𝗺', n: '𝗻', o: '𝗼', p: '𝗽', q: '𝗾', r: '𝗿', s: '𝘀', t: '𝘁', u: '𝘂', v: '𝘃', w: '𝘄', x: '𝘅', y: '𝘆', z: '𝘇',
        A: '𝗔', B: '𝗕', C: '𝗖', D: '𝗗', E: '𝗘', F: '𝗙', G: '𝗚', H: '𝗛', I: '𝗜', J: '𝗝', K: '𝗞', L: '𝗟', M: '𝗠', N: '𝗡', O: '𝗢', P: '𝗣', Q: '𝗤', R: '𝗥', S: '𝗦', T: '𝗧', U: '𝗨', V: '𝗩', W: '𝗪', X: '𝗫', Y: '𝗬', Z: '𝗭',
        '0': '𝟬', '1': '𝟭', '2': '𝟮', '3': '𝟯', '4': '𝟰', '5': '𝟱', '6': '𝟲', '7': '𝟳', '8': '𝟴', '9': '𝟵'
      },
      gothic: {
        a: '𝔞', b: '𝔟', c: '𝔠', d: '𝔡', e: '𝔢', f: '𝔣', g: '𝔤', h: '𝔥', i: '𝔦', j: '𝔧', k: '𝔨', l: '𝔩', m: '𝔪', n: '𝔫', o: '𝔬', p: '𝔭', q: '𝔮', r: '𝔯', s: '𝔰', t: '𝔱', u: '𝔲', v: '𝔳', w: '𝔴', x: '𝔵', y: '𝔶', z: '𝔷',
        A: '𝔄', B: '𝔅', C: 'ℭ', D: '𝔇', E: '𝔈', F: '𝔉', G: '𝔊', H: 'ℌ', I: 'ℑ', J: '𝔍', K: '𝔎', L: '𝔏', M: '𝔐', N: '𝔑', O: '𝔒', P: '𝔓', Q: '𝔔', R: 'ℜ', S: '𝔖', T: '𝔗', U: '𝔘', V: '𝔙', W: '𝔚', X: '𝔛', Y: '𝔜', Z: 'ℨ'
      },
      script: {
        a: '𝒶', b: '𝒷', c: '𝒸', d: '𝒹', e: 'ℯ', f: '𝒻', g: 'ℊ', h: '𝒽', i: '𝒾', j: '𝒿', k: '𝓀', l: '𝓁', m: '𝓂', n: '𝓃', o: 'ℴ', p: '𝓅', q: '𝓆', r: '𝓇', s: '𝓈', t: '𝓉', u: '𝓊', v: '𝓋', w: '𝓌', x: '𝓍', y: '𝓎', z: '𝓏',
        A: '𝒜', B: 'ℬ', C: '𝒞', D: '𝒟', E: 'ℰ', F: 'ℱ', G: '𝒢', H: 'ℋ', I: 'ℐ', J: '𝒥', K: '𝒦', L: 'ℒ', M: 'ℳ', N: '𝒩', O: '𝒪', P: '𝒫', Q: '𝒬', R: 'ℛ', S: '𝒮', T: '𝒯', U: '𝒰', V: '𝒱', W: '𝒲', X: '𝒳', Y: '𝒴', Z: '𝒵'
      },
      doubleStruck: {
        a: '𝕒', b: '𝕓', c: '𝕔', d: '𝕕', e: '𝕖', f: '𝕗', g: '𝕘', h: '𝕙', i: '𝕚', j: '𝕛', k: '𝕜', l: '𝕝', m: '𝕞', n: '𝕟', o: '𝕠', p: '𝕡', q: '𝕢', r: '𝕣', s: '𝕤', t: '𝕥', u: '𝕦', v: '𝕧', w: '𝕨', x: '𝕩', y: '𝕪', z: '𝕫',
        A: '𝔸', B: '𝔹', C: 'ℂ', D: '𝔻', E: '𝔼', F: '𝔽', G: '𝔾', H: 'ℍ', I: '𝕀', J: '𝕁', K: '𝕂', L: '𝕃', M: '𝕄', N: 'ℕ', O: '𝕆', P: 'ℙ', Q: 'ℚ', R: 'ℝ', S: '𝕊', T: '𝕋', U: '𝕌', V: '𝕍', W: '𝕎', X: '𝕏', Y: '𝕐', Z: 'ℤ'
      },
      circled: {
        a: 'ⓐ', b: 'ⓑ', c: 'ⓒ', d: 'ⓓ', e: 'ⓔ', f: 'ⓕ', g: 'ⓖ', h: 'ⓗ', i: 'ⓘ', j: 'ⓙ', k: 'ⓚ', l: 'ⓛ', m: 'ⓜ', n: 'ⓝ', o: 'ⓞ', p: 'ⓟ', q: 'ⓠ', r: 'ⓡ', s: 'ⓢ', t: 'ⓣ', u: 'ⓤ', v: 'ⓥ', w: 'ⓦ', x: 'ⓧ', y: 'ⓨ', z: 'ⓩ',
        A: 'Ⓐ', B: 'Ⓑ', C: 'Ⓒ', D: 'Ⓓ', E: 'Ⓔ', F: 'Ⓕ', G: 'Ⓖ', H: 'Ⓗ', I: 'Ⓘ', J: 'Ⓙ', K: 'Ⓚ', L: 'Ⓛ', M: 'Ⓜ', N: 'Ⓝ', O: 'Ⓞ', P: 'Ⓟ', Q: 'Ⓠ', R: 'Ⓡ', S: 'Ⓢ', T: 'Ⓣ', U: 'Ⓤ', V: 'Ⓥ', W: 'Ⓦ', X: 'Ⓧ', Y: 'Ⓨ', Z: 'Ⓩ'
      },
      monospace: {
        a: '𝚊', b: '𝚋', c: '𝚌', d: '𝚍', e: '𝚎', f: '𝚏', g: '𝚐', h: '𝚑', i: '𝚒', j: '𝚓', k: '𝚔', l: '𝚕', m: '𝚖', n: '𝚗', o: '𝚘', p: '𝚙', q: '𝚚', r: '𝚛', s: '𝚜', t: '𝚝', u: '𝚞', v: '𝚟', w: '𝚠', x: '𝚡', y: '𝚢', z: '𝚣',
        A: '𝙰', B: '𝙱', C: '𝙲', D: '𝙳', E: '𝙴', F: '𝙵', G: '𝙶', H: '𝙷', I: '𝙸', J: '𝙹', K: '𝙺', L: '𝙻', M: '𝙼', N: '𝙽', O: '𝙾', P: '𝙿', Q: '𝚀', R: '𝚁', S: '𝚂', T: '𝚃', U: '𝚄', V: '𝚅', W: '𝚆', X: '𝚇', Y: '𝚈', Z: '𝚉'
      },
      smallCaps: {
        a: 'ᴀ', b: 'ʙ', c: 'ᴄ', d: 'ᴅ', e: 'ᴇ', f: 'ꜰ', g: 'ɢ', h: 'ʜ', i: 'ɪ', j: 'ᴊ', k: 'ᴋ', l: 'ʟ', m: 'ᴍ', n: 'ɴ', o: 'ᴏ', p: 'ᴘ', q: 'ǫ', r: 'ʀ', s: 'ꜱ', t: 'ᴛ', u: 'ᴜ', v: 'ᴠ', w: 'ᴡ', x: 'x', y: 'ʏ', z: 'ᴢ'
      },
      upsideDown: {
        a: 'ɐ', b: 'q', c: 'ɔ', d: 'p', e: 'ǝ', f: 'ɟ', g: 'ƃ', h: 'ɥ', i: 'ᴉ', j: 'ɾ', k: 'ʞ', l: 'l', m: 'ɯ', n: 'u', o: 'o', p: 'd', q: 'b', r: 'ɹ', s: 's', t: 'ʇ', u: 'n', v: 'ʌ', w: 'ʍ', x: 'x', y: 'ʎ', z: 'z'
      }
    },

    // Aesthetic symbol frames and decorations
    symbolFrames: [
      (s) => `★彡 ${s} 彡★`,
      (s) => `༺ ${s} ༻`,
      (s) => `꧁ ${s} ꧂`,
      (s) => `⚡ ${s} ⚡`,
      (s) => `✧˖° ${s} °˖✧`,
      (s) => `亗 ${s} 亗`,
      (s) => `xX_${s}_Xx`,
      (s) => `♛ ${s} ♛`,
      (s) => `✿ ${s} ✿`,
      (s) => `「 ${s} 」`,
      (s) => `『 ${s} 』`,
      (s) => `✦ ${s} ✦`,
      (s) => `•.¸♡ ${s} ♡¸.•`,
      (s) => `ღ(¯\`◕‿◕´¯) ♫ ♪ ${s} ♪ ♫ (¯\`◕‿◕´¯)ღ`,
      (s) => `ıllıllı ${s} ıllıllı`,
      (s) => `｡☆✼★ ${s} ★✼☆｡`
    ],

    // Curated Baby Names by Category & Origin
    babyNames: {
      boy: [
        { name: 'Aarav', meaning: 'Peaceful, Wisdom', origin: 'Indian', initial: 'A' },
        { name: 'Liam', meaning: 'Strong-willed warrior', origin: 'Irish', initial: 'L' },
        { name: 'Noah', meaning: 'Rest, Peace', origin: 'Hebrew', initial: 'N' },
        { name: 'Vivaan', meaning: 'Full of life, Morning sun', origin: 'Indian', initial: 'V' },
        { name: 'Oliver', meaning: 'Olive tree, Peaceful', origin: 'Latin', initial: 'O' },
        { name: 'Elijah', meaning: 'My God is Yahweh', origin: 'Hebrew', initial: 'E' },
        { name: 'Advik', meaning: 'Unique, Matchless', origin: 'Indian', initial: 'A' },
        { name: 'Lucas', meaning: 'Bringer of light', origin: 'Greek', initial: 'L' },
        { name: 'Reyansh', meaning: 'First ray of light', origin: 'Indian', initial: 'R' },
        { name: 'Leo', meaning: 'Lion, Brave', origin: 'Latin', initial: 'L' },
        { name: 'Mateo', meaning: 'Gift of God', origin: 'Spanish', initial: 'M' },
        { name: 'Kabir', meaning: 'Great, Leader', origin: 'Indian', initial: 'K' },
        { name: 'Ezra', meaning: 'Helper, Protector', origin: 'Hebrew', initial: 'E' },
        { name: 'Ishaan', meaning: 'Lord Shiva, Sun', origin: 'Indian', initial: 'I' },
        { name: 'Milo', meaning: 'Beloved, Soldier', origin: 'Germanic', initial: 'M' },
        { name: 'Arjun', meaning: 'Bright, Shining', origin: 'Indian', initial: 'A' },
        { name: 'Julian', meaning: 'Youthful, Sky-father', origin: 'Latin', initial: 'J' },
        { name: 'Siddharth', meaning: 'One who has achieved a goal', origin: 'Indian', initial: 'S' },
        { name: 'Finn', meaning: 'Fair, White', origin: 'Irish', initial: 'F' },
        { name: 'Aryan', meaning: 'Noble, Honorable', origin: 'Indian', initial: 'A' },
        { name: 'Kian', meaning: 'Ancient, God\'s grace', origin: 'Persian', initial: 'K' },
        { name: 'Dhruv', meaning: 'Pole star, Unshakable', origin: 'Indian', initial: 'D' },
        { name: 'Zayn', meaning: 'Beauty, Grace', origin: 'Arabic', initial: 'Z' },
        { name: 'Rohan', meaning: 'Ascending, Blossom', origin: 'Indian', initial: 'R' }
      ],
      girl: [
        { name: 'Aadhya', meaning: 'First power, Goddess Durga', origin: 'Indian', initial: 'A' },
        { name: 'Olivia', meaning: 'Peace, Olive tree', origin: 'Latin', initial: 'O' },
        { name: 'Ananya', meaning: 'Incomparable, Unique', origin: 'Indian', initial: 'A' },
        { name: 'Emma', meaning: 'Whole, Universal', origin: 'Germanic', initial: 'E' },
        { name: 'Diya', meaning: 'Light, Splendor', origin: 'Indian', initial: 'D' },
        { name: 'Amelia', meaning: 'Industrious, Striving', origin: 'Germanic', initial: 'A' },
        { name: 'Isha', meaning: 'One who protects, Goddess', origin: 'Indian', initial: 'I' },
        { name: 'Sophia', meaning: 'Wisdom', origin: 'Greek', initial: 'S' },
        { name: 'Kiara', meaning: 'Bright, Clear', origin: 'Italian', initial: 'K' },
        { name: 'Mia', meaning: 'Beloved, Ocean star', origin: 'Scandinavian', initial: 'M' },
        { name: 'Myra', meaning: 'Sweet fragrant resin', origin: 'Greek', initial: 'M' },
        { name: 'Isabella', meaning: 'Pledged to God', origin: 'Hebrew', initial: 'I' },
        { name: 'Saanvi', meaning: 'Goddess Lakshmi, Follower', origin: 'Indian', initial: 'S' },
        { name: 'Luna', meaning: 'Moon, Radiant light', origin: 'Latin', initial: 'L' },
        { name: 'Pari', meaning: 'Fairy, Angelic beauty', origin: 'Persian', initial: 'P' },
        { name: 'Aria', meaning: 'Melody, Noble air', origin: 'Italian', initial: 'A' },
        { name: 'Rhea', meaning: 'Flowing stream, Grace', origin: 'Greek', initial: 'R' },
        { name: 'Tara', meaning: 'Star, Guiding light', origin: 'Indian', initial: 'T' },
        { name: 'Chloe', meaning: 'Blooming, Green sprout', origin: 'Greek', initial: 'C' },
        { name: 'Zoya', meaning: 'Alive, Loving life', origin: 'Russian', initial: 'Z' },
        { name: 'Avani', meaning: 'Earth, Mother Nature', origin: 'Indian', initial: 'A' },
        { name: 'Maya', meaning: 'Illusion, Creative magic', origin: 'Indian', initial: 'M' }
      ],
      unisex: [
        { name: 'Rowan', meaning: 'Little red one, Tree of life', origin: 'Gaelic', initial: 'R' },
        { name: 'Avery', meaning: 'Ruler of spirits', origin: 'English', initial: 'A' },
        { name: 'Kiran', meaning: 'Ray of sunlight', origin: 'Indian', initial: 'K' },
        { name: 'Jordan', meaning: 'Flowing down', origin: 'Hebrew', initial: 'J' },
        { name: 'Amrit', meaning: 'Nectar of immortality', origin: 'Indian', initial: 'A' },
        { name: 'Kai', meaning: 'Ocean, Sea breeze', origin: 'Hawaiian', initial: 'K' },
        { name: 'Noor', meaning: 'Divine light', origin: 'Arabic', initial: 'N' },
        { name: 'Riley', meaning: 'Courageous, Meadow', origin: 'Irish', initial: 'R' },
        { name: 'Milan', meaning: 'Union, Gracious', origin: 'Slavic', initial: 'M' },
        { name: 'Eden', meaning: 'Delight, Paradise', origin: 'Hebrew', initial: 'E' },
        { name: 'Shiloh', meaning: 'Peaceful, Tranquil', origin: 'Hebrew', initial: 'S' },
        { name: 'Samar', meaning: 'Fruit of effort, Evening conversation', origin: 'Arabic', initial: 'S' }
      ],
      twins: [
        { pair: ['Aarav', 'Ananya'], theme: 'Harmony & Light', score: 98 },
        { pair: ['Leo', 'Luna'], theme: 'Sun & Moon', score: 99 },
        { pair: ['Reyansh', 'Rhea'], theme: 'Radiance & Grace', score: 96 },
        { pair: ['Oliver', 'Olivia'], theme: 'Peaceful Blossoms', score: 97 },
        { pair: ['Advik', 'Aditi'], theme: 'Unique & Boundless', score: 95 },
        { pair: ['Kai', 'Kiran'], theme: 'Ocean & Sunlight', score: 96 },
        { pair: ['Milo', 'Mia'], theme: 'Beloved Joy', score: 98 },
        { pair: ['Kabir', 'Kiara'], theme: 'Leadership & Clarity', score: 94 },
        { pair: ['Finn', 'Faye'], theme: 'Fair & Enchanted', score: 95 },
        { pair: ['Aryan', 'Aarya'], theme: 'Noble & Respectful', score: 97 }
      ]
    },

    // Curated Gaming, Esports & Clan Banks
    gaming: {
      tacticalPrefixes: ['Shadow', 'Vortex', 'Phantom', 'Apex', 'Cyber', 'Frost', 'Viper', 'Havoc', 'Rogue', 'Titan', 'Zenith', 'Echo', 'Neon', 'Specter', 'Oblivion', 'Grim', 'Venom', 'Hyper', 'Nova', 'Storm'],
      warriorNouns: ['Reaper', 'Slayer', 'Ghost', 'Knight', 'Striker', 'Hunter', 'Blade', 'Phoenix', 'Ninja', 'Wolf', 'Sniper', 'Assassin', 'Warlord', 'Samurai', 'Falcon', 'Sentinel', 'Titan', 'Vanguard', 'Beast'],
      esportsTags: ['FAZE', 'OPTIC', 'NAVI', 'TSM', 'CLOUD', 'TALON', 'AURA', 'REAP', 'VORT', 'NOVA', 'ZEN', 'APEX', 'MYTH', 'ECHO', 'VOID', 'LNR', 'SYNX', 'KRON', 'HYPR', 'GLYT'],
      clanNouns: ['Legion', 'Syndicate', 'Vanguard', 'Order', 'Brotherhood', 'Dynasty', 'Imperium', 'Dominion', 'Alliance', 'Squadron', 'Brigade', 'Outlaws', 'Phalanx', 'Ascendants', 'Elites'],
      robloxWords: ['Blox', 'Noob', 'Obby', 'Tycoon', 'Adopt', 'Pixel', 'Robloxian', 'Glitch', 'Spark', 'Speedy', 'Tower', 'Crafty'],
      minecraftWords: ['Creeper', 'Miner', 'Craft', 'Redstone', 'Nether', 'Ender', 'Diamond', 'Blocky', 'Obsidian', 'Elytra', 'Golem', 'Biome'],
      fortniteWords: ['Sniper', 'Victory', 'Royale', 'Storm', 'Builder', 'Chug', 'Rift', 'Llama', 'Tilted', 'Drop', 'Pump', 'Zone']
    },

    // Social Media, Influencer & Aesthetic Words
    social: {
      aestheticAdjectives: ['velvet', 'cosmic', 'golden', 'ethereal', 'honey', 'vintage', 'pastel', 'cloudy', 'midnight', 'blooming', 'glow', 'dreamy', 'hazel', 'mystic', 'chilled', 'serene', 'starlight', 'radiant'],
      nouns: ['vibes', 'diaries', 'soul', 'muse', 'studio', 'aesthetic', 'palette', 'haven', 'whisper', 'glow', 'tales', 'aura', 'journal', 'lane', 'craft', 'moments', 'echo', 'bliss'],
      youtubeCategories: {
        gaming: ['Plays', 'Gaming', 'Arcade', 'Walkthroughs', 'Central', 'Zone', 'Hub'],
        vlog: ['Diaries', 'Life', 'Vlogs', 'Journeys', 'Chronicles', 'Unfiltered'],
        tech: ['Tech', 'Lab', 'Reviews', 'Bytes', 'Geek', 'Breakdown', 'Innovations'],
        beauty: ['Glam', 'Glow', 'Chic', 'Styles', 'Looks', 'Beauty', 'Studio']
      }
    },

    // Business, Startup, Store, & Branding Affixes
    business: {
      prefixes: ['Omni', 'Nova', 'Apex', 'Aero', 'Syn', 'Meta', 'Hyper', 'True', 'Zen', 'Pulse', 'Strat', 'Peak', 'Nexus', 'Vivid', 'Quantum', 'Opti', 'Lumina', 'Core', 'Prime', 'Sol'],
      suffixes: ['ify', 'ly', 'io', 'lab', 'hub', 'forge', 'sync', 'flow', 'stack', 'craft', 'wave', 'scale', 'verse', 'zone', 'mate', 'base', 'bridge', 'path', 'nest', 'link'],
      domains: ['.com', '.io', '.ai', '.co', '.app', '.dev', '.store', '.tech', '.solutions'],
      cafeKeywords: ['Bean', 'Roast', 'Brew', 'Mocha', 'Espresso', 'Aroma', 'Crumbs', 'Cozy', 'Cup', 'Haven', 'Steam', 'Perk'],
      clothingKeywords: ['Threads', 'Apparel', 'Atelier', 'Wear', 'Couture', 'Stitch', 'Loom', 'Vibe', 'Attire', 'Drape', 'Fabric', 'Closet'],
      restaurantKeywords: ['Bistro', 'Table', 'Kitchen', 'Plate', 'Palate', 'Fork', 'Gourmet', 'Rustic', 'Spices', 'Feast', 'Haven', 'Grill']
    },

    // Nicknames Collections
    nicknames: {
      cute: ['Peanut', 'Boba', 'Honeybee', 'Cuddlebug', 'Mochi', 'Pudding', 'Cupcake', 'Sweetpea', 'Pip', 'Bubbles', 'Button', 'Cookie', 'Nugget', 'Bunny'],
      funny: ['Potato', 'Chaos Gremlin', 'Sir Laughs-a-lot', 'Captain Sarcasm', 'Goofball', 'Noodle', 'Snooze King', 'Snack Monster', 'Taco Chief', 'Troublemaker'],
      cool: ['Ace', 'Maverick', 'Shadow', 'Blaze', 'Phoenix', 'Rogue', 'Dash', 'Falcon', 'Ghost', 'Nova', 'Viper', 'Striker', 'Titan', 'Apex'],
      attitude: ['Boss', 'Savage', 'Rebel', 'Ruthless', 'Outlaw', 'Alpha', 'Dynamo', 'Wildcard', 'Havoc', 'Vandal', 'Fury', 'Ringleader'],
      bestFriend: ['Buddy', 'Partner in Crime', 'Homie', 'Twin', 'Sidekick', 'Rockstar', 'Ride or Die', 'Champ', 'Bestie', 'Soul Sister', 'Brother from another Mother'],
      boy: ['Champ', 'Tiger', 'Chief', 'Scout', 'Bruiser', 'Rocket', 'Hawk', 'Spike', 'Captain', 'Maverick', 'Tank', 'Blaze', 'Ranger', 'Striker'],
      girl: ['Dolly', 'Sunny', 'Buttercup', 'Pixie', 'Bambi', 'Bella', 'Princess', 'Twinkle', 'Daisy', 'Blossom', 'Starlet', 'Sparky', 'Goddess'],
      instagram: ['vibe_seeker', 'aesthetic_soul', 'velvet_muse', 'golden_hour', 'soft_whisper', 'daily_dreamer', 'luxe_lens', 'cosmic_bloom'],
      gaming: ['FragKing', 'SilentSniper', 'NightRaven', 'ShadowStrike', 'BloodHound', 'ViperVenom', 'HyperGhost', 'DeathBringer', 'ZeroAim']
    },

    // Creative, Fantasy, Band & Character
    creative: {
      fantasyPrefixes: ['Ael', 'Dra', 'Mor', 'Syl', 'Val', 'Thal', 'Zeph', 'Fen', 'Kael', 'Il', 'Cor', 'Bryn', 'Eld', 'Vor'],
      fantasySuffixes: ['dor', 'ryn', 'ion', 'wynn', 'mar', 'thas', 'vyn', 'riel', 'gorn', 'thiel', 'dras', 'mir'],
      bandVibes: ['The Electric', 'Velvet', 'Midnight', 'Neon', 'Silent', 'Cosmic', 'Echoing', 'Rogue', 'Crimson', 'Sonic', 'Astral', 'Broken'],
      bandNouns: ['Monkeys', 'Orchestra', 'Echoes', 'Mirage', 'Skeletons', 'Tides', 'Rebels', 'Kingdom', 'Prophets', 'Wolves', 'Signals', 'Dreamers'],
      podcastKeywords: ['Cast', 'Uncut', 'Deep Dive', 'Chronicles', 'Sessions', 'Show', 'Conversations', 'Room', 'Hour', 'Frequency', 'Insider']
    }
  };

  window.NameData = NameData;
})();
