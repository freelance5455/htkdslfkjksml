/**
 * Combiner Engine: Advanced Phonetic & Syllabic Name Fusion
 * Handles Couple, Baby, Business, Ship, Mixer, Blender, Mashup, Fusion, and Merger combinations.
 */
(function () {
  const Combiner = {
    clean(str) {
      return (str || '').trim().replace(/[^a-zA-Z\s]/g, '');
    },

    capitalize(str) {
      if (!str) return '';
      return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
    },

    getSyllables(word) {
      word = (word || '').toLowerCase();
      if (word.length <= 3) return [word];
      const vowels = 'aeiouy';
      const chunks = [];
      let cur = '';
      for (let i = 0; i < word.length; i++) {
        cur += word[i];
        if (vowels.includes(word[i]) && i < word.length - 1 && !vowels.includes(word[i + 1])) {
          chunks.push(cur);
          cur = '';
        }
      }
      if (cur) chunks.push(cur);
      return chunks.length > 0 ? chunks : [word];
    },

    calculateScore(name, n1, n2) {
      let score = 75;
      const len = name.length;

      // Ideal length 4 to 8 characters
      if (len >= 4 && len <= 8) score += 15;
      else if (len < 3 || len > 11) score -= 20;

      // Vowel ratio
      const vowels = (name.match(/[aeiouy]/gi) || []).length;
      const ratio = vowels / (len || 1);
      if (ratio >= 0.35 && ratio <= 0.6) score += 12;
      else if (ratio < 0.25 || ratio > 0.7) score -= 15;

      // Triple consonants penalty
      if (/[bcdfghjklmnpqrstvwxyz]{3,}/i.test(name)) score -= 25;

      // Double vowel smooth reward
      if (/[aeiou]{2}/i.test(name)) score += 5;

      return Math.min(99, Math.max(52, Math.round(score)));
    },

    combine(names, options = {}) {
      const mode = options.mode || 'couple';
      const style = options.style || 'creative';
      const count = parseInt(options.count, 10) || 12;
      const seed = options.seed || Math.random();

      const n1 = this.clean(names[0] || '');
      const n2 = this.clean(names[1] || '');
      const n3 = this.clean(names[2] || '');

      if (!n1 && !n2) return [];
      if (!n2) return [{ name: this.capitalize(n1), score: 95 }];

      const candidates = new Set();

      // 1. Prefix + Suffix cross combinations
      const mid1 = Math.max(1, Math.floor(n1.length / 2));
      const mid2 = Math.max(1, Math.floor(n2.length / 2));

      const p1 = n1.slice(0, Math.ceil(n1.length / 2));
      const s1 = n1.slice(mid1);
      const p2 = n2.slice(0, Math.ceil(n2.length / 2));
      const s2 = n2.slice(mid2);

      candidates.add(p1 + s2);
      candidates.add(p2 + s1);
      candidates.add(n1.slice(0, 2) + n2.slice(-3));
      candidates.add(n2.slice(0, 2) + n1.slice(-3));
      candidates.add(n1.slice(0, 3) + n2.slice(2));
      candidates.add(n2.slice(0, 3) + n1.slice(2));

      // 2. Phonological Overlap Detection
      for (let i = 1; i < n1.length; i++) {
        const endChunk = n1.slice(i).toLowerCase();
        if (n2.toLowerCase().startsWith(endChunk)) {
          candidates.add(n1.slice(0, i) + n2);
        }
      }
      for (let i = 1; i < n2.length; i++) {
        const endChunk = n2.slice(i).toLowerCase();
        if (n1.toLowerCase().startsWith(endChunk)) {
          candidates.add(n2.slice(0, i) + n1);
        }
      }

      // 3. Syllable Splicing
      const syl1 = this.getSyllables(n1);
      const syl2 = this.getSyllables(n2);
      syl1.forEach(c1 => {
        syl2.forEach(c2 => {
          candidates.add(c1 + c2);
          candidates.add(c2 + c1);
          if (c1.length >= 2 && c2.length >= 2) {
            candidates.add(c1.slice(0, 2) + c2);
            candidates.add(c2.slice(0, 2) + c1);
          }
        });
      });

      // 4. 3-Name Fusion (if 3rd name supplied)
      if (n3) {
        const p3 = n3.slice(0, Math.ceil(n3.length / 2));
        const s3 = n3.slice(Math.floor(n3.length / 2));
        candidates.add(p1 + p2.slice(0, 2) + s3);
        candidates.add(p3 + s1.slice(-2) + s2);
        candidates.add(n1.slice(0, 2) + n2.slice(0, 2) + n3.slice(-2));
        candidates.add(p2 + p3 + s1);
      }

      // 5. Mode-Specific Nuances
      if (mode === 'couple' || mode === 'romantic') {
        candidates.add(p1 + 'lyn');
        candidates.add(p2 + 'rose');
        candidates.add(p1 + 'ia');
        candidates.add(p2 + 'el');
      } else if (mode === 'baby') {
        const babyEndings = ['an', 'en', 'iel', 'ara', 'ora', 'iana', 'ik', 'a'];
        babyEndings.forEach(end => {
          candidates.add(p1.slice(0, 3) + end);
          candidates.add(p2.slice(0, 3) + end);
        });
      } else if (mode === 'business') {
        const bizEndings = ['ify', 'ly', 'io', 'sync', 'hub', 'ex', 'corp'];
        bizEndings.forEach(end => {
          candidates.add(p1 + end);
          candidates.add(p2 + end);
          candidates.add(p1.slice(0, 3) + p2.slice(0, 3) + end);
        });
      } else if (mode === 'ship') {
        candidates.add(n1.slice(0, 3) + n2.slice(-3));
        candidates.add(n2.slice(0, 3) + n1.slice(-3));
        candidates.add(n1.slice(0, 2) + n2);
        candidates.add(n2.slice(0, 2) + n1);
      } else if (mode === 'mashup') {
        candidates.add(`${n1}-${n2}`);
        candidates.add(`${n2}-${n1}`);
        candidates.add(`${p1}&${p2}`);
      } else if (mode === 'merger') {
        candidates.add(n1 + n2);
        candidates.add(n2 + n1);
      }

      // 6. Score, Filter, and Sort Results
      const list = [];
      const seen = new Set();

      Array.from(candidates).forEach(cand => {
        let cleanCand = cand.replace(/[^a-zA-Z\s\-]/g, '');
        if (cleanCand.length < 3 || cleanCand.length > 15) return;
        const normalized = this.capitalize(cleanCand);
        if (seen.has(normalized.toLowerCase())) return;
        seen.add(normalized.toLowerCase());

        const score = this.calculateScore(normalized, n1, n2);
        list.push({ name: normalized, score });
      });

      // Sort primarily by score with slight deterministic jitter based on seed
      list.sort((a, b) => {
        const jitter = (Math.sin(a.name.length + seed * 10) - Math.sin(b.name.length + seed * 10)) * 4;
        return (b.score - a.score) + jitter;
      });

      return list.slice(0, count);
    }
  };

  window.CombinerEngine = Combiner;
})();
