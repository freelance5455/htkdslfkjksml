/**
 * Formatter Engine: Text Transformation, Unicode Fonts, Hashtags, Acronyms, Initials & Anagrams
 * Powers Stylish, Fancy, Aesthetic, Hashtags, Acronyms, Initials, Abbreviations, and Anagrams.
 */
(function () {
  const Formatter = {
    clean(str) {
      return (str || '').trim();
    },

    convertFont(text, fontMap) {
      if (!fontMap) return text;
      return text.split('').map(char => fontMap[char] || char).join('');
    },

    generateHashtags(n1, n2, year = new Date().getFullYear()) {
      n1 = this.clean(n1).replace(/[^a-zA-Z]/g, '');
      n2 = this.clean(n2).replace(/[^a-zA-Z]/g, '');
      const p1 = n1.charAt(0).toUpperCase() + n1.slice(1);
      const p2 = n2.charAt(0).toUpperCase() + n2.slice(1);

      return [
        `#${p1}Weds${p2}`,
        `#${p1}And${p2}Forever`,
        `#${p1}${p2}${year}`,
        `#HitchedWith${p2}`,
        `#Finally${p1}And${p2}`,
        `#TwoBecomeOne${p1}${p2}`,
        `#${p1}FoundHis${p2}`,
        `#${p2}SaidYesTo${p1}`,
        `#The${p1}And${p2}Story`,
        `#ForeverStartsNow${p1}${p2}`,
        `#HappilyEver${p1}${p2}`,
        `#${p1}${p2}LoveStory`
      ].map((tag, idx) => ({
        name: tag,
        score: 99 - idx
      }));
    },

    generateAcronyms(name) {
      const clean = this.clean(name).toUpperCase().replace(/[^A-Z]/g, '');
      if (!clean) return [];

      const dict = {
        A: ['Authentic', 'Ambitious', 'Adventurous', 'Astonishing'],
        B: ['Brilliant', 'Brave', 'Boundless', 'Bold'],
        C: ['Creative', 'Courageous', 'Charming', 'Charismatic'],
        D: ['Dynamic', 'Daring', 'Dedicated', 'Delightful'],
        E: ['Energetic', 'Empowered', 'Enchanting', 'Epic'],
        F: ['Fearless', 'Focused', 'Friendly', 'Fierce'],
        G: ['Genuine', 'Graceful', 'Generous', 'Glorious'],
        H: ['Honorable', 'Harmonious', 'Heroic', 'Heartfelt'],
        I: ['Inspiring', 'Innovative', 'Intelligent', 'Invincible'],
        J: ['Joyful', 'Just', 'Jubilant', 'Judicious'],
        K: ['Kindhearted', 'Keen', 'Knowledgeable', 'Kinetic'],
        L: ['Luminous', 'Loyal', 'Legendary', 'Loving'],
        M: ['Magnificent', 'Mindful', 'Motivated', 'Masterful'],
        N: ['Noble', 'Naturally gifted', 'Nurturing', 'Notable'],
        O: ['Optimistic', 'Original', 'Outstanding', 'Open-hearted'],
        P: ['Passionate', 'Powerful', 'Peaceful', 'Persistent'],
        Q: ['Quick-witted', 'Quietly confident', 'Quintessential'],
        R: ['Resilient', 'Radiant', 'Remarkable', 'Reliable'],
        S: ['Steadfast', 'Sincere', 'Spirited', 'Shining'],
        T: ['Trustworthy', 'Tenacious', 'Talented', 'Thoughtful'],
        U: ['Unstoppable', 'Unique', 'Uplifting', 'Unwavering'],
        V: ['Visionary', 'Vibrant', 'Valiant', 'Victorious'],
        W: ['Wise', 'Warm-hearted', 'Wonderful', 'Witty'],
        X: ['Xceptional', 'Xtraordinary', 'Xpert'],
        Y: ['Youthful', 'Yearning for excellence', 'Yielding wisdom'],
        Z: ['Zealous', 'Zenith-seeking', 'Zestful']
      };

      const results = [];
      for (let cycle = 0; cycle < 4; cycle++) {
        const words = clean.split('').map(char => {
          const options = dict[char] || ['Special'];
          return options[cycle % options.length];
        });

        results.push({
          name: words.join(' • '),
          desc: `Acronym for ${clean}`,
          score: 95 - cycle * 2
        });
      }

      return results;
    },

    generateInitials(name) {
      const parts = this.clean(name).split(/\s+/).filter(Boolean);
      const rawInitials = parts.map(p => p[0].toUpperCase()).join('');

      return [
        { name: rawInitials, desc: 'Classic Uppercase Monogram', score: 98 },
        { name: rawInitials.split('').join('. ') + '.', desc: 'Punctuation Monogram', score: 97 },
        { name: `[ ${rawInitials} ]`, desc: 'Modern Brackets', score: 95 },
        { name: `• ${rawInitials} •`, desc: 'Minimal Bullet Accent', score: 94 },
        { name: `⚜️ ${rawInitials} ⚜️`, desc: 'Royal Crest Monogram', score: 93 },
        { name: `✨ ${rawInitials} ✨`, desc: 'Sparkle Monogram', score: 92 },
        { name: `« ${rawInitials} »`, desc: 'Guillemet Badge', score: 91 },
        { name: `// ${rawInitials} //`, desc: 'Tech Monogram', score: 90 }
      ];
    },

    generateShortener(name) {
      const clean = this.clean(name);
      if (!clean) return [];

      const vowelsRemoved = clean.replace(/[aeiou]/gi, '');
      const firstThree = clean.slice(0, 3);
      const firstFour = clean.slice(0, 4);

      return [
        { name: clean.slice(0, 3).toUpperCase(), desc: '3-Letter Abbreviation', score: 96 },
        { name: clean.slice(0, 4), desc: '4-Letter Short Nickname', score: 95 },
        { name: vowelsRemoved || clean, desc: 'Disemvoweled Punchy Handle', score: 94 },
        { name: `${firstThree}y`, desc: 'Diminutive Ending', score: 92 },
        { name: `${firstThree}o`, desc: 'Modern Slang Ending', score: 91 }
      ];
    },

    generateAnagrams(name) {
      const clean = this.clean(name).toLowerCase().replace(/[^a-z]/g, '');
      if (!clean) return [];

      const chars = clean.split('');
      const anagrams = new Set();

      // Simple deterministic permutations
      for (let i = 0; i < 20; i++) {
        const shuffled = [...chars].sort(() => Math.sin(i * 3 + 1) - 0.5).join('');
        if (shuffled !== clean) anagrams.add(shuffled);
      }

      return Array.from(anagrams).slice(0, 8).map((ana, idx) => ({
        name: ana.charAt(0).toUpperCase() + ana.slice(1),
        desc: `Anagram permutation of ${name}`,
        score: 90 - idx
      }));
    },

    format(text, options = {}) {
      const data = window.NameData || {};
      const type = options.type || 'stylish-name-generator';
      const cleanText = this.clean(text) || 'Name';

      // 1. Hashtags
      if (type.includes('hashtag')) {
        const n1 = options.name1 || text;
        const n2 = options.name2 || 'Partner';
        return this.generateHashtags(n1, n2);
      }

      // 2. Acronyms
      if (type === 'name-acronym-generator') {
        return this.generateAcronyms(cleanText);
      }

      // 3. Initials
      if (type === 'name-initials-generator') {
        return this.generateInitials(cleanText);
      }

      // 4. Shortener / Abbreviation
      if (type === 'name-shortener' || type === 'name-abbreviation-generator' || type === 'short-nickname-generator') {
        return this.generateShortener(cleanText);
      }

      // 5. Anagrams
      if (type === 'name-anagram-generator') {
        return this.generateAnagrams(cleanText);
      }

      // 6. Stylish & Fancy Unicode Fonts + Frames
      const fonts = data.unicodeFonts || {};
      const frames = data.symbolFrames || [];

      const results = [
        { name: this.convertFont(cleanText, fonts.boldSans), desc: 'Bold Sans Font', score: 99 },
        { name: this.convertFont(cleanText, fonts.boldSerif), desc: 'Bold Serif Font', score: 98 },
        { name: this.convertFont(cleanText, fonts.gothic), desc: 'Gothic Fraktur', score: 97 },
        { name: this.convertFont(cleanText, fonts.script), desc: 'Calligraphy Script', score: 96 },
        { name: this.convertFont(cleanText, fonts.doubleStruck), desc: 'Double-Struck / Chalkboard', score: 95 },
        { name: this.convertFont(cleanText, fonts.circled), desc: 'Bubble / Circled Letters', score: 94 },
        { name: this.convertFont(cleanText, fonts.smallCaps), desc: 'Small Capitals', score: 93 },
        { name: this.convertFont(cleanText, fonts.monospace), desc: 'Typewriter Monospace', score: 92 }
      ];

      // Add symbol frames
      frames.slice(0, 6).forEach((frameFn, idx) => {
        results.push({
          name: frameFn(cleanText),
          desc: 'Aesthetic Symbol Frame',
          score: 91 - idx
        });
      });

      return results;
    }
  };

  window.FormatterEngine = Formatter;
})();
