/**
 * Universal Tool Runner
 * Binds UI inputs, form submissions, regenerate, copy, favorites, and share across all 100 tools.
 */
document.addEventListener('DOMContentLoaded', () => {
  const form = document.querySelector('form.tool-form') || document.querySelector('form');
  const resultsContainer = document.getElementById('results-list');
  const resultsCountSpan = document.getElementById('results-count');
  const emptyState = document.getElementById('empty-state');
  const resultsCard = document.getElementById('results-card');
  const resetBtn = document.getElementById('reset-btn');
  const copyAllBtn = document.getElementById('copy-all-btn');
  const regenerateBtn = document.getElementById('regenerate-btn');

  if (!form || !window.TOOL_CONFIG) return;

  let currentSeed = 1;

  function collectInputs() {
    const inputs = { seed: currentSeed };
    const elements = form.elements;
    for (let i = 0; i < elements.length; i++) {
      const el = elements[i];
      if (el.name || el.id) {
        const key = el.name || el.id;
        inputs[key] = el.type === 'checkbox' ? el.checked : el.value;
      }
    }
    return inputs;
  }

  function renderResults(results) {
    if (!resultsContainer) return;
    resultsContainer.innerHTML = '';

    if (!results || results.length === 0) {
      if (emptyState) emptyState.classList.remove('hidden');
      if (resultsCard) resultsCard.classList.add('hidden');
      return;
    }

    if (emptyState) emptyState.classList.add('hidden');
    if (resultsCard) resultsCard.classList.remove('hidden');
    if (resultsCountSpan) resultsCountSpan.textContent = results.length;

    // Qualitative label instead of fake percentage precision — the underlying
    // number is an internal heuristic score, not a real-world match/availability rate.
    function qualityLabel(score) {
      const s = typeof score === 'number' ? score : 85;
      if (s >= 92) return 'Strong Match';
      if (s >= 82) return 'Good Blend';
      if (s >= 70) return 'Creative Pick';
      return 'Alternative';
    }

    results.forEach((item, index) => {
      const safeName = escapeHtml(item.name);
      const isFav = window.FavoritesManager ? window.FavoritesManager.isFavorite(item.name) : false;
      const card = document.createElement('div');
      card.className = 'result-card flex items-center justify-between p-3.5 sm:p-4 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700/80 shadow-sm animate-fade-in hover:border-indigo-500/40 transition';

      const badgeHtml = item.desc ?
        `<span class="ml-2 inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-slate-100 text-slate-700 dark:bg-slate-700 dark:text-slate-300">${escapeHtml(item.desc)}</span>` :
        `<span class="ml-2 inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-emerald-50 text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800/50">${qualityLabel(item.score)}</span>`;

      card.innerHTML = `
        <div class="flex items-center gap-3 overflow-hidden">
          <span class="w-6 text-xs font-bold text-slate-400 dark:text-slate-500 shrink-0">${index + 1}.</span>
          <div class="truncate">
            <span class="text-base sm:text-lg font-bold text-slate-900 dark:text-white tracking-wide result-name">${safeName}</span>
            ${badgeHtml}
          </div>
        </div>
        <div class="flex items-center gap-1.5 sm:gap-2 shrink-0">
          <button type="button" class="copy-single-btn p-2 text-slate-500 hover:text-indigo-600 dark:text-slate-400 dark:hover:text-indigo-400 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition" title="Copy name" data-name="${safeName}">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"/></svg>
          </button>
          <button type="button" class="fav-single-btn p-2 text-slate-500 hover:text-rose-500 dark:text-slate-400 dark:hover:text-rose-400 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition ${isFav ? 'text-rose-500 dark:text-rose-400' : ''}" title="Favorite" data-name="${safeName}">
            <svg class="w-4 h-4" fill="${isFav ? 'currentColor' : 'none'}" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/></svg>
          </button>
          <button type="button" class="share-single-btn p-2 text-slate-500 hover:text-sky-600 dark:text-slate-400 dark:hover:text-sky-400 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition" title="Share" data-name="${safeName}">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z"/></svg>
          </button>
        </div>
      `;
      resultsContainer.appendChild(card);
    });

    // Event listeners
    resultsContainer.querySelectorAll('.copy-single-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        if (window.copyToClipboard) window.copyToClipboard(btn.dataset.name);
      });
    });

    resultsContainer.querySelectorAll('.fav-single-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const name = btn.dataset.name;
        if (window.FavoritesManager) {
          const isAdded = window.FavoritesManager.toggle(name, window.TOOL_CONFIG.category, window.TOOL_CONFIG.title);
          const icon = btn.querySelector('svg');
          if (isAdded) {
            btn.classList.add('text-rose-500', 'dark:text-rose-400');
            icon.setAttribute('fill', 'currentColor');
          } else {
            btn.classList.remove('text-rose-500', 'dark:text-rose-400');
            icon.setAttribute('fill', 'none');
          }
        }
      });
    });

    resultsContainer.querySelectorAll('.share-single-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        if (window.shareName) window.shareName(btn.dataset.name, window.TOOL_CONFIG.title);
      });
    });
  }

  function runGeneration() {
    const inputs = collectInputs();
    if (window.NameEngine) {
      const results = window.NameEngine.execute(window.TOOL_CONFIG, inputs);
      renderResults(results);
      if (resultsCard) {
        resultsCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }
    }
  }

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    currentSeed = Math.random() * 1000 + 1;
    runGeneration();
  });

  if (regenerateBtn) {
    regenerateBtn.addEventListener('click', () => {
      currentSeed = Math.random() * 1000 + 1;
      runGeneration();
      if (window.showToast) window.showToast('Regenerated fresh combinations!');
    });
  }

  if (resetBtn) {
    resetBtn.addEventListener('click', () => {
      form.reset();
      if (resultsContainer) resultsContainer.innerHTML = '';
      if (resultsCard) resultsCard.classList.add('hidden');
      if (emptyState) emptyState.classList.remove('hidden');
    });
  }

  if (copyAllBtn) {
    copyAllBtn.addEventListener('click', () => {
      const names = Array.from(resultsContainer.querySelectorAll('.result-name'))
        .map(el => el.textContent.trim());
      if (names.length > 0 && window.copyToClipboard) {
        window.copyToClipboard(names.join('\n'), `Copied ${names.length} names to clipboard!`);
      }
    });
  }
});
