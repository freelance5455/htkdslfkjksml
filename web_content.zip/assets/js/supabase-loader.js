/* LAMSA360 live catalog loader: falls back to the bundled catalog if API is unavailable. */
(() => {
  const cfg = window.LAMSA_CONFIG;
  const base = cfg.url + '/rest/v1/';
  const headers = { apikey: cfg.publishableKey, Authorization: 'Bearer ' + cfg.publishableKey };
  const get = async (table, query) => {
    const r = await fetch(base + table + '?' + query, { headers });
    if (!r.ok) throw new Error('Supabase ' + table + ': ' + r.status);
    return r.json();
  };
  const names = (r) => ({ ar:r.name_ar, fr:r.name_fr || r.name_ar, en:r.name_en || r.name_ar });
  window.LAMSA_READY = (async () => {
    try {
      const [cats, products, variants] = await Promise.all([
        get('categories','select=*&is_active=eq.true&order=sort_order.asc'),
        get('products','select=*&is_active=eq.true&order=sort_order.asc'),
        get('product_variants','select=*&is_active=eq.true&order=sort_order.asc')
      ]);
      if (!Array.isArray(cats) || !Array.isArray(products)) throw new Error('Invalid catalog response');
      const catById = Object.fromEntries(cats.map(c => [c.id,c]));
      const colorMap = {white:'#f4f2ec',black:'#1f2321',grey:'#a7a8a4',blue:'#5f7896',beige:'#e6dcc6',green:'#2f5d46',multi:'conic-gradient(#e9e4da 0 25%,#5b4a63 0 50%,#3f6a66 0 75%,#1f2321 0)'};
      const colorNames = {
        white:{ar:'أبيض',fr:'Blanc',en:'White'}, black:{ar:'أسود',fr:'Noir',en:'Black'},
        grey:{ar:'رمادي',fr:'Gris',en:'Grey'}, blue:{ar:'أزرق',fr:'Bleu',en:'Blue'},
        beige:{ar:'بيج وكريمي',fr:'Beige & crème',en:'Beige & cream'}, green:{ar:'أخضر',fr:'Vert',en:'Green'},
        multi:{ar:'ألوان متعددة',fr:'Multicolore',en:'Multicolour'}
      };
      const variantsByProduct = {};
      for (const v of variants) (variantsByProduct[v.product_id] ||= []).push({
        type: v.media_type === 'illustration' ? 'illus' : v.media_type,
        src: v.image_url || undefined, poster: v.poster_url || undefined,
        fam: v.color_keys || [], sw: (v.color_keys || []).length ? (colorMap[v.color_keys[0]] || '#d8b66a') : '#d8b66a',
        color: (v.color_keys || []).length ? (colorMap[v.color_keys[0]] || '#d8b66a') : '#d8b66a',
        name: { ar:v.name_ar, fr:v.name_fr || v.name_ar, en:v.name_en || v.name_ar }
      });
      window.CATALOG = {
        categories: cats.map(c => ({ id:c.slug, cover:c.image_url || '', name:names(c) })),
        soon: [],
        colors: Object.fromEntries(Object.entries(colorMap).map(([k,sw])=>[k,{sw,name:(colorNames[k] || {ar:k,fr:k,en:k})}])),
        sizes:['S','M','L','XL','XXL'],
        products: products.map(p => ({
          id:p.id, cat:(catById[p.category_id] || {}).slug || '', added:p.sort_order || 0,
          price:p.price_on_request ? null : Number(p.price),
          name:names(p),
          desc:{ar:p.description_ar || '',fr:p.description_fr || p.description_ar || '',en:p.description_en || p.description_ar || ''},
          details:{ar:[],fr:[],en:[]}, kw:'',
          variants:variantsByProduct[p.id] || (p.image_url ? [{type:'photo',src:p.image_url,fam:[],sw:'#d8b66a',name:{ar:'الصورة الرئيسية',fr:'Image principale',en:'Main image'}}] : [])
        }))
      };
      document.documentElement.dataset.catalogSource = 'supabase';
    } catch (e) {
      console.warn('LAMSA360: live catalog unavailable; using bundled catalog.', e);
      document.documentElement.dataset.catalogSource = 'fallback';
    }
  })();
})();
