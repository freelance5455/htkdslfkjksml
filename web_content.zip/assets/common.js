const fa=n=>String(n).replace(/\d/g,d=>"۰۱۲۳۴۵۶۷۸۹"[d]);
const norm=s=>s.replace(/[۰-۹]/g,d=>"۰۱۲۳۴۵۶۷۸۹".indexOf(d)).replace(/ي/g,"ی").replace(/ك/g,"ک").toLowerCase();
const PAL=[["#1e4d8c","#8fbcf2","rgba(63,130,220,.4)"],["#0f9d8a","#4fdcc6","rgba(20,184,160,.38)"],["#7c5cbf","#c2aff5","rgba(140,108,220,.4)"],["#d4a24c","#f3cc82","rgba(230,175,70,.38)"],["#d9577a","#f59bb5","rgba(230,95,135,.38)"]];
const pv=i=>{const p=PAL[i%5];return`--c:${p[0]};--t:${p[1]};--g:${p[2]}`};
const ROS='<svg class="ros" viewBox="0 0 64 64"><circle cx="32" cy="32" r="29" opacity=".7"/><path d="M15 15H49V49H15Z"/><path d="M32 6L58 32L32 58L6 32Z"/><circle class="dot" cx="32" cy="32" r="4"/></svg>';
const foot=()=>'<footer class="credit" aria-label="مشخصات طراح و توسعه‌دهنده"><i class="dm"></i><div class="credit-t"><small>طراحی و توسعه</small><b>اداره کل دفتر معاونت قوانین - اداره پایش و پیگیری امور تقنینی</b></div></footer>';
const esc=x=>x.replace(/[&<>]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;"}[c]));
if("serviceWorker"in navigator&&location.protocol.indexOf("http")===0)window.addEventListener("load",()=>navigator.serviceWorker.register("sw.js").catch(()=>{}));
