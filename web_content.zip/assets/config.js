/*
  CONFIGURAÇÃO DO BANCO DE VOTOS

  1) Crie um projeto no Supabase.
  2) Abra Project Settings > API.
  3) Cole aqui a URL do projeto e a chave anon/public.

  NÃO coloque aqui uma service_role key.
*/
window.MISS_CONFIG = {
  SUPABASE_URL: "COLE_AQUI_A_URL_DO_SUPABASE",
  SUPABASE_ANON_KEY: "COLE_AQUI_A_CHAVE_ANON"
};
