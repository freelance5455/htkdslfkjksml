(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const i of document.querySelectorAll('link[rel="modulepreload"]'))n(i);new MutationObserver(i=>{for(const s of i)if(s.type==="childList")for(const a of s.addedNodes)a.tagName==="LINK"&&a.rel==="modulepreload"&&n(a)}).observe(document,{childList:!0,subtree:!0});function e(i){const s={};return i.integrity&&(s.integrity=i.integrity),i.referrerPolicy&&(s.referrerPolicy=i.referrerPolicy),i.crossOrigin==="use-credentials"?s.credentials="include":i.crossOrigin==="anonymous"?s.credentials="omit":s.credentials="same-origin",s}function n(i){if(i.ep)return;i.ep=!0;const s=e(i);fetch(i.href,s)}})();/**
 * @license
 * Copyright 2010-2024 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const ka="170",Lc=0,mo=1,Dc=2,Ol=1,zl=2,Mn=3,Bn=0,Ne=1,Ve=2,Sn=0,ri=1,Ii=2,go=3,_o=4,Ic=5,Qn=100,Uc=101,Nc=102,Fc=103,Oc=104,zc=200,kc=201,Bc=202,Gc=203,Zr=204,Jr=205,Hc=206,Vc=207,Wc=208,Xc=209,qc=210,$c=211,Yc=212,jc=213,Kc=214,Qr=0,ta=1,ea=2,Ui=3,na=4,ia=5,sa=6,ra=7,kl=0,Zc=1,Jc=2,zn=0,Bl=1,Gl=2,Hl=3,Ba=4,Qc=5,Vl=6,Wl=7,Xl=300,Ni=301,Fi=302,aa=303,oa=304,rr=306,Zs=1e3,ni=1001,la=1002,We=1003,th=1004,ps=1005,cn=1006,hr=1007,ii=1008,Tn=1009,ql=1010,$l=1011,hs=1012,Ga=1013,ai=1014,hn=1015,bn=1016,Ha=1017,Va=1018,Oi=1020,Yl=35902,jl=1021,Kl=1022,nn=1023,Zl=1024,Jl=1025,Pi=1026,zi=1027,Wa=1028,Xa=1029,Ql=1030,qa=1031,$a=1033,Ws=33776,Xs=33777,qs=33778,$s=33779,ca=35840,ha=35841,ua=35842,fa=35843,da=36196,pa=37492,ma=37496,ga=37808,_a=37809,xa=37810,va=37811,Ma=37812,ya=37813,Sa=37814,ba=37815,wa=37816,Ta=37817,Ea=37818,Aa=37819,Ra=37820,Ca=37821,Ys=36492,Pa=36494,La=36495,tc=36283,Da=36284,Ia=36285,Ua=36286,eh=3200,nh=3201,ec=0,ih=1,On="",Ue="srgb",Hi="srgb-linear",ar="linear",se="srgb",fi=7680,xo=519,sh=512,rh=513,ah=514,nc=515,oh=516,lh=517,ch=518,hh=519,vo=35044,si=35048,Mo="300 es",yn=2e3,Js=2001;class Vi{addEventListener(t,e){this._listeners===void 0&&(this._listeners={});const n=this._listeners;n[t]===void 0&&(n[t]=[]),n[t].indexOf(e)===-1&&n[t].push(e)}hasEventListener(t,e){if(this._listeners===void 0)return!1;const n=this._listeners;return n[t]!==void 0&&n[t].indexOf(e)!==-1}removeEventListener(t,e){if(this._listeners===void 0)return;const i=this._listeners[t];if(i!==void 0){const s=i.indexOf(e);s!==-1&&i.splice(s,1)}}dispatchEvent(t){if(this._listeners===void 0)return;const n=this._listeners[t.type];if(n!==void 0){t.target=this;const i=n.slice(0);for(let s=0,a=i.length;s<a;s++)i[s].call(this,t);t.target=null}}}const Ae=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"];let yo=1234567;const os=Math.PI/180,ki=180/Math.PI;function Wi(){const r=Math.random()*4294967295|0,t=Math.random()*4294967295|0,e=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(Ae[r&255]+Ae[r>>8&255]+Ae[r>>16&255]+Ae[r>>24&255]+"-"+Ae[t&255]+Ae[t>>8&255]+"-"+Ae[t>>16&15|64]+Ae[t>>24&255]+"-"+Ae[e&63|128]+Ae[e>>8&255]+"-"+Ae[e>>16&255]+Ae[e>>24&255]+Ae[n&255]+Ae[n>>8&255]+Ae[n>>16&255]+Ae[n>>24&255]).toLowerCase()}function Te(r,t,e){return Math.max(t,Math.min(e,r))}function Ya(r,t){return(r%t+t)%t}function uh(r,t,e,n,i){return n+(r-t)*(i-n)/(e-t)}function fh(r,t,e){return r!==t?(e-r)/(t-r):0}function ls(r,t,e){return(1-e)*r+e*t}function dh(r,t,e,n){return ls(r,t,1-Math.exp(-e*n))}function ph(r,t=1){return t-Math.abs(Ya(r,t*2)-t)}function mh(r,t,e){return r<=t?0:r>=e?1:(r=(r-t)/(e-t),r*r*(3-2*r))}function gh(r,t,e){return r<=t?0:r>=e?1:(r=(r-t)/(e-t),r*r*r*(r*(r*6-15)+10))}function _h(r,t){return r+Math.floor(Math.random()*(t-r+1))}function xh(r,t){return r+Math.random()*(t-r)}function vh(r){return r*(.5-Math.random())}function Mh(r){r!==void 0&&(yo=r);let t=yo+=1831565813;return t=Math.imul(t^t>>>15,t|1),t^=t+Math.imul(t^t>>>7,t|61),((t^t>>>14)>>>0)/4294967296}function yh(r){return r*os}function Sh(r){return r*ki}function bh(r){return(r&r-1)===0&&r!==0}function wh(r){return Math.pow(2,Math.ceil(Math.log(r)/Math.LN2))}function Th(r){return Math.pow(2,Math.floor(Math.log(r)/Math.LN2))}function Eh(r,t,e,n,i){const s=Math.cos,a=Math.sin,o=s(e/2),l=a(e/2),c=s((t+n)/2),h=a((t+n)/2),u=s((t-n)/2),f=a((t-n)/2),d=s((n-t)/2),g=a((n-t)/2);switch(i){case"XYX":r.set(o*h,l*u,l*f,o*c);break;case"YZY":r.set(l*f,o*h,l*u,o*c);break;case"ZXZ":r.set(l*u,l*f,o*h,o*c);break;case"XZX":r.set(o*h,l*g,l*d,o*c);break;case"YXY":r.set(l*d,o*h,l*g,o*c);break;case"ZYZ":r.set(l*g,l*d,o*h,o*c);break;default:console.warn("THREE.MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+i)}}function Ri(r,t){switch(t.constructor){case Float32Array:return r;case Uint32Array:return r/4294967295;case Uint16Array:return r/65535;case Uint8Array:return r/255;case Int32Array:return Math.max(r/2147483647,-1);case Int16Array:return Math.max(r/32767,-1);case Int8Array:return Math.max(r/127,-1);default:throw new Error("Invalid component type.")}}function De(r,t){switch(t.constructor){case Float32Array:return r;case Uint32Array:return Math.round(r*4294967295);case Uint16Array:return Math.round(r*65535);case Uint8Array:return Math.round(r*255);case Int32Array:return Math.round(r*2147483647);case Int16Array:return Math.round(r*32767);case Int8Array:return Math.round(r*127);default:throw new Error("Invalid component type.")}}const Ye={DEG2RAD:os,RAD2DEG:ki,generateUUID:Wi,clamp:Te,euclideanModulo:Ya,mapLinear:uh,inverseLerp:fh,lerp:ls,damp:dh,pingpong:ph,smoothstep:mh,smootherstep:gh,randInt:_h,randFloat:xh,randFloatSpread:vh,seededRandom:Mh,degToRad:yh,radToDeg:Sh,isPowerOfTwo:bh,ceilPowerOfTwo:wh,floorPowerOfTwo:Th,setQuaternionFromProperEuler:Eh,normalize:De,denormalize:Ri};class Bt{constructor(t=0,e=0){Bt.prototype.isVector2=!0,this.x=t,this.y=e}get width(){return this.x}set width(t){this.x=t}get height(){return this.y}set height(t){this.y=t}set(t,e){return this.x=t,this.y=e,this}setScalar(t){return this.x=t,this.y=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y)}copy(t){return this.x=t.x,this.y=t.y,this}add(t){return this.x+=t.x,this.y+=t.y,this}addScalar(t){return this.x+=t,this.y+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this}subScalar(t){return this.x-=t,this.y-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this}multiply(t){return this.x*=t.x,this.y*=t.y,this}multiplyScalar(t){return this.x*=t,this.y*=t,this}divide(t){return this.x/=t.x,this.y/=t.y,this}divideScalar(t){return this.multiplyScalar(1/t)}applyMatrix3(t){const e=this.x,n=this.y,i=t.elements;return this.x=i[0]*e+i[3]*n+i[6],this.y=i[1]*e+i[4]*n+i[7],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this}clampLength(t,e){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(t){return this.x*t.x+this.y*t.y}cross(t){return this.x*t.y-this.y*t.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(t){const e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;const n=this.dot(t)/e;return Math.acos(Te(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){const e=this.x-t.x,n=this.y-t.y;return e*e+n*n}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this}equals(t){return t.x===this.x&&t.y===this.y}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this}rotateAround(t,e){const n=Math.cos(e),i=Math.sin(e),s=this.x-t.x,a=this.y-t.y;return this.x=s*n-a*i+t.x,this.y=s*i+a*n+t.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}}class Xt{constructor(t,e,n,i,s,a,o,l,c){Xt.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],t!==void 0&&this.set(t,e,n,i,s,a,o,l,c)}set(t,e,n,i,s,a,o,l,c){const h=this.elements;return h[0]=t,h[1]=i,h[2]=o,h[3]=e,h[4]=s,h[5]=l,h[6]=n,h[7]=a,h[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(t){const e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],this}extractBasis(t,e,n){return t.setFromMatrix3Column(this,0),e.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(t){const e=t.elements;return this.set(e[0],e[4],e[8],e[1],e[5],e[9],e[2],e[6],e[10]),this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){const n=t.elements,i=e.elements,s=this.elements,a=n[0],o=n[3],l=n[6],c=n[1],h=n[4],u=n[7],f=n[2],d=n[5],g=n[8],_=i[0],m=i[3],p=i[6],x=i[1],y=i[4],v=i[7],R=i[2],T=i[5],E=i[8];return s[0]=a*_+o*x+l*R,s[3]=a*m+o*y+l*T,s[6]=a*p+o*v+l*E,s[1]=c*_+h*x+u*R,s[4]=c*m+h*y+u*T,s[7]=c*p+h*v+u*E,s[2]=f*_+d*x+g*R,s[5]=f*m+d*y+g*T,s[8]=f*p+d*v+g*E,this}multiplyScalar(t){const e=this.elements;return e[0]*=t,e[3]*=t,e[6]*=t,e[1]*=t,e[4]*=t,e[7]*=t,e[2]*=t,e[5]*=t,e[8]*=t,this}determinant(){const t=this.elements,e=t[0],n=t[1],i=t[2],s=t[3],a=t[4],o=t[5],l=t[6],c=t[7],h=t[8];return e*a*h-e*o*c-n*s*h+n*o*l+i*s*c-i*a*l}invert(){const t=this.elements,e=t[0],n=t[1],i=t[2],s=t[3],a=t[4],o=t[5],l=t[6],c=t[7],h=t[8],u=h*a-o*c,f=o*l-h*s,d=c*s-a*l,g=e*u+n*f+i*d;if(g===0)return this.set(0,0,0,0,0,0,0,0,0);const _=1/g;return t[0]=u*_,t[1]=(i*c-h*n)*_,t[2]=(o*n-i*a)*_,t[3]=f*_,t[4]=(h*e-i*l)*_,t[5]=(i*s-o*e)*_,t[6]=d*_,t[7]=(n*l-c*e)*_,t[8]=(a*e-n*s)*_,this}transpose(){let t;const e=this.elements;return t=e[1],e[1]=e[3],e[3]=t,t=e[2],e[2]=e[6],e[6]=t,t=e[5],e[5]=e[7],e[7]=t,this}getNormalMatrix(t){return this.setFromMatrix4(t).invert().transpose()}transposeIntoArray(t){const e=this.elements;return t[0]=e[0],t[1]=e[3],t[2]=e[6],t[3]=e[1],t[4]=e[4],t[5]=e[7],t[6]=e[2],t[7]=e[5],t[8]=e[8],this}setUvTransform(t,e,n,i,s,a,o){const l=Math.cos(s),c=Math.sin(s);return this.set(n*l,n*c,-n*(l*a+c*o)+a+t,-i*c,i*l,-i*(-c*a+l*o)+o+e,0,0,1),this}scale(t,e){return this.premultiply(ur.makeScale(t,e)),this}rotate(t){return this.premultiply(ur.makeRotation(-t)),this}translate(t,e){return this.premultiply(ur.makeTranslation(t,e)),this}makeTranslation(t,e){return t.isVector2?this.set(1,0,t.x,0,1,t.y,0,0,1):this.set(1,0,t,0,1,e,0,0,1),this}makeRotation(t){const e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,n,e,0,0,0,1),this}makeScale(t,e){return this.set(t,0,0,0,e,0,0,0,1),this}equals(t){const e=this.elements,n=t.elements;for(let i=0;i<9;i++)if(e[i]!==n[i])return!1;return!0}fromArray(t,e=0){for(let n=0;n<9;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){const n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t}clone(){return new this.constructor().fromArray(this.elements)}}const ur=new Xt;function ic(r){for(let t=r.length-1;t>=0;--t)if(r[t]>=65535)return!0;return!1}function Qs(r){return document.createElementNS("http://www.w3.org/1999/xhtml",r)}function Ah(){const r=Qs("canvas");return r.style.display="block",r}const So={};function rs(r){r in So||(So[r]=!0,console.warn(r))}function Rh(r,t,e){return new Promise(function(n,i){function s(){switch(r.clientWaitSync(t,r.SYNC_FLUSH_COMMANDS_BIT,0)){case r.WAIT_FAILED:i();break;case r.TIMEOUT_EXPIRED:setTimeout(s,e);break;default:n()}}setTimeout(s,e)})}function Ch(r){const t=r.elements;t[2]=.5*t[2]+.5*t[3],t[6]=.5*t[6]+.5*t[7],t[10]=.5*t[10]+.5*t[11],t[14]=.5*t[14]+.5*t[15]}function Ph(r){const t=r.elements;t[11]===-1?(t[10]=-t[10]-1,t[14]=-t[14]):(t[10]=-t[10],t[14]=-t[14]+1)}const jt={enabled:!0,workingColorSpace:Hi,spaces:{},convert:function(r,t,e){return this.enabled===!1||t===e||!t||!e||(this.spaces[t].transfer===se&&(r.r=wn(r.r),r.g=wn(r.g),r.b=wn(r.b)),this.spaces[t].primaries!==this.spaces[e].primaries&&(r.applyMatrix3(this.spaces[t].toXYZ),r.applyMatrix3(this.spaces[e].fromXYZ)),this.spaces[e].transfer===se&&(r.r=Li(r.r),r.g=Li(r.g),r.b=Li(r.b))),r},fromWorkingColorSpace:function(r,t){return this.convert(r,this.workingColorSpace,t)},toWorkingColorSpace:function(r,t){return this.convert(r,t,this.workingColorSpace)},getPrimaries:function(r){return this.spaces[r].primaries},getTransfer:function(r){return r===On?ar:this.spaces[r].transfer},getLuminanceCoefficients:function(r,t=this.workingColorSpace){return r.fromArray(this.spaces[t].luminanceCoefficients)},define:function(r){Object.assign(this.spaces,r)},_getMatrix:function(r,t,e){return r.copy(this.spaces[t].toXYZ).multiply(this.spaces[e].fromXYZ)},_getDrawingBufferColorSpace:function(r){return this.spaces[r].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(r=this.workingColorSpace){return this.spaces[r].workingColorSpaceConfig.unpackColorSpace}};function wn(r){return r<.04045?r*.0773993808:Math.pow(r*.9478672986+.0521327014,2.4)}function Li(r){return r<.0031308?r*12.92:1.055*Math.pow(r,.41666)-.055}const bo=[.64,.33,.3,.6,.15,.06],wo=[.2126,.7152,.0722],To=[.3127,.329],Eo=new Xt().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),Ao=new Xt().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);jt.define({[Hi]:{primaries:bo,whitePoint:To,transfer:ar,toXYZ:Eo,fromXYZ:Ao,luminanceCoefficients:wo,workingColorSpaceConfig:{unpackColorSpace:Ue},outputColorSpaceConfig:{drawingBufferColorSpace:Ue}},[Ue]:{primaries:bo,whitePoint:To,transfer:se,toXYZ:Eo,fromXYZ:Ao,luminanceCoefficients:wo,outputColorSpaceConfig:{drawingBufferColorSpace:Ue}}});let di;class Lh{static getDataURL(t){if(/^data:/i.test(t.src)||typeof HTMLCanvasElement>"u")return t.src;let e;if(t instanceof HTMLCanvasElement)e=t;else{di===void 0&&(di=Qs("canvas")),di.width=t.width,di.height=t.height;const n=di.getContext("2d");t instanceof ImageData?n.putImageData(t,0,0):n.drawImage(t,0,0,t.width,t.height),e=di}return e.width>2048||e.height>2048?(console.warn("THREE.ImageUtils.getDataURL: Image converted to jpg for performance reasons",t),e.toDataURL("image/jpeg",.6)):e.toDataURL("image/png")}static sRGBToLinear(t){if(typeof HTMLImageElement<"u"&&t instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&t instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&t instanceof ImageBitmap){const e=Qs("canvas");e.width=t.width,e.height=t.height;const n=e.getContext("2d");n.drawImage(t,0,0,t.width,t.height);const i=n.getImageData(0,0,t.width,t.height),s=i.data;for(let a=0;a<s.length;a++)s[a]=wn(s[a]/255)*255;return n.putImageData(i,0,0),e}else if(t.data){const e=t.data.slice(0);for(let n=0;n<e.length;n++)e instanceof Uint8Array||e instanceof Uint8ClampedArray?e[n]=Math.floor(wn(e[n]/255)*255):e[n]=wn(e[n]);return{data:e,width:t.width,height:t.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),t}}let Dh=0;class sc{constructor(t=null){this.isSource=!0,Object.defineProperty(this,"id",{value:Dh++}),this.uuid=Wi(),this.data=t,this.dataReady=!0,this.version=0}set needsUpdate(t){t===!0&&this.version++}toJSON(t){const e=t===void 0||typeof t=="string";if(!e&&t.images[this.uuid]!==void 0)return t.images[this.uuid];const n={uuid:this.uuid,url:""},i=this.data;if(i!==null){let s;if(Array.isArray(i)){s=[];for(let a=0,o=i.length;a<o;a++)i[a].isDataTexture?s.push(fr(i[a].image)):s.push(fr(i[a]))}else s=fr(i);n.url=s}return e||(t.images[this.uuid]=n),n}}function fr(r){return typeof HTMLImageElement<"u"&&r instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&r instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&r instanceof ImageBitmap?Lh.getDataURL(r):r.data?{data:Array.from(r.data),width:r.width,height:r.height,type:r.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}let Ih=0;class Ce extends Vi{constructor(t=Ce.DEFAULT_IMAGE,e=Ce.DEFAULT_MAPPING,n=ni,i=ni,s=cn,a=ii,o=nn,l=Tn,c=Ce.DEFAULT_ANISOTROPY,h=On){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:Ih++}),this.uuid=Wi(),this.name="",this.source=new sc(t),this.mipmaps=[],this.mapping=e,this.channel=0,this.wrapS=n,this.wrapT=i,this.magFilter=s,this.minFilter=a,this.anisotropy=c,this.format=o,this.internalFormat=null,this.type=l,this.offset=new Bt(0,0),this.repeat=new Bt(1,1),this.center=new Bt(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new Xt,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=h,this.userData={},this.version=0,this.onUpdate=null,this.isRenderTargetTexture=!1,this.pmremVersion=0}get image(){return this.source.data}set image(t=null){this.source.data=t}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}clone(){return new this.constructor().copy(this)}copy(t){return this.name=t.name,this.source=t.source,this.mipmaps=t.mipmaps.slice(0),this.mapping=t.mapping,this.channel=t.channel,this.wrapS=t.wrapS,this.wrapT=t.wrapT,this.magFilter=t.magFilter,this.minFilter=t.minFilter,this.anisotropy=t.anisotropy,this.format=t.format,this.internalFormat=t.internalFormat,this.type=t.type,this.offset.copy(t.offset),this.repeat.copy(t.repeat),this.center.copy(t.center),this.rotation=t.rotation,this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrix.copy(t.matrix),this.generateMipmaps=t.generateMipmaps,this.premultiplyAlpha=t.premultiplyAlpha,this.flipY=t.flipY,this.unpackAlignment=t.unpackAlignment,this.colorSpace=t.colorSpace,this.userData=JSON.parse(JSON.stringify(t.userData)),this.needsUpdate=!0,this}toJSON(t){const e=t===void 0||typeof t=="string";if(!e&&t.textures[this.uuid]!==void 0)return t.textures[this.uuid];const n={metadata:{version:4.6,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(t).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),e||(t.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(t){if(this.mapping!==Xl)return t;if(t.applyMatrix3(this.matrix),t.x<0||t.x>1)switch(this.wrapS){case Zs:t.x=t.x-Math.floor(t.x);break;case ni:t.x=t.x<0?0:1;break;case la:Math.abs(Math.floor(t.x)%2)===1?t.x=Math.ceil(t.x)-t.x:t.x=t.x-Math.floor(t.x);break}if(t.y<0||t.y>1)switch(this.wrapT){case Zs:t.y=t.y-Math.floor(t.y);break;case ni:t.y=t.y<0?0:1;break;case la:Math.abs(Math.floor(t.y)%2)===1?t.y=Math.ceil(t.y)-t.y:t.y=t.y-Math.floor(t.y);break}return this.flipY&&(t.y=1-t.y),t}set needsUpdate(t){t===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(t){t===!0&&this.pmremVersion++}}Ce.DEFAULT_IMAGE=null;Ce.DEFAULT_MAPPING=Xl;Ce.DEFAULT_ANISOTROPY=1;class ge{constructor(t=0,e=0,n=0,i=1){ge.prototype.isVector4=!0,this.x=t,this.y=e,this.z=n,this.w=i}get width(){return this.z}set width(t){this.z=t}get height(){return this.w}set height(t){this.w=t}set(t,e,n,i){return this.x=t,this.y=e,this.z=n,this.w=i,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this.w=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setW(t){return this.w=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;case 3:this.w=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this.w=t.w!==void 0?t.w:1,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this.w+=t.w,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this.w+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this.w=t.w+e.w,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this.w+=t.w*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this.w-=t.w,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this.w-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this.w=t.w-e.w,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this.w*=t.w,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this.w*=t,this}applyMatrix4(t){const e=this.x,n=this.y,i=this.z,s=this.w,a=t.elements;return this.x=a[0]*e+a[4]*n+a[8]*i+a[12]*s,this.y=a[1]*e+a[5]*n+a[9]*i+a[13]*s,this.z=a[2]*e+a[6]*n+a[10]*i+a[14]*s,this.w=a[3]*e+a[7]*n+a[11]*i+a[15]*s,this}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this.w/=t.w,this}divideScalar(t){return this.multiplyScalar(1/t)}setAxisAngleFromQuaternion(t){this.w=2*Math.acos(t.w);const e=Math.sqrt(1-t.w*t.w);return e<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=t.x/e,this.y=t.y/e,this.z=t.z/e),this}setAxisAngleFromRotationMatrix(t){let e,n,i,s;const l=t.elements,c=l[0],h=l[4],u=l[8],f=l[1],d=l[5],g=l[9],_=l[2],m=l[6],p=l[10];if(Math.abs(h-f)<.01&&Math.abs(u-_)<.01&&Math.abs(g-m)<.01){if(Math.abs(h+f)<.1&&Math.abs(u+_)<.1&&Math.abs(g+m)<.1&&Math.abs(c+d+p-3)<.1)return this.set(1,0,0,0),this;e=Math.PI;const y=(c+1)/2,v=(d+1)/2,R=(p+1)/2,T=(h+f)/4,E=(u+_)/4,P=(g+m)/4;return y>v&&y>R?y<.01?(n=0,i=.707106781,s=.707106781):(n=Math.sqrt(y),i=T/n,s=E/n):v>R?v<.01?(n=.707106781,i=0,s=.707106781):(i=Math.sqrt(v),n=T/i,s=P/i):R<.01?(n=.707106781,i=.707106781,s=0):(s=Math.sqrt(R),n=E/s,i=P/s),this.set(n,i,s,e),this}let x=Math.sqrt((m-g)*(m-g)+(u-_)*(u-_)+(f-h)*(f-h));return Math.abs(x)<.001&&(x=1),this.x=(m-g)/x,this.y=(u-_)/x,this.z=(f-h)/x,this.w=Math.acos((c+d+p-1)/2),this}setFromMatrixPosition(t){const e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this.w=e[15],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this.w=Math.min(this.w,t.w),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this.w=Math.max(this.w,t.w),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this.z=Math.max(t.z,Math.min(e.z,this.z)),this.w=Math.max(t.w,Math.min(e.w,this.w)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this.z=Math.max(t,Math.min(e,this.z)),this.w=Math.max(t,Math.min(e,this.w)),this}clampLength(t,e){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z+this.w*t.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this.w+=(t.w-this.w)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this.w=t.w+(e.w-t.w)*n,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z&&t.w===this.w}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this.w=t[e+3],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t[e+3]=this.w,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this.w=t.getW(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}}class Uh extends Vi{constructor(t=1,e=1,n={}){super(),this.isRenderTarget=!0,this.width=t,this.height=e,this.depth=1,this.scissor=new ge(0,0,t,e),this.scissorTest=!1,this.viewport=new ge(0,0,t,e);const i={width:t,height:e,depth:1};n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:cn,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1},n);const s=new Ce(i,n.mapping,n.wrapS,n.wrapT,n.magFilter,n.minFilter,n.format,n.type,n.anisotropy,n.colorSpace);s.flipY=!1,s.generateMipmaps=n.generateMipmaps,s.internalFormat=n.internalFormat,this.textures=[];const a=n.count;for(let o=0;o<a;o++)this.textures[o]=s.clone(),this.textures[o].isRenderTargetTexture=!0;this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.resolveDepthBuffer=n.resolveDepthBuffer,this.resolveStencilBuffer=n.resolveStencilBuffer,this.depthTexture=n.depthTexture,this.samples=n.samples}get texture(){return this.textures[0]}set texture(t){this.textures[0]=t}setSize(t,e,n=1){if(this.width!==t||this.height!==e||this.depth!==n){this.width=t,this.height=e,this.depth=n;for(let i=0,s=this.textures.length;i<s;i++)this.textures[i].image.width=t,this.textures[i].image.height=e,this.textures[i].image.depth=n;this.dispose()}this.viewport.set(0,0,t,e),this.scissor.set(0,0,t,e)}clone(){return new this.constructor().copy(this)}copy(t){this.width=t.width,this.height=t.height,this.depth=t.depth,this.scissor.copy(t.scissor),this.scissorTest=t.scissorTest,this.viewport.copy(t.viewport),this.textures.length=0;for(let n=0,i=t.textures.length;n<i;n++)this.textures[n]=t.textures[n].clone(),this.textures[n].isRenderTargetTexture=!0;const e=Object.assign({},t.texture.image);return this.texture.source=new sc(e),this.depthBuffer=t.depthBuffer,this.stencilBuffer=t.stencilBuffer,this.resolveDepthBuffer=t.resolveDepthBuffer,this.resolveStencilBuffer=t.resolveStencilBuffer,t.depthTexture!==null&&(this.depthTexture=t.depthTexture.clone()),this.samples=t.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}}class sn extends Uh{constructor(t=1,e=1,n={}){super(t,e,n),this.isWebGLRenderTarget=!0}}class rc extends Ce{constructor(t=null,e=1,n=1,i=1){super(null),this.isDataArrayTexture=!0,this.image={data:t,width:e,height:n,depth:i},this.magFilter=We,this.minFilter=We,this.wrapR=ni,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(t){this.layerUpdates.add(t)}clearLayerUpdates(){this.layerUpdates.clear()}}class Nh extends Ce{constructor(t=null,e=1,n=1,i=1){super(null),this.isData3DTexture=!0,this.image={data:t,width:e,height:n,depth:i},this.magFilter=We,this.minFilter=We,this.wrapR=ni,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class kn{constructor(t=0,e=0,n=0,i=1){this.isQuaternion=!0,this._x=t,this._y=e,this._z=n,this._w=i}static slerpFlat(t,e,n,i,s,a,o){let l=n[i+0],c=n[i+1],h=n[i+2],u=n[i+3];const f=s[a+0],d=s[a+1],g=s[a+2],_=s[a+3];if(o===0){t[e+0]=l,t[e+1]=c,t[e+2]=h,t[e+3]=u;return}if(o===1){t[e+0]=f,t[e+1]=d,t[e+2]=g,t[e+3]=_;return}if(u!==_||l!==f||c!==d||h!==g){let m=1-o;const p=l*f+c*d+h*g+u*_,x=p>=0?1:-1,y=1-p*p;if(y>Number.EPSILON){const R=Math.sqrt(y),T=Math.atan2(R,p*x);m=Math.sin(m*T)/R,o=Math.sin(o*T)/R}const v=o*x;if(l=l*m+f*v,c=c*m+d*v,h=h*m+g*v,u=u*m+_*v,m===1-o){const R=1/Math.sqrt(l*l+c*c+h*h+u*u);l*=R,c*=R,h*=R,u*=R}}t[e]=l,t[e+1]=c,t[e+2]=h,t[e+3]=u}static multiplyQuaternionsFlat(t,e,n,i,s,a){const o=n[i],l=n[i+1],c=n[i+2],h=n[i+3],u=s[a],f=s[a+1],d=s[a+2],g=s[a+3];return t[e]=o*g+h*u+l*d-c*f,t[e+1]=l*g+h*f+c*u-o*d,t[e+2]=c*g+h*d+o*f-l*u,t[e+3]=h*g-o*u-l*f-c*d,t}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get w(){return this._w}set w(t){this._w=t,this._onChangeCallback()}set(t,e,n,i){return this._x=t,this._y=e,this._z=n,this._w=i,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(t){return this._x=t.x,this._y=t.y,this._z=t.z,this._w=t.w,this._onChangeCallback(),this}setFromEuler(t,e=!0){const n=t._x,i=t._y,s=t._z,a=t._order,o=Math.cos,l=Math.sin,c=o(n/2),h=o(i/2),u=o(s/2),f=l(n/2),d=l(i/2),g=l(s/2);switch(a){case"XYZ":this._x=f*h*u+c*d*g,this._y=c*d*u-f*h*g,this._z=c*h*g+f*d*u,this._w=c*h*u-f*d*g;break;case"YXZ":this._x=f*h*u+c*d*g,this._y=c*d*u-f*h*g,this._z=c*h*g-f*d*u,this._w=c*h*u+f*d*g;break;case"ZXY":this._x=f*h*u-c*d*g,this._y=c*d*u+f*h*g,this._z=c*h*g+f*d*u,this._w=c*h*u-f*d*g;break;case"ZYX":this._x=f*h*u-c*d*g,this._y=c*d*u+f*h*g,this._z=c*h*g-f*d*u,this._w=c*h*u+f*d*g;break;case"YZX":this._x=f*h*u+c*d*g,this._y=c*d*u+f*h*g,this._z=c*h*g-f*d*u,this._w=c*h*u-f*d*g;break;case"XZY":this._x=f*h*u-c*d*g,this._y=c*d*u-f*h*g,this._z=c*h*g+f*d*u,this._w=c*h*u+f*d*g;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+a)}return e===!0&&this._onChangeCallback(),this}setFromAxisAngle(t,e){const n=e/2,i=Math.sin(n);return this._x=t.x*i,this._y=t.y*i,this._z=t.z*i,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(t){const e=t.elements,n=e[0],i=e[4],s=e[8],a=e[1],o=e[5],l=e[9],c=e[2],h=e[6],u=e[10],f=n+o+u;if(f>0){const d=.5/Math.sqrt(f+1);this._w=.25/d,this._x=(h-l)*d,this._y=(s-c)*d,this._z=(a-i)*d}else if(n>o&&n>u){const d=2*Math.sqrt(1+n-o-u);this._w=(h-l)/d,this._x=.25*d,this._y=(i+a)/d,this._z=(s+c)/d}else if(o>u){const d=2*Math.sqrt(1+o-n-u);this._w=(s-c)/d,this._x=(i+a)/d,this._y=.25*d,this._z=(l+h)/d}else{const d=2*Math.sqrt(1+u-n-o);this._w=(a-i)/d,this._x=(s+c)/d,this._y=(l+h)/d,this._z=.25*d}return this._onChangeCallback(),this}setFromUnitVectors(t,e){let n=t.dot(e)+1;return n<Number.EPSILON?(n=0,Math.abs(t.x)>Math.abs(t.z)?(this._x=-t.y,this._y=t.x,this._z=0,this._w=n):(this._x=0,this._y=-t.z,this._z=t.y,this._w=n)):(this._x=t.y*e.z-t.z*e.y,this._y=t.z*e.x-t.x*e.z,this._z=t.x*e.y-t.y*e.x,this._w=n),this.normalize()}angleTo(t){return 2*Math.acos(Math.abs(Te(this.dot(t),-1,1)))}rotateTowards(t,e){const n=this.angleTo(t);if(n===0)return this;const i=Math.min(1,e/n);return this.slerp(t,i),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(t){return this._x*t._x+this._y*t._y+this._z*t._z+this._w*t._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let t=this.length();return t===0?(this._x=0,this._y=0,this._z=0,this._w=1):(t=1/t,this._x=this._x*t,this._y=this._y*t,this._z=this._z*t,this._w=this._w*t),this._onChangeCallback(),this}multiply(t){return this.multiplyQuaternions(this,t)}premultiply(t){return this.multiplyQuaternions(t,this)}multiplyQuaternions(t,e){const n=t._x,i=t._y,s=t._z,a=t._w,o=e._x,l=e._y,c=e._z,h=e._w;return this._x=n*h+a*o+i*c-s*l,this._y=i*h+a*l+s*o-n*c,this._z=s*h+a*c+n*l-i*o,this._w=a*h-n*o-i*l-s*c,this._onChangeCallback(),this}slerp(t,e){if(e===0)return this;if(e===1)return this.copy(t);const n=this._x,i=this._y,s=this._z,a=this._w;let o=a*t._w+n*t._x+i*t._y+s*t._z;if(o<0?(this._w=-t._w,this._x=-t._x,this._y=-t._y,this._z=-t._z,o=-o):this.copy(t),o>=1)return this._w=a,this._x=n,this._y=i,this._z=s,this;const l=1-o*o;if(l<=Number.EPSILON){const d=1-e;return this._w=d*a+e*this._w,this._x=d*n+e*this._x,this._y=d*i+e*this._y,this._z=d*s+e*this._z,this.normalize(),this}const c=Math.sqrt(l),h=Math.atan2(c,o),u=Math.sin((1-e)*h)/c,f=Math.sin(e*h)/c;return this._w=a*u+this._w*f,this._x=n*u+this._x*f,this._y=i*u+this._y*f,this._z=s*u+this._z*f,this._onChangeCallback(),this}slerpQuaternions(t,e,n){return this.copy(t).slerp(e,n)}random(){const t=2*Math.PI*Math.random(),e=2*Math.PI*Math.random(),n=Math.random(),i=Math.sqrt(1-n),s=Math.sqrt(n);return this.set(i*Math.sin(t),i*Math.cos(t),s*Math.sin(e),s*Math.cos(e))}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._w===this._w}fromArray(t,e=0){return this._x=t[e],this._y=t[e+1],this._z=t[e+2],this._w=t[e+3],this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._w,t}fromBufferAttribute(t,e){return this._x=t.getX(e),this._y=t.getY(e),this._z=t.getZ(e),this._w=t.getW(e),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}class D{constructor(t=0,e=0,n=0){D.prototype.isVector3=!0,this.x=t,this.y=e,this.z=n}set(t,e,n){return n===void 0&&(n=this.z),this.x=t,this.y=e,this.z=n,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this}multiplyVectors(t,e){return this.x=t.x*e.x,this.y=t.y*e.y,this.z=t.z*e.z,this}applyEuler(t){return this.applyQuaternion(Ro.setFromEuler(t))}applyAxisAngle(t,e){return this.applyQuaternion(Ro.setFromAxisAngle(t,e))}applyMatrix3(t){const e=this.x,n=this.y,i=this.z,s=t.elements;return this.x=s[0]*e+s[3]*n+s[6]*i,this.y=s[1]*e+s[4]*n+s[7]*i,this.z=s[2]*e+s[5]*n+s[8]*i,this}applyNormalMatrix(t){return this.applyMatrix3(t).normalize()}applyMatrix4(t){const e=this.x,n=this.y,i=this.z,s=t.elements,a=1/(s[3]*e+s[7]*n+s[11]*i+s[15]);return this.x=(s[0]*e+s[4]*n+s[8]*i+s[12])*a,this.y=(s[1]*e+s[5]*n+s[9]*i+s[13])*a,this.z=(s[2]*e+s[6]*n+s[10]*i+s[14])*a,this}applyQuaternion(t){const e=this.x,n=this.y,i=this.z,s=t.x,a=t.y,o=t.z,l=t.w,c=2*(a*i-o*n),h=2*(o*e-s*i),u=2*(s*n-a*e);return this.x=e+l*c+a*u-o*h,this.y=n+l*h+o*c-s*u,this.z=i+l*u+s*h-a*c,this}project(t){return this.applyMatrix4(t.matrixWorldInverse).applyMatrix4(t.projectionMatrix)}unproject(t){return this.applyMatrix4(t.projectionMatrixInverse).applyMatrix4(t.matrixWorld)}transformDirection(t){const e=this.x,n=this.y,i=this.z,s=t.elements;return this.x=s[0]*e+s[4]*n+s[8]*i,this.y=s[1]*e+s[5]*n+s[9]*i,this.z=s[2]*e+s[6]*n+s[10]*i,this.normalize()}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this}divideScalar(t){return this.multiplyScalar(1/t)}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this.z=Math.max(t.z,Math.min(e.z,this.z)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this.z=Math.max(t,Math.min(e,this.z)),this}clampLength(t,e){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this}cross(t){return this.crossVectors(this,t)}crossVectors(t,e){const n=t.x,i=t.y,s=t.z,a=e.x,o=e.y,l=e.z;return this.x=i*l-s*o,this.y=s*a-n*l,this.z=n*o-i*a,this}projectOnVector(t){const e=t.lengthSq();if(e===0)return this.set(0,0,0);const n=t.dot(this)/e;return this.copy(t).multiplyScalar(n)}projectOnPlane(t){return dr.copy(this).projectOnVector(t),this.sub(dr)}reflect(t){return this.sub(dr.copy(t).multiplyScalar(2*this.dot(t)))}angleTo(t){const e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;const n=this.dot(t)/e;return Math.acos(Te(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){const e=this.x-t.x,n=this.y-t.y,i=this.z-t.z;return e*e+n*n+i*i}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)+Math.abs(this.z-t.z)}setFromSpherical(t){return this.setFromSphericalCoords(t.radius,t.phi,t.theta)}setFromSphericalCoords(t,e,n){const i=Math.sin(e)*t;return this.x=i*Math.sin(n),this.y=Math.cos(e)*t,this.z=i*Math.cos(n),this}setFromCylindrical(t){return this.setFromCylindricalCoords(t.radius,t.theta,t.y)}setFromCylindricalCoords(t,e,n){return this.x=t*Math.sin(e),this.y=n,this.z=t*Math.cos(e),this}setFromMatrixPosition(t){const e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this}setFromMatrixScale(t){const e=this.setFromMatrixColumn(t,0).length(),n=this.setFromMatrixColumn(t,1).length(),i=this.setFromMatrixColumn(t,2).length();return this.x=e,this.y=n,this.z=i,this}setFromMatrixColumn(t,e){return this.fromArray(t.elements,e*4)}setFromMatrix3Column(t,e){return this.fromArray(t.elements,e*3)}setFromEuler(t){return this.x=t._x,this.y=t._y,this.z=t._z,this}setFromColor(t){return this.x=t.r,this.y=t.g,this.z=t.b,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const t=Math.random()*Math.PI*2,e=Math.random()*2-1,n=Math.sqrt(1-e*e);return this.x=n*Math.cos(t),this.y=e,this.z=n*Math.sin(t),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}}const dr=new D,Ro=new kn;class li{constructor(t=new D(1/0,1/0,1/0),e=new D(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=t,this.max=e}set(t,e){return this.min.copy(t),this.max.copy(e),this}setFromArray(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e+=3)this.expandByPoint(Ze.fromArray(t,e));return this}setFromBufferAttribute(t){this.makeEmpty();for(let e=0,n=t.count;e<n;e++)this.expandByPoint(Ze.fromBufferAttribute(t,e));return this}setFromPoints(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e++)this.expandByPoint(t[e]);return this}setFromCenterAndSize(t,e){const n=Ze.copy(e).multiplyScalar(.5);return this.min.copy(t).sub(n),this.max.copy(t).add(n),this}setFromObject(t,e=!1){return this.makeEmpty(),this.expandByObject(t,e)}clone(){return new this.constructor().copy(this)}copy(t){return this.min.copy(t.min),this.max.copy(t.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(t){return this.isEmpty()?t.set(0,0,0):t.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(t){return this.isEmpty()?t.set(0,0,0):t.subVectors(this.max,this.min)}expandByPoint(t){return this.min.min(t),this.max.max(t),this}expandByVector(t){return this.min.sub(t),this.max.add(t),this}expandByScalar(t){return this.min.addScalar(-t),this.max.addScalar(t),this}expandByObject(t,e=!1){t.updateWorldMatrix(!1,!1);const n=t.geometry;if(n!==void 0){const s=n.getAttribute("position");if(e===!0&&s!==void 0&&t.isInstancedMesh!==!0)for(let a=0,o=s.count;a<o;a++)t.isMesh===!0?t.getVertexPosition(a,Ze):Ze.fromBufferAttribute(s,a),Ze.applyMatrix4(t.matrixWorld),this.expandByPoint(Ze);else t.boundingBox!==void 0?(t.boundingBox===null&&t.computeBoundingBox(),ms.copy(t.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),ms.copy(n.boundingBox)),ms.applyMatrix4(t.matrixWorld),this.union(ms)}const i=t.children;for(let s=0,a=i.length;s<a;s++)this.expandByObject(i[s],e);return this}containsPoint(t){return t.x>=this.min.x&&t.x<=this.max.x&&t.y>=this.min.y&&t.y<=this.max.y&&t.z>=this.min.z&&t.z<=this.max.z}containsBox(t){return this.min.x<=t.min.x&&t.max.x<=this.max.x&&this.min.y<=t.min.y&&t.max.y<=this.max.y&&this.min.z<=t.min.z&&t.max.z<=this.max.z}getParameter(t,e){return e.set((t.x-this.min.x)/(this.max.x-this.min.x),(t.y-this.min.y)/(this.max.y-this.min.y),(t.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(t){return t.max.x>=this.min.x&&t.min.x<=this.max.x&&t.max.y>=this.min.y&&t.min.y<=this.max.y&&t.max.z>=this.min.z&&t.min.z<=this.max.z}intersectsSphere(t){return this.clampPoint(t.center,Ze),Ze.distanceToSquared(t.center)<=t.radius*t.radius}intersectsPlane(t){let e,n;return t.normal.x>0?(e=t.normal.x*this.min.x,n=t.normal.x*this.max.x):(e=t.normal.x*this.max.x,n=t.normal.x*this.min.x),t.normal.y>0?(e+=t.normal.y*this.min.y,n+=t.normal.y*this.max.y):(e+=t.normal.y*this.max.y,n+=t.normal.y*this.min.y),t.normal.z>0?(e+=t.normal.z*this.min.z,n+=t.normal.z*this.max.z):(e+=t.normal.z*this.max.z,n+=t.normal.z*this.min.z),e<=-t.constant&&n>=-t.constant}intersectsTriangle(t){if(this.isEmpty())return!1;this.getCenter(ji),gs.subVectors(this.max,ji),pi.subVectors(t.a,ji),mi.subVectors(t.b,ji),gi.subVectors(t.c,ji),Cn.subVectors(mi,pi),Pn.subVectors(gi,mi),Hn.subVectors(pi,gi);let e=[0,-Cn.z,Cn.y,0,-Pn.z,Pn.y,0,-Hn.z,Hn.y,Cn.z,0,-Cn.x,Pn.z,0,-Pn.x,Hn.z,0,-Hn.x,-Cn.y,Cn.x,0,-Pn.y,Pn.x,0,-Hn.y,Hn.x,0];return!pr(e,pi,mi,gi,gs)||(e=[1,0,0,0,1,0,0,0,1],!pr(e,pi,mi,gi,gs))?!1:(_s.crossVectors(Cn,Pn),e=[_s.x,_s.y,_s.z],pr(e,pi,mi,gi,gs))}clampPoint(t,e){return e.copy(t).clamp(this.min,this.max)}distanceToPoint(t){return this.clampPoint(t,Ze).distanceTo(t)}getBoundingSphere(t){return this.isEmpty()?t.makeEmpty():(this.getCenter(t.center),t.radius=this.getSize(Ze).length()*.5),t}intersect(t){return this.min.max(t.min),this.max.min(t.max),this.isEmpty()&&this.makeEmpty(),this}union(t){return this.min.min(t.min),this.max.max(t.max),this}applyMatrix4(t){return this.isEmpty()?this:(pn[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(t),pn[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(t),pn[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(t),pn[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(t),pn[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(t),pn[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(t),pn[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(t),pn[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(t),this.setFromPoints(pn),this)}translate(t){return this.min.add(t),this.max.add(t),this}equals(t){return t.min.equals(this.min)&&t.max.equals(this.max)}}const pn=[new D,new D,new D,new D,new D,new D,new D,new D],Ze=new D,ms=new li,pi=new D,mi=new D,gi=new D,Cn=new D,Pn=new D,Hn=new D,ji=new D,gs=new D,_s=new D,Vn=new D;function pr(r,t,e,n,i){for(let s=0,a=r.length-3;s<=a;s+=3){Vn.fromArray(r,s);const o=i.x*Math.abs(Vn.x)+i.y*Math.abs(Vn.y)+i.z*Math.abs(Vn.z),l=t.dot(Vn),c=e.dot(Vn),h=n.dot(Vn);if(Math.max(-Math.max(l,c,h),Math.min(l,c,h))>o)return!1}return!0}const Fh=new li,Ki=new D,mr=new D;class ci{constructor(t=new D,e=-1){this.isSphere=!0,this.center=t,this.radius=e}set(t,e){return this.center.copy(t),this.radius=e,this}setFromPoints(t,e){const n=this.center;e!==void 0?n.copy(e):Fh.setFromPoints(t).getCenter(n);let i=0;for(let s=0,a=t.length;s<a;s++)i=Math.max(i,n.distanceToSquared(t[s]));return this.radius=Math.sqrt(i),this}copy(t){return this.center.copy(t.center),this.radius=t.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(t){return t.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(t){return t.distanceTo(this.center)-this.radius}intersectsSphere(t){const e=this.radius+t.radius;return t.center.distanceToSquared(this.center)<=e*e}intersectsBox(t){return t.intersectsSphere(this)}intersectsPlane(t){return Math.abs(t.distanceToPoint(this.center))<=this.radius}clampPoint(t,e){const n=this.center.distanceToSquared(t);return e.copy(t),n>this.radius*this.radius&&(e.sub(this.center).normalize(),e.multiplyScalar(this.radius).add(this.center)),e}getBoundingBox(t){return this.isEmpty()?(t.makeEmpty(),t):(t.set(this.center,this.center),t.expandByScalar(this.radius),t)}applyMatrix4(t){return this.center.applyMatrix4(t),this.radius=this.radius*t.getMaxScaleOnAxis(),this}translate(t){return this.center.add(t),this}expandByPoint(t){if(this.isEmpty())return this.center.copy(t),this.radius=0,this;Ki.subVectors(t,this.center);const e=Ki.lengthSq();if(e>this.radius*this.radius){const n=Math.sqrt(e),i=(n-this.radius)*.5;this.center.addScaledVector(Ki,i/n),this.radius+=i}return this}union(t){return t.isEmpty()?this:this.isEmpty()?(this.copy(t),this):(this.center.equals(t.center)===!0?this.radius=Math.max(this.radius,t.radius):(mr.subVectors(t.center,this.center).setLength(t.radius),this.expandByPoint(Ki.copy(t.center).add(mr)),this.expandByPoint(Ki.copy(t.center).sub(mr))),this)}equals(t){return t.center.equals(this.center)&&t.radius===this.radius}clone(){return new this.constructor().copy(this)}}const mn=new D,gr=new D,xs=new D,Ln=new D,_r=new D,vs=new D,xr=new D;class ja{constructor(t=new D,e=new D(0,0,-1)){this.origin=t,this.direction=e}set(t,e){return this.origin.copy(t),this.direction.copy(e),this}copy(t){return this.origin.copy(t.origin),this.direction.copy(t.direction),this}at(t,e){return e.copy(this.origin).addScaledVector(this.direction,t)}lookAt(t){return this.direction.copy(t).sub(this.origin).normalize(),this}recast(t){return this.origin.copy(this.at(t,mn)),this}closestPointToPoint(t,e){e.subVectors(t,this.origin);const n=e.dot(this.direction);return n<0?e.copy(this.origin):e.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(t){return Math.sqrt(this.distanceSqToPoint(t))}distanceSqToPoint(t){const e=mn.subVectors(t,this.origin).dot(this.direction);return e<0?this.origin.distanceToSquared(t):(mn.copy(this.origin).addScaledVector(this.direction,e),mn.distanceToSquared(t))}distanceSqToSegment(t,e,n,i){gr.copy(t).add(e).multiplyScalar(.5),xs.copy(e).sub(t).normalize(),Ln.copy(this.origin).sub(gr);const s=t.distanceTo(e)*.5,a=-this.direction.dot(xs),o=Ln.dot(this.direction),l=-Ln.dot(xs),c=Ln.lengthSq(),h=Math.abs(1-a*a);let u,f,d,g;if(h>0)if(u=a*l-o,f=a*o-l,g=s*h,u>=0)if(f>=-g)if(f<=g){const _=1/h;u*=_,f*=_,d=u*(u+a*f+2*o)+f*(a*u+f+2*l)+c}else f=s,u=Math.max(0,-(a*f+o)),d=-u*u+f*(f+2*l)+c;else f=-s,u=Math.max(0,-(a*f+o)),d=-u*u+f*(f+2*l)+c;else f<=-g?(u=Math.max(0,-(-a*s+o)),f=u>0?-s:Math.min(Math.max(-s,-l),s),d=-u*u+f*(f+2*l)+c):f<=g?(u=0,f=Math.min(Math.max(-s,-l),s),d=f*(f+2*l)+c):(u=Math.max(0,-(a*s+o)),f=u>0?s:Math.min(Math.max(-s,-l),s),d=-u*u+f*(f+2*l)+c);else f=a>0?-s:s,u=Math.max(0,-(a*f+o)),d=-u*u+f*(f+2*l)+c;return n&&n.copy(this.origin).addScaledVector(this.direction,u),i&&i.copy(gr).addScaledVector(xs,f),d}intersectSphere(t,e){mn.subVectors(t.center,this.origin);const n=mn.dot(this.direction),i=mn.dot(mn)-n*n,s=t.radius*t.radius;if(i>s)return null;const a=Math.sqrt(s-i),o=n-a,l=n+a;return l<0?null:o<0?this.at(l,e):this.at(o,e)}intersectsSphere(t){return this.distanceSqToPoint(t.center)<=t.radius*t.radius}distanceToPlane(t){const e=t.normal.dot(this.direction);if(e===0)return t.distanceToPoint(this.origin)===0?0:null;const n=-(this.origin.dot(t.normal)+t.constant)/e;return n>=0?n:null}intersectPlane(t,e){const n=this.distanceToPlane(t);return n===null?null:this.at(n,e)}intersectsPlane(t){const e=t.distanceToPoint(this.origin);return e===0||t.normal.dot(this.direction)*e<0}intersectBox(t,e){let n,i,s,a,o,l;const c=1/this.direction.x,h=1/this.direction.y,u=1/this.direction.z,f=this.origin;return c>=0?(n=(t.min.x-f.x)*c,i=(t.max.x-f.x)*c):(n=(t.max.x-f.x)*c,i=(t.min.x-f.x)*c),h>=0?(s=(t.min.y-f.y)*h,a=(t.max.y-f.y)*h):(s=(t.max.y-f.y)*h,a=(t.min.y-f.y)*h),n>a||s>i||((s>n||isNaN(n))&&(n=s),(a<i||isNaN(i))&&(i=a),u>=0?(o=(t.min.z-f.z)*u,l=(t.max.z-f.z)*u):(o=(t.max.z-f.z)*u,l=(t.min.z-f.z)*u),n>l||o>i)||((o>n||n!==n)&&(n=o),(l<i||i!==i)&&(i=l),i<0)?null:this.at(n>=0?n:i,e)}intersectsBox(t){return this.intersectBox(t,mn)!==null}intersectTriangle(t,e,n,i,s){_r.subVectors(e,t),vs.subVectors(n,t),xr.crossVectors(_r,vs);let a=this.direction.dot(xr),o;if(a>0){if(i)return null;o=1}else if(a<0)o=-1,a=-a;else return null;Ln.subVectors(this.origin,t);const l=o*this.direction.dot(vs.crossVectors(Ln,vs));if(l<0)return null;const c=o*this.direction.dot(_r.cross(Ln));if(c<0||l+c>a)return null;const h=-o*Ln.dot(xr);return h<0?null:this.at(h/a,s)}applyMatrix4(t){return this.origin.applyMatrix4(t),this.direction.transformDirection(t),this}equals(t){return t.origin.equals(this.origin)&&t.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class Zt{constructor(t,e,n,i,s,a,o,l,c,h,u,f,d,g,_,m){Zt.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],t!==void 0&&this.set(t,e,n,i,s,a,o,l,c,h,u,f,d,g,_,m)}set(t,e,n,i,s,a,o,l,c,h,u,f,d,g,_,m){const p=this.elements;return p[0]=t,p[4]=e,p[8]=n,p[12]=i,p[1]=s,p[5]=a,p[9]=o,p[13]=l,p[2]=c,p[6]=h,p[10]=u,p[14]=f,p[3]=d,p[7]=g,p[11]=_,p[15]=m,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new Zt().fromArray(this.elements)}copy(t){const e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],e[9]=n[9],e[10]=n[10],e[11]=n[11],e[12]=n[12],e[13]=n[13],e[14]=n[14],e[15]=n[15],this}copyPosition(t){const e=this.elements,n=t.elements;return e[12]=n[12],e[13]=n[13],e[14]=n[14],this}setFromMatrix3(t){const e=t.elements;return this.set(e[0],e[3],e[6],0,e[1],e[4],e[7],0,e[2],e[5],e[8],0,0,0,0,1),this}extractBasis(t,e,n){return t.setFromMatrixColumn(this,0),e.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this}makeBasis(t,e,n){return this.set(t.x,e.x,n.x,0,t.y,e.y,n.y,0,t.z,e.z,n.z,0,0,0,0,1),this}extractRotation(t){const e=this.elements,n=t.elements,i=1/_i.setFromMatrixColumn(t,0).length(),s=1/_i.setFromMatrixColumn(t,1).length(),a=1/_i.setFromMatrixColumn(t,2).length();return e[0]=n[0]*i,e[1]=n[1]*i,e[2]=n[2]*i,e[3]=0,e[4]=n[4]*s,e[5]=n[5]*s,e[6]=n[6]*s,e[7]=0,e[8]=n[8]*a,e[9]=n[9]*a,e[10]=n[10]*a,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromEuler(t){const e=this.elements,n=t.x,i=t.y,s=t.z,a=Math.cos(n),o=Math.sin(n),l=Math.cos(i),c=Math.sin(i),h=Math.cos(s),u=Math.sin(s);if(t.order==="XYZ"){const f=a*h,d=a*u,g=o*h,_=o*u;e[0]=l*h,e[4]=-l*u,e[8]=c,e[1]=d+g*c,e[5]=f-_*c,e[9]=-o*l,e[2]=_-f*c,e[6]=g+d*c,e[10]=a*l}else if(t.order==="YXZ"){const f=l*h,d=l*u,g=c*h,_=c*u;e[0]=f+_*o,e[4]=g*o-d,e[8]=a*c,e[1]=a*u,e[5]=a*h,e[9]=-o,e[2]=d*o-g,e[6]=_+f*o,e[10]=a*l}else if(t.order==="ZXY"){const f=l*h,d=l*u,g=c*h,_=c*u;e[0]=f-_*o,e[4]=-a*u,e[8]=g+d*o,e[1]=d+g*o,e[5]=a*h,e[9]=_-f*o,e[2]=-a*c,e[6]=o,e[10]=a*l}else if(t.order==="ZYX"){const f=a*h,d=a*u,g=o*h,_=o*u;e[0]=l*h,e[4]=g*c-d,e[8]=f*c+_,e[1]=l*u,e[5]=_*c+f,e[9]=d*c-g,e[2]=-c,e[6]=o*l,e[10]=a*l}else if(t.order==="YZX"){const f=a*l,d=a*c,g=o*l,_=o*c;e[0]=l*h,e[4]=_-f*u,e[8]=g*u+d,e[1]=u,e[5]=a*h,e[9]=-o*h,e[2]=-c*h,e[6]=d*u+g,e[10]=f-_*u}else if(t.order==="XZY"){const f=a*l,d=a*c,g=o*l,_=o*c;e[0]=l*h,e[4]=-u,e[8]=c*h,e[1]=f*u+_,e[5]=a*h,e[9]=d*u-g,e[2]=g*u-d,e[6]=o*h,e[10]=_*u+f}return e[3]=0,e[7]=0,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromQuaternion(t){return this.compose(Oh,t,zh)}lookAt(t,e,n){const i=this.elements;return Be.subVectors(t,e),Be.lengthSq()===0&&(Be.z=1),Be.normalize(),Dn.crossVectors(n,Be),Dn.lengthSq()===0&&(Math.abs(n.z)===1?Be.x+=1e-4:Be.z+=1e-4,Be.normalize(),Dn.crossVectors(n,Be)),Dn.normalize(),Ms.crossVectors(Be,Dn),i[0]=Dn.x,i[4]=Ms.x,i[8]=Be.x,i[1]=Dn.y,i[5]=Ms.y,i[9]=Be.y,i[2]=Dn.z,i[6]=Ms.z,i[10]=Be.z,this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){const n=t.elements,i=e.elements,s=this.elements,a=n[0],o=n[4],l=n[8],c=n[12],h=n[1],u=n[5],f=n[9],d=n[13],g=n[2],_=n[6],m=n[10],p=n[14],x=n[3],y=n[7],v=n[11],R=n[15],T=i[0],E=i[4],P=i[8],b=i[12],M=i[1],C=i[5],U=i[9],O=i[13],V=i[2],X=i[6],W=i[10],j=i[14],k=i[3],it=i[7],q=i[11],tt=i[15];return s[0]=a*T+o*M+l*V+c*k,s[4]=a*E+o*C+l*X+c*it,s[8]=a*P+o*U+l*W+c*q,s[12]=a*b+o*O+l*j+c*tt,s[1]=h*T+u*M+f*V+d*k,s[5]=h*E+u*C+f*X+d*it,s[9]=h*P+u*U+f*W+d*q,s[13]=h*b+u*O+f*j+d*tt,s[2]=g*T+_*M+m*V+p*k,s[6]=g*E+_*C+m*X+p*it,s[10]=g*P+_*U+m*W+p*q,s[14]=g*b+_*O+m*j+p*tt,s[3]=x*T+y*M+v*V+R*k,s[7]=x*E+y*C+v*X+R*it,s[11]=x*P+y*U+v*W+R*q,s[15]=x*b+y*O+v*j+R*tt,this}multiplyScalar(t){const e=this.elements;return e[0]*=t,e[4]*=t,e[8]*=t,e[12]*=t,e[1]*=t,e[5]*=t,e[9]*=t,e[13]*=t,e[2]*=t,e[6]*=t,e[10]*=t,e[14]*=t,e[3]*=t,e[7]*=t,e[11]*=t,e[15]*=t,this}determinant(){const t=this.elements,e=t[0],n=t[4],i=t[8],s=t[12],a=t[1],o=t[5],l=t[9],c=t[13],h=t[2],u=t[6],f=t[10],d=t[14],g=t[3],_=t[7],m=t[11],p=t[15];return g*(+s*l*u-i*c*u-s*o*f+n*c*f+i*o*d-n*l*d)+_*(+e*l*d-e*c*f+s*a*f-i*a*d+i*c*h-s*l*h)+m*(+e*c*u-e*o*d-s*a*u+n*a*d+s*o*h-n*c*h)+p*(-i*o*h-e*l*u+e*o*f+i*a*u-n*a*f+n*l*h)}transpose(){const t=this.elements;let e;return e=t[1],t[1]=t[4],t[4]=e,e=t[2],t[2]=t[8],t[8]=e,e=t[6],t[6]=t[9],t[9]=e,e=t[3],t[3]=t[12],t[12]=e,e=t[7],t[7]=t[13],t[13]=e,e=t[11],t[11]=t[14],t[14]=e,this}setPosition(t,e,n){const i=this.elements;return t.isVector3?(i[12]=t.x,i[13]=t.y,i[14]=t.z):(i[12]=t,i[13]=e,i[14]=n),this}invert(){const t=this.elements,e=t[0],n=t[1],i=t[2],s=t[3],a=t[4],o=t[5],l=t[6],c=t[7],h=t[8],u=t[9],f=t[10],d=t[11],g=t[12],_=t[13],m=t[14],p=t[15],x=u*m*c-_*f*c+_*l*d-o*m*d-u*l*p+o*f*p,y=g*f*c-h*m*c-g*l*d+a*m*d+h*l*p-a*f*p,v=h*_*c-g*u*c+g*o*d-a*_*d-h*o*p+a*u*p,R=g*u*l-h*_*l-g*o*f+a*_*f+h*o*m-a*u*m,T=e*x+n*y+i*v+s*R;if(T===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const E=1/T;return t[0]=x*E,t[1]=(_*f*s-u*m*s-_*i*d+n*m*d+u*i*p-n*f*p)*E,t[2]=(o*m*s-_*l*s+_*i*c-n*m*c-o*i*p+n*l*p)*E,t[3]=(u*l*s-o*f*s-u*i*c+n*f*c+o*i*d-n*l*d)*E,t[4]=y*E,t[5]=(h*m*s-g*f*s+g*i*d-e*m*d-h*i*p+e*f*p)*E,t[6]=(g*l*s-a*m*s-g*i*c+e*m*c+a*i*p-e*l*p)*E,t[7]=(a*f*s-h*l*s+h*i*c-e*f*c-a*i*d+e*l*d)*E,t[8]=v*E,t[9]=(g*u*s-h*_*s-g*n*d+e*_*d+h*n*p-e*u*p)*E,t[10]=(a*_*s-g*o*s+g*n*c-e*_*c-a*n*p+e*o*p)*E,t[11]=(h*o*s-a*u*s-h*n*c+e*u*c+a*n*d-e*o*d)*E,t[12]=R*E,t[13]=(h*_*i-g*u*i+g*n*f-e*_*f-h*n*m+e*u*m)*E,t[14]=(g*o*i-a*_*i-g*n*l+e*_*l+a*n*m-e*o*m)*E,t[15]=(a*u*i-h*o*i+h*n*l-e*u*l-a*n*f+e*o*f)*E,this}scale(t){const e=this.elements,n=t.x,i=t.y,s=t.z;return e[0]*=n,e[4]*=i,e[8]*=s,e[1]*=n,e[5]*=i,e[9]*=s,e[2]*=n,e[6]*=i,e[10]*=s,e[3]*=n,e[7]*=i,e[11]*=s,this}getMaxScaleOnAxis(){const t=this.elements,e=t[0]*t[0]+t[1]*t[1]+t[2]*t[2],n=t[4]*t[4]+t[5]*t[5]+t[6]*t[6],i=t[8]*t[8]+t[9]*t[9]+t[10]*t[10];return Math.sqrt(Math.max(e,n,i))}makeTranslation(t,e,n){return t.isVector3?this.set(1,0,0,t.x,0,1,0,t.y,0,0,1,t.z,0,0,0,1):this.set(1,0,0,t,0,1,0,e,0,0,1,n,0,0,0,1),this}makeRotationX(t){const e=Math.cos(t),n=Math.sin(t);return this.set(1,0,0,0,0,e,-n,0,0,n,e,0,0,0,0,1),this}makeRotationY(t){const e=Math.cos(t),n=Math.sin(t);return this.set(e,0,n,0,0,1,0,0,-n,0,e,0,0,0,0,1),this}makeRotationZ(t){const e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,0,n,e,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(t,e){const n=Math.cos(e),i=Math.sin(e),s=1-n,a=t.x,o=t.y,l=t.z,c=s*a,h=s*o;return this.set(c*a+n,c*o-i*l,c*l+i*o,0,c*o+i*l,h*o+n,h*l-i*a,0,c*l-i*o,h*l+i*a,s*l*l+n,0,0,0,0,1),this}makeScale(t,e,n){return this.set(t,0,0,0,0,e,0,0,0,0,n,0,0,0,0,1),this}makeShear(t,e,n,i,s,a){return this.set(1,n,s,0,t,1,a,0,e,i,1,0,0,0,0,1),this}compose(t,e,n){const i=this.elements,s=e._x,a=e._y,o=e._z,l=e._w,c=s+s,h=a+a,u=o+o,f=s*c,d=s*h,g=s*u,_=a*h,m=a*u,p=o*u,x=l*c,y=l*h,v=l*u,R=n.x,T=n.y,E=n.z;return i[0]=(1-(_+p))*R,i[1]=(d+v)*R,i[2]=(g-y)*R,i[3]=0,i[4]=(d-v)*T,i[5]=(1-(f+p))*T,i[6]=(m+x)*T,i[7]=0,i[8]=(g+y)*E,i[9]=(m-x)*E,i[10]=(1-(f+_))*E,i[11]=0,i[12]=t.x,i[13]=t.y,i[14]=t.z,i[15]=1,this}decompose(t,e,n){const i=this.elements;let s=_i.set(i[0],i[1],i[2]).length();const a=_i.set(i[4],i[5],i[6]).length(),o=_i.set(i[8],i[9],i[10]).length();this.determinant()<0&&(s=-s),t.x=i[12],t.y=i[13],t.z=i[14],Je.copy(this);const c=1/s,h=1/a,u=1/o;return Je.elements[0]*=c,Je.elements[1]*=c,Je.elements[2]*=c,Je.elements[4]*=h,Je.elements[5]*=h,Je.elements[6]*=h,Je.elements[8]*=u,Je.elements[9]*=u,Je.elements[10]*=u,e.setFromRotationMatrix(Je),n.x=s,n.y=a,n.z=o,this}makePerspective(t,e,n,i,s,a,o=yn){const l=this.elements,c=2*s/(e-t),h=2*s/(n-i),u=(e+t)/(e-t),f=(n+i)/(n-i);let d,g;if(o===yn)d=-(a+s)/(a-s),g=-2*a*s/(a-s);else if(o===Js)d=-a/(a-s),g=-a*s/(a-s);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+o);return l[0]=c,l[4]=0,l[8]=u,l[12]=0,l[1]=0,l[5]=h,l[9]=f,l[13]=0,l[2]=0,l[6]=0,l[10]=d,l[14]=g,l[3]=0,l[7]=0,l[11]=-1,l[15]=0,this}makeOrthographic(t,e,n,i,s,a,o=yn){const l=this.elements,c=1/(e-t),h=1/(n-i),u=1/(a-s),f=(e+t)*c,d=(n+i)*h;let g,_;if(o===yn)g=(a+s)*u,_=-2*u;else if(o===Js)g=s*u,_=-1*u;else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+o);return l[0]=2*c,l[4]=0,l[8]=0,l[12]=-f,l[1]=0,l[5]=2*h,l[9]=0,l[13]=-d,l[2]=0,l[6]=0,l[10]=_,l[14]=-g,l[3]=0,l[7]=0,l[11]=0,l[15]=1,this}equals(t){const e=this.elements,n=t.elements;for(let i=0;i<16;i++)if(e[i]!==n[i])return!1;return!0}fromArray(t,e=0){for(let n=0;n<16;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){const n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t[e+9]=n[9],t[e+10]=n[10],t[e+11]=n[11],t[e+12]=n[12],t[e+13]=n[13],t[e+14]=n[14],t[e+15]=n[15],t}}const _i=new D,Je=new Zt,Oh=new D(0,0,0),zh=new D(1,1,1),Dn=new D,Ms=new D,Be=new D,Co=new Zt,Po=new kn;class rn{constructor(t=0,e=0,n=0,i=rn.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=e,this._z=n,this._order=i}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get order(){return this._order}set order(t){this._order=t,this._onChangeCallback()}set(t,e,n,i=this._order){return this._x=t,this._y=e,this._z=n,this._order=i,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(t){return this._x=t._x,this._y=t._y,this._z=t._z,this._order=t._order,this._onChangeCallback(),this}setFromRotationMatrix(t,e=this._order,n=!0){const i=t.elements,s=i[0],a=i[4],o=i[8],l=i[1],c=i[5],h=i[9],u=i[2],f=i[6],d=i[10];switch(e){case"XYZ":this._y=Math.asin(Te(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-h,d),this._z=Math.atan2(-a,s)):(this._x=Math.atan2(f,c),this._z=0);break;case"YXZ":this._x=Math.asin(-Te(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(o,d),this._z=Math.atan2(l,c)):(this._y=Math.atan2(-u,s),this._z=0);break;case"ZXY":this._x=Math.asin(Te(f,-1,1)),Math.abs(f)<.9999999?(this._y=Math.atan2(-u,d),this._z=Math.atan2(-a,c)):(this._y=0,this._z=Math.atan2(l,s));break;case"ZYX":this._y=Math.asin(-Te(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(f,d),this._z=Math.atan2(l,s)):(this._x=0,this._z=Math.atan2(-a,c));break;case"YZX":this._z=Math.asin(Te(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-h,c),this._y=Math.atan2(-u,s)):(this._x=0,this._y=Math.atan2(o,d));break;case"XZY":this._z=Math.asin(-Te(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(f,c),this._y=Math.atan2(o,s)):(this._x=Math.atan2(-h,d),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+e)}return this._order=e,n===!0&&this._onChangeCallback(),this}setFromQuaternion(t,e,n){return Co.makeRotationFromQuaternion(t),this.setFromRotationMatrix(Co,e,n)}setFromVector3(t,e=this._order){return this.set(t.x,t.y,t.z,e)}reorder(t){return Po.setFromEuler(this),this.setFromQuaternion(Po,t)}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._order===this._order}fromArray(t){return this._x=t[0],this._y=t[1],this._z=t[2],t[3]!==void 0&&(this._order=t[3]),this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._order,t}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}rn.DEFAULT_ORDER="XYZ";class ac{constructor(){this.mask=1}set(t){this.mask=(1<<t|0)>>>0}enable(t){this.mask|=1<<t|0}enableAll(){this.mask=-1}toggle(t){this.mask^=1<<t|0}disable(t){this.mask&=~(1<<t|0)}disableAll(){this.mask=0}test(t){return(this.mask&t.mask)!==0}isEnabled(t){return(this.mask&(1<<t|0))!==0}}let kh=0;const Lo=new D,xi=new kn,gn=new Zt,ys=new D,Zi=new D,Bh=new D,Gh=new kn,Do=new D(1,0,0),Io=new D(0,1,0),Uo=new D(0,0,1),No={type:"added"},Hh={type:"removed"},vi={type:"childadded",child:null},vr={type:"childremoved",child:null};class fe extends Vi{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:kh++}),this.uuid=Wi(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=fe.DEFAULT_UP.clone();const t=new D,e=new rn,n=new kn,i=new D(1,1,1);function s(){n.setFromEuler(e,!1)}function a(){e.setFromQuaternion(n,void 0,!1)}e._onChange(s),n._onChange(a),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:e},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:i},modelViewMatrix:{value:new Zt},normalMatrix:{value:new Xt}}),this.matrix=new Zt,this.matrixWorld=new Zt,this.matrixAutoUpdate=fe.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=fe.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new ac,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(t){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(t),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(t){return this.quaternion.premultiply(t),this}setRotationFromAxisAngle(t,e){this.quaternion.setFromAxisAngle(t,e)}setRotationFromEuler(t){this.quaternion.setFromEuler(t,!0)}setRotationFromMatrix(t){this.quaternion.setFromRotationMatrix(t)}setRotationFromQuaternion(t){this.quaternion.copy(t)}rotateOnAxis(t,e){return xi.setFromAxisAngle(t,e),this.quaternion.multiply(xi),this}rotateOnWorldAxis(t,e){return xi.setFromAxisAngle(t,e),this.quaternion.premultiply(xi),this}rotateX(t){return this.rotateOnAxis(Do,t)}rotateY(t){return this.rotateOnAxis(Io,t)}rotateZ(t){return this.rotateOnAxis(Uo,t)}translateOnAxis(t,e){return Lo.copy(t).applyQuaternion(this.quaternion),this.position.add(Lo.multiplyScalar(e)),this}translateX(t){return this.translateOnAxis(Do,t)}translateY(t){return this.translateOnAxis(Io,t)}translateZ(t){return this.translateOnAxis(Uo,t)}localToWorld(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(this.matrixWorld)}worldToLocal(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(gn.copy(this.matrixWorld).invert())}lookAt(t,e,n){t.isVector3?ys.copy(t):ys.set(t,e,n);const i=this.parent;this.updateWorldMatrix(!0,!1),Zi.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?gn.lookAt(Zi,ys,this.up):gn.lookAt(ys,Zi,this.up),this.quaternion.setFromRotationMatrix(gn),i&&(gn.extractRotation(i.matrixWorld),xi.setFromRotationMatrix(gn),this.quaternion.premultiply(xi.invert()))}add(t){if(arguments.length>1){for(let e=0;e<arguments.length;e++)this.add(arguments[e]);return this}return t===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",t),this):(t&&t.isObject3D?(t.removeFromParent(),t.parent=this,this.children.push(t),t.dispatchEvent(No),vi.child=t,this.dispatchEvent(vi),vi.child=null):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",t),this)}remove(t){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}const e=this.children.indexOf(t);return e!==-1&&(t.parent=null,this.children.splice(e,1),t.dispatchEvent(Hh),vr.child=t,this.dispatchEvent(vr),vr.child=null),this}removeFromParent(){const t=this.parent;return t!==null&&t.remove(this),this}clear(){return this.remove(...this.children)}attach(t){return this.updateWorldMatrix(!0,!1),gn.copy(this.matrixWorld).invert(),t.parent!==null&&(t.parent.updateWorldMatrix(!0,!1),gn.multiply(t.parent.matrixWorld)),t.applyMatrix4(gn),t.removeFromParent(),t.parent=this,this.children.push(t),t.updateWorldMatrix(!1,!0),t.dispatchEvent(No),vi.child=t,this.dispatchEvent(vi),vi.child=null,this}getObjectById(t){return this.getObjectByProperty("id",t)}getObjectByName(t){return this.getObjectByProperty("name",t)}getObjectByProperty(t,e){if(this[t]===e)return this;for(let n=0,i=this.children.length;n<i;n++){const a=this.children[n].getObjectByProperty(t,e);if(a!==void 0)return a}}getObjectsByProperty(t,e,n=[]){this[t]===e&&n.push(this);const i=this.children;for(let s=0,a=i.length;s<a;s++)i[s].getObjectsByProperty(t,e,n);return n}getWorldPosition(t){return this.updateWorldMatrix(!0,!1),t.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Zi,t,Bh),t}getWorldScale(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Zi,Gh,t),t}getWorldDirection(t){this.updateWorldMatrix(!0,!1);const e=this.matrixWorld.elements;return t.set(e[8],e[9],e[10]).normalize()}raycast(){}traverse(t){t(this);const e=this.children;for(let n=0,i=e.length;n<i;n++)e[n].traverse(t)}traverseVisible(t){if(this.visible===!1)return;t(this);const e=this.children;for(let n=0,i=e.length;n<i;n++)e[n].traverseVisible(t)}traverseAncestors(t){const e=this.parent;e!==null&&(t(e),e.traverseAncestors(t))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(t){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||t)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,t=!0);const e=this.children;for(let n=0,i=e.length;n<i;n++)e[n].updateMatrixWorld(t)}updateWorldMatrix(t,e){const n=this.parent;if(t===!0&&n!==null&&n.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),e===!0){const i=this.children;for(let s=0,a=i.length;s<a;s++)i[s].updateWorldMatrix(!1,!0)}}toJSON(t){const e=t===void 0||typeof t=="string",n={};e&&(t={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.6,type:"Object",generator:"Object3D.toJSON"});const i={};i.uuid=this.uuid,i.type=this.type,this.name!==""&&(i.name=this.name),this.castShadow===!0&&(i.castShadow=!0),this.receiveShadow===!0&&(i.receiveShadow=!0),this.visible===!1&&(i.visible=!1),this.frustumCulled===!1&&(i.frustumCulled=!1),this.renderOrder!==0&&(i.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(i.userData=this.userData),i.layers=this.layers.mask,i.matrix=this.matrix.toArray(),i.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(i.matrixAutoUpdate=!1),this.isInstancedMesh&&(i.type="InstancedMesh",i.count=this.count,i.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(i.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(i.type="BatchedMesh",i.perObjectFrustumCulled=this.perObjectFrustumCulled,i.sortObjects=this.sortObjects,i.drawRanges=this._drawRanges,i.reservedRanges=this._reservedRanges,i.visibility=this._visibility,i.active=this._active,i.bounds=this._bounds.map(o=>({boxInitialized:o.boxInitialized,boxMin:o.box.min.toArray(),boxMax:o.box.max.toArray(),sphereInitialized:o.sphereInitialized,sphereRadius:o.sphere.radius,sphereCenter:o.sphere.center.toArray()})),i.maxInstanceCount=this._maxInstanceCount,i.maxVertexCount=this._maxVertexCount,i.maxIndexCount=this._maxIndexCount,i.geometryInitialized=this._geometryInitialized,i.geometryCount=this._geometryCount,i.matricesTexture=this._matricesTexture.toJSON(t),this._colorsTexture!==null&&(i.colorsTexture=this._colorsTexture.toJSON(t)),this.boundingSphere!==null&&(i.boundingSphere={center:i.boundingSphere.center.toArray(),radius:i.boundingSphere.radius}),this.boundingBox!==null&&(i.boundingBox={min:i.boundingBox.min.toArray(),max:i.boundingBox.max.toArray()}));function s(o,l){return o[l.uuid]===void 0&&(o[l.uuid]=l.toJSON(t)),l.uuid}if(this.isScene)this.background&&(this.background.isColor?i.background=this.background.toJSON():this.background.isTexture&&(i.background=this.background.toJSON(t).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(i.environment=this.environment.toJSON(t).uuid);else if(this.isMesh||this.isLine||this.isPoints){i.geometry=s(t.geometries,this.geometry);const o=this.geometry.parameters;if(o!==void 0&&o.shapes!==void 0){const l=o.shapes;if(Array.isArray(l))for(let c=0,h=l.length;c<h;c++){const u=l[c];s(t.shapes,u)}else s(t.shapes,l)}}if(this.isSkinnedMesh&&(i.bindMode=this.bindMode,i.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(s(t.skeletons,this.skeleton),i.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const o=[];for(let l=0,c=this.material.length;l<c;l++)o.push(s(t.materials,this.material[l]));i.material=o}else i.material=s(t.materials,this.material);if(this.children.length>0){i.children=[];for(let o=0;o<this.children.length;o++)i.children.push(this.children[o].toJSON(t).object)}if(this.animations.length>0){i.animations=[];for(let o=0;o<this.animations.length;o++){const l=this.animations[o];i.animations.push(s(t.animations,l))}}if(e){const o=a(t.geometries),l=a(t.materials),c=a(t.textures),h=a(t.images),u=a(t.shapes),f=a(t.skeletons),d=a(t.animations),g=a(t.nodes);o.length>0&&(n.geometries=o),l.length>0&&(n.materials=l),c.length>0&&(n.textures=c),h.length>0&&(n.images=h),u.length>0&&(n.shapes=u),f.length>0&&(n.skeletons=f),d.length>0&&(n.animations=d),g.length>0&&(n.nodes=g)}return n.object=i,n;function a(o){const l=[];for(const c in o){const h=o[c];delete h.metadata,l.push(h)}return l}}clone(t){return new this.constructor().copy(this,t)}copy(t,e=!0){if(this.name=t.name,this.up.copy(t.up),this.position.copy(t.position),this.rotation.order=t.rotation.order,this.quaternion.copy(t.quaternion),this.scale.copy(t.scale),this.matrix.copy(t.matrix),this.matrixWorld.copy(t.matrixWorld),this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrixWorldAutoUpdate=t.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=t.matrixWorldNeedsUpdate,this.layers.mask=t.layers.mask,this.visible=t.visible,this.castShadow=t.castShadow,this.receiveShadow=t.receiveShadow,this.frustumCulled=t.frustumCulled,this.renderOrder=t.renderOrder,this.animations=t.animations.slice(),this.userData=JSON.parse(JSON.stringify(t.userData)),e===!0)for(let n=0;n<t.children.length;n++){const i=t.children[n];this.add(i.clone())}return this}}fe.DEFAULT_UP=new D(0,1,0);fe.DEFAULT_MATRIX_AUTO_UPDATE=!0;fe.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;const Qe=new D,_n=new D,Mr=new D,xn=new D,Mi=new D,yi=new D,Fo=new D,yr=new D,Sr=new D,br=new D,wr=new ge,Tr=new ge,Er=new ge;class en{constructor(t=new D,e=new D,n=new D){this.a=t,this.b=e,this.c=n}static getNormal(t,e,n,i){i.subVectors(n,e),Qe.subVectors(t,e),i.cross(Qe);const s=i.lengthSq();return s>0?i.multiplyScalar(1/Math.sqrt(s)):i.set(0,0,0)}static getBarycoord(t,e,n,i,s){Qe.subVectors(i,e),_n.subVectors(n,e),Mr.subVectors(t,e);const a=Qe.dot(Qe),o=Qe.dot(_n),l=Qe.dot(Mr),c=_n.dot(_n),h=_n.dot(Mr),u=a*c-o*o;if(u===0)return s.set(0,0,0),null;const f=1/u,d=(c*l-o*h)*f,g=(a*h-o*l)*f;return s.set(1-d-g,g,d)}static containsPoint(t,e,n,i){return this.getBarycoord(t,e,n,i,xn)===null?!1:xn.x>=0&&xn.y>=0&&xn.x+xn.y<=1}static getInterpolation(t,e,n,i,s,a,o,l){return this.getBarycoord(t,e,n,i,xn)===null?(l.x=0,l.y=0,"z"in l&&(l.z=0),"w"in l&&(l.w=0),null):(l.setScalar(0),l.addScaledVector(s,xn.x),l.addScaledVector(a,xn.y),l.addScaledVector(o,xn.z),l)}static getInterpolatedAttribute(t,e,n,i,s,a){return wr.setScalar(0),Tr.setScalar(0),Er.setScalar(0),wr.fromBufferAttribute(t,e),Tr.fromBufferAttribute(t,n),Er.fromBufferAttribute(t,i),a.setScalar(0),a.addScaledVector(wr,s.x),a.addScaledVector(Tr,s.y),a.addScaledVector(Er,s.z),a}static isFrontFacing(t,e,n,i){return Qe.subVectors(n,e),_n.subVectors(t,e),Qe.cross(_n).dot(i)<0}set(t,e,n){return this.a.copy(t),this.b.copy(e),this.c.copy(n),this}setFromPointsAndIndices(t,e,n,i){return this.a.copy(t[e]),this.b.copy(t[n]),this.c.copy(t[i]),this}setFromAttributeAndIndices(t,e,n,i){return this.a.fromBufferAttribute(t,e),this.b.fromBufferAttribute(t,n),this.c.fromBufferAttribute(t,i),this}clone(){return new this.constructor().copy(this)}copy(t){return this.a.copy(t.a),this.b.copy(t.b),this.c.copy(t.c),this}getArea(){return Qe.subVectors(this.c,this.b),_n.subVectors(this.a,this.b),Qe.cross(_n).length()*.5}getMidpoint(t){return t.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(t){return en.getNormal(this.a,this.b,this.c,t)}getPlane(t){return t.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(t,e){return en.getBarycoord(t,this.a,this.b,this.c,e)}getInterpolation(t,e,n,i,s){return en.getInterpolation(t,this.a,this.b,this.c,e,n,i,s)}containsPoint(t){return en.containsPoint(t,this.a,this.b,this.c)}isFrontFacing(t){return en.isFrontFacing(this.a,this.b,this.c,t)}intersectsBox(t){return t.intersectsTriangle(this)}closestPointToPoint(t,e){const n=this.a,i=this.b,s=this.c;let a,o;Mi.subVectors(i,n),yi.subVectors(s,n),yr.subVectors(t,n);const l=Mi.dot(yr),c=yi.dot(yr);if(l<=0&&c<=0)return e.copy(n);Sr.subVectors(t,i);const h=Mi.dot(Sr),u=yi.dot(Sr);if(h>=0&&u<=h)return e.copy(i);const f=l*u-h*c;if(f<=0&&l>=0&&h<=0)return a=l/(l-h),e.copy(n).addScaledVector(Mi,a);br.subVectors(t,s);const d=Mi.dot(br),g=yi.dot(br);if(g>=0&&d<=g)return e.copy(s);const _=d*c-l*g;if(_<=0&&c>=0&&g<=0)return o=c/(c-g),e.copy(n).addScaledVector(yi,o);const m=h*g-d*u;if(m<=0&&u-h>=0&&d-g>=0)return Fo.subVectors(s,i),o=(u-h)/(u-h+(d-g)),e.copy(i).addScaledVector(Fo,o);const p=1/(m+_+f);return a=_*p,o=f*p,e.copy(n).addScaledVector(Mi,a).addScaledVector(yi,o)}equals(t){return t.a.equals(this.a)&&t.b.equals(this.b)&&t.c.equals(this.c)}}const oc={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},In={h:0,s:0,l:0},Ss={h:0,s:0,l:0};function Ar(r,t,e){return e<0&&(e+=1),e>1&&(e-=1),e<1/6?r+(t-r)*6*e:e<1/2?t:e<2/3?r+(t-r)*6*(2/3-e):r}class Pt{constructor(t,e,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(t,e,n)}set(t,e,n){if(e===void 0&&n===void 0){const i=t;i&&i.isColor?this.copy(i):typeof i=="number"?this.setHex(i):typeof i=="string"&&this.setStyle(i)}else this.setRGB(t,e,n);return this}setScalar(t){return this.r=t,this.g=t,this.b=t,this}setHex(t,e=Ue){return t=Math.floor(t),this.r=(t>>16&255)/255,this.g=(t>>8&255)/255,this.b=(t&255)/255,jt.toWorkingColorSpace(this,e),this}setRGB(t,e,n,i=jt.workingColorSpace){return this.r=t,this.g=e,this.b=n,jt.toWorkingColorSpace(this,i),this}setHSL(t,e,n,i=jt.workingColorSpace){if(t=Ya(t,1),e=Te(e,0,1),n=Te(n,0,1),e===0)this.r=this.g=this.b=n;else{const s=n<=.5?n*(1+e):n+e-n*e,a=2*n-s;this.r=Ar(a,s,t+1/3),this.g=Ar(a,s,t),this.b=Ar(a,s,t-1/3)}return jt.toWorkingColorSpace(this,i),this}setStyle(t,e=Ue){function n(s){s!==void 0&&parseFloat(s)<1&&console.warn("THREE.Color: Alpha component of "+t+" will be ignored.")}let i;if(i=/^(\w+)\(([^\)]*)\)/.exec(t)){let s;const a=i[1],o=i[2];switch(a){case"rgb":case"rgba":if(s=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(s[4]),this.setRGB(Math.min(255,parseInt(s[1],10))/255,Math.min(255,parseInt(s[2],10))/255,Math.min(255,parseInt(s[3],10))/255,e);if(s=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(s[4]),this.setRGB(Math.min(100,parseInt(s[1],10))/100,Math.min(100,parseInt(s[2],10))/100,Math.min(100,parseInt(s[3],10))/100,e);break;case"hsl":case"hsla":if(s=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(s[4]),this.setHSL(parseFloat(s[1])/360,parseFloat(s[2])/100,parseFloat(s[3])/100,e);break;default:console.warn("THREE.Color: Unknown color model "+t)}}else if(i=/^\#([A-Fa-f\d]+)$/.exec(t)){const s=i[1],a=s.length;if(a===3)return this.setRGB(parseInt(s.charAt(0),16)/15,parseInt(s.charAt(1),16)/15,parseInt(s.charAt(2),16)/15,e);if(a===6)return this.setHex(parseInt(s,16),e);console.warn("THREE.Color: Invalid hex color "+t)}else if(t&&t.length>0)return this.setColorName(t,e);return this}setColorName(t,e=Ue){const n=oc[t.toLowerCase()];return n!==void 0?this.setHex(n,e):console.warn("THREE.Color: Unknown color "+t),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(t){return this.r=t.r,this.g=t.g,this.b=t.b,this}copySRGBToLinear(t){return this.r=wn(t.r),this.g=wn(t.g),this.b=wn(t.b),this}copyLinearToSRGB(t){return this.r=Li(t.r),this.g=Li(t.g),this.b=Li(t.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(t=Ue){return jt.fromWorkingColorSpace(Re.copy(this),t),Math.round(Te(Re.r*255,0,255))*65536+Math.round(Te(Re.g*255,0,255))*256+Math.round(Te(Re.b*255,0,255))}getHexString(t=Ue){return("000000"+this.getHex(t).toString(16)).slice(-6)}getHSL(t,e=jt.workingColorSpace){jt.fromWorkingColorSpace(Re.copy(this),e);const n=Re.r,i=Re.g,s=Re.b,a=Math.max(n,i,s),o=Math.min(n,i,s);let l,c;const h=(o+a)/2;if(o===a)l=0,c=0;else{const u=a-o;switch(c=h<=.5?u/(a+o):u/(2-a-o),a){case n:l=(i-s)/u+(i<s?6:0);break;case i:l=(s-n)/u+2;break;case s:l=(n-i)/u+4;break}l/=6}return t.h=l,t.s=c,t.l=h,t}getRGB(t,e=jt.workingColorSpace){return jt.fromWorkingColorSpace(Re.copy(this),e),t.r=Re.r,t.g=Re.g,t.b=Re.b,t}getStyle(t=Ue){jt.fromWorkingColorSpace(Re.copy(this),t);const e=Re.r,n=Re.g,i=Re.b;return t!==Ue?`color(${t} ${e.toFixed(3)} ${n.toFixed(3)} ${i.toFixed(3)})`:`rgb(${Math.round(e*255)},${Math.round(n*255)},${Math.round(i*255)})`}offsetHSL(t,e,n){return this.getHSL(In),this.setHSL(In.h+t,In.s+e,In.l+n)}add(t){return this.r+=t.r,this.g+=t.g,this.b+=t.b,this}addColors(t,e){return this.r=t.r+e.r,this.g=t.g+e.g,this.b=t.b+e.b,this}addScalar(t){return this.r+=t,this.g+=t,this.b+=t,this}sub(t){return this.r=Math.max(0,this.r-t.r),this.g=Math.max(0,this.g-t.g),this.b=Math.max(0,this.b-t.b),this}multiply(t){return this.r*=t.r,this.g*=t.g,this.b*=t.b,this}multiplyScalar(t){return this.r*=t,this.g*=t,this.b*=t,this}lerp(t,e){return this.r+=(t.r-this.r)*e,this.g+=(t.g-this.g)*e,this.b+=(t.b-this.b)*e,this}lerpColors(t,e,n){return this.r=t.r+(e.r-t.r)*n,this.g=t.g+(e.g-t.g)*n,this.b=t.b+(e.b-t.b)*n,this}lerpHSL(t,e){this.getHSL(In),t.getHSL(Ss);const n=ls(In.h,Ss.h,e),i=ls(In.s,Ss.s,e),s=ls(In.l,Ss.l,e);return this.setHSL(n,i,s),this}setFromVector3(t){return this.r=t.x,this.g=t.y,this.b=t.z,this}applyMatrix3(t){const e=this.r,n=this.g,i=this.b,s=t.elements;return this.r=s[0]*e+s[3]*n+s[6]*i,this.g=s[1]*e+s[4]*n+s[7]*i,this.b=s[2]*e+s[5]*n+s[8]*i,this}equals(t){return t.r===this.r&&t.g===this.g&&t.b===this.b}fromArray(t,e=0){return this.r=t[e],this.g=t[e+1],this.b=t[e+2],this}toArray(t=[],e=0){return t[e]=this.r,t[e+1]=this.g,t[e+2]=this.b,t}fromBufferAttribute(t,e){return this.r=t.getX(e),this.g=t.getY(e),this.b=t.getZ(e),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const Re=new Pt;Pt.NAMES=oc;let Vh=0;class hi extends Vi{static get type(){return"Material"}get type(){return this.constructor.type}set type(t){}constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:Vh++}),this.uuid=Wi(),this.name="",this.blending=ri,this.side=Bn,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=Zr,this.blendDst=Jr,this.blendEquation=Qn,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new Pt(0,0,0),this.blendAlpha=0,this.depthFunc=Ui,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=xo,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=fi,this.stencilZFail=fi,this.stencilZPass=fi,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(t){this._alphaTest>0!=t>0&&this.version++,this._alphaTest=t}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(t){if(t!==void 0)for(const e in t){const n=t[e];if(n===void 0){console.warn(`THREE.Material: parameter '${e}' has value of undefined.`);continue}const i=this[e];if(i===void 0){console.warn(`THREE.Material: '${e}' is not a property of THREE.${this.type}.`);continue}i&&i.isColor?i.set(n):i&&i.isVector3&&n&&n.isVector3?i.copy(n):this[e]=n}}toJSON(t){const e=t===void 0||typeof t=="string";e&&(t={textures:{},images:{}});const n={metadata:{version:4.6,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,this.name!==""&&(n.name=this.name),this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(t).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(t).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(t).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.dispersion!==void 0&&(n.dispersion=this.dispersion),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(t).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(t).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(t).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(t).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(t).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(t).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(t).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(t).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(t).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(t).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(t).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(t).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(t).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(t).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(t).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(t).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(t).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(t).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapRotation!==void 0&&(n.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(t).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(t).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(t).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.shadowSide!==null&&(n.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),this.blending!==ri&&(n.blending=this.blending),this.side!==Bn&&(n.side=this.side),this.vertexColors===!0&&(n.vertexColors=!0),this.opacity<1&&(n.opacity=this.opacity),this.transparent===!0&&(n.transparent=!0),this.blendSrc!==Zr&&(n.blendSrc=this.blendSrc),this.blendDst!==Jr&&(n.blendDst=this.blendDst),this.blendEquation!==Qn&&(n.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(n.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(n.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(n.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(n.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(n.blendAlpha=this.blendAlpha),this.depthFunc!==Ui&&(n.depthFunc=this.depthFunc),this.depthTest===!1&&(n.depthTest=this.depthTest),this.depthWrite===!1&&(n.depthWrite=this.depthWrite),this.colorWrite===!1&&(n.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(n.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==xo&&(n.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(n.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(n.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==fi&&(n.stencilFail=this.stencilFail),this.stencilZFail!==fi&&(n.stencilZFail=this.stencilZFail),this.stencilZPass!==fi&&(n.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(n.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(n.rotation=this.rotation),this.polygonOffset===!0&&(n.polygonOffset=!0),this.polygonOffsetFactor!==0&&(n.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(n.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(n.linewidth=this.linewidth),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.dithering===!0&&(n.dithering=!0),this.alphaTest>0&&(n.alphaTest=this.alphaTest),this.alphaHash===!0&&(n.alphaHash=!0),this.alphaToCoverage===!0&&(n.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(n.premultipliedAlpha=!0),this.forceSinglePass===!0&&(n.forceSinglePass=!0),this.wireframe===!0&&(n.wireframe=!0),this.wireframeLinewidth>1&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(n.flatShading=!0),this.visible===!1&&(n.visible=!1),this.toneMapped===!1&&(n.toneMapped=!1),this.fog===!1&&(n.fog=!1),Object.keys(this.userData).length>0&&(n.userData=this.userData);function i(s){const a=[];for(const o in s){const l=s[o];delete l.metadata,a.push(l)}return a}if(e){const s=i(t.textures),a=i(t.images);s.length>0&&(n.textures=s),a.length>0&&(n.images=a)}return n}clone(){return new this.constructor().copy(this)}copy(t){this.name=t.name,this.blending=t.blending,this.side=t.side,this.vertexColors=t.vertexColors,this.opacity=t.opacity,this.transparent=t.transparent,this.blendSrc=t.blendSrc,this.blendDst=t.blendDst,this.blendEquation=t.blendEquation,this.blendSrcAlpha=t.blendSrcAlpha,this.blendDstAlpha=t.blendDstAlpha,this.blendEquationAlpha=t.blendEquationAlpha,this.blendColor.copy(t.blendColor),this.blendAlpha=t.blendAlpha,this.depthFunc=t.depthFunc,this.depthTest=t.depthTest,this.depthWrite=t.depthWrite,this.stencilWriteMask=t.stencilWriteMask,this.stencilFunc=t.stencilFunc,this.stencilRef=t.stencilRef,this.stencilFuncMask=t.stencilFuncMask,this.stencilFail=t.stencilFail,this.stencilZFail=t.stencilZFail,this.stencilZPass=t.stencilZPass,this.stencilWrite=t.stencilWrite;const e=t.clippingPlanes;let n=null;if(e!==null){const i=e.length;n=new Array(i);for(let s=0;s!==i;++s)n[s]=e[s].clone()}return this.clippingPlanes=n,this.clipIntersection=t.clipIntersection,this.clipShadows=t.clipShadows,this.shadowSide=t.shadowSide,this.colorWrite=t.colorWrite,this.precision=t.precision,this.polygonOffset=t.polygonOffset,this.polygonOffsetFactor=t.polygonOffsetFactor,this.polygonOffsetUnits=t.polygonOffsetUnits,this.dithering=t.dithering,this.alphaTest=t.alphaTest,this.alphaHash=t.alphaHash,this.alphaToCoverage=t.alphaToCoverage,this.premultipliedAlpha=t.premultipliedAlpha,this.forceSinglePass=t.forceSinglePass,this.visible=t.visible,this.toneMapped=t.toneMapped,this.userData=JSON.parse(JSON.stringify(t.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(t){t===!0&&this.version++}onBuild(){console.warn("Material: onBuild() has been removed.")}}class Oe extends hi{static get type(){return"MeshBasicMaterial"}constructor(t){super(),this.isMeshBasicMaterial=!0,this.color=new Pt(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new rn,this.combine=kl,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.fog=t.fog,this}}const ve=new D,bs=new Bt;class xe{constructor(t,e,n=!1){if(Array.isArray(t))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,this.name="",this.array=t,this.itemSize=e,this.count=t!==void 0?t.length/e:0,this.normalized=n,this.usage=vo,this.updateRanges=[],this.gpuType=hn,this.version=0}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.name=t.name,this.array=new t.array.constructor(t.array),this.itemSize=t.itemSize,this.count=t.count,this.normalized=t.normalized,this.usage=t.usage,this.gpuType=t.gpuType,this}copyAt(t,e,n){t*=this.itemSize,n*=e.itemSize;for(let i=0,s=this.itemSize;i<s;i++)this.array[t+i]=e.array[n+i];return this}copyArray(t){return this.array.set(t),this}applyMatrix3(t){if(this.itemSize===2)for(let e=0,n=this.count;e<n;e++)bs.fromBufferAttribute(this,e),bs.applyMatrix3(t),this.setXY(e,bs.x,bs.y);else if(this.itemSize===3)for(let e=0,n=this.count;e<n;e++)ve.fromBufferAttribute(this,e),ve.applyMatrix3(t),this.setXYZ(e,ve.x,ve.y,ve.z);return this}applyMatrix4(t){for(let e=0,n=this.count;e<n;e++)ve.fromBufferAttribute(this,e),ve.applyMatrix4(t),this.setXYZ(e,ve.x,ve.y,ve.z);return this}applyNormalMatrix(t){for(let e=0,n=this.count;e<n;e++)ve.fromBufferAttribute(this,e),ve.applyNormalMatrix(t),this.setXYZ(e,ve.x,ve.y,ve.z);return this}transformDirection(t){for(let e=0,n=this.count;e<n;e++)ve.fromBufferAttribute(this,e),ve.transformDirection(t),this.setXYZ(e,ve.x,ve.y,ve.z);return this}set(t,e=0){return this.array.set(t,e),this}getComponent(t,e){let n=this.array[t*this.itemSize+e];return this.normalized&&(n=Ri(n,this.array)),n}setComponent(t,e,n){return this.normalized&&(n=De(n,this.array)),this.array[t*this.itemSize+e]=n,this}getX(t){let e=this.array[t*this.itemSize];return this.normalized&&(e=Ri(e,this.array)),e}setX(t,e){return this.normalized&&(e=De(e,this.array)),this.array[t*this.itemSize]=e,this}getY(t){let e=this.array[t*this.itemSize+1];return this.normalized&&(e=Ri(e,this.array)),e}setY(t,e){return this.normalized&&(e=De(e,this.array)),this.array[t*this.itemSize+1]=e,this}getZ(t){let e=this.array[t*this.itemSize+2];return this.normalized&&(e=Ri(e,this.array)),e}setZ(t,e){return this.normalized&&(e=De(e,this.array)),this.array[t*this.itemSize+2]=e,this}getW(t){let e=this.array[t*this.itemSize+3];return this.normalized&&(e=Ri(e,this.array)),e}setW(t,e){return this.normalized&&(e=De(e,this.array)),this.array[t*this.itemSize+3]=e,this}setXY(t,e,n){return t*=this.itemSize,this.normalized&&(e=De(e,this.array),n=De(n,this.array)),this.array[t+0]=e,this.array[t+1]=n,this}setXYZ(t,e,n,i){return t*=this.itemSize,this.normalized&&(e=De(e,this.array),n=De(n,this.array),i=De(i,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=i,this}setXYZW(t,e,n,i,s){return t*=this.itemSize,this.normalized&&(e=De(e,this.array),n=De(n,this.array),i=De(i,this.array),s=De(s,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=i,this.array[t+3]=s,this}onUpload(t){return this.onUploadCallback=t,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const t={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(t.name=this.name),this.usage!==vo&&(t.usage=this.usage),t}}class lc extends xe{constructor(t,e,n){super(new Uint16Array(t),e,n)}}class cc extends xe{constructor(t,e,n){super(new Uint32Array(t),e,n)}}class Kt extends xe{constructor(t,e,n){super(new Float32Array(t),e,n)}}let Wh=0;const qe=new Zt,Rr=new fe,Si=new D,Ge=new li,Ji=new li,we=new D;class de extends Vi{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:Wh++}),this.uuid=Wi(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(t){return Array.isArray(t)?this.index=new(ic(t)?cc:lc)(t,1):this.index=t,this}setIndirect(t){return this.indirect=t,this}getIndirect(){return this.indirect}getAttribute(t){return this.attributes[t]}setAttribute(t,e){return this.attributes[t]=e,this}deleteAttribute(t){return delete this.attributes[t],this}hasAttribute(t){return this.attributes[t]!==void 0}addGroup(t,e,n=0){this.groups.push({start:t,count:e,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(t,e){this.drawRange.start=t,this.drawRange.count=e}applyMatrix4(t){const e=this.attributes.position;e!==void 0&&(e.applyMatrix4(t),e.needsUpdate=!0);const n=this.attributes.normal;if(n!==void 0){const s=new Xt().getNormalMatrix(t);n.applyNormalMatrix(s),n.needsUpdate=!0}const i=this.attributes.tangent;return i!==void 0&&(i.transformDirection(t),i.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(t){return qe.makeRotationFromQuaternion(t),this.applyMatrix4(qe),this}rotateX(t){return qe.makeRotationX(t),this.applyMatrix4(qe),this}rotateY(t){return qe.makeRotationY(t),this.applyMatrix4(qe),this}rotateZ(t){return qe.makeRotationZ(t),this.applyMatrix4(qe),this}translate(t,e,n){return qe.makeTranslation(t,e,n),this.applyMatrix4(qe),this}scale(t,e,n){return qe.makeScale(t,e,n),this.applyMatrix4(qe),this}lookAt(t){return Rr.lookAt(t),Rr.updateMatrix(),this.applyMatrix4(Rr.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Si).negate(),this.translate(Si.x,Si.y,Si.z),this}setFromPoints(t){const e=this.getAttribute("position");if(e===void 0){const n=[];for(let i=0,s=t.length;i<s;i++){const a=t[i];n.push(a.x,a.y,a.z||0)}this.setAttribute("position",new Kt(n,3))}else{for(let n=0,i=e.count;n<i;n++){const s=t[n];e.setXYZ(n,s.x,s.y,s.z||0)}t.length>e.count&&console.warn("THREE.BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),e.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new li);const t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new D(-1/0,-1/0,-1/0),new D(1/0,1/0,1/0));return}if(t!==void 0){if(this.boundingBox.setFromBufferAttribute(t),e)for(let n=0,i=e.length;n<i;n++){const s=e[n];Ge.setFromBufferAttribute(s),this.morphTargetsRelative?(we.addVectors(this.boundingBox.min,Ge.min),this.boundingBox.expandByPoint(we),we.addVectors(this.boundingBox.max,Ge.max),this.boundingBox.expandByPoint(we)):(this.boundingBox.expandByPoint(Ge.min),this.boundingBox.expandByPoint(Ge.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new ci);const t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new D,1/0);return}if(t){const n=this.boundingSphere.center;if(Ge.setFromBufferAttribute(t),e)for(let s=0,a=e.length;s<a;s++){const o=e[s];Ji.setFromBufferAttribute(o),this.morphTargetsRelative?(we.addVectors(Ge.min,Ji.min),Ge.expandByPoint(we),we.addVectors(Ge.max,Ji.max),Ge.expandByPoint(we)):(Ge.expandByPoint(Ji.min),Ge.expandByPoint(Ji.max))}Ge.getCenter(n);let i=0;for(let s=0,a=t.count;s<a;s++)we.fromBufferAttribute(t,s),i=Math.max(i,n.distanceToSquared(we));if(e)for(let s=0,a=e.length;s<a;s++){const o=e[s],l=this.morphTargetsRelative;for(let c=0,h=o.count;c<h;c++)we.fromBufferAttribute(o,c),l&&(Si.fromBufferAttribute(t,c),we.add(Si)),i=Math.max(i,n.distanceToSquared(we))}this.boundingSphere.radius=Math.sqrt(i),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const t=this.index,e=this.attributes;if(t===null||e.position===void 0||e.normal===void 0||e.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const n=e.position,i=e.normal,s=e.uv;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new xe(new Float32Array(4*n.count),4));const a=this.getAttribute("tangent"),o=[],l=[];for(let P=0;P<n.count;P++)o[P]=new D,l[P]=new D;const c=new D,h=new D,u=new D,f=new Bt,d=new Bt,g=new Bt,_=new D,m=new D;function p(P,b,M){c.fromBufferAttribute(n,P),h.fromBufferAttribute(n,b),u.fromBufferAttribute(n,M),f.fromBufferAttribute(s,P),d.fromBufferAttribute(s,b),g.fromBufferAttribute(s,M),h.sub(c),u.sub(c),d.sub(f),g.sub(f);const C=1/(d.x*g.y-g.x*d.y);isFinite(C)&&(_.copy(h).multiplyScalar(g.y).addScaledVector(u,-d.y).multiplyScalar(C),m.copy(u).multiplyScalar(d.x).addScaledVector(h,-g.x).multiplyScalar(C),o[P].add(_),o[b].add(_),o[M].add(_),l[P].add(m),l[b].add(m),l[M].add(m))}let x=this.groups;x.length===0&&(x=[{start:0,count:t.count}]);for(let P=0,b=x.length;P<b;++P){const M=x[P],C=M.start,U=M.count;for(let O=C,V=C+U;O<V;O+=3)p(t.getX(O+0),t.getX(O+1),t.getX(O+2))}const y=new D,v=new D,R=new D,T=new D;function E(P){R.fromBufferAttribute(i,P),T.copy(R);const b=o[P];y.copy(b),y.sub(R.multiplyScalar(R.dot(b))).normalize(),v.crossVectors(T,b);const C=v.dot(l[P])<0?-1:1;a.setXYZW(P,y.x,y.y,y.z,C)}for(let P=0,b=x.length;P<b;++P){const M=x[P],C=M.start,U=M.count;for(let O=C,V=C+U;O<V;O+=3)E(t.getX(O+0)),E(t.getX(O+1)),E(t.getX(O+2))}}computeVertexNormals(){const t=this.index,e=this.getAttribute("position");if(e!==void 0){let n=this.getAttribute("normal");if(n===void 0)n=new xe(new Float32Array(e.count*3),3),this.setAttribute("normal",n);else for(let f=0,d=n.count;f<d;f++)n.setXYZ(f,0,0,0);const i=new D,s=new D,a=new D,o=new D,l=new D,c=new D,h=new D,u=new D;if(t)for(let f=0,d=t.count;f<d;f+=3){const g=t.getX(f+0),_=t.getX(f+1),m=t.getX(f+2);i.fromBufferAttribute(e,g),s.fromBufferAttribute(e,_),a.fromBufferAttribute(e,m),h.subVectors(a,s),u.subVectors(i,s),h.cross(u),o.fromBufferAttribute(n,g),l.fromBufferAttribute(n,_),c.fromBufferAttribute(n,m),o.add(h),l.add(h),c.add(h),n.setXYZ(g,o.x,o.y,o.z),n.setXYZ(_,l.x,l.y,l.z),n.setXYZ(m,c.x,c.y,c.z)}else for(let f=0,d=e.count;f<d;f+=3)i.fromBufferAttribute(e,f+0),s.fromBufferAttribute(e,f+1),a.fromBufferAttribute(e,f+2),h.subVectors(a,s),u.subVectors(i,s),h.cross(u),n.setXYZ(f+0,h.x,h.y,h.z),n.setXYZ(f+1,h.x,h.y,h.z),n.setXYZ(f+2,h.x,h.y,h.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){const t=this.attributes.normal;for(let e=0,n=t.count;e<n;e++)we.fromBufferAttribute(t,e),we.normalize(),t.setXYZ(e,we.x,we.y,we.z)}toNonIndexed(){function t(o,l){const c=o.array,h=o.itemSize,u=o.normalized,f=new c.constructor(l.length*h);let d=0,g=0;for(let _=0,m=l.length;_<m;_++){o.isInterleavedBufferAttribute?d=l[_]*o.data.stride+o.offset:d=l[_]*h;for(let p=0;p<h;p++)f[g++]=c[d++]}return new xe(f,h,u)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const e=new de,n=this.index.array,i=this.attributes;for(const o in i){const l=i[o],c=t(l,n);e.setAttribute(o,c)}const s=this.morphAttributes;for(const o in s){const l=[],c=s[o];for(let h=0,u=c.length;h<u;h++){const f=c[h],d=t(f,n);l.push(d)}e.morphAttributes[o]=l}e.morphTargetsRelative=this.morphTargetsRelative;const a=this.groups;for(let o=0,l=a.length;o<l;o++){const c=a[o];e.addGroup(c.start,c.count,c.materialIndex)}return e}toJSON(){const t={metadata:{version:4.6,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(t.uuid=this.uuid,t.type=this.type,this.name!==""&&(t.name=this.name),Object.keys(this.userData).length>0&&(t.userData=this.userData),this.parameters!==void 0){const l=this.parameters;for(const c in l)l[c]!==void 0&&(t[c]=l[c]);return t}t.data={attributes:{}};const e=this.index;e!==null&&(t.data.index={type:e.array.constructor.name,array:Array.prototype.slice.call(e.array)});const n=this.attributes;for(const l in n){const c=n[l];t.data.attributes[l]=c.toJSON(t.data)}const i={};let s=!1;for(const l in this.morphAttributes){const c=this.morphAttributes[l],h=[];for(let u=0,f=c.length;u<f;u++){const d=c[u];h.push(d.toJSON(t.data))}h.length>0&&(i[l]=h,s=!0)}s&&(t.data.morphAttributes=i,t.data.morphTargetsRelative=this.morphTargetsRelative);const a=this.groups;a.length>0&&(t.data.groups=JSON.parse(JSON.stringify(a)));const o=this.boundingSphere;return o!==null&&(t.data.boundingSphere={center:o.center.toArray(),radius:o.radius}),t}clone(){return new this.constructor().copy(this)}copy(t){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const e={};this.name=t.name;const n=t.index;n!==null&&this.setIndex(n.clone(e));const i=t.attributes;for(const c in i){const h=i[c];this.setAttribute(c,h.clone(e))}const s=t.morphAttributes;for(const c in s){const h=[],u=s[c];for(let f=0,d=u.length;f<d;f++)h.push(u[f].clone(e));this.morphAttributes[c]=h}this.morphTargetsRelative=t.morphTargetsRelative;const a=t.groups;for(let c=0,h=a.length;c<h;c++){const u=a[c];this.addGroup(u.start,u.count,u.materialIndex)}const o=t.boundingBox;o!==null&&(this.boundingBox=o.clone());const l=t.boundingSphere;return l!==null&&(this.boundingSphere=l.clone()),this.drawRange.start=t.drawRange.start,this.drawRange.count=t.drawRange.count,this.userData=t.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}}const Oo=new Zt,Wn=new ja,ws=new ci,zo=new D,Ts=new D,Es=new D,As=new D,Cr=new D,Rs=new D,ko=new D,Cs=new D;class ot extends fe{constructor(t=new de,e=new Oe){super(),this.isMesh=!0,this.type="Mesh",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),t.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=t.morphTargetInfluences.slice()),t.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},t.morphTargetDictionary)),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}updateMorphTargets(){const e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){const i=e[n[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,a=i.length;s<a;s++){const o=i[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=s}}}}getVertexPosition(t,e){const n=this.geometry,i=n.attributes.position,s=n.morphAttributes.position,a=n.morphTargetsRelative;e.fromBufferAttribute(i,t);const o=this.morphTargetInfluences;if(s&&o){Rs.set(0,0,0);for(let l=0,c=s.length;l<c;l++){const h=o[l],u=s[l];h!==0&&(Cr.fromBufferAttribute(u,t),a?Rs.addScaledVector(Cr,h):Rs.addScaledVector(Cr.sub(e),h))}e.add(Rs)}return e}raycast(t,e){const n=this.geometry,i=this.material,s=this.matrixWorld;i!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),ws.copy(n.boundingSphere),ws.applyMatrix4(s),Wn.copy(t.ray).recast(t.near),!(ws.containsPoint(Wn.origin)===!1&&(Wn.intersectSphere(ws,zo)===null||Wn.origin.distanceToSquared(zo)>(t.far-t.near)**2))&&(Oo.copy(s).invert(),Wn.copy(t.ray).applyMatrix4(Oo),!(n.boundingBox!==null&&Wn.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(t,e,Wn)))}_computeIntersections(t,e,n){let i;const s=this.geometry,a=this.material,o=s.index,l=s.attributes.position,c=s.attributes.uv,h=s.attributes.uv1,u=s.attributes.normal,f=s.groups,d=s.drawRange;if(o!==null)if(Array.isArray(a))for(let g=0,_=f.length;g<_;g++){const m=f[g],p=a[m.materialIndex],x=Math.max(m.start,d.start),y=Math.min(o.count,Math.min(m.start+m.count,d.start+d.count));for(let v=x,R=y;v<R;v+=3){const T=o.getX(v),E=o.getX(v+1),P=o.getX(v+2);i=Ps(this,p,t,n,c,h,u,T,E,P),i&&(i.faceIndex=Math.floor(v/3),i.face.materialIndex=m.materialIndex,e.push(i))}}else{const g=Math.max(0,d.start),_=Math.min(o.count,d.start+d.count);for(let m=g,p=_;m<p;m+=3){const x=o.getX(m),y=o.getX(m+1),v=o.getX(m+2);i=Ps(this,a,t,n,c,h,u,x,y,v),i&&(i.faceIndex=Math.floor(m/3),e.push(i))}}else if(l!==void 0)if(Array.isArray(a))for(let g=0,_=f.length;g<_;g++){const m=f[g],p=a[m.materialIndex],x=Math.max(m.start,d.start),y=Math.min(l.count,Math.min(m.start+m.count,d.start+d.count));for(let v=x,R=y;v<R;v+=3){const T=v,E=v+1,P=v+2;i=Ps(this,p,t,n,c,h,u,T,E,P),i&&(i.faceIndex=Math.floor(v/3),i.face.materialIndex=m.materialIndex,e.push(i))}}else{const g=Math.max(0,d.start),_=Math.min(l.count,d.start+d.count);for(let m=g,p=_;m<p;m+=3){const x=m,y=m+1,v=m+2;i=Ps(this,a,t,n,c,h,u,x,y,v),i&&(i.faceIndex=Math.floor(m/3),e.push(i))}}}}function Xh(r,t,e,n,i,s,a,o){let l;if(t.side===Ne?l=n.intersectTriangle(a,s,i,!0,o):l=n.intersectTriangle(i,s,a,t.side===Bn,o),l===null)return null;Cs.copy(o),Cs.applyMatrix4(r.matrixWorld);const c=e.ray.origin.distanceTo(Cs);return c<e.near||c>e.far?null:{distance:c,point:Cs.clone(),object:r}}function Ps(r,t,e,n,i,s,a,o,l,c){r.getVertexPosition(o,Ts),r.getVertexPosition(l,Es),r.getVertexPosition(c,As);const h=Xh(r,t,e,n,Ts,Es,As,ko);if(h){const u=new D;en.getBarycoord(ko,Ts,Es,As,u),i&&(h.uv=en.getInterpolatedAttribute(i,o,l,c,u,new Bt)),s&&(h.uv1=en.getInterpolatedAttribute(s,o,l,c,u,new Bt)),a&&(h.normal=en.getInterpolatedAttribute(a,o,l,c,u,new D),h.normal.dot(n.direction)>0&&h.normal.multiplyScalar(-1));const f={a:o,b:l,c,normal:new D,materialIndex:0};en.getNormal(Ts,Es,As,f.normal),h.face=f,h.barycoord=u}return h}class Gt extends de{constructor(t=1,e=1,n=1,i=1,s=1,a=1){super(),this.type="BoxGeometry",this.parameters={width:t,height:e,depth:n,widthSegments:i,heightSegments:s,depthSegments:a};const o=this;i=Math.floor(i),s=Math.floor(s),a=Math.floor(a);const l=[],c=[],h=[],u=[];let f=0,d=0;g("z","y","x",-1,-1,n,e,t,a,s,0),g("z","y","x",1,-1,n,e,-t,a,s,1),g("x","z","y",1,1,t,n,e,i,a,2),g("x","z","y",1,-1,t,n,-e,i,a,3),g("x","y","z",1,-1,t,e,n,i,s,4),g("x","y","z",-1,-1,t,e,-n,i,s,5),this.setIndex(l),this.setAttribute("position",new Kt(c,3)),this.setAttribute("normal",new Kt(h,3)),this.setAttribute("uv",new Kt(u,2));function g(_,m,p,x,y,v,R,T,E,P,b){const M=v/E,C=R/P,U=v/2,O=R/2,V=T/2,X=E+1,W=P+1;let j=0,k=0;const it=new D;for(let q=0;q<W;q++){const tt=q*C-O;for(let rt=0;rt<X;rt++){const ut=rt*M-U;it[_]=ut*x,it[m]=tt*y,it[p]=V,c.push(it.x,it.y,it.z),it[_]=0,it[m]=0,it[p]=T>0?1:-1,h.push(it.x,it.y,it.z),u.push(rt/E),u.push(1-q/P),j+=1}}for(let q=0;q<P;q++)for(let tt=0;tt<E;tt++){const rt=f+tt+X*q,ut=f+tt+X*(q+1),B=f+(tt+1)+X*(q+1),J=f+(tt+1)+X*q;l.push(rt,ut,J),l.push(ut,B,J),k+=6}o.addGroup(d,k,b),d+=k,f+=j}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Gt(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)}}function Bi(r){const t={};for(const e in r){t[e]={};for(const n in r[e]){const i=r[e][n];i&&(i.isColor||i.isMatrix3||i.isMatrix4||i.isVector2||i.isVector3||i.isVector4||i.isTexture||i.isQuaternion)?i.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),t[e][n]=null):t[e][n]=i.clone():Array.isArray(i)?t[e][n]=i.slice():t[e][n]=i}}return t}function Ie(r){const t={};for(let e=0;e<r.length;e++){const n=Bi(r[e]);for(const i in n)t[i]=n[i]}return t}function qh(r){const t=[];for(let e=0;e<r.length;e++)t.push(r[e].clone());return t}function hc(r){const t=r.getRenderTarget();return t===null?r.outputColorSpace:t.isXRRenderTarget===!0?t.texture.colorSpace:jt.workingColorSpace}const us={clone:Bi,merge:Ie};var $h=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,Yh=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class ye extends hi{static get type(){return"ShaderMaterial"}constructor(t){super(),this.isShaderMaterial=!0,this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=$h,this.fragmentShader=Yh,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,t!==void 0&&this.setValues(t)}copy(t){return super.copy(t),this.fragmentShader=t.fragmentShader,this.vertexShader=t.vertexShader,this.uniforms=Bi(t.uniforms),this.uniformsGroups=qh(t.uniformsGroups),this.defines=Object.assign({},t.defines),this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.fog=t.fog,this.lights=t.lights,this.clipping=t.clipping,this.extensions=Object.assign({},t.extensions),this.glslVersion=t.glslVersion,this}toJSON(t){const e=super.toJSON(t);e.glslVersion=this.glslVersion,e.uniforms={};for(const i in this.uniforms){const a=this.uniforms[i].value;a&&a.isTexture?e.uniforms[i]={type:"t",value:a.toJSON(t).uuid}:a&&a.isColor?e.uniforms[i]={type:"c",value:a.getHex()}:a&&a.isVector2?e.uniforms[i]={type:"v2",value:a.toArray()}:a&&a.isVector3?e.uniforms[i]={type:"v3",value:a.toArray()}:a&&a.isVector4?e.uniforms[i]={type:"v4",value:a.toArray()}:a&&a.isMatrix3?e.uniforms[i]={type:"m3",value:a.toArray()}:a&&a.isMatrix4?e.uniforms[i]={type:"m4",value:a.toArray()}:e.uniforms[i]={value:a}}Object.keys(this.defines).length>0&&(e.defines=this.defines),e.vertexShader=this.vertexShader,e.fragmentShader=this.fragmentShader,e.lights=this.lights,e.clipping=this.clipping;const n={};for(const i in this.extensions)this.extensions[i]===!0&&(n[i]=!0);return Object.keys(n).length>0&&(e.extensions=n),e}}class uc extends fe{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new Zt,this.projectionMatrix=new Zt,this.projectionMatrixInverse=new Zt,this.coordinateSystem=yn}copy(t,e){return super.copy(t,e),this.matrixWorldInverse.copy(t.matrixWorldInverse),this.projectionMatrix.copy(t.projectionMatrix),this.projectionMatrixInverse.copy(t.projectionMatrixInverse),this.coordinateSystem=t.coordinateSystem,this}getWorldDirection(t){return super.getWorldDirection(t).negate()}updateMatrixWorld(t){super.updateMatrixWorld(t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(t,e){super.updateWorldMatrix(t,e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}}const Un=new D,Bo=new Bt,Go=new Bt;class He extends uc{constructor(t=50,e=1,n=.1,i=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=t,this.zoom=1,this.near=n,this.far=i,this.focus=10,this.aspect=e,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.fov=t.fov,this.zoom=t.zoom,this.near=t.near,this.far=t.far,this.focus=t.focus,this.aspect=t.aspect,this.view=t.view===null?null:Object.assign({},t.view),this.filmGauge=t.filmGauge,this.filmOffset=t.filmOffset,this}setFocalLength(t){const e=.5*this.getFilmHeight()/t;this.fov=ki*2*Math.atan(e),this.updateProjectionMatrix()}getFocalLength(){const t=Math.tan(os*.5*this.fov);return .5*this.getFilmHeight()/t}getEffectiveFOV(){return ki*2*Math.atan(Math.tan(os*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(t,e,n){Un.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),e.set(Un.x,Un.y).multiplyScalar(-t/Un.z),Un.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(Un.x,Un.y).multiplyScalar(-t/Un.z)}getViewSize(t,e){return this.getViewBounds(t,Bo,Go),e.subVectors(Go,Bo)}setViewOffset(t,e,n,i,s,a){this.aspect=t/e,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=i,this.view.width=s,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const t=this.near;let e=t*Math.tan(os*.5*this.fov)/this.zoom,n=2*e,i=this.aspect*n,s=-.5*i;const a=this.view;if(this.view!==null&&this.view.enabled){const l=a.fullWidth,c=a.fullHeight;s+=a.offsetX*i/l,e-=a.offsetY*n/c,i*=a.width/l,n*=a.height/c}const o=this.filmOffset;o!==0&&(s+=t*o/this.getFilmWidth()),this.projectionMatrix.makePerspective(s,s+i,e,e-n,t,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){const e=super.toJSON(t);return e.object.fov=this.fov,e.object.zoom=this.zoom,e.object.near=this.near,e.object.far=this.far,e.object.focus=this.focus,e.object.aspect=this.aspect,this.view!==null&&(e.object.view=Object.assign({},this.view)),e.object.filmGauge=this.filmGauge,e.object.filmOffset=this.filmOffset,e}}const bi=-90,wi=1;class jh extends fe{constructor(t,e,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;const i=new He(bi,wi,t,e);i.layers=this.layers,this.add(i);const s=new He(bi,wi,t,e);s.layers=this.layers,this.add(s);const a=new He(bi,wi,t,e);a.layers=this.layers,this.add(a);const o=new He(bi,wi,t,e);o.layers=this.layers,this.add(o);const l=new He(bi,wi,t,e);l.layers=this.layers,this.add(l);const c=new He(bi,wi,t,e);c.layers=this.layers,this.add(c)}updateCoordinateSystem(){const t=this.coordinateSystem,e=this.children.concat(),[n,i,s,a,o,l]=e;for(const c of e)this.remove(c);if(t===yn)n.up.set(0,1,0),n.lookAt(1,0,0),i.up.set(0,1,0),i.lookAt(-1,0,0),s.up.set(0,0,-1),s.lookAt(0,1,0),a.up.set(0,0,1),a.lookAt(0,-1,0),o.up.set(0,1,0),o.lookAt(0,0,1),l.up.set(0,1,0),l.lookAt(0,0,-1);else if(t===Js)n.up.set(0,-1,0),n.lookAt(-1,0,0),i.up.set(0,-1,0),i.lookAt(1,0,0),s.up.set(0,0,1),s.lookAt(0,1,0),a.up.set(0,0,-1),a.lookAt(0,-1,0),o.up.set(0,-1,0),o.lookAt(0,0,1),l.up.set(0,-1,0),l.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+t);for(const c of e)this.add(c),c.updateMatrixWorld()}update(t,e){this.parent===null&&this.updateMatrixWorld();const{renderTarget:n,activeMipmapLevel:i}=this;this.coordinateSystem!==t.coordinateSystem&&(this.coordinateSystem=t.coordinateSystem,this.updateCoordinateSystem());const[s,a,o,l,c,h]=this.children,u=t.getRenderTarget(),f=t.getActiveCubeFace(),d=t.getActiveMipmapLevel(),g=t.xr.enabled;t.xr.enabled=!1;const _=n.texture.generateMipmaps;n.texture.generateMipmaps=!1,t.setRenderTarget(n,0,i),t.render(e,s),t.setRenderTarget(n,1,i),t.render(e,a),t.setRenderTarget(n,2,i),t.render(e,o),t.setRenderTarget(n,3,i),t.render(e,l),t.setRenderTarget(n,4,i),t.render(e,c),n.texture.generateMipmaps=_,t.setRenderTarget(n,5,i),t.render(e,h),t.setRenderTarget(u,f,d),t.xr.enabled=g,n.texture.needsPMREMUpdate=!0}}class fc extends Ce{constructor(t,e,n,i,s,a,o,l,c,h){t=t!==void 0?t:[],e=e!==void 0?e:Ni,super(t,e,n,i,s,a,o,l,c,h),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(t){this.image=t}}class Kh extends sn{constructor(t=1,e={}){super(t,t,e),this.isWebGLCubeRenderTarget=!0;const n={width:t,height:t,depth:1},i=[n,n,n,n,n,n];this.texture=new fc(i,e.mapping,e.wrapS,e.wrapT,e.magFilter,e.minFilter,e.format,e.type,e.anisotropy,e.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.generateMipmaps=e.generateMipmaps!==void 0?e.generateMipmaps:!1,this.texture.minFilter=e.minFilter!==void 0?e.minFilter:cn}fromEquirectangularTexture(t,e){this.texture.type=e.type,this.texture.colorSpace=e.colorSpace,this.texture.generateMipmaps=e.generateMipmaps,this.texture.minFilter=e.minFilter,this.texture.magFilter=e.magFilter;const n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},i=new Gt(5,5,5),s=new ye({name:"CubemapFromEquirect",uniforms:Bi(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:Ne,blending:Sn});s.uniforms.tEquirect.value=e;const a=new ot(i,s),o=e.minFilter;return e.minFilter===ii&&(e.minFilter=cn),new jh(1,10,this).update(t,a),e.minFilter=o,a.geometry.dispose(),a.material.dispose(),this}clear(t,e,n,i){const s=t.getRenderTarget();for(let a=0;a<6;a++)t.setRenderTarget(this,a),t.clear(e,n,i);t.setRenderTarget(s)}}const Pr=new D,Zh=new D,Jh=new Xt;class Kn{constructor(t=new D(1,0,0),e=0){this.isPlane=!0,this.normal=t,this.constant=e}set(t,e){return this.normal.copy(t),this.constant=e,this}setComponents(t,e,n,i){return this.normal.set(t,e,n),this.constant=i,this}setFromNormalAndCoplanarPoint(t,e){return this.normal.copy(t),this.constant=-e.dot(this.normal),this}setFromCoplanarPoints(t,e,n){const i=Pr.subVectors(n,e).cross(Zh.subVectors(t,e)).normalize();return this.setFromNormalAndCoplanarPoint(i,t),this}copy(t){return this.normal.copy(t.normal),this.constant=t.constant,this}normalize(){const t=1/this.normal.length();return this.normal.multiplyScalar(t),this.constant*=t,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(t){return this.normal.dot(t)+this.constant}distanceToSphere(t){return this.distanceToPoint(t.center)-t.radius}projectPoint(t,e){return e.copy(t).addScaledVector(this.normal,-this.distanceToPoint(t))}intersectLine(t,e){const n=t.delta(Pr),i=this.normal.dot(n);if(i===0)return this.distanceToPoint(t.start)===0?e.copy(t.start):null;const s=-(t.start.dot(this.normal)+this.constant)/i;return s<0||s>1?null:e.copy(t.start).addScaledVector(n,s)}intersectsLine(t){const e=this.distanceToPoint(t.start),n=this.distanceToPoint(t.end);return e<0&&n>0||n<0&&e>0}intersectsBox(t){return t.intersectsPlane(this)}intersectsSphere(t){return t.intersectsPlane(this)}coplanarPoint(t){return t.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(t,e){const n=e||Jh.getNormalMatrix(t),i=this.coplanarPoint(Pr).applyMatrix4(t),s=this.normal.applyMatrix3(n).normalize();return this.constant=-i.dot(s),this}translate(t){return this.constant-=t.dot(this.normal),this}equals(t){return t.normal.equals(this.normal)&&t.constant===this.constant}clone(){return new this.constructor().copy(this)}}const Xn=new ci,Ls=new D;class Ka{constructor(t=new Kn,e=new Kn,n=new Kn,i=new Kn,s=new Kn,a=new Kn){this.planes=[t,e,n,i,s,a]}set(t,e,n,i,s,a){const o=this.planes;return o[0].copy(t),o[1].copy(e),o[2].copy(n),o[3].copy(i),o[4].copy(s),o[5].copy(a),this}copy(t){const e=this.planes;for(let n=0;n<6;n++)e[n].copy(t.planes[n]);return this}setFromProjectionMatrix(t,e=yn){const n=this.planes,i=t.elements,s=i[0],a=i[1],o=i[2],l=i[3],c=i[4],h=i[5],u=i[6],f=i[7],d=i[8],g=i[9],_=i[10],m=i[11],p=i[12],x=i[13],y=i[14],v=i[15];if(n[0].setComponents(l-s,f-c,m-d,v-p).normalize(),n[1].setComponents(l+s,f+c,m+d,v+p).normalize(),n[2].setComponents(l+a,f+h,m+g,v+x).normalize(),n[3].setComponents(l-a,f-h,m-g,v-x).normalize(),n[4].setComponents(l-o,f-u,m-_,v-y).normalize(),e===yn)n[5].setComponents(l+o,f+u,m+_,v+y).normalize();else if(e===Js)n[5].setComponents(o,u,_,y).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+e);return this}intersectsObject(t){if(t.boundingSphere!==void 0)t.boundingSphere===null&&t.computeBoundingSphere(),Xn.copy(t.boundingSphere).applyMatrix4(t.matrixWorld);else{const e=t.geometry;e.boundingSphere===null&&e.computeBoundingSphere(),Xn.copy(e.boundingSphere).applyMatrix4(t.matrixWorld)}return this.intersectsSphere(Xn)}intersectsSprite(t){return Xn.center.set(0,0,0),Xn.radius=.7071067811865476,Xn.applyMatrix4(t.matrixWorld),this.intersectsSphere(Xn)}intersectsSphere(t){const e=this.planes,n=t.center,i=-t.radius;for(let s=0;s<6;s++)if(e[s].distanceToPoint(n)<i)return!1;return!0}intersectsBox(t){const e=this.planes;for(let n=0;n<6;n++){const i=e[n];if(Ls.x=i.normal.x>0?t.max.x:t.min.x,Ls.y=i.normal.y>0?t.max.y:t.min.y,Ls.z=i.normal.z>0?t.max.z:t.min.z,i.distanceToPoint(Ls)<0)return!1}return!0}containsPoint(t){const e=this.planes;for(let n=0;n<6;n++)if(e[n].distanceToPoint(t)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}function dc(){let r=null,t=!1,e=null,n=null;function i(s,a){e(s,a),n=r.requestAnimationFrame(i)}return{start:function(){t!==!0&&e!==null&&(n=r.requestAnimationFrame(i),t=!0)},stop:function(){r.cancelAnimationFrame(n),t=!1},setAnimationLoop:function(s){e=s},setContext:function(s){r=s}}}function Qh(r){const t=new WeakMap;function e(o,l){const c=o.array,h=o.usage,u=c.byteLength,f=r.createBuffer();r.bindBuffer(l,f),r.bufferData(l,c,h),o.onUploadCallback();let d;if(c instanceof Float32Array)d=r.FLOAT;else if(c instanceof Uint16Array)o.isFloat16BufferAttribute?d=r.HALF_FLOAT:d=r.UNSIGNED_SHORT;else if(c instanceof Int16Array)d=r.SHORT;else if(c instanceof Uint32Array)d=r.UNSIGNED_INT;else if(c instanceof Int32Array)d=r.INT;else if(c instanceof Int8Array)d=r.BYTE;else if(c instanceof Uint8Array)d=r.UNSIGNED_BYTE;else if(c instanceof Uint8ClampedArray)d=r.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+c);return{buffer:f,type:d,bytesPerElement:c.BYTES_PER_ELEMENT,version:o.version,size:u}}function n(o,l,c){const h=l.array,u=l.updateRanges;if(r.bindBuffer(c,o),u.length===0)r.bufferSubData(c,0,h);else{u.sort((d,g)=>d.start-g.start);let f=0;for(let d=1;d<u.length;d++){const g=u[f],_=u[d];_.start<=g.start+g.count+1?g.count=Math.max(g.count,_.start+_.count-g.start):(++f,u[f]=_)}u.length=f+1;for(let d=0,g=u.length;d<g;d++){const _=u[d];r.bufferSubData(c,_.start*h.BYTES_PER_ELEMENT,h,_.start,_.count)}l.clearUpdateRanges()}l.onUploadCallback()}function i(o){return o.isInterleavedBufferAttribute&&(o=o.data),t.get(o)}function s(o){o.isInterleavedBufferAttribute&&(o=o.data);const l=t.get(o);l&&(r.deleteBuffer(l.buffer),t.delete(o))}function a(o,l){if(o.isInterleavedBufferAttribute&&(o=o.data),o.isGLBufferAttribute){const h=t.get(o);(!h||h.version<o.version)&&t.set(o,{buffer:o.buffer,type:o.type,bytesPerElement:o.elementSize,version:o.version});return}const c=t.get(o);if(c===void 0)t.set(o,e(o,l));else if(c.version<o.version){if(c.size!==o.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");n(c.buffer,o,l),c.version=o.version}}return{get:i,remove:s,update:a}}class Me extends de{constructor(t=1,e=1,n=1,i=1){super(),this.type="PlaneGeometry",this.parameters={width:t,height:e,widthSegments:n,heightSegments:i};const s=t/2,a=e/2,o=Math.floor(n),l=Math.floor(i),c=o+1,h=l+1,u=t/o,f=e/l,d=[],g=[],_=[],m=[];for(let p=0;p<h;p++){const x=p*f-a;for(let y=0;y<c;y++){const v=y*u-s;g.push(v,-x,0),_.push(0,0,1),m.push(y/o),m.push(1-p/l)}}for(let p=0;p<l;p++)for(let x=0;x<o;x++){const y=x+c*p,v=x+c*(p+1),R=x+1+c*(p+1),T=x+1+c*p;d.push(y,v,T),d.push(v,R,T)}this.setIndex(d),this.setAttribute("position",new Kt(g,3)),this.setAttribute("normal",new Kt(_,3)),this.setAttribute("uv",new Kt(m,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Me(t.width,t.height,t.widthSegments,t.heightSegments)}}var tu=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,eu=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,nu=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,iu=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,su=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,ru=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,au=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,ou=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,lu=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec3 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 ).rgb;
	}
#endif`,cu=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,hu=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,uu=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,fu=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,du=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,pu=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,mu=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,gu=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,_u=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,xu=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,vu=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,Mu=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,yu=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec3 vColor;
#endif`,Su=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif
#ifdef USE_BATCHING_COLOR
	vec3 batchingColor = getBatchingColor( getIndirectIndex( gl_DrawID ) );
	vColor.xyz *= batchingColor.xyz;
#endif`,bu=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,wu=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,Tu=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,Eu=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,Au=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,Ru=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,Cu=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,Pu="gl_FragColor = linearToOutputTexel( gl_FragColor );",Lu=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,Du=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,Iu=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,Uu=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,Nu=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,Fu=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,Ou=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,zu=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,ku=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,Bu=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,Gu=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,Hu=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,Vu=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,Wu=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,Xu=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,qu=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,$u=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,Yu=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,ju=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,Ku=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,Zu=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,Ju=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,Qu=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,tf=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,ef=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,nf=`#if defined( USE_LOGDEPTHBUF )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,sf=`#if defined( USE_LOGDEPTHBUF )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,rf=`#ifdef USE_LOGDEPTHBUF
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,af=`#ifdef USE_LOGDEPTHBUF
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,of=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,lf=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,cf=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,hf=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,uf=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,ff=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,df=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,pf=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,mf=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,gf=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,_f=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,xf=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,vf=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,Mf=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,yf=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Sf=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,bf=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,wf=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,Tf=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,Ef=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,Af=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,Rf=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,Cf=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,Pf=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,Lf=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,Df=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,If=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,Uf=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,Nf=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,Ff=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		
		float lightToPositionLength = length( lightToPosition );
		if ( lightToPositionLength - shadowCameraFar <= 0.0 && lightToPositionLength - shadowCameraNear >= 0.0 ) {
			float dp = ( lightToPositionLength - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
			#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
				vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
				shadow = (
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
				) * ( 1.0 / 9.0 );
			#else
				shadow = texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
			#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
#endif`,Of=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,zf=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,kf=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,Bf=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,Gf=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,Hf=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,Vf=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,Wf=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,Xf=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,qf=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,$f=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,Yf=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,jf=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
		
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
		
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		
		#else
		
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,Kf=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Zf=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Jf=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,Qf=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const td=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,ed=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,nd=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,id=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,sd=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,rd=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,ad=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,od=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,ld=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,cd=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,hd=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,ud=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,fd=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,dd=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,pd=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,md=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,gd=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,_d=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,xd=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,vd=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Md=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,yd=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,Sd=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,bd=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,wd=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,Td=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Ed=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Ad=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Rd=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,Cd=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Pd=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Ld=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Dd=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Id=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,$t={alphahash_fragment:tu,alphahash_pars_fragment:eu,alphamap_fragment:nu,alphamap_pars_fragment:iu,alphatest_fragment:su,alphatest_pars_fragment:ru,aomap_fragment:au,aomap_pars_fragment:ou,batching_pars_vertex:lu,batching_vertex:cu,begin_vertex:hu,beginnormal_vertex:uu,bsdfs:fu,iridescence_fragment:du,bumpmap_pars_fragment:pu,clipping_planes_fragment:mu,clipping_planes_pars_fragment:gu,clipping_planes_pars_vertex:_u,clipping_planes_vertex:xu,color_fragment:vu,color_pars_fragment:Mu,color_pars_vertex:yu,color_vertex:Su,common:bu,cube_uv_reflection_fragment:wu,defaultnormal_vertex:Tu,displacementmap_pars_vertex:Eu,displacementmap_vertex:Au,emissivemap_fragment:Ru,emissivemap_pars_fragment:Cu,colorspace_fragment:Pu,colorspace_pars_fragment:Lu,envmap_fragment:Du,envmap_common_pars_fragment:Iu,envmap_pars_fragment:Uu,envmap_pars_vertex:Nu,envmap_physical_pars_fragment:qu,envmap_vertex:Fu,fog_vertex:Ou,fog_pars_vertex:zu,fog_fragment:ku,fog_pars_fragment:Bu,gradientmap_pars_fragment:Gu,lightmap_pars_fragment:Hu,lights_lambert_fragment:Vu,lights_lambert_pars_fragment:Wu,lights_pars_begin:Xu,lights_toon_fragment:$u,lights_toon_pars_fragment:Yu,lights_phong_fragment:ju,lights_phong_pars_fragment:Ku,lights_physical_fragment:Zu,lights_physical_pars_fragment:Ju,lights_fragment_begin:Qu,lights_fragment_maps:tf,lights_fragment_end:ef,logdepthbuf_fragment:nf,logdepthbuf_pars_fragment:sf,logdepthbuf_pars_vertex:rf,logdepthbuf_vertex:af,map_fragment:of,map_pars_fragment:lf,map_particle_fragment:cf,map_particle_pars_fragment:hf,metalnessmap_fragment:uf,metalnessmap_pars_fragment:ff,morphinstance_vertex:df,morphcolor_vertex:pf,morphnormal_vertex:mf,morphtarget_pars_vertex:gf,morphtarget_vertex:_f,normal_fragment_begin:xf,normal_fragment_maps:vf,normal_pars_fragment:Mf,normal_pars_vertex:yf,normal_vertex:Sf,normalmap_pars_fragment:bf,clearcoat_normal_fragment_begin:wf,clearcoat_normal_fragment_maps:Tf,clearcoat_pars_fragment:Ef,iridescence_pars_fragment:Af,opaque_fragment:Rf,packing:Cf,premultiplied_alpha_fragment:Pf,project_vertex:Lf,dithering_fragment:Df,dithering_pars_fragment:If,roughnessmap_fragment:Uf,roughnessmap_pars_fragment:Nf,shadowmap_pars_fragment:Ff,shadowmap_pars_vertex:Of,shadowmap_vertex:zf,shadowmask_pars_fragment:kf,skinbase_vertex:Bf,skinning_pars_vertex:Gf,skinning_vertex:Hf,skinnormal_vertex:Vf,specularmap_fragment:Wf,specularmap_pars_fragment:Xf,tonemapping_fragment:qf,tonemapping_pars_fragment:$f,transmission_fragment:Yf,transmission_pars_fragment:jf,uv_pars_fragment:Kf,uv_pars_vertex:Zf,uv_vertex:Jf,worldpos_vertex:Qf,background_vert:td,background_frag:ed,backgroundCube_vert:nd,backgroundCube_frag:id,cube_vert:sd,cube_frag:rd,depth_vert:ad,depth_frag:od,distanceRGBA_vert:ld,distanceRGBA_frag:cd,equirect_vert:hd,equirect_frag:ud,linedashed_vert:fd,linedashed_frag:dd,meshbasic_vert:pd,meshbasic_frag:md,meshlambert_vert:gd,meshlambert_frag:_d,meshmatcap_vert:xd,meshmatcap_frag:vd,meshnormal_vert:Md,meshnormal_frag:yd,meshphong_vert:Sd,meshphong_frag:bd,meshphysical_vert:wd,meshphysical_frag:Td,meshtoon_vert:Ed,meshtoon_frag:Ad,points_vert:Rd,points_frag:Cd,shadow_vert:Pd,shadow_frag:Ld,sprite_vert:Dd,sprite_frag:Id},ft={common:{diffuse:{value:new Pt(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Xt},alphaMap:{value:null},alphaMapTransform:{value:new Xt},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Xt}},envmap:{envMap:{value:null},envMapRotation:{value:new Xt},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Xt}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Xt}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Xt},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Xt},normalScale:{value:new Bt(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Xt},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Xt}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Xt}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Xt}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new Pt(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new Pt(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Xt},alphaTest:{value:0},uvTransform:{value:new Xt}},sprite:{diffuse:{value:new Pt(16777215)},opacity:{value:1},center:{value:new Bt(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Xt},alphaMap:{value:null},alphaMapTransform:{value:new Xt},alphaTest:{value:0}}},on={basic:{uniforms:Ie([ft.common,ft.specularmap,ft.envmap,ft.aomap,ft.lightmap,ft.fog]),vertexShader:$t.meshbasic_vert,fragmentShader:$t.meshbasic_frag},lambert:{uniforms:Ie([ft.common,ft.specularmap,ft.envmap,ft.aomap,ft.lightmap,ft.emissivemap,ft.bumpmap,ft.normalmap,ft.displacementmap,ft.fog,ft.lights,{emissive:{value:new Pt(0)}}]),vertexShader:$t.meshlambert_vert,fragmentShader:$t.meshlambert_frag},phong:{uniforms:Ie([ft.common,ft.specularmap,ft.envmap,ft.aomap,ft.lightmap,ft.emissivemap,ft.bumpmap,ft.normalmap,ft.displacementmap,ft.fog,ft.lights,{emissive:{value:new Pt(0)},specular:{value:new Pt(1118481)},shininess:{value:30}}]),vertexShader:$t.meshphong_vert,fragmentShader:$t.meshphong_frag},standard:{uniforms:Ie([ft.common,ft.envmap,ft.aomap,ft.lightmap,ft.emissivemap,ft.bumpmap,ft.normalmap,ft.displacementmap,ft.roughnessmap,ft.metalnessmap,ft.fog,ft.lights,{emissive:{value:new Pt(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:$t.meshphysical_vert,fragmentShader:$t.meshphysical_frag},toon:{uniforms:Ie([ft.common,ft.aomap,ft.lightmap,ft.emissivemap,ft.bumpmap,ft.normalmap,ft.displacementmap,ft.gradientmap,ft.fog,ft.lights,{emissive:{value:new Pt(0)}}]),vertexShader:$t.meshtoon_vert,fragmentShader:$t.meshtoon_frag},matcap:{uniforms:Ie([ft.common,ft.bumpmap,ft.normalmap,ft.displacementmap,ft.fog,{matcap:{value:null}}]),vertexShader:$t.meshmatcap_vert,fragmentShader:$t.meshmatcap_frag},points:{uniforms:Ie([ft.points,ft.fog]),vertexShader:$t.points_vert,fragmentShader:$t.points_frag},dashed:{uniforms:Ie([ft.common,ft.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:$t.linedashed_vert,fragmentShader:$t.linedashed_frag},depth:{uniforms:Ie([ft.common,ft.displacementmap]),vertexShader:$t.depth_vert,fragmentShader:$t.depth_frag},normal:{uniforms:Ie([ft.common,ft.bumpmap,ft.normalmap,ft.displacementmap,{opacity:{value:1}}]),vertexShader:$t.meshnormal_vert,fragmentShader:$t.meshnormal_frag},sprite:{uniforms:Ie([ft.sprite,ft.fog]),vertexShader:$t.sprite_vert,fragmentShader:$t.sprite_frag},background:{uniforms:{uvTransform:{value:new Xt},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:$t.background_vert,fragmentShader:$t.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new Xt}},vertexShader:$t.backgroundCube_vert,fragmentShader:$t.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:$t.cube_vert,fragmentShader:$t.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:$t.equirect_vert,fragmentShader:$t.equirect_frag},distanceRGBA:{uniforms:Ie([ft.common,ft.displacementmap,{referencePosition:{value:new D},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:$t.distanceRGBA_vert,fragmentShader:$t.distanceRGBA_frag},shadow:{uniforms:Ie([ft.lights,ft.fog,{color:{value:new Pt(0)},opacity:{value:1}}]),vertexShader:$t.shadow_vert,fragmentShader:$t.shadow_frag}};on.physical={uniforms:Ie([on.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Xt},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Xt},clearcoatNormalScale:{value:new Bt(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Xt},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Xt},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Xt},sheen:{value:0},sheenColor:{value:new Pt(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Xt},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Xt},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Xt},transmissionSamplerSize:{value:new Bt},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Xt},attenuationDistance:{value:0},attenuationColor:{value:new Pt(0)},specularColor:{value:new Pt(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Xt},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Xt},anisotropyVector:{value:new Bt},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Xt}}]),vertexShader:$t.meshphysical_vert,fragmentShader:$t.meshphysical_frag};const Ds={r:0,b:0,g:0},qn=new rn,Ud=new Zt;function Nd(r,t,e,n,i,s,a){const o=new Pt(0);let l=s===!0?0:1,c,h,u=null,f=0,d=null;function g(x){let y=x.isScene===!0?x.background:null;return y&&y.isTexture&&(y=(x.backgroundBlurriness>0?e:t).get(y)),y}function _(x){let y=!1;const v=g(x);v===null?p(o,l):v&&v.isColor&&(p(v,1),y=!0);const R=r.xr.getEnvironmentBlendMode();R==="additive"?n.buffers.color.setClear(0,0,0,1,a):R==="alpha-blend"&&n.buffers.color.setClear(0,0,0,0,a),(r.autoClear||y)&&(n.buffers.depth.setTest(!0),n.buffers.depth.setMask(!0),n.buffers.color.setMask(!0),r.clear(r.autoClearColor,r.autoClearDepth,r.autoClearStencil))}function m(x,y){const v=g(y);v&&(v.isCubeTexture||v.mapping===rr)?(h===void 0&&(h=new ot(new Gt(1,1,1),new ye({name:"BackgroundCubeMaterial",uniforms:Bi(on.backgroundCube.uniforms),vertexShader:on.backgroundCube.vertexShader,fragmentShader:on.backgroundCube.fragmentShader,side:Ne,depthTest:!1,depthWrite:!1,fog:!1})),h.geometry.deleteAttribute("normal"),h.geometry.deleteAttribute("uv"),h.onBeforeRender=function(R,T,E){this.matrixWorld.copyPosition(E.matrixWorld)},Object.defineProperty(h.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),i.update(h)),qn.copy(y.backgroundRotation),qn.x*=-1,qn.y*=-1,qn.z*=-1,v.isCubeTexture&&v.isRenderTargetTexture===!1&&(qn.y*=-1,qn.z*=-1),h.material.uniforms.envMap.value=v,h.material.uniforms.flipEnvMap.value=v.isCubeTexture&&v.isRenderTargetTexture===!1?-1:1,h.material.uniforms.backgroundBlurriness.value=y.backgroundBlurriness,h.material.uniforms.backgroundIntensity.value=y.backgroundIntensity,h.material.uniforms.backgroundRotation.value.setFromMatrix4(Ud.makeRotationFromEuler(qn)),h.material.toneMapped=jt.getTransfer(v.colorSpace)!==se,(u!==v||f!==v.version||d!==r.toneMapping)&&(h.material.needsUpdate=!0,u=v,f=v.version,d=r.toneMapping),h.layers.enableAll(),x.unshift(h,h.geometry,h.material,0,0,null)):v&&v.isTexture&&(c===void 0&&(c=new ot(new Me(2,2),new ye({name:"BackgroundMaterial",uniforms:Bi(on.background.uniforms),vertexShader:on.background.vertexShader,fragmentShader:on.background.fragmentShader,side:Bn,depthTest:!1,depthWrite:!1,fog:!1})),c.geometry.deleteAttribute("normal"),Object.defineProperty(c.material,"map",{get:function(){return this.uniforms.t2D.value}}),i.update(c)),c.material.uniforms.t2D.value=v,c.material.uniforms.backgroundIntensity.value=y.backgroundIntensity,c.material.toneMapped=jt.getTransfer(v.colorSpace)!==se,v.matrixAutoUpdate===!0&&v.updateMatrix(),c.material.uniforms.uvTransform.value.copy(v.matrix),(u!==v||f!==v.version||d!==r.toneMapping)&&(c.material.needsUpdate=!0,u=v,f=v.version,d=r.toneMapping),c.layers.enableAll(),x.unshift(c,c.geometry,c.material,0,0,null))}function p(x,y){x.getRGB(Ds,hc(r)),n.buffers.color.setClear(Ds.r,Ds.g,Ds.b,y,a)}return{getClearColor:function(){return o},setClearColor:function(x,y=1){o.set(x),l=y,p(o,l)},getClearAlpha:function(){return l},setClearAlpha:function(x){l=x,p(o,l)},render:_,addToRenderList:m}}function Fd(r,t){const e=r.getParameter(r.MAX_VERTEX_ATTRIBS),n={},i=f(null);let s=i,a=!1;function o(M,C,U,O,V){let X=!1;const W=u(O,U,C);s!==W&&(s=W,c(s.object)),X=d(M,O,U,V),X&&g(M,O,U,V),V!==null&&t.update(V,r.ELEMENT_ARRAY_BUFFER),(X||a)&&(a=!1,v(M,C,U,O),V!==null&&r.bindBuffer(r.ELEMENT_ARRAY_BUFFER,t.get(V).buffer))}function l(){return r.createVertexArray()}function c(M){return r.bindVertexArray(M)}function h(M){return r.deleteVertexArray(M)}function u(M,C,U){const O=U.wireframe===!0;let V=n[M.id];V===void 0&&(V={},n[M.id]=V);let X=V[C.id];X===void 0&&(X={},V[C.id]=X);let W=X[O];return W===void 0&&(W=f(l()),X[O]=W),W}function f(M){const C=[],U=[],O=[];for(let V=0;V<e;V++)C[V]=0,U[V]=0,O[V]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:C,enabledAttributes:U,attributeDivisors:O,object:M,attributes:{},index:null}}function d(M,C,U,O){const V=s.attributes,X=C.attributes;let W=0;const j=U.getAttributes();for(const k in j)if(j[k].location>=0){const q=V[k];let tt=X[k];if(tt===void 0&&(k==="instanceMatrix"&&M.instanceMatrix&&(tt=M.instanceMatrix),k==="instanceColor"&&M.instanceColor&&(tt=M.instanceColor)),q===void 0||q.attribute!==tt||tt&&q.data!==tt.data)return!0;W++}return s.attributesNum!==W||s.index!==O}function g(M,C,U,O){const V={},X=C.attributes;let W=0;const j=U.getAttributes();for(const k in j)if(j[k].location>=0){let q=X[k];q===void 0&&(k==="instanceMatrix"&&M.instanceMatrix&&(q=M.instanceMatrix),k==="instanceColor"&&M.instanceColor&&(q=M.instanceColor));const tt={};tt.attribute=q,q&&q.data&&(tt.data=q.data),V[k]=tt,W++}s.attributes=V,s.attributesNum=W,s.index=O}function _(){const M=s.newAttributes;for(let C=0,U=M.length;C<U;C++)M[C]=0}function m(M){p(M,0)}function p(M,C){const U=s.newAttributes,O=s.enabledAttributes,V=s.attributeDivisors;U[M]=1,O[M]===0&&(r.enableVertexAttribArray(M),O[M]=1),V[M]!==C&&(r.vertexAttribDivisor(M,C),V[M]=C)}function x(){const M=s.newAttributes,C=s.enabledAttributes;for(let U=0,O=C.length;U<O;U++)C[U]!==M[U]&&(r.disableVertexAttribArray(U),C[U]=0)}function y(M,C,U,O,V,X,W){W===!0?r.vertexAttribIPointer(M,C,U,V,X):r.vertexAttribPointer(M,C,U,O,V,X)}function v(M,C,U,O){_();const V=O.attributes,X=U.getAttributes(),W=C.defaultAttributeValues;for(const j in X){const k=X[j];if(k.location>=0){let it=V[j];if(it===void 0&&(j==="instanceMatrix"&&M.instanceMatrix&&(it=M.instanceMatrix),j==="instanceColor"&&M.instanceColor&&(it=M.instanceColor)),it!==void 0){const q=it.normalized,tt=it.itemSize,rt=t.get(it);if(rt===void 0)continue;const ut=rt.buffer,B=rt.type,J=rt.bytesPerElement,ht=B===r.INT||B===r.UNSIGNED_INT||it.gpuType===Ga;if(it.isInterleavedBufferAttribute){const at=it.data,wt=at.stride,xt=it.offset;if(at.isInstancedInterleavedBuffer){for(let Y=0;Y<k.locationSize;Y++)p(k.location+Y,at.meshPerAttribute);M.isInstancedMesh!==!0&&O._maxInstanceCount===void 0&&(O._maxInstanceCount=at.meshPerAttribute*at.count)}else for(let Y=0;Y<k.locationSize;Y++)m(k.location+Y);r.bindBuffer(r.ARRAY_BUFFER,ut);for(let Y=0;Y<k.locationSize;Y++)y(k.location+Y,tt/k.locationSize,B,q,wt*J,(xt+tt/k.locationSize*Y)*J,ht)}else{if(it.isInstancedBufferAttribute){for(let at=0;at<k.locationSize;at++)p(k.location+at,it.meshPerAttribute);M.isInstancedMesh!==!0&&O._maxInstanceCount===void 0&&(O._maxInstanceCount=it.meshPerAttribute*it.count)}else for(let at=0;at<k.locationSize;at++)m(k.location+at);r.bindBuffer(r.ARRAY_BUFFER,ut);for(let at=0;at<k.locationSize;at++)y(k.location+at,tt/k.locationSize,B,q,tt*J,tt/k.locationSize*at*J,ht)}}else if(W!==void 0){const q=W[j];if(q!==void 0)switch(q.length){case 2:r.vertexAttrib2fv(k.location,q);break;case 3:r.vertexAttrib3fv(k.location,q);break;case 4:r.vertexAttrib4fv(k.location,q);break;default:r.vertexAttrib1fv(k.location,q)}}}}x()}function R(){P();for(const M in n){const C=n[M];for(const U in C){const O=C[U];for(const V in O)h(O[V].object),delete O[V];delete C[U]}delete n[M]}}function T(M){if(n[M.id]===void 0)return;const C=n[M.id];for(const U in C){const O=C[U];for(const V in O)h(O[V].object),delete O[V];delete C[U]}delete n[M.id]}function E(M){for(const C in n){const U=n[C];if(U[M.id]===void 0)continue;const O=U[M.id];for(const V in O)h(O[V].object),delete O[V];delete U[M.id]}}function P(){b(),a=!0,s!==i&&(s=i,c(s.object))}function b(){i.geometry=null,i.program=null,i.wireframe=!1}return{setup:o,reset:P,resetDefaultState:b,dispose:R,releaseStatesOfGeometry:T,releaseStatesOfProgram:E,initAttributes:_,enableAttribute:m,disableUnusedAttributes:x}}function Od(r,t,e){let n;function i(c){n=c}function s(c,h){r.drawArrays(n,c,h),e.update(h,n,1)}function a(c,h,u){u!==0&&(r.drawArraysInstanced(n,c,h,u),e.update(h,n,u))}function o(c,h,u){if(u===0)return;t.get("WEBGL_multi_draw").multiDrawArraysWEBGL(n,c,0,h,0,u);let d=0;for(let g=0;g<u;g++)d+=h[g];e.update(d,n,1)}function l(c,h,u,f){if(u===0)return;const d=t.get("WEBGL_multi_draw");if(d===null)for(let g=0;g<c.length;g++)a(c[g],h[g],f[g]);else{d.multiDrawArraysInstancedWEBGL(n,c,0,h,0,f,0,u);let g=0;for(let _=0;_<u;_++)g+=h[_]*f[_];e.update(g,n,1)}}this.setMode=i,this.render=s,this.renderInstances=a,this.renderMultiDraw=o,this.renderMultiDrawInstances=l}function zd(r,t,e,n){let i;function s(){if(i!==void 0)return i;if(t.has("EXT_texture_filter_anisotropic")===!0){const E=t.get("EXT_texture_filter_anisotropic");i=r.getParameter(E.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else i=0;return i}function a(E){return!(E!==nn&&n.convert(E)!==r.getParameter(r.IMPLEMENTATION_COLOR_READ_FORMAT))}function o(E){const P=E===bn&&(t.has("EXT_color_buffer_half_float")||t.has("EXT_color_buffer_float"));return!(E!==Tn&&n.convert(E)!==r.getParameter(r.IMPLEMENTATION_COLOR_READ_TYPE)&&E!==hn&&!P)}function l(E){if(E==="highp"){if(r.getShaderPrecisionFormat(r.VERTEX_SHADER,r.HIGH_FLOAT).precision>0&&r.getShaderPrecisionFormat(r.FRAGMENT_SHADER,r.HIGH_FLOAT).precision>0)return"highp";E="mediump"}return E==="mediump"&&r.getShaderPrecisionFormat(r.VERTEX_SHADER,r.MEDIUM_FLOAT).precision>0&&r.getShaderPrecisionFormat(r.FRAGMENT_SHADER,r.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let c=e.precision!==void 0?e.precision:"highp";const h=l(c);h!==c&&(console.warn("THREE.WebGLRenderer:",c,"not supported, using",h,"instead."),c=h);const u=e.logarithmicDepthBuffer===!0,f=e.reverseDepthBuffer===!0&&t.has("EXT_clip_control"),d=r.getParameter(r.MAX_TEXTURE_IMAGE_UNITS),g=r.getParameter(r.MAX_VERTEX_TEXTURE_IMAGE_UNITS),_=r.getParameter(r.MAX_TEXTURE_SIZE),m=r.getParameter(r.MAX_CUBE_MAP_TEXTURE_SIZE),p=r.getParameter(r.MAX_VERTEX_ATTRIBS),x=r.getParameter(r.MAX_VERTEX_UNIFORM_VECTORS),y=r.getParameter(r.MAX_VARYING_VECTORS),v=r.getParameter(r.MAX_FRAGMENT_UNIFORM_VECTORS),R=g>0,T=r.getParameter(r.MAX_SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:s,getMaxPrecision:l,textureFormatReadable:a,textureTypeReadable:o,precision:c,logarithmicDepthBuffer:u,reverseDepthBuffer:f,maxTextures:d,maxVertexTextures:g,maxTextureSize:_,maxCubemapSize:m,maxAttributes:p,maxVertexUniforms:x,maxVaryings:y,maxFragmentUniforms:v,vertexTextures:R,maxSamples:T}}function kd(r){const t=this;let e=null,n=0,i=!1,s=!1;const a=new Kn,o=new Xt,l={value:null,needsUpdate:!1};this.uniform=l,this.numPlanes=0,this.numIntersection=0,this.init=function(u,f){const d=u.length!==0||f||n!==0||i;return i=f,n=u.length,d},this.beginShadows=function(){s=!0,h(null)},this.endShadows=function(){s=!1},this.setGlobalState=function(u,f){e=h(u,f,0)},this.setState=function(u,f,d){const g=u.clippingPlanes,_=u.clipIntersection,m=u.clipShadows,p=r.get(u);if(!i||g===null||g.length===0||s&&!m)s?h(null):c();else{const x=s?0:n,y=x*4;let v=p.clippingState||null;l.value=v,v=h(g,f,y,d);for(let R=0;R!==y;++R)v[R]=e[R];p.clippingState=v,this.numIntersection=_?this.numPlanes:0,this.numPlanes+=x}};function c(){l.value!==e&&(l.value=e,l.needsUpdate=n>0),t.numPlanes=n,t.numIntersection=0}function h(u,f,d,g){const _=u!==null?u.length:0;let m=null;if(_!==0){if(m=l.value,g!==!0||m===null){const p=d+_*4,x=f.matrixWorldInverse;o.getNormalMatrix(x),(m===null||m.length<p)&&(m=new Float32Array(p));for(let y=0,v=d;y!==_;++y,v+=4)a.copy(u[y]).applyMatrix4(x,o),a.normal.toArray(m,v),m[v+3]=a.constant}l.value=m,l.needsUpdate=!0}return t.numPlanes=_,t.numIntersection=0,m}}function Bd(r){let t=new WeakMap;function e(a,o){return o===aa?a.mapping=Ni:o===oa&&(a.mapping=Fi),a}function n(a){if(a&&a.isTexture){const o=a.mapping;if(o===aa||o===oa)if(t.has(a)){const l=t.get(a).texture;return e(l,a.mapping)}else{const l=a.image;if(l&&l.height>0){const c=new Kh(l.height);return c.fromEquirectangularTexture(r,a),t.set(a,c),a.addEventListener("dispose",i),e(c.texture,a.mapping)}else return null}}return a}function i(a){const o=a.target;o.removeEventListener("dispose",i);const l=t.get(o);l!==void 0&&(t.delete(o),l.dispose())}function s(){t=new WeakMap}return{get:n,dispose:s}}class Za extends uc{constructor(t=-1,e=1,n=1,i=-1,s=.1,a=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=t,this.right=e,this.top=n,this.bottom=i,this.near=s,this.far=a,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.left=t.left,this.right=t.right,this.top=t.top,this.bottom=t.bottom,this.near=t.near,this.far=t.far,this.zoom=t.zoom,this.view=t.view===null?null:Object.assign({},t.view),this}setViewOffset(t,e,n,i,s,a){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=i,this.view.width=s,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const t=(this.right-this.left)/(2*this.zoom),e=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,i=(this.top+this.bottom)/2;let s=n-t,a=n+t,o=i+e,l=i-e;if(this.view!==null&&this.view.enabled){const c=(this.right-this.left)/this.view.fullWidth/this.zoom,h=(this.top-this.bottom)/this.view.fullHeight/this.zoom;s+=c*this.view.offsetX,a=s+c*this.view.width,o-=h*this.view.offsetY,l=o-h*this.view.height}this.projectionMatrix.makeOrthographic(s,a,o,l,this.near,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){const e=super.toJSON(t);return e.object.zoom=this.zoom,e.object.left=this.left,e.object.right=this.right,e.object.top=this.top,e.object.bottom=this.bottom,e.object.near=this.near,e.object.far=this.far,this.view!==null&&(e.object.view=Object.assign({},this.view)),e}}const Ci=4,Ho=[.125,.215,.35,.446,.526,.582],ti=20,Lr=new Za,Vo=new Pt;let Dr=null,Ir=0,Ur=0,Nr=!1;const Zn=(1+Math.sqrt(5))/2,Ti=1/Zn,Wo=[new D(-Zn,Ti,0),new D(Zn,Ti,0),new D(-Ti,0,Zn),new D(Ti,0,Zn),new D(0,Zn,-Ti),new D(0,Zn,Ti),new D(-1,1,-1),new D(1,1,-1),new D(-1,1,1),new D(1,1,1)];class Na{constructor(t){this._renderer=t,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(t,e=0,n=.1,i=100){Dr=this._renderer.getRenderTarget(),Ir=this._renderer.getActiveCubeFace(),Ur=this._renderer.getActiveMipmapLevel(),Nr=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(256);const s=this._allocateTargets();return s.depthBuffer=!0,this._sceneToCubeUV(t,n,i,s),e>0&&this._blur(s,0,0,e),this._applyPMREM(s),this._cleanup(s),s}fromEquirectangular(t,e=null){return this._fromTexture(t,e)}fromCubemap(t,e=null){return this._fromTexture(t,e)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=$o(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=qo(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(t){this._lodMax=Math.floor(Math.log2(t)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let t=0;t<this._lodPlanes.length;t++)this._lodPlanes[t].dispose()}_cleanup(t){this._renderer.setRenderTarget(Dr,Ir,Ur),this._renderer.xr.enabled=Nr,t.scissorTest=!1,Is(t,0,0,t.width,t.height)}_fromTexture(t,e){t.mapping===Ni||t.mapping===Fi?this._setSize(t.image.length===0?16:t.image[0].width||t.image[0].image.width):this._setSize(t.image.width/4),Dr=this._renderer.getRenderTarget(),Ir=this._renderer.getActiveCubeFace(),Ur=this._renderer.getActiveMipmapLevel(),Nr=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const n=e||this._allocateTargets();return this._textureToCubeUV(t,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){const t=3*Math.max(this._cubeSize,112),e=4*this._cubeSize,n={magFilter:cn,minFilter:cn,generateMipmaps:!1,type:bn,format:nn,colorSpace:Hi,depthBuffer:!1},i=Xo(t,e,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==t||this._pingPongRenderTarget.height!==e){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=Xo(t,e,n);const{_lodMax:s}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=Gd(s)),this._blurMaterial=Hd(s,t,e)}return i}_compileMaterial(t){const e=new ot(this._lodPlanes[0],t);this._renderer.compile(e,Lr)}_sceneToCubeUV(t,e,n,i){const o=new He(90,1,e,n),l=[1,-1,1,1,1,1],c=[1,1,1,-1,-1,-1],h=this._renderer,u=h.autoClear,f=h.toneMapping;h.getClearColor(Vo),h.toneMapping=zn,h.autoClear=!1;const d=new Oe({name:"PMREM.Background",side:Ne,depthWrite:!1,depthTest:!1}),g=new ot(new Gt,d);let _=!1;const m=t.background;m?m.isColor&&(d.color.copy(m),t.background=null,_=!0):(d.color.copy(Vo),_=!0);for(let p=0;p<6;p++){const x=p%3;x===0?(o.up.set(0,l[p],0),o.lookAt(c[p],0,0)):x===1?(o.up.set(0,0,l[p]),o.lookAt(0,c[p],0)):(o.up.set(0,l[p],0),o.lookAt(0,0,c[p]));const y=this._cubeSize;Is(i,x*y,p>2?y:0,y,y),h.setRenderTarget(i),_&&h.render(g,o),h.render(t,o)}g.geometry.dispose(),g.material.dispose(),h.toneMapping=f,h.autoClear=u,t.background=m}_textureToCubeUV(t,e){const n=this._renderer,i=t.mapping===Ni||t.mapping===Fi;i?(this._cubemapMaterial===null&&(this._cubemapMaterial=$o()),this._cubemapMaterial.uniforms.flipEnvMap.value=t.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=qo());const s=i?this._cubemapMaterial:this._equirectMaterial,a=new ot(this._lodPlanes[0],s),o=s.uniforms;o.envMap.value=t;const l=this._cubeSize;Is(e,0,0,3*l,2*l),n.setRenderTarget(e),n.render(a,Lr)}_applyPMREM(t){const e=this._renderer,n=e.autoClear;e.autoClear=!1;const i=this._lodPlanes.length;for(let s=1;s<i;s++){const a=Math.sqrt(this._sigmas[s]*this._sigmas[s]-this._sigmas[s-1]*this._sigmas[s-1]),o=Wo[(i-s-1)%Wo.length];this._blur(t,s-1,s,a,o)}e.autoClear=n}_blur(t,e,n,i,s){const a=this._pingPongRenderTarget;this._halfBlur(t,a,e,n,i,"latitudinal",s),this._halfBlur(a,t,n,n,i,"longitudinal",s)}_halfBlur(t,e,n,i,s,a,o){const l=this._renderer,c=this._blurMaterial;a!=="latitudinal"&&a!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");const h=3,u=new ot(this._lodPlanes[i],c),f=c.uniforms,d=this._sizeLods[n]-1,g=isFinite(s)?Math.PI/(2*d):2*Math.PI/(2*ti-1),_=s/g,m=isFinite(s)?1+Math.floor(h*_):ti;m>ti&&console.warn(`sigmaRadians, ${s}, is too large and will clip, as it requested ${m} samples when the maximum is set to ${ti}`);const p=[];let x=0;for(let E=0;E<ti;++E){const P=E/_,b=Math.exp(-P*P/2);p.push(b),E===0?x+=b:E<m&&(x+=2*b)}for(let E=0;E<p.length;E++)p[E]=p[E]/x;f.envMap.value=t.texture,f.samples.value=m,f.weights.value=p,f.latitudinal.value=a==="latitudinal",o&&(f.poleAxis.value=o);const{_lodMax:y}=this;f.dTheta.value=g,f.mipInt.value=y-n;const v=this._sizeLods[i],R=3*v*(i>y-Ci?i-y+Ci:0),T=4*(this._cubeSize-v);Is(e,R,T,3*v,2*v),l.setRenderTarget(e),l.render(u,Lr)}}function Gd(r){const t=[],e=[],n=[];let i=r;const s=r-Ci+1+Ho.length;for(let a=0;a<s;a++){const o=Math.pow(2,i);e.push(o);let l=1/o;a>r-Ci?l=Ho[a-r+Ci-1]:a===0&&(l=0),n.push(l);const c=1/(o-2),h=-c,u=1+c,f=[h,h,u,h,u,u,h,h,u,u,h,u],d=6,g=6,_=3,m=2,p=1,x=new Float32Array(_*g*d),y=new Float32Array(m*g*d),v=new Float32Array(p*g*d);for(let T=0;T<d;T++){const E=T%3*2/3-1,P=T>2?0:-1,b=[E,P,0,E+2/3,P,0,E+2/3,P+1,0,E,P,0,E+2/3,P+1,0,E,P+1,0];x.set(b,_*g*T),y.set(f,m*g*T);const M=[T,T,T,T,T,T];v.set(M,p*g*T)}const R=new de;R.setAttribute("position",new xe(x,_)),R.setAttribute("uv",new xe(y,m)),R.setAttribute("faceIndex",new xe(v,p)),t.push(R),i>Ci&&i--}return{lodPlanes:t,sizeLods:e,sigmas:n}}function Xo(r,t,e){const n=new sn(r,t,e);return n.texture.mapping=rr,n.texture.name="PMREM.cubeUv",n.scissorTest=!0,n}function Is(r,t,e,n,i){r.viewport.set(t,e,n,i),r.scissor.set(t,e,n,i)}function Hd(r,t,e){const n=new Float32Array(ti),i=new D(0,1,0);return new ye({name:"SphericalGaussianBlur",defines:{n:ti,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/e,CUBEUV_MAX_MIP:`${r}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:n},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:i}},vertexShader:Ja(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:Sn,depthTest:!1,depthWrite:!1})}function qo(){return new ye({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:Ja(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Sn,depthTest:!1,depthWrite:!1})}function $o(){return new ye({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Ja(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Sn,depthTest:!1,depthWrite:!1})}function Ja(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function Vd(r){let t=new WeakMap,e=null;function n(o){if(o&&o.isTexture){const l=o.mapping,c=l===aa||l===oa,h=l===Ni||l===Fi;if(c||h){let u=t.get(o);const f=u!==void 0?u.texture.pmremVersion:0;if(o.isRenderTargetTexture&&o.pmremVersion!==f)return e===null&&(e=new Na(r)),u=c?e.fromEquirectangular(o,u):e.fromCubemap(o,u),u.texture.pmremVersion=o.pmremVersion,t.set(o,u),u.texture;if(u!==void 0)return u.texture;{const d=o.image;return c&&d&&d.height>0||h&&d&&i(d)?(e===null&&(e=new Na(r)),u=c?e.fromEquirectangular(o):e.fromCubemap(o),u.texture.pmremVersion=o.pmremVersion,t.set(o,u),o.addEventListener("dispose",s),u.texture):null}}}return o}function i(o){let l=0;const c=6;for(let h=0;h<c;h++)o[h]!==void 0&&l++;return l===c}function s(o){const l=o.target;l.removeEventListener("dispose",s);const c=t.get(l);c!==void 0&&(t.delete(l),c.dispose())}function a(){t=new WeakMap,e!==null&&(e.dispose(),e=null)}return{get:n,dispose:a}}function Wd(r){const t={};function e(n){if(t[n]!==void 0)return t[n];let i;switch(n){case"WEBGL_depth_texture":i=r.getExtension("WEBGL_depth_texture")||r.getExtension("MOZ_WEBGL_depth_texture")||r.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":i=r.getExtension("EXT_texture_filter_anisotropic")||r.getExtension("MOZ_EXT_texture_filter_anisotropic")||r.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":i=r.getExtension("WEBGL_compressed_texture_s3tc")||r.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||r.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":i=r.getExtension("WEBGL_compressed_texture_pvrtc")||r.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:i=r.getExtension(n)}return t[n]=i,i}return{has:function(n){return e(n)!==null},init:function(){e("EXT_color_buffer_float"),e("WEBGL_clip_cull_distance"),e("OES_texture_float_linear"),e("EXT_color_buffer_half_float"),e("WEBGL_multisampled_render_to_texture"),e("WEBGL_render_shared_exponent")},get:function(n){const i=e(n);return i===null&&rs("THREE.WebGLRenderer: "+n+" extension not supported."),i}}}function Xd(r,t,e,n){const i={},s=new WeakMap;function a(u){const f=u.target;f.index!==null&&t.remove(f.index);for(const g in f.attributes)t.remove(f.attributes[g]);for(const g in f.morphAttributes){const _=f.morphAttributes[g];for(let m=0,p=_.length;m<p;m++)t.remove(_[m])}f.removeEventListener("dispose",a),delete i[f.id];const d=s.get(f);d&&(t.remove(d),s.delete(f)),n.releaseStatesOfGeometry(f),f.isInstancedBufferGeometry===!0&&delete f._maxInstanceCount,e.memory.geometries--}function o(u,f){return i[f.id]===!0||(f.addEventListener("dispose",a),i[f.id]=!0,e.memory.geometries++),f}function l(u){const f=u.attributes;for(const g in f)t.update(f[g],r.ARRAY_BUFFER);const d=u.morphAttributes;for(const g in d){const _=d[g];for(let m=0,p=_.length;m<p;m++)t.update(_[m],r.ARRAY_BUFFER)}}function c(u){const f=[],d=u.index,g=u.attributes.position;let _=0;if(d!==null){const x=d.array;_=d.version;for(let y=0,v=x.length;y<v;y+=3){const R=x[y+0],T=x[y+1],E=x[y+2];f.push(R,T,T,E,E,R)}}else if(g!==void 0){const x=g.array;_=g.version;for(let y=0,v=x.length/3-1;y<v;y+=3){const R=y+0,T=y+1,E=y+2;f.push(R,T,T,E,E,R)}}else return;const m=new(ic(f)?cc:lc)(f,1);m.version=_;const p=s.get(u);p&&t.remove(p),s.set(u,m)}function h(u){const f=s.get(u);if(f){const d=u.index;d!==null&&f.version<d.version&&c(u)}else c(u);return s.get(u)}return{get:o,update:l,getWireframeAttribute:h}}function qd(r,t,e){let n;function i(f){n=f}let s,a;function o(f){s=f.type,a=f.bytesPerElement}function l(f,d){r.drawElements(n,d,s,f*a),e.update(d,n,1)}function c(f,d,g){g!==0&&(r.drawElementsInstanced(n,d,s,f*a,g),e.update(d,n,g))}function h(f,d,g){if(g===0)return;t.get("WEBGL_multi_draw").multiDrawElementsWEBGL(n,d,0,s,f,0,g);let m=0;for(let p=0;p<g;p++)m+=d[p];e.update(m,n,1)}function u(f,d,g,_){if(g===0)return;const m=t.get("WEBGL_multi_draw");if(m===null)for(let p=0;p<f.length;p++)c(f[p]/a,d[p],_[p]);else{m.multiDrawElementsInstancedWEBGL(n,d,0,s,f,0,_,0,g);let p=0;for(let x=0;x<g;x++)p+=d[x]*_[x];e.update(p,n,1)}}this.setMode=i,this.setIndex=o,this.render=l,this.renderInstances=c,this.renderMultiDraw=h,this.renderMultiDrawInstances=u}function $d(r){const t={geometries:0,textures:0},e={frame:0,calls:0,triangles:0,points:0,lines:0};function n(s,a,o){switch(e.calls++,a){case r.TRIANGLES:e.triangles+=o*(s/3);break;case r.LINES:e.lines+=o*(s/2);break;case r.LINE_STRIP:e.lines+=o*(s-1);break;case r.LINE_LOOP:e.lines+=o*s;break;case r.POINTS:e.points+=o*s;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",a);break}}function i(){e.calls=0,e.triangles=0,e.points=0,e.lines=0}return{memory:t,render:e,programs:null,autoReset:!0,reset:i,update:n}}function Yd(r,t,e){const n=new WeakMap,i=new ge;function s(a,o,l){const c=a.morphTargetInfluences,h=o.morphAttributes.position||o.morphAttributes.normal||o.morphAttributes.color,u=h!==void 0?h.length:0;let f=n.get(o);if(f===void 0||f.count!==u){let M=function(){P.dispose(),n.delete(o),o.removeEventListener("dispose",M)};var d=M;f!==void 0&&f.texture.dispose();const g=o.morphAttributes.position!==void 0,_=o.morphAttributes.normal!==void 0,m=o.morphAttributes.color!==void 0,p=o.morphAttributes.position||[],x=o.morphAttributes.normal||[],y=o.morphAttributes.color||[];let v=0;g===!0&&(v=1),_===!0&&(v=2),m===!0&&(v=3);let R=o.attributes.position.count*v,T=1;R>t.maxTextureSize&&(T=Math.ceil(R/t.maxTextureSize),R=t.maxTextureSize);const E=new Float32Array(R*T*4*u),P=new rc(E,R,T,u);P.type=hn,P.needsUpdate=!0;const b=v*4;for(let C=0;C<u;C++){const U=p[C],O=x[C],V=y[C],X=R*T*4*C;for(let W=0;W<U.count;W++){const j=W*b;g===!0&&(i.fromBufferAttribute(U,W),E[X+j+0]=i.x,E[X+j+1]=i.y,E[X+j+2]=i.z,E[X+j+3]=0),_===!0&&(i.fromBufferAttribute(O,W),E[X+j+4]=i.x,E[X+j+5]=i.y,E[X+j+6]=i.z,E[X+j+7]=0),m===!0&&(i.fromBufferAttribute(V,W),E[X+j+8]=i.x,E[X+j+9]=i.y,E[X+j+10]=i.z,E[X+j+11]=V.itemSize===4?i.w:1)}}f={count:u,texture:P,size:new Bt(R,T)},n.set(o,f),o.addEventListener("dispose",M)}if(a.isInstancedMesh===!0&&a.morphTexture!==null)l.getUniforms().setValue(r,"morphTexture",a.morphTexture,e);else{let g=0;for(let m=0;m<c.length;m++)g+=c[m];const _=o.morphTargetsRelative?1:1-g;l.getUniforms().setValue(r,"morphTargetBaseInfluence",_),l.getUniforms().setValue(r,"morphTargetInfluences",c)}l.getUniforms().setValue(r,"morphTargetsTexture",f.texture,e),l.getUniforms().setValue(r,"morphTargetsTextureSize",f.size)}return{update:s}}function jd(r,t,e,n){let i=new WeakMap;function s(l){const c=n.render.frame,h=l.geometry,u=t.get(l,h);if(i.get(u)!==c&&(t.update(u),i.set(u,c)),l.isInstancedMesh&&(l.hasEventListener("dispose",o)===!1&&l.addEventListener("dispose",o),i.get(l)!==c&&(e.update(l.instanceMatrix,r.ARRAY_BUFFER),l.instanceColor!==null&&e.update(l.instanceColor,r.ARRAY_BUFFER),i.set(l,c))),l.isSkinnedMesh){const f=l.skeleton;i.get(f)!==c&&(f.update(),i.set(f,c))}return u}function a(){i=new WeakMap}function o(l){const c=l.target;c.removeEventListener("dispose",o),e.remove(c.instanceMatrix),c.instanceColor!==null&&e.remove(c.instanceColor)}return{update:s,dispose:a}}class pc extends Ce{constructor(t,e,n,i,s,a,o,l,c,h=Pi){if(h!==Pi&&h!==zi)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");n===void 0&&h===Pi&&(n=ai),n===void 0&&h===zi&&(n=Oi),super(null,i,s,a,o,l,h,n,c),this.isDepthTexture=!0,this.image={width:t,height:e},this.magFilter=o!==void 0?o:We,this.minFilter=l!==void 0?l:We,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(t){return super.copy(t),this.compareFunction=t.compareFunction,this}toJSON(t){const e=super.toJSON(t);return this.compareFunction!==null&&(e.compareFunction=this.compareFunction),e}}const mc=new Ce,Yo=new pc(1,1),gc=new rc,_c=new Nh,xc=new fc,jo=[],Ko=[],Zo=new Float32Array(16),Jo=new Float32Array(9),Qo=new Float32Array(4);function Xi(r,t,e){const n=r[0];if(n<=0||n>0)return r;const i=t*e;let s=jo[i];if(s===void 0&&(s=new Float32Array(i),jo[i]=s),t!==0){n.toArray(s,0);for(let a=1,o=0;a!==t;++a)o+=e,r[a].toArray(s,o)}return s}function Se(r,t){if(r.length!==t.length)return!1;for(let e=0,n=r.length;e<n;e++)if(r[e]!==t[e])return!1;return!0}function be(r,t){for(let e=0,n=t.length;e<n;e++)r[e]=t[e]}function or(r,t){let e=Ko[t];e===void 0&&(e=new Int32Array(t),Ko[t]=e);for(let n=0;n!==t;++n)e[n]=r.allocateTextureUnit();return e}function Kd(r,t){const e=this.cache;e[0]!==t&&(r.uniform1f(this.addr,t),e[0]=t)}function Zd(r,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(r.uniform2f(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Se(e,t))return;r.uniform2fv(this.addr,t),be(e,t)}}function Jd(r,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(r.uniform3f(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else if(t.r!==void 0)(e[0]!==t.r||e[1]!==t.g||e[2]!==t.b)&&(r.uniform3f(this.addr,t.r,t.g,t.b),e[0]=t.r,e[1]=t.g,e[2]=t.b);else{if(Se(e,t))return;r.uniform3fv(this.addr,t),be(e,t)}}function Qd(r,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(r.uniform4f(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Se(e,t))return;r.uniform4fv(this.addr,t),be(e,t)}}function tp(r,t){const e=this.cache,n=t.elements;if(n===void 0){if(Se(e,t))return;r.uniformMatrix2fv(this.addr,!1,t),be(e,t)}else{if(Se(e,n))return;Qo.set(n),r.uniformMatrix2fv(this.addr,!1,Qo),be(e,n)}}function ep(r,t){const e=this.cache,n=t.elements;if(n===void 0){if(Se(e,t))return;r.uniformMatrix3fv(this.addr,!1,t),be(e,t)}else{if(Se(e,n))return;Jo.set(n),r.uniformMatrix3fv(this.addr,!1,Jo),be(e,n)}}function np(r,t){const e=this.cache,n=t.elements;if(n===void 0){if(Se(e,t))return;r.uniformMatrix4fv(this.addr,!1,t),be(e,t)}else{if(Se(e,n))return;Zo.set(n),r.uniformMatrix4fv(this.addr,!1,Zo),be(e,n)}}function ip(r,t){const e=this.cache;e[0]!==t&&(r.uniform1i(this.addr,t),e[0]=t)}function sp(r,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(r.uniform2i(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Se(e,t))return;r.uniform2iv(this.addr,t),be(e,t)}}function rp(r,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(r.uniform3i(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(Se(e,t))return;r.uniform3iv(this.addr,t),be(e,t)}}function ap(r,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(r.uniform4i(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Se(e,t))return;r.uniform4iv(this.addr,t),be(e,t)}}function op(r,t){const e=this.cache;e[0]!==t&&(r.uniform1ui(this.addr,t),e[0]=t)}function lp(r,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(r.uniform2ui(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Se(e,t))return;r.uniform2uiv(this.addr,t),be(e,t)}}function cp(r,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(r.uniform3ui(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(Se(e,t))return;r.uniform3uiv(this.addr,t),be(e,t)}}function hp(r,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(r.uniform4ui(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Se(e,t))return;r.uniform4uiv(this.addr,t),be(e,t)}}function up(r,t,e){const n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(r.uniform1i(this.addr,i),n[0]=i);let s;this.type===r.SAMPLER_2D_SHADOW?(Yo.compareFunction=nc,s=Yo):s=mc,e.setTexture2D(t||s,i)}function fp(r,t,e){const n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(r.uniform1i(this.addr,i),n[0]=i),e.setTexture3D(t||_c,i)}function dp(r,t,e){const n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(r.uniform1i(this.addr,i),n[0]=i),e.setTextureCube(t||xc,i)}function pp(r,t,e){const n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(r.uniform1i(this.addr,i),n[0]=i),e.setTexture2DArray(t||gc,i)}function mp(r){switch(r){case 5126:return Kd;case 35664:return Zd;case 35665:return Jd;case 35666:return Qd;case 35674:return tp;case 35675:return ep;case 35676:return np;case 5124:case 35670:return ip;case 35667:case 35671:return sp;case 35668:case 35672:return rp;case 35669:case 35673:return ap;case 5125:return op;case 36294:return lp;case 36295:return cp;case 36296:return hp;case 35678:case 36198:case 36298:case 36306:case 35682:return up;case 35679:case 36299:case 36307:return fp;case 35680:case 36300:case 36308:case 36293:return dp;case 36289:case 36303:case 36311:case 36292:return pp}}function gp(r,t){r.uniform1fv(this.addr,t)}function _p(r,t){const e=Xi(t,this.size,2);r.uniform2fv(this.addr,e)}function xp(r,t){const e=Xi(t,this.size,3);r.uniform3fv(this.addr,e)}function vp(r,t){const e=Xi(t,this.size,4);r.uniform4fv(this.addr,e)}function Mp(r,t){const e=Xi(t,this.size,4);r.uniformMatrix2fv(this.addr,!1,e)}function yp(r,t){const e=Xi(t,this.size,9);r.uniformMatrix3fv(this.addr,!1,e)}function Sp(r,t){const e=Xi(t,this.size,16);r.uniformMatrix4fv(this.addr,!1,e)}function bp(r,t){r.uniform1iv(this.addr,t)}function wp(r,t){r.uniform2iv(this.addr,t)}function Tp(r,t){r.uniform3iv(this.addr,t)}function Ep(r,t){r.uniform4iv(this.addr,t)}function Ap(r,t){r.uniform1uiv(this.addr,t)}function Rp(r,t){r.uniform2uiv(this.addr,t)}function Cp(r,t){r.uniform3uiv(this.addr,t)}function Pp(r,t){r.uniform4uiv(this.addr,t)}function Lp(r,t,e){const n=this.cache,i=t.length,s=or(e,i);Se(n,s)||(r.uniform1iv(this.addr,s),be(n,s));for(let a=0;a!==i;++a)e.setTexture2D(t[a]||mc,s[a])}function Dp(r,t,e){const n=this.cache,i=t.length,s=or(e,i);Se(n,s)||(r.uniform1iv(this.addr,s),be(n,s));for(let a=0;a!==i;++a)e.setTexture3D(t[a]||_c,s[a])}function Ip(r,t,e){const n=this.cache,i=t.length,s=or(e,i);Se(n,s)||(r.uniform1iv(this.addr,s),be(n,s));for(let a=0;a!==i;++a)e.setTextureCube(t[a]||xc,s[a])}function Up(r,t,e){const n=this.cache,i=t.length,s=or(e,i);Se(n,s)||(r.uniform1iv(this.addr,s),be(n,s));for(let a=0;a!==i;++a)e.setTexture2DArray(t[a]||gc,s[a])}function Np(r){switch(r){case 5126:return gp;case 35664:return _p;case 35665:return xp;case 35666:return vp;case 35674:return Mp;case 35675:return yp;case 35676:return Sp;case 5124:case 35670:return bp;case 35667:case 35671:return wp;case 35668:case 35672:return Tp;case 35669:case 35673:return Ep;case 5125:return Ap;case 36294:return Rp;case 36295:return Cp;case 36296:return Pp;case 35678:case 36198:case 36298:case 36306:case 35682:return Lp;case 35679:case 36299:case 36307:return Dp;case 35680:case 36300:case 36308:case 36293:return Ip;case 36289:case 36303:case 36311:case 36292:return Up}}class Fp{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.setValue=mp(e.type)}}class Op{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.size=e.size,this.setValue=Np(e.type)}}class zp{constructor(t){this.id=t,this.seq=[],this.map={}}setValue(t,e,n){const i=this.seq;for(let s=0,a=i.length;s!==a;++s){const o=i[s];o.setValue(t,e[o.id],n)}}}const Fr=/(\w+)(\])?(\[|\.)?/g;function tl(r,t){r.seq.push(t),r.map[t.id]=t}function kp(r,t,e){const n=r.name,i=n.length;for(Fr.lastIndex=0;;){const s=Fr.exec(n),a=Fr.lastIndex;let o=s[1];const l=s[2]==="]",c=s[3];if(l&&(o=o|0),c===void 0||c==="["&&a+2===i){tl(e,c===void 0?new Fp(o,r,t):new Op(o,r,t));break}else{let u=e.map[o];u===void 0&&(u=new zp(o),tl(e,u)),e=u}}}class js{constructor(t,e){this.seq=[],this.map={};const n=t.getProgramParameter(e,t.ACTIVE_UNIFORMS);for(let i=0;i<n;++i){const s=t.getActiveUniform(e,i),a=t.getUniformLocation(e,s.name);kp(s,a,this)}}setValue(t,e,n,i){const s=this.map[e];s!==void 0&&s.setValue(t,n,i)}setOptional(t,e,n){const i=e[n];i!==void 0&&this.setValue(t,n,i)}static upload(t,e,n,i){for(let s=0,a=e.length;s!==a;++s){const o=e[s],l=n[o.id];l.needsUpdate!==!1&&o.setValue(t,l.value,i)}}static seqWithValue(t,e){const n=[];for(let i=0,s=t.length;i!==s;++i){const a=t[i];a.id in e&&n.push(a)}return n}}function el(r,t,e){const n=r.createShader(t);return r.shaderSource(n,e),r.compileShader(n),n}const Bp=37297;let Gp=0;function Hp(r,t){const e=r.split(`
`),n=[],i=Math.max(t-6,0),s=Math.min(t+6,e.length);for(let a=i;a<s;a++){const o=a+1;n.push(`${o===t?">":" "} ${o}: ${e[a]}`)}return n.join(`
`)}const nl=new Xt;function Vp(r){jt._getMatrix(nl,jt.workingColorSpace,r);const t=`mat3( ${nl.elements.map(e=>e.toFixed(4))} )`;switch(jt.getTransfer(r)){case ar:return[t,"LinearTransferOETF"];case se:return[t,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space: ",r),[t,"LinearTransferOETF"]}}function il(r,t,e){const n=r.getShaderParameter(t,r.COMPILE_STATUS),i=r.getShaderInfoLog(t).trim();if(n&&i==="")return"";const s=/ERROR: 0:(\d+)/.exec(i);if(s){const a=parseInt(s[1]);return e.toUpperCase()+`

`+i+`

`+Hp(r.getShaderSource(t),a)}else return i}function Wp(r,t){const e=Vp(t);return[`vec4 ${r}( vec4 value ) {`,`	return ${e[1]}( vec4( value.rgb * ${e[0]}, value.a ) );`,"}"].join(`
`)}function Xp(r,t){let e;switch(t){case Bl:e="Linear";break;case Gl:e="Reinhard";break;case Hl:e="Cineon";break;case Ba:e="ACESFilmic";break;case Vl:e="AgX";break;case Wl:e="Neutral";break;case Qc:e="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",t),e="Linear"}return"vec3 "+r+"( vec3 color ) { return "+e+"ToneMapping( color ); }"}const Us=new D;function qp(){jt.getLuminanceCoefficients(Us);const r=Us.x.toFixed(4),t=Us.y.toFixed(4),e=Us.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${r}, ${t}, ${e} );`,"	return dot( weights, rgb );","}"].join(`
`)}function $p(r){return[r.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",r.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(as).join(`
`)}function Yp(r){const t=[];for(const e in r){const n=r[e];n!==!1&&t.push("#define "+e+" "+n)}return t.join(`
`)}function jp(r,t){const e={},n=r.getProgramParameter(t,r.ACTIVE_ATTRIBUTES);for(let i=0;i<n;i++){const s=r.getActiveAttrib(t,i),a=s.name;let o=1;s.type===r.FLOAT_MAT2&&(o=2),s.type===r.FLOAT_MAT3&&(o=3),s.type===r.FLOAT_MAT4&&(o=4),e[a]={type:s.type,location:r.getAttribLocation(t,a),locationSize:o}}return e}function as(r){return r!==""}function sl(r,t){const e=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return r.replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,e).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows)}function rl(r,t){return r.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}const Kp=/^[ \t]*#include +<([\w\d./]+)>/gm;function Fa(r){return r.replace(Kp,Jp)}const Zp=new Map;function Jp(r,t){let e=$t[t];if(e===void 0){const n=Zp.get(t);if(n!==void 0)e=$t[n],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',t,n);else throw new Error("Can not resolve #include <"+t+">")}return Fa(e)}const Qp=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function al(r){return r.replace(Qp,tm)}function tm(r,t,e,n){let i="";for(let s=parseInt(t);s<parseInt(e);s++)i+=n.replace(/\[\s*i\s*\]/g,"[ "+s+" ]").replace(/UNROLLED_LOOP_INDEX/g,s);return i}function ol(r){let t=`precision ${r.precision} float;
	precision ${r.precision} int;
	precision ${r.precision} sampler2D;
	precision ${r.precision} samplerCube;
	precision ${r.precision} sampler3D;
	precision ${r.precision} sampler2DArray;
	precision ${r.precision} sampler2DShadow;
	precision ${r.precision} samplerCubeShadow;
	precision ${r.precision} sampler2DArrayShadow;
	precision ${r.precision} isampler2D;
	precision ${r.precision} isampler3D;
	precision ${r.precision} isamplerCube;
	precision ${r.precision} isampler2DArray;
	precision ${r.precision} usampler2D;
	precision ${r.precision} usampler3D;
	precision ${r.precision} usamplerCube;
	precision ${r.precision} usampler2DArray;
	`;return r.precision==="highp"?t+=`
#define HIGH_PRECISION`:r.precision==="mediump"?t+=`
#define MEDIUM_PRECISION`:r.precision==="lowp"&&(t+=`
#define LOW_PRECISION`),t}function em(r){let t="SHADOWMAP_TYPE_BASIC";return r.shadowMapType===Ol?t="SHADOWMAP_TYPE_PCF":r.shadowMapType===zl?t="SHADOWMAP_TYPE_PCF_SOFT":r.shadowMapType===Mn&&(t="SHADOWMAP_TYPE_VSM"),t}function nm(r){let t="ENVMAP_TYPE_CUBE";if(r.envMap)switch(r.envMapMode){case Ni:case Fi:t="ENVMAP_TYPE_CUBE";break;case rr:t="ENVMAP_TYPE_CUBE_UV";break}return t}function im(r){let t="ENVMAP_MODE_REFLECTION";if(r.envMap)switch(r.envMapMode){case Fi:t="ENVMAP_MODE_REFRACTION";break}return t}function sm(r){let t="ENVMAP_BLENDING_NONE";if(r.envMap)switch(r.combine){case kl:t="ENVMAP_BLENDING_MULTIPLY";break;case Zc:t="ENVMAP_BLENDING_MIX";break;case Jc:t="ENVMAP_BLENDING_ADD";break}return t}function rm(r){const t=r.envMapCubeUVHeight;if(t===null)return null;const e=Math.log2(t)-2,n=1/t;return{texelWidth:1/(3*Math.max(Math.pow(2,e),7*16)),texelHeight:n,maxMip:e}}function am(r,t,e,n){const i=r.getContext(),s=e.defines;let a=e.vertexShader,o=e.fragmentShader;const l=em(e),c=nm(e),h=im(e),u=sm(e),f=rm(e),d=$p(e),g=Yp(s),_=i.createProgram();let m,p,x=e.glslVersion?"#version "+e.glslVersion+`
`:"";e.isRawShaderMaterial?(m=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,g].filter(as).join(`
`),m.length>0&&(m+=`
`),p=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,g].filter(as).join(`
`),p.length>0&&(p+=`
`)):(m=[ol(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,g,e.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",e.batching?"#define USE_BATCHING":"",e.batchingColor?"#define USE_BATCHING_COLOR":"",e.instancing?"#define USE_INSTANCING":"",e.instancingColor?"#define USE_INSTANCING_COLOR":"",e.instancingMorph?"#define USE_INSTANCING_MORPH":"",e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.map?"#define USE_MAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+h:"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.displacementMap?"#define USE_DISPLACEMENTMAP":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.mapUv?"#define MAP_UV "+e.mapUv:"",e.alphaMapUv?"#define ALPHAMAP_UV "+e.alphaMapUv:"",e.lightMapUv?"#define LIGHTMAP_UV "+e.lightMapUv:"",e.aoMapUv?"#define AOMAP_UV "+e.aoMapUv:"",e.emissiveMapUv?"#define EMISSIVEMAP_UV "+e.emissiveMapUv:"",e.bumpMapUv?"#define BUMPMAP_UV "+e.bumpMapUv:"",e.normalMapUv?"#define NORMALMAP_UV "+e.normalMapUv:"",e.displacementMapUv?"#define DISPLACEMENTMAP_UV "+e.displacementMapUv:"",e.metalnessMapUv?"#define METALNESSMAP_UV "+e.metalnessMapUv:"",e.roughnessMapUv?"#define ROUGHNESSMAP_UV "+e.roughnessMapUv:"",e.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+e.anisotropyMapUv:"",e.clearcoatMapUv?"#define CLEARCOATMAP_UV "+e.clearcoatMapUv:"",e.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+e.clearcoatNormalMapUv:"",e.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+e.clearcoatRoughnessMapUv:"",e.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+e.iridescenceMapUv:"",e.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+e.iridescenceThicknessMapUv:"",e.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+e.sheenColorMapUv:"",e.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+e.sheenRoughnessMapUv:"",e.specularMapUv?"#define SPECULARMAP_UV "+e.specularMapUv:"",e.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+e.specularColorMapUv:"",e.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+e.specularIntensityMapUv:"",e.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+e.transmissionMapUv:"",e.thicknessMapUv?"#define THICKNESSMAP_UV "+e.thicknessMapUv:"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.flatShading?"#define FLAT_SHADED":"",e.skinning?"#define USE_SKINNING":"",e.morphTargets?"#define USE_MORPHTARGETS":"",e.morphNormals&&e.flatShading===!1?"#define USE_MORPHNORMALS":"",e.morphColors?"#define USE_MORPHCOLORS":"",e.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+e.morphTextureStride:"",e.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+e.morphTargetsCount:"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+l:"",e.sizeAttenuation?"#define USE_SIZEATTENUATION":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",e.reverseDepthBuffer?"#define USE_REVERSEDEPTHBUF":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(as).join(`
`),p=[ol(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,g,e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",e.map?"#define USE_MAP":"",e.matcap?"#define USE_MATCAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+c:"",e.envMap?"#define "+h:"",e.envMap?"#define "+u:"",f?"#define CUBEUV_TEXEL_WIDTH "+f.texelWidth:"",f?"#define CUBEUV_TEXEL_HEIGHT "+f.texelHeight:"",f?"#define CUBEUV_MAX_MIP "+f.maxMip+".0":"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoat?"#define USE_CLEARCOAT":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.dispersion?"#define USE_DISPERSION":"",e.iridescence?"#define USE_IRIDESCENCE":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaTest?"#define USE_ALPHATEST":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.sheen?"#define USE_SHEEN":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors||e.instancingColor||e.batchingColor?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.gradientMap?"#define USE_GRADIENTMAP":"",e.flatShading?"#define FLAT_SHADED":"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+l:"",e.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",e.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",e.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",e.reverseDepthBuffer?"#define USE_REVERSEDEPTHBUF":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",e.toneMapping!==zn?"#define TONE_MAPPING":"",e.toneMapping!==zn?$t.tonemapping_pars_fragment:"",e.toneMapping!==zn?Xp("toneMapping",e.toneMapping):"",e.dithering?"#define DITHERING":"",e.opaque?"#define OPAQUE":"",$t.colorspace_pars_fragment,Wp("linearToOutputTexel",e.outputColorSpace),qp(),e.useDepthPacking?"#define DEPTH_PACKING "+e.depthPacking:"",`
`].filter(as).join(`
`)),a=Fa(a),a=sl(a,e),a=rl(a,e),o=Fa(o),o=sl(o,e),o=rl(o,e),a=al(a),o=al(o),e.isRawShaderMaterial!==!0&&(x=`#version 300 es
`,m=[d,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+m,p=["#define varying in",e.glslVersion===Mo?"":"layout(location = 0) out highp vec4 pc_fragColor;",e.glslVersion===Mo?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+p);const y=x+m+a,v=x+p+o,R=el(i,i.VERTEX_SHADER,y),T=el(i,i.FRAGMENT_SHADER,v);i.attachShader(_,R),i.attachShader(_,T),e.index0AttributeName!==void 0?i.bindAttribLocation(_,0,e.index0AttributeName):e.morphTargets===!0&&i.bindAttribLocation(_,0,"position"),i.linkProgram(_);function E(C){if(r.debug.checkShaderErrors){const U=i.getProgramInfoLog(_).trim(),O=i.getShaderInfoLog(R).trim(),V=i.getShaderInfoLog(T).trim();let X=!0,W=!0;if(i.getProgramParameter(_,i.LINK_STATUS)===!1)if(X=!1,typeof r.debug.onShaderError=="function")r.debug.onShaderError(i,_,R,T);else{const j=il(i,R,"vertex"),k=il(i,T,"fragment");console.error("THREE.WebGLProgram: Shader Error "+i.getError()+" - VALIDATE_STATUS "+i.getProgramParameter(_,i.VALIDATE_STATUS)+`

Material Name: `+C.name+`
Material Type: `+C.type+`

Program Info Log: `+U+`
`+j+`
`+k)}else U!==""?console.warn("THREE.WebGLProgram: Program Info Log:",U):(O===""||V==="")&&(W=!1);W&&(C.diagnostics={runnable:X,programLog:U,vertexShader:{log:O,prefix:m},fragmentShader:{log:V,prefix:p}})}i.deleteShader(R),i.deleteShader(T),P=new js(i,_),b=jp(i,_)}let P;this.getUniforms=function(){return P===void 0&&E(this),P};let b;this.getAttributes=function(){return b===void 0&&E(this),b};let M=e.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return M===!1&&(M=i.getProgramParameter(_,Bp)),M},this.destroy=function(){n.releaseStatesOfProgram(this),i.deleteProgram(_),this.program=void 0},this.type=e.shaderType,this.name=e.shaderName,this.id=Gp++,this.cacheKey=t,this.usedTimes=1,this.program=_,this.vertexShader=R,this.fragmentShader=T,this}let om=0;class lm{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(t){const e=t.vertexShader,n=t.fragmentShader,i=this._getShaderStage(e),s=this._getShaderStage(n),a=this._getShaderCacheForMaterial(t);return a.has(i)===!1&&(a.add(i),i.usedTimes++),a.has(s)===!1&&(a.add(s),s.usedTimes++),this}remove(t){const e=this.materialCache.get(t);for(const n of e)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(t),this}getVertexShaderID(t){return this._getShaderStage(t.vertexShader).id}getFragmentShaderID(t){return this._getShaderStage(t.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(t){const e=this.materialCache;let n=e.get(t);return n===void 0&&(n=new Set,e.set(t,n)),n}_getShaderStage(t){const e=this.shaderCache;let n=e.get(t);return n===void 0&&(n=new cm(t),e.set(t,n)),n}}class cm{constructor(t){this.id=om++,this.code=t,this.usedTimes=0}}function hm(r,t,e,n,i,s,a){const o=new ac,l=new lm,c=new Set,h=[],u=i.logarithmicDepthBuffer,f=i.vertexTextures;let d=i.precision;const g={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function _(b){return c.add(b),b===0?"uv":`uv${b}`}function m(b,M,C,U,O){const V=U.fog,X=O.geometry,W=b.isMeshStandardMaterial?U.environment:null,j=(b.isMeshStandardMaterial?e:t).get(b.envMap||W),k=j&&j.mapping===rr?j.image.height:null,it=g[b.type];b.precision!==null&&(d=i.getMaxPrecision(b.precision),d!==b.precision&&console.warn("THREE.WebGLProgram.getParameters:",b.precision,"not supported, using",d,"instead."));const q=X.morphAttributes.position||X.morphAttributes.normal||X.morphAttributes.color,tt=q!==void 0?q.length:0;let rt=0;X.morphAttributes.position!==void 0&&(rt=1),X.morphAttributes.normal!==void 0&&(rt=2),X.morphAttributes.color!==void 0&&(rt=3);let ut,B,J,ht;if(it){const ie=on[it];ut=ie.vertexShader,B=ie.fragmentShader}else ut=b.vertexShader,B=b.fragmentShader,l.update(b),J=l.getVertexShaderID(b),ht=l.getFragmentShaderID(b);const at=r.getRenderTarget(),wt=r.state.buffers.depth.getReversed(),xt=O.isInstancedMesh===!0,Y=O.isBatchedMesh===!0,et=!!b.map,dt=!!b.matcap,zt=!!j,L=!!b.aoMap,Qt=!!b.lightMap,Ot=!!b.bumpMap,It=!!b.normalMap,Tt=!!b.displacementMap,te=!!b.emissiveMap,Dt=!!b.metalnessMap,A=!!b.roughnessMap,S=b.anisotropy>0,z=b.clearcoat>0,Z=b.dispersion>0,nt=b.iridescence>0,K=b.sheen>0,Et=b.transmission>0,mt=S&&!!b.anisotropyMap,vt=z&&!!b.clearcoatMap,kt=z&&!!b.clearcoatNormalMap,st=z&&!!b.clearcoatRoughnessMap,gt=nt&&!!b.iridescenceMap,Ut=nt&&!!b.iridescenceThicknessMap,Nt=K&&!!b.sheenColorMap,Mt=K&&!!b.sheenRoughnessMap,Yt=!!b.specularMap,qt=!!b.specularColorMap,oe=!!b.specularIntensityMap,I=Et&&!!b.transmissionMap,_t=Et&&!!b.thicknessMap,$=!!b.gradientMap,Q=!!b.alphaMap,bt=b.alphaTest>0,yt=!!b.alphaHash,Vt=!!b.extensions;let pe=zn;b.toneMapped&&(at===null||at.isXRRenderTarget===!0)&&(pe=r.toneMapping);const Ee={shaderID:it,shaderType:b.type,shaderName:b.name,vertexShader:ut,fragmentShader:B,defines:b.defines,customVertexShaderID:J,customFragmentShaderID:ht,isRawShaderMaterial:b.isRawShaderMaterial===!0,glslVersion:b.glslVersion,precision:d,batching:Y,batchingColor:Y&&O._colorsTexture!==null,instancing:xt,instancingColor:xt&&O.instanceColor!==null,instancingMorph:xt&&O.morphTexture!==null,supportsVertexTextures:f,outputColorSpace:at===null?r.outputColorSpace:at.isXRRenderTarget===!0?at.texture.colorSpace:Hi,alphaToCoverage:!!b.alphaToCoverage,map:et,matcap:dt,envMap:zt,envMapMode:zt&&j.mapping,envMapCubeUVHeight:k,aoMap:L,lightMap:Qt,bumpMap:Ot,normalMap:It,displacementMap:f&&Tt,emissiveMap:te,normalMapObjectSpace:It&&b.normalMapType===ih,normalMapTangentSpace:It&&b.normalMapType===ec,metalnessMap:Dt,roughnessMap:A,anisotropy:S,anisotropyMap:mt,clearcoat:z,clearcoatMap:vt,clearcoatNormalMap:kt,clearcoatRoughnessMap:st,dispersion:Z,iridescence:nt,iridescenceMap:gt,iridescenceThicknessMap:Ut,sheen:K,sheenColorMap:Nt,sheenRoughnessMap:Mt,specularMap:Yt,specularColorMap:qt,specularIntensityMap:oe,transmission:Et,transmissionMap:I,thicknessMap:_t,gradientMap:$,opaque:b.transparent===!1&&b.blending===ri&&b.alphaToCoverage===!1,alphaMap:Q,alphaTest:bt,alphaHash:yt,combine:b.combine,mapUv:et&&_(b.map.channel),aoMapUv:L&&_(b.aoMap.channel),lightMapUv:Qt&&_(b.lightMap.channel),bumpMapUv:Ot&&_(b.bumpMap.channel),normalMapUv:It&&_(b.normalMap.channel),displacementMapUv:Tt&&_(b.displacementMap.channel),emissiveMapUv:te&&_(b.emissiveMap.channel),metalnessMapUv:Dt&&_(b.metalnessMap.channel),roughnessMapUv:A&&_(b.roughnessMap.channel),anisotropyMapUv:mt&&_(b.anisotropyMap.channel),clearcoatMapUv:vt&&_(b.clearcoatMap.channel),clearcoatNormalMapUv:kt&&_(b.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:st&&_(b.clearcoatRoughnessMap.channel),iridescenceMapUv:gt&&_(b.iridescenceMap.channel),iridescenceThicknessMapUv:Ut&&_(b.iridescenceThicknessMap.channel),sheenColorMapUv:Nt&&_(b.sheenColorMap.channel),sheenRoughnessMapUv:Mt&&_(b.sheenRoughnessMap.channel),specularMapUv:Yt&&_(b.specularMap.channel),specularColorMapUv:qt&&_(b.specularColorMap.channel),specularIntensityMapUv:oe&&_(b.specularIntensityMap.channel),transmissionMapUv:I&&_(b.transmissionMap.channel),thicknessMapUv:_t&&_(b.thicknessMap.channel),alphaMapUv:Q&&_(b.alphaMap.channel),vertexTangents:!!X.attributes.tangent&&(It||S),vertexColors:b.vertexColors,vertexAlphas:b.vertexColors===!0&&!!X.attributes.color&&X.attributes.color.itemSize===4,pointsUvs:O.isPoints===!0&&!!X.attributes.uv&&(et||Q),fog:!!V,useFog:b.fog===!0,fogExp2:!!V&&V.isFogExp2,flatShading:b.flatShading===!0,sizeAttenuation:b.sizeAttenuation===!0,logarithmicDepthBuffer:u,reverseDepthBuffer:wt,skinning:O.isSkinnedMesh===!0,morphTargets:X.morphAttributes.position!==void 0,morphNormals:X.morphAttributes.normal!==void 0,morphColors:X.morphAttributes.color!==void 0,morphTargetsCount:tt,morphTextureStride:rt,numDirLights:M.directional.length,numPointLights:M.point.length,numSpotLights:M.spot.length,numSpotLightMaps:M.spotLightMap.length,numRectAreaLights:M.rectArea.length,numHemiLights:M.hemi.length,numDirLightShadows:M.directionalShadowMap.length,numPointLightShadows:M.pointShadowMap.length,numSpotLightShadows:M.spotShadowMap.length,numSpotLightShadowsWithMaps:M.numSpotLightShadowsWithMaps,numLightProbes:M.numLightProbes,numClippingPlanes:a.numPlanes,numClipIntersection:a.numIntersection,dithering:b.dithering,shadowMapEnabled:r.shadowMap.enabled&&C.length>0,shadowMapType:r.shadowMap.type,toneMapping:pe,decodeVideoTexture:et&&b.map.isVideoTexture===!0&&jt.getTransfer(b.map.colorSpace)===se,decodeVideoTextureEmissive:te&&b.emissiveMap.isVideoTexture===!0&&jt.getTransfer(b.emissiveMap.colorSpace)===se,premultipliedAlpha:b.premultipliedAlpha,doubleSided:b.side===Ve,flipSided:b.side===Ne,useDepthPacking:b.depthPacking>=0,depthPacking:b.depthPacking||0,index0AttributeName:b.index0AttributeName,extensionClipCullDistance:Vt&&b.extensions.clipCullDistance===!0&&n.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(Vt&&b.extensions.multiDraw===!0||Y)&&n.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:n.has("KHR_parallel_shader_compile"),customProgramCacheKey:b.customProgramCacheKey()};return Ee.vertexUv1s=c.has(1),Ee.vertexUv2s=c.has(2),Ee.vertexUv3s=c.has(3),c.clear(),Ee}function p(b){const M=[];if(b.shaderID?M.push(b.shaderID):(M.push(b.customVertexShaderID),M.push(b.customFragmentShaderID)),b.defines!==void 0)for(const C in b.defines)M.push(C),M.push(b.defines[C]);return b.isRawShaderMaterial===!1&&(x(M,b),y(M,b),M.push(r.outputColorSpace)),M.push(b.customProgramCacheKey),M.join()}function x(b,M){b.push(M.precision),b.push(M.outputColorSpace),b.push(M.envMapMode),b.push(M.envMapCubeUVHeight),b.push(M.mapUv),b.push(M.alphaMapUv),b.push(M.lightMapUv),b.push(M.aoMapUv),b.push(M.bumpMapUv),b.push(M.normalMapUv),b.push(M.displacementMapUv),b.push(M.emissiveMapUv),b.push(M.metalnessMapUv),b.push(M.roughnessMapUv),b.push(M.anisotropyMapUv),b.push(M.clearcoatMapUv),b.push(M.clearcoatNormalMapUv),b.push(M.clearcoatRoughnessMapUv),b.push(M.iridescenceMapUv),b.push(M.iridescenceThicknessMapUv),b.push(M.sheenColorMapUv),b.push(M.sheenRoughnessMapUv),b.push(M.specularMapUv),b.push(M.specularColorMapUv),b.push(M.specularIntensityMapUv),b.push(M.transmissionMapUv),b.push(M.thicknessMapUv),b.push(M.combine),b.push(M.fogExp2),b.push(M.sizeAttenuation),b.push(M.morphTargetsCount),b.push(M.morphAttributeCount),b.push(M.numDirLights),b.push(M.numPointLights),b.push(M.numSpotLights),b.push(M.numSpotLightMaps),b.push(M.numHemiLights),b.push(M.numRectAreaLights),b.push(M.numDirLightShadows),b.push(M.numPointLightShadows),b.push(M.numSpotLightShadows),b.push(M.numSpotLightShadowsWithMaps),b.push(M.numLightProbes),b.push(M.shadowMapType),b.push(M.toneMapping),b.push(M.numClippingPlanes),b.push(M.numClipIntersection),b.push(M.depthPacking)}function y(b,M){o.disableAll(),M.supportsVertexTextures&&o.enable(0),M.instancing&&o.enable(1),M.instancingColor&&o.enable(2),M.instancingMorph&&o.enable(3),M.matcap&&o.enable(4),M.envMap&&o.enable(5),M.normalMapObjectSpace&&o.enable(6),M.normalMapTangentSpace&&o.enable(7),M.clearcoat&&o.enable(8),M.iridescence&&o.enable(9),M.alphaTest&&o.enable(10),M.vertexColors&&o.enable(11),M.vertexAlphas&&o.enable(12),M.vertexUv1s&&o.enable(13),M.vertexUv2s&&o.enable(14),M.vertexUv3s&&o.enable(15),M.vertexTangents&&o.enable(16),M.anisotropy&&o.enable(17),M.alphaHash&&o.enable(18),M.batching&&o.enable(19),M.dispersion&&o.enable(20),M.batchingColor&&o.enable(21),b.push(o.mask),o.disableAll(),M.fog&&o.enable(0),M.useFog&&o.enable(1),M.flatShading&&o.enable(2),M.logarithmicDepthBuffer&&o.enable(3),M.reverseDepthBuffer&&o.enable(4),M.skinning&&o.enable(5),M.morphTargets&&o.enable(6),M.morphNormals&&o.enable(7),M.morphColors&&o.enable(8),M.premultipliedAlpha&&o.enable(9),M.shadowMapEnabled&&o.enable(10),M.doubleSided&&o.enable(11),M.flipSided&&o.enable(12),M.useDepthPacking&&o.enable(13),M.dithering&&o.enable(14),M.transmission&&o.enable(15),M.sheen&&o.enable(16),M.opaque&&o.enable(17),M.pointsUvs&&o.enable(18),M.decodeVideoTexture&&o.enable(19),M.decodeVideoTextureEmissive&&o.enable(20),M.alphaToCoverage&&o.enable(21),b.push(o.mask)}function v(b){const M=g[b.type];let C;if(M){const U=on[M];C=us.clone(U.uniforms)}else C=b.uniforms;return C}function R(b,M){let C;for(let U=0,O=h.length;U<O;U++){const V=h[U];if(V.cacheKey===M){C=V,++C.usedTimes;break}}return C===void 0&&(C=new am(r,M,b,s),h.push(C)),C}function T(b){if(--b.usedTimes===0){const M=h.indexOf(b);h[M]=h[h.length-1],h.pop(),b.destroy()}}function E(b){l.remove(b)}function P(){l.dispose()}return{getParameters:m,getProgramCacheKey:p,getUniforms:v,acquireProgram:R,releaseProgram:T,releaseShaderCache:E,programs:h,dispose:P}}function um(){let r=new WeakMap;function t(a){return r.has(a)}function e(a){let o=r.get(a);return o===void 0&&(o={},r.set(a,o)),o}function n(a){r.delete(a)}function i(a,o,l){r.get(a)[o]=l}function s(){r=new WeakMap}return{has:t,get:e,remove:n,update:i,dispose:s}}function fm(r,t){return r.groupOrder!==t.groupOrder?r.groupOrder-t.groupOrder:r.renderOrder!==t.renderOrder?r.renderOrder-t.renderOrder:r.material.id!==t.material.id?r.material.id-t.material.id:r.z!==t.z?r.z-t.z:r.id-t.id}function ll(r,t){return r.groupOrder!==t.groupOrder?r.groupOrder-t.groupOrder:r.renderOrder!==t.renderOrder?r.renderOrder-t.renderOrder:r.z!==t.z?t.z-r.z:r.id-t.id}function cl(){const r=[];let t=0;const e=[],n=[],i=[];function s(){t=0,e.length=0,n.length=0,i.length=0}function a(u,f,d,g,_,m){let p=r[t];return p===void 0?(p={id:u.id,object:u,geometry:f,material:d,groupOrder:g,renderOrder:u.renderOrder,z:_,group:m},r[t]=p):(p.id=u.id,p.object=u,p.geometry=f,p.material=d,p.groupOrder=g,p.renderOrder=u.renderOrder,p.z=_,p.group=m),t++,p}function o(u,f,d,g,_,m){const p=a(u,f,d,g,_,m);d.transmission>0?n.push(p):d.transparent===!0?i.push(p):e.push(p)}function l(u,f,d,g,_,m){const p=a(u,f,d,g,_,m);d.transmission>0?n.unshift(p):d.transparent===!0?i.unshift(p):e.unshift(p)}function c(u,f){e.length>1&&e.sort(u||fm),n.length>1&&n.sort(f||ll),i.length>1&&i.sort(f||ll)}function h(){for(let u=t,f=r.length;u<f;u++){const d=r[u];if(d.id===null)break;d.id=null,d.object=null,d.geometry=null,d.material=null,d.group=null}}return{opaque:e,transmissive:n,transparent:i,init:s,push:o,unshift:l,finish:h,sort:c}}function dm(){let r=new WeakMap;function t(n,i){const s=r.get(n);let a;return s===void 0?(a=new cl,r.set(n,[a])):i>=s.length?(a=new cl,s.push(a)):a=s[i],a}function e(){r=new WeakMap}return{get:t,dispose:e}}function pm(){const r={};return{get:function(t){if(r[t.id]!==void 0)return r[t.id];let e;switch(t.type){case"DirectionalLight":e={direction:new D,color:new Pt};break;case"SpotLight":e={position:new D,direction:new D,color:new Pt,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":e={position:new D,color:new Pt,distance:0,decay:0};break;case"HemisphereLight":e={direction:new D,skyColor:new Pt,groundColor:new Pt};break;case"RectAreaLight":e={color:new Pt,position:new D,halfWidth:new D,halfHeight:new D};break}return r[t.id]=e,e}}}function mm(){const r={};return{get:function(t){if(r[t.id]!==void 0)return r[t.id];let e;switch(t.type){case"DirectionalLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Bt};break;case"SpotLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Bt};break;case"PointLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Bt,shadowCameraNear:1,shadowCameraFar:1e3};break}return r[t.id]=e,e}}}let gm=0;function _m(r,t){return(t.castShadow?2:0)-(r.castShadow?2:0)+(t.map?1:0)-(r.map?1:0)}function xm(r){const t=new pm,e=mm(),n={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let c=0;c<9;c++)n.probe.push(new D);const i=new D,s=new Zt,a=new Zt;function o(c){let h=0,u=0,f=0;for(let b=0;b<9;b++)n.probe[b].set(0,0,0);let d=0,g=0,_=0,m=0,p=0,x=0,y=0,v=0,R=0,T=0,E=0;c.sort(_m);for(let b=0,M=c.length;b<M;b++){const C=c[b],U=C.color,O=C.intensity,V=C.distance,X=C.shadow&&C.shadow.map?C.shadow.map.texture:null;if(C.isAmbientLight)h+=U.r*O,u+=U.g*O,f+=U.b*O;else if(C.isLightProbe){for(let W=0;W<9;W++)n.probe[W].addScaledVector(C.sh.coefficients[W],O);E++}else if(C.isDirectionalLight){const W=t.get(C);if(W.color.copy(C.color).multiplyScalar(C.intensity),C.castShadow){const j=C.shadow,k=e.get(C);k.shadowIntensity=j.intensity,k.shadowBias=j.bias,k.shadowNormalBias=j.normalBias,k.shadowRadius=j.radius,k.shadowMapSize=j.mapSize,n.directionalShadow[d]=k,n.directionalShadowMap[d]=X,n.directionalShadowMatrix[d]=C.shadow.matrix,x++}n.directional[d]=W,d++}else if(C.isSpotLight){const W=t.get(C);W.position.setFromMatrixPosition(C.matrixWorld),W.color.copy(U).multiplyScalar(O),W.distance=V,W.coneCos=Math.cos(C.angle),W.penumbraCos=Math.cos(C.angle*(1-C.penumbra)),W.decay=C.decay,n.spot[_]=W;const j=C.shadow;if(C.map&&(n.spotLightMap[R]=C.map,R++,j.updateMatrices(C),C.castShadow&&T++),n.spotLightMatrix[_]=j.matrix,C.castShadow){const k=e.get(C);k.shadowIntensity=j.intensity,k.shadowBias=j.bias,k.shadowNormalBias=j.normalBias,k.shadowRadius=j.radius,k.shadowMapSize=j.mapSize,n.spotShadow[_]=k,n.spotShadowMap[_]=X,v++}_++}else if(C.isRectAreaLight){const W=t.get(C);W.color.copy(U).multiplyScalar(O),W.halfWidth.set(C.width*.5,0,0),W.halfHeight.set(0,C.height*.5,0),n.rectArea[m]=W,m++}else if(C.isPointLight){const W=t.get(C);if(W.color.copy(C.color).multiplyScalar(C.intensity),W.distance=C.distance,W.decay=C.decay,C.castShadow){const j=C.shadow,k=e.get(C);k.shadowIntensity=j.intensity,k.shadowBias=j.bias,k.shadowNormalBias=j.normalBias,k.shadowRadius=j.radius,k.shadowMapSize=j.mapSize,k.shadowCameraNear=j.camera.near,k.shadowCameraFar=j.camera.far,n.pointShadow[g]=k,n.pointShadowMap[g]=X,n.pointShadowMatrix[g]=C.shadow.matrix,y++}n.point[g]=W,g++}else if(C.isHemisphereLight){const W=t.get(C);W.skyColor.copy(C.color).multiplyScalar(O),W.groundColor.copy(C.groundColor).multiplyScalar(O),n.hemi[p]=W,p++}}m>0&&(r.has("OES_texture_float_linear")===!0?(n.rectAreaLTC1=ft.LTC_FLOAT_1,n.rectAreaLTC2=ft.LTC_FLOAT_2):(n.rectAreaLTC1=ft.LTC_HALF_1,n.rectAreaLTC2=ft.LTC_HALF_2)),n.ambient[0]=h,n.ambient[1]=u,n.ambient[2]=f;const P=n.hash;(P.directionalLength!==d||P.pointLength!==g||P.spotLength!==_||P.rectAreaLength!==m||P.hemiLength!==p||P.numDirectionalShadows!==x||P.numPointShadows!==y||P.numSpotShadows!==v||P.numSpotMaps!==R||P.numLightProbes!==E)&&(n.directional.length=d,n.spot.length=_,n.rectArea.length=m,n.point.length=g,n.hemi.length=p,n.directionalShadow.length=x,n.directionalShadowMap.length=x,n.pointShadow.length=y,n.pointShadowMap.length=y,n.spotShadow.length=v,n.spotShadowMap.length=v,n.directionalShadowMatrix.length=x,n.pointShadowMatrix.length=y,n.spotLightMatrix.length=v+R-T,n.spotLightMap.length=R,n.numSpotLightShadowsWithMaps=T,n.numLightProbes=E,P.directionalLength=d,P.pointLength=g,P.spotLength=_,P.rectAreaLength=m,P.hemiLength=p,P.numDirectionalShadows=x,P.numPointShadows=y,P.numSpotShadows=v,P.numSpotMaps=R,P.numLightProbes=E,n.version=gm++)}function l(c,h){let u=0,f=0,d=0,g=0,_=0;const m=h.matrixWorldInverse;for(let p=0,x=c.length;p<x;p++){const y=c[p];if(y.isDirectionalLight){const v=n.directional[u];v.direction.setFromMatrixPosition(y.matrixWorld),i.setFromMatrixPosition(y.target.matrixWorld),v.direction.sub(i),v.direction.transformDirection(m),u++}else if(y.isSpotLight){const v=n.spot[d];v.position.setFromMatrixPosition(y.matrixWorld),v.position.applyMatrix4(m),v.direction.setFromMatrixPosition(y.matrixWorld),i.setFromMatrixPosition(y.target.matrixWorld),v.direction.sub(i),v.direction.transformDirection(m),d++}else if(y.isRectAreaLight){const v=n.rectArea[g];v.position.setFromMatrixPosition(y.matrixWorld),v.position.applyMatrix4(m),a.identity(),s.copy(y.matrixWorld),s.premultiply(m),a.extractRotation(s),v.halfWidth.set(y.width*.5,0,0),v.halfHeight.set(0,y.height*.5,0),v.halfWidth.applyMatrix4(a),v.halfHeight.applyMatrix4(a),g++}else if(y.isPointLight){const v=n.point[f];v.position.setFromMatrixPosition(y.matrixWorld),v.position.applyMatrix4(m),f++}else if(y.isHemisphereLight){const v=n.hemi[_];v.direction.setFromMatrixPosition(y.matrixWorld),v.direction.transformDirection(m),_++}}}return{setup:o,setupView:l,state:n}}function hl(r){const t=new xm(r),e=[],n=[];function i(h){c.camera=h,e.length=0,n.length=0}function s(h){e.push(h)}function a(h){n.push(h)}function o(){t.setup(e)}function l(h){t.setupView(e,h)}const c={lightsArray:e,shadowsArray:n,camera:null,lights:t,transmissionRenderTarget:{}};return{init:i,state:c,setupLights:o,setupLightsView:l,pushLight:s,pushShadow:a}}function vm(r){let t=new WeakMap;function e(i,s=0){const a=t.get(i);let o;return a===void 0?(o=new hl(r),t.set(i,[o])):s>=a.length?(o=new hl(r),a.push(o)):o=a[s],o}function n(){t=new WeakMap}return{get:e,dispose:n}}class Mm extends hi{static get type(){return"MeshDepthMaterial"}constructor(t){super(),this.isMeshDepthMaterial=!0,this.depthPacking=eh,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(t)}copy(t){return super.copy(t),this.depthPacking=t.depthPacking,this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this}}class ym extends hi{static get type(){return"MeshDistanceMaterial"}constructor(t){super(),this.isMeshDistanceMaterial=!0,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(t)}copy(t){return super.copy(t),this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this}}const Sm=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,bm=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function wm(r,t,e){let n=new Ka;const i=new Bt,s=new Bt,a=new ge,o=new Mm({depthPacking:nh}),l=new ym,c={},h=e.maxTextureSize,u={[Bn]:Ne,[Ne]:Bn,[Ve]:Ve},f=new ye({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new Bt},radius:{value:4}},vertexShader:Sm,fragmentShader:bm}),d=f.clone();d.defines.HORIZONTAL_PASS=1;const g=new de;g.setAttribute("position",new xe(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const _=new ot(g,f),m=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=Ol;let p=this.type;this.render=function(T,E,P){if(m.enabled===!1||m.autoUpdate===!1&&m.needsUpdate===!1||T.length===0)return;const b=r.getRenderTarget(),M=r.getActiveCubeFace(),C=r.getActiveMipmapLevel(),U=r.state;U.setBlending(Sn),U.buffers.color.setClear(1,1,1,1),U.buffers.depth.setTest(!0),U.setScissorTest(!1);const O=p!==Mn&&this.type===Mn,V=p===Mn&&this.type!==Mn;for(let X=0,W=T.length;X<W;X++){const j=T[X],k=j.shadow;if(k===void 0){console.warn("THREE.WebGLShadowMap:",j,"has no shadow.");continue}if(k.autoUpdate===!1&&k.needsUpdate===!1)continue;i.copy(k.mapSize);const it=k.getFrameExtents();if(i.multiply(it),s.copy(k.mapSize),(i.x>h||i.y>h)&&(i.x>h&&(s.x=Math.floor(h/it.x),i.x=s.x*it.x,k.mapSize.x=s.x),i.y>h&&(s.y=Math.floor(h/it.y),i.y=s.y*it.y,k.mapSize.y=s.y)),k.map===null||O===!0||V===!0){const tt=this.type!==Mn?{minFilter:We,magFilter:We}:{};k.map!==null&&k.map.dispose(),k.map=new sn(i.x,i.y,tt),k.map.texture.name=j.name+".shadowMap",k.camera.updateProjectionMatrix()}r.setRenderTarget(k.map),r.clear();const q=k.getViewportCount();for(let tt=0;tt<q;tt++){const rt=k.getViewport(tt);a.set(s.x*rt.x,s.y*rt.y,s.x*rt.z,s.y*rt.w),U.viewport(a),k.updateMatrices(j,tt),n=k.getFrustum(),v(E,P,k.camera,j,this.type)}k.isPointLightShadow!==!0&&this.type===Mn&&x(k,P),k.needsUpdate=!1}p=this.type,m.needsUpdate=!1,r.setRenderTarget(b,M,C)};function x(T,E){const P=t.update(_);f.defines.VSM_SAMPLES!==T.blurSamples&&(f.defines.VSM_SAMPLES=T.blurSamples,d.defines.VSM_SAMPLES=T.blurSamples,f.needsUpdate=!0,d.needsUpdate=!0),T.mapPass===null&&(T.mapPass=new sn(i.x,i.y)),f.uniforms.shadow_pass.value=T.map.texture,f.uniforms.resolution.value=T.mapSize,f.uniforms.radius.value=T.radius,r.setRenderTarget(T.mapPass),r.clear(),r.renderBufferDirect(E,null,P,f,_,null),d.uniforms.shadow_pass.value=T.mapPass.texture,d.uniforms.resolution.value=T.mapSize,d.uniforms.radius.value=T.radius,r.setRenderTarget(T.map),r.clear(),r.renderBufferDirect(E,null,P,d,_,null)}function y(T,E,P,b){let M=null;const C=P.isPointLight===!0?T.customDistanceMaterial:T.customDepthMaterial;if(C!==void 0)M=C;else if(M=P.isPointLight===!0?l:o,r.localClippingEnabled&&E.clipShadows===!0&&Array.isArray(E.clippingPlanes)&&E.clippingPlanes.length!==0||E.displacementMap&&E.displacementScale!==0||E.alphaMap&&E.alphaTest>0||E.map&&E.alphaTest>0){const U=M.uuid,O=E.uuid;let V=c[U];V===void 0&&(V={},c[U]=V);let X=V[O];X===void 0&&(X=M.clone(),V[O]=X,E.addEventListener("dispose",R)),M=X}if(M.visible=E.visible,M.wireframe=E.wireframe,b===Mn?M.side=E.shadowSide!==null?E.shadowSide:E.side:M.side=E.shadowSide!==null?E.shadowSide:u[E.side],M.alphaMap=E.alphaMap,M.alphaTest=E.alphaTest,M.map=E.map,M.clipShadows=E.clipShadows,M.clippingPlanes=E.clippingPlanes,M.clipIntersection=E.clipIntersection,M.displacementMap=E.displacementMap,M.displacementScale=E.displacementScale,M.displacementBias=E.displacementBias,M.wireframeLinewidth=E.wireframeLinewidth,M.linewidth=E.linewidth,P.isPointLight===!0&&M.isMeshDistanceMaterial===!0){const U=r.properties.get(M);U.light=P}return M}function v(T,E,P,b,M){if(T.visible===!1)return;if(T.layers.test(E.layers)&&(T.isMesh||T.isLine||T.isPoints)&&(T.castShadow||T.receiveShadow&&M===Mn)&&(!T.frustumCulled||n.intersectsObject(T))){T.modelViewMatrix.multiplyMatrices(P.matrixWorldInverse,T.matrixWorld);const O=t.update(T),V=T.material;if(Array.isArray(V)){const X=O.groups;for(let W=0,j=X.length;W<j;W++){const k=X[W],it=V[k.materialIndex];if(it&&it.visible){const q=y(T,it,b,M);T.onBeforeShadow(r,T,E,P,O,q,k),r.renderBufferDirect(P,null,O,q,T,k),T.onAfterShadow(r,T,E,P,O,q,k)}}}else if(V.visible){const X=y(T,V,b,M);T.onBeforeShadow(r,T,E,P,O,X,null),r.renderBufferDirect(P,null,O,X,T,null),T.onAfterShadow(r,T,E,P,O,X,null)}}const U=T.children;for(let O=0,V=U.length;O<V;O++)v(U[O],E,P,b,M)}function R(T){T.target.removeEventListener("dispose",R);for(const P in c){const b=c[P],M=T.target.uuid;M in b&&(b[M].dispose(),delete b[M])}}}const Tm={[Qr]:ta,[ea]:sa,[na]:ra,[Ui]:ia,[ta]:Qr,[sa]:ea,[ra]:na,[ia]:Ui};function Em(r,t){function e(){let I=!1;const _t=new ge;let $=null;const Q=new ge(0,0,0,0);return{setMask:function(bt){$!==bt&&!I&&(r.colorMask(bt,bt,bt,bt),$=bt)},setLocked:function(bt){I=bt},setClear:function(bt,yt,Vt,pe,Ee){Ee===!0&&(bt*=pe,yt*=pe,Vt*=pe),_t.set(bt,yt,Vt,pe),Q.equals(_t)===!1&&(r.clearColor(bt,yt,Vt,pe),Q.copy(_t))},reset:function(){I=!1,$=null,Q.set(-1,0,0,0)}}}function n(){let I=!1,_t=!1,$=null,Q=null,bt=null;return{setReversed:function(yt){if(_t!==yt){const Vt=t.get("EXT_clip_control");_t?Vt.clipControlEXT(Vt.LOWER_LEFT_EXT,Vt.ZERO_TO_ONE_EXT):Vt.clipControlEXT(Vt.LOWER_LEFT_EXT,Vt.NEGATIVE_ONE_TO_ONE_EXT);const pe=bt;bt=null,this.setClear(pe)}_t=yt},getReversed:function(){return _t},setTest:function(yt){yt?at(r.DEPTH_TEST):wt(r.DEPTH_TEST)},setMask:function(yt){$!==yt&&!I&&(r.depthMask(yt),$=yt)},setFunc:function(yt){if(_t&&(yt=Tm[yt]),Q!==yt){switch(yt){case Qr:r.depthFunc(r.NEVER);break;case ta:r.depthFunc(r.ALWAYS);break;case ea:r.depthFunc(r.LESS);break;case Ui:r.depthFunc(r.LEQUAL);break;case na:r.depthFunc(r.EQUAL);break;case ia:r.depthFunc(r.GEQUAL);break;case sa:r.depthFunc(r.GREATER);break;case ra:r.depthFunc(r.NOTEQUAL);break;default:r.depthFunc(r.LEQUAL)}Q=yt}},setLocked:function(yt){I=yt},setClear:function(yt){bt!==yt&&(_t&&(yt=1-yt),r.clearDepth(yt),bt=yt)},reset:function(){I=!1,$=null,Q=null,bt=null,_t=!1}}}function i(){let I=!1,_t=null,$=null,Q=null,bt=null,yt=null,Vt=null,pe=null,Ee=null;return{setTest:function(ie){I||(ie?at(r.STENCIL_TEST):wt(r.STENCIL_TEST))},setMask:function(ie){_t!==ie&&!I&&(r.stencilMask(ie),_t=ie)},setFunc:function(ie,je,fn){($!==ie||Q!==je||bt!==fn)&&(r.stencilFunc(ie,je,fn),$=ie,Q=je,bt=fn)},setOp:function(ie,je,fn){(yt!==ie||Vt!==je||pe!==fn)&&(r.stencilOp(ie,je,fn),yt=ie,Vt=je,pe=fn)},setLocked:function(ie){I=ie},setClear:function(ie){Ee!==ie&&(r.clearStencil(ie),Ee=ie)},reset:function(){I=!1,_t=null,$=null,Q=null,bt=null,yt=null,Vt=null,pe=null,Ee=null}}}const s=new e,a=new n,o=new i,l=new WeakMap,c=new WeakMap;let h={},u={},f=new WeakMap,d=[],g=null,_=!1,m=null,p=null,x=null,y=null,v=null,R=null,T=null,E=new Pt(0,0,0),P=0,b=!1,M=null,C=null,U=null,O=null,V=null;const X=r.getParameter(r.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let W=!1,j=0;const k=r.getParameter(r.VERSION);k.indexOf("WebGL")!==-1?(j=parseFloat(/^WebGL (\d)/.exec(k)[1]),W=j>=1):k.indexOf("OpenGL ES")!==-1&&(j=parseFloat(/^OpenGL ES (\d)/.exec(k)[1]),W=j>=2);let it=null,q={};const tt=r.getParameter(r.SCISSOR_BOX),rt=r.getParameter(r.VIEWPORT),ut=new ge().fromArray(tt),B=new ge().fromArray(rt);function J(I,_t,$,Q){const bt=new Uint8Array(4),yt=r.createTexture();r.bindTexture(I,yt),r.texParameteri(I,r.TEXTURE_MIN_FILTER,r.NEAREST),r.texParameteri(I,r.TEXTURE_MAG_FILTER,r.NEAREST);for(let Vt=0;Vt<$;Vt++)I===r.TEXTURE_3D||I===r.TEXTURE_2D_ARRAY?r.texImage3D(_t,0,r.RGBA,1,1,Q,0,r.RGBA,r.UNSIGNED_BYTE,bt):r.texImage2D(_t+Vt,0,r.RGBA,1,1,0,r.RGBA,r.UNSIGNED_BYTE,bt);return yt}const ht={};ht[r.TEXTURE_2D]=J(r.TEXTURE_2D,r.TEXTURE_2D,1),ht[r.TEXTURE_CUBE_MAP]=J(r.TEXTURE_CUBE_MAP,r.TEXTURE_CUBE_MAP_POSITIVE_X,6),ht[r.TEXTURE_2D_ARRAY]=J(r.TEXTURE_2D_ARRAY,r.TEXTURE_2D_ARRAY,1,1),ht[r.TEXTURE_3D]=J(r.TEXTURE_3D,r.TEXTURE_3D,1,1),s.setClear(0,0,0,1),a.setClear(1),o.setClear(0),at(r.DEPTH_TEST),a.setFunc(Ui),Ot(!1),It(mo),at(r.CULL_FACE),L(Sn);function at(I){h[I]!==!0&&(r.enable(I),h[I]=!0)}function wt(I){h[I]!==!1&&(r.disable(I),h[I]=!1)}function xt(I,_t){return u[I]!==_t?(r.bindFramebuffer(I,_t),u[I]=_t,I===r.DRAW_FRAMEBUFFER&&(u[r.FRAMEBUFFER]=_t),I===r.FRAMEBUFFER&&(u[r.DRAW_FRAMEBUFFER]=_t),!0):!1}function Y(I,_t){let $=d,Q=!1;if(I){$=f.get(_t),$===void 0&&($=[],f.set(_t,$));const bt=I.textures;if($.length!==bt.length||$[0]!==r.COLOR_ATTACHMENT0){for(let yt=0,Vt=bt.length;yt<Vt;yt++)$[yt]=r.COLOR_ATTACHMENT0+yt;$.length=bt.length,Q=!0}}else $[0]!==r.BACK&&($[0]=r.BACK,Q=!0);Q&&r.drawBuffers($)}function et(I){return g!==I?(r.useProgram(I),g=I,!0):!1}const dt={[Qn]:r.FUNC_ADD,[Uc]:r.FUNC_SUBTRACT,[Nc]:r.FUNC_REVERSE_SUBTRACT};dt[Fc]=r.MIN,dt[Oc]=r.MAX;const zt={[zc]:r.ZERO,[kc]:r.ONE,[Bc]:r.SRC_COLOR,[Zr]:r.SRC_ALPHA,[qc]:r.SRC_ALPHA_SATURATE,[Wc]:r.DST_COLOR,[Hc]:r.DST_ALPHA,[Gc]:r.ONE_MINUS_SRC_COLOR,[Jr]:r.ONE_MINUS_SRC_ALPHA,[Xc]:r.ONE_MINUS_DST_COLOR,[Vc]:r.ONE_MINUS_DST_ALPHA,[$c]:r.CONSTANT_COLOR,[Yc]:r.ONE_MINUS_CONSTANT_COLOR,[jc]:r.CONSTANT_ALPHA,[Kc]:r.ONE_MINUS_CONSTANT_ALPHA};function L(I,_t,$,Q,bt,yt,Vt,pe,Ee,ie){if(I===Sn){_===!0&&(wt(r.BLEND),_=!1);return}if(_===!1&&(at(r.BLEND),_=!0),I!==Ic){if(I!==m||ie!==b){if((p!==Qn||v!==Qn)&&(r.blendEquation(r.FUNC_ADD),p=Qn,v=Qn),ie)switch(I){case ri:r.blendFuncSeparate(r.ONE,r.ONE_MINUS_SRC_ALPHA,r.ONE,r.ONE_MINUS_SRC_ALPHA);break;case Ii:r.blendFunc(r.ONE,r.ONE);break;case go:r.blendFuncSeparate(r.ZERO,r.ONE_MINUS_SRC_COLOR,r.ZERO,r.ONE);break;case _o:r.blendFuncSeparate(r.ZERO,r.SRC_COLOR,r.ZERO,r.SRC_ALPHA);break;default:console.error("THREE.WebGLState: Invalid blending: ",I);break}else switch(I){case ri:r.blendFuncSeparate(r.SRC_ALPHA,r.ONE_MINUS_SRC_ALPHA,r.ONE,r.ONE_MINUS_SRC_ALPHA);break;case Ii:r.blendFunc(r.SRC_ALPHA,r.ONE);break;case go:r.blendFuncSeparate(r.ZERO,r.ONE_MINUS_SRC_COLOR,r.ZERO,r.ONE);break;case _o:r.blendFunc(r.ZERO,r.SRC_COLOR);break;default:console.error("THREE.WebGLState: Invalid blending: ",I);break}x=null,y=null,R=null,T=null,E.set(0,0,0),P=0,m=I,b=ie}return}bt=bt||_t,yt=yt||$,Vt=Vt||Q,(_t!==p||bt!==v)&&(r.blendEquationSeparate(dt[_t],dt[bt]),p=_t,v=bt),($!==x||Q!==y||yt!==R||Vt!==T)&&(r.blendFuncSeparate(zt[$],zt[Q],zt[yt],zt[Vt]),x=$,y=Q,R=yt,T=Vt),(pe.equals(E)===!1||Ee!==P)&&(r.blendColor(pe.r,pe.g,pe.b,Ee),E.copy(pe),P=Ee),m=I,b=!1}function Qt(I,_t){I.side===Ve?wt(r.CULL_FACE):at(r.CULL_FACE);let $=I.side===Ne;_t&&($=!$),Ot($),I.blending===ri&&I.transparent===!1?L(Sn):L(I.blending,I.blendEquation,I.blendSrc,I.blendDst,I.blendEquationAlpha,I.blendSrcAlpha,I.blendDstAlpha,I.blendColor,I.blendAlpha,I.premultipliedAlpha),a.setFunc(I.depthFunc),a.setTest(I.depthTest),a.setMask(I.depthWrite),s.setMask(I.colorWrite);const Q=I.stencilWrite;o.setTest(Q),Q&&(o.setMask(I.stencilWriteMask),o.setFunc(I.stencilFunc,I.stencilRef,I.stencilFuncMask),o.setOp(I.stencilFail,I.stencilZFail,I.stencilZPass)),te(I.polygonOffset,I.polygonOffsetFactor,I.polygonOffsetUnits),I.alphaToCoverage===!0?at(r.SAMPLE_ALPHA_TO_COVERAGE):wt(r.SAMPLE_ALPHA_TO_COVERAGE)}function Ot(I){M!==I&&(I?r.frontFace(r.CW):r.frontFace(r.CCW),M=I)}function It(I){I!==Lc?(at(r.CULL_FACE),I!==C&&(I===mo?r.cullFace(r.BACK):I===Dc?r.cullFace(r.FRONT):r.cullFace(r.FRONT_AND_BACK))):wt(r.CULL_FACE),C=I}function Tt(I){I!==U&&(W&&r.lineWidth(I),U=I)}function te(I,_t,$){I?(at(r.POLYGON_OFFSET_FILL),(O!==_t||V!==$)&&(r.polygonOffset(_t,$),O=_t,V=$)):wt(r.POLYGON_OFFSET_FILL)}function Dt(I){I?at(r.SCISSOR_TEST):wt(r.SCISSOR_TEST)}function A(I){I===void 0&&(I=r.TEXTURE0+X-1),it!==I&&(r.activeTexture(I),it=I)}function S(I,_t,$){$===void 0&&(it===null?$=r.TEXTURE0+X-1:$=it);let Q=q[$];Q===void 0&&(Q={type:void 0,texture:void 0},q[$]=Q),(Q.type!==I||Q.texture!==_t)&&(it!==$&&(r.activeTexture($),it=$),r.bindTexture(I,_t||ht[I]),Q.type=I,Q.texture=_t)}function z(){const I=q[it];I!==void 0&&I.type!==void 0&&(r.bindTexture(I.type,null),I.type=void 0,I.texture=void 0)}function Z(){try{r.compressedTexImage2D.apply(r,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function nt(){try{r.compressedTexImage3D.apply(r,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function K(){try{r.texSubImage2D.apply(r,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function Et(){try{r.texSubImage3D.apply(r,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function mt(){try{r.compressedTexSubImage2D.apply(r,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function vt(){try{r.compressedTexSubImage3D.apply(r,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function kt(){try{r.texStorage2D.apply(r,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function st(){try{r.texStorage3D.apply(r,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function gt(){try{r.texImage2D.apply(r,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function Ut(){try{r.texImage3D.apply(r,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function Nt(I){ut.equals(I)===!1&&(r.scissor(I.x,I.y,I.z,I.w),ut.copy(I))}function Mt(I){B.equals(I)===!1&&(r.viewport(I.x,I.y,I.z,I.w),B.copy(I))}function Yt(I,_t){let $=c.get(_t);$===void 0&&($=new WeakMap,c.set(_t,$));let Q=$.get(I);Q===void 0&&(Q=r.getUniformBlockIndex(_t,I.name),$.set(I,Q))}function qt(I,_t){const Q=c.get(_t).get(I);l.get(_t)!==Q&&(r.uniformBlockBinding(_t,Q,I.__bindingPointIndex),l.set(_t,Q))}function oe(){r.disable(r.BLEND),r.disable(r.CULL_FACE),r.disable(r.DEPTH_TEST),r.disable(r.POLYGON_OFFSET_FILL),r.disable(r.SCISSOR_TEST),r.disable(r.STENCIL_TEST),r.disable(r.SAMPLE_ALPHA_TO_COVERAGE),r.blendEquation(r.FUNC_ADD),r.blendFunc(r.ONE,r.ZERO),r.blendFuncSeparate(r.ONE,r.ZERO,r.ONE,r.ZERO),r.blendColor(0,0,0,0),r.colorMask(!0,!0,!0,!0),r.clearColor(0,0,0,0),r.depthMask(!0),r.depthFunc(r.LESS),a.setReversed(!1),r.clearDepth(1),r.stencilMask(4294967295),r.stencilFunc(r.ALWAYS,0,4294967295),r.stencilOp(r.KEEP,r.KEEP,r.KEEP),r.clearStencil(0),r.cullFace(r.BACK),r.frontFace(r.CCW),r.polygonOffset(0,0),r.activeTexture(r.TEXTURE0),r.bindFramebuffer(r.FRAMEBUFFER,null),r.bindFramebuffer(r.DRAW_FRAMEBUFFER,null),r.bindFramebuffer(r.READ_FRAMEBUFFER,null),r.useProgram(null),r.lineWidth(1),r.scissor(0,0,r.canvas.width,r.canvas.height),r.viewport(0,0,r.canvas.width,r.canvas.height),h={},it=null,q={},u={},f=new WeakMap,d=[],g=null,_=!1,m=null,p=null,x=null,y=null,v=null,R=null,T=null,E=new Pt(0,0,0),P=0,b=!1,M=null,C=null,U=null,O=null,V=null,ut.set(0,0,r.canvas.width,r.canvas.height),B.set(0,0,r.canvas.width,r.canvas.height),s.reset(),a.reset(),o.reset()}return{buffers:{color:s,depth:a,stencil:o},enable:at,disable:wt,bindFramebuffer:xt,drawBuffers:Y,useProgram:et,setBlending:L,setMaterial:Qt,setFlipSided:Ot,setCullFace:It,setLineWidth:Tt,setPolygonOffset:te,setScissorTest:Dt,activeTexture:A,bindTexture:S,unbindTexture:z,compressedTexImage2D:Z,compressedTexImage3D:nt,texImage2D:gt,texImage3D:Ut,updateUBOMapping:Yt,uniformBlockBinding:qt,texStorage2D:kt,texStorage3D:st,texSubImage2D:K,texSubImage3D:Et,compressedTexSubImage2D:mt,compressedTexSubImage3D:vt,scissor:Nt,viewport:Mt,reset:oe}}function ul(r,t,e,n){const i=Am(n);switch(e){case jl:return r*t;case Zl:return r*t;case Jl:return r*t*2;case Wa:return r*t/i.components*i.byteLength;case Xa:return r*t/i.components*i.byteLength;case Ql:return r*t*2/i.components*i.byteLength;case qa:return r*t*2/i.components*i.byteLength;case Kl:return r*t*3/i.components*i.byteLength;case nn:return r*t*4/i.components*i.byteLength;case $a:return r*t*4/i.components*i.byteLength;case Ws:case Xs:return Math.floor((r+3)/4)*Math.floor((t+3)/4)*8;case qs:case $s:return Math.floor((r+3)/4)*Math.floor((t+3)/4)*16;case ha:case fa:return Math.max(r,16)*Math.max(t,8)/4;case ca:case ua:return Math.max(r,8)*Math.max(t,8)/2;case da:case pa:return Math.floor((r+3)/4)*Math.floor((t+3)/4)*8;case ma:return Math.floor((r+3)/4)*Math.floor((t+3)/4)*16;case ga:return Math.floor((r+3)/4)*Math.floor((t+3)/4)*16;case _a:return Math.floor((r+4)/5)*Math.floor((t+3)/4)*16;case xa:return Math.floor((r+4)/5)*Math.floor((t+4)/5)*16;case va:return Math.floor((r+5)/6)*Math.floor((t+4)/5)*16;case Ma:return Math.floor((r+5)/6)*Math.floor((t+5)/6)*16;case ya:return Math.floor((r+7)/8)*Math.floor((t+4)/5)*16;case Sa:return Math.floor((r+7)/8)*Math.floor((t+5)/6)*16;case ba:return Math.floor((r+7)/8)*Math.floor((t+7)/8)*16;case wa:return Math.floor((r+9)/10)*Math.floor((t+4)/5)*16;case Ta:return Math.floor((r+9)/10)*Math.floor((t+5)/6)*16;case Ea:return Math.floor((r+9)/10)*Math.floor((t+7)/8)*16;case Aa:return Math.floor((r+9)/10)*Math.floor((t+9)/10)*16;case Ra:return Math.floor((r+11)/12)*Math.floor((t+9)/10)*16;case Ca:return Math.floor((r+11)/12)*Math.floor((t+11)/12)*16;case Ys:case Pa:case La:return Math.ceil(r/4)*Math.ceil(t/4)*16;case tc:case Da:return Math.ceil(r/4)*Math.ceil(t/4)*8;case Ia:case Ua:return Math.ceil(r/4)*Math.ceil(t/4)*16}throw new Error(`Unable to determine texture byte length for ${e} format.`)}function Am(r){switch(r){case Tn:case ql:return{byteLength:1,components:1};case hs:case $l:case bn:return{byteLength:2,components:1};case Ha:case Va:return{byteLength:2,components:4};case ai:case Ga:case hn:return{byteLength:4,components:1};case Yl:return{byteLength:4,components:3}}throw new Error(`Unknown texture type ${r}.`)}function Rm(r,t,e,n,i,s,a){const o=t.has("WEBGL_multisampled_render_to_texture")?t.get("WEBGL_multisampled_render_to_texture"):null,l=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),c=new Bt,h=new WeakMap;let u;const f=new WeakMap;let d=!1;try{d=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function g(A,S){return d?new OffscreenCanvas(A,S):Qs("canvas")}function _(A,S,z){let Z=1;const nt=Dt(A);if((nt.width>z||nt.height>z)&&(Z=z/Math.max(nt.width,nt.height)),Z<1)if(typeof HTMLImageElement<"u"&&A instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&A instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&A instanceof ImageBitmap||typeof VideoFrame<"u"&&A instanceof VideoFrame){const K=Math.floor(Z*nt.width),Et=Math.floor(Z*nt.height);u===void 0&&(u=g(K,Et));const mt=S?g(K,Et):u;return mt.width=K,mt.height=Et,mt.getContext("2d").drawImage(A,0,0,K,Et),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+nt.width+"x"+nt.height+") to ("+K+"x"+Et+")."),mt}else return"data"in A&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+nt.width+"x"+nt.height+")."),A;return A}function m(A){return A.generateMipmaps}function p(A){r.generateMipmap(A)}function x(A){return A.isWebGLCubeRenderTarget?r.TEXTURE_CUBE_MAP:A.isWebGL3DRenderTarget?r.TEXTURE_3D:A.isWebGLArrayRenderTarget||A.isCompressedArrayTexture?r.TEXTURE_2D_ARRAY:r.TEXTURE_2D}function y(A,S,z,Z,nt=!1){if(A!==null){if(r[A]!==void 0)return r[A];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+A+"'")}let K=S;if(S===r.RED&&(z===r.FLOAT&&(K=r.R32F),z===r.HALF_FLOAT&&(K=r.R16F),z===r.UNSIGNED_BYTE&&(K=r.R8)),S===r.RED_INTEGER&&(z===r.UNSIGNED_BYTE&&(K=r.R8UI),z===r.UNSIGNED_SHORT&&(K=r.R16UI),z===r.UNSIGNED_INT&&(K=r.R32UI),z===r.BYTE&&(K=r.R8I),z===r.SHORT&&(K=r.R16I),z===r.INT&&(K=r.R32I)),S===r.RG&&(z===r.FLOAT&&(K=r.RG32F),z===r.HALF_FLOAT&&(K=r.RG16F),z===r.UNSIGNED_BYTE&&(K=r.RG8)),S===r.RG_INTEGER&&(z===r.UNSIGNED_BYTE&&(K=r.RG8UI),z===r.UNSIGNED_SHORT&&(K=r.RG16UI),z===r.UNSIGNED_INT&&(K=r.RG32UI),z===r.BYTE&&(K=r.RG8I),z===r.SHORT&&(K=r.RG16I),z===r.INT&&(K=r.RG32I)),S===r.RGB_INTEGER&&(z===r.UNSIGNED_BYTE&&(K=r.RGB8UI),z===r.UNSIGNED_SHORT&&(K=r.RGB16UI),z===r.UNSIGNED_INT&&(K=r.RGB32UI),z===r.BYTE&&(K=r.RGB8I),z===r.SHORT&&(K=r.RGB16I),z===r.INT&&(K=r.RGB32I)),S===r.RGBA_INTEGER&&(z===r.UNSIGNED_BYTE&&(K=r.RGBA8UI),z===r.UNSIGNED_SHORT&&(K=r.RGBA16UI),z===r.UNSIGNED_INT&&(K=r.RGBA32UI),z===r.BYTE&&(K=r.RGBA8I),z===r.SHORT&&(K=r.RGBA16I),z===r.INT&&(K=r.RGBA32I)),S===r.RGB&&z===r.UNSIGNED_INT_5_9_9_9_REV&&(K=r.RGB9_E5),S===r.RGBA){const Et=nt?ar:jt.getTransfer(Z);z===r.FLOAT&&(K=r.RGBA32F),z===r.HALF_FLOAT&&(K=r.RGBA16F),z===r.UNSIGNED_BYTE&&(K=Et===se?r.SRGB8_ALPHA8:r.RGBA8),z===r.UNSIGNED_SHORT_4_4_4_4&&(K=r.RGBA4),z===r.UNSIGNED_SHORT_5_5_5_1&&(K=r.RGB5_A1)}return(K===r.R16F||K===r.R32F||K===r.RG16F||K===r.RG32F||K===r.RGBA16F||K===r.RGBA32F)&&t.get("EXT_color_buffer_float"),K}function v(A,S){let z;return A?S===null||S===ai||S===Oi?z=r.DEPTH24_STENCIL8:S===hn?z=r.DEPTH32F_STENCIL8:S===hs&&(z=r.DEPTH24_STENCIL8,console.warn("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):S===null||S===ai||S===Oi?z=r.DEPTH_COMPONENT24:S===hn?z=r.DEPTH_COMPONENT32F:S===hs&&(z=r.DEPTH_COMPONENT16),z}function R(A,S){return m(A)===!0||A.isFramebufferTexture&&A.minFilter!==We&&A.minFilter!==cn?Math.log2(Math.max(S.width,S.height))+1:A.mipmaps!==void 0&&A.mipmaps.length>0?A.mipmaps.length:A.isCompressedTexture&&Array.isArray(A.image)?S.mipmaps.length:1}function T(A){const S=A.target;S.removeEventListener("dispose",T),P(S),S.isVideoTexture&&h.delete(S)}function E(A){const S=A.target;S.removeEventListener("dispose",E),M(S)}function P(A){const S=n.get(A);if(S.__webglInit===void 0)return;const z=A.source,Z=f.get(z);if(Z){const nt=Z[S.__cacheKey];nt.usedTimes--,nt.usedTimes===0&&b(A),Object.keys(Z).length===0&&f.delete(z)}n.remove(A)}function b(A){const S=n.get(A);r.deleteTexture(S.__webglTexture);const z=A.source,Z=f.get(z);delete Z[S.__cacheKey],a.memory.textures--}function M(A){const S=n.get(A);if(A.depthTexture&&(A.depthTexture.dispose(),n.remove(A.depthTexture)),A.isWebGLCubeRenderTarget)for(let Z=0;Z<6;Z++){if(Array.isArray(S.__webglFramebuffer[Z]))for(let nt=0;nt<S.__webglFramebuffer[Z].length;nt++)r.deleteFramebuffer(S.__webglFramebuffer[Z][nt]);else r.deleteFramebuffer(S.__webglFramebuffer[Z]);S.__webglDepthbuffer&&r.deleteRenderbuffer(S.__webglDepthbuffer[Z])}else{if(Array.isArray(S.__webglFramebuffer))for(let Z=0;Z<S.__webglFramebuffer.length;Z++)r.deleteFramebuffer(S.__webglFramebuffer[Z]);else r.deleteFramebuffer(S.__webglFramebuffer);if(S.__webglDepthbuffer&&r.deleteRenderbuffer(S.__webglDepthbuffer),S.__webglMultisampledFramebuffer&&r.deleteFramebuffer(S.__webglMultisampledFramebuffer),S.__webglColorRenderbuffer)for(let Z=0;Z<S.__webglColorRenderbuffer.length;Z++)S.__webglColorRenderbuffer[Z]&&r.deleteRenderbuffer(S.__webglColorRenderbuffer[Z]);S.__webglDepthRenderbuffer&&r.deleteRenderbuffer(S.__webglDepthRenderbuffer)}const z=A.textures;for(let Z=0,nt=z.length;Z<nt;Z++){const K=n.get(z[Z]);K.__webglTexture&&(r.deleteTexture(K.__webglTexture),a.memory.textures--),n.remove(z[Z])}n.remove(A)}let C=0;function U(){C=0}function O(){const A=C;return A>=i.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+A+" texture units while this GPU supports only "+i.maxTextures),C+=1,A}function V(A){const S=[];return S.push(A.wrapS),S.push(A.wrapT),S.push(A.wrapR||0),S.push(A.magFilter),S.push(A.minFilter),S.push(A.anisotropy),S.push(A.internalFormat),S.push(A.format),S.push(A.type),S.push(A.generateMipmaps),S.push(A.premultiplyAlpha),S.push(A.flipY),S.push(A.unpackAlignment),S.push(A.colorSpace),S.join()}function X(A,S){const z=n.get(A);if(A.isVideoTexture&&Tt(A),A.isRenderTargetTexture===!1&&A.version>0&&z.__version!==A.version){const Z=A.image;if(Z===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(Z.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{B(z,A,S);return}}e.bindTexture(r.TEXTURE_2D,z.__webglTexture,r.TEXTURE0+S)}function W(A,S){const z=n.get(A);if(A.version>0&&z.__version!==A.version){B(z,A,S);return}e.bindTexture(r.TEXTURE_2D_ARRAY,z.__webglTexture,r.TEXTURE0+S)}function j(A,S){const z=n.get(A);if(A.version>0&&z.__version!==A.version){B(z,A,S);return}e.bindTexture(r.TEXTURE_3D,z.__webglTexture,r.TEXTURE0+S)}function k(A,S){const z=n.get(A);if(A.version>0&&z.__version!==A.version){J(z,A,S);return}e.bindTexture(r.TEXTURE_CUBE_MAP,z.__webglTexture,r.TEXTURE0+S)}const it={[Zs]:r.REPEAT,[ni]:r.CLAMP_TO_EDGE,[la]:r.MIRRORED_REPEAT},q={[We]:r.NEAREST,[th]:r.NEAREST_MIPMAP_NEAREST,[ps]:r.NEAREST_MIPMAP_LINEAR,[cn]:r.LINEAR,[hr]:r.LINEAR_MIPMAP_NEAREST,[ii]:r.LINEAR_MIPMAP_LINEAR},tt={[sh]:r.NEVER,[hh]:r.ALWAYS,[rh]:r.LESS,[nc]:r.LEQUAL,[ah]:r.EQUAL,[ch]:r.GEQUAL,[oh]:r.GREATER,[lh]:r.NOTEQUAL};function rt(A,S){if(S.type===hn&&t.has("OES_texture_float_linear")===!1&&(S.magFilter===cn||S.magFilter===hr||S.magFilter===ps||S.magFilter===ii||S.minFilter===cn||S.minFilter===hr||S.minFilter===ps||S.minFilter===ii)&&console.warn("THREE.WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),r.texParameteri(A,r.TEXTURE_WRAP_S,it[S.wrapS]),r.texParameteri(A,r.TEXTURE_WRAP_T,it[S.wrapT]),(A===r.TEXTURE_3D||A===r.TEXTURE_2D_ARRAY)&&r.texParameteri(A,r.TEXTURE_WRAP_R,it[S.wrapR]),r.texParameteri(A,r.TEXTURE_MAG_FILTER,q[S.magFilter]),r.texParameteri(A,r.TEXTURE_MIN_FILTER,q[S.minFilter]),S.compareFunction&&(r.texParameteri(A,r.TEXTURE_COMPARE_MODE,r.COMPARE_REF_TO_TEXTURE),r.texParameteri(A,r.TEXTURE_COMPARE_FUNC,tt[S.compareFunction])),t.has("EXT_texture_filter_anisotropic")===!0){if(S.magFilter===We||S.minFilter!==ps&&S.minFilter!==ii||S.type===hn&&t.has("OES_texture_float_linear")===!1)return;if(S.anisotropy>1||n.get(S).__currentAnisotropy){const z=t.get("EXT_texture_filter_anisotropic");r.texParameterf(A,z.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(S.anisotropy,i.getMaxAnisotropy())),n.get(S).__currentAnisotropy=S.anisotropy}}}function ut(A,S){let z=!1;A.__webglInit===void 0&&(A.__webglInit=!0,S.addEventListener("dispose",T));const Z=S.source;let nt=f.get(Z);nt===void 0&&(nt={},f.set(Z,nt));const K=V(S);if(K!==A.__cacheKey){nt[K]===void 0&&(nt[K]={texture:r.createTexture(),usedTimes:0},a.memory.textures++,z=!0),nt[K].usedTimes++;const Et=nt[A.__cacheKey];Et!==void 0&&(nt[A.__cacheKey].usedTimes--,Et.usedTimes===0&&b(S)),A.__cacheKey=K,A.__webglTexture=nt[K].texture}return z}function B(A,S,z){let Z=r.TEXTURE_2D;(S.isDataArrayTexture||S.isCompressedArrayTexture)&&(Z=r.TEXTURE_2D_ARRAY),S.isData3DTexture&&(Z=r.TEXTURE_3D);const nt=ut(A,S),K=S.source;e.bindTexture(Z,A.__webglTexture,r.TEXTURE0+z);const Et=n.get(K);if(K.version!==Et.__version||nt===!0){e.activeTexture(r.TEXTURE0+z);const mt=jt.getPrimaries(jt.workingColorSpace),vt=S.colorSpace===On?null:jt.getPrimaries(S.colorSpace),kt=S.colorSpace===On||mt===vt?r.NONE:r.BROWSER_DEFAULT_WEBGL;r.pixelStorei(r.UNPACK_FLIP_Y_WEBGL,S.flipY),r.pixelStorei(r.UNPACK_PREMULTIPLY_ALPHA_WEBGL,S.premultiplyAlpha),r.pixelStorei(r.UNPACK_ALIGNMENT,S.unpackAlignment),r.pixelStorei(r.UNPACK_COLORSPACE_CONVERSION_WEBGL,kt);let st=_(S.image,!1,i.maxTextureSize);st=te(S,st);const gt=s.convert(S.format,S.colorSpace),Ut=s.convert(S.type);let Nt=y(S.internalFormat,gt,Ut,S.colorSpace,S.isVideoTexture);rt(Z,S);let Mt;const Yt=S.mipmaps,qt=S.isVideoTexture!==!0,oe=Et.__version===void 0||nt===!0,I=K.dataReady,_t=R(S,st);if(S.isDepthTexture)Nt=v(S.format===zi,S.type),oe&&(qt?e.texStorage2D(r.TEXTURE_2D,1,Nt,st.width,st.height):e.texImage2D(r.TEXTURE_2D,0,Nt,st.width,st.height,0,gt,Ut,null));else if(S.isDataTexture)if(Yt.length>0){qt&&oe&&e.texStorage2D(r.TEXTURE_2D,_t,Nt,Yt[0].width,Yt[0].height);for(let $=0,Q=Yt.length;$<Q;$++)Mt=Yt[$],qt?I&&e.texSubImage2D(r.TEXTURE_2D,$,0,0,Mt.width,Mt.height,gt,Ut,Mt.data):e.texImage2D(r.TEXTURE_2D,$,Nt,Mt.width,Mt.height,0,gt,Ut,Mt.data);S.generateMipmaps=!1}else qt?(oe&&e.texStorage2D(r.TEXTURE_2D,_t,Nt,st.width,st.height),I&&e.texSubImage2D(r.TEXTURE_2D,0,0,0,st.width,st.height,gt,Ut,st.data)):e.texImage2D(r.TEXTURE_2D,0,Nt,st.width,st.height,0,gt,Ut,st.data);else if(S.isCompressedTexture)if(S.isCompressedArrayTexture){qt&&oe&&e.texStorage3D(r.TEXTURE_2D_ARRAY,_t,Nt,Yt[0].width,Yt[0].height,st.depth);for(let $=0,Q=Yt.length;$<Q;$++)if(Mt=Yt[$],S.format!==nn)if(gt!==null)if(qt){if(I)if(S.layerUpdates.size>0){const bt=ul(Mt.width,Mt.height,S.format,S.type);for(const yt of S.layerUpdates){const Vt=Mt.data.subarray(yt*bt/Mt.data.BYTES_PER_ELEMENT,(yt+1)*bt/Mt.data.BYTES_PER_ELEMENT);e.compressedTexSubImage3D(r.TEXTURE_2D_ARRAY,$,0,0,yt,Mt.width,Mt.height,1,gt,Vt)}S.clearLayerUpdates()}else e.compressedTexSubImage3D(r.TEXTURE_2D_ARRAY,$,0,0,0,Mt.width,Mt.height,st.depth,gt,Mt.data)}else e.compressedTexImage3D(r.TEXTURE_2D_ARRAY,$,Nt,Mt.width,Mt.height,st.depth,0,Mt.data,0,0);else console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else qt?I&&e.texSubImage3D(r.TEXTURE_2D_ARRAY,$,0,0,0,Mt.width,Mt.height,st.depth,gt,Ut,Mt.data):e.texImage3D(r.TEXTURE_2D_ARRAY,$,Nt,Mt.width,Mt.height,st.depth,0,gt,Ut,Mt.data)}else{qt&&oe&&e.texStorage2D(r.TEXTURE_2D,_t,Nt,Yt[0].width,Yt[0].height);for(let $=0,Q=Yt.length;$<Q;$++)Mt=Yt[$],S.format!==nn?gt!==null?qt?I&&e.compressedTexSubImage2D(r.TEXTURE_2D,$,0,0,Mt.width,Mt.height,gt,Mt.data):e.compressedTexImage2D(r.TEXTURE_2D,$,Nt,Mt.width,Mt.height,0,Mt.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):qt?I&&e.texSubImage2D(r.TEXTURE_2D,$,0,0,Mt.width,Mt.height,gt,Ut,Mt.data):e.texImage2D(r.TEXTURE_2D,$,Nt,Mt.width,Mt.height,0,gt,Ut,Mt.data)}else if(S.isDataArrayTexture)if(qt){if(oe&&e.texStorage3D(r.TEXTURE_2D_ARRAY,_t,Nt,st.width,st.height,st.depth),I)if(S.layerUpdates.size>0){const $=ul(st.width,st.height,S.format,S.type);for(const Q of S.layerUpdates){const bt=st.data.subarray(Q*$/st.data.BYTES_PER_ELEMENT,(Q+1)*$/st.data.BYTES_PER_ELEMENT);e.texSubImage3D(r.TEXTURE_2D_ARRAY,0,0,0,Q,st.width,st.height,1,gt,Ut,bt)}S.clearLayerUpdates()}else e.texSubImage3D(r.TEXTURE_2D_ARRAY,0,0,0,0,st.width,st.height,st.depth,gt,Ut,st.data)}else e.texImage3D(r.TEXTURE_2D_ARRAY,0,Nt,st.width,st.height,st.depth,0,gt,Ut,st.data);else if(S.isData3DTexture)qt?(oe&&e.texStorage3D(r.TEXTURE_3D,_t,Nt,st.width,st.height,st.depth),I&&e.texSubImage3D(r.TEXTURE_3D,0,0,0,0,st.width,st.height,st.depth,gt,Ut,st.data)):e.texImage3D(r.TEXTURE_3D,0,Nt,st.width,st.height,st.depth,0,gt,Ut,st.data);else if(S.isFramebufferTexture){if(oe)if(qt)e.texStorage2D(r.TEXTURE_2D,_t,Nt,st.width,st.height);else{let $=st.width,Q=st.height;for(let bt=0;bt<_t;bt++)e.texImage2D(r.TEXTURE_2D,bt,Nt,$,Q,0,gt,Ut,null),$>>=1,Q>>=1}}else if(Yt.length>0){if(qt&&oe){const $=Dt(Yt[0]);e.texStorage2D(r.TEXTURE_2D,_t,Nt,$.width,$.height)}for(let $=0,Q=Yt.length;$<Q;$++)Mt=Yt[$],qt?I&&e.texSubImage2D(r.TEXTURE_2D,$,0,0,gt,Ut,Mt):e.texImage2D(r.TEXTURE_2D,$,Nt,gt,Ut,Mt);S.generateMipmaps=!1}else if(qt){if(oe){const $=Dt(st);e.texStorage2D(r.TEXTURE_2D,_t,Nt,$.width,$.height)}I&&e.texSubImage2D(r.TEXTURE_2D,0,0,0,gt,Ut,st)}else e.texImage2D(r.TEXTURE_2D,0,Nt,gt,Ut,st);m(S)&&p(Z),Et.__version=K.version,S.onUpdate&&S.onUpdate(S)}A.__version=S.version}function J(A,S,z){if(S.image.length!==6)return;const Z=ut(A,S),nt=S.source;e.bindTexture(r.TEXTURE_CUBE_MAP,A.__webglTexture,r.TEXTURE0+z);const K=n.get(nt);if(nt.version!==K.__version||Z===!0){e.activeTexture(r.TEXTURE0+z);const Et=jt.getPrimaries(jt.workingColorSpace),mt=S.colorSpace===On?null:jt.getPrimaries(S.colorSpace),vt=S.colorSpace===On||Et===mt?r.NONE:r.BROWSER_DEFAULT_WEBGL;r.pixelStorei(r.UNPACK_FLIP_Y_WEBGL,S.flipY),r.pixelStorei(r.UNPACK_PREMULTIPLY_ALPHA_WEBGL,S.premultiplyAlpha),r.pixelStorei(r.UNPACK_ALIGNMENT,S.unpackAlignment),r.pixelStorei(r.UNPACK_COLORSPACE_CONVERSION_WEBGL,vt);const kt=S.isCompressedTexture||S.image[0].isCompressedTexture,st=S.image[0]&&S.image[0].isDataTexture,gt=[];for(let Q=0;Q<6;Q++)!kt&&!st?gt[Q]=_(S.image[Q],!0,i.maxCubemapSize):gt[Q]=st?S.image[Q].image:S.image[Q],gt[Q]=te(S,gt[Q]);const Ut=gt[0],Nt=s.convert(S.format,S.colorSpace),Mt=s.convert(S.type),Yt=y(S.internalFormat,Nt,Mt,S.colorSpace),qt=S.isVideoTexture!==!0,oe=K.__version===void 0||Z===!0,I=nt.dataReady;let _t=R(S,Ut);rt(r.TEXTURE_CUBE_MAP,S);let $;if(kt){qt&&oe&&e.texStorage2D(r.TEXTURE_CUBE_MAP,_t,Yt,Ut.width,Ut.height);for(let Q=0;Q<6;Q++){$=gt[Q].mipmaps;for(let bt=0;bt<$.length;bt++){const yt=$[bt];S.format!==nn?Nt!==null?qt?I&&e.compressedTexSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Q,bt,0,0,yt.width,yt.height,Nt,yt.data):e.compressedTexImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Q,bt,Yt,yt.width,yt.height,0,yt.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):qt?I&&e.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Q,bt,0,0,yt.width,yt.height,Nt,Mt,yt.data):e.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Q,bt,Yt,yt.width,yt.height,0,Nt,Mt,yt.data)}}}else{if($=S.mipmaps,qt&&oe){$.length>0&&_t++;const Q=Dt(gt[0]);e.texStorage2D(r.TEXTURE_CUBE_MAP,_t,Yt,Q.width,Q.height)}for(let Q=0;Q<6;Q++)if(st){qt?I&&e.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Q,0,0,0,gt[Q].width,gt[Q].height,Nt,Mt,gt[Q].data):e.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Q,0,Yt,gt[Q].width,gt[Q].height,0,Nt,Mt,gt[Q].data);for(let bt=0;bt<$.length;bt++){const Vt=$[bt].image[Q].image;qt?I&&e.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Q,bt+1,0,0,Vt.width,Vt.height,Nt,Mt,Vt.data):e.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Q,bt+1,Yt,Vt.width,Vt.height,0,Nt,Mt,Vt.data)}}else{qt?I&&e.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Q,0,0,0,Nt,Mt,gt[Q]):e.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Q,0,Yt,Nt,Mt,gt[Q]);for(let bt=0;bt<$.length;bt++){const yt=$[bt];qt?I&&e.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Q,bt+1,0,0,Nt,Mt,yt.image[Q]):e.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Q,bt+1,Yt,Nt,Mt,yt.image[Q])}}}m(S)&&p(r.TEXTURE_CUBE_MAP),K.__version=nt.version,S.onUpdate&&S.onUpdate(S)}A.__version=S.version}function ht(A,S,z,Z,nt,K){const Et=s.convert(z.format,z.colorSpace),mt=s.convert(z.type),vt=y(z.internalFormat,Et,mt,z.colorSpace),kt=n.get(S),st=n.get(z);if(st.__renderTarget=S,!kt.__hasExternalTextures){const gt=Math.max(1,S.width>>K),Ut=Math.max(1,S.height>>K);nt===r.TEXTURE_3D||nt===r.TEXTURE_2D_ARRAY?e.texImage3D(nt,K,vt,gt,Ut,S.depth,0,Et,mt,null):e.texImage2D(nt,K,vt,gt,Ut,0,Et,mt,null)}e.bindFramebuffer(r.FRAMEBUFFER,A),It(S)?o.framebufferTexture2DMultisampleEXT(r.FRAMEBUFFER,Z,nt,st.__webglTexture,0,Ot(S)):(nt===r.TEXTURE_2D||nt>=r.TEXTURE_CUBE_MAP_POSITIVE_X&&nt<=r.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&r.framebufferTexture2D(r.FRAMEBUFFER,Z,nt,st.__webglTexture,K),e.bindFramebuffer(r.FRAMEBUFFER,null)}function at(A,S,z){if(r.bindRenderbuffer(r.RENDERBUFFER,A),S.depthBuffer){const Z=S.depthTexture,nt=Z&&Z.isDepthTexture?Z.type:null,K=v(S.stencilBuffer,nt),Et=S.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT,mt=Ot(S);It(S)?o.renderbufferStorageMultisampleEXT(r.RENDERBUFFER,mt,K,S.width,S.height):z?r.renderbufferStorageMultisample(r.RENDERBUFFER,mt,K,S.width,S.height):r.renderbufferStorage(r.RENDERBUFFER,K,S.width,S.height),r.framebufferRenderbuffer(r.FRAMEBUFFER,Et,r.RENDERBUFFER,A)}else{const Z=S.textures;for(let nt=0;nt<Z.length;nt++){const K=Z[nt],Et=s.convert(K.format,K.colorSpace),mt=s.convert(K.type),vt=y(K.internalFormat,Et,mt,K.colorSpace),kt=Ot(S);z&&It(S)===!1?r.renderbufferStorageMultisample(r.RENDERBUFFER,kt,vt,S.width,S.height):It(S)?o.renderbufferStorageMultisampleEXT(r.RENDERBUFFER,kt,vt,S.width,S.height):r.renderbufferStorage(r.RENDERBUFFER,vt,S.width,S.height)}}r.bindRenderbuffer(r.RENDERBUFFER,null)}function wt(A,S){if(S&&S.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(e.bindFramebuffer(r.FRAMEBUFFER,A),!(S.depthTexture&&S.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");const Z=n.get(S.depthTexture);Z.__renderTarget=S,(!Z.__webglTexture||S.depthTexture.image.width!==S.width||S.depthTexture.image.height!==S.height)&&(S.depthTexture.image.width=S.width,S.depthTexture.image.height=S.height,S.depthTexture.needsUpdate=!0),X(S.depthTexture,0);const nt=Z.__webglTexture,K=Ot(S);if(S.depthTexture.format===Pi)It(S)?o.framebufferTexture2DMultisampleEXT(r.FRAMEBUFFER,r.DEPTH_ATTACHMENT,r.TEXTURE_2D,nt,0,K):r.framebufferTexture2D(r.FRAMEBUFFER,r.DEPTH_ATTACHMENT,r.TEXTURE_2D,nt,0);else if(S.depthTexture.format===zi)It(S)?o.framebufferTexture2DMultisampleEXT(r.FRAMEBUFFER,r.DEPTH_STENCIL_ATTACHMENT,r.TEXTURE_2D,nt,0,K):r.framebufferTexture2D(r.FRAMEBUFFER,r.DEPTH_STENCIL_ATTACHMENT,r.TEXTURE_2D,nt,0);else throw new Error("Unknown depthTexture format")}function xt(A){const S=n.get(A),z=A.isWebGLCubeRenderTarget===!0;if(S.__boundDepthTexture!==A.depthTexture){const Z=A.depthTexture;if(S.__depthDisposeCallback&&S.__depthDisposeCallback(),Z){const nt=()=>{delete S.__boundDepthTexture,delete S.__depthDisposeCallback,Z.removeEventListener("dispose",nt)};Z.addEventListener("dispose",nt),S.__depthDisposeCallback=nt}S.__boundDepthTexture=Z}if(A.depthTexture&&!S.__autoAllocateDepthBuffer){if(z)throw new Error("target.depthTexture not supported in Cube render targets");wt(S.__webglFramebuffer,A)}else if(z){S.__webglDepthbuffer=[];for(let Z=0;Z<6;Z++)if(e.bindFramebuffer(r.FRAMEBUFFER,S.__webglFramebuffer[Z]),S.__webglDepthbuffer[Z]===void 0)S.__webglDepthbuffer[Z]=r.createRenderbuffer(),at(S.__webglDepthbuffer[Z],A,!1);else{const nt=A.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT,K=S.__webglDepthbuffer[Z];r.bindRenderbuffer(r.RENDERBUFFER,K),r.framebufferRenderbuffer(r.FRAMEBUFFER,nt,r.RENDERBUFFER,K)}}else if(e.bindFramebuffer(r.FRAMEBUFFER,S.__webglFramebuffer),S.__webglDepthbuffer===void 0)S.__webglDepthbuffer=r.createRenderbuffer(),at(S.__webglDepthbuffer,A,!1);else{const Z=A.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT,nt=S.__webglDepthbuffer;r.bindRenderbuffer(r.RENDERBUFFER,nt),r.framebufferRenderbuffer(r.FRAMEBUFFER,Z,r.RENDERBUFFER,nt)}e.bindFramebuffer(r.FRAMEBUFFER,null)}function Y(A,S,z){const Z=n.get(A);S!==void 0&&ht(Z.__webglFramebuffer,A,A.texture,r.COLOR_ATTACHMENT0,r.TEXTURE_2D,0),z!==void 0&&xt(A)}function et(A){const S=A.texture,z=n.get(A),Z=n.get(S);A.addEventListener("dispose",E);const nt=A.textures,K=A.isWebGLCubeRenderTarget===!0,Et=nt.length>1;if(Et||(Z.__webglTexture===void 0&&(Z.__webglTexture=r.createTexture()),Z.__version=S.version,a.memory.textures++),K){z.__webglFramebuffer=[];for(let mt=0;mt<6;mt++)if(S.mipmaps&&S.mipmaps.length>0){z.__webglFramebuffer[mt]=[];for(let vt=0;vt<S.mipmaps.length;vt++)z.__webglFramebuffer[mt][vt]=r.createFramebuffer()}else z.__webglFramebuffer[mt]=r.createFramebuffer()}else{if(S.mipmaps&&S.mipmaps.length>0){z.__webglFramebuffer=[];for(let mt=0;mt<S.mipmaps.length;mt++)z.__webglFramebuffer[mt]=r.createFramebuffer()}else z.__webglFramebuffer=r.createFramebuffer();if(Et)for(let mt=0,vt=nt.length;mt<vt;mt++){const kt=n.get(nt[mt]);kt.__webglTexture===void 0&&(kt.__webglTexture=r.createTexture(),a.memory.textures++)}if(A.samples>0&&It(A)===!1){z.__webglMultisampledFramebuffer=r.createFramebuffer(),z.__webglColorRenderbuffer=[],e.bindFramebuffer(r.FRAMEBUFFER,z.__webglMultisampledFramebuffer);for(let mt=0;mt<nt.length;mt++){const vt=nt[mt];z.__webglColorRenderbuffer[mt]=r.createRenderbuffer(),r.bindRenderbuffer(r.RENDERBUFFER,z.__webglColorRenderbuffer[mt]);const kt=s.convert(vt.format,vt.colorSpace),st=s.convert(vt.type),gt=y(vt.internalFormat,kt,st,vt.colorSpace,A.isXRRenderTarget===!0),Ut=Ot(A);r.renderbufferStorageMultisample(r.RENDERBUFFER,Ut,gt,A.width,A.height),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0+mt,r.RENDERBUFFER,z.__webglColorRenderbuffer[mt])}r.bindRenderbuffer(r.RENDERBUFFER,null),A.depthBuffer&&(z.__webglDepthRenderbuffer=r.createRenderbuffer(),at(z.__webglDepthRenderbuffer,A,!0)),e.bindFramebuffer(r.FRAMEBUFFER,null)}}if(K){e.bindTexture(r.TEXTURE_CUBE_MAP,Z.__webglTexture),rt(r.TEXTURE_CUBE_MAP,S);for(let mt=0;mt<6;mt++)if(S.mipmaps&&S.mipmaps.length>0)for(let vt=0;vt<S.mipmaps.length;vt++)ht(z.__webglFramebuffer[mt][vt],A,S,r.COLOR_ATTACHMENT0,r.TEXTURE_CUBE_MAP_POSITIVE_X+mt,vt);else ht(z.__webglFramebuffer[mt],A,S,r.COLOR_ATTACHMENT0,r.TEXTURE_CUBE_MAP_POSITIVE_X+mt,0);m(S)&&p(r.TEXTURE_CUBE_MAP),e.unbindTexture()}else if(Et){for(let mt=0,vt=nt.length;mt<vt;mt++){const kt=nt[mt],st=n.get(kt);e.bindTexture(r.TEXTURE_2D,st.__webglTexture),rt(r.TEXTURE_2D,kt),ht(z.__webglFramebuffer,A,kt,r.COLOR_ATTACHMENT0+mt,r.TEXTURE_2D,0),m(kt)&&p(r.TEXTURE_2D)}e.unbindTexture()}else{let mt=r.TEXTURE_2D;if((A.isWebGL3DRenderTarget||A.isWebGLArrayRenderTarget)&&(mt=A.isWebGL3DRenderTarget?r.TEXTURE_3D:r.TEXTURE_2D_ARRAY),e.bindTexture(mt,Z.__webglTexture),rt(mt,S),S.mipmaps&&S.mipmaps.length>0)for(let vt=0;vt<S.mipmaps.length;vt++)ht(z.__webglFramebuffer[vt],A,S,r.COLOR_ATTACHMENT0,mt,vt);else ht(z.__webglFramebuffer,A,S,r.COLOR_ATTACHMENT0,mt,0);m(S)&&p(mt),e.unbindTexture()}A.depthBuffer&&xt(A)}function dt(A){const S=A.textures;for(let z=0,Z=S.length;z<Z;z++){const nt=S[z];if(m(nt)){const K=x(A),Et=n.get(nt).__webglTexture;e.bindTexture(K,Et),p(K),e.unbindTexture()}}}const zt=[],L=[];function Qt(A){if(A.samples>0){if(It(A)===!1){const S=A.textures,z=A.width,Z=A.height;let nt=r.COLOR_BUFFER_BIT;const K=A.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT,Et=n.get(A),mt=S.length>1;if(mt)for(let vt=0;vt<S.length;vt++)e.bindFramebuffer(r.FRAMEBUFFER,Et.__webglMultisampledFramebuffer),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0+vt,r.RENDERBUFFER,null),e.bindFramebuffer(r.FRAMEBUFFER,Et.__webglFramebuffer),r.framebufferTexture2D(r.DRAW_FRAMEBUFFER,r.COLOR_ATTACHMENT0+vt,r.TEXTURE_2D,null,0);e.bindFramebuffer(r.READ_FRAMEBUFFER,Et.__webglMultisampledFramebuffer),e.bindFramebuffer(r.DRAW_FRAMEBUFFER,Et.__webglFramebuffer);for(let vt=0;vt<S.length;vt++){if(A.resolveDepthBuffer&&(A.depthBuffer&&(nt|=r.DEPTH_BUFFER_BIT),A.stencilBuffer&&A.resolveStencilBuffer&&(nt|=r.STENCIL_BUFFER_BIT)),mt){r.framebufferRenderbuffer(r.READ_FRAMEBUFFER,r.COLOR_ATTACHMENT0,r.RENDERBUFFER,Et.__webglColorRenderbuffer[vt]);const kt=n.get(S[vt]).__webglTexture;r.framebufferTexture2D(r.DRAW_FRAMEBUFFER,r.COLOR_ATTACHMENT0,r.TEXTURE_2D,kt,0)}r.blitFramebuffer(0,0,z,Z,0,0,z,Z,nt,r.NEAREST),l===!0&&(zt.length=0,L.length=0,zt.push(r.COLOR_ATTACHMENT0+vt),A.depthBuffer&&A.resolveDepthBuffer===!1&&(zt.push(K),L.push(K),r.invalidateFramebuffer(r.DRAW_FRAMEBUFFER,L)),r.invalidateFramebuffer(r.READ_FRAMEBUFFER,zt))}if(e.bindFramebuffer(r.READ_FRAMEBUFFER,null),e.bindFramebuffer(r.DRAW_FRAMEBUFFER,null),mt)for(let vt=0;vt<S.length;vt++){e.bindFramebuffer(r.FRAMEBUFFER,Et.__webglMultisampledFramebuffer),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0+vt,r.RENDERBUFFER,Et.__webglColorRenderbuffer[vt]);const kt=n.get(S[vt]).__webglTexture;e.bindFramebuffer(r.FRAMEBUFFER,Et.__webglFramebuffer),r.framebufferTexture2D(r.DRAW_FRAMEBUFFER,r.COLOR_ATTACHMENT0+vt,r.TEXTURE_2D,kt,0)}e.bindFramebuffer(r.DRAW_FRAMEBUFFER,Et.__webglMultisampledFramebuffer)}else if(A.depthBuffer&&A.resolveDepthBuffer===!1&&l){const S=A.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT;r.invalidateFramebuffer(r.DRAW_FRAMEBUFFER,[S])}}}function Ot(A){return Math.min(i.maxSamples,A.samples)}function It(A){const S=n.get(A);return A.samples>0&&t.has("WEBGL_multisampled_render_to_texture")===!0&&S.__useRenderToTexture!==!1}function Tt(A){const S=a.render.frame;h.get(A)!==S&&(h.set(A,S),A.update())}function te(A,S){const z=A.colorSpace,Z=A.format,nt=A.type;return A.isCompressedTexture===!0||A.isVideoTexture===!0||z!==Hi&&z!==On&&(jt.getTransfer(z)===se?(Z!==nn||nt!==Tn)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",z)),S}function Dt(A){return typeof HTMLImageElement<"u"&&A instanceof HTMLImageElement?(c.width=A.naturalWidth||A.width,c.height=A.naturalHeight||A.height):typeof VideoFrame<"u"&&A instanceof VideoFrame?(c.width=A.displayWidth,c.height=A.displayHeight):(c.width=A.width,c.height=A.height),c}this.allocateTextureUnit=O,this.resetTextureUnits=U,this.setTexture2D=X,this.setTexture2DArray=W,this.setTexture3D=j,this.setTextureCube=k,this.rebindTextures=Y,this.setupRenderTarget=et,this.updateRenderTargetMipmap=dt,this.updateMultisampleRenderTarget=Qt,this.setupDepthRenderbuffer=xt,this.setupFrameBufferTexture=ht,this.useMultisampledRTT=It}function Cm(r,t){function e(n,i=On){let s;const a=jt.getTransfer(i);if(n===Tn)return r.UNSIGNED_BYTE;if(n===Ha)return r.UNSIGNED_SHORT_4_4_4_4;if(n===Va)return r.UNSIGNED_SHORT_5_5_5_1;if(n===Yl)return r.UNSIGNED_INT_5_9_9_9_REV;if(n===ql)return r.BYTE;if(n===$l)return r.SHORT;if(n===hs)return r.UNSIGNED_SHORT;if(n===Ga)return r.INT;if(n===ai)return r.UNSIGNED_INT;if(n===hn)return r.FLOAT;if(n===bn)return r.HALF_FLOAT;if(n===jl)return r.ALPHA;if(n===Kl)return r.RGB;if(n===nn)return r.RGBA;if(n===Zl)return r.LUMINANCE;if(n===Jl)return r.LUMINANCE_ALPHA;if(n===Pi)return r.DEPTH_COMPONENT;if(n===zi)return r.DEPTH_STENCIL;if(n===Wa)return r.RED;if(n===Xa)return r.RED_INTEGER;if(n===Ql)return r.RG;if(n===qa)return r.RG_INTEGER;if(n===$a)return r.RGBA_INTEGER;if(n===Ws||n===Xs||n===qs||n===$s)if(a===se)if(s=t.get("WEBGL_compressed_texture_s3tc_srgb"),s!==null){if(n===Ws)return s.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===Xs)return s.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===qs)return s.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===$s)return s.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(s=t.get("WEBGL_compressed_texture_s3tc"),s!==null){if(n===Ws)return s.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===Xs)return s.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===qs)return s.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===$s)return s.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(n===ca||n===ha||n===ua||n===fa)if(s=t.get("WEBGL_compressed_texture_pvrtc"),s!==null){if(n===ca)return s.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===ha)return s.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===ua)return s.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===fa)return s.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(n===da||n===pa||n===ma)if(s=t.get("WEBGL_compressed_texture_etc"),s!==null){if(n===da||n===pa)return a===se?s.COMPRESSED_SRGB8_ETC2:s.COMPRESSED_RGB8_ETC2;if(n===ma)return a===se?s.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:s.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(n===ga||n===_a||n===xa||n===va||n===Ma||n===ya||n===Sa||n===ba||n===wa||n===Ta||n===Ea||n===Aa||n===Ra||n===Ca)if(s=t.get("WEBGL_compressed_texture_astc"),s!==null){if(n===ga)return a===se?s.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:s.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===_a)return a===se?s.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:s.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===xa)return a===se?s.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:s.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===va)return a===se?s.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:s.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===Ma)return a===se?s.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:s.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===ya)return a===se?s.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:s.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===Sa)return a===se?s.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:s.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===ba)return a===se?s.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:s.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===wa)return a===se?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:s.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===Ta)return a===se?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:s.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===Ea)return a===se?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:s.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===Aa)return a===se?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:s.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===Ra)return a===se?s.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:s.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===Ca)return a===se?s.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:s.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(n===Ys||n===Pa||n===La)if(s=t.get("EXT_texture_compression_bptc"),s!==null){if(n===Ys)return a===se?s.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:s.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===Pa)return s.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===La)return s.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(n===tc||n===Da||n===Ia||n===Ua)if(s=t.get("EXT_texture_compression_rgtc"),s!==null){if(n===Ys)return s.COMPRESSED_RED_RGTC1_EXT;if(n===Da)return s.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===Ia)return s.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===Ua)return s.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return n===Oi?r.UNSIGNED_INT_24_8:r[n]!==void 0?r[n]:null}return{convert:e}}class Pm extends He{constructor(t=[]){super(),this.isArrayCamera=!0,this.cameras=t}}class me extends fe{constructor(){super(),this.isGroup=!0,this.type="Group"}}const Lm={type:"move"};class Or{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new me,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new me,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new D,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new D),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new me,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new D,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new D),this._grip}dispatchEvent(t){return this._targetRay!==null&&this._targetRay.dispatchEvent(t),this._grip!==null&&this._grip.dispatchEvent(t),this._hand!==null&&this._hand.dispatchEvent(t),this}connect(t){if(t&&t.hand){const e=this._hand;if(e)for(const n of t.hand.values())this._getHandJoint(e,n)}return this.dispatchEvent({type:"connected",data:t}),this}disconnect(t){return this.dispatchEvent({type:"disconnected",data:t}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(t,e,n){let i=null,s=null,a=null;const o=this._targetRay,l=this._grip,c=this._hand;if(t&&e.session.visibilityState!=="visible-blurred"){if(c&&t.hand){a=!0;for(const _ of t.hand.values()){const m=e.getJointPose(_,n),p=this._getHandJoint(c,_);m!==null&&(p.matrix.fromArray(m.transform.matrix),p.matrix.decompose(p.position,p.rotation,p.scale),p.matrixWorldNeedsUpdate=!0,p.jointRadius=m.radius),p.visible=m!==null}const h=c.joints["index-finger-tip"],u=c.joints["thumb-tip"],f=h.position.distanceTo(u.position),d=.02,g=.005;c.inputState.pinching&&f>d+g?(c.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:t.handedness,target:this})):!c.inputState.pinching&&f<=d-g&&(c.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:t.handedness,target:this}))}else l!==null&&t.gripSpace&&(s=e.getPose(t.gripSpace,n),s!==null&&(l.matrix.fromArray(s.transform.matrix),l.matrix.decompose(l.position,l.rotation,l.scale),l.matrixWorldNeedsUpdate=!0,s.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(s.linearVelocity)):l.hasLinearVelocity=!1,s.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(s.angularVelocity)):l.hasAngularVelocity=!1));o!==null&&(i=e.getPose(t.targetRaySpace,n),i===null&&s!==null&&(i=s),i!==null&&(o.matrix.fromArray(i.transform.matrix),o.matrix.decompose(o.position,o.rotation,o.scale),o.matrixWorldNeedsUpdate=!0,i.linearVelocity?(o.hasLinearVelocity=!0,o.linearVelocity.copy(i.linearVelocity)):o.hasLinearVelocity=!1,i.angularVelocity?(o.hasAngularVelocity=!0,o.angularVelocity.copy(i.angularVelocity)):o.hasAngularVelocity=!1,this.dispatchEvent(Lm)))}return o!==null&&(o.visible=i!==null),l!==null&&(l.visible=s!==null),c!==null&&(c.visible=a!==null),this}_getHandJoint(t,e){if(t.joints[e.jointName]===void 0){const n=new me;n.matrixAutoUpdate=!1,n.visible=!1,t.joints[e.jointName]=n,t.add(n)}return t.joints[e.jointName]}}const Dm=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,Im=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class Um{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(t,e,n){if(this.texture===null){const i=new Ce,s=t.properties.get(i);s.__webglTexture=e.texture,(e.depthNear!=n.depthNear||e.depthFar!=n.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=i}}getMesh(t){if(this.texture!==null&&this.mesh===null){const e=t.cameras[0].viewport,n=new ye({vertexShader:Dm,fragmentShader:Im,uniforms:{depthColor:{value:this.texture},depthWidth:{value:e.z},depthHeight:{value:e.w}}});this.mesh=new ot(new Me(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class Nm extends Vi{constructor(t,e){super();const n=this;let i=null,s=1,a=null,o="local-floor",l=1,c=null,h=null,u=null,f=null,d=null,g=null;const _=new Um,m=e.getContextAttributes();let p=null,x=null;const y=[],v=[],R=new Bt;let T=null;const E=new He;E.viewport=new ge;const P=new He;P.viewport=new ge;const b=[E,P],M=new Pm;let C=null,U=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(B){let J=y[B];return J===void 0&&(J=new Or,y[B]=J),J.getTargetRaySpace()},this.getControllerGrip=function(B){let J=y[B];return J===void 0&&(J=new Or,y[B]=J),J.getGripSpace()},this.getHand=function(B){let J=y[B];return J===void 0&&(J=new Or,y[B]=J),J.getHandSpace()};function O(B){const J=v.indexOf(B.inputSource);if(J===-1)return;const ht=y[J];ht!==void 0&&(ht.update(B.inputSource,B.frame,c||a),ht.dispatchEvent({type:B.type,data:B.inputSource}))}function V(){i.removeEventListener("select",O),i.removeEventListener("selectstart",O),i.removeEventListener("selectend",O),i.removeEventListener("squeeze",O),i.removeEventListener("squeezestart",O),i.removeEventListener("squeezeend",O),i.removeEventListener("end",V),i.removeEventListener("inputsourceschange",X);for(let B=0;B<y.length;B++){const J=v[B];J!==null&&(v[B]=null,y[B].disconnect(J))}C=null,U=null,_.reset(),t.setRenderTarget(p),d=null,f=null,u=null,i=null,x=null,ut.stop(),n.isPresenting=!1,t.setPixelRatio(T),t.setSize(R.width,R.height,!1),n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(B){s=B,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(B){o=B,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return c||a},this.setReferenceSpace=function(B){c=B},this.getBaseLayer=function(){return f!==null?f:d},this.getBinding=function(){return u},this.getFrame=function(){return g},this.getSession=function(){return i},this.setSession=async function(B){if(i=B,i!==null){if(p=t.getRenderTarget(),i.addEventListener("select",O),i.addEventListener("selectstart",O),i.addEventListener("selectend",O),i.addEventListener("squeeze",O),i.addEventListener("squeezestart",O),i.addEventListener("squeezeend",O),i.addEventListener("end",V),i.addEventListener("inputsourceschange",X),m.xrCompatible!==!0&&await e.makeXRCompatible(),T=t.getPixelRatio(),t.getSize(R),i.renderState.layers===void 0){const J={antialias:m.antialias,alpha:!0,depth:m.depth,stencil:m.stencil,framebufferScaleFactor:s};d=new XRWebGLLayer(i,e,J),i.updateRenderState({baseLayer:d}),t.setPixelRatio(1),t.setSize(d.framebufferWidth,d.framebufferHeight,!1),x=new sn(d.framebufferWidth,d.framebufferHeight,{format:nn,type:Tn,colorSpace:t.outputColorSpace,stencilBuffer:m.stencil})}else{let J=null,ht=null,at=null;m.depth&&(at=m.stencil?e.DEPTH24_STENCIL8:e.DEPTH_COMPONENT24,J=m.stencil?zi:Pi,ht=m.stencil?Oi:ai);const wt={colorFormat:e.RGBA8,depthFormat:at,scaleFactor:s};u=new XRWebGLBinding(i,e),f=u.createProjectionLayer(wt),i.updateRenderState({layers:[f]}),t.setPixelRatio(1),t.setSize(f.textureWidth,f.textureHeight,!1),x=new sn(f.textureWidth,f.textureHeight,{format:nn,type:Tn,depthTexture:new pc(f.textureWidth,f.textureHeight,ht,void 0,void 0,void 0,void 0,void 0,void 0,J),stencilBuffer:m.stencil,colorSpace:t.outputColorSpace,samples:m.antialias?4:0,resolveDepthBuffer:f.ignoreDepthValues===!1})}x.isXRRenderTarget=!0,this.setFoveation(l),c=null,a=await i.requestReferenceSpace(o),ut.setContext(i),ut.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(i!==null)return i.environmentBlendMode},this.getDepthTexture=function(){return _.getDepthTexture()};function X(B){for(let J=0;J<B.removed.length;J++){const ht=B.removed[J],at=v.indexOf(ht);at>=0&&(v[at]=null,y[at].disconnect(ht))}for(let J=0;J<B.added.length;J++){const ht=B.added[J];let at=v.indexOf(ht);if(at===-1){for(let xt=0;xt<y.length;xt++)if(xt>=v.length){v.push(ht),at=xt;break}else if(v[xt]===null){v[xt]=ht,at=xt;break}if(at===-1)break}const wt=y[at];wt&&wt.connect(ht)}}const W=new D,j=new D;function k(B,J,ht){W.setFromMatrixPosition(J.matrixWorld),j.setFromMatrixPosition(ht.matrixWorld);const at=W.distanceTo(j),wt=J.projectionMatrix.elements,xt=ht.projectionMatrix.elements,Y=wt[14]/(wt[10]-1),et=wt[14]/(wt[10]+1),dt=(wt[9]+1)/wt[5],zt=(wt[9]-1)/wt[5],L=(wt[8]-1)/wt[0],Qt=(xt[8]+1)/xt[0],Ot=Y*L,It=Y*Qt,Tt=at/(-L+Qt),te=Tt*-L;if(J.matrixWorld.decompose(B.position,B.quaternion,B.scale),B.translateX(te),B.translateZ(Tt),B.matrixWorld.compose(B.position,B.quaternion,B.scale),B.matrixWorldInverse.copy(B.matrixWorld).invert(),wt[10]===-1)B.projectionMatrix.copy(J.projectionMatrix),B.projectionMatrixInverse.copy(J.projectionMatrixInverse);else{const Dt=Y+Tt,A=et+Tt,S=Ot-te,z=It+(at-te),Z=dt*et/A*Dt,nt=zt*et/A*Dt;B.projectionMatrix.makePerspective(S,z,Z,nt,Dt,A),B.projectionMatrixInverse.copy(B.projectionMatrix).invert()}}function it(B,J){J===null?B.matrixWorld.copy(B.matrix):B.matrixWorld.multiplyMatrices(J.matrixWorld,B.matrix),B.matrixWorldInverse.copy(B.matrixWorld).invert()}this.updateCamera=function(B){if(i===null)return;let J=B.near,ht=B.far;_.texture!==null&&(_.depthNear>0&&(J=_.depthNear),_.depthFar>0&&(ht=_.depthFar)),M.near=P.near=E.near=J,M.far=P.far=E.far=ht,(C!==M.near||U!==M.far)&&(i.updateRenderState({depthNear:M.near,depthFar:M.far}),C=M.near,U=M.far),E.layers.mask=B.layers.mask|2,P.layers.mask=B.layers.mask|4,M.layers.mask=E.layers.mask|P.layers.mask;const at=B.parent,wt=M.cameras;it(M,at);for(let xt=0;xt<wt.length;xt++)it(wt[xt],at);wt.length===2?k(M,E,P):M.projectionMatrix.copy(E.projectionMatrix),q(B,M,at)};function q(B,J,ht){ht===null?B.matrix.copy(J.matrixWorld):(B.matrix.copy(ht.matrixWorld),B.matrix.invert(),B.matrix.multiply(J.matrixWorld)),B.matrix.decompose(B.position,B.quaternion,B.scale),B.updateMatrixWorld(!0),B.projectionMatrix.copy(J.projectionMatrix),B.projectionMatrixInverse.copy(J.projectionMatrixInverse),B.isPerspectiveCamera&&(B.fov=ki*2*Math.atan(1/B.projectionMatrix.elements[5]),B.zoom=1)}this.getCamera=function(){return M},this.getFoveation=function(){if(!(f===null&&d===null))return l},this.setFoveation=function(B){l=B,f!==null&&(f.fixedFoveation=B),d!==null&&d.fixedFoveation!==void 0&&(d.fixedFoveation=B)},this.hasDepthSensing=function(){return _.texture!==null},this.getDepthSensingMesh=function(){return _.getMesh(M)};let tt=null;function rt(B,J){if(h=J.getViewerPose(c||a),g=J,h!==null){const ht=h.views;d!==null&&(t.setRenderTargetFramebuffer(x,d.framebuffer),t.setRenderTarget(x));let at=!1;ht.length!==M.cameras.length&&(M.cameras.length=0,at=!0);for(let xt=0;xt<ht.length;xt++){const Y=ht[xt];let et=null;if(d!==null)et=d.getViewport(Y);else{const zt=u.getViewSubImage(f,Y);et=zt.viewport,xt===0&&(t.setRenderTargetTextures(x,zt.colorTexture,f.ignoreDepthValues?void 0:zt.depthStencilTexture),t.setRenderTarget(x))}let dt=b[xt];dt===void 0&&(dt=new He,dt.layers.enable(xt),dt.viewport=new ge,b[xt]=dt),dt.matrix.fromArray(Y.transform.matrix),dt.matrix.decompose(dt.position,dt.quaternion,dt.scale),dt.projectionMatrix.fromArray(Y.projectionMatrix),dt.projectionMatrixInverse.copy(dt.projectionMatrix).invert(),dt.viewport.set(et.x,et.y,et.width,et.height),xt===0&&(M.matrix.copy(dt.matrix),M.matrix.decompose(M.position,M.quaternion,M.scale)),at===!0&&M.cameras.push(dt)}const wt=i.enabledFeatures;if(wt&&wt.includes("depth-sensing")){const xt=u.getDepthInformation(ht[0]);xt&&xt.isValid&&xt.texture&&_.init(t,xt,i.renderState)}}for(let ht=0;ht<y.length;ht++){const at=v[ht],wt=y[ht];at!==null&&wt!==void 0&&wt.update(at,J,c||a)}tt&&tt(B,J),J.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:J}),g=null}const ut=new dc;ut.setAnimationLoop(rt),this.setAnimationLoop=function(B){tt=B},this.dispose=function(){}}}const $n=new rn,Fm=new Zt;function Om(r,t){function e(m,p){m.matrixAutoUpdate===!0&&m.updateMatrix(),p.value.copy(m.matrix)}function n(m,p){p.color.getRGB(m.fogColor.value,hc(r)),p.isFog?(m.fogNear.value=p.near,m.fogFar.value=p.far):p.isFogExp2&&(m.fogDensity.value=p.density)}function i(m,p,x,y,v){p.isMeshBasicMaterial||p.isMeshLambertMaterial?s(m,p):p.isMeshToonMaterial?(s(m,p),u(m,p)):p.isMeshPhongMaterial?(s(m,p),h(m,p)):p.isMeshStandardMaterial?(s(m,p),f(m,p),p.isMeshPhysicalMaterial&&d(m,p,v)):p.isMeshMatcapMaterial?(s(m,p),g(m,p)):p.isMeshDepthMaterial?s(m,p):p.isMeshDistanceMaterial?(s(m,p),_(m,p)):p.isMeshNormalMaterial?s(m,p):p.isLineBasicMaterial?(a(m,p),p.isLineDashedMaterial&&o(m,p)):p.isPointsMaterial?l(m,p,x,y):p.isSpriteMaterial?c(m,p):p.isShadowMaterial?(m.color.value.copy(p.color),m.opacity.value=p.opacity):p.isShaderMaterial&&(p.uniformsNeedUpdate=!1)}function s(m,p){m.opacity.value=p.opacity,p.color&&m.diffuse.value.copy(p.color),p.emissive&&m.emissive.value.copy(p.emissive).multiplyScalar(p.emissiveIntensity),p.map&&(m.map.value=p.map,e(p.map,m.mapTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,e(p.alphaMap,m.alphaMapTransform)),p.bumpMap&&(m.bumpMap.value=p.bumpMap,e(p.bumpMap,m.bumpMapTransform),m.bumpScale.value=p.bumpScale,p.side===Ne&&(m.bumpScale.value*=-1)),p.normalMap&&(m.normalMap.value=p.normalMap,e(p.normalMap,m.normalMapTransform),m.normalScale.value.copy(p.normalScale),p.side===Ne&&m.normalScale.value.negate()),p.displacementMap&&(m.displacementMap.value=p.displacementMap,e(p.displacementMap,m.displacementMapTransform),m.displacementScale.value=p.displacementScale,m.displacementBias.value=p.displacementBias),p.emissiveMap&&(m.emissiveMap.value=p.emissiveMap,e(p.emissiveMap,m.emissiveMapTransform)),p.specularMap&&(m.specularMap.value=p.specularMap,e(p.specularMap,m.specularMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest);const x=t.get(p),y=x.envMap,v=x.envMapRotation;y&&(m.envMap.value=y,$n.copy(v),$n.x*=-1,$n.y*=-1,$n.z*=-1,y.isCubeTexture&&y.isRenderTargetTexture===!1&&($n.y*=-1,$n.z*=-1),m.envMapRotation.value.setFromMatrix4(Fm.makeRotationFromEuler($n)),m.flipEnvMap.value=y.isCubeTexture&&y.isRenderTargetTexture===!1?-1:1,m.reflectivity.value=p.reflectivity,m.ior.value=p.ior,m.refractionRatio.value=p.refractionRatio),p.lightMap&&(m.lightMap.value=p.lightMap,m.lightMapIntensity.value=p.lightMapIntensity,e(p.lightMap,m.lightMapTransform)),p.aoMap&&(m.aoMap.value=p.aoMap,m.aoMapIntensity.value=p.aoMapIntensity,e(p.aoMap,m.aoMapTransform))}function a(m,p){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,p.map&&(m.map.value=p.map,e(p.map,m.mapTransform))}function o(m,p){m.dashSize.value=p.dashSize,m.totalSize.value=p.dashSize+p.gapSize,m.scale.value=p.scale}function l(m,p,x,y){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,m.size.value=p.size*x,m.scale.value=y*.5,p.map&&(m.map.value=p.map,e(p.map,m.uvTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,e(p.alphaMap,m.alphaMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest)}function c(m,p){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,m.rotation.value=p.rotation,p.map&&(m.map.value=p.map,e(p.map,m.mapTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,e(p.alphaMap,m.alphaMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest)}function h(m,p){m.specular.value.copy(p.specular),m.shininess.value=Math.max(p.shininess,1e-4)}function u(m,p){p.gradientMap&&(m.gradientMap.value=p.gradientMap)}function f(m,p){m.metalness.value=p.metalness,p.metalnessMap&&(m.metalnessMap.value=p.metalnessMap,e(p.metalnessMap,m.metalnessMapTransform)),m.roughness.value=p.roughness,p.roughnessMap&&(m.roughnessMap.value=p.roughnessMap,e(p.roughnessMap,m.roughnessMapTransform)),p.envMap&&(m.envMapIntensity.value=p.envMapIntensity)}function d(m,p,x){m.ior.value=p.ior,p.sheen>0&&(m.sheenColor.value.copy(p.sheenColor).multiplyScalar(p.sheen),m.sheenRoughness.value=p.sheenRoughness,p.sheenColorMap&&(m.sheenColorMap.value=p.sheenColorMap,e(p.sheenColorMap,m.sheenColorMapTransform)),p.sheenRoughnessMap&&(m.sheenRoughnessMap.value=p.sheenRoughnessMap,e(p.sheenRoughnessMap,m.sheenRoughnessMapTransform))),p.clearcoat>0&&(m.clearcoat.value=p.clearcoat,m.clearcoatRoughness.value=p.clearcoatRoughness,p.clearcoatMap&&(m.clearcoatMap.value=p.clearcoatMap,e(p.clearcoatMap,m.clearcoatMapTransform)),p.clearcoatRoughnessMap&&(m.clearcoatRoughnessMap.value=p.clearcoatRoughnessMap,e(p.clearcoatRoughnessMap,m.clearcoatRoughnessMapTransform)),p.clearcoatNormalMap&&(m.clearcoatNormalMap.value=p.clearcoatNormalMap,e(p.clearcoatNormalMap,m.clearcoatNormalMapTransform),m.clearcoatNormalScale.value.copy(p.clearcoatNormalScale),p.side===Ne&&m.clearcoatNormalScale.value.negate())),p.dispersion>0&&(m.dispersion.value=p.dispersion),p.iridescence>0&&(m.iridescence.value=p.iridescence,m.iridescenceIOR.value=p.iridescenceIOR,m.iridescenceThicknessMinimum.value=p.iridescenceThicknessRange[0],m.iridescenceThicknessMaximum.value=p.iridescenceThicknessRange[1],p.iridescenceMap&&(m.iridescenceMap.value=p.iridescenceMap,e(p.iridescenceMap,m.iridescenceMapTransform)),p.iridescenceThicknessMap&&(m.iridescenceThicknessMap.value=p.iridescenceThicknessMap,e(p.iridescenceThicknessMap,m.iridescenceThicknessMapTransform))),p.transmission>0&&(m.transmission.value=p.transmission,m.transmissionSamplerMap.value=x.texture,m.transmissionSamplerSize.value.set(x.width,x.height),p.transmissionMap&&(m.transmissionMap.value=p.transmissionMap,e(p.transmissionMap,m.transmissionMapTransform)),m.thickness.value=p.thickness,p.thicknessMap&&(m.thicknessMap.value=p.thicknessMap,e(p.thicknessMap,m.thicknessMapTransform)),m.attenuationDistance.value=p.attenuationDistance,m.attenuationColor.value.copy(p.attenuationColor)),p.anisotropy>0&&(m.anisotropyVector.value.set(p.anisotropy*Math.cos(p.anisotropyRotation),p.anisotropy*Math.sin(p.anisotropyRotation)),p.anisotropyMap&&(m.anisotropyMap.value=p.anisotropyMap,e(p.anisotropyMap,m.anisotropyMapTransform))),m.specularIntensity.value=p.specularIntensity,m.specularColor.value.copy(p.specularColor),p.specularColorMap&&(m.specularColorMap.value=p.specularColorMap,e(p.specularColorMap,m.specularColorMapTransform)),p.specularIntensityMap&&(m.specularIntensityMap.value=p.specularIntensityMap,e(p.specularIntensityMap,m.specularIntensityMapTransform))}function g(m,p){p.matcap&&(m.matcap.value=p.matcap)}function _(m,p){const x=t.get(p).light;m.referencePosition.value.setFromMatrixPosition(x.matrixWorld),m.nearDistance.value=x.shadow.camera.near,m.farDistance.value=x.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:i}}function zm(r,t,e,n){let i={},s={},a=[];const o=r.getParameter(r.MAX_UNIFORM_BUFFER_BINDINGS);function l(x,y){const v=y.program;n.uniformBlockBinding(x,v)}function c(x,y){let v=i[x.id];v===void 0&&(g(x),v=h(x),i[x.id]=v,x.addEventListener("dispose",m));const R=y.program;n.updateUBOMapping(x,R);const T=t.render.frame;s[x.id]!==T&&(f(x),s[x.id]=T)}function h(x){const y=u();x.__bindingPointIndex=y;const v=r.createBuffer(),R=x.__size,T=x.usage;return r.bindBuffer(r.UNIFORM_BUFFER,v),r.bufferData(r.UNIFORM_BUFFER,R,T),r.bindBuffer(r.UNIFORM_BUFFER,null),r.bindBufferBase(r.UNIFORM_BUFFER,y,v),v}function u(){for(let x=0;x<o;x++)if(a.indexOf(x)===-1)return a.push(x),x;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function f(x){const y=i[x.id],v=x.uniforms,R=x.__cache;r.bindBuffer(r.UNIFORM_BUFFER,y);for(let T=0,E=v.length;T<E;T++){const P=Array.isArray(v[T])?v[T]:[v[T]];for(let b=0,M=P.length;b<M;b++){const C=P[b];if(d(C,T,b,R)===!0){const U=C.__offset,O=Array.isArray(C.value)?C.value:[C.value];let V=0;for(let X=0;X<O.length;X++){const W=O[X],j=_(W);typeof W=="number"||typeof W=="boolean"?(C.__data[0]=W,r.bufferSubData(r.UNIFORM_BUFFER,U+V,C.__data)):W.isMatrix3?(C.__data[0]=W.elements[0],C.__data[1]=W.elements[1],C.__data[2]=W.elements[2],C.__data[3]=0,C.__data[4]=W.elements[3],C.__data[5]=W.elements[4],C.__data[6]=W.elements[5],C.__data[7]=0,C.__data[8]=W.elements[6],C.__data[9]=W.elements[7],C.__data[10]=W.elements[8],C.__data[11]=0):(W.toArray(C.__data,V),V+=j.storage/Float32Array.BYTES_PER_ELEMENT)}r.bufferSubData(r.UNIFORM_BUFFER,U,C.__data)}}}r.bindBuffer(r.UNIFORM_BUFFER,null)}function d(x,y,v,R){const T=x.value,E=y+"_"+v;if(R[E]===void 0)return typeof T=="number"||typeof T=="boolean"?R[E]=T:R[E]=T.clone(),!0;{const P=R[E];if(typeof T=="number"||typeof T=="boolean"){if(P!==T)return R[E]=T,!0}else if(P.equals(T)===!1)return P.copy(T),!0}return!1}function g(x){const y=x.uniforms;let v=0;const R=16;for(let E=0,P=y.length;E<P;E++){const b=Array.isArray(y[E])?y[E]:[y[E]];for(let M=0,C=b.length;M<C;M++){const U=b[M],O=Array.isArray(U.value)?U.value:[U.value];for(let V=0,X=O.length;V<X;V++){const W=O[V],j=_(W),k=v%R,it=k%j.boundary,q=k+it;v+=it,q!==0&&R-q<j.storage&&(v+=R-q),U.__data=new Float32Array(j.storage/Float32Array.BYTES_PER_ELEMENT),U.__offset=v,v+=j.storage}}}const T=v%R;return T>0&&(v+=R-T),x.__size=v,x.__cache={},this}function _(x){const y={boundary:0,storage:0};return typeof x=="number"||typeof x=="boolean"?(y.boundary=4,y.storage=4):x.isVector2?(y.boundary=8,y.storage=8):x.isVector3||x.isColor?(y.boundary=16,y.storage=12):x.isVector4?(y.boundary=16,y.storage=16):x.isMatrix3?(y.boundary=48,y.storage=48):x.isMatrix4?(y.boundary=64,y.storage=64):x.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",x),y}function m(x){const y=x.target;y.removeEventListener("dispose",m);const v=a.indexOf(y.__bindingPointIndex);a.splice(v,1),r.deleteBuffer(i[y.id]),delete i[y.id],delete s[y.id]}function p(){for(const x in i)r.deleteBuffer(i[x]);a=[],i={},s={}}return{bind:l,update:c,dispose:p}}class km{constructor(t={}){const{canvas:e=Ah(),context:n=null,depth:i=!0,stencil:s=!1,alpha:a=!1,antialias:o=!1,premultipliedAlpha:l=!0,preserveDrawingBuffer:c=!1,powerPreference:h="default",failIfMajorPerformanceCaveat:u=!1,reverseDepthBuffer:f=!1}=t;this.isWebGLRenderer=!0;let d;if(n!==null){if(typeof WebGLRenderingContext<"u"&&n instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");d=n.getContextAttributes().alpha}else d=a;const g=new Uint32Array(4),_=new Int32Array(4);let m=null,p=null;const x=[],y=[];this.domElement=e,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this._outputColorSpace=Ue,this.toneMapping=zn,this.toneMappingExposure=1;const v=this;let R=!1,T=0,E=0,P=null,b=-1,M=null;const C=new ge,U=new ge;let O=null;const V=new Pt(0);let X=0,W=e.width,j=e.height,k=1,it=null,q=null;const tt=new ge(0,0,W,j),rt=new ge(0,0,W,j);let ut=!1;const B=new Ka;let J=!1,ht=!1;const at=new Zt,wt=new Zt,xt=new D,Y=new ge,et={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let dt=!1;function zt(){return P===null?k:1}let L=n;function Qt(w,N){return e.getContext(w,N)}try{const w={alpha:!0,depth:i,stencil:s,antialias:o,premultipliedAlpha:l,preserveDrawingBuffer:c,powerPreference:h,failIfMajorPerformanceCaveat:u};if("setAttribute"in e&&e.setAttribute("data-engine",`three.js r${ka}`),e.addEventListener("webglcontextlost",Q,!1),e.addEventListener("webglcontextrestored",bt,!1),e.addEventListener("webglcontextcreationerror",yt,!1),L===null){const N="webgl2";if(L=Qt(N,w),L===null)throw Qt(N)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}}catch(w){throw console.error("THREE.WebGLRenderer: "+w.message),w}let Ot,It,Tt,te,Dt,A,S,z,Z,nt,K,Et,mt,vt,kt,st,gt,Ut,Nt,Mt,Yt,qt,oe,I;function _t(){Ot=new Wd(L),Ot.init(),qt=new Cm(L,Ot),It=new zd(L,Ot,t,qt),Tt=new Em(L,Ot),It.reverseDepthBuffer&&f&&Tt.buffers.depth.setReversed(!0),te=new $d(L),Dt=new um,A=new Rm(L,Ot,Tt,Dt,It,qt,te),S=new Bd(v),z=new Vd(v),Z=new Qh(L),oe=new Fd(L,Z),nt=new Xd(L,Z,te,oe),K=new jd(L,nt,Z,te),Nt=new Yd(L,It,A),st=new kd(Dt),Et=new hm(v,S,z,Ot,It,oe,st),mt=new Om(v,Dt),vt=new dm,kt=new vm(Ot),Ut=new Nd(v,S,z,Tt,K,d,l),gt=new wm(v,K,It),I=new zm(L,te,It,Tt),Mt=new Od(L,Ot,te),Yt=new qd(L,Ot,te),te.programs=Et.programs,v.capabilities=It,v.extensions=Ot,v.properties=Dt,v.renderLists=vt,v.shadowMap=gt,v.state=Tt,v.info=te}_t();const $=new Nm(v,L);this.xr=$,this.getContext=function(){return L},this.getContextAttributes=function(){return L.getContextAttributes()},this.forceContextLoss=function(){const w=Ot.get("WEBGL_lose_context");w&&w.loseContext()},this.forceContextRestore=function(){const w=Ot.get("WEBGL_lose_context");w&&w.restoreContext()},this.getPixelRatio=function(){return k},this.setPixelRatio=function(w){w!==void 0&&(k=w,this.setSize(W,j,!1))},this.getSize=function(w){return w.set(W,j)},this.setSize=function(w,N,G=!0){if($.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}W=w,j=N,e.width=Math.floor(w*k),e.height=Math.floor(N*k),G===!0&&(e.style.width=w+"px",e.style.height=N+"px"),this.setViewport(0,0,w,N)},this.getDrawingBufferSize=function(w){return w.set(W*k,j*k).floor()},this.setDrawingBufferSize=function(w,N,G){W=w,j=N,k=G,e.width=Math.floor(w*G),e.height=Math.floor(N*G),this.setViewport(0,0,w,N)},this.getCurrentViewport=function(w){return w.copy(C)},this.getViewport=function(w){return w.copy(tt)},this.setViewport=function(w,N,G,H){w.isVector4?tt.set(w.x,w.y,w.z,w.w):tt.set(w,N,G,H),Tt.viewport(C.copy(tt).multiplyScalar(k).round())},this.getScissor=function(w){return w.copy(rt)},this.setScissor=function(w,N,G,H){w.isVector4?rt.set(w.x,w.y,w.z,w.w):rt.set(w,N,G,H),Tt.scissor(U.copy(rt).multiplyScalar(k).round())},this.getScissorTest=function(){return ut},this.setScissorTest=function(w){Tt.setScissorTest(ut=w)},this.setOpaqueSort=function(w){it=w},this.setTransparentSort=function(w){q=w},this.getClearColor=function(w){return w.copy(Ut.getClearColor())},this.setClearColor=function(){Ut.setClearColor.apply(Ut,arguments)},this.getClearAlpha=function(){return Ut.getClearAlpha()},this.setClearAlpha=function(){Ut.setClearAlpha.apply(Ut,arguments)},this.clear=function(w=!0,N=!0,G=!0){let H=0;if(w){let F=!1;if(P!==null){const ct=P.texture.format;F=ct===$a||ct===qa||ct===Xa}if(F){const ct=P.texture.type,St=ct===Tn||ct===ai||ct===hs||ct===Oi||ct===Ha||ct===Va,At=Ut.getClearColor(),Rt=Ut.getClearAlpha(),Ht=At.r,Wt=At.g,Ct=At.b;St?(g[0]=Ht,g[1]=Wt,g[2]=Ct,g[3]=Rt,L.clearBufferuiv(L.COLOR,0,g)):(_[0]=Ht,_[1]=Wt,_[2]=Ct,_[3]=Rt,L.clearBufferiv(L.COLOR,0,_))}else H|=L.COLOR_BUFFER_BIT}N&&(H|=L.DEPTH_BUFFER_BIT),G&&(H|=L.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),L.clear(H)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){e.removeEventListener("webglcontextlost",Q,!1),e.removeEventListener("webglcontextrestored",bt,!1),e.removeEventListener("webglcontextcreationerror",yt,!1),vt.dispose(),kt.dispose(),Dt.dispose(),S.dispose(),z.dispose(),K.dispose(),oe.dispose(),I.dispose(),Et.dispose(),$.dispose(),$.removeEventListener("sessionstart",ao),$.removeEventListener("sessionend",oo),Gn.stop()};function Q(w){w.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),R=!0}function bt(){console.log("THREE.WebGLRenderer: Context Restored."),R=!1;const w=te.autoReset,N=gt.enabled,G=gt.autoUpdate,H=gt.needsUpdate,F=gt.type;_t(),te.autoReset=w,gt.enabled=N,gt.autoUpdate=G,gt.needsUpdate=H,gt.type=F}function yt(w){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",w.statusMessage)}function Vt(w){const N=w.target;N.removeEventListener("dispose",Vt),pe(N)}function pe(w){Ee(w),Dt.remove(w)}function Ee(w){const N=Dt.get(w).programs;N!==void 0&&(N.forEach(function(G){Et.releaseProgram(G)}),w.isShaderMaterial&&Et.releaseShaderCache(w))}this.renderBufferDirect=function(w,N,G,H,F,ct){N===null&&(N=et);const St=F.isMesh&&F.matrixWorld.determinant()<0,At=Rc(w,N,G,H,F);Tt.setMaterial(H,St);let Rt=G.index,Ht=1;if(H.wireframe===!0){if(Rt=nt.getWireframeAttribute(G),Rt===void 0)return;Ht=2}const Wt=G.drawRange,Ct=G.attributes.position;let Jt=Wt.start*Ht,le=(Wt.start+Wt.count)*Ht;ct!==null&&(Jt=Math.max(Jt,ct.start*Ht),le=Math.min(le,(ct.start+ct.count)*Ht)),Rt!==null?(Jt=Math.max(Jt,0),le=Math.min(le,Rt.count)):Ct!=null&&(Jt=Math.max(Jt,0),le=Math.min(le,Ct.count));const he=le-Jt;if(he<0||he===1/0)return;oe.setup(F,H,At,G,Rt);let Fe,ee=Mt;if(Rt!==null&&(Fe=Z.get(Rt),ee=Yt,ee.setIndex(Fe)),F.isMesh)H.wireframe===!0?(Tt.setLineWidth(H.wireframeLinewidth*zt()),ee.setMode(L.LINES)):ee.setMode(L.TRIANGLES);else if(F.isLine){let Lt=H.linewidth;Lt===void 0&&(Lt=1),Tt.setLineWidth(Lt*zt()),F.isLineSegments?ee.setMode(L.LINES):F.isLineLoop?ee.setMode(L.LINE_LOOP):ee.setMode(L.LINE_STRIP)}else F.isPoints?ee.setMode(L.POINTS):F.isSprite&&ee.setMode(L.TRIANGLES);if(F.isBatchedMesh)if(F._multiDrawInstances!==null)ee.renderMultiDrawInstances(F._multiDrawStarts,F._multiDrawCounts,F._multiDrawCount,F._multiDrawInstances);else if(Ot.get("WEBGL_multi_draw"))ee.renderMultiDraw(F._multiDrawStarts,F._multiDrawCounts,F._multiDrawCount);else{const Lt=F._multiDrawStarts,dn=F._multiDrawCounts,ne=F._multiDrawCount,Ke=Rt?Z.get(Rt).bytesPerElement:1,ui=Dt.get(H).currentProgram.getUniforms();for(let ke=0;ke<ne;ke++)ui.setValue(L,"_gl_DrawID",ke),ee.render(Lt[ke]/Ke,dn[ke])}else if(F.isInstancedMesh)ee.renderInstances(Jt,he,F.count);else if(G.isInstancedBufferGeometry){const Lt=G._maxInstanceCount!==void 0?G._maxInstanceCount:1/0,dn=Math.min(G.instanceCount,Lt);ee.renderInstances(Jt,he,dn)}else ee.render(Jt,he)};function ie(w,N,G){w.transparent===!0&&w.side===Ve&&w.forceSinglePass===!1?(w.side=Ne,w.needsUpdate=!0,ds(w,N,G),w.side=Bn,w.needsUpdate=!0,ds(w,N,G),w.side=Ve):ds(w,N,G)}this.compile=function(w,N,G=null){G===null&&(G=w),p=kt.get(G),p.init(N),y.push(p),G.traverseVisible(function(F){F.isLight&&F.layers.test(N.layers)&&(p.pushLight(F),F.castShadow&&p.pushShadow(F))}),w!==G&&w.traverseVisible(function(F){F.isLight&&F.layers.test(N.layers)&&(p.pushLight(F),F.castShadow&&p.pushShadow(F))}),p.setupLights();const H=new Set;return w.traverse(function(F){if(!(F.isMesh||F.isPoints||F.isLine||F.isSprite))return;const ct=F.material;if(ct)if(Array.isArray(ct))for(let St=0;St<ct.length;St++){const At=ct[St];ie(At,G,F),H.add(At)}else ie(ct,G,F),H.add(ct)}),y.pop(),p=null,H},this.compileAsync=function(w,N,G=null){const H=this.compile(w,N,G);return new Promise(F=>{function ct(){if(H.forEach(function(St){Dt.get(St).currentProgram.isReady()&&H.delete(St)}),H.size===0){F(w);return}setTimeout(ct,10)}Ot.get("KHR_parallel_shader_compile")!==null?ct():setTimeout(ct,10)})};let je=null;function fn(w){je&&je(w)}function ao(){Gn.stop()}function oo(){Gn.start()}const Gn=new dc;Gn.setAnimationLoop(fn),typeof self<"u"&&Gn.setContext(self),this.setAnimationLoop=function(w){je=w,$.setAnimationLoop(w),w===null?Gn.stop():Gn.start()},$.addEventListener("sessionstart",ao),$.addEventListener("sessionend",oo),this.render=function(w,N){if(N!==void 0&&N.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(R===!0)return;if(w.matrixWorldAutoUpdate===!0&&w.updateMatrixWorld(),N.parent===null&&N.matrixWorldAutoUpdate===!0&&N.updateMatrixWorld(),$.enabled===!0&&$.isPresenting===!0&&($.cameraAutoUpdate===!0&&$.updateCamera(N),N=$.getCamera()),w.isScene===!0&&w.onBeforeRender(v,w,N,P),p=kt.get(w,y.length),p.init(N),y.push(p),wt.multiplyMatrices(N.projectionMatrix,N.matrixWorldInverse),B.setFromProjectionMatrix(wt),ht=this.localClippingEnabled,J=st.init(this.clippingPlanes,ht),m=vt.get(w,x.length),m.init(),x.push(m),$.enabled===!0&&$.isPresenting===!0){const ct=v.xr.getDepthSensingMesh();ct!==null&&cr(ct,N,-1/0,v.sortObjects)}cr(w,N,0,v.sortObjects),m.finish(),v.sortObjects===!0&&m.sort(it,q),dt=$.enabled===!1||$.isPresenting===!1||$.hasDepthSensing()===!1,dt&&Ut.addToRenderList(m,w),this.info.render.frame++,J===!0&&st.beginShadows();const G=p.state.shadowsArray;gt.render(G,w,N),J===!0&&st.endShadows(),this.info.autoReset===!0&&this.info.reset();const H=m.opaque,F=m.transmissive;if(p.setupLights(),N.isArrayCamera){const ct=N.cameras;if(F.length>0)for(let St=0,At=ct.length;St<At;St++){const Rt=ct[St];co(H,F,w,Rt)}dt&&Ut.render(w);for(let St=0,At=ct.length;St<At;St++){const Rt=ct[St];lo(m,w,Rt,Rt.viewport)}}else F.length>0&&co(H,F,w,N),dt&&Ut.render(w),lo(m,w,N);P!==null&&(A.updateMultisampleRenderTarget(P),A.updateRenderTargetMipmap(P)),w.isScene===!0&&w.onAfterRender(v,w,N),oe.resetDefaultState(),b=-1,M=null,y.pop(),y.length>0?(p=y[y.length-1],J===!0&&st.setGlobalState(v.clippingPlanes,p.state.camera)):p=null,x.pop(),x.length>0?m=x[x.length-1]:m=null};function cr(w,N,G,H){if(w.visible===!1)return;if(w.layers.test(N.layers)){if(w.isGroup)G=w.renderOrder;else if(w.isLOD)w.autoUpdate===!0&&w.update(N);else if(w.isLight)p.pushLight(w),w.castShadow&&p.pushShadow(w);else if(w.isSprite){if(!w.frustumCulled||B.intersectsSprite(w)){H&&Y.setFromMatrixPosition(w.matrixWorld).applyMatrix4(wt);const St=K.update(w),At=w.material;At.visible&&m.push(w,St,At,G,Y.z,null)}}else if((w.isMesh||w.isLine||w.isPoints)&&(!w.frustumCulled||B.intersectsObject(w))){const St=K.update(w),At=w.material;if(H&&(w.boundingSphere!==void 0?(w.boundingSphere===null&&w.computeBoundingSphere(),Y.copy(w.boundingSphere.center)):(St.boundingSphere===null&&St.computeBoundingSphere(),Y.copy(St.boundingSphere.center)),Y.applyMatrix4(w.matrixWorld).applyMatrix4(wt)),Array.isArray(At)){const Rt=St.groups;for(let Ht=0,Wt=Rt.length;Ht<Wt;Ht++){const Ct=Rt[Ht],Jt=At[Ct.materialIndex];Jt&&Jt.visible&&m.push(w,St,Jt,G,Y.z,Ct)}}else At.visible&&m.push(w,St,At,G,Y.z,null)}}const ct=w.children;for(let St=0,At=ct.length;St<At;St++)cr(ct[St],N,G,H)}function lo(w,N,G,H){const F=w.opaque,ct=w.transmissive,St=w.transparent;p.setupLightsView(G),J===!0&&st.setGlobalState(v.clippingPlanes,G),H&&Tt.viewport(C.copy(H)),F.length>0&&fs(F,N,G),ct.length>0&&fs(ct,N,G),St.length>0&&fs(St,N,G),Tt.buffers.depth.setTest(!0),Tt.buffers.depth.setMask(!0),Tt.buffers.color.setMask(!0),Tt.setPolygonOffset(!1)}function co(w,N,G,H){if((G.isScene===!0?G.overrideMaterial:null)!==null)return;p.state.transmissionRenderTarget[H.id]===void 0&&(p.state.transmissionRenderTarget[H.id]=new sn(1,1,{generateMipmaps:!0,type:Ot.has("EXT_color_buffer_half_float")||Ot.has("EXT_color_buffer_float")?bn:Tn,minFilter:ii,samples:4,stencilBuffer:s,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:jt.workingColorSpace}));const ct=p.state.transmissionRenderTarget[H.id],St=H.viewport||C;ct.setSize(St.z,St.w);const At=v.getRenderTarget();v.setRenderTarget(ct),v.getClearColor(V),X=v.getClearAlpha(),X<1&&v.setClearColor(16777215,.5),v.clear(),dt&&Ut.render(G);const Rt=v.toneMapping;v.toneMapping=zn;const Ht=H.viewport;if(H.viewport!==void 0&&(H.viewport=void 0),p.setupLightsView(H),J===!0&&st.setGlobalState(v.clippingPlanes,H),fs(w,G,H),A.updateMultisampleRenderTarget(ct),A.updateRenderTargetMipmap(ct),Ot.has("WEBGL_multisampled_render_to_texture")===!1){let Wt=!1;for(let Ct=0,Jt=N.length;Ct<Jt;Ct++){const le=N[Ct],he=le.object,Fe=le.geometry,ee=le.material,Lt=le.group;if(ee.side===Ve&&he.layers.test(H.layers)){const dn=ee.side;ee.side=Ne,ee.needsUpdate=!0,ho(he,G,H,Fe,ee,Lt),ee.side=dn,ee.needsUpdate=!0,Wt=!0}}Wt===!0&&(A.updateMultisampleRenderTarget(ct),A.updateRenderTargetMipmap(ct))}v.setRenderTarget(At),v.setClearColor(V,X),Ht!==void 0&&(H.viewport=Ht),v.toneMapping=Rt}function fs(w,N,G){const H=N.isScene===!0?N.overrideMaterial:null;for(let F=0,ct=w.length;F<ct;F++){const St=w[F],At=St.object,Rt=St.geometry,Ht=H===null?St.material:H,Wt=St.group;At.layers.test(G.layers)&&ho(At,N,G,Rt,Ht,Wt)}}function ho(w,N,G,H,F,ct){w.onBeforeRender(v,N,G,H,F,ct),w.modelViewMatrix.multiplyMatrices(G.matrixWorldInverse,w.matrixWorld),w.normalMatrix.getNormalMatrix(w.modelViewMatrix),F.onBeforeRender(v,N,G,H,w,ct),F.transparent===!0&&F.side===Ve&&F.forceSinglePass===!1?(F.side=Ne,F.needsUpdate=!0,v.renderBufferDirect(G,N,H,F,w,ct),F.side=Bn,F.needsUpdate=!0,v.renderBufferDirect(G,N,H,F,w,ct),F.side=Ve):v.renderBufferDirect(G,N,H,F,w,ct),w.onAfterRender(v,N,G,H,F,ct)}function ds(w,N,G){N.isScene!==!0&&(N=et);const H=Dt.get(w),F=p.state.lights,ct=p.state.shadowsArray,St=F.state.version,At=Et.getParameters(w,F.state,ct,N,G),Rt=Et.getProgramCacheKey(At);let Ht=H.programs;H.environment=w.isMeshStandardMaterial?N.environment:null,H.fog=N.fog,H.envMap=(w.isMeshStandardMaterial?z:S).get(w.envMap||H.environment),H.envMapRotation=H.environment!==null&&w.envMap===null?N.environmentRotation:w.envMapRotation,Ht===void 0&&(w.addEventListener("dispose",Vt),Ht=new Map,H.programs=Ht);let Wt=Ht.get(Rt);if(Wt!==void 0){if(H.currentProgram===Wt&&H.lightsStateVersion===St)return fo(w,At),Wt}else At.uniforms=Et.getUniforms(w),w.onBeforeCompile(At,v),Wt=Et.acquireProgram(At,Rt),Ht.set(Rt,Wt),H.uniforms=At.uniforms;const Ct=H.uniforms;return(!w.isShaderMaterial&&!w.isRawShaderMaterial||w.clipping===!0)&&(Ct.clippingPlanes=st.uniform),fo(w,At),H.needsLights=Pc(w),H.lightsStateVersion=St,H.needsLights&&(Ct.ambientLightColor.value=F.state.ambient,Ct.lightProbe.value=F.state.probe,Ct.directionalLights.value=F.state.directional,Ct.directionalLightShadows.value=F.state.directionalShadow,Ct.spotLights.value=F.state.spot,Ct.spotLightShadows.value=F.state.spotShadow,Ct.rectAreaLights.value=F.state.rectArea,Ct.ltc_1.value=F.state.rectAreaLTC1,Ct.ltc_2.value=F.state.rectAreaLTC2,Ct.pointLights.value=F.state.point,Ct.pointLightShadows.value=F.state.pointShadow,Ct.hemisphereLights.value=F.state.hemi,Ct.directionalShadowMap.value=F.state.directionalShadowMap,Ct.directionalShadowMatrix.value=F.state.directionalShadowMatrix,Ct.spotShadowMap.value=F.state.spotShadowMap,Ct.spotLightMatrix.value=F.state.spotLightMatrix,Ct.spotLightMap.value=F.state.spotLightMap,Ct.pointShadowMap.value=F.state.pointShadowMap,Ct.pointShadowMatrix.value=F.state.pointShadowMatrix),H.currentProgram=Wt,H.uniformsList=null,Wt}function uo(w){if(w.uniformsList===null){const N=w.currentProgram.getUniforms();w.uniformsList=js.seqWithValue(N.seq,w.uniforms)}return w.uniformsList}function fo(w,N){const G=Dt.get(w);G.outputColorSpace=N.outputColorSpace,G.batching=N.batching,G.batchingColor=N.batchingColor,G.instancing=N.instancing,G.instancingColor=N.instancingColor,G.instancingMorph=N.instancingMorph,G.skinning=N.skinning,G.morphTargets=N.morphTargets,G.morphNormals=N.morphNormals,G.morphColors=N.morphColors,G.morphTargetsCount=N.morphTargetsCount,G.numClippingPlanes=N.numClippingPlanes,G.numIntersection=N.numClipIntersection,G.vertexAlphas=N.vertexAlphas,G.vertexTangents=N.vertexTangents,G.toneMapping=N.toneMapping}function Rc(w,N,G,H,F){N.isScene!==!0&&(N=et),A.resetTextureUnits();const ct=N.fog,St=H.isMeshStandardMaterial?N.environment:null,At=P===null?v.outputColorSpace:P.isXRRenderTarget===!0?P.texture.colorSpace:Hi,Rt=(H.isMeshStandardMaterial?z:S).get(H.envMap||St),Ht=H.vertexColors===!0&&!!G.attributes.color&&G.attributes.color.itemSize===4,Wt=!!G.attributes.tangent&&(!!H.normalMap||H.anisotropy>0),Ct=!!G.morphAttributes.position,Jt=!!G.morphAttributes.normal,le=!!G.morphAttributes.color;let he=zn;H.toneMapped&&(P===null||P.isXRRenderTarget===!0)&&(he=v.toneMapping);const Fe=G.morphAttributes.position||G.morphAttributes.normal||G.morphAttributes.color,ee=Fe!==void 0?Fe.length:0,Lt=Dt.get(H),dn=p.state.lights;if(J===!0&&(ht===!0||w!==M)){const Xe=w===M&&H.id===b;st.setState(H,w,Xe)}let ne=!1;H.version===Lt.__version?(Lt.needsLights&&Lt.lightsStateVersion!==dn.state.version||Lt.outputColorSpace!==At||F.isBatchedMesh&&Lt.batching===!1||!F.isBatchedMesh&&Lt.batching===!0||F.isBatchedMesh&&Lt.batchingColor===!0&&F.colorTexture===null||F.isBatchedMesh&&Lt.batchingColor===!1&&F.colorTexture!==null||F.isInstancedMesh&&Lt.instancing===!1||!F.isInstancedMesh&&Lt.instancing===!0||F.isSkinnedMesh&&Lt.skinning===!1||!F.isSkinnedMesh&&Lt.skinning===!0||F.isInstancedMesh&&Lt.instancingColor===!0&&F.instanceColor===null||F.isInstancedMesh&&Lt.instancingColor===!1&&F.instanceColor!==null||F.isInstancedMesh&&Lt.instancingMorph===!0&&F.morphTexture===null||F.isInstancedMesh&&Lt.instancingMorph===!1&&F.morphTexture!==null||Lt.envMap!==Rt||H.fog===!0&&Lt.fog!==ct||Lt.numClippingPlanes!==void 0&&(Lt.numClippingPlanes!==st.numPlanes||Lt.numIntersection!==st.numIntersection)||Lt.vertexAlphas!==Ht||Lt.vertexTangents!==Wt||Lt.morphTargets!==Ct||Lt.morphNormals!==Jt||Lt.morphColors!==le||Lt.toneMapping!==he||Lt.morphTargetsCount!==ee)&&(ne=!0):(ne=!0,Lt.__version=H.version);let Ke=Lt.currentProgram;ne===!0&&(Ke=ds(H,N,F));let ui=!1,ke=!1,$i=!1;const ue=Ke.getUniforms(),an=Lt.uniforms;if(Tt.useProgram(Ke.program)&&(ui=!0,ke=!0,$i=!0),H.id!==b&&(b=H.id,ke=!0),ui||M!==w){Tt.buffers.depth.getReversed()?(at.copy(w.projectionMatrix),Ch(at),Ph(at),ue.setValue(L,"projectionMatrix",at)):ue.setValue(L,"projectionMatrix",w.projectionMatrix),ue.setValue(L,"viewMatrix",w.matrixWorldInverse);const An=ue.map.cameraPosition;An!==void 0&&An.setValue(L,xt.setFromMatrixPosition(w.matrixWorld)),It.logarithmicDepthBuffer&&ue.setValue(L,"logDepthBufFC",2/(Math.log(w.far+1)/Math.LN2)),(H.isMeshPhongMaterial||H.isMeshToonMaterial||H.isMeshLambertMaterial||H.isMeshBasicMaterial||H.isMeshStandardMaterial||H.isShaderMaterial)&&ue.setValue(L,"isOrthographic",w.isOrthographicCamera===!0),M!==w&&(M=w,ke=!0,$i=!0)}if(F.isSkinnedMesh){ue.setOptional(L,F,"bindMatrix"),ue.setOptional(L,F,"bindMatrixInverse");const Xe=F.skeleton;Xe&&(Xe.boneTexture===null&&Xe.computeBoneTexture(),ue.setValue(L,"boneTexture",Xe.boneTexture,A))}F.isBatchedMesh&&(ue.setOptional(L,F,"batchingTexture"),ue.setValue(L,"batchingTexture",F._matricesTexture,A),ue.setOptional(L,F,"batchingIdTexture"),ue.setValue(L,"batchingIdTexture",F._indirectTexture,A),ue.setOptional(L,F,"batchingColorTexture"),F._colorsTexture!==null&&ue.setValue(L,"batchingColorTexture",F._colorsTexture,A));const Yi=G.morphAttributes;if((Yi.position!==void 0||Yi.normal!==void 0||Yi.color!==void 0)&&Nt.update(F,G,Ke),(ke||Lt.receiveShadow!==F.receiveShadow)&&(Lt.receiveShadow=F.receiveShadow,ue.setValue(L,"receiveShadow",F.receiveShadow)),H.isMeshGouraudMaterial&&H.envMap!==null&&(an.envMap.value=Rt,an.flipEnvMap.value=Rt.isCubeTexture&&Rt.isRenderTargetTexture===!1?-1:1),H.isMeshStandardMaterial&&H.envMap===null&&N.environment!==null&&(an.envMapIntensity.value=N.environmentIntensity),ke&&(ue.setValue(L,"toneMappingExposure",v.toneMappingExposure),Lt.needsLights&&Cc(an,$i),ct&&H.fog===!0&&mt.refreshFogUniforms(an,ct),mt.refreshMaterialUniforms(an,H,k,j,p.state.transmissionRenderTarget[w.id]),js.upload(L,uo(Lt),an,A)),H.isShaderMaterial&&H.uniformsNeedUpdate===!0&&(js.upload(L,uo(Lt),an,A),H.uniformsNeedUpdate=!1),H.isSpriteMaterial&&ue.setValue(L,"center",F.center),ue.setValue(L,"modelViewMatrix",F.modelViewMatrix),ue.setValue(L,"normalMatrix",F.normalMatrix),ue.setValue(L,"modelMatrix",F.matrixWorld),H.isShaderMaterial||H.isRawShaderMaterial){const Xe=H.uniformsGroups;for(let An=0,Rn=Xe.length;An<Rn;An++){const po=Xe[An];I.update(po,Ke),I.bind(po,Ke)}}return Ke}function Cc(w,N){w.ambientLightColor.needsUpdate=N,w.lightProbe.needsUpdate=N,w.directionalLights.needsUpdate=N,w.directionalLightShadows.needsUpdate=N,w.pointLights.needsUpdate=N,w.pointLightShadows.needsUpdate=N,w.spotLights.needsUpdate=N,w.spotLightShadows.needsUpdate=N,w.rectAreaLights.needsUpdate=N,w.hemisphereLights.needsUpdate=N}function Pc(w){return w.isMeshLambertMaterial||w.isMeshToonMaterial||w.isMeshPhongMaterial||w.isMeshStandardMaterial||w.isShadowMaterial||w.isShaderMaterial&&w.lights===!0}this.getActiveCubeFace=function(){return T},this.getActiveMipmapLevel=function(){return E},this.getRenderTarget=function(){return P},this.setRenderTargetTextures=function(w,N,G){Dt.get(w.texture).__webglTexture=N,Dt.get(w.depthTexture).__webglTexture=G;const H=Dt.get(w);H.__hasExternalTextures=!0,H.__autoAllocateDepthBuffer=G===void 0,H.__autoAllocateDepthBuffer||Ot.has("WEBGL_multisampled_render_to_texture")===!0&&(console.warn("THREE.WebGLRenderer: Render-to-texture extension was disabled because an external texture was provided"),H.__useRenderToTexture=!1)},this.setRenderTargetFramebuffer=function(w,N){const G=Dt.get(w);G.__webglFramebuffer=N,G.__useDefaultFramebuffer=N===void 0},this.setRenderTarget=function(w,N=0,G=0){P=w,T=N,E=G;let H=!0,F=null,ct=!1,St=!1;if(w){const Rt=Dt.get(w);if(Rt.__useDefaultFramebuffer!==void 0)Tt.bindFramebuffer(L.FRAMEBUFFER,null),H=!1;else if(Rt.__webglFramebuffer===void 0)A.setupRenderTarget(w);else if(Rt.__hasExternalTextures)A.rebindTextures(w,Dt.get(w.texture).__webglTexture,Dt.get(w.depthTexture).__webglTexture);else if(w.depthBuffer){const Ct=w.depthTexture;if(Rt.__boundDepthTexture!==Ct){if(Ct!==null&&Dt.has(Ct)&&(w.width!==Ct.image.width||w.height!==Ct.image.height))throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");A.setupDepthRenderbuffer(w)}}const Ht=w.texture;(Ht.isData3DTexture||Ht.isDataArrayTexture||Ht.isCompressedArrayTexture)&&(St=!0);const Wt=Dt.get(w).__webglFramebuffer;w.isWebGLCubeRenderTarget?(Array.isArray(Wt[N])?F=Wt[N][G]:F=Wt[N],ct=!0):w.samples>0&&A.useMultisampledRTT(w)===!1?F=Dt.get(w).__webglMultisampledFramebuffer:Array.isArray(Wt)?F=Wt[G]:F=Wt,C.copy(w.viewport),U.copy(w.scissor),O=w.scissorTest}else C.copy(tt).multiplyScalar(k).floor(),U.copy(rt).multiplyScalar(k).floor(),O=ut;if(Tt.bindFramebuffer(L.FRAMEBUFFER,F)&&H&&Tt.drawBuffers(w,F),Tt.viewport(C),Tt.scissor(U),Tt.setScissorTest(O),ct){const Rt=Dt.get(w.texture);L.framebufferTexture2D(L.FRAMEBUFFER,L.COLOR_ATTACHMENT0,L.TEXTURE_CUBE_MAP_POSITIVE_X+N,Rt.__webglTexture,G)}else if(St){const Rt=Dt.get(w.texture),Ht=N||0;L.framebufferTextureLayer(L.FRAMEBUFFER,L.COLOR_ATTACHMENT0,Rt.__webglTexture,G||0,Ht)}b=-1},this.readRenderTargetPixels=function(w,N,G,H,F,ct,St){if(!(w&&w.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let At=Dt.get(w).__webglFramebuffer;if(w.isWebGLCubeRenderTarget&&St!==void 0&&(At=At[St]),At){Tt.bindFramebuffer(L.FRAMEBUFFER,At);try{const Rt=w.texture,Ht=Rt.format,Wt=Rt.type;if(!It.textureFormatReadable(Ht)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!It.textureTypeReadable(Wt)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}N>=0&&N<=w.width-H&&G>=0&&G<=w.height-F&&L.readPixels(N,G,H,F,qt.convert(Ht),qt.convert(Wt),ct)}finally{const Rt=P!==null?Dt.get(P).__webglFramebuffer:null;Tt.bindFramebuffer(L.FRAMEBUFFER,Rt)}}},this.readRenderTargetPixelsAsync=async function(w,N,G,H,F,ct,St){if(!(w&&w.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let At=Dt.get(w).__webglFramebuffer;if(w.isWebGLCubeRenderTarget&&St!==void 0&&(At=At[St]),At){const Rt=w.texture,Ht=Rt.format,Wt=Rt.type;if(!It.textureFormatReadable(Ht))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!It.textureTypeReadable(Wt))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");if(N>=0&&N<=w.width-H&&G>=0&&G<=w.height-F){Tt.bindFramebuffer(L.FRAMEBUFFER,At);const Ct=L.createBuffer();L.bindBuffer(L.PIXEL_PACK_BUFFER,Ct),L.bufferData(L.PIXEL_PACK_BUFFER,ct.byteLength,L.STREAM_READ),L.readPixels(N,G,H,F,qt.convert(Ht),qt.convert(Wt),0);const Jt=P!==null?Dt.get(P).__webglFramebuffer:null;Tt.bindFramebuffer(L.FRAMEBUFFER,Jt);const le=L.fenceSync(L.SYNC_GPU_COMMANDS_COMPLETE,0);return L.flush(),await Rh(L,le,4),L.bindBuffer(L.PIXEL_PACK_BUFFER,Ct),L.getBufferSubData(L.PIXEL_PACK_BUFFER,0,ct),L.deleteBuffer(Ct),L.deleteSync(le),ct}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")}},this.copyFramebufferToTexture=function(w,N=null,G=0){w.isTexture!==!0&&(rs("WebGLRenderer: copyFramebufferToTexture function signature has changed."),N=arguments[0]||null,w=arguments[1]);const H=Math.pow(2,-G),F=Math.floor(w.image.width*H),ct=Math.floor(w.image.height*H),St=N!==null?N.x:0,At=N!==null?N.y:0;A.setTexture2D(w,0),L.copyTexSubImage2D(L.TEXTURE_2D,G,0,0,St,At,F,ct),Tt.unbindTexture()},this.copyTextureToTexture=function(w,N,G=null,H=null,F=0){w.isTexture!==!0&&(rs("WebGLRenderer: copyTextureToTexture function signature has changed."),H=arguments[0]||null,w=arguments[1],N=arguments[2],F=arguments[3]||0,G=null);let ct,St,At,Rt,Ht,Wt,Ct,Jt,le;const he=w.isCompressedTexture?w.mipmaps[F]:w.image;G!==null?(ct=G.max.x-G.min.x,St=G.max.y-G.min.y,At=G.isBox3?G.max.z-G.min.z:1,Rt=G.min.x,Ht=G.min.y,Wt=G.isBox3?G.min.z:0):(ct=he.width,St=he.height,At=he.depth||1,Rt=0,Ht=0,Wt=0),H!==null?(Ct=H.x,Jt=H.y,le=H.z):(Ct=0,Jt=0,le=0);const Fe=qt.convert(N.format),ee=qt.convert(N.type);let Lt;N.isData3DTexture?(A.setTexture3D(N,0),Lt=L.TEXTURE_3D):N.isDataArrayTexture||N.isCompressedArrayTexture?(A.setTexture2DArray(N,0),Lt=L.TEXTURE_2D_ARRAY):(A.setTexture2D(N,0),Lt=L.TEXTURE_2D),L.pixelStorei(L.UNPACK_FLIP_Y_WEBGL,N.flipY),L.pixelStorei(L.UNPACK_PREMULTIPLY_ALPHA_WEBGL,N.premultiplyAlpha),L.pixelStorei(L.UNPACK_ALIGNMENT,N.unpackAlignment);const dn=L.getParameter(L.UNPACK_ROW_LENGTH),ne=L.getParameter(L.UNPACK_IMAGE_HEIGHT),Ke=L.getParameter(L.UNPACK_SKIP_PIXELS),ui=L.getParameter(L.UNPACK_SKIP_ROWS),ke=L.getParameter(L.UNPACK_SKIP_IMAGES);L.pixelStorei(L.UNPACK_ROW_LENGTH,he.width),L.pixelStorei(L.UNPACK_IMAGE_HEIGHT,he.height),L.pixelStorei(L.UNPACK_SKIP_PIXELS,Rt),L.pixelStorei(L.UNPACK_SKIP_ROWS,Ht),L.pixelStorei(L.UNPACK_SKIP_IMAGES,Wt);const $i=w.isDataArrayTexture||w.isData3DTexture,ue=N.isDataArrayTexture||N.isData3DTexture;if(w.isRenderTargetTexture||w.isDepthTexture){const an=Dt.get(w),Yi=Dt.get(N),Xe=Dt.get(an.__renderTarget),An=Dt.get(Yi.__renderTarget);Tt.bindFramebuffer(L.READ_FRAMEBUFFER,Xe.__webglFramebuffer),Tt.bindFramebuffer(L.DRAW_FRAMEBUFFER,An.__webglFramebuffer);for(let Rn=0;Rn<At;Rn++)$i&&L.framebufferTextureLayer(L.READ_FRAMEBUFFER,L.COLOR_ATTACHMENT0,Dt.get(w).__webglTexture,F,Wt+Rn),w.isDepthTexture?(ue&&L.framebufferTextureLayer(L.DRAW_FRAMEBUFFER,L.COLOR_ATTACHMENT0,Dt.get(N).__webglTexture,F,le+Rn),L.blitFramebuffer(Rt,Ht,ct,St,Ct,Jt,ct,St,L.DEPTH_BUFFER_BIT,L.NEAREST)):ue?L.copyTexSubImage3D(Lt,F,Ct,Jt,le+Rn,Rt,Ht,ct,St):L.copyTexSubImage2D(Lt,F,Ct,Jt,le+Rn,Rt,Ht,ct,St);Tt.bindFramebuffer(L.READ_FRAMEBUFFER,null),Tt.bindFramebuffer(L.DRAW_FRAMEBUFFER,null)}else ue?w.isDataTexture||w.isData3DTexture?L.texSubImage3D(Lt,F,Ct,Jt,le,ct,St,At,Fe,ee,he.data):N.isCompressedArrayTexture?L.compressedTexSubImage3D(Lt,F,Ct,Jt,le,ct,St,At,Fe,he.data):L.texSubImage3D(Lt,F,Ct,Jt,le,ct,St,At,Fe,ee,he):w.isDataTexture?L.texSubImage2D(L.TEXTURE_2D,F,Ct,Jt,ct,St,Fe,ee,he.data):w.isCompressedTexture?L.compressedTexSubImage2D(L.TEXTURE_2D,F,Ct,Jt,he.width,he.height,Fe,he.data):L.texSubImage2D(L.TEXTURE_2D,F,Ct,Jt,ct,St,Fe,ee,he);L.pixelStorei(L.UNPACK_ROW_LENGTH,dn),L.pixelStorei(L.UNPACK_IMAGE_HEIGHT,ne),L.pixelStorei(L.UNPACK_SKIP_PIXELS,Ke),L.pixelStorei(L.UNPACK_SKIP_ROWS,ui),L.pixelStorei(L.UNPACK_SKIP_IMAGES,ke),F===0&&N.generateMipmaps&&L.generateMipmap(Lt),Tt.unbindTexture()},this.copyTextureToTexture3D=function(w,N,G=null,H=null,F=0){return w.isTexture!==!0&&(rs("WebGLRenderer: copyTextureToTexture3D function signature has changed."),G=arguments[0]||null,H=arguments[1]||null,w=arguments[2],N=arguments[3],F=arguments[4]||0),rs('WebGLRenderer: copyTextureToTexture3D function has been deprecated. Use "copyTextureToTexture" instead.'),this.copyTextureToTexture(w,N,G,H,F)},this.initRenderTarget=function(w){Dt.get(w).__webglFramebuffer===void 0&&A.setupRenderTarget(w)},this.initTexture=function(w){w.isCubeTexture?A.setTextureCube(w,0):w.isData3DTexture?A.setTexture3D(w,0):w.isDataArrayTexture||w.isCompressedArrayTexture?A.setTexture2DArray(w,0):A.setTexture2D(w,0),Tt.unbindTexture()},this.resetState=function(){T=0,E=0,P=null,Tt.reset(),oe.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return yn}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(t){this._outputColorSpace=t;const e=this.getContext();e.drawingBufferColorspace=jt._getDrawingBufferColorSpace(t),e.unpackColorSpace=jt._getUnpackColorSpace()}}class Qa{constructor(t,e=25e-5){this.isFogExp2=!0,this.name="",this.color=new Pt(t),this.density=e}clone(){return new Qa(this.color,this.density)}toJSON(){return{type:"FogExp2",name:this.name,color:this.color.getHex(),density:this.density}}}class vc extends fe{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new rn,this.environmentIntensity=1,this.environmentRotation=new rn,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(t,e){return super.copy(t,e),t.background!==null&&(this.background=t.background.clone()),t.environment!==null&&(this.environment=t.environment.clone()),t.fog!==null&&(this.fog=t.fog.clone()),this.backgroundBlurriness=t.backgroundBlurriness,this.backgroundIntensity=t.backgroundIntensity,this.backgroundRotation.copy(t.backgroundRotation),this.environmentIntensity=t.environmentIntensity,this.environmentRotation.copy(t.environmentRotation),t.overrideMaterial!==null&&(this.overrideMaterial=t.overrideMaterial.clone()),this.matrixAutoUpdate=t.matrixAutoUpdate,this}toJSON(t){const e=super.toJSON(t);return this.fog!==null&&(e.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(e.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(e.object.backgroundIntensity=this.backgroundIntensity),e.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(e.object.environmentIntensity=this.environmentIntensity),e.object.environmentRotation=this.environmentRotation.toArray(),e}}class Bm extends Ce{constructor(t=null,e=1,n=1,i,s,a,o,l,c=We,h=We,u,f){super(null,a,o,l,c,h,i,s,u,f),this.isDataTexture=!0,this.image={data:t,width:e,height:n},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class fl extends xe{constructor(t,e,n,i=1){super(t,e,n),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=i}copy(t){return super.copy(t),this.meshPerAttribute=t.meshPerAttribute,this}toJSON(){const t=super.toJSON();return t.meshPerAttribute=this.meshPerAttribute,t.isInstancedBufferAttribute=!0,t}}const Ei=new Zt,dl=new Zt,Ns=[],pl=new li,Gm=new Zt,Qi=new ot,ts=new ci;class Jn extends ot{constructor(t,e,n){super(t,e),this.isInstancedMesh=!0,this.instanceMatrix=new fl(new Float32Array(n*16),16),this.instanceColor=null,this.morphTexture=null,this.count=n,this.boundingBox=null,this.boundingSphere=null;for(let i=0;i<n;i++)this.setMatrixAt(i,Gm)}computeBoundingBox(){const t=this.geometry,e=this.count;this.boundingBox===null&&(this.boundingBox=new li),t.boundingBox===null&&t.computeBoundingBox(),this.boundingBox.makeEmpty();for(let n=0;n<e;n++)this.getMatrixAt(n,Ei),pl.copy(t.boundingBox).applyMatrix4(Ei),this.boundingBox.union(pl)}computeBoundingSphere(){const t=this.geometry,e=this.count;this.boundingSphere===null&&(this.boundingSphere=new ci),t.boundingSphere===null&&t.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let n=0;n<e;n++)this.getMatrixAt(n,Ei),ts.copy(t.boundingSphere).applyMatrix4(Ei),this.boundingSphere.union(ts)}copy(t,e){return super.copy(t,e),this.instanceMatrix.copy(t.instanceMatrix),t.morphTexture!==null&&(this.morphTexture=t.morphTexture.clone()),t.instanceColor!==null&&(this.instanceColor=t.instanceColor.clone()),this.count=t.count,t.boundingBox!==null&&(this.boundingBox=t.boundingBox.clone()),t.boundingSphere!==null&&(this.boundingSphere=t.boundingSphere.clone()),this}getColorAt(t,e){e.fromArray(this.instanceColor.array,t*3)}getMatrixAt(t,e){e.fromArray(this.instanceMatrix.array,t*16)}getMorphAt(t,e){const n=e.morphTargetInfluences,i=this.morphTexture.source.data.data,s=n.length+1,a=t*s+1;for(let o=0;o<n.length;o++)n[o]=i[a+o]}raycast(t,e){const n=this.matrixWorld,i=this.count;if(Qi.geometry=this.geometry,Qi.material=this.material,Qi.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),ts.copy(this.boundingSphere),ts.applyMatrix4(n),t.ray.intersectsSphere(ts)!==!1))for(let s=0;s<i;s++){this.getMatrixAt(s,Ei),dl.multiplyMatrices(n,Ei),Qi.matrixWorld=dl,Qi.raycast(t,Ns);for(let a=0,o=Ns.length;a<o;a++){const l=Ns[a];l.instanceId=s,l.object=this,e.push(l)}Ns.length=0}}setColorAt(t,e){this.instanceColor===null&&(this.instanceColor=new fl(new Float32Array(this.instanceMatrix.count*3).fill(1),3)),e.toArray(this.instanceColor.array,t*3)}setMatrixAt(t,e){e.toArray(this.instanceMatrix.array,t*16)}setMorphAt(t,e){const n=e.morphTargetInfluences,i=n.length+1;this.morphTexture===null&&(this.morphTexture=new Bm(new Float32Array(i*this.count),i,this.count,Wa,hn));const s=this.morphTexture.source.data.data;let a=0;for(let c=0;c<n.length;c++)a+=n[c];const o=this.geometry.morphTargetsRelative?1:1-a,l=i*t;s[l]=o,s.set(n,l+1)}updateMorphTargets(){}dispose(){return this.dispatchEvent({type:"dispose"}),this.morphTexture!==null&&(this.morphTexture.dispose(),this.morphTexture=null),this}}class Hm extends hi{static get type(){return"LineBasicMaterial"}constructor(t){super(),this.isLineBasicMaterial=!0,this.color=new Pt(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.linewidth=t.linewidth,this.linecap=t.linecap,this.linejoin=t.linejoin,this.fog=t.fog,this}}const tr=new D,er=new D,ml=new Zt,es=new ja,Fs=new ci,zr=new D,gl=new D;class Vm extends fe{constructor(t=new de,e=new Hm){super(),this.isLine=!0,this.type="Line",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}computeLineDistances(){const t=this.geometry;if(t.index===null){const e=t.attributes.position,n=[0];for(let i=1,s=e.count;i<s;i++)tr.fromBufferAttribute(e,i-1),er.fromBufferAttribute(e,i),n[i]=n[i-1],n[i]+=tr.distanceTo(er);t.setAttribute("lineDistance",new Kt(n,1))}else console.warn("THREE.Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}raycast(t,e){const n=this.geometry,i=this.matrixWorld,s=t.params.Line.threshold,a=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),Fs.copy(n.boundingSphere),Fs.applyMatrix4(i),Fs.radius+=s,t.ray.intersectsSphere(Fs)===!1)return;ml.copy(i).invert(),es.copy(t.ray).applyMatrix4(ml);const o=s/((this.scale.x+this.scale.y+this.scale.z)/3),l=o*o,c=this.isLineSegments?2:1,h=n.index,f=n.attributes.position;if(h!==null){const d=Math.max(0,a.start),g=Math.min(h.count,a.start+a.count);for(let _=d,m=g-1;_<m;_+=c){const p=h.getX(_),x=h.getX(_+1),y=Os(this,t,es,l,p,x);y&&e.push(y)}if(this.isLineLoop){const _=h.getX(g-1),m=h.getX(d),p=Os(this,t,es,l,_,m);p&&e.push(p)}}else{const d=Math.max(0,a.start),g=Math.min(f.count,a.start+a.count);for(let _=d,m=g-1;_<m;_+=c){const p=Os(this,t,es,l,_,_+1);p&&e.push(p)}if(this.isLineLoop){const _=Os(this,t,es,l,g-1,d);_&&e.push(_)}}}updateMorphTargets(){const e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){const i=e[n[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,a=i.length;s<a;s++){const o=i[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=s}}}}}function Os(r,t,e,n,i,s){const a=r.geometry.attributes.position;if(tr.fromBufferAttribute(a,i),er.fromBufferAttribute(a,s),e.distanceSqToSegment(tr,er,zr,gl)>n)return;zr.applyMatrix4(r.matrixWorld);const l=t.ray.origin.distanceTo(zr);if(!(l<t.near||l>t.far))return{distance:l,point:gl.clone().applyMatrix4(r.matrixWorld),index:i,face:null,faceIndex:null,barycoord:null,object:r}}const _l=new D,xl=new D;class Wm extends Vm{constructor(t,e){super(t,e),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){const t=this.geometry;if(t.index===null){const e=t.attributes.position,n=[];for(let i=0,s=e.count;i<s;i+=2)_l.fromBufferAttribute(e,i),xl.fromBufferAttribute(e,i+1),n[i]=i===0?0:n[i-1],n[i+1]=n[i]+_l.distanceTo(xl);t.setAttribute("lineDistance",new Kt(n,1))}else console.warn("THREE.LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}}class Xm extends hi{static get type(){return"PointsMaterial"}constructor(t){super(),this.isPointsMaterial=!0,this.color=new Pt(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.size=t.size,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}}const vl=new Zt,Oa=new ja,zs=new ci,ks=new D;class qm extends fe{constructor(t=new de,e=new Xm){super(),this.isPoints=!0,this.type="Points",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}raycast(t,e){const n=this.geometry,i=this.matrixWorld,s=t.params.Points.threshold,a=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),zs.copy(n.boundingSphere),zs.applyMatrix4(i),zs.radius+=s,t.ray.intersectsSphere(zs)===!1)return;vl.copy(i).invert(),Oa.copy(t.ray).applyMatrix4(vl);const o=s/((this.scale.x+this.scale.y+this.scale.z)/3),l=o*o,c=n.index,u=n.attributes.position;if(c!==null){const f=Math.max(0,a.start),d=Math.min(c.count,a.start+a.count);for(let g=f,_=d;g<_;g++){const m=c.getX(g);ks.fromBufferAttribute(u,m),Ml(ks,m,l,i,t,e,this)}}else{const f=Math.max(0,a.start),d=Math.min(u.count,a.start+a.count);for(let g=f,_=d;g<_;g++)ks.fromBufferAttribute(u,g),Ml(ks,g,l,i,t,e,this)}}updateMorphTargets(){const e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){const i=e[n[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,a=i.length;s<a;s++){const o=i[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=s}}}}}function Ml(r,t,e,n,i,s,a){const o=Oa.distanceSqToPoint(r);if(o<e){const l=new D;Oa.closestPointToPoint(r,l),l.applyMatrix4(n);const c=i.ray.origin.distanceTo(l);if(c<i.near||c>i.far)return;s.push({distance:c,distanceToRay:Math.sqrt(o),point:l,index:t,face:null,faceIndex:null,barycoord:null,object:a})}}class Mc extends Ce{constructor(t,e,n,i,s,a,o,l,c){super(t,e,n,i,s,a,o,l,c),this.isCanvasTexture=!0,this.needsUpdate=!0}}class $m{constructor(){this.type="Curve",this.arcLengthDivisions=200}getPoint(){return console.warn("THREE.Curve: .getPoint() not implemented."),null}getPointAt(t,e){const n=this.getUtoTmapping(t);return this.getPoint(n,e)}getPoints(t=5){const e=[];for(let n=0;n<=t;n++)e.push(this.getPoint(n/t));return e}getSpacedPoints(t=5){const e=[];for(let n=0;n<=t;n++)e.push(this.getPointAt(n/t));return e}getLength(){const t=this.getLengths();return t[t.length-1]}getLengths(t=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===t+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;const e=[];let n,i=this.getPoint(0),s=0;e.push(0);for(let a=1;a<=t;a++)n=this.getPoint(a/t),s+=n.distanceTo(i),e.push(s),i=n;return this.cacheArcLengths=e,e}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(t,e){const n=this.getLengths();let i=0;const s=n.length;let a;e?a=e:a=t*n[s-1];let o=0,l=s-1,c;for(;o<=l;)if(i=Math.floor(o+(l-o)/2),c=n[i]-a,c<0)o=i+1;else if(c>0)l=i-1;else{l=i;break}if(i=l,n[i]===a)return i/(s-1);const h=n[i],f=n[i+1]-h,d=(a-h)/f;return(i+d)/(s-1)}getTangent(t,e){let i=t-1e-4,s=t+1e-4;i<0&&(i=0),s>1&&(s=1);const a=this.getPoint(i),o=this.getPoint(s),l=e||(a.isVector2?new Bt:new D);return l.copy(o).sub(a).normalize(),l}getTangentAt(t,e){const n=this.getUtoTmapping(t);return this.getTangent(n,e)}computeFrenetFrames(t,e){const n=new D,i=[],s=[],a=[],o=new D,l=new Zt;for(let d=0;d<=t;d++){const g=d/t;i[d]=this.getTangentAt(g,new D)}s[0]=new D,a[0]=new D;let c=Number.MAX_VALUE;const h=Math.abs(i[0].x),u=Math.abs(i[0].y),f=Math.abs(i[0].z);h<=c&&(c=h,n.set(1,0,0)),u<=c&&(c=u,n.set(0,1,0)),f<=c&&n.set(0,0,1),o.crossVectors(i[0],n).normalize(),s[0].crossVectors(i[0],o),a[0].crossVectors(i[0],s[0]);for(let d=1;d<=t;d++){if(s[d]=s[d-1].clone(),a[d]=a[d-1].clone(),o.crossVectors(i[d-1],i[d]),o.length()>Number.EPSILON){o.normalize();const g=Math.acos(Te(i[d-1].dot(i[d]),-1,1));s[d].applyMatrix4(l.makeRotationAxis(o,g))}a[d].crossVectors(i[d],s[d])}if(e===!0){let d=Math.acos(Te(s[0].dot(s[t]),-1,1));d/=t,i[0].dot(o.crossVectors(s[0],s[t]))>0&&(d=-d);for(let g=1;g<=t;g++)s[g].applyMatrix4(l.makeRotationAxis(i[g],d*g)),a[g].crossVectors(i[g],s[g])}return{tangents:i,normals:s,binormals:a}}clone(){return new this.constructor().copy(this)}copy(t){return this.arcLengthDivisions=t.arcLengthDivisions,this}toJSON(){const t={metadata:{version:4.6,type:"Curve",generator:"Curve.toJSON"}};return t.arcLengthDivisions=this.arcLengthDivisions,t.type=this.type,t}fromJSON(t){return this.arcLengthDivisions=t.arcLengthDivisions,this}}function to(){let r=0,t=0,e=0,n=0;function i(s,a,o,l){r=s,t=o,e=-3*s+3*a-2*o-l,n=2*s-2*a+o+l}return{initCatmullRom:function(s,a,o,l,c){i(a,o,c*(o-s),c*(l-a))},initNonuniformCatmullRom:function(s,a,o,l,c,h,u){let f=(a-s)/c-(o-s)/(c+h)+(o-a)/h,d=(o-a)/h-(l-a)/(h+u)+(l-o)/u;f*=h,d*=h,i(a,o,f,d)},calc:function(s){const a=s*s,o=a*s;return r+t*s+e*a+n*o}}}const Bs=new D,kr=new to,Br=new to,Gr=new to;class Ym extends $m{constructor(t=[],e=!1,n="centripetal",i=.5){super(),this.isCatmullRomCurve3=!0,this.type="CatmullRomCurve3",this.points=t,this.closed=e,this.curveType=n,this.tension=i}getPoint(t,e=new D){const n=e,i=this.points,s=i.length,a=(s-(this.closed?0:1))*t;let o=Math.floor(a),l=a-o;this.closed?o+=o>0?0:(Math.floor(Math.abs(o)/s)+1)*s:l===0&&o===s-1&&(o=s-2,l=1);let c,h;this.closed||o>0?c=i[(o-1)%s]:(Bs.subVectors(i[0],i[1]).add(i[0]),c=Bs);const u=i[o%s],f=i[(o+1)%s];if(this.closed||o+2<s?h=i[(o+2)%s]:(Bs.subVectors(i[s-1],i[s-2]).add(i[s-1]),h=Bs),this.curveType==="centripetal"||this.curveType==="chordal"){const d=this.curveType==="chordal"?.5:.25;let g=Math.pow(c.distanceToSquared(u),d),_=Math.pow(u.distanceToSquared(f),d),m=Math.pow(f.distanceToSquared(h),d);_<1e-4&&(_=1),g<1e-4&&(g=_),m<1e-4&&(m=_),kr.initNonuniformCatmullRom(c.x,u.x,f.x,h.x,g,_,m),Br.initNonuniformCatmullRom(c.y,u.y,f.y,h.y,g,_,m),Gr.initNonuniformCatmullRom(c.z,u.z,f.z,h.z,g,_,m)}else this.curveType==="catmullrom"&&(kr.initCatmullRom(c.x,u.x,f.x,h.x,this.tension),Br.initCatmullRom(c.y,u.y,f.y,h.y,this.tension),Gr.initCatmullRom(c.z,u.z,f.z,h.z,this.tension));return n.set(kr.calc(l),Br.calc(l),Gr.calc(l)),n}copy(t){super.copy(t),this.points=[];for(let e=0,n=t.points.length;e<n;e++){const i=t.points[e];this.points.push(i.clone())}return this.closed=t.closed,this.curveType=t.curveType,this.tension=t.tension,this}toJSON(){const t=super.toJSON();t.points=[];for(let e=0,n=this.points.length;e<n;e++){const i=this.points[e];t.points.push(i.toArray())}return t.closed=this.closed,t.curveType=this.curveType,t.tension=this.tension,t}fromJSON(t){super.fromJSON(t),this.points=[];for(let e=0,n=t.points.length;e<n;e++){const i=t.points[e];this.points.push(new D().fromArray(i))}return this.closed=t.closed,this.curveType=t.curveType,this.tension=t.tension,this}}class eo extends de{constructor(t=1,e=32,n=0,i=Math.PI*2){super(),this.type="CircleGeometry",this.parameters={radius:t,segments:e,thetaStart:n,thetaLength:i},e=Math.max(3,e);const s=[],a=[],o=[],l=[],c=new D,h=new Bt;a.push(0,0,0),o.push(0,0,1),l.push(.5,.5);for(let u=0,f=3;u<=e;u++,f+=3){const d=n+u/e*i;c.x=t*Math.cos(d),c.y=t*Math.sin(d),a.push(c.x,c.y,c.z),o.push(0,0,1),h.x=(a[f]/t+1)/2,h.y=(a[f+1]/t+1)/2,l.push(h.x,h.y)}for(let u=1;u<=e;u++)s.push(u,u+1,0);this.setIndex(s),this.setAttribute("position",new Kt(a,3)),this.setAttribute("normal",new Kt(o,3)),this.setAttribute("uv",new Kt(l,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new eo(t.radius,t.segments,t.thetaStart,t.thetaLength)}}class un extends de{constructor(t=1,e=1,n=1,i=32,s=1,a=!1,o=0,l=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:t,radiusBottom:e,height:n,radialSegments:i,heightSegments:s,openEnded:a,thetaStart:o,thetaLength:l};const c=this;i=Math.floor(i),s=Math.floor(s);const h=[],u=[],f=[],d=[];let g=0;const _=[],m=n/2;let p=0;x(),a===!1&&(t>0&&y(!0),e>0&&y(!1)),this.setIndex(h),this.setAttribute("position",new Kt(u,3)),this.setAttribute("normal",new Kt(f,3)),this.setAttribute("uv",new Kt(d,2));function x(){const v=new D,R=new D;let T=0;const E=(e-t)/n;for(let P=0;P<=s;P++){const b=[],M=P/s,C=M*(e-t)+t;for(let U=0;U<=i;U++){const O=U/i,V=O*l+o,X=Math.sin(V),W=Math.cos(V);R.x=C*X,R.y=-M*n+m,R.z=C*W,u.push(R.x,R.y,R.z),v.set(X,E,W).normalize(),f.push(v.x,v.y,v.z),d.push(O,1-M),b.push(g++)}_.push(b)}for(let P=0;P<i;P++)for(let b=0;b<s;b++){const M=_[b][P],C=_[b+1][P],U=_[b+1][P+1],O=_[b][P+1];(t>0||b!==0)&&(h.push(M,C,O),T+=3),(e>0||b!==s-1)&&(h.push(C,U,O),T+=3)}c.addGroup(p,T,0),p+=T}function y(v){const R=g,T=new Bt,E=new D;let P=0;const b=v===!0?t:e,M=v===!0?1:-1;for(let U=1;U<=i;U++)u.push(0,m*M,0),f.push(0,M,0),d.push(.5,.5),g++;const C=g;for(let U=0;U<=i;U++){const V=U/i*l+o,X=Math.cos(V),W=Math.sin(V);E.x=b*W,E.y=m*M,E.z=b*X,u.push(E.x,E.y,E.z),f.push(0,M,0),T.x=X*.5+.5,T.y=W*.5*M+.5,d.push(T.x,T.y),g++}for(let U=0;U<i;U++){const O=R+U,V=C+U;v===!0?h.push(V,V+1,O):h.push(V+1,V,O),P+=3}c.addGroup(p,P,v===!0?1:2),p+=P}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new un(t.radiusTop,t.radiusBottom,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}}class ei extends un{constructor(t=1,e=1,n=32,i=1,s=!1,a=0,o=Math.PI*2){super(0,t,e,n,i,s,a,o),this.type="ConeGeometry",this.parameters={radius:t,height:e,radialSegments:n,heightSegments:i,openEnded:s,thetaStart:a,thetaLength:o}}static fromJSON(t){return new ei(t.radius,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}}class lr extends de{constructor(t=[],e=[],n=1,i=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:t,indices:e,radius:n,detail:i};const s=[],a=[];o(i),c(n),h(),this.setAttribute("position",new Kt(s,3)),this.setAttribute("normal",new Kt(s.slice(),3)),this.setAttribute("uv",new Kt(a,2)),i===0?this.computeVertexNormals():this.normalizeNormals();function o(x){const y=new D,v=new D,R=new D;for(let T=0;T<e.length;T+=3)d(e[T+0],y),d(e[T+1],v),d(e[T+2],R),l(y,v,R,x)}function l(x,y,v,R){const T=R+1,E=[];for(let P=0;P<=T;P++){E[P]=[];const b=x.clone().lerp(v,P/T),M=y.clone().lerp(v,P/T),C=T-P;for(let U=0;U<=C;U++)U===0&&P===T?E[P][U]=b:E[P][U]=b.clone().lerp(M,U/C)}for(let P=0;P<T;P++)for(let b=0;b<2*(T-P)-1;b++){const M=Math.floor(b/2);b%2===0?(f(E[P][M+1]),f(E[P+1][M]),f(E[P][M])):(f(E[P][M+1]),f(E[P+1][M+1]),f(E[P+1][M]))}}function c(x){const y=new D;for(let v=0;v<s.length;v+=3)y.x=s[v+0],y.y=s[v+1],y.z=s[v+2],y.normalize().multiplyScalar(x),s[v+0]=y.x,s[v+1]=y.y,s[v+2]=y.z}function h(){const x=new D;for(let y=0;y<s.length;y+=3){x.x=s[y+0],x.y=s[y+1],x.z=s[y+2];const v=m(x)/2/Math.PI+.5,R=p(x)/Math.PI+.5;a.push(v,1-R)}g(),u()}function u(){for(let x=0;x<a.length;x+=6){const y=a[x+0],v=a[x+2],R=a[x+4],T=Math.max(y,v,R),E=Math.min(y,v,R);T>.9&&E<.1&&(y<.2&&(a[x+0]+=1),v<.2&&(a[x+2]+=1),R<.2&&(a[x+4]+=1))}}function f(x){s.push(x.x,x.y,x.z)}function d(x,y){const v=x*3;y.x=t[v+0],y.y=t[v+1],y.z=t[v+2]}function g(){const x=new D,y=new D,v=new D,R=new D,T=new Bt,E=new Bt,P=new Bt;for(let b=0,M=0;b<s.length;b+=9,M+=6){x.set(s[b+0],s[b+1],s[b+2]),y.set(s[b+3],s[b+4],s[b+5]),v.set(s[b+6],s[b+7],s[b+8]),T.set(a[M+0],a[M+1]),E.set(a[M+2],a[M+3]),P.set(a[M+4],a[M+5]),R.copy(x).add(y).add(v).divideScalar(3);const C=m(R);_(T,M+0,x,C),_(E,M+2,y,C),_(P,M+4,v,C)}}function _(x,y,v,R){R<0&&x.x===1&&(a[y]=x.x-1),v.x===0&&v.z===0&&(a[y]=R/2/Math.PI+.5)}function m(x){return Math.atan2(x.z,-x.x)}function p(x){return Math.atan2(-x.y,Math.sqrt(x.x*x.x+x.z*x.z))}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new lr(t.vertices,t.indices,t.radius,t.details)}}class no extends lr{constructor(t=1,e=0){const n=(1+Math.sqrt(5))/2,i=1/n,s=[-1,-1,-1,-1,-1,1,-1,1,-1,-1,1,1,1,-1,-1,1,-1,1,1,1,-1,1,1,1,0,-i,-n,0,-i,n,0,i,-n,0,i,n,-i,-n,0,-i,n,0,i,-n,0,i,n,0,-n,0,-i,n,0,-i,-n,0,i,n,0,i],a=[3,11,7,3,7,15,3,15,13,7,19,17,7,17,6,7,6,15,17,4,8,17,8,10,17,10,6,8,0,16,8,16,2,8,2,10,0,12,1,0,1,18,0,18,16,6,10,2,6,2,13,6,13,15,2,16,18,2,18,3,2,3,13,18,1,9,18,9,11,18,11,3,4,14,12,4,12,0,4,0,8,11,9,5,11,5,19,11,19,7,19,5,14,19,14,4,19,4,17,1,12,14,1,14,5,1,5,9];super(s,a,t,e),this.type="DodecahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new no(t.radius,t.detail)}}class io extends lr{constructor(t=1,e=0){const n=(1+Math.sqrt(5))/2,i=[-1,n,0,1,n,0,-1,-n,0,1,-n,0,0,-1,n,0,1,n,0,-1,-n,0,1,-n,n,0,-1,n,0,1,-n,0,-1,-n,0,1],s=[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1];super(i,s,t,e),this.type="IcosahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new io(t.radius,t.detail)}}class oi extends de{constructor(t=1,e=32,n=16,i=0,s=Math.PI*2,a=0,o=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:t,widthSegments:e,heightSegments:n,phiStart:i,phiLength:s,thetaStart:a,thetaLength:o},e=Math.max(3,Math.floor(e)),n=Math.max(2,Math.floor(n));const l=Math.min(a+o,Math.PI);let c=0;const h=[],u=new D,f=new D,d=[],g=[],_=[],m=[];for(let p=0;p<=n;p++){const x=[],y=p/n;let v=0;p===0&&a===0?v=.5/e:p===n&&l===Math.PI&&(v=-.5/e);for(let R=0;R<=e;R++){const T=R/e;u.x=-t*Math.cos(i+T*s)*Math.sin(a+y*o),u.y=t*Math.cos(a+y*o),u.z=t*Math.sin(i+T*s)*Math.sin(a+y*o),g.push(u.x,u.y,u.z),f.copy(u).normalize(),_.push(f.x,f.y,f.z),m.push(T+v,1-y),x.push(c++)}h.push(x)}for(let p=0;p<n;p++)for(let x=0;x<e;x++){const y=h[p][x+1],v=h[p][x],R=h[p+1][x],T=h[p+1][x+1];(p!==0||a>0)&&d.push(y,v,T),(p!==n-1||l<Math.PI)&&d.push(v,R,T)}this.setIndex(d),this.setAttribute("position",new Kt(g,3)),this.setAttribute("normal",new Kt(_,3)),this.setAttribute("uv",new Kt(m,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new oi(t.radius,t.widthSegments,t.heightSegments,t.phiStart,t.phiLength,t.thetaStart,t.thetaLength)}}class nr extends de{constructor(t=1,e=.4,n=12,i=48,s=Math.PI*2){super(),this.type="TorusGeometry",this.parameters={radius:t,tube:e,radialSegments:n,tubularSegments:i,arc:s},n=Math.floor(n),i=Math.floor(i);const a=[],o=[],l=[],c=[],h=new D,u=new D,f=new D;for(let d=0;d<=n;d++)for(let g=0;g<=i;g++){const _=g/i*s,m=d/n*Math.PI*2;u.x=(t+e*Math.cos(m))*Math.cos(_),u.y=(t+e*Math.cos(m))*Math.sin(_),u.z=e*Math.sin(m),o.push(u.x,u.y,u.z),h.x=t*Math.cos(_),h.y=t*Math.sin(_),f.subVectors(u,h).normalize(),l.push(f.x,f.y,f.z),c.push(g/i),c.push(d/n)}for(let d=1;d<=n;d++)for(let g=1;g<=i;g++){const _=(i+1)*d+g-1,m=(i+1)*(d-1)+g-1,p=(i+1)*(d-1)+g,x=(i+1)*d+g;a.push(_,m,x),a.push(m,p,x)}this.setIndex(a),this.setAttribute("position",new Kt(o,3)),this.setAttribute("normal",new Kt(l,3)),this.setAttribute("uv",new Kt(c,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new nr(t.radius,t.tube,t.radialSegments,t.tubularSegments,t.arc)}}class jm extends ye{static get type(){return"RawShaderMaterial"}constructor(t){super(t),this.isRawShaderMaterial=!0}}class Ft extends hi{static get type(){return"MeshStandardMaterial"}constructor(t){super(),this.isMeshStandardMaterial=!0,this.defines={STANDARD:""},this.color=new Pt(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Pt(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=ec,this.normalScale=new Bt(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new rn,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.defines={STANDARD:""},this.color.copy(t.color),this.roughness=t.roughness,this.metalness=t.metalness,this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.emissive.copy(t.emissive),this.emissiveMap=t.emissiveMap,this.emissiveIntensity=t.emissiveIntensity,this.bumpMap=t.bumpMap,this.bumpScale=t.bumpScale,this.normalMap=t.normalMap,this.normalMapType=t.normalMapType,this.normalScale.copy(t.normalScale),this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.roughnessMap=t.roughnessMap,this.metalnessMap=t.metalnessMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.envMapIntensity=t.envMapIntensity,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.flatShading=t.flatShading,this.fog=t.fog,this}}class yc extends Ft{static get type(){return"MeshPhysicalMaterial"}constructor(t){super(),this.isMeshPhysicalMaterial=!0,this.defines={STANDARD:"",PHYSICAL:""},this.anisotropyRotation=0,this.anisotropyMap=null,this.clearcoatMap=null,this.clearcoatRoughness=0,this.clearcoatRoughnessMap=null,this.clearcoatNormalScale=new Bt(1,1),this.clearcoatNormalMap=null,this.ior=1.5,Object.defineProperty(this,"reflectivity",{get:function(){return Te(2.5*(this.ior-1)/(this.ior+1),0,1)},set:function(e){this.ior=(1+.4*e)/(1-.4*e)}}),this.iridescenceMap=null,this.iridescenceIOR=1.3,this.iridescenceThicknessRange=[100,400],this.iridescenceThicknessMap=null,this.sheenColor=new Pt(0),this.sheenColorMap=null,this.sheenRoughness=1,this.sheenRoughnessMap=null,this.transmissionMap=null,this.thickness=0,this.thicknessMap=null,this.attenuationDistance=1/0,this.attenuationColor=new Pt(1,1,1),this.specularIntensity=1,this.specularIntensityMap=null,this.specularColor=new Pt(1,1,1),this.specularColorMap=null,this._anisotropy=0,this._clearcoat=0,this._dispersion=0,this._iridescence=0,this._sheen=0,this._transmission=0,this.setValues(t)}get anisotropy(){return this._anisotropy}set anisotropy(t){this._anisotropy>0!=t>0&&this.version++,this._anisotropy=t}get clearcoat(){return this._clearcoat}set clearcoat(t){this._clearcoat>0!=t>0&&this.version++,this._clearcoat=t}get iridescence(){return this._iridescence}set iridescence(t){this._iridescence>0!=t>0&&this.version++,this._iridescence=t}get dispersion(){return this._dispersion}set dispersion(t){this._dispersion>0!=t>0&&this.version++,this._dispersion=t}get sheen(){return this._sheen}set sheen(t){this._sheen>0!=t>0&&this.version++,this._sheen=t}get transmission(){return this._transmission}set transmission(t){this._transmission>0!=t>0&&this.version++,this._transmission=t}copy(t){return super.copy(t),this.defines={STANDARD:"",PHYSICAL:""},this.anisotropy=t.anisotropy,this.anisotropyRotation=t.anisotropyRotation,this.anisotropyMap=t.anisotropyMap,this.clearcoat=t.clearcoat,this.clearcoatMap=t.clearcoatMap,this.clearcoatRoughness=t.clearcoatRoughness,this.clearcoatRoughnessMap=t.clearcoatRoughnessMap,this.clearcoatNormalMap=t.clearcoatNormalMap,this.clearcoatNormalScale.copy(t.clearcoatNormalScale),this.dispersion=t.dispersion,this.ior=t.ior,this.iridescence=t.iridescence,this.iridescenceMap=t.iridescenceMap,this.iridescenceIOR=t.iridescenceIOR,this.iridescenceThicknessRange=[...t.iridescenceThicknessRange],this.iridescenceThicknessMap=t.iridescenceThicknessMap,this.sheen=t.sheen,this.sheenColor.copy(t.sheenColor),this.sheenColorMap=t.sheenColorMap,this.sheenRoughness=t.sheenRoughness,this.sheenRoughnessMap=t.sheenRoughnessMap,this.transmission=t.transmission,this.transmissionMap=t.transmissionMap,this.thickness=t.thickness,this.thicknessMap=t.thicknessMap,this.attenuationDistance=t.attenuationDistance,this.attenuationColor.copy(t.attenuationColor),this.specularIntensity=t.specularIntensity,this.specularIntensityMap=t.specularIntensityMap,this.specularColor.copy(t.specularColor),this.specularColorMap=t.specularColorMap,this}}class so extends fe{constructor(t,e=1){super(),this.isLight=!0,this.type="Light",this.color=new Pt(t),this.intensity=e}dispose(){}copy(t,e){return super.copy(t,e),this.color.copy(t.color),this.intensity=t.intensity,this}toJSON(t){const e=super.toJSON(t);return e.object.color=this.color.getHex(),e.object.intensity=this.intensity,this.groundColor!==void 0&&(e.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(e.object.distance=this.distance),this.angle!==void 0&&(e.object.angle=this.angle),this.decay!==void 0&&(e.object.decay=this.decay),this.penumbra!==void 0&&(e.object.penumbra=this.penumbra),this.shadow!==void 0&&(e.object.shadow=this.shadow.toJSON()),this.target!==void 0&&(e.object.target=this.target.uuid),e}}class Km extends so{constructor(t,e,n){super(t,n),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(fe.DEFAULT_UP),this.updateMatrix(),this.groundColor=new Pt(e)}copy(t,e){return super.copy(t,e),this.groundColor.copy(t.groundColor),this}}const Hr=new Zt,yl=new D,Sl=new D;class Sc{constructor(t){this.camera=t,this.intensity=1,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new Bt(512,512),this.map=null,this.mapPass=null,this.matrix=new Zt,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new Ka,this._frameExtents=new Bt(1,1),this._viewportCount=1,this._viewports=[new ge(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(t){const e=this.camera,n=this.matrix;yl.setFromMatrixPosition(t.matrixWorld),e.position.copy(yl),Sl.setFromMatrixPosition(t.target.matrixWorld),e.lookAt(Sl),e.updateMatrixWorld(),Hr.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),this._frustum.setFromProjectionMatrix(Hr),n.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),n.multiply(Hr)}getViewport(t){return this._viewports[t]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(t){return this.camera=t.camera.clone(),this.intensity=t.intensity,this.bias=t.bias,this.radius=t.radius,this.mapSize.copy(t.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){const t={};return this.intensity!==1&&(t.intensity=this.intensity),this.bias!==0&&(t.bias=this.bias),this.normalBias!==0&&(t.normalBias=this.normalBias),this.radius!==1&&(t.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(t.mapSize=this.mapSize.toArray()),t.camera=this.camera.toJSON(!1).object,delete t.camera.matrix,t}}class Zm extends Sc{constructor(){super(new He(50,1,.5,500)),this.isSpotLightShadow=!0,this.focus=1}updateMatrices(t){const e=this.camera,n=ki*2*t.angle*this.focus,i=this.mapSize.width/this.mapSize.height,s=t.distance||e.far;(n!==e.fov||i!==e.aspect||s!==e.far)&&(e.fov=n,e.aspect=i,e.far=s,e.updateProjectionMatrix()),super.updateMatrices(t)}copy(t){return super.copy(t),this.focus=t.focus,this}}class Jm extends so{constructor(t,e,n=0,i=Math.PI/3,s=0,a=2){super(t,e),this.isSpotLight=!0,this.type="SpotLight",this.position.copy(fe.DEFAULT_UP),this.updateMatrix(),this.target=new fe,this.distance=n,this.angle=i,this.penumbra=s,this.decay=a,this.map=null,this.shadow=new Zm}get power(){return this.intensity*Math.PI}set power(t){this.intensity=t/Math.PI}dispose(){this.shadow.dispose()}copy(t,e){return super.copy(t,e),this.distance=t.distance,this.angle=t.angle,this.penumbra=t.penumbra,this.decay=t.decay,this.target=t.target.clone(),this.shadow=t.shadow.clone(),this}}class Qm extends Sc{constructor(){super(new Za(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class t0 extends so{constructor(t,e){super(t,e),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(fe.DEFAULT_UP),this.updateMatrix(),this.target=new fe,this.shadow=new Qm}dispose(){this.shadow.dispose()}copy(t){return super.copy(t),this.target=t.target.clone(),this.shadow=t.shadow.clone(),this}}class bc{constructor(t=!0){this.autoStart=t,this.startTime=0,this.oldTime=0,this.elapsedTime=0,this.running=!1}start(){this.startTime=bl(),this.oldTime=this.startTime,this.elapsedTime=0,this.running=!0}stop(){this.getElapsedTime(),this.running=!1,this.autoStart=!1}getElapsedTime(){return this.getDelta(),this.elapsedTime}getDelta(){let t=0;if(this.autoStart&&!this.running)return this.start(),0;if(this.running){const e=bl();t=(e-this.oldTime)/1e3,this.oldTime=e,this.elapsedTime+=t}return t}}function bl(){return performance.now()}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:ka}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=ka);const wl=[{name:"Rosso",hex:"#c8102e"},{name:"Racing Green",hex:"#0b5d3b"},{name:"Gulf Blue",hex:"#7ab8e0"},{name:"Papaya",hex:"#ff7a00"},{name:"Arctic",hex:"#e9edf2"},{name:"Carbon",hex:"#1a1c20"},{name:"Volt",hex:"#c6f000"},{name:"Royal",hex:"#1d3fbf"}],Fn=[{id:"gt3",name:"Vortex GT3",cls:"GT3 · RWD",desc:"Balanced endurance coupe. Forgiving, stable on the brakes.",mass:1250,topSpeed:79,torque:640,maxRPM:8400,idleRPM:1100,gears:[3.05,2.2,1.72,1.4,1.17,.98],grip:1.78,brake:1,downforce:1.05,steerMax:.52,cf:98e3,cr:112e3,a:1.22,b:1.38,cg:.42,wheelR:.34,engine:{cyl:8,tone:.9},stats:{accel:7,top:7,handling:7,braking:7},paint:"#c8102e",model:{len:4.6,halfW:1,bodyBottom:.16,top:[[0,.78],[.08,.92],[.22,.9],[.35,.86],[.62,.8],[.8,.68],[.93,.56],[1,.42]],cabin:{z0:.3,z1:.68,roof:1.27,halfW:.74,rake:.45},wing:"gt",splitter:!0,scoop:!1,fin:!1,wheelBase:2.6}},{id:"lmp",name:"Apex LMP-H",cls:"Prototype · RWD",desc:"Le Mans prototype. Huge downforce and top speed, punishing when pushed.",mass:980,topSpeed:92,torque:690,maxRPM:9200,idleRPM:1400,gears:[2.9,2.15,1.7,1.4,1.18,1,.87],grip:1.85,brake:1.25,downforce:1.9,steerMax:.48,cf:104e3,cr:118e3,a:1.3,b:1.45,cg:.32,wheelR:.35,engine:{cyl:6,tone:1.15},stats:{accel:8,top:10,handling:9,braking:10},paint:"#e9edf2",model:{len:4.9,halfW:1,bodyBottom:.1,top:[[0,.82],[.1,.86],[.25,.72],[.45,.62],[.62,.66],[.78,.6],[.92,.42],[1,.3]],cabin:{z0:.42,z1:.68,roof:1.08,halfW:.56,rake:.55},wing:"lmp",splitter:!0,scoop:!1,fin:!0,wheelBase:2.75}},{id:"hatch",name:"Strada RS Hatch",cls:"Touring · FWD",desc:"Light touring hatch. Modest power, darts into tight corners.",mass:1040,topSpeed:64,torque:410,maxRPM:7600,idleRPM:950,gears:[3.3,2.3,1.75,1.4,1.15,.97],grip:1.74,brake:.95,downforce:.45,steerMax:.6,cf:92e3,cr:1e5,a:1.05,b:1.4,cg:.5,wheelR:.31,fwd:!0,engine:{cyl:4,tone:1.25},stats:{accel:5,top:4,handling:9,braking:6},paint:"#ff7a00",model:{len:4.1,halfW:.92,bodyBottom:.18,top:[[0,.95],[.06,1],[.18,.98],[.4,.9],[.65,.86],[.82,.78],[.94,.66],[1,.55]],cabin:{z0:.06,z1:.66,roof:1.45,halfW:.78,rake:.4},wing:"roof",splitter:!1,scoop:!1,fin:!1,wheelBase:2.45}},{id:"muscle",name:"Titan V8 Muscle",cls:"Super GT · RWD",desc:"Brutal torque and straight-line pace. Heavy, loose, and hard on brakes.",mass:1560,topSpeed:85,torque:920,maxRPM:7200,idleRPM:850,gears:[2.85,2.05,1.6,1.3,1.08,.9],grip:1.62,brake:.78,downforce:.6,steerMax:.5,cf:102e3,cr:98e3,a:1.3,b:1.45,cg:.5,wheelR:.35,engine:{cyl:8,tone:.72},stats:{accel:9,top:8,handling:5,braking:4},paint:"#1d3fbf",model:{len:4.85,halfW:1.02,bodyBottom:.17,top:[[0,.86],[.07,.92],[.22,.9],[.36,.88],[.6,.84],[.82,.82],[.95,.74],[1,.6]],cabin:{z0:.26,z1:.58,roof:1.3,halfW:.76,rake:.5},wing:"duck",splitter:!1,scoop:!0,fin:!1,wheelBase:2.85}}],_e=[{id:"velocita",name:"Velocità Ring",type:"High-speed circuit",difficulty:1,desc:"Long straights, fast sweepers, one heavy braking zone.",theme:"circuit",halfWidth:8,runoff:16,wall:"armco",kerbs:!0,time:"day",weather:"sunny",points:[[0,-60],[0,200],[0,420],[24,560],[110,640],[240,660],[360,610],[420,500],[400,380],[440,270],[560,220],[680,160],[740,30],[700,-120],[560,-200],[420,-190],[330,-120],[240,-170],[150,-280],[40,-280],[2,-200]]},{id:"kessel",name:"Kesselbahn",type:"Technical circuit",difficulty:3,desc:"Hairpins, chicanes and a tight esses section. Brakes and patience.",theme:"technical",halfWidth:7,runoff:12,wall:"tyre",kerbs:!0,time:"day",weather:"cloudy",points:[[0,-20],[0,140],[16,210],[70,236],[118,206],[112,150],[150,108],[220,116],[252,176],[310,214],[372,186],[384,110],[336,52],[338,-22],[392,-82],[376,-170],[300,-200],[226,-150],[160,-186],[96,-196],[34,-150],[6,-96]]},{id:"marina",name:"Marina Street Circuit",type:"Street circuit",difficulty:2,desc:"Concrete walls inches away. Ninety-degree corners between city blocks.",theme:"street",halfWidth:6.5,runoff:1.6,wall:"concrete",kerbs:!1,time:"dusk",weather:"sunny",points:[[0,60],[0,150],[0,250],[6,274],[30,282],[190,282],[214,290],[222,314],[222,380],[230,404],[254,412],[380,412],[404,404],[412,380],[412,160],[404,136],[380,128],[310,128],[288,120],[280,96],[280,30],[270,-2],[240,-14],[30,-14],[8,-10],[0,10]]},{id:"alpine",name:"Alpine Pass",type:"Mountain circuit",difficulty:3,desc:"Climbs 60 m through pine forest. Blind crests and switchbacks.",theme:"mountain",halfWidth:6.5,runoff:3,wall:"armco",kerbs:!1,time:"day",weather:"sunny",points:[[0,-40,0],[0,80,2],[20,170,8],[80,230,16],[160,236,24],[216,196,30],[210,140,36],[160,110,40],[150,60,44],[196,20,50],[270,30,56],[330,80,60],[400,70,58],[430,0,52],[400,-70,44],[320,-96,36],[250,-150,28],[170,-200,18],[80,-190,10],[20,-130,3]]},{id:"neon",name:"Neon Bay Night",type:"Night circuit",difficulty:2,desc:"Floodlit harbour circuit under the skyline. Fast flowing night race.",theme:"night",halfWidth:7.5,runoff:10,wall:"concrete",kerbs:!0,time:"night",weather:"sunny",points:[[0,-40],[0,160],[10,290],[70,360],[170,370],[240,310],[250,220],[310,160],[420,170],[500,240],[590,230],[620,120],[560,20],[470,-20],[440,-120],[360,-190],[240,-180],[180,-100],[100,-140],[30,-130]]}],e0=[{name:"M. Varga",code:"VAR"},{name:"L. Okonkwo",code:"OKO"},{name:"C. Brennan",code:"BRE"},{name:"O. Pastri",code:"PAS"},{name:"S. Navarro",code:"NAV"},{name:"K. Rossberg",code:"RSB"},{name:"A. Lindqvist",code:"LIN"},{name:"D. Takeda",code:"TAK"}],Gs={easy:{skill:.86,label:"Amateur"},medium:{skill:.93,label:"Pro"},hard:{skill:.995,label:"Elite"}};function vn(r,t=!1){const e=r[0].index!==null,n=new Set(Object.keys(r[0].attributes)),i=new Set(Object.keys(r[0].morphAttributes)),s={},a={},o=r[0].morphTargetsRelative,l=new de;let c=0;for(let h=0;h<r.length;++h){const u=r[h];let f=0;if(e!==(u.index!==null))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". All geometries must have compatible attributes; make sure index attribute exists among all geometries, or in none of them."),null;for(const d in u.attributes){if(!n.has(d))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+'. All geometries must have compatible attributes; make sure "'+d+'" attribute exists among all geometries, or in none of them.'),null;s[d]===void 0&&(s[d]=[]),s[d].push(u.attributes[d]),f++}if(f!==n.size)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". Make sure all geometries have the same number of attributes."),null;if(o!==u.morphTargetsRelative)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". .morphTargetsRelative must be consistent throughout all geometries."),null;for(const d in u.morphAttributes){if(!i.has(d))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+".  .morphAttributes must be consistent throughout all geometries."),null;a[d]===void 0&&(a[d]=[]),a[d].push(u.morphAttributes[d])}if(t){let d;if(e)d=u.index.count;else if(u.attributes.position!==void 0)d=u.attributes.position.count;else return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". The geometry must have either an index or a position attribute"),null;l.addGroup(c,d,h),c+=d}}if(e){let h=0;const u=[];for(let f=0;f<r.length;++f){const d=r[f].index;for(let g=0;g<d.count;++g)u.push(d.getX(g)+h);h+=r[f].attributes.position.count}l.setIndex(u)}for(const h in s){const u=Tl(s[h]);if(!u)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+h+" attribute."),null;l.setAttribute(h,u)}for(const h in a){const u=a[h][0].length;if(u===0)break;l.morphAttributes=l.morphAttributes||{},l.morphAttributes[h]=[];for(let f=0;f<u;++f){const d=[];for(let _=0;_<a[h].length;++_)d.push(a[h][_][f]);const g=Tl(d);if(!g)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+h+" morphAttribute."),null;l.morphAttributes[h].push(g)}}return l}function Tl(r){let t,e,n,i=-1,s=0;for(let c=0;c<r.length;++c){const h=r[c];if(t===void 0&&(t=h.array.constructor),t!==h.array.constructor)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.array must be of consistent array types across matching attributes."),null;if(e===void 0&&(e=h.itemSize),e!==h.itemSize)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.itemSize must be consistent across matching attributes."),null;if(n===void 0&&(n=h.normalized),n!==h.normalized)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.normalized must be consistent across matching attributes."),null;if(i===-1&&(i=h.gpuType),i!==h.gpuType)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.gpuType must be consistent across matching attributes."),null;s+=h.count*e}const a=new t(s),o=new xe(a,e,n);let l=0;for(let c=0;c<r.length;++c){const h=r[c];if(h.isInterleavedBufferAttribute){const u=l/e;for(let f=0,d=h.count;f<d;f++)for(let g=0;g<e;g++){const _=h.getComponent(f,g);o.setComponent(f+u,g,_)}}else a.set(h.array,l);l+=h.count*e}return i!==void 0&&(o.gpuType=i),o}function En(r=1){let t=r>>>0;return()=>{t=t+1831565813>>>0;let e=t;return e=Math.imul(e^e>>>15,e|1),e^=e+Math.imul(e^e>>>7,e|61),((e^e>>>14)>>>0)/4294967296}}function Pe(r,t){const e=document.createElement("canvas");return e.width=r,e.height=t,[e,e.getContext("2d")]}function Le(r,t=!0,e=!0){const n=new Mc(r);return t&&(n.wrapS=n.wrapT=Zs),n.anisotropy=8,e&&(n.colorSpace=Ue),n}function ir(r,t,e,n,i,s,a,o){for(let l=0;l<n;l++){const c=a?255:0;r.fillStyle=`rgba(${c},${c},${c},${i+o()*(s-i)})`;const h=1+o()*2;r.fillRect(o()*t,o()*e,h,h)}}const sr={};function wc(r){for(const t in sr)if(sr[t]===r)return!0;return!1}function ze(r,t){return sr[r]||(sr[r]=t())}function n0(r=!1){return ze("asphalt"+r,()=>{const[n,i]=Pe(512,512),s=En(7);i.fillStyle="#3a3c40",i.fillRect(0,0,512,512),ir(i,512,512,26e3,.03,.14,!0,s),ir(i,512,512,26e3,.04,.2,!1,s);const a=i.createLinearGradient(0,0,512,0);a.addColorStop(0,"rgba(0,0,0,0)"),a.addColorStop(.35,"rgba(10,10,12,0.18)"),a.addColorStop(.5,"rgba(10,10,12,0.26)"),a.addColorStop(.65,"rgba(10,10,12,0.18)"),a.addColorStop(1,"rgba(0,0,0,0)"),i.fillStyle=a,i.fillRect(0,0,512,512);for(let o=0;o<14;o++)i.fillStyle=`rgba(${s()>.5?255:0},${s()>.5?255:0},${s()>.5?255:0},0.025)`,i.fillRect(s()*512,s()*512,30+s()*120,20+s()*90);return i.fillStyle="#e8e8e2",i.fillRect(512*.015,0,512*.022,512),i.fillRect(512*.963,0,512*.022,512),r&&(i.fillStyle="rgba(235,235,225,0.9)",i.fillRect(512*.494,0,512*.012,512*.45)),Le(n)})}function i0(){return ze("asphaltR",()=>{const[e,n]=Pe(256,256),i=En(9);n.fillStyle="#d8d8d8",n.fillRect(0,0,256,256),ir(n,256,256,9e3,.1,.35,!1,i);const s=n.createLinearGradient(0,0,256,0);return s.addColorStop(0,"rgba(0,0,0,0)"),s.addColorStop(.5,"rgba(0,0,0,0.25)"),s.addColorStop(1,"rgba(0,0,0,0)"),n.fillStyle=s,n.fillRect(0,0,256,256),Le(e,!0,!1)})}function Vr(){return ze("grass",()=>{const[t,e]=Pe(512,512),n=En(3);e.fillStyle="#4b7a35",e.fillRect(0,0,512,512);for(let i=0;i<4e4;i++){const s=90+n()*70;e.fillStyle=`rgba(${30+n()*40},${s},${20+n()*30},0.35)`,e.fillRect(n()*512,n()*512,1,2+n()*3)}for(let i=0;i<8;i++)e.fillStyle=i%2?"rgba(255,255,255,0.035)":"rgba(0,0,0,0.035)",e.fillRect(0,i*512/8,512,512/8);return Le(t)})}function Hs(r){return ze("ground"+r,()=>{const[e,n]=Pe(512,512),i=En(11),s={gravel:"#b59f7c",dirt:"#6b5a42",concrete:"#8d8f92",pavement:"#77797d"}[r];n.fillStyle=s,n.fillRect(0,0,512,512);for(let a=0;a<3e4;a++){const o=i()>.5?255:0;n.fillStyle=`rgba(${o},${o},${o},${.04+i()*.12})`;const l=r==="gravel"?1+i()*3:1+i()*1.5;n.fillRect(i()*512,i()*512,l,l)}if(r==="pavement"){n.strokeStyle="rgba(0,0,0,0.25)",n.lineWidth=2;for(let a=0;a<=4;a++)n.beginPath(),n.moveTo(0,a*512/4),n.lineTo(512,a*512/4),n.stroke(),n.beginPath(),n.moveTo(a*512/4,0),n.lineTo(a*512/4,512),n.stroke()}return Le(e)})}function s0(){return ze("kerb",()=>{const[r,t]=Pe(64,256);return t.fillStyle="#d61f26",t.fillRect(0,0,64,256),t.fillStyle="#f2f2ee",t.fillRect(0,0,64,128),t.fillStyle="rgba(0,0,0,0.12)",t.fillRect(0,0,8,256),Le(r)})}function r0(){return ze("checker",()=>{const[r,t]=Pe(256,64),e=16,n=4;for(let i=0;i<e;i++)for(let s=0;s<n;s++)t.fillStyle=(i+s)%2?"#111":"#f4f4f4",t.fillRect(i*256/e,s*64/n,256/e,64/n);return Le(r,!1)})}function El(r){return ze("wall"+r,()=>{const[t,e]=Pe(512,128),n=En(5);if(r==="concrete"){e.fillStyle="#b9bbbd",e.fillRect(0,0,512,128),ir(e,512,128,6e3,.03,.12,!1,n),e.fillStyle="#c8102e",e.fillRect(0,96,512,14),e.fillStyle="#f4f4f4",e.fillRect(0,88,512,8),e.fillStyle="rgba(0,0,0,0.25)";for(let i=0;i<4;i++)e.fillRect(i*128,0,2,128)}else if(r==="tyre"){e.fillStyle="#1a1a1c",e.fillRect(0,0,512,128);for(let i=0;i<16;i++)for(let s=0;s<4;s++)e.fillStyle=s===1?i%2?"#d61f26":"#eeeeee":"#222226",e.beginPath(),e.ellipse(i*32+16,s*32+16,15,14,0,0,Math.PI*2),e.fill(),e.fillStyle="#0c0c0d",e.beginPath(),e.ellipse(i*32+16,s*32+16,6,5,0,0,Math.PI*2),e.fill()}else{e.fillStyle="#5b6066",e.fillRect(0,0,512,128);const i=e.createLinearGradient(0,0,0,128);i.addColorStop(0,"#d9dde1"),i.addColorStop(.2,"#9aa1a8"),i.addColorStop(.3,"#e6e9ec"),i.addColorStop(.45,"#8a9198"),i.addColorStop(.5,"#3c4046"),i.addColorStop(.55,"#d9dde1"),i.addColorStop(.75,"#9aa1a8"),i.addColorStop(.8,"#e6e9ec"),i.addColorStop(1,"#6b7178"),e.fillStyle=i,e.fillRect(0,0,512,128),e.fillStyle="rgba(0,0,0,0.35)";for(let s=0;s<4;s++)e.fillRect(s*128+60,0,6,128)}return Le(t)})}function a0(){return ze("crowd",()=>{const[r,t]=Pe(512,256),e=En(21);t.fillStyle="#2a2d33",t.fillRect(0,0,512,256);const n=["#e63946","#f1faee","#a8dadc","#ffbe0b","#3a86ff","#ff006e","#222","#8338ec","#fb5607"];for(let i=0;i<16;i++)for(let s=0;s<64;s++){if(e()<.12)continue;t.fillStyle=n[e()*n.length|0];const a=s*8+e()*3,o=i*16+4+e()*3;t.fillRect(a,o,5,7),t.fillStyle="#e0b89a",t.fillRect(a+1,o-3,3,3)}return Le(r)})}function o0(r,t){return ze("win"+r+t,()=>{const[e,n]=Pe(256,512),i=En(r);n.fillStyle=t?"#07090d":"#59636e",n.fillRect(0,0,256,512);const s=8,a=24;for(let o=0;o<a;o++){const l=i();for(let c=0;c<s;c++){const h=t?i()<l*.75-.1:!1;if(t){const u=.55+i()*.45;n.fillStyle=h?`rgba(255,${200+i()*40},${130+i()*60},${u})`:"rgba(30,40,55,0.9)"}else{const u=120+i()*70;n.fillStyle=`rgb(${u*.75},${u*.88},${u})`}n.fillRect(c*32+4,o*21+4,24,13)}}return Le(e)})}function Wr(r){return ze("bb"+r,()=>{const[t,e]=Pe(512,128),n=[["APEX","#c8102e","#fff"],["VORTEX OIL","#111","#ffbe0b"],["KAZE TYRES","#ffbe0b","#111"],["NOVA ENERGY","#1d3fbf","#fff"],["STRADA","#0b5d3b","#fff"],["TITAN","#e9edf2","#c8102e"]],[i,s,a]=n[r%n.length];return e.fillStyle=s,e.fillRect(0,0,512,128),e.fillStyle=a,e.font='800 italic 72px "Saira Condensed", sans-serif',e.textAlign="center",e.textBaseline="middle",e.fillText(i,256,68),Le(t,!1)})}function l0(r,t="#fff"){const[e,n]=Pe(128,128);return n.fillStyle=t,n.beginPath(),n.arc(64,64,60,0,Math.PI*2),n.fill(),n.fillStyle="#111",n.font='800 78px "Saira Condensed", sans-serif',n.textAlign="center",n.textBaseline="middle",n.fillText(String(r),64,70),Le(e,!1)}function c0(r=0){return ze("livery"+r,()=>{const[t,e]=Pe(512,512);e.fillStyle="#fff",e.fillRect(0,0,512,512),e.fillStyle="#26282c",e.fillRect(512*.215,0,512*.022,512),e.fillRect(512*.263,0,512*.022,512),e.fillStyle="rgba(30,32,36,0.85)";for(const n of[-.02,.98,.48])e.fillRect(n*512,512*.12,512*.04,512*.5);return Le(t,!0)})}function Tc(r="rgba(255,255,255,1)",t="rgba(255,255,255,0)",e=128){const[n,i]=Pe(e,e),s=i.createRadialGradient(e/2,e/2,0,e/2,e/2,e/2);return s.addColorStop(0,r),s.addColorStop(1,t),i.fillStyle=s,i.fillRect(0,0,e,e),Le(n,!1)}function h0(){return ze("beam",()=>{const[r,t]=Pe(128,256),e=t.createLinearGradient(0,256,0,0);return e.addColorStop(0,"rgba(255,245,220,0.9)"),e.addColorStop(1,"rgba(255,245,220,0)"),t.fillStyle=e,t.beginPath(),t.moveTo(54,256),t.lineTo(74,256),t.lineTo(128,0),t.lineTo(0,0),t.closePath(),t.fill(),Le(r,!1)})}function u0(){return ze("pitsign",()=>{const[r,t]=Pe(256,128);return t.fillStyle="#0d3a8a",t.fillRect(0,0,256,128),t.strokeStyle="#fff",t.lineWidth=6,t.strokeRect(5,5,246,118),t.fillStyle="#fff",t.font='800 76px "Saira Condensed", sans-serif',t.textAlign="center",t.textBaseline="middle",t.fillText("PIT",82,68),t.fillStyle="#fff",t.beginPath(),t.arc(190,64,48,0,Math.PI*2),t.fill(),t.strokeStyle="#d4141c",t.lineWidth=11,t.beginPath(),t.arc(190,64,42,0,Math.PI*2),t.stroke(),t.fillStyle="#111",t.font='800 44px "Saira Condensed", sans-serif',t.fillText("80",190,67),Le(r,!1)})}function Al(r){return ze("garage"+r,()=>{const[t,e]=Pe(256,128);if(e.fillStyle=r?"#2a2f37":"#c9ced6",e.fillRect(0,0,256,128),e.fillStyle=r?"#e8e2c8":"#3a3f47",e.fillRect(22,30,212,98),r)e.fillStyle="rgba(255,255,255,0.5)",e.fillRect(22,30,212,10);else{e.fillStyle="rgba(255,255,255,0.08)";for(let n=34;n<128;n+=8)e.fillRect(22,n,212,3)}return e.fillStyle="#d4141c",e.fillRect(0,10,256,8),Le(t)})}const f0=2,Yn=1.3;function re(r,t){return(r%t+t)%t}class Rl{constructor(t){this.def=t,this.hw=t.halfWidth,this.group=new me,this.dynamic={lampHeads:null,pools:null,startLights:[],floodMats:[]},this._sample(),this._walls(),this._surfaces(),this._pit(),this._racingLine(),this._grid()}_sample(){const t=this.def.points.map(m=>new D(m[0],m[2]||0,m[1])),e=new Ym(t,!0,"centripetal"),n=e.getLength(),i=Math.round(n/f0),s=e.getSpacedPoints(i);s.pop(),this.N=i,this.length=n,this.ds=n/i;const a=this.px=new Float32Array(i),o=this.py=new Float32Array(i),l=this.pz=new Float32Array(i);s.forEach((m,p)=>{a[p]=m.x,o[p]=m.y,l[p]=m.z});for(let m=0;m<6;m++){const p=o.slice();for(let x=0;x<i;x++)o[x]=(p[re(x-2,i)]+p[re(x-1,i)]+p[x]+p[re(x+1,i)]+p[re(x+2,i)])/5}this.tx=new Float32Array(i),this.tz=new Float32Array(i),this.lx=new Float32Array(i),this.lz=new Float32Array(i),this.curv=new Float32Array(i),this.slope=new Float32Array(i),this.heading=new Float32Array(i);for(let m=0;m<i;m++){const p=re(m-1,i),x=re(m+1,i);let y=a[x]-a[p],v=l[x]-l[p];const R=Math.hypot(y,v);y/=R,v/=R,this.tx[m]=y,this.tz[m]=v,this.lx[m]=v,this.lz[m]=-y,this.heading[m]=Math.atan2(y,v),this.slope[m]=(o[x]-o[p])/(2*this.ds)}const c=3;for(let m=0;m<i;m++){let p=this.heading[re(m+c,i)]-this.heading[re(m-c,i)];for(;p>Math.PI;)p-=2*Math.PI;for(;p<-Math.PI;)p+=2*Math.PI;this.curv[m]=p/(2*c*this.ds)}let h=1/0,u=-1/0;for(let m=0;m<i;m++)h=Math.min(h,o[m]),u=Math.max(u,o[m]);this.minY=h,this.maxY=u,this.cell=24,this.hash=new Map;for(let m=0;m<i;m++){const p=this._key(Math.floor(a[m]/this.cell),Math.floor(l[m]/this.cell));this.hash.has(p)||this.hash.set(p,[]),this.hash.get(p).push(m)}let f=1/0,d=-1/0,g=1/0,_=-1/0;for(let m=0;m<i;m++)f=Math.min(f,a[m]),d=Math.max(d,a[m]),g=Math.min(g,l[m]),_=Math.max(_,l[m]);this.bounds={x0:f,x1:d,z0:g,z1:_,cx:(f+d)/2,cz:(g+_)/2,size:Math.max(d-f,_-g)}}_key(t,e){return t*73856093^e*19349663}nearest(t,e){const n=Math.floor(t/this.cell),i=Math.floor(e/this.cell);let s=1/0,a=-1;for(let o=0;o<=3;o++){for(let l=-o;l<=o;l++)for(let c=-o;c<=o;c++){if(Math.max(Math.abs(l),Math.abs(c))!==o)continue;const h=this.hash.get(this._key(n+l,i+c));if(h)for(const u of h){const f=(this.px[u]-t)**2+(this.pz[u]-e)**2;f<s&&(s=f,a=u)}}if(a>=0&&o>=1)break}if(a<0)for(let o=0;o<this.N;o++){const l=(this.px[o]-t)**2+(this.pz[o]-e)**2;l<s&&(s=l,a=o)}return{i:a,d:Math.sqrt(s)}}distToTrack(t,e){return this.nearest(t,e).d}_walls(){const t=this.N,e=this.hw,n=this.def,i=e+(n.kerbs?Yn:0)+n.runoff,s=new Float32Array(t).fill(i),a=new Float32Array(t).fill(i);for(let h=0;h<t;h++){const u=this.curv[h];if(Math.abs(u)>1e-4){const f=.8/Math.abs(u);u>0?s[h]=Math.min(s[h],f):a[h]=Math.min(a[h],f)}}const o=Math.ceil(i*3/this.ds)+6;for(let h=0;h<t;h++){const u=this.px[h],f=this.pz[h],d=Math.floor(u/this.cell),g=Math.floor(f/this.cell);for(let _=-3;_<=3;_++)for(let m=-3;m<=3;m++){const p=this.hash.get(this._key(d+_,g+m));if(p)for(const x of p){let y=Math.abs(h-x);if(y=Math.min(y,t-y),y<o)continue;const v=this.px[x]-u,R=this.pz[x]-f,T=Math.hypot(v,R);if(T>i*2+8)continue;const E=v*this.lx[h]+R*this.lz[h],P=T/2-1.5;E>0?s[h]=Math.min(s[h],P):a[h]=Math.min(a[h],P)}}}const l=e+(n.kerbs?Yn:0)+.9,c=h=>{let u=h.slice();for(let f=0;f<t;f++){let d=1/0;for(let g=-10;g<=10;g++)d=Math.min(d,u[re(f+g,t)]);h[f]=Math.max(l,d)}for(let f=0;f<3;f++){u=h.slice();for(let d=0;d<t;d++){let g=0;for(let _=-6;_<=6;_++)g+=u[re(d+_,t)];h[d]=Math.max(l,g/13)}}};c(s),c(a),this.wallL=s,this.wallR=a}_surfaces(){const t=this.N,e=this.def;if(this.kerb=new Uint8Array(t),e.kerbs){const i=new Uint8Array(t);for(let s=0;s<t;s++)i[s]=Math.abs(this.curv[s])>1/140?1:0;for(let s=0;s<t;s++){let a=0;for(let o=-6;o<=6;o++)a|=i[re(s+o,t)];this.kerb[s]=a}}const n={circuit:0,technical:0,night:3,street:3,mountain:2}[e.theme];if(this.runL=new Uint8Array(t).fill(n),this.runR=new Uint8Array(t).fill(n),e.theme==="circuit"||e.theme==="technical")for(let i=0;i<t;i++){let s=0;for(let a=-12;a<=4;a++)s+=this.curv[re(i+a,t)];s/=17,Math.abs(s)>1/110&&(s>0?this.runR[i]=1:this.runL[i]=1)}}_pit(){const t=this.N,e=this.ds,n=this.def,i=this.hw+(n.kerbs?Yn:0),s=i+1.2,a=.35,o=s+a+2.4,l=s+a+6.6,c=s+a+9.2,h=M=>{const C=this.curv[M];if(Math.abs(C)>1/120||C>0&&C*c>.45||this.kerb[M])return!1;const U=this.px[M],O=this.pz[M],V=Math.floor(U/this.cell),X=Math.floor(O/this.cell);for(let W=-3;W<=3;W++)for(let j=-3;j<=3;j++){const k=this.hash.get(this._key(V+W,X+j));if(k)for(const it of k){let q=Math.abs(M-it);if(q=Math.min(q,t-q),q<40)continue;const tt=this.px[it]-U,rt=this.pz[it]-O;if(Math.hypot(tt,rt)<c+this.hw+8&&tt*this.lx[M]+rt*this.lz[M]>0)return!1}}return!0},u=Math.floor(190/e);let f=0,d=0;for(;f<u&&h(re(f+1,t));)f++;for(;d>-u&&h(re(d-1,t));)d--;const g=d*e+4,_=f*e-4;if(this.pitZone=new Uint8Array(t),this.pit=null,_-g<150)return;const m=Math.min(36,(_-g)*.2),p=g+m+8,x=_-m-8,y=x-p-34,v=Math.max(4,Math.min(12,Math.floor(y/8.5))),R=Math.min(12,y/v),T=(p+x)/2-R*v/2,E=[];for(let M=0;M<v;M++)E.push(T+R*(M+.5));const P=M=>(M=Math.max(0,Math.min(1,M)),M*M*(3-2*M)),b=this.wallL.slice();for(let M=Math.floor(g/e)-2;M<=Math.ceil(_/e)+2;M++){const C=re(M,t),U=M*e;if(U<g||U>_)continue;const O=Math.min(P((U-g)/m),P((_-U)/m));this.wallL[C]=b[C]+(c-b[C])*O,this.pitZone[C]=U>=p&&U<=x?2:1}this.pit={sE:g,sX:_,sD0:p,sD1:x,D:s,DT:a,laneLat:o,boxLat:l,Wout:c,boxes:E,tp:m,limit:80/3.6,inner:i}}pitRel(t){const e=this.length;let n=t-this.pit.sE;return n=(n%e+e)%e,n>e-400&&(n-=e),n}pitPath(t,e,n,i){const s=this.pit,a=this.pitRel(t)+s.sE,o=h=>(h=Math.max(0,Math.min(1,h)),h*h*(3-2*h)),l=s.boxes[e];if(n===0){if(a<s.sE||a>s.sX)return i;let h=i+(s.laneLat-i)*o((a-s.sE)/(s.sD0-s.sE-4));return a>l-26&&(h+=(s.boxLat-s.laneLat)*o((a-(l-26))/20)),h}if(a<s.sE||a>s.sX)return i;let c=s.boxLat+(s.laneLat-s.boxLat)*o((a-l)/22);return a>s.sD1&&(c=s.laneLat+(i-s.laneLat)*o((a-s.sD1)/(s.sX-s.sD1))),c}_racingLine(){const t=this.N,e=new Float32Array(t),n=this.hw-1.7,i=7;for(let l=0;l<420;l++)for(let c=0;c<t;c++){const h=re(c-i,t),u=re(c+i,t),f=this.px[h]+this.lx[h]*e[h],d=this.pz[h]+this.lz[h]*e[h],g=this.px[u]+this.lx[u]*e[u],_=this.pz[u]+this.lz[u]*e[u],m=(f+g)/2-this.px[c],p=(d+_)/2-this.pz[c],x=m*this.lx[c]+p*this.lz[c];e[c]+=(x-e[c])*.55,e[c]>n&&(e[c]=n),e[c]<-n&&(e[c]=-n)}this.lineOff=e;const s=new Float32Array(t),a=new Float32Array(t);for(let l=0;l<t;l++)s[l]=this.px[l]+this.lx[l]*e[l],a[l]=this.pz[l]+this.lz[l]*e[l];this.linePX=s,this.linePZ=a;const o=new Float32Array(t);for(let l=0;l<t;l++){const c=re(l-4,t),h=re(l+4,t),u=s[c],f=a[c],d=s[l],g=a[l],_=s[h],m=a[h],p=Math.hypot(d-u,g-f),x=Math.hypot(_-d,m-g),y=Math.hypot(_-u,m-f),v=Math.abs((d-u)*(m-f)-(g-f)*(_-u));o[l]=2*v/Math.max(1e-6,p*x*y)}for(let l=0;l<2;l++){const c=o.slice();for(let h=0;h<t;h++)o[h]=(c[re(h-1,t)]+c[h]*2+c[re(h+1,t)])/4}this.lineCurv=o}speedProfile(t,e,n,i,s){const a=this.N,o=9.81,l=new Float32Array(a);for(let c=0;c<a;c++){const u=Math.max(this.lineCurv[c],1e-5)-t*e/n;let f=u<=0?120:Math.sqrt(t*o/u);l[c]=Math.min(f,120)}for(let c=0;c<3;c++)for(let h=a-1;h>=0;h--){const u=re(h+1,a);l[h]=Math.min(l[h],Math.sqrt(l[u]*l[u]+2*s*this.ds))}return l}project(t,e,n,i){const s=this.N;let a=-1,o=1/0;if(n==null||n<0)a=this.nearest(t,e).i;else{for(let R=-14;R<=14;R++){const T=re(n+R,s),E=(this.px[T]-t)**2+(this.pz[T]-e)**2;E<o&&(o=E,a=T)}o>60*60&&(a=this.nearest(t,e).i)}let l=a;const c=t-this.px[a],h=e-this.pz[a];c*this.tx[a]+h*this.tz[a]<0&&(l=re(a-1,s));const u=re(l+1,s),f=this.px[u]-this.px[l],d=this.pz[u]-this.pz[l],g=f*f+d*d;let _=((t-this.px[l])*f+(e-this.pz[l])*d)/g;_=Math.max(0,Math.min(1,_));const m=this.px[l]+f*_,p=this.pz[l]+d*_,x=this.lx[l]*(1-_)+this.lx[u]*_,y=this.lz[l]*(1-_)+this.lz[u]*_,v=Math.hypot(x,y);return i=i||{},i.i=l,i.t=_,i.s=(l+_)*this.ds,i.lat=((t-m)*x+(e-p)*y)/v,i.y=this.py[l]*(1-_)+this.py[u]*_,i.tx=this.tx[l]*(1-_)+this.tx[u]*_,i.tz=this.tz[l]*(1-_)+this.tz[u]*_,i.lx=x/v,i.lz=y/v,i.slope=this.slope[l]*(1-_)+this.slope[u]*_,i.wallL=this.wallL[l]*(1-_)+this.wallL[u]*_,i.wallR=this.wallR[l]*(1-_)+this.wallR[u]*_,i.curv=this.curv[l],i.pit=this.pitZone?this.pitZone[l]:0,i}surfaceAt(t,e){const n=Math.abs(e);if(n<=this.hw)return 0;if(this.kerb[t]&&n<=this.hw+Yn)return 4;if(e>0&&this.pitZone[t])return 0;const i=e>0?this.runL[t]:this.runR[t];return i===3?5:i+1}pointAt(t,e=0){const n=this.N;t=(t%this.length+this.length)%this.length;const i=t/this.ds,s=Math.floor(i)%n,a=(s+1)%n,o=i-Math.floor(i),l=this.px[s]*(1-o)+this.px[a]*o,c=this.pz[s]*(1-o)+this.pz[a]*o,h=this.py[s]*(1-o)+this.py[a]*o;return{x:l+this.lx[s]*e,z:c+this.lz[s]*e,y:h,heading:Math.atan2(this.tx[s],this.tz[s]),i:s}}_grid(){this.gridSlots=[];for(let t=0;t<12;t++){const e=-10-t*9,n=(t%2===0?1:-1)*this.hw*.42;this.gridSlots.push(this.pointAt(e,n))}}_strip(t,e,n,i,s,a=0){const o=this.N,l=[],c=[],h=[],u=[];for(let g=0;g<=o;g++){const _=g%o,[m,p]=t(_),[x,y]=e(_),v=this.py[_]+a;l.push(this.px[_]+this.lx[_]*m,v+p,this.pz[_]+this.lz[_]*m),l.push(this.px[_]+this.lx[_]*x,v+y,this.pz[_]+this.lz[_]*x);const R=g*this.ds/i;c.push(n?m/n:0,R,n?x/n:1,R),u.push(0,1,0,0,1,0)}for(let g=0;g<o;g++){if(s&&!s(g))continue;const _=g*2,m=_+1,p=_+2,x=_+3;h.push(_,m,p,m,x,p)}const f=new de;f.setAttribute("position",new Kt(l,3)),f.setAttribute("uv",new Kt(c,2)),f.setAttribute("normal",new Kt(u,3)),f.setIndex(h),f.computeVertexNormals();const d=f.attributes.normal;for(let g=0;g<d.count;g++)d.getY(g)<0&&d.setXYZ(g,-d.getX(g),-d.getY(g),-d.getZ(g));return f}_wallGeo(t,e){const n=this.N,i=t>0?this.wallL:this.wallR,s=[],a=[],o=[];for(let c=0;c<=n;c++){const h=c%n,u=i[h]*t,f=this.px[h]+this.lx[h]*u,d=this.pz[h]+this.lz[h]*u,g=this.py[h],_=c*this.ds/8;s.push(f,g-.6,d,f,g+e,d),a.push(_,0,_,1)}for(let c=0;c<n;c++){const h=c*2,u=h+1,f=h+2,d=h+3;t>0?o.push(h,f,u,u,f,d):o.push(h,u,f,u,d,f)}const l=new de;return l.setAttribute("position",new Kt(s,3)),l.setAttribute("uv",new Kt(a,2)),l.setIndex(o),l.computeVertexNormals(),l}build(t){const e=this.def,n=this.hw,i=this.group,s=e.theme==="street",a=new Ft({map:n0(s),roughnessMap:i0(),roughness:.92,metalness:0});this.roadMat=a;const o=new ot(this._strip(()=>[n,0],()=>[-n,0],0,14,null,.02),a);if(o.receiveShadow=!0,i.add(o),e.kerbs){const f=new Ft({map:s0(),roughness:.6}),d=m=>this.kerb[m],g=new ot(this._strip(()=>[n+Yn,.06],()=>[n-.05,0],0,4,d,.02),f),_=new ot(this._strip(()=>[-n+.05,0],()=>[-n-Yn,.06],0,4,d,.02),f);g.receiveShadow=_.receiveShadow=!0,i.add(g,_)}const l=n+(e.kerbs?Yn:0),c=[[0,Vr(),12],[1,Hs("gravel"),6],[2,Hs("dirt"),8],[3,Hs("pavement"),4]];for(const[f,d,g]of c){const _=new Ft({map:d,roughness:1}),m=this._strip(x=>[this.wallL[x]+.3,0],()=>[l-.02,0],g,g,x=>this.runL[x]===f&&!this.pitZone[x],-.005),p=this._strip(()=>[-l+.02,0],x=>[-this.wallR[x]-.3,0],g,g,x=>this.runR[x]===f,-.005);for(const x of[m,p]){if(x.index.count===0)continue;const y=new ot(x,_);y.receiveShadow=!0,i.add(y)}}const h=e.wall==="concrete"?1.25:e.wall==="tyre"?1:.9,u=new Ft({map:El(e.wall),roughness:e.wall==="armco"?.35:.85,metalness:e.wall==="armco"?.6:0,side:Ve});for(const f of[1,-1]){const d=new ot(this._wallGeo(f,h),u);d.castShadow=t!=="low",d.receiveShadow=!0,i.add(d)}if(e.theme==="circuit"||e.theme==="night"){const f=new Ft({color:10134186,transparent:!0,opacity:.18,side:Ve,metalness:.5,roughness:.5,depthWrite:!1});for(const d of[1,-1]){const g=this._wallGeo(d,4),_=g.attributes.position;for(let p=0;p<_.count;p+=2)_.setY(p,_.getY(p)+.6+h);const m=new ot(g,f);i.add(m)}}this._ground(t),this._pitLane(t),this._startFinish(),this._sectors(),this._scenery(t),this._lamps(),this._cameraSpots()}_pitLane(t){const e=this.pit,n=this.group,i=this.N,s=this.ds;if(this.pitBoxMats=[],!e)return;const a=this.def.theme==="night",o=this.roadMat,l=new ot(this._strip(q=>[this.wallL[q]+.3,0],()=>[e.inner-.02,0],0,14,q=>this.pitZone[q],.02),o);l.receiveShadow=!0,n.add(l);const c=new Ft({color:15263976,roughness:.7,polygonOffset:!0,polygonOffsetFactor:-2}),h=new Ft({color:15909912,roughness:.7,polygonOffset:!0,polygonOffsetFactor:-2}),u=e.D+e.DT+4.6;n.add(new ot(this._strip(()=>[u+.09,0],()=>[u-.09,0],0,4,q=>this.pitZone[q]===2,.03),c));const f=(q,tt)=>{const rt=[];for(let ut=Math.ceil(q/s);ut<=Math.floor(tt/s);ut++)rt.push(ut);return rt},d=(q,tt,rt,ut,B)=>{const J=[],ht=[];q.forEach((xt,Y)=>{const et=re(xt,i),[dt,zt]=tt(et,xt),[L,Qt]=rt(et,xt),Ot=this.py[et];if(J.push(this.px[et]+this.lx[et]*dt,Ot+zt,this.pz[et]+this.lz[et]*dt),J.push(this.px[et]+this.lx[et]*L,Ot+Qt,this.pz[et]+this.lz[et]*L),Y>0){const It=(Y-1)*2;ht.push(It,It+1,It+2,It+1,It+3,It+2)}});const at=new de;if(at.setAttribute("position",new Kt(J,3)),at.setIndex(ht),at.computeVertexNormals(),!B){const xt=at.attributes.normal;for(let Y=0;Y<xt.count;Y++)xt.getY(Y)<0&&xt.setXYZ(Y,-xt.getX(Y),-xt.getY(Y),-xt.getZ(Y))}const wt=new ot(at,ut);return wt.receiveShadow=!0,n.add(wt),wt},g=q=>(q=Math.max(0,Math.min(1,q)),q*q*(3-2*q)),_=q=>{const tt=q*s,rt=tt<0||tt<e.sD0+1?(tt-e.sE)/(e.sD0-e.sE):(e.sX-tt)/(e.sX-e.sD1);return e.inner+.15+(e.D-e.DT-e.inner-.15)*g(rt)};d(f(e.sE+6,e.sD0),(q,tt)=>[_(tt)+.12,.03],(q,tt)=>[_(tt)-.12,.03],c),d(f(e.sD1,e.sX-6),(q,tt)=>[_(tt)+.12,.03],(q,tt)=>[_(tt)-.12,.03],c);const m=new Ft({map:El("concrete"),roughness:.85}),p=f(e.sD0,e.sD1),x=1.05,y=d(p,()=>[e.D-e.DT,-.3],()=>[e.D-e.DT,x],m,!0),v=d(p,()=>[e.D+e.DT,x],()=>[e.D+e.DT,-.3],m,!0);d(p,()=>[e.D+e.DT,x],()=>[e.D-e.DT,x],new Ft({color:14211288,roughness:.8})),y.castShadow=v.castShadow=t!=="low";const R=new me;for(let q=0;q<3;q++){const tt=new ot(new Gt(e.DT*2+.3,.95,.9),new Ft({color:q%2?1118481:15909912,roughness:.6}));tt.position.set(0,.48,-.45-q*.92),tt.castShadow=!0,R.add(tt)}this._placeOnTrack(R,e.sD0+.2,e.D,0,0),n.add(R);for(let q=0;q<e.boxes.length;q++){const tt=e.boxes[q],rt=new me,ut=new Oe({color:3817287,transparent:!0,opacity:.55,polygonOffset:!0,polygonOffsetFactor:-1,depthWrite:!1}),B=new ot(new Me(3.4,6.2),ut);B.rotation.x=-Math.PI/2,rt.add(B);for(const[J,ht,at,wt]of[[3.4,.16,0,3.1],[3.4,.16,0,-3.1],[.16,6.2,1.7,0],[.16,6.2,-1.7,0]]){const xt=new ot(new Me(J,ht),h);xt.rotation.x=-Math.PI/2,xt.position.set(at,.005,wt),rt.add(xt)}this._placeOnTrack(rt,tt,e.boxLat,0,.035),n.add(rt),this.pitBoxMats.push(ut)}const T=e.boxes.length>1?e.boxes[1]-e.boxes[0]:10,E=new Ft({map:Al(a),roughness:.6,emissive:a?16777215:0,emissiveMap:a?Al(a):null,emissiveIntensity:a?.35:0}),P=new Ft({color:a?2830392:12173255,roughness:.7,metalness:.1}),b=new Ft({color:a?1843238:7107452,roughness:.5,metalness:.4}),M=6.5,C=14;for(let q=0;q<e.boxes.length;q++){const tt=new me,rt=new Gt(C,M,T-.3),ut=new ot(rt,[P,E,b,P,P,P]);ut.position.set(0,M/2,0),ut.castShadow=!0,ut.receiveShadow=!0,tt.add(ut),this._placeOnTrack(tt,e.boxes[q],e.Wout+.6+C/2,0,0),n.add(tt)}const U=T*e.boxes.length+8,O=new ot(new Gt(C+4,.5,U),b);O.castShadow=!0;const V=new me;O.position.set(0,M+.25,0),V.add(O),this._placeOnTrack(V,(e.boxes[0]+e.boxes[e.boxes.length-1])/2,e.Wout+.6+C/2-1.5,0,0),n.add(V);const X=new me,W=new Ft({color:2764083,metalness:.5,roughness:.5});for(const q of[-1.1,1.1]){const tt=new ot(new Gt(.14,3.2,.14),W);tt.position.set(q,1.6,0),X.add(tt)}const j=new ot(new Me(2.8,1.4),new Oe({map:u0()}));j.position.set(0,3,.08),j.rotation.y=Math.PI,X.add(j);const k=re(Math.round((e.sE-50)/s),i);this._placeOnTrack(X,e.sE-50,this.wallL[k]-.6,0,0),n.add(X);const it=X.clone();this._placeOnTrack(it,e.sD0+3,e.D,0,x),it.scale.setScalar(.55),n.add(it)}setPitBoxColors(t){(this.pitBoxMats||[]).forEach((e,n)=>{t[n]&&(e.color.set(t[n]),e.opacity=.5)})}_ground(t){const e=this.def,n=this.bounds,i=e.theme==="mountain",s=i?this.minY-3:-.04;let a,o=16777215;e.theme==="night"||e.theme==="street"?(a=Hs("concrete"),o=e.theme==="night"?7830400:10526880):a=Vr(),a=a.clone(),a.needsUpdate=!0,a.repeat.set(220,220);const l=new ot(new Me(5e3,5e3,48,48),new Ft({map:a,color:o,roughness:1}));if(l.rotation.x=-Math.PI/2,l.position.set(n.cx,s,n.cz),l.receiveShadow=!0,this.group.add(l),i){const c=new Ft({map:Vr(),color:10465418,roughness:1});for(const h of[1,-1]){const u=h>0?this.wallL:this.wallR,f=this._strip(_=>[h*(u[_]+.2),0],_=>[h*(u[_]+8+(this.py[_]-s)*1.6),-(this.py[_]-s)-.5],10,10,null,-.02);h>0&&f.index.array.reverse(),f.computeVertexNormals();const d=f.attributes.normal;for(let _=0;_<d.count;_++)d.getY(_)<0&&d.setXYZ(_,-d.getX(_),-d.getY(_),-d.getZ(_));const g=new ot(f,c);g.material.side=Ve,g.receiveShadow=!0,this.group.add(g)}}this.groundY=s}_placeOnTrack(t,e,n,i=0,s=0){const a=this.pointAt(e,n);return t.position.set(a.x,a.y+s,a.z),t.rotation.y=a.heading+i,a}_startFinish(){const t=this.hw,e=this.group,n=new ot(new Me(t*2,1.6),new Ft({map:r0(),roughness:.7,polygonOffset:!0,polygonOffsetFactor:-2}));n.rotation.x=-Math.PI/2;const i=new me;i.add(n),this._placeOnTrack(i,0,0,0,.035),e.add(i);const s=new Oe({color:15790320,polygonOffset:!0,polygonOffsetFactor:-2});for(const u of this.gridSlots.slice(0,10)){const f=new me,d=new ot(new Me(3.2,.25),s);d.rotation.x=-Math.PI/2,d.position.z=2.9,f.add(d);for(const g of[-1.6,1.6]){const _=new ot(new Me(.2,1.2),s);_.rotation.x=-Math.PI/2,_.position.set(g,0,2.4),f.add(_)}f.position.set(u.x,u.y+.034,u.z),f.rotation.y=u.heading,e.add(f)}const a=new me,o=new Ft({color:2303531,metalness:.6,roughness:.4}),l=Math.max(this.wallL[0],this.wallR[0])+.6;for(const u of[-l,l]){const f=new ot(new Gt(.7,8,.7),o);f.position.set(u,4,0),f.castShadow=!0,a.add(f)}const c=new ot(new Gt(l*2+.7,1.4,.9),o);c.position.set(0,7.6,0),c.castShadow=!0,a.add(c);const h=new ot(new Me(l*2,1.2),new Oe({map:Wr(0)}));h.position.set(0,7.6,.46),h.rotation.y=Math.PI,a.add(h);for(let u=0;u<5;u++){const f=new Ft({color:2228224,emissive:16715792,emissiveIntensity:0});for(const g of[-.47,.47]){const _=new ot(new eo(.28,16),f);_.position.set((u-2)*1,6.6,g*1.02),_.rotation.y=g<0?Math.PI:0,a.add(_)}const d=new ot(new Gt(.8,.8,.9),o);d.position.set((u-2)*1,6.6,0),a.add(d),this.dynamic.startLights.push(f)}this._placeOnTrack(a,0,0,0,0),e.add(a)}_sectors(){const t=new Ft({color:3159098,metalness:.5,roughness:.5});this.sectorS=[this.length/3,2*this.length/3],this.sectorS.forEach((e,n)=>{const[i,s]=(()=>{const o=document.createElement("canvas");return o.width=256,o.height=128,[o,o.getContext("2d")]})();s.fillStyle="#111317",s.fillRect(0,0,256,128),s.fillStyle="#ffd400",s.fillRect(0,108,256,20),s.fillStyle="#fff",s.font='800 64px "Saira Condensed", sans-serif',s.textAlign="center",s.textBaseline="middle",s.fillText(`SECTOR ${n+2}`,128,56);const a=new Mc(i);a.colorSpace=Ue;for(const o of[1,-1]){const l=Math.floor(e/this.ds)%this.N,c=o*((o>0?this.wallL[l]:this.wallR[l])+.8),h=new me,u=new ot(new Gt(.25,4,.25),t);u.position.y=2;const f=new ot(new Me(2.4,1.2),new Oe({map:a,side:Ve}));f.position.y=4.2,h.add(u,f),this._placeOnTrack(h,e,c,Math.PI,0),this.group.add(h)}})}_scenery(t){const e=this.def,n=this.bounds,i=this.group,s=En(e.id.length*977+13),a=u=>Math.max(this.wallL[u],this.wallR[u]),o=(u,f,d)=>{const g=this.nearest(u,f);return g.d>a(g.i)+d},l=t==="low"?.45:t==="medium"?.75:1,c=Math.floor({circuit:900,technical:1200,mountain:2200,night:160,street:60}[e.theme]*l);if(c){const u=e.theme==="mountain"||e.theme==="technical",f=new un(.18,.28,3,6);f.translate(0,1.5,0);let d;if(u){const M=new ei(2.2,5,7);M.translate(0,4.5,0);const C=new ei(1.6,4,7);C.translate(0,7,0);const U=new ei(1,3,7);U.translate(0,9.2,0),d=vn([M,C,U])}else{d=new io(2.6,1);const M=d.attributes.position,C=En(4);for(let U=0;U<M.count;U++)M.setXYZ(U,M.getX(U)*(.85+C()*.3),M.getY(U)*(.8+C()*.3),M.getZ(U)*(.85+C()*.3));d=vn([d.toNonIndexed()]),d.computeVertexNormals(),d.scale(1,1.1,1),d.translate(0,5,0)}const g=new Ft({color:4863268,roughness:1}),_=new Ft({color:16777215,roughness:.9,flatShading:!0}),m=new Jn(f,g,c),p=new Jn(d,_,c),x=new Zt,y=new kn,v=new D,R=new D,T=new Pt;let E=0,P=0;const b=n.size*.75+260;for(;E<c&&P<c*12;){P++;const M=n.cx+(s()-.5)*b*2,C=n.cz+(s()-.5)*b*2;if(!o(M,C,7))continue;const U=this.nearest(M,C);if(U.d>200&&s()<.6)continue;let O=e.theme==="mountain"?this._terrainY(M,C,U):0;const V=.7+s()*.8;R.set(M,O-.2,C),y.setFromAxisAngle(new D(0,1,0),s()*6.28),v.set(V,V*(.9+s()*.3),V),x.compose(R,y,v),m.setMatrixAt(E,x),p.setMatrixAt(E,x),u?T.setHSL(.3+s()*.06,.45+s()*.2,.16+s()*.08):T.setHSL(.22+s()*.1,.45+s()*.25,.22+s()*.12),p.setColorAt(E,T),E++}m.count=p.count=E,p.castShadow=t==="high",m.castShadow=!1,p.receiveShadow=!0,i.add(m,p)}if(e.theme!=="mountain"){const u=this._grandstandGeo(),f=new Ft({map:a0(),roughness:.9}),d=new Ft({color:4277838,roughness:.6,metalness:.3}),g=new Ft({color:14672872,roughness:.4,metalness:.4});for(let _=0;_<4;_++){const m=-60+_*34,p=Math.floor((m%this.length+this.length)%this.length/this.ds);if(Math.abs(this.curv[p])>1/300)continue;const x=new me,y=new ot(u.steps,f),v=new ot(u.frame,d),R=new ot(u.roof,g);y.castShadow=v.castShadow=R.castShadow=!0,y.receiveShadow=!0,x.add(y,v,R),this._placeOnTrack(x,m,-(this.wallR[p]+3),0,0),i.add(x)}}const h=10;for(let u=0;u<h;u++){const f=(u+.5)/h*this.length,d=Math.floor(f/this.ds)%this.N,g=this.curv[d]>0?-1:1,_=g*((g>0?this.wallL[d]:this.wallR[d])+1.2),m=new me,p=new ot(new Me(12,3),new Ft({map:Wr(u+1),roughness:.5,emissive:16777215,emissiveMap:Wr(u+1),emissiveIntensity:0}));p.position.y=2.6,p.rotation.y=g>0?-Math.PI/2:Math.PI/2,this.dynamic.floodMats.push(p.material);const x=new ot(new Gt(.2,3.2,12.2),new Ft({color:2830133}));x.position.set(g*.12,2.6,0),m.add(p,x);for(const y of[-5,5]){const v=new ot(new Gt(.2,1.2,.2),x.material);v.position.set(g*.1,.6,y),m.add(v)}this._placeOnTrack(m,f,_,0,0),m.traverse(y=>{y.isMesh&&(y.castShadow=!0)}),i.add(m)}if((e.theme==="street"||e.theme==="night")&&this._buildings(s,o,e.theme==="night",l),e.theme==="mountain"&&this._mountains(s),(e.theme==="circuit"||e.theme==="technical")&&this._hills(s),e.theme==="mountain"){const u=new no(1.4,0),f=new Ft({color:8223348,roughness:1,flatShading:!0}),d=Math.floor(260*l),g=new Jn(u,f,d),_=new Zt,m=new kn,p=new D,x=new D;let y=0,v=0;for(;y<d&&v<d*20;){v++;const R=Math.floor(s()*this.N),T=s()>.5?1:-1,E=T*((T>0?this.wallL[R]:this.wallR[R])+2+s()*30),P=this.px[R]+this.lx[R]*E,b=this.pz[R]+this.lz[R]*E;if(!o(P,b,1.5))continue;const M=this.nearest(P,b);x.set(P,this._terrainY(P,b,M),b),m.setFromEuler(new rn(s()*3,s()*3,s()*3));const C=.5+s()*1.8;p.set(C*(1+s()),C,C*(1+s())),_.compose(x,m,p),g.setMatrixAt(y++,_)}g.count=y,g.castShadow=t==="high",g.receiveShadow=!0,i.add(g)}}_terrainY(t,e,n){const i=n.i,s=Math.max(this.wallL[i],this.wallR[i]),a=this.py[i],o=this.minY-3,l=Math.max(0,n.d-s-.2),c=Math.max(0,(l-8)/1.6);return Math.max(o,a-Math.min(a-o,c)-(l>0?Math.min(.5,l*.06):0))}_grandstandGeo(){const t=[];for(let o=0;o<8;o++){const l=new Gt(30,.9,1.4),c=l.attributes.uv;for(let h=0;h<c.count;h++)c.setXY(h,c.getX(h)*3,(c.getY(h)+o)/8);l.translate(0,.45+o*.9,-o*1.4),t.push(l)}const i=[],s=new Gt(30,8*.9+4,.4);s.translate(0,(8*.9+4)/2,-8*1.4),i.push(s);for(const o of[-30/2,30/2]){const l=new Gt(.4,11.2,11.2);l.translate(o,(8*.9+4)/2,-8*.7),i.push(l)}const a=new Gt(32,.3,8*1.4+3);return a.rotateX(-.08),a.translate(0,8*.9+4.2,-8*.7+.8),{steps:vn(t),frame:vn(i),roof:a}}_buildings(t,e,n,i){const s=this.bounds,a=[[],[]],o=Math.floor((n?260:340)*i);let l=0,c=0;for(;l<o&&c<o*30;){c++;let h,u,f=!1;if(n&&t()<.5){const v=t()*Math.PI*2,R=s.size*.6+200+t()*500;h=s.cx+Math.cos(v)*R,u=s.cz+Math.sin(v)*R,f=!0}else h=s.cx+(t()-.5)*(s.size+260),u=s.cz+(t()-.5)*(s.size+260);const d=14+t()*22,g=14+t()*22,_=f?40+t()*140:10+t()*(n?50:70),m=Math.hypot(d,g)/2;if(!e(h,u,m+3))continue;const p=new Gt(d,_,g),x=p.attributes.uv,y=p.attributes.normal;for(let v=0;v<x.count;v++){const R=y.getY(v),T=y.getX(v);if(Math.abs(R)>.5){x.setXY(v,.001,.001);continue}const E=Math.abs(T)>.5?g:d;x.setXY(v,x.getX(v)*E/32,x.getY(v)*_/60)}p.translate(h,_/2-.05,u),p.rotateY(0),a[l%2].push(p),l++}a.forEach((h,u)=>{if(!h.length)return;const f=o0(40+u,n),d=new Ft({map:f,roughness:n?.8:.35,metalness:n?.1:.5,emissive:n?16777215:0,emissiveMap:n?f:null,emissiveIntensity:n?1.4:0,color:n?6711920:[14210252,12568786][u]}),g=new ot(vn(h),d);g.castShadow=!0,g.receiveShadow=!0,this.group.add(g),this.dynamic.buildingMat=this.dynamic.buildingMat||[],this.dynamic.buildingMat.push(d)})}_mountains(t){const e=this.bounds,n=[],i=[];for(let o=0;o<28;o++){const l=o/28*Math.PI*2+t()*.2,c=e.size*.8+600+t()*700,h=220+t()*420,u=300+t()*380,f=new ei(u,h,9,4),d=f.attributes.position;for(let _=0;_<d.count;_++){const m=d.getY(_);m<h/2-1&&d.setXYZ(_,d.getX(_)*(.8+t()*.45),m+(t()-.5)*h*.06,d.getZ(_)*(.8+t()*.45))}f.translate(e.cx+Math.cos(l)*c,h/2+this.minY-6,e.cz+Math.sin(l)*c),n.push(f);const g=new ei(u*.3,h*.3,9,1);g.translate(e.cx+Math.cos(l)*c,h*.85+this.minY-6+1,e.cz+Math.sin(l)*c),i.push(g)}const s=new ot(vn(n.map(o=>o.toNonIndexed())),new Ft({color:6253154,roughness:1,flatShading:!0})),a=new ot(vn(i.map(o=>o.toNonIndexed())),new Ft({color:16054266,roughness:.8,flatShading:!0}));this.group.add(s,a)}_hills(t){const e=this.bounds,n=[];for(let s=0;s<22;s++){const a=s/22*Math.PI*2+t()*.3,o=e.size*.7+500+t()*500,l=60+t()*120,c=250+t()*300,h=new oi(c,12,6,0,Math.PI*2,0,Math.PI/2);h.scale(1,l/c,1),h.translate(e.cx+Math.cos(a)*o,-2,e.cz+Math.sin(a)*o),n.push(h.toNonIndexed())}const i=new ot(vn(n),new Ft({color:5206848,roughness:1,flatShading:!0}));this.group.add(i)}_lamps(){const t=this.def.theme==="night"||this.def.theme==="street"?36:60,e=Math.floor(this.length/t),n=new un(.12,.18,10,6);n.translate(0,5,0);const i=new Gt(.12,.12,3);i.translate(0,9.9,1.5);const s=vn([n,i]),a=new Gt(.6,.18,1.2);a.translate(0,9.8,3);const o=new Ft({color:3817286,metalness:.6,roughness:.5}),l=new Ft({color:8947848,emissive:16773590,emissiveIntensity:0}),c=new Jn(s,o,e),h=new Jn(a,l,e),u=new Me(1,1);u.rotateX(-Math.PI/2);const f=new Oe({map:Tc("rgba(255,236,200,0.55)","rgba(255,236,200,0)"),transparent:!0,depthWrite:!1,blending:Ii,opacity:0,polygonOffset:!0,polygonOffsetFactor:-4}),d=new Jn(u,f,e),g=new Zt,_=new kn,m=new D(1,1,1),p=new D;this.lampPositions=[];for(let x=0;x<e;x++){const y=x*t+18,v=Math.floor(y/this.ds)%this.N,R=x%2?1:-1,T=R*((R>0?this.wallL[v]:this.wallR[v])+.9),E=this.pointAt(y,T);p.set(E.x,E.y,E.z),_.setFromAxisAngle(new D(0,1,0),E.heading+(R>0?-Math.PI/2:Math.PI/2)),m.set(1,1,1),g.compose(p,_,m),c.setMatrixAt(x,g),h.setMatrixAt(x,g);const P=this.pointAt(y,T-R*6);p.set(P.x,P.y+.05,P.z),m.set(24,1,24),_.identity(),g.compose(p,_,m),d.setMatrixAt(x,g),this.lampPositions.push(P)}c.castShadow=!0,this.group.add(c,h,d),this.dynamic.lampHeads=l,this.dynamic.pools=f}_cameraSpots(){this.camSpots=[];const t=120;for(let e=40;e<this.length;e+=t){const n=Math.floor(e/this.ds)%this.N,i=this.curv[n]>0?-1:1,s=i*((i>0?this.wallL[n]:this.wallR[n])+4),a=this.pointAt(e,s);this.camSpots.push({s:e,x:a.x,y:a.y+3+e*7%5,z:a.z})}}setNight(t,e){const n=this.dynamic;n.lampHeads&&(n.lampHeads.emissiveIntensity=e?6:0),n.pools&&(n.pools.opacity=e?t:0),n.floodMats.forEach(i=>i.emissiveIntensity=e?.6*t:0)}setStartLights(t,e=!1){this.dynamic.startLights.forEach((n,i)=>{n.emissive.set(e?2162496:16715792),n.emissiveIntensity=e?4:i<t?5:0})}dispose(){d0(this.group)}}function d0(r){const t=new Set;r.traverse(e=>{e.geometry&&e.geometry.dispose(),e.material&&(Array.isArray(e.material)?e.material:[e.material]).forEach(n=>t.add(n))});for(const e of t){for(const n of["map","roughnessMap","normalMap","emissiveMap","alphaMap","metalnessMap"]){const i=e[n];i&&i.isTexture&&!wc(i)&&i.dispose()}e.dispose()}}const Ai=(r,t,e)=>{const n=Math.max(0,Math.min(1,(e-r)/(t-r)));return n*n*(3-2*n)},Vs=(r,t)=>Math.exp(-(r*r)/(2*t*t));function p0(r,t){for(let e=0;e<r.length-1;e++){const[n,i]=r[e],[s,a]=r[e+1];if(t>=n&&t<=s){const o=(t-n)/(s-n),l=o*o*(3-2*o);return i+(a-i)*l}}return r[r.length-1][1]}function Cl(r,t,e){const n=[],i=[],s=[],a=[],o=r.length;for(let u=0;u<o;u++){const f=r[u];for(let d=0;d<=t;d++){const g=d/t*Math.PI*2,_=Math.cos(g),m=Math.sin(g),p=2/f.n,x=Math.sign(_)*Math.pow(Math.abs(_),p),y=Math.sign(m)*Math.pow(Math.abs(m),m>0?p:2/(f.nb||f.n)),v=(f.yb+f.yt)/2,R=(f.yt-f.yb)/2,T=v+R*y,E=(T-f.yb)/Math.max(.001,f.yt-f.yb),P=f.w*x*(1-f.taper*E*E);n.push(P,T,f.z),i.push(d/t,u/(o-1))}}const l=t+1;for(let u=0;u<o-1;u++)for(let f=0;f<t;f++){const d=u*l+f,g=d+1,_=d+l,m=_+1;(e&&e(u,f,t,o)?a:s).push(d,g,_,g,m,_)}const c=(u,f)=>{const d=r[u],g=n.length/3;n.push(0,(d.yb+d.yt)/2,d.z),i.push(.5,u/(o-1));for(let _=0;_<t;_++){const m=u*l+_,p=m+1;f?s.push(g,p,m):s.push(g,m,p)}};c(0,!0),c(o-1,!1);const h=new de;return h.setAttribute("position",new Kt(n,3)),h.setAttribute("uv",new Kt(i,2)),h.setIndex([...s,...a]),h.addGroup(0,s.length,0),a.length&&h.addGroup(s.length,a.length,1),h.computeVertexNormals(),h}const $e={};function m0(){return $e.carbon||($e.carbon=new Ft({color:1184534,roughness:.45,metalness:.3}),$e.glass=new yc({color:658963,roughness:.03,metalness:.4,clearcoat:1,clearcoatRoughness:.02,envMapIntensity:1.6}),$e.tire=new Ft({color:1381653,roughness:.92}),$e.rim=new Ft({color:12106946,roughness:.22,metalness:.95}),$e.rimDark=new Ft({color:2763824,roughness:.3,metalness:.9}),$e.caliper=new Ft({color:14032678,roughness:.4,metalness:.3}),$e.chrome=new Ft({color:14540253,roughness:.1,metalness:1}),$e.interior=new Ft({color:1776671,roughness:.8}),$e.shadowTex=Tc("rgba(0,0,0,0.75)","rgba(0,0,0,0)",128)),$e}class Pl{constructor(t,e,n=1){const i=t.model,s=m0();this.spec=t,this.root=new me,this.body=new me,this.root.add(this.body);const a=i.len,o=i.halfW,l=t.wheelR,c=i.wheelBase/2,h=-i.wheelBase/2;this.axF=c,this.axR=h;const u=Y=>p0(i.top,(Y+a/2)/a);this.topAt=u,this.paint=new yc({color:new Pt(e),map:c0(0),metalness:.55,roughness:.32,clearcoat:1,clearcoatRoughness:.035,envMapIntensity:1.25});const f=[],d=40;for(let Y=0;Y<d;Y++){const et=Y/(d-1),dt=-a/2+et*a,zt=u(dt),L=Math.max(Vs(dt-c,.45),Vs(dt-h,.45));let Qt=o*(.9+.1*L);Qt*=1-.28*Ai(.86,1,et)-.1*Ai(.1,0,et);const Ot=Math.max(Vs(dt-c,l*.82),Vs(dt-h,l*.82)),It=Math.min(2*l+.02,zt-.16);let Tt=i.bodyBottom+(It-i.bodyBottom)*Ot;Tt+=.08*Ai(.92,1,et)+.05*Ai(.06,0,et),f.push({z:dt,w:Qt,yb:Tt,yt:zt,n:5,nb:8,taper:.16})}f[0].w*=.9,f[d-1].w*=.8;const g=Cl(f,40);this.bodyMesh=new ot(g,this.paint),this.bodyMesh.castShadow=!0,this.body.add(this.bodyMesh),this.basePos=Float32Array.from(g.attributes.position.array);const _=new ot(new Gt(o*1.7,.08,i.wheelBase+.4),s.carbon);_.position.y=i.bodyBottom+.04,this.body.add(_);const m=i.cabin,p=-a/2+m.z0*a,x=-a/2+m.z1*a,y=[],v=18;for(let Y=0;Y<v;Y++){const et=Y/(v-1),dt=p+(x-p)*et,zt=u(dt)-.06,L=Ai(0,.38,et)*(1-Ai(1-m.rake,1,et)),Qt=zt+.06+(m.roof-zt-.06)*L,Ot=m.halfW*(.82+.18*Math.sin(Math.PI*et));y.push({z:dt,w:Ot,yb:zt-.15,yt:Math.max(Qt,zt+.07),n:3.2,taper:.42})}const R=Cl(y,32,(Y,et,dt,zt)=>{const L=(et+.5)/dt*Math.PI*2,Qt=Y/(zt-1);return Math.sin(L)>.8&&Qt>.3&&Qt<.62-m.rake*.25}),T=new ot(R,[s.glass,this.paint]);T.castShadow=!0,this.body.add(T),this.cabinMesh=T;const E=m.roof;this.driverPos=new D(o*.3,u((p+x)/2)+(E-u((p+x)/2))*.55,p+(x-p)*.42),this.cockpitHide=[];const P=p+(x-p)*(1-m.rake);for(const Y of[-1,1]){const et=new D(Y*m.halfW*.86,u(x)+.02,x-.05),dt=new D(Y*m.halfW*.78,E-.03,P),zt=et.distanceTo(dt),L=new ot(new Gt(.045,.05,zt),s.carbon);L.position.copy(et).add(dt).multiplyScalar(.5),L.lookAt(this.body.localToWorld(dt.clone())),this.body.add(L),this.cockpitHide.push(L)}if(i.splitter){const Y=new ot(new Gt(o*1.75,.04,.35),s.carbon);Y.position.set(0,i.bodyBottom+.02,a/2-.12),this.body.add(Y)}const b=new ot(new Gt(o*1.5,.16,.4),s.carbon);b.position.set(0,i.bodyBottom+.1,-a/2+.18),this.body.add(b);for(let Y=-2;Y<=2;Y++){const et=new ot(new Gt(.02,.18,.4),s.carbon);et.position.set(Y*o*.3,i.bodyBottom+.08,-a/2+.1),this.body.add(et)}for(const Y of[-1,1]){const et=new ot(new Gt(.06,.1,i.wheelBase-l*2.2),s.carbon);et.position.set(Y*o*.9,i.bodyBottom+.05,(c+h)/2),this.body.add(et)}const M=u(-a/2+.3);if(i.wing==="gt"||i.wing==="lmp"){const Y=i.wing==="lmp"?o*1.9:o*1.72,et=M+(i.wing==="lmp"?.32:.36),dt=-a/2+(i.wing==="lmp"?.12:.28),zt=new ot(new Gt(Y,.035,.36),s.carbon);zt.position.set(0,et,dt),zt.rotation.x=-.12;const L=zt.clone();L.scale.set(1,.8,.5),L.position.set(0,et+.07,dt-.16),L.rotation.x=-.35,this.body.add(zt,L);for(const Qt of[-1,1]){const Ot=new ot(new Gt(.02,.3,.55),this.paint);Ot.position.set(Qt*Y/2,et+.02,dt-.06),this.body.add(Ot);const It=new ot(new Gt(.03,et-M+.04,.12),s.carbon);It.position.set(Qt*Y*.26,(et+M)/2,dt+.04),this.body.add(It)}}else if(i.wing==="roof"){const Y=new ot(new Gt(m.halfW*1.7,.04,.32),this.paint);Y.position.set(0,m.roof-.03,p-.08),Y.rotation.x=.2,this.body.add(Y)}else if(i.wing==="duck"){const Y=new ot(new Gt(o*1.6,.05,.22),this.paint);Y.position.set(0,M+.04,-a/2+.14),Y.rotation.x=.35,this.body.add(Y)}if(i.fin){const Y=p-(-a/2+.15),et=new ot(new Gt(.02,.32,Y),this.paint);et.position.set(0,u(p-Y/2)+.14,p-Y/2),this.body.add(et)}if(i.scoop){const Y=a/2-a*.3,et=new ot(new Gt(.55,.12,.9),this.paint);et.position.set(0,u(Y)+.03,Y);const dt=new ot(new Gt(.45,.08,.02),s.carbon);dt.position.set(0,u(Y)+.05,Y+.46),this.body.add(et,dt)}for(const Y of[-1,1]){const et=new ot(new Gt(.18,.09,.12),this.paint);et.position.set(Y*(m.halfW+.12),u(x-.2)+.1,x-.25),this.body.add(et),this.cockpitHide.push(et)}for(const Y of[-1,1]){const et=new ot(new un(.05,.05,.2,10),s.chrome);et.rotation.x=Math.PI/2,et.position.set(Y*o*.35,i.bodyBottom+.16,-a/2-.02),this.body.add(et)}this.exhaustLocal=[new D(-o*.35,i.bodyBottom+.16,-a/2-.1),new D(o*.35,i.bodyBottom+.16,-a/2-.1)],this.headMat=new Ft({color:15660287,emissive:16774880,emissiveIntensity:.4,roughness:.1,metalness:.2}),this.tailMat=new Ft({color:4194304,emissive:16718352,emissiveIntensity:.6,roughness:.3});const C=a/2-.22;for(const Y of[-1,1]){const et=new ot(new oi(.15,16,10),this.headMat);et.scale.set(1.3,.45,.8),et.position.set(Y*o*.58,u(C)-.03,C),this.body.add(et);const dt=new ot(new Gt(o*.5,.06,.04),this.tailMat);dt.position.set(Y*o*.48,u(-a/2+.05)-.12,-a/2+.02),this.body.add(dt)}const U=new ot(new Gt(o*1.2,.025,.03),this.tailMat);U.position.set(0,u(-a/2+.05)-.12,-a/2+.015),this.body.add(U);const O=l0(n),V=new Ft({map:O,transparent:!0,roughness:.35,polygonOffset:!0,polygonOffsetFactor:-2}),X=(c+h)/2+.1,W=f.reduce((Y,et)=>Math.abs(et.z-X)<Math.abs(Y.z-X)?et:Y);for(const Y of[-1,1]){const et=new ot(new Me(.5,.5),V);et.position.set(Y*(W.w*.995+.012),(W.yb+W.yt)/2+.03,X),et.rotation.y=Y>0?Math.PI/2:-Math.PI/2,this.body.add(et)}const j=new ot(new Me(.46,.46),V),k=a/2-a*.17;j.position.set(0,u(k)+.012,k),j.rotation.x=-Math.PI/2+.25,this.body.add(j),this.cockpit=new me;const it=new ot(new Gt(m.halfW*1.7,.16,.3),s.interior);it.position.set(0,this.driverPos.y-.28,this.driverPos.z+.62);const q=new ot(new nr(.17,.025,8,24),s.interior);q.position.set(this.driverPos.x,this.driverPos.y-.22,this.driverPos.z+.42),q.rotation.x=-.35;const tt=new ot(new Gt(.16,.08,.03),s.carbon);q.add(tt);const rt=new ot(new Me(.1,.045),new Oe({color:2285690}));rt.position.set(0,0,.02),tt.add(rt),this.steeringWheel=q,this.cockpit.add(it,q),this.cockpit.visible=!1,this.body.add(this.cockpit),this.wheels=[];const ut=[[o*.96-.15,c,!0],[-(o*.96-.15),c,!0],[o*.96-.15,h,!1],[-(o*.96-.15),h,!1]],B=new un(l,l,.3,28,1);B.rotateZ(Math.PI/2);const J=new un(l*.68,l*.68,.305,24,1);J.rotateZ(Math.PI/2);const ht=new un(l*.55,l*.55,.03,20);ht.rotateZ(Math.PI/2);const at=new Gt(.03,l*1.2,.07);this.discMat=new Ft({color:4473924,metalness:.8,roughness:.4,emissive:16726528,emissiveIntensity:0});const wt=t.id==="muscle"||t.id==="lmp"?s.rimDark:s.rim;for(const[Y,et,dt]of ut){const zt=new me;zt.position.set(Y,l,et);const L=new me,Qt=new ot(B,s.tire);Qt.castShadow=!0;const Ot=new ot(J,s.carbon);L.add(Qt,Ot);const It=Math.sign(Y);for(let A=0;A<6;A++){const S=new ot(at,wt);S.rotation.x=A/6*Math.PI,S.position.x=It*.155,L.add(S)}const Tt=new ot(new nr(l*.64,.025,6,24),wt);Tt.rotation.y=Math.PI/2,Tt.position.x=It*.155,L.add(Tt);const te=new ot(ht,this.discMat);te.position.x=It*.02,L.add(te),zt.add(L);const Dt=new ot(new Gt(.06,.14,.18),s.caliper);Dt.position.set(It*.06,l*.32,-.12),zt.add(Dt),this.root.add(zt),this.wheels.push({pivot:zt,spin:L,front:dt,x:Y,z:et})}const xt=new ot(new Me(o*2.5,a*1.15),new Oe({map:s.shadowTex,transparent:!0,depthWrite:!1,opacity:.85,polygonOffset:!0,polygonOffsetFactor:-3}));xt.rotation.x=-Math.PI/2,xt.position.y=.04,xt.renderOrder=1,this.root.add(xt),this.contactShadow=xt,this.beam=new ot(new Me(9,26),new Oe({map:h0(),transparent:!0,depthWrite:!1,blending:Ii,opacity:0,polygonOffset:!0,polygonOffsetFactor:-4})),this.beam.rotation.x=-Math.PI/2,this.beam.rotation.z=Math.PI,this.beam.position.set(0,.06,a/2+13),this.root.add(this.beam),this.wheelSpin=0}setPaint(t){this.paint.color.set(t)}makeGhost(t="#6fd0ff"){const e=new Ft({color:t,emissive:t,emissiveIntensity:.35,roughness:.4,metalness:.1,transparent:!0,opacity:.32,depthWrite:!1});this.root.traverse(n=>{n.isMesh&&(n.material=e,n.castShadow=!1,n.receiveShadow=!1,n.renderOrder=3)}),this.contactShadow.visible=!1,this.beam.visible=!1,this.ghostMat=e,this.tailMat=this.discMat=this.headMat=new Oe,this.nightTail=!1}setNight(t){this.headMat.emissiveIntensity=t?3:.4,this.beam.material.opacity=t?.2:0,this.nightTail=t}deform(t,e){const n=this.bodyMesh.geometry.attributes.position,i=n.array,s=this.basePos,a=.95;let o=!1;for(let l=0;l<n.count;l++){const c=i[l*3],h=i[l*3+1],u=i[l*3+2],f=Math.hypot(c-t.x,(h-t.y)*.8,u-t.z);if(f>a)continue;const d=(1-f/a)**2*e,g=-c,_=-u*.35,m=Math.hypot(g,_)||1;let p=c+g/m*d,x=u+_/m*d*.6,y=h-d*.25;const v=s[l*3],R=s[l*3+1],T=s[l*3+2],E=p-v,P=y-R,b=x-T,M=Math.hypot(E,P,b);if(M>.22){const C=.22/M;p=v+E*C,y=R+P*C,x=T+b*C}i[l*3]=p,i[l*3+1]=y,i[l*3+2]=x,o=!0}o&&(n.needsUpdate=!0,this.bodyMesh.geometry.computeVertexNormals())}repair(){const t=this.bodyMesh.geometry.attributes.position;t.array.set(this.basePos),t.needsUpdate=!0,this.bodyMesh.geometry.computeVertexNormals()}update(t,e){const n=this.root;n.position.set(t.x,t.y,t.z),n.rotation.set(0,0,0),n.rotation.order="YXZ",n.rotation.y=t.heading,n.rotation.x=-t.pitchTrack,this.body.rotation.order="YXZ",this.body.rotation.z=Ye.clamp(-t.latAcc*.0065,-.06,.06),this.body.rotation.x=Ye.clamp(t.longAcc*.0035,-.04,.04),this.body.position.y=t.bump||0;const i=t.vLong/this.spec.wheelR*e;this.wheelSpin+=i,this.rearSpin=(this.rearSpin||0)+(t.rearLocked?0:t.wheelspin?i*1.8:i);for(const a of this.wheels)a.spin.rotation.x=a.front?this.wheelSpin:this.rearSpin,a.front&&(a.pivot.rotation.y=t.steer);this.steeringWheel.rotation.z=-t.steer*4;const s=t.brakeInput>.05&&t.vLong>.5;this.tailMat.emissiveIntensity=s?7:this.nightTail?2:.6,this.discMat.emissiveIntensity=Ye.clamp(t.brakeHeat,0,1)*2.2}dispose(){g0(this.root)}}function g0(r){const t=new Set;r.traverse(e=>{e.geometry&&e.geometry.dispose(),e.material&&(Array.isArray(e.material)?e.material:[e.material]).forEach(n=>t.add(n))});for(const e of t){for(const n of["map","roughnessMap","normalMap","emissiveMap","alphaMap","metalnessMap"]){const i=e[n];i&&i.isTexture&&!wc(i)&&i.dispose()}e.dispose()}}const ns=9.81,_0=[{grip:1,drag:0,rumble:0,name:"asphalt"},{grip:.62,drag:260,rumble:.35,name:"grass"},{grip:.5,drag:900,rumble:.6,name:"gravel"},{grip:.7,drag:160,rumble:.4,name:"dirt"},{grip:.96,drag:0,rumble:1,name:"kerb"},{grip:.9,drag:20,rumble:.05,name:"pavement"}];class x0{constructor(t){this.spec=t,this.x=0,this.y=0,this.z=0,this.heading=0,this.vx=0,this.vz=0,this.yawRate=0,this.steer=0,this.gear=1,this.rpm=t.idleRPM,this.shiftTimer=0,this.longAcc=0,this.latAcc=0,this.vLong=0,this.vLat=0,this.slipR=0,this.slipF=0,this.wheelspin=!1,this.rearLocked=!1,this.skid=0,this.brakeHeat=0,this.brakeInput=0,this.throttle=0,this.damage=0,this.wear=0,this.wearRate=1,this.pitchTrack=0,this.surface=0,this.bump=0,this.trackInfo={},this.trackIdx=-1,this.weatherGrip=1,this.damageEnabled=!0,this.assist=1,this.manualGears=!1,this.draft=0;const e=t.mass*(t.a*t.a+t.b*t.b)*.55;this.inertia=e;const n=t.gears[t.gears.length-1],i=t.maxRPM*.97*2*Math.PI/60;this.finalDrive=i*t.wheelR/(t.topSpeed*n);const s=this.torqueAt(t.maxRPM*.97)*n*this.finalDrive/t.wheelR*.9;this.drag=(s-t.mass*.012*ns)/(t.topSpeed*t.topSpeed),this.rolling=t.mass*.012*ns}torqueAt(t){const e=this.spec,n=Math.min(1,t/e.maxRPM);return e.torque*(.62+.38*Math.sin(Math.PI*Math.min(1,n*.95+.08)))}shiftUp(){this.shiftTimer>0||this.gear<this.spec.gears.length&&(this.gear++,this.shiftTimer=.14,this.onShift&&this.onShift(1))}shiftDown(){if(this.shiftTimer>0)return;const t=this.spec;if(this.gear>1){const e=this.vx*Math.sin(this.heading)+this.vz*Math.cos(this.heading);if(Math.abs(e)/t.wheelR*60/(2*Math.PI)*t.gears[this.gear-2]*this.finalDrive>t.maxRPM*1.02){this.onShiftDenied&&this.onShiftDenied();return}this.gear--,this.shiftTimer=.1,this.onShift&&this.onShift(-1)}else this.gear===1&&this.speed<1.5&&(this.gear=0)}get speed(){return Math.hypot(this.vx,this.vz)}get kmh(){return this.speed*3.6}place(t,e,n,i){this.x=t,this.y=e,this.z=n,this.heading=i,this.vx=this.vz=this.yawRate=this.steer=0,this.gear=1,this.rpm=this.spec.idleRPM,this.trackIdx=-1}step(t,e,n){const i=this.spec,s=i.mass,a=Math.sin(this.heading),o=Math.cos(this.heading);let l=this.vx*a+this.vz*o,c=this.vx*o-this.vz*a;const h=Math.hypot(l,c),u=this.damageEnabled?this.damage:0,f=n.project(this.x,this.z,this.trackIdx,this.trackInfo);this.trackIdx=f.i;const d=n.surfaceAt(f.i,f.lat);this.surface=d;const g=_0[d],_=g.grip*(d===0||d===4?this.weatherGrip:.92+this.weatherGrip*.08),m=i.steerMax/(1+h*h*42e-5),p=e.steer*m,x=(Math.abs(p)<Math.abs(this.steer)?4.5:2.6)*(e.analog?2:1),y=p-this.steer;this.steer+=Math.sign(y)*Math.min(Math.abs(y),x*t);const v=this.steer+(u>30?(u-30)*25e-5:0),R=e.throttle,T=e.brake;this.throttle=R,this.brakeInput=T;const E=Math.abs(l)/i.wheelR*60/(2*Math.PI);if(this.shiftTimer>0&&(this.shiftTimer-=t),this.gear===0)R>.1&&l>-1&&(this.gear=1);else{T>.3&&l<.8&&R<.1&&(this.gear=0);const kt=i.gears[this.gear-1]*this.finalDrive,st=E*kt;this.manualGears||(st>i.maxRPM*.94&&this.gear<i.gears.length&&this.shiftTimer<=0?(this.gear++,this.shiftTimer=.18,this.onShift&&this.onShift(1)):this.gear>1&&this.shiftTimer<=0&&E*i.gears[this.gear-2]*this.finalDrive<i.maxRPM*.7&&st<i.maxRPM*.48&&(this.gear--,this.shiftTimer=.12,this.onShift&&this.onShift(-1)))}const P=this.gear===0?3.2*this.finalDrive:i.gears[this.gear-1]*this.finalDrive;let b=E*P;const M=i.idleRPM+(this.gear<=1?R*3200:0);b=Math.max(b,this.gear<=1?M:i.idleRPM);const C=b>=i.maxRPM;this.rpm+=(Math.min(b,i.maxRPM+150)-this.rpm)*Math.min(1,t*18);const U=i.a+i.b,O=i.downforce*h*h,V=s*ns+O;let X=V*i.b/U-i.cg/U*s*this.longAcc,W=V*i.a/U+i.cg/U*s*this.longAcc;X=Math.max(X,V*.15),W=Math.max(W,V*.15);const j=1-.11*Math.pow(this.wear,1.35),k=i.grip*_*j,it=1-Math.min(.35,u/280);let q=0;if(this.shiftTimer<=0&&!C){const kt=this.torqueAt(this.rpm)*it;this.gear===0?q=T>.1&&l>-11?-T*kt*P/i.wheelR*.9:0:q=R*kt*P/i.wheelR*.9}let tt=0;this.gear!==0&&T>0&&l>.3&&(tt=-T*i.brake*s*13.5),this.gear===0&&R>0&&l<-.3&&(tt=R*i.brake*s*10);const rt=e.handbrake&&Math.abs(l)>.5,ut=k*X,B=k*W;let J=tt*.66,ht=tt*.34;i.fwd?J+=q:ht+=q,rt&&(ht+=-Math.sign(l)*B*.75),this.wheelspin=!1;const at=i.fwd?ut:B;Math.abs(q)>at*.97&&Math.abs(l)<35&&(this.wheelspin=!0);const wt=Math.abs(J)>ut*.98;J=Math.max(-ut,Math.min(ut,J)),ht=Math.max(-B,Math.min(B,ht)),this.rearLocked=rt||Math.abs(tt*.34)>B*.98;const xt=Math.max(Math.abs(l),3.5),Y=l>=0?1:-1,et=Math.atan2(c+this.yawRate*i.a,xt)-v*Y,dt=Math.atan2(c-this.yawRate*i.b,xt),zt=Math.sqrt(Math.max(0,ut*ut-J*J))*(wt?.55:1);let L=Math.sqrt(Math.max(0,B*B-ht*ht));rt&&(L*=.38),this.wheelspin&&!i.fwd&&(L*=.82);const Qt=(kt,st,gt)=>gt<1?0:gt*Math.tanh(-kt*st/gt),Ot=Qt(i.cf,et,zt),It=Qt(i.cr,dt,L);if(this.slipF=et,this.slipR=dt,this.wearRate>0&&h>1){const kt=Math.min(.6,Math.abs(et)+Math.abs(dt));let st=h*16e-6+kt*h*34e-5;(this.wheelspin||wt||this.rearLocked&&!rt)&&(st+=h*6e-5),d!==0&&d!==4&&(st*=.6),this.wear=Math.min(1,this.wear+st*this.wearRate*t)}const Tt=this.drag*h*(1-.32*this.draft);let te=ht+J*Math.cos(v)-Ot*Math.sin(v)-Tt*l-this.rolling*Math.tanh(l)-g.drag*l,Dt=It+Ot*Math.cos(v)+J*Math.sin(v)-Tt*c-g.drag*c*.5;const A=this.heading-Math.atan2(f.tx,f.tz),S=f.slope*Math.cos(A);te-=s*ns*S,this.pitchTrack=Math.atan(S);const z=i.a*(Ot*Math.cos(v)+J*Math.sin(v))-i.b*It,Z=te/s,nt=Dt/s;if(this.longAcc+=(Z-this.longAcc)*Math.min(1,t*8),this.latAcc+=(nt+l*this.yawRate-this.latAcc)*Math.min(1,t*8),this.vx+=(Z*a+nt*o)*t,this.vz+=(Z*o-nt*a)*t,this.yawRate+=z/this.inertia*t,h<4){const kt=1-h/4,st=l*Math.tan(v)/U;this.yawRate+=(st-this.yawRate)*Math.min(1,kt*t*20);const gt=o,Ut=-a,Nt=this.vx*gt+this.vz*Ut;this.vx-=gt*Nt*Math.min(1,kt*t*10),this.vz-=Ut*Nt*Math.min(1,kt*t*10),h<.25&&R<.05&&T<.05&&(this.vx*=.8,this.vz*=.8)}this.gear!==0&&T>0&&R<.05&&this.vx*a+this.vz*o<0&&l>=0&&(this.vx=this.vz=0),this.yawRate*=1-Math.min(1,t*.6);const K=this.assist;if(h>3&&l>0){const st=k*(ns+O/s)/h,gt=Math.max(-st,Math.min(st,l*Math.tan(v)/U)),Ut=(rt?.5:5)*K;if(this.yawRate+=(gt-this.yawRate)*Math.min(1,Ut*t),!rt){const Nt=Math.hypot(this.vx,this.vz);let Mt=Math.atan2(this.vx,this.vz)-this.heading;for(;Mt>Math.PI;)Mt-=2*Math.PI;for(;Mt<-Math.PI;)Mt+=2*Math.PI;if(Math.abs(Mt)<1.6){const Yt=this.heading+Mt*(1-Math.min(1,1.6*K*t));this.vx=Math.sin(Yt)*Nt,this.vz=Math.cos(Yt)*Nt}}}this.heading+=this.yawRate*t,this.x+=this.vx*t,this.z+=this.vz*t,this.y+=(f.y-this.y)*Math.min(1,t*30),this.vLong=l,this.vLat=c;const Et=Math.max(0,Math.abs(dt)-.09)*6,mt=Math.max(0,Math.abs(et)-.11)*5;let vt=Math.min(1,Et+mt*.6);return this.wheelspin&&R>.5&&(vt=Math.max(vt,.75)),(this.rearLocked||wt)&&h>4&&(vt=Math.max(vt,.85)),h<2.5&&(vt*=h/2.5),this.skid+=(vt-this.skid)*Math.min(1,t*12),this.onAsphalt=d===0||d===4||d===5,this.brakeHeat+=T*h>30?t*.8:-t*.25,this.brakeHeat=Math.max(0,Math.min(1.2,this.brakeHeat)),this.rumble=g.rumble*Math.min(1,h/20),this.bump=this.rumble?Math.sin(performance.now()*.06)*.012*this.rumble:0,f}}class Ll{constructor(t,e,n,i){this.e=t,this.track=e;const s=t.car.spec;this.skill=n,this.baseSkill=n,this.profile=e.speedProfile(s.grip*.97,s.downforce,s.mass,0,s.brake*13.5*.72),this.offset=0,this.lineMix=.9+i*37%10/100,this.phase=i*1.7,this.stuck=0,this.reverse=0,this.t=0,this.input={steer:0,throttle:0,brake:0,handbrake:!1,analog:!0},this.pit=null}update(t,e,n,i){var tt;const s=this.e.car,a=this.track,o=a.N;this.t+=t;const l=this.input,c=s.speed,h=s.trackIdx<0?0:s.trackIdx;if(this.reverse>0){this.reverse-=t;let ut=a.heading[h]-s.heading;for(;ut>Math.PI;)ut-=2*Math.PI;for(;ut<-Math.PI;)ut+=2*Math.PI;return l.steer=-Math.sign(ut)*1,l.throttle=0,l.brake=1,l.handbrake=!1,l}const u=a.pit,f=!!(this.pit&&u),d=rt=>u&&rt.car.trackInfo.pit>0&&rt.car.trackInfo.lat>u.D-u.DT-.4,g=f?a.pitRel(s.trackInfo.s)+u.sE:0;f&&g>u.sD0-10&&g<u.sD1||((tt=this.e.pit)==null?void 0:tt.phase)==="service"?this.stuck=0:c<1.5&&this.e.racing?this.stuck+=t:this.stuck=Math.max(0,this.stuck-t*2),this.stuck>1.6&&(this.stuck=0,this.reverse=1.4);let m=0,p=1/0;const x=s.trackInfo.s,y=s.trackInfo.lat;for(const rt of e){if(rt===this.e||u&&d(rt)!==(f&&d(this.e)))continue;let ut=rt.car.trackInfo.s-x;if(ut>a.length/2&&(ut-=a.length),ut<-a.length/2&&(ut+=a.length),ut<-3||ut>30)continue;const B=rt.car.trackInfo.lat-y;if(Math.abs(B)>3.2)continue;const J=c-rt.car.speed;if(ut>0&&(J>-1||ut<9)){const ht=a.hw-1.6,at=ht-rt.car.trackInfo.lat,wt=rt.car.trackInfo.lat+ht,xt=at>wt?1:-1,Y=Math.max(at,wt),et=rt.car.trackInfo.lat+xt*3.3-a.lineOff[h]*this.lineMix;Y>2.6?m=et:p=Math.min(p,rt.car.speed-.5),ut<7&&Y<=2.6&&(p=Math.min(p,rt.car.speed-1.5))}ut>-3&&ut<3&&Math.abs(B)<2.4&&(m+=-Math.sign(B||1)*1.2)}f&&(m=0),this.offset+=(m-this.offset)*Math.min(1,t*1.6);const v=7+c*.42,R=(h+Math.round(v/a.ds))%o,T=a.hw-1.3;let E=a.lineOff[R]*this.lineMix+this.offset;E=Math.max(-T,Math.min(T,E)),f&&(E=a.pitPath(R*a.ds,this.pit.box,this.pit.phase,E));const P=a.px[R]+a.lx[R]*E,b=a.pz[R]+a.lz[R]*E,M=P-s.x,C=b-s.z;let U=Math.atan2(M,C)-s.heading;for(;U>Math.PI;)U-=2*Math.PI;for(;U<-Math.PI;)U+=2*Math.PI;const O=s.spec.a+s.spec.b,V=Math.hypot(M,C);let X=Math.atan(2*O*Math.sin(U)/Math.max(4,V));X+=Math.atan2(s.vLat,Math.max(5,s.vLong))*.35;const W=s.spec.steerMax/(1+c*c*42e-5);l.steer=Math.max(-1,Math.min(1,X/W)),l.analog=!0;const j=(h+2+Math.round(c*.5/a.ds))%o,k=1+Math.sin(this.t*.37+this.phase)*.012;let it=Math.min(this.profile[j],this.profile[(j+3)%o])*this.skill*i*k*(.86+.14*n);if(it*=Math.sqrt(1-.11*Math.pow(s.wear,1.35)),Math.abs(this.offset)>1.5&&(it*=.97),it=Math.min(it,p),Math.abs(U)>1.3&&(it=Math.min(it,12)),f){const rt=a.pitRel(x)+u.sE;if(rt<u.sD1&&(it=Math.min(it,Math.sqrt(u.limit*.94*u.limit*.94+2*5*Math.max(0,u.sD0-2-rt)))),this.pit.phase===0&&rt<u.sX){const B=u.boxes[this.pit.box]-rt-.2;B<-3.2&&rt>u.sE&&(this.pit.phase=1),it=Math.min(it,B>.8?Math.max(2.2,Math.sqrt(2*3.5*B)):0)}}const q=it-c;return q<-.6?(l.throttle=0,l.brake=Math.min(1,.25-q/2.2)):(l.brake=0,l.throttle=Math.max(0,Math.min(1,.35+q/2.5))),s.wheelspin&&(l.throttle*=.55),Math.abs(s.slipR)>.14&&(l.throttle*=.5),l.handbrake=!1,l}}const Xr=["FL","FR","RL","RR","JACK","LOLLI"],Dl=5.2,v0=2.2,za=r=>Math.max(0,Math.min(1,r)),Il=r=>(r=za(r),r*r*(3-2*r)),qr=(r,t,e)=>{let n=t-r;for(;n>Math.PI;)n-=2*Math.PI;for(;n<-Math.PI;)n+=2*Math.PI;return r+n*e};function M0(){const r=[],t=(x,y,v,R)=>{const T=new fe;return T.position.set(y,v,R),x.add(T),T},e=(x,y,v,R,T,E,P,b)=>{const M=t(x,E,P,b);return M.scale.set(v,R,T),r.push({node:M,kind:y}),M},n=new fe,i=t(n,0,.92,0),s=[];for(const x of[1,-1]){const y=t(i,x*.11,0,0);e(y,"suit",.15,.47,.17,0,-.235,0);const v=t(y,0,-.47,0);e(v,"suit",.13,.42,.15,0,-.21,0),e(v,"dark",.15,.08,.27,0,-.42,.05),s.push({thigh:y,knee:v})}const a=t(i,0,.02,0);e(a,"suit",.4,.58,.25,0,.3,0),e(a,"dark",.42,.07,.27,0,.02,0);const o=t(a,0,.62,0);e(o,"helmet",.3,.3,.31,0,.14,.01),e(o,"dark",.24,.09,.05,0,.15,.15);const l=[];for(const x of[1,-1]){const y=t(a,x*.26,.53,0);e(y,"suit",.11,.33,.12,0,-.165,0);const v=t(y,0,-.33,0);e(v,"suit",.1,.3,.11,0,-.15,0),e(v,"dark",.1,.09,.11,0,-.32,0),l.push({sh:y,el:v,hand:t(v,0,-.34,0)})}const c=e(l[0].hand,"dark",.12,.12,.34,0,0,.12),h=t(l[1].hand,0,0,0),u=e(h,"dark",.04,1.5,.04,0,.62,0),f=e(h,"board",.36,.04,.36,0,1.4,0);f.rotation.x=Math.PI/2;const d=t(n,0,0,0),g=e(d,"dark",.34,.16,.9,0,.09,.55),_=e(d,"dark",.06,.06,1,0,.45,.05);_.rotation.x=-.55;const m=t(n,.42,.32,.05),p=e(m,"dark",.24,.64,.64,0,0,0);return{root:n,hips:i,legs:s,torso:a,neck:o,arms:l,gun:c,poleMesh:u,board:f,pole:h,jack:d,jackBody:g,jackBar:_,tyre:m,tyreMesh:p,parts:r}}class y0{constructor(t,e="high"){this.track=t,this.group=new me,this.rig=M0(),this.crews=[],this.quality=e,this.meshes=null,this._m=new Zt,this._zero=new Zt().makeScale(0,0,0),this._c=new Pt}setTeams(t){if(this.clear(),!!this.track.pit){for(const n of t){const i=Xr.map((s,a)=>{const o=this.homeSpot(n.box,a);return{role:s,k:a,x:o.x,z:o.z,y:o.y,yaw:o.yaw,phase:Math.random()*6,moving:0,pose:0,kneel:0,gun:0,lift:0,lolli:0}});this.crews.push({box:n.box,color:new Pt(n.color),entry:n.entry,members:i,state:"idle",svcT:0,outT:0,lift:0})}this.buildMeshes()}}buildMeshes(){const t=this.crews.length*Xr.length,e={suit:0,dark:0,helmet:0,board:0};for(const c of this.rig.parts)e[c.kind]++;const n=new Gt(1,1,1),i=this.track.def.theme==="night",s=(c,h,u)=>{const f=new Jn(h,u,Math.max(1,e[c]*t));return f.frustumCulled=!1,f.castShadow=this.quality!=="low"&&c!=="board",f.instanceMatrix.setUsage(si),this.group.add(f),f};this.meshes={suit:s("suit",n,new Ft({roughness:.75,emissive:i?2236962:0})),dark:s("dark",n,new Ft({color:1776930,roughness:.6,metalness:.2})),helmet:s("helmet",new oi(.5,12,8),new Ft({roughness:.35,metalness:.1})),board:s("board",new un(.5,.5,1,18),new Ft({color:14160667,roughness:.5,emissive:5570560}))};const a=new Pt(15921906);let o=0,l=0;for(const c of this.crews)for(let h=0;h<Xr.length;h++)for(const u of this.rig.parts)u.kind==="suit"?this.meshes.suit.setColorAt(o++,c.color):u.kind==="helmet"&&this.meshes.helmet.setColorAt(l++,this._c.copy(a).lerp(c.color,.25));this.meshes.suit.instanceColor&&(this.meshes.suit.instanceColor.needsUpdate=!0),this.meshes.helmet.instanceColor&&(this.meshes.helmet.instanceColor.needsUpdate=!0)}homeSpot(t,e){const n=this.track.pit,i=n.boxes[t],s=[-2.4,-1.2,0,1.2,2.4,3.4][e],a=this.track.pointAt(i+s,n.Wout-.25-(e===5?.5:0));return{x:a.x,y:a.y,z:a.z,yaw:a.heading-Math.PI/2}}readySpot(t,e){const n=this.track.pit,i=n.boxes[t];let s,a,o;e<4?(s=e%2===0?2.45:-2.45,a=e<2?1.3:-1.3):e===4?(s=0,a=4.6):(s=1.5,a=3.9);const l=this.track.pointAt(i+a,n.boxLat+s);return e<4?o=l.heading+(s>0?-Math.PI/2:Math.PI/2):o=l.heading+Math.PI,{x:l.x,y:l.y,z:l.z,yaw:o}}serviceSpot(t,e,n){const i=t.spec.model,s=Math.sin(t.heading),a=Math.cos(t.heading);let o,l,c;if(n<4){const h=e.wheels.find(u=>(n<2?u.front:!u.front)&&Math.sign(u.x)===(n%2===0?1:-1))||{x:(n%2?-1:1)*i.halfW,z:n<2?t.spec.a:-t.spec.b};o=h.x+Math.sign(h.x)*.72,l=h.z,c=t.heading+(h.x>0?-Math.PI/2:Math.PI/2)}else n===4?(o=0,l=i.len/2+1,c=t.heading+Math.PI):(o=i.halfW+.35,l=i.len/2+1.55,c=t.heading+Math.PI-.35);return{x:t.x+o*a+l*s,y:t.y,z:t.z-o*s+l*a,yaw:c}}clear(){if(this.meshes)for(const t of Object.values(this.meshes))this.group.remove(t),t.dispose(),t.material.dispose();this.meshes=null,this.crews=[]}dispose(){this.clear()}update(t,e){if(!this.meshes||!this.crews.length)return;const n=this.track.pit;for(const i of this.crews){const s=i.entry,a=s.car,o=s.pit,l=n.boxes[i.box],c=e(s),h=o.phase==="service",u=!h&&o.phase!=="out"&&(s.isPlayer&&o.phase==="in"||!s.isPlayer&&s.ai&&s.ai.pit&&s.ai.pit.phase===0)&&c>l-140&&c<l+4,f=i.state;h?i.state="service":f==="service"||f==="release"&&c<l+14&&o.lane?i.state="release":u?i.state="ready":i.state="idle",i.state==="service"&&(f!=="service"&&(i.svcT=0),i.svcT+=t),i.state==="release"&&f!=="release"&&(i.outT=0),i.outT+=t;const d=h?za(o.t/Math.max(.1,o.dur)):1,g=h?Il((o.t-.25)/.35)*(1-Il((o.t-(o.dur-.45))/.3)):0;i.lift+=(g-i.lift)*Math.min(1,t*10),s.vis&&i.lift>.002&&(s.vis.root.position.y+=i.lift*.085);for(const _ of i.members)this.stepMember(i,_,t,a,s.vis,d,o)}this.writeInstances()}stepMember(t,e,n,i,s,a,o){let l;if(t.state==="service")l=this.serviceSpot(i,s,e.k);else if(t.state==="ready")l=this.readySpot(t.box,e.k);else if(t.state==="release"){const x=e._svc||this.serviceSpot(i,s,e.k),y=this.track.pit,v=y.boxes[t.box],R=this.track.pointAt(v+(e.k===4||e.k===5?2.8:e.k<2?-.6:-3.4),y.boxLat+(e.k%2===1&&e.k<4?-2.6:2.4));l=t.outT<1.6?{x:R.x,y:R.y,z:R.z,yaw:x.yaw}:this.homeSpot(t.box,e.k)}else l=this.homeSpot(t.box,e.k);t.state==="service"&&(e._svc=l);const c=l.x-e.x,h=l.z-e.z,u=Math.hypot(c,h),f=t.state==="idle"?v0:Dl,d=Math.min(u,f*n);u>.03?(e.x+=c/u*d,e.z+=h/u*d,e.phase+=d*3.1,e.moving+=(Math.min(1,u/.4)-e.moving)*Math.min(1,n*10),u>.35?e.yaw=qr(e.yaw,Math.atan2(c,h),Math.min(1,n*12)):e.yaw=qr(e.yaw,l.yaw,Math.min(1,n*10))):(e.moving+=(0-e.moving)*Math.min(1,n*10),e.yaw=qr(e.yaw,l.yaw,Math.min(1,n*10))),e.y+=(l.y-e.y)*Math.min(1,n*8),e.run=f===Dl?1:.55;const g=t.state==="service"&&u<.25,_=e.k<4&&g?1:0;e.kneel+=(_-e.kneel)*Math.min(1,n*9);const m=e.k<4&&g&&(o.t<.85||o.t>o.dur-.8);e.gun=m?1:0,e.lift=e.k===4&&g?1:0;const p=t.state==="service"?a>.94?1:0:t.state==="release"&&t.outT<1.2?1:-1;e.lolli+=(p-e.lolli)*Math.min(1,n*7),e.t=(e.t||0)+n}pose(t,e){const n=this.rig;n.root.position.set(t.x,t.y,t.z),n.root.rotation.set(0,t.yaw,0);const i=Math.sin(t.phase)*t.moving*(.45+.35*t.run),s=Math.abs(Math.cos(t.phase))*t.moving*.05*t.run,a=Math.sin(t.t*1.7+t.k)*.02,o=t.kneel;n.hips.position.y=.92-o*.44+s,n.legs[0].thigh.rotation.x=-i*(1-o)-o*1.45,n.legs[0].knee.rotation.x=Math.max(0,i)*.6*(1-o)+o*1.5,n.legs[1].thigh.rotation.x=i*(1-o)+o*.05,n.legs[1].knee.rotation.x=Math.max(0,-i)*.6*(1-o)+o*1.55,n.torso.rotation.x=.08*t.moving*t.run+o*.3+(t.lift?.35:0)+a,n.torso.rotation.z=Math.sin(t.t*.9+t.k*2)*.02*(1-t.moving),n.neck.rotation.x=-o*.25-(t.lift?.3:0);const l=t.k<4,c=t.k===5,h=t.k===4,u=t.gun?Math.sin(t.t*70)*.05:0;let f=i*.8,d=-.25,g=-i*.8,_=-.25;if(l){const p=o;f=f*(1-p)+(-1.35+u)*p,d=d*(1-p)+-.25*p,g=g*(1-p)-1.15*p,_=_*(1-p)-.4*p}h&&t.lift&&(f=-1.1,g=-1.1,d=_=-.5);let m=0;if(c){const p=za((t.lolli+1)/2);g=-.9-p*1.95,_=-.2+p*.15,m=.9*(1-p)+.1}n.arms[0].sh.rotation.set(f,0,-.08),n.arms[0].el.rotation.set(d,0,0),n.arms[1].sh.rotation.set(g,0,.08),n.arms[1].el.rotation.set(_,0,0),n.gun.visible=l,n.pole.rotation.set(m,0,0),n.poleMesh.visible=n.board.visible=c,n.jack.visible=h,n.jackBar.rotation.x=-.55-(t.lift?.5:0),n.tyre.visible=l&&e.state==="idle"&&t.moving<.1,n.root.updateMatrixWorld(!0)}writeInstances(){const t=this.meshes,e={suit:0,dark:0,helmet:0,board:0},n=i=>{for(let s=i;s;s=s.parent)if(s.visible===!1)return!1;return!0};for(const i of this.crews)for(const s of i.members){this.pose(s,i);for(const a of this.rig.parts)t[a.kind].setMatrixAt(e[a.kind]++,n(a.node)?a.node.matrixWorld:this._zero)}for(const i of Object.values(t))i.instanceMatrix.needsUpdate=!0}}const S0=`
varying vec3 vDir;
void main(){
  vDir = normalize(position);
  vec4 p = modelViewMatrix * vec4(position,1.0);
  gl_Position = projectionMatrix * p;
  gl_Position.z = gl_Position.w; // keep at far plane
}`,b0=`
uniform vec3 uZenith; uniform vec3 uHorizon; uniform vec3 uGround;
uniform vec3 uSunDir; uniform vec3 uSunColor; uniform float uSunSize;
uniform float uCloud; uniform vec3 uCloudColor; uniform float uTime; uniform float uStars;
varying vec3 vDir;
float hash(vec2 p){ return fract(sin(dot(p, vec2(127.1,311.7)))*43758.5453); }
float noise(vec2 p){ vec2 i=floor(p), f=fract(p); f=f*f*(3.0-2.0*f);
  return mix(mix(hash(i),hash(i+vec2(1,0)),f.x), mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x), f.y); }
float fbm(vec2 p){ float v=0.0, a=0.5; for(int i=0;i<5;i++){ v+=a*noise(p); p*=2.03; a*=0.5; } return v; }
void main(){
  vec3 d = normalize(vDir);
  float h = d.y;
  vec3 col = mix(uHorizon, uZenith, pow(clamp(h,0.0,1.0), 0.45));
  col = mix(col, uGround, smoothstep(0.0, -0.08, h));
  float sd = max(dot(d, normalize(uSunDir)), 0.0);
  col += uSunColor * (pow(sd, 6.0) * 0.18 + pow(sd, 60.0) * 0.5);
  col += uSunColor * smoothstep(1.0 - uSunSize, 1.0 - uSunSize * 0.6, sd) * 12.0;
  // clouds on a virtual plane
  if (h > 0.0) {
    vec2 uv = d.xz / (h + 0.12) * 1.6 + vec2(uTime * 0.008, uTime * 0.003);
    float n = fbm(uv);
    float cov = smoothstep(1.0 - uCloud * 0.95 - 0.15, 1.05 - uCloud * 0.5, n);
    float lit = 0.75 + 0.35 * pow(sd, 3.0);
    vec3 cc = uCloudColor * lit;
    col = mix(col, cc, cov * smoothstep(0.0, 0.18, h) * 0.95);
  }
  // stars
  if (uStars > 0.0 && h > 0.0) {
    vec2 g = vec2(atan(d.z, d.x) * 120.0, h * 240.0);
    float s = hash(floor(g));
    float tw = 0.6 + 0.4 * sin(uTime * 2.0 + s * 50.0);
    col += vec3(step(0.9965, s)) * uStars * tw * smoothstep(0.05, 0.3, h) * 1.5 * (1.0 - uCloud);
  }
  gl_FragColor = vec4(col, 1.0);
}`,w0={day:{sunEl:48,sunAz:35,sunColor:16773597,sunInt:3.2,hemiSky:12572927,hemiGround:5925701,hemiInt:1.05,zenith:3108817,horizon:12572656,ground:7043674,exposure:.95,fog:12834538,fogD:.0011,stars:0,lamps:0},dusk:{sunEl:5,sunAz:250,sunColor:16752736,sunInt:2.4,hemiSky:16752250,hemiGround:3880272,hemiInt:.7,zenith:1780314,horizon:16747088,ground:2894389,exposure:1,fog:12615792,fogD:.0016,stars:.2,lamps:.55},night:{sunEl:35,sunAz:140,sunColor:10335487,sunInt:.28,hemiSky:2306127,hemiGround:723984,hemiInt:.38,zenith:132107,horizon:857124,ground:329224,exposure:1.15,fog:724760,fogD:.0022,stars:1,lamps:1}},T0={sunny:{cloud:.25,sunMul:1,hemiMul:1,fogMul:1,cloudColor:16777215,grip:1},cloudy:{cloud:.78,sunMul:.38,hemiMul:1.35,fogMul:2,cloudColor:12107462,grip:1,desat:.55},rain:{cloud:1,sunMul:.16,hemiMul:1.15,fogMul:3.6,cloudColor:7172987,grip:.82,desat:.75,wet:!0}};class E0{constructor(t,e){this.renderer=t,this.scene=e,this.pmrem=new Na(t),this.skyMat=new ye({vertexShader:S0,fragmentShader:b0,side:Ne,depthWrite:!1,fog:!1,uniforms:{uZenith:{value:new Pt},uHorizon:{value:new Pt},uGround:{value:new Pt},uSunDir:{value:new D(0,1,0)},uSunColor:{value:new Pt},uSunSize:{value:6e-4},uCloud:{value:.3},uCloudColor:{value:new Pt},uTime:{value:0},uStars:{value:0}}}),this.sky=new ot(new oi(4e3,32,16),this.skyMat),this.sky.renderOrder=-10,this.sky.frustumCulled=!1,e.add(this.sky),this.hemi=new Km(16777215,4473924,1),e.add(this.hemi),this.sun=new t0(16777215,3),this.sun.castShadow=!0,this.sun.shadow.mapSize.set(2048,2048);const n=this.sun.shadow.camera;n.left=-70,n.right=70,n.top=70,n.bottom=-70,n.near=1,n.far=400,this.sun.shadow.bias=-4e-4,this.sun.shadow.normalBias=.04,e.add(this.sun,this.sun.target),this.sunDir=new D,e.fog=new Qa(16777215,.001),this._rain(),this.state={time:"day",weather:"sunny"}}_rain(){const e=new Float32Array(36e3),n=new Float32Array(6e3*2);for(let s=0;s<6e3;s++){const a=Math.random()*80,o=Math.random()*40,l=Math.random()*80;for(let c=0;c<2;c++)e.set([a,o,l],(s*2+c)*3),n[s*2+c]=c}const i=new de;i.setAttribute("position",new xe(e,3)),i.setAttribute("aEnd",new xe(n,1)),this.rainMat=new ye({transparent:!0,depthWrite:!1,fog:!1,uniforms:{uTime:{value:0},uCam:{value:new D},uVel:{value:new D},uOpacity:{value:.32},uColor:{value:new Pt(13161180)}},vertexShader:`
        attribute float aEnd; uniform float uTime; uniform vec3 uCam; uniform vec3 uVel; varying float vA;
        void main(){
          vec3 box = vec3(80.0, 40.0, 80.0);
          vec3 p = position;
          p.y -= uTime * 28.0;
          p = mod(p - uCam, box) + uCam - box * 0.5;
          vec3 fall = vec3(-uVel.x * 0.035, 0.75, -uVel.z * 0.035);
          p += fall * aEnd * 0.9;
          vA = aEnd;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);
        }`,fragmentShader:"uniform float uOpacity; uniform vec3 uColor; varying float vA; void main(){ gl_FragColor = vec4(uColor, uOpacity * (0.35 + vA)); }"}),this.rain=new Wm(i,this.rainMat),this.rain.frustumCulled=!1,this.rain.visible=!1,this.scene.add(this.rain)}apply(t,e,n){this.state={time:t,weather:e};const i=w0[t],s=T0[e],a=Ye.degToRad(i.sunEl),o=Ye.degToRad(i.sunAz);this.sunDir.set(Math.cos(a)*Math.sin(o),Math.sin(a),Math.cos(a)*Math.cos(o)).normalize();const l=this.skyMat.uniforms,c=(f,d)=>{const g=new Pt(f);if(!d)return g;const _=g.r*.3+g.g*.59+g.b*.11;return g.lerp(new Pt(_,_,_),d)},h=t==="night"?0:s.desat||0;l.uZenith.value.copy(c(i.zenith,h)).multiplyScalar(e==="rain"&&t!=="night"?.55:1),l.uHorizon.value.copy(c(i.horizon,h)).multiplyScalar(e==="rain"&&t!=="night"?.7:1),l.uGround.value.copy(c(i.ground,h)),l.uSunDir.value.copy(this.sunDir),l.uSunColor.value.set(i.sunColor).multiplyScalar(t==="night"?.25:s.sunMul),l.uSunSize.value=t==="night"?4e-4:7e-4,l.uCloud.value=s.cloud,l.uCloudColor.value.set(s.cloudColor).multiplyScalar(t==="night"?.06:t==="dusk"?.75:1),t==="dusk"&&l.uCloudColor.value.lerp(new Pt(16751216),.4),l.uStars.value=i.stars,this.sun.color.set(i.sunColor),this.sun.intensity=i.sunInt*s.sunMul,this.hemi.color.set(i.hemiSky),this.hemi.groundColor.set(i.hemiGround),this.hemi.intensity=i.hemiInt*s.hemiMul*(t==="night"&&n&&n.def.theme==="night"?1.5:1);const u=c(i.fog,h);if(e==="rain"&&t!=="night"&&u.multiplyScalar(.72),this.scene.fog.color.copy(u),this.scene.fog.density=i.fogD*s.fogMul,this.renderer.toneMappingExposure=i.exposure,this.rain.visible=!!s.wet,this.rainMat.uniforms.uColor.value.set(t==="night"?8425640:13161180),this.grip=s.grip,this.wet=!!s.wet,this.night=t==="night",this.lampLevel=i.lamps,n){n.setNight(i.lamps,i.lamps>0);const f=n.roadMat;f&&(f.roughness=this.wet?.28:.92,f.color.setScalar(this.wet?.62:1),f.envMapIntensity=this.wet?1.8:.6,f.needsUpdate=!0),n.dynamic.buildingMat&&n.dynamic.buildingMat.forEach(d=>d.emissiveIntensity=t==="night"?1.4:t==="dusk"?.5:0)}this._envMap()}_envMap(){const t=new vc,e=new ot(new oi(100,32,16),this.skyMat);if(t.add(e),this.night||this.state.time==="dusk"){const i=new Oe({color:new Pt(1,.9,.75).multiplyScalar(this.night?6:3)});for(let s=0;s<10;s++){const a=new ot(new Gt(8,1.5,3),i),o=s/10*Math.PI*2;a.position.set(Math.cos(o)*60,25+s%3*6,Math.sin(o)*60),a.lookAt(0,0,0),t.add(a)}}const n=this.pmrem.fromScene(t,.02);this.envRT&&this.envRT.dispose(),this.envRT=n,this.scene.environment=n.texture,this.scene.environmentIntensity=this.night?.6:1,e.geometry.dispose()}setShadows(t,e){this.sun.castShadow=t,t&&this.sun.shadow.mapSize.x!==e&&(this.sun.shadow.mapSize.set(e,e),this.sun.shadow.map&&(this.sun.shadow.map.dispose(),this.sun.shadow.map=null))}update(t,e,n,i){if(this.skyMat.uniforms.uTime.value+=t,this.sky.position.copy(e.position),n){const s=Math.round(n.x/.5)*.5,a=Math.round(n.z/.5)*.5;this.sun.target.position.set(s,n.y,a),this.sun.position.set(s+this.sunDir.x*150,n.y+this.sunDir.y*150,a+this.sunDir.z*150)}this.rain.visible&&(this.rainMat.uniforms.uTime.value+=t,this.rainMat.uniforms.uCam.value.copy(e.position),i&&this.rainMat.uniforms.uVel.value.set(i.x,0,i.z))}}class $r{constructor(t,e,n,i){this.count=e,this.kind=i,this.pos=new Float32Array(e*3),this.vel=new Float32Array(e*3),this.life=new Float32Array(e),this.maxLife=new Float32Array(e).fill(1),this.size0=new Float32Array(e),this.size1=new Float32Array(e),this.alpha0=new Float32Array(e),this.sizeAttr=new Float32Array(e),this.alphaAttr=new Float32Array(e),this.colAttr=new Float32Array(e*3),this.cursor=0;const s=new de;s.setAttribute("position",new xe(this.pos,3).setUsage(si)),s.setAttribute("aSize",new xe(this.sizeAttr,1).setUsage(si)),s.setAttribute("aAlpha",new xe(this.alphaAttr,1).setUsage(si)),s.setAttribute("aColor",new xe(this.colAttr,3).setUsage(si)),this.geo=s,this.mat=new ye({transparent:!0,depthWrite:!1,blending:n?Ii:ri,uniforms:{uScale:{value:600},uLight:{value:1}},vertexShader:`
        attribute float aSize; attribute float aAlpha; attribute vec3 aColor;
        uniform float uScale; varying float vA; varying vec3 vC;
        void main(){
          vec4 mv = modelViewMatrix * vec4(position, 1.0);
          float dist = max(0.5, -mv.z);
          gl_PointSize = aSize * uScale / dist;
          // pull the sprite's depth toward the camera so the ground doesn't slice it
          vec4 mv2 = mv; mv2.z += min(aSize * 0.6, dist - 0.3);
          gl_Position = projectionMatrix * mv2;
          gl_Position.xy = (projectionMatrix * mv).xy / (projectionMatrix * mv).w * gl_Position.w;
          // fade sprites that are about to engulf the camera
          vA = aAlpha * smoothstep(0.8, 4.0, dist); vC = aColor;
        }`,fragmentShader:n?"varying float vA; varying vec3 vC; void main(){ vec2 d = gl_PointCoord - 0.5; float r = length(d); float a = smoothstep(0.5, 0.0, r); gl_FragColor = vec4(vC * a * vA * 2.0, 1.0); }":`varying float vA; varying vec3 vC; uniform float uLight;
          void main(){ vec2 d = gl_PointCoord - 0.5; float r = length(d);
            float n = 0.5 + 0.5 * sin(d.x * 9.0 + d.y * 7.0) * cos(d.y * 11.0 - d.x * 5.0);
            float a = smoothstep(0.5, 0.0, r) * (0.75 + 0.25 * n) * vA;
            if (a < 0.003) discard;
            gl_FragColor = vec4(vC * uLight * (0.9 + 0.15 * n), a); }`}),this.points=new qm(s,this.mat),this.points.frustumCulled=!1,this.points.renderOrder=5,t.add(this.points)}emit(t,e,n,i,s,a,o,l,c,h,u,f,d){const g=this.cursor;this.cursor=(this.cursor+1)%this.count,this.pos[g*3]=t,this.pos[g*3+1]=e,this.pos[g*3+2]=n,this.vel[g*3]=i,this.vel[g*3+1]=s,this.vel[g*3+2]=a,this.life[g]=o,this.maxLife[g]=o,this.size0[g]=l,this.size1[g]=c,this.alpha0[g]=h,this.colAttr[g*3]=u,this.colAttr[g*3+1]=f,this.colAttr[g*3+2]=d}update(t){const e=this.kind==="spark"?-9.8:.6,n=this.kind==="spark"?.6:1.8;let i=!1;for(let s=0;s<this.count;s++){if(this.life[s]<=0){this.sizeAttr[s]=0,this.alphaAttr[s]=0;continue}i=!0,this.life[s]-=t;const a=1-Math.max(0,this.life[s])/this.maxLife[s],o=Math.exp(-n*t);this.vel[s*3]*=o,this.vel[s*3+2]*=o,this.vel[s*3+1]=this.vel[s*3+1]*o+e*t,this.pos[s*3]+=this.vel[s*3]*t,this.pos[s*3+1]+=this.vel[s*3+1]*t,this.pos[s*3+2]+=this.vel[s*3+2]*t,this.sizeAttr[s]=this.size0[s]+(this.size1[s]-this.size0[s])*Math.sqrt(a),this.alphaAttr[s]=this.alpha0[s]*(this.kind==="spark"?1-a:Math.sin(Math.min(1,a*3)*Math.PI*.5)*(1-a))}(i||this._wasAny)&&(this.geo.attributes.position.needsUpdate=!0,this.geo.attributes.aSize.needsUpdate=!0,this.geo.attributes.aAlpha.needsUpdate=!0,this.geo.attributes.aColor.needsUpdate=!0),this._wasAny=i}clear(){this.life.fill(0)}}class A0{constructor(t,e=4e3){this.max=e,this.pos=new Float32Array(e*4*3),this.alpha=new Float32Array(e*4);const n=new Uint32Array(e*6);for(let s=0;s<e;s++){const a=s*4;n.set([a,a+1,a+2,a+1,a+3,a+2],s*6)}const i=new de;i.setAttribute("position",new xe(this.pos,3).setUsage(si)),i.setAttribute("aAlpha",new xe(this.alpha,1).setUsage(si)),i.setIndex(new xe(n,1)),this.geo=i,this.mesh=new ot(i,new ye({transparent:!0,depthWrite:!1,polygonOffset:!0,polygonOffsetFactor:-3,polygonOffsetUnits:-3,vertexShader:"attribute float aAlpha; varying float vA; void main(){ vA = aAlpha; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }",fragmentShader:"varying float vA; void main(){ gl_FragColor = vec4(0.03,0.03,0.035, vA * 0.55); }"})),this.mesh.frustumCulled=!1,this.mesh.renderOrder=2,t.add(this.mesh),this.cursor=0,this.last=new Map,this.dirty=!1}add(t,e,n,i,s,a,o,l){const c=this.last.get(t);if(this.last.set(t,{x:e,y:n,z:i,a:l}),!c)return;const h=e-c.x,u=i-c.z,f=Math.hypot(h,u);if(f<.05||f>3){f>3&&this.last.delete(t);return}const d=-u/f*o*.5,g=h/f*o*.5,_=this.cursor;this.cursor=(this.cursor+1)%this.max;const m=_*12;this.pos.set([c.x+d,c.y,c.z+g,c.x-d,c.y,c.z-g,e+d,n,i+g,e-d,n,i-g],m),this.alpha.set([c.a,c.a,l,l],_*4),this.dirty=!0}lift(t){this.last.delete(t)}update(){this.dirty&&(this.geo.attributes.position.needsUpdate=!0,this.geo.attributes.aAlpha.needsUpdate=!0,this.dirty=!1)}clear(){this.pos.fill(0),this.alpha.fill(0),this.last.clear(),this.dirty=!0,this.update()}}class R0{constructor(t){this.smoke=new $r(t,1600,!1,"smoke"),this.sparks=new $r(t,500,!0,"spark"),this.flames=new $r(t,120,!0,"flame"),this.skids=new A0(t),this.light=1}setLighting(t){this.smoke.mat.uniforms.uLight.value=t}setScale(t,e){const n=t/(2*Math.tan(Ye.degToRad(e)/2));this.smoke.mat.uniforms.uScale.value=n,this.sparks.mat.uniforms.uScale.value=n,this.flames.mat.uniforms.uScale.value=n}tyreSmoke(t,e,n,i,s,a,o){const l=Math.random;this.smoke.emit(t+(l()-.5)*.4,e+.25,n+(l()-.5)*.4,i*.25+(l()-.5)*2.2,.6+l()*1.2,s*.25+(l()-.5)*2.2,1.6+l()*1.4,.7,4.2+l()*2.5,.38*a,o[0],o[1],o[2])}spray(t,e,n,i,s){const a=Math.random;this.smoke.emit(t+(a()-.5)*.6,e+.3,n+(a()-.5)*.6,i*.55+(a()-.5)*3,.8+a(),s*.55+(a()-.5)*3,.7+a()*.5,.8,2.4,.16,.82,.85,.9)}dust(t,e,n,i,s,a){const o=Math.random;this.smoke.emit(t,e+.2,n,i*.3+(o()-.5)*2,.8+o()*1.5,s*.3+(o()-.5)*2,1.2+o(),.8,4,.35,a[0],a[1],a[2])}damageSmoke(t,e,n,i){const s=Math.random,a=i?.12:.35;this.smoke.emit(t+(s()-.5)*.3,e,n+(s()-.5)*.3,s()-.5,2+s()*1.5,s()-.5,1.4+s(),.5,2.8,i?.6:.35,a,a,a)}sparkBurst(t,e,n,i,s,a,o){const l=Math.random;for(let c=0;c<a;c++){const h=o*(.3+l()*.7);this.sparks.emit(t,e,n,i*h+(l()-.5)*h,1+l()*4,s*h+(l()-.5)*h,.3+l()*.5,.1+l()*.12,.04,1,1,.65+l()*.25,.25)}}backfire(t,e,n,i,s){const a=Math.random;for(let o=0;o<6;o++)this.flames.emit(t,e,n,i*(3+a()*4),a()*.5,s*(3+a()*4),.08+a()*.08,.35,.15,1,1,.45+a()*.2,.1)}update(t){this.smoke.update(t),this.sparks.update(t),this.flames.update(t),this.skids.update()}clear(){this.smoke.clear(),this.sparks.clear(),this.flames.clear(),this.skids.clear()}}const Ec={name:"CopyShader",uniforms:{tDiffuse:{value:null},opacity:{value:1}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform float opacity;

		uniform sampler2D tDiffuse;

		varying vec2 vUv;

		void main() {

			vec4 texel = texture2D( tDiffuse, vUv );
			gl_FragColor = opacity * texel;


		}`};class qi{constructor(){this.isPass=!0,this.enabled=!0,this.needsSwap=!0,this.clear=!1,this.renderToScreen=!1}setSize(){}render(){console.error("THREE.Pass: .render() must be implemented in derived pass.")}dispose(){}}const C0=new Za(-1,1,1,-1,0,1);class P0 extends de{constructor(){super(),this.setAttribute("position",new Kt([-1,3,0,-1,-1,0,3,-1,0],3)),this.setAttribute("uv",new Kt([0,2,0,0,2,0],2))}}const L0=new P0;class ro{constructor(t){this._mesh=new ot(L0,t)}dispose(){this._mesh.geometry.dispose()}render(t){t.render(this._mesh,C0)}get material(){return this._mesh.material}set material(t){this._mesh.material=t}}class Ac extends qi{constructor(t,e){super(),this.textureID=e!==void 0?e:"tDiffuse",t instanceof ye?(this.uniforms=t.uniforms,this.material=t):t&&(this.uniforms=us.clone(t.uniforms),this.material=new ye({name:t.name!==void 0?t.name:"unspecified",defines:Object.assign({},t.defines),uniforms:this.uniforms,vertexShader:t.vertexShader,fragmentShader:t.fragmentShader})),this.fsQuad=new ro(this.material)}render(t,e,n){this.uniforms[this.textureID]&&(this.uniforms[this.textureID].value=n.texture),this.fsQuad.material=this.material,this.renderToScreen?(t.setRenderTarget(null),this.fsQuad.render(t)):(t.setRenderTarget(e),this.clear&&t.clear(t.autoClearColor,t.autoClearDepth,t.autoClearStencil),this.fsQuad.render(t))}dispose(){this.material.dispose(),this.fsQuad.dispose()}}class Ul extends qi{constructor(t,e){super(),this.scene=t,this.camera=e,this.clear=!0,this.needsSwap=!1,this.inverse=!1}render(t,e,n){const i=t.getContext(),s=t.state;s.buffers.color.setMask(!1),s.buffers.depth.setMask(!1),s.buffers.color.setLocked(!0),s.buffers.depth.setLocked(!0);let a,o;this.inverse?(a=0,o=1):(a=1,o=0),s.buffers.stencil.setTest(!0),s.buffers.stencil.setOp(i.REPLACE,i.REPLACE,i.REPLACE),s.buffers.stencil.setFunc(i.ALWAYS,a,4294967295),s.buffers.stencil.setClear(o),s.buffers.stencil.setLocked(!0),t.setRenderTarget(n),this.clear&&t.clear(),t.render(this.scene,this.camera),t.setRenderTarget(e),this.clear&&t.clear(),t.render(this.scene,this.camera),s.buffers.color.setLocked(!1),s.buffers.depth.setLocked(!1),s.buffers.color.setMask(!0),s.buffers.depth.setMask(!0),s.buffers.stencil.setLocked(!1),s.buffers.stencil.setFunc(i.EQUAL,1,4294967295),s.buffers.stencil.setOp(i.KEEP,i.KEEP,i.KEEP),s.buffers.stencil.setLocked(!0)}}class D0 extends qi{constructor(){super(),this.needsSwap=!1}render(t){t.state.buffers.stencil.setLocked(!1),t.state.buffers.stencil.setTest(!1)}}class I0{constructor(t,e){if(this.renderer=t,this._pixelRatio=t.getPixelRatio(),e===void 0){const n=t.getSize(new Bt);this._width=n.width,this._height=n.height,e=new sn(this._width*this._pixelRatio,this._height*this._pixelRatio,{type:bn}),e.texture.name="EffectComposer.rt1"}else this._width=e.width,this._height=e.height;this.renderTarget1=e,this.renderTarget2=e.clone(),this.renderTarget2.texture.name="EffectComposer.rt2",this.writeBuffer=this.renderTarget1,this.readBuffer=this.renderTarget2,this.renderToScreen=!0,this.passes=[],this.copyPass=new Ac(Ec),this.copyPass.material.blending=Sn,this.clock=new bc}swapBuffers(){const t=this.readBuffer;this.readBuffer=this.writeBuffer,this.writeBuffer=t}addPass(t){this.passes.push(t),t.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}insertPass(t,e){this.passes.splice(e,0,t),t.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}removePass(t){const e=this.passes.indexOf(t);e!==-1&&this.passes.splice(e,1)}isLastEnabledPass(t){for(let e=t+1;e<this.passes.length;e++)if(this.passes[e].enabled)return!1;return!0}render(t){t===void 0&&(t=this.clock.getDelta());const e=this.renderer.getRenderTarget();let n=!1;for(let i=0,s=this.passes.length;i<s;i++){const a=this.passes[i];if(a.enabled!==!1){if(a.renderToScreen=this.renderToScreen&&this.isLastEnabledPass(i),a.render(this.renderer,this.writeBuffer,this.readBuffer,t,n),a.needsSwap){if(n){const o=this.renderer.getContext(),l=this.renderer.state.buffers.stencil;l.setFunc(o.NOTEQUAL,1,4294967295),this.copyPass.render(this.renderer,this.writeBuffer,this.readBuffer,t),l.setFunc(o.EQUAL,1,4294967295)}this.swapBuffers()}Ul!==void 0&&(a instanceof Ul?n=!0:a instanceof D0&&(n=!1))}}this.renderer.setRenderTarget(e)}reset(t){if(t===void 0){const e=this.renderer.getSize(new Bt);this._pixelRatio=this.renderer.getPixelRatio(),this._width=e.width,this._height=e.height,t=this.renderTarget1.clone(),t.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}this.renderTarget1.dispose(),this.renderTarget2.dispose(),this.renderTarget1=t,this.renderTarget2=t.clone(),this.writeBuffer=this.renderTarget1,this.readBuffer=this.renderTarget2}setSize(t,e){this._width=t,this._height=e;const n=this._width*this._pixelRatio,i=this._height*this._pixelRatio;this.renderTarget1.setSize(n,i),this.renderTarget2.setSize(n,i);for(let s=0;s<this.passes.length;s++)this.passes[s].setSize(n,i)}setPixelRatio(t){this._pixelRatio=t,this.setSize(this._width,this._height)}dispose(){this.renderTarget1.dispose(),this.renderTarget2.dispose(),this.copyPass.dispose()}}class U0 extends qi{constructor(t,e,n=null,i=null,s=null){super(),this.scene=t,this.camera=e,this.overrideMaterial=n,this.clearColor=i,this.clearAlpha=s,this.clear=!0,this.clearDepth=!1,this.needsSwap=!1,this._oldClearColor=new Pt}render(t,e,n){const i=t.autoClear;t.autoClear=!1;let s,a;this.overrideMaterial!==null&&(a=this.scene.overrideMaterial,this.scene.overrideMaterial=this.overrideMaterial),this.clearColor!==null&&(t.getClearColor(this._oldClearColor),t.setClearColor(this.clearColor,t.getClearAlpha())),this.clearAlpha!==null&&(s=t.getClearAlpha(),t.setClearAlpha(this.clearAlpha)),this.clearDepth==!0&&t.clearDepth(),t.setRenderTarget(this.renderToScreen?null:n),this.clear===!0&&t.clear(t.autoClearColor,t.autoClearDepth,t.autoClearStencil),t.render(this.scene,this.camera),this.clearColor!==null&&t.setClearColor(this._oldClearColor),this.clearAlpha!==null&&t.setClearAlpha(s),this.overrideMaterial!==null&&(this.scene.overrideMaterial=a),t.autoClear=i}}const N0={uniforms:{tDiffuse:{value:null},luminosityThreshold:{value:1},smoothWidth:{value:1},defaultColor:{value:new Pt(0)},defaultOpacity:{value:0}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;

			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform sampler2D tDiffuse;
		uniform vec3 defaultColor;
		uniform float defaultOpacity;
		uniform float luminosityThreshold;
		uniform float smoothWidth;

		varying vec2 vUv;

		void main() {

			vec4 texel = texture2D( tDiffuse, vUv );

			float v = luminance( texel.xyz );

			vec4 outputColor = vec4( defaultColor.rgb, defaultOpacity );

			float alpha = smoothstep( luminosityThreshold, luminosityThreshold + smoothWidth, v );

			gl_FragColor = mix( outputColor, texel, alpha );

		}`};class Gi extends qi{constructor(t,e,n,i){super(),this.strength=e!==void 0?e:1,this.radius=n,this.threshold=i,this.resolution=t!==void 0?new Bt(t.x,t.y):new Bt(256,256),this.clearColor=new Pt(0,0,0),this.renderTargetsHorizontal=[],this.renderTargetsVertical=[],this.nMips=5;let s=Math.round(this.resolution.x/2),a=Math.round(this.resolution.y/2);this.renderTargetBright=new sn(s,a,{type:bn}),this.renderTargetBright.texture.name="UnrealBloomPass.bright",this.renderTargetBright.texture.generateMipmaps=!1;for(let u=0;u<this.nMips;u++){const f=new sn(s,a,{type:bn});f.texture.name="UnrealBloomPass.h"+u,f.texture.generateMipmaps=!1,this.renderTargetsHorizontal.push(f);const d=new sn(s,a,{type:bn});d.texture.name="UnrealBloomPass.v"+u,d.texture.generateMipmaps=!1,this.renderTargetsVertical.push(d),s=Math.round(s/2),a=Math.round(a/2)}const o=N0;this.highPassUniforms=us.clone(o.uniforms),this.highPassUniforms.luminosityThreshold.value=i,this.highPassUniforms.smoothWidth.value=.01,this.materialHighPassFilter=new ye({uniforms:this.highPassUniforms,vertexShader:o.vertexShader,fragmentShader:o.fragmentShader}),this.separableBlurMaterials=[];const l=[3,5,7,9,11];s=Math.round(this.resolution.x/2),a=Math.round(this.resolution.y/2);for(let u=0;u<this.nMips;u++)this.separableBlurMaterials.push(this.getSeperableBlurMaterial(l[u])),this.separableBlurMaterials[u].uniforms.invSize.value=new Bt(1/s,1/a),s=Math.round(s/2),a=Math.round(a/2);this.compositeMaterial=this.getCompositeMaterial(this.nMips),this.compositeMaterial.uniforms.blurTexture1.value=this.renderTargetsVertical[0].texture,this.compositeMaterial.uniforms.blurTexture2.value=this.renderTargetsVertical[1].texture,this.compositeMaterial.uniforms.blurTexture3.value=this.renderTargetsVertical[2].texture,this.compositeMaterial.uniforms.blurTexture4.value=this.renderTargetsVertical[3].texture,this.compositeMaterial.uniforms.blurTexture5.value=this.renderTargetsVertical[4].texture,this.compositeMaterial.uniforms.bloomStrength.value=e,this.compositeMaterial.uniforms.bloomRadius.value=.1;const c=[1,.8,.6,.4,.2];this.compositeMaterial.uniforms.bloomFactors.value=c,this.bloomTintColors=[new D(1,1,1),new D(1,1,1),new D(1,1,1),new D(1,1,1),new D(1,1,1)],this.compositeMaterial.uniforms.bloomTintColors.value=this.bloomTintColors;const h=Ec;this.copyUniforms=us.clone(h.uniforms),this.blendMaterial=new ye({uniforms:this.copyUniforms,vertexShader:h.vertexShader,fragmentShader:h.fragmentShader,blending:Ii,depthTest:!1,depthWrite:!1,transparent:!0}),this.enabled=!0,this.needsSwap=!1,this._oldClearColor=new Pt,this.oldClearAlpha=1,this.basic=new Oe,this.fsQuad=new ro(null)}dispose(){for(let t=0;t<this.renderTargetsHorizontal.length;t++)this.renderTargetsHorizontal[t].dispose();for(let t=0;t<this.renderTargetsVertical.length;t++)this.renderTargetsVertical[t].dispose();this.renderTargetBright.dispose();for(let t=0;t<this.separableBlurMaterials.length;t++)this.separableBlurMaterials[t].dispose();this.compositeMaterial.dispose(),this.blendMaterial.dispose(),this.basic.dispose(),this.fsQuad.dispose()}setSize(t,e){let n=Math.round(t/2),i=Math.round(e/2);this.renderTargetBright.setSize(n,i);for(let s=0;s<this.nMips;s++)this.renderTargetsHorizontal[s].setSize(n,i),this.renderTargetsVertical[s].setSize(n,i),this.separableBlurMaterials[s].uniforms.invSize.value=new Bt(1/n,1/i),n=Math.round(n/2),i=Math.round(i/2)}render(t,e,n,i,s){t.getClearColor(this._oldClearColor),this.oldClearAlpha=t.getClearAlpha();const a=t.autoClear;t.autoClear=!1,t.setClearColor(this.clearColor,0),s&&t.state.buffers.stencil.setTest(!1),this.renderToScreen&&(this.fsQuad.material=this.basic,this.basic.map=n.texture,t.setRenderTarget(null),t.clear(),this.fsQuad.render(t)),this.highPassUniforms.tDiffuse.value=n.texture,this.highPassUniforms.luminosityThreshold.value=this.threshold,this.fsQuad.material=this.materialHighPassFilter,t.setRenderTarget(this.renderTargetBright),t.clear(),this.fsQuad.render(t);let o=this.renderTargetBright;for(let l=0;l<this.nMips;l++)this.fsQuad.material=this.separableBlurMaterials[l],this.separableBlurMaterials[l].uniforms.colorTexture.value=o.texture,this.separableBlurMaterials[l].uniforms.direction.value=Gi.BlurDirectionX,t.setRenderTarget(this.renderTargetsHorizontal[l]),t.clear(),this.fsQuad.render(t),this.separableBlurMaterials[l].uniforms.colorTexture.value=this.renderTargetsHorizontal[l].texture,this.separableBlurMaterials[l].uniforms.direction.value=Gi.BlurDirectionY,t.setRenderTarget(this.renderTargetsVertical[l]),t.clear(),this.fsQuad.render(t),o=this.renderTargetsVertical[l];this.fsQuad.material=this.compositeMaterial,this.compositeMaterial.uniforms.bloomStrength.value=this.strength,this.compositeMaterial.uniforms.bloomRadius.value=this.radius,this.compositeMaterial.uniforms.bloomTintColors.value=this.bloomTintColors,t.setRenderTarget(this.renderTargetsHorizontal[0]),t.clear(),this.fsQuad.render(t),this.fsQuad.material=this.blendMaterial,this.copyUniforms.tDiffuse.value=this.renderTargetsHorizontal[0].texture,s&&t.state.buffers.stencil.setTest(!0),this.renderToScreen?(t.setRenderTarget(null),this.fsQuad.render(t)):(t.setRenderTarget(n),this.fsQuad.render(t)),t.setClearColor(this._oldClearColor,this.oldClearAlpha),t.autoClear=a}getSeperableBlurMaterial(t){const e=[];for(let n=0;n<t;n++)e.push(.39894*Math.exp(-.5*n*n/(t*t))/t);return new ye({defines:{KERNEL_RADIUS:t},uniforms:{colorTexture:{value:null},invSize:{value:new Bt(.5,.5)},direction:{value:new Bt(.5,.5)},gaussianCoefficients:{value:e}},vertexShader:`varying vec2 vUv;
				void main() {
					vUv = uv;
					gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
				}`,fragmentShader:`#include <common>
				varying vec2 vUv;
				uniform sampler2D colorTexture;
				uniform vec2 invSize;
				uniform vec2 direction;
				uniform float gaussianCoefficients[KERNEL_RADIUS];

				void main() {
					float weightSum = gaussianCoefficients[0];
					vec3 diffuseSum = texture2D( colorTexture, vUv ).rgb * weightSum;
					for( int i = 1; i < KERNEL_RADIUS; i ++ ) {
						float x = float(i);
						float w = gaussianCoefficients[i];
						vec2 uvOffset = direction * invSize * x;
						vec3 sample1 = texture2D( colorTexture, vUv + uvOffset ).rgb;
						vec3 sample2 = texture2D( colorTexture, vUv - uvOffset ).rgb;
						diffuseSum += (sample1 + sample2) * w;
						weightSum += 2.0 * w;
					}
					gl_FragColor = vec4(diffuseSum/weightSum, 1.0);
				}`})}getCompositeMaterial(t){return new ye({defines:{NUM_MIPS:t},uniforms:{blurTexture1:{value:null},blurTexture2:{value:null},blurTexture3:{value:null},blurTexture4:{value:null},blurTexture5:{value:null},bloomStrength:{value:1},bloomFactors:{value:null},bloomTintColors:{value:null},bloomRadius:{value:0}},vertexShader:`varying vec2 vUv;
				void main() {
					vUv = uv;
					gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
				}`,fragmentShader:`varying vec2 vUv;
				uniform sampler2D blurTexture1;
				uniform sampler2D blurTexture2;
				uniform sampler2D blurTexture3;
				uniform sampler2D blurTexture4;
				uniform sampler2D blurTexture5;
				uniform float bloomStrength;
				uniform float bloomRadius;
				uniform float bloomFactors[NUM_MIPS];
				uniform vec3 bloomTintColors[NUM_MIPS];

				float lerpBloomFactor(const in float factor) {
					float mirrorFactor = 1.2 - factor;
					return mix(factor, mirrorFactor, bloomRadius);
				}

				void main() {
					gl_FragColor = bloomStrength * ( lerpBloomFactor(bloomFactors[0]) * vec4(bloomTintColors[0], 1.0) * texture2D(blurTexture1, vUv) +
						lerpBloomFactor(bloomFactors[1]) * vec4(bloomTintColors[1], 1.0) * texture2D(blurTexture2, vUv) +
						lerpBloomFactor(bloomFactors[2]) * vec4(bloomTintColors[2], 1.0) * texture2D(blurTexture3, vUv) +
						lerpBloomFactor(bloomFactors[3]) * vec4(bloomTintColors[3], 1.0) * texture2D(blurTexture4, vUv) +
						lerpBloomFactor(bloomFactors[4]) * vec4(bloomTintColors[4], 1.0) * texture2D(blurTexture5, vUv) );
				}`})}}Gi.BlurDirectionX=new Bt(1,0);Gi.BlurDirectionY=new Bt(0,1);const F0={name:"OutputShader",uniforms:{tDiffuse:{value:null},toneMappingExposure:{value:1}},vertexShader:`
		precision highp float;

		uniform mat4 modelViewMatrix;
		uniform mat4 projectionMatrix;

		attribute vec3 position;
		attribute vec2 uv;

		varying vec2 vUv;

		void main() {

			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`
	
		precision highp float;

		uniform sampler2D tDiffuse;

		#include <tonemapping_pars_fragment>
		#include <colorspace_pars_fragment>

		varying vec2 vUv;

		void main() {

			gl_FragColor = texture2D( tDiffuse, vUv );

			// tone mapping

			#ifdef LINEAR_TONE_MAPPING

				gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );

			#elif defined( REINHARD_TONE_MAPPING )

				gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );

			#elif defined( CINEON_TONE_MAPPING )

				gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );

			#elif defined( ACES_FILMIC_TONE_MAPPING )

				gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );

			#elif defined( AGX_TONE_MAPPING )

				gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );

			#elif defined( NEUTRAL_TONE_MAPPING )

				gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );

			#endif

			// color space

			#ifdef SRGB_TRANSFER

				gl_FragColor = sRGBTransferOETF( gl_FragColor );

			#endif

		}`};class O0 extends qi{constructor(){super();const t=F0;this.uniforms=us.clone(t.uniforms),this.material=new jm({name:t.name,uniforms:this.uniforms,vertexShader:t.vertexShader,fragmentShader:t.fragmentShader}),this.fsQuad=new ro(this.material),this._outputColorSpace=null,this._toneMapping=null}render(t,e,n){this.uniforms.tDiffuse.value=n.texture,this.uniforms.toneMappingExposure.value=t.toneMappingExposure,(this._outputColorSpace!==t.outputColorSpace||this._toneMapping!==t.toneMapping)&&(this._outputColorSpace=t.outputColorSpace,this._toneMapping=t.toneMapping,this.material.defines={},jt.getTransfer(this._outputColorSpace)===se&&(this.material.defines.SRGB_TRANSFER=""),this._toneMapping===Bl?this.material.defines.LINEAR_TONE_MAPPING="":this._toneMapping===Gl?this.material.defines.REINHARD_TONE_MAPPING="":this._toneMapping===Hl?this.material.defines.CINEON_TONE_MAPPING="":this._toneMapping===Ba?this.material.defines.ACES_FILMIC_TONE_MAPPING="":this._toneMapping===Vl?this.material.defines.AGX_TONE_MAPPING="":this._toneMapping===Wl&&(this.material.defines.NEUTRAL_TONE_MAPPING=""),this.material.needsUpdate=!0),this.renderToScreen===!0?(t.setRenderTarget(null),this.fsQuad.render(t)):(t.setRenderTarget(e),this.clear&&t.clear(t.autoClearColor,t.autoClearDepth,t.autoClearStencil),this.fsQuad.render(t))}dispose(){this.material.dispose(),this.fsQuad.dispose()}}const z0={uniforms:{tDiffuse:{value:null},uStrength:{value:0},uVignette:{value:.35},uRain:{value:0},uTime:{value:0}},vertexShader:"varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }",fragmentShader:`
    uniform sampler2D tDiffuse; uniform float uStrength; uniform float uVignette; uniform float uRain; uniform float uTime;
    varying vec2 vUv;
    float h(vec2 p){ return fract(sin(dot(p, vec2(41.3,289.1)))*43758.5453); }
    void main(){
      vec2 c = vec2(0.5, 0.52);
      vec2 d = vUv - c;
      float r = length(d);
      float k = uStrength * smoothstep(0.12, 0.75, r);
      vec2 uv = vUv;
      // rain droplets on the lens
      if (uRain > 0.0) {
        vec2 g = vUv * vec2(28.0, 16.0);
        vec2 id = floor(g);
        float rnd = h(id);
        float t = fract(uTime * (0.15 + rnd * 0.25) + rnd);
        vec2 f = fract(g) - 0.5;
        float drop = smoothstep(0.22, 0.0, length(f + vec2(0.0, t - 0.5) * 0.6)) * step(0.82, rnd);
        uv += f * drop * 0.02 * uRain;
      }
      vec4 col = vec4(0.0);
      const int N = 10;
      for (int i = 0; i < N; i++) {
        float s = 1.0 - k * 0.09 * (float(i) / float(N - 1));
        col += texture2D(tDiffuse, c + (uv - c) * s);
      }
      col /= float(N);
      float v = smoothstep(0.95, 0.35, r * (1.0 + uVignette * 0.5));
      col.rgb *= mix(1.0, v, uVignette + uStrength * 0.25);
      gl_FragColor = col;
    }`};class k0{constructor(t,e,n){this.renderer=t,this.composer=new I0(t),this.renderPass=new U0(e,n),this.bloom=new Gi(new Bt(256,256),.35,.5,.9),this.blur=new Ac(z0),this.output=new O0,this.composer.addPass(this.renderPass),this.composer.addPass(this.bloom),this.composer.addPass(this.blur),this.composer.addPass(this.output),this.enabled=!0}setCamera(t){this.renderPass.camera=t}setSize(t,e,n){this.composer.setPixelRatio(n),this.composer.setSize(t,e)}configure({bloom:t,motionBlur:e,night:n}){this.bloom.enabled=t,this.bloom.strength=n?.7:.28,this.bloom.threshold=n?.78:.92,this.bloom.radius=n?.55:.4,this.blur.enabled=!0,this.motionBlur=e}render(t,e,n){const i=this.blur.uniforms;i.uStrength.value=this.motionBlur?e:0,i.uRain.value=n,i.uTime.value+=t,this.composer.render(t)}}class B0{constructor(){this.ctx=null,this.master=.8,this.music=.45,this.ready=!1}init(){if(this.ctx){this.ctx.resume();return}const t=window.AudioContext||window.webkitAudioContext;if(!t)return;const e=this.ctx=new t;this.out=e.createGain(),this.out.gain.value=this.master;const n=e.createDynamicsCompressor();n.threshold.value=-14,n.ratio.value=4,this.out.connect(n).connect(e.destination),this.sfx=e.createGain(),this.sfx.connect(this.out),this.musicBus=e.createGain(),this.musicBus.gain.value=this.music*.5,this.musicBus.connect(this.out);const i=e.sampleRate*2,s=e.createBuffer(1,i,e.sampleRate),a=s.getChannelData(0);for(let o=0;o<i;o++)a[o]=Math.random()*2-1;this.noiseBuf=s,this.player=this._engine(1),this.rival=this._engine(.5),this.screech=this._noiseVoice("bandpass",1600,2.5),this.screech2=this._noiseVoice("bandpass",2900,4),this.rumble=this._noiseVoice("lowpass",260,1),this.wind=this._noiseVoice("lowpass",700,.7),this.rainV=this._noiseVoice("highpass",1800,.5),this.ready=!0,this._musicLoop()}_noiseVoice(t,e,n){const i=this.ctx,s=i.createBufferSource();s.buffer=this.noiseBuf,s.loop=!0;const a=i.createBiquadFilter();a.type=t,a.frequency.value=e,a.Q.value=n;const o=i.createGain();return o.gain.value=0,s.connect(a).connect(o).connect(this.sfx),s.start(),{g:o,f:a}}_engine(t){const e=this.ctx,n=e.createOscillator();n.type="sawtooth";const i=e.createOscillator();i.type="square";const s=e.createOscillator();s.type="sawtooth";const a=e.createGain(),o=e.createGain(),l=e.createGain();a.gain.value=.5,o.gain.value=.3,l.gain.value=.12;const c=e.createWaveShaper(),h=new Float32Array(1024);for(let m=0;m<1024;m++){const p=m/1023*2-1;h[m]=Math.tanh(p*2.4)}c.curve=h;const u=e.createBiquadFilter();u.type="lowpass",u.Q.value=2.5;const f=e.createGain();f.gain.value=0,n.connect(a),i.connect(o),s.connect(l),a.connect(c),o.connect(c),l.connect(c),c.connect(u).connect(f).connect(this.sfx);const d=e.createBufferSource();d.buffer=this.noiseBuf,d.loop=!0;const g=e.createBiquadFilter();g.type="bandpass",g.Q.value=1.2;const _=e.createGain();return _.gain.value=0,d.connect(g).connect(_).connect(this.sfx),n.start(),i.start(),s.start(),d.start(),{o1:n,o2:i,o3:s,lp:u,out:f,nf:g,ng:_,level:t}}setVolumes(t,e){this.master=t,this.music=e,this.ctx&&(this.out.gain.setTargetAtTime(t,this.ctx.currentTime,.05),this.musicBus.gain.setTargetAtTime(e*.5,this.ctx.currentTime,.1))}_setEngine(t,e,n,i,s,a){const o=this.ctx.currentTime,l=e/60*(i/2)*s;t.o1.frequency.setTargetAtTime(l,o,.02),t.o2.frequency.setTargetAtTime(l*.5,o,.02),t.o3.frequency.setTargetAtTime(l*2.01,o,.02),t.lp.frequency.setTargetAtTime(350+n*2600+e*.25,o,.04),t.out.gain.setTargetAtTime(a*(.09+n*.09)*t.level,o,.03),t.nf.frequency.setTargetAtTime(l*3,o,.03),t.ng.gain.setTargetAtTime(a*n*.04*t.level,o,.05)}update(t,e,n){if(!this.ready)return;const i=this.ctx.currentTime,s=n.racing||n.menu;t&&this._setEngine(this.player,t.rpm,s?t.throttle:0,t.spec.engine.cyl,t.spec.engine.tone,s?1:.4),e?this._setEngine(this.rival,e.car.rpm,e.car.throttle,e.car.spec.engine.cyl,e.car.spec.engine.tone,e.gain):this.rival.out.gain.setTargetAtTime(0,i,.1);const a=t&&t.onAsphalt?t.skid:0;this.screech.g.gain.setTargetAtTime(a*.16,i,.04),this.screech2.g.gain.setTargetAtTime(a*.07,i,.04),this.rumble.g.gain.setTargetAtTime(t?(t.rumble||0)*.5:0,i,.05);const o=t?Math.min(1,t.speed/85):0;this.wind.g.gain.setTargetAtTime(o*o*.2,i,.1),this.wind.f.frequency.setTargetAtTime(400+o*1400,i,.1),this.rainV.g.gain.setTargetAtTime(n.rain?.05:0,i,.3)}silenceEngines(){if(!this.ready)return;const t=this.ctx.currentTime;for(const e of[this.player,this.rival])e.out.gain.setTargetAtTime(0,t,.05),e.ng.gain.setTargetAtTime(0,t,.05);for(const e of[this.screech,this.screech2,this.rumble,this.wind])e.g.gain.setTargetAtTime(0,t,.05)}impact(t){if(!this.ready)return;const e=this.ctx,n=e.currentTime,i=e.createBufferSource();i.buffer=this.noiseBuf;const s=e.createBiquadFilter();s.type="lowpass",s.frequency.value=500+t*1600;const a=e.createGain(),o=Math.min(1,t)*.9;a.gain.setValueAtTime(o,n),a.gain.exponentialRampToValueAtTime(.001,n+.35),i.connect(s).connect(a).connect(this.sfx),i.start(n,Math.random()),i.stop(n+.4);const l=e.createOscillator();l.type="triangle",l.frequency.value=180+Math.random()*120;const c=e.createGain();c.gain.setValueAtTime(o*.3,n),c.gain.exponentialRampToValueAtTime(.001,n+.25),l.connect(c).connect(this.sfx),l.start(n),l.stop(n+.3)}pop(){if(!this.ready)return;const t=this.ctx,e=t.currentTime,n=t.createBufferSource();n.buffer=this.noiseBuf;const i=t.createBiquadFilter();i.type="bandpass",i.frequency.value=220,i.Q.value=.8;const s=t.createGain();s.gain.setValueAtTime(.45,e),s.gain.exponentialRampToValueAtTime(.001,e+.12),n.connect(i).connect(s).connect(this.sfx),n.start(e,Math.random()),n.stop(e+.15)}beep(t){if(!this.ready)return;const e=this.ctx,n=e.currentTime,i=e.createOscillator();i.type="square",i.frequency.value=t?880:440;const s=e.createGain();s.gain.setValueAtTime(.12,n),s.gain.exponentialRampToValueAtTime(.001,n+(t?.6:.25)),i.connect(s).connect(this.sfx),i.start(n),i.stop(n+.7)}click(){if(!this.ready)return;const t=this.ctx,e=t.currentTime,n=t.createOscillator();n.type="sine",n.frequency.setValueAtTime(1400,e),n.frequency.exponentialRampToValueAtTime(600,e+.05);const i=t.createGain();i.gain.setValueAtTime(.08,e),i.gain.exponentialRampToValueAtTime(.001,e+.07),n.connect(i).connect(this.sfx),n.start(e),n.stop(e+.08)}_musicLoop(){const t=this.ctx,e=124,n=60/e/4,i=[45,45,57,45,45,45,57,45,41,41,53,41,43,43,55,43],s=[[57,60,64],[53,57,60],[55,59,62],[52,55,59]],a=[69,-1,72,-1,76,-1,74,72,69,-1,67,-1,64,-1,67,-1],o=g=>440*Math.pow(2,(g-69)/12);let l=t.currentTime+.2,c=0;const h=(g,_,m,p,x,y)=>{const v=t.createOscillator();v.type=g,v.frequency.value=_;const R=t.createBiquadFilter();R.type="lowpass",R.frequency.value=y;const T=t.createGain();T.gain.setValueAtTime(1e-4,m),T.gain.linearRampToValueAtTime(x,m+.01),T.gain.exponentialRampToValueAtTime(1e-4,m+p),v.connect(R).connect(T).connect(this.musicBus),v.start(m),v.stop(m+p+.05)},u=(g,_)=>{const m=t.createBufferSource();m.buffer=this.noiseBuf;const p=t.createBiquadFilter();p.type="highpass",p.frequency.value=7e3;const x=t.createGain();x.gain.setValueAtTime(_,g),x.gain.exponentialRampToValueAtTime(1e-4,g+.05),m.connect(p).connect(x).connect(this.musicBus),m.start(g,Math.random()),m.stop(g+.06)},f=g=>{const _=t.createOscillator();_.frequency.setValueAtTime(140,g),_.frequency.exponentialRampToValueAtTime(40,g+.15);const m=t.createGain();m.gain.setValueAtTime(.5,g),m.gain.exponentialRampToValueAtTime(.001,g+.25),_.connect(m).connect(this.musicBus),_.start(g),_.stop(g+.3)},d=()=>{if(this.music<=.001){l=t.currentTime+.1;return}for(;l<t.currentTime+.25;){const g=c%16,_=Math.floor(c/16)%4;g%4===0&&f(l),g%2===1&&u(l,.05);const m=i[(g+_*0)%16]+(_===1?-4:_===2?-2:_===3?-5:0);if(h("sawtooth",o(m-12),l,n*.9,.12,600),g===0)for(const p of s[_])h("triangle",o(p),l,n*15,.035,2200);a[g]>0&&Math.floor(c/64)%2===1&&h("square",o(a[g]),l,n*1.6,.03,3e3),l+=n,c++}};this._music=setInterval(d,60)}}class G0{constructor(){this.keys=new Set,this.touch={left:!1,right:!1,gas:!1,brake:!1,hb:!1},this.out={steer:0,throttle:0,brake:0,handbrake:!1,analog:!1},this.handlers={},this.sensitivity=1,this.enabled=!0,window.addEventListener("keydown",t=>{if(t.target&&(t.target.tagName==="INPUT"||t.target.tagName==="SELECT"))return;const e=t.code;["ArrowUp","ArrowDown","ArrowLeft","ArrowRight","Space"].includes(e)&&t.preventDefault(),t.repeat||this._fire(e),this.keys.add(e)}),window.addEventListener("keyup",t=>this.keys.delete(t.code)),window.addEventListener("blur",()=>this.keys.clear())}on(t,e){this.handlers[t]=e}_fire(t){const n={KeyC:"camera",Escape:"pause",KeyP:"pause",KeyR:"reset",KeyM:"mute",Digit1:"cam1",Digit2:"cam2",Digit3:"cam3",Digit4:"cam4",KeyF:"fps",KeyB:"lookback",KeyE:"shiftUp",KeyQ:"shiftDown",ShiftRight:"shiftUp",ControlRight:"shiftDown"}[t];n&&this.handlers[n]&&this.handlers[n]()}bindTouch(t){const e=(n,i)=>{const s=o=>{o.preventDefault(),this.touch[i]=!0,n.classList.add("down")},a=o=>{o.preventDefault(),this.touch[i]=!1,n.classList.remove("down")};n.addEventListener("pointerdown",s),n.addEventListener("pointerup",a),n.addEventListener("pointercancel",a),n.addEventListener("pointerleave",a)};t.querySelectorAll("[data-touch]").forEach(n=>e(n,n.dataset.touch)),t.querySelectorAll("[data-tap]").forEach(n=>{n.addEventListener("pointerdown",s=>{s.preventDefault(),n.classList.add("down");const a=this.handlers[n.dataset.tap];a&&a()});const i=()=>n.classList.remove("down");n.addEventListener("pointerup",i),n.addEventListener("pointerleave",i),n.addEventListener("pointercancel",i)})}lookingBack(){return this.keys.has("KeyB")}update(t){const e=this.keys,n=this.touch;let i=0,s=0,a=0,o=!1,l=!1;(e.has("KeyA")||e.has("ArrowLeft")||n.left)&&(i+=1),(e.has("KeyD")||e.has("ArrowRight")||n.right)&&(i-=1),(e.has("KeyW")||e.has("ArrowUp")||n.gas)&&(s=1),(e.has("KeyS")||e.has("ArrowDown")||n.brake)&&(a=1),(e.has("Space")||n.hb)&&(o=!0);const c=navigator.getGamepads?navigator.getGamepads():[];for(const f of c){if(!f)continue;const d=f.axes[0]||0;Math.abs(d)>.08&&(i=-d*Math.abs(d)**.3,l=!0);const g=f.buttons[7]?f.buttons[7].value:0,_=f.buttons[6]?f.buttons[6].value:0;g>.05&&(s=Math.max(s,g)),_>.05&&(a=Math.max(a,_)),f.buttons[0]&&f.buttons[0].pressed&&(o=!0);const m=!!(f.buttons[5]&&f.buttons[5].pressed),p=!!(f.buttons[4]&&f.buttons[4].pressed);m&&!this._rb&&this.handlers.shiftUp&&this.handlers.shiftUp(),p&&!this._lb&&this.handlers.shiftDown&&this.handlers.shiftDown(),this._rb=m,this._lb=p;break}const h=this.out;this.enabled||(i=0,s=0,a=0,o=!1),h.steer=Math.max(-1,Math.min(1,i*this.sensitivity));const u=(f,d,g,_)=>d>f?Math.min(d,f+g*t):Math.max(d,f-_*t);return h.throttle=l?s:u(h.throttle,s,5,9),h.brake=l?a:u(h.brake,a,7,10),h.handbrake=o,h.analog=l,h}}const is=["chase","cockpit","bumper","cinematic"],H0={chase:"Chase cam",cockpit:"Cockpit",bumper:"Bumper",cinematic:"TV cinematic",orbit:"Showroom"},tn=new D,jn=new D;class V0{constructor(t){this.cam=t,this.mode="chase",this.pos=new D(0,5,-10),this.look=new D,this.cineSpot=null,this.cineTimer=0,this.orbitA=0,this.shake=0,this.baseFov=62}set(t){this.mode=t,this.snap=!0}update(t,e,n,i,s={}){const a=this.cam,o=Math.sin(e.heading),l=Math.cos(e.heading),c=e.speed,h=Math.min(1,c/85);let u=this.baseFov;if(n){const d=this.mode==="cockpit";n.cockpit.visible=d;for(const g of n.cockpitHide)g.visible=!d;n.beam.visible=!(d||this.mode==="bumper")}const f=s.lookBack;if(this.mode==="orbit"){this.orbitA+=t*.18;const d=8.2;tn.set(e.x+Math.sin(this.orbitA)*d,e.y+1.9+Math.sin(this.orbitA*.7)*.4,e.z+Math.cos(this.orbitA)*d),a.position.copy(tn),a.lookAt(e.x,e.y+.6,e.z),a.aspect>1.2&&a.rotateY(.16),u=40}else if(this.mode==="chase"){const d=f?-1:1,g=6.6+h*1.4,_=2.15+h*.2;let m=o,p=l;if(c>6){const v=e.vx/c,R=e.vz/c;m=m*.8+v*.2,p=p*.8+R*.2;const T=Math.hypot(m,p);m/=T,p/=T}tn.set(e.x-m*g*d,e.y+_,e.z-p*g*d);const x=this.snap?1:1-Math.exp(-t*7.5);this.pos.lerp(tn,x);const y=e.y+1;this.pos.y<y&&(this.pos.y=y),a.position.copy(this.pos),jn.set(e.x+o*3*d,e.y+1.05,e.z+l*3*d),this.look.lerp(jn,this.snap?1:1-Math.exp(-t*14)),a.lookAt(this.look),u=this.baseFov+h*14}else if(this.mode==="cockpit"||this.mode==="bumper"){const d=n.root,g=n.body;d.updateMatrixWorld(!0),this.mode==="cockpit"?(tn.copy(n.driverPos),tn.y+=.04):tn.set(0,.55,n.spec.model.len/2+.05),g.localToWorld(tn),a.position.copy(tn),jn.set(this.mode==="cockpit"?n.driverPos.x:0,this.mode==="cockpit"?n.driverPos.y-.05:.5,f?-20:30),g.localToWorld(jn),a.lookAt(jn);const _=(e.rumble||0)*.012+h*.0015;a.position.x+=(Math.random()-.5)*_,a.position.y+=(Math.random()-.5)*_,u=this.mode==="cockpit"?68+h*8:70+h*12}else if(this.mode==="cinematic"){this.cineTimer-=t;const d=e.trackInfo.s||0;let g=null,_=1/0;for(const p of i.camSpots){let x=p.s-d;if(x<-i.length/2&&(x+=i.length),x>i.length/2&&(x-=i.length),x<-50||x>140)continue;const y=Math.abs(x-35);y<_&&(_=y,g=p)}if(this.cineSpot){let p=this.cineSpot.s-d;p<-i.length/2&&(p+=i.length);const x=Math.hypot(this.cineSpot.x-e.x,this.cineSpot.z-e.z);(p<-45||x>150)&&(this.cineSpot=null)}!this.cineSpot&&g&&(this.cineSpot=g);const m=this.cineSpot;if(m){a.position.set(m.x,m.y,m.z),jn.set(e.x+e.vx*.12,e.y+.8,e.z+e.vz*.12),this.look.lerp(jn,this.snap?1:1-Math.exp(-t*10)),a.lookAt(this.look);const p=a.position.distanceTo(this.look);u=Ye.clamp(Ye.radToDeg(2*Math.atan(7/p)),8,55)}else tn.set(e.x-o*9,e.y+4,e.z-l*9),a.position.lerp(tn,1-Math.exp(-t*4)),a.lookAt(e.x,e.y+.8,e.z),u=55}this.shake>.001&&(a.position.x+=(Math.random()-.5)*this.shake,a.position.y+=(Math.random()-.5)*this.shake,this.shake*=Math.exp(-t*8)),Math.abs(a.fov-u)>.01&&(a.fov+=(u-a.fov)*(this.snap||this.mode==="cinematic"?1:1-Math.exp(-t*4)),a.updateProjectionMatrix()),this.snap=!1}}const ce=r=>document.getElementById(r);function ln(r){if(r==null||!isFinite(r))return"--:--.---";const t=Math.floor(r/60),e=r-t*60;return`${t}:${e.toFixed(3).padStart(6,"0")}`}const Nn=135,ss=405;function cs(r,t,e,n){const i=n*Math.PI/180;return[r+e*Math.cos(i),t+e*Math.sin(i)]}function Yr(r,t,e,n,i){const[s,a]=cs(r,t,e,n),[o,l]=cs(r,t,e,i),c=i-n>180?1:0;return`M ${s.toFixed(2)} ${a.toFixed(2)} A ${e} ${e} 0 ${c} 1 ${o.toFixed(2)} ${l.toFixed(2)}`}class W0{constructor(){this.el={root:ce("hud"),pos:ce("h-pos"),posT:ce("h-pos-total"),lap:ce("h-lap"),lapT:ce("h-lap-total"),time:ce("h-time"),laptime:ce("h-laptime"),last:ce("h-last"),best:ce("h-best"),split:ce("h-split"),gear:ce("h-gear"),speed:ce("h-speed"),unit:ce("h-unit"),dmg:ce("h-dmg"),tyre:ce("h-tyre"),tower:ce("tower"),center:ce("center-msg"),sub:ce("sub-msg"),toast:ce("cam-toast"),rpmFill:ce("rpm-fill"),shift:[...ce("shift-lights").children],debug:ce("debug")},this.mm=ce("minimap"),this.mmCtx=this.mm.getContext("2d"),this.units="kmh",this._msgTimer=0,this._subTimer=0,this._toastTimer=0,this._splitTimer=0,this._last={}}setupGauge(t){this.maxRPM=t;const e=110,n=110,i=98;ce("rpm-track").setAttribute("d",Yr(e,n,i,Nn,ss));const s=Nn+(ss-Nn)*.88;ce("rpm-red").setAttribute("d",Yr(e,n,i,s,ss));const a=ce("rpm-ticks");a.innerHTML="";const o=Math.ceil(t/1e3);for(let l=0;l<=o;l++){const c=Nn+(ss-Nn)*(l*1e3/(o*1e3)),[h,u]=cs(e,n,i-9,c),[f,d]=cs(e,n,i-16,c),[g,_]=cs(e,n,i-28,c);a.insertAdjacentHTML("beforeend",`<line x1="${h}" y1="${u}" x2="${f}" y2="${d}"/><text x="${g}" y="${_}">${l}</text>`)}this.gaugeK=o*1e3}setUnits(t){this.units=t,this.el.unit.textContent=t==="mph"?"MPH":"KM/H"}setupMinimap(t){const e=t.bounds,n=22,i=this.mm.width,s=(i-n*2)/e.size;this.mmMap=(l,c)=>[i/2-(l-e.cx)*s,i/2-(c-e.cz)*s];const a=new Path2D;for(let l=0;l<=t.N;l+=2){const c=l%t.N,[h,u]=this.mmMap(t.px[c],t.pz[c]);l===0?a.moveTo(h,u):a.lineTo(h,u)}a.closePath(),this.mmPath=a,this.mmStart=this.mmMap(t.px[0],t.pz[0]),this.mmPit=null;const o=t.pit;if(o){const l=new Path2D;let c=!0;for(let h=o.sE;h<=o.sX;h+=4){const u=h<o.sD0?o.inner+(o.laneLat-o.inner)*(h-o.sE)/(o.sD0-o.sE):h>o.sD1?o.laneLat+(o.inner-o.laneLat)*(h-o.sD1)/(o.sX-o.sD1):o.laneLat,f=t.pointAt(h,u),[d,g]=this.mmMap(f.x,f.z);c?(l.moveTo(d,g),c=!1):l.lineTo(d,g)}this.mmPit=l}}drawMinimap(t,e){const n=this.mmCtx,i=this.mm.width;n.clearRect(0,0,i,i),n.lineJoin="round",n.strokeStyle="rgba(0,0,0,0.6)",n.lineWidth=9,n.stroke(this.mmPath),this.mmPit&&(n.strokeStyle="rgba(255,212,0,0.75)",n.lineWidth=2.5,n.stroke(this.mmPit)),n.strokeStyle="rgba(235,238,242,0.9)",n.lineWidth=4.5,n.stroke(this.mmPath),n.fillStyle="#ffd400",n.fillRect(this.mmStart[0]-4,this.mmStart[1]-4,8,8);for(const s of t){if(s===e)continue;const[a,o]=this.mmMap(s.car.x,s.car.z);n.beginPath(),n.arc(a,o,5,0,Math.PI*2),n.fillStyle=s.color,n.fill(),n.lineWidth=1.5,n.strokeStyle="#000",n.stroke()}if(e){const[s,a]=this.mmMap(e.car.x,e.car.z);n.save(),n.translate(s,a),n.rotate(-e.car.heading),n.beginPath(),n.moveTo(0,-9),n.lineTo(6.5,6),n.lineTo(0,3),n.lineTo(-6.5,6),n.closePath(),n.fillStyle="#e10600",n.fill(),n.lineWidth=2,n.strokeStyle="#fff",n.stroke(),n.restore()}}buildTower(t){this.el.tower.innerHTML=t.map(()=>'<li><span class="p"></span><span class="c"></span><span class="n"></span><span class="g"></span></li>').join(""),this.towerRows=[...this.el.tower.children]}updateTower(t,e,n,i){t.forEach((s,a)=>{const o=this.towerRows[a];if(!o)return;s.code+a+(s===e),o.className=s===e?"me":"",o.children[0].textContent=a+1,o.children[1].style.background=s.color,o.children[2].textContent=s.code;let l;if(s.pit&&(s.pit.lane||s.pit.phase==="service"))l="PIT";else if(a===0)l="Leader";else if(s.finished)l="FIN";else{const c=n-s.prog;l=c>i?`+${Math.floor(c/i)} lap`:`+${(c/Math.max(20,s.car.speed||20)).toFixed(1)}`}o.children[3].textContent=l})}update(t,e){const n=this.el,i=this.units==="mph"?t.speed*2.23694:t.speed*3.6,s=String(Math.round(i));this._last.sp!==s&&(n.speed.textContent=s,this._last.sp=s);const a=t.gear===0?"R":t.speed<.5&&t.throttle<.05?"N":String(t.gear);this._last.g!==a&&(n.gear.textContent=a,this._last.g=a);const o=Math.min(1,t.rpm/this.gaugeK),l=Nn+(ss-Nn)*Math.max(.002,o);n.rpmFill.setAttribute("d",Yr(110,110,98,Nn,l)),n.rpmFill.style.stroke=t.rpm>t.spec.maxRPM*.9?"#ff2a1f":"#eef0f3";const c=(t.rpm/t.spec.maxRPM-.68)/.27,h=Math.round(Math.max(0,Math.min(1,c))*7),u=t.rpm>t.spec.maxRPM*.95&&Math.floor(performance.now()/80)%2;n.shift.forEach((g,_)=>{g.className=u?"b":_<h?_<3?"g":_<5?"r":"b":""});const f=Math.round(t.damage);this._last.dm!==f&&(n.dmg.style.width=`${Math.min(100,f)}%`,n.dmg.style.background=f>60?"#e10600":f>30?"#ffd400":"#22d36f",this._last.dm=f);const d=Math.round((1-(t.wear||0))*100);this._last.ty!==d&&(n.tyre.style.width=`${d}%`,n.tyre.style.background=d<35?"#e10600":d<60?"#ffd400":"#22d36f",this._last.ty=d),e&&(n.pos.textContent=e.pos,n.posT.textContent=`/${e.total}`,n.lap.textContent=e.lap,n.lapT.textContent=`/${e.laps}`,n.time.textContent=ln(e.time),n.laptime.textContent=ln(e.lapTime),n.last.textContent=ln(e.last),n.best.textContent=ln(e.best))}message(t,e="",n=1.2){const i=this.el.center;i.textContent=t,i.className="center-msg show "+e,this._msgTimer=n}sub(t,e=2){this.el.sub.textContent=t,this.el.sub.classList.add("show"),this._subTimer=e}split(t,e){this.el.split.textContent=t,this.el.split.className="split "+e,this._splitTimer=4}toast(t){this.el.toast.textContent=t,this.el.toast.classList.add("show"),this._toastTimer=1.6}tick(t){this._msgTimer>0&&(this._msgTimer-=t)<=0&&this.el.center.classList.remove("show"),this._subTimer>0&&(this._subTimer-=t)<=0&&this.el.sub.classList.remove("show"),this._toastTimer>0&&(this._toastTimer-=t)<=0&&this.el.toast.classList.remove("show"),this._splitTimer>0&&(this._splitTimer-=t)<=0&&(this.el.split.textContent="")}clearMessages(){this._msgTimer=this._subTimer=0,this.el.center.classList.remove("show"),this.el.sub.classList.remove("show"),this.el.split.textContent=""}}function X0(r,t){const e=Math.min(2,window.devicePixelRatio||1),n=r.clientWidth||200,i=r.clientHeight||92;r.width=n*e,r.height=i*e;const s=r.getContext("2d");s.scale(e,e);const a=t.bounds,o=Math.min((n-16)/(a.x1-a.x0),(i-16)/(a.z1-a.z0)),l=(u,f)=>[n/2-(u-a.cx)*o,i/2-(f-a.cz)*o];s.beginPath();for(let u=0;u<=t.N;u+=3){const f=u%t.N,[d,g]=l(t.px[f],t.pz[f]);u===0?s.moveTo(d,g):s.lineTo(d,g)}s.closePath(),s.lineJoin="round",s.strokeStyle="rgba(255,255,255,0.85)",s.lineWidth=3,s.stroke();const[c,h]=l(t.px[0],t.pz[0]);s.fillStyle="#e10600",s.fillRect(c-3.5,h-3.5,7,7)}const pt=r=>document.getElementById(r),Ks=matchMedia("(pointer: coarse)").matches||"ontouchstart"in window,jr=1/120,q0={full:1,sport:.45,off:.1},Nl=20,$0=[25,18,15,12,10,8,6,4],Kr={marina:"rain"},ae={quality:Ks?"medium":"high",shadows:"on",bloom:"on",motionBlur:"on",camera:"chase",units:"kmh",touch:"auto",fps:"off",steer:1,master:.8,music:.4,gearbox:"auto",assist:"full"},Y0={off:0,normal:1,high:3.5},Fl=5,lt={track:"velocita",car:"gt3",paint:Fn[0].paint,laps:3,opponents:5,difficulty:"medium",time:"day",weather:"sunny",damage:"on",grid:"one",ghost:"on",tyres:"normal"};class j0{constructor(){const t=this.renderer=new km({antialias:!Ks,powerPreference:"high-performance"});t.outputColorSpace=Ue,t.toneMapping=Ba,t.shadowMap.enabled=!0,t.shadowMap.type=zl,pt("game").appendChild(t.domElement),this.scene=new vc,this.camera=new He(62,innerWidth/innerHeight,.1,6e3),this.env=new E0(t,this.scene),this.effects=new R0(this.scene),this.post=new k0(t,this.scene,this.camera),this.audio=new B0,this.input=new G0,this.hud=new W0,this.rig=new V0(this.camera),this.entries=[],this.state="loading",this.clock=new bc,this.acc=0,this.raceTime=0,this.events=[],this.manual=!1,this.fpsAvg=60,this.perf={slow:0,fast:0},this.trackCache={},this.records={},this.paceCache={},this.ghost=null,this.champ=null,this.champSetup=!1,this.headlight=new Jm(16773852,0,140,.5,.55,1.4),this.headlight.position.set(0,.8,2.2),this.headlight.target.position.set(0,-.6,30),addEventListener("resize",()=>this.resize()),this.bindInput()}async boot(){const t=pt("load-fill"),e=pt("load-text"),n=(i,s)=>(t.style.width=`${i}%`,e.textContent=s,new Promise(a=>setTimeout(a,16)));await document.fonts.ready.catch(()=>{}),await n(10,"Surveying circuits…");for(let i=0;i<_e.length;i++)this.trackCache[_e[i].id]=new Rl(_e[i]),await n(10+(i+1)/_e.length*50,`Surveying ${_e[i].name}…`);this.buildMenus(),this.applySettings(),await n(70,"Building circuit…"),this.loadTrack(lt.track),await n(88,"Preparing grid…"),this.buildGrid(),this.toMenu("home"),await n(100,"Ready"),this.resize(),requestAnimationFrame(()=>this.loop()),setTimeout(()=>pt("loading").classList.add("fade"),150),setTimeout(()=>pt("loading").classList.add("hidden"),650)}resize(){const t=innerWidth,e=innerHeight;this.camera.aspect=t/e,this.camera.updateProjectionMatrix(),this.renderer.setSize(t,e),this.renderer.setPixelRatio(this.pr||1),this.post.setSize(t,e,this.pr||1),this.effects.setScale(e*(this.pr||1),this.camera.fov)}loadTrack(t){if(this.crew&&(this.scene.remove(this.crew.group),this.crew.dispose(),this.crew=null),this.track){this.scene.remove(this.track.group),this.track.dispose();const n=this.track.def;this.trackCache[n.id]=new Rl(n)}const e=this.track=this.trackCache[t];e.build(ae.quality),this.scene.add(e.group),e.pit&&(this.crew=new y0(e,ae.quality),this.scene.add(this.crew.group)),this.env.apply(lt.time,lt.weather,e),this.hud.setupMinimap(e),this.effects.clear(),this.effects.setLighting(this.env.night?.6:lt.time==="dusk"?.8:1),this.configurePost()}clearGrid(){for(const t of this.entries)this.scene.remove(t.vis.root),t.vis.dispose();this.entries=[]}buildGrid(){this.clearGrid();const t=this.track,e=Fn.find(h=>h.id===lt.car),n=lt.opponents+1,i=n-1,s=wl.map(h=>h.hex).filter(h=>h.toLowerCase()!==lt.paint.toLowerCase()),a=Gs[lt.difficulty].skill;let o=0;const l=Fn.indexOf(e),c=h=>lt.grid==="mixed"?Fn[(l+1+h)%Fn.length]:e;for(let h=0;h<n;h++){const u=h===i,f=u?lt.paint:s[o%s.length],d=u?e:c(o),g=new x0(d),_=new Pl(d,f,u?7:[11,3,44,16,63,1,22,81][o]),m=u?{name:"You",code:"YOU"}:e0[o],p={car:g,vis:_,isPlayer:u,color:f,name:m.name,code:m.code,prog:0,lastS:0,lapsDone:0,lapStart:0,lapTimes:[],best:null,finished:!1,finishTime:null,sector:0,sectorStart:0,racing:!1,wrong:0,pit:{phase:"none",t:0,dur:0,d0:0,box:0,lane:!1,stops:0,warned:-1,w0:0,tyres:!1,trap:!1},divSide:0,penalty:0};g.damageEnabled=lt.damage==="on",g.wearRate=Y0[lt.tyres]??1,g.weatherGrip=this.env.grip;const x=t.gridSlots[h];g.place(x.x,x.y,x.z,x.heading),t.project(g.x,g.z,-1,g.trackInfo),g.trackIdx=g.trackInfo.i;const y=g.trackInfo.s;if(p.prog=y>t.length/2?y-t.length:y,p.lastS=y,!u){let v=a*(1-o%4*.008)*(.985+o*53%7/250);d!==e&&(v*=Ye.clamp(this.pace(d)/this.pace(e),.8,1)),p.ai=new Ll(p,t,v,o+1),o++}_.setNight(this.env.night||lt.time==="dusk"),_.update(g,0),this.scene.add(_.root),this.entries.push(p),u&&(this.player=p)}this.player.car.onShift=h=>{if(h>0&&this.state==="racing"){const u=this.player.car,f=this.player.vis;f.root.updateMatrixWorld(!0);const d=f.exhaustLocal[0].clone();f.body.localToWorld(d),this.effects.backfire(d.x,d.y,d.z,-Math.sin(u.heading),-Math.cos(u.heading)),this.audio.pop()}},this.champ&&this.champ.round>0&&this.reverseGrid(),this.applyDriverAids(),this.buildGhost(e),this.player.vis.root.add(this.headlight,this.headlight.target),this.headlight.intensity=this.env.night?70:lt.time==="dusk"?25:0,this.hud.setupGauge(e.maxRPM),this.hud.buildTower(this.entries),this.assignPitBoxes(),this.finishOrder=[],this.track.setStartLights(0)}pace(t){const e=`${this.track.def.id}:${t.id}`;if(this.paceCache[e])return this.paceCache[e];const n=this.track,i=n.N,s=n.speedProfile(t.grip*.97,t.downforce,t.mass,0,t.brake*13.5*.72),a=t.torque*(t.maxRPM*.8*2*Math.PI/60)*.75,o=new Float32Array(i);for(let c=0;c<i;c++)o[c]=Math.min(s[c],t.topSpeed*.97);for(let c=0;c<2;c++)for(let h=0;h<i;h++){const u=(h+1)%i,f=Math.max(o[h],5),d=Math.min(t.grip*9.81*.8,a/(t.mass*f));o[u]=Math.min(o[u],Math.sqrt(f*f+2*d*n.ds))}let l=0;for(let c=0;c<i;c++)l+=n.ds/Math.max(o[c],3);return this.paceCache[e]=l}applyDriverAids(){if(!this.player)return;const t=this.player.car;t.assist=q0[ae.assist]??1,t.manualGears=ae.gearbox==="manual",document.body.classList.toggle("manual-gears",t.manualGears);const e=pt("h-gearmode");e.textContent=t.manualGears?Ks?"MANUAL":"MANUAL · Q/E":"AUTO",e.classList.toggle("manual",t.manualGears)}recKey(){return`${lt.track}:${lt.car}`}buildGhost(t){if(this.ghost&&(this.scene.remove(this.ghost.root),this.ghost.dispose(),this.ghost=null),lt.ghost!=="on")return;const e=this.ghost=new Pl(t,"#6fd0ff",0);e.makeGhost(),e.root.visible=!1,this.scene.add(e.root)}recordGhost(){const t=this.player;if(!t.racing||t.finished)return;const e=this.rec||(this.rec={frames:[],next:0}),n=this.raceTime-t.lapStart;if(n<e.next)return;e.next=n+1/Nl;const i=t.car;e.frames.push(n,i.x,i.y,i.z,i.heading,t.prog-t.lapsDone*this.track.length)}lapDone(t){const e=this.rec;if(this.rec={frames:[],next:0},!e||e.frames.length<12)return!1;const n=this.recKey(),i=this.records[n];if(i&&i.time<=t)return!1;const s=new Float32Array(e.frames),a=s.length/6,o=new Float32Array(a),l=new Float32Array(a);let c=-1/0;for(let h=0;h<a;h++)c=Math.max(c,s[h*6+5]),o[h]=c,l[h]=s[h*6];return this.records[n]={time:t,frames:s,dist:o,ftime:l,laps:lt.laps},!0}updateGhost(){const t=this.ghost,e=this.player,n=this.records[this.recKey()],i=pt("ghost-row");if(!t||!n||!e||this.state!=="racing"||e.finished||!e.racing){t&&(t.root.visible=!1),i.classList.toggle("on",!!(t&&n&&this.state!=="menu"));return}i.classList.add("on");const s=this.raceTime-e.lapStart,a=n.frames,o=a.length/6,l=Math.min(o-1.001,s*Nl);if(l<0||s>a[(o-1)*6]+.5)t.root.visible=!1;else{const m=Math.floor(l),p=l-m,x=m*6,y=Math.min(o-1,m+1)*6,v=P=>a[x+P]+(a[y+P]-a[x+P])*p;let R=a[y+4]-a[x+4];for(;R>Math.PI;)R-=2*Math.PI;for(;R<-Math.PI;)R+=2*Math.PI;const T=t.root;T.position.set(v(1),v(2),v(3)),T.rotation.set(0,a[x+4]+R*p,0);const E=Math.min(Math.hypot(v(1)-e.car.x,v(3)-e.car.z),Math.hypot(v(1)-this.camera.position.x,v(3)-this.camera.position.z)+2);t.ghostMat.opacity=.32*Ye.clamp((E-3)/6,0,1),T.visible=t.ghostMat.opacity>.01;for(const P of t.wheels)P.spin.rotation.x+=.4}if(this._dT=(this._dT||0)-1,this._dT>0)return;this._dT=6;const c=e.prog-e.lapsDone*this.track.length,h=n.dist,u=pt("h-delta");if(c<=h[0]||c>=h[h.length-1]){u.textContent=ln(n.time),u.className="";return}let f=0,d=h.length-1;for(;d-f>1;){const m=f+d>>1;h[m]<c?f=m:d=m}const g=n.ftime[f]+(n.ftime[d]-n.ftime[f])*(c-h[f])/Math.max(.001,h[d]-h[f]),_=s-g;u.textContent=`${_<0?"−":"+"}${Math.abs(_).toFixed(2)}`,u.className=_<0?"ahead":"behind"}drafting(t){const e=this.entries,n=this.track.length;for(const i of e){const s=i.car,a=s.trackInfo;let o=0;if(s.speed>22)for(const l of e){if(l===i)continue;let c=l.car.trackInfo.s-a.s;if(c>n/2&&(c-=n),c<-n/2&&(c+=n),c<3.5||c>32)continue;const h=Math.abs(l.car.trackInfo.lat-a.lat);h>2.2||(o=Math.max(o,(1-c/32)*(1-h/2.2)*Math.min(1,l.car.speed/30)))}s.draft+=(Math.min(1,o*1.4)-s.draft)*Math.min(1,t*3)}}champTable(){const t=this.champ;return Object.keys(t.points).map(e=>({code:e,pts:t.points[e],name:t.names[e],color:t.colors[e],wins:t.wins[e]||0,best:t.bestPos[e]||99})).sort((e,n)=>n.pts-e.pts||n.wins-e.wins||e.best-n.best)}reverseGrid(){const t=this.track,e=this.champTable(),n=s=>{const a=e.findIndex(o=>o.code===s.code);return a<0?0:a};[...this.entries].sort((s,a)=>n(a)-n(s)).forEach((s,a)=>{const o=s.car,l=t.gridSlots[a];o.place(l.x,l.y,l.z,l.heading),t.project(o.x,o.z,-1,o.trackInfo),o.trackIdx=o.trackInfo.i;const c=o.trackInfo.s;s.prog=c>t.length/2?c-t.length:c,s.lastS=c,s.vis.update(o,0)})}openChampSetup(){this.champSetup=!0,document.body.classList.add("champ-setup"),document.querySelectorAll(".tab").forEach(t=>t.classList.toggle("active",t.dataset.tab==="track")),document.querySelectorAll(".pane").forEach(t=>t.classList.toggle("active",t.dataset.pane==="track")),pt("btn-start").textContent="Start championship ›",this.renderCalendar(pt("champ-cal"),null),this.showScreen("setup"),this.updateSummary()}openQuickSetup(){this.champSetup=!1,document.body.classList.remove("champ-setup"),pt("btn-start").textContent="Start race ›",this.showScreen("setup"),this.updateSummary()}showScreen(t){document.querySelectorAll(".screen").forEach(e=>e.classList.toggle("active",e.id===`scr-${t}`))}renderCalendar(t,e){t.innerHTML=_e.map((n,i)=>{const s=e&&e.results[i],a=s?"done":e&&i===e.round?"next":"",o=Kr[n.id]||n.weather,l=s?`P${s.pos} · ${s.pts} pts`:`${n.type} · ${n.time==="night"?"Night":n.time==="dusk"?"Dusk":"Day"}${o==="rain"?" · Rain":""}`;return`<li class="${a}"><span class="r">R${i+1}</span><b>${n.name}</b><span class="m">${l}</span></li>`}).join("")}startChampionship(){this.champSetup=!1,document.body.classList.remove("champ-setup"),this.champ={round:0,points:{},names:{},colors:{},wins:{},bestPos:{},results:[],cfg:{car:lt.car,paint:lt.paint,laps:lt.laps,opponents:lt.opponents,difficulty:lt.difficulty,grid:lt.grid,damage:lt.damage}},this.startChampRound()}startChampRound(){const t=this.champ;Object.assign(lt,t.cfg);const e=_e[t.round];lt.track=e.id,lt.time=e.time,lt.weather=e.weather,Kr[e.id]&&(lt.weather=Kr[e.id]),this.loadTrack(lt.track),this.env.apply(lt.time,lt.weather,this.track),this.syncRaceUI(),this.inChamp=!0,this.startRace()}scoreChampRound(){const t=this.champ;if(!t||t.results[t.round])return;const e=this.order(),n=this.entries.reduce((s,a)=>a.best!=null&&(s==null||a.best<s.best)?a:s,null),i={track:this.track.def.id,rows:[]};e.forEach((s,a)=>{let o=$0[a]||0;s===n&&a<10&&(o+=1),t.points[s.code]=(t.points[s.code]||0)+o,t.names[s.code]=s.name,t.colors[s.code]=s.color,a===0&&(t.wins[s.code]=(t.wins[s.code]||0)+1),t.bestPos[s.code]=Math.min(t.bestPos[s.code]||99,a+1),i.rows.push({code:s.code,pts:o,fast:s===n}),s.isPlayer&&(i.pos=a+1,i.pts=o)}),t.results[t.round]=i}fillChampResults(){const t=this.champ,e=t.results[t.round],n=this.champTable();pt("res-standings").innerHTML=n.map((a,o)=>{const l=e?e.rows.find(c=>c.code===a.code):null;return`<tr class="${a.code==="YOU"?"me":""}"><td>${o+1}</td><td><span class="sw" style="background:${a.color}"></span>${a.name}</td><td class="num">${a.pts}${l&&l.pts?`<span class="gain">+${l.pts}</span>`:""}</td></tr>`}).join("");const i=t.round>=_e.length-1,s=n.findIndex(a=>a.code==="YOU")+1;pt("res-again").textContent=i?"Final standings ›":`Next: ${_e[t.round+1].name} ›`,pt("res-menu").textContent="Menu",pt("res-track").textContent=`Round ${t.round+1} of ${_e.length} · ${this.track.def.name} · Championship P${s}`}openHub(){const t=this.champ;if(!t)return this.toMenu("home");const e=t.results.filter(Boolean).length,n=e>=_e.length,i=this.champTable(),s=i.findIndex(o=>o.code==="YOU")+1;this.toMenu("champhub"),pt("hub-kicker").textContent=`Apex Grand Prix Series · ${Fn.find(o=>o.id===t.cfg.car).name}`,pt("hub-title").textContent=n?s===1?"World Champion":`Championship finished P${s}`:`Round ${t.round+1} of ${_e.length} · ${_e[t.round].name}`,pt("hub-place").textContent=`P${s}`,pt("hub-place").classList.toggle("champion",n&&s===1);const a=i[0];pt("hub-standings").innerHTML=i.map((o,l)=>`<tr class="${o.code==="YOU"?"me":""}"><td>${l+1}</td><td><span class="sw" style="background:${o.color}"></span>${o.name}</td><td class="num wins">${o.wins?`${o.wins} ${o.wins>1?"wins":"win"}`:""}</td><td class="num"><b>${o.pts}</b></td><td class="num muted">${l?`−${a.pts-o.pts}`:""}</td></tr>`).join("")||'<tr><td colspan="5" class="muted">No points yet</td></tr>',this.renderCalendar(pt("hub-cal"),t),pt("hub-go").textContent=n?"New championship":e?`Start round ${t.round+1} ›`:"Start round 1 ›",pt("hub-abandon").classList.toggle("hidden",n),n&&s===1&&!t.celebrated&&(t.celebrated=!0,this.audio.beep(!0))}startRace(){this.audio.init(),this.loadTrackIfNeeded(),this.buildGrid(),this.effects.clear(),this.state="countdown",this.countT=0,this.lightsOutAt=5+.4+Math.random()*.9,this.lightsShown=0,this.raceTime=0,this.rig.set(ae.camera),this.camIndex=is.indexOf(ae.camera),pt("menu").classList.add("hidden"),pt("results").classList.add("hidden"),pt("pause").classList.add("hidden"),pt("hud").classList.remove("hidden"),this.showTouch(!0),this.hud.clearMessages(),this.inChamp=!!(this.inChamp&&this.champ&&this.champ.results[this.champ.round]==null),document.body.classList.toggle("champ-on",this.inChamp),this.hud.sub(`${this.inChamp?`Round ${this.champ.round+1}/${_e.length} · `:""}${this.track.def.name} · ${lt.laps} ${lt.laps>1?"laps":"lap"}`,3.5),this.input.enabled=!0,this.resultsShown=!1,this.rec={frames:[],next:0}}loadTrackIfNeeded(){this.track.def.id!==lt.track&&this.loadTrack(lt.track)}toMenu(t="home"){this.state="menu",this.audio.silenceEngines(),pt("menu").classList.remove("hidden"),pt("hud").classList.add("hidden"),pt("pause").classList.add("hidden"),pt("results").classList.add("hidden"),this.showTouch(!1),document.querySelectorAll(".screen").forEach(e=>e.classList.toggle("active",e.id===`scr-${t}`)),this.track&&this.track.def.id!==lt.track&&this.loadTrack(lt.track),(!this.player||this.dirtyGrid)&&(this.buildGrid(),this.dirtyGrid=!1),this.rig.set("orbit"),this.syncRaceUI()}pause(t){t&&(this.state==="racing"||this.state==="countdown"||this.state==="finished")?(this.prevState=this.state,this.state="paused",pt("pause").classList.remove("hidden"),this.audio.silenceEngines()):!t&&this.state==="paused"&&(this.state=this.prevState,pt("pause").classList.add("hidden"),document.querySelectorAll(".modal").forEach(e=>e.id!=="results"&&e.classList.add("hidden")),this.clock.getDelta())}showTouch(t){const e=ae.touch==="on"||ae.touch==="auto"&&Ks;pt("touch").classList.toggle("hidden",!(t&&e)),document.body.classList.toggle("touch-on",t&&e)}finish(t){if(t.finished=!0,t.finishTime=this.raceTime+t.penalty,this.finishOrder.push(t),this.finishOrder.sort((e,n)=>e.finishTime-n.finishTime),t.isPlayer){const e=this.finishOrder.indexOf(t)+1;this.state="finished",this.hud.message(e===1?"Victory":`P${e}`,e===1?"go":"",3),this.hud.sub("Chequered flag",3),t.ai=new Ll(t,this.track,.82,99),setTimeout(()=>{this.state==="finished"&&this.rig.set("cinematic")},1200),setTimeout(()=>this.showResults(),3200)}}order(){const t=this.finishOrder;return[...this.entries].sort((e,n)=>e.finished&&n.finished?t.indexOf(e)-t.indexOf(n):e.finished?-1:n.finished?1:n.prog-e.prog)}showResults(){this.state!=="finished"&&this.state!=="paused"||(this.resultsShown=!0,this.inChamp&&this.scoreChampRound(),pt("res-champ").classList.toggle("hidden",!this.inChamp),pt("results").classList.remove("hidden"),this.fillResults())}fillResults(){const t=this.inChamp&&this.champ.results[this.champ.round],e=t?t.rows.map(a=>this.entries.find(o=>o.code===a.code)):this.order(),n=e.indexOf(this.player)+1;pt("res-place").textContent=`P${n}`,pt("res-title").textContent=n===1?"Victory":n<=3?"Podium finish":"Race result",pt("res-track").textContent=`${this.track.def.name} · ${lt.laps} ${lt.laps>1?"laps":"lap"} · ${Gs[lt.difficulty].label}`;const i=Math.min(...this.entries.map(a=>a.best??1/0)),s=e[0];pt("res-body").innerHTML=e.map((a,o)=>{let l;a.finished?l=o===0?ln(a.finishTime):`+${(a.finishTime-s.finishTime).toFixed(3)}`:l=`<span class="muted">Lap ${Math.min(lt.laps,a.lapsDone+1)}/${lt.laps}</span>`;const c=`${a.pit.stops||"—"}${a.penalty?` <span class="pen">+${a.penalty}s</span>`:""}`,h=a.best!=null?`<span class="${a.best===i?"best":""}">${ln(a.best)}</span>`:"—",u=this.inChamp&&this.champ.results[this.champ.round],f=u&&u.rows.find(g=>g.code===a.code),d=f?`${f.pts}${f.fast?' <span class="best">FL</span>':""}`:"";return`<tr class="${a.isPlayer?"me":""}"><td>${o+1}</td><td><span class="sw" style="background:${a.color}"></span>${a.name}</td><td>${a.car.spec.name}</td><td class="num">${l}</td><td class="num">${h}</td><td class="num pits-col">${c}</td><td class="num champ-col">${d}</td></tr>`}).join(""),this.inChamp?this.fillChampResults():(pt("res-again").textContent="Race again",pt("res-menu").textContent="Menu")}resetPlayer(){if(!(this.state==="racing"||this.state==="finished"))return;const t=this.player.car,e=this.track,n=t.trackIdx<0?e.nearest(t.x,t.z).i:t.trackIdx,i=e.pointAt(n*e.ds,0);t.place(i.x,i.y,i.z,i.heading),e.project(t.x,t.z,-1,t.trackInfo),t.trackIdx=t.trackInfo.i,this.player.lastS=t.trackInfo.s,this.player.divSide=0,this.effects.skids.last.clear(),this.rig.snap=!0,this.hud.toast("Car reset")}rubber(t){if(!this.player||t.isPlayer)return 1;const e=t.prog-this.player.prog;return Ye.clamp(1-e/9e3,.965,1.03)}simulate(t){const e=this.state,n=e==="racing"||e==="finished";n&&(this.raceTime+=t);const i=this.track,s=this.env.grip;n&&this.drafting(t);for(const a of this.entries){const o=a.car;o.weatherGrip=s;let l=a.isPlayer&&!a.finished?this.playerInput:a.ai.update(t,this.entries,s,this.rubber(a));if(n&&(l=this.pitInput(a,l)),!n){const c=o.spec.idleRPM+l.throttle*(o.spec.maxRPM*.78-o.spec.idleRPM);o.rpm+=(c-o.rpm)*Math.min(1,t*7),o.throttle=l.throttle;continue}o.step(t,l,i),this.walls(a),this.pitLogic(a,t)}n&&this.carCollisions();for(const a of this.entries)this.progress(a,t);n&&lt.ghost==="on"&&this.recordGhost()}walls(t){const e=t.car,n=e.trackInfo,i=e.spec.model,s=e.heading-Math.atan2(n.tx,n.tz),a=i.halfW*Math.abs(Math.cos(s))+i.len/2*Math.abs(Math.sin(s)),o=this.track.pit,l=[[1,n.wallL],[-1,n.wallR]];if(o&&n.pit===2){const c=n.lat>o.D?1:-1;(!t.divSide||c!==t.divSide&&Math.abs(n.lat-o.D)>o.DT+a+.8)&&(t.divSide=c),l.push(t.divSide<0?[1,o.D-o.DT]:[-1,-(o.D+o.DT)])}else t.divSide=0;for(const[c,h]of l){const u=c*n.lat+a-h;if(u<=0)continue;const f=-c*n.lx,d=-c*n.lz;e.x+=f*u,e.z+=d*u,n.lat-=c*u;const g=e.vx*f+e.vz*d,_=e.speed;if(g<0){const m=-g;e.vx-=f*g*1.3,e.vz-=d*g*1.3;const p=Math.max(.55,1-m*.03);e.vx*=p,e.vz*=p,e.yawRate=e.yawRate*.5-m*.11*Math.sin(s);const x=e.x-f*a*.9,y=e.z-d*a*.9;m>1.5&&this.events.push({type:"hit",e:t,x,y:e.y+.45,z:y,nx:f,nz:d,imp:m,tx:e.vx,tz:e.vz}),m>3&&e.damageEnabled&&(e.damage=Math.min(100,e.damage+(m-3)*2.1),this.dent(t,x,y,Math.min(.16,m*.011)))}else _>8&&Math.random()<.3&&this.events.push({type:"scrape",e:t,x:e.x-f*a,y:e.y+.35,z:e.z-d*a,tx:e.vx,tz:e.vz})}}assignPitBoxes(){const t=this.track.pit;if(!t)return;const e=t.boxes.length,n=[];let i=0;for(const s of this.entries)s.pit.box=s.isPlayer?0:1+i++%(e-1),n[s.pit.box]||(n[s.pit.box]=s.color);if(this.track.setPitBoxColors(n),this.crew){const s=new Set,a=[];for(const o of this.entries)s.has(o.pit.box)||(s.add(o.pit.box),a.push({box:o.pit.box,color:o.color,entry:o}));this.crew.setTeams(a)}}pitRs(t){const e=this.track.pit;return this.track.pitRel(t.car.trackInfo.s)+e.sE}pitInput(t,e){const n=this.track.pit;if(!n)return e;const i=t.pit,s=t.car;if(i.phase==="service")return{steer:0,throttle:0,brake:0,handbrake:!0,analog:!0};if(i.lane&&s.speed>n.limit-.4){const a=s.speed-(n.limit-.4);return{...e,throttle:0,brake:Math.max(e.brake||0,Math.min(1,a*.3))}}return e}pitLogic(t,e){const n=this.track.pit;if(!n||!t.racing)return;const i=t.car,s=i.trackInfo,a=t.pit,o=this.pitRs(t),l=a.lane;a.lane=s.pit>0&&s.lat>n.D-n.DT-.3&&o>=n.sD0-1&&o<=n.sD1+1;const c=n.boxes[a.box];if(a.phase==="service"){i.vx=i.vz=0,i.yawRate=0,a.t+=e;const f=Math.min(1,a.t/a.dur);i.damage=a.d0*(1-f),a.tyres&&(i.wear=a.w0*(1-Math.min(1,a.t/Math.min(a.dur,3.2)))),f>=1&&(i.damage=0,a.tyres&&(i.wear=0),t.vis.repair(),a.phase="out",a.stops++,t.ai&&t.ai.pit&&(t.ai.pit.phase=1),t.isPlayer&&(this.hud.toast(a.d0>.5?a.tyres?"Repaired · fresh tyres · go":"Repairs complete · go":a.tyres?"Fresh tyres · go":"All checked · go"),this.audio.beep(!0)));return}if(a.lane||(a.trap=!1),a.lane&&!a.trap&&o>n.sD0+6&&(a.trap=!0,i.speed>n.limit+12/3.6&&!t.finished&&(t.penalty+=Fl,t.isPlayer&&(this.hud.toast(`Pit lane speeding ${Math.round(i.kmh)} km/h · +${Fl} s penalty`),this.audio.beep(!1)))),a.lane&&!l&&t.isPlayer&&a.phase==="none"&&(a.phase="in",this.hud.toast("Pit limiter 80 km/h · stop in your box")),a.lane&&a.phase!=="out"&&i.speed<1.3&&Math.abs(o-c)<3.6&&s.lat>n.boxLat-2.4&&(t.ai&&!t.isPlayer?!!t.ai.pit:!0)){a.phase="service",a.t=0,a.d0=i.damage,a.w0=i.wear,a.tyres=i.wear>.08,a.dur=2.4+i.damage*.06+(a.tyres?2.2:0),i.vx=i.vz=0,i.gear===0&&(i.gear=1),t.isPlayer&&this.hud.toast(i.damage>.5?"Pit crew working":a.tyres?"Tyre change":"Quick check · no damage");return}if(!a.lane&&l&&(a.phase="none",t.ai&&t.ai.pit&&t.ai.pit.phase===1&&(t.ai.pit=null)),t.ai&&!t.isPlayer&&t.ai.pit&&o>n.sX+5&&o<n.sX+200&&(t.ai.pit=null),t.ai&&!t.isPlayer&&!t.ai.pit&&!t.finished){const f=lt.laps-t.lapsDone,d=i.damageEnabled&&i.damage>45,g=i.wearRate>0&&i.wear>.6;o>n.sE-320&&o<n.sE-150&&f>1&&(d||g)&&(t.ai.pit={box:a.box,phase:0})}const h=i.damageEnabled&&i.damage>40,u=i.wearRate>0&&i.wear>.6;t.isPlayer&&(h||u)&&!t.finished&&lt.laps-t.lapsDone>1&&o>n.sE-520&&o<n.sE-380&&a.warned!==t.lapsDone&&(a.warned=t.lapsDone,this.hud.toast(`${h?`Damage ${Math.round(i.damage)}%`:`Tyres ${Math.round((1-i.wear)*100)}% left`} · pit lane on the left`))}dent(t,e,n,i){const s=t.car,a=e-s.x,o=n-s.z,l=Math.sin(s.heading),c=Math.cos(s.heading),h=new D(a*c-o*l,.55,a*l+o*c);t.vis.deform(h,i)}carCollisions(){const t=this.entries,e=[-.32,0,.32];for(let n=0;n<t.length;n++)for(let i=n+1;i<t.length;i++){const s=t[n].car,a=t[i].car,o=a.x-s.x,l=a.z-s.z,c=s.spec.model.len,h=a.spec.model.len;if(o*o+l*l>((c+h)/2+1)**2||Math.abs(s.y-a.y)>2)continue;const u=s.spec.model.halfW*1.02,f=a.spec.model.halfW*1.02;let d=null;const g=Math.sin(s.heading),_=Math.cos(s.heading),m=Math.sin(a.heading),p=Math.cos(a.heading);for(const ut of e){const B=s.x+g*ut*c,J=s.z+_*ut*c;for(const ht of e){const at=a.x+m*ht*h,wt=a.z+p*ht*h,xt=B-at,Y=J-wt,et=Math.hypot(xt,Y),dt=u+f-et;dt>0&&(!d||dt>d.pen)&&(d={pen:dt,nx:xt/(et||1),nz:Y/(et||1),cx:(B+at)/2,cz:(J+wt)/2})}}if(!d)continue;const{pen:x,nx:y,nz:v,cx:R,cz:T}=d,E=1/s.spec.mass,P=1/a.spec.mass,b=E+P;s.x+=y*x*(E/b),s.z+=v*x*(E/b),a.x-=y*x*(P/b),a.z-=v*x*(P/b);const M=R-s.x,C=T-s.z,U=R-a.x,O=T-a.z,V=s.vx+s.yawRate*C,X=s.vz-s.yawRate*M,W=a.vx+a.yawRate*O,j=a.vz-a.yawRate*U,k=(V-W)*y+(X-j)*v;if(k>=0)continue;const it=C*y-M*v,q=O*y-U*v,tt=-1.25*k/(b+it*it/s.inertia+q*q/a.inertia);s.vx+=y*tt*E,s.vz+=v*tt*E,a.vx-=y*tt*P,a.vz-=v*tt*P,s.yawRate+=it*tt/s.inertia*.7,a.yawRate-=q*tt/a.inertia*.7;const rt=-k;if(rt>1.2&&this.events.push({type:"hit",e:t[n],other:t[i],x:R,y:(s.y+a.y)/2+.5,z:T,nx:y,nz:v,imp:rt,tx:(s.vx+a.vx)/2,tz:(s.vz+a.vz)/2}),rt>2.5)for(const[ut,B]of[[t[n],s],[t[i],a]])B.damageEnabled&&(B.damage=Math.min(100,B.damage+(rt-2.5)*1.6),this.dent(ut,R,T,Math.min(.12,rt*.01)))}}progress(t,e){const n=this.track,i=n.length,s=t.car,a=s.trackInfo.s;let o=a-t.lastS;if(o>i/2&&(o-=i),o<-i/2&&(o+=i),t.prog+=o,t.lastS=a,!t.racing||t.finished)return;const l=Math.floor(t.prog/i);if(l>t.lapsDone){t.lapsDone=l;const u=this.raceTime-t.lapStart;t.lapTimes.push(u),t.lapStart=this.raceTime;const f=t.best;if((t.best==null||u<t.best)&&(t.best=u),t.isPlayer&&this.lapDone(u)&&this.hud.toast(`New ghost · ${ln(u)}`),t.isPlayer&&l<lt.laps){const g=Math.min(...this.entries.map(m=>m.best??1/0)),_=u<=g?"purple":f==null||u<f?"green":"yellow";this.hud.split(`LAP ${ln(u)}`,_),l===lt.laps-1?this.hud.message("Final lap","warn",2):this.hud.sub(`Lap ${l+1} / ${lt.laps}`,2),this.audio.beep(!1)}if(l>=lt.laps){this.finish(t);return}}const c=(t.prog%i+i)%i,h=Math.min(2,Math.floor(c/(i/3)));if(h!==t.sector&&t.prog>0){if(t.isPlayer&&h>t.sector){const u=this.raceTime-t.sectorStart,f=`s${t.sector}`;t.secBest=t.secBest||{};const d=t.secBest[f],g=d==null?"yellow":u<d?"green":"yellow";(d==null||u<d)&&(t.secBest[f]=u),this.hud.split(`S${t.sector+1}  ${u.toFixed(3)}`,g)}t.sector=h,t.sectorStart=this.raceTime}if(t.isPlayer){const u=s.heading-Math.atan2(s.trackInfo.tx,s.trackInfo.tz);Math.cos(u)<-.2&&s.speed>3?t.wrong+=e:t.wrong=0}}loop(){requestAnimationFrame(()=>this.loop());const t=Math.min(.1,this.clock.getDelta());this.manual||this.tick(t),this.render(t)}tick(t){this.playerInput=this.input.update(t);const e=this.state;if(!(e==="paused"||e==="loading")){if(e==="countdown"&&this.countdown(t),e==="countdown"||e==="racing"||e==="finished"){this.acc+=t;let n=0;for(;this.acc>=jr&&n<16;)this.simulate(jr),this.acc-=jr,n++;n===16&&(this.acc=0)}this.frameVisuals(t)}}countdown(t){this.countT+=t;const e=Math.min(5,Math.floor(this.countT));if(e!==this.lightsShown&&this.countT<this.lightsOutAt&&(this.lightsShown=e,this.track.setStartLights(e),e>0&&(this.audio.beep(!1),this.hud.message(String(e),"",.8))),this.countT>=this.lightsOutAt){this.state="racing",this.track.setStartLights(0,!0),setTimeout(()=>this.track.setStartLights(0),2500),this.audio.beep(!0),this.hud.message("Go","go",1.2);for(const n of this.entries)n.racing=!0,n.lapStart=0,n.sectorStart=0}}frameVisuals(t){const e=this.track,n=this.events;for(const o of this.entries)o.vis.update(o.car,t),this.emitCarFx(o,t);for(const o of n){const l=o.e===this.player||o.other===this.player;if(o.type==="hit"){this.effects.sparkBurst(o.x,o.y,o.z,o.tx*.08,o.tz*.08,Math.min(40,6+o.imp*3),4+o.imp*.6);const c=Math.hypot(o.x-this.camera.position.x,o.z-this.camera.position.z);this.audio.impact(Math.min(1,o.imp/12)*Math.max(.1,1-c/120)),l&&(this.rig.shake=Math.min(.35,this.rig.shake+o.imp*.02))}else this.effects.sparkBurst(o.x,o.y,o.z,o.tx*.06,o.tz*.06,2,3)}n.length=0,this.crew&&this.crew.update(this.state==="paused"?0:Math.min(t,.1),o=>this.pitRs(o)),this.effects.update(t);const i=this.player;if(!i)return;this.rig.update(t,i.car,i.vis,e,{lookBack:this.input.lookingBack()}),this.env.update(t,this.camera,i.car,{x:i.car.vx,z:i.car.vz});let s=null,a=70;for(const o of this.entries){if(o===i)continue;const l=Math.hypot(o.car.x-this.camera.position.x,o.car.z-this.camera.position.z);l<a&&(a=l,s=o)}this.audio.update(i.car,s?{car:s.car,gain:(1-a/70)**2*.8}:null,{racing:this.state==="racing"||this.state==="countdown"||this.state==="finished",menu:this.state==="menu",rain:this.env.wet}),this.updateGhost(),(this.state==="racing"||this.state==="countdown"||this.state==="finished")&&this.updateHud(t)}emitCarFx(t,e){const n=t.car,i=this.effects;if(n.speed<.6&&n.skid<.05){i.skids.lift(t.code+"L"),i.skids.lift(t.code+"R");return}const s=Math.sin(n.heading),a=Math.cos(n.heading),o=n.spec.model,l=o.halfW*.96-.15,c=t.vis.axR,h=this.env.night?.45:1,u=this.camera.position,f=Math.hypot(n.x-u.x,n.z-u.z)>160;for(const d of[1,-1]){const g=t.code+(d>0?"L":"R"),_=n.x+a*l*d+s*c,m=n.z-s*l*d+a*c;if(n.skid>.28&&n.onAsphalt){if(i.skids.add(g,_,n.y+.03,m,s,a,.3,Math.min(1,n.skid*1.2)),!f){const p=n.skid*38*e;let x=Math.floor(p)+(Math.random()<p%1?1:0);for(;x--;)i.tyreSmoke(_,n.y,m,n.vx,n.vz,n.skid,[.86*h,.86*h,.88*h])}}else i.skids.lift(g);if(!n.onAsphalt&&n.speed>4&&!f){const p=n.surface===2?[.72,.64,.5]:n.surface===3?[.52,.44,.32]:[.42,.48,.3],x=n.speed/25*14*e;let y=Math.floor(x)+(Math.random()<x%1?1:0);for(;y--;)i.dust(_,n.y,m,n.vx,n.vz,p.map(v=>v*h))}if(this.env.wet&&n.speed>12&&n.onAsphalt&&!f){const p=n.speed*.35*e;let x=Math.floor(p)+(Math.random()<p%1?1:0);for(;x--;)i.spray(_-s*.4,n.y,m-a*.4,n.vx,n.vz)}}if(n.damage>55&&!f){const d=(n.damage-50)*.35*e;if(Math.random()<d){const g=o.len/2-.9;i.damageSmoke(n.x+s*g,n.y+.95,n.z+a*g,n.damage>80)}}}updateHud(t){const e=this.player,n=this.hud;n.tick(t),this.hudT=(this.hudT||0)-t;const i=this.order(),s={pos:i.indexOf(e)+1,total:this.entries.length,lap:Math.min(lt.laps,e.lapsDone+1),laps:lt.laps,time:this.raceTime,lapTime:this.state==="countdown"?0:e.finished?e.lapTimes[e.lapTimes.length-1]:this.raceTime-e.lapStart,last:e.lapTimes.length?e.lapTimes[e.lapTimes.length-1]:null,best:e.best};n.update(e.car,s),this.hudT<=0&&(this.hudT=.2,n.updateTower(i,e,i[0].prog,this.track.length),this.resultsShown&&this.fillResults()),n.drawMinimap(this.entries,e);const a=e.car.draft>.3&&!e.finished;a!==this._draftOn&&(this._draftOn=a,pt("h-draft").classList.toggle("on",a));const o=e.penalty||0;o!==this._penShown&&(this._penShown=o,pt("pen-row").classList.toggle("on",o>0),pt("h-pen").textContent=`+${o} s`);const l=e.pit,c=l.lane&&l.phase!=="service";c!==this._pitOn&&(this._pitOn=c,pt("h-pit").classList.toggle("on",c));const h=l.phase==="service";if(h!==this._svcOn&&(this._svcOn=h,pt("pit-service").classList.toggle("on",h)),h){const u=Math.min(1,l.t/l.dur);pt("ps-bar").style.width=`${(u*100).toFixed(0)}%`,pt("ps-txt").textContent=`${l.d0>.5?l.tyres?"Repairs + tyres":"Repairing":l.tyres?"Changing tyres":"Checking"} · ${Math.round(u*100)}%`}e.wrong>1.2&&!e.finished&&n.message("Wrong way","warn",.3)}render(t){const e=this.player;if(this.fpsAvg+=(1/Math.max(t,.001)-this.fpsAvg)*.05,ae.fps==="on"&&(this._dbgT=(this._dbgT||0)-t,this._dbgT<=0)){this._dbgT=.25;const o=this.renderer.info;pt("debug").textContent=`${this.fpsAvg.toFixed(0)} fps · ${(1e3/this.fpsAvg).toFixed(1)} ms · ${o.render.calls} calls · ${(o.render.triangles/1e3).toFixed(0)}k tris · res ${this.pr.toFixed(2)}`}if(!this.manual&&this.state!=="paused"&&(this.fpsAvg<48?this.perf.slow+=t:this.perf.slow=0,this.fpsAvg>58?this.perf.fast+=t:this.perf.fast=0,this.perf.slow>2.5&&this.pr>.6&&(this.pr=Math.max(.6,this.pr-.15),this.perf.slow=0,this.resize()),this.perf.fast>6&&this.pr<this.basePR&&(this.pr=Math.min(this.basePR,this.pr+.1),this.perf.fast=0,this.resize())),!e)return;const n=e.car.speed,s=this.rig.mode!=="cinematic"&&this.rig.mode!=="orbit"?Ye.clamp((n-28)/55,0,1)*.9:0,a=this.env.wet&&(this.rig.mode==="chase"||this.rig.mode==="bumper"||this.rig.mode==="cockpit")?1:0;this.usePost?this.post.render(t,s,a):this.renderer.render(this.scene,this.camera)}applySettings(){const t=ae.quality,e=window.devicePixelRatio||1;this.basePR=t==="low"?Math.min(e,1)*.75:t==="medium"?Math.min(e,1.25):Math.min(e,1.75),this.pr=this.basePR,this.usePost=t!=="low",this.env.setShadows(ae.shadows==="on"&&t!=="low",t==="high"?2048:1024),this.configurePost(),this.hud.setUnits(ae.units),this.input.sensitivity=ae.steer,this.applyDriverAids(),this.audio.setVolumes(ae.master,ae.music),pt("debug").classList.toggle("hidden",ae.fps!=="on"),(this.state==="racing"||this.state==="countdown"||this.state==="finished"||this.state==="paused")&&this.showTouch(!0),this.resize()}configurePost(){this.post.configure({bloom:ae.bloom==="on",motionBlur:ae.motionBlur==="on",night:this.env.night||lt.time==="dusk"})}cycleCamera(t){(this.state==="racing"||this.state==="countdown"||this.state==="finished")&&(this.camIndex=t??(this.camIndex+1)%is.length,this.rig.set(is[this.camIndex]),this.hud.toast(H0[is[this.camIndex]]))}bindInput(){const t=this.input;t.on("camera",()=>this.cycleCamera()),is.forEach((n,i)=>t.on(`cam${i+1}`,()=>this.cycleCamera(i))),t.on("pause",()=>{const n=[...document.querySelectorAll("#settings, #controls")].find(i=>!i.classList.contains("hidden"));if(n){n.classList.add("hidden");return}this.state==="paused"?this.pause(!1):this.pause(!0)}),t.on("reset",()=>this.resetPlayer());const e=()=>ae.gearbox==="manual"&&this.player&&!this.player.finished&&(this.state==="racing"||this.state==="countdown");t.on("shiftUp",()=>{e()&&this.player.car.shiftUp()}),t.on("shiftDown",()=>{e()&&this.player.car.shiftDown()}),t.on("mute",()=>{this.muted=!this.muted,this.audio.setVolumes(this.muted?0:ae.master,this.muted?0:ae.music),this.hud.toast(this.muted?"Audio muted":"Audio on")}),t.on("fps",()=>{ae.fps=ae.fps==="on"?"off":"on",this.applySettings(),this.syncSettingsUI()}),t.bindTouch(pt("touch")),pt("btn-pause").addEventListener("click",()=>this.pause(!0)),pt("btn-cam").addEventListener("click",()=>this.cycleCamera())}buildMenus(){const t=pt("track-list");t.innerHTML=_e.map(i=>`
      <button class="card" data-track="${i.id}">
        <div class="c-type">${i.type}</div>
        <div class="c-name">${i.name}</div>
        <canvas></canvas>
        <div class="c-desc">${i.desc}</div>
        <div class="c-best" data-best="${i.id}"></div>
        <div class="c-meta"><span>${(this.trackCache[i.id].length/1e3).toFixed(2)} km</span><span class="diff">${[1,2,3].map(s=>`<i class="${s<=i.difficulty?"on":""}"></i>`).join("")}</span></div>
      </button>`).join(""),t.querySelectorAll(".card").forEach(i=>{i.addEventListener("click",()=>this.pickTrack(i.dataset.track))}),requestAnimationFrame(()=>t.querySelectorAll(".card").forEach(i=>X0(i.querySelector("canvas"),this.trackCache[i.dataset.track])));const e=pt("car-list");e.innerHTML=Fn.map(i=>`
      <button class="card" data-car="${i.id}">
        <div class="c-type">${i.cls}</div>
        <div class="c-name">${i.name}</div>
        <div class="c-desc">${i.desc}</div>
        <div class="stats">
          ${[["Accel",i.stats.accel],["Top speed",i.stats.top],["Handling",i.stats.handling],["Braking",i.stats.braking]].map(([s,a])=>`<div class="stat"><span>${s}</span><div class="sb"><i style="width:${a*10}%"></i></div></div>`).join("")}
        </div>
        <div class="c-meta"><span>${Math.round(i.topSpeed*3.6)} km/h</span><span>${i.mass} kg</span></div>
      </button>`).join(""),e.querySelectorAll(".card").forEach(i=>i.addEventListener("click",()=>this.pickCar(i.dataset.car)));const n=pt("paints");n.innerHTML=wl.map(i=>`<button class="swatch" data-paint="${i.hex}" title="${i.name}" aria-label="${i.name}" style="background:${i.hex}"></button>`).join(""),n.querySelectorAll(".swatch").forEach(i=>i.addEventListener("click",()=>this.pickPaint(i.dataset.paint))),pt("paint-custom").addEventListener("input",i=>this.pickPaint(i.target.value)),document.querySelectorAll("[data-go]").forEach(i=>i.addEventListener("click",()=>{this.audio.init(),this.audio.click();const s=i.dataset.go;document.querySelectorAll(".screen").forEach(a=>a.classList.toggle("active",a.id===`scr-${s}`))})),document.querySelectorAll(".tab").forEach(i=>i.addEventListener("click",()=>{this.audio.click(),document.querySelectorAll(".tab").forEach(s=>s.classList.toggle("active",s===i)),document.querySelectorAll(".pane").forEach(s=>s.classList.toggle("active",s.dataset.pane===i.dataset.tab))})),document.querySelectorAll("[data-opt]").forEach(i=>{i.querySelectorAll("button").forEach(s=>s.addEventListener("click",()=>{this.audio.click();const a=i.dataset.opt;let o=s.dataset.v;if((a==="laps"||a==="opponents")&&(o=parseInt(o,10)),lt[a]=o,this.syncRaceUI(),a==="time"||a==="weather"){this.env.apply(lt.time,lt.weather,this.track),this.effects.setLighting(this.env.night?.6:lt.time==="dusk"?.8:1),this.configurePost();for(const l of this.entries)l.vis.setNight(this.env.night||lt.time==="dusk");this.headlight.intensity=this.env.night?70:lt.time==="dusk"?25:0}(a==="opponents"||a==="grid"||a==="ghost")&&this.buildGrid()}))}),document.querySelectorAll("[data-set]").forEach(i=>{i.querySelectorAll("button").forEach(s=>s.addEventListener("click",()=>{this.audio.click(),ae[i.dataset.set]=s.dataset.v,this.applySettings(),this.syncSettingsUI()}))}),document.querySelectorAll("[data-range]").forEach(i=>i.addEventListener("input",()=>{ae[i.dataset.range]=parseFloat(i.value),this.applySettings()})),document.querySelectorAll("[data-open]").forEach(i=>i.addEventListener("click",()=>{this.audio.init(),this.audio.click(),pt(i.dataset.open).classList.remove("hidden")})),document.querySelectorAll("[data-close]").forEach(i=>i.addEventListener("click",()=>{this.audio.click(),pt(i.dataset.close).classList.add("hidden")})),pt("btn-start").addEventListener("click",()=>{this.audio.click(),this.champSetup?this.startChampionship():(this.inChamp=!1,this.startRace())}),pt("btn-quick").addEventListener("click",()=>{this.audio.init(),this.audio.click(),this.openQuickSetup()}),pt("btn-champ").addEventListener("click",()=>{this.audio.init(),this.audio.click(),this.champ?this.openHub():this.openChampSetup()}),pt("hub-go").addEventListener("click",()=>{if(this.audio.click(),this.champ.results.filter(Boolean).length>=_e.length){this.champ=null,this.updateHomeChamp(),this.openChampSetup();return}this.startChampRound()}),pt("hub-abandon").addEventListener("click",()=>{this.audio.click(),this.champ=null,this.updateHomeChamp(),this.toMenu("home")}),pt("btn-resume").addEventListener("click",()=>this.pause(!1)),pt("btn-restart").addEventListener("click",()=>this.startRace()),pt("btn-quit").addEventListener("click",()=>{this.dirtyGrid=!0,this.inChamp?(this.inChamp=!1,document.body.classList.remove("champ-on"),this.updateHomeChamp(),this.toMenu("home")):this.toMenu("setup")}),pt("res-again").addEventListener("click",()=>{this.inChamp?(this.advanceChamp(),this.openHub()):this.startRace()}),pt("res-menu").addEventListener("click",()=>{this.dirtyGrid=!0,this.inChamp?(this.advanceChamp(),this.toMenu("home")):this.toMenu("setup")}),this.syncRaceUI(),this.syncSettingsUI()}advanceChamp(){const t=this.champ;t&&t.results[t.round]&&t.round<_e.length-1&&t.round++,this.inChamp=!1,document.body.classList.remove("champ-on"),this.updateHomeChamp()}updateHomeChamp(){const t=this.champ,e=pt("btn-champ");if(!t){e.textContent="Championship";return}const n=t.results.filter(Boolean).length;e.textContent=n>=_e.length?"Championship · results":`Continue championship · R${t.round+1}`}pickTrack(t){if(this.audio.click(),lt.track===t)return;lt.track=t;const e=_e.find(n=>n.id===t);lt.time=e.time,lt.weather=e.weather,this.syncRaceUI(),this.loadTrack(t),this.buildGrid()}pickCar(t){this.audio.click(),lt.car!==t&&(lt.car=t,this.syncRaceUI(),this.buildGrid())}pickPaint(t){lt.paint=t,this.player.vis.setPaint(t),this.player.color=t,this.dirtyGrid=!0,this.syncRaceUI()}syncRaceUI(){document.querySelectorAll("[data-track]").forEach(t=>t.classList.toggle("active",t.dataset.track===lt.track)),document.querySelectorAll("[data-car]").forEach(t=>t.classList.toggle("active",t.dataset.car===lt.car)),document.querySelectorAll("[data-best]").forEach(t=>{const e=this.records[`${t.dataset.best}:${lt.car}`];t.textContent=e?`Best ${ln(e.time)}`:""}),document.querySelectorAll(".swatch").forEach(t=>t.classList.toggle("active",t.dataset.paint.toLowerCase()===lt.paint.toLowerCase())),document.querySelectorAll("[data-opt]").forEach(t=>t.querySelectorAll("button").forEach(e=>e.classList.toggle("active",String(lt[t.dataset.opt])===e.dataset.v))),this.updateSummary()}syncSettingsUI(){document.querySelectorAll("[data-set]").forEach(t=>t.querySelectorAll("button").forEach(e=>e.classList.toggle("active",String(ae[t.dataset.set])===e.dataset.v))),document.querySelectorAll("[data-range]").forEach(t=>t.value=ae[t.dataset.range])}updateSummary(){const t=_e.find(i=>i.id===lt.track),e=Fn.find(i=>i.id===lt.car),n=i=>i[0].toUpperCase()+i.slice(1);if(this.champSetup){pt("setup-summary").innerHTML=`<span><b>Championship</b> · ${_e.length} rounds</span><span>Car <b>${e.name}</b></span><span><b>${lt.laps}</b> ${lt.laps>1?"laps":"lap"} per round</span><span><b>${lt.opponents}</b> rivals · ${Gs[lt.difficulty].label}</span><span>${lt.grid==="mixed"?"Multi-class":"One-make"}</span>`;return}pt("setup-summary").innerHTML=`<span>Track <b>${t.name}</b></span><span>Car <b>${e.name}</b></span><span><b>${lt.laps}</b> laps</span><span><b>${lt.opponents}</b> opponents · ${Gs[lt.difficulty].label}</span><span>${n(lt.time)} · ${n(lt.weather)}</span><span>${lt.grid==="mixed"?"Multi-class":"One-make"}</span>`}textState(){var i,s,a;const t=this.player;if(!t)return JSON.stringify({mode:this.state});const e=t.car,n=this.order();return JSON.stringify({coords:"x/z ground plane, y up; heading 0 = +z, positive = turning left",mode:this.state,track:this.track.def.id,camera:this.rig.mode,lap:Math.min(lt.laps,t.lapsDone+1),laps:lt.laps,position:n.indexOf(t)+1,of:this.entries.length,time:+this.raceTime.toFixed(2),lapTimes:t.lapTimes.map(o=>+o.toFixed(2)),player:{x:+e.x.toFixed(1),z:+e.z.toFixed(1),heading:+e.heading.toFixed(3),kmh:Math.round(e.kmh),gear:e.gear,rpm:Math.round(e.rpm),lat:+((i=e.trackInfo.lat)==null?void 0:i.toFixed(2)),s:+((s=e.trackInfo.s)==null?void 0:s.toFixed(1)),prog:+t.prog.toFixed(1),damage:Math.round(e.damage),tyres:Math.round((1-e.wear)*100),penalty:t.penalty,pit:{phase:t.pit.phase,lane:t.pit.lane,box:t.pit.box,stops:t.pit.stops,progress:t.pit.phase==="service"?+(t.pit.t/t.pit.dur).toFixed(2):null},steer:+e.steer.toFixed(3),surface:e.surface,skid:+e.skid.toFixed(2),draft:+e.draft.toFixed(2),gearbox:e.manualGears?"manual":"auto",assist:e.assist},champ:this.champ?{round:this.champ.round+1,done:this.champ.results.filter(Boolean).length,inRound:!!this.inChamp,standings:this.champTable().map(o=>`${o.code}:${o.pts}`)}:null,ghost:this.records[this.recKey()]?{best:+this.records[this.recKey()].time.toFixed(2),visible:!!((a=this.ghost)!=null&&a.root.visible),delta:pt("h-delta").textContent}:null,opponents:this.entries.filter(o=>!o.isPlayer).map(o=>{var l;return{code:o.code,car:o.car.spec.id,prog:Math.round(o.prog),kmh:Math.round(o.car.kmh),lat:+((l=o.car.trackInfo.lat)==null?void 0:l.toFixed(1)),dmg:Math.round(o.car.damage),tyres:Math.round((1-o.car.wear)*100),pit:o.pit.phase,stops:o.pit.stops,pitting:!!(o.ai&&o.ai.pit)}})})}}const Di=new j0;window.__game=Di;window.render_game_to_text=()=>Di.textState();window.advanceTime=r=>{Di.manual=!0;const t=Math.max(1,Math.round(r/(1e3/60)));for(let e=0;e<t;e++)Di.tick(1/60);Di.render(1/60)};Di.boot();
