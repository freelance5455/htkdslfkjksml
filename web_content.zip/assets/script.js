
const menuButton=document.querySelector('.menu-btn');
const nav=document.querySelector('.navlinks');
if(menuButton&&nav){menuButton.addEventListener('click',()=>{const open=nav.classList.toggle('open');menuButton.setAttribute('aria-expanded',String(open));});}
document.querySelectorAll('[data-year]').forEach(el=>el.textContent=new Date().getFullYear());
const form=document.querySelector('#inquiry-form');
if(form){form.addEventListener('submit',e=>{e.preventDefault();const d=new FormData(form);const msg=`Hello Entire Apparel,%0A%0AName: ${encodeURIComponent(d.get('name')||'')}%0ABrand/Company: ${encodeURIComponent(d.get('company')||'')}%0AEmail: ${encodeURIComponent(d.get('email')||'')}%0AInterested in: ${encodeURIComponent(d.get('interest')||'')}%0AOrder quantity: ${encodeURIComponent(d.get('quantity')||'')}%0ADetails: ${encodeURIComponent(d.get('message')||'')}`;window.open('https://wa.me/923326846694?text='+msg,'_blank');});}
