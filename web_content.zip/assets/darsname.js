const app=document.getElementById("app"),PORTAL="index.html",$=id=>document.getElementById(id);
const st=(k,v)=>{try{if(v===undefined)return JSON.parse(localStorage.getItem(k)||"[]");localStorage.setItem(k,JSON.stringify(v))}catch(e){return[]}};
const fd=s=>String(s).replace(/\d/g,d=>"۰۱۲۳۴۵۶۷۸۹"[d]);
const CA={};CONST.a.forEach(a=>CA[a.n]=a);
const RA={};RULES.a.forEach(a=>RA[a.n]=a);
const DD={};DST.ch.forEach(c=>c.docs.forEach(d=>{if(!d.p)DD[d.id]=d}));
const SH={};Object.values(SAHN).forEach(a=>a.forEach(x=>SH[x.id]=x.t));
const READY=LIST.filter(x=>x.ready&&(LS[x.id]||LV2[x.id]));
const done=()=>st("ds_les_done");
const sec=(id,t,b)=>`<section class="lsec" id="${id}"><h2>${t}</h2>${b}</section>`;
const ul=a=>`<ul style="padding-right:22px">${a.map(x=>`<li>${esc(x)}</li>`).join("")}</ul>`;
const dtitle=id=>DD[id]?DD[id].t:id;
function home(){const d=done(),n=LIST.length;
const draw=arr=>{let g="";return arr.map(t=>{const h=t.g!==g?(g=t.g,`<h3>${esc(g)}</h3>`):"";
return h+(t.ready&&(LS[t.id]||LV2[t.id])?`<a class="cp${d.includes(t.id)?" t":""}" style="display:block;border-radius:12px;padding:6px 14px;margin:6px 0" href="#t${t.id}">${d.includes(t.id)?"✅":"⬜"} ${esc(t.t)}</a>`:`<div class="pd"><b>${esc(t.t)}</b><span class="tag draft">به‌زودی</span></div>`)}).join("")};
const sh=LIST.filter(t=>!t.x),ex=LIST.filter(t=>t.x);
app.innerHTML=`<div class="nav"><a class="pill" href="${PORTAL}">‹ صفحه‌ی اصلی سامانه</a></div><header class="ph">${ROS}<h1 class="grad">درس‌نامه‌های موضوعی</h1><p>هر موضوع در چهار بخش: قانون اساسی، آیین‌نامه داخلی، احکام کاربردی صحن و دستورالعمل‌ها</p></header><div class="tools"><a class="pill" href="ayin.html#l">🎓 مسیر یادگیری آیین‌نامه (ماده‌به‌ماده)</a></div><p class="sub">${fd(d.filter(x=>READY.some(r=>r.id===x)).length)} درس از ${fd(READY.length)} درس آماده تمام شده؛ ${fd(sh.length)} موضوع مشترک و ${fd(ex.length)} موضوع اختصاصی در برنامه است</p><div class="prog" aria-hidden="true"><i style="width:${d.length/n*100}%"></i></div><h2 style="margin-top:18px">موضوعات مشترک (در دو یا چند بخش)</h2>${draw(sh)}<h2 style="margin-top:26px">موضوعات اختصاصی (فقط در یک بخش)</h2>${draw(ex)}<div class="box"><b>آزمون:</b> پس از تکمیل درس‌ها اضافه می‌شود.</div>${foot()}`}
function lesson(id){if(LV2[id])return lessonV2(id);const l=LS[id],m=LIST.find(x=>x.id===id);if(!l||!m)return home();
const i=READY.findIndex(x=>x.id===id),dn=done().includes(id);
const con=l.con.map(c=>{const a=CA[c.n];return`<div class="box"><b>اصل ${fd(c.n)}</b><p>${esc(c.s)}</p>${c.u?`<p><small style="color:var(--mut)">کاربرد: ${esc(c.u)}</small></p>`:""}<details class="tn"><summary>متن رسمی اصل ${fd(c.n)}</summary><div class="ap">${a?`<p>${esc(a.x.replace(/\s*\n\s*/g," "))}</p>`:""}</div></details><a class="cp" href="qanun.html#p${c.n}">صفحه‌ی اصل</a></div>`}).join("");
const ay=l.ayin.map(x=>{const a=RA[x.n];return`<div class="box"><b>ماده ${fd(x.n)}</b><p>${esc(x.s)}</p>${x.pts?ul(x.pts):""}<details class="tn"><summary>متن رسمی ماده ${fd(x.n)}</summary><div class="ap">${a?a.x.split("\n").filter(Boolean).map(p=>`<p>${esc(p)}</p>`).join(""):""}</div></details><a class="cp" href="ayin.html#m${x.n}">صفحه‌ی ماده</a></div>`}).join("");
const sh=`<div class="box"><p>${esc(l.sahn.s)}</p>${l.sahn.ids.map(k=>`<a class="cp t" href="sahn.html#t${k}">${esc(SH[k]||"")}</a>`).join("")}</div>`;
const ds=l.dst.map(x=>`<div class="box"><b>${esc(dtitle(x.d))}</b><p>${esc(x.s)}</p>${x.pts?ul(x.pts):""}<a class="cp" href="dastoor.html#d${x.d}">متن مستند</a></div>`).join("");
const body=sec("s0","تصویر کلی",l.ov.map(p=>`<p>${esc(p)}</p>`).join(""))+
sec("s1","قانون اساسی چه می‌گوید؟",con)+
sec("s2","آیین‌نامه داخلی چه می‌گوید؟",`<p>${esc(l.ayinNote)}</p>${ay}`)+
sec("s3","احکام کاربردی صحن چه می‌گوید؟",sh)+
sec("s4","دستورالعمل‌ها چه می‌گویند؟",ds)+
sec("s5","پیوند بین چهار بخش",ul(l.link))+
sec("s6","نکات مهم و خطاهای رایج",ul(l.tips))+
sec("s7","خلاصه‌ی درس (برای مرور)",ul(l.sum))+
(l.warn?`<div class="box warnb"><b>⚠️ یادداشت تطبیق</b><p>${esc(l.warn)}</p></div>`:"");
const nav=[["s0","تصویر کلی"],["s1","قانون اساسی"],["s2","آیین‌نامه"],["s3","صحن"],["s4","دستورالعمل‌ها"],["s5","پیوندها"],["s6","نکات"],["s7","خلاصه"]].map(a=>`<button class="cp" data-go="${a[0]}">${a[1]}</button>`).join("");
app.innerHTML=`<div class="nav"><button class="back" id="hb">‹ فهرست درس‌ها</button></div><header class="ph">${ROS}<h1 class="grad" style="font-size:clamp(22px,2.9vw,38px)">درس ${fd(LIST.findIndex(x=>x.id===id)+1)}: ${esc(m.t)}</h1><div class="crumb">${esc(m.g)}</div></header><div class="tools" style="justify-content:flex-start"><button class="pill${dn?" on":""}" id="dn">${dn?"✅ تمام شد":"☐ درس را تمام کردم"}</button></div><div>${nav}</div>${body}<div class="tools">${i>0?`<a class="pill" href="#t${READY[i-1].id}">› درس قبل</a>`:""}${i<READY.length-1?`<a class="pill" href="#t${READY[i+1].id}">درس بعد ‹</a>`:""}</div>${foot()}`;
$("hb").onclick=()=>go("");
$("dn").onclick=()=>{const c=done();st("ds_les_done",c.includes(id)?c.filter(x=>x!==id):[...c,id]);lesson(id)};
app.querySelectorAll("[data-go]").forEach(b=>b.onclick=()=>{const e=$(b.dataset.go);if(e)e.scrollIntoView({behavior:"smooth",block:"start"})})}

/* ===== قالب نسخه‌ی ۲ ===== */
let STEP=0,FCI=0,FCB=false;const QA={};
const stDone=id=>st("ds_steps_"+id);
function refBox(r){if(r.c){const a=CA[r.c];return a?`<details class="tn"><summary>متن رسمی اصل ${fd(r.c)}</summary><div class="ap"><p>${esc(a.x.replace(/\s*\n\s*/g," "))}</p></div></details><a class="cp" href="qanun.html#p${r.c}">صفحه‌ی اصل</a>`:""}
if(r.r){const a=RA[r.r];return a?`<details class="tn"><summary>متن رسمی ماده ${fd(r.r)}</summary><div class="ap">${a.x.split("\n").filter(Boolean).map(p=>`<p>${esc(p)}</p>`).join("")}</div></details><a class="cp" href="ayin.html#m${r.r}">صفحه‌ی ماده</a>`:""}return""}
function blkH(b){
if(b.k==="cards")return b.items.map(c=>`<div class="box"><b>${esc(c.h)}</b><p>${esc(c.s)}</p>${c.u?`<p><small style="color:var(--mut)">کاربرد: ${esc(c.u)}</small></p>`:""}${c.ref?refBox(c.ref):""}${c.link?`<a class="cp t" href="${c.link}">${esc(c.lt||"مشاهده")}</a>`:""}</div>`).join("");
if(b.k==="flow")return`<h3>${esc(b.title)}</h3><div class="tlv">${b.items.map((x,i)=>`<div class="fst"><i>${fd(i+1)}</i><div><b>${esc(x.t)}</b> <span class="ddl">${esc(x.d)}</span><p>${esc(x.s)}</p>${x.br?`<div class="fbr"><b>↳ ${esc(x.br.t)}</b><ul>${x.br.it.map(y=>`<li>${esc(y)}</li>`).join("")}</ul></div>`:""}</div></div>`).join("")}</div>`;
if(b.k==="cmp")return`<h3>${esc(b.title)}</h3><div class="tw"><table class="tbl"><tr>${b.head.map(h=>`<th>${esc(h)}</th>`).join("")}</tr>${b.rows.map(r=>`<tr>${r.map((c,i)=>i?`<td>${esc(c)}</td>`:`<td><b>${esc(c)}</b></td>`).join("")}</tr>`).join("")}</table></div>`;
if(b.k==="fc")return`<h3>${esc(b.title)}</h3><div id="fcw"></div>`;return""}
function qzH(l,si){const qs=l.steps[si].qz;if(!qs||!qs.length)return"";
return`<h3>🧠 خودسنجی <small id="sc${si}" style="color:var(--mut)"></small></h3>${qs.map((q,qi)=>{const k=l.id+"."+si+"."+qi,a=QA[k];return`<div class="box qz" data-k="${k}" data-si="${si}" data-qi="${qi}"><small>سؤال ${fd(qi+1)} از ${fd(qs.length)}</small><p><b>${esc(q.q)}</b></p>${q.o.map((o,oi)=>`<button class="qo${a!==undefined?(oi===q.a?" ok":oi===a?" bad":""):""}" data-o="${oi}"${a!==undefined?" disabled":""}>${esc(o)}</button>`).join("")}<div class="qe"${a===undefined?" hidden":""}>${a!==undefined?(a===q.a?"✅ درست؛ ":"❌ نادرست؛ ")+esc(q.e):""}</div></div>`}).join("")}`}
function lessonV2(id){const l=Object.assign({id:id},LV2[id]),m=LIST.find(x=>x.id===id);if(!m)return home();
const i=READY.findIndex(x=>x.id===id);STEP=0;FCI=0;FCB=false;
const sd=()=>stDone(id);
const draw=()=>{const d=sd();$("stp").innerHTML=l.steps.map((s,k)=>`<button class="stp${k===STEP?" on":""}" data-s="${k}"><span>${d.includes(k)?"✅":s.ic}</span>${fd(k+1)}. ${esc(s.t)}</button>`).join("");
const s=l.steps[STEP];
$("sb").innerHTML=s.bl.map(blkH).join("")+qzH(l,STEP)+(STEP===l.steps.length-1&&l.warn?`<div class="box warnb"><b>⚠️</b> ${esc(l.warn)}</div>`:"")+`<div class="tools"><button class="pill${d.includes(STEP)?" on":""}" id="sdn">${d.includes(STEP)?"✅ این گام تمام شد":"☐ این گام را تمام کردم"}</button>${STEP<l.steps.length-1?`<button class="pill" id="snx">گام بعدی ‹</button>`:""}</div>`;
scoreUp();fcDraw();
app.querySelectorAll(".stp").forEach(b=>b.onclick=()=>{STEP=+b.dataset.s;draw();$("stp").scrollIntoView({behavior:"smooth",block:"start"})});
$("sdn").onclick=()=>{const c=sd();st("ds_steps_"+id,c.includes(STEP)?c.filter(x=>x!==STEP):[...c,STEP]);const all=sd().length===l.steps.length,dn=done();st("ds_les_done",all?[...new Set([...dn,id])]:dn.filter(x=>x!==id));draw()};
if($("snx"))$("snx").onclick=()=>{STEP++;draw();$("stp").scrollIntoView({behavior:"smooth",block:"start"})};
app.querySelectorAll(".qz .qo").forEach(b=>b.onclick=()=>{const bx=b.closest(".qz"),q=l.steps[+bx.dataset.si].qz[+bx.dataset.qi],o=+b.dataset.o;if(QA[bx.dataset.k]!==undefined)return;QA[bx.dataset.k]=o;
bx.querySelectorAll(".qo").forEach((x,k)=>{x.disabled=true;if(k===q.a)x.classList.add("ok");else if(k===o)x.classList.add("bad")});const e=bx.querySelector(".qe");e.hidden=false;e.textContent=(o===q.a?"✅ درست؛ ":"❌ نادرست؛ ")+q.e;scoreUp()})};
const scoreUp=()=>{const qs=l.steps[STEP].qz||[];const el=$("sc"+STEP);if(!el)return;const ans=qs.filter((q,k)=>QA[id+"."+STEP+"."+k]!==undefined).length,ok=qs.filter((q,k)=>QA[id+"."+STEP+"."+k]===q.a).length;el.textContent=ans?`(${fd(ok)} درست از ${fd(ans)} پاسخ‌داده‌شده)`:""};
const fcDraw=()=>{const w=$("fcw");if(!w)return;const c=l.fc[FCI];w.innerHTML=`<div class="fcd${FCB?" bk":""}" id="fcd" role="button" tabindex="0"><small>کارت ${fd(FCI+1)} از ${fd(l.fc.length)}</small><p>${esc(FCB?c[1]:c[0])}</p><small>${FCB?"پاسخ":"برای دیدن پاسخ بزنید"}</small></div><div class="tools"><button class="pill" id="fpv2">› قبلی</button><button class="pill" id="fnx2">بعدی ‹</button></div>`;
$("fcd").onclick=()=>{FCB=!FCB;fcDraw()};$("fnx2").onclick=()=>{FCI=(FCI+1)%l.fc.length;FCB=false;fcDraw()};$("fpv2").onclick=()=>{FCI=(FCI-1+l.fc.length)%l.fc.length;FCB=false;fcDraw()}};
app.innerHTML=`<div class="nav"><button class="back" id="hb">‹ فهرست درس‌ها</button></div><header class="ph">${ROS}<h1 class="grad" style="font-size:clamp(22px,2.9vw,38px)">درس ${fd(LIST.findIndex(x=>x.id===id)+1)}: ${esc(m.t)}</h1><div class="crumb">${esc(m.g)}</div></header>
<div class="box key"><b>⏱ کارت ۱ دقیقه‌ای</b><ul style="padding-right:22px">${l.key.map(x=>`<li>${esc(x)}</li>`).join("")}</ul><div class="nums">${l.nums.map(n=>`<span><b>${esc(n[0])}</b><small>${esc(n[1])}</small></span>`).join("")}</div></div>
<div class="stps" id="stp"></div><div id="sb"></div><div class="tools">${i>0?`<a class="pill" href="#t${READY[i-1].id}">› درس قبل</a>`:""}${i<READY.length-1?`<a class="pill" href="#t${READY[i+1].id}">درس بعد ‹</a>`:""}</div>${foot()}`;
$("hb").onclick=()=>go("");draw()}
function route(){const h=decodeURIComponent(location.hash.slice(1));let m;if(m=h.match(/^t(\w+)$/))lesson(m[1]);else home();scrollTo(0,0)}
function go(h){if(location.hash.slice(1)===h)route();else location.hash=h}
window.addEventListener("hashchange",route);route();
