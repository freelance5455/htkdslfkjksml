/* ============================================================
   ads.js — پل بین صفحه HTML و SDK بومی Adivery (داخل اپ Flutter)
   ------------------------------------------------------------
   - SDK واقعی Adivery در کد Dart (lib/main.dart) اجرا می‌شود.
   - این فایل فقط درخواست نمایش تبلیغ را به کانال «AdBridge» می‌فرستد
     و نتیجه را از Dart دریافت می‌کند.
   - اگر صفحه خارج از اپ (مرورگر) باز شود، پل وجود ندارد و برنامه
     طبق onUnavailable رفتار می‌کند (پیش‌فرض: کپی مستقیم).
   ============================================================ */
(function (global) {
  "use strict";

  var CONFIG = {
    provider: "native",       // ارائه‌دهنده فعال
    requestTimeoutMs: 8000,   // حداکثر انتظار برای آماده‌سازی
    showTimeoutMs: 75000,     // حداکثر انتظار برای پایان تبلیغ
    onUnavailable: "copy",    // تبلیغ نبود/خطا: "copy" یا "block"
    onEarlyClose: "block"     // کاربر زود بست: "copy" یا "block" (block = بدون پاداش کپی نمی‌شود)
  };

  var registry = {};
  var busy = false;
  var pending = null;

  function withTimeout(promise, ms, label) {
    return new Promise(function (resolve, reject) {
      var t = setTimeout(function () { reject(new Error(label || "timeout")); }, ms);
      promise.then(function (v) { clearTimeout(t); resolve(v); },
                   function (e) { clearTimeout(t); reject(e); });
    });
  }

  function hasBridge() {
    return !!(global.AdBridge && typeof global.AdBridge.postMessage === "function");
  }

  /* ---------- ارائه‌دهنده بومی (Adivery داخل اپ Flutter) ---------- */
  registry.native = {
    init: function () {
      return hasBridge() ? Promise.resolve() : Promise.reject(new Error("no-bridge"));
    },
    isReady: function () { return hasBridge(); },
    show: function () {
      return new Promise(function (resolve, reject) {
        if (pending) { reject(new Error("busy")); return; }
        var entry = { resolve: resolve, reject: reject };
        pending = entry;
        setTimeout(function () {
          if (pending === entry) { pending = null; reject(new Error("timeout")); }
        }, CONFIG.showTimeoutMs);
        try {
          global.AdBridge.postMessage(JSON.stringify({ type: "showRewarded" }));
        } catch (e) {
          pending = null;
          reject(e);
        }
      });
    }
  };

  var PromptAds = {
    configure: function (partial) {
      if (!partial) return;
      Object.keys(partial).forEach(function (k) { CONFIG[k] = partial[k]; });
    },

    /** ثبت شبکه جدید: { init(), isReady(), show() → Promise<{completed}> } */
    registerProvider: function (name, impl) { registry[name] = impl; },

    init: function () {
      var p = registry[CONFIG.provider];
      if (!p) return Promise.resolve(false);
      return withTimeout(Promise.resolve(p.init()), CONFIG.requestTimeoutMs, "init-timeout")
        .then(function () { return true; }, function () { return false; });
    },

    isReady: function () {
      var p = registry[CONFIG.provider];
      return !!(p && p.isReady && p.isReady());
    },

    /** همیشه resolve می‌شود: completed | dismissed | unavailable | error | busy */
    showAd: function () {
      if (busy) return Promise.resolve({ status: "busy" });
      var p = registry[CONFIG.provider];
      if (!p) return Promise.resolve({ status: "unavailable" });

      busy = true;
      return PromptAds.init().then(function (ok) {
        if (!ok || !p.isReady()) return { status: "unavailable" };
        return Promise.resolve(p.show()).then(function (r) {
          return { status: r && r.completed ? "completed" : "dismissed" };
        });
      }).catch(function () {
        return { status: "error" };
      }).then(function (result) {
        busy = false;
        return result;
      });
    },

    shouldCopy: function (result) {
      var s = result && result.status;
      if (s === "completed") return true;
      if (s === "busy") return false;
      if (s === "dismissed") return CONFIG.onEarlyClose !== "block";
      return CONFIG.onUnavailable !== "block";
    },

    /** فقط توسط کد Dart صدا زده می‌شود */
    _nativeResult: function (status) {
      var p = pending;
      pending = null;
      if (!p) return;
      if (status === "completed") p.resolve({ completed: true });
      else if (status === "dismissed") p.resolve({ completed: false });
      else p.reject(new Error(String(status)));
    }
  };

  global.PromptAds = PromptAds;
})(window);
