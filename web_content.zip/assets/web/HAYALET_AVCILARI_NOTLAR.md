# Hayalet Avcıları modu

- Ana menü > Tüm Oyunlar bölümünden açılır.
- Android dokunmatik joystick, zıplama ve ETKİLE düğmesiyle oynanır.
- Fener oyuncuyla birlikte aydınlatma sağlar.
- Üç ipucunu bul, paranormal olay uyarılarına dikkat et ve yeşil çıkışa ulaş.
- Hayalet yaklaşınca uzaklaş; yakalanırsan güvenli noktaya dönersin.

Bu paket web oyun dosyasıdır, APK değildir. Çevrimiçi arkadaşlarla birlikte oynama, mevcut sunucu yapılandırmasına bağlıdır. Gerçek cihazda test edilmemiştir.
