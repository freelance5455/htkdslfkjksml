# Kayıp Şehir — Kabusun Başlangıcı

- Ana menüye ayrı oyun kartı eklendi.
- Bölüm 1'de şehir, hastane, metro ve yeraltı tesisi alanları bulunur.
- Üç güç hücresi toplanır, üç elektrik panosu etkinleştirilir ve çıkışa ulaşılır.
- Gölge yaratık oyuncuyu takip eder; turkuaz dolap / konteyner noktalarında saklanılabilir.
- Bölüm 2 şu anda kilitlidir.
- Düşük poligonlu Three.js geometri kullanıldı; harici model dosyaları eklenmedi.
