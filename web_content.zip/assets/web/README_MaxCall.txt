MAX CALL — HD kamera ko‘rish rejimi

Fayllar:
- index.html: zamonaviy interfeys va kamera oldindan ko‘rish rejimi.

Kamera sifati:
- 2K (2560×1440) so‘rovi, Full HD (1920×1080) va HD (1280×720) tanlovi mavjud.
- Qurilma/brauzer ruxsat bermasa, HD rejimiga avtomatik qaytadi.
- Haqiqiy olinadigan aniqlik kameraga, qurilmaga, WebView/brauzerga va ruxsatlarga bog‘liq.
- Kamera ishlashi uchun HTTPS yoki kamera ruxsati to‘g‘ri sozlangan Android WebView kerak bo‘lishi mumkin.

Muhim:
- Bu yangilanish kamera oldindan ko‘rish funksiyasini qo‘shadi; boshqa foydalanuvchiga haqiqiy internet video qo‘ng‘irog‘i hali ishlamaydi. Buning uchun WebRTC/ZEGOCLOUD signalizatsiyasi va server sozlamalari kerak.
- Tayyor APK qayta yig‘ilmadi yoki imzolanmadi.


Refreshed icon edition: modern inline SVG icons for calling, contacts, video, microphone, camera, and camera switching. Existing button handlers were kept unchanged.


Additional refreshed icons: Bosh sahifa (home), Sozlamalar (settings), and Tarix (history). Existing navigation actions and page logic were preserved.
