# AI TOX — تطبيق أندرويد (APK)

## الطريقة 1: على جهازك (Android Studio)
المتطلبات: Node.js 18+ و JDK 17 و Android Studio (يثبّت Android SDK).

```
npm install
npx cap add android      # مرة واحدة فقط
npm run apk:debug
```
الملف الناتج: `android/app/build/outputs/apk/debug/app-debug.apk`
(انقله إلى الموبايل وثبّته، وفعّل «التثبيت من مصادر غير معروفة»).

## الطريقة 2: بدون Android Studio (GitHub Actions)
1. ارفع هذا المجلد إلى مستودع GitHub.
2. من تبويب Actions شغّل «Build AI TOX APK».
3. نزّل `app-debug.apk` من Artifacts.

## ما الذي تغيّر في الصفحة؟
- التقرير (PDF والمعاينة داخل الصفحة): عرض ثابت بحجم A4، الجداول `table-layout: fixed`، والنصوص تلتف داخل الخلايا، والصور بعرض 100% — لا شيء يخرج عن حدود الصفحة.
- أُزيل زر «Open Standalone in Google Chrome» وزر «Load 5-Fold Example Dataset».
- زر PDF الأحمر يفتح التقرير كاملاً داخل الصفحة أولاً، ثم زر «Save / Share PDF» لحفظ الملف أو مشاركته.
- كل المكتبات والخطوط محلية، فالتطبيق يعمل بدون إنترنت. (خط STIX Two Math غير مضمّن؛ تُستخدم Cambria Math / Times New Roman بدلاً منه.)

- أُزيل الدومين من كل مكان في الصفحة والتقرير.
- حفظ PDF: «Save / Share PDF» أولاً، وإن لم يعمل على جهازك فزر «Print / Save as PDF» (طباعة الصفحة إلى PDF) أو اقرأ التقرير داخل الصفحة.

## للنشر على Google Play
APK التجريبي (debug) للتجربة فقط. للنشر تحتاج AAB موقّعاً بمفتاحك: `./gradlew bundleRelease` ثم توقيعه.

## تقرير Excel علمي (جديد)
- زر **Excel Report** (أخضر في الشريط العلوي) وزر **Excel Report (.xlsx)** بجانب زر التقرير العلمي — يعملان مع مركّب واحد أو أي عدد من المركبات.
- الملف الناتج (`AI_TOX_Scientific_Report_<الاسم>.xlsx`) يحتوي على 6 شيتات:
  `Report` (تقرير كامل بأسلوب Springer: Abstract / Methods / Results / Conclusions / References + Table 1 و Table 2 بنظام الخطوط الثلاثة + الأشكال)،
  `Table S1 LC values`، `Table S2 Dose-response`، `Table S3 Comparisons`، `Chart data`، `Equations`.
- الأشكال رسومات Excel أصلية قابلة للتعديل: أعمدة LC50 مع حدود الثقة وحروف الفروق المعنوية، أعمدة مستويات LC10–LC90، أعمدة الكفاءة النسبية (fold)، خطوط السمية (probit lines)، وأعمدة الموت المصحح مع منحنى probit المتوقع لكل مركّب.
- الكود مستقل تماماً (بدون مكتبات خارجية) ويعمل أوفلاين: `src/xlsx-report.js` (مولّد xlsx) + `src/excel-glue.js` (ربط التطبيق) + `src/patch_excel.py` (يضيف كل شيء إلى `patched.html`، ويُستدعى تلقائياً من آخر `patch.py`).
- لتحديث الـ APK: نفس الخطوات أعلاه (`npm run apk:debug` أو GitHub Actions) — `patched.html` المحدّث جاهز.
