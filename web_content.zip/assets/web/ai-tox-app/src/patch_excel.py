# Adds the "Excel Report" feature (xlsx-report.js + glue + buttons) to src/patched.html.
# Run from the project root:  python3 src/patch_excel.py      (idempotent)
import re
s = open('src/patched.html', encoding='utf-8').read()
if 'AITOX_XLSX' in s:
    print('excel feature already present'); raise SystemExit
lib = open('src/xlsx-report.js', encoding='utf-8').read()
glue = open('src/excel-glue.js', encoding='utf-8').read()
assert '</script>' not in lib and '</script>' not in glue

def rep(old, new, count=1):
    global s
    assert s.count(old) >= 1, 'missing: ' + old[:80]
    s = s.replace(old, new, count)

# 1) library (own <script>, loaded before the main script)
marker = '<script>\n\n    const APP_STATE = {'
assert s.count(marker) == 1, 'main script marker'
s = s.replace(marker, '<script>\n' + lib + '\n  </script>\n  ' + marker)

# 2) glue (inside the main script, right before the PDF export section)
rep('    // =========================================================================\n\n    // EXPORT PUBLICATION-READY SCIENTIFIC PDF REPORT (.PDF)',
    glue + '\n    // =========================================================================\n\n    // EXPORT PUBLICATION-READY SCIENTIFIC PDF REPORT (.PDF)')

# 3) buttons
icon = '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 10h18M3 15h18M9 4v16"/></svg>'
rep('<button id="clearAllInputsBtn" type="button" class="btn-ghost">Clear</button>',
    '<button id="exportXlsxBtnTop" type="button" class="btn-primary" style="background:#16a34a;color:#fff">' + icon + '<span>Excel Report</span></button>\n        <button id="clearAllInputsBtn" type="button" class="btn-ghost">Clear</button>')
rep('<button id="exportPdfBtnMain" type="button"',
    '<button id="exportXlsxBtnMain" type="button" class="bg-emerald-700 hover:bg-emerald-600 text-white font-extrabold px-4 py-1.5 rounded-lg text-xs shadow transition">\n                Excel Report (.xlsx)\n              </button>\n\n              <button id="exportPdfBtnMain" type="button"')

# 4) listeners
rep("document.getElementById('exportPdfBtnMain').addEventListener('click', exportScientificPdfReport);",
    "document.getElementById('exportPdfBtnMain').addEventListener('click', exportScientificPdfReport);\n      document.getElementById('exportXlsxBtnTop').addEventListener('click', exportExcelReport);\n      document.getElementById('exportXlsxBtnMain').addEventListener('click', exportExcelReport);")
open('src/patched.html', 'w', encoding='utf-8').write(s)
print('excel feature added', len(s))
