/* AI TOX — Excel scientific report builder (no external libraries, works offline).
 * Produces a real .xlsx (OOXML) with Springer-style three-line tables, native editable charts
 * (columns + error bars, toxicity/probit lines, combo columns+curve) and an auto-written report.
 * Public API:  AITOX_XLSX.build(data) -> Uint8Array   (data schema is documented in buildExcelReportData()).
 */
(function (root) {
  'use strict';

  // ======================= ZIP (stored, no compression) =======================
  const CRC_T = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
  function crc32(b) { let c = 0xFFFFFFFF; for (let i = 0; i < b.length; i++) c = CRC_T[(c ^ b[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; }
  const ENC = new TextEncoder();
  function zip(files) {
    const chunks = [], central = []; let off = 0;
    const DT = 0x0021, DD = ((2026 - 1980) << 9) | (1 << 5) | 1;
    files.forEach(f => {
      const nb = ENC.encode(f.name), db = typeof f.data === 'string' ? ENC.encode(f.data) : f.data, crc = crc32(db);
      const lh = new DataView(new ArrayBuffer(30));
      lh.setUint32(0, 0x04034b50, true); lh.setUint16(4, 20, true); lh.setUint16(6, 0x0800, true); lh.setUint16(8, 0, true);
      lh.setUint16(10, DT, true); lh.setUint16(12, DD, true); lh.setUint32(14, crc, true);
      lh.setUint32(18, db.length, true); lh.setUint32(22, db.length, true); lh.setUint16(26, nb.length, true); lh.setUint16(28, 0, true);
      chunks.push(new Uint8Array(lh.buffer), nb, db);
      const ch = new DataView(new ArrayBuffer(46));
      ch.setUint32(0, 0x02014b50, true); ch.setUint16(4, 20, true); ch.setUint16(6, 20, true); ch.setUint16(8, 0x0800, true); ch.setUint16(10, 0, true);
      ch.setUint16(12, DT, true); ch.setUint16(14, DD, true); ch.setUint32(16, crc, true);
      ch.setUint32(20, db.length, true); ch.setUint32(24, db.length, true); ch.setUint16(28, nb.length, true);
      ch.setUint32(42, off, true);
      central.push(new Uint8Array(ch.buffer), nb);
      off += 30 + nb.length + db.length;
    });
    let csize = 0; central.forEach(c => csize += c.length);
    const end = new DataView(new ArrayBuffer(22));
    end.setUint32(0, 0x06054b50, true); end.setUint16(8, files.length, true); end.setUint16(10, files.length, true);
    end.setUint32(12, csize, true); end.setUint32(16, off, true);
    const all = chunks.concat(central, [new Uint8Array(end.buffer)]);
    let total = 0; all.forEach(c => total += c.length);
    const out = new Uint8Array(total); let p = 0; all.forEach(c => { out.set(c, p); p += c.length; });
    return out;
  }

  // ======================= helpers =======================
  const esc = s => String(s).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const colL = n => { let s = ''; while (n > 0) { const m = (n - 1) % 26; s = String.fromCharCode(65 + m) + s; n = Math.floor((n - 1) / 26); } return s; };
  const A1 = (r, c) => colL(c) + r;
  const ABS = (r, c) => '$' + colL(c) + '$' + r;
  const fin = v => typeof v === 'number' && isFinite(v);
  const FONT = 'Times New Roman';
  const SUB = { '0': '₀', '1': '₁', '2': '₂', '3': '₃', '4': '₄', '5': '₅', '6': '₆', '7': '₇', '8': '₈', '9': '₉' };

  // mini markup: _{sub}  ^{sup}  ~italic~   -> runs
  function parseMarkup(str) {
    str = String(str);
    if (!/[_^]\{|~/.test(str)) return null;
    const runs = []; let i = 0, buf = '', ital = false;
    const flush = () => { if (buf) { runs.push({ t: buf, i: ital }); buf = ''; } };
    while (i < str.length) {
      const ch = str[i];
      if ((ch === '_' || ch === '^') && str[i + 1] === '{') {
        const j = str.indexOf('}', i + 2);
        if (j > 0) { flush(); runs.push({ t: str.slice(i + 2, j), i: ital, sub: ch === '_', sup: ch === '^' }); i = j + 1; continue; }
      }
      if (ch === '~') { flush(); ital = !ital; i++; continue; }
      buf += ch; i++;
    }
    flush();
    return runs;
  }
  const plain = s => String(s).replace(/_\{([^}]*)\}/g, (m, x) => x.replace(/[0-9]/g, d => SUB[d])).replace(/\^\{([^}]*)\}/g, (m, x) => x === '2' ? '²' : x === '3' ? '³' : x).replace(/~/g, '');

  // ======================= styles =======================
  function Styles() {
    const fonts = [], fills = ['<fill><patternFill patternType="none"/></fill>', '<fill><patternFill patternType="gray125"/></fill>'], borders = [], fmts = [], xfs = [], specs = [], memo = {};
    const idx = (arr, x) => { let i = arr.indexOf(x); if (i < 0) { arr.push(x); i = arr.length - 1; } return i; };
    const fontXml = s => '<font>' + (s.b ? '<b/>' : '') + (s.i ? '<i/>' : '') + '<sz val="' + (s.sz || 10) + '"/><color rgb="FF' + (s.color || '000000') + '"/><name val="' + FONT + '"/><family val="1"/></font>';
    const bd = (side, st, col) => st ? '<' + side + ' style="' + st + '"><color rgb="FF' + (col || '000000') + '"/></' + side + '>' : '<' + side + '/>';
    function get(s) {
      s = s || {};
      const key = JSON.stringify(s); if (memo[key] != null) return memo[key];
      const f = idx(fonts, fontXml(s));
      const fl = s.fill ? idx(fills, '<fill><patternFill patternType="solid"><fgColor rgb="FF' + s.fill + '"/><bgColor indexed="64"/></patternFill></fill>') : 0;
      const b = idx(borders, '<border>' + bd('left', s.bL, s.bc) + bd('right', s.bR, s.bc) + bd('top', s.bT, s.bc) + bd('bottom', s.bB, s.bc) + '<diagonal/></border>');
      let nf = 0; if (s.fmt && s.fmt !== 'General') nf = 164 + idx(fmts, s.fmt);
      const al = '<alignment' + (s.h ? ' horizontal="' + s.h + '"' : '') + ' vertical="' + (s.v || 'center') + '"' + (s.wrap ? ' wrapText="1"' : '') + (s.indent ? ' indent="' + s.indent + '"' : '') + '/>';
      xfs.push('<xf numFmtId="' + nf + '" fontId="' + f + '" fillId="' + fl + '" borderId="' + b + '" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">' + al + '</xf>');
      specs.push(s); memo[key] = xfs.length - 1; return xfs.length - 1;
    }
    get({}); // xf 0
    // make sure border[0] is the empty border (get({}) created it first)
    function xml() {
      return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">' +
        (fmts.length ? '<numFmts count="' + fmts.length + '">' + fmts.map((f, i) => '<numFmt numFmtId="' + (164 + i) + '" formatCode="' + esc(f) + '"/>').join('') + '</numFmts>' : '') +
        '<fonts count="' + fonts.length + '">' + fonts.join('') + '</fonts><fills count="' + fills.length + '">' + fills.join('') + '</fills><borders count="' + borders.length + '">' + borders.join('') + '</borders>' +
        '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="' + xfs.length + '">' + xfs.join('') + '</cellXfs>' +
        '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>';
    }
    return { get, xml, spec: id => specs[id] };
  }

  // ======================= sheet =======================
  function Sheet(name, styles, opts) {
    opts = opts || {};
    const cells = new Map(), rowH = {}, colW = {}, merges = [], charts = [], breaks = [];
    const sh = { name, charts, tab: opts.tab, landscape: opts.landscape !== false, freeze: opts.freeze || null, selected: !!opts.selected, maxR: 0, maxC: 0 };
    function put(r, c, val, spec) { cells.set(r + ',' + c, { r, c, val, sid: styles.get(spec), spec: spec || {} }); if (r > sh.maxR) sh.maxR = r; if (c > sh.maxC) sh.maxC = c; }
    sh.set = put;
    sh.merge = (r1, c1, r2, c2, val, spec) => {
      for (let r = r1; r <= r2; r++) for (let c = c1; c <= c2; c++) put(r, c, (r === r1 && c === c1) ? val : null, spec);
      if (r1 !== r2 || c1 !== c2) merges.push(A1(r1, c1) + ':' + A1(r2, c2));
    };
    sh.height = (r, h) => { rowH[r] = h; };
    sh.heightOf = r => rowH[r] || 14.25;
    sh.breakAfter = r => { if (breaks.indexOf(r) < 0) breaks.push(r); };
    sh.width = (c, w) => { colW[c] = w; };
    sh.colWidth = c => colW[c] || 9;
    sh.addChart = (xml, r1, c1, r2, c2) => charts.push({ xml, r1, c1, r2, c2 });
    function cellXml(x) {
      const ref = A1(x.r, x.c), v = x.val, s = ' s="' + x.sid + '"';
      if (v === null || v === undefined || v === '') return '<c r="' + ref + '"' + s + '/>';
      if (typeof v === 'number') return fin(v) ? '<c r="' + ref + '"' + s + '><v>' + v + '</v></c>' : '<c r="' + ref + '"' + s + ' t="inlineStr"><is><t>–</t></is></c>';
      if (typeof v === 'object' && v.f !== undefined) {
        const cv = v.v;
        if (typeof cv === 'string') return '<c r="' + ref + '"' + s + ' t="str"><f>' + esc(v.f) + '</f><v>' + esc(cv) + '</v></c>';
        return '<c r="' + ref + '"' + s + '><f>' + esc(v.f) + '</f>' + (fin(cv) ? '<v>' + cv + '</v>' : '') + '</c>';
      }
      const str = String(v), runs = parseMarkup(str);
      if (!runs) return '<c r="' + ref + '"' + s + ' t="inlineStr"><is><t xml:space="preserve">' + esc(str) + '</t></is></c>';
      const sp = x.spec;
      return '<c r="' + ref + '"' + s + ' t="inlineStr"><is>' + runs.map(r => '<r><rPr>' + (sp.b ? '<b/>' : '') + ((sp.i || r.i) ? '<i/>' : '') + (r.sub ? '<vertAlign val="subscript"/>' : '') + (r.sup ? '<vertAlign val="superscript"/>' : '') +
        '<sz val="' + (sp.sz || 10) + '"/><color rgb="FF' + (sp.color || '000000') + '"/><rFont val="' + FONT + '"/><family val="1"/></rPr><t xml:space="preserve">' + esc(r.t) + '</t></r>').join('') + '</is></c>';
    }
    sh.xml = function (hasDrawing) {
      const rows = {}; cells.forEach(x => { (rows[x.r] = rows[x.r] || []).push(x); });
      Object.keys(rowH).forEach(k => { if (!rows[k]) rows[k] = []; });
      const rnums = Object.keys(rows).map(Number).sort((a, b) => a - b);
      let sd = '';
      rnums.forEach(r => {
        const h = rowH[r];
        sd += '<row r="' + r + '"' + (h ? ' ht="' + h + '" customHeight="1"' : '') + '>' + rows[r].sort((a, b) => a.c - b.c).map(cellXml).join('') + '</row>';
      });
      const cw = Object.keys(colW).map(Number).sort((a, b) => a - b);
      const pane = sh.freeze ? '<pane ' + (sh.freeze.c > 1 ? 'xSplit="' + (sh.freeze.c - 1) + '" ' : '') + (sh.freeze.r > 1 ? 'ySplit="' + (sh.freeze.r - 1) + '" ' : '') + 'topLeftCell="' + A1(sh.freeze.r, sh.freeze.c) + '" activePane="' + (sh.freeze.r > 1 && sh.freeze.c > 1 ? 'bottomRight' : (sh.freeze.r > 1 ? 'bottomLeft' : 'topRight')) + '" state="frozen"/>' : '';
      return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">' +
        '<sheetPr>' + (sh.tab ? '<tabColor rgb="FF' + sh.tab + '"/>' : '') + '<pageSetUpPr fitToPage="1"/></sheetPr>' +
        '<dimension ref="A1:' + A1(Math.max(1, sh.maxR), Math.max(1, sh.maxC)) + '"/>' +
        '<sheetViews><sheetView showGridLines="0" ' + (sh.selected ? 'tabSelected="1" ' : '') + 'workbookViewId="0">' + pane + '</sheetView></sheetViews>' +
        '<sheetFormatPr defaultRowHeight="14.25"/>' +
        (cw.length ? '<cols>' + cw.map(c => '<col min="' + c + '" max="' + c + '" width="' + colW[c] + '" customWidth="1"/>').join('') + '</cols>' : '') +
        '<sheetData>' + sd + '</sheetData>' +
        (merges.length ? '<mergeCells count="' + merges.length + '">' + merges.map(m => '<mergeCell ref="' + m + '"/>').join('') + '</mergeCells>' : '') +
        '<pageMargins left="0.5" right="0.5" top="0.6" bottom="0.6" header="0.3" footer="0.3"/>' +
        '<pageSetup paperSize="9" orientation="' + (sh.landscape ? 'landscape' : 'portrait') + '" fitToWidth="1" fitToHeight="0"/>' +
        '<headerFooter><oddFooter>&amp;L&amp;8AI TOX — Scientific report&amp;R&amp;8Page &amp;P of &amp;N</oddFooter></headerFooter>' +
        (breaks.length ? '<rowBreaks count="' + breaks.length + '" manualBreakCount="' + breaks.length + '">' + breaks.sort((a, b) => a - b).map(b => '<brk id="' + b + '" max="16383" man="1"/>').join('') + '</rowBreaks>' : '') +
        (hasDrawing ? '<drawing r:id="rId1"/>' : '') + '</worksheet>';
    };
    return sh;
  }

  // ======================= charts (native DrawingML) =======================
  const NS_C = 'xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"';
  const hex = c => String(c || '#000000').replace('#', '').toUpperCase();
  const fillX = c => '<a:solidFill><a:srgbClr val="' + hex(c) + '"/></a:solidFill>';
  const lnX = (c, w, dash) => '<a:ln w="' + (w || 9525) + '">' + (c ? fillX(c) : '<a:noFill/>') + (dash ? '<a:prstDash val="' + dash + '"/>' : '') + '</a:ln>';
  const rpr = (sz, b) => '<a:defRPr sz="' + (sz * 100) + '" b="' + (b ? 1 : 0) + '">' + fillX('000000') + '<a:latin typeface="' + FONT + '"/><a:cs typeface="' + FONT + '"/></a:defRPr>';
  const txPr = (sz, b, rot) => '<c:txPr><a:bodyPr' + (rot != null ? ' rot="' + rot + '" vert="horz"' : '') + '/><a:lstStyle/><a:p><a:pPr>' + rpr(sz, b) + '</a:pPr><a:endParaRPr lang="en-US"/></a:p></c:txPr>';
  const cTitle = (t, rot) => '<c:title><c:tx><c:rich><a:bodyPr' + (rot != null ? ' rot="' + rot + '" vert="horz"' : '') + '/><a:lstStyle/><a:p><a:pPr>' + rpr(10, true) + '</a:pPr><a:r><a:rPr lang="en-US" sz="1000" b="1">' + fillX('000000') + '<a:latin typeface="' + FONT + '"/><a:cs typeface="' + FONT + '"/></a:rPr><a:t>' + esc(plain(t)) + '</a:t></a:r></a:p></c:rich></c:tx><c:overlay val="0"/></c:title>';
  const numRef = (ref, vals, fmt) => '<c:numRef><c:f>' + esc(ref) + '</c:f><c:numCache><c:formatCode>' + esc(fmt || 'General') + '</c:formatCode><c:ptCount val="' + vals.length + '"/>' + vals.map((v, i) => fin(v) ? '<c:pt idx="' + i + '"><c:v>' + v + '</c:v></c:pt>' : '').join('') + '</c:numCache></c:numRef>';
  const strRef = (ref, vals) => '<c:strRef><c:f>' + esc(ref) + '</c:f><c:strCache><c:ptCount val="' + vals.length + '"/>' + vals.map((v, i) => '<c:pt idx="' + i + '"><c:v>' + esc(plain(v)) + '</c:v></c:pt>').join('') + '</c:strCache></c:strRef>';
  const serTx = n => n.ref ? '<c:tx>' + strRef(n.ref, [n.v]) + '</c:tx>' : '<c:tx><c:v>' + esc(plain(n.v)) + '</c:v></c:tx>';
  const errBars = (e, col) => '<c:errBars><c:errBarType val="both"/><c:errValType val="cust"/><c:noEndCap val="0"/><c:plus>' + numRef(e.plus.ref, e.plus.vals) + '</c:plus><c:minus>' + numRef(e.minus.ref, e.minus.vals) + '</c:minus><c:spPr>' + lnX('000000', 12700) + '</c:spPr></c:errBars>';
  const flags = (val) => '<c:showLegendKey val="0"/><c:showVal val="' + (val ? 1 : 0) + '"/><c:showCatName val="0"/><c:showSerName val="0"/><c:showPercent val="0"/><c:showBubbleSize val="0"/>';

  // series: {name:{ref,v}, cat:{ref,vals}, val:{ref,vals,fmt}, color, ptColors[], err:{plus,minus}, letters[] (labels), kind:'bar'|'line'|'scatter', x:{ref,vals}, marker, noLine, dash, w}
  function serXml(s, i, kind) {
    let x = '<c:ser><c:idx val="' + i + '"/><c:order val="' + i + '"/>' + serTx(s.name);
    if (kind === 'bar') {
      x += '<c:spPr>' + fillX(s.color) + lnX('000000', 6350) + '</c:spPr><c:invertIfNegative val="0"/>';
      (s.ptColors || []).forEach((pc, k) => { x += '<c:dPt><c:idx val="' + k + '"/><c:invertIfNegative val="0"/><c:bubble3D val="0"/><c:spPr>' + fillX(pc) + lnX('000000', 6350) + '</c:spPr></c:dPt>'; });
      if (s.showVal) x += '<c:dLbls><c:numFmt formatCode="' + esc(s.valFmt || '0.0') + '" sourceLinked="0"/><c:spPr><a:noFill/><a:ln><a:noFill/></a:ln></c:spPr>' + txPr(9, false) + '<c:dLblPos val="outEnd"/>' + flags(true) + '</c:dLbls>';
      if (s.err) x += errBars(s.err);
      x += '<c:cat>' + strRef(s.cat.ref, s.cat.vals) + '</c:cat><c:val>' + numRef(s.val.ref, s.val.vals, s.val.fmt) + '</c:val></c:ser>';
    } else if (kind === 'line') {
      x += '<c:spPr>' + (s.noLine ? lnX(null) : lnX(s.color, s.w || 25400, s.dash)) + '</c:spPr>';
      x += '<c:marker>' + (s.marker ? '<c:symbol val="' + s.marker + '"/><c:size val="7"/><c:spPr>' + fillX(s.color) + lnX('000000', 6350) + '</c:spPr>' : '<c:symbol val="none"/>') + '</c:marker>';
      if (s.letters) {
        x += '<c:dLbls>' + s.letters.map((t, k) => '<c:dLbl><c:idx val="' + k + '"/><c:tx><c:rich><a:bodyPr/><a:lstStyle/><a:p><a:r><a:rPr lang="en-US" sz="1100" b="1"><a:latin typeface="' + FONT + '"/></a:rPr><a:t>' + esc(t) + '</a:t></a:r></a:p></c:rich></c:tx><c:dLblPos val="t"/>' + flags(true) + '</c:dLbl>').join('') +
          '<c:spPr><a:noFill/><a:ln><a:noFill/></a:ln></c:spPr>' + txPr(11, true) + '<c:dLblPos val="t"/>' + flags(true) + '</c:dLbls>';
      }
      x += '<c:cat>' + strRef(s.cat.ref, s.cat.vals) + '</c:cat><c:val>' + numRef(s.val.ref, s.val.vals, s.val.fmt) + '</c:val><c:smooth val="0"/></c:ser>';
    } else { // scatter
      x += '<c:spPr>' + (s.noLine ? lnX(null) : lnX(s.color, s.w || 22225, s.dash)) + '</c:spPr>';
      x += '<c:marker>' + (s.marker ? '<c:symbol val="' + s.marker + '"/><c:size val="8"/><c:spPr>' + fillX(s.color) + lnX('000000', 6350) + '</c:spPr>' : '<c:symbol val="none"/>') + '</c:marker>';
      x += '<c:xVal>' + numRef(s.x.ref, s.x.vals) + '</c:xVal><c:yVal>' + numRef(s.val.ref, s.val.vals) + '</c:yVal><c:smooth val="0"/></c:ser>';
    }
    return x;
  }
  function axisCat(id, cross, title) {
    return '<c:catAx><c:axId val="' + id + '"/><c:scaling><c:orientation val="minMax"/></c:scaling><c:delete val="0"/><c:axPos val="b"/>' + (title ? cTitle(title) : '') +
      '<c:numFmt formatCode="General" sourceLinked="0"/><c:majorTickMark val="out"/><c:minorTickMark val="none"/><c:tickLblPos val="low"/><c:spPr>' + lnX('000000', 9525) + '</c:spPr>' + txPr(10, false) +
      '<c:crossAx val="' + cross + '"/><c:crosses val="autoZero"/><c:auto val="1"/><c:lblAlgn val="ctr"/><c:lblOffset val="100"/><c:noMultiLvlLbl val="0"/></c:catAx>';
  }
  function axisVal(id, cross, o) {
    o = o || {};
    return '<c:valAx><c:axId val="' + id + '"/><c:scaling><c:orientation val="minMax"/>' + (o.max != null ? '<c:max val="' + o.max + '"/>' : '') + (o.min != null ? '<c:min val="' + o.min + '"/>' : '') + '</c:scaling><c:delete val="0"/><c:axPos val="' + (o.pos || 'l') + '"/>' +
      (o.grid ? '<c:majorGridlines><c:spPr>' + lnX('D9D9D9', 6350) + '</c:spPr></c:majorGridlines>' : '') + (o.title ? cTitle(o.title, o.pos === 'b' ? null : -5400000) : '') +
      '<c:numFmt formatCode="' + esc(o.fmt || 'General') + '" sourceLinked="0"/><c:majorTickMark val="out"/><c:minorTickMark val="none"/><c:tickLblPos val="' + (o.lblPos || 'nextTo') + '"/><c:spPr>' + lnX('000000', 9525) + '</c:spPr>' + txPr(10, false) +
      '<c:crossAx val="' + cross + '"/><c:crosses val="' + (o.crosses || 'autoZero') + '"/><c:crossBetween val="' + (o.between || 'between') + '"/>' + (o.major ? '<c:majorUnit val="' + o.major + '"/>' : '') + '</c:valAx>';
  }
  // spec: {type:'bar'|'combo'|'scatter', bars:[ser], lines:[ser], scatter:[ser], xTitle,yTitle,yMin,yMax,legend:bool, legendHide:[idx], gap, xFmt,yFmt,xMin,xMax,major}
  function chartXml(sp) {
    let plot = '<c:layout/>', ax = '', i = 0;
    if (sp.type === 'scatter') {
      plot += '<c:scatterChart><c:scatterStyle val="lineMarker"/><c:varyColors val="0"/>' + sp.scatter.map(s => serXml(s, i++, 'scatter')).join('') + '<c:axId val="5001"/><c:axId val="5002"/></c:scatterChart>';
      ax = axisVal(5001, 5002, { pos: 'b', title: sp.xTitle, fmt: sp.xFmt || '0.0', min: sp.xMin, max: sp.xMax, between: 'midCat', lblPos: 'low' }) +
        axisVal(5002, 5001, { pos: 'l', title: sp.yTitle, fmt: sp.yFmt || '0', grid: true, min: sp.yMin, max: sp.yMax, between: 'midCat', crosses: 'min', major: sp.major });
    } else {
      plot += '<c:barChart><c:barDir val="col"/><c:grouping val="clustered"/><c:varyColors val="0"/>' + sp.bars.map(s => serXml(s, i++, 'bar')).join('') + '<c:gapWidth val="' + (sp.gap || 70) + '"/><c:overlap val="' + (sp.overlap != null ? sp.overlap : 0) + '"/><c:axId val="5001"/><c:axId val="5002"/></c:barChart>';
      if (sp.lines && sp.lines.length) plot += '<c:lineChart><c:grouping val="standard"/><c:varyColors val="0"/>' + sp.lines.map(s => serXml(s, i++, 'line')).join('') + '<c:marker val="1"/><c:axId val="5001"/><c:axId val="5002"/></c:lineChart>';
      ax = axisCat(5001, 5002, sp.xTitle) + axisVal(5002, 5001, { pos: 'l', title: sp.yTitle, fmt: sp.yFmt || '0', grid: true, min: sp.yMin != null ? sp.yMin : 0, max: sp.yMax, major: sp.major });
    }
    const legend = sp.legend ? '<c:legend><c:legendPos val="b"/>' + (sp.legendHide || []).map(k => '<c:legendEntry><c:idx val="' + k + '"/><c:delete val="1"/></c:legendEntry>').join('') + '<c:overlay val="0"/>' + txPr(10, false) + '</c:legend>' : '';
    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><c:chartSpace ' + NS_C + '><c:roundedCorners val="0"/><c:chart><c:autoTitleDeleted val="1"/><c:plotArea>' + plot + ax + '<c:spPr><a:noFill/><a:ln><a:noFill/></a:ln></c:spPr></c:plotArea>' + legend +
      '<c:plotVisOnly val="1"/><c:dispBlanksAs val="gap"/></c:chart><c:spPr>' + fillX('FFFFFF') + lnX('7F7F7F', 9525) + '</c:spPr>' + txPr(10, false) + '</c:chartSpace>';
  }

  // ======================= workbook packaging =======================
  function packageXlsx(sheets, styles, meta) {
    const files = []; let chartN = 0, drawN = 0;
    const ct = ['<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>',
      '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>',
      '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>',
      '<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>'];
    sheets.forEach((sh, k) => {
      const n = k + 1; ct.push('<Override PartName="/xl/worksheets/sheet' + n + '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>');
      const has = sh.charts.length > 0;
      files.push({ name: 'xl/worksheets/sheet' + n + '.xml', data: sh.xml(has) });
      if (has) {
        drawN++;
        files.push({ name: 'xl/worksheets/_rels/sheet' + n + '.xml.rels', data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing" Target="../drawings/drawing' + drawN + '.xml"/></Relationships>' });
        ct.push('<Override PartName="/xl/drawings/drawing' + drawN + '.xml" ContentType="application/vnd.openxmlformats-officedocument.drawing+xml"/>');
        let dx = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><xdr:wsDr xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">', rels = '';
        sh.charts.forEach((ch, j) => {
          chartN++;
          files.push({ name: 'xl/charts/chart' + chartN + '.xml', data: ch.xml });
          ct.push('<Override PartName="/xl/charts/chart' + chartN + '.xml" ContentType="application/vnd.openxmlformats-officedocument.drawingml.chart+xml"/>');
          rels += '<Relationship Id="rId' + (j + 1) + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/chart" Target="../charts/chart' + chartN + '.xml"/>';
          dx += '<xdr:twoCellAnchor editAs="oneCell"><xdr:from><xdr:col>' + (ch.c1 - 1) + '</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>' + (ch.r1 - 1) + '</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:from><xdr:to><xdr:col>' + (ch.c2) + '</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>' + (ch.r2) + '</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:to>' +
            '<xdr:graphicFrame macro=""><xdr:nvGraphicFramePr><xdr:cNvPr id="' + (j + 2) + '" name="Figure ' + chartN + '"/><xdr:cNvGraphicFramePr/></xdr:nvGraphicFramePr><xdr:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/></xdr:xfrm><a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/chart"><c:chart xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" r:id="rId' + (j + 1) + '"/></a:graphicData></a:graphic></xdr:graphicFrame><xdr:clientData/></xdr:twoCellAnchor>';
        });
        dx += '</xdr:wsDr>';
        files.push({ name: 'xl/drawings/drawing' + drawN + '.xml', data: dx });
        files.push({ name: 'xl/drawings/_rels/drawing' + drawN + '.xml.rels', data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' + rels + '</Relationships>' });
      }
    });
    files.push({ name: '[Content_Types].xml', data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>' + ct.join('') + '</Types>' });
    files.push({ name: '_rels/.rels', data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>' });
    const iso = new Date().toISOString().replace(/\.\d+Z$/, 'Z');
    files.push({ name: 'docProps/core.xml', data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>' + esc(meta.title) + '</dc:title><dc:creator>' + esc(meta.author) + '</dc:creator><dcterms:created xsi:type="dcterms:W3CDTF">' + iso + '</dcterms:created></cp:coreProperties>' });
    files.push({ name: 'docProps/app.xml', data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"><Application>AI TOX</Application></Properties>' });
    files.push({ name: 'xl/workbook.xml', data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView activeTab="0"/></bookViews><sheets>' + sheets.map((s, k) => '<sheet name="' + esc(s.name) + '" sheetId="' + (k + 1) + '" r:id="rId' + (k + 1) + '"/>').join('') + '</sheets><calcPr calcId="191029" fullCalcOnLoad="1"/></workbook>' });
    files.push({ name: 'xl/_rels/workbook.xml.rels', data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' + sheets.map((s, k) => '<Relationship Id="rId' + (k + 1) + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet' + (k + 1) + '.xml"/>').join('') + '<Relationship Id="rId' + (sheets.length + 1) + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>' });
    files.push({ name: 'xl/styles.xml', data: styles.xml() });
    return zip(files);
  }

  // ======================= statistics helpers for the report =======================
  const axFmt = mx => mx < 1 ? '0.000' : mx < 10 ? '0.00' : mx < 100 ? '0.0' : '0';
  const f3 = v => fin(v) ? (Math.abs(v) >= 10000 || (Math.abs(v) > 0 && Math.abs(v) < 0.001) ? v.toExponential(2) : v.toFixed(3)) : '–';
  const fx = (v, d) => fin(v) ? v.toFixed(d) : '–';
  const fP = p => !fin(p) ? '–' : (p < 0.001 ? '< 0.001' : p.toFixed(3));
  const cat = (arr, sep, last) => arr.length <= 1 ? (arr[0] || '') : arr.slice(0, -1).join(sep || ', ') + (last || ' and ') + arr[arr.length - 1];
  function lvl(c, p) { return c.levels.find(l => l.pct === p); }

  // compact letter display from a significance matrix, order = indices sorted by LC50 ascending
  function letters(order, sig) {
    let groups = [new Set(order)];
    for (let a = 0; a < order.length; a++) for (let b = a + 1; b < order.length; b++) {
      const i = order[a], j = order[b];
      if (!sig[i][j]) continue;
      const next = [];
      groups.forEach(g => {
        if (g.has(i) && g.has(j)) { const g1 = new Set(g); g1.delete(i); const g2 = new Set(g); g2.delete(j); next.push(g1, g2); } else next.push(g);
      });
      groups = next.filter((g, x) => g.size && !next.some((h, y) => y !== x && h.size >= g.size && [...g].every(v => h.has(v)) && (h.size > g.size || y < x)));
    }
    groups.sort((p, q) => Math.min(...[...p].map(v => order.indexOf(v))) - Math.min(...[...q].map(v => order.indexOf(v))));
    const res = {}; order.forEach(i => { res[i] = groups.map((g, k) => g.has(i) ? String.fromCharCode(97 + k) : '').join(''); });
    return res;
  }

  // ======================= main builder =======================
  function build(D) {
    const st = Styles();
    const M = D.meta, C = D.compounds, N = C.length, U = M.unit || '', MET = M.metric || 'LC';
    const org = M.organism || 'the target organism';
    const exposure = M.exposure || 'the specified exposure period';
    const names = C.map(c => c.name);
    // ---- derived quantities
    const order = C.map((c, i) => i).sort((a, b) => lvl(C[a], 50).dose - lvl(C[b], 50).dose);
    const most = order[0], least = order[N - 1];
    const lc50 = i => lvl(C[i], 50), lc90 = i => lvl(C[i], 90);
    const sigM = C.map((c, i) => C.map((d, j) => i === j ? false : !!(D.ratios[i][j] && D.ratios[i][j].sig)));
    const CLD = N > 1 ? letters(order, sigM) : { 0: '' };
    const fold = i => lc50(least).dose / lc50(i).dose;
    const TI = i => lc50(most).dose / lc50(i).dose * 100;
    const nTot = c => c.doses.reduce((s, d) => s + d.total, 0);

    // ---- style presets
    const T = { sz: 10 };
    const S = {
      banner: { sz: 8, color: '7F7F7F', h: 'left' },
      title: { sz: 16, b: true, h: 'center', wrap: true, v: 'center' },
      author: { sz: 11, h: 'center', wrap: true }, affil: { sz: 9.5, i: true, h: 'center', wrap: true, color: '404040' },
      rule: { bB: 'medium' },
      h1: { sz: 12, b: true, h: 'left', bB: 'thin', bc: '7F7F7F' }, h2: { sz: 10.5, b: true, i: true, h: 'left' },
      para: { sz: 10, h: 'justify', v: 'top', wrap: true }, abs: { sz: 9.5, h: 'justify', v: 'top', wrap: true, fill: 'F2F2F2' }, absH: { sz: 10, b: true, h: 'left', fill: 'F2F2F2' },
      cap: { sz: 10, h: 'left', v: 'top', wrap: true }, capB: { sz: 10, b: true, h: 'left', v: 'top', wrap: true },
      note: { sz: 8.5, h: 'left', v: 'top', wrap: true, color: '262626' }
    };
    const paraHeight = (text, widthChars, sz) => { const cpl = Math.max(20, widthChars * 1.18 * (10 / (sz || 10))); const n = String(plain(text)).split('\n').reduce((s, p) => s + Math.max(1, Math.ceil(p.length / cpl)), 0); return Math.round((n * (sz || 10) * 1.32 + 5) * 10) / 10; };

    const sheets = [];
    let lastBrk = 1; const PAGE_H = 500;
    const ensure = (h) => { let acc = 0; for (let k = lastBrk; k < r; k++) acc += R.heightOf(k); if (acc > 0 && acc + h > PAGE_H) { R.breakAfter(r - 1); lastBrk = r; } };
    // =============== Sheet: Report ===============
    const R = Sheet('Report', st, { tab: '1F3864', selected: true }); sheets.push(R);
    [2, 22, 10, 15, 15, 25, 25, 12, 10, 9, 9, 2].forEach((w, k) => R.width(1 + k, w));
    const C1 = 2, C2 = 11; let totalW = 22 + 10 + 15 + 15 + 25 + 25 + 12 + 10 + 9 + 9;
    let r = 1;
    const para = (text, style, w) => { R.merge(r, C1, r, C2, text, style || S.para); R.height(r, paraHeight(text, w || totalW, (style || S.para).sz)); r++; };
    const gap = (h) => { R.height(r, h || 8); r++; };

    R.merge(r, C1, r, C2, 'AI TOX  ·  Statistical Toxicology & Bioassay Platform  ·  Scientific report', S.banner); r++;
    gap(4);
    const ttl = 'Concentration–mortality (probit) analysis of ' + cat(names) + ' against ' + org; R.merge(r, C1, r, C2, ttl, S.title); R.height(r, paraHeight(ttl, totalW * 0.62, 16)); r++;
    R.merge(r, C1, r, C2, M.researcher || '', S.author); R.height(r, 18); r++;
    R.merge(r, C1, r, C2, [M.specialty, M.college, M.university].filter(Boolean).join(', '), S.affil); R.height(r, 16); r++;
    R.merge(r, C1, r, C2, 'Report generated: ' + M.date + '   |   Exposure: ' + exposure + '   |   Treatments: ' + N + '   |   Unit: ' + (U || '—'), S.affil); R.height(r, 15); r++;
    for (let c = C1; c <= C2; c++) R.set(r, c, null, S.rule); R.height(r, 4); r++;
    gap(6);

    // ----- Abstract
    const best = C[most], l50m = lc50(most);
    let abs = 'The toxicity of ' + (N > 1 ? N + ' treatments (' + cat(names) + ')' : names[0]) + ' against ' + org + ' was assessed after ' + exposure + ' of exposure using concentration–mortality bioassays. Mortality was corrected for control mortality with Abbott’s formula and analysed by Finney’s weighted probit regression. ';
    abs += (N > 1 ? best.name + ' was the most toxic treatment ' : best.name + ' gave ') + MET + '_{50} = ' + f3(l50m.dose) + ' ' + U + ' (95% FL ' + f3(l50m.lo) + '–' + f3(l50m.hi) + ')';
    abs += '. ';
    if (N > 1) {
      abs += 'The least toxic treatment was ' + C[least].name + ' (' + MET + '_{50} = ' + f3(lc50(least).dose) + ' ' + U + '), i.e. ' + fx(fold(most), 2) + '-fold less potent than ' + best.name + '. ';
      const sigPairs = []; for (let a = 0; a < N; a++) for (let b = a + 1; b < N; b++) if (sigM[a][b]) sigPairs.push(1);
      const nPairs = N * (N - 1) / 2;
      abs += (nPairs === 1 ? (sigPairs.length ? 'The ' + MET + '_{50} values differed significantly' : 'The ' + MET + '_{50} values did not differ significantly') : (sigPairs.length ? sigPairs.length + ' of ' + nPairs + ' pairwise ' + MET + '_{50} comparisons were significant' : 'No pairwise ' + MET + '_{50} comparison was significant')) + ' according to the Robertson–Preisler ratio test (95% CI of the ratio excluding 1). ';
      if (D.parallel && D.parallel.valid) abs += 'Probit lines were ' + (D.parallel.isParallel ? 'parallel' : 'not parallel') + ' (χ^{2} = ' + f3(D.parallel.chi) + ', df = ' + D.parallel.df + ', ~P~ = ' + fP(D.parallel.p) + '). ';
    } else {
      abs += MET + '_{90} was ' + f3(lc90(0).dose) + ' ' + U + ' (95% FL ' + f3(lc90(0).lo) + '–' + f3(lc90(0).hi) + ') with a slope of ' + fx(C[0].b, 3) + ' ± ' + fx(C[0].seB, 3) + '. ';
    }
    R.merge(r, C1, r, C2, 'Abstract', S.absH); R.height(r, 16); r++;
    R.merge(r, C1, r, C2, abs, S.abs); R.height(r, paraHeight(abs, totalW, 9.5)); r++;
    R.merge(r, C1, r, C2, '~Keywords~  Probit analysis · ' + MET + '_{50} · Abbott’s correction · Fiducial limits · Relative potency · Concentration–mortality · Toxicity index', S.note); R.height(r, 15); r++;
    gap(8);

    // ----- 1 Materials and methods
    ensure(90); R.merge(r, C1, r, C2, '1  Materials and methods', S.h1); R.height(r, 19); r++; gap(4);
    R.merge(r, C1, r, C2, '1.1  Bioassay design', S.h2); r++;
    const totalAll = C.reduce((s, c) => s + nTot(c), 0);
    let m1 = 'Concentration–mortality bioassays were carried out for ' + (N > 1 ? N + ' treatments (' + cat(names) + ')' : names[0]) + ' on ' + org + '. Each treatment was tested at ' + cat(C.map(c => String(c.doses.length)).filter((v, i, a) => a.indexOf(v) === i)) + ' concentration(s) (' + U + '), with a total of ' + totalAll + ' treated individuals and untreated controls (' + cat(C.map(c => c.controlTotal + ' individuals, ' + c.controlDead + ' dead')) + '). Mortality was recorded after ' + exposure + ' and the endpoint was expressed as ' + MET + ' (' + U + ').';
    para(m1);
    R.merge(r, C1, r, C2, '1.2  Statistical analysis', S.h2); r++;
    const m2 = 'Observed mortality was corrected for natural mortality using Abbott’s (1925) formula. Concentration–mortality data were analysed by Finney’s (1971) maximum-likelihood probit analysis (iteratively re-weighted least squares on log_{10} concentration), and ' + MET + ' values with 95% fiducial limits (FL) were calculated from the regression line (Y = a + b·log_{10} X). The goodness of fit was tested by Pearson’s χ^{2} (df = number of concentrations − 2); when χ^{2} exceeded the tabulated value (heterogeneity factor > 1) the variances were multiplied by the heterogeneity factor and Student’s ~t~ was used for the fiducial limits. ' +
      (N > 1 ? 'Potency of treatments was compared with the Robertson–Preisler (1992) lethal-concentration ratio test: two ' + MET + '_{50} values were considered significantly different (~P~ < 0.05) when the 95% confidence interval of their ratio did not include 1. Treatments sharing the same letter in Table 1 are not significantly different. Relative potency (fold) was calculated as ' + MET + '_{50} of the least toxic treatment divided by that of each treatment, and the toxicity index (Sun 1950) as ' + MET + '_{50} of the most toxic treatment divided by that of each treatment × 100. Parallelism of the probit lines was tested with a χ^{2} test of the deviation of individual slopes from the weighted common slope.' : 'Statistics reported include slope ± SE, intercept ± SE, correlation coefficient (~r~), coefficient of determination (~R~^{2}) and the χ^{2} goodness-of-fit test.') + ' All calculations were performed with AI TOX.';
    para(m2); gap(6);

    // ----- 2 Results
    ensure(120); R.merge(r, C1, r, C2, '2  Results', S.h1); R.height(r, 19); r++; gap(4);
    ensure(110); R.merge(r, C1, r, C2, '2.1  Toxicity of the tested treatments', S.h2); r++;
    let res1 = '';
    order.forEach((i, rank) => {
      const c = C[i], l5 = lc50(i), l9 = lc90(i);
      res1 += (N > 1 ? (rank === 0 ? 'Based on ' + MET + '_{50}, ' : '') + c.name + ' (rank ' + (rank + 1) + ') ' : c.name + ' ') + 'gave ' + MET + '_{50} = ' + f3(l5.dose) + ' ' + U + ' (95% FL ' + f3(l5.lo) + '–' + f3(l5.hi) + ') and ' + MET + '_{90} = ' + f3(l9.dose) + ' ' + U + ' (95% FL ' + f3(l9.lo) + '–' + f3(l9.hi) + '); slope = ' + fx(c.b, 3) + ' ± ' + fx(c.seB, 3) + ', ~r~ = ' + fx(c.r, 4) + ', χ^{2} = ' + fx(c.chi, 3) + ' (df = ' + c.df + ', ~P~ = ' + fP(c.p) + '), ' + (c.hetero ? 'heterogeneity factor ' + fx(c.H, 2) + ' applied. ' : 'no significant heterogeneity (data fit the probit model). ');
    });
    res1 += 'Detailed results are given in Table 1 and Fig. 1; lethal concentrations at other mortality levels are given in Table S1 and Fig. 2.';
    para(res1);
    gap(4);

    // --- Table 1
    const tbl = { hdr: { sz: 10, b: true, h: 'center', v: 'center', wrap: true, bT: 'medium', bB: 'thin' }, hdrL: { sz: 10, b: true, h: 'left', v: 'center', wrap: true, bT: 'medium', bB: 'thin' } };
    const body = (h, last, extra) => Object.assign({ sz: 10, h: h || 'center', v: 'center', wrap: true }, last ? { bB: 'medium' } : {}, extra || {});
    ensure(60 + N * 22 + 70);
    R.merge(r, C1, r, C2, '', S.cap);
    R.set(r, C1, 'Table 1  ' + MET + ' values of ' + cat(names) + ' against ' + org + ' after ' + exposure, S.capB); R.height(r, paraHeight('Table 1  ' + MET + ' values of ' + cat(names) + ' against ' + org + ' after ' + exposure, totalW, 10)); r++;
    const h1 = ['Treatment', '~n~ (tested)', 'Slope ± SE', 'Intercept ± SE', MET + '_{50} (' + U + ') (95% FL)', MET + '_{90} (' + U + ') (95% FL)', 'χ^{2} (df)', '~P~', '~r~', '~R~^{2}'];
    // 10 header columns B..K
    h1.forEach((t, k) => R.set(r, C1 + k, t, k === 0 ? tbl.hdrL : tbl.hdr)); R.height(r, 32); r++;
    const t1first = r;
    order.forEach((i, rank) => {
      const c = C[i], last = rank === N - 1, l5 = lc50(i), l9 = lc90(i);
      const row = [c.name + (N > 1 && CLD[i] ? '  (' + CLD[i] + ')' : ''), nTot(c), fx(c.b, 3) + ' ± ' + fx(c.seB, 3), fx(c.a, 3) + ' ± ' + fx(c.seA, 3),
        f3(l5.dose) + ' (' + f3(l5.lo) + '–' + f3(l5.hi) + ')', f3(l9.dose) + ' (' + f3(l9.lo) + '–' + f3(l9.hi) + ')', fx(c.chi, 3) + ' (' + c.df + ')', fP(c.p), fx(c.r, 4), fx(c.r2, 4)];
      row.forEach((v, k) => R.set(r, C1 + k, v, body(k === 0 ? 'left' : 'center', last, rank === 0 && N > 1 ? { b: false } : null)));
      R.height(r, Math.max(row[4].length, row[5].length) > 24 ? 30 : 22); r++;
    });
    const note1 = 'Treatments are ranked from the most to the least toxic (by ' + MET + '_{50}). ' + MET + '_{50} and ' + MET + '_{90}: concentrations (' + U + ') causing 50% and 90% mortality; FL: 95% fiducial limits; ~n~: number of treated individuals (controls excluded); slope and intercept are those of the probit line Y = a + b·log_{10} X (± SE); χ^{2}: Pearson goodness of fit with degrees of freedom in parentheses; ~P~ > 0.05 indicates that the data fit the probit model; ~r~: correlation coefficient; ~R~^{2}: coefficient of determination.' + (N > 1 ? ' Letters in parentheses: treatments sharing a letter are not significantly different (Robertson–Preisler ratio test, 95% CI of the ratio includes 1).' : '');
    para(note1, S.note); gap(8);

    // --- Fig 1
    const FIG_ROWS = 21; let figNo = 0;
    const figRegistry = [];
    const placeFig = (xml, capTitle, capText) => {
      ensure(FIG_ROWS * 14.25 + 50);
      figNo++;
      R.addChart(xml, r, C1, r + FIG_ROWS - 1, 7); r += FIG_ROWS;
      const t = 'Fig. ' + figNo + '  ' + capTitle + (capText ? ' ' + capText : '');
      R.merge(r, C1, r, 7, t, S.cap); R.height(r, paraHeight(t, 22 + 10 + 15 + 15 + 25 + 25, 10)); r++; gap(8);
    };

    // =============== Sheet: Chart data (built before charts so refs exist) ===============
    const CD = Sheet('Chart data', st, { tab: '7F7F7F', landscape: true }); 
    const cdName = "'Chart data'!";
    const rng = (sheet, r1, c1, r2, c2) => sheet + ABS(r1, c1) + (r2 != null ? ':' + ABS(r2, c2) : '');
    CD.width(1, 28); for (let c = 2; c <= 12; c++) CD.width(c, 13);
    const cdH = { sz: 10, b: true, h: 'center', wrap: true, bT: 'medium', bB: 'thin' }, cdHL = Object.assign({}, cdH, { h: 'left' });
    const cdB = (last, h, fmt) => ({ sz: 10, h: h || 'center', bB: last ? 'medium' : null, fmt: fmt || 'General' });
    CD.merge(1, 1, 1, 10, 'Chart data — source ranges of the native Excel charts in the Report sheet (edit a value and the charts update).', { sz: 10, b: true, h: 'left' });
    let q = 3;
    // Block A: LC50
    CD.set(q, 1, MET + '_{50} summary', { sz: 10, b: true, i: true, h: 'left' }); q++;
    const hA = ['Treatment', MET + '_{50}', 'Lower FL', 'Upper FL', '+ error', '− error', 'Group', 'Fold potency', 'Toxicity index (%)'];
    hA.forEach((t, k) => CD.set(q, 1 + k, t, k === 0 ? cdHL : cdH)); CD.height(q, 28); q++;
    const aR1 = q, aR2 = q + N - 1;
    C.forEach((c, i) => {
      const last = i === N - 1, l = lc50(i), rr = q + i;
      CD.set(rr, 1, c.name, cdB(last, 'left'));
      CD.set(rr, 2, l.dose, cdB(last, 'center', '0.000')); CD.set(rr, 3, l.lo, cdB(last, 'center', '0.000')); CD.set(rr, 4, l.hi, cdB(last, 'center', '0.000'));
      CD.set(rr, 5, { f: A1(rr, 4) + '-' + A1(rr, 2), v: l.hi - l.dose }, cdB(last, 'center', '0.000')); CD.set(rr, 6, { f: A1(rr, 2) + '-' + A1(rr, 3), v: l.dose - l.lo }, cdB(last, 'center', '0.000'));
      CD.set(rr, 7, N > 1 ? CLD[i] : '', cdB(last));
      CD.set(rr, 8, { f: 'MAX(' + ABS(aR1, 2) + ':' + ABS(aR2, 2) + ')/' + A1(rr, 2), v: fold(i) }, cdB(last, 'center', '0.00'));
      CD.set(rr, 9, { f: 'MIN(' + ABS(aR1, 2) + ':' + ABS(aR2, 2) + ')/' + A1(rr, 2) + '*100', v: TI(i) }, cdB(last, 'center', '0.00'));
    });
    q = aR2 + 2;
    CD.merge(q, 1, q, 9, 'Fold potency = ' + MET + '_{50} of the least toxic ÷ ' + MET + '_{50} of each treatment; toxicity index = ' + MET + '_{50} of the most toxic ÷ ' + MET + '_{50} of each treatment × 100 (Sun 1950). ' + MET + '_{50} and FL are AI TOX outputs (hard-coded results).', S.note); CD.height(q, 26); q += 2;

    // Block B: LC levels
    const LV = [10, 25, 50, 75, 90];
    CD.set(q, 1, 'Lethal levels (columns) with 95% fiducial limits', { sz: 10, b: true, i: true, h: 'left' }); q++;
    CD.set(q, 1, 'Level', cdHL);
    C.forEach((c, j) => { CD.set(q, 2 + 3 * j, c.name, cdH); CD.set(q, 3 + 3 * j, '+ error', cdH); CD.set(q, 4 + 3 * j, '− error', cdH); });
    CD.height(q, 28); q++;
    const bR1 = q;
    LV.forEach((p, k) => {
      const last = k === LV.length - 1, rr = q + k;
      CD.set(rr, 1, MET + p, cdB(last, 'left'));
      C.forEach((c, j) => { const l = lvl(c, p); CD.set(rr, 2 + 3 * j, l.dose, cdB(last, 'center', '0.000')); CD.set(rr, 3 + 3 * j, l.hi - l.dose, cdB(last, 'center', '0.000')); CD.set(rr, 4 + 3 * j, l.dose - l.lo, cdB(last, 'center', '0.000')); });
    });
    const bR2 = q + LV.length - 1; q = bR2 + 3;

    // Block C: probit lines
    CD.set(q, 1, 'Toxicity (probit) lines — observed points and fitted regression lines', { sz: 10, b: true, i: true, h: 'left' }); q++;
    const lineRef = [];
    let xAll = [], yAll = [];
    C.forEach((c, j) => {
      CD.set(q, 1, c.name + ' — observed', cdHL); CD.set(q, 2, 'Log_{10} conc.', cdH); CD.set(q, 3, 'Empirical probit', cdH); CD.height(q, 28); q++;
      const o1 = q;
      c.doses.forEach((d, k) => { CD.set(q, 1, d.conc, cdB(false, 'left', '0.###')); CD.set(q, 2, d.logConc, cdB(false, 'center', '0.0000')); CD.set(q, 3, d.empProbit, cdB(false, 'center', '0.0000')); xAll.push(d.logConc); yAll.push(d.empProbit); q++; });
      const o2 = q - 1;
      const xmin = Math.min(...c.doses.map(d => d.logConc)), xmax = Math.max(...c.doses.map(d => d.logConc)), pad = Math.max(0.05, (xmax - xmin) * 0.08);
      const f1 = xmin - pad, f2 = xmax + pad;
      CD.set(q, 1, 'Fitted line (Y = a + b·X)', cdB(false, 'left')); CD.set(q, 2, f1, cdB(false, 'center', '0.0000')); CD.set(q, 3, { f: fx(c.a, 10) + '+' + fx(c.b, 10) + '*' + A1(q, 2), v: c.a + c.b * f1 }, cdB(false, 'center', '0.0000')); q++;
      CD.set(q, 1, '', cdB(true, 'left')); CD.set(q, 2, f2, cdB(true, 'center', '0.0000')); CD.set(q, 3, { f: fx(c.a, 10) + '+' + fx(c.b, 10) + '*' + A1(q, 2), v: c.a + c.b * f2 }, cdB(true, 'center', '0.0000'));
      lineRef.push({ o1, o2, f1: q - 1, f2: q, x1: f1, x2: f2 }); xAll.push(f1, f2); yAll.push(c.a + c.b * f1, c.a + c.b * f2); q += 2;
    });
    const xlo = Math.min(...xAll), xhi = Math.max(...xAll), refY = 5;
    CD.set(q, 1, 'Reference (probit 5 = 50% mortality)', cdHL); CD.set(q, 2, 'Log_{10} conc.', cdH); CD.set(q, 3, 'Probit', cdH); CD.height(q, 28); q++;
    const refR1 = q; CD.set(q, 1, '', cdB(false, 'left')); CD.set(q, 2, xlo, cdB(false, 'center', '0.0000')); CD.set(q, 3, refY, cdB(false, 'center', '0.0')); q++;
    CD.set(q, 1, '', cdB(true, 'left')); CD.set(q, 2, xhi, cdB(true, 'center', '0.0000')); CD.set(q, 3, refY, cdB(true, 'center', '0.0')); const refR2 = q; q += 3;

    // =============== Sheet: Table S2 (dose–response) ===============
    const S2 = Sheet('Table S2 Dose-response', st, { tab: '548235', freeze: { r: 5, c: 1 } });
    S2.width(1, 22); for (let c = 2; c <= 12; c++) S2.width(c, 13);
    S2.merge(1, 1, 1, 12, 'Table S2  Observed and probit-expected mortality of ' + cat(names) + ' against ' + org + ' after ' + exposure, S.capB); S2.height(1, 20);
    S2.merge(2, 1, 2, 12, 'Corrected mortality uses Abbott’s formula with the control mortality of each treatment (formula-driven). Expected values come from the fitted probit line. Empirical probit is the probit of the corrected mortality (0.5/n and 1 − 0.5/n substitutes for 0% and 100%).', S.note); S2.height(2, 26);
    const h2 = ['Treatment', 'Concentration (' + U + ')', 'Log_{10} conc.', '~n~ (tested)', 'Dead', 'Observed mortality (%)', 'Corrected mortality (%)', 'Empirical probit', 'Expected mortality (%)', 'Expected probit', 'χ^{2} contribution', 'Residual (%)'];
    h2.forEach((t, k) => S2.set(4, 1 + k, t, k === 0 ? tbl.hdrL : tbl.hdr)); S2.height(4, 42);
    let s2r = 5; const s2rows = [];
    C.forEach((c, j) => {
      const ctrlRow = s2r;
      S2.set(s2r, 1, c.name, { sz: 10, h: 'left', b: true }); S2.set(s2r, 2, 0, { sz: 10, h: 'center', fmt: '0' }); S2.set(s2r, 3, '–', { sz: 10, h: 'center' }); S2.set(s2r, 4, c.controlTotal, { sz: 10, h: 'center' }); S2.set(s2r, 5, c.controlDead, { sz: 10, h: 'center' });
      S2.set(s2r, 6, { f: A1(s2r, 5) + '/' + A1(s2r, 4) + '*100', v: c.controlPct }, { sz: 10, h: 'center', fmt: '0.00' });
      for (let k = 7; k <= 12; k++) S2.set(s2r, k, '–', { sz: 10, h: 'center' });
      s2r++;
      const rowsJ = [];
      c.doses.forEach((d, k) => {
        const last = (j === N - 1) && k === c.doses.length - 1, rr = s2r;
        const sp = (h, fmt) => ({ sz: 10, h: h || 'center', fmt: fmt || 'General', bB: last ? 'medium' : null });
        S2.set(rr, 1, c.name, sp('left')); S2.set(rr, 2, d.conc, sp('center', '0.###')); S2.set(rr, 3, { f: 'LOG10(' + A1(rr, 2) + ')', v: d.logConc }, sp('center', '0.0000'));
        S2.set(rr, 4, d.total, sp()); S2.set(rr, 5, d.dead, sp());
        S2.set(rr, 6, { f: A1(rr, 5) + '/' + A1(rr, 4) + '*100', v: d.obsPct }, sp('center', '0.00'));
        S2.set(rr, 7, { f: 'IF(' + A1(rr, 6) + '>' + ABS(ctrlRow, 6) + ',(' + A1(rr, 6) + '-' + ABS(ctrlRow, 6) + ')/(100-' + ABS(ctrlRow, 6) + ')*100,0)', v: d.corrPct }, sp('center', '0.00'));
        S2.set(rr, 8, d.empProbit, sp('center', '0.0000')); S2.set(rr, 9, d.expPct, sp('center', '0.00')); S2.set(rr, 10, d.expProbit, sp('center', '0.0000')); S2.set(rr, 11, d.chi, sp('center', '0.0000'));
        S2.set(rr, 12, { f: A1(rr, 7) + '-' + A1(rr, 9), v: d.corrPct - d.expPct }, sp('center', '0.00'));
        rowsJ.push(rr); s2r++;
      });
      s2rows.push(rowsJ);
    });
    S2.merge(s2r + 1, 1, s2r + 1, 12, 'Σχ^{2} per treatment: ' + C.map(c => c.name + ' = ' + fx(c.chi, 3) + ' (df = ' + c.df + ')').join('; ') + '.', S.note); S2.height(s2r + 1, 18);

    // Block D: mortality (linked to S2)
    CD.set(q, 1, 'Concentration–mortality (columns = corrected mortality, line = probit-expected mortality) — linked to Table S2', { sz: 10, b: true, i: true, h: 'left' }); q++;
    const mortRef = [];
    C.forEach((c, j) => {
      CD.set(q, 1, c.name + ' — conc. (' + U + ')', cdHL); CD.set(q, 2, 'Corrected mortality (%)', cdH); CD.set(q, 3, 'Expected mortality (%)', cdH); CD.height(q, 28); q++;
      const m1r = q;
      c.doses.forEach((d, k) => {
        const last = k === c.doses.length - 1, rr = s2rows[j][k], sq = "'Table S2 Dose-response'!";
        CD.set(q, 1, { f: 'TEXT(' + sq + A1(rr, 2) + ',"0.###")', v: String(+(+d.conc).toPrecision(6)) }, cdB(last, 'left'));
        CD.set(q, 2, { f: sq + A1(rr, 7), v: d.corrPct }, cdB(last, 'center', '0.00')); CD.set(q, 3, { f: sq + A1(rr, 9), v: d.expPct }, cdB(last, 'center', '0.00')); q++;
      });
      mortRef.push({ r1: m1r, r2: q - 1 }); q += 2;
    });

    // =============== Charts ===============
    const palette = C.map(c => c.color || '#1F3864');
    // Fig 1: LC50 columns + error bars + letters
    {
      const catRef = cdName + ABS(aR1, 1) + ':' + ABS(aR2, 1), catVals = names;
      const bar = { name: { v: MET + '50 (95% FL)' }, cat: { ref: catRef, vals: catVals }, val: { ref: rng(cdName, aR1, 2, aR2, 2), vals: C.map((c, i) => lc50(i).dose), fmt: '0.000' }, color: palette[0], ptColors: palette,
        err: { plus: { ref: rng(cdName, aR1, 5, aR2, 5), vals: C.map((c, i) => lc50(i).hi - lc50(i).dose) }, minus: { ref: rng(cdName, aR1, 6, aR2, 6), vals: C.map((c, i) => lc50(i).dose - lc50(i).lo) } } };
      const lines = N > 1 ? [{ name: { v: 'Group' }, cat: { ref: catRef, vals: catVals }, val: { ref: rng(cdName, aR1, 4, aR2, 4), vals: C.map((c, i) => lc50(i).hi) }, noLine: true, letters: C.map((c, i) => CLD[i] || '') }] : [];
      const xml = chartXml({ type: 'combo', bars: [bar], lines, xTitle: 'Treatment', yTitle: MET + '_{50} (' + U + ') ± 95% FL', gap: 90, legend: false, yFmt: axFmt(Math.max.apply(null, C.map((c, i) => lc50(i).hi))) });
      placeFig(xml, MET + '_{50} values of the tested treatments against ' + org + ' after ' + exposure + '.', 'Columns show ' + MET + '_{50}; error bars are 95% fiducial limits' + (N > 1 ? '; columns sharing the same letter are not significantly different (Robertson–Preisler ratio test).' : '.'));
    }
    // Fig 2: lethal levels
    {
      const catRef = rng(cdName, bR1, 1, bR2, 1), catVals = LV.map(p => MET + p);
      const bars = C.map((c, j) => ({ name: { v: c.name }, cat: { ref: catRef, vals: catVals }, val: { ref: rng(cdName, bR1, 2 + 3 * j, bR2, 2 + 3 * j), vals: LV.map(p => lvl(c, p).dose), fmt: '0.000' }, color: palette[j],
        err: { plus: { ref: rng(cdName, bR1, 3 + 3 * j, bR2, 3 + 3 * j), vals: LV.map(p => lvl(c, p).hi - lvl(c, p).dose) }, minus: { ref: rng(cdName, bR1, 4 + 3 * j, bR2, 4 + 3 * j), vals: LV.map(p => lvl(c, p).dose - lvl(c, p).lo) } } }));
      placeFig(chartXml({ type: 'bar', bars, xTitle: 'Lethal level', yTitle: 'Concentration (' + U + ') ± 95% FL', gap: 60, legend: true, yFmt: axFmt(Math.max.apply(null, C.map(c => lvl(c, 90).hi))) }), 'Toxicity profile: lethal concentrations (' + MET + '_{10}, ' + MET + '_{25}, ' + MET + '_{50}, ' + MET + '_{75}, ' + MET + '_{90}) of the treatments.', 'Columns are the probit-estimated concentrations; error bars are 95% fiducial limits.');
    }
    // Fig 3: fold potency
    if (N > 1) {
      const catRef = cdName + ABS(aR1, 1) + ':' + ABS(aR2, 1);
      const bar = { name: { v: 'Fold potency' }, cat: { ref: catRef, vals: names }, val: { ref: rng(cdName, aR1, 8, aR2, 8), vals: C.map((c, i) => fold(i)), fmt: '0.00' }, color: palette[0], ptColors: palette, showVal: true, valFmt: '0.00"×"' };
      placeFig(chartXml({ type: 'bar', bars: [bar], xTitle: 'Treatment', yTitle: 'Relative potency (fold of the least toxic)', gap: 80, legend: false, yFmt: axFmt(Math.max.apply(null, C.map((c, i) => fold(i)))) }), 'Relative potency of the treatments.', 'Fold potency = ' + MET + '_{50} of the least toxic treatment (' + C[least].name + ') divided by the ' + MET + '_{50} of each treatment.');
    }
    // Fig 4: toxicity (probit) lines
    {
      const sc = []; 
      C.forEach((c, j) => {
        const L = lineRef[j];
        sc.push({ name: { v: c.name + ' (observed)' }, x: { ref: rng(cdName, L.o1, 2, L.o2, 2), vals: c.doses.map(d => d.logConc) }, val: { ref: rng(cdName, L.o1, 3, L.o2, 3), vals: c.doses.map(d => d.empProbit) }, color: palette[j], marker: ['circle', 'square', 'triangle', 'diamond', 'x', 'star'][j % 6], noLine: true });
        sc.push({ name: { v: c.name + ' (probit line)' }, x: { ref: rng(cdName, L.f1, 2, L.f2, 2), vals: [L.x1, L.x2] }, val: { ref: rng(cdName, L.f1, 3, L.f2, 3), vals: [c.a + c.b * L.x1, c.a + c.b * L.x2] }, color: palette[j], w: 25400 });
      });
      sc.push({ name: { v: 'Probit 5 (50% mortality)' }, x: { ref: rng(cdName, refR1, 2, refR2, 2), vals: [xlo, xhi] }, val: { ref: rng(cdName, refR1, 3, refR2, 3), vals: [refY, refY] }, color: '7F7F7F', w: 12700, dash: 'dash' });
      placeFig(chartXml({ type: 'scatter', scatter: sc, xTitle: 'Log_{10} concentration (' + U + ')', yTitle: 'Probit mortality', legend: true, xFmt: '0.0', yFmt: '0', yMin: Math.max(0, Math.floor(Math.min.apply(null, yAll.concat([5])) - 0.5)), yMax: Math.ceil(Math.max.apply(null, yAll.concat([5])) + 0.5), xMin: Math.floor((xlo - 0.1) * 2) / 2, xMax: Math.ceil((xhi + 0.1) * 2) / 2 }), 'Toxicity (concentration–probit) lines of the treatments.', 'Symbols are empirical probits of the corrected mortality; solid lines are the fitted probit regression lines (Y = a + b·log_{10} X); the dashed line marks probit 5 (' + MET + '_{50}).');
    }
    // Fig 5+: per-compound mortality columns + expected curve
    const perStart = r;
    for (let j = 0; j < N; j += 2) {
      ensure(20 * 14.25 + 70);
      const pair = [j, j + 1].filter(x => x < N);
      pair.forEach((ci, pi) => {
        const c = C[ci], M2 = mortRef[ci], catRef = rng(cdName, M2.r1, 1, M2.r2, 1), cv = c.doses.map(d => String(+(+d.conc).toPrecision(6)));
        const bar = { name: { v: 'Corrected mortality (%)' }, cat: { ref: catRef, vals: cv }, val: { ref: rng(cdName, M2.r1, 2, M2.r2, 2), vals: c.doses.map(d => d.corrPct), fmt: '0.00' }, color: palette[ci], showVal: true, valFmt: '0.0' };
        const ln = { name: { v: 'Expected (probit line)' }, cat: { ref: catRef, vals: cv }, val: { ref: rng(cdName, M2.r1, 3, M2.r2, 3), vals: c.doses.map(d => d.expPct), fmt: '0.00' }, color: '000000', marker: 'circle', w: 22225 };
        const xml = chartXml({ type: 'combo', bars: [bar], lines: [ln], xTitle: 'Concentration (' + U + ')', yTitle: 'Corrected mortality (%)', yMin: 0, yMax: 100, major: 20, gap: 60, legend: true });
        const c1 = pi === 0 ? 2 : 6, c2 = pi === 0 ? 5 : 8;
        R.addChart(xml, r, c1, r + 19, c2);
      });
      r += 20;
      let capH = 30;
      pair.forEach((ci, pi) => {
        figNo++;
        const t = 'Fig. ' + figNo + '  ' + 'Concentration–mortality response of ' + C[ci].name + '. Columns: corrected mortality (%); line: mortality expected from the fitted probit line (χ^{2} = ' + fx(C[ci].chi, 3) + ', df = ' + C[ci].df + ', ~P~ = ' + fP(C[ci].p) + ').';
        R.merge(r, pi === 0 ? 2 : 6, r, pi === 0 ? 5 : 8, t, S.cap);
        capH = Math.max(capH, paraHeight(t, 62, 10));
      });
      R.height(r, capH);
      r++; gap(8);
    }

    // --- Table 2 relative potency
    if (N > 1) {
      ensure(60 + 70 + 44 + N * 20 + 60);
      R.merge(r, C1, r, C2, '2.2  Relative potency and parallelism', S.h2); r++;
      let res2 = C[most].name + ' was the most toxic treatment. Relative to the least toxic treatment (' + C[least].name + ') the potency of the treatments ranged from ' + fx(fold(least), 2) + ' to ' + fx(fold(most), 2) + '-fold (Table 2, Fig. 3). ';
      if (D.parallel && D.parallel.valid) res2 += 'The test of parallelism ' + (D.parallel.isParallel ? 'did not reject' : 'rejected') + ' the hypothesis of parallel probit lines (χ^{2} = ' + fx(D.parallel.chi, 3) + ', df = ' + D.parallel.df + ', ~P~ = ' + fP(D.parallel.p) + '; common slope = ' + fx(D.parallel.commonSlope, 3) + '), ' + (D.parallel.isParallel ? 'so relative potency is constant across the response range.' : 'so relative potency depends on the mortality level and ' + MET + '_{50}-based ratios should be interpreted with caution.');
      para(res2); gap(4);
      const cap2 = 'Table 2  Relative potency of the treatments against ' + org + ' based on ' + MET + '_{50}';
      R.merge(r, C1, r, C2, '', S.cap); R.set(r, C1, cap2, S.capB); R.height(r, 18); r++;
      const hh = ['Treatment', 'Rank', MET + '_{50} (' + U + ')', 'Fold potency', 'Ratio vs least toxic (95% CI)', 'Significance (~P~ < 0.05)', 'Toxicity index (%)', 'Group'];
      const place = [[2, 2], [3, 3], [4, 4], [5, 5], [6, 7], [8, 8], [9, 9], [10, 10]];
      hh.forEach((t, k) => { R.merge(r, place[k][0], r, place[k][1], t, k === 0 ? tbl.hdrL : tbl.hdr); }); R.height(r, 44); r++;
      order.forEach((i, rank) => {
        const last = rank === N - 1, ratio = i === least ? null : D.ratios[least][i];
        const vals = [C[i].name, rank + 1, f3(lc50(i).dose), i === least ? '1.00' : fx(fold(i), 2), ratio ? fx(ratio.ratio, 2) + ' (' + fx(ratio.lo, 2) + '–' + fx(ratio.hi, 2) + ')' : '—', ratio ? (ratio.sig ? 'Significant' : 'NS') : '—', fx(TI(i), 2), CLD[i]];
        vals.forEach((v, k) => R.merge(r, place[k][0], r, place[k][1], v, body(k === 0 ? 'left' : 'center', last)));
        R.height(r, 18); r++;
      });
      para('Fold potency = ' + MET + '_{50} of the least toxic treatment ÷ ' + MET + '_{50} of the treatment. Ratio: Robertson–Preisler lethal-dose ratio (least toxic ÷ treatment) with its 95% confidence interval; a ratio whose interval excludes 1 is significant (~P~ < 0.05); NS = not significant. Toxicity index (Sun 1950) = ' + MET + '_{50} of the most toxic ÷ ' + MET + '_{50} of the treatment × 100. All pairwise comparisons are in Table S3.', S.note);
      gap(8);
    }

    // --- Conclusion
    R.merge(r, C1, r, C2, '3  Conclusions', S.h1); R.height(r, 19); r++; gap(4);
    let concl = N > 1 ? 'Ranking the treatments by ' + MET + '_{50} gave the order ' + order.map(i => C[i].name + ' (' + f3(lc50(i).dose) + ' ' + U + ')').join(' > ') + ' (from the most to the least toxic). ' + C[most].name + ' was ' + fx(fold(most), 2) + '-fold more potent than ' + C[least].name + '. ' : C[0].name + ' showed a ' + MET + '_{50} of ' + f3(lc50(0).dose) + ' ' + U + ' against ' + org + ' after ' + exposure + '. ';
    concl += 'All probit models were ' + (C.every(c => !c.hetero) ? 'adequate (no significant heterogeneity).' : 'evaluated with heterogeneity-corrected fiducial limits where χ^{2} indicated lack of fit (' + C.filter(c => c.hetero).map(c => c.name).join(', ') + ').');
    para(concl); gap(8);

    // --- Sheet guide + references
    R.merge(r, C1, r, C2, 'Supplementary sheets', S.h1); R.height(r, 19); r++; gap(3);
    ['Table S1 LC values — probit, log concentration, lethal concentrations (LC5–LC99) with 95% fiducial limits for each treatment.', 'Table S2 Dose-response — observed vs expected mortality, Abbott correction (formula-driven), χ² contributions.', 'Table S3 Comparisons — Robertson–Preisler pairwise ratio tests, parallelism test and regression statistics.', 'Chart data — source ranges of every chart (edit and charts update).', 'Equations — statistical laws and formulas used.'].forEach(t => para(t, S.note, totalW));
    gap(6);
    R.merge(r, C1, r, C2, 'References', S.h1); R.height(r, 19); r++; gap(3);
    ['Abbott WS (1925) A method of computing the effectiveness of an insecticide. J Econ Entomol 18:265–267', 'Finney DJ (1971) Probit analysis, 3rd edn. Cambridge University Press, Cambridge', 'Robertson JL, Preisler HK (1992) Pesticide bioassays with arthropods. CRC Press, Boca Raton', 'Robertson JL, Jones MM, Olguin E, Alberts B (2017) Bioassays with arthropods, 3rd edn. CRC Press, Boca Raton', 'Sun YP (1950) Toxicity index — an improved method of comparing the relative toxicity of insecticides. J Econ Entomol 43:45–53'].forEach(t => para(t, S.note, totalW));

    // =============== Sheet: Table S1 ===============
    const S1 = Sheet('Table S1 LC values', st, { tab: '548235' });
    S1.width(1, 22); for (let c = 2; c <= 7; c++) S1.width(c, 17);
    S1.merge(1, 1, 1, 7, 'Table S1  Lethal concentrations (' + MET + ') of ' + cat(names) + ' against ' + org + ' with 95% fiducial limits', S.capB); S1.height(1, 20);
    let s1r = 3, s1Acc = 0;
    C.forEach((c, j) => {
      if (s1Acc + 190 > 500 && j > 0) { S1.breakAfter(s1r - 1); s1Acc = 0; }
      s1Acc += 190;
      S1.merge(s1r, 1, s1r, 7, c.name + '   ·   Y = ' + fx(c.a, 4) + ' + ' + fx(c.b, 4) + ' · log_{10}(X)   ·   ~r~ = ' + fx(c.r, 4) + '   ·   ~R~^{2} = ' + fx(c.r2, 4) + '   ·   χ^{2} (df) = ' + fx(c.chi, 3) + ' (' + c.df + ')   ·   ~g~ = ' + fx(c.g, 4), { sz: 10, b: true, h: 'left', fill: 'F2F2F2' }); S1.height(s1r, 18); s1r++;
      ['Level', 'Probit (Y)', 'Log_{10} concentration', 'Concentration (' + U + ')', 'Lower 95% FL', 'Upper 95% FL', 'FL width'].forEach((t, k) => S1.set(s1r, 1 + k, t, k === 0 ? tbl.hdrL : tbl.hdr)); S1.height(s1r, 30); s1r++;
      c.levels.forEach((l, k) => {
        const last = k === c.levels.length - 1, sp = (h, fmt, b) => ({ sz: 10, h: h || 'center', fmt: fmt || 'General', b: !!b, bB: last ? 'medium' : null });
        S1.set(s1r, 1, MET + '_{' + l.pct + '}', sp('left')); S1.set(s1r, 2, l.probit, sp('center', '0.0000')); S1.set(s1r, 3, l.logDose, sp('center', '0.0000')); S1.set(s1r, 4, l.dose, sp('center', '0.0000', l.pct === 50));
        S1.set(s1r, 5, l.lo, sp('center', '0.0000')); S1.set(s1r, 6, l.hi, sp('center', '0.0000')); S1.set(s1r, 7, { f: A1(s1r, 6) + '-' + A1(s1r, 5), v: l.hi - l.lo }, sp('center', '0.0000')); s1r++;
      });
      s1r += 1;
    });
    S1.merge(s1r, 1, s1r, 7, 'FL: fiducial limits (Finney 1971); ~g~: index of significance of the potency estimate (limits are reliable when ~g~ < 0.5). Results are AI TOX outputs.', S.note); S1.height(s1r, 18);

    // =============== Sheet: Table S3 ===============
    const S3 = Sheet('Table S3 Comparisons', st, { tab: '548235' });
    S3.width(1, 24); S3.width(2, 24); for (let c = 3; c <= 9; c++) S3.width(c, 15);
    S3.merge(1, 1, 1, 9, 'Table S3  Regression statistics, pairwise Robertson–Preisler ratio tests and parallelism test', S.capB); S3.height(1, 20);
    let s3r = 3;
    S3.set(s3r, 1, 'A. Probit regression statistics', { sz: 10, b: true, i: true, h: 'left' }); s3r++;
    ['Treatment', 'Slope ± SE', 'Intercept ± SE', '~t~-ratio (slope)', 'Heterogeneity (χ^{2}/df)', 'Heterogeneous?', '~g~ factor', '~P~ (χ^{2})', 'Common weights'].slice(0, 8).forEach((t, k) => S3.set(s3r, 1 + k, t, k === 0 ? tbl.hdrL : tbl.hdr)); S3.height(s3r, 32); s3r++;
    C.forEach((c, j) => {
      const last = j === N - 1, sp = (h) => ({ sz: 10, h: h || 'center', bB: last ? 'medium' : null });
      [c.name, fx(c.b, 4) + ' ± ' + fx(c.seB, 4), fx(c.a, 4) + ' ± ' + fx(c.seA, 4), fx(c.tRatio, 3), fx(c.H, 3), c.hetero ? 'Yes' : 'No', fx(c.g, 4), fP(c.p)].forEach((v, k) => S3.set(s3r, 1 + k, v, sp(k === 0 ? 'left' : 'center'))); s3r++;
    });
    s3r += 2;
    if (N > 1) {
      S3.set(s3r, 1, 'B. Pairwise lethal-concentration ratio tests (' + MET + '_{50})', { sz: 10, b: true, i: true, h: 'left' }); s3r++;
      ['Treatment A', 'Treatment B', MET + '_{50} A', MET + '_{50} B', 'Ratio A/B', 'Lower 95% CI', 'Upper 95% CI', 'Result'].forEach((t, k) => S3.set(s3r, 1 + k, t, k < 2 ? tbl.hdrL : tbl.hdr)); S3.height(s3r, 30); s3r++;
      const pairs = []; for (let a = 0; a < N; a++) for (let b = a + 1; b < N; b++) pairs.push([a, b]);
      pairs.forEach(([a, b], k) => {
        const last = k === pairs.length - 1, rt = D.ratios[a][b], sp = (h, fmt) => ({ sz: 10, h: h || 'center', fmt: fmt || 'General', bB: last ? 'medium' : null });
        S3.set(s3r, 1, C[a].name, sp('left')); S3.set(s3r, 2, C[b].name, sp('left')); S3.set(s3r, 3, lc50(a).dose, sp('center', '0.000')); S3.set(s3r, 4, lc50(b).dose, sp('center', '0.000'));
        S3.set(s3r, 5, { f: A1(s3r, 3) + '/' + A1(s3r, 4), v: lc50(a).dose / lc50(b).dose }, sp('center', '0.000')); S3.set(s3r, 6, rt.lo, sp('center', '0.000')); S3.set(s3r, 7, rt.hi, sp('center', '0.000'));
        S3.set(s3r, 8, rt.sig ? 'Significant (~P~ < 0.05)' : 'Not significant', sp('center')); s3r++;
      });
      s3r += 2;
      S3.set(s3r, 1, 'C. Test of parallelism of the probit lines', { sz: 10, b: true, i: true, h: 'left' }); s3r++;
      if (D.parallel && D.parallel.valid) {
        const P = D.parallel;
        [['Common (weighted) slope', fx(P.commonSlope, 4)], ['χ^{2} (parallelism)', fx(P.chi, 4)], ['Degrees of freedom', String(P.df)], ['Critical χ^{2} (0.05)', fx(P.crit, 3)], ['~P~ value', fP(P.p)], ['Conclusion', P.isParallel ? 'Lines are parallel (hypothesis not rejected)' : 'Lines are not parallel (hypothesis rejected)']].forEach(([a, b], k, arr) => {
          const last = k === arr.length - 1; S3.set(s3r, 1, a, { sz: 10, h: 'left', bT: k === 0 ? 'medium' : null, bB: last ? 'medium' : null }); S3.merge(s3r, 2, s3r, 4, b, { sz: 10, h: 'left', bT: k === 0 ? 'medium' : null, bB: last ? 'medium' : null }); s3r++;
        });
      }
    }

    // =============== Sheet: Equations ===============
    const EQ = Sheet('Equations', st, { tab: 'BF9000' });
    EQ.width(1, 38); EQ.width(2, 62); EQ.width(3, 70);
    EQ.merge(1, 1, 1, 3, 'Statistical laws and equations used in the analysis', S.capB); EQ.height(1, 20);
    ['Law and reference', 'Formula', 'Application'].forEach((t, k) => EQ.set(3, 1 + k, t, k === 0 ? tbl.hdrL : Object.assign({}, tbl.hdr, { h: 'left' }))); EQ.height(3, 20);
    (D.equations || []).forEach((e, k, arr) => {
      const last = k === arr.length - 1, sp = Object.assign({ sz: 10, h: 'left', v: 'top', wrap: true }, last ? { bB: 'medium' } : {});
      EQ.set(4 + k, 1, e.title, Object.assign({}, sp, { b: true })); EQ.set(4 + k, 2, e.formula, sp); EQ.set(4 + k, 3, e.desc, sp);
      EQ.height(4 + k, Math.max(paraHeight(e.formula, 62, 10), paraHeight(e.desc, 70, 10), paraHeight(e.title, 38, 10)));
    });

    CD.height(1, 20);
    const out = [R, S1, S2, S3, CD, EQ];
    return packageXlsx(out, st, { title: MET + ' probit analysis report', author: M.researcher || 'AI TOX' });
  }

  root.AITOX_XLSX = { build, _letters: letters };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.AITOX_XLSX;
})(typeof window !== 'undefined' ? window : globalThis);
