    // =========================================================================
    // EXCEL SCIENTIFIC REPORT (.xlsx) — Springer-style tables + native charts
    // =========================================================================
    function aitoxHtmlToText(h) {
      const sub = { '0': '₀', '1': '₁', '2': '₂', '3': '₃', '4': '₄', '5': '₅', '6': '₆', '7': '₇', '8': '₈', '9': '₉' };
      const sup = { '0': '⁰', '1': '¹', '2': '²', '3': '³', '4': '⁴', '5': '⁵', '6': '⁶', '7': '⁷', '8': '⁸', '9': '⁹' };
      const ent = { minus: '−', times: '×', plusmn: '±', chi: 'χ', middot: '·', ndash: '–', mdash: '—', le: '≤', ge: '≥', lt: '<', gt: '>', amp: '&', nbsp: ' ', alpha: 'α', beta: 'β', sigma: 'σ', Sigma: 'Σ', mu: 'μ', rho: 'ρ', theta: 'θ', lambda: 'λ', infin: '∞', radic: '√', asymp: '≈', ne: '≠', deg: '°', sum: 'Σ', Phi: 'Φ', phi: 'φ', Delta: 'Δ', delta: 'δ', hellip: '…', quot: '"', apos: "'" };
      return String(h || '')
        .replace(/<sub>([\s\S]*?)<\/sub>/gi, (m, x) => { const t = x.replace(/<[^>]+>/g, ''); return /^[0-9]+$/.test(t) ? t.replace(/[0-9]/g, d => sub[d]) : '_' + t; })
        .replace(/<sup>([\s\S]*?)<\/sup>/gi, (m, x) => { const t = x.replace(/<[^>]+>/g, ''); return /^[0-9]+$/.test(t) ? t.replace(/[0-9]/g, d => sup[d]) : '^' + t; })
        .replace(/<br\s*\/?>/gi, ' ').replace(/<[^>]+>/g, '')
        .replace(/&#(\d+);/g, (m, n) => String.fromCharCode(+n)).replace(/&([a-zA-Z]+);/g, (m, n) => ent[n] !== undefined ? ent[n] : m)
        .replace(/\s+/g, ' ').trim();
    }
    function buildExcelReportData() {
      const valid = APP_STATE.results.filter(r => r && r.valid);
      const rs = APP_STATE.researcher || { name: 'Authorized Researcher', specialty: 'Toxicology & Bioassay', college: '', university: '' };
      const exp = APP_STATE.experiment;
      const levelOf = (r, p) => r.levels.find(l => l.pct === p);
      const compounds = valid.map((r, idx) => ({
        name: r.compound.name || ('Compound ' + (idx + 1)),
        color: r.compound.color || PALETTE[idx % PALETTE.length],
        controlTotal: r.controlTotal, controlDead: r.controlDead, controlPct: r.controlPct,
        doses: r.dosePoints.map(d => ({ conc: d.conc, logConc: d.logConc, total: d.total, dead: d.obsDead, obsPct: d.obsPct, corrPct: d.corrPct, empProbit: d.empiricalProbit, expPct: d.expectedPct, expProbit: d.expectedProbit, chi: d.chiContrib })),
        a: r.a, seA: r.seA, b: r.b, seB: r.seB, r: r.corrR, r2: r.rSquared, chi: r.chiSquare, df: r.df, chiCrit: r.chiCrit, p: r.pValue,
        H: r.heterogeneityH, hetero: r.isHeterogeneous, g: r.gFactor, tRatio: r.tRatio,
        levels: r.levels.map(l => ({ pct: l.pct, probit: l.probitY, logDose: l.logDose, dose: l.dose, lo: l.lowerDose, hi: l.upperDose }))
      }));
      const ratios = valid.map((ri, i) => valid.map((rj, j) => {
        if (i === j) return null;
        const t = calcRobertsonRatioTest(ri, rj);
        return { ratio: t.ratio, lo: t.lowerRatio, hi: t.upperRatio, sig: t.isSignificant };
      }));
      const par = calcParallelismTest(valid);
      return {
        meta: { researcher: rs.name, specialty: rs.specialty, college: rs.college, university: rs.university, organism: exp.organismName, metric: exp.metricType || 'LC', unit: exp.unit || '', exposure: exp.exposureTime, date: new Date().toLocaleDateString('en-US') },
        compounds, ratios,
        parallel: par.valid ? { valid: true, commonSlope: par.commonSlope, chi: par.chiParallel, df: par.df, p: par.pVal, crit: par.crit, isParallel: par.isParallel } : { valid: false },
        equations: TOXICOLOGY_EQUATIONS_LIST.map(e => ({ title: aitoxHtmlToText(e.title), formula: aitoxHtmlToText(e.wordFormula), desc: aitoxHtmlToText(e.desc) }))
      };
    }
    function aitoxBytesToBase64(bytes) {
      let bin = ''; const CH = 0x8000;
      for (let i = 0; i < bytes.length; i += CH) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + CH));
      return btoa(bin);
    }
    async function exportExcelReport() {
      const valid = APP_STATE.results.filter(r => r && r.valid);
      if (valid.length === 0) { showToast('No valid bioassay results to export.'); return; }
      showToast('Building the Excel report...');
      try {
        const bytes = AITOX_XLSX.build(buildExcelReportData());
        const rs = APP_STATE.researcher;
        const safe = ((rs && rs.name) || 'Researcher').replace(/[^A-Za-z0-9_\-]+/g, '_');
        const filename = 'AI_TOX_Scientific_Report_' + safe + '.xlsx';
        if (window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform()) {
          const Fs = window.Capacitor.Plugins.Filesystem, Sh = window.Capacitor.Plugins.Share;
          const w = await Fs.writeFile({ path: filename, data: aitoxBytesToBase64(bytes), directory: 'CACHE' });
          await Sh.share({ title: filename, url: w.uri, dialogTitle: 'AI TOX Excel report' });
        } else {
          const blob = new Blob([bytes], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
          const url = URL.createObjectURL(blob), a = document.createElement('a');
          a.href = url; a.download = filename; document.body.appendChild(a); a.click(); document.body.removeChild(a);
          setTimeout(() => URL.revokeObjectURL(url), 4000);
        }
        showToast('Excel report ready.');
      } catch (err) { showToast('Excel export failed: ' + (err && err.message ? err.message : err)); }
    }
