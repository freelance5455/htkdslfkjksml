REAMAB V2 - Premium Smart Salary & Expense Manager

V2 includes the V1 base plus Premium foundations:
- Analytics and budget score
- Savings goals and monthly target calculation
- REAMAB AI advisor with local smart analysis
- Optional secure AI backend endpoint
- Premium reports/PDF print
- JSON backup
- Existing V1 budget/name/theme/language/currency/notes/expenses functionality
- 5-language foundation retained from V1

AI SECURITY:
Never embed a secret AI API key in the client app. For production, connect REAMAB V2 to your own secure backend endpoint. The endpoint receives the user's question and financial data needed for analysis.

APK:
This is a web/Capacitor source project. Android APK compilation requires the Android/Capacitor build environment.
