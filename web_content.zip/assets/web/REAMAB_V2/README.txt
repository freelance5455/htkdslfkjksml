REAMAB V2 - Premium Smart Salary & Expense Manager

V2 includes the V1 base plus Premium foundations:
- Analytics and budget score
- Savings goals and monthly target calculation
- Premium reports/PDF print
- JSON backup
- Existing V1 budget/name/theme/language/currency/notes/expenses functionality


APK:
This is a web/Capacitor source project. Android APK compilation requires the Android/Capacitor build environment.
