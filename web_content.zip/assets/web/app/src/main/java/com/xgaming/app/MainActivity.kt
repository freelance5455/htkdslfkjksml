package com.xgaming.app

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.os.Build
import android.Manifest
import android.webkit.*
import android.widget.Toast

class MainActivity : Activity() {
    private val connectivityReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: android.content.Context?, intent: Intent?) {
            updateNetworkState()
        }
    }

    private fun hasInternet(): Boolean {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    private fun updateNetworkState() {
        if (::web.isInitialized) {
            val online = hasInternet()
            web.evaluateJavascript("window.nativeNetworkState && window.nativeNetworkState(" + online + ");", null)
        }
    }
    private lateinit var web: WebView
    private var chooser: ValueCallback<Array<Uri>>? = null
    private val PICK = 4001
    private val STORAGE_PERMISSION_REQUEST = 4002

    private fun requestStorageAccess() {
        if (Build.VERSION.SDK_INT >= 33) {
            val permissions = arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
            val missing = permissions.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }.toTypedArray()
            if (missing.isNotEmpty()) requestPermissions(missing, STORAGE_PERMISSION_REQUEST)
        } else if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), STORAGE_PERMISSION_REQUEST)
        }
    }

    private fun openTelegramSafely(uriString: String = "tg://resolve?domain=XGamesMods") {
        val telegramUri = Uri.parse(uriString)
        val packages = listOf("org.telegram.messenger", "org.thunderdog.challegram")
        for (pkg in packages) {
            try {
                val intent = Intent(Intent.ACTION_VIEW, telegramUri).apply { setPackage(pkg) }
                if (intent.resolveActivity(packageManager) != null) {
                    startActivity(intent)
                    return
                }
            } catch (_: Exception) { }
        }
        try {
            val generic = Intent(Intent.ACTION_VIEW, telegramUri)
            if (generic.resolveActivity(packageManager) != null) {
                startActivity(generic)
                return
            }
        } catch (_: Exception) { }
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/XGamesMods")))
        } catch (_: Exception) {
            Toast.makeText(this, "تعذر فتح تيليجرام", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        web.addJavascriptInterface(object {
            @JavascriptInterface fun isOnline(): Boolean = hasInternet()
            @JavascriptInterface fun requestStoragePermission() {
                runOnUiThread { requestStorageAccess() }
            }
            @JavascriptInterface fun openTelegram() {
                runOnUiThread { openTelegramSafely() }
            }
        }, "XGNetwork")
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                chooser?.onReceiveValue(null)
                chooser = filePathCallback
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    val accepts = fileChooserParams?.acceptTypes?.filter { it.isNotBlank() } ?: emptyList()
                    type = if (accepts.any { it.startsWith("image/") }) "image/*" else "*/*"
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, fileChooserParams?.mode == FileChooserParams.MODE_OPEN_MULTIPLE)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                }
                try { startActivityForResult(intent, PICK) }
                catch (e: Exception) {
                    chooser = null
                    Toast.makeText(this@MainActivity, "تعذر فتح الملفات", Toast.LENGTH_SHORT).show()
                }
                return true
            }
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val rawUrl = request?.url?.toString() ?: return false
                val url = try { Uri.decode(rawUrl) } catch (_: Exception) { rawUrl }
                val lower = url.lowercase()
                if (lower.startsWith("tg://") || lower.startsWith("tg:")) {
                    openTelegramSafely(url)
                    return true
                }
                if (lower.startsWith("https://t.me/") || lower.startsWith("http://t.me/")) {
                    openTelegramSafely()
                    return true
                }
                if (lower.startsWith("http://") || lower.startsWith("https://")) {
                    try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) { }
                    return true
                }
                return false
            }
        }
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)
        registerReceiver(connectivityReceiver, android.content.IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION))
        web.postDelayed({ updateNetworkState() }, 300)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK) {
            val results = if (resultCode == RESULT_OK && data != null) {
                val clip = data.clipData
                if (clip != null) Array(clip.itemCount) { clip.getItemAt(it).uri }
                else data.data?.let { arrayOf(it) }
            } else null
            chooser?.onReceiveValue(results)
            chooser = null
        }
    }

    override fun onDestroy() {
        try { unregisterReceiver(connectivityReceiver) } catch (_: Exception) { }
        super.onDestroy()
    }

    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
