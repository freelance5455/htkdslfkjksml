const CATS=["كل الألعاب","أكشن","مغامرات","رياضة","سباق","استراتيجية","رعب","ألعاب خفيفة","تطبيقات"];
const TELEGRAM="https://t.me/XGamesMods";
const ADMIN_PASSWORD="XG@1234";
// ضع هنا رابط السيرفر بعد رفعه، مثال: https://your-domain.com/api
const SERVER_API="https://xgaming-api-1scl-production.up.railway.app/api";
let active="كل الألعاب", games=[];
let imageLibrary=[];
const $=id=>document.getElementById(id);
// الاتصال بالإنترنت والسيرفر
const networkOverlay = () => $("networkOverlay");
const serverStatus = () => $("serverStatus");
const serverStatusText = () => $("serverStatusText");
let serverOnline = false;
function setNetworkUI(online){
  networkOverlay()?.classList.toggle("show", !online);
}
function setServerUI(online, text){
  serverOnline=!!online;
  const box=serverStatus();
  if(!box)return;
  box.classList.toggle("online",!!online); box.classList.toggle("offline",!online);
  serverStatusText().textContent=text || (online?"السيرفر متصل":"السيرفر غير متاح");
}
function nativeOnline(){try{return window.XGNetwork ? !!window.XGNetwork.isOnline() : navigator.onLine!==false}catch(e){return navigator.onLine!==false}}
window.nativeNetworkState=function(online){setNetworkUI(!!online);if(online) refreshRemoteState()};
async function checkServer(){
  if(!serverReady()){setServerUI(false,"السيرفر غير مُعد");return false}
  if(!nativeOnline()){setServerUI(false,"لا يوجد إنترنت");return false}
  try{
    await apiFetch("/games",{cache:"no-store"});
    setServerUI(true,"السيرفر متصل"); return true;
  }catch(e){
    setServerUI(false,"السيرفر غير متاح"); return false;
  }
}
async function refreshRemoteState(){
  setNetworkUI(nativeOnline());
  if(nativeOnline()) { await checkServer(); await loadServerGames(); await loadImageLibrary(); await renderGames(); }
}
window.addEventListener("online",()=>refreshRemoteState());
window.addEventListener("offline",()=>{setNetworkUI(false);setServerUI(false,"لا يوجد إنترنت")});
if($("networkRetry")) $("networkRetry").onclick=()=>refreshRemoteState();

function save(){localStorage.setItem("xg_games",JSON.stringify(games))}
function placeholder(name){return "data:image/svg+xml;charset=UTF-8,"+encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="600" height="440"><defs><linearGradient id="g" x1="0" x2="1"><stop stop-color="#170c24"/><stop offset="1" stop-color="#5b16a0"/></linearGradient></defs><rect width="100%" height="100%" fill="url(#g)"/><text x="50%" y="52%" text-anchor="middle" fill="white" font-size="34" font-family="Arial">${name||"GAME"}</text></svg>`) }

// مكتبة صور دائمة داخل الجهاز باستخدام IndexedDB حتى لا تمتلئ localStorage بسهولة.
const DB_NAME="xgaming_media", DB_VERSION=1, STORE="images";
function openDB(){return new Promise((resolve,reject)=>{const r=indexedDB.open(DB_NAME,DB_VERSION);r.onupgradeneeded=()=>{if(!r.result.objectStoreNames.contains(STORE))r.result.createObjectStore(STORE,{keyPath:"id"})};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
async function dbPut(item){const db=await openDB();return new Promise((res,rej)=>{const tx=db.transaction(STORE,"readwrite");tx.objectStore(STORE).put(item);tx.oncomplete=()=>res();tx.onerror=()=>rej(tx.error)})}
async function dbGetAll(){const db=await openDB();return new Promise((res,rej)=>{const tx=db.transaction(STORE,"readonly");const r=tx.objectStore(STORE).getAll();r.onsuccess=()=>res(r.result||[]);r.onerror=()=>rej(r.error)})}
async function dbDelete(id){const db=await openDB();return new Promise((res,rej)=>{const tx=db.transaction(STORE,"readwrite");tx.objectStore(STORE).delete(id);tx.oncomplete=()=>res();tx.onerror=()=>rej(tx.error)})}
async function loadImageLibrary(){
  try{
    imageLibrary=await dbGetAll(); await migrateOldImages();
    if(serverReady()){
      const remote=await apiFetch("/images");
      imageLibrary=remote.map(x=>({id:x.id,name:x.name,data:x.url,remote:true})).concat(imageLibrary.filter(x=>!x.remote));
    }
  }catch(e){imageLibrary=await dbGetAll()}
}
async function migrateOldImages(){let changed=false;for(const g of games){if(g.image && !g.imageId){const id="legacy_"+g.id;await dbPut({id,name:g.name+" - صورة اللعبة",data:g.image,created:g.id});g.imageId=id;delete g.image;changed=true}}if(changed)save();imageLibrary=await dbGetAll()}

function renderCats(){
  $("chips").innerHTML=CATS.map(c=>`<button class="chip ${c===active?"active":""}" data-cat="${c}">${c}</button>`).join("");
  $("drawerCats").innerHTML=CATS.slice(1).map(c=>`<button class="nav" data-cat="${c}">🎮 <span>${c}</span></button>`).join("");
  $("gCat").innerHTML=CATS.slice(1).map(c=>`<option>${c}</option>`).join("");
  document.querySelectorAll("[data-cat]").forEach(x=>x.onclick=()=>{active=x.dataset.cat;renderCats();renderGames();closeDrawer()});
}
async function imageDataForGame(g){
  if(g.imageUrl)return g.imageUrl;
  if(g.imageId){const found=imageLibrary.find(x=>x.id===g.imageId);if(found)return found.data}
  return g.image||placeholder(g.name);
}
async function renderGames(){
  const q=$("search").value.trim().toLowerCase();
  const list=games.filter(g=>(active==="كل الألعاب"||g.cat===active)&&(!q||g.name.toLowerCase().includes(q)));
  const cards=await Promise.all(list.map(async g=>`<article class="card"><img class="cover" loading="lazy" decoding="async" src="${esc(await imageDataForGame(g))}"><div class="cardBody"><div class="cardTitle">${esc(g.name)}</div><div class="meta">الإصدار ${esc(g.version||"1.0")} · ${esc(g.size||"روابط اللعبة")}</div><span class="tag">${esc(g.cat)}</span><div class="cardLinks">${linkButton(g.apk,"APK")}${linkButton(g.obb,"OBB")}${linkButton(g.data,"DATA")}</div></div></article>`));
  $("games").innerHTML=cards.join(""); $("empty").style.display=list.length?"none":"block";
}
function esc(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function closeDrawer(){$("drawer").classList.remove("open");$("drawerBack").classList.remove("open")}
$("menuBtn").onclick=()=>{$("drawer").classList.add("open");$("drawerBack").classList.add("open")}
$("closeDrawer").onclick=closeDrawer;$("drawerBack").onclick=closeDrawer;
$("themeBtn").onclick=()=>{document.body.classList.toggle("light");localStorage.setItem("xg_theme",document.body.classList.contains("light")?"light":"dark");$("themeBtn").textContent=document.body.classList.contains("light")?"☀":"☾"}
$("search").oninput=renderGames;
$("allBtn").onclick=()=>{active="كل الألعاب";renderCats();renderGames()};
$("reportOpen").onclick=()=>{$("reportModal").classList.add("show");closeDrawer();$("reportText").focus()};
$("adminOpen").onclick=()=>{try{window.XGNetwork&&window.XGNetwork.requestStoragePermission()}catch(e){} $("loginModal").classList.add("show");closeDrawer();$("adminPass").focus()};
$("sendReport").onclick=sendProblemReport;
document.querySelectorAll("[data-close]").forEach(b=>b.onclick=()=>b.closest(".modal").classList.remove("show"));
$("loginBtn").onclick=async()=>{if($("adminPass").value===ADMIN_PASSWORD){$("loginModal").classList.remove("show");$("adminModal").classList.add("show");$("adminPass").value="";renderAdmin();renderImageLibrary();await loadComplaints()}else $("loginError").textContent="كلمة المرور غير صحيحة"};
async function sendProblemReport(){
  const text=$("reportText").value.trim(), name=$("reportName").value.trim();
  $("reportError").textContent="";
  if(!text){$("reportError").textContent="اكتب المشكلة الأول";return}
  if(!serverReady()||!nativeOnline()){$("reportError").textContent="لا يوجد اتصال بالسيرفر حالياً. اتصل بالإنترنت وحاول مرة أخرى.";return}
  const btn=$("sendReport");btn.disabled=true;btn.textContent="جاري الإرسال...";
  try{
    await apiFetch("/complaints",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message:text,name,deviceId:getDeviceId(),appVersion:"X Gaming"})});
    $("reportText").value="";$("reportName").value="";$("reportModal").classList.remove("show");alert("تم إرسال المشكلة للمسؤول بنجاح ❤️");
  }catch(e){$("reportError").textContent="حصلت مشكلة أثناء الإرسال. حاول مرة تانية."}
  finally{btn.disabled=false;btn.textContent="إرسال المشكلة"}
}
async function loadComplaints(){
  const box=$("adminComplaints");if(!box)return;
  if(!serverReady()||!nativeOnline()){box.innerHTML='<div class="complaintEmpty">تعذر تحميل مشاكل المستخدمين حالياً.</div>';return}
  try{
    const result=await apiFetch("/complaints",{headers:{Authorization:"Bearer "+ADMIN_PASSWORD}});
    const list=Array.isArray(result)?result:(Array.isArray(result.complaints)?result.complaints:[]);
    box.innerHTML='<h3>مشاكل المستخدمين</h3>'+ (list.length?list.map(c=>`<div class="complaintItem"><b>${esc(c.name||"مستخدم بدون اسم")}</b><br><small>${esc(c.created_at||c.createdAt||"")} · ${esc(c.deviceId||"")}</small><div class="complaintText">${esc(c.message||"")}</div><button type="button" class="del complaintDelete" data-complaint="${esc(c.id)}">حذف البلاغ</button></div>`).join(""):'<div class="complaintEmpty">مفيش مشاكل جديدة.</div>');
  box.querySelectorAll(".complaintDelete").forEach(btn=>btn.onclick=async()=>{if(!confirm("حذف البلاغ ده؟"))return;try{await apiFetch("/complaints/"+encodeURIComponent(btn.dataset.complaint),{method:"DELETE",headers:{Authorization:"Bearer "+ADMIN_PASSWORD}});await loadComplaints()}catch(e){alert("تعذر حذف البلاغ حالياً")}});
  }catch(e){box.innerHTML='<div class="complaintEmpty">تعذر تحميل مشاكل المستخدمين من السيرفر.</div>'}
}
function normalizeUrl(value){const v=String(value||"").trim();if(!v)return "";if(/^https?:\/\//i.test(v)||/^tg:\/\//i.test(v))return v;return "https://"+v}
function serverReady(){return !SERVER_API.includes("YOUR-SERVER-DOMAIN")}
function getDeviceId(){let id=localStorage.getItem("xg_device_id");if(!id){id="xg-"+Date.now().toString(36)+"-"+Math.random().toString(36).slice(2,10);localStorage.setItem("xg_device_id",id)}return id}
async function apiFetch(path, options={}){if(!serverReady())throw new Error("SERVER_NOT_CONFIGURED");const r=await fetch(SERVER_API+path,options);if(!r.ok)throw new Error(await r.text());return r.json()}
async function loadServerGames(){
  if(!serverReady()||!nativeOnline())return;
  try{
    const result=await apiFetch("/games");
    games=Array.isArray(result)?result:(Array.isArray(result.games)?result.games:[]);
    save();
  }catch(e){console.warn("تعذر الاتصال بالسيرفر",e)}
}

$("gImages").onchange=async()=>{
  const files=[...( $("gImages").files||[] )];
  for(const file of files){
    if(!file.type.startsWith("image/"))continue;
    const data=await new Promise((resolve,reject)=>{const fr=new FileReader();fr.onload=()=>resolve(fr.result);fr.onerror=()=>reject(fr.error);fr.readAsDataURL(file)});
    const id="img_"+Date.now()+"_"+Math.random().toString(36).slice(2);
    // احفظ الصورة داخل مكتبة التطبيق أولاً حتى تعمل حتى لو API الصور غير متاح.
    await dbPut({id,name:file.name,data,created:Date.now()});
    // لو السيرفر عنده API للصور ارفع نسخة له أيضاً، لكن لا تمنع المكتبة المحلية.
    if(serverReady()){
      try{const fd=new FormData(); fd.append("image",file); await apiFetch("/images",{method:"POST",headers:{Authorization:"Bearer "+ADMIN_PASSWORD},body:fd})}catch(e){console.warn("تعذر رفع الصورة للسيرفر، تم حفظها محلياً",e)}
    }
  }
  $("gImages").value=""; await loadImageLibrary(); renderImageLibrary();
};
let selectedImageId="";
function renderImageLibrary(){
  const box=$("imageLibrary");if(!box)return;
  if(!imageLibrary.length){box.innerHTML='<div class="emptyImages">لا توجد صور في المكتبة بعد.</div>';return}
  box.innerHTML=imageLibrary.map(img=>`<div class="libItem ${selectedImageId===img.id?"selected":""}" data-img="${esc(img.id)}"><img src="${esc(img.data)}"><div class="libName">${esc(img.name)}</div><button type="button" class="pickImg">${selectedImageId===img.id?"✓ مختارة":"اختيار"}</button><button type="button" class="deleteImg">حذف</button></div>`).join("");
  box.querySelectorAll(".libItem").forEach(el=>{const id=el.dataset.img;el.querySelector(".pickImg").onclick=()=>{selectedImageId=id;renderImageLibrary()};el.querySelector(".deleteImg").onclick=async()=>{if(!confirm("حذف الصورة من المكتبة؟"))return;await dbDelete(id);if(selectedImageId===id)selectedImageId="";imageLibrary=await dbGetAll();renderImageLibrary()}})
}

$("addGame").onclick=async()=>{
 const name=$("gName").value.trim(); if(!name){alert("اكتب اسم اللعبة");return}
 if(!selectedImageId && imageLibrary.length){alert("اختر صورة الغلاف للعبة");return}
 const apkUrl=normalizeUrl($("gApk").value), obbUrl=normalizeUrl($("gObb").value), dataUrl=normalizeUrl($("gData").value);
 const picked=imageLibrary.find(x=>x.id===selectedImageId);
 const safeId=(name.toLowerCase().replace(/[^a-z0-9\u0600-\u06ff]+/g,"-").replace(/^-+|-+$/g,"").slice(0,50)||"game")+"-"+Date.now();
 const payload={id:safeId,name,version:$("gVersion").value||"1.0",cat:$("gCat").value,desc:$("gDesc").value,imageId:selectedImageId,imageUrl:picked?.remote?picked.data:"",apk:apkUrl,obb:obbUrl,data:dataUrl};
 try{
   if(serverReady()){await apiFetch("/games",{method:"POST",headers:{"Content-Type":"application/json",Authorization:"Bearer "+ADMIN_PASSWORD},body:JSON.stringify(payload)});await loadServerGames();alert("تم نشر اللعبة، وستظهر عند جميع مستخدمي التطبيق بعد تحديث البيانات.")}
   else{games.unshift({...payload,id:Date.now(),size:""});save();alert("تم نشر اللعبة على هذا الجهاز. اربط SERVER_API بسيرفر حتى تظهر للجميع.")}
 }catch(e){alert("تعذر نشر اللعبة على السيرفر");return}
 renderGames();renderAdmin();["gName","gVersion","gDesc","gApk","gObb","gData"].forEach(id=>$(id).value="");selectedImageId="";renderImageLibrary();
};
function linkButton(url,label){if(!url)return "";return `<a class="fileLink" href="${esc(url)}" target="_blank" rel="noopener">${label}</a>`}
async function renderAdmin(){
 $("adminGames").innerHTML=games.length?games.map(g=>`<div class="adminItem"><div><b>${esc(g.name)}</b><br><small>${esc(g.cat)} · APK: ${g.apk?"موجود":"—"} · OBB: ${g.obb?"موجود":"—"} · DATA: ${g.data?"موجود":"—"}</small></div><div>${g.apk?`<a class="del linkBtn" href="${esc(g.apk)}" target="_blank" rel="noopener">APK</a>`:""} ${g.obb?`<a class="del linkBtn" href="${esc(g.obb)}" target="_blank" rel="noopener">OBB</a>`:""} ${g.data?`<a class="del linkBtn" href="${esc(g.data)}" target="_blank" rel="noopener">DATA</a>`:""} <button class="del" onclick="removeGame(${JSON.stringify(g.id).replace(/</g,"\u003c")})">حذف</button></div></div>`).join(""):"<small>لا توجد ألعاب مضافة.</small>";
}
async function removeGame(id){
  try{
    const gameId=String(id);
    if(serverReady() && nativeOnline()){
      await apiFetch("/games/"+encodeURIComponent(gameId),{method:"DELETE",headers:{Authorization:"Bearer "+ADMIN_PASSWORD}});
      games=games.filter(g=>String(g.id)!==gameId);
      save();
      await loadServerGames();
    }else{
      games=games.filter(g=>String(g.id)!==gameId);
      save();
    }
    renderAdmin();renderGames();
  }catch(e){
    // لا تسيب اللعبة ظاهرة في لوحة الإدارة لو السيرفر غير متاح؛ احذفها من النسخة المحلية.
    games=games.filter(g=>String(g.id)!==String(id));
    save();renderAdmin();renderGames();
    alert("تم حذف اللعبة من التطبيق. السيرفر غير متاح حالياً، لذلك لن يتم مزامنة الحذف معه حتى يعود للعمل.");
  }
}
$("telegramFloat").onclick=(e)=>{e.preventDefault();try{if(window.XGNetwork&&window.XGNetwork.openTelegram){window.XGNetwork.openTelegram();return}}catch(err){} window.location.href=TELEGRAM};
if(localStorage.getItem("xg_theme")==="light"){$("themeBtn").textContent="☀";document.body.classList.add("light")}
(async()=>{
  setNetworkUI(nativeOnline());
  renderCats();
  if(nativeOnline()){
    await checkServer();
    await loadServerGames();
    await loadImageLibrary();
  } else setServerUI(false,"لا يوجد إنترنت");
  await renderGames();
})();
