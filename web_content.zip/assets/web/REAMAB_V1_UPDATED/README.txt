REAMAB V1 - Updated Build

Updates in this version:
- 5 languages: Arabic, English, French, Swahili, Spanish.
- Unified gradient visual identity across themes and interface elements.
- Seven cohesive theme choices: Olive, Green, Pink, Purple, Silver, Beige, White.
- PDF actions: Export/Save PDF and Print PDF.
- Notes are saved locally inside the app as separate notes and remain available in My Notes.
- Import/export data supports the updated notes structure and migrates older saved notes.
