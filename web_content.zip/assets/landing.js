(() => {
  'use strict';
  const toggle = document.getElementById('menuToggle');
  const menu = document.getElementById('mobileMenu');
  if (toggle && menu) {
    toggle.addEventListener('click', () => {
      const open = menu.hidden;
      menu.hidden = !open;
      toggle.setAttribute('aria-expanded', String(open));
      toggle.setAttribute('aria-label', open ? 'Close navigation' : 'Open navigation');
      toggle.textContent = open ? '×' : '☰';
    });
    menu.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
      menu.hidden = true;
      toggle.setAttribute('aria-expanded', 'false');
      toggle.setAttribute('aria-label', 'Open navigation');
      toggle.textContent = '☰';
    }));
  }
  document.querySelectorAll('a[href^="#"]').forEach(link => link.addEventListener('click', () => {
    if (menu && !menu.hidden) {
      menu.hidden = true;
      if (toggle) { toggle.setAttribute('aria-expanded', 'false'); toggle.textContent = '☰'; }
    }
  }));

  // Duplicate the services row for a seamless marquee; keep clones out of keyboard navigation.
  const serviceTrack = document.querySelector('.service-track');
  if (serviceTrack && !serviceTrack.querySelector('.service-set')) {
    const original = document.createElement('div');
    original.className = 'service-set';
    while (serviceTrack.firstChild) original.appendChild(serviceTrack.firstChild);
    const clone = original.cloneNode(true);
    clone.setAttribute('aria-hidden', 'true');
    clone.querySelectorAll('a').forEach(link => link.setAttribute('tabindex', '-1'));
    serviceTrack.append(original, clone);
  }
})();
