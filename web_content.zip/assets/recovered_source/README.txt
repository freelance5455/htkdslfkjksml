MINDMATE AI — ZIPPED SITE PACKAGE

IMPORTANT: index.html is at the ROOT of this ZIP, as required by Zipped Site.

HOW TO USE
1. Upload this ZIP to your Zipped Site builder.
2. Preview the site.
3. Open Settings > AI connection.
4. Enter your own Gemini API key, select a model, and tap Test connection.
5. Save changes and start chatting.

DEFAULT MODEL
Gemini 3.5 Flash-Lite (gemini-3.5-flash-lite)
Other available choices are in Settings.

CHAT MANAGEMENT
- New chat button creates a conversation.
- Recent chat items can be long-pressed/right-clicked to rename, save, unsave, or delete.
- Saved chats and Unsaved chats are separate filters.
- Settings > Data lets you export chats or delete all chats.
- Conversations and settings are stored in browser local storage on this device.

SECURITY NOTE
This is a static client-side app. A Gemini API key entered here is stored locally in this browser and sent to Google's Gemini API when you chat. Do not publish a build containing your personal API key. For a public app, use a secure backend to protect API credentials.

MODEL NOTE
Gemini model availability and access depend on your Google AI account and API key. The app cannot guarantee access to every model.
