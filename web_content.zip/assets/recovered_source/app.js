(() => {
  const $ = (s) => document.querySelector(s);
  const $$ = (s) => [...document.querySelectorAll(s)];
  const KEY = 'mindmate_v3_data';
  const defaults = { chats: [], activeId: null, theme: 'dark', model: 'gemini-3.5-flash-lite', apiKey: '' };
  let state;
  try { state = {...defaults, ...JSON.parse(localStorage.getItem(KEY) || '{}')}; } catch { state = {...defaults}; }
  let busy = false, view = 'all';
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(state)); } catch { toast('Storage is full. Export chats and clear old conversations.'); } };
  const id = () => Date.now().toString(36) + Math.random().toString(36).slice(2,7);
  const toast = (s) => { const el=$('#toast'); el.textContent=s; el.classList.add('show'); setTimeout(()=>el.classList.remove('show'),2300); };
  const active = () => state.chats.find(c=>c.id===state.activeId);
  const titleOf = c => c.title || 'New conversation';
  const escapeHTML = s => String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function applyTheme(){ document.body.classList.toggle('light',state.theme==='light' || (state.theme==='system' && matchMedia('(prefers-color-scheme: light)').matches)); $('#themeSelect').value=state.theme; }
  function render(){
    const chats = state.chats.filter(c=>view==='saved'?c.saved:view==='unsaved'?!c.saved:true);
    $('#chatList').innerHTML = chats.slice().reverse().map(c=>`<div class="chat-entry ${c.id===state.activeId?'selected':''}" data-id="${c.id}"><span>◦</span><span>${escapeHTML(titleOf(c))}</span></div>`).join('') || '<div style="padding:10px;color:var(--muted);font-size:11px">No conversations yet</div>';
    $('#savedCount').textContent=state.chats.filter(c=>c.saved).length;
    $('#modelChip').textContent=state.model.replace('gemini-','Gemini ').replaceAll('-',' ').replace(/\bflash\b/gi,'Flash').replace(/\blite\b/gi,'Lite').replace(/\b\w/g,m=>m.toUpperCase());
    const c=active(); $('#topTitle').textContent=c?titleOf(c):'New conversation';
    $('#welcome').hidden=!!(c && c.messages.length); $('#messages').innerHTML='';
    if(c) c.messages.forEach(m=>appendMessage(m.role,m.text,false));
    $$('.nav-item[data-view]').forEach(b=>b.classList.toggle('active',b.dataset.view===view));
  }
  function appendMessage(role,text,scroll=true){
    const el=document.createElement('div'); el.className='message '+(role==='user'?'user':'assistant');
    if(role==='user') el.innerHTML=`<div class="bubble">${escapeHTML(text)}</div>`;
    else el.innerHTML=`<div class="message-icon">✦</div><div class="bubble">${escapeHTML(text)}</div>`;
    $('#messages').append(el); if(scroll) el.scrollIntoView({behavior:'smooth',block:'end'});
  }
  function newChat(){const c={id:id(),title:'New conversation',saved:false,messages:[],updated:Date.now()};state.chats.push(c);state.activeId=c.id;view='all';save();render();$('#messageInput').focus();}
  function requireChat(){if(!active())newChat();return active();}
  async function send(text){
    text=text.trim(); if(!text||busy)return; const c=requireChat(); c.messages.push({role:'user',text}); if(c.messages.length===1)c.title=text.slice(0,42)+(text.length>42?'…':''); c.updated=Date.now(); save();
    $('#welcome').hidden=true; appendMessage('user',text); $('#messageInput').value='';$('#messageInput').style.height='auto';busy=true;$('#sendBtn').disabled=true;
    const typing=document.createElement('div');typing.className='message assistant';typing.innerHTML='<div class="message-icon">✦</div><div class="bubble typing">MindMate is thinking…</div>';$('#messages').append(typing);typing.scrollIntoView({behavior:'smooth',block:'end'});
    try{
      if(!state.apiKey) throw new Error('Add your Gemini API key in Settings → AI connection first.');
      const history=c.messages.slice(-24).map(m=>({role:m.role==='assistant'?'model':'user',parts:[{text:m.text}]}));
      const response=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(state.model)}:generateContent?key=${encodeURIComponent(state.apiKey)}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({contents:history,generationConfig:{temperature:0.7,maxOutputTokens:4096}})});
      const data=await response.json(); if(!response.ok) throw new Error(data.error?.message||`Gemini API error (${response.status})`);
      const answer=data.candidates?.[0]?.content?.parts?.map(p=>p.text||'').join('').trim()||'I could not create a text response. Please try again.';
      typing.remove(); c.messages.push({role:'assistant',text:answer}); c.updated=Date.now(); save(); appendMessage('assistant',answer);
    }catch(e){typing.remove();const msg='Connection issue: '+e.message; c.messages.push({role:'assistant',text:msg});save();appendMessage('assistant',msg);}
    finally{busy=false;$('#sendBtn').disabled=false;renderSidebarOnly();}
  }
  function renderSidebarOnly(){const list=$('#chatList');const c=active();const entries=state.chats.filter(x=>view==='saved'?x.saved:view==='unsaved'?!x.saved:true).slice().reverse();list.innerHTML=entries.map(x=>`<div class="chat-entry ${x.id===state.activeId?'selected':''}" data-id="${x.id}"><span>◦</span><span class="chat-name">${escapeHTML(titleOf(x))}</span><button class="chat-menu" data-menu="${x.id}" aria-label="Chat options">⋯</button></div>`).join('')||'<div style="padding:10px;color:var(--muted);font-size:11px">No conversations yet</div>';$('#savedCount').textContent=state.chats.filter(x=>x.saved).length;$('#topTitle').textContent=c?titleOf(c):'New conversation';}
  function openSettings(tab='general'){$('#settingsModal').hidden=false;document.body.classList.add('settings-open');$('#apiKey').value=state.apiKey;$('#modelSelect').value=state.model;$('#themeSelect').value=state.theme;switchTab(tab);}
  function switchTab(tab){$$('.tab').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));$$('.tab-panel').forEach(p=>p.hidden=p.id!=='tab-'+tab);}
  function closeSettings(){$('#settingsModal').hidden=true;document.body.classList.remove('settings-open');}
  function saveSettings(){try{state.apiKey=$('#apiKey').value.trim();state.model=$('#modelSelect').value;state.theme=$('#themeSelect').value;save();applyTheme();renderSidebarOnly();closeSettings();toast('Settings saved on this device.');}catch(err){console.error('Settings save failed',err);$('#saveStatus').textContent='Could not save settings. Please try again.';toast('Could not save settings.');}}
  async function testConnection(){const key=$('#apiKey').value.trim(),model=$('#modelSelect').value,status=$('#apiStatus');if(!key){status.textContent='Enter your API key first.';return;}status.textContent='Testing connection…';try{const r=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(key)}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({contents:[{parts:[{text:'Reply with the single word Connected.'}]}],generationConfig:{maxOutputTokens:20}})});const d=await r.json();if(!r.ok)throw new Error(d.error?.message||`HTTP ${r.status}`);status.textContent='✓ Connection successful. Save changes to use this model.';}catch(e){status.textContent='Connection failed: '+e.message;}}
  $('#newChat').addEventListener('click',newChat);$('#sendBtn').addEventListener('click',()=>send($('#messageInput').value));$('#messageInput').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();send(e.target.value);}});$('#messageInput').addEventListener('input',e=>{e.target.style.height='auto';e.target.style.height=Math.min(e.target.scrollHeight,150)+'px';});
  $$('.prompt-card').forEach(b=>b.addEventListener('click',()=>{if(!active())newChat();$('#messageInput').value=b.dataset.prompt;$('#messageInput').focus();}));
  $$('.nav-item[data-view]').forEach(b=>b.addEventListener('click',()=>{view=b.dataset.view;render();}));
  $('#chatList').addEventListener('click',e=>{const row=e.target.closest('.chat-entry');if(!row)return;state.activeId=row.dataset.id;save();render();});
  $('#chatList').addEventListener('click',e=>{const menu=e.target.closest('[data-menu]');if(!menu)return;e.stopPropagation();const c=state.chats.find(x=>x.id===menu.dataset.menu);if(!c)return;const action=prompt(`Options for ${titleOf(c)}\n1 = Rename\n2 = ${c.saved?'Unsave':'Save'}\n3 = Delete`);if(action==='1'){const t=prompt('New chat name',c.title);if(t)c.title=t.trim();}else if(action==='2'){c.saved=!c.saved;}else if(action==='3'&&confirm('Delete this conversation?')){state.chats=state.chats.filter(x=>x.id!==c.id);if(state.activeId===c.id)state.activeId=null;}save();render();});
  $('#chatList').addEventListener('contextmenu',e=>{const row=e.target.closest('.chat-entry');if(!row)return;e.preventDefault();const c=state.chats.find(x=>x.id===row.dataset.id);const action=prompt(`Chat: ${titleOf(c)}\nType: rename, save, unsave, delete`);if(!action)return;const a=action.toLowerCase();if(a==='rename'){const t=prompt('New chat name',c.title);if(t)c.title=t.trim();}else if(a==='save')c.saved=true;else if(a==='unsave')c.saved=false;else if(a==='delete'){if(confirm('Delete this conversation?')){state.chats=state.chats.filter(x=>x.id!==c.id);if(state.activeId===c.id)state.activeId=null;}}save();render();});
  $('#settingsOpen').addEventListener('click',()=>openSettings());$('#topSettings').addEventListener('click',()=>openSettings());$('#closeSettings').addEventListener('click',closeSettings);$('#settingsModal').addEventListener('click',e=>{if(e.target.id==='settingsModal')closeSettings();});$$('.tab').forEach(b=>b.addEventListener('click',()=>switchTab(b.dataset.tab)));$('#saveSettings').addEventListener('click',saveSettings);$('#testApi').addEventListener('click',testConnection);$('#themeToggle').addEventListener('click',()=>{state.theme=state.theme==='dark'?'light':'dark';save();applyTheme();$('#themeSelect').value=state.theme;});$('#themeSelect').addEventListener('change',e=>{state.theme=e.target.value;applyTheme();});
  $('#exportChats').addEventListener('click',()=>{const blob=new Blob([JSON.stringify(state.chats,null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='mindmate-chats-backup.json';a.click();URL.revokeObjectURL(a.href);});$('#deleteAll').addEventListener('click',()=>{if(confirm('Delete every conversation on this device? This cannot be undone.')){state.chats=[];state.activeId=null;save();render();toast('All conversations deleted.');}});
  $('#menuBtn').addEventListener('click',()=>$('#sidebar').classList.toggle('open'));document.addEventListener('click',e=>{if(innerWidth<=760&&!e.target.closest('#sidebar')&&!e.target.closest('#menuBtn'))$('#sidebar').classList.remove('open');});
  applyTheme();render();
})();
