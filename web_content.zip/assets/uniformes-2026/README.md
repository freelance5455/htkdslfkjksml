# Catálogo de imagens de camisas 2026

As imagens disponíveis são **referências remotas**, não arquivos locais no ZIP. A tela carrega-as pela internet; os servidores podem alterar/remover os arquivos. A permissão para redistribuição não foi confirmada, portanto as imagens não foram copiadas para o pacote. A presença de uma imagem não certifica por si só todos os patrocinadores, patches ou a licença de uso.

**Imagens de referência remotas vinculadas:** 27 / 40
**Arquivos de imagem embutidos no ZIP:** 0

| Clube | Divisão | Status da imagem | Fonte da imagem | Observações |
|---|---|---|---|---|
| Athletico Paranaense | Série A | Referência remota no jogo | [Abrir fonte](https://www.footballkitarchive.com/pt/athletico-paranaense-2026-home-kit/457269/) | front only; sponsor layout incomplete in reference image |
| Atlético Mineiro | Série A | Referência remota no jogo | [Abrir fonte](https://blacksportsfsa.com/camisa-do-atletico-mineiro-i-2026/p) | 2026 design reference; confirm license/sponsor completeness |
| Bahia | Série A | Referência remota no jogo | [Abrir fonte](https://sports.yahoo.com/articles/kit-best-see-2026-brasileir-122500122.html) | 2026 design reference; image host is a proxy, not local |
| Botafogo | Série A | Pendente | [Ficha do uniforme](https://www.footballkitarchive.com/pt/camisa-titular-botafogo-2026-482675/) | Imagem de frente adequada da temporada 2026 ainda não integrada. |
| Chapecoense | Série A | Referência remota no jogo | [Abrir fonte](https://www.ivocamisas.com.br/camisa-chapecoense-titular-2026) | 2026 product image; permission to redistribute not confirmed |
| Corinthians | Série A | Referência remota no jogo | [Abrir fonte](https://www.nike.com.br/camisa-corinthians-nike-i-2026-27-jogador-masculina-098390.html) | Official 2026/27 home shirt image from Nike; sponsor marks vary by competition/version |
| Coritiba | Série A | Referência remota no jogo | [Abrir fonte](https://www.oldensports.com.br/clubes/camisa-coritiba-diadora-2026-uniforme-1-torcedor-masculino) | 2026 home shirt product image; license not confirmed |
| Cruzeiro | Série A | Referência remota no jogo | [Abrir fonte](https://www.centauro.com.br/camisa-cruzeiro-i-2026-adidas-masculina-m18txv-mktp.html) | 2026 home shirt product image; this version omits some match sponsors |
| Flamengo | Série A | Referência remota no jogo | [Abrir fonte](https://www.lojasoficiaisdoflamengo.com.br/manto-flamengo-jogo-1-adidas-2026/p) | official store product image; remote only |
| Fluminense | Série A | Referência remota no jogo | [Abrir fonte](https://br.puma.com/pd/camisa-fluminense-home-2026-torcedor-masculina/788188.html) | official supplier product image; remote only |
| Grêmio | Série A | Referência remota no jogo | [Abrir fonte](https://www.futebolreligiao.com.br/camisa-i-gremio-2026-new-balance-oficial) | 2026 design reference; license not confirmed |
| Internacional | Série A | Referência remota no jogo | [Abrir fonte](https://www.futebolreligiao.com.br/camisa-i-internacional-2026-adidas-oficial) | 2026 design reference; sponsorship variant may differ |
| Mirassol | Série A | Referência remota no jogo | [Abrir fonte](https://athletabrasil.com/collections/mirassol) | official supplier collection image; remote only |
| Palmeiras | Série A | Referência remota no jogo | [Abrir fonte](https://www.aesportiva.com.br/camisa-puma-palmeiras-i-2026-juvenil--torcedor-0995010010/p?idsku=400105299) | 2026 design reference; verify sponsor/variant before claiming full official match kit |
| Red Bull Bragantino | Série A | Referência remota no jogo | [Abrir fonte](https://www.futebolreligiao.com.br/camisa-i-red-bull-bragantino-2026-puma-oficial) | 2026 design reference; license not confirmed |
| Remo | Série A | Referência remota no jogo | [Abrir fonte](https://www.futfanatics.com.br/camisa-volt-remo-i-2026) | 2026 design reference; license not confirmed |
| Santos | Série A | Referência remota no jogo | [Abrir fonte](https://www.futebolreligiao.com.br/camisa-i-santos-2026-umbro-oficial) | 2026 design reference; license not confirmed |
| São Paulo | Série A | Referência remota no jogo | [Abrir fonte](https://www.footballkitarchive.com/sao-paulo-fc-2026-home-kit-441290/) | 2026 home kit image; source is community kit archive |
| Vasco da Gama | Série A | Referência remota no jogo | [Abrir fonte](https://www.futebolreligiao.com.br/camisa-i-vasco-da-gama-2026-home) | 2026 design reference; license not confirmed |
| Vitória | Série A | Referência remota no jogo | [Abrir fonte](https://www.footballkitarchive.com/pt/camisa-titular-vitoria-2026-475215/) | 2026 home kit image; source is community kit archive |
| América Mineiro | Série B | Pendente | [Ficha do uniforme](https://www.footballkitarchive.com/pt/camisa-titular-america-mineiro-2026-475039/) | Imagem de frente adequada da temporada 2026 ainda não integrada. |
| Athletic Club | Série B | Pendente | [Ficha do uniforme](https://www.footballkitarchive.com/pt/camisa-reserva-athletic-club-mg-2026-467031/) | Imagem de frente adequada da temporada 2026 ainda não integrada. |
| Atlético Goianiense | Série B | Referência remota no jogo | [Abrir fonte](https://www.oldensports.com.br/clubes/camisa-atletico-goianiense-tolledo-2026-uniforme-1-jogador-masculino) | 2026 product image; confirm supplier details |
| Avaí | Série B | Referência remota no jogo | [Abrir fonte](https://www.footballkitarchive.com/pt/avai-2026-home-kit/467817/) | 2026 home shirt; hanger/background, front view |
| Botafogo-SP | Série B | Referência remota no jogo | [Abrir fonte](https://www.oldensports.com.br/camisa-botafogo-ribeirao-preto-volt-2026-uniforme-1-torcedor-masculino) | 2026 product image; license not confirmed |
| Ceará | Série B | Referência remota no jogo | [Abrir fonte](https://outletfc.com/camisa-ceara-i-2026/p) | 2026 product image appears without sponsor marks; not a full sponsored match version |
| CRB | Série B | Pendente | [Ficha do uniforme](https://www.footballkitarchive.com/pt/camisa-titular-crb-2026-469414/) | Imagem de frente adequada da temporada 2026 ainda não integrada. |
| Criciúma | Série B | Pendente | [Ficha do uniforme](https://www.footballkitarchive.com/pt/camisa-titular-criciuma-ec-2026-467816/) | Imagem de frente adequada da temporada 2026 ainda não integrada. |
| Cuiabá | Série B | Pendente | [Ficha do uniforme](https://www.footballkitarchive.com/pt/camisa-titular-cuiaba-2026-488974/) | Imagem de frente adequada da temporada 2026 ainda não integrada. |
| Fortaleza | Série B | Pendente | [Ficha do uniforme](https://www.footballkitarchive.com/pt/camisa-titular-fortaleza-ec-2026-469437/) | Imagem de frente adequada da temporada 2026 ainda não integrada. |
| Goiás | Série B | Pendente | [Ficha do uniforme](https://www.footballkitarchive.com/pt/camisa-titular-goias-2026-510077/) | Imagem de frente adequada da temporada 2026 ainda não integrada. |
| Juventude | Série B | Referência remota no jogo | [Abrir fonte](https://www.footballkitarchive.com/fr/ec-juventude-2026-home-kit/426967/) | 2026 season listing; image upload date is 2025, verify exact launch version |
| Londrina | Série B | Referência remota no jogo | [Abrir fonte](https://www.footballkitarchive.com/tr/londrina-ec-2026-ic-saha-formasi-465868/) | 2026 home kit; shirt-only front view |
| Náutico | Série B | Pendente | [Ficha do uniforme](https://www.footballkitarchive.com/pt/camisa-titular-clube-nautico-capibaribe-2026-478783/) | Imagem de frente adequada da temporada 2026 ainda não integrada. |
| Novorizontino | Série B | Pendente | [Ficha do uniforme](https://www.footballkitarchive.com/pt/camisa-titular-gremio-novorizontino-2026-441727/) | Imagem de frente adequada da temporada 2026 ainda não integrada. |
| Operário-PR | Série B | Referência remota no jogo | [Abrir fonte](https://www.futfanatics.com.br/camisa-karilu-operario-ferroviario-i-2026) | 2026 home shirt; license not confirmed |
| Ponte Preta | Série B | Referência remota no jogo | [Abrir fonte](https://www.footballkitarchive.com/zh/aa-ponte-preta-2026-home-kit/464822/) | 2026 home kit; shown on hanger |
| São Bernardo | Série B | Pendente | [Ficha do uniforme](https://www.footballkitarchive.com/pt/camisa-titular-sao-bernardo-fc-2026-483304/) | Imagem de frente adequada da temporada 2026 ainda não integrada. |
| Sport Recife | Série B | Pendente | [Ficha do uniforme](https://www.footballkitarchive.com/pt/camisa-titular-sport-recife-2026-465029/) | Imagem de frente adequada da temporada 2026 ainda não integrada. |
| Vila Nova | Série B | Pendente | [Ficha do uniforme](https://www.footballkitarchive.com/pt/camisa-titular-vila-nova-2026-478618/) | Imagem de frente adequada da temporada 2026 ainda não integrada. |

## Catálogos consultados
- [Football Kit Archive — Série A 2026](https://www.footballkitarchive.com/brasileiro-serie-a-kits-2026-l29/)
- [Football Kit Archive — Série B 2026](https://www.footballkitarchive.com/brasileiro-serie-b-kits-2026-l30/)

## Licenças
As imagens permanecem hospedadas nos sites de origem. Não foram copiadas para o ZIP. Para distribuição pública do jogo, obtenha autorização/licença ou substitua-as por arquivos autorizados.
