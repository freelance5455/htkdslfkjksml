/* ========== STATE ========== */
const state = {
  user: null, // { name, email, id }
  installed: [],
  recent: [],
  storageUsed: 1.6, // TB
  storageTotal: 30,
  currentPath: 'home',
  pendingInstall: null,
};

const ICONS = {
  game: ['🎮', '🕹️', '👾', '🎯', '⚔️', '🏰', '🚀', '🏎️'],
  app: ['📱', '⚙️', '📊', '🎵', '📷', '💬', '🌐', '📂'],
  exe: '💻',
  apk: '🤖',
  html: '🌐',
  aik: '✨',
  zip: '📦',
  media: '🎵',
  file: '📄',
};

const DEMO_GAMES = [
  { id: 'g1', name: 'Neon Racer', type: 'game', format: 'exe', icon: '🏎️', size: '2.4 GB', desc: 'Гоночный симулятор в неоновом городе' },
  { id: 'g2', name: 'Space Odyssey', type: 'game', format: 'html', icon: '🚀', size: '48 MB', desc: 'Космическое приключение (HTML5)' },
  { id: 'g3', name: 'Pixel Quest', type: 'game', format: 'apk', icon: '⚔️', size: '180 MB', desc: 'RPG в пиксельном стиле' },
  { id: 'g4', name: 'AI Arena', type: 'game', format: 'aik', icon: '✨', size: '1.1 GB', desc: 'Игра на движке Laden AIK' },
];

const DEMO_APPS = [
  { id: 'a1', name: 'Laden Music', type: 'app', format: 'apk', icon: '🎵', size: '64 MB', desc: 'Музыкальный плеер' },
  { id: 'a2', name: 'Notes Pro', type: 'app', format: 'exe', icon: '📝', size: '22 MB', desc: 'Заметки и списки' },
  { id: 'a3', name: 'Photo Lab', type: 'app', format: 'html', icon: '📷', size: '15 MB', desc: 'Редактор изображений' },
];

const STORE_ITEMS = [
  ...DEMO_GAMES,
  ...DEMO_APPS,
  { id: 's1', name: 'Cyber Strike', type: 'game', format: 'exe', icon: '🔫', size: '4.2 GB', desc: 'Шутер от первого лица' },
  { id: 's2', name: 'Puzzle Master', type: 'game', format: 'html', icon: '🧩', size: '12 MB', desc: 'Логические головоломки' },
  { id: 's3', name: 'Cloud Drive', type: 'app', format: 'apk', icon: '☁️', size: '38 MB', desc: 'Облачное хранилище' },
  { id: 's4', name: 'AI Chat', type: 'app', format: 'aik', icon: '🤖', size: '210 MB', desc: 'Локальный ИИ-ассистент' },
];

const FILE_SYSTEM = {
  home: [
    { name: 'Игры', type: 'folder', icon: '▶' },
    { name: 'Приложения', type: 'folder', icon: '▣' },
    { name: 'Загрузки', type: 'folder', icon: '⬇' },
    { name: 'Медиа', type: 'folder', icon: '🎵' },
    { name: 'Документы', type: 'folder', icon: '📄' },
    { name: 'readme.txt', type: 'file', icon: '📄', size: '2 KB' },
  ],
  games: [],
  apps: [],
  downloads: [
    { name: 'demo-game.exe', type: 'file', icon: '💻', size: '1.2 GB', format: 'exe' },
    { name: 'arcade.apk', type: 'file', icon: '🤖', size: '85 MB', format: 'apk' },
    { name: 'mini-game.html', type: 'file', icon: '🌐', size: '3.4 MB', format: 'html' },
    { name: 'ai-demo.aik', type: 'file', icon: '✨', size: '420 MB', format: 'aik' },
  ],
  media: [
    { name: 'soundtrack.mp3', type: 'file', icon: '🎵', size: '8.2 MB' },
    { name: 'trailer.mp4', type: 'file', icon: '🎬', size: '145 MB' },
  ],
  docs: [
    { name: 'manual.pdf', type: 'file', icon: '📄', size: '1.1 MB' },
  ],
};

/* ========== INIT ========== */
function init() {
  // Load from localStorage
  try {
    const saved = localStorage.getItem('laden_console');
    if (saved) {
      const data = JSON.parse(saved);
      state.user = data.user || null;
      state.installed = data.installed || [];
      state.recent = data.recent || [];
      state.storageUsed = data.storageUsed || 1.6;
    }
  } catch (e) {}

  // Seed demo if empty
  if (state.installed.length === 0) {
    state.installed = [
      { ...DEMO_GAMES[0], installedAt: Date.now() },
      { ...DEMO_GAMES[1], installedAt: Date.now() },
      { ...DEMO_APPS[0], installedAt: Date.now() },
    ];
    state.recent = [DEMO_GAMES[0].id, DEMO_APPS[0].id];
    save();
  }

  bindEvents();
  updateUI();
  renderAll();
}

function save() {
  localStorage.setItem('laden_console', JSON.stringify({
    user: state.user,
    installed: state.installed,
    recent: state.recent,
    storageUsed: state.storageUsed,
  }));
}

/* ========== NAVIGATION ========== */
function switchView(view) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));

  const el = document.getElementById('view-' + view);
  if (el) el.classList.add('active');

  const btn = document.querySelector(`.nav-btn[data-view="${view}"]`);
  if (btn) btn.classList.add('active');

  if (view === 'explorer') renderExplorer();
  if (view === 'browser') {
    // keep overlay until navigate
  }
}

function bindEvents() {
  document.querySelectorAll('.nav-btn').forEach(btn => {
    btn.addEventListener('click', () => switchView(btn.dataset.view));
  });

  document.getElementById('account-btn').addEventListener('click', openAccount);

  // Installer drop zone
  const dropZone = document.getElementById('drop-zone');
  const installInput = document.getElementById('install-input');

  dropZone.addEventListener('click', () => installInput.click());
  dropZone.addEventListener('dragover', e => {
    e.preventDefault();
    dropZone.classList.add('dragover');
  });
  dropZone.addEventListener('dragleave', () => dropZone.classList.remove('dragover'));
  dropZone.addEventListener('drop', e => {
    e.preventDefault();
    dropZone.classList.remove('dragover');
    if (e.dataTransfer.files.length) handleInstallFile(e.dataTransfer.files[0]);
  });
  installInput.addEventListener('change', e => {
    if (e.target.files[0]) handleInstallFile(e.target.files[0]);
  });

  // Explorer file input
  document.getElementById('file-input').addEventListener('change', e => {
    Array.from(e.target.files).forEach(f => addFileToExplorer(f));
  });

  // Sidebar
  document.querySelectorAll('.side-item').forEach(item => {
    item.addEventListener('click', () => {
      document.querySelectorAll('.side-item').forEach(i => i.classList.remove('active'));
      item.classList.add('active');
      state.currentPath = item.dataset.path;
      renderExplorer();
    });
  });

  // Browser enter key
  document.getElementById('url-input').addEventListener('keydown', e => {
    if (e.key === 'Enter') navigateBrowser();
  });
}

/* ========== RENDER ========== */
function updateUI() {
  const nameEl = document.getElementById('user-name');
  const avatarEl = document.getElementById('user-avatar');
  if (state.user) {
    nameEl.textContent = state.user.name;
    avatarEl.textContent = state.user.name.charAt(0).toUpperCase();
  } else {
    nameEl.textContent = 'Гость';
    avatarEl.textContent = '?';
  }

  const used = state.storageUsed.toFixed(1);
  document.getElementById('storage-text').textContent = `${used} / 30 ТБ`;
}

function renderAll() {
  renderGames();
  renderApps();
  renderRecent();
  renderStore();
  updateUI();
}

function renderGames() {
  const grid = document.getElementById('games-grid');
  const games = state.installed.filter(i => i.type === 'game');
  if (games.length === 0) {
    grid.innerHTML = `<p style="color:var(--text-dim);grid-column:1/-1">Нет установленных игр. Установите через установщик или магазин.</p>`;
    return;
  }
  grid.innerHTML = games.map(item => cardHTML(item)).join('');
}

function renderApps() {
  const grid = document.getElementById('apps-grid');
  const apps = state.installed.filter(i => i.type === 'app');
  if (apps.length === 0) {
    grid.innerHTML = `<p style="color:var(--text-dim);grid-column:1/-1">Нет установленных приложений.</p>`;
    return;
  }
  grid.innerHTML = apps.map(item => cardHTML(item)).join('');
}

function renderRecent() {
  const row = document.getElementById('recent-list');
  const items = state.recent
    .map(id => state.installed.find(i => i.id === id))
    .filter(Boolean)
    .slice(0, 8);

  if (items.length === 0) {
    row.innerHTML = `<p style="color:var(--text-dim)">Пока ничего не запускали</p>`;
    return;
  }
  row.innerHTML = items.map(item => `
    <div class="recent-item" onclick="launchItem('${item.id}')">
      <div class="ri-icon">${item.icon || '📦'}</div>
      <div class="ri-name">${escapeHtml(item.name)}</div>
    </div>
  `).join('');
}

function renderStore() {
  const grid = document.getElementById('store-grid');
  grid.innerHTML = STORE_ITEMS.map(item => {
    const installed = state.installed.some(i => i.id === item.id);
    return `
      <div class="app-card">
        <div class="app-cover">${item.icon}</div>
        <div class="app-info">
          <h3>${escapeHtml(item.name)}</h3>
          <div class="app-meta">${item.format.toUpperCase()} · ${item.size}</div>
          <div class="app-actions">
            ${installed
              ? `<button class="btn small primary" onclick="launchItem('${item.id}')">Запустить</button>`
              : `<button class="btn small primary" onclick="installFromStore('${item.id}')">Установить</button>`
            }
          </div>
        </div>
      </div>
    `;
  }).join('');
}

function cardHTML(item) {
  return `
    <div class="app-card">
      <div class="app-cover">${item.icon || '📦'}</div>
      <div class="app-info">
        <h3>${escapeHtml(item.name)}</h3>
        <div class="app-meta">${(item.format || '').toUpperCase()} · ${item.size || '—'}</div>
        <div class="app-actions">
          <button class="btn small primary" onclick="launchItem('${item.id}')">Запустить</button>
          <button class="btn small ghost" onclick="uninstallItem('${item.id}')">✕</button>
        </div>
      </div>
    </div>
  `;
}

function renderExplorer() {
  const pathNames = {
    home: 'Laden:/Главная',
    games: 'Laden:/Игры',
    apps: 'Laden:/Приложения',
    downloads: 'Laden:/Загрузки',
    media: 'Laden:/Медиа',
    docs: 'Laden:/Документы',
  };
  document.getElementById('current-path').textContent = pathNames[state.currentPath] || 'Laden:/';

  // Sync installed into games/apps folders
  FILE_SYSTEM.games = state.installed
    .filter(i => i.type === 'game')
    .map(i => ({ name: i.name + '.' + (i.format || 'bin'), type: 'file', icon: i.icon || '🎮', size: i.size, id: i.id, format: i.format }));
  FILE_SYSTEM.apps = state.installed
    .filter(i => i.type === 'app')
    .map(i => ({ name: i.name + '.' + (i.format || 'bin'), type: 'file', icon: i.icon || '📱', size: i.size, id: i.id, format: i.format }));

  const list = document.getElementById('file-list');
  const files = FILE_SYSTEM[state.currentPath] || [];

  if (files.length === 0) {
    list.innerHTML = `<p style="color:var(--text-dim);grid-column:1/-1;padding:20px">Папка пуста</p>`;
    return;
  }

  list.innerHTML = files.map(f => {
    if (f.type === 'folder') {
      return `
        <div class="file-item" onclick="openFolder('${f.name}')">
          <div class="file-icon">${f.icon}</div>
          <div class="file-name">${escapeHtml(f.name)}</div>
        </div>
      `;
    }
    const canInstall = ['exe', 'apk', 'html', 'aik'].includes(f.format);
    return `
      <div class="file-item" onclick="${f.id ? `launchItem('${f.id}')` : (canInstall ? `installExplorerFile('${f.name}','${f.format}')` : `showToast('Файл: ${escapeHtml(f.name)}')`)}">
        <div class="file-icon">${f.icon}</div>
        <div class="file-name">${escapeHtml(f.name)}</div>
        <div class="file-size">${f.size || ''}</div>
      </div>
    `;
  }).join('');
}

function openFolder(name) {
  const map = { 'Игры': 'games', 'Приложения': 'apps', 'Загрузки': 'downloads', 'Медиа': 'media', 'Документы': 'docs' };
  const path = map[name];
  if (path) {
    state.currentPath = path;
    document.querySelectorAll('.side-item').forEach(i => {
      i.classList.toggle('active', i.dataset.path === path);
    });
    renderExplorer();
  }
}

/* ========== INSTALLER ========== */
function openInstaller() {
  document.getElementById('installer-modal').classList.add('open');
  document.getElementById('drop-zone').style.display = 'block';
  document.getElementById('install-progress').style.display = 'none';
  document.getElementById('install-success').style.display = 'none';
  document.getElementById('install-input').value = '';
}

function closeInstaller() {
  document.getElementById('installer-modal').classList.remove('open');
}

function handleInstallFile(file) {
  const name = file.name;
  const ext = name.split('.').pop().toLowerCase();
  const supported = ['exe', 'apk', 'html', 'htm', 'aik', 'zip'];

  if (!supported.includes(ext)) {
    showToast('Формат не поддерживается. Используйте .zip, .apk, .html, .aik, .exe');
    return;
  }

  const format = ext === 'htm' ? 'html' : ext;
  // zip = package; prefer game if name suggests it
  const type = (format === 'html' || format === 'zip' || name.toLowerCase().includes('game'))
    ? 'game'
    : (['exe', 'apk', 'aik'].includes(format) && name.toLowerCase().includes('game') ? 'game' : 'app');

  const iconMap = { exe: '💻', apk: '🤖', html: '🌐', aik: '✨', zip: '📦' };
  const sizeMB = (file.size / (1024 * 1024)).toFixed(1);
  const sizeStr = sizeMB > 1024 ? (sizeMB / 1024).toFixed(1) + ' GB' : sizeMB + ' MB';

  state.pendingInstall = {
    id: 'local_' + Date.now(),
    name: name.replace(/\.[^.]+$/, ''),
    type,
    format,
    icon: iconMap[format] || '📦',
    size: sizeStr,
    file,
  };

  startInstallAnimation();
}

function installFromStore(id) {
  const item = STORE_ITEMS.find(i => i.id === id);
  if (!item) return;
  if (state.installed.some(i => i.id === id)) {
    showToast('Уже установлено');
    return;
  }
  state.pendingInstall = { ...item };
  openInstaller();
  startInstallAnimation();
}

function installExplorerFile(name, format) {
  const base = name.replace(/\.[^.]+$/, '');
  const iconMap = { exe: '💻', apk: '🤖', html: '🌐', aik: '✨' };
  state.pendingInstall = {
    id: 'exp_' + Date.now(),
    name: base,
    type: format === 'html' || name.toLowerCase().includes('game') ? 'game' : 'app',
    format,
    icon: iconMap[format] || '📦',
    size: '—',
  };
  openInstaller();
  startInstallAnimation();
}

function startInstallAnimation() {
  const p = state.pendingInstall;
  document.getElementById('drop-zone').style.display = 'none';
  document.getElementById('install-success').style.display = 'none';
  const prog = document.getElementById('install-progress');
  prog.style.display = 'block';

  document.getElementById('preview-icon').textContent = p.icon;
  document.getElementById('preview-name').textContent = p.name;
  document.getElementById('preview-type').textContent = `${p.format.toUpperCase()} · ${p.size}`;
  document.getElementById('progress-fill').style.width = '0%';
  document.getElementById('progress-percent').textContent = '0%';
  document.getElementById('progress-status').textContent = 'Проверка файла...';

  const steps = [
    { pct: 12, msg: 'Проверка файла...' },
    { pct: 28, msg: 'Распаковка...' },
    { pct: 45, msg: 'Проверка совместимости...' },
    { pct: 62, msg: 'Копирование в виртуальную память...' },
    { pct: 80, msg: 'Регистрация в Laden Console...' },
    { pct: 95, msg: 'Финальная настройка...' },
    { pct: 100, msg: 'Готово!' },
  ];

  let i = 0;
  const interval = setInterval(() => {
    if (i >= steps.length) {
      clearInterval(interval);
      completeInstall();
      return;
    }
    const s = steps[i];
    document.getElementById('progress-fill').style.width = s.pct + '%';
    document.getElementById('progress-percent').textContent = s.pct + '%';
    document.getElementById('progress-status').textContent = s.msg;
    i++;
  }, 380);
}

function completeInstall() {
  const p = state.pendingInstall;
  if (!p) return;

  // Avoid duplicates by name+format
  if (!state.installed.some(i => i.id === p.id)) {
    state.installed.push({
      id: p.id,
      name: p.name,
      type: p.type,
      format: p.format,
      icon: p.icon,
      size: p.size,
      installedAt: Date.now(),
    });
    // Simulate storage usage
    const add = Math.random() * 0.3 + 0.05;
    state.storageUsed = Math.min(29.9, state.storageUsed + add);
  }

  save();
  renderAll();

  document.getElementById('install-progress').style.display = 'none';
  document.getElementById('install-success').style.display = 'block';
  document.getElementById('success-msg').textContent =
    `«${p.name}» успешно установлено и доступно в библиотеке.`;
}

function finishInstall() {
  closeInstaller();
  state.pendingInstall = null;
  showToast('Установка завершена');
}

/* ========== LAUNCH ========== */
function launchItem(id) {
  const item = state.installed.find(i => i.id === id) || STORE_ITEMS.find(i => i.id === id);
  if (!item) {
    showToast('Элемент не найден');
    return;
  }

  // Add to recent
  state.recent = [id, ...state.recent.filter(r => r !== id)].slice(0, 12);
  save();
  renderRecent();

  const modal = document.getElementById('player-modal');
  const title = document.getElementById('player-title');
  const body = document.getElementById('player-body');

  title.textContent = item.name;

  if (item.format === 'html') {
    // Simple embedded HTML demo game
    body.innerHTML = `
      <div class="html-frame">
        <iframe srcdoc="${getHtmlGameSrc(item.name)}"></iframe>
      </div>
      <p style="margin-top:12px;color:var(--text-dim);font-size:12px">HTML5-контент запущен внутри Laden Console</p>
    `;
  } else {
    body.innerHTML = `
      <div class="player-icon">${item.icon || '▶'}</div>
      <h3>${escapeHtml(item.name)}</h3>
      <p>${escapeHtml(item.desc || 'Приложение запущено в виртуальной среде Laden Console')}</p>
      <p style="font-size:12px;color:var(--text-dim)">Формат: ${item.format?.toUpperCase() || '—'} · ${item.size || ''}</p>
      <div style="margin-top:20px;display:flex;gap:10px;justify-content:center">
        <button class="btn primary" onclick="closePlayer()">В фоновом режиме</button>
        <button class="btn ghost" onclick="closePlayer()">Закрыть</button>
      </div>
    `;
  }

  modal.classList.add('open');
}

function getHtmlGameSrc(name) {
  // Tiny playable demo
  return escapeHtmlAttr(`
    <!DOCTYPE html>
    <html><head><style>
      body{margin:0;background:#0a0e17;color:#e0f7fa;font-family:system-ui;display:flex;flex-direction:column;align-items:center;justify-content:center;height:100vh;user-select:none}
      h1{font-size:18px;margin-bottom:8px}
      canvas{border:2px solid #00e5ff;border-radius:8px;background:#06080f;cursor:crosshair}
      p{font-size:12px;opacity:.7;margin-top:10px}
    </style></head>
    <body>
      <h1>${name || 'HTML Game'}</h1>
      <canvas id="c" width="320" height="200"></canvas>
      <p>Кликай / двигай мышью · Laden HTML Runtime</p>
      <script>
        const c=document.getElementById('c'),x=c.getContext('2d');
        let px=160,py=100,score=0,t=0;
        const orbs=[];
        function spawn(){orbs.push({x:Math.random()*300+10,y:Math.random()*180+10,r:8+Math.random()*10,vx:(Math.random()-0.5)*2,vy:(Math.random()-0.5)*2,hue:Math.random()*360})}
        for(let i=0;i<6;i++)spawn();
        c.onmousemove=e=>{const r=c.getBoundingClientRect();px=e.clientX-r.left;py=e.clientY-r.top};
        c.onclick=()=>{score+=5;spawn()};
        function loop(){
          t++;
          x.fillStyle='#06080f';x.fillRect(0,0,320,200);
          // player
          x.beginPath();x.arc(px,py,12,0,Math.PI*2);
          x.fillStyle='#00e5ff';x.fill();
          x.shadowColor='#00e5ff';x.shadowBlur=12;x.fill();x.shadowBlur=0;
          orbs.forEach((o,i)=>{
            o.x+=o.vx;o.y+=o.vy;
            if(o.x<0||o.x>320)o.vx*=-1;
            if(o.y<0||o.y>200)o.vy*=-1;
            const dx=o.x-px,dy=o.y-py;
            if(Math.hypot(dx,dy)<o.r+12){score++;orbs.splice(i,1);spawn()}
            x.beginPath();x.arc(o.x,o.y,o.r,0,Math.PI*2);
            x.fillStyle='hsl('+o.hue+',80%,60%)';x.fill();
          });
          x.fillStyle='#e0f7fa';x.font='14px system-ui';x.fillText('Счёт: '+score,12,22);
          requestAnimationFrame(loop);
        }
        loop();
      <\/script>
    </body></html>
  `);
}

function closePlayer() {
  document.getElementById('player-modal').classList.remove('open');
}

function uninstallItem(id) {
  state.installed = state.installed.filter(i => i.id !== id);
  state.recent = state.recent.filter(r => r !== id);
  state.storageUsed = Math.max(0.5, state.storageUsed - 0.15);
  save();
  renderAll();
  showToast('Удалено');
}

/* ========== ACCOUNT ========== */
function openAccount() {
  const body = document.getElementById('account-body');
  if (state.user) {
    body.innerHTML = `
      <div class="account-info">
        <div class="big-avatar">${state.user.name.charAt(0).toUpperCase()}</div>
        <h3>${escapeHtml(state.user.name)}</h3>
        <div class="email">${escapeHtml(state.user.email)}</div>
        <p style="color:var(--text-dim);font-size:13px;margin-bottom:20px">Laden ID: ${state.user.id}</p>
        <button class="btn ghost" onclick="logout()">Выйти</button>
      </div>
    `;
  } else {
    body.innerHTML = `
      <div class="account-guest">
        <p>Вы можете пользоваться консолью без аккаунта: устанавливать приложения, запускать игры и файлы.<br>Laden ID нужен для синхронизации и магазина.</p>
      </div>
      <div class="account-form">
        <label>Имя</label>
        <input type="text" id="login-name" placeholder="Ваше имя" />
        <label>Email</label>
        <input type="email" id="login-email" placeholder="email@example.com" />
        <button class="btn primary" onclick="doLogin()">Войти / Создать Laden ID</button>
        <button class="btn ghost" onclick="closeAccount()">Продолжить как гость</button>
      </div>
    `;
  }
  document.getElementById('account-modal').classList.add('open');
}

function closeAccount() {
  document.getElementById('account-modal').classList.remove('open');
}

function doLogin() {
  const name = (document.getElementById('login-name')?.value || '').trim();
  const email = (document.getElementById('login-email')?.value || '').trim();
  if (!name) {
    showToast('Введите имя');
    return;
  }
  state.user = {
    name,
    email: email || name.toLowerCase().replace(/\s/g, '') + '@laden.local',
    id: 'LD-' + Math.random().toString(36).slice(2, 8).toUpperCase(),
  };
  save();
  updateUI();
  closeAccount();
  showToast('Добро пожаловать, ' + name + '!');
}

function logout() {
  state.user = null;
  save();
  updateUI();
  closeAccount();
  showToast('Вы вышли из аккаунта');
}

/* ========== BROWSER ========== */
function navigateBrowser() {
  let url = document.getElementById('url-input').value.trim();
  if (!url) return;
  if (!/^https?:\/\//i.test(url)) {
    if (url.includes('.') && !url.includes(' ')) {
      url = 'https://' + url;
    } else {
      url = 'https://www.google.com/search?q=' + encodeURIComponent(url);
    }
  }
  document.getElementById('url-input').value = url;
  const iframe = document.getElementById('browser-iframe');
  const overlay = document.getElementById('browser-overlay');
  overlay.classList.add('hidden');
  iframe.src = url;
}

function goTo(url) {
  document.getElementById('url-input').value = url;
  navigateBrowser();
}

function browserBack() {
  try { document.getElementById('browser-iframe').contentWindow.history.back(); } catch(e) {}
}
function browserForward() {
  try { document.getElementById('browser-iframe').contentWindow.history.forward(); } catch(e) {}
}
function browserReload() {
  const iframe = document.getElementById('browser-iframe');
  iframe.src = iframe.src;
}

/* ========== HELPERS ========== */
function addFileToExplorer(file) {
  const ext = file.name.split('.').pop().toLowerCase();
  const iconMap = { exe:'💻', apk:'🤖', html:'🌐', htm:'🌐', aik:'✨', zip:'📦', mp3:'🎵', mp4:'🎬', pdf:'📄', png:'📄', jpg:'🖼', png:'🖼' };
  FILE_SYSTEM.downloads.push({
    name: file.name,
    type: 'file',
    icon: iconMap[ext] || '📄',
    size: (file.size / 1024 / 1024).toFixed(1) + ' MB',
    format: ['exe','apk','html','htm','aik'].includes(ext) ? (ext === 'htm' ? 'html' : ext) : undefined,
  });
  state.currentPath = 'downloads';
  document.querySelectorAll('.side-item').forEach(i => i.classList.toggle('active', i.dataset.path === 'downloads'));
  renderExplorer();
  showToast('Файл добавлен в Загрузки');
}

function showToast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2600);
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function escapeHtmlAttr(str) {
  return str.replace(/"/g, '&quot;');
}

/* ========== START ========== */
init();
