"use strict";
var Numera = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // src/lib/calc/bundle.ts
  var bundle_exports = {};
  __export(bundle_exports, {
    formatNumber: () => formatNumber,
    getDisplay: () => getDisplay,
    initialState: () => initialState,
    persistOf: () => persistOf,
    reduce: () => reduce
  });

  // src/lib/calc/engine.ts
  var FUNCTIONS = /* @__PURE__ */ new Set([
    "sin",
    "cos",
    "tan",
    "asin",
    "acos",
    "atan",
    "ln",
    "log",
    "sqrt",
    "abs",
    "exp"
  ]);
  var CalcError = class extends Error {
    incomplete;
    constructor(message, incomplete = false) {
      super(message);
      this.name = "CalcError";
      this.incomplete = incomplete;
    }
  };
  function normalize(input) {
    return input.replace(/×/g, "*").replace(/÷/g, "/").replace(/−/g, "-").replace(/π/g, "pi").replace(/,/g, "").replace(/\s+/g, "");
  }
  function tokenize(input) {
    const s = normalize(input);
    const toks = [];
    let i = 0;
    while (i < s.length) {
      const c = s[i] ?? "";
      if (c === "*" && s[i + 1] === "*") {
        toks.push({ k: "op", v: "^" });
        i += 2;
        continue;
      }
      if (c === "\u221A") {
        toks.push({ k: "op", v: "\u221A" });
        i += 1;
        continue;
      }
      if ("+-*/^%!()".includes(c)) {
        toks.push({ k: "op", v: c });
        i += 1;
        continue;
      }
      if (c >= "0" && c <= "9" || c === ".") {
        let j = i + 1;
        let sawDot = c === ".";
        while (j < s.length) {
          const d = s[j] ?? "";
          if (d >= "0" && d <= "9") {
            j += 1;
            continue;
          }
          if (d === "." && !sawDot) {
            sawDot = true;
            j += 1;
            continue;
          }
          break;
        }
        if (j < s.length && (s[j] === "e" || s[j] === "E")) {
          let k = j + 1;
          if (s[k] === "+" || s[k] === "-") k += 1;
          const expStart = k;
          while (k < s.length && (s[k] ?? "") >= "0" && (s[k] ?? "") <= "9") k += 1;
          if (k > expStart) j = k;
        }
        const raw = s.slice(i, j);
        if (raw === ".") throw new CalcError("Invalid expression");
        const v = Number(raw);
        if (!Number.isFinite(v)) throw new CalcError("Invalid expression");
        toks.push({ k: "num", v });
        i = j;
        continue;
      }
      if (c >= "a" && c <= "z" || c >= "A" && c <= "Z") {
        let j = i + 1;
        while (j < s.length && /[a-zA-Z]/.test(s[j] ?? "")) j += 1;
        toks.push({ k: "id", v: s.slice(i, j).toLowerCase() });
        i = j;
        continue;
      }
      throw new CalcError("Invalid expression");
    }
    return toks;
  }
  var Parser = class {
    toks;
    i = 0;
    constructor(toks) {
      this.toks = toks;
    }
    parse() {
      if (this.toks.length === 0) throw new CalcError("Incomplete expression", true);
      const ast = this.expr();
      if (this.peek()) throw new CalcError("Invalid expression");
      return ast;
    }
    peek() {
      return this.toks[this.i];
    }
    pop() {
      const tok = this.toks[this.i];
      this.i += 1;
      return tok;
    }
    expr() {
      let left = this.term();
      while (this.peek()?.k === "op" && (this.peek()?.v === "+" || this.peek()?.v === "-")) {
        const op = this.pop()?.v === "-" ? "-" : "+";
        left = { k: "add", op, a: left, b: this.term() };
      }
      return left;
    }
    term() {
      let left = this.power();
      for (; ; ) {
        const next = this.peek();
        if (next?.k === "op" && (next.v === "*" || next.v === "/")) {
          const op = this.pop()?.v === "/" ? "/" : "*";
          left = { k: "mul", op, a: left, b: this.power() };
          continue;
        }
        if (next && (next.k === "num" || next.k === "id" || next.k === "op" && (next.v === "(" || next.v === "\u221A"))) {
          left = { k: "mul", op: "*", a: left, b: this.power() };
          continue;
        }
        return left;
      }
    }
    power() {
      const base = this.unary();
      if (this.peek()?.k === "op" && this.peek()?.v === "^") {
        this.pop();
        return { k: "pow", a: base, b: this.power() };
      }
      return base;
    }
    unary() {
      const next = this.peek();
      if (next?.k === "op" && next.v === "-") {
        this.pop();
        return { k: "neg", a: this.unary() };
      }
      if (next?.k === "op" && next.v === "+") {
        this.pop();
        return this.unary();
      }
      if (next?.k === "op" && next.v === "\u221A") {
        this.pop();
        return { k: "call", name: "sqrt", a: this.unary() };
      }
      return this.postfix();
    }
    postfix() {
      let node = this.primary();
      for (; ; ) {
        const next = this.peek();
        if (next?.k === "op" && (next.v === "!" || next.v === "%")) {
          this.pop();
          node = next.v === "!" ? { k: "fact", a: node } : { k: "pct", a: node };
          continue;
        }
        return node;
      }
    }
    primary() {
      const next = this.peek();
      if (!next) throw new CalcError("Incomplete expression", true);
      if (next.k === "num") {
        this.pop();
        return { k: "num", v: next.v };
      }
      if (next.k === "id") {
        this.pop();
        if (next.v === "pi") return { k: "num", v: Math.PI };
        if (next.v === "e") return { k: "num", v: Math.E };
        if (!FUNCTIONS.has(next.v)) throw new CalcError("Unknown function");
        const open = this.peek();
        if (!open || open.k !== "op" || open.v !== "(") {
          throw new CalcError("Incomplete expression", true);
        }
        this.pop();
        const arg = this.expr();
        this.expectClose();
        return { k: "call", name: next.v, a: arg };
      }
      if (next.k === "op" && next.v === "(") {
        this.pop();
        const inner = this.expr();
        this.expectClose();
        return inner;
      }
      throw new CalcError("Invalid expression");
    }
    expectClose() {
      const close = this.pop();
      if (!close || close.k !== "op" || close.v !== ")") {
        throw new CalcError("Incomplete expression", true);
      }
    }
  };
  function clean(n) {
    if (!Number.isFinite(n)) return n;
    if (n === 0 || Object.is(n, -0)) return 0;
    const next = Number(n.toPrecision(12));
    return Object.is(next, -0) ? 0 : next;
  }
  function factorial(n) {
    if (!Number.isFinite(n) || n < 0 || Math.floor(n) !== n) {
      throw new CalcError("Factorial needs a whole number");
    }
    if (n > 170) throw new CalcError("Number too large");
    let result = 1;
    for (let i = 2; i <= n; i += 1) result *= i;
    return result;
  }
  function call(name, x, angle) {
    if (name === "sin" || name === "cos" || name === "tan") {
      if (angle === "deg" && name === "tan") {
        const mod = (x % 180 + 180) % 180;
        if (Math.abs(mod - 90) < 1e-9) throw new CalcError("Undefined");
      }
      const rad = angle === "deg" ? x * Math.PI / 180 : x;
      const value = name === "sin" ? Math.sin(rad) : name === "cos" ? Math.cos(rad) : Math.tan(rad);
      if (!Number.isFinite(value)) throw new CalcError("Undefined");
      return value;
    }
    if (name === "asin" || name === "acos" || name === "atan") {
      if ((name === "asin" || name === "acos") && (x < -1 || x > 1)) {
        throw new CalcError("Out of range");
      }
      const rad = name === "asin" ? Math.asin(x) : name === "acos" ? Math.acos(x) : Math.atan(x);
      if (!Number.isFinite(rad)) throw new CalcError("Undefined");
      return angle === "deg" ? rad * 180 / Math.PI : rad;
    }
    if (name === "ln") {
      if (x <= 0) throw new CalcError("Out of range");
      return Math.log(x);
    }
    if (name === "log") {
      if (x <= 0) throw new CalcError("Out of range");
      return Math.log10(x);
    }
    if (name === "sqrt") {
      if (x < 0) throw new CalcError("Out of range");
      return Math.sqrt(x);
    }
    if (name === "abs") return Math.abs(x);
    if (name === "exp") {
      const value = Math.exp(x);
      if (!Number.isFinite(value)) throw new CalcError("Number too large");
      return value;
    }
    throw new CalcError("Unknown function");
  }
  function evalAst(node, angle) {
    switch (node.k) {
      case "num":
        return node.v;
      case "neg":
        return -evalAst(node.a, angle);
      case "pct":
        return evalAst(node.a, angle) / 100;
      case "fact":
        return factorial(evalAst(node.a, angle));
      case "call":
        return call(node.name, evalAst(node.a, angle), angle);
      case "pow": {
        const value = evalAst(node.a, angle) ** evalAst(node.b, angle);
        if (!Number.isFinite(value)) throw new CalcError("Undefined");
        return value;
      }
      case "mul": {
        const right = evalAst(node.b, angle);
        if (node.op === "/" && right === 0) throw new CalcError("Can't divide by zero");
        const left = evalAst(node.a, angle);
        const value = node.op === "/" ? left / right : left * right;
        if (!Number.isFinite(value)) throw new CalcError("Undefined");
        return value;
      }
      case "add": {
        const left = evalAst(node.a, angle);
        if (node.b.k === "pct") {
          const rate = evalAst(node.b.a, angle) / 100;
          return node.op === "+" ? left * (1 + rate) : left * (1 - rate);
        }
        const right = evalAst(node.b, angle);
        return node.op === "+" ? left + right : left - right;
      }
      default:
        throw new CalcError("Invalid expression");
    }
  }
  function evaluate(input, angle = "deg") {
    try {
      if (!input.trim()) return { ok: false, error: "Incomplete expression", incomplete: true };
      const ast = new Parser(tokenize(input)).parse();
      let value = clean(evalAst(ast, angle));
      if (!Number.isFinite(value)) return { ok: false, error: "Undefined" };
      return { ok: true, value };
    } catch (err) {
      if (err instanceof CalcError) {
        return { ok: false, error: err.message, incomplete: err.incomplete };
      }
      return { ok: false, error: "Invalid expression" };
    }
  }
  function formatExact(n) {
    if (!Number.isFinite(n) || Object.is(n, -0)) return "0";
    const abs = Math.abs(n);
    if (abs !== 0 && (abs >= 1e12 || abs < 1e-7)) {
      return n.toExponential(10).replace(/(\.\d*?)0+e/, "$1e").replace(/\.e/, "e").replace("e+", "e");
    }
    const text = n.toFixed(10).replace(/0+$/, "").replace(/\.$/, "");
    return text === "-0" ? "0" : text;
  }
  function formatNumber(n) {
    if (!Number.isFinite(n) || Object.is(n, -0) || n === 0) return "0";
    const abs = Math.abs(n);
    if (abs >= 1e12 || abs < 1e-7) {
      return n.toExponential(6).replace(/(\.\d*?)0+e/, "$1e").replace(/\.e/, "e").replace("e+", "e");
    }
    const precise = Number(n.toPrecision(12));
    return precise.toLocaleString("en-US", {
      maximumFractionDigits: 10,
      useGrouping: true
    });
  }
  function prettify(expr) {
    return expr.replaceAll("asin(", "sin\u207B\xB9(").replaceAll("acos(", "cos\u207B\xB9(").replaceAll("atan(", "tan\u207B\xB9(").replaceAll("exp(", "e^(").replaceAll("*", "\xD7").replaceAll("/", "\xF7").replaceAll("-", "\u2212");
  }
  var TRAILING_FN = /(asin|acos|atan|sqrt|abs|exp|sin|cos|tan|log|ln)$/i;
  var TRAILING_OP = /[+\-*/^√(]+$/;
  function previewExpression(input) {
    let s = input.trim();
    for (let n = 0; n < 24 && s; n += 1) {
      const next = s.replace(TRAILING_FN, "").replace(TRAILING_OP, "");
      if (next === s) break;
      s = next;
    }
    if (!s) return "";
    let open = 0;
    for (const ch of s) {
      if (ch === "(") open += 1;
      else if (ch === ")") open -= 1;
    }
    if (open > 0) s += ")".repeat(open);
    return s;
  }
  function toggleTrailingSign(expr) {
    const whole = expr.match(/^(-?)(\d+\.?\d*|\.\d+)(e[+-]?\d+)?$/i);
    if (whole) {
      const sign = whole[1] ?? "";
      const digits = whole[2] ?? "";
      const exp = whole[3] ?? "";
      return sign === "-" ? `${digits}${exp}` : `-${digits}${exp}`;
    }
    const wrapped = expr.match(/^(.*)\(-((?:\d+\.?\d*|\.\d+))\)$/);
    if (wrapped) return `${wrapped[1] ?? ""}${wrapped[2] ?? ""}`;
    const num = expr.match(/^(.*?)(\d+\.?\d*|\.\d+)$/);
    if (num) {
      const prefix = num[1] ?? "";
      const digits = num[2] ?? "";
      if (/(^|[+*/^(])-$/.test(prefix)) return prefix.slice(0, -1) + digits;
      return `${prefix}(-${digits})`;
    }
    if (expr === "" || /[+\-*/^(]$/.test(expr)) return `${expr}(-`;
    return expr;
  }

  // src/lib/calc/reducer.ts
  var initialState = {
    expression: "",
    resultRaw: "0",
    lastSource: "",
    fresh: false,
    error: null,
    memory: null,
    angle: "deg",
    scientific: false,
    history: []
  };
  var HISTORY_LIMIT = 40;
  function currentValue(state) {
    const source = state.expression.trim();
    if (!source) return null;
    const direct = evaluate(source, state.angle);
    if (direct.ok) return direct.value;
    const preview = previewExpression(source);
    if (!preview) return null;
    const next = evaluate(preview, state.angle);
    return next.ok ? next.value : null;
  }
  function getDisplay(state) {
    if (state.error) {
      return {
        primary: state.error,
        secondary: prettify(state.expression),
        isError: true
      };
    }
    if (!state.expression) {
      return {
        primary: "0",
        secondary: state.lastSource ? prettify(state.lastSource) : "",
        isError: false
      };
    }
    if (state.fresh) {
      const res = evaluate(state.expression, state.angle);
      return {
        primary: res.ok ? formatNumber(res.value) : prettify(state.expression),
        secondary: prettify(state.lastSource),
        isError: false
      };
    }
    const previewSrc = previewExpression(state.expression);
    const preview = previewSrc ? evaluate(previewSrc, state.angle) : null;
    if (preview?.ok) {
      return {
        primary: formatNumber(preview.value),
        secondary: prettify(state.expression),
        isError: false
      };
    }
    return {
      primary: prettify(state.expression) || "0",
      secondary: "",
      isError: false
    };
  }
  function insert(state, token) {
    const next = state.error ? { ...state, error: null } : state;
    let expression = next.expression;
    let fresh = next.fresh;
    if (fresh) {
      expression = /^[+\-*/^%!]/.test(token) ? `${next.resultRaw || "0"}${token}` : token;
      fresh = false;
    } else if (/^[+*/^]/.test(token) && /[+\-*/^]$/.test(expression)) {
      expression = expression.slice(0, -1) + token;
    } else if (token === "-" && expression.endsWith("-")) {
      return next;
    } else {
      expression += token;
    }
    if (expression.length > 220) return next;
    return { ...next, expression, fresh, error: null };
  }
  function remember(state, value) {
    const result = formatNumber(value);
    const resultRaw = formatExact(value);
    const history = [
      { expression: state.expression, result },
      ...state.history.filter((item) => item.expression !== state.expression || item.result !== result)
    ].slice(0, HISTORY_LIMIT);
    return {
      ...state,
      expression: resultRaw,
      resultRaw,
      lastSource: state.expression,
      fresh: true,
      error: null,
      history
    };
  }
  function applySign(state) {
    if (state.error) return { ...state, error: null };
    if (state.fresh) {
      const flipped = toggleTrailingSign(state.resultRaw);
      const res = evaluate(flipped, state.angle);
      const raw = res.ok ? formatExact(res.value) : flipped;
      return { ...state, expression: raw, resultRaw: raw, fresh: true, error: null };
    }
    if (!state.expression) return { ...state, expression: "-", error: null };
    return { ...state, expression: toggleTrailingSign(state.expression), error: null };
  }
  function memory(state, op) {
    if (op === "clear") return { ...state, memory: null };
    if (op === "recall") {
      if (state.memory === null) return state;
      const raw = formatExact(state.memory);
      const token = raw.startsWith("-") ? `(${raw})` : raw;
      if (state.fresh || state.error || !state.expression) {
        return { ...state, expression: raw, resultRaw: raw, fresh: true, error: null };
      }
      return insert(state, token);
    }
    const value = currentValue(state);
    if (value === null) return state;
    const base = state.memory ?? 0;
    const next = op === "add" ? base + value : base - value;
    if (!Number.isFinite(next)) return state;
    return { ...state, memory: Object.is(next, -0) ? 0 : next };
  }
  function persistOf(state) {
    return {
      history: state.history.slice(0, HISTORY_LIMIT),
      memory: state.memory,
      angle: state.angle,
      scientific: state.scientific
    };
  }
  function hydrate(state, data) {
    if (!data || typeof data !== "object") return state;
    const record = data;
    const history = [];
    if (Array.isArray(record.history)) {
      for (const item of record.history) {
        if (history.length >= HISTORY_LIMIT) break;
        if (!item || typeof item !== "object") continue;
        const row = item;
        if (typeof row.expression !== "string" || typeof row.result !== "string") continue;
        history.push({ expression: row.expression.slice(0, 220), result: row.result.slice(0, 80) });
      }
    } else {
      history.push(...state.history);
    }
    const memory2 = typeof record.memory === "number" && Number.isFinite(record.memory) ? record.memory : record.memory === null ? null : state.memory;
    return {
      ...state,
      history,
      memory: memory2,
      angle: record.angle === "rad" ? "rad" : record.angle === "deg" ? "deg" : state.angle,
      scientific: typeof record.scientific === "boolean" ? record.scientific : state.scientific
    };
  }
  function reduce(state, action) {
    switch (action.type) {
      case "insert":
        return insert(state, action.token);
      case "clear":
        return {
          ...state,
          expression: "",
          resultRaw: "0",
          lastSource: "",
          fresh: false,
          error: null
        };
      case "backspace":
        if (state.fresh) {
          return { ...state, expression: "", resultRaw: "0", lastSource: "", fresh: false, error: null };
        }
        return { ...state, expression: state.expression.slice(0, -1), fresh: false, error: null };
      case "equals": {
        const res = evaluate(state.expression, state.angle);
        if (!res.ok) {
          return {
            ...state,
            error: res.incomplete ? "Incomplete expression" : res.error,
            fresh: false
          };
        }
        return remember(state, res.value);
      }
      case "sign":
        return applySign(state);
      case "toggle-angle": {
        const angle = state.angle === "deg" ? "rad" : "deg";
        if (state.fresh && state.lastSource) {
          const res = evaluate(state.lastSource, angle);
          if (res.ok) {
            const raw = formatExact(res.value);
            return { ...state, angle, expression: raw, resultRaw: raw, error: null };
          }
        }
        return { ...state, angle };
      }
      case "toggle-scientific":
        return { ...state, scientific: !state.scientific };
      case "memory":
        return memory(state, action.op);
      case "use-history":
        return {
          ...state,
          expression: action.expression,
          fresh: false,
          error: null
        };
      case "clear-history":
        return { ...state, history: [] };
      case "hydrate":
        return hydrate(state, action.data);
      default:
        return state;
    }
  }
  return __toCommonJS(bundle_exports);
})();
