#!/usr/bin/env bash
# MYRA start:  bash start.sh        (screen par chalta hai)
#              bash start.sh bg     (background mein chalta hai)
cd "$(dirname "$(readlink -f "$0")")" || exit 1
if ! command -v python >/dev/null 2>&1; then
  echo "Python nahi mila. Pehle chalao:  bash setup.sh"; exit 1
fi
URL="http://localhost:8080"
open_browser() { sleep 1.5; command -v termux-open-url >/dev/null 2>&1 && termux-open-url "$URL"; }

if [ "$1" = "bg" ]; then
  command -v termux-wake-lock >/dev/null 2>&1 && termux-wake-lock
  nohup python serve.py >/dev/null 2>&1 &
  open_browser &
  echo "MYRA background mein chal raha hai: $URL"
  echo "Band karne ke liye:  bash stop.sh"
  exit 0
fi

command -v termux-wake-lock >/dev/null 2>&1 && termux-wake-lock
trap 'command -v termux-wake-unlock >/dev/null 2>&1 && termux-wake-unlock' EXIT
open_browser &
python serve.py
