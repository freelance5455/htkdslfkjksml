#!/usr/bin/env bash
# MYRA ek baar ka setup (Termux): bash setup.sh
set -e
cd "$(dirname "$(readlink -f "$0")")"
DIR="$(pwd)"
echo "== MYRA setup shuru =="
if command -v pkg >/dev/null 2>&1; then
  echo "-> Python install ho raha hai..."
  pkg install -y python
else
  echo "(Ye Termux nahi lag raha. Python 3 pehle se install hona chahiye.)"
fi
command -v python >/dev/null 2>&1 || { echo "Python install nahi hua. Internet check karo aur dobara chalao."; exit 1; }

chmod +x start.sh stop.sh serve.py 2>/dev/null || true

# 'myra' aur 'myra-stop' shortcut commands
touch "$HOME/.bashrc"
sed -i '/# MYRA shortcuts/d;/alias myra=/d;/alias myra-bg=/d;/alias myra-stop=/d' "$HOME/.bashrc"
{
  echo "# MYRA shortcuts"
  echo "alias myra=\"bash '$DIR/start.sh'\""
  echo "alias myra-bg=\"bash '$DIR/start.sh' bg\""
  echo "alias myra-stop=\"bash '$DIR/stop.sh'\""
} >> "$HOME/.bashrc"

echo
echo "== Setup ho gaya =="
echo "Ab ye chalao (pehle:  source ~/.bashrc ):"
echo "  myra          -> MYRA chalao"
echo "  myra-bg       -> background mein chalao"
echo "  myra-stop     -> band karo"
echo "Ya seedha:  bash start.sh"
