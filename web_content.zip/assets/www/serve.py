#!/usr/bin/env python3
"""MYRA local server (Termux). Sirf aapke phone par chalta hai: http://localhost:8080"""
import errno, os, sys
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer

HOST, PORT = "127.0.0.1", 8080   # port fixed rakho: browser mein key/contacts isi address par save hote hain
HERE = os.path.dirname(os.path.abspath(__file__))
PIDFILE = os.path.join(HERE, ".myra.pid")

class Handler(SimpleHTTPRequestHandler):
    extensions_map = {**SimpleHTTPRequestHandler.extensions_map, ".js": "text/javascript", ".html": "text/html; charset=utf-8"}
    def __init__(self, *a, **k):
        super().__init__(*a, directory=HERE, **k)
    def end_headers(self):
        self.send_header("Cache-Control", "no-store")   # update karne par purana page na dikhe
        super().end_headers()
    def log_message(self, fmt, *args):
        pass

def main():
    try:
        srv = ThreadingHTTPServer((HOST, PORT), Handler)
    except OSError as e:
        if e.errno == errno.EADDRINUSE:
            print(f"Port {PORT} pehle se use mein hai. Shayad MYRA already chal raha hai.")
            print(f"Chrome mein kholo: http://localhost:{PORT}")
            print("Band karna ho to: bash stop.sh")
            return 0
        raise
    try:
        open(PIDFILE, "w").write(str(os.getpid()))
    except OSError:
        pass
    print("=" * 44)
    print(" MYRA chal raha hai")
    print(f" Chrome mein kholo: http://localhost:{PORT}")
    print(" Band karne ke liye: Ctrl+C (Volume Down + C)")
    print("=" * 44)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nMYRA band ho gaya.")
    finally:
        srv.server_close()
        try:
            os.remove(PIDFILE)
        except OSError:
            pass
    return 0

if __name__ == "__main__":
    sys.exit(main())
