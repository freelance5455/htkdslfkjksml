MYRA - TERMUX SETUP (Hinglish)
==============================

Ye kya hai: MYRA (UI + Agent Town) ko aapke phone par Termux se chalane ka package.
Server sirf aapke phone par chalta hai (localhost). Mic bhi chalta hai, kyunki
localhost ko browser safe address maanta hai.

PEHLE ZAROORI
- Termux F-Droid ya GitHub se install karo. Play Store wala Termux purana hai aur kaam nahi karta.
- Browser: Chrome ya Edge (mic typing ke liye).

STEP 1: Zip phone mein download karo (Downloads folder mein).

STEP 2: Termux kholo aur ye ek-ek karke chalao
    termux-setup-storage
    cd ~
    cp ~/storage/downloads/myra-termux.zip .
    pkg install -y unzip
    unzip -o myra-termux.zip
    cd myra
    bash setup.sh
    source ~/.bashrc

(Agar zip ka naam alag ho, jaise "myra-termux (1).zip", to cp mein wahi naam likho.)

STEP 3: Chalao
    myra
Chrome apne aap khulega. Na khule to Chrome mein ye address daalo:
    http://localhost:8080

STEP 4: Pehli baar
    - Setting card kholo, Gemini API key daalo (aistudio.google.com/apikey).
    - ElevenLabs key aur voice ID bhi Setting mein daal sakte ho.
    - Key sirf is phone ke browser mein save hoti hai.

COMMANDS
    myra          screen par chalao (band karne ke liye Volume Down + C)
    myra-bg       background mein chalao (Termux band karke bhi chalta rehta hai)
    myra-stop     band karo

TIPS
- Chrome menu mein "Add to Home screen" karoge to MYRA ka icon home screen par aa jayega.
- Hamesha wahi address use karo: http://localhost:8080 . Address badalne par saved key/contacts nahi dikhenge.
- Background mein chalane ke liye phone Settings mein Termux ki battery optimization band karo
  (Unrestricted), warna Android use kill kar sakta hai.
- Update karna ho: nayi index.html ko is myra folder mein purani ki jagah copy kar do.

AI ENGINE (Setting card)
- Gemini API key aur Claude API key dono daal sakte ho. Ek na chale (quota, key, network) to
  MYRA apne aap doosre AI par shift ho jati hai. "GEMINI TEST" / "CLAUDE TEST" se key check karo.
- Gemini Live: Setting mein "Gemini Live use karo" on karo, phir START AI dabao aur seedha bolo.
  Default model: gemini-3.8-live. Zyada reasoning chahiye to gemini-3.8-live-extended-thinking likho.
  Live ke liye mic chahiye, aur ye http://localhost:8080 par chalta hai.
- Gemini Live bina Gemini key ke nahi chalta (Claude se Live voice nahi hoti).

MYRA KO TEZ AUR NATURAL KAISE RAKHEIN
- Gemini Live (default ON): START AI dabao aur seedha bolo. Beech mein tok sakte ho.
- Jawab slow lage to Setting mein "LIVE JAWAB KI SPEED" ko "Tez" karo.
- ElevenLabs model "eleven_flash_v2_5" sabse tez hai.
- Camera: camera button dabao aur kuch dikhakar poocho "ye kya hai?".
- Internet na ho to MYRA basic kaam karti hai: reminder, note, tasks, goals, time, call.

KILL / DELETE
- MYRA ke panel mein START/STOP ke bagal ka laal power (KILL) button:
    SAB BAND KARO      -> mic, camera, Live, awaaz aur auto mode turant band (data safe).
    MYRA KO DELETE KARO -> browser mein saved sab kuch hat jata hai (keys, memory, goals, notes, contacts).
- Termux se files bhi hataani hon to:  bash ~/myra/uninstall.sh

DHYAN
- Gemini aur ElevenLabs ke liye internet chahiye.
- Termux se phone ke dusre apps seedhe control nahi hote. Nova sirf link ke button banati hai.
