#!/usr/bin/env bash
# MYRA band karo (background wala bhi)
cd "$(dirname "$(readlink -f "$0")")" || exit 1
STOPPED=0
if [ -f .myra.pid ]; then
  PID="$(cat .myra.pid 2>/dev/null)"
  if [ -n "$PID" ] && kill "$PID" 2>/dev/null; then STOPPED=1; fi
  rm -f .myra.pid
fi
if [ "$STOPPED" = "0" ] && pkill -f "^python3? serve.py$" 2>/dev/null; then STOPPED=1; fi
[ "$STOPPED" = "1" ] && echo "MYRA band ho gaya." || echo "MYRA chal hi nahi raha tha."
command -v termux-wake-unlock >/dev/null 2>&1 && termux-wake-unlock
