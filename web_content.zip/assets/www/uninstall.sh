#!/usr/bin/env bash
# MYRA ko Termux se hatao:  bash uninstall.sh
DIR="$(cd "$(dirname "$(readlink -f "$0")")" && pwd)"

# safety: sirf asli MYRA folder par chalega
if [ ! -f "$DIR/serve.py" ] || [ ! -f "$DIR/index.html" ] || [ "$DIR" = "$HOME" ] || [ "$DIR" = "/" ]; then
  echo "Ye MYRA ka folder nahi lag raha. Kuch delete nahi kiya."; exit 1
fi

# server band + shortcuts hatao
if [ -f "$DIR/.myra.pid" ]; then kill "$(cat "$DIR/.myra.pid")" 2>/dev/null; fi
(cd "$DIR" && pkill -f "^python3? serve.py$" 2>/dev/null)
command -v termux-wake-unlock >/dev/null 2>&1 && termux-wake-unlock
if [ -f "$HOME/.bashrc" ]; then
  sed -i '/# MYRA shortcuts/d;/alias myra=/d;/alias myra-bg=/d;/alias myra-stop=/d' "$HOME/.bashrc"
fi
echo "Server band kiya aur myra shortcuts hata diye."

read -r -p "Folder $DIR hamesha ke liye delete karun? (haan/na): " ans
case "$ans" in
  haan|Haan|HAAN|y|Y|yes|YES)
    cd "$HOME" && rm -rf "$DIR" && echo "MYRA delete ho gayi."
    echo "Browser mein saved data hatane ke liye: MYRA page mein KILL (power) button -> MYRA KO DELETE KARO."
    ;;
  *) echo "Folder rakha gaya: $DIR" ;;
esac
