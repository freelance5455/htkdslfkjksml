ZERO X ACADEMY brand assets. zero-x-logo.png is the supplied project logo.
