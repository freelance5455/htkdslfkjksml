No extra assets needed: the app uses only the files in css/, js/, images/ and icons/.
