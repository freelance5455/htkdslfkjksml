Optional: add licensed sound effects, music, images or fonts here. Core gameplay assets are drawn by Canvas in script.js.
