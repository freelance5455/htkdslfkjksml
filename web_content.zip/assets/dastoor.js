const app=document.getElementById("app"),PORTAL="index.html",CHS=DST.ch;
const DL=[];CHS.forEach(c=>c.docs.forEach(d=>{d.c=c;if(!d.p)DL.push(d)}));
const DM=Object.fromEntries(DL.map((d,i)=>[d.id,i]));
const $=id=>document.getElementById(id);let q="";
const st=(k,v)=>{try{if(v===undefined)return JSON.parse(localStorage.getItem(k)||"[]");localStorage.setItem(k,JSON.stringify(v))}catch(e){return[]}};
/* نرمال‌سازی جستجو با نگاشت به موقعیت اصلی (برای برجسته‌سازی و برش دقیق متن) */
const CM={"ي":"ی","ك":"ک","ة":"ه","ۀ":"ه","أ":"ا","إ":"ا","آ":"ا"};
function nmap(s){let t="",m=[],sp=false;for(let i=0;i<s.length;i++){let c=s[i];const k=c.charCodeAt(0);
if(k===8204||k===8205||k===8206||k===8207||k===1600||(k>=1611&&k<=1618))continue;
if(k>=1776&&k<=1785)c=String(k-1776);else if(k>=1632&&k<=1641)c=String(k-1632);
else if(k===160||/\s/.test(c)){if(sp)continue;sp=true;t+=" ";m.push(i);continue}else c=CM[c]||c.toLowerCase();
sp=false;t+=c;m.push(i)}return{t:t,m:m}}
function rxq(s){s=nmap(s.trim()).t;if(s.length<2)return null;
s=s.replace(/(ماده|اصل|تبصره)\s*\(?\s*(\d+)\s*\)?/g,"$1 $2");
let p=s.replace(/[.*+?^${}()|[\]\\]/g,"\\$&").replace(/\s+/g,"\\s*");
p=p.replace(/(ماده|اصل|تبصره)\\s\*(\d+)/g,"$1\\s*\\(?\\s*$2(?!\\d)");
try{return new RegExp(p,"g")}catch(e){return null}}
const ptxt=h=>h.replace(/<sup class="fn"[^>]*>\d+<\/sup>/g,"").replace(/<br>/g," ").replace(/<\/(p|h[1-6]|tr|div)>/g,"\n").replace(/<\/(td|th)>/g," | ").replace(/<[^>]+>/g,"").replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/&amp;/g,"&");
const tx=d=>{if(!d.x){d.x=ptxt(d.h);d.n=nmap(d.x)}return d};
function searchAll(s){const r=rxq(s);if(!r)return null;const out=[];
DL.forEach(d=>{tx(d);r.lastIndex=0;let m,c=0,f=null;const t=d.n.t;
while((m=r.exec(t))){if(!m[0].length){r.lastIndex++;continue}c++;if(!f)f=[d.n.m[m.index],d.n.m[m.index+m[0].length-1]+1]}
if(c)out.push({d:d,c:c,f:f})});return out}
const sn=(x,f)=>{const a=Math.max(0,f[0]-50),b=Math.min(x.length,f[1]+100),g=s=>esc(s.replace(/\s+/g," "));return(a?"… ":"")+g(x.slice(a,f[0]))+"<mark>"+g(x.slice(f[0],f[1]))+"</mark>"+g(x.slice(f[1],b))+(b<x.length?" …":"")};
const meta=d=>`<span class="tag">${d.k}</span>`+(d.arts.length>=3?`<span class="tag">${fa(d.arts.length)} ماده</span>`:"")+(d.tbl?`<span class="tag">${fa(d.tbl)} جدول</span>`:"")+(d.img?`<span class="tag">${fa(d.img)} تصویر</span>`:"")+(d.att.length?`<span class="tag">${fa(d.att.length)} پیوست</span>`:"")+(d.fn?`<span class="tag">${fa(d.fn)} پاورقی</span>`:"");
const row=d=>`<a href="#d${d.id}"><b>${esc(d.t)}</b>${meta(d)}</a>`;
const hdr=(t,sub)=>`<div class="nav"><button class="back" id="hb">‹ بازگشت به فهرست</button></div><header class="ph">${ROS}<h1 class="grad" style="font-size:clamp(22px,2.9vw,38px)">${esc(t)}</h1>${sub}</header>`;
function chapters(){return CHS.map((c,i)=>{const n=c.docs.filter(d=>!d.p).length;
return`<details class="tn l1" open><summary>${c.l}: ${c.t} <span class="tag">${fa(n)} مستند</span></summary><div class="res dl">${c.docs.map(d=>d.p?`<div class="pd"><b>${esc(d.t)}</b><span class="tag draft">به‌زودی</span></div>`:row(d)).join("")}</div></details>`}).join("")}
function homeBody(){const s=q.trim();
if(s){const r=searchAll(s);if(!r)return`<p class="sub">برای جستجو دست‌کم دو حرف وارد کنید.</p>`;
const tot=r.reduce((a,x)=>a+x.c,0);
return`<p class="sub">${fa(tot)} مورد در ${fa(r.length)} مستند</p><div class="res">${r.map(x=>`<a href="#d${x.d.id}"><b>${esc(x.d.t)}</b><small>${x.d.c.l}: ${x.d.c.t} — ${fa(x.c)} مورد</small>${sn(x.d.x,x.f)}</a>`).join("")}</div>`}
const bm=st("ds_bm").filter(i=>DM[i]!==undefined),rc=st("ds_rec").filter(i=>DM[i]!==undefined);
return`<div class="tools" style="margin-top:14px"><a class="pill" href="qanun.html">📜 قانون اساسی</a><a class="pill" href="ayin.html">📖 آیین‌نامه داخلی مجلس</a><a class="pill" href="sahn.html">📊 احکام کاربردی در صحن علنی مجلس</a></div>${bm.length?`<h3>⭐ نشان‌شده‌ها</h3><div class="res dl">${bm.map(i=>row(DL[DM[i]])).join("")}</div>`:""}${rc.length?`<h3>🕘 اخیراً دیده‌شده</h3><div class="res dl">${rc.map(i=>row(DL[DM[i]])).join("")}</div>`:""}<h3>فهرست مستندات</h3>${chapters()}`}
function home(){clearPop();
app.innerHTML=`<div class="nav"><a class="pill" href="${PORTAL}">‹ صفحه‌ی اصلی سامانه</a></div><header class="ph">${ROS}<h1 class="grad">دستورالعمل‌ها و شیوه‌نامه‌ها</h1><p>معاونت قوانین مجلس شورای اسلامی؛ متن کامل، پیوست‌ها و جستجو در متن</p><small style="color:var(--mut)">${DST.v}</small></header><input id="q" placeholder="جستجو در متن مستندات (مثلاً ماده ۱۵۶)" value="${esc(q)}" aria-label="جستجو"><div id="hbody">${homeBody()}</div>${foot()}`;
$("q").oninput=e=>{q=e.target.value;$("hbody").innerHTML=homeBody()}}
/* ---------- صفحه‌ی مستند ---------- */
const REL={"2-3":[["sahn.html","📊 احکام کاربردی در صحن علنی مجلس"]]};
let MK=[],ci=0;
function clearMarks(root){root.querySelectorAll("mark.hl").forEach(m=>{const p=m.parentNode;p.replaceChild(document.createTextNode(m.textContent),m);p.normalize()})}
function showMark(i){if(!MK.length)return;MK.forEach(m=>m.classList.remove("cur"));ci=(i+MK.length)%MK.length;const m=MK[ci];m.classList.add("cur");m.scrollIntoView({block:"center",behavior:"smooth"});$("fc").textContent=fa(ci+1)+" از "+fa(MK.length)}
function doFind(root,s,jump){clearMarks(root);MK=[];ci=0;const r=rxq(s);
if(r){const w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT,null),nodes=[];let n;while((n=w.nextNode()))nodes.push(n);
nodes.forEach(nd=>{const o=nmap(nd.nodeValue),rg=[];let x;r.lastIndex=0;
while((x=r.exec(o.t))){if(!x[0].length){r.lastIndex++;continue}rg.push([o.m[x.index],o.m[x.index+x[0].length-1]+1])}
const loc=[];for(let i=rg.length-1;i>=0;i--){const rn=document.createRange();rn.setStart(nd,rg[i][0]);rn.setEnd(nd,rg[i][1]);const mk=document.createElement("mark");mk.className="hl";try{rn.surroundContents(mk);loc.unshift(mk)}catch(e){}}
MK.push.apply(MK,loc)})}
$("fc").textContent=MK.length?"":(r?"یافت نشد":"");if(MK.length&&jump)showMark(0);else if(MK.length)$("fc").textContent=fa(MK.length)+" مورد"}
function jumpTo(id){const el=$(id);if(!el)return;el.scrollIntoView({behavior:"smooth",block:"start"});el.classList.remove("fl");void el.offsetWidth;el.classList.add("fl")}
function clearPop(){const p=document.querySelector(".fnpop");if(p)p.remove()}
const cpy=(t,b,l)=>navigator.clipboard?navigator.clipboard.writeText(t).then(()=>{b.textContent="✓ کپی شد"},()=>prompt(l,t)):prompt(l,t);
function tables(root){root.querySelectorAll(".tw").forEach(w=>{const tb=w.querySelector("table"),rs=tb?Array.from(tb.rows):[];if(rs.length<=40)return;
const nt=rs.map(r=>nmap(r.textContent).t),inp=document.createElement("input");inp.className="tf";inp.placeholder="جستجو در این جدول (از "+fa(rs.length)+" ردیف)…";
inp.oninput=()=>{const v=nmap(inp.value.trim()).t;rs.forEach((r,i)=>{r.style.display=(!v||i===0||nt[i].includes(v))?"":"none"})};w.parentNode.insertBefore(inp,w)})}
function docPage(id){const d0=DL[DM[id]];if(!d0)return home();clearPop();const d=tx(d0),idx=DM[id],pv=DL[idx-1],nx=DL[idx+1];
const bm=st("ds_bm").includes(id);st("ds_rec",[id,...st("ds_rec").filter(x=>x!==id)].slice(0,5));
const ref=`«${d.t}» - معاونت قوانین مجلس شورای اسلامی`;
const rel=(REL[id]||[]).map(r=>`<a class="cp t" href="${r[0]}">${r[1]}</a>`).join("");
app.innerHTML=`<div>${hdr(d.t,`<div class="crumb">${d.c.l}: ${d.c.t}</div>`)}
<div class="tools" style="justify-content:flex-start"><button class="pill" id="cr">📋 کپی ارجاع</button><button class="pill" id="ct">📄 کپی متن</button><button class="pill" id="bk">${bm?"⭐ نشان‌شده":"☆ نشان‌گذاری"}</button><button class="pill" id="pr">🖨 چاپ</button></div>
<div class="find"><input id="fq" placeholder="جستجو در این مستند…" value="${esc(q)}" aria-label="جستجو در مستند"><span class="tag" id="fc"></span><button class="pill" id="fpv" aria-label="مورد قبل">▲</button><button class="pill" id="fnx" aria-label="مورد بعد">▼</button></div>
${rel?`<div class="box note"><b>بخش‌های مرتبط:</b> ${rel}</div>`:""}
${d.att.length?`<h3>پیوست‌ها</h3>${d.att.map(a=>`<button class="pill" data-go="${a[1]}">📎 ${esc(a[0])}</button>`).join(" ")}`:""}
${d.arts.length>=3?`<details class="tn"><summary>فهرست مواد <span class="tag">${fa(d.arts.length)} ماده</span></summary><div>${d.arts.map(a=>`<button class="cp" data-go="${a[1]}">ماده ${fa(a[0])}</button>`).join("")}</div></details>`:""}
${d.toc.length?`<details class="tn"><summary>فهرست مطالب <span class="tag">${fa(d.toc.length)} عنوان</span></summary><div class="toc">${d.toc.map(t=>`<button class="tc${t[0]}" data-go="${t[2]}">${esc(t[1])}</button>`).join("")}</div></details>`:""}
<div class="box ap dc" id="dc">${d.h}</div>
<div class="tools">${pv?`<a class="pill" href="#d${pv.id}">› مستند قبل</a>`:""}${nx?`<a class="pill" href="#d${nx.id}">مستند بعد ‹</a>`:""}</div>
<div class="po"></div></div>${foot()}`;
const dc=$("dc");tables(dc);
$("hb").onclick=()=>go("");
$("cr").onclick=e=>cpy(ref,e.target,"ارجاع:");$("ct").onclick=e=>cpy(ref+"\n\n"+d.x,e.target,"متن:");
$("pr").onclick=()=>{const po=app.querySelector(".po");po.innerHTML=`<h1>${esc(d.t)}</h1>`+d.h+`<p><small>${esc(DST.v)}</small></p>`;window.addEventListener("afterprint",()=>{po.innerHTML=""},{once:true});window.print()};
$("bk").onclick=()=>{const b=st("ds_bm");st("ds_bm",b.includes(id)?b.filter(y=>y!==id):[...b,id]);docPage(id)};
app.querySelectorAll("[data-go]").forEach(b=>b.onclick=()=>jumpTo(b.dataset.go));
dc.addEventListener("click",e=>{const s=e.target.closest("sup.fn");if(!s)return;clearPop();const f=$("f"+s.dataset.f),p=document.createElement("div");p.className="fnpop";
p.innerHTML=`<button class="pill" aria-label="بستن">✕</button><div><b>پاورقی ${fa(s.dataset.f)}:</b> ${f?f.innerHTML.replace(/^<sup>\d+<\/sup>\s*/,""):""}</div>`;p.querySelector("button").onclick=clearPop;document.body.appendChild(p)});
const fq=$("fq");let tm;fq.oninput=()=>{q=fq.value;clearTimeout(tm);tm=setTimeout(()=>doFind(dc,q,true),250)};
fq.onkeydown=e=>{if(e.key==="Enter"){e.preventDefault();showMark(ci+(e.shiftKey?-1:1))}};
$("fnx").onclick=()=>showMark(ci+1);$("fpv").onclick=()=>showMark(ci-1);
if(q.trim().length>=2)doFind(dc,q,true)}
function route(){const h=decodeURIComponent(location.hash.slice(1));let m;
if(m=h.match(/^d(\d+-\d+)$/))docPage(m[1]);else home();scrollTo(0,0)}
function go(h){if(location.hash.slice(1)===h)route();else location.hash=h}
window.addEventListener("hashchange",route);route();
