const $ = id => document.getElementById(id);
const KEY_ACTIVE='matyka_access_v1', SWITCH_KEY='matyka_switches_v1', HISTORY_KEY='matyka_history_v1';
const modules=[
 {group:'AIMBOT',number:'01',items:[
  ['Aimbot Legit','Mira Gruda','◎'],['Aimbot Rage','100% Capa','◈'],['Aimbot Collider','Gruda Disfarçado','⌖']]},
 {group:'FUNÇÕES DE HS',number:'02',items:[
  ['HS Alto','Tiro No Alto Da Cabeça É Capa','↟'],['HS Pescoço','Tiro no Pescoço É Capa','⌁'],['HS Peito Lite','Tiro No Peito É Capa','◇'],['HS Peito Fix','Hs para Partidas Normais','⊕']]},
 {group:'LOCATION',number:'03',items:[
  ['ESP LINE','Faz Uma Linha De Você Até O Oponente','╱'],['ESP Box','Faz Uma Caixa Ao Redor Do Oponente','▢'],['ESP Vida','Marca A Vida Do Oponente','♡'],['Holograma','Chams Da Cabeça Aos Pés','◉']]},
 {group:'BYPASS AP',number:'04',items:[['Apagar Rastros','Limpa Qualquer Rastro Do Smartphone','⌫']]}
];
let switches=JSON.parse(localStorage.getItem(SWITCH_KEY)||'{}');
let history=JSON.parse(localStorage.getItem(HISTORY_KEY)||'[]');
let connectionRunning=false;

function logActivity(message){
 const time=new Date().toLocaleString('pt-BR',{hour:'2-digit',minute:'2-digit',day:'2-digit',month:'2-digit'});
 history.unshift({message,time}); history=history.slice(0,25);
 localStorage.setItem(HISTORY_KEY,JSON.stringify(history)); renderHistory();
}
function renderHistory(){
 const host=$('historyList');
 host.innerHTML=history.length?history.map(x=>`<div class="history-item"><i></i><div>${escapeHtml(x.message)}<small>${x.time}</small></div></div>`).join(''):'<div class="empty-state">Nenhuma atividade registrada.</div>';
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function renderModules(){
 $('moduleGroups').innerHTML=modules.map(g=>`<section class="module-group"><div class="group-head"><span class="group-number">${g.number}</span><h3>${g.group}</h3></div>${g.items.map((it,i)=>{const key=g.number+'-'+i, on=!!switches[key];return `<div class="module-card ${on?'enabled':''}"><div class="module-icon">${it[2]}</div><div class="module-info"><strong>${it[0]}</strong><small>${it[1]}</small></div><button class="switch ${on?'on':''}" role="switch" aria-checked="${on}" aria-label="Alternar ${it[0]}" data-switch="${key}"></button></div>`}).join('')}</section>`).join('');
 document.querySelectorAll('[data-switch]').forEach(btn=>btn.addEventListener('click',()=>{const key=btn.dataset.switch;switches[key]=!switches[key];localStorage.setItem(SWITCH_KEY,JSON.stringify(switches));renderModules();updateCount();const [g,i]=key.split('-');logActivity(`${modules.find(x=>x.number===g).items[Number(i)][0]} ${switches[key]?'ativado':'desativado'}`)}));
 updateCount();
}
function updateCount(){const n=Object.values(switches).filter(Boolean).length;$('enabledCount').textContent=String(n).padStart(2,'0')}
function showApp(){ $('activation').classList.add('hidden');$('app').classList.remove('hidden');renderModules();renderHistory(); }
function showAuth(){ $('app').classList.add('hidden');$('activation').classList.remove('hidden'); }
function switchTab(tab){
 document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));
 $('functions').classList.toggle('hidden',tab!=='functions');$('connections').classList.toggle('hidden',tab!=='connections');
}
document.querySelectorAll('.tab').forEach(b=>b.addEventListener('click',()=>switchTab(b.dataset.tab)));
$('activateBtn').addEventListener('click',()=>{
 const key=$('keyInput').value.trim();
 if(!key){$('authMessage').textContent='Digite uma KEY para continuar.';return}
 $('activateBtn').disabled=true;$('activateBtn').textContent='ATIVANDO...';
 setTimeout(()=>{localStorage.setItem(KEY_ACTIVE,'1');$('authMessage').textContent='Acesso liberado.';logActivity('Acesso local ativado');showApp();$('activateBtn').disabled=false;$('activateBtn').innerHTML='ATIVAR ACESSO <b>↗</b>'},450);
});
$('keyInput').addEventListener('keydown',e=>{if(e.key==='Enter')$('activateBtn').click()});
$('settingsBtn').addEventListener('click',()=>$('settingsOverlay').classList.remove('hidden'));
$('closeSettings').addEventListener('click',()=>$('settingsOverlay').classList.add('hidden'));
$('logoutBtn').addEventListener('click',()=>{localStorage.removeItem(KEY_ACTIVE);$('settingsOverlay').classList.add('hidden');$('keyInput').value='';showAuth();logActivity('Sessão encerrada')});
$('clearData').addEventListener('click',()=>{if(confirm('Limpar ativação, opções e histórico salvos neste dispositivo?')){localStorage.removeItem(KEY_ACTIVE);localStorage.removeItem(SWITCH_KEY);localStorage.removeItem(HISTORY_KEY);switches={};history=[];$('settingsOverlay').classList.add('hidden');$('keyInput').value='';showAuth()}});
$('clearHistory').addEventListener('click',()=>{history=[];localStorage.setItem(HISTORY_KEY,'[]');renderHistory()});
$('viewHistory').addEventListener('click',()=>{$('settingsOverlay').classList.add('hidden');switchTab('connections');$('historyList').scrollIntoView({behavior:'smooth',block:'center'})});

$('injectBtn').addEventListener('click',()=>{
 const pkg=$('packageInput').value.trim(), btn=$('injectBtn'), bar=$('injectProgress'), msg=$('injectMessage');
 if(!pkg){msg.textContent='Informe o pacote do aplicativo ou deixe o campo vazio para validar a interface.';return}
 if(!/^[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z0-9_]+)+$/.test(pkg)){msg.textContent='Formato de pacote inválido. Exemplo: com.exemplo.app';return}
 bar.style.width='35%';msg.textContent='Preparando solicitação de abertura...';btn.disabled=true;
 setTimeout(()=>{bar.style.width='75%';msg.textContent='Solicitação enviada ao ambiente Android, se compatível.'},350);
 setTimeout(()=>{bar.style.width='100%';msg.textContent='Se o conversor oferecer suporte à abertura por pacote, o Android poderá abrir o aplicativo.';btn.disabled=false;logActivity('Solicitação de abertura: '+pkg);setTimeout(()=>bar.style.width='0',1300)},850);
});

function setConnectionState(active){connectionRunning=active;$('connectionDot').classList.toggle('active',active);$('connectionState').textContent=active?'SOLICITAÇÃO ATIVA':'PARADO';}
$('startConnection').addEventListener('click',()=>{
 const ip=$('ipInput').value.trim(),port=$('portInput').value.trim(),code=$('pairInput').value.trim();
 if(!ip||!port||!code){$('connectionMessage').textContent='Preencha IP, PORT e PAIRING CODE.';return}
 $('connectionMessage').textContent='Dados preenchidos. A interface não consegue estabelecer ADB sem suporte nativo do Android.';setConnectionState(false);logActivity('Dados de depuração Wi-Fi informados');
});
$('stopConnection').addEventListener('click',()=>{setConnectionState(false);$('connectionMessage').textContent='Nenhuma sessão ADB ativa para interromper.';logActivity('Solicitação para parar depuração Wi-Fi')});
$('refreshStatus').addEventListener('click',()=>{$('connectionMessage').textContent='Status atualizado: nenhuma conexão ADB foi confirmada pelo sistema.';setConnectionState(false);logActivity('Status de conexão consultado')});
$('openAndroidSettings').addEventListener('click',()=>{
 $('connectionMessage').textContent='Se disponível, use as configurações do Android para abrir Sistema > Opções do desenvolvedor > Depuração sem fio.';
 logActivity('Orientação para abrir configurações Android');
 // Android intent navigation is not available in a plain browser wrapper; no false success is reported.
 try{window.location.href='intent:#Intent;action=android.settings.APPLICATION_DEVELOPMENT_SETTINGS;end'}catch(e){}
});
renderHistory();
setTimeout(()=>{$('splash').classList.add('out');setTimeout(()=>$('splash').remove(),500);if(localStorage.getItem(KEY_ACTIVE)==='1')showApp();else showAuth()},1250);
