(() => {
  const $ = s => document.querySelector(s);
  const $$ = s => [...document.querySelectorAll(s)];
  const filePicker = $('#filePicker'), imagePicker = $('#imagePicker');
  let files = [], currentFile = null, imageFiles = [], filter = 'all', toastTimer;
  const iconFor = f => f.type.startsWith('image/') ? 'IMG' : 'PDF';
  const niceSize = n => n < 1024*1024 ? `${Math.max(1,Math.round(n/1024))} ك.ب` : `${(n/1024/1024).toFixed(1)} م.ب`;
  const showToast = msg => { const t=$('#toast'); t.textContent=msg; t.classList.add('show'); clearTimeout(toastTimer); toastTimer=setTimeout(()=>t.classList.remove('show'),2300); };
  const safeName = name => name.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function addFiles(list) {
    [...list].forEach(file => {
      if (!file.type.startsWith('application/pdf') && !file.type.startsWith('image/')) { showToast('نوع الملف غير مدعوم'); return; }
      if (files.some(x => x.file.name===file.name && x.file.size===file.size)) return;
      files.unshift({id:Date.now()+Math.random(),file,url:URL.createObjectURL(file),added:new Date()});
    });
    renderFiles(); if(files.length) showToast('تمت إضافة الملفات');
  }
  function rowMarkup(item) {
    const isImg=item.file.type.startsWith('image/');
    return `<div class="file-row"><div class="file-thumb ${isImg?'image':''}">${isImg?'IMG':'PDF'}</div><div class="file-info"><b>${safeName(item.file.name)}</b><small>${niceSize(item.file.size)} · ${isImg?'صورة':'مستند PDF'}</small></div><button class="file-open" data-open="${item.id}" aria-label="فتح الملف">‹</button></div>`;
  }
  function renderFiles() {
    const q=($('#searchInput')?.value||'').trim().toLowerCase();
    const filtered=files.filter(x=>(filter==='all'||(filter==='pdf'?x.file.type==='application/pdf':x.file.type.startsWith('image/')))&&x.file.name.toLowerCase().includes(q));
    $('#recentCount').textContent=files.length?`${files.length} ملف`:'لا توجد ملفات بعد';
    $('#recentFiles').innerHTML=files.slice(0,3).map(rowMarkup).join('');
    $('#allFiles').innerHTML=filtered.map(rowMarkup).join('');
    $('#homeEmpty').hidden=files.length>0;
    $('#filesEmpty').hidden=filtered.length>0;
    $('#allFiles').style.display=filtered.length?'flex':'none';
    $('#recentFiles').style.display=files.length?'flex':'none';
    bindOpen();
  }
  function bindOpen() { $$('[data-open]').forEach(b=>b.onclick=()=>openFile(files.find(x=>String(x.id)===b.dataset.open))); }
  function openFile(item) {
    if(!item) return;
    currentFile=item;
    $('#viewerName').textContent=item.file.name;
    $('#viewerMeta').textContent=`${iconFor(item.file)} · ${niceSize(item.file.size)}`;
    const body=$('#viewerBody'); body.innerHTML='';
    if(item.file.type.startsWith('image/')) { const img=document.createElement('img'); img.src=item.url; body.append(img); }
    else { const frame=document.createElement('iframe'); frame.src=item.url+'#toolbar=0&navpanes=0&scrollbar=1'; frame.title=item.file.name; body.append(frame); }
    $('#viewer').classList.add('open'); $('#viewer').setAttribute('aria-hidden','false');
  }
  function closeViewer(){ $('#viewer').classList.remove('open'); $('#viewer').setAttribute('aria-hidden','true'); $('#viewerBody').innerHTML=''; }
  function navigate(page) {
    $$('.page').forEach(p=>p.classList.toggle('active',p.dataset.page===page));
    $$('.nav-item[data-nav]').forEach(n=>n.classList.toggle('active',n.dataset.nav===page));
    $('#mainContent').scrollTop=0;
  }
  function openCreate(){ $('#createModal').classList.add('open'); $('#createModal').setAttribute('aria-hidden','false'); }
  function closeCreate(){ $('#createModal').classList.remove('open'); $('#createModal').setAttribute('aria-hidden','true'); }
  function updateImagePreview(){
    const box=$('#imagePreview'); box.innerHTML='';
    if(!imageFiles.length){box.classList.remove('has-images');box.innerHTML='<span>▧</span><b>لم تُضف صورًا بعد</b><small>يمكن اختيار أكثر من صورة</small>';$('#makePdf').disabled=true;return;}
    box.classList.add('has-images');
    imageFiles.forEach(f=>{const img=document.createElement('img');img.className='preview-thumb';img.src=URL.createObjectURL(f);box.append(img);});
    $('#makePdf').disabled=false;
  }
  function makeImagePrint() {
    if(!imageFiles.length)return;
    const w=window.open('','_blank');
    if(!w){showToast('اسمح بفتح نافذة الطباعة من إعدادات المتصفح');return;}
    const images=imageFiles.map(f=>URL.createObjectURL(f));
    w.document.write(`<!doctype html><html lang="ar"><head><meta charset="utf-8"><title>PDF</title><style>@page{size:auto;margin:0}body{margin:0}section{height:100vh;display:flex;align-items:center;justify-content:center;page-break-after:always;break-after:page}img{max-width:100%;max-height:100%;object-fit:contain}section:last-child{page-break-after:auto}</style></head><body>${images.map(src=>`<section><img src="${src}"></section>`).join('')}<script>window.onload=()=>setTimeout(()=>window.print(),500)<\/script></body></html>`);
    w.document.close(); closeCreate(); showToast('اختر حفظ كـ PDF من نافذة الطباعة');
  }
  function printCurrent() {
    if(!currentFile){showToast('افتح مستندًا أولًا');return;}
    if(currentFile.file.type.startsWith('image/')) { const w=window.open(currentFile.url,'_blank'); if(w)w.onload=()=>w.print(); }
    else { const w=window.open(currentFile.url,'_blank'); if(w) setTimeout(()=>w.print(),500); }
  }
  function shareCurrent() {
    if(!currentFile){showToast('افتح مستندًا أولًا');return;}
    if(navigator.share && navigator.canShare) {
      const f=currentFile.file;
      try { const shareData={files:[f],title:f.name}; if(navigator.canShare(shareData)) navigator.share(shareData).catch(()=>{}); else showToast('المشاركة المباشرة غير متاحة لهذا الملف'); } catch(e){showToast('المشاركة غير متاحة');}
    } else showToast('المشاركة المباشرة غير مدعومة في هذا المتصفح');
  }
  $('#headerAdd').onclick=()=>filePicker.click(); $('#heroAdd').onclick=()=>filePicker.click(); $('#emptyAdd').onclick=()=>filePicker.click(); $('#filesAdd').onclick=()=>filePicker.click(); $('#navAdd').onclick=()=>filePicker.click();
  filePicker.onchange=e=>{if(e.target.files.length)addFiles(e.target.files);e.target.value='';};
  $$('.quick-card,.tool-card').forEach(b=>b.onclick=()=>runAction(b.dataset.action));
  function runAction(action){
    if(action==='open')filePicker.click();
    if(action==='create'){imageFiles=[];updateImagePreview();openCreate();}
    if(action==='print'){if(currentFile)printCurrent();else{showToast('اختر مستندًا للطباعة');filePicker.click();}}
    if(action==='share'){if(currentFile)shareCurrent();else{showToast('افتح مستندًا للمشاركة');filePicker.click();}}
  }
  $$('[data-nav]').forEach(b=>b.onclick=()=>navigate(b.dataset.nav));
  $('#searchInput').addEventListener('input',renderFiles);
  $$('.filter-chip').forEach(b=>b.onclick=()=>{$$('.filter-chip').forEach(x=>x.classList.toggle('active',x===b));filter=b.dataset.filter;renderFiles();});
  $('#closeViewer').onclick=closeViewer; $('#viewerPrint').onclick=printCurrent; $('#viewerShare').onclick=shareCurrent;
  $('#closeCreate').onclick=closeCreate; $('#chooseImages').onclick=()=>imagePicker.click(); imagePicker.onchange=e=>{imageFiles=[...e.target.files];updateImagePreview();e.target.value='';}; $('#makePdf').onclick=makeImagePrint;
  $('#createModal').onclick=e=>{if(e.target===$('#createModal'))closeCreate();};
  $('#clearRecent').onclick=()=>{files.forEach(x=>URL.revokeObjectURL(x.url));files=[];renderFiles();showToast('تم مسح قائمة الملفات');};
  // منع التكبير بالإيماءات والضغط المتكرر، مع إبقاء التمرير الطبيعي.
  document.addEventListener('gesturestart',e=>e.preventDefault(),{passive:false});
  document.addEventListener('touchmove',e=>{if(e.scale && e.scale!==1)e.preventDefault();},{passive:false});
  let lastTouchEnd=0;document.addEventListener('touchend',e=>{const now=Date.now();if(now-lastTouchEnd<=300)e.preventDefault();lastTouchEnd=now;},{passive:false});
  document.addEventListener('keydown',e=>{if(e.key==='Escape'){closeViewer();closeCreate();}});
  renderFiles();
})();
