const lessons=[
{id:1,title:"أساسيات الشبكات",icon:"🌐",text:`<h3>الدرس 1: أساسيات الشبكات</h3>
<p>الشبكة هي مجموعة أجهزة تتبادل البيانات وفق قواعد وبروتوكولات محددة. فهم الشبكات هو الأساس لفهم الأمن السيبراني.</p>
<h4>1. عنوان IP</h4><p>يُستخدم عنوان IP للتعرّف على جهاز أو واجهة شبكة داخل نطاق معين. يوجد IPv4 وIPv6. في المختبرات التعليمية نستخدم عناوين خاصة أو وهمية بدل اختبار أجهزة حقيقية.</p>
<h4>2. TCP وUDP</h4><p>TCP يركز على موثوقية نقل البيانات وترتيبها، بينما UDP أبسط وأسرع ولا يضمن التسليم بنفس الطريقة.</p>
<h4>3. DNS</h4><p>DNS يحول أسماء النطاقات إلى عناوين IP، مثل تحويل اسم موقع إلى العنوان الذي يحتاجه جهازك للاتصال.</p>
<div class="safe-note">🛡️ تمرين آمن: ارسم على ورقة المسار: جهازك → الراوتر → DNS → الخادم، وحدد وظيفة كل جزء.</div>`},
{id:2,title:"Linux للمبتدئين",icon:"🐧",text:`<h3>الدرس 2: Linux للمبتدئين</h3>
<p>Linux نظام مهم في الأمن السيبراني والخوادم. تعلم الطرفية يساعدك على فهم الملفات والعمليات والصلاحيات.</p>
<h4>أوامر أساسية</h4><pre>pwd      # معرفة المجلد الحالي
ls       # عرض الملفات
cd       # الانتقال بين المجلدات
mkdir    # إنشاء مجلد
cat      # قراءة ملف نصي</pre>
<h4>الصلاحيات</h4><p>الملفات في Linux لها صلاحيات للمالك والمجموعة والآخرين. فهم الصلاحيات يساعدك على منع الوصول غير المقصود إلى الملفات.</p>
<div class="safe-note">🛡️ تمرين آمن: أنشئ مجلدًا تجريبيًا على جهازك وتدرب على التنقل داخله دون تعديل ملفات النظام.</div>`},
{id:3,title:"Python للأمن السيبراني",icon:"🐍",text:`<h3>الدرس 3: Python للأمن السيبراني</h3>
<p>Python لغة مناسبة لأتمتة مهام التحليل والدفاع، مثل معالجة السجلات وفحص البيانات.</p>
<h4>المتغيرات والدوال</h4><pre>name = "Ahmed"

def greet(user):
    return "Welcome " + user

print(greet(name))</pre>
<h4>مثال دفاعي: فحص سجل</h4><pre>log = "LOGIN failed user=unknown"
if "failed" in log:
    print("مراجعة محاولة الدخول")</pre>
<p>الفكرة هي تحويل البيانات الخام إلى معلومات تساعد المدافع على اكتشاف النشاط غير المعتاد.</p>
<div class="safe-note">🛡️ تمرين آمن: عدّل المثال ليبحث عن كلمة "warning" داخل نص تجريبي.</div>`},
{id:4,title:"التشفير والتجزئة",icon:"🔐",text:`<h3>الدرس 4: التشفير والتجزئة</h3>
<p>التشفير يحول البيانات إلى صيغة يمكن استعادتها بالمفتاح المناسب، بينما التجزئة تنتج قيمة ثابتة الطول تستخدم للمقارنة والتحقق.</p>
<h4>مفاهيم مهمة</h4><ul><li>Encryption: حماية سرية البيانات.</li><li>Hashing: التحقق من البيانات وتخزين تمثيل غير قابل للعكس عمليًا عند استخدام خوارزمية مناسبة.</li><li>MFA: إضافة عامل تحقق آخر إلى جانب كلمة المرور.</li></ul>
<p>لا ينبغي تخزين كلمات المرور كنص صريح. الأنظمة الحديثة تستخدم خوارزميات تجزئة مخصصة لكلمات المرور مع salt.</p>
<div class="safe-note">🛡️ تمرين آمن: اشرح لنفسك الفرق بين "تشفير ملف" و"تجزئة كلمة مرور" في جملتين.</div>`},
{id:5,title:"أمن تطبيقات الويب",icon:"🌐",text:`<h3>الدرس 5: أمن تطبيقات الويب</h3>
<p>تطبيقات الويب تتعامل مع مدخلات المستخدم، لذلك يجب اعتبار المدخلات غير موثوقة حتى يتم التحقق منها ومعالجتها بأمان.</p>
<h4>SQL Injection</h4><p>يحدث عندما تُبنى استعلامات قاعدة البيانات بطريقة تسمح للمدخلات بتغيير معنى الاستعلام. الحماية تشمل parameterized queries والتحقق المناسب من المدخلات.</p>
<h4>XSS</h4><p>ينتج عندما يستطيع محتوى غير موثوق الوصول إلى صفحة بطريقة تسمح بتنفيذه في سياق المستخدم. من وسائل الحماية output encoding وسياسات CSP المناسبة.</p>
<div class="safe-note">🛡️ تمرين آمن: افتح مختبرًا محليًا مصممًا للتعلم فقط، وحدد أين يجب أن تتم عملية التحقق من المدخلات.</div>`},
{id:6,title:"تحليل السجلات",icon:"📊",text:`<h3>الدرس 6: تحليل السجلات واكتشاف النشاط المشبوه</h3>
<p>السجلات تسجل أحداثًا مثل تسجيل الدخول والأخطاء والطلبات. تحليلها يساعد فريق الدفاع على اكتشاف الأنماط غير المعتادة.</p>
<h4>مثال</h4><pre>10:01 LOGIN success user=ahmed
10:02 LOGIN failed user=unknown
10:02 LOGIN failed user=unknown
10:03 LOGIN failed user=unknown</pre>
<p>تكرار الفشل خلال فترة قصيرة قد يكون سببًا للمراجعة. في نظام حقيقي يمكن استخدام rate limiting والمصادقة متعددة العوامل والتنبيهات.</p>
<div class="safe-note">🛡️ تمرين آمن: عدّ عدد محاولات الفشل في السجل أعلاه وحدد الحدث الذي يستحق التحقيق.</div>`},
{id:7,title:"الاختبار الأخلاقي وCTF",icon:"🎯",text:`<h3>الدرس 7: الاختبار الأخلاقي وCTF</h3>
<p>الاختبار الأخلاقي يعني العمل ضمن نطاق واضح وبإذن. قبل أي اختبار يجب معرفة الأنظمة المسموح بها، والوقت، ونوع الاختبارات، وكيفية الإبلاغ عن النتائج.</p>
<h4>قواعد أساسية</h4><ul><li>اختبر أنظمة تملكها أو لديك إذن صريح لاختبارها.</li><li>لا تحاول الوصول إلى حسابات أو أجهزة الآخرين.</li><li>احتفظ بنطاق الاختبار والتوثيق.</li><li>استخدم CTF والمختبرات التعليمية كبيئة آمنة للتدريب.</li></ul>
<div class="safe-note">🛡️ مشروع التخرج: أنشئ مختبرًا محليًا صغيرًا يحتوي على سجلات وهمية وثلاثة أخطاء دفاعية، ثم اكتب تقريرًا يوضح المشكلة والحل دون مهاجمة أي نظام حقيقي.</div>`}
];

document.getElementById("lessons").innerHTML=lessons.map(x=>`
<button type="button" class="lesson-btn" data-id="${x.id}">
<span class="lesson-icon">${x.icon}</span><span><b>الدرس ${x.id}: ${x.title}</b><small>اضغط لفتح الدرس الكامل</small></span><span>›</span>
</button>`).join("");

document.querySelectorAll(".lesson-btn").forEach(btn=>btn.addEventListener("click",()=>{
 const lesson=lessons.find(x=>x.id===Number(btn.dataset.id));
 document.querySelectorAll(".lesson-btn").forEach(x=>x.classList.remove("selected"));
 btn.classList.add("selected");
 const viewer=document.getElementById("lessonViewer");
 viewer.innerHTML=`<div class="terminal-title">root@joker:~$ lesson_${lesson.id}</div>${lesson.text}
 <div class="lesson-actions"><button type="button" class="backTop">↑ العودة لقائمة الدروس</button></div>`;
 viewer.scrollIntoView({behavior:"smooth",block:"start"});
 viewer.querySelector(".backTop").addEventListener("click",()=>document.getElementById("lessons").scrollIntoView({behavior:"smooth"}));
}));

document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>{document.querySelectorAll(".tab").forEach(x=>x.classList.remove("active"));document.querySelectorAll(".page").forEach(x=>x.classList.remove("active"));b.classList.add("active");document.getElementById(b.dataset.page).classList.add("active")});
document.getElementById("run").onclick=()=>{let c=document.getElementById("code").value;let out=[];let m=c.match(/print\(["'](.*?)["']\)/g)||[];m.forEach(x=>out.push(x.replace(/^print\(["']|["']\)$/g,"")));document.getElementById("output").textContent=out.length?out.join("\n"):"تم تحليل المثال. شغّل print('نص') لرؤية ناتج تدريبي.";};
document.getElementById("clear").onclick=()=>document.getElementById("output").textContent="";
const qs=[["ما أفضل ممارسة لكلمة المرور؟",["استخدام كلمة طويلة وفريدة","مشاركة كلمة المرور","استخدام 123456"],0],["ما وظيفة MFA؟",["زيادة سرعة الإنترنت","إضافة عامل تحقق إضافي","حذف الحساب"],1],["ما المقصود بـ XSS؟",["نوع قاعدة بيانات","ثغرة في تطبيقات الويب تتعلق بإدخال محتوى قابل للتنفيذ","بروتوكول بريد"],1],["ما الحماية الشائعة من SQL Injection؟",["Parameterized Queries","تعطيل لوحة المفاتيح","زيادة سطوع الشاشة"],0],["ماذا تفعل قبل اختبار نظام ليس ملكك؟",["تبدأ مباشرة","تحصل على إذن ونطاق واضح","تخفي هويتك"],1],["ما فائدة تحليل السجلات؟",["اكتشاف نشاط غير معتاد","تغيير خلفية الهاتف","زيادة مساحة التخزين"],0],["أين يجب تنفيذ تمارين الاختراق التعليمية؟",["على أجهزة عشوائية","على مختبر تملكه أو لديك تصريح لاختباره","على حسابات الآخرين"],1]];
let qi=0,score=0,answered=false;
function renderQ(){const q=qs[qi];document.getElementById("quiz").innerHTML=`<div class="question"><b>اختبار ${qi+1} من 7</b><h3>${q[0]}</h3>${q[1].map((o,i)=>`<button class="option" data-i="${i}">${o}</button>`).join("")}</div>`;answered=false;document.querySelectorAll(".option").forEach(b=>b.onclick=()=>{if(answered)return;answered=true;let i=+b.dataset.i;if(i===q[2]){score++;b.classList.add("correct")}else{b.classList.add("wrong");document.querySelectorAll(".option")[q[2]].classList.add("correct")}document.getElementById("score").textContent=`النتيجة الحالية: ${score}/${qi+1}`;});}
document.getElementById("next").onclick=()=>{if(!answered)return;if(qi<6){qi++;renderQ()}else{document.getElementById("score").textContent=`انتهت الاختبارات. نتيجتك: ${score}/7. ${score>=5?"يمكنك إنشاء شهادة إتمام تعليمية.":"أعد المحاولة بعد مراجعة الدروس."}`;}};renderQ();
document.getElementById("makeCert").onclick=()=>{if(score<5){alert("تحتاج إلى 5/7 على الأقل.");return}let n=document.getElementById("studentName").value.trim()||"أحمد ملك الظلام الجوكر";let svg=`<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="800"><rect width="1200" height="800" fill="#08111d"/><rect x="35" y="35" width="1130" height="730" fill="none" stroke="#7aa4c8" stroke-width="4"/><text x="600" y="150" text-anchor="middle" fill="#9fc7e8" font-size="36" font-family="Arial">CYBER ACADEMY</text><text x="600" y="250" text-anchor="middle" fill="white" font-size="52" font-family="Arial">شهادة إتمام تعليمية</text><text x="600" y="350" text-anchor="middle" fill="white" font-size="42" font-family="Arial">${n.replace(/&/g,"&amp;").replace(/</g,"&lt;")}</text><text x="600" y="430" text-anchor="middle" fill="#b9c8d8" font-size="28" font-family="Arial">أكمل مسار الأمن السيبراني الأخلاقي</text><text x="600" y="500" text-anchor="middle" fill="#b9c8d8" font-size="24" font-family="Arial">نتيجة الاختبارات: ${score}/7</text><text x="600" y="650" text-anchor="middle" fill="#7aa4c8" font-size="22" font-family="Arial">أحمد ملك الظلام الجوكر</text></svg>`;let url="data:image/svg+xml;charset=utf-8,"+encodeURIComponent(svg);document.getElementById("certBox").innerHTML=`<img alt="شهادة إتمام تعليمية" src="${url}"><br><a href="${url}" download="Ahmed_Cyber_Certificate.svg">تنزيل الشهادة كصورة SVG</a>`;};