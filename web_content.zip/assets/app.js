const CONFIG = window.MISS_CONFIG || {};
const hasSupabase = window.supabase && CONFIG.SUPABASE_URL &&
  !CONFIG.SUPABASE_URL.includes("COLE_AQUI") &&
  CONFIG.SUPABASE_ANON_KEY && !CONFIG.SUPABASE_ANON_KEY.includes("COLE_AQUI");

const db = hasSupabase ? window.supabase.createClient(
  CONFIG.SUPABASE_URL, CONFIG.SUPABASE_ANON_KEY
) : null;

const demoCandidates = [
  { id: 1, number: "01", name: "Yassimin Muhammad Mussa Bhikha", image: "../assets/candidate-01.jpg", description: "Candidata nº 01" },
  { id: 2, number: "02", name: "Wilma Sebastião Mugano", image: "../assets/candidate-02.jpg", description: "Candidata nº 02" },
  { id: 3, number: "03", name: "Nome da Candidata", image: "../assets/candidate-03.jpg", description: "Candidata nº 03" },
  { id: 4, number: "04", name: "Nome da Candidata", image: "../assets/candidate-04.jpg", description: "Candidata nº 04" },
  { id: 5, number: "05", name: "Nome da Candidata", image: "../assets/candidate-05.jpg", description: "Candidata nº 05" },
  { id: 6, number: "06", name: "Nome da Candidata", image: "../assets/candidate-06.jpg", description: "Candidata nº 06" }
];

const state = { candidates: demoCandidates, votes: {}, selected: null };

function getVoterId() {
  let id = localStorage.getItem("miss_escola_voter_id");
  if (!id) {
    id = crypto.randomUUID ? crypto.randomUUID() :
      "v-" + Date.now() + "-" + Math.random().toString(36).slice(2);
    localStorage.setItem("miss_escola_voter_id", id);
  }
  return id;
}

function escapeHTML(s) {
  return String(s).replace(/[&<>"']/g, c => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
  }[c]));
}

function initials(name) {
  return name.split(/\s+/).slice(0,2).map(x => x[0]).join("").toUpperCase();
}

function renderCandidates() {
  const grid = document.querySelector("#candidate-grid");
  grid.innerHTML = state.candidates.map(c => `
    <article class="candidate">
      <div class="candidate-photo">
        <img src="${c.image}" alt="${escapeHTML(c.name)}"
             onerror="this.style.display='none';this.nextElementSibling.style.display='grid'">
        <div class="photo-fallback">${initials(c.name)}</div>
        <span class="number">Nº ${escapeHTML(c.number)}</span>
      </div>
      <div class="candidate-body">
        <h3>${escapeHTML(c.name)}</h3>
        <p>${escapeHTML(c.description || "Sem descrição disponível.")}</p>
        <button class="vote-btn" data-id="${c.id}">VOTAR NESTA CANDIDATA</button>
      </div>
    </article>
  `).join("");

  grid.querySelectorAll(".vote-btn").forEach(btn => {
    btn.addEventListener("click", () => openVote(Number(btn.dataset.id)));
  });
}

async function loadVotes() {
  if (!db) {
    state.votes = JSON.parse(localStorage.getItem("miss_escola_demo_votes") || "{}");
    document.querySelector("#status").textContent = "Modo demonstração";
    return;
  }
  const { data, error } = await db.from("votes").select("candidate_id");
  if (error) {
    console.error(error);
    document.querySelector("#status").textContent = "Erro ao carregar votos";
    return;
  }
  state.votes = {};
  data.forEach(v => state.votes[v.candidate_id] = (state.votes[v.candidate_id] || 0) + 1);
  document.querySelector("#status").textContent = "Votação online";
}

function totalVotes() {
  return Object.values(state.votes).reduce((a,b) => a+b, 0);
}

function renderRanking() {
  const total = totalVotes();
  const ranking = [...state.candidates]
    .map(c => ({...c, votes: state.votes[c.id] || 0}))
    .sort((a,b) => b.votes - a.votes)
    .slice(0,10);

  document.querySelector("#ranking-list").innerHTML = ranking.map((c,i) => {
    const pct = total ? ((c.votes / total) * 100).toFixed(1) : "0.0";
    return `
      <div class="rank-card">
        <div class="rank-place">${i+1}º</div>
        <div class="rank-avatar">
          <img src="${c.image}" alt="" onerror="this.style.display='none'">
        </div>
        <div class="rank-main">
          <strong>${escapeHTML(c.name)}</strong>
          <span>Nº ${escapeHTML(c.number)}</span>
        </div>
        <div class="rank-votes">
          <strong>${c.votes}</strong>
          <span>votos (${pct}%)</span>
        </div>
      </div>
    `;
  }).join("");
}

function openVote(id) {
  state.selected = state.candidates.find(c => c.id === id);
  document.querySelector("#modal-title").textContent = "Confirmar voto";
  document.querySelector("#modal-text").innerHTML =
    `Deseja votar em <strong>${escapeHTML(state.selected.name)}</strong>, candidata nº ${escapeHTML(state.selected.number)}?`;
  document.querySelector("#modal-msg").textContent = "";
  document.querySelector("#modal").classList.add("show");
  document.querySelector("#modal").setAttribute("aria-hidden","false");
}

function closeModal() {
  document.querySelector("#modal").classList.remove("show");
  document.querySelector("#modal").setAttribute("aria-hidden","true");
  state.selected = null;
}

async function submitVote() {
  if (!state.selected) return;
  const voterId = getVoterId();
  const msg = document.querySelector("#modal-msg");
  const button = document.querySelector("#confirm");
  button.disabled = true;
  button.textContent = "A ENVIAR…";

  if (!db) {
    const already = localStorage.getItem("miss_escola_has_voted");
    if (already) {
      msg.textContent = "Este dispositivo já registou um voto nesta demonstração.";
      button.disabled = false;
      button.textContent = "CONFIRMAR VOTO";
      return;
    }
    state.votes[state.selected.id] = (state.votes[state.selected.id] || 0) + 1;
    localStorage.setItem("miss_escola_demo_votes", JSON.stringify(state.votes));
    localStorage.setItem("miss_escola_has_voted", "1");
  } else {
    const { error } = await db.from("votes").insert({
      candidate_id: state.selected.id,
      voter_id: voterId
    });
    if (error) {
      if (error.code === "23505") msg.textContent = "Este dispositivo já registou um voto.";
      else msg.textContent = "Não foi possível registar o voto. Tente novamente.";
      button.disabled = false;
      button.textContent = "CONFIRMAR VOTO";
      return;
    }
    state.votes[state.selected.id] = (state.votes[state.selected.id] || 0) + 1;
  }

  msg.textContent = "✓ Voto registado com sucesso!";
  button.textContent = "VOTO REGISTADO";
  renderRanking();
  setTimeout(closeModal, 1200);
}

document.querySelector(".close").onclick = closeModal;
document.querySelector("#cancel").onclick = closeModal;
document.querySelector("#confirm").onclick = submitVote;
document.querySelector("#modal").addEventListener("click", e => {
  if (e.target.id === "modal") closeModal();
});

(async function init() {
  renderCandidates();
  await loadVotes();
  renderRanking();
})();
