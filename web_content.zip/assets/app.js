(() => {
  const cfg = window.PRONOSTICS_CONFIG || {};
  const $ = id => document.getElementById(id);
  const statusText = $("statusText");
  const statusDetail = $("statusDetail");
  const statusDot = $("statusDot");
  const matchesEl = $("matches");
  const summaryEl = $("summary");
  const dateInput = $("dateInput");

  const today = new Intl.DateTimeFormat("en-CA", {
    timeZone: cfg.TIMEZONE || "Africa/Abidjan",
    year: "numeric", month: "2-digit", day: "2-digit"
  }).format(new Date());
  dateInput.value = today;

  function setStatus(text, detail="", kind="") {
    statusText.textContent = text;
    statusDetail.textContent = detail;
    statusDot.className = "dot " + kind;
  }

  function esc(v) {
    return String(v ?? "").replace(/[&<>"']/g, c => ({
      "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
    }[c]));
  }

  async function api(path, params={}) {
    if (!cfg.API_KEY || cfg.API_KEY.includes("COLLE_TA_CLE")) {
      throw new Error("Clé API-Football absente. Ouvre config.js et renseigne API_KEY.");
    }
    const url = new URL((cfg.API_BASE || "https://v3.football.api-sports.io") + path);
    Object.entries(params).forEach(([k,v]) => url.searchParams.set(k, v));
    const res = await fetch(url.toString(), {
      headers: { "x-apisports-key": cfg.API_KEY }
    });
    if (!res.ok) throw new Error(`API HTTP ${res.status}`);
    const data = await res.json();
    if (data.errors && Object.keys(data.errors).length) {
      throw new Error(Object.entries(data.errors).map(([k,v]) => `${k}: ${v}`).join(" · "));
    }
    return data;
  }

  function pct(x) {
    const n = Number(x);
    return Number.isFinite(n) ? `${Math.round(n)}%` : "—";
  }

  function confidence(p) {
    const values = [p.home, p.draw, p.away].filter(Number.isFinite).sort((a,b)=>b-a);
    if (!values.length) return {label:"Inconnu", cls:""};
    const top = values[0];
    if (top >= 70) return {label:"Élevée", cls:""};
    if (top >= 55) return {label:"Moyenne", cls:""};
    return {label:"Faible", cls:""};
  }

  function parsePercent(v) {
    if (typeof v === "number") return v;
    const n = parseFloat(String(v || "").replace("%",""));
    return Number.isFinite(n) ? n : NaN;
  }

  function extractProbabilities(pred) {
    const p = pred?.predictions || {};
    const percent = p.percent || {};
    return {
      home: parsePercent(percent.home),
      draw: parsePercent(percent.draw),
      away: parsePercent(percent.away)
    };
  }

  function bestOutcome(p, home, away) {
    const list = [
      {k:"1", n:home, v:p.home},
      {k:"N", n:"Match nul", v:p.draw},
      {k:"2", n:away, v:p.away}
    ].filter(x => Number.isFinite(x.v));
    if (!list.length) return "Analyse indisponible";
    list.sort((a,b)=>b.v-a.v);
    return `${list[0].k} · ${list[0].n}`;
  }

  function renderMatch(match, prediction) {
    const f = prediction ? extractProbabilities(prediction) : {home:NaN,draw:NaN,away:NaN};
    const conf = confidence(f);
    const home = match.teams?.home?.name || "Équipe domicile";
    const away = match.teams?.away?.name || "Équipe extérieur";
    const league = match.league?.name || "Compétition";
    const date = match.fixture?.date ? new Date(match.fixture.date).toLocaleTimeString("fr-FR", {
      hour:"2-digit", minute:"2-digit", timeZone: cfg.TIMEZONE || "Africa/Abidjan"
    }) : "—";
    const predText = prediction?.predictions?.advice || "";
    const winner = prediction?.predictions?.winner?.name || bestOutcome(f, home, away);
    const goals = prediction?.predictions?.goals || {};
    const score = prediction?.predictions?.score?.fulltime;
    const scoreText = score?.home != null && score?.away != null ? `${score.home}–${score.away}` : "—";

    return `
      <article class="match-card">
        <div class="match-head">
          <span class="league">${esc(league)}</span>
          <span>${esc(date)}</span>
        </div>
        <div class="teams">${esc(home)} <span class="muted">vs</span> ${esc(away)}</div>
        <div class="prediction">
          <div><span class="badge">🎯 ${esc(winner)}</span> <span class="badge">Confiance : ${esc(conf.label)}</span></div>
          <div class="grid">
            <div class="metric"><span>1</span><strong>${pct(f.home)}</strong></div>
            <div class="metric"><span>N</span><strong>${pct(f.draw)}</strong></div>
            <div class="metric"><span>2</span><strong>${pct(f.away)}</strong></div>
          </div>
          <p><strong>Score estimé :</strong> ${esc(scoreText)}</p>
          <p><strong>Buts :</strong> ${esc(goals.home ?? "—")} / ${esc(goals.away ?? "—")}</p>
          ${predText ? `<p class="muted">${esc(predText)}</p>` : ""}
        </div>
      </article>`;
  }

  async function load() {
    matchesEl.innerHTML = "";
    summaryEl.classList.add("hidden");
    setStatus("Chargement…", "Récupération des matchs et des analyses.", "");
    try {
      const date = dateInput.value || today;
      const fixtures = await api("/fixtures", {date, timezone: cfg.TIMEZONE || "Africa/Abidjan"});
      const list = fixtures.response || [];
      summaryEl.textContent = `${list.length} match(s) trouvé(s) pour ${date}.`;
      summaryEl.classList.remove("hidden");

      if (!list.length) {
        matchesEl.innerHTML = `<section class="match-card"><strong>Aucun match trouvé.</strong><p class="muted">Essaie une autre date.</p></section>`;
        setStatus("Terminé", "Aucun match trouvé.", "ok");
        return;
      }

      setStatus("Matchs récupérés", `${list.length} match(s). Analyse des pronostics…`, "ok");

      // API-Football's predictions endpoint is called one fixture at a time.
      const cards = [];
      for (const match of list.slice(0, 30)) {
        let prediction = null;
        try {
          const r = await api("/predictions", {fixture: match.fixture.id});
          prediction = r.response?.[0] || null;
        } catch (e) {
          prediction = null;
        }
        cards.push(renderMatch(match, prediction));
        matchesEl.innerHTML = cards.join("");
      }

      setStatus("Analyse terminée", `${Math.min(list.length,30)} match(s) affiché(s).`, "ok");
    } catch (e) {
      setStatus("Erreur", e.message || "Impossible de récupérer les données.", "bad");
      matchesEl.innerHTML = `<section class="match-card error"><strong>Impossible de charger les données.</strong><p>${esc(e.message)}</p></section>`;
    }
  }

  $("loadBtn").addEventListener("click", load);
  $("refreshBtn").addEventListener("click", load);

  if (cfg.API_KEY && !cfg.API_KEY.includes("COLLE_TA_CLE")) {
    setStatus("Clé configurée", "Prêt à récupérer les matchs.", "ok");
  } else {
    setStatus("Clé API nécessaire", "Renseigne API_KEY dans config.js.", "bad");
  }
})();
