(() => {
  const cfg = window.PRONOSTICS_CONFIG || {};
  const $ = id => document.getElementById(id);
  const statusText = $("statusText"), statusDetail = $("statusDetail"), statusDot = $("statusDot");
  const matchesEl = $("matches"), summaryEl = $("summary"), dateInput = $("dateInput");
  const today = new Intl.DateTimeFormat("en-CA", { timeZone: cfg.TIMEZONE || "Africa/Abidjan", year:"numeric", month:"2-digit", day:"2-digit" }).format(new Date());
  dateInput.value = today;

  function setStatus(text, detail="", kind="") { statusText.textContent=text; statusDetail.textContent=detail; statusDot.className="dot "+kind; }
  function esc(v) { return String(v ?? "").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c])); }
  async function api(path, params={}) {
    if (!cfg.API_KEY || cfg.API_KEY.includes("COLLE_TA_CLE")) throw new Error("Clé API-Football absente. Ouvre config.js et renseigne API_KEY.");
    const url=new URL((cfg.API_BASE||"https://v3.football.api-sports.io")+path);
    Object.entries(params).forEach(([k,v])=>url.searchParams.set(k,v));
    const res=await fetch(url.toString(),{headers:{"x-apisports-key":cfg.API_KEY}});
    if(!res.ok) throw new Error(`API HTTP ${res.status}`);
    const data=await res.json();
    if(data.errors&&Object.keys(data.errors).length) throw new Error(Object.entries(data.errors).map(([k,v])=>`${k}: ${v}`).join(" · "));
    return data;
  }
  function pct(x){const n=Number(x);return Number.isFinite(n)?`${Math.round(n)}%`:"—";}
  function num(x){const n=Number(x);return Number.isFinite(n)?n:NaN;}
  function confidence(p){const values=[p.home,p.draw,p.away].filter(Number.isFinite).sort((a,b)=>b-a);if(!values.length)return{label:"Inconnue",cls:""};return values[0]>=70?{label:"Élevée",cls:"high"}:values[0]>=55?{label:"Moyenne",cls:"medium"}:{label:"Faible",cls:"low"};}
  function parsePercent(v){if(typeof v==="number")return v;const n=parseFloat(String(v||"").replace("%",""));return Number.isFinite(n)?n:NaN;}
  function extractProbabilities(pred){const p=pred?.predictions||{}, percent=p.percent||{};return{home:parsePercent(percent.home),draw:parsePercent(percent.draw),away:parsePercent(percent.away)};}
  function bestOutcome(p,home,away){const list=[{k:"1",n:home,v:p.home},{k:"N",n:"Match nul",v:p.draw},{k:"2",n:away,v:p.away}].filter(x=>Number.isFinite(x.v));if(!list.length)return"Analyse indisponible";list.sort((a,b)=>b.v-a.v);return`${list[0].k} · ${list[0].n}`;}
  function resultForTeam(fixture, teamId){
    const h=fixture.teams?.home, a=fixture.teams?.away, hg=num(fixture.goals?.home), ag=num(fixture.goals?.away);
    if(!h||!a||!Number.isFinite(hg)||!Number.isFinite(ag)) return {code:"?",cls:"unknown"};
    const isHome=h.id===teamId, gf=isHome?hg:ag, ga=isHome?ag:hg;
    if(gf>ga)return{code:"V",cls:"win"}; if(gf<ga)return{code:"D",cls:"loss"}; return{code:"N",cls:"draw"};
  }
  function formStats(fixtures, teamId){
    const arr=(fixtures||[]).filter(f=>f.teams?.home?.id===teamId||f.teams?.away?.id===teamId).slice(-5);
    let w=0,d=0,l=0,gf=0,ga=0;
    arr.forEach(f=>{const r=resultForTeam(f,teamId);if(r.code==="V")w++;else if(r.code==="N")d++;else if(r.code==="D")l++;const h=f.teams.home.id===teamId;const a=num(f.goals?.away),hh=num(f.goals?.home);if(Number.isFinite(hh)&&Number.isFinite(a)){gf+=h?hh:a;ga+=h?a:hh;}});
    return {arr,w,d,l,gf,ga};
  }
  function formHTML(label, teamId, fixtures){
    const s=formStats(fixtures,teamId); const names=s.arr.map(f=>{const opp=f.teams.home.id===teamId?f.teams.away.name:f.teams.home.name;const r=resultForTeam(f,teamId);return `<div class="form-row"><span class="form-dot ${r.cls}">${r.code}</span><span>${esc(opp)}</span></div>`}).join("")||'<div class="muted">Forme indisponible.</div>';
    return `<div class="detail-card"><div class="detail-title">📈 ${esc(label)} — 5 derniers matchs</div><div class="form-summary"><b>${s.w} V</b><b>${s.d} N</b><b>${s.l} D</b><span>${s.gf} buts marqués · ${s.ga} encaissés</span></div><div class="form-list">${names}</div></div>`;
  }
  function h2hHTML(h2h, homeId, awayId){
    const list=(h2h||[]).slice(0,5); let hw=0,aw=0,d=0;
    list.forEach(f=>{const hg=num(f.goals?.home),ag=num(f.goals?.away);if(!Number.isFinite(hg)||!Number.isFinite(ag))return;if(hg===ag)d++;else if((f.teams?.home?.id===homeId&&hg>ag)||(f.teams?.away?.id===homeId&&ag>hg))hw++;else aw++;});
    const rows=list.map(f=>`<div class="h2h-row"><span>${esc(f.teams?.home?.name||"—")}</span><strong>${esc(f.goals?.home??"—")}–${esc(f.goals?.away??"—")}</strong><span>${esc(f.teams?.away?.name||"—")}</span></div>`).join("")||'<div class="muted">Aucune confrontation disponible.</div>';
    return `<div class="detail-card"><div class="detail-title">⚔️ Confrontations directes</div><div class="form-summary"><b>${hw} ${esc("victoire(s) "+(h2h?.[0]?.teams?.home?.id===homeId?"domicile":""))}</b><b>${d} nul(s)</b><b>${aw} autre(s)</b></div><div class="h2h-list">${rows}</div></div>`;
  }
  function statValue(stats, names){
    const wanted = names.map(x=>x.toLowerCase());
    const row = (stats||[]).find(x=>wanted.includes(String(x.type||"").toLowerCase()));
    if(!row || row.value==null || row.value==="") return null;
    return row.value;
  }
  function statNumber(v){
    if(v==null) return NaN;
    const n=parseFloat(String(v).replace('%','').replace(',','.'));
    return Number.isFinite(n)?n:NaN;
  }
  function statDisplay(v, suffix=""){
    if(v==null || v==="") return "—";
    return `${esc(v)}${suffix}`;
  }
  function statBar(home, away, unit=""){
    const h=statNumber(home), a=statNumber(away);
    if(!Number.isFinite(h)||!Number.isFinite(a)||(h+a)<=0) return `<div class="stat-bar"><span class="bar-fill home-fill" style="width:50%"></span><span class="bar-fill away-fill" style="width:50%"></span></div>`;
    const hp=Math.max(0,Math.min(100,(h/(h+a))*100));
    return `<div class="stat-bar"><span class="bar-fill home-fill" style="width:${hp}%"></span><span class="bar-fill away-fill" style="width:${100-hp}%"></span></div>`;
  }
  function matchStatsHTML(statistics, homeName, awayName, homeId=window.__detailHomeId, awayId=window.__detailAwayId, liveInfo=""){
    const blocks=statistics||[];
    const home=blocks.find(x=>x.team?.id===homeId)?.statistics||[];
    const away=blocks.find(x=>x.team?.id===awayId)?.statistics||[];
    const rows=[
      {label:"Possession", names:["Ball Possession"], suffix:""},
      {label:"Tirs", names:["Total Shots"]},
      {label:"Tirs cadrés", names:["Shots on Goal","Shots on Target"]},
      {label:"Corners", names:["Corner Kicks","Corners"]},
      {label:"Cartons jaunes", names:["Yellow Cards"]},
      {label:"Cartons rouges", names:["Red Cards"]}
    ];
    const html=rows.map(r=>{
      const hv=statValue(home,r.names), av=statValue(away,r.names);
      return `<div class="stat-row"><div class="stat-name">${esc(r.label)}</div><strong class="stat-home">${statDisplay(hv)}</strong><div class="stat-center">${statBar(hv,av)}</div><strong class="stat-away">${statDisplay(av)}</strong></div>`;
    }).join("");
    return `<div class="detail-card stats-card"><div class="detail-title">📊 Statistiques du match ${liveInfo}</div><div class="stat-legend"><span><i class="legend-home"></i>${esc(homeName)}</span><span><i class="legend-away"></i>${esc(awayName)}</span></div><div class="stats-table">${html}</div><div class="notice">Les statistiques sont affichées lorsqu'elles sont disponibles pour ce match. API-Football précise que certaines compétitions ne fournissent pas toutes les statistiques.</div></div>`;
  }
  function eventIcon(ev){
    const type=String(ev?.type||'').toLowerCase(), detail=String(ev?.detail||'').toLowerCase();
    if(type==='goal') return detail.includes('own') ? '🔴' : detail.includes('missed') ? '❌' : '⚽';
    if(type==='card') return detail.includes('red') ? '🟥' : detail.includes('yellow-red') ? '🟨🟥' : '🟨';
    if(type==='subst') return '🔄';
    if(type.includes('var')) return '📺';
    return '•';
  }
  function eventLabel(ev){
    const type=String(ev?.type||'').toLowerCase(), detail=String(ev?.detail||'');
    if(type==='goal'){
      if(detail.toLowerCase().includes('own')) return 'But contre son camp';
      if(detail.toLowerCase().includes('penalty')) return 'But sur penalty';
      if(detail.toLowerCase().includes('missed')) return 'Penalty manqué';
      return 'But';
    }
    if(type==='card') return detail || 'Carton';
    if(type==='subst') return 'Remplacement';
    if(type.includes('var')) return detail || 'VAR';
    return detail || ev?.type || 'Événement';
  }
  function eventMinute(ev){
    const elapsed=ev?.time?.elapsed, extra=ev?.time?.extra;
    if(elapsed==null) return '—′';
    return extra!=null ? `${elapsed}+${extra}′` : `${elapsed}′`;
  }
  function eventsHTML(events, homeId, awayId, homeName, awayName){
    const list=(events||[]).slice().sort((a,b)=>(Number(a?.time?.elapsed)||0)-(Number(b?.time?.elapsed)||0) || (Number(a?.time?.extra)||0)-(Number(b?.time?.extra)||0));
    if(!list.length) return `<div class="detail-card live-events"><div class="detail-title">⏱️ Événements en direct</div><div class="muted">Aucun événement communiqué pour le moment.</div></div>`;
    const rows=list.map(ev=>{
      const teamId=ev?.team?.id, side=teamId===homeId?'home':teamId===awayId?'away':'neutral';
      const player=ev?.player?.name||'—', assist=ev?.assist?.name, icon=eventIcon(ev), label=eventLabel(ev);
      const subIn=ev?.assist?.name && String(ev?.type||'').toLowerCase()==='subst' ? ev.assist.name : null;
      const subOut=ev?.player?.name && String(ev?.type||'').toLowerCase()==='subst' ? ev.player.name : null;
      const text=String(ev?.type||'').toLowerCase()==='subst' ? `${esc(subOut||'—')} <span class="event-arrow">→</span> ${esc(subIn||'—')}` : `${esc(player)}${assist && String(ev?.type||'').toLowerCase()==='goal'?` <span class="event-assist">(passe : ${esc(assist)})</span>`:''}`;
      return `<div class="event-row ${side}"><div class="event-minute">${esc(eventMinute(ev))}</div><div class="event-icon">${icon}</div><div class="event-body"><strong>${esc(label)}</strong><div>${text}</div></div><div class="event-team">${esc(ev?.team?.name|| (side==='home'?homeName:side==='away'?awayName:'—'))}</div></div>`;
    }).join('');
    return `<div class="detail-card live-events"><div class="detail-title">⏱️ Événements minute par minute <span class="event-count">${list.length}</span></div><div class="event-list">${rows}</div><div class="notice">🔄 La timeline est actualisée automatiquement pendant le direct.</div></div>`;
  }
  function injuriesHTML(injuries, homeId, awayId){
    const list=injuries||[]; const home=list.filter(x=>x.team?.id===homeId), away=list.filter(x=>x.team?.id===awayId);
    const block=(label,arr)=>`<div class="absence-side"><strong>${esc(label)}</strong>${arr.length?arr.map(x=>`<div class="absence"><span>⚠️ ${esc(x.player?.name||"Joueur")}</span><small>${esc(x.type||"Indisponibilité")} · ${esc(x.reason||"raison non précisée")}</small></div>`).join(""):'<div class="muted">Aucune absence signalée par l’API.</div>'}</div>`;
    return `<div class="detail-card"><div class="detail-title">🚑 Absences et suspensions</div><div class="absence-grid">${block("Équipe à domicile",home)}${block("Équipe à l’extérieur",away)}</div></div>`;
  }
  function explanation(pred, match, homeForm, awayForm, injuries){
    const p=pred?.predictions||{}, probs=extractProbabilities(pred), home=match.teams.home.name, away=match.teams.away.name;
    const winner=p.winner?.name||bestOutcome(probs,home,away), score=p.score?.fulltime;
    const factors=[];
    if(Number.isFinite(probs.home)||Number.isFinite(probs.away)||Number.isFinite(probs.draw)) factors.push(`Le modèle donne ${pct(probs.home)} à ${home}, ${pct(probs.draw)} au nul et ${pct(probs.away)} à ${away}.`);
    if(p.advice) factors.push(`Conseil du modèle : ${p.advice}.`);
    if(p.under_over) factors.push(`Le scénario buts privilégié est ${p.under_over}.`);
    if(score?.home!=null&&score?.away!=null) factors.push(`Le score théorique proposé est ${score.home}–${score.away}.`);
    const hf=formStats(homeForm,match.teams.home.id), af=formStats(awayForm,match.teams.away.id);
    if(hf.arr.length&&af.arr.length) factors.push(`Sur leurs cinq derniers matchs, ${home} affiche ${hf.w} victoire(s), ${hf.d} nul(s), ${hf.l} défaite(s), contre ${af.w}/${af.d}/${af.l} pour ${away}.`);
    const injHome=(injuries||[]).filter(x=>x.team?.id===match.teams.home.id).length, injAway=(injuries||[]).filter(x=>x.team?.id===match.teams.away.id).length;
    if(injHome||injAway) factors.push(`Le rapport d’absences signale ${injHome} indisponibilité(s) côté ${home} et ${injAway} côté ${away}.`);
    return `<div class="detail-card explanation"><div class="detail-title">🧠 Pourquoi ce pronostic ?</div><p>Le choix principal est <strong>${esc(winner)}</strong>. Voici les éléments qui l’expliquent :</p><ul>${factors.map(x=>`<li>${esc(x)}</li>`).join("")||'<li>Les données détaillées du modèle ne sont pas disponibles pour ce match.</li>'}</ul><div class="notice">ℹ️ Les données peuvent être incomplètes selon la couverture de la compétition. Ce pronostic reste une estimation et ne garantit pas le résultat.</div></div>`;
  }
  function renderMatch(match,prediction){
    const f=prediction?extractProbabilities(prediction):{home:NaN,draw:NaN,away:NaN}, conf=confidence(f), home=match.teams?.home?.name||"Équipe domicile", away=match.teams?.away?.name||"Équipe extérieur", league=match.league?.name||"Compétition";
    const date=match.fixture?.date?new Date(match.fixture.date).toLocaleTimeString("fr-FR",{hour:"2-digit",minute:"2-digit",timeZone:cfg.TIMEZONE||"Africa/Abidjan"}):"—";
    const predText=prediction?.predictions?.advice||"", winner=prediction?.predictions?.winner?.name||bestOutcome(f,home,away), goals=prediction?.predictions?.goals||{}, score=prediction?.predictions?.score?.fulltime, scoreText=score?.home!=null&&score?.away!=null?`${score.home}–${score.away}`:"—";
    return `<article class="match-card" data-fixture="${esc(match.fixture.id)}"><div class="match-head"><span class="league">${esc(league)}</span><span>${esc(date)}</span></div><div class="teams">${esc(home)} <span class="muted">vs</span> ${esc(away)}</div><div class="prediction"><div><span class="badge winner">🎯 ${esc(winner)}</span> <span class="badge">Confiance : ${esc(conf.label)}</span></div><div class="grid"><div class="metric home-m"><span>1</span><strong>${pct(f.home)}</strong></div><div class="metric draw-m"><span>N</span><strong>${pct(f.draw)}</strong></div><div class="metric away-m"><span>2</span><strong>${pct(f.away)}</strong></div></div><p><strong>Score estimé :</strong> ${esc(scoreText)} · <strong>Buts :</strong> ${esc(goals.home??"—")} / ${esc(goals.away??"—")}</p>${predText?`<p class="muted">${esc(predText)}</p>`:""}<button class="details-btn" data-detail="${esc(match.fixture.id)}">🔎 Voir l’analyse complète</button><div id="detail-${esc(match.fixture.id)}" class="match-detail hidden"></div></div></article>`;
  }
  const LIVE_STATUSES = new Set(["1H","2H","ET"]);
  window.__liveTimers = window.__liveTimers || {};
  function stopLiveRefresh(fixtureId){
    const timer=window.__liveTimers[fixtureId];
    if(timer){clearInterval(timer);delete window.__liveTimers[fixtureId];}
  }
  function startLiveRefresh(match, detail){
    const fixtureId=match.fixture.id; stopLiveRefresh(fixtureId);
    const refresh=async()=>{
      if(detail.classList.contains("hidden")){stopLiveRefresh(fixtureId);return;}
      try{
        const r=await api("/fixtures",{id:fixtureId});
        const f=r.response?.[0]; if(!f)return;
        const status=f.fixture?.status?.short||"";
        const stats=f.statistics||[];
        const events=f.events||[];
        const homeId=match.teams.home.id, awayId=match.teams.away.id;
        const info=LIVE_STATUSES.has(status)
          ? `<span class="live-indicator">● LIVE · ${esc(f.fixture?.status?.elapsed??"—")}′</span>`
          : status==="HT" ? `<span class="live-indicator">⏸ MI-TEMPS</span>`
          : `<span class="live-indicator ended">${esc(f.fixture?.status?.long||status)}</span>`;
        const box=detail.querySelector(".stats-card");
        if(box){box.outerHTML=matchStatsHTML(stats,match.teams.home.name,match.teams.away.name,homeId,awayId,info);}
        const timeline=detail.querySelector(".live-events");
        if(timeline){timeline.outerHTML=eventsHTML(events,homeId,awayId,match.teams.home.name,match.teams.away.name);}
        const score=`${f.goals?.home??0} – ${f.goals?.away??0}`;
        const scoreEls=detail.querySelectorAll(".live-score"); scoreEls.forEach(el=>el.textContent=score);
        const top=detail.querySelector(".detail-top");
        if(top){const pill=top.querySelector(".live-status-pill"); if(pill) pill.innerHTML=info; const note=top.querySelector(".live-update-note"); if(note) note.textContent=LIVE_STATUSES.has(status)?"Événements : ~15 s · Statistiques : ~60 s.":"";}
        if(!LIVE_STATUSES.has(status) && status!=="HT") stopLiveRefresh(fixtureId);
      }catch(e){
        const note=detail.querySelector(".live-update-note"); if(note) note.textContent="Mise à jour en direct : nouvelle tentative dans 15 s.";
      }
    };
    if(LIVE_STATUSES.has(match.fixture?.status?.short||"") || match.fixture?.status?.short==="HT"){
      refresh();
      window.__liveTimers[fixtureId]=setInterval(refresh,15000);
    }
  }
  async function openDetail(match){
    const detail=$("detail-"+match.fixture.id); if(!detail)return; detail.classList.remove("hidden"); stopLiveRefresh(match.fixture.id); detail.innerHTML='<div class="detail-loading">⏳ Analyse détaillée en cours…</div>';
    try{
      const homeId=match.teams.home.id, awayId=match.teams.away.id;
      const [homeR,awayR,h2hR,injR,predR,fixtureR]=await Promise.all([
        api("/fixtures",{team:homeId,last:5,status:"FT",timezone:cfg.TIMEZONE||"Africa/Abidjan"}),
        api("/fixtures",{team:awayId,last:5,status:"FT",timezone:cfg.TIMEZONE||"Africa/Abidjan"}),
        api("/fixtures/headtohead",{h2h:`${homeId}-${awayId}`,last:5}),
        api("/injuries",{fixture:match.fixture.id}),
        api("/predictions",{fixture:match.fixture.id}),
        api("/fixtures",{id:match.fixture.id})
      ]);
      const hf=homeR.response||[], af=awayR.response||[], hh=h2hR.response||[], inj=injR.response||[], pred=predR.response?.[0]||null, detailFixture=fixtureR.response?.[0]||null;
      const statistics=detailFixture?.statistics||[];
      const status=detailFixture?.fixture?.status?.short||match.fixture?.status?.short||"";
      window.__detailHomeId=homeId; window.__detailAwayId=awayId;
      const liveInfo=LIVE_STATUSES.has(status)?`<span class="live-indicator">● LIVE · ${esc(detailFixture.fixture.status.elapsed??"—")}′</span>`:(status==="HT"?`<span class="live-indicator">⏸ MI-TEMPS</span>`:"");
      const score=`<span class="live-score">${detailFixture?.goals?.home??"—"} – ${detailFixture?.goals?.away??"—"}</span>`;
      detail.innerHTML=`<div class="detail-top"><span class="detail-pill">${esc(match.league?.name||"Match")}</span><strong>${esc(match.teams.home.name)} <span class="muted">${score}</span> ${esc(match.teams.away.name)}</strong><span class="live-status-pill">${liveInfo}</span><span class="live-update-note">${LIVE_STATUSES.has(status)?"Événements : ~15 s · Statistiques : ~60 s.":""}</span></div>${eventsHTML(detailFixture?.events||[],homeId,awayId,match.teams.home.name,match.teams.away.name)}${matchStatsHTML(statistics,match.teams.home.name,match.teams.away.name,homeId,awayId,liveInfo)}${formHTML(match.teams.home.name,homeId,hf)}${formHTML(match.teams.away.name,awayId,af)}${h2hHTML(hh,homeId,awayId)}${injuriesHTML(inj,homeId,awayId)}${explanation(pred,match,hf,af,inj)}`;
      if(LIVE_STATUSES.has(status)) startLiveRefresh({...match,fixture:{...match.fixture,status:detailFixture.fixture.status}},detail);
      else if(status==="HT") startLiveRefresh({...match,fixture:{...match.fixture,status:detailFixture.fixture.status}},detail);
    }catch(e){detail.innerHTML=`<div class="detail-card error"><strong>Analyse détaillée indisponible.</strong><p>${esc(e.message)}</p><small>Vérifie la couverture de la compétition et ta connexion.</small></div>`;}
  }
  async function load(){
    matchesEl.innerHTML=""; summaryEl.classList.add("hidden"); setStatus("Chargement…","Récupération des matchs et des analyses.","");
    try{const date=dateInput.value||today;const fixtures=window.__prefetchedFixtures&&window.__prefetchedDate===date?{response:window.__prefetchedFixtures}:await api("/fixtures",{date,timezone:cfg.TIMEZONE||"Africa/Abidjan"});const list=fixtures.response||[];summaryEl.textContent=`${list.length} match(s) trouvé(s) pour ${date}. Appuie sur « Voir l’analyse complète » pour les détails.`;summaryEl.classList.remove("hidden");if(!list.length){matchesEl.innerHTML='<section class="match-card"><strong>Aucun match trouvé.</strong><p class="muted">Essaie une autre date.</p></section>';setStatus("Terminé","Aucun match trouvé.","ok");return;}setStatus("Matchs récupérés",`${list.length} match(s). Analyse des pronostics…`,"ok");const cards=[];for(const match of list.slice(0,30)){let prediction=null;try{prediction=(await api("/predictions",{fixture:match.fixture.id})).response?.[0]||null;}catch(e){}cards.push(renderMatch(match,prediction));matchesEl.innerHTML=cards.join("");}setStatus("Analyse terminée",`${Math.min(list.length,30)} match(s) affiché(s).`,"ok");}
    catch(e){setStatus("Erreur",e.message||"Impossible de récupérer les données.","bad");matchesEl.innerHTML=`<section class="match-card error"><strong>Impossible de charger les données.</strong><p>${esc(e.message)}</p></section>`;}
  }
  matchesEl.addEventListener("click",e=>{const b=e.target.closest("[data-detail]");if(!b)return;const card=b.closest(".match-card"), id=Number(b.dataset.detail);const cache=window.__matches||{};const match=cache[id];if(match){if(b.textContent.includes("Fermer")){$("detail-"+id).classList.add("hidden");stopLiveRefresh(id);b.textContent="🔎 Voir l’analyse complète";}else{b.textContent="✕ Fermer l’analyse";openDetail(match);}}});
  const originalLoad=load;
  async function loadAndCache(){window.__matches={};window.__prefetchedFixtures=null;window.__prefetchedDate=null;try{const date=dateInput.value||today;const fixtures=await api("/fixtures",{date,timezone:cfg.TIMEZONE||"Africa/Abidjan"});window.__prefetchedFixtures=fixtures.response||[];window.__prefetchedDate=date;window.__prefetchedFixtures.slice(0,30).forEach(m=>window.__matches[m.fixture.id]=m);}catch(e){}return originalLoad();}
  $("loadBtn").addEventListener("click",loadAndCache); $("refreshBtn").addEventListener("click",loadAndCache);
  if(cfg.API_KEY&&!cfg.API_KEY.includes("COLLE_TA_CLE"))setStatus("Clé configurée","Prêt à récupérer les matchs.","ok");else setStatus("Clé API nécessaire","Renseigne API_KEY dans config.js.","bad");
})();
