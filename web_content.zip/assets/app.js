/* =========================================================
   MATYKA CHEATS — PROXY ANDROID
   Lógica local, persistência em localStorage e navegação
   ========================================================= */

(function () {
  "use strict";

  const STORAGE_KEYS = {
    LICENSE: "mtk_proxy_license_v1",
    FEATURES: "mtk_proxy_features_v1",
    PACKAGE: "mtk_proxy_package_v1",
    PREFS: "mtk_proxy_prefs_v1",
    CONN: "mtk_proxy_conn_v1",
    LOGS: "mtk_proxy_logs_v1"
  };

  // Referências DOM
  const splashScreen = document.getElementById("splash-screen");
  const splashProgress = document.getElementById("splash-progress");
  const splashStatus = document.getElementById("splash-status");

  const activationScreen = document.getElementById("activation-screen");
  const activationForm = document.getElementById("activation-form");
  const licenseInput = document.getElementById("license-key");
  const activationFeedback = document.getElementById("activation-feedback");

  const mainApp = document.getElementById("main-app");
  const tabNav = document.querySelector(".tab-nav");
  const tabBtns = document.querySelectorAll(".tab-btn");
  const tabPanes = document.querySelectorAll(".tab-pane");

  const featureToggles = document.querySelectorAll(".toggle-input[data-category]");
  const activeModulesCount = document.getElementById("active-modules-count");

  const targetPackageInput = document.getElementById("target-package");
  const btnInject = document.getElementById("btn-inject");
  const injectProgressWrap = document.getElementById("inject-progress-wrap");
  const injectBarFill = document.getElementById("inject-bar-fill");
  const injectStepText = document.getElementById("inject-step-text");
  const injectFeedback = document.getElementById("inject-feedback");

  // Conexões
  const connIpInput = document.getElementById("conn-ip");
  const connPortInput = document.getElementById("conn-port");
  const connPairingInput = document.getElementById("conn-pairing");
  const connStateBadge = document.getElementById("conn-state-badge");
  const connStateLabel = document.getElementById("conn-state-label");
  const connStatusDetail = document.getElementById("conn-status-detail");
  const networkOnlineTag = document.getElementById("network-online-tag");
  const btnConnStart = document.getElementById("btn-conn-start");
  const btnConnStop = document.getElementById("btn-conn-stop");
  const btnConnRefresh = document.getElementById("btn-conn-refresh");
  const btnAndroidSettings = document.getElementById("btn-android-settings");
  const btnClearConnLog = document.getElementById("btn-clear-conn-log");
  const activityLogList = document.getElementById("activity-log-list");

  // Configurações
  const settingsModal = document.getElementById("settings-modal");
  const btnOpenSettings = document.getElementById("btn-open-settings");
  const btnCloseSettings = document.getElementById("btn-close-settings");
  const settingsActiveKey = document.getElementById("settings-active-key");
  const settingsHistoryList = document.getElementById("settings-history-list");
  const prefVibration = document.getElementById("pref-vibration");
  const prefAutoPackage = document.getElementById("pref-auto-package");
  const btnClearLocalData = document.getElementById("btn-clear-local-data");
  const btnLogout = document.getElementById("btn-logout");

  const toastEl = document.getElementById("toast");
  let toastTimer = null;

  // Utilitários
  function readJSON(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (_) {
      return fallback;
    }
  }

  function writeJSON(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (_) {}
  }

  function vibrate(ms) {
    const prefs = readJSON(STORAGE_KEYS.PREFS, { vibration: true, autoPackage: true });
    if (prefs.vibration && typeof navigator !== "undefined" && typeof navigator.vibrate === "function") {
      navigator.vibrate(ms);
    }
  }

  function showToast(message) {
    toastEl.textContent = message;
    toastEl.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      toastEl.classList.remove("show");
    }, 2600);
  }

  function getTimeNow() {
    const now = new Date();
    return now.toTimeString().slice(0, 8);
  }

  function appendLog(message) {
    const logs = readJSON(STORAGE_KEYS.LOGS, []);
    logs.unshift({ time: getTimeNow(), text: message });
    if (logs.length > 30) logs.length = 30;
    writeJSON(STORAGE_KEYS.LOGS, logs);
    renderLogs();
  }

  function renderLogs() {
    const logs = readJSON(STORAGE_KEYS.LOGS, []);
    const emptyHTML = '<li><span>Nenhum registro recente.</span><span class="log-time">--:--:--</span></li>';
    const itemsHTML = logs.length
      ? logs.map((item) => `<li><span>${escapeHTML(item.text)}</span><span class="log-time">${item.time}</span></li>`).join("")
      : emptyHTML;

    if (activityLogList) activityLogList.innerHTML = itemsHTML;
    if (settingsHistoryList) settingsHistoryList.innerHTML = itemsHTML;
  }

  function escapeHTML(str) {
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  // 1. SPLASH SCREEN
  function runSplash() {
    const steps = [
      { pct: 30, text: "CARREGANDO INTERFACE MATYKA..." },
      { pct: 68, text: "VERIFICANDO ARMAZENAMENTO LOCAL..." },
      { pct: 100, text: "PRONTO" }
    ];

    let idx = 0;
    const interval = setInterval(() => {
      if (idx < steps.length) {
        splashProgress.style.width = steps[idx].pct + "%";
        splashStatus.textContent = steps[idx].text;
        idx++;
      } else {
        clearInterval(interval);
        setTimeout(() => {
          splashScreen.classList.remove("active");
          checkLicenseState();
        }, 320);
      }
    }, 340);
  }

  // 2. SISTEMA DE ATIVAÇÃO
  function checkLicenseState() {
    const savedKey = localStorage.getItem(STORAGE_KEYS.LICENSE);
    if (savedKey && savedKey.trim().length > 0) {
      enterMainApp(savedKey.trim());
    } else {
      mainApp.classList.add("hidden");
      activationScreen.classList.add("active");
    }
  }

  function enterMainApp(key) {
    activationScreen.classList.remove("active");
    mainApp.classList.remove("hidden");
    settingsActiveKey.textContent = key;
    restoreAllState();
  }

  activationForm.addEventListener("submit", function (e) {
    e.preventDefault();
    const keyVal = licenseInput.value.trim();

    if (!keyVal) {
      activationFeedback.className = "feedback-msg error";
      activationFeedback.textContent = "Informe uma chave de acesso válida para continuar.";
      vibrate(35);
      return;
    }

    localStorage.setItem(STORAGE_KEYS.LICENSE, keyVal);
    activationFeedback.className = "feedback-msg success";
    activationFeedback.textContent = "Acesso liberado. Carregando perfil...";
    vibrate(25);
    appendLog("Licença ativada localmente.");

    setTimeout(() => {
      activationFeedback.textContent = "";
      licenseInput.value = "";
      enterMainApp(keyVal);
    }, 450);
  });

  // 3. NAVEGAÇÃO DE ABAS
  tabBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      const targetId = btn.getAttribute("data-tab");
      tabBtns.forEach((b) => {
        b.classList.remove("active");
        b.setAttribute("aria-selected", "false");
      });
      tabPanes.forEach((p) => p.classList.remove("active"));

      btn.classList.add("active");
      btn.setAttribute("aria-selected", "true");
      document.getElementById(targetId).classList.add("active");

      if (targetId === "tab-conexoes") {
        tabNav.classList.add("second-active");
        updateNetworkIndicator();
      } else {
        tabNav.classList.remove("second-active");
      }
      vibrate(12);
    });
  });

  // 4. CONTROLES DA ABA FUNÇÕES
  function updateFeatureRowVisual(toggle) {
    const row = toggle.closest(".feature-row");
    if (row) {
      row.classList.toggle("is-on", toggle.checked);
    }
  }

  function updateModulesCounter() {
    let activeCount = 0;
    featureToggles.forEach((t) => {
      if (t.checked) activeCount++;
    });
    activeModulesCount.textContent = `${activeCount} / ${featureToggles.length}`;
  }

  function saveFeaturesState() {
    const state = {};
    featureToggles.forEach((t) => {
      state[t.id] = t.checked;
    });
    writeJSON(STORAGE_KEYS.FEATURES, state);
    updateModulesCounter();
  }

  featureToggles.forEach((toggle) => {
    toggle.addEventListener("change", () => {
      updateFeatureRowVisual(toggle);
      saveFeaturesState();
      const cat = toggle.getAttribute("data-category");
      const name = toggle.getAttribute("data-name");
      const status = toggle.checked ? "ativado" : "desativado";
      vibrate(15);
      showToast(`[${cat}] ${name} ${status}`);
      appendLog(`${cat}: ${name} ${status}.`);
    });
  });

  // 5. BOTÃO PRINCIPAL INJETAR & ABERTURA DE PACOTE
  targetPackageInput.addEventListener("input", () => {
    const prefs = readJSON(STORAGE_KEYS.PREFS, { vibration: true, autoPackage: true });
    if (prefs.autoPackage) {
      localStorage.setItem(STORAGE_KEYS.PACKAGE, targetPackageInput.value.trim());
    }
  });

  function launchAndroidPackage(pkgName) {
    const cleanPkg = pkgName.replace(/[^a-zA-Z0-9._]/g, "");
    if (!cleanPkg) return;

    // Tentativa padrão Android Intent URI suportada por WebViews / APK Forge
    const intentUrl = `intent://#Intent;package=${cleanPkg};end`;
    try {
      window.location.href = intentUrl;
    } catch (_) {}
  }

  btnInject.addEventListener("click", () => {
    const pkg = targetPackageInput.value.trim();
    if (!pkg) {
      injectFeedback.textContent = "Informe o nome do pacote instalado antes de prosseguir.";
      showToast("Informe o pacote do aplicativo.");
      vibrate(30);
      return;
    }

    const activeNames = [];
    featureToggles.forEach((t) => {
      if (t.checked) activeNames.push(t.getAttribute("data-name"));
    });

    btnInject.disabled = true;
    injectProgressWrap.classList.remove("hidden");
    injectBarFill.style.width = "15%";
    injectStepText.textContent = "Consolidando preferências selecionadas...";
    injectFeedback.textContent = "";
    vibrate(25);

    setTimeout(() => {
      injectBarFill.style.width = "62%";
      injectStepText.textContent = `Preparando solicitação para ${pkg}...`;
    }, 450);

    setTimeout(() => {
      injectBarFill.style.width = "100%";
      injectStepText.textContent = "Perfil salvo. Solicitando abertura do pacote...";
      btnInject.disabled = false;

      const summary = activeNames.length
        ? `${activeNames.length} opção(ões) salva(s) no perfil local.`
        : "Nenhuma opção marcada no perfil local.";

      injectFeedback.textContent = `${summary} Solicitando abertura do pacote "${pkg}" ao sistema Android.`;
      appendLog(`Solicitada abertura do pacote ${pkg} (${activeNames.length} opções).`);
      showToast(`Abrindo pacote: ${pkg}`);
      launchAndroidPackage(pkg);
    }, 950);
  });

  // 6. ABA CONEXÕES (MATYKA CONNECTIONS)
  function updateNetworkIndicator() {
    const online = typeof navigator !== "undefined" ? navigator.onLine : true;
    networkOnlineTag.textContent = online ? "REDE ONLINE" : "OFFLINE";
  }

  function saveConnFields() {
    writeJSON(STORAGE_KEYS.CONN, {
      ip: connIpInput.value.trim(),
      port: connPortInput.value.trim(),
      pairing: connPairingInput.value.trim()
    });
  }

  [connIpInput, connPortInput, connPairingInput].forEach((el) => {
    el.addEventListener("input", saveConnFields);
  });

  btnConnStart.addEventListener("click", () => {
    const ip = connIpInput.value.trim();
    const port = connPortInput.value.trim();
    const pairing = connPairingInput.value.trim();

    saveConnFields();
    vibrate(20);

    if (!ip || !port) {
      connStateBadge.className = "conn-badge idle";
      connStateLabel.textContent = "DADOS INCOMPLETOS";
      connStatusDetail.textContent = "Preencha IP e PORT obtidos na tela de Depuração sem fio do Android.";
      showToast("Informe IP e PORT.");
      return;
    }

    connStateBadge.className = "conn-badge ready";
    connStateLabel.textContent = "PARÂMETROS PRONTOS";
    connStatusDetail.textContent = `Parâmetros registrados localmente (${ip}:${port}${pairing ? " | Código: " + pairing : ""}). O ambiente WebView não executa daemon ADB diretamente; utilize as Configurações do Android para parear o dispositivo.`;
    appendLog(`Parâmetros Wi-Fi registrados: ${ip}:${port}`);
    showToast("Parâmetros de depuração salvos.");
  });

  btnConnStop.addEventListener("click", () => {
    vibrate(15);
    connStateBadge.className = "conn-badge idle";
    connStateLabel.textContent = "INTERROMPIDO";
    connStatusDetail.textContent = "Sessão local encerrada. Nenhuma conexão ativa em andamento.";
    appendLog("Sessão de conexão interrompida.");
    showToast("Sessão encerrada.");
  });

  btnConnRefresh.addEventListener("click", () => {
    vibrate(15);
    updateNetworkIndicator();
    const online = navigator.onLine ? "conectado à rede" : "sem rede ativa";
    connStatusDetail.textContent = `Status verificado às ${getTimeNow()}: dispositivo ${online}. Nenhuma ponte ADB nativa detectada no navegador.`;
    appendLog("Status de rede atualizado.");
    showToast("Status atualizado.");
  });

  btnAndroidSettings.addEventListener("click", () => {
    vibrate(20);
    appendLog("Tentativa de abertura das Configurações do Android.");
    showToast("Abrindo Configurações do Android...");

    // Tenta abrir Opções do Desenvolvedor / Configurações do Android via Intent URI
    const devIntent = "intent://#Intent;action=android.settings.APPLICATION_DEVELOPMENT_SETTINGS;end";
    const fallbackSettings = "intent://#Intent;action=android.settings.SETTINGS;end";

    try {
      window.location.href = devIntent;
      setTimeout(() => {
        connStatusDetail.textContent = "Solicitação enviada ao Android. Caso não abra automaticamente no navegador, acesse Ajustes > Opções do desenvolvedor > Depuração por Wi-Fi.";
      }, 600);
    } catch (_) {
      try {
        window.location.href = fallbackSettings;
      } catch (__) {}
    }
  });

  btnClearConnLog.addEventListener("click", () => {
    writeJSON(STORAGE_KEYS.LOGS, []);
    renderLogs();
    showToast("Histórico limpo.");
  });

  // 7. CONFIGURAÇÕES & CONTA
  btnOpenSettings.addEventListener("click", () => {
    renderLogs();
    settingsModal.classList.remove("hidden");
    vibrate(12);
  });

  btnCloseSettings.addEventListener("click", () => {
    settingsModal.classList.add("hidden");
  });

  settingsModal.addEventListener("click", (e) => {
    if (e.target === settingsModal) {
      settingsModal.classList.add("hidden");
    }
  });

  function savePrefs() {
    writeJSON(STORAGE_KEYS.PREFS, {
      vibration: prefVibration.checked,
      autoPackage: prefAutoPackage.checked
    });
  }

  prefVibration.addEventListener("change", () => {
    savePrefs();
    vibrate(15);
  });

  prefAutoPackage.addEventListener("change", savePrefs);

  btnClearLocalData.addEventListener("click", () => {
    localStorage.removeItem(STORAGE_KEYS.FEATURES);
    localStorage.removeItem(STORAGE_KEYS.PACKAGE);
    localStorage.removeItem(STORAGE_KEYS.CONN);
    localStorage.removeItem(STORAGE_KEYS.LOGS);

    featureToggles.forEach((t) => {
      t.checked = false;
      updateFeatureRowVisual(t);
    });
    updateModulesCounter();
    targetPackageInput.value = "com.dts.freefireth";
    connIpInput.value = "";
    connPortInput.value = "";
    connPairingInput.value = "";
    injectFeedback.textContent = "";
    injectProgressWrap.classList.add("hidden");
    renderLogs();
    vibrate(30);
    showToast("Dados locais redefinidos.");
  });

  btnLogout.addEventListener("click", () => {
    localStorage.removeItem(STORAGE_KEYS.LICENSE);
    settingsModal.classList.add("hidden");
    mainApp.classList.add("hidden");
    activationScreen.classList.add("active");
    vibrate(25);
    showToast("Sessão encerrada.");
  });

  // Restaurar estado salvo
  function restoreAllState() {
    const savedFeatures = readJSON(STORAGE_KEYS.FEATURES, {});
    featureToggles.forEach((t) => {
      t.checked = Boolean(savedFeatures[t.id]);
      updateFeatureRowVisual(t);
    });
    updateModulesCounter();

    const savedPrefs = readJSON(STORAGE_KEYS.PREFS, { vibration: true, autoPackage: true });
    prefVibration.checked = savedPrefs.vibration !== false;
    prefAutoPackage.checked = savedPrefs.autoPackage !== false;

    const savedPkg = localStorage.getItem(STORAGE_KEYS.PACKAGE);
    if (savedPkg && prefAutoPackage.checked) {
      targetPackageInput.value = savedPkg;
    }

    const savedConn = readJSON(STORAGE_KEYS.CONN, {});
    if (savedConn.ip) connIpInput.value = savedConn.ip;
    if (savedConn.port) connPortInput.value = savedConn.port;
    if (savedConn.pairing) connPairingInput.value = savedConn.pairing;

    updateNetworkIndicator();
    renderLogs();
  }

  window.addEventListener("online", updateNetworkIndicator);
  window.addEventListener("offline", updateNetworkIndicator);

  // Iniciar aplicativo
  runSplash();
})();
