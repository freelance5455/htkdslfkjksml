const lessons=[
{id:1,title:"أساسيات الشبكات",icon:"🌐",text:`<h3>الدرس 1: أساسيات الشبكات</h3>
<p>الشبكة هي مجموعة أجهزة تتبادل البيانات وفق قواعد وبروتوكولات محددة. فهم الشبكات هو الأساس لفهم الأمن السيبراني.</p>
<h4>1. عنوان IP</h4><p>يُستخدم عنوان IP للتعرّف على جهاز أو واجهة شبكة داخل نطاق معين. يوجد IPv4 وIPv6. في المختبرات التعليمية نستخدم عناوين خاصة أو وهمية بدل اختبار أجهزة حقيقية.</p>
<h4>2. TCP وUDP</h4><p>TCP يركز على موثوقية نقل البيانات وترتيبها، بينما UDP أبسط وأسرع ولا يضمن التسليم بنفس الطريقة.</p>
<h4>3. DNS</h4><p>DNS يحول أسماء النطاقات إلى عناوين IP، مثل تحويل اسم موقع إلى العنوان الذي يحتاجه جهازك للاتصال.</p>
<div class="safe-note">🛡️ تمرين آمن: ارسم على ورقة المسار: جهازك → الراوتر → DNS → الخادم، وحدد وظيفة كل جزء.</div>`},
{id:2,title:"Linux للمبتدئين",icon:"🐧",text:`<h3>الدرس 2: Linux للمبتدئين</h3>
<p>Linux نظام مهم في الأمن السيبراني والخوادم. تعلم الطرفية يساعدك على فهم الملفات والعمليات والصلاحيات.</p>
<h4>أوامر أساسية</h4><pre>pwd      # معرفة المجلد الحالي
ls       # عرض الملفات
cd       # الانتقال بين المجلدات
mkdir    # إنشاء مجلد
cat      # قراءة ملف نصي</pre>
<h4>الصلاحيات</h4><p>الملفات في Linux لها صلاحيات للمالك والمجموعة والآخرين. فهم الصلاحيات يساعدك على منع الوصول غير المقصود إلى الملفات.</p>
<div class="safe-note">🛡️ تمرين آمن: أنشئ مجلدًا تجريبيًا على جهازك وتدرب على التنقل داخله دون تعديل ملفات النظام.</div>`},
{id:3,title:"Python للأمن السيبراني",icon:"🐍",text:`<h3>الدرس 3: Python للأمن السيبراني</h3>
<p>Python لغة مناسبة لأتمتة مهام التحليل والدفاع، مثل معالجة السجلات وفحص البيانات.</p>
<h4>المتغيرات والدوال</h4><pre>name = "Ahmed"

def greet(user):
    return "Welcome " + user

print(greet(name))</pre>
<h4>مثال دفاعي: فحص سجل</h4><pre>log = "LOGIN failed user=unknown"
if "failed" in log:
    print("مراجعة محاولة الدخول")</pre>
<p>الفكرة هي تحويل البيانات الخام إلى معلومات تساعد المدافع على اكتشاف النشاط غير المعتاد.</p>
<div class="safe-note">🛡️ تمرين آمن: عدّل المثال ليبحث عن كلمة "warning" داخل نص تجريبي.</div>`},
{id:4,title:"التشفير والتجزئة",icon:"🔐",text:`<h3>الدرس 4: التشفير والتجزئة</h3>
<p>التشفير يحول البيانات إلى صيغة يمكن استعادتها بالمفتاح المناسب، بينما التجزئة تنتج قيمة ثابتة الطول تستخدم للمقارنة والتحقق.</p>
<h4>مفاهيم مهمة</h4><ul><li>Encryption: حماية سرية البيانات.</li><li>Hashing: التحقق من البيانات وتخزين تمثيل غير قابل للعكس عمليًا عند استخدام خوارزمية مناسبة.</li><li>MFA: إضافة عامل تحقق آخر إلى جانب كلمة المرور.</li></ul>
<p>لا ينبغي تخزين كلمات المرور كنص صريح. الأنظمة الحديثة تستخدم خوارزميات تجزئة مخصصة لكلمات المرور مع salt.</p>
<div class="safe-note">🛡️ تمرين آمن: اشرح لنفسك الفرق بين "تشفير ملف" و"تجزئة كلمة مرور" في جملتين.</div>`},
{id:5,title:"أمن تطبيقات الويب",icon:"🌐",text:`<h3>الدرس 5: أمن تطبيقات الويب</h3>
<p>تطبيقات الويب تتعامل مع مدخلات المستخدم، لذلك يجب اعتبار المدخلات غير موثوقة حتى يتم التحقق منها ومعالجتها بأمان.</p>
<h4>SQL Injection</h4><p>يحدث عندما تُبنى استعلامات قاعدة البيانات بطريقة تسمح للمدخلات بتغيير معنى الاستعلام. الحماية تشمل parameterized queries والتحقق المناسب من المدخلات.</p>
<h4>XSS</h4><p>ينتج عندما يستطيع محتوى غير موثوق الوصول إلى صفحة بطريقة تسمح بتنفيذه في سياق المستخدم. من وسائل الحماية output encoding وسياسات CSP المناسبة.</p>
<div class="safe-note">🛡️ تمرين آمن: افتح مختبرًا محليًا مصممًا للتعلم فقط، وحدد أين يجب أن تتم عملية التحقق من المدخلات.</div>`},
{id:6,title:"تحليل السجلات",icon:"📊",text:`<h3>الدرس 6: تحليل السجلات واكتشاف النشاط المشبوه</h3>
<p>السجلات تسجل أحداثًا مثل تسجيل الدخول والأخطاء والطلبات. تحليلها يساعد فريق الدفاع على اكتشاف الأنماط غير المعتادة.</p>
<h4>مثال</h4><pre>10:01 LOGIN success user=ahmed
10:02 LOGIN failed user=unknown
10:02 LOGIN failed user=unknown
10:03 LOGIN failed user=unknown</pre>
<p>تكرار الفشل خلال فترة قصيرة قد يكون سببًا للمراجعة. في نظام حقيقي يمكن استخدام rate limiting والمصادقة متعددة العوامل والتنبيهات.</p>
<div class="safe-note">🛡️ تمرين آمن: عدّ عدد محاولات الفشل في السجل أعلاه وحدد الحدث الذي يستحق التحقيق.</div>`},
{id:7,title:"الاختبار الأخلاقي وCTF",icon:"🎯",text:`<h3>الدرس 7: الاختبار الأخلاقي وCTF</h3>
<p>الاختبار الأخلاقي يعني العمل ضمن نطاق واضح وبإذن. قبل أي اختبار يجب معرفة الأنظمة المسموح بها، والوقت، ونوع الاختبارات، وكيفية الإبلاغ عن النتائج.</p>
<h4>قواعد أساسية</h4><ul><li>اختبر أنظمة تملكها أو لديك إذن صريح لاختبارها.</li><li>لا تحاول الوصول إلى حسابات أو أجهزة الآخرين.</li><li>احتفظ بنطاق الاختبار والتوثيق.</li><li>استخدم CTF والمختبرات التعليمية كبيئة آمنة للتدريب.</li></ul>
<div class="safe-note">🛡️ مشروع التخرج: أنشئ مختبرًا محليًا صغيرًا يحتوي على سجلات وهمية وثلاثة أخطاء دفاعية، ثم اكتب تقريرًا يوضح المشكلة والحل دون مهاجمة أي نظام حقيقي.</div>`}
];

document.getElementById("lessons").innerHTML=lessons.map(x=>`
<button type="button" class="lesson-btn" data-id="${x.id}">
<span class="lesson-icon">${x.icon}</span><span><b>الدرس ${x.id}: ${x.title}</b><small>اضغط لفتح الدرس الكامل</small></span><span>›</span>
</button>`).join("");

document.querySelectorAll(".lesson-btn").forEach(btn=>btn.addEventListener("click",()=>{
 const lesson=lessons.find(x=>x.id===Number(btn.dataset.id));
 document.querySelectorAll(".lesson-btn").forEach(x=>x.classList.remove("selected"));
 btn.classList.add("selected");
 const viewer=document.getElementById("lessonViewer");
 viewer.innerHTML=`<div class="terminal-title">root@joker:~$ lesson_${lesson.id}</div>${lesson.text}
 <div class="lesson-actions"><button type="button" class="backTop">↑ العودة لقائمة الدروس</button></div>`;
 viewer.scrollIntoView({behavior:"smooth",block:"start"});
 viewer.querySelector(".backTop").addEventListener("click",()=>document.getElementById("lessons").scrollIntoView({behavior:"smooth"}));
}));

document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>{document.querySelectorAll(".tab").forEach(x=>x.classList.remove("active"));document.querySelectorAll(".page").forEach(x=>x.classList.remove("active"));b.classList.add("active");document.getElementById(b.dataset.page).classList.add("active")});
document.getElementById("run").onclick=()=>{let c=document.getElementById("code").value;let out=[];let m=c.match(/print\(["'](.*?)["']\)/g)||[];m.forEach(x=>out.push(x.replace(/^print\(["']|["']\)$/g,"")));document.getElementById("output").textContent=out.length?out.join("\n"):"تم تحليل المثال. شغّل print('نص') لرؤية ناتج تدريبي.";};
document.getElementById("clear").onclick=()=>document.getElementById("output").textContent="";
const qs=[["ما أفضل ممارسة لكلمة المرور؟",["استخدام كلمة طويلة وفريدة","مشاركة كلمة المرور","استخدام 123456"],0],["ما وظيفة MFA؟",["زيادة سرعة الإنترنت","إضافة عامل تحقق إضافي","حذف الحساب"],1],["ما المقصود بـ XSS؟",["نوع قاعدة بيانات","ثغرة في تطبيقات الويب تتعلق بإدخال محتوى قابل للتنفيذ","بروتوكول بريد"],1],["ما الحماية الشائعة من SQL Injection؟",["Parameterized Queries","تعطيل لوحة المفاتيح","زيادة سطوع الشاشة"],0],["ماذا تفعل قبل اختبار نظام ليس ملكك؟",["تبدأ مباشرة","تحصل على إذن ونطاق واضح","تخفي هويتك"],1],["ما فائدة تحليل السجلات؟",["اكتشاف نشاط غير معتاد","تغيير خلفية الهاتف","زيادة مساحة التخزين"],0],["أين يجب تنفيذ تمارين الاختراق التعليمية؟",["على أجهزة عشوائية","على مختبر تملكه أو لديك تصريح لاختباره","على حسابات الآخرين"],1]];
let qi=0,score=0,answered=false;
function renderQ(){const q=qs[qi];document.getElementById("quiz").innerHTML=`<div class="question"><b>اختبار ${qi+1} من 7</b><h3>${q[0]}</h3>${q[1].map((o,i)=>`<button class="option" data-i="${i}">${o}</button>`).join("")}</div>`;answered=false;document.querySelectorAll(".option").forEach(b=>b.onclick=()=>{if(answered)return;answered=true;let i=+b.dataset.i;if(i===q[2]){score++;b.classList.add("correct")}else{b.classList.add("wrong");document.querySelectorAll(".option")[q[2]].classList.add("correct")}document.getElementById("score").textContent=`النتيجة الحالية: ${score}/${qi+1}`;});}
document.getElementById("next").onclick=()=>{if(!answered)return;if(qi<6){qi++;renderQ()}else{document.getElementById("score").textContent=`انتهت الاختبارات. نتيجتك: ${score}/7. ${score>=5?"يمكنك إنشاء شهادة إتمام تعليمية.":"أعد المحاولة بعد مراجعة الدروس."}`;}};renderQ();
function escapeHtml(v){return v.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function roundedRect(ctx,x,y,w,h,r){ctx.beginPath();ctx.moveTo(x+r,y);ctx.arcTo(x+w,y,x+w,y+h,r);ctx.arcTo(x+w,y+h,x,y+h,r);ctx.arcTo(x,y+h,x,y,r);ctx.arcTo(x,y,x+w,y,r);ctx.closePath();}
function drawGlowText(ctx,text,x,y,size){ctx.save();ctx.textAlign='center';ctx.font=`700 ${size}px Arial,sans-serif`;ctx.shadowColor='#35ff7a';ctx.shadowBlur=18;ctx.fillStyle='#35ff7a';ctx.fillText(text,x,y);ctx.shadowBlur=0;ctx.fillStyle='#d9ffe7';ctx.fillText(text,x,y);ctx.restore();}
function makeCertificatePNG(name,finalScore){
 const W=1600,H=1050,canvas=document.createElement('canvas');canvas.width=W;canvas.height=H;const ctx=canvas.getContext('2d');
 const bg=ctx.createLinearGradient(0,0,W,H);bg.addColorStop(0,'#020806');bg.addColorStop(.5,'#06170e');bg.addColorStop(1,'#010503');ctx.fillStyle=bg;ctx.fillRect(0,0,W,H);
 ctx.strokeStyle='#35ff7a';ctx.lineWidth=4;roundedRect(ctx,28,28,W-56,H-56,26);ctx.stroke();ctx.lineWidth=1;ctx.globalAlpha=.35;roundedRect(ctx,48,48,W-96,H-96,18);ctx.stroke();ctx.globalAlpha=1;
 ctx.strokeStyle='#35ff7a';ctx.globalAlpha=.25;ctx.lineWidth=2;for(let i=0;i<13;i++){let y=90+i*68;ctx.beginPath();ctx.moveTo(65,y);ctx.lineTo(210,y);ctx.lineTo(240,y-22);ctx.lineTo(360,y-22);ctx.stroke();ctx.beginPath();ctx.arc(65,y,5,0,Math.PI*2);ctx.stroke();}ctx.globalAlpha=1;
 drawGlowText(ctx,'☠ CYBER EMPIRE ACADEMY ☠',W/2,115,44);ctx.fillStyle='#b8ffd0';ctx.font='700 30px Arial,sans-serif';ctx.textAlign='center';ctx.fillText('أكاديمية الإمبراطورية السيبرانية',W/2,160);ctx.fillStyle='#8dffa9';ctx.font='700 24px Arial,sans-serif';ctx.fillText('HACK • LEARN • PROTECT • THE FUTURE',W/2,198);
 roundedRect(ctx,220,245,W-440,560,24);ctx.fillStyle='rgba(2,12,7,.88)';ctx.fill();ctx.strokeStyle='#35ff7a';ctx.lineWidth=3;ctx.stroke();drawGlowText(ctx,'شهادة إتمام الدورة',W/2,325,52);ctx.fillStyle='#caffd9';ctx.font='700 25px Arial,sans-serif';ctx.fillText('CERTIFICATE OF COMPLETION',W/2,365);ctx.fillStyle='#9effb8';ctx.font='700 26px Arial,sans-serif';ctx.fillText('تشهد أكاديمية الإمبراطورية السيبرانية بأن',W/2,425);drawGlowText(ctx,name,W/2,510,62);ctx.fillStyle='#e4ffeb';ctx.font='700 31px Arial,sans-serif';ctx.fillText('قد أتم بنجاح مسار الأمن السيبراني الأخلاقي',W/2,565);ctx.fillStyle='#9effb8';ctx.font='700 25px Arial,sans-serif';ctx.fillText(`إكمال 7 دروس واجتياز الاختبارات — النتيجة ${finalScore}/7`,W/2,615);ctx.fillStyle='#d4ffe0';ctx.font='22px Arial,sans-serif';ctx.fillText('المهارات: أساسيات الشبكات • Python • Linux • التشفير • أمن الويب • تحليل السجلات • CTF',W/2,665);ctx.strokeStyle='#35ff7a';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(420,715);ctx.lineTo(1180,715);ctx.stroke();ctx.fillStyle='#8dffa9';ctx.font='700 21px Arial,sans-serif';ctx.fillText('شهادة تعليمية محلية — للتدريب والتعلم فقط',W/2,755);
 ctx.beginPath();ctx.arc(135,875,70,0,Math.PI*2);ctx.strokeStyle='#35ff7a';ctx.lineWidth=4;ctx.stroke();drawGlowText(ctx,'CE',135,888,40);ctx.beginPath();ctx.arc(W-135,875,70,0,Math.PI*2);ctx.stroke();drawGlowText(ctx,'✓',W-135,892,48);ctx.fillStyle='#aaffbf';ctx.font='18px Arial,sans-serif';ctx.fillText('Cyber Empire',135,920);ctx.fillText('Ethical Training',W-135,920);ctx.fillStyle='#8dffa9';ctx.font='20px Arial,sans-serif';ctx.fillText('التاريخ: '+new Date().toLocaleDateString('ar-EG'),W/2,875);ctx.fillText('أحمد ملك الظلام الجوكر',W/2,910);
 return canvas.toDataURL('image/png');
}
function dataUrlToBlob(dataUrl){const parts=dataUrl.split(',');const mime=(parts[0].match(/:(.*?);/)||[])[1]||'image/png';const binary=atob(parts[1]);const bytes=new Uint8Array(binary.length);for(let i=0;i<binary.length;i++)bytes[i]=binary.charCodeAt(i);return new Blob([bytes],{type:mime});}
function downloadCertificate(blob,name){const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;a.style.display='none';document.body.appendChild(a);a.click();setTimeout(()=>{a.remove();URL.revokeObjectURL(url)},1500);return url;}
document.getElementById("makeCert").onclick=()=>{if(score<5){alert("تحتاج إلى 5/7 على الأقل.");return}const raw=document.getElementById("studentName").value.trim()||"أحمد ملك الظلام الجوكر";const dataUrl=makeCertificatePNG(raw,score);const blob=dataUrlToBlob(dataUrl);const objectUrl=URL.createObjectURL(blob);document.getElementById("certBox").innerHTML=`<div class="cert-preview"><img alt="شهادة إتمام تعليمية" src="${objectUrl}"></div><div class="cert-actions"><button class="download-cert" id="downloadCert">⬇ تنزيل الشهادة PNG</button><button class="download-cert secondary" id="openCert">↗ فتح الصورة</button></div><p class="cert-note">إذا لم يبدأ التنزيل تلقائيًا، اضغط «فتح الصورة» ثم اختر «تنزيل الصورة» أو اضغط مطولًا عليها.</p>`;document.getElementById('downloadCert').onclick=()=>downloadCertificate(blob,'Cyber_Empire_Certificate.png');document.getElementById('openCert').onclick=()=>{const w=window.open(objectUrl,'_blank');if(!w)location.href=objectUrl;};};
