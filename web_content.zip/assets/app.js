const $=id=>document.getElementById(id);
const state={messages:JSON.parse(localStorage.getItem('rahvessa_messages')||'[]'),history:JSON.parse(localStorage.getItem('rahvessa_history')||'[]'),projects:JSON.parse(localStorage.getItem('rahvessa_projects')||'[]'),apiKey:localStorage.getItem('rahvessa_key')||'',model:localStorage.getItem('rahvessa_model')||'gpt-4o-mini',attachment:null};

function save(){localStorage.setItem('rahvessa_messages',JSON.stringify(state.messages));localStorage.setItem('rahvessa_history',JSON.stringify(state.history));localStorage.setItem('rahvessa_projects',JSON.stringify(state.projects));}
function showView(id){document.querySelectorAll('.view').forEach(v=>v.classList.remove('active'));$(id).classList.add('active'); if(id==='chatView')renderMessages();if(id==='historyView')renderHistory();if(id==='projectsView')renderProjects();}
function addMessage(role,content){state.messages.push({role,content,at:Date.now()});save();renderMessages();}
function renderMessages(){const box=$('messages');box.innerHTML='';for(const m of state.messages){const d=document.createElement('div');d.className='bubble '+(m.role==='user'?'user':'assistant');d.textContent=m.content;box.appendChild(d)}box.scrollTop=box.scrollHeight;}
function renderHistory(){const box=$('history');box.innerHTML=state.history.length?'':'<p class="muted">No saved conversations yet.</p>';state.history.slice().reverse().forEach(h=>{const d=document.createElement('div');d.innerHTML='<b>'+escapeHtml(h.title)+'</b><br><span class="muted">'+new Date(h.at).toLocaleString()+'</span>';box.appendChild(d)});}
function renderProjects(){const box=$('projects');box.innerHTML='';state.projects.slice().reverse().forEach((p,i)=>{const d=document.createElement('div');d.innerHTML='<b>'+escapeHtml(p.name)+'</b><p>'+escapeHtml(p.note)+'</p>';box.appendChild(d)});if(!state.projects.length)box.innerHTML='<p class="muted">No projects yet.</p>';}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}

async function send(){
 const text=$('prompt').value.trim(); if(!text&&!state.attachment)return;
 if(!state.apiKey){openSettings();return}
 let userContent=text;
 if(state.attachment) userContent+=(text?'\\n\\n':'')+'[Attached file: '+state.attachment.name+']';
 addMessage('user',userContent); $('prompt').value=''; $('attachmentName').textContent=''; $('typing').classList.remove('hidden');
 try{
   const messages=[{role:'system',content:'You are Rahvessa AI, a helpful assistant.'},...state.messages.filter(m=>m.role==='user'||m.role==='assistant').map(m=>({role:m.role,content:m.content}))];
   const r=await fetch('https://api.openai.com/v1/chat/completions',{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+state.apiKey},body:JSON.stringify({model:state.model,messages,temperature:.7,max_tokens:1024})});
   const data=await r.json(); if(!r.ok)throw new Error(data.error?.message||('API error '+r.status));
   const answer=data.choices?.[0]?.message?.content||'No response received.';
   addMessage('assistant',answer);
   state.history.push({title:text||'Image/file message',at:Date.now()});save();
 }catch(e){addMessage('assistant','Error: '+e.message)}
 finally{$('typing').classList.add('hidden');state.attachment=null;}
}

function openSettings(){$('apiKey').value=state.apiKey;$('model').value=state.model;$('settingsModal').classList.remove('hidden')}
$('settingsBtn').onclick=openSettings;$('closeSettings').onclick=()=>$('settingsModal').classList.add('hidden');
$('saveSettings').onclick=()=>{state.apiKey=$('apiKey').value.trim();state.model=$('model').value;localStorage.setItem('rahvessa_key',state.apiKey);localStorage.setItem('rahvessa_model',state.model);$('settingsModal').classList.add('hidden')};
$('startChat').onclick=()=>showView('chatView');$('sendBtn').onclick=send;$('prompt').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();send()}});
$('attachBtn').onclick=()=>$('fileInput').click();
$('fileInput').onchange=e=>{const f=e.target.files[0];if(f){state.attachment=f;$('attachmentName').textContent='Attached: '+f.name}};

document.querySelectorAll('.bottom button').forEach(b=>b.onclick=()=>showView(b.dataset.view));
document.querySelectorAll('[data-prompt]').forEach(b=>b.onclick=()=>{$('prompt').value=b.dataset.prompt;showView('chatView');$('prompt').focus()});
$('clearHistory').onclick=()=>{state.history=[];save();renderHistory()};
$('saveProject').onclick=()=>{const n=$('projectName').value.trim(),t=$('projectNote').value.trim();if(!n)return;state.projects.push({name:n,note:t,at:Date.now()});$('projectName').value='';$('projectNote').value='';save();renderProjects()};
$('backBtn').onclick=()=>showView('homeView');

renderMessages();renderHistory();renderProjects();
