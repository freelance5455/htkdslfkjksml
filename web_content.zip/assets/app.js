const TOPICS=["Hematology","Clinical Biochemistry","Microbiology","Histopathology / Pathology","Anatomy & Physiology","Laboratory Quality & Safety"];
const BANK=[
["Hematology","Which anticoagulant is commonly used for a CBC?","EDTA","Sodium fluoride","Sodium citrate","Heparin","A"],
["Hematology","The normal pH of arterial blood is approximately:","6.8","7.4","8.5","5.5","B"],
["Clinical Biochemistry","SGPT is also known as:","ALT","AST","ALP","GGT","A"],
["Clinical Biochemistry","Bilirubin is mainly produced from breakdown of:","Hemoglobin","Glucose","Albumin","Urea","A"],
["Microbiology","Gram-positive bacteria retain which primary stain?","Crystal violet","Safranin","Carbol fuchsin","Methylene blue","A"],
["Microbiology","Autoclaving uses:","Dry heat","Steam under pressure","UV only","Filtration only","B"],
["Histopathology / Pathology","The routine fixative for histopathology is:","10% neutral buffered formalin","Distilled water","Normal saline only","Ethanol only","A"],
["Anatomy & Physiology","The functional unit of the kidney is the:","Nephron","Neuron","Alveolus","Osteon","A"],
["Laboratory Quality & Safety","A PPE item used to protect the eyes is:","Goggles","Shoe polish","Notebook","Tourniquet","A"],
["Laboratory Quality & Safety","A biological spill should be managed according to:","Laboratory SOP","Personal preference","No procedure","Social media advice","A"]
];

let questions=[];
TOPICS.forEach((topic,ti)=>{
  for(let i=0;i<104;i++){
    const b=BANK.find(x=>x[0]===topic)||BANK[ti%BANK.length];
    questions.push({id:topic.slice(0,3).toUpperCase()+"-"+(i+1),topic:topic,q:b[1],opts:[b[2],b[3],b[4],b[5]],ans:b[6],ex:"Review the relevant DMLT textbook/SOP for the full explanation.",difficulty:["Easy","Medium","Hard"][i%3],pyq:false});
  }
});
let state=JSON.parse(localStorage.getItem("pgimerState")||'{"answered":0,"correct":0,"tests":0,"streak":0,"bookmarks":[],"wrong":[],"name":"","errorLog":""}');
let session=[],qi=0,score=0,selected=null;

function save(){localStorage.setItem("pgimerState",JSON.stringify(state));renderStats();}
function show(id){document.querySelectorAll(".screen").forEach(x=>x.classList.remove("active"));document.getElementById(id).classList.add("active");if(id==="progress")renderProgress();if(id==="bookmarks")renderBookmarks();if(id==="profile")name.value=state.name||""}
function renderStats(){answered.textContent=state.answered;tests.textContent=state.tests;accuracy.textContent=(state.answered?Math.round(state.correct/state.answered*100):0)+"%";streak.textContent=state.streak+" days"}
function startTest(topic,n){
 let pool=topic==="Mixed"?questions:questions.filter(q=>q.topic===topic);
 session=pool.sort(()=>Math.random()-.5).slice(0,n);qi=0;score=0;selected=null;show("quiz");renderQuestion();
}
function renderQuestion(){
 const q=session[qi];qMeta.textContent=q.topic+" • "+q.difficulty+" • "+(qi+1)+"/"+session.length;
 question.textContent=q.q;bar.style.width=((qi)/session.length*100)+"%";options.innerHTML="";
 q.opts.forEach((o,i)=>{let b=document.createElement("button");b.className="option";b.textContent=String.fromCharCode(65+i)+". "+o;b.onclick=()=>answer(i,b);options.appendChild(b)});
}
function answer(i,btn){
 if(selected!==null)return;selected=i;const q=session[qi], correct=q.ans.charCodeAt(0)-65;
 [...options.children].forEach((b,j)=>{if(j===correct)b.classList.add("good");if(j===i&&i!==correct)b.classList.add("bad")});
 state.answered++;if(i===correct){score++;state.correct++}else state.wrong.push(q.id);save();
}
function nextQuestion(){if(selected===null){alert("Select an answer first.");return}if(qi<session.length-1){qi++;selected=null;renderQuestion()}else finishTest()}
function finishTest(){if(!session.length)return;state.tests++;state.streak=Math.max(1,state.streak);save();rScore.textContent=score+"/"+session.length;rCorrect.textContent=score;rWrong.textContent=session.length-score;rAcc.textContent=Math.round(score/session.length*100)+"%";review.innerHTML=session.filter((q,i)=>{return false}).length?"":"Review wrong questions from your Progress/Error Log.";show("result");}
function searchMCQ(){const s=(search.value||"").toLowerCase().trim();if(!s){searchOut.innerHTML="";return}let r=questions.filter(q=>(q.q+" "+q.topic+" "+q.ex).toLowerCase().includes(s)).slice(0,50);searchOut.innerHTML="<p class='small'>"+r.length+" result(s)</p>"+r.map(q=>"<div class='card'><b>"+q.topic+"</b><br>"+q.q+"<br><span class='small'>Answer: "+q.opts[q.ans.charCodeAt(0)-65]+"</span></div>").join("")}
function renderProgress(){progressStats.innerHTML="<p>Questions answered: <b>"+state.answered+"</b></p><p>Correct: <b>"+state.correct+"</b></p><p>Accuracy: <b>"+(state.answered?Math.round(state.correct/state.answered*100):0)+"%</b></p><p>Tests: <b>"+state.tests+"</b></p>";weak.innerHTML=TOPICS.map(t=>"<span class='tag'>"+t+"</span>").join("");errorLog.value=state.errorLog||""}
function saveErrorLog(){state.errorLog=errorLog.value;save();alert("Saved offline.")}
function renderBookmarks(){bookmarksOut.innerHTML=state.bookmarks.length?state.bookmarks.map(id=>"<div class='card'>"+id+"</div>").join(""):"No bookmarks yet. Use the bookmark system in the full Firebase build."}
function saveName(){state.name=name.value;save();alert("Saved.")}
function toggleTheme(){document.body.classList.toggle("light");document.documentElement.style.setProperty("--bg",document.body.classList.contains("light")?"#f4f6f8":"#0d1117");document.documentElement.style.setProperty("--card",document.body.classList.contains("light")?"#fff":"#151b23");document.documentElement.style.setProperty("--text",document.body.classList.contains("light")?"#111":"#f5f7fa")}
topic.innerHTML=TOPICS.map(x=>"<option>"+x+"</option>").join("");
tags.innerHTML=TOPICS.map(x=>"<span class='tag'>"+x+"</span>").join("");
renderStats();
