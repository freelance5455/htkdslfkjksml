const APP = window.ANONYMOUX_APP;
const API = (path) => `${APP.apiBase}/${path}`;
const $ = (id) => document.getElementById(id);

let appConfig = null;
let allPrompts = [];
let selectedPromptId = null;
let selectedModel = 'lucy-2.6';
let cameraStream = null;
let peerConnection = null;
let realtimeClient = null;
let decartClient = null;
let sdkModulePromise = null;
let eventSource = null;
let remoteSessionId = null;
let lastEndedSessionId = null;
let pendingIce = [];
let flushingIce = false;
let selectedReference = null;
let currentFacingMode = 'user';
let paused = false;
let connectionStartedAt = null;
let sessionElapsed = 0;
let sessionTimer = null;
let intentionalSdkDisconnect = false;

function showToast(message, type = 'success') {
  const toast = document.createElement('div');
  toast.className = `toast ${type === 'error' ? 'error' : ''}`;
  toast.textContent = message;
  $('toastRegion').appendChild(toast);
  window.setTimeout(() => toast.remove(), 4300);
}

function setMessage(message, type = '') {
  const node = $('sessionMessage');
  node.textContent = message;
  node.classList.toggle('is-error', type === 'error');
  node.classList.toggle('is-success', type === 'success');
}

function setConnection(label, state = 'ready') {
  $('connectionText').textContent = label;
  $('connectionPill').classList.toggle('is-live', state === 'live');
  $('connectionPill').classList.toggle('is-error', state === 'error');
  $('outputFrameStatus').textContent = state === 'live' ? 'LIVE TRANSFORM' : state === 'starting' ? 'CONNECTING' : state === 'error' ? 'CONNECTION ERROR' : 'WAITING FOR SESSION';
  $('outputFrameStatus').classList.toggle('is-live', state === 'live');
}

async function requestJson(url, options = {}) {
  const headers = new Headers(options.headers || {});
  headers.set('Accept', 'application/json');
  if (options.method && options.method !== 'GET') headers.set('X-CSRF-Token', APP.csrfToken);
  if (options.body && !(options.body instanceof FormData) && !headers.has('Content-Type')) headers.set('Content-Type', 'application/json');
  const response = await fetch(url, { credentials: 'same-origin', ...options, headers });
  const raw = await response.text();
  let data;
  try { data = raw ? JSON.parse(raw) : {}; } catch { throw new Error(`Server returned an unreadable response (HTTP ${response.status}).`); }
  if (!response.ok || data.ok === false) throw new Error(data.error || `Request failed (HTTP ${response.status}).`);
  return data;
}

function postJson(url, body, options = {}) {
  return requestJson(url, { method: 'POST', body: JSON.stringify(body), ...options });
}

function hasActiveSession() {
  return Boolean(remoteSessionId || peerConnection || realtimeClient);
}

function isSdkDirect() {
  return (appConfig?.transport || 'sdk-direct') === 'sdk-direct';
}

function setBusy(isBusy) {
  const active = hasActiveSession();
  $('startBtn').disabled = isBusy || active || appConfig?.configured === false || !selectedModel;
  $('stopBtn').disabled = !active;
  $('pauseBtn').disabled = !cameraStream || !active;
  $('switchCameraBtn').disabled = !cameraStream;
  $('openCameraBtn').disabled = Boolean(cameraStream && cameraStream.getVideoTracks().some((track) => track.readyState === 'live'));
  $('openCameraBtn').textContent = $('openCameraBtn').disabled ? '✓ Camera ready' : '◎ Open camera';
  $('applyPromptBtn').disabled = !active;
}

function renderModelSelection() {
  document.querySelectorAll('.model-card').forEach((card) => {
    const isSelected = card.dataset.model === selectedModel;
    card.classList.toggle('selected', isSelected);
    card.setAttribute('aria-pressed', String(isSelected));
    const indicator = card.querySelector('.model-select-indicator');
    if (indicator) indicator.innerHTML = card.disabled ? 'Disabled by admin' : (isSelected ? 'Selected <span>✓</span>' : 'Select model <span>↗</span>');
  });
}

async function loadConfig() {
  appConfig = await requestJson(API('config.php'));
  const availableModels = (appConfig.models || []).map((model) => model.id);
  const preferredModel = appConfig.preferences?.model;
  selectedModel = availableModels.includes(preferredModel) ? preferredModel : (availableModels[0] || '');
  document.querySelectorAll('.model-choice').forEach((card) => { card.disabled = !availableModels.includes(card.dataset.model); });
  if (!selectedModel) { $('startBtn').disabled = true; setMessage('Realtime models are currently disabled by the administrator.', 'error'); }
  if (appConfig.configured !== true) {
    $('configWarning').hidden = false;
    $('startBtn').disabled = true;
    setMessage('Add your Decart API key on the server before starting a transformation.', 'error');
    setConnection('Configuration required', 'error');
  }
  renderModelSelection();
  if (appConfig.preferences?.prompt) $('promptInput').value = appConfig.preferences.prompt;
  if (typeof appConfig.preferences?.enhance_prompt === 'boolean') $('enhancePrompt').checked = appConfig.preferences.enhance_prompt;
  updateCharacterCount();
  if (appConfig.reference) renderReference(appConfig.reference);
  await refreshCameraPermission();
  // A page reload closes any prior browser-owned session so it cannot be orphaned or billed unnoticed.
  for (const stale of (appConfig.activeSessions || [])) {
    try { await postJson(API('sessions.php'), { action: 'end', session_id: stale.id }); } catch { /* the provider may have already ended it */ }
  }
}

async function saveWorkspace(changes) {
  return postJson(API('workspace.php'), changes);
}

async function selectModel(model) {
  if (!['lucy-2.5', 'lucy-2.6'].includes(model) || !(appConfig?.models || []).some((item) => item.id === model) || model === selectedModel) return;
  const wasActive = hasActiveSession();
  if (wasActive) {
    setMessage(`Switching to ${model === 'lucy-2.5' ? 'Lucy 2.5' : 'Lucy 2.6'}: ending the current session first…`);
    await stopSession({ stopCamera: false, silent: true });
  }
  selectedModel = model;
  renderModelSelection();
  try { await saveWorkspace({ model }); } catch (error) { showToast(error.message, 'error'); }
  setMessage(`Model selected: ${model === 'lucy-2.5' ? 'Lucy 2.5' : 'Lucy 2.6'}.`);
  if (wasActive) {
    try { await startTransformation({ reuseCamera: true }); }
    catch (error) { setMessage(error.message, 'error'); showToast(error.message, 'error'); }
  }
}

function updateCharacterCount() {
  $('charCount').textContent = `${$('promptInput').value.length} / 2000`;
}

function filteredPrompts() {
  const search = $('promptSearch').value.trim().toLowerCase();
  const category = $('promptCategory').value;
  return allPrompts.filter((p) => {
    const matchesCategory = category === 'all' || p.category === category;
    const matchesSearch = !search || `${p.title} ${p.description} ${p.prompt} ${p.category}`.toLowerCase().includes(search);
    return matchesCategory && matchesSearch;
  });
}

function renderPromptLibrary() {
  const items = filteredPrompts();
  $('promptCount').textContent = `${items.length} prompts`;
  const strip = $('promptStrip');
  strip.replaceChildren();
  if (!items.length) {
    const empty = document.createElement('div');
    empty.className = 'empty-state inline-empty';
    empty.textContent = 'No prompts match your search.';
    strip.appendChild(empty);
    return;
  }
  for (const item of items) {
    const card = document.createElement('button');
    card.type = 'button';
    card.className = `prompt-card${String(item.id) === String(selectedPromptId) ? ' selected' : ''}`;
    card.setAttribute('aria-pressed', String(String(item.id) === String(selectedPromptId)));
    const category = document.createElement('span'); category.className = 'prompt-category'; category.textContent = item.category;
    const title = document.createElement('strong'); title.textContent = item.title;
    const description = document.createElement('p'); description.textContent = item.description || 'Custom transformation prompt.';
    const action = document.createElement('span'); action.className = 'prompt-pick'; action.textContent = 'Use prompt  ↗';
    card.append(category, title, description, action);
    card.addEventListener('click', () => {
      selectedPromptId = item.id;
      $('promptInput').value = item.prompt;
      updateCharacterCount();
      renderPromptLibrary();
      saveWorkspace({ prompt: item.prompt }).catch((error) => showToast(error.message, 'error'));
      $('promptInput').focus();
      setMessage(`“${item.title}” inserted into the prompt editor.`);
    });
    strip.appendChild(card);
  }
}

async function loadPrompts() {
  const data = await requestJson(API('prompts.php'));
  allPrompts = data.prompts || [];
  const categories = [...new Set(allPrompts.map((p) => p.category))].sort();
  const select = $('promptCategory');
  select.replaceChildren(new Option('All categories', 'all'));
  categories.forEach((category) => select.add(new Option(category, category)));
  renderPromptLibrary();
}

function renderManagedPrompts() {
  const wrap = $('managedPrompts');
  wrap.replaceChildren();
  const customs = allPrompts.filter((p) => p.is_custom);
  const builtIns = allPrompts.filter((p) => !p.is_custom);
  if (!allPrompts.length) {
    const empty = document.createElement('div'); empty.className = 'empty-state'; empty.textContent = 'No prompts yet.'; wrap.appendChild(empty); return;
  }
  for (const prompt of [...customs, ...builtIns]) {
    const row = document.createElement('div'); row.className = 'managed-prompt';
    const info = document.createElement('div');
    const title = document.createElement('strong'); title.textContent = `${prompt.title}${prompt.is_custom ? '' : ' · Built-in'}`;
    const desc = document.createElement('p'); desc.textContent = `${prompt.category} — ${prompt.description || prompt.prompt}`;
    info.append(title, desc);
    const actions = document.createElement('div'); actions.className = 'managed-actions';
    if (prompt.is_custom) {
      const edit = document.createElement('button'); edit.type = 'button'; edit.className = 'outline-button'; edit.textContent = 'Edit'; edit.addEventListener('click', () => openPromptForm(prompt));
      const duplicate = document.createElement('button'); duplicate.type = 'button'; duplicate.className = 'outline-button'; duplicate.textContent = 'Duplicate'; duplicate.addEventListener('click', () => managePrompt('duplicate', prompt));
      const del = document.createElement('button'); del.type = 'button'; del.className = 'outline-button danger-text'; del.textContent = 'Delete'; del.addEventListener('click', () => managePrompt('delete', prompt));
      actions.append(edit, duplicate, del);
    } else {
      const duplicate = document.createElement('button'); duplicate.type = 'button'; duplicate.className = 'outline-button'; duplicate.textContent = 'Use'; duplicate.addEventListener('click', () => {
        $('promptInput').value = prompt.prompt; selectedPromptId = prompt.id; updateCharacterCount(); renderPromptLibrary(); $('promptDialog').close();
      });
      actions.append(duplicate);
    }
    row.append(info, actions); wrap.appendChild(row);
  }
}

function openPromptForm(prompt = null) {
  $('promptForm').hidden = false;
  $('editPromptId').value = prompt?.id || '';
  $('promptFormTitle').textContent = prompt ? 'Edit custom prompt' : 'Create custom prompt';
  $('customPromptTitle').value = prompt?.title || '';
  $('customPromptDescription').value = prompt?.description || '';
  $('customPromptText').value = prompt?.prompt || '';
  $('customPromptCategory').value = prompt?.category || 'Creative Effects';
  $('customPromptTitle').focus();
}

function clearPromptForm() {
  $('promptForm').reset();
  $('editPromptId').value = '';
  $('promptForm').hidden = true;
}

async function managePrompt(action, prompt) {
  if (action === 'delete' && !window.confirm(`Delete “${prompt.title}”?`)) return;
  try {
    await postJson(API('prompts.php'), {
      action, id: prompt.id,
      title: action === 'duplicate' ? `${prompt.title} Copy` : prompt.title,
      description: prompt.description,
      prompt: prompt.prompt,
      category: prompt.category,
    });
    await loadPrompts();
    renderManagedPrompts();
    showToast(action === 'delete' ? 'Prompt deleted.' : 'Prompt duplicated.');
  } catch (error) { showToast(error.message, 'error'); }
}

$('promptForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const id = $('editPromptId').value;
  const body = {
    action: id ? 'update' : 'create',
    id: id ? Number(id) : undefined,
    title: $('customPromptTitle').value.trim(),
    description: $('customPromptDescription').value.trim(),
    prompt: $('customPromptText').value.trim(),
    category: $('customPromptCategory').value,
  };
  try {
    await postJson(API('prompts.php'), body);
    clearPromptForm();
    await loadPrompts();
    renderManagedPrompts();
    showToast(id ? 'Custom prompt updated.' : 'Custom prompt saved.');
  } catch (error) { showToast(error.message, 'error'); }
});

function renderReference(reference) {
  selectedReference = reference || null;
  const hasReference = Boolean(reference);
  $('referencePlaceholder').hidden = hasReference;
  $('referencePreview').hidden = !hasReference;
  $('referenceMeta').hidden = !hasReference;
  $('removeReferenceBtn').hidden = !hasReference;
  if (!hasReference) {
    $('referencePreview').removeAttribute('src');
    $('referenceFileName').textContent = '';
    $('referenceDimensions').textContent = '';
    $('referenceStatus').textContent = 'JPEG, PNG or WebP · Recommended 512 × 512 or larger · Up to 5 MB';
    return;
  }
  $('referencePreview').src = `${API('reference.php')}?action=preview&id=${encodeURIComponent(reference.id)}&v=${Date.now()}`;
  $('referenceFileName').textContent = reference.original_name;
  $('referenceDimensions').textContent = `${reference.width} × ${reference.height} · ${(Number(reference.file_size) / 1024 / 1024).toFixed(2)} MB`;
  $('referenceStatus').textContent = 'Stored privately. It will be sent to Decart when the session starts.';
}

async function optimizeReference(file) {
  if (!file || !/^image\/(jpeg|png|webp)$/.test(file.type)) return file;
  let bitmap;
  try { bitmap = await createImageBitmap(file); } catch { return file; }
  const maxSide = Math.max(bitmap.width, bitmap.height);
  if (file.size <= 3 * 1024 * 1024 && maxSide <= 3000) { bitmap.close?.(); return file; }
  const scale = Math.min(1, 2560 / maxSide);
  const canvas = document.createElement('canvas');
  canvas.width = Math.max(1, Math.round(bitmap.width * scale));
  canvas.height = Math.max(1, Math.round(bitmap.height * scale));
  const context = canvas.getContext('2d', { alpha: true });
  context.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  bitmap.close?.();
  const outputType = file.type === 'image/jpeg' ? 'image/jpeg' : 'image/webp';
  const blob = await new Promise((resolve) => canvas.toBlob(resolve, outputType, 0.88));
  if (!blob || blob.size >= file.size) return file;
  const ext = outputType === 'image/jpeg' ? 'jpg' : 'webp';
  const base = file.name.replace(/\.[^.]+$/, '');
  return new File([blob], `${base}-optimized.${ext}`, { type: outputType, lastModified: Date.now() });
}

async function uploadReference(file) {
  if (!file) return;
  $('referenceStatus').textContent = 'Checking and optimizing image…';
  try { file = await optimizeReference(file); }
  catch { /* upload original when browser encoding is unavailable */ }
  if (file.size > 5 * 1024 * 1024) { $('referenceStatus').textContent = 'This image is larger than 5 MB. Choose a smaller file.'; showToast('Reference image exceeds the 5 MB limit.', 'error'); return; }
  const form = new FormData();
  form.append('reference_image', file, file.name);
  $('referenceStatus').textContent = 'Uploading image to workspace…';
  $('uploadProgressTrack').hidden = false;
  $('uploadProgress').style.width = '0%';
  const xhr = new XMLHttpRequest();
  xhr.open('POST', `${API('reference.php')}?action=upload`);
  xhr.setRequestHeader('X-CSRF-Token', APP.csrfToken);
  xhr.withCredentials = true;
  xhr.upload.addEventListener('progress', (event) => {
    if (event.lengthComputable) $('uploadProgress').style.width = `${Math.round((event.loaded / event.total) * 100)}%`;
  });
  xhr.addEventListener('load', async () => {
    $('uploadProgressTrack').hidden = true;
    let data;
    try { data = JSON.parse(xhr.responseText); } catch { data = null; }
    if (xhr.status < 200 || xhr.status >= 300 || !data?.ok) {
      const message = data?.error || `Image upload failed (HTTP ${xhr.status}).`;
      $('referenceStatus').textContent = message;
      showToast(message, 'error'); return;
    }
    renderReference(data.reference);
    if (data.warning) showToast(data.warning, 'error');
    else showToast('Reference image uploaded.');
    if (realtimeClient && isSdkDirect()) {
      try {
        const image = await loadReferenceImage(data.reference);
        const nextState = { image, enhance: $('enhancePrompt').checked };
        const prompt = $('promptInput').value.trim();
        if (prompt) nextState.prompt = prompt;
        await realtimeClient.set(nextState);
        setMessage('Reference image uploaded and applied to the active Decart session.', 'success');
      } catch (error) { setMessage(`Image was stored, but Decart did not accept the update: ${error.message}`, 'error'); showToast(error.message, 'error'); }
    } else if (remoteSessionId) {
      try {
        await postJson(API('sessions.php'), { action: 'image', session_id: remoteSessionId, reference_id: data.reference.id, prompt: $('promptInput').value.trim(), enhance_prompt: $('enhancePrompt').checked });
        setMessage('Reference image uploaded and sent to the active Decart session.', 'success');
      } catch (error) { setMessage(error.message, 'error'); showToast(error.message, 'error'); }
    }
  });
  xhr.addEventListener('error', () => { $('uploadProgressTrack').hidden = true; $('referenceStatus').textContent = 'Network error while uploading.'; showToast('Network error while uploading the reference image.', 'error'); });
  xhr.send(form);
}

async function removeReference() {
  const wasActive = hasActiveSession();
  try {
    if (realtimeClient && isSdkDirect()) {
      const nextState = { image: null, enhance: $('enhancePrompt').checked };
      const prompt = $('promptInput').value.trim();
      if (prompt) nextState.prompt = prompt;
      await realtimeClient.set(nextState);
    } else if (wasActive) {
      await stopSession({ stopCamera: false, silent: true });
    }
    await requestJson(`${API('reference.php')}?action=delete`, { method: 'POST', body: JSON.stringify({}) });
    renderReference(null);
    showToast('Reference image removed from the workspace and active session.');
    if (wasActive && isSdkDirect()) setMessage('Reference image cleared in the active Decart session.', 'success');
    if (wasActive && !isSdkDirect()) await startTransformation({ reuseCamera: true });
  } catch (error) { setMessage(error.message, 'error'); showToast(error.message, 'error'); }
}

async function refreshCameraPermission() {
  const el = $('cameraPermission');
  let label = 'Camera permission: available';
  el.classList.remove('permission-granted', 'permission-denied');
  try {
    if (navigator.permissions?.query) {
      const permission = await navigator.permissions.query({ name: 'camera' });
      label = `Camera permission: ${permission.state}`;
      el.classList.toggle('permission-granted', permission.state === 'granted');
      el.classList.toggle('permission-denied', permission.state === 'denied');
      permission.addEventListener?.('change', () => refreshCameraPermission());
    }
  } catch { label = 'Camera permission: requested on start'; }
  if (!navigator.mediaDevices?.getUserMedia) label = 'Camera unavailable — use HTTPS';
  el.querySelector('span:last-child').textContent = label;
}

async function ensureCamera(modelDefinition = null) {
  if (cameraStream && cameraStream.getVideoTracks().some((track) => track.readyState === 'live')) return cameraStream;
  if (!window.isSecureContext) throw new Error('Camera access requires HTTPS. Open this workspace using a valid SSL certificate.');
  if (!navigator.mediaDevices?.getUserMedia) throw new Error('This browser cannot access the camera. Use a recent Android Chrome or iOS Safari browser over HTTPS.');
  try {
    cameraStream = await navigator.mediaDevices.getUserMedia({
      audio: false,
      video: {
        width: modelDefinition?.width || { ideal: 1280 },
        height: modelDefinition?.height || { ideal: 720 },
        frameRate: modelDefinition?.fps || { ideal: 30, max: 30 },
        facingMode: { ideal: currentFacingMode },
      },
    });
  } catch (error) {
    if (error.name === 'NotAllowedError' || error.name === 'PermissionDeniedError') throw new Error('Camera permission was denied. Allow camera access in your browser settings and reload this page.');
    if (error.name === 'NotFoundError') throw new Error('No camera was found on this device.');
    if (error.name === 'NotReadableError') throw new Error('The camera is already in use by another app. Close it and try again.');
    throw new Error(error.message || 'Could not open the camera.');
  }
  $('inputVideo').srcObject = cameraStream;
  $('inputEmpty').hidden = true;
  $('inputLiveLabel').hidden = false;
  $('inputFrameStatus').textContent = 'CAMERA READY';
  $('inputFrameStatus').classList.add('is-live');
  $('openCameraBtn').disabled = true;
  $('openCameraBtn').textContent = '✓ Camera ready';
  $('switchCameraBtn').disabled = false;
  await refreshCameraPermission();
  return cameraStream;
}

function setInputPreview() {
  if (cameraStream) {
    $('inputVideo').srcObject = cameraStream;
    $('inputEmpty').hidden = true;
    $('inputLiveLabel').hidden = false;
    $('inputFrameStatus').textContent = 'CAMERA READY';
    $('inputFrameStatus').classList.add('is-live');
  } else {
    $('inputVideo').srcObject = null;
    $('inputEmpty').hidden = false;
    $('inputLiveLabel').hidden = true;
    $('inputFrameStatus').textContent = 'CAMERA OFF';
    $('inputFrameStatus').classList.remove('is-live');
  }
}

function enqueueIce(candidate) {
  pendingIce.push(candidate ? {
    candidate: candidate.candidate,
    sdpMLineIndex: candidate.sdpMLineIndex,
    sdpMid: candidate.sdpMid,
  } : null);
  flushIceQueue().catch((error) => {
    setMessage(`ICE signaling issue: ${error.message}`, 'error');
  });
}

async function flushIceQueue() {
  if (flushingIce || !remoteSessionId) return;
  flushingIce = true;
  try {
    while (pendingIce.length && remoteSessionId) {
      const candidate = pendingIce.shift();
      const result = await postJson(API('sessions.php'), { action: 'ice', session_id: remoteSessionId, candidates: [candidate] });
      if (result.etag) appConfig.lastEtag = result.etag;
    }
  } finally { flushingIce = false; }
}

function openSessionEvents(events) {
  if (!events?.url || !events?.event_token) throw new Error('Decart did not return its realtime event connection details.');
  const separator = events.url.includes('?') ? '&' : '?';
  eventSource = new EventSource(`${events.url}${separator}event_token=${encodeURIComponent(events.event_token)}`);
  eventSource.addEventListener('generation_started', () => {
    setConnection('Live transformation', 'live');
    setMessage('Decart is transforming your live camera feed.', 'success');
  });
  eventSource.addEventListener('generation_tick', (event) => {
    try { sessionElapsed = Number(JSON.parse(event.data).seconds || sessionElapsed); } catch { /* ignore malformed telemetry */ }
  });
  eventSource.addEventListener('ice-candidate', async (event) => {
    if (!peerConnection) return;
    try {
      const data = JSON.parse(event.data);
      await peerConnection.addIceCandidate(data.candidate === null ? null : {
        candidate: data.candidate,
        sdpMLineIndex: data.sdpMLineIndex,
        sdpMid: data.sdpMid,
      });
    } catch (error) { setMessage(`Could not apply a server ICE candidate: ${error.message}`, 'error'); }
  });
  eventSource.addEventListener('ice-restart', async (event) => {
    try {
      const data = JSON.parse(event.data);
      await restartIce(data.ice_servers || []);
    } catch (error) { setMessage(`Network recovery failed: ${error.message}`, 'error'); }
  });
  eventSource.addEventListener('generation_ended', (event) => {
    let data = {};
    try { data = JSON.parse(event.data); } catch { /* ignore */ }
    finishRemoteSession(data.reason || 'ended');
  });
  eventSource.addEventListener('error', (event) => {
    if (event.data) {
      try { const data = JSON.parse(event.data); setMessage(data.detail || data.title || 'Decart reported a session error.', 'error'); }
      catch { setMessage('Decart reported a realtime session error.', 'error'); }
    }
  });
  eventSource.onerror = () => {
    if (remoteSessionId && eventSource?.readyState === EventSource.CONNECTING) setConnection('Reconnecting events…', 'starting');
  };
}

async function restartIce(iceServers) {
  if (!peerConnection || !remoteSessionId) return;
  if (iceServers.length) peerConnection.setConfiguration({ iceServers });
  const offer = await peerConnection.createOffer({ iceRestart: true });
  await peerConnection.setLocalDescription(offer);
  const result = await postJson(API('sessions.php'), {
    action: 'ice', session_id: remoteSessionId,
    sdp: { type: 'offer', sdp: peerConnection.localDescription.sdp },
  });
  if (result.sdp) await peerConnection.setRemoteDescription(result.sdp);
}

async function loadReferenceImage(reference = selectedReference) {
  if (!reference?.id) return null;
  const url = `${API('reference.php')}?action=preview&id=${encodeURIComponent(reference.id)}&download=${Date.now()}`;
  const response = await fetch(url, { credentials: 'same-origin', cache: 'no-store' });
  if (!response.ok) throw new Error(`Could not retrieve the private reference image (HTTP ${response.status}).`);
  const blob = await response.blob();
  if (!blob.type.startsWith('image/')) throw new Error('The stored reference file is not a supported image.');
  return new File([blob], reference.original_name || 'reference-image', { type: blob.type, lastModified: Date.now() });
}

async function getDecartSdk() {
  if (!sdkModulePromise) {
    sdkModulePromise = import('https://esm.sh/@decartai/sdk?bundle&target=es2022')
      .then((module) => {
        if (typeof module.createDecartClient !== 'function' || !module.models?.realtime) {
          throw new Error('The Decart browser SDK did not expose the expected realtime API.');
        }
        return module;
      })
      .catch((error) => {
        sdkModulePromise = null;
        throw new Error(`Could not load Decart's browser SDK. Check your internet connection or content-security policy. ${error.message}`);
      });
  }
  return sdkModulePromise;
}

async function startSdkDirect(stream, sdkModule, model) {
  const { createDecartClient } = sdkModule;
  if (!decartClient) {
    decartClient = createDecartClient({
      apiKeyProvider: async () => {
        const token = await postJson(API('client-token.php'), { model: selectedModel });
        if (token.model !== selectedModel || !token.apiKey) throw new Error('The server returned a token that was not scoped to the selected model.');
        return token.apiKey;
      },
    });
  }

  const initialState = {};
  const prompt = $('promptInput').value.trim();
  if (prompt) initialState.prompt = { text: prompt, enhance: $('enhancePrompt').checked };
  if (selectedReference?.id) initialState.image = await loadReferenceImage(selectedReference);

  setConnection(`Connecting ${selectedModel}…`, 'starting');
  setMessage(`Connecting to Decart ${selectedModel} using its official browser SDK…`);
  realtimeClient = await decartClient.realtime.connect(stream, {
    model,
    mirror: 'auto',
    onRemoteStream: (transformedStream) => {
      $('outputVideo').srcObject = transformedStream;
      $('outputEmpty').hidden = true;
      $('outputLiveLabel').hidden = false;
      $('outputFrameStatus').textContent = 'OUTPUT RECEIVING';
      $('outputFrameStatus').classList.add('is-live');
      $('outputVideo').play().catch(() => {});
      setConnection('Connected to Decart', 'live');
      setMessage('Realtime connection established. Your transformed video is live.', 'success');
    },
    ...(Object.keys(initialState).length ? { initialState } : {}),
  });

  // Surface the SDK's documented realtime lifecycle and error events in the workspace UI.
  if (typeof realtimeClient.on === 'function') {
    const thisSessionClient = realtimeClient;
    realtimeClient.on('connectionChange', (state) => {
      if (realtimeClient !== thisSessionClient) return;
      if (state === 'connected') {
        setConnection('Decart connected · preparing output', 'starting');
      } else if (state === 'generating') {
        setConnection('Live transformation', 'live');
      } else if (state === 'reconnecting') {
        setConnection('Reconnecting to Decart…', 'starting');
        setMessage('The Decart connection is recovering. Keep this page open.');
      } else if (state === 'disconnected' && !intentionalSdkDisconnect) {
        finishSdkSession('connection disconnected', thisSessionClient);
      }
    });
    // The current Decart SDK emits sessionEnded with provider-side termination reasons
    // (for example insufficient credits or a session limit). Handle it explicitly;
    // connectionChange alone does not reliably communicate why the session ended.
    realtimeClient.on('sessionEnded', ({ reason } = {}) => {
      finishSdkSession(reason || 'ended by Decart', thisSessionClient);
    });
    realtimeClient.on('generationTick', ({ seconds } = {}) => {
      if (realtimeClient !== thisSessionClient) return;
      if (Number.isFinite(Number(seconds))) sessionElapsed = Number(seconds);
    });
    realtimeClient.on('error', (error) => {
      if (realtimeClient !== thisSessionClient) return;
      const message = error?.message || 'Decart reported a realtime session error.';
      setConnection('Decart session error', 'error');
      setMessage(message, 'error');
      showToast(message, 'error');
    });
  }

  connectionStartedAt = Date.now();
  sessionElapsed = 0;
  setBusy(false);
  if (!$('outputVideo').srcObject) {
    setConnection('Session connected · waiting for output', 'starting');
    setMessage(`Connected to ${selectedModel}. Waiting for the first transformed video frames…`);
  }
}

function finishSdkSession(reason, sessionClient) {
  if (sessionClient && realtimeClient !== sessionClient) return;
  realtimeClient = null;
  $('outputVideo').srcObject = null;
  $('outputEmpty').hidden = false;
  $('outputLiveLabel').hidden = true;
  $('outputFrameStatus').textContent = 'SESSION ENDED';
  $('outputFrameStatus').classList.remove('is-live');
  setConnection('Session ended', 'ready');
  setBusy(false);
  if (!intentionalSdkDisconnect) {
    const detail = String(reason || 'ended').replace(/[_-]+/g, ' ');
    setMessage(`Decart ended the realtime session (${detail}). Your camera remains available; start a new transformation when ready.`, 'error');
  }
}

async function startTransformation(options = {}) {
  if (!appConfig?.configured) throw new Error('Decart is not configured. Add the permanent API key to the server first.');
  if (hasActiveSession()) return;
  if (!$('promptInput').value.trim() && !selectedReference?.id) throw new Error('Choose a prompt or upload a reference image before starting the transformation.');
  setConnection('Starting session…', 'starting');
  setMessage('Requesting camera access and creating your Decart realtime session…');
  setBusy(true);
  try {
    if (isSdkDirect()) {
      const sdkModule = await getDecartSdk();
      const modelDefinition = sdkModule.models.realtime(selectedModel);
      if (!modelDefinition) throw new Error(`Decart's browser SDK does not recognize ${selectedModel}. No fallback model will be selected.`);
      const stream = await ensureCamera(modelDefinition);
      await startSdkDirect(stream, sdkModule, modelDefinition);
      return;
    }
    const stream = await ensureCamera();
    const pc = new RTCPeerConnection({ iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] });
    peerConnection = pc;
    pendingIce = [];
    pc.onicecandidate = (event) => enqueueIce(event.candidate);
    pc.ontrack = (event) => {
      const remoteStream = event.streams?.[0] || new MediaStream([event.track]);
      $('outputVideo').srcObject = remoteStream;
      $('outputEmpty').hidden = true;
      $('outputLiveLabel').hidden = false;
      $('outputFrameStatus').textContent = 'OUTPUT RECEIVING';
      $('outputFrameStatus').classList.add('is-live');
      $('outputVideo').play().catch(() => {});
    };
    pc.onconnectionstatechange = () => {
      if (pc.connectionState === 'connected') {
        setConnection('Connected to Decart', 'live');
        $('outputEmpty').hidden = true;
        setMessage('Realtime connection established. Your transformed video is live.', 'success');
      } else if (pc.connectionState === 'failed') {
        setConnection('Connection failed', 'error');
        setMessage('WebRTC connection failed. Check your network, firewall, and HTTPS configuration, then try again.', 'error');
      } else if (pc.connectionState === 'disconnected') {
        setConnection('Connection interrupted', 'starting');
      }
    };
    stream.getVideoTracks().forEach((track) => pc.addTrack(track, stream));
    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);
    const result = await postJson(API('sessions.php'), {
      action: 'create', model: selectedModel,
      sdp: { type: 'offer', sdp: pc.localDescription.sdp },
      prompt: $('promptInput').value.trim(),
      enhance_prompt: $('enhancePrompt').checked,
    });
    remoteSessionId = result.session_id;
    appConfig.lastEtag = result.etag;
    if (result.ice_servers?.length) {
      const combined = [...(result.ice_servers || []), { urls: 'stun:stun.l.google.com:19302' }];
      pc.setConfiguration({ iceServers: combined });
    }
    await pc.setRemoteDescription(result.sdp);
    openSessionEvents(result.events);
    await flushIceQueue();
    connectionStartedAt = Date.now();
    sessionElapsed = 0;
    $('outputVideo').play().catch(() => {});
    $('startBtn').disabled = true;
    $('stopBtn').disabled = false;
    $('pauseBtn').disabled = false;
    $('switchCameraBtn').disabled = false;
    $('applyPromptBtn').disabled = false;
    setConnection('Session created · connecting media', 'starting');
    setMessage(`Session created with ${selectedModel === 'lucy-2.5' ? 'Lucy 2.5' : 'Lucy 2.6'}. Waiting for transformed video…`);
  } catch (error) {
    try { peerConnection?.close(); } catch { /* no-op */ }
    peerConnection = null;
    try { realtimeClient?.disconnect(); } catch { /* best-effort cleanup */ }
    realtimeClient = null;
    if (eventSource) eventSource.close();
    eventSource = null;
    if (remoteSessionId) {
      try { await postJson(API('sessions.php'), { action: 'end', session_id: remoteSessionId }); } catch { /* session cleanup best effort */ }
    }
    remoteSessionId = null;
    if (!options.reuseCamera && cameraStream) {
      cameraStream.getTracks().forEach((track) => track.stop());
      cameraStream = null;
      setInputPreview();
    }
    setConnection('Unable to connect', 'error');
    setBusy(false);
    throw error;
  }
}

function finishRemoteSession(reason) {
  if (eventSource) eventSource.close();
  eventSource = null;
  if (peerConnection) peerConnection.close();
  peerConnection = null;
  const endedId = remoteSessionId;
  lastEndedSessionId = endedId;
  remoteSessionId = null;
  $('outputVideo').srcObject = null;
  $('outputEmpty').hidden = false;
  $('outputLiveLabel').hidden = true;
  $('outputFrameStatus').textContent = 'SESSION ENDED';
  $('outputFrameStatus').classList.remove('is-live');
  setConnection('Session ended', 'ready');
  setBusy(false);
  if (endedId) {
    setMessage(`Decart ended the session (${reason}). Finalizing provider-measured billing…`);
    postJson(API('sessions.php'), { action: 'end', session_id: endedId }).then(ended => {
      if (ended.billing) {
        const bill = ended.billing;
        $('retryRealtimeBilling').hidden = bill.status !== 'unpaid';
        setMessage(bill.status === 'settled' ? `Realtime ended · ${bill.billed_seconds} billed seconds · ${Number(bill.credits_charged).toLocaleString()} credits charged.` : `Realtime ended · ${Number(bill.credits_due).toLocaleString()} credits due. Top up and retry reconciliation.`, bill.status === 'settled' ? 'success' : 'error');
      } else setMessage('Realtime ended. Decart did not return billed_seconds, so no estimated charge was made.');
    }).catch(() => setMessage('Realtime ended, but billing could not be finalized. Check session history before retrying.', 'error'));
  }
}

async function stopSession(options = {}) {
  const { stopCamera = true, silent = false } = options;
  let billingMessage = '';
  let billingMessageType = '';
  const id = remoteSessionId;
  lastEndedSessionId = id;
  if (eventSource) eventSource.close();
  eventSource = null;
  if (peerConnection) peerConnection.close();
  peerConnection = null;
  if (realtimeClient) {
    intentionalSdkDisconnect = true;
    try { await realtimeClient.disconnect(); }
    catch (error) { if (!silent) showToast(`SDK disconnect warning: ${error.message}`, 'error'); }
    finally { intentionalSdkDisconnect = false; }
  }
  realtimeClient = null;
  remoteSessionId = null;
  pendingIce = [];
  if (id) {
    try { const ended=await postJson(API('sessions.php'), { action: 'end', session_id: id }); if(!silent&&ended.billing){const b=ended.billing;$('retryRealtimeBilling').hidden=b.status!=='unpaid';billingMessage=b.status==='settled'?`Transformation stopped · ${b.billed_seconds} billed seconds · ${Number(b.credits_charged).toLocaleString()} credits charged.`:`Transformation stopped · ${Number(b.credits_due).toLocaleString()} credits due. Add credits, then retry reconciliation.`;billingMessageType=b.status==='settled'?'success':'error';}else if(!silent&&!ended.billing){billingMessage='Transformation stopped. Decart has not supplied billed_seconds, so no estimated charge was applied.';}}
    catch (error) { if (!silent) showToast(`Session cleanup warning: ${error.message}`, 'error'); }
  }
  $('outputVideo').srcObject = null;
  $('outputEmpty').hidden = false;
  $('outputLiveLabel').hidden = true;
  $('outputFrameStatus').textContent = 'WAITING FOR SESSION';
  $('outputFrameStatus').classList.remove('is-live');
  if (stopCamera && cameraStream) {
    cameraStream.getTracks().forEach((track) => track.stop());
    cameraStream = null;
    $('openCameraBtn').disabled = false;
    $('openCameraBtn').textContent = '◎ Open camera';
    $('switchCameraBtn').disabled = true;
    setInputPreview();
  }
  paused = false;
  // A model switch may keep the camera stream alive; always re-enable its track after a pause.
  cameraStream?.getVideoTracks().forEach((track) => { track.enabled = true; });
  $('pauseBtn').textContent = 'Ⅱ Pause input';
  setConnection('Ready to connect', 'ready');
  setBusy(false);
  if (!silent) setMessage(billingMessage || 'Transformation stopped. Camera and Decart session have been closed.', billingMessageType);
}

async function applyPrompt() {
  if (!hasActiveSession()) { showToast('Start a transformation before applying a live prompt.', 'error'); return; }
  const prompt = $('promptInput').value.trim();
  if (!prompt) { showToast('Enter a transformation prompt first.', 'error'); return; }
  $('applyPromptBtn').disabled = true;
  setMessage('Sending prompt update to Decart…');
  try {
    if (realtimeClient && isSdkDirect()) {
      const image = selectedReference?.id ? await loadReferenceImage(selectedReference) : null;
      await realtimeClient.set({ prompt, image, enhance: $('enhancePrompt').checked });
    } else if (selectedReference?.id) {
      await postJson(API('sessions.php'), { action: 'image', session_id: remoteSessionId, reference_id: selectedReference.id, prompt, enhance_prompt: $('enhancePrompt').checked });
    } else {
      await postJson(API('sessions.php'), { action: 'prompt', session_id: remoteSessionId, prompt, enhance_prompt: $('enhancePrompt').checked });
    }
    await saveWorkspace({ prompt, enhance_prompt: $('enhancePrompt').checked });
    setMessage('Prompt update accepted by Decart.', 'success');
    showToast('Prompt applied to the live session.');
  } catch (error) { setMessage(error.message, 'error'); showToast(error.message, 'error'); }
  finally { $('applyPromptBtn').disabled = !hasActiveSession(); }
}

async function switchCamera() {
  if (!cameraStream) return;
  const nextFacing = currentFacingMode === 'user' ? 'environment' : 'user';
  const wasActive = hasActiveSession();

  if (realtimeClient && isSdkDirect()) {
    // The SDK connection does not expose a documented replaceTrack operation; restart cleanly with the new camera.
    await stopSession({ stopCamera: false, silent: true });
    cameraStream?.getTracks().forEach((track) => track.stop());
    cameraStream = null;
    currentFacingMode = nextFacing;
    try {
      await ensureCamera();
      if (wasActive) await startTransformation({ reuseCamera: true });
      showToast(`Switched to ${nextFacing === 'user' ? 'front' : 'back'} camera.`);
    } catch (error) {
      setMessage(error.message, 'error');
      showToast(error.message, 'error');
    }
    return;
  }

  let nextStream;
  try {
    nextStream = await navigator.mediaDevices.getUserMedia({ audio: false, video: { facingMode: { exact: nextFacing }, width: { ideal: 1280 }, height: { ideal: 720 } } });
  } catch (error) {
    try {
      nextStream = await navigator.mediaDevices.getUserMedia({ audio: false, video: { facingMode: { ideal: nextFacing }, width: { ideal: 1280 }, height: { ideal: 720 } } });
    } catch { showToast('The other camera is not available on this device.', 'error'); return; }
  }
  const newTrack = nextStream.getVideoTracks()[0];
  const sender = peerConnection?.getSenders().find((item) => item.track?.kind === 'video');
  try { if (sender) await sender.replaceTrack(newTrack); }
  catch (error) { nextStream.getTracks().forEach((track) => track.stop()); showToast(`Could not switch camera: ${error.message}`, 'error'); return; }
  cameraStream?.getTracks().forEach((track) => track.stop());
  cameraStream = nextStream;
  currentFacingMode = nextFacing;
  $('inputVideo').srcObject = cameraStream;
  showToast(`Switched to ${nextFacing === 'user' ? 'front' : 'back'} camera.`);
}

function togglePause() {
  const track = cameraStream?.getVideoTracks()[0];
  if (!track) return;
  paused = !paused;
  track.enabled = !paused;
  $('pauseBtn').textContent = paused ? '▶ Resume input' : 'Ⅱ Pause input';
  setMessage(paused ? 'Camera input paused. The Decart session remains connected and may continue to count usage.' : 'Camera input resumed.', paused ? '' : 'success');
}

async function fullscreenOutput() {
  const stage = $('outputStage');
  try {
    if (document.fullscreenElement === stage) await document.exitFullscreen();
    else if (stage.requestFullscreen) await stage.requestFullscreen();
    else if ($('outputVideo').webkitEnterFullscreen) $('outputVideo').webkitEnterFullscreen();
    else showToast('Fullscreen is not available in this browser.', 'error');
  } catch (error) { showToast(`Could not enter fullscreen: ${error.message}`, 'error'); }
}

async function resetWorkspace() {
  const running = hasActiveSession();
  await stopSession({ stopCamera: true, silent: true });
  try { await requestJson(`${API('reference.php')}?action=delete`, { method: 'POST', body: JSON.stringify({}) }); } catch { /* nothing to remove */ }
  renderReference(null);
  $('promptInput').value = '';
  $('enhancePrompt').checked = true;
  selectedPromptId = null;
  const enabledModels = (appConfig?.models || []).map((item) => item.id);
  selectedModel = enabledModels.includes('lucy-2.6') ? 'lucy-2.6' : (enabledModels[0] || '');
  renderModelSelection();
  if (selectedModel) { try { await saveWorkspace({ model: selectedModel, prompt: '', enhance_prompt: true }); } catch (error) { showToast(error.message, 'error'); } }
  updateCharacterCount();
  renderPromptLibrary();
  setMessage(running ? 'Workspace reset. The camera and realtime session were closed.' : (selectedModel ? `Workspace reset to ${selectedModel} with an empty prompt.` : 'Workspace reset. No realtime model is currently enabled.'));
  showToast('Workspace reset.');
}

$('modelGrid').addEventListener('click', (event) => {
  const card = event.target.closest('[data-model]');
  if (card) selectModel(card.dataset.model);
});
$('promptInput').addEventListener('input', () => { updateCharacterCount(); saveWorkspace({ prompt: $('promptInput').value }).catch(() => {}); });
$('enhancePrompt').addEventListener('change', () => saveWorkspace({ enhance_prompt: $('enhancePrompt').checked }).catch((error) => showToast(error.message, 'error')));
$('applyPromptBtn').addEventListener('click', applyPrompt);
$('openCameraBtn').addEventListener('click', async () => {
  const button = $('openCameraBtn');
  button.disabled = true;
  button.textContent = 'Opening camera…';
  try {
    await ensureCamera();
    setMessage('Camera is open. You can preview your input or start the transformation when ready.', 'success');
    showToast('Camera opened successfully.');
  } catch (error) {
    button.disabled = false;
    button.textContent = '◎ Open camera';
    setMessage(error.message, 'error');
    showToast(error.message, 'error');
  }
});
$('startBtn').addEventListener('click', async () => {
  try { await startTransformation(); }
  catch (error) { setMessage(error.message, 'error'); showToast(error.message, 'error'); }
});
$('stopBtn').addEventListener('click', () => stopSession());
$('retryRealtimeBilling')?.addEventListener('click', async () => {
  if (!lastEndedSessionId) return;
  const button = $('retryRealtimeBilling'); button.disabled = true;
  try {
    const result = await postJson(API('sessions.php'), { action: 'reconcile', session_id: lastEndedSessionId });
    const bill = result.billing || {};
    if (bill.status === 'settled') { button.hidden = true; setMessage(`Realtime billing settled · ${Number(bill.credits_charged || 0).toLocaleString()} credits charged.`, 'success'); }
    else setMessage(`Realtime usage remains unpaid · ${Number(bill.credits_due || 0).toLocaleString()} credits due. Add credits and retry.`, 'error');
  } catch (error) { setMessage(error.message || 'Could not reconcile realtime billing.', 'error'); }
  finally { button.disabled = false; }
});

$('pauseBtn').addEventListener('click', togglePause);
$('switchCameraBtn').addEventListener('click', switchCamera);
$('fullscreenOutputBtn').addEventListener('click', fullscreenOutput);
$('resetBtn').addEventListener('click', resetWorkspace);
$('referenceFile').addEventListener('change', (event) => { uploadReference(event.target.files?.[0]); event.target.value = ''; });
$('referenceCameraFile').addEventListener('change', (event) => { uploadReference(event.target.files?.[0]); event.target.value = ''; });
$('removeReferenceBtn').addEventListener('click', removeReference);
$('promptSearch').addEventListener('input', renderPromptLibrary);
$('promptCategory').addEventListener('change', renderPromptLibrary);
$('promptPrev').addEventListener('click', () => $('promptStrip').scrollBy({ left: -360, behavior: 'smooth' }));
$('promptNext').addEventListener('click', () => $('promptStrip').scrollBy({ left: 360, behavior: 'smooth' }));
$('managePromptsBtn').addEventListener('click', () => { renderManagedPrompts(); $('promptDialog').showModal(); });
$('newPromptBtn').addEventListener('click', () => openPromptForm());
$('cancelPromptEdit').addEventListener('click', clearPromptForm);
$('promptDialog').addEventListener('close', clearPromptForm);

window.addEventListener('pagehide', () => {
  if (remoteSessionId) {
    const body = new Blob([JSON.stringify({ action: 'end', session_id: remoteSessionId })], { type: 'application/json' });
    fetch(API('sessions.php'), { method: 'POST', headers: { 'X-CSRF-Token': APP.csrfToken }, body, credentials: 'same-origin', keepalive: true }).catch(() => {});
  }
  cameraStream?.getTracks().forEach((track) => track.stop());
  eventSource?.close();
  peerConnection?.close();
  try {
    intentionalSdkDisconnect = true;
    realtimeClient?.disconnect();
  } catch { /* page is unloading */ }
});

document.addEventListener('fullscreenchange', () => {
  $('fullscreenOutputBtn').textContent = document.fullscreenElement === $('outputStage') ? '×' : '⛶';
});

async function boot() {
  try {
    await loadConfig();
    await loadPrompts();
    setBusy(false);
    if (appConfig.configured) setConnection('Ready to connect', 'ready');
  } catch (error) {
    setConnection('Workspace setup issue', 'error');
    setMessage(error.message, 'error');
    showToast(error.message, 'error');
  }
}
boot();
