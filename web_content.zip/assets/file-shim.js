(function(){
  if (location.protocol !== "file:") return;
  var me = document.currentScript && document.currentScript.src || "";
  var ROOT = me.replace(/assets\/file-shim\.js.*$/, "");
  var MAP = {"assets/kb-g9.json": "ebc80d9f077b", "assets/study-data-g7.json": "387da68129d8", "assets/kb-g7.json": "c90d6adfa10a", "assets/grades.json": "c9f0933e971a", "assets/study-data-g9.json": "68b900262931", "assets/study-data.json": "4d78c3bfe500", "assets/kb.json": "1301360b8aca", "g9/pages/quran.html": "a0c24e1a29b0", "g9/pages/art.html": "05b1e868aa75", "g9/pages/math.html": "c9d11c99fd30", "g9/pages/english.html": "dba88abb6cb4", "g9/pages/science.html": "7c8dc8222141", "g9/pages/religion.html": "e4225d2f4f94", "g9/pages/farsi.html": "c4aba5285d1b", "g9/pages/negaresh.html": "02b1c70301cf", "g9/pages/arabic.html": "99c984c11b96", "g9/pages/tech.html": "de760aee0eab", "g9/pages/social.html": "d75cca369585", "g9/pages/defa.html": "bf8a1dee6c2f", "g7/pages/quran.html": "c6211225c708", "g7/pages/art.html": "092f82742a63", "g7/pages/math.html": "5663e7de55af", "g7/pages/thinking.html": "a812e2c8cdc1", "g7/pages/english.html": "65fdb0c47ab2", "g7/pages/science.html": "fb47e86aa499", "g7/pages/religion.html": "cdb4af198265", "g7/pages/farsi.html": "a58a94d8f1c0", "g7/pages/negaresh.html": "15d91b1b86f0", "g7/pages/arabic.html": "fe46be950413", "g7/pages/tech.html": "220bf2c72a3c", "g7/pages/social.html": "8144d5f2be34", "pages/quran.html": "f519bdb0c6cb", "pages/art.html": "8b3873a5c916", "pages/math.html": "0d2e106e82a6", "pages/thinking.html": "b1e63d88bc69", "pages/english.html": "ceb7357aa49b", "pages/science.html": "7ddd35972be4", "pages/religion.html": "4ecfbe241dc4", "pages/farsi.html": "3a6c8f239a81", "pages/negaresh.html": "03f2a5708f36", "pages/arabic.html": "170c4bb8cef6", "pages/tech.html": "118090d61688", "pages/social.html": "c9fee0806b39"};
  window.__FD = window.__FD || {};
  var orig = window.fetch ? window.fetch.bind(window) : null;
  function load(key){
    return new Promise(function(res, rej){
      if (key in window.__FD) return res(window.__FD[key]);
      var s = document.createElement("script");
      s.src = ROOT + "assets/fdata/" + MAP[key] + ".js";
      s.onload = function(){ res(window.__FD[key]); };
      s.onerror = function(){ rej(new TypeError("load failed: " + key)); };
      document.head.appendChild(s);
    });
  }
  function resp(text, key){
    var isJson = /\.json$/.test(key);
    return {
      ok: true, status: 200, url: ROOT + key, headers: { get: function(){ return isJson ? "application/json" : "text/html"; } },
      text: function(){ return Promise.resolve(text); },
      json: function(){ try { return Promise.resolve(JSON.parse(text)); } catch(e){ return Promise.reject(e); } },
      clone: function(){ return resp(text, key); }
    };
  }
  window.fetch = function(input, init){
    var u = typeof input === "string" ? input : (input && input.url) || "";
    try {
      var abs = new URL(u, location.href).href.split("#")[0].split("?")[0];
      if (abs.indexOf(ROOT) === 0) {
        var key = decodeURIComponent(abs.slice(ROOT.length));
        if (MAP[key]) return load(key).then(function(t){ return resp(t, key); });
      }
    } catch(e){}
    return orig ? orig(input, init) : Promise.reject(new TypeError("fetch unavailable"));
  };
})();
