# Audio Assets Directory

Snake Escape features a complete **Web Audio API procedural sound synthesizer** located in `js/audio.js`.
All sound effects and ambient jungle background music are generated dynamically in code using native browser oscillators, gain nodes, and biquad filters:

- `button_click`: Juicy wooden pop
- `snake_move`: Soft organic whoosh
- `snake_turn`: Melodic turn chime
- `wall_bump`: Soft rubbery thud
- `portal_escape`: Sparkling magical portal chime
- `star_reward`: Ascending bell chime
- `level_complete`: Triumphant celebratory fanfare
- `level_failed`: Sad descending minor tone
- `hint`: Celestial chime
- `undo`: Quick reverse swoosh
- `background_music`: Looping pentatonic marimba & ambient jungle soundscape

No external MP3/WAV files are required to run the game! Custom sound files may optionally be placed in this folder if desired.
