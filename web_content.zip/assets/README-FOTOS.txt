Coloque aqui as fotos JPG das candidatas com os nomes candidate-01.jpg, candidate-02.jpg, etc.
