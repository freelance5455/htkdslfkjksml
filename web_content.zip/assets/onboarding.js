(() => {
  'use strict';
  const body = document.body;
  const slides = [...document.querySelectorAll('[data-slide]')];
  const progress = [...document.querySelectorAll('.progress-step')];
  const next = document.getElementById('nextButton');
  const back = document.getElementById('backButton');
  const skip = document.getElementById('skipIntro');
  const count = document.getElementById('currentSlide');
  const category = document.getElementById('slideCategory');
  const entry = document.getElementById('entryLink');
  const stage = document.getElementById('onboardingStage');
  const nextLabel = document.getElementById('nextLabel');
  const completeKey = 'anonymoux-onboarding-v1-complete';
  const entryTarget = body.dataset.entryTarget || 'login.php?direct=1';
  const isAuthenticated = body.dataset.authenticated === '1';
  const replay = body.dataset.replay === '1';
  let active = 0;
  let touchStart = null;
  let locked = false;

  const completed = () => {
    try { return localStorage.getItem(completeKey) === '1'; } catch { return false; }
  };
  const markComplete = () => {
    try { localStorage.setItem(completeKey, '1'); } catch { /* Private browsing may block storage. */ }
  };
  const enter = () => {
    markComplete();
    window.location.assign(entryTarget);
  };
  if (!replay && !isAuthenticated && completed()) {
    window.location.replace(entryTarget);
    return;
  }

  function preloadAround(index) {
    [index, index + 1].forEach((i) => {
      const image = slides[i]?.querySelector('img[data-src]');
      if (image) {
        image.src = image.dataset.src;
        image.removeAttribute('data-src');
      }
    });
  }

  function render(index, direction = 1) {
    if (locked || index < 0 || index >= slides.length || index === active) return;
    locked = true;
    const previous = active;
    active = index;
    slides.forEach((slide, i) => {
      const on = i === active;
      slide.classList.toggle('is-active', on);
      slide.setAttribute('aria-hidden', String(!on));
    });
    progress.forEach((step, i) => {
      step.classList.toggle('is-active', i === active);
      step.classList.toggle('is-complete', i < active);
      if (i === active) step.setAttribute('aria-current', 'step');
      else step.removeAttribute('aria-current');
    });
    count.textContent = String(active + 1).padStart(2, '0');
    const meta = slides[active].querySelector('.slide-meta span:last-child');
    category.textContent = meta ? meta.textContent : '';
    back.disabled = active === 0;
    nextLabel.textContent = active === slides.length - 1 ? (isAuthenticated ? 'Enter Studio' : 'Sign in') : 'Next';
    next.querySelector('span:last-child').textContent = active === slides.length - 1 ? '↗' : '→';
    entry.textContent = isAuthenticated ? 'Enter Studio' : 'Sign in to Studio';
    preloadAround(active);
    stage.dataset.direction = direction > 0 ? 'next' : 'previous';
    window.setTimeout(() => { locked = false; }, window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 20 : 560);
  }

  next.addEventListener('click', () => {
    if (active === slides.length - 1) enter();
    else render(active + 1, 1);
  });
  back.addEventListener('click', () => render(active - 1, -1));
  skip.addEventListener('click', enter);
  progress.forEach((step) => step.addEventListener('click', () => {
    const target = Number(step.dataset.go);
    if (Number.isInteger(target) && target <= active) render(target, -1);
  }));
  entry.addEventListener('click', (event) => {
    event.preventDefault();
    enter();
  });

  document.addEventListener('keydown', (event) => {
    if (event.altKey || event.ctrlKey || event.metaKey) return;
    if (event.key === 'ArrowRight' && active < slides.length - 1) {
      event.preventDefault(); render(active + 1, 1);
    } else if (event.key === 'ArrowLeft' && active > 0) {
      event.preventDefault(); render(active - 1, -1);
    } else if (event.key === 'Escape') {
      event.preventDefault(); enter();
    }
  });

  stage.addEventListener('pointerdown', (event) => {
    if (event.target.closest('button,a')) return;
    touchStart = { x: event.clientX, y: event.clientY, id: event.pointerId };
  }, { passive: true });
  stage.addEventListener('pointerup', (event) => {
    if (!touchStart || touchStart.id !== event.pointerId) return;
    const dx = event.clientX - touchStart.x;
    const dy = event.clientY - touchStart.y;
    touchStart = null;
    if (Math.abs(dx) > 48 && Math.abs(dx) > Math.abs(dy) * 1.25) {
      if (dx < 0 && active < slides.length - 1) render(active + 1, 1);
      if (dx > 0 && active > 0) render(active - 1, -1);
    }
  }, { passive: true });
  stage.addEventListener('pointercancel', () => { touchStart = null; }, { passive: true });

  preloadAround(0);
  back.disabled = true;
})();
