GYMNach — proyecto Android

Este proyecto envuelve la aplicación de entrenamiento en una aplicación Android nativa con WebView. No solicita permiso de Internet y carga el HTML desde los assets locales; las funciones principales pueden usarse sin conexión.

PARA GENERAR EL APK
1. Instala Android Studio en un ordenador.
2. Abre la carpeta GYMNach-Android como proyecto existente.
3. Deja que Android Studio sincronice Gradle e instale el SDK de Android API 35 si lo solicita.
4. Selecciona Build > Build Bundle(s) / APK(s) > Build APK(s).
5. El APK de depuración se encontrará en app/build/outputs/apk/debug/app-debug.apk.

Nota: en el entorno actual no están instalados Android SDK ni Gradle, por lo que no se ha podido compilar ni verificar un APK aquí. Este ZIP contiene el proyecto fuente listo para abrir en Android Studio, no un APK ya compilado.
