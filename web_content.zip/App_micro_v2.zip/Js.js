self.addEventListener('install',e=>self.skipWaiting());
self.addEventListener('fetch',e=>e.respondWith(fetch(e.request).catch(()=>{})));
self.addEventListener('notificationclick',e=>{e.notification.close();e.waitUntil(clients.openWindow('index.html'));});