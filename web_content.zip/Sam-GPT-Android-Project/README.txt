SAM GPT — ANDROID APP STARTER
============================

This ZIP contains the Sam GPT mobile web app and a Capacitor Android wrapper project.

IMPORTANT MODEL NOTE
--------------------
The Qwen2.5-0.5B-Instruct model WEIGHTS ARE NOT EMBEDDED in this ZIP. The app's
current Transformers.js setup downloads the quantized model the first time you
press “Download & load model”. It then uses the browser cache where supported.
This first download requires internet and several hundred MB of storage. I have
not labelled this ZIP as a fully offline/model-bundled build because the model
binary could not be included in this package.

The app uses:
- Qwen2.5-0.5B-Instruct via onnx-community / Hugging Face Transformers.js
- Local on-device text generation after the model has loaded
- No API key
- A mobile-friendly chat UI
- Basic image adjustments (not AI image generation)
- A simple Wikipedia-based research mode (requires internet)

ANDROID BUILD (requires a computer with Node.js and Android Studio)
-------------------------------------------------------------------
1. Extract this ZIP.
2. Open a terminal in the extracted Sam-GPT-Android-Project folder.
3. Run: npm install
4. Run: npx cap add android
5. Run: npx cap sync android
6. Run: npx cap open android
7. In Android Studio, wait for Gradle sync, then build the APK using Build > Build Bundle(s) / APK(s) > Build APK(s).

If Android Studio says the Android platform already exists, skip step 4 and run
npx cap sync android.

TEST IN A BROWSER FIRST
-----------------------
You can also open www/index.html in a modern browser. Model loading requires
internet on first launch. Some browsers restrict local-file module imports;
if so, serve the www folder from a local development server instead.

DEVICE LIMITATIONS
------------------
Qwen2.5-0.5B is a small model, not ChatGPT-level. Speed and compatibility vary
by phone. The current phone-safe path uses CPU inference to reduce GPU crashes,
but low-memory phones may still close the app while loading the model.

MODEL / LIBRARY REFERENCES
--------------------------
Model: https://huggingface.co/onnx-community/Qwen2.5-0.5B-Instruct
Transformers.js: https://huggingface.co/docs/transformers.js
Capacitor: https://capacitorjs.com/docs

The model is distributed under its upstream licence; check the model card for
licence and attribution details before redistribution.
