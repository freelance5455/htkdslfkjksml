Qwen2.5-0.5B-Instruct model weights are not included in this starter ZIP.
The app downloads the quantized model at first launch using Transformers.js.
See the project README.txt for details.
