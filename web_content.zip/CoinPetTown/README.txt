코인 펫타운 Android 앱 프로젝트

Android Studio에서 이 폴더를 열고 Gradle 동기화 후 Build > Generate App Bundles or APKs > Generate APKs를 선택하세요.
생성된 APK를 Android 휴대폰으로 옮겨 설치하면 됩니다.
