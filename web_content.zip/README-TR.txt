NEXUS OS — TELEFON VE PC PAKETİ
================================

UYGULAMA ADI VE İKON
Uygulama Nexus OS adı ve yeni mavi/lacivert N ikonuyla güncellendi.

PAKET İÇERİĞİ
- pc/: Windows bilgisayarda tarayıcı uygulama penceresinde çalıştırma dosyası
- android/: Android Studio ile APK derlemek için kaynak proje
- index.html + manifest + service-worker + ikonlar: HTTPS üzerinde barındırılınca PWA kurulumu

ZORUNLU İLK KAYIT
İlk açılışta ad soyad, işletme adı, e-posta ve en az 8 karakterlik şifre gerekir. Sonraki açılışlarda giriş yapılır. Bu yerel sürümde hesap yalnızca o cihazda saklanır; e-posta doğrulaması veya cihazlar arası senkronizasyon yoktur.

PC
ZIP dosyasını çıkarın, pc klasörünü açın ve Nexus-OS-Baslat.bat dosyasına çift tıklayın.

ANDROID APK
android klasörünü Android Studio ile açın, SDK 35 ve Gradle eşitlemesini tamamlayın, ardından Build > Build APK(s) seçin. Bu paket APK değil, kaynak projedir.

VERİLER
Veriler cihaz/tarayıcı hafızasında tutulur. Düzenli JSON yedeği alın.
