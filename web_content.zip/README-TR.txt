# VeilCalc Web Uygulaması

Bu proje bir Progressive Web App (PWA) şablonudur.

## Dosya Yapısı
- `index.html`: Ana web sayfası
- `sw.js`: Çevrimdışı destek için Service Worker
- `manifest.webmanifest`: PWA yapılandırma dosyası
- `favicon.svg`: Uygulama logosu/simgesi
- `README-TR.txt`: Açıklama dosyası
