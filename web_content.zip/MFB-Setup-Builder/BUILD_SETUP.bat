@echo off
title MFB Setup Builder
echo ============================================
echo  MFB Management System - Setup.exe banana
echo ============================================
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo Node.js installed nahi hai. Pehle https://nodejs.org se LTS version install karein,
  echo phir yeh file dobara chalayein.
  pause
  exit /b
)
call npm install
if errorlevel 1 goto fail
call npm run dist
if errorlevel 1 goto fail
echo.
echo DONE! Setup file yahan hai: dist\MFB Management System Setup 1.0.0.exe
start "" dist
pause
exit /b
:fail
echo.
echo Error aaya. Internet connection check karein aur dobara try karein.
pause
