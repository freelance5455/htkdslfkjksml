# SOCIAL MEDIA - Real Account Stage

This version no longer uses localStorage as the login system. The client is wired for Firebase Authentication (Email/Password) and Cloud Firestore for user profiles.

## Required one-time setup
1. Create a Firebase project.
2. Add a Web App.
3. Enable Authentication -> Email/Password.
4. Create Firestore.
5. Copy the Web App config into `social-media/firebase-config.js`.
6. Apply `firebase/firestore.rules`.

### What is now in the app
- Real email/password sign-up and login hooks
- Firebase UID-based account identity
- Cloud Firestore user profile storage
- Display name, bio, email and DOB profile editing
- 13+ room-access gate based on DOB
- App Settings screen
- Bangla / English language switch
- Theme switch
- Reduced-motion switch
- Notifications and sound preferences
- Profile visibility preference
- Account/security section placeholder for the next backend stage
- Home welcome section and Study Corner

### Important
The Firebase Web config is intentionally left blank. Without the project's real Firebase configuration, no fake/local login is enabled. This prevents the app from pretending that a local demo account is a real online account.

Real voice rooms, realtime room presence, chat, push notifications and moderation enforcement are the next server-backed stage. They require the backend/media credentials and must not be implemented as client-only UI permissions.
