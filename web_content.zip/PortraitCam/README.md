# PortraitCam – get your APK in ~5 minutes (no Android Studio needed)

1. Create a free account at github.com and make a **new repository** (any name, Private is fine).
2. Click **Add file > Upload files**, drag in everything from this folder
   (include the hidden `.github` folder – or unzip on a PC first), then **Commit**.
3. Open the **Actions** tab > **Build APK** > wait ~4 min for the green tick.
   (If it didn't start: Build APK > **Run workflow**.)
4. Open the finished run > **Artifacts** > download **PortraitCam-apk**, unzip it.
5. Copy the .apk to your Moto Edge 50 Neo, tap it, allow "install unknown apps", install.

Photos save to Pictures/PortraitCam, videos to Movies/PortraitCam.
