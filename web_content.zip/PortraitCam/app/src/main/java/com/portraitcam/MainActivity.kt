package com.portraitcam

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.os.Bundle
import android.provider.MediaStore
import android.util.Range
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.Button
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.core.UseCase
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.exifinterface.media.ExifInterface
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import java.io.File
import java.nio.ByteBuffer
import kotlin.concurrent.thread
import kotlin.math.hypot
import kotlin.math.max

private fun cm(
    sat: Float = 1f, con: Float = 1f,
    r: Float = 1f, g: Float = 1f, b: Float = 1f, lift: Float = 0f
): ColorMatrix {
    val m = ColorMatrix()
    m.setSaturation(sat)
    val t = (1f - con) * 128f + lift
    m.postConcat(
        ColorMatrix(
            floatArrayOf(
                con * r, 0f, 0f, 0f, t,
                0f, con * g, 0f, 0f, t,
                0f, 0f, con * b, 0f, t,
                0f, 0f, 0f, 1f, 0f
            )
        )
    )
    return m
}

class MainActivity : ComponentActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var info: TextView
    private lateinit var shutter: Button
    private lateinit var modeBtn: Button
    private lateinit var portraitBtn: Button
    private lateinit var portraitRow: LinearLayout
    private lateinit var filterScroll: HorizontalScrollView
    private val lensBtns = mutableListOf<Button>()
    private val filterBtns = mutableListOf<Button>()

    private var provider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null

    private var front = false
    private var videoMode = false
    private var portrait = true
    private var blurStrength = 60
    private var filterIdx = 0
    private var lensMm = 55          // 0 = ultrawide
    private var baseEq = 24f         // 35mm-equivalent focal length of the 1x lens

    private val lenses = listOf("UW" to 0, "25" to 25, "35" to 35, "55" to 55, "85" to 85)
    private val filters: List<Pair<String, ColorMatrix?>> = listOf(
        "Original" to null,
        "Vivid" to cm(sat = 1.35f, con = 1.08f),
        "Warm" to cm(r = 1.08f, b = 0.9f, sat = 1.05f),
        "Cool" to cm(r = 0.92f, b = 1.08f),
        "B&W" to cm(sat = 0f, con = 1.1f),
        "Film" to cm(sat = 0.8f, con = 0.92f, r = 1.04f, b = 0.96f, lift = 12f)
    )

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
            if (r[Manifest.permission.CAMERA] == true) startCamera() else toast("Camera permission is required")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else {
            permLauncher.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
        }
    }

    // ---------------------------------------------------------------- UI

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun styleBtn(b: Button, on: Boolean) {
        val bg = GradientDrawable().apply {
            cornerRadius = dp(18).toFloat()
            setColor(if (on) 0xFFFFC107.toInt() else 0x44FFFFFF)
        }
        b.background = bg
        b.setTextColor(if (on) Color.BLACK else Color.WHITE)
    }

    private fun makeBtn(text: String, onClick: () -> Unit): Button = Button(this).apply {
        this.text = text
        isAllCaps = false
        textSize = 13f
        minWidth = 0; minimumWidth = 0; minHeight = 0; minimumHeight = 0
        setPadding(dp(12), dp(6), dp(12), dp(6))
        styleBtn(this, false)
        setOnClickListener { onClick() }
    }

    private fun row() = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(0, dp(4), 0, dp(4))
    }

    private fun buildUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK); fitsSystemWindows = true }
        previewView = PreviewView(this).apply { scaleType = PreviewView.ScaleType.FIT_CENTER }
        root.addView(previewView, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))

        info = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER
            setPadding(dp(12), dp(6), dp(12), dp(6))
        }
        root.addView(info, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0x99000000.toInt())
            setPadding(dp(10), dp(6), dp(10), dp(12))
        }

        // Lens row: UW / 25 / 35 / 55 / 85 mm
        val lensRow = row()
        for ((label, mm) in lenses) {
            val b = makeBtn(if (mm == 0) "UW" else "${label}mm") { lensMm = mm; refreshLensUi(); applyZoom() }
            lensBtns.add(b)
            lensRow.addView(b, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        panel.addView(lensRow)

        // Filter row
        filterScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val fRow = row()
        filters.forEachIndexed { i, (name, _) ->
            val b = makeBtn(name) { filterIdx = i; refreshFilterUi() }
            filterBtns.add(b)
            fRow.addView(b, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        filterScroll.addView(fRow)
        panel.addView(filterScroll)

        // Portrait row
        portraitRow = row()
        portraitBtn = makeBtn("Portrait blur: ON") {
            portrait = !portrait
            portraitBtn.text = if (portrait) "Portrait blur: ON" else "Portrait blur: OFF"
            styleBtn(portraitBtn, portrait)
        }
        styleBtn(portraitBtn, true)
        portraitRow.addView(portraitBtn)
        val seek = SeekBar(this).apply {
            max = 100; progress = blurStrength
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { blurStrength = p }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        portraitRow.addView(seek, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { setMargins(dp(8), 0, 0, 0) })
        panel.addView(portraitRow)

        // Control row
        val ctrl = row().apply { gravity = Gravity.CENTER }
        modeBtn = makeBtn("Photo") { videoMode = !videoMode; refreshModeUi(); bind() }
        shutter = Button(this).apply { setOnClickListener { onShutter() } }
        val flip = makeBtn("Flip") {
            front = !front
            lensMm = if (front) 25 else 55
            refreshLensUi(); bind()
        }
        ctrl.addView(modeBtn, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { setMargins(dp(8), 0, dp(8), 0) })
        ctrl.addView(shutter, LinearLayout.LayoutParams(dp(72), dp(72)))
        ctrl.addView(flip, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { setMargins(dp(8), 0, dp(8), 0) })
        panel.addView(ctrl)

        root.addView(panel, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT, Gravity.BOTTOM))
        setContentView(root)

        refreshLensUi(); refreshFilterUi(); refreshModeUi(); setRec(false)
    }

    private fun refreshLensUi() = lensBtns.forEachIndexed { i, b -> styleBtn(b, lenses[i].second == lensMm) }
    private fun refreshFilterUi() = filterBtns.forEachIndexed { i, b -> styleBtn(b, i == filterIdx) }
    private fun refreshModeUi() {
        modeBtn.text = if (videoMode) "Video 4K" else "Photo"
        val photoOnly = if (videoMode) android.view.View.GONE else android.view.View.VISIBLE
        portraitRow.visibility = photoOnly
        filterScroll.visibility = photoOnly
    }

    private fun setRec(rec: Boolean) {
        shutter.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(if (rec) Color.RED else Color.WHITE)
            setStroke(dp(4), 0xFFFFC107.toInt())
        }
    }

    private fun toast(s: String) = runOnUiThread { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() }

    // ---------------------------------------------------------------- Camera

    private fun startCamera() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({ provider = f.get(); bind() }, ContextCompat.getMainExecutor(this))
    }

    private fun bind() {
        val p = provider ?: return
        recording?.stop(); recording = null
        p.unbindAll()
        val sel = if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
        val ratio = if (videoMode) AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY
        else AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY
        val rs = ResolutionSelector.Builder().setAspectRatioStrategy(ratio).build()
        val preview = Preview.Builder().setResolutionSelector(rs).build()
            .also { it.setSurfaceProvider(previewView.surfaceProvider) }

        val useCase: UseCase
        if (videoMode) {
            val recorder = Recorder.Builder()
                .setQualitySelector(
                    QualitySelector.fromOrderedList(
                        listOf(Quality.UHD, Quality.FHD, Quality.HD),
                        FallbackStrategy.lowerQualityOrHigherThan(Quality.HD)
                    )
                ).build()
            val vc = VideoCapture.Builder(recorder)
                .setTargetFrameRate(Range(30, 30))
                .setVideoStabilizationEnabled(true)
                .build()
            videoCapture = vc; imageCapture = null; useCase = vc
        } else {
            val ic = ImageCapture.Builder()
                .setResolutionSelector(rs)
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .setJpegQuality(100)
                .build()
            imageCapture = ic; videoCapture = null; useCase = ic
        }
        try {
            camera = p.bindToLifecycle(this, sel, preview, useCase)
        } catch (e: Exception) {
            toast("Could not start camera: ${e.message}"); return
        }
        computeBase()
        previewView.post { applyZoom() }
    }

    private fun computeBase() {
        baseEq = 24f
        try {
            val ci = Camera2CameraInfo.from(camera!!.cameraInfo)
            val fl = ci.getCameraCharacteristic(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull()
            val sz = ci.getCameraCharacteristic(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE)
            if (fl != null && sz != null) {
                val eq = fl * 43.27f / hypot(sz.width, sz.height)
                if (eq in 20f..32f) baseEq = eq
            }
        } catch (_: Exception) { }
    }

    private fun applyZoom() {
        val cam = camera ?: return
        val zs = cam.cameraInfo.zoomState.value ?: return
        val want = if (lensMm == 0) zs.minZoomRatio else lensMm / baseEq
        val r = want.coerceIn(zs.minZoomRatio, zs.maxZoomRatio)
        cam.cameraControl.setZoomRatio(r)
        info.text = (if (lensMm == 0) "Ultrawide" else "${lensMm}mm") + "  •  " + "%.1f".format(r) + "x"
    }

    // ---------------------------------------------------------------- Shutter

    private fun onShutter() = if (videoMode) toggleRecord() else takePhoto()

    private fun takePhoto() {
        val ic = imageCapture ?: return
        val file = File(cacheDir, "raw_${System.currentTimeMillis()}.jpg")
        ic.takePicture(
            ImageCapture.OutputFileOptions.Builder(file).build(),
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(r: ImageCapture.OutputFileResults) {
                    toast("Processing…")
                    thread { processAndSave(file) }
                }
                override fun onError(e: ImageCaptureException) = toast("Capture failed: ${e.message}")
            }
        )
    }

    @SuppressLint("MissingPermission")
    private fun toggleRecord() {
        val vc = videoCapture ?: return
        val cur = recording
        if (cur != null) { cur.stop(); recording = null; return }
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "VID_${System.currentTimeMillis()}")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/PortraitCam")
        }
        val opts = MediaStoreOutputOptions.Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(cv).build()
        var pr = vc.output.prepareRecording(this, opts)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            pr = pr.withAudioEnabled()
        }
        recording = pr.start(ContextCompat.getMainExecutor(this)) { ev ->
            if (ev is VideoRecordEvent.Finalize) {
                recording = null; setRec(false)
                toast(if (ev.hasError()) "Video error" else "Video saved to Movies/PortraitCam")
            }
        }
        setRec(true)
    }

    // ---------------------------------------------------------------- Photo processing

    private fun processAndSave(file: File) {
        try {
            val flt = filters[filterIdx].second
            if (!portrait && flt == null) { saveFile(file); toast("Photo saved"); return }

            val exif = ExifInterface(file.path)
            val orient = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.path, bounds)
            var s = 1
            while (max(bounds.outWidth, bounds.outHeight) / s > 4096) s *= 2
            var bmp = BitmapFactory.decodeFile(file.path, BitmapFactory.Options().apply { inSampleSize = s })
                ?: run { toast("Decode failed"); return }
            val m = Matrix()
            when (orient) {
                ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
                ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
                ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
                ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            }
            if (!m.isIdentity) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)

            if (portrait) bmp = portraitBlur(bmp)
            if (flt != null) bmp = applyFilter(bmp, flt)
            saveBitmap(bmp)
            toast("Photo saved to Pictures/PortraitCam")
        } catch (e: Exception) {
            toast("Processing failed: ${e.message}")
        } finally {
            file.delete()
        }
    }

    private fun portraitBlur(src: Bitmap): Bitmap {
        // 1) segment the person on a small copy (fast)
        val sc = 768f / max(src.width, src.height)
        val small = Bitmap.createScaledBitmap(src, (src.width * sc).toInt(), (src.height * sc).toInt(), true)
        val seg = Segmentation.getClient(
            SelfieSegmenterOptions.Builder().setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE).build()
        )
        val res = try { Tasks.await(seg.process(InputImage.fromBitmap(small, 0))) } finally { seg.close() }
        val mw = res.width; val mh = res.height
        val buf = res.buffer; buf.rewind()
        val bytes = ByteArray(mw * mh)
        var sum = 0L
        for (i in bytes.indices) {
            val c = buf.float
            val t = ((c - 0.3f) / 0.4f).coerceIn(0f, 1f)
            val v = (t * t * (3f - 2f * t) * 255f).toInt()   // smoothstep for soft edges
            bytes[i] = v.toByte(); sum += v
        }
        if (sum / bytes.size < 8) { toast("No person found – saved without blur"); return src }
        val mask = Bitmap.createBitmap(mw, mh, Bitmap.Config.ALPHA_8)
        mask.copyPixelsFromBuffer(ByteBuffer.wrap(bytes))
        val maskFull = Bitmap.createScaledBitmap(mask, src.width, src.height, true)

        // 2) blurred background
        val blurred = blurBackground(src, small)

        // 3) sharp subject on top
        val subject = src.copy(Bitmap.Config.ARGB_8888, true)
        Canvas(subject).drawBitmap(maskFull, 0f, 0f, Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) })
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawBitmap(blurred, 0f, 0f, null)
        c.drawBitmap(subject, 0f, 0f, null)
        return out
    }

    private fun blurBackground(src: Bitmap, small768: Bitmap): Bitmap {
        val sc = 900f / max(src.width, src.height)
        val w = (src.width * sc).toInt(); val h = (src.height * sc).toInt()
        val s = Bitmap.createScaledBitmap(src, w, h, true)
        val r = 3 + blurStrength * 20 / 100
        val px = IntArray(w * h); s.getPixels(px, 0, w, 0, 0, w, h)
        val tmp = IntArray(w * h)
        repeat(2) {
            pass(px, tmp, w, h, 1, w, r)    // horizontal
            pass(tmp, px, h, w, w, 1, r)    // vertical
        }
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        b.setPixels(px, 0, w, 0, 0, w, h)
        return Bitmap.createScaledBitmap(b, src.width, src.height, true)
    }

    /** One box-blur pass over `lines` lines of `n` pixels. */
    private fun pass(s: IntArray, d: IntArray, n: Int, lines: Int, step: Int, lineStep: Int, r: Int) {
        val div = 2 * r + 1
        for (l in 0 until lines) {
            val base = l * lineStep
            var ra = 0; var ga = 0; var ba = 0
            for (k in -r..r) {
                val p = s[base + k.coerceIn(0, n - 1) * step]
                ra += (p shr 16) and 255; ga += (p shr 8) and 255; ba += p and 255
            }
            for (i in 0 until n) {
                d[base + i * step] = (0xFF shl 24) or ((ra / div) shl 16) or ((ga / div) shl 8) or (ba / div)
                val add = s[base + (i + r + 1).coerceAtMost(n - 1) * step]
                val rem = s[base + (i - r).coerceAtLeast(0) * step]
                ra += ((add shr 16) and 255) - ((rem shr 16) and 255)
                ga += ((add shr 8) and 255) - ((rem shr 8) and 255)
                ba += (add and 255) - (rem and 255)
            }
        }
    }

    private fun applyFilter(src: Bitmap, m: ColorMatrix): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        Canvas(out).drawBitmap(src, 0f, 0f, Paint().apply { colorFilter = ColorMatrixColorFilter(m) })
        return out
    }

    // ---------------------------------------------------------------- Saving

    private fun newImageUri() = contentResolver.insert(
        MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
        ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "IMG_${System.currentTimeMillis()}.jpg")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/PortraitCam")
        }
    )

    private fun saveBitmap(b: Bitmap) {
        val uri = newImageUri() ?: return
        contentResolver.openOutputStream(uri)?.use { b.compress(Bitmap.CompressFormat.JPEG, 97, it) }
    }

    private fun saveFile(f: File) {
        val uri = newImageUri() ?: return
        contentResolver.openOutputStream(uri)?.use { out -> f.inputStream().use { it.copyTo(out) } }
    }
}
