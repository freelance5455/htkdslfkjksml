/* craft B — Owner Admin: service worker (offline shell + notifications) */
const CACHE='craftb-admin-v1';
const SHELL=['./','./index.html','./manifest.json','./css/app.css','./js/firebase_config.js','./js/util.js','./js/db.js','./js/auth.js','./js/store.js','./js/ui.js','./js/main.js','./icons/icon-192.png','./icons/icon-512.png'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(SHELL)).then(()=>self.skipWaiting()));});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));});
self.addEventListener('fetch',e=>{
  const u=new URL(e.request.url);
  if(e.request.method!=='GET'||u.origin!==location.origin)return; /* Firebase and other hosts: always network */
  e.respondWith(fetch(e.request).then(r=>{const cp=r.clone();caches.open(CACHE).then(c=>c.put(e.request,cp));return r;}).catch(()=>caches.match(e.request).then(r=>r||caches.match('./index.html'))));
});
self.addEventListener('notificationclick',e=>{
  e.notification.close();
  e.waitUntil(self.clients.matchAll({type:'window',includeUncontrolled:true}).then(cs=>{
    for(const c of cs){if('focus' in c){c.postMessage({type:'open',tab:(e.notification.data&&e.notification.data.tab)||'orders'});return c.focus();}}
    return self.clients.openWindow('./index.html#'+((e.notification.data&&e.notification.data.tab)||'orders'));
  }));
});
