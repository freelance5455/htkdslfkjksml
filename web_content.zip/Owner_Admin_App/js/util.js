/* أدوات مساعدة */
const $=id=>document.getElementById(id);
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=n=>(Math.round(+n||0)).toLocaleString('ar-EG-u-nu-latn');
const fmtDT=n=>(Math.round((+n||0)*10)/10).toLocaleString('ar-EG-u-nu-latn')+' DT';
const startOfDay=()=>{const d=new Date();d.setHours(0,0,0,0);return d.getTime();};
function ago(t){
  if(!t)return 'غير معروف';const s=Math.max(0,(Date.now()-t)/1000);
  if(s<60)return 'قبل لحظات';if(s<3600)return 'منذ '+Math.floor(s/60)+' د';
  if(s<86400)return 'منذ '+Math.floor(s/3600)+' س';return 'منذ '+Math.floor(s/86400)+' يوم';
}
function hm(sec){sec=Math.floor(+sec||0);const h=Math.floor(sec/3600),m=Math.floor(sec%3600/60);return (h?h+' ساعة ':'')+m+' دقيقة';}
function timeStr(t){const d=new Date(t);return d.toLocaleTimeString('ar-EG-u-nu-latn',{hour:'2-digit',minute:'2-digit'})+' · '+d.toLocaleDateString('ar-EG-u-nu-latn',{day:'numeric',month:'short'});}
async function sha256(s){
  try{const b=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s));return Array.from(new Uint8Array(b)).map(x=>x.toString(16).padStart(2,'0')).join('');}
  catch(e){let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}return 'f'+(h>>>0).toString(36);}
}
async function copyText(t){
  try{await navigator.clipboard.writeText(t);return true;}catch(e){}
  try{const a=document.createElement('textarea');a.value=t;a.style.cssText='position:fixed;opacity:0';document.body.appendChild(a);a.select();const ok=document.execCommand('copy');a.remove();return ok;}catch(e){return false;}
}
function toast(msg,kind){
  const d=document.createElement('div');d.className='toast '+(kind||'');d.textContent=msg;$('toasts').appendChild(d);
  setTimeout(()=>d.classList.add('out'),3600);setTimeout(()=>d.remove(),4100);
}
/* أسماء الشخصيات في اللعبة */
const SKIN_N={explorer:'المستكشف',farmer:'المزارع',knight:'الفارس',ninja:'النينجا',wizard:'الساحر',pirate:'القرصان',alien:'الفضائي',robot:'الروبوت',astronaut:'رائد الفضاء',vampire:'مصاص الدماء',king:'الملك',samurai:'الساموراي',cyber:'السايبورغ',phoenix:'العنقاء (سرية)'};
/* ===== الصوت: رنين مميز للطلبات + نغمات خفيفة للتنبيهات ===== */
const Snd={ctx:null,on:true,
  unlock(){try{if(!this.ctx)this.ctx=new (window.AudioContext||window.webkitAudioContext)();if(this.ctx.state==='suspended')this.ctx.resume();}catch(e){}},
  tone(f,t0,d,type,vol){if(!this.ctx||!this.on)return;const c=this.ctx,o=c.createOscillator(),g=c.createGain();o.type=type||'sine';o.frequency.value=f;g.gain.setValueAtTime(0.0001,c.currentTime+t0);g.gain.exponentialRampToValueAtTime(vol||.2,c.currentTime+t0+.02);g.gain.exponentialRampToValueAtTime(.0001,c.currentTime+t0+d);o.connect(g);g.connect(c.destination);o.start(c.currentTime+t0);o.stop(c.currentTime+t0+d+.05);},
  order(){for(let i=0;i<3;i++){this.tone(1046,i*.55,.16,'triangle',.28);this.tone(1318,i*.55+.17,.16,'triangle',.28);this.tone(1568,i*.55+.34,.2,'triangle',.28);}try{navigator.vibrate&&navigator.vibrate([250,100,250,100,400]);}catch(e){}},
  alert(){this.tone(740,0,.12,'sine',.2);this.tone(988,.14,.18,'sine',.2);try{navigator.vibrate&&navigator.vibrate(120);}catch(e){}},
  warn(){this.tone(220,0,.25,'sawtooth',.14);this.tone(165,.26,.3,'sawtooth',.14);try{navigator.vibrate&&navigator.vibrate([200,80,200]);}catch(e){}}
};
