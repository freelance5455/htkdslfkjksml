/* مربوط مسبقاً باللعبة. root = اسم سري للقناة. لا تشاركه. */
window.FIREBASE_CONFIG={relay:"https://ntfy.sh",root:"g29cfd1206f5620d0280feb8f0f7d5e987ae8a890",databaseURL:"",apiKey:""};
window.OWNER={email:"",pinHash:""};
