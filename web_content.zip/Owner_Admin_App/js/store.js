/* ============================================================
   المخزن: يشترك ببث Firebase اللحظي ويشتق الإحصائيات والتنبيهات
   مسارات قاعدة البيانات (نفس ما تكتبه اللعبة):
     saves/{token}                 حفظ سحابي للاعب (الاسم، العملات، الشخصيات، وقت اللعب)
     telemetry/{token}/status      الحالة الحية (online/offline، الطور، آخر نبضة)
     telemetry/{token}/events/*    الأحداث (login, register, start, mode_big, secret, boss, coin_tamper, order, bonus, quest)
     orders/{id}                   طلبات الشحن
     players/{token}/bonus|ack|ban|adjust   أوامر المالك إلى اللاعب
     lb/hidden/{token}             إخفاء من لوحة المتصدرين
   ============================================================ */
const ONLINE_MS=75000;
const EV_TEXT={
  login:(n)=>n+' فتح اللعبة',
  register:(n)=>n+' أنشأ حساباً جديداً ودخل اللعبة',
  start:(n,i)=>n+' بدأ عالماً ('+(i||'')+')',
  mode_big:(n,i)=>n+' دخل طور The big'+(i?' — كوكب '+i:''),
  secret:(n,i)=>i==='phoenix'?n+' أدخل كود الشخصية السرية (العنقاء)':n+' أدخل كود طور The big السري',
  secret_fail:(n)=>n+' أدخل رمزاً سرياً خاطئاً',
  coin_tamper:(n)=>'تنبيه: '+n+' — محاولة تعديل غير شرعي للعملات',
  order:(n,i)=>n+' أرسل طلب شحن '+i+' عملة',
  bonus:(n,i)=>n+' استلم '+i+' عملة من المالك',
  quest:(n,i)=>n+' أنهى مهمة ('+i+')',
  boss:(n,i)=>n+' هزم زعيماً ('+i+')'
};
const EV_CAT={login:'login',register:'login',start:'login',mode_big:'secret',secret:'secret',secret_fail:'warn',coin_tamper:'warn',order:'order',bonus:'order',quest:'login',boss:'secret'};
const ALERT_TYPES={register:'info',secret:'info',boss:'info',coin_tamper:'warn',mode_big:'quiet'};

const Store={
  tel:{},saves:{},orders:{},plr:{},lb:{},
  got:{},primed:false,seenEv:new Set(),seenOrd:new Set(),
  streams:[],connOk:{},onChange:null,onOrder:null,onAlert:null,
  start(){
    const map={telemetry:'tel',saves:'saves',orders:'orders',players:'plr',lb:'lb'};
    this.stop();
    for(const path in map){
      const key=map[path];
      this.streams.push(DB.stream(path,tree=>{
        this[key]=tree||{};this.got[key]=true;this.detect();this.schedule();
      },(p,ok,why)=>{this.connOk[p]=ok;this.schedule(true);}));
    }
    setTimeout(()=>{if(!this.primed){this.primed=true;this.detect(true);}},7000);
  },
  stop(){for(const s of this.streams)try{s.close();}catch(e){}this.streams=[];this.got={};this.primed=false;this.seenEv.clear();this.seenOrd.clear();},
  _t:null,
  schedule(){clearTimeout(this._t);this._t=setTimeout(()=>this.onChange&&this.onChange(),150);},
  conn(){const v=Object.values(this.connOk);return v.length&&v.every(Boolean);},
  detect(force){
    if(!this.primed&&this.got.tel&&this.got.orders){
      /* أول لقطة: سجّل كل ما هو موجود دون تنبيه */
      for(const id in this.orders)this.seenOrd.add(id);
      for(const tk in this.tel){const ev=(this.tel[tk]||{}).events||{};for(const id in ev)this.seenEv.add(tk+'/'+id);}
      this.primed=true;return;
    }
    if(!this.primed)return;
    for(const id in this.orders){
      if(this.seenOrd.has(id))continue;this.seenOrd.add(id);
      const o=this.orders[id];if(o&&o.status==='new'&&this.onOrder)this.onOrder(id,o);
    }
    for(const tk in this.tel){
      const ev=(this.tel[tk]||{}).events||{};
      for(const id in ev){
        const k=tk+'/'+id;if(this.seenEv.has(k))continue;this.seenEv.add(k);
        const e=ev[id];if(!e||!ALERT_TYPES[e.type])continue;
        if(e.type==='secret_fail')continue;
        this.onAlert&&this.onAlert(tk,e,ALERT_TYPES[e.type]);
      }
    }
  },
  nameOf(tk,e){return (e&&e.n)||((this.tel[tk]||{}).status||{}).name||(this.saves[tk]||{}).name||tk;},
  isOnline(s){return !!(s&&s.state==='online'&&Date.now()-(s.t||0)<ONLINE_MS);},
  phoneOf(tk){let best=null;for(const id in this.orders){const o=this.orders[id];if(o&&o.token===tk&&(!best||o.t>best.t))best=o;}return best;},
  players(){
    const tks=new Set([...Object.keys(this.saves),...Object.keys(this.tel)]);const out=[];
    for(const tk of tks){
      const sv=this.saves[tk]||{},st=(this.tel[tk]||{}).status||{},od=this.phoneOf(tk),pl=this.players_(tk);
      out.push({token:tk,name:sv.name||st.name||tk,coins:(sv.coins!=null?sv.coins:st.coins)||0,owned:sv.owned||[],skin:sv.skin||'',playSec:Math.max(sv.playSec||0,st.playSec||0),
        online:this.isOnline(st),mode:st.mode||'',last:Math.max(st.t||0,sv.t||0),phone:od?od.phone:'',social:od?(od.platform+': '+od.handle):'',banned:pl.ban===true,hidden:!!((this.lb.hidden||{})[tk])});
    }
    return out;
  },
  players_(tk){return this.plr[tk]||{};},
  stats(){
    const sod=startOfDay();let on=0,mo={online:0,offline:0,big:0};const today=new Set();
    const all=new Set([...Object.keys(this.saves),...Object.keys(this.tel)]);
    for(const tk of all){
      const t=this.tel[tk]||{},st=t.status||{};
      if(this.isOnline(st)){on++;const m=st.mode==='big'?'big':(st.mode==='online'?'online':'offline');mo[m]++;}
      if((st.t||0)>=sod)today.add(tk);
      const ev=t.events||{};for(const id in ev){const e=ev[id];if(e&&e.t>=sod&&(e.type==='login'||e.type==='register'||e.type==='start'))today.add(tk);}
    }
    let rev=0,pend=0,pendCoins=0;
    for(const id in this.orders){const o=this.orders[id];if(!o)continue;if(o.status==='done')rev+=+o.priceDT||0;else if(o.status==='new'){pend++;pendCoins+=+o.coins||0;}}
    return {online:on,modes:mo,today:today.size,total:all.size,revenue:rev,pending:pend,pendingCoins:pendCoins};
  },
  feed(limit){
    const out=[];
    for(const tk in this.tel){const ev=(this.tel[tk]||{}).events||{};for(const id in ev){const e=ev[id];if(e&&e.type)out.push({id:tk+'/'+id,tk,t:e.t||0,type:e.type,info:e.info,n:this.nameOf(tk,e)});}}
    out.sort((a,b)=>b.t-a.t);return out.slice(0,limit||150);
  },
  text(f){const fn=EV_TEXT[f.type];return fn?fn(f.n,f.info):f.n+' — '+f.type+(f.info?' ('+f.info+')':'');}
};

/* ===== أوامر المالك إلى اللاعب ===== */
const Cmd={
  uid(p){return p+Date.now().toString(36)+Math.random().toString(36).slice(2,6);},
  /* شحن عملات: يدمج مع مكافأة سابقة لم يستلمها اللاعب بعد حتى لا تضيع */
  async credit(token,coins,msg){
    coins=Math.floor(+coins);if(!token||!(coins>0)||coins>1e6)throw new Error('قيمة غير صالحة (1 – 1,000,000)');
    const pl=(await DB.get('players/'+token))||{};let add=coins,m=msg||'';
    if(pl.bonus&&pl.bonus.id&&pl.bonus.id!==pl.ack&&+pl.bonus.coins>0){add+=+pl.bonus.coins;m=(pl.bonus.msg?pl.bonus.msg+' + ':'')+m;}
    if(add>1e6)throw new Error('الرصيد المعلّق تجاوز الحد، انتظر استلام اللاعب أولاً');
    await DB.put('players/'+token+'/bonus',{id:this.uid('b'),coins:add,msg:m.slice(0,120),t:Date.now()});
    return add;
  },
  async confirmOrder(id){
    const o=await DB.get('orders/'+id);
    if(!o)throw new Error('الطلب غير موجود');if(o.status!=='new')throw new Error('تمت معالجة هذا الطلب مسبقاً');
    if(!o.token)throw new Error('الطلب بلا رمز حساب، لا يمكن الشحن تلقائياً');
    await DB.patch('orders/'+id,{status:'done',doneAt:Date.now()});
    try{await this.credit(o.token,o.coins,'تم شحن باقتك ('+o.coins+' عملة). شكراً لك!');}
    catch(e){await DB.patch('orders/'+id,{status:'new',doneAt:null});throw e;}
    return o;
  },
  rejectOrder(id){return DB.patch('orders/'+id,{status:'rejected',doneAt:Date.now()});},
  deleteOrder(id){return DB.del('orders/'+id);},
  ban(token,on){return on?DB.put('players/'+token+'/ban',true):DB.del('players/'+token+'/ban');},
  setCoins(token,n){n=Math.max(0,Math.min(1e7,Math.floor(+n)));if(!isFinite(n))throw new Error('رقم غير صالح');return DB.put('players/'+token+'/adjust',{id:this.uid('a'),set:n,t:Date.now()});},
  hideLb(token,on){return on?DB.put('lb/hidden/'+token,true):DB.del('lb/hidden/'+token);}
};
