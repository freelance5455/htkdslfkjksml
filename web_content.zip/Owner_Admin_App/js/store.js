/* ============================================================
   المخزن: يشترك ببث Firebase اللحظي ويشتق الإحصائيات والتنبيهات
   مسارات قاعدة البيانات (نفس ما تكتبه اللعبة):
     saves/{token}                 حفظ سحابي للاعب (الاسم، العملات، الشخصيات، وقت اللعب)
     telemetry/{token}/status      الحالة الحية (online/offline، الطور، آخر نبضة)
     telemetry/{token}/events/*    الأحداث (login, register, start, mode_big, secret, boss, coin_tamper, order, bonus, quest)
     orders/{id}                   طلبات الشحن
     players/{token}/bonus|ack|ban|adjust   أوامر المالك إلى اللاعب
     lb/hidden/{token}             إخفاء من لوحة المتصدرين
   ============================================================ */
const ONLINE_MS=75000;
const EV_TEXT={
  code:(n,i)=>n+' فعّل كود هدية',
  login:(n)=>n+' فتح اللعبة',
  register:(n)=>n+' أنشأ حساباً جديداً ودخل اللعبة',
  start:(n,i)=>n+' بدأ عالماً ('+(i||'')+')',
  mode_big:(n,i)=>n+' دخل طور The big'+(i?' — كوكب '+i:''),
  secret:(n,i)=>i==='phoenix'?n+' أدخل كود الشخصية السرية (العنقاء)':n+' أدخل كود طور The big السري',
  secret_fail:(n)=>n+' أدخل رمزاً سرياً خاطئاً',
  coin_tamper:(n)=>'تنبيه: '+n+' — محاولة تعديل غير شرعي للعملات',
  order:(n,i)=>n+' أرسل طلب شحن '+(/^\d+$/.test(String(i))?i+' عملة':String(i).startsWith('g')&&/^g\d+$/.test(String(i))?String(i).slice(1)+' جوهرة':i),
  season:(n,i)=>n+' وصل إلى مستوى الموسم '+String(i).slice(1),
  seasonclaim:(n,i)=>n+' استلم جائزة الموسم '+String(i).slice(1),
  ach:(n,i)=>n+' فتح إنجازاً ('+i+')',
  streak:(n,i)=>n+' استلم جائزة السلسلة (يوم '+String(i).slice(1)+')',
  challenge:(n,i)=>n+' أكمل التحدي اليومي ('+i+')',
  evtclaim:(n,i)=>n+' استلم هدية الإعلان ('+i+')',
  pet:(n,i)=>n+' اشترى رفيقاً ('+i+')',
  legend:(n,i)=>n+' حصل على سلاح أسطوري ('+i+')',
  giftsend:(n,i)=>n+' أرسل هدية: '+i,
  spin:(n,i)=>n+' لفّ عجلة الحظ ('+i+')',
  gchest:(n,i)=>n+' فتح صندوق جواهر ('+i+')',
  daily:(n,i)=>n+' استلم جائزة المسار اليومي ('+i+')',
  buy:(n,i)=>n+' اشترى ('+(SKIN_N[i]||i)+')',
  bonus:(n,i)=>n+' استلم '+(/^\d+$/.test(String(i))?i+' عملة':i)+' من المالك',
  quest:(n,i)=>n+' أنهى مهمة ('+i+')',
  boss:(n,i)=>n+' هزم زعيماً ('+i+')'
};
const EV_CAT={pet:'login',legend:'secret',giftsend:'login',login:'login',register:'login',start:'login',mode_big:'secret',secret:'secret',secret_fail:'warn',coin_tamper:'warn',order:'order',bonus:'order',quest:'login',boss:'secret',spin:'login',gchest:'login',season:'login',seasonclaim:'login',ach:'login',streak:'login',challenge:'login',evtclaim:'login',daily:'login',buy:'login'};
const ALERT_TYPES={register:'info',secret:'info',boss:'info',coin_tamper:'warn',mode_big:'quiet'};

const Store={
  tel:{},saves:{},orders:{},plr:{},lb:{},over:{},
  got:{},primed:false,seenEv:new Set(),seenOrd:new Set(),
  streams:[],connOk:{},onChange:null,onOrder:null,onAlert:null,
  start(){
    const map={telemetry:'tel',saves:'saves',orders:'orders',players:'plr',lb:'lb'};
    this.stop();
    for(const path in map){
      const key=map[path];
      this.streams.push(DB.stream(path,tree=>{
        this[key]=tree||{};this.got[key]=true;this.detect();this.schedule();
      },(p,ok,why)=>{this.connOk[p]=ok;this.schedule(true);}));
    }
    setTimeout(()=>{if(!this.primed){this.primed=true;this.detect(true);}},7000);
  },
  stop(){for(const s of this.streams)try{s.close();}catch(e){}this.streams=[];this.got={};this.primed=false;this.seenEv.clear();this.seenOrd.clear();},
  _t:null,
  schedule(){clearTimeout(this._t);this._t=setTimeout(()=>this.onChange&&this.onChange(),150);},
  conn(){const v=Object.values(this.connOk);return v.length&&v.every(Boolean);},
  detect(force){
    if(!this.primed&&this.got.tel&&this.got.orders){
      /* أول لقطة: سجّل كل ما هو موجود دون تنبيه */
      for(const id in this.orders)this.seenOrd.add(id);
      for(const tk in this.tel){const ev=(this.tel[tk]||{}).events||{};for(const id in ev)this.seenEv.add(tk+'/'+id);}
      this.primed=true;return;
    }
    if(!this.primed)return;
    for(const id in this.orders){
      if(this.seenOrd.has(id))continue;this.seenOrd.add(id);
      const o=this.orders[id];if(o&&o.status==='new'&&this.onOrder)this.onOrder(id,o);
    }
    for(const tk in this.tel){
      const ev=(this.tel[tk]||{}).events||{};
      for(const id in ev){
        const k=tk+'/'+id;if(this.seenEv.has(k))continue;this.seenEv.add(k);
        const e=ev[id];if(!e||!ALERT_TYPES[e.type])continue;
        if(e.type==='secret_fail')continue;
        this.onAlert&&this.onAlert(tk,e,ALERT_TYPES[e.type]);
      }
    }
  },
  nameOf(tk,e){return (e&&e.n)||((this.tel[tk]||{}).status||{}).name||(this.saves[tk]||{}).name||tk;},
  isOnline(s){return !!(s&&s.state==='online'&&Date.now()-(s.t||0)<ONLINE_MS);},
  phoneOf(tk){let best=null;for(const id in this.orders){const o=this.orders[id];if(o&&o.token===tk&&(!best||o.t>best.t))best=o;}return best;},
  players(){
    const tks=new Set([...Object.keys(this.saves),...Object.keys(this.tel)]);const out=[];
    for(const tk of tks){
      if((this.plr[tk]||{}).ban===true||this.over['ban:'+tk])continue;
      const sv=this.saves[tk]||{},st=(this.tel[tk]||{}).status||{},od=this.phoneOf(tk),pl=this.players_(tk);
      out.push({token:tk,name:sv.name||st.name||tk,coins:this.ov(tk,'coins',(sv.coins!=null?sv.coins:st.coins)||0,sv,st),gems:this.ov(tk,'gems',(sv.gems!=null?sv.gems:st.gems)||0,sv,st),owned:sv.owned||[],skin:sv.skin||'',playSec:Math.max(sv.playSec||0,st.playSec||0),
        online:this.isOnline(st),mode:st.mode||'',last:Math.max(st.t||0,sv.t||0),phone:od?od.phone:'',social:od?(od.platform+': '+od.handle):'',banned:pl.ban===true,hidden:!!((this.lb.hidden||{})[tk])});
    }
    return out;
  },
  ov(tk,f,v,sv,st){const o=this.over[tk+':'+f];if(o&&Math.max(sv.t||0,st.t||0)<=o.t)return o.v;if(o)delete this.over[tk+':'+f];return v;},
  players_(tk){return this.plr[tk]||{};},
  stats(){
    const sod=startOfDay();let on=0,mo={online:0,offline:0,big:0};const today=new Set();
    const all=new Set([...Object.keys(this.saves),...Object.keys(this.tel)]);
    for(const tk of all){
      if((this.plr[tk]||{}).ban===true||this.over['ban:'+tk])continue;
      const t=this.tel[tk]||{},st=t.status||{};
      if(this.isOnline(st)){on++;const m=st.mode==='big'?'big':(st.mode==='online'?'online':'offline');mo[m]++;}
      if((st.t||0)>=sod)today.add(tk);
      const ev=t.events||{};for(const id in ev){const e=ev[id];if(e&&e.t>=sod&&(e.type==='login'||e.type==='register'||e.type==='start'))today.add(tk);}
    }
    let rev=0,pend=0,pendCoins=0;
    for(const id in this.orders){const o=this.orders[id];if(!o)continue;if(o.status==='done')rev+=+o.priceDT||0;else if(o.status==='new'){pend++;pendCoins+=+o.coins||0;}}
    return {online:on,modes:mo,today:today.size,total:all.size,revenue:rev,pending:pend,pendingCoins:pendCoins};
  },
  feed(limit){
    const out=[];
    for(const tk in this.tel){const ev=(this.tel[tk]||{}).events||{};for(const id in ev){const e=ev[id];if(e&&e.type){if((this.plr[tk]||{}).ban===true)continue;out.push({id:tk+'/'+id,tk,t:e.t||0,type:e.type,info:e.info,m:e.m,n:this.nameOf(tk,e)});}}}
    out.sort((a,b)=>b.t-a.t);return out.slice(0,limit||150);
  },
  text(f){const fn=EV_TEXT[f.type];const MA={online:'أونلاين',offline:'أوفلاين',big:'The big'};const tail=f.m&&MA[f.m]?' ['+MA[f.m]+']':'';return (fn?fn(f.n,f.info):f.n+' — '+f.type+(f.info?' ('+f.info+')':''))+tail;}
};

/* ===== أوامر المالك إلى اللاعب ===== */
const Cmd={
  uid(p){return p+Date.now().toString(36)+Math.random().toString(36).slice(2,6);},
  /* شحن عملات: يدمج مع مكافأة سابقة لم يستلمها اللاعب بعد حتى لا تضيع */
  async credit(token,coins,msg,gems,extra){
    coins=Math.floor(+coins||0);gems=Math.floor(+gems||0);const ex=extra||{};const vip=Math.max(0,Math.min(365,Math.floor(+ex.vip||0)));const skin=/^[a-z0-9_]{1,24}$/i.test(ex.skin||'')?ex.skin:'';
    if(!token||!(coins>0||gems>0||vip>0||skin||String(msg||'').trim())||coins>1e6||gems>1e5||coins<0||gems<0)throw new Error('قيمة غير صالحة (عملات 1 – 1,000,000 · جواهر 1 – 100,000)');
    const pl=(await DB.get('players/'+token))||{};let add=coins,ag=gems,m=msg||'',v=vip,sk=skin;
    if(pl.bonus&&pl.bonus.id&&pl.bonus.id!==pl.ack){add+=+pl.bonus.coins||0;ag+=+pl.bonus.gems||0;v+=+pl.bonus.vip||0;if(pl.bonus.skin){if(sk&&sk!==pl.bonus.skin)throw new Error('عند اللاعب سكن معلّق لم يستلمه بعد، انتظر استلامه');sk=pl.bonus.skin;}m=(pl.bonus.msg?pl.bonus.msg+' + ':'')+m;}
    if(add>1e6||ag>1e5)throw new Error('الرصيد المعلّق تجاوز الحد، انتظر استلام اللاعب أولاً');
    const b={id:this.uid('b'),coins:add,gems:ag,msg:m.slice(0,120),t:Date.now()};if(v>0)b.vip=Math.min(365,v);if(sk)b.skin=sk;
    await DB.put('players/'+token+'/bonus',b);
    return add;
  },
  async control(token,a,v,n){
    if(!token||!DB.relay)throw new Error('التحكم المباشر متاح في وضع القناة فقط');
    const okA=['give','take','clear','heal','hurt','kill','spawn','purge','tod','tp','freeze','god','fly','food','kick'];if(!okA.includes(a))throw new Error('أمر غير معروف');
    await DB.put('players/'+token+'/cmd',{id:this.uid('m'),a,v:String(v||''),n:Math.max(1,Math.min(999,Math.floor(+n||1))),t:Date.now()});return true;
  },
  async controlAll(a,v,n){
    if(!DB.relay)throw new Error('متاح في وضع القناة فقط');
    const ok=await DB.pubAll({k:'cmd',id:this.uid('m'),a,v:String(v||''),n:Math.max(1,Math.min(999,Math.floor(+n||1))),t:Date.now()});if(!ok)throw new Error('تعذّر الإرسال');return true;
  },
  giveSkin(token,skin){return this.credit(token,0,'هدية: شخصية جديدة من المالك!',0,{skin});},
  giveVip(token,days){return this.credit(token,0,'تم تفعيل VIP لحسابك',0,{vip:days});},
  message(token,text){return this.credit(token,0,String(text||'').trim().slice(0,120),0);},
  async boost(coinX,xpX,hours,label){
    if(!DB.relay)throw new Error('العروض متاحة في وضع القناة فقط');
    coinX=Math.max(1,Math.min(5,+coinX||1));xpX=Math.max(1,Math.min(5,+xpX||1));hours=Math.max(.25,Math.min(12,+hours||2));
    if(coinX<=1&&xpX<=1)throw new Error('اختر مضاعفاً أكبر من 1');
    const ok=await DB.pubAll({k:'boost',id:this.uid('x'),coinX,xpX,label:String(label||'').trim().slice(0,40)||'عرض خاص',until:Date.now()+hours*36e5});
    if(!ok)throw new Error('تعذّر الإرسال، تحقق من الاتصال');return true;
  },
  notes:{get(tk){try{return (JSON.parse(localStorage.getItem('adm_notes')||'{}')[tk])||'';}catch(e){return '';}},set(tk,t){try{const o=JSON.parse(localStorage.getItem('adm_notes')||'{}');if(t)o[tk]=String(t).slice(0,200);else delete o[tk];localStorage.setItem('adm_notes',JSON.stringify(o));}catch(e){}}},
  async confirmOrder(id){
    const o=await DB.get('orders/'+id);
    if(!o)throw new Error('الطلب غير موجود');if(o.status!=='new')throw new Error('تمت معالجة هذا الطلب مسبقاً');
    if(!o.token)throw new Error('الطلب بلا رمز حساب، لا يمكن الشحن تلقائياً');
    await DB.patch('orders/'+id,{status:'done',doneAt:Date.now()});
    try{await this.credit(o.token,o.coins||0,'تم شحن باقتك ('+(o.vip?'VIP '+o.vip+' يوم':o.gems?o.gems+' جوهرة':o.coins+' عملة')+'). شكراً لك!',o.gems||0,{vip:o.vip||0});}
    catch(e){await DB.patch('orders/'+id,{status:'new',doneAt:null});throw e;}
    return o;
  },
  rejectOrder(id){return DB.patch('orders/'+id,{status:'rejected',doneAt:Date.now()});},
  deleteOrder(id){return DB.del('orders/'+id);},
  ban(token,on){if(on)Store.over['ban:'+token]={v:1,t:Date.now()};else delete Store.over['ban:'+token];Store.schedule();return on?DB.put('players/'+token+'/ban',true):DB.del('players/'+token+'/ban');},
  setCoins(token,n,g){n=Math.max(0,Math.min(1e7,Math.floor(+n)));if(!isFinite(n))throw new Error('رقم غير صالح');
    const o={id:this.uid('a'),set:n,t:Date.now()};Store.over[token+':coins']={v:n,t:Date.now()};
    if(g!=null){const gg=Math.max(0,Math.min(1e6,Math.floor(+g)));if(!isFinite(gg))throw new Error('رقم غير صالح');o.gset=gg;Store.over[token+':gems']={v:gg,t:Date.now()};}
    Store.schedule();return DB.put('players/'+token+'/adjust',o);},
  async announce(title,msg,coins,gems,hours){
    if(!DB.relay)throw new Error('الإعلانات متاحة في وضع القناة فقط');
    title=String(title||'').trim().slice(0,40);msg=String(msg||'').trim().slice(0,160);coins=Math.max(0,Math.min(1e5,Math.floor(+coins||0)));gems=Math.max(0,Math.min(1e3,Math.floor(+gems||0)));hours=Math.max(1,Math.min(12,+hours||6));
    if(!title)throw new Error('اكتب عنواناً');
    const ok=await DB.pubAll({k:'evt',id:this.uid('e'),title,msg,coins,gems,until:Date.now()+hours*36e5});
    if(!ok)throw new Error('تعذّر الإرسال، تحقق من الاتصال');return true;
  },
  hideLb(token,on){return on?DB.put('lb/hidden/'+token,true):DB.del('lb/hidden/'+token);}
};
