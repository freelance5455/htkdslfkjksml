/* ============================================================
   الواجهة: البطاقات والقوائم والنوافذ
   ============================================================ */
const UI={
  tab:'home',filter:'all',alerts:[],unread:0,
  icon:{coin:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7v10M9 9.500h4.500a1.500 1.500 0 0 1 0 3H10a1.500 1.500 0 0 0 0 3h5" fill="none" stroke="#0b1020" stroke-width="1.700"/></svg>'},
  /* ---------- نافذة ---------- */
  sheet(html,mount){const m=$('modal');$('sheet').innerHTML=html;m.hidden=false;document.body.classList.add('noscroll');if(mount)mount($('sheet'));},
  close(){$('modal').hidden=true;$('sheet').innerHTML='';document.body.classList.remove('noscroll');},
  confirm(title,body,okTxt,danger){
    return new Promise(res=>{
      this.sheet('<h3>'+esc(title)+'</h3><div class="body">'+body+'</div><div class="row"><button class="btn '+(danger?'danger':'primary')+'" id="cfOk">'+esc(okTxt||'تأكيد')+'</button><button class="btn" id="cfNo">إلغاء</button></div>',s=>{
        $('cfOk').onclick=()=>{this.close();res(true);};$('cfNo').onclick=()=>{this.close();res(false);};
      });
    });
  },
  /* ---------- الرئيسية ---------- */
  renderHome(){
    const s=Store.stats(),m=s.modes;
    $('cards').innerHTML=
     '<article class="card live"><div class="ct"><span class="pulse"></span>المتصلون الآن</div><div class="big">'+fmt(s.online)+'</div><div class="sub3"><span>أونلاين <b>'+m.online+'</b></span><span>أوفلاين <b>'+m.offline+'</b></span><span>The big <b>'+m.big+'</b></span></div></article>'+
     '<article class="card"><div class="ct">زيارات اليوم</div><div class="big">'+fmt(s.today)+'</div><div class="sub3"><span>إجمالي الحسابات <b>'+fmt(s.total)+'</b></span></div></article>'+
     '<article class="card gold"><div class="ct">إجمالي الأرباح</div><div class="big">'+fmtDT(s.revenue)+'</div><div class="sub3"><span>من الطلبات المؤكدة</span></div></article>'+
     '<article class="card '+(s.pending?'alertc':'')+'" data-go="orders"><div class="ct">طلبات الشحن المعلّقة</div><div class="big">'+fmt(s.pending)+'</div><div class="sub3"><span>'+fmt(s.pendingCoins)+' عملة بانتظارك</span></div></article>';
    for(const c of $('cards').querySelectorAll('[data-go]'))c.onclick=()=>this.go(c.dataset.go);
    this.feedInto($('feedMini'),8,'all');
  },
  feedInto(el,limit,filter){
    let f=Store.feed(300);if(filter!=='all')f=f.filter(x=>(EV_CAT[x.type]||'login')===filter);f=f.slice(0,limit);
    if(!f.length){el.innerHTML='<div class="empty">لا توجد أحداث بعد. ستظهر هنا لحظة حدوثها داخل اللعبة.</div>';return;}
    el.innerHTML=f.map(x=>'<div class="fi '+(EV_CAT[x.type]||'')+'"><i></i><div><div class="ft">'+esc(Store.text(x))+'</div><div class="fd">'+esc(timeStr(x.t))+' · '+esc(ago(x.t))+'</div></div></div>').join('');
  },
  /* ---------- الطلبات ---------- */
  orderCard(id,o,done){
    const st=o.status;
    return '<article class="ord '+st+'"><div class="oh"><b>'+esc(o.name||'—')+'</b><span class="tag '+st+'">'+(st==='new'?'جديد':st==='done'?'مؤكد':'مرفوض')+'</span></div>'+
      '<div class="og"><div><small>الباقة</small><b>'+fmt(o.coins)+' عملة</b></div><div><small>السعر</small><b>'+fmtDT(o.priceDT)+'</b></div>'+
      '<div><small>الحساب</small><b>'+esc(o.account||'—')+'</b></div><div><small>رمز الحساب</small><b dir="ltr">'+esc(o.token||'—')+'</b></div>'+
      '<div><small>الهاتف</small><b dir="ltr">'+esc(o.phone||'—')+'</b></div><div><small>'+esc(o.platform||'التواصل')+'</small><b dir="ltr">'+esc(o.handle||'—')+'</b></div></div>'+
      '<div class="muted">'+esc(timeStr(o.t))+' · '+esc(ago(o.t))+'</div>'+
      '<div class="row wrap"><button class="btn sm" data-cp="'+esc(o.handle||'')+'">نسخ الحساب</button><button class="btn sm" data-cp="'+esc(o.phone||'')+'">نسخ الرقم</button>'+
      (st==='new'?'<button class="btn primary sm" data-ok="'+id+'">تأكيد وشحن الباقة</button><button class="btn danger sm" data-no="'+id+'">رفض</button>':'')+
      (st==='rejected'?'<button class="btn danger sm" data-del="'+id+'">حذف نهائي</button>':'')+'</div></article>';
  },
  renderOrders(){
    const ids=Object.keys(Store.orders),pend=ids.filter(i=>Store.orders[i]&&Store.orders[i].status==='new').sort((a,b)=>Store.orders[b].t-Store.orders[a].t);
    const done=ids.filter(i=>Store.orders[i]&&Store.orders[i].status!=='new').sort((a,b)=>(Store.orders[b].doneAt||Store.orders[b].t)-(Store.orders[a].doneAt||Store.orders[a].t)).slice(0,15);
    $('pendN').textContent=pend.length;
    $('pendList').innerHTML=pend.length?pend.map(i=>this.orderCard(i,Store.orders[i])).join(''):'<div class="empty">لا توجد طلبات معلّقة.</div>';
    $('doneList').innerHTML=done.length?done.map(i=>this.orderCard(i,Store.orders[i])).join(''):'<div class="empty">لا توجد طلبات سابقة.</div>';
    const n=$('navOrd');n.hidden=!pend.length;n.textContent=pend.length;
    for(const b of document.querySelectorAll('[data-cp]'))b.onclick=async()=>{toast(await copyText(b.dataset.cp)?'تم النسخ':'تعذّر النسخ','ok');};
    for(const b of document.querySelectorAll('[data-ok]'))b.onclick=()=>this.doConfirm(b.dataset.ok);
    for(const b of document.querySelectorAll('[data-no]'))b.onclick=()=>this.doReject(b.dataset.no);
    for(const b of document.querySelectorAll('[data-del]'))b.onclick=async()=>{if(await this.confirm('حذف الطلب نهائياً؟','سيُحذف السجل من قاعدة البيانات.','حذف',true)){try{await Cmd.deleteOrder(b.dataset.del);toast('تم الحذف','ok');}catch(e){toast('فشل: '+e.message,'bad');}}};
  },
  async doConfirm(id){
    const o=Store.orders[id];if(!o)return;
    const ok=await this.confirm('تأكيد وشحن الباقة','<p>هل استلمت المبلغ <b>'+fmtDT(o.priceDT)+'</b> من <b>'+esc(o.name)+'</b>؟</p><p>سيُضاف <b>'+fmt(o.coins)+'</b> عملة إلى حساب <b>'+esc(o.account||'')+'</b> فوراً ويُسجَّل المبلغ ضمن أرباحك.</p>','نعم، استلمت — اشحن الآن');
    if(!ok)return;
    try{await Cmd.confirmOrder(id);toast('تم الشحن وإضافة المبلغ للأرباح','ok');$('orderPop').hidden=true;}catch(e){toast('تعذّر الشحن: '+e.message,'bad');}
  },
  async doReject(id){
    const o=Store.orders[id];if(!o)return;
    if(await this.confirm('رفض الطلب؟','<p>سيُوسَم طلب <b>'+esc(o.name)+'</b> كمرفوض ولن تُضاف عملات.</p>','رفض الطلب',true)){try{await Cmd.rejectOrder(id);toast('تم رفض الطلب','ok');$('orderPop').hidden=true;}catch(e){toast('فشل: '+e.message,'bad');}}
  },
  /* ---------- اللاعبون ---------- */
  renderPlayers(){
    const q=($('q').value||'').trim().toLowerCase();let L=Store.players();
    L.sort((a,b)=>(b.online-a.online)||(b.last-a.last));
    if(q)L=L.filter(p=>p.name.toLowerCase().includes(q)||p.token.toLowerCase().includes(q)||(p.phone||'').replace(/\s/g,'').includes(q.replace(/\s/g,''))||(p.social||'').toLowerCase().includes(q));
    $('plCount').textContent=L.length+' لاعب';
    $('plList').innerHTML=L.length?L.slice(0,150).map(p=>'<article class="pl'+(p.banned?' banned':'')+'"><div class="ph"><span class="st '+(p.online?'on':'off')+'"></span><b>'+esc(p.name)+'</b>'+(p.banned?'<span class="tag rejected">محظور</span>':'')+'<span class="muted">'+(p.online?'متصل الآن'+(p.mode?' · '+({online:'أونلاين',offline:'أوفلاين',big:'The big'}[p.mode]||''):''):'آخر ظهور '+esc(ago(p.last)))+'</span></div>'+
      '<div class="og"><div><small>الرصيد</small><b>'+fmt(p.coins)+' عملة</b></div><div><small>وقت اللعب</small><b>'+esc(hm(p.playSec))+'</b></div>'+
      '<div class="w2"><small>رمز الاسترجاع</small><b dir="ltr">'+esc(p.token)+'</b></div>'+(p.phone?'<div><small>الهاتف</small><b dir="ltr">'+esc(p.phone)+'</b></div><div><small>التواصل</small><b dir="ltr">'+esc(p.social)+'</b></div>':'')+
      '<div class="w2"><small>الشخصيات ('+p.owned.length+')</small><b>'+(p.owned.map(x=>esc(SKIN_N[x]||x)).join('، ')||'—')+'</b></div></div>'+
      '<div class="row wrap"><button class="btn gold sm" data-send="'+esc(p.token)+'">شحن عملات (Send Coins)</button><button class="btn sm '+(p.banned?'':'danger')+'" data-ban="'+esc(p.token)+'">'+(p.banned?'فك الحظر':'حظر')+'</button><button class="btn sm" data-cp="'+esc(p.token)+'">نسخ الرمز</button></div></article>').join(''):'<div class="empty">لا يوجد لاعبون مطابقون.</div>';
    for(const b of document.querySelectorAll('#plList [data-cp]'))b.onclick=async()=>{toast(await copyText(b.dataset.cp)?'تم النسخ':'تعذّر النسخ','ok');};
    for(const b of document.querySelectorAll('[data-send]'))b.onclick=()=>this.sendCoins(b.dataset.send);
    for(const b of document.querySelectorAll('[data-ban]'))b.onclick=()=>this.toggleBan(b.dataset.ban);
  },
  sendCoins(tk){
    const p=Store.players().find(x=>x.token===tk);if(!p)return;
    this.sheet('<h3>شحن عملات لـ '+esc(p.name)+'</h3><div class="body"><label>عدد العملات<input id="scN" type="number" inputmode="numeric" min="1" max="1000000" placeholder="مثال: 500" dir="ltr"></label><div class="chips" id="scQ">'+[500,1000,2000,5000,12000].map(n=>'<button class="chip" data-n="'+n+'">'+fmt(n)+'</button>').join('')+'</div><label>رسالة للاعب (اختياري)<input id="scM" maxlength="100" placeholder="تظهر له مع التهنئة"></label><div class="muted">تصل العملات للاعب فور اتصاله ويظهر رصيده المحدّث لحظياً.</div></div><div class="row"><button class="btn primary" id="scGo">إرسال العملات الآن</button><button class="btn" id="scNo">إلغاء</button></div>',s=>{
      for(const c of s.querySelectorAll('#scQ .chip'))c.onclick=()=>{$('scN').value=c.dataset.n;};
      $('scNo').onclick=()=>this.close();
      $('scGo').onclick=async()=>{const n=Math.floor(+$('scN').value);if(!(n>0)||n>1e6){toast('أدخل عدداً بين 1 و 1,000,000','bad');return;}
        $('scGo').disabled=true;try{const add=await Cmd.credit(tk,n,$('scM').value.trim()||'هدية من المالك');this.close();toast('تم إرسال '+fmt(n)+' عملة إلى '+p.name+(add>n?' (مجموع المعلّق '+fmt(add)+')':''),'ok');}catch(e){$('scGo').disabled=false;toast('تعذّر الإرسال: '+e.message,'bad');}};
      setTimeout(()=>$('scN').focus(),50);
    });
  },
  async toggleBan(tk){
    const p=Store.players().find(x=>x.token===tk);if(!p)return;const on=!p.banned;
    if(await this.confirm(on?'حظر اللاعب؟':'فك الحظر؟','<p>'+(on?'سيُطرد <b>'+esc(p.name)+'</b> فوراً من اللعبة ولن يستطيع الدخول.':'سيتمكن <b>'+esc(p.name)+'</b> من اللعب مجدداً.')+'</p>',on?'حظر':'فك الحظر',on)){
      try{await Cmd.ban(tk,on);toast(on?'تم الحظر':'تم فك الحظر','ok');}catch(e){toast('فشل: '+e.message,'bad');}}
  },
  /* ---------- السجل ---------- */
  renderFeed(){
    const cats=[['all','الكل'],['order','الطلبات'],['login','الدخول'],['secret','الأكواد السرية'],['warn','تحذيرات']];
    $('feedFilter').innerHTML=cats.map(c=>'<button class="chip'+(this.filter===c[0]?' on':'')+'" data-f="'+c[0]+'">'+c[1]+'</button>').join('');
    for(const b of $('feedFilter').querySelectorAll('.chip'))b.onclick=()=>{this.filter=b.dataset.f;this.renderFeed();};
    this.feedInto($('feed'),150,this.filter);
  },
  /* ---------- المتصدرون ---------- */
  renderLb(){
    const showH=$('lbHidden').checked;let L=Store.players().filter(p=>showH||!p.hidden).sort((a,b)=>b.coins-a.coins).slice(0,25);
    $('lbList').innerHTML=L.length?L.map((p,i)=>'<article class="pl lb'+(p.hidden?' banned':'')+'"><div class="ph"><span class="rank">'+(i+1)+'</span><b>'+esc(p.name)+'</b>'+(p.hidden?'<span class="tag rejected">مخفي</span>':'')+'<span class="muted">'+fmt(p.coins)+' عملة · '+esc(hm(p.playSec))+'</span></div><div class="row wrap"><button class="btn sm" data-hide="'+esc(p.token)+'">'+(p.hidden?'إظهار في اللوحة':'إخفاء من اللوحة')+'</button><button class="btn sm" data-edit="'+esc(p.token)+'">تعديل الرصيد</button><button class="btn danger sm" data-zero="'+esc(p.token)+'">تصفير الرصيد</button></div></article>').join(''):'<div class="empty">لا يوجد لاعبون.</div>';
    for(const b of document.querySelectorAll('[data-hide]'))b.onclick=async()=>{const p=Store.players().find(x=>x.token===b.dataset.hide);try{await Cmd.hideLb(p.token,!p.hidden);toast(p.hidden?'أُظهر في اللوحة':'أُخفي من اللوحة','ok');}catch(e){toast('فشل: '+e.message,'bad');}};
    for(const b of document.querySelectorAll('[data-zero]'))b.onclick=async()=>{const p=Store.players().find(x=>x.token===b.dataset.zero);if(await this.confirm('تصفير رصيد '+p.name+'؟','<p>سيصبح رصيده 0 داخل اللعبة فور اتصاله.</p>','تصفير',true)){try{await Cmd.setCoins(p.token,0);toast('أُرسل أمر التصفير','ok');}catch(e){toast('فشل: '+e.message,'bad');}}};
    for(const b of document.querySelectorAll('[data-edit]'))b.onclick=()=>{const p=Store.players().find(x=>x.token===b.dataset.edit);
      this.sheet('<h3>تعديل رصيد '+esc(p.name)+'</h3><div class="body"><label>الرصيد الجديد<input id="edN" type="number" inputmode="numeric" min="0" dir="ltr" value="'+Math.floor(p.coins)+'"></label></div><div class="row"><button class="btn primary" id="edGo">حفظ</button><button class="btn" id="edNo">إلغاء</button></div>',s=>{$('edNo').onclick=()=>this.close();$('edGo').onclick=async()=>{try{await Cmd.setCoins(p.token,$('edN').value);this.close();toast('أُرسل التعديل للاعب','ok');}catch(e){toast('فشل: '+e.message,'bad');}};});};
  },
  /* ---------- تنبيهات ---------- */
  pushAlert(title,body,kind,tab){
    this.alerts.unshift({t:Date.now(),title,body,kind,tab});this.alerts=this.alerts.slice(0,40);this.unread++;this.bell();
    toast(title+(body?' — '+body:''),kind==='warn'?'bad':'ok');
    if(kind==='warn')Snd.warn();else if(kind!=='quiet')Snd.alert();
    this.sys(title,body,tab,kind);
  },
  bell(){const b=$('bellN');b.hidden=!this.unread;b.textContent=this.unread;},
  showOrder(id,o){
    this.unread++;this.bell();Snd.order();
    $('orderPopCard').innerHTML='<div class="ringHead"><span class="ringIc"></span><h3>طلب شحن جديد!</h3></div><div class="og big2"><div><small>اللاعب</small><b>'+esc(o.name)+'</b></div><div><small>الباقة</small><b>'+fmt(o.coins)+' عملة</b></div><div><small>السعر</small><b>'+fmtDT(o.priceDT)+'</b></div><div><small>الهاتف</small><b dir="ltr">'+esc(o.phone)+'</b></div><div class="w2"><small>'+esc(o.platform||'التواصل')+'</small><b dir="ltr">'+esc(o.handle)+'</b></div></div><div class="row wrap"><button class="btn sm" data-cp="'+esc(o.handle||'')+'">نسخ الحساب</button><button class="btn sm" data-cp="'+esc(o.phone||'')+'">نسخ الرقم</button></div><div class="row"><button class="btn primary" id="opOk">تأكيد وشحن</button><button class="btn danger" id="opNo">رفض</button><button class="btn" id="opX">لاحقاً</button></div>';
    $('orderPop').hidden=false;
    for(const b of $('orderPopCard').querySelectorAll('[data-cp]'))b.onclick=async()=>{toast(await copyText(b.dataset.cp)?'تم النسخ':'تعذّر النسخ','ok');};
    $('opOk').onclick=()=>this.doConfirm(id);$('opNo').onclick=()=>this.doReject(id);$('opX').onclick=()=>{$('orderPop').hidden=true;};
    this.sys('طلب شحن جديد',o.name+' — '+fmt(o.coins)+' عملة ('+fmtDT(o.priceDT)+')','orders','order');
  },
  async sys(title,body,tab,kind){
    try{if(!('Notification' in window)||Notification.permission!=='granted'||!document.hidden)return;
      const reg=await navigator.serviceWorker.getRegistration();const opt={body:body||'',icon:'icons/icon-192.png',badge:'icons/icon-192.png',dir:'rtl',lang:'ar',tag:kind+'-'+Date.now(),vibrate:[200,100,200],data:{tab},requireInteraction:kind==='order'};
      if(reg)reg.showNotification(title,opt);else new Notification(title,opt);}catch(e){}
  },
  showBell(){
    this.unread=0;this.bell();
    const perm=('Notification' in window)?Notification.permission:'unsupported';
    this.sheet('<h3>الإشعارات</h3><div class="body"><div class="muted">'+(perm==='granted'?'إشعارات النظام مفعّلة (تظهر عندما يكون التطبيق في الخلفية وهو مفتوح).':perm==='denied'?'إشعارات النظام محظورة من إعدادات المتصفح.':perm==='unsupported'?'متصفحك لا يدعم إشعارات النظام.':'فعّل إشعارات النظام لتصلك التنبيهات حتى والتطبيق في الخلفية.')+'</div>'+(perm==='default'?'<button class="btn primary" id="nfOn">تفعيل إشعارات النظام</button>':'')+
      '<div class="feed">'+(this.alerts.length?this.alerts.map(a=>'<div class="fi '+(a.kind==='warn'?'warn':a.kind==='order'?'order':'secret')+'"><i></i><div><div class="ft">'+esc(a.title)+(a.body?' — '+esc(a.body):'')+'</div><div class="fd">'+esc(ago(a.t))+'</div></div></div>').join(''):'<div class="empty">لا توجد تنبيهات في هذه الجلسة.</div>')+'</div></div><div class="row"><button class="btn" id="nfX">إغلاق</button></div>',s=>{
      $('nfX').onclick=()=>this.close();const b=$('nfOn');if(b)b.onclick=async()=>{try{await Notification.requestPermission();}catch(e){}this.showBell();};});
  },
  showSettings(){
    this.sheet('<h3>الإعدادات</h3><div class="body"><label class="chk"><input type="checkbox" id="stSnd" '+(Snd.on?'checked':'')+'> <span>الصوت والاهتزاز للتنبيهات</span></label><button class="btn sm" id="stTest">تجربة رنين طلب الشحن</button><div class="muted">الاتصال: '+(LIVE?'قاعدة بيانات حقيقية':'وضع تجريبي (بيانات وهمية)')+' · الحماية: '+(Auth.mode==='firebase'?'Firebase Authentication':'رمز PIN محلي')+'</div><button class="btn sm" id="stInst" hidden>تثبيت التطبيق على الشاشة الرئيسية</button><button class="btn sm" id="stPin" '+(Auth.mode==='pin'?'':'hidden')+'>تغيير رمز PIN</button></div><div class="row"><button class="btn danger" id="stOut">تسجيل الخروج</button><button class="btn" id="stX">إغلاق</button></div>',s=>{
      $('stSnd').onchange=e=>{Snd.on=e.target.checked;try{localStorage.setItem('adm_snd',Snd.on?'1':'0');}catch(x){}};
      $('stTest').onclick=()=>{Snd.unlock();Snd.order();};$('stX').onclick=()=>this.close();$('stOut').onclick=()=>{this.close();App.logout();};
      if(App.deferred){$('stInst').hidden=false;$('stInst').onclick=async()=>{App.deferred.prompt();App.deferred=null;this.close();};}
      $('stPin').onclick=()=>{this.close();App.changePin();};
    });
  },
  /* ---------- تنقّل ---------- */
  go(tab){
    this.tab=tab;for(const t of document.querySelectorAll('.tab'))t.classList.toggle('on',t.id==='tab-'+tab);
    for(const b of $('bar').querySelectorAll('button'))b.classList.toggle('on',b.dataset.tab===tab);
    try{history.replaceState(null,'','#'+tab);}catch(e){}
    this.render();window.scrollTo(0,0);
  },
  render(){
    const t=this.tab;
    this.renderOrdersBadge();
    if(t==='home')this.renderHome();else if(t==='orders')this.renderOrders();else if(t==='players')this.renderPlayers();else if(t==='feed')this.renderFeed();else if(t==='lb')this.renderLb();
    const ok=Store.conn();$('connDot').className='dot '+(ok?'ok':'bad');$('connTxt').textContent=ok?'متصل لحظياً':(LIVE?'غير متصل — إعادة المحاولة…':'وضع تجريبي');
  },
  renderOrdersBadge(){let n=0;for(const id in Store.orders)if(Store.orders[id]&&Store.orders[id].status==='new')n++;const b=$('navOrd');b.hidden=!n;b.textContent=n;}
};
