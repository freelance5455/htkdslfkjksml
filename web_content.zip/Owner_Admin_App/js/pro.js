/* ============================================================
   أدوات المالك المتقدمة — سجل ميزات (تقارير + إجراءات + إعدادات)
   كل ميزة: {c:القسم, n:الاسم, d:وصف قصير, run:()=>...}
   ============================================================ */
const LS={
  get(k,d){try{const v=localStorage.getItem(k);return v==null?d:JSON.parse(v);}catch(e){return d;}},
  set(k,v){try{localStorage.setItem(k,JSON.stringify(v));}catch(e){}}
};
const PL=()=>Store.players();
const OR=()=>Object.keys(Store.orders||{}).map(id=>Object.assign({id},Store.orders[id])).filter(o=>o&&o.status);
const DONE=()=>OR().filter(o=>o.status==='done');
const DAY=864e5;
const sum=(a,f)=>a.reduce((s,x)=>s+(+f(x)||0),0);
const dkey=t=>{const d=new Date(t);return d.getFullYear()+'-'+(d.getMonth()+1)+'-'+d.getDate();};
const kv=(rows)=>'<div class="body">'+rows.map(r=>'<div class="w2" style="display:flex;justify-content:space-between;gap:8px;padding:6px 0;border-bottom:1px solid var(--line)"><small>'+esc(r[0])+'</small><b>'+(r[2]?r[1]:esc(r[1]))+'</b></div>').join('')+'</div>';
const bars=(items,unit)=>{const mx=Math.max(1,...items.map(i=>i[1]));return '<div class="body">'+items.map(i=>'<div style="display:flex;align-items:center;gap:8px;margin:4px 0"><small style="width:74px;flex:none">'+esc(i[0])+'</small><div style="flex:1;background:rgba(255,255,255,.07);border-radius:6px;height:16px"><div style="width:'+Math.round(i[1]/mx*100)+'%;height:100%;border-radius:6px;background:linear-gradient(90deg,var(--ac),var(--ac2))"></div></div><b style="min-width:54px;text-align:left">'+esc(String(Math.round(i[1]*10)/10))+(unit||'')+'</b></div>').join('')+'</div>';};
const plist=(arr,extra)=>arr.length?'<div class="body">'+arr.slice(0,60).map(p=>'<div style="padding:6px 0;border-bottom:1px solid var(--line);display:flex;justify-content:space-between;gap:8px"><b>'+esc(p.name)+'</b><small>'+(extra?esc(extra(p)):'')+'</small></div>').join('')+(arr.length>60?'<div class="muted">… و'+(arr.length-60)+' آخرين</div>':'')+'</div>':'<div class="body muted">لا يوجد</div>';
const csvOf=rows=>'﻿'+rows.map(r=>r.map(c=>'"'+String(c==null?'':c).replace(/"/g,'""')+'"').join(',')).join('\n');
const pick=a=>a[Math.floor(Math.random()*a.length)];
const nm=tk=>{const p=PL().find(x=>x.token===tk);return p?p.name:tk;};

/* ---------- سجل الإجراءات + الحماية (يغلّف أوامر المالك) ---------- */
const Audit={
  list(){return LS.get('adm_log',[]);},
  add(t){const l=this.list();l.push({t:Date.now(),x:String(t).slice(0,140)});LS.set('adm_log',l.slice(-300));},
  clear(){LS.set('adm_log',[]);}
};
const Guard={
  ro(){return LS.get('adm_ro',false);},
  cap(){return +LS.get('adm_cap',0)||0;},
  spent(){const d=LS.get('adm_spent',{d:'',n:0});return d.d===dkey(Date.now())?d.n:0;},
  addSpent(n){LS.set('adm_spent',{d:dkey(Date.now()),n:this.spent()+n});}
};
(function wrap(){
  const names={control:'تحكم مباشر',controlAll:'تحكم بكل المتصلين',credit:'هدية/رسالة',ban:'حظر',setCoins:'تعديل رصيد',announce:'إعلان',boost:'عرض مضاعفة',confirmOrder:'تأكيد طلب',rejectOrder:'رفض طلب',deleteOrder:'حذف طلب'};
  for(const k in names){
    const f=Cmd[k];if(typeof f!=='function')continue;
    Cmd[k]=function(...a){
      if(Guard.ro())throw new Error('وضع القراءة فقط مفعّل — أوقفه من تبويب الأدوات');
      if(k==='credit'){const n=(+a[1]||0);const cap=Guard.cap();if(cap&&Guard.spent()+n>cap)throw new Error('تجاوزت الحد اليومي للهدايا ('+fmt(cap)+' عملة)');}
      const r=f.apply(Cmd,a);
      const done=()=>{Audit.add(names[k]+(a[0]&&typeof a[0]==='string'&&a[0].length<30?' · '+nm(a[0]):''));if(k==='credit')Guard.addSpent(+a[1]||0);};
      if(r&&r.then)return r.then(v=>{done();return v;});done();return r;
    };
  }
})();

/* ---------- إرسال جماعي ---------- */
async function bulk(list,coins,gems,msg,vip,label){
  list=list.slice(0,200);
  if(!list.length){toast('لا يوجد لاعبون مطابقون','bad');return;}
  const tot=list.length*(coins||0);
  const ok=await UI.confirm('إرسال جماعي','سيصل '+list.length+' لاعباً: '+(coins?fmt(coins)+' عملة ':'')+(gems?fmt(gems)+' جوهرة ':'')+(vip?'VIP '+vip+' يوم ':'')+(msg?'· «'+msg+'»':'')+(tot?' (المجموع '+fmt(tot)+' عملة)':''),'إرسال',false);
  if(!ok)return;
  let n=0,bad=0;
  for(const p of list){try{await Cmd.credit(p.token,coins||0,msg||'',gems||0,{vip:vip||0});n++;}catch(e){bad++;if(/القراءة فقط|الحد اليومي/.test(e.message)){toast(e.message,'bad');break;}}}
  toast('أُرسل إلى '+n+(bad?' · فشل '+bad:''),bad?'bad':'ok');
}
const ask=(title,fields,go)=>{ // fields: [{id,label,type,value,opts}]
  const h='<h3>'+esc(title)+'</h3><div class="body">'+fields.map(f=>f.opts?'<label>'+esc(f.label)+'<select id="pa_'+f.id+'">'+f.opts.map(o=>'<option value="'+esc(o[0])+'">'+esc(o[1])+'</option>').join('')+'</select></label>':'<label>'+esc(f.label)+'<input id="pa_'+f.id+'" type="'+(f.type||'text')+'" value="'+esc(f.value==null?'':f.value)+'" '+(f.type==='number'?'inputmode="numeric" dir="ltr"':'')+'></label>').join('')+'</div><div class="row"><button class="btn primary" id="pa_go">تنفيذ</button><button class="btn" id="pa_no">إلغاء</button></div>';
  UI.sheet(h,()=>{$('pa_no').onclick=()=>UI.close();$('pa_go').onclick=async()=>{const v={};for(const f of fields)v[f.id]=$('pa_'+f.id).value;$('pa_go').disabled=true;try{UI.close();await go(v);}catch(e){toast(e.message,'bad');}};});
};
const out=(title,html,copy)=>{
  UI.sheet('<h3>'+esc(title)+'</h3>'+html+'<div class="row">'+(copy?'<button class="btn" id="po_cp">نسخ</button>':'')+'<button class="btn primary" id="po_x">إغلاق</button></div>',()=>{$('po_x').onclick=()=>UI.close();if(copy)$('po_cp').onclick=async()=>{toast(await copyText(copy)?'تم النسخ':'تعذّر النسخ');};});
};
const dl=(name,text)=>{copyText(text).then(ok=>toast(ok?'نُسخ '+name+' إلى الحافظة':'تعذّر النسخ','ok'));};
const STAT=o=>o.status==='done'?'منتهٍ':o.status==='new'?'معلّق':o.status==='rejected'?'مرفوض':o.status;

/* ---------- المؤقّتات (تعمل ما دام التطبيق مفتوحاً) ---------- */
const Timers={list:[],add(ms,label,fn){const t={id:Cmd.uid('t'),at:Date.now()+ms,label,h:setTimeout(async()=>{try{await fn();toast('نُفّذ: '+label,'ok');}catch(e){toast('فشل '+label+': '+e.message,'bad');}this.list=this.list.filter(x=>x.id!==t.id);},ms)};this.list.push(t);}};

/* ---------- الميزات ---------- */
const F=[];
const add=(c,n,d,run)=>F.push({c,n,d,run});
const A='تحليلات',B='لاعبون',C='جماعي',D='عروض',E='طلبات',G='أمان',H='مظهر';

/* ===== تحليلات ===== */
const revBy=days=>{const m={};const now=Date.now();for(let i=days-1;i>=0;i--)m[dkey(now-i*DAY)]=0;for(const o of DONE()){const k=dkey(o.doneAt||o.t);if(k in m)m[k]+=+o.priceDT||0;}return Object.entries(m).map(([k,v])=>[k.split('-').slice(1).join('/'),v]);};
add(A,'إيراد اليوم','مجموع الطلبات المنتهية اليوم',()=>{const s=startOfDay();const a=DONE().filter(o=>(o.doneAt||o.t)>=s);out('إيراد اليوم',kv([['الطلبات',a.length],['الإيراد',fmtDT(sum(a,o=>o.priceDT))]]));});
add(A,'إيراد 7 أيام','رسم أعمدة',()=>out('آخر 7 أيام',bars(revBy(7),' DT')));
add(A,'إيراد 30 يوماً','رسم أعمدة',()=>out('آخر 30 يوماً',bars(revBy(30),' DT')));
add(A,'إجمالي الإيراد','منذ البداية',()=>out('إجمالي الإيراد',kv([['الطلبات المنتهية',DONE().length],['الإيراد',fmtDT(sum(DONE(),o=>o.priceDT))]])));
add(A,'متوسط قيمة الطلب','',()=>{const d=DONE();out('متوسط الطلب',kv([['المتوسط',fmtDT(d.length?sum(d,o=>o.priceDT)/d.length:0)],['الأكبر',fmtDT(Math.max(0,...d.map(o=>+o.priceDT||0)))],['الأصغر',fmtDT(d.length?Math.min(...d.map(o=>+o.priceDT||0)):0)]]));});
add(A,'أعلى المنفقين','حسب الإنفاق الفعلي',()=>{const m={};for(const o of DONE())m[o.token]=(m[o.token]||0)+(+o.priceDT||0);out('أعلى المنفقين',bars(Object.entries(m).sort((a,b)=>b[1]-a[1]).slice(0,10).map(([t,v])=>[nm(t),v]),' DT'));});
add(A,'نسبة التحويل','مشترون ÷ لاعبون',()=>{const buyers=new Set(DONE().map(o=>o.token)).size,t=PL().length;out('التحويل',kv([['اللاعبون',t],['المشترون',buyers],['النسبة',(t?Math.round(buyers/t*1000)/10:0)+'%']]));});
add(A,'قيمة الطلبات المعلّقة','',()=>{const a=OR().filter(o=>o.status==='new');out('المعلّق',kv([['العدد',a.length],['القيمة',fmtDT(sum(a,o=>o.priceDT))]]));});
add(A,'الطلبات حسب المنصة','',()=>{const m={};for(const o of OR())m[o.platform||'?']=(m[o.platform||'?']||0)+1;out('المنصات',bars(Object.entries(m).sort((a,b)=>b[1]-a[1])));});
add(A,'الطلبات حسب الباقة','عملات / جواهر / VIP',()=>{const m={'عملات':0,'جواهر':0,'VIP':0};for(const o of OR()){if(+o.vip>0)m.VIP++;else if(+o.gems>0&&!(+o.coins>0))m['جواهر']++;else m['عملات']++;}out('الباقات',bars(Object.entries(m)));});
add(A,'نسبة الرفض','',()=>{const a=OR(),r=a.filter(o=>o.status==='rejected').length;out('الرفض',kv([['الكل',a.length],['المرفوضة',r],['النسبة',(a.length?Math.round(r/a.length*1000)/10:0)+'%']]));});
add(A,'ساعة الذروة للطلبات','',()=>{const h=Array(24).fill(0);for(const o of OR())h[new Date(o.t).getHours()]++;out('الطلبات حسب الساعة',bars(h.map((v,i)=>[i+':00',v]).filter(x=>x[1]>0)));});
add(A,'المتصلون الآن','',()=>{const a=PL().filter(p=>p.online);out('المتصلون ('+a.length+')',plist(a,p=>p.mode||''));});
add(A,'نشطون آخر 24 ساعة','',()=>{const a=PL().filter(p=>Date.now()-p.last<DAY);out('نشطون 24 ساعة ('+a.length+')',plist(a,p=>ago(p.last)));});
add(A,'نشطون آخر 7 أيام','',()=>{const a=PL().filter(p=>Date.now()-p.last<7*DAY);out('نشطون 7 أيام ('+a.length+')',plist(a,p=>ago(p.last)));});
add(A,'غير نشطين +7 أيام','مرشّحون لحملة عودة',()=>{const a=PL().filter(p=>Date.now()-p.last>=7*DAY);out('غير نشطين ('+a.length+')',plist(a,p=>ago(p.last)));});
add(A,'متوسط وقت اللعب','',()=>{const a=PL();const t=sum(a,p=>p.playSec);out('وقت اللعب',kv([['المتوسط',hm(a.length?t/a.length:0)],['الإجمالي',hm(t)]]));});
add(A,'إجمالي العملات في الاقتصاد','',()=>out('الاقتصاد',kv([['العملات',fmt(sum(PL(),p=>p.coins))],['الجواهر',fmt(sum(PL(),p=>p.gems))],['متوسط العملات',fmt(PL().length?sum(PL(),p=>p.coins)/PL().length:0)]])));
add(A,'الأغنى (أعلى 10)','',()=>out('الأغنى',plist([...PL()].sort((a,b)=>b.coins-a.coins).slice(0,10),p=>fmt(p.coins)+' عملة')));
add(A,'شعبية الشخصيات','الأكثر امتلاكاً',()=>{const m={};for(const p of PL())for(const s of p.owned)m[s]=(m[s]||0)+1;out('الشخصيات',bars(Object.entries(m).sort((a,b)=>b[1]-a[1]).slice(0,12).map(([k,v])=>[SKIN_N[k]||k,v])));});
add(A,'نسبة امتلاك الشخصيات','',()=>{const t=PL().length||1;const m=PL().map(p=>p.owned.length);out('الامتلاك',kv([['المتوسط',(Math.round(sum(m,x=>x)/t*10)/10)+' لكل لاعب'],['الأعلى',Math.max(0,...m)],['بشخصية واحدة فقط',m.filter(x=>x<=1).length]]));});
add(A,'وسيط العملات','',()=>{const a=PL().map(p=>p.coins).sort((x,y)=>x-y);out('الوسيط',kv([['الوسيط',fmt(a.length?a[Math.floor(a.length/2)]:0)],['الأعلى',fmt(a[a.length-1]||0)]]));});
add(A,'توزيع الثروة','شرائح',()=>{const b=[['<100',0],['100-1k',0],['1k-10k',0],['10k-100k',0],['>100k',0]];for(const p of PL()){const c=p.coins;b[c<100?0:c<1e3?1:c<1e4?2:c<1e5?3:4][1]++;}out('الثروة',bars(b));});
add(A,'آخر ظهور (توزيع)','',()=>{const b=[['<1س',0],['1-24س',0],['1-3 أيام',0],['3-7 أيام',0],['+7 أيام',0]];for(const p of PL()){const d=Date.now()-p.last;b[d<36e5?0:d<DAY?1:d<3*DAY?2:d<7*DAY?3:4][1]++;}out('آخر ظهور',bars(b));});
add(A,'سرعة إنجاز الطلبات','',()=>{const a=DONE().filter(o=>o.doneAt&&o.t);const v=a.map(o=>(o.doneAt-o.t)/6e4);out('زمن التنفيذ',kv([['المتوسط',(v.length?Math.round(sum(v,x=>x)/v.length):0)+' دقيقة'],['الأطول',Math.round(Math.max(0,...v))+' دقيقة']]));});
add(A,'أقدم طلب معلّق','',()=>{const a=OR().filter(o=>o.status==='new').sort((x,y)=>x.t-y.t);out('الأقدم',a.length?kv([['اللاعب',a[0].name],['منذ',ago(a[0].t)],['الباقة',pkg(a[0])]]):'<div class="body muted">لا يوجد معلّق</div>');});
add(A,'أكثر لاعب وقتاً','',()=>out('الأكثر لعباً',plist([...PL()].sort((a,b)=>b.playSec-a.playSec).slice(0,10),p=>hm(p.playSec))));
const dayText=()=>{const s=startOfDay(),st=Store.stats(),d=DONE().filter(o=>(o.doneAt||o.t)>=s);return 'ملخص '+new Date().toLocaleDateString('ar-EG-u-nu-latn')+'\nنشطون اليوم: '+st.today+'\nمتصلون الآن: '+st.online+'\nطلبات منتهية: '+d.length+'\nإيراد اليوم: '+fmtDT(sum(d,o=>o.priceDT))+'\nمعلّق: '+st.pending;};
add(A,'ملخص اليوم (نص)','جاهز للنسخ',()=>out('ملخص اليوم','<div class="body"><pre style="white-space:pre-wrap;margin:0">'+esc(dayText())+'</pre></div>',dayText()));
const weekText=()=>{const w=revBy(7);return 'تقرير أسبوعي\n'+w.map(x=>x[0]+': '+x[1]+' DT').join('\n')+'\nالمجموع: '+sum(w,x=>x[1])+' DT\nلاعبون: '+PL().length;};
add(A,'تقرير أسبوعي (نص)','جاهز للنسخ',()=>out('التقرير الأسبوعي','<div class="body"><pre style="white-space:pre-wrap;margin:0">'+esc(weekText())+'</pre></div>',weekText()));

/* ===== لاعبون ===== */
add(B,'المحظورون','مع رفع الحظر',()=>{const arr=Object.keys(Store.plr||{}).filter(t=>Store.plr[t]&&Store.plr[t].ban===true);out('المحظورون ('+arr.length+')','<div class="body">'+(arr.length?arr.map(t=>'<div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0"><b>'+esc(nm(t))+'</b><button class="btn sm" data-ub="'+esc(t)+'">رفع الحظر</button></div>').join(''):'<span class="muted">لا يوجد</span>')+'</div>');for(const b of document.querySelectorAll('[data-ub]'))b.onclick=async()=>{try{await Cmd.ban(b.dataset.ub,false);toast('رُفع الحظر','ok');b.disabled=true;}catch(e){toast(e.message,'bad');}};});
add(B,'قائمة VIP','',()=>out('VIP',plist(PL().filter(p=>(Store.saves[p.token]||{}).vip>Date.now()||(Store.saves[p.token]||{}).meta&&(Store.saves[p.token].meta.vip>Date.now())),p=>'')));
add(B,'الحيتان','أصحاب أكثر من 50 ألف عملة',()=>out('الحيتان',plist(PL().filter(p=>p.coins>=5e4).sort((a,b)=>b.coins-a.coins),p=>fmt(p.coins))));
add(B,'مشتبه بهم (غش)','رصيد ضخم + وقت لعب قصير',()=>out('مشتبه بهم',plist(PL().filter(p=>p.coins>1e5&&p.playSec<1800),p=>fmt(p.coins)+' · '+hm(p.playSec))));
add(B,'هواتف مكررة','حسابات متعددة لنفس الرقم',()=>{const m={};for(const o of OR()){if(!o.phone)continue;(m[o.phone]=m[o.phone]||new Set()).add(o.token);}const r=Object.entries(m).filter(([k,v])=>v.size>1);out('هواتف مكررة',r.length?'<div class="body">'+r.map(([k,v])=>'<div style="padding:6px 0"><b dir="ltr">'+esc(k)+'</b><br><small>'+[...v].map(nm).map(esc).join('، ')+'</small></div>').join('')+'</div>':'<div class="body muted">لا يوجد</div>');});
add(B,'بدون شخصيات مشتراة','',()=>out('بلا شراء',plist(PL().filter(p=>p.owned.length<=1),p=>fmt(p.coins))));
add(B,'لاعبون بلا طلبات شحن','',()=>{const s=new Set(OR().map(o=>o.token));out('بلا طلبات',plist(PL().filter(p=>!s.has(p.token)),p=>hm(p.playSec)));});
add(B,'المشترون السابقون','',()=>{const s=new Set(DONE().map(o=>o.token));out('المشترون',plist(PL().filter(p=>s.has(p.token)),p=>''));});
add(B,'المفضّلون ⭐','إدارة محلية',()=>{const f=LS.get('adm_fav',[]);out('المفضّلون',plist(PL().filter(p=>f.includes(p.token)),p=>fmt(p.coins))+'<div class="muted">أضف لاعباً من «نجمة» في أداة الوسوم</div>');});
add(B,'وسم/نجمة للاعب','تصنيف محلي',()=>ask('وسم لاعب',[{id:'t',label:'الرمز أو الاسم'},{id:'g',label:'الوسم',opts:[['fav','⭐ مفضّل'],['vip','👑 VIP'],['sus','⚠️ مشتبه'],['frd','🤝 صديق'],['none','إزالة']]}],v=>{const p=PL().find(x=>x.token===v.t||x.name===v.t);if(!p)throw new Error('لاعب غير موجود');const tags=LS.get('adm_tags',{});if(v.g==='none')delete tags[p.token];else tags[p.token]=v.g;LS.set('adm_tags',tags);const f=LS.get('adm_fav',[]).filter(x=>x!==p.token);if(v.g==='fav')f.push(p.token);LS.set('adm_fav',f);toast('تم','ok');}));
add(B,'كل الملاحظات','',()=>{const o=LS.get('adm_notes',{});const k=Object.keys(o);out('الملاحظات ('+k.length+')','<div class="body">'+(k.map(t=>'<div style="padding:6px 0;border-bottom:1px solid var(--line)"><b>'+esc(nm(t))+'</b><br><small>'+esc(o[t])+'</small></div>').join('')||'<span class="muted">لا توجد</span>')+'</div>');});
add(B,'مقارنة لاعبين','',()=>ask('مقارنة',[{id:'a',label:'اللاعب 1 (اسم/رمز)'},{id:'b',label:'اللاعب 2'}],v=>{const f=s=>PL().find(x=>x.token===s||x.name===s);const a=f(v.a),b=f(v.b);if(!a||!b)throw new Error('لم يُعثر على أحدهما');const r=(l,g)=>[l,g(a)+'  |  '+g(b)];out('مقارنة',kv([['',a.name+'  |  '+b.name],r('العملات',p=>fmt(p.coins)),r('الجواهر',p=>fmt(p.gems)),r('الشخصيات',p=>p.owned.length),r('وقت اللعب',p=>hm(p.playSec)),r('آخر ظهور',p=>ago(p.last))]));}));
add(B,'بطاقة لاعب كاملة','كل التفاصيل',()=>ask('بطاقة لاعب',[{id:'t',label:'الاسم أو الرمز'}],v=>{const p=PL().find(x=>x.token===v.t||x.name===v.t);if(!p)throw new Error('غير موجود');const od=OR().filter(o=>o.token===p.token);out(p.name,kv([['الرمز',p.token],['العملات',fmt(p.coins)],['الجواهر',fmt(p.gems)],['الشخصيات',p.owned.map(x=>SKIN_N[x]||x).join('، ')||'—'],['وقت اللعب',hm(p.playSec)],['آخر ظهور',ago(p.last)],['الحالة',p.online?'متصل':'غير متصل'],['الهاتف',p.phone||'—'],['حسابه',p.social||'—'],['طلبات الشحن',od.length],['الإنفاق',fmtDT(sum(od.filter(o=>o.status==='done'),o=>o.priceDT))]]));}));
add(B,'ترتيب بالجواهر','',()=>out('الأكثر جواهر',plist([...PL()].sort((a,b)=>b.gems-a.gems).slice(0,10),p=>fmt(p.gems))));
add(B,'ترتيب بعدد الشخصيات','',()=>out('الأكثر شخصيات',plist([...PL()].sort((a,b)=>b.owned.length-a.owned.length).slice(0,10),p=>p.owned.length)));
add(B,'تصدير اللاعبين CSV','ينسخ إلى الحافظة',()=>dl('اللاعبين',csvOf([['الاسم','الرمز','العملات','الجواهر','الشخصيات','وقت اللعب(ث)','آخر ظهور','الهاتف']].concat(PL().map(p=>[p.name,p.token,p.coins,p.gems,p.owned.length,p.playSec,new Date(p.last).toISOString(),p.phone])))));
add(B,'نسخ كل الرموز','',()=>dl('الرموز',PL().map(p=>p.name+'\t'+p.token).join('\n')));
add(B,'سحب فائز عشوائي','من كل اللاعبين',()=>{const p=pick(PL());if(!p){toast('لا يوجد لاعبون','bad');return;}out('الفائز 🎉','<div class="body" style="text-align:center;font-size:22px"><b>'+esc(p.name)+'</b></div>');});
add(B,'سحب فائز من المتصلين','',()=>{const p=pick(PL().filter(x=>x.online));if(!p){toast('لا يوجد متصلون','bad');return;}out('الفائز 🎉','<div class="body" style="text-align:center;font-size:22px"><b>'+esc(p.name)+'</b></div>');});
add(B,'جائزة أعلى 3 أغنياء','تُرسل مباشرة',()=>ask('جائزة المتصدرين',[{id:'c',label:'عملات لكل فائز',type:'number',value:500}],v=>bulk([...PL()].sort((a,b)=>b.coins-a.coins).slice(0,3),Math.floor(+v.c),0,'جائزة المتصدرين من المالك! 🏆')));
add(B,'جائزة أطول لعباً (3)','',()=>ask('جائزة الأكثر لعباً',[{id:'c',label:'عملات لكل فائز',type:'number',value:500}],v=>bulk([...PL()].sort((a,b)=>b.playSec-a.playSec).slice(0,3),Math.floor(+v.c),0,'جائزة أكثر اللاعبين وقتاً! ⏱️')));
add(B,'بحث متقدّم','عملات من/إلى',()=>ask('بحث متقدّم',[{id:'a',label:'عملات من',type:'number',value:0},{id:'b',label:'عملات إلى',type:'number',value:1000000},{id:'o',label:'الحالة',opts:[['all','الكل'],['on','متصل'],['off','غير متصل']]}],v=>{const r=PL().filter(p=>p.coins>=+v.a&&p.coins<=+v.b&&(v.o==='all'||(v.o==='on')===p.online));out('النتائج ('+r.length+')',plist(r,p=>fmt(p.coins)));}));

/* ===== إرسال جماعي ===== */
const grp={on:()=>PL().filter(p=>p.online),idle:()=>PL().filter(p=>Date.now()-p.last>=7*DAY),buyers:()=>{const s=new Set(DONE().map(o=>o.token));return PL().filter(p=>s.has(p.token));},all:()=>PL(),fav:()=>{const f=LS.get('adm_fav',[]);return PL().filter(p=>f.includes(p.token));},poor:()=>PL().filter(p=>p.coins<100),new24:()=>PL().filter(p=>Date.now()-p.last<DAY)};
const gname={on:'المتصلين',idle:'غير النشطين',buyers:'المشترين السابقين',all:'كل اللاعبين',fav:'المفضّلين',poor:'اللاعبين الفقراء (<100)',new24:'نشطي 24 ساعة'};
for(const k of Object.keys(grp)){
  add(C,'رسالة إلى '+gname[k],'',()=>ask('رسالة جماعية',[{id:'m',label:'النص'}],v=>{if(!v.m.trim())throw new Error('اكتب نصاً');return bulk(grp[k](),0,0,v.m.trim().slice(0,120));}));
  add(C,'هدية عملات إلى '+gname[k],'',()=>ask('هدية عملات',[{id:'c',label:'عملات لكل لاعب',type:'number',value:200},{id:'m',label:'رسالة',value:'هدية من المالك!'}],v=>bulk(grp[k](),Math.floor(+v.c),0,v.m)));
}
add(C,'جواهر إلى المتصلين','',()=>ask('جواهر',[{id:'g',label:'جواهر لكل لاعب',type:'number',value:5}],v=>bulk(grp.on(),0,Math.floor(+v.g),'هدية جواهر من المالك 💎')));
add(C,'VIP إلى المشترين السابقين','',()=>ask('VIP',[{id:'d',label:'الأيام',type:'number',value:7}],v=>bulk(grp.buyers(),0,0,'ترقية VIP كشكر لك',Math.floor(+v.d))));
add(C,'حملة العودة (غير النشطين)','عملات + جواهر + رسالة',()=>ask('حملة عودة',[{id:'c',label:'عملات',type:'number',value:500},{id:'g',label:'جواهر',type:'number',value:10}],v=>bulk(grp.idle(),Math.floor(+v.c),Math.floor(+v.g),'اشتقنا لك! عد والعب 🎁')));
add(C,'منح VIP لكل المتصلين','',()=>ask('VIP للمتصلين',[{id:'d',label:'الأيام',type:'number',value:3}],v=>bulk(grp.on(),0,0,'VIP هدية لك الآن!',Math.floor(+v.d))));

/* ===== عروض وأحداث ===== */
const BO=(c,x,m,l)=>()=>Cmd.boost(c,x,m/60,l).then(()=>toast('أُطلق: '+l,'ok')).catch(e=>toast(e.message,'bad'));
add(D,'ساعة الحظ ×2 (ساعة)','',BO(2,2,60,'ساعة الحظ'));
add(D,'عطلة نهاية الأسبوع (12 ساعة)','',BO(2,2,720,'عرض نهاية الأسبوع'));
add(D,'عملات ×3 (30 د)','',BO(3,1,30,'عملات ×3'));
add(D,'خبرة ×3 (ساعة)','',BO(1,3,60,'خبرة ×3'));
add(D,'عرض صاعق ×5 (15 د)','',BO(5,2,15,'عرض صاعق'));
add(D,'إيقاف العرض الحالي','',()=>DB.pubAll({k:'boost',id:Cmd.uid('x'),coinX:1,xpX:1,label:'انتهى',until:Date.now()+1000}).then(()=>{Audit.add('إيقاف عرض');toast('طُلب الإيقاف','ok');}));
add(D,'عرض مخصّص','نافذة كاملة',()=>UI.boost());
add(D,'إعلان / هدية للجميع','',()=>UI.announce());
add(D,'هدية سريعة 500 عملة للجميع','حدث لساعة',()=>Cmd.announce('هدية سريعة','500 عملة لكل لاعب',500,0,1).then(()=>toast('أُرسل','ok')).catch(e=>toast(e.message,'bad')));
add(D,'هدية جواهر للجميع (5)','حدث لساعتين',()=>Cmd.announce('هدية الجواهر','5 جواهر لكل لاعب',0,5,2).then(()=>toast('أُرسل','ok')).catch(e=>toast(e.message,'bad')));
add(D,'إشعار للجميع (لافتة)','تظهر في اللعبة',()=>ask('إشعار للجميع',[{id:'m',label:'النص (حتى 100 حرف)'},{id:'h',label:'المدة بالساعات',type:'number',value:2}],async v=>{const m=v.m.trim().slice(0,100);if(!m)throw new Error('اكتب نصاً');if(Guard.ro())throw new Error('وضع القراءة فقط');const ok=await DB.pubAll({k:'notice',id:Cmd.uid('n'),msg:m,until:Date.now()+Math.min(12,Math.max(.1,+v.h||2))*36e5});Audit.add('إشعار: '+m);toast(ok?'أُرسل':'تعذّر','ok');}));
add(D,'رسالة صيانة','لافتة حمراء',()=>ask('صيانة',[{id:'m',label:'النص',value:'صيانة قصيرة، قد تنقطع الخدمة قليلاً'}],async v=>{const ok=await DB.pubAll({k:'notice',id:Cmd.uid('n'),msg:'🛠️ '+v.m.slice(0,95),until:Date.now()+2*36e5,warn:1});Audit.add('صيانة');toast(ok?'أُرسلت':'تعذّر','ok');}));
add(D,'تخفيض المتجر','نسبة على أسعار الجواهر',()=>ask('تخفيض',[{id:'p',label:'النسبة (5 – 70)',type:'number',value:20},{id:'h',label:'ساعات',type:'number',value:3}],async v=>{const p=Math.max(5,Math.min(70,Math.floor(+v.p||0)));if(Guard.ro())throw new Error('وضع القراءة فقط');const ok=await DB.pubAll({k:'sale',id:Cmd.uid('s'),pct:p,until:Date.now()+Math.min(12,Math.max(.1,+v.h||3))*36e5});Audit.add('تخفيض '+p+'%');toast(ok?'بدأ التخفيض':'تعذّر','ok');}));
add(D,'إلغاء التخفيض','',()=>DB.pubAll({k:'sale',id:Cmd.uid('s'),pct:0,until:Date.now()+1000}).then(()=>toast('أُلغي','ok')));
add(D,'جدولة عرض بعد وقت','ما دام التطبيق مفتوحاً',()=>ask('جدولة',[{id:'m',label:'بعد كم دقيقة',type:'number',value:30},{id:'x',label:'المضاعف',opts:[['2','×2'],['3','×3'],['5','×5']]}],v=>{const mins=Math.max(1,Math.min(720,+v.m||30));Timers.add(mins*6e4,'عرض ×'+v.x,()=>Cmd.boost(+v.x,+v.x>3?2:+v.x,1,'عرض مجدول'));toast('سيُطلق بعد '+mins+' د (أبقِ التطبيق مفتوحاً)','ok');}));
add(D,'المؤقّتات النشطة','',()=>out('المؤقّتات',Timers.list.length?'<div class="body">'+Timers.list.map(t=>'<div style="padding:6px 0">'+esc(t.label)+' — '+Math.max(0,Math.round((t.at-Date.now())/6e4))+' د</div>').join('')+'</div>':'<div class="body muted">لا توجد</div>'));
add(D,'إلغاء كل المؤقّتات','',()=>{for(const t of Timers.list)clearTimeout(t.h);Timers.list=[];toast('أُلغيت','ok');});

/* ===== طلبات ===== */
add(E,'طلبات اليوم','',()=>{const s=startOfDay();const a=OR().filter(o=>o.t>=s);out('طلبات اليوم ('+a.length+')','<div class="body">'+(a.map(o=>'<div style="padding:6px 0;border-bottom:1px solid var(--line)"><b>'+esc(o.name)+'</b> · '+esc(pkg(o))+' · '+STAT(o)+'</div>').join('')||'<span class="muted">لا يوجد</span>')+'</div>');});
add(E,'معلّقة أكثر من 24 ساعة','',()=>{const a=OR().filter(o=>o.status==='new'&&Date.now()-o.t>DAY);out('متأخّرة ('+a.length+')','<div class="body">'+(a.map(o=>'<div style="padding:6px 0"><b>'+esc(o.name)+'</b> · '+ago(o.t)+'</div>').join('')||'<span class="muted">لا يوجد</span>')+'</div>');});
add(E,'واتساب لآخر طلب معلّق','فتح رابط wa.me',()=>{const o=OR().filter(x=>x.status==='new').sort((a,b)=>b.t-a.t)[0];if(!o){toast('لا يوجد معلّق','bad');return;}const n=String(o.phone||'').replace(/[^\d]/g,'');out('تواصل مع '+o.name,'<div class="body"><a class="btn primary" target="_blank" rel="noopener" href="https://wa.me/'+n+'?text='+encodeURIComponent('مرحباً '+o.name+'، بخصوص طلبك ('+pkg(o)+') في craft B')+'">فتح واتساب</a></div>');});
add(E,'رسالة تذكير بالدفع','نص جاهز للنسخ',()=>{const o=OR().filter(x=>x.status==='new')[0];const t='مرحباً'+(o?' '+o.name:'')+'، طلبك'+(o?' ('+pkg(o)+')':'')+' بانتظار التحويل. بعد الدفع سأشحن حسابك فوراً. شكراً!';out('تذكير','<div class="body">'+esc(t)+'</div>',t);});
add(E,'رفض آخر طلب مع سبب','يصل اللاعب رسالة',()=>{const o=OR().filter(x=>x.status==='new').sort((a,b)=>b.t-a.t)[0];if(!o){toast('لا يوجد معلّق','bad');return;}ask('رفض: '+o.name,[{id:'r',label:'السبب',value:'لم يصلنا التحويل'}],async v=>{await Cmd.rejectOrder(o.id);try{await Cmd.credit(o.token,0,'تعذّر تنفيذ طلبك: '+v.r.slice(0,80),0);}catch(e){}toast('رُفض وأُبلغ اللاعب','ok');});});
add(E,'تأكيد كل المعلّقة','⚠️ مع تأكيد',async()=>{const a=OR().filter(o=>o.status==='new');if(!a.length){toast('لا يوجد معلّق','bad');return;}if(!await UI.confirm('تأكيد '+a.length+' طلب','سيُشحن الجميع الآن، تأكد من استلام الأموال.','تأكيد الكل',false))return;let n=0;for(const o of a){try{await Cmd.confirmOrder(o.id);n++;}catch(e){}}toast('تم '+n,'ok');});
add(E,'تصدير الطلبات CSV','',()=>dl('الطلبات',csvOf([['الاسم','الهاتف','المنصة','الحساب','الباقة','السعر','الحالة','التاريخ']].concat(OR().map(o=>[o.name,o.phone,o.platform,o.handle,pkg(o),o.priceDT,STAT(o),new Date(o.t).toISOString()])))));
add(E,'ملاحظة على طلب','محلية',()=>ask('ملاحظة طلب',[{id:'n',label:'اسم صاحب الطلب'},{id:'t',label:'الملاحظة'}],v=>{const o=OR().find(x=>x.name===v.n);if(!o)throw new Error('طلب غير موجود');const m=LS.get('adm_onotes',{});m[o.id]=v.t.slice(0,150);LS.set('adm_onotes',m);toast('حُفظت','ok');}));
add(E,'قائمة الأسعار','تعرض أسعار الباقات',()=>out('الأسعار','<div class="body">'+[['1000 عملة','2 DT'],['2000 عملة','3.5 DT'],['5000 عملة','5.7 DT'],['حزمة المبتدئ','3 DT'],['VIP 30 يوم','12 DT']].map(r=>'<div style="display:flex;justify-content:space-between;padding:5px 0"><span>'+r[0]+'</span><b>'+r[1]+'</b></div>').join('')+'<div class="muted">للمرجع، الأسعار الحقيقية داخل اللعبة.</div></div>'));
add(E,'حاسبة الإيراد','سعر × عدد',()=>ask('حاسبة',[{id:'p',label:'السعر DT',type:'number',value:3},{id:'n',label:'عدد الطلبات',type:'number',value:10}],v=>out('الناتج',kv([['المجموع',fmtDT(+v.p*+v.n)]]))));
add(E,'حذف المنتهية الأقدم من 30 يوماً','تنظيف',async()=>{const a=OR().filter(o=>o.status!=='new'&&Date.now()-(o.doneAt||o.t)>30*DAY);if(!a.length){toast('لا يوجد','ok');return;}if(!await UI.confirm('حذف '+a.length+' طلباً','طلبات منتهية أقدم من 30 يوماً.','حذف',true))return;for(const o of a)try{await Cmd.deleteOrder(o.id);}catch(e){}toast('تم الحذف','ok');});

/* ===== أمان وتحكم ===== */
add(G,'وضع القراءة فقط','يمنع أي إرسال',()=>{LS.set('adm_ro',!Guard.ro());toast(Guard.ro()?'القراءة فقط: مفعّل':'القراءة فقط: متوقف','ok');Pro.render();});
add(G,'قفل التطبيق الآن','',()=>App.logout());
add(G,'قفل تلقائي','بعد خمول',()=>ask('قفل تلقائي',[{id:'m',label:'دقائق (0 = إيقاف)',type:'number',value:LS.get('adm_alock',0)}],v=>{LS.set('adm_alock',Math.max(0,Math.min(120,Math.floor(+v.m||0))));Pro.armLock();toast('تم','ok');}));
add(G,'وضع الخصوصية','يموّه الأرقام',()=>{LS.set('adm_priv',!LS.get('adm_priv',false));Pro.apply();toast(LS.get('adm_priv',false)?'تمويه الأرقام':'إظهار الأرقام','ok');});
add(G,'سجل إجراءاتي','',()=>{const l=Audit.list().slice().reverse();out('السجل ('+l.length+')','<div class="body">'+(l.slice(0,80).map(x=>'<div style="padding:5px 0;border-bottom:1px solid var(--line)"><small>'+timeStr(x.t)+'</small><br>'+esc(x.x)+'</div>').join('')||'<span class="muted">فارغ</span>')+'</div>');});
add(G,'تصدير السجل','',()=>dl('السجل',Audit.list().map(x=>new Date(x.t).toISOString()+'  '+x.x).join('\n')));
add(G,'مسح السجل','',()=>{Audit.clear();toast('مُسح','ok');});
add(G,'حد يومي للهدايا','سقف العملات',()=>ask('الحد اليومي',[{id:'c',label:'عملات (0 = بلا حد)',type:'number',value:Guard.cap()}],v=>{LS.set('adm_cap',Math.max(0,Math.floor(+v.c||0)));toast('تم','ok');}));
add(G,'المُنفَق اليوم من الحد','',()=>out('الحد',kv([['المُنفَق اليوم',fmt(Guard.spent())],['الحد',Guard.cap()?fmt(Guard.cap()):'بلا حد']])));
add(G,'نسخة احتياطية للإعدادات','JSON',()=>{const o={};for(const k of ['adm_notes','adm_tags','adm_fav','adm_cap','adm_alock','adm_onotes','adm_priv','adm_fs','adm_cmp','adm_th'])o[k]=LS.get(k,null);dl('النسخة',JSON.stringify(o));});
add(G,'استعادة الإعدادات','الصق JSON',()=>ask('استعادة',[{id:'j',label:'JSON'}],v=>{let o;try{o=JSON.parse(v.j);}catch(e){throw new Error('JSON غير صالح');}for(const k in o)if(/^adm_(notes|tags|fav|cap|alock|onotes|priv|fs|cmp|th)$/.test(k)&&o[k]!=null)LS.set(k,o[k]);Pro.apply();toast('تمت الاستعادة','ok');}));
add(G,'مسح البيانات المحلية','⚠️ ملاحظات ووسوم',async()=>{if(!await UI.confirm('مسح','سيُمسح كل ما حفظته على الجهاز (ملاحظات، وسوم، سجل).','مسح',true))return;for(const k of ['adm_notes','adm_tags','adm_fav','adm_cap','adm_alock','adm_onotes','adm_priv','adm_fs','adm_cmp','adm_th','adm_log','adm_ro','adm_spent'])try{localStorage.removeItem(k);}catch(e){}Pro.apply();toast('مُسح','ok');});
add(G,'تغيير الرمز السري','',()=>App.changePin());
add(G,'حالة الاتصال','',()=>out('الاتصال',kv([['القناة',Store.conn()?'متصل':'غير متصل'],['اللاعبون',PL().length],['الطلبات',OR().length],['الوضع',LIVE?'حقيقي':'تجريبي']])));

/* ===== مظهر ===== */
add(H,'حجم الخط','',()=>ask('حجم الخط',[{id:'s',label:'الحجم',opts:[['13','صغير'],['15','عادي'],['17','كبير'],['19','كبير جداً']]}],v=>{LS.set('adm_fs',+v.s);Pro.apply();}));
add(H,'الوضع المضغوط','',()=>{LS.set('adm_cmp',!LS.get('adm_cmp',false));Pro.apply();});
add(H,'ثيم أسود AMOLED','',()=>{LS.set('adm_th',LS.get('adm_th','')==='amoled'?'':'amoled');Pro.apply();});
add(H,'صوت التنبيهات (تبديل)','',()=>{Snd.on=!Snd.on;LS.set('adm_snd2',Snd.on);try{localStorage.setItem('adm_snd',Snd.on?'1':'0');}catch(e){}toast(Snd.on?'الصوت يعمل':'الصوت متوقف','ok');});
add(H,'اختبار رنين الطلب','',()=>{Snd.unlock();Snd.order();});
add(H,'اختبار تنبيه عادي','',()=>{Snd.unlock();Snd.alert();});
add(H,'تثبيت التطبيق','',()=>{if(App.deferred){App.deferred.prompt();App.deferred=null;}else toast('غير متاح الآن (ربما مثبّت بالفعل)');});
add(H,'عن التطبيق','',()=>out('لوحة المالك',kv([['عدد الأدوات',F.length],['الإصدار','3.0'],['الاتصال','ntfy بدون Firebase']])));


/* ===== دفعة إضافية ===== */
const TPL=['أهلاً بك في craft B! استمتع باللعب 🎮','شكراً لدعمك، هديتك وصلت 🎁','نعتذر عن المشكلة، تم تعويضك','تذكير: عروض نهاية الأسبوع بدأت 🔥','ننصحك بتجربة المزرعة والرفاق 🐾','لا تنسَ صندوق الحظ المجاني كل 4 ساعات!'];
add(C,'قالب رسالة سريعة للاعب','6 قوالب جاهزة',()=>ask('قالب رسالة',[{id:'t',label:'الاسم أو الرمز'},{id:'m',label:'القالب',opts:TPL.map(x=>[x,x])}],async v=>{const p=PL().find(x=>x.token===v.t||x.name===v.t);if(!p)throw new Error('لاعب غير موجود');await Cmd.message(p.token,v.m);toast('أُرسل','ok');}));
add(B,'تعويض سريع للاعب (500)','عملات + رسالة اعتذار',()=>ask('تعويض',[{id:'t',label:'الاسم أو الرمز'},{id:'c',label:'عملات',type:'number',value:500}],async v=>{const p=PL().find(x=>x.token===v.t||x.name===v.t);if(!p)throw new Error('لاعب غير موجود');await Cmd.credit(p.token,Math.floor(+v.c),'تعويض من المالك، نعتذر عن الإزعاج',0);toast('تم','ok');}));
add(B,'نشاط لاعب (آخر الأحداث)','من الخلاصة',()=>ask('نشاط لاعب',[{id:'t',label:'الاسم'}],v=>{const f=Store.feed(300).filter(x=>x.n===v.t).slice(0,25);out('نشاط '+v.t,'<div class="body">'+(f.map(x=>'<div style="padding:5px 0;border-bottom:1px solid var(--line)"><small>'+ago(x.t)+'</small><br>'+esc(Store.text(x))+'</div>').join('')||'<span class="muted">لا نشاط</span>')+'</div>');}));
add(A,'آخر 20 حدثاً','',()=>{const f=Store.feed(20);out('آخر الأحداث','<div class="body">'+(f.map(x=>'<div style="padding:5px 0;border-bottom:1px solid var(--line)"><small>'+ago(x.t)+'</small><br>'+esc(Store.text(x))+'</div>').join('')||'<span class="muted">لا شيء</span>')+'</div>');});
add(A,'أنواع الأحداث','عدّ حسب النوع',()=>{const m={};for(const x of Store.feed(500))m[x.type]=(m[x.type]||0)+1;out('الأحداث',bars(Object.entries(m).sort((a,b)=>b[1]-a[1]).slice(0,12)));});
add(A,'تنبيه الاقتصاد','لاعبون فوق 20× المتوسط',()=>{const a=PL();const av=sum(a,p=>p.coins)/(a.length||1);out('أرصدة غير طبيعية',plist(a.filter(p=>p.coins>av*20&&p.coins>2e4),p=>fmt(p.coins)));});
add(A,'توقّع إيراد الشهر','من متوسط آخر 7 أيام',()=>{const w=sum(revBy(7),x=>x[1]);out('التوقّع',kv([['آخر 7 أيام',fmtDT(w)],['الشهر المتوقع',fmtDT(w/7*30)]]));});
add(A,'أفضل يوم مبيعات','',()=>{const m={};for(const o of DONE()){const k=dkey(o.doneAt||o.t);m[k]=(m[k]||0)+(+o.priceDT||0);}const e=Object.entries(m).sort((a,b)=>b[1]-a[1])[0];out('أفضل يوم',e?kv([['اليوم',e[0]],['الإيراد',fmtDT(e[1])]]):'<div class="body muted">لا مبيعات</div>');});
add(D,'عرض نهاية الأسبوع + تخفيض','×2 + تخفيض 20% (6 ساعات)',async()=>{await Cmd.boost(2,2,6,'عرض مميز');await DB.pubAll({k:'sale',id:Cmd.uid('s'),pct:20,until:Date.now()+6*36e5});Audit.add('عرض + تخفيض');toast('أُطلق العرض والتخفيض','ok');});
add(D,'جدولة هدية للمتصلين','بعد وقت (التطبيق مفتوح)',()=>ask('جدولة هدية',[{id:'m',label:'بعد كم دقيقة',type:'number',value:15},{id:'c',label:'عملات',type:'number',value:200}],v=>{Timers.add(Math.max(1,+v.m||15)*6e4,'هدية للمتصلين',async()=>{for(const p of grp.on().slice(0,200))await Cmd.credit(p.token,Math.floor(+v.c),'هدية مجدولة من المالك',0);});toast('جُدولت','ok');}));
add(G,'إعادة ضبط الحد اليومي','',()=>{LS.set('adm_spent',{d:'',n:0});toast('أُعيد الضبط','ok');});
add(H,'لون التطبيق','لون التمييز',()=>ask('اللون',[{id:'c',label:'اللون',opts:[['','الافتراضي'],['#3ddc97','أخضر'],['#4ea1ff','أزرق'],['#ff6b9a','وردي'],['#ffb347','برتقالي']]}],v=>{LS.set('adm_ac',v.c);Pro.apply();}));
add(G,'نسخ رابط اللعبة','',()=>copyText(location.origin+'/').then(ok=>toast(ok?'نُسخ':'تعذّر')));
add(B,'لاعبون ثلاثيّو الشخصيات فأكثر','',()=>out('جامعو الشخصيات',plist(PL().filter(p=>p.owned.length>=3),p=>p.owned.length+' شخصيات')));

/* ===== أكواد الهدايا ===== */
const hcode=t=>{t=String(t||'').trim().toUpperCase();let h=2166136261;for(let i=0;i<t.length;i++){h^=t.charCodeAt(i);h=Math.imul(h,16777619)>>>0;}return h.toString(36)+t.length;};
const Codes={list(){return LS.get('adm_codes',[]).filter(c=>c.until>Date.now());},save(l){LS.set('adm_codes',l);}};
add(D,'إنشاء كود هدية','يكتبه اللاعب في اللعبة',()=>ask('كود هدية',[{id:'k',label:'الكود (حروف/أرقام)',value:'GIFT'+Math.floor(Math.random()*900+100)},{id:'c',label:'عملات (حتى 5000)',type:'number',value:300},{id:'g',label:'جواهر (حتى 50)',type:'number',value:0},{id:'h',label:'صلاحية بالساعات (حتى 720)',type:'number',value:48}],async v=>{
  const k=v.k.trim().toUpperCase();if(!/^[A-Z0-9]{3,20}$/.test(k))throw new Error('الكود: 3–20 حرفاً إنجليزياً أو رقماً');
  const c=Math.max(0,Math.min(5000,Math.floor(+v.c||0))),g=Math.max(0,Math.min(50,Math.floor(+v.g||0)));if(!c&&!g)throw new Error('حدد عملات أو جواهر');
  if(Guard.ro())throw new Error('وضع القراءة فقط');
  const until=Date.now()+Math.max(1,Math.min(720,+v.h||48))*36e5;const id=Cmd.uid('c');
  const ok=await DB.pubAll({k:'code',id,h:hcode(k),coins:c,gems:g,until});if(!ok)throw new Error('تعذّر الإرسال');
  const l=Codes.list().filter(x=>x.k!==k);l.push({k,c,g,until,id});Codes.save(l);Audit.add('كود '+k);
  out('تم إنشاء الكود',kv([['الكود',k],['المكافأة',(c?c+' عملة ':'')+(g?g+' جوهرة':'')],['ينتهي',timeStr(until)]])+'<div class="muted body">أرسله للاعبين: اللعبة › العالم › المزيد › كود هدية. كل لاعب يستخدمه مرة واحدة. ينتهي تلقائياً، ويصل من يفتح اللعبة خلال 12 ساعة من الإنشاء.</div>',k);}));
add(D,'الأكواد النشطة','نسخ أو إلغاء',()=>{const l=Codes.list();out('الأكواد ('+l.length+')','<div class="body">'+(l.map(x=>'<div style="display:flex;justify-content:space-between;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid var(--line)"><span><b dir="ltr">'+esc(x.k)+'</b><br><small>'+(x.c?x.c+' عملة ':'')+(x.g?x.g+' جوهرة ':'')+'· '+ago(x.until).replace('منذ','بعد')+'</small></span><span><button class="btn sm" data-cc="'+esc(x.k)+'">نسخ</button> <button class="btn sm danger" data-cr="'+esc(x.k)+'">إلغاء</button></span></div>').join('')||'<span class="muted">لا توجد</span>')+'</div>');
  for(const b of document.querySelectorAll('[data-cc]'))b.onclick=()=>copyText(b.dataset.cc).then(()=>toast('نُسخ'));
  for(const b of document.querySelectorAll('[data-cr]'))b.onclick=async()=>{try{if(Guard.ro())throw new Error('وضع القراءة فقط');const x=Codes.list().find(c=>c.k===b.dataset.cr);await DB.pubAll({k:'code',id:Cmd.uid('c'),h:hcode(x.k),revoke:1});Codes.save(Codes.list().filter(c=>c.k!==x.k));Audit.add('إلغاء كود '+x.k);toast('أُلغي (يسري عند اتصال اللاعب)','ok');b.disabled=true;}catch(e){toast(e.message,'bad');}};});
add(A,'استخدامات الأكواد','من الخلاصة',()=>{const f=Store.feed(500).filter(x=>x.type==='code');out('استخدامات الأكواد ('+f.length+')','<div class="body">'+(f.slice(0,40).map(x=>'<div style="padding:5px 0;border-bottom:1px solid var(--line)">'+esc(x.n)+' · <small>'+ago(x.t)+'</small></div>').join('')||'<span class="muted">لا استخدامات</span>')+'</div>');});

/* ===== تحكم مباشر جماعي ===== */
const CA=(n,d,a,v,k)=>add('تحكم','🎮 '+n,d,async()=>{if(!await UI.confirm(n,'يُنفَّذ على كل اللاعبين المتصلين الآن (خلال دقائق).','نفّذ',false))return;await Cmd.controlAll(a,v||'',k||1);toast('أُرسل للمتصلين','ok');});
CA('شفاء كل المتصلين','','heal');CA('إشباع الجميع','','food');CA('نهار للجميع','','tod','day');CA('ليل للجميع','','tod','night');CA('إزالة كل الأعداء','حول كل لاعب','purge');
CA('زعيم لكل لاعب','تحدٍّ جماعي','spawn','boss',1);CA('أعداء زومبي ×5 للجميع','','spawn','zombie',5);CA('لا يُقهرون 60ث','','god','',60);CA('الطيران للجميع','','fly','on');CA('إيقاف الطيران','','fly','off');
CA('خشب ×50 للجميع','','give','wood',50);CA('حجر ×50 للجميع','','give','stone',50);CA('حديد ×20 للجميع','','give','iron',20);CA('ألماس ×5 للجميع','','give','diamond',5);CA('سهام ×30 للجميع','','give','arrow',30);CA('رصاص ×30 للجميع','','give','bullet',30);CA('لحم ×10 للجميع','','give','meat',10);
add('تحكم','🎮 تحكم مباشر بلاعب','اختر لاعباً',()=>ask('تحكم مباشر',[{id:'t',label:'الاسم أو الرمز'}],v=>{const p=PL().find(x=>x.token===v.t||x.name===v.t);if(!p)throw new Error('لاعب غير موجود');UI.control(p.token);}));
add('تحكم','المتصلون الآن (للتحكم)','اضغط لاعباً',()=>{const a=PL().filter(p=>p.online);out('المتصلون ('+a.length+')','<div class="body">'+(a.map(p=>'<div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0"><b>'+esc(p.name)+'</b><button class="btn sm gold" data-cq="'+esc(p.token)+'">🎮 تحكم</button></div>').join('')||'<span class="muted">لا أحد</span>')+'</div>');for(const b of document.querySelectorAll('[data-cq]'))b.onclick=()=>{UI.close();setTimeout(()=>UI.control(b.dataset.cq),50);};});
/* ---------- الواجهة ---------- */
const Pro={
  cat:'الكل',q:'',
  cats:[A,B,C,D,E,G,H,'تحكم'],
  apply(){const b=document.body.classList;b.toggle('priv',!!LS.get('adm_priv',false));b.toggle('cmp',!!LS.get('adm_cmp',false));b.toggle('amo',LS.get('adm_th','')==='amoled');const ac=LS.get('adm_ac','');ac?document.documentElement.style.setProperty('--ac',ac):document.documentElement.style.removeProperty('--ac');document.documentElement.style.fontSize=(LS.get('adm_fs',15))+'px';},
  armLock(){clearTimeout(this._lk);const m=+LS.get('adm_alock',0);if(!m)return;this._lk=setTimeout(()=>{if(App.entered)App.logout();},m*6e4);},
  render(){
    const el=$('proBody');if(!el)return;
    const ro=Guard.ro();
    let h='<div class="muted" style="margin-bottom:8px">'+F.length+' أداة · '+(ro?'🔒 وضع القراءة فقط مفعّل':'جاهز')+'</div>';
    h+='<div class="search"><input id="proQ" type="search" placeholder="ابحث في الأدوات…" value="'+esc(this.q)+'"></div>';
    h+='<div class="chips">'+['الكل'].concat(this.cats).map(c=>'<button class="chip'+(c===this.cat?' on':'')+'" data-pc="'+esc(c)+'">'+esc(c)+'</button>').join('')+'</div>';
    const list=F.map((f,i)=>({f,i})).filter(x=>(this.cat==='الكل'||x.f.c===this.cat)&&(!this.q||(x.f.n+' '+x.f.d+' '+x.f.c).includes(this.q)));
    h+='<div id="proList">'+list.map(x=>'<button class="btn" data-pf="'+x.i+'" style="width:100%;text-align:right;margin:4px 0;display:flex;justify-content:space-between;gap:8px"><span>'+esc(x.f.n)+'</span><small class="muted">'+esc(x.f.d||x.f.c)+'</small></button>').join('')+(list.length?'':'<div class="muted">لا نتائج</div>')+'</div>';
    el.innerHTML=h;
    $('proQ').oninput=e=>{this.q=e.target.value.trim();const pos=e.target.selectionStart;this.render();const q=$('proQ');q.focus();try{q.setSelectionRange(pos,pos);}catch(x){}};
    for(const b of el.querySelectorAll('[data-pc]'))b.onclick=()=>{this.cat=b.dataset.pc;this.render();};
    for(const b of el.querySelectorAll('[data-pf]'))b.onclick=()=>this.run(+b.dataset.pf);
  },
  async run(i){const f=F[i];try{await f.run();}catch(e){toast(e.message||'خطأ','bad');}},
  count(){return F.length;}
};
document.addEventListener('click',()=>Pro.armLock(),{passive:true});
