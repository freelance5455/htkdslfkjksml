/* ============================================================
   التشغيل: قفل الدخول → اشتراك لحظي → واجهة
   ============================================================ */
const App={
  deferred:null,entered:false,
  say(t,bad){const m=$('lMsg');m.textContent=t||'';m.className='msg'+(bad?' bad':'');},
  async init(){
    try{Snd.on=localStorage.getItem('adm_snd')!=='0';}catch(e){}
    $('demoTag').hidden=LIVE;$('demoBar').hidden=LIVE;try{if(!OWNER.email)OWNER.email=localStorage.getItem('adm_mail')||'';}catch(e){}
    if('serviceWorker' in navigator){navigator.serviceWorker.register('service-worker.js').catch(()=>{});navigator.serviceWorker.addEventListener('message',e=>{if(e.data&&e.data.type==='open'){UI.go(e.data.tab||'orders');}});}
    window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();App.deferred=e;});
    $('lGo').onclick=()=>this.submit();
    for(const id of ['lPin','lPin2','lPass','lEmail'])$(id).addEventListener('keydown',e=>{if(e.key==='Enter')this.submit();});
    for(const b of $('bar').querySelectorAll('button'))b.onclick=()=>UI.go(b.dataset.tab);
    $('q').addEventListener('input',()=>UI.renderPlayers());$('lbHidden').addEventListener('change',()=>UI.renderLb());
    $('annBtn').onclick=()=>UI.announce();$('boostBtn').onclick=()=>UI.boost();$('bellBtn').onclick=()=>UI.showBell();$('setBtn').onclick=()=>UI.showSettings();
    $('modal').addEventListener('click',e=>{if(e.target.id==='modal')UI.close();});
    $('orderPop').addEventListener('click',e=>{if(e.target.id==='orderPop')$('orderPop').hidden=true;});
    setInterval(()=>{if(this.entered&&!document.hidden)UI.render();},20000); /* تحديث «منذ…» والحالة */
    try{Pro.apply();Pro.armLock();}catch(e){}
    await this.prepare();
  },
  async prepare(){
    const demo=sessionStorage.getItem('adm_demo')==='1';
    $('connBox').hidden=LIVE||demo;$('mainForm').hidden=!(LIVE||demo);
    $('cfgSave').onclick=()=>{const u=$('cfgUrl').value.trim();if(!/^https:\/\/.+/.test(u)){this.say('الرابط يجب أن يبدأ بـ https://',true);return;}try{localStorage.setItem('adm_cfg',JSON.stringify({databaseURL:u,apiKey:$('cfgKey').value.trim(),secret:$('cfgSecret').value.trim()}));if($('cfgMail').value.trim())localStorage.setItem('adm_mail',$('cfgMail').value.trim());}catch(e){}location.reload();};
    $('cfgDemo').onclick=()=>{sessionStorage.setItem('adm_demo','1');location.reload();};
    if(!LIVE&&!demo)return;
    /* جلسة محفوظة؟ */
    try{
      if(Auth.mode==='firebase'){
        const rt=localStorage.getItem('adm_rt');
        if(rt){Auth.refreshToken=rt;try{await Auth.refresh();return this.enter();}catch(e){localStorage.removeItem('adm_rt');}}
      }else{
        const ok=localStorage.getItem('adm_ok')||sessionStorage.getItem('adm_ok');
        if(ok&&+ok>Date.now()&&await Auth.pinStored())return this.enter();
      }
    }catch(e){}
    this.showLock();
  },
  async showLock(){
    $('lock').hidden=false;$('app').hidden=true;this.entered=false;
    const fb=Auth.mode==='firebase';$('fbForm').hidden=!fb;$('pinForm').hidden=fb;
    if(!fb){
      const has=!!(await Auth.pinStored());this.creating=!has;
      $('pin2Wrap').hidden=has;$('pinLabel').firstChild.textContent=has?'الرمز السري (PIN)':'أنشئ رمز PIN جديداً (4 أرقام على الأقل)';
      $('lockSub').textContent=has?'أدخل رمز المالك للمتابعة':'أول تشغيل: أنشئ رمزاً سرياً يحمي لوحتك على هذا الجهاز';
      $('lGo').textContent=has?'دخول':'إنشاء الرمز والدخول';
    }else{$('lockSub').textContent='سجّل الدخول ببريد المالك وكلمة المرور';$('lGo').textContent='دخول';}
  },
  async submit(){
    Snd.unlock();this.say('');
    if(Date.now()<Auth.lockUntil){this.say('محاولات كثيرة. انتظر '+Math.ceil((Auth.lockUntil-Date.now())/1000)+' ثانية',true);return;}
    const rem=$('lRemember').checked;$('lGo').disabled=true;
    try{
      if(Auth.mode==='firebase'){
        const em=$('lEmail').value.trim(),pw=$('lPass').value;if(!em||!pw){this.say('اكتب البريد وكلمة المرور',true);return;}
        try{await Auth.login(em,pw);}catch(e){this.fail(e.message==='NOT_OWNER'?'هذا الحساب ليس حساب المالك':'بيانات الدخول غير صحيحة');return;}
        try{if(rem)localStorage.setItem('adm_rt',Auth.refreshToken);}catch(e){}
      }else{
        const pin=$('lPin').value;
        if(this.creating){
          if(!/^\d{4,16}$/.test(pin)){this.say('الرمز: من 4 إلى 16 رقماً',true);return;}
          if(pin!==$('lPin2').value){this.say('الرمزان غير متطابقين',true);return;}
          await Auth.pinSet(pin);
        }else if(!(await Auth.pinCheck(pin))){this.fail('الرمز غير صحيح');return;}
        try{(rem?localStorage:sessionStorage).setItem('adm_ok',String(Date.now()+(rem?7*864e5:12*36e5)));}catch(e){}
      }
      Auth.fails=0;$('lPin').value=$('lPin2').value=$('lPass').value='';
      this.enter();
    }finally{$('lGo').disabled=false;}
  },
  fail(m){Auth.fails++;if(Auth.fails>=5){Auth.lockUntil=Date.now()+30000;Auth.fails=0;m+=' — تم القفل 30 ثانية';}this.say(m,true);},
  enter(){
    $('lock').hidden=true;$('app').hidden=false;this.entered=true;
    if(RELAYU){if(!RelayDB.inited){RelayDB.inited=true;RelayDB.init();}}else if(!LIVE&&!MemDB.seeded){MemDB.seeded=true;MemDB.seed();}
    Store.onChange=()=>UI.render();
    Store.onOrder=(id,o)=>UI.showOrder(id,o);
    Store.onAlert=(tk,e,kind)=>UI.pushAlert(Store.text({type:e.type,info:e.info,n:Store.nameOf(tk,e)}),'',kind==='warn'?'warn':(kind==='quiet'?'quiet':'info'),'feed');
    Store.start();Auth.keepAlive();
    const h=(location.hash||'').replace('#','');UI.go(['home','orders','players','feed','lb'].includes(h)?h:'home');
    if('Notification' in window&&Notification.permission==='default')setTimeout(()=>toast('فعّل إشعارات النظام من زر الجرس','ok'),2500);
  },
  logout(){Store.stop();Auth.logout();try{localStorage.removeItem('adm_ok');}catch(e){}this.showLock();},
  changePin(){
    UI.sheet('<h3>تغيير رمز PIN</h3><div class="body"><label>الرمز الحالي<input id="cpO" type="password" inputmode="numeric" dir="ltr"></label><label>الرمز الجديد<input id="cpN" type="password" inputmode="numeric" dir="ltr" maxlength="16"></label></div><div class="row"><button class="btn primary" id="cpGo">حفظ</button><button class="btn" id="cpNo">إلغاء</button></div>',s=>{
      $('cpNo').onclick=()=>UI.close();
      $('cpGo').onclick=async()=>{if(!(await Auth.pinCheck($('cpO').value))){toast('الرمز الحالي غير صحيح','bad');return;}const n=$('cpN').value;if(!/^\d{4,16}$/.test(n)){toast('الرمز الجديد: 4 إلى 16 رقماً','bad');return;}await Auth.pinSet(n);UI.close();toast('تم تغيير الرمز','ok');};
    });
  }
};
window.addEventListener('DOMContentLoaded',()=>App.init());
