/* ============================================================
   طبقة البيانات: Firebase Realtime Database عبر REST + بث لحظي (Server-Sent Events)
   - بدون مكتبات خارجية. نفس أسلوب اللعبة.
   - وضع تجريبي (MemDB) عند غياب databaseURL.
   ============================================================ */
const FBC=Object.assign({},window.FIREBASE_CONFIG||{});
try{const c=JSON.parse(localStorage.getItem('adm_cfg')||'null');if(c&&(c.databaseURL||c.relay))Object.assign(FBC,c);}catch(e){}
if(FBC.databaseURL)FBC.databaseURL=FBC.databaseURL.trim().replace(/\/+$/,'');
const RELAYU=FBC.relay?String(FBC.relay).replace(/\/+$/,''):'';
const LIVE=!!RELAYU||!!(FBC.databaseURL&&/^(https:\/\/|http:\/\/localhost)/.test(FBC.databaseURL));

class Stream{
  constructor(db,path,cb,state){this.db=db;this.path=path;this.cb=cb;this.state=state;this.tree=null;this.es=null;this.timer=null;this.retry=1500;this.dead=false;this.pend=null;this.open();}
  open(){
    if(this.dead)return;this.close(true);
    let es;try{es=new EventSource(this.db.url(this.path));}catch(e){this.later();return;}
    this.es=es;
    es.onopen=()=>{this.retry=1500;this.state&&this.state(this.path,true);};
    es.addEventListener('put',e=>this.on(e,false));
    es.addEventListener('patch',e=>this.on(e,true));
    es.addEventListener('auth_revoked',()=>{this.db.refresh().then(()=>this.open()).catch(()=>this.state&&this.state(this.path,false,'auth'));});
    es.onerror=()=>{this.state&&this.state(this.path,false);if(es.readyState===2){this.later();}};
  }
  later(){clearTimeout(this.timer);this.timer=setTimeout(()=>this.open(),this.retry);this.retry=Math.min(this.retry*1.7,30000);}
  close(keep){if(this.es){try{this.es.close();}catch(e){}this.es=null;}if(!keep){this.dead=true;clearTimeout(this.timer);}}
  on(e,merge){
    let m;try{m=JSON.parse(e.data);}catch(x){return;}
    const p=m.path==='/'?[]:String(m.path).split('/').filter(Boolean);const d=m.data;
    const mergeInto=(o,d)=>{for(const k in d){if(d[k]===null)delete o[k];else o[k]=d[k];}};
    if(!p.length){
      if(merge){if(d&&typeof d==='object'){if(!this.tree||typeof this.tree!=='object')this.tree={};mergeInto(this.tree,d);}}
      else this.tree=d;
    }else{
      if(!this.tree||typeof this.tree!=='object')this.tree={};
      let o=this.tree;for(let i=0;i<p.length-1;i++){if(!o[p[i]]||typeof o[p[i]]!=='object')o[p[i]]={};o=o[p[i]];}
      const k=p[p.length-1];
      if(merge&&d&&typeof d==='object'){if(!o[k]||typeof o[k]!=='object')o[k]={};mergeInto(o[k],d);}
      else if(d===null)delete o[k];else o[k]=d;
    }
    if(!this.pend)this.pend=setTimeout(()=>{this.pend=null;this.cb(this.tree||{});},120);
  }
}

const RealDB={
  live:true,tok:FBC.secret||null,
  url(p){return FBC.databaseURL.replace(/\/$/,'')+'/'+(FBC.root?FBC.root+'/':'')+p+'.json'+(this.tok?'?auth='+encodeURIComponent(this.tok):'');},
  async req(method,p,body){
    const r=await fetch(this.url(p),{method,headers:body!==undefined?{'Content-Type':'application/json'}:undefined,body:body===undefined?undefined:JSON.stringify(body)});
    if(r.status===401||r.status===403){const e=new Error('permission');e.code=r.status;throw e;}
    if(!r.ok)throw new Error('http '+r.status);
    return r.json();
  },
  get(p){return this.req('GET',p);},put(p,d){return this.req('PUT',p,d);},patch(p,d){return this.req('PATCH',p,d);},
  post(p,d){return this.req('POST',p,d);},del(p){return this.req('DELETE',p);},
  stream(p,cb,state){return new Stream(this,p,cb,state);},
  async refresh(){return Auth.refresh();}
};

/* ===== وضع تجريبي: قاعدة بيانات في الذاكرة بنفس الواجهة + أحداث وهمية ===== */
const MemDB={
  live:false,tok:null,tree:{},subs:[],
  _get(p){let o=this.tree;for(const k of String(p).split('/').filter(Boolean)){if(o==null||typeof o!=='object')return null;o=o[k];}return o===undefined?null:o;},
  _set(p,v,merge){
    const ks=String(p).split('/').filter(Boolean);
    if(!ks.length){this.tree=v||{};this._fire(p);return;}
    let o=this.tree;for(let i=0;i<ks.length-1;i++){if(!o[ks[i]]||typeof o[ks[i]]!=='object')o[ks[i]]={};o=o[ks[i]];}
    const k=ks[ks.length-1];
    if(v===null){delete o[k];}
    else if(merge&&v&&typeof v==='object'){if(!o[k]||typeof o[k]!=='object')o[k]={};for(const x in v){if(v[x]===null)delete o[k][x];else o[k][x]=v[x];}}
    else o[k]=v;
    this._fire(p);
  },
  _fire(p){for(const s of this.subs){if(String(p).startsWith(s.path)||s.path.startsWith(String(p)))s.cb(JSON.parse(JSON.stringify(this._get(s.path)||{})));}},
  async get(p){return JSON.parse(JSON.stringify(this._get(p)));},
  async put(p,d){this._set(p,d,false);return d;},async patch(p,d){this._set(p,d,true);return d;},
  async post(p,d){const id='-D'+Math.random().toString(36).slice(2,9);this._set(p+'/'+id,d,false);return {name:id};},
  async del(p){this._set(p,null,false);return null;},
  stream(path,cb,state){const s={path,cb,close(){MemDB.subs=MemDB.subs.filter(x=>x!==s);}};this.subs.push(s);setTimeout(()=>{cb(JSON.parse(JSON.stringify(this._get(path)||{})));state&&state(path,true);},30);return s;},
  async refresh(){},
  seed(){
    const now=Date.now(),T=this.tree;T.saves={};T.telemetry={};T.orders={};T.players={};
    const P=[['أحمد','FL-A1B2-C3D4',1250,['explorer','knight'],'online','online',7200],['سارة','FL-S9K2-M4P7',9800,['explorer','wizard','king'],'online','online',36000],['كريم','FL-K7X3-Q2W8',430,['explorer'],'online','big',1800],['ليلى','FL-L5T6-N8R2',150,['explorer','farmer'],'offline','offline',5400],['يوسف','FL-Y2D4-H6J9',22000,['explorer','ninja','cyber','phoenix'],'offline','offline',90000],['منى','FL-M8B3-V5C1',60,['explorer'],'online','offline',600]];
    for(const [n,tok,c,own,st,mode,ps] of P){
      T.saves[tok]={v:2,name:n,coins:c,owned:own,skin:own[own.length-1],playSec:ps,t:now-6e4*Math.random()*30};
      T.telemetry[tok]={status:{name:n,state:st,playSec:ps,coins:c,mode,t:st==='online'?now-4000:now-3600e3*(2+Math.random()*30)},events:{}};
      T.telemetry[tok].events['-e1']={t:now-9e5,type:'login',info:'',n};
    }
    T.orders['-o1']={name:'سارة بن علي',phone:'+21650123456',platform:'Instagram',handle:'@sara_gamer',coins:2000,priceDT:3.5,account:'سارة',token:'FL-S9K2-M4P7',t:now-18e5,status:'new'};
    T.orders['-o2']={name:'يوسف',phone:'+21699887766',platform:'Facebook',handle:'youssef.k',coins:5000,priceDT:5.7,account:'يوسف',token:'FL-Y2D4-H6J9',t:now-864e5,status:'done',doneAt:now-86e6};
    T.telemetry['FL-Y2D4-H6J9'].events['-e2']={t:now-3e6,type:'secret',info:'phoenix',n:'يوسف'};
    T.telemetry['FL-K7X3-Q2W8'].events['-e3']={t:now-1e5,type:'mode_big',info:'tiny',n:'كريم'};
    T.telemetry['FL-K7X3-Q2W8'].events['-e4']={t:now-2e5,type:'secret',info:'big',n:'كريم'};
    T.telemetry['FL-M8B3-V5C1'].events['-e5']={t:now-4e5,type:'coin_tamper',info:'checksum mismatch',n:'منى'};
    this.sim();
  },
  sim(){
    setInterval(()=>{const T=this.tree;for(const k in T.telemetry){const s=T.telemetry[k].status;if(s.state==='online'){this._set('telemetry/'+k+'/status/t',Date.now(),false);this._set('telemetry/'+k+'/status/playSec',(s.playSec||0)+5,false);}}},5000);
    let n=0;setTimeout(()=>{this._set('telemetry/FL-L5T6-N8R2/status',{name:'ليلى',state:'online',playSec:5400,coins:150,mode:'online',t:Date.now()},false);this._set('telemetry/FL-L5T6-N8R2/events/-d'+(n++),{t:Date.now(),type:'login',info:'',n:'ليلى'},false);},9000);
    setTimeout(()=>{this._set('orders/-o3',{name:'كريم الهادي',phone:'+21622334455',platform:'TikTok',handle:'@karim_b',coins:1000,priceDT:2,account:'كريم',token:'FL-K7X3-Q2W8',t:Date.now(),status:'new'},false);},16000);
  }
};

/* ===== وضع المرحّل (بدون Firebase): رسائل لحظية عبر خدمة ntfy العامة + قاعدة محلية على جهازك ===== */
const TOK_RE=/^[A-Z0-9-]{6,20}$/,ID_RE=/^[\w-]{1,24}$/;
const RelayDB=Object.assign(Object.create(MemDB),{
  live:true,relay:true,tree:{},subs:[],ids:[],lastResend:{},es:null,ok:false,_pt:null,
  base(){return 'cb'+String(FBC.root||'x').slice(1,25);},
  init(){
    try{this.tree=JSON.parse(localStorage.getItem('adm_tree')||'{}')||{};this.ids=JSON.parse(localStorage.getItem('adm_ids')||'[]')||[];}catch(e){this.tree={};this.ids=[];}
    for(const k of ['saves','telemetry','orders','players','lb'])if(!this.tree[k]||typeof this.tree[k]!=='object')this.tree[k]={};
    this.open();
  },
  open(){
    if(this.es){try{this.es.close();}catch(e){}}
    let es;try{es=new EventSource(RELAYU+'/'+this.base()+'-up/sse?since=12h');}catch(e){return;}
    this.es=es;es.addEventListener('message',ev=>this.onmsg(ev));
    es.onopen=()=>{this.ok=true;};es.onerror=()=>{this.ok=false;};
  },
  persist(){clearTimeout(this._pt);this._pt=setTimeout(()=>{try{localStorage.setItem('adm_tree',JSON.stringify(this.tree));localStorage.setItem('adm_ids',JSON.stringify(this.ids.slice(-800)));}catch(e){}},400);},
  _fire(p){MemDB._fire.call(this,p);this.persist();},
  stream(path,cb,state){const s={path,cb,close(){RelayDB.subs=RelayDB.subs.filter(x=>x!==s);}};this.subs.push(s);setTimeout(()=>{cb(JSON.parse(JSON.stringify(this._get(path)||{})));state&&state(path,true);},30);return s;},
  onmsg(ev){
    let m,d;try{m=JSON.parse(ev.data);}catch(e){return;}
    if(!m||!m.id||this.ids.includes(m.id))return;
    this.ids.push(m.id);if(this.ids.length>1000)this.ids.splice(0,200);
    try{d=JSON.parse(m.message);}catch(e){return;}
    if(!d||typeof d!=='object')return;
    const t=d.t,i=d.i;
    if(d.k!=='ord'&&!TOK_RE.test(String(t)))return;if(d.k==='evb'&&!ID_RE.test(String(d.i||'x')))return;
    switch(d.k){
      case 'st':this._set('telemetry/'+t+'/status',d.d,false);if(d.d&&d.d.state==='online')this.resend(t);break;
      case 'ev':if(!ID_RE.test(String(i)))return;this._set('telemetry/'+t+'/events/'+i,d.d,false);this.prune(t);break;
      case 'evb':{if(!Array.isArray(d.d))return;let go=false;d.d.slice(0,12).forEach((e,j)=>{if(!e||typeof e.type!=='string')return;this._set('telemetry/'+t+'/events/'+String(d.i||'x').replace(/[^\w-]/g,'')+'_'+j,{t:+e.t||Date.now(),type:e.type.slice(0,20),info:String(e.info||'').slice(0,80),n:String(e.n||'').slice(0,20),m:String(e.m||'').slice(0,8)},false);if(e.type==='login'||e.type==='start'||e.type==='register')go=true;});this.prune(t);if(go)this.resend(t);break;}
      case 'sv':this._set('saves/'+t,d.d,false);break;
      case 'ord':if(!ID_RE.test(String(i)))return;if(!this._get('orders/'+i))this._set('orders/'+i,d.d,false);break;
      case 'ack':this._set('players/'+t+'/ack',d.d,false);break;
    }
  },
  prune(t){const ev=((this.tree.telemetry[t]||{}).events)||{};const ks=Object.keys(ev);if(ks.length>80){ks.sort((a,b)=>(ev[a].t||0)-(ev[b].t||0));for(const k of ks.slice(0,ks.length-80))delete ev[k];}},
  pub(t,o){try{fetch(RELAYU+'/'+this.base()+'-d-'+String(t).replace(/-/g,''),{method:'POST',body:JSON.stringify(o)}).catch(()=>{});}catch(e){}},
  out(p,d){
    const m=String(p).match(/^players\/([^/]+)\/(bonus|ban|adjust|cmd)$/);if(!m)return;
    const t=m[1];
    if(m[2]==='bonus'&&d)this.pub(t,Object.assign({k:'bonus'},d));
    else if(m[2]==='adjust'&&d)this.pub(t,Object.assign({k:'adj'},d));
    else if(m[2]==='cmd'&&d)this.pub(t,Object.assign({k:'cmd'},d));
    else if(m[2]==='ban')this.pub(t,{k:'ban',on:d===true});
  },
  pubAll(o){return fetch(RELAYU+'/'+this.base()+'-d-all',{method:'POST',body:JSON.stringify(o)}).then(r=>r.ok).catch(()=>false);},
  resend(t){
    if(Date.now()-(this.lastResend[t]||0)<60000)return;this.lastResend[t]=Date.now();
    const p=this._get('players/'+t)||{};
    if(p.bonus&&p.ack!==p.bonus.id)this.pub(t,Object.assign({k:'bonus'},p.bonus));
    if(p.ban===true)this.pub(t,{k:'ban',on:true});
    if(p.adjust)this.pub(t,Object.assign({k:'adj'},p.adjust));
  },
  async put(p,d){this._set(p,d,false);this.out(p,d);return d;},
  async patch(p,d){this._set(p,d,true);return d;},
  async del(p){this._set(p,null,false);this.out(p,null);return null;}
});

const DB=RELAYU?RelayDB:(LIVE?RealDB:MemDB);
