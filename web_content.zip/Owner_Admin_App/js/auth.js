/* ============================================================
   حماية المالك
   - إن وُجد apiKey: تسجيل دخول Firebase Authentication (بريد + كلمة مرور) ويُرسل idToken مع كل طلب.
   - وإلا: رمز PIN محلي (يُحفظ كبصمة SHA-256 على الجهاز) — يحمي الواجهة فقط.
   ملاحظة مهمة: الحماية الحقيقية للبيانات تتم بقواعد Firebase (FIREBASE_RULES_ADMIN.json) وليس بالواجهة.
   ============================================================ */
const Auth={
  mode:(FBC.apiKey&&LIVE)?'firebase':'pin',
  idToken:null,refreshToken:null,exp:0,email:'',
  async fbPost(url,body,form){
    const r=await fetch(url,{method:'POST',headers:{'Content-Type':form?'application/x-www-form-urlencoded':'application/json'},body:form?new URLSearchParams(body).toString():JSON.stringify(body)});
    const j=await r.json();if(!r.ok)throw new Error((j.error&&j.error.message)||'error');return j;
  },
  async login(email,pass){
    const j=await this.fbPost('https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key='+encodeURIComponent(FBC.apiKey),{email,password:pass,returnSecureToken:true});
    if(window.OWNER&&OWNER.email&&OWNER.email.toLowerCase()!==String(j.email).toLowerCase())throw new Error('NOT_OWNER');
    this.set(j.idToken,j.refreshToken,+j.expiresIn,j.email);
  },
  set(id,ref,exp,email){this.idToken=id;this.refreshToken=ref;this.exp=Date.now()+(exp-120)*1000;this.email=email||this.email;DB.tok=id;},
  async refresh(){
    if(!this.refreshToken)throw new Error('no refresh');
    const j=await this.fbPost('https://securetoken.googleapis.com/v1/token?key='+encodeURIComponent(FBC.apiKey),{grant_type:'refresh_token',refresh_token:this.refreshToken},true);
    this.set(j.id_token,j.refresh_token,+j.expires_in);
    try{if(localStorage.getItem('adm_rt'))localStorage.setItem('adm_rt',this.refreshToken);}catch(e){}
  },
  /* تحديث تلقائي قبل الانتهاء */
  keepAlive(onNew){setInterval(async()=>{if(this.mode==='firebase'&&this.refreshToken&&Date.now()>this.exp){try{await this.refresh();onNew&&onNew();}catch(e){}}},30000);},
  /* PIN */
  async pinStored(){try{return (window.OWNER&&OWNER.pinHash)||localStorage.getItem('adm_pin')||'';}catch(e){return '';}},
  async pinSet(pin){const h=await sha256('adm|'+pin);try{localStorage.setItem('adm_pin',h);}catch(e){}return h;},
  async pinCheck(pin){return (await sha256('adm|'+pin))===(await this.pinStored());},
  fails:0,lockUntil:0,
  logout(){this.idToken=this.refreshToken=null;DB.tok=null;try{localStorage.removeItem('adm_rt');sessionStorage.removeItem('adm_ok');}catch(e){}}
};
