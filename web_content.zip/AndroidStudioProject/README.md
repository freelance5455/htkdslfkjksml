# Mansoor Niazi Calculator (Android)

A native Android Studio project for a dark calculator UI inspired by the supplied screenshot. It includes arithmetic, percent, delete, clear, result, history, and an About screen with the creator details supplied in chat. No TikTok branding is included.

## Build the APK
1. Install Android Studio (current stable) with Android SDK Platform 35.
2. Open this folder (`MansoorNiaziCalculator`) in Android Studio.
3. Allow Gradle to sync. The project uses Android Gradle Plugin 8.7.3.
4. Choose **Build > Build APK(s)**.
5. The debug APK will be created at `app/build/outputs/apk/debug/app-debug.apk`.

This environment did not have the Android SDK or Gradle installed, so an APK could not be compiled here. The complete source project is included so it can be built in Android Studio.

## Package
`com.mansoor.niazi.calculator`
