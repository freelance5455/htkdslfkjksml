package com.mansoor.niazi.calculator;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.text.DecimalFormat;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private LinearLayout root, keys;
    private TextView expressionView, resultView;
    private String expression = "";
    private boolean justEvaluated = false;
    private final ArrayList<String> history = new ArrayList<>();
    private final int BG = Color.rgb(5,5,5), PANEL = Color.rgb(23,23,23),
            OP = Color.rgb(62,62,65), BLUE = Color.rgb(41,98,255), WHITE = Color.rgb(245,245,247);

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(PANEL);
        getWindow().getDecorView().setSystemUiVisibility(0);
        buildUi();
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        setContentView(root);

        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setPadding(dp(22), dp(18), dp(22), dp(12));
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(toolbar, new LinearLayout.LayoutParams(-1, dp(58)));
        TextView brand = text("MN", 17, WHITE, true);
        brand.setGravity(Gravity.CENTER);
        GradientDrawable badge = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{BLUE, Color.rgb(0,210,255)});
        badge.setCornerRadius(dp(8)); brand.setBackground(badge);
        toolbar.addView(brand, new LinearLayout.LayoutParams(dp(38), dp(32)));
        TextView title = text("  Mansoor Niazi", 16, WHITE, true);
        toolbar.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        TextView historyBtn = text("◷", 28, WHITE, false);
        historyBtn.setGravity(Gravity.CENTER);
        toolbar.addView(historyBtn, new LinearLayout.LayoutParams(dp(44), dp(42)));
        historyBtn.setOnClickListener(v -> showHistory());
        TextView menu = text("⋮", 28, WHITE, false);
        menu.setGravity(Gravity.CENTER);
        toolbar.addView(menu, new LinearLayout.LayoutParams(dp(30), dp(42)));
        menu.setOnClickListener(v -> showAbout());

        LinearLayout display = new LinearLayout(this);
        display.setOrientation(LinearLayout.VERTICAL);
        display.setGravity(Gravity.BOTTOM | Gravity.RIGHT);
        display.setPadding(dp(24), dp(12), dp(24), dp(24));
        root.addView(display, new LinearLayout.LayoutParams(-1, 0, 1.0f));
        expressionView = text("", 26, Color.LTGRAY, false);
        expressionView.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        display.addView(expressionView, new LinearLayout.LayoutParams(-1, dp(50)));
        resultView = text("0", 52, WHITE, false);
        resultView.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        resultView.setSingleLine(true);
        resultView.setTextSize(52);
        display.addView(resultView, new LinearLayout.LayoutParams(-1, dp(72)));

        keys = new LinearLayout(this);
        keys.setOrientation(LinearLayout.VERTICAL);
        keys.setPadding(dp(16), dp(14), dp(16), dp(14));
        keys.setBackgroundColor(PANEL);
        root.addView(keys, new LinearLayout.LayoutParams(-1, dp(410)));
        String[][] rows = {
            {"C", "%", "⌫", "÷"},
            {"7", "8", "9", "×"},
            {"4", "5", "6", "−"},
            {"1", "2", "3", "+"},
            {"00", "0", ".", "="}
        };
        for (int r=0; r<rows.length; r++) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            keys.addView(row, new LinearLayout.LayoutParams(-1, 0, 1));
            for (int c=0; c<4; c++) {
                String label = rows[r][c];
                Button b = new Button(this);
                b.setText(label);
                b.setTextSize(label.length()>1 && !label.equals("00") ? 24 : 28);
                b.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
                b.setTextColor((c==3 || label.equals("=")) ? WHITE : WHITE);
                b.setAllCaps(false);
                b.setStateListAnimator(null);
                b.setPadding(0,0,0,0);
                b.setBackground(makeBg((c==3) ? (label.equals("=") ? BLUE : OP) : Color.TRANSPARENT,
                        (c==3) ? 100 : 12));
                LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -1, 1);
                p.setMargins(dp(3), dp(3), dp(3), dp(3));
                row.addView(b,p);
                b.setOnClickListener(v -> press(label));
            }
        }
    }

    private GradientDrawable makeBg(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radiusDp)); return d;
    }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL)); return t;
    }
    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }

    private void press(String key) {
        if (key.equals("C")) { expression=""; resultView.setText("0"); expressionView.setText(""); justEvaluated=false; return; }
        if (key.equals("⌫")) {
            if (!expression.isEmpty()) expression = expression.substring(0, expression.length()-1);
            expressionView.setText(expression); resultView.setText(expression.isEmpty() ? "0" : expression); justEvaluated=false; return;
        }
        if (key.equals("=")) {
            if (expression.isEmpty()) return;
            try {
                double value = new Parser(expression).parse();
                String formatted = new DecimalFormat("0.##########").format(value);
                history.add(expression + " = " + formatted);
                expressionView.setText(expression + " =");
                resultView.setText(formatted); expression = formatted; justEvaluated=true;
            } catch (Exception e) {
                resultView.setText("Error");
            }
            return;
        }
        if (key.equals("%")) {
            if (!expression.isEmpty()) expression += "%";
        } else {
            if (justEvaluated && "0123456789.00".contains(key)) { expression = ""; expressionView.setText(""); }
            expression += key; justEvaluated=false;
        }
        expressionView.setText(expression);
        resultView.setText(expression.isEmpty() ? "0" : expression);
    }
    private void showHistory() {
        if (history.isEmpty()) { Toast.makeText(this, "No calculation history yet", Toast.LENGTH_SHORT).show(); return; }
        StringBuilder b = new StringBuilder("Calculation history\n\n");
        for (int i=history.size()-1; i>=0; i--) b.append(history.get(i)).append("\n");
        new android.app.AlertDialog.Builder(this).setTitle("History").setMessage(b.toString())
            .setPositiveButton("Close", null).setNeutralButton("Clear", (d,w)->history.clear()).show();
    }
    private void showAbout() {
        new android.app.AlertDialog.Builder(this).setTitle("د منصور نیازي ماشین حساب")
            .setMessage("جوړونکی: منصور نیازي\nد محمد جميل نيازي زوی، د جمعه خان نيازي لمسی\nوردک ولایت، بند چک ولسوالۍ، عربانو دره، خانک خېلو کلی\n\nMansoor Niazi Calculator")
            .setPositiveButton("سمه ده", null).show();
    }

    // Recursive-descent calculator parser: +, −, ×, ÷, %, parentheses and unary signs.
    static class Parser {
        private final String s; private int p=0;
        Parser(String input) { s=input.replace("×","*").replace("÷","/").replace("−","-").replace(" ",""); }
        double parse() { double x=expression(); if (p<s.length()) throw new RuntimeException(); return x; }
        double expression() { double x=term(); while(p<s.length()) { char c=s.charAt(p); if(c=='+'){p++;x+=term();} else if(c=='-'){p++;x-=term();} else break; } return x; }
        double term() { double x=factor(); while(p<s.length()) { char c=s.charAt(p); if(c=='*'){p++;x*=factor();} else if(c=='/'){p++;double y=factor(); if(y==0)throw new ArithmeticException(); x/=y;} else break; } return x; }
        double factor() {
            if(p>=s.length()) throw new RuntimeException();
            if(s.charAt(p)=='+'){p++;return factor();}
            if(s.charAt(p)=='-'){p++;return -factor();}
            if(s.charAt(p)=='('){p++;double x=expression();if(p>=s.length()||s.charAt(p)!=')')throw new RuntimeException();p++;return x;}
            int start=p; boolean dot=false;
            while(p<s.length() && (Character.isDigit(s.charAt(p)) || s.charAt(p)=='.')) { if(s.charAt(p)=='.'){if(dot)throw new RuntimeException();dot=true;} p++; }
            if(start==p) throw new RuntimeException();
            double x=Double.parseDouble(s.substring(start,p));
            if(p<s.length() && s.charAt(p)=='%'){p++;x/=100.0;}
            return x;
        }
    }
}
