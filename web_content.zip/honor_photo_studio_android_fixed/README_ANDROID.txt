HONOR PHOTO STUDIO AI — ANDROID GALLERY PICKER FIX

This is an Android Studio source project, not a prebuilt APK.

WHAT WAS FIXED
- MainActivity implements WebChromeClient.onShowFileChooser.
- The web app's HTML file input can now launch Android's native image picker.
- Supports images selected through Android's document/photo picker.

IMPORTANT SETUP
1. Deploy the contents of ai_backend/ to a trusted Python host with HTTPS.
2. Configure OPENAI_API_KEY as a server-side environment secret. Never put it in this app.
3. Install Python packages from ai_backend/requirements.txt and run:
   uvicorn server:app --host 0.0.0.0 --port 8000
   Use the hosting provider's required start command/port configuration.
4. In app/src/main/java/com/honor/photostudio/MainActivity.kt, replace
   https://YOUR-DEPLOYED-BACKEND.example.com/
   with the actual HTTPS address of your deployed backend, including trailing slash.
5. Open this folder in Android Studio, allow Gradle sync, then Build > Build APK(s).
6. Test gallery selection and AI enhancement on the HONOR 400 Pro.

NOTES
- The original ZIP contains a PWA and Python backend, not an Android Studio project.
- This package adds a native Android WebView file chooser wrapper around that app.
- AI processing remains server-side and requires an API key and internet connection.
- Generative AI may alter small facial details; compare output with the original.
- No APK is included because this environment cannot perform a verified Android SDK build.
