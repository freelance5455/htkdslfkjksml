# Carreira de Craque v1.62.7 — LaLiga selecionável

- Adicionada Espanha ao seletor **Escolher País e Clube**.
- Cadastrados os 20 clubes solicitados pelo usuário, com avaliação por estrelas e URLs de escudos.
- Adicionada a seleção de carreira profissional em LaLiga.
- Gerado calendário ida e volta com 20 clubes, 38 rodadas e 380 partidas.
- Classificação, simulação de resultados e progressão de temporada usam o motor de partidas e a tabela existentes.
- LaLiga não participa indevidamente da Copa do Brasil nem das rotinas de sincronização das divisões brasileiras.
- Preservadas as ligas e os sistemas existentes.

## Limitações conhecidas

- Os links de escudos são usados como imagens remotas. O ambiente de edição não conseguiu baixar os arquivos para armazenamento local; se algum servidor bloquear hotlink ou mudar o endereço, o escudo poderá não carregar.
- A base de jogadores existente não contém elencos espanhóis completos. Esta atualização não inventa listas de jogadores licenciados; os elencos completos precisam de uma base específica.
