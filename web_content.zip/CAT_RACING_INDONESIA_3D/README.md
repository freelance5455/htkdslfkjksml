# CAT RACING INDONESIA 3D

Prototype game balapan 3D mobile berbasis Three.js.

## Menjalankan
- Buka `index.html` melalui server lokal atau hosting HTTPS.
- Koneksi internet diperlukan untuk memuat Three.js dari CDN.
- Di Android, gunakan Chrome versi terbaru.
- Sentuh MULAI BALAPAN; tahan GAS, gunakan kiri/kanan, dan tekan NITRO.

## Kontrol
- Layar sentuh: kiri, kanan, gas, rem, nitro.
- Keyboard: panah / WASD, Space untuk nitro.

## Catatan teknis
Ini adalah prototype playable, bukan APK final dan bukan game konsol penuh. Model karakter/motor dibuat secara prosedural dari geometri 3D; suara mesin adalah sintesis Web Audio sementara, bukan rekaman mesin motor. Untuk produksi, ganti model dengan aset GLB berlisensi, gunakan rekaman audio berlisensi, lakukan profiling pada perangkat Android target, dan uji build APK.

## Jalur menuju APK Android
1. Pasang Node.js dan Android Studio.
2. Buat proyek Capacitor baru dengan `npm create @capacitor/app`.
3. Salin `index.html` ke folder web proyek yang ditentukan Capacitor.
4. Jalankan `npm install @capacitor/android` lalu `npx cap add android`.
5. Jalankan `npx cap sync android` dan `npx cap open android`.
6. Di Android Studio, uji pada perangkat fisik lalu pilih Build > Build Bundle(s) / APK(s) > Build APK(s).

Pastikan aplikasi memiliki koneksi internet atau bundel Three.js secara lokal sebelum distribusi offline.
