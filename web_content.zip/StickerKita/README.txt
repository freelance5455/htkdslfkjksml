StickerKita — prototipe tombol diperbaiki

Perbaikan/interaksi demo:
- Navigasi Beranda, Buat, Saldo, Profil.
- Pencarian stiker dan filter kategori.
- Simpan file stiker lokal dan tampilkan koleksi di profil.
- Ganti foto profil dan nama profil.
- Tombol Ikuti/Mengikuti dengan hitungan lokal.
- Pilihan penarikan Rp5.000 atau Rp10.000 dan validasi formulir.

PENTING: ini masih prototipe HTML. Login Google, unggah server, iklan AdMob, saldo sungguhan, sinkronisasi follow, ekspor stiker WhatsApp, dan pembayaran nyata belum terhubung. Perubahan pada HTML belum otomatis mengubah APK; APK perlu dibangun ulang melalui proyek Android/pembungkus yang digunakan.
