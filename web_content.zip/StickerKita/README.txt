StickerKita — prototipe UI awal
================================
Isi:
- index.html: prototipe tampilan responsif untuk HP Android.
- Fitur demo: katalog stiker, navigasi, formulir draf upload, formulir penarikan dengan validasi minimum Rp10.000.

Penting:
Ini BELUM APK dan belum aplikasi produksi. Iklan, akun, unggah ke server, unduhan stiker WhatsApp, saldo nyata, backend, anti-penipuan, dan pembayaran e-wallet belum terhubung. Angka saldo tidak menghasilkan atau mengirim uang. Jangan mengumpulkan data pembayaran sungguhan melalui demo ini.

Cara melihat dari HP:
1. Ekstrak ZIP.
2. Buka index.html dengan browser atau editor HTML yang mendukung preview.
3. Untuk membuat APK produksi, lanjutkan dengan project Android (misalnya Android Studio/Gradle atau layanan build cloud), backend aman, dan integrasi iklan/pembayaran yang disetujui.
