'use strict';
/* مشوار — نسخة تجريبية محلية. كل البيانات تُحفظ في localStorage داخل الهاتف. */
var KEY = 'mishwar.demo.v1';
var BASE = 20, INCLUDED = 3, MAXPAX = 7, EXTRA_RATE = 0.2, COMM = 0.12, MAXROUNDS = 5;
var CARS = {
  eco:    { name: 'اقتصادية', cap: 4 },
  comfort:{ name: 'مريحة',    cap: 4 },
  family: { name: 'عائلية',   cap: 7 }
};
var PLACES = ['وسط المدينة','ميدان الشهداء','مطار معيتيقة','جامعة طرابلس','طريق الشط','سوق الجمعة','حي الأندلس','عين زارة','تاجوراء','جنزور'];
var DRIVER = 'أحمد المبروك';
var state, tab = 'rider', form = { from: '', to: '', pax: 1, car: 'eco', offer: '' }, errs = {};

function money(n) { return (Math.round(n * 100) / 100).toFixed(2).replace(/\.00$/, '') + ' د.ل'; }
function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
function pax(n) { return n === 1 ? 'راكب واحد' : n === 2 ? 'راكبان' : n + (n < 11 ? ' ركاب' : ' راكبًا'); }

function fare(p) {
  var extraPax = Math.max(0, p - INCLUDED);
  var extra = extraPax * BASE * EXTRA_RATE;
  return { extraPax: extraPax, extra: extra, total: BASE + extra };
}
function commission(price) { return Math.round(price * COMM * 100) / 100; }

function seed() {
  function mk(id, from, to, p, car, final, status, offers) {
    var f = fare(p);
    return { id: id, from: from, to: to, pax: p, car: car, base: BASE, extra: f.extra, fare: f.total,
      offers: offers, status: status, final: final, turn: status === 'negotiating' ? 'driver' : null,
      commission: final ? commission(final) : 0, created: Date.now() - id * 3600000 * 5, demo: true };
  }
  return { seq: 4, trips: [
    mk(1, 'وسط المدينة', 'مطار معيتيقة', 2, 'eco', 20, 'completed', [{ by: 'rider', price: 20 }, { by: 'driver', price: 20 }]),
    mk(2, 'جامعة طرابلس', 'حي الأندلس', 5, 'family', 30, 'completed', [{ by: 'rider', price: 28 }, { by: 'driver', price: 32 }, { by: 'rider', price: 30 }, { by: 'driver', price: 30 }]),
    mk(3, 'عين زارة', 'ميدان الشهداء', 4, 'comfort', 28, 'negotiating', [{ by: 'rider', price: 24 }])
  ]};
}
function load() {
  try { var s = JSON.parse(localStorage.getItem(KEY)); if (s && s.trips) return s; } catch (e) {}
  return seed();
}
function save() { try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (e) { toast('تعذّر حفظ البيانات على الهاتف.'); } }
function toast(m) { var t = document.getElementById('toast'); t.textContent = m; t.className = 'show'; clearTimeout(toast.h); toast.h = setTimeout(function () { t.className = ''; }, 2600); }

function parsePrice(v) {
  var s = String(v).replace(/[٠-٩]/g, function (d) { return d.charCodeAt(0) - 1632; }).replace('٫', '.').replace(',', '.').trim();
  var n = Number(s);
  if (s === '' || isNaN(n)) return { err: 'أدخل سعرًا صحيحًا بالأرقام.' };
  if (n < 5) return { err: 'السعر منخفض جدًا. الحد الأدنى 5 دنانير.' };
  if (n > 500) return { err: 'السعر مرتفع جدًا. الحد الأعلى 500 دينار.' };
  return { v: Math.round(n * 100) / 100 };
}
function find(id) { return state.trips.filter(function (t) { return t.id === id; })[0]; }
function badge(t) {
  if (t.status === 'negotiating') return '<span class="badge b-neg">قيد التفاوض</span>';
  if (t.status === 'confirmed') return '<span class="badge b-ok">مؤكدة</span>';
  if (t.status === 'completed') return '<span class="badge b-done">مكتملة</span>';
  return '<span class="badge b-bad">' + (t.status === 'rejected' ? 'مرفوضة' : 'ملغاة') + '</span>';
}

/* ---------- عمليات التفاوض ---------- */
function createTrip() {
  errs = {};
  var f = form;
  if (!f.from.trim() || !f.to.trim()) errs.main = 'حدّد نقطة الانطلاق ونقطة الوصول.';
  else if (f.from.trim() === f.to.trim()) errs.main = 'نقطة الانطلاق والوصول متطابقتان. اختر وجهة مختلفة.';
  else if (f.pax < 1 || f.pax > MAXPAX) errs.main = 'عدد الركاب يجب أن يكون بين 1 و 7.';
  else if (f.pax > CARS[f.car].cap) errs.main = 'سيارة «' + CARS[f.car].name + '» تتسع لـ ' + CARS[f.car].cap + ' ركاب فقط. اختر سيارة عائلية.';
  var fr = fare(f.pax), price = fr.total;
  if (!errs.main && String(f.offer).trim() !== '') {
    var p = parsePrice(f.offer);
    if (p.err) errs.main = p.err; else price = p.v;
  }
  if (errs.main) return render();
  var t = { id: state.seq++, from: f.from.trim(), to: f.to.trim(), pax: f.pax, car: f.car, base: BASE, extra: fr.extra,
    fare: fr.total, offers: [{ by: 'rider', price: price }], status: 'negotiating', final: null, turn: 'driver', commission: 0, created: Date.now() };
  state.trips.unshift(t); save();
  form = { from: '', to: '', pax: 1, car: 'eco', offer: '' };
  toast('أُرسل عرضك للسائق. افتح تبويب السائق للرد.'); render();
}
function accept(id, who) {
  var t = find(id); if (!t || t.status !== 'negotiating' || t.turn !== who) return;
  var last = t.offers[t.offers.length - 1];
  t.final = last.price; t.commission = commission(t.final); t.status = 'confirmed'; t.turn = null; save();
  toast('اتفق الطرفان على ' + money(t.final) + '. الرحلة مؤكدة.'); render();
}
function counter(id, who) {
  var t = find(id); if (!t || t.status !== 'negotiating' || t.turn !== who) return;
  var inp = document.getElementById('c' + id), p = parsePrice(inp ? inp.value : '');
  if (t.offers.length >= MAXROUNDS) { errs[id] = 'انتهت جولات التفاوض الخمس. اقبل العرض أو ارفضه.'; return render(); }
  if (p.err) { errs[id] = p.err; return render(); }
  if (p.v === t.offers[t.offers.length - 1].price) { errs[id] = 'هذا هو السعر المعروض حاليًا. اضغط «قبول» أو اقترح سعرًا مختلفًا.'; return render(); }
  delete errs[id];
  t.offers.push({ by: who, price: p.v }); t.turn = who === 'rider' ? 'driver' : 'rider'; save();
  toast('أُرسل العرض المضاد.'); render();
}
function reject(id, who) {
  var t = find(id); if (!t || t.status !== 'negotiating') return;
  t.status = who === 'driver' ? 'rejected' : 'cancelled'; t.turn = null; save(); toast('أُنهي التفاوض.'); render();
}
function complete(id) { var t = find(id); if (t && t.status === 'confirmed') { t.status = 'completed'; save(); toast('اكتملت الرحلة وسُجّلت العمولة.'); render(); } }
function resetDemo() { if (confirm('سيتم حذف كل الرحلات واستعادة البيانات التجريبية. متابعة؟')) { state = seed(); save(); toast('أُعيدت البيانات التجريبية.'); render(); } }

/* ---------- عرض ---------- */
function offersLog(t) {
  var rounds = t.offers.map(function (o, i) {
    return '<li' + (i === t.offers.length - 1 ? ' class="last"' : '') + '><span>الجولة ' + (i + 1) + ' — ' + (o.by === 'rider' ? 'الراكب' : 'السائق') + '</span><span>' + money(o.price) + '</span></li>';
  }).join('');
  return '<h3>سجل العروض (' + t.offers.length + ' من ' + MAXROUNDS + ')</h3><ul class="log">' + rounds + '</ul>';
}
function summary(t) {
  var price = t.final != null ? t.final : t.offers[t.offers.length - 1].price;
  var r = '<div class="kv"><span>عدد الركاب</span><span>' + t.pax + '</span>' +
    '<span>السعر الأساسي</span><span>' + money(t.base) + '</span>' +
    '<span>رسوم الركاب الإضافيين</span><span>' + money(t.extra) + '</span>' +
    '<span>السعر المقترح من النظام</span><span>' + money(t.fare) + '</span>' +
    '<span>' + (t.final != null ? 'السعر النهائي' : 'آخر عرض') + '</span><span>' + money(price) + '</span>';
  if (t.final != null) r += '<span>عمولة المنصة 12%</span><span>' + money(t.commission) + '</span><span>صافي السائق</span><span>' + money(t.final - t.commission) + '</span>';
  return r + '</div>';
}
function negBox(t, who) {
  var last = t.offers[t.offers.length - 1], full = t.offers.length >= MAXROUNDS;
  var h = '<h3>' + (who === 'driver' ? 'عرض الراكب' : 'عرض السائق') + ': ' + money(last.price) + '</h3>';
  if (!full) h += '<input id="c' + t.id + '" inputmode="decimal" placeholder="اقترح سعرًا مضادًا (د.ل)">';
  else h += '<p class="note">هذه الجولة الأخيرة: اقبل العرض أو ارفضه.</p>';
  if (errs[t.id]) h += '<div class="err">' + esc(errs[t.id]) + '</div>';
  h += '<div class="btns"><button class="btn" data-a="accept" data-id="' + t.id + '" data-w="' + who + '">قبول ' + money(last.price) + '</button>';
  if (!full) h += '<button class="btn sec" data-a="counter" data-id="' + t.id + '" data-w="' + who + '">عرض مضاد</button>';
  return h + '<button class="btn ghost" data-a="reject" data-id="' + t.id + '" data-w="' + who + '">' + (who === 'driver' ? 'رفض' : 'إلغاء') + '</button></div>';
}
function tripCard(t, role) {
  var h = '<div class="card"><div class="trip-h"><b>' + esc(t.from) + ' ← ' + esc(t.to) + '</b>' + badge(t) + '</div>' +
    '<div class="note">سيارة ' + CARS[t.car].name + ' · ' + pax(t.pax) + (t.demo ? ' · بيانات تجريبية' : '') + '</div>' + summary(t) + offersLog(t);
  if (t.status === 'negotiating') {
    if (t.turn === role) h += negBox(t, role);
    else h += '<p class="note">بانتظار رد ' + (role === 'rider' ? 'السائق — بدّل إلى تبويب السائق للرد.' : 'الراكب — بدّل إلى تبويب الراكب للرد.') + '</p>';
  }
  if (role === 'driver' && t.status === 'confirmed') h += '<button class="btn" data-a="complete" data-id="' + t.id + '">إنهاء الرحلة</button>';
  return h + '</div>';
}
function riderView() {
  var fr = fare(form.pax), car = CARS[form.car];
  var cars = Object.keys(CARS).map(function (k) {
    var ok = form.pax <= CARS[k].cap;
    return '<button class="car ' + (form.car === k && ok ? 'on' : '') + (ok ? '' : ' off') + '" data-a="car" data-k="' + k + '"><span><b>' + CARS[k].name + '</b><small>حتى ' + CARS[k].cap + ' ركاب</small></span><span>' + (ok ? (form.car === k ? '✓' : '') : 'لا تتسع') + '</span></button>';
  }).join('');
  var dl = '<datalist id="pl">' + PLACES.map(function (p) { return '<option value="' + p + '">'; }).join('') + '</datalist>';
  var h = '<div class="card"><h2>رحلة جديدة</h2>' + dl +
    '<label>من</label><input id="from" list="pl" placeholder="نقطة الانطلاق" value="' + esc(form.from) + '">' +
    '<label>إلى</label><input id="to" list="pl" placeholder="الوجهة" value="' + esc(form.to) + '">' +
    '<label>عدد الركاب (حتى 7)</label><div class="pax"><button data-a="pm" data-d="-1" aria-label="إنقاص">−</button><output>' + form.pax + '</output><button data-a="pm" data-d="1" aria-label="زيادة">+</button></div>' +
    '<label>فئة السيارة</label><div class="cars">' + cars + '</div>' +
    '<label>عرضك للسائق (اختياري)</label><input id="offer" inputmode="decimal" placeholder="اتركه فارغًا لاعتماد ' + money(fr.total) + '" value="' + esc(form.offer) + '">' +
    '<div class="bill"><div><span>السعر الأساسي (يشمل 3 ركاب)</span><span>' + money(BASE) + '</span></div>' +
    '<div><span>رسوم ' + fr.extraPax + ' راكب إضافي (20% لكل راكب)</span><span>' + money(fr.extra) + '</span></div>' +
    '<div class="tot"><span>الإجمالي المقترح</span><span>' + money(fr.total) + '</span></div>' +
    '<div><span>عمولة المنصة 12% (تُخصم من السائق)</span><span>' + money(commission(fr.total)) + '</span></div></div>' +
    (errs.main ? '<div class="err">' + esc(errs.main) + '</div>' : '') +
    '<button class="btn" data-a="create">أرسل العرض للسائق</button></div>';
  var mine = state.trips;
  h += '<h2>رحلاتي</h2>' + (mine.length ? mine.map(function (t) { return tripCard(t, 'rider'); }).join('') : '<div class="card empty">لا توجد رحلات بعد. أنشئ أول رحلة من الأعلى.</div>');
  return h;
}
function driverView() {
  var inc = state.trips.filter(function (t) { return t.status === 'negotiating'; });
  var act = state.trips.filter(function (t) { return t.status === 'confirmed'; });
  var old = state.trips.filter(function (t) { return t.status !== 'negotiating' && t.status !== 'confirmed'; });
  var earn = old.filter(function (t) { return t.status === 'completed'; }).reduce(function (a, t) { return a + t.final - t.commission; }, 0);
  var h = '<div class="card"><h2>مرحبًا ' + DRIVER + '</h2><div class="note">حساب سائق تجريبي — لا يوجد تسجيل دخول حقيقي.</div><div class="kv"><span>أرباح الرحلات المكتملة (بعد العمولة)</span><span>' + money(earn) + '</span></div></div>';
  h += '<h2>طلبات قيد التفاوض</h2>' + (inc.length ? inc.map(function (t) { return tripCard(t, 'driver'); }).join('') : '<div class="card empty">لا توجد طلبات الآن.</div>');
  h += '<h2>رحلات مؤكدة</h2>' + (act.length ? act.map(function (t) { return tripCard(t, 'driver'); }).join('') : '<div class="card empty">لا توجد رحلات مؤكدة.</div>');
  if (old.length) h += '<h2>السجل</h2>' + old.map(function (t) { return tripCard(t, 'driver'); }).join('');
  return h;
}
function adminView() {
  var done = state.trips.filter(function (t) { return t.status === 'completed'; });
  var conf = state.trips.filter(function (t) { return t.status === 'confirmed'; });
  var vol = done.reduce(function (a, t) { return a + t.final; }, 0), com = done.reduce(function (a, t) { return a + t.commission; }, 0);
  var rows = state.trips.map(function (t) {
    return '<div class="card"><div class="trip-h"><b>#' + t.id + ' ' + esc(t.from) + ' ← ' + esc(t.to) + '</b>' + badge(t) + '</div>' + summary(t) + '</div>';
  }).join('');
  return '<div class="stats"><div class="stat"><b>' + state.trips.length + '</b><span>إجمالي الرحلات</span></div><div class="stat"><b>' + done.length + '</b><span>مكتملة (' + conf.length + ' مؤكدة)</span></div>' +
    '<div class="stat"><b>' + money(vol) + '</b><span>قيمة الرحلات المكتملة</span></div><div class="stat"><b>' + money(com) + '</b><span>عمولة المنصة 12%</span></div></div>' +
    '<div class="card"><h2>الإعدادات المعتمدة</h2><div class="kv"><span>السعر الأساسي (3 ركاب)</span><span>20 د.ل</span><span>الراكب الإضافي</span><span>+4 د.ل (20%)</span><span>الحد الأقصى للركاب</span><span>7</span><span>جولات التفاوض</span><span>5</span><span>العمولة</span><span>12%</span></div>' +
    '<button class="btn ghost" data-a="reset">استعادة البيانات التجريبية</button></div><h2>كل الرحلات</h2>' + rows;
}
function render() {
  var v = document.getElementById('view');
  v.innerHTML = tab === 'rider' ? riderView() : tab === 'driver' ? driverView() : adminView();
  Array.prototype.forEach.call(document.querySelectorAll('.tabs button'), function (b) { b.className = b.dataset.tab === tab ? 'on' : ''; });
}

/* ---------- أحداث ---------- */
document.addEventListener('input', function (e) {
  var id = e.target.id;
  if (id === 'from' || id === 'to' || id === 'offer') form[id] = e.target.value;
});
document.addEventListener('click', function (e) {
  var tb = e.target.closest('.tabs button');
  if (tb) { tab = tb.dataset.tab; errs = {}; window.scrollTo(0, 0); return render(); }
  var b = e.target.closest('[data-a]'); if (!b) return;
  var a = b.dataset.a, id = Number(b.dataset.id);
  if (a === 'pm') {
    var n = form.pax + Number(b.dataset.d);
    if (n > MAXPAX) { errs.main = 'الحد الأقصى 7 ركاب في الرحلة الواحدة.'; return render(); }
    if (n < 1) return;
    errs = {}; form.pax = n;
    if (n > CARS[form.car].cap) { form.car = 'family'; toast('تم اختيار سيارة عائلية لأن العدد يتجاوز 4 ركاب.'); }
    return render();
  }
  if (a === 'car') {
    var k = b.dataset.k;
    if (form.pax > CARS[k].cap) { errs.main = 'سيارة «' + CARS[k].name + '» لا تتسع لـ ' + pax(form.pax) + '. اختر سيارة عائلية.'; return render(); }
    errs = {}; form.car = k; return render();
  }
  if (a === 'create') return createTrip();
  if (a === 'accept') return accept(id, b.dataset.w);
  if (a === 'counter') return counter(id, b.dataset.w);
  if (a === 'reject') return reject(id, b.dataset.w);
  if (a === 'complete') return complete(id);
  if (a === 'reset') return resetDemo();
});

state = load();
render();
