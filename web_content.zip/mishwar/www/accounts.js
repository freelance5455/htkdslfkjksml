'use strict';
/* مشوار v0.2 — الحسابات والعمولات + الإلغاء وتسجيل السبب. يُحمَّل قبل app.js */
var REASONS = ['تغيير الخطة','تأخر السائق','تعذر الوصول إلى الراكب','عدم الاتفاق على السعر','مشكلة في السيارة','خطأ في الطلب','سبب آخر'];
var ROLE_AR = { rider: 'الراكب', driver: 'السائق', admin: 'الإدارة' };
var SEED_DRIVERS = [
  { id: 'd1', name: 'أحمد المبروك', phone: '0912345678', car: 'تويوتا كورولا', cat: 'eco', model: '2018', color: 'أبيض', plate: '12-3456', seats: 4, status: 'approved', demo: true, history: [] },
  { id: 'd2', name: 'سالم الفيتوري', phone: '0925551234', car: 'هيونداي ستاريا', cat: 'family', model: '2020', color: 'رمادي', plate: '45-7789', seats: 7, status: 'approved', demo: true, history: [] },
  { id: 'd3', name: 'محمد الغرياني', phone: '0944443210', car: 'كيا أوبتيما', cat: 'comfort', model: '2021', color: 'أسود', plate: '78-1122', seats: 4, status: 'approved', demo: true, history: [] }
];
var DRIVERS = SEED_DRIVERS;
function clone(o) { return JSON.parse(JSON.stringify(o)); }
function mkRiders(trips, riders) {
  trips.forEach(function (t) {
    if (t.riderPhone) return;
    var r = riders.filter(function (x) { return x.name === t.riderName; })[0];
    if (!r) { r = { id: 'r' + (riders.length + 1), name: t.riderName, phone: '091000' + p2(riders.length + 1) + '00', demo: true, blocked: false, createdAt: t.created }; riders.push(r); }
    t.riderPhone = r.phone;
  });
  return riders;
}
var sub = 'ov', cancelId = null, cf = { reason: '', note: '', err: '' };
var acc = { drv: 'all', per: 'all', from: '', to: '', st: 'all', q: '', pay: null, perr: '', led: null };

function r2(n) { return Math.round(n * 100) / 100; }
function p2(n) { return (n < 10 ? '0' : '') + n; }
function dayKey(ts) { var d = new Date(ts); return d.getFullYear() + '-' + p2(d.getMonth() + 1) + '-' + p2(d.getDate()); }
function fmt(ts) { var d = new Date(ts); return dayKey(ts) + ' ' + p2(d.getHours()) + ':' + p2(d.getMinutes()); }
function nd(s) { return String(s).replace(/[٠-٩]/g, function (d) { return d.charCodeAt(0) - 1632; }).toLowerCase().trim(); }
function drvOf(id) { return DRIVERS.filter(function (d) { return d.id === id; })[0] || DRIVERS[0]; }
function makeSettle(price, at) { var c = commission(price); return { price: price, rate: COMM, commission: c, net: r2(price - c), at: at }; }
function tAt(t) { return t.status === 'completed' && t.settle ? t.settle.at : (t.status === 'cancelled' && t.cancel ? t.cancel.at : t.created); }
function canCancel(t) { return t.status === 'negotiating' || t.status === 'confirmed'; }

/* ---------- البيانات: بذرة + ترحيل من الإصدار 0.1 ---------- */
function seed() {
  var D = 86400000, n = Date.now(), id = 1, T = [];
  function mk(drv, rider, from, to, p, car, fin, status, ago, c) {
    var f = fare(p);
    var t = { id: id++, from: from, to: to, pax: p, car: car, base: BASE, extra: f.extra, fare: f.total,
      offers: [{ by: 'rider', price: fin || f.total }], status: status, final: fin, turn: status === 'negotiating' ? 'driver' : null,
      commission: 0, created: n - ago * D - 3600000, demo: true, driverId: drv, riderName: rider };
    if (status === 'completed') t.settle = makeSettle(fin, n - ago * D);
    if (status === 'cancelled') {
      t.cancel = { tripId: t.id, by: c[0], byId: c[0] === 'rider' ? rider : c[0] === 'driver' ? drv : 'admin',
        byName: c[0] === 'rider' ? rider : c[0] === 'driver' ? drvOf(drv).name : 'الإدارة', reason: c[1], note: c[2] || '', at: n - ago * D };
    }
    T.push(t);
  }
  mk('d1', 'سارة', 'وسط المدينة', 'مطار معيتيقة', 2, 'eco', 20, 'completed', 0);
  mk('d1', 'خالد', 'جامعة طرابلس', 'حي الأندلس', 5, 'family', 30, 'completed', 2);
  mk('d1', 'منى', 'جنزور', 'وسط المدينة', 3, 'comfort', null, 'cancelled', 1, ['driver', 'تعذر الوصول إلى الراكب']);
  mk('d1', 'يوسف', 'عين زارة', 'ميدان الشهداء', 4, 'comfort', null, 'negotiating', 0);
  mk('d2', 'ليلى', 'تاجوراء', 'سوق الجمعة', 4, 'comfort', 24, 'completed', 0);
  mk('d2', 'عمر', 'طريق الشط', 'جنزور', 7, 'family', 34, 'completed', 3);
  mk('d2', 'هدى', 'وسط المدينة', 'تاجوراء', 3, 'eco', 20, 'completed', 40);
  mk('d2', 'رامي', 'حي الأندلس', 'مطار معيتيقة', 2, 'eco', null, 'cancelled', 5, ['rider', 'تغيير الخطة']);
  mk('d2', 'نورا', 'سوق الجمعة', 'عين زارة', 4, 'eco', 25, 'cancelled', 4, ['admin', 'خطأ في الطلب', 'تكرار الطلب']);
  mk('d2', 'فهد', 'ميدان الشهداء', 'جامعة طرابلس', 3, 'eco', 26, 'confirmed', 0);
  mk('d3', 'علي', 'مطار معيتيقة', 'طريق الشط', 6, 'family', 32, 'completed', 1);
  mk('d3', 'سلمى', 'جنزور', 'تاجوراء', 2, 'eco', null, 'cancelled', 2, ['rider', 'عدم الاتفاق على السعر']);
  mk('d3', 'ماهر', 'عين زارة', 'وسط المدينة', 3, 'eco', 20, 'cancelled', 6, ['driver', 'مشكلة في السيارة']);
  T.sort(function (a, b) { return b.created - a.created; });
  var dr = clone(SEED_DRIVERS).concat([
    { id: 'd4', name: 'ياسر الككلي', phone: '0926667788', car: 'نيسان صني', cat: 'eco', model: '2016', color: 'فضي', plate: '33-9090', seats: 4, status: 'pending', demo: true, history: [] },
    { id: 'd5', name: 'عادل بن سليمان', phone: '0913332211', car: 'هيونداي إلنترا', cat: 'comfort', model: '2019', color: 'أزرق', plate: '55-2468', seats: 4, status: 'suspended', demo: true, history: [] }]);
  return { v: 3, seq: id, pseq: 2, cur: 'd1', rider: null, riders: mkRiders(T, []), drivers: dr, trips: T,
    payouts: [{ id: 1, driverId: 'd1', amount: 15, note: 'دفعة نقدية تجريبية', at: n - D }] };
}
function load() {
  var s = null;
  try { s = JSON.parse(localStorage.getItem(KEY)); } catch (e) {}
  if (!s || !s.trips) return seed();
  if (!s.v || s.v < 2) {
    s.trips.forEach(function (t) {
      t.driverId = t.driverId || 'd1'; t.riderName = t.riderName || 'راكب تجريبي';
      if (t.status === 'rejected') {
        t.status = 'cancelled';
        t.cancel = { tripId: t.id, by: 'driver', byId: t.driverId, byName: drvOf(t.driverId).name, reason: 'عدم الاتفاق على السعر', note: 'رفض قبل الإصدار 0.2', at: t.created };
      }
      if (t.status === 'completed' && !t.settle) t.settle = makeSettle(t.final, t.created);
    });
    s.v = 2; s.cur = 'd1'; s.payouts = s.payouts || []; s.pseq = s.pseq || 1;
  }
  if (s.v < 3) { s.drivers = clone(SEED_DRIVERS); s.riders = mkRiders(s.trips, []); s.rider = null; s.v = 3; }
  return s;
}

/* ---------- الحسابات ---------- */
function inPer(ts) {
  var k = dayKey(ts), n = dayKey(Date.now());
  if (acc.per === 'today') return k === n;
  if (acc.per === 'month') return k.slice(0, 7) === n.slice(0, 7);
  if (acc.per === 'custom') { if (acc.from && k < acc.from) return false; if (acc.to && k > acc.to) return false; }
  return true;
}
function scopeDrivers() {
  var q = nd(acc.q);
  return DRIVERS.filter(function (d) { return (acc.drv === 'all' || d.id === acc.drv) && (!q || nd(d.name).indexOf(q) > -1 || d.phone.indexOf(q) > -1); });
}
function stOk(t) { return acc.st === 'all' || (acc.st === 'active' ? (t.status === 'negotiating' || t.status === 'confirmed') : t.status === acc.st); }
function accTrips() {
  var ids = scopeDrivers().map(function (d) { return d.id; });
  return state.trips.filter(function (t) { return ids.indexOf(t.driverId) > -1 && inPer(tAt(t)) && stOk(t); })
    .sort(function (a, b) { return tAt(b) - tAt(a); });
}
function sums(list) {
  var s = { value: 0, comm: 0, net: 0, done: 0, canc: 0, active: 0 };
  list.forEach(function (t) {
    if (t.status === 'completed' && t.settle) { s.value += t.settle.price; s.comm += t.settle.commission; s.net += t.settle.net; s.done++; }
    else if (t.status === 'cancelled') s.canc++;
    else s.active++;
  });
  s.value = r2(s.value); s.comm = r2(s.comm); s.net = r2(s.net); return s;
}
function paidOf(id, byPeriod) {
  return r2(state.payouts.filter(function (p) { return p.driverId === id && (!byPeriod || inPer(p.at)); }).reduce(function (a, p) { return a + p.amount; }, 0));
}
function dueAll(id) { return sums(state.trips.filter(function (t) { return t.driverId === id; })).net; }
function doPay(id) {
  var amt = Number(nd(document.getElementById('payamt').value)), note = document.getElementById('paynote').value.trim();
  var rem = r2(dueAll(id) - paidOf(id, false));
  if (!amt || isNaN(amt) || amt <= 0) acc.perr = 'أدخل مبلغًا صحيحًا أكبر من صفر.';
  else if (amt > rem) acc.perr = 'المبلغ أكبر من المتبقي المستحق للسائق (' + money(rem) + ').';
  else {
    state.payouts.push({ id: state.pseq++, driverId: id, amount: r2(amt), note: note, at: Date.now() });
    acc.pay = null; acc.perr = ''; save(); toast('سُجّلت دفعة ' + money(amt) + ' للسائق.');
  }
  render();
}

/* ---------- الإلغاء ---------- */
function doCancel(id, role) {
  var t = find(id);
  if (!t || !canCancel(t)) { cancelId = null; toast('لا يمكن إلغاء الرحلة في حالتها الحالية.'); return render(); }
  cf.reason = document.getElementById('crs').value; cf.note = document.getElementById('cnote').value.trim();
  if (role === 'driver' && t.driverId !== state.cur) cf.err = 'هذه الرحلة غير مسندة إلى السائق المحدد.';
  else if (!cf.reason) cf.err = 'اختر سبب الإلغاء من القائمة.';
  else if (cf.reason === 'سبب آخر' && cf.note.length < 3) cf.err = 'اكتب شرحًا لسبب الإلغاء الآخر.';
  else cf.err = '';
  if (cf.err) return render();
  var who = role === 'rider' ? { id: t.riderName, name: t.riderName } : role === 'driver' ? { id: t.driverId, name: drvOf(t.driverId).name } : { id: 'admin', name: 'الإدارة' };
  t.cancel = { tripId: t.id, by: role, byId: who.id, byName: who.name, reason: cf.reason, note: cf.note, at: Date.now() };
  t.status = 'cancelled'; t.turn = null; t.commission = 0; cancelId = null; save();
  toast('أُلغيت الرحلة وسُجّل السبب.'); render();
}
function cancelArea(t, role) {
  if (!canCancel(t)) return '';
  if (cancelId !== t.id) return '<button class="btn ghost" data-a="cancelopen" data-id="' + t.id + '">إلغاء الرحلة</button>';
  var o = REASONS.map(function (r) { return '<option' + (cf.reason === r ? ' selected' : '') + '>' + r + '</option>'; }).join('');
  return '<div class="card cxl"><h3>إلغاء الرحلة #' + t.id + '</h3><label>الجهة التي ألغت</label><select disabled><option>' + ROLE_AR[role] + '</option></select>' +
    '<label>سبب الإلغاء</label><select id="crs"><option value="">— اختر السبب —</option>' + o + '</select>' +
    '<label>شرح السبب (إلزامي عند «سبب آخر»)</label><input id="cnote" value="' + esc(cf.note) + '">' +
    (cf.err ? '<div class="err">' + esc(cf.err) + '</div>' : '') +
    '<div class="btns"><button class="btn ghost" data-a="cancelgo" data-id="' + t.id + '" data-w="' + role + '">تأكيد الإلغاء</button><button class="btn sec" data-a="cancelback">رجوع</button></div></div>';
}
function cancelInfo(t) {
  if (t.status !== 'cancelled' || !t.cancel) return '';
  var c = t.cancel;
  return '<div class="err">ملغاة بواسطة ' + ROLE_AR[c.by] + ' (' + esc(c.byName) + ') · ' + fmt(c.at) + '<br>السبب: ' + esc(c.reason) + (c.note ? ' — ' + esc(c.note) : '') + '<br>لا تُحتسب عمولة ولا مستحقات.</div>';
}
function metaRow(t) { var d = drvOf(t.driverId); return '<div class="note">رحلة #' + t.id + ' · الراكب: ' + esc(t.riderName) + ' · السائق: ' + esc(d.name) + ' (' + d.phone + ')<br>الحالة: ' + statusLine(t) + '</div>' + stepper(t); }
function moneyRows(t) {
  if (t.status === 'completed' && t.settle) return '<span>عمولة المنصة ' + Math.round(t.settle.rate * 100) + '%</span><span>' + money(t.settle.commission) + '</span><span>صافي مستحق السائق</span><span>' + money(t.settle.net) + '</span>';
  if (t.status === 'confirmed') return '<span>العمولة المتوقعة (لا تُحتسب قبل الاكتمال)</span><span>' + money(commission(t.final)) + '</span>';
  return '';
}
function riderFields() {
  return '<label>اسم الراكب</label><input id="rider" placeholder="راكب تجريبي" value="' + esc(form.rider || '') + '"><label>السائق</label><select id="fdrv">' +
    DRIVERS.map(function (d) { return '<option value="' + d.id + '"' + ((form.driverId || state.cur) === d.id ? ' selected' : '') + '>' + esc(d.name) + ' — ' + d.phone + '</option>'; }).join('') + '</select>';
}

/* ---------- واجهة السائق ---------- */
function driverHome() {
  var d = drvOf(state.cur), mine = state.trips.filter(function (t) { return t.driverId === d.id; });
  var due = dueAll(d.id), paid = paidOf(d.id, false);
  var by = function (s) { return mine.filter(function (t) { return t.status === s; }); };
  var old = mine.filter(function (t) { return t.status === 'completed' || t.status === 'cancelled'; });
  var list = function (a, e) { return a.length ? a.map(function (t) { return tripCard(t, 'driver'); }).join('') : '<div class="card empty">' + e + '</div>'; };
  return '<div class="card"><h2>حساب السائق ' + dbadge(d) + '</h2><select id="curdrv">' + DRIVERS.map(function (x) { return '<option value="' + x.id + '"' + (x.id === d.id ? ' selected' : '') + '>' + esc(x.name) + (x.status !== 'approved' ? ' (' + DSTAT[x.status] + ')' : '') + '</option>'; }).join('') +
    '</select><div class="note">حساب تجريبي — لا يوجد تسجيل دخول حقيقي.</div><div class="kv"><span>مستحق للسائق (رحلات مكتملة بعد العمولة)</span><span>' + money(due) + '</span><span>تم دفعه</span><span>' + money(paid) + '</span><span>المتبقي</span><span>' + money(r2(due - paid)) + '</span></div></div>' +
    driverBody(d, by, list) +
    (old.length ? '<h2>السجل</h2>' + old.map(function (t) { return tripCard(t, 'driver'); }).join('') : '');
}

/* ---------- واجهة الإدارة: الحسابات والعمولات ---------- */
function opt(v, l, cur) { return '<option value="' + v + '"' + (cur === v ? ' selected' : '') + '>' + l + '</option>'; }
function groupSummary(keyFn, limit, base) {
  var m = {};
  base.forEach(function (t) {
    var k, g;
    if (t.status === 'completed' && t.settle) { k = keyFn(t.settle.at); g = m[k] = m[k] || { n: 0, v: 0, c: 0, d: 0, x: 0 }; g.n++; g.v += t.settle.price; g.c += t.settle.commission; g.d += t.settle.net; }
    else if (t.status === 'cancelled' && t.cancel) { k = keyFn(t.cancel.at); g = m[k] = m[k] || { n: 0, v: 0, c: 0, d: 0, x: 0 }; g.x++; }
  });
  var ks = Object.keys(m).sort().reverse().slice(0, limit);
  return ks.length ? '<ul class="log">' + ks.map(function (k) { var g = m[k];
    return '<li class="blk"><b>' + k + '</b><div class="note">' + g.n + ' مكتملة · قيمة ' + money(r2(g.v)) + ' · عمولة ' + money(r2(g.c)) + ' · مستحق للسائقين ' + money(r2(g.d)) + ' · ملغاة ' + g.x + '</div></li>'; }).join('') + '</ul>' : '<div class="empty">لا بيانات.</div>';
}
function ledger(d, own) {
  var rows = own.filter(function (t) { return t.status === 'completed' || t.status === 'cancelled'; }).map(function (t) {
    return t.status === 'completed' ? { at: t.settle.at, txt: 'رحلة #' + t.id + ' مكتملة (سعر ' + money(t.settle.price) + '، عمولة ' + money(t.settle.commission) + ')', amt: t.settle.net }
      : { at: t.cancel.at, txt: 'رحلة #' + t.id + ' ملغاة — ' + esc(t.cancel.reason), amt: 0 };
  }).concat(state.payouts.filter(function (p) { return p.driverId === d.id && inPer(p.at); }).map(function (p) {
    return { at: p.at, txt: 'دفعة للسائق' + (p.note ? ' — ' + esc(p.note) : ''), amt: -p.amount };
  })).sort(function (a, b) { return a.at - b.at; });
  var run = 0;
  return '<h3>السجل المالي (الأقدم أولًا، الرصيد ضمن الفترة)</h3><ul class="log">' + (rows.length ? rows.map(function (r) { run = r2(run + r.amt);
    return '<li class="blk"><span>' + fmt(r.at) + ' · ' + r.txt + '</span><div class="note">' + (r.amt < 0 ? 'مدفوع ' : 'مستحق ') + money(Math.abs(r.amt)) + ' · الرصيد ' + money(run) + '</div></li>'; }).join('') : '<li>لا حركات.</li>') + '</ul>';
}
function accountsView() {
  var list = accTrips(), s = sums(list), ds = scopeDrivers();
  var paidAll = r2(ds.reduce(function (a, d) { return a + paidOf(d.id, true); }, 0));
  var h = '<div class="card"><h2>تصفية الحسابات</h2><label>بحث عن سائق (الاسم أو الهاتف)</label><input id="accq" value="' + esc(acc.q) + '" placeholder="مثال: أحمد أو 0912">' +
    '<label>السائق</label><select id="accdrv">' + opt('all', 'كل السائقين', acc.drv) + DRIVERS.map(function (d) { return opt(d.id, esc(d.name), acc.drv); }).join('') + '</select>' +
    '<label>الفترة</label><select id="accper">' + opt('all', 'كل الفترات', acc.per) + opt('today', 'اليوم', acc.per) + opt('month', 'هذا الشهر', acc.per) + opt('custom', 'فترة مخصصة', acc.per) + '</select>' +
    (acc.per === 'custom' ? '<div class="row"><input type="date" id="accfrom" value="' + acc.from + '"><input type="date" id="accto" value="' + acc.to + '"></div>' : '') +
    '<label>حالة الرحلة</label><select id="accst">' + opt('all', 'الكل', acc.st) + opt('completed', 'مكتملة', acc.st) + opt('cancelled', 'ملغاة', acc.st) + opt('active', 'جارية / معلقة', acc.st) + '</select></div>';
  h += '<div class="stats"><div class="stat"><b>' + money(s.value) + '</b><span>إجمالي قيمة الرحلات المكتملة</span></div><div class="stat"><b>' + money(s.comm) + '</b><span>عمولة المنصة 12%</span></div>' +
    '<div class="stat"><b>' + money(s.net) + '</b><span>مستحقات السائقين بعد العمولة</span></div><div class="stat"><b>' + s.done + ' / ' + s.canc + '</b><span>مكتملة / ملغاة</span></div>' +
    '<div class="stat"><b>' + money(paidAll) + '</b><span>تم دفعه (مسجّل إداريًا)</span></div><div class="stat"><b>' + money(r2(s.net - paidAll)) + '</b><span>مستحق غير مدفوع</span></div></div>' +
    '<p class="note">تشمل المبالغ الرحلات المكتملة فقط. الملغاة والجارية (' + s.active + ') لا تُحتسب إيرادات ولا عمولة. المستحق ليس مدفوعًا حتى تُسجَّل له دفعة.</p>';
  h += '<h2>حسابات السائقين</h2>' + (ds.length ? ds.map(function (d) {
    var own = list.filter(function (t) { return t.driverId === d.id; }), x = sums(own), pd = paidOf(d.id, true), rem = r2(dueAll(d.id) - paidOf(d.id, false));
    var c = '<div class="card"><div class="trip-h"><b>' + esc(d.name) + '</b><span class="note">' + d.phone + '</span></div><div class="kv"><span>رحلات مكتملة / ملغاة</span><span>' + x.done + ' / ' + x.canc + '</span>' +
      '<span>إجمالي القيمة</span><span>' + money(x.value) + '</span><span>إجمالي عمولات المنصة</span><span>' + money(x.comm) + '</span><span>مستحق للسائق</span><span>' + money(x.net) + '</span>' +
      '<span>تم دفعه</span><span>' + money(pd) + '</span><span>المتبقي (كل الفترات)</span><span>' + money(rem) + '</span></div>' +
      '<div class="btns"><button class="btn sec" data-a="ledger" data-d="' + d.id + '">السجل المالي</button><button class="btn" data-a="payopen" data-d="' + d.id + '">تسجيل دفعة</button></div>';
    if (acc.pay === d.id) c += '<div class="card cxl"><h3>تسجيل دفعة — المتبقي ' + money(rem) + '</h3><input id="payamt" inputmode="decimal" placeholder="المبلغ (د.ل)"><input id="paynote" placeholder="ملاحظة (اختياري)" style="margin-top:8px">' +
      (acc.perr ? '<div class="err">' + esc(acc.perr) + '</div>' : '') + '<div class="btns"><button class="btn" data-a="paygo" data-d="' + d.id + '">حفظ الدفعة</button><button class="btn sec" data-a="payclose">إغلاق</button></div></div>';
    if (acc.led === d.id) c += ledger(d, own);
    return c + '</div>';
  }).join('') : '<div class="card empty">لا يوجد سائق مطابق للبحث.</div>');
  var rs = {}; list.forEach(function (t) { if (t.status === 'cancelled' && t.cancel) rs[t.cancel.reason] = (rs[t.cancel.reason] || 0) + 1; });
  var rk = Object.keys(rs).sort(function (a, b) { return rs[b] - rs[a]; }).slice(0, 5);
  h += '<div class="card"><h2>أسباب الإلغاء الأكثر تكرارًا</h2>' + (rk.length ? '<ul class="log">' + rk.map(function (k) { return '<li><span>' + esc(k) + '</span><span>' + rs[k] + '</span></li>'; }).join('') + '</ul>' : '<div class="empty">لا رحلات ملغاة.</div>') + '</div>';
  var ids = ds.map(function (d) { return d.id; }), base = state.trips.filter(function (t) { return ids.indexOf(t.driverId) > -1; });
  h += '<div class="card"><h2>الملخص اليومي (آخر 7 أيام فيها حركة)</h2>' + groupSummary(dayKey, 7, base) + '<h2 style="margin-top:14px">الملخص الشهري</h2>' + groupSummary(function (ts) { return dayKey(ts).slice(0, 7); }, 12, base) + '</div>';
  h += '<h2>تفاصيل الرحلات (' + list.length + ')</h2>' + (list.length ? list.map(function (t) {
    var m = t.status === 'completed' && t.settle ? '<span>السعر النهائي</span><span>' + money(t.settle.price) + '</span><span>عمولة المنصة</span><span>' + money(t.settle.commission) + '</span><span>صافي مستحق السائق</span><span>' + money(t.settle.net) + '</span>'
      : '<span>الحساب</span><span>' + (t.status === 'cancelled' ? 'لا تُحتسب (ملغاة)' : 'غير محتسبة بعد') + '</span>';
    return '<div class="card"><div class="trip-h"><b>رحلة #' + t.id + '</b>' + badge(t) + '</div><div class="note">الراكب: ' + esc(t.riderName) + ' · السائق: ' + esc(drvOf(t.driverId).name) + ' · ' + fmt(tAt(t)) + '</div><div class="kv">' + m + '</div>' + cancelInfo(t) + '</div>';
  }).join('') : '<div class="card empty">لا رحلات ضمن هذه التصفية.</div>');
  return h;
}

/* ---------- أحداث ---------- */
document.addEventListener('click', function (e) {
  if (e.target.closest('.tabs button')) { cancelId = null; return; }
  var b = e.target.closest('[data-a]'); if (!b) return;
  var a = b.dataset.a, id = Number(b.dataset.id);
  if (a === 'sub') { sub = b.dataset.s; render(); }
  else if (a === 'cancelopen') { cancelId = id; cf = { reason: '', note: '', err: '' }; render(); }
  else if (a === 'cancelback') { cancelId = null; render(); }
  else if (a === 'cancelgo') { if (b.dataset.w === roleOf()) doCancel(id, roleOf()); }
  else if (a === 'payopen') { acc.pay = b.dataset.d; acc.perr = ''; render(); }
  else if (a === 'payclose') { acc.pay = null; render(); }
  else if (a === 'paygo') doPay(b.dataset.d);
  else if (a === 'ledger') { acc.led = acc.led === b.dataset.d ? null : b.dataset.d; render(); }
});
document.addEventListener('change', function (e) {
  var id = e.target.id, v = e.target.value, m = { accdrv: 'drv', accper: 'per', accst: 'st', accfrom: 'from', accto: 'to' };
  if (id === 'fdrv') form.driverId = v;
  else if (id === 'curdrv') { state.cur = v; save(); render(); }
  else if (m[id]) { acc[m[id]] = v; render(); }
});
document.addEventListener('input', function (e) {
  if (e.target.id !== 'accq') return;
  acc.q = e.target.value; var p = e.target.selectionStart; render();
  var n = document.getElementById('accq'); if (n) { n.focus(); try { n.setSelectionRange(p, p); } catch (x) {} }
});
