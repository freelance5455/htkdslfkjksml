'use strict';
/* مشوار v0.3 — الصفحة الرئيسية والخريطة التجريبية وتسجيل الراكب والسائق وإدارة السائقين والركاب. يُحمَّل بعد accounts.js وقبل app.js */
var MAPP = [
  { id: 'shuhada', n: 'ميدان الشهداء', x: 190, y: 110 }, { id: 'omar', n: 'شارع عمر المختار', x: 95, y: 150 },
  { id: 'jazaer', n: 'ميدان الجزائر', x: 255, y: 75 }, { id: 'dahra', n: 'منطقة الظهرة', x: 150, y: 215 },
  { id: 'qarq', n: 'منطقة قرقارش', x: 62, y: 262 }, { id: 'ben', n: 'منطقة بن عاشور', x: 288, y: 230 }
];
var DSTAT = { pending: 'قيد المراجعة', approved: 'مقبول', rejected: 'مرفوض', suspended: 'موقوف' };
var DMSG = { pending: 'طلب تسجيلك قيد مراجعة الإدارة. لا يمكنك استقبال الرحلات قبل الموافقة اليدوية.', rejected: 'رُفض طلب تسجيلك. تواصل مع الإدارة التجريبية.', suspended: 'حسابك موقوف، ولا يمكنك استقبال الرحلات حتى تعيد الإدارة تفعيله.' };
var DBADGE = { pending: 'b-neg', approved: 'b-ok', rejected: 'b-bad', suspended: 'b-done' };
var ICO = {
  home: '<path d="M3 11l9-8 9 8v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
  trips: '<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M9 8h6M9 12h6M9 16h4"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>',
  car: '<path d="M5 17v-6l2-5h10l2 5v6M3 17h18M7 20v-3M17 20v-3"/><circle cx="8" cy="14" r="1"/><circle cx="16" cy="14" r="1"/>',
  wallet: '<rect x="3" y="6" width="18" height="14" rx="3"/><path d="M3 10h18M16 15h2"/>',
  pin: '<path d="M12 21s-7-6-7-11a7 7 0 0 1 14 0c0 5-7 11-7 11z"/><circle cx="12" cy="10" r="2.5"/>'
};
function ic(n) { return '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + ICO[n] + '</svg>'; }
var dsub = 'req';
var forms = { login: { name: '', phone: '' }, drv: { name: '', phone: '', car: '', cat: 'eco', model: '', color: '', plate: '', seats: '4' } };
var ferr = { login: '', drv: '' }, aq = { d: '', r: '', t: '', s: 'all' };

function roleOf() { return tab === 'driver' ? 'driver' : tab === 'admin' ? 'admin' : 'rider'; }
function placeOf(n) { return MAPP.filter(function (p) { return p.n === n; })[0]; }
function fullName(s) { var w = String(s).trim().split(/\s+/); return w.length >= 2 && w.every(function (x) { return x.length >= 2; }); }
function phoneN(s) { return nd(s).replace(/[\s\-]/g, ''); }
function phoneOk(s) { return /^09\d{8}$/.test(phoneN(s)); }
var PLACE_KM = { 'omar|shuhada': 3, 'jazaer|shuhada': 2, 'dahra|shuhada': 4.5, 'qarq|shuhada': 9, 'ben|shuhada': 7, 'jazaer|omar': 4, 'dahra|omar': 6, 'omar|qarq': 8, 'ben|omar': 12,
  'dahra|jazaer': 6.5, 'jazaer|qarq': 14.5, 'ben|jazaer': 9, 'dahra|qarq': 5, 'ben|dahra': 10, 'ben|qarq': 16 };
function demoKm(a, b) { return PLACE_KM[[a, b].sort().join('|')]; }
/* المسافة: مُدخلة يدويًا (تجريبية) أو من جدول ثابت بين الأماكن التجريبية. ليست قياسًا حقيقيًا. */
function curKm() {
  var m = form.km == null ? '' : String(form.km).trim();
  if (m !== '') { var v = Number(nd(m).replace('٫', '.').replace(',', '.')); return v > 0 && v <= 200 ? { km: v, src: 'manual' } : { err: 'أدخل مسافة صحيحة بالكيلومتر (من 0.1 إلى 200).' }; }
  var f = placeOf(form.from), t = placeOf(form.to);
  return f && t && f.id !== t.id ? { km: demoKm(f.id, t.id), src: 'demo' } : { km: null };
}
function fareNow() { var k = curKm(); return k.km ? fare(form.pax, k.km) : null; }
function billHtml() {
  var k = curKm(), fr = fareNow();
  if (k.err) return '<div class="err">' + k.err + '</div>';
  if (!fr) return '<div class="note">اختر الانطلاق والوجهة (أو أدخل مسافة تجريبية) ليظهر السعر.</div>';
  return '<div class="bill"><div><span>المسافة (' + (k.src === 'manual' ? 'مُدخلة تجريبيًا' : 'تجريبية ثابتة') + ')</span><span>' + k.km + ' كم</span></div><div><span>السعر الأساسي حسب المسافة (يشمل 3 ركاب)</span><span>' + money(fr.base) + '</span></div><div><span>رسوم ' + fr.extraPax + ' راكب إضافي (20% من الأساسي)</span><span>' + money(fr.extra) + '</span></div><div class="tot"><span>الإجمالي</span><span>' + money(fr.total) + '</span></div><div><span>عمولة المنصة 12% (تُخصم من السائق)</span><span>' + money(commission(fr.total)) + '</span></div></div>';
}
function refreshPrice() {
  var b = document.getElementById('bill'); if (b) b.innerHTML = billHtml();
  var fr = fareNow(); Array.prototype.forEach.call(document.querySelectorAll('.car:not(.off) .cp'), function (e) { e.textContent = fr ? money(fr.total) : '—'; });
  var o = document.getElementById('offer'); if (o) o.placeholder = fr ? 'اتركه فارغًا لاعتماد ' + money(fr.total) : 'اختر المسافة أولًا';
}
function eligible() { return DRIVERS.filter(function (d) { return d.status === 'approved' && d.cat === form.car && d.seats >= form.pax; }); }
function driverOk(t) {
  if (drvOf(t.driverId).status === 'approved') return true;
  toast('لا يمكن للسائق غير المعتمد استقبال الرحلات أو تنفيذها.'); return false;
}
function driverBody(d, by, list) {
  if (d.status !== 'approved') return '<div class="err">' + DMSG[d.status] + '</div>';
  return '<h2>طلبات قيد التفاوض</h2>' + list(by('negotiating'), 'لا توجد طلبات الآن.') + '<h2>رحلات مؤكدة</h2>' + list(by('confirmed'), 'لا توجد رحلات مؤكدة.');
}
function dbadge(d) { return '<span class="badge ' + DBADGE[d.status] + '">' + DSTAT[d.status] + '</span>'; }
function stepper(t) {
  if (t.status === 'cancelled') return '';
  var i = t.status === 'negotiating' ? 0 : t.status === 'confirmed' ? 1 : 3, L = ['تفاوض', 'مؤكدة', 'مكتملة'];
  return '<div class="steps">' + L.map(function (l, k) { return '<span class="st' + (k < i ? ' done' : k === i ? ' now' : '') + '"><i></i>' + l + '</span>'; }).join('') + '</div>';
}
function statusLine(t) {
  if (t.status === 'negotiating') return 'بانتظار رد ' + (t.turn === 'driver' ? 'السائق' : 'الراكب') + ' · الجولة ' + t.offers.length + ' من ' + MAXROUNDS;
  if (t.status === 'confirmed') return 'مؤكدة بسعر ' + money(t.final) + ' — بانتظار إنهاء السائق للرحلة';
  if (t.status === 'completed') return 'اكتملت وحُفظت في السجل';
  return 'ملغاة';
}

/* ---------- الخريطة التجريبية (SVG محلي، بلا إنترنت ولا موقع جغرافي) ---------- */
function mapSvg() {
  var f = placeOf(form.from), t = placeOf(form.to);
  var s = '<svg viewBox="0 0 360 300" class="map" role="img" aria-label="خريطة تجريبية"><rect width="360" height="300" fill="#E6EFF1"/><rect width="360" height="34" fill="#BFE3EA"/>' +
    '<rect x="170" y="150" width="60" height="34" rx="8" fill="#CDE8D5"/><rect x="20" y="190" width="54" height="34" rx="8" fill="#CDE8D5"/><rect x="250" y="95" width="50" height="30" rx="8" fill="#D9E7C9"/>' +
    '<path d="M0 90H360M0 170H360M0 265H360M60 34V300M150 34V300M240 34V300M325 34V300M0 45L360 255" stroke="#fff" stroke-width="10" fill="none"/>' +
    '<text x="180" y="22" text-anchor="middle" font-size="11" fill="#2F6F80">البحر (رسم تجريبي)</text>';
  if (f && t) s += '<line x1="' + f.x + '" y1="' + f.y + '" x2="' + t.x + '" y2="' + t.y + '" stroke="#0B2545" stroke-width="4" stroke-dasharray="8 6" stroke-linecap="round"/>';
  MAPP.forEach(function (p) {
    var fill = f && f.id === p.id ? '#1E8E5A' : t && t.id === p.id ? '#19D9CF' : '#0B2545', r = fill === '#0B2545' ? 7 : 12;
    s += '<g data-a="pick" data-p="' + p.id + '"><circle cx="' + p.x + '" cy="' + p.y + '" r="22" fill="transparent"/><circle cx="' + p.x + '" cy="' + p.y + '" r="' + r + '" fill="' + fill + '" stroke="#fff" stroke-width="3"/>' +
      '<text x="' + p.x + '" y="' + (p.y + 26) + '" text-anchor="middle" font-size="12" font-weight="700" fill="#0B2545" stroke="#fff" stroke-width="3" paint-order="stroke">' + p.n + '</text></g>';
  });
  return s + '</svg>';
}
function pick(pid) {
  var n = MAPP.filter(function (p) { return p.id === pid; })[0].n, m = form.mode || (form.from ? 'to' : 'from');
  if (m === 'from') { form.from = n; if (form.to === n) form.to = ''; form.mode = 'to'; }
  else if (n === form.from) { errs.main = 'الوجهة تطابق موقع الانطلاق. اختر مكانًا آخر.'; return render(); }
  else form.to = n;
  errs = {}; render();
}
function placeSel(id, cur, ph) {
  return '<select id="' + id + '"><option value="">' + ph + '</option>' + MAPP.map(function (p) { return '<option' + (cur === p.n ? ' selected' : '') + '>' + p.n + '</option>'; }).join('') + '</select>';
}

/* ---------- الراكب: الرئيسية ---------- */
function homeView() {
  var fr = fareNow(), el = eligible(), mode = form.mode || (form.from ? 'to' : 'from');
  var sel = form.driverId && el.some(function (d) { return d.id === form.driverId; }) ? form.driverId : (el[0] ? el[0].id : '');
  var cars = Object.keys(CARS).map(function (k) {
    var ok = form.pax <= CARS[k].cap;
    return '<button class="car ' + (form.car === k && ok ? 'on' : '') + (ok ? '' : ' off') + '" data-a="car" data-k="' + k + '"><span class="cic">' + ic('car') + '</span><span><b>' + CARS[k].name + '</b><small>حتى ' + CARS[k].cap + ' ركاب</small></span><span class="cp">' + (ok ? (fr ? money(fr.total) : '—') : 'لا تتسع') + '</span></button>';
  }).join('');
  var h = '<div class="mapbox"><span class="demo-badge">خريطة تجريبية</span>' + mapSvg() + '<div class="maphint">' + ic('pin') + 'اضغط مكانًا لتحديد ' + (mode === 'from' ? 'الانطلاق' : 'الوجهة') + '</div></div>' +
    '<div class="card sheet"><h1 class="hero">وين تبي تمشي؟</h1><p class="note">' + (state.rider ? 'أهلًا ' + esc(state.rider.name) : 'للطلب سجّل دخولك التجريبي من تبويب «الحساب».') + '</p>' +
    '<div class="frow"><i class="dot g"></i>' + placeSel('from', form.from, 'من أين تنطلق؟') + '</div><div class="frow"><i class="dot t"></i>' + placeSel('to', form.to, 'إلى أين؟') + '</div>' +
    '<div class="chips"><button data-a="mode" data-m="from" class="' + (mode === 'from' ? 'on' : '') + '">تحديد الانطلاق</button><button data-a="mode" data-m="to" class="' + (mode === 'to' ? 'on' : '') + '">تحديد الوجهة</button><button data-a="resetpath">إعادة تعيين</button></div>' +
    '<p class="note">الأماكن والخريطة للعرض فقط ولا تمثل مواقع أو مسافات حقيقية.</p>';
  var ckS = curKm();
  if (form.from && form.to) h += '<div class="sum"><b>' + esc(form.from) + ' ← ' + esc(form.to) + '</b><span class="note">' + (ckS.km ? 'المسافة: ' + ckS.km + ' كم (' + (ckS.src === 'manual' ? 'مُدخلة تجريبيًا' : 'تجريبية ثابتة') + '، ليست قياسًا حقيقيًا) وتؤثر على السعر.' : '') + '</span></div>';
  h += '</div><div class="card"><h2>الركاب والسيارة</h2><div class="pax"><button data-a="pm" data-d="-1" aria-label="إنقاص">−</button><output>' + form.pax + '</output><button data-a="pm" data-d="1" aria-label="زيادة">+</button></div><div class="note" style="text-align:center">عدد الركاب (1–7) يشمل صاحب الطلب</div>' +
    '<label>فئة السيارة</label><div class="cars">' + cars + '</div><label>سائق تجريبي معتمد</label>' +
    (el.length ? '<select id="fdrv">' + el.map(function (d) { return '<option value="' + d.id + '"' + (d.id === sel ? ' selected' : '') + '>' + esc(d.name) + ' — ' + esc(d.car) + ' ' + d.color + '</option>'; }).join('') + '</select>' : '<div class="err">لا يوجد سائق معتمد من فئة «' + CARS[form.car].name + '» يتسع لـ ' + pax(form.pax) + ' حاليًا.</div>') +
    '<label>مسافة تجريبية بالكيلومتر (اختياري)</label><input id="km" inputmode="decimal" placeholder="تُحسب من الأماكن التجريبية، أو اكتبها للتجربة" value="' + esc(form.km || '') + '">' +
    '<label>عرضك للسائق بدينار صحيح (اختياري)</label><input id="offer" inputmode="numeric" placeholder="' + (fr ? 'اتركه فارغًا لاعتماد ' + money(fr.total) : 'اختر المسافة أولًا') + '" value="' + esc(form.offer) + '">' +
    '<div id="bill">' + billHtml() + '</div>' +
    (errs.main ? '<div class="err">' + esc(errs.main) + '</div>' : '') + '<button class="btn" data-a="create">اطلب رحلة</button></div>';
  return h;
}
function createTrip() {
  errs = {}; var f = form, r = state.rider;
  var rr = r && state.riders.filter(function (x) { return x.phone === r.phone; })[0];
  if (!r) errs.main = 'سجّل الدخول التجريبي من تبويب «الحساب» قبل طلب الرحلة.';
  else if (rr && rr.blocked) errs.main = 'حسابك معطّل من الإدارة التجريبية.';
  else if (!f.from || !f.to) errs.main = 'اختر موقع الانطلاق والوجهة من الخريطة أو القائمة.';
  else if (f.from === f.to) errs.main = 'موقع الانطلاق والوجهة متطابقان. اختر وجهة مختلفة.';
  else if (f.pax < 1 || f.pax > MAXPAX) errs.main = 'عدد الركاب يجب أن يكون بين 1 و 7.';
  else if (f.pax > CARS[f.car].cap) errs.main = 'سيارة «' + CARS[f.car].name + '» تتسع لـ ' + CARS[f.car].cap + ' ركاب فقط. اختر سيارة عائلية.';
  var el = eligible(), drv = el.filter(function (d) { return d.id === f.driverId; })[0] || el[0];
  if (!errs.main && !drv) errs.main = 'لا يوجد سائق معتمد من هذه الفئة يتسع لـ ' + pax(f.pax) + '.';
  var ck = curKm();
  if (!errs.main && (ck.err || !ck.km)) errs.main = ck.err || 'اختر الانطلاق والوجهة لتحديد المسافة والسعر.';
  var fr = ck.km ? fare(f.pax, ck.km) : { base: 0, extra: 0, total: 0 }, price = fr.total;
  if (!errs.main && String(f.offer).trim() !== '') { var p = parsePrice(f.offer); if (p.err) errs.main = p.err; else price = p.v; }
  if (errs.main) { if (!r) tab = 'account'; return render(); }
  state.trips.unshift({ id: state.seq++, from: f.from, to: f.to, pax: f.pax, car: f.car, base: fr.base, km: ck.km, kmSrc: ck.src, extra: fr.extra, fare: fr.total,
    offers: [{ by: 'rider', price: price }], status: 'negotiating', final: null, turn: 'driver', commission: 0, created: Date.now(),
    driverId: drv.id, riderName: r.name, riderPhone: r.phone });
  save(); form = { from: '', to: '', pax: 1, car: 'eco', offer: '', mode: 'from', km: '' }; tab = 'trips';
  toast('أُرسل عرضك للسائق التجريبي. بدّل إلى وضع السائق للرد.'); render();
}

/* ---------- رحلاتي والحساب ---------- */
function tripsView() {
  if (!state.rider) return '<div class="card empty">سجّل الدخول التجريبي لعرض رحلاتك.<button class="btn" data-a="goacc">الذهاب إلى الحساب</button></div>';
  var mine = state.trips.filter(function (t) { return t.riderPhone === state.rider.phone; }), x = sums(mine);
  return '<div class="stats"><div class="stat"><b>' + mine.length + '</b><span>كل رحلاتي</span></div><div class="stat"><b>' + x.done + ' / ' + x.canc + '</b><span>مكتملة / ملغاة</span></div></div><h2>سجل الرحلات</h2>' + (mine.length ? mine.map(function (t) { return tripCard(t, 'rider'); }).join('') : '<div class="card empty">لا رحلات بعد. اطلب أول رحلة من الرئيسية.</div>');
}
function fld(k, label, ph, extra) { var o = k.split('.'); return '<label>' + label + '</label><input data-f="' + k + '" placeholder="' + ph + '" value="' + esc(forms[o[0]][o[1]]) + '" ' + (extra || '') + '>'; }
function accountView() {
  var r = state.rider, h = '';
  if (r) h += '<div class="card"><div class="avatar">' + esc(r.name.charAt(0)) + '</div><h2>حسابي</h2><div class="kv"><span>الاسم</span><span>' + esc(r.name) + '</span><span>الهاتف</span><span>' + r.phone + '</span><span>عدد رحلاتي</span><span>' + state.trips.filter(function (t) { return t.riderPhone === r.phone; }).length + '</span></div><button class="btn ghost" data-a="logout">تسجيل الخروج</button><p class="note">الخروج ينهي الجلسة فقط، وسجل الرحلات يبقى محفوظًا على هذا الجهاز.</p></div>';
  else h += '<div class="card"><h2>دخول الراكب (تجريبي)</h2>' + fld('login.name', 'الاسم الكامل', 'مثال: سالم محمد') + fld('login.phone', 'رقم الهاتف', '09XXXXXXXX', 'inputmode="tel"') +
    (ferr.login ? '<div class="err">' + esc(ferr.login) + '</div>' : '') + '<button class="btn" data-a="login">دخول / إنشاء حساب</button><p class="note">تسجيل تجريبي: لا يُرسل أي رمز تحقق ولا يتصل بأي خادم.</p></div>';
  var c = forms.drv;
  h += '<div class="card"><h2>تسجيل سائق جديد</h2><p class="note">يبدأ الطلب «قيد المراجعة» ولا يستقبل رحلات قبل موافقة الإدارة يدويًا.</p>' + fld('drv.name', 'الاسم الكامل', 'اسم السائق') + fld('drv.phone', 'رقم الهاتف', '09XXXXXXXX', 'inputmode="tel"') +
    fld('drv.car', 'نوع السيارة', 'مثال: تويوتا كورولا') + '<label>الفئة</label><select data-f="drv.cat">' + Object.keys(CARS).map(function (k) { return '<option value="' + k + '"' + (c.cat === k ? ' selected' : '') + '>' + CARS[k].name + ' (حتى ' + CARS[k].cap + ')</option>'; }).join('') + '</select>' +
    fld('drv.model', 'الموديل (السنة)', 'مثال: 2018', 'inputmode="numeric"') + fld('drv.color', 'اللون', 'مثال: أبيض') + fld('drv.plate', 'رقم اللوحة', 'مثال: 12-3456') + fld('drv.seats', 'عدد المقاعد للركاب', '4', 'inputmode="numeric"') +
    (ferr.drv ? '<div class="err">' + esc(ferr.drv) + '</div>' : '') + '<button class="btn" data-a="regdrv">إرسال طلب التسجيل</button></div>';
  return h + '<div class="card"><h2>أوضاع التجربة</h2><p class="note">لا يوجد تسجيل دخول حقيقي للسائق أو الإدارة في هذه النسخة؛ الأوضاع أدناه للعرض فقط.</p><div class="btns"><button class="btn sec" data-a="gomode" data-m="driver">وضع السائق</button><button class="btn sec" data-a="gomode" data-m="admin">وضع الإدارة</button></div></div>' +
    '<p class="note">كل البيانات محفوظة محليًا على هذا الهاتف فقط (localStorage) وليست مشتركة بين الأجهزة.</p>';
}
function doLogin() {
  var f = forms.login, ph = phoneN(f.phone); ferr.login = '';
  if (!fullName(f.name)) ferr.login = 'أدخل الاسم الكامل (اسمان على الأقل).';
  else if (!phoneOk(f.phone)) ferr.login = 'أدخل رقم هاتف صحيحًا: 10 أرقام يبدأ بـ 09.';
  else {
    var r = state.riders.filter(function (x) { return x.phone === ph; })[0];
    if (r && r.blocked) ferr.login = 'هذا الحساب معطّل من الإدارة التجريبية.';
    else {
      if (!r) { r = { id: 'r' + Date.now().toString(36), name: f.name.trim(), phone: ph, blocked: false, createdAt: Date.now() }; state.riders.push(r); }
      state.rider = { name: r.name, phone: r.phone }; forms.login = { name: '', phone: '' }; save(); tab = 'home'; toast('أهلًا ' + r.name);
    }
  }
  render();
}
function regDriver() {
  var c = forms.drv, cap = CARS[c.cat].cap, seats = Number(nd(c.seats)), yr = Number(nd(c.model)), ph = phoneN(c.phone);
  ferr.drv = '';
  if (!fullName(c.name)) ferr.drv = 'أدخل الاسم الكامل (اسمان على الأقل).';
  else if (!phoneOk(c.phone)) ferr.drv = 'أدخل رقم هاتف صحيحًا: 10 أرقام يبدأ بـ 09.';
  else if (DRIVERS.some(function (d) { return d.phone === ph; })) ferr.drv = 'رقم الهاتف مسجّل لسائق آخر.';
  else if (c.car.trim().length < 2) ferr.drv = 'أدخل نوع السيارة.';
  else if (!(yr >= 1990 && yr <= 2027)) ferr.drv = 'أدخل سنة الموديل بين 1990 و2027.';
  else if (c.color.trim().length < 2) ferr.drv = 'أدخل لون السيارة.';
  else if (c.plate.trim().length < 3) ferr.drv = 'أدخل رقم اللوحة.';
  else if (DRIVERS.some(function (d) { return nd(d.plate) === nd(c.plate); })) ferr.drv = 'رقم اللوحة مسجّل لسيارة أخرى.';
  else if (!(seats >= 1 && seats <= cap)) ferr.drv = 'عدد المقاعد لفئة «' + CARS[c.cat].name + '» يجب أن يكون بين 1 و' + cap + '.';
  if (ferr.drv) return render();
  var d = { id: 'd' + Date.now().toString(36), name: c.name.trim(), phone: ph, car: c.car.trim(), cat: c.cat, model: String(yr), color: c.color.trim(), plate: c.plate.trim(), seats: seats, status: 'pending', history: [{ status: 'pending', at: Date.now(), by: 'self' }], createdAt: Date.now() };
  state.drivers.push(d); state.cur = d.id; forms.drv = { name: '', phone: '', car: '', cat: 'eco', model: '', color: '', plate: '', seats: '4' }; save();
  toast('أُرسل طلبك: قيد المراجعة.'); tab = 'driver'; render();
}

/* ---------- السائق: الطلبات والأرباح والملف ---------- */
function driverView() {
  var b = function (k, l, i) { return '<button class="' + (dsub === k ? 'on' : '') + '" data-a="dsub" data-s="' + k + '">' + ic(i) + l + '</button>'; }, d = drvOf(state.cur);
  return '<div class="subnav">' + b('req', 'الطلبات', 'car') + b('earn', 'الأرباح', 'wallet') + b('prof', 'الملف', 'user') + '</div>' + (dsub === 'earn' ? driverEarn(d) : dsub === 'prof' ? driverProf(d) : driverHome());
}
function driverEarn(d) {
  var own = state.trips.filter(function (t) { return t.driverId === d.id; }), x = sums(own), paid = paidOf(d.id, false), done = own.filter(function (t) { return t.status === 'completed' && t.settle; }).sort(function (a, b) { return b.settle.at - a.settle.at; });
  return '<div class="card"><h2>أرباح ' + esc(d.name) + ' ' + dbadge(d) + '</h2><div class="stats"><div class="stat"><b>' + money(x.net) + '</b><span>مستحق (بعد العمولة)</span></div><div class="stat"><b>' + money(x.comm) + '</b><span>عمولة المنصة 12%</span></div><div class="stat"><b>' + money(paid) + '</b><span>تم دفعه</span></div><div class="stat"><b>' + money(r2(x.net - paid)) + '</b><span>المتبقي</span></div></div>' +
    '<div class="kv"><span>إجمالي أجرة الرحلات المكتملة</span><span>' + money(x.value) + '</span><span>مكتملة / ملغاة</span><span>' + x.done + ' / ' + x.canc + '</span></div><p class="note">الرحلات الملغاة والجارية لا تدخل في الأرباح. «تم دفعه» يسجّله مدير النظام فقط. حساب السائق الحالي يُغيَّر من صفحة الطلبات.</p></div>' +
    '<h2>الرحلات المكتملة</h2>' + (done.length ? done.map(function (t) { return '<div class="card"><div class="trip-h"><b>#' + t.id + ' ' + esc(t.from) + ' ← ' + esc(t.to) + '</b></div><div class="kv"><span>الأجرة</span><span>' + money(t.settle.price) + '</span><span>العمولة</span><span>' + money(t.settle.commission) + '</span><span>صافيك</span><span>' + money(t.settle.net) + '</span></div><div class="note">' + fmt(t.settle.at) + '</div></div>'; }).join('') : '<div class="card empty">لا رحلات مكتملة بعد.</div>');
}
function driverProf(d) {
  var hs = (d.history || []).slice().reverse().map(function (h) { return '<li><span>' + DSTAT[h.status] + '</span><span>' + fmt(h.at) + '</span></li>'; }).join('');
  return '<div class="card"><div class="avatar">' + esc(d.name.charAt(0)) + '</div><h2>' + esc(d.name) + ' ' + dbadge(d) + '</h2>' + (d.status !== 'approved' ? '<div class="err">' + DMSG[d.status] + '</div>' : '') +
    '<div class="kv"><span>الهاتف</span><span>' + d.phone + '</span><span>السيارة</span><span>' + esc(d.car) + ' ' + esc(d.model) + '</span><span>اللون</span><span>' + esc(d.color) + '</span><span>اللوحة</span><span>' + esc(d.plate) + '</span><span>الفئة / المقاعد</span><span>' + CARS[d.cat].name + ' / ' + d.seats + '</span></div>' +
    (hs ? '<h3>سجل الحالة</h3><ul class="log">' + hs + '</ul>' : '') + '<p class="note">' + (d.demo ? 'سائق تجريبي لأغراض العرض.' : 'بيانات مسجّلة محليًا على هذا الجهاز.') + '</p></div>';
}

/* ---------- الإدارة ---------- */
function adminView() {
  var b = function (k, l) { return '<button class="' + (sub === k ? 'on' : '') + '" data-a="sub" data-s="' + k + '">' + l + '</button>'; };
  var body = sub === 'ac' ? accountsView() : sub === 'dr' ? adminDrivers() : sub === 'us' ? adminRiders() : sub === 'tr' ? adminTrips() : adminDash();
  return '<div class="subnav">' + b('ov', 'لوحة الإحصائيات') + b('tr', 'الرحلات') + b('ac', 'الحسابات والعمولات') + b('dr', 'السائقون') + b('us', 'الركاب') + '</div>' + body;
}
function adminDash() {
  var s = sums(state.trips), n = function (st) { return DRIVERS.filter(function (d) { return d.status === st; }).length; }, rs = {};
  state.trips.forEach(function (t) { if (t.status === 'cancelled' && t.cancel) rs[t.cancel.reason] = (rs[t.cancel.reason] || 0) + 1; });
  var rk = Object.keys(rs).sort(function (a, b) { return rs[b] - rs[a]; }).slice(0, 5), stat = function (v, l) { return '<div class="stat"><b>' + v + '</b><span>' + l + '</span></div>'; };
  return (n('pending') ? '<div class="banner">' + n('pending') + ' طلب سائق بانتظار المراجعة<button data-a="sub" data-s="dr">مراجعة</button></div>' : '') +
    '<div class="stats">' + stat(state.riders.length, 'الركاب') + stat(DRIVERS.length, 'السائقون (' + n('approved') + ' مقبول)') + stat(state.trips.length, 'كل الرحلات') + stat(s.done + ' / ' + s.canc, 'مكتملة / ملغاة') +
    stat(money(s.value), 'قيمة الرحلات المكتملة') + stat(money(s.comm), 'عمولة المنصة 12%') + stat(money(s.net), 'مستحقات السائقين') + stat(s.active, 'جارية / معلقة') + '</div>' +
    '<div class="card"><h2>أسباب الإلغاء الأكثر تكرارًا</h2>' + (rk.length ? '<ul class="log">' + rk.map(function (k) { return '<li><span>' + esc(k) + '</span><span>' + rs[k] + '</span></li>'; }).join('') + '</ul>' : '<div class="empty">لا رحلات ملغاة.</div>') + '</div>' +
    '<div class="card"><h2>الإعدادات المعتمدة</h2><div class="kv"><span>أقل من 5 كم</span><span>11 د.ل</span><span>5–13 كم</span><span>11 + 2 د.ل لكل كم</span><span>أكثر من 13 كم</span><span>27 + 1.75 د.ل لكل كم</span><span>الراكب بعد الثالث</span><span>+20% من الأساسي</span><span>التقريب</span><span>للأعلى دائمًا</span><span>الحد الأقصى للركاب</span><span>7</span><span>جولات التفاوض</span><span>5</span><span>العمولة</span><span>12%</span></div><button class="btn ghost" data-a="reset">استعادة البيانات التجريبية</button></div>';
}
function adminTrips() {
  var q = nd(aq.t), list = state.trips.filter(function (t) {
    var stOk2 = aq.s === 'all' || (aq.s === 'active' ? (t.status === 'negotiating' || t.status === 'confirmed') : t.status === aq.s);
    return stOk2 && (!q || String(t.id) === q || nd(t.riderName).indexOf(q) > -1 || (t.riderPhone || '').indexOf(q) > -1 || nd(drvOf(t.driverId).name).indexOf(q) > -1 || nd(t.from + ' ' + t.to).indexOf(q) > -1);
  }).sort(function (a, b) { return b.created - a.created; });
  return '<input id="tq" placeholder="بحث: رقم الرحلة أو الراكب أو السائق أو المكان" value="' + esc(aq.t) + '"><select id="tsf" style="margin-top:8px">' + opt('all', 'كل الحالات', aq.s) + opt('completed', 'مكتملة', aq.s) + opt('cancelled', 'ملغاة', aq.s) + opt('active', 'جارية / معلقة', aq.s) + '</select><h2 style="margin-top:14px">الرحلات (' + list.length + ')</h2>' +
    (list.length ? list.map(function (t) { return '<div class="card"><div class="trip-h"><b>#' + t.id + ' ' + esc(t.from) + ' ← ' + esc(t.to) + '</b>' + badge(t) + '</div>' + metaRow(t) + summary(t) + cancelInfo(t) + offersLog(t) + cancelArea(t, 'admin') + '</div>'; }).join('') : '<div class="card empty">لا رحلات مطابقة.</div>');
}
function qmatch(q, a, b) { q = nd(q); return !q || nd(a).indexOf(q) > -1 || b.indexOf(q) > -1; }
function adminDrivers() {
  var list = DRIVERS.filter(function (d) { return qmatch(aq.d, d.name, d.phone); });
  var order = { pending: 0, approved: 1, suspended: 2, rejected: 3 }; list = list.slice().sort(function (a, b) { return order[a.status] - order[b.status]; });
  return '<input id="dq" placeholder="بحث عن سائق بالاسم أو الهاتف" value="' + esc(aq.d) + '"><h2 style="margin-top:14px">السائقون (' + list.length + ')</h2>' + (list.length ? list.map(function (d) {
    var own = state.trips.filter(function (t) { return t.driverId === d.id; }), x = sums(own), btn = function (s, l, c) { return '<button class="btn ' + c + '" data-a="dst" data-d="' + d.id + '" data-s="' + s + '">' + l + '</button>'; };
    var acts = d.status === 'pending' ? btn('approved', 'قبول', '') + btn('rejected', 'رفض', 'ghost') : d.status === 'approved' ? btn('suspended', 'إيقاف', 'ghost') : d.status === 'suspended' ? btn('approved', 'إعادة تفعيل', '') : btn('approved', 'قبول بعد المراجعة', 'sec');
    var last = d.history && d.history.length ? d.history[d.history.length - 1] : null;
    return '<div class="card"><div class="trip-h"><b>' + esc(d.name) + (d.demo ? ' <small class="note">(سائق تجريبي)</small>' : '') + '</b><span class="badge ' + DBADGE[d.status] + '">' + DSTAT[d.status] + '</span></div><div class="kv"><span>الهاتف</span><span>' + d.phone + '</span><span>السيارة</span><span>' + esc(d.car) + ' ' + esc(d.model) + ' · ' + esc(d.color) + '</span><span>الفئة / المقاعد</span><span>' + CARS[d.cat].name + ' / ' + d.seats + '</span><span>اللوحة</span><span>' + esc(d.plate) + '</span><span>مكتملة / ملغاة</span><span>' + x.done + ' / ' + x.canc + '</span></div>' +
      (last ? '<div class="note">آخر تحديث للحالة: ' + fmt(last.at) + '</div>' : '') + '<div class="btns">' + acts + '</div></div>';
  }).join('') : '<div class="card empty">لا يوجد سائق مطابق.</div>');
}
function adminRiders() {
  var list = state.riders.filter(function (r) { return qmatch(aq.r, r.name, r.phone); });
  return '<input id="rq" placeholder="بحث عن راكب بالاسم أو الهاتف" value="' + esc(aq.r) + '"><h2 style="margin-top:14px">الركاب (' + list.length + ')</h2>' + (list.length ? list.map(function (r) {
    var own = state.trips.filter(function (t) { return t.riderPhone === r.phone; }), x = sums(own);
    return '<div class="card"><div class="trip-h"><b>' + esc(r.name) + (r.demo ? ' <small class="note">(تجريبي)</small>' : '') + '</b><span class="badge ' + (r.blocked ? 'b-bad' : 'b-ok') + '">' + (r.blocked ? 'معطّل' : 'نشط') + '</span></div><div class="kv"><span>الهاتف</span><span>' + r.phone + '</span><span>رحلات</span><span>' + own.length + '</span><span>مكتملة / ملغاة</span><span>' + x.done + ' / ' + x.canc + '</span></div><button class="btn ' + (r.blocked ? '' : 'ghost') + '" data-a="rblk" data-r="' + r.phone + '">' + (r.blocked ? 'إعادة تفعيل الحساب' : 'تعطيل الحساب') + '</button></div>';
  }).join('') : '<div class="card empty">لا يوجد راكب مطابق.</div>');
}
function setDrv(id, st) {
  var d = DRIVERS.filter(function (x) { return x.id === id; })[0], ok = { pending: ['approved', 'rejected'], rejected: ['approved'], approved: ['suspended'], suspended: ['approved'] };
  if (!d || (ok[d.status] || []).indexOf(st) < 0) return toast('هذا الإجراء غير مسموح لحالة السائق الحالية.');
  d.status = st; d.history = d.history || []; d.history.push({ status: st, at: Date.now(), by: 'admin' }); save(); toast('حالة السائق الآن: ' + DSTAT[st]); render();
}
function viewFor() {
  var back = function (t) { return '<div class="banner">' + t + '<button data-a="goacc">رجوع</button></div>'; };
  if (tab === 'trips') return tripsView();
  if (tab === 'account') return accountView();
  if (tab === 'driver') return back('وضع السائق التجريبي — بلا تسجيل دخول حقيقي') + driverView();
  if (tab === 'admin') return back('وضع الإدارة التجريبي — للعرض فقط، وليس حماية حقيقية. الإدارة الفعلية تحتاج خادمًا ومصادقة وصلاحيات.') + adminView();
  return homeView();
}

/* ---------- أحداث ---------- */
document.addEventListener('click', function (e) {
  var b = e.target.closest('[data-a]'); if (!b) return; var a = b.dataset.a;
  if (a === 'goacc') { tab = 'account'; cancelId = null; window.scrollTo(0, 0); render(); }
  else if (a === 'gomode') { tab = b.dataset.m; cancelId = null; window.scrollTo(0, 0); render(); }
  else if (a === 'dsub') { dsub = b.dataset.s; render(); }
  else if (a === 'pick') pick(b.dataset.p);
  else if (a === 'mode') { form.mode = b.dataset.m; errs = {}; render(); }
  else if (a === 'resetpath') { form.from = ''; form.to = ''; form.km = ''; form.mode = 'from'; errs = {}; render(); }
  else if (a === 'login') doLogin();
  else if (a === 'logout') { state.rider = null; save(); toast('تم تسجيل الخروج. سجل رحلاتك محفوظ.'); render(); }
  else if (a === 'regdrv') regDriver();
  else if (a === 'dst') setDrv(b.dataset.d, b.dataset.s);
  else if (a === 'rblk') { var r = state.riders.filter(function (x) { return x.phone === b.dataset.r; })[0]; if (r) { r.blocked = !r.blocked; save(); toast(r.blocked ? 'عُطّل حساب الراكب.' : 'أُعيد تفعيل حساب الراكب.'); render(); } }
});
document.addEventListener('input', function (e) {
  var f = e.target.dataset && e.target.dataset.f;
  if (f) { var o = f.split('.'); forms[o[0]][o[1]] = e.target.value; return; }
  var id = e.target.id;
  if (id === 'km') { form.km = e.target.value; refreshPrice(); return; }
  if (id !== 'dq' && id !== 'rq' && id !== 'tq') return;
  aq[id === 'dq' ? 'd' : id === 'rq' ? 'r' : 't'] = e.target.value; var p = e.target.selectionStart; render();
  var n = document.getElementById(id); if (n) { n.focus(); try { n.setSelectionRange(p, p); } catch (x) {} }
});
document.addEventListener('change', function (e) {
  var f = e.target.dataset && e.target.dataset.f, id = e.target.id;
  if (f) { var o = f.split('.'); forms[o[0]][o[1]] = e.target.value; }
  else if (id === 'tsf') { aq.s = e.target.value; render(); }
  else if (id === 'from' || id === 'to') { form[id] = e.target.value; if (form.from && form.from === form.to) { form.to = ''; toast('الوجهة تطابق الانطلاق، اختر وجهة أخرى.'); } render(); }
});
