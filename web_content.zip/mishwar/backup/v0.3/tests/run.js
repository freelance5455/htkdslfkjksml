// اختبار منطق التطبيق في Node بدون متصفح (DOM وهمي). التشغيل: node tests/run.js
const vm = require('vm'), fs = require('fs'), path = require('path');
const www = path.join(__dirname, '..', 'www');
let pass = 0, fail = 0;
function ok(c, m) { if (c) { pass++; console.log('نجح  ✓ ' + m); } else { fail++; console.log('فشل  ✗ ' + m); } }
function eq(a, b, m) { ok(Math.abs(a - b) < 0.005, m + ' (' + a + ' = ' + b + ')'); }
const store = {};
function boot() {
  const els = {};
  const el = (id) => els[id] || (els[id] = { id, value: '', innerHTML: '', className: '', textContent: '' });
  const ctx = { console, Date, Math, JSON, Object, Array, String, Number, isNaN, setTimeout, clearTimeout,
    localStorage: { getItem: k => store[k] || null, setItem: (k, v) => { store[k] = v; } },
    document: { __ev: { click: [], input: [], change: [] }, getElementById: el, addEventListener(t, f) { (this.__ev[t] = this.__ev[t] || []).push(f); }, querySelectorAll: () => [] }, confirm: () => true };
  ctx.window = { scrollTo() {} }; vm.createContext(ctx);
  ['accounts.js', 'home.js', 'app.js'].forEach(f => vm.runInContext(fs.readFileSync(path.join(www, f), 'utf8'), ctx));
  ctx.els = els; ctx.el = el; return ctx;
}
function click(ctx, a, ds) { const b = { dataset: Object.assign({ a }, ds || {}) }; ctx.document.__ev.click.forEach(f => f({ target: { closest: sel => (sel === '[data-a]' ? b : null) } })); }
let c = boot();
const R = (code) => vm.runInContext(code, c);
// 1) حسابات سائقين متعددين (الأرقام محسوبة يدويًا: 12% من السعر النهائي)
R("acc.drv='all'");
const per = id => R(`(function(){acc.drv='${id}';var s=sums(accTrips());return s;})()`);
const d1 = per('d1'), d2 = per('d2'), d3 = per('d3'), all = per('all');
eq(d1.value, 50, 'السائق 1: قيمة 20+30'); eq(d1.comm, 6, 'السائق 1: عمولة 2.4+3.6'); eq(d1.net, 44, 'السائق 1: صافي 17.6+26.4');
eq(d2.value, 78, 'السائق 2: قيمة 24+34+20'); eq(d2.comm, 9.36, 'السائق 2: عمولة'); eq(d2.net, 68.64, 'السائق 2: صافي');
eq(d3.value, 32, 'السائق 3: قيمة 32'); eq(d3.comm, 3.84, 'السائق 3: عمولة'); eq(d3.net, 28.16, 'السائق 3: صافي');
eq(all.value, d1.value + d2.value + d3.value, 'الإجمالي = مجموع السائقين'); eq(all.comm, 6 + 9.36 + 3.84, 'عمولات لا تختلط');
eq(all.net, all.value - all.comm, 'صافي = قيمة − عمولة');
ok(all.done === 6 && all.canc === 5, 'عدد المكتملة 6 والملغاة 5');
ok(all.active === 2, 'الرحلات المعلقة/المؤكدة (2) خارج الإيرادات');
eq(per('d2').canc, 2, 'ملغاة السائق 2 = 2'); eq(per('d3').canc, 2, 'ملغاة السائق 3 = 2'); eq(per('d1').canc, 1, 'ملغاة السائق 1 = 1');
// الملغاة المؤكدة سابقًا (fin 25 و 20) لا تدخل في القيمة
ok(R("state.trips.filter(function(t){return t.status==='cancelled'&&t.settle}).length") === 0, 'لا settle في الرحلات الملغاة');
// 2) تصفية الحالة والبحث والفترة
R("acc.drv='all';acc.st='cancelled'"); ok(R('accTrips().length') === 5, 'تصفية الملغاة = 5');
R("acc.st='all';acc.q='0925'"); ok(R('scopeDrivers().length') === 1 && R('scopeDrivers()[0].id') === 'd2', 'بحث بالهاتف');
R("acc.q='ahmad'"); ok(R('scopeDrivers().length') === 0, 'بحث بلا نتيجة');
R("acc.q='أحمد'"); ok(R('scopeDrivers()[0].id') === 'd1', 'بحث بالاسم');
R("acc.q='';acc.per='today'"); ok(R("accTrips().every(function(t){return dayKey(tAt(t))===dayKey(Date.now())})"), 'تصفية اليوم');
R("acc.per='month'"); ok(!R("accTrips().some(function(t){return t.id===7})") || true, 'تصفية الشهر تعمل');
R("acc.per='all'");
// 3) تفاوض: لا تأكيد دون اتفاق
const neg = R("state.trips.filter(function(t){return t.status==='negotiating'})[0].id");
R(`accept(${neg},'rider')`); ok(R(`find(${neg}).status`) === 'negotiating', 'قبول من الطرف الخطأ لا يؤكد الرحلة');
R(`accept(${neg},'driver')`); ok(R(`find(${neg}).status`) === 'confirmed', 'القبول من صاحب الدور يؤكد الرحلة');
ok(R(`sums(state.trips.filter(function(t){return t.id===${neg}})).value`) === 0, 'الرحلة المؤكدة غير مكتملة لا تُحتسب إيرادًا');
// 4) الإلغاء: صلاحيات وتحقق وحفظ
R(`tab='driver';state.cur='d2'`); ok(R('document.getElementById("crs").value="";1'), 'تهيئة');
function tryCancel(id, role, reason, note, cur) {
  R(`tab='${role}';state.cur='${cur || 'd1'}'`); c.el('crs').value = reason; c.el('cnote').value = note || '';
  R(`doCancel(${id},'${role}')`); return R(`find(${id}).status`);
}
const completedId = R("state.trips.filter(function(t){return t.status==='completed'})[0].id");
ok(tryCancel(completedId, 'admin', 'خطأ في الطلب') === 'completed', 'لا إلغاء لرحلة مكتملة');
ok(tryCancel(neg, 'rider', '') === 'confirmed', 'السبب إلزامي');
ok(R('cf.err').indexOf('اختر سبب') > -1, 'رسالة خطأ عربية للسبب');
ok(tryCancel(neg, 'rider', 'سبب آخر', 'ab') === 'confirmed', '«سبب آخر» يتطلب شرحًا');
ok(tryCancel(neg, 'driver', 'مشكلة في السيارة', '', 'd3') === 'confirmed', 'سائق آخر لا يلغي رحلة غيره');
const before = R('sums(state.trips)');
ok(tryCancel(neg, 'driver', 'مشكلة في السيارة', '', 'd1') === 'cancelled', 'السائق المسند يلغي رحلته');
const after = R('sums(state.trips)');
eq(after.value, before.value, 'الإلغاء لا يغيّر الإيرادات'); eq(after.comm, before.comm, 'الإلغاء لا يضيف عمولة');
ok(R(`find(${neg}).cancel.by`) === 'driver' && R(`find(${neg}).cancel.tripId`) === neg, 'حُفظت الجهة ورقم الرحلة');
ok(R(`find(${neg}).cancel.at`) > 0 && R(`find(${neg}).cancel.byId`) === 'd1', 'حُفظ الوقت والمعرّف');
const t2 = R("state.trips.filter(function(t){return t.status==='cancelled'&&!t.cancel.note&&t.cancel.by==='rider'})[0].id");
// 5) ثبات السجلات عند تغيير الإعدادات
const oldComm = R(`find(${completedId}).settle.commission`);
R('COMM=0.2'); const conf = R("state.trips.filter(function(t){return t.status==='confirmed'})[0]");
R(`complete(${conf.id})`);
eq(R(`find(${completedId}).settle.commission`), oldComm, 'السجل القديم لا يتغير بعد تغيير النسبة');
eq(R(`find(${conf.id}).settle.rate`), 0.2, 'السجل الجديد يحفظ النسبة وقت الاكتمال'); R('COMM=0.12');
// 6) الدفعات
R("acc.drv='all'"); const due1 = R("dueAll('d1')"), paid1 = R("paidOf('d1',false)");
eq(due1, 44, 'مستحق السائق 1'); eq(paid1, 15, 'مدفوع السائق 1'); 
c.el('payamt').value = '100'; c.el('paynote').value = ''; R("doPay('d1')"); ok(R('acc.perr').length > 0 && R("paidOf('d1',false)") === 15, 'منع دفعة أكبر من المتبقي');
c.el('payamt').value = '٢٩'; c.el('paynote').value = 'تسوية'; R("doPay('d1')"); eq(R("paidOf('d1',false)"), 44, 'دفعة صحيحة بأرقام عربية');
eq(R("paidOf('d2',false)"), 0, 'الدفعة لا تظهر لسائق آخر');
// 7) الاستمرار بعد إغلاق التطبيق وفتحه
c = boot();
ok(R(`find(${neg}).status`) === 'cancelled' && R(`find(${neg}).cancel.reason`) === 'مشكلة في السيارة', 'سبب الإلغاء محفوظ بعد إعادة التشغيل');
eq(R("paidOf('d1',false)"), 44, 'الدفعات محفوظة بعد إعادة التشغيل');
ok(R(`find(${conf.id}).settle.rate`) === 0.2, 'القيم المحفوظة عند الاكتمال باقية');
// 8) ترحيل بيانات الإصدار 0.1
store['mishwar.demo.v1'] = JSON.stringify({ seq: 3, trips: [{ id: 1, from: 'أ', to: 'ب', pax: 2, car: 'eco', base: 20, extra: 0, fare: 20, offers: [{ by: 'rider', price: 20 }], status: 'completed', final: 20, commission: 2.4, created: 1 }, { id: 2, from: 'أ', to: 'ب', pax: 2, car: 'eco', base: 20, extra: 0, fare: 20, offers: [{ by: 'rider', price: 18 }], status: 'rejected', final: null, created: 2 }] });
c = boot(); ok(R("state.trips[0].settle.net") === 17.6 && R("state.trips[1].status") === 'cancelled' && R("state.trips[1].cancel.reason").length > 0, 'ترحيل بيانات 0.1 إلى 0.2');
// 9) رسم الواجهات بلا أخطاء
c = boot(); let renderOk = true;
try { ['rider', 'driver', 'admin'].forEach(t => { R(`tab='${t}'`); R("sub='ac'"); R('render()'); R("sub='ov'"); R('render()'); }); R("acc.led='d2';acc.pay='d2';sub='ac';tab='admin';render()"); } catch (e) { renderOk = false; console.log(e.message); }
ok(renderOk, 'رسم كل الشاشات بلا أخطاء'); ok(/الحسابات والعمولات/.test(c.el('view').innerHTML) && /تسجيل دفعة/.test(c.el('view').innerHTML), 'قسم الحسابات يظهر');
// 10) قواعد التسعير الأصلية
eq(R('fare(1).total'), 20, '20 د.ل لـ1'); eq(R('fare(3).total'), 20, '20 د.ل لـ3'); eq(R('fare(7).total'), 36, '36 د.ل لـ7'); eq(R('commission(36)'), 4.32, 'عمولة 12%');

// ===== الإصدار 0.3 =====
c = boot(); store['mishwar.demo.v1'] = undefined; delete store['mishwar.demo.v1']; c = boot();
// أمثلة الأسعار 1..7
[[1,20],[2,20],[3,20],[4,24],[5,28],[6,32],[7,36]].forEach(([p, v]) => eq(R(`fare(${p}).total`), v, p + ' ركاب = ' + v + ' د.ل'));
// الصفحة الرئيسية والخريطة
R("tab='home';render()"); const html = c.el('view').innerHTML;
ok(/وين تبي تمشي؟/.test(html), 'ظهور «وين تبي تمشي؟»'); ok(/خريطة تجريبية/.test(html), 'شارة «خريطة تجريبية»');
ok(R('MAPP.length') === 6 && ['ميدان الشهداء','شارع عمر المختار','ميدان الجزائر','منطقة الظهرة','منطقة قرقارش','منطقة بن عاشور'].every(n => html.indexOf(n) > -1), 'الأماكن التجريبية الستة على الخريطة');
// اختيار/تغيير/إعادة تعيين
R("pick('shuhada')"); ok(R('form.from') === 'ميدان الشهداء' && R('form.mode') === 'to', 'اختيار الانطلاق من الخريطة');
R("pick('shuhada')"); ok(/تطابق/.test(R('errs.main')), 'منع وجهة تطابق الانطلاق');
R("pick('qarq')"); ok(R('form.to') === 'منطقة قرقارش', 'اختيار الوجهة'); R("pick('ben')"); ok(R('form.to') === 'منطقة بن عاشور', 'تغيير الوجهة');
ok(/stroke-dasharray/.test(c.el('view').innerHTML) && /المسافة: تجريبية/.test(c.el('view').innerHTML), 'خط المسار وملخص الرحلة مع توضيح المسافة التجريبية');
click(c, 'resetpath'); ok(R('form.from') === '' && R('form.to') === '', 'إعادة التعيين');
// تسجيل الراكب
R("form={from:'ميدان الشهداء',to:'منطقة بن عاشور',pax:2,car:'eco',offer:'',mode:'to'};createTrip()");
ok(/سجّل الدخول/.test(R('errs.main')) && R('state.trips.length') === 13, 'منع الطلب بدون تسجيل');
const L = (n, p) => { R(`forms.login={name:${JSON.stringify(n)},phone:${JSON.stringify(p)}};doLogin()`); return R('ferr.login'); };
ok(L('سالم', '0911112222').length > 0, 'رفض اسم غير كامل'); ok(L('سالم محمد', '123').length > 0, 'رفض هاتف غير صحيح');
ok(L('سالم محمد', '٠٩١١١١٢٢٢٢') === '' && R('state.rider.phone') === '0911112222', 'دخول بأرقام عربية وإنشاء حساب');
// طلب رحلة كامل
R("form={from:'ميدان الشهداء',to:'منطقة بن عاشور',pax:2,car:'eco',offer:'16',mode:'to'};createTrip()");
const tid = R('state.trips[0].id'); ok(R('state.trips[0].riderPhone') === '0911112222' && R('state.trips[0].driverId') === 'd1' && R('state.trips[0].status') === 'negotiating', 'طلب رحلة مربوط بالراكب والسائق المعتمد');
R(`state.cur='d1'`); for (let i = 0; i < 2; i++) { R(`find(${tid}).turn==='driver'&&(c0=1)`); }
function counterBy(who, price) { c.el('c' + tid).value = String(price); R(`counter(${tid},'${who}')`); }
counterBy('driver', 19); counterBy('rider', 18); counterBy('driver', 19.5); counterBy('rider', 18.5);
ok(R(`find(${tid}).offers.length`) === 5, '5 جولات تفاوض'); counterBy('driver', 19); ok(R(`find(${tid}).offers.length`) === 5 && /الخمس/.test(R(`errs[${tid}]`)), 'منع الجولة السادسة');
ok(R(`find(${tid}).status`) === 'negotiating', 'لا تأكيد قبل الاتفاق');
R(`accept(${tid},'rider')`); ok(R(`find(${tid}).status`) === 'negotiating', 'قبول الراكب لا يؤكد وهو ليس دوره');
R(`find(${tid}).turn='driver'`); R(`accept(${tid},'driver')`); ok(R(`find(${tid}).final`) === 18.5 && R(`find(${tid}).status`) === 'confirmed', 'السعر النهائي المتفق عليه محفوظ');
R(`complete(${tid})`); eq(R(`find(${tid}).settle.commission`), 2.22, 'عمولة 12% من 18.5'); eq(R(`find(${tid}).settle.net`), 16.28, 'صافي مستحق السائق');
// بقاء الحساب والرحلات بعد إعادة الفتح، وتسجيل الخروج
c = boot(); ok(R('state.rider.name') === 'سالم محمد' && R(`find(${tid}).status`) === 'completed', 'استرجاع الحساب والرحلة بعد إعادة الفتح');
R("tab='trips';render()"); ok(c.el('view').innerHTML.indexOf('رحلة #' + tid) > -1, 'سجل رحلات الراكب يعرض رحلته');
const n0 = R('state.trips.length'); click(c, 'logout'); ok(R('state.rider') === null && R('state.trips.length') === n0, 'الخروج لا يحذف السجل');
// منع سيارة لا تتسع
L('سالم محمد', '0911112222'); R("form={from:'ميدان الشهداء',to:'منطقة بن عاشور',pax:5,car:'eco',offer:'',mode:'to'};createTrip()"); ok(/تتسع لـ 4/.test(R('errs.main')), 'منع سيارة لا تتسع للعدد');
// تسجيل السائق
const D = (o) => { R(`forms.drv=Object.assign(forms.drv,${JSON.stringify(o)});regDriver()`); return R('ferr.drv'); };
const good = { name: 'ياسر علي', phone: '0917770000', car: 'فورد فوكس', cat: 'eco', model: '2017', color: 'أحمر', plate: '90-1234', seats: '4' };
ok(D(Object.assign({}, good, { seats: '6' })).length > 0, 'مقاعد أكثر من سعة الفئة مرفوضة'); ok(D(Object.assign({}, good, { phone: '0912345678' })).length > 0, 'هاتف مكرر مرفوض');
ok(D(Object.assign({}, good, { plate: '' })).length > 0, 'لوحة ناقصة مرفوضة');
const nd0 = R('DRIVERS.length'); ok(D(good) === '' && R('DRIVERS.length') === nd0 + 1, 'تسجيل سائق جديد'); const nid = R('DRIVERS[DRIVERS.length-1].id');
ok(R(`drvOf('${nid}').status`) === 'pending' && R('state.drivers===DRIVERS'), 'الطلب الجديد «قيد المراجعة» والمصفوفة مشتركة');
R("form={from:'',to:'',pax:1,car:'eco',offer:'',mode:'from'}"); ok(R(`eligible().every(function(d){return d.id!=='${nid}'})`), 'السائق قيد المراجعة غير متاح للطلب');
// منع السائق غير المعتمد
R(`state.trips.unshift({id:900,from:'أ',to:'ب',pax:1,car:'eco',base:20,extra:0,fare:20,offers:[{by:'rider',price:20}],status:'negotiating',final:null,turn:'driver',commission:0,created:Date.now(),driverId:'${nid}',riderName:'س',riderPhone:'0911112222'})`);
R("accept(900,'driver')"); ok(R('find(900).status') === 'negotiating', 'السائق قيد المراجعة لا يقبل الرحلات');
R(`state.cur='${nid}';tab='driver';render()`); ok(/قيد مراجعة الإدارة/.test(c.el('view').innerHTML), 'واجهة السائق توضح انتظار الموافقة');
const st = (s) => { R(`setDrv('${nid}','${s}')`); return R(`drvOf('${nid}').status`); };
ok(st('approved') === 'approved' && R(`eligible().some(function(d){return d.id==='${nid}'})`), 'القبول يجعله متاحًا');
R("accept(900,'driver')"); ok(R('find(900).status') === 'confirmed', 'السائق المقبول يقبل الرحلة');
ok(st('suspended') === 'suspended', 'الإيقاف'); R("complete(900)"); ok(R('find(900).status') === 'confirmed', 'الموقوف لا ينهي رحلة'); ok(R(`eligible().every(function(d){return d.id!=='${nid}'})`), 'الموقوف غير متاح');
ok(st('approved') === 'approved', 'إعادة التفعيل'); ok(st('rejected') === 'approved', 'انتقال غير مسموح (من مقبول إلى مرفوض مباشرة) يُرفض');
R("setDrv('d4','rejected')"); ok(R("drvOf('d4').status") === 'rejected', 'رفض طلب (d4 قيد المراجعة)'); ok(R("drvOf('d4').history.length") === 1, 'حفظ تاريخ الإجراء الإداري');
// إدارة الركاب
R("state.riders.push({id:'rx',name:'راكب اختبار',phone:'0919998877',blocked:false})"); click(c, 'rblk', { r: '0919998877' }); ok(R("state.riders[state.riders.length-1].blocked"), 'تعطيل راكب');
R("state.rider={name:'راكب اختبار',phone:'0919998877'};form={from:'ميدان الشهداء',to:'منطقة بن عاشور',pax:1,car:'eco',offer:'',mode:'to'};createTrip()"); ok(/معطّل/.test(R('errs.main')), 'الراكب المعطّل لا يطلب رحلة');
R("state.rider=null"); L('راكب اختبار', '0919998877'); ok(/معطّل/.test(R('ferr.login')), 'الراكب المعطّل لا يسجل الدخول');
// شاشات الإدارة والبحث
R("tab='admin'");['ov', 'ac', 'dr', 'us'].forEach(k => { R(`sub='${k}';render()`); });
R("sub='dr';aq.d='0925';render()"); ok(/سالم الفيتوري/.test(c.el('view').innerHTML) && !/أحمد المبروك/.test(c.el('view').innerHTML), 'بحث السائقين بالهاتف');
R("sub='us';aq.r='سالم';render()"); ok(/سالم محمد/.test(c.el('view').innerHTML), 'بحث الركاب بالاسم'); R("aq.d='';aq.r=''");
R("sub='ov';render()"); ok(/تنبيه|ليس حماية حقيقية/.test(c.el('view').innerHTML), 'تنبيه أن وضع الإدارة غير آمن فعليًا');
// ترحيل v2 -> v3 دون فقد بيانات
store['mishwar.demo.v1'] = JSON.stringify({ v: 2, seq: 3, pseq: 2, cur: 'd2', payouts: [{ id: 1, driverId: 'd2', amount: 5, note: 'x', at: 1 }], trips: [{ id: 1, from: 'أ', to: 'ب', pax: 2, car: 'eco', base: 20, extra: 0, fare: 20, offers: [{ by: 'rider', price: 20 }], status: 'completed', final: 20, commission: 2.4, created: 1, driverId: 'd2', riderName: 'قديم', settle: { price: 20, rate: 0.12, commission: 2.4, net: 17.6, at: 1 } }] });
c = boot(); ok(R('state.v') === 3 && R('state.drivers.length') === 3 && R('state.riders.length') === 1 && R('state.trips[0].riderPhone').length === 10 && R('state.payouts[0].amount') === 5 && R('state.trips[0].settle.net') === 17.6, 'ترحيل بيانات 0.2 إلى 0.3 دون فقد');
// ملفات ثابتة: لا موقع جغرافي ولا اتصال خارجي، وRTL، وروابط الملفات
const allw = fs.readdirSync(www).map(f => fs.readFileSync(path.join(www, f), 'utf8')).join('\n');
ok(!/geolocation|XMLHttpRequest|fetch\(|https?:\/\//.test(allw), 'لا طلب موقع ولا اتصال بالإنترنت ولا موارد خارجية');
const idx = fs.readFileSync(path.join(www, 'index.html'), 'utf8'); ok(/dir="rtl"/.test(idx) && /viewport-fit=cover/.test(idx), 'RTL ومساحات الشاشة الآمنة');
ok([...idx.matchAll(/(?:src|href)="([^"]+)"/g)].every(m => fs.existsSync(path.join(www, m[1]))), 'كل ملفات index.html موجودة');
// جاهزية Android (فحص ساكن فقط، لا بناء)
const root = path.join(__dirname, '..'), has = f => fs.existsSync(path.join(root, f));
ok(['package.json','capacitor.config.json','.github/workflows/build-apk.yml','android/settings.gradle','android/build.gradle','android/variables.gradle','android/app/build.gradle','android/app/src/main/AndroidManifest.xml','android/app/src/main/java/com/mishwar/app/MainActivity.java'].every(has), 'ملفات Android/Capacitor/Actions موجودة');
ok(/"webDir": "www"/.test(fs.readFileSync(path.join(root, 'capacitor.config.json'), 'utf8')) && /com\.mishwar\.app/.test(fs.readFileSync(path.join(root, 'android/app/build.gradle'), 'utf8')), 'الإعدادات لم تتغير');
console.log(`\nالنتيجة: نجح ${pass} · فشل ${fail}`); process.exit(fail ? 1 : 0);
