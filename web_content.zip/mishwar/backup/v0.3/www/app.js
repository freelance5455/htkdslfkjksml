'use strict';
/* مشوار — نسخة تجريبية محلية. كل البيانات تُحفظ في localStorage داخل الهاتف. */
var KEY = 'mishwar.demo.v1';
var BASE = 20, INCLUDED = 3, MAXPAX = 7, EXTRA_RATE = 0.2, COMM = 0.12, MAXROUNDS = 5;
var CARS = {
  eco:    { name: 'اقتصادية', cap: 4 },
  comfort:{ name: 'مريحة',    cap: 4 },
  family: { name: 'عائلية',   cap: 7 }
};
var PLACES = ['وسط المدينة','ميدان الشهداء','مطار معيتيقة','جامعة طرابلس','طريق الشط','سوق الجمعة','حي الأندلس','عين زارة','تاجوراء','جنزور'];
var DRIVER = 'أحمد المبروك';
var state, tab = 'home', form = { from: '', to: '', pax: 1, car: 'eco', offer: '', mode: 'from' }, errs = {};

function money(n) { return (Math.round(n * 100) / 100).toFixed(2).replace(/\.00$/, '') + ' د.ل'; }
function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
function pax(n) { return n === 1 ? 'راكب واحد' : n === 2 ? 'راكبان' : n + (n < 11 ? ' ركاب' : ' راكبًا'); }

function fare(p) {
  var extraPax = Math.max(0, p - INCLUDED);
  var extra = extraPax * BASE * EXTRA_RATE;
  return { extraPax: extraPax, extra: extra, total: BASE + extra };
}
function commission(price) { return Math.round(price * COMM * 100) / 100; }

function save() { try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (e) { toast('تعذّر حفظ البيانات على الهاتف.'); } }
function toast(m) { var t = document.getElementById('toast'); t.textContent = m; t.className = 'show'; clearTimeout(toast.h); toast.h = setTimeout(function () { t.className = ''; }, 2600); }

function parsePrice(v) {
  var s = String(v).replace(/[٠-٩]/g, function (d) { return d.charCodeAt(0) - 1632; }).replace('٫', '.').replace(',', '.').trim();
  var n = Number(s);
  if (s === '' || isNaN(n)) return { err: 'أدخل سعرًا صحيحًا بالأرقام.' };
  if (n < 5) return { err: 'السعر منخفض جدًا. الحد الأدنى 5 دنانير.' };
  if (n > 500) return { err: 'السعر مرتفع جدًا. الحد الأعلى 500 دينار.' };
  return { v: Math.round(n * 100) / 100 };
}
function find(id) { return state.trips.filter(function (t) { return t.id === id; })[0]; }
function badge(t) {
  if (t.status === 'negotiating') return '<span class="badge b-neg">قيد التفاوض</span>';
  if (t.status === 'confirmed') return '<span class="badge b-ok">مؤكدة</span>';
  if (t.status === 'completed') return '<span class="badge b-done">مكتملة</span>';
  return '<span class="badge b-bad">' + (t.status === 'rejected' ? 'مرفوضة' : 'ملغاة') + '</span>';
}

/* ---------- عمليات التفاوض ---------- */
function accept(id, who) {
  var t = find(id); if (!t || t.status !== 'negotiating' || t.turn !== who) return;
  if (who === 'driver' && !driverOk(t)) return;
  var last = t.offers[t.offers.length - 1];
  t.final = last.price; t.commission = commission(t.final); t.status = 'confirmed'; t.turn = null; save();
  toast('اتفق الطرفان على ' + money(t.final) + '. الرحلة مؤكدة.'); render();
}
function counter(id, who) {
  var t = find(id); if (!t || t.status !== 'negotiating' || t.turn !== who) return;
  if (who === 'driver' && !driverOk(t)) return;
  var inp = document.getElementById('c' + id), p = parsePrice(inp ? inp.value : '');
  if (t.offers.length >= MAXROUNDS) { errs[id] = 'انتهت جولات التفاوض الخمس. اقبل العرض أو ارفضه.'; return render(); }
  if (p.err) { errs[id] = p.err; return render(); }
  if (p.v === t.offers[t.offers.length - 1].price) { errs[id] = 'هذا هو السعر المعروض حاليًا. اضغط «قبول» أو اقترح سعرًا مختلفًا.'; return render(); }
  delete errs[id];
  t.offers.push({ by: who, price: p.v }); t.turn = who === 'rider' ? 'driver' : 'rider'; save();
  toast('أُرسل العرض المضاد.'); render();
}
function reject(id, who) {
  var t = find(id); if (!t || t.status !== 'negotiating') return;
  t.status = who === 'driver' ? 'rejected' : 'cancelled'; t.turn = null; save(); toast('أُنهي التفاوض.'); render();
}
function complete(id) { var t = find(id); if (t && t.status === 'confirmed' && driverOk(t)) { t.status = 'completed'; t.settle = makeSettle(t.final, Date.now()); t.commission = t.settle.commission; save(); toast('اكتملت الرحلة وسُجّلت العمولة.'); render(); } }
function resetDemo() { if (confirm('سيتم حذف كل الرحلات واستعادة البيانات التجريبية. متابعة؟')) { state = seed(); DRIVERS = state.drivers; save(); toast('أُعيدت البيانات التجريبية.'); render(); } }

/* ---------- عرض ---------- */
function offersLog(t) {
  var rounds = t.offers.map(function (o, i) {
    return '<li' + (i === t.offers.length - 1 ? ' class="last"' : '') + '><span>الجولة ' + (i + 1) + ' — ' + (o.by === 'rider' ? 'الراكب' : 'السائق') + '</span><span>' + money(o.price) + '</span></li>';
  }).join('');
  return '<h3>سجل العروض (' + t.offers.length + ' من ' + MAXROUNDS + ')</h3><ul class="log">' + rounds + '</ul>';
}
function summary(t) {
  var price = t.final != null ? t.final : t.offers[t.offers.length - 1].price;
  var r = '<div class="kv"><span>عدد الركاب</span><span>' + t.pax + '</span>' +
    '<span>السعر الأساسي</span><span>' + money(t.base) + '</span>' +
    '<span>رسوم الركاب الإضافيين</span><span>' + money(t.extra) + '</span>' +
    '<span>السعر المقترح من النظام</span><span>' + money(t.fare) + '</span>' +
    '<span>' + (t.final != null ? 'السعر النهائي' : 'آخر عرض') + '</span><span>' + money(price) + '</span>';
  r += moneyRows(t);
  return r + '</div>';
}
function negBox(t, who) {
  var last = t.offers[t.offers.length - 1], full = t.offers.length >= MAXROUNDS;
  var h = '<h3>' + (who === 'driver' ? 'عرض الراكب' : 'عرض السائق') + ': ' + money(last.price) + '</h3>';
  if (!full) h += '<input id="c' + t.id + '" inputmode="decimal" placeholder="اقترح سعرًا مضادًا (د.ل)">';
  else h += '<p class="note">هذه الجولة الأخيرة: اقبل العرض أو ارفضه.</p>';
  if (errs[t.id]) h += '<div class="err">' + esc(errs[t.id]) + '</div>';
  h += '<div class="btns"><button class="btn" data-a="accept" data-id="' + t.id + '" data-w="' + who + '">قبول ' + money(last.price) + '</button>';
  if (!full) h += '<button class="btn sec" data-a="counter" data-id="' + t.id + '" data-w="' + who + '">عرض مضاد</button>';
  return h + '</div>';
}
function tripCard(t, role) {
  var h = '<div class="card"><div class="trip-h"><b>' + esc(t.from) + ' ← ' + esc(t.to) + '</b>' + badge(t) + '</div>' +
    '<div class="note">سيارة ' + CARS[t.car].name + ' · ' + pax(t.pax) + (t.demo ? ' · بيانات تجريبية' : '') + '</div>' + metaRow(t) + summary(t) + cancelInfo(t) + offersLog(t);
  if (t.status === 'negotiating') {
    if (t.turn === role) h += negBox(t, role);
    else h += '<p class="note">بانتظار رد ' + (role === 'rider' ? 'السائق — بدّل إلى تبويب السائق للرد.' : 'الراكب — بدّل إلى تبويب الراكب للرد.') + '</p>';
  }
  if (role === 'driver' && t.status === 'confirmed') h += '<button class="btn" data-a="complete" data-id="' + t.id + '">إنهاء الرحلة</button>';
  return h + cancelArea(t, role) + '</div>';
}
function adminOverview() {
  var done = state.trips.filter(function (t) { return t.status === 'completed'; });
  var conf = state.trips.filter(function (t) { return t.status === 'confirmed'; });
  var vol = done.reduce(function (a, t) { return a + t.settle.price; }, 0), com = done.reduce(function (a, t) { return a + t.settle.commission; }, 0);
  var rows = state.trips.map(function (t) {
    return '<div class="card"><div class="trip-h"><b>#' + t.id + ' ' + esc(t.from) + ' ← ' + esc(t.to) + '</b>' + badge(t) + '</div>' + metaRow(t) + summary(t) + cancelInfo(t) + cancelArea(t, 'admin') + '</div>';
  }).join('');
  return '<div class="stats"><div class="stat"><b>' + state.trips.length + '</b><span>إجمالي الرحلات</span></div><div class="stat"><b>' + done.length + '</b><span>مكتملة (' + conf.length + ' مؤكدة)</span></div>' +
    '<div class="stat"><b>' + money(vol) + '</b><span>قيمة الرحلات المكتملة</span></div><div class="stat"><b>' + money(com) + '</b><span>عمولة المنصة 12%</span></div></div>' +
    '<div class="card"><h2>الإعدادات المعتمدة</h2><div class="kv"><span>السعر الأساسي (3 ركاب)</span><span>20 د.ل</span><span>الراكب الإضافي</span><span>+4 د.ل (20%)</span><span>الحد الأقصى للركاب</span><span>7</span><span>جولات التفاوض</span><span>5</span><span>العمولة</span><span>12%</span></div>' +
    '<button class="btn ghost" data-a="reset">استعادة البيانات التجريبية</button></div><h2>كل الرحلات</h2>' + rows;
}
function render() {
  var v = document.getElementById('view');
  v.innerHTML = viewFor();
  Array.prototype.forEach.call(document.querySelectorAll('.tabs button'), function (b) { b.className = b.dataset.tab === (tab === 'driver' || tab === 'admin' ? 'account' : tab) ? 'on' : ''; });
}

/* ---------- أحداث ---------- */
document.addEventListener('input', function (e) {
  var id = e.target.id;
  if (id === 'from' || id === 'to' || id === 'offer' || id === 'rider') form[id] = e.target.value;
});
document.addEventListener('click', function (e) {
  var tb = e.target.closest('.tabs button');
  if (tb) { tab = tb.dataset.tab; errs = {}; window.scrollTo(0, 0); return render(); }
  var b = e.target.closest('[data-a]'); if (!b) return;
  var a = b.dataset.a, id = Number(b.dataset.id);
  if (a === 'pm') {
    var n = form.pax + Number(b.dataset.d);
    if (n > MAXPAX) { errs.main = 'الحد الأقصى 7 ركاب في الرحلة الواحدة.'; return render(); }
    if (n < 1) return;
    errs = {}; form.pax = n;
    if (n > CARS[form.car].cap) { form.car = 'family'; toast('تم اختيار سيارة عائلية لأن العدد يتجاوز 4 ركاب.'); }
    return render();
  }
  if (a === 'car') {
    var k = b.dataset.k;
    if (form.pax > CARS[k].cap) { errs.main = 'سيارة «' + CARS[k].name + '» لا تتسع لـ ' + pax(form.pax) + '. اختر سيارة عائلية.'; return render(); }
    errs = {}; form.car = k; return render();
  }
  if (a === 'create') return createTrip();
  if (a === 'accept') return accept(id, b.dataset.w);
  if (a === 'counter') return counter(id, b.dataset.w);
  if (a === 'reject') return reject(id, b.dataset.w);
  if (a === 'complete') return complete(id);
  if (a === 'reset') return resetDemo();
});

state = load();
DRIVERS = state.drivers;
render();
