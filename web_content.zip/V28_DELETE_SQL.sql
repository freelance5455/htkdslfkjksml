-- V28: safe teacher deletion policies. Run once in Supabase SQL Editor.
-- Does NOT delete any existing data by itself.

alter table public.circles enable row level security;
alter table public.students enable row level security;
alter table public.recitations enable row level security;
alter table public.attendance enable row level security;
alter table public.daily_reports enable row level security;

drop policy if exists "teacher_circles_delete_own" on public.circles;
create policy "teacher_circles_delete_own" on public.circles
for delete to authenticated
using (teacher_id = auth.uid());

drop policy if exists "teacher_students_delete_own" on public.students;
create policy "teacher_students_delete_own" on public.students
for delete to authenticated
using (exists (select 1 from public.circles c where c.id = students.circle_id and c.teacher_id = auth.uid()));

drop policy if exists "teacher_recitations_delete_own" on public.recitations;
create policy "teacher_recitations_delete_own" on public.recitations
for delete to authenticated
using (exists (select 1 from public.students s join public.circles c on c.id=s.circle_id where s.id=recitations.student_id and c.teacher_id=auth.uid()));

drop policy if exists "teacher_attendance_delete_own" on public.attendance;
create policy "teacher_attendance_delete_own" on public.attendance
for delete to authenticated
using (teacher_id = auth.uid() or exists (select 1 from public.circles c where c.id=attendance.circle_id and c.teacher_id=auth.uid()));

drop policy if exists "teacher_daily_reports_delete_own" on public.daily_reports;
create policy "teacher_daily_reports_delete_own" on public.daily_reports
for delete to authenticated
using (teacher_id = auth.uid() or exists (select 1 from public.circles c where c.id=daily_reports.circle_id and c.teacher_id=auth.uid()));

grant delete on public.circles, public.students, public.recitations, public.attendance, public.daily_reports to authenticated;
notify pgrst, 'reload schema';
