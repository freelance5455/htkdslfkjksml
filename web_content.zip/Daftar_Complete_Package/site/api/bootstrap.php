<?php
declare(strict_types=1);
require_once __DIR__ . '/config.php';
$isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>$isHttps,'httponly'=>true,'samesite'=>'Strict']);
session_start();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate');
function respond(array $data, int $status=200): void { http_response_code($status); echo json_encode($data, JSON_UNESCAPED_UNICODE); exit; }
function db(): PDO { static $pdo=null; if($pdo)return $pdo; $pdo=new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4',DB_USER,DB_PASS,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]); return $pdo; }
function body(): array { $x=json_decode(file_get_contents('php://input'),true); return is_array($x)?$x:[]; }
function require_login(): int { if(empty($_SESSION['user_id']))respond(['ok'=>false,'message'=>'ابتدا وارد حساب شوید.'],401); return (int)$_SESSION['user_id']; }
function require_csrf(): void { $t=$_SERVER['HTTP_X_CSRF_TOKEN']??''; if(!$t||!hash_equals($_SESSION['csrf']??'', $t))respond(['ok'=>false,'message'=>'درخواست معتبر نیست؛ صفحه را تازه‌سازی کنید.'],403); }
