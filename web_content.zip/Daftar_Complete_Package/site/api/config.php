<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'ctjeysbt_school');
define('DB_USER', 'ctjeysbt_shooluser');
define('DB_PASS', 'رمز_کاربر_دیتابیس');
