<?php
require_once __DIR__.'/bootstrap.php';
$action=$_GET['action']??'';
if($action==='me'){if(empty($_SESSION['user_id']))respond(['ok'=>false],401);if(empty($_SESSION['csrf']))$_SESSION['csrf']=bin2hex(random_bytes(32));respond(['ok'=>true,'username'=>$_SESSION['username'],'csrf'=>$_SESSION['csrf']]);}
if($_SERVER['REQUEST_METHOD']!=='POST')respond(['ok'=>false,'message'=>'روش درخواست پشتیبانی نمی‌شود.'],405);
if($action==='logout'){require_login();require_csrf();$_SESSION=[];session_regenerate_id(true);respond(['ok'=>true]);}
$x=body();$username=trim((string)($x['username']??''));$password=(string)($x['password']??'');
if(!preg_match('/^[\p{L}\p{N}_.-]{3,100}$/u',$username))respond(['ok'=>false,'message'=>'نام کاربری باید حداقل ۳ نویسه و بدون فاصله باشد.'],422);
if(strlen($password)<8)respond(['ok'=>false,'message'=>'رمز عبور باید حداقل ۸ نویسه باشد.'],422);
try{
 if($action==='register'){$q=db()->prepare('INSERT INTO users(username,password_hash) VALUES(?,?)');try{$q->execute([$username,password_hash($password,PASSWORD_DEFAULT)]);}catch(PDOException $e){if($e->getCode()==='23000')respond(['ok'=>false,'message'=>'این نام کاربری قبلاً ثبت شده است.'],409);throw $e;}$id=(int)db()->lastInsertId();}
 elseif($action==='login'){$q=db()->prepare('SELECT id,username,password_hash FROM users WHERE username=? LIMIT 1');$q->execute([$username]);$u=$q->fetch();if(!$u||!password_verify($password,$u['password_hash']))respond(['ok'=>false,'message'=>'نام کاربری یا رمز عبور نادرست است.'],401);$id=(int)$u['id'];$username=$u['username'];}
 else respond(['ok'=>false,'message'=>'درخواست نامعتبر است.'],400);
 session_regenerate_id(true);$_SESSION['user_id']=$id;$_SESSION['username']=$username;$_SESSION['csrf']=bin2hex(random_bytes(32));respond(['ok'=>true]);
}catch(Throwable $e){error_log($e->getMessage());respond(['ok'=>false,'message'=>'خطای سرور یا اتصال دیتابیس. تنظیمات api/config.php را بررسی کنید.'],500);}
