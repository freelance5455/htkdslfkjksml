<?php
require_once __DIR__.'/bootstrap.php';$userId=require_login();
try{
 if($_SERVER['REQUEST_METHOD']==='GET'){$q=db()->prepare('SELECT data FROM app_data WHERE user_id=?');$q->execute([$userId]);$row=$q->fetch();$decoded=$row?json_decode($row['data'],true):null;respond(['ok'=>true,'data'=>is_array($decoded)?$decoded:null]);}
 if($_SERVER['REQUEST_METHOD']==='POST'){require_csrf();$x=body();$payload=$x['data']??null;if(!is_array($payload))respond(['ok'=>false,'message'=>'ساختار اطلاعات معتبر نیست.'],422);$json=json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE);if($json===false||strlen($json)>5*1024*1024)respond(['ok'=>false,'message'=>'حجم اطلاعات بیش از حد مجاز است.'],413);$q=db()->prepare('INSERT INTO app_data(user_id,data) VALUES(?,?) ON DUPLICATE KEY UPDATE data=VALUES(data)');$q->execute([$userId,$json]);respond(['ok'=>true]);}
 respond(['ok'=>false,'message'=>'روش درخواست پشتیبانی نمی‌شود.'],405);
}catch(Throwable $e){error_log($e->getMessage());respond(['ok'=>false,'message'=>'ذخیره یا دریافت اطلاعات با خطا مواجه شد.'],500);}
