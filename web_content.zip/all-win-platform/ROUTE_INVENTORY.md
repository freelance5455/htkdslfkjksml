# ALL WIN — Route Inventory & Target Map

## Target ALL WIN Navigation Architecture
- `/`: Home / Lobby (Featured, Popular, Categories, New Games)
- `/catalog`: Full Game Catalog with Filters
- `/catalog/:category`: Category specific view (Originals, Slots, Crash, Table, Lottery, Instant, Arcade, Other)
- `/game/:slug`: Game Runtime Viewport & Controls
- `/wallet`: Wallet Overview
- `/wallet/deposit`: Deposit flow
- `/wallet/withdraw`: Withdrawal flow
- `/wallet/history`: Wallet transaction history
- `/activity`: Recent games, wins, losses, and active sessions
- `/history`: Full game history search and round details
- `/promotions`: Promotions catalog and details
- `/vip`: VIP tier status, benefits, and progress
- `/profile`: User profile, security settings, PIN reset
- `/admin`: C-Panel Administrative Dashboard

## Audited External Routes Across All 8 Sources

### 1. `Afterhand` (`afterhand`)
- `/`: Home page featuring interactive live film tables
- `/games/blackjack`: Blackjack game table, coaching grid, practice session
- `/games/blackjack/learn`: Blackjack rules & strategy learning guide
- `/games/poker`: 4-handed Texas Hold'em poker table vs AI
- `/games/poker/learn`: Poker hand evaluation & pot odds guide
- `/games/baccarat`: Baccarat table with 3rd card tableau explanations
- `/games/baccarat/learn`: Baccarat rules guide
- `/games/roulette`: Interactive European & American roulette wheels & betting board
- `/games/roulette/learn`: Roulette rules guide
- `/learn`, `/rules`: Interactive glossary, tutorials, and rules index

### 2. `Rush` (`rush`)
- `/`: Main lobby and matchmaking landing
- `/lobby/:id`: Multiplayer battle royale lobby
- `/play`: Game runner view
- `/profile`: User stats and settings
- `/sign-in`, `/sign-up`: Custom authentication routes
- `/api/games/*`: Server game endpoints (`baccarat`, `blackjack`, `chicken`, `crate-run`, `crash`, `diamonds`, `dice`, `dragon-tower`, `hilo`, `keno`, `limbo`, `mines`, `plinko`, `roulette`, `slots`, `wheel`)

### 3. `vfair-games` (`@vfair/source`)
- `admin-web`: Admin panel dashboard (`/dashboard`, `/players`, `/games`, `/rounds`, `/partners`, `/kpi`)
- `games-verification-web`: Provable fairness verifier (`/verify`, `/calculator`)
- `dice-web`, `limbo-web`, `mines-web`, `plinko-web`, `keno-web`: Individual game WebShell apps

### 4. `stake-originals-clone` (`stake-games-clone`)
- `/`: Home page
- `/crash`, `/plinko`, `/dino`, `/mines`: Game pages

### 5. `casino` (`losslimit-casino`)
- `/`: Lobby (`Lobby.tsx`)
- `/baccarat`, `/blackjack`, `/coinflip`, `/crash`, `/dice`, `/keno`, `/matka`, `/mines`, `/plinko`, `/roulette`, `/slots`, `/teenpatti`, `/wheel`: Individual game routes
- `/admin`, `/statistics`, `/fairness`, `/transactions`: Administrative & utility routes
