import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import './styles/global.css';

import { I18nProvider } from './context/I18nContext.js';
import { ThemeProvider } from './context/ThemeContext.js';
import { AppShell } from './components/layout/AppShell.js';

import { Home } from './pages/Home.js';
import { Register } from './pages/Register.js';
import { Login } from './pages/Login.js';
import { CustomerService } from './pages/CustomerService.js';
import { GameDetail, GamePlay } from './pages/GameView.js';
import { Lobby } from './pages/Lobby.js';
import { Activity } from './pages/Activity.js';
import { Promotion } from './pages/Promotion.js';
import { Wallet } from './pages/Wallet.js';
import { History } from './pages/History.js';
import { Menu } from './pages/Menu.js';
import { Profile } from './pages/Profile.js';
import { Vip } from './pages/Vip.js';
import {
  GiftsPage,
  StatisticsPage,
  NotificationsPage,
  SecurityPage,
  ResponsibleGamingPage,
  SettingsPage,
} from './pages/SubPages.js';

import { ROUTES } from './core/config/routes.js';
import { ScrollToTop } from './components/layout/ScrollToTop.js';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <I18nProvider>
      <ThemeProvider>
        <BrowserRouter>
          <ScrollToTop />
          <AppShell>
            <Routes>
              <Route path={ROUTES.HOME} element={<Home />} />
              <Route path={ROUTES.REGISTER} element={<Register />} />
              <Route path={ROUTES.LOGIN} element={<Login />} />
              <Route path={ROUTES.CUSTOMER_SERVICE} element={<CustomerService />} />
              <Route path={ROUTES.CATALOG} element={<Lobby />} />
              <Route path={ROUTES.CATALOG_CATEGORY} element={<Lobby />} />
              <Route path={ROUTES.GAME_VIEW} element={<GameDetail />} />
              <Route path={ROUTES.GAME_PLAY} element={<GamePlay />} />
              <Route path={ROUTES.ACTIVITY} element={<Activity />} />
              <Route path={ROUTES.PROMOTION} element={<Promotion />} />
              <Route path={ROUTES.WALLET} element={<Wallet />} />
              {/* Non-monetary build: no deposits or withdrawals exist. */}
              <Route path={ROUTES.WALLET_DEPOSIT} element={<Navigate to={ROUTES.WALLET} replace />} />
              <Route path={ROUTES.WALLET_WITHDRAW} element={<Navigate to={ROUTES.WALLET} replace />} />
              <Route path={ROUTES.WALLET_HISTORY} element={<History />} />
              <Route path={ROUTES.GAME_HISTORY} element={<History />} />
              <Route path={ROUTES.MENU} element={<Menu />} />
              <Route path={ROUTES.PROFILE} element={<Profile />} />
              <Route path={ROUTES.VIP} element={<Vip />} />
              <Route path="/menu/gifts" element={<GiftsPage />} />
              <Route path="/menu/statistics" element={<StatisticsPage />} />
              <Route path="/menu/notifications" element={<NotificationsPage />} />
              <Route path="/menu/security" element={<SecurityPage />} />
              <Route path="/menu/responsible-gaming" element={<ResponsibleGamingPage />} />
              <Route path="/menu/settings" element={<SettingsPage />} />
              <Route path="*" element={<Navigate to={ROUTES.HOME} replace />} />
            </Routes>
          </AppShell>
        </BrowserRouter>
      </ThemeProvider>
    </I18nProvider>
  </React.StrictMode>
);
