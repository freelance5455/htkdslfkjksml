import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';

/** Resets scroll position on route changes (mobile page-transition behaviour). */
export const ScrollToTop = () => {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
};
