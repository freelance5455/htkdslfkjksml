import React from 'react';
import { NavLink } from 'react-router-dom';
import { Home, Activity, Gift, Wallet, Menu } from 'lucide-react';
import { LOCKED_BOTTOM_NAV } from '../../core/config/routes.js';
import { useI18n } from '../../context/I18nContext.js';

export const BottomNavigation: React.FC = () => {
  const { t } = useI18n();

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'home': return <Home className="w-5 h-5" />;
      case 'activity': return <Activity className="w-5 h-5" />;
      case 'promotion': return <Gift className="w-5 h-5" />;
      case 'wallet': return <Wallet className="w-5 h-5" />;
      case 'menu': return <Menu className="w-5 h-5" />;
      default: return <Home className="w-5 h-5" />;
    }
  };

  const getLabelKey = (id: string) => {
    switch (id) {
      case 'HOME': return 'home';
      case 'ACTIVITY': return 'activity';
      case 'PROMOTION': return 'promotion';
      case 'WALLET': return 'wallet';
      case 'MENU': return 'menu';
      default: return 'home';
    }
  };

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#12213D] border-t border-[#243A66] safe-area-bottom shadow-2xl">
      <div className="flex items-center justify-between h-16 max-w-lg mx-auto">
        {LOCKED_BOTTOM_NAV.map((item) => (
          <NavLink
            key={item.id}
            to={item.route}
            className={({ isActive }) =>
              `flex flex-col items-center justify-center w-1/5 h-full transition-all duration-200 ${
                isActive ? 'text-[#C58937] font-bold scale-105' : 'text-slate-400 hover:text-slate-200 font-medium'
              }`
            }
          >
            {getIcon(item.icon)}
            <span className="text-[10px] mt-1 tracking-tight truncate w-full text-center px-0.5">
              {t(getLabelKey(item.id) as any)}
            </span>
          </NavLink>
        ))}
      </div>
    </nav>
  );
};
