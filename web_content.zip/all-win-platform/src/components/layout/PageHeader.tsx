import React, { ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

interface PageHeaderProps {
  title: string;
  onBack?: () => void;
  rightAction?: ReactNode;
}

export const PageHeader: React.FC<PageHeaderProps> = ({ title, onBack, rightAction }) => {
  const navigate = useNavigate();

  const handleBack = () => {
    if (onBack) {
      onBack();
    } else {
      navigate(-1);
    }
  };

  return (
    <header className="sticky top-0 z-30 bg-[#12213D] border-b border-[#243A66] px-4 py-3 shadow-md">
      <div className="flex items-center justify-between max-w-lg mx-auto">
        <button
          onClick={handleBack}
          className="p-1.5 rounded-lg bg-[#1A2C4E] border border-[#243A66] text-slate-300 hover:text-white transition-colors"
          aria-label="Back"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>

        <h1 className="text-base font-bold text-white tracking-wide truncate max-w-[200px] text-center">
          {title}
        </h1>

        <div className="w-8 flex items-center justify-end">
          {rightAction || <div className="w-8" />}
        </div>
      </div>
    </header>
  );
};
