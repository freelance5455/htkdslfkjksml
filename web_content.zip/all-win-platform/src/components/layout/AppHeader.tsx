import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Bell, Menu as MenuIcon, Coins } from 'lucide-react';
import { usePlayStore } from '../../core/state/playStore.js';
import { fmtCredits } from '../../games/framework/session.js';
import { ROUTES } from '../../core/config/routes.js';
import { useI18n } from '../../context/I18nContext.js';

export const AppHeader: React.FC = () => {
  const navigate = useNavigate();
  const { language, setLanguage } = useI18n();
  const credits = usePlayStore((s) => s.credits);
  const unread = usePlayStore((s) => s.notices.some((n) => !n.read));

  return (
    <header className="sticky top-0 z-30 bg-[#12213D] border-b border-[#243A66] px-4 py-3 shadow-lg">
      <div className="flex items-center justify-between max-w-lg mx-auto">
        <Link to={ROUTES.HOME} className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg gold-gradient-bg flex items-center justify-center font-black text-white shadow-md text-sm">
            AW
          </div>
          <span className="font-extrabold text-lg tracking-wider text-white">ALL WIN</span>
        </Link>

        <div className="flex items-center gap-2">
          <button
            onClick={() => navigate(ROUTES.WALLET)}
            aria-label="Play credits"
            className="h-9 px-2.5 text-xs font-extrabold rounded-lg bg-[#1A2C4E] border border-[#243A66] text-[#01A879] flex items-center gap-1"
          >
            <Coins className="w-3.5 h-3.5 text-[#C58937]" /> {fmtCredits(Math.floor(credits))}
          </button>
          <button
            onClick={() => setLanguage(language === 'EN' ? 'BN' : 'EN')}
            aria-label="Switch language"
            className="h-9 px-2.5 text-xs font-bold rounded-lg bg-[#1A2C4E] border border-[#243A66] text-[#C58937] hover:bg-[#243A66] transition-all"
          >
            {language}
          </button>

          <button
            onClick={() => navigate('/menu/notifications')}
            aria-label="Notifications"
            className="relative w-9 h-9 flex items-center justify-center rounded-lg bg-[#1A2C4E] border border-[#243A66] text-slate-300 hover:text-white transition-colors"
          >
            <Bell className="w-4 h-4" />
            {unread && <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[#E92844]" />}
          </button>

          <button
            onClick={() => navigate(ROUTES.MENU)}
            aria-label="Menu"
            className="w-9 h-9 flex items-center justify-center rounded-lg bg-[#1A2C4E] border border-[#243A66] text-slate-300 hover:text-white transition-colors"
          >
            <MenuIcon className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
