import React, { ReactNode } from 'react';
import { useLocation } from 'react-router-dom';
import { AppHeader } from './AppHeader.js';
import { BottomNavigation } from './BottomNavigation.js';
import { ROUTES } from '../../core/config/routes.js';

interface AppShellProps {
  children: ReactNode;
}

export const AppShell: React.FC<AppShellProps> = ({ children }) => {
  const location = useLocation();

  // Hide headers & bottom nav on full game viewport or auth screens if needed
  const isAuthScreen = [ROUTES.REGISTER, ROUTES.LOGIN, ROUTES.FORGOT_PASSWORD].includes(location.pathname as any);
  const isGameScreen = location.pathname.startsWith('/game/');

  return (
    <div className="min-h-screen bg-[#0B0E14] text-white flex flex-col justify-between">
      {!isAuthScreen && !isGameScreen && <AppHeader />}

      <main className={`flex-1 w-full max-w-lg mx-auto ${!isAuthScreen && !isGameScreen ? 'pb-20 p-4' : 'p-0'}`}>
        <div key={location.pathname} className="anim-fade-in">{children}</div>
      </main>

      {!isAuthScreen && !isGameScreen && <BottomNavigation />}
    </div>
  );
};
