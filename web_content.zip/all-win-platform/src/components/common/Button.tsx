import React, { ButtonHTMLAttributes } from 'react';

export type ButtonVariant = 'primary' | 'secondary' | 'neutral' | 'confirm' | 'destructive';

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  isLoading?: boolean;
  fullWidth?: boolean;
}

export const Button: React.FC<ButtonProps> = ({
  children,
  variant = 'primary',
  isLoading = false,
  fullWidth = false,
  disabled,
  className = '',
  ...props
}) => {
  let baseStyles = 'inline-flex items-center justify-center font-semibold rounded-xl px-5 py-3 text-sm transition-all duration-200 active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed disabled:active:scale-100 shadow-md';

  if (fullWidth) baseStyles += ' w-full';

  let variantStyles = '';
  switch (variant) {
    case 'primary':
      variantStyles = 'bg-gradient-to-r from-[#C58937] to-[#E2A85C] text-white hover:brightness-110 shadow-[#C58937]/20';
      break;
    case 'confirm':
      variantStyles = 'bg-white text-[#01A879] hover:bg-slate-100 border border-[#01A879]/30';
      break;
    case 'destructive':
      variantStyles = 'bg-white text-[#E92844] hover:bg-slate-100 border border-[#E92844]/30';
      break;
    case 'neutral':
      variantStyles = 'bg-white text-slate-900 hover:bg-slate-100 border border-slate-200';
      break;
    case 'secondary':
    default:
      variantStyles = 'bg-[#1A2C4E] text-white border border-[#243A66] hover:bg-[#243A66]';
      break;
  }

  return (
    <button
      disabled={disabled || isLoading}
      className={`${baseStyles} ${variantStyles} ${className}`}
      {...props}
    >
      {isLoading ? (
        <span className="flex items-center gap-2">
          <svg className="animate-spin h-4 w-4 text-current" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
          Processing...
        </span>
      ) : (
        children
      )}
    </button>
  );
};
