import React from 'react';
import { CheckCircle2, Phone } from 'lucide-react';
import { validateBangladeshPhoneNumber } from '../../core/types/domains.js';

interface PhoneInputProps {
  value: string;
  onChange: (value: string) => void;
  label?: string;
}

export const PhoneInput: React.FC<PhoneInputProps> = ({ value, onChange, label }) => {
  const validation = validateBangladeshPhoneNumber(value);

  return (
    <div className="flex flex-col gap-1.5 text-left w-full">
      {label && <label className="text-xs font-medium text-slate-300 flex items-center gap-1.5"><Phone className="w-3.5 h-3.5 text-[#C58937]" /> {label}</label>}
      <div className="relative flex items-center">
        <div className="flex items-center gap-1 bg-[#1A2C4E] border border-[#243A66] rounded-l-xl px-3 py-3 text-sm font-semibold text-slate-200 border-r-0">
          <span className="text-base">🇧🇩</span>
          <span>+880</span>
        </div>
        <input
          type="tel"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder="Please enter phone number"
          className={`w-full bg-[#12213D] border ${validation.isValid ? 'border-[#01A879]' : value ? 'border-[#E92844]' : 'border-[#243A66]'} rounded-r-xl px-3 py-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-[#C58937] transition-all pr-10`}
        />
        {validation.isValid && (
          <CheckCircle2 className="absolute right-3 w-5 h-5 text-[#01A879]" />
        )}
      </div>
      {value && !validation.isValid && (
        <p className="text-xs text-[#E92844] font-medium">{validation.errorMessage}</p>
      )}
    </div>
  );
};
