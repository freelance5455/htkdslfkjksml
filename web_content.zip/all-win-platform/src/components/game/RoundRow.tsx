import React from 'react';
import { useNavigate } from 'react-router-dom';
import type { RoundRecord } from '../../core/state/playStore.js';
import { getGame } from '../../games/registry.js';
import { fmtCredits } from '../../games/framework/session.js';

export const timeAgo = (ts: number) => {
  const s = Math.floor((Date.now() - ts) / 1000);
  if (s < 60) return 'just now';
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  return new Date(ts).toLocaleDateString();
};

/** One row of round history (game, detail, stake → payout). */
export const RoundRow: React.FC<{ r: RoundRecord }> = ({ r }) => {
  const navigate = useNavigate();
  const g = getGame(r.slug);
  const Thumb = g?.Thumbnail;
  const net = r.payout - r.stake;
  return (
    <button onClick={() => navigate(`/game/${r.slug}`)} className="w-full p-3 flex items-center gap-3 text-left hover:bg-[#1A2C4E] transition-colors">
      <div className="w-10 h-10 rounded-xl bg-[#1A2C4E] flex items-center justify-center shrink-0">{Thumb && <Thumb className="w-8 h-8" />}</div>
      <div className="flex-1 min-w-0">
        <p className="text-xs font-bold text-white truncate">{r.gameName}</p>
        <p className="text-[10px] text-slate-400 truncate">{r.detail}</p>
        <p className="text-[9px] text-slate-500">{timeAgo(r.ts)} · stake {fmtCredits(r.stake)}</p>
      </div>
      <div className="text-right shrink-0">
        <p className={`text-xs font-extrabold ${net > 0 ? 'text-[#01A879]' : net < 0 ? 'text-[#E92844]' : 'text-[#C58937]'}`}>{net > 0 ? '+' : ''}{fmtCredits(net)}</p>
        <p className="text-[9px] text-slate-500">{r.multiplier.toFixed(2)}×</p>
      </div>
    </button>
  );
};
