import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Heart, Play } from 'lucide-react';
import type { GameModuleEntry } from '../../games/framework/types.js';
import { playStore, usePlayStore } from '../../core/state/playStore.js';

/** Lobby card used on Home, Lobby and Favourites. Opens the game's detail/launch screen. */
export const GameCard: React.FC<{ game: GameModuleEntry }> = ({ game }) => {
  const navigate = useNavigate();
  const fav = usePlayStore((s) => s.favorites.includes(game.config.slug));
  const { config, Thumbnail } = game;
  return (
    <div
      role="link"
      tabIndex={0}
      aria-label={`Open ${config.name}`}
      onClick={() => navigate(`/game/${config.slug}`)}
      onKeyDown={(e) => e.key === 'Enter' && navigate(`/game/${config.slug}`)}
      className="group relative bg-[#12213D] border border-[#243A66] rounded-2xl p-3 flex flex-col justify-between h-44 cursor-pointer hover:border-[#C58937] transition-colors duration-200 shadow-lg overflow-hidden anim-slide-up"
    >
      <div className="absolute inset-0 opacity-25 group-hover:opacity-35 transition-opacity" style={{ background: `linear-gradient(135deg, ${config.accent} 0%, #12213D 70%)` }} />
      <div className="relative z-10 flex items-center justify-between">
        <span className="text-[9px] font-black px-2 py-0.5 rounded-md bg-[#1A2C4E] border border-[#243A66] text-[#C58937] uppercase truncate max-w-[75%]">{config.badge}</span>
        <button
          aria-label={fav ? 'Remove from favourites' : 'Add to favourites'}
          onClick={(e) => { e.stopPropagation(); playStore.toggleFavorite(config.slug); }}
          className="w-8 h-8 -m-1.5 flex items-center justify-center"
        >
          <Heart className={`w-4 h-4 transition-colors ${fav ? 'fill-[#E92844] text-[#E92844]' : 'text-slate-400'}`} />
        </button>
      </div>
      <div className="relative z-10 flex-1 flex items-center justify-center">
        <Thumbnail className="w-20 h-20 drop-shadow-lg transition-transform duration-300 group-hover:rotate-3" />
      </div>
      <div className="relative z-10 flex items-center justify-between pt-2 border-t border-[#243A66]/50">
        <div className="min-w-0">
          <p className="text-xs font-bold text-white truncate">{config.name}</p>
          <p className="text-[9px] text-slate-400">{config.category}</p>
        </div>
        <span className="p-1.5 rounded-lg gold-gradient-bg text-white shadow-md"><Play className="w-3 h-3 fill-current" /></span>
      </div>
    </div>
  );
};

export const EmptyState: React.FC<{ icon: React.ReactNode; title: string; body?: string; action?: React.ReactNode }> = ({ icon, title, body, action }) => (
  <div className="bg-[#12213D] border border-dashed border-[#243A66] rounded-2xl p-8 text-center flex flex-col items-center gap-2 anim-fade-in">
    <div className="w-12 h-12 rounded-full bg-[#1A2C4E] flex items-center justify-center text-[#C58937]">{icon}</div>
    <p className="text-sm font-bold text-white">{title}</p>
    {body && <p className="text-xs text-slate-400 max-w-[260px]">{body}</p>}
    {action}
  </div>
);
