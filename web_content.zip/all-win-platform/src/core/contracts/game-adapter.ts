import type { GameSession, GameRound, GameResultEnvelope } from '../types/game-runtime.js';

export interface GameAdapterContract<
  TState = unknown,
  TAction = unknown,
  TOutcome = unknown
> {
  initialize(config: Record<string, unknown>): Promise<void>;
  load(viewportElementId: string): Promise<void>;
  startSession(userId: string, gameId: string): Promise<GameSession>;
  getState(): TState;
  submitAction(action: TAction): Promise<GameRound>;
  getResult(roundId: string): Promise<GameResultEnvelope<TOutcome>>;
  destroy(): Promise<void>;
}

export interface GameRuntimeContract {
  mountGame(gameId: string, adapter: GameAdapterContract): Promise<void>;
  unmountGame(): Promise<void>;
  getActiveSession(): GameSession | null;
  getActiveRound(): GameRound | null;
  requestExitSession(): Promise<boolean>;
}
