import type {
  DualBalance,
  DepositRequest,
  DepositResult,
  WithdrawRequest,
  WithdrawResult,
  WalletTransaction
} from '../types/wallet.js';

export interface WalletProviderContract {
  getBalance(userId: string): Promise<DualBalance>;
  processDeposit(request: DepositRequest): Promise<DepositResult>;
  processWithdraw(request: WithdrawRequest): Promise<WithdrawResult>;
  getTransactionHistory(
    userId: string,
    limit?: number,
    offset?: number
  ): Promise<WalletTransaction[]>;
}
