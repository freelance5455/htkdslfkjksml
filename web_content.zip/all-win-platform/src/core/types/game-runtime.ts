export type SessionStatus =
  | 'CREATED'
  | 'ACTIVE'
  | 'PAUSED'
  | 'COMPLETED'
  | 'CANCELLED'
  | 'EXPIRED';

export type SettlementStatus =
  | 'PENDING'
  | 'PROCESSING'
  | 'SETTLED'
  | 'FAILED'
  | 'REJECTED'
  | 'CANCELLED';

export interface GameSession {
  sessionId: string;
  userId: string;
  gameId: string;
  status: SessionStatus;
  startedAt: Date;
  endedAt?: Date;
  metadata?: Record<string, unknown>;
}

export interface GameRound {
  roundId: string;
  gameSessionId: string;
  userId: string;
  gameId: string;
  stake: number;
  result?: GameResultEnvelope;
  settlementStatus: SettlementStatus;
  createdAt: Date;
  completedAt?: Date;
}

export interface GameResultEnvelope<TOutcome = unknown> {
  roundId: string;
  gameId: string;
  status: 'WIN' | 'LOSS' | 'PUSH' | 'CANCELLED';
  outcome: TOutcome;
  stake: number;
  payout: number;
  netResult: number;
  timestamp: Date;
}
