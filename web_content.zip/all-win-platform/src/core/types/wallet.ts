export type BalanceType = 'REAL' | 'BONUS';

export type TransactionType =
  | 'DEPOSIT'
  | 'WITHDRAWAL'
  | 'BET_STAKE'
  | 'BET_PAYOUT'
  | 'BONUS_REWARD'
  | 'REFUND'
  | 'COMMISSION'
  | 'REBATE'
  | 'ADJUSTMENT';

export type DepositCanonicalState =
  | 'CREATED'
  | 'PAYMENT_IN_PROGRESS'
  | 'SUBMITTED'
  | 'VERIFICATION_PENDING'
  | 'PROCESSING'
  | 'COMPLETED'
  | 'FAILED'
  | 'REJECTED'
  | 'CANCELLED'
  | 'EXPIRED';

export type WithdrawCanonicalState =
  | 'CREATED'
  | 'SUBMITTED'
  | 'UNDER_REVIEW'
  | 'PROCESSING'
  | 'SENT_TO_PROVIDER'
  | 'COMPLETED'
  | 'FAILED'
  | 'REJECTED'
  | 'CANCELLED'
  | 'RETURNED';

export type StandardPaymentMethod = 'BKASH' | 'NAGAD' | 'ROCKET' | 'BANK_TRANSFER';

export type PaymentChannel = 'CASH_OUT' | 'SEND_MONEY';

export const DEPOSIT_LIMITS = {
  minAmount: 100, // ৳100
  maxAmount: 100000, // ৳100,000
  currency: 'BDT',
} as const;

export const WITHDRAWAL_LIMITS = {
  maxRequestsPerDay: 3,
  maxAmountPerRequest: 50000, // ৳50,000
  minAmountPerRequest: 'CONFIGURABLE / REQUIRES PRODUCT DECISION' as const,
  estimatedProcessingTime: 'up to 3–4 hours',
} as const;

export interface DualBalance {
  totalBalance: number;
  realBalance: number;
  bonusBalance: number;
  withdrawableBalance: number;
  currency: string;
  updatedAt: Date;
}

export interface WalletTransaction {
  transactionId: string;
  userId: string;
  type: TransactionType;
  method: StandardPaymentMethod | string;
  channel?: PaymentChannel;
  amount: number;
  balanceType: BalanceType;
  status: DepositCanonicalState | WithdrawCanonicalState;
  reference: string;
  createdAt: Date;
  updatedAt: Date;
  failureReason?: string;
  metadata?: Record<string, unknown>;
}

export interface DepositRequest {
  userId: string;
  method: StandardPaymentMethod;
  channel: PaymentChannel;
  amount: number;
  operatorNumber: string;
  transactionId: string; // TrxID
}

export interface DepositResult {
  transactionId: string;
  status: DepositCanonicalState;
  estimatedSettlement: string;
}

export interface WithdrawRequest {
  userId: string;
  method: StandardPaymentMethod;
  destinationAccount: string;
  amount: number;
  balanceType: BalanceType;
  saveAccountForFuture: boolean;
}

export interface WithdrawResult {
  transactionId: string;
  status: WithdrawCanonicalState;
  feeAmount: number;
  netPayoutAmount: number;
  dailyRequestsRemaining: number;
}
