export interface PhoneValidationResult {
  countryCode: string; // '+880'
  rawLocalInput: string;
  isValid: boolean;
  errorMessage?: string;
}

export function validateBangladeshPhoneNumber(localNumber: string): PhoneValidationResult {
  const digitsOnly = localNumber.replace(/\D/g, '');
  if (digitsOnly.length === 0) {
    return {
      countryCode: '+880',
      rawLocalInput: localNumber,
      isValid: false,
      errorMessage: 'Phone number is required.',
    };
  }
  if (!digitsOnly.startsWith('01')) {
    return {
      countryCode: '+880',
      rawLocalInput: localNumber,
      isValid: false,
      errorMessage: 'Bangladesh phone number must start with 01.',
    };
  }
  if (digitsOnly.length !== 11) {
    return {
      countryCode: '+880',
      rawLocalInput: localNumber,
      isValid: false,
      errorMessage: 'Number is incomplete. Please enter a valid 11-digit phone number.',
    };
  }
  return {
    countryCode: '+880',
    rawLocalInput: digitsOnly,
    isValid: true,
  };
}

export interface UserProfile {
  userId: string;
  username: string;
  phone: string; // Bangladesh 11-digit local format: '01XXXXXXXXX'
  email?: string;
  preferredLanguage: 'EN' | 'BN';
  theme: 'DARK' | 'LIGHT';
  accountStatus: 'ACTIVE' | 'SUSPENDED' | 'VERIFICATION_REQUIRED';
  pinCreated: boolean;
  vipLevel: number;
  lastLoginAt: Date;
  securitySettings: {
    twoFactorEnabled: boolean;
    loginNotificationsEnabled: boolean;
    rememberPasswordEnabled: boolean;
  };
}

export interface ReferralOverview {
  userId: string;
  yesterdayCommission: number;
  currentLevel: string;
  upgradeLevel: string;
  directSubordinates: number;
  teamSubordinates: number;
  registrationCount: number;
  depositCount: number;
  totalDepositAmount: number;
  firstDepositMembers: number;
  invitationCode: string;
  invitationQrUrl: string;
  rebateRatio: number;
}

export interface ActivityRecord {
  activityId: string;
  userId: string;
  gameId: string;
  gameName: string;
  type: 'WIN' | 'LOSS' | 'PENDING';
  stake: number;
  netResult: number;
  timestamp: Date;
  sessionId?: string;
  activeSessionReturnRoute?: string;
}

export interface PromotionEntry {
  promotionId: string;
  title: string;
  category: 'FEATURED' | 'DEPOSIT_OFFERS' | 'GAME_PROMOTIONS' | 'VIP' | 'CHALLENGES' | 'REWARDS' | 'SPECIAL_EVENTS';
  bannerUrl: string;
  description: string;
  howItWorks: string;
  rewardDescription: string;
  status: 'AVAILABLE' | 'CLAIMED' | 'LOCKED' | 'EXPIRED' | 'NOT_ELIGIBLE';
  validityStart: Date;
  validityEnd: Date;
  termsAndConditions: string[];
}

export interface VIPStatus {
  userId: string;
  currentLevel: number;
  levelName: string;
  vipPoints: number;
  pointsToNextLevel: number;
  monthlyRewardClaimed: boolean;
  levelUpRewardClaimed: boolean;
  benefits: string[];
}

export interface AuditLogEntry {
  auditId: string;
  actorId: string;
  actorType: 'USER' | 'ADMIN' | 'SYSTEM';
  action: string;
  targetType: string;
  targetId: string;
  timestamp: Date;
  metadata?: Record<string, unknown>;
}
