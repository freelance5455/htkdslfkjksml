export type GameCategory =
  | 'ORIGINALS'
  | 'SLOTS'
  | 'CRASH'
  | 'TABLE_GAMES'
  | 'LOTTERY_NUMBER'
  | 'INSTANT_MINI'
  | 'ARCADE'
  | 'OTHER';

export type GameStatus =
  | 'ACTIVE'
  | 'DISABLED'
  | 'MAINTENANCE'
  | 'COMING_SOON';

export type GameProviderSource =
  | 'vfair-games'
  | 'Rush'
  | 'play-kit'
  | 'stake-originals-clone'
  | 'SlotGame'
  | 'Afterhand'
  | 'casino'
  | 'Bet'
  | 'INTERNAL_ALL_WIN';

export interface GameRegistryEntry {
  gameId: string;
  name: string;
  slug: string;
  category: GameCategory;
  subcategory?: string;
  thumbnail: string;
  banner?: string;
  icon?: string;
  route: string;
  providerSource: GameProviderSource;
  engine: string;
  adapter: string;
  status: GameStatus;
  isFeatured: boolean;
  isPopular: boolean;
  isNew: boolean;
  sortOrder: number;
  minStake: number;
  maxStake: number;
  rulesReference: string;
  soundConfig: {
    enabled: boolean;
    bgmUrl?: string;
    sfxUrls?: Record<string, string>;
  };
  animationConfig: {
    engine: 'css' | 'framer-motion' | 'phaser' | 'canvas';
    reducedMotionSupported: boolean;
  };
  orientation: 'PORTRAIT' | 'LANDSCAPE' | 'BOTH';
  isHistoryEnabled: boolean;
  isActivityEnabled: boolean;
}
