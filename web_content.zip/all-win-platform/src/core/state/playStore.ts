/**
 * Non-monetary play store.
 *
 * Holds PLAY CREDITS only. Credits have no cash value, cannot be bought,
 * deposited, withdrawn or exchanged. Persisted to localStorage so a player's
 * practice progress survives reloads on the same device.
 */
import { useSyncExternalStore } from 'react';

export const STARTING_CREDITS = 10_000;
const STORAGE_KEY = 'allwin_play_v1';
const MAX_HISTORY = 300;

export type Outcome = 'win' | 'lose' | 'push';

export interface RoundRecord {
  id: string;
  slug: string;
  gameName: string;
  stake: number;
  payout: number;
  multiplier: number;
  outcome: Outcome;
  detail: string;
  ts: number;
}

export interface LedgerEntry {
  id: string;
  kind: 'stake' | 'payout' | 'bonus' | 'reset';
  amount: number;
  label: string;
  ts: number;
}

export interface Notice {
  id: string;
  title: string;
  body: string;
  ts: number;
  read: boolean;
}

export interface PlayState {
  credits: number;
  history: RoundRecord[];
  ledger: LedgerEntry[];
  notices: Notice[];
  profile: { nickname: string; avatar: number; joined: number };
  favorites: string[];
  lastDailyClaim: string | null;
  streak: number;
  claimedMissions: string[];
  redeemedCodes: string[];
}

const uid = () => Math.random().toString(36).slice(2, 10);

const initialState = (): PlayState => ({
  credits: STARTING_CREDITS,
  history: [],
  ledger: [{ id: uid(), kind: 'bonus', amount: STARTING_CREDITS, label: 'Welcome play credits', ts: Date.now() }],
  notices: [
    {
      id: uid(),
      title: 'Welcome to ALL WIN',
      body: 'You have 10,000 free play credits. Credits are for fun only and have no cash value.',
      ts: Date.now(),
      read: false,
    },
  ],
  profile: { nickname: 'Player_' + Math.floor(100000 + Math.random() * 899999), avatar: 0, joined: Date.now() },
  favorites: [],
  lastDailyClaim: null,
  streak: 0,
  claimedMissions: [],
  redeemedCodes: [],
});

const load = (): PlayState => {
  try {
    const raw = typeof localStorage !== 'undefined' ? localStorage.getItem(STORAGE_KEY) : null;
    if (raw) return { ...initialState(), ...JSON.parse(raw) };
  } catch {
    /* corrupted storage – start fresh */
  }
  return initialState();
};

let state: PlayState = load();
const listeners = new Set<() => void>();

const commit = (next: PlayState) => {
  state = next;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    /* storage full / private mode */
  }
  listeners.forEach((l) => l());
};

const ledger = (kind: LedgerEntry['kind'], amount: number, label: string): LedgerEntry => ({
  id: uid(),
  kind,
  amount,
  label,
  ts: Date.now(),
});

const notice = (title: string, body: string): Notice => ({ id: uid(), title, body, ts: Date.now(), read: false });

export const playStore = {
  get: () => state,
  subscribe(l: () => void) {
    listeners.add(l);
    return () => listeners.delete(l);
  },
  /** Deducts a stake. Returns false when there are not enough credits. */
  debit(amount: number, label: string): boolean {
    if (amount <= 0 || amount > state.credits) return false;
    commit({
      ...state,
      credits: round2(state.credits - amount),
      ledger: [ledger('stake', -amount, label), ...state.ledger].slice(0, MAX_HISTORY),
    });
    return true;
  },
  credit(amount: number, label: string, kind: LedgerEntry['kind'] = 'payout') {
    if (amount <= 0) return;
    commit({
      ...state,
      credits: round2(state.credits + amount),
      ledger: [ledger(kind, amount, label), ...state.ledger].slice(0, MAX_HISTORY),
    });
  },
  addRound(r: Omit<RoundRecord, 'id' | 'ts'>) {
    const rec: RoundRecord = { ...r, id: uid(), ts: Date.now() };
    const notices =
      r.outcome === 'win' && r.multiplier >= 10
        ? [notice(`Big win on ${r.gameName}!`, `You hit ${r.multiplier.toFixed(2)}× for ${fmt(r.payout)} play credits.`), ...state.notices]
        : state.notices;
    commit({ ...state, history: [rec, ...state.history].slice(0, MAX_HISTORY), notices: notices.slice(0, 50) });
  },
  resetCredits() {
    commit({
      ...state,
      credits: STARTING_CREDITS,
      ledger: [ledger('reset', STARTING_CREDITS, 'Practice credits reset'), ...state.ledger].slice(0, MAX_HISTORY),
    });
  },
  clearHistory() {
    commit({ ...state, history: [], ledger: [] });
  },
  toggleFavorite(slug: string) {
    const has = state.favorites.includes(slug);
    commit({ ...state, favorites: has ? state.favorites.filter((s) => s !== slug) : [...state.favorites, slug] });
  },
  updateProfile(p: Partial<PlayState['profile']>) {
    commit({ ...state, profile: { ...state.profile, ...p } });
  },
  claimDaily(): number {
    const today = dayKey(Date.now());
    if (state.lastDailyClaim === today) return 0;
    const yesterday = dayKey(Date.now() - 86_400_000);
    const streak = state.lastDailyClaim === yesterday ? (state.streak % 7) + 1 : 1;
    const amount = streak * 100;
    commit({
      ...state,
      lastDailyClaim: today,
      streak,
      credits: state.credits + amount,
      ledger: [ledger('bonus', amount, `Daily check-in day ${streak}`), ...state.ledger].slice(0, MAX_HISTORY),
    });
    return amount;
  },
  claimMission(id: string, reward: number, title: string) {
    if (state.claimedMissions.includes(id)) return;
    commit({
      ...state,
      claimedMissions: [...state.claimedMissions, id],
      credits: state.credits + reward,
      ledger: [ledger('bonus', reward, `Mission: ${title}`), ...state.ledger].slice(0, MAX_HISTORY),
      notices: [notice('Mission complete', `${title} — +${fmt(reward)} play credits`), ...state.notices].slice(0, 50),
    });
  },
  redeemCode(code: string): { ok: boolean; message: string } {
    const c = code.trim().toUpperCase();
    const codes: Record<string, number> = { WELCOME: 1000, LUCKY7: 777, ALLWIN: 500 };
    if (!c) return { ok: false, message: 'Please enter a code.' };
    if (!(c in codes)) return { ok: false, message: 'That code is not valid.' };
    if (state.redeemedCodes.includes(c)) return { ok: false, message: 'You already redeemed this code.' };
    commit({
      ...state,
      redeemedCodes: [...state.redeemedCodes, c],
      credits: state.credits + codes[c],
      ledger: [ledger('bonus', codes[c], `Gift code ${c}`), ...state.ledger].slice(0, MAX_HISTORY),
    });
    return { ok: true, message: `+${fmt(codes[c])} play credits added.` };
  },
  markNoticesRead() {
    commit({ ...state, notices: state.notices.map((n) => ({ ...n, read: true })) });
  },
};

export function usePlayStore<T>(selector: (s: PlayState) => T): T {
  return useSyncExternalStore(playStore.subscribe, () => selector(state), () => selector(state));
}

export const dayKey = (ts: number) => new Date(ts).toISOString().slice(0, 10);
export const round2 = (n: number) => Math.round(n * 100) / 100;
const fmt = (n: number) => n.toLocaleString('en-US', { maximumFractionDigits: 2 });

export interface PlayStats {
  rounds: number;
  wins: number;
  winRate: number;
  staked: number;
  returned: number;
  net: number;
  bestMultiplier: number;
  gamesPlayed: number;
  bySlug: Record<string, { rounds: number; wins: number; net: number; best: number }>;
}

export const computeStats = (history: RoundRecord[]): PlayStats => {
  const bySlug: PlayStats['bySlug'] = {};
  let wins = 0, staked = 0, returned = 0, best = 0;
  for (const r of history) {
    const s = (bySlug[r.slug] ||= { rounds: 0, wins: 0, net: 0, best: 0 });
    s.rounds++;
    s.net += r.payout - r.stake;
    if (r.outcome === 'win') {
      wins++;
      s.wins++;
      s.best = Math.max(s.best, r.multiplier);
      best = Math.max(best, r.multiplier);
    }
    staked += r.stake;
    returned += r.payout;
  }
  return {
    rounds: history.length,
    wins,
    winRate: history.length ? (wins / history.length) * 100 : 0,
    staked,
    returned,
    net: returned - staked,
    bestMultiplier: best,
    gamesPlayed: Object.keys(bySlug).length,
    bySlug,
  };
};
