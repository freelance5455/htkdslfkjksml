export type ErrorCode =
  | 'VALIDATION_ERROR'
  | 'AUTH_ERROR'
  | 'PERMISSION_ERROR'
  | 'NOT_FOUND'
  | 'CONFLICT'
  | 'NETWORK_ERROR'
  | 'TRANSACTION_ERROR'
  | 'GAME_ERROR'
  | 'SESSION_ERROR'
  | 'SYSTEM_ERROR';

export class ALLWINError extends Error {
  constructor(
    public readonly code: ErrorCode,
    message: string,
    public readonly userMessage: string,
    public readonly details?: Record<string, unknown>
  ) {
    super(message);
    this.name = 'ALLWINError';
  }
}
