export const ROUTES = {
  HOME: '/',
  REGISTER: '/register',
  LOGIN: '/login',
  FORGOT_PASSWORD: '/forgot-password',
  CUSTOMER_SERVICE: '/customer-service',
  CATALOG: '/catalog',
  CATALOG_CATEGORY: '/catalog/:category',
  GAME_VIEW: '/game/:slug',
  GAME_PLAY: '/game/:slug/play',
  ACTIVITY: '/activity',
  PROMOTION: '/promotion',
  WALLET: '/wallet',
  WALLET_DEPOSIT: '/wallet/deposit',
  WALLET_WITHDRAW: '/wallet/withdraw',
  WALLET_HISTORY: '/wallet/history',
  GAME_HISTORY: '/history',
  VIP: '/vip',
  PROFILE: '/profile',
  MENU: '/menu',
  ADMIN: '/admin',
} as const;

export const LOCKED_BOTTOM_NAV = [
  { id: 'HOME', label: 'Home', route: ROUTES.HOME, icon: 'home' },
  { id: 'ACTIVITY', label: 'Activity', route: ROUTES.ACTIVITY, icon: 'activity' },
  { id: 'PROMOTION', label: 'Promotion', route: ROUTES.PROMOTION, icon: 'promotion' },
  { id: 'WALLET', label: 'Wallet', route: ROUTES.WALLET, icon: 'wallet' },
  { id: 'MENU', label: 'Menu', route: ROUTES.MENU, icon: 'menu' },
] as const;

export interface GlobalNavigationPolicy {
  confirmGameExitOnActiveSession: boolean;
  respectModalHistory: boolean;
  lockBottomNav: boolean;
  fiveItemEqualBottomNav: boolean;
}

export const DEFAULT_NAV_POLICY: GlobalNavigationPolicy = {
  confirmGameExitOnActiveSession: true,
  respectModalHistory: true,
  lockBottomNav: true,
  fiveItemEqualBottomNav: true,
};
