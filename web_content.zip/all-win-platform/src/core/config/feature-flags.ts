export interface FeatureFlags {
  gamesEnabled: boolean;
  walletDepositEnabled: boolean;
  walletWithdrawEnabled: boolean;
  promotionsEnabled: boolean;
  vipEnabled: boolean;
  activityEnabled: boolean;
  gameHistoryEnabled: boolean;
  adminEnabled: boolean;
  dualBalanceEnabled: boolean;
}

export const DEFAULT_FEATURE_FLAGS: FeatureFlags = {
  gamesEnabled: true,
  walletDepositEnabled: true,
  walletWithdrawEnabled: true,
  promotionsEnabled: true,
  vipEnabled: true,
  activityEnabled: true,
  gameHistoryEnabled: true,
  adminEnabled: true,
  dualBalanceEnabled: true,
};
