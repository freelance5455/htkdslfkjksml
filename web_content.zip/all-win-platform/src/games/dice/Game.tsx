import React, { useState } from 'react';
import {
  GameShell, GameStage, StakeControl, ActionButton, Segmented, EffectsLayer,
  useScheduler, usePhaseMachine, useGameSession, useGameSound, useParticleLayer, fmtCredits,
} from '../framework/index.js';
import { config, ROLL_MS } from './config.js';
import { TRANSITIONS, Phase, RollRecord } from './gameState.js';
import { Mode, multiplier, winChance, rollValue, isWin } from './gameLogic.js';
import { SOUNDS } from './sounds/index.js';
import { animateRoll } from './animations/index.js';
import { winBurst } from './effects/index.js';

export default function DiceGame() {
  const session = useGameSession(config);
  const sched = useScheduler();
  const sound = useGameSound(SOUNDS);
  const fsm = usePhaseMachine<Phase>('IDLE', TRANSITIONS);
  const { canvasRef, burst } = useParticleLayer(sched);

  const [stake, setStake] = useState(config.defaultStake);
  const [target, setTarget] = useState(50);
  const [mode, setMode] = useState<Mode>('under');
  const [display, setDisplay] = useState<number | null>(null);
  const [marker, setMarker] = useState(50);
  const [cube, setCube] = useState(0);
  const [last, setLast] = useState<{ win: boolean; payout: number } | null>(null);
  const [rolls, setRolls] = useState<RollRecord[]>([]);

  const mult = multiplier(target, mode);
  const chance = winChance(target, mode);

  const roll = async () => {
    sound.unlock();
    if (fsm.is('ROLLING')) return;
    const r = session.beginRound(stake);
    if (!r) return;
    fsm.go('ROLLING');
    setLast(null);
    const value = rollValue();
    await animateRoll(sched, value, (d, m, a) => { setDisplay(d); setMarker(m); setCube(a); }, () => sound.play('rattle'), ROLL_MS);
    const win = isWin(value, target, mode);
    const payout = win ? Math.floor(stake * mult * 100) / 100 : 0;
    session.settleRound(r, payout, `Rolled ${value.toFixed(2)} (${mode} ${target})`);
    setLast({ win, payout });
    setRolls((x) => [{ value, win }, ...x].slice(0, 10));
    sound.play(win ? 'win' : 'lose');
    if (win) winBurst(burst, value);
    fsm.go('RESULT');
  };

  const rolling = fsm.phase === 'ROLLING';
  const winZone = mode === 'under' ? { left: 0, width: target } : { left: target, width: 100 - target };

  return (
    <GameShell
      config={config}
      credits={session.credits}
      busy={rolling}
      status={rolling ? 'Rolling…' : last ? (last.win ? 'Win' : 'Loss') : 'Ready'}
      stage={
        <GameStage accent={config.accent}>
          <EffectsLayer ref={canvasRef} />
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-6 px-5">
            <div className="flex gap-1.5 self-stretch justify-center min-h-[24px]">
              {rolls.map((r, i) => (
                <span key={i} className={`px-2 py-0.5 rounded text-[10px] font-black anim-pop ${r.win ? 'bg-[#01A879]/20 text-[#01A879]' : 'bg-[#E92844]/20 text-[#E92844]'}`}>{r.value.toFixed(0)}</span>
              ))}
            </div>
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-xl bg-white flex items-center justify-center shadow-xl" style={{ transform: `rotate(${cube}deg)` }}>
                <div className="grid grid-cols-3 gap-1">
                  {[1, 0, 1, 0, 1, 0, 1, 0, 1].map((d, i) => <span key={i} className={`w-2 h-2 rounded-full ${d ? 'bg-[#12213D]' : ''}`} />)}
                </div>
              </div>
              <div
                data-testid="dice-value"
                className={`text-6xl font-black tabular ${last ? (last.win ? 'text-[#01A879]' : 'text-[#E92844]') : 'text-white'} ${last ? 'anim-pop' : ''}`}
                key={last ? 'r' + rolls.length : 'd'}
              >
                {display === null ? '--.--' : display.toFixed(2)}
              </div>
            </div>
            {last && (
              <p className={`text-sm font-black anim-slide-up ${last.win ? 'text-[#01A879]' : 'text-[#E92844]'}`} data-testid="result">
                {last.win ? `You won ${fmtCredits(last.payout)} credits!` : 'No luck — try again'}
              </p>
            )}
            {/* Track */}
            <div className="w-full">
              <div className="relative h-4 rounded-full bg-[#E92844]/70 overflow-visible">
                <div className="absolute h-full rounded-full bg-[#01A879]" style={{ left: `${winZone.left}%`, width: `${winZone.width}%` }} />
                <div className="absolute -top-2 w-1 h-8 bg-white rounded" style={{ left: `calc(${target}% - 2px)` }} />
                <div className="absolute -top-9 -translate-x-1/2 transition-none" style={{ left: `${marker}%` }}>
                  <div className={`px-2 py-1 rounded-md text-[10px] font-black shadow ${last ? (last.win ? 'bg-[#01A879]' : 'bg-[#E92844]') : 'bg-[#C58937]'}`}>
                    {display === null ? '?' : display.toFixed(0)}
                  </div>
                </div>
              </div>
              <input
                aria-label="Target"
                type="range" min={2} max={98} value={target} disabled={rolling}
                onChange={(e) => { setTarget(+e.target.value); sound.play('slide'); }}
                className="w-full mt-3 accent-[#C58937] h-8"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-bold"><span>0</span><span>25</span><span>50</span><span>75</span><span>100</span></div>
            </div>
          </div>
        </GameStage>
      }
      controls={
        <>
          <div className="grid grid-cols-3 gap-2 text-center">
            {[['Target', `${mode === 'under' ? '<' : '>'} ${target}`], ['Win chance', `${chance}%`], ['Multiplier', `${mult.toFixed(4)}×`]].map(([k, v]) => (
              <div key={k} className="bg-[#1A2C4E] border border-[#243A66] rounded-xl py-2">
                <p className="text-[9px] uppercase font-bold text-slate-400">{k}</p>
                <p className="text-xs font-black">{v}</p>
              </div>
            ))}
          </div>
          <Segmented options={[{ value: 'under', label: 'Roll Under' }, { value: 'over', label: 'Roll Over' }]} value={mode} onChange={setMode} disabled={rolling} />
          <StakeControl value={stake} onChange={setStake} min={config.minStake} max={config.maxStake} credits={session.credits} disabled={rolling} />
          <ActionButton onClick={roll} disabled={rolling || stake > session.credits}>
            {rolling ? 'Rolling…' : stake > session.credits ? 'Not enough credits' : last ? `Roll again · ${fmtCredits(stake)}` : `Roll · ${fmtCredits(stake)}`}
          </ActionButton>
        </>
      }
    />
  );
}
