import React from 'react';

export const Thumbnail: React.FC<{ className?: string }> = ({ className }) => (
  <svg viewBox="0 0 96 96" className={className} aria-hidden>
    <g transform="rotate(-12 40 46)">
      <rect x="18" y="24" width="44" height="44" rx="10" fill="#fff" />
      <circle cx="30" cy="36" r="4" fill="#12213D" /><circle cx="50" cy="56" r="4" fill="#12213D" /><circle cx="40" cy="46" r="4" fill="#C58937" />
    </g>
    <g transform="rotate(14 66 62)">
      <rect x="52" y="48" width="30" height="30" rx="7" fill="#C58937" />
      <circle cx="60" cy="56" r="3" fill="#fff" /><circle cx="74" cy="70" r="3" fill="#fff" />
    </g>
  </svg>
);
