import type { GameConfig } from '../framework/types.js';

export const config: GameConfig = {
  slug: 'dice',
  name: 'Dice',
  category: 'Originals',
  badge: 'HOT',
  tagline: 'Set your odds, roll 0–100.',
  description: 'Pick a target and choose to roll over or under it. Lower odds pay a bigger multiplier. The roll is animated live on the track.',
  howToPlay: [
    'Drag the slider to set your target number.',
    'Toggle Roll Over / Roll Under.',
    'Pick a stake and tap Roll.',
    'If the result lands on your side of the target you win stake × multiplier.',
  ],
  rtp: '99%',
  accent: '#C58937',
  minStake: 10,
  maxStake: 5000,
  defaultStake: 100,
};

export const EDGE = 0.01;
export const ROLL_MS = 900;
