import type { SoundBank } from '../../framework/sound.js';

export const SOUNDS: SoundBank = {
  rattle: [{ wave: 'noise', freq: 2500, dur: 45, gain: 0.12 }],
  win: [
    { wave: 'triangle', freq: 660, dur: 100, gain: 0.22 },
    { wave: 'triangle', freq: 990, dur: 220, at: 90, gain: 0.22 },
  ],
  lose: [{ wave: 'sawtooth', freq: 220, to: 110, dur: 280, gain: 0.12 }],
  slide: [{ wave: 'sine', freq: 500, dur: 25, gain: 0.05 }],
};
