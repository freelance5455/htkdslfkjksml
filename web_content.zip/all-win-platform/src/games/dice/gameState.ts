import type { Transitions } from '../framework/stateMachine.js';

/** IDLE → ROLLING → RESULT → (ROLLING | IDLE) */
export type Phase = 'IDLE' | 'ROLLING' | 'RESULT';
export const TRANSITIONS: Transitions<Phase> = {
  IDLE: ['ROLLING'],
  ROLLING: ['RESULT'],
  RESULT: ['ROLLING', 'IDLE'],
};

export interface RollRecord {
  value: number;
  win: boolean;
}
