import type { Scheduler } from '../../framework/scheduler.js';
import { easeOutQuart } from '../../framework/animation.js';
import { rollValue } from '../gameLogic.js';

/**
 * Roll animation: the readout tumbles through random values while the marker
 * glides along the track and decelerates onto the final value.
 */
export async function animateRoll(
  s: Scheduler,
  final: number,
  onFrame: (display: number, markerPos: number, cubeAngle: number) => void,
  onRattle: () => void,
  ms: number
) {
  const startPos = 50;
  let lastRattle = 0;
  await s.tween(ms, (p) => {
    const tumbling = p < 0.97;
    const display = tumbling ? rollValue() : final;
    const pos = startPos + (final - startPos) * p + Math.sin(p * Math.PI * 3) * (1 - p) * 30;
    if (p - lastRattle > 0.08) {
      lastRattle = p;
      onRattle();
    }
    onFrame(display, Math.max(0, Math.min(100, pos)), p * 720);
  }, easeOutQuart);
  onFrame(final, final, 0);
}
