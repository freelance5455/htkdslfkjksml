type Burst = (o: { rx?: number; ry?: number; count?: number; colors?: string[]; speed?: number; shape?: 'circle' | 'square' | 'star' }) => void;

export const winBurst = (burst: Burst, markerPct: number) =>
  burst({ rx: markerPct / 100, ry: 0.62, count: 36, colors: ['#01A879', '#C58937', '#ffffff'], speed: 260, shape: 'star' });
