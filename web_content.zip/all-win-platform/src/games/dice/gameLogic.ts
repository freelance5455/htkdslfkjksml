import { rng } from '../framework/session.js';
import { EDGE } from './config.js';

export type Mode = 'over' | 'under';

export const winChance = (target: number, mode: Mode) => (mode === 'under' ? target : 100 - target);
export const multiplier = (target: number, mode: Mode) => Math.floor(((100 * (1 - EDGE)) / winChance(target, mode)) * 10000) / 10000;
export const rollValue = () => Math.floor(rng.float() * 10001) / 100; // 0.00 – 100.00
export const isWin = (roll: number, target: number, mode: Mode) => (mode === 'under' ? roll < target : roll > target);
