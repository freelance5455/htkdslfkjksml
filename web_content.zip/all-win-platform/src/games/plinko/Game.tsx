import React, { useEffect, useRef, useState } from 'react';
import {
  GameShell, GameStage, StakeControl, ActionButton, Segmented,
  useScheduler, usePhaseMachine, useGameSession, useGameSound, useCanvas, ParticleSystem, fmtCredits,
} from '../framework/index.js';
import { config, ROW_OPTIONS, Rows, Risk, ROW_MS } from './config.js';
import { TRANSITIONS, Phase, Ball, BinFlash } from './gameState.js';
import { payoutTable, rollPath, binOf, binColor } from './gameLogic.js';
import { SOUNDS } from './sounds/index.js';
import { layout, stepBall, drawBoard, drawBall, Board } from './animations/index.js';
import { binSplash } from './effects/index.js';

const MAX_BALLS = 10;

export default function PlinkoGame() {
  const session = useGameSession(config);
  const sched = useScheduler();
  const sound = useGameSound(SOUNDS);
  const fsm = usePhaseMachine<Phase>('IDLE', TRANSITIONS);
  const { canvasRef, size, ctx } = useCanvas();

  const [stake, setStake] = useState(config.defaultStake);
  const [rows, setRows] = useState<Rows>(12);
  const [risk, setRisk] = useState<Risk>('medium');
  const [inFlight, setInFlight] = useState(0);
  const [recent, setRecent] = useState<{ m: number; payout: number; key: number }[]>([]);

  const table = payoutTable(rows, risk);
  const tableRef = useRef(table);
  tableRef.current = table;
  const rowsRef = useRef(rows);
  rowsRef.current = rows;

  const balls = useRef<Ball[]>([]);
  const flashes = useRef<BinFlash[]>([]);
  const pegGlow = useRef(new Map<string, number>());
  const fx = useRef(new ParticleSystem());
  const nextId = useRef(1);
  const board = useRef<Board | null>(null);
  const lastPeg = useRef(0);

  const drop = () => {
    sound.unlock();
    if (balls.current.length >= MAX_BALLS) return;
    const r = session.beginRound(stake);
    if (!r) return;
    balls.current.push({ id: nextId.current++, path: rollPath(rows), row: 0, t: 0, round: r, x: 0, y: 0, done: false });
    setInFlight(balls.current.length);
    fsm.go('DROPPING');
    sound.play('drop');
  };

  const land = (ball: Ball) => {
    const bin = binOf(ball.path);
    const m = tableRef.current[bin];
    const payout = Math.floor(ball.round.stake * m * 100) / 100;
    session.settleRound(ball.round, payout, `Slot ${bin + 1}/${rowsRef.current + 1} · ${m}× (${rowsRef.current} rows)`);
    flashes.current.push({ bin, t: 0 });
    binSplash(fx.current, ball.x, ball.y, binColor(m), m >= 3);
    sound.play(m >= 3 ? 'high' : m >= 1 ? 'mid' : 'low');
    setRecent((x) => [{ m, payout, key: ball.id }, ...x].slice(0, 8));
  };

  useEffect(() => {
    return sched.loop((dt) => {
      const c = ctx();
      const { w, h } = size.current;
      if (!c || !w) return;
      const b = (board.current = layout(w, h, rowsRef.current));
      for (const ball of balls.current) {
        const landed = stepBall(ball, b, dt, ROW_MS, () => {
          const rights = ball.path.slice(0, ball.row).reduce((a, x) => a + x, 0);
          pegGlow.current.set(`${ball.row - 1}:${rights + 1 - ball.path[ball.row - 1]}`, 1);
          const now = performance.now();
          if (now - lastPeg.current > 40) { sound.play('peg'); lastPeg.current = now; }
        });
        if (landed && !ball.done) {
          ball.done = true;
          land(ball);
        }
      }
      if (balls.current.some((x) => x.done)) {
        balls.current = balls.current.filter((x) => !x.done);
        setInFlight(balls.current.length);
        if (!balls.current.length) fsm.go('IDLE');
      }
      pegGlow.current.forEach((v, k) => (v - dt * 3 <= 0 ? pegGlow.current.delete(k) : pegGlow.current.set(k, v - dt * 3)));
      flashes.current.forEach((f) => (f.t += dt * 3));
      flashes.current = flashes.current.filter((f) => f.t < 1);

      drawBoard(c, w, h, b, tableRef.current, flashes.current, pegGlow.current);
      for (const ball of balls.current) drawBall(c, ball, b);
      fx.current.update(dt);
      fx.current.draw(c);
    });
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const dropping = fsm.phase === 'DROPPING';

  return (
    <GameShell
      config={config}
      credits={session.credits}
      busy={dropping}
      status={dropping ? `${inFlight} ball${inFlight > 1 ? 's' : ''} in play` : 'Ready'}
      stage={
        <div className="flex flex-col gap-2 flex-1">
          <div className="flex gap-1.5 min-h-[26px] overflow-hidden" data-testid="result">
            {recent.length === 0 && <span className="text-[10px] text-slate-500 py-1">Drop a ball to start</span>}
            {recent.map((r) => (
              <span key={r.key} className="px-2 py-1 rounded-md text-[10px] font-black anim-pop text-white" style={{ background: binColor(r.m) }}>
                {r.m}× {r.payout > 0 ? `+${fmtCredits(r.payout)}` : ''}
              </span>
            ))}
          </div>
          <GameStage accent={config.accent}>
            <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" />
          </GameStage>
        </div>
      }
      controls={
        <>
          <div className="grid grid-cols-2 gap-2">
            <Segmented options={ROW_OPTIONS.map((r) => ({ value: r, label: `${r} rows` }))} value={rows} onChange={setRows} disabled={dropping} />
            <Segmented options={[{ value: 'low', label: 'Low' }, { value: 'medium', label: 'Med' }, { value: 'high', label: 'High' }]} value={risk} onChange={setRisk} disabled={dropping} />
          </div>
          <StakeControl value={stake} onChange={setStake} min={config.minStake} max={config.maxStake} credits={session.credits} />
          <ActionButton onClick={drop} disabled={stake > session.credits || inFlight >= MAX_BALLS}>
            {stake > session.credits ? 'Not enough credits' : `Drop ball · ${fmtCredits(stake)}`}
          </ActionButton>
        </>
      }
    />
  );
}
