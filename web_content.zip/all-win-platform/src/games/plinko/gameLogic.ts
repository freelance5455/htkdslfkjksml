import { rng } from '../framework/session.js';
import { RISK_CURVE, Risk, TARGET_RTP } from './config.js';

const binomial = (n: number) => {
  const p: number[] = [];
  let c = 1;
  for (let k = 0; k <= n; k++) {
    p.push(c / 2 ** n);
    c = (c * (n - k)) / (k + 1);
  }
  return p;
};

/** Original payout table: exponential edge weighting normalised to the target RTP. */
export const payoutTable = (rows: number, risk: Risk): number[] => {
  const probs = binomial(rows);
  const raw = probs.map((_, k) => {
    const d = Math.abs(k - rows / 2) / (rows / 2);
    return Math.exp(RISK_CURVE[risk] * d * d);
  });
  const ev = raw.reduce((s, r, k) => s + r * probs[k], 0);
  return raw.map((r) => {
    const m = (r / ev) * TARGET_RTP;
    return m >= 10 ? Math.round(m) : Math.max(0.2, Math.round(m * 10) / 10);
  });
};

/** A ball's path: one left(0)/right(1) decision per row. */
export const rollPath = (rows: number) => Array.from({ length: rows }, () => (rng.float() < 0.5 ? 0 : 1));
export const binOf = (path: number[]) => path.reduce((a, b) => a + b, 0);

export const binColor = (m: number) => (m >= 10 ? '#E92844' : m >= 3 ? '#F97316' : m >= 1 ? '#C58937' : '#3B82F6');
