import type { Transitions } from '../framework/stateMachine.js';
import type { RoundHandle } from '../framework/session.js';

/** IDLE ⇄ DROPPING (one or more balls in flight). */
export type Phase = 'IDLE' | 'DROPPING';
export const TRANSITIONS: Transitions<Phase> = { IDLE: ['DROPPING'], DROPPING: ['IDLE'] };

export interface Ball {
  id: number;
  path: number[];
  row: number; // current segment index
  t: number; // 0..1 within segment
  round: RoundHandle;
  x: number;
  y: number;
  done: boolean;
}

export interface BinFlash {
  bin: number;
  t: number;
}
