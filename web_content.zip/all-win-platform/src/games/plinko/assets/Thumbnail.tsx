import React from 'react';

export const Thumbnail: React.FC<{ className?: string }> = ({ className }) => (
  <svg viewBox="0 0 96 96" className={className} aria-hidden>
    {[0, 1, 2, 3].map((r) => Array.from({ length: r + 2 }, (_, i) => (
      <circle key={`${r}-${i}`} cx={48 + (i - (r + 1) / 2) * 16} cy={20 + r * 15} r="3" fill="#CBD5E1" />
    )))}
    <circle cx="56" cy="42" r="6" fill="#E2A85C" />
    {['#E92844', '#F97316', '#3B82F6', '#F97316', '#E92844'].map((c, i) => (
      <rect key={i} x={10 + i * 16} y="78" width="13" height="10" rx="3" fill={c} />
    ))}
  </svg>
);
