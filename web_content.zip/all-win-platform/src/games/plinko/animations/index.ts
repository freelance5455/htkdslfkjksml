import { binColor } from '../gameLogic.js';
import type { Ball, BinFlash } from '../gameState.js';

export interface Board {
  rows: number;
  sx: number;
  sy: number;
  top: number;
  cx: number;
  binY: number;
  pegR: number;
}

export const layout = (w: number, h: number, rows: number): Board => {
  const sx = Math.min((w - 16) / (rows + 2), 40);
  const top = 26;
  const binH = 30;
  const sy = Math.min((h - top - binH - 16) / rows, sx * 1.05);
  return { rows, sx, sy, top, cx: w / 2, binY: top + rows * sy + 6, pegR: Math.max(2, sx * 0.11) };
};

export const pegX = (b: Board, row: number, i: number) => b.cx + (i - (row + 2) / 2) * b.sx;
export const ballXAt = (b: Board, row: number, rights: number) => b.cx + (rights - row / 2) * b.sx;

/** Advances a ball along its path with a hop arc between peg rows. Returns true when it lands. */
export function stepBall(ball: Ball, b: Board, dt: number, rowMs: number, onPeg: () => void): boolean {
  ball.t += (dt * 1000) / rowMs;
  while (ball.t >= 1 && ball.row < b.rows) {
    ball.t -= 1;
    ball.row++;
    onPeg();
  }
  const rightsBefore = ball.path.slice(0, ball.row).reduce((a, c) => a + c, 0);
  if (ball.row >= b.rows) {
    ball.x = ballXAt(b, b.rows, rightsBefore);
    ball.y = b.binY + 8;
    return true;
  }
  const x0 = ballXAt(b, ball.row, rightsBefore);
  const x1 = ballXAt(b, ball.row + 1, rightsBefore + ball.path[ball.row]);
  const y0 = b.top + ball.row * b.sy - b.pegR * 2.5;
  const y1 = y0 + b.sy;
  const t = ball.t;
  ball.x = x0 + (x1 - x0) * t;
  ball.y = y0 + (y1 - y0) * t * t - Math.sin(t * Math.PI) * b.sy * 0.35;
  return false;
}

export function drawBoard(ctx: CanvasRenderingContext2D, w: number, h: number, b: Board, table: number[], flashes: BinFlash[], pegGlow: Map<string, number>) {
  ctx.clearRect(0, 0, w, h);
  for (let r = 0; r < b.rows; r++) {
    for (let i = 0; i < r + 3; i++) {
      const glow = pegGlow.get(`${r}:${i}`) ?? 0;
      ctx.fillStyle = glow > 0 ? `rgba(255,224,138,${0.4 + glow * 0.6})` : '#CBD5E1';
      ctx.beginPath();
      ctx.arc(pegX(b, r, i), b.top + r * b.sy, b.pegR * (1 + glow * 0.6), 0, Math.PI * 2);
      ctx.fill();
    }
  }
  const bw = b.sx - 3;
  table.forEach((m, k) => {
    const x = b.cx + (k - b.rows / 2) * b.sx;
    const f = flashes.find((fl) => fl.bin === k);
    const bump = f ? Math.sin(Math.min(1, f.t) * Math.PI) * 6 : 0;
    ctx.fillStyle = binColor(m);
    ctx.globalAlpha = f ? 1 : 0.85;
    ctx.beginPath();
    ctx.roundRect(x - bw / 2, b.binY + bump, bw, 24, 5);
    ctx.fill();
    ctx.globalAlpha = 1;
    ctx.fillStyle = '#fff';
    ctx.font = `900 ${b.rows > 12 ? 8 : 10}px Inter, sans-serif`;
    ctx.textAlign = 'center';
    ctx.fillText(m >= 100 ? `${m}` : `${m}×`, x, b.binY + bump + 15);
  });
  ctx.textAlign = 'left';
}

export function drawBall(ctx: CanvasRenderingContext2D, ball: Ball, b: Board) {
  const r = Math.max(4, b.sx * 0.2);
  const g = ctx.createRadialGradient(ball.x - r / 3, ball.y - r / 3, 1, ball.x, ball.y, r);
  g.addColorStop(0, '#FFF3C4');
  g.addColorStop(1, '#E2A85C');
  ctx.fillStyle = g;
  ctx.shadowColor = '#E2A85C';
  ctx.shadowBlur = 10;
  ctx.beginPath();
  ctx.arc(ball.x, ball.y, r, 0, Math.PI * 2);
  ctx.fill();
  ctx.shadowBlur = 0;
}
