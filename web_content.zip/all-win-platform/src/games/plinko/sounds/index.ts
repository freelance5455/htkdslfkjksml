import type { SoundBank } from '../../framework/sound.js';

export const SOUNDS: SoundBank = {
  drop: [{ wave: 'triangle', freq: 600, to: 300, dur: 90, gain: 0.12 }],
  peg: [{ wave: 'sine', freq: 1400, dur: 30, gain: 0.05 }],
  low: [{ wave: 'triangle', freq: 330, dur: 160, gain: 0.15 }],
  mid: [
    { wave: 'triangle', freq: 523, dur: 100, gain: 0.18 },
    { wave: 'triangle', freq: 659, dur: 160, at: 80, gain: 0.18 },
  ],
  high: [
    { wave: 'sine', freq: 784, dur: 100, gain: 0.25 },
    { wave: 'sine', freq: 1046, dur: 100, at: 80, gain: 0.25 },
    { wave: 'sine', freq: 1568, dur: 300, at: 160, gain: 0.25 },
  ],
};
