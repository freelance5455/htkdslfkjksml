import type { GameConfig } from '../framework/types.js';

export const config: GameConfig = {
  slug: 'plinko',
  name: 'Plinko',
  category: 'Originals',
  badge: 'MULTI-BALL',
  tagline: 'Drop a ball through the peg pyramid.',
  description: 'Each ball bounces left or right off every peg row before landing in a multiplier slot. Edges pay big, the centre pays small. Drop several balls at once!',
  howToPlay: [
    'Choose the number of rows (8, 12 or 16) and a risk level.',
    'Set a stake and tap Drop ball — each ball is its own round.',
    'The ball bounces through the pegs and lands in a slot.',
    'You win stake × the slot multiplier.',
  ],
  rtp: '98%',
  accent: '#3B82F6',
  minStake: 10,
  maxStake: 2000,
  defaultStake: 50,
};

export type Risk = 'low' | 'medium' | 'high';
export const ROW_OPTIONS = [8, 12, 16] as const;
export type Rows = (typeof ROW_OPTIONS)[number];
export const RISK_CURVE: Record<Risk, number> = { low: 2.2, medium: 4.2, high: 6.8 };
export const TARGET_RTP = 0.98;
export const ROW_MS = 120;
