import type { ParticleSystem } from '../../framework/particles.js';

export const binSplash = (p: ParticleSystem, x: number, y: number, color: string, big: boolean) =>
  p.burst({ x, y, count: big ? 40 : 10, colors: [color, '#ffffff'], speed: big ? 260 : 120, gravity: 400, life: big ? 1 : 0.5, size: 4, angle: -Math.PI / 2, spread: Math.PI * 0.9 });
