import type { GameModuleEntry, LobbyCategory } from './framework/types.js';
import { entry as skyRocket } from './sky-rocket/index.js';
import { entry as cluckCrossing } from './cluck-crossing/index.js';
import { entry as dice } from './dice/index.js';
import { entry as mines } from './mines/index.js';
import { entry as limbo } from './limbo/index.js';
import { entry as plinko } from './plinko/index.js';
import { entry as slot } from './harlequin-slot/index.js';
import { entry as blackjack } from './blackjack/index.js';
import { entry as roulette } from './roulette/index.js';
import { entry as scratch } from './scratch-card/index.js';
import { entry as keno } from './keno/index.js';

/**
 * Central game registry. Each entry's gameplay module is lazy-loaded into its
 * own chunk, so opening one game never loads or runs another game's code.
 */
export const GAMES: GameModuleEntry[] = [skyRocket, cluckCrossing, dice, mines, limbo, plinko, slot, blackjack, roulette, scratch, keno];

export const getGame = (slug: string | undefined) => GAMES.find((g) => g.config.slug === slug);
export const gamesIn = (cat: LobbyCategory) => GAMES.filter((g) => g.config.category === cat);

export const categorySlug = (c: LobbyCategory) => c.toLowerCase().replace(/\s+/g, '-');
export const categoryFromSlug = (s: string | undefined) =>
  (['Originals', 'Slots', 'Crash', 'Table Games', 'Lottery', 'Instant Mini', 'Arcade'] as LobbyCategory[]).find((c) => categorySlug(c) === s);
