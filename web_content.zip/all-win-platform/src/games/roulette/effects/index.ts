type Burst = (o: { rx?: number; ry?: number; count?: number; colors?: string[]; speed?: number; gravity?: number; shape?: 'circle' | 'square' | 'star'; size?: number }) => void;

export const winConfetti = (burst: Burst) =>
  burst({ rx: 0.5, ry: 0.4, count: 70, colors: ['#01A879', '#C58937', '#E92844', '#ffffff'], speed: 340, gravity: 480 });
