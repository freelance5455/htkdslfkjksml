import type { GameConfig } from '../framework/types.js';

export const config: GameConfig = {
  slug: 'roulette',
  name: 'Roulette',
  category: 'Table Games',
  badge: 'EUROPEAN',
  tagline: 'Single-zero wheel. Place your chips and spin.',
  description: 'European roulette with 37 pockets. Bet on single numbers, colours, odd/even, high/low, dozens or columns, then watch the ball settle.',
  howToPlay: [
    'Choose a chip value.',
    'Tap numbers (Numbers tab) or outside bets (Outside tab) to place chips. Tap again to add more.',
    'Use Undo or Clear to adjust, then tap Spin.',
    'Straight numbers pay 35:1, dozens & columns 2:1, red/black, odd/even, 1–18/19–36 pay 1:1.',
    'Tap Rebet to repeat your last layout.',
  ],
  rtp: '97.3%',
  accent: '#01A879',
  minStake: 10,
  maxStake: 10000,
  defaultStake: 10,
};

export const CHIP_VALUES = [10, 50, 100, 500] as const;
export const SPIN_MS = 4800;
