import { rng } from '../framework/session.js';

export const WHEEL_ORDER = [0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23, 10, 5, 24, 16, 33, 1, 20, 14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26];
const REDS = new Set([1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36]);

export const colorOf = (n: number): 'green' | 'red' | 'black' => (n === 0 ? 'green' : REDS.has(n) ? 'red' : 'black');
export const COLOR_HEX = { green: '#01A879', red: '#E92844', black: '#1F2937' } as const;

export type BetKey =
  | `n${number}` | 'red' | 'black' | 'odd' | 'even' | 'low' | 'high'
  | 'dozen1' | 'dozen2' | 'dozen3' | 'col1' | 'col2' | 'col3';

export const OUTSIDE: { key: BetKey; label: string; pays: number }[] = [
  { key: 'red', label: 'Red', pays: 2 },
  { key: 'black', label: 'Black', pays: 2 },
  { key: 'odd', label: 'Odd', pays: 2 },
  { key: 'even', label: 'Even', pays: 2 },
  { key: 'low', label: '1–18', pays: 2 },
  { key: 'high', label: '19–36', pays: 2 },
  { key: 'dozen1', label: '1st 12', pays: 3 },
  { key: 'dozen2', label: '2nd 12', pays: 3 },
  { key: 'dozen3', label: '3rd 12', pays: 3 },
  { key: 'col1', label: 'Col 1', pays: 3 },
  { key: 'col2', label: 'Col 2', pays: 3 },
  { key: 'col3', label: 'Col 3', pays: 3 },
];

/** Returns the total-return multiplier for a bet key given the winning number (0 if lost). */
export const betReturn = (key: BetKey, n: number): number => {
  if (key.startsWith('n')) return Number(key.slice(1)) === n ? 36 : 0;
  if (n === 0) return 0;
  switch (key) {
    case 'red': return colorOf(n) === 'red' ? 2 : 0;
    case 'black': return colorOf(n) === 'black' ? 2 : 0;
    case 'odd': return n % 2 === 1 ? 2 : 0;
    case 'even': return n % 2 === 0 ? 2 : 0;
    case 'low': return n <= 18 ? 2 : 0;
    case 'high': return n >= 19 ? 2 : 0;
    case 'dozen1': return n <= 12 ? 3 : 0;
    case 'dozen2': return n >= 13 && n <= 24 ? 3 : 0;
    case 'dozen3': return n >= 25 ? 3 : 0;
    case 'col1': return n % 3 === 1 ? 3 : 0;
    case 'col2': return n % 3 === 2 ? 3 : 0;
    case 'col3': return n % 3 === 0 ? 3 : 0;
  }
  return 0;
};

export type Bets = Record<string, number>;
export const totalBet = (b: Bets) => Object.values(b).reduce((s, v) => s + (v ?? 0), 0);
export const settleBets = (b: Bets, n: number) =>
  Object.entries(b).reduce((s, [k, v]) => s + (v ?? 0) * betReturn(k as BetKey, n), 0);

export const spinNumber = () => rng.int(0, 36);
