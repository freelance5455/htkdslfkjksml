import React, { useEffect, useRef, useState } from 'react';
import { RotateCcw, Trash2, Undo2 } from 'lucide-react';
import {
  GameShell, GameStage, ActionButton, Segmented, EffectsLayer,
  useScheduler, usePhaseMachine, useGameSession, useGameSound, useParticleLayer, useCanvas, easeOutCubic, fmtCredits,
} from '../framework/index.js';
import { config, CHIP_VALUES, SPIN_MS } from './config.js';
import { TRANSITIONS, Phase, WheelPose } from './gameState.js';
import { Bets, BetKey, OUTSIDE, totalBet, settleBets, spinNumber, colorOf, COLOR_HEX } from './gameLogic.js';
import { SOUNDS } from './sounds/index.js';
import { drawWheel, targetWheelAngle, SEG } from './animations/index.js';
import { winConfetti } from './effects/index.js';

export default function RouletteGame() {
  const session = useGameSession(config);
  const sched = useScheduler();
  const sound = useGameSound(SOUNDS);
  const fsm = usePhaseMachine<Phase>('BETTING', TRANSITIONS);
  const { canvasRef: wheelRef, size, ctx } = useCanvas();
  const { canvasRef: fxRef, burst } = useParticleLayer(sched);

  const [chip, setChip] = useState<number>(10);
  const [bets, setBets] = useState<Bets>({});
  const [stack, setStack] = useState<{ key: BetKey; amt: number }[]>([]);
  const [lastBets, setLastBets] = useState<Bets | null>(null);
  const [tab, setTab] = useState<'numbers' | 'outside'>('numbers');
  const [winner, setWinner] = useState<number | null>(null);
  const [outcome, setOutcome] = useState<{ payout: number; total: number } | null>(null);
  const [recent, setRecent] = useState<number[]>([]);

  const pose = useRef<WheelPose>({ wheel: 0, ball: 0, ballR: 1, settled: null });
  const highlight = useRef<number | null>(null);

  // idle drift + drawing
  useEffect(() => {
    return sched.loop((dt) => {
      const c = ctx();
      const { w, h } = size.current;
      if (!c || !w) return;
      if (fsm.current() !== 'SPINNING') {
        pose.current.wheel += dt * 0.25;
        if (pose.current.settled !== null) pose.current.ball += dt * 0.25;
      }
      drawWheel(c, w, h, pose.current, highlight.current);
    });
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const total = totalBet(bets);
  const canBet = fsm.phase !== 'SPINNING';

  const place = (key: BetKey) => {
    if (!canBet) return;
    sound.unlock();
    if (fsm.is('RESULT')) { fsm.go('BETTING'); setOutcome(null); }
    if (total + chip > session.credits || total + chip > config.maxStake) return;
    sound.play('chip');
    setBets((b) => ({ ...b, [key]: (b[key] ?? 0) + chip }));
    setStack((s) => [...s, { key, amt: chip }]);
  };
  const undo = () => {
    const last = stack[stack.length - 1];
    if (!last) return;
    setStack((s) => s.slice(0, -1));
    setBets((b) => {
      const n = { ...b, [last.key]: (b[last.key] ?? 0) - last.amt };
      if (!n[last.key]) delete n[last.key];
      return n;
    });
  };
  const clear = () => { setBets({}); setStack([]); };
  const rebet = () => {
    if (!lastBets || totalBet(lastBets) > session.credits) return;
    setBets(lastBets);
    setStack(Object.entries(lastBets).map(([key, amt]) => ({ key: key as BetKey, amt: amt! })));
    if (fsm.is('RESULT')) { fsm.go('BETTING'); setOutcome(null); }
  };

  const spin = async () => {
    sound.unlock();
    if (!total || fsm.is('SPINNING')) return;
    const r = session.beginRound(total);
    if (!r) return;
    const placed = bets;
    fsm.go('SPINNING');
    setOutcome(null);
    setWinner(null);
    highlight.current = null;
    sound.play('spin');
    const n = spinNumber();
    const p = pose.current;
    const w0 = p.wheel, wEnd = targetWheelAngle(w0, n, 4);
    const b0 = p.ball, bEnd = b0 - Math.PI * 2 * 7 - (((b0 % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2));
    let lastPocket = 0;
    p.settled = null;
    await sched.tween(SPIN_MS, (t) => {
      p.wheel = w0 + (wEnd - w0) * t;
      p.ball = b0 + (bEnd - b0) * Math.min(1, t * 1.08);
      p.ballR = t < 0.6 ? 1 : Math.max(0, 1 - (t - 0.6) / 0.3);
      const pocket = Math.floor(p.ball / SEG);
      if (pocket !== lastPocket && t > 0.55) { lastPocket = pocket; sound.play('clack'); }
    }, easeOutCubic);
    p.ball = 0; p.ballR = 0; p.settled = n;
    // keep ball locked to the pocket during idle drift
    p.ball = p.wheel - wEnd;
    sound.play('drop');
    highlight.current = n;
    const payout = settleBets(placed, n);
    session.settleRound(r, payout, `Ball landed on ${n} (${colorOf(n)})`);
    setWinner(n);
    setRecent((x) => [n, ...x].slice(0, 12));
    setOutcome({ payout, total });
    setLastBets(placed);
    setBets({});
    setStack([]);
    fsm.go('RESULT');
    if (payout > 0) { sound.play('win'); winConfetti(burst); } else sound.play('lose');
  };

  const chipBadge = (key: BetKey) =>
    bets[key] ? <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full bg-[#C58937] text-[9px] font-black flex items-center justify-center shadow anim-pop">{bets[key]! >= 1000 ? `${Math.floor(bets[key]! / 1000)}k` : bets[key]}</span> : null;

  return (
    <GameShell
      config={config}
      credits={session.credits}
      busy={fsm.phase === 'SPINNING'}
      status={fsm.phase === 'SPINNING' ? 'No more bets' : total ? `Bet ${fmtCredits(total)}` : 'Place your chips'}
      stage={
        <GameStage accent={config.accent} className="bg-[radial-gradient(ellipse_at_center,#0F5C45_0%,#0B3B2E_80%)] min-h-[260px]">
          <canvas ref={wheelRef} className="absolute inset-0 w-full h-full" />
          <EffectsLayer ref={fxRef} />
          <div className="absolute top-2 inset-x-2 flex gap-1 overflow-hidden">
            {recent.map((n, i) => (
              <span key={i} className="w-6 h-6 shrink-0 rounded-full text-[10px] font-black flex items-center justify-center anim-pop" style={{ background: COLOR_HEX[colorOf(n)] }}>{n}</span>
            ))}
          </div>
          {winner !== null && outcome && (
            <div className="absolute bottom-3 inset-x-0 flex justify-center pointer-events-none" data-testid="result">
              <div className={`px-4 py-2 rounded-2xl border-2 bg-[#12213D]/95 text-center ${outcome.payout > 0 ? 'anim-pop border-[#01A879]' : 'anim-shake border-[#E92844]'}`}>
                <p className="text-xs font-bold text-slate-300">Winning number</p>
                <p className="text-2xl font-black" style={{ color: winner === 0 ? '#01A879' : colorOf(winner) === 'red' ? '#F87171' : '#fff' }}>{winner}</p>
                <p className={`text-xs font-black ${outcome.payout > 0 ? 'text-[#01A879]' : 'text-[#E92844]'}`}>
                  {outcome.payout > 0 ? `+${fmtCredits(outcome.payout)} credits` : `Lost ${fmtCredits(outcome.total)}`}
                </p>
              </div>
            </div>
          )}
        </GameStage>
      }
      controls={
        <>
          <div className="flex items-center gap-2">
            {CHIP_VALUES.map((v) => (
              <button key={v} onClick={() => setChip(v)} aria-label={`Chip ${v}`}
                className={`w-11 h-11 rounded-full text-[11px] font-black border-4 border-dashed transition-all ${chip === v ? 'border-white scale-110 shadow-lg' : 'border-white/40'}`}
                style={{ background: v === 10 ? '#3B82F6' : v === 50 ? '#01A879' : v === 100 ? '#E92844' : '#1F2937' }}>
                {v}
              </button>
            ))}
            <div className="flex-1" />
            <button aria-label="Undo" onClick={undo} disabled={!stack.length || !canBet} className="w-10 h-10 rounded-xl bg-[#1A2C4E] border border-[#243A66] flex items-center justify-center disabled:opacity-40"><Undo2 className="w-4 h-4" /></button>
            <button aria-label="Clear bets" onClick={clear} disabled={!stack.length || !canBet} className="w-10 h-10 rounded-xl bg-[#1A2C4E] border border-[#243A66] flex items-center justify-center disabled:opacity-40"><Trash2 className="w-4 h-4" /></button>
            <button aria-label="Rebet" onClick={rebet} disabled={!lastBets || !canBet || stack.length > 0} className="w-10 h-10 rounded-xl bg-[#1A2C4E] border border-[#243A66] flex items-center justify-center disabled:opacity-40"><RotateCcw className="w-4 h-4" /></button>
          </div>
          <Segmented options={[{ value: 'numbers', label: 'Numbers' }, { value: 'outside', label: 'Outside bets' }]} value={tab} onChange={setTab} />
          {tab === 'numbers' ? (
            <div className={`grid grid-cols-6 gap-1 ${canBet ? '' : 'opacity-50 pointer-events-none'}`} data-testid="number-board">
              <button onClick={() => place('n0')} className="relative col-span-6 h-9 rounded-lg font-black text-sm" style={{ background: COLOR_HEX.green }}>0{chipBadge('n0')}</button>
              {Array.from({ length: 36 }, (_, i) => i + 1).map((n) => (
                <button key={n} onClick={() => place(`n${n}`)} className={`relative h-10 rounded-lg font-black text-sm ${winner === n ? 'ring-2 ring-white' : ''}`} style={{ background: COLOR_HEX[colorOf(n)] }}>
                  {n}{chipBadge(`n${n}`)}
                </button>
              ))}
            </div>
          ) : (
            <div className={`grid grid-cols-3 gap-1.5 ${canBet ? '' : 'opacity-50 pointer-events-none'}`}>
              {OUTSIDE.map((o) => (
                <button key={o.key} onClick={() => place(o.key)}
                  className="relative h-12 rounded-lg text-xs font-black border border-[#243A66]"
                  style={{ background: o.key === 'red' ? COLOR_HEX.red : o.key === 'black' ? COLOR_HEX.black : '#1A2C4E' }}>
                  {o.label}<span className="block text-[9px] text-slate-300 font-bold">pays {o.pays - 1}:1</span>{chipBadge(o.key)}
                </button>
              ))}
            </div>
          )}
          <ActionButton onClick={spin} disabled={!total || fsm.phase === 'SPINNING'}>
            {fsm.phase === 'SPINNING' ? 'Spinning…' : total ? `Spin · ${fmtCredits(total)}` : 'Place a chip to spin'}
          </ActionButton>
        </>
      }
    />
  );
}
