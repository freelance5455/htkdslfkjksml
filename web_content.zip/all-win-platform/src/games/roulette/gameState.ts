import type { Transitions } from '../framework/stateMachine.js';

/** BETTING → SPINNING → RESULT → BETTING */
export type Phase = 'BETTING' | 'SPINNING' | 'RESULT';
export const TRANSITIONS: Transitions<Phase> = {
  BETTING: ['SPINNING'],
  SPINNING: ['RESULT'],
  RESULT: ['BETTING', 'SPINNING'],
};

/** Mutable wheel pose for the render loop. */
export interface WheelPose {
  wheel: number; // radians
  ball: number; // radians (screen space, 0 = top)
  ballR: number; // 0..1 (1 = outer track, 0 = pocket ring)
  settled: number | null;
}
