import React from 'react';

export const Thumbnail: React.FC<{ className?: string }> = ({ className }) => (
  <svg viewBox="0 0 96 96" className={className} aria-hidden>
    <circle cx="48" cy="48" r="40" fill="#5B3A1A" />
    <circle cx="48" cy="48" r="36" fill="#C58937" />
    {Array.from({ length: 18 }, (_, i) => {
      const a0 = (i * Math.PI * 2) / 18, a1 = ((i + 1) * Math.PI * 2) / 18;
      const p = (a: number, r: number) => `${48 + Math.cos(a) * r} ${48 + Math.sin(a) * r}`;
      return <path key={i} d={`M${p(a0, 34)} A34 34 0 0 1 ${p(a1, 34)} L${p(a1, 20)} A20 20 0 0 0 ${p(a0, 20)} Z`} fill={i === 0 ? '#01A879' : i % 2 ? '#E92844' : '#1F2937'} />;
    })}
    <circle cx="48" cy="48" r="18" fill="#8B5A24" />
    <circle cx="48" cy="20" r="4" fill="#fff" />
  </svg>
);
