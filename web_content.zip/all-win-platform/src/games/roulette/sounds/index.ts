import type { SoundBank } from '../../framework/sound.js';

export const SOUNDS: SoundBank = {
  chip: [{ wave: 'square', freq: 1900, dur: 25, gain: 0.08 }, { wave: 'square', freq: 2400, dur: 25, at: 35, gain: 0.06 }],
  spin: [{ wave: 'noise', freq: 800, to: 2400, dur: 600, gain: 0.12 }],
  clack: [{ wave: 'triangle', freq: 2200, dur: 18, gain: 0.07 }],
  drop: [{ wave: 'triangle', freq: 900, to: 400, dur: 160, gain: 0.2 }],
  win: [
    { wave: 'sine', freq: 659, dur: 120, gain: 0.22 },
    { wave: 'sine', freq: 880, dur: 120, at: 100, gain: 0.22 },
    { wave: 'sine', freq: 1175, dur: 300, at: 200, gain: 0.22 },
  ],
  lose: [{ wave: 'triangle', freq: 260, to: 130, dur: 380, gain: 0.15 }],
};
