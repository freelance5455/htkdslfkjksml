import { WHEEL_ORDER, colorOf, COLOR_HEX } from '../gameLogic.js';
import type { WheelPose } from '../gameState.js';

export const SEG = (Math.PI * 2) / WHEEL_ORDER.length;

/** Final wheel angle so the winning pocket lands at the top pointer, after `turns` extra turns. */
export const targetWheelAngle = (start: number, winner: number, turns: number) => {
  const idx = WHEEL_ORDER.indexOf(winner);
  const desired = -idx * SEG;
  const base = start + turns * Math.PI * 2;
  const mod = (((desired - base) % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2);
  return base + mod;
};

export function drawWheel(ctx: CanvasRenderingContext2D, w: number, h: number, pose: WheelPose, highlight: number | null) {
  ctx.clearRect(0, 0, w, h);
  const cx = w / 2, cy = h / 2;
  const R = Math.min(w, h) / 2 - 8;
  // outer rim
  ctx.fillStyle = '#5B3A1A';
  ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = '#C58937';
  ctx.beginPath(); ctx.arc(cx, cy, R * 0.93, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = '#2B1A0C';
  ctx.beginPath(); ctx.arc(cx, cy, R * 0.9, 0, Math.PI * 2); ctx.fill();

  const outer = R * 0.88, inner = R * 0.62;
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(pose.wheel);
  WHEEL_ORDER.forEach((n, i) => {
    const a0 = -Math.PI / 2 + i * SEG - SEG / 2;
    ctx.beginPath();
    ctx.arc(0, 0, outer, a0, a0 + SEG);
    ctx.arc(0, 0, inner, a0 + SEG, a0, true);
    ctx.closePath();
    ctx.fillStyle = COLOR_HEX[colorOf(n)];
    ctx.fill();
    if (highlight === n) {
      ctx.fillStyle = 'rgba(255,255,255,0.35)';
      ctx.fill();
    }
    ctx.strokeStyle = '#C58937';
    ctx.lineWidth = 1;
    ctx.stroke();
    ctx.save();
    ctx.rotate(i * SEG);
    ctx.fillStyle = '#fff';
    ctx.font = `bold ${Math.max(8, R * 0.075)}px Inter, sans-serif`;
    ctx.textAlign = 'center';
    ctx.fillText(String(n), 0, -outer + R * 0.1);
    ctx.restore();
  });
  // hub
  const hub = ctx.createRadialGradient(0, 0, 4, 0, 0, inner);
  hub.addColorStop(0, '#E2A85C');
  hub.addColorStop(0.5, '#8B5A24');
  hub.addColorStop(1, '#3B240E');
  ctx.fillStyle = hub;
  ctx.beginPath(); ctx.arc(0, 0, inner * 0.98, 0, Math.PI * 2); ctx.fill();
  ctx.strokeStyle = '#E2A85C';
  ctx.lineWidth = 3;
  for (let k = 0; k < 4; k++) {
    ctx.rotate(Math.PI / 4);
    ctx.beginPath(); ctx.moveTo(-inner * 0.5, 0); ctx.lineTo(inner * 0.5, 0); ctx.stroke();
  }
  ctx.restore();

  // pointer
  ctx.fillStyle = '#FDE68A';
  ctx.beginPath();
  ctx.moveTo(cx - 8, cy - R - 2); ctx.lineTo(cx + 8, cy - R - 2); ctx.lineTo(cx, cy - R + 12); ctx.closePath(); ctx.fill();

  // ball
  const ballTrack = R * 0.86 + pose.ballR * R * 0.02;
  const ballRing = inner + (outer - inner) * 0.3;
  const br = ballRing + (ballTrack - ballRing) * pose.ballR;
  const bx = cx + Math.cos(pose.ball - Math.PI / 2) * br;
  const by = cy + Math.sin(pose.ball - Math.PI / 2) * br;
  const g = ctx.createRadialGradient(bx - 2, by - 2, 1, bx, by, 6);
  g.addColorStop(0, '#ffffff');
  g.addColorStop(1, '#94A3B8');
  ctx.fillStyle = g;
  ctx.beginPath(); ctx.arc(bx, by, Math.max(4, R * 0.04), 0, Math.PI * 2); ctx.fill();
}
