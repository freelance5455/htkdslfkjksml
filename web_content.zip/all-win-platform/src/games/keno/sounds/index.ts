import type { SoundBank } from '../../framework/sound.js';

export const SOUNDS: SoundBank = {
  pick: [{ wave: 'triangle', freq: 700, dur: 50, gain: 0.12 }],
  unpick: [{ wave: 'triangle', freq: 450, dur: 50, gain: 0.1 }],
  ball: [{ wave: 'sine', freq: 520, to: 380, dur: 120, gain: 0.15 }],
  hit: [
    { wave: 'sine', freq: 880, dur: 80, gain: 0.2 },
    { wave: 'sine', freq: 1320, dur: 140, at: 60, gain: 0.18 },
  ],
  win: [
    { wave: 'triangle', freq: 523, dur: 110, gain: 0.2 },
    { wave: 'triangle', freq: 784, dur: 110, at: 100, gain: 0.2 },
    { wave: 'triangle', freq: 1046, dur: 280, at: 200, gain: 0.2 },
  ],
  lose: [{ wave: 'triangle', freq: 280, to: 140, dur: 320, gain: 0.14 }],
};
