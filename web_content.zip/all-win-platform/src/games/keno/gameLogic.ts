import { rng } from '../framework/session.js';
import { BOARD, DRAWS, TARGET_RTP } from './config.js';

const comb = (n: number, k: number) => {
  if (k < 0 || k > n) return 0;
  let r = 1;
  for (let i = 0; i < k; i++) r = (r * (n - i)) / (i + 1);
  return r;
};

/** P(exactly h of k picks are among the DRAWS drawn numbers). */
export const hitProbability = (k: number, h: number) => (comb(DRAWS, h) * comb(BOARD - DRAWS, k - h)) / comb(BOARD, k);

const minHit = (k: number) => (k <= 3 ? 1 : Math.floor(k / 2));

/** Original paytable: exponential reward for hits, normalised to the target RTP. */
export const paytable = (k: number): number[] => {
  if (k === 0) return [];
  const raw = Array.from({ length: k + 1 }, (_, h) => (h >= minHit(k) ? Math.exp(1.55 * h) - (h === minHit(k) ? 0 : 0) : 0));
  const ev = raw.reduce((s, r, h) => s + r * hitProbability(k, h), 0);
  return raw.map((r) => {
    const m = (r / ev) * TARGET_RTP;
    if (m === 0) return 0;
    return m >= 100 ? Math.round(m) : m >= 10 ? Math.round(m * 2) / 2 : Math.max(0.1, Math.round(m * 10) / 10);
  });
};

export const drawNumbers = (): number[] => rng.shuffle([...Array(BOARD).keys()].map((i) => i + 1)).slice(0, DRAWS);
export const quickPick = (k: number): number[] => rng.shuffle([...Array(BOARD).keys()].map((i) => i + 1)).slice(0, k);
