import type { Scheduler } from '../../framework/scheduler.js';

/** Sequential ball draw: reveals one number every `interval` ms. */
export async function drawSequence(s: Scheduler, numbers: number[], interval: number, onBall: (n: number, i: number) => void) {
  for (let i = 0; i < numbers.length; i++) {
    await s.wait(interval);
    onBall(numbers[i], i);
  }
}
