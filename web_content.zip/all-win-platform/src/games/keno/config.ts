import type { GameConfig } from '../framework/types.js';

export const config: GameConfig = {
  slug: 'keno',
  name: 'Keno',
  category: 'Lottery',
  badge: 'NUMBER DRAW',
  tagline: 'Pick up to 10 numbers, watch 10 balls drawn.',
  description: 'Choose 1 to 10 numbers from a board of 40. Ten numbers are drawn one by one — the more of your picks that are hit, the bigger the payout.',
  howToPlay: [
    'Tap numbers on the board to pick 1–10 of them (or use Quick pick).',
    'Set a stake and tap Draw.',
    'Ten balls are drawn one at a time; matches light up green.',
    'Your payout depends on how many picks were hit — see the paytable.',
  ],
  rtp: '≈96%',
  accent: '#06B6D4',
  minStake: 10,
  maxStake: 5000,
  defaultStake: 100,
};

export const BOARD = 40;
export const DRAWS = 10;
export const MAX_PICKS = 10;
export const DRAW_INTERVAL_MS = 320;
export const TARGET_RTP = 0.96;
