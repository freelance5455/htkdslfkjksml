import React from 'react';

export const Thumbnail: React.FC<{ className?: string }> = ({ className }) => (
  <svg viewBox="0 0 96 96" className={className} aria-hidden>
    {Array.from({ length: 16 }, (_, i) => {
      const x = 14 + (i % 4) * 18, y = 14 + Math.floor(i / 4) * 18;
      const hit = [1, 6, 11, 12].includes(i), pick = [3, 9].includes(i);
      return <rect key={i} x={x} y={y} width="14" height="14" rx="4" fill={hit ? '#01A879' : pick ? '#06B6D4' : '#243A66'} />;
    })}
    <circle cx="78" cy="78" r="12" fill="#fff" />
    <text x="78" y="83" textAnchor="middle" fontSize="12" fontWeight="900" fill="#12213D">7</text>
  </svg>
);
