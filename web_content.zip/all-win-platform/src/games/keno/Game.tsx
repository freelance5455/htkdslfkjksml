import React, { useRef, useState } from 'react';
import {
  GameShell, GameStage, StakeControl, ActionButton, EffectsLayer,
  useScheduler, usePhaseMachine, useGameSession, useGameSound, useParticleLayer, fmtCredits,
} from '../framework/index.js';
import { config, BOARD, MAX_PICKS, DRAW_INTERVAL_MS } from './config.js';
import { TRANSITIONS, Phase } from './gameState.js';
import { paytable, drawNumbers, quickPick } from './gameLogic.js';
import { SOUNDS } from './sounds/index.js';
import { drawSequence } from './animations/index.js';
import { hitPop, kenoWin } from './effects/index.js';

export default function KenoGame() {
  const session = useGameSession(config);
  const sched = useScheduler();
  const sound = useGameSound(SOUNDS);
  const fsm = usePhaseMachine<Phase>('PICKING', TRANSITIONS);
  const { canvasRef, burst } = useParticleLayer(sched);

  const [stake, setStake] = useState(config.defaultStake);
  const [picks, setPicks] = useState<number[]>([]);
  const [drawn, setDrawn] = useState<number[]>([]);
  const [summary, setSummary] = useState<{ hits: number; mult: number; payout: number } | null>(null);
  const boardRef = useRef<HTMLDivElement>(null);

  const table = paytable(picks.length);
  const drawing = fsm.phase === 'DRAWING';

  const toggle = (n: number) => {
    if (drawing) return;
    sound.unlock();
    if (fsm.is('RESULT')) { fsm.go('PICKING'); setDrawn([]); setSummary(null); }
    setPicks((p) => {
      if (p.includes(n)) { sound.play('unpick'); return p.filter((x) => x !== n); }
      if (p.length >= MAX_PICKS) return p;
      sound.play('pick');
      return [...p, n];
    });
  };

  const cellCenter = (n: number) => {
    const el = boardRef.current?.children[n - 1] as HTMLElement | undefined;
    const host = boardRef.current?.closest('[data-stage]') as HTMLElement | null;
    if (!el || !host) return { x: 0, y: 0 };
    const a = el.getBoundingClientRect(), b = host.getBoundingClientRect();
    return { x: a.left - b.left + a.width / 2, y: a.top - b.top + a.height / 2 };
  };

  const draw = async () => {
    sound.unlock();
    if (!picks.length || drawing) return;
    const r = session.beginRound(stake);
    if (!r) return;
    fsm.go('DRAWING');
    setDrawn([]);
    setSummary(null);
    const numbers = drawNumbers();
    const chosen = new Set(picks);
    let hits = 0;
    await drawSequence(sched, numbers, DRAW_INTERVAL_MS, (n) => {
      setDrawn((d) => [...d, n]);
      if (chosen.has(n)) {
        hits++;
        sound.play('hit');
        const c = cellCenter(n);
        hitPop(burst, c.x, c.y);
      } else sound.play('ball');
    });
    const mult = table[hits] ?? 0;
    const payout = Math.floor(stake * mult * 100) / 100;
    session.settleRound(r, payout, `${hits} of ${picks.length} hit`);
    setSummary({ hits, mult, payout });
    fsm.go('RESULT');
    if (payout > stake) { sound.play('win'); kenoWin(burst); } else sound.play(payout > 0 ? 'hit' : 'lose');
  };

  const quick = () => {
    if (drawing) return;
    if (fsm.is('RESULT')) { fsm.go('PICKING'); setDrawn([]); setSummary(null); }
    setPicks(quickPick(Math.max(picks.length, 5)));
    sound.play('pick');
  };
  const clear = () => {
    if (drawing) return;
    if (fsm.is('RESULT')) { fsm.go('PICKING'); setDrawn([]); setSummary(null); }
    setPicks([]);
  };

  const drawnSet = new Set(drawn);

  return (
    <GameShell
      config={config}
      credits={session.credits}
      busy={drawing}
      status={drawing ? `Drawing ${drawn.length}/10` : `${picks.length}/${MAX_PICKS} picked`}
      stage={
        <GameStage accent={config.accent}>
          <div data-stage className="absolute inset-0">
            <EffectsLayer ref={canvasRef} />
            <div className="absolute inset-0 flex flex-col gap-2 p-3">
              <div className="flex gap-1 min-h-[30px] flex-wrap justify-center">
                {drawn.map((n) => (
                  <span key={n} className={`w-7 h-7 rounded-full text-[11px] font-black flex items-center justify-center anim-pop shadow ${picks.includes(n) ? 'bg-[#01A879]' : 'bg-white text-[#12213D]'}`}>{n}</span>
                ))}
                {!drawn.length && <span className="text-[11px] text-slate-400 self-center">{picks.length ? 'Ready to draw' : 'Pick 1–10 numbers'}</span>}
              </div>
              <div ref={boardRef} className="grid grid-cols-8 gap-1.5 flex-1 content-center" data-testid="keno-board">
                {Array.from({ length: BOARD }, (_, i) => i + 1).map((n) => {
                  const picked = picks.includes(n), hit = picked && drawnSet.has(n), miss = !picked && drawnSet.has(n);
                  return (
                    <button key={n} onClick={() => toggle(n)} aria-label={`Number ${n}`}
                      className={`aspect-square rounded-lg text-xs font-black transition-all ${hit ? 'bg-[#01A879] anim-pop shadow-[0_0_12px_#01A879]' : picked ? 'bg-[#06B6D4]' : miss ? 'bg-[#243A66] text-[#E92844]' : 'bg-[#1A2C4E] text-slate-300'} active:scale-95`}>
                      {n}
                    </button>
                  );
                })}
              </div>
              <div className="h-8 flex items-center justify-center" data-testid="result">
                {summary && (
                  <p className={`text-sm font-black anim-pop ${summary.payout > stake ? 'text-[#01A879]' : summary.payout > 0 ? 'text-[#C58937]' : 'text-[#E92844]'}`}>
                    {summary.hits} hits · {summary.mult}× · {summary.payout > 0 ? `+${fmtCredits(summary.payout)}` : 'no win'}
                  </p>
                )}
              </div>
              {picks.length > 0 && (
                <div className="flex gap-1 overflow-x-auto scrollbar-none">
                  {table.map((m, h) => (
                    <div key={h} className={`shrink-0 min-w-[42px] rounded-md px-1 py-1 text-center ${summary?.hits === h ? 'bg-[#01A879]' : 'bg-[#1A2C4E]'}`}>
                      <p className="text-[9px] text-slate-300 font-bold">{h} hit</p>
                      <p className="text-[10px] font-black">{m ? `${m}×` : '–'}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </GameStage>
      }
      controls={
        <>
          <div className="grid grid-cols-2 gap-2">
            <ActionButton tone="navy" onClick={quick} disabled={drawing}>Quick pick</ActionButton>
            <ActionButton tone="navy" onClick={clear} disabled={drawing || !picks.length}>Clear</ActionButton>
          </div>
          <StakeControl value={stake} onChange={setStake} min={config.minStake} max={config.maxStake} credits={session.credits} disabled={drawing} />
          <ActionButton onClick={draw} disabled={drawing || !picks.length || stake > session.credits}>
            {drawing ? 'Drawing…' : !picks.length ? 'Pick numbers first' : stake > session.credits ? 'Not enough credits' : `Draw · ${fmtCredits(stake)}`}
          </ActionButton>
        </>
      }
    />
  );
}
