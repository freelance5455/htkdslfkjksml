import type { Transitions } from '../framework/stateMachine.js';

/** PICKING → DRAWING → RESULT → (PICKING | DRAWING) */
export type Phase = 'PICKING' | 'DRAWING' | 'RESULT';
export const TRANSITIONS: Transitions<Phase> = {
  PICKING: ['DRAWING'],
  DRAWING: ['RESULT'],
  RESULT: ['PICKING', 'DRAWING'],
};
