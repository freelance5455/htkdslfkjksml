type Burst = (o: { x?: number; y?: number; rx?: number; ry?: number; count?: number; colors?: string[]; speed?: number; gravity?: number; shape?: 'circle' | 'square' | 'star'; size?: number; life?: number }) => void;

export const hitPop = (burst: Burst, x: number, y: number) =>
  burst({ x, y, count: 16, colors: ['#01A879', '#67E8F9', '#ffffff'], speed: 160, gravity: 200, shape: 'star', size: 4, life: 0.7 });

export const kenoWin = (burst: Burst) =>
  burst({ rx: 0.5, ry: 0.4, count: 70, colors: ['#06B6D4', '#01A879', '#C58937', '#ffffff'], speed: 330, gravity: 450 });
