import React from 'react';

export const Thumbnail: React.FC<{ className?: string }> = ({ className }) => (
  <svg viewBox="0 0 96 96" className={className} aria-hidden>
    {[0, 1, 2].map((r) => [0, 1, 2].map((c) => (
      <rect key={`${r}${c}`} x={14 + c * 24} y={14 + r * 24} width="20" height="20" rx="5" fill={r === 1 && c === 1 ? '#01A879' : '#243A66'} />
    )))}
    <path d="M48 42 L54 48 L48 56 L42 48 Z" fill="#A7F3D0" />
    <circle cx="72" cy="72" r="7" fill="#E92844" />
    <path d="M72 62 V66 M72 78 V82 M62 72 H66 M78 72 H82" stroke="#E92844" strokeWidth="2.5" />
  </svg>
);
