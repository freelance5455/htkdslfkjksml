import type { Scheduler } from '../../framework/scheduler.js';

/** Staggered reveal of the remaining board after a round ends (ripple from origin). */
export function rippleReveal(s: Scheduler, origin: number, indices: number[], reveal: (i: number) => void, onTick: () => void) {
  const ox = origin % 5, oy = Math.floor(origin / 5);
  for (const i of indices) {
    const d = Math.hypot((i % 5) - ox, Math.floor(i / 5) - oy);
    s.timeout(() => {
      reveal(i);
      onTick();
    }, 60 + d * 70);
  }
}

/** CSS 3D flip classes for a tile. */
export const flipStyle = (revealed: boolean): React.CSSProperties => ({
  transform: revealed ? 'rotateY(180deg)' : 'rotateY(0deg)',
  transition: 'transform 380ms cubic-bezier(.2,.8,.2,1)',
});
