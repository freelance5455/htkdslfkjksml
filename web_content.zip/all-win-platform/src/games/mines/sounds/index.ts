import type { SoundBank } from '../../framework/sound.js';

export const SOUNDS: SoundBank = {
  start: [{ wave: 'triangle', freq: 392, to: 784, dur: 180, gain: 0.15 }],
  gem: [
    { wave: 'sine', freq: 1046, dur: 90, gain: 0.2 },
    { wave: 'sine', freq: 1568, dur: 160, at: 60, gain: 0.15 },
  ],
  mine: [
    { wave: 'noise', freq: 1800, to: 80, dur: 700, gain: 0.5 },
    { wave: 'sine', freq: 90, to: 35, dur: 500, gain: 0.4 },
  ],
  reveal: [{ wave: 'triangle', freq: 300, dur: 40, gain: 0.05 }],
  cashout: [
    { wave: 'sine', freq: 784, dur: 100, gain: 0.22 },
    { wave: 'sine', freq: 1046, dur: 100, at: 80, gain: 0.22 },
    { wave: 'sine', freq: 1568, dur: 260, at: 160, gain: 0.22 },
  ],
};
