import React, { useRef, useState } from 'react';
import { Gem, Bomb } from 'lucide-react';
import {
  GameShell, GameStage, StakeControl, ActionButton, ResultBanner, ResultInfo, EffectsLayer,
  useScheduler, usePhaseMachine, useGameSession, useGameSound, useParticleLayer, RoundHandle, fmtCredits, rng,
} from '../framework/index.js';
import { config, GRID } from './config.js';
import { TRANSITIONS, Phase, TileState, emptyBoard } from './gameState.js';
import { placeMines, minesMultiplier, maxSafe } from './gameLogic.js';
import { SOUNDS } from './sounds/index.js';
import { rippleReveal, flipStyle } from './animations/index.js';
import { gemSparkle, mineBlast, cashRain } from './effects/index.js';

export default function MinesGame() {
  const session = useGameSession(config);
  const sched = useScheduler();
  const sound = useGameSound(SOUNDS);
  const fsm = usePhaseMachine<Phase>('IDLE', TRANSITIONS);
  const { canvasRef, burst } = useParticleLayer(sched);

  const [stake, setStake] = useState(config.defaultStake);
  const [mineCount, setMineCount] = useState(3);
  const [board, setBoard] = useState<TileState[]>(emptyBoard);
  const [safe, setSafe] = useState(0);
  const [result, setResult] = useState<ResultInfo | null>(null);
  const mines = useRef<Set<number>>(new Set());
  const round = useRef<RoundHandle | null>(null);
  const gridRef = useRef<HTMLDivElement>(null);

  const mult = minesMultiplier(mineCount, safe);
  const nextMult = minesMultiplier(mineCount, safe + 1);

  const tileCenter = (i: number) => {
    const el = gridRef.current?.children[i] as HTMLElement | undefined;
    const host = gridRef.current?.parentElement;
    if (!el || !host) return { x: 0, y: 0 };
    const a = el.getBoundingClientRect(), b = host.getBoundingClientRect();
    return { x: a.left - b.left + a.width / 2, y: a.top - b.top + a.height / 2 };
  };

  const start = () => {
    sound.unlock();
    const r = session.beginRound(stake);
    if (!r) return;
    round.current = r;
    mines.current = placeMines(mineCount);
    setBoard(emptyBoard());
    setSafe(0);
    setResult(null);
    fsm.go('ACTIVE');
    sound.play('start');
  };

  const revealRest = (origin: number) => {
    const rest = [...Array(GRID).keys()].filter((i) => board[i] === 'hidden' && i !== origin);
    rippleReveal(sched, origin, rest, (i) => setBoard((b) => {
      const n = [...b];
      if (n[i] === 'hidden') n[i] = mines.current.has(i) ? 'ghost-mine' : 'ghost-gem';
      return n;
    }), () => sound.play('reveal'));
  };

  const pick = (i: number) => {
    if (!fsm.is('ACTIVE') || board[i] !== 'hidden') return;
    const { x, y } = tileCenter(i);
    if (mines.current.has(i)) {
      setBoard((b) => { const n = [...b]; n[i] = 'mine'; return n; });
      fsm.go('BUSTED');
      sound.play('mine');
      mineBlast(burst, x, y);
      session.settleRound(round.current!, 0, `Hit a mine after ${safe} gems (${mineCount} mines)`);
      round.current = null;
      revealRest(i);
      sched.timeout(() => setResult({ outcome: 'lose', title: 'Boom!', payout: 0, note: `${safe} gems found` }), 900);
      return;
    }
    const s = safe + 1;
    setBoard((b) => { const n = [...b]; n[i] = 'gem'; return n; });
    setSafe(s);
    sound.play('gem');
    gemSparkle(burst, x, y);
    if (s >= maxSafe(mineCount)) cashOut(s, i);
  };

  const cashOut = (s = safe, origin = 12) => {
    if (!fsm.is('ACTIVE') || s === 0) return;
    const m = minesMultiplier(mineCount, s);
    const payout = Math.floor(stake * m * 100) / 100;
    session.settleRound(round.current!, payout, `Cashed out with ${s} gems (${mineCount} mines)`);
    round.current = null;
    fsm.go('CASHED');
    sound.play('cashout');
    cashRain(burst);
    revealRest(origin);
    sched.timeout(() => setResult({ outcome: 'win', title: 'Cashed out!', multiplier: m, payout, note: `${s} gems · ${mineCount} mines` }), 700);
  };

  const randomPick = () => {
    const hidden = [...Array(GRID).keys()].filter((i) => board[i] === 'hidden');
    if (hidden.length) pick(rng.pick(hidden));
  };

  const replay = () => {
    setResult(null);
    setBoard(emptyBoard());
    setSafe(0);
    fsm.go('IDLE');
  };

  const phase = fsm.phase;
  const active = phase === 'ACTIVE';

  return (
    <GameShell
      config={config}
      credits={session.credits}
      busy={active}
      status={active ? `${safe} gems · ${mult.toFixed(2)}×` : phase === 'IDLE' ? 'Ready' : 'Round over'}
      stage={
        <GameStage accent={config.accent}>
          <EffectsLayer ref={canvasRef} />
          <div className="absolute inset-0 flex flex-col items-center justify-center p-3 gap-3">
            <div className="flex gap-2 text-[11px] font-bold">
              <span className="px-3 py-1 rounded-full bg-[#1A2C4E] text-[#01A879]">Current {mult.toFixed(2)}×</span>
              <span className="px-3 py-1 rounded-full bg-[#1A2C4E] text-[#C58937]">Next {nextMult.toFixed(2)}×</span>
            </div>
            <div ref={gridRef} className="grid grid-cols-5 gap-2 w-full max-w-[360px] aspect-square" data-testid="mines-grid">
              {board.map((t, i) => {
                const revealed = t !== 'hidden';
                const isMine = t === 'mine' || t === 'ghost-mine';
                const ghost = t.startsWith('ghost');
                return (
                  <button
                    key={i}
                    aria-label={`Tile ${i + 1}`}
                    onClick={() => pick(i)}
                    disabled={!active || revealed}
                    className="relative perspective w-full h-full"
                  >
                    <div className="absolute inset-0 preserve-3d" style={flipStyle(revealed)}>
                      <div className={`absolute inset-0 backface-hidden rounded-xl border-b-4 border-[#0E1A31] ${active ? 'bg-[#2A4170] active:bg-[#34508A]' : 'bg-[#243A66]'} shadow-md`} />
                      <div
                        className={`absolute inset-0 backface-hidden rounded-xl flex items-center justify-center ${isMine ? 'bg-[#E92844]/25' : 'bg-[#01A879]/20'} ${ghost ? 'opacity-45' : ''}`}
                        style={{ transform: 'rotateY(180deg)' }}
                      >
                        {revealed && (isMine ? <Bomb className="w-1/2 h-1/2 text-[#E92844]" /> : <Gem className="w-1/2 h-1/2 text-[#34D399]" />)}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
          <ResultBanner result={result} onReplay={replay} />
        </GameStage>
      }
      controls={
        active ? (
          <div className="grid grid-cols-2 gap-2">
            <ActionButton tone="navy" onClick={randomPick}>Random tile</ActionButton>
            <ActionButton tone="green" onClick={() => cashOut()} disabled={safe === 0}>
              Cash out {safe > 0 ? fmtCredits(Math.floor(stake * mult * 100) / 100) : ''}
            </ActionButton>
          </div>
        ) : (
          <>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold uppercase text-slate-400 w-10">Mines</span>
              <input aria-label="Mines" type="range" min={1} max={24} value={mineCount} disabled={phase !== 'IDLE'}
                onChange={(e) => setMineCount(+e.target.value)} className="flex-1 accent-[#01A879] h-8" />
              <span className="w-8 text-right text-sm font-black text-[#E92844]">{mineCount}</span>
            </div>
            <StakeControl value={stake} onChange={setStake} min={config.minStake} max={config.maxStake} credits={session.credits} disabled={phase !== 'IDLE'} />
            <ActionButton onClick={phase === 'IDLE' ? start : replay} disabled={phase === 'IDLE' && stake > session.credits}>
              {phase === 'IDLE' ? (stake > session.credits ? 'Not enough credits' : `Start · ${fmtCredits(stake)}`) : 'New round'}
            </ActionButton>
          </>
        )
      }
    />
  );
}
