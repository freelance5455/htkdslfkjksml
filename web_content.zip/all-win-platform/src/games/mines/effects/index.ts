type Burst = (o: { x?: number; y?: number; count?: number; colors?: string[]; speed?: number; gravity?: number; shape?: 'circle' | 'square' | 'star'; size?: number; life?: number }) => void;

export const gemSparkle = (burst: Burst, x: number, y: number) =>
  burst({ x, y, count: 18, colors: ['#34D399', '#A7F3D0', '#ffffff'], speed: 180, gravity: 120, shape: 'star', size: 4, life: 0.7 });

export const mineBlast = (burst: Burst, x: number, y: number) => {
  burst({ x, y, count: 60, colors: ['#E92844', '#FFB347', '#FFE08A'], speed: 360, gravity: 200, shape: 'circle', size: 6 });
};

export const cashRain = (burst: Burst) =>
  burst({ count: 70, colors: ['#C58937', '#E2A85C', '#01A879'], speed: 340, gravity: 500, size: 6 });
