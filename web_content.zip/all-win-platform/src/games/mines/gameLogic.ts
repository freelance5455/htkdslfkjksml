import { rng } from '../framework/session.js';
import { EDGE, GRID } from './config.js';

export const placeMines = (count: number): Set<number> => new Set(rng.shuffle([...Array(GRID).keys()]).slice(0, count));

const comb = (n: number, k: number) => {
  let r = 1;
  for (let i = 0; i < k; i++) r = (r * (n - i)) / (i + 1);
  return r;
};

/** Multiplier after `safe` gems revealed with `mines` mines on the board. */
export const minesMultiplier = (mines: number, safe: number) =>
  safe === 0 ? 1 : Math.floor((1 - EDGE) * (comb(GRID, safe) / comb(GRID - mines, safe)) * 100) / 100;

export const maxSafe = (mines: number) => GRID - mines;
