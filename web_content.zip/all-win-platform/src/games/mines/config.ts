import type { GameConfig } from '../framework/types.js';

export const config: GameConfig = {
  slug: 'mines',
  name: 'Mines',
  category: 'Originals',
  badge: 'POPULAR',
  tagline: 'Uncover gems, dodge the mines.',
  description: 'A 5×5 field hides gems and mines. Every gem you uncover boosts the multiplier. Cash out any time — hit a mine and the stake is lost.',
  howToPlay: [
    'Choose how many mines to hide (1–24). More mines = faster multiplier growth.',
    'Set a stake and tap Start.',
    'Tap tiles to reveal them. Gems raise your multiplier.',
    'Tap Cash out to collect, or keep going for more.',
    'Reveal a mine and the round ends.',
  ],
  rtp: '99%',
  accent: '#01A879',
  minStake: 10,
  maxStake: 5000,
  defaultStake: 100,
};

export const GRID = 25;
export const EDGE = 0.01;
