import type { Transitions } from '../framework/stateMachine.js';
import { GRID } from './config.js';

/** IDLE → ACTIVE → (BUSTED | CASHED) → IDLE */
export type Phase = 'IDLE' | 'ACTIVE' | 'BUSTED' | 'CASHED';
export const TRANSITIONS: Transitions<Phase> = {
  IDLE: ['ACTIVE'],
  ACTIVE: ['BUSTED', 'CASHED'],
  BUSTED: ['IDLE'],
  CASHED: ['IDLE'],
};

export type TileState = 'hidden' | 'gem' | 'mine' | 'ghost-gem' | 'ghost-mine';
export const emptyBoard = (): TileState[] => Array(GRID).fill('hidden');
