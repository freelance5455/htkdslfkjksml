import { rng } from '../framework/session.js';
import { DIFFICULTY, Difficulty, RTP } from './config.js';

/** Fair multiplier after surviving `lane` lanes: RTP / P(survive lane lanes). */
export const laneMultiplier = (d: Difficulty, lane: number): number => {
  if (lane <= 0) return 1;
  const p = DIFFICULTY[d].hitChance;
  return Math.floor((RTP / Math.pow(1 - p, lane)) * 100) / 100;
};

export const multiplierTable = (d: Difficulty) =>
  Array.from({ length: DIFFICULTY[d].lanes }, (_, i) => laneMultiplier(d, i + 1));

/** Resolves whether the hop into the next lane is hit by traffic. */
export const rollHop = (d: Difficulty): 'safe' | 'hit' => (rng.float() < DIFFICULTY[d].hitChance ? 'hit' : 'safe');

export const payoutFor = (stake: number, m: number) => Math.floor(stake * m * 100) / 100;
