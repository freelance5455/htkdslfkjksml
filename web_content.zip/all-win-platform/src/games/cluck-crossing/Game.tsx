import React, { useEffect, useRef, useState } from 'react';
import {
  GameShell, GameStage, StakeControl, ActionButton, Segmented, ResultBanner, ResultInfo,
  useScheduler, usePhaseMachine, useGameSession, useGameSound, useCanvas, ParticleSystem, RoundHandle,
  easeOutCubic, lerp, fmtCredits,
} from '../framework/index.js';
import { config, DIFFICULTY, Difficulty, HOP_MS, LANE_H } from './config.js';
import { TRANSITIONS, Phase, World, createWorld, laneCenterY } from './gameState.js';
import { multiplierTable, rollHop, payoutFor } from './gameLogic.js';
import { SOUNDS } from './sounds/index.js';
import { drawRoad, drawCars, drawHen, toScreen } from './animations/index.js';
import { feathers, safeSparkle, victory } from './effects/index.js';

export default function CluckCrossingGame() {
  const session = useGameSession(config);
  const sched = useScheduler();
  const sound = useGameSound(SOUNDS);
  const fsm = usePhaseMachine<Phase>('IDLE', TRANSITIONS);
  const { canvasRef, size, ctx } = useCanvas((w) => {
    if (fsm.current() === 'IDLE') world.current = createWorld(diffRef.current, w);
  });

  const [stake, setStake] = useState(config.defaultStake);
  const [difficulty, setDifficulty] = useState<Difficulty>('medium');
  const [lane, setLane] = useState(0);
  const [result, setResult] = useState<ResultInfo | null>(null);

  const diffRef = useRef(difficulty);
  diffRef.current = difficulty;
  const world = useRef<World>(createWorld(difficulty, 360));
  const multsRef = useRef(multiplierTable(difficulty));
  const round = useRef<RoundHandle | null>(null);
  const pending = useRef<'safe' | 'hit'>('safe');
  const fx = useRef(new ParticleSystem());

  const mults = multiplierTable(difficulty);
  const n = DIFFICULTY[difficulty].lanes;

  const changeDifficulty = (d: Difficulty) => {
    setDifficulty(d);
    diffRef.current = d;
    multsRef.current = multiplierTable(d);
    world.current = createWorld(d, size.current.w || 360);
  };

  /* ---------------- actions ---------------- */
  const start = () => {
    sound.unlock();
    const r = session.beginRound(stake);
    if (!r) return;
    round.current = r;
    world.current = createWorld(difficulty, size.current.w || 360);
    multsRef.current = multiplierTable(difficulty);
    setLane(0);
    setResult(null);
    fsm.go('ACTIVE');
    sound.play('start');
  };

  const hop = () => {
    if (!fsm.is('ACTIVE')) return;
    const w = world.current;
    pending.current = rollHop(diffRef.current);
    fsm.go('HOPPING');
    sound.play('hop');
    if (w.henLane > 0) w.lanes[w.henLane - 1].blocked = false;
    if (pending.current === 'safe') w.lanes[w.henLane].blocked = true;
    w.hopFrom = w.henY;
    w.hopT = 0;
  };

  const finish = (outcome: 'cash' | 'complete') => {
    const w = world.current;
    const m = multsRef.current[w.henLane - 1];
    const payout = payoutFor(round.current!.stake, m);
    session.settleRound(round.current!, payout, outcome === 'complete' ? `Crossed all ${w.lanes.length} lanes` : `Cashed out at lane ${w.henLane}`);
    round.current = null;
    fsm.go('RESULT');
    sound.play('cashout');
    victory(fx.current, w.henX, toScreen(w.henY, w.camY, size.current.h));
    setResult({ outcome: 'win', title: outcome === 'complete' ? 'Made it across!' : 'Cashed out!', multiplier: m, payout, note: `Lane ${w.henLane} of ${w.lanes.length}` });
  };

  const cashOut = () => {
    if (!fsm.is('ACTIVE') || world.current.henLane < 1) return;
    finish('cash');
  };

  const landed = () => {
    const w = world.current;
    w.henLane += 1;
    w.hopT = -1;
    w.squash = 1;
    setLane(w.henLane);
    const sy = toScreen(w.henY, w.camY, size.current.h);
    if (pending.current === 'hit') {
      fsm.go('HIT');
      sound.play('horn');
      const ln = w.lanes[w.henLane - 1];
      ln.cars.push({ x: ln.dir === 1 ? -70 : size.current.w + 70, speed: 820, w: 60, color: '#E92844', killer: true });
      return;
    }
    sound.play('safe');
    safeSparkle(fx.current, w.henX, sy);
    if (w.henLane >= w.lanes.length) {
      // final hop onto the safe zone
      w.henLane = w.lanes.length;
      finish('complete');
      return;
    }
    fsm.go('ACTIVE');
    if (Math.random() < 0.3) sound.play('cluck');
  };

  const squashed = () => {
    const w = world.current;
    w.dead = true;
    sound.play('crash');
    feathers(fx.current, w.henX, toScreen(w.henY, w.camY, size.current.h));
    session.settleRound(round.current!, 0, `Hit in lane ${w.henLane}`);
    round.current = null;
    sched.timeout(() => {
      fsm.go('RESULT');
      setResult({ outcome: 'lose', title: 'Splat!', payout: 0, note: `Caught in lane ${w.henLane}` });
    }, 900);
  };

  const replay = () => {
    setResult(null);
    world.current = createWorld(diffRef.current, size.current.w || 360);
    setLane(0);
    fsm.go('IDLE');
  };

  /* ---------------- simulation + render loop ---------------- */
  useEffect(() => {
    return sched.loop((dt) => {
      const c = ctx();
      const { w, h } = size.current;
      if (!c || !w) return;
      const wd = world.current;
      wd.time += dt;
      wd.henX = w / 2;
      // hen hop animation
      if (wd.hopT >= 0) {
        wd.hopT = Math.min(1, wd.hopT + (dt * 1000) / HOP_MS);
        wd.henY = lerp(wd.hopFrom, laneCenterY(wd.henLane + 1), easeOutCubic(wd.hopT));
        if (wd.hopT >= 1) landed();
      }
      wd.squash = Math.max(0, wd.squash - dt * 5);
      // traffic
      wd.lanes.forEach((ln, i) => {
        const barrier = ln.dir === 1 ? w / 2 - 52 : w / 2 + 52;
        const ordered = [...ln.cars].sort((a, b) => (ln.dir === 1 ? b.x - a.x : a.x - b.x));
        let limit = barrier;
        for (const car of ordered) {
          car.x += ln.dir * car.speed * dt;
          if (ln.blocked && !car.killer) {
            const front = car.x + (ln.dir * car.w) / 2;
            const before = ln.dir === 1 ? car.x < w / 2 - 20 : car.x > w / 2 + 20;
            if (before && (ln.dir === 1 ? front > limit : front < limit)) car.x = limit - (ln.dir * car.w) / 2;
            if (before) limit = car.x - ln.dir * (car.w / 2 + 10);
          }
          if (car.killer && !wd.dead && i === wd.henLane - 1 && Math.abs(car.x - wd.henX) < car.w / 2 + 10) squashed();
        }
        ln.cars = ln.cars.filter((car) => car.x > -120 && car.x < w + 120);
        ln.spawnIn -= dt;
        if (ln.spawnIn <= 0) {
          ln.spawnIn = (1.1 + Math.random() * 1.8) / DIFFICULTY[diffRef.current].traffic;
          ln.cars.push({ x: ln.dir === 1 ? -60 : w + 60, speed: ln.speed, w: 46 + Math.random() * 20, color: ['#3B82F6', '#01A879', '#A855F7', '#F97316', '#E2E8F0'][Math.floor(Math.random() * 5)] });
        }
      });
      // camera follows hen
      const target = Math.max(0, wd.henY - h * 0.3);
      wd.camY = lerp(wd.camY, Math.min(target, (wd.lanes.length + 2) * LANE_H - h), Math.min(1, dt * 6));
      wd.camY = Math.max(0, wd.camY);

      drawRoad(c, w, h, wd, multsRef.current);
      drawCars(c, h, wd);
      drawHen(c, wd.henX, toScreen(wd.henY, wd.camY, h), wd.hopT, wd.squash, wd.dead, wd.time);
      fx.current.update(dt);
      fx.current.draw(c);
    });
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const phase = fsm.phase;
  const current = lane > 0 ? mults[lane - 1] : 1;
  const next = lane < n ? mults[lane] : null;

  return (
    <GameShell
      config={config}
      credits={session.credits}
      busy={phase === 'ACTIVE' || phase === 'HOPPING'}
      status={phase === 'IDLE' ? 'Ready' : phase === 'RESULT' ? 'Round over' : `Lane ${lane}/${n}`}
      stage={
        <GameStage accent={config.accent}>
          <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" />
          <div className="absolute top-3 inset-x-3 flex justify-between pointer-events-none">
            <div className="px-3 py-1.5 rounded-xl bg-[#12213D]/90 border border-[#243A66]">
              <p className="text-[9px] text-slate-400 font-bold uppercase">Current</p>
              <p className="text-lg font-black text-[#01A879] tabular" data-testid="current-mult">{current.toFixed(2)}×</p>
            </div>
            {next && (
              <div className="px-3 py-1.5 rounded-xl bg-[#12213D]/90 border border-[#243A66] text-right">
                <p className="text-[9px] text-slate-400 font-bold uppercase">Next lane</p>
                <p className="text-lg font-black text-[#C58937] tabular">{next.toFixed(2)}×</p>
              </div>
            )}
          </div>
          <ResultBanner result={result} onReplay={replay} />
        </GameStage>
      }
      controls={
        phase === 'IDLE' ? (
          <>
            <Segmented
              options={(Object.keys(DIFFICULTY) as Difficulty[]).map((d) => ({ value: d, label: DIFFICULTY[d].label }))}
              value={difficulty}
              onChange={changeDifficulty}
            />
            <StakeControl value={stake} onChange={setStake} min={config.minStake} max={config.maxStake} credits={session.credits} />
            <ActionButton onClick={start} disabled={stake > session.credits}>
              {stake > session.credits ? 'Not enough credits' : `Start crossing · ${fmtCredits(stake)}`}
            </ActionButton>
          </>
        ) : (
          <div className="grid grid-cols-2 gap-2">
            <ActionButton tone="green" onClick={cashOut} disabled={phase !== 'ACTIVE' || lane < 1}>
              Cash out{lane > 0 ? ` ${fmtCredits(payoutFor(stake, current))}` : ''}
            </ActionButton>
            <ActionButton onClick={hop} disabled={phase !== 'ACTIVE'}>Hop ↑</ActionButton>
          </div>
        )
      }
    />
  );
}
