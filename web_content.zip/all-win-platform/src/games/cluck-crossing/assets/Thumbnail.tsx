import React from 'react';

/** Original artwork: hen crossing striped lanes. */
export const Thumbnail: React.FC<{ className?: string }> = ({ className }) => (
  <svg viewBox="0 0 96 96" className={className} aria-hidden>
    <rect x="4" y="18" width="88" height="60" rx="8" fill="#1D2738" />
    <path d="M4 38 H92 M4 58 H92" stroke="#fff" strokeOpacity=".35" strokeDasharray="8 6" strokeWidth="2" />
    <rect x="58" y="22" width="26" height="12" rx="3" fill="#E92844" />
    <rect x="12" y="62" width="26" height="12" rx="3" fill="#3B82F6" />
    <g transform="translate(46 50)">
      <ellipse cx="0" cy="0" rx="12" ry="11" fill="#fff" />
      <circle cx="-2" cy="-11" r="3.2" fill="#E92844" />
      <circle cx="3" cy="-12" r="3.2" fill="#E92844" />
      <path d="M10 -3 L17 0 L10 3 Z" fill="#F59E0B" />
      <circle cx="5" cy="-3" r="1.8" fill="#12213D" />
    </g>
  </svg>
);
