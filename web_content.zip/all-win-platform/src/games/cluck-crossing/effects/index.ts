import type { ParticleSystem } from '../../framework/particles.js';

export const feathers = (p: ParticleSystem, x: number, y: number) =>
  p.burst({ x, y, count: 45, colors: ['#ffffff', '#F1F5F9', '#F5B841', '#E92844'], speed: 260, gravity: 160, life: 1.4, size: 7 });

export const safeSparkle = (p: ParticleSystem, x: number, y: number) =>
  p.burst({ x, y, count: 14, colors: ['#01A879', '#C58937'], speed: 140, gravity: 60, life: 0.6, shape: 'star', size: 4 });

export const victory = (p: ParticleSystem, x: number, y: number) =>
  p.burst({ x, y, count: 90, colors: ['#C58937', '#E2A85C', '#01A879', '#ffffff'], speed: 380, gravity: 420, life: 1.6 });
