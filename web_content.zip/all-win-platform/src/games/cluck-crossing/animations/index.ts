import { LANE_H } from '../config.js';
import type { World } from '../gameState.js';

/** World y (bottom-up) → screen y. */
export const toScreen = (worldY: number, camY: number, h: number) => h - (worldY - camY);

export function drawRoad(ctx: CanvasRenderingContext2D, w: number, h: number, world: World, multipliers: number[]) {
  const n = world.lanes.length;
  ctx.fillStyle = '#0E1A31';
  ctx.fillRect(0, 0, w, h);
  // start sidewalk (lane 0) and finish (lane n+1)
  for (const [lane, label] of [[0, 'START'], [n + 1, 'SAFE ZONE']] as const) {
    const y = toScreen((lane + 1) * LANE_H, world.camY, h);
    ctx.fillStyle = lane === 0 ? '#2A3B5E' : '#1F5E4A';
    ctx.fillRect(0, y, w, LANE_H);
    ctx.fillStyle = 'rgba(255,255,255,0.35)';
    ctx.font = 'bold 11px Inter, sans-serif';
    ctx.textAlign = 'left';
    ctx.fillText(label, 10, y + LANE_H / 2 + 4);
  }
  for (let i = 0; i < n; i++) {
    const lane = i + 1;
    const y = toScreen((lane + 1) * LANE_H, world.camY, h);
    if (y > h || y + LANE_H < 0) continue;
    ctx.fillStyle = i % 2 ? '#1A2333' : '#1D2738';
    ctx.fillRect(0, y, w, LANE_H);
    // dashed separator
    ctx.strokeStyle = 'rgba(255,255,255,0.18)';
    ctx.setLineDash([14, 12]);
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(w, y);
    ctx.stroke();
    ctx.setLineDash([]);
    // multiplier marker (manhole)
    const passed = world.henLane >= lane;
    ctx.fillStyle = passed ? 'rgba(1,168,121,0.25)' : 'rgba(197,137,55,0.12)';
    ctx.beginPath();
    ctx.ellipse(w / 2, y + LANE_H / 2, 30, 18, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = passed ? '#01A879' : '#C58937';
    ctx.font = 'bold 12px Inter, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(`${multipliers[i].toFixed(2)}×`, w / 2, y + LANE_H / 2 + 4);
    // barrier on hen's safe lane
    if (world.lanes[i].blocked) {
      const bx = world.lanes[i].dir === 1 ? w / 2 - 50 : w / 2 + 38;
      ctx.fillStyle = '#F5B841';
      ctx.fillRect(bx, y + 8, 12, LANE_H - 16);
      ctx.fillStyle = '#12213D';
      for (let s = 0; s < 3; s++) ctx.fillRect(bx, y + 14 + s * 16, 12, 6);
    }
  }
  ctx.textAlign = 'left';
}

export function drawCars(ctx: CanvasRenderingContext2D, h: number, world: World) {
  world.lanes.forEach((lane, i) => {
    const y = toScreen((i + 2) * LANE_H, world.camY, h);
    if (y > h || y + LANE_H < 0) return;
    for (const car of lane.cars) {
      const cy = y + LANE_H / 2;
      ctx.save();
      ctx.translate(car.x, cy);
      if (lane.dir === -1) ctx.scale(-1, 1);
      ctx.fillStyle = 'rgba(0,0,0,0.35)';
      ctx.fillRect(-car.w / 2 + 3, -12, car.w, 28);
      ctx.fillStyle = car.color;
      roundRect(ctx, -car.w / 2, -15, car.w, 30, 7);
      ctx.fill();
      ctx.fillStyle = 'rgba(18,33,61,0.85)';
      roundRect(ctx, car.w / 2 - 20, -11, 11, 22, 3);
      ctx.fill();
      ctx.fillStyle = '#FFE08A';
      ctx.fillRect(car.w / 2 - 3, -12, 3, 6);
      ctx.fillRect(car.w / 2 - 3, 6, 3, 6);
      ctx.restore();
    }
  });
}

/** Original hen character. */
export function drawHen(ctx: CanvasRenderingContext2D, x: number, y: number, hop: number, squash: number, dead: boolean, time: number) {
  const lift = hop >= 0 ? Math.sin(hop * Math.PI) * 18 : Math.abs(Math.sin(time * 4)) * 2;
  const sx = dead ? 1.6 : 1 + squash * 0.2;
  const sy = dead ? 0.35 : 1 - squash * 0.2;
  ctx.save();
  ctx.translate(x, y - lift);
  ctx.fillStyle = 'rgba(0,0,0,0.3)';
  ctx.beginPath();
  ctx.ellipse(0, 14 + lift, 14, 5, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.scale(sx, sy);
  // legs
  ctx.strokeStyle = '#F59E0B';
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  ctx.moveTo(-4, 8); ctx.lineTo(-5, 15);
  ctx.moveTo(4, 8); ctx.lineTo(5, 15);
  ctx.stroke();
  // body
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.ellipse(0, 0, 14, 13, 0, 0, Math.PI * 2);
  ctx.fill();
  // wing
  ctx.fillStyle = '#E2E8F0';
  ctx.beginPath();
  ctx.ellipse(-6, 2, 7, 5, -0.4 + (hop >= 0 ? Math.sin(hop * 20) * 0.5 : 0), 0, Math.PI * 2);
  ctx.fill();
  // comb
  ctx.fillStyle = '#E92844';
  ctx.beginPath();
  ctx.arc(-2, -13, 3.5, 0, Math.PI * 2);
  ctx.arc(3, -14, 3.5, 0, Math.PI * 2);
  ctx.fill();
  // beak & eye
  ctx.fillStyle = '#F59E0B';
  ctx.beginPath();
  ctx.moveTo(12, -3); ctx.lineTo(19, 0); ctx.lineTo(12, 3); ctx.fill();
  ctx.fillStyle = '#12213D';
  if (dead) {
    ctx.font = 'bold 8px sans-serif';
    ctx.fillText('x', 4, -1);
  } else {
    ctx.beginPath();
    ctx.arc(6, -4, 2, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}
