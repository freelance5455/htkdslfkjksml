import type { SoundBank } from '../../framework/sound.js';

export const SOUNDS: SoundBank = {
  start: [
    { wave: 'square', freq: 523, dur: 90, gain: 0.12 },
    { wave: 'square', freq: 784, dur: 140, at: 90, gain: 0.12 },
  ],
  hop: [{ wave: 'triangle', freq: 300, to: 700, dur: 160, gain: 0.2 }],
  safe: [
    { wave: 'sine', freq: 880, dur: 90, gain: 0.18 },
    { wave: 'sine', freq: 1175, dur: 140, at: 70, gain: 0.18 },
  ],
  cluck: [
    { wave: 'square', freq: 900, to: 600, dur: 70, gain: 0.08 },
    { wave: 'square', freq: 1000, to: 650, dur: 80, at: 110, gain: 0.08 },
  ],
  horn: [
    { wave: 'sawtooth', freq: 330, dur: 260, gain: 0.12 },
    { wave: 'sawtooth', freq: 415, dur: 260, gain: 0.1 },
  ],
  crash: [
    { wave: 'noise', freq: 3000, to: 200, dur: 500, gain: 0.45 },
    { wave: 'sine', freq: 160, to: 50, dur: 400, gain: 0.3 },
  ],
  cashout: [
    { wave: 'sine', freq: 659, dur: 110, gain: 0.22 },
    { wave: 'sine', freq: 880, dur: 110, at: 90, gain: 0.22 },
    { wave: 'sine', freq: 1319, dur: 280, at: 180, gain: 0.22 },
  ],
};
