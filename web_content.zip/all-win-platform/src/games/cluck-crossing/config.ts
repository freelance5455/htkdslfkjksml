import type { GameConfig } from '../framework/types.js';

export const config: GameConfig = {
  slug: 'cluck-crossing',
  name: 'Cluck Crossing',
  category: 'Arcade',
  badge: 'RISK LADDER',
  tagline: 'Hop the hen across traffic — every lane raises the reward and the risk.',
  description:
    'Guide a brave hen across a busy multi-lane road. Each lane you survive pushes the multiplier higher. Cash out whenever you like — but if a car catches the hen, the round is lost.',
  howToPlay: [
    'Pick a difficulty: higher difficulty means faster multiplier growth and more danger per lane.',
    'Choose a stake and tap Start crossing.',
    'Tap Hop to move the hen into the next lane.',
    'Survive a lane and its multiplier is locked in — tap Cash out to collect.',
    'Reach the far sidewalk to win the maximum multiplier automatically.',
  ],
  rtp: '97%',
  accent: '#F5B841',
  minStake: 10,
  maxStake: 5000,
  defaultStake: 100,
};

export type Difficulty = 'easy' | 'medium' | 'hard' | 'daredevil';

export const DIFFICULTY: Record<Difficulty, { label: string; hitChance: number; lanes: number; traffic: number }> = {
  easy: { label: 'Easy', hitChance: 0.08, lanes: 12, traffic: 1 },
  medium: { label: 'Medium', hitChance: 0.16, lanes: 10, traffic: 1.25 },
  hard: { label: 'Hard', hitChance: 0.26, lanes: 8, traffic: 1.5 },
  daredevil: { label: 'Daredevil', hitChance: 0.4, lanes: 6, traffic: 1.9 },
};

export const RTP = 0.97;
export const LANE_H = 66;
export const HOP_MS = 380;
