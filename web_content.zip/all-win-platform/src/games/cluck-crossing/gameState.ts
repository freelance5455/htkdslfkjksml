import type { Transitions } from '../framework/stateMachine.js';
import { DIFFICULTY, Difficulty, LANE_H } from './config.js';

/** IDLE → ACTIVE ⇄ HOPPING → (HIT) → RESULT → IDLE */
export type Phase = 'IDLE' | 'ACTIVE' | 'HOPPING' | 'HIT' | 'RESULT';

export const TRANSITIONS: Transitions<Phase> = {
  IDLE: ['ACTIVE'],
  ACTIVE: ['HOPPING', 'RESULT'],
  HOPPING: ['ACTIVE', 'HIT', 'RESULT'],
  HIT: ['RESULT'],
  RESULT: ['IDLE'],
};

export interface Car {
  x: number;
  speed: number;
  w: number;
  color: string;
  killer?: boolean;
}

export interface Lane {
  dir: 1 | -1;
  speed: number;
  cars: Car[];
  spawnIn: number;
  blocked: boolean;
}

/** Mutable world simulated by the rAF loop (not React state). */
export interface World {
  lanes: Lane[];
  henLane: number; // 0 = start sidewalk, n+1 = finish
  henY: number; // world y (px from bottom)
  henX: number;
  hopFrom: number;
  hopT: number; // 0..1 while hopping, -1 idle
  squash: number;
  camY: number;
  dead: boolean;
  time: number;
}

const CAR_COLORS = ['#E92844', '#3B82F6', '#01A879', '#A855F7', '#F97316', '#E2E8F0'];

export const createWorld = (d: Difficulty, width: number): World => {
  const n = DIFFICULTY[d].lanes;
  const lanes: Lane[] = Array.from({ length: n }, (_, i) => {
    const dir = (i % 2 === 0 ? 1 : -1) as 1 | -1;
    const speed = (90 + Math.random() * 70 + i * 9) * DIFFICULTY[d].traffic;
    const cars: Car[] = [];
    let x = Math.random() * 120;
    while (x < width) {
      cars.push({ x, speed, w: 46 + Math.random() * 20, color: CAR_COLORS[Math.floor(Math.random() * CAR_COLORS.length)] });
      x += 140 + Math.random() * 160;
    }
    return { dir, speed, cars, spawnIn: 0.5 + Math.random(), blocked: false };
  });
  return { lanes, henLane: 0, henY: LANE_H / 2, henX: width / 2, hopFrom: LANE_H / 2, hopT: -1, squash: 0, camY: 0, dead: false, time: 0 };
};

export const laneCenterY = (lane: number) => lane * LANE_H + LANE_H / 2;
