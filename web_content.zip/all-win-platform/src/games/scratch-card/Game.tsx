import React, { useRef, useState } from 'react';
import {
  GameShell, GameStage, StakeControl, ActionButton, ResultBanner, ResultInfo, EffectsLayer,
  useScheduler, usePhaseMachine, useGameSession, useGameSound, useParticleLayer, useCanvas, RoundHandle, fmtCredits,
} from '../framework/index.js';
import { config, AUTO_REVEAL_AT, BRUSH } from './config.js';
import { TRANSITIONS, Phase } from './gameState.js';
import { generateCard, winningCells, PRIZES, Sym } from './gameLogic.js';
import { SOUNDS } from './sounds/index.js';
import { paintFoil, scratchLine, scratchedRatio } from './animations/index.js';
import { foilFlakes, prizeBurst } from './effects/index.js';
import { SymbolIcon } from './assets/Thumbnail.js';

export default function ScratchCardGame() {
  const session = useGameSession(config);
  const sched = useScheduler();
  const sound = useGameSound(SOUNDS);
  const fsm = usePhaseMachine<Phase>('IDLE', TRANSITIONS);
  const { canvasRef: fxRef, burst } = useParticleLayer(sched);
  const foil = useCanvas((w, h) => {
    const c = foil.ctx();
    if (c && (fsm.current() === 'SCRATCHING' || fsm.current() === 'IDLE')) paintFoil(c, w, h);
  }, { willReadFrequently: true });

  const [stake, setStake] = useState(config.defaultStake);
  const [card, setCard] = useState<{ cells: Sym[]; prize: (typeof PRIZES)[number] | null } | null>(null);
  const [foilOpacity, setFoilOpacity] = useState(1);
  const [progress, setProgress] = useState(0);
  const [result, setResult] = useState<ResultInfo | null>(null);
  const round = useRef<RoundHandle | null>(null);
  const last = useRef<{ x: number; y: number } | null>(null);
  const moves = useRef(0);
  const lastSound = useRef(0);

  const buy = () => {
    sound.unlock();
    const r = session.beginRound(stake);
    if (!r) return;
    round.current = r;
    setCard(generateCard());
    setResult(null);
    setProgress(0);
    setFoilOpacity(1);
    const c = foil.ctx();
    if (c) paintFoil(c, foil.size.current.w, foil.size.current.h);
    fsm.go('SCRATCHING');
    sound.play('buy');
  };

  const reveal = async () => {
    if (!fsm.is('SCRATCHING') || !card) return;
    fsm.go('REVEALING');
    sound.play('reveal');
    await sched.tween(450, (p) => setFoilOpacity(1 - p));
    const payout = card.prize ? stake * card.prize.mult : 0;
    session.settleRound(round.current!, payout, card.prize ? `3× ${card.prize.label}` : 'No match');
    round.current = null;
    fsm.go('RESULT');
    if (card.prize) {
      sound.play('win');
      prizeBurst(burst);
      setResult({ outcome: payout > stake ? 'win' : 'push', title: `3 × ${card.prize.label}`, multiplier: card.prize.mult, payout });
    } else {
      sound.play('lose');
      setResult({ outcome: 'lose', title: 'No match', payout: 0, note: 'Better luck on the next card' });
    }
  };

  const point = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const r = e.currentTarget.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  };
  const onDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!fsm.is('SCRATCHING')) return;
    e.currentTarget.setPointerCapture(e.pointerId);
    last.current = point(e);
    onMove(e);
  };
  const onMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!last.current || !fsm.is('SCRATCHING')) return;
    const c = foil.ctx();
    if (!c) return;
    const p = point(e);
    scratchLine(c, last.current.x, last.current.y, p.x, p.y, BRUSH);
    last.current = p;
    foilFlakes(burst, p.x, p.y);
    const now = performance.now();
    if (now - lastSound.current > 70) { sound.play('scratch'); lastSound.current = now; }
    if (++moves.current % 8 === 0 && foil.canvasRef.current) {
      const ratio = scratchedRatio(foil.canvasRef.current);
      setProgress(ratio);
      if (ratio >= AUTO_REVEAL_AT) reveal();
    }
  };
  const onUp = () => { last.current = null; };

  const phase = fsm.phase;
  const wins = card && phase === 'RESULT' ? winningCells(card.cells, card.prize?.sym ?? null) : [];

  return (
    <GameShell
      config={config}
      credits={session.credits}
      busy={phase === 'SCRATCHING' || phase === 'REVEALING'}
      status={phase === 'SCRATCHING' ? `Scratched ${Math.round(progress * 100)}%` : phase === 'RESULT' ? 'Card revealed' : 'Buy a card'}
      stage={
        <GameStage accent={config.accent} className="bg-gradient-to-b from-[#2A1C0E] to-[#12213D]">
          <EffectsLayer ref={fxRef} />
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 p-4">
            <p className="text-sm font-black tracking-[0.25em] text-[#E2A85C]">LUCKY SCRATCH</p>
            <div className="relative w-full max-w-[320px] aspect-square rounded-2xl bg-white p-3 shadow-2xl">
              <div className="grid grid-cols-3 gap-2 w-full h-full" data-testid="scratch-grid">
                {(card?.cells ?? Array(9).fill('coin')).map((s, i) => (
                  <div key={i} className={`rounded-xl flex items-center justify-center bg-slate-100 transition-all ${wins.includes(i) ? 'ring-4 ring-[#01A879] bg-emerald-50 anim-pop' : ''} ${!card ? 'opacity-0' : ''}`}>
                    <SymbolIcon sym={s} className="w-3/4 h-3/4" />
                  </div>
                ))}
              </div>
              <canvas
                ref={foil.canvasRef}
                className="absolute inset-3 rounded-xl touch-none"
                style={{ width: 'calc(100% - 24px)', height: 'calc(100% - 24px)', opacity: foilOpacity, cursor: phase === 'SCRATCHING' ? 'crosshair' : 'default', pointerEvents: phase === 'RESULT' ? 'none' : 'auto' }}
                onPointerDown={onDown}
                onPointerMove={onMove}
                onPointerUp={onUp}
                onPointerCancel={onUp}
                data-testid="foil"
              />
            </div>
            <div className="grid grid-cols-6 gap-1 w-full max-w-[320px]">
              {PRIZES.map((p) => (
                <div key={p.sym} className="flex flex-col items-center bg-[#1A2C4E]/80 rounded-md py-1">
                  <SymbolIcon sym={p.sym} className="w-5 h-5" />
                  <span className="text-[9px] font-black text-slate-200">{p.mult}×</span>
                </div>
              ))}
            </div>
          </div>
          <ResultBanner result={result} onReplay={buy} replayLabel={`Buy another · ${fmtCredits(stake)}`} />
        </GameStage>
      }
      controls={
        phase === 'SCRATCHING' || phase === 'REVEALING' ? (
          <ActionButton tone="navy" onClick={reveal} disabled={phase !== 'SCRATCHING'}>Reveal all</ActionButton>
        ) : (
          <>
            <StakeControl value={stake} onChange={setStake} min={config.minStake} max={config.maxStake} credits={session.credits} label="Price" />
            <ActionButton onClick={buy} disabled={stake > session.credits}>
              {stake > session.credits ? 'Not enough credits' : `Buy card · ${fmtCredits(stake)}`}
            </ActionButton>
          </>
        )
      }
    />
  );
}
