import type { Transitions } from '../framework/stateMachine.js';

/** IDLE → SCRATCHING → REVEALING → RESULT → IDLE */
export type Phase = 'IDLE' | 'SCRATCHING' | 'REVEALING' | 'RESULT';
export const TRANSITIONS: Transitions<Phase> = {
  IDLE: ['SCRATCHING'],
  SCRATCHING: ['REVEALING'],
  REVEALING: ['RESULT'],
  RESULT: ['IDLE', 'SCRATCHING'],
};
