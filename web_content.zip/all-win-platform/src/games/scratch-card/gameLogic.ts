import { rng } from '../framework/session.js';

export type Sym = 'coin' | 'clover' | 'horseshoe' | 'star' | 'crown' | 'diamond';

export const PRIZES: { sym: Sym; mult: number; chance: number; label: string; color: string }[] = [
  { sym: 'diamond', mult: 100, chance: 0.0005, label: 'Diamond', color: '#60A5FA' },
  { sym: 'crown', mult: 50, chance: 0.002, label: 'Crown', color: '#F59E0B' },
  { sym: 'star', mult: 10, chance: 0.015, label: 'Star', color: '#FBBF24' },
  { sym: 'horseshoe', mult: 5, chance: 0.04, label: 'Horseshoe', color: '#94A3B8' },
  { sym: 'clover', mult: 2, chance: 0.12, label: 'Clover', color: '#22C55E' },
  { sym: 'coin', mult: 1, chance: 0.2, label: 'Coin', color: '#E2A85C' },
];

const ALL: Sym[] = PRIZES.map((p) => p.sym);

/** Decides the prize first, then builds a 3×3 card consistent with it. */
export const generateCard = (): { cells: Sym[]; prize: (typeof PRIZES)[number] | null } => {
  let r = rng.float();
  let prize: (typeof PRIZES)[number] | null = null;
  for (const p of PRIZES) {
    if (r < p.chance) { prize = p; break; }
    r -= p.chance;
  }
  const cells: (Sym | null)[] = Array(9).fill(null);
  const counts = new Map<Sym, number>();
  if (prize) {
    for (const i of rng.shuffle([...Array(9).keys()]).slice(0, 3)) cells[i] = prize.sym;
    counts.set(prize.sym, 3);
  }
  for (let i = 0; i < 9; i++) {
    if (cells[i]) continue;
    const options = ALL.filter((s) => (counts.get(s) ?? 0) < 2 && s !== prize?.sym);
    const s = rng.pick(options);
    cells[i] = s;
    counts.set(s, (counts.get(s) ?? 0) + 1);
  }
  return { cells: cells as Sym[], prize };
};

export const winningCells = (cells: Sym[], prize: Sym | null) => (prize ? cells.map((c, i) => (c === prize ? i : -1)).filter((i) => i >= 0) : []);
