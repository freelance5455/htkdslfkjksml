import type { SoundBank } from '../../framework/sound.js';

export const SOUNDS: SoundBank = {
  buy: [{ wave: 'triangle', freq: 500, to: 900, dur: 140, gain: 0.15 }],
  scratch: [{ wave: 'noise', freq: 5000, to: 3000, dur: 60, gain: 0.08, filter: 6000 }],
  reveal: [{ wave: 'noise', freq: 3000, to: 8000, dur: 400, gain: 0.12 }],
  win: [
    { wave: 'sine', freq: 784, dur: 120, gain: 0.22 },
    { wave: 'sine', freq: 988, dur: 120, at: 100, gain: 0.22 },
    { wave: 'sine', freq: 1568, dur: 320, at: 200, gain: 0.22 },
  ],
  lose: [{ wave: 'triangle', freq: 330, to: 160, dur: 320, gain: 0.14 }],
};
