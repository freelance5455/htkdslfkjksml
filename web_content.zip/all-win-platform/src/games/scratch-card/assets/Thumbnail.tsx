import React from 'react';
import type { Sym } from '../gameLogic.js';

/** Original symbol artwork for the scratch card. */
export const SymbolIcon: React.FC<{ sym: Sym; className?: string }> = ({ sym, className }) => {
  switch (sym) {
    case 'diamond':
      return <svg viewBox="0 0 48 48" className={className}><path d="M10 18 L18 8 H30 L38 18 L24 42 Z" fill="#60A5FA" /><path d="M10 18 H38 L24 42 Z" fill="#2563EB" /></svg>;
    case 'crown':
      return <svg viewBox="0 0 48 48" className={className}><path d="M8 36 L6 14 L16 24 L24 10 L32 24 L42 14 L40 36 Z" fill="#F59E0B" /><rect x="8" y="36" width="32" height="5" rx="2" fill="#B45309" /></svg>;
    case 'star':
      return <svg viewBox="0 0 48 48" className={className}><path d="M24 4 L29 18 L44 18 L32 27 L36 42 L24 33 L12 42 L16 27 L4 18 L19 18 Z" fill="#FBBF24" /></svg>;
    case 'horseshoe':
      return <svg viewBox="0 0 48 48" className={className}><path d="M12 8 V24 A12 12 0 0 0 36 24 V8" stroke="#94A3B8" strokeWidth="7" fill="none" strokeLinecap="round" /><circle cx="12" cy="14" r="1.5" fill="#12213D" /><circle cx="36" cy="14" r="1.5" fill="#12213D" /></svg>;
    case 'clover':
      return <svg viewBox="0 0 48 48" className={className}><g fill="#22C55E"><circle cx="17" cy="17" r="8" /><circle cx="31" cy="17" r="8" /><circle cx="17" cy="30" r="8" /><circle cx="31" cy="30" r="8" /></g><path d="M24 26 Q26 38 32 44" stroke="#15803D" strokeWidth="3" fill="none" /></svg>;
    default:
      return <svg viewBox="0 0 48 48" className={className}><circle cx="24" cy="24" r="17" fill="#E2A85C" stroke="#B8792E" strokeWidth="3" /><text x="24" y="30" textAnchor="middle" fontSize="16" fontWeight="900" fill="#7C4A12">AW</text></svg>;
  }
};

export const Thumbnail: React.FC<{ className?: string }> = ({ className }) => (
  <svg viewBox="0 0 96 96" className={className} aria-hidden>
    <rect x="10" y="16" width="76" height="64" rx="8" fill="#fff" />
    <rect x="16" y="22" width="64" height="52" rx="5" fill="#E2A85C" />
    <path d="M18 60 Q40 30 60 52 T80 34" stroke="#fff" strokeWidth="10" strokeLinecap="round" fill="none" />
    <path d="M44 38 L48 30 L52 38 L60 39 L54 44 L56 52 L48 48 L40 52 L42 44 L36 39 Z" fill="#FBBF24" />
  </svg>
);
