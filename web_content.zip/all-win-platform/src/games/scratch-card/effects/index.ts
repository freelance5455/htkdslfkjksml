type Burst = (o: { x?: number; y?: number; rx?: number; ry?: number; count?: number; colors?: string[]; speed?: number; gravity?: number; shape?: 'circle' | 'square' | 'star'; size?: number; life?: number }) => void;

export const foilFlakes = (burst: Burst, x: number, y: number) =>
  burst({ x, y, count: 3, colors: ['#F1C27D', '#B8792E'], speed: 90, gravity: 600, size: 3, life: 0.5 });

export const prizeBurst = (burst: Burst) =>
  burst({ rx: 0.5, ry: 0.5, count: 80, colors: ['#C58937', '#FDE68A', '#01A879', '#ffffff'], speed: 360, gravity: 420, shape: 'star', size: 5 });
