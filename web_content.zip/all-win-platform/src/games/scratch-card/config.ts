import type { GameConfig } from '../framework/types.js';

export const config: GameConfig = {
  slug: 'scratch-card',
  name: 'Scratch Card',
  category: 'Instant Mini',
  badge: 'INSTANT WIN',
  tagline: 'Scratch the foil — match 3 to win.',
  description: 'Buy a card and scratch away the golden foil with your finger. Reveal three matching symbols to win that symbol\'s multiplier.',
  howToPlay: [
    'Choose a card price and tap Buy card.',
    'Scratch the foil with your finger or mouse.',
    'Find 3 identical symbols to win stake × that symbol\'s multiplier.',
    'Tap Reveal all to uncover the card instantly.',
  ],
  rtp: '≈94%',
  accent: '#C58937',
  minStake: 10,
  maxStake: 1000,
  defaultStake: 50,
};

export const AUTO_REVEAL_AT = 0.55;
export const BRUSH = 22;
