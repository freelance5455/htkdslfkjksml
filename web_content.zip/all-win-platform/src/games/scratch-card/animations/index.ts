/** Paints the golden foil coating (original pattern). */
export function paintFoil(ctx: CanvasRenderingContext2D, w: number, h: number) {
  ctx.globalCompositeOperation = 'source-over';
  ctx.globalAlpha = 1;
  const g = ctx.createLinearGradient(0, 0, w, h);
  g.addColorStop(0, '#B8792E');
  g.addColorStop(0.45, '#F1C27D');
  g.addColorStop(0.55, '#E2A85C');
  g.addColorStop(1, '#9C6424');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, w, h);
  ctx.fillStyle = 'rgba(255,255,255,0.12)';
  for (let y = -h; y < h * 2; y += 14) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(w, y + w * 0.4);
    ctx.lineTo(w, y + w * 0.4 + 5);
    ctx.lineTo(0, y + 5);
    ctx.fill();
  }
  ctx.fillStyle = 'rgba(18,33,61,0.75)';
  ctx.font = '900 18px Inter, sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('SCRATCH HERE', w / 2, h / 2 + 6);
  ctx.font = '700 11px Inter, sans-serif';
  ctx.fillText('match 3 symbols to win', w / 2, h / 2 + 24);
}

/** Erases a stroke segment from the foil. */
export function scratchLine(ctx: CanvasRenderingContext2D, x0: number, y0: number, x1: number, y1: number, r: number) {
  ctx.globalCompositeOperation = 'destination-out';
  ctx.lineCap = 'round';
  ctx.lineWidth = r * 2;
  ctx.beginPath();
  ctx.moveTo(x0, y0);
  ctx.lineTo(x1, y1);
  ctx.stroke();
  ctx.globalCompositeOperation = 'source-over';
}

/** Fraction of foil removed (sampled grid for speed). */
export function scratchedRatio(canvas: HTMLCanvasElement): number {
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  if (!ctx) return 0;
  const { width, height } = canvas;
  const data = ctx.getImageData(0, 0, width, height).data;
  let clear = 0, total = 0;
  const step = 12;
  for (let y = 0; y < height; y += step) {
    for (let x = 0; x < width; x += step) {
      total++;
      if (data[(y * width + x) * 4 + 3] < 40) clear++;
    }
  }
  return total ? clear / total : 0;
}
