import type { GameConfig } from '../framework/types.js';

export const config: GameConfig = {
  slug: 'limbo',
  name: 'Limbo',
  category: 'Originals',
  badge: 'NEW',
  tagline: 'Name your multiplier. Will the orb rise past it?',
  description: 'Set a target multiplier, then launch. An energy orb soars to a random multiplier — if it reaches or passes your target, you win stake × target.',
  howToPlay: [
    'Enter a target multiplier between 1.01× and 1000×.',
    'Higher targets pay more but are less likely.',
    'Set your stake and tap Launch.',
    'If the result ≥ target you win stake × target.',
  ],
  rtp: '99%',
  accent: '#A855F7',
  minStake: 10,
  maxStake: 5000,
  defaultStake: 100,
};

export const EDGE = 0.01;
export const LAUNCH_MS = 1300;
export const MIN_TARGET = 1.01;
export const MAX_TARGET = 1000;
