import type { Transitions } from '../framework/stateMachine.js';

/** IDLE → LAUNCHING → RESULT → LAUNCHING … */
export type Phase = 'IDLE' | 'LAUNCHING' | 'RESULT';
export const TRANSITIONS: Transitions<Phase> = {
  IDLE: ['LAUNCHING'],
  LAUNCHING: ['RESULT'],
  RESULT: ['LAUNCHING'],
};
