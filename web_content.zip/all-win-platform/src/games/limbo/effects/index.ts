type Burst = (o: { rx?: number; ry?: number; count?: number; colors?: string[]; speed?: number; gravity?: number; shape?: 'circle' | 'square' | 'star'; size?: number }) => void;

export const orbWin = (burst: Burst, ry: number) =>
  burst({ rx: 0.5, ry, count: 60, colors: ['#A855F7', '#E9D5FF', '#01A879', '#ffffff'], speed: 320, gravity: 200, shape: 'star', size: 5 });

export const orbFizzle = (burst: Burst, ry: number) =>
  burst({ rx: 0.5, ry, count: 20, colors: ['#64748B', '#A855F7'], speed: 110, gravity: 260, shape: 'circle', size: 4 });
