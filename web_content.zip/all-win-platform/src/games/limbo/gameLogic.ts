import { rng } from '../framework/session.js';
import { EDGE, MAX_TARGET, MIN_TARGET } from './config.js';

export const rollResult = () => {
  const m = Math.floor(((1 - EDGE) / (1 - rng.float())) * 100) / 100;
  return Math.max(1, Math.min(1_000_000, m));
};
export const winChance = (target: number) => ((1 - EDGE) / target) * 100;
export const clampTarget = (t: number) => Math.max(MIN_TARGET, Math.min(MAX_TARGET, Math.round(t * 100) / 100));
/** Gauge height (0..1) on a log scale up to 1000×. */
export const gauge = (m: number) => Math.min(1, Math.log(m) / Math.log(1000));
