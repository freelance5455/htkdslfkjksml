import type { SoundBank } from '../../framework/sound.js';

export const SOUNDS: SoundBank = {
  charge: [{ wave: 'sawtooth', freq: 120, to: 900, dur: 1200, gain: 0.07 }],
  win: [
    { wave: 'sine', freq: 880, dur: 120, gain: 0.22 },
    { wave: 'sine', freq: 1320, dur: 260, at: 100, gain: 0.22 },
  ],
  lose: [{ wave: 'triangle', freq: 300, to: 90, dur: 400, gain: 0.18 }],
};
