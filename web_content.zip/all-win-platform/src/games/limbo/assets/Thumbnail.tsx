import React from 'react';

export const Thumbnail: React.FC<{ className?: string }> = ({ className }) => (
  <svg viewBox="0 0 96 96" className={className} aria-hidden>
    <defs>
      <radialGradient id="lb-orb"><stop offset="0" stopColor="#fff" /><stop offset=".5" stopColor="#C084FC" /><stop offset="1" stopColor="#7E22CE" /></radialGradient>
    </defs>
    <path d="M48 88 V40" stroke="#A855F7" strokeOpacity=".5" strokeWidth="6" strokeLinecap="round" />
    <circle cx="48" cy="30" r="16" fill="url(#lb-orb)" />
    <path d="M20 50 H76" stroke="#E2A85C" strokeDasharray="5 4" strokeWidth="2" />
    <text x="62" y="46" fontSize="11" fontWeight="900" fill="#E2A85C">2×</text>
  </svg>
);
