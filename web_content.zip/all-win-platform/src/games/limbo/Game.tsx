import React, { useState } from 'react';
import {
  GameShell, GameStage, StakeControl, ActionButton, EffectsLayer,
  useScheduler, usePhaseMachine, useGameSession, useGameSound, useParticleLayer, fmtCredits,
} from '../framework/index.js';
import { config, LAUNCH_MS } from './config.js';
import { TRANSITIONS, Phase } from './gameState.js';
import { rollResult, winChance, clampTarget, gauge } from './gameLogic.js';
import { SOUNDS } from './sounds/index.js';
import { animateLaunch } from './animations/index.js';
import { orbWin, orbFizzle } from './effects/index.js';

export default function LimboGame() {
  const session = useGameSession(config);
  const sched = useScheduler();
  const sound = useGameSound(SOUNDS);
  const fsm = usePhaseMachine<Phase>('IDLE', TRANSITIONS);
  const { canvasRef, burst } = useParticleLayer(sched);

  const [stake, setStake] = useState(config.defaultStake);
  const [target, setTarget] = useState(2);
  const [targetText, setTargetText] = useState('2.00');
  const [shown, setShown] = useState(1);
  const [height, setHeight] = useState(0);
  const [last, setLast] = useState<{ win: boolean; value: number; payout: number } | null>(null);
  const [recent, setRecent] = useState<{ v: number; win: boolean }[]>([]);

  const commitTarget = (t: number) => {
    const c = clampTarget(t);
    setTarget(c);
    setTargetText(c.toFixed(2));
  };

  const launch = async () => {
    sound.unlock();
    if (fsm.is('LAUNCHING')) return;
    const r = session.beginRound(stake);
    if (!r) return;
    fsm.go('LAUNCHING');
    setLast(null);
    sound.play('charge');
    const value = rollResult();
    await animateLaunch(sched, value, LAUNCH_MS, (m) => {
      setShown(m);
      setHeight(gauge(m));
    });
    const win = value >= target;
    const payout = win ? Math.floor(stake * target * 100) / 100 : 0;
    session.settleRound(r, payout, `Result ${value.toFixed(2)}× vs target ${target.toFixed(2)}×`);
    setLast({ win, value, payout });
    setRecent((x) => [{ v: value, win }, ...x].slice(0, 10));
    sound.play(win ? 'win' : 'lose');
    (win ? orbWin : orbFizzle)(burst, 0.85 - gauge(value) * 0.7);
    fsm.go('RESULT');
  };

  const launching = fsm.phase === 'LAUNCHING';
  const color = last ? (last.win ? '#01A879' : '#E92844') : '#ffffff';

  return (
    <GameShell
      config={config}
      credits={session.credits}
      busy={launching}
      status={launching ? 'Launching…' : last ? (last.win ? 'Win' : 'Loss') : 'Ready'}
      stage={
        <GameStage accent={config.accent} className="bg-gradient-to-b from-[#1E0F3A] to-[#12213D]">
          <EffectsLayer ref={canvasRef} />
          <div className="absolute inset-x-0 top-2 flex gap-1.5 justify-center">
            {recent.map((r, i) => (
              <span key={i} className={`px-2 py-0.5 rounded text-[10px] font-black anim-pop ${r.win ? 'bg-[#01A879]/20 text-[#01A879]' : 'bg-[#E92844]/20 text-[#E92844]'}`}>{r.v.toFixed(2)}×</span>
            ))}
          </div>
          {/* target line */}
          <div className="absolute inset-x-6 border-t-2 border-dashed border-[#E2A85C]" style={{ bottom: `${12 + gauge(target) * 70}%` }}>
            <span className="absolute right-0 -top-5 text-[10px] font-black text-[#E2A85C]">TARGET {target.toFixed(2)}×</span>
          </div>
          {/* orb + trail */}
          <div className="absolute left-1/2 -translate-x-1/2 w-2 rounded-full bg-gradient-to-t from-transparent to-[#A855F7]/70" style={{ bottom: '10%', height: `${height * 70}%` }} />
          <div
            className="absolute left-1/2 -translate-x-1/2 w-14 h-14 rounded-full"
            style={{
              bottom: `calc(${8 + height * 70}%)`,
              background: 'radial-gradient(circle at 35% 35%, #fff, #C084FC 45%, #7E22CE)',
              boxShadow: `0 0 ${20 + height * 40}px ${last ? color : '#A855F7'}`,
            }}
          />
          <div className="absolute inset-x-0 top-1/3 text-center pointer-events-none">
            <div data-testid="limbo-value" className={`text-6xl font-black tabular drop-shadow-xl ${last ? 'anim-pop' : ''}`} style={{ color }} key={recent.length}>
              {shown.toFixed(2)}×
            </div>
            {last && (
              <p className="mt-1 text-sm font-black anim-slide-up" style={{ color }} data-testid="result">
                {last.win ? `+${fmtCredits(last.payout)} credits` : `Missed ${target.toFixed(2)}×`}
              </p>
            )}
          </div>
        </GameStage>
      }
      controls={
        <>
          <div className="grid grid-cols-2 gap-2">
            <label className="bg-[#1A2C4E] border border-[#243A66] rounded-xl px-3 py-1.5">
              <span className="text-[9px] uppercase font-bold text-slate-400">Target multiplier</span>
              <input
                aria-label="Target multiplier"
                inputMode="decimal"
                value={targetText}
                disabled={launching}
                onChange={(e) => setTargetText(e.target.value)}
                onBlur={() => commitTarget(parseFloat(targetText) || 2)}
                className="w-full bg-transparent text-base font-black outline-none"
              />
            </label>
            <div className="bg-[#1A2C4E] border border-[#243A66] rounded-xl px-3 py-1.5">
              <span className="text-[9px] uppercase font-bold text-slate-400">Win chance</span>
              <p className="text-base font-black">{winChance(target).toFixed(2)}%</p>
            </div>
          </div>
          <div className="grid grid-cols-5 gap-1.5">
            {[1.5, 2, 5, 10, 100].map((t) => (
              <button key={t} disabled={launching} onClick={() => commitTarget(t)}
                className={`h-9 rounded-lg text-xs font-bold border ${target === t ? 'border-[#A855F7] text-[#C084FC]' : 'border-[#243A66] text-slate-300'} bg-[#1A2C4E]`}>
                {t}×
              </button>
            ))}
          </div>
          <StakeControl value={stake} onChange={setStake} min={config.minStake} max={config.maxStake} credits={session.credits} disabled={launching} />
          <ActionButton onClick={launch} disabled={launching || stake > session.credits}>
            {launching ? 'Launching…' : stake > session.credits ? 'Not enough credits' : `Launch · win ${fmtCredits(Math.floor(stake * target * 100) / 100)}`}
          </ActionButton>
        </>
      }
    />
  );
}
