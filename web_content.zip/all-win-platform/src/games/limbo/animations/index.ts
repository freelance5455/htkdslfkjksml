import type { Scheduler } from '../../framework/scheduler.js';
import { easeOutCubic } from '../../framework/animation.js';

/** Counts the multiplier from 1.00× up to `final` on a log curve while the orb rises. */
export const animateLaunch = (s: Scheduler, final: number, ms: number, onFrame: (m: number, p: number) => void) =>
  s.tween(ms, (p) => onFrame(Math.exp(Math.log(final) * p), p), easeOutCubic);
