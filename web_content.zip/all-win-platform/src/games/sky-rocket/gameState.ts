import type { Transitions } from '../framework/stateMachine.js';
import type { RoundHandle } from '../framework/session.js';

/**
 * READY → BETTING (countdown) → FLYING (multiplier rising) → CRASHED → BETTING …
 */
export type Phase = 'READY' | 'BETTING' | 'FLYING' | 'CRASHED';

export const TRANSITIONS: Transitions<Phase> = {
  READY: ['BETTING'],
  BETTING: ['FLYING'],
  FLYING: ['CRASHED'],
  CRASHED: ['BETTING'],
};

export type BetStatus = 'none' | 'queued' | 'live' | 'cashed' | 'lost';

export interface BetState {
  status: BetStatus;
  stake: number;
  round?: RoundHandle;
  cashedAt?: number;
}

/** Mutable per-round flight data read by the render loop. */
export interface Flight {
  t: number;
  multiplier: number;
  crashPoint: number;
  crashedAt: number;
}

export const newFlight = (): Flight => ({ t: 0, multiplier: 1, crashPoint: 1, crashedAt: 0 });
