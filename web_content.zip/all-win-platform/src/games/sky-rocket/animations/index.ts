import { multiplierAt } from '../gameLogic.js';
import type { Flight, Phase } from '../gameState.js';

export interface Star { x: number; y: number; r: number; s: number }

export const createStars = (n = 70): Star[] =>
  Array.from({ length: n }, () => ({ x: Math.random(), y: Math.random(), r: Math.random() * 1.4 + 0.3, s: Math.random() * 0.6 + 0.2 }));

const PAD = 28;

/** Maps flight time / multiplier to canvas coordinates with auto-zooming axes. */
export const projector = (w: number, h: number, t: number, m: number) => {
  const tMax = Math.max(8, t * 1.15);
  const mMax = Math.max(2, m * 1.25);
  return {
    x: (tt: number) => PAD + ((w - PAD * 1.6) * tt) / tMax,
    y: (mm: number) => h - PAD - ((h - PAD * 2.2) * (mm - 1)) / (mMax - 1),
    tMax,
    mMax,
  };
};

export function drawBackground(ctx: CanvasRenderingContext2D, w: number, h: number, stars: Star[], speed: number, dt: number) {
  const g = ctx.createLinearGradient(0, 0, 0, h);
  g.addColorStop(0, '#0B1430');
  g.addColorStop(1, '#12213D');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, w, h);
  ctx.fillStyle = '#ffffff';
  for (const s of stars) {
    s.x -= s.s * speed * dt * 0.08;
    s.y += s.s * speed * dt * 0.05;
    if (s.x < 0) s.x += 1;
    if (s.y > 1) s.y -= 1;
    ctx.globalAlpha = 0.3 + s.s * 0.6;
    ctx.beginPath();
    ctx.arc(s.x * w, s.y * h, s.r, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.globalAlpha = 1;
}

export function drawAxes(ctx: CanvasRenderingContext2D, w: number, h: number, proj: ReturnType<typeof projector>) {
  ctx.strokeStyle = 'rgba(36,58,102,0.8)';
  ctx.lineWidth = 1;
  ctx.font = '10px Inter, sans-serif';
  ctx.fillStyle = '#64748B';
  const steps = [1.5, 2, 3, 5, 10, 20, 50, 100, 200, 500];
  for (const m of steps) {
    if (m > proj.mMax) break;
    const y = proj.y(m);
    ctx.beginPath();
    ctx.moveTo(PAD, y);
    ctx.lineTo(w - 8, y);
    ctx.stroke();
    ctx.fillText(`${m}×`, 4, y + 3);
  }
  ctx.beginPath();
  ctx.moveTo(PAD, h - PAD);
  ctx.lineTo(w - 8, h - PAD);
  ctx.stroke();
}

/** Draws the multiplier curve and returns the rocket's tip position + heading. */
export function drawCurve(ctx: CanvasRenderingContext2D, proj: ReturnType<typeof projector>, t: number, color: string) {
  const N = 60;
  ctx.beginPath();
  let px = proj.x(0), py = proj.y(1), ang = 0;
  ctx.moveTo(px, py);
  for (let i = 1; i <= N; i++) {
    const tt = (t * i) / N;
    const x = proj.x(tt), y = proj.y(multiplierAt(tt));
    ang = Math.atan2(y - py, x - px);
    ctx.lineTo(x, y);
    px = x; py = y;
  }
  ctx.strokeStyle = color;
  ctx.lineWidth = 4;
  ctx.lineCap = 'round';
  ctx.shadowColor = color;
  ctx.shadowBlur = 12;
  ctx.stroke();
  ctx.shadowBlur = 0;
  // fill under curve
  ctx.lineTo(px, proj.y(1));
  ctx.lineTo(proj.x(0), proj.y(1));
  ctx.closePath();
  ctx.fillStyle = `${color}22`;
  ctx.fill();
  return { x: px, y: py, angle: t > 0.05 ? ang : -0.3 };
}

/** Original rocket artwork drawn with canvas paths. */
export function drawRocket(ctx: CanvasRenderingContext2D, x: number, y: number, angle: number, time: number, scale = 1) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(angle);
  ctx.scale(scale, scale);
  // flame
  const fl = 14 + Math.sin(time * 40) * 4 + Math.random() * 3;
  const fg = ctx.createLinearGradient(-22 - fl, 0, -18, 0);
  fg.addColorStop(0, 'rgba(255,122,61,0)');
  fg.addColorStop(1, '#FFE08A');
  ctx.fillStyle = fg;
  ctx.beginPath();
  ctx.moveTo(-18, -5);
  ctx.quadraticCurveTo(-22 - fl, 0, -18, 5);
  ctx.fill();
  // fins
  ctx.fillStyle = '#E92844';
  ctx.beginPath();
  ctx.moveTo(-14, -6); ctx.lineTo(-22, -14); ctx.lineTo(-8, -7); ctx.fill();
  ctx.beginPath();
  ctx.moveTo(-14, 6); ctx.lineTo(-22, 14); ctx.lineTo(-8, 7); ctx.fill();
  // body
  const bg = ctx.createLinearGradient(0, -8, 0, 8);
  bg.addColorStop(0, '#ffffff');
  bg.addColorStop(1, '#C9D3E3');
  ctx.fillStyle = bg;
  ctx.beginPath();
  ctx.moveTo(18, 0);
  ctx.quadraticCurveTo(8, -9, -18, -7);
  ctx.lineTo(-18, 7);
  ctx.quadraticCurveTo(8, 9, 18, 0);
  ctx.fill();
  // nose
  ctx.fillStyle = '#C58937';
  ctx.beginPath();
  ctx.moveTo(18, 0);
  ctx.quadraticCurveTo(13, -5, 9, -6);
  ctx.lineTo(9, 6);
  ctx.quadraticCurveTo(13, 5, 18, 0);
  ctx.fill();
  // window
  ctx.fillStyle = '#12213D';
  ctx.beginPath();
  ctx.arc(1, 0, 3.6, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = '#C58937';
  ctx.lineWidth = 1.2;
  ctx.stroke();
  ctx.restore();
}

export const engineSpeed = (phase: Phase, f: Flight) => (phase === 'FLYING' ? 1 + Math.min(8, f.multiplier) : 0.4);
