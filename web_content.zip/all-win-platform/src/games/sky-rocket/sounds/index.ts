import type { SoundBank } from '../../framework/sound.js';

/** Original synthesized sound assets for Sky Rocket. */
export const SOUNDS: SoundBank = {
  tick: [{ wave: 'square', freq: 660, dur: 60, gain: 0.08 }],
  bet: [
    { wave: 'triangle', freq: 440, dur: 80, gain: 0.15 },
    { wave: 'triangle', freq: 660, dur: 100, at: 70, gain: 0.15 },
  ],
  launch: [
    { wave: 'noise', freq: 400, to: 3000, dur: 700, gain: 0.25 },
    { wave: 'sawtooth', freq: 90, to: 220, dur: 700, gain: 0.08 },
  ],
  cashout: [
    { wave: 'sine', freq: 784, dur: 120, gain: 0.25 },
    { wave: 'sine', freq: 988, dur: 120, at: 90, gain: 0.25 },
    { wave: 'sine', freq: 1319, dur: 260, at: 180, gain: 0.25 },
  ],
  explode: [
    { wave: 'noise', freq: 2200, to: 120, dur: 900, gain: 0.5 },
    { wave: 'sine', freq: 120, to: 40, dur: 600, gain: 0.4 },
  ],
};

export const ENGINE_LOOP = { id: 'engine', freq: 70, wave: 'sawtooth' as OscillatorType, gain: 0.035 };
