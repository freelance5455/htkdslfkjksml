import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  GameShell, GameStage, StakeControl, ActionButton, ResultBanner, ResultInfo, CountdownRing,
  useScheduler, usePhaseMachine, useGameSession, useGameSound, useCanvas, ParticleSystem, fmtCredits,
} from '../framework/index.js';
import { config, TUNING } from './config.js';
import { TRANSITIONS, Phase, BetState, newFlight } from './gameState.js';
import { rollCrashPoint, multiplierAt, payoutFor, crashColor } from './gameLogic.js';
import { SOUNDS, ENGINE_LOOP } from './sounds/index.js';
import { createStars, drawBackground, drawAxes, drawCurve, drawRocket, projector, engineSpeed } from './animations/index.js';
import { explosion, cashoutSparks, exhaust } from './effects/index.js';

export default function SkyRocketGame() {
  const session = useGameSession(config);
  const sched = useScheduler();
  const sound = useGameSound(SOUNDS);
  const fsm = usePhaseMachine<Phase>('READY', TRANSITIONS);
  const { canvasRef, size, ctx } = useCanvas();

  const [stake, setStake] = useState(config.defaultStake);
  const [autoOn, setAutoOn] = useState(false);
  const [autoAt, setAutoAt] = useState(2);
  const [bet, setBetState] = useState<BetState>({ status: 'none', stake: 0 });
  const [countdown, setCountdown] = useState(0);
  const [recent, setRecent] = useState<number[]>([]);
  const [result, setResult] = useState<ResultInfo | null>(null);

  const betRef = useRef(bet);
  const setBet = (b: BetState) => { betRef.current = b; setBetState(b); };
  const autoRef = useRef({ on: autoOn, at: autoAt });
  autoRef.current = { on: autoOn, at: autoAt };

  const flight = useRef(newFlight());
  const stars = useRef(createStars());
  const fx = useRef(new ParticleSystem());
  const multEl = useRef<HTMLDivElement>(null);
  const tip = useRef({ x: 0, y: 0, angle: 0 });

  /* ---------------- lifecycle ---------------- */
  const startBetting = useCallback(() => {
    if (!fsm.go('BETTING')) return;
    setResult(null);
    flight.current = newFlight();
    const b = betRef.current;
    if (b.status === 'cashed' || b.status === 'lost') setBet({ status: 'none', stake: 0 });
    let remaining = TUNING.bettingSeconds;
    let lastWhole = Math.ceil(remaining);
    setCountdown(remaining);
    sched.loop((dt) => {
      remaining -= dt;
      setCountdown(Math.max(0, remaining));
      if (Math.ceil(remaining) !== lastWhole) {
        lastWhole = Math.ceil(remaining);
        if (lastWhole > 0) sound.play('tick');
      }
      if (remaining <= 0) {
        launch();
        return false;
      }
    });
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const launch = () => {
    const b = betRef.current;
    if (b.status === 'queued') {
      const round = session.beginRound(b.stake);
      setBet(round ? { status: 'live', stake: b.stake, round } : { status: 'none', stake: 0 });
    }
    flight.current = { t: 0, multiplier: 1, crashPoint: rollCrashPoint(), crashedAt: 0 };
    fsm.go('FLYING');
    sound.play('launch');
    sound.startLoop(ENGINE_LOOP.id, ENGINE_LOOP.freq, ENGINE_LOOP.wave, ENGINE_LOOP.gain);
  };

  const cashOut = (at?: number) => {
    const b = betRef.current;
    if (fsm.current() !== 'FLYING' || b.status !== 'live' || !b.round) return;
    const m = at ?? flight.current.multiplier;
    const payout = payoutFor(b.stake, m);
    session.settleRound(b.round, payout, `Cashed out at ${m.toFixed(2)}×`);
    setBet({ ...b, status: 'cashed', cashedAt: m });
    sound.play('cashout');
    cashoutSparks(fx.current, tip.current.x, tip.current.y);
  };

  const crash = () => {
    const f = flight.current;
    f.multiplier = f.crashPoint;
    f.crashedAt = performance.now();
    fsm.go('CRASHED');
    sound.stopLoop(ENGINE_LOOP.id);
    sound.play('explode');
    explosion(fx.current, tip.current.x, tip.current.y);
    setRecent((r) => [f.crashPoint, ...r].slice(0, 12));
    const b = betRef.current;
    if (b.status === 'live' && b.round) {
      session.settleRound(b.round, 0, `Exploded at ${f.crashPoint.toFixed(2)}×`);
      setBet({ ...b, status: 'lost' });
      setResult({ outcome: 'lose', title: `Blasted at ${f.crashPoint.toFixed(2)}×`, payout: 0 });
    } else if (b.status === 'cashed') {
      const payout = payoutFor(b.stake, b.cashedAt!);
      setResult({ outcome: 'win', title: 'Cashed out!', multiplier: b.cashedAt, payout, note: `Rocket reached ${f.crashPoint.toFixed(2)}×` });
    }
    sched.timeout(() => fsm.current() === 'CRASHED' && startBetting(), TUNING.crashedPauseMs);
  };

  /* ---------------- render loop (whole mount) ---------------- */
  useEffect(() => {
    let time = 0;
    const stop = sched.loop((dt) => {
      time += dt;
      const c = ctx();
      const { w, h } = size.current;
      if (!c || !w) return;
      const phase = fsm.current();
      const f = flight.current;
      if (phase === 'FLYING') {
        f.t += dt;
        f.multiplier = multiplierAt(f.t);
        const b = betRef.current;
        if (autoRef.current.on && b.status === 'live' && f.multiplier >= autoRef.current.at && autoRef.current.at < f.crashPoint) cashOut(autoRef.current.at);
        if (f.multiplier >= f.crashPoint) crash();
        sound.setLoopPitch(ENGINE_LOOP.id, 1 + Math.log(f.multiplier));
      }
      drawBackground(c, w, h, stars.current, engineSpeed(phase, f), dt);
      const showFlight = phase === 'FLYING' || phase === 'CRASHED';
      const proj = projector(w, h, showFlight ? f.t : 0, showFlight ? f.multiplier : 1);
      drawAxes(c, w, h, proj);
      if (showFlight) {
        const color = phase === 'CRASHED' ? '#E92844' : '#C58937';
        tip.current = drawCurve(c, proj, f.t, color);
        if (phase === 'FLYING') {
          exhaust(fx.current, tip.current.x, tip.current.y, tip.current.angle);
          drawRocket(c, tip.current.x, tip.current.y, tip.current.angle, time, 1.1);
        }
      } else {
        // idle rocket bobbing on the launch pad
        const x = proj.x(0) + 26, y = proj.y(1) - 16 + Math.sin(time * 3) * 3;
        tip.current = { x, y, angle: -Math.PI / 2 };
        drawRocket(c, x, y, -Math.PI / 2, time, 1.1);
      }
      fx.current.update(dt);
      fx.current.draw(c);
      if (multEl.current) {
        multEl.current.textContent = `${f.multiplier.toFixed(2)}×`;
        multEl.current.style.color = phase === 'CRASHED' ? '#E92844' : betRef.current.status === 'cashed' ? '#01A879' : '#ffffff';
      }
    });
    return stop;
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  /* ---------------- UI ---------------- */
  const phase = fsm.phase;
  const placeBet = () => {
    sound.unlock();
    if (stake > session.credits) return;
    sound.play('bet');
    setBet({ status: 'queued', stake });
  };

  let action: React.ReactNode;
  if (phase === 'READY') {
    action = <ActionButton onClick={() => { sound.unlock(); startBetting(); }}>Start</ActionButton>;
  } else if (phase === 'BETTING') {
    action = bet.status === 'queued'
      ? <ActionButton tone="navy" onClick={() => setBet({ status: 'none', stake: 0 })}>Cancel bet ({fmtCredits(bet.stake)})</ActionButton>
      : <ActionButton disabled={stake > session.credits} onClick={placeBet}>{stake > session.credits ? 'Not enough credits' : `Place bet ${fmtCredits(stake)}`}</ActionButton>;
  } else if (phase === 'FLYING') {
    action = bet.status === 'live'
      ? <ActionButton tone="green" onClick={() => cashOut()}>Cash out</ActionButton>
      : <ActionButton tone="navy" disabled>{bet.status === 'cashed' ? `Cashed at ${bet.cashedAt?.toFixed(2)}×` : 'Waiting for next round'}</ActionButton>;
  } else {
    action = <ActionButton tone="navy" disabled>Next round starting…</ActionButton>;
  }

  return (
    <GameShell
      config={config}
      credits={session.credits}
      busy={bet.status === 'live'}
      status={phase === 'BETTING' ? 'Place your bets' : phase === 'FLYING' ? 'In flight' : phase === 'CRASHED' ? 'Blasted' : 'Ready'}
      stage={
        <div className="flex flex-col gap-2 flex-1">
          <div className="flex gap-1.5 overflow-x-auto scrollbar-none min-h-[26px]">
            {recent.length === 0 && <span className="text-[10px] text-slate-500 py-1">No rounds yet this session</span>}
            {recent.map((m, i) => (
              <span key={i} className="px-2 py-1 rounded-md text-[10px] font-black bg-[#1A2C4E] anim-pop" style={{ color: crashColor(m) }}>{m.toFixed(2)}×</span>
            ))}
          </div>
          <GameStage accent={config.accent}>
            <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" />
            <div className="absolute inset-x-0 top-6 flex flex-col items-center pointer-events-none">
              {phase === 'BETTING' ? (
                <CountdownRing remaining={countdown} total={TUNING.bettingSeconds} label="Lift-off in" />
              ) : (
                <div ref={multEl} data-testid="multiplier" className="text-5xl font-black tabular drop-shadow-lg">1.00×</div>
              )}
              {phase === 'READY' && <p className="text-xs text-slate-300 mt-2">Tap Start to begin the rounds</p>}
              {bet.status === 'cashed' && phase === 'FLYING' && (
                <p className="mt-2 px-3 py-1 rounded-full bg-[#01A879] text-xs font-black anim-pop">+{fmtCredits(payoutFor(bet.stake, bet.cashedAt!))}</p>
              )}
            </div>
            <ResultBanner result={result} onReplay={() => { setResult(null); }} replayLabel="Continue" />
          </GameStage>
        </div>
      }
      controls={
        <>
          <StakeControl value={stake} onChange={setStake} min={config.minStake} max={config.maxStake} credits={session.credits}
            disabled={bet.status === 'queued' || bet.status === 'live'} />
          <div className="flex items-center gap-2">
            <button
              onClick={() => setAutoOn(!autoOn)}
              className={`h-10 px-3 rounded-xl text-xs font-bold border ${autoOn ? 'border-[#01A879] text-[#01A879] bg-[#01A879]/10' : 'border-[#243A66] text-slate-300 bg-[#1A2C4E]'}`}
            >
              Auto cash-out {autoOn ? 'ON' : 'OFF'}
            </button>
            <div className="flex-1 flex items-center bg-[#1A2C4E] border border-[#243A66] rounded-xl h-10">
              <button className="px-3 h-full font-black" onClick={() => setAutoAt(Math.max(1.1, +(autoAt - 0.5).toFixed(2)))}>−</button>
              <span className="flex-1 text-center text-xs font-extrabold">{autoAt.toFixed(2)}×</span>
              <button className="px-3 h-full font-black" onClick={() => setAutoAt(Math.min(100, +(autoAt + 0.5).toFixed(2)))}>+</button>
            </div>
          </div>
          {action}
        </>
      }
    />
  );
}
