import React from 'react';

/** Original artwork: rocket on a rising curve. */
export const Thumbnail: React.FC<{ className?: string }> = ({ className }) => (
  <svg viewBox="0 0 96 96" className={className} aria-hidden>
    <defs>
      <linearGradient id="sr-g" x1="0" y1="1" x2="1" y2="0">
        <stop offset="0" stopColor="#C58937" />
        <stop offset="1" stopColor="#FFE08A" />
      </linearGradient>
    </defs>
    <path d="M10 84 Q50 80 78 22" stroke="url(#sr-g)" strokeWidth="5" fill="none" strokeLinecap="round" />
    <g transform="translate(74 24) rotate(-60)">
      <path d="M-14 -4 Q-24 0 -14 4 Z" fill="#FFB347" />
      <path d="M14 0 Q6 -7 -14 -6 L-14 6 Q6 7 14 0 Z" fill="#fff" />
      <path d="M-10 -5 L-17 -12 L-5 -6 Z M-10 5 L-17 12 L-5 6 Z" fill="#E92844" />
      <circle cx="1" cy="0" r="3" fill="#12213D" stroke="#C58937" />
    </g>
    <text x="14" y="30" fontSize="16" fontWeight="900" fill="#fff">2.4×</text>
  </svg>
);
