import { rng } from '../framework/session.js';
import { TUNING } from './config.js';

/** Crash point with a fixed house edge: P(crash ≥ m) = (1 - edge) / m. */
export const rollCrashPoint = (): number => {
  const r = rng.float();
  if (r < TUNING.houseEdge) return 1;
  const m = Math.floor((100 * (1 - TUNING.houseEdge)) / (1 - r)) / 100;
  return Math.min(TUNING.maxMultiplier, Math.max(1, m));
};

export const multiplierAt = (seconds: number) => Math.exp(TUNING.growth * seconds);
export const timeFor = (multiplier: number) => Math.log(multiplier) / TUNING.growth;

export const payoutFor = (stake: number, multiplier: number) => Math.floor(stake * multiplier * 100) / 100;

export const crashColor = (m: number) => (m < 2 ? '#E92844' : m < 10 ? '#C58937' : '#01A879');
