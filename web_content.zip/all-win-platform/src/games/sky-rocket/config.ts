import type { GameConfig } from '../framework/types.js';

export const config: GameConfig = {
  slug: 'sky-rocket',
  name: 'Sky Rocket',
  category: 'Crash',
  badge: 'LIVE ROUNDS',
  tagline: 'Ride the rising multiplier — cash out before it blasts.',
  description:
    'A rocket lifts off every round and its multiplier climbs faster and faster. Cash out at any moment to lock in stake × multiplier. If the rocket explodes before you cash out, the stake is lost.',
  howToPlay: [
    'Tap Start to begin the round cycle.',
    'During the countdown, choose a stake and tap Place Bet.',
    'Watch the multiplier rise after lift-off.',
    'Tap Cash Out to lock in your multiplier — or set Auto Cash-out.',
    'If the rocket explodes first, the stake is lost. A new round starts automatically.',
  ],
  rtp: '97%',
  accent: '#E2A85C',
  minStake: 10,
  maxStake: 5000,
  defaultStake: 100,
};

export const TUNING = {
  bettingSeconds: 5,
  crashedPauseMs: 3200,
  /** Growth rate k in m(t) = e^(k·t). */
  growth: 0.12,
  houseEdge: 0.03,
  maxMultiplier: 1000,
};
