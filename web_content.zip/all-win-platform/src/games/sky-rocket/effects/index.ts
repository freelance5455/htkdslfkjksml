import type { ParticleSystem } from '../../framework/particles.js';

export const explosion = (p: ParticleSystem, x: number, y: number) => {
  p.burst({ x, y, count: 70, colors: ['#FFB347', '#E92844', '#FFE08A', '#ffffff'], speed: 340, gravity: 120, life: 1.2, shape: 'circle', size: 6 });
  p.burst({ x, y, count: 30, colors: ['#64748B', '#94A3B8'], speed: 120, gravity: -40, life: 1.6, shape: 'circle', size: 10 });
};

export const cashoutSparks = (p: ParticleSystem, x: number, y: number) => {
  p.burst({ x, y, count: 40, colors: ['#01A879', '#C58937', '#ffffff'], speed: 260, gravity: 300, shape: 'star', size: 5 });
};

export const exhaust = (p: ParticleSystem, x: number, y: number, angle: number) => {
  p.burst({ x, y, count: 2, colors: ['#FFB347', '#FF7A3D', '#FFE08A'], speed: 90, gravity: 0, life: 0.45, spread: 0.6, angle: angle + Math.PI, shape: 'circle', size: 5 });
};
