import React, { ReactNode, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Volume2, VolumeX, HelpCircle, Coins } from 'lucide-react';
import { Modal } from '../../../components/common/Modal.js';
import { Button } from '../../../components/common/Button.js';
import { soundSettings, useSoundSettings } from '../sound.js';
import { fmtCredits } from '../session.js';
import type { GameConfig } from '../types.js';

interface GameShellProps {
  config: GameConfig;
  credits: number;
  /** When true, leaving asks for confirmation (round in progress). */
  busy?: boolean;
  /** Status chip shown in the credits bar (e.g. current phase). */
  status?: ReactNode;
  stage: ReactNode;
  controls: ReactNode;
}

/**
 * Common chrome for every game: back/exit flow, title, sound toggle,
 * how-to-play modal, credits bar, stage area and control dock.
 */
export const GameShell: React.FC<GameShellProps> = ({ config, credits, busy, status, stage, controls }) => {
  const navigate = useNavigate();
  const sound = useSoundSettings();
  const [exitOpen, setExitOpen] = useState(false);
  const [helpOpen, setHelpOpen] = useState(false);

  const leave = () => navigate(`/game/${config.slug}`);

  return (
    <div className="min-h-[100dvh] bg-[#0B0E14] text-white flex flex-col max-w-lg mx-auto anim-fade-in" data-game={config.slug}>
      <header className="flex items-center justify-between px-3 py-2.5 bg-[#12213D] border-b border-[#243A66] sticky top-0 z-30">
        <button
          aria-label="Leave game"
          onClick={() => (busy ? setExitOpen(true) : leave())}
          className="w-10 h-10 rounded-xl bg-[#1A2C4E] border border-[#243A66] text-slate-300 hover:text-white flex items-center justify-center"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div className="text-center min-w-0">
          <h1 className="text-sm font-black uppercase tracking-wider truncate">{config.name}</h1>
          <p className="text-[10px] font-bold" style={{ color: config.accent }}>{config.category} · Play credits</p>
        </div>
        <div className="flex items-center gap-1.5">
          <button
            aria-label="How to play"
            onClick={() => setHelpOpen(true)}
            className="w-10 h-10 rounded-xl bg-[#1A2C4E] border border-[#243A66] text-slate-300 hover:text-white flex items-center justify-center"
          >
            <HelpCircle className="w-4 h-4" />
          </button>
          <button
            aria-label={sound.muted ? 'Unmute' : 'Mute'}
            onClick={() => soundSettings.toggle()}
            className="w-10 h-10 rounded-xl bg-[#1A2C4E] border border-[#243A66] text-slate-300 hover:text-white flex items-center justify-center"
          >
            {sound.muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-[#C58937]" />}
          </button>
        </div>
      </header>

      <div className="px-4 py-2 bg-[#152542] border-b border-[#243A66] flex items-center justify-between text-xs">
        <span className="flex items-center gap-1.5 text-slate-400 font-medium">
          <Coins className="w-3.5 h-3.5 text-[#C58937]" /> Credits
          <span className="font-extrabold text-[#01A879] text-sm" data-testid="credits">{fmtCredits(credits)}</span>
        </span>
        <span className="text-[10px] font-bold uppercase tracking-wider text-slate-300">{status}</span>
      </div>

      <div className="flex-1 p-3 flex flex-col">{stage}</div>

      <div className="p-3 bg-[#12213D] border-t border-[#243A66] space-y-3 safe-area-bottom">{controls}</div>

      <Modal isOpen={exitOpen} onClose={() => setExitOpen(false)} title="Leave Game?">
        <div className="space-y-5 pt-2">
          <p className="text-sm text-slate-200">A round is in progress. Leaving now forfeits the current stake.</p>
          <div className="grid grid-cols-2 gap-3">
            <Button variant="neutral" onClick={() => setExitOpen(false)} className="py-2.5 text-xs">Stay</Button>
            <Button variant="destructive" onClick={leave} className="py-2.5 text-xs">Leave</Button>
          </div>
        </div>
      </Modal>

      <Modal isOpen={helpOpen} onClose={() => setHelpOpen(false)} title={`How to play ${config.name}`}>
        <ol className="text-left space-y-2 text-xs text-slate-300 list-decimal pl-4">
          {config.howToPlay.map((s) => <li key={s}>{s}</li>)}
        </ol>
        <p className="mt-4 text-[10px] text-slate-500 text-left">Play credits have no cash value. RTP {config.rtp}.</p>
        <Button fullWidth className="mt-4 py-2.5 text-xs" onClick={() => setHelpOpen(false)}>Got it</Button>
      </Modal>
    </div>
  );
};
