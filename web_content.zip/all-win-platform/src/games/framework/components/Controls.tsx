import React from 'react';
import { fmtCredits } from '../session.js';

interface StakeControlProps {
  value: number;
  onChange: (v: number) => void;
  min: number;
  max: number;
  credits: number;
  disabled?: boolean;
  label?: string;
}

/** Shared stake selector: ½ / 2× / presets, clamped to game limits and credits. */
export const StakeControl: React.FC<StakeControlProps> = ({ value, onChange, min, max, credits, disabled, label = 'Stake' }) => {
  const clamp = (v: number) => Math.max(min, Math.min(max, Math.min(Math.floor(v), Math.max(min, Math.floor(credits)))));
  const presets = [10, 50, 100, 500].filter((p) => p >= min && p <= max);
  return (
    <div className={`space-y-2 ${disabled ? 'opacity-50 pointer-events-none' : ''}`}>
      <div className="flex items-center gap-2">
        <span className="text-[10px] font-bold uppercase text-slate-400 w-10">{label}</span>
        <div className="flex-1 bg-[#1A2C4E] border border-[#243A66] rounded-xl flex items-center justify-between h-11">
          <button aria-label="Halve stake" onClick={() => onChange(clamp(value / 2))} className="h-full px-4 text-sm font-black text-slate-300 active:text-white">½</button>
          <span className="text-sm font-extrabold" data-testid="stake">{fmtCredits(value)}</span>
          <button aria-label="Double stake" onClick={() => onChange(clamp(value * 2))} className="h-full px-4 text-sm font-black text-slate-300 active:text-white">2×</button>
        </div>
      </div>
      <div className="grid grid-cols-4 gap-1.5">
        {presets.map((p) => (
          <button
            key={p}
            onClick={() => onChange(clamp(p))}
            className={`h-9 rounded-lg text-xs font-bold border transition-colors ${
              value === p ? 'border-[#C58937] text-[#C58937] bg-[#C58937]/10' : 'border-[#243A66] text-slate-300 bg-[#1A2C4E]'
            }`}
          >
            {p}
          </button>
        ))}
      </div>
    </div>
  );
};

interface ActionButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  tone?: 'gold' | 'green' | 'red' | 'navy';
}

/** Large touch-friendly primary action button. */
export const ActionButton: React.FC<ActionButtonProps> = ({ tone = 'gold', className = '', children, ...rest }) => {
  const bg =
    tone === 'green' ? 'bg-[#01A879] shadow-[#01A879]/30' :
    tone === 'red' ? 'bg-[#E92844] shadow-[#E92844]/30' :
    tone === 'navy' ? 'bg-[#1A2C4E] border border-[#243A66]' :
    'bg-gradient-to-r from-[#C58937] to-[#E2A85C] shadow-[#C58937]/30';
  return (
    <button
      {...rest}
      className={`w-full min-h-[52px] rounded-xl text-sm font-black uppercase tracking-wider text-white shadow-lg transition-all active:scale-[0.98] disabled:opacity-40 disabled:active:scale-100 ${bg} ${className}`}
    >
      {children}
    </button>
  );
};

interface SegmentedProps<T extends string | number> {
  options: { value: T; label: string }[];
  value: T;
  onChange: (v: T) => void;
  disabled?: boolean;
}

export function Segmented<T extends string | number>({ options, value, onChange, disabled }: SegmentedProps<T>) {
  return (
    <div className={`flex bg-[#1A2C4E] border border-[#243A66] rounded-xl p-1 gap-1 ${disabled ? 'opacity-50 pointer-events-none' : ''}`}>
      {options.map((o) => (
        <button
          key={String(o.value)}
          onClick={() => onChange(o.value)}
          className={`flex-1 h-9 rounded-lg text-xs font-bold transition-all ${
            value === o.value ? 'gold-gradient-bg text-white shadow' : 'text-slate-400'
          }`}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}
