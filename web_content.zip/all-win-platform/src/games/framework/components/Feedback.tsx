import React, { ReactNode } from 'react';
import { RotateCcw, Trophy, XCircle, MinusCircle } from 'lucide-react';
import type { Outcome } from '../../../core/state/playStore.js';
import { fmtCredits } from '../session.js';

export interface ResultInfo {
  outcome: Outcome;
  title: string;
  multiplier?: number;
  payout?: number;
  note?: string;
}

/** Animated result card shown over the stage at the end of a round. */
export const ResultBanner: React.FC<{ result: ResultInfo | null; onReplay?: () => void; replayLabel?: string }> = ({
  result,
  onReplay,
  replayLabel = 'Play again',
}) => {
  if (!result) return null;
  const win = result.outcome === 'win';
  const push = result.outcome === 'push';
  const color = win ? '#01A879' : push ? '#C58937' : '#E92844';
  return (
    <div className="absolute inset-0 z-20 flex items-center justify-center bg-black/40 backdrop-blur-[2px] anim-fade-in" data-testid="result">
      <div
        className={`mx-6 w-full max-w-[280px] rounded-2xl border-2 bg-[#12213D] p-5 text-center shadow-2xl ${win ? 'anim-pop' : 'anim-shake'}`}
        style={{ borderColor: color, boxShadow: `0 0 40px -8px ${color}` }}
      >
        <div className="flex justify-center mb-2">
          {win ? <Trophy className="w-9 h-9" style={{ color }} /> : push ? <MinusCircle className="w-9 h-9" style={{ color }} /> : <XCircle className="w-9 h-9" style={{ color }} />}
        </div>
        <p className="text-lg font-black uppercase tracking-wide" style={{ color }}>{result.title}</p>
        {result.multiplier !== undefined && <p className="text-3xl font-black text-white mt-1">{result.multiplier.toFixed(2)}×</p>}
        {result.payout !== undefined && (
          <p className="text-xs text-slate-300 mt-1">{result.payout > 0 ? `+${fmtCredits(result.payout)} credits` : 'No credits returned'}</p>
        )}
        {result.note && <p className="text-[11px] text-slate-400 mt-1">{result.note}</p>}
        {onReplay && (
          <button
            onClick={onReplay}
            className="mt-4 w-full min-h-[44px] rounded-xl gold-gradient-bg text-white text-xs font-black uppercase flex items-center justify-center gap-1.5 active:scale-[0.98]"
          >
            <RotateCcw className="w-4 h-4" /> {replayLabel}
          </button>
        )}
      </div>
    </div>
  );
};

/** Responsive stage container (keeps aspect on wide screens, fills on mobile). */
export const GameStage: React.FC<{ children: ReactNode; className?: string; aspect?: string; accent?: string }> = ({
  children,
  className = '',
  aspect,
  accent = '#C58937',
}) => (
  <div
    className={`relative w-full flex-1 min-h-[300px] rounded-2xl overflow-hidden border bg-[#12213D] shadow-2xl ${className}`}
    style={{ borderColor: `${accent}66`, aspectRatio: aspect, boxShadow: `0 4px 24px -6px ${accent}33` }}
  >
    {children}
  </div>
);

/** Countdown ring used by round-based games. */
export const CountdownRing: React.FC<{ remaining: number; total: number; label?: string }> = ({ remaining, total, label }) => {
  const r = 34;
  const c = 2 * Math.PI * r;
  const p = Math.max(0, remaining / total);
  return (
    <div className="flex flex-col items-center gap-1">
      <svg width="84" height="84" viewBox="0 0 84 84">
        <circle cx="42" cy="42" r={r} stroke="#243A66" strokeWidth="6" fill="none" />
        <circle
          cx="42" cy="42" r={r} stroke="#C58937" strokeWidth="6" fill="none"
          strokeDasharray={c} strokeDashoffset={c * (1 - p)} strokeLinecap="round"
          transform="rotate(-90 42 42)"
        />
        <text x="42" y="50" textAnchor="middle" fontSize="22" fontWeight="900" fill="#fff">{Math.ceil(remaining)}</text>
      </svg>
      {label && <span className="text-[10px] font-bold uppercase tracking-widest text-slate-300">{label}</span>}
    </div>
  );
};

/** Transparent overlay canvas for particle effects. */
export const EffectsLayer = React.forwardRef<HTMLCanvasElement>((_, ref) => (
  <canvas ref={ref} className="absolute inset-0 w-full h-full pointer-events-none z-10" />
));
EffectsLayer.displayName = 'EffectsLayer';
