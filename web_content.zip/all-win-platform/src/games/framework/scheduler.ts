import { useEffect, useRef } from 'react';
import { runtime } from './runtime.js';
import { Easing, linear } from './animation.js';

/**
 * Scheduler – owns every timer and animation frame a game creates.
 * When the game unmounts, `dispose()` cancels everything, so leaving a game
 * never leaves timeouts, intervals or rAF loops running.
 * Promises from `wait`/`tween` simply never resolve after disposal, which
 * halts any async game sequence mid-flight.
 */
export class Scheduler {
  private timeouts = new Set<number>();
  private intervals = new Set<number>();
  private frames = new Map<number, number>();
  private nextLoop = 1;
  alive = true;

  timeout(fn: () => void, ms: number): number {
    if (!this.alive) return -1;
    const id = window.setTimeout(() => {
      this.timeouts.delete(id);
      runtime.add('timers', -1);
      if (this.alive) fn();
    }, ms);
    this.timeouts.add(id);
    runtime.add('timers', 1);
    return id;
  }

  interval(fn: () => void, ms: number): number {
    if (!this.alive) return -1;
    const id = window.setInterval(() => this.alive && fn(), ms);
    this.intervals.add(id);
    runtime.add('timers', 1);
    return id;
  }

  clear(id: number) {
    if (this.timeouts.delete(id)) {
      clearTimeout(id);
      runtime.add('timers', -1);
    }
    if (this.intervals.delete(id)) {
      clearInterval(id);
      runtime.add('timers', -1);
    }
  }

  wait(ms: number): Promise<void> {
    return new Promise((resolve) => {
      this.timeout(resolve, ms);
    });
  }

  /**
   * Starts a rAF loop. `fn(dt, elapsed)` is called every frame (seconds).
   * Return `false` to stop. Returns a stop function.
   */
  loop(fn: (dt: number, elapsed: number) => boolean | void): () => void {
    if (!this.alive) return () => {};
    const key = this.nextLoop++;
    let last = performance.now();
    const start = last;
    runtime.add('rafs', 1);
    const tick = (now: number) => {
      if (!this.frames.has(key)) return;
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      const keep = fn(dt, (now - start) / 1000);
      if (keep === false || !this.alive) {
        stop();
        return;
      }
      this.frames.set(key, requestAnimationFrame(tick));
    };
    const stop = () => {
      const f = this.frames.get(key);
      if (f !== undefined) {
        cancelAnimationFrame(f);
        this.frames.delete(key);
        runtime.add('rafs', -1);
      }
    };
    this.frames.set(key, requestAnimationFrame(tick));
    return stop;
  }

  /** Tween 0→1 over `ms`, eased. Resolves when finished. */
  tween(ms: number, onUpdate: (p: number) => void, ease: Easing = linear): Promise<void> {
    return new Promise((resolve) => {
      let t = 0;
      this.loop((dt) => {
        t += dt * 1000;
        const p = Math.min(1, t / ms);
        onUpdate(ease(p));
        if (p >= 1) {
          resolve();
          return false;
        }
      });
    });
  }

  get activeCount() {
    return this.timeouts.size + this.intervals.size + this.frames.size;
  }

  dispose() {
    this.alive = false;
    this.timeouts.forEach((id) => clearTimeout(id));
    this.intervals.forEach((id) => clearInterval(id));
    this.frames.forEach((f) => cancelAnimationFrame(f));
    runtime.add('timers', -(this.timeouts.size + this.intervals.size));
    runtime.add('rafs', -this.frames.size);
    this.timeouts.clear();
    this.intervals.clear();
    this.frames.clear();
  }

  revive() {
    this.alive = true;
  }
}

/** One Scheduler per mounted game; disposed automatically on unmount. */
export function useScheduler(): Scheduler {
  const ref = useRef<Scheduler | null>(null);
  if (!ref.current) ref.current = new Scheduler();
  useEffect(() => {
    const s = ref.current!;
    s.revive();
    return () => s.dispose();
  }, []);
  return ref.current;
}
