/**
 * Runtime diagnostics for the game framework.
 * Every scheduler / sound engine registers here so leaks are observable:
 *   window.__ALLWIN_RUNTIME__  -> { timers, rafs, audioContexts, mountedGames }
 */
export interface RuntimeCounters {
  timers: number;
  rafs: number;
  audioContexts: number;
  mountedGames: string[];
}

const counters: RuntimeCounters = { timers: 0, rafs: 0, audioContexts: 0, mountedGames: [] };

if (typeof window !== 'undefined') {
  (window as unknown as { __ALLWIN_RUNTIME__: RuntimeCounters }).__ALLWIN_RUNTIME__ = counters;
}

export const runtime = {
  counters,
  add(key: 'timers' | 'rafs' | 'audioContexts', n: number) {
    counters[key] = Math.max(0, counters[key] + n);
  },
  mount(slug: string) {
    counters.mountedGames.push(slug);
  },
  unmount(slug: string) {
    const i = counters.mountedGames.indexOf(slug);
    if (i >= 0) counters.mountedGames.splice(i, 1);
  },
};
