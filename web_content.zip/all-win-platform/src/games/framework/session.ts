import { useCallback, useEffect, useRef } from 'react';
import { playStore, usePlayStore, round2, Outcome } from '../../core/state/playStore.js';
import { runtime } from './runtime.js';
import type { GameConfig } from './types.js';

export interface RoundHandle {
  id: number;
  stake: number;
}

export interface GameSession {
  credits: number;
  /** Debits the stake and opens a round. Returns null if credits are insufficient. */
  beginRound: (stake: number) => RoundHandle | null;
  /** Closes the round, credits payout (if any) and records history. */
  settleRound: (round: RoundHandle, payout: number, detail: string) => Outcome;
  /** Adds to an open round's stake (double down, split). Returns false if credits are insufficient. */
  raiseStake: (round: RoundHandle, amount: number) => boolean;
  roundsPlayed: () => number;
}

/**
 * Round management bound to one mounted game instance.
 * The round counter lives in a ref owned by this mount, so every time a game
 * is opened it starts a brand-new session with no state from previous visits
 * or from other games.
 */
export function useGameSession(config: GameConfig): GameSession {
  const credits = usePlayStore((s) => s.credits);
  const counter = useRef(0);
  const open = useRef(new Set<number>());

  useEffect(() => {
    runtime.mount(config.slug);
    return () => runtime.unmount(config.slug);
  }, [config.slug]);

  const beginRound = useCallback(
    (stake: number) => {
      const s = round2(stake);
      if (s < config.minStake || s > config.maxStake) return null;
      if (!playStore.debit(s, `${config.name} stake`)) return null;
      const id = ++counter.current;
      open.current.add(id);
      return { id, stake: s };
    },
    [config]
  );

  const settleRound = useCallback(
    (round: RoundHandle, payout: number, detail: string): Outcome => {
      if (!open.current.delete(round.id)) return 'lose';
      const p = round2(Math.max(0, payout));
      if (p > 0) playStore.credit(p, `${config.name} payout`);
      const outcome: Outcome = p > round.stake ? 'win' : p === round.stake ? 'push' : 'lose';
      playStore.addRound({
        slug: config.slug,
        gameName: config.name,
        stake: round.stake,
        payout: p,
        multiplier: round.stake ? p / round.stake : 0,
        outcome,
        detail,
      });
      return outcome;
    },
    [config]
  );

  const raiseStake = useCallback(
    (round: RoundHandle, amount: number) => {
      if (!open.current.has(round.id)) return false;
      if (!playStore.debit(round2(amount), `${config.name} stake`)) return false;
      round.stake = round2(round.stake + amount);
      return true;
    },
    [config]
  );

  return { credits, beginRound, settleRound, raiseStake, roundsPlayed: () => counter.current };
}

/** Uniform random helpers (local, non-monetary play). */
export const rng = {
  float: () => {
    const a = new Uint32Array(1);
    crypto.getRandomValues(a);
    return a[0] / 2 ** 32;
  },
  int: (min: number, maxInclusive: number) => min + Math.floor(rng.float() * (maxInclusive - min + 1)),
  pick: <T,>(arr: readonly T[]): T => arr[Math.floor(rng.float() * arr.length)],
  shuffle: <T,>(arr: T[]): T[] => {
    const a = [...arr];
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(rng.float() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  },
};

export const fmtCredits = (n: number) =>
  n.toLocaleString('en-US', { minimumFractionDigits: n % 1 ? 2 : 0, maximumFractionDigits: 2 });
