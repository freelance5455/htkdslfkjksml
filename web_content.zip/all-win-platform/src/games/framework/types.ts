import type React from 'react';

export type LobbyCategory = 'Originals' | 'Slots' | 'Crash' | 'Table Games' | 'Lottery' | 'Instant Mini' | 'Arcade';

export const LOBBY_CATEGORIES: LobbyCategory[] = ['Originals', 'Slots', 'Crash', 'Table Games', 'Lottery', 'Instant Mini', 'Arcade'];

/** Static, serialisable configuration every game module exports from config.ts. */
export interface GameConfig {
  slug: string;
  name: string;
  category: LobbyCategory;
  badge: string;
  tagline: string;
  description: string;
  howToPlay: string[];
  /** Theoretical return to player – informational only. */
  rtp: string;
  /** Accent colour used for the card + game chrome. */
  accent: string;
  minStake: number;
  maxStake: number;
  defaultStake: number;
}

/** Registry entry: config + artwork are eager, gameplay code is lazy-loaded. */
export interface GameModuleEntry {
  config: GameConfig;
  Thumbnail: React.FC<{ className?: string }>;
  load: () => Promise<{ default: React.ComponentType }>;
}
