import { useEffect, useMemo, useRef, useSyncExternalStore } from 'react';
import { runtime } from './runtime.js';

/* ------------------------------------------------------------------ */
/* Global sound settings – persisted for the current browser session. */
/* ------------------------------------------------------------------ */
export interface SoundSettings {
  muted: boolean;
  volume: number; // 0..1
}
const KEY = 'allwin_sound';
let settings: SoundSettings = (() => {
  try {
    const raw = sessionStorage.getItem(KEY);
    if (raw) return { muted: false, volume: 0.7, ...JSON.parse(raw) };
  } catch {
    /* ignore */
  }
  return { muted: false, volume: 0.7 };
})();
const subs = new Set<() => void>();

export const soundSettings = {
  get: () => settings,
  set(p: Partial<SoundSettings>) {
    settings = { ...settings, ...p };
    try {
      sessionStorage.setItem(KEY, JSON.stringify(settings));
    } catch {
      /* ignore */
    }
    subs.forEach((s) => s());
  },
  toggle() {
    soundSettings.set({ muted: !settings.muted });
  },
  subscribe(fn: () => void) {
    subs.add(fn);
    return () => subs.delete(fn);
  },
};

export const useSoundSettings = () =>
  useSyncExternalStore(soundSettings.subscribe, soundSettings.get, soundSettings.get);

/* ------------------------------------------------------------------ */
/* Sound definitions. Each game ships its own bank of synthesized     */
/* sound "assets" (in games/<id>/sounds). They are original sounds    */
/* rendered at runtime with the Web Audio API – no external files.    */
/* ------------------------------------------------------------------ */
export interface ToneDef {
  /** Oscillator wave, or 'noise' for a filtered white-noise burst. */
  wave?: OscillatorType | 'noise';
  freq: number;
  /** Optional glide target frequency. */
  to?: number;
  /** Duration in ms. */
  dur: number;
  /** Start offset in ms. */
  at?: number;
  gain?: number;
  /** Low-pass cutoff for noise. */
  filter?: number;
}
export type SoundBank = Record<string, ToneDef[]>;

const userHasInteracted = () => {
  const ua = (navigator as Navigator & { userActivation?: { hasBeenActive: boolean } }).userActivation;
  return ua ? ua.hasBeenActive : true;
};

/**
 * Per-game sound engine. Owns its own AudioContext, created lazily on the
 * first sound after a user gesture (browser autoplay policy). Closed on
 * dispose so no audio continues after leaving the game.
 */
export class SoundEngine {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private noiseBuf: AudioBuffer | null = null;
  private loops = new Map<string, { osc: OscillatorNode; gain: GainNode; base: number }>();
  private unsub: () => void;
  private disposed = false;

  constructor(private bank: SoundBank) {
    this.unsub = soundSettings.subscribe(() => this.applyVolume());
  }

  private ensure(): AudioContext | null {
    if (this.disposed) return null;
    if (!this.ctx) {
      if (!userHasInteracted()) return null;
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AC) return null;
      this.ctx = new AC();
      runtime.add('audioContexts', 1);
      this.master = this.ctx.createGain();
      this.master.connect(this.ctx.destination);
      this.applyVolume();
    }
    if (this.ctx.state === 'suspended') this.ctx.resume().catch(() => {});
    return this.ctx;
  }

  private applyVolume() {
    if (!this.master || !this.ctx) return;
    const v = settings.muted ? 0 : settings.volume;
    this.master.gain.setTargetAtTime(v, this.ctx.currentTime, 0.02);
  }

  /** Call from a user gesture to unlock audio early. */
  unlock() {
    this.ensure();
  }

  play(name: string) {
    if (settings.muted) return;
    const tones = this.bank[name];
    const ctx = this.ensure();
    if (!tones || !ctx || !this.master) return;
    const now = ctx.currentTime;
    for (const t of tones) {
      const start = now + (t.at ?? 0) / 1000;
      const end = start + t.dur / 1000;
      const g = ctx.createGain();
      const peak = t.gain ?? 0.25;
      g.gain.setValueAtTime(0.0001, start);
      g.gain.exponentialRampToValueAtTime(peak, start + 0.008);
      g.gain.exponentialRampToValueAtTime(0.0001, end);
      g.connect(this.master);
      if (t.wave === 'noise') {
        const src = ctx.createBufferSource();
        src.buffer = this.noise(ctx);
        const f = ctx.createBiquadFilter();
        f.type = 'lowpass';
        f.frequency.setValueAtTime(t.filter ?? t.freq, start);
        if (t.to) f.frequency.exponentialRampToValueAtTime(t.to, end);
        src.connect(f).connect(g);
        src.start(start);
        src.stop(end + 0.02);
      } else {
        const o = ctx.createOscillator();
        o.type = (t.wave as OscillatorType) ?? 'sine';
        o.frequency.setValueAtTime(t.freq, start);
        if (t.to) o.frequency.exponentialRampToValueAtTime(t.to, end);
        o.connect(g);
        o.start(start);
        o.stop(end + 0.02);
      }
    }
  }

  /** Continuous tone (e.g. engine hum). Pitch adjustable with setLoopPitch. */
  startLoop(id: string, freq: number, wave: OscillatorType = 'sawtooth', gain = 0.05) {
    const ctx = this.ensure();
    if (!ctx || !this.master || this.loops.has(id)) return;
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = wave;
    o.frequency.value = freq;
    g.gain.value = 0.0001;
    g.gain.setTargetAtTime(gain, ctx.currentTime, 0.05);
    o.connect(g).connect(this.master);
    o.start();
    this.loops.set(id, { osc: o, gain: g, base: freq });
  }

  setLoopPitch(id: string, multiplier: number) {
    const l = this.loops.get(id);
    if (l && this.ctx) l.osc.frequency.setTargetAtTime(l.base * multiplier, this.ctx.currentTime, 0.05);
  }

  stopLoop(id: string) {
    const l = this.loops.get(id);
    if (!l || !this.ctx) return;
    l.gain.gain.setTargetAtTime(0.0001, this.ctx.currentTime, 0.03);
    l.osc.stop(this.ctx.currentTime + 0.2);
    this.loops.delete(id);
  }

  private noise(ctx: AudioContext) {
    if (!this.noiseBuf) {
      const len = ctx.sampleRate;
      this.noiseBuf = ctx.createBuffer(1, len, ctx.sampleRate);
      const d = this.noiseBuf.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    }
    return this.noiseBuf;
  }

  dispose() {
    this.disposed = true;
    this.unsub();
    this.loops.forEach((_, id) => this.stopLoop(id));
    if (this.ctx) {
      this.ctx.close().catch(() => {});
      runtime.add('audioContexts', -1);
      this.ctx = null;
    }
  }
}

export interface GameSound {
  play: (name: string) => void;
  unlock: () => void;
  startLoop: SoundEngine['startLoop'];
  setLoopPitch: SoundEngine['setLoopPitch'];
  stopLoop: SoundEngine['stopLoop'];
}

/** Hook: a SoundEngine bound to the component lifecycle. */
export function useGameSound(bank: SoundBank): GameSound {
  const ref = useRef<SoundEngine | null>(null);
  useEffect(() => {
    const engine = new SoundEngine(bank);
    ref.current = engine;
    return () => {
      engine.dispose();
      if (ref.current === engine) ref.current = null;
    };
  }, [bank]);
  return useMemo(
    () => ({
      play: (n) => ref.current?.play(n),
      unlock: () => ref.current?.unlock(),
      startLoop: (...a) => ref.current?.startLoop(...a),
      setLoopPitch: (...a) => ref.current?.setLoopPitch(...a),
      stopLoop: (...a) => ref.current?.stopLoop(...a),
    }),
    []
  );
}

/** Common UI sounds shared by the framework controls. */
export const UI_SOUNDS: SoundBank = {
  click: [{ wave: 'triangle', freq: 880, dur: 50, gain: 0.12 }],
  test: [
    { wave: 'triangle', freq: 523, dur: 120, gain: 0.2 },
    { wave: 'triangle', freq: 659, dur: 120, at: 110, gain: 0.2 },
    { wave: 'triangle', freq: 784, dur: 220, at: 220, gain: 0.2 },
  ],
};
