import { useCallback, useRef, useState } from 'react';

/**
 * Finite state machine for a game's lifecycle phases.
 * Each game declares its own phases and the legal transitions between them,
 * e.g. READY → COUNTDOWN → ACTIVE → RESULT → READY.
 * Illegal transitions are rejected (and logged in dev) so games can't end up
 * in inconsistent states from double taps or stale timers.
 */
export type Transitions<P extends string> = { readonly [K in P]: readonly P[] };

export interface PhaseMachine<P extends string> {
  phase: P;
  /** Move to `next` if legal. Returns whether the transition happened. */
  go: (next: P) => boolean;
  /** Synchronous read of the current phase (safe inside timers / loops). */
  current: () => P;
  is: (...p: P[]) => boolean;
}

export function usePhaseMachine<P extends string>(initial: P, transitions: Transitions<P>): PhaseMachine<P> {
  const [phase, setPhase] = useState<P>(initial);
  const ref = useRef<P>(initial);

  const go = useCallback(
    (next: P) => {
      const cur = ref.current;
      if (cur === next) return true;
      if (!transitions[cur].includes(next)) {
        if (import.meta.env?.DEV) console.debug(`[phase] rejected ${cur} → ${next}`);
        return false;
      }
      ref.current = next;
      setPhase(next);
      return true;
    },
    [transitions]
  );

  const current = useCallback(() => ref.current, []);
  const is = useCallback((...p: P[]) => p.includes(ref.current), []);

  return { phase, go, current, is };
}
