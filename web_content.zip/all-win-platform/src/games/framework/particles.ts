import { useCallback, useEffect, useRef } from 'react';
import type { Scheduler } from './scheduler.js';

/**
 * Lightweight canvas particle system used for game effects (win bursts,
 * explosions, sparks). Each game configures its own effect presets in
 * games/<id>/effects and drives them through this shared renderer.
 */
export interface Particle {
  x: number; y: number; vx: number; vy: number;
  life: number; max: number; size: number; color: string;
  gravity: number; shape: 'circle' | 'square' | 'star';
  rot: number; vr: number;
}

export interface BurstOptions {
  x: number;
  y: number;
  count?: number;
  colors?: string[];
  speed?: number;
  gravity?: number;
  life?: number;
  size?: number;
  spread?: number; // radians, default full circle
  angle?: number; // centre angle
  shape?: Particle['shape'];
}

export class ParticleSystem {
  particles: Particle[] = [];

  burst(o: BurstOptions) {
    const n = o.count ?? 40;
    const spread = o.spread ?? Math.PI * 2;
    const base = o.angle ?? -Math.PI / 2;
    for (let i = 0; i < n; i++) {
      const a = base + (Math.random() - 0.5) * spread;
      const sp = (o.speed ?? 280) * (0.35 + Math.random() * 0.65);
      const life = (o.life ?? 1.1) * (0.6 + Math.random() * 0.4);
      this.particles.push({
        x: o.x, y: o.y,
        vx: Math.cos(a) * sp, vy: Math.sin(a) * sp,
        life, max: life,
        size: (o.size ?? 5) * (0.5 + Math.random()),
        color: (o.colors ?? ['#C58937', '#E2A85C', '#ffffff'])[Math.floor(Math.random() * (o.colors?.length ?? 3))],
        gravity: o.gravity ?? 520,
        shape: o.shape ?? 'square',
        rot: Math.random() * 6, vr: (Math.random() - 0.5) * 12,
      });
    }
  }

  update(dt: number) {
    for (const p of this.particles) {
      p.life -= dt;
      p.vy += p.gravity * dt;
      p.vx *= 0.99;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.rot += p.vr * dt;
    }
    this.particles = this.particles.filter((p) => p.life > 0);
  }

  draw(ctx: CanvasRenderingContext2D) {
    for (const p of this.particles) {
      ctx.globalAlpha = Math.max(0, p.life / p.max);
      ctx.fillStyle = p.color;
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate(p.rot);
      if (p.shape === 'circle') {
        ctx.beginPath();
        ctx.arc(0, 0, p.size / 2, 0, Math.PI * 2);
        ctx.fill();
      } else if (p.shape === 'star') {
        ctx.beginPath();
        for (let i = 0; i < 5; i++) {
          const a = (i * 4 * Math.PI) / 5;
          ctx.lineTo(Math.cos(a) * p.size, Math.sin(a) * p.size);
        }
        ctx.fill();
      } else {
        ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size * 0.6);
      }
      ctx.restore();
    }
    ctx.globalAlpha = 1;
  }

  get alive() {
    return this.particles.length > 0;
  }
}

/** Sizes a canvas to its CSS box × devicePixelRatio and reports size changes. */
export function useCanvas(onResize?: (w: number, h: number) => void, settings?: CanvasRenderingContext2DSettings) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const size = useRef({ w: 0, h: 0 });
  const cb = useRef(onResize);
  cb.current = onResize;

  useEffect(() => {
    const c = canvasRef.current;
    if (!c) return;
    const apply = () => {
      const r = c.getBoundingClientRect();
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      c.width = Math.max(1, Math.round(r.width * dpr));
      c.height = Math.max(1, Math.round(r.height * dpr));
      const ctx = c.getContext('2d', settings);
      ctx?.setTransform(dpr, 0, 0, dpr, 0, 0);
      size.current = { w: r.width, h: r.height };
      cb.current?.(r.width, r.height);
    };
    apply();
    const ro = new ResizeObserver(apply);
    ro.observe(c);
    return () => ro.disconnect();
  }, []);

  const ctx = useCallback(() => canvasRef.current?.getContext('2d', settings) ?? null, []); // eslint-disable-line react-hooks/exhaustive-deps
  return { canvasRef, size, ctx };
}

/**
 * Overlay particle layer: a transparent canvas that renders bursts.
 * Runs its rAF loop only while particles are alive.
 */
export function useParticleLayer(scheduler: Scheduler) {
  const { canvasRef, size, ctx } = useCanvas();
  const sys = useRef(new ParticleSystem());
  const running = useRef(false);

  const burst = useCallback(
    (o: Omit<BurstOptions, 'x' | 'y'> & { x?: number; y?: number; rx?: number; ry?: number }) => {
      const { w, h } = size.current;
      sys.current.burst({ ...o, x: o.x ?? (o.rx ?? 0.5) * w, y: o.y ?? (o.ry ?? 0.5) * h });
      if (running.current) return;
      running.current = true;
      scheduler.loop((dt) => {
        const c = ctx();
        if (!c) return false;
        c.clearRect(0, 0, size.current.w, size.current.h);
        sys.current.update(dt);
        sys.current.draw(c);
        if (!sys.current.alive) {
          running.current = false;
          return false;
        }
      });
    },
    [scheduler, ctx, size]
  );

  useEffect(() => () => {
    running.current = false;
  }, []);

  return { canvasRef, burst };
}
