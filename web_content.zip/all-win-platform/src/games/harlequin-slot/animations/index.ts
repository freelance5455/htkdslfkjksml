import type { Scheduler } from '../../framework/scheduler.js';
import { easeOutBack } from '../../framework/animation.js';

/**
 * Spins one reel strip: accelerates, then decelerates with a small overshoot
 * onto the final symbols. Writes transforms directly (no React re-render).
 * Strip layout: [final(3) … filler … previous(3)]; we move from showing the
 * bottom 3 (previous) to showing the top 3 (final).
 */
export function spinReel(
  s: Scheduler,
  el: HTMLElement,
  cells: number,
  cellPx: number,
  ms: number,
  onTick: () => void
): Promise<void> {
  const startY = -(cells - 3) * cellPx;
  let lastCell = 0;
  el.style.filter = 'blur(1.5px)';
  return s
    .tween(ms, (p) => {
      const y = startY * (1 - p);
      el.style.transform = `translateY(${y}px)`;
      const c = Math.floor(-y / cellPx);
      if (c !== lastCell) {
        lastCell = c;
        onTick();
      }
      if (p > 0.85) el.style.filter = 'none';
    }, easeOutBack)
    .then(() => {
      el.style.transform = 'translateY(0px)';
      el.style.filter = 'none';
    });
}
