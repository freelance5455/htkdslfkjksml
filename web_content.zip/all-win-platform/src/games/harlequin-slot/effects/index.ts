type Burst = (o: { rx?: number; ry?: number; count?: number; colors?: string[]; speed?: number; gravity?: number; shape?: 'circle' | 'square' | 'star'; size?: number; life?: number }) => void;

export const lineWin = (burst: Burst) =>
  burst({ rx: 0.5, ry: 0.5, count: 30, colors: ['#F59E0B', '#FDE68A'], speed: 220, shape: 'star', size: 4 });

export const bigWinShower = (burst: Burst) => {
  for (const rx of [0.2, 0.5, 0.8]) burst({ rx, ry: 0.15, count: 50, colors: ['#F59E0B', '#E92844', '#A855F7', '#34D399', '#ffffff'], speed: 300, gravity: 520, life: 1.8 });
};
