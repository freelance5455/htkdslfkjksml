import React, { useEffect, useRef, useState } from 'react';
import {
  GameShell, GameStage, StakeControl, ActionButton, EffectsLayer,
  useScheduler, usePhaseMachine, useGameSession, useGameSound, useParticleLayer, fmtCredits,
} from '../framework/index.js';
import { config, LINES, REELS, SPIN_BASE_MS, SPIN_STAGGER_MS } from './config.js';
import { TRANSITIONS, Phase, buildStrip, initialGrid } from './gameState.js';
import { spinGrid, evaluate, totalPay, Grid, LineWin, SymbolId, SYMBOLS } from './gameLogic.js';
import { SOUNDS } from './sounds/index.js';
import { spinReel } from './animations/index.js';
import { lineWin, bigWinShower } from './effects/index.js';
import { SymbolArt } from './assets/Thumbnail.js';

export default function HarlequinSlotGame() {
  const session = useGameSession(config);
  const sched = useScheduler();
  const sound = useGameSound(SOUNDS);
  const fsm = usePhaseMachine<Phase>('IDLE', TRANSITIONS);
  const { canvasRef, burst } = useParticleLayer(sched);

  const [stake, setStake] = useState(config.defaultStake);
  const [grid, setGrid] = useState<Grid>(initialGrid);
  const [strips, setStrips] = useState<SymbolId[][]>(() => grid.map((c) => c));
  const [wins, setWins] = useState<LineWin[]>([]);
  const [lastWin, setLastWin] = useState<number | null>(null);
  const [autoLeft, setAutoLeft] = useState(0);
  const autoRef = useRef(0);
  const stripEls = useRef<(HTMLDivElement | null)[]>([]);
  const windowRef = useRef<HTMLDivElement>(null);
  const gridRef = useRef(grid);
  gridRef.current = grid;
  const [cellH, setCellH] = useState(80);
  const [startOffset, setStartOffset] = useState(false);

  useEffect(() => {
    const el = windowRef.current;
    if (!el) return;
    const ro = new ResizeObserver(() => setCellH(el.clientHeight / 3));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const spin = async () => {
    sound.unlock();
    if (fsm.is('SPINNING')) return false;
    const r = session.beginRound(stake);
    if (!r) return false;
    fsm.go('SPINNING');
    setWins([]);
    setLastWin(null);
    const next = spinGrid();
    const newStrips = next.map((col, i) => buildStrip(col, gridRef.current[i], i * 4));
    setStartOffset(true);
    setStrips(newStrips);
    sound.play('spin');
    await sched.wait(20); // let React paint the new strips at their start offset
    const cellPx = (windowRef.current?.clientHeight ?? 240) / 3;
    await Promise.all(
      newStrips.map((strip, i) => {
        const el = stripEls.current[i];
        if (!el) return Promise.resolve();
        return spinReel(sched, el, strip.length, cellPx, SPIN_BASE_MS + i * SPIN_STAGGER_MS, () => sound.play('tick')).then(() => sound.play('stop'));
      })
    );
    setGrid(next);
    setStartOffset(false);
    setStrips(next.map((c) => c));
    const w = evaluate(next);
    const pay = totalPay(w, stake);
    session.settleRound(r, pay, w.length ? w.map((x) => `${x.count}× ${x.symbol}`).join(', ') : 'No winning lines');
    setWins(w);
    setLastWin(pay);
    if (pay > 0) {
      fsm.go('WIN_SHOW');
      if (pay >= stake * 10) { sound.play('bigwin'); bigWinShower(burst); }
      else { sound.play('win'); lineWin(burst); }
    } else fsm.go('IDLE');
    return true;
  };

  const runAuto = async (n: number) => {
    autoRef.current = n;
    setAutoLeft(n);
    while (autoRef.current > 0 && sched.alive) {
      const ok = await spin();
      if (!ok) break;
      autoRef.current--;
      setAutoLeft(autoRef.current);
      await sched.wait(700);
    }
    autoRef.current = 0;
    setAutoLeft(0);
  };

  const spinning = fsm.phase === 'SPINNING';
  const winningCells = new Set<string>();
  wins.forEach((w) => LINES[w.line].slice(0, w.count).forEach((row, reel) => winningCells.add(`${reel}:${row}`)));
  const idle = !spinning;

  return (
    <GameShell
      config={config}
      credits={session.credits}
      busy={spinning || autoLeft > 0}
      status={spinning ? 'Spinning…' : autoLeft > 0 ? `Auto ${autoLeft} left` : lastWin ? `Won ${fmtCredits(lastWin)}` : 'Ready'}
      stage={
        <GameStage accent={config.accent} className="bg-gradient-to-b from-[#2A1640] to-[#12213D]">
          <EffectsLayer ref={canvasRef} />
          <div className="absolute inset-0 flex flex-col items-center justify-center p-3 gap-3">
            <p className="text-xs font-black tracking-[0.3em] text-[#F59E0B]">HARLEQUIN</p>
            <div className="relative w-full max-w-[380px] rounded-2xl p-2 bg-[#0B0E14] border-2 border-[#F59E0B]/60 shadow-[0_0_30px_-8px_#F59E0B]">
              <div ref={windowRef} className="grid grid-cols-5 gap-1.5 aspect-[5/3] overflow-hidden" data-testid="reels">
                {strips.map((strip, reel) => (
                  <div key={reel} className="relative overflow-hidden rounded-lg bg-[#12213D]">
                    <div ref={(el) => { stripEls.current[reel] = el; }} className="absolute inset-x-0 top-0 will-change-transform"
                      style={{ transform: `translateY(${startOffset ? -(strip.length - 3) * cellH : 0}px)` }}>
                      {strip.map((sym, i) => {
                        const win = !spinning && i < 3 && winningCells.has(`${reel}:${i}`);
                        return (
                          <div key={i} className="flex items-center justify-center" style={{ height: `${cellH}px` }}>
                            <div className={`w-[82%] h-[82%] rounded-lg flex items-center justify-center ${win ? 'bg-[#F59E0B]/25 ring-2 ring-[#F59E0B] anim-pulse-glow' : ''}`}>
                              <SymbolArt id={sym} className="w-[85%] h-[85%]" />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="h-10 flex items-center" data-testid="result">
              {lastWin !== null && (
                lastWin > 0 ? (
                  <div className="text-center anim-pop">
                    <p className="text-xl font-black text-[#F59E0B]">WIN {fmtCredits(lastWin)}</p>
                    <p className="text-[10px] text-slate-300">{wins.map((w) => `Line ${w.line + 1}: ${w.count}× ${w.symbol}`).join(' · ')}</p>
                  </div>
                ) : <p className="text-xs text-slate-400 anim-fade-in">No win this spin</p>
              )}
            </div>
            <div className="grid grid-cols-7 gap-1 w-full max-w-[380px]">
              {SYMBOLS.map((s) => (
                <div key={s.id} className="flex flex-col items-center bg-[#1A2C4E]/70 rounded-md py-1">
                  <SymbolArt id={s.id} className="w-6 h-6" />
                  <span className="text-[8px] text-slate-300 font-bold">{s.pays[2]}×</span>
                </div>
              ))}
            </div>
          </div>
        </GameStage>
      }
      controls={
        <>
          <StakeControl value={stake} onChange={setStake} min={config.minStake} max={config.maxStake} credits={session.credits} disabled={!idle || autoLeft > 0} label="Total" />
          <div className="grid grid-cols-[1fr_2fr] gap-2">
            {autoLeft > 0 ? (
              <ActionButton tone="red" onClick={() => { autoRef.current = 0; setAutoLeft(0); }}>Stop</ActionButton>
            ) : (
              <ActionButton tone="navy" disabled={!idle || stake > session.credits} onClick={() => runAuto(10)}>Auto ×10</ActionButton>
            )}
            <ActionButton onClick={() => spin()} disabled={!idle || autoLeft > 0 || stake > session.credits}>
              {spinning ? 'Spinning…' : stake > session.credits ? 'No credits' : `Spin · ${fmtCredits(stake)}`}
            </ActionButton>
          </div>
        </>
      }
    />
  );
}
