import { rng } from '../framework/session.js';
import { LINES, REELS, ROWS } from './config.js';

export type SymbolId = 'jester' | 'crown' | 'mask' | 'gem' | 'bell' | 'star' | 'cherry';

export interface SymbolDef {
  id: SymbolId;
  weight: number;
  pays: [number, number, number]; // 3, 4, 5 of a kind (× line stake)
  color: string;
}

export const SYMBOLS: SymbolDef[] = [
  { id: 'jester', weight: 3, pays: [60, 250, 1200], color: '#E92844' },
  { id: 'crown', weight: 5, pays: [36, 120, 450], color: '#F59E0B' },
  { id: 'mask', weight: 7, pays: [25, 75, 250], color: '#A855F7' },
  { id: 'gem', weight: 9, pays: [16, 48, 160], color: '#34D399' },
  { id: 'bell', weight: 12, pays: [10, 30, 95], color: '#FBBF24' },
  { id: 'star', weight: 15, pays: [6, 20, 60], color: '#60A5FA' },
  { id: 'cherry', weight: 18, pays: [4, 12, 32], color: '#F43F5E' },
];

const TOTAL = SYMBOLS.reduce((s, x) => s + x.weight, 0);
export const randomSymbol = (): SymbolId => {
  let r = rng.float() * TOTAL;
  for (const s of SYMBOLS) if ((r -= s.weight) < 0) return s.id;
  return 'cherry';
};

/** grid[reel][row] */
export type Grid = SymbolId[][];
export const spinGrid = (): Grid => Array.from({ length: REELS }, () => Array.from({ length: ROWS }, randomSymbol));

export interface LineWin {
  line: number;
  symbol: SymbolId;
  count: number;
  pay: number; // × line stake
}

export const evaluate = (grid: Grid): LineWin[] => {
  const wins: LineWin[] = [];
  LINES.forEach((rows, li) => {
    const syms = rows.map((r, reel) => grid[reel][r]);
    const base = syms.find((s) => s !== 'jester') ?? 'jester';
    let count = 0;
    for (const s of syms) {
      if (s === base || s === 'jester') count++;
      else break;
    }
    if (count >= 3) {
      const def = SYMBOLS.find((d) => d.id === base)!;
      wins.push({ line: li, symbol: base, count, pay: def.pays[count - 3] });
    }
  });
  return wins;
};

export const totalPay = (wins: LineWin[], stake: number) =>
  Math.floor(wins.reduce((s, w) => s + w.pay, 0) * (stake / LINES.length) * 100) / 100;
