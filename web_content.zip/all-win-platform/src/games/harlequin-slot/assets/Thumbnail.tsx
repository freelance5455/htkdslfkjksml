import React from 'react';
import type { SymbolId } from '../gameLogic.js';

/** Original SVG artwork for every reel symbol. */
export const SymbolArt: React.FC<{ id: SymbolId; className?: string }> = ({ id, className }) => {
  switch (id) {
    case 'jester':
      return (
        <svg viewBox="0 0 64 64" className={className}>
          <path d="M8 34 L18 10 L32 28 L46 10 L56 34 Z" fill="#E92844" />
          <path d="M32 28 L46 10 L56 34 L32 34 Z" fill="#7C3AED" />
          <circle cx="18" cy="9" r="4" fill="#FBBF24" /><circle cx="46" cy="9" r="4" fill="#FBBF24" />
          <rect x="8" y="34" width="48" height="8" rx="3" fill="#FBBF24" />
          <circle cx="32" cy="50" r="10" fill="#FDE68A" />
          <circle cx="28" cy="48" r="1.6" fill="#12213D" /><circle cx="36" cy="48" r="1.6" fill="#12213D" />
          <path d="M27 53 Q32 57 37 53" stroke="#E92844" strokeWidth="2" fill="none" />
          <text x="32" y="63" fontSize="7" fontWeight="900" textAnchor="middle" fill="#fff">WILD</text>
        </svg>
      );
    case 'crown':
      return (
        <svg viewBox="0 0 64 64" className={className}>
          <path d="M10 46 L8 18 L22 30 L32 12 L42 30 L56 18 L54 46 Z" fill="#F59E0B" stroke="#FDE68A" strokeWidth="2" />
          <rect x="10" y="46" width="44" height="7" rx="2" fill="#B45309" />
          <circle cx="32" cy="36" r="4" fill="#E92844" /><circle cx="20" cy="39" r="3" fill="#34D399" /><circle cx="44" cy="39" r="3" fill="#60A5FA" />
        </svg>
      );
    case 'mask':
      return (
        <svg viewBox="0 0 64 64" className={className}>
          <path d="M6 24 Q32 10 58 24 Q56 46 40 46 Q32 38 24 46 Q8 46 6 24 Z" fill="#A855F7" stroke="#E9D5FF" strokeWidth="2" />
          <ellipse cx="21" cy="29" rx="6" ry="4" fill="#12213D" /><ellipse cx="43" cy="29" rx="6" ry="4" fill="#12213D" />
          <path d="M58 24 L62 12" stroke="#FBBF24" strokeWidth="3" />
        </svg>
      );
    case 'gem':
      return (
        <svg viewBox="0 0 64 64" className={className}>
          <path d="M14 22 L24 10 H40 L50 22 L32 54 Z" fill="#34D399" />
          <path d="M14 22 H50 L32 54 Z" fill="#059669" />
          <path d="M24 10 L32 22 L40 10" stroke="#A7F3D0" strokeWidth="2" fill="none" />
        </svg>
      );
    case 'bell':
      return (
        <svg viewBox="0 0 64 64" className={className}>
          <path d="M16 44 Q18 16 32 14 Q46 16 48 44 Z" fill="#FBBF24" stroke="#FDE68A" strokeWidth="2" />
          <rect x="12" y="42" width="40" height="6" rx="3" fill="#D97706" />
          <circle cx="32" cy="52" r="5" fill="#B45309" />
        </svg>
      );
    case 'star':
      return (
        <svg viewBox="0 0 64 64" className={className}>
          <path d="M32 6 L39 24 L58 25 L43 37 L48 56 L32 45 L16 56 L21 37 L6 25 L25 24 Z" fill="#60A5FA" stroke="#DBEAFE" strokeWidth="2" />
        </svg>
      );
    default:
      return (
        <svg viewBox="0 0 64 64" className={className}>
          <path d="M32 12 Q28 30 20 38 M32 12 Q38 30 44 40" stroke="#16A34A" strokeWidth="3" fill="none" />
          <path d="M32 12 Q44 8 50 14 Q42 18 32 12" fill="#22C55E" />
          <circle cx="20" cy="44" r="10" fill="#F43F5E" /><circle cx="44" cy="46" r="10" fill="#E11D48" />
          <circle cx="17" cy="41" r="2.5" fill="#FECDD3" />
        </svg>
      );
  }
};

export const Thumbnail: React.FC<{ className?: string }> = ({ className }) => (
  <svg viewBox="0 0 96 96" className={className} aria-hidden>
    <rect x="8" y="22" width="80" height="52" rx="10" fill="#1A2C4E" stroke="#F59E0B" strokeWidth="3" />
    {[0, 1, 2].map((i) => <rect key={i} x={16 + i * 22} y="30" width="18" height="36" rx="4" fill="#0B0E14" />)}
    <path d="M18 54 L22 40 L25 48 L28 40 L32 54 Z" fill="#E92844" />
    <path d="M40 54 L44 40 L47 48 L50 40 L54 54 Z" fill="#E92844" />
    <path d="M62 54 L66 40 L69 48 L72 40 L76 54 Z" fill="#E92844" />
    <circle cx="86" cy="30" r="5" fill="#F59E0B" />
  </svg>
);
