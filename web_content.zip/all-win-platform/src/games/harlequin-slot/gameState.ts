import type { Transitions } from '../framework/stateMachine.js';
import { REELS } from './config.js';
import { randomSymbol, Grid, SymbolId } from './gameLogic.js';

/** IDLE → SPINNING → (WIN_SHOW | IDLE) → … */
export type Phase = 'IDLE' | 'SPINNING' | 'WIN_SHOW';
export const TRANSITIONS: Transitions<Phase> = {
  IDLE: ['SPINNING'],
  SPINNING: ['WIN_SHOW', 'IDLE'],
  WIN_SHOW: ['SPINNING', 'IDLE'],
};

export const STRIP_PAD = 18;

/** Visible strip per reel: final 3 symbols on top, random filler below, current view at the bottom. */
export const buildStrip = (finalCol: SymbolId[], prevCol: SymbolId[], extra: number): SymbolId[] => [
  ...finalCol,
  ...Array.from({ length: STRIP_PAD + extra }, randomSymbol),
  ...prevCol,
];

export const initialGrid = (): Grid => Array.from({ length: REELS }, () => [randomSymbol(), randomSymbol(), randomSymbol()]);
