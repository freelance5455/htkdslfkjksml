import type { GameConfig } from '../framework/types.js';

export const config: GameConfig = {
  slug: 'harlequin-slot',
  name: 'Harlequin Slot',
  category: 'Slots',
  badge: '5 LINES',
  tagline: 'Five reels of jesters, crowns and gems.',
  description: 'A 5-reel, 3-row video slot with 5 paylines. The Jester is wild and substitutes for every symbol. Line up 3, 4 or 5 matching symbols from the left to win.',
  howToPlay: [
    'Set your total stake — it is split evenly over 5 paylines.',
    'Tap Spin. Reels stop one after another.',
    'Matching symbols from the leftmost reel on a payline pay line stake × symbol value.',
    'The Jester (wild) substitutes for any symbol.',
    'Use Auto ×10 to spin ten times in a row (stops if credits run out).',
  ],
  rtp: '≈95%',
  accent: '#F59E0B',
  minStake: 10,
  maxStake: 2500,
  defaultStake: 50,
};

export const REELS = 5;
export const ROWS = 3;
export const LINES: number[][] = [
  [1, 1, 1, 1, 1],
  [0, 0, 0, 0, 0],
  [2, 2, 2, 2, 2],
  [0, 1, 2, 1, 0],
  [2, 1, 0, 1, 2],
];
export const SPIN_BASE_MS = 900;
export const SPIN_STAGGER_MS = 260;
