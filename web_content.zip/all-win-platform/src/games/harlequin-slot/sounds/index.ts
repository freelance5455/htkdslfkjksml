import type { SoundBank } from '../../framework/sound.js';

export const SOUNDS: SoundBank = {
  spin: [{ wave: 'sawtooth', freq: 180, to: 360, dur: 300, gain: 0.06 }],
  tick: [{ wave: 'square', freq: 1200, dur: 18, gain: 0.03 }],
  stop: [{ wave: 'triangle', freq: 220, to: 140, dur: 110, gain: 0.25 }],
  win: [
    { wave: 'triangle', freq: 523, dur: 100, gain: 0.2 },
    { wave: 'triangle', freq: 659, dur: 100, at: 90, gain: 0.2 },
    { wave: 'triangle', freq: 784, dur: 200, at: 180, gain: 0.2 },
  ],
  bigwin: [
    { wave: 'sine', freq: 523, dur: 140, gain: 0.25 },
    { wave: 'sine', freq: 659, dur: 140, at: 120, gain: 0.25 },
    { wave: 'sine', freq: 784, dur: 140, at: 240, gain: 0.25 },
    { wave: 'sine', freq: 1046, dur: 500, at: 360, gain: 0.25 },
    { wave: 'triangle', freq: 1318, dur: 500, at: 360, gain: 0.12 },
  ],
};
