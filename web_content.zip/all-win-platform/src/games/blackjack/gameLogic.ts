import { rng } from '../framework/session.js';
import { DECKS } from './config.js';

export type Suit = '♠' | '♥' | '♦' | '♣';
export type Rank = 'A' | '2' | '3' | '4' | '5' | '6' | '7' | '8' | '9' | '10' | 'J' | 'Q' | 'K';
export interface Card { rank: Rank; suit: Suit; id: number }

const SUITS: Suit[] = ['♠', '♥', '♦', '♣'];
const RANKS: Rank[] = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];

let nextId = 1;
export const newShoe = (): Card[] => {
  const cards: Card[] = [];
  for (let d = 0; d < DECKS; d++) for (const s of SUITS) for (const r of RANKS) cards.push({ rank: r, suit: s, id: nextId++ });
  return rng.shuffle(cards);
};

export const cardValue = (c: Card) => (c.rank === 'A' ? 11 : ['J', 'Q', 'K'].includes(c.rank) ? 10 : Number(c.rank));

export const handTotal = (cards: Card[]) => {
  let total = 0, aces = 0;
  for (const c of cards) {
    total += cardValue(c);
    if (c.rank === 'A') aces++;
  }
  while (total > 21 && aces > 0) {
    total -= 10;
    aces--;
  }
  return { total, soft: aces > 0 };
};

export const isBlackjack = (cards: Card[]) => cards.length === 2 && handTotal(cards).total === 21;
export const isBust = (cards: Card[]) => handTotal(cards).total > 21;
export const canSplit = (cards: Card[]) => cards.length === 2 && cardValue(cards[0]) === cardValue(cards[1]);
export const dealerShouldHit = (cards: Card[]) => handTotal(cards).total < 17;

/** Payout (total returned) for one player hand vs dealer. */
export const settleHand = (player: Card[], dealer: Card[], stake: number, fromSplit: boolean): { payout: number; label: string } => {
  const p = handTotal(player).total;
  const d = handTotal(dealer).total;
  if (p > 21) return { payout: 0, label: 'Bust' };
  if (!fromSplit && isBlackjack(player) && !isBlackjack(dealer)) return { payout: stake * 2.5, label: 'Blackjack!' };
  if (isBlackjack(dealer) && !(isBlackjack(player) && !fromSplit)) return { payout: 0, label: 'Dealer blackjack' };
  if (d > 21) return { payout: stake * 2, label: 'Dealer busts' };
  if (p > d) return { payout: stake * 2, label: 'Win' };
  if (p === d) return { payout: stake, label: 'Push' };
  return { payout: 0, label: 'Lose' };
};

export const isRed = (c: Card) => c.suit === '♥' || c.suit === '♦';
