import React from 'react';

export const Thumbnail: React.FC<{ className?: string }> = ({ className }) => (
  <svg viewBox="0 0 96 96" className={className} aria-hidden>
    <g transform="rotate(-12 36 50)">
      <rect x="16" y="22" width="38" height="54" rx="6" fill="#fff" />
      <text x="22" y="38" fontSize="13" fontWeight="900" fill="#0F172A">A</text>
      <text x="28" y="62" fontSize="20" fill="#0F172A">♠</text>
    </g>
    <g transform="rotate(10 62 50)">
      <rect x="42" y="20" width="38" height="54" rx="6" fill="#fff" />
      <text x="47" y="36" fontSize="13" fontWeight="900" fill="#E11D48">K</text>
      <text x="54" y="60" fontSize="20" fill="#E11D48">♥</text>
    </g>
    <text x="48" y="92" textAnchor="middle" fontSize="12" fontWeight="900" fill="#C58937">21</text>
  </svg>
);
