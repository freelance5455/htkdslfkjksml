import type { Transitions } from '../framework/stateMachine.js';
import type { Card } from './gameLogic.js';

/** IDLE → DEALING → PLAYER → DEALER → RESULT → IDLE (DEALING can jump to RESULT on blackjack). */
export type Phase = 'IDLE' | 'DEALING' | 'PLAYER' | 'DEALER' | 'RESULT';
export const TRANSITIONS: Transitions<Phase> = {
  IDLE: ['DEALING'],
  DEALING: ['PLAYER', 'DEALER', 'RESULT'],
  PLAYER: ['DEALER', 'RESULT'],
  DEALER: ['RESULT'],
  RESULT: ['IDLE', 'DEALING'],
};

export interface Hand {
  cards: Card[];
  stake: number;
  done: boolean;
  doubled: boolean;
  fromSplit: boolean;
  outcome?: string;
}

export const newHand = (stake: number, fromSplit = false): Hand => ({ cards: [], stake, done: false, doubled: false, fromSplit });
