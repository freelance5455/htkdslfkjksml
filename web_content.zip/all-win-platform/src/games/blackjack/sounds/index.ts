import type { SoundBank } from '../../framework/sound.js';

export const SOUNDS: SoundBank = {
  deal: [{ wave: 'noise', freq: 4000, to: 1500, dur: 90, gain: 0.18 }],
  flip: [{ wave: 'noise', freq: 2500, dur: 60, gain: 0.15 }, { wave: 'triangle', freq: 500, dur: 50, at: 40, gain: 0.08 }],
  chip: [{ wave: 'square', freq: 1800, dur: 30, gain: 0.08 }, { wave: 'square', freq: 2200, dur: 30, at: 40, gain: 0.06 }],
  win: [
    { wave: 'triangle', freq: 523, dur: 110, gain: 0.2 },
    { wave: 'triangle', freq: 784, dur: 220, at: 100, gain: 0.2 },
  ],
  blackjack: [
    { wave: 'sine', freq: 659, dur: 120, gain: 0.25 },
    { wave: 'sine', freq: 880, dur: 120, at: 110, gain: 0.25 },
    { wave: 'sine', freq: 1318, dur: 360, at: 220, gain: 0.25 },
  ],
  lose: [{ wave: 'sawtooth', freq: 200, to: 100, dur: 350, gain: 0.12 }],
  push: [{ wave: 'triangle', freq: 440, dur: 200, gain: 0.15 }],
};
