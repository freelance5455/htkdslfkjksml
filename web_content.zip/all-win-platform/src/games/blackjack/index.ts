import type { GameModuleEntry } from '../framework/types.js';
import { config } from './config.js';
import { Thumbnail } from './assets/Thumbnail.js';

export const entry: GameModuleEntry = { config, Thumbnail, load: () => import('./Game.js') };
