import type { GameConfig } from '../framework/types.js';

export const config: GameConfig = {
  slug: 'blackjack',
  name: 'Blackjack',
  category: 'Table Games',
  badge: 'STRATEGY',
  tagline: 'Beat the dealer to 21.',
  description: 'Classic six-deck blackjack. Hit, stand, double down or split pairs. Dealer stands on all 17s. Blackjack pays 3:2.',
  howToPlay: [
    'Choose a stake and tap Deal.',
    'Get closer to 21 than the dealer without going over.',
    'Hit draws a card, Stand ends your hand.',
    'Double doubles your stake for exactly one more card (first two cards only).',
    'Split a pair into two hands (one split per round).',
    'Dealer draws to 16 and stands on all 17s. Blackjack pays 3:2, a push returns the stake.',
  ],
  rtp: '≈99.4%',
  accent: '#E11D48',
  minStake: 10,
  maxStake: 5000,
  defaultStake: 100,
};

export const DECKS = 6;
export const RESHUFFLE_AT = 60;
export const DEAL_DELAY_MS = 380;
