import React, { useRef, useState } from 'react';
import {
  GameShell, GameStage, StakeControl, ActionButton, ResultBanner, ResultInfo, EffectsLayer,
  useScheduler, usePhaseMachine, useGameSession, useGameSound, useParticleLayer, RoundHandle, fmtCredits,
} from '../framework/index.js';
import { config, DEAL_DELAY_MS, RESHUFFLE_AT } from './config.js';
import { TRANSITIONS, Phase, Hand, newHand } from './gameState.js';
import { Card, newShoe, handTotal, isBlackjack, isBust, canSplit, dealerShouldHit, settleHand, cardValue } from './gameLogic.js';
import { SOUNDS } from './sounds/index.js';
import { PlayingCard } from './animations/index.js';
import { chipsWin, blackjackBurst } from './effects/index.js';

export default function BlackjackGame() {
  const session = useGameSession(config);
  const sched = useScheduler();
  const sound = useGameSound(SOUNDS);
  const fsm = usePhaseMachine<Phase>('IDLE', TRANSITIONS);
  const { canvasRef, burst } = useParticleLayer(sched);

  const [stake, setStake] = useState(config.defaultStake);
  const [view, setView] = useState<{ hands: Hand[]; dealer: Card[]; hidden: boolean; active: number }>({ hands: [], dealer: [], hidden: true, active: 0 });
  const [result, setResult] = useState<ResultInfo | null>(null);
  const [roundNo, setRoundNo] = useState(0);

  const shoe = useRef<Card[]>(newShoe());
  const g = useRef({ hands: [] as Hand[], dealer: [] as Card[], hidden: true, active: 0 });
  const round = useRef<RoundHandle | null>(null);
  const busy = useRef(false);

  const sync = () => setView({ hands: g.current.hands.map((h) => ({ ...h, cards: [...h.cards] })), dealer: [...g.current.dealer], hidden: g.current.hidden, active: g.current.active });
  const draw = () => {
    if (shoe.current.length < 1) shoe.current = newShoe();
    return shoe.current.pop()!;
  };
  const dealTo = async (target: 'dealer' | number) => {
    const c = draw();
    if (target === 'dealer') g.current.dealer.push(c);
    else g.current.hands[target].cards.push(c);
    sync();
    sound.play('deal');
    await sched.wait(DEAL_DELAY_MS);
  };

  const deal = async () => {
    sound.unlock();
    if (busy.current) return;
    const r = session.beginRound(stake);
    if (!r) return;
    busy.current = true;
    round.current = r;
    if (shoe.current.length < RESHUFFLE_AT) shoe.current = newShoe();
    g.current = { hands: [newHand(stake)], dealer: [], hidden: true, active: 0 };
    setResult(null);
    setRoundNo((n) => n + 1);
    sound.play('chip');
    fsm.go('DEALING');
    sync();
    await dealTo(0);
    await dealTo('dealer');
    await dealTo(0);
    await dealTo('dealer');
    const up = g.current.dealer[0];
    const peek = up.rank === 'A' || cardValue(up) === 10;
    if ((peek && isBlackjack(g.current.dealer)) || isBlackjack(g.current.hands[0].cards)) {
      await reveal();
      return finish();
    }
    busy.current = false;
    fsm.go('PLAYER');
  };

  const reveal = async () => {
    g.current.hidden = false;
    sync();
    sound.play('flip');
    await sched.wait(450);
  };

  const advance = async () => {
    const next = g.current.hands.findIndex((h) => !h.done);
    if (next >= 0) {
      g.current.active = next;
      sync();
      busy.current = false;
      return;
    }
    fsm.go('DEALER');
    await reveal();
    if (!g.current.hands.every((h) => isBust(h.cards))) {
      while (dealerShouldHit(g.current.dealer)) await dealTo('dealer');
    }
    finish();
  };

  const act = async (fn: (h: Hand) => Promise<void> | void) => {
    if (!fsm.is('PLAYER') || busy.current) return;
    busy.current = true;
    const h = g.current.hands[g.current.active];
    await fn(h);
    const cur = g.current.hands[g.current.active];
    if (handTotal(cur.cards).total >= 21) cur.done = true;
    sync();
    if (cur.done) await advance();
    else busy.current = false;
  };

  const hit = () => act(async () => { await dealTo(g.current.active); });
  const stand = () => act((h) => { h.done = true; });
  const double = () => act(async (h) => {
    if (h.cards.length !== 2 || !session.raiseStake(round.current!, h.stake)) return;
    sound.play('chip');
    h.stake *= 2;
    h.doubled = true;
    await dealTo(g.current.active);
    h.done = true;
  });
  const split = () => act(async (h) => {
    if (!canSplit(h.cards) || g.current.hands.length > 1 || !session.raiseStake(round.current!, h.stake)) return;
    sound.play('chip');
    const [a, b] = h.cards;
    const aces = a.rank === 'A';
    g.current.hands = [{ ...newHand(h.stake, true), cards: [a] }, { ...newHand(h.stake, true), cards: [b] }];
    g.current.active = 0;
    sync();
    await sched.wait(250);
    await dealTo(0);
    await dealTo(1);
    if (aces) g.current.hands.forEach((x) => (x.done = true));
    const first = g.current.hands[0];
    if (handTotal(first.cards).total >= 21) first.done = true;
    // the act() wrapper handles the active (first) hand; second hand gets checked on advance
    if (handTotal(g.current.hands[1].cards).total >= 21) g.current.hands[1].done = true;
  });

  const finish = () => {
    let total = 0;
    const labels: string[] = [];
    for (const h of g.current.hands) {
      const s = settleHand(h.cards, g.current.dealer, h.stake, h.fromSplit);
      h.outcome = s.label;
      total += s.payout;
      labels.push(`${s.label} (${handTotal(h.cards).total})`);
    }
    const r = round.current!;
    const outcome = session.settleRound(r, total, `${labels.join(' / ')} vs dealer ${handTotal(g.current.dealer).total}`);
    round.current = null;
    sync();
    fsm.go('RESULT');
    busy.current = false;
    const bj = g.current.hands.some((h) => h.outcome === 'Blackjack!');
    if (outcome === 'win') { sound.play(bj ? 'blackjack' : 'win'); (bj ? blackjackBurst : chipsWin)(burst); }
    else sound.play(outcome === 'push' ? 'push' : 'lose');
    setResult({
      outcome,
      title: g.current.hands.length > 1 ? labels.join(' · ') : labels[0].replace(/ \(.*/, ''),
      payout: total,
      note: `You ${g.current.hands.map((h) => handTotal(h.cards).total).join(' & ')} · Dealer ${handTotal(g.current.dealer).total}`,
    });
  };

  const phase = fsm.phase;
  const active = view.hands[view.active];
  const playing = phase === 'PLAYER';
  const dealerTotal = view.hidden ? (view.dealer[0] ? handTotal([view.dealer[0]]).total : 0) : handTotal(view.dealer).total;

  return (
    <GameShell
      config={config}
      credits={session.credits}
      busy={phase !== 'IDLE' && phase !== 'RESULT'}
      status={phase === 'PLAYER' ? 'Your move' : phase === 'DEALER' ? 'Dealer plays' : phase === 'DEALING' ? 'Dealing…' : phase === 'RESULT' ? 'Round over' : 'Place stake'}
      stage={
        <GameStage accent={config.accent} className="bg-[radial-gradient(ellipse_at_center,#0F5C45_0%,#0B3B2E_70%,#082A21_100%)]">
          <EffectsLayer ref={canvasRef} />
          <div className="absolute inset-0 flex flex-col justify-between p-4" key={roundNo}>
            <div className="flex flex-col items-center gap-2">
              <span className="text-[10px] font-black uppercase tracking-widest text-emerald-200/80">Dealer {view.dealer.length ? `· ${dealerTotal}` : ''}</span>
              <div className="flex min-h-[96px]" data-testid="dealer-cards">
                {view.dealer.map((c, i) => <PlayingCard key={c.id} card={c} index={i} faceDown={i === 1 && view.hidden} />)}
              </div>
            </div>
            <p className="text-center text-[10px] font-bold text-emerald-200/60 tracking-widest">BLACKJACK PAYS 3 TO 2 · DEALER STANDS ON 17</p>
            <div className="flex justify-center gap-6">
              {view.hands.length === 0 && <p className="text-sm text-emerald-100/80 self-center">Set your stake and tap Deal</p>}
              {view.hands.map((h, hi) => (
                <div key={hi} className={`flex flex-col items-center gap-2 rounded-xl p-1.5 transition-all ${playing && hi === view.active && view.hands.length > 1 ? 'ring-2 ring-[#C58937]' : ''}`}>
                  <div className="flex min-h-[96px]" data-testid="player-cards">
                    {h.cards.map((c, i) => <PlayingCard key={c.id} card={c} index={i} />)}
                  </div>
                  <span className={`text-xs font-black px-2 py-0.5 rounded-full ${isBust(h.cards) ? 'bg-[#E92844]' : 'bg-[#12213D]/80'}`}>
                    {h.cards.length ? handTotal(h.cards).total : ''}{h.doubled ? ' · 2×' : ''} · {fmtCredits(h.stake)}
                  </span>
                </div>
              ))}
            </div>
          </div>
          <ResultBanner result={result} onReplay={() => { setResult(null); deal(); }} replayLabel={`Deal again · ${fmtCredits(stake)}`} />
        </GameStage>
      }
      controls={
        playing && active ? (
          <div className="grid grid-cols-4 gap-2">
            <ActionButton tone="green" onClick={hit}>Hit</ActionButton>
            <ActionButton tone="red" onClick={stand}>Stand</ActionButton>
            <ActionButton tone="navy" onClick={double} disabled={active.cards.length !== 2 || session.credits < active.stake}>Double</ActionButton>
            <ActionButton tone="navy" onClick={split} disabled={!canSplit(active.cards) || view.hands.length > 1 || session.credits < active.stake}>Split</ActionButton>
          </div>
        ) : (
          <>
            <StakeControl value={stake} onChange={setStake} min={config.minStake} max={config.maxStake} credits={session.credits} disabled={phase !== 'IDLE' && phase !== 'RESULT'} />
            <ActionButton onClick={() => { setResult(null); deal(); }} disabled={(phase !== 'IDLE' && phase !== 'RESULT') || stake > session.credits}>
              {phase === 'DEALING' || phase === 'DEALER' ? 'Dealing…' : stake > session.credits ? 'Not enough credits' : `Deal · ${fmtCredits(stake)}`}
            </ActionButton>
          </>
        )
      }
    />
  );
}
