type Burst = (o: { rx?: number; ry?: number; count?: number; colors?: string[]; speed?: number; gravity?: number; shape?: 'circle' | 'square' | 'star'; size?: number }) => void;

export const chipsWin = (burst: Burst) =>
  burst({ rx: 0.5, ry: 0.7, count: 40, colors: ['#C58937', '#E2A85C', '#01A879', '#ffffff'], speed: 300, gravity: 520, shape: 'circle', size: 7 });

export const blackjackBurst = (burst: Burst) => {
  chipsWin(burst);
  burst({ rx: 0.5, ry: 0.5, count: 60, colors: ['#FDE68A', '#ffffff', '#E11D48'], speed: 380, gravity: 300, shape: 'star', size: 5 });
};
