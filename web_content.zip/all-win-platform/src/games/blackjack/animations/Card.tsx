import React from 'react';
import type { Card } from '../gameLogic.js';
import { isRed } from '../gameLogic.js';

/**
 * Card component: enters with the deal keyframe and flips in 3D when the
 * dealer's hole card is revealed.
 */
export const PlayingCard: React.FC<{ card: Card; faceDown?: boolean; index: number }> = ({ card, faceDown, index }) => (
  <div className="relative w-14 h-20 sm:w-16 sm:h-24 perspective anim-deal" style={{ marginLeft: index ? -22 : 0, animationDelay: '0ms' }}>
    <div className="absolute inset-0 preserve-3d" style={{ transform: faceDown ? 'rotateY(180deg)' : 'none', transition: 'transform 420ms cubic-bezier(.2,.8,.2,1)' }}>
      <div className={`absolute inset-0 backface-hidden rounded-lg bg-white shadow-xl border border-slate-200 p-1 flex flex-col justify-between ${isRed(card) ? 'text-[#E11D48]' : 'text-[#0F172A]'}`}>
        <span className="text-sm font-black leading-none">{card.rank}<br />{card.suit}</span>
        <span className="text-2xl self-center leading-none">{card.suit}</span>
        <span className="text-sm font-black leading-none self-end rotate-180">{card.rank}</span>
      </div>
      <div className="absolute inset-0 backface-hidden rounded-lg shadow-xl border-2 border-[#C58937] bg-[#12213D] flex items-center justify-center" style={{ transform: 'rotateY(180deg)' }}>
        <div className="w-[80%] h-[85%] rounded border border-[#C58937]/60 bg-[repeating-linear-gradient(45deg,#1A2C4E_0_4px,#12213D_4px_8px)] flex items-center justify-center">
          <span className="text-[10px] font-black text-[#C58937]">AW</span>
        </div>
      </div>
    </div>
  </div>
);
