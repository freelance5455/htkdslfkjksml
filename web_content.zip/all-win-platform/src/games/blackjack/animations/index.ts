import { useCallback, useRef } from 'react';

/** Animation timeline helpers for dealing order. */
export const DEAL_ORDER = ['player', 'dealer', 'player', 'dealer'] as const;
export { PlayingCard } from './Card.js';

/** Keeps a re-render counter so card entry animations replay on every new round. */
export const useRoundKey = () => {
  const k = useRef(0);
  return { key: () => k.current, bump: useCallback(() => ++k.current, []) };
};
