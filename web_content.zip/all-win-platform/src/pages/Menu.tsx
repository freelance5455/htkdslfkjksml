import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { PageHeader } from '../components/layout/PageHeader.js';
import {
  User, Crown, History as HistoryIcon, Gift, BarChart2, Bell, Globe,
  Headphones, Shield, HeartHandshake, Settings, LogOut, Gamepad2, Coins
} from 'lucide-react';
import { useI18n } from '../context/I18nContext.js';
import { Modal } from '../components/common/Modal.js';
import { Button } from '../components/common/Button.js';
import { ROUTES } from '../core/config/routes.js';

export const Menu: React.FC = () => {
  const { t, language, setLanguage } = useI18n();
  const navigate = useNavigate();

  const [isLogoutModalOpen, setIsLogoutModalOpen] = useState(false);

  const menuItems = [
    { label: t('profile'), icon: <User className="w-5 h-5 text-[#C58937]" />, route: ROUTES.PROFILE },
    { label: 'Game Lobby', icon: <Gamepad2 className="w-5 h-5 text-[#01A879]" />, route: ROUTES.CATALOG },
    { label: t('wallet'), icon: <Coins className="w-5 h-5 text-[#C58937]" />, route: ROUTES.WALLET },
    { label: t('vip'), icon: <Crown className="w-5 h-5 text-amber-400" />, route: ROUTES.VIP },
    { label: t('history'), icon: <HistoryIcon className="w-5 h-5 text-blue-400" />, route: '/history' },
    { label: t('gifts'), icon: <Gift className="w-5 h-5 text-emerald-400" />, route: '/menu/gifts' },
    { label: t('statistics'), icon: <BarChart2 className="w-5 h-5 text-purple-400" />, route: '/menu/statistics' },
    { label: t('notifications'), icon: <Bell className="w-5 h-5 text-rose-400" />, route: '/menu/notifications' },
    { label: t('serviceCenter'), icon: <Headphones className="w-5 h-5 text-[#01A879]" />, route: ROUTES.CUSTOMER_SERVICE },
    { label: t('security'), icon: <Shield className="w-5 h-5 text-cyan-400" />, route: '/menu/security' },
    { label: t('responsibleGaming'), icon: <HeartHandshake className="w-5 h-5 text-rose-500" />, route: '/menu/responsible-gaming' },
    { label: t('settings'), icon: <Settings className="w-5 h-5 text-slate-400" />, route: '/menu/settings' },
  ];

  const handleConfirmLogout = () => {
    setIsLogoutModalOpen(false);
    navigate(ROUTES.LOGIN);
  };

  return (
    <div className="space-y-4 text-left pb-8">
      <PageHeader title={t('menu')} />

      {/* Language Toggle Widget */}
      <div className="bg-[#12213D] border border-[#243A66] rounded-2xl p-4 shadow-lg flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Globe className="w-5 h-5 text-[#C58937]" />
          <div>
            <p className="text-xs font-bold text-white">{t('language')}</p>
            <p className="text-[10px] text-slate-400">Current: {language === 'EN' ? 'English' : 'বাংলা (Bengali)'}</p>
          </div>
        </div>
        <button
          onClick={() => setLanguage(language === 'EN' ? 'BN' : 'EN')}
          className="px-3 py-1.5 rounded-xl gold-gradient-bg text-white text-xs font-bold shadow-md hover:brightness-110"
        >
          {language === 'EN' ? 'বাংলা' : 'English'}
        </button>
      </div>

      {/* Menu Options List */}
      <div className="bg-[#12213D] border border-[#243A66] rounded-2xl divide-y divide-[#243A66]/50 shadow-lg overflow-hidden">
        {menuItems.map((item) => (
          <button
            key={item.label}
            onClick={() => navigate(item.route)}
            className="w-full p-4 flex items-center justify-between cursor-pointer hover:bg-[#1A2C4E] transition-colors"
          >
            <div className="flex items-center gap-3">
              {item.icon}
              <span className="text-xs font-bold text-slate-200">{item.label}</span>
            </div>
            <span className="text-slate-500 text-xs">→</span>
          </button>
        ))}
      </div>

      {/* Controlled Vertical Gap before Logout */}
      <div className="pt-8">
        <button
          onClick={() => setIsLogoutModalOpen(true)}
          className="w-full py-3.5 px-4 rounded-2xl bg-[#12213D] border border-[#E92844]/40 text-[#E92844] font-bold text-sm hover:bg-[#E92844]/10 transition-all flex items-center justify-center gap-2 shadow-lg"
        >
          <LogOut className="w-4 h-4" />
          {t('logout')}
        </button>
      </div>

      {/* Logout Confirmation Modal */}
      <Modal
        isOpen={isLogoutModalOpen}
        onClose={() => setIsLogoutModalOpen(false)}
        title={t('logoutConfirmTitle')}
      >
        <div className="space-y-5 pt-2">
          <p className="text-sm font-medium text-slate-200">
            {t('logoutConfirmMessage')}
          </p>
          <div className="grid grid-cols-2 gap-3 pt-2">
            <Button
              variant="neutral"
              onClick={() => setIsLogoutModalOpen(false)}
              className="py-2.5 text-xs font-bold"
            >
              {t('cancel')}
            </Button>
            <Button
              variant="confirm"
              onClick={handleConfirmLogout}
              className="py-2.5 text-xs font-bold"
            >
              {t('confirm')}
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
