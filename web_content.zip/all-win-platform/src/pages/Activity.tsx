import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Calendar, Gamepad2, TrendingUp, Trophy, Percent, Zap } from 'lucide-react';
import { PageHeader } from '../components/layout/PageHeader.js';
import { useI18n } from '../context/I18nContext.js';
import { Button } from '../components/common/Button.js';
import { playStore, usePlayStore, computeStats, dayKey } from '../core/state/playStore.js';
import { RoundRow } from '../components/game/RoundRow.js';
import { EmptyState } from '../components/game/GameCard.js';
import { fmtCredits } from '../games/framework/session.js';

export const Activity: React.FC = () => {
  const { t } = useI18n();
  const navigate = useNavigate();
  const history = usePlayStore((s) => s.history);
  const lastClaim = usePlayStore((s) => s.lastDailyClaim);
  const streak = usePlayStore((s) => s.streak);
  const [claimed, setClaimed] = useState<number | null>(null);
  const stats = computeStats(history);
  const claimedToday = lastClaim === dayKey(Date.now());
  const yesterday = dayKey(Date.now() - 86_400_000);
  const nextDay = claimedToday ? streak : lastClaim === yesterday ? (streak % 7) + 1 : 1;

  return (
    <div className="space-y-5 text-left anim-fade-in">
      <PageHeader title={t('activity')} />

      <div className="bg-[#12213D] border gold-border-glow rounded-2xl p-5 shadow-xl">
        <h2 className="text-sm font-black text-white flex items-center gap-2 mb-3"><TrendingUp className="w-4 h-4 text-[#C58937]" /> Your play summary</h2>
        <div className="grid grid-cols-2 gap-3">
          {[
            { k: 'Rounds played', v: String(stats.rounds), icon: <Gamepad2 className="w-3.5 h-3.5" />, c: 'text-white' },
            { k: 'Win rate', v: `${stats.winRate.toFixed(1)}%`, icon: <Percent className="w-3.5 h-3.5" />, c: 'text-[#01A879]' },
            { k: 'Best multiplier', v: `${stats.bestMultiplier.toFixed(2)}×`, icon: <Zap className="w-3.5 h-3.5" />, c: 'text-[#C58937]' },
            { k: 'Net credits', v: fmtCredits(stats.net), icon: <Trophy className="w-3.5 h-3.5" />, c: stats.net >= 0 ? 'text-[#01A879]' : 'text-[#E92844]' },
          ].map((x) => (
            <div key={x.k} className="bg-[#1A2C4E] border border-[#243A66] p-3 rounded-xl">
              <span className="text-[10px] text-slate-400 font-medium flex items-center gap-1">{x.icon}{x.k}</span>
              <p className={`text-base font-black mt-0.5 ${x.c}`}>{x.v}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-[#12213D] border border-[#243A66] rounded-2xl p-4 shadow-lg space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold text-white flex items-center gap-1.5"><Calendar className="w-4 h-4 text-[#C58937]" /> Daily check-in</h3>
          <span className="text-[10px] font-bold text-[#01A879]">Day {nextDay} of 7</span>
        </div>
        <div className="grid grid-cols-7 gap-1.5">
          {[1, 2, 3, 4, 5, 6, 7].map((day) => {
            const done = claimedToday ? day <= streak : day < nextDay;
            const today = !claimedToday && day === nextDay;
            return (
              <div key={day} className={`py-2 rounded-xl text-center border text-[10px] font-bold ${done ? 'bg-[#01A879]/20 border-[#01A879] text-[#01A879]' : today ? 'gold-gradient-bg border-transparent text-white anim-pulse-glow' : 'bg-[#1A2C4E] border-[#243A66] text-slate-400'}`}>
                <div>D{day}</div>
                <div className="mt-1 font-black">{day * 100}</div>
              </div>
            );
          })}
        </div>
        <Button variant="primary" fullWidth disabled={claimedToday} onClick={() => setClaimed(playStore.claimDaily())} className="py-3 text-xs font-extrabold">
          {claimedToday ? (claimed ? `+${claimed} play credits claimed ✓` : 'Come back tomorrow ✓') : `Claim ${nextDay * 100} play credits`}
        </Button>
        <p className="text-[10px] text-slate-500">Check-in rewards are free play credits with no cash value.</p>
      </div>

      <div className="bg-[#12213D] border border-[#243A66] rounded-2xl shadow-lg overflow-hidden">
        <div className="flex items-center justify-between p-4 pb-2">
          <h3 className="text-xs font-bold text-white">Recent rounds</h3>
          {history.length > 0 && <button onClick={() => navigate('/history')} className="text-[11px] font-bold text-[#C58937]">View all →</button>}
        </div>
        {history.length ? (
          <div className="divide-y divide-[#243A66]/50">{history.slice(0, 8).map((r) => <RoundRow key={r.id} r={r} />)}</div>
        ) : (
          <div className="p-4 pt-0">
            <EmptyState icon={<Gamepad2 className="w-5 h-5" />} title="No activity yet" body="Play any game and your rounds will appear here."
              action={<button onClick={() => navigate('/catalog')} className="mt-2 px-4 h-10 rounded-xl gold-gradient-bg text-xs font-bold">Open game lobby</button>} />
          </div>
        )}
      </div>
    </div>
  );
};
