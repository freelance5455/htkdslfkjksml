import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Flame, Heart, Clock, Coins, ChevronRight, Search } from 'lucide-react';
import { useI18n } from '../context/I18nContext.js';
import { GAMES, categorySlug, getGame } from '../games/registry.js';
import { LOBBY_CATEGORIES, LobbyCategory } from '../games/framework/types.js';
import { GameCard, EmptyState } from '../components/game/GameCard.js';
import { usePlayStore } from '../core/state/playStore.js';
import { fmtCredits } from '../games/framework/session.js';

export const Home: React.FC = () => {
  const { t } = useI18n();
  const navigate = useNavigate();
  const [activeCategory, setActiveCategory] = useState<'ALL' | LobbyCategory>('ALL');
  const credits = usePlayStore((s) => s.credits);
  const favorites = usePlayStore((s) => s.favorites);
  const history = usePlayStore((s) => s.history);

  const filtered = activeCategory === 'ALL' ? GAMES : GAMES.filter((g) => g.config.category === activeCategory);
  const recent = useMemo(() => {
    const seen: string[] = [];
    for (const r of history) if (!seen.includes(r.slug)) seen.push(r.slug);
    return seen.slice(0, 6).map(getGame).filter(Boolean);
  }, [history]);
  const favGames = favorites.map(getGame).filter(Boolean);

  return (
    <div className="space-y-6 text-left pb-6 anim-fade-in">
      {/* Hero */}
      <div className="relative rounded-2xl gold-border-glow p-5 navy-gradient-bg overflow-hidden shadow-2xl">
        <div className="absolute -right-8 -bottom-8 w-36 h-36 rounded-full bg-[#C58937]/10 blur-2xl pointer-events-none" />
        <div className="absolute right-2 bottom-2 w-28 h-28 opacity-90 pointer-events-none">
          {(() => { const T = GAMES[0].Thumbnail; return <T className="w-full h-full" />; })()}
        </div>
        <div className="relative z-10 max-w-[230px]">
          <span className="inline-block px-2.5 py-1 text-[10px] font-black rounded-full gold-gradient-bg text-white mb-2 uppercase tracking-widest shadow-md">PLAY FOR FUN</span>
          <h2 className="text-xl font-black text-white leading-tight">
            {GAMES.length} original games. <span className="text-[#C58937]">Free play credits.</span>
          </h2>
          <p className="text-xs text-slate-300 mt-2">Credits have no cash value — just pure gameplay. Ride the rocket, cross the road, beat the dealer.</p>
          <div className="mt-4 flex items-center gap-2">
            <button onClick={() => navigate('/game/sky-rocket')} className="px-4 py-2.5 rounded-xl gold-gradient-bg text-white text-xs font-bold shadow-lg hover:brightness-110 transition-all">
              Play Sky Rocket →
            </button>
            <button onClick={() => navigate('/wallet')} className="px-3 py-2.5 rounded-xl bg-[#1A2C4E] border border-[#243A66] text-xs font-bold flex items-center gap-1">
              <Coins className="w-3.5 h-3.5 text-[#C58937]" /> {fmtCredits(credits)}
            </button>
          </div>
        </div>
      </div>

      {/* Search shortcut */}
      <button onClick={() => navigate('/catalog')} className="w-full flex items-center gap-2 px-4 h-11 rounded-xl bg-[#12213D] border border-[#243A66] text-slate-400 text-xs">
        <Search className="w-4 h-4" /> Search games…
      </button>

      {/* Categories */}
      <div>
        <div className="flex items-center justify-between mb-2.5 px-1">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">{t('categories')}</h3>
          <button onClick={() => navigate(activeCategory === 'ALL' ? '/catalog' : `/catalog/${categorySlug(activeCategory)}`)} className="text-[11px] font-bold text-[#C58937] flex items-center">
            Open lobby <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          {(['ALL', ...LOBBY_CATEGORIES] as const).map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-3.5 h-9 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                activeCategory === cat ? 'gold-gradient-bg text-white shadow-md' : 'bg-[#12213D] border border-[#243A66] text-slate-300 hover:text-white'
              }`}
            >
              {cat === 'ALL' ? t('allGames') : cat}
            </button>
          ))}
        </div>
      </div>

      {recent.length > 0 && activeCategory === 'ALL' && (
        <section>
          <h3 className="text-sm font-black text-white flex items-center gap-2 mb-3 px-1"><Clock className="w-4 h-4 text-[#C58937]" /> Recently played</h3>
          <div className="flex gap-3 overflow-x-auto scrollbar-none pb-1">
            {recent.map((g) => {
              const T = g!.Thumbnail;
              return (
                <button key={g!.config.slug} onClick={() => navigate(`/game/${g!.config.slug}/play`)} className="shrink-0 w-24 bg-[#12213D] border border-[#243A66] rounded-xl p-2 flex flex-col items-center gap-1 hover:border-[#C58937]">
                  <T className="w-12 h-12" />
                  <span className="text-[10px] font-bold truncate w-full text-center">{g!.config.name}</span>
                </button>
              );
            })}
          </div>
        </section>
      )}

      {favGames.length > 0 && activeCategory === 'ALL' && (
        <section>
          <h3 className="text-sm font-black text-white flex items-center gap-2 mb-3 px-1"><Heart className="w-4 h-4 text-[#E92844]" /> Favourites</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3.5">
            {favGames.map((g) => <GameCard key={g!.config.slug} game={g!} />)}
          </div>
        </section>
      )}

      <section>
        <h3 className="text-sm font-black text-white flex items-center gap-2 mb-3 px-1">
          <Flame className="w-4 h-4 text-[#C58937]" /> {activeCategory === 'ALL' ? t('featuredGames') : activeCategory}
        </h3>
        {filtered.length ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3.5" key={activeCategory}>
            {filtered.map((g) => <GameCard key={g.config.slug} game={g} />)}
          </div>
        ) : (
          <EmptyState icon={<Flame className="w-5 h-5" />} title="No games here yet" body="Try another category." />
        )}
      </section>

      <footer className="pt-6 border-t border-[#243A66] text-xs text-slate-400 space-y-2 px-1">
        <h4 className="font-extrabold text-sm text-[#C58937]">{t('homeFooterTitle')}</h4>
        <p className="leading-relaxed text-[11px] text-slate-400">
          ALL WIN is a free-to-play entertainment app. All games are original implementations that use play credits only — credits cannot be purchased, withdrawn or exchanged for money or prizes.
        </p>
      </footer>
    </div>
  );
};
