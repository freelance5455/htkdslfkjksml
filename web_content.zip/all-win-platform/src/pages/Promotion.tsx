import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Target, Award, Check, Lock } from 'lucide-react';
import { PageHeader } from '../components/layout/PageHeader.js';
import { useI18n } from '../context/I18nContext.js';
import { playStore, usePlayStore, computeStats, PlayStats } from '../core/state/playStore.js';
import { GAMES } from '../games/registry.js';

interface Mission {
  id: string;
  title: string;
  body: string;
  reward: number;
  progress: (s: PlayStats) => [number, number];
  cta: string;
}

const MISSIONS: Mission[] = [
  { id: 'first-round', title: 'First steps', body: 'Play your first round of any game.', reward: 200, progress: (s) => [Math.min(1, s.rounds), 1], cta: '/catalog' },
  { id: 'ten-rounds', title: 'Warming up', body: 'Play 10 rounds in total.', reward: 500, progress: (s) => [Math.min(10, s.rounds), 10], cta: '/catalog' },
  { id: 'explorer', title: 'Explorer', body: 'Try 5 different games.', reward: 800, progress: (s) => [Math.min(5, s.gamesPlayed), 5], cta: '/catalog' },
  { id: 'rocket-5x', title: 'To the moon', body: 'Cash out at 5× or more in Sky Rocket.', reward: 1000, progress: (s) => [s.bySlug['sky-rocket']?.best >= 5 ? 1 : 0, 1], cta: '/game/sky-rocket' },
  { id: 'crossing-5', title: 'Road warrior', body: 'Win a Cluck Crossing round.', reward: 600, progress: (s) => [Math.min(1, s.bySlug['cluck-crossing']?.wins ?? 0), 1], cta: '/game/cluck-crossing' },
  { id: 'big-10x', title: 'Big hitter', body: 'Land any 10× win.', reward: 1500, progress: (s) => [s.bestMultiplier >= 10 ? 1 : 0, 1], cta: '/catalog' },
  { id: 'all-games', title: 'Completionist', body: `Play all ${GAMES.length} games.`, reward: 3000, progress: (s) => [s.gamesPlayed, GAMES.length], cta: '/catalog' },
];

export const Promotion: React.FC = () => {
  const { t } = useI18n();
  const navigate = useNavigate();
  const [tab, setTab] = useState<'OPEN' | 'DONE'>('OPEN');
  const history = usePlayStore((s) => s.history);
  const claimed = usePlayStore((s) => s.claimedMissions);
  const stats = computeStats(history);
  const list = MISSIONS.filter((m) => (tab === 'DONE') === claimed.includes(m.id));

  return (
    <div className="space-y-4 text-left anim-fade-in">
      <PageHeader title={t('promotion')} />
      <div className="relative rounded-2xl gold-border-glow p-5 navy-gradient-bg overflow-hidden">
        <span className="inline-block px-2.5 py-1 text-[10px] font-black rounded-full gold-gradient-bg mb-2 uppercase tracking-widest">MISSIONS</span>
        <h2 className="text-lg font-black">Complete missions, earn bonus play credits</h2>
        <p className="text-xs text-slate-300 mt-1">{claimed.length}/{MISSIONS.length} completed</p>
        <div className="h-2 mt-3 rounded-full bg-[#1A2C4E] overflow-hidden"><div className="h-full gold-gradient-bg transition-all duration-700" style={{ width: `${(claimed.length / MISSIONS.length) * 100}%` }} /></div>
      </div>
      <div className="flex bg-[#12213D] p-1 rounded-xl border border-[#243A66]">
        {(['OPEN', 'DONE'] as const).map((k) => (
          <button key={k} onClick={() => setTab(k)} className={`flex-1 h-9 text-xs font-bold rounded-lg ${tab === k ? 'gold-gradient-bg text-white shadow-md' : 'text-slate-400'}`}>{k === 'OPEN' ? 'Active missions' : 'Completed'}</button>
        ))}
      </div>
      <div className="space-y-3">
        {list.length === 0 && (
          <div className="bg-[#12213D] border border-dashed border-[#243A66] rounded-2xl p-8 text-center">
            <Award className="w-8 h-8 text-[#C58937] mx-auto" />
            <p className="text-sm font-bold mt-2">{tab === 'DONE' ? 'No missions completed yet' : 'All missions completed!'}</p>
          </div>
        )}
        {list.map((m) => {
          const [cur, max] = m.progress(stats);
          const ready = cur >= max;
          const done = claimed.includes(m.id);
          return (
            <div key={m.id} className="bg-[#12213D] border border-[#243A66] rounded-2xl p-4 space-y-2 anim-slide-up">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <h3 className="text-sm font-black flex items-center gap-1.5"><Target className="w-4 h-4 text-[#C58937]" />{m.title}</h3>
                  <p className="text-xs text-slate-300 mt-0.5">{m.body}</p>
                </div>
                <span className="text-[10px] font-black px-2 py-1 rounded-full bg-[#C58937]/15 text-[#C58937] whitespace-nowrap">+{m.reward} credits</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="flex-1 h-2 rounded-full bg-[#1A2C4E] overflow-hidden"><div className="h-full bg-[#01A879] transition-all duration-700" style={{ width: `${(cur / max) * 100}%` }} /></div>
                <span className="text-[10px] font-bold text-slate-400">{cur}/{max}</span>
              </div>
              {done ? (
                <p className="text-xs font-bold text-[#01A879] flex items-center gap-1"><Check className="w-4 h-4" /> Claimed</p>
              ) : ready ? (
                <button onClick={() => playStore.claimMission(m.id, m.reward, m.title)} className="w-full h-10 rounded-xl gold-gradient-bg text-xs font-black anim-pulse-glow">Claim reward</button>
              ) : (
                <button onClick={() => navigate(m.cta)} className="w-full h-10 rounded-xl bg-[#1A2C4E] border border-[#243A66] text-xs font-bold flex items-center justify-center gap-1.5"><Lock className="w-3.5 h-3.5" /> Go play</button>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
