import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Coins, RotateCcw, History as HistoryIcon, Info, Gift } from 'lucide-react';
import { PageHeader } from '../components/layout/PageHeader.js';
import { useI18n } from '../context/I18nContext.js';
import { Modal } from '../components/common/Modal.js';
import { Button } from '../components/common/Button.js';
import { playStore, usePlayStore, STARTING_CREDITS } from '../core/state/playStore.js';
import { fmtCredits } from '../games/framework/session.js';

/** Play-credit wallet. Non-monetary: no deposits, withdrawals or payments exist. */
export const Wallet: React.FC = () => {
  const { t } = useI18n();
  const navigate = useNavigate();
  const credits = usePlayStore((s) => s.credits);
  const ledger = usePlayStore((s) => s.ledger);
  const [confirm, setConfirm] = useState(false);
  const [done, setDone] = useState(false);

  const earned = ledger.filter((l) => l.kind === 'payout').reduce((s, l) => s + l.amount, 0);
  const staked = -ledger.filter((l) => l.kind === 'stake').reduce((s, l) => s + l.amount, 0);
  const bonus = ledger.filter((l) => l.kind === 'bonus').reduce((s, l) => s + l.amount, 0);

  return (
    <div className="space-y-4 text-left anim-fade-in">
      <PageHeader title={t('wallet')} />

      <div className="bg-[#12213D] border gold-border-glow rounded-2xl p-5 shadow-2xl space-y-1 relative overflow-hidden">
        <div className="absolute -right-6 -top-6 w-28 h-28 rounded-full bg-[#C58937]/10 blur-xl" />
        <p className="text-xs text-slate-400 font-bold flex items-center gap-1.5"><Coins className="w-4 h-4 text-[#C58937]" /> Play credits</p>
        <p className="text-4xl font-black text-white tabular" data-testid="wallet-credits">{fmtCredits(credits)}</p>
        <p className="text-[11px] text-slate-400">For entertainment only · no cash value</p>
      </div>

      <div className="grid grid-cols-3 gap-2 text-center">
        {[['Staked', staked, 'text-[#E92844]'], ['Returned', earned, 'text-[#01A879]'], ['Bonuses', bonus, 'text-[#C58937]']].map(([k, v, c]) => (
          <div key={k as string} className="bg-[#12213D] border border-[#243A66] rounded-xl py-2.5">
            <p className="text-[9px] uppercase font-bold text-slate-400">{k}</p>
            <p className={`text-xs font-black ${c}`}>{fmtCredits(v as number)}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-3">
        <button onClick={() => setConfirm(true)} className="bg-[#12213D] border border-[#243A66] rounded-2xl p-4 flex flex-col items-center gap-2 hover:border-[#C58937] transition-colors">
          <RotateCcw className="w-6 h-6 text-[#C58937]" />
          <span className="text-xs font-bold">Reset credits</span>
        </button>
        <button onClick={() => navigate('/wallet/history')} className="bg-[#12213D] border border-[#243A66] rounded-2xl p-4 flex flex-col items-center gap-2 hover:border-[#C58937] transition-colors">
          <HistoryIcon className="w-6 h-6 text-[#01A879]" />
          <span className="text-xs font-bold">Credit ledger</span>
        </button>
        <button onClick={() => navigate('/activity')} className="bg-[#12213D] border border-[#243A66] rounded-2xl p-4 flex flex-col items-center gap-2 hover:border-[#C58937] transition-colors">
          <Gift className="w-6 h-6 text-[#E92844]" />
          <span className="text-xs font-bold">Daily check-in</span>
        </button>
        <button onClick={() => navigate('/menu/gifts')} className="bg-[#12213D] border border-[#243A66] rounded-2xl p-4 flex flex-col items-center gap-2 hover:border-[#C58937] transition-colors">
          <Gift className="w-6 h-6 text-[#A855F7]" />
          <span className="text-xs font-bold">Gift codes</span>
        </button>
      </div>

      <div className="p-4 bg-[#152542] border border-[#243A66] rounded-2xl flex gap-3 text-xs text-slate-300">
        <Info className="w-5 h-5 text-[#C58937] shrink-0" />
        <p>ALL WIN uses free play credits only. There are no deposits, withdrawals, purchases or payment methods, and credits can never be exchanged for money or prizes.</p>
      </div>

      <Modal isOpen={confirm} onClose={() => setConfirm(false)} title="Reset play credits?">
        <div className="space-y-5 pt-2">
          <p className="text-sm text-slate-200">Your balance will be set back to {fmtCredits(STARTING_CREDITS)} play credits. Your game history is kept.</p>
          <div className="grid grid-cols-2 gap-3">
            <Button variant="neutral" onClick={() => setConfirm(false)} className="py-2.5 text-xs">Cancel</Button>
            <Button variant="confirm" onClick={() => { playStore.resetCredits(); setConfirm(false); setDone(true); }} className="py-2.5 text-xs">Reset</Button>
          </div>
        </div>
      </Modal>
      <Modal isOpen={done} onClose={() => setDone(false)} title="Credits reset">
        <p className="text-sm text-slate-200">You now have {fmtCredits(STARTING_CREDITS)} play credits.</p>
        <Button fullWidth className="mt-4 py-2.5 text-xs" onClick={() => setDone(false)}>OK</Button>
      </Modal>
    </div>
  );
};
