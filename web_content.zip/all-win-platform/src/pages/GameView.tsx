import React, { Component, ReactNode, Suspense, lazy, useMemo, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { AlertTriangle, ArrowLeft, Heart, History as HistoryIcon, Info, Play, Trophy } from 'lucide-react';
import { getGame } from '../games/registry.js';
import type { GameModuleEntry } from '../games/framework/types.js';
import { playStore, usePlayStore, computeStats } from '../core/state/playStore.js';
import { fmtCredits } from '../games/framework/session.js';
import { RoundRow } from '../components/game/RoundRow.js';
import { EmptyState } from '../components/game/GameCard.js';

const NotFound: React.FC = () => {
  const navigate = useNavigate();
  return (
    <div className="p-6 pt-16 max-w-lg mx-auto">
      <EmptyState icon={<AlertTriangle className="w-5 h-5" />} title="Game not found" body="This game doesn't exist or has been moved."
        action={<button onClick={() => navigate('/catalog')} className="mt-2 px-4 h-10 rounded-xl gold-gradient-bg text-xs font-bold">Browse the lobby</button>} />
    </div>
  );
};

/** /game/:slug — detail & launch screen. */
export const GameDetail: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const game = getGame(slug);
  const history = usePlayStore((s) => s.history);
  const fav = usePlayStore((s) => !!slug && s.favorites.includes(slug));
  const credits = usePlayStore((s) => s.credits);
  if (!game) return <NotFound />;
  const { config, Thumbnail } = game;
  const mine = history.filter((h) => h.slug === config.slug);
  const stats = computeStats(mine);

  return (
    <div className="min-h-[100dvh] max-w-lg mx-auto pb-28 anim-fade-in">
      <div className="relative p-5 pt-4 overflow-hidden" style={{ background: `linear-gradient(180deg, ${config.accent}40 0%, #0B0E14 100%)` }}>
        <div className="flex items-center justify-between">
          <button aria-label="Back" onClick={() => navigate(-1)} className="w-10 h-10 rounded-xl bg-[#12213D]/80 border border-[#243A66] flex items-center justify-center"><ArrowLeft className="w-5 h-5" /></button>
          <button aria-label="Favourite" onClick={() => playStore.toggleFavorite(config.slug)} className="w-10 h-10 rounded-xl bg-[#12213D]/80 border border-[#243A66] flex items-center justify-center">
            <Heart className={`w-5 h-5 ${fav ? 'fill-[#E92844] text-[#E92844]' : 'text-slate-300'}`} />
          </button>
        </div>
        <div className="flex flex-col items-center text-center mt-2">
          <Thumbnail className="w-36 h-36 drop-shadow-2xl anim-pop" />
          <span className="mt-2 text-[10px] font-black px-2 py-0.5 rounded-md bg-[#1A2C4E] border border-[#243A66] text-[#C58937] uppercase">{config.badge}</span>
          <h1 className="text-2xl font-black mt-2">{config.name}</h1>
          <p className="text-xs text-slate-300 mt-1 max-w-[300px]">{config.tagline}</p>
        </div>
      </div>

      <div className="px-4 space-y-4">
        <div className="grid grid-cols-3 gap-2 text-center">
          {[['Category', config.category], ['RTP', config.rtp], ['Stake', `${config.minStake}–${fmtCredits(config.maxStake)}`]].map(([k, v]) => (
            <div key={k} className="bg-[#12213D] border border-[#243A66] rounded-xl py-2.5">
              <p className="text-[9px] uppercase font-bold text-slate-400">{k}</p>
              <p className="text-xs font-black">{v}</p>
            </div>
          ))}
        </div>

        <section className="bg-[#12213D] border border-[#243A66] rounded-2xl p-4 space-y-2">
          <h3 className="text-xs font-bold flex items-center gap-1.5"><Info className="w-4 h-4 text-[#C58937]" /> About</h3>
          <p className="text-xs text-slate-300 leading-relaxed">{config.description}</p>
          <ol className="text-xs text-slate-300 list-decimal pl-4 space-y-1 pt-1">
            {config.howToPlay.map((s) => <li key={s}>{s}</li>)}
          </ol>
        </section>

        <section className="bg-[#12213D] border border-[#243A66] rounded-2xl p-4">
          <h3 className="text-xs font-bold flex items-center gap-1.5 mb-3"><Trophy className="w-4 h-4 text-[#C58937]" /> Your stats</h3>
          <div className="grid grid-cols-4 gap-2 text-center">
            {[['Rounds', stats.rounds], ['Wins', stats.wins], ['Best', `${stats.bestMultiplier.toFixed(2)}×`], ['Net', fmtCredits(stats.net)]].map(([k, v]) => (
              <div key={k as string}><p className="text-[9px] text-slate-400 uppercase font-bold">{k}</p><p className={`text-xs font-black ${k === 'Net' ? (stats.net >= 0 ? 'text-[#01A879]' : 'text-[#E92844]') : ''}`}>{v}</p></div>
            ))}
          </div>
        </section>

        <section className="bg-[#12213D] border border-[#243A66] rounded-2xl overflow-hidden">
          <h3 className="text-xs font-bold flex items-center gap-1.5 p-4 pb-2"><HistoryIcon className="w-4 h-4 text-[#C58937]" /> Recent rounds</h3>
          {mine.length ? (
            <div className="divide-y divide-[#243A66]/50">{mine.slice(0, 5).map((r) => <RoundRow key={r.id} r={r} />)}</div>
          ) : <p className="text-xs text-slate-500 px-4 pb-4">No rounds yet — launch the game to play your first.</p>}
        </section>
      </div>

      <div className="fixed bottom-0 inset-x-0 z-40 bg-[#12213D] border-t border-[#243A66] safe-area-bottom">
        <div className="max-w-lg mx-auto p-3 flex items-center gap-3">
          <div className="text-xs"><p className="text-slate-400">Credits</p><p className="font-black text-[#01A879]">{fmtCredits(credits)}</p></div>
          <button onClick={() => navigate(`/game/${config.slug}/play`)} className="flex-1 min-h-[52px] rounded-xl gold-gradient-bg font-black uppercase tracking-wider text-sm flex items-center justify-center gap-2 shadow-lg active:scale-[0.98] anim-pulse-glow">
            <Play className="w-4 h-4 fill-current" /> Launch game
          </button>
        </div>
      </div>
    </div>
  );
};

/* ---------------- play screen ---------------- */

const lazyCache = new Map<string, React.LazyExoticComponent<React.ComponentType>>();
const lazyFor = (g: GameModuleEntry, attempt: number) => {
  const key = `${g.config.slug}#${attempt}`;
  if (!lazyCache.has(key)) lazyCache.set(key, lazy(g.load));
  return lazyCache.get(key)!;
};

const GameLoading: React.FC<{ game: GameModuleEntry }> = ({ game }) => {
  const T = game.Thumbnail;
  return (
    <div className="min-h-[100dvh] max-w-lg mx-auto flex flex-col items-center justify-center gap-4 anim-fade-in" data-testid="game-loading">
      <T className="w-24 h-24 animate-pulse" />
      <div className="w-10 h-10 rounded-full border-4 border-[#243A66] border-t-[#C58937] anim-spin" />
      <p className="text-xs font-bold text-slate-300 uppercase tracking-widest">Loading {game.config.name}…</p>
    </div>
  );
};

class GameErrorBoundary extends Component<{ children: ReactNode; onRetry: () => void; name: string }, { error: Error | null }> {
  state = { error: null as Error | null };
  static getDerivedStateFromError(error: Error) {
    return { error };
  }
  render() {
    if (!this.state.error) return this.props.children;
    return (
      <div className="min-h-[100dvh] max-w-lg mx-auto p-6 flex items-center">
        <EmptyState icon={<AlertTriangle className="w-5 h-5" />} title={`${this.props.name} failed to load`} body="Check your connection and try again."
          action={
            <div className="flex gap-2 mt-2">
              <button onClick={() => history.back()} className="px-4 h-10 rounded-xl bg-[#1A2C4E] border border-[#243A66] text-xs font-bold">Go back</button>
              <button onClick={() => { this.setState({ error: null }); this.props.onRetry(); }} className="px-4 h-10 rounded-xl gold-gradient-bg text-xs font-bold">Retry</button>
            </div>
          } />
      </div>
    );
  }
}

/** /game/:slug/play — mounts the game's own lazily loaded module. */
export const GamePlay: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const game = getGame(slug);
  const [attempt, setAttempt] = useState(0);
  const Lazy = useMemo(() => (game ? lazyFor(game, attempt) : null), [game, attempt]);
  if (!game || !Lazy) return <NotFound />;
  return (
    <GameErrorBoundary name={game.config.name} onRetry={() => setAttempt((a) => a + 1)}>
      <Suspense fallback={<GameLoading game={game} />}>
        <Lazy key={`${game.config.slug}-${attempt}`} />
      </Suspense>
    </GameErrorBoundary>
  );
};
