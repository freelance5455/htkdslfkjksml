import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Crown, CheckCircle2, Lock } from 'lucide-react';
import { PageHeader } from '../components/layout/PageHeader.js';
import { useI18n } from '../context/I18nContext.js';
import { usePlayStore } from '../core/state/playStore.js';
import { vipLevel } from './Profile.js';

const LEVELS = [
  { level: 1, need: 0, perks: ['Access to all games', 'Daily check-in'] },
  { level: 2, need: 25, perks: ['Bronze profile badge'] },
  { level: 3, need: 80, perks: ['Silver profile badge'] },
  { level: 4, need: 200, perks: ['Gold profile badge'] },
  { level: 5, need: 500, perks: ['Diamond profile badge', 'Hall of fame'] },
];

/** Player levels are earned by playing rounds – cosmetic only, nothing to buy. */
export const Vip: React.FC = () => {
  const { t } = useI18n();
  const navigate = useNavigate();
  const rounds = usePlayStore((s) => s.history.length);
  const lvl = vipLevel(rounds);
  const next = LEVELS.find((l) => l.level === lvl + 1);
  const cur = LEVELS[lvl - 1];
  const pct = next ? ((rounds - cur.need) / (next.need - cur.need)) * 100 : 100;

  return (
    <div className="space-y-4 text-left anim-fade-in">
      <PageHeader title={t('vip')} />
      <div className="bg-[#12213D] border gold-border-glow rounded-2xl p-5 shadow-2xl space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-sm font-black flex items-center gap-2"><Crown className="w-6 h-6 text-amber-400" /> Player Level {lvl}</span>
          <span className="text-xs font-bold text-[#C58937]">{rounds} rounds</span>
        </div>
        <div className="w-full bg-[#1A2C4E] h-2.5 rounded-full overflow-hidden border border-[#243A66]">
          <div className="gold-gradient-bg h-full rounded-full transition-all duration-700" style={{ width: `${Math.min(100, pct)}%` }} />
        </div>
        <p className="text-[10px] text-slate-400 text-right">{next ? `${next.need - rounds} rounds to Level ${next.level}` : 'Max level reached'}</p>
        <button onClick={() => navigate('/catalog')} className="w-full h-11 rounded-xl gold-gradient-bg text-xs font-black">Play to level up</button>
      </div>
      <div className="space-y-2">
        {LEVELS.map((l) => (
          <div key={l.level} className={`bg-[#12213D] border rounded-2xl p-3.5 flex items-start gap-3 ${l.level === lvl ? 'border-[#C58937]' : 'border-[#243A66]'}`}>
            {l.level <= lvl ? <CheckCircle2 className="w-5 h-5 text-[#01A879] shrink-0" /> : <Lock className="w-5 h-5 text-slate-500 shrink-0" />}
            <div>
              <p className="text-xs font-black">Level {l.level} <span className="text-slate-400 font-bold">· {l.need}+ rounds</span></p>
              <p className="text-[11px] text-slate-300">{l.perks.join(' · ')}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
