import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { PhoneInput } from '../components/common/PhoneInput.js';
import { PasswordInput } from '../components/common/PasswordInput.js';
import { Button } from '../components/common/Button.js';
import { ROUTES } from '../core/config/routes.js';
import { useI18n } from '../context/I18nContext.js';
import { validateBangladeshPhoneNumber } from '../core/types/domains.js';
import { Headphones, Unlock } from 'lucide-react';

export const Login: React.FC = () => {
  const { t, language, setLanguage } = useI18n();
  const navigate = useNavigate();

  const [loginTab, setLoginTab] = useState<'PHONE' | 'EMAIL'>('PHONE');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [rememberPassword, setRememberPassword] = useState(true);
  const [isLoading, setIsLoading] = useState(false);

  const phoneValidation = validateBangladeshPhoneNumber(phone);
  const isFormValid = loginTab === 'PHONE' ? (phoneValidation.isValid && password.length >= 6) : (email.includes('@') && password.length >= 6);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isFormValid || isLoading) return;

    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      navigate(ROUTES.HOME);
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-[#0B0E14] text-white p-4 flex flex-col justify-between max-w-lg mx-auto">
      <div>
        <header className="flex items-center justify-between py-3 border-b border-[#243A66]">
          <Link to={ROUTES.HOME} className="text-slate-400 hover:text-white text-sm font-semibold">
            ← Home
          </Link>
          <div className="flex items-center gap-1.5 font-black text-[#C58937] text-lg">
            <div className="w-7 h-7 rounded-md gold-gradient-bg flex items-center justify-center text-white text-xs font-black">AW</div>
            ALL WIN
          </div>
          <button
            onClick={() => setLanguage(language === 'EN' ? 'BN' : 'EN')}
            className="px-2 py-1 text-xs font-bold rounded-lg bg-[#1A2C4E] border border-[#243A66] text-[#C58937]"
          >
            {language}
          </button>
        </header>

        <div className="mt-6 mb-4 text-left">
          <h1 className="text-2xl font-black text-white tracking-wide">{t('loginTitle')}</h1>
          <p className="text-xs text-slate-400 mt-1">{t('loginSubtitle')}</p>
        </div>

        {/* Login Tabs */}
        <div className="flex border-b border-[#243A66] mb-5">
          <button
            onClick={() => setLoginTab('PHONE')}
            className={`flex-1 py-2.5 text-xs font-bold transition-all border-b-2 ${
              loginTab === 'PHONE' ? 'border-[#C58937] text-[#C58937]' : 'border-transparent text-slate-400'
            }`}
          >
            {t('phoneLoginTab')}
          </button>
          <button
            onClick={() => setLoginTab('EMAIL')}
            className={`flex-1 py-2.5 text-xs font-bold transition-all border-b-2 ${
              loginTab === 'EMAIL' ? 'border-[#C58937] text-[#C58937]' : 'border-transparent text-slate-400'
            }`}
          >
            {t('emailLoginTab')}
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {loginTab === 'PHONE' ? (
            <PhoneInput
              label={t('phoneNumber')}
              value={phone}
              onChange={setPhone}
            />
          ) : (
            <div className="flex flex-col gap-1.5 text-left w-full">
              <label className="text-xs font-medium text-slate-300">Email Address</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter email address"
                className="w-full bg-[#12213D] border border-[#243A66] rounded-xl px-3.5 py-3 text-sm text-white focus:outline-none focus:ring-1 focus:ring-[#C58937]"
              />
            </div>
          )}

          <PasswordInput
            label={t('setPassword')}
            value={password}
            onChange={setPassword}
          />

          <div className="flex items-center gap-2 text-left">
            <input
              type="checkbox"
              id="remember"
              checked={rememberPassword}
              onChange={(e) => setRememberPassword(e.target.checked)}
              className="w-4 h-4 accent-[#C58937] rounded cursor-pointer"
            />
            <label htmlFor="remember" className="text-xs text-slate-300 cursor-pointer">
              {t('rememberPassword')}
            </label>
          </div>

          <Button
            type="submit"
            variant="primary"
            fullWidth
            disabled={!isFormValid}
            isLoading={isLoading}
            className="mt-2 py-3.5 text-base font-extrabold"
          >
            {t('loginBtn')}
          </Button>

          <Button
            type="button"
            variant="secondary"
            fullWidth
            onClick={() => navigate(ROUTES.REGISTER)}
            className="py-3 text-sm font-bold"
          >
            {t('registerBtn')}
          </Button>
        </form>
      </div>

      <div className="py-6 flex items-center justify-between text-xs text-slate-400 border-t border-[#243A66]/50 mt-6">
        <Link to={ROUTES.CUSTOMER_SERVICE} className="flex items-center gap-1.5 hover:text-white transition-colors">
          <Unlock className="w-4 h-4 text-[#C58937]" />
          <span>{t('forgotPassword')}</span>
        </Link>

        <Link to={ROUTES.CUSTOMER_SERVICE} className="flex items-center gap-1.5 hover:text-white transition-colors">
          <Headphones className="w-4 h-4 text-[#01A879]" />
          <span>{t('customerService')}</span>
        </Link>
      </div>
    </div>
  );
};
