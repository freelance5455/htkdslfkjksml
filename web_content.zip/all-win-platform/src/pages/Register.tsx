import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { PhoneInput } from '../components/common/PhoneInput.js';
import { PasswordInput } from '../components/common/PasswordInput.js';
import { Button } from '../components/common/Button.js';
import { ROUTES } from '../core/config/routes.js';
import { useI18n } from '../context/I18nContext.js';
import { validateBangladeshPhoneNumber } from '../core/types/domains.js';

export const Register: React.FC = () => {
  const { t, language, setLanguage } = useI18n();
  const navigate = useNavigate();

  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [inviteCode, setInviteCode] = useState('');
  const [agreePrivacy, setAgreedPrivacy] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [submitError, setSubmitError] = useState('');

  const phoneValidation = validateBangladeshPhoneNumber(phone);
  const isFormValid = phoneValidation.isValid && password.length >= 6 && password === confirmPassword && agreePrivacy;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isFormValid || isLoading) return;

    setIsLoading(true);
    setSubmitError('');

    setTimeout(() => {
      setIsLoading(false);
      navigate(ROUTES.HOME);
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-[#0B0E14] text-white p-4 flex flex-col justify-between max-w-lg mx-auto">
      <div>
        {/* Register Top Header */}
        <header className="flex items-center justify-between py-3 border-b border-[#243A66]">
          <Link to={ROUTES.LOGIN} className="text-slate-400 hover:text-white text-sm font-semibold">
            ← Back
          </Link>
          <div className="flex items-center gap-1.5 font-black text-[#C58937] text-lg">
            <div className="w-7 h-7 rounded-md gold-gradient-bg flex items-center justify-center text-white text-xs font-black">AW</div>
            ALL WIN
          </div>
          <button
            onClick={() => setLanguage(language === 'EN' ? 'BN' : 'EN')}
            className="px-2 py-1 text-xs font-bold rounded-lg bg-[#1A2C4E] border border-[#243A66] text-[#C58937]"
          >
            {language}
          </button>
        </header>

        {/* Title */}
        <div className="mt-6 mb-6 text-left">
          <h1 className="text-2xl font-black text-white tracking-wide">{t('registerTitle')}</h1>
          <p className="text-xs text-slate-400 mt-1">{t('registerSubtitle')}</p>
        </div>

        {/* Registration Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <PhoneInput
            label={t('phoneNumber')}
            value={phone}
            onChange={setPhone}
          />

          <PasswordInput
            label={t('setPassword')}
            value={password}
            onChange={setPassword}
          />

          <PasswordInput
            label={t('confirmPassword')}
            value={confirmPassword}
            onChange={setConfirmPassword}
          />

          <div className="flex flex-col gap-1.5 text-left w-full">
            <label className="text-xs font-medium text-slate-300">{t('inviteCode')}</label>
            <input
              type="text"
              value={inviteCode}
              onChange={(e) => setInviteCode(e.target.value)}
              placeholder="Please enter invitation code"
              className="w-full bg-[#12213D] border border-[#243A66] rounded-xl px-3.5 py-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-[#C58937]"
            />
          </div>

          <div className="flex items-center gap-2 pt-2 text-left">
            <input
              type="checkbox"
              id="privacy"
              checked={agreePrivacy}
              onChange={(e) => setAgreedPrivacy(e.target.checked)}
              className="w-4 h-4 accent-[#C58937] rounded cursor-pointer"
            />
            <label htmlFor="privacy" className="text-xs text-slate-300 cursor-pointer">
              {t('privacyAgreement')}
            </label>
          </div>

          {submitError && <p className="text-xs text-[#E92844]">{submitError}</p>}

          <Button
            type="submit"
            variant="primary"
            fullWidth
            disabled={!isFormValid}
            isLoading={isLoading}
            className="mt-4 py-3.5 text-base font-extrabold"
          >
            {t('registerBtn')}
          </Button>
        </form>
      </div>

      <div className="py-6 text-center">
        <Link to={ROUTES.LOGIN} className="text-xs font-semibold text-[#C58937] hover:underline">
          {t('alreadyHaveAccount')}
        </Link>
      </div>
    </div>
  );
};
