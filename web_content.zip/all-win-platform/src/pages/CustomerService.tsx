import React from 'react';
import { PageHeader } from '../components/layout/PageHeader.js';
import { Headphones, MessageSquare, ShieldCheck, HelpCircle } from 'lucide-react';
import { useI18n } from '../context/I18nContext.js';

export const CustomerService: React.FC = () => {
  const { t } = useI18n();

  return (
    <div className="space-y-4">
      <PageHeader title={t('customerService')} />

      <div className="bg-[#12213D] border border-[#243A66] rounded-2xl p-5 text-center shadow-lg space-y-3">
        <div className="w-12 h-12 rounded-full gold-gradient-bg flex items-center justify-center mx-auto text-white shadow-md">
          <Headphones className="w-6 h-6" />
        </div>
        <h2 className="text-lg font-black text-white">24/7 Live Customer Support</h2>
        <p className="text-xs text-slate-300">
          Questions about the games, play credits or your profile? Check the answers below.
        </p>

        <a href="mailto:support@allwin.example" className="w-full py-3 px-4 rounded-xl gold-gradient-bg text-white font-bold text-sm shadow-lg flex items-center justify-center gap-2 hover:brightness-110 active:scale-[0.98] transition-all">
          <MessageSquare className="w-4 h-4" />
          Email support
        </a>
      </div>

      <div className="bg-[#12213D] border border-[#243A66] rounded-2xl p-4 space-y-3 text-left">
        <h3 className="text-sm font-bold text-[#C58937] flex items-center gap-2">
          <HelpCircle className="w-4 h-4 text-[#C58937]" /> Frequently Asked Questions
        </h3>
        <div className="space-y-2 text-xs text-slate-300">
          <div className="p-3 bg-[#1A2C4E] rounded-xl border border-[#243A66]">
            <p className="font-bold text-white mb-1">Are play credits real money?</p>
            <p className="text-slate-400">No. Credits are free, have no cash value and cannot be bought, withdrawn or exchanged.</p>
          </div>
          <div className="p-3 bg-[#1A2C4E] rounded-xl border border-[#243A66]">
            <p className="font-bold text-white mb-1">I ran out of credits — what now?</p>
            <p className="text-slate-400">Open Wallet and tap Reset credits, claim your daily check-in, or complete missions.</p>
          </div>
          <div className="p-3 bg-[#1A2C4E] rounded-xl border border-[#243A66]">
            <p className="font-bold text-white mb-1">Where is my progress stored?</p>
            <p className="text-slate-400">On this device only. Clearing browser data resets your profile and history.</p>
          </div>
        </div>
      </div>

      <div className="p-4 bg-[#152542] border border-[#243A66] rounded-2xl flex items-center gap-3 text-xs text-slate-300">
        <ShieldCheck className="w-6 h-6 text-[#01A879] flex-shrink-0" />
        <span>All games are original implementations using play credits only.</span>
      </div>
    </div>
  );
};
