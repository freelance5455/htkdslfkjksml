import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Copy, Check, Crown, Pencil, Calendar } from 'lucide-react';
import { PageHeader } from '../components/layout/PageHeader.js';
import { useI18n } from '../context/I18nContext.js';
import { Modal } from '../components/common/Modal.js';
import { Button } from '../components/common/Button.js';
import { playStore, usePlayStore, computeStats } from '../core/state/playStore.js';
import { GAMES } from '../games/registry.js';
import { fmtCredits } from '../games/framework/session.js';

export const AVATAR_COLORS = ['#C58937', '#01A879', '#E92844', '#3B82F6', '#A855F7', '#F59E0B'];

export const vipLevel = (rounds: number) => (rounds >= 500 ? 5 : rounds >= 200 ? 4 : rounds >= 80 ? 3 : rounds >= 25 ? 2 : 1);

export const Profile: React.FC = () => {
  const { t } = useI18n();
  const navigate = useNavigate();
  const profile = usePlayStore((s) => s.profile);
  const history = usePlayStore((s) => s.history);
  const credits = usePlayStore((s) => s.credits);
  const [copied, setCopied] = useState(false);
  const [edit, setEdit] = useState(false);
  const [name, setName] = useState(profile.nickname);
  const [avatar, setAvatar] = useState(profile.avatar);
  const [err, setErr] = useState('');
  const stats = computeStats(history);
  const uid = 'AW' + profile.joined.toString(36).toUpperCase().slice(-6);

  const copy = () => {
    navigator.clipboard?.writeText(uid).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };
  const save = () => {
    const n = name.trim();
    if (n.length < 3 || n.length > 18) return setErr('Nickname must be 3–18 characters.');
    if (!/^[\w .-]+$/.test(n)) return setErr('Use letters, numbers, spaces, dots, dashes or underscores.');
    playStore.updateProfile({ nickname: n, avatar });
    setEdit(false);
  };

  const ranked = GAMES.map((g) => ({ g, s: stats.bySlug[g.config.slug] })).filter((x) => x.s).sort((a, b) => b.s!.rounds - a.s!.rounds);

  return (
    <div className="space-y-4 text-left anim-fade-in">
      <PageHeader title={t('profile')} />
      <div className="bg-[#12213D] border gold-border-glow rounded-2xl p-5 shadow-2xl text-center space-y-3">
        <div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto text-white text-2xl font-black shadow-lg" style={{ background: AVATAR_COLORS[profile.avatar] }}>
          {profile.nickname.slice(0, 1).toUpperCase()}
        </div>
        <div>
          <h2 className="text-lg font-black text-white flex items-center justify-center gap-2">
            {profile.nickname}
            <button aria-label="Edit profile" onClick={() => { setName(profile.nickname); setAvatar(profile.avatar); setErr(''); setEdit(true); }} className="w-8 h-8 rounded-lg bg-[#1A2C4E] border border-[#243A66] flex items-center justify-center"><Pencil className="w-3.5 h-3.5" /></button>
          </h2>
          <button onClick={() => navigate('/vip')} className="flex items-center justify-center gap-1.5 mt-1 text-xs font-bold text-[#C58937] mx-auto">
            <Crown className="w-4 h-4 text-amber-400" /> Level {vipLevel(stats.rounds)} Player
          </button>
        </div>
        <div className="flex items-center justify-center gap-2">
          <div className="bg-[#1A2C4E] border border-[#243A66] rounded-xl px-3 py-1.5 font-mono text-xs font-bold text-slate-300">UID: {uid}</div>
          <button onClick={copy} className="px-3 py-1.5 rounded-xl gold-gradient-bg text-white text-xs font-bold shadow-md flex items-center gap-1">
            {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}{copied ? 'Copied' : 'Copy'}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        {[['Play credits', fmtCredits(credits), 'text-[#01A879]'], ['Rounds', String(stats.rounds), 'text-white'], ['Win rate', `${stats.winRate.toFixed(1)}%`, 'text-[#C58937]'], ['Games tried', `${stats.gamesPlayed}/${GAMES.length}`, 'text-white']].map(([k, v, c]) => (
          <div key={k} className="bg-[#12213D] border border-[#243A66] rounded-xl p-3">
            <p className="text-[10px] text-slate-400">{k}</p>
            <p className={`text-base font-black ${c}`}>{v}</p>
          </div>
        ))}
      </div>

      <div className="bg-[#12213D] border border-[#243A66] rounded-2xl p-4 space-y-2">
        <h3 className="text-xs font-bold">Favourite games</h3>
        {ranked.length ? ranked.slice(0, 5).map(({ g, s }) => (
          <button key={g.config.slug} onClick={() => navigate(`/game/${g.config.slug}`)} className="w-full flex items-center gap-3 p-2 rounded-xl bg-[#1A2C4E] border border-[#243A66]">
            <g.Thumbnail className="w-8 h-8" />
            <span className="flex-1 text-left text-xs font-bold">{g.config.name}</span>
            <span className="text-[10px] text-slate-400">{s!.rounds} rounds</span>
          </button>
        )) : <p className="text-xs text-slate-500">Play some games to see your favourites here.</p>}
        <p className="text-[10px] text-slate-500 flex items-center gap-1 pt-1"><Calendar className="w-3 h-3" /> Joined {new Date(profile.joined).toLocaleDateString()}</p>
      </div>

      <Modal isOpen={edit} onClose={() => setEdit(false)} title="Edit profile">
        <div className="space-y-4 text-left">
          <label className="block">
            <span className="text-xs font-bold text-slate-300">Nickname</span>
            <input value={name} onChange={(e) => { setName(e.target.value); setErr(''); }} className="mt-1 w-full h-11 bg-[#1A2C4E] border border-[#243A66] rounded-xl px-3 text-sm outline-none focus:border-[#C58937]" />
          </label>
          {err && <p className="text-xs text-[#E92844] font-bold">{err}</p>}
          <div>
            <span className="text-xs font-bold text-slate-300">Avatar colour</span>
            <div className="flex gap-2 mt-2">
              {AVATAR_COLORS.map((c, i) => (
                <button key={c} aria-label={`Avatar colour ${i + 1}`} onClick={() => setAvatar(i)} className={`w-10 h-10 rounded-full ${avatar === i ? 'ring-2 ring-white ring-offset-2 ring-offset-[#12213D]' : ''}`} style={{ background: c }} />
              ))}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3 pt-2">
            <Button variant="neutral" onClick={() => setEdit(false)} className="py-2.5 text-xs">Cancel</Button>
            <Button variant="confirm" onClick={save} className="py-2.5 text-xs">Save</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
