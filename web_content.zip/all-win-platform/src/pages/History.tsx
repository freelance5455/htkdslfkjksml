import React, { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { History as HistoryIcon, ArrowDownLeft, ArrowUpRight, Gift, RotateCcw } from 'lucide-react';
import { PageHeader } from '../components/layout/PageHeader.js';
import { useI18n } from '../context/I18nContext.js';
import { usePlayStore } from '../core/state/playStore.js';
import { RoundRow, timeAgo } from '../components/game/RoundRow.js';
import { EmptyState } from '../components/game/GameCard.js';
import { GAMES } from '../games/registry.js';
import { fmtCredits } from '../games/framework/session.js';

type Tab = 'GAME' | 'LEDGER';
type Filter = 'all' | 'win' | 'lose';

/** /history (game rounds) and /wallet/history (credit ledger). */
export const History: React.FC = () => {
  const { t } = useI18n();
  const location = useLocation();
  const navigate = useNavigate();
  const [tab, setTab] = useState<Tab>(location.pathname.startsWith('/wallet') ? 'LEDGER' : 'GAME');
  const [game, setGame] = useState('all');
  const [filter, setFilter] = useState<Filter>('all');
  const history = usePlayStore((s) => s.history);
  const ledger = usePlayStore((s) => s.ledger);

  const rows = history.filter((r) => (game === 'all' || r.slug === game) && (filter === 'all' || (filter === 'win' ? r.outcome === 'win' : r.outcome !== 'win')));

  return (
    <div className="space-y-4 text-left anim-fade-in">
      <PageHeader title={t('history')} />
      <div className="flex bg-[#12213D] p-1 rounded-xl border border-[#243A66]">
        {(['GAME', 'LEDGER'] as Tab[]).map((k) => (
          <button key={k} onClick={() => setTab(k)} className={`flex-1 h-9 text-xs font-bold rounded-lg transition-all ${tab === k ? 'gold-gradient-bg text-white shadow-md' : 'text-slate-400'}`}>
            {k === 'GAME' ? t('gameHistory') : 'Credit ledger'}
          </button>
        ))}
      </div>

      {tab === 'GAME' ? (
        <>
          <div className="flex gap-2">
            <select aria-label="Filter by game" value={game} onChange={(e) => setGame(e.target.value)} className="flex-1 h-10 rounded-xl bg-[#12213D] border border-[#243A66] px-3 text-xs font-bold">
              <option value="all">All games</option>
              {GAMES.map((g) => <option key={g.config.slug} value={g.config.slug}>{g.config.name}</option>)}
            </select>
            <div className="flex bg-[#12213D] border border-[#243A66] rounded-xl p-1">
              {(['all', 'win', 'lose'] as Filter[]).map((f) => (
                <button key={f} onClick={() => setFilter(f)} className={`px-3 rounded-lg text-[11px] font-bold capitalize ${filter === f ? 'bg-[#243A66] text-white' : 'text-slate-400'}`}>{f}</button>
              ))}
            </div>
          </div>
          {rows.length ? (
            <div className="bg-[#12213D] border border-[#243A66] rounded-2xl divide-y divide-[#243A66]/50 overflow-hidden">{rows.map((r) => <RoundRow key={r.id} r={r} />)}</div>
          ) : (
            <EmptyState icon={<HistoryIcon className="w-5 h-5" />} title="No rounds found" body={history.length ? 'Try a different filter.' : 'Your game rounds will appear here once you play.'}
              action={!history.length ? <button onClick={() => navigate('/catalog')} className="mt-2 px-4 h-10 rounded-xl gold-gradient-bg text-xs font-bold">Play a game</button> : undefined} />
          )}
        </>
      ) : ledger.length ? (
        <div className="bg-[#12213D] border border-[#243A66] rounded-2xl divide-y divide-[#243A66]/50 overflow-hidden">
          {ledger.map((l) => (
            <div key={l.id} className="p-3 flex items-center gap-3">
              <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${l.amount >= 0 ? 'bg-[#01A879]/15 text-[#01A879]' : 'bg-[#E92844]/15 text-[#E92844]'}`}>
                {l.kind === 'bonus' ? <Gift className="w-4 h-4" /> : l.kind === 'reset' ? <RotateCcw className="w-4 h-4" /> : l.amount >= 0 ? <ArrowDownLeft className="w-4 h-4" /> : <ArrowUpRight className="w-4 h-4" />}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-bold truncate">{l.label}</p>
                <p className="text-[10px] text-slate-500">{timeAgo(l.ts)}</p>
              </div>
              <span className={`text-xs font-extrabold ${l.amount >= 0 ? 'text-[#01A879]' : 'text-[#E92844]'}`}>{l.amount >= 0 ? '+' : ''}{fmtCredits(l.amount)}</span>
            </div>
          ))}
        </div>
      ) : (
        <EmptyState icon={<HistoryIcon className="w-5 h-5" />} title="Ledger is empty" body="Play-credit movements will be listed here." />
      )}
    </div>
  );
};
