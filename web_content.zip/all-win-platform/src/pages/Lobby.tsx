import React, { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Search, Gamepad2 } from 'lucide-react';
import { PageHeader } from '../components/layout/PageHeader.js';
import { GAMES, categoryFromSlug, categorySlug } from '../games/registry.js';
import { LOBBY_CATEGORIES } from '../games/framework/types.js';
import { GameCard, EmptyState } from '../components/game/GameCard.js';

/** Game lobby: search + category tabs. Routes: /catalog and /catalog/:category */
export const Lobby: React.FC = () => {
  const { category } = useParams<{ category: string }>();
  const navigate = useNavigate();
  const active = categoryFromSlug(category);
  const [q, setQ] = useState('');

  const list = GAMES.filter((g) => (!active || g.config.category === active) && (g.config.name + g.config.tagline).toLowerCase().includes(q.toLowerCase()));

  return (
    <div className="space-y-4 text-left anim-fade-in">
      <PageHeader title={active ? active : 'Game Lobby'} />
      <label className="flex items-center gap-2 px-4 h-11 rounded-xl bg-[#12213D] border border-[#243A66] focus-within:border-[#C58937]">
        <Search className="w-4 h-4 text-slate-400" />
        <input aria-label="Search games" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search games…" className="flex-1 bg-transparent text-sm outline-none placeholder:text-slate-500" />
      </label>
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        <button onClick={() => navigate('/catalog')} className={`px-3.5 h-9 rounded-xl text-xs font-bold whitespace-nowrap ${!active ? 'gold-gradient-bg text-white' : 'bg-[#12213D] border border-[#243A66] text-slate-300'}`}>All ({GAMES.length})</button>
        {LOBBY_CATEGORIES.map((c) => (
          <button key={c} onClick={() => navigate(`/catalog/${categorySlug(c)}`)} className={`px-3.5 h-9 rounded-xl text-xs font-bold whitespace-nowrap ${active === c ? 'gold-gradient-bg text-white' : 'bg-[#12213D] border border-[#243A66] text-slate-300'}`}>
            {c} ({GAMES.filter((g) => g.config.category === c).length})
          </button>
        ))}
      </div>
      {list.length ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3.5" key={(active ?? 'all') + q}>
          {list.map((g) => <GameCard key={g.config.slug} game={g} />)}
        </div>
      ) : (
        <EmptyState icon={<Gamepad2 className="w-5 h-5" />} title="No games found" body={q ? `Nothing matches “${q}”.` : 'This category is empty.'}
          action={<button onClick={() => { setQ(''); navigate('/catalog'); }} className="mt-2 px-4 h-9 rounded-xl gold-gradient-bg text-xs font-bold">Show all games</button>} />
      )}
    </div>
  );
};
