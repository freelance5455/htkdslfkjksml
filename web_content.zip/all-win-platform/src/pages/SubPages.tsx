import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Gift, BarChart2, Bell, Shield, HeartHandshake, Settings as SettingsIcon, Volume2, VolumeX, Globe, Trash2, Clock } from 'lucide-react';
import { PageHeader } from '../components/layout/PageHeader.js';
import { useI18n } from '../context/I18nContext.js';
import { Button } from '../components/common/Button.js';
import { Modal } from '../components/common/Modal.js';
import { playStore, usePlayStore, computeStats } from '../core/state/playStore.js';
import { soundSettings, useSoundSettings, useGameSound, UI_SOUNDS } from '../games/framework/sound.js';
import { GAMES } from '../games/registry.js';
import { fmtCredits } from '../games/framework/session.js';
import { timeAgo } from '../components/game/RoundRow.js';
import { EmptyState } from '../components/game/GameCard.js';

const Card: React.FC<{ children: React.ReactNode; className?: string }> = ({ children, className = '' }) => (
  <div className={`bg-[#12213D] border border-[#243A66] rounded-2xl p-4 shadow-lg space-y-3 ${className}`}>{children}</div>
);

export const GiftsPage: React.FC = () => {
  const { t } = useI18n();
  const [code, setCode] = useState('');
  const [msg, setMsg] = useState<{ ok: boolean; message: string } | null>(null);
  return (
    <div className="space-y-4 text-left anim-fade-in">
      <PageHeader title={t('gifts')} />
      <Card>
        <label className="text-xs font-bold text-white flex items-center gap-1.5"><Gift className="w-4 h-4 text-[#C58937]" /> Redeem a gift code</label>
        <div className="flex items-center gap-2">
          <input value={code} onChange={(e) => { setCode(e.target.value); setMsg(null); }} placeholder="Enter gift code"
            className="flex-1 min-w-0 bg-[#1A2C4E] border border-[#243A66] rounded-xl px-3.5 h-11 text-sm font-mono uppercase outline-none focus:border-[#C58937]" />
          <Button variant="primary" onClick={() => setMsg(playStore.redeemCode(code))} className="h-11 py-0 text-xs font-bold">Redeem</Button>
        </div>
        {msg && <p className={`text-xs font-bold anim-slide-up ${msg.ok ? 'text-[#01A879]' : 'text-[#E92844]'}`}>{msg.message}</p>}
        <p className="text-[10px] text-slate-500">Try WELCOME, LUCKY7 or ALLWIN. Codes add free play credits only.</p>
      </Card>
    </div>
  );
};

export const StatisticsPage: React.FC = () => {
  const { t } = useI18n();
  const history = usePlayStore((s) => s.history);
  const s = computeStats(history);
  const max = Math.max(1, ...Object.values(s.bySlug).map((x) => x.rounds));
  return (
    <div className="space-y-4 text-left anim-fade-in">
      <PageHeader title={t('statistics')} />
      <Card>
        <h3 className="text-xs font-bold flex items-center gap-2"><BarChart2 className="w-4 h-4 text-[#C58937]" /> Overall</h3>
        <div className="grid grid-cols-2 gap-3 text-xs">
          {[['Total rounds', String(s.rounds), 'text-white'], ['Win rate', `${s.winRate.toFixed(1)}%`, 'text-[#01A879]'], ['Total staked', fmtCredits(s.staked), 'text-[#C58937]'], ['Net result', fmtCredits(s.net), s.net >= 0 ? 'text-[#01A879]' : 'text-[#E92844]']].map(([k, v, c]) => (
            <div key={k} className="bg-[#1A2C4E] p-3 rounded-xl border border-[#243A66]"><span className="text-slate-400">{k}</span><p className={`text-base font-black mt-0.5 ${c}`}>{v}</p></div>
          ))}
        </div>
      </Card>
      <Card>
        <h3 className="text-xs font-bold">Rounds per game</h3>
        {s.rounds === 0 ? <p className="text-xs text-slate-500">No rounds yet.</p> : GAMES.map((g) => {
          const x = s.bySlug[g.config.slug];
          return (
            <div key={g.config.slug} className="flex items-center gap-2 text-[11px]">
              <span className="w-24 truncate text-slate-300">{g.config.name}</span>
              <div className="flex-1 h-2.5 bg-[#1A2C4E] rounded-full overflow-hidden"><div className="h-full rounded-full transition-all duration-700" style={{ width: `${((x?.rounds ?? 0) / max) * 100}%`, background: g.config.accent }} /></div>
              <span className="w-8 text-right font-bold">{x?.rounds ?? 0}</span>
            </div>
          );
        })}
      </Card>
    </div>
  );
};

export const NotificationsPage: React.FC = () => {
  const { t } = useI18n();
  const notices = usePlayStore((s) => s.notices);
  useEffect(() => {
    const id = setTimeout(() => playStore.markNoticesRead(), 800);
    return () => clearTimeout(id);
  }, []);
  return (
    <div className="space-y-4 text-left anim-fade-in">
      <PageHeader title={t('notifications')} />
      {notices.length ? (
        <div className="space-y-2.5">
          {notices.map((n) => (
            <div key={n.id} className="bg-[#12213D] border border-[#243A66] rounded-2xl p-3.5 flex items-start gap-3 shadow-lg anim-slide-up">
              <Bell className={`w-5 h-5 shrink-0 mt-0.5 ${n.read ? 'text-slate-500' : 'text-[#C58937]'}`} />
              <div className="flex-1">
                <p className="text-xs font-bold text-white flex items-center gap-1.5">{n.title}{!n.read && <span className="w-1.5 h-1.5 rounded-full bg-[#E92844]" />}</p>
                <p className="text-[11px] text-slate-300 mt-0.5">{n.body}</p>
                <p className="text-[9px] text-slate-500 mt-1">{timeAgo(n.ts)}</p>
              </div>
            </div>
          ))}
        </div>
      ) : <EmptyState icon={<Bell className="w-5 h-5" />} title="No notifications" body="Big wins and mission rewards will show up here." />}
    </div>
  );
};

export const SecurityPage: React.FC = () => {
  const { t } = useI18n();
  return (
    <div className="space-y-4 text-left anim-fade-in">
      <PageHeader title={t('security')} />
      <Card>
        <h3 className="text-xs font-bold flex items-center gap-1.5"><Shield className="w-4 h-4 text-[#01A879]" /> Privacy & data</h3>
        <p className="text-xs text-slate-300 leading-relaxed">Your profile, play credits and history are stored only on this device (browser local storage). Nothing is sent to a server and no payment details are ever collected.</p>
        <ul className="text-xs text-slate-300 space-y-1.5 list-disc pl-4">
          <li>Game outcomes use the browser's cryptographic random generator.</li>
          <li>Clearing browser data removes your local progress.</li>
          <li>You can wipe history any time from Settings.</li>
        </ul>
      </Card>
    </div>
  );
};

export const ResponsibleGamingPage: React.FC = () => {
  const { t } = useI18n();
  const [since] = useState(() => Number(sessionStorage.getItem('allwin_session_start') || Date.now()));
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    if (!sessionStorage.getItem('allwin_session_start')) sessionStorage.setItem('allwin_session_start', String(since));
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, [since]);
  const mins = Math.floor((now - since) / 60000);
  return (
    <div className="space-y-4 text-left anim-fade-in">
      <PageHeader title={t('responsibleGaming')} />
      <Card>
        <h3 className="text-xs font-bold flex items-center gap-1.5"><HeartHandshake className="w-4 h-4 text-rose-500" /> Play for fun</h3>
        <p className="text-xs text-slate-300 leading-relaxed">ALL WIN is a free entertainment app with play credits that have no monetary value. Take regular breaks and keep gaming a fun part of a balanced day.</p>
      </Card>
      <Card>
        <h3 className="text-xs font-bold flex items-center gap-1.5"><Clock className="w-4 h-4 text-[#C58937]" /> This session</h3>
        <p className="text-2xl font-black">{mins} min</p>
        <p className="text-[11px] text-slate-400">Time since you opened the app in this tab.</p>
      </Card>
    </div>
  );
};

export const SettingsPage: React.FC = () => {
  const { t, language, setLanguage } = useI18n();
  const navigate = useNavigate();
  const sound = useSoundSettings();
  const ui = useGameSound(UI_SOUNDS);
  const [wipe, setWipe] = useState(false);
  return (
    <div className="space-y-4 text-left anim-fade-in">
      <PageHeader title={t('settings')} />
      <Card>
        <h3 className="text-xs font-bold flex items-center gap-1.5"><SettingsIcon className="w-4 h-4 text-[#C58937]" /> Sound</h3>
        <div className="flex items-center justify-between">
          <span className="text-xs text-slate-300 flex items-center gap-2">{sound.muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-[#C58937]" />} Game sounds</span>
          <button role="switch" aria-checked={!sound.muted} aria-label="Toggle sound" onClick={() => soundSettings.toggle()}
            className={`w-12 h-7 rounded-full p-1 transition-colors ${sound.muted ? 'bg-[#243A66]' : 'bg-[#01A879]'}`}>
            <span className={`block w-5 h-5 rounded-full bg-white transition-transform ${sound.muted ? '' : 'translate-x-5'}`} />
          </button>
        </div>
        <label className="flex items-center gap-3">
          <span className="text-xs text-slate-300 w-14">Volume</span>
          <input aria-label="Volume" type="range" min={0} max={100} value={Math.round(sound.volume * 100)} disabled={sound.muted}
            onChange={(e) => soundSettings.set({ volume: +e.target.value / 100 })} className="flex-1 accent-[#C58937] h-8" />
          <span className="text-xs font-bold w-9 text-right">{Math.round(sound.volume * 100)}%</span>
        </label>
        <Button variant="secondary" onClick={() => ui.play('test')} disabled={sound.muted} className="w-full py-2.5 text-xs">Play test sound</Button>
        <p className="text-[10px] text-slate-500">Sound preference is kept for this browser session. Browsers start audio only after your first tap.</p>
      </Card>
      <Card>
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold flex items-center gap-2"><Globe className="w-4 h-4 text-[#C58937]" /> {t('language')}</span>
          <div className="flex bg-[#1A2C4E] rounded-xl p-1 border border-[#243A66]">
            {(['EN', 'BN'] as const).map((l) => (
              <button key={l} onClick={() => setLanguage(l)} className={`px-3 h-8 rounded-lg text-xs font-bold ${language === l ? 'gold-gradient-bg' : 'text-slate-400'}`}>{l === 'EN' ? 'English' : 'বাংলা'}</button>
            ))}
          </div>
        </div>
      </Card>
      <Card>
        <h3 className="text-xs font-bold">Data</h3>
        <Button variant="secondary" onClick={() => navigate('/menu/notifications')} className="w-full py-2.5 text-xs">View notifications</Button>
        <button onClick={() => setWipe(true)} className="w-full h-11 rounded-xl border border-[#E92844]/50 text-[#E92844] text-xs font-bold flex items-center justify-center gap-2"><Trash2 className="w-4 h-4" /> Clear game history</button>
      </Card>
      <Modal isOpen={wipe} onClose={() => setWipe(false)} title="Clear history?">
        <div className="space-y-5 pt-2">
          <p className="text-sm text-slate-200">All recorded rounds and ledger entries will be deleted. Your credits stay the same.</p>
          <div className="grid grid-cols-2 gap-3">
            <Button variant="neutral" onClick={() => setWipe(false)} className="py-2.5 text-xs">Cancel</Button>
            <Button variant="destructive" onClick={() => { playStore.clearHistory(); setWipe(false); }} className="py-2.5 text-xs">Clear</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
