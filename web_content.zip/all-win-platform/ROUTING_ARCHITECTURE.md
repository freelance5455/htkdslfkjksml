# ALL WIN — Routing & Navigation Architecture

## 1. Canonical Routes
- `/`: Home / Lobby (Featured, Popular, Categories, New Games)
- `/register`: Registration Page (11-digit Bangladesh phone validation, privacy agreement)
- `/login`: Login Page (Phone / Email tabs, Customer Service recovery path)
- `/customer-service`: Customer Support Center
- `/catalog`: Full Game Catalog
- `/catalog/:category`: Category specific view
- `/game/:slug`: Game Runtime Viewport
- `/activity`: Activity Page (Bonus Hub, Check-in, Game Activity, Active Sessions)
- `/promotion`: Promotion Page (Promotions & Referral/Partner Hub)
- `/wallet`: Wallet Overview
- `/wallet/deposit`: Deposit flow (bKash, Nagad, Rocket, Bank; Min ৳100, Max ৳100,000)
- `/wallet/withdraw`: Withdrawal flow (3/day, Max ৳50,000/req; Min withdrawal `CONFIGURABLE / REQUIRES PRODUCT DECISION`)
- `/wallet/history`: Financial Transaction History
- `/history`: Detailed Game History
- `/vip`: VIP Club tier progress
- `/profile`: Profile & PIN Security
- `/menu`: Menu Page (Profile, VIP, History, Gifts, Stats, Notifications, Language, Service Center, Security, Responsible Gaming, Settings, LOGOUT at bottom)
- `/admin`: C-Panel Dashboard (Isolated Admin Domain)

## 2. Absolute Bottom Navigation Lock
The mobile bottom navigation bar is permanently locked to **exactly 5 equal-width items**:
1. **HOME** (`/`)
2. **ACTIVITY** (`/activity`)
3. **PROMOTION** (`/promotion`)
4. **WALLET** (`/wallet`)
5. **MENU** (`/menu`)

```
┌─────────────────────────────────────────────────────────┐
│  [🏠]       [📊]        [🎁]       [👛]       [☰]       │
│  HOME     ACTIVITY    PROMOTION   WALLET     MENU       │
└─────────────────────────────────────────────────────────┘
```

## 3. Global Back Button & Game Exit Policy
- Dedicated inner pages provide visible page Back Arrow, hardware Back, and browser Back support, returning exactly one step in history.
- If an active game session exists when the user attempts to navigate back or leave the page, the runtime enforces a global confirmation modal (`DEFAULT_NAV_POLICY.confirmGameExitOnActiveSession`).
