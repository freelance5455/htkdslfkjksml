# ALL WIN — Game Domain Architecture

## 1. Game Registry & Identity
The **Game Registry** (`src/core/types/game-registry.ts`) is the single source of truth for all games.
- **Stable Identity**: Each game has a immutable `gameId` (e.g. `vfair-dice`) and URL `slug` (e.g. `dice`). Display names and array indexes MUST NOT be used as identifiers.
- **Registry Attributes**: `gameId`, `name`, `slug`, `category`, `subcategory`, `thumbnail`, `banner`, `icon`, `route`, `providerSource`, `engine`, `adapter`, `status` (`ACTIVE`, `DISABLED`, `MAINTENANCE`, `COMING_SOON`), `isFeatured`, `isPopular`, `isNew`, `sortOrder`, `minStake`, `maxStake`, `rulesReference`, `soundConfig`, `animationConfig`, `orientation`, `isHistoryEnabled`, `isActivityEnabled`.

## 2. Canonical Game Categories
- `ORIGINALS` (Dice, Limbo, Mines, Plinko, Diamonds, Dragon Tower, Hilo)
- `SLOTS` (Harlequin's Slot, Mega Slots)
- `CRASH` (Crash, Chart Multiplier)
- `TABLE_GAMES` (Blackjack, Baccarat, Roulette, Texas Hold'em, Teen Patti)
- `LOTTERY_NUMBER` (Keno, Lotto, Satta Matka)
- `INSTANT_MINI` (Chicken, Wheel, Coinflip, Scratch Card)
- `ARCADE` (Dino Run, Crate Run, Flappy, Claw Machine)
- `OTHER` (Sportsbook, Live Events)

## 3. Game Runtime & Adapter Contract
The **Game Runtime** manages the platform-level game lifecycle while the **Game Adapter** (`src/core/contracts/game-adapter.ts`) wraps specific game engines behind a clean interface:

```typescript
export interface GameAdapterContract<TState, TAction, TOutcome> {
  initialize(config: Record<string, unknown>): Promise<void>;
  load(viewportElementId: string): Promise<void>;
  startSession(userId: string, gameId: string): Promise<GameSession>;
  getState(): TState;
  submitAction(action: TAction): Promise<GameRound>;
  getResult(roundId: string): Promise<GameResultEnvelope<TOutcome>>;
  destroy(): Promise<void>;
}
```

## 4. Game Session & Round Lifecycle
- **Session Lifecycle**: `CREATED` -> `ACTIVE` -> `PAUSED` -> `COMPLETED` / `CANCELLED` / `EXPIRED`.
- **Round Lifecycle**: Created -> Action Submitted -> Server Computed -> Settlement (`PENDING` -> `SETTLED` / `FAILED` / `REJECTED`).
- **Result Envelope**: Contains `roundId`, `gameId`, `status`, `outcome` payload, `stake`, `payout`, `netResult`, and `timestamp`.
