# ALL WIN — Master System Architecture

## 1. Architectural Philosophy
The **ALL WIN** platform is engineered as a provider-ready, modular, data-driven, server-authoritative gaming and entertainment system. The architecture guarantees clean domain separation, preventing individual game engines or payment providers from dictating the platform's core structure.

```
                     GAME REGISTRY
                           │
                           ▼
                     GAME CATALOG
                           │
                           ▼
                     GAME ROUTER
                           │
                           ▼
                     GAME RUNTIME
                           │
                           ▼
                    GAME ADAPTER
                           │
             ┌─────────────┼─────────────┐
             ▼             ▼             ▼
        vfair-games    Afterhand     play-kit
```

---

## 2. Master Domain Boundaries
The ALL WIN system is strictly divided into decoupled, independent domains:

1. **User / Identity Domain**: User profile, preferences, language (EN/BN), security settings, 11-digit Bangladesh phone validation (`01XXXXXXXXX`), and global session identity.
2. **Game Domain**: Game Registry, Game Catalog, Game Runtime, Game Adapter Layer, Game Session, and Round Settlement.
3. **Wallet Domain**: Dual-balance ledger (Real + Bonus), Deposit flow (bKash, Nagad, Rocket, Bank), Withdrawal flow (No Agent Withdrawal), Transaction audit trail, and Provider abstractions.
4. **Activity Domain**: User recent games, wins, losses, Bonus Hub, Daily Check-In, and active session management.
5. **Game History Domain**: Detailed round history search, filters, and round verification breakdown.
6. **Promotion Domain**: Configuration-driven deposit offers, challenges, events, and Referral/Partner hub (Direct & Team subordinates, commission, rebate, invite code, invite QR).
7. **VIP Domain**: Progression engine, tier levels, points, and level-up rewards.
8. **C-Panel / Administrative Domain**: Player management, game enablement, round monitoring, risk/safety oversight, and system audit logs.

---

## 3. Server-Authoritative Settlement Boundary
All financial transactions, round outcomes, and payouts are authoritative on the trusted server side (`vfair-games` NestJS core or equivalent trusted backend). Browser clients serve purely as presentation shells and MUST NEVER be trusted for final bet settlement, balance mutation, or outcome generation.

---

## 4. Architectural Sequence
1. User selects a game from the **Game Catalog** (populated via **Game Registry**).
2. The **Game Router** instantiates the **Game Runtime** at `/game/:slug`.
3. The **Game Runtime** loads the designated **Game Adapter**.
4. The **Game Adapter** initializes the external/internal Game Engine.
5. The player performs an action; the adapter communicates with the server to create a **Round**.
6. The server settles the round authoritatively and records a **Wallet Transaction** and **Game History** entry.
7. The adapter receives the **Result Envelope** and renders the outcome animation.
