# ALL WIN — Architecture Gap Analysis Report

## Executive Summary
This document compares the current working state of the ALL WIN repository and external sources against the target ALL WIN enterprise architecture.

## Architectural Area Breakdown

### 1. Game Registry System
- **Target**: Centralized, data-driven registry mapping `GameIdentity`, `Slug`, `Category`, `Artwork`, `Route`, `AdapterEngine`, `Status`, `Featured`, `Popular`, and `New` flags.
- **Current State**: Fragmented across `stake-originals-clone` (`games.js`), `vfair-games` (`PartnerGame` model), and `Rush` (hardcoded API routes).
- **Gap**: Missing a unified ALL WIN Game Registry module.

### 2. Game Runtime & Adapter Layer
- **Target**: Unified `GameViewport` component executing through standard lifecycle hooks (`initSession`, `createRound`, `settleRound`, `destroySession`).
- **Current State**: Games in external sources use varied props, WebSockets, or direct Next.js fetch hooks.
- **Gap**: An Adapter Layer needs to wrap external game engines (Phaser 3, React State Machine, Canvas Slot Engine) into a standardized ALL WIN contract.

### 3. Dual-Balance Wallet Ledger
- **Target**: Real Balance + Bonus Balance, deposit/withdrawal flows, standard financial payment adapters, and complete audit trail.
- **Current State**: `vfair-games` provides a single-balance `WalletTransaction` ledger. `Rush` uses Supabase RPC procedures. `casino` uses LocalStorage.
- **Gap**: Missing dual-balance separation and provider payment abstraction.

### 4. Promotion & VIP Engine
- **Target**: Configuration-driven First/Second/Third deposit bonuses, claim states, VIP tiers, level-up rewards, and progress tracking.
- **Current State**: `play-kit` provides interactive promo components (Daily Check-in, Lucky Wheel, Scratch Card), but no server-side VIP progression engine exists.
- **Gap**: Missing backend promotion/VIP configuration system.

### 5. C-Panel & Admin Oversight
- **Target**: Dashboard, Player lookup, Game enable/disable, Round lookup, Promotion config, VIP config, Anti-fraud monitoring, and Audit logs.
- **Current State**: `vfair-games` provides ~75% of this infrastructure in `admin-api` and `admin-web`.
- **Gap**: Needs integration with ALL WIN wallet ledger, promo system, and game registry.
