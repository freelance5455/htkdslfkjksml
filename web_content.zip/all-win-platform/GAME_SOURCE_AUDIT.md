# ALL WIN — External Game Source Audit Report

## Source 1: `play-kit` (`@play-kit/games`)
- **Identity**: `@play-kit/games` (v0.0.0)
- **License**: **MIT License**
- **Stack**: React 18/19, TypeScript 5.5, Biome, Vitest, Playwright, Tailwind CSS
- **Dependencies**: Zero runtime non-peer dependencies.
- **Game Inventory (17 Games)**:
  1. `daily-checkin`, 2. `doll-machine`, 3. `flip-match`, 4. `gift-box`, 5. `gift-rain`, 6. `guess-gift`, 7. `lotto-roll`, 8. `lucky-wheel`, 9. `marquee`, 10. `nine-grid`, 11. `quiz`, 12. `ring-toss`, 13. `scratch-card`, 14. `shake`, 15. `shake-dice`, 16. `slot-machine`, 17. `smash-egg`.
- **Architecture & Quality**: Outstanding. Controlled 6-state machine (`idle`, `playing`, `won`, `lost`, `claimed`, `cooldown`), full WCAG a11y, SSR-safe, clean ref API.
- **Mobile Compatibility**: Fully mobile-first and responsive.
- **Integration Feasibility**: **Classification A (Strong Candidate)** for Instant/Mini-games, Loyalty, and Promotional mini-games.

---

## Source 2: `SlotGame` (`slot-game`)
- **Identity**: `slot-game` (Harlequin's Fortune Slot)
- **License**: **UNVERIFIED** (Requires formal license grant before commercial distribution)
- **Stack**: React 19, Vite 7, TypeScript 5.9, React Icons
- **Dependencies**: `react`, `react-dom`, `react-icons`
- **Game Inventory**:
  1. `Harlequin's Fortune` (10-payline professional slot machine with Wilds, Scatters, Auto-spin, and Monte Carlo tested 95.3% RTP)
- **Architecture & Quality**: High. Features custom canvas/CSS reel animations, sound effects, full WCAG keyboard navigation, and Monte Carlo RTP simulation script.
- **Mobile Compatibility**: Excellent responsive layout with bottom control sheet.
- **Integration Feasibility**: **Classification A (Strong Candidate)** for Slots category.

---

## Source 3: `stake-originals-clone` (`stake-games-clone`)
- **Identity**: `stake-games-clone` (v1.0.0)
- **License**: **UNVERIFIED**
- **Stack**: React 18, Vite 5, Tailwind CSS v4, Ant Design, Radix UI, Phaser 3.90, Matter.js 0.20
- **Dependencies**: `phaser`, `matter-js`, `antd`, `chart.js`, `lucide-react`
- **Game Inventory (4 Games)**:
  1. `Crash`, 2. `Plinko`, 3. `Dino`, 4. `Mines`.
- **Architecture & Quality**: Good UI fidelity (Stake-like aesthetic). Physics simulation in Plinko is very smooth.
- **Mobile Compatibility**: Features mobile bet sheet and mobile navigation bar.
- **Integration Feasibility**: **Classification B (Candidate with Adaptation)** for Crash, Plinko, Mines, and Dino.

---

## Source 4: `vfair-games` (`@vfair/source`)
- **Identity**: `@vfair/source` (v0.0.0)
- **License**: **Apache License 2.0**
- **Stack**: Nx Monorepo, NestJS 11, React 19, Prisma 7 + PostgreSQL, Socket.IO 4, Redis, RabbitMQ, Tailwind CSS
- **Game Inventory (5 Provably Fair Games)**:
  1. `Dice`, 2. `Limbo`, 3. `Mines`, 4. `Plinko`, 5. `Keno`.
- **Architecture & Quality**: Production-grade. Complete HMAC-SHA256 seed commitment scheme, partner wallet adapter, KPI worker, and admin management suite.
- **Mobile Compatibility**: Excellent Radix UI / Radix Palette responsive styling.
- **Integration Feasibility**: **Classification A (Strong Candidate)** for Core Backend & Originals Architecture.

---

## Source 5: `casino` (`losslimit-casino`)
- **Identity**: `losslimit-casino` (v1.0.0)
- **License**: **GNU General Public License v3 (GPL v3)**
- **Stack**: React 18, Vite 5, React Router v6, Recharts, Tailwind CSS
- **Game Inventory (13 Games)**:
  1. `Baccarat`, 2. `Blackjack`, 3. `Coinflip`, 4. `Crash`, 5. `Dice`, 6. `Keno`, 7. `Matka` (Satta Matka), 8. `Mines`, 9. `Plinko`, 10. `Roulette`, 11. `Slots`, 12. `TeenPatti`, 13. `Wheel`.
- **License Risk**: **GPL v3 Copyleft**. Code MUST NOT be directly copy-pasted into a proprietary ALL WIN app without triggering GPL distribution requirements.
- **Integration Feasibility**: **Classification C (Reference Only)** due to GPL v3 licensing.

---

## Source 6: `Rush` (`rush`)
- **Identity**: `rush` (v0.1.0)
- **License**: **MIT License**
- **Stack**: Next.js 15.5 (App Router), React 19, Tailwind CSS v4, Supabase (Postgres), Pusher Channels, Vitest, Playwright
- **Game Inventory (17 Games)**:
  1. `Dice`, 2. `Limbo`, 3. `Plinko`, 4. `Keno`, 5. `Roulette`, 6. `Wheel`, 7. `Slots`, 8. `Baccarat`, 9. `Diamonds`, 10. `Mines`, 11. `Dragon Tower`, 12. `Hilo`, 13. `Blackjack`, 14. `Crash`, 15. `Chicken`, 16. `Crate Run`, 17. `Flappy`.
- **Architecture & Quality**: Solid server-authoritative Next.js API endpoints (`/api/games/*`) and real-time multiplayer lobbies.
- **Integration Feasibility**: **Classification B (Candidate with Adaptation)** for Next.js backend logic and multiplayer lobby mechanics.

---

## Source 7: `Bet` (`Gamble`)
- **Identity**: `Gamble` (Reference Documentation)
- **License**: **UNVERIFIED**
- **Stack**: Next.js App Router, Prisma + Neon Postgres, Tailwind CSS
- **Game Inventory**: 23 games documented.
- **Integration Feasibility**: **Classification C (Reference Only)** as specification source.

---

## Source 8: `Afterhand` (`afterhand`)
- **Identity**: `afterhand` (v0.1.0)
- **License**: **MIT License**
- **Stack**: Next.js 16.3 (App Router), React 19.2, Tailwind CSS v4, Framer Motion 13, Zustand 5, Vitest 4
- **Dependencies**: `framer-motion`, `next`, `react`, `react-dom`, `zustand`
- **Game Inventory (4 Table Games)**:
  1. `Blackjack` (Full multi-deck basic strategy chart, soft 17, split, double, surrender, coaching engine)
  2. `Texas Hold'em Poker` (4-handed vs AI bots, side pots, pot odds, Monte Carlo equity simulator)
  3. `Baccarat` (Standard tableau 3rd card drawing rules, rule explanations)
  4. `Roulette` (European 37-number & American 38-number wheels, full betting board)
- **Architecture & Quality**: Outstanding pure TypeScript engines (`lib/games/*`), Zustand session stores, Framer Motion card/chip animations, zero raster images (pure CSS cards/chips), WCAG compliant, dynamic mobile viewport heights (`dvh`).
- **Mobile Compatibility**: Exceptional mobile layout and touch responsiveness.
- **Integration Feasibility**: **Classification A (Strong Candidate)** for Table Games UI & Rule Engines (wrapped around server settlement).
