# ALL WIN — Administrative C-Panel Architecture

## 1. Administrative Scope & Boundaries
The **C-Panel** provides operational oversight, configuration management, risk monitoring, and compliance auditing. It communicates with the backend via isolated administrative contracts and MUST NOT directly mutate player UI state.

## 2. Core Modules
1. **Dashboard**: High-level KPIs (GGR, NGR, Active Players, Active Sessions).
2. **Players**: Player lookup, account status, security controls.
3. **Games**: Enable/Disable games, set maintenance state, adjust min/max stakes.
4. **Rounds**: Round lookup, seed verification, settlement audit.
5. **Promotions & VIP**: Configure bonus parameters, wagering multipliers, VIP tier thresholds.
6. **Wallet / Transactions**: Financial transaction review, deposit/withdrawal approval queues.
7. **Risk & Safety**: Abuse detection, anomaly alerts, emergency game kill-switches.

## 3. Win/Loss & Fairness Boundary
- **STRICT PROHIBITION**: Outcome manipulation, targeted user rigging, or real-money result forcing algorithms MUST NOT be implemented.
- Operational controls are strictly limited to risk monitoring, fraud detection, emergency game maintenance, and audit logging.
