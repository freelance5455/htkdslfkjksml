# ALL WIN — Source Integration & License Policy

## 1. Integration Pipeline
No code from any external source may enter the ALL WIN runtime directly. All games must follow this clean-room pipeline:

```
External Source
       ↓
Audit & License Review
       ↓
Adapter Contract Definition
       ↓
Server-Authoritative Round Settlement Binding
       ↓
Game Registry Registration
       ↓
Catalog & Runtime Mount
```

## 2. Source Role Allocations
- **`vfair-games` (Apache 2.0)**: Reference & Core Backend for Server-Authoritative Provably Fair rounds, NestJS contracts, and Wallet Adapters.
- **`Afterhand` (MIT)**: Primary Candidate for Table Games UI (Blackjack, Texas Hold'em, Baccarat, Roulette), pure CSS card/chip components, and rules engines.
- **`Rush` (MIT)**: Candidate for Next.js API route patterns, multiplayer lobby state, and additional game math.
- **`play-kit` (MIT)**: Primary Candidate for Instant/Mini-games, Scratch Cards, and Promotional Mini-games.
- **`SlotGame` (Unverified)**: Candidate for Main Slot Machine engine (pending written license grant).
- **`stake-originals-clone` (Unverified)**: Candidate for Phaser 3 physics (Plinko, Dino) (pending license grant).
- **`casino` (GPL v3)**: **STRICT REFERENCE ONLY**. Code MUST NOT be copy-pasted to avoid GPL v3 copyleft contamination.
- **`Bet` (Unverified)**: Reference specification only.

## 3. Duplicate Resolution
When duplicate games exist (e.g. Blackjack in `Afterhand`, `casino`, `Rush`), the selected candidate is wrapped in an ALL WIN Adapter while unselected candidates remain isolated.
