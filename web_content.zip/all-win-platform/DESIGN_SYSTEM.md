# ALL WIN — Design System Foundation

## 1. Brand Palette & Tokens
- **Gold**: `#C58937` (Primary Accent, Glossy Borders, CTA Highlights)
- **Navy**: `#12213D` (Primary Dark Navy Surface & Brand Base)
- **Green**: `#01A879` (Success, Positive Payouts, Real Balance)
- **Red**: `#E92844` (Danger, Losses, Cancel/Close Actions)

## 2. Theme Architecture
- **Dark Mode (Primary Identity)**: Deep navy background (`#0B0E14`), dark navy card surfaces (`#12213D` / `#152542`), gold accents (`#C58937`), subtle depth borders (`#243A66`).
- **Light Mode**: Warm clean paper background (`#F8FAFC`), crisp white card surfaces (`#FFFFFF`), dark slate text (`#0F172A`).

## 3. Typography
- **English (EN)**: `Inter, system-ui, sans-serif`.
- **Bengali (BN)**: `Noto Sans Bengali, Hind Siliguri, kalpurush, sans-serif`. Self-hosted font assets only; zero Google CDN runtime dependencies.

## 4. Mobile & Responsive Guidelines
- Mobile-first breakpoints: `mobileSmall` (360px), `mobileStandard` (390px), `mobileLarge` (430px), `tablet` (768px), `desktop` (1024px).
- Dynamic viewport height (`dvh`), safe area inset padding (`env(safe-area-inset-*)`), touch target size >= 44px.
