import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { validateBangladeshPhoneNumber } from '../src/core/types/domains.js';

describe('Bangladesh Phone Validation Invariants', () => {
  test('Empty input must fail validation', () => {
    const res = validateBangladeshPhoneNumber('');
    assert.equal(res.isValid, false);
    assert.equal(res.errorMessage, 'Phone number is required.');
  });

  test('Input not starting with 01 must fail validation', () => {
    const res = validateBangladeshPhoneNumber('0212345678');
    assert.equal(res.isValid, false);
    assert.match(res.errorMessage || '', /must start with 01/);
  });

  test('Incomplete input (fewer than 11 digits) must fail validation and show incomplete warning', () => {
    const res = validateBangladeshPhoneNumber('017123456');
    assert.equal(res.isValid, false);
    assert.match(res.errorMessage || '', /incomplete/i);
  });

  test('Exactly 11 digits starting with 01 must pass validation', () => {
    const res = validateBangladeshPhoneNumber('01712345678');
    assert.equal(res.isValid, true);
    assert.equal(res.errorMessage, undefined);
    assert.equal(res.rawLocalInput, '01712345678');
    assert.equal(res.countryCode, '+880');
  });
});
