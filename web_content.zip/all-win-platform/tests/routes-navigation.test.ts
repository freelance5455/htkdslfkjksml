import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { ROUTES, LOCKED_BOTTOM_NAV } from '../src/core/config/routes.js';

describe('Navigation Architecture Invariants', () => {
  test('Locked Bottom Navigation must contain exactly 5 equal items: HOME, ACTIVITY, PROMOTION, WALLET, MENU', () => {
    assert.equal(LOCKED_BOTTOM_NAV.length, 5, 'Bottom nav must have exactly 5 items');
    const ids = LOCKED_BOTTOM_NAV.map((item) => item.id);
    assert.deepEqual(ids, ['HOME', 'ACTIVITY', 'PROMOTION', 'WALLET', 'MENU']);
  });

  test('Wallet History and Game History routes must remain separate domains', () => {
    assert.notEqual(ROUTES.WALLET_HISTORY, ROUTES.GAME_HISTORY);
    assert.equal(ROUTES.WALLET_HISTORY, '/wallet/history');
    assert.equal(ROUTES.GAME_HISTORY, '/history');
    assert.equal(ROUTES.ACTIVITY, '/activity');
    assert.equal(ROUTES.PROMOTION, '/promotion');
    assert.equal(ROUTES.MENU, '/menu');
  });
});
