import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import type { GameRegistryEntry } from '../src/core/types/game-registry.js';

describe('Game Registry Contract & Schema Invariants', () => {
  const sampleRegistry: GameRegistryEntry[] = [
    {
      gameId: 'vfair-dice',
      name: 'Dice',
      slug: 'dice',
      category: 'ORIGINALS',
      thumbnail: '/art/dice.png',
      route: '/game/dice',
      providerSource: 'vfair-games',
      engine: 'provably-fair-dice',
      adapter: 'VfairDiceAdapter',
      status: 'ACTIVE',
      isFeatured: true,
      isPopular: true,
      isNew: false,
      sortOrder: 1,
      minStake: 10,
      maxStake: 10000,
      rulesReference: '/rules/dice',
      soundConfig: { enabled: true },
      animationConfig: { engine: 'radix-ui' as unknown as 'css', reducedMotionSupported: true },
      orientation: 'PORTRAIT',
      isHistoryEnabled: true,
      isActivityEnabled: true,
    },
    {
      gameId: 'afterhand-blackjack',
      name: 'Blackjack',
      slug: 'blackjack',
      category: 'TABLE_GAMES',
      thumbnail: '/art/blackjack.png',
      route: '/game/blackjack',
      providerSource: 'Afterhand',
      engine: 'afterhand-blackjack',
      adapter: 'AfterhandBlackjackAdapter',
      status: 'ACTIVE',
      isFeatured: true,
      isPopular: true,
      isNew: false,
      sortOrder: 2,
      minStake: 50,
      maxStake: 50000,
      rulesReference: '/rules/blackjack',
      soundConfig: { enabled: true },
      animationConfig: { engine: 'framer-motion', reducedMotionSupported: true },
      orientation: 'BOTH',
      isHistoryEnabled: true,
      isActivityEnabled: true,
    },
  ];

  test('All registry entries must have unique gameId and unique slug', () => {
    const gameIds = new Set<string>();
    const slugs = new Set<string>();

    for (const game of sampleRegistry) {
      assert.ok(!gameIds.has(game.gameId), `Duplicate gameId found: ${game.gameId}`);
      assert.ok(!slugs.has(game.slug), `Duplicate slug found: ${game.slug}`);
      gameIds.add(game.gameId);
      slugs.add(game.slug);
    }
  });

  test('Game ID and slug must not rely on array index, timestamp, or display name', () => {
    for (const game of sampleRegistry) {
      assert.notEqual(game.gameId, game.name, 'gameId should not be display name');
      assert.match(game.slug, /^[a-z0-9-]+$/, 'slug must be lowercase hyphenated string');
    }
  });

  test('Category must be a valid canonical ALL WIN category', () => {
    const validCategories = new Set([
      'ORIGINALS',
      'SLOTS',
      'CRASH',
      'TABLE_GAMES',
      'LOTTERY_NUMBER',
      'INSTANT_MINI',
      'ARCADE',
      'OTHER',
    ]);

    for (const game of sampleRegistry) {
      assert.ok(validCategories.has(game.category), `Invalid category: ${game.category}`);
    }
  });
});
