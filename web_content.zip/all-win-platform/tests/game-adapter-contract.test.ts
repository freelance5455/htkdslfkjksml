import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import type { GameAdapterContract } from '../src/core/contracts/game-adapter.js';
import type { GameSession, GameRound, GameResultEnvelope } from '../src/core/types/game-runtime.js';

class MockGameAdapter implements GameAdapterContract<{ score: number }, { bet: number }, { win: boolean }> {
  private state = { score: 0 };
  private session: GameSession | null = null;

  async initialize(config: Record<string, unknown>): Promise<void> {
    assert.ok(config, 'Config must be provided');
  }

  async load(viewportElementId: string): Promise<void> {
    assert.ok(viewportElementId, 'Viewport ID must be provided');
  }

  async startSession(userId: string, gameId: string): Promise<GameSession> {
    this.session = {
      sessionId: 'sess_123',
      userId,
      gameId,
      status: 'ACTIVE',
      startedAt: new Date(),
    };
    return this.session;
  }

  getState() {
    return this.state;
  }

  async submitAction(action: { bet: number }): Promise<GameRound> {
    assert.ok(this.session, 'Session must be active');
    const resultEnvelope: GameResultEnvelope<{ win: boolean }> = {
      roundId: 'round_123',
      gameId: this.session.gameId,
      status: 'WIN',
      outcome: { win: true },
      stake: action.bet,
      payout: action.bet * 2,
      netResult: action.bet,
      timestamp: new Date(),
    };

    return {
      roundId: 'round_123',
      gameSessionId: this.session.sessionId,
      userId: this.session.userId,
      gameId: this.session.gameId,
      stake: action.bet,
      result: resultEnvelope,
      settlementStatus: 'SETTLED',
      createdAt: new Date(),
      completedAt: new Date(),
    };
  }

  async getResult(roundId: string): Promise<GameResultEnvelope<{ win: boolean }>> {
    return {
      roundId,
      gameId: 'dice',
      status: 'WIN',
      outcome: { win: true },
      stake: 100,
      payout: 200,
      netResult: 100,
      timestamp: new Date(),
    };
  }

  async destroy(): Promise<void> {
    this.session = null;
  }
}

describe('Game Adapter Contract Verification', () => {
  test('Mock Game Adapter must fulfill lifecycle lifecycle methods without error', async () => {
    const adapter = new MockGameAdapter();
    await adapter.initialize({ debug: true });
    await adapter.load('game-viewport');

    const session = await adapter.startSession('usr_777', 'dice');
    assert.equal(session.status, 'ACTIVE');

    const round = await adapter.submitAction({ bet: 50 });
    assert.equal(round.settlementStatus, 'SETTLED');
    assert.equal(round.result?.payout, 100);

    await adapter.destroy();
  });
});
