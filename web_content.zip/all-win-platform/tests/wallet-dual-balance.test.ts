import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import type { DualBalance, StandardPaymentMethod } from '../src/core/types/wallet.js';
import { DEPOSIT_LIMITS, WITHDRAWAL_LIMITS } from '../src/core/types/wallet.js';

describe('Wallet Dual Balance & Provider Architecture Invariants', () => {
  test('DualBalance contract must preserve Real and Bonus balances separately', () => {
    const wallet: DualBalance = {
      totalBalance: 6200,
      realBalance: 5000,
      bonusBalance: 1200,
      withdrawableBalance: 5000,
      currency: 'BDT',
      updatedAt: new Date(),
    };

    assert.equal(typeof wallet.realBalance, 'number');
    assert.equal(typeof wallet.bonusBalance, 'number');
    assert.ok(wallet.realBalance >= 0, 'Real balance must be non-negative');
    assert.ok(wallet.bonusBalance >= 0, 'Bonus balance must be non-negative');
    assert.equal(wallet.totalBalance, wallet.realBalance + wallet.bonusBalance);
  });

  test('Deposit limits must be ৳100 minimum and ৳100,000 maximum', () => {
    assert.equal(DEPOSIT_LIMITS.minAmount, 100);
    assert.equal(DEPOSIT_LIMITS.maxAmount, 100000);
    assert.equal(DEPOSIT_LIMITS.currency, 'BDT');
  });

  test('Withdrawal limits must enforce 3 requests/day, ৳50,000 max/request, and undefined minimum', () => {
    assert.equal(WITHDRAWAL_LIMITS.maxRequestsPerDay, 3);
    assert.equal(WITHDRAWAL_LIMITS.maxAmountPerRequest, 50000);
    assert.equal(WITHDRAWAL_LIMITS.minAmountPerRequest, 'CONFIGURABLE / REQUIRES PRODUCT DECISION');
  });

  test('Standard payment methods must NOT contain Agent withdrawal options', () => {
    const supportedMethods: StandardPaymentMethod[] = [
      'BKASH',
      'NAGAD',
      'ROCKET',
      'BANK_TRANSFER',
    ];

    for (const method of supportedMethods) {
      assert.notEqual(method, 'AGENT', 'Agent withdrawal is prohibited');
      assert.ok(!method.includes('AGENT'), 'No agent payment methods permitted');
    }
  });
});
