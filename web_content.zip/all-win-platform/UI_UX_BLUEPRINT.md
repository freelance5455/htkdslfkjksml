# ALL WIN — Master UI/UX & Screen Blueprint Specification

## 1. Global Navigation Architecture
### Absolute Bottom Navigation Lock
The ALL WIN User App bottom navigation is permanently locked to **exactly 5 equally-spaced items**:
```
┌─────────────────────────────────────────────────────────┐
│  [🏠]       [📊]        [🎁]       [👛]       [☰]       │
│  HOME     ACTIVITY    PROMOTION   WALLET     MENU       │
└─────────────────────────────────────────────────────────┘
```
- Equal width (20% each), equal horizontal spacing, equal interaction area.
- No floating center button.
- Wallet is a standard bottom navigation tab.
- Logout is NOT in bottom nav (located at the bottom of MENU page with controlled vertical gap).

---

## 2. Authentication UI & Layout Specifications

### 2.1 Register Page Layout & Validation
```
┌───────────────────────────────────────────┐
│ ←            ALL WIN LOGO             EN⌄ │
│                                           │
│ Register                                  │
│ Please register by phone number or email  │
├───────────────────────────────────────────┤
│                                           │
│               [PHONE]                     │
│         Register your phone               │
│ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ │
│                                           │
│ [PHONE] Phone number                      │
│ ┌─────────┐ ┌───────────────────────────┐ │
│ │🇧🇩 +880⌄ │ │ Please enter phone number │ │
│ └─────────┘ └───────────────────────────┘ │
│  ⚠ Number is incomplete. Please enter a   │
│    valid 11-digit phone number.           │
│                                           │
│ [LOCK] Set password                       │
│ ┌───────────────────────────────────── 👁 │
│ │ Set password                            │
│ └─────────────────────────────────────────┘
│                                           │
│ [LOCK] Confirm password                   │
│ ┌───────────────────────────────────── 👁 │
│ │ Confirm password                        │
│ └─────────────────────────────────────────┘
│                                           │
│ [INVITE] Invite code                      │
│ ┌─────────────────────────────────────────┐
│ │ Please enter invitation code            │
│ └─────────────────────────────────────────┘
│                                           │
│ ☑ I have read and agree Privacy Agreement │
│                                           │
│             [ REGISTER ]                  │
│                                           │
│        I have an account. Login           │
└───────────────────────────────────────────┘
```

#### Phone Number Validation Rules (Bangladesh 🇧🇩):
- Country selector displays **Bangladesh 🇧🇩 +880** only.
- Local number input expects **exactly 11 digits** starting with `01` (e.g., `01XXXXXXXXX`).
- **Validation State**:
  - While incomplete or invalid: Small red text under field ("Number is incomplete. Please enter a valid 11-digit phone number.").
  - When exactly 11 digits starting with `01` are entered: Red text disappears, and a **green checkmark** appears on the far-right inside the field.
- **Privacy Agreement**: Checkbox required to enable submission.

---

### 2.2 Login Page Layout
```
┌───────────────────────────────────────────┐
│ ←            ALL WIN LOGO             EN⌄ │
│                                           │
│ Log in                                    │
│ Please log in with your phone number or   │
│ email. If you forget your password,       │
│ please contact customer service.          │
├───────────────────────────────────────────┤
│    [PHONE]                  [EMAIL]       │
│ Phone number              Email Login     │
│ ━━━━━━━━━━━━             ━━━━━━━━━━━━     │
│                                           │
│ [PHONE] Phone number                      │
│ ┌─────────┐ ┌───────────────────────────┐ │
│ │🇧🇩 +880⌄ │ │ Enter phone no.           │ │
│ └─────────┘ └───────────────────────────┘ │
│                                           │
│ [LOCK] Password                           │
│ ┌───────────────────────────────────── 👁 │
│ │ •••••••••••••••                         │
│ └─────────────────────────────────────────┘
│                                           │
│ ☑ Remember password                       │
│                                           │
│               [ LOG IN ]                  │
│               [ REGISTER ]                │
│                                           │
│ [🔓]                                  [💬] │
│ Forgot password            Customer Service│
└───────────────────────────────────────────┘
```
- Forgot Password routes to **Customer Service** recovery path.

---

## 3. Home Page & Footer Specification

### 3.1 Home Page Layout
Header features ALL WIN logo, Notification bell `🔔`, and Menu shortcut `☰`.
Body contains:
1. Hero / Promotional Banner Carousel
2. Category Quick Access (Originals, Slots, Crash, Table Games, Lottery, Instant Mini, Arcade)
3. Featured Games Grid
4. Popular Games Grid
5. New & Recommended Games Grid
6. Exact Home Footer Copy
7. Locked 5-Item Bottom Navigation Bar

### 3.2 Exact Home Footer Copy
> **AllWin**
>
> AllWin is your destination for online video games, slots, and casino entertainment.
> We partner with over 10,000 game and casino providers, all certified for fair play. Enjoy fast deposits, quick withdrawals, and friendly 24/7 customer support.
> Play responsibly. Gambling can be addictive. Set limits and play for fun.
> AllWin is only for players aged 18 and over.

---

## 4. Modal System Specifications

### 4.1 Game Entry Tips Modal
When a user taps "PLAY" on a game card:
```
┌───────────────────────────────────────────┐
│                   Tips                    │
│                                           │
│       Are you sure you want to join       │
│                 this game?                │
│                                           │
│   ┌─────────────┐       ┌─────────────┐   │
│   │   Cancel    │       │   Confirm   │   │
│   └─────────────┘       └─────────────┘   │
└───────────────────────────────────────────┘
```
- **Cancel Button**: White background, Black text.
- **Confirm Button**: White background, **Deep Green text (`#01A879`)**.

### 4.2 Game Exit Modal
When a user attempts to leave an active game:
```
┌───────────────────────────────────────────┐
│                Leave Game?                │
│                                           │
│       Are you sure you want to leave      │
│                 this game?                │
│                                           │
│   ┌─────────────┐       ┌─────────────┐   │
│   │   Cancel    │       │    Leave    │   │
│   └─────────────┘       └─────────────┘   │
└───────────────────────────────────────────┘
```
- **Cancel Button**: White background, Black text.
- **Leave Button**: White background, **Red text (`#E92844`)**.

### 4.3 Logout Confirmation Modal
Triggered from the bottom of the MENU page:
```
┌───────────────────────────────────────────┐
│                  Logout?                  │
│                                           │
│       Are you sure you want to log        │
│                   out?                    │
│                                           │
│   ┌─────────────┐       ┌─────────────┐   │
│   │   Cancel    │       │   Confirm   │   │
│   └─────────────┘       └─────────────┘   │
└───────────────────────────────────────────┘
```
- **Cancel Button**: White background, Black text.
- **Confirm Button**: White background, **Deep Green text (`#01A879`)**.

---

## 5. Wallet, Deposit & Withdrawal UI Specifications

### 5.1 Wallet Page Layout
```
┌───────────────────────────────────────────┐
│ Wallet                                 ↻  │
├───────────────────────────────────────────┤
│ Total Balance                             │
│ ৳6,200.00                                 │
│                                           │
│ Real Balance (Withdrawable)               │
│ ৳5,000.00                                 │
│                                           │
│ Bonus Balance (Promotional)               │
│ ৳1,200.00                                 │
│                                           │
│   ┌───────────────┐     ┌─────────────┐   │
│   │   Deposit     │     │  Withdraw   │   │
│   └───────────────┘     └─────────────┘   │
│                                           │
│ Transaction History                       │
└───────────────────────────────────────────┘
```

### 5.2 Deposit Page Layout
- **Methods**: bKash, Nagad, Rocket, Bank Transfer.
- **Channels**: Cash Out, Send Money.
- **Limits**: Minimum **৳100**, Maximum **৳100,000**.
- **Fields**: Method selection, Channel selection, Amount, Operator payment number (with Copy button), Transaction ID (TrxID) input, Submit button.
- **Canonical State Machine**: `CREATED` -> `PAYMENT_IN_PROGRESS` -> `SUBMITTED` -> `VERIFICATION_PENDING` -> `PROCESSING` -> `COMPLETED` (Terminal `FAILED` / `REJECTED` / `CANCELLED` / `EXPIRED`).

### 5.3 Withdrawal Page Layout
- **Limits**: Maximum **3 requests per day**, Maximum **৳50,000 per request**, Minimum withdrawal: `CONFIGURABLE / REQUIRES PRODUCT DECISION`.
- **Fields**: Available Balance, Withdrawable Balance, Daily counter (e.g. 1/3, Remaining: 2), Amount, Method selection, Destination Account number, "Save account" checkbox, Fee display, Estimated processing time ("up to 3–4 hours"), Withdraw button.
- **Canonical State Machine**: `CREATED` -> `SUBMITTED` -> `UNDER_REVIEW` -> `PROCESSING` -> `SENT_TO_PROVIDER` -> `COMPLETED` (Terminal `FAILED` / `REJECTED` / `CANCELLED` / `RETURNED`).

---

## 6. Activity, Promotion & Menu Page Specifications

### 6.1 Activity Page
Contains Bonus Hub (Today's Bonus, Total Bonus, Bonus Details), Attendance Bonus, Daily Check-In, Member Activities, Game Activity Summary (Wins, Losses, Pending, Completed), and Active Sessions with "Return to Game" CTA.

### 6.2 Promotion & Referral Page
Contains 2 main tabs:
1. **Promotions**: Featured, Deposit Offers, Game Promos, Challenges, Events.
2. **Referral / Partner**: Direct Subordinates, Team Subordinates, Yesterday's Commission, Upgrade Level, Registration Count, Deposit Count, Deposit Amount, First-deposit members, Invite Code (with Copy), Invite QR code. (**NO Agent Withdrawal**).

### 6.3 Menu Page Layout & Logout Position
Vertical list: Profile, VIP, History (Game History, Transaction History, Deposit History, Withdrawal History), Gifts, Statistics, Notifications, Language (EN/BN), Service Center (Settings, Feedback, Announcement, Customer Service, Beginner's Guide, About Us), Security, Responsible Gaming, Settings.
- **LOGOUT**: Located at the very bottom with a controlled vertical gap and top border separator.

---

## 7. Design Tokens & Visual Language
- **Gold Accent**: `#C58937`
- **Dark Navy Base**: `#12213D`
- **Success Green**: `#01A879`
- **Danger Red**: `#E92844`
- **Dark Background**: `#0B0E14`
- **Currency Format**: Centralized `৳` symbol (e.g. `৳100`, `৳1,000`).
- **Languages**: English (`EN`) and Bengali (`BN`).
