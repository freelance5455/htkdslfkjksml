# ALL WIN — Wallet Architecture

## 1. Dual-Balance Ledger Model
ALL WIN explicitly separates user balances into two ledgers:
- **Real Balance**: Funds deposited by the user or won from real-money stakes. Fully withdrawable.
- **Bonus Balance**: Promotional rewards, deposit matches, or loyalty bonuses. Subject to wagering requirements before converting to Real Balance.

```
ALL WIN WALLET
├── Real Balance (Withdrawable)
└── Bonus Balance (Promotional / Restricted)
```

## 2. Deposit Flow & State Machine
`Wallet` -> `Deposit` -> `Select Method` (`bKash`, `Nagad`, `Rocket`, `Bank`) -> `Select Channel` (`Cash Out`, `Send Money`) -> `Amount` -> `Payment Instructions & Operator Number Copy` -> `Transaction ID (TrxID)` -> `Submit`.
- **Limits**: Minimum **৳100**, Maximum **৳100,000**.
- **Canonical Deposit State Machine**: `CREATED` -> `PAYMENT_IN_PROGRESS` -> `SUBMITTED` -> `VERIFICATION_PENDING` -> `PROCESSING` -> `COMPLETED` (Terminal states: `FAILED`, `REJECTED`, `CANCELLED`, `EXPIRED`).

## 3. Withdrawal Flow & State Machine
`Wallet` -> `Withdraw` -> `Select Method` -> `Destination Account` -> `Amount` -> `Security Verification` -> `Submit`.
- **Limits**: Maximum **3 requests per day**, Maximum **৳50,000 per request**, Minimum withdrawal is **`CONFIGURABLE / REQUIRES PRODUCT DECISION`**.
- **Estimated Time**: "up to 3–4 hours".
- **STRICT REQUIREMENT**: No Agent withdrawal option is permitted anywhere in the architecture.
- **Canonical Withdrawal State Machine**: `CREATED` -> `SUBMITTED` -> `UNDER_REVIEW` -> `PROCESSING` -> `SENT_TO_PROVIDER` -> `COMPLETED` (Terminal states: `FAILED`, `REJECTED`, `CANCELLED`, `RETURNED`).

## 4. Separation of Wallet History vs Game History
- **Wallet History**: Financial ledger entries (Deposits, Withdrawals, Refunds, Bonus credits).
- **Game History**: Individual game rounds, bets, multipliers, and outcomes.
