# ALL WIN — Master Game Inventory

Total Game References: 83
Total Playable Games: 44
Total Unique Playable Games: 28

| Game Name | Source | Category | Route / Path | Playable | UI Quality | Mechanics | Animation | Mobile | License | Integration Feasibility | Recommendation |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Blackjack | Afterhand | Table Games | app/games/blackjack | Yes | High | 6-Deck Basic Strategy / Coach | Framer Motion | Yes | MIT | Class A | Primary candidate for Blackjack UI/Coaching |
| Texas Hold'em Poker | Afterhand | Table Games | app/games/poker | Yes | High | 4-Handed AI / Monte Carlo Equity | Framer Motion | Yes | MIT | Class A | Primary candidate for Poker Engine & AI |
| Baccarat | Afterhand | Table Games | app/games/baccarat | Yes | High | 3rd Card Tableau Rules | Framer Motion | Yes | MIT | Class A | Primary candidate for Baccarat UI |
| Roulette | Afterhand | Table Games | app/games/roulette | Yes | High | European/American Wheels | CSS / Motion | Yes | MIT | Class A | Primary candidate for Roulette Wheel/Board |
| Daily Check-in | play-kit | Instant / Mini | packages/games/src/games/daily-checkin | Yes | High | Check-in State | Smooth | Yes | MIT | Class A | Use for VIP/Daily Loyalty |
| Doll Machine | play-kit | Instant / Mini | packages/games/src/games/doll-machine | Yes | High | Claw Grab | Smooth | Yes | MIT | Class A | Primary candidate for Claw Arcade |
| Flip Match | play-kit | Instant / Mini | packages/games/src/games/flip-match | Yes | High | Memory Cards | Smooth | Yes | MIT | Class A | Use for Casual Skill Games |
| Gift Box | play-kit | Instant / Mini | packages/games/src/games/gift-box | Yes | High | Box Open | Smooth | Yes | MIT | Class A | Use for Bonus/Reward Reveals |
| Gift Rain | play-kit | Instant / Mini | packages/games/src/games/gift-rain | Yes | High | Catching Game | Smooth | Yes | MIT | Class A | Use for Event Rain promos |
| Guess Gift | play-kit | Instant / Mini | packages/games/src/games/guess-gift | Yes | High | 3-Box Choice | Smooth | Yes | MIT | Class A | Use for Instant Win promos |
| Lotto Roll | play-kit | Lottery | packages/games/src/games/lotto-roll | Yes | High | Ball Spin | Smooth | Yes | MIT | Class A | Primary candidate for Lotto |
| Lucky Wheel | play-kit | Instant / Mini | packages/games/src/games/lucky-wheel | Yes | High | Wheel Spin | Smooth | Yes | MIT | Class A | Primary candidate for Promo Wheel |
| Marquee | play-kit | Instant / Mini | packages/games/src/games/marquee | Yes | High | Light Marquee | Smooth | Yes | MIT | Class A | Use for Mini Slots |
| Nine Grid | play-kit | Instant / Mini | packages/games/src/games/nine-grid | Yes | High | Grid Spinner | Smooth | Yes | MIT | Class A | Use for Grid Rewards |
| Quiz | play-kit | Instant / Mini | packages/games/src/games/quiz | Yes | High | Trivia Choice | Smooth | Yes | MIT | Class A | Use for Community Quizzes |
| Ring Toss | play-kit | Instant / Mini | packages/games/src/games/ring-toss | Yes | High | Physics Toss | Smooth | Yes | MIT | Class A | Use for Arcade Skill |
| Scratch Card | play-kit | Instant / Mini | packages/games/src/games/scratch-card | Yes | High | Canvas Scratch | Smooth | Yes | MIT | Class A | Primary candidate for Scratch Cards |
| Shake | play-kit | Instant / Mini | packages/games/src/games/shake | Yes | High | Accelerometer | Smooth | Yes | MIT | Class A | Use for Mobile Shake Promo |
| Shake Dice | play-kit | Instant / Mini | packages/games/src/games/shake-dice | Yes | High | Dice Cup | Smooth | Yes | MIT | Class A | Use for Casual Dice |
| Slot Machine | play-kit | Slots | packages/games/src/games/slot-machine | Yes | High | 3-Reel Slot | Smooth | Yes | MIT | Class A | Use for Mini Slot promos |
| Smash Egg | play-kit | Instant / Mini | packages/games/src/games/smash-egg | Yes | High | Hammer Smash | Smooth | Yes | MIT | Class A | Primary candidate for Egg Smash promo |
| Harlequin's Fortune | SlotGame | Slots | src/components/Reels.tsx | Yes | High | 10-Line Slot / Wilds | Canvas/CSS | Yes | UNVERIFIED | Class A | Primary candidate for Main Slot Engine |
| Crash | stake-originals-clone | Crash | src/components/CrashGame | Yes | High | Multiplier Curve | Chart/Canvas | Yes | UNVERIFIED | Class B | Adapt with vfair server seed |
| Plinko | stake-originals-clone | Originals | src/components/PlinkoGame | Yes | High | Phaser/Matter Physics | Phaser 3 | Yes | UNVERIFIED | Class B | Primary candidate for Plinko Visuals |
| Dino Run | stake-originals-clone | Arcade | src/components/DinoGame | Yes | High | Runner Arcade | Phaser 3 | Yes | UNVERIFIED | Class B | Primary candidate for Dino Arcade |
| Mines | stake-originals-clone | Originals | src/components/MinesGame | Yes | High | Grid Reveal | CSS Motion | Yes | UNVERIFIED | Class B | Adapt UI with vfair backend |
| Dice | vfair-games | Originals | apps/dice-web | Yes | High | Provably Fair Dice | Radix/CSS | Yes | Apache 2.0 | Class A | Primary Backend Core for Dice |
| Limbo | vfair-games | Originals | apps/limbo-web | Yes | High | Provably Fair Limbo | Radix/CSS | Yes | Apache 2.0 | Class A | Primary Backend Core for Limbo |
| Mines | vfair-games | Originals | apps/mines-web | Yes | High | Provably Fair Mines | Radix/CSS | Yes | Apache 2.0 | Class A | Primary Backend Core for Mines |
| Plinko | vfair-games | Originals | apps/plinko-web | Yes | High | Provably Fair Plinko | Radix/CSS | Yes | Apache 2.0 | Class A | Primary Backend Core for Plinko Math |
| Keno | vfair-games | Lottery | apps/keno-web | Yes | High | Provably Fair Keno | Radix/CSS | Yes | Apache 2.0 | Class A | Primary Backend Core for Keno |
| Baccarat | casino | Table Games | pages/Baccarat.tsx | Yes | Medium | Card Dealing | CSS | Partial | GPL v3 | Class C | Reference only due to GPL v3 |
| Blackjack | casino | Table Games | pages/Blackjack.tsx | Yes | Medium | Card Dealing | CSS | Partial | GPL v3 | Class C | Reference only due to GPL v3 |
| Coinflip | casino | Instant / Mini | pages/Coinflip.tsx | Yes | Medium | Coin Spin | CSS | Yes | GPL v3 | Class C | Reference only due to GPL v3 |
| Crash | casino | Crash | pages/Crash.tsx | Yes | Medium | Multiplier Curve | Canvas | Yes | GPL v3 | Class C | Reference only due to GPL v3 |
| Dice | casino | Originals | pages/Dice.tsx | Yes | Medium | Slider Range | CSS | Yes | GPL v3 | Class C | Reference only due to GPL v3 |
| Keno | casino | Lottery | pages/Keno.tsx | Yes | Medium | Grid Select | CSS | Yes | GPL v3 | Class C | Reference only due to GPL v3 |
| Matka | casino | Lottery | pages/Matka.tsx | Yes | Medium | Card/Satta Draw | CSS | Yes | GPL v3 | Class C | Reference only for Matka mechanics |
| Mines | casino | Originals | pages/Mines.tsx | Yes | Medium | Grid Reveal | CSS | Yes | GPL v3 | Class C | Reference only due to GPL v3 |
| Plinko | casino | Originals | pages/Plinko.tsx | Yes | Medium | Canvas Pegs | Canvas | Yes | GPL v3 | Class C | Reference only due to GPL v3 |
| Roulette | casino | Table Games | pages/Roulette.tsx | Yes | Medium | Wheel Animation | CSS | Yes | GPL v3 | Class C | Reference only due to GPL v3 |
| Slots | casino | Slots | pages/Slots.tsx | Yes | Medium | Reel Spin | CSS | Yes | GPL v3 | Class C | Reference only due to GPL v3 |
| Teen Patti | casino | Table Games | pages/TeenPatti.tsx | Yes | Medium | 3-Card Poker | CSS | Yes | GPL v3 | Class C | Reference only for Teen Patti rules |
| Wheel | casino | Instant / Mini | pages/Wheel.tsx | Yes | Medium | Wheel Spin | CSS | Yes | GPL v3 | Class C | Reference only due to GPL v3 |
| Dice | Rush | Originals | src/app/api/games/dice/play | Yes | High | Server API Bet | Tailwind CSS | Yes | MIT | Class B | Candidate for Next.js API route |
| Limbo | Rush | Originals | src/app/api/games/limbo/play | Yes | High | Server API Bet | Tailwind CSS | Yes | MIT | Class B | Candidate for Next.js API route |
| Plinko | Rush | Originals | src/app/api/games/plinko/play | Yes | High | Server API Bet | Tailwind CSS | Yes | MIT | Class B | Candidate for Next.js API route |
| Keno | Rush | Lottery | src/app/api/games/keno/play | Yes | High | Server API Bet | Tailwind CSS | Yes | MIT | Class B | Candidate for Next.js API route |
| Roulette | Rush | Table Games | src/app/api/games/roulette/play | Yes | High | Server API Bet | Tailwind CSS | Yes | MIT | Class B | Candidate for Next.js API route |
| Wheel | Rush | Instant / Mini | src/app/api/games/wheel/play | Yes | High | Server API Bet | Tailwind CSS | Yes | MIT | Class B | Candidate for Next.js API route |
| Slots | Rush | Slots | src/app/api/games/slots/play | Yes | High | Server API Bet | Tailwind CSS | Yes | MIT | Class B | Candidate for Next.js API route |
| Baccarat | Rush | Table Games | src/app/api/games/baccarat/play | Yes | High | Server API Bet | Tailwind CSS | Yes | MIT | Class B | Candidate for Next.js API route |
| Diamonds | Rush | Originals | src/app/api/games/diamonds/play | Yes | High | 5-Gem Match | Tailwind CSS | Yes | MIT | Class B | Primary candidate for Diamonds game |
| Mines | Rush | Originals | src/app/api/games/mines/* | Yes | High | Server Reveal/Cashout | Tailwind CSS | Yes | MIT | Class B | Candidate for Next.js API route |
| Dragon Tower | Rush | Originals | src/app/api/games/dragon-tower/* | Yes | High | Tower Climb | Tailwind CSS | Yes | MIT | Class B | Primary candidate for Dragon Tower |
| Hilo | Rush | Originals | src/app/api/games/hilo/* | Yes | High | Higher/Lower Card | Tailwind CSS | Yes | MIT | Class B | Primary candidate for Hilo game |
| Blackjack | Rush | Table Games | src/app/api/games/blackjack/* | Yes | High | Hit/Stand/Double | Tailwind CSS | Yes | MIT | Class B | Candidate for Next.js API route |
| Crash | Rush | Crash | src/app/api/games/crash/* | Yes | High | Real-time Tick | Tailwind CSS | Yes | MIT | Class B | Candidate for real-time multiplayer Crash |
| Chicken | Rush | Instant / Mini | src/app/api/games/chicken/* | Yes | High | Cross Road / Step | Tailwind CSS | Yes | MIT | Class B | Primary candidate for Chicken game |
| Crate Run | Rush | Arcade | src/app/api/games/crate-run/play | Yes | High | Crate Open Run | Tailwind CSS | Yes | MIT | Class B | Primary candidate for Crate Run |
| Flappy | Rush | Arcade | src/app/api/lobbies/.../flappy | Yes | High | Flappy Bird Arcade | Canvas | Yes | MIT | Class B | Primary candidate for Flappy Arcade |
| Dice (Doc Ref) | Bet | Originals | README.md | Doc Ref | N/A | HMAC-SHA256 | N/A | Yes | UNVERIFIED | Class C | Specification reference |
| Limbo (Doc Ref) | Bet | Originals | README.md | Doc Ref | N/A | HMAC-SHA256 | N/A | Yes | UNVERIFIED | Class C | Specification reference |
| Crash (Doc Ref) | Bet | Crash | README.md | Doc Ref | N/A | HMAC-SHA256 | N/A | Yes | UNVERIFIED | Class C | Specification reference |
| Mines (Doc Ref) | Bet | Originals | README.md | Doc Ref | N/A | HMAC-SHA256 | N/A | Yes | UNVERIFIED | Class C | Specification reference |
| Plinko (Doc Ref) | Bet | Originals | README.md | Doc Ref | N/A | HMAC-SHA256 | N/A | Yes | UNVERIFIED | Class C | Specification reference |
| Wheel (Doc Ref) | Bet | Instant / Mini | README.md | Doc Ref | N/A | HMAC-SHA256 | N/A | Yes | UNVERIFIED | Class C | Specification reference |
| Keno (Doc Ref) | Bet | Lottery | README.md | Doc Ref | N/A | HMAC-SHA256 | N/A | Yes | UNVERIFIED | Class C | Specification reference |
| Coin Flip (Doc Ref) | Bet | Instant / Mini | README.md | Doc Ref | N/A | HMAC-SHA256 | N/A | Yes | UNVERIFIED | Class C | Specification reference |
| Hilo (Doc Ref) | Bet | Originals | README.md | Doc Ref | N/A | HMAC-SHA256 | N/A | Yes | UNVERIFIED | Class C | Specification reference |
| Dragon Tower (Doc Ref) | Bet | Originals | README.md | Doc Ref | N/A | HMAC-SHA256 | N/A | Yes | UNVERIFIED | Class C | Specification reference |
| Diamonds (Doc Ref) | Bet | Originals | README.md | Doc Ref | N/A | HMAC-SHA256 | N/A | Yes | UNVERIFIED | Class C | Specification reference |
| Roulette (Doc Ref) | Bet | Table Games | README.md | Doc Ref | N/A | HMAC-SHA256 | N/A | Yes | UNVERIFIED | Class C | Specification reference |
| Blackjack (Doc Ref) | Bet | Table Games | README.md | Doc Ref | N/A | HMAC-SHA256 | N/A | Yes | UNVERIFIED | Class C | Specification reference |
| Baccarat (Doc Ref) | Bet | Table Games | README.md | Doc Ref | N/A | HMAC-SHA256 | N/A | Yes | UNVERIFIED | Class C | Specification reference |
| Teen Patti (Doc Ref) | Bet | Table Games | README.md | Doc Ref | N/A | 3-Card Poker | N/A | Yes | UNVERIFIED | Class C | Specification reference |
| Andar Bahar (Doc Ref) | Bet | Table Games | README.md | Doc Ref | N/A | Andar/Bahar Match | N/A | Yes | UNVERIFIED | Class C | Specification reference |
| Dragon Tiger (Doc Ref) | Bet | Table Games | README.md | Doc Ref | N/A | 2-Card Comparison | N/A | Yes | UNVERIFIED | Class C | Specification reference |
| Sic Bo (Doc Ref) | Bet | Table Games | README.md | Doc Ref | N/A | 3-Dice Combination | N/A | Yes | UNVERIFIED | Class C | Specification reference |
| Casino War (Doc Ref) | Bet | Table Games | README.md | Doc Ref | N/A | High Card Comparison | N/A | Yes | UNVERIFIED | Class C | Specification reference |
| Three Card Poker (Doc Ref) | Bet | Table Games | README.md | Doc Ref | N/A | Pair Plus / Ante | N/A | Yes | UNVERIFIED | Class C | Specification reference |
| Mega Slots (Doc Ref) | Bet | Slots | README.md | Doc Ref | N/A | 5-Payline | N/A | Yes | UNVERIFIED | Class C | Specification reference |
| Live Sportsbook (Doc Ref) | Bet | Other Games | README.md | Doc Ref | N/A | Cricket/Football Odds | N/A | Yes | UNVERIFIED | Class C | Specification reference |
