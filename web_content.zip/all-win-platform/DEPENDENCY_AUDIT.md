# ALL WIN — Dependency & Stack Audit Across All 8 Sources

## Summary of Core Framework Stacks
- **React**: React 19 (`vfair-games`, `Rush`, `Afterhand`, `SlotGame`, `play-kit`), React 18 (`stake-originals-clone`, `casino`).
- **Build Tooling**: Next.js 15/16, Vite 5/7/8, Nx Monorepo 22.7, TypeScript 5.x.
- **Backend Frameworks**: NestJS 11 (`vfair-games`), Next.js Route Handlers (`Rush`).
- **Database & ORM**: PostgreSQL with Prisma 7 (`vfair-games`), PostgreSQL with Supabase (`Rush`).
- **Real-Time Engine**: Socket.IO 4 (`vfair-games`), Pusher Channels (`Rush`).
- **State Management**: Zustand 5 (`vfair-games`, `Afterhand`), TanStack Query 5 (`vfair-games`).
- **Motion & Physics**: Framer Motion 13 (`Afterhand`), Phaser 3.90 (`stake-originals-clone`), Matter.js 0.20 (`stake-originals-clone`).

## License Breakdown
- **MIT License**: `Afterhand`, `Rush`, `play-kit`. Fully compatible with commercial adaptation.
- **Apache License 2.0**: `vfair-games`. Fully compatible with commercial adaptation.
- **GPL v3 (GNU General Public License)**: `casino`. COPYLEFT RISK. Do not copy code directly into proprietary repositories.
- **UNVERIFIED**: `SlotGame`, `stake-originals-clone`, `Bet`. Requires written license clarification before commercial release.
