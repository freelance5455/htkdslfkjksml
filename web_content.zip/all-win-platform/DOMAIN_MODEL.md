# ALL WIN — Domain Model Specification

## 1. User & Profile Domain
Contains `userId`, `username`, `email`, `phone`, `preferredLanguage` (`EN` | `BN`), `theme` (`DARK` | `LIGHT`), `accountStatus`, `pinCreated`, and `securitySettings`.

## 2. Activity Domain
Distinct from Wallet History. Represents recent player gaming activity:
- `ActivityRecord`: `activityId`, `userId`, `gameId`, `type` (`WIN` | `LOSS` | `PENDING`), `stake`, `netResult`, `timestamp`, `sessionId`, `activeSessionReturnRoute`.
- Filterable by Today, Yesterday, 7 Days, 30 Days. Supports "Return to Active Game Session".

## 3. Game History Domain
Provides round-level audit capability. Filterable by Game, Category, Date range, and Net Result. Contains full seed and verification details for provably fair rounds.

## 4. Promotion Domain
Categories: `FEATURED`, `DEPOSIT_OFFERS`, `GAME_PROMOTIONS`, `VIP`, `CHALLENGES`, `REWARDS`, `SPECIAL_EVENTS`.
States: `AVAILABLE`, `CLAIMED`, `LOCKED`, `EXPIRED`, `NOT_ELIGIBLE`. Decoupled from hardcoded UI values via configuration models.

## 5. VIP Domain
Tracks `currentLevel`, `levelName`, `vipPoints`, `pointsToNextLevel`, `monthlyRewardClaimed`, `levelUpRewardClaimed`, and `benefits`. Fully configuration-driven.

## 6. C-Panel & Administrative Domain
Modules: `DASHBOARD`, `PLAYERS`, `GAMES`, `ROUNDS`, `PROMOTIONS`, `VIP`, `TRANSACTIONS`, `ANALYTICS`, `ADMIN_USERS`, `PERMISSIONS`, `AUDIT_LOGS`, `RISK_SAFETY`.

## 7. Audit Logging Domain
Tracks `auditId`, `actorId`, `actorType` (`USER` | `ADMIN` | `SYSTEM`), `action`, `targetType`, `targetId`, `timestamp`, and `metadata`.
