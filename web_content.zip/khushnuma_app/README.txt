KHUSHNUMA SHOPPING APP

Phone par chalane ke liye index.html ko Chrome mein kholen.
Android Chrome menu se “Add to Home screen” / “Install app” choose karein.
Internet ki zarurat pehli baar page kholne ke baad nahi padegi (basic app shell).
Yeh demo/trial storefront hai; real payment, login, inventory aur delivery backend abhi connected nahi hain.
