const {app,BrowserWindow,shell}=require("electron");
function make(){const w=new BrowserWindow({width:1200,height:800,minWidth:380,backgroundColor:"#10131c",autoHideMenuBar:true,icon:__dirname+"/icon-512.png",title:"SCHART.S"});
w.loadFile("index.html");w.webContents.setWindowOpenHandler(({url})=>{shell.openExternal(url);return{action:"deny"}});}
app.whenReady().then(make);
app.on("window-all-closed",()=>{if(process.platform!=="darwin")app.quit()});
