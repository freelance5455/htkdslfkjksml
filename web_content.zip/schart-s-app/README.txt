SCHART.S - app package

A) DESKTOP APP (Windows / Mac / Linux)
   1. Install Node.js (nodejs.org)
   2. In this folder run:   npm install
   3. Try it:               npm start
   4. Build installer:      npm run dist      (installer appears in the "dist" folder)
   Windows -> .exe installer   Mac -> .dmg   Linux -> .AppImage / .deb

B) PHONE APP (Android / iPhone) - no coding
   1. Upload this folder's files to any free HTTPS host (Netlify Drop, GitHub Pages, Cloudflare Pages).
   2. Open the link on your phone:
      Android Chrome: menu > Install app
      iPhone Safari: Share > Add to Home Screen
   3. Optional real APK: paste your link into pwabuilder.com and download the Android package.

First launch: works immediately in Free mode (no key). For better answers: Settings > choose provider > paste API key > Save.
