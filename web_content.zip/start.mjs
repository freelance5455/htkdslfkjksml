import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));
try{process.loadEnvFile(path.join(root,'.env'))}catch(e){if(e.code!=='ENOENT')throw e}
const {default:backend}=await import('./backend/server.cjs');
const port=Number(process.env.PORT)||3000;
http.createServer((req,res)=>{
 if(req.url.startsWith('/api/'))return backend.handleRequest(req,res);
 if(req.url!=='/'&&!req.url.startsWith('/index.html')){res.writeHead(404);return res.end('Not found')}
 res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});
 fs.createReadStream(path.join(root,'public/index.html')).pipe(res);
}).listen(port,'127.0.0.1',()=>console.log(`Th.. AI Studio: http://localhost:${port} (local access only)`));
