# Socle 2.8 — Première scène 3D WebGL du CGD V117

## Objectif
Remplacer la simple inclinaison CSS de l'ancienne vue immersive par un véritable rendu 3D temps réel, sans remplacer ni altérer le moteur réglementaire de jeu de dames.

## Réalisé
- Nouveau module `src/scene-3d.js`, sans dépendance distante ni bibliothèque externe.
- Initialisation d'un contexte WebGL et compilation de shaders de sommets et de fragments.
- Caméra en perspective et matrice de vue 3D.
- Plateau 10×10 composé de surfaces géométriques avec épaisseur et éclairage directionnel.
- Pions et dames modélisés en volumes cylindriques avec plusieurs niveaux, couleurs et reliefs distincts.
- Rendu synchronisé avec l'état réel du damier après chaque interaction et chaque coup de l'IA.
- Les cases restent interactives : sélection, destinations légales, prises et règles demeurent gérées par `draughts.js`.
- Bouton d'activation/désactivation du moteur 3D. Repli sur la vue classique si WebGL n'est pas disponible.
- Aucun CDN ni ressource externe nécessaire.

## Limites assumées
Ce socle constitue une scène 3D WebGL géométrique, pas encore une production photoréaliste comparable à Football Manager 26. Les modèles humains animés, stades 3D détaillés, tribunes, animations cinématiques, textures haute résolution, audio spatial et caméra de retransmission restent à développer. La vérification visuelle navigateur n'a pas pu être menée dans cet environnement (navigation locale bloquée par l'environnement d'exécution).

## Préservation
Le changement porte sur `src/scene-3d.js`, `src/match-ui.js`, `src/app.js`, `index.html`, les tests et la documentation. Les moteurs des huit compétitions ne sont pas modifiés. Le moteur réglementaire `draughts.js` n'est pas modifié.
