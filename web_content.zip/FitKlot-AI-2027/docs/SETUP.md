
# Setup notes

## Change the UPI ID
Open `web/app.js` and replace `ADD_YOUR_UPI_ID` with the exact UPI ID that should receive payment.

## Admin
On the device/browser where you want to manage the local dashboard:
1. Open Account → Admin dashboard.
2. Create the first local admin account.
3. Sign in with that email and password.

The password is not hardcoded in this project. The local account is stored on that device only. Browser storage is not equivalent to server-side security and can be cleared by the user or browser.

## Payment status
Payment records are saved as `Pending verification`. This build deliberately does not mark a payment verified from a UTR alone. Check the actual receipt in your UPI/bank account before treating a payment as received.

## Global users
A local-only application cannot count all unique visitors across separate devices or browsers. A shared backend is required for global analytics and secure cross-device admin access.
