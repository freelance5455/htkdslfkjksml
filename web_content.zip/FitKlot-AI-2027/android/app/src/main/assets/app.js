
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const LEGACY_KEY = 'fitklot_fresh_2027_v1';
  const ACCOUNTS_KEY = 'fitklot_local_accounts_v1';
  const USER_SESSION_KEY = 'fitklot_user_session_v1';
  const LEGACY_MIGRATION_KEY = 'fitklot_legacy_data_migrated_v1';
  let KEY = LEGACY_KEY;
  const UPI_ID = 'priyanshuuuuuu@slc';
  const ADMIN_EMAIL = 'priyanshujangraaaawork@gmail.com';
  const defaults = {profile:{name:'',email:'',height:'',goal:'Build consistency'},meals:[],water:0,weights:[],workouts:[],notes:'',payments:[],strength:[],admin:null,premium:false};
  let currentUser = null;
  let state = freshState();
  function freshState(){return JSON.parse(JSON.stringify(defaults));}
  function userDataKey(email){return 'fitklot_fresh_2027_v1.user.'+encodeURIComponent(String(email).toLowerCase());}
  function getAccounts(){try{return JSON.parse(localStorage.getItem(ACCOUNTS_KEY)||'{}')||{};}catch{return {};}}
  function readUserData(email){
    try{
      const raw=JSON.parse(localStorage.getItem(userDataKey(email))||'{}');
      return {...freshState(),...raw,profile:{...defaults.profile,...(raw.profile||{})}};
    }catch{return freshState();}
  }
  function load(){try{const raw=JSON.parse(localStorage.getItem(KEY)||'{}');return {...freshState(),...raw,profile:{...defaults.profile,...(raw.profile||{})}};}catch{return freshState();}}
  function save(){if(!currentUser)return;localStorage.setItem(KEY,JSON.stringify(state));render();}
  function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
  function toast(msg){const t=$('toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2200);}

  function setAuthView(mode){
    $('authLoginView').classList.toggle('hidden',mode!=='login');
    $('authSignupView').classList.toggle('hidden',mode!=='signup');
    $('authMessage').textContent='';
  }
  function bytesToHex(bytes){return Array.from(bytes).map(v=>v.toString(16).padStart(2,'0')).join('');}
  function randomSalt(){
    if(!window.crypto||!window.crypto.getRandomValues)throw new Error('Secure password storage is unavailable. Open FitKlot using its HTTPS website or supported app browser.');
    const bytes=new Uint8Array(16);window.crypto.getRandomValues(bytes);return bytesToHex(bytes);
  }
  async function deriveLocalPasswordHash(password,saltHex){
    if(!window.crypto||!window.crypto.subtle)throw new Error('Secure sign-in is unavailable in this browser. Please open FitKlot using its HTTPS website or supported app browser.');
    const salt=new Uint8Array(saltHex.match(/.{2}/g).map(v=>parseInt(v,16)));
    const material=await window.crypto.subtle.importKey('raw',new TextEncoder().encode(password),'PBKDF2',false,['deriveBits']);
    const bits=await window.crypto.subtle.deriveBits({name:'PBKDF2',salt,iterations:120000,hash:'SHA-256'},material,256);
    return bytesToHex(new Uint8Array(bits));
  }
  function activateLocalUser(email,showWelcome=true){
    const accounts=getAccounts(),account=accounts[email];
    if(!account)throw new Error('This account was not found on this device.');
    currentUser={email,name:account.name||email.split('@')[0]};
    KEY=userDataKey(email);
    let stored=localStorage.getItem(KEY);
    if(!stored&&!localStorage.getItem(LEGACY_MIGRATION_KEY)){
      const oldData=localStorage.getItem(LEGACY_KEY);
      if(oldData){localStorage.setItem(KEY,oldData);}
      localStorage.setItem(LEGACY_MIGRATION_KEY,'1');
      stored=localStorage.getItem(KEY);
    }
    state=load();
    state.profile=state.profile||{...defaults.profile};
    state.profile.email=email;
    if(!state.profile.name)state.profile.name=currentUser.name;
    localStorage.setItem(KEY,JSON.stringify(state));
    account.lastLogin=new Date().toISOString();
    accounts[email]=account;
    localStorage.setItem(ACCOUNTS_KEY,JSON.stringify(accounts));
    sessionStorage.setItem(USER_SESSION_KEY,email);
    $('authGate').classList.add('hidden');
    $('appShell').classList.remove('guest-hidden');
    $('emailInput').value=email;
    render();
    go('home');
    if(showWelcome)toast('Welcome to FitKlot, '+currentUser.name+'!');
  }
  $('showSignup').addEventListener('click',()=>setAuthView('signup'));
  $('showLogin').addEventListener('click',()=>setAuthView('login'));
  $('signupForm').addEventListener('submit',async e=>{
    e.preventDefault();
    const name=$('signupName').value.trim();
    const email=$('signupEmail').value.trim().toLowerCase();
    const password=$('signupPassword').value;
    const confirmPassword=$('signupPasswordConfirm').value;
    const accounts=getAccounts();
    if(!name){$('authMessage').textContent='Please enter your name.';return;}
    if(password.length<8){$('authMessage').textContent='Use a password with at least 8 characters.';return;}
    if(password!==confirmPassword){$('authMessage').textContent='The passwords do not match.';return;}
    if(accounts[email]){$('authMessage').textContent='An account with this email already exists. Please log in.';return;}
    const button=$('signupForm').querySelector('button[type="submit"]');
    button.disabled=true;button.textContent='Creating account…';
    try{
      const salt=randomSalt(),passwordHash=await deriveLocalPasswordHash(password,salt);
      accounts[email]={name,salt,passwordHash,createdAt:new Date().toISOString(),lastLogin:null};
      localStorage.setItem(ACCOUNTS_KEY,JSON.stringify(accounts));
      $('signupForm').reset();
      activateLocalUser(email,true);
    }catch(error){$('authMessage').textContent=error.message||'Could not create your account. Please try again.';}
    finally{button.disabled=false;button.textContent='✨ Create account';}
  });
  $('loginForm').addEventListener('submit',async e=>{
    e.preventDefault();
    const email=$('loginEmail').value.trim().toLowerCase();
    const password=$('loginPassword').value;
    const accounts=getAccounts(),account=accounts[email];
    if(!account){$('authMessage').textContent='No account found with this email on this device. Please sign up first.';return;}
    const button=$('loginForm').querySelector('button[type="submit"]');
    button.disabled=true;button.textContent='Signing in…';
    try{
      const passwordHash=await deriveLocalPasswordHash(password,account.salt);
      if(passwordHash!==account.passwordHash){$('authMessage').textContent='Incorrect email or password.';return;}
      $('loginForm').reset();
      activateLocalUser(email,true);
    }catch(error){$('authMessage').textContent=error.message||'Could not sign in. Please try again.';}
    finally{button.disabled=false;button.textContent='🔐 Log in';}
  });
  $('userLogout').addEventListener('click',()=>{
    if(currentUser)save();
    sessionStorage.removeItem(USER_SESSION_KEY);
    sessionStorage.removeItem('fitklot_admin_session');
    currentUser=null;KEY=LEGACY_KEY;state=freshState();
    $('appShell').classList.add('guest-hidden');
    $('authGate').classList.remove('hidden');
    $('loginForm').reset();$('signupForm').reset();
    $('loginEmail').value='';
    setAuthView('login');
    $('authMessage').textContent='You have been logged out.';
  });
  function go(name){
    const premiumSections=['workouts','nutrition','progress'];
    if(premiumSections.includes(name) && !state.premium){
      name='payment';
      toast('🔒 This section is included with Premium. View the membership plan below.');
    }
    document.querySelectorAll('.screen').forEach(x=>x.classList.toggle('active',x.id==='screen-'+name));
    document.querySelectorAll('.nav-item').forEach(x=>x.classList.toggle('active',x.dataset.go===name));
    window.scrollTo({top:0,behavior:'smooth'});
    if(name==='admin')renderAdmin();
  }
  document.querySelectorAll('[data-go]').forEach(b=>b.addEventListener('click',()=>go(b.dataset.go)));
  $('profileShortcut').addEventListener('click',()=>go('account'));
  const helpForm = $('helpForm');
  if(helpForm) helpForm.addEventListener('submit', e => {
    e.preventDefault();
    const topic = $('helpTopic').value;
    const message = $('helpMessage').value.trim();
    const subject = encodeURIComponent('[FitKlot Support] ' + topic);
    const body = encodeURIComponent('FitKlot AI support request\\nTopic: ' + topic + '\\n\\nDetails:\\n' + message + '\\n\\nDevice: ' + navigator.userAgent);
    $('helpStatus').textContent = 'Opening your email app. Review the message and press Send.';
    window.location.href = 'mailto:priyanshujangraaaawork@gmail.com?subject=' + subject + '&body=' + body;
  });
  $('todayLabel').textContent=new Intl.DateTimeFormat(undefined,{weekday:'long',month:'long',day:'numeric'}).format(new Date()).toUpperCase();

  const exercises=[['Bodyweight squat','3 sets · 10 reps'],['Incline push-up','3 sets · 8–12 reps'],['Lat pulldown','3 sets · 10 reps'],['Dumbbell shoulder press','2 sets · 10 reps'],['Plank','3 rounds · 20–30 sec']];
  $('exerciseList').innerHTML=exercises.map((e,i)=>`<label class="exercise"><span class="exercise-num">0${i+1}</span><span><b>${e[0]}</b><small>${e[1]}</small></span><input type="checkbox" aria-label="Complete ${e[0]}"></label>`).join('');
  $('completeWorkout').addEventListener('click',()=>{const checked=[...$('exerciseList').querySelectorAll('input:checked')].length;if(!checked){toast('Tick the exercises you completed first.');return;}state.workouts.push({date:new Date().toISOString(),count:checked});save();toast('Workout saved on this device.');});
  $('workoutNotes').value=state.notes;$('saveWorkoutNotes').addEventListener('click',()=>{state.notes=$('workoutNotes').value;save();toast('Notes saved.');});

  const exerciseCatalog = {"Chest": ["Barbell bench press", "Dumbbell bench press", "Incline barbell press", "Incline dumbbell press", "Decline bench press", "Dumbbell fly", "Cable chest fly", "Low-to-high cable fly", "High-to-low cable fly", "Pec deck", "Machine chest press", "Push-up", "Incline push-up", "Decline push-up", "Chest dip"], "Back": ["Pull-up", "Chin-up", "Lat pulldown", "Close-grip lat pulldown", "Straight-arm pulldown", "Barbell bent-over row", "Pendlay row", "T-bar row", "One-arm dumbbell row", "Chest-supported row", "Seated cable row", "Machine row", "Deadlift", "Rack pull", "Back extension"], "Shoulders": ["Standing overhead press", "Seated dumbbell shoulder press", "Arnold press", "Machine shoulder press", "Dumbbell lateral raise", "Cable lateral raise", "Leaning lateral raise", "Front raise", "Reverse pec deck", "Bent-over rear-delt raise", "Face pull", "Upright row", "Barbell shrug", "Dumbbell shrug"], "Biceps": ["Standing barbell curl", "EZ-bar curl", "Alternating dumbbell curl", "Incline dumbbell curl", "Preacher curl", "Spider curl", "Hammer curl", "Cross-body hammer curl", "Cable curl", "Bayesian cable curl", "Concentration curl", "Reverse curl"], "Triceps": ["Close-grip bench press", "Parallel-bar dip", "Cable triceps pushdown", "Rope pushdown", "Overhead cable extension", "Dumbbell overhead extension", "EZ-bar skull crusher", "Lying triceps extension", "Single-arm reverse-grip pushdown", "Diamond push-up"], "Forearms": ["Wrist curl", "Reverse wrist curl", "Behind-the-back wrist curl", "Reverse barbell curl", "Farmer's carry", "Dead hang", "Plate pinch hold", "Wrist roller"], "Quads": ["Barbell back squat", "Front squat", "Goblet squat", "Hack squat", "Leg press", "Bulgarian split squat", "Walking lunge", "Reverse lunge", "Leg extension", "Step-up", "Sissy squat"], "Hamstrings": ["Romanian deadlift", "Stiff-leg deadlift", "Lying leg curl", "Seated leg curl", "Nordic hamstring curl", "Good morning", "Single-leg Romanian deadlift"], "Glutes": ["Barbell hip thrust", "Glute bridge", "Cable kickback", "Cable pull-through", "Sumo deadlift", "Hip abduction machine", "Step-up"], "Calves": ["Standing calf raise", "Seated calf raise", "Leg press calf raise", "Single-leg calf raise", "Donkey calf raise"], "Abs & Core": ["Plank", "Side plank", "Hanging knee raise", "Hanging leg raise", "Cable crunch", "Machine crunch", "Reverse crunch", "Ab wheel rollout", "Dead bug", "Pallof press", "Russian twist", "Bicycle crunch"], "Full Body": ["Barbell clean", "Power clean", "Kettlebell swing", "Thruster", "Burpee", "Turkish get-up", "Sled push", "Battle rope"]};

  let activeExerciseGroup = 'All';
  function renderExerciseLibrary(){
    const query = ($('exerciseSearch').value || '').trim().toLowerCase();
    const groups = ['All', ...Object.keys(exerciseCatalog)];
    $('exerciseFilters').innerHTML = groups.map(group =>
      `<button type="button" class="exercise-filter ${group===activeExerciseGroup?'active':''}" data-exercise-group="${esc(group)}">${esc(group)}</button>`
    ).join('');
    const rows = Object.entries(exerciseCatalog).flatMap(([group,names]) =>
      names.filter(name => (activeExerciseGroup==='All'||activeExerciseGroup===group) && (!query || name.toLowerCase().includes(query) || group.toLowerCase().includes(query)))
        .map(name => ({group,name}))
    );
    const expanded = $('exerciseLibraryList').dataset.expanded === 'true';
    const visibleRows = expanded ? rows : rows.slice(0, 8);
    $('exerciseLibraryList').innerHTML = visibleRows.length ? visibleRows.map(({group,name}) =>
      `<article class="exercise-library-item"><div><b>${esc(name)}</b><small>${esc(group)}</small></div><button type="button" class="add-exercise" data-add-exercise="${esc(name)}">＋ Add</button></article>`
    ).join('') : '<p class="tiny muted">No matching exercises. Try another search or muscle group.</p>';
    $('exerciseViewToggle').classList.toggle('hidden', rows.length <= 8);
    $('exerciseViewToggle').textContent = expanded ? 'View less ↑' : `View more ↓ (${rows.length - 8} more)`;
    $('exerciseLibraryCount').textContent = `${visibleRows.length} of ${rows.length} shown · ${Object.values(exerciseCatalog).reduce((n,a)=>n+a.length,0)} total`;
  }
  $('exerciseSearch').addEventListener('input', () => {
    $('exerciseLibraryList').dataset.expanded = 'false';
    renderExerciseLibrary();
  });
  $('exerciseFilters').addEventListener('click', e => {
    const button=e.target.closest('[data-exercise-group]');
    if(!button)return;
    activeExerciseGroup=button.dataset.exerciseGroup;
    $('exerciseLibraryList').dataset.expanded = 'false';
    renderExerciseLibrary();
  });
  $('exerciseViewToggle').addEventListener('click', () => {
    $('exerciseLibraryList').dataset.expanded = $('exerciseLibraryList').dataset.expanded !== 'true' ? 'true' : 'false';
    renderExerciseLibrary();
  });
  $('exerciseLibraryList').addEventListener('click', e => {
    const button=e.target.closest('[data-add-exercise]');
    if(!button)return;
    const name=button.dataset.addExercise;
    $('strengthExercise').value=name;
    $('strengthExercise').scrollIntoView({behavior:'smooth',block:'center'});
    toast(`${name} added to the strength tracker. Set your sets, reps and weight below.`);
  });
  renderExerciseLibrary();


  $('mealForm').addEventListener('submit',e=>{e.preventDefault();state.meals.push({name:$('mealName').value.trim(),calories:+$('mealCalories').value,protein:+$('mealProtein').value,date:new Date().toISOString()});e.target.reset();save();toast('Meal added.');});
  $('waterPlus').addEventListener('click',()=>{state.water=Math.min(30,state.water+1);save();});$('waterMinus').addEventListener('click',()=>{state.water=Math.max(0,state.water-1);save();});
  $('weightForm').addEventListener('submit',e=>{e.preventDefault();state.weights.push({value:+$('weightInput').value,date:new Date().toISOString()});e.target.reset();save();toast('Weight saved.');});
  $('editProfile').addEventListener('click',()=>{$('profileForm').classList.toggle('hidden');$('nameInput').value=state.profile.name;$('emailInput').value=currentUser?currentUser.email:state.profile.email;$('heightInput').value=state.profile.height;$('goalInput').value=state.profile.goal;});
  $('profileForm').addEventListener('submit',e=>{e.preventDefault();state.profile={name:$('nameInput').value.trim(),email:currentUser?currentUser.email:$('emailInput').value.trim(),height:$('heightInput').value,goal:$('goalInput').value};save();$('profileForm').classList.add('hidden');toast('Profile saved.');});
  $('resetData').addEventListener('click',()=>{
    if(!confirm('Clear all FitKlot data saved on this device? This cannot be undone.')) return;
    try {
      localStorage.removeItem(KEY);
      sessionStorage.removeItem('fitklot_admin_session');
      state = freshState();
      state.profile.email = currentUser ? currentUser.email : '';
      state.profile.name = currentUser ? currentUser.name : '';
      save();
      ['profileForm','mealForm','weightForm','paymentForm','helpForm'].forEach(id=>$(id)?.reset());
      $('workoutNotes').value = '';
      $('proteinWeight').value = '';
      $('proteinResult')?.classList.add('hidden');
      $('bodyTypeResult')?.classList.add('hidden');
      $('paymentConfirmation')?.classList.add('hidden');
      $('adminPassword').value = '';
      $('adminEmail').value = '';
      $('adminLoginPanel')?.classList.add('hidden');
      $('adminPanel')?.classList.add('hidden');
      document.querySelectorAll('.recovery-check').forEach(box=>box.checked=false);
      if($('recoveryText')) $('recoveryText').textContent='Tick the checks that apply to you.';
      go('home');
      toast('All FitKlot data on this device has been reset.');
    } catch (error) {
      console.error('FitKlot reset failed:', error);
      toast('Reset failed. Please close and reopen the app, then try again.');
    }
  });

  $('upiId').textContent=UPI_ID;$('copyUpi').addEventListener('click',async()=>{try{await navigator.clipboard.writeText(UPI_ID);toast('UPI ID copied.');}catch{toast('Copy is not available in this browser.');}});
  $('paymentDate').value=new Date().toISOString().slice(0,10);
  $('paymentForm').addEventListener('submit',e=>{e.preventDefault();const utr=$('utrInput').value.trim();if(utr.length<8){toast('Enter a valid transaction reference.');return;}state.payments.unshift({utr,date:$('paymentDate').value,time:$('paymentTime').value,status:'Pending verification',createdAt:new Date().toISOString()});save();$('paymentForm').reset();$('paymentConfirmation').classList.remove('hidden');$('paymentConfirmation').scrollIntoView({behavior:'smooth',block:'center'});});
  $('backToAccount').addEventListener('click',()=>go('account'));

  async function hashPassword(password){const bytes=new TextEncoder().encode(password);const digest=await crypto.subtle.digest('SHA-256',bytes);return [...new Uint8Array(digest)].map(b=>b.toString(16).padStart(2,'0')).join('');}
  let createMode=false;
  $('adminOpen').addEventListener('click',()=>{go('admin');$('adminLoginPanel').classList.remove('hidden');$('adminPanel').classList.add('hidden');createMode=!state.admin;$('createAdminMode').classList.toggle('hidden',!!state.admin);$('adminSubmit').textContent=createMode?'Create admin account':'Sign in';$('adminMessage').textContent=state.admin?'Sign in with the admin account created on this device.':'No local admin exists yet. Create the first admin account on this device.';});
  $('createAdminMode').addEventListener('click',()=>{createMode=true;$('adminSubmit').textContent='Create admin account';$('adminMessage').textContent='Choose a private email and a strong password (10+ characters).';});
  $('adminForm').addEventListener('submit',async e=>{e.preventDefault();const email=$('adminEmail').value.trim().toLowerCase(),pass=$('adminPassword').value;if(pass.length<10){$('adminMessage').textContent='Use at least 10 characters.';return;}const hash=await hashPassword(pass);if(createMode){if(state.admin){$('adminMessage').textContent='An admin account already exists on this device.';return;}if(email!==ADMIN_EMAIL){$('adminMessage').textContent='Use the designated admin email for this device.';return;}state.admin={email,hash};save();toast('Local admin account created.');}else if(!state.admin||email!==state.admin.email||hash!==state.admin.hash){$('adminMessage').textContent='Email or password is incorrect.';return;}sessionStorage.setItem('fitklot_admin_session','1');$('adminPassword').value='';renderAdmin();});
  $('adminLogout').addEventListener('click',()=>{sessionStorage.removeItem('fitklot_admin_session');renderAdmin();toast('Admin signed out.');});
  function renderAdmin(){
    const ok=sessionStorage.getItem('fitklot_admin_session')==='1'&&!!state.admin&&!!currentUser&&currentUser.email===ADMIN_EMAIL&&state.admin.email===ADMIN_EMAIL;
    $('adminLoginPanel').classList.toggle('hidden',ok);
    $('adminPanel').classList.toggle('hidden',!ok);
    if(!ok)return;
    const accounts=getAccounts();
    const users=Object.entries(accounts).map(([email,account])=>({email,account,data:readUserData(email)}));
    $('adminUserCount').textContent=users.length;
    const allPayments=users.flatMap(user=>(user.data.payments||[]).map((payment,index)=>({email:user.email,payment,index})));
    $('adminPaymentCount').textContent=allPayments.length;
    $('adminUsers').innerHTML=users.length?users.map(user=>`<div class="list-row"><span><b>${esc(user.data.profile.name||user.account.name||'Unnamed user')}</b><small>${esc(user.email)}</small></span><small>On this device</small></div>`).join(''):'<div class="empty-state">No accounts registered on this device.</div>';
    $('adminPayments').innerHTML=allPayments.length?allPayments.map(item=>`<div class="list-row"><span><b>${esc(item.payment.utr)}</b><small>${esc(item.email)} · ${esc(item.payment.date)} · ${esc(item.payment.time)}</small></span><span class="admin-payment-action"><small>${esc(item.payment.status)}</small>${item.payment.status==='Pending verification'?`<button class="text-button" data-approve-email="${encodeURIComponent(item.email)}" data-approve-index="${item.index}">Approve</button>`:''}</span></div>`).join(''):'<div class="empty-state">No submissions yet.</div>';
    $('adminPayments').querySelectorAll('[data-approve-email]').forEach(btn=>btn.addEventListener('click',()=>{
      const email=decodeURIComponent(btn.dataset.approveEmail);
      const target=readUserData(email),payment=target.payments[Number(btn.dataset.approveIndex)];
      if(!payment)return;
      if(!confirm('Have you checked your UPI/bank account and confirmed this payment was received?'))return;
      payment.status='Approved';target.premium=true;
      localStorage.setItem(userDataKey(email),JSON.stringify(target));
      if(currentUser&&currentUser.email===email){state=target;render();}
      renderAdmin();
      toast('Verified payment approved. Premium unlocked for '+email+' on this device.');
    }));
  }
  // Premium fitness calculators and recovery helper
  if($('proteinWeight')){
    const latestWeight=state.weights.length?state.weights[state.weights.length-1].value:'';
    $('proteinWeight').value=latestWeight;
    $('proteinGoal').value=state.profile.goal==='Fat loss'?'fat':state.profile.goal==='Muscle gain'?'muscle':'maintain';
    const updateProtein=()=>{
      const kg=Number($('proteinWeight').value),goal=$('proteinGoal').value;
      if(!Number.isFinite(kg)||kg<25||kg>300){$('proteinResult').classList.add('hidden');return;}
      const ranges={muscle:[1.6,2.2,'muscle gain'],fat:[1.6,2.0,'fat loss'],maintain:[1.2,1.6,'maintenance']};
      const [low,high,label]=ranges[goal],min=Math.round(kg*low),max=Math.round(kg*high);
      $('proteinResult').innerHTML=`<span class="tiny muted">Estimated daily protein range · ${label}</span><strong>${min}–${max} g/day</strong><p class="tiny muted">Calculated from ${kg} kg body weight (${low}–${high} g/kg). This is a general estimate; needs vary with training, age and health. If you have kidney disease or a prescribed diet, ask your clinician before changing protein intake.</p>`;
      $('proteinResult').classList.remove('hidden');
    };
    $('proteinForm').addEventListener('submit',e=>{e.preventDefault();updateProtein();});
    $('proteinWeight').addEventListener('input',updateProtein);$('proteinGoal').addEventListener('change',updateProtein);
    if(latestWeight)updateProtein();
  }
  if($('strengthForm')){
    $('strengthForm').addEventListener('submit',e=>{e.preventDefault();state.strength=state.strength||[];state.strength.unshift({exercise:$('strengthExercise').value.trim(),sets:+$('strengthSets').value,reps:+$('strengthReps').value,weight:+$('strengthWeight').value,date:new Date().toISOString()});save();e.target.reset();$('strengthSets').value=3;$('strengthReps').value=10;toast('Strength entry saved.');});
  }
  if($('bodyTypeForm')){
    $('bodyTypeForm').addEventListener('submit',e=>{
      e.preventDefault();
      const v={build:$('buildInput').value,shape:$('shapeInput').value,gain:$('gainInput').value,fat:$('fatInput').value,muscle:$('muscleInput').value};
      let scores={ectomorph:0,mesomorph:0,endomorph:0};
      if(v.build==='slim')scores.ectomorph+=2; if(v.build==='stocky')scores.endomorph+=2; if(v.build==='average')scores.mesomorph++;
      if(v.shape==='shoulder')scores.mesomorph+=2; if(v.shape==='waist')scores.endomorph+=2; if(v.shape==='similar')scores.ectomorph++;
      if(v.gain==='hard')scores.ectomorph+=2; if(v.gain==='easy')scores.endomorph+=2; if(v.gain==='middle')scores.mesomorph++;
      if(v.fat==='waist')scores.endomorph+=2; if(v.fat==='low')scores.ectomorph+=2; if(v.fat==='even')scores.mesomorph++;
      if(v.muscle==='high')scores.mesomorph+=2; if(v.muscle==='low')scores.ectomorph+=2; if(v.muscle==='average')scores.endomorph++;
      const sorted=Object.entries(scores).sort((a,b)=>b[1]-a[1]);
      const names={ectomorph:'Ectomorph',mesomorph:'Mesomorph',endomorph:'Endomorph'};
      const advice={ectomorph:'You may relate more to a naturally lean build. Prioritise progressive strength training, adequate calories and consistent protein.',mesomorph:'You may relate more to an athletic or naturally muscular build. Use balanced strength training, recovery and nutrition that match your goal.',endomorph:'You may relate more to a stockier build or easier weight gain. Focus on sustainable nutrition, strength training and regular activity rather than extreme dieting.'};
      const top=sorted[0][1],ties=sorted.filter(x=>x[1]===top).map(x=>names[x[0]]);
      const result=ties.length>1?`Mixed traits: ${ties.join(' + ')}`:names[sorted[0][0]];
      const guidance=ties.length>1?'Your answers are mixed, so no single category stands out. Use the training and nutrition habits that fit your goals.':advice[sorted[0][0]];
      $('bodyTypeResult').innerHTML=`<span class="tiny muted">Your closest traditional body-build match</span><strong>${esc(result)}</strong><p>${esc(guidance)}</p><p class="tiny muted">Important: ectomorph, mesomorph and endomorph are old, simplified somatotype labels. They do not reliably determine metabolism, health or the best workout. Most people have a mix of traits, and body shape can change.</p>`;
      $('bodyTypeResult').classList.remove('hidden');
    });
  }
  document.querySelectorAll('.recovery-check').forEach(box=>box.addEventListener('change',()=>{
    const checked=[...document.querySelectorAll('.recovery-check:checked')].length;
    $('recoveryText').textContent=`${checked} of 4 recovery checks completed. ${checked===4?'Good — still adjust training to how you feel.':checked>=2?'Review anything you left unchecked before deciding your training intensity.':'Consider an easier session or rest if you feel under-recovered.'}`;
  }));

  function render(){
    const today=new Date().toISOString().slice(0,10),meals=state.meals.filter(m=>m.date.slice(0,10)===today),cal=meals.reduce((a,m)=>a+m.calories,0),protein=meals.reduce((a,m)=>a+m.protein,0);
    $('caloriesValue').textContent=cal;$('proteinValue').textContent=protein+'g';$('waterValue').textContent=state.water;$('workoutValue').textContent=state.workouts.length;$('nutritionCalories').textContent=cal;$('nutritionProtein').textContent=protein+'g';$('waterCount').textContent=state.water;$('mealCount').textContent=meals.length+' entries';$('streakValue').textContent=state.workouts.length;
    $('mealList').classList.toggle('empty-state',!meals.length);$('mealList').innerHTML=meals.length?meals.slice().reverse().map(m=>`<div class="list-row"><span><b>${esc(m.name)}</b><small>${m.calories} kcal · ${m.protein}g protein</small></span></div>`).join(''):'No meals logged yet.';
    $('weightHistory').classList.toggle('empty-state',!state.weights.length);$('weightHistory').innerHTML=state.weights.length?state.weights.slice().reverse().map(w=>`<div class="list-row"><b>${w.value} kg</b><small>${new Date(w.date).toLocaleDateString()}</small></div>`).join(''):'Add your first entry to begin.';
    $('consistencyBar').style.width=Math.min(100,state.workouts.length*10)+'%';$('consistencyText').textContent=state.workouts.length+' sessions completed';
    $('profileName').textContent=state.profile.name||'Your profile';$('profileEmail').textContent=state.profile.email||state.profile.goal;$('profileAvatar').textContent=(state.profile.name||'U').charAt(0).toUpperCase();$('avatarInitial').textContent=(state.profile.name||'U').charAt(0).toUpperCase();
    ['workouts','nutrition','progress'].forEach(section=>{
      const nav=document.querySelector(`.nav-item[data-go="${section}"]`);
      if(nav){
        nav.classList.toggle('premium-locked',!state.premium);
        nav.setAttribute('aria-label', (section==='workouts'?'Workout':section==='nutrition'?'Nutrition':'Progress') + (state.premium?'':' - Premium locked'));
        const label=nav.querySelector('small');
        if(label) label.textContent=(section==='workouts'?'Workout':section==='nutrition'?'Nutrition':'Progress')+(state.premium?'':' 🔒');
      }
    });
    $('premiumHomeStatus').textContent=state.premium?'ACTIVE':'LOCKED';$('premiumWorkoutStatus').textContent=state.premium?'ACTIVE':'LOCKED';$('premiumLocked').classList.toggle('hidden',state.premium);$('premiumUnlocked').classList.toggle('hidden',!state.premium);
    if($('strengthHistory')){const logs=state.strength||[];$('strengthHistory').classList.toggle('empty-state',!logs.length);$('strengthHistory').innerHTML=logs.length?logs.slice(0,12).map(x=>`<div class="list-row"><span><b>${esc(x.exercise)}</b><small>${x.sets} sets × ${x.reps} reps · ${x.weight} kg</small></span><small>${new Date(x.date).toLocaleDateString()}</small></div>`).join(''):'No strength entries yet.';}
    $('paymentHistory').classList.toggle('empty-state',!state.payments.length);$('paymentHistory').innerHTML=state.payments.length?state.payments.map(p=>`<div class="list-row"><span><b>${esc(p.utr)}</b><small>${esc(p.date)} · ${esc(p.time)}</small></span><small>${esc(p.status)}</small></div>`).join(''):'No payment submissions yet.';
  }
  function restoreLocalSession(){
    const email=sessionStorage.getItem(USER_SESSION_KEY);
    const accounts=getAccounts();
    if(email&&accounts[email]){
      try{activateLocalUser(email,false);}
      catch(error){sessionStorage.removeItem(USER_SESSION_KEY);$('authMessage').textContent=error.message||'Please log in again.';}
    }else{
      sessionStorage.removeItem(USER_SESSION_KEY);
      $('appShell').classList.add('guest-hidden');
      $('authGate').classList.remove('hidden');
      setAuthView('login');
    }
  }
  restoreLocalSession();
  if('serviceWorker' in navigator && location.protocol.startsWith('http'))navigator.serviceWorker.register('sw.js').catch(()=>{});
})();
