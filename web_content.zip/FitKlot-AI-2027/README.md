
# FitKlot AI — Fresh 2026/2027 Build

A completely new, mobile-first fitness web app with a clean dark interface. This project does not reuse the previous ZIP or its source files.

## Included
- Responsive fitness dashboard
- Workout planner and workout logging
- Premium protein target calculator (updates as weight/goal changes)
- Premium body-build self-check for ectomorph, mesomorph and endomorph traits
- Premium 6-day push/pull/legs guide with a rest day
- Progressive overload log for sets, reps and working weights
- Daily recovery checklist
- Nutrition and water tracking
- Progress tracking
- Account section
- Local payment submission flow (UTR, date, time) with a clear **Submitted — pending verification** status
- Payment history
- Admin-only local dashboard with a first-run admin account setup
- Local user count and local activity records
- PWA manifest and service worker
- Android Java WebView wrapper with local assets

## Fitness calculator notes
- Protein estimates use broad per-kg ranges and are educational estimates, not personalised medical advice.
- The ectomorph/mesomorph/endomorph labels are traditional simplified somatotypes. They are not validated diagnoses and do not determine metabolism or the best training plan. The result describes which answers resemble a category most.
- Premium fitness tools appear after local admin approval of a payment. In this local-first build, premium status does not sync across devices.

## Important limitations
- This is a local-first starter app. Data is stored in the browser/WebView on the device and does not sync across devices.
- A UTR entry alone cannot verify receipt of money. The app never falsely marks an unverified payment as paid or activates paid membership automatically.
- The admin account is local to the device. To have a secure admin dashboard and user counts across all website/app users, a trusted online backend and server-side authorization are required.
- Admin email is prefilled as priyanshujangraaaawork@gmail.com. Create a new local password on first use; the previously shared password is not embedded or reused. Admin can approve a payment only after checking the actual bank/UPI receipt. Local approval unlocks premium on this device only.
- This is a source project, not a signed APK or a deployed website.

## Run the website
Open `web/index.html` in a browser, or serve the `web` folder with any static web server.

## Android
Open the `android` folder in Android Studio. Build with a current Android Gradle setup. The WebView loads bundled local assets from `android/app/src/main/assets`.

## First-time admin setup
First create a normal FitKlot account using the designated admin email priyanshujangraaaawork@gmail.com. Then open Account → Admin dashboard → Create first admin account and set a strong admin password. Admin access applies only to this device.


## Help & FAQ update (v3)
- Added a dedicated Help & FAQ screen reachable from Account.
- Added concise, closed-by-default FAQ items for profile setup, workouts, protein estimates, body-build labels, local data, payments, admin access, reset and safety.
- Added a support form that opens a prefilled email draft; the user must review and send it.
- Kept Help out of the bottom navigation to avoid crowding the app.
- Mirrored website assets into the Android WebView assets and bumped the service-worker cache version.


## Exercise library update (v5)
- Added a searchable, filterable exercise catalogue across chest, back, shoulders, biceps, triceps, forearms, quads, hamstrings, glutes, calves, abs/core and full body.
- Added an Add action that places the selected exercise into the existing strength tracker.
- Added expandable reference routines for Arnold Schwarzenegger, Ronnie Coleman and Chris Bumstead (CBum).
- Routine examples are simplified templates, not claims of exact historical training logs or prescriptions to copy professional volume.
- Synced website assets with Android WebView assets and refreshed the service-worker cache.


## Exercise browser layout update (v6)
- Changed exercise cards from a tall vertical list to a compact horizontal, swipeable row.
- Shows up to eight matching exercises initially.
- Added View more / View less to expand or collapse the filtered results.
- Search and muscle-group changes reset the list to its compact preview.
- Synced website and Android WebView assets; refreshed the service-worker cache.


## Premium section lock update (v7)
- Workout, Nutrition and Progress navigation now routes to Membership while Premium is inactive.
- All three sections unlock together when the existing admin payment-approval flow marks the membership approved.
- Navigation labels show a lock while Premium is inactive.
- Membership page now explains that one approved membership unlocks all three sections.
- This build retains manual UPI/UTR verification; UTR submission alone does not automatically verify payment.
- Website and Android WebView assets synced; service-worker cache refreshed.


## Account login / signup update (v8)
- Added a dedicated FitKlot welcome screen with Sign up and Log in forms.
- Added per-device local accounts with unique email addresses and PBKDF2 password hashes (120,000 SHA-256 iterations plus a random salt).
- Added an Account > Log out action. Logout ends the current app session without deleting that user's saved records.
- Fitness, nutrition, progress, payment and Premium records are stored separately for each local account on this device.
- The first account can inherit existing anonymous app data from the earlier local build so existing entries are not discarded.
- The designated admin account can view local registrations and payment submissions from this device and approve a specific user's submitted payment after checking the bank/UPI receipt.
- Payment approval remains manual and local; there is no server-side authentication, cloud sync, automatic UPI verification or cross-device login.
- Website and Android WebView assets synced; service-worker cache refreshed.

- New sign-ups and logins are device-local. The same email cannot be used to log in on another device unless a future shared authentication backend is connected.
- Account passwords are stored as salted PBKDF2 hashes, not as plain text. This browser-only account system is not a substitute for server-side authentication and cannot provide secure cloud identity or account recovery.
- Users should keep their password safe; a forgotten local password cannot currently be recovered through email.
