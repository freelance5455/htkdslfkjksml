DÖNER CLICKER – KOMPLETTES SPIELPROJEKT

DIESES PROJEKT ENTHÄLT
- 2D-Clicker-Spiel im Querformat mit Querformat-Hinweis im Hochformat
- Selbst gezeichnete Döner-Maskottchen-Grafik (SVG)
- Hauptmenü, Spielansicht, Shop, Inventar und Einstellungen
- 8 rein kosmetische Döner-Skins
- Vier unendlich kaufbare Upgrades mit steigenden Preisen
- Klick-Sounds und einfache prozedural erzeugte Hintergrundmusik
- Automatisches lokales Speichern und Offline-Produktion (maximal 7 Tage gutgeschrieben)
- PWA-Dateien für installierbares/offlinefähiges Web-Erlebnis
- Capacitor-Konfiguration als Grundlage für eine Android-APK

SPCK
1. ZIP entpacken.
2. Den Ordner Döner_Clicker öffnen.
3. index.html, style.css, game.js und den Ordner assets in dein Spck-Projekt übernehmen.
4. Für die Browser-Vorschau index.html starten.
5. Handy ins Querformat drehen.
Wichtig: Der Service Worker funktioniert nur über localhost oder HTTPS, nicht bei jedem lokalen Datei-Preview.

SPIELSTAND
Der Fortschritt wird im lokalen Browser-Speicher unter "kepapClickerSave" abgelegt. Er ist nicht automatisch zwischen Geräten synchronisiert. Vor dem Löschen von Browserdaten sichern.

APK – WICHTIG
Eine ZIP-Datei ist noch keine APK. Dieses Projekt enthält die Capacitor-Konfiguration und package.json als Grundlage, aber keine bereits kompilierte APK und keinen vollständigen Android-Studio-Build-Ordner.
Für eine APK müssen die Webdateien mit Node.js/Vite gebaut und anschließend mit Capacitor in einem Android-Projekt verpackt werden. Dafür wird normalerweise ein Computer mit Android Studio und Android SDK benötigt:
  npm install
  npm run build
  npx cap add android
  npx cap sync android
  npx cap open android
In Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s).
Eine signierte Release-APK erfordert zusätzlich einen eigenen Signaturschlüssel.
Wenn du nur ein Android-Handy verwendest, können wir danach gemeinsam einen passenden Cloud-Build-Weg auswählen. Versprich dir bitte nicht, dass die APK schon in dieser ZIP enthalten ist.

HINWEISE
- Musik ist eine einfache, eigens erzeugte Melodie und kein bekanntes Lied.
- Die Skins verwenden Farbvarianten derselben Original-SVG-Grafik; individuelle komplett neue Zeichnungen können später ergänzt werden.
- Keine Online-Konten, Cloud-Speicherung, Rangliste oder Prestige-Funktion enthalten.
