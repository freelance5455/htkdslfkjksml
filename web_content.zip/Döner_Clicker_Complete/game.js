const $=id=>document.getElementById(id);
const SKINS=[
{id:"classic",name:"Klassischer Döner",price:0,css:"classic"},
{id:"pizza",name:"Pizza-Döner",price:500,css:"pizza"},
{id:"gold",name:"Gold-Döner",price:1500,css:"gold"},
{id:"ice",name:"Eis-Döner",price:800,css:"ice"},
{id:"rainbow",name:"Regenbogen-Döner",price:2000,css:"rainbow"},
{id:"diamond",name:"Diamant-Döner",price:3000,css:"diamond"},
{id:"silver",name:"Silber-Döner",price:1200,css:"silver"},
{id:"cookie",name:"Keks-Döner",price:900,css:"cookie"},
{id:"shadow",name:"Schatten-Döner",price:2500,css:"shadow"}];
const UPGRADES=[
{id:"click",name:"Auto-Klicker",desc:"+1 DC pro Klick",icon:"👆",base:25,rate:1,type:"click"},
{id:"shop",name:"Döner-Shop",desc:"+1 DC pro Sekunde",icon:"🏪",base:75,rate:1,type:"sec"},
{id:"machine",name:"Döner-Maschine",desc:"+5 DC pro Sekunde",icon:"⚙️",base:250,rate:5,type:"sec"},
{id:"chef",name:"Döner-Chef",desc:"+25 DC pro Sekunde",icon:"👨‍🍳",base:1000,rate:25,type:"sec"}];
const SAVE_KEY="kepapClickerSave";
const fresh=()=>({coins:0,levels:{click:0,shop:0,machine:0,chef:0},owned:["classic"],equipped:"classic",music:false,sound:true,last:Date.now()});
let state=load();let audioCtx=null,musicTimer=null,musicStep=0,lastSave=Date.now();
function load(){try{const s=JSON.parse(localStorage.getItem(SAVE_KEY));if(!s)return fresh();const f=fresh();return {...f,...s,levels:{...f.levels,...(s.levels||{})},owned:Array.isArray(s.owned)?s.owned:["classic"]}}catch{return fresh()}}
function save(){state.last=Date.now();try{localStorage.setItem(SAVE_KEY,JSON.stringify(state));$("saveStatus").textContent="✓ Spielstand gespeichert."}catch{$("saveStatus").textContent="Speichern im Browser nicht verfügbar."}lastSave=Date.now()}
function fmt(n){return Math.floor(Math.max(0,n)).toLocaleString("de-DE")}
function clickPower(){return 1+state.levels.click}
function income(){return UPGRADES.filter(u=>u.type==="sec").reduce((n,u)=>n+state.levels[u.id]*u.rate,0)}
function cost(u){return Math.floor(u.base*Math.pow(1.17,state.levels[u.id]))}
function toast(msg){const t=$("toast");t.textContent=msg;t.classList.add("show");clearTimeout(toast.timer);toast.timer=setTimeout(()=>t.classList.remove("show"),1800)}
function audio(){if(!audioCtx){const AC=window.AudioContext||window.webkitAudioContext;if(AC)audioCtx=new AC()}if(audioCtx?.state==="suspended")audioCtx.resume();return audioCtx}
function tone(freq=440,duration=.09,type="sine",volume=.06){if(!state.sound)return;const c=audio();if(!c)return;const o=c.createOscillator(),g=c.createGain();o.type=type;o.frequency.value=freq;o.connect(g);g.connect(c.destination);g.gain.setValueAtTime(volume,c.currentTime);g.gain.exponentialRampToValueAtTime(.001,c.currentTime+duration);o.start();o.stop(c.currentTime+duration)}
function clickSound(){tone(420,.07,"triangle",.07);setTimeout(()=>tone(620,.06,"sine",.035),35)}
function startMusic(){if(!state.music||musicTimer)return;audio();const notes=[262,330,392,330,294,370,440,370,262,330,392,494,440,392,330,294];musicTimer=setInterval(()=>{if(!state.music||!audioCtx)return;const n=notes[musicStep++%notes.length];const o=audioCtx.createOscillator(),g=audioCtx.createGain();o.type="sine";o.frequency.value=n;o.connect(g);g.connect(audioCtx.destination);g.gain.setValueAtTime(.018,audioCtx.currentTime);g.gain.exponentialRampToValueAtTime(.001,audioCtx.currentTime+.28);o.start();o.stop(audioCtx.currentTime+.3)},330)}
function stopMusic(){if(musicTimer){clearInterval(musicTimer);musicTimer=null}}
function skin(){return SKINS.find(s=>s.id===state.equipped)||SKINS[0]}
function applySkin(){const s=skin();["gameMascot","homeMascot"].forEach(id=>{$(id).className="mascot skin-"+s.css});}
function update(){ $("coins").textContent=fmt(state.coins);$("perClick").textContent=fmt(clickPower());$("perSecond").textContent=fmt(income());applySkin();renderUpgrades();renderShop();renderInventory();$("musicToggle").checked=state.music;$("soundToggle").checked=state.sound}
function renderUpgrades(){$("upgradeList").innerHTML=UPGRADES.map(u=>{const c=cost(u),lv=state.levels[u.id];return `<div class="upgrade"><div class="upgrade-head"><span class="upgrade-icon">${u.icon}</span><strong>${u.name} · Lv. ${lv}</strong></div><small>${u.desc}</small><button data-upgrade="${u.id}" ${state.coins<c?"disabled":""}>Kaufen · ${fmt(c)} DC</button></div>`}).join("")}
function renderShop(){$("shopGrid").innerHTML=SKINS.filter(s=>s.id!=="classic").map(s=>{const own=state.owned.includes(s.id);return `<div class="skin-card"><div class="skin-preview ${s.css}"></div><strong>${s.name}</strong><small>Nur ein neues Aussehen</small><button data-buy-skin="${s.id}" ${own||state.coins<s.price?"disabled":""}>${own?"Gekauft":`Kaufen · ${fmt(s.price)} DC`}</button></div>`}).join("")}
function renderInventory(){$("inventoryGrid").innerHTML=state.owned.map(id=>{const s=SKINS.find(x=>x.id===id);if(!s)return "";const active=state.equipped===id;return `<div class="skin-card"><div class="skin-preview ${s.css}"></div><strong>${s.name}</strong><button data-equip="${id}" ${active?"disabled":""}>${active?"Ausgerüstet":"Ausrüsten"}</button></div>`}).join("")}
function showScreen(name){document.querySelectorAll(".screen").forEach(x=>x.classList.add("hidden"));$(name+"Screen").classList.remove("hidden");if(name==="game")update();if(name==="settings"){$("musicToggle").checked=state.music;$("soundToggle").checked=state.sound}}
function doClick(){state.coins+=clickPower();$("clickGain").textContent="+"+fmt(clickPower())+" DC";clickSound();save();update()}
document.addEventListener("click",e=>{
 const nav=e.target.closest("[data-screen]");if(nav){audio();showScreen(nav.dataset.screen);if(state.music)startMusic()}
 const buy=e.target.closest("[data-upgrade]");if(buy){const u=UPGRADES.find(x=>x.id===buy.dataset.upgrade),c=cost(u);if(state.coins>=c){state.coins-=c;state.levels[u.id]++;tone(660,.12,"triangle");save();update();toast(u.name+" verbessert!")}}
 const sb=e.target.closest("[data-buy-skin]");if(sb){const s=SKINS.find(x=>x.id===sb.dataset.buySkin);if(state.coins>=s.price&&!state.owned.includes(s.id)){state.coins-=s.price;state.owned.push(s.id);tone(780,.15,"sine");save();update();toast(s.name+" gekauft!")}}
 const eq=e.target.closest("[data-equip]");if(eq){state.equipped=eq.dataset.equip;tone(520,.1);save();update();toast("Skin ausgerüstet!")}
});
$("doenerButton").addEventListener("click",doClick);
$("settingsBtn").onclick=()=>{audio();showScreen("settings")};
$("musicToggle").onchange=e=>{state.music=e.target.checked;save();if(state.music){audio();startMusic()}else stopMusic();toast(state.music?"Musik eingeschaltet":"Musik ausgeschaltet")};
$("soundToggle").onchange=e=>{state.sound=e.target.checked;save();toast(state.sound?"Sounds eingeschaltet":"Sounds ausgeschaltet")};
$("saveNowBtn").onclick=()=>{save();toast("Spielstand gespeichert!")};
$("resetBtn").onclick=()=>{if(confirm("Wirklich alle Döner Coins, Upgrades und Skins zurücksetzen?")){state=fresh();stopMusic();save();update();showScreen("home");toast("Spielstand zurückgesetzt")}};
$("offlineClose").onclick=()=>$("offlineModal").classList.add("hidden");
function offlineReward(){const now=Date.now(),elapsed=Math.max(0,Math.min(now-(state.last||now),7*24*60*60*1000)),earned=income()*elapsed/1000;if(earned>=1){state.coins+=earned;$("offlineText").textContent=`Während du weg warst, hast du ${fmt(earned)} DC verdient!`; $("offlineModal").classList.remove("hidden")}}
offlineReward();update();save();
setInterval(()=>{const n=income();if(n>0){state.coins+=n;update()}if(Date.now()-lastSave>5000)save()},1000);
document.addEventListener("visibilitychange",()=>{if(document.hidden)save()});window.addEventListener("pagehide",save);
document.addEventListener("pointerdown",()=>{if(state.music){audio();startMusic()}},{once:true});
try{if(screen.orientation?.lock)screen.orientation.lock("landscape").catch(()=>{})}catch{}
if("serviceWorker" in navigator && location.protocol.startsWith("http"))window.addEventListener("load",()=>navigator.serviceWorker.register("./service-worker.js").catch(()=>{}));
