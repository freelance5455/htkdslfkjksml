const $ = (id) => document.getElementById(id);
const API_URL = "https://api.mymemory.translated.net/get";
let lastResult = "";
let history = JSON.parse(localStorage.getItem("tt_history") || "[]");
let sourceIsEnglish = true;

function toast(message) {
  const el = $("toast"); el.textContent = message; el.classList.add("show");
  clearTimeout(toast.timer); toast.timer = setTimeout(() => el.classList.remove("show"), 2400);
}
function updateConnection() {
  const online = navigator.onLine;
  const el = $("connection");
  el.className = "status " + (online ? "online" : "offline");
  el.innerHTML = `<i></i>${online ? "Internet bar" : "Internet ýok"}`;
}
window.addEventListener("online", updateConnection);
window.addEventListener("offline", updateConnection);
updateConnection();

function offlineTranslate(text) {
  const normalized = text.toLowerCase().trim().replace(/[.!?]+$/,"");
  if (PHRASES[normalized]) return PHRASES[normalized];
  const tokens = text.match(/[A-Za-z]+(?:['’][A-Za-z]+)?|[0-9]+|[^A-Za-z0-9\s]+|\s+/g) || [];
  let unknown = 0;
  const translated = tokens.map(token => {
    if (!/^[A-Za-z]/.test(token)) return token;
    const key = token.toLowerCase();
    if (Object.prototype.hasOwnProperty.call(DICTIONARY, key)) {
      const value = DICTIONARY[key];
      if (!value) return "";
      return token[0] === token[0].toUpperCase() ? value.charAt(0).toUpperCase()+value.slice(1) : value;
    }
    unknown++;
    return token;
  }).join("");
  return {text: translated, unknown};
}
async function onlineTranslate(text) {
  const url = new URL(API_URL);
  url.searchParams.set("q", text);
  url.searchParams.set("langpair", sourceIsEnglish ? "en|tk" : "tk|en");
  const response = await fetch(url.toString(), {method:"GET"});
  if (!response.ok) throw new Error("API jogap bermedi (" + response.status + ")");
  const data = await response.json();
  if (data.responseStatus !== 200 || !data.responseData?.translatedText) {
    throw new Error(data.responseDetails || "Terjime hyzmaty bu dil jübütini goldamaýar.");
  }
  const result = data.responseData.translatedText;
  if (/MYMEMORY WARNING|PLEASE CONTACT US/i.test(result)) throw new Error("Onlaýn terjime çäklendirmesi.");
  return result;
}
async function translate() {
  const text = $("sourceText").value.trim();
  if (!text) { toast("Ilki tekst giriziň."); return; }
  const mode = $("mode").value;
  const btn = $("translateBtn");
  btn.disabled = true; btn.querySelector("span").textContent = "Terjime edilýär...";
  $("resultText").textContent = "Garaşyň...";
  let result, usedMode;
  try {
    if (mode !== "offline" && navigator.onLine) {
      try {
        result = await onlineTranslate(text); usedMode = "Onlaýn";
      } catch (e) {
        if (mode === "online") throw e;
        const local = offlineTranslate(text); result = local.text; usedMode = "Oflaýn sözlük";
        $("resultMeta").textContent = "Onlaýn hyzmat elýeterli däl · " + local.unknown + " näbelli söz";
      }
    } else {
      if (mode === "online") throw new Error("Internet birikmesi ýok.");
      const local = offlineTranslate(text); result = local.text; usedMode = "Oflaýn sözlük";
      $("resultMeta").textContent = local.unknown + " näbelli söz";
    }
    lastResult = result;
    $("resultText").textContent = result;
    if (!$("resultMeta").textContent.includes("Onlaýn hyzmat")) $("resultMeta").textContent = usedMode;
    saveHistory(text, result, usedMode);
    toast(usedMode + " arkaly terjime edildi.");
  } catch (e) {
    $("resultText").textContent = "Terjime başartmady: " + e.message + "\n\nAwto režimi saýlap görüň ýa-da oflaýn sözlügi ulanyň.";
    $("resultMeta").textContent = "Ýalňyşlyk";
    toast("Onlaýn terjime elýeterli däl.");
  } finally {
    btn.disabled = false; btn.querySelector("span").textContent = "Terjime et";
  }
}
function saveHistory(input, output, mode) {
  history.unshift({input, output, mode, date:Date.now()});
  history = history.slice(0,12);
  localStorage.setItem("tt_history", JSON.stringify(history));
  renderHistory();
}
function renderHistory() {
  const box = $("historyList");
  if (!history.length) { box.innerHTML = '<div class="empty-state">Entek terjime ýok.</div>'; return; }
  box.replaceChildren();
  history.forEach(item => {
    const row = document.createElement("div"); row.className = "history-item";
    const left = document.createElement("strong"); left.textContent = item.input;
    const right = document.createElement("span"); right.textContent = item.output;
    row.append(left,right);
    row.addEventListener("click", () => { $("sourceText").value=item.input; $("resultText").textContent=item.output; lastResult=item.output; updateCount(); });
    box.append(row);
  });
}
function updateCount() { $("charCount").textContent = $("sourceText").value.length + " / 5000"; }
$("sourceText").addEventListener("input", updateCount);
$("translateBtn").addEventListener("click", translate);
$("clearBtn").addEventListener("click", () => { $("sourceText").value=""; $("resultText").textContent="Terjime şu ýerde görkeziler..."; $("resultMeta").textContent="Taýýar"; lastResult=""; updateCount(); });
$("copyBtn").addEventListener("click", async () => {
  const value = $("resultText").textContent;
  try { await navigator.clipboard.writeText(value); toast("Göçürildi!"); }
  catch { toast("Göçürmek üçin tekst saýlaň."); }
});
function speak(text, lang) {
  if (!("speechSynthesis" in window)) return toast("Bu brauzerde seslendirme ýok.");
  speechSynthesis.cancel(); const u = new SpeechSynthesisUtterance(text); u.lang=lang; speechSynthesis.speak(u);
}
$("speakSource").addEventListener("click", () => speak($("sourceText").value, sourceIsEnglish?"en-US":"tk-TM"));
$("speakResult").addEventListener("click", () => speak($("resultText").textContent, sourceIsEnglish?"tk-TM":"en-US"));
$("mode").addEventListener("change", () => { $("modeLabel").textContent = $("mode").selectedOptions[0].text; });
$("clearHistory").addEventListener("click", () => { history=[]; localStorage.removeItem("tt_history"); renderHistory(); toast("Taryh arassalandy."); });
$("themeBtn").addEventListener("click", () => document.body.classList.toggle("light"));
$("swapBtn").addEventListener("click", () => {
  sourceIsEnglish = !sourceIsEnglish;
  document.querySelector(".language-row .language-pill:first-child").innerHTML = sourceIsEnglish ? '<span class="flag">🇬🇧</span><span>English</span>' : '<span class="flag">🇹🇲</span><span>Türkmençe</span>';
  document.querySelector(".language-row .language-pill:last-of-type").innerHTML = sourceIsEnglish ? '<span class="flag">🇹🇲</span><span>Türkmençe</span>' : '<span class="flag">🇬🇧</span><span>English</span>';
  $("sourceText").placeholder = sourceIsEnglish ? "Write or paste text here..." : "Türkmençe tekst giriziň...";
  toast("Dil ugry üýtgedildi. Sözlük diňe English → Türkmen üçin.");
});
$("sourceText").addEventListener("keydown", e => { if ((e.ctrlKey||e.metaKey) && e.key==="Enter") translate(); });
renderHistory();
