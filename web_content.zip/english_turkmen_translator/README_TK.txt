ENGLISH → TÜRKMEN TRANSLATOR PRO
================================

Faýllar:
- index.html       Sahypanyň gurluşy
- style.css        Garaňky dizaýn
- app.js           Terjime logikasy, online/offline režimleri
- dictionary.js    Ýerli sözlük we belli söz düzümleri

IŞE GOÝBERMEK
1. Ähli faýllary bir papka çykaryň.
2. index.html faýlyny Chrome ýa-da Edge bilen açyň.
3. Tekst giriziň we "Terjime et" düwmesine basyň.
4. "Awto" režimi internet bar bolsa online hyzmaty synap görýär, şowsuz bolsa ýerli sözlüge geçýär.
5. "Diňe oflaýn" režimi diňe dictionary.js faýlyny ulanýar.

ONLINE TERJIME BARADA
- Häzirki nusga MyMemory web API ulanýar: https://api.mymemory.translated.net/get
- Bu daşarky hyzmatdyr; elýeterliligi, çäklendirmeleri we English→Turkmen dil jübütiniň goldawy hyzmatyň özüne bagly.
- Eger hyzmat bu dil jübütini goldamasa, online terjime ýalňyşlyk berer. "Awto" režiminde programma offline sözlüge geçer.
- API hyzmatynyň elýeterliligi kepillendirilmeýär. Geljekde goldaýan başga API bilen app.js içindäki onlineTranslate() funksiýasyny çalşyp bolýar.
- Frontend-only programmada gizlin API açaryny ygtybarly saklap bolmaýar. Şonuň üçin bu nusgada gizlin açar ýok.

OFFLINE TERJIME ÇÄKLENDIRMESI
Ýerli sözlük başlangyç nusgadyr. Ol diňe dictionary.js içindäki sözleri we belli söz düzümlerini terjime edýär. Sözlükde ýok sözler asyl görnüşinde galýar. Bu doly dil modeli däl we sözlem gurluşyny/grammatikany doly terjime etmeýär. Has ýokary hilli doly offline terjime üçin uly ýerli sözlük ýa-da ýörite dil modeli gerek.

Bellik:
Google Fonts ulanylyşy CSS-de bar. Internet ýok wagty programma şriftini ulgam şriftine geçirýär; esasy programma işlemegini dowam etdirýär.
