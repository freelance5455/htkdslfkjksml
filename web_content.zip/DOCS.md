# AI Creator Studio — CORE 1.0
## Documentação de Execução e Portabilidade

**Proprietário:** Sadraque Ngola  
**Versão:** CORE 1.0  
**Stack:** React 18 + TypeScript + Vite + Tailwind CSS

---

## Credenciais de Acesso Privado

```
Email:    sadraquengola83@gmail.com
Senha:    SadraqueNgola@2025
```

---

## Executar Localmente

### Pré-requisitos
- Node.js ≥ 18
- npm ou bun

### Instalação
```bash
npm install
# ou
bun install
```

### Desenvolvimento
```bash
npm run dev
# ou
bun dev
```

### Build de Produção
```bash
npm run build
# ou
bun run build
```

---

## Portabilidade

### Replit
1. Importe o repositório GitHub
2. O Replit detecta automaticamente o Vite
3. Configure o run command: `npm run dev`
4. Expose porta 5173

### GitHub Pages / Netlify / Vercel
```bash
npm run build
# Pasta de saída: dist/
```

### Google Cloud Run / Docker
```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json .
RUN npm install
COPY . .
RUN npm run build
RUN npm install -g serve
CMD ["serve", "-s", "dist", "-l", "3000"]
```

---

## Arquitetura CORE 1.0

```
src/
├── types/index.ts          — Todos os tipos TypeScript
├── constants/index.ts      — Constantes da aplicação
├── lib/
│   ├── auth.ts             — Autenticação privada
│   ├── storage.ts          — Persistência localStorage
│   ├── analyzer.ts         — Request Analyzer (NLP)
│   ├── orchestrator.ts     — AI Orchestrator (simulado)
│   └── utils.ts            — Utilitários
├── hooks/
│   ├── useAuth.ts          — Hook de autenticação
│   ├── useProjects.ts      — Hook de projetos
│   ├── useIdeas.ts         — Hook de ideias
│   └── useCalendar.ts      — Hook de calendário
├── components/
│   ├── layout/             — Sidebar, Header, AppLayout
│   └── features/           — Componentes de funcionalidade
└── pages/                  — Páginas da aplicação
```

---

## Workflow de Produção (CORE 1.0)

```
IDEIA → BRIEFING → ROTEIRO → STORYBOARD → PLANO DE MÍDIA
→ GERAÇÃO → EDIÇÃO → REVISÃO → RENDER → CONCLUÍDO
```

---

## Módulos Implementados (CORE 1.0)

- ✅ Foundation (Auth, Router, Layout, Dashboard)
- ✅ AI Core (Request Analyzer, Orchestrator simulado)
- ✅ Content Brief Generator
- ✅ Script Writer (editor por seções)
- ✅ Storyboard Director (cenas com prompts)
- ✅ Media Planner
- ✅ Task Engine (estados e progresso)
- ✅ Project Chat (AI contextual por projeto)
- ✅ Timeline Editor (visual com tracks)
- ✅ Creator Memory
- ✅ Ideas Lab
- ✅ Content Calendar
- ✅ Brand Kit
- ✅ Media Library
- ✅ Channel Manager

---

## Próximos Módulos

### CORE 1.1 — Providers de IA Reais
- Gemini API (texto, análise, roteiros)
- Imagen / Veo (imagens e vídeos)
- ElevenLabs (voz e narração)
- Suno / Udio (música)
- Backend OnSpace Cloud (banco de dados, storage)

### CORE 2.0 — Publicação nas Redes Sociais
- YouTube Data API
- Instagram Graph API
- TikTok API
- Facebook Graph API
- Scheduler automático

### CORE 3.0 — AI Autopilot
- Geração e publicação automática
- Análise de performance
- Otimização por dados

---

## Variáveis de Ambiente (CORE 1.1+)

```env
VITE_GEMINI_API_KEY=
VITE_ELEVENLABS_API_KEY=
VITE_SUNO_API_KEY=
VITE_SUPABASE_URL=
VITE_SUPABASE_ANON_KEY=
```
