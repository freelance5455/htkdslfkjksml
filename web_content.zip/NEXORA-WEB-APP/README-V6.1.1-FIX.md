SN FF TOUR V6.1.1 BUILD FIX

Fixed the Wallet JSX parser error that caused:
Expected "}" but found "value"

Also restored the expected NEXORA-WEB-APP directory wrapper in the ZIP, so the standard Termux `cd NEXORA-WEB-APP` command works.

No UI redesign was intentionally made in this fix.
