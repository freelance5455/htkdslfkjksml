import { execFileSync } from 'node:child_process';
import { writeFileSync } from 'node:fs';

function run(args) {
  try {
    return execFileSync('firebase', args, { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] });
  } catch (error) {
    const out = [error?.stdout, error?.stderr, error?.message].filter(Boolean).join('\n');
    throw new Error(out || 'Firebase CLI command failed.');
  }
}
function parseJson(text) {
  const first = text.indexOf('{');
  const last = text.lastIndexOf('}');
  if (first < 0 || last < first) throw new Error(`Could not parse Firebase CLI JSON output.\n${text}`);
  return JSON.parse(text.slice(first, last + 1));
}
const apps = parseJson(run(['apps:list', '--json']));
const list = apps.result?.apps ?? apps.apps ?? apps.result ?? [];
const web = Array.isArray(list) ? list.find((a) => String(a.platform || '').toUpperCase() === 'WEB') : null;
if (!web?.appId) throw new Error('No Firebase Web App found in sn-hub-d29e2. Create/register a Web App in Firebase Console first.');
const sdk = parseJson(run(['apps:sdkconfig', 'WEB', web.appId]));
const config = sdk.result?.config ?? sdk.config ?? sdk;
const required = ['apiKey','authDomain','projectId','messagingSenderId','appId'];
const missing = required.filter((key) => !config?.[key]);
if (missing.length) throw new Error(`Firebase SDK config is incomplete: ${missing.join(', ')}`);
writeFileSync('.env.local', [
  `VITE_FIREBASE_API_KEY=${config.apiKey}`,
  `VITE_FIREBASE_AUTH_DOMAIN=${config.authDomain}`,
  `VITE_FIREBASE_PROJECT_ID=${config.projectId}`,
  `VITE_FIREBASE_STORAGE_BUCKET=${config.storageBucket ?? ''}`,
  `VITE_FIREBASE_MESSAGING_SENDER_ID=${config.messagingSenderId}`,
  `VITE_FIREBASE_APP_ID=${config.appId}`, ''
].join('\n'));
console.log(`Firebase Web App config loaded: ${web.appId}`);
