# V6 targeted fixes

- Match Rules and Joined Players moved inside the Join Match popup; removed from the outer match card.
- Join Match button is always visible and opens the match popup; closed matches show Registration Time Ended.
- Join popup shows category prize breakdown, entry fee, player-count selector, rules, and joined players.
- Withdraw now includes Personal/Agent Type and stores it with the withdraw request for admin.
- Empty match lists show No Match Found instead of a blank area.
- All joined-player rows are readable to signed-in users for the match details popup.
