SN FF TOUR V4

Changes:
- Replaced legacy screenshot-style default match artwork with clean 2:1 tournament banners using the supplied SN FF TOUR logo.
- Admin transactions are shown oldest-to-newest with request date/time.
- Added Admin Add / Cut Balance control for Main Balance or Winning Balance.
- Added admin-only balance adjustment audit records in balanceAdjustments.
- Kept hidden admin access via 12 fast profile taps + PIN 0592; no visible Admin Panel menu.
- Profile bio remains removed.
- Existing tournament/payment/withdraw/banner/ban systems otherwise preserved.

Deployment: use the project's existing Firebase Hosting target; do not recreate sn-nexora-ff if it already exists.
