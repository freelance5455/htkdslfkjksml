export type UserRole='user'|'admin';
export interface User { id:string; email:string; username:string; phone:string; displayName:string; avatarUrl:string; role:UserRole; banned?:boolean; balance:number; matchesPlayed:number; matchesWon:number; createdAt:number; }
export interface PrizePool { first:number; second:number; third:number; perKill:number; }
export interface Tournament { id:string; matchNumber:number; title:string; banner:string; badge:string; description:string; matchType:'BR'|'CS'; mode:'Solo'|'Duo'|'Squad'; map:string; device:string; startAt:number; registrationOpen:boolean; maxSlots:number; joinedCount:number; winPrize:number; perKill:number; entryFee:number; rules:string; roomId:string; roomPassword:string; roomPublished:boolean; status:'upcoming'|'live'|'completed'|'cancelled'; createdAt:number; }
export interface JoinPlayer { name:string; slot:number; }
export interface Join { id:string; tournamentId:string; userId:string; gameName:string; playerCount:number; players:JoinPlayer[]; slot:number; status:'joined'|'checked-in'|'rejected'|'completed'|'refunded'; amountPaid:number; createdAt:number; refundedAt?:number; }
export type TxType='deposit'|'withdraw'|'refund'; export type TxStatus='pending'|'approved'|'rejected'|'completed';
export interface Transaction { id:string; userId:string; type:TxType; amount:number; method:string; accountNumber?:string; withdrawType?:'personal'|'agent'; transactionId?:string; status:TxStatus; note?:string; createdAt:number; }
export interface BannerItem { id:string; image:string; title:string; link:string; }
export interface AppSettings { appName:string; appIcon:string; supportLink:string; minDeposit:number; minWithdraw:number; notice:string; bkashNumber:string; nagadNumber:string; banners:BannerItem[]; prizePools:Record<string,PrizePool>; rulesByCategory:Record<string,string>; }
export interface Result { id:string; tournamentId:string; userId:string; gameName:string; placement:number; kills:number; points:number; prize:number; note:string; createdAt:number; }
