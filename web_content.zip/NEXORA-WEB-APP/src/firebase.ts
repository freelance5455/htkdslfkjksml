import { initializeApp, getApps } from 'firebase/app';
import { getAuth, setPersistence, browserLocalPersistence } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || '',
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || '',
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || 'sn-hub-d29e2',
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || '',
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || '',
  appId: import.meta.env.VITE_FIREBASE_APP_ID || '',
};

const missing = ['apiKey', 'authDomain', 'projectId', 'messagingSenderId', 'appId']
  .filter((key) => !firebaseConfig[key as keyof typeof firebaseConfig]);

if (missing.length) {
  throw new Error(`Firebase configuration missing: ${missing.join(', ')}. Run npm run setup:firebase before build.`);
}

const app = getApps()[0] || initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
void setPersistence(auth, browserLocalPersistence).catch(() => {});
export default app;
