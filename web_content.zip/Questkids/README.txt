Questkids
=========
A simple offline mobile HTML game.

Includes the Questkids game and icon.
No notifications, accounts, chat, location, or purchases.

Open www/index.html in an HTML-to-APK/WebView builder and set the app name to Questkids.
