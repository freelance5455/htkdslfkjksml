"use strict";(function(w,d){var N={worker:"کارگر",contractor:"پیمانکار",owner:"کارفرما"},I={worker:"👷",contractor:"🧱",owner:"🏢"},cur=w.YSP_APP,first=!N[cur];
function set(r){try{localStorage.setItem("ysp_active_role",r)}catch(e){}location.replace(location.pathname)}
function sheet(force){if(d.getElementById("ysp-roles"))return;var o=d.createElement("div");o.id="ysp-roles";o.dir="rtl";
o.style.cssText="position:fixed;inset:0;z-index:2147483000;background:rgba(0,0,0,.94);display:flex;align-items:center;justify-content:center;padding:18px;font-family:inherit";
var h="<div style=\"width:100%;max-width:380px;background:#14110a;border:1px solid #e6c265;border-radius:18px;padding:20px;color:#fff;text-align:center\"><div style=\"font-size:20px;color:#e6c265;font-weight:700;margin-bottom:6px\">نقش خود را انتخاب کنید</div><div style=\"font-size:12px;opacity:.75;margin-bottom:14px;line-height:1.8\">اطلاعات هر نقش جدا و امن نگه داشته می‌شود؛ با تغییر نقش، چیزی پاک نمی‌شود.</div>";
for(var k in N)h+="<button data-r=\""+k+"\" style=\"display:block;width:100%;margin:8px 0;padding:14px;border-radius:12px;border:1px solid #e6c265;background:"+(k===cur?"#e6c265":"#000")+";color:"+(k===cur?"#000":"#e6c265")+";font-size:17px;font-weight:700\">"+I[k]+" "+N[k]+(k===cur?" (فعلی)":"")+"</button>";
if(!force)h+="<button data-x=\"1\" style=\"margin-top:8px;padding:10px 18px;background:none;border:0;color:#aaa;font-size:14px\">انصراف</button>";
o.innerHTML=h+"</div>";o.addEventListener("click",function(e){var t=e.target.closest("button");if(!t)return;if(t.dataset.x)o.remove();else if(t.dataset.r)t.dataset.r===cur?o.remove():set(t.dataset.r)});d.body.appendChild(o)}
function btn(){var b=d.createElement("button");b.id="ysp-role-btn";b.textContent="🔄 "+N[cur];
b.style.cssText="position:fixed;top:calc(env(safe-area-inset-top,0px) + 6px);left:8px;z-index:9990;padding:6px 12px;border-radius:999px;border:1px solid #e6c265;background:rgba(0,0,0,.82);color:#e6c265;font-size:13px;font-weight:700";
b.onclick=function(){sheet(false)};d.body.appendChild(b)}
w.YSPRoles={open:function(){sheet(false)},set:set,current:function(){return first?"":cur}};
function go(){first?sheet(true):btn()}d.readyState==="loading"?d.addEventListener("DOMContentLoaded",go):go()})(window,document);
