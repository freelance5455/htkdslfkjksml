# مهامي اليومية — مشروع Capacitor لبناء APK

## المطلوب على جهازك
- Node.js (نسخة LTS)
- Android Studio

## الخطوات
```
npm install
npx cap add android
npx cap sync
```

بعد كده افتح الملف: android/app/src/main/AndroidManifest.xml
وضيف السطور دي جوه وسم <manifest> (قبل <application>):
```
<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
<uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM"/>
<uses-permission android:name="android.permission.USE_EXACT_ALARM"/>
<uses-permission android:name="android.permission.VIBRATE"/>
```

ثم:
```
npx cap open android
```
ومن Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s)
هتلاقي الملف في: android/app/build/outputs/apk/debug/app-debug.apk

## ملاحظات
- كود التطبيق كله في www/index.html.
- عند إضافة مهمة بمنبه، التطبيق بيجدول إشعار حقيقي في أندرويد، فيرنّ والتطبيق مقفول.
- أول مرة هيطلب إذن الإشعارات، وافق عليه.
- لو الإشعارات اتأخرت: من إعدادات الهاتف شغّل "المنبهات والتذكيرات" للتطبيق، واستثنيه من توفير البطارية.
- الإشعارات هتتجدول فقط للمهام اللي بتتضاف أو تتعدّل بعد التثبيت.
- المشروع ماتجرّبش على جهاز فعلي.
