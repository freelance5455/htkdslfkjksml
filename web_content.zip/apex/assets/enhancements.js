(function(){
window.APEX_INDIAN_SCALE=20;
var KEY="apex-enhanced-save",S={car:"amg",quality:"HIGH",sensitivity:1,deadzone:0.04,assist:0.35,wheelSize:120,lighting:"DAY"};
try{Object.assign(S,JSON.parse(localStorage.getItem(KEY)||"{}"))}catch(e){}
function save(){try{localStorage.setItem(KEY,JSON.stringify(S))}catch(e){}}
var CARS=[
 {id:"amg",name:"Mercedes-AMG GT3",sub:"Mercedes-AMG GT3 · Red Bull Racing",url:"/__l5e/assets-v1/1912a8c8-de3b-4815-9b98-bde6d12a0c52/car.glb",stats:[["Top speed","310 km/h"],["0–100","3.4 s"],["Gearbox","6-speed auto"],["Drive","RWD"]]},
 {id:"porsche",name:"2024 Porsche 992 GT3 R",sub:"Porsche 992 GT3 R · Endurance Spec",url:"/__l5e/assets-v1/7aadd0bb-9644-456f-a19d-f0966267ab1b/porsche.glb",stats:[["Top speed","296 km/h"],["0–100","3.2 s"],["Gearbox","6-speed seq."],["Drive","RWD"]]},
 {id:"aventador",name:"Lamborghini Aventador",sub:"Lamborghini Aventador · V12",url:"/__l5e/assets-v1/7527d61e-9a21-4de3-8e12-acc3ee9a694a/aventador-mobile.glb",stats:[["Engine","V12"],["Transmission","7-speed"],["Body","Supplied Aventador"],["Drive","AWD"]]},
 {id:"bmw",name:"BMW E38 Cyberbody",sub:"BMW E38 · Cyberbody",url:"/__l5e/assets-v1/48fb1143-3f50-4375-8e35-d496bf40e313/bmw-e38-mobile.glb",stats:[["Body","Supplied Cyberbody"],["Transmission","Automatic"],["Class","Sports saloon"],["Drive","RWD"]]}];
var Q={LOW:{dpr:[0.75,1],shadow:512,aa:false},MEDIUM:{dpr:[1,1.25],shadow:1024,aa:true},HIGH:{dpr:[1,1.5],shadow:1024,aa:true},ULTRA:{dpr:[1,2],shadow:2048,aa:true}};
if(!Q[S.quality])S.quality="HIGH";
if(!CARS.some(function(c){return c.id===S.car}))S.car="amg";
window.apexCar=function(){return CARS.find(function(c){return c.id===S.car})||CARS[0]};
window.apexQ=function(){return Q[S.quality]};
window.apexSettings=function(){return S};
window.apexSetSetting=function(k,value){S[k]=value;save();window.dispatchEvent(new Event("apex-settings"))};
var REF_LEN=null;
window.apexFitCar=function(obj,THREE_Box,isRef){
 // measure footprint; scale non-reference cars to the reference car length
 var b=new THREE_Box().setFromObject(obj),sx=b.max.x-b.min.x,sz=b.max.z-b.min.z,L=Math.max(sx,sz);
 if(isRef){REF_LEN=L;return obj}
 var target=REF_LEN||4.6,s=target/L;obj.scale.multiplyScalar(s);obj.updateMatrixWorld(true);
 b.setFromObject(obj);
 if(sz>sx)obj.rotation.y+=Math.PI/2;
 obj.updateMatrixWorld(true);b.setFromObject(obj);
 obj.position.x-=(b.max.x+b.min.x)/2;obj.position.z-=(b.max.z+b.min.z)/2;obj.position.y-=b.min.y;
 return obj};
var comp=null;
window.ApexGarage=function(W,v,Button){if(comp)return comp;comp=function(){
  var st=v.useState(0),bump=function(){save();st[1](st[0]+1);window.dispatchEvent(new Event("apex-settings"))},car=window.apexCar(),j=W.jsx,js=W.jsxs;
 return js(W.Fragment,{children:[
   j(window.ApexUpgrade.components.CarPreview,{car:car}),
   j("div",{className:"car-choices car-selector",children:CARS.map(function(c,index){return js(Button,{type:"button",className:"apex-choice car-option"+(c.id===S.car?" active":""),"aria-label":c.name,"aria-pressed":c.id===S.car,onClick:function(){S.car=c.id;bump()},children:[j("span",{className:"car-option-number",children:"0"+(index+1)}),j("span",{children:c.name})]},c.id)})}),
  j("div",{className:"card-title",children:car.name}),
  js("div",{children:car.stats.map(function(r){return js("div",{className:"stat-row",children:[j("span",{children:r[0]}),j("b",{children:r[1]})]},r[0])})}),
  j("div",{className:"card-label",style:{marginTop:12},children:"Graphics quality"}),
  j("div",{className:"car-choices",children:Object.keys(Q).map(function(k){return j(Button,{type:"button",className:"apex-choice"+(k===S.quality?" active":""),"aria-pressed":k===S.quality,onClick:function(){S.quality=k;bump()},children:k},k)})})
 ]})};return comp};
})();
