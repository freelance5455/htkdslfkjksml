(function () {
  "use strict";
  var engine, api, telemetry = { damage: 0, mode: "chase", airborne: false, boost: false }, particles = [], cursor = 0;
  var colors = { trim: "#14171b", leather: "#24282d", metal: "#9ba6ac", instrument: "#66e4da", flame: "#58aaff", spark: "#ffd575", dust: "#a6a08d" };
  for (var i = 0; i < 96; i++) particles.push({ life: 0, x: 0, y: 0, z: 0, vx: 0, vy: 0, vz: 0, kind: 0 });
  function burst(pos, count, kind) {
    for (var i = 0; i < count; i++) {
      var p = particles[cursor++ % particles.length];
      Object.assign(p, { life: kind ? 0.8 : 0.45, x: pos.x, y: pos.y + 0.3, z: pos.z, vx: (Math.random() - 0.5) * 8, vy: Math.random() * (kind ? 3 : 7), vz: (Math.random() - 0.5) * 8, kind: kind });
    }
  }
  function sound(kind, strength) {
    var audio = api.audio, ctx = audio.ctx;
    if (!ctx || audio.muted || ctx.state !== "running") return;
    var source = ctx.createBufferSource(), buffer = ctx.createBuffer(1, ctx.sampleRate * 0.3, ctx.sampleRate), data = buffer.getChannelData(0);
    for (var i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
    source.buffer = buffer;
    var filter = ctx.createBiquadFilter(), gain = ctx.createGain();
    filter.type = "lowpass"; filter.frequency.value = kind === "nitro" ? 2400 : 700;
    gain.gain.setValueAtTime(Math.min(0.22, strength * 0.02), ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.28);
    source.connect(filter).connect(gain).connect(ctx.destination); source.start(); source.stop(ctx.currentTime + 0.3);
    source.onended = function () { source.disconnect(); filter.disconnect(); gain.disconnect(); };
  }
  window.ApexUpgrade = {
    install: function (runtime) { api = runtime; engine = this.createComponents(runtime); this.components = engine; return engine; },
    reset: function (s) { s.damage = 0; s.shake = 0; s.suspension = 0; s.hitCooldown = 0; s.airborne = false; s.wasGrounded = false; s.groundHeight = undefined; s.wasBoost = false; telemetry.damage = 0; particles.forEach(function (p) { p.life = 0; }); },
    prepare: function (visual) {
      var groups = {}, steering = [];
      visual.traverse(function (mesh) {
        if (!mesh.isMesh) return;
        var match = mesh.name.match(/^(front|rear)_(left|right)_/);
        if (match && !/calliper|caliper|paint/i.test(mesh.name)) {
          var key = match[1] + "_" + match[2]; (groups[key] ||= []).push(mesh);
        }
        var materials = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
        if (materials.some(function (m) { return /steering.?wheel/i.test(m?.name || ""); })) steering.push(mesh);
      });
      Object.keys(groups).forEach(function (key) {
        var parts = groups[key], parent = parts[0].parent;
        if (!parent || parent.userData.apexWheelPivot) return;
        var pivot = new api.Group(), box = new api.Box();
        parts.forEach(function (part) { box.union(new api.Box().setFromObject(part)); });
        var center = box.getCenter(parts[0].position.clone()); parent.worldToLocal(center); pivot.position.copy(center); pivot.name = key + "_pivot"; pivot.userData.apexWheelPivot = true; parent.add(pivot); parent.updateMatrixWorld(true);
        parts.forEach(function (part) { pivot.attach(part); });
      });
      steering.forEach(function (part) {
        var parent = part.parent; if (!parent || parent.userData.apexSteeringPivot) return;
        var pivot = new api.Group(), center = new api.Box().setFromObject(part).getCenter(part.position.clone());
        parent.worldToLocal(center); pivot.position.copy(center); pivot.userData.apexSteeringPivot = true; pivot.userData.apexSteeringBase = 0; parent.add(pivot); parent.updateMatrixWorld(true); pivot.attach(part);
      });
    },
    steering: function (raw, speed) {
      var settings = apexSettings(), dz = settings.deadzone;
      var value = Math.abs(raw) <= dz ? 0 : Math.sign(raw) * (Math.abs(raw) - dz) / (1 - dz);
      return Math.max(-1, Math.min(1, value * settings.sensitivity)) / (1 + Math.abs(speed) * settings.assist / 100);
    },
    impact: function (s, force, normal) {
      if (force < 2 || (s.hitCooldown || 0) > 0) return;
      s.hitCooldown = 0.18; s.damage = Math.min(1, (s.damage || 0) + Math.min(0.28, force * force / 3500));
      s.shake = Math.min(0.35, force / 65); s.suspension = Math.min(0.12, force / 200);
      burst(s.pos, 22, 0); sound("crash", force);
      if (s.visual) {
        s.visual.traverse(function (mesh) {
          if (!mesh.isMesh || /^front|^rear/.test(mesh.name) || !mesh.geometry?.attributes.position) return;
          if (!mesh.userData.apexOriginal) { mesh.geometry = mesh.geometry.clone(); mesh.userData.apexOriginal = mesh.geometry.attributes.position.array.slice(); }
          var a = mesh.geometry.attributes.position, original = mesh.userData.apexOriginal;
          for (var i = 0; i < a.count; i++) {
            var x = original[i * 3], y = original[i * 3 + 1], z = original[i * 3 + 2], edge = Math.max(0, Math.abs(x) - 1.3);
            a.setXYZ(i, x - Math.sign(x) * edge * s.damage * 0.15, y - edge * s.damage * 0.035, z + Math.sin(x * 11 + y * 9) * edge * s.damage * 0.025);
          }
          a.needsUpdate = true; mesh.geometry.computeVertexNormals();
        });
      }
    },
    ground: function (s, height, dt, speed) {
      if (height === null) { s.airborne = true; return; }
      var gap = s.pos.y - height;
      if (s.wasGrounded && gap > 0.38 && speed > 8 && s.pitch > 0.045) { s.vy = Math.max(s.vy, speed * Math.sin(s.pitch)); s.airborne = true; }
      if (s.airborne && gap <= 0.3 && s.vy <= 0) {
        var force = Math.abs(s.vy); s.suspension = Math.min(0.17, force * 0.015); s.shake = Math.min(0.25, force * 0.014);
        s.airborne = false; burst(s.pos, 18, 1); if (force > 3) sound("land", force);
        if (force > 14) this.impact(s, force * 0.5, null);
      }
      s.wasGrounded = gap <= 0.3;
    },
    terrain: function (s, hits, center, dt, speed) {
      var contact = hits.filter(Boolean), height = center?.point.y;
      if (contact.length >= 2) height = contact.reduce(function (sum, hit) { return sum + hit.point.y; }, 0) / contact.length;
      var previous = s.groundHeight;
      if (height === undefined) {
        if (s.wasGrounded) s.vy = Math.max(0, speed * Math.sin(s.pitch));
        s.airborne = true; s.wasGrounded = false;
      } else {
        var rise = previous === undefined ? 0 : height - previous;
        // Keep contact on an uphill; launch only after leaving the crest.
        if (s.wasGrounded && previous !== undefined && rise < -0.18 && speed > 8 && s.pitch > 0.04) {
          s.vy = Math.max(s.vy, speed * Math.sin(s.pitch)); s.airborne = true; s.wasGrounded = false;
        }
        if (!s.airborne && s.pos.y - height <= 0.5 && height - s.pos.y <= Math.max(0.48, speed * dt * 1.5)) {
          s.pos.y = height; s.vy = 0; s.wasGrounded = true;
        } else {
          s.vy -= 25 * dt;
          var next = s.pos.y + s.vy * dt;
          if (next <= height && s.vy <= 0 && height <= s.pos.y + 0.5) {
            var force = Math.abs(s.vy); s.pos.y = height; s.vy = 0; s.airborne = false; s.wasGrounded = true;
            s.suspension = Math.min(0.17, force * 0.015); s.shake = Math.min(0.25, force * 0.014);
            if (force > 3) { burst(s.pos, 18, 1); sound("land", force); }
          } else { s.pos.y = next; s.airborne = true; }
        }
        s.groundHeight = height;
      }
      if (height === undefined) { s.vy -= 25 * dt; s.pos.y += s.vy * dt; }
      var front = hits[0], rear = hits[1], left = hits[2], right = hits[3];
      if (front && rear && !s.airborne) s.pitch += (Math.max(-0.9, Math.min(0.9, Math.atan2(front.point.y - rear.point.y, 2.7))) - s.pitch) * (1 - Math.exp(-14 * dt));
      if (left && right && !s.airborne) s.roll += (Math.max(-0.55, Math.min(0.55, Math.atan2(left.point.y - right.point.y, 1.6))) - s.roll) * (1 - Math.exp(-12 * dt));
      if (s.airborne) s.pitch += (-0.12 - s.pitch) * (1 - Math.exp(-0.7 * dt));
    },
    step: function (s, hit, direction, meshes, distance, dt) {
      if (!hit || s.airborne) return false;
      var x = s.pos.x + direction.x * (hit.dist + 0.12), z = s.pos.z + direction.z * (hit.dist + 0.12);
      var top = api.groundRay(meshes, x, s.pos.y + 0.65, z, 1.15);
      if (!top) return false;
      var height = top.point.y - s.pos.y;
      // Only tyre-sized lips, never container sides or building walls.
      if (height <= 0.02 || height > 0.38) return false;
      s.pos.y += height; s.suspension = Math.min(0.1, height * 0.3); s.pos.addScaledVector(s.v, dt); return true;
    },
    tick: function (s, visual, dt, paused, mode) {
      s.visual = visual; s.hitCooldown = Math.max(0, (s.hitCooldown || 0) - dt);
      s.shake = (s.shake || 0) * Math.exp(-8 * dt); s.suspension = (s.suspension || 0) * Math.exp(-10 * dt);
      telemetry.damage = s.damage || 0; telemetry.airborne = !!s.airborne; telemetry.mode = mode;
      telemetry.boost = !paused && api.input.nitro > 0 && s.nitro > 0 && api.input.throttle > 0;
      if (telemetry.boost && !s.wasBoost) sound("nitro", 9);
      s.wasBoost = telemetry.boost;
      if (!visual) return;
      if (!paused) {
        s.wheelAngle = (s.wheelAngle || 0) + s.v.length() * dt / 0.34;
        visual.traverse(function (mesh) {
          if (mesh.userData.apexWheelPivot) {
            mesh.userData.apexBaseY ??= mesh.position.y;
            mesh.position.y = mesh.userData.apexBaseY - (s.airborne ? 0.08 : -s.suspension);
            mesh.rotation.z = -s.wheelAngle;
            if (/^front_/.test(mesh.name)) mesh.rotation.y = s.steer;
          }
        });
        visual.traverse(function (mesh) {
          if (mesh.userData.apexSteeringPivot) mesh.rotation.x = mesh.userData.apexSteeringBase - s.steer * 4;
        });
      }
      if (s.damage === 0) visual.traverse(function (mesh) {
        if (!mesh.userData.apexOriginal) return;
        mesh.geometry.attributes.position.array.set(mesh.userData.apexOriginal); mesh.geometry.attributes.position.needsUpdate = true; mesh.geometry.computeVertexNormals(); mesh.userData.apexOriginal = null;
      });
    },
    camera: function (camera, s, dt, mode, forward, side) {
      if (mode === "cockpit") {
        var eye = apexCar().eye || [0.34, 1.02, -0.42];
        camera.position.copy(s.pos).addScaledVector(forward, eye[2]).addScaledVector(side, -eye[0]); camera.position.y += eye[1] - (s.suspension || 0);
        var target = s.pos.clone().addScaledVector(forward, 35); target.y = camera.position.y + Math.sin(s.pitch) * 35; camera.lookAt(target);
        camera.near = 0.025;
      } else { camera.near = 0.1; }
      if (s.shake > 0.002) { camera.position.x += Math.sin(api.hud.time * 97) * s.shake; camera.position.y += Math.cos(api.hud.time * 113) * s.shake * 0.7; }
      if (mode === "cockpit") camera.rotation.z += s.roll * 0.15;
    },
    createComponents: function (a) {
      var R = a.React, j = a.JSX.jsx, js = a.JSX.jsxs, Fragment = a.JSX.Fragment;
      function mesh(geometry, args, position, color, extra) {
        return js("mesh", Object.assign({ position: position, children: [j(geometry, { args: args }), j("meshStandardMaterial", { color: color, roughness: 0.6, metalness: color === colors.metal ? 0.7 : 0.12 })] }, extra));
      }
      function Settings() {
        var state = R.useState(0), settings = apexSettings();
        function range(key, label, min, max, step) {
          return js("label", { className: "upgrade-setting", children: [js("span", { children: [label, j("output", { children: key === "wheelSize" ? settings[key] + " px" : Math.round(settings[key] * 100) + "%" })] }), j("input", { type: "range", min: min, max: max, step: step, value: settings[key], "aria-label": label, onChange: function (e) { apexSetSetting(key, Number(e.target.value)); state[1](state[0] + 1); } })] }, key);
        }
        return js("div", { className: "upgrade-settings", children: [range("sensitivity", "Sensitivity", 0.4, 1.8, 0.05), range("deadzone", "Dead zone", 0, 0.25, 0.01), range("assist", "Steering assist", 0, 1, 0.05), range("wheelSize", "Wheel size", 90, 150, 5), j("div", { className: "card-label", children: "Lighting" }), j("div", { className: "car-choices", children: ["DAY", "DUSK", "NIGHT"].map(function (mode) { return j(a.Button, { className: "apex-choice" + (settings.lighting === mode ? " active" : ""), "aria-pressed": settings.lighting === mode, onClick: function () { apexSetSetting("lighting", mode); state[1](state[0] + 1); }, children: mode }, mode); }) })] });
      }
      function Wheel() {
        var element = R.useRef(null), drag = R.useRef(null);
        function release() { drag.current = null; a.steer(0); element.current?.style.setProperty("--wheel-turn", "0deg"); }
        R.useEffect(function () { return release; }, []);
        function move(e) {
          if (!drag.current) return;
          var b = element.current.getBoundingClientRect(), angle = Math.atan2(e.clientX - b.x - b.width / 2, b.y + b.height / 2 - e.clientY);
          var delta = Math.atan2(Math.sin(angle - drag.current.angle), Math.cos(angle - drag.current.angle));
          drag.current.total = Math.max(-2.1, Math.min(2.1, drag.current.total + delta)); drag.current.angle = angle;
          a.steer(drag.current.total / 2.1); element.current.style.setProperty("--wheel-turn", drag.current.total + "rad");
        }
        return js(a.Button, { ref: element, variant: "game", size: "game", className: "steering-wheel", style: { width: apexSettings().wheelSize, height: apexSettings().wheelSize }, "aria-label": "Steering wheel", title: "Steering wheel", onPointerDown: function (e) { e.preventDefault(); var b = e.currentTarget.getBoundingClientRect(); drag.current = { total: 0, angle: Math.atan2(e.clientX - b.x - b.width / 2, b.y + b.height / 2 - e.clientY) }; e.currentTarget.setPointerCapture(e.pointerId); }, onPointerMove: move, onPointerUp: release, onPointerCancel: release, onLostPointerCapture: release, children: [j("span", { className: "wheel-spoke wheel-spoke-left" }), j("span", { className: "wheel-spoke wheel-spoke-right" }), j("span", { className: "wheel-spoke wheel-spoke-bottom" }), j("span", { className: "wheel-hub", children: "APEX" })] });
      }
      function Hud() {
        var state = R.useState(0);
        R.useEffect(function () { var timer = setInterval(function () { state[1](function (x) { return x + 1; }); }, 100); return function () { clearInterval(timer); }; }, []);
        return js(Fragment, { children: [js("div", { className: "vehicle-health", children: [j("span", { children: "CONDITION " + Math.round((1 - telemetry.damage) * 100) + "%" }), j("meter", { min: 0, max: 1, value: 1 - telemetry.damage, "aria-label": "Vehicle condition" }), j("span", { children: telemetry.mode.toUpperCase() + (telemetry.airborne ? " · AIR" : "") })] }), telemetry.boost && j("div", { className: "nitro-vision", "aria-hidden": true })] });
      }
      function Instruments() {
        var texture = R.useMemo(function () {
          var canvas = document.createElement("canvas"); canvas.width = 512; canvas.height = 192;
          var tex = new a.Texture(canvas); tex.colorSpace = "srgb"; return tex;
        }, []), elapsed = R.useRef(0);
        a.frame(function (_, dt) {
          elapsed.current += dt; if (elapsed.current < 0.1) return; elapsed.current = 0;
          var c = texture.image.getContext("2d"); if (!c) return;
          c.fillStyle = colors.trim; c.fillRect(0, 0, 512, 192);
          c.strokeStyle = colors.instrument; c.lineWidth = 3;
          [100, 410].forEach(function (x, idx) {
            c.beginPath(); c.arc(x, 100, 70, Math.PI * 0.75, Math.PI * 2.25); c.stroke();
            for (var k = 0; k < 10; k++) { var angle = Math.PI * 0.75 + k * Math.PI / 6; c.beginPath(); c.moveTo(x + Math.cos(angle) * 60, 100 + Math.sin(angle) * 60); c.lineTo(x + Math.cos(angle) * 67, 100 + Math.sin(angle) * 67); c.stroke(); }
            var value = idx ? a.hud.rpm / 8000 : a.hud.speedKmh / 320, angle = Math.PI * 0.75 + Math.min(1, value) * Math.PI * 1.5;
            c.strokeStyle = colors.spark; c.beginPath(); c.moveTo(x, 100); c.lineTo(x + Math.cos(angle) * 55, 100 + Math.sin(angle) * 55); c.stroke(); c.strokeStyle = colors.instrument;
          });
          c.fillStyle = colors.instrument; c.textAlign = "center"; c.font = "bold 48px sans-serif"; c.fillText(Math.round(a.hud.speedKmh), 255, 89); c.font = "18px sans-serif"; c.fillText("KM/H   " + a.hud.gear, 255, 123); c.fillText("APEX", 255, 159); texture.needsUpdate = true;
        });
        R.useEffect(function () { return function () { texture.dispose(); }; }, [texture]);
        return js("mesh", { position: [0.36, 0.9, 0.42], rotation: [-0.2, Math.PI, 0], children: [j("planeGeometry", { args: [0.65, 0.245] }), j("meshBasicMaterial", { map: texture, toneMapped: false })] });
      }
      function Cockpit(props) {
        // Interior geometry is part of the selected supplied model; never substitute a generic dashboard.
        return j("pointLight", { visible: props.mode === "cockpit", position: [0, 1, 0], color: colors.instrument, intensity: 0.35, distance: 2 });
      }
      function PreviewModel(props) {
        var source = a.load(props.car.url).scene;
        var model = R.useMemo(function () {
          var group = new a.Group(); group.add(source.clone(true)); apexFitCar(group, a.Box, false); return group;
        }, [source]), ref = R.useRef(null);
        a.frame(function (_, dt) { if (ref.current) ref.current.rotation.y += Math.min(dt, 0.05) * 0.2; });
        return j("group", { ref: ref, rotation: [0, -0.6, 0], children: j("primitive", { object: model }) });
      }
      function CarPreview(props) {
        return j("div", { className: "car-preview", "aria-label": props.car.name + " model", children: js(a.Canvas, { dpr: [0.75, 1], camera: { position: [5.8, 3.1, 5.8], fov: 36 }, children: [j("ambientLight", { intensity: 1.6 }), j("directionalLight", { position: [3, 6, 5], intensity: 3 }), j("directionalLight", { position: [-4, 2, -4], intensity: 2 }), j(R.Suspense, { fallback: null, children: j(PreviewModel, { car: props.car }, props.car.id) })] }) });
      }
      function Effects(props) {
        var pool = R.useRef(null), flame = R.useRef(null), dummy = R.useMemo(function () { return new a.Group(); }, []), tone = R.useMemo(function () { return new a.Color(); }, []);
        a.frame(function (_, raw) {
          var dt = props.paused ? 0 : Math.min(raw, 0.05), s = props.state.current;
          if (flame.current) {
            flame.current.position.copy(s.pos); flame.current.rotation.y = s.heading; flame.current.visible = telemetry.boost;
            flame.current.scale.set(1, 1, 0.8 + Math.sin(a.hud.time * 80) * 0.2);
          }
          if (!pool.current) return;
          particles.forEach(function (p, i) {
            p.life = Math.max(0, p.life - dt); p.vy -= dt * (p.kind ? 1 : 12); p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt;
            dummy.position.set(p.x, p.y, p.z); dummy.scale.setScalar(p.life * (p.kind ? 0.3 : 0.065)); dummy.updateMatrix();
            pool.current.setMatrixAt(i, dummy.matrix); tone.set(p.kind ? colors.dust : colors.spark); pool.current.setColorAt(i, tone);
          });
          pool.current.instanceMatrix.needsUpdate = true; if (pool.current.instanceColor) pool.current.instanceColor.needsUpdate = true;
        });
        return js(Fragment, { children: [js("instancedMesh", { ref: pool, args: [undefined, undefined, 96], frustumCulled: false, children: [j("sphereGeometry", { args: [1, 5, 4] }), j("meshBasicMaterial", { toneMapped: false })] }), js("group", { ref: flame, visible: false, children: [-0.45, 0.45].map(function (x) { return js("group", { position: [x, 0.38, -2.3], children: [js("mesh", { rotation: [-Math.PI / 2, 0, 0], children: [j("coneGeometry", { args: [0.16, 1.1, 12] }), j("meshBasicMaterial", { color: colors.flame, transparent: true, opacity: 0.75, toneMapped: false })] }), j("pointLight", { color: colors.flame, intensity: 3, distance: 3 })] }, x); }) })] });
      }
      return { Settings: Settings, Wheel: Wheel, Hud: Hud, Cockpit: Cockpit, Effects: Effects, CarPreview: CarPreview };
    }
  };
})();