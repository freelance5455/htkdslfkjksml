# APEX upgrade
- [x] Convert and optimize supplied Lamborghini, BMW, wheel pack and steering wheel.
- [ ] Fix ramp/terrain snagging while retaining wall collisions.
- [ ] Show selected car model in the car chooser and use its own interior.
- [ ] Present gameplay horizontally in portrait and landscape phone viewports.
- [ ] Integrate playable cars while retaining existing game.
- [ ] Add cockpit view and adjustable mobile steering.
- [ ] Add jump, suspension, Nitro, collision and progressive damage effects.
- [ ] Expand India-inspired environment and day/night lighting.
- [ ] Verify original flows and upgraded cars/effects on desktop and mobile.