# MyWeather Android-Projekt

Android-Studio-Projekt für eine Wetter-App mit aktuellen, stündlichen und 14-tägigen Prognosen über Open-Meteo.

## APK bauen
1. Projekt in Android Studio öffnen.
2. Gradle-Synchronisierung abwarten.
3. Menü **Build → Build APK(s)** wählen.
4. APK liegt danach unter `app/build/outputs/apk/debug/app-debug.apk`.

## Funktionen
- Standortfreigabe (optional), standardmäßig Grevenbroich
- Aktuelle Werte, 24-Stunden-Übersicht und 14-Tage-Prognose
- Temperaturfarben gemäß Vorgabe, Wetter-Emojis, Regenwahrscheinlichkeit und Wind in km/h
- Windhinweis über 30 km/h
- Umschaltbare Gewitter-, Glätte- und Windhinweise
- Link zum interaktiven Kachelmannwetter-Radar
- Temperaturdiagramm
- Datenquelle: Open-Meteo API (Internet nötig)

## Sicherheitshinweis
Die App leitet keine Tornadowarnung aus einer rotierenden Gewitterzelle ab. Eine solche automatische Erkennung wäre ohne verlässliche Radar-/Warnintegration unsicher. Aktuelle amtliche Warnungen bitte beim Deutschen Wetterdienst prüfen. Die Warnschalter in dieser Version zeigen lokale, prognosebasierte Hinweise und sind keine garantierten Push-Warnungen im Hintergrund.
