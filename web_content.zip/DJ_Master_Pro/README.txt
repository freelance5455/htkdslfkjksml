DJ MASTER PRO — HTML project for ApkForge

FILES
- index.html: the complete DJ mixer interface and Web Audio implementation.

FEATURES
- Two independent audio decks; choose audio files from your Android device.
- Play/pause, cue-to-cue-point, 5-second rewind, seek and tempo.
- Crossfader, deck gain and 3-band EQ.
- Per-deck filter control and loop in/out/loop toggle.
- Master echo, reverb and low-pass filter effect toggles.
- Responsive black-and-gold layout for mobile screens.

IMPORT INTO APKFORGE
1. Create a new HTML / WebView project in ApkForge.
2. Import index.html (or import this ZIP if the app supports ZIP project import).
3. Set the app name to DJ Master Pro.
4. Enable local file/media access and audio playback permissions if ApkForge exposes those settings.
5. Build/export the Android APK and test on a real device.

IMPORTANT NOTES
- This is a browser-based DJ mixer project. It uses the Web Audio API and HTML audio elements.
- Audio files are selected locally by the user; they are not bundled with the project.
- Audio playback starts after a user gesture, as required by Android browsers/WebView.
- For best results, use a recent Android System WebView and test with MP3, WAV or M4A files.
- The effects are functional starter effects. This is not a replacement for native low-latency professional DJ hardware/software; performance depends on the Android device and WebView.
