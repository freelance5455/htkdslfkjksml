/* Web Worker entry for the multi-file build. The single-file build (dist/) builds the same worker from a Blob. */
importScripts("gguf-core.js");
let __H = null;
onmessage = e => {
  const d = e.data;
  if (d && d.type === "port") {                 /* helper thread: gets a port to the main worker */
    const p = d.port, C = XireGGUF.makeComputeHandler((m, t) => p.postMessage(m, t || []));
    p.addEventListener("message", ev => C(ev.data));
    if (p.start) p.start();
    return;
  }
  if (!__H) __H = XireGGUF.makeHandler(m => postMessage(m));   /* main worker */
  __H(d);
};
