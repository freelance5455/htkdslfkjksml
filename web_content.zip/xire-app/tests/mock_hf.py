import http.server, json, socketserver, time, sys
class H(http.server.BaseHTTPRequestHandler):
    protocol_version="HTTP/1.1"
    def cors(self):
        self.send_header("Access-Control-Allow-Origin","*");self.send_header("Access-Control-Allow-Headers","authorization,content-type");self.send_header("Access-Control-Allow-Methods","POST,OPTIONS")
    def do_OPTIONS(self):
        self.send_response(204);self.cors();self.send_header("Content-Length","0");self.end_headers()
    def do_POST(self):
        n=int(self.headers.get("Content-Length","0"));req=json.loads(self.rfile.read(n))
        if self.headers.get("Authorization")!="Bearer test-token":
            b=json.dumps({"error":{"message":"Invalid token"}}).encode();self.send_response(401);self.cors();self.send_header("Content-Type","application/json");self.send_header("Content-Length",str(len(b)));self.end_headers();self.wfile.write(b);return
        if req.get("model")=="ratelimit":
            b=json.dumps({"error":{"message":"slow down"}}).encode();self.send_response(429);self.cors();self.send_header("Content-Type","application/json");self.send_header("Content-Length",str(len(b)));self.end_headers();self.wfile.write(b);return
        last=req["messages"][-1]["content"]
        text="Hello! The capital of France is Paris. You said: "+last
        self.send_response(200);self.cors();self.send_header("Content-Type","text/event-stream");self.send_header("Connection","close");self.end_headers()
        words=text.split(" ")
        self.wfile.write(b": keep-alive\n\n");self.wfile.flush()
        for i,w in enumerate(words):
            ch={"choices":[{"delta":{"content":(w if i==0 else " "+w)}}]}
            data=("data: "+json.dumps(ch)+"\n\n").encode()
            # split an event across two writes to test buffering
            self.wfile.write(data[:7]);self.wfile.flush();time.sleep(0.03);self.wfile.write(data[7:]);self.wfile.flush();time.sleep(0.03)
        self.wfile.write(b"data: [DONE]\n\n");self.wfile.flush();self.close_connection=True
    def log_message(self,*a):pass
class S(socketserver.ThreadingTCPServer):
    allow_reuse_address=True;daemon_threads=True
S(("127.0.0.1",int(sys.argv[1])),H).serve_forever()
