const $=s=>document.getElementById(s), LOGO="logo.png";
const WL_VER="2.3.5";
/* Models looked for next to this page, in order. Add your own file name here if you rename the model. */
const BUNDLED_MODELS=["Shadow-0_7B_Q2_K.gguf","model.gguf"];
/* Engine sources, tried in order. "./wllama/" = copy bundled inside the APK (works fully offline). */
const MIRRORS=["./wllama/","https://cdn.jsdelivr.net/npm/@wllama/wllama@"+WL_VER+"/","https://fastly.jsdelivr.net/npm/@wllama/wllama@"+WL_VER+"/","https://unpkg.com/@wllama/wllama@"+WL_VER+"/"];
async function getBytes(url){
  const hasC=typeof caches!=="undefined";let cache=null;
  if(hasC){try{cache=await caches.open("petal-engine-"+WL_VER)}catch(e){}}
  if(cache){try{const h=await cache.match(url);if(h){const b=await h.arrayBuffer();if(b.byteLength>10000)return b}}catch(e){}}
  const r=await fetch(url,{cache:"no-store"});
  if(!r.ok)throw new Error("HTTP "+r.status+" for "+url.split("/").slice(-2).join("/"));
  const b=await r.arrayBuffer();
  if(b.byteLength<10000)throw new Error("engine file came back empty");
  if(cache){try{await cache.put(url,new Response(b.slice(0)))}catch(e){}}
  return b;
}
const blobUrl=b=>URL.createObjectURL(new Blob([b],{type:"application/wasm"}));
let engineMode="data";const ENGINE_LOG=[];
async function initEngine(setStep){
  let last;
  for(const base of MIRRORS){
    try{
      setStep("Getting AI engine from "+(base.startsWith("./")?"app files":new URL(base).host)+"…");
      const mod=await import(base+"esm/index.js");
      let cfg;
      if(engineMode==="data"){
        const toData=async u=>{const b=new Uint8Array(await getBytes(u));let bin="";for(let i=0;i<b.length;i+=0x8000)bin+=String.fromCharCode.apply(null,b.subarray(i,i+0x8000));return "data:application/wasm;base64,"+btoa(bin)};
        const one=await toData(base+"esm/single-thread/wllama.wasm");let multi=one;
        if(self.crossOriginIsolated===true){try{multi=await toData(base+"esm/multi-thread/wllama.wasm")}catch(e){}}
        cfg={"single-thread/wasm":one,"multi-thread/wasm":multi};
      }else if(engineMode==="direct"){
        const abs=p=>new URL(base+p,location.href).href;
        cfg={"single-thread/wasm":abs("esm/single-thread/wllama.wasm"),"multi-thread/wasm":abs("esm/multi-thread/wllama.wasm")};
      }else{
        const one=blobUrl(await getBytes(base+"esm/single-thread/wllama.wasm"));
        let multi=one;
        if(self.crossOriginIsolated===true){try{multi=blobUrl(await getBytes(base+"esm/multi-thread/wllama.wasm"))}catch(e){}}
        cfg={"single-thread/wasm":one,"multi-thread/wasm":multi};
      }
      return new mod.Wllama(cfg);
    }catch(e){last=e;console.warn("engine source failed",base,e)}
  }
  throw new Error("Engine files could not be loaded ("+((last&&last.message)||last)+")");
}
let chats=[],cur=null,ctrl=null,ready=false,wl=null,ctxSize=2048,genStatus=null,engineKind=null,loadToken=0,loadTick=null,rmCount=0;
const SYS="You are Xire, a friendly and accurate assistant running privately on the user's device. Answer clearly and concisely. Use Markdown. Always put code in fenced code blocks and name the language.";
/* keep the conversation inside the model's context window: newest messages win */
function fit(msgs,reserve){
  const budget=Math.max(300,ctxSize-reserve-Math.ceil(SYS.length/3)-64)*3.2;
  const keep=[];let used=0;
  for(let i=msgs.length-1;i>=0;i--){
    const n=msgs[i].content.length+16;
    if(keep.length&&used+n>budget)break;
    keep.unshift(msgs[i]);used+=n;
  }
  while(keep.length>1&&keep[0].role!=="user")keep.shift();
  const f=keep[0];if(f.content.length>budget)keep[0]={role:f.role,content:f.content.slice(-Math.floor(budget))};
  return keep;
}

try{chats=JSON.parse(localStorage.getItem("petal.chats")||"[]")}catch(e){}
const save=()=>{try{localStorage.setItem("petal.chats",JSON.stringify(chats))}catch(e){}};
const active=()=>chats.find(c=>c.id===cur);

/* theme */
const mq=matchMedia("(prefers-color-scheme:dark)");
function applyTheme(t){
  const dark=t==="dark"||(t==="auto"&&mq.matches);
  document.documentElement.dataset.theme=dark?"dark":"light";
  $("tc").content=dark?"#000000":"#FAF8FF";
  try{window.PetalApp&&window.PetalApp.setTheme(dark)}catch(e){}
  document.querySelectorAll(".seg button").forEach(b=>b.setAttribute("aria-pressed",b.dataset.th===t));
}
let theme="auto";try{theme=localStorage.getItem("petal.theme")||"auto"}catch(e){}
document.querySelectorAll(".seg button").forEach(b=>b.onclick=()=>{theme=b.dataset.th;try{localStorage.setItem("petal.theme",theme)}catch(e){}applyTheme(theme)});
(mq.addEventListener?mq.addEventListener("change",()=>applyTheme(theme)):mq.addListener(()=>applyTheme(theme)));
applyTheme(theme);

/* sidebar */
const mobile=()=>innerWidth<=860;
const toggle=()=>document.body.classList.toggle("closed");
$("show").onclick=toggle;$("hide").onclick=toggle;$("scrim").onclick=toggle;
if(!mobile())document.body.classList.remove("closed");
matchMedia("(max-width:860px)").addEventListener("change",e=>document.body.classList.toggle("closed",e.matches));

function groupOf(ts){
  const sod=x=>new Date(x.getFullYear(),x.getMonth(),x.getDate()).getTime();
  const d=Math.round((sod(new Date())-sod(new Date(ts)))/864e5);
  return d<=0?"Today":d===1?"Yesterday":d<=7?"Previous 7 days":d<=30?"Previous 30 days":"Older";
}
function renderList(){
  const l=$("list");l.innerHTML="";
  if(!chats.length){l.innerHTML='<div class="none">No chats yet</div>';return}
  let g="";
  chats.forEach(c=>{
    const gn=groupOf(+c.id||Date.now());
    if(gn!==g){g=gn;const h=document.createElement("div");h.className="grp";h.textContent=g;l.appendChild(h)}
    const d=document.createElement("div");d.className="item"+(c.id===cur?" on":"");
    d.innerHTML='<span></span><button aria-label="Delete chat" title="Delete chat">🗑</button>';
    d.querySelector("span").textContent=c.title;
    d.onclick=()=>{open(c.id);if(mobile())toggle()};
    d.querySelector("button").onclick=e=>{e.stopPropagation();remove(c.id)};
    l.appendChild(d);
  });
}
function newChat(){cur=null;renderChat();renderList();if(mobile()&&!document.body.classList.contains("closed"))toggle();$("input").focus()}
function open(id){cur=id;renderChat();renderList()}
function remove(id){chats=chats.filter(c=>c.id!==id);if(cur===id)cur=null;save();renderChat();renderList()}
$("new").onclick=newChat;

/* ---------- markdown + code blocks ---------- */
const esc=t=>t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
const HASHL=new Set(["python","py","bash","sh","shell","zsh","yaml","yml","ruby","rb","r","toml","dockerfile","makefile","perl","powershell","ps1"]);
const KW="function|const|let|var|return|if|else|elif|for|while|do|switch|case|break|continue|class|def|import|from|export|default|new|try|catch|except|finally|throw|raise|async|await|in|of|is|not|and|or|None|null|undefined|true|false|True|False|public|private|protected|static|void|int|float|double|string|bool|boolean|char|long|struct|enum|interface|extends|implements|package|using|namespace|fn|mut|impl|pub|use|self|this|lambda|with|as|yield|typeof|instanceof|super|final|echo|fi|then|done|SELECT|FROM|WHERE|INSERT|UPDATE|DELETE|CREATE|TABLE|JOIN|ORDER|BY|GROUP";
const R_STR=/"""[\s\S]*?"""|"(?:\\.|[^"\\\n])*"|'(?:\\.|[^'\\\n])*'|`(?:\\.|[^`\\])*`/.source;
const R_NUM=/\b\d+(?:\.\d+)?\b/.source;
const R_KW="\\b(?:"+KW+")\\b";
function hl(code,lang){
  if(!lang)return esc(code);
  const com=HASHL.has(lang)?/#[^\n]*/.source
    :(lang==="html"||lang==="xml")?/<!--[\s\S]*?-->/.source
    :lang==="css"?/\/\*[\s\S]*?\*\//.source
    :lang==="sql"?/--[^\n]*/.source
    :/\/\/[^\n]*|\/\*[\s\S]*?\*\//.source;
  const re=new RegExp("("+com+")|("+R_STR+")|("+R_NUM+")|("+R_KW+")","g");
  let o="",last=0,m;
  while((m=re.exec(code))){
    if(m[0]===""){re.lastIndex++;continue}
    o+=esc(code.slice(last,m.index));
    const k=m[1]!==undefined?"c":m[2]!==undefined?"s":m[3]!==undefined?"n":"k";
    o+='<span class="t'+k+'">'+esc(m[0])+"</span>";last=re.lastIndex;
  }
  return o+esc(code.slice(last));
}
const COPY_SVG='<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="9" y="9" width="11" height="11" rx="2.5"/><path d="M5 15V6.5A2.5 2.5 0 0 1 7.5 4H15"/></svg>';
function codeBlock(code,lang){
  const l=(lang||"").toLowerCase();
  return '<div class="code"><div class="code-h"><span class="lang">'+esc(l||"code")+'</span><button class="copy" type="button" aria-label="Copy code">'+COPY_SVG+'<span>Copy</span></button></div><pre><code>'+hl(code,l)+'</code></pre></div>';
}
function inline(t){
  return t.split(/(`[^`\n]+`)/).map(p=>(p.length>2&&p[0]==="`"&&p.endsWith("`"))
    ?"<code>"+esc(p.slice(1,-1))+"</code>"
    :esc(p).replace(/\*\*([^*\n]+)\*\*/g,"<strong>$1</strong>").replace(/(^|[^*\w])\*([^*\n]+)\*(?![*\w])/g,"$1<em>$2</em>")).join("");
}
function md(src){
  const L=String(src).replace(/\r/g,"").split("\n"),out=[];let i=0,para=[],list=null,quote=[];
  const fP=()=>{if(para.length){out.push("<p>"+para.map(inline).join("<br>")+"</p>");para=[]}};
  const fL=()=>{if(list){out.push("<"+list.t+">"+list.i.map(x=>"<li>"+inline(x)+"</li>").join("")+"</"+list.t+">");list=null}};
  const fQ=()=>{if(quote.length){out.push("<blockquote>"+quote.map(inline).join("<br>")+"</blockquote>");quote=[]}};
  const flush=()=>{fP();fL();fQ()};
  while(i<L.length){
    const ln=L[i];let m;
    if((m=ln.match(/^\s*```\s*([\w+#.-]*)\s*$/))){
      flush();const buf=[];i++;
      while(i<L.length&&!/^\s*```\s*$/.test(L[i])){buf.push(L[i]);i++}
      i++;out.push(codeBlock(buf.join("\n"),m[1]));continue;
    }
    if(!ln.trim()){flush();i++;continue}
    if((m=ln.match(/^(#{1,4})\s+(.*)$/))){flush();out.push('<div class="h h'+m[1].length+'">'+inline(m[2])+"</div>");i++;continue}
    if(/^\s*([-*_])(\s*\1){2,}\s*$/.test(ln)){flush();out.push("<hr>");i++;continue}
    if((m=ln.match(/^>\s?(.*)$/))){fP();fL();quote.push(m[1]);i++;continue}
    if((m=ln.match(/^\s*[-*+]\s+(.*)$/))){fP();fQ();if(!list||list.t!=="ul"){fL();list={t:"ul",i:[]}}list.i.push(m[1]);i++;continue}
    if((m=ln.match(/^\s*\d+[.)]\s+(.*)$/))){fP();fQ();if(!list||list.t!=="ol"){fL();list={t:"ol",i:[]}}list.i.push(m[1]);i++;continue}
    fL();fQ();para.push(ln);i++;
  }
  flush();return out.join("");
}
document.addEventListener("click",async e=>{
  const b=e.target.closest&&e.target.closest(".copy");if(!b)return;
  const code=b.closest(".code").querySelector("code").textContent;let ok=false;
  try{await navigator.clipboard.writeText(code);ok=true}catch(_){}
  if(!ok){try{const t=document.createElement("textarea");t.value=code;t.style.cssText="position:fixed;opacity:0;top:0";document.body.appendChild(t);t.select();ok=document.execCommand("copy");t.remove()}catch(_){}}
  const sp=b.querySelector("span");b.classList.toggle("ok",ok);sp.textContent=ok?"Copied":"Copy failed";
  clearTimeout(b._t);b._t=setTimeout(()=>{b.classList.remove("ok");sp.textContent="Copy"},1600);
});
document.documentElement.style.setProperty("--logo","url("+LOGO+")");

/* chat view */
function bubble(role,text){
  const w=$("log");document.body.classList.remove("home");if(w.querySelector(".empty"))w.innerHTML="";
  const ai=role!=="user";
  const d=document.createElement("div");d.className="msg "+(ai?"ai":"user");
  d.innerHTML=(ai?'<i class="av" aria-hidden="true"></i>':'')+'<div><div class="bubble'+(ai?' md':'')+'"></div><div class="meta"></div></div>';
  const b=d.querySelector(".bubble");
  if(ai&&text)b.innerHTML=md(text);else b.textContent=text;
  w.appendChild(d);$("chat").scrollTop=1e9;return d;
}
const CHIPS=[
 ["<svg class=\"i\" viewBox=\"0 0 24 24\" aria-hidden=\"true\"><path d=\"M4 20l1-4L16.5 4.5a2 2 0 0 1 3 3L8 19l-4 1z\"/><path d=\"M14 7l3 3\"/></svg>","Write","Help me write a polite email asking my manager for a deadline extension."],
 ["<svg class=\"i\" viewBox=\"0 0 24 24\" aria-hidden=\"true\"><path d=\"M3 9l9-5 9 5-9 5-9-5z\"/><path d=\"M7 11.5V16c0 1.3 2.2 3 5 3s5-1.7 5-3v-4.5\"/><path d=\"M21 9v6\"/></svg>","Learn","Explain how neural networks work in simple terms with an analogy."],
 ["<svg class=\"i\" viewBox=\"0 0 24 24\" aria-hidden=\"true\"><path d=\"M8 8l-5 4 5 4M16 8l5 4-5 4M14 5l-4 14\"/></svg>","Code","Write a Python function that checks if a number is prime, with comments and an example."],
 ["<svg class=\"i\" viewBox=\"0 0 24 24\" aria-hidden=\"true\"><path d=\"M9 18h6M10 21h4\"/><path d=\"M12 3a6 6 0 0 0-3.5 10.9c.6.5 1 1.2 1 2.1h5c0-.9.4-1.6 1-2.1A6 6 0 0 0 12 3z\"/></svg>","Brainstorm","Give me 5 creative project ideas I can build in a weekend."]];
function greeting(){return "Hello, I am Xire intelligence"}
const SUB_OFF='Add a model file to get started · <a class="cta">Add model</a>',SUB_ON="Running privately on your device";
const EMPTY=()=>'<div class="empty"><div class="greet"><img src="'+LOGO+'" alt=""><h2>'+greeting()+'</h2></div><p class="sub">'+(ready?SUB_ON:SUB_OFF)+'</p>'
 '</div>';
const CHIPS_HTML=CHIPS.map(c=>'<button class="chip" type="button" data-p="'+c[2].replace(/"/g,"&quot;")+'">'+c[0]+'<span>'+c[1]+'</span></button>').join("");
$("homeChips").addEventListener("click",e=>{const c=e.target.closest(".chip");if(c){const i=$("input");i.value=c.dataset.p;i.dispatchEvent(new Event("input"));i.focus()}});
$("log").addEventListener("click",e=>{
  const c=e.target.closest(".chip");
  if(c){const i=$("input");i.value=c.dataset.p;i.dispatchEvent(new Event("input"));i.focus();return}
  if(e.target.closest(".cta"))$("dlg").showModal();
});
function renderChat(){
  const c=active();$("title").textContent=c?c.title:"New chat";$("log").innerHTML="";
  if(!c||!c.msgs.length){$("log").innerHTML=EMPTY();$("homeChips").innerHTML=CHIPS_HTML;document.body.classList.add("home");updateCta();return}
  document.body.classList.remove("home");
  c.msgs.forEach(m=>bubble(m.role,m.content));
}

/* saved model: keep the picked file on this device so it loads by itself next time */
const MStore={
  db:()=>new Promise((ok,no)=>{const r=indexedDB.open("xire-model",1);r.onupgradeneeded=()=>r.result.createObjectStore("f");r.onsuccess=()=>ok(r.result);r.onerror=()=>no(r.error)}),
  async put(fl){const d=await this.db();return new Promise((ok,no)=>{const t=d.transaction("f","readwrite"),st=t.objectStore("f");st.clear();st.put(fl.map(f=>({name:f.name,blob:f})),"model");t.oncomplete=ok;t.onerror=()=>no(t.error)})},
  async get(){const d=await this.db();return new Promise((ok,no)=>{const q=d.transaction("f").objectStore("f").get("model");q.onsuccess=()=>ok(q.result||null);q.onerror=()=>no(q.error)})},
  async clear(){const d=await this.db();return new Promise((ok,no)=>{const t=d.transaction("f","readwrite");t.objectStore("f").clear();t.oncomplete=ok;t.onerror=()=>no(t.error)})}
};
let fromSaved=false;
/* some models (Qwen3 / R1 style) print their reasoning inside <think> tags: hide it, show only the answer */
function clean(t){let x=String(t).replace(/<think>[\s\S]*?<\/think>/g,"");const i=x.indexOf("<think>");if(i>=0)x=x.slice(0,i);return x.replace(/^\s+/,"")}
const SYSX=()=>SYS+(/qwen|shadow/i.test((file&&file.name)||"")?" /no_think":"");
/* runner panel */
let file=null;
const fmt=b=>b>1e9?(b/1e9).toFixed(2)+" GB":Math.round(b/1e6)+" MB";
const dz=$("drop"),useCloud=()=>$("useCloud").checked,useSrv=()=>$("useServer").checked||useCloud();
const cloudSettings=()=>({base:$("cbase").value.trim(),model:$("cmodel").value.trim(),token:$("ctoken").value.trim(),remember:$("cremember").checked});
const srvSettings=()=>({base:$("url").value.replace(/\/$/,"")+"/v1",model:$("mname").value,anonymous:true});
const srvName=()=>useCloud()?(cloudSettings().model.split("/").pop().split(":")[0]||"Cloud model"):$("mname").value;
const setNote=(t,bad)=>{$("note").textContent=t;$("note").classList.toggle("errt",!!bad);$("note").classList.remove("warn")};
let files=[];
const totalSize=()=>files.reduce((a,f)=>a+f.size,0);
function pick(list){
  const fs=[...(list||[])];if(!fs.length)return;
  if(!fs.every(f=>/\.gguf$/i.test(f.name))){setNote("That isn’t a .gguf model file.",1);return}
  fs.sort((x,y)=>x.name.localeCompare(y.name,undefined,{numeric:true}));
  try{localStorage.removeItem("xire-noauto")}catch(_){}
  files=fs;file=fs[0];ready=false;setNote("");$("step").textContent="File added. Tap Run model.";showFile();updatePill();
  if(/[._-]I?Q[12]_/i.test(fs[0].name)){setNote("This is a very low-quality (Q1/Q2) file, so answers are often nonsense. For good answers use a Q4_K_M or Q8_0 file of the same model.");$("note").classList.add("warn")}
  if(totalSize()>1.4e9){setNote("Large model ("+fmt(totalSize())+"). The built-in engine can run out of memory above about 1.5 GB. A smaller model (around 1 GB) is the safest choice.");$("note").classList.add("warn")}
}
function showFile(){
  $("fileCard").hidden=!file;dz.hidden=!!file;$("gethint").hidden=!!file;$("srv").hidden=!$("useServer").checked;$("cloud").hidden=!useCloud();
  if(file){$("fn").textContent=files.length>1?file.name+" (+"+(files.length-1)+" more)":file.name;
    $("fs").textContent=fmt(totalSize())+(files.length>1?" · "+files.length+" parts":"")}
  $("run").disabled=!(file||useSrv());
}
function updateCta(){const p=document.querySelector(".empty .sub");if(p)p.innerHTML=ready?SUB_ON:SUB_OFF}
function updatePill(){updateCta();
  const g=$("gear");g.classList.toggle("on",ready);
  g.querySelector("span").textContent=ready?(useSrv()?srvName():(file?file.name.replace(/\.gguf$/i,""):"Model")):(file?"Run model":"Add model");
}
$("file").onchange=e=>pick(e.target.files);
["dragenter","dragover"].forEach(v=>dz.addEventListener(v,e=>{e.preventDefault();dz.classList.add("over")}));
["dragleave","drop"].forEach(v=>dz.addEventListener(v,e=>{e.preventDefault();dz.classList.remove("over")}));
dz.addEventListener("drop",e=>pick(e.dataTransfer.files));
$("rm").onclick=()=>{
  rmCount++;try{localStorage.setItem("xire-noauto","1")}catch(_){}
  loadToken++;clearInterval(loadTick);
  try{if(ctrl)ctrl.abort()}catch(_){}
  try{XEngine.dispose()}catch(_){}
  if(wl){try{wl.exit()}catch(_){}wl=null}
  engineKind=null;try{MStore.clear()}catch(_){}
  file=null;files=[];ready=false;fromSaved=false;$("file").value="";
  $("dlg").classList.remove("busy","done");setNote("");$("step").textContent="Add your AI model file";
  showFile();updatePill();
};
$("useServer").onchange=()=>{if($("useServer").checked)$("useCloud").checked=false;ready=false;showFile();updatePill()};
$("useCloud").onchange=()=>{if(useCloud())$("useServer").checked=false;ready=false;showFile();updatePill()};
$("gear").onclick=()=>$("dlg").showModal();
$("plus").onclick=()=>$("dlg").showModal();
$("close").onclick=()=>$("dlg").close();
$("temp").oninput=e=>$("tv").textContent=e.target.value;
$("max").oninput=e=>$("mv").textContent=e.target.value;

/* ===== Built-in runner (gguf-core.js, pure JavaScript, runs in a Web Worker): used for Qwen3 .gguf models ===== */
const SYSB="You are Xire, a helpful assistant. Be clear and brief. Put code in fenced code blocks.";
const XEngine={
  w:null,workers:[],url:null,send:null,nCtx:1024,threads:1,seq:0,loadCb:null,genCb:null,pongCb:null,
  inPage(){const H=XireGGUF.makeHandler(m=>setTimeout(()=>this.onMsg(m),0));this.w=null;this.send=d=>H(d)},
  dispose(){
    for(const w of [this.w,...this.workers]){try{w&&w.terminate()}catch(_){}}
    this.w=null;this.workers=[];this.send=null;
    if(this.url){if(this.url.startsWith("blob:")){try{URL.revokeObjectURL(this.url)}catch(_){}}this.url=null}
    const c=this.loadCb;this.loadCb=null;if(c){const e=new Error("cancelled");e.cancelled=true;c.no(e)}
    const g=this.genCb;this.genCb=null;if(g){const e=new Error("stopped");e.name="AbortError";g.no(e)}
  },
  start(){
    this.dispose();
    try{
      const el=document.getElementById("xire-core");
      if(el&&el.textContent.trim().length>1000){          /* single-file build: the runner is inside the page */
        const src=el.textContent+"\nlet __H=null;onmessage=e=>{const d=e.data;if(d&&d.type==='port'){const p=d.port,C=XireGGUF.makeComputeHandler((m,t)=>p.postMessage(m,t||[]));p.addEventListener('message',ev=>C(ev.data));if(p.start)p.start();return}if(!__H)__H=XireGGUF.makeHandler(m=>postMessage(m));__H(d)};";
        this.url=URL.createObjectURL(new Blob([src],{type:"text/javascript"}));
      }else this.url="gguf-worker.js";                       /* multi-file build */
      const w=new Worker(this.url);w.onmessage=e=>this.onMsg(e.data);w.onerror=()=>{};this.w=w;this.send=(d,t)=>w.postMessage(d,t||[]);
    }catch(err){this.inPage()}
  },
  ping(){return new Promise(r=>{
    if(!this.w)return r();let done=false;
    const t=setTimeout(()=>{if(!done){done=true;try{this.w.terminate()}catch(_){}this.inPage();r()}},2500);
    this.pongCb=()=>{if(!done){done=true;clearTimeout(t);r()}};this.send({type:"ping"});
  })},
  async load(file,setStep,threads){
    this.start();await this.ping();
    const ports=[];
    if(this.w){
      try{for(let i=1;i<(threads||1);i++){const w=new Worker(this.url),ch=new MessageChannel();w.postMessage({type:"port",port:ch.port1},[ch.port1]);this.workers.push(w);ports.push(ch.port2)}}
      catch(e){this.workers.forEach(w=>{try{w.terminate()}catch(_){}});this.workers=[];ports.length=0}
    }
    return new Promise((ok,no)=>{this.loadCb={ok,no,setStep};this.send({type:"load",file,nCtx:1024,noThink:true,warm:SYSB,ports},ports)});
  },
  onMsg(m){
    if(m.type==="pong"){this.pongCb&&this.pongCb();return}
    if(m.type==="status"){if(m.id!==undefined){this.genCb&&this.genCb.onStatus&&this.genCb.onStatus(m.text)}else this.loadCb&&this.loadCb.setStep(m.text);return}
    if(m.type==="ready"){this.nCtx=m.nCtx;this.threads=m.threads||1;const c=this.loadCb;this.loadCb=null;c&&c.ok();return}
    if(m.type==="text"){this.genCb&&this.genCb.onText(m.text);return}
    if(m.type==="done"){const c=this.genCb;this.genCb=null;c&&c.ok();return}
    if(m.type==="error"){
      const e=new Error(m.message);
      if(m.id==="load"){const c=this.loadCb;this.loadCb=null;e.code=m.code;e.xire=true;c&&c.no(e)}
      else{const c=this.genCb;this.genCb=null;e.name=m.name||"Error";c&&c.no(e)}
    }
  },
  generate(msgs,opts,onText,signal,onStatus){
    return new Promise((ok,no)=>{
      const id=++this.seq,ab=()=>this.send&&this.send({type:"stop"});
      const fin=f=>x=>{signal.removeEventListener("abort",ab);f(x)};
      this.genCb={ok:fin(ok),no:fin(no),onText,onStatus};
      signal.addEventListener("abort",ab);
      this.send({type:"gen",id,messages:msgs,opts});
    });
  }
};
const THREADS=Math.max(1,Math.min(4,navigator.hardwareConcurrency||2));
function friendlyErr(e){
  if(e&&e.xire)return "Couldn’t load the model: "+e.message;
  const raw=String((e&&e.message)||e||"unknown error"),gb=totalSize()/1e9;
  if(/BufferSource|instantiate|empty/i.test(raw))return "The AI engine could not start on this device (its engine file was read as empty), so this is not a problem with your model file. Tried: "+ENGINE_LOG.map(x=>x.split(" / ")[0]).filter((v,i,a)=>a.indexOf(v)===i).join(", ")+". Please make sure the device is online once, then tap Run model again.";
  if(gb>1.4)return "This model ("+gb.toFixed(2)+" GB) is too large for the built-in engine on this device, so it ran out of memory. Please add a smaller model (about 1 GB or less), or use a local llama.cpp server under More options.";
  return "Couldn’t load the model ("+raw.slice(0,120)+"). Check the internet once (the engine is cached after that), or try a smaller .gguf.";
}
$("run").onclick=async()=>{
  const d=$("dlg"),t0=Date.now(),my=++loadToken;
  d.classList.add("busy");$("run").disabled=true;setNote("");$("gear").querySelector("span").textContent="Loading model…";
  clearInterval(loadTick);
  const tick=loadTick=setInterval(()=>setNote("Keep this page open. Elapsed "+Math.round((Date.now()-t0)/1000)+"s (timer only; the line above shows real progress)."),1000);
  try{
    if(useCloud()){
      $("step").textContent="Checking cloud settings…";ctxSize=4096;
      const cs=cloudSettings();
      if(!cs.base||!cs.model)throw Object.assign(new Error("Fill in the API address and the model name."),{cloud:true});
      if(!cs.token)await XCloud.probe();
      XCloud.target(cs);          /* throws a clear message if there is neither a token nor a server-side token */
      XCloud.save(cs);
    }else if(useSrv()){
      $("step").textContent="Connecting to server…";ctxSize=4096;
      const r=await fetch($("url").value.replace(/\/$/,"")+"/v1/models");if(!r.ok)throw 0;
    }else{
      engineKind=null;let built=false;
      if(files.length===1){
        const stp=x=>{if(my===loadToken)$("step").textContent=x};
        try{
          try{await XEngine.load(files[0],stp,THREADS)}
          catch(e1){if(e1&&(e1.cancelled||e1.code)||THREADS<2)throw e1;stp("Retrying with one thread…");await XEngine.load(files[0],stp,1)}
          engineKind="xire";ctxSize=XEngine.nCtx;built=true;
        }catch(e0){if(e0&&e0.cancelled)return;if(!(e0&&(e0.code==="UNSUPPORTED_ARCH"||e0.code==="UNSUPPORTED_TYPE")))throw e0;$("step").textContent="This model type needs the downloadable engine…"}
      }
      if(!built){
      $("step").textContent="Preparing engine…";
      if(wl){try{await wl.exit()}catch(_){}wl=null}
      wl=await initEngine(s=>$("step").textContent=s);
      $("step").textContent="Loading model into memory…";
      const big=totalSize()>1.2e9;
      const tries=big?[{n_ctx:1024,n_batch:128},{n_ctx:512,n_batch:64},{n_ctx:256,n_batch:32}]:[{n_ctx:4096,n_batch:512},{n_ctx:2048,n_batch:256},{n_ctx:768,n_batch:128}];
      let lastErr=null,k=0,m=0;const MODES=["data","direct","blob"];engineMode=MODES[0];ENGINE_LOG.length=0;
      while(k<tries.length){
        try{await wl.loadModel(files,Object.assign({},tries[k],{progressCallback:({loaded,total})=>{if(total)$("step").textContent="Loading model into memory… "+Math.min(100,Math.round(loaded/total*100))+"% ("+fmt(loaded)+" of "+fmt(total)+")"}}));ctxSize=tries[k].n_ctx;lastErr=null;break}
        catch(e1){
          lastErr=e1;const msg=String((e1&&e1.message)||e1);ENGINE_LOG.push(engineMode+" / ctx "+tries[k].n_ctx+": "+msg.slice(0,80));
          console.warn("load attempt failed",engineMode,tries[k],e1);
          try{await wl.exit()}catch(_){}
          if(/BufferSource|instantiate|empty/i.test(msg)&&m<MODES.length-1){m++;engineMode=MODES[m];$("step").textContent="Trying another engine method…"}
          else if(k<tries.length-1){k++;$("step").textContent="Retrying with less memory…"}
          else break;
          wl=await initEngine(x=>$("step").textContent=x);
        }
      }
      if(lastErr)throw lastErr;
      }
    }
    if(my!==loadToken)return;
    ready=true;clearInterval(tick);setNote("");$("step").textContent="Ready to chat"+(engineKind==="xire"?" · "+XEngine.threads+" thread"+(XEngine.threads>1?"s":""):"");
    if(!useSrv()&&!fromSaved&&totalSize()<9e8){MStore.put(files).catch(()=>{})}d.classList.add("done");updatePill();
    setTimeout(()=>{d.close();d.classList.remove("busy","done");$("input").focus()},1000);
  }catch(e){
    if(my!==loadToken)return;
    ready=false;clearInterval(tick);d.classList.remove("busy");$("step").textContent="Couldn’t start the model";
    setNote(useCloud()?XCloud.explain(e):useSrv()?"Can’t reach the server. Check the address and that it’s running.":friendlyErr(e),1);
    updatePill();
  }
  showFile();
};

const THINK='<div class="think" role="status"><span class="dots"><i></i><i></i><i></i></span><span>Thinking…</span></div>';
/* generate */
async function generate(msgs,onText,signal){
  const temp=+$("temp").value;const max=Math.min(+$("max").value,Math.floor(ctxSize/2));let out="";const hist=fit(msgs,max);
  if(!useSrv()&&engineKind==="xire"){
    await XEngine.generate([{role:"system",content:SYSB},...hist],{max,temp,topK:40,topP:.9,penalty:1.1},t=>{out=t;onText(t)},signal,x=>{if(genStatus)genStatus(x)});
    return out;
  }
  if(!useSrv()){
    const go=m=>wl.createChatCompletion(m,{nPredict:max,sampling:{temp,top_k:40,top_p:.9,penalty_repeat:1.1},abortSignal:signal,onNewToken:(t,p,text)=>{out=text;onText(text)}});
    try{await go([{role:"system",content:SYSX()},...hist])}
    catch(e){
      /* some chat templates reject a system role: retry with the instructions folded into the first message */
      if(signal.aborted||(e&&e.name==="AbortError")||out)throw e;
      const h=hist.slice();h[0]={role:h[0].role,content:SYSX()+"\n\n"+h[0].content};
      await go(h);
    }
    return out;
  }
  return await XCloud.stream(useCloud()?cloudSettings():srvSettings(),[{role:"system",content:SYSX()},...hist],{temperature:temp,max_tokens:max},signal,t=>{out=t;onText(t)});
}

async function send(){
  const text=$("input").value.trim();
  if(ctrl){ctrl.abort();return}
  if(!text)return;
  if(!ready){$("dlg").showModal();setNote("Add a model file and tap Run model first.");return}
  $("input").value="";$("input").style.height="auto";
  let c=active();
  if(!c){c={id:Date.now()+"",title:text.slice(0,32),msgs:[]};chats.unshift(c);cur=c.id;renderList()}
  c.msgs.push({role:"user",content:text});$("title").textContent=c.title;bubble("user",text);
  const el=bubble("ai",""),b=el.querySelector(".bubble");b.classList.add("md");b.innerHTML=THINK;genStatus=x=>{const e=b.querySelector(".think span:last-child");if(e)e.textContent=x};
  $("send").textContent="■";$("send").style.fontSize="14px";$("send").setAttribute("aria-label","Stop");ctrl=new AbortController();const t0=performance.now();let out="",raf=0;
  try{
    out=await generate(c.msgs.slice(),t=>{out=t;b.classList.add("cursor");if(!raf)raf=requestAnimationFrame(()=>{raf=0;const sh=clean(out);b.innerHTML=sh?md(sh):THINK;$("chat").scrollTop=1e9})},ctrl.signal);
    const s=(performance.now()-t0)/1000,n=out.split(/\s+/).length;el.querySelector(".meta").textContent=(n/s).toFixed(1)+" words/sec";
  }catch(e){
    if(e.name!=="AbortError"&&!ctrl.signal.aborted){b.textContent=out||(useCloud()?XCloud.explain(e):useSrv()?"Couldn’t reach the server. Open the model menu and reconnect.":"The reply stopped unexpectedly. Try a shorter message, or reload the model from the model menu.");if(useSrv()&&!useCloud()){ready=false;updatePill()}}
  }
  out=clean(out);
  if(out)c.msgs.push({role:"assistant",content:out});
  if(raf){cancelAnimationFrame(raf);raf=0}
  if(out)b.innerHTML=md(out);else if(b.querySelector(".think"))b.textContent="Stopped.";b.classList.remove("cursor");$("send").textContent="↑";$("send").style.fontSize="";$("send").setAttribute("aria-label","Send");ctrl=null;save();
}
$("send").onclick=send;
$("input").addEventListener("input",e=>{e.target.style.height="auto";e.target.style.height=e.target.scrollHeight+"px"});
$("input").addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey&&!mobile()){e.preventDefault();send()}});
renderChat();renderList();
(async()=>{
  const s=XCloud.load();$("cbase").value=s.base;$("cmodel").value=s.model;$("ctoken").value=s.token||"";$("cremember").checked=!!s.remember;
  const p=await XCloud.probe();
  if(p){
    if(!s.remember&&p.model)$("cmodel").value=p.model;
    $("cinfo").textContent=p.hasToken?"This Xire server already holds a Hugging Face token, so you can leave the token field empty. The token never reaches your browser.":"Needs internet. Your messages go to the provider you choose, not just your device. Set HF_TOKEN before starting Xire to keep the token on the server.";
  }
})();
setTimeout(()=>{const x=document.getElementById("splash");if(x)x.remove()},1600);
(async()=>{
  try{
    await new Promise(r=>setTimeout(r,600));
    if(ready||useSrv())return;
    try{if(localStorage.getItem("xire-noauto"))return}catch(_){}   /* the user removed the model: do not load it again by itself */
    const rc=rmCount;
    let saved=null;
    const isGguf=async b=>b.size>1e6&&new TextDecoder().decode(await b.slice(0,4).arrayBuffer())==="GGUF";
    const grab=async(url,name)=>{try{const r=await fetch(url);if(!r.ok)return null;const b=await r.blob();return(await isGguf(b))?[{name,blob:b}]:null}catch(e){return null}};
    /* 1) a computer/server run: any model in the models folder */
    try{const lr=await fetch("api/models",{cache:"no-store"});const list=lr.ok?await lr.json():[];
      if(Array.isArray(list)&&list.length){$("step").textContent="Loading "+list[0].name+"…";saved=await grab(list[0].url,list[0].name)}}catch(e){}
    /* 2) a model bundled next to this page (APK assets / static hosting) */
    if(!saved){for(const n of BUNDLED_MODELS){$("step").textContent="Loading "+n+"…";saved=await grab("./"+n,n);if(saved)break}}
    /* 3) the model remembered from last time */
    if(!saved||!saved.length){try{saved=await MStore.get()}catch(e){}}
    if(!saved||!saved.length){
      /* nothing local: if this server holds a Hugging Face token, start in cloud mode */
      const p=XCloud.proxy||await XCloud.probe();
      if(p&&p.hasToken&&rc===rmCount&&!file&&!ready){$("useServer").checked=false;$("useCloud").checked=true;showFile();$("run").click()}
      return;
    }
    if(rc!==rmCount||file||ready)return;   /* removed or chosen by hand while this was loading */
    fromSaved=true;pick(saved.map(x=>new File([x.blob],x.name)));
    $("step").textContent="Loading saved model…";$("run").click();
  }catch(e){}
})();
/* Auto-connect when this page is served by llama-server itself (same address, no setup) */
(async()=>{
  if(!/^https?:$/.test(location.protocol))return;
  try{
    const r=await fetch(location.origin+"/v1/models");if(!r.ok)return;
    const j=await r.json();if(!Array.isArray(j.data))return;
    const id=(j.data[0]&&(j.data[0].id||j.data[0].model))||"Local model";
    $("useServer").checked=true;$("url").value=location.origin;
    $("mname").value=String(id).split("/").pop().replace(/\.gguf$/i,"");
    ready=true;showFile();updatePill();
  }catch(e){}
})();
