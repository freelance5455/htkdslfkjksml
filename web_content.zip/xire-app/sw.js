/* Xire AI - service worker: keeps the app shell available offline.
   Network first (so updates always arrive), cache as the fallback.
   Never cached: model files, /api/ calls (cloud proxy, model list). */
const CACHE = "xire-shell-v3";
const SHELL = ["./", "index.html", "style.css", "app.js", "cloud.js", "gguf-core.js", "gguf-worker.js", "logo.png", "icon-192.png", "icon-512.png", "manifest.json"];
self.addEventListener("install", e => { e.waitUntil(caches.open(CACHE).then(c => Promise.all(SHELL.map(f => c.add(f).catch(() => {})))).catch(() => {})); self.skipWaiting(); });
self.addEventListener("activate", e => { e.waitUntil(caches.keys().then(k => Promise.all(k.filter(x => x !== CACHE).map(x => caches.delete(x)))).then(() => self.clients.claim())); });
self.addEventListener("fetch", e => {
  const r = e.request, u = new URL(r.url);
  if (r.method !== "GET" || u.origin !== location.origin || /\.gguf$/i.test(u.pathname) || u.pathname.includes("/api/") || r.headers.has("range")) return;
  e.respondWith(fetch(r).then(res => { if (res.ok) { const cp = res.clone(); caches.open(CACHE).then(c => c.put(r, cp)); } return res; }).catch(() => caches.match(r)));
});
