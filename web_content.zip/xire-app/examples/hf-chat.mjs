/* Hugging Face router example (the code you gave me, made safer and more useful).

   Setup:   npm install openai
   Run:     HF_TOKEN=hf_xxx node examples/hf-chat.mjs "What is the capital of France?"
            HF_TOKEN=hf_xxx node examples/hf-chat.mjs --stream "Write a haiku about rain"

   The same endpoint and model are used by Xire's "cloud model" option (cloud.js). */

import { OpenAI } from "openai";

const token = process.env.HF_TOKEN;
if (!token) {
  console.error("HF_TOKEN is not set. Create a token at https://huggingface.co/settings/tokens");
  console.error('(permission: "Make calls to Inference Providers") and run: HF_TOKEN=hf_xxx node examples/hf-chat.mjs "Hello"');
  process.exit(1);
}

const client = new OpenAI({
  baseURL: process.env.XIRE_UPSTREAM || "https://router.huggingface.co/v1",
  apiKey: token,
});

const MODEL = process.env.XIRE_MODEL || "Qwen/Qwen2.5-0.5B-Instruct:featherless-ai";
const args = process.argv.slice(2);
const stream = args[0] === "--stream";
const prompt = (stream ? args.slice(1) : args).join(" ") || "What is the capital of France?";
const messages = [
  { role: "system", content: "You are Xire, a friendly and accurate assistant. Answer clearly and briefly." },
  { role: "user", content: prompt },
];

try {
  if (stream) {
    const s = await client.chat.completions.create({ model: MODEL, messages, stream: true, max_tokens: 512 });
    for await (const part of s) process.stdout.write(part.choices[0]?.delta?.content ?? "");
    process.stdout.write("\n");
  } else {
    const chatCompletion = await client.chat.completions.create({ model: MODEL, messages, max_tokens: 512 });
    console.log(chatCompletion.choices[0].message.content);
  }
} catch (e) {
  const status = e && e.status;
  if (status === 401 || status === 403) console.error("The token was rejected. Check it and its permissions.");
  else if (status === 402) console.error("This provider needs credits. Add credits on Hugging Face or pick another model.");
  else if (status === 404) console.error("Model not found. The format is owner/model:provider.");
  else if (status === 429) console.error("Too many requests. Wait a moment and try again.");
  else console.error("Request failed:", (e && e.message) || e);
  process.exit(1);
}
