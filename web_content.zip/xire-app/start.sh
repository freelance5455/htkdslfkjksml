#!/bin/sh
# Xire AI - Mac / Linux / Termux launcher. Double-click or run: sh start.sh
cd "$(dirname "$0")" || exit 1
if command -v python3 >/dev/null 2>&1; then exec python3 run.py "$@"; fi
if command -v python >/dev/null 2>&1; then exec python run.py "$@"; fi
echo "Python is not installed. Get it from https://www.python.org/downloads/"; exit 1
