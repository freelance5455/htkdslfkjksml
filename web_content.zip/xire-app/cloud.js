/* Xire cloud runner
   Talks to any OpenAI-compatible chat API. The default is the Hugging Face router, the same endpoint as
   examples/hf-chat.mjs:  https://router.huggingface.co/v1  +  model "Qwen/Qwen2.5-0.5B-Instruct:featherless-ai".

   Two ways to authenticate:
   1) Proxy (safest): start Xire with run.py or server.mjs while HF_TOKEN is set. The token stays on the server
      and the browser calls /api/cloud/v1/chat/completions without ever seeing it.
   2) Direct: type your token in the app. It is sent straight from the browser to the API.
      It is only saved on the device if "Remember" is ticked. */
(function (root) {
"use strict";

const DEFAULTS = { base: "https://router.huggingface.co/v1", model: "Qwen/Qwen2.5-0.5B-Instruct:featherless-ai" };
const KEY = "xire-cloud";

function fail(code, message, status) { const e = new Error(message); e.cloud = true; e.code = code; e.status = status; return e; }

function explainStatus(status, detail) {
  const d = detail ? " (" + String(detail).slice(0, 140) + ")" : "";
  if (status === 401 || status === 403) return "The token was rejected. Check that it is correct and has the permission “Make calls to Inference Providers”." + d;
  if (status === 402) return "This provider needs credits (the free allowance is used up). Add credits on Hugging Face or pick another model." + d;
  if (status === 404) return "Model not found. Check the model name. The format is owner/model or owner/model:provider." + d;
  if (status === 408 || status === 504) return "The provider took too long to answer. Try again." + d;
  if (status === 413) return "The conversation is too long for this model. Start a new chat." + d;
  if (status === 429) return "Too many requests right now. Wait a moment and try again." + d;
  if (status >= 500) return "The provider had a problem. Try again in a moment, or choose another model." + d;
  return "The cloud model returned an error (" + status + ")." + d;
}

const XCloud = {
  DEFAULTS,
  proxy: null,               /* filled by probe() when the page is served by serve.py / server.mjs */

  load() {
    const base = Object.assign({ token: "", remember: false }, DEFAULTS);
    try { return Object.assign(base, JSON.parse(localStorage.getItem(KEY) || "{}")); } catch (e) { return base; }
  },
  save(s) {
    try {
      const o = { base: s.base, model: s.model, remember: !!s.remember };
      if (s.remember && s.token) o.token = s.token;
      localStorage.setItem(KEY, JSON.stringify(o));
    } catch (e) {}
  },
  forget() { try { localStorage.removeItem(KEY); } catch (e) {} },

  /* Is there a Xire server with a token next to this page? */
  async probe() {
    if (!/^https?:$/.test(location.protocol)) return null;
    try {
      const r = await fetch("api/cloud/status", { cache: "no-store" });
      if (!r.ok) return null;
      const j = await r.json();
      if (j && j.proxy) { this.proxy = j; return j; }
    } catch (e) {}
    return null;
  },

  /* Decide where a request goes. Throws a friendly error when something is missing. */
  target(s) {
    const token = (s.token || "").trim();
    if (s.anonymous) return { url: s.base.replace(/\/+$/, "") + "/chat/completions", headers: { "Content-Type": "application/json" }, via: "direct" };
    if (!token && this.proxy && this.proxy.hasToken) return { url: "api/cloud/v1/chat/completions", headers: { "Content-Type": "application/json" }, via: "proxy" };
    if (!token) throw fail("NO_TOKEN", "Add your Hugging Face token in the model menu, or start Xire with HF_TOKEN set.");
    if (!/^https:\/\//i.test(s.base) && !/^http:\/\/(localhost|127\.0\.0\.1)/i.test(s.base)) throw fail("BAD_URL", "The API address must start with https://");
    return { url: s.base.replace(/\/+$/, "") + "/chat/completions", headers: { "Content-Type": "application/json", Authorization: "Bearer " + token }, via: "direct" };
  },

  /* Streams a reply. onText(fullTextSoFar) is called as tokens arrive. Returns the full text. */
  async stream(s, messages, o, signal, onText) {
    const t = this.target(s);
    let r;
    try {
      r = await fetch(t.url, { method: "POST", signal, headers: t.headers,
        body: JSON.stringify({ model: s.model, messages, stream: true, temperature: o.temperature, max_tokens: o.max_tokens }) });
    } catch (e) {
      if (e && e.name === "AbortError") throw e;
      throw fail("NETWORK", t.via === "direct" && !s.anonymous
        ? "Couldn’t reach the cloud API. Check your internet. If it keeps failing, your browser may be blocking direct calls (CORS): start Xire with run.py and set HF_TOKEN instead."
        : "Couldn’t reach the server. Check the address and that it is running.");
    }
    if (!r.ok) {
      let detail = "";
      try { const j = await r.clone().json(); detail = (j.error && (j.error.message || j.error)) || j.message || ""; } catch (_) { try { detail = await r.text(); } catch (__) {} }
      throw fail("HTTP" + r.status, explainStatus(r.status, typeof detail === "string" ? detail : JSON.stringify(detail)), r.status);
    }
    let out = "";
    const ct = r.headers.get("content-type") || "";
    if (!/event-stream/i.test(ct) || !r.body) {         /* the provider ignored streaming: one JSON answer */
      const j = await r.json();
      const c = j.choices && j.choices[0] && ((j.choices[0].message && j.choices[0].message.content) || j.choices[0].text);
      if (!c) throw fail("EMPTY", "The model returned an empty reply.");
      onText(c); return c;
    }
    const rd = r.body.getReader(), dec = new TextDecoder();
    let buf = "";
    for (;;) {
      const { done, value } = await rd.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      const lines = buf.split(/\r?\n/); buf = lines.pop();
      for (const line of lines) {
        if (!line.startsWith("data:")) continue;           /* ignores ": keep-alive" comments and blank lines */
        const p = line.slice(5).trim();
        if (!p || p === "[DONE]") continue;
        let j; try { j = JSON.parse(p); } catch (e) { continue; }
        if (j.error) throw fail("STREAM", "The provider stopped the reply: " + String(j.error.message || j.error).slice(0, 160));
        const c = j.choices && j.choices[0] && ((j.choices[0].delta && j.choices[0].delta.content) || j.choices[0].text);
        if (c) { out += c; onText(out); }
      }
    }
    if (!out) throw fail("EMPTY", "The model returned an empty reply. Try again or pick another model.");
    return out;
  },

  /* Text for the user when something goes wrong */
  explain(e) {
    if (e && e.cloud) return e.message;
    return "Couldn’t reach the model. Check the connection and the settings in the model menu.";
  },
};

root.XCloud = XCloud;
if (typeof module !== "undefined" && module.exports) module.exports = XCloud;
})(typeof self !== "undefined" ? self : this);
