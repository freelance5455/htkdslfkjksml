/* Xire GGUF runner - pure JavaScript, no external engine.
   Reads a .gguf file, tokenizes, runs the Qwen3 transformer on the CPU, samples tokens.
   Supported weight types: F32, F16, Q2_K, Q3_K, Q6_K (and Q4_K/Q5_K/Q8_0/Q4_0 where marked).
   Supported architecture: qwen3.  Other models fall back to the old engine in the app. */
(function (root) {
"use strict";

/* ---------- half float table ---------- */
const F16 = new Float32Array(65536);
for (let i = 0; i < 65536; i++) {
  const s = (i & 0x8000) ? -1 : 1, e = (i >> 10) & 31, m = i & 1023;
  F16[i] = e === 0 ? s * m * 5.960464477539063e-8 : e === 31 ? (m ? NaN : s * Infinity) : s * (1 + m / 1024) * Math.pow(2, e - 15);
}

/* ---------- GGUF parser ---------- */
const TYPE_INFO = { // ggml type id -> [name, block size (values), bytes per block]
  0: ["F32", 1, 4], 1: ["F16", 1, 2], 2: ["Q4_0", 32, 18], 8: ["Q8_0", 32, 34],
  10: ["Q2_K", 256, 84], 11: ["Q3_K", 256, 110], 12: ["Q4_K", 256, 144], 13: ["Q5_K", 256, 176], 14: ["Q6_K", 256, 210]
};
const SUPPORTED = new Set([0, 1, 2, 8, 10, 11, 12, 13, 14]);

function parseGGUF(u8) {
  const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
  const td = new TextDecoder("utf-8");
  let p = 0;
  const u32 = () => { const v = dv.getUint32(p, true); p += 4; return v; };
  const u64 = () => { const lo = dv.getUint32(p, true), hi = dv.getUint32(p + 4, true); p += 8; return hi * 4294967296 + lo; };
  const str = () => { const n = u64(); const s = td.decode(u8.subarray(p, p + n)); p += n; return s; };
  function val(t) {
    switch (t) {
      case 0: return dv.getUint8(p++);
      case 1: return dv.getInt8(p++);
      case 2: { const v = dv.getUint16(p, true); p += 2; return v; }
      case 3: { const v = dv.getInt16(p, true); p += 2; return v; }
      case 4: return u32();
      case 5: { const v = dv.getInt32(p, true); p += 4; return v; }
      case 6: { const v = dv.getFloat32(p, true); p += 4; return v; }
      case 7: return dv.getUint8(p++) !== 0;
      case 8: return str();
      case 9: { const et = u32(), n = u64(), a = new Array(n); for (let i = 0; i < n; i++) a[i] = val(et); return a; }
      case 10: return u64();
      case 11: { const lo = dv.getUint32(p, true), hi = dv.getInt32(p + 4, true); p += 8; return hi * 4294967296 + lo; }
      case 12: { const v = dv.getFloat64(p, true); p += 8; return v; }
      default: throw new Error("Unknown GGUF value type " + t);
    }
  }
  if (u32() !== 0x46554747) throw new Error("This is not a GGUF file.");
  const version = u32();
  if (version < 2) throw new Error("GGUF version " + version + " is too old.");
  const nT = u64(), nK = u64();
  const kv = {};
  for (let i = 0; i < nK; i++) { const k = str(), t = u32(); kv[k] = val(t); }
  const tensors = {}, infoStart = p;
  for (let i = 0; i < nT; i++) {
    const name = str(), nd = u32(), dims = [];
    for (let d = 0; d < nd; d++) dims.push(u64());
    const type = u32(), off = u64();
    tensors[name] = { name, dims, type, off };
  }
  const align = kv["general.alignment"] || 32;
  const dataStart = Math.ceil(p / align) * align;
  for (const k in tensors) tensors[k].off += dataStart;
  return { kv, tensors, u8, infoStart, nT, nK };
}

/* ---------- dequantization of one row (nb blocks of 256) ---------- */
function dqQ2K(u, off, nb, out) {
  let o = 0;
  for (let b = 0; b < nb; b++) {
    const base = off + b * 84, d = F16[u[base + 80] | (u[base + 81] << 8)], dm = F16[u[base + 82] | (u[base + 83] << 8)];
    let is = 0, q = base + 16;
    for (let n = 0; n < 2; n++) {
      let shift = 0;
      for (let j = 0; j < 4; j++) {
        let s = u[base + is++], dl = d * (s & 15), ml = dm * (s >> 4);
        for (let l = 0; l < 16; l++) out[o++] = dl * ((u[q + l] >> shift) & 3) - ml;
        s = u[base + is++]; dl = d * (s & 15); ml = dm * (s >> 4);
        for (let l = 0; l < 16; l++) out[o++] = dl * ((u[q + l + 16] >> shift) & 3) - ml;
        shift += 2;
      }
      q += 32;
    }
  }
}
const _sc3 = new Int8Array(16), _sc3u = new Uint32Array(_sc3.buffer);
function dqQ3K(u, off, nb, out) {
  let o = 0;
  for (let b = 0; b < nb; b++) {
    const base = off + b * 110, hm = base, q0 = base + 32, sp = base + 96;
    const d = F16[u[base + 108] | (u[base + 109] << 8)];
    const a0 = (u[sp] | (u[sp + 1] << 8) | (u[sp + 2] << 16) | (u[sp + 3] << 24)) >>> 0;
    const a1 = (u[sp + 4] | (u[sp + 5] << 8) | (u[sp + 6] << 16) | (u[sp + 7] << 24)) >>> 0;
    const t = (u[sp + 8] | (u[sp + 9] << 8) | (u[sp + 10] << 16) | (u[sp + 11] << 24)) >>> 0;
    _sc3u[2] = (((a0 >>> 4) & 0x0f0f0f0f) | (((t >>> 4) & 0x03030303) << 4)) >>> 0;
    _sc3u[3] = (((a1 >>> 4) & 0x0f0f0f0f) | (((t >>> 6) & 0x03030303) << 4)) >>> 0;
    _sc3u[0] = (((a0 & 0x0f0f0f0f) | (((t >>> 0) & 0x03030303) << 4))) >>> 0;
    _sc3u[1] = (((a1 & 0x0f0f0f0f) | (((t >>> 2) & 0x03030303) << 4))) >>> 0;
    let is = 0, q = q0, m = 1;
    for (let n = 0; n < 2; n++) {
      let shift = 0;
      for (let j = 0; j < 4; j++) {
        let dl = d * (_sc3[is++] - 32);
        for (let l = 0; l < 16; l++) out[o++] = dl * (((u[q + l] >> shift) & 3) - ((u[hm + l] & m) ? 0 : 4));
        dl = d * (_sc3[is++] - 32);
        for (let l = 0; l < 16; l++) out[o++] = dl * (((u[q + l + 16] >> shift) & 3) - ((u[hm + l + 16] & m) ? 0 : 4));
        shift += 2; m <<= 1;
      }
      q += 32;
    }
  }
}
function dqQ6K(u, off, nb, out) {
  let o = 0;
  for (let b = 0; b < nb; b++) {
    const base = off + b * 210, d = F16[u[base + 208] | (u[base + 209] << 8)];
    let ql = base, qh = base + 128, sc = base + 192;
    for (let n = 0; n < 2; n++) {
      for (let l = 0; l < 32; l++) {
        const is = l >> 4, h = u[qh + l], a = u[ql + l], c = u[ql + l + 32];
        const s0 = u[sc + is] << 24 >> 24, s2 = u[sc + is + 2] << 24 >> 24, s4 = u[sc + is + 4] << 24 >> 24, s6 = u[sc + is + 6] << 24 >> 24;
        out[o + l] = d * s0 * (((a & 15) | (((h) & 3) << 4)) - 32);
        out[o + l + 32] = d * s2 * (((c & 15) | (((h >> 2) & 3) << 4)) - 32);
        out[o + l + 64] = d * s4 * (((a >> 4) | (((h >> 4) & 3) << 4)) - 32);
        out[o + l + 96] = d * s6 * (((c >> 4) | (((h >> 6) & 3) << 4)) - 32);
      }
      o += 128; ql += 64; qh += 32; sc += 8;
    }
  }
}
/* the formats below follow the ggml reference code but are not verified on a real file here */
function dqQ4K(u, off, nb, out) {
  let o = 0;
  for (let b = 0; b < nb; b++) {
    const base = off + b * 144, d = F16[u[base] | (u[base + 1] << 8)], dm = F16[u[base + 2] | (u[base + 3] << 8)];
    const sp = base + 4; let q = base + 16, is = 0;
    for (let j = 0; j < 256; j += 64) {
      let sc, m, sc2, m2;
      if (is < 4) { sc = u[sp + is] & 63; m = u[sp + is + 4] & 63; sc2 = u[sp + is + 1] & 63; m2 = u[sp + is + 5] & 63; }
      else { sc = (u[sp + is + 4] & 15) | ((u[sp + is - 4] >> 6) << 4); m = (u[sp + is + 4] >> 4) | ((u[sp + is] >> 6) << 4);
             sc2 = (u[sp + is + 5] & 15) | ((u[sp + is - 3] >> 6) << 4); m2 = (u[sp + is + 5] >> 4) | ((u[sp + is + 1] >> 6) << 4); }
      const d1 = d * sc, m1 = dm * m, d2 = d * sc2, mm2 = dm * m2;
      for (let l = 0; l < 32; l++) out[o + l] = d1 * (u[q + l] & 15) - m1;
      for (let l = 0; l < 32; l++) out[o + 32 + l] = d2 * (u[q + l] >> 4) - mm2;
      o += 64; q += 32; is += 2;
    }
  }
}
function dqQ5K(u, off, nb, out) {
  let o = 0;
  for (let b = 0; b < nb; b++) {
    const base = off + b * 176, d = F16[u[base] | (u[base + 1] << 8)], dm = F16[u[base + 2] | (u[base + 3] << 8)];
    const sp = base + 4, qh = base + 16; let ql = base + 48, is = 0, u1 = 1, u2 = 2;
    for (let j = 0; j < 256; j += 64) {
      let sc, m, sc2, m2;
      if (is < 4) { sc = u[sp + is] & 63; m = u[sp + is + 4] & 63; sc2 = u[sp + is + 1] & 63; m2 = u[sp + is + 5] & 63; }
      else { sc = (u[sp + is + 4] & 15) | ((u[sp + is - 4] >> 6) << 4); m = (u[sp + is + 4] >> 4) | ((u[sp + is] >> 6) << 4);
             sc2 = (u[sp + is + 5] & 15) | ((u[sp + is - 3] >> 6) << 4); m2 = (u[sp + is + 5] >> 4) | ((u[sp + is + 1] >> 6) << 4); }
      const d1 = d * sc, m1 = dm * m, d2 = d * sc2, mm2 = dm * m2;
      for (let l = 0; l < 32; l++) out[o + l] = d1 * ((u[ql + l] & 15) + ((u[qh + l] & u1) ? 16 : 0)) - m1;
      for (let l = 0; l < 32; l++) out[o + 32 + l] = d2 * ((u[ql + l] >> 4) + ((u[qh + l] & u2) ? 16 : 0)) - mm2;
      o += 64; ql += 32; is += 2; u1 <<= 2; u2 <<= 2;
    }
  }
}
function dqQ8_0(u, off, nb, out) { // nb counts 32-value blocks here
  let o = 0;
  for (let b = 0; b < nb; b++) { const base = off + b * 34, d = F16[u[base] | (u[base + 1] << 8)];
    for (let l = 0; l < 32; l++) out[o++] = d * (u[base + 2 + l] << 24 >> 24); }
}
function dqQ4_0(u, off, nb, out) {
  let o = 0;
  for (let b = 0; b < nb; b++) { const base = off + b * 18, d = F16[u[base] | (u[base + 1] << 8)];
    for (let l = 0; l < 16; l++) { const x = u[base + 2 + l]; out[o + l] = d * ((x & 15) - 8); out[o + l + 16] = d * ((x >> 4) - 8); } o += 32; }
}
function dqF32(u, off, n, out) { const dv = new DataView(u.buffer, u.byteOffset + off, n * 4); for (let i = 0; i < n; i++) out[i] = dv.getFloat32(i * 4, true); }
function dqF16(u, off, n, out) { for (let i = 0; i < n; i++) out[i] = F16[u[off + 2 * i] | (u[off + 2 * i + 1] << 8)]; }

function dequantRow(type, u, off, cols, out) {
  switch (type) {
    case 10: return dqQ2K(u, off, cols >> 8, out);
    case 11: return dqQ3K(u, off, cols >> 8, out);
    case 14: return dqQ6K(u, off, cols >> 8, out);
    case 12: return dqQ4K(u, off, cols >> 8, out);
    case 13: return dqQ5K(u, off, cols >> 8, out);
    case 8: return dqQ8_0(u, off, cols >> 5, out);
    case 2: return dqQ4_0(u, off, cols >> 5, out);
    case 0: return dqF32(u, off, cols, out);
    case 1: return dqF16(u, off, cols, out);
  }
  throw new Error("Unsupported weight type " + type);
}
function rowBytes(type, cols) { const t = TYPE_INFO[type]; return (cols / t[1]) * t[2]; }

/* ---------- matrix * vectors:  Y[t][r] = sum_i W[r][i] * X[t][i] ----------
   Q2_K / Q3_K / Q6_K are computed directly on the packed weights (no float copy of the row). */
function dotQ2K(u, off, nb, X, xo, xs, so) {
  let acc = 0;
  for (let b = 0; b < nb; b++) {
    const base = off + b * 84, d = F16[u[base + 80] | (u[base + 81] << 8)], dm = F16[u[base + 82] | (u[base + 83] << 8)];
    let q = base + 16, xi = xo + b * 256, g = so + b * 16;
    for (let n = 0; n < 2; n++) {
      const sb = base + n * 8;
      for (let half = 0; half < 2; half++) {
        let a0 = 0, a1 = 0, a2 = 0, a3 = 0;
        for (let l = half * 16, e = l + 16; l < e; l++) {
          const by = u[q + l];
          a0 += (by & 3) * X[xi + l]; a1 += ((by >> 2) & 3) * X[xi + 32 + l]; a2 += ((by >> 4) & 3) * X[xi + 64 + l]; a3 += (by >> 6) * X[xi + 96 + l];
        }
        const s0 = u[sb + half], s1 = u[sb + 2 + half], s2 = u[sb + 4 + half], s3 = u[sb + 6 + half];
        acc += d * ((s0 & 15) * a0 + (s1 & 15) * a1 + (s2 & 15) * a2 + (s3 & 15) * a3)
             - dm * ((s0 >> 4) * xs[g + half] + (s1 >> 4) * xs[g + 2 + half] + (s2 >> 4) * xs[g + 4 + half] + (s3 >> 4) * xs[g + 6 + half]);
      }
      q += 32; xi += 128; g += 8;
    }
  }
  return acc;
}
function dotQ3K(u, off, nb, X, xo) {
  let acc = 0;
  for (let b = 0; b < nb; b++) {
    const base = off + b * 110, hm = base, sp = base + 96, d = F16[u[base + 108] | (u[base + 109] << 8)];
    const a0 = (u[sp] | (u[sp + 1] << 8) | (u[sp + 2] << 16) | (u[sp + 3] << 24)) >>> 0;
    const a1 = (u[sp + 4] | (u[sp + 5] << 8) | (u[sp + 6] << 16) | (u[sp + 7] << 24)) >>> 0;
    const t = (u[sp + 8] | (u[sp + 9] << 8) | (u[sp + 10] << 16) | (u[sp + 11] << 24)) >>> 0;
    _sc3u[2] = (((a0 >>> 4) & 0x0f0f0f0f) | (((t >>> 4) & 0x03030303) << 4)) >>> 0;
    _sc3u[3] = (((a1 >>> 4) & 0x0f0f0f0f) | (((t >>> 6) & 0x03030303) << 4)) >>> 0;
    _sc3u[0] = ((a0 & 0x0f0f0f0f) | (((t >>> 0) & 0x03030303) << 4)) >>> 0;
    _sc3u[1] = ((a1 & 0x0f0f0f0f) | (((t >>> 2) & 0x03030303) << 4)) >>> 0;
    let q = base + 32, xi = xo + b * 256;
    for (let n = 0; n < 2; n++) {
      const k0 = n * 4;
      for (let half = 0; half < 2; half++) {
        let c0 = 0, c1 = 0, c2 = 0, c3 = 0;
        for (let l = half * 16, e = l + 16; l < e; l++) {
          const by = u[q + l], h = u[hm + l];
          c0 += ((by & 3) - ((((h >> k0) & 1) ^ 1) << 2)) * X[xi + l];
          c1 += (((by >> 2) & 3) - ((((h >> (k0 + 1)) & 1) ^ 1) << 2)) * X[xi + 32 + l];
          c2 += (((by >> 4) & 3) - ((((h >> (k0 + 2)) & 1) ^ 1) << 2)) * X[xi + 64 + l];
          c3 += ((by >> 6) - ((((h >> (k0 + 3)) & 1) ^ 1) << 2)) * X[xi + 96 + l];
        }
        const si = n * 8 + half;
        acc += d * ((_sc3[si] - 32) * c0 + (_sc3[si + 2] - 32) * c1 + (_sc3[si + 4] - 32) * c2 + (_sc3[si + 6] - 32) * c3);
      }
      q += 32; xi += 128;
    }
  }
  return acc;
}
function dotQ6K(u, off, nb, X, xo) {
  let acc = 0;
  for (let b = 0; b < nb; b++) {
    const base = off + b * 210, d = F16[u[base + 208] | (u[base + 209] << 8)];
    let ql = base, qh = base + 128, sc = base + 192, xi = xo + b * 256, tot = 0;
    for (let n = 0; n < 2; n++) {
      for (let half = 0; half < 2; half++) {
        const s0 = u[sc + half] << 24 >> 24, s2 = u[sc + half + 2] << 24 >> 24, s4 = u[sc + half + 4] << 24 >> 24, s6 = u[sc + half + 6] << 24 >> 24;
        let a0 = 0, a2 = 0, a4 = 0, a6 = 0;
        for (let l = half * 16; l < half * 16 + 16; l++) {
          const h = u[qh + l], a = u[ql + l], c = u[ql + l + 32];
          a0 += (((a & 15) | ((h & 3) << 4)) - 32) * X[xi + l];
          a2 += (((c & 15) | (((h >> 2) & 3) << 4)) - 32) * X[xi + l + 32];
          a4 += (((a >> 4) | (((h >> 4) & 3) << 4)) - 32) * X[xi + l + 64];
          a6 += (((c >> 4) | (((h >> 6) & 3) << 4)) - 32) * X[xi + l + 96];
        }
        tot += s0 * a0 + s2 * a2 + s4 * a4 + s6 * a6;
      }
      xi += 128; ql += 64; qh += 32; sc += 8;
    }
    acc += d * tot;
  }
  return acc;
}
function dotQ8_0(u, off, nb, X, xo) {
  let acc = 0;
  for (let b = 0; b < nb; b++) {
    const base = off + b * 34, d = F16[u[base] | (u[base + 1] << 8)], q = base + 2, xi = xo + b * 32;
    let s0 = 0, s1 = 0, s2 = 0, s3 = 0;
    for (let l = 0; l < 32; l += 4) {
      s0 += (u[q + l] << 24 >> 24) * X[xi + l]; s1 += (u[q + l + 1] << 24 >> 24) * X[xi + l + 1];
      s2 += (u[q + l + 2] << 24 >> 24) * X[xi + l + 2]; s3 += (u[q + l + 3] << 24 >> 24) * X[xi + l + 3];
    }
    acc += d * (s0 + s1 + s2 + s3);
  }
  return acc;
}
let _rowBuf = new Float32Array(4096), _xs = new Float64Array(1);
let _x64 = new Float64Array(1);
function matmul(W, X32, n, Y, u8, r0, r1) {
  const rows = W.rows, cols = W.cols, rb = W.rb, type = W.type, base = W.off, nb = type === 8 ? cols >> 5 : cols >> 8;
  r0 = r0 || 0; if (r1 === undefined) r1 = rows;
  if (type === 10 || type === 11 || type === 14 || type === 8) {
    if (_x64.length < n * cols) _x64 = new Float64Array(n * cols);
    const X = _x64; for (let i = 0, e = n * cols; i < e; i++) X[i] = X32[i];
    let xs = _xs;
    if (type === 10) { // sums of every 16 input values, for the "minus min" part of Q2_K
      const ng = cols >> 4; if (_xs.length < n * ng) _xs = xs = new Float64Array(n * ng);
      for (let t = 0; t < n; t++) for (let g = 0; g < ng; g++) { let s = 0; const o = t * cols + g * 16; for (let i = 0; i < 16; i++) s += X[o + i]; xs[t * ng + g] = s; }
    }
    const ng = cols >> 4;
    for (let r = r0; r < r1; r++) {
      const ro = base + r * rb;
      for (let t = 0; t < n; t++) {
        Y[t * rows + r] = type === 10 ? dotQ2K(u8, ro, nb, X, t * cols, xs, t * ng) : type === 11 ? dotQ3K(u8, ro, nb, X, t * cols) : type === 8 ? dotQ8_0(u8, ro, nb, X, t * cols) : dotQ6K(u8, ro, nb, X, t * cols);
      }
    }
    return;
  }
  if (_rowBuf.length < cols) _rowBuf = new Float32Array(cols);
  const buf = _rowBuf;
  for (let r = r0; r < r1; r++) {
    dequantRow(type, u8, base + r * rb, cols, buf);
    for (let t = 0; t < n; t++) { const xo = t * cols; let s = 0; for (let i = 0; i < cols; i++) s += buf[i] * X32[xo + i]; Y[t * rows + r] = s; }
  }
}

/* ---------- tokenizer (GPT-2 style byte-level BPE, Qwen pre-tokenizer) ---------- */
const BYTE_ENC = [], BYTE_DEC = new Map();
(function () {
  const bs = [], cs = [];
  for (let i = 33; i <= 126; i++) bs.push(i);
  for (let i = 161; i <= 172; i++) bs.push(i);
  for (let i = 174; i <= 255; i++) bs.push(i);
  for (const b of bs) cs.push(b);
  let n = 0;
  for (let b = 0; b < 256; b++) if (!bs.includes(b)) { bs.push(b); cs.push(256 + n); n++; }
  for (let i = 0; i < 256; i++) { const ch = String.fromCharCode(cs[i]); BYTE_ENC[bs[i]] = ch; BYTE_DEC.set(ch, bs[i]); }
})();
const PRE = /(?:'[sS]|'[tT]|'[rR][eE]|'[vV][eE]|'[mM]|'[lL][lL]|'[dD])|[^\r\n\p{L}\p{N}]?\p{L}+|\p{N}| ?[^\s\p{L}\p{N}]+[\r\n]*|\s*[\r\n]+|\s+(?!\S)|\s+/gu;

class Tokenizer {
  constructor(kv) {
    this.tokens = kv["tokenizer.ggml.tokens"];
    if (!this.tokens) throw new Error("This model file has no tokenizer.");
    if (kv["tokenizer.ggml.model"] !== "gpt2") throw new Error("Unsupported tokenizer: " + kv["tokenizer.ggml.model"]);
    this.id = new Map(); this.tokens.forEach((t, i) => this.id.set(t, i));
    this.rank = new Map(); (kv["tokenizer.ggml.merges"] || []).forEach((m, i) => this.rank.set(m, i));
    this.cache = new Map();
    this.eos = kv["tokenizer.ggml.eos_token_id"];
    this.types = kv["tokenizer.ggml.token_type"] || [];
    this.dec = new TextDecoder("utf-8");
  }
  special(name) { const v = this.id.get(name); return v === undefined ? -1 : v; }
  bpe(word) {
    const c = this.cache.get(word); if (c) return c;
    let parts = Array.from(word);
    while (parts.length > 1) {
      let best = Infinity, bi = -1;
      for (let i = 0; i < parts.length - 1; i++) { const r = this.rank.get(parts[i] + " " + parts[i + 1]); if (r !== undefined && r < best) { best = r; bi = i; } }
      if (bi < 0) break;
      parts.splice(bi, 2, parts[bi] + parts[bi + 1]);
    }
    const ids = parts.map(p => { const v = this.id.get(p); return v === undefined ? -1 : v; }).filter(v => v >= 0);
    if (this.cache.size < 20000) this.cache.set(word, ids);
    return ids;
  }
  encode(text) {
    const out = [], enc = new TextEncoder();
    const m = text.match(PRE) || [];
    for (const piece of m) {
      const bytes = enc.encode(piece); let w = "";
      for (let i = 0; i < bytes.length; i++) w += BYTE_ENC[bytes[i]];
      for (const id of this.bpe(w)) out.push(id);
    }
    return out;
  }
  /* bytes of one token (for streaming UTF-8 decoding) */
  bytesOf(id) {
    const t = this.tokens[id]; if (t === undefined || this.types[id] === 3) return new Uint8Array(0);
    const b = new Uint8Array(t.length); let n = 0;
    for (const ch of t) { const v = BYTE_DEC.get(ch); if (v === undefined) { const e = new TextEncoder().encode(ch); const nb = new Uint8Array(n + e.length + t.length); nb.set(b.subarray(0, n)); nb.set(e, n); n += e.length; return nb.subarray(0, n); } b[n++] = v; }
    return b.subarray(0, n);
  }
}

/* ---------- the model ---------- */
class Model {
  constructor(u8, opts) {
    opts = opts || {};
    const g = parseGGUF(u8); this.g = g; this.u8 = u8; const kv = g.kv;
    const arch = kv["general.architecture"];
    if (arch !== "qwen3") { const e = new Error("UNSUPPORTED_ARCH:" + arch); e.code = "UNSUPPORTED_ARCH"; throw e; }
    const P = arch + ".";
    this.nLayer = kv[P + "block_count"]; this.dim = kv[P + "embedding_length"]; this.ffn = kv[P + "feed_forward_length"];
    this.nHead = kv[P + "attention.head_count"]; this.nKV = kv[P + "attention.head_count_kv"];
    this.hd = kv[P + "attention.key_length"] || (this.dim / this.nHead);
    this.eps = kv[P + "attention.layer_norm_rms_epsilon"] || 1e-6; this.base = kv[P + "rope.freq_base"] || 10000;
    this.maxCtx = kv[P + "context_length"] || 4096;
    this.nCtx = Math.min(opts.nCtx || 1024, this.maxCtx);
    this.qDim = this.nHead * this.hd; this.kvDim = this.nKV * this.hd;
    this.tok = new Tokenizer(kv);
    this.vocab = this.tok.tokens.length;
    const T = g.tensors;
    const need = n => { const t = T[n]; if (!t) throw new Error("Model file is missing tensor " + n); if (!SUPPORTED.has(t.type)) { const e = new Error("UNSUPPORTED_TYPE:" + t.type); e.code = "UNSUPPORTED_TYPE"; throw e; } return t; };
    const mat = n => { const t = need(n); const cols = t.dims[0], rows = t.dims[1]; if (cols % (TYPE_INFO[t.type][1]) !== 0 && t.type > 1) throw new Error("Bad shape in " + n); return { type: t.type, cols, rows, off: t.off, rb: rowBytes(t.type, cols) }; };
    const vec = n => { const t = need(n); const len = t.dims[0]; const out = new Float32Array(len); dequantRow(t.type, u8, t.off, len, out); return out; };
    this.embd = mat("token_embd.weight");
    this.outNorm = vec("output_norm.weight");
    this.out = T["output.weight"] ? mat("output.weight") : this.embd; /* tied embeddings */
    this.L = [];
    for (let l = 0; l < this.nLayer; l++) {
      const b = "blk." + l + ".";
      this.L.push({ an: vec(b + "attn_norm.weight"), q: mat(b + "attn_q.weight"), k: mat(b + "attn_k.weight"), v: mat(b + "attn_v.weight"), o: mat(b + "attn_output.weight"),
        qn: vec(b + "attn_q_norm.weight"), kn: vec(b + "attn_k_norm.weight"), fn: vec(b + "ffn_norm.weight"),
        gate: mat(b + "ffn_gate.weight"), up: mat(b + "ffn_up.weight"), down: mat(b + "ffn_down.weight") });
    }
    this.allocKV(this.nCtx);
    /* rope tables (NEOX style: element i pairs with element i + hd/2) */
    const half = this.hd >> 1; this.cos = new Float32Array(this.nCtx * half); this.sin = new Float32Array(this.nCtx * half);
    for (let p = 0; p < this.nCtx; p++) for (let i = 0; i < half; i++) { const a = p * Math.pow(this.base, -2 * i / this.hd); this.cos[p * half + i] = Math.cos(a); this.sin[p * half + i] = Math.sin(a); }
    this.cached = [];
  }
  allocKV(n) {
    this.nCtx = n; this.K = []; this.V = [];
    for (let l = 0; l < this.nLayer; l++) { this.K.push(new Float32Array(n * this.kvDim)); this.V.push(new Float32Array(n * this.kvDim)); }
  }
  rms(x, xo, w, n, eps, out, oo) {
    let s = 0; for (let i = 0; i < n; i++) { const v = x[xo + i]; s += v * v; }
    const k = 1 / Math.sqrt(s / n + eps); for (let i = 0; i < n; i++) out[oo + i] = x[xo + i] * k * w[i];
  }
  /* run n tokens starting at position pos; returns logits of the last token if wantLogits */
  forward(ids, pos, wantLogits) {
    const n = ids.length, D = this.dim, hd = this.hd, nH = this.nHead, nKV = this.nKV, half = hd >> 1, u8 = this.u8;
    const x = new Float32Array(n * D), h = new Float32Array(n * D);
    const q = new Float32Array(n * this.qDim), k = new Float32Array(n * this.kvDim), v = new Float32Array(n * this.kvDim);
    const ao = new Float32Array(n * this.qDim), tmp = new Float32Array(n * D);
    const g = new Float32Array(n * this.ffn), uu = new Float32Array(n * this.ffn);
    const sc = new Float32Array(pos + n), grp = nH / nKV, scale = 1 / Math.sqrt(hd);
    const row = new Float32Array(D);
    for (let t = 0; t < n; t++) { dequantRow(this.embd.type, u8, this.embd.off + ids[t] * this.embd.rb, D, row); x.set(row, t * D); }
    for (let l = 0; l < this.nLayer; l++) {
      const L = this.L[l], Kc = this.K[l], Vc = this.V[l];
      for (let t = 0; t < n; t++) this.rms(x, t * D, L.an, D, this.eps, h, t * D);
      matmul(L.q, h, n, q, u8); matmul(L.k, h, n, k, u8); matmul(L.v, h, n, v, u8);
      for (let t = 0; t < n; t++) {
        const p = pos + t;
        for (let hh = 0; hh < nH; hh++) { const o = t * this.qDim + hh * hd; this.rms(q, o, L.qn, hd, this.eps, q, o); this.rope(q, o, p, half); }
        for (let hh = 0; hh < nKV; hh++) { const o = t * this.kvDim + hh * hd; this.rms(k, o, L.kn, hd, this.eps, k, o); this.rope(k, o, p, half); }
        Kc.set(k.subarray(t * this.kvDim, (t + 1) * this.kvDim), p * this.kvDim);
        Vc.set(v.subarray(t * this.kvDim, (t + 1) * this.kvDim), p * this.kvDim);
        for (let hh = 0; hh < nH; hh++) {
          const qo = t * this.qDim + hh * hd, ko = Math.floor(hh / grp) * hd;
          let mx = -Infinity;
          for (let s = 0; s <= p; s++) {
            const kb = s * this.kvDim + ko; let d = 0;
            for (let i = 0; i < hd; i++) d += q[qo + i] * Kc[kb + i];
            d *= scale; sc[s] = d; if (d > mx) mx = d;
          }
          let sum = 0; for (let s = 0; s <= p; s++) { const e = Math.exp(sc[s] - mx); sc[s] = e; sum += e; }
          const inv = 1 / sum, oo = t * this.qDim + hh * hd;
          for (let i = 0; i < hd; i++) ao[oo + i] = 0;
          for (let s = 0; s <= p; s++) { const w = sc[s] * inv, vb = s * this.kvDim + ko; for (let i = 0; i < hd; i++) ao[oo + i] += w * Vc[vb + i]; }
        }
      }
      matmul(L.o, ao, n, tmp, u8);
      for (let i = 0; i < n * D; i++) x[i] += tmp[i];
      for (let t = 0; t < n; t++) this.rms(x, t * D, L.fn, D, this.eps, h, t * D);
      matmul(L.gate, h, n, g, u8); matmul(L.up, h, n, uu, u8);
      for (let i = 0; i < n * this.ffn; i++) { const a = g[i]; g[i] = (a / (1 + Math.exp(-a))) * uu[i]; }
      matmul(L.down, g, n, tmp, u8);
      for (let i = 0; i < n * D; i++) x[i] += tmp[i];
    }
    if (!wantLogits) return null;
    const last = new Float32Array(D); this.rms(x, (n - 1) * D, this.outNorm, D, this.eps, last, 0);
    const logits = new Float32Array(this.vocab); matmul(this.out, last, 1, logits, u8);
    return logits;
  }
  rope(a, o, p, half) {
    const c = this.cos, s = this.sin, bo = p * half;
    for (let i = 0; i < half; i++) { const x0 = a[o + i], x1 = a[o + i + half]; a[o + i] = x0 * c[bo + i] - x1 * s[bo + i]; a[o + i + half] = x0 * s[bo + i] + x1 * c[bo + i]; }
  }

  /* ---------- chat template + sampling ---------- */
  buildPrompt(messages, maxNew) {
    const T = this.tok, imS = T.special("<|im_start|>"), imE = T.special("<|im_end|>");
    if (imS < 0 || imE < 0) throw new Error("This model has no ChatML tokens.");
    const nl = T.encode("\n"), turn = (role, text) => [imS, ...T.encode(role), ...nl, ...T.encode(text), imE, ...nl];
    const sys = messages.filter(m => m.role === "system"), rest = messages.filter(m => m.role !== "system");
    const budget = this.nCtx - maxNew - 4;
    const sysT = sys.length ? turn("system", sys.map(m => m.content).join("\n")) : [];
    const gen = [imS, ...T.encode("assistant"), ...nl];
    const tS = T.special("<think>"), tE = T.special("</think>");
    if (this.noThink && tS >= 0 && tE >= 0) gen.push(tS, ...T.encode("\n\n"), tE, ...T.encode("\n\n")); /* skip the slow "thinking" part */
    let from = 0, parts = rest.map(m => turn(m.role === "assistant" ? "assistant" : "user", m.content));
    const total = () => sysT.length + parts.slice(from).reduce((a, b) => a + b.length, 0) + gen.length;
    while (total() > budget && from < parts.length - 1) from++;
    let ids = [...sysT, ...parts.slice(from).flat(), ...gen];
    if (ids.length > budget) ids = [...ids.slice(0, Math.min(sysT.length, 64)), ...ids.slice(ids.length - (budget - Math.min(sysT.length, 64)))];
    return ids;
  }
  sample(logits, recent, o) {
    const V = this.vocab;
    if (o.penalty && o.penalty !== 1) for (const id of recent) { const l = logits[id]; logits[id] = l > 0 ? l / o.penalty : l * o.penalty; }
    if (!(o.temp > 0)) { let b = 0; for (let i = 1; i < V; i++) if (logits[i] > logits[b]) b = i; return b; }
    const K = Math.min(o.topK || 40, V), idx = new Int32Array(K), val = new Float32Array(K).fill(-Infinity);
    for (let i = 0; i < V; i++) {
      const l = logits[i]; if (l <= val[K - 1]) continue;
      let j = K - 1; while (j > 0 && val[j - 1] < l) { val[j] = val[j - 1]; idx[j] = idx[j - 1]; j--; } val[j] = l; idx[j] = i;
    }
    const mx = val[0], pr = new Float32Array(K); let sum = 0;
    for (let i = 0; i < K; i++) { pr[i] = Math.exp((val[i] - mx) / o.temp); sum += pr[i]; }
    let cut = K, acc = 0; const tp = o.topP || 0.9;
    for (let i = 0; i < K; i++) { acc += pr[i] / sum; if (acc >= tp) { cut = i + 1; break; } }
    let s2 = 0; for (let i = 0; i < cut; i++) s2 += pr[i];
    let r = Math.random() * s2; for (let i = 0; i < cut; i++) { r -= pr[i]; if (r <= 0) return idx[i]; }
    return idx[0];
  }
  /* read the system prompt ahead of time so the first question is faster */
  async warm(sysText, yieldFn) {
    const T = this.tok, imS = T.special("<|im_start|>"), imE = T.special("<|im_end|>"), nl = T.encode("\n");
    const ids = [imS, ...T.encode("system"), ...nl, ...T.encode(sysText), imE, ...nl];
    if (this.cached.length) return;
    for (let i = 0; i < ids.length; i += 16) { const e = Math.min(i + 16, ids.length); await this.forward(ids.slice(i, e), i, false); for (let j = i; j < e; j++) this.cached.push(ids[j]); await yieldFn(); }
  }
  /* async generator-like: calls onText(fullText) as it goes. yieldFn lets the host process abort messages. */
  async generate(messages, o, onText, shouldStop, yieldFn, onStatus) {
    const max = Math.max(1, Math.min(o.max || 512, this.nCtx - 32));
    const prompt = this.buildPrompt(messages, max);
    let common = 0; const c = this.cached, m = Math.min(c.length, prompt.length - 1);
    while (common < m && c[common] === prompt[common]) common++;
    this.cached = prompt.slice(0, common);
    let pos = common, logits = null, i = common;
    const CH = 24;
    while (i < prompt.length) {
      if (shouldStop()) throw Object.assign(new Error("aborted"), { name: "AbortError" });
      const end = Math.min(i + CH, prompt.length), last = end === prompt.length;
      logits = await this.forward(prompt.slice(i, end), i, last);
      for (let j = i; j < end; j++) this.cached.push(prompt[j]);
      i = end; pos = end;
      if (onStatus) onStatus("Reading prompt… " + Math.round(i / prompt.length * 100) + "%");
      await yieldFn();
    }
    const T = this.tok, imE = T.special("<|im_end|>"), eot = T.special("<|endoftext|>");
    const dec = new TextDecoder("utf-8"); let text = "", recent = prompt.slice(-64);
    for (let n = 0; n < max; n++) {
      if (shouldStop()) throw Object.assign(new Error("aborted"), { name: "AbortError" });
      const id = this.sample(logits, recent, o);
      if (id === imE || id === eot || id === T.eos) break;
      text += dec.decode(T.bytesOf(id), { stream: true }); onText(text);
      recent.push(id); if (recent.length > 64) recent.shift();
      if (pos >= this.nCtx - 1) break;
      logits = await this.forward([id], pos, true); this.cached.push(id); pos++;
      await yieldFn();
    }
    text += dec.decode(); onText(text);
    return text;
  }
}


/* Build a tiny WebAssembly SIMD kernel:  r(w, rb, nb, x, out, nRows)
   out[i] = sum over nb Q8_0 blocks of  half(d) * sum_j int8[j] * x[j]   for each of nRows rows (row stride rb bytes). */
function buildQ8Wasm() {
  const leb = (v, signed) => { const o = []; for (;;) { let b = v & 0x7f; v = signed ? v >> 7 : v >>> 7; if (signed ? !((v === 0 && !(b & 0x40)) || (v === -1 && (b & 0x40))) : v !== 0) o.push(b | 0x80); else { o.push(b); break; } } return o; };
  const ul = v => leb(v, false), sl = v => leb(v, true);
  const LG = i => [0x20, ...ul(i)], LS = i => [0x21, ...ul(i)], LT = i => [0x22, ...ul(i)];
  const C = v => [0x41, ...sl(v)];
  const VL = (base, off) => [...LG(base), 0xfd, 0x00, 0x00, ...ul(off)];       // v128.load base+off
  const S = (op) => [0xfd, ...ul(op)];
  const cvt = (lowHi8, lowHi16) => [...S(lowHi8 ? 0x88 : 0x87), ...S(lowHi16 ? 0xa8 : 0xa7), ...S(0xfa)];   // i8x16 -> f32x4
  const W = 0, RB = 1, NB = 2, X = 3, OUT = 4, NR = 5, B = 6, H = 7, BITS = 8, R = 9, WP = 10, XP = 11, D = 12, ACC = 13, SUM = 14, A = 15;
  const chunk = (wOff, xOff) => [
    ...VL(WP, wOff), ...LS(A),
    ...[[0, 0], [0, 1], [1, 0], [1, 1]].flatMap(([h8, h16], k) => [...LG(A), ...cvt(h8, h16), ...VL(XP, xOff + 16 * k), ...S(0xe6), ...(k ? [...S(0xe4)] : [])]),
  ];
  const body = [];
  const emit = (...a) => a.forEach(x => body.push(...x));
  emit(C(0), LS(R));
  emit([0x02, 0x40]);                                   // block $done
  emit([0x03, 0x40]);                                   // loop $rows
  emit(LG(R), LG(NR), [0x4f], [0x0d, 0x01]);            // br_if $done if r >= nRows (i32.ge_u)
  emit(LG(W), LG(R), LG(RB), [0x6c], [0x6a], LS(WP));   // wp = w + r*rb
  emit(LG(X), LS(XP));
  emit([0xfd, 0x0c, ...new Array(16).fill(0)], LS(ACC)); // acc = 0
  emit(LG(NB), LS(B));
  emit([0x03, 0x40]);                                   // loop $blk
  emit(LG(WP), [0x2f, 0x01, 0x00], LS(H));              // h = u16[wp]
  emit(LG(H), C(0x8000), [0x71], C(16), [0x74],         //   sign
       LG(H), C(0x7fff), [0x71], C(13), [0x74], C(0x38000000), [0x6a], [0x72],
       C(0), LG(H), C(0x7c00), [0x71], [0x1b], [0xbe], LS(D)); // d = select(bits, 0, h&0x7c00) as f32
  emit(chunk(2, 0), chunk(18, 64) , );
  // chunk() leaves one v128 on the stack each; they must be summed and scaled
  emit(S(0xe4), LG(D), S(0x13), S(0xe6), LG(ACC), S(0xe4), LS(ACC)); // acc += (s1+s2) * d
  emit(LG(WP), C(34), [0x6a], LS(WP), LG(XP), C(128), [0x6a], LS(XP));
  emit(LG(B), C(1), [0x6b], LT(B), [0x0d, 0x00]);       // b -= 1; br_if $blk (b != 0)
  emit([0x0b]);                                         // end loop $blk
  emit(LG(OUT), LG(R), C(2), [0x74], [0x6a]);           // address of out[r]
  emit(LG(ACC), S(0x1f), [0], LG(ACC), S(0x1f), [1], [0x92], LG(ACC), S(0x1f), [2], [0x92], LG(ACC), S(0x1f), [3], [0x92]);
  emit([0x38, 0x02, 0x00]);                             // f32.store
  emit(LG(R), C(1), [0x6a], LS(R), [0x0c, 0x00]);       // r++; br $rows
  emit([0x0b], [0x0b], [0x0b]);                         // end loop, end block, end func
  const locals = [3, 6, 0x7f, 1, 0x7d, 3, 0x7b];       // 3 groups: 6 x i32, 1 x f32, 3 x v128
  const code = [...ul(3).slice(0, 1), 6, 0x7f, 1, 0x7d, 3, 0x7b, ...body];
  const sec = (id, bytes) => [id, ...ul(bytes.length), ...bytes];
  const bytes = [0, 0x61, 0x73, 0x6d, 1, 0, 0, 0,
    ...sec(1, [1, 0x60, 6, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0]),
    ...sec(2, [1, 1, 0x65, 1, 0x6d, 2, 0, 1]),
    ...sec(3, [1, 0]),
    ...sec(7, [1, 1, 0x72, 0, 0]),
    ...sec(10, [1, ...ul(code.length), ...code]),
  ];
  return new Uint8Array(bytes);
}
let WASM_MOD = null;
function q8Module() {
  if (WASM_MOD !== null) return WASM_MOD || null;
  try { if (typeof WebAssembly === "object") { const b = buildQ8Wasm(); if (WebAssembly.validate(b)) { WASM_MOD = new WebAssembly.Module(b); return WASM_MOD; } } } catch (e) {}
  WASM_MOD = false; return null;
}

/* =====================  multi-thread version  =====================
   Every weight matrix is cut into row slices. Thread k keeps only slice k (so memory is not duplicated)
   and the "main" worker runs attention, norms and sampling and asks the others for matrix products. */
const rowRange = (rows, k, N) => [Math.floor(rows * k / N), Math.floor(rows * (k + 1) / N)];
function readConfig(kv, opts) {
  const arch = kv["general.architecture"];
  if (arch !== "qwen3") { const e = new Error("UNSUPPORTED_ARCH:" + arch); e.code = "UNSUPPORTED_ARCH"; throw e; }
  const P = arch + ".", c = { nLayer: kv[P + "block_count"], dim: kv[P + "embedding_length"], ffn: kv[P + "feed_forward_length"], nHead: kv[P + "attention.head_count"], nKV: kv[P + "attention.head_count_kv"] };
  c.hd = kv[P + "attention.key_length"] || (c.dim / c.nHead);
  c.eps = kv[P + "attention.layer_norm_rms_epsilon"] || 1e-6; c.base = kv[P + "rope.freq_base"] || 10000;
  c.maxCtx = kv[P + "context_length"] || 4096; c.nCtx = Math.min((opts && opts.nCtx) || 1024, c.maxCtx);
  c.qDim = c.nHead * c.hd; c.kvDim = c.nKV * c.hd;
  return c;
}
const f32h = new Float32Array(1), i32h = new Int32Array(f32h.buffer);
function toHalf(v) {
  f32h[0] = v; const x = i32h[0], sign = (x >>> 16) & 0x8000; let e = ((x >>> 23) & 0xff) - 127 + 15, m = x & 0x7fffff;
  if (e <= 0) { if (e < -10) return sign; m = (m | 0x800000) >> (1 - e); return sign | ((m + 0x1000) >> 13); }
  if (e >= 31) return sign | 0x7c00;
  let r = sign | (e << 10) | (m >> 13); if (m & 0x1000) r++; return r;
}
/* float row -> Q8_0 blocks written into buf at off */
function quantQ8Row(row, cols, buf, off) {
  for (let b = 0, nb = cols >> 5; b < nb; b++) {
    const o = b * 32; let am = 0;
    for (let l = 0; l < 32; l++) { const a = Math.abs(row[o + l]); if (a > am) am = a; }
    const d = am / 127, id = d ? 1 / d : 0, h = toHalf(d), p = off + b * 34;
    buf[p] = h & 255; buf[p + 1] = h >> 8;
    for (let l = 0; l < 32; l++) { let q = Math.round(row[o + l] * id); q = q > 127 ? 127 : q < -127 ? -127 : q; buf[p + 2 + l] = q & 255; }
  }
}
const REPACK = new Set([2, 10, 11, 12, 13, 14]);   /* weight types that are converted to Q8_0 when the SIMD kernel is available */
class Slices {
  constructor() { this.mats = new Map(); this.u8 = null; this.wasm = null; this.mem = null; }
  async load(file, table, k, N, progress) {
    const simd = !!q8Module();
    let total = 0; const plan = [];
    for (const t of table) {
      const rbS = rowBytes(t.type, t.cols), r = rowRange(t.rows, k, N), rep = simd && REPACK.has(t.type) && t.cols % 32 === 0;
      const tt = rep ? 8 : t.type, rb = rep ? (t.cols >> 5) * 34 : rbS;
      plan.push({ t, rbS, rb, tt, rep, r0: r[0], r1: r[1], loc: total }); total += (r[1] - r[0]) * rb;
    }
    let buf = null, done = 0;
    if (simd && plan.some(p => p.tt === 8)) {           /* Q8_0 weights live in WebAssembly memory so the SIMD kernel can read them */
      try {
        const SCR = 3 * 1024 * 1024, mem = new WebAssembly.Memory({ initial: Math.ceil((total + SCR) / 65536) });
        const inst = new WebAssembly.Instance(q8Module(), { e: { m: mem } });
        buf = new Uint8Array(mem.buffer, 0, total); this.mem = mem; this.wasm = inst.exports.r; this.xp = Math.ceil(total / 16) * 16; this.op = this.xp + 1024 * 1024;
      } catch (e) { buf = null; this.wasm = null; this.mem = null; }
    }
    if (!this.wasm) { /* no SIMD kernel (or no memory for it): plan again with the original weight types */
      total = 0; for (const p of plan) { p.rb = p.rbS; p.tt = p.t.type; p.rep = false; p.loc = total; total += (p.r1 - p.r0) * p.rb; }
      buf = new Uint8Array(total);
    }
    const rowBuf = new Float32Array(Math.max(...table.map(t => t.cols)));
    for (const p of plan) {
      if (p.r1 > p.r0) {
        const ab = new Uint8Array(await file.slice(p.t.off + p.r0 * p.rbS, p.t.off + p.r1 * p.rbS).arrayBuffer());
        if (p.rep) { for (let r = 0, n = p.r1 - p.r0; r < n; r++) { dequantRow(p.t.type, ab, r * p.rbS, p.t.cols, rowBuf); quantQ8Row(rowBuf, p.t.cols, buf, p.loc + r * p.rb); } }
        else buf.set(ab, p.loc);
      }
      this.mats.set(p.t.name, { type: p.tt, cols: p.t.cols, rows: p.r1 - p.r0, off: p.loc, rb: p.rb, r0: p.r0, r1: p.r1 });
      if (progress && (++done % 6 === 0)) progress(done / plan.length);
    }
    this.u8 = buf;
  }
  mm(names, X, n) {
    const outs = [];
    for (const nm of names) {
      const M = this.mats.get(nm), Y = new Float32Array(n * M.rows);
      if (this.wasm && M.type === 8 && n * M.cols <= 262144 && n * M.rows <= 524288) {
        new Float32Array(this.mem.buffer, this.xp, n * M.cols).set(X);
        for (let t = 0; t < n; t++) this.wasm(M.off, M.rb, M.cols >> 5, this.xp + t * M.cols * 4, this.op + t * M.rows * 4, M.rows);
        Y.set(new Float32Array(this.mem.buffer, this.op, n * M.rows));
      } else matmul(M, X, n, Y, this.u8);
      outs.push(Y);
    }
    return outs;
  }
  emb(name, ids) {
    const M = this.mats.get(name), out = new Float32Array(ids.length * M.cols), row = new Float32Array(M.cols);
    for (let i = 0; i < ids.length; i++) { dequantRow(M.type, this.u8, M.off + (ids[i] - M.r0) * M.rb, M.cols, row); out.set(row, i * M.cols); }
    return out;
  }
}
function makeComputeHandler(post) {
  const S = new Slices();
  return async d => {
    try {
      if (d.op === "init") { await S.load(d.file, d.table, d.k, d.N); post({ id: d.id, ok: 1 }); }
      else if (d.op === "mm") { const outs = S.mm(d.names, d.X, d.n); post({ id: d.id, outs }, outs.map(o => o.buffer)); }
      else if (d.op === "emb") { const o = S.emb(d.name, d.ids); post({ id: d.id, out: o }, [o.buffer]); }
    } catch (e) { post({ id: d.id, err: String((e && e.message) || e) }); }
  };
}
class Remote {
  constructor(port) {
    this.port = port; this.seq = 0; this.pend = new Map();
    port.addEventListener("message", e => { const d = e.data, p = this.pend.get(d.id); if (!p) return; this.pend.delete(d.id); d.err ? p.no(new Error(d.err)) : p.ok(d); });
    if (port.start) port.start();
  }
  call(msg) { return new Promise((ok, no) => { const id = ++this.seq; this.pend.set(id, { ok, no }); this.port.postMessage(Object.assign({ id }, msg)); }); }
}
class ParModel {
  static async create(file, ports, opts, status) {
    const m = new ParModel(); status = status || (() => {});
    const magic = new TextDecoder().decode(await file.slice(0, 4).arrayBuffer());
    if (magic !== "GGUF") throw new Error("This is not a GGUF file.");
    let size = Math.min(file.size, 16 * 1024 * 1024), g = null;
    for (;;) {
      const u8 = new Uint8Array(await file.slice(0, size).arrayBuffer());
      try { g = parseGGUF(u8); break; }
      catch (e) { if (!(e instanceof RangeError) || size >= file.size || size >= 256 * 1024 * 1024) throw e; size = Math.min(file.size, size * 2); }
    }
    const kv = g.kv, T = g.tensors; Object.assign(m, readConfig(kv, opts));
    m.tok = new Tokenizer(kv); m.vocab = m.tok.tokens.length;
    const need = n => { const t = T[n]; if (!t) throw new Error("Model file is missing tensor " + n); if (!SUPPORTED.has(t.type)) { const e = new Error("UNSUPPORTED_TYPE:" + t.type); e.code = "UNSUPPORTED_TYPE"; throw e; } return t; };
    const table = [], add = n => { const t = need(n); table.push({ name: n, type: t.type, cols: t.dims[0], rows: t.dims[1], off: t.off }); };
    add("token_embd.weight"); m.outName = T["output.weight"] ? "output.weight" : "token_embd.weight"; if (m.outName !== "token_embd.weight") add(m.outName);
    for (let l = 0; l < m.nLayer; l++) for (const w of ["attn_q", "attn_k", "attn_v", "attn_output", "ffn_gate", "ffn_up", "ffn_down"]) add("blk." + l + "." + w + ".weight");
    m.meta = new Map(table.map(t => [t.name, t]));
    const vec = async n => { const t = need(n), len = t.dims[0]; const ab = await file.slice(t.off, t.off + rowBytes(t.type, len)).arrayBuffer(); const out = new Float32Array(len); dequantRow(t.type, new Uint8Array(ab), 0, len, out); return out; };
    m.outNorm = await vec("output_norm.weight"); m.L = [];
    for (let l = 0; l < m.nLayer; l++) { const b = "blk." + l + "."; m.L.push({ an: await vec(b + "attn_norm.weight"), qn: await vec(b + "attn_q_norm.weight"), kn: await vec(b + "attn_k_norm.weight"), fn: await vec(b + "ffn_norm.weight") }); }
    m.remotes = ports.map(p => new Remote(p)); m.N = 1 + m.remotes.length; m.local = new Slices();
    status("Loading model into memory…");
    await Promise.all([...m.remotes.map((r, i) => r.call({ op: "init", file, table, k: i + 1, N: m.N })),
      m.local.load(file, table, 0, m.N, f => status("Loading model into memory… " + Math.round(f * 100) + "%"))]);
    const half = m.hd >> 1;
    for (let n = m.nCtx; ; n = n >> 1) {
      try { m.allocKV(n); break; } catch (e) { if (n <= 128) throw e; }
    }
    m.cos = new Float32Array(m.nCtx * half); m.sin = new Float32Array(m.nCtx * half);
    for (let p = 0; p < m.nCtx; p++) for (let i = 0; i < half; i++) { const a = p * Math.pow(m.base, -2 * i / m.hd); m.cos[p * half + i] = Math.cos(a); m.sin[p * half + i] = Math.sin(a); }
    m.cached = []; return m;
  }
  async mm(names, X, n) {
    const calls = this.remotes.map(r => r.call({ op: "mm", names, X, n }));
    const own = this.local.mm(names, X, n), rest = await Promise.all(calls), res = [];
    names.forEach((nm, i) => {
      const rows = this.meta.get(nm).rows, Y = new Float32Array(n * rows);
      const place = (k, arr) => { const r = rowRange(rows, k, this.N), w = r[1] - r[0]; for (let t = 0; t < n; t++) Y.set(arr.subarray(t * w, (t + 1) * w), t * rows + r[0]); };
      place(0, own[i]); rest.forEach((d, j) => place(j + 1, d.outs[i])); res.push(Y);
    });
    return res;
  }
  async embed(ids) {
    const name = "token_embd.weight", rows = this.meta.get(name).rows, D = this.dim, x = new Float32Array(ids.length * D), groups = new Map();
    ids.forEach((id, i) => { let k = 0; while (k < this.N - 1 && id >= rowRange(rows, k + 1, this.N)[0]) k++; if (!groups.has(k)) groups.set(k, []); groups.get(k).push(i); });
    await Promise.all([...groups].map(async ([k, idxs]) => {
      const sub = idxs.map(i => ids[i]);
      const out = k === 0 ? this.local.emb(name, sub) : (await this.remotes[k - 1].call({ op: "emb", name, ids: sub })).out;
      idxs.forEach((i, j) => x.set(out.subarray(j * D, (j + 1) * D), i * D));
    }));
    return x;
  }
  async forward(ids, pos, wantLogits) {
    const n = ids.length, D = this.dim, hd = this.hd, nH = this.nHead, nKV = this.nKV, half = hd >> 1;
    const x = await this.embed(ids), h = new Float32Array(n * D), ao = new Float32Array(n * this.qDim);
    const sc = new Float32Array(pos + n), grp = nH / nKV, scale = 1 / Math.sqrt(hd);
    for (let l = 0; l < this.nLayer; l++) {
      const L = this.L[l], Kc = this.K[l], Vc = this.V[l], b = "blk." + l + ".";
      for (let t = 0; t < n; t++) this.rms(x, t * D, L.an, D, this.eps, h, t * D);
      const [q, k, v] = await this.mm([b + "attn_q.weight", b + "attn_k.weight", b + "attn_v.weight"], h, n);
      for (let t = 0; t < n; t++) {
        const p = pos + t;
        for (let hh = 0; hh < nH; hh++) { const o = t * this.qDim + hh * hd; this.rms(q, o, L.qn, hd, this.eps, q, o); this.rope(q, o, p, half); }
        for (let hh = 0; hh < nKV; hh++) { const o = t * this.kvDim + hh * hd; this.rms(k, o, L.kn, hd, this.eps, k, o); this.rope(k, o, p, half); }
        Kc.set(k.subarray(t * this.kvDim, (t + 1) * this.kvDim), p * this.kvDim);
        Vc.set(v.subarray(t * this.kvDim, (t + 1) * this.kvDim), p * this.kvDim);
        for (let hh = 0; hh < nH; hh++) {
          const qo = t * this.qDim + hh * hd, ko = Math.floor(hh / grp) * hd; let mx = -Infinity;
          for (let s = 0; s <= p; s++) { const kb = s * this.kvDim + ko; let d = 0; for (let i = 0; i < hd; i++) d += q[qo + i] * Kc[kb + i]; d *= scale; sc[s] = d; if (d > mx) mx = d; }
          let sum = 0; for (let s = 0; s <= p; s++) { const e = Math.exp(sc[s] - mx); sc[s] = e; sum += e; }
          const inv = 1 / sum, oo = t * this.qDim + hh * hd;
          for (let i = 0; i < hd; i++) ao[oo + i] = 0;
          for (let s = 0; s <= p; s++) { const w = sc[s] * inv, vb = s * this.kvDim + ko; for (let i = 0; i < hd; i++) ao[oo + i] += w * Vc[vb + i]; }
        }
      }
      const [o] = await this.mm([b + "attn_output.weight"], ao, n);
      for (let i = 0; i < n * D; i++) x[i] += o[i];
      for (let t = 0; t < n; t++) this.rms(x, t * D, L.fn, D, this.eps, h, t * D);
      const [g, u] = await this.mm([b + "ffn_gate.weight", b + "ffn_up.weight"], h, n);
      for (let i = 0; i < g.length; i++) { const a = g[i]; g[i] = (a / (1 + Math.exp(-a))) * u[i]; }
      const [dn] = await this.mm([b + "ffn_down.weight"], g, n);
      for (let i = 0; i < n * D; i++) x[i] += dn[i];
    }
    if (!wantLogits) return null;
    const last = new Float32Array(D); this.rms(x, (n - 1) * D, this.outNorm, D, this.eps, last, 0);
    return (await this.mm([this.outName], last, 1))[0];
  }
  allocKV(n) { this.nCtx = n; this.K = []; this.V = []; for (let l = 0; l < this.nLayer; l++) { this.K.push(new Float32Array(n * this.kvDim)); this.V.push(new Float32Array(n * this.kvDim)); } }
}
for (const nm of ["rms", "rope", "buildPrompt", "sample", "generate", "warm"]) ParModel.prototype[nm] = Model.prototype[nm];

/* ---------- message handler (runs inside a Web Worker, or in the page as a fallback) ---------- */
function makeHandler(post) {
  let model = null, stop = false, chain = Promise.resolve();
  const yieldFn = () => new Promise(r => setTimeout(r, 0));
  async function work(d) {
    if (d.type === "load") {
      try {
        post({ type: "status", text: "Reading model file…" });
        model = await ParModel.create(d.file, d.ports || [], { nCtx: d.nCtx || 1024 }, t => post({ type: "status", text: t }));
        model.noThink = d.noThink !== false;
        post({ type: "ready", nCtx: model.nCtx, threads: model.N });
        if (d.warm) { try { await model.warm(d.warm, yieldFn); } catch (e) {} }
      } catch (e) { post({ type: "error", id: "load", code: e && e.code, message: String((e && e.message) || e) }); }
    } else if (d.type === "gen") {
      stop = false;
      try {
        await model.generate(d.messages, d.opts, t => post({ type: "text", id: d.id, text: t }), () => stop, yieldFn, s => post({ type: "status", id: d.id, text: s }));
        post({ type: "done", id: d.id });
      } catch (e) { post({ type: "error", id: d.id, name: e && e.name, message: String((e && e.message) || e) }); }
    }
  }
  return d => { if (d.type === "stop") { stop = true; return; } if (d.type === "ping") { post({ type: "pong" }); return; } chain = chain.then(() => work(d)); };
}

const api = { parseGGUF, Model, ParModel, Tokenizer, TYPE_INFO, SUPPORTED, dequantRow, makeHandler, makeComputeHandler, matmul };
if (typeof module !== "undefined" && module.exports) module.exports = api; else root.XireGGUF = api;
})(typeof self !== "undefined" ? self : this);

