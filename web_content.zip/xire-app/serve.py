#!/usr/bin/env python3
"""Xire AI - local web server (Python, no extra packages).

    python3 serve.py [port]          or:   python3 run.py   (checks everything first, opens the browser)

What it does
  * serves the app files
  * GET  /api/models                  lists every .gguf in ./models/ and next to index.html
  * GET  /api/cloud/status            tells the page whether a Hugging Face token is set on this server
  * POST /api/cloud/v1/chat/completions
        forwards the chat request to the cloud API and adds  Authorization: Bearer $HF_TOKEN
        so the token never reaches the browser. Streaming (SSE) is passed straight through.

Settings (environment variables, or a .env file next to this script)
  HF_TOKEN          your Hugging Face token (permission: "Make calls to Inference Providers")
  XIRE_UPSTREAM     API base address         default https://router.huggingface.co/v1
  XIRE_MODEL        default model name       default Qwen/Qwen2.5-0.5B-Instruct:featherless-ai
  XIRE_ALLOW_LAN=1  also let other devices on your Wi-Fi use the token (off by default)
"""
import http.server, json, os, socket, socketserver, sys, urllib.error, urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
os.chdir(HERE)


def load_env():
    p = os.path.join(HERE, ".env")
    if not os.path.isfile(p):
        return
    for line in open(p, encoding="utf-8", errors="ignore"):
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        k, v = k.strip(), v.strip().strip('"').strip("'")
        if k and k not in os.environ:       # real environment variables win over the file
            os.environ[k] = v


load_env()
UPSTREAM_DEFAULT = "https://router.huggingface.co/v1"
MODEL_DEFAULT = "Qwen/Qwen2.5-0.5B-Instruct:featherless-ai"
MAX_BODY = 2 * 1024 * 1024
LOOPBACK = ("127.0.0.1", "::1", "::ffff:127.0.0.1")


def cfg():
    return {
        "token": os.environ.get("HF_TOKEN", "").strip(),
        "upstream": os.environ.get("XIRE_UPSTREAM", UPSTREAM_DEFAULT).rstrip("/"),
        "model": os.environ.get("XIRE_MODEL", MODEL_DEFAULT),
        "lan": os.environ.get("XIRE_ALLOW_LAN", "") in ("1", "true", "yes"),
    }


def list_models():
    found = []
    md = os.path.join(HERE, "models")
    if os.path.isdir(md):
        for n in sorted(os.listdir(md)):
            if n.lower().endswith(".gguf"):
                found.append({"name": n, "url": "models/" + n, "size": os.path.getsize(os.path.join(md, n))})
    for n in sorted(os.listdir(HERE)):
        if n.lower().endswith(".gguf"):
            found.append({"name": n, "url": n, "size": os.path.getsize(os.path.join(HERE, n))})
    return found


class Handler(http.server.SimpleHTTPRequestHandler):
    extensions_map = {**http.server.SimpleHTTPRequestHandler.extensions_map,
                      ".wasm": "application/wasm", ".js": "text/javascript", ".mjs": "text/javascript",
                      ".gguf": "application/octet-stream", ".json": "application/json",
                      ".webmanifest": "application/manifest+json", ".css": "text/css"}

    # ---- helpers -------------------------------------------------------
    def end_headers(self):
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Cross-Origin-Opener-Policy", "same-origin")
        self.send_header("Cross-Origin-Embedder-Policy", "credentialless")
        self.send_header("Cross-Origin-Resource-Policy", "same-origin")
        super().end_headers()

    def is_local(self):
        return self.client_address[0] in LOOPBACK

    def send_json(self, code, obj):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def err(self, code, msg):
        self.send_json(code, {"error": {"message": msg}})

    def token_allowed(self):
        c = cfg()
        return bool(c["token"]) and (self.is_local() or c["lan"])

    # ---- routes --------------------------------------------------------
    def do_GET(self):
        path = self.path.split("?")[0]
        if path == "/api/models":
            return self.send_json(200, list_models())
        if path == "/api/cloud/status":
            c = cfg()
            return self.send_json(200, {"proxy": True, "hasToken": self.token_allowed(), "model": c["model"]})
        super().do_GET()

    def do_POST(self):
        path = self.path.split("?")[0]
        if path != "/api/cloud/v1/chat/completions":
            return self.err(404, "Not found")
        c = cfg()
        if not c["token"]:
            return self.err(401, "No HF_TOKEN is set on the Xire server. Set it and restart, or type a token in the app.")
        if not self.token_allowed():
            return self.err(403, "The cloud proxy only answers on this computer. Type your own token in the app instead.")
        try:
            n = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            n = 0
        if n <= 0 or n > MAX_BODY:
            return self.err(413 if n > MAX_BODY else 400, "Bad request size")
        try:
            req = json.loads(self.rfile.read(n))
            msgs = req["messages"]
            assert isinstance(msgs, list) and msgs
        except Exception:
            return self.err(400, "Body must be JSON with a messages list")
        body = {
            "model": str(req.get("model") or c["model"])[:200],
            "messages": msgs,
            "stream": bool(req.get("stream", True)),
            "temperature": req.get("temperature", 0.7),
            "max_tokens": min(int(req.get("max_tokens") or 512), 4096),
        }
        up = urllib.request.Request(
            c["upstream"] + "/chat/completions", data=json.dumps(body).encode(), method="POST",
            headers={"Content-Type": "application/json", "Authorization": "Bearer " + c["token"],
                     "Accept": "text/event-stream" if body["stream"] else "application/json",
                     "User-Agent": "xire-ai/1.0"})
        try:
            resp = urllib.request.urlopen(up, timeout=120)
        except urllib.error.HTTPError as e:           # forward the provider's error (it never contains our token)
            data = e.read()[:4000]
            self.send_response(e.code)
            self.send_header("Content-Type", e.headers.get("Content-Type", "application/json"))
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return
        except Exception as e:
            return self.err(502, "Could not reach the cloud API: " + str(getattr(e, "reason", e))[:160])
        with resp:
            self.send_response(resp.status)
            self.send_header("Content-Type", resp.headers.get("Content-Type", "application/json"))
            self.send_header("X-Accel-Buffering", "no")
            self.end_headers()
            try:
                while True:
                    chunk = resp.read1(4096) if hasattr(resp, "read1") else resp.read(4096)
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    self.wfile.flush()
            except (BrokenPipeError, ConnectionResetError):
                pass                                    # the page pressed Stop

    def log_message(self, fmt, *args):
        line = args[0] if args else ""
        if "/api/models" in line or "/api/cloud/status" in line:
            return
        super().log_message(fmt, *args)


def lan_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return None


class Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


def serve(port=8000, quiet=False):
    with Server(("", port), Handler) as httpd:
        if not quiet:
            c = cfg()
            print(f"\n  Xire AI is running\n  this computer : http://localhost:{port}")
            ip = lan_ip()
            if ip:
                print(f"  same Wi-Fi    : http://{ip}:{port}")
            print("  cloud model   : " + ("token found, ready (" + c["model"] + ")" if c["token"] else "no HF_TOKEN set (you can still type a token in the app)"))
            print("\n  Press Ctrl+C to stop.\n")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nStopped.")


if __name__ == "__main__":
    serve(int(sys.argv[1]) if len(sys.argv) > 1 else 8000)
