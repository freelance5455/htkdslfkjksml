#!/usr/bin/env node
/* Xire AI - Node.js server (Node 18 or newer, no npm packages needed).

     node server.mjs [port]

   Same features as serve.py:
     - serves the app files
     - GET  /api/models                       lists .gguf files in ./models and next to index.html
     - GET  /api/cloud/status                 says whether HF_TOKEN is set on this server
     - POST /api/cloud/v1/chat/completions    forwards the chat to the cloud API with your token added,
                                              so the token never reaches the browser (streaming supported)

   Settings (environment variables or a .env file next to this script):
     HF_TOKEN, XIRE_UPSTREAM (default https://router.huggingface.co/v1),
     XIRE_MODEL (default Qwen/Qwen2.5-0.5B-Instruct:featherless-ai), XIRE_ALLOW_LAN=1 */

import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import os from "node:os";
import { fileURLToPath } from "node:url";

const ROOT = path.dirname(fileURLToPath(import.meta.url));

function loadEnv() {
  const p = path.join(ROOT, ".env");
  if (!fs.existsSync(p)) return;
  for (let line of fs.readFileSync(p, "utf8").split(/\r?\n/)) {
    line = line.trim();
    if (!line || line.startsWith("#") || !line.includes("=")) continue;
    const i = line.indexOf("=");
    const k = line.slice(0, i).trim(), v = line.slice(i + 1).trim().replace(/^["']|["']$/g, "");
    if (k && !(k in process.env)) process.env[k] = v;   // real environment variables win over the file
  }
}
loadEnv();

const cfg = () => ({
  token: (process.env.HF_TOKEN || "").trim(),
  upstream: (process.env.XIRE_UPSTREAM || "https://router.huggingface.co/v1").replace(/\/+$/, ""),
  model: process.env.XIRE_MODEL || "Qwen/Qwen2.5-0.5B-Instruct:featherless-ai",
  lan: ["1", "true", "yes"].includes(process.env.XIRE_ALLOW_LAN || ""),
});

const MIME = {
  ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8", ".js": "text/javascript; charset=utf-8",
  ".mjs": "text/javascript; charset=utf-8", ".json": "application/json", ".webmanifest": "application/manifest+json",
  ".png": "image/png", ".jpg": "image/jpeg", ".svg": "image/svg+xml", ".wasm": "application/wasm",
  ".gguf": "application/octet-stream", ".txt": "text/plain; charset=utf-8", ".md": "text/plain; charset=utf-8",
};
const LOOPBACK = new Set(["127.0.0.1", "::1", "::ffff:127.0.0.1"]);
const MAX_BODY = 2 * 1024 * 1024;

function listModels() {
  const out = [];
  const add = (dir, prefix) => {
    if (!fs.existsSync(dir)) return;
    for (const n of fs.readdirSync(dir).sort()) {
      if (n.toLowerCase().endsWith(".gguf")) out.push({ name: n, url: prefix + n, size: fs.statSync(path.join(dir, n)).size });
    }
  };
  add(path.join(ROOT, "models"), "models/");
  add(ROOT, "");
  return out;
}

const json = (res, code, obj) => {
  const b = Buffer.from(JSON.stringify(obj));
  res.writeHead(code, { "Content-Type": "application/json", "Content-Length": b.length });
  res.end(b);
};
const fail = (res, code, message) => json(res, code, { error: { message } });

function baseHeaders(extra = {}) {
  return {
    "Cache-Control": "no-cache",
    "Cross-Origin-Opener-Policy": "same-origin",
    "Cross-Origin-Embedder-Policy": "credentialless",
    "Cross-Origin-Resource-Policy": "same-origin",
    ...extra,
  };
}

const readBody = (req) => new Promise((resolve, reject) => {
  let size = 0; const parts = [];
  req.on("data", (c) => { size += c.length; if (size > MAX_BODY) { reject(Object.assign(new Error("too big"), { code: 413 })); req.destroy(); } else parts.push(c); });
  req.on("end", () => resolve(Buffer.concat(parts)));
  req.on("error", reject);
});

async function proxyChat(req, res) {
  const c = cfg();
  if (!c.token) return fail(res, 401, "No HF_TOKEN is set on the Xire server. Set it and restart, or type a token in the app.");
  if (!LOOPBACK.has(req.socket.remoteAddress) && !c.lan) return fail(res, 403, "The cloud proxy only answers on this computer. Type your own token in the app instead.");
  let req2;
  try {
    req2 = JSON.parse((await readBody(req)).toString("utf8"));
    if (!Array.isArray(req2.messages) || !req2.messages.length) throw new Error("no messages");
  } catch (e) {
    return fail(res, e && e.code === 413 ? 413 : 400, "Body must be JSON with a messages list");
  }
  const stream = req2.stream !== false;
  const body = {
    model: String(req2.model || c.model).slice(0, 200), messages: req2.messages, stream,
    temperature: req2.temperature ?? 0.7, max_tokens: Math.min(parseInt(req2.max_tokens) || 512, 4096),
  };
  const ac = new AbortController();
  res.on("close", () => ac.abort());                    // the page pressed Stop: stop paying for tokens
  let up;
  try {
    up = await fetch(c.upstream + "/chat/completions", {
      method: "POST", signal: ac.signal, body: JSON.stringify(body),
      headers: { "Content-Type": "application/json", Authorization: "Bearer " + c.token, Accept: stream ? "text/event-stream" : "application/json", "User-Agent": "xire-ai/1.0" },
    });
  } catch (e) {
    if (ac.signal.aborted) return;
    return fail(res, 502, "Could not reach the cloud API: " + String((e && e.cause && e.cause.message) || e.message || e).slice(0, 160));
  }
  const ct = up.headers.get("content-type") || "application/json";
  if (!up.ok) {                                         // forward the provider's error (it never contains our token)
    const data = Buffer.from((await up.text()).slice(0, 4000));
    res.writeHead(up.status, { "Content-Type": ct, "Content-Length": data.length });
    return res.end(data);
  }
  res.writeHead(up.status, { "Content-Type": ct, "X-Accel-Buffering": "no", "Cache-Control": "no-cache" });
  try {
    for await (const chunk of up.body) res.write(chunk);
  } catch (e) { /* aborted */ }
  res.end();
}

function serveStatic(req, res) {
  let rel = decodeURIComponent((req.url || "/").split("?")[0]);
  if (rel.endsWith("/")) rel += "index.html";
  const file = path.normalize(path.join(ROOT, rel));
  if (!file.startsWith(ROOT + path.sep) && file !== ROOT) return fail(res, 403, "Forbidden");
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) return fail(res, 404, "Not found");
    res.writeHead(200, baseHeaders({ "Content-Type": MIME[path.extname(file).toLowerCase()] || "application/octet-stream", "Content-Length": st.size }));
    fs.createReadStream(file).pipe(res);
  });
}

export function createServer() {
  return http.createServer(async (req, res) => {
    try {
      const p = (req.url || "/").split("?")[0];
      if (req.method === "GET" && p === "/api/models") return json(res, 200, listModels());
      if (req.method === "GET" && p === "/api/cloud/status") {
        const c = cfg();
        return json(res, 200, { proxy: true, hasToken: !!c.token && (LOOPBACK.has(req.socket.remoteAddress) || c.lan), model: c.model });
      }
      if (req.method === "POST" && p === "/api/cloud/v1/chat/completions") return await proxyChat(req, res);
      if (req.method === "GET" || req.method === "HEAD") return serveStatic(req, res);
      return fail(res, 404, "Not found");
    } catch (e) {
      if (!res.headersSent) fail(res, 500, "Server error");
      else res.end();
    }
  });
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  const port = parseInt(process.argv[2] || process.env.PORT || "8000", 10);
  createServer().listen(port, () => {
    const c = cfg();
    const ip = Object.values(os.networkInterfaces()).flat().find((i) => i && i.family === "IPv4" && !i.internal);
    console.log(`\n  Xire AI is running\n  this computer : http://localhost:${port}`);
    if (ip) console.log(`  same Wi-Fi    : http://${ip.address}:${port}`);
    console.log("  cloud model   : " + (c.token ? `token found, ready (${c.model})` : "no HF_TOKEN set (you can still type a token in the app)"));
    console.log("\n  Press Ctrl+C to stop.\n");
  });
}
