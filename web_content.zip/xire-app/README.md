# Xire AI

A private AI chat app. Two ways to run a model:

| | Local model | Cloud model |
|---|---|---|
| Where it runs | on your device, in the browser | Hugging Face router (OpenAI-compatible API) |
| Needs | a `.gguf` file (Qwen3 models) | internet and a Hugging Face token |
| Your messages | never leave the device | go to the provider you choose |

## Quick start
1. Computer: `python3 run.py` (Windows: double-click `start.bat`). Or with Node 18+: `node server.mjs`.
2. **Local model:** put a `.gguf` file in `models/` (or tap Add model in the app). Best choice: `Qwen3-0.6B-Q8_0.gguf` from huggingface.co/Qwen/Qwen3-0.6B-GGUF.
3. **Cloud model:** see below.

## Cloud model (Hugging Face)
Uses the same endpoint and model as your example code: `https://router.huggingface.co/v1` and
`Qwen/Qwen2.5-0.5B-Instruct:featherless-ai`. Create a token at huggingface.co/settings/tokens
(permission: "Make calls to Inference Providers").

**Option A, safest: keep the token on the server.**
Copy `.env.example` to `.env`, put your token in it, start Xire with `run.py` or `server.mjs`.
The app switches to the cloud model by itself when no local model is found. The browser never sees the token.
The proxy only answers on the same computer. Use `XIRE_ALLOW_LAN=1` only if you trust everyone on your Wi-Fi.

**Option B: type the token in the app.**
More options, then "Use a cloud model", paste the token, tap Run model.
It is saved on the device only if you tick "Remember". This works from a single HTML file or an APK.
Direct browser calls depend on the provider allowing CORS; if your browser blocks them, use Option A.

Never put a token inside `index.html`, `app.js` or any file you share.

## Files
| File | Purpose |
|---|---|
| `index.html`, `style.css` | page and look (light, dark, purple) |
| `app.js` | the interface: chats, sidebar, model menu, local and cloud modes |
| `cloud.js` | cloud runner: OpenAI-compatible streaming client, friendly errors |
| `gguf-core.js`, `gguf-worker.js` | local runner: GGUF reader, tokenizer, Qwen3 model, WebAssembly SIMD kernel, threads |
| `serve.py`, `run.py`, `start.bat`, `start.sh` | Python server (+ token proxy) and one-command launcher |
| `server.mjs` | the same server in Node.js, no packages needed |
| `build.py` | makes one self-contained file: `dist/Xire_AI_Pro.html` |
| `examples/hf-chat.mjs` | your Hugging Face example (needs `npm install openai`) |
| `tests/mock_hf.py` | a fake Hugging Face server to test without a token |
| `sw.js`, `manifest.json`, icons | offline shell and installable app |

## Single file for an APK
`python3 build.py` creates `dist/Xire_AI_Pro.html` (CSS, JavaScript and logo inside). Put it in your APK's assets folder.
For a local model also put the `.gguf` next to it. In a single file the runner threads start from a Blob, so no extra file is needed.

## Test without a token
```
python3 tests/mock_hf.py 9111
HF_TOKEN=test-token XIRE_UPSTREAM=http://127.0.0.1:9111/v1 python3 run.py
```

## Troubleshooting
- "The token was rejected": check the token and its "Inference Providers" permission.
- "needs credits" / "Too many requests": a provider limit; wait, add credits, or choose another model.
- "Model not found": the format is `owner/model` or `owner/model:provider`.
- Local answers are nonsense: the file is probably a Q1/Q2 quantization. Use Q8_0 or Q4_K_M.
- Slow local answers: keep the page open on a device with 4+ cores; first load converts the weights (about 15 s).
