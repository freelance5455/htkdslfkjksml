#!/usr/bin/env python3
"""Builds ONE self-contained file for APK apps and quick sharing:  dist/Xire_AI_Pro.html
   (CSS, JavaScript and the logo are put inside index.html; the model file is still separate.)
       python3 build.py"""
import base64, os, re, sys
HERE = os.path.dirname(os.path.abspath(__file__))
rd = lambda f: open(os.path.join(HERE, f), encoding="utf-8").read()
html = rd("index.html")
logo = "data:image/png;base64," + base64.b64encode(open(os.path.join(HERE, "logo.png"), "rb").read()).decode()

def sub(pat, repl, s, must=True):
    n = len(re.findall(pat, s))
    if must and n == 0: sys.exit("build failed: pattern not found: " + pat)
    return re.sub(pat, lambda m: repl, s)

css, core, cloud, app = rd("style.css"), rd("gguf-core.js"), rd("cloud.js"), rd("app.js")
for name, text in (("style.css", css), ("gguf-core.js", core), ("cloud.js", cloud), ("app.js", app)):
    if "</script" in text or "</style" in text.lower(): sys.exit("build failed: " + name + " contains a closing tag")
html = sub(r'<link rel="stylesheet" href="style\.css">', "<style>\n" + css + "</style>", html)
html = sub(r'<script id="xire-core" src="gguf-core\.js"></script>', '<script id="xire-core">\n' + core + "\n</script>", html)
html = sub(r'<script src="cloud\.js"></script>', "<script>\n" + cloud + "\n</script>", html)
html = sub(r'<script src="app\.js"></script>', "<script>\n" + app + "\n</script>", html)
html = html.replace('href="logo.png"', 'href="' + logo + '"').replace('src="logo.png"', 'src="' + logo + '"')
html = html.replace('LOGO="logo.png"', 'LOGO="' + logo + '"')
os.makedirs(os.path.join(HERE, "dist"), exist_ok=True)
out = os.path.join(HERE, "dist", "Xire_AI_Pro.html")
open(out, "w", encoding="utf-8").write(html)
print("built", out, round(len(html) / 1024), "KB")
