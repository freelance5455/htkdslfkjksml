#!/usr/bin/env python3
"""Xire AI - one command to check everything and start.
    python3 run.py              check files, start the server, open the browser
    python3 run.py --check      only check that every file is in place (no server)
    python3 run.py --port 9000  use another port
    python3 run.py --no-browser do not open the browser

Cloud model: put  HF_TOKEN=hf_xxx  in a file named .env (copy .env.example) or set it in your terminal.
The token stays on this computer; the browser never sees it."""
import argparse, json, os, socket, sys, threading, webbrowser

HERE = os.path.dirname(os.path.abspath(__file__))
os.chdir(HERE)
REQUIRED = ["index.html", "style.css", "app.js", "cloud.js", "gguf-core.js", "gguf-worker.js", "sw.js",
            "manifest.json", "logo.png", "icon-192.png", "icon-512.png", "serve.py"]

def ok(m): print("  [ok]   " + m)
def warn(m): print("  [warn] " + m)
def bad(m): print("  [FAIL] " + m)

def check():
    print("\nXire AI - system check\n")
    good = True
    if sys.version_info < (3, 7): bad("Python 3.7 or newer is needed"); good = False
    else: ok("Python " + sys.version.split()[0])
    for f in REQUIRED:
        if os.path.isfile(f) and os.path.getsize(f) > 0: ok(f)
        else: bad(f + " is missing or empty"); good = False
    try: json.load(open("manifest.json")); ok("manifest.json is valid")
    except Exception as e: bad("manifest.json: " + str(e)); good = False
    os.makedirs("models", exist_ok=True)
    import serve   # reads .env
    c = serve.cfg()
    ok("local AI runner is built in (Qwen3 .gguf models, no download)")
    if c["token"]: ok("cloud model ready: HF_TOKEN found, model " + c["model"])
    else: warn("no HF_TOKEN set: the cloud model option will ask you to type a token in the app")
    ggufs = [f for f in os.listdir("models") if f.lower().endswith(".gguf")] + [f for f in os.listdir(".") if f.lower().endswith(".gguf")]
    if ggufs:
        for g in ggufs:
            p = g if os.path.isfile(g) else os.path.join("models", g)
            gb = os.path.getsize(p) / 1e9
            (ok if gb <= 1.5 else warn)(f"model {g} ({gb:.2f} GB)" + ("" if gb <= 1.5 else " - big for a browser, may run out of memory"))
    else:
        warn("no local model yet: put a .gguf file in the models folder, or use the cloud model")
    return good

def free_port(p):
    for q in range(p, p + 50):
        with socket.socket() as s:
            if s.connect_ex(("127.0.0.1", q)) != 0: return q
    return p

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true"); ap.add_argument("--no-browser", action="store_true")
    ap.add_argument("--port", type=int, default=8000)
    a = ap.parse_args()
    if not check(): print("\nFix the files marked FAIL, then run again."); sys.exit(1)
    if a.check: print("\nAll good."); return
    port = free_port(a.port)
    import serve
    if not a.no_browser: threading.Timer(1.2, lambda: webbrowser.open(f"http://localhost:{port}")).start()
    serve.serve(port)

if __name__ == "__main__": main()
