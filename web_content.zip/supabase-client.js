/**
 * Maa Annapurna Tiffin Service - Supabase Cloud Database Client
 * Location: Kunwar Singh Nagar | +91 9311155593
 * 
 * Provides:
 *  - 100% Free PostgreSQL Cloud Storage via Supabase
 *  - Realtime Multi-Device Synchronization (Kitchen, Admin & Delivery Phones)
 *  - In-App Setup with One-Click SQL Migration Script
 *  - Zero-setup local fallback (Sandbox) when credentials are not yet entered
 */

const SUPABASE_CONFIG = {
  url: '',
  anonKey: '',
  tableName: 'tiffin_records',

  isConfigured: function () {
    return Boolean(
      this.url &&
      this.url.trim() !== '' &&
      this.url.startsWith('https://') &&
      this.anonKey &&
      this.anonKey.trim() !== ''
    );
  }
};

// Load saved credentials from localStorage
(function initSupabaseSettings() {
  try {
    const saved = localStorage.getItem('annapurna_supabase_config');
    if (saved) {
      const parsed = JSON.parse(saved);
      if (parsed.url) SUPABASE_CONFIG.url = parsed.url.trim().replace(/\/+$/, '');
      if (parsed.anonKey) SUPABASE_CONFIG.anonKey = parsed.anonKey.trim();
      if (parsed.tableName) SUPABASE_CONFIG.tableName = parsed.tableName.trim();
    }
  } catch (err) {
    console.error('Error loading Supabase configuration:', err);
  }
})();

function saveSupabaseConfigToStorage(config) {
  try {
    if (config.url) SUPABASE_CONFIG.url = config.url.trim().replace(/\/+$/, '');
    if (config.anonKey) SUPABASE_CONFIG.anonKey = config.anonKey.trim();
    if (config.tableName) SUPABASE_CONFIG.tableName = config.tableName.trim() || 'tiffin_records';

    localStorage.setItem('annapurna_supabase_config', JSON.stringify({
      url: SUPABASE_CONFIG.url,
      anonKey: SUPABASE_CONFIG.anonKey,
      tableName: SUPABASE_CONFIG.tableName
    }));

    // Reset client instance so it re-initializes with new credentials
    SupabaseClient.resetInstance();
    return true;
  } catch (err) {
    console.error('Failed to save Supabase config:', err);
    return false;
  }
}

function resetSupabaseConfigStorage() {
  try {
    localStorage.removeItem('annapurna_supabase_config');
    SUPABASE_CONFIG.url = '';
    SUPABASE_CONFIG.anonKey = '';
    SUPABASE_CONFIG.tableName = 'tiffin_records';
    SupabaseClient.resetInstance();
    return true;
  } catch {
    return false;
  }
}

const SupabaseClient = (function () {
  let clientInstance = null;
  let syncTimeout = null;
  let lastSyncTime = null;
  let realtimeChannel = null;

  function getClient() {
    if (!SUPABASE_CONFIG.isConfigured()) return null;
    if (clientInstance) return clientInstance;

    if (typeof supabase !== 'undefined' && supabase.createClient) {
      try {
        clientInstance = supabase.createClient(SUPABASE_CONFIG.url, SUPABASE_CONFIG.anonKey, {
          auth: {
            persistSession: true,
            autoRefreshToken: true
          }
        });
        return clientInstance;
      } catch (err) {
        console.error('Failed to initialize Supabase client:', err);
        return null;
      }
    } else {
      console.warn('Supabase SDK (@supabase/supabase-js) is not loaded.');
      return null;
    }
  }

  function updateSyncIndicator(state, message) {
    const indicator = document.getElementById('cloudSyncStatusBadge');
    if (!indicator) return;

    if (state === 'syncing') {
      indicator.className = 'badge-soft-blue text-[10.5px] font-bold px-2 py-0.5 rounded-lg flex items-center space-x-1 animate-pulse';
      indicator.innerHTML = `<span class="w-1.5 h-1.5 rounded-full bg-blue-500 animate-ping"></span><span>⏳ Syncing to Supabase...</span>`;
    } else if (state === 'synced') {
      const timeStr = lastSyncTime ? new Date(lastSyncTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Now';
      indicator.className = 'badge-soft-emerald text-[10.5px] font-bold px-2 py-0.5 rounded-lg flex items-center space-x-1';
      indicator.innerHTML = `<span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span><span>⚡ Supabase: Synced (${timeStr})</span>`;
    } else if (state === 'error') {
      indicator.className = 'badge-soft-red text-[10.5px] font-bold px-2 py-0.5 rounded-lg flex items-center space-x-1';
      indicator.innerHTML = `<span class="w-1.5 h-1.5 rounded-full bg-red-500"></span><span>⚠️ ${message || 'Supabase Sync Issue'}</span>`;
    }
  }

  return {
    isConfigured: function () {
      return SUPABASE_CONFIG.isConfigured();
    },

    resetInstance: function () {
      if (realtimeChannel && clientInstance) {
        try { clientInstance.removeChannel(realtimeChannel); } catch (e) {}
      }
      clientInstance = null;
      realtimeChannel = null;
    },

    // Test connection against user's Supabase project
    testConnection: async function () {
      const client = getClient();
      if (!client) {
        return { success: false, error: 'Please enter a valid Supabase URL and Anon Key.' };
      }

      try {
        const { data, error } = await client
          .from(SUPABASE_CONFIG.tableName)
          .select('id')
          .limit(1);

        if (error) {
          if (error.code === '42P01' || error.message?.includes('relation') || error.message?.includes('does not exist')) {
            return {
              success: false,
              tableMissing: true,
              error: `Table "${SUPABASE_CONFIG.tableName}" does not exist yet. Please run the SQL Setup Script in your Supabase SQL Editor.`
            };
          }
          return { success: false, error: error.message };
        }

        return { success: true, message: 'Connected successfully to Supabase!' };
      } catch (err) {
        return { success: false, error: err.message || 'Network error connecting to Supabase.' };
      }
    },

    // Fetch user cloud data
    fetchUserData: async function (recordId = 'admin_primary') {
      const client = getClient();
      if (!client) return null;

      updateSyncIndicator('syncing');

      try {
        const { data, error } = await client
          .from(SUPABASE_CONFIG.tableName)
          .select('data, updated_at')
          .eq('id', recordId)
          .maybeSingle();

        if (error) {
          console.warn('Supabase fetch notice:', error.message);
          updateSyncIndicator('error', 'Supabase Read Failed');
          return null;
        }

        if (data && data.data) {
          lastSyncTime = Date.now();
          updateSyncIndicator('synced');
          return data.data;
        }

        updateSyncIndicator('synced');
        return null;
      } catch (err) {
        console.error('Supabase fetch error:', err);
        updateSyncIndicator('error', 'Connection Error');
        return null;
      }
    },

    // Save user cloud data
    saveUserData: async function (payload, immediate = false, recordId = 'admin_primary') {
      const client = getClient();
      if (!client) return false;

      if (!immediate) {
        if (syncTimeout) clearTimeout(syncTimeout);
        syncTimeout = setTimeout(() => {
          this.executeSave(client, payload, recordId);
        }, 500);
        return true;
      } else {
        if (syncTimeout) clearTimeout(syncTimeout);
        return await this.executeSave(client, payload, recordId);
      }
    },

    executeSave: async function (client, payload, recordId) {
      updateSyncIndicator('syncing');

      const dataToSave = {
        clients: payload.clients || [],
        logs: payload.logs || [],
        boxStates: payload.boxStates || {},
        settings: payload.settings || {},
        weeklyMenu: payload.weeklyMenu || {},
        customMenus: payload.customMenus || [],
        extraItemsCatalog: payload.extraItemsCatalog || [],
        qrDatabase: payload.qrDatabase || []
      };

      try {
        const { error } = await client
          .from(SUPABASE_CONFIG.tableName)
          .upsert({
            id: recordId,
            user_id: recordId,
            data: dataToSave,
            updated_at: new Date().toISOString()
          }, { onConflict: 'id' });

        if (error) {
          console.error('Supabase upsert error:', error);
          updateSyncIndicator('error', 'Save Failed');
          return false;
        }

        lastSyncTime = Date.now();
        updateSyncIndicator('synced');
        return true;
      } catch (err) {
        console.error('Supabase network error during save:', err);
        updateSyncIndicator('error', 'Network Error');
        return false;
      }
    },

    // Realtime listener for live updates across devices
    setupRealtimeSubscription: function (onDataChange, recordId = 'admin_primary') {
      const client = getClient();
      if (!client) return;

      if (realtimeChannel) {
        try { client.removeChannel(realtimeChannel); } catch (e) {}
      }

      try {
        realtimeChannel = client
          .channel('public:' + SUPABASE_CONFIG.tableName)
          .on(
            'postgres_changes',
            {
              event: '*',
              schema: 'public',
              table: SUPABASE_CONFIG.tableName,
              filter: `id=eq.${recordId}`
            },
            (payload) => {
              if (payload.new && payload.new.data) {
                // Another device made a change; notify app to reload state
                if (typeof onDataChange === 'function') {
                  onDataChange(payload.new.data);
                }
              }
            }
          )
          .subscribe();
      } catch (e) {
        console.warn('Realtime subscription error:', e);
      }
    },

    // Return ready-to-run SQL setup code
    getSqlSetupScript: function () {
      const table = SUPABASE_CONFIG.tableName || 'tiffin_records';
      return `-- ========================================================
-- Maa Annapurna Tiffin Service - Supabase Database Setup
-- Run this in your Supabase SQL Editor (Takes only 5 seconds!)
-- ========================================================

-- 1. Create table for Tiffin Management application
CREATE TABLE IF NOT EXISTS public.${table} (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  data JSONB NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Enable Row Level Security (RLS)
ALTER TABLE public.${table} ENABLE ROW LEVEL SECURITY;

-- 3. Create Public Access Policy (for Anon Web Client)
DROP POLICY IF EXISTS "Public access to ${table}" ON public.${table};
CREATE POLICY "Public access to ${table}"
ON public.${table}
FOR ALL
TO anon, authenticated
USING (true)
WITH CHECK (true);

-- 4. Enable Realtime updates across phones & tablets
ALTER PUBLICATION supabase_realtime ADD TABLE public.${table};
`;
    },

    updateIndicator: updateSyncIndicator
  };
})();
