-- Regex keys
CREATE TABLE IF NOT EXISTS regex_keys (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  key_hash TEXT NOT NULL UNIQUE,
  key_hint TEXT NOT NULL,
  label TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'active',
  created_at TEXT NOT NULL,
  expires_at TEXT,
  last_used_at TEXT,
  activation TEXT NOT NULL DEFAULT 'created',
  activated_at TEXT,
  duration_seconds INTEGER,
  lifetime_label TEXT NOT NULL DEFAULT 'Never expires'
);

CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  expires_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS login_failures (
  ip TEXT PRIMARY KEY,
  count INTEGER NOT NULL,
  window_start INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS activity (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  at TEXT NOT NULL,
  action TEXT NOT NULL,
  detail TEXT NOT NULL DEFAULT ''
);

-- Dominant source tree lives here (NOT on GitHub)
CREATE TABLE IF NOT EXISTS dominant_files (
  path TEXT PRIMARY KEY,
  content TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  size INTEGER NOT NULL,
  sha256 TEXT
);

CREATE TABLE IF NOT EXISTS dominant_meta (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

-- Short-lived tokens for module streaming after /load
CREATE TABLE IF NOT EXISTS load_tokens (
  token_hash TEXT PRIMARY KEY,
  key_hint TEXT NOT NULL,
  expires_at INTEGER NOT NULL,
  used INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_dominant_files_updated ON dominant_files(updated_at);
CREATE INDEX IF NOT EXISTS idx_regex_keys_status ON regex_keys(status);
