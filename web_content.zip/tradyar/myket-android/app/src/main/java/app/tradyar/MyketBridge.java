package app.tradyar;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import ir.myket.billingclient.IabHelper;
import ir.myket.billingclient.util.IabResult;
import ir.myket.billingclient.util.Inventory;
import ir.myket.billingclient.util.Purchase;

/**
 * MyketBridge — پل جاوااسکریپت ↔ SDK رسمی پرداخت مایکت (نسخه 2.2)
 *
 * اصلاحات نسخهٔ جدید (رفع «درگاه پرداخت باز نمی‌شود»):
 *  ۱. Auto-Setup: اگر purchase/query/consume قبل از اتمام راه‌اندازی صدا زده شود،
 *     به‌جای خطای «not_ready» خودکار startSetup انجام می‌شود و عملیات در صف می‌ماند.
 *  ۲. کد عددی خطا (response) در همهٔ جواب‌ها برگردانده می‌شود تا JS بتواند پیام دقیق فارسی نشان دهد.
 *  ۳. getNativeDiagnostics(): وضعیت کامل دستگاه (نصب مایکت/کروم، امضای APK، متادیتاهای مانیفست،
 *     آخرین خطاها) برای گزارش‌گیری دقیق هنگام پشتیبانی.
 *  ۴. لاگ همیشه فعال روی سطح Info برای خطایابی روی گوشی کاربر.
 */
public class MyketBridge {
    private static final String TAG = "MyketBridge";

    private final Activity activity;
    private final WebView webView;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private IabHelper mHelper;
    private volatile boolean isSetup = false;
    private boolean setupInProgress = false;
    /** آخرین پیام راه‌اندازی برای گزارش خطا */
    private volatile String lastSetupMessage = "";
    private volatile boolean lastSetupSuccess = false;
    private volatile String lastPurchaseMessage = "";
    private volatile int lastPurchaseResponse = Integer.MIN_VALUE;

    /** عملیات‌های در انتظار اتمام setup */
    private final List<Runnable> pendingAfterSetup = new ArrayList<>();

    /** خریدهایی که در همین نشست دیده شده‌اند (token → Purchase) تا بتوان مصرفشان کرد */
    private final Map<String, Purchase> knownPurchases = new HashMap<>();
    /** همهٔ SKUهایی که JS تا الان پرسیده؛ برای پیدا کردن خرید با توکن */
    private final Set<String> knownSkus = new LinkedHashSet<>();

    public MyketBridge(Activity activity, WebView webView) {
        this.activity = activity;
        this.webView = webView;
    }

    /* ------------------------------------------------------------------ */
    /* مرحله ۱ — startSetup                                                */
    /* ------------------------------------------------------------------ */
    @JavascriptInterface
    public void startSetup(final String ignoredKeyFromJs) {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (isSetup) {
                    callJavaScript("myketOnSetupFinished", "{\"success\":true}");
                    return;
                }
                if (setupInProgress) {
                    Log.i(TAG, "startSetup: setup already in progress, JS keeps polling");
                    return;
                }
                setupInProgress = true;
                try {
                    mHelper = new IabHelper(activity, BuildConfig.IAB_PUBLIC_KEY);
                    // لاگ SDK فقط در بیلد دیباگ؛ لاگ خود پل همیشه روشن است
                    mHelper.enableDebugLogging(BuildConfig.DEBUG, TAG);
                    Log.i(TAG, "startSetup: calling SDK startSetup…");
                    mHelper.startSetup(result -> {
                        setupInProgress = false;
                        boolean ok = result != null && result.isSuccess();
                        lastSetupSuccess = ok;
                        lastSetupMessage = result != null ? String.valueOf(result.getMessage()) : "null result";
                        if (!ok) {
                            isSetup = false;
                            Log.e(TAG, "Setup failed: " + lastSetupMessage);
                            try { if (mHelper != null) mHelper.dispose(); } catch (Throwable ignored) { }
                            mHelper = null; // تا تلاش بعدی از نو شروع شود
                            callJavaScript("myketOnSetupFinished",
                                    "{\"success\":false,\"message\":\"" + esc(lastSetupMessage) + "\"}");
                            return;
                        }
                        isSetup = true;
                        Log.i(TAG, "Setup OK: " + lastSetupMessage);
                        callJavaScript("myketOnSetupFinished", "{\"success\":true}");
                        flushPendingAfterSetup();
                    });
                } catch (Throwable e) {
                    setupInProgress = false;
                    isSetup = false;
                    mHelper = null;
                    lastSetupSuccess = false;
                    lastSetupMessage = String.valueOf(e.getMessage());
                    Log.e(TAG, "startSetup error", e);
                    callJavaScript("myketOnSetupFinished",
                            "{\"success\":false,\"message\":\"" + esc(lastSetupMessage) + "\"}");
                }
            }
        });
    }

    @JavascriptInterface
    public boolean isSetup() {
        return isSetup && mHelper != null;
    }

    /** اگر setup آماده است کار را اجرا می‌کند؛ وگرنه خودکار setup را شروع می‌کند و کار را صف می‌کند */
    private void ensureSetupThen(final Runnable action) {
        if (isSetup && mHelper != null) {
            action.run();
            return;
        }
        synchronized (pendingAfterSetup) {
            pendingAfterSetup.add(action);
        }
        Log.i(TAG, "Operation queued until setup finishes");
        startSetup(null);
    }

    private void flushPendingAfterSetup() {
        List<Runnable> pending;
        synchronized (pendingAfterSetup) {
            pending = new ArrayList<>(pendingAfterSetup);
            pendingAfterSetup.clear();
        }
        for (Runnable r : pending) {
            try { r.run(); } catch (Throwable e) { Log.e(TAG, "pending action failed", e); }
        }
    }

    /* ------------------------------------------------------------------ */
    /* مرحله ۲ — queryInventory (خریدهای مصرف‌نشده + بازیابی بعد از کرش)   */
    /* ------------------------------------------------------------------ */
    @JavascriptInterface
    public void queryInventoryAsync(boolean querySkuDetails, String itemSkusJson, String subSkusJson,
                                    final String callbackId) {
        final List<String> skus = parseSkus(itemSkusJson);
        // مایکت اشتراک ندارد؛ هر SKU که از سمت JS به‌عنوان sub بیاید هم به‌عنوان inapp پرسیده می‌شود
        for (String s : parseSkus(subSkusJson)) if (!skus.contains(s)) skus.add(s);
        synchronized (knownSkus) { knownSkus.addAll(skus); }
        final boolean details = querySkuDetails;

        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (skus.isEmpty() && !details) {
                    invokeCallback(callbackId, "{\"success\":true,\"purchases\":[],\"purchase\":[]}");
                    return;
                }
                ensureSetupThen(new Runnable() {
                    @Override
                    public void run() {
                        runQueryInventory(details, skus, callbackId);
                    }
                });
            }
        });
    }

    private void runQueryInventory(final boolean details, final List<String> skus, final String callbackId) {
        try {
            mHelper.queryInventoryAsync(details, skus, (result, inventory) -> {
                if (result == null || result.isFailure() || inventory == null) {
                    int code = result != null ? result.getResponse() : -1;
                    String msg = result != null ? result.getMessage() : "unknown";
                    Log.e(TAG, "queryInventory failed (" + code + "): " + msg);
                    invokeCallback(callbackId, "{\"success\":false,\"response\":" + code
                            + ",\"message\":\"" + esc(msg) + "\"}");
                    return;
                }
                try {
                    JSONArray arr = new JSONArray();
                    for (String sku : skus) {
                        Purchase p = inventory.getPurchase(sku);
                        if (p == null) continue;
                        if (p.getToken() != null) knownPurchases.put(p.getToken(), p);
                        arr.put(purchaseJson(p));
                    }
                    JSONObject out = new JSONObject();
                    out.put("success", true);
                    out.put("purchases", arr);
                    out.put("purchase", arr); // سازگاری با کد قدیمی JS
                    invokeCallback(callbackId, out.toString());
                } catch (Throwable e) {
                    invokeCallback(callbackId, "{\"success\":false,\"response\":-1,\"message\":\""
                            + esc(String.valueOf(e.getMessage())) + "\"}");
                }
            });
        } catch (Throwable e) {
            Log.e(TAG, "queryInventoryAsync error", e);
            invokeCallback(callbackId, "{\"success\":false,\"error\":\"" + errCode(e) + "\",\"message\":\""
                    + esc(String.valueOf(e.getMessage())) + "\"}");
        }
    }

    /* ------------------------------------------------------------------ */
    /* مرحله ۳ — launchPurchaseFlow (درگاه پرداخت مایکت)                   */
    /* ------------------------------------------------------------------ */
    @JavascriptInterface
    public void launchPurchaseFlow(final String sku, String itemType, final String developerPayload,
                                   final String callbackId) {
        synchronized (knownSkus) { if (sku != null) knownSkus.add(sku); }
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                final String payload = developerPayload == null ? "" : developerPayload;
                ensureSetupThen(new Runnable() {
                    @Override
                    public void run() {
                        runPurchase(sku, payload, callbackId);
                    }
                });
            }
        });
    }

    private void runPurchase(final String sku, final String payload, final String callbackId) {
        String trimmed = payload.length() > 800 ? payload.substring(0, 800) : payload; // سقف مستندات مایکت
        final String p = trimmed;
        try {
            Log.i(TAG, "launchPurchaseFlow sku=" + sku);
            mHelper.launchPurchaseFlow(activity, sku, (result, purchase) -> {
                int code = result != null ? result.getResponse() : -1;
                lastPurchaseResponse = code;
                lastPurchaseMessage = result != null ? String.valueOf(result.getMessage()) : "unknown";
                if (result == null || result.isFailure() || purchase == null) {
                    Log.e(TAG, "Purchase failed (" + code + "): " + lastPurchaseMessage);
                    String msg = lastPurchaseMessage;
                    String low = msg == null ? "" : msg.toLowerCase();
                    boolean cancelled = low.contains("cancel");
                    boolean owned = code == 7 || low.contains("already owned"); // خرید قبلی مصرف‌نشده
                    String kind = cancelled ? "cancelled" : (owned ? "already_owned" : "purchase_failed");
                    invokeCallback(callbackId, "{\"success\":false,\"error\":\"" + kind
                            + "\",\"response\":" + code
                            + ",\"cancelled\":" + cancelled
                            + ",\"message\":\"" + esc(msg) + "\"}");
                    return;
                }
                try {
                    Log.i(TAG, "Purchase OK sku=" + purchase.getSku());
                    if (purchase.getToken() != null) knownPurchases.put(purchase.getToken(), purchase);
                    JSONObject pj = purchaseJson(purchase);
                    JSONObject out = new JSONObject();
                    out.put("success", true);
                    out.put("isSuccess", true);
                    out.put("purchase", pj);
                    out.put("token", purchase.getToken());
                    out.put("purchaseToken", purchase.getToken());
                    out.put("orderId", purchase.getOrderId());
                    invokeCallback(callbackId, out.toString());
                } catch (Throwable e) {
                    invokeCallback(callbackId, "{\"success\":false,\"error\":\"bad_purchase\"}");
                }
            }, p);
        } catch (Throwable e) {
            Log.e(TAG, "launchPurchaseFlow error", e);
            invokeCallback(callbackId, "{\"success\":false,\"error\":\"" + errCode(e) + "\",\"message\":\"" + esc(String.valueOf(e.getMessage())) + "\"}");
        }
    }

    /* ------------------------------------------------------------------ */
    /* مرحله ۴ — consumeAsync                                              */
    /* ------------------------------------------------------------------ */
    @JavascriptInterface
    public void consumeAsync(String tokenOrPurchase, final String callbackId) {
        String t = tokenOrPurchase == null ? "" : tokenOrPurchase.trim();
        if (t.startsWith("{")) {
            try {
                JSONObject o = new JSONObject(t);
                t = o.optString("token", o.optString("purchaseToken", o.optString("mToken", "")));
            } catch (Throwable ignored) { }
        }
        final String token = t;
        if (token.isEmpty()) {
            invokeCallback(callbackId, "{\"success\":false,\"error\":\"invalid_token\"}");
            return;
        }
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                final Purchase known = knownPurchases.get(token);
                if (known != null) {
                    ensureSetupThen(new Runnable() {
                        @Override
                        public void run() { doConsume(known, callbackId); }
                    });
                    return;
                }
                // خرید در این نشست دیده نشده (مثلاً بعد از ری‌استارت): از موجودی پیدا می‌کنیم
                ensureSetupThen(new Runnable() {
                    @Override
                    public void run() { findAndConsume(token, callbackId); }
                });
            }
        });
    }

    private void findAndConsume(final String token, final String callbackId) {
        final List<String> skus;
        synchronized (knownSkus) { skus = new ArrayList<>(knownSkus); }
        if (skus.isEmpty()) {
            invokeCallback(callbackId, "{\"success\":false,\"error\":\"purchase_not_found\"}");
            return;
        }
        try {
            mHelper.queryInventoryAsync(false, skus, (result, inventory) -> {
                Purchase found = null;
                if (result != null && result.isSuccess() && inventory != null) {
                    for (String sku : skus) {
                        Purchase p = inventory.getPurchase(sku);
                        if (p != null && token.equals(p.getToken())) { found = p; break; }
                    }
                }
                if (found == null) {
                    invokeCallback(callbackId, "{\"success\":false,\"error\":\"purchase_not_found\"}");
                    return;
                }
                knownPurchases.put(token, found);
                doConsume(found, callbackId);
            });
        } catch (Throwable e) {
            invokeCallback(callbackId, "{\"success\":false,\"error\":\"" + esc(String.valueOf(e.getMessage())) + "\"}");
        }
    }

    private void doConsume(final Purchase purchase, final String callbackId) {
        try {
            mHelper.consumeAsync(purchase, (consumed, result) -> {
                if (result != null && result.isSuccess()) {
                    if (purchase.getToken() != null) knownPurchases.remove(purchase.getToken());
                    invokeCallback(callbackId, "{\"success\":true,\"isSuccess\":true}");
                } else {
                    int code = result != null ? result.getResponse() : -1;
                    invokeCallback(callbackId, "{\"success\":false,\"response\":" + code + ",\"message\":\""
                            + esc(result != null ? result.getMessage() : "unknown") + "\"}");
                }
            });
        } catch (Throwable e) {
            Log.e(TAG, "consume error", e);
            invokeCallback(callbackId, "{\"success\":false,\"error\":\"" + esc(String.valueOf(e.getMessage())) + "\"}");
        }
    }

    /* ------------------------------------------------------------------ */
    /* گزارش دقیق دستگاه برای پشتیبانی (دکمهٔ «کپی گزارش خطا»)              */
    /* ------------------------------------------------------------------ */
    @JavascriptInterface
    public String getNativeDiagnostics() {
        JSONObject o = new JSONObject();
        try {
            Context ctx = activity != null ? activity.getApplicationContext() : null;
            PackageManager pm = ctx != null ? ctx.getPackageManager() : null;
            String pkg = ctx != null ? ctx.getPackageName() : "";
            o.put("appPackage", pkg);
            try {
                PackageInfo pi = pm.getPackageInfo(pkg, 0);
                o.put("appVersionName", pi.versionName);
                o.put("appVersionCode", (Build.VERSION.SDK_INT >= 28) ? pi.getLongVersionCode() : pi.versionCode);
                // امضای فعلی APK — باید با امضای فایل بارگذاری‌شده در پنل مایکت یکی باشد
                if (Build.VERSION.SDK_INT >= 28) {
                    android.content.pm.SigningInfo si = pi.signingInfo;
                    byte[] cert = (si != null && si.hasMultipleSigners())
                            ? si.getApkContentsSigners()[0].toCharsString().getBytes()
                            : (si != null ? si.getSigningCertificateHistory()[0].toCharsString().getBytes() : null);
                    if (cert != null) o.put("appSignatureSha256", sha256(cert));
                }
            } catch (Throwable e) { o.put("appInfoError", String.valueOf(e.getMessage())); }
            if (pm != null) {
                o.put("myketInstalled", isInstalled(pm, "ir.mservices.market"));
                o.put("myketVersion", packageVersion(pm, "ir.mservices.market"));
                o.put("chromeInstalled", isInstalled(pm, "com.android.chrome"));
                o.put("browsersFound", countBrowsers(pm));
            }
            try {
                ApplicationInfo ai = pm != null ? pm.getApplicationInfo(pkg, PackageManager.GET_META_DATA) : null;
                if (ai != null && ai.metaData != null) {
                    o.put("metaMarketId", ai.metaData.getString("market_id"));
                    o.put("metaBindAddress", ai.metaData.getString("market_bind_address"));
                    o.put("metaSdkVersion", ai.metaData.getInt("sdk_version"));
                } else {
                    o.put("metaError", "no meta-data");
                }
            } catch (Throwable e) { o.put("metaError", String.valueOf(e.getMessage())); }
            o.put("setupDone", isSetup);
            o.put("setupInProgress", setupInProgress);
            o.put("lastSetupSuccess", lastSetupSuccess);
            o.put("lastSetupMessage", lastSetupMessage);
            o.put("lastPurchaseResponse", lastPurchaseResponse == Integer.MIN_VALUE ? "" : String.valueOf(lastPurchaseResponse));
            o.put("lastPurchaseMessage", lastPurchaseMessage);
            o.put("publicKeySet", BuildConfig.IAB_PUBLIC_KEY != null && BuildConfig.IAB_PUBLIC_KEY.length() > 50);
            o.put("androidOs", Build.VERSION.SDK_INT);
            o.put("device", Build.MANUFACTURER + " " + Build.MODEL);
        } catch (Throwable e) {
            try { o.put("diagError", String.valueOf(e.getMessage())); } catch (Throwable ignored) { }
        }
        return o.toString();
    }

    private boolean isInstalled(PackageManager pm, String packageName) {
        try { pm.getPackageInfo(packageName, 0); return true; } catch (Throwable e) { return false; }
    }

    private String packageVersion(PackageManager pm, String packageName) {
        try {
            PackageInfo pi = pm.getPackageInfo(packageName, 0);
            return pi.versionName + " (" + pi.versionCode + ")";
        } catch (Throwable e) { return null; }
    }

    private int countBrowsers(PackageManager pm) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://myket.ir"));
            return pm.queryIntentActivities(i, 0).size();
        } catch (Throwable e) { return 0; }
    }

    private String sha256(byte[] data) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] h = md.digest(data);
            StringBuilder sb = new StringBuilder();
            for (byte b : h) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Throwable e) { return null; }
    }

    @JavascriptInterface
    public String generateCallbackId() {
        return "cb_" + System.currentTimeMillis() + "_" + UUID.randomUUID().toString().substring(0, 8);
    }

    /* ------------------------------------------------------------------ */
    private JSONObject purchaseJson(Purchase p) throws Exception {
        JSONObject o = new JSONObject();
        o.put("sku", p.getSku());
        o.put("token", p.getToken());
        o.put("orderId", p.getOrderId());
        o.put("itemType", p.getItemType());
        o.put("packageName", p.getPackageName());
        o.put("purchaseTime", p.getPurchaseTime());
        o.put("purchaseState", p.getPurchaseState());
        o.put("developerPayload", p.getDeveloperPayload());
        o.put("originalJson", p.getOriginalJson());
        o.put("signature", p.getSignature());
        return o;
    }

    private List<String> parseSkus(String json) {
        List<String> skus = new ArrayList<>();
        if (json == null || json.trim().isEmpty()) return skus;
        try {
            if (json.trim().startsWith("[")) {
                JSONArray a = new JSONArray(json);
                for (int i = 0; i < a.length(); i++) {
                    String s = a.optString(i, "").trim();
                    if (!s.isEmpty() && !skus.contains(s)) skus.add(s);
                }
            } else {
                for (String part : json.split(",")) {
                    String s = part.trim().replace("\"", "");
                    if (!s.isEmpty() && !skus.contains(s)) skus.add(s);
                }
            }
        } catch (Throwable e) {
            Log.e(TAG, "parseSkus: " + json, e);
        }
        return skus;
    }

    /** SDK مایکت هم‌زمان فقط یک عملیات می‌پذیرد؛ این حالت را «busy» می‌نامیم تا JS دوباره تلاش کند */
    private String errCode(Throwable e) {
        String n = e.getClass().getSimpleName();
        if (n.contains("AsyncInProgress")) return "busy";
        if (n.contains("IllegalState")) return "illegal_state";
        return "failed";
    }

    private String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r").replace("\t", "\\t");
    }

    private void invokeCallback(final String callbackId, final String data) {
        if (callbackId == null || callbackId.isEmpty()) return;
        final String safe = (data == null || data.equals("null")) ? "null" : data;
        final String js = "if(window.__invokeMyketCallback){window.__invokeMyketCallback(\"" + esc(callbackId) + "\"," + safe + ");}";
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                try { webView.evaluateJavascript(js, null); } catch (Throwable e) { Log.e(TAG, "invokeCallback", e); }
            }
        });
    }

    private void callJavaScript(final String fn, final String data) {
        final String safe = (data == null || data.equals("null")) ? "null" : data;
        final String js = "if(window." + fn + "){window." + fn + "(" + safe + ");}";
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                try { webView.evaluateJavascript(js, null); } catch (Throwable e) { Log.e(TAG, "callJavaScript", e); }
            }
        });
    }

    /** آزادسازی منابع (مرحلهٔ پنجم مستندات) */
    public void onDestroy() {
        try { if (mHelper != null) mHelper.dispose(); } catch (Throwable e) { Log.w(TAG, "dispose", e); }
        mHelper = null;
        isSetup = false;
        setupInProgress = false;
        synchronized (pendingAfterSetup) { pendingAfterSetup.clear(); }
        knownPurchases.clear();
    }
}
