VAISHNAV WORLD ADMIN — PERMISSION DENIED PATCH
================================================

What was checked/fixed in this source ZIP
- Synced the same complete Admin UI/app.js into all packaged Admin web folders so APK and web copies do not differ.
- Added missing Realtime Database path rules for the current feature set: quiz drafts/meta/daily/results, shlokaReading, monthlyLeaderboard, challengeProgress, courseProgress, shlokChallenge, challenge30, japa, sadhana, pointsEvents, notifications, pushQueue, fcmTokens, calendar, books, YouTube, courses, articles, profiles, and existing legacy paths.
- Added clearer Firebase Permission Denied messages in Admin UI.
- Kept Hindi/Bengali quiz publishing (10 questions per language/date), bilingual Shlok Reading, XP & Activity, courses, weekly challenges, content, calendar, YouTube, books, Prabhupada Today and notifications.

IMPORTANT: this ZIP cannot change the rules already published in your online Firebase project. If the Console still has old rules, Permission Denied will continue until you update and Publish the rules there.

TEST ONLY RULES — NOT SAFE FOR A PUBLIC APP
The included firebase-rules.json and firebase-rules-admin-development.json allow unauthenticated reads/writes on the listed feature paths. Anyone who can reach this database could change or read data. Use only for a private short test, then replace with Firebase Authentication and admin-only writes. A password-only screen inside the app is not Firebase authentication. Never leave these rules on a public/live app.

To test temporarily:
1. Firebase Console -> project hare-krishna-94342 -> Build -> Realtime Database -> Rules.
2. Back up the currently published rules.
3. For a private test only, copy firebase-rules.json from this ZIP into the Rules editor and press Publish.
4. Test Admin reads/writes, then verify the same quiz/shlok appears in Devotee app.
5. Before public use, configure Firebase Authentication and secure path-specific rules; do not keep the temporary rules.

Paths used by the Admin/Devotee code include:
- quiz/drafts/{language}/{date}, quiz/daily/{language}/{date}, quiz/meta/{language}/{date}, quiz/results/{date}/{memberKey}
- shlokaReading/{date}; monthlyLeaderboard/{month}/{memberKey}; challengeProgress/{challengeId}
- users, courses, courseProgress, challenges, bhaktiContent, calendar, youtube, books, prabhupadaToday, notifications, pushQueue, fcmTokens, shlokChallenge, challenge30, japa, sadhana, pointsEvents, dailyDarshan and darshanComments.

Verification limits
ZIP archive integrity and JavaScript syntax were checked locally. No APK build, Firebase Console publish, or live database test was performed, so live Permission Denied resolution cannot be claimed until the rules are published and tested.
