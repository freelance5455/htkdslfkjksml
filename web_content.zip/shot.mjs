import { chromium } from 'playwright';
const browser = await chromium.launch({ executablePath: '/home/user/.cache/ms-playwright/chromium_headless_shell-1148/chrome-linux/headless_shell', args: ['--no-sandbox','--disable-gpu'] });
const page = await browser.newPage({ viewport: { width: 1440, height: 1000 }, deviceScaleFactor: 1 });
const errors = [];
page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
await page.goto('http://localhost:4173/', { waitUntil: 'networkidle' });
await page.waitForTimeout(700);

// Levels
await page.getByRole('button', { name: 'Levels', exact: true }).first().click();
await page.waitForTimeout(600);
await page.screenshot({ path: 'qa/levels.png' });

// Ranks
await page.getByRole('button', { name: 'Ranks', exact: true }).first().click();
await page.waitForTimeout(500);
await page.screenshot({ path: 'qa/ranks.png' });

// Skins
await page.getByRole('button', { name: 'Skins', exact: true }).first().click();
await page.waitForTimeout(500);
await page.screenshot({ path: 'qa/skins.png' });

// Game from Home
await page.getByRole('button', { name: 'Home', exact: true }).first().click();
await page.waitForTimeout(400);
await page.getByRole('button', { name: /Start the descent/ }).click();
await page.waitForTimeout(900);
await page.screenshot({ path: 'qa/game-tutorial.png' });
await page.getByRole('button', { name: /Start level/ }).click();
await page.waitForTimeout(900);
await page.screenshot({ path: 'qa/game.png' });

// play: hold on canvas center
const canvas = page.locator('canvas');
const box = await canvas.boundingBox();
console.log('canvas box', JSON.stringify(box));
await page.mouse.move(box.x + box.width/2, box.y + box.height*0.45);
await page.mouse.down();
await page.waitForTimeout(7000);
await page.screenshot({ path: 'qa/game-playing.png' });
await page.mouse.up();
await page.waitForTimeout(1600);
await page.screenshot({ path: 'qa/game-result.png' });
const bodyText = await page.locator('body').innerText();
console.log('has result overlay:', /Core reached|Clean run|Flawless/.test(bodyText));
console.log('ERRORS:', JSON.stringify(errors, null, 2));
await browser.close();
