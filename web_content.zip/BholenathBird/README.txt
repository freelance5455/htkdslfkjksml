BHOLENATH BIRD — Android project (WebView + AdMob Interstitial)
==================================================================

Kya hai is zip mein:
- Ek complete Android Studio project jisme tumhara game
  (app/src/main/assets/index.html) ek native app ke andar WebView
  mein chalta hai.
- AdMob App ID already AndroidManifest.xml mein daala hua hai:
    ca-app-pub-5601616934409724~1357833139
- AdMob Interstitial Ad Unit ID already MainActivity.java mein
  daala hua hai:
    ca-app-pub-5601616934409724/5186532974
  Ye ad har 2nd "Game Over" ke baad dikhega (har baar nahi, taaki
  ads spammy na lagein — chaaho to MainActivity.java mein
  SHOW_AD_EVERY_N_GAMEOVERS value change kar sakte ho).
- Placeholder launcher icon (orange bird circle) — Play Store pe
  upload karne se pehle isse apne khud ke professional icon se
  replace karna recommended hai (play_store_icon_512.png bhi diya
  hai reference ke liye, 512x512).

IMPORTANT: Maine yahan APK/AAB build NAHI kiya hai, kyunki is
environment mein Android SDK aur internet access nahi hai. Tumhe
ye steps khud (ya kisi bhi Windows/Mac/Linux PC pe) karne honge:

STEP 1 — Android Studio install karo (free): 
  https://developer.android.com/studio

STEP 2 — Is zip ko extract karke Android Studio mein kholo:
  File > Open > BholenathBird folder select karo.
  Pehli baar Gradle sync hone mein thoda time lagega (internet
  chahiye, kyunki dependencies download hongi).

STEP 3 — Apna AdMob account (Google AdSense/Play Console linked)
  verify kar lo aur wahi App ID / Ad Unit ID use ho rahe hain check
  kar lo (already daale hue hain, but confirm zaroor karna apne
  AdMob dashboard se).

STEP 4 — Test karo:
  Ek Android phone/emulator connect karke Run (▶) button dabao.
  NOTE: Jab tak app AdMob console mein "live" nahi hota aur test
  device add nahi hota, real ads production mein late aa sakte
  hain — pehle AdMob ke test ads use karna better hai launch se
  pehle (AdMob docs: "Test ads").

STEP 5 — Play Store ke liye signed AAB banao:
  Build > Generate Signed Bundle / APK > Android App Bundle
  Naya keystore banao (isse SAFE jagah save karo — kho gaya to
  future updates upload nahi kar paoge).

STEP 6 — Google Play Console pe naya app banao, AAB upload karo,
  store listing (screenshots, description, privacy policy —
  ads/AdMob use karne par privacy policy MANDATORY hai Play Store
  policy ke hisaab se) fill karo, aur submit for review karo.

Agar Android Studio install karne mein ya kisi step mein atko, bata
dena — us step ka detailed walkthrough bhi kar sakte hain.
