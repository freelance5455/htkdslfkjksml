'use strict';

// NoHomYar Pro — dependency-free Node.js server.
// Messages and content are stored outside /public so they cannot be downloaded as files.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { URL } = require('node:url');

const ROOT = __dirname;
const PUBLIC_DIR = path.join(ROOT, 'public');
const DATA_DIR = path.resolve(process.env.DATA_DIR || path.join(ROOT, 'data'));
const DB_FILE = path.join(DATA_DIR, 'db.json');
const ADMIN_FILE = path.join(DATA_DIR, 'admin.json');
const HOST = process.env.HOST || '127.0.0.1';
const PORT = Number(process.env.PORT || 8080);
const IS_PRODUCTION = process.env.NODE_ENV === 'production' || process.env.FORCE_SECURE_COOKIE === 'true';
const COOKIE_NAME = 'nh_session';
const MAX_BODY = 5 * 1024 * 1024;
const sessions = new Map();
const rateBuckets = new Map();

fs.mkdirSync(DATA_DIR, { recursive: true, mode: 0o700 });

function initialDb() {
  return { version: 1, users: [], tickets: [], ads: [], resources: [], questions: [], licenses: [] };
}
function loadDb() {
  try {
    const parsed = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
    return { ...initialDb(), ...parsed,
      users: Array.isArray(parsed.users) ? parsed.users : [],
      tickets: Array.isArray(parsed.tickets) ? parsed.tickets : [],
      ads: Array.isArray(parsed.ads) ? parsed.ads : [],
      resources: Array.isArray(parsed.resources) ? parsed.resources : [],
      questions: Array.isArray(parsed.questions) ? parsed.questions : [],
      licenses: Array.isArray(parsed.licenses) ? parsed.licenses : [] };
  } catch (err) {
    if (err.code !== 'ENOENT') console.error('Database is invalid; refusing to overwrite it:', err.message);
    if (err.code !== 'ENOENT') throw new Error('فایل داده خراب است؛ قبل از ادامه از آن نسخهٔ پشتیبان بگیر.');
    const fresh = initialDb(); saveDb(fresh); return fresh;
  }
}
function saveDb(db) {
  const tmp = DB_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(db), { mode: 0o600 });
  fs.renameSync(tmp, DB_FILE);
  try { fs.chmodSync(DB_FILE, 0o600); } catch (_) {}
}
let db = loadDb();

function json(res, status, value, extraHeaders = {}) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'same-origin',
    'X-Frame-Options': 'DENY',
    ...extraHeaders,
  });
  res.end(JSON.stringify(value));
}
function fail(res, status, message, more = {}) { return json(res, status, { error: message, ...more }); }
function readBody(req) {
  return new Promise((resolve, reject) => {
    let raw = ''; let size = 0;
    req.on('data', chunk => {
      size += chunk.length;
      if (size > MAX_BODY) { reject(Object.assign(new Error('حجم درخواست بیش از حد مجاز است.'), { status: 413 })); req.destroy(); return; }
      raw += chunk.toString('utf8');
    });
    req.on('end', () => {
      if (!raw) return resolve({});
      try { resolve(JSON.parse(raw)); }
      catch (_) { reject(Object.assign(new Error('فرمت JSON معتبر نیست.'), { status: 400 })); }
    });
    req.on('error', reject);
  });
}
function trimText(v, max = 4000) { return typeof v === 'string' ? v.trim().slice(0, max) : ''; }
function id(prefix) { return prefix + '_' + crypto.randomBytes(12).toString('hex'); }
function usernameKey(v) { return String(v || '').normalize('NFKC').toLocaleLowerCase('en-US'); }
function validUsername(v) { return /^[\p{L}\p{N}_-]{3,24}$/u.test(String(v || '').normalize('NFKC')); }
function randomHex(bytes = 32) { return crypto.randomBytes(bytes).toString('hex'); }
function passwordHash(password, saltHex) { return crypto.scryptSync(password, Buffer.from(saltHex, 'hex'), 64).toString('hex'); }
function safeEqual(a, b) {
  try { const x = Buffer.from(String(a), 'hex'), y = Buffer.from(String(b), 'hex'); return x.length === y.length && crypto.timingSafeEqual(x, y); }
  catch (_) { return false; }
}
function safeUrl(v) {
  const s = trimText(v, 2000); if (!s) return '';
  try { const u = new URL(s); return ['https:', 'http:'].includes(u.protocol) ? u.href : ''; }
  catch (_) { return ''; }
}
function cookieValue(req, name) {
  const header = req.headers.cookie || '';
  for (const part of header.split(';')) {
    const at = part.indexOf('='); if (at < 0) continue;
    if (part.slice(0, at).trim() === name) return decodeURIComponent(part.slice(at + 1).trim());
  }
  return '';
}
function cookieHeader(token, maxAge) {
  return `${COOKIE_NAME}=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge}${IS_PRODUCTION ? '; Secure' : ''}`;
}
function createSession(res, role, subjectId, username) {
  const token = randomHex(32);
  const ttl = role === 'admin' ? 12 * 60 * 60 * 1000 : 30 * 24 * 60 * 60 * 1000;
  sessions.set(token, { role, subjectId, username, expiresAt: Date.now() + ttl });
  res.setHeader('Set-Cookie', cookieHeader(token, Math.floor(ttl / 1000)));
}
function clearSession(req, res) {
  const token = cookieValue(req, COOKIE_NAME); if (token) sessions.delete(token);
  res.setHeader('Set-Cookie', cookieHeader('', 0));
}
function currentSession(req) {
  const token = cookieValue(req, COOKIE_NAME); if (!token) return null;
  const s = sessions.get(token); if (!s) return null;
  if (s.expiresAt < Date.now()) { sessions.delete(token); return null; }
  return { ...s, token };
}
function requireUser(req, res) {
  const s = currentSession(req);
  if (!s || s.role !== 'user') { fail(res, 401, 'برای ادامه وارد حساب کاربری شو.'); return null; }
  return s;
}
function requireAdmin(req, res) {
  const s = currentSession(req);
  if (!s || s.role !== 'admin') { fail(res, 401, 'نشست مدیر معتبر نیست؛ دوباره وارد پنل شو.'); return null; }
  return s;
}
function rateLimit(req, key, max, periodMs) {
  const trustedForwarded = process.env.TRUST_PROXY === 'true' ? req.headers['x-forwarded-for'] : '';
  const ip = String(trustedForwarded || req.socket.remoteAddress || 'unknown').split(',')[0].trim();
  const now = Date.now(), bucketKey = `${ip}:${key}`;
  const item = rateBuckets.get(bucketKey);
  if (!item || item.resetAt <= now) { rateBuckets.set(bucketKey, { count: 1, resetAt: now + periodMs }); return true; }
  item.count += 1; return item.count <= max;
}
function sameOriginIfProvided(req) {
  const origin = req.headers.origin;
  if (!origin) return true;
  try { const parsed = new URL(origin); return parsed.host === req.headers.host; }
  catch (_) { return false; }
}
function adminConfig() {
  try { return JSON.parse(fs.readFileSync(ADMIN_FILE, 'utf8')); }
  catch (_) { return null; }
}
function isDuplicateQuestion(items, q) {
  const key = `${usernameKey(q.subject)}|${usernameKey(q.q).replace(/\s+/g, ' ')}`;
  return items.some(x => `${usernameKey(x.subject)}|${usernameKey(x.q).replace(/\s+/g, ' ')}` === key);
}
function validQuestion(q) {
  if (!q || typeof q !== 'object') return null;
  const subject = trimText(q.subject, 80), lesson = trimText(q.lesson, 120), question = trimText(q.q, 2500);
  const options = Array.isArray(q.options) ? q.options.slice(0, 4).map(v => trimText(v, 800)) : [];
  const answer = Number(q.answer), difficulty = ['آسان', 'متوسط', 'دشوار'].includes(q.difficulty) ? q.difficulty : 'متوسط';
  if (!subject || !lesson || !question || options.length !== 4 || options.some(v => !v) || !Number.isInteger(answer) || answer < 0 || answer > 3) return null;
  return { id: id('q'), source: 'server', subject, lesson, difficulty, q: question, options, answer, explanation: trimText(q.explanation, 2500), active: q.active !== false, premium: q.premium === true, createdAt: new Date().toISOString() };
}
function safeUser(u) { const premiumUntil = u.premiumUntil || null; return { id: u.id, username: u.username, displayName: u.displayName || u.username, createdAt: u.createdAt, premiumUntil, premium: !!premiumUntil && Date.parse(premiumUntil) > Date.now() }; }
function ticketSummary(t) {
  const messages = t.messages || [];
  return { id: t.id, subject: t.subject, category: t.category, status: t.status, createdAt: t.createdAt, updatedAt: t.updatedAt,
    messages: messages.map(m => ({ id: m.id, from: m.from, text: m.text, createdAt: m.createdAt, readByUser: !!m.readByUser, readByAdmin: !!m.readByAdmin })) };
}
function isPremiumForRequest(req) { const session = currentSession(req); if (!session || session.role !== 'user') return false; const user = db.users.find(u => u.id === session.subjectId); return !!user && !!user.premiumUntil && Date.parse(user.premiumUntil) > Date.now(); }
function publicContent(req) {
  const premium = isPremiumForRequest(req);
  const maySee = item => item.active !== false && (!item.premium || premium);
  return { ads: db.ads.filter(maySee), resources: db.resources.filter(maySee), questions: db.questions.filter(maySee) };
}
function adminContent() { return { ads: db.ads, resources: db.resources, questions: db.questions }; }
function notFound(res) { return fail(res, 404, 'مسیر موردنظر پیدا نشد.'); }

async function handleApi(req, res, url) {
  const pathname = url.pathname;
  const method = req.method || 'GET';
  if (method !== 'GET' && !sameOriginIfProvided(req)) return fail(res, 403, 'درخواست از مبدأ نامعتبر رد شد.');
  let body = {};
  if (!['GET', 'HEAD'].includes(method)) {
    try { body = await readBody(req); }
    catch (e) { return fail(res, e.status || 400, e.message || 'درخواست خوانده نشد.'); }
  }

  if (pathname === '/api/health' && method === 'GET') return json(res, 200, { ok: true, app: 'NoHomYar Pro', time: new Date().toISOString() });
  if (pathname === '/api/content' && method === 'GET') return json(res, 200, publicContent(req));

  if (pathname === '/api/auth/register' && method === 'POST') {
    if (!rateLimit(req, 'register', 8, 60 * 60 * 1000)) return fail(res, 429, 'تلاش‌های ساخت حساب زیاد شده؛ کمی بعد دوباره امتحان کن.');
    const username = trimText(body.username, 24).normalize('NFKC');
    const password = typeof body.password === 'string' ? body.password : '';
    const displayName = trimText(body.displayName, 50) || username;
    if (!validUsername(username)) return fail(res, 400, 'نام کاربری باید ۳ تا ۲۴ نویسه و فقط شامل حروف، عدد، _ یا - باشد.');
    if (usernameKey(username) === 'admin') return fail(res, 400, 'این نام کاربری رزرو شده است.');
    if (password.length < 10 || password.length > 200) return fail(res, 400, 'رمز باید حداقل ۱۰ و حداکثر ۲۰۰ نویسه داشته باشد.');
    if (db.users.some(u => usernameKey(u.username) === usernameKey(username))) return fail(res, 409, 'این نام کاربری قبلاً ثبت شده است.');
    const salt = randomHex(16), user = { id: id('u'), username, displayName, salt, passwordHash: passwordHash(password, salt), createdAt: new Date().toISOString() };
    db.users.push(user); saveDb(db); createSession(res, 'user', user.id, user.username);
    return json(res, 201, { ok: true, user: safeUser(user) });
  }
  if (pathname === '/api/auth/login' && method === 'POST') {
    if (!rateLimit(req, 'user-login', 10, 15 * 60 * 1000)) return fail(res, 429, 'تعداد تلاش برای ورود زیاد است؛ ۱۵ دقیقه بعد دوباره امتحان کن.');
    const username = trimText(body.username, 24), password = typeof body.password === 'string' ? body.password : '';
    const user = db.users.find(u => usernameKey(u.username) === usernameKey(username));
    const test = user ? passwordHash(password, user.salt) : passwordHash(password || 'dummy', '00112233445566778899aabbccddeeff');
    if (!user || !safeEqual(test, user.passwordHash)) return fail(res, 401, 'نام کاربری یا رمز درست نیست.');
    createSession(res, 'user', user.id, user.username);
    return json(res, 200, { ok: true, user: safeUser(user) });
  }
  if (pathname === '/api/auth/logout' && method === 'POST') { clearSession(req, res); return json(res, 200, { ok: true }); }
  if (pathname === '/api/me' && method === 'GET') {
    const s = currentSession(req);
    if (!s || s.role !== 'user') return json(res, 200, { authenticated: false });
    const user = db.users.find(u => u.id === s.subjectId);
    return user ? json(res, 200, { authenticated: true, user: safeUser(user) }) : json(res, 200, { authenticated: false });
  }

  if (pathname === '/api/admin/login' && method === 'POST') {
    if (!rateLimit(req, 'admin-login', 5, 15 * 60 * 1000)) return fail(res, 429, 'ورودهای ناموفق زیاد بوده؛ ۱۵ دقیقه بعد دوباره امتحان کن.');
    const admin = adminConfig();
    if (!admin) return fail(res, 503, 'مدیر هنوز ساخته نشده است. روی سرور دستور node setup.js را اجرا کن.');
    const username = trimText(body.username, 40), password = typeof body.password === 'string' ? body.password : '';
    const hashed = passwordHash(password, admin.salt);
    if (usernameKey(username) !== usernameKey(admin.username) || !safeEqual(hashed, admin.passwordHash)) return fail(res, 401, 'نام کاربری یا رمز مدیریت درست نیست.');
    createSession(res, 'admin', 'administrator', admin.username);
    return json(res, 200, { ok: true, admin: { username: admin.username } });
  }
  if (pathname === '/api/admin/logout' && method === 'POST') {
    const s = currentSession(req); if (s && s.role !== 'admin') return fail(res, 403, 'اجازهٔ این کار را نداری.');
    clearSession(req, res); return json(res, 200, { ok: true });
  }
  if (pathname === '/api/admin/me' && method === 'GET') {
    const s = currentSession(req); return s && s.role === 'admin' ? json(res, 200, { authenticated: true, username: s.username }) : json(res, 200, { authenticated: false });
  }

  if (pathname === '/api/support/tickets' && method === 'GET') {
    const s = requireUser(req, res); if (!s) return;
    let changed = false;
    const tickets = db.tickets.filter(t => t.userId === s.subjectId).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
    for (const t of tickets) for (const m of t.messages) if (m.from === 'admin' && !m.readByUser) { m.readByUser = true; changed = true; }
    if (changed) saveDb(db);
    return json(res, 200, { tickets: tickets.map(ticketSummary) });
  }
  if (pathname === '/api/support/tickets' && method === 'POST') {
    const s = requireUser(req, res); if (!s) return;
    if (!rateLimit(req, 'user-ticket', 5, 60 * 60 * 1000)) return fail(res, 429, 'درخواست‌های پشتیبانی زیادی فرستاده‌ای؛ بعداً دوباره امتحان کن.');
    const subject = trimText(body.subject, 100), text = trimText(body.message, 4000), category = trimText(body.category, 40) || 'عمومی';
    if (subject.length < 3 || text.length < 2) return fail(res, 400, 'موضوع و متن پیام را کامل کن.');
    const ticket = { id: id('t'), userId: s.subjectId, subject, category, status: 'open', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(), messages: [{ id: id('m'), from: 'user', text, createdAt: new Date().toISOString(), readByAdmin: false, readByUser: true }] };
    db.tickets.push(ticket); saveDb(db); return json(res, 201, { ticket: ticketSummary(ticket) });
  }
  const userTicketMessageMatch = pathname.match(/^\/api\/support\/tickets\/([^/]+)\/messages$/);
  if (userTicketMessageMatch && method === 'POST') {
    const s = requireUser(req, res); if (!s) return;
    if (!rateLimit(req, 'user-message', 20, 60 * 1000)) return fail(res, 429, 'پیام‌های زیادی در یک دقیقه فرستاده شده است.');
    const ticket = db.tickets.find(t => t.id === decodeURIComponent(userTicketMessageMatch[1]) && t.userId === s.subjectId);
    if (!ticket) return fail(res, 404, 'گفت‌وگو پیدا نشد.');
    const text = trimText(body.message, 4000); if (text.length < 1) return fail(res, 400, 'متن پیام را وارد کن.');
    ticket.messages.push({ id: id('m'), from: 'user', text, createdAt: new Date().toISOString(), readByAdmin: false, readByUser: true });
    ticket.updatedAt = new Date().toISOString(); ticket.status = 'open'; saveDb(db);
    return json(res, 201, { ticket: ticketSummary(ticket) });
  }

  if (pathname === '/api/admin/tickets' && method === 'GET') {
    const s = requireAdmin(req, res); if (!s) return;
    const status = url.searchParams.get('status') || 'all';
    const tickets = db.tickets.filter(t => status === 'all' || t.status === status)
      .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))
      .map(t => ({ ...ticketSummary(t), username: (db.users.find(u => u.id === t.userId) || {}).username || 'حساب حذف‌شده', unreadByAdmin: t.messages.filter(m => m.from === 'user' && !m.readByAdmin).length }));
    return json(res, 200, { tickets });
  }
  const adminReplyMatch = pathname.match(/^\/api\/admin\/tickets\/([^/]+)\/reply$/);
  if (adminReplyMatch && method === 'POST') {
    const s = requireAdmin(req, res); if (!s) return;
    const ticket = db.tickets.find(t => t.id === decodeURIComponent(adminReplyMatch[1])); if (!ticket) return fail(res, 404, 'گفت‌وگو پیدا نشد.');
    const text = trimText(body.message, 4000); if (!text) return fail(res, 400, 'متن پاسخ را وارد کن.');
    ticket.messages.push({ id: id('m'), from: 'admin', text, createdAt: new Date().toISOString(), readByAdmin: true, readByUser: false });
    ticket.status = 'waiting_user'; ticket.updatedAt = new Date().toISOString(); saveDb(db);
    return json(res, 201, { ticket: ticketSummary(ticket) });
  }
  const adminReadMatch = pathname.match(/^\/api\/admin\/tickets\/([^/]+)\/read$/);
  if (adminReadMatch && method === 'PATCH') {
    const s = requireAdmin(req, res); if (!s) return;
    const ticket = db.tickets.find(t => t.id === decodeURIComponent(adminReadMatch[1])); if (!ticket) return fail(res, 404, 'گفت‌وگو پیدا نشد.');
    let changed = false;
    for (const m of ticket.messages) if (m.from === 'user' && !m.readByAdmin) { m.readByAdmin = true; changed = true; }
    if (changed) saveDb(db);
    return json(res, 200, { ok: true });
  }
  const adminStatusMatch = pathname.match(/^\/api\/admin\/tickets\/([^/]+)\/status$/);
  if (adminStatusMatch && method === 'PATCH') {
    const s = requireAdmin(req, res); if (!s) return;
    const ticket = db.tickets.find(t => t.id === decodeURIComponent(adminStatusMatch[1])); if (!ticket) return fail(res, 404, 'گفت‌وگو پیدا نشد.');
    const status = ['open', 'waiting_user', 'resolved'].includes(body.status) ? body.status : '';
    if (!status) return fail(res, 400, 'وضعیت انتخاب‌شده معتبر نیست.');
    ticket.status = status; ticket.updatedAt = new Date().toISOString(); saveDb(db); return json(res, 200, { ok: true });
  }
  if (pathname === '/api/admin/stats' && method === 'GET') {
    const s = requireAdmin(req, res); if (!s) return;
    return json(res, 200, { users: db.users.length, tickets: db.tickets.length, openTickets: db.tickets.filter(t => t.status !== 'resolved').length, questions: db.questions.length, ads: db.ads.length, resources: db.resources.length });
  }

  if (pathname === '/api/admin/licenses' && method === 'GET') {
    const s = requireAdmin(req, res); if (!s) return;
    return json(res, 200, { licenses: db.licenses.map(x => ({ id: x.id, label: `NH9-••••••••-${x.suffix}`, days: x.days, usesRemaining: x.usesRemaining, active: x.active, createdAt: x.createdAt, redeemedCount: (x.redemptions || []).length })) });
  }
  if (pathname === '/api/admin/licenses' && method === 'POST') {
    const s = requireAdmin(req, res); if (!s) return;
    const count = Math.max(1, Math.min(100, Math.floor(Number(body.count) || 1)));
    const days = Math.max(1, Math.min(3650, Math.floor(Number(body.days) || 30)));
    const codes = [];
    for (let i = 0; i < count; i++) {
      const code = `NH9-${randomHex(4).toUpperCase()}-${randomHex(4).toUpperCase()}`;
      const codeHash = crypto.createHash('sha256').update(code).digest('hex');
      db.licenses.push({ id: id('lic'), codeHash, suffix: code.slice(-4), days, usesRemaining: 1, active: true, createdAt: new Date().toISOString(), redemptions: [] });
      codes.push(code);
    }
    saveDb(db);
    // Raw codes are returned only once to the authenticated administrator.
    return json(res, 201, { ok: true, codes, count, days });
  }
  if (pathname === '/api/premium/redeem' && method === 'POST') {
    const s = requireUser(req, res); if (!s) return;
    if (!rateLimit(req, 'redeem-code', 10, 60 * 60 * 1000)) return fail(res, 429, 'تعداد تلاش برای فعال‌سازی زیاد است؛ کمی بعد دوباره امتحان کن.');
    const code = trimText(body.code, 80).toUpperCase().replace(/\s+/g, '');
    if (!/^NH9-[A-F0-9]{8}-[A-F0-9]{8}$/.test(code)) return fail(res, 400, 'قالب کد فعال‌سازی درست نیست.');
    const codeHash = crypto.createHash('sha256').update(code).digest('hex');
    const license = db.licenses.find(x => x.codeHash === codeHash && x.active && x.usesRemaining > 0);
    if (!license) return fail(res, 400, 'کد فعال‌سازی نامعتبر، مصرف‌شده یا غیرفعال است.');
    const user = db.users.find(u => u.id === s.subjectId); if (!user) return fail(res, 401, 'حساب کاربری پیدا نشد.');
    const current = user.premiumUntil && Date.parse(user.premiumUntil) > Date.now() ? Date.parse(user.premiumUntil) : Date.now();
    user.premiumUntil = new Date(current + license.days * 24 * 60 * 60 * 1000).toISOString();
    license.usesRemaining -= 1; license.redemptions = license.redemptions || []; license.redemptions.push({ userId: user.id, redeemedAt: new Date().toISOString() });
    saveDb(db);
    return json(res, 200, { ok: true, user: safeUser(user) });
  }

  if (pathname === '/api/admin/content' && method === 'GET') {
    const s = requireAdmin(req, res); if (!s) return; return json(res, 200, adminContent());
  }
  if (pathname === '/api/admin/content/ads' && method === 'POST') {
    const s = requireAdmin(req, res); if (!s) return;
    const title = trimText(body.title, 120); if (!title) return fail(res, 400, 'عنوان تبلیغ الزامی است.');
    const ad = { id: id('ad'), title, body: trimText(body.body, 4000), cta: trimText(body.cta, 60) || 'مشاهده', link: safeUrl(body.link), image: safeUrl(body.image), placement: body.placement === 'all' ? 'all' : 'home', active: body.active !== false, createdAt: new Date().toISOString() };
    db.ads.unshift(ad); saveDb(db); return json(res, 201, { ad });
  }
  const adMatch = pathname.match(/^\/api\/admin\/content\/ads\/([^/]+)$/);
  if (adMatch && method === 'DELETE') {
    const s = requireAdmin(req, res); if (!s) return;
    const before = db.ads.length; db.ads = db.ads.filter(a => a.id !== decodeURIComponent(adMatch[1]));
    if (db.ads.length === before) return fail(res, 404, 'تبلیغ پیدا نشد.'); saveDb(db); return json(res, 200, { ok: true });
  }
  if (pathname === '/api/admin/content/resources' && method === 'POST') {
    const s = requireAdmin(req, res); if (!s) return;
    const title = trimText(body.title, 120), text = trimText(body.body, 8000); if (!title || !text) return fail(res, 400, 'عنوان و توضیحات محتوا الزامی است.');
    const resource = { id: id('res'), title, kind: trimText(body.kind, 40) || 'منبع', subject: trimText(body.subject, 80), link: safeUrl(body.link), body: text, active: body.active !== false, premium: body.premium === true, createdAt: new Date().toISOString() };
    db.resources.unshift(resource); saveDb(db); return json(res, 201, { resource });
  }
  const resourceMatch = pathname.match(/^\/api\/admin\/content\/resources\/([^/]+)$/);
  if (resourceMatch && method === 'DELETE') {
    const s = requireAdmin(req, res); if (!s) return;
    const before = db.resources.length; db.resources = db.resources.filter(r => r.id !== decodeURIComponent(resourceMatch[1]));
    if (db.resources.length === before) return fail(res, 404, 'محتوا پیدا نشد.'); saveDb(db); return json(res, 200, { ok: true });
  }
  if (pathname === '/api/admin/content/questions/bulk' && method === 'POST') {
    const s = requireAdmin(req, res); if (!s) return;
    const incoming = Array.isArray(body.questions) ? body.questions : [];
    if (!incoming.length) return fail(res, 400, 'فایل هیچ سؤالی ندارد.');
    if (incoming.length > 5000) return fail(res, 413, 'در هر بار حداکثر ۵۰۰۰ سؤال بارگذاری کن.');
    let invalid = 0, skipped = 0, added = 0;
    for (const original of incoming) {
      const q = validQuestion(original); if (!q) { invalid++; continue; }
      if (isDuplicateQuestion(db.questions, q)) { skipped++; continue; }
      db.questions.push(q); added++;
    }
    if (added) saveDb(db);
    return json(res, 201, { ok: true, added, skipped, invalid, total: db.questions.length });
  }
  const questionMatch = pathname.match(/^\/api\/admin\/content\/questions\/([^/]+)$/);
  if (questionMatch && method === 'DELETE') {
    const s = requireAdmin(req, res); if (!s) return;
    const before = db.questions.length; db.questions = db.questions.filter(q => q.id !== decodeURIComponent(questionMatch[1]));
    if (db.questions.length === before) return fail(res, 404, 'سؤال پیدا نشد.'); saveDb(db); return json(res, 200, { ok: true });
  }
  return notFound(res);
}

const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.ico': 'image/x-icon' };
function serveStatic(req, res, url) {
  let pathname = decodeURIComponent(url.pathname);
  if (pathname === '/') pathname = '/index.html';
  const file = path.resolve(PUBLIC_DIR, '.' + pathname);
  if (!file.startsWith(PUBLIC_DIR + path.sep) && file !== path.join(PUBLIC_DIR, 'index.html')) return fail(res, 403, 'دسترسی رد شد.');
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) return fail(res, 404, 'صفحه پیدا نشد.');
    const headers = {
      'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream',
      'X-Content-Type-Options': 'nosniff',
      'X-Frame-Options': 'DENY',
      'Referrer-Policy': 'strict-origin-when-cross-origin',
      'Content-Security-Policy': "default-src 'self'; img-src 'self' data: https: http:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'",
      'Cache-Control': pathname === '/index.html' ? 'no-cache' : 'public, max-age=3600',
    };
    res.writeHead(200, headers);
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(file).pipe(res);
  });
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    if (url.pathname.startsWith('/api/')) return await handleApi(req, res, url);
    if (!['GET', 'HEAD'].includes(req.method)) return fail(res, 405, 'این روش مجاز نیست.');
    return serveStatic(req, res, url);
  } catch (err) {
    console.error('Request failed:', err.message);
    if (!res.headersSent) fail(res, err.status || 500, err.status ? err.message : 'خطای داخلی سرور.');
    else res.destroy();
  }
});

server.listen(PORT, HOST, () => {
  console.log('╭──────────────────────────────────────────────╮');
  console.log('│  NoHomYar Pro — server edition                │');
  console.log(`│  Local:  http://localhost:${PORT}`.padEnd(47) + '│');
  console.log('│  Data directory is outside the public folder. │');
  console.log('╰──────────────────────────────────────────────╯');
  if (!adminConfig()) console.warn('⚠️ مدیر هنوز ساخته نشده: ابتدا سرور را متوقف و node setup.js را اجرا کن.');
  if (process.env.NODE_ENV === 'production') console.log('🔒 Secure cookies enabled; put this server behind HTTPS.');
});

function shutdown() { try { saveDb(db); } catch (e) { console.error('Could not persist DB:', e.message); } server.close(() => process.exit(0)); setTimeout(() => process.exit(0), 3000).unref(); }
process.on('SIGINT', shutdown); process.on('SIGTERM', shutdown);
