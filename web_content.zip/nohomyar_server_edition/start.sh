#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
DATA_PATH="${DATA_DIR:-$PWD/data}"
if [ ! -f "$DATA_PATH/admin.json" ]; then
  node setup.js
fi
exec node server.js
