'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const readline = require('node:readline');
const DATA_DIR = path.resolve(process.env.DATA_DIR || path.join(__dirname, 'data'));
const ADMIN_FILE = path.join(DATA_DIR, 'admin.json');
let rl = null;
function makeRl() { rl = readline.createInterface({ input: process.stdin, output: process.stdout }); return rl; }
async function ask(question) { if (!rl) makeRl(); return rl.question(question); }
async function askHidden(question) {
  if (rl) { rl.close(); rl = null; }
  if (!process.stdin.isTTY || typeof process.stdin.setRawMode !== 'function') {
    console.warn('ورودی این ترمینال امن/مخفی نیست؛ هنگام تایپ رمز آن را در صفحه می‌بینی.');
    return ask(question);
  }
  process.stdout.write(question);
  const input = process.stdin;
  input.setRawMode(true); input.resume(); input.setEncoding('utf8');
  let value = '';
  return new Promise((resolve, reject) => {
    const onData = ch => {
      if (ch === '\u0003') { cleanup(); process.stdout.write('\n'); reject(new Error('لغو شد.')); return; }
      if (ch === '\r' || ch === '\n') { cleanup(); process.stdout.write('\n'); resolve(value); return; }
      if (ch === '\u0008' || ch === '\u007f') value = value.slice(0, -1);
      else if (ch >= ' ' && ch !== '\u001b') value += ch;
    };
    function cleanup() { input.removeListener('data', onData); input.setRawMode(false); input.pause(); }
    input.on('data', onData);
  });
}
function passwordHash(password, saltHex) { return crypto.scryptSync(password, Buffer.from(saltHex, 'hex'), 64).toString('hex'); }
async function main() {
  fs.mkdirSync(DATA_DIR, { recursive: true, mode: 0o700 });
  if (fs.existsSync(ADMIN_FILE) && process.env.RESET_ADMIN !== 'true') {
    const answer = (await ask('مدیر قبلاً ساخته شده است. برای تغییر نام کاربری/رمز، بنویس YES: ')).trim();
    if (answer !== 'YES') { console.log('تغییری انجام نشد.'); if (rl) rl.close(); return; }
  }
  let username = process.env.ADMIN_USERNAME || (await ask('نام کاربری مدیر (پیشنهاد: owner): ')).trim();
  username = username.normalize('NFKC');
  if (!/^[\p{L}\p{N}_-]{3,40}$/u.test(username)) throw new Error('نام کاربری باید ۳ تا ۴۰ نویسه و بدون فاصله باشد.');
  let password = process.env.ADMIN_PASSWORD;
  if (!password) {
    password = await askHidden('رمز مدیریت (حداقل ۱۴ نویسه؛ تایپ پنهان است): ');
    const again = await askHidden('تکرار رمز مدیریت: ');
    if (password !== again) throw new Error('رمزها یکسان نیستند.');
  }
  if (password.length < 14 || password.length > 200) throw new Error('رمز مدیریت باید حداقل ۱۴ و حداکثر ۲۰۰ نویسه باشد.');
  const salt = crypto.randomBytes(16).toString('hex');
  const record = { username, salt, passwordHash: passwordHash(password, salt), changedAt: new Date().toISOString() };
  const tmp = ADMIN_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(record, null, 2), { mode: 0o600 });
  fs.renameSync(tmp, ADMIN_FILE);
  try { fs.chmodSync(ADMIN_FILE, 0o600); } catch (_) {}
  console.log('\n✅ حساب مدیریت آماده است.');
  console.log(`نام کاربری: ${record.username}`);
  console.log('رمز خام ذخیره نشده و فقط هش امن آن نگهداری می‌شود.');
  console.log('حالا با دستور node server.js برنامه را اجرا کن.');
  if (rl) rl.close();
}
main().catch(err => { console.error('خطا:', err.message); if (rl) rl.close(); process.exitCode = 1; });
