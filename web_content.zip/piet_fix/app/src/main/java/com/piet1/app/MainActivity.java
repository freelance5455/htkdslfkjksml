package com.piet1.app;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private PietView pietView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window w = getWindow();
        w.setStatusBarColor(Color.BLACK);
        w.setNavigationBarColor(Color.BLACK);
        w.getDecorView().setSystemUiVisibility(0);
        pietView = new PietView();
        setContentView(pietView);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (pietView != null) {
            pietView.startClock();
            pietView.invalidate();
        }
    }

    @Override
    protected void onPause() {
        if (pietView != null) pietView.stopClock();
        super.onPause();
    }

    @Override
    public void onBackPressed() {
        if (pietView.isMess()) {
            pietView.showHome();
        } else if (pietView.isExitVisible()) {
            pietView.hideExit();
        } else {
            pietView.showExit();
        }
    }

    private class PietView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Handler handler = new Handler();
        private final SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.ENGLISH);
        private final SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm:ss a", Locale.ENGLISH);
        private Bitmap home, mess, splash;
        private int page = 0; // 0 home, 1 mess
        private boolean splashVisible = true, loading = false, exitVisible = false;
        private final Runnable clockTick = new Runnable() { public void run() { invalidate(); handler.postDelayed(this, 1000); } };

        PietView() {
            super(MainActivity.this);
            setBackgroundColor(Color.BLACK);
            home = load("home_bg.jpg");
            mess = load("mess_exact.jpg");
            splash = load("splash_bg.jpg");
            handler.postDelayed(() -> { splashVisible = false; invalidate(); }, 1200);
            startClock();
        }

        void startClock() {
            handler.removeCallbacks(clockTick);
            handler.post(clockTick);
        }

        void stopClock() {
            handler.removeCallbacks(clockTick);
        }

        private Bitmap load(String name) {
            try (InputStream in = getAssets().open("www/" + name)) {
                return BitmapFactory.decodeStream(in);
            } catch (IOException e) { return null; }
        }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            Bitmap b = page == 1 ? mess : home;
            if (splashVisible && splash != null) b = splash;
            if (b != null) c.drawBitmap(b, null, new Rect(0, 0, getWidth(), getHeight()), paint);

            if (page == 1 && !splashVisible) drawClock(c);
            if (loading) drawLoading(c);
            if (exitVisible) drawExit(c);
        }

        private void drawClock(Canvas c) {
            long now = System.currentTimeMillis();
            Date d = new Date(now);
            String date = dateFormat.format(d);
            String time = timeFormat.format(d);
            float sx = getWidth() / 720f, sy = getHeight() / 1472f;
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTypeface(android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD));
            paint.setTextSize(26 * sx);
            paint.setColor(Color.rgb(155,165,175));
            c.drawText(date, 360*sx, 1043*sy, paint);
            paint.setTextSize(39 * sx);
            paint.setColor(Color.rgb(21,153,146));
            c.drawText(time, 360*sx, 1208*sy, paint);
        }

        private void drawLoading(Canvas c) {
            paint.setColor(0x99000000); c.drawRect(0,0,getWidth(),getHeight(),paint);
            float sx=getWidth()/720f, sy=getHeight()/1472f;
            float l=79*sx, t=636*sy, r=641*sx, b=836*sy;
            paint.setColor(Color.WHITE); c.drawRoundRect(l,t,r,b,12*sx,12*sy,paint);
            paint.setColor(Color.BLACK); paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(4*sx);
            c.drawCircle(245*sx,736*sy,22*sx,paint); paint.setStyle(Paint.Style.FILL);
            paint.setTextAlign(Paint.Align.LEFT); paint.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); paint.setTextSize(31*sx);
            c.drawText("Please wait...", 310*sx, 747*sy, paint);
        }

        private void drawExit(Canvas c) {
            paint.setColor(0x1A000000); c.drawRect(0,0,getWidth(),getHeight(),paint);
            float sx=getWidth()/720f, sy=getHeight()/1472f;
            float l=90*sx,t=604*sy,r=630*sx,b=864*sy;
            paint.setColor(0xE8FFFFFF); c.drawRoundRect(l,t,r,b,26*sx,26*sy,paint);
            paint.setTextAlign(Paint.Align.CENTER); paint.setColor(Color.BLACK); paint.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); paint.setTextSize(31*sx);
            c.drawText("Exit",360*sx,688*sy,paint);
            paint.setTypeface(android.graphics.Typeface.DEFAULT); paint.setTextSize(26*sx); paint.setColor(Color.GRAY);
            c.drawText("Are you sure want to exit?",360*sx,748*sy,paint);
            paint.setTextSize(29*sx); paint.setColor(Color.rgb(233,142,142));
            c.drawText("No",205*sx,820*sy,paint); paint.setColor(Color.rgb(115,174,234)); c.drawText("Yes",515*sx,820*sy,paint);
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            if (e.getAction()!=MotionEvent.ACTION_UP) return true;
            float x=e.getX(), y=e.getY(), sx=getWidth()/720f, sy=getHeight()/1472f;
            if (exitVisible) {
                if (y > 780*sy && y < 870*sy) {
                    if (x < 360*sx) hideExit(); else finish();
                }
                return true;
            }
            if (splashVisible) return true;
            if (page==1) {
                if (x < 110*sx && y < 115*sy) showHome();
                return true;
            }
            // Home: the bottom-right tile opens Mess Pass.
            if (x >= 488*sx && y >= 1065*sy && y <= 1265*sy) showMess();
            return true;
        }

        void showMess() {
            loading=true; invalidate();
            handler.postDelayed(() -> { loading=false; page=1; invalidate(); }, 850);
        }
        void showHome(){page=0; loading=false; exitVisible=false; invalidate();}
        void showExit(){exitVisible=true; invalidate();}
        void hideExit(){exitVisible=false; invalidate();}
        boolean isMess(){return page==1;}
        boolean isExitVisible(){return exitVisible;}

        @Override protected void onDetachedFromWindow(){ handler.removeCallbacksAndMessages(null); super.onDetachedFromWindow(); }
    }
}
