PIET-1 Device-Compatible Replica

This version uses native Android Canvas rendering (no WebView/appassets URL), so it does not depend on appassets.androidplatform.net.

Mess Pass:
- Hostel: SARDAR BHAWAN A
- Date: device-local date, DD-MM-YYYY
- Time: device-local 12-hour time with seconds (HH:MM:SS AM/PM)
- Clock refreshes every second and resumes correctly after returning to the app.

Build in Android Studio and install the generated PIET-1.apk.
