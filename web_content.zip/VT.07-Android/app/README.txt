VT.07 Android

Atualização visual:
- Nome do aplicativo: VT.07
- Logo/arte do VT.07 usada na tela inicial e como ícone do aplicativo.
- A interface continua em WebView.

Para usar saques Pix reais, hospede o servidor Node do pacote VT.07-Web em HTTPS e altere MainActivity.java para carregar a URL HTTPS do seu servidor em vez do arquivo local.

Nunca coloque BRLPAY_TOKEN, BRLPAY_CLIENT_ID ou qualquer segredo de API dentro do APK.
