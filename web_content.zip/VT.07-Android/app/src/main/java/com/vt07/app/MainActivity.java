package com.vt07.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.PermissionRequest;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        WebView web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient(){ @Override public void onPermissionRequest(final PermissionRequest request){runOnUiThread(()->request.grant(request.getResources()));} });
        // Change this URL to the address where the VT.07 Node server is hosted.
        // The bundled interface is used here so the app can open immediately.
        // Para produção, troque pela URL HTTPS pública do VT.07-Web:
        // web.loadUrl("https://SEU-DOMINIO.com/");
        web.loadUrl("file:///android_asset/index.html");
    }
}
