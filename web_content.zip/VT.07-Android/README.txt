# VT.07 Android

Projeto Android Studio pronto para gerar o APK do VT.07.

IMPORTANTE:
- Este projeto inclui a interface do VT.07 e a foto enviada.
- O backend Node.js/SQLite do site continua sendo necessário para cadastro, saldo e saques reais.
- O APK não foi compilado aqui porque este ambiente não possui Android SDK/Gradle instalado.
- Para conectar ao backend, altere `web.loadUrl(...)` em `MainActivity.java` para a URL HTTPS do servidor.
