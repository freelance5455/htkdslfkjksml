package com.orderix.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.text.InputType;
import java.security.MessageDigest;

public class MainActivity extends Activity {
    private static final String PASSWORD_HASH = "a075cae3c414814792ad164d23f2793b0b4a3091cfbc387da5fc0f0936cd8d78";
    private WebView web;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        showPassword();
    }

    private void showPassword() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(36, 36, 36, 36);
        box.setBackgroundColor(Color.WHITE);
        TextView title = new TextView(this);
        title.setText("ORDERIX");
        title.setTextSize(28);
        title.setTextColor(Color.BLACK);
        title.setGravity(Gravity.CENTER);
        EditText pass = new EditText(this);
        pass.setHint("أدخل كلمة المرور");
        pass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        Button enter = new Button(this);
        enter.setText("دخول");
        box.addView(title);
        box.addView(pass);
        box.addView(enter);
        setContentView(box);
        enter.setOnClickListener(v -> {
            if (sha256(pass.getText().toString()).equals(PASSWORD_HASH)) openApp();
            else Toast.makeText(this, "كلمة المرور غير صحيحة", Toast.LENGTH_SHORT).show();
        });
    }

    private String sha256(String s) {
        try {
            byte[] d = MessageDigest.getInstance("SHA-256").digest(s.getBytes("UTF-8"));
            StringBuilder out = new StringBuilder();
            for (byte b : d) out.append(String.format("%02x", b));
            return out.toString();
        } catch (Exception e) { return ""; }
    }

    private void openApp() {
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setBackgroundColor(Color.WHITE);
        web.setWebViewClient(new WebViewClient());
        setContentView(web);
        web.loadUrl("file:///android_asset/ORDERIX.html");
        startService(new Intent(this, BubbleService.class));
        if (getIntent().getBooleanExtra("open_add", false)) {
            web.postDelayed(() -> openOrderEntry(), 900);
        }
    }

    public void openOrderEntry() {
        if (web == null) return;
        web.evaluateJavascript("(function(){ if(typeof openOrderModal==='function') openOrderModal(); var k=document.getElementById('inp-km'); if(k) k.focus(); })()", null);
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent.getBooleanExtra("open_add", false)) {
            if (web == null) showPassword();
            else web.postDelayed(() -> openOrderEntry(), 300);
        }
    }
}
