# CPLS V2 — Stage 1151
## Futures Candle Source Adapter
- Adds a small WebView-side source/capability adapter.
- Future real-candle providers can advertise `candleSource=real` without changing chart rendering logic.
- Current behavior remains LBank sampled Last Price aggregation.
