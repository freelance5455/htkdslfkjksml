
/* =========================================
   SKIPTRACK — STORAGE
   Penyimpanan lokal menggunakan localStorage
========================================= */

(function () {
  "use strict";

  const SESSIONS_KEY = "skiptrack_sessions_v1";
  const SETTINGS_KEY = "skiptrack_settings_v1";

  function readJSON(key, fallback) {
    try {
      const value = localStorage.getItem(key);
      if (value === null) return fallback;

      const parsed = JSON.parse(value);
      return parsed ?? fallback;
    } catch (error) {
      console.error("SkipTrack: gagal membaca data", error);
      return fallback;
    }
  }

  function writeJSON(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (error) {
      console.error("SkipTrack: gagal menyimpan data", error);
      return false;
    }
  }

  function makeId() {
    if (window.crypto && typeof window.crypto.randomUUID === "function") {
      return window.crypto.randomUUID();
    }

    return "session-" + Date.now() + "-" +
      Math.random().toString(36).slice(2, 10);
  }

  function localDateKey(date = new Date()) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");

    return `${year}-${month}-${day}`;
  }

  function normalizeSession(session) {
    if (!session || typeof session !== "object") return null;

    const jumps = Math.max(0, Math.floor(Number(session.jumps) || 0));
    const durationSeconds = Math.max(
      0,
      Math.floor(
        Number(session.durationSeconds ?? session.duration) || 0
      )
    );

    const createdAt = session.createdAt || session.startedAt || Date.now();
    const dateObject = new Date(createdAt);

    if (Number.isNaN(dateObject.getTime())) return null;

    return {
      id: String(session.id || makeId()),
      date: session.date || localDateKey(dateObject),
      createdAt,
      startedAt: session.startedAt || createdAt,
      durationSeconds,
      jumps,
      targetMinutes: Math.max(0, Number(session.targetMinutes) || 0),
      targetJumps: Math.max(0, Number(session.targetJumps) || 0)
    };
  }

  function getSessions() {
    const raw = readJSON(SESSIONS_KEY, []);

    if (!Array.isArray(raw)) return [];

    return raw
      .map(normalizeSession)
      .filter(Boolean)
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  }

  function saveSession(session) {
    const normalized = normalizeSession({
      ...session,
      id: session && session.id ? session.id : makeId(),
      createdAt: session && session.createdAt
        ? session.createdAt
        : Date.now()
    });

    if (!normalized) return false;

    const sessions = getSessions();
    const index = sessions.findIndex(item => item.id === normalized.id);

    if (index >= 0) {
      sessions[index] = normalized;
    } else {
      sessions.push(normalized);
    }

    return writeJSON(SESSIONS_KEY, sessions);
  }

  function deleteSession(id) {
    const sessions = getSessions();
    const filtered = sessions.filter(item => item.id !== String(id));

    if (filtered.length === sessions.length) return false;

    return writeJSON(SESSIONS_KEY, filtered);
  }

  function clearSessions() {
    return writeJSON(SESSIONS_KEY, []);
  }

  function getSettings() {
    const defaults = {
      targetMinutes: 5,
      targetJumps: 500
    };

    const stored = readJSON(SETTINGS_KEY, {});

    return {
      targetMinutes: clampNumber(stored.targetMinutes, 1, 240, defaults.targetMinutes),
      targetJumps: clampNumber(stored.targetJumps, 0, 1000000, defaults.targetJumps)
    };
  }

  function saveSettings(settings) {
    const current = getSettings();

    const next = {
      targetMinutes: clampNumber(
        settings && settings.targetMinutes,
        1,
        240,
        current.targetMinutes
      ),
      targetJumps: clampNumber(
        settings && settings.targetJumps,
        0,
        1000000,
        current.targetJumps
      )
    };

    return writeJSON(SETTINGS_KEY, next);
  }

  function clampNumber(value, min, max, fallback) {
    const number = Number(value);

    if (!Number.isFinite(number)) return fallback;

    return Math.min(max, Math.max(min, Math.floor(number)));
  }

  function getTodaySessions() {
    const today = localDateKey();
    return getSessions().filter(session => session.date === today);
  }

  function getStats() {
    const sessions = getSessions();
    const todaySessions = getTodaySessions();

    const sum = (items, field) =>
      items.reduce((total, item) => total + (Number(item[field]) || 0), 0);

    const bestJumps = sessions.reduce(
      (best, item) => Math.max(best, item.jumps),
      0
    );

    const bestDuration = sessions.reduce(
      (best, item) => Math.max(best, item.durationSeconds),
      0
    );

    return {
      sessions,
      todaySessions,
      totalSessions: sessions.length,
      totalJumps: sum(sessions, "jumps"),
      totalDurationSeconds: sum(sessions, "durationSeconds"),
      todayJumps: sum(todaySessions, "jumps"),
      todayDurationSeconds: sum(todaySessions, "durationSeconds"),
      todaySessionsCount: todaySessions.length,
      bestJumps,
      bestDurationSeconds: bestDuration
    };
  }

  window.SkipTrackStorage = Object.freeze({
    getSessions,
    saveSession,
    deleteSession,
    clearSessions,
    getSettings,
    saveSettings,
    getTodaySessions,
    getStats,
    localDateKey
  });
})();
