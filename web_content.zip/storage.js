// مفتاح التخزين في المتصفح
const STORAGE_KEY = 'warranty_devices_data';

// دالة لجلب كل الأجهزة
function getDevices() {
  const data = localStorage.getItem(STORAGE_KEY);
  return data ? JSON.parse(data) : [];
}

// دالة لحفظ جهاز جديد أو تعديل جهاز موجود
function saveDevice(device) {
  let devices = getDevices();
  
  if (device.id) {
    // تعديل جهاز موجود
    const index = devices.findIndex(d => d.id === device.id);
    if (index !== -1) {
      devices[index] = device;
    }
  } else {
    // إضافة جهاز جديد (بنعمل له ID فريد باستخدام الوقت)
    device.id = Date.now().toString();
    devices.push(device);
  }
  
  localStorage.setItem(STORAGE_KEY, JSON.stringify(devices));
  return device;
}

// دالة لجلب جهاز واحد بالـ ID
function getDeviceById(id) {
  const devices = getDevices();
  return devices.find(d => d.id === id);
}

// دالة لحذف جهاز
function deleteDevice(id) {
  let devices = getDevices();
  devices = devices.filter(d => d.id !== id);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(devices));
}