'use strict';
(() => {
  const $ = id => document.getElementById(id);
  const API = 'https://api.sharkexchange.in/v1/market/klines?priceType=MARK_PRICE';
  const SOCKET_URL = 'https://fawss.sharkexchange.in/';
  const INTERVALS = ['3m','5m','15m'];
  const state = { pair:'BTCINR', price:null, candles:{}, socket:null, timer:null, lastSocketAt:0, generation:0 };
  const fmt = n => Number.isFinite(Number(n)) ? Number(n).toLocaleString('en-IN',{maximumFractionDigits:4}) : '—';
  const setText = (id, value) => { $(id).textContent = value; };
  function status(message){ setText('status', message); }
  function setSignal(id, signal){ const el=$(id); el.textContent=signal; el.className=signal==='BUY'?'buy':signal==='SELL'?'sell':'wait'; }
  function unwrap(payload){
    let x=payload;
    for(let i=0;i<4;i++){
      if(Array.isArray(x)) return x;
      if(!x || typeof x!=='object') return [];
      if(Array.isArray(x.data)) return x.data;
      if(Array.isArray(x.result)) return x.result;
      if(Array.isArray(x.klines)) return x.klines;
      if(Array.isArray(x.rows)) return x.rows;
      if(x.data && typeof x.data==='object'){ x=x.data; continue; }
      return [];
    }
    return [];
  }
  function normalizeCandle(c){
    if(Array.isArray(c)) return {time:+c[0],open:+c[1],high:+c[2],low:+c[3],close:+c[4],volume:+c[5]||0};
    if(!c || typeof c!=='object') return null;
    const pick=(...keys)=>{for(const k of keys) if(c[k]!==undefined&&c[k]!==null)return c[k];return NaN;};
    const v={time:+pick('startTime','openTime','time','t','timestamp'),open:+pick('open','o'),high:+pick('high','h'),low:+pick('low','l'),close:+pick('close','c','markPrice','price'),volume:+pick('volume','v','baseVolume')||0};
    return [v.open,v.high,v.low,v.close].every(Number.isFinite)?v:null;
  }
  async function fetchCandles(interval, generation){
    const response=await fetch(API,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({pair:state.pair,interval,limit:200}),cache:'no-store'});
    if(!response.ok) throw new Error(`REST ${response.status} (${interval})`);
    const payload=await response.json();
    if(payload && payload.success===false) throw new Error(payload.message||payload.msg||'API returned success=false');
    const rows=unwrap(payload).map(normalizeCandle).filter(c=>c&&Number.isFinite(c.close)&&c.close>0).sort((a,b)=>(a.time||0)-(b.time||0));
    if(generation!==state.generation)return;
    if(rows.length<55) throw new Error(`Only ${rows.length} valid ${interval} candles returned; need at least 55`);
    state.candles[interval]=rows;
  }
  function ema(values, period){if(values.length<period)return NaN;const k=2/(period+1);let out=values.slice(0,period).reduce((a,b)=>a+b,0)/period;for(let i=period;i<values.length;i++)out=values[i]*k+out*(1-k);return out;}
  function rsi(values, period=14){if(values.length<=period)return NaN;let gain=0,loss=0;for(let i=1;i<=period;i++){const d=values[i]-values[i-1];if(d>0)gain+=d;else loss-=d;}let ag=gain/period,al=loss/period;for(let i=period+1;i<values.length;i++){const d=values[i]-values[i-1];ag=(ag*(period-1)+Math.max(d,0))/period;al=(al*(period-1)+Math.max(-d,0))/period;}return al===0?100:100-100/(1+ag/al);}
  function atr(candles,period=14){if(candles.length<=period)return NaN;const tr=[];for(let i=1;i<candles.length;i++){const c=candles[i],p=candles[i-1];tr.push(Math.max(c.high-c.low,Math.abs(c.high-p.close),Math.abs(c.low-p.close)));}return tr.slice(-period).reduce((a,b)=>a+b,0)/period;}
  function analyze(interval){const candles=state.candles[interval]||[];if(candles.length<55)return {signal:'WAIT',reason:'Not enough candles'};const closes=candles.map(c=>c.close), last=closes.at(-1), e9=ema(closes,9),e21=ema(closes,21),e50=ema(closes,50),rv=rsi(closes), fast=ema(closes,12),slow=ema(closes,26),macd=fast-slow;const hist=macd-ema(closes.map((_,i)=>ema(closes.slice(0,i+1),12)-ema(closes.slice(0,i+1),26)).filter(Number.isFinite),9);const volumeNow=candles.at(-1).volume, volumeAvg=candles.slice(-21,-1).reduce((s,c)=>s+c.volume,0)/20;const volumeOK=volumeNow===0||volumeAvg===0||volumeNow>=volumeAvg*.8;let score=0;if(last>e9)score++;else score--;if(e9>e21)score++;else score--;if(e21>e50)score++;else score--;if(rv>=52&&rv<70)score++;else if(rv<48&&rv>30)score--;if(hist>0)score++;else if(hist<0)score--;let signal='WAIT';if(score>=4&&rv<70&&volumeOK)signal='BUY';if(score<=-4&&rv>30&&volumeOK)signal='SELL';return {signal,last,e9,e21,e50,rv,hist,atr:atr(candles),volumeNow,volumeAvg,volumeOK,score,reason:`score ${score}; RSI ${rv.toFixed(1)}; ${volumeOK?'volume confirmed':'weak volume'}`};}
  function updateUI(){
    const a3=analyze('3m'),a5=analyze('5m'),a15=analyze('15m');setSignal('sig3',a3.signal);setSignal('sig5',a5.signal);setSignal('sig15',a15.signal);
    const agree=a5.signal===a15.signal&&a5.signal!=='WAIT';const confirm=a3.signal===a5.signal;const final=agree&&confirm?a5.signal:'WAIT';setSignal('finalSignal',final);setText('signalReason',final==='WAIT'?'5m + 15m must agree; 3m confirms direction':`5m and 15m agree; 3m confirms ${final}`);
    if(Number.isFinite(state.price))setText('price',fmt(state.price));else if(Number.isFinite(a5.last))setText('price',fmt(a5.last));
    if(Number.isFinite(a5.e9))setText('ema',`${fmt(a5.e9)} / ${fmt(a5.e21)} / ${fmt(a5.e50)}`);setText('rsi',Number.isFinite(a5.rv)?a5.rv.toFixed(2):'—');setText('macd',fmt(a5.hist));setText('atr',fmt(a5.atr));setText('volume',a5.volumeOK?'Normal / confirmed':'Below average');
    const entry=Number.isFinite(state.price)?state.price:a5.last;const range=a5.atr; if(Number.isFinite(entry)&&Number.isFinite(range)&&range>0&&final!=='WAIT'){const long=final==='BUY';setText('entry',fmt(entry));setText('sl',fmt(entry+(long?-1:1)*1.5*range));setText('tp1',fmt(entry+(long?1:-1)*1.5*range));setText('tp2',fmt(entry+(long?1:-1)*2.5*range));}else{['entry','sl','tp1','tp2'].forEach(id=>setText(id,'—'));}
    setText('updated','Updated '+new Date().toLocaleTimeString('en-IN',{timeZone:'Asia/Kolkata'})+' IST');
  }
  function parsePrice(payload){let d=payload?.data??payload; if(Array.isArray(d))d=d.find(x=>String(x.s||x.symbol||x.pair||'').toUpperCase()===state.pair)||d[0];if(typeof d==='string'){try{d=JSON.parse(d)}catch{return NaN}}if(!d||typeof d!=='object')return NaN;for(const k of ['markPrice','price','p','lastPrice','c','close']){const n=Number(d[k]);if(Number.isFinite(n)&&n>0)return n;}return NaN;}
  function connectSocket(){if(!window.io){setText('socketStatus','Socket.IO client did not load; REST polling will still be used.');return;}try{if(state.socket)state.socket.disconnect();const socket=io(SOCKET_URL,{transports:['websocket','polling'],reconnection:true,reconnectionAttempts:Infinity,timeout:12000});state.socket=socket;socket.on('connect',()=>{setText('socketStatus','Socket.IO connected · '+socket.id);$('connection').textContent='Socket connected';$('connection').className='pill ok';const p=state.pair.toLowerCase();socket.emit('subscribe',{params:[`${p}@markPrice`,`${p}@ticker`,...INTERVALS.map(i=>`${p}@kline_${i}`)]});});socket.on('connect_error',e=>{setText('socketStatus','Socket error: '+(e.message||'connection failed')+'; REST polling active');});socket.on('disconnect',reason=>{setText('socketStatus','Socket disconnected: '+reason+'; reconnecting');});const onPrice=data=>{const n=parsePrice(data);if(Number.isFinite(n)){state.price=n;state.lastSocketAt=Date.now();updateUI();}};socket.on('markPriceUpdate',onPrice);socket.on('markPriceArr',onPrice);socket.on('24hrTicker',onPrice);socket.on('tickerArr',onPrice);socket.on('kline',data=>{const raw=data?.data??data;const pair=String(raw?.s||raw?.pair||raw?.symbol||state.pair).toUpperCase();if(pair!==state.pair)return;const interval=String(raw?.interval||raw?.i||raw?.k?.i||'');const candle=normalizeCandle(raw?.k||raw);if(candle&&interval&&INTERVALS.includes(interval)){const arr=state.candles[interval]||[];const t=candle.time;const idx=arr.findIndex(x=>x.time===t);if(idx>=0)arr[idx]=candle;else arr.push(candle);arr.sort((a,b)=>(a.time||0)-(b.time||0));state.candles[interval]=arr.slice(-250);updateUI();}});}catch(e){setText('socketStatus','Socket setup failed: '+e.message);}}
  async function refresh(){const gen=++state.generation;state.pair=$('pair').value;state.price=null;state.candles={};setText('restStatus','REST candles: fetching 3m, 5m and 15m…');setText('price','—');setSignal('finalSignal','WAIT');status('Fetching public Shark Exchange market candles…');$('connection').textContent='Fetching data…';$('connection').className='pill idle';try{const results=await Promise.allSettled(INTERVALS.map(i=>fetchCandles(i,gen)));if(gen!==state.generation)return;const errors=[];results.forEach((r,i)=>{if(r.status==='rejected')errors.push(`${INTERVALS[i]}: ${r.reason.message}`)});const ok=INTERVALS.filter(i=>(state.candles[i]||[]).length>=55);if(ok.length){setText('restStatus',`REST candles: OK · ${ok.map(i=>i+': '+state.candles[i].length).join(' · ')}`);$('connection').textContent=errors.length?'Partial data':'REST connected';$('connection').className=errors.length?'pill idle':'pill ok';updateUI();status(errors.length?'Some intervals failed. '+errors.join(' | '):'Shark Exchange REST market data loaded successfully.');}else{setText('restStatus','REST candles failed: '+errors.join(' | '));$('connection').textContent='API error';$('connection').className='pill bad';status('No candles received. This can be caused by network/CORS blocking, API outage, unsupported pair, or a changed response format. Try serving the files over HTTPS and check browser console.');}}catch(e){setText('restStatus','REST error: '+e.message);status('Request failed: '+e.message);} }
  function restart(){connectSocket();refresh();}
  $('pair').addEventListener('change',restart);$('refresh').addEventListener('click',refresh);$('retry').addEventListener('click',restart);connectSocket();refresh();state.timer=setInterval(()=>{if(Date.now()-state.lastSocketAt>15000)refresh();},30000);
})();
