SHARK EXCHANGE LIVE CRYPTO ANALYZER

Files: index.html, style.css, script.js

API details follow Shark Exchange's public documentation:
- REST: POST https://api.sharkexchange.in/v1/market/klines?priceType=MARK_PRICE
- Body example: {"pair":"BTCINR","interval":"5m","limit":200}
- Public Socket.IO: https://fawss.sharkexchange.in/
- Topics: pair@markPrice, pair@ticker, pair@kline_3m, pair@kline_5m, pair@kline_15m

HOW TO RUN
1. Extract this ZIP.
2. Open the folder in SPCK Editor.
3. Preview/serve index.html over HTTPS or a local web server. Do not rely on file:// if requests fail.
4. Allow internet access. Socket.IO client is loaded from a CDN.
5. Use the status/diagnostics area to see REST and socket errors.

IMPORTANT
- This app uses public market endpoints; no API key is required for public candles.
- Browser network policies/CORS, the exchange server, unsupported pairs, or API response changes may prevent live data. The ZIP code cannot guarantee the exchange server is online. Verify status in the app after running it.
- BUY/SELL/WAIT is a technical heuristic, not financial advice and not a profit guarantee. It does not place trades.
- Never put exchange API secrets in frontend JavaScript.

Official docs: https://docs.sharkexchange.in/
