(() => {
"use strict";
const ZONE = "Asia/Pontianak";
const PRAYERS = ["Subuh","Dzuhur","Ashar","Maghrib","Isya"];
const KEY = "jamIndukMasjidDigitalNusantara.v1";
const $ = id => document.getElementById(id);
const defaults = {
  times: ["","","","",""],
  iqamahMinutes: 10,
  preIqamahMinutes: 1,
  message: "LURUSKAN DAN RAPATKAN SAF SEBELUM SHOLAT • SELAMAT DATANG DI MASJID",
  theme: "emerald",
  brightness: 80,
  animations: true,
  blink: true,
  volume: 45
};
let settings = structuredCloneSafe(defaults);
let audioContext = null;
let activeOscillators = [];
let overlayTimer = null;
let iqamahRemaining = 0;
let lastTriggeredKey = "";
let lastAlertKey = "";

function structuredCloneSafe(value){ return JSON.parse(JSON.stringify(value)); }
function validTime(value){ return /^([01]\d|2[0-3]):[0-5]\d$/.test(value); }
function escapeHTML(value){ return String(value).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }

function dateTimeParts(date = new Date()) {
  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone: ZONE, hour:"2-digit", minute:"2-digit", second:"2-digit", hourCycle:"h23"
  }).formatToParts(date);
  return Object.fromEntries(parts.map(p => [p.type,p.value]));
}
function formattedDate(){
  return new Intl.DateTimeFormat("id-ID", {
    timeZone: ZONE, weekday:"long", day:"2-digit", month:"long", year:"numeric"
  }).format(new Date());
}
function nowSeconds(){
  const p = dateTimeParts();
  return Number(p.hour)*3600 + Number(p.minute)*60 + Number(p.second);
}
function secondsAt(time){ const [h,m] = time.split(":").map(Number); return h*3600 + m*60; }
function formatDuration(total){
  total = Math.max(0, Math.floor(total));
  const h = Math.floor(total/3600), m = Math.floor((total%3600)/60), s = total%60;
  return [h,m,s].map(v=>String(v).padStart(2,"0")).join(":");
}
function saveSettings(){
  try { localStorage.setItem(KEY, JSON.stringify(settings)); }
  catch(err){ console.warn("Tidak dapat menyimpan pengaturan", err); }
}
function loadSettings(){
  try {
    const parsed = JSON.parse(localStorage.getItem(KEY) || "null");
    if (!parsed || typeof parsed !== "object") return;
    settings = {...defaults, ...parsed};
    if (!Array.isArray(settings.times) || settings.times.length !== 5) settings.times = [...defaults.times];
    settings.times = settings.times.map(t => validTime(t) ? t : "");
  } catch(err){ settings = structuredCloneSafe(defaults); }
}
function renderScheduleInputs(){
  $("scheduleInputs").innerHTML = PRAYERS.map((name,i)=>`
    <div><label class="field-label" for="prayer-${i}">${name}</label>
    <input id="prayer-${i}" type="time" value="${settings.times[i]}" aria-label="Waktu ${name}"></div>`).join("");
}
function renderPrayerCards(){
  const html = PRAYERS.map((name,i)=>`
    <div class="prayer-card" data-prayer-index="${i}">
      <b>${name}</b><time>${settings.times[i] || "--:--"}</time>
      <small>${settings.times[i] ? "Jadwal diatur" : "Belum diatur"}</small>
    </div>`).join("");
  $("mainPrayerGrid").innerHTML = html;
}
function scheduleIsReady(){ return settings.times.every(validTime); }
function getNextPrayer(){
  if (!scheduleIsReady()) return null;
  const now = nowSeconds();
  const today = settings.times.map((time,index)=>({name:PRAYERS[index],time,index,sec:secondsAt(time)}))
    .sort((a,b)=>a.sec-b.sec);
  let next = today.find(item=>item.sec > now);
  let dayOffset = 0;
  if (!next){ next = today[0]; dayOffset = 1; }
  return {...next, remaining: next.sec + dayOffset*86400 - now};
}
function refreshClock(){
  const p = dateTimeParts();
  const clock = `${p.hour}:${p.minute}:${p.second}`;
  $("mainClock").textContent = clock;
  $("companionClock").textContent = clock;
  $("mainDate").textContent = formattedDate();
  $("companionDate").textContent = formattedDate();
  const next = getNextPrayer();
  if (!next){
    $("mainStatus").textContent = "Jadwal belum dikonfigurasi";
    $("nextPrayer").textContent = "Belum tersedia";
    $("nextCountdown").textContent = "--:--:--";
    $("companionStatus").textContent = "Jadwal Sholat belum dikonfigurasi";
    document.querySelectorAll(".prayer-card").forEach(el=>el.classList.remove("active","blink"));
    return;
  }
  $("mainStatus").textContent = "Jadwal aktif • waktu Pontianak";
  $("nextPrayer").textContent = `${next.name} • ${next.time}`;
  $("nextCountdown").textContent = formatDuration(next.remaining);
  $("companionStatus").textContent = `Sholat berikutnya: ${next.name} • ${next.time}`;
  document.querySelectorAll(".prayer-card").forEach(el=>{
    const active = Number(el.dataset.prayerIndex) === next.index;
    el.classList.toggle("active", active);
    el.classList.toggle("blink", active && settings.blink);
  });
  checkPrayerEvents(p, next);
}
function checkPrayerEvents(parts, next){
  const minuteKey = `${formattedDate()}-${parts.hour}:${parts.minute}`;
  const currentTime = `${parts.hour}:${parts.minute}`;
  const index = settings.times.indexOf(currentTime);
  if (index >= 0 && lastTriggeredKey !== minuteKey){
    lastTriggeredKey = minuteKey;
    showPrayerOverlay("WAKTU SHOLAT", 5, PRAYERS[index]);
    gentleBeep();
  }
  if (settings.preIqamahMinutes > 0 && next.remaining <= settings.preIqamahMinutes*60 && next.remaining > settings.preIqamahMinutes*60-1){
    const key = `${formattedDate()}-${next.name}-pre`;
    if(lastAlertKey !== key){ lastAlertKey=key; $("mainStatus").textContent = `Persiapan Iqamah ${next.name}`; }
  }
}
function setTheme(){
  document.body.classList.remove("theme-ivory","theme-midnight","theme-violet");
  if(settings.theme==="ivory") document.body.classList.add("theme-ivory");
  if(settings.theme==="midnight") document.body.classList.add("theme-midnight");
  if(settings.theme==="violet") document.body.classList.add("theme-violet");
  document.body.style.setProperty("--brightness", String(settings.brightness/100));
  document.body.classList.toggle("no-animations", !settings.animations);
  document.body.classList.toggle("no-blink", !settings.blink);
}
function applySettingsToControls(){
  $("iqamahMinutes").value=settings.iqamahMinutes;
  $("preIqamahMinutes").value=settings.preIqamahMinutes;
  $("messageInput").value=settings.message;
  $("themeSelect").value=settings.theme;
  $("brightness").value=settings.brightness;
  $("brightnessValue").textContent=settings.brightness+"%";
  $("animationsEnabled").checked=settings.animations;
  $("blinkEnabled").checked=settings.blink;
  $("volume").value=settings.volume;
  $("volumeValue").textContent=settings.volume+"%";
  $("ticker").textContent=settings.message+" • "+settings.message+" •";
  setTheme();
}
function saveSchedule(){
  settings.times = PRAYERS.map((_,i)=>$("prayer-"+i).value);
  if(settings.times.some(t=>t && !validTime(t))){ alert("Periksa format waktu. Gunakan format HH:MM."); return; }
  saveSettings(); renderPrayerCards(); refreshClock();
  $("mainStatus").textContent = scheduleIsReady() ? "Jadwal berhasil disimpan" : "Jadwal belum lengkap";
}
function saveGeneral(){
  settings.iqamahMinutes = clamp(Number($("iqamahMinutes").value)||10,1,60);
  settings.preIqamahMinutes = clamp(Number($("preIqamahMinutes").value)||0,0,10);
  settings.message = $("messageInput").value.trim() || defaults.message;
  $("ticker").textContent=settings.message+" • "+settings.message+" •";
  saveSettings();
}
function saveDisplay(){
  settings.theme=$("themeSelect").value;
  settings.brightness=clamp(Number($("brightness").value)||80,50,120);
  settings.animations=$("animationsEnabled").checked;
  settings.blink=$("blinkEnabled").checked;
  settings.volume=clamp(Number($("volume").value)||0,0,100);
  applySettingsToControls(); saveSettings(); refreshClock();
}
function clamp(n,min,max){return Math.max(min,Math.min(max,n));}

async function enableAudio(){
  try{
    const AudioCtx=window.AudioContext||window.webkitAudioContext;
    if(!AudioCtx) throw new Error("Web Audio tidak didukung browser");
    audioContext=audioContext||new AudioCtx();
    if(audioContext.state==="suspended") await audioContext.resume();
    $("audioStatus").textContent="Audio siap digunakan pada halaman ini.";
  }catch(err){$("audioStatus").textContent="Audio tidak dapat diaktifkan: "+err.message;}
}
function tone(freq=660,duration=.22,volume=null){
  if(!audioContext) return;
  const osc=audioContext.createOscillator(), gain=audioContext.createGain();
  const level=(volume===null?settings.volume:volume)/100*.16;
  osc.type="sine"; osc.frequency.value=freq;
  gain.gain.setValueAtTime(0,audioContext.currentTime);
  gain.gain.linearRampToValueAtTime(level,audioContext.currentTime+.025);
  gain.gain.setTargetAtTime(0,audioContext.currentTime+duration*.55,.06);
  osc.connect(gain); gain.connect(audioContext.destination);
  osc.start(); osc.stop(audioContext.currentTime+duration);
  activeOscillators.push(osc);
  osc.onended=()=>{osc.disconnect();gain.disconnect();activeOscillators=activeOscillators.filter(x=>x!==osc);};
}
function gentleBeep(){ if(audioContext && audioContext.state==="running"){tone(523,.18);setTimeout(()=>tone(659,.22),240);} }
function stopAudio(){
  activeOscillators.forEach(o=>{try{o.stop()}catch(e){}});
  activeOscillators=[];
  $("audioStatus").textContent="Audio dihentikan.";
}
function showPrayerOverlay(label, seconds, caption){
  $("specialLabel").textContent=label;
  $("specialCaption").textContent=caption||"";
  $("specialCount").textContent=String(seconds).padStart(2,"0");
  $("specialOverlay").classList.remove("hidden");
  clearTimeout(overlayTimer);
  overlayTimer=setTimeout(()=>{$("specialOverlay").classList.add("hidden");},seconds*1000);
}
function startIqamahDemo(){
  iqamahRemaining=settings.iqamahMinutes*60;
  $("specialLabel").textContent="IQAMAH";
  $("specialCaption").textContent="Hitung mundur Iqamah • simulasi";
  $("specialOverlay").classList.remove("hidden");
  $("specialCount").textContent=formatDuration(iqamahRemaining);
  clearInterval(overlayTimer);
  overlayTimer=setInterval(()=>{
    iqamahRemaining--;
    $("specialCount").textContent=formatDuration(iqamahRemaining);
    if(iqamahRemaining<=0){
      clearInterval(overlayTimer);
      $("specialLabel").textContent="LURUSKAN SAF";
      $("specialCount").textContent="•";
      $("specialCaption").textContent="Simulasi selesai";
    }
  },1000);
}
function closeOverlay(){
  clearInterval(overlayTimer); clearTimeout(overlayTimer);
  $("specialOverlay").classList.add("hidden");
}
function runDiagnostics(){
  const checks=[
    ["Elemen jam utama",!!$("mainClock"),"Komponen jam utama ditemukan."],
    ["Panel kedua",!!$("companionClock"),"Panel pendamping ditemukan."],
    ["Lima baris Sholat",PRAYERS.length===5,"Lima waktu Sholat terdaftar."],
    ["Zona waktu",(()=>{try{return dateTimeParts().hour!==undefined}catch(e){return false}})(),"Zona waktu Asia/Pontianak dapat dibaca."],
    ["Penyimpanan lokal",(()=>{try{localStorage.setItem("__jam_test","1");localStorage.removeItem("__jam_test");return true}catch(e){return false}})(),"Browser mengizinkan localStorage."],
    ["Web Audio",!!(window.AudioContext||window.webkitAudioContext),"Browser mendukung Web Audio."],
    ["Service Worker", "serviceWorker" in navigator,"Browser mendukung service worker."],
    ["Jadwal Sholat",scheduleIsReady(),"Semua lima waktu telah diisi."]
  ];
  $("diagnosticResults").innerHTML=checks.map(([name,ok,detail])=>`<div class="diag-item ${ok?"diag-ok":"diag-warn"}"><strong>${ok?"LULUS":"PERLU PERHATIAN"} • ${escapeHTML(name)}</strong>${escapeHTML(detail)}</div>`).join("");
}
function bindEvents(){
  $("saveSchedule").addEventListener("click",saveSchedule);
  $("clearSchedule").addEventListener("click",()=>{settings.times=["","","","",""];renderScheduleInputs();saveSettings();renderPrayerCards();refreshClock();});
  $("saveGeneral").addEventListener("click",saveGeneral);
  $("saveDisplay").addEventListener("click",saveDisplay);
  $("enableAudio").addEventListener("click",enableAudio);
  $("testTone").addEventListener("click",async()=>{await enableAudio();tone(523,.2);setTimeout(()=>tone(659,.2),260);setTimeout(()=>tone(784,.3),520);});
  $("stopTone").addEventListener("click",stopAudio);
  $("demoIqamah").addEventListener("click",async()=>{await enableAudio();startIqamahDemo();});
  $("exitSpecial").addEventListener("click",closeOverlay);
  $("closeOverlay").addEventListener("click",closeOverlay);
  $("runDiagnostics").addEventListener("click",runDiagnostics);
  $("brightness").addEventListener("input",()=>{$("brightnessValue").textContent=$("brightness").value+"%";});
  $("volume").addEventListener("input",()=>{$("volumeValue").textContent=$("volume").value+"%";});
  $("themeSelect").addEventListener("change",()=>{settings.theme=$("themeSelect").value;setTheme();});
  $("animationsEnabled").addEventListener("change",()=>{settings.animations=$("animationsEnabled").checked;setTheme();});
  $("blinkEnabled").addEventListener("change",()=>{settings.blink=$("blinkEnabled").checked;setTheme();refreshClock();});
}
function registerServiceWorker(){
  if("serviceWorker" in navigator && location.protocol.startsWith("http")){
    navigator.serviceWorker.register("./service-worker.js").catch(err=>console.info("Service worker belum aktif:",err));
  }
}
loadSettings();
renderScheduleInputs();
renderPrayerCards();
applySettingsToControls();
bindEvents();
refreshClock();
setInterval(refreshClock,250);
runDiagnostics();
registerServiceWorker();
})();