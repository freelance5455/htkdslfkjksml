# Jam Induk Masjid Digital Nusantara

Paket web offline-first berisi HTML, CSS, JavaScript, manifest, dan service worker.

## Isi paket
- `index.html` — struktur dua panel dan kontrol.
- `style.css` — desain responsif, LED Hijau Zamrud, tema, animasi.
- `app.js` — jam WIB Pontianak, jadwal Sholat manual, hitung mundur, Iqamah demo, audio, penyimpanan, diagnostik.
- `manifest.json` — metadata aplikasi web.
- `service-worker.js` — cache untuk penggunaan offline setelah situs dibuka melalui HTTPS atau localhost.
- `TESTING.md` — prosedur pengujian dan batasan yang diketahui.

## Menjalankan
1. Ekstrak ZIP ke satu folder.
2. Buka `index.html` di browser untuk uji dasar.
3. Untuk PWA/offline cache, unggah folder ke hosting HTTPS (misalnya layanan hosting statis) atau jalankan melalui server lokal.
4. Masukkan jadwal resmi masjid pada bagian **Jadwal Lima Waktu Sholat**, lalu tekan **Simpan Jadwal Sholat**.

## Penting
- Jadwal Sholat awal sengaja kosong. Aplikasi tidak mengarang jadwal dan belum menghitung waktu Sholat otomatis.
- Zona waktu jam adalah `Asia/Pontianak` (WIB/UTC+7).
- Alarm dan audio berbasis browser hanya dapat berjalan saat halaman aktif dan browser mengizinkan audio. Browser dapat menunda timer saat layar mati atau halaman ditutup.
- Demo Iqamah adalah simulasi layar. Ini belum menjadi alarm Android native.
- Untuk penggunaan operasional masjid, cocokkan jadwal dengan sumber resmi/otoritas masjid setempat dan lakukan uji perangkat.
- Jangan mengandalkan prototipe ini sebagai satu-satunya pengingat waktu Sholat sebelum seluruh pengujian lapangan selesai.

## Persyaratan teknis
Browser modern dengan dukungan JavaScript, Intl time zone, localStorage, dan Web Audio. Service worker memerlukan HTTPS atau localhost.
