# Rencana dan hasil pemeriksaan awal

## Pemeriksaan struktur paket
- [x] File HTML utama tersedia.
- [x] CSS terpisah dari HTML.
- [x] JavaScript terpisah dari HTML.
- [x] Manifest aplikasi web tersedia.
- [x] Service worker cache tersedia.
- [x] Dokumentasi penggunaan tersedia.

## Pengujian fungsional yang harus dilakukan pada perangkat
- [ ] Buka halaman pada browser Android dan pastikan jam bergerak setiap detik.
- [ ] Pastikan tanggal dan jam sesuai waktu Pontianak.
- [ ] Masukkan lima jadwal Sholat resmi dan simpan.
- [ ] Muat ulang halaman dan pastikan jadwal tetap tersimpan.
- [ ] Pastikan hitung mundur menuju Sholat berikutnya benar.
- [ ] Uji tema, kecerahan, animasi, dan running text.
- [ ] Aktifkan audio melalui tombol, lalu uji nada dan tombol hentikan.
- [ ] Jalankan demo Iqamah dan periksa hitung mundurnya.
- [ ] Jalankan diagnostik; pahami bahwa jadwal kosong akan ditandai perlu perhatian.
- [ ] Hosting melalui HTTPS, buka sekali, lalu aktifkan mode pesawat dan uji cache offline.
- [ ] Uji pada layar terkunci dan browser ditutup; catat bahwa alarm browser tidak dijamin berjalan.

## Batasan yang diketahui
1. Tidak ada alarm native Android ketika browser ditutup.
2. Tidak ada integrasi otomatis dengan API jadwal Sholat resmi.
3. Jadwal disimpan lokal pada browser/perangkat, bukan tersinkronisasi antarperangkat.
4. Audio memerlukan interaksi pengguna dan izin/dukungan browser.
5. Belum dilakukan pengujian lintas perangkat dan audit keamanan produksi.

## Status
Paket 1.0 adalah prototipe web fungsional awal yang disiapkan untuk pengujian, bukan rilis produksi masjid.
