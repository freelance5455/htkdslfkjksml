# Catatan versi

## 1.0 — Paket awal
- Dua panel vertikal terpadu.
- Jam digital WIB zona Asia/Pontianak.
- Lima waktu Sholat dengan input manual.
- Hitung mundur Sholat berikutnya.
- Running text Panel II.
- Pengaturan Iqamah 10 menit secara default.
- Tema, kecerahan, animasi, dan kedip LED.
- Audio tes berbasis Web Audio.
- Demo Iqamah layar penuh.
- Diagnostik browser dan penyimpanan pengaturan.
- Manifest dan service worker untuk fondasi PWA/offline.
