"use strict";

(function () {
  const MAX_LAYERS = 6;
  const MAX_SIDE = 9;
  const MIN_SIDE_FINAL = 7;
  const MAX_TOTAL = MAX_LAYERS * MAX_SIDE * 2; // 108

  const input = document.getElementById("bunch-count");
  const generateButton = document.getElementById("generate-btn");
  const resetButton = document.getElementById("reset-btn");
  const message = document.getElementById("message");
  const results = document.getElementById("results");

  function showMessage(english, hindi, isError) {
    message.className = "message " + (isError ? "error-message" : "success-message");
    message.replaceChildren();
    const en = document.createElement("strong");
    en.textContent = english;
    const hi = document.createElement("span");
    hi.lang = "hi";
    hi.textContent = hindi;
    message.append(en, hi);
    message.hidden = false;
  }

  function clearMessage() {
    message.hidden = true;
    message.replaceChildren();
    message.className = "message";
  }

  // Each non-final layer must be 8+8 or 9+9. The final layer may be
  // any 7..9 by 7..9 combination. Search all legal combinations.
  // Layer-count priority: five layers first; otherwise use the fewest
  // valid layers. Within a count, maximize 8+8 layers, then prefer a
  // symmetrical final layer, then fewer 9+9 layers.
  function findPackingPlan(total) {
    const candidates = [];
    for (let layerCount = 1; layerCount <= MAX_LAYERS; layerCount++) {
      const normalCount = layerCount - 1;
      const normalOptions = [];
      for (let nines = 0; nines <= normalCount; nines++) {
        const normalTotal = (normalCount - nines) * 16 + nines * 18;
        for (let left = MIN_SIDE_FINAL; left <= MAX_SIDE; left++) {
          for (let right = MIN_SIDE_FINAL; right <= MAX_SIDE; right++) {
            if (normalTotal + left + right !== total) continue;
            const layers = [];
            for (let i = 0; i < normalCount; i++) {
              const isNine = i >= normalCount - nines;
              layers.push({ left: isNine ? 9 : 8, right: isNine ? 9 : 8 });
            }
            layers.push({ left, right });
            const eights = layers.filter(x => x.left === 8 && x.right === 8).length;
            const finalSymmetry = left === right ? 1 : 0;
            candidates.push({
              layers,
              layerCount,
              eights,
              finalSymmetry,
              nines,
              priorityFive: layerCount === 5 ? 1 : 0
            });
          }
        }
      }
    }
    if (!candidates.length) return null;
    candidates.sort((a, b) =>
      b.priorityFive - a.priorityFive ||
      (a.priorityFive ? 0 : a.layerCount - b.layerCount) ||
      b.eights - a.eights ||
      b.finalSymmetry - a.finalSymmetry ||
      a.nines - b.nines
    );
    // The required 66-bunch method is three 8+8 layers and one 9+9 layer.
    return candidates[0].layers;
  }

  function validateInput() {
    const raw = input.value.trim();
    if (raw === "") {
      return { error: ["Please enter a valid whole number greater than zero.", "कृपया शून्य से बड़ी सही पूर्ण संख्या डालें।"] };
    }
    // Read the literal string first so decimal values, signs and text are rejected.
    if (!/^\d+$/.test(raw)) {
      return { error: ["Please enter a valid whole number greater than zero. Decimals and negative numbers are not allowed.", "कृपया शून्य से बड़ी सही पूर्ण संख्या डालें। दशमलव और ऋणात्मक संख्या मान्य नहीं हैं।"] };
    }
    const number = Number(raw);
    if (!Number.isSafeInteger(number) || number <= 0) {
      return { error: ["Please enter a valid whole number greater than zero.", "कृपया शून्य से बड़ी सही पूर्ण संख्या डालें।"] };
    }
    if (number > MAX_TOTAL) {
      return { error: ["This quantity is too large. The maximum capacity is 108 bunches across six layers.", "यह संख्या बहुत बड़ी है। छह लेयर में अधिकतम 108 बंच रखे जा सकते हैं।"] };
    }
    return { number };
  }

  function renderPlan(total, layers) {
    const tbody = document.getElementById("layer-rows");
    tbody.replaceChildren();
    let leftSum = 0, rightSum = 0;

    layers.forEach((layer, index) => {
      const row = document.createElement("tr");
      const layerTotal = layer.left + layer.right;
      leftSum += layer.left;
      rightSum += layer.right;
      const values = [
        { en: "Layer " + (index + 1), hi: "लेयर " + (index + 1) },
        { en: String(layer.left) },
        { en: String(layer.right) },
        { en: String(layerTotal) }
      ];
      values.forEach((value, col) => {
        const cell = document.createElement(col === 0 ? "th" : "td");
        if (col === 0) {
          const en = document.createElement("span");
          en.textContent = value.en;
          const hi = document.createElement("small");
          hi.lang = "hi";
          hi.textContent = value.hi;
          cell.append(en, hi);
        } else {
          cell.textContent = value.en;
        }
        row.appendChild(cell);
      });
      tbody.appendChild(row);
    });

    document.getElementById("summary-bunches").textContent = String(total);
    document.getElementById("summary-layers").textContent = String(layers.length);
    document.getElementById("total-left").textContent = String(leftSum);
    document.getElementById("total-right").textContent = String(rightSum);
    document.getElementById("grand-total").textContent = String(leftSum + rightSum);
    document.getElementById("left-total-card").textContent = String(leftSum);
    document.getElementById("right-total-card").textContent = String(rightSum);
    document.getElementById("grand-total-card").textContent = String(leftSum + rightSum);

    // Safety invariant: never display a plan that does not exactly match input.
    if (leftSum + rightSum !== total || layers.length > MAX_LAYERS ||
        layers.some((x, i) => x.left > MAX_SIDE || x.right > MAX_SIDE ||
          (i < layers.length - 1 && (x.left !== x.right || x.left < 8)))) {
      throw new Error("Packing plan invariant failed");
    }
    results.hidden = false;
    clearMessage();
    results.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function generate() {
    clearMessage();
    results.hidden = true;
    const validation = validateInput();
    if (validation.error) {
      showMessage(validation.error[0], validation.error[1], true);
      return;
    }
    const total = validation.number;
    const plan = findPackingPlan(total);
    if (!plan) {
      showMessage(
        "No valid packing arrangement was found under the current rules.",
        "मौजूदा नियमों के अनुसार पैकिंग का कोई सही तरीका नहीं मिला।",
        true
      );
      return;
    }
    try {
      renderPlan(total, plan);
    } catch (error) {
      showMessage(
        "No valid packing arrangement was found under the current rules.",
        "मौजूदा नियमों के अनुसार पैकिंग का कोई सही तरीका नहीं मिला।",
        true
      );
    }
  }

  function reset() {
    input.value = "";
    results.hidden = true;
    clearMessage();
    input.focus();
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  generateButton.addEventListener("click", generate);
  resetButton.addEventListener("click", reset);
  input.addEventListener("keydown", event => {
    if (event.key === "Enter") generate();
  });
})();
