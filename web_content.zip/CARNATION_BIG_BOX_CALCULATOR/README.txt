CARNATION BIG BOX CALCULATOR
कार्नेशन बिग बॉक्स कैलकुलेटर

PROJECT TYPE
Self-contained offline HTML, CSS and JavaScript app. No backend, account, paid API, or runtime network connection is required.

FILES
- index.html: app structure and bilingual English/Hindi interface.
- style.css: responsive rose-pink and cream mobile design.
- script.js: input validation, packing-plan search, totals, and reset behavior.
- README.txt: these setup and usage instructions.

HOW TO USE
1. Open index.html in a modern browser to run the calculator locally.
2. Enter a positive whole-number bunch quantity and tap GENERATE PACKING PLAN.
3. Read the layer-by-layer left/right arrangement and verify the totals.
4. Tap CALCULATE ANOTHER BOX to clear the previous plan.

PACKING RULES IMPLEMENTED
- Maximum 6 layers, and no side may exceed 9 bunches.
- Every layer except the final layer must be 8+8 or 9+9.
- The final layer may have 7–9 bunches on each side.
- Five layers are preferred whenever a valid plan exists.
- If five layers are not possible, the calculator chooses the fewest valid layers.
- Every generated plan is checked against the exact total before it is shown.
- Quantity range is constrained by the physical rules; values above 108 cannot fit in six layers.
- The specified 66-bunch and 84-bunch arrangements are included in the search priorities and tested.

IMPORTANT BUILDER NOTE
This ZIP is a web-app source project, NOT an APK and NOT a native Android Studio project. APK builders differ:
- Choose an HTML-to-APK/WebView option that accepts an index.html project or a ZIP containing index.html, style.css and script.js.
- If the builder asks for a start page, use index.html.
- Enable local/offline assets and disable unnecessary internet permission if the builder allows it.
- Some ZIP-to-APK services require a different manifest, icon, package ID, or project template. If your builder specifically requires a native Android project, this web ZIP may need to be imported into its HTML/WebView template first.
- Test the generated APK on your phone before using it for actual packing.

DEVELOPER WATERMARK
Built by Er. Nitish Thakur
निर्माता: Er. Nitish Thakur
The watermark is part of the page design and is not editable from the app interface.
