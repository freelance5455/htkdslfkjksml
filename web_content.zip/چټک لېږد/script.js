"use strict";


/* =========================================================
   چټک لېږد
   MAIN JAVASCRIPT
========================================================= */


let selectedFiles = [];

let transferTimer = null;


/* =========================================================
   FILE PICKER
========================================================= */

function openFilePicker() {

    const input =
        document.getElementById("fileInput");

    input.click();

}


/* =========================================================
   FILE SELECTED
========================================================= */

function filesSelected(event) {

    const files =
        Array.from(event.target.files);

    if (!files.length) return;


    selectedFiles = [
        ...selectedFiles,
        ...files
    ];


    renderFiles();


    showToast(
        `${files.length} فایل وټاکل شو`
    );

}


/* =========================================================
   RENDER FILES
========================================================= */

function renderFiles() {

    const list =
        document.getElementById("fileList");


    if (!selectedFiles.length) {

        list.innerHTML = `
            <div class="empty">

                <div class="empty-icon">
                    📁
                </div>

                <p>
                    تر اوسه کوم فایل نه دی ټاکل شوی
                </p>

            </div>
        `;

        return;
    }


    list.innerHTML = "";


    selectedFiles.forEach(
        (file, index) => {

            const item =
                document.createElement("div");

            item.className =
                "file-item";


            item.innerHTML = `

                <div class="file-icon">
                    ${getFileIcon(file)}
                </div>

                <div class="file-info">

                    <div class="file-name">
                        ${escapeHTML(file.name)}
                    </div>

                    <div class="file-size">
                        ${formatSize(file.size)}
                    </div>

                </div>

                <button
                    class="remove-file"
                    onclick="removeFile(${index})">

                    ×

                </button>

            `;


            list.appendChild(item);

        }
    );

}


/* =========================================================
   REMOVE FILE
========================================================= */

function removeFile(index) {

    selectedFiles.splice(index, 1);

    renderFiles();

}


/* =========================================================
   CLEAR FILES
========================================================= */

function clearFiles() {

    selectedFiles = [];

    document.getElementById(
        "fileInput"
    ).value = "";

    renderFiles();

    showToast(
        "ټول فایلونه پاک شول"
    );

}


/* =========================================================
   FILE ICON
========================================================= */

function getFileIcon(file) {

    const type =
        file.type || "";

    const name =
        file.name.toLowerCase();


    if (type.startsWith("image/"))
        return "🖼️";

    if (type.startsWith("video/"))
        return "🎬";

    if (type.startsWith("audio/"))
        return "🎵";

    if (
        name.endsWith(".pdf")
    )
        return "📕";

    if (
        name.endsWith(".doc") ||
        name.endsWith(".docx")
    )
        return "📘";

    if (
        name.endsWith(".xls") ||
        name.endsWith(".xlsx")
    )
        return "📗";

    if (
        name.endsWith(".zip") ||
        name.endsWith(".rar")
    )
        return "🗜️";

    return "📄";

}


/* =========================================================
   FORMAT SIZE
========================================================= */

function formatSize(bytes) {

    if (bytes === 0)
        return "0 B";


    const units = [
        "B",
        "KB",
        "MB",
        "GB"
    ];


    const i =
        Math.floor(
            Math.log(bytes) /
            Math.log(1024)
        );


    return (
        bytes /
        Math.pow(1024, i)
    ).toFixed(2)
    + " "
    + units[i];

}


/* =========================================================
   SCAN DEVICES
========================================================= */

function scanDevices() {

    const status =
        document.getElementById(
            "statusText"
        );

    const deviceStatus =
        document.getElementById(
            "deviceStatus"
        );


    status.innerText =
        "د وسیلو لټون روان دی...";


    deviceStatus.innerText =
        "مهرباني وکړئ لږ انتظار وکړئ";


    const button =
        document.querySelector(
            ".scan-btn"
        );


    button.disabled = true;

    button.innerText =
        "لټون روان دی...";


    setTimeout(() => {

        status.innerText =
            "لټون بشپړ شو";

        deviceStatus.innerText =
            "د نږدې وسیلو لپاره چمتو دی";

        button.disabled = false;

        button.innerText =
            "بیا وسیلې ولټوئ";


        showToast(
            "د وسیلو لټون بشپړ شو"
        );

    }, 2500);

}


/* =========================================================
   RECEIVE MODE
========================================================= */

function receiveMode() {

    const status =
        document.getElementById(
            "statusText"
        );

    const deviceStatus =
        document.getElementById(
            "deviceStatus"
        );


    status.innerText =
        "د ترلاسه کولو حالت";

    deviceStatus.innerText =
        "اوس د بلې وسیلې د فایل لپاره انتظار کوئ";


    showToast(
        "د فایل ترلاسه کولو حالت فعال شو"
    );

}


/* =========================================================
   START DEMO TRANSFER
========================================================= */

function startTransfer() {

    if (!selectedFiles.length) {

        showToast(
            "لومړی یو فایل وټاکئ"
        );

        return;

    }


    const transferBox =
        document.getElementById(
            "transferBox"
        );


    transferBox.classList.remove(
        "hidden"
    );


    let totalSize =
        selectedFiles.reduce(
            (sum, file) =>
                sum + file.size,
            0
        );


    let progress = 0;


    const bar =
        document.getElementById(
            "progressBar"
        );


    const progressText =
        document.getElementById(
            "progressText"
        );


    const speed =
        document.getElementById(
            "speed"
        );


    const sizeText =
        document.getElementById(
            "sizeText"
        );


    clearInterval(
        transferTimer
    );


    transferTimer =
        setInterval(() => {

            progress +=
                Math.random() * 9 + 3;


            if (progress >= 100) {

                progress = 100;

                clearInterval(
                    transferTimer
                );


                speed.innerText =
                    "بشپړ شو";


                showToast(
                    "فایلونه په بریالیتوب ولېږل شول"
                );


                addHistory();

            }
            else {

                speed.innerText =
                    (
                        Math.random() *
                        20 + 5
                    ).toFixed(1)
                    + " MB/s";

            }


            bar.style.width =
                progress + "%";


            progressText.innerText =
                Math.floor(progress)
                + "%";


            const transferred =
                totalSize *
                (progress / 100);


            sizeText.innerText =
                formatSize(
                    transferred
                )
                + " / "
                + formatSize(
                    totalSize
                );

        }, 300);

}


/* =========================================================
   HISTORY
========================================================= */

function addHistory() {

    const history =
        document.getElementById(
            "historyList"
        );


    const total =
        selectedFiles.length;


    const item =
        document.createElement("div");


    item.className =
        "history-item";


    item.innerHTML = `

        <div class="history-icon">
            ↑
        </div>

        <div class="history-info">

            <strong>
                ${total} فایل لېږل شوي
            </strong>

            <small>
                همدا اوس
            </small>

        </div>

    `;


    const empty =
        history.querySelector(
            ".history-empty"
        );


    if (empty)
        empty.remove();


    history.prepend(item);

}


/* =========================================================
   OPEN HISTORY
========================================================= */

function openHistory() {

    document.querySelector(
        ".history"
    ).scrollIntoView({
        behavior: "smooth"
    });

}


/* =========================================================
   ABOUT
========================================================= */

function openAbout() {

    document
        .getElementById(
            "aboutModal"
        )
        .classList.add("show");

}


function closeAbout() {

    document
        .getElementById(
            "aboutModal"
        )
        .classList.remove("show");

}


/* =========================================================
   TOAST
========================================================= */

function showToast(message) {

    const toast =
        document.getElementById(
            "toast"
        );


    toast.innerText =
        message;


    toast.classList.add(
        "show"
    );


    setTimeout(() => {

        toast.classList.remove(
            "show"
        );

    }, 2500);

}


/* =========================================================
   SECURITY
========================================================= */

function escapeHTML(text) {

    const div =
        document.createElement(
            "div"
        );

    div.textContent = text;

    return div.innerHTML;

}


/* =========================================================
   WEB SHARE
   که موبایل یې ملاتړ کوي،
   ټاکل شوي فایلونه شریکوي.
========================================================= */

async function shareFiles() {

    if (!selectedFiles.length) {

        showToast(
            "لومړی فایل وټاکئ"
        );

        return;

    }


    if (
        navigator.share &&
        navigator.canShare
    ) {

        try {

            const data = {
                files: selectedFiles,
                title: "چټک لېږد",
                text: "فایل شریکول"
            };


            if (
                navigator.canShare(data)
            ) {

                await navigator.share(
                    data
                );

                showToast(
                    "فایل شریک شو"
                );

                return;

            }

        }
        catch(error) {

            console.log(error);

        }

    }


    showToast(
        "ستاسو موبایل د فایل مستقیم Share ملاتړ نه کوي"
    );

}


/* =========================================================
   SEND BUTTON
========================================================= */

document
    .querySelector(".send")
    .addEventListener(
        "contextmenu",
        function(e) {

            e.preventDefault();

            shareFiles();

        }
    );


/* =========================================================
   STARTUP
========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    () => {

        renderFiles();

    }
);