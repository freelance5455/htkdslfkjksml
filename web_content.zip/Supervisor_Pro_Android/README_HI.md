# Supervisor Pro — Android phone app starter

## Is version mein kya hai
- Mobile-first dashboard aur 6 tabs: Home, Employees, Attendance, Joining, Tasks, Reports
- Employee add/edit/delete aur search
- Date, department, shift ke hisaab se worker-wise attendance: Present, Absent, Leave, Weekly Off
- Attendance re-save karne par same date/department/shift record update hota hai
- Joining tracker, task list, JSON backup/restore, employee/attendance CSV exports
- PWA manifest, app icon aur service worker

## Bahut zaroori limitation
Ye abhi **local-first PWA prototype** hai. Data is browser ke local storage mein rehta hai. Login, secure cloud database/sync, remote document upload, push reminders aur production hosting abhi connect nahi hain. Ismein real employee data tab tak mat daalein jab tak authentication, access rules aur cloud sync implement/test na ho.

## Android phone se test/install karne ka asaan tareeqa
PWA ko home screen par install karne ke liye ise HTTPS website par host karna hota hai. Sirf ZIP download karne se app install nahi hota.
1. ZIP ko extract karein.
2. Project files ko kisi static hosting service par upload karein jo HTTPS URL deti ho.
3. Hosted URL ko Android Chrome mein kholein.
4. Chrome menu mein `Install app` ya `Add to Home screen` chunein (menu wording phone ke hisaab se badal sakti hai).

Agar phone se upload karna mushkil lage, kisi bharosemand vyakti se sirf hosting setup mein madad lein. Passwords ya employee records share na karein.

## Local data
Backup & data icon se JSON backup download karein. Reports se CSV export kar sakte hain. Browser storage clear karne ya phone badalne se pehle backup zaroor karein.
