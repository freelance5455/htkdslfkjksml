plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    // IMPORTANT: if this game is already published, use the SAME applicationId and the SAME signing key as your old APK.
    namespace = "com.example.shiftingmaze"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.shiftingmaze"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"

        // AdMob APP ID (not secret; goes into the manifest)
        manifestPlaceholders["admobAppId"] = "ca-app-pub-4793101120321816~8307746642"
    }

    buildTypes {
        debug {
            // Google's official TEST rewarded ad unit: safe to load and click while developing
            buildConfigField("String", "REWARDED_AD_UNIT_ID", "\"ca-app-pub-3940256099942544/5224354917\"")
        }
        release {
            // YOUR real rewarded ad unit: only used by the release build
            buildConfigField("String", "REWARDED_AD_UNIT_ID", "\"ca-app-pub-4793101120321816/7225142997\"")
            isMinifyEnabled = false
        }
    }

    buildFeatures { buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.gms:play-services-ads:25.5.0") // check for a newer version when you build
}
