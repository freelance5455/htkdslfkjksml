CONTROL PARTY - projet APK (Flutter + application complete embarquee)

Obtenir l'APK sans PC :
1. Creer un depot GitHub (prive) et y deposer tout le contenu de ce dossier.
2. Onglet Actions > Build APK > Run workflow (ou attendre la fin du build automatique).
3. Telecharger "control-party-apk" (fichier app-release.apk), l'envoyer sur le telephone et l'installer
   (autoriser l'installation depuis cette source).

Avec un PC : installer Flutter, puis : flutter create --platforms android . ; flutter build apk --release
(penser a ajouter les permissions INTERNET et CAMERA et usesCleartextTraffic="true" dans AndroidManifest.xml).

Les donnees restent sur le telephone. Pour mettre a jour l'application : remplacer assets/web/index.html.
