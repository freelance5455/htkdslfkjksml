import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:permission_handler/permission_handler.dart';

// Petit serveur local : la page tourne en contexte securise (chiffrement, camera).
final InAppLocalhostServer server =
    InAppLocalhostServer(documentRoot: 'assets/web', port: 8765);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await server.start();
  runApp(const App());
}

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Control Party',
        debugShowCheckedModeBanner: false,
        theme: ThemeData.dark(),
        home: const Shell(),
      );
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  @override
  void initState() {
    super.initState();
    Permission.camera.request();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: const Color(0xFF171717),
        body: SafeArea(
          child: InAppWebView(
            initialUrlRequest:
                URLRequest(url: WebUri('http://localhost:8765/index.html')),
            initialSettings: InAppWebViewSettings(
              javaScriptEnabled: true,
              domStorageEnabled: true,
              mediaPlaybackRequiresUserGesture: false,
              allowsInlineMediaPlayback: true,
            ),
            onPermissionRequest: (controller, request) async =>
                PermissionResponse(
                    resources: request.resources,
                    action: PermissionResponseAction.GRANT),
          ),
        ),
      );
}
