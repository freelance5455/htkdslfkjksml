export type EventType = 'battle' | 'protest' | 'border';
export type Verification = 'verified' | 'corroborated' | 'unverified';
export type SourceId = 'gdelt' | 'acled';

export interface Incident {
  id: string;
  type: EventType;
  region: string;
  description: string;
  source: string;
  verification: Verification;
  lat: number;
  lng: number;
  time: number; // epoch ms
}

export const TYPE_META: Record<EventType, { label: string; short: string; color: string }> = {
  battle: { label: 'Active battlefront', short: 'Battlefronts', color: '#b3261e' },
  protest: { label: 'Protest', short: 'Protests', color: '#a15c00' },
  border: { label: 'Border security', short: 'Border', color: '#1d5fa8' },
};
