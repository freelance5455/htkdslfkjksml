import { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { TYPE_META, type Incident } from '../types';

interface Props {
  incidents: Incident[];
  selectedId: string | null;
  onSelect: (id: string) => void; // must be stable (useCallback)
}

export default function MapView({ incidents, selectedId, onSelect }: Props) {
  const el = useRef<HTMLDivElement>(null);
  const map = useRef<L.Map>();
  const layer = useRef<L.LayerGroup>();
  const latest = useRef(incidents);
  latest.current = incidents;

  useEffect(() => {
    const m = L.map(el.current!, { minZoom: 2, zoomControl: false, worldCopyJump: true }).setView([20, 15], 2);
    // Public OSM tiles suit development only; use a commercial/self-hosted tile source in production.
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 18, attribution: '© OpenStreetMap contributors',
    }).addTo(m);
    L.control.zoom({ position: 'bottomright' }).addTo(m);
    layer.current = L.layerGroup().addTo(m);
    map.current = m;
    const ro = new ResizeObserver(() => m.invalidateSize());
    ro.observe(el.current!);
    return () => { ro.disconnect(); m.remove(); };
  }, []);

  useEffect(() => {
    const g = layer.current!;
    g.clearLayers();
    incidents.forEach((i) => {
      const sel = i.id === selectedId;
      L.circleMarker([i.lat, i.lng], {
        radius: sel ? 11 : 7, color: '#ffffff', weight: 2,
        fillColor: TYPE_META[i.type].color, fillOpacity: i.verification === 'unverified' ? 0.55 : 0.95,
      }).on('click', () => onSelect(i.id)).addTo(g);
    });
  }, [incidents, selectedId, onSelect]);

  useEffect(() => {
    const i = latest.current.find((x) => x.id === selectedId);
    if (i && map.current) map.current.flyTo([i.lat, i.lng], Math.max(map.current.getZoom(), 5), { duration: 0.6 });
  }, [selectedId]);

  return <div ref={el} className="h-full w-full" role="application" aria-label="Incident map" />;
}
