// Data layer: a TypeScript port of fetch_events.py, running inside the app.
// Native HTTP (CapacitorHttp) is used so requests are not blocked by browser CORS rules.
import { CapacitorHttp } from '@capacitor/core';
import { SecureStorage } from '@aparajita/capacitor-secure-storage';
import { strFromU8, unzipSync } from 'fflate';
import type { EventType, Incident, SourceId, Verification } from './types';

const ACLED_TOKEN_URL = 'https://acleddata.com/oauth/token'; // verify against current ACLED docs
const ACLED_READ_URL = 'https://acleddata.com/api/acled/read';
const GDELT_LASTUPDATE_URL = 'https://data.gdeltproject.org/gdeltv2/lastupdate.txt';
const MAX_EVENTS = 500;

export interface Credentials { username: string; password: string }
export class AuthRequiredError extends Error {}

const verificationFor = (n: number): Verification => (n >= 3 ? 'verified' : n === 2 ? 'corroborated' : 'unverified');
const httpsOnly = (url: string) => {
  if (!url.startsWith('https://')) throw new Error('Refusing non-HTTPS URL');
  return url;
};

function base64ToBytes(b64: string): Uint8Array {
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

// ---- GDELT (public, no credentials) -------------------------------------
const GDELT_ROOT: Record<string, { type: EventType; label: string }> = {
  '14': { type: 'protest', label: 'Protest' },
  '18': { type: 'battle', label: 'Assault' },
  '19': { type: 'battle', label: 'Armed clash' },
  '20': { type: 'battle', label: 'Mass violence' },
};

async function fetchGdelt(): Promise<Incident[]> {
  const listing = await CapacitorHttp.get({ url: httpsOnly(GDELT_LASTUPDATE_URL), responseType: 'text' });
  const line = String(listing.data).split('\n').find((l) => l.includes('export.CSV.zip'));
  if (!line) throw new Error('GDELT listing has no events export');
  const url = httpsOnly(line.trim().split(/\s+/).pop()!.replace('http://', 'https://'));

  const zip = await CapacitorHttp.get({ url, responseType: 'arraybuffer' }); // returned as base64
  const csv = strFromU8(Object.values(unzipSync(base64ToBytes(zip.data as string)))[0]);

  const out: Incident[] = [];
  for (const row of csv.split('\n')) {
    const c = row.split('\t'); // column indices follow the GDELT 2.0 events spec
    const root = GDELT_ROOT[c[28]];
    if (!root) continue;
    const d = c[1] ?? '';
    const actors = `${c[6] || 'Unknown'} / ${c[16] || 'Unknown'}`;
    out.push({
      id: `gdelt-${c[0]}`,
      type: root.type,
      region: c[52] || 'Unknown',
      description: `${root.label}: ${actors}`,
      source: c[60] || 'GDELT',
      verification: verificationFor(Number(c[32]) || 1),
      lat: Number(c[56]),
      lng: Number(c[57]),
      time: Date.UTC(+d.slice(0, 4), +d.slice(4, 6) - 1, +d.slice(6, 8)),
    });
  }
  return out;
}

// ---- ACLED (authenticated) ----------------------------------------------
const ACLED_TYPES: Record<string, EventType> = {
  Protests: 'protest', Riots: 'protest', Battles: 'battle',
  'Explosions/Remote violence': 'battle', 'Violence against civilians': 'battle',
};

async function fetchAcled(creds: Credentials, days = 7): Promise<Incident[]> {
  const auth = await CapacitorHttp.post({
    url: httpsOnly(ACLED_TOKEN_URL),
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    data: { username: creds.username, password: creds.password, grant_type: 'password', client_id: 'acled' },
  });
  const token = auth.data?.access_token as string | undefined;
  if (auth.status >= 400 || !token) throw new AuthRequiredError('ACLED sign-in failed');

  const end = new Date();
  const start = new Date(end.getTime() - days * 86_400_000);
  const day = (d: Date) => d.toISOString().slice(0, 10);
  const res = await CapacitorHttp.get({
    url: httpsOnly(ACLED_READ_URL),
    headers: { Authorization: `Bearer ${token}` },
    params: {
      _format: 'json', event_date: `${day(start)}|${day(end)}`, event_date_where: 'BETWEEN',
      fields: 'event_id_cnty|event_date|event_type|country|admin1|latitude|longitude|notes|source',
      limit: String(MAX_EVENTS),
    },
  });
  if (res.status >= 400) throw new Error(`ACLED request failed (${res.status})`);

  return ((res.data?.data ?? []) as Record<string, string>[]).map((r) => {
    const notes = (r.notes ?? '').trim();
    return {
      id: `acled-${r.event_id_cnty}`,
      type: /\bborder\b/i.test(notes) ? 'border' : (ACLED_TYPES[r.event_type] as EventType),
      region: [r.admin1, r.country].filter(Boolean).join(', '),
      description: notes.slice(0, 500),
      source: r.source || 'ACLED',
      verification: verificationFor((r.source ?? '').split(';').length),
      lat: Number(r.latitude),
      lng: Number(r.longitude),
      time: Date.parse(`${r.event_date}T00:00:00Z`),
    };
  });
}

// ---- cleaning + public API ----------------------------------------------
function clean(items: Incident[]): Incident[] {
  const seen = new Set<string>();
  return items
    .filter((i) => i.type && Number.isFinite(i.lat) && Number.isFinite(i.lng) && Number.isFinite(i.time))
    .filter((i) => Math.abs(i.lat) <= 90 && Math.abs(i.lng) <= 180 && (i.lat !== 0 || i.lng !== 0))
    .filter((i) => (seen.has(i.id) ? false : (seen.add(i.id), true)))
    .sort((a, b) => b.time - a.time)
    .slice(0, MAX_EVENTS);
}

export async function loadIncidents(source: SourceId): Promise<Incident[]> {
  if (source === 'gdelt') return clean(await fetchGdelt());
  const creds = await loadCredentials();
  if (!creds) throw new AuthRequiredError('ACLED login required');
  return clean(await fetchAcled(creds));
}

// ---- credentials: stored in iOS Keychain / Android Keystore --------------
export async function saveCredentials(c: Credentials) {
  await SecureStorage.set('acled_user', c.username);
  await SecureStorage.set('acled_pass', c.password);
}
export async function loadCredentials(): Promise<Credentials | null> {
  try {
    const username = await SecureStorage.get('acled_user');
    const password = await SecureStorage.get('acled_pass');
    return typeof username === 'string' && typeof password === 'string' ? { username, password } : null;
  } catch {
    return null;
  }
}
export async function clearCredentials() {
  await SecureStorage.remove('acled_user');
  await SecureStorage.remove('acled_pass');
}
