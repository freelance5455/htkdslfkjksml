import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  BadgeCheck, Clock, Eye, KeyRound, MapPin, Megaphone, RefreshCw, ShieldAlert, ShieldCheck, Swords,
} from 'lucide-react';
import MapView from './components/MapView';
import { AuthRequiredError, clearCredentials, loadIncidents, saveCredentials } from './sources';
import { TYPE_META, type EventType, type Incident, type SourceId } from './types';

const ICONS = { battle: Swords, protest: Megaphone, border: ShieldAlert } as const;
const VERIFY = {
  verified: { label: 'Verified', Icon: BadgeCheck },
  corroborated: { label: 'Corroborated', Icon: ShieldCheck },
  unverified: { label: 'Unverified', Icon: Eye },
} as const;

type Status = 'loading' | 'ok' | 'error' | 'needs-auth';

function ago(t: number, now: number) {
  const s = Math.max(0, Math.floor((now - t) / 1000));
  if (s < 3600) return `${Math.max(1, Math.floor(s / 60))}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  return `${Math.floor(s / 86400)}d ago`;
}

export default function App() {
  const [source, setSource] = useState<SourceId>('gdelt');
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [filters, setFilters] = useState<Record<EventType, boolean>>({ battle: true, protest: true, border: true });
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [status, setStatus] = useState<Status>('loading');
  const [updated, setUpdated] = useState<number | null>(null);
  const [now, setNow] = useState(Date.now());
  const [creds, setCreds] = useState({ username: '', password: '' });

  const refresh = useCallback(async () => {
    setStatus('loading');
    try {
      setIncidents(await loadIncidents(source));
      setUpdated(Date.now());
      setStatus('ok');
    } catch (e) {
      setStatus(e instanceof AuthRequiredError ? 'needs-auth' : 'error');
    }
  }, [source]);

  useEffect(() => {
    setSelectedId(null);
    refresh();
    const poll = setInterval(refresh, 15 * 60_000); // GDELT publishes every 15 minutes
    return () => clearInterval(poll);
  }, [refresh]);

  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 30_000);
    return () => clearInterval(t);
  }, []);

  const onSelect = useCallback((id: string) => setSelectedId((s) => (s === id ? null : id)), []);
  useEffect(() => {
    if (selectedId) document.getElementById(`inc-${selectedId}`)?.scrollIntoView({ block: 'nearest' });
  }, [selectedId]);

  const counts = useMemo(() => {
    const c: Record<EventType, number> = { battle: 0, protest: 0, border: 0 };
    incidents.forEach((i) => c[i.type]++);
    return c;
  }, [incidents]);
  const visible = useMemo(() => incidents.filter((i) => filters[i.type]), [incidents, filters]);

  async function submitCreds(e: React.FormEvent) {
    e.preventDefault();
    await saveCredentials(creds);
    setCreds({ username: '', password: '' });
    refresh();
  }

  return (
    <div className="flex h-full flex-col" style={{ paddingTop: 'env(safe-area-inset-top)' }}>
      <header className="border-b border-line bg-panel px-4 py-3">
        <div className="flex items-center justify-between gap-2">
          <div>
            <h1 className="text-base font-semibold leading-tight">Global Conflict &amp; Event Tracker</h1>
            <p className="text-xs text-mute">
              {status === 'ok' && updated ? `${visible.length} incidents · updated ${ago(updated, now)}` : 'Research dataset'}
            </p>
          </div>
          <button onClick={refresh} aria-label="Refresh data" className="rounded-md border border-line p-2">
            <RefreshCw size={16} className={status === 'loading' ? 'animate-spin' : ''} />
          </button>
        </div>
        <div className="mt-2 flex gap-2" role="group" aria-label="Data source">
          {(['gdelt', 'acled'] as SourceId[]).map((s) => (
            <button key={s} aria-pressed={source === s} onClick={() => setSource(s)}
              className={`rounded-md border px-3 py-1.5 text-sm font-medium ${source === s ? 'border-ink' : 'border-line text-mute'}`}>
              {s === 'gdelt' ? 'GDELT (public)' : 'ACLED (login)'}
            </button>
          ))}
        </div>
        <div className="mt-2 flex flex-wrap gap-2" role="group" aria-label="Filter incident types">
          {(Object.keys(TYPE_META) as EventType[]).map((k) => {
            const Icon = ICONS[k]; const on = filters[k]; const m = TYPE_META[k];
            return (
              <button key={k} aria-pressed={on} onClick={() => setFilters((f) => ({ ...f, [k]: !f[k] }))}
                className="flex items-center gap-1.5 rounded-md border px-2.5 py-1.5 text-sm font-medium"
                style={{ borderColor: on ? m.color : 'var(--line)', color: on ? m.color : 'var(--mute)' }}>
                <Icon size={15} />{m.short}
                <span className="text-xs tabular-nums">{counts[k]}</span>
              </button>
            );
          })}
        </div>
      </header>

      <main className="flex min-h-0 flex-1 flex-col md:flex-row">
        <section className="order-1 min-h-0 flex-1 md:order-2">
          <MapView incidents={visible} selectedId={selectedId} onSelect={onSelect} />
        </section>

        <aside className="order-2 flex h-[42%] min-h-0 flex-col border-t border-line bg-bg md:order-1 md:h-auto md:w-96 md:border-r md:border-t-0"
               style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}>
          <ul className="flex-1 space-y-2 overflow-y-auto p-3">
            {status === 'needs-auth' && (
              <li className="rounded-md border border-line bg-panel p-3">
                <form onSubmit={submitCreds} className="space-y-2 text-sm">
                  <p className="flex items-center gap-2 font-medium"><KeyRound size={15} />Sign in to ACLED</p>
                  <p className="text-xs text-mute">Stored in the device keychain, never in the app bundle.</p>
                  <input required type="email" placeholder="Email" autoComplete="username" value={creds.username}
                    onChange={(e) => setCreds({ ...creds, username: e.target.value })}
                    className="w-full rounded border border-line bg-bg px-2 py-1.5" />
                  <input required type="password" placeholder="Password" autoComplete="current-password" value={creds.password}
                    onChange={(e) => setCreds({ ...creds, password: e.target.value })}
                    className="w-full rounded border border-line bg-bg px-2 py-1.5" />
                  <button className="rounded-md border border-ink px-3 py-1.5 font-medium">Save and load</button>
                </form>
              </li>
            )}
            {status === 'error' && (
              <li className="rounded-md border border-dashed border-line p-3 text-sm text-mute">
                Could not load events. Check your connection and tap refresh.
              </li>
            )}
            {status === 'ok' && visible.length === 0 && (
              <li className="rounded-md border border-dashed border-line p-3 text-sm text-mute">
                No incidents match. Turn on at least one filter.
              </li>
            )}
            {visible.map((i) => {
              const m = TYPE_META[i.type]; const Icon = ICONS[i.type]; const V = VERIFY[i.verification];
              return (
                <li key={i.id} id={`inc-${i.id}`}>
                  <button onClick={() => onSelect(i.id)} aria-pressed={i.id === selectedId}
                    className="w-full rounded-md border bg-panel p-3 text-left"
                    style={{ borderColor: i.id === selectedId ? m.color : 'var(--line)', borderLeft: `4px solid ${m.color}` }}>
                    <div className="flex items-center justify-between text-xs">
                      <span className="flex items-center gap-1.5 font-medium" style={{ color: m.color }}><Icon size={14} />{m.label}</span>
                      <span className="flex items-center gap-1 text-mute"><Clock size={12} />{ago(i.time, now)}</span>
                    </div>
                    <p className="mt-1.5 line-clamp-3 text-sm font-medium leading-snug">{i.description || 'No description provided'}</p>
                    <div className="mt-2 flex flex-wrap gap-x-3 gap-y-1 text-xs text-mute">
                      <span className="flex items-center gap-1"><MapPin size={12} />{i.region}</span>
                      <span className="flex items-center gap-1"><V.Icon size={12} />{V.label}</span>
                    </div>
                    <p className="mt-1 break-words text-xs text-mute">Source: {i.source}</p>
                  </button>
                </li>
              );
            })}
            {source === 'acled' && status === 'ok' && (
              <li><button onClick={async () => { await clearCredentials(); setIncidents([]); setStatus('needs-auth'); }}
                className="text-xs text-mute underline">Remove saved ACLED login</button></li>
            )}
          </ul>
        </aside>
      </main>
    </div>
  );
}
