import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'org.example.conflicttracker', // change to your reverse-domain ID before release
  appName: 'Conflict Tracker',
  webDir: 'dist',
};

export default config;
