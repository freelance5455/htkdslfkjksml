# Global Conflict & Event Tracker (Capacitor)

React + TypeScript + Vite + Tailwind + Leaflet, wrapped for iOS/Android with Capacitor.
Data fetching (GDELT / ACLED) runs inside the app via native HTTP; no separate backend.

## Requirements
- Node.js 18.18+ and npm
- Android: Android Studio (latest stable), JDK 17, Android SDK Platform 34+
- iOS (macOS only): Xcode 15+, CocoaPods, an Apple ID (paid Developer account for TestFlight/App Store)

## First-time setup
    npm install
    npx cap add android      # and/or: npx cap add ios
    npm run sync

## Run / build
    npm run dev              # browser preview (GDELT is blocked by CORS here; use a device or emulator)
    npm run android          # builds web assets, syncs, opens Android Studio -> Run
    npm run ios              # builds web assets, syncs, opens Xcode -> Run

Release builds: Android Studio -> Build > Generate Signed Bundle (AAB); Xcode -> Product > Archive.
Change `appId` in `capacitor.config.ts` before the first native build.

## Notes
- ACLED credentials are entered by the user and stored in the Keychain/Keystore. Do not hard-code them.
  For a public release, consider a small proxy service that holds the ACLED account instead.
- Public OpenStreetMap tiles are for development; switch to a tile provider that permits app traffic.
