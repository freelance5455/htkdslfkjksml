# Obtenir le fichier APK Android

Le code source est prêt avec une configuration Capacitor et une automatisation GitHub Actions. **L'APK n'est pas encore compilé dans cette archive** : la compilation Android nécessite le SDK Android/Gradle, qui n'est pas installé dans l'environnement de préparation.

## Compilation depuis un téléphone Android
1. Créez ou ouvrez un compte GitHub et créez un dépôt privé nommé `coran-academy-b`.
2. Téléversez le contenu de cette archive dans le dépôt (à la racine, pas le dossier parent `coran_src`).
3. Ouvrez l'onglet **Actions** du dépôt et autorisez les workflows si GitHub le demande.
4. Lancez **Build CORAN ACADEMY B APK** avec **Run workflow**. Un lancement se fait aussi automatiquement après un push sur `main` ou `master`.
5. Quand l'exécution est terminée avec succès, ouvrez-la, puis téléchargez l'artefact `CORAN-ACADEMY-B-debug-apk`.
6. Extrayez le ZIP de l'artefact et installez `app-debug.apk` sur Android. Autorisez temporairement l'installation depuis cette source si Android le demande.

Ce sera un APK de test/debug, installable mais non signé pour une distribution publique. Une version de publication nécessite une clé de signature Android conservée en sécurité et une compilation release.
