PRAGMA foreign_keys = ON;
PRAGMA journal_mode = WAL;

CREATE TABLE IF NOT EXISTS surahs (
    id INTEGER PRIMARY KEY CHECK (id BETWEEN 1 AND 114),
    arabic_name TEXT NOT NULL,
    transliteration TEXT NOT NULL,
    french_name TEXT NOT NULL,
    revelation_type TEXT NOT NULL CHECK (revelation_type IN ('Meccan', 'Medinan')),
    verses_count INTEGER NOT NULL CHECK (verses_count > 0),
    juz_start INTEGER NOT NULL CHECK (juz_start BETWEEN 1 AND 30),
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS verses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    surah_id INTEGER NOT NULL,
    verse_number INTEGER NOT NULL CHECK (verse_number > 0),
    arabic_uthmani TEXT NOT NULL,
    arabic_simple TEXT NOT NULL,
    juz INTEGER NOT NULL,
    hizb INTEGER NOT NULL,
    page_number INTEGER NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY (surah_id) REFERENCES surahs(id) ON DELETE CASCADE,
    UNIQUE (surah_id, verse_number)
);

CREATE TABLE IF NOT EXISTS translations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    verse_id INTEGER NOT NULL,
    language_code TEXT NOT NULL CHECK (language_code IN ('fr', 'mos', 'dyu')),
    translator_name TEXT NOT NULL,
    text TEXT NOT NULL,
    version INTEGER NOT NULL DEFAULT 1,
    updated_at TEXT NOT NULL,
    FOREIGN KEY (verse_id) REFERENCES verses(id) ON DELETE CASCADE,
    UNIQUE (verse_id, language_code, translator_name)
);

CREATE TABLE IF NOT EXISTS reciters (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    country_code TEXT,
    region_label TEXT,
    riwayah TEXT NOT NULL DEFAULT 'Hafs an Asim',
    is_local_featured INTEGER NOT NULL DEFAULT 0 CHECK (is_local_featured IN (0, 1)),
    audio_base_url TEXT,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS hadiths (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    collection_name TEXT NOT NULL,
    book_name TEXT,
    hadith_number TEXT NOT NULL,
    arabic_text TEXT NOT NULL,
    french_text TEXT,
    moore_explanation TEXT NOT NULL,
    theme_tag TEXT,
    updated_at TEXT NOT NULL,
    UNIQUE (collection_name, hadith_number)
);
