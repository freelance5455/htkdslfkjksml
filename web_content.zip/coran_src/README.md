# CORAN ACADEMY B — source Android en préparation

Cette archive contient l'application web d'origine améliorée, ainsi qu'une enveloppe Android Capacitor et un workflow GitHub Actions pour compiler un APK debug.

## Fonctions présentes
- Interface CORAN ACADEMY B et catalogue des 114 sourates.
- Lecteur audio de sourate pour les récitateurs Alafasy et Al-Husary via une source distante.
- Téléchargement audio dans le cache du navigateur/Android pour l'écoute ultérieure hors connexion, après téléchargement réussi.
- Mise en cache de l'interface par service worker en contexte web compatible.
- Configuration Capacitor Android et automatisation de compilation APK debug.

## Limites de contenu
- Le projet source ne contient pas le texte complet vérifié des 114 sourates ni les traductions complètes en français, Mooré et Dioula. Les versets absents ne sont plus remplacés par des textes fictifs : l'application affiche un avertissement.
- Les récitateurs burkinabè ne sont pas ajoutés faute de fichiers audio et d'autorisations documentées.
- Les hadiths, contenus de tajwid et réponses de l'assistant sont encore limités et nécessitent une vérification par des personnes qualifiées.
- L'audio dépend d'une source distante lors du premier chargement. La disponibilité et les droits de redistribution doivent être vérifiés avant publication.

## Construire l'APK
Consultez `BUILD_APK_ANDROID.md`. L'archive prépare le projet et le workflow, mais ne contient pas encore un APK compilé. Le workflow doit être exécuté sur GitHub Actions pour produire l'APK debug téléchargeable.
