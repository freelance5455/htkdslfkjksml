const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const out = path.join(root, 'www');
fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(out, { recursive: true });
for (const name of ['index.html', 'manifest.json', 'sw.js']) {
  fs.copyFileSync(path.join(root, name), path.join(out, name));
}
console.log('CORAN ACADEMY B web assets prepared in www/');
