#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle introuvable. Ouvrez ce projet dans Android Studio, synchronisez Gradle, puis lancez Build > Build APK(s)." >&2
  exit 2
fi
gradle --no-daemon assembleDebug
echo "APK : app/build/outputs/apk/debug/app-debug.apk"
