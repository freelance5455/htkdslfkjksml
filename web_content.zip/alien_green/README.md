# ALIEN x GREEN — Android latihan lokal project

A dark alien-green Android WebView app prototype. Features include local latihan lokal login, intro/loading, onboarding text, home dashboard, statistics, local history, tutorial, WA/Group simulation forms, local sender manager, and mock pairing code.

## Latihan lokal accounts
- catra / catra2026
- admin / admin123 (admin badge)
- tihh / tihh123

## Safety / behavior
All WA and group actions are UI-only simulations. The app does not connect to WhatsApp, send messages, attack targets, join groups, or pair real devices. Sender entries and history are stored locally in WebView localStorage.

## Build APK
Open this folder in Android Studio (Giraffe or newer) and allow Gradle sync. Then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The output is typically `app/build/outputs/apk/debug/app-debug.apk`.

This source package is provided; a compiled APK is not included because the current build environment does not have the Android SDK/Gradle toolchain installed.
