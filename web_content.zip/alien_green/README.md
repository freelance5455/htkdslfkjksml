# ALIEN x GREEN — Android latihan lokal project

A dark alien-green Android WebView app prototype. Features include local latihan lokal login, intro/loading, onboarding text, home dashboard, statistics, local history, tutorial, WA/Group simulation forms, local sender manager, and mock pairing code.

## Latihan lokal accounts
- catra / catra2026
- admin / admin123 (admin badge)
- tihh / tihh123
- Yafi / Yafi123

## Safety / behavior
All WA and group actions are UI-only simulations. The app does not connect to WhatsApp, send messages, attack targets, join groups, or pair real devices. Sender entries and history are stored locally in WebView localStorage.

## Build APK
Open this folder in Android Studio (Giraffe or newer) and allow Gradle sync. Then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The output is typically `app/build/outputs/apk/debug/app-debug.apk`.

This source package is provided; a compiled APK is not included because the current build environment does not have the Android SDK/Gradle toolchain installed.


Menu AI ALIEN menyediakan tanya-jawab lokal tentang panduan ALIEN x GREEN (login, menu, Bug WA/Grup, Manage Sender, Pairing, statistik, dan tutorial). Jawaban menggunakan basis informasi yang tertanam di aplikasi dan bukan layanan AI online.


Pembaruan V4: AI ALIEN mendukung sapaan sederhana, ucapan terima kasih/perpisahan, identitas asisten, bantuan, serta jawaban jam dan tanggal berdasarkan waktu perangkat.


Pembaruan V5: AI ALIEN mengenali lebih dari 500 kata dan ungkapan sehari-hari dalam bahasa Indonesia, termasuk sapaan, kabar, ucapan terima kasih, perasaan, aktivitas, makanan, sekolah, pekerjaan, hiburan, dan percakapan umum. Jawaban jam/tanggal tetap memakai waktu perangkat. Ini adalah pencocokan frasa dan jawaban lokal, bukan layanan AI online atau pemahaman bahasa bebas tanpa batas.


Pembaruan V6: menambahkan akun Yafi / Yafi123 serta kredit pembuat “by Zakaria Pratama or zipzupzap👽” pada layar intro dan login.
