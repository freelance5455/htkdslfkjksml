NEON VANGUARD — Offline HTML5 arcade shooter
================================================

Files
- index.html: complete self-contained game (CSS and JavaScript included)

Run locally
1. Extract the ZIP.
2. Open index.html in a modern browser.
3. The game works offline; no external libraries or network requests are used.

Controls
- Desktop: WASD / arrow keys to move, mouse to aim, click or Space to shoot, P to pause.
- Touch screens: use the Move and Fire buttons.

Notes for publication
- This is a playable HTML5 game prototype, not a signed Android APK.
- To publish as an Android app, package it with a trusted HTML-to-APK/WebView service or a Capacitor-based Android build, test on multiple devices, add your own publisher identity/privacy details if required, and sign the release build.
- Test game behavior, screen sizes, audio, and offline mode before public release.
