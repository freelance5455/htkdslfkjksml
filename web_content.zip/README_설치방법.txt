OmniVerse AI 앱형 웹앱 패키지
================================

이 폴더는 올려준 OmniVerse_AI_CORS_Fixed.html을 앱처럼 실행할 수 있도록
PWA(Progressive Web App) 형식으로 구성한 파일입니다.

포함 기능
- 축구 일정·결과 조회
- 과학 논문 검색
- 세계 뉴스
- 번역
- 도시별 날씨
- 휴대폰 홈 화면에 추가 가능한 앱 화면(HTTPS 웹 주소로 배포한 경우)

중요한 점
- 이 파일은 네이티브 Android APK가 아닙니다.
- PWA 설치를 위해서는 HTTPS 주소로 배포하거나 localhost에서 실행해야 합니다.
- 인터넷 데이터 기능은 인터넷 연결이 필요하고, 외부 API/CORS 정책에 따라 앱 내부 조회가 실패할 수 있습니다.
- 서비스 워커는 앱 화면 파일을 캐시하지만, 실시간 뉴스/경기/날씨/번역은 오프라인에서 제공되지 않습니다.

가장 쉬운 설치 방법(권장)
1. GitHub에 새 저장소(repository)를 만듭니다.
2. 이 폴더 안의 모든 파일을 저장소 최상위에 올립니다.
3. 저장소 Settings → Pages → Deploy from a branch → main / root를 선택하고 저장합니다.
4. 생성된 HTTPS 웹 주소를 Android Chrome으로 엽니다.
5. Chrome 메뉴(⋮)에서 '앱 설치' 또는 '홈 화면에 추가'를 누릅니다.

파일을 PC에서 테스트하려면
- Python 3이 설치된 폴더에서 터미널/명령 프롬프트를 열고 다음 명령을 실행하세요:
  python -m http.server 8000
- 브라우저에서 http://localhost:8000 을 엽니다.

참고: HTML 파일만 직접 열면(file://) PWA 설치와 일부 API 연결이 제한됩니다.
