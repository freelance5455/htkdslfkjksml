# Vérification Socle 5.0-D

- [x] Catalogue de 24 galaxies exposé pour la sélection.
- [x] 60 emplacements de clubs exposés (12 par division sur 5 divisions).
- [x] 36 clubs existants sélectionnables dès le démarrage.
- [x] 12 emplacements de Ligue C verrouillés jusqu'à l'activation en saison 3.
- [x] 12 emplacements de Ligue D verrouillés jusqu'à l'activation en saison 5.
- [x] Refus moteur d'un emplacement non activé.
- [x] Prise en charge des trois modes de carrière.
- [x] Création de carrière seulement après validation de la sélection.
- [x] Aucun faux club injecté dans les divisions futures.
- [x] Compatibilité avec les données existantes conservée : aucun changement de schéma de sauvegarde requis.

Limite connue : les 24 futures fiches club (noms et effectifs) ne sont pas présentes dans l'archive source 5.0-C. La sélection montre leurs emplacements verrouillés, sans inventer les données manquantes. Elles deviendront sélectionnables dès qu'elles seront réellement injectées lors de l'activation de leur division.

Commande de vérification : `npm test`
Résultat : 250 tests réussis, 0 échec.
