# Arrow Puzzle – Think • Rotate • Solve 🎯

A vibrant, commercial-quality, open-source casual puzzle game built entirely with **HTML5, CSS3, and Vanilla JavaScript (ES6+)**.

Playable instantly in any web browser without build tools, dependencies, backends, or servers.

---

## 🌟 Features

- **Intuitive Core Gameplay**: Tap or click arrows to rotate them clockwise and route the beam from **START** to **TARGET**.
- **100 Solvable Levels**: 5 progressive difficulty worlds:
  - **Levels 1–20**: Easy (3x3 to 4x4 grids)
  - **Levels 21–40**: Easy/Medium (4x4 grids)
  - **Levels 41–60**: Medium (5x5 grids with decoy paths)
  - **Levels 61–80**: Hard (5x5 grids with intricate turns)
  - **Levels 81–100**: Expert (5x5 grids with complex mazes)
- **Web Audio API Procedural Synthesizer**: Zero audio files required! Synthesizes crisp button clicks, arrow rotation snaps, path completion chimes, victory fanfare chords, star pops, coin pings, and procedural ambient background music.
- **8 Complete Screens & Modals**:
  1. Home / Start Screen
  2. 100-Level Selection Screen (with World Tabs & Star Ratings)
  3. Interactive Gameplay Screen (Beveled Metallic Frame)
  4. Pause Modal
  5. Level Complete Modal (Stars Animation, Stats & Canvas Confetti)
  6. Game Over / Lives Out Modal (with Auto-Regeneration Timer)
  7. Level Unlocked / Treasure Chest Reward Modal
  8. Settings Modal (Music, SFX, Vibration, Dark Mode, Multi-Language, Safe Reset)
- **Economy & Progression**:
  - Star rating system (1 to 3 stars based on optimal move count).
  - Coins earned on victories and bonus daily rewards.
  - Hint system (highlights misoriented arrows on the solution path).
  - Lives system (max 5 lives, auto-regenerates 1 life every 10 minutes, or refill with coins).
- **Multi-Language Localization**: English 🇺🇸, Spanish 🇪🇸, French 🇫🇷, German 🇩🇪, Japanese 🇯🇵.
- **Vibration & Haptics**: Tactile feedback on supported mobile devices.
- **Progressive Web App (PWA)**: Offline-first caching via Service Worker.
- **100% Dependency-Free**: Zero npm dependencies, zero frameworks, pure web platform. Firebase, PHP and Node.js backends are not required.

---

## 🚀 How to Run

### Option 1: Direct File Opening
Simply double-click `index.html` or drag it into any web browser (Chrome, Firefox, Safari, Edge).

### Option 2: Static Web Server
Run with any static server or deploy directly to **GitHub Pages**, **Vercel**, **Netlify**, or **Cloudflare Pages**:
```bash
# Python
python -m http.server 8000

# Node / npx
npx serve .
```
Then visit `http://localhost:8000`.

---

## 📁 Project Structure

```text
arrow/
├── index.html              # Main single-page application shell
├── manifest.json           # Progressive Web App manifest
├── sw.js                   # PWA Service Worker for offline play
├── LICENSE                 # MIT License
├── README.md               # Documentation & customization guide
│
├── css/
│   ├── style.css           # Global design system, tokens, background & 3D buttons
│   ├── home.css            # Home screen layout & 3D logo
│   ├── levels.css          # 100-level selection grid, tabs & stars
│   ├── game.css            # Puzzle board frame, tiles & neon path glow
│   └── modals.css          # Overlays (Pause, Complete, Game Over, Unlock, Settings)
│
├── js/
│   ├── storage.js          # LocalStorage progression, currency & life regeneration
│   ├── audio.js            # Web Audio API procedural sound & music engine
│   ├── levels.js           # 100 verified solvable levels dataset
│   ├── puzzle-engine.js    # Graph traversal, beam routing, rotation & stars
│   ├── ui.js               # Screen navigation, modals, HUD & confetti
│   ├── settings.js         # Settings, theme, vibration & i18n localization
│   └── app.js              # Main coordinator & lifecycle bootstrapping
│
├── assets/
│   ├── icons/              # SVG UI icons (coin, hearts, stars, locks, play, etc.)
│   ├── arrows/             # 6 colored SVG puzzle arrows (blue, green, yellow, orange, purple, cyan)
│   ├── puzzle/             # Puzzle nodes (start beacon, target bullseye, active target)
│   ├── rewards/            # Reward assets (closed/open chests, royal crown, sparkles)
│   ├── decorations/        # Layered scenic graphics (clouds, mountains, trees)
│   └── backgrounds/        # Screen-specific atmospheric backgrounds (home, levels, gameplay)
│
└── tests/
    └── solver-test.js      # Automated validation script testing all 100 levels
```

---

## 🛠️ How to Customize & Extend

### 1. Adding New Levels
Open [`js/levels.js`](js/levels.js) and add a new level object to `window.LEVELS_DATA`:
```javascript
{
    id: 101,
    name: "Level 101",
    world: 5,
    rows: 5,
    cols: 5,
    start: { row: 0, col: 0, dir: "RIGHT" },
    target: { row: 4, col: 4 },
    parMoves: 6,
    arrows: [
        { row: 0, col: 1, direction: "DOWN", correctDir: "RIGHT", color: "#00d2ff" },
        { row: 0, col: 2, direction: "LEFT", correctDir: "DOWN", color: "#43e97b" },
        // ...
    ]
}
```

### 2. Customizing Colors & Themes
Open [`css/style.css`](css/style.css) and modify the CSS custom properties in `:root`:
```css
:root {
    --c-sky-top: #38bdf8;
    --c-sky-bottom: #bae6fd;
    --c-btn-green: #22c55e;
    --c-btn-blue: #0284c7;
    --c-btn-purple: #9333ea;
}
```

### 3. Adding New Languages
Open [`js/settings.js`](js/settings.js) and add your language code and translations to `TRANSLATIONS`:
```javascript
TRANSLATIONS.pt = {
    gameTitle: "ARCO PUZZLE",
    play: "JOGAR",
    // ...
};
```

---

## 🧪 Testing

Open the game in your browser, press `F12` to open the developer console, and run:
```javascript
runSolverTests();
```
This runs an automated schema + solution-path test across all levels. It is also available as a Node-compatible test script:

```bash
node tests/solver-test.js
```

---

## 📄 License

This project is licensed under the [MIT License](LICENSE).
Feel free to use, modify, and distribute this game for educational or commercial purposes.

## UI & First-Time Tutorial

The game uses a screen-based flow: **Home → Level Select → Gameplay**. Only one top-level screen is visible at a time.

On the first launch of Level 1, a short interactive 3-step tutorial appears. It highlights real arrow tiles and advances from actual player taps. The tutorial is stored in `localStorage` under `arrowPuzzle_tutorial_v2` and can be shown again by using **Reset Progress** in Settings.

The UI is intentionally built with HTML/CSS/SVG and vanilla JavaScript so it remains static-hosting friendly. No Firebase, PHP, Node.js backend, React, Vue, or Angular is required.

## Responsive UI

Version 1.3.0 includes responsive layouts for small phones (320px+), normal phones, tablets, desktop browsers, portrait/landscape orientations, safe-area insets, and reduced-motion preferences. The puzzle board scales while preserving its square aspect ratio and touch controls remain usable on coarse-pointer devices.


### Shared World Background
`assets/backgrounds/world-bg.webp` is the main responsive game-world background used across Home, Level Select and Gameplay. The CSS applies screen-specific dark/light overlays while preserving the same visual world.
