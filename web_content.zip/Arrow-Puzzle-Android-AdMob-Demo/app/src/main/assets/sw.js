/**
 * sw.js - Service Worker for Offline PWA Support with Comprehensive Asset Pre-Caching
 */

const CACHE_NAME = 'arrow-puzzle-v1.4.0';
const ASSETS_TO_CACHE = [
    './',
    './index.html',
    './manifest.json',
    './css/style.css',
    './css/home.css',
    './css/levels.css',
    './css/game.css',
    './css/modals.css',
    './js/storage.js',
    './js/audio.js',
    './js/levels.js',
    './js/puzzle-engine.js',
    './js/settings.js',
    './js/ui.js',
    './js/app.js',
    // Icons
    './assets/icons/favicon.svg',
    './assets/icons/icon-192.svg',
    './assets/icons/icon-512.svg',
    './assets/icons/coin.svg',
    './assets/icons/heart-full.svg',
    './assets/icons/heart-empty.svg',
    './assets/icons/heart-broken.svg',
    './assets/icons/star.svg',
    './assets/icons/star-empty.svg',
    './assets/icons/lock.svg',
    './assets/icons/unlock.svg',
    './assets/icons/hint.svg',
    './assets/icons/undo.svg',
    './assets/icons/reset.svg',
    './assets/icons/pause.svg',
    './assets/icons/play.svg',
    './assets/icons/home.svg',
    './assets/icons/settings.svg',
    './assets/icons/music.svg',
    './assets/icons/sound.svg',
    './assets/icons/vibration.svg',
    './assets/icons/language.svg',
    './assets/icons/share.svg',
    './assets/icons/gamepad.svg',
    './assets/icons/rate.svg',
    './assets/icons/moon.svg',
    './assets/icons/sun.svg',
    // Arrows
    './assets/arrows/arrow-blue.svg',
    './assets/arrows/arrow-green.svg',
    './assets/arrows/arrow-yellow.svg',
    './assets/arrows/arrow-orange.svg',
    './assets/arrows/arrow-purple.svg',
    './assets/arrows/arrow-cyan.svg',
    // Puzzle Nodes
    './assets/puzzle/start.svg',
    './assets/puzzle/target.svg',
    './assets/puzzle/target-active.svg',
    // Rewards
    './assets/rewards/chest-closed.svg',
    './assets/rewards/chest-open.svg',
    './assets/rewards/crown.svg',
    './assets/rewards/sparkle.svg',
    // Decorations
    './assets/decorations/clouds.svg',
    './assets/decorations/mountains-back.svg',
    './assets/decorations/mountains-front.svg',
    './assets/decorations/trees.svg',
    // Backgrounds
    './assets/backgrounds/home-bg.svg',
    './assets/backgrounds/levels-bg.svg',
    './assets/backgrounds/gameplay-bg.svg',
    './assets/backgrounds/world-bg.webp'
];

self.addEventListener('install', (event) => {
    event.waitUntil(
        caches.open(CACHE_NAME).then((cache) => {
            return cache.addAll(ASSETS_TO_CACHE);
        }).then(() => self.skipWaiting())
    );
});

self.addEventListener('activate', (event) => {
    event.waitUntil(
        caches.keys().then((keys) => {
            return Promise.all(
                keys.map((key) => {
                    if (key !== CACHE_NAME) {
                        return caches.delete(key);
                    }
                })
            );
        }).then(() => self.clients.claim())
    );
});

self.addEventListener('fetch', (event) => {
    // Only cache GET requests
    if (event.request.method !== 'GET') return;

    event.respondWith(
        caches.match(event.request).then((cachedResponse) => {
            if (cachedResponse) {
                return cachedResponse;
            }
            return fetch(event.request).then((networkResponse) => {
                if (!networkResponse || networkResponse.status !== 200 || networkResponse.type !== 'basic') {
                    return networkResponse;
                }
                const responseToCache = networkResponse.clone();
                caches.open(CACHE_NAME).then((cache) => {
                    cache.put(event.request, responseToCache);
                });
                return networkResponse;
            }).catch(() => {
                // Return offline cached index.html if html navigation
                if (event.request.headers.get('accept') && event.request.headers.get('accept').includes('text/html')) {
                    return caches.match('./index.html');
                }
            });
        })
    );
});
