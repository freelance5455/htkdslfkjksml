/**
 * app.js - Main Application Coordinator & Game Lifecycle
 * Ties together Storage, Audio, PuzzleEngine, Settings, and UI.
 */

const GAME_CONFIG = Object.freeze({
    name: 'Arrow Puzzle',
    moreGamesUrl: '',
    rateUrl: ''
});

class ArrowPuzzleApp {
    constructor() {
        this.currentLevelId = 1;
        this.isProcessingMove = false;
        this.unlockedNextId = null;
        this.unlockedBonus = null;
        this.tutorialStep = 0;
        this.tutorialActive = false;
    }

    init() {
        window.UI.init();
        this._bindEvents();

        // Check if there is an active level saved or start at 1
        const highestUnlocked = Math.max(...window.Storage.data.unlockedLevels);
        this.currentLevelId = highestUnlocked || 1;

        // Apply any saved language & theme
        window.Settings.init();

        console.log('Arrow Puzzle initialized successfully.');
    }

    _bindEvents() {
        // === HOME SCREEN BUTTONS ===
        const btnPlay = document.getElementById('btn-home-play');
        if (btnPlay) {
            btnPlay.addEventListener('click', () => {
                if (window.Audio) window.Audio.playClick();
                const highestUnlocked = Math.max(...window.Storage.data.unlockedLevels);
                this.startLevel(highestUnlocked);
            });
        }

        const btnLevels = document.getElementById('btn-home-levels');
        if (btnLevels) {
            btnLevels.addEventListener('click', () => {
                if (window.Audio) window.Audio.playClick();
                window.UI.showScreen('screen-levels');
            });
        }

        const btnSettings = document.getElementById('btn-home-settings');
        if (btnSettings) {
            btnSettings.addEventListener('click', () => {
                if (window.Audio) window.Audio.playClick();
                this.openSettingsModal();
            });
        }

        const btnMoreGames = document.getElementById('btn-more-games');
        if (btnMoreGames) {
            btnMoreGames.addEventListener('click', () => {
                if (window.Audio) window.Audio.playClick();
                if (GAME_CONFIG.moreGamesUrl) { window.location.href = GAME_CONFIG.moreGamesUrl; } else { window.UI.showModal('modal-more-games'); }
            });
        }

        const btnShare = document.getElementById('btn-share');
        if (btnShare) {
            btnShare.addEventListener('click', () => {
                if (window.Audio) window.Audio.playClick();
                this.handleShare();
            });
        }

        const btnRate = document.getElementById('btn-rate');
        if (btnRate) {
            btnRate.addEventListener('click', () => {
                if (window.Audio) window.Audio.playClick();
                if (GAME_CONFIG.rateUrl) { window.location.href = GAME_CONFIG.rateUrl; } else { window.UI.showModal('modal-rate'); }
            });
        }

        // === FIRST-TIME TUTORIAL ===
        const tutorialNext = document.getElementById('btn-tutorial-next');
        const tutorialSkip = document.getElementById('btn-tutorial-skip');
        if (tutorialNext) {
            tutorialNext.addEventListener('click', () => {
                if (window.Audio) window.Audio.playClick();
                this.advanceTutorial();
            });
        }
        if (tutorialSkip) {
            tutorialSkip.addEventListener('click', () => {
                if (window.Audio) window.Audio.playClick();
                this.finishTutorial();
            });
        }

        // === LEVEL SELECT SCREEN ===
        const btnLevelsBack = document.getElementById('btn-levels-back');
        if (btnLevelsBack) {
            btnLevelsBack.addEventListener('click', () => {
                if (window.Audio) window.Audio.playClick();
                window.UI.showScreen('screen-home');
            });
        }

        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                if (window.Audio) window.Audio.playClick();
                const pack = Number(btn.getAttribute('data-pack'));
                window.UI.setLevelPack(pack);
            });
        });

        const btnPackPrev = document.getElementById('btn-pack-prev');
        if (btnPackPrev) {
            btnPackPrev.addEventListener('click', () => {
                if (window.Audio) window.Audio.playClick();
                window.UI.setLevelPack(window.UI.currentLevelPack - 1);
            });
        }

        const btnPackNext = document.getElementById('btn-pack-next');
        if (btnPackNext) {
            btnPackNext.addEventListener('click', () => {
                if (window.Audio) window.Audio.playClick();
                window.UI.setLevelPack(window.UI.currentLevelPack + 1);
            });
        }

        // === GAMEPLAY HUD & CONTROLS ===
        const btnGameBack = document.getElementById('btn-game-back');
        if (btnGameBack) {
            btnGameBack.addEventListener('click', () => {
                if (window.Audio) window.Audio.playClick();
                window.UI.showScreen('screen-levels');
            });
        }

        const btnGamePause = document.getElementById('btn-game-pause');
        if (btnGamePause) {
            btnGamePause.addEventListener('click', () => {
                if (window.Audio) window.Audio.playClick();
                window.UI.showModal('modal-pause');
            });
        }

        const btnUndo = document.getElementById('btn-undo');
        if (btnUndo) {
            btnUndo.addEventListener('click', () => {
                if (window.Audio) window.Audio.playClick();
                const res = window.PuzzleEngine.undo();
                if (res) {
                    window.UI.updateTileRotation(res.row, res.col, res.dir, res.angle);
                    window.UI.refreshBoardPath(window.PuzzleEngine.grid, res.isSolved);
                    this.updateGameplayHUD();
                }
            });
        }

        const btnReset = document.getElementById('btn-reset');
        if (btnReset) {
            btnReset.addEventListener('click', () => {
                if (window.Audio) window.Audio.playClick();
                this.startLevel(this.currentLevelId, false);
            });
        }

        const btnHint = document.getElementById('btn-hint');
        if (btnHint) {
            btnHint.addEventListener('click', () => {
                this.handleHint();
            });
        }

        // === PAUSE MODAL BUTTONS ===
        const btnResume = document.getElementById('btn-pause-resume');
        if (btnResume) {
            btnResume.addEventListener('click', () => {
                if (window.Audio) window.Audio.playClick();
                window.UI.hideModal('modal-pause');
            });
        }

        const btnRestart = document.getElementById('btn-pause-restart');
        if (btnRestart) {
            btnRestart.addEventListener('click', () => {
                if (window.Audio) window.Audio.playClick();
                window.UI.hideModal('modal-pause');
                // Restarting the level you're already attempting should not cost an
                // extra life on top of the one already spent to start this attempt.
                this.startLevel(this.currentLevelId, false);
            });
        }

        const btnPauseHome = document.getElementById('btn-pause-home');
        if (btnPauseHome) {
            btnPauseHome.addEventListener('click', () => {
                if (window.Audio) window.Audio.playClick();
                window.UI.hideModal('modal-pause');
                window.UI.showScreen('screen-home');
            });
        }

        const btnPauseSettings = document.getElementById('btn-pause-settings');
        if (btnPauseSettings) {
            btnPauseSettings.addEventListener('click', () => {
                if (window.Audio) window.Audio.playClick();
                this.openSettingsModal();
            });
        }

        // === LEVEL COMPLETE MODAL BUTTONS ===
        const btnNextLevel = document.getElementById('btn-complete-next');
        if (btnNextLevel) {
            btnNextLevel.addEventListener('click', () => {
                if (window.Audio) window.Audio.playClick();
                window.UI.hideModal('modal-complete');
                const nextId = this.currentLevelId + 1;
                if (nextId <= window.LEVELS_DATA.length) {
                    // Check if newly unlocked reward screen should show
                    if (this.unlockedNextId === nextId) {
                        this.showLevelUnlockedModal(nextId, this.unlockedBonus);
                        this.unlockedNextId = null;
                        this.unlockedBonus = null;
                    } else {
                        this.startLevel(nextId);
                    }
                } else {
                    window.UI.showToast('Congratulations! You completed all 100 levels!');
                    window.UI.showScreen('screen-levels');
                }
            });
        }

        const btnReplay = document.getElementById('btn-complete-replay');
        if (btnReplay) {
            btnReplay.addEventListener('click', () => {
                if (window.Audio) window.Audio.playClick();
                window.UI.hideModal('modal-complete');
                // Replaying a level you already beat (to improve your score) should
                // not cost a life, consistent with the in-game Reset button.
                this.startLevel(this.currentLevelId, false);
            });
        }

        const btnCompleteHome = document.getElementById('btn-complete-home');
        if (btnCompleteHome) {
            btnCompleteHome.addEventListener('click', () => {
                if (window.Audio) window.Audio.playClick();
                window.UI.hideModal('modal-complete');
                window.UI.showScreen('screen-home');
            });
        }

        // === LEVEL UNLOCK MODAL BUTTONS ===
        const btnUnlockPlay = document.getElementById('btn-unlock-play');
        if (btnUnlockPlay) {
            btnUnlockPlay.addEventListener('click', () => {
                if (window.Audio) window.Audio.playClick();
                window.UI.hideModal('modal-unlock');
                this.startLevel(this.currentLevelId + 1);
            });
        }

        // === GAME OVER MODAL BUTTONS ===
        const btnGameOverRetry = document.getElementById('btn-gameover-retry');
        if (btnGameOverRetry) {
            btnGameOverRetry.addEventListener('click', () => {
                if (window.Audio) window.Audio.playClick();
                if (window.Storage.getLives() <= 0) {
                    window.UI.showToast(window.Settings.t('outOfLives'));
                    return;
                }
                window.UI.hideModal('modal-gameover');
                this.startLevel(this.currentLevelId);
            });
        }

        const btnGameOverHome = document.getElementById('btn-gameover-home');
        if (btnGameOverHome) {
            btnGameOverHome.addEventListener('click', () => {
                if (window.Audio) window.Audio.playClick();
                window.UI.hideModal('modal-gameover');
                window.UI.showScreen('screen-home');
            });
        }

        const btnRefillLives = document.getElementById('btn-refill-lives');
        if (btnRefillLives) {
            btnRefillLives.addEventListener('click', () => {
                if (window.Storage.getCoins() >= 100) {
                    window.Storage.spendCoins(100);
                    window.Storage.refillLives();
                    window.UI.updateHUD();
                    window.UI.hideModal('modal-gameover');
                    window.UI.showToast('Lives refilled to 5!');
                    this.startLevel(this.currentLevelId);
                } else {
                    window.UI.showToast('Need 100 coins to refill lives!');
                }
            });
        }

        // === SETTINGS MODAL BINDINGS ===
        const btnSettingsBack = document.getElementById('btn-settings-back');
        if (btnSettingsBack) {
            btnSettingsBack.addEventListener('click', () => {
                if (window.Audio) window.Audio.playClick();
                window.UI.hideModal('modal-settings');
            });
        }

        const toggleMusic = document.getElementById('toggle-music');
        if (toggleMusic) {
            toggleMusic.addEventListener('change', (e) => {
                window.Audio.setMusicEnabled(e.target.checked);
            });
        }

        const toggleSfx = document.getElementById('toggle-sfx');
        if (toggleSfx) {
            toggleSfx.addEventListener('change', (e) => {
                window.Audio.setSfxEnabled(e.target.checked);
            });
        }

        const toggleVibration = document.getElementById('toggle-vibration');
        if (toggleVibration) {
            toggleVibration.addEventListener('change', (e) => {
                window.Settings.setVibration(e.target.checked);
            });
        }

        const toggleDarkMode = document.getElementById('toggle-darkmode');
        if (toggleDarkMode) {
            toggleDarkMode.addEventListener('change', (e) => {
                window.Settings.setDarkMode(e.target.checked);
            });
        }

        const selectLanguage = document.getElementById('select-language');
        if (selectLanguage) {
            selectLanguage.addEventListener('change', (e) => {
                window.Settings.setLanguage(e.target.value);
            });
        }

        const btnResetProgress = document.getElementById('btn-reset-progress');
        if (btnResetProgress) {
            btnResetProgress.addEventListener('click', () => {
                if (window.Audio) window.Audio.playClick();
                window.UI.showModal('modal-reset-confirm');
            });
        }

        const btnConfirmReset = document.getElementById('btn-confirm-reset');
        if (btnConfirmReset) {
            btnConfirmReset.addEventListener('click', () => {
                if (window.Audio) window.Audio.playClick();
                window.Storage.resetProgress();
                // Reset the first-time tutorial together with game progress.
                localStorage.removeItem('arrowPuzzle_tutorial_v2');
                window.UI.hideModal('modal-reset-confirm');
                window.UI.hideModal('modal-settings');
                window.UI.updateHUD();
                window.UI.renderLevelSelect();
                window.UI.showToast('All progress has been reset.');
                window.UI.showScreen('screen-home');
            });
        }

        const btnCancelReset = document.getElementById('btn-cancel-reset');
        if (btnCancelReset) {
            btnCancelReset.addEventListener('click', () => {
                if (window.Audio) window.Audio.playClick();
                window.UI.hideModal('modal-reset-confirm');
            });
        }

        // Close generic dialog buttons
        document.querySelectorAll('.btn-close-modal').forEach(btn => {
            btn.addEventListener('click', () => {
                if (window.Audio) window.Audio.playClick();
                window.UI.closeAllModals();
            });
        });

        // Top HUD plus buttons (add coins / refill lives)
        document.querySelectorAll('.hud-lives-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                if (window.Storage.getLives() < 5) {
                    if (window.Storage.getCoins() >= 50) {
                        window.Storage.spendCoins(50);
                        window.Storage.refillLives();
                        window.UI.updateHUD();
                        window.UI.showToast('Lives refilled! (-50 Coins)');
                        if (window.Audio) window.Audio.playCoin();
                    } else {
                        window.UI.showToast('Need 50 coins to refill lives!');
                    }
                } else {
                    window.UI.showToast('Lives are already full! (5/5)');
                }
            });
        });

        document.querySelectorAll('.hud-coins-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const reward = window.Storage.claimDailyReward();
                window.UI.updateHUD();
                if (reward.claimed) {
                    if (window.Audio) window.Audio.playCoin();
                    window.UI.showToast(`+${reward.amount} Daily Bonus Coins!`);
                } else {
                    window.UI.showToast('Daily coin bonus already claimed today.');
                }
            });
        });
    }

    startLevel(levelId, deductLifeOnFail = true) {
        if (!window.LEVELS_DATA) return;
        const levelData = window.LEVELS_DATA.find(lvl => lvl.id === Number(levelId));
        if (!levelData) {
            console.error('Level not found:', levelId);
            return;
        }

        // Check lives
        if (window.Storage.getLives() <= 0) {
            window.UI.showModal('modal-gameover');
            if (window.Audio) window.Audio.playGameOver();
            return;
        }

        // A life is consumed when a new attempt starts. Replay/reset uses false
        // so players can retry the current board without another life charge.
        if (deductLifeOnFail) {
            window.Storage.loseLife();
            window.UI.updateHUD();
        }

        this.currentLevelId = Number(levelId);
        this.isProcessingMove = false;

        const engineState = window.PuzzleEngine.loadLevel(levelData);

        // Update Level indicator in HUD
        const badge = document.getElementById('game-level-badge');
        if (badge) badge.textContent = `Level ${levelId}`;

        const movesVal = document.getElementById('game-moves-val');
        if (movesVal) movesVal.textContent = '0';

        // Render board
        window.UI.renderBoard(engineState, (r, c) => this.handleTileClick(r, c));

        // Switch to Game Screen
        window.UI.showScreen('screen-game');

        // Guide a first-time player on Level 1 only. The tutorial is stored
        // locally, so returning players never see it again unless progress is reset.
        if (this.currentLevelId === 1 && !localStorage.getItem('arrowPuzzle_tutorial_v2')) {
            requestAnimationFrame(() => this.startTutorial());
        }
    }

    startTutorial() {
        if (this.currentLevelId !== 1 || this.tutorialActive) return;
        const overlay = document.getElementById('tutorial-overlay');
        if (!overlay) return;
        this.tutorialActive = true;
        this.tutorialStep = 1;
        overlay.classList.add('active');
        overlay.setAttribute('aria-hidden', 'false');
        this.updateTutorial();
    }

    updateTutorial() {
        const overlay = document.getElementById('tutorial-overlay');
        const stepEl = document.getElementById('tutorial-step-number');
        const titleEl = document.getElementById('tutorial-title');
        const messageEl = document.getElementById('tutorial-message');
        const nextEl = document.getElementById('btn-tutorial-next');
        const iconEl = document.getElementById('tutorial-icon');
        if (!overlay) return;

        document.querySelectorAll('.puzzle-tile.tutorial-focus').forEach(el => el.classList.remove('tutorial-focus'));

        const arrows = Array.from(document.querySelectorAll('#puzzle-board .arrow-tile'));
        const focusIndex = this.tutorialStep === 1 ? 0 : (this.tutorialStep === 2 ? 1 : -1);
        if (focusIndex >= 0 && arrows[focusIndex]) arrows[focusIndex].classList.add('tutorial-focus');

        if (this.tutorialStep === 1) {
            stepEl.textContent = '1';
            titleEl.textContent = 'Tap an Arrow';
            messageEl.textContent = 'Tap the glowing arrow. Each tap rotates it by 90°.';
            nextEl.textContent = 'Try It';
            iconEl.src = 'assets/icons/undo.svg';
        } else if (this.tutorialStep === 2) {
            stepEl.textContent = '2';
            titleEl.textContent = 'Rotate to Connect';
            messageEl.textContent = 'Keep rotating arrows until their tips point into the next tile.';
            nextEl.textContent = 'Try It';
            iconEl.src = 'assets/icons/reset.svg';
        } else {
            stepEl.textContent = '3';
            titleEl.textContent = 'Reach the Target';
            messageEl.textContent = 'Connect START to TARGET. The glowing tiles show the connected path.';
            nextEl.textContent = 'Start Playing';
            iconEl.src = 'assets/puzzle/target-active.svg';
        }
    }

    advanceTutorial() {
        if (!this.tutorialActive) return;
        if (this.tutorialStep < 3) {
            this.tutorialStep += 1;
            this.updateTutorial();
        } else {
            this.finishTutorial();
        }
    }

    finishTutorial() {
        const overlay = document.getElementById('tutorial-overlay');
        this.tutorialActive = false;
        this.tutorialStep = 0;
        localStorage.setItem('arrowPuzzle_tutorial_v2', '1');
        document.querySelectorAll('.puzzle-tile.tutorial-focus').forEach(el => el.classList.remove('tutorial-focus'));
        if (overlay) {
            overlay.classList.remove('active');
            overlay.setAttribute('aria-hidden', 'true');
        }
    }

    handleTileClick(row, col) {
        if (this.isProcessingMove || window.PuzzleEngine.isSolved) return;

        // Check lives
        if (window.Storage.getLives() <= 0) {
            window.UI.showModal('modal-gameover');
            if (window.Audio) window.Audio.playGameOver();
            return;
        }

        // Rotate arrow in engine
        const res = window.PuzzleEngine.rotateArrow(row, col);
        if (!res) return;

        // Tutorial progresses from real player input rather than fake demo moves.
        if (this.tutorialActive && this.tutorialStep <= 2) {
            const focusTiles = Array.from(document.querySelectorAll('#puzzle-board .arrow-tile'));
            const expected = focusTiles[this.tutorialStep - 1];
            const clicked = document.getElementById(`tile-${row}-${col}`);
            if (expected && clicked === expected) {
                this.tutorialStep += 1;
                this.updateTutorial();
            }
        }

        // SFX & Haptics
        if (window.Audio) window.Audio.playRotate();
        if (window.Settings) window.Settings.vibrate(35);

        // Update visual rotation
        window.UI.updateTileRotation(res.row, res.col, res.newDir, res.angle);
        window.UI.refreshBoardPath(window.PuzzleEngine.grid, res.isSolved);
        this.updateGameplayHUD();

        // If path connected to target: WIN!
        if (res.isSolved) {
            this.handleLevelWin();
        }
    }

    handleLevelWin() {
        this.isProcessingMove = true;

        if (window.Audio) {
            window.Audio.playLevelComplete();
        }
        if (window.Settings) {
            window.Settings.vibrate([60, 40, 100]);
        }

        // Confetti explosion!
        window.UI.triggerConfetti(2800);

        const moves = window.PuzzleEngine.moves;
        const stars = window.PuzzleEngine.calculateStars();
        const baseCoins = 25;
        const bonusCoins = stars === 3 ? 25 : (stars === 2 ? 10 : 0);
        const coinsEarned = baseCoins + bonusCoins;

        // Record progress in storage
        const result = window.Storage.recordLevelCompletion(this.currentLevelId, stars, moves, coinsEarned);
        if (result.newlyUnlocked) {
            this.unlockedNextId = result.nextId;
            this.unlockedBonus = result.unlockBonus;
        }

        // Animate stars sound & visual reveal
        setTimeout(() => {
            this.showLevelCompleteModal(stars, moves, coinsEarned);
            this.isProcessingMove = false;
            // Android wrapper: show a Google demo interstitial every 3 completed levels.
            if (window.AndroidAds && typeof window.AndroidAds.levelCompleted === 'function') {
                window.AndroidAds.levelCompleted();
            }
        }, 700);
    }

    showLevelCompleteModal(stars, moves, coinsEarned) {
        const modal = document.getElementById('modal-complete');
        if (!modal) return;

        const levelNumEl = document.getElementById('complete-level-num');
        if (levelNumEl) levelNumEl.textContent = `Level ${this.currentLevelId}`;

        const movesEl = document.getElementById('complete-moves-val');
        if (movesEl) movesEl.textContent = moves;

        const coinsEl = document.getElementById('complete-coins-val');
        if (coinsEl) coinsEl.textContent = `+${coinsEarned}`;

        const bestEl = document.getElementById('complete-best-val');
        if (bestEl) {
            const best = window.Storage.getBestMoves(this.currentLevelId) || moves;
            bestEl.textContent = best;
        }

        // Reset and animate stars in modal
        for (let i = 1; i <= 3; i++) {
            const starEl = document.getElementById(`complete-star-${i}`);
            if (starEl) {
                starEl.classList.remove('revealed', 'active');
                if (i <= stars) {
                    setTimeout(() => {
                        starEl.classList.add('revealed', 'active');
                        if (window.Audio) window.Audio.playStar(i);
                    }, i * 260);
                }
            }
        }

        window.UI.showModal('modal-complete');
        window.UI.updateHUD();
    }

    showLevelUnlockedModal(nextLevelId, bonus) {
        const modal = document.getElementById('modal-unlock');
        if (!modal) return;

        const numEl = document.getElementById('unlock-level-num');
        if (numEl) numEl.textContent = `Level ${nextLevelId}`;
        const rewardText = modal.querySelector('.unlock-coin-reward');
        if (rewardText) rewardText.textContent = `+${bonus || 50}`;

        if (window.Audio) window.Audio.playUnlock();
        window.UI.showModal('modal-unlock');
    }

    handleHint() {
        if (window.PuzzleEngine.isSolved) return;

        const hintCost = 20;
        if (window.Storage.getCoins() < hintCost) {
            window.UI.showToast('Need 20 coins for a hint!');
            if (window.Audio) window.Audio.playError();
            const btn = document.getElementById('btn-hint');
            if (btn) {
                btn.classList.add('shake');
                setTimeout(() => btn.classList.remove('shake'), 400);
            }
            return;
        }

        const hint = window.PuzzleEngine.getHint();
        if (hint) {
            window.Storage.spendCoins(hintCost);
            window.Storage.data.stats.hintsUsed = (window.Storage.data.stats.hintsUsed || 0) + 1;
            window.Storage.save();
            window.UI.updateHUD();
            if (window.Audio) window.Audio.playHint();

            const tile = document.getElementById(`tile-${hint.row}-${hint.col}`);
            if (tile) {
                tile.classList.add('hint-active');
            }
            window.UI.showToast(`Hint: Rotate arrow at (${hint.row + 1}, ${hint.col + 1})`);
        } else {
            window.UI.showToast('Path is almost complete! Check connected arrows.');
        }
    }

    handleShare() {
        const text = `I'm playing Arrow Puzzle! Can you beat Level ${this.currentLevelId}? 🎯 Think • Rotate • Solve!`;
        const url = window.location.href;

        if (navigator.share) {
            navigator.share({
                title: 'Arrow Puzzle',
                text: text,
                url: url
            }).catch(() => {});
        } else if (navigator.clipboard) {
            navigator.clipboard.writeText(`${text} ${url}`).then(() => {
                window.UI.showToast(window.Settings.t('copied'));
            }).catch(() => {
                window.UI.showModal('modal-share');
            });
        } else {
            window.UI.showModal('modal-share');
        }
    }

    openSettingsModal() {
        const s = window.Storage.getSettings();

        const toggleMusic = document.getElementById('toggle-music');
        if (toggleMusic) toggleMusic.checked = !!s.music;

        const toggleSfx = document.getElementById('toggle-sfx');
        if (toggleSfx) toggleSfx.checked = !!s.sfx;

        const toggleVibration = document.getElementById('toggle-vibration');
        if (toggleVibration) toggleVibration.checked = s.vibration !== false;

        const toggleDarkMode = document.getElementById('toggle-darkmode');
        if (toggleDarkMode) toggleDarkMode.checked = !!s.darkMode;

        const selectLanguage = document.getElementById('select-language');
        if (selectLanguage) selectLanguage.value = s.language || 'en';

        window.UI.showModal('modal-settings');
    }

    updateGameplayHUD() {
        const movesVal = document.getElementById('game-moves-val');
        if (movesVal) movesVal.textContent = window.PuzzleEngine.moves;

        const btnUndo = document.getElementById('btn-undo');
        if (btnUndo) {
            btnUndo.disabled = window.PuzzleEngine.undoStack.length === 0;
            btnUndo.style.opacity = window.PuzzleEngine.undoStack.length === 0 ? '0.6' : '1.0';
        }
    }
}

// Global bootstrap
window.addEventListener('DOMContentLoaded', () => {
    window.App = new ArrowPuzzleApp();
    window.App.init();

    // Register PWA Service Worker if supported and on https or localhost
    if ('serviceWorker' in navigator && (window.location.protocol === 'https:' || window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1')) {
        navigator.serviceWorker.register('sw.js').catch(err => {
            console.log('SW registration skipped or failed:', err);
        });
    }
});
