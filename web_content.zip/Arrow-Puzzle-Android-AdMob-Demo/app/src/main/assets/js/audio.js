/**
 * audio.js - Web Audio API Procedural Sound & Music Engine
 * Generates crisp, arcade-quality sound effects and a pleasant relaxing
 * background soundtrack entirely via Web Audio oscillators and envelopes.
 * Zero external audio files required, 100% offline & instant playback.
 */

class AudioManager {
    constructor() {
        this.ctx = null;
        this.masterGain = null;
        this.sfxGain = null;
        this.musicGain = null;
        this.isUnlocked = false;

        this.sfxEnabled = true;
        this.musicEnabled = true;

        this.bgmTimer = null;
        this.bgmStep = 0;
        this.bgmPlaying = false;

        this._initSettings();
        this._bindUnlock();
    }

    _initSettings() {
        if (window.Storage) {
            const settings = window.Storage.getSettings();
            this.sfxEnabled = !!settings.sfx;
            this.musicEnabled = !!settings.music;
        }
    }

    _ensureContext() {
        if (!this.ctx) {
            const AudioContext = window.AudioContext || window.webkitAudioContext;
            if (!AudioContext) return null;
            this.ctx = new AudioContext();

            this.masterGain = this.ctx.createGain();
            this.masterGain.gain.setValueAtTime(1.0, this.ctx.currentTime);
            this.masterGain.connect(this.ctx.destination);

            this.sfxGain = this.ctx.createGain();
            this.sfxGain.gain.setValueAtTime(0.7, this.ctx.currentTime);
            this.sfxGain.connect(this.masterGain);

            this.musicGain = this.ctx.createGain();
            this.musicGain.gain.setValueAtTime(0.22, this.ctx.currentTime);
            this.musicGain.connect(this.masterGain);
        }

        if (this.ctx.state === 'suspended') {
            this.ctx.resume().catch(() => {});
        }
        return this.ctx;
    }

    _bindUnlock() {
        const unlock = () => {
            if (!this.isUnlocked) {
                this._ensureContext();
                this.isUnlocked = true;
                if (this.musicEnabled && !this.bgmPlaying) {
                    this.startBgm();
                }
            }
            window.removeEventListener('pointerdown', unlock);
            window.removeEventListener('keydown', unlock);
        };
        window.addEventListener('pointerdown', unlock, { once: true });
        window.addEventListener('keydown', unlock, { once: true });
    }

    setSfxEnabled(enabled) {
        this.sfxEnabled = enabled;
        if (window.Storage) window.Storage.updateSettings({ sfx: enabled });
    }

    setMusicEnabled(enabled) {
        this.musicEnabled = enabled;
        if (window.Storage) window.Storage.updateSettings({ music: enabled });
        if (enabled) {
            this.startBgm();
        } else {
            this.stopBgm();
        }
    }

    /* === SOUND EFFECTS === */

    // Button Click / Tap: Crisp, playful pop
    playClick() {
        if (!this.sfxEnabled) return;
        const ctx = this._ensureContext();
        if (!ctx) return;

        const now = ctx.currentTime;
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(480, now);
        osc.frequency.exponentialRampToValueAtTime(750, now + 0.05);

        gain.gain.setValueAtTime(0.3, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);

        osc.connect(gain);
        gain.connect(this.sfxGain);

        osc.start(now);
        osc.stop(now + 0.08);
    }

    // Arrow Rotate: Tactile mechanical snap + sweep
    playRotate() {
        if (!this.sfxEnabled) return;
        const ctx = this._ensureContext();
        if (!ctx) return;

        const now = ctx.currentTime;
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(320, now);
        osc.frequency.exponentialRampToValueAtTime(560, now + 0.09);

        gain.gain.setValueAtTime(0.35, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);

        osc.connect(gain);
        gain.connect(this.sfxGain);

        osc.start(now);
        osc.stop(now + 0.12);
    }

    // Path Connecting / Advancing: Pleasant harmonic ping
    playPathConnect(step = 1) {
        if (!this.sfxEnabled) return;
        const ctx = this._ensureContext();
        if (!ctx) return;

        const now = ctx.currentTime;
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        // Pentatonic progression based on path length
        const baseFreq = 440;
        const scale = [1, 1.125, 1.25, 1.5, 1.667, 2.0];
        const multiplier = scale[Math.min(step, scale.length - 1)];

        osc.type = 'sine';
        osc.frequency.setValueAtTime(baseFreq * multiplier, now);

        gain.gain.setValueAtTime(0.25, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);

        osc.connect(gain);
        gain.connect(this.sfxGain);

        osc.start(now);
        osc.stop(now + 0.15);
    }

    // Coin Earned: Double bright metallic chime
    playCoin() {
        if (!this.sfxEnabled) return;
        const ctx = this._ensureContext();
        if (!ctx) return;

        const now = ctx.currentTime;
        const playPing = (freq, time, dur) => {
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.type = 'sine';
            osc.frequency.setValueAtTime(freq, time);
            gain.gain.setValueAtTime(0.28, time);
            gain.gain.exponentialRampToValueAtTime(0.001, time + dur);
            osc.connect(gain);
            gain.connect(this.sfxGain);
            osc.start(time);
            osc.stop(time + dur);
        };

        playPing(987.77, now, 0.18);        // B5
        playPing(1318.51, now + 0.08, 0.28); // E6
    }

    // Star Pop (1, 2, or 3): Cheerful chord arpeggio
    playStar(index = 1) {
        if (!this.sfxEnabled) return;
        const ctx = this._ensureContext();
        if (!ctx) return;

        const now = ctx.currentTime;
        const starPitches = [523.25, 659.25, 783.99]; // C5, E5, G5
        const freq = starPitches[Math.min(index - 1, 2)] || 659.25;

        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, now);
        osc.frequency.exponentialRampToValueAtTime(freq * 1.5, now + 0.25);

        gain.gain.setValueAtTime(0.35, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

        osc.connect(gain);
        gain.connect(this.sfxGain);

        osc.start(now);
        osc.stop(now + 0.35);
    }

    // Level Complete: Celebratory fanfare chord sequence
    playLevelComplete() {
        if (!this.sfxEnabled) return;
        const ctx = this._ensureContext();
        if (!ctx) return;

        const now = ctx.currentTime;
        const notes = [
            { f: 523.25, d: 0.15, delay: 0 },    // C5
            { f: 659.25, d: 0.15, delay: 0.12 }, // E5
            { f: 783.99, d: 0.15, delay: 0.24 }, // G5
            { f: 1046.50, d: 0.45, delay: 0.36 } // C6
        ];

        notes.forEach(n => {
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.type = 'triangle';
            osc.frequency.setValueAtTime(n.f, now + n.delay);

            gain.gain.setValueAtTime(0.3, now + n.delay);
            gain.gain.exponentialRampToValueAtTime(0.001, now + n.delay + n.d);

            osc.connect(gain);
            gain.connect(this.sfxGain);

            osc.start(now + n.delay);
            osc.stop(now + n.delay + n.d);
        });
    }

    // Unlock / Reward Chest Fanfare
    playUnlock() {
        if (!this.sfxEnabled) return;
        const ctx = this._ensureContext();
        if (!ctx) return;

        const now = ctx.currentTime;
        const freqs = [440, 554.37, 659.25, 880, 1108.73];
        freqs.forEach((f, idx) => {
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            const start = now + (idx * 0.08);

            osc.type = 'sine';
            osc.frequency.setValueAtTime(f, start);

            gain.gain.setValueAtTime(0.25, start);
            gain.gain.exponentialRampToValueAtTime(0.001, start + 0.4);

            osc.connect(gain);
            gain.connect(this.sfxGain);

            osc.start(start);
            osc.stop(start + 0.4);
        });
    }

    // Game Over: Descending somber notes
    playGameOver() {
        if (!this.sfxEnabled) return;
        const ctx = this._ensureContext();
        if (!ctx) return;

        const now = ctx.currentTime;
        const notes = [
            { f: 392.00, delay: 0 },    // G4
            { f: 349.23, delay: 0.22 }, // F4
            { f: 311.13, delay: 0.44 }, // Eb4
            { f: 261.63, delay: 0.70 }  // C4
        ];

        notes.forEach(n => {
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.type = 'sawtooth';
            osc.frequency.setValueAtTime(n.f, now + n.delay);

            gain.gain.setValueAtTime(0.25, now + n.delay);
            gain.gain.exponentialRampToValueAtTime(0.001, now + n.delay + 0.35);

            osc.connect(gain);
            gain.connect(this.sfxGain);

            osc.start(now + n.delay);
            osc.stop(now + n.delay + 0.35);
        });
    }

    // Invalid Move / Error: Low thud/buzz
    playError() {
        if (!this.sfxEnabled) return;
        const ctx = this._ensureContext();
        if (!ctx) return;

        const now = ctx.currentTime;
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'square';
        osc.frequency.setValueAtTime(140, now);
        osc.frequency.exponentialRampToValueAtTime(90, now + 0.12);

        gain.gain.setValueAtTime(0.2, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);

        osc.connect(gain);
        gain.connect(this.sfxGain);

        osc.start(now);
        osc.stop(now + 0.12);
    }

    // Hint activated: Shimmering sparkle
    playHint() {
        if (!this.sfxEnabled) return;
        const ctx = this._ensureContext();
        if (!ctx) return;

        const now = ctx.currentTime;
        for (let i = 0; i < 4; i++) {
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            const start = now + (i * 0.06);

            osc.type = 'sine';
            osc.frequency.setValueAtTime(800 + (i * 240), start);

            gain.gain.setValueAtTime(0.2, start);
            gain.gain.exponentialRampToValueAtTime(0.001, start + 0.2);

            osc.connect(gain);
            gain.connect(this.sfxGain);

            osc.start(start);
            osc.stop(start + 0.2);
        }
    }

    /* === BACKGROUND MUSIC (PROCEDURAL AMBIENT LOOP) === */
    startBgm() {
        if (!this.musicEnabled || this.bgmPlaying) return;
        const ctx = this._ensureContext();
        if (!ctx) return;

        this.bgmPlaying = true;
        this.bgmStep = 0;

        // Friendly upbeat pentatonic progression (Key of C / G)
        // BPM = 100 -> step = 300ms per 8th note
        const melody = [
            261.63, 329.63, 392.00, 523.25,
            392.00, 329.63, 261.63, 392.00,
            293.66, 369.99, 440.00, 587.33,
            440.00, 369.99, 293.66, 440.00
        ];
        const bass = [
            130.81, 0, 130.81, 0,
            130.81, 0, 164.81, 0,
            146.83, 0, 146.83, 0,
            196.00, 0, 196.00, 0
        ];

        const stepTime = 280; // ms

        const tick = () => {
            if (!this.bgmPlaying) return;
            const now = this.ctx.currentTime;
            const mFreq = melody[this.bgmStep % melody.length];
            const bFreq = bass[this.bgmStep % bass.length];

            if (mFreq) {
                const mOsc = this.ctx.createOscillator();
                const mGain = this.ctx.createGain();
                mOsc.type = 'sine';
                mOsc.frequency.setValueAtTime(mFreq, now);

                mGain.gain.setValueAtTime(0.09, now);
                mGain.gain.exponentialRampToValueAtTime(0.001, now + 0.24);

                mOsc.connect(mGain);
                mGain.connect(this.musicGain);

                mOsc.start(now);
                mOsc.stop(now + 0.24);
            }

            if (bFreq) {
                const bOsc = this.ctx.createOscillator();
                const bGain = this.ctx.createGain();
                bOsc.type = 'triangle';
                bOsc.frequency.setValueAtTime(bFreq, now);

                bGain.gain.setValueAtTime(0.12, now);
                bGain.gain.exponentialRampToValueAtTime(0.001, now + 0.26);

                bOsc.connect(bGain);
                bGain.connect(this.musicGain);

                bOsc.start(now);
                bOsc.stop(now + 0.26);
            }

            this.bgmStep = (this.bgmStep + 1) % 64;
            this.bgmTimer = setTimeout(tick, stepTime);
        };

        tick();
    }

    stopBgm() {
        this.bgmPlaying = false;
        if (this.bgmTimer) {
            clearTimeout(this.bgmTimer);
            this.bgmTimer = null;
        }
    }
}

// Export singleton instance
window.Audio = new AudioManager();
