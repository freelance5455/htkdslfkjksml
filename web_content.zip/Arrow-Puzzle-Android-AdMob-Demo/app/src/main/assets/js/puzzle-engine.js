/**
 * puzzle-engine.js - Core Arrow Puzzle Simulation & Validation Engine
 * Handles grid representation, arrow rotation, real-time beam tracing from START to TARGET,
 * loop detection, undo history, hints, and star ratings.
 */

const DIRECTIONS = ['UP', 'RIGHT', 'DOWN', 'LEFT'];

const DIR_DELTAS = {
    UP:    { dr: -1, dc: 0,  angle: 0 },
    RIGHT: { dr: 0,  dc: 1,  angle: 90 },
    DOWN:  { dr: 1,  dc: 0,  angle: 180 },
    LEFT:  { dr: 0,  dc: -1, angle: 270 }
};

const OPPOSITE_DIR = {
    UP: 'DOWN',
    RIGHT: 'LEFT',
    DOWN: 'UP',
    LEFT: 'RIGHT'
};

class PuzzleEngine {
    constructor() {
        this.levelData = null;
        this.grid = []; // 2D array of cells
        this.moves = 0;
        this.undoStack = [];
        this.isSolved = false;
        this.connectedPath = []; // Array of {row, col, dir}
    }

    loadLevel(levelData) {
        this.levelData = JSON.parse(JSON.stringify(levelData));
        this.moves = 0;
        this.undoStack = [];
        this.isSolved = false;
        this.connectedPath = [];

        const { rows, cols, start, target, arrows } = this.levelData;

        // Initialize empty grid
        this.grid = Array.from({ length: rows }, (_, r) =>
            Array.from({ length: cols }, (_, c) => ({
                row: r,
                col: c,
                type: 'empty', // 'start', 'target', 'arrow', 'empty', 'wall'
                dir: null,
                correctDir: null,
                isLocked: false,
                color: null,
                inPath: false,
                pathIndex: -1,
                hintActive: false
            }))
        );

        // Place Start
        if (start) {
            this.grid[start.row][start.col].type = 'start';
            this.grid[start.row][start.col].dir = start.dir || 'RIGHT';
        }

        // Place Target
        if (target) {
            this.grid[target.row][target.col].type = 'target';
        }

        // Place Arrows
        if (Array.isArray(arrows)) {
            arrows.forEach(arr => {
                if (arr.row >= 0 && arr.row < rows && arr.col >= 0 && arr.col < cols) {
                    const cell = this.grid[arr.row][arr.col];
                    cell.type = 'arrow';
                    cell.dir = arr.direction || arr.currentDir || 'RIGHT';
                    cell.correctDir = arr.correctDir || arr.direction || 'RIGHT';
                    cell.isLocked = !!arr.isLocked;
                    cell.color = arr.color || null;
                }
            });
        }

        // Initial path evaluation
        this.evaluatePath();
        return this.getState();
    }

    rotateArrow(row, col, recordUndo = true) {
        if (this.isSolved) return null;
        if (row < 0 || row >= this.levelData.rows || col < 0 || col >= this.levelData.cols) return null;

        const cell = this.grid[row][col];
        if (cell.type !== 'arrow' || cell.isLocked) return null;

        const prevDir = cell.dir;
        const curIdx = DIRECTIONS.indexOf(cell.dir);
        const nextIdx = (curIdx + 1) % DIRECTIONS.length;
        cell.dir = DIRECTIONS[nextIdx];
        cell.hintActive = false; // Clear hint if rotated

        this.moves += 1;

        if (recordUndo) {
            this.undoStack.push({
                row,
                col,
                prevDir,
                newDir: cell.dir
            });
        }

        this.evaluatePath();
        return {
            row,
            col,
            prevDir,
            newDir: cell.dir,
            angle: DIR_DELTAS[cell.dir].angle,
            moves: this.moves,
            isSolved: this.isSolved,
            connectedPath: this.connectedPath
        };
    }

    undo() {
        if (this.isSolved || this.undoStack.length === 0) return null;

        const lastAction = this.undoStack.pop();
        const cell = this.grid[lastAction.row][lastAction.col];
        cell.dir = lastAction.prevDir;
        cell.hintActive = false;
        this.moves = Math.max(0, this.moves - 1);

        this.evaluatePath();
        return {
            row: lastAction.row,
            col: lastAction.col,
            dir: cell.dir,
            angle: DIR_DELTAS[cell.dir].angle,
            moves: this.moves,
            isSolved: this.isSolved,
            connectedPath: this.connectedPath
        };
    }

    reset() {
        if (!this.levelData) return null;
        return this.loadLevel(this.levelData);
    }

    evaluatePath() {
        // Reset path flags on all cells
        for (let r = 0; r < this.levelData.rows; r++) {
            for (let c = 0; c < this.levelData.cols; c++) {
                this.grid[r][c].inPath = false;
                this.grid[r][c].pathIndex = -1;
            }
        }

        this.connectedPath = [];
        const start = this.levelData.start;
        const target = this.levelData.target;

        if (!start || !target) {
            this.isSolved = false;
            return;
        }

        const startCell = this.grid[start.row][start.col];
        startCell.inPath = true;
        startCell.pathIndex = 0;
        this.connectedPath.push({ row: start.row, col: start.col, dir: startCell.dir });

        let curR = start.row;
        let curC = start.col;
        let curDir = startCell.dir;
        let stepCount = 1;

        const visitedKeys = new Set();
        visitedKeys.add(`${curR},${curC}`);

        let reachedTarget = false;

        while (true) {
            const delta = DIR_DELTAS[curDir];
            if (!delta) break;

            const nextR = curR + delta.dr;
            const nextC = curC + delta.dc;

            // Check bounds
            if (nextR < 0 || nextR >= this.levelData.rows || nextC < 0 || nextC >= this.levelData.cols) {
                break; // Beam went off grid
            }

            // Check Target
            if (nextR === target.row && nextC === target.col) {
                const targetCell = this.grid[nextR][nextC];
                targetCell.inPath = true;
                targetCell.pathIndex = stepCount;
                this.connectedPath.push({ row: nextR, col: nextC, dir: null });
                reachedTarget = true;
                break;
            }

            const nextCell = this.grid[nextR][nextC];

            // If empty or wall, stops
            if (nextCell.type !== 'arrow') {
                break;
            }

            // Head-on collision check: arrow pointing directly backwards at incoming beam
            if (nextCell.dir === OPPOSITE_DIR[curDir]) {
                break;
            }

            // Loop detection: if already in visited path, stop to prevent cycle
            const key = `${nextR},${nextC}`;
            if (visitedKeys.has(key)) {
                break;
            }
            visitedKeys.add(key);

            // Beam successfully flows through this arrow
            nextCell.inPath = true;
            nextCell.pathIndex = stepCount++;
            this.connectedPath.push({ row: nextR, col: nextC, dir: nextCell.dir });

            curR = nextR;
            curC = nextC;
            curDir = nextCell.dir;
        }

        this.isSolved = reachedTarget;
    }

    getHint() {
        if (this.isSolved) return null;

        // Find the first arrow on the solution path that is misoriented
        const arrows = this.levelData.arrows || [];
        for (const arr of arrows) {
            const cell = this.grid[arr.row][arr.col];
            if (cell.type === 'arrow' && arr.correctDir && cell.dir !== arr.correctDir) {
                cell.hintActive = true;
                return {
                    row: arr.row,
                    col: arr.col,
                    suggestedDir: arr.correctDir,
                    currentDir: cell.dir
                };
            }
        }
        return null;
    }

    calculateStars() {
        const par = this.levelData.parMoves || 4;
        if (this.moves <= par) {
            return 3;
        } else if (this.moves <= par + 4) {
            return 2;
        }
        return 1;
    }

    getState() {
        return {
            levelId: this.levelData ? this.levelData.id : null,
            name: this.levelData ? this.levelData.name : '',
            world: this.levelData ? this.levelData.world : 1,
            rows: this.levelData ? this.levelData.rows : 0,
            cols: this.levelData ? this.levelData.cols : 0,
            moves: this.moves,
            isSolved: this.isSolved,
            connectedPath: this.connectedPath,
            grid: this.grid,
            canUndo: this.undoStack.length > 0,
            parMoves: this.levelData ? this.levelData.parMoves : 4
        };
    }
}

// Export singleton instance
window.PuzzleEngine = new PuzzleEngine();
