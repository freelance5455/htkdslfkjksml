/**
 * storage.js - LocalStorage Management for Arrow Puzzle
 * Handles persistence of player progression, currency, lives with timer regeneration,
 * level stars, best scores, and user settings.
 */

const STORAGE_KEY = 'arrowPuzzle_save_v2';
const LIFE_REGEN_INTERVAL_MS = 10 * 60 * 1000; // 10 minutes per life
const MAX_LIVES = 5;

const DEFAULT_STATE = {
    version: 1,
    currentLevel: 1,
    unlockedLevels: [1],
    stars: {},        // { levelId: starsCount (1-3) }
    bestMoves: {},    // { levelId: moves }
    coins: 250,       // Matches reference mock-up starting balance
    lives: 5,
    lastLifeTimestamp: Date.now(),
    lastDailyReward: null,
    settings: {
        music: true,
        sfx: true,
        vibration: true,
        darkMode: false,
        language: 'en'
    },
    stats: {
        puzzlesSolved: 0,
        totalStars: 0,
        hintsUsed: 0
    }
};

class StorageManager {
    constructor() {
        this.memoryStore = null;
        this.isLocalStorageAvailable = this._checkStorage();
        this.data = this.load();
        this.updateLifeRegeneration();
    }

    _checkStorage() {
        try {
            const testKey = '__arrow_test__';
            window.localStorage.setItem(testKey, testKey);
            window.localStorage.removeItem(testKey);
            return true;
        } catch (e) {
            console.warn('localStorage is not available. Using in-memory storage fallback.', e);
            return false;
        }
    }

    load() {
        if (!this.isLocalStorageAvailable) {
            if (!this.memoryStore) {
                this.memoryStore = JSON.parse(JSON.stringify(DEFAULT_STATE));
            }
            return this.memoryStore;
        }

        try {
            const raw = window.localStorage.getItem(STORAGE_KEY);
            if (!raw) {
                const fresh = JSON.parse(JSON.stringify(DEFAULT_STATE));
                this.save(fresh);
                return fresh;
            }
            const parsed = JSON.parse(raw);
            // Merge with defaults in case of missing keys
            return this._mergeDefaults(parsed, DEFAULT_STATE);
        } catch (e) {
            console.error('Corrupted save data found, recovering with defaults:', e);
            const fresh = JSON.parse(JSON.stringify(DEFAULT_STATE));
            this.save(fresh);
            return fresh;
        }
    }

    save(dataToSave = this.data) {
        this.data = dataToSave;
        if (!this.isLocalStorageAvailable) {
            this.memoryStore = JSON.parse(JSON.stringify(dataToSave));
            return;
        }
        try {
            window.localStorage.setItem(STORAGE_KEY, JSON.stringify(dataToSave));
        } catch (e) {
            console.error('Failed to write to localStorage:', e);
        }
    }

    _mergeDefaults(target, defaults) {
        const result = { ...defaults, ...target };
        result.settings = { ...defaults.settings, ...(target.settings || {}) };
        result.stats = { ...defaults.stats, ...(target.stats || {}) };
        result.stars = target.stars || {};
        result.bestMoves = target.bestMoves || {};
        if (!Array.isArray(result.unlockedLevels) || result.unlockedLevels.length === 0) {
            result.unlockedLevels = [1];
        }
        return result;
    }

    /* === Progression & Levels === */
    isLevelUnlocked(levelId) {
        return this.data.unlockedLevels.includes(Number(levelId));
    }

    unlockLevel(levelId) {
        const id = Number(levelId);
        if (!this.data.unlockedLevels.includes(id)) {
            this.data.unlockedLevels.push(id);
            this.data.unlockedLevels.sort((a, b) => a - b);
            this.save();
            return true;
        }
        return false;
    }

    getLevelStars(levelId) {
        return this.data.stars[levelId] || 0;
    }

    getBestMoves(levelId) {
        return this.data.bestMoves[levelId] || null;
    }

    recordLevelCompletion(levelId, stars, moves, coinsEarned) {
        const id = Number(levelId);
        const oldStars = this.data.stars[id] || 0;
        if (stars > oldStars) {
            this.data.stars[id] = stars;
        }

        const oldBest = this.data.bestMoves[id];
        if (oldBest === undefined || moves < oldBest) {
            this.data.bestMoves[id] = moves;
        }

        this.data.coins += coinsEarned;
        this.data.stats.puzzlesSolved += 1;
        this.data.stats.totalStars = Object.values(this.data.stars).reduce((a, b) => a + b, 0);

        // Unlock next level if exists
        const nextId = id + 1;
        const newlyUnlocked = nextId <= 100 ? this.unlockLevel(nextId) : false;
        const unlockBonus = newlyUnlocked ? 50 : 0;
        if (unlockBonus) this.data.coins += unlockBonus;

        this.save();
        return { newlyUnlocked, nextId, unlockBonus };
    }

    /* === Currency & Lives === */
    getCoins() {
        return this.data.coins;
    }

    addCoins(amount) {
        this.data.coins = Math.max(0, this.data.coins + amount);
        this.save();
        return this.data.coins;
    }

    spendCoins(amount) {
        if (this.data.coins >= amount) {
            this.data.coins -= amount;
            this.save();
            return true;
        }
        return false;
    }

    getLives() {
        this.updateLifeRegeneration();
        return this.data.lives;
    }

    loseLife() {
        this.updateLifeRegeneration();
        if (this.data.lives > 0) {
            this.data.lives -= 1;
            if (this.data.lives < MAX_LIVES && !this.data.lastLifeTimestamp) {
                this.data.lastLifeTimestamp = Date.now();
            }
            this.save();
            return true;
        }
        return false;
    }

    refillLives() {
        this.data.lives = MAX_LIVES;
        this.data.lastLifeTimestamp = Date.now();
        this.save();
        return this.data.lives;
    }

    updateLifeRegeneration() {
        if (this.data.lives >= MAX_LIVES) {
            this.data.lastLifeTimestamp = Date.now();
            return;
        }

        const now = Date.now();
        const elapsed = now - (this.data.lastLifeTimestamp || now);
        const livesToAdd = Math.floor(elapsed / LIFE_REGEN_INTERVAL_MS);

        if (livesToAdd > 0) {
            this.data.lives = Math.min(MAX_LIVES, this.data.lives + livesToAdd);
            this.data.lastLifeTimestamp = now - (elapsed % LIFE_REGEN_INTERVAL_MS);
            this.save();
        }
    }

    getTimeUntilNextLife() {
        if (this.data.lives >= MAX_LIVES) return 0;
        const now = Date.now();
        const elapsed = now - (this.data.lastLifeTimestamp || now);
        const remaining = Math.max(0, LIFE_REGEN_INTERVAL_MS - (elapsed % LIFE_REGEN_INTERVAL_MS));
        return remaining;
    }

    /* === Daily Reward === */
    claimDailyReward() {
        const today = new Date().toISOString().slice(0, 10);
        if (this.data.lastDailyReward === today) return { claimed: false, amount: 0 };
        const amount = 50;
        this.data.lastDailyReward = today;
        this.data.coins += amount;
        this.save();
        return { claimed: true, amount };
    }

    /* === Settings === */
    getSettings() {
        return { ...this.data.settings };
    }

    updateSettings(newSettings) {
        this.data.settings = { ...this.data.settings, ...newSettings };
        this.save();
        return this.data.settings;
    }

    /* === Reset Progress === */
    resetProgress() {
        const currentSettings = { ...this.data.settings };
        this.data = JSON.parse(JSON.stringify(DEFAULT_STATE));
        this.data.settings = currentSettings; // Keep user preference
        this.save();
        return this.data;
    }
}

// Export singleton instance
window.Storage = new StorageManager();
