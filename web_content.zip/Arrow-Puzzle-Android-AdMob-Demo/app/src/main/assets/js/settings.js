/**
 * settings.js - Settings Management & Multi-Language Localization
 * Manages audio toggles, vibration, dark theme, language selection,
 * and safe progress resetting.
 */

const TRANSLATIONS = {
    en: {
        gameTitle: "ARROW PUZZLE",
        tagline: "Think • Rotate • Solve",
        play: "PLAY",
        levels: "LEVELS",
        settings: "SETTINGS",
        moreGames: "More Games",
        share: "Share",
        rateUs: "Rate Us",
        selectLevel: "SELECT LEVEL",
        instruction: "Rotate the arrows to connect the path",
        undo: "Undo",
        reset: "Reset",
        hint: "Hint",
        paused: "PAUSED",
        resume: "Resume",
        restartLevel: "Restart Level",
        home: "Home",
        levelComplete: "LEVEL COMPLETE!",
        moves: "Moves",
        coinsEarned: "Coins Earned",
        best: "Best",
        nextLevel: "Next Level",
        replay: "Replay",
        gameOver: "GAME OVER",
        outOfLives: "Out of Lives!",
        dontWorry: "Don't worry, you can try again!",
        retry: "Retry",
        levelUnlocked: "LEVEL UNLOCKED",
        newChallenge: "New challenge awaits!",
        playNow: "Play Now",
        music: "Music",
        soundEffects: "Sound Effects",
        vibration: "Vibration",
        darkMode: "Dark Mode",
        language: "Language",
        resetProgress: "Reset Progress",
        resetConfirmTitle: "Reset All Progress?",
        resetConfirmText: "This will delete all completed levels, stars, and coins. This action cannot be undone!",
        cancel: "Cancel",
        back: "Back",
        confirm: "Yes, Reset",
        refillLives: "Refill Lives (+5)",
        costCoins: "Coins",
        copied: "Copied to clipboard!",
        shared: "Thanks for sharing Arrow Puzzle!"
    },
    es: {
        gameTitle: "ARROW PUZZLE",
        tagline: "Piensa • Gira • Resuelve",
        play: "JUGAR",
        levels: "NIVELES",
        settings: "AJUSTES",
        moreGames: "Más Juegos",
        share: "Compartir",
        rateUs: "Calificar",
        selectLevel: "SELECCIONAR NIVEL",
        instruction: "Gira las flechas para conectar el camino",
        undo: "Deshacer",
        reset: "Reiniciar",
        hint: "Pista",
        paused: "PAUSA",
        resume: "Continuar",
        restartLevel: "Reiniciar Nivel",
        home: "Inicio",
        levelComplete: "¡NIVEL COMPLETADO!",
        moves: "Movimientos",
        coinsEarned: "Monedas Ganadas",
        best: "Récord",
        nextLevel: "Siguiente Nivel",
        replay: "Reintentar",
        gameOver: "FIN DEL JUEGO",
        outOfLives: "¡Sin Vidas!",
        dontWorry: "¡No te preocupes, inténtalo de nuevo!",
        retry: "Reintentar",
        levelUnlocked: "NIVEL DESBLOQUEADO",
        newChallenge: "¡Nuevo desafío te espera!",
        playNow: "Jugar Ahora",
        music: "Música",
        soundEffects: "Efectos de Sonido",
        vibration: "Vibración",
        darkMode: "Modo Oscuro",
        language: "Idioma",
        resetProgress: "Borrar Progreso",
        resetConfirmTitle: "¿Borrar Todo el Progreso?",
        resetConfirmText: "Se perderán todas las estrellas y monedas.",
        cancel: "Cancelar",
        back: "Atrás",
        confirm: "Sí, Borrar",
        refillLives: "Recargar Vidas (+5)",
        costCoins: "Monedas",
        copied: "¡Copiado al portapapeles!",
        shared: "¡Gracias por compartir!"
    },
    fr: {
        gameTitle: "ARROW PUZZLE",
        tagline: "Penser • Tourner • Résoudre",
        play: "JOUER",
        levels: "NIVEAUX",
        settings: "PARAMÈTRES",
        moreGames: "Plus de Jeux",
        share: "Partager",
        rateUs: "Noter",
        selectLevel: "CHOISIR UN NIVEAU",
        instruction: "Faites pivoter les flèches pour relier le chemin",
        undo: "Annuler",
        reset: "Recommencer",
        hint: "Indice",
        paused: "PAUSE",
        resume: "Reprendre",
        restartLevel: "Recommencer Niveau",
        home: "Accueil",
        levelComplete: "NIVEAU TERMINÉ !",
        moves: "Coups",
        coinsEarned: "Pièces Gagnées",
        best: "Meilleur",
        nextLevel: "Niveau Suivant",
        replay: "Rejouer",
        gameOver: "PARTIE TERMINÉE",
        outOfLives: "Plus de Vies !",
        dontWorry: "Pas d'inquiétude, réessayez !",
        retry: "Réessayer",
        levelUnlocked: "NIVEAU DÉBLOQUÉ",
        newChallenge: "Un nouveau défi vous attend !",
        playNow: "Jouer",
        music: "Musique",
        soundEffects: "Effets Sonores",
        vibration: "Vibration",
        darkMode: "Mode Sombre",
        language: "Langue",
        resetProgress: "Réinitialiser",
        resetConfirmTitle: "Tout réinitialiser ?",
        resetConfirmText: "Toutes vos étoiles et pièces seront effacées.",
        cancel: "Annuler",
        back: "Retour",
        confirm: "Oui, Réinitialiser",
        refillLives: "Recharger Vies (+5)",
        costCoins: "Pièces",
        copied: "Copié dans le presse-papiers !",
        shared: "Merci pour le partage !"
    },
    de: {
        gameTitle: "ARROW PUZZLE",
        tagline: "Denken • Drehen • Lösen",
        play: "SPIELEN",
        levels: "LEVELS",
        settings: "EINSTELLUNGEN",
        moreGames: "Mehr Spiele",
        share: "Teilen",
        rateUs: "Bewerten",
        selectLevel: "LEVEL WÄHLEN",
        instruction: "Drehe die Pfeile, um den Pfad zu verbinden",
        undo: "Zurück",
        reset: "Neu starten",
        hint: "Tipp",
        paused: "PAUSE",
        resume: "Fortsetzen",
        restartLevel: "Level Neustart",
        home: "Start",
        levelComplete: "LEVEL GESCHAFFT!",
        moves: "Züge",
        coinsEarned: "Münzen",
        best: "Bestwert",
        nextLevel: "Nächstes Level",
        replay: "Wiederholen",
        gameOver: "SPIEL VORBEI",
        outOfLives: "Keine Leben mehr!",
        dontWorry: "Keine Sorge, versuche es nochmal!",
        retry: "Wiederholen",
        levelUnlocked: "LEVEL FREIGESCHALTET",
        newChallenge: "Neue Herausforderung wartet!",
        playNow: "Jetzt Spielen",
        music: "Musik",
        soundEffects: "Soundeffekte",
        vibration: "Vibration",
        darkMode: "Dunkler Modus",
        language: "Sprache",
        resetProgress: "Fortschritt löschen",
        resetConfirmTitle: "Alles zurücksetzen?",
        resetConfirmText: "Alle Sterne und Münzen werden gelöscht.",
        cancel: "Abbrechen",
        back: "Zurück",
        confirm: "Ja, Löschen",
        refillLives: "Leben auffüllen (+5)",
        costCoins: "Münzen",
        copied: "In Zwischenablage kopiert!",
        shared: "Danke fürs Teilen!"
    },
    ja: {
        gameTitle: "アローパズル",
        tagline: "考えて • 回して • つなぐ",
        play: "プレイ",
        levels: "レベル",
        settings: "設定",
        moreGames: "他のゲーム",
        share: "共有",
        rateUs: "評価する",
        selectLevel: "レベル選択",
        instruction: "矢印をタップして道をつなごう",
        undo: "戻す",
        reset: "リセット",
        hint: "ヒント",
        paused: "一時停止",
        resume: "再開",
        restartLevel: "やり直す",
        home: "ホーム",
        levelComplete: "クリア！",
        moves: "手数",
        coinsEarned: "獲得コイン",
        best: "ベスト",
        nextLevel: "次のレベル",
        replay: "もう一度",
        gameOver: "ゲームオーバー",
        outOfLives: "ライフがなくなりました！",
        dontWorry: "大丈夫、もう一度挑戦！",
        retry: "リトライ",
        levelUnlocked: "レベル解放",
        newChallenge: "新しい挑戦が待っている！",
        playNow: "今すぐプレイ",
        music: "BGM",
        soundEffects: "効果音",
        vibration: "振動",
        darkMode: "ダークモード",
        language: "言語",
        resetProgress: "データをリセット",
        resetConfirmTitle: "本当にリセットしますか？",
        resetConfirmText: "すべての星とコインが消去されます。",
        cancel: "キャンセル",
        back: "戻る",
        confirm: "リセットする",
        refillLives: "ライフ全回復 (+5)",
        costCoins: "コイン",
        copied: "コピーしました！",
        shared: "シェアありがとう！"
    }
};

class SettingsManager {
    constructor() {
        this.currentLang = 'en';
        this.vibrationEnabled = true;
        this.darkModeEnabled = false;
        this.init();
    }

    init() {
        if (!window.Storage) return;
        const s = window.Storage.getSettings();
        this.currentLang = s.language || 'en';
        this.vibrationEnabled = s.vibration !== false;
        this.darkModeEnabled = !!s.darkMode;

        this.applyTheme(this.darkModeEnabled);
        this.applyLanguage(this.currentLang);
    }

    setLanguage(lang) {
        if (TRANSLATIONS[lang]) {
            this.currentLang = lang;
            if (window.Storage) window.Storage.updateSettings({ language: lang });
            this.applyLanguage(lang);
        }
    }

    applyLanguage(lang) {
        const t = TRANSLATIONS[lang] || TRANSLATIONS.en;
        document.querySelectorAll('[data-i18n]').forEach(el => {
            const key = el.getAttribute('data-i18n');
            if (t[key]) {
                el.textContent = t[key];
            }
        });
    }

    t(key) {
        const langData = TRANSLATIONS[this.currentLang] || TRANSLATIONS.en;
        return langData[key] || TRANSLATIONS.en[key] || key;
    }

    setDarkMode(enabled) {
        this.darkModeEnabled = enabled;
        if (window.Storage) window.Storage.updateSettings({ darkMode: enabled });
        this.applyTheme(enabled);
    }

    applyTheme(isDark) {
        const themeIcon = document.getElementById('settings-theme-icon');
        if (isDark) {
            document.documentElement.classList.add('dark-theme');
            if (themeIcon) themeIcon.src = 'assets/icons/sun.svg';
        } else {
            document.documentElement.classList.remove('dark-theme');
            if (themeIcon) themeIcon.src = 'assets/icons/moon.svg';
        }
    }

    setVibration(enabled) {
        this.vibrationEnabled = enabled;
        if (window.Storage) window.Storage.updateSettings({ vibration: enabled });
    }

    vibrate(pattern = 30) {
        if (!this.vibrationEnabled) return;
        try {
            if ('vibrate' in navigator) {
                navigator.vibrate(pattern);
            }
        } catch (e) {
            // Ignore vibration errors silently
        }
    }
}

// Export singleton instance
window.Settings = new SettingsManager();
