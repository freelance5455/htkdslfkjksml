/**
 * levels.js - 100 Playable, Verified Solvable Levels for Arrow Puzzle
 * Structured into 5 Progressive Difficulty Worlds:
 * Levels 1-20: Easy (3x3 to 4x4)
 * Levels 21-40: Easy/Medium (4x4)
 * Levels 41-60: Medium (5x5)
 * Levels 61-80: Hard (5x5)
 * Levels 81-100: Expert (5x5)
 */

window.LEVELS_DATA = [
    {
        "id":  1,
        "cols":  4,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  1,
        "name":  "Level 1",
        "target":  {
                       "col":  3,
                       "row":  3
                   },
        "rows":  4,
        "parMoves":  7
    },
    {
        "id":  2,
        "cols":  4,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "DOWN",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  1,
        "name":  "Level 2",
        "target":  {
                       "col":  3,
                       "row":  3
                   },
        "rows":  4,
        "parMoves":  10
    },
    {
        "id":  3,
        "cols":  4,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "LEFT",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  1,
        "name":  "Level 3",
        "target":  {
                       "col":  3,
                       "row":  3
                   },
        "rows":  4,
        "parMoves":  11
    },
    {
        "id":  4,
        "cols":  4,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "DOWN",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  1,
        "name":  "Level 4",
        "target":  {
                       "col":  3,
                       "row":  3
                   },
        "rows":  4,
        "parMoves":  11
    },
    {
        "id":  5,
        "cols":  4,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  1,
        "name":  "Level 5",
        "target":  {
                       "col":  3,
                       "row":  3
                   },
        "rows":  4,
        "parMoves":  8
    },
    {
        "id":  6,
        "cols":  4,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "DOWN",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  1,
        "name":  "Level 6",
        "target":  {
                       "col":  3,
                       "row":  3
                   },
        "rows":  4,
        "parMoves":  13
    },
    {
        "id":  7,
        "cols":  4,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "LEFT",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  1,
        "name":  "Level 7",
        "target":  {
                       "col":  3,
                       "row":  3
                   },
        "rows":  4,
        "parMoves":  9
    },
    {
        "id":  8,
        "cols":  4,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "LEFT",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  1,
        "name":  "Level 8",
        "target":  {
                       "col":  3,
                       "row":  3
                   },
        "rows":  4,
        "parMoves":  7
    },
    {
        "id":  9,
        "cols":  4,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  1,
        "name":  "Level 9",
        "target":  {
                       "col":  3,
                       "row":  3
                   },
        "rows":  4,
        "parMoves":  8
    },
    {
        "id":  10,
        "cols":  4,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "DOWN",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  1,
        "name":  "Level 10",
        "target":  {
                       "col":  3,
                       "row":  3
                   },
        "rows":  4,
        "parMoves":  7
    },
    {
        "id":  11,
        "cols":  4,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "DOWN",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  1,
        "name":  "Level 11",
        "target":  {
                       "col":  3,
                       "row":  3
                   },
        "rows":  4,
        "parMoves":  10
    },
    {
        "id":  12,
        "cols":  4,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  1,
        "name":  "Level 12",
        "target":  {
                       "col":  3,
                       "row":  3
                   },
        "rows":  4,
        "parMoves":  9
    },
    {
        "id":  13,
        "cols":  4,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "DOWN",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  1,
        "name":  "Level 13",
        "target":  {
                       "col":  3,
                       "row":  3
                   },
        "rows":  4,
        "parMoves":  13
    },
    {
        "id":  14,
        "cols":  4,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "DOWN",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  1,
        "name":  "Level 14",
        "target":  {
                       "col":  3,
                       "row":  3
                   },
        "rows":  4,
        "parMoves":  11
    },
    {
        "id":  15,
        "cols":  4,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "DOWN",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  1,
        "name":  "Level 15",
        "target":  {
                       "col":  3,
                       "row":  3
                   },
        "rows":  4,
        "parMoves":  13
    },
    {
        "id":  16,
        "cols":  4,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  1,
        "name":  "Level 16",
        "target":  {
                       "col":  3,
                       "row":  3
                   },
        "rows":  4,
        "parMoves":  7
    },
    {
        "id":  17,
        "cols":  4,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "LEFT",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  1,
        "name":  "Level 17",
        "target":  {
                       "col":  3,
                       "row":  3
                   },
        "rows":  4,
        "parMoves":  10
    },
    {
        "id":  18,
        "cols":  4,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "LEFT",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  1,
        "name":  "Level 18",
        "target":  {
                       "col":  3,
                       "row":  3
                   },
        "rows":  4,
        "parMoves":  11
    },
    {
        "id":  19,
        "cols":  4,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "DOWN",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  1,
        "name":  "Level 19",
        "target":  {
                       "col":  3,
                       "row":  3
                   },
        "rows":  4,
        "parMoves":  10
    },
    {
        "id":  20,
        "cols":  4,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  1,
        "name":  "Level 20",
        "target":  {
                       "col":  3,
                       "row":  3
                   },
        "rows":  4,
        "parMoves":  10
    },
    {
        "id":  21,
        "cols":  4,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "DOWN",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  2,
        "name":  "Level 21",
        "target":  {
                       "col":  3,
                       "row":  3
                   },
        "rows":  4,
        "parMoves":  14
    },
    {
        "id":  22,
        "cols":  4,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  2,
        "name":  "Level 22",
        "target":  {
                       "col":  3,
                       "row":  3
                   },
        "rows":  4,
        "parMoves":  9
    },
    {
        "id":  23,
        "cols":  4,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "DOWN",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  2,
        "name":  "Level 23",
        "target":  {
                       "col":  3,
                       "row":  3
                   },
        "rows":  4,
        "parMoves":  11
    },
    {
        "id":  24,
        "cols":  4,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "DOWN",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  2,
        "name":  "Level 24",
        "target":  {
                       "col":  3,
                       "row":  3
                   },
        "rows":  4,
        "parMoves":  9
    },
    {
        "id":  25,
        "cols":  4,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "DOWN",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  2,
        "name":  "Level 25",
        "target":  {
                       "col":  3,
                       "row":  3
                   },
        "rows":  4,
        "parMoves":  10
    },
    {
        "id":  26,
        "cols":  4,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  2,
        "name":  "Level 26",
        "target":  {
                       "col":  3,
                       "row":  3
                   },
        "rows":  4,
        "parMoves":  7
    },
    {
        "id":  27,
        "cols":  4,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "DOWN",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "RIGHT",
                           "col":  0,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  2,
        "name":  "Level 27",
        "target":  {
                       "col":  3,
                       "row":  3
                   },
        "rows":  4,
        "parMoves":  11
    },
    {
        "id":  28,
        "cols":  4,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  2,
        "name":  "Level 28",
        "target":  {
                       "col":  3,
                       "row":  3
                   },
        "rows":  4,
        "parMoves":  9
    },
    {
        "id":  29,
        "cols":  4,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "LEFT",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  2,
        "name":  "Level 29",
        "target":  {
                       "col":  3,
                       "row":  3
                   },
        "rows":  4,
        "parMoves":  10
    },
    {
        "id":  30,
        "cols":  4,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "LEFT",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  2,
        "name":  "Level 30",
        "target":  {
                       "col":  3,
                       "row":  3
                   },
        "rows":  4,
        "parMoves":  10
    },
    {
        "id":  31,
        "cols":  4,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "LEFT",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  2,
        "name":  "Level 31",
        "target":  {
                       "col":  3,
                       "row":  3
                   },
        "rows":  4,
        "parMoves":  11
    },
    {
        "id":  32,
        "cols":  4,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "DOWN",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  2,
        "name":  "Level 32",
        "target":  {
                       "col":  3,
                       "row":  3
                   },
        "rows":  4,
        "parMoves":  12
    },
    {
        "id":  33,
        "cols":  4,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "LEFT",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  2,
        "name":  "Level 33",
        "target":  {
                       "col":  3,
                       "row":  3
                   },
        "rows":  4,
        "parMoves":  11
    },
    {
        "id":  34,
        "cols":  4,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  2,
        "name":  "Level 34",
        "target":  {
                       "col":  3,
                       "row":  3
                   },
        "rows":  4,
        "parMoves":  10
    },
    {
        "id":  35,
        "cols":  4,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "RIGHT",
                           "col":  0,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  2,
        "name":  "Level 35",
        "target":  {
                       "col":  3,
                       "row":  3
                   },
        "rows":  4,
        "parMoves":  8
    },
    {
        "id":  36,
        "cols":  4,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "LEFT",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  2,
        "name":  "Level 36",
        "target":  {
                       "col":  3,
                       "row":  3
                   },
        "rows":  4,
        "parMoves":  11
    },
    {
        "id":  37,
        "cols":  4,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  2,
        "name":  "Level 37",
        "target":  {
                       "col":  3,
                       "row":  3
                   },
        "rows":  4,
        "parMoves":  9
    },
    {
        "id":  38,
        "cols":  4,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "DOWN",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  2,
        "name":  "Level 38",
        "target":  {
                       "col":  3,
                       "row":  3
                   },
        "rows":  4,
        "parMoves":  10
    },
    {
        "id":  39,
        "cols":  4,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "LEFT",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  2,
        "name":  "Level 39",
        "target":  {
                       "col":  3,
                       "row":  3
                   },
        "rows":  4,
        "parMoves":  13
    },
    {
        "id":  40,
        "cols":  4,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  2,
        "name":  "Level 40",
        "target":  {
                       "col":  3,
                       "row":  3
                   },
        "rows":  4,
        "parMoves":  8
    },
    {
        "id":  41,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  3,
        "name":  "Level 41",
        "target":  {
                       "col":  4,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  17
    },
    {
        "id":  42,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "LEFT",
                      "col":  1
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "RIGHT",
                           "col":  0,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "DOWN",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  3,
        "name":  "Level 42",
        "target":  {
                       "col":  3,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  14
    },
    {
        "id":  43,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "DOWN",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  3,
        "name":  "Level 43",
        "target":  {
                       "col":  4,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  16
    },
    {
        "id":  44,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "LEFT",
                      "col":  1
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "LEFT",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "RIGHT",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#9b59b6",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  3,
        "name":  "Level 44",
        "target":  {
                       "col":  3,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  26
    },
    {
        "id":  45,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "LEFT",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  3,
        "name":  "Level 45",
        "target":  {
                       "col":  4,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  13
    },
    {
        "id":  46,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "LEFT",
                      "col":  1
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "LEFT",
                           "col":  0,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "LEFT",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  3,
        "name":  "Level 46",
        "target":  {
                       "col":  3,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  19
    },
    {
        "id":  47,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "LEFT",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  3,
        "name":  "Level 47",
        "target":  {
                       "col":  4,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  15
    },
    {
        "id":  48,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  1
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#e74c3c",
                           "direction":  "DOWN",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  3,
        "name":  "Level 48",
        "target":  {
                       "col":  3,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  11
    },
    {
        "id":  49,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "LEFT",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  3,
        "name":  "Level 49",
        "target":  {
                       "col":  4,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  16
    },
    {
        "id":  50,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  1
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#43e97b",
                           "direction":  "DOWN",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  3,
        "name":  "Level 50",
        "target":  {
                       "col":  3,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  17
    },
    {
        "id":  51,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  3,
        "name":  "Level 51",
        "target":  {
                       "col":  4,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  14
    },
    {
        "id":  52,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "LEFT",
                      "col":  1
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "RIGHT",
                           "col":  0,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "DOWN",
                           "col":  0,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "LEFT",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#e74c3c",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  3,
        "name":  "Level 52",
        "target":  {
                       "col":  3,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  21
    },
    {
        "id":  53,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  3,
        "name":  "Level 53",
        "target":  {
                       "col":  4,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  13
    },
    {
        "id":  54,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "LEFT",
                      "col":  1
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "RIGHT",
                           "col":  0,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  0,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "RIGHT",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  3,
        "name":  "Level 54",
        "target":  {
                       "col":  3,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  19
    },
    {
        "id":  55,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  3,
        "name":  "Level 55",
        "target":  {
                       "col":  4,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  16
    },
    {
        "id":  56,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "LEFT",
                      "col":  1
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "RIGHT",
                           "col":  0,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  0,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "DOWN",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  3,
        "name":  "Level 56",
        "target":  {
                       "col":  3,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  24
    },
    {
        "id":  57,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  3,
        "name":  "Level 57",
        "target":  {
                       "col":  4,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  14
    },
    {
        "id":  58,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  1
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#43e97b",
                           "direction":  "DOWN",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  3,
        "name":  "Level 58",
        "target":  {
                       "col":  3,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  11
    },
    {
        "id":  59,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "LEFT",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "RIGHT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  3,
        "name":  "Level 59",
        "target":  {
                       "col":  4,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  12
    },
    {
        "id":  60,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "DOWN",
                      "col":  1
                  },
        "arrows":  [
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "DOWN",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#9b59b6",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  3,
        "name":  "Level 60",
        "target":  {
                       "col":  3,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  20
    },
    {
        "id":  61,
        "cols":  5,
        "start":  {
                      "row":  1,
                      "dir":  "DOWN",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "LEFT",
                           "col":  0,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "LEFT",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "RIGHT",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "DOWN",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "DOWN",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "RIGHT",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "RIGHT",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  4,
        "name":  "Level 61",
        "target":  {
                       "col":  4,
                       "row":  3
                   },
        "rows":  5,
        "parMoves":  25
    },
    {
        "id":  62,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "RIGHT",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#fee140",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  4,
        "name":  "Level 62",
        "target":  {
                       "col":  4,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  25
    },
    {
        "id":  63,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "DOWN",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#43e97b",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  4,
        "name":  "Level 63",
        "target":  {
                       "col":  4,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  21
    },
    {
        "id":  64,
        "cols":  5,
        "start":  {
                      "row":  1,
                      "dir":  "UP",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "DOWN",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "RIGHT",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#43e97b",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  4,
        "name":  "Level 64",
        "target":  {
                       "col":  4,
                       "row":  3
                   },
        "rows":  5,
        "parMoves":  30
    },
    {
        "id":  65,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "RIGHT",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "RIGHT",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#fee140",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#43e97b",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  4,
        "name":  "Level 65",
        "target":  {
                       "col":  4,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  32
    },
    {
        "id":  66,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "RIGHT",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  4,
        "name":  "Level 66",
        "target":  {
                       "col":  4,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  26
    },
    {
        "id":  67,
        "cols":  5,
        "start":  {
                      "row":  1,
                      "dir":  "UP",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "LEFT",
                           "col":  0,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "LEFT",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "RIGHT",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "RIGHT",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  4,
        "name":  "Level 67",
        "target":  {
                       "col":  4,
                       "row":  3
                   },
        "rows":  5,
        "parMoves":  26
    },
    {
        "id":  68,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "DOWN",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  4,
        "name":  "Level 68",
        "target":  {
                       "col":  4,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  23
    },
    {
        "id":  69,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#4facfe",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#9b59b6",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  4,
        "name":  "Level 69",
        "target":  {
                       "col":  4,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  27
    },
    {
        "id":  70,
        "cols":  5,
        "start":  {
                      "row":  1,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "RIGHT",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "DOWN",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#f39c12",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  4,
        "name":  "Level 70",
        "target":  {
                       "col":  4,
                       "row":  3
                   },
        "rows":  5,
        "parMoves":  23
    },
    {
        "id":  71,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "LEFT",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "DOWN",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#fee140",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  4,
        "name":  "Level 71",
        "target":  {
                       "col":  4,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  22
    },
    {
        "id":  72,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "LEFT",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "DOWN",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "RIGHT",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "RIGHT",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#9b59b6",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  4,
        "name":  "Level 72",
        "target":  {
                       "col":  4,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  27
    },
    {
        "id":  73,
        "cols":  5,
        "start":  {
                      "row":  1,
                      "dir":  "DOWN",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "DOWN",
                           "col":  0,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "LEFT",
                           "col":  1,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#4facfe",
                           "direction":  "DOWN",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#e74c3c",
                           "direction":  "RIGHT",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "RIGHT",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "RIGHT",
                           "col":  2,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "DOWN",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "DOWN",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  4,
        "name":  "Level 73",
        "target":  {
                       "col":  4,
                       "row":  3
                   },
        "rows":  5,
        "parMoves":  37
    },
    {
        "id":  74,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "DOWN",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "RIGHT",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  4,
        "name":  "Level 74",
        "target":  {
                       "col":  4,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  28
    },
    {
        "id":  75,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "RIGHT",
                           "col":  2,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "RIGHT",
                           "col":  1,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#43e97b",
                           "direction":  "LEFT",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#f39c12",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  4,
        "name":  "Level 75",
        "target":  {
                       "col":  4,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  30
    },
    {
        "id":  76,
        "cols":  5,
        "start":  {
                      "row":  1,
                      "dir":  "UP",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "LEFT",
                           "col":  0,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#fee140",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#9b59b6",
                           "direction":  "DOWN",
                           "col":  4,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  4,
        "name":  "Level 76",
        "target":  {
                       "col":  4,
                       "row":  3
                   },
        "rows":  5,
        "parMoves":  22
    },
    {
        "id":  77,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#f39c12",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  4,
        "name":  "Level 77",
        "target":  {
                       "col":  4,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  21
    },
    {
        "id":  78,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "DOWN",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#e74c3c",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  4,
        "name":  "Level 78",
        "target":  {
                       "col":  4,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  23
    },
    {
        "id":  79,
        "cols":  5,
        "start":  {
                      "row":  1,
                      "dir":  "UP",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "DOWN",
                           "col":  0,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "DOWN",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "DOWN",
                           "col":  4,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  4,
        "name":  "Level 79",
        "target":  {
                       "col":  4,
                       "row":  3
                   },
        "rows":  5,
        "parMoves":  21
    },
    {
        "id":  80,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "LEFT",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "RIGHT",
                           "col":  1,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#fee140",
                           "direction":  "DOWN",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#4facfe",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  4,
        "name":  "Level 80",
        "target":  {
                       "col":  4,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  23
    },
    {
        "id":  81,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "RIGHT",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  5,
        "name":  "Level 81",
        "target":  {
                       "col":  4,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  31
    },
    {
        "id":  82,
        "cols":  5,
        "start":  {
                      "row":  1,
                      "dir":  "DOWN",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "DOWN",
                           "col":  0,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "LEFT",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "DOWN",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#4facfe",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#43e97b",
                           "direction":  "DOWN",
                           "col":  4,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  5,
        "name":  "Level 82",
        "target":  {
                       "col":  4,
                       "row":  3
                   },
        "rows":  5,
        "parMoves":  28
    },
    {
        "id":  83,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "RIGHT",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "LEFT",
                           "col":  1,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "RIGHT",
                           "col":  1,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "RIGHT",
                           "col":  1,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  5,
        "name":  "Level 83",
        "target":  {
                       "col":  4,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  37
    },
    {
        "id":  84,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "DOWN",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "RIGHT",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#e74c3c",
                           "direction":  "DOWN",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#fee140",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#f39c12",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  5,
        "name":  "Level 84",
        "target":  {
                       "col":  4,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  42
    },
    {
        "id":  85,
        "cols":  5,
        "start":  {
                      "row":  1,
                      "dir":  "UP",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  0,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "DOWN",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "DOWN",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  5,
        "name":  "Level 85",
        "target":  {
                       "col":  4,
                       "row":  3
                   },
        "rows":  5,
        "parMoves":  33
    },
    {
        "id":  86,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "DOWN",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "RIGHT",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "RIGHT",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  5,
        "name":  "Level 86",
        "target":  {
                       "col":  4,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  33
    },
    {
        "id":  87,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#9b59b6",
                           "direction":  "DOWN",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#fee140",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  5,
        "name":  "Level 87",
        "target":  {
                       "col":  4,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  26
    },
    {
        "id":  88,
        "cols":  5,
        "start":  {
                      "row":  1,
                      "dir":  "DOWN",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  0,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#f39c12",
                           "direction":  "DOWN",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "RIGHT",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "RIGHT",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  5,
        "name":  "Level 88",
        "target":  {
                       "col":  4,
                       "row":  3
                   },
        "rows":  5,
        "parMoves":  30
    },
    {
        "id":  89,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "DOWN",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "RIGHT",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "RIGHT",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#fee140",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#fee140",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  5,
        "name":  "Level 89",
        "target":  {
                       "col":  4,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  28
    },
    {
        "id":  90,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#9b59b6",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#4facfe",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  5,
        "name":  "Level 90",
        "target":  {
                       "col":  4,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  32
    },
    {
        "id":  91,
        "cols":  5,
        "start":  {
                      "row":  1,
                      "dir":  "UP",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "DOWN",
                           "col":  0,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "DOWN",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "RIGHT",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "RIGHT",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#f39c12",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  5,
        "name":  "Level 91",
        "target":  {
                       "col":  4,
                       "row":  3
                   },
        "rows":  5,
        "parMoves":  25
    },
    {
        "id":  92,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "DOWN",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "DOWN",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "RIGHT",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "RIGHT",
                           "col":  1,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#9b59b6",
                           "direction":  "DOWN",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#4facfe",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  5,
        "name":  "Level 92",
        "target":  {
                       "col":  4,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  30
    },
    {
        "id":  93,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "LEFT",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "RIGHT",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#4facfe",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#9b59b6",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  5,
        "name":  "Level 93",
        "target":  {
                       "col":  4,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  31
    },
    {
        "id":  94,
        "cols":  5,
        "start":  {
                      "row":  1,
                      "dir":  "DOWN",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "DOWN",
                           "col":  0,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "DOWN",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#4facfe",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#43e97b",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  5,
        "name":  "Level 94",
        "target":  {
                       "col":  4,
                       "row":  3
                   },
        "rows":  5,
        "parMoves":  32
    },
    {
        "id":  95,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "DOWN",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#43e97b",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#43e97b",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  5,
        "name":  "Level 95",
        "target":  {
                       "col":  4,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  32
    },
    {
        "id":  96,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "DOWN",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "DOWN",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "RIGHT",
                           "col":  1,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "LEFT",
                           "col":  1,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  5,
        "name":  "Level 96",
        "target":  {
                       "col":  4,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  37
    },
    {
        "id":  97,
        "cols":  5,
        "start":  {
                      "row":  1,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "DOWN",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#00d2ff",
                           "direction":  "RIGHT",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#e74c3c",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  2,
                           "color":  "#9b59b6",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "LEFT",
                           "col":  1,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  5,
        "name":  "Level 97",
        "target":  {
                       "col":  4,
                       "row":  3
                   },
        "rows":  5,
        "parMoves":  33
    },
    {
        "id":  98,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  3,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#f39c12",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  5,
        "name":  "Level 98",
        "target":  {
                       "col":  4,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  32
    },
    {
        "id":  99,
        "cols":  5,
        "start":  {
                      "row":  0,
                      "dir":  "RIGHT",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#4facfe",
                           "direction":  "LEFT",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "RIGHT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#43e97b",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "DOWN",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "DOWN",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "RIGHT",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  1,
                           "color":  "#f39c12",
                           "direction":  "RIGHT",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  4,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  4,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  3,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  5,
        "name":  "Level 99",
        "target":  {
                       "col":  4,
                       "row":  4
                   },
        "rows":  5,
        "parMoves":  27
    },
    {
        "id":  100,
        "cols":  5,
        "start":  {
                      "row":  1,
                      "dir":  "UP",
                      "col":  0
                  },
        "arrows":  [
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "DOWN",
                           "col":  0,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#fee140",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  0,
                           "color":  "#f39c12",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  1,
                           "color":  "#fee140",
                           "direction":  "LEFT",
                           "col":  4,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "DOWN",
                           "col":  4,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  2,
                           "color":  "#43e97b",
                           "direction":  "DOWN",
                           "col":  2,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  2,
                           "color":  "#f39c12",
                           "direction":  "DOWN",
                           "col":  1,
                           "correctDir":  "LEFT"
                       },
                       {
                           "row":  2,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  0,
                           "correctDir":  "DOWN"
                       },
                       {
                           "row":  3,
                           "color":  "#fee140",
                           "direction":  "LEFT",
                           "col":  0,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  3,
                           "color":  "#9b59b6",
                           "direction":  "LEFT",
                           "col":  2,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  3,
                           "color":  "#e74c3c",
                           "direction":  "LEFT",
                           "col":  3,
                           "correctDir":  "RIGHT"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  1,
                           "color":  "#9b59b6",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#4facfe",
                           "direction":  "UP",
                           "col":  0,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  1,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#00d2ff",
                           "direction":  "UP",
                           "col":  2,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#43e97b",
                           "direction":  "UP",
                           "col":  3,
                           "correctDir":  "UP"
                       },
                       {
                           "row":  4,
                           "color":  "#f39c12",
                           "direction":  "UP",
                           "col":  4,
                           "correctDir":  "UP"
                       }
                   ],
        "world":  5,
        "name":  "Level 100",
        "target":  {
                       "col":  4,
                       "row":  3
                   },
        "rows":  5,
        "parMoves":  29
    }
];