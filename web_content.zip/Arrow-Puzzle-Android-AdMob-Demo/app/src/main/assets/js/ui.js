/**
 * ui.js - User Interface Controller, Screen Navigation, Modal Management,
 * HUD Updaters, and Canvas Confetti Particle System
 */

const ARROW_ASSETS = {
    blue: 'assets/arrows/arrow-blue.svg',
    green: 'assets/arrows/arrow-green.svg',
    yellow: 'assets/arrows/arrow-yellow.svg',
    orange: 'assets/arrows/arrow-orange.svg',
    purple: 'assets/arrows/arrow-purple.svg',
    cyan: 'assets/arrows/arrow-cyan.svg'
};

function getArrowAssetForColor(color) {
    if (!color) return ARROW_ASSETS.blue;
    const c = String(color).toLowerCase();
    if (c.includes('43e97b') || c.includes('2ecc71') || c.includes('green') || c.includes('16a34a') || c.includes('4ade80')) return ARROW_ASSETS.green;
    if (c.includes('9b59b6') || c.includes('8b5cf6') || c.includes('purple') || c.includes('7c3aed') || c.includes('a855f7')) return ARROW_ASSETS.purple;
    if (c.includes('f1c40f') || c.includes('fbbf24') || c.includes('yellow') || c.includes('eab308') || c.includes('fde047')) return ARROW_ASSETS.yellow;
    if (c.includes('f39c12') || c.includes('f97316') || c.includes('orange') || c.includes('e67e22') || c.includes('e74c3c') || c.includes('f87171')) return ARROW_ASSETS.orange;
    if (c.includes('00d2ff') || c.includes('06b6d4') || c.includes('cyan') || c.includes('67e8f9')) return ARROW_ASSETS.cyan;
    return ARROW_ASSETS.blue;
}

class UIManager {
    constructor() {
        this.currentScreen = 'screen-home';
        this.currentLevelPack = 1; // 1: 1-20, 2: 21-40, 3: 41-60, 4: 61-80, 5: 81-100
        this.boardElement = null;
        this.confettiCanvas = null;
        this.confettiCtx = null;
        this.confettiParticles = [];
        this.confettiAnimationId = null;
        this.lifeTimerInterval = null;
    }

    init() {
        this.boardElement = document.getElementById('puzzle-board');
        this.confettiCanvas = document.getElementById('confetti-canvas');
        if (this.confettiCanvas) {
            this.confettiCtx = this.confettiCanvas.getContext('2d');
            this._resizeCanvas();
            window.addEventListener('resize', () => this._resizeCanvas());
        }

        this.updateHUD();
        this.startLifeTimer();
        this.renderLevelSelect();
    }

    _resizeCanvas() {
        if (this.confettiCanvas) {
            this.confettiCanvas.width = window.innerWidth;
            this.confettiCanvas.height = window.innerHeight;
        }
    }

    /* === SCREEN SWITCHING === */
    showScreen(screenId) {
        document.querySelectorAll('.game-screen').forEach(el => {
            el.classList.remove('active');
        });
        const target = document.getElementById(screenId);
        if (target) {
            target.classList.add('active');
            this.currentScreen = screenId;
        }
        this.closeAllModals();
        this.updateHUD();

        if (screenId === 'screen-levels') {
            this.renderLevelSelect();
        }
    }

    /* === MODAL MANAGEMENT === */
    showModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('active');
        }
    }

    hideModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('active');
        }
    }

    closeAllModals() {
        document.querySelectorAll('.modal-overlay').forEach(m => m.classList.remove('active'));
    }

    /* === HUD & STATUS UPDATES === */
    updateHUD() {
        if (!window.Storage) return;

        const coins = window.Storage.getCoins();
        const lives = window.Storage.getLives();

        document.querySelectorAll('.hud-coins-val').forEach(el => {
            el.textContent = coins;
        });

        document.querySelectorAll('.hud-lives-val').forEach(el => {
            el.textContent = lives;
        });
    }

    startLifeTimer() {
        if (this.lifeTimerInterval) clearInterval(this.lifeTimerInterval);
        this.lifeTimerInterval = setInterval(() => {
            if (!window.Storage) return;
            window.Storage.updateLifeRegeneration();
            this.updateHUD();

            const msRemaining = window.Storage.getTimeUntilNextLife();
            const timerEl = document.getElementById('life-regen-timer');
            if (timerEl) {
                if (window.Storage.getLives() >= 5) {
                    timerEl.textContent = 'FULL';
                } else {
                    const totalSec = Math.floor(msRemaining / 1000);
                    const mins = Math.floor(totalSec / 60);
                    const secs = totalSec % 60;
                    timerEl.textContent = `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
                }
            }
        }, 1000);
    }

    /* === LEVEL SELECT RENDERING === */
    setLevelPack(packIndex) {
        this.currentLevelPack = Math.max(1, Math.min(5, packIndex));
        this.renderLevelSelect();
    }

    renderLevelSelect() {
        const container = document.getElementById('levels-grid');
        if (!container || !window.LEVELS_DATA || !window.Storage) return;

        container.innerHTML = '';

        const startId = (this.currentLevelPack - 1) * 20 + 1;
        const endId = startId + 19;

        // Update tabs
        document.querySelectorAll('.tab-btn').forEach(btn => {
            const pack = Number(btn.getAttribute('data-pack'));
            if (pack === this.currentLevelPack) {
                btn.classList.add('active');
            } else {
                btn.classList.remove('active');
            }
        });

        // Update pagination dots
        document.querySelectorAll('.page-dot').forEach((dot, idx) => {
            if (idx + 1 === this.currentLevelPack) {
                dot.classList.add('active');
            } else {
                dot.classList.remove('active');
            }
        });

        const currentHighestUnlocked = Math.max(...window.Storage.data.unlockedLevels);

        for (let id = startId; id <= endId; id++) {
            const isUnlocked = window.Storage.isLevelUnlocked(id);
            const stars = window.Storage.getLevelStars(id);
            const isCurrent = (id === currentHighestUnlocked);

            const card = document.createElement('button');
            card.className = `level-card ${isUnlocked ? 'unlocked' : 'locked'} ${isCurrent ? 'current' : ''}`;
            card.setAttribute('data-level-id', id);

            if (isUnlocked) {
                // Stars display: 3 stars using SVG assets
                let starsHtml = '<div class="level-stars">';
                for (let s = 1; s <= 3; s++) {
                    const filled = s <= stars ? 'filled' : 'empty';
                    const starSrc = filled === 'filled' ? 'assets/icons/star.svg' : 'assets/icons/star-empty.svg';
                    starsHtml += `<img src="${starSrc}" class="star-icon ${filled}" alt="${filled === 'filled' ? 'Earned star' : 'Empty star'}">`;
                }
                starsHtml += '</div>';

                card.innerHTML = `
                    <span class="level-num">${id}</span>
                    ${starsHtml}
                `;

                card.addEventListener('click', () => {
                    if (window.Audio) window.Audio.playClick();
                    if (window.App) window.App.startLevel(id);
                });
            } else {
                card.innerHTML = `
                    <span class="level-num">${id}</span>
                    <img src="assets/icons/lock.svg" class="lock-icon-img" alt="Locked">
                `;
                card.addEventListener('click', () => {
                    if (window.Audio) window.Audio.playError();
                    card.classList.add('shake');
                    setTimeout(() => card.classList.remove('shake'), 400);
                });
            }

            container.appendChild(card);
        }
    }

    /* === PUZZLE BOARD RENDERING === */
    renderBoard(engineState, onArrowClick) {
        if (!this.boardElement) return;

        const { rows, cols, grid, isSolved } = engineState;

        this.boardElement.style.gridTemplateRows = `repeat(${rows}, 1fr)`;
        this.boardElement.style.gridTemplateColumns = `repeat(${cols}, 1fr)`;
        this.boardElement.innerHTML = '';

        for (let r = 0; r < rows; r++) {
            for (let c = 0; c < cols; c++) {
                const cell = grid[r][c];
                const tile = document.createElement('div');
                tile.className = `puzzle-tile tile-${cell.type}`;
                tile.id = `tile-${r}-${c}`;
                tile.setAttribute('data-row', r);
                tile.setAttribute('data-col', c);

                if (cell.inPath) {
                    tile.classList.add('in-path');
                    tile.style.setProperty('--path-delay', `${(cell.pathIndex || 0) * 0.05}s`);
                }

                if (cell.hintActive) {
                    tile.classList.add('hint-active');
                }

                if (cell.type === 'start') {
                    tile.innerHTML = `
                        <div class="start-badge">
                            <img src="assets/puzzle/start.svg" class="start-icon" alt="Start">
                            <span class="tile-label">START</span>
                        </div>
                    `;
                } else if (cell.type === 'target') {
                    const targetAsset = isSolved ? 'assets/puzzle/target-active.svg' : 'assets/puzzle/target.svg';
                    tile.innerHTML = `
                        <div class="target-badge ${isSolved ? 'activated' : ''}">
                            <img src="${targetAsset}" class="target-icon" alt="Target">
                            <span class="tile-label">TARGET</span>
                        </div>
                    `;
                } else if (cell.type === 'arrow') {
                    const angle = DIR_DELTAS[cell.dir] ? DIR_DELTAS[cell.dir].angle : 0;
                    const arrowAsset = getArrowAssetForColor(cell.color);
                    tile.classList.add('arrow-tile');
                    tile.setAttribute('role', 'button');
                    tile.setAttribute('tabindex', '0');
                    tile.setAttribute('aria-label', `Arrow pointing ${cell.dir}`);

                    tile.innerHTML = `
                        <div class="arrow-wrapper" style="transform: rotate(${angle}deg);">
                            <img src="${arrowAsset}" class="arrow-svg" alt="">
                        </div>
                    `;

                    // Click & Keyboard support
                    const handleClick = (e) => {
                        e.preventDefault();
                        onArrowClick(r, c);
                    };

                    tile.addEventListener('pointerdown', handleClick);
                    tile.addEventListener('keydown', (e) => {
                        if (e.key === 'Enter' || e.key === ' ') {
                            handleClick(e);
                        }
                    });
                }

                this.boardElement.appendChild(tile);
            }
        }
    }

    updateTileRotation(row, col, newDir, angle, inPath, pathIndex) {
        const tile = document.getElementById(`tile-${row}-${col}`);
        if (!tile) return;

        const wrapper = tile.querySelector('.arrow-wrapper');
        if (wrapper) {
            wrapper.style.transform = `rotate(${angle}deg)`;
        }

        tile.setAttribute('aria-label', `Arrow pointing ${newDir}`);
        tile.classList.remove('hint-active');
    }

    refreshBoardPath(grid, isSolved) {
        if (!this.boardElement) return;

        const rows = grid.length;
        const cols = grid[0].length;

        for (let r = 0; r < rows; r++) {
            for (let c = 0; c < cols; c++) {
                const cell = grid[r][c];
                const tile = document.getElementById(`tile-${r}-${c}`);
                if (!tile) continue;

                if (cell.inPath) {
                    tile.classList.add('in-path');
                    tile.style.setProperty('--path-delay', `${(cell.pathIndex || 0) * 0.05}s`);
                } else {
                    tile.classList.remove('in-path');
                }

                if (cell.hintActive) {
                    tile.classList.add('hint-active');
                } else {
                    tile.classList.remove('hint-active');
                }

                if (cell.type === 'target') {
                    const badge = tile.querySelector('.target-badge');
                    const targetImg = tile.querySelector('.target-icon');
                    if (badge) {
                        if (isSolved) {
                            badge.classList.add('activated');
                            if (targetImg) targetImg.src = 'assets/puzzle/target-active.svg';
                        } else {
                            badge.classList.remove('activated');
                            if (targetImg) targetImg.src = 'assets/puzzle/target.svg';
                        }
                    }
                }
            }
        }
    }

    /* === CONFETTI CELEBRATION === */
    triggerConfetti(durationMs = 2600) {
        if (!this.confettiCanvas || !this.confettiCtx) return;

        const colors = ['#f39c12', '#e74c3c', '#3498db', '#2ecc71', '#9b59b6', '#f1c40f', '#00d2ff', '#e056fd'];
        this.confettiParticles = [];

        const count = 120;
        for (let i = 0; i < count; i++) {
            this.confettiParticles.push({
                x: window.innerWidth * (0.2 + Math.random() * 0.6),
                y: window.innerHeight * 0.4,
                vx: (Math.random() - 0.5) * 16,
                vy: (Math.random() - 1.2) * 18,
                size: Math.random() * 9 + 5,
                color: colors[Math.floor(Math.random() * colors.length)],
                rotation: Math.random() * 360,
                rotSpeed: (Math.random() - 0.5) * 14,
                gravity: 0.42,
                drag: 0.98,
                opacity: 1
            });
        }

        const startTime = Date.now();

        const animate = () => {
            const elapsed = Date.now() - startTime;
            this.confettiCtx.clearRect(0, 0, this.confettiCanvas.width, this.confettiCanvas.height);

            this.confettiParticles.forEach(p => {
                p.x += p.vx;
                p.y += p.vy;
                p.vy += p.gravity;
                p.vx *= p.drag;
                p.rotation += p.rotSpeed;

                if (elapsed > durationMs - 800) {
                    p.opacity = Math.max(0, 1 - (elapsed - (durationMs - 800)) / 800);
                }

                this.confettiCtx.save();
                this.confettiCtx.translate(p.x, p.y);
                this.confettiCtx.rotate((p.rotation * Math.PI) / 180);
                this.confettiCtx.globalAlpha = p.opacity;
                this.confettiCtx.fillStyle = p.color;
                this.confettiCtx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size * 0.7);
                this.confettiCtx.restore();
            });

            if (elapsed < durationMs) {
                this.confettiAnimationId = requestAnimationFrame(animate);
            } else {
                this.confettiCtx.clearRect(0, 0, this.confettiCanvas.width, this.confettiCanvas.height);
                this.confettiParticles = [];
            }
        };

        if (this.confettiAnimationId) cancelAnimationFrame(this.confettiAnimationId);
        this.confettiAnimationId = requestAnimationFrame(animate);
    }

    /* === TOAST MESSAGES === */
    showToast(message, duration = 2200) {
        let toast = document.getElementById('game-toast');
        if (!toast) {
            toast = document.createElement('div');
            toast.id = 'game-toast';
            toast.className = 'game-toast';
            document.body.appendChild(toast);
        }
        toast.textContent = message;
        toast.classList.add('visible');

        clearTimeout(this.toastTimeout);
        this.toastTimeout = setTimeout(() => {
            toast.classList.remove('visible');
        }, duration);
    }
}

// Export singleton instance
window.UI = new UIManager();
