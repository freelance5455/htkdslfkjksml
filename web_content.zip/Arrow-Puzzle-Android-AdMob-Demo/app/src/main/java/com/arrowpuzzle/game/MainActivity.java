package com.arrowpuzzle.game;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;

public class MainActivity extends AppCompatActivity {
    private static final String TEST_BANNER = "ca-app-pub-3940256099942544/9214589741";
    private static final String TEST_INTERSTITIAL = "ca-app-pub-3940256099942544/1033173712";
    private static final String TEST_REWARDED = "ca-app-pub-3940256099942544/5224354917";

    private WebView webView;
    private AdView bannerAd;
    private InterstitialAd interstitialAd;
    private RewardedAd rewardedAd;
    private int completedSinceInterstitial = 0;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_main);
        hideSystemBars();

        webView = findViewById(R.id.game_webview);
        configureWebView();

        MobileAds.initialize(this, status -> {
            runOnUiThread(() -> {
                loadBanner();
                loadInterstitial();
                loadRewarded();
            });
        });

        webView.loadUrl("file:///android_asset/index.html");
    }

    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setTextZoom(100);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setUserAgentString(s.getUserAgentString() + " ArrowPuzzleAndroid/1.0");

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AdsBridge(), "AndroidAds");
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG);
    }

    private void loadBanner() {
        if (bannerAd != null) return;
        bannerAd = new AdView(this);
        bannerAd.setAdUnitId(TEST_BANNER);
        bannerAd.setAdSize(AdSize.getLargeAnchoredAdaptiveBannerAdSize(this, getResources().getDisplayMetrics().widthPixels));
        FrameLayout container = findViewById(R.id.ad_container);
        container.removeAllViews();
        container.addView(bannerAd, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT));
        bannerAd.loadAd(new AdRequest.Builder().build());
    }

    private void loadInterstitial() {
        InterstitialAd.load(this, TEST_INTERSTITIAL, new AdRequest.Builder().build(),
                new InterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull InterstitialAd ad) {
                        interstitialAd = ad;
                    }
                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError error) {
                        interstitialAd = null;
                    }
                });
    }

    private void loadRewarded() {
        RewardedAd.load(this, TEST_REWARDED, new AdRequest.Builder().build(),
                new RewardedAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull RewardedAd ad) {
                        rewardedAd = ad;
                    }
                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError error) {
                        rewardedAd = null;
                    }
                });
    }

    private void maybeShowInterstitial() {
        completedSinceInterstitial++;
        if (completedSinceInterstitial < 3) return;
        completedSinceInterstitial = 0;
        if (interstitialAd != null) {
            InterstitialAd ad = interstitialAd;
            interstitialAd = null;
            ad.setFullScreenContentCallback(new com.google.android.gms.ads.FullScreenContentCallback() {
                @Override public void onAdDismissedFullScreenContent() { loadInterstitial(); }
                @Override public void onAdFailedToShowFullScreenContent(@NonNull com.google.android.gms.ads.AdError adError) { loadInterstitial(); }
            });
            ad.show(this);
        } else {
            loadInterstitial();
        }
    }

    private void showRewardedForLife() {
        if (rewardedAd == null) {
            Toast.makeText(this, "Demo reward ad is still loading. Try again.", Toast.LENGTH_SHORT).show();
            loadRewarded();
            return;
        }
        RewardedAd ad = rewardedAd;
        rewardedAd = null;
        ad.setFullScreenContentCallback(new com.google.android.gms.ads.FullScreenContentCallback() {
            @Override public void onAdDismissedFullScreenContent() { loadRewarded(); }
            @Override public void onAdFailedToShowFullScreenContent(@NonNull com.google.android.gms.ads.AdError error) { loadRewarded(); }
        });
        ad.show(this, rewardItem -> {
            runOnUiThread(() -> webView.evaluateJavascript(
                    "window.Storage && window.Storage.refillLives ? window.Storage.refillLives() : null; window.UI && window.UI.updateHUD ? window.UI.updateHUD() : null;",
                    null));
            Toast.makeText(this, "+1 Life", Toast.LENGTH_SHORT).show();
        });
    }

    private void hideSystemBars() {
        Window window = getWindow();
        WindowInsetsController controller = window.getInsetsController();
        if (controller != null) {
            controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
            controller.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
        } else {
            window.getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null) {
            webView.evaluateJavascript(
                    "(window.UI && document.querySelector('#modal-pause.active')) ? document.querySelector('#btn-pause-resume')?.click() : (document.querySelector('#screen-game.active') ? document.querySelector('#btn-game-back')?.click() : (document.querySelector('#screen-levels.active') ? document.querySelector('#btn-levels-back')?.click() : false));",
                    value -> {});
        }
    }

    @Override
    protected void onDestroy() {
        if (bannerAd != null) bannerAd.destroy();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    private class AdsBridge {
        @JavascriptInterface
        public void levelCompleted() {
            runOnUiThread(MainActivity.this::maybeShowInterstitial);
        }

        @JavascriptInterface
        public void showRewardedLife() {
            runOnUiThread(MainActivity.this::showRewardedForLife);
        }

        @JavascriptInterface
        public void openUrl(String url) {
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(intent);
            } catch (Exception ignored) { }
        }
    }
}
