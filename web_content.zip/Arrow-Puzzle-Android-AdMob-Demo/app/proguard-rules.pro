# Arrow Puzzle uses WebView + Google Mobile Ads. Keep default Android/R8 rules.
