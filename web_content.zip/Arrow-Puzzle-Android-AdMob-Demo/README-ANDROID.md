# Arrow Puzzle — Android + AdMob Demo

This folder is an Android Studio project wrapping the existing **Arrow Puzzle** HTML5 game in a native Android WebView.

## Included

- Arrow Puzzle web game bundled locally under `app/src/main/assets/`
- Portrait orientation
- Full-screen immersive game UI
- Android back-button handling
- LocalStorage and Web Audio support
- Google Mobile Ads SDK `25.4.0`
- Google official **demo/test** banner ad
- Google official **demo/test** interstitial every 3 completed levels
- Google official **demo/test** rewarded ad bridge for `+1 Life`
- No Firebase, PHP, Node.js backend, React, Vue, or Angular
- Works offline for game content; ads require internet

## Demo Ad IDs

These are Google's official Android demo ad units and are safe for development/testing:

- Banner: `ca-app-pub-3940256099942544/9214589741`
- Interstitial: `ca-app-pub-3940256099942544/1033173712`
- Rewarded: `ca-app-pub-3940256099942544/5224354917`
- Demo App ID: `ca-app-pub-3940256099942544~3347511713`

**Do not publish with these IDs.** Replace them with your own AdMob App ID and ad-unit IDs before release.

## Build in Android Studio

1. Install Android Studio.
2. Open this `Arrow-Puzzle-Android-AdMob-Demo` folder.
3. Allow Gradle sync to download the Android/Google dependencies.
4. Connect an Android phone or start an emulator.
5. Choose `app` and press **Run** for the debug/demo build.
6. For an APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

The current build configuration uses min SDK 23, target/compile SDK 35, and Java 17.

## Before publishing

1. Create/register the app in your AdMob account.
2. Replace the demo App ID in `app/src/main/res/values/strings.xml`.
3. Replace the three demo ad-unit IDs in `MainActivity.java`.
4. Add the required consent/privacy flow for the markets in which you distribute the app.
5. Create a signed release APK/AAB and test the release build.

Google's documentation explicitly recommends test ads during development and replacing demo IDs before publishing.
