// =============================================================================
// 1. INISIALISASI PUSTAKA LURING
// =============================================================================
if (window.pdfjsLib) {
    pdfjsLib.GlobalWorkerOptions.workerSrc = 'pdf.worker.min.js';
}

// =============================================================================
// 2. FUNGSI PEMBANTU BAHASA ARAB & RTL
// =============================================================================
function isArabicText(text) {
    if (!text) return false;
    const arabicRegex = /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]/;
    return arabicRegex.test(text);
}

function normalizeArabic(text) {
    if (!text) return '';
    return text
        .replace(/[\u064B-\u065F\u0670]/g, '')
        .replace(/[إأآٱ]/g, 'ا')
        .replace(/ى/g, 'ي')
        .replace(/ة/g, 'ه')
        .toLowerCase();
}

// =============================================================================
// 3. STATUS & VARIABEL GLOBAL APLIKASI
// =============================================================================
let pdfDoc = null;
let currentPDFBytes = null;
let pageNum = 1;
let pageRendering = false;
let pageNumPending = null;
let scale = 1.0;
let currentFileKey = "";
let currentFileName = "";
let currentFileSize = "";

// Pencarian Teks
let searchMatches = [];
let currentSearchIndex = -1;
let searchTimeout = null;
let activeSearchToken = 0;

// Anotasi
let isAnnotationMode = false;
let currentTool = 'pen';
let currentColor = '#000000';
let isDrawing = false;
let currentStroke = null;
let pageAnnotations = {};

// Status Editor Teks Anotasi
let pendingTextPos = null;
let currentTextDirection = 'rtl';
let currentTextAlign = 'right';

// Text-to-Speech
let ttsUtterance = null;
let isTTSPlaying = false;
let ttsSpeedIndex = 1;
const ttsSpeeds = [0.75, 1.0, 1.25, 1.5, 2.0];
let ttsLanguageMode = 'auto'; // 'auto', 'ar', 'id'
let availableVoices = [];

function updateTTSVoices() {
    if ('speechSynthesis' in window) {
        availableVoices = window.speechSynthesis.getVoices();
    }
}
if ('speechSynthesis' in window) {
    window.speechSynthesis.onvoiceschanged = updateTTSVoices;
    updateTTSVoices();
}

// Status OCR (Tahap 7D)
let ocrWorker = null;

// =============================================================================
// 4. ELEMEN DOM / ANTARMUKA HTML
// =============================================================================
const fileInput = document.getElementById('file-input');
const fileMergeInput = document.getElementById('file-merge-input');
const btnOpenTop = document.getElementById('btn-open-top');
const btnOpenMain = document.getElementById('btn-open-main');
const emptyState = document.getElementById('empty-state');
const canvasWrapper = document.getElementById('canvas-wrapper');
const appFooter = document.getElementById('app-footer');
const canvas = document.getElementById('pdf-canvas');
const ctx = canvas.getContext('2d');
const annoCanvas = document.getElementById('annotation-canvas');
const annoCtx = annoCanvas.getContext('2d');

const pageLabel = document.getElementById('page-label');
const zoomLabel = document.getElementById('zoom-label');
const docTitle = document.getElementById('doc-title');
const loadingBadge = document.getElementById('loading-badge');
const btnTheme = document.getElementById('btn-theme');
const toastMsg = document.getElementById('toast-msg');
const btnFullscreen = document.getElementById('btn-fullscreen');

// TTS
const btnTtsToggle = document.getElementById('btn-tts-toggle');
const ttsPlayerBar = document.getElementById('tts-player-bar');
const ttsStatusText = document.getElementById('tts-status-text');
const btnTtsPlayPause = document.getElementById('btn-tts-playpause');
const btnTtsStop = document.getElementById('btn-tts-stop');
const btnTtsSpeed = document.getElementById('btn-tts-speed');
const btnTtsLang = document.getElementById('btn-tts-lang');

const ttsGuideModal = document.getElementById('tts-guide-modal');
const ttsGuideBackdrop = document.getElementById('tts-guide-backdrop');
const btnCloseTtsGuide = document.getElementById('btn-close-tts-guide');
const btnOkTtsGuide = document.getElementById('btn-ok-tts-guide');

// OCR Elemen (Tahap 7D)
const ocrModal = document.getElementById('ocr-modal');
const ocrBackdrop = document.getElementById('ocr-backdrop');
const btnCloseOcrModal = document.getElementById('btn-close-ocr-modal');
const btnCloseOcr = document.getElementById('btn-close-ocr');
const selectOcrLang = document.getElementById('select-ocr-lang');
const btnRunOcr = document.getElementById('btn-run-ocr');
const ocrProgressContainer = document.getElementById('ocr-progress-container');
const ocrProgressBar = document.getElementById('ocr-progress-bar');
const ocrProgressText = document.getElementById('ocr-progress-text');
const ocrResultText = document.getElementById('ocr-result-text');
const btnOcrCopy = document.getElementById('btn-ocr-copy');
const btnOcrSpeak = document.getElementById('btn-ocr-speak');

const ocrGuideModal = document.getElementById('ocr-guide-modal');
const ocrGuideBackdrop = document.getElementById('ocr-guide-backdrop');
const btnCloseOcrGuide = document.getElementById('btn-close-ocr-guide');
const btnOkOcrGuide = document.getElementById('btn-ok-ocr-guide');

// Navigasi & Pencarian
const btnSearchToggle = document.getElementById('btn-search-toggle');
const searchBar = document.getElementById('search-bar');
const searchInput = document.getElementById('search-input');
const searchStatus = document.getElementById('search-status');
const btnSearchPrev = document.getElementById('btn-search-prev');
const btnSearchNext = document.getElementById('btn-search-next');
const btnSearchClose = document.getElementById('btn-search-close');
const btnBookmark = document.getElementById('btn-bookmark');

// Anotasi
const btnAnnoToggle = document.getElementById('btn-anno-toggle');
const annoToolbar = document.getElementById('annotation-toolbar');
const toolPen = document.getElementById('tool-pen');
const toolHighlighter = document.getElementById('tool-highlighter');
const toolEraser = document.getElementById('tool-eraser');
const toolText = document.getElementById('tool-text');
const btnAnnoUndo = document.getElementById('btn-anno-undo');
const btnAnnoRedo = document.getElementById('btn-anno-redo');
const btnAnnoClear = document.getElementById('btn-anno-clear');
const btnAnnoDone = document.getElementById('btn-anno-done');
const colorDots = document.querySelectorAll('.color-dot');

// Modal Editor Teks
const textEditorModal = document.getElementById('text-editor-modal');
const textEditorBackdrop = document.getElementById('text-editor-backdrop');
const btnCloseTextModal = document.getElementById('btn-close-text-modal');
const annotationTextInput = document.getElementById('annotation-text-input');
const btnToggleDirection = document.getElementById('btn-toggle-direction');
const btnAlignRight = document.getElementById('btn-align-right');
const btnAlignCenter = document.getElementById('btn-align-center');
const btnAlignLeft = document.getElementById('btn-align-left');
const selectFontSize = document.getElementById('select-font-size');
const btnCancelText = document.getElementById('btn-cancel-text');
const btnSaveText = document.getElementById('btn-save-text');

// Alat Pengolah PDF
const btnToolsToggle = document.getElementById('btn-tools-toggle');
const toolsBackdrop = document.getElementById('tools-backdrop');
const toolsModal = document.getElementById('tools-modal');
const btnCloseTools = document.getElementById('btn-close-tools');
const toolOcrPage = document.getElementById('tool-ocr-page');
const toolCopyText = document.getElementById('tool-copy-text');
const toolExportText = document.getElementById('tool-export-text');
const toolRotatePage = document.getElementById('tool-rotate-page');
const toolDeletePage = document.getElementById('tool-delete-page');
const toolExtractPage = document.getElementById('tool-extract-page');
const toolExportImage = document.getElementById('tool-export-image');
const toolMergePdf = document.getElementById('tool-merge-pdf');
const toolDownloadPdf = document.getElementById('tool-download-pdf');

// Drawer
const btnMenu = document.getElementById('btn-menu');
const appDrawer = document.getElementById('app-drawer');
const drawerBackdrop = document.getElementById('drawer-backdrop');
const btnCloseDrawer = document.getElementById('btn-close-drawer');
const bookmarkList = document.getElementById('bookmark-list');
const historyList = document.getElementById('history-list');

// =============================================================================
// 5. SISTEM TEMA & LAYAR PENUH
// =============================================================================
const themes = ['light-mode', 'sepia-mode', 'dark-mode'];
const themeIcons = ['☀️', '📜', '🌙'];
let currentThemeIndex = 0;

btnTheme.addEventListener('click', () => {
    document.body.classList.remove(themes[currentThemeIndex]);
    currentThemeIndex = (currentThemeIndex + 1) % themes.length;
    document.body.classList.add(themes[currentThemeIndex]);
    btnTheme.textContent = themeIcons[currentThemeIndex];
    showToast(`Tema: ${themes[currentThemeIndex].replace('-mode', '').toUpperCase()}`);
});

function showToast(text) {
    toastMsg.textContent = text;
    toastMsg.style.display = 'block';
    setTimeout(() => { toastMsg.style.display = 'none'; }, 2400);
}

btnFullscreen.addEventListener('click', () => {
    if (!document.fullscreenElement) {
        document.documentElement.requestFullscreen().catch(() => {});
        btnFullscreen.textContent = "✕";
    } else {
        document.exitFullscreen().catch(() => {});
        btnFullscreen.textContent = "⛶";
    }
});

// =============================================================================
// 6. BUKA DOKUMEN PDF
// =============================================================================
btnOpenTop.addEventListener('click', () => fileInput.click());
btnOpenMain.addEventListener('click', () => fileInput.click());

fileInput.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file || file.type !== 'application/pdf') {
        alert('Harap pilih file PDF yang valid.');
        return;
    }

    currentFileName = file.name;
    currentFileSize = (file.size / (1024 * 1024)).toFixed(2) + " MB";
    currentFileKey = `pdf_${file.name}_${file.size}`;
    docTitle.textContent = file.name;
    loadingBadge.style.display = 'block';

    const reader = new FileReader();
    reader.onload = function(event) {
        currentPDFBytes = new Uint8Array(event.target.result);
        loadPDF(currentPDFBytes);
    };
    reader.readAsArrayBuffer(file);
});

function loadPDF(data) {
    return pdfjsLib.getDocument({ data: data }).promise.then((pdf) => {
        pdfDoc = pdf;
        emptyState.style.display = 'none';
        canvasWrapper.style.display = 'flex';
        appFooter.style.display = 'flex';
        btnSearchToggle.style.display = 'flex';
        btnBookmark.style.display = 'flex';
        btnAnnoToggle.style.display = 'flex';
        btnToolsToggle.style.display = 'flex';
        btnTtsToggle.style.display = 'flex';
        btnFullscreen.style.display = 'flex';
        loadingBadge.style.display = 'none';

        const savedPage = localStorage.getItem(`${currentFileKey}_last_page`);
        pageNum = (!savedPage || parseInt(savedPage) > pdfDoc.numPages) ? 1 : parseInt(savedPage);

        loadSavedAnnotations();
        saveToHistory(currentFileName, currentFileSize, pdfDoc.numPages);
        renderPage(pageNum);
        updateBookmarkButton();
    }).catch((err) => {
        loadingBadge.style.display = 'none';
        alert('Gagal memuat dokumen: ' + err.message);
    });
}

// =============================================================================
// 7. RENDER HALAMAN KE KANVAS
// =============================================================================
function renderPage(num) {
    pageRendering = true;

    pdfDoc.getPage(num).then((page) => {
        const pixelRatio = window.devicePixelRatio || 1;
        const viewport = page.getViewport({ scale: scale });

        const canvasW = Math.floor(viewport.width * pixelRatio);
        const canvasH = Math.floor(viewport.height * pixelRatio);

        canvas.height = canvasW ? canvasH : 100;
        canvas.width = canvasW;
        canvas.style.width = Math.floor(viewport.width) + 'px';
        canvas.style.height = Math.floor(viewport.height) + 'px';

        annoCanvas.height = canvas.height;
        annoCanvas.width = canvas.width;
        annoCanvas.style.width = canvas.style.width;
        annoCanvas.style.height = canvas.style.height;

        const renderContext = {
            canvasContext: ctx,
            viewport: viewport,
            transform: pixelRatio !== 1 ? [pixelRatio, 0, 0, pixelRatio, 0, 0] : null
        };

        const renderTask = page.render(renderContext);

        renderTask.promise.then(() => {
            pageRendering = false;
            redrawAnnotations();

            if (pageNumPending !== null) {
                renderPage(pageNumPending);
                pageNumPending = null;
            }
        });

        if (currentFileKey) {
            localStorage.setItem(`${currentFileKey}_last_page`, num);
        }

        pageLabel.textContent = `${num} / ${pdfDoc.numPages}`;
        zoomLabel.textContent = `${Math.round(scale * 100)}%`;
        updateBookmarkButton();
        document.getElementById('viewer-container').scrollTop = 0;
    });
}

function queueRenderPage(num) {
    if (pageRendering) {
        pageNumPending = num;
    } else {
        renderPage(num);
    }
}

// =============================================================================
// 8. NAVIGASI HALAMAN & ZOOM
// =============================================================================
document.getElementById('btn-prev').addEventListener('click', () => {
    if (pageNum <= 1) return;
    pageNum--;
    stopTTS();
    queueRenderPage(pageNum);
});

document.getElementById('btn-next').addEventListener('click', () => {
    if (!pdfDoc || pageNum >= pdfDoc.numPages) return;
    pageNum++;
    stopTTS();
    queueRenderPage(pageNum);
});

pageLabel.addEventListener('click', () => {
    if (!pdfDoc) return;
    const target = prompt(`Lompat ke halaman (1 - ${pdfDoc.numPages}):`, pageNum);
    const targetPage = parseInt(target);
    if (targetPage >= 1 && targetPage <= pdfDoc.numPages) {
        pageNum = targetPage;
        stopTTS();
        queueRenderPage(pageNum);
    }
});

document.getElementById('btn-zoom-in').addEventListener('click', () => {
    if (!pdfDoc || scale >= 2.5) return;
    scale = +(scale + 0.2).toFixed(1);
    queueRenderPage(pageNum);
});

document.getElementById('btn-zoom-out').addEventListener('click', () => {
    if (!pdfDoc || scale <= 0.6) return;
    scale = +(scale - 0.2).toFixed(1);
    queueRenderPage(pageNum);
});

// =============================================================================
// 9. PENCARIAN TEKS DENGAN NORMALISASI HARAKAT ARAB
// =============================================================================
btnSearchToggle.addEventListener('click', () => {
    const isShowing = searchBar.style.display === 'flex';
    searchBar.style.display = isShowing ? 'none' : 'flex';
    if (!isShowing) searchInput.focus();
});

btnSearchClose.addEventListener('click', () => {
    searchBar.style.display = 'none';
    clearSearch();
});

function clearSearch() {
    searchMatches = [];
    currentSearchIndex = -1;
    searchStatus.textContent = '0/0';
    activeSearchToken++;
}

searchInput.addEventListener('input', () => {
    clearTimeout(searchTimeout);
    const rawQuery = searchInput.value.trim();

    if (!rawQuery || !pdfDoc) {
        clearSearch();
        return;
    }

    searchStatus.textContent = 'Mencari...';
    searchTimeout = setTimeout(() => {
        executeSearch(rawQuery);
    }, 400);
});

async function executeSearch(rawQuery) {
    const currentToken = ++activeSearchToken;
    searchMatches = [];
    currentSearchIndex = -1;

    const isArabic = isArabicText(rawQuery);
    const normalizedQuery = isArabic ? normalizeArabic(rawQuery) : rawQuery.toLowerCase();

    try {
        for (let i = 1; i <= pdfDoc.numPages; i++) {
            if (currentToken !== activeSearchToken) return;

            const page = await pdfDoc.getPage(i);
            const textContent = await page.getTextContent();
            let pageText = textContent.items.map(item => item.str || '').join(' ');

            const searchSource = isArabic ? normalizeArabic(pageText) : pageText.toLowerCase();

            if (searchSource.includes(normalizedQuery)) {
                searchMatches.push(i);
            }
        }

        if (currentToken !== activeSearchToken) return;

        if (searchMatches.length > 0) {
            currentSearchIndex = 0;
            searchStatus.textContent = `1/${searchMatches.length}`;
            pageNum = searchMatches[0];
            queueRenderPage(pageNum);
            showToast(`Ditemukan di ${searchMatches.length} halaman`);
        } else {
            searchStatus.textContent = '0/0';
            showToast('Teks tidak ditemukan');
        }
    } catch (e) {
        searchStatus.textContent = '0/0';
    }
}

btnSearchNext.addEventListener('click', () => {
    if (searchMatches.length === 0) return;
    currentSearchIndex = (currentSearchIndex + 1) % searchMatches.length;
    searchStatus.textContent = `${currentSearchIndex + 1}/${searchMatches.length}`;
    pageNum = searchMatches[currentSearchIndex];
    queueRenderPage(pageNum);
});

btnSearchPrev.addEventListener('click', () => {
    if (searchMatches.length === 0) return;
    currentSearchIndex = (currentSearchIndex - 1 + searchMatches.length) % searchMatches.length;
    searchStatus.textContent = `${currentSearchIndex + 1}/${searchMatches.length}`;
    pageNum = searchMatches[currentSearchIndex];
    queueRenderPage(pageNum);
});

// =============================================================================
// 10. SISTEM ANOTASI & EDITOR TEKS ARAB
// =============================================================================
btnAnnoToggle.addEventListener('click', toggleAnnotationMode);
btnAnnoDone.addEventListener('click', toggleAnnotationMode);

function toggleAnnotationMode() {
    isAnnotationMode = !isAnnotationMode;
    document.body.classList.toggle('annotating', isAnnotationMode);
    annoToolbar.style.display = isAnnotationMode ? 'flex' : 'none';
    btnAnnoToggle.textContent = isAnnotationMode ? '❌' : '✏️';

    if (isAnnotationMode) {
        showToast('Mode anotasi aktif. Coret atau ketik teks.');
    } else {
        saveAnnotationsToStorage();
        showToast('Anotasi disimpan.');
    }
}

const toolButtons = [toolPen, toolHighlighter, toolEraser, toolText];
function setActiveTool(tool, button) {
    currentTool = tool;
    toolButtons.forEach(btn => btn.classList.remove('active'));
    button.classList.add('active');
}

toolPen.addEventListener('click', () => setActiveTool('pen', toolPen));
toolHighlighter.addEventListener('click', () => setActiveTool('highlighter', toolHighlighter));
toolEraser.addEventListener('click', () => setActiveTool('eraser', toolEraser));
toolText.addEventListener('click', () => setActiveTool('text', toolText));

colorDots.forEach(dot => {
    dot.addEventListener('click', () => {
        colorDots.forEach(d => d.classList.remove('active'));
        dot.classList.add('active');
        currentColor = dot.getAttribute('data-color');
    });
});

function getNormalizedCoords(e) {
    const rect = annoCanvas.getBoundingClientRect();
    const touch = (e.touches && e.touches.length > 0) 
        ? e.touches[0] 
        : ((e.changedTouches && e.changedTouches.length > 0) ? e.changedTouches[0] : e);

    const canvasX = (touch.clientX - rect.left) * (annoCanvas.width / rect.width);
    const canvasY = (touch.clientY - rect.top) * (annoCanvas.height / rect.height);

    return {
        nx: canvasX / annoCanvas.width,
        ny: canvasY / annoCanvas.height
    };
}

annoCanvas.addEventListener('touchstart', onDrawStart, { passive: false });
annoCanvas.addEventListener('touchmove', onDrawMove, { passive: false });
annoCanvas.addEventListener('touchend', onDrawEnd, { passive: false });

annoCanvas.addEventListener('mousedown', onDrawStart);
annoCanvas.addEventListener('mousemove', onDrawMove);
annoCanvas.addEventListener('mouseup', onDrawEnd);

function onDrawStart(e) {
    if (!isAnnotationMode) return;
    e.preventDefault();

    const pos = getNormalizedCoords(e);

    if (currentTool === 'text') {
        openTextEditorModal(pos);
        return;
    }

    isDrawing = true;
    currentStroke = {
        type: currentTool,
        color: currentColor,
        size: currentTool === 'highlighter' ? 24 : (currentTool === 'eraser' ? 26 : 3.5),
        points: [pos]
    };

    drawSegment(pos, pos, currentStroke);
}

function onDrawMove(e) {
    if (!isDrawing || !isAnnotationMode) return;
    e.preventDefault();

    const pos = getNormalizedCoords(e);
    const prevPos = currentStroke.points[currentStroke.points.length - 1];
    currentStroke.points.push(pos);

    drawSegment(prevPos, pos, currentStroke);
}

function onDrawEnd(e) {
    if (!isDrawing) return;
    isDrawing = false;

    if (currentStroke && currentStroke.points.length > 0) {
        initPageAnnoData();
        pageAnnotations[pageNum].strokes.push(currentStroke);
        pageAnnotations[pageNum].redo = [];
        saveAnnotationsToStorage();
    }
    currentStroke = null;
}

function drawSegment(p1, p2, stroke) {
    annoCtx.save();
    annoCtx.lineCap = 'round';
    annoCtx.lineJoin = 'round';

    const renderW = annoCanvas.width;
    const baseWidth = stroke.size * (renderW / 600);
    annoCtx.lineWidth = Math.max(1, baseWidth);

    if (stroke.type === 'eraser') {
        annoCtx.globalCompositeOperation = 'destination-out';
        annoCtx.strokeStyle = 'rgba(0,0,0,1)';
    } else if (stroke.type === 'highlighter') {
        annoCtx.globalCompositeOperation = 'source-over';
        annoCtx.strokeStyle = stroke.color;
        annoCtx.globalAlpha = 0.35;
    } else {
        annoCtx.globalCompositeOperation = 'source-over';
        annoCtx.strokeStyle = stroke.color;
        annoCtx.globalAlpha = 1.0;
    }

    annoCtx.beginPath();
    annoCtx.moveTo(p1.nx * annoCanvas.width, p1.ny * annoCanvas.height);
    annoCtx.lineTo(p2.nx * annoCanvas.width, p2.ny * annoCanvas.height);
    annoCtx.stroke();
    annoCtx.restore();
}

function initPageAnnoData() {
    if (!pageAnnotations[pageNum]) {
        pageAnnotations[pageNum] = { strokes: [], redo: [] };
    }
}

function redrawAnnotations() {
    annoCtx.clearRect(0, 0, annoCanvas.width, annoCanvas.height);
    const pageData = pageAnnotations[pageNum];
    if (!pageData || !pageData.strokes) return;

    pageData.strokes.forEach(stroke => {
        if (stroke.type === 'text') {
            annoCtx.save();
            const fontSize = Math.floor((stroke.fontSize || 22) * (annoCanvas.width / 600));
            annoCtx.font = `${fontSize}px 'Noto Naskh Arabic', 'Amiri', 'Scheherazade New', 'Noto Sans Arabic', 'Segoe UI', Tahoma, sans-serif`;
            annoCtx.fillStyle = stroke.color || '#000000';
            annoCtx.direction = stroke.direction || 'rtl';
            annoCtx.textAlign = stroke.align || 'right';

            const lines = (stroke.text || '').split('\n');
            const lineHeight = fontSize * 1.5;

            lines.forEach((line, index) => {
                annoCtx.fillText(
                    line, 
                    stroke.nx * annoCanvas.width, 
                    (stroke.ny * annoCanvas.height) + (index * lineHeight)
                );
            });
            annoCtx.restore();
        } else if (stroke.points && stroke.points.length > 1) {
            for (let i = 1; i < stroke.points.length; i++) {
                drawSegment(stroke.points[i - 1], stroke.points[i], stroke);
            }
        }
    });
}

function openTextEditorModal(pos) {
    pendingTextPos = pos;
    annotationTextInput.value = '';
    currentTextDirection = 'rtl';
    currentTextAlign = 'right';
    annotationTextInput.dir = 'rtl';
    btnToggleDirection.textContent = '⇄ RTL';

    setAlignButtonsActive(btnAlignRight);
    textEditorBackdrop.style.display = 'block';
    textEditorModal.style.display = 'flex';
    setTimeout(() => annotationTextInput.focus(), 100);
}

function closeTextEditorModal() {
    textEditorBackdrop.style.display = 'none';
    textEditorModal.style.display = 'none';
    pendingTextPos = null;
}

btnToggleDirection.addEventListener('click', () => {
    currentTextDirection = (currentTextDirection === 'rtl') ? 'ltr' : 'rtl';
    annotationTextInput.dir = currentTextDirection;
    btnToggleDirection.textContent = (currentTextDirection === 'rtl') ? '⇄ RTL' : '⇄ LTR';
    if (currentTextDirection === 'rtl') {
        currentTextAlign = 'right';
        setAlignButtonsActive(btnAlignRight);
    } else {
        currentTextAlign = 'left';
        setAlignButtonsActive(btnAlignLeft);
    }
});

function setAlignButtonsActive(activeBtn) {
    [btnAlignRight, btnAlignCenter, btnAlignLeft].forEach(b => b.classList.remove('active'));
    activeBtn.classList.add('active');
}

btnAlignRight.addEventListener('click', () => {
    currentTextAlign = 'right';
    setAlignButtonsActive(btnAlignRight);
});
btnAlignCenter.addEventListener('click', () => {
    currentTextAlign = 'center';
    setAlignButtonsActive(btnAlignCenter);
});
btnAlignLeft.addEventListener('click', () => {
    currentTextAlign = 'left';
    setAlignButtonsActive(btnAlignLeft);
});

btnCloseTextModal.addEventListener('click', closeTextEditorModal);
btnCancelText.addEventListener('click', closeTextEditorModal);

btnSaveText.addEventListener('click', () => {
    const textVal = annotationTextInput.value.trim();
    if (!textVal || !pendingTextPos) {
        closeTextEditorModal();
        return;
    }

    initPageAnnoData();
    pageAnnotations[pageNum].strokes.push({
        type: 'text',
        nx: pendingTextPos.nx,
        ny: pendingTextPos.ny,
        text: textVal,
        color: currentColor,
        fontSize: parseInt(selectFontSize.value, 10),
        align: currentTextAlign,
        direction: currentTextDirection
    });

    pageAnnotations[pageNum].redo = [];
    redrawAnnotations();
    saveAnnotationsToStorage();
    closeTextEditorModal();
    showToast('Teks berhasil ditempelkan.');
});

btnAnnoUndo.addEventListener('click', () => {
    initPageAnnoData();
    const data = pageAnnotations[pageNum];
    if (data.strokes.length > 0) {
        data.redo.push(data.strokes.pop());
        redrawAnnotations();
        saveAnnotationsToStorage();
    }
});

btnAnnoRedo.addEventListener('click', () => {
    initPageAnnoData();
    const data = pageAnnotations[pageNum];
    if (data.redo.length > 0) {
        data.strokes.push(data.redo.pop());
        redrawAnnotations();
        saveAnnotationsToStorage();
    }
});

btnAnnoClear.addEventListener('click', () => {
    initPageAnnoData();
    if (confirm('Hapus seluruh anotasi di halaman ini?')) {
        pageAnnotations[pageNum].strokes = [];
        pageAnnotations[pageNum].redo = [];
        redrawAnnotations();
        saveAnnotationsToStorage();
    }
});

function saveAnnotationsToStorage() {
    if (!currentFileKey) return;
    try {
        localStorage.setItem(`${currentFileKey}_annotations`, JSON.stringify(pageAnnotations));
    } catch (e) {}
}

function loadSavedAnnotations() {
    if (!currentFileKey) return;
    const saved = localStorage.getItem(`${currentFileKey}_annotations`);
    pageAnnotations = saved ? JSON.parse(saved) : {};
}

// =============================================================================
// 11. PENGOLAH PDF, TEKS, & OCR LURING (TAHAP 7D)
// =============================================================================
btnToolsToggle.addEventListener('click', () => {
    toolsModal.style.display = 'block';
    toolsBackdrop.style.display = 'block';
});

function closeToolsModal() {
    toolsModal.style.display = 'none';
    toolsBackdrop.style.display = 'none';
}

btnCloseTools.addEventListener('click', closeToolsModal);
toolsBackdrop.addEventListener('click', closeToolsModal);

function checkPDFLibReady() {
    if (!window.PDFLib) {
        alert("PENTING: File 'pdf-lib.min.js' belum ada di folder PDFReader.");
        return false;
    }
    if (!currentPDFBytes) {
        alert("Buka file PDF terlebih dahulu.");
        return false;
    }
    return true;
}

function downloadBlob(data, fileName, mimeType) {
    const blob = data instanceof Blob ? data : new Blob([data], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }, 1500);
}

// --- Integrasi OCR Bahasa Arab & Latin Luring (Tahap 7D) ---
toolOcrPage.addEventListener('click', () => {
    if (!pdfDoc) {
        alert("Buka file PDF terlebih dahulu.");
        return;
    }
    closeToolsModal();

    // Periksa apakah pustaka Tesseract terpasang
    if (!window.Tesseract) {
        ocrGuideBackdrop.style.display = 'block';
        ocrGuideModal.style.display = 'flex';
        return;
    }

    // Buka antarmuka OCR
    ocrResultText.value = '';
    ocrProgressContainer.style.display = 'none';
    ocrBackdrop.style.display = 'block';
    ocrModal.style.display = 'flex';
});

function closeOcrModal() {
    ocrBackdrop.style.display = 'none';
    ocrModal.style.display = 'none';
}

btnCloseOcrModal.addEventListener('click', closeOcrModal);
btnCloseOcr.addEventListener('click', closeOcrModal);

btnCloseOcrGuide.addEventListener('click', () => {
    ocrGuideBackdrop.style.display = 'none';
    ocrGuideModal.style.display = 'none';
});
btnOkOcrGuide.addEventListener('click', () => {
    ocrGuideBackdrop.style.display = 'none';
    ocrGuideModal.style.display = 'none';
});

// Jalankan Pemrosesan OCR pada Halaman Aktif
btnRunOcr.addEventListener('click', async () => {
    const selectedLang = selectOcrLang.value;
    ocrProgressContainer.style.display = 'flex';
    ocrProgressBar.style.width = '0%';
    ocrProgressText.textContent = 'Menyiapkan kanvas & memproses kontras...';
    btnRunOcr.disabled = true;

    try {
        // Buat kanvas biner grayscale untuk mengoptimalkan ketajaman tulisan Arab
        const ocrCanvas = document.createElement('canvas');
        ocrCanvas.width = canvas.width;
        ocrCanvas.height = canvas.height;
        const ocrCtx = ocrCanvas.getContext('2d');
        ocrCtx.drawImage(canvas, 0, 0);

        // Prapemrosesan gambar (Thresholding hitam-putih agar titik harakat terbaca jelas)
        const imgData = ocrCtx.getImageData(0, 0, ocrCanvas.width, ocrCanvas.height);
        const d = imgData.data;
        for (let i = 0; i < d.length; i += 4) {
            const avg = (d[i] + d[i + 1] + d[i + 2]) / 3;
            const threshold = avg < 140 ? 0 : 255;
            d[i] = d[i + 1] = d[i + 2] = threshold;
        }
        ocrCtx.putImageData(imgData, 0, 0);

        // Inisialisasi Tesseract Luring
        const worker = await Tesseract.createWorker({
            workerPath: 'libs/tesseract/worker.min.js',
            corePath: 'libs/tesseract/tesseract-core.wasm.js',
            langPath: 'libs/tesseract/',
            logger: m => {
                if (m.status === 'recognizing text') {
                    const percent = Math.floor((m.progress || 0) * 100);
                    ocrProgressBar.style.width = `${percent}%`;
                    ocrProgressText.textContent = `Memindai teks: ${percent}%`;
                } else {
                    ocrProgressText.textContent = m.status;
                }
            }
        });

        await worker.loadLanguage(selectedLang);
        await worker.initialize(selectedLang);
        const result = await worker.recognize(ocrCanvas);
        await worker.terminate();

        const recognized = result.data.text.trim();
        ocrResultText.value = recognized || "Tidak ditemukan teks yang dapat dikenali pada halaman ini.";
        ocrProgressContainer.style.display = 'none';
        btnRunOcr.disabled = false;
        showToast("Proses OCR selesai.");
    } catch (err) {
        ocrProgressContainer.style.display = 'none';
        btnRunOcr.disabled = false;
        alert("Gagal memproses OCR luring: " + (err.message || "Pastikan berkas model bahasa Tesseract tersedia di folder libs/tesseract/"));
    }
});

btnOcrCopy.addEventListener('click', async () => {
    const text = ocrResultText.value.trim();
    if (!text) return;
    if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(text);
        showToast("Teks OCR berhasil disalin!");
    } else {
        prompt("Salin teks OCR:", text);
    }
});

btnOcrSpeak.addEventListener('click', () => {
    const text = ocrResultText.value.trim();
    if (!text) return;
    closeOcrModal();
    ttsPlayerBar.style.display = 'flex';
    ttsStatusText.textContent = "Membaca teks hasil OCR...";
    window.speechSynthesis.cancel();

    const targetLang = isArabicText(text) ? 'ar-SA' : 'id-ID';
    ttsUtterance = new SpeechSynthesisUtterance(text);
    ttsUtterance.rate = ttsSpeeds[ttsSpeedIndex];
    ttsUtterance.lang = targetLang;

    const matchedVoice = availableVoices.find(v => v.lang.toLowerCase().startsWith(targetLang.substring(0, 2)));
    if (matchedVoice) ttsUtterance.voice = matchedVoice;

    window.speechSynthesis.speak(ttsUtterance);
});

// Alat Pengolah PDF Lainnya
toolCopyText.addEventListener('click', async () => {
    if (!pdfDoc) return;
    closeToolsModal();
    loadingBadge.style.display = 'block';

    try {
        const page = await pdfDoc.getPage(pageNum);
        const textContent = await page.getTextContent();
        const text = textContent.items.map(item => item.str || '').join(' ').trim();
        loadingBadge.style.display = 'none';

        if (!text) {
            alert("Tidak ada teks yang dapat disalin pada halaman ini.");
            return;
        }

        if (navigator.clipboard && navigator.clipboard.writeText) {
            await navigator.clipboard.writeText(text);
            showToast("Teks halaman berhasil disalin!");
        } else {
            prompt("Salin teks berikut secara manual:", text);
        }
    } catch (e) {
        loadingBadge.style.display = 'none';
        alert("Gagal menyalin teks: " + e.message);
    }
});

toolExportText.addEventListener('click', async () => {
    if (!pdfDoc) return;
    closeToolsModal();
    loadingBadge.style.display = 'block';

    try {
        let fullText = `=== EKSTRAKSI TEKS DOKUMEN: ${currentFileName} ===\n\n`;
        for (let i = 1; i <= pdfDoc.numPages; i++) {
            loadingBadge.textContent = `Mengekstrak ${i}/${pdfDoc.numPages}...`;
            const page = await pdfDoc.getPage(i);
            const textContent = await page.getTextContent();
            const pageText = textContent.items.map(item => item.str || '').join(' ').trim();
            fullText += `--- Halaman ${i} ---\n${pageText}\n\n`;
        }

        loadingBadge.style.display = 'none';
        loadingBadge.textContent = 'Memuat...';
        const baseName = currentFileName.replace(/\.pdf$/i, '');
        downloadBlob(fullText, `${baseName}_teks.txt`, 'text/plain;charset=utf-8');
        showToast("File teks .txt berhasil diunduh.");
    } catch (e) {
        loadingBadge.style.display = 'none';
        alert("Gagal mengekstrak teks: " + e.message);
    }
});

toolRotatePage.addEventListener('click', async () => {
    if (!checkPDFLibReady()) return;
    closeToolsModal();
    loadingBadge.style.display = 'block';

    try {
        const { PDFDocument, degrees } = PDFLib;
        const pdfDocLib = await PDFDocument.load(currentPDFBytes);
        const page = pdfDocLib.getPage(pageNum - 1);
        const currentRotation = page.getRotation().angle;
        page.setRotation(degrees((currentRotation + 90) % 360));

        currentPDFBytes = await pdfDocLib.save();
        await loadPDF(currentPDFBytes);
        showToast(`Halaman ${pageNum} diputar 90°`);
    } catch (err) {
        loadingBadge.style.display = 'none';
        alert("Gagal memutar halaman: " + err.message);
    }
});

toolDeletePage.addEventListener('click', async () => {
    if (!checkPDFLibReady()) return;
    if (pdfDoc.numPages <= 1) {
        alert("Dokumen hanya memiliki 1 halaman, tidak dapat dihapus.");
        return;
    }

    if (!confirm(`Hapus halaman ${pageNum} secara permanen dari dokumen ini?`)) return;

    closeToolsModal();
    loadingBadge.style.display = 'block';

    try {
        const { PDFDocument } = PDFLib;
        const pdfDocLib = await PDFDocument.load(currentPDFBytes);
        pdfDocLib.removePage(pageNum - 1);

        currentPDFBytes = await pdfDocLib.save();
        if (pageNum > pdfDocLib.getPageCount()) {
            pageNum = pdfDocLib.getPageCount();
        }
        await loadPDF(currentPDFBytes);
        showToast("Halaman berhasil dihapus.");
    } catch (err) {
        loadingBadge.style.display = 'none';
        alert("Gagal menghapus halaman: " + err.message);
    }
});

toolExtractPage.addEventListener('click', async () => {
    if (!checkPDFLibReady()) return;
    closeToolsModal();
    loadingBadge.style.display = 'block';

    try {
        const { PDFDocument } = PDFLib;
        const sourceDoc = await PDFDocument.load(currentPDFBytes);
        const newDoc = await PDFDocument.create();

        const [extractedPage] = await newDoc.copyPages(sourceDoc, [pageNum - 1]);
        newDoc.addPage(extractedPage);

        const newPdfBytes = await newDoc.save();
        const baseName = currentFileName.replace(/\.pdf$/i, '');
        downloadBlob(newPdfBytes, `${baseName}_hal_${pageNum}.pdf`, 'application/pdf');
        loadingBadge.style.display = 'none';
        showToast(`Halaman ${pageNum} diekstrak ke PDF baru.`);
    } catch (err) {
        loadingBadge.style.display = 'none';
        alert("Gagal mengekstrak halaman: " + err.message);
    }
});

toolExportImage.addEventListener('click', () => {
    if (!pdfDoc) {
        alert("Buka file PDF terlebih dahulu.");
        return;
    }
    if (canvas.width === 0 || canvas.height === 0) {
        alert("Tunggu hingga halaman selesai dimuat.");
        return;
    }
    closeToolsModal();
    loadingBadge.style.display = 'block';

    try {
        const exportCanvas = document.createElement('canvas');
        exportCanvas.width = canvas.width;
        exportCanvas.height = canvas.height;
        const exportCtx = exportCanvas.getContext('2d');

        exportCtx.fillStyle = '#ffffff';
        exportCtx.fillRect(0, 0, exportCanvas.width, exportCanvas.height);
        exportCtx.drawImage(canvas, 0, 0);
        exportCtx.drawImage(annoCanvas, 0, 0);

        exportCanvas.toBlob((blob) => {
            loadingBadge.style.display = 'none';
            if (blob) {
                const baseName = currentFileName.replace(/\.pdf$/i, '');
                downloadBlob(blob, `${baseName}_hal_${pageNum}.png`, 'image/png');
                showToast(`Halaman ${pageNum} disimpan sebagai PNG.`);
            } else {
                alert("Gagal membuat gambar dari kanvas.");
            }
        }, 'image/png');
    } catch (err) {
        loadingBadge.style.display = 'none';
        alert("Gagal mengekspor gambar: " + err.message);
    }
});

toolMergePdf.addEventListener('click', () => {
    if (!checkPDFLibReady()) return;
    closeToolsModal();
    fileMergeInput.value = '';
    fileMergeInput.click();
});

fileMergeInput.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file || file.type !== 'application/pdf') {
        alert('Pilih file PDF yang valid untuk digabungkan.');
        return;
    }

    loadingBadge.style.display = 'block';
    const reader = new FileReader();
    reader.onload = async function(event) {
        try {
            const secondPdfBytes = new Uint8Array(event.target.result);
            const { PDFDocument } = PDFLib;

            const mainDoc = await PDFDocument.load(currentPDFBytes);
            const secondDoc = await PDFDocument.load(secondPdfBytes);

            const copiedPages = await mainDoc.copyPages(secondDoc, secondDoc.getPageIndices());
            copiedPages.forEach(p => mainDoc.addPage(p));

            currentPDFBytes = await mainDoc.save();
            await loadPDF(currentPDFBytes);
            showToast(`Berhasil menggabungkan ${file.name}`);
        } catch (err) {
            loadingBadge.style.display = 'none';
            alert("Gagal menggabungkan PDF: " + err.message);
        }
    };
    reader.readAsArrayBuffer(file);
});

toolDownloadPdf.addEventListener('click', () => {
    if (!checkPDFLibReady()) return;
    closeToolsModal();
    const downloadName = `edit_${currentFileName}`;
    downloadBlob(currentPDFBytes, downloadName, 'application/pdf');
    showToast("Mengunduh salinan file PDF...");
});

// =============================================================================
// 12. TEXT-TO-SPEECH (TTS)
// =============================================================================
btnTtsToggle.addEventListener('click', async () => {
    if (!pdfDoc) return;
    if (ttsPlayerBar.style.display === 'flex') {
        stopTTS();
    } else {
        ttsPlayerBar.style.display = 'flex';
        await startReadingCurrentPage();
    }
});

btnTtsLang.addEventListener('click', () => {
    if (ttsLanguageMode === 'auto') {
        ttsLanguageMode = 'ar';
        btnTtsLang.textContent = '🌐 Arab';
        showToast('Bahasa Suara: Bahasa Arab');
    } else if (ttsLanguageMode === 'ar') {
        ttsLanguageMode = 'id';
        btnTtsLang.textContent = '🌐 Indo';
        showToast('Bahasa Suara: Bahasa Indonesia');
    } else {
        ttsLanguageMode = 'auto';
        btnTtsLang.textContent = '🌐 Auto';
        showToast('Bahasa Suara: Deteksi Otomatis');
    }

    if (isTTSPlaying) {
        startReadingCurrentPage();
    }
});

function openTtsGuideModal() {
    ttsGuideBackdrop.style.display = 'block';
    ttsGuideModal.style.display = 'flex';
}

function closeTtsGuideModal() {
    ttsGuideBackdrop.style.display = 'none';
    ttsGuideModal.style.display = 'none';
}

btnCloseTtsGuide.addEventListener('click', closeTtsGuideModal);
btnOkTtsGuide.addEventListener('click', closeTtsGuideModal);
ttsGuideBackdrop.addEventListener('click', closeTtsGuideModal);

async function startReadingCurrentPage() {
    if (!('speechSynthesis' in window)) {
        alert("Perangkat Anda tidak mendukung fitur Text-to-Speech.");
        return;
    }

    window.speechSynthesis.cancel();
    btnTtsPlayPause.textContent = "⏸️";
    isTTSPlaying = true;

    try {
        const page = await pdfDoc.getPage(pageNum);
        const textContent = await page.getTextContent();
        const text = textContent.items.map(item => item.str || '').join(' ').trim();

        if (!text) {
            ttsStatusText.textContent = "Halaman tidak memiliki teks.";
            showToast("Halaman ini tidak berisi teks yang terbaca.");
            return;
        }

        let targetLang = 'id-ID';
        if (ttsLanguageMode === 'ar') {
            targetLang = 'ar-SA';
        } else if (ttsLanguageMode === 'id') {
            targetLang = 'id-ID';
        } else {
            targetLang = isArabicText(text) ? 'ar-SA' : 'id-ID';
        }

        updateTTSVoices();

        if (targetLang.startsWith('ar')) {
            const hasArabicVoice = availableVoices.some(v => v.lang.toLowerCase().startsWith('ar'));
            if (!hasArabicVoice) {
                stopTTS();
                openTtsGuideModal();
                return;
            }
        }

        ttsStatusText.textContent = `[${targetLang.startsWith('ar') ? 'Arab' : 'Indo'}] Hal. ${pageNum}...`;
        ttsUtterance = new SpeechSynthesisUtterance(text);
        ttsUtterance.rate = ttsSpeeds[ttsSpeedIndex];
        ttsUtterance.lang = targetLang;

        const matchedVoice = availableVoices.find(v => v.lang.toLowerCase().startsWith(targetLang.substring(0, 2)));
        if (matchedVoice) {
            ttsUtterance.voice = matchedVoice;
        }

        ttsUtterance.onend = () => {
            isTTSPlaying = false;
            btnTtsPlayPause.textContent = "▶️";
            ttsStatusText.textContent = "Selesai membaca.";
            if (pageNum < pdfDoc.numPages) {
                pageNum++;
                queueRenderPage(pageNum);
                setTimeout(() => startReadingCurrentPage(), 1000);
            }
        };

        ttsUtterance.onerror = () => {
            isTTSPlaying = false;
            btnTtsPlayPause.textContent = "▶️";
            ttsStatusText.textContent = "Pembacaan dihentikan.";
        };

        window.speechSynthesis.speak(ttsUtterance);
    } catch (e) {
        showToast("Gagal membaca teks halaman.");
    }
}

btnTtsPlayPause.addEventListener('click', () => {
    if (!window.speechSynthesis) return;

    if (isTTSPlaying) {
        window.speechSynthesis.pause();
        isTTSPlaying = false;
        btnTtsPlayPause.textContent = "▶️";
        ttsStatusText.textContent = "Dijeda";
    } else {
        if (window.speechSynthesis.paused) {
            window.speechSynthesis.resume();
            isTTSPlaying = true;
            btnTtsPlayPause.textContent = "⏸️";
            ttsStatusText.textContent = `Membaca Hal. ${pageNum}...`;
        } else {
            startReadingCurrentPage();
        }
    }
});

btnTtsStop.addEventListener('click', stopTTS);

function stopTTS() {
    if (window.speechSynthesis) {
        window.speechSynthesis.cancel();
    }
    isTTSPlaying = false;
    ttsPlayerBar.style.display = 'none';
}

btnTtsSpeed.addEventListener('click', () => {
    ttsSpeedIndex = (ttsSpeedIndex + 1) % ttsSpeeds.length;
    const speed = ttsSpeeds[ttsSpeedIndex];
    btnTtsSpeed.textContent = `${speed}x`;
    showToast(`Kecepatan Suara: ${speed}x`);
    if (isTTSPlaying) {
        startReadingCurrentPage();
    }
});

// =============================================================================
// 13. SISTEM BOOKMARK & RIWAYAT MEMBACA
// =============================================================================
btnBookmark.addEventListener('click', () => {
    if (!pdfDoc || !currentFileKey) return;

    let bookmarks = JSON.parse(localStorage.getItem(`${currentFileKey}_bookmarks`) || '[]');
    const index = bookmarks.indexOf(pageNum);

    if (index === -1) {
        bookmarks.push(pageNum);
        bookmarks.sort((a, b) => a - b);
        showToast(`Halaman ${pageNum} ditandai`);
    } else {
        bookmarks.splice(index, 1);
        showToast(`Tanda halaman ${pageNum} dihapus`);
    }

    localStorage.setItem(`${currentFileKey}_bookmarks`, JSON.stringify(bookmarks));
    updateBookmarkButton();
});

function updateBookmarkButton() {
    if (!currentFileKey) return;
    let bookmarks = JSON.parse(localStorage.getItem(`${currentFileKey}_bookmarks`) || '[]');
    btnBookmark.textContent = bookmarks.includes(pageNum) ? '★' : '🔖';
}

function renderBookmarkList() {
    bookmarkList.innerHTML = '';
    if (!currentFileKey) {
        bookmarkList.innerHTML = '<li>Belum ada file terbuka.</li>';
        return;
    }
    let bookmarks = JSON.parse(localStorage.getItem(`${currentFileKey}_bookmarks`) || '[]');
    if (bookmarks.length === 0) {
        bookmarkList.innerHTML = '<li>Belum ada halaman yang ditandai.</li>';
        return;
    }
    bookmarks.forEach(page => {
        const li = document.createElement('li');
        li.innerHTML = `<span>Halaman ${page}</span> <span>Buka ➔</span>`;
        li.onclick = () => {
            pageNum = page;
            stopTTS();
            queueRenderPage(pageNum);
            closeDrawer();
        };
        bookmarkList.appendChild(li);
    });
}

function saveToHistory(name, size, pages) {
    let history = JSON.parse(localStorage.getItem('pdf_reader_history') || '[]');
    history = history.filter(item => item.name !== name);
    history.unshift({
        name: name,
        size: size,
        pages: pages,
        date: new Date().toLocaleDateString('id-ID')
    });
    if (history.length > 10) history.pop();
    localStorage.setItem('pdf_reader_history', JSON.stringify(history));
}

function renderHistoryList() {
    historyList.innerHTML = '';
    let history = JSON.parse(localStorage.getItem('pdf_reader_history') || '[]');
    if (history.length === 0) {
        historyList.innerHTML = '<li>Belum ada riwayat.</li>';
        return;
    }
    history.forEach(item => {
        const li = document.createElement('li');
        li.innerHTML = `<div><strong>${item.name}</strong><br><small>${item.pages} Hal • ${item.date}</small></div>`;
        historyList.appendChild(li);
    });
}

btnMenu.addEventListener('click', () => {
    appDrawer.classList.add('open');
    drawerBackdrop.style.display = 'block';
    renderBookmarkList();
    renderHistoryList();

    document.getElementById('info-name').textContent = currentFileName || '-';
    document.getElementById('info-size').textContent = currentFileSize || '-';
    document.getElementById('info-pages').textContent = pdfDoc ? pdfDoc.numPages : '-';
});

function closeDrawer() {
    appDrawer.classList.remove('open');
    drawerBackdrop.style.display = 'none';
}

btnCloseDrawer.addEventListener('click', closeDrawer);
drawerBackdrop.addEventListener('click', closeDrawer);

document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.drawer-content').forEach(c => c.classList.remove('active'));
        btn.classList.add('active');
        const targetId = btn.id.replace('tab-btn-', 'tab-');
        document.getElementById(targetId).classList.add('active');
    });
});