MIRI TV — yenilənmiş veb tətbiq

AÇMAQ
1. ZIP-i yükləyib çıxarın.
2. index.html faylını brauzerdə açın.
3. Daha sabit istifadə üçün qovluğu HTTPS hostinqə yerləşdirin.

YENİLƏNMƏLƏR
- Reklam paneli yuxarıda kiçik zolaq şəklindədir.
- Azərbaycan, Türkiyə və Rusiya üçün əlavə kanallar, o cümlədən idman kanalları.
- Video pleyeri sabitdir, yalnız kanal siyahısı sürüşür.
- Daxili pleyerə icazə verməyən rəsmi saytlar üçün boş/qara ekran əvəzinə aydın rəsmi yayım düyməsi göstərilir.
- Rəsmi yayım keçidləri kanal sahibinin səhifəsinə aparır.
- AZ/RU/EN dil seçimi və WhatsApp reklam əlaqəsi: +994706533525.
- Reklam sınağı 5 saniyədir; taymer 20 dəqiqəlik dövrə ilə işləyir.

VACİB
Bütün kanalları hər telefonda daxili pleyerdə işlətmək mümkün deyil: yayımçıların iframe/region/copyright məhdudiyyətləri var. Rəsmi səhifə açılmırsa, həmin yayımçı linki dəyişmiş və ya region üzrə bloklanmış ola bilər. Tətbiq pirat yayım ünvanları deyil, rəsmi səhifələrdən istifadə edir. Bütün istifadəçilərə reklam göstərmək üçün server və admin paneli lazımdır; bu versiyada reklam əlavələri lokal brauzerdə saxlanılır.

PWA quraşdırılması üçün index.html, manifest.json, sw.js və icons qovluğunu eyni qovluqda HTTPS hostinqə yerləşdirin, sonra Chrome menyusundan “Əsas ekrana əlavə et” seçin.
