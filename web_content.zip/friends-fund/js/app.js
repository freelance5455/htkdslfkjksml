(function () {
  'use strict';

  /* ============ التخزين ============ */
  var KEY = 'friends-fund-v1';

  function defaults() {
    return {
      settings: { name: 'صندوق الأصدقاء', tagline: 'معاً .. نساند بعضنا', monthly: 2000, totalMonths: 12, currency: 'MRU' },
      members: [],
      needy: [],
      expenses: []
    };
  }

  function normalize(raw) {
    var d = defaults();
    if (!raw || typeof raw !== 'object') return d;
    var s = raw.settings && typeof raw.settings === 'object' ? raw.settings : {};
    d.settings.name = String(s.name || d.settings.name).slice(0, 40);
    d.settings.tagline = String(s.tagline == null ? d.settings.tagline : s.tagline).slice(0, 60);
    d.settings.monthly = Math.max(0, Number(s.monthly) || d.settings.monthly);
    d.settings.totalMonths = Math.min(120, Math.max(1, Math.round(Number(s.totalMonths) || d.settings.totalMonths)));
    d.settings.currency = String(s.currency || d.settings.currency).slice(0, 8);
    d.members = Array.isArray(raw.members) ? raw.members.filter(function (m) { return m && m.id; }) : [];
    d.needy = Array.isArray(raw.needy) ? raw.needy.filter(function (n) { return n && n.id; }) : [];
    d.expenses = Array.isArray(raw.expenses) ? raw.expenses.filter(function (x) { return x && x.id; }) : [];
    return d;
  }

  function load() {
    try {
      var r = localStorage.getItem(KEY);
      if (r) return normalize(JSON.parse(r));
    } catch (e) { /* تجاهل */ }
    return defaults();
  }

  var state = load();
  var ui = { tab: 'home', q: '' };

  function save() {
    try {
      localStorage.setItem(KEY, JSON.stringify(state));
    } catch (e) {
      toast('تعذر الحفظ، المساحة ممتلئة. احذف بعض الصور أو صغّرها.');
    }
  }

  /* ============ أدوات ============ */
  function $(s, r) { return (r || document).querySelector(s); }
  function esc(v) {
    return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
  function fmt(n) { return (Math.round(Number(n)) || 0).toLocaleString('en-US'); }
  function today() {
    var d = new Date();
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  }
  function monthsText(n) {
    if (n === 1) return 'شهر واحد';
    if (n === 2) return 'شهرين';
    if (n >= 3 && n <= 10) return n + ' أشهر';
    return n + ' شهرًا';
  }

  var toastTimer;
  function toast(msg) {
    var t = $('#toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.classList.remove('show'); }, 2600);
  }

  /* ============ الأيقونات ============ */
  var P = {
    users: '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
    wallet: '<path d="M20 12V8H6a2 2 0 0 1 0-4h12v4"/><path d="M4 6v12a2 2 0 0 0 2 2h14v-4"/><path d="M18 12a2 2 0 0 0 0 4h4v-4Z"/>',
    home: '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/><path d="M10 20v-6h4v6"/>',
    heart: '<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1 1.1L12 21l7.8-7.5 1-1.1a5.5 5.5 0 0 0 0-7.8z"/>',
    doc: '<path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><path d="M14 3v6h6"/><path d="M8 13h8M8 17h6"/>',
    gear: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    chev: '<path d="M15 18l-6-6 6-6"/>',
    menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
    cap: '<path d="M22 10L12 5 2 10l10 5 10-5z"/><path d="M6 12v5c3 2 9 2 12 0v-5"/>',
    medical: '<rect x="3" y="3" width="18" height="18" rx="3"/><path d="M12 8v8M8 12h8"/>',
    box: '<path d="M21 8l-9-5-9 5 9 5 9-5z"/><path d="M3 8v8l9 5 9-5V8"/>',
    x: '<path d="M18 6L6 18M6 6l12 12"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>',
    check: '<path d="M20 6L9 17l-5-5"/>'
  };
  function icon(n, size) {
    var s = size || 22;
    return '<svg class="ic" width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + P[n] + '</svg>';
  }

  var CATS = {
    member: { label: 'مساعدة عضو', icon: 'heart', cls: 'red' },
    emergency: { label: 'مساعدة طارئة', icon: 'home', cls: 'blue' },
    education: { label: 'دعم تعليمي', icon: 'cap', cls: 'blue' },
    health: { label: 'مساعدة صحية', icon: 'medical', cls: 'green' },
    other: { label: 'أخرى', icon: 'box', cls: 'gray' }
  };

  /* ============ الحسابات ============ */
  function monthly() { return Math.max(0, Number(state.settings.monthly) || 0); }
  function totalMonths() { return Math.max(1, Math.round(Number(state.settings.totalMonths) || 12)); }
  function cur() { return esc(state.settings.currency); }
  function paidOf(m) { return Math.min(totalMonths(), Math.max(0, Math.round(Number(m.paid) || 0))); }
  function totals() {
    var c = state.members.reduce(function (a, m) { return a + paidOf(m) * monthly(); }, 0);
    var e = state.expenses.reduce(function (a, x) { return a + (Number(x.amount) || 0); }, 0);
    return { c: c, e: e, b: c - e };
  }

  /* ============ الصور الشخصية ============ */
  var COLORS = ['#2e7d6b', '#3b6fc4', '#b5651d', '#7a4fb0', '#c2455a', '#2f8f9d'];
  function avatar(photo, name, size) {
    if (photo && String(photo).indexOf('data:image/') === 0) {
      return '<img class="av ' + size + '" src="' + esc(photo) + '" alt="">';
    }
    var s = String(name || '').trim();
    var ch = s ? Array.from(s)[0] : '؟';
    var h = 0;
    for (var i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
    return '<span class="av ' + size + '" style="background:' + COLORS[h % COLORS.length] + '" aria-hidden="true">' + esc(ch) + '</span>';
  }

  function readPhoto(file) {
    return new Promise(function (resolve, reject) {
      var r = new FileReader();
      r.onerror = reject;
      r.onload = function () {
        var img = new Image();
        img.onerror = reject;
        img.onload = function () {
          var max = 256;
          var k = Math.min(1, max / Math.max(img.width, img.height));
          var w = Math.max(1, Math.round(img.width * k));
          var h = Math.max(1, Math.round(img.height * k));
          var c = document.createElement('canvas');
          c.width = w; c.height = h;
          c.getContext('2d').drawImage(img, 0, 0, w, h);
          resolve(c.toDataURL('image/jpeg', 0.82));
        };
        img.src = r.result;
      };
      r.readAsDataURL(file);
    });
  }

  /* ============ الرأس والتبويبات ============ */
  var TABS = [
    { id: 'home', label: 'الرئيسية', icon: 'home' },
    { id: 'needy', label: 'غير المدعمين', icon: 'heart' },
    { id: 'expenses', label: 'المصروفات', icon: 'doc' },
    { id: 'settings', label: 'الإعدادات', icon: 'gear' }
  ];
  var SUB = {
    needy: { title: 'الأعضاء غير المدعمين', icon: 'heart' },
    expenses: { title: 'تفاصيل المصروفات', icon: 'doc' },
    settings: { title: 'الإعدادات', icon: 'gear' }
  };

  function renderTop() {
    var el = $('#top');
    if (ui.tab === 'home') {
      el.className = 'top';
      el.innerHTML = '<div class="top-row"><div class="brand">' + icon('users', 38) +
        '<div><h1>' + esc(state.settings.name) + '</h1><p>' + esc(state.settings.tagline) + '</p></div></div>' +
        '<button class="icon-btn" data-action="nav" data-tab="settings" aria-label="الإعدادات">' + icon('menu') + '</button></div>';
    } else {
      var s = SUB[ui.tab];
      el.className = 'top sub';
      el.innerHTML = '<div class="top-row"><div class="ttl">' + icon(s.icon, 24) + '<h1>' + s.title + '</h1></div>' +
        '<button class="icon-btn" data-action="nav" data-tab="home" aria-label="رجوع">' + icon('chev') + '</button></div>';
    }
  }

  function renderTabs() {
    $('#tabs').innerHTML = TABS.map(function (t) {
      return '<button class="tab' + (ui.tab === t.id ? ' on' : '') + '" data-action="nav" data-tab="' + t.id + '"' +
        (ui.tab === t.id ? ' aria-current="page"' : '') + '>' + icon(t.icon, 24) + '<span>' + t.label + '</span></button>';
    }).join('');
  }

  /* ============ الصفحة الرئيسية ============ */
  function memberCard(m) {
    var p = paidOf(m), T = totalMonths(), left = T - p;
    var pct = Math.round(p / T * 100);
    return '<article class="card member" data-action="edit-member" data-id="' + esc(m.id) + '" role="button" tabindex="0">' +
      avatar(m.photo, m.name, 'md') +
      '<div class="m-body"><h3>' + esc(m.name) + '</h3>' +
      '<p class="m-sub">دفع ' + monthsText(p) + ' من أصل ' + T + '</p>' +
      '<div class="bar-row"><div class="bar"><i style="width:' + pct + '%"></i></div><b>' + pct + '%</b></div>' +
      (left > 0
        ? '<p class="m-left">المتبقي: ' + left + ' شهر · ' + fmt(left * monthly()) + ' ' + cur() + '</p>'
        : '<p class="m-left done">المتبقي: 0 شهر · مكتمل</p>') +
      '</div>' +
      '<div class="m-amt"><strong>' + fmt(p * monthly()) + '</strong><small>' + cur() + '</small></div></article>';
  }

  function homeView() {
    var t = totals();
    var h = '<section class="hero-balance' + (t.b < 0 ? ' neg' : '') + '"><div><span class="lbl">الرصيد الحالي بعد خصم المصروفات</span>' +
      '<strong class="num">' + fmt(t.b) + '<small>' + cur() + '</small></strong></div><span class="hb-ic">' + icon('wallet', 28) + '</span></section>';
    h += '<section class="stats">' +
      '<div class="stat green"><span class="lbl">' + icon('wallet', 18) + 'إجمالي المساهمات</span><strong>' + fmt(t.c) + '<small>' + cur() + '</small></strong></div>' +
      '<div class="stat blue"><span class="lbl">' + icon('users', 18) + 'عدد الأعضاء</span><strong>' + state.members.length + '</strong></div></section>';
    h += '<h2 class="section-title">' + icon('users', 22) + 'الأعضاء المشاركون</h2>';
    if (!state.members.length) {
      h += '<div class="card empty">' + icon('users', 44) + '<h3>لا يوجد أعضاء بعد</h3>' +
        '<p>أضف أصدقاءك المشاركين في الصندوق، وسجّل عدد الأشهر التي دفعها كل واحد.</p>' +
        '<div class="row"><button class="btn primary" data-action="add-member">' + icon('plus', 20) + 'إضافة عضو</button>' +
        '<button class="btn ghost" data-action="demo">تجربة ببيانات نموذجية</button></div></div>';
    } else {
      h += '<div class="list">' + state.members.map(memberCard).join('') + '</div>';
      h += '<button class="btn primary wide" data-action="add-member">' + icon('plus', 20) + 'إضافة عضو جديد</button>';
    }
    return h;
  }

  /* ============ غير المدعمين ============ */
  function needyCard(n) {
    var ok = n.status === 'supported';
    return '<article class="card needy"><div class="n-top">' + avatar(n.photo, n.name, 'lg') +
      '<div class="n-info"><div class="n-head"><h3>' + esc(n.name) + '</h3>' +
      '<span class="chip ' + (ok ? 'ok' : 'need') + '">' + (ok ? 'تم دعمه' : 'يحتاج إلى دعم') + '</span></div>' +
      '<p class="n-job">' + esc(n.label) + '</p><p class="n-story">' + esc(n.story) + '</p></div></div>' +
      '<button class="btn soft wide" data-action="view-needy" data-id="' + esc(n.id) + '">عرض التفاصيل ' + icon('chev', 18) + '</button></article>';
  }

  function needyList() {
    var q = ui.q.trim().toLowerCase();
    var list = state.needy.filter(function (n) {
      return !q || (n.name + ' ' + (n.label || '') + ' ' + (n.story || '')).toLowerCase().indexOf(q) !== -1;
    });
    if (!state.needy.length) {
      return '<div class="card empty">' + icon('heart', 44) + '<h3>لا توجد حالات مسجلة</h3>' +
        '<p>أضف الأعضاء غير المدعمين مع صورهم وقصتهم ليسهل على الجميع معرفة من يحتاج إلى مساعدة.</p></div>';
    }
    if (!list.length) return '<div class="card empty"><h3>لا نتائج</h3><p>لم يتم العثور على عضو بهذا الاسم.</p></div>';
    return list.map(needyCard).join('');
  }

  function needyView() {
    return '<label class="search">' + icon('search', 20) +
      '<input id="q" type="search" placeholder="ابحث عن عضو..." value="' + esc(ui.q) + '" aria-label="بحث"></label>' +
      '<div class="list" id="needy-list">' + needyList() + '</div>' +
      '<button class="btn primary wide" data-action="add-needy">' + icon('plus', 20) + 'إضافة عضو غير مدعم</button>';
  }

  /* ============ المصروفات ============ */
  function expenseRow(x) {
    var c = CATS[x.cat] || CATS.other;
    var n = state.needy.filter(function (z) { return z.id === x.needyId; })[0];
    var desc = [x.desc, n ? '(' + n.name + ')' : ''].filter(Boolean).join(' ');
    return '<article class="card exp" data-action="edit-expense" data-id="' + esc(x.id) + '" role="button" tabindex="0">' +
      '<span class="e-ic ' + c.cls + '">' + icon(c.icon, 22) + '</span>' +
      '<div class="e-body"><h3>' + esc(x.title) + '</h3>' + (desc ? '<p>' + esc(desc) + '</p>' : '') + '<p>' + esc(x.date) + '</p></div>' +
      '<div class="e-amt"><strong>-' + fmt(x.amount) + '</strong><small>' + cur() + '</small></div></article>';
  }

  function expensesView() {
    var t = totals();
    var h = '<section class="hero-balance' + (t.b < 0 ? ' neg' : '') + '"><div><span class="lbl">الرصيد الحالي بعد خصم المصروفات</span>' +
      '<strong class="num">' + fmt(t.b) + '<small>' + cur() + '</small></strong></div><span class="hb-ic">' + icon('wallet', 28) + '</span></section>';
    h += '<section class="stats three">' +
      '<div class="stat"><span class="lbl">إجمالي المساهمات</span><strong>' + fmt(t.c) + '</strong><small>' + cur() + '</small></div>' +
      '<div class="stat red"><span class="lbl">إجمالي المصروفات</span><strong>' + fmt(t.e) + '</strong><small>' + cur() + '</small></div>' +
      '<div class="stat green"><span class="lbl">الرصيد الحالي</span><strong>' + fmt(t.b) + '</strong><small>' + cur() + '</small></div></section>';
    h += '<h2 class="section-title">سجل المصروفات</h2>';
    var sorted = state.expenses.slice().sort(function (a, b) {
      return String(b.date).localeCompare(String(a.date)) || String(b.id).localeCompare(String(a.id));
    });
    if (!sorted.length) {
      h += '<div class="card empty">' + icon('doc', 44) + '<h3>لا توجد مصروفات</h3><p>سجّل كل مبلغ يصرف من الصندوق مع السبب والتاريخ، وسيُخصم من الرصيد تلقائيًا.</p></div>';
    } else {
      h += '<div class="list">' + sorted.map(expenseRow).join('') + '</div>';
    }
    h += '<button class="btn primary wide" data-action="add-expense">' + icon('plus', 20) + 'إضافة مصروف</button>';
    h += '<p class="note">' + icon('info', 18) + '<span>يتم تحديث الرصيد تلقائيًا بعد كل عملية صرف. جميع المصروفات موثقة بالتاريخ والسبب.</span></p>';
    return h;
  }

  /* ============ الإعدادات ============ */
  function settingsView() {
    var s = state.settings;
    return '<form class="card panel" id="settings-form" autocomplete="off">' +
      '<h3>بيانات الصندوق</h3>' +
      '<label class="fld"><span>اسم الصندوق</span><input name="name" required maxlength="40" value="' + esc(s.name) + '"></label>' +
      '<label class="fld"><span>الشعار</span><input name="tagline" maxlength="60" value="' + esc(s.tagline) + '"></label>' +
      '<div class="row2"><label class="fld"><span>المبلغ الشهري لكل عضو</span><input name="monthly" type="number" inputmode="numeric" min="0" step="any" required value="' + esc(s.monthly) + '"></label>' +
      '<label class="fld"><span>عدد أشهر الصندوق</span><input name="totalMonths" type="number" inputmode="numeric" min="1" max="120" required value="' + esc(s.totalMonths) + '"></label></div>' +
      '<label class="fld"><span>العملة</span><input name="currency" required maxlength="8" value="' + esc(s.currency) + '"></label>' +
      '<p class="hint">عند تغيير المبلغ الشهري يُعاد حساب مساهمات جميع الأعضاء بالمبلغ الجديد.</p>' +
      '<button class="btn primary" type="submit">حفظ الإعدادات</button></form>' +
      '<section class="card panel"><h3>النسخ الاحتياطي</h3>' +
      '<p class="hint">البيانات محفوظة على هذا الجهاز فقط. صدّر نسخة احتياطية بشكل دوري، أو استوردها لنقل البيانات إلى جهاز آخر.</p>' +
      '<div class="btn-col"><button class="btn soft" data-action="export">تصدير نسخة احتياطية</button>' +
      '<label class="btn ghost">استيراد نسخة احتياطية<input id="import-file" type="file" accept="application/json,.json" hidden></label>' +
      '<button class="btn ghost" data-action="demo">تحميل بيانات نموذجية</button>' +
      '<button class="btn danger" data-action="reset">حذف كل البيانات</button></div></section>';
  }

  /* ============ العرض ============ */
  function render() {
    renderTop();
    var v = $('#view');
    var f = { home: homeView, needy: needyView, expenses: expensesView, settings: settingsView }[ui.tab];
    v.innerHTML = f();
    renderTabs();
    document.title = state.settings.name;
  }

  function go(tab) {
    ui.tab = tab;
    if (tab !== 'needy') ui.q = '';
    render();
    window.scrollTo(0, 0);
  }

  /* ============ النوافذ ============ */
  function openModal(title, body, mount) {
    closeModal();
    var root = $('#modal-root');
    root.innerHTML = '<div class="backdrop"><div class="sheet" role="dialog" aria-modal="true" aria-label="' + esc(title) + '">' +
      '<div class="sheet-h"><h2>' + esc(title) + '</h2><button class="icon-btn" data-action="close" aria-label="إغلاق">' + icon('x') + '</button></div>' +
      '<div class="sheet-b">' + body + '</div></div></div>';
    document.body.classList.add('lock');
    var sheet = $('.sheet', root);
    if (mount) mount(sheet);
    var first = sheet.querySelector('input:not([type=file]),textarea,select');
    if (first && !first.value) { try { first.focus(); } catch (e) { /* تجاهل */ } }
  }
  function closeModal() {
    $('#modal-root').innerHTML = '';
    document.body.classList.remove('lock');
  }

  function photoField() {
    return '<div class="photo-field"><div id="pp"></div><div class="pbtns">' +
      '<label class="btn ghost small">اختيار صورة<input id="pf" type="file" accept="image/*" hidden></label>' +
      '<button type="button" class="btn ghost small" id="prm">إزالة الصورة</button></div></div>';
  }
  function wirePhoto(sheet, state0, size) {
    var pp = $('#pp', sheet), nameEl = $('[name=name]', sheet);
    function draw() { pp.innerHTML = avatar(state0.photo, nameEl.value, size); }
    draw();
    nameEl.addEventListener('input', draw);
    $('#pf', sheet).addEventListener('change', function (e) {
      var f = e.target.files && e.target.files[0];
      if (!f) return;
      readPhoto(f).then(function (d) { state0.photo = d; draw(); }, function () { toast('تعذر قراءة الصورة'); });
    });
    $('#prm', sheet).addEventListener('click', function () { state0.photo = ''; draw(); });
  }

  /* ---- عضو مشارك ---- */
  function memberModal(id) {
    var m = id ? state.members.filter(function (x) { return x.id === id; })[0] : null;
    var T = totalMonths();
    var ph = { photo: m ? m.photo || '' : '' };
    var body = '<form id="mf" autocomplete="off">' + photoField() +
      '<label class="fld"><span>الاسم</span><input name="name" required maxlength="40" value="' + esc(m ? m.name : '') + '"></label>' +
      '<div class="fld"><span>الأشهر المدفوعة (من أصل ' + T + ')</span><div class="stepper">' +
      '<button type="button" data-step="-1" aria-label="إنقاص شهر">−</button>' +
      '<input name="paid" type="number" inputmode="numeric" min="0" max="' + T + '" value="' + (m ? paidOf(m) : 0) + '" aria-label="عدد الأشهر">' +
      '<button type="button" data-step="1" aria-label="إضافة شهر">+</button></div></div>' +
      '<p class="hint" id="calc"></p>' +
      '<div class="actions"><button class="btn primary" type="submit">' + (m ? 'حفظ التعديلات' : 'إضافة العضو') + '</button>' +
      (m ? '<button type="button" class="btn danger" id="del">حذف العضو</button>' : '') + '</div></form>';
    openModal(m ? 'تعديل العضو' : 'إضافة عضو جديد', body, function (sheet) {
      wirePhoto(sheet, ph, 'xl');
      var paid = $('[name=paid]', sheet), calc = $('#calc', sheet);
      function val() { return Math.min(T, Math.max(0, Math.round(Number(paid.value) || 0))); }
      function upd() {
        var p = val();
        calc.textContent = 'إجمالي ما دفعه: ' + fmt(p * monthly()) + ' ' + state.settings.currency + ' · المتبقي: ' + fmt((T - p) * monthly()) + ' ' + state.settings.currency + ' (' + (T - p) + ' شهر)';
      }
      upd();
      paid.addEventListener('input', upd);
      sheet.querySelectorAll('[data-step]').forEach(function (b) {
        b.addEventListener('click', function () { paid.value = Math.min(T, Math.max(0, val() + Number(b.dataset.step))); upd(); });
      });
      $('#mf', sheet).addEventListener('submit', function (e) {
        e.preventDefault();
        var name = $('[name=name]', sheet).value.trim();
        if (!name) return;
        if (m) { m.name = name; m.photo = ph.photo; m.paid = val(); }
        else state.members.push({ id: uid(), name: name, photo: ph.photo, paid: val() });
        save(); closeModal(); render(); toast(m ? 'تم حفظ التعديلات' : 'تمت إضافة العضو');
      });
      var del = $('#del', sheet);
      if (del) del.addEventListener('click', function () {
        if (!confirm('حذف العضو "' + m.name + '"؟ سيُخصم مبلغ مساهماته من إجمالي الصندوق.')) return;
        state.members = state.members.filter(function (x) { return x.id !== m.id; });
        save(); closeModal(); render(); toast('تم حذف العضو');
      });
    });
  }

  /* ---- غير مدعم ---- */
  function needyDetails(id) {
    var n = state.needy.filter(function (x) { return x.id === id; })[0];
    if (!n) return;
    var ok = n.status === 'supported';
    var got = state.expenses.filter(function (x) { return x.needyId === id; });
    var sum = got.reduce(function (a, x) { return a + (Number(x.amount) || 0); }, 0);
    var body = '<div class="detail-head">' + avatar(n.photo, n.name, 'xl') + '<div><h3>' + esc(n.name) + '</h3>' +
      '<p class="n-job">' + esc(n.label) + '</p><span class="chip ' + (ok ? 'ok' : 'need') + '">' + (ok ? 'تم دعمه' : 'يحتاج إلى دعم') + '</span></div></div>' +
      (n.story ? '<div class="story">' + esc(n.story) + '</div>' : '') +
      (n.phone ? '<div class="kv"><span>رقم التواصل</span><b dir="ltr">' + esc(n.phone) + '</b></div>' : '') +
      '<div class="kv"><span>إجمالي ما صُرف له من الصندوق</span><b>' + fmt(sum) + ' ' + cur() + '</b></div>' +
      (got.length ? '<div class="mini-list">' + got.map(function (x) {
        return '<div><span>' + esc(x.title) + ' · ' + esc(x.date) + '</span><b>' + fmt(x.amount) + '</b></div>';
      }).join('') + '</div>' : '') +
      '<div class="actions"><button class="btn primary" data-action="toggle-needy" data-id="' + esc(n.id) + '">' + (ok ? 'إعادته إلى قائمة المحتاجين' : 'تحديد أنه تم دعمه') + '</button>' +
      '<button class="btn soft" data-action="edit-needy" data-id="' + esc(n.id) + '">تعديل البيانات</button></div>';
    openModal('تفاصيل الحالة', body);
  }

  function needyModal(id) {
    var n = id ? state.needy.filter(function (x) { return x.id === id; })[0] : null;
    var ph = { photo: n ? n.photo || '' : '' };
    var body = '<form id="nf" autocomplete="off">' + photoField() +
      '<label class="fld"><span>الاسم</span><input name="name" required maxlength="40" value="' + esc(n ? n.name : '') + '"></label>' +
      '<label class="fld"><span>الوصف المختصر (مثال: طالب جامعي)</span><input name="label" maxlength="50" value="' + esc(n ? n.label : '') + '"></label>' +
      '<label class="fld"><span>الحالة</span><select name="status"><option value="needs"' + (!n || n.status !== 'supported' ? ' selected' : '') + '>يحتاج إلى دعم</option>' +
      '<option value="supported"' + (n && n.status === 'supported' ? ' selected' : '') + '>تم دعمه</option></select></label>' +
      '<label class="fld"><span>رقم التواصل (اختياري)</span><input name="phone" inputmode="tel" dir="ltr" maxlength="25" value="' + esc(n ? n.phone || '' : '') + '"></label>' +
      '<label class="fld"><span>السيرة الذاتية والظروف</span><textarea name="story" maxlength="1200">' + esc(n ? n.story || '' : '') + '</textarea></label>' +
      '<div class="actions"><button class="btn primary" type="submit">' + (n ? 'حفظ التعديلات' : 'إضافة') + '</button>' +
      (n ? '<button type="button" class="btn danger" id="del">حذف</button>' : '') + '</div></form>';
    openModal(n ? 'تعديل الحالة' : 'إضافة عضو غير مدعم', body, function (sheet) {
      wirePhoto(sheet, ph, 'xl');
      $('#nf', sheet).addEventListener('submit', function (e) {
        e.preventDefault();
        var g = function (k) { return $('[name=' + k + ']', sheet).value.trim(); };
        if (!g('name')) return;
        var rec = { name: g('name'), label: g('label'), status: g('status') === 'supported' ? 'supported' : 'needs', phone: g('phone'), story: g('story'), photo: ph.photo };
        if (n) Object.assign(n, rec); else state.needy.push(Object.assign({ id: uid() }, rec));
        save(); closeModal(); render(); toast('تم الحفظ');
      });
      var del = $('#del', sheet);
      if (del) del.addEventListener('click', function () {
        if (!confirm('حذف "' + n.name + '" من القائمة؟')) return;
        state.needy = state.needy.filter(function (x) { return x.id !== n.id; });
        state.expenses.forEach(function (x) { if (x.needyId === n.id) x.needyId = ''; });
        save(); closeModal(); render(); toast('تم الحذف');
      });
    });
  }

  /* ---- مصروف ---- */
  function expenseModal(id) {
    var x = id ? state.expenses.filter(function (z) { return z.id === id; })[0] : null;
    var body = '<form id="ef" autocomplete="off">' +
      '<label class="fld"><span>عنوان المصروف</span><input name="title" required maxlength="50" placeholder="مثال: مساعدة عضو" value="' + esc(x ? x.title : '') + '"></label>' +
      '<div class="row2"><label class="fld"><span>التصنيف</span><select name="cat">' +
      Object.keys(CATS).map(function (k) { return '<option value="' + k + '"' + ((x ? x.cat : 'member') === k ? ' selected' : '') + '>' + CATS[k].label + '</option>'; }).join('') + '</select></label>' +
      '<label class="fld"><span>المبلغ (' + cur() + ')</span><input name="amount" type="number" inputmode="numeric" min="1" step="any" required value="' + esc(x ? x.amount : '') + '"></label></div>' +
      '<label class="fld"><span>التاريخ</span><input name="date" type="date" required value="' + esc(x ? x.date : today()) + '"></label>' +
      '<label class="fld"><span>صُرف لصالح (اختياري)</span><select name="needyId"><option value="">بدون ربط</option>' +
      state.needy.map(function (n) { return '<option value="' + esc(n.id) + '"' + (x && x.needyId === n.id ? ' selected' : '') + '>' + esc(n.name) + '</option>'; }).join('') + '</select></label>' +
      '<label class="fld"><span>التفاصيل والسبب</span><input name="desc" maxlength="120" placeholder="مثال: دعم خالد (علاج)" value="' + esc(x ? x.desc || '' : '') + '"></label>' +
      '<div class="actions"><button class="btn primary" type="submit">' + (x ? 'حفظ التعديلات' : 'تسجيل المصروف') + '</button>' +
      (x ? '<button type="button" class="btn danger" id="del">حذف المصروف</button>' : '') + '</div></form>';
    openModal(x ? 'تعديل المصروف' : 'إضافة مصروف', body, function (sheet) {
      $('#ef', sheet).addEventListener('submit', function (e) {
        e.preventDefault();
        var g = function (k) { return $('[name=' + k + ']', sheet).value.trim(); };
        var amount = Number(g('amount'));
        if (!g('title') || !(amount > 0)) { toast('أدخل عنوانًا ومبلغًا صحيحًا'); return; }
        var t = totals();
        var available = t.b + (x ? Number(x.amount) || 0 : 0);
        if (amount > available && !confirm('المبلغ أكبر من الرصيد المتاح (' + fmt(available) + ' ' + state.settings.currency + '). هل تريد المتابعة؟')) return;
        var rec = { title: g('title'), cat: g('cat'), amount: amount, date: g('date') || today(), needyId: g('needyId'), desc: g('desc') };
        if (x) Object.assign(x, rec); else state.expenses.push(Object.assign({ id: uid() }, rec));
        save(); closeModal(); render(); toast(x ? 'تم حفظ التعديلات' : 'تم تسجيل المصروف وخصمه من الرصيد');
      });
      var del = $('#del', sheet);
      if (del) del.addEventListener('click', function () {
        if (!confirm('حذف هذا المصروف؟ سيعود مبلغه إلى الرصيد.')) return;
        state.expenses = state.expenses.filter(function (z) { return z.id !== x.id; });
        save(); closeModal(); render(); toast('تم حذف المصروف');
      });
    });
  }

  /* ============ بيانات نموذجية ============ */
  function demo() {
    if ((state.members.length || state.needy.length || state.expenses.length) &&
      !confirm('سيتم استبدال البيانات الحالية بالبيانات النموذجية. هل تريد المتابعة؟')) return;
    var n1 = uid() + 'a', n2 = uid() + 'b', n3 = uid() + 'c', n4 = uid() + 'd';
    state = normalize({
      settings: defaults().settings,
      members: [['أحمد', 6], ['محمد', 9], ['خالد', 12], ['سالم', 4], ['يحيى', 7], ['عمر', 10], ['إبراهيم', 11], ['بلال', 5]]
        .map(function (a, i) { return { id: uid() + i, name: a[0], photo: '', paid: a[1] }; }),
      needy: [
        { id: n1, name: 'علي محمد', label: 'طالب جامعي', status: 'needs', phone: '', photo: '', story: 'علي طالب في الجامعة، يعاني من ظروف مادية صعبة ولا يستطيع تغطية مصاريف دراسته. أي دعم سيكون له فرق كبير في مواصلة تعليمه وتحقيق حلمه.' },
        { id: n2, name: 'عبدالله الحسن', label: 'معيل أسرة', status: 'needs', phone: '', photo: '', story: 'عبدالله يعمل بوظيفة بسيطة براتب محدود، وتتكون أسرته من 4 أفراد. فقد عمله مؤخرًا ويحتاج إلى مساعدة لتغطية تكاليف المعيشة الأساسية.' },
        { id: n3, name: 'موسى إبراهيم', label: 'صحة', status: 'needs', phone: '', photo: '', story: 'موسى يعاني من مرض مزمن ويحتاج إلى علاج مستمر، وقد أصبحت تكاليف العلاج عبئًا كبيرًا عليه.' },
        { id: n4, name: 'الشيخ أحمد', label: 'أسرة كبيرة', status: 'supported', phone: '', photo: '', story: 'يعمل بوظيفة بسيطة براتب محدود، ولديه أربعة أطفال يحتاجون إلى مصاريف أساسية للحياة.' }
      ],
      expenses: [
        { id: uid() + 'e1', title: 'مساعدة عضو', cat: 'member', amount: 20000, date: '2026-10-15', needyId: n3, desc: 'دعم خالد (علاج)' },
        { id: uid() + 'e2', title: 'مساعدة طارئة', cat: 'emergency', amount: 15000, date: '2026-10-12', needyId: n2, desc: 'دعم أحمد (إيجار)' },
        { id: uid() + 'e3', title: 'دعم تعليمي', cat: 'education', amount: 10000, date: '2026-10-08', needyId: n1, desc: 'دعم علي (دراسة)' },
        { id: uid() + 'e4', title: 'مساعدة صحية', cat: 'health', amount: 25000, date: '2026-10-05', needyId: n3, desc: 'دعم موسى (علاج)' }
      ]
    });
    save(); render(); toast('تم تحميل البيانات النموذجية');
  }

  /* ============ النسخ الاحتياطي ============ */
  function exportData() {
    var blob = new Blob([JSON.stringify(state, null, 2)], { type: 'application/json' });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'friends-fund-' + today() + '.json';
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(function () { URL.revokeObjectURL(a.href); }, 1000);
    toast('تم تصدير النسخة الاحتياطية');
  }

  function importData(file) {
    var r = new FileReader();
    r.onload = function () {
      try {
        var d = JSON.parse(r.result);
        if (!d || typeof d !== 'object' || !Array.isArray(d.members)) throw new Error('bad');
        if (!confirm('سيتم استبدال البيانات الحالية بمحتوى الملف. هل تريد المتابعة؟')) return;
        state = normalize(d);
        save(); render(); toast('تم استيراد البيانات');
      } catch (e) { toast('الملف غير صالح'); }
    };
    r.readAsText(file);
  }

  /* ============ الأحداث ============ */
  var actions = {
    nav: function (el) { go(el.dataset.tab); },
    close: closeModal,
    'add-member': function () { memberModal(); },
    'edit-member': function (el) { memberModal(el.dataset.id); },
    'add-needy': function () { needyModal(); },
    'view-needy': function (el) { needyDetails(el.dataset.id); },
    'edit-needy': function (el) { needyModal(el.dataset.id); },
    'toggle-needy': function (el) {
      var n = state.needy.filter(function (x) { return x.id === el.dataset.id; })[0];
      if (!n) return;
      n.status = n.status === 'supported' ? 'needs' : 'supported';
      save(); render(); needyDetails(n.id);
    },
    'add-expense': function () { expenseModal(); },
    'edit-expense': function (el) { expenseModal(el.dataset.id); },
    demo: demo,
    export: exportData,
    reset: function () {
      if (!confirm('سيتم حذف كل الأعضاء والمصروفات نهائيًا. هل أنت متأكد؟')) return;
      state = defaults(); save(); render(); toast('تم حذف كل البيانات');
    }
  };

  document.addEventListener('click', function (e) {
    if (e.target.classList && e.target.classList.contains('backdrop')) { closeModal(); return; }
    var el = e.target.closest ? e.target.closest('[data-action]') : null;
    if (el && actions[el.dataset.action]) actions[el.dataset.action](el);
  });

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') closeModal();
    if ((e.key === 'Enter' || e.key === ' ') && e.target.matches && e.target.matches('[role=button][data-action]')) {
      e.preventDefault();
      actions[e.target.dataset.action](e.target);
    }
  });

  document.addEventListener('input', function (e) {
    if (e.target.id === 'q') {
      ui.q = e.target.value;
      $('#needy-list').innerHTML = needyList();
    }
  });

  document.addEventListener('change', function (e) {
    if (e.target.id === 'import-file' && e.target.files[0]) {
      importData(e.target.files[0]);
      e.target.value = '';
    }
  });

  document.addEventListener('submit', function (e) {
    if (e.target.id !== 'settings-form') return;
    e.preventDefault();
    var f = new FormData(e.target);
    state.settings.name = String(f.get('name') || '').trim() || 'صندوق الأصدقاء';
    state.settings.tagline = String(f.get('tagline') || '').trim();
    state.settings.monthly = Math.max(0, Number(f.get('monthly')) || 0);
    state.settings.totalMonths = Math.min(120, Math.max(1, Math.round(Number(f.get('totalMonths')) || 12)));
    state.settings.currency = String(f.get('currency') || '').trim() || 'MRU';
    save(); render(); toast('تم حفظ الإعدادات');
  });

  render();
})();
