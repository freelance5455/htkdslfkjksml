#!/system/bin/sh
# C14_hwui_skia_renderer — hwui skia renderer
# Ask HWUI to use the Skia OpenGL pipeline (fastest on most devices; will fall back if unavailable).
MODULE_ID="C14_hwui_skia_renderer"
. "$(dirname "$0")/../lib/core.sh"
vcg_init
apply() {
    vcg_apply_or_skip C14_ENABLED || return 0
    vcg_run "$MODULE_ID" setprop debug.hwui.renderer skiagl
}
revert() {
    vcg_run "revert" setprop debug.hwui.renderer ""
}
case "${1:-apply}" in apply) apply ;; revert) revert ;; *) exit 1 ;; esac
