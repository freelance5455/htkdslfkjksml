SAVINGS TRACKER V3 - APK READY
Features: Dashboard, Charts, Goals, Calendar, Income/Expense, Reports, JSON Backup/Restore, PIN, offline PWA.

Capacitor build on a computer:
1. npm install
2. npx cap add android
3. npx cap sync android
4. npx cap open android
5. Build APK from Android Studio.

This ZIP is APK-ready source, not a precompiled APK. The app stores data locally. PIN is local protection, not bank-grade encryption.
