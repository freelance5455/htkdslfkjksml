Fishstrap Mobile — Android-friendly demo

Files:
- index.html: the complete mobile-friendly dashboard.

How to use on Android:
1. Download and unzip the project.
2. Open index.html in Acode or another HTML editor.
3. Preview it in your browser.
4. To package it as an APK, use an Android WebView wrapper project or Android Studio.

What works:
- Dark/light theme
- Accent color selection
- Compact layout
- Save/reset preferences in browser local storage
- Attempts to open the installed Roblox Android app

Limitations:
This is an unofficial UI demo, not the original Fishstrap bootstrapper. It cannot modify Roblox's protected files, install Roblox itself, or enable unsupported platform features.
