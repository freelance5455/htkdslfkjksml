# Testes da versão 9 — pacote para HTML to APK

Checks de estrutura do pacote: 15/15 passaram.

- [x] arquivo index.html
- [x] index.html importa o módulo relativo
- [x] index.html inclui fallback de compatibilidade
- [x] index.html referências DOM resolvidas
- [x] arquivo web/index.html
- [x] web/index.html importa o módulo relativo
- [x] web/index.html inclui fallback de compatibilidade
- [x] web/index.html referências DOM resolvidas
- [x] arquivo www/index.html
- [x] www/index.html importa o módulo relativo
- [x] www/index.html inclui fallback de compatibilidade
- [x] www/index.html referências DOM resolvidas
- [x] rota esperada web/index.html na raiz do ZIP
- [x] módulo narrativo web
- [x] config local web

O teste automatizado narrativo incluído na origem passou 11/11 no ambiente de desenvolvimento.

Não foi possível gerar um APK final nem testar o conversor HTML to APK ou o aparelho físico neste ambiente. A correção do caminho é estrutural: a raiz do ZIP não tem uma pasta externa adicional, e contém `web/index.html` diretamente.
