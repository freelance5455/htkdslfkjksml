/* RADHE RADHE: Android (Capacitor) bridge. HTML jin naamo ko bulati hai unhe plugins se jodta hai. */
(function () {
  var C = window.Capacitor;
  if (!C || !C.registerPlugin) return;
  function P(n) { try { return C.registerPlugin(n); } catch (e) { return null; } }
  var FS = P('Filesystem'), SH = P('Share'), TTS = P('TextToSpeech'),
      SR = P('SpeechRecognition'), CT = P('Contacts'), BIO = P('BiometricAuth');
  function say(m) { try { if (window.toast) window.toast(m, 'info'); } catch (e) {} }

  var bridge = {
    // Backup: pehle Documents/<folder>/ me likhne ki koshish, na ho to Share se bhejna
    saveBackup: function (name, content, folder) {
      return (async function () {
        var path = (folder || 'VyaparBackup') + '/' + name;
        try {
          await FS.writeFile({ path: path, data: content, directory: 'DOCUMENTS', encoding: 'utf8', recursive: true });
          say('Backup save hua: Documents/' + path);
          return true;
        } catch (e) {
          try {
            var r = await FS.writeFile({ path: name, data: content, directory: 'CACHE', encoding: 'utf8' });
            await SH.share({ title: name, files: [r.uri] });
            return true;
          } catch (e2) { say('Backup save nahi hua'); return false; }
        }
      })();
    },
    shareFile: function (dataUrl, name, type, text) {
      (async function () {
        try {
          var b64 = String(dataUrl).split(',')[1] || '';
          var r = await FS.writeFile({ path: name, data: b64, directory: 'CACHE' });
          await SH.share({ title: name, text: text || '', files: [r.uri] });
        } catch (e) { say('Share nahi hua'); }
      })();
      return true;
    },
    selectContact: function () {
      return (async function () {
        try {
          await CT.requestPermissions();
          var r = await CT.pickContact({ projection: { name: true, phones: true } });
          var c = (r && r.contact) || {};
          var nm = (c.name && (c.name.display || [c.name.given, c.name.family].filter(Boolean).join(' '))) || '';
          var ph = (c.phones && c.phones[0] && c.phones[0].number) || '';
          return { name: nm, phone: ph };
        } catch (e) { return null; }
      })();
    },
    speak: function (text, lang) {
      try { TTS.speak({ text: String(text), lang: lang || 'hi-IN', rate: 1.0, pitch: 1.0, volume: 1.0 }); } catch (e) {}
    },
    stopSpeak: function () { try { TTS.stop(); } catch (e) {} },
    authenticateBiometric: function (cb, reason) {
      (async function () {
        try {
          var info = await BIO.checkBiometry();
          if (!info.isAvailable) { window[cb](false); return; }
          await BIO.authenticate({ reason: reason || 'Fingerprint', cancelTitle: 'Cancel', allowDeviceCredential: true });
          window[cb](true);
        } catch (e) { window[cb](false); }
      })();
    }
  };
  window.Android = window.Android || bridge;

  // Awaaz pehchan (WebView me Web Speech nahi hota) — plugin se banaya
  if (SR && !window.webkitSpeechRecognition && !window.SpeechRecognition) {
    var W = function () { this.lang = 'hi-IN'; this.interimResults = false; this.maxAlternatives = 1; this.continuous = false; };
    W.prototype.start = function () {
      var self = this;
      (async function () {
        try {
          var perm = await SR.requestPermissions();
          if (perm && perm.speechRecognition && perm.speechRecognition !== 'granted') {
            if (self.onerror) self.onerror({ error: 'not-allowed' });
            if (self.onend) self.onend();
            return;
          }
          if (self.onstart) self.onstart();
          var r = await SR.start({ language: self.lang || 'hi-IN', maxResults: 5, prompt: 'Boliye', partialResults: false, popup: true });
          var m = (r && r.matches) || [];
          if (m.length && self.onresult) {
            var alts = m.map(function (t) { return { transcript: t, confidence: 0.9 }; });
            alts.isFinal = true;
            self.onresult({ results: [alts], resultIndex: 0 });
          } else if (self.onerror) self.onerror({ error: 'no-speech' });
        } catch (e) {
          if (self.onerror) self.onerror({ error: 'aborted' });
        }
        if (self.onend) self.onend();
      })();
    };
    W.prototype.stop = W.prototype.abort = function () { try { SR.stop(); } catch (e) {} };
    window.webkitSpeechRecognition = W;
    window.SpeechRecognition = W;
  }
})();
