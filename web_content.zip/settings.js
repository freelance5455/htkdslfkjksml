export const PRESETS = {
  low: { scale:0.36, fogFar:12, grain:0.12, colorBits:4, dither:0.45 },
  medium: { scale:0.52, fogFar:16, grain:0.09, colorBits:5, dither:0.28 },
  high: { scale:0.68, fogFar:21, grain:0.05, colorBits:5, dither:0.16 }
};
const PRESET_KEY='ramenShiftGraphics';
function readPreset(){try{const value=localStorage.getItem(PRESET_KEY);return PRESETS[value]?value:'medium';}catch{return 'medium';}}
export let currentPreset=readPreset();
export function setPreset(name){currentPreset=PRESETS[name]?name:'medium';try{localStorage.setItem(PRESET_KEY,currentPreset);}catch{}return PRESETS[currentPreset];}
