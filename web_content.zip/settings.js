// 12. الإعدادات والتنسيقات
// ========================================


function passwordSettingsHTML() {
  const enabled = !!securityRead();

  return `
    <section class="card" style="margin-top:20px">
      <h3>🔐 الأمان وكلمة المرور</h3>

      <p>
        حالة الحماية:
        <strong style="color:${enabled ? '#22c55e' : '#f59e0b'}">
          ${enabled ? 'مفعّلة' : 'غير مفعّلة'}
        </strong>
      </p>

      ${
        enabled
          ? `
            <button class="bad" type="button"
              onclick="disablePasswordForm()">
              🔓 إلغاء كلمة المرور
            </button>

            <hr>

            <h4>تغيير كلمة المرور</h4>
            <form id="changePasswordForm">
              <label for="oldAppPassword">كلمة المرور الحالية</label>
              <input id="oldAppPassword" type="password" required>

              <label for="newAppPassword">كلمة المرور الجديدة</label>
              <input id="newAppPassword" type="password"
                minlength="4" required>

              <label for="confirmAppPassword">تأكيد كلمة المرور الجديدة</label>
              <input id="confirmAppPassword" type="password"
                minlength="4" required>

              <p id="passwordChangeMessage"></p>

              <button class="primary" type="submit">
                حفظ كلمة المرور الجديدة
              </button>
            </form>
          `
          : `
            <p class="muted">
              الحماية غير مفعّلة. يمكنك إعداد كلمة مرور لحماية البرنامج.
            </p>
            <button class="primary" type="button"
              onclick="enablePasswordSetup()">
              🔒 إضافة كلمة مرور
            </button>
          `
      }
    </section>
  `;
}

function renderSettings(c) {
  const st = db.settings;

  c.innerHTML = `<h2>الإعدادات</h2>

    <div class="card settings-card">
      <div class="field app-name-field">
        <label for="appNameSetting">اسم البرنامج الذي يظهر في الصفحة الرئيسية</label>
        <input id="appNameSetting" value="${esc((st.appName || localStorage.getItem("gameLoungeAppName") || "Game Lounge"))}" maxlength="40" placeholder="اكتب اسم البرنامج">
      </div>
      <div class="field">
        <label for="currency">اسم العملة</label>
        <input id="currency" value="${esc(db.currency)}" maxlength="12">
      </div>

      <div class="settings-grid">
        <div class="field">
          <label for="textColor">لون الخط</label>
          <input id="textColor" type="color" value="${esc(st.textColor)}">
        </div>

        <div class="field">
          <label for="accentColor">اللون الرئيسي والأزرار</label>
          <input id="accentColor" type="color" value="${esc(st.accentColor)}">
        </div>

        <div class="field">
          <label for="backgroundColor">خلفية الصفحة</label>
          <input id="backgroundColor" type="color" value="${esc(st.backgroundColor)}">
        </div>

        <div class="field">
          <label for="fontSize">حجم الخط</label>
          <select id="fontSize">
            <option value="13" ${Number(st.fontSize) === 13 ? "selected" : ""}>صغير</option>
            <option value="15" ${Number(st.fontSize) === 15 ? "selected" : ""}>متوسط</option>
            <option value="17" ${Number(st.fontSize) === 17 ? "selected" : ""}>كبير</option>
            <option value="19" ${Number(st.fontSize) === 19 ? "selected" : ""}>كبير جداً</option>
          </select>
        </div>
      </div>

      <div class="actions">
        <button class="primary" onclick="saveSettings()">حفظ الإعدادات</button>
        <button onclick="resetStyleSettings()">إرجاع التنسيق الافتراضي</button>
      </div>

      <hr>

      <div class="bar">
        <div>
          <b>أسعار ساعات اللعب</b>
          <p class="muted">تحديد السعر الافتراضي لكل نوع جهاز.</p>
        </div>
        <button class="primary" onclick="hourlyRatesForm()">⚙️ أسعار الساعات</button>
      </div>

      <div class="actions">
        <button onclick="backup()">حفظ نسخة احتياطية</button>
        <button onclick="document.getElementById('file').click()">استعادة نسخة</button>
      </div>

      <p class="notice">
        البيانات محفوظة على هذا الجهاز. احتفظ بنسخة احتياطية بشكل دوري.
      </p>

      <hr>
      <button class="bad" onclick="resetDemo()">إعادة ضبط بيانات العرض</button>
      <p class="muted">هذا الزر يحذف بيانات البرنامج بعد تأكيدك.</p>
      <hr>
      ${passwordSettingsHTML()}
    </div>`;
}

function applySettings() {
  const s = db.settings || {};

  // أسماء المتغيرات متوافقة مع style.css.
  document.documentElement.style.setProperty(
    "--text", s.textColor || "#edf4ff"
  );

  document.documentElement.style.setProperty(
    "--accent", s.accentColor || "#52d8e7"
  );

  document.documentElement.style.setProperty(
    "--bg", s.backgroundColor || "#0b1222"
  );

  document.documentElement.style.setProperty(
    "--font-size", (Number(s.fontSize) || 15) + "px"
  );
}

function saveCurrency() {
  saveSettings();
}

function saveSettings() {
  const currencyEl = document.getElementById("currency");
  if (!currencyEl) return;

  const currency = currencyEl.value.trim();

  if (!currency) return notify("أدخل اسم العملة");

  const textColor = document.getElementById("textColor").value;
  const accentColor = document.getElementById("accentColor").value;
  const backgroundColor = document.getElementById("backgroundColor").value;
  const fontSize = Number(document.getElementById("fontSize").value);

  if (![textColor, accentColor, backgroundColor].every(
    color => /^#[0-9a-f]{6}$/i.test(color)
  ) || ![13, 15, 17, 19].includes(fontSize)) {
    return notify("تحقق من إعدادات التنسيق");
  }

  const appName = (document.getElementById("appNameSetting")?.value || "Game Lounge").trim();
  if (!appName) return notify("اكتب اسم البرنامج");
  db.currency = currency;
  db.settings = { ...db.settings, appName, textColor, accentColor, backgroundColor, fontSize };
  localStorage.setItem("gameLoungeAppName", appName);

  try {
    save();
    applySettings();
    render();
    notify("تم حفظ الإعدادات");
  } catch (e) {
    notify("تعذّر حفظ الإعدادات");
  }
}

function resetStyleSettings() {
  if (!confirm("إرجاع ألوان وحجم الخط إلى الوضع الافتراضي؟")) return;

  db.settings = { ...seed.settings };
  save();
  applySettings();
  render();
  notify("تم إرجاع التنسيق الافتراضي");
}

function resetDemo() {
  if (!confirm("سيتم حذف الأجهزة والطلبات والجلسات والمصروفات وأسعار الساعات. هل تريد المتابعة؟")) {
    return;
  }

  db = JSON.parse(JSON.stringify(seed));
  save();
  applySettings();
  render();
  notify("تمت إعادة بيانات البداية");
}

// ========================================
// 13. النسخ الاحتياطي والاستعادة
// ========================================
function backup() {
  try {
    const blob = new Blob(
      [JSON.stringify(db, null, 2)],
      { type: "application/json" }
    );

    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");

    a.href = url;
    a.download = "game-lounge-backup.json";
    a.click();

    setTimeout(() => URL.revokeObjectURL(url), 1000);
    notify("تم تجهيز النسخة الاحتياطية");
  } catch (e) {
    notify("تعذّر إنشاء النسخة الاحتياطية");
  }
}

function restore(e) {
  const file = e.target.files && e.target.files[0];
  if (!file) return;

  const reader = new FileReader();

  reader.onload = () => {
    try {
      const x = JSON.parse(reader.result);

      if (!x || !Array.isArray(x.devices) ||
          !Array.isArray(x.items) || !Array.isArray(x.history)) {
        throw new Error("invalid backup");
      }

      if (!confirm("استعادة النسخة ستستبدل بيانات البرنامج الحالية. هل تريد المتابعة؟")) {
        e.target.value = "";
        return;
      }

      x.expenses = Array.isArray(x.expenses) ? x.expenses : [];
      x.hourlyRates = Object.assign({}, seed.hourlyRates, x.hourlyRates || {});
      x.settings = Object.assign({}, seed.settings, x.settings || {});
      x.id = Number(x.id) || 10;

      db = x;
      save();
      applySettings();
      render();
      notify("تمت استعادة النسخة الاحتياطية");
    } catch (err) {
      notify("الملف غير صالح أو غير متوافق");
    }

    e.target.value = "";
  };

  reader.readAsText(file);
}

// ========================================
// 14. تشغيل البرنامج وتحديث الوقت
// ========================================

/* ===== حماية Game Lounge ===== */
const SECURITY_KEY = "game-lounge-security-v1";

function securityRead() {
  try {
    return JSON.parse(localStorage.getItem(SECURITY_KEY) || "null");
  } catch {
    return null;
  }
}

async function securityHash(value, salt) {
  const data = new TextEncoder().encode(salt + ":" + value);
  const digest = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(digest))
    .map(b => b.toString(16).padStart(2, "0"))
    .join("");
}

function securitySalt() {
  const bytes = crypto.getRandomValues(new Uint8Array(16));
  return Array.from(bytes)
    .map(b => b.toString(16).padStart(2, "0"))
    .join("");
}

function showLockMessage(message) {
  const el = document.getElementById("lockMessage");
  if (el) el.textContent = message;
}

function lockApp() {
  document.getElementById("lockScreen").style.display = "flex";
  document.querySelector(".app").style.visibility = "hidden";
}

function unlockApp() {
  document.getElementById("lockScreen").style.display = "none";
  document.querySelector(".app").style.visibility = "visible";
  applySettings();
  render();
}

function showFirstSetup() {
  const card = document.querySelector(".lock-card");
  card.innerHTML = `
    <div class="lock-logo">G</div>
    <h2>إعداد حماية البرنامج</h2>
    <p>أنشئ كلمة مرور وسؤال أمان للاستعادة</p>
    <form id="setupSecurityForm">
      <label>كلمة المرور الجديدة</label>
      <input id="newSecurityPassword" type="password"
        minlength="4" autocomplete="new-password" required>
      <label>تأكيد كلمة المرور</label>
      <input id="confirmSecurityPassword" type="password"
        minlength="4" autocomplete="new-password" required>
      <label>سؤال الأمان</label>
      <input id="securityQuestion" type="text"
        placeholder="مثلاً: ما اسم مدرستي؟" required>
      <label>جواب الأمان</label>
      <input id="securityAnswer" type="password" required>
      <p id="lockMessage" class="lock-message"></p>
      <button class="primary lock-button" type="submit">حفظ الحماية</button>
    </form>
  `;

  document.getElementById("setupSecurityForm").addEventListener("submit", async e => {
    e.preventDefault();

    const password = document.getElementById("newSecurityPassword").value;
    const confirm = document.getElementById("confirmSecurityPassword").value;
    const question = document.getElementById("securityQuestion").value.trim();
    const answer = document.getElementById("securityAnswer").value.trim();

    if (password !== confirm) {
      showLockMessage("كلمتا المرور غير متطابقتين.");
      return;
    }

    if (password.length < 4 || !question || !answer) {
      showLockMessage("أكمل جميع الحقول، واجعل كلمة المرور 4 أحرف أو أرقام على الأقل.");
      return;
    }

    try {
      const salt = securitySalt();
      const answerSalt = securitySalt();

      localStorage.setItem(SECURITY_KEY, JSON.stringify({
        salt,
        passwordHash: await securityHash(password, salt),
        question,
        answerSalt,
        answerHash: await securityHash(answer.toLowerCase(), answerSalt)
      }));

      unlockApp();
    } catch {
      showLockMessage("تعذر إعداد الحماية على هذا المتصفح.");
    }
  });
}

function showUnlockForm() {
  const card = document.querySelector(".lock-card");
  card.innerHTML = `
    <div class="lock-logo">G</div>
    <h2>Game Lounge</h2>
    <p>أدخل كلمة المرور لفتح البرنامج</p>
    <form id="unlockForm">
      <label>كلمة المرور</label>
      <input id="unlockPassword" type="password"
        autocomplete="current-password" required>
      <p id="lockMessage" class="lock-message"></p>
      <button class="primary lock-button" type="submit">فتح البرنامج</button>
      <button type="button" id="forgotPassword" class="lock-forgot">
        نسيت كلمة المرور؟
      </button>
    </form>
  `;

  document.getElementById("unlockForm").addEventListener("submit", async e => {
    e.preventDefault();
    const security = securityRead();
    if (!security) {
      showFirstSetup();
      return;
    }

    try {
      const password = document.getElementById("unlockPassword").value;
      const hash = await securityHash(password, security.salt);

      if (hash !== security.passwordHash) {
        showLockMessage("كلمة المرور غير صحيحة.");
        return;
      }

      unlockApp();
    } catch {
      showLockMessage("تعذر التحقق من كلمة المرور.");
    }
  });

  document.getElementById("forgotPassword").addEventListener("click", showRecoveryForm);
}

function showRecoveryForm() {
  const security = securityRead();
  if (!security) {
    showFirstSetup();
    return;
  }

  const card = document.querySelector(".lock-card");
  card.innerHTML = `
    <div class="lock-logo">G</div>
    <h2>استعادة كلمة المرور</h2>
    <p>${security.question.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")}</p>
    <form id="recoveryForm">
      <label>جواب الأمان</label>
      <input id="recoveryAnswer" type="password" required>
      <label>كلمة المرور الجديدة</label>
      <input id="recoveryNewPassword" type="password" minlength="4" required>
      <p id="lockMessage" class="lock-message"></p>
      <button class="primary lock-button" type="submit">إعادة تعيين كلمة المرور</button>
      <button type="button" id="backToUnlock" class="lock-forgot">رجوع</button>
    </form>
  `;

  document.getElementById("backToUnlock").addEventListener("click", showUnlockForm);

  document.getElementById("recoveryForm").addEventListener("submit", async e => {
    e.preventDefault();

    try {
      const answer = document.getElementById("recoveryAnswer").value.trim().toLowerCase();
      const newPassword = document.getElementById("recoveryNewPassword").value;

      if (newPassword.length < 4) {
        showLockMessage("كلمة المرور يجب أن تكون 4 أحرف أو أرقام على الأقل.");
        return;
      }

      const answerHash = await securityHash(answer, security.answerSalt);
      if (answerHash !== security.answerHash) {
        showLockMessage("جواب الأمان غير صحيح.");
        return;
      }

      const salt = securitySalt();
      security.salt = salt;
      security.passwordHash = await securityHash(newPassword, salt);
      localStorage.setItem(SECURITY_KEY, JSON.stringify(security));
      showUnlockForm();
      showLockMessage("تم تغيير كلمة المرور. أدخلها الآن.");
    } catch {
      showLockMessage("تعذرت استعادة كلمة المرور.");
    }
  });
}

/* ===== تشغيل البرنامج والمؤقتات ===== */
if (securityRead()) {
  lockApp();

  if (window.crypto && crypto.subtle) {
    showUnlockForm();
  } else {
    showLockMessage("الحماية غير مدعومة في بيئة التشغيل الحالية.");
  }
} else {
  // إذا لم تكن كلمة المرور مفعّلة، افتح البرنامج مباشرةً
  document.getElementById("lockScreen").style.display = "none";
  document.querySelector(".app").style.visibility = "visible";
  applySettings();
  render();
}


setInterval(() => {
  db.devices.forEach(d => {
    const s = d.s;
    if (!s || s.end) return;

    const now = Date.now();
    const timer = document.getElementById("timer" + d.id);

    // حساب وقت اللعب الفعلي دون الاستراحات
    const elapsed = Math.max(
      0,
      (s.pausedAt || now) - s.start - (s.pausedTotal || 0)
    );

    if (timer) {
      timer.textContent = time(elapsed);
    }

    // لا تنه الجلسة تلقائياً أثناء الاستراحة
    if (
      !s.pausedAt &&
      s.minutes &&
      elapsed >= s.minutes * 60000
    ) {
      playTimeUpSound(d.id);
      stop(d.id);
    }
  });
}, 500);

// صوت تنبيه عند انتهاء الوقت المحدد: نغمة قصيرة تتكرر حتى يضغط المستخدم إيقاف
const gameLoungeActiveAlarms = new Map();
function playTimeUpSound(deviceId) {
  if (gameLoungeActiveAlarms.has(deviceId)) return;

  // واجهة واضحة لإيقاف التنبيه
  let panel = document.getElementById("gameLoungeAlarmPanel");
  if (!panel) {
    panel = document.createElement("div");
    panel.id = "gameLoungeAlarmPanel";
    panel.setAttribute("role", "alertdialog");
    panel.style.cssText = "position:fixed;z-index:99999;left:16px;right:16px;bottom:20px;padding:18px;border-radius:16px;background:#171b2e;color:#fff;border:2px solid #8b5cf6;box-shadow:0 8px 30px #0009;text-align:center;font-family:inherit";
    document.body.appendChild(panel);
  }
  const device = db.devices.find(x => x.id === deviceId);
  panel.innerHTML = `<div style="font-size:18px;font-weight:700;margin-bottom:8px">🔔 انتهى الوقت المحدد${device ? ` — ${String(device.name).replace(/[&<>\"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[c]))}` : ""}</div><div style="margin-bottom:12px">يرجى إيقاف التنبيه بعد الانتباه إليه.</div><button id="gameLoungeStopAlarm" style="padding:10px 22px;border:0;border-radius:10px;background:#8b5cf6;color:white;font-weight:700">إيقاف التنبيه</button>`;
  document.getElementById("gameLoungeStopAlarm").onclick = () => stopTimeUpAlarm(deviceId);

  const alarm = { timer: null, ctx: null };
  gameLoungeActiveAlarms.set(deviceId, alarm);
  const ring = () => {
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return;
      if (!alarm.ctx || alarm.ctx.state === "closed") alarm.ctx = new AudioCtx();
      if (alarm.ctx.state === "suspended") alarm.ctx.resume().catch(() => {});
      const ctx = alarm.ctx;
      // نغمة أوضح وأعلى: موجة مربعة مع مستوى صوت أعلى داخل حدود المتصفح
      [1046, 784, 1046].forEach((frequency, index) => {
        const oscillator = ctx.createOscillator();
        const gain = ctx.createGain();
        const at = ctx.currentTime + index * 0.24;
        oscillator.type = "square";
        oscillator.frequency.value = frequency;
        gain.gain.setValueAtTime(0.0001, at);
        gain.gain.exponentialRampToValueAtTime(0.72, at + 0.018);
        gain.gain.setValueAtTime(0.72, at + 0.14);
        gain.gain.exponentialRampToValueAtTime(0.0001, at + 0.21);
        oscillator.connect(gain); gain.connect(ctx.destination);
        oscillator.start(at); oscillator.stop(at + 0.22);
      });
    } catch (error) { console.warn("تعذر تشغيل صوت انتهاء الوقت", error); }
  };
  ring();
  alarm.timer = setInterval(ring, 2500);
}

function stopTimeUpAlarm(deviceId) {
  const alarm = gameLoungeActiveAlarms.get(deviceId);
  if (alarm) {
    clearInterval(alarm.timer);
    if (alarm.ctx && alarm.ctx.state !== "closed") alarm.ctx.close().catch(() => {});
    gameLoungeActiveAlarms.delete(deviceId);
  }
  // إذا ما عاد في تنبيهات، أخفِ لوحة التنبيه
  if (gameLoungeActiveAlarms.size === 0) {
    const panel = document.getElementById("gameLoungeAlarmPanel");
    if (panel) panel.remove();
  } else {
    const panel = document.getElementById("gameLoungeAlarmPanel");
    if (panel) panel.querySelector("div").textContent = "🔔 انتهى الوقت المحدد";
  }
}

// تغيير كلمة المرور من صفحة الإعدادات
document.addEventListener("submit", async function (event) {
  if (!event.target || event.target.id !== "changePasswordForm") return;

  event.preventDefault();

  const message = document.getElementById("passwordChangeMessage");
  const saved = securityRead();

  if (!saved) {
    if (message) message.textContent = "الحماية غير مفعّلة.";
    return;
  }

  const oldPassword = document.getElementById("oldAppPassword").value;
  const newPassword = document.getElementById("newAppPassword").value;
  const confirmPassword = document.getElementById("confirmAppPassword").value;

  if (newPassword.length < 4) {
    if (message) message.textContent = "كلمة المرور الجديدة يجب أن تكون 4 أحرف أو أرقام على الأقل.";
    return;
  }

  if (newPassword !== confirmPassword) {
    if (message) message.textContent = "كلمتا المرور الجديدتان غير متطابقتين.";
    return;
  }

  try {
    const oldHash = await securityHash(oldPassword, saved.salt);

    if (oldHash !== saved.passwordHash) {
      if (message) message.textContent = "كلمة المرور الحالية غير صحيحة.";
      return;
    }

    const newSalt = securitySalt();
    saved.salt = newSalt;
    saved.passwordHash = await securityHash(newPassword, newSalt);
    localStorage.setItem(SECURITY_KEY, JSON.stringify(saved));

    notify("تم تغيير كلمة المرور بنجاح");
    render();
  } catch (error) {
    if (message) message.textContent = "تعذر تغيير كلمة المرور. حاول مرة أخرى.";
  }
});

function enablePasswordSetup() {
  if (!window.crypto || !crypto.subtle) {
    alert("ميزة كلمة المرور غير مدعومة في بيئة التشغيل الحالية.");
    return;
  }

  lockApp();
  showFirstSetup();
}

function disablePasswordForm() {
  modal(`
    <h3>🔓 إلغاء كلمة المرور</h3>
    <p>أدخل كلمة المرور الحالية لإلغاء الحماية.</p>

    <form id="disablePasswordForm">
      <input
        id="disableCurrentPassword"
        type="password"
        placeholder="كلمة المرور الحالية"
        required
      >

      <p id="disablePasswordMessage"></p>

      <button class="bad" type="submit">
        تأكيد إلغاء كلمة المرور
      </button>

      <button type="button" onclick="closemodal()">
        تراجع
      </button>
    </form>
  `);

  document.getElementById("disablePasswordForm")
    .addEventListener("submit", confirmDisablePassword);
}

async function confirmDisablePassword(event) {
  event.preventDefault();

  const password =
    document.getElementById("disableCurrentPassword").value;

  const saved = securityRead();

  if (!saved) {
    closemodal();
    render();
    return;
  }

  try {
    const hash = await securityHash(password, saved.salt);

    if (hash !== saved.passwordHash) {
      document.getElementById("disablePasswordMessage").textContent =
        "كلمة المرور غير صحيحة.";
      return;
    }

    if (!confirm("هل تريد إلغاء حماية البرنامج بكلمة المرور؟")) {
      return;
    }

    localStorage.removeItem(SECURITY_KEY);
    closemodal();

    document.getElementById("lockScreen").style.display = "none";
    document.querySelector(".app").style.visibility = "visible";

    applySettings();
    render();
  } catch (error) {
    alert("حدث خطأ أثناء التحقق من كلمة المرور.");
  }
}
