export const PRESETS = {
  low: { scale:0.36, fogFar:12, grain:0.12, colorBits:4, dither:0.45 },
  medium: { scale:0.52, fogFar:16, grain:0.09, colorBits:5, dither:0.28 },
  high: { scale:0.68, fogFar:21, grain:0.05, colorBits:5, dither:0.16 }
};
export let currentPreset='medium';
export function setPreset(name){currentPreset=PRESETS[name]?name:'medium';return PRESETS[currentPreset];}
