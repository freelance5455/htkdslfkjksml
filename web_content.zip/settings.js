"use strict";

const MUEEN_NOTIFICATIONS_DISABLED = true;


/* =========================================================
   MUEEN SETTINGS
========================================================= */


/* =========================================================
   STORAGE KEYS
========================================================= */

const NOTIFICATION_SETTINGS_KEY =
    "mueen_notification_settings";

const LAST_BACKUP_KEY =
    "mueen_last_backup";

const TERM_STATUS_KEY =
    "mueen_term_status";


/* =========================================================
   DEFAULT SETTINGS
========================================================= */

const DEFAULT_NOTIFICATION_SETTINGS = {

    enabled: false,

    reminderMinutes: 15

};


const DEFAULT_TERM_STATUS =
    "active";


/* =========================================================
   DOM
========================================================= */

const notificationsToggle =
    document.getElementById(
        "notificationsToggle"
    );


const notificationOptions =
    document.getElementById(
        "notificationOptions"
    );


const reminderMinutes =
    document.getElementById(
        "reminderMinutes"
    );


const termActive =
    document.getElementById(
        "termActive"
    );


const termVacation =
    document.getElementById(
        "termVacation"
    );


const vacationMessagePreview =
    document.getElementById(
        "vacationMessagePreview"
    );


const newTermButton =
    document.getElementById(
        "newTermButton"
    );


const backupButton =
    document.getElementById(
        "backupButton"
    );


const restoreButton =
    document.getElementById(
        "restoreButton"
    );


const lastBackup =
    document.getElementById(
        "lastBackup"
    );


const backButton =
    document.getElementById(
        "backButton"
    );

const settingsSubjectsList =
    document.getElementById("settingsSubjectsList");

const addSettingsSubjectButton =
    document.getElementById("addSettingsSubjectButton");

const settingsSubjectModal =
    document.getElementById("settingsSubjectModal");

const settingsSubjectModalTitle =
    document.getElementById("settingsSubjectModalTitle");

const settingsSubjectName =
    document.getElementById("settingsSubjectName");

const closeSettingsSubjectModal =
    document.getElementById("closeSettingsSubjectModal");

const cancelSettingsSubject =
    document.getElementById("cancelSettingsSubject");

const saveSettingsSubject =
    document.getElementById("saveSettingsSubject");

const restoreBackupFile =
    document.getElementById("restoreBackupFile");
const exportAllDataButton =
    document.getElementById("exportAllDataButton");

// أزرار Google Drive اختيارية في بعض إصدارات واجهة الإعدادات.
// تعريفها صراحة يمنع توقف بقية أحداث الصفحة إذا لم تكن موجودة في HTML.
const backupDriveButton =
    document.getElementById("backupDriveButton");

const restoreDriveButton =
    document.getElementById("restoreDriveButton");

let editingSettingsSubjectId = null;


/* =========================================================
   SAFE JSON
========================================================= */

function readJSON(
    key,
    fallback
) {

    try {

        const value =
            localStorage.getItem(key);

        if (!value) {

            return fallback;

        }


        return JSON.parse(value);

    } catch (error) {

        console.warn(
            "Mueen settings read error:",
            error
        );

        return fallback;

    }

}


/* =========================================================
   NOTIFICATION SETTINGS
========================================================= */

function getNotificationSettings() {

    const saved =
        readJSON(
            NOTIFICATION_SETTINGS_KEY,
            DEFAULT_NOTIFICATION_SETTINGS
        );


    return {

        enabled:
            saved.enabled === true,

        reminderMinutes:
            [5, 10, 15, 20, 30, 45, 60]
                .includes(
                    Number(
                        saved.reminderMinutes
                    )
                )
                ? Number(
                    saved.reminderMinutes
                )
                : 15

    };

}


/* =========================================================
   SAVE NOTIFICATION SETTINGS
========================================================= */

function saveNotificationSettings(
    settings
) {

    const normalized = {

        enabled:
            settings.enabled === true,

        reminderMinutes:
            [5, 10, 15, 20, 30, 45, 60]
                .includes(
                    Number(
                        settings.reminderMinutes
                    )
                )
                ? Number(
                    settings.reminderMinutes
                )
                : 15

    };


    localStorage.setItem(

        NOTIFICATION_SETTINGS_KEY,

        JSON.stringify(
            normalized
        )

    );


    return normalized;

}


/* =========================================================
   SUBJECTS
========================================================= */

function getSettingsSubjects() {
    try {
        const value = localStorage.getItem("mueen_subjects");
        const parsed = value ? JSON.parse(value) : [];
        return Array.isArray(parsed) ? parsed : [];
    } catch (_) {
        return [];
    }
}

function saveSettingsSubjects(subjects) {
    localStorage.setItem(
        "mueen_subjects",
        JSON.stringify(subjects)
    );
}

function renderSettingsSubjects() {
    if (!settingsSubjectsList) return;

    const subjects = getSettingsSubjects();

    if (!subjects.length) {
        settingsSubjectsList.innerHTML =
            '<div class="settings-empty">لم تتم إضافة مواد بعد.</div>';
        return;
    }

    settingsSubjectsList.innerHTML =
        subjects.map(subject => `
            <div class="settings-subject-row">
                <span class="settings-subject-name">${escapeSettingsHtml(subject.name)}</span>
                <div class="settings-subject-actions">
                    <button type="button" data-edit-settings-subject="${escapeSettingsHtml(subject.id)}" aria-label="تعديل">✎</button>
                    <button type="button" data-delete-settings-subject="${escapeSettingsHtml(subject.id)}" aria-label="حذف">×</button>
                </div>
            </div>
        `).join("");
}

function escapeSettingsHtml(value) {
    return String(value ?? "")
        .replaceAll("&","&amp;")
        .replaceAll("<","&lt;")
        .replaceAll(">","&gt;")
        .replaceAll('"',"&quot;")
        .replaceAll("'","&#039;");
}

function openSettingsSubjectModal(id = null) {
    editingSettingsSubjectId = id;

    if (settingsSubjectModalTitle) {
        settingsSubjectModalTitle.textContent =
            id ? "تعديل المادة" : "إضافة مادة";
    }

    if (settingsSubjectName) {
        const subject =
            getSettingsSubjects().find(
                item => String(item.id) === String(id)
            );
        settingsSubjectName.value = subject ? subject.name : "";
    }

    if (settingsSubjectModal) {
        settingsSubjectModal.hidden = false;
        settingsSubjectModal.setAttribute("aria-hidden", "false");
    }

    setTimeout(() => settingsSubjectName?.focus(), 60);
}

function closeSettingsSubjectModalWindow() {
    if (settingsSubjectModal) {
        settingsSubjectModal.hidden = true;
        settingsSubjectModal.setAttribute("aria-hidden", "true");
    }
    editingSettingsSubjectId = null;
    if (settingsSubjectName) settingsSubjectName.value = "";
}

function saveSettingsSubjectValue() {
    const name = settingsSubjectName?.value.trim();

    if (!name) {
        alert("يرجى كتابة اسم المادة.");
        return;
    }

    const subjects = getSettingsSubjects();

    const duplicate = subjects.some(
        item =>
            item.name.trim() === name &&
            String(item.id) !== String(editingSettingsSubjectId)
    );

    if (duplicate) {
        alert("هذه المادة موجودة بالفعل.");
        return;
    }

    if (editingSettingsSubjectId) {
        const index = subjects.findIndex(
            item => String(item.id) === String(editingSettingsSubjectId)
        );
        if (index !== -1) subjects[index].name = name;
    } else {
        subjects.push({
            id: Date.now().toString(),
            name,
            createdAt: new Date().toISOString()
        });
    }

    saveSettingsSubjects(subjects);
    renderSettingsSubjects();
    closeSettingsSubjectModalWindow();
}

function deleteSettingsSubject(id) {
    const subjects = getSettingsSubjects();
    const subject = subjects.find(
        item => String(item.id) === String(id)
    );

    if (!subject) return;

    if (!confirm(`هل تريد حذف مادة "${subject.name}"؟`)) return;

    saveSettingsSubjects(
        subjects.filter(
            item => String(item.id) !== String(id)
        )
    );

    renderSettingsSubjects();
}

/* =========================================================
   TERM STATUS
========================================================= */

function getTermStatus() {

    const value =
        localStorage.getItem(
            TERM_STATUS_KEY
        );


    if (
        value === "vacation"
    ) {

        return "vacation";

    }


    return "active";

}


/* =========================================================
   SAVE TERM STATUS
========================================================= */

function saveTermStatus(
    status
) {

    const normalized =
        status === "vacation"
            ? "vacation"
            : "active";


    localStorage.setItem(

        TERM_STATUS_KEY,

        normalized

    );


    return normalized;

}


/* =========================================================
   UPDATE TERM UI
========================================================= */

function updateTermStatusUI() {

    const status =
        getTermStatus();


    if (termActive) {

        termActive.checked =
            status === "active";

    }


    if (termVacation) {

        termVacation.checked =
            status === "vacation";

    }


    if (vacationMessagePreview) {

        vacationMessagePreview.hidden =
            status !== "vacation";

    }


    if (newTermButton) {

        newTermButton.hidden =
            status !== "vacation";

    }

}


/* =========================================================
   TERM CHANGE
========================================================= */

function handleTermStatusChange(
    event
) {

    const value =
        event.target.value;


    const status =
        saveTermStatus(
            value
        );


    updateTermStatusUI();


    /*
       إشعار الصفحات الأخرى بأن حالة الترم تغيرت.
    */

    window.dispatchEvent(
        new CustomEvent(
            "mueen-term-status-changed",
            {
                detail: {
                    status
                }
            }
        )
    );


    /*
       تحديث home.js إذا كانت الصفحة الرئيسية
       مفتوحة في نفس السياق.
    */

    try {

        if (
            window.parent &&
            window.parent !== window
        ) {

            window.parent.dispatchEvent(
                new CustomEvent(
                    "mueen-term-status-changed",
                    {
                        detail: {
                            status
                        }
                    }
                )
            );

        }

    } catch (error) {

        console.warn(
            "Mueen term event:",
            error
        );

    }

}


/* =========================================================
   NEW TERM
========================================================= */

function handleNewTerm() {

    const confirmed =
        window.confirm(
            "هل تريد بدء ترم جديد؟\n\nسيعود مُعين إلى الوضع الدراسي العادي."
        );


    if (!confirmed) {

        return;

    }


    saveTermStatus(
        "active"
    );


    updateTermStatusUI();


    window.dispatchEvent(
        new CustomEvent(
            "mueen-term-status-changed",
            {
                detail: {
                    status: "active"
                }
            }
        )
    );


    window.alert(
        "تم بدء الترم الجديد بنجاح."
    );

}


/* =========================================================
   NOTIFICATION MANAGER
========================================================= */

function getNotificationManager() {

    if (
        window.MueenNotifications
    ) {

        return window.MueenNotifications;

    }


    return null;

}


/* =========================================================
   UPDATE NOTIFICATION UI
========================================================= */

function updateNotificationUI() {

    const settings =
        getNotificationSettings();


    if (notificationsToggle) {

        notificationsToggle.checked =
            settings.enabled;

    }


    if (reminderMinutes) {

        reminderMinutes.value =
            String(
                settings.reminderMinutes
            );

    }


    if (notificationOptions) {

        notificationOptions.hidden =
            !settings.enabled;

    }

}


/* =========================================================
   ENABLE NOTIFICATIONS
========================================================= */

async function enableNotifications() {

    if (MUEEN_NOTIFICATIONS_DISABLED) {
        saveNotificationSettings({
            enabled: false,
            reminderMinutes: 15
        });
        updateNotificationUI();
        return null;
    }


    const manager =
        getNotificationManager();


    if (!manager) {

        const settings =
            saveNotificationSettings({

                enabled: true,

                reminderMinutes:
                    Number(
                        reminderMinutes?.value ||
                        15
                    )

            });


        updateNotificationUI();

        return settings;

    }


    try {

        const permission =
            await manager.requestPermission();


        if (
            permission !== "granted"
        ) {

            if (notificationsToggle) {

                notificationsToggle.checked =
                    false;

            }


            saveNotificationSettings({

                enabled: false,

                reminderMinutes:
                    Number(
                        reminderMinutes?.value ||
                        15
                    )

            });


            updateNotificationUI();


            window.alert(
                "لم يتم السماح بالإشعارات. يمكنك السماح بها من إعدادات الجهاز عند الحاجة."
            );


            return null;

        }


        const settings =
            saveNotificationSettings({

                enabled: true,

                reminderMinutes:
                    Number(
                        reminderMinutes?.value ||
                        15
                    )

            });


        if (
            typeof manager.setReminderMinutes ===
            "function"
        ) {

            manager.setReminderMinutes(
                settings.reminderMinutes
            );

        }


        if (
            typeof manager.enable ===
            "function"
        ) {

            manager.enable();

        }


        updateNotificationUI();


        return settings;

    } catch (error) {

        console.error(
            "Mueen notification enable error:",
            error
        );


        saveNotificationSettings({

            enabled: false,

            reminderMinutes:
                Number(
                    reminderMinutes?.value ||
                    15
                )

        });


        updateNotificationUI();


        window.alert(
            "تعذر تفعيل الإشعارات حاليًا."
        );


        return null;

    }

}


/* =========================================================
   DISABLE NOTIFICATIONS
========================================================= */

function disableNotifications() {

    if (MUEEN_NOTIFICATIONS_DISABLED) {
        saveNotificationSettings({
            enabled: false,
            reminderMinutes: 15
        });
        updateNotificationUI();
        return null;
    }


    const settings =
        saveNotificationSettings({

            enabled: false,

            reminderMinutes:
                Number(
                    reminderMinutes?.value ||
                    15
                )

        });


    const manager =
        getNotificationManager();


    if (
        manager &&
        typeof manager.disable ===
        "function"
    ) {

        manager.disable();

    }


    updateNotificationUI();


    return settings;

}


/* =========================================================
   TOGGLE NOTIFICATIONS
========================================================= */

async function handleNotificationsToggle() {

    if (MUEEN_NOTIFICATIONS_DISABLED) {
        saveNotificationSettings({
            enabled: false,
            reminderMinutes: 15
        });
        updateNotificationUI();
        return null;
    }


    if (
        !notificationsToggle
    ) {

        return;

    }


    if (
        notificationsToggle.checked
    ) {

        await enableNotifications();

    } else {

        disableNotifications();

    }

}


/* =========================================================
   REMINDER MINUTES
========================================================= */

function handleReminderMinutesChange() {

    if (MUEEN_NOTIFICATIONS_DISABLED) {
        saveNotificationSettings({
            enabled: false,
            reminderMinutes: 15
        });
        updateNotificationUI();
        return null;
    }


    const minutes =
        Number(
            reminderMinutes?.value ||
            15
        );


    const settings =
        saveNotificationSettings({

            enabled:
                notificationsToggle?.checked === true,

            reminderMinutes:
                minutes

        });


    const manager =
        getNotificationManager();


    if (
        manager &&
        typeof manager.setReminderMinutes ===
        "function"
    ) {

        manager.setReminderMinutes(
            settings.reminderMinutes
        );

    }


    updateNotificationUI();

}


/* =========================================================
   LAST BACKUP
========================================================= */

function updateLastBackupUI() {

    if (!lastBackup) {

        return;

    }


    const saved =
        localStorage.getItem(
            LAST_BACKUP_KEY
        );


    if (!saved) {

        lastBackup.textContent =
            "لم يتم إنشاء نسخة بعد";

        return;

    }


    const date =
        new Date(
            saved
        );


    if (
        Number.isNaN(
            date.getTime()
        )
    ) {

        lastBackup.textContent =
            "لم يتم إنشاء نسخة بعد";

        return;

    }


    lastBackup.textContent =
        date.toLocaleString(
            "ar-EG",
            {
                dateStyle: "medium",
                timeStyle: "short"
            }
        );

}


/* =========================================================
   COLLECT BACKUP DATA
========================================================= */

function collectBackupData() {

    const data = {

        version:
            1,

        app:
            "MUEEN",

        createdAt:
            new Date().toISOString(),

        localStorage: {}

    };


    for (
        let index = 0;
        index < localStorage.length;
        index++
    ) {

        const key =
            localStorage.key(
                index
            );


        if (!key) {

            continue;

        }


        data.localStorage[key] =
            localStorage.getItem(
                key
            );

    }


    return data;

}


/* =========================================================
   BACKUP NOW
========================================================= */

function downloadOrShareBackupFile(data) {
    const json = JSON.stringify(data, null, 2);
    const blob = new Blob([json], { type: "application/json;charset=utf-8" });
    const filename =
        "MUEEN-Backup-" +
        new Date().toISOString().slice(0, 10) +
        ".json";

    try {
        const file = new File([blob], filename, {
            type: "application/json"
        });

        if (
            navigator.share &&
            navigator.canShare &&
            navigator.canShare({ files: [file] })
        ) {
            navigator.share({
                title: "نسخة احتياطية من مُعين",
                text: "نسخة احتياطية لبيانات تطبيق مُعين",
                files: [file]
            }).catch(() => {});
            return true;
        }
    } catch (_) {}

    try {
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = url;
        link.target = "_blank";
        link.rel = "noopener";
        document.body.appendChild(link);
        link.click();
        setTimeout(() => {
            link.remove();
            URL.revokeObjectURL(url);
        }, 1500);
        return true;
    } catch (error) {
        console.error("Mueen backup file error:", error);
        return false;
    }
}

function exportAllMueenData() {
    const data = collectBackupData();
    const json = JSON.stringify(data, null, 2);
    const blob = new Blob(
        [json],
        { type: "application/json;charset=utf-8" }
    );
    const filename =
        "MUEEN-All-Data-" +
        new Date().toISOString().slice(0, 10) +
        ".json";

    try {
        const file = new File(
            [blob],
            filename,
            { type: "application/json" }
        );

        if (
            navigator.share &&
            navigator.canShare &&
            navigator.canShare({ files: [file] })
        ) {
            navigator.share({
                title: "كل بيانات مُعين",
                text: "تصدير كامل لبيانات تطبيق مُعين",
                files: [file]
            }).catch(() => {});
            return;
        }
    } catch (_) {}

    try {
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = url;
        link.target = "_blank";
        link.rel = "noopener";
        document.body.appendChild(link);
        link.click();

        setTimeout(() => {
            link.remove();
            URL.revokeObjectURL(url);
        }, 1500);

        window.alert(
            "تم تجهيز ملف بيانات مُعين بالكامل."
        );
    } catch (error) {
        console.error(
            "Mueen full export error:",
            error
        );
        window.alert(
            "تعذر تصدير بيانات مُعين."
        );
    }
}

async function handleDriveBackup() {
    if (!window.MueenNative?.available || typeof window.MueenNative.backupToDrive !== "function") {
        window.MueenUI.alert(
            "النسخ إلى Google Drive يحتاج نسخة Android مزودة بجسر Google Drive. تم تجهيز التطبيق لاستدعاء الجسر تلقائيًا عند تحويله إلى APK.",
            "Google Drive"
        );
        return;
    }

    const ok = await window.MueenUI.confirm(
        "سيتم اختيار حساب Google من الهاتف عند بدء النسخ، ثم إنشاء نسخة احتياطية كاملة من بيانات مُعين على Google Drive.",
        "النسخ الاحتياطي السحابي",
        "بدء النسخ"
    );
    if (!ok) return;

    try {
        const data = collectBackupData();
        const filename = "MUEEN-Backup-" + new Date().toISOString().slice(0,10) + ".json";
        await window.MueenNative.backupToDrive(JSON.stringify(data), filename);

        localStorage.setItem(LAST_BACKUP_KEY, new Date().toISOString());
        localStorage.setItem("mueen_last_backup_data", JSON.stringify(data));
        updateLastBackupUI();

        window.MueenUI.toast("تم حفظ النسخة الاحتياطية على Google Drive.", "success");
    } catch (error) {
        console.error("MUEEN Drive backup:", error);
        window.MueenUI.alert("تعذر إنشاء النسخة على Google Drive. تأكد من تسجيل الدخول ومنح التطبيق صلاحية الوصول إلى Drive.", "تعذر النسخ");
    }
}

async function handleDriveRestore() {
    if (!window.MueenNative?.available || typeof window.MueenNative.restoreFromDrive !== "function") {
        window.MueenUI.alert(
            "استعادة البيانات من Google Drive تحتاج نسخة Android مزودة بجسر Google Drive. تم تجهيز التطبيق لاستدعاء الجسر تلقائيًا عند تحويله إلى APK.",
            "Google Drive"
        );
        return;
    }

    try {
        const raw = await Promise.resolve(window.MueenNative.restoreFromDrive());
        if (!raw) {
            window.MueenUI.toast("لم يتم اختيار نسخة احتياطية.", "info");
            return;
        }

        const backup = typeof raw === "string" ? JSON.parse(raw) : raw;
        const ok = await window.MueenUI.confirm(
            "سيتم استبدال بيانات مُعين الحالية بالنسخة المختارة من Google Drive.\nيُنصح بإنشاء نسخة حالية قبل المتابعة.",
            "تأكيد الاستعادة",
            "استعادة البيانات"
        );
        if (!ok) return;

        restoreBackupObject(backup);
        window.MueenUI.toast("تمت استعادة بيانات مُعين بنجاح.", "success");
    } catch (error) {
        console.error("MUEEN Drive restore:", error);
        window.MueenUI.alert("تعذر استعادة النسخة. قد تكون غير صالحة أو لم يتم اختيار نسخة.", "تعذر الاستعادة");
    }
}

function handleBackup() {
    const data = collectBackupData();

    try {
        localStorage.setItem(
            "mueen_last_backup_data",
            JSON.stringify(data)
        );

        localStorage.setItem(
            LAST_BACKUP_KEY,
            new Date().toISOString()
        );

        updateLastBackupUI();

        const sharedOrDownloaded =
            downloadOrShareBackupFile(data);

        if (sharedOrDownloaded) {
            window.MueenUI.toast("تم إنشاء النسخة الاحتياطية وتجهيز ملفها للحفظ.", "success");
        } else {
            window.MueenUI.alert("تم حفظ النسخة داخل مُعين، لكن تعذر إنشاء ملف خارجي على هذا الجهاز.", "تعذر الحفظ الخارجي");
        }
    } catch (error) {
        console.error("Mueen backup error:", error);
        window.MueenUI.alert("تعذر إنشاء النسخة الاحتياطية.", "تعذر النسخ");
    }
}


/* =========================================================
   RESTORE BACKUP
========================================================= */

function restoreBackupObject(backup) {
    if (!backup || backup.app !== "MUEEN" || !backup.localStorage) {
        throw new Error("Invalid backup");
    }

    Object.keys(backup.localStorage).forEach(key => {
        localStorage.setItem(
            key,
            backup.localStorage[key]
        );
    });

    updateNotificationUI();
    updateTermStatusUI();
    updateLastBackupUI();
    renderSettingsSubjects();
}

function handleRestore() {
    if (restoreBackupFile) {
        restoreBackupFile.value = "";
        restoreBackupFile.click();
        return;
    }

    const saved =
        localStorage.getItem("mueen_last_backup_data");

    if (!saved) {
        window.alert("لا توجد نسخة احتياطية محلية جاهزة للاستعادة.");
        return;
    }

    try {
        restoreBackupObject(JSON.parse(saved));
        window.alert("تمت استعادة النسخة الاحتياطية بنجاح.");
    } catch (error) {
        console.error("Mueen restore error:", error);
        window.alert("تعذر قراءة النسخة الاحتياطية.");
    }
}



/* SUPABASE BACKUP */
function setupSupabaseBackup() {
    const backup = document.getElementById("supabaseBackupButton");
    const restore = document.getElementById("supabaseRestoreButton");
    const status = document.getElementById("supabaseBackupStatus");
    const setStatus = text => { if (status) status.textContent = text; };
    backup?.addEventListener("click", async () => {
        if (!navigator.onLine) { setStatus("يلزم الاتصال بالإنترنت لإجراء النسخ الاحتياطي."); return; }
        try {
            if (!window.MueenSupabaseBackup?.ready()) throw new Error("SUPABASE_NOT_CONFIGURED");
            setStatus("جاري رفع بيانات مُعين...");
            await window.MueenSupabaseBackup.backup();
            setStatus("تم تحديث النسخة الاحتياطية السحابية بنجاح.");
            window.MueenUI?.toast?.("تم إنشاء النسخة الاحتياطية بنجاح.", "success");
        } catch (e) { console.error(e); setStatus(e.message === "SUPABASE_NOT_CONFIGURED" ? "لم يتم إعداد اتصال Supabase بعد." : "تعذر إنشاء النسخة الاحتياطية الآن."); }
    });
    restore?.addEventListener("click", async () => {
        if (!navigator.onLine) { setStatus("يلزم الاتصال بالإنترنت لاستعادة البيانات."); return; }
        try {
            if (!window.MueenSupabaseBackup?.ready()) throw new Error("SUPABASE_NOT_CONFIGURED");
            const ok = await (window.MueenUI?.confirm?.("سيتم استبدال البيانات المحلية بالنسخة السحابية الحالية. هل تريد المتابعة؟", "تأكيد الاستعادة", "استعادة") ?? true);
            if (!ok) return;
            setStatus("جاري استعادة بيانات مُعين...");
            await window.MueenSupabaseBackup.restore();
            setStatus("تمت الاستعادة بنجاح.");
            window.MueenUI?.toast?.("تمت استعادة البيانات بنجاح.", "success");
            setTimeout(() => location.reload(), 700);
        } catch (e) { console.error(e); setStatus(e.message === "SUPABASE_NOT_CONFIGURED" ? "لم يتم إعداد اتصال Supabase بعد." : e.message === "NO_BACKUP" ? "لا توجد نسخة سحابية محفوظة بعد." : "تعذر استعادة النسخة الاحتياطية الآن."); }
    });
}

/* =========================================================
   NAVIGATION
========================================================= */

function navigateTo(
    page
) {

    window.location.href =
        page;

}


/* =========================================================
   BOTTOM NAVIGATION
   EXACT SAME PAGES AS HOME
========================================================= */

function setupNavigation() {

    const navigationMap = {

        homeNavigation:
            "home.html",

        attendanceNavigation:
            "attendance.html",

        studentsNavigation:
            "students.html",

        scheduleNavigation:
            "schedule.html",

        gradesNavigation:
            "grades.html",

        reportsNavigation:
            "reports.html"

    };


    Object.entries(
        navigationMap
    ).forEach(
        (
            [
                id,
                page
            ]
        ) => {

            const button =
                document.getElementById(
                    id
                );


            if (!button) {

                return;

            }


            button.addEventListener(
                "click",
                () => {

                    navigateTo(
                        page
                    );

                }
            );

        }
    );

}


/* =========================================================
   BACK BUTTON
========================================================= */

function setupBackButton() {

    if (!backButton) {

        return;

    }


    backButton.addEventListener(
        "click",
        () => {

            /*
               نعود للصفحة السابقة إن وجدت،
               وإلا نعود للرئيسية.
            */

            if (
                window.history.length > 1
            ) {

                window.history.back();

            } else {

                navigateTo(
                    "home.html"
                );

            }

        }
    );

}


/* =========================================================
   STORAGE EVENT
========================================================= */

function handleStorageChange(
    event
) {

    if (
        event.key ===
        NOTIFICATION_SETTINGS_KEY
    ) {

        updateNotificationUI();

    }


    if (
        event.key ===
        TERM_STATUS_KEY
    ) {

        updateTermStatusUI();

    }


    if (
        event.key ===
        LAST_BACKUP_KEY
    ) {

        updateLastBackupUI();

    }

}


/* =========================================================
   CUSTOM TERM EVENT
========================================================= */

function setupTermEventListener() {

    window.addEventListener(

        "mueen-term-status-changed",

        () => {

            updateTermStatusUI();

        }

    );

}


/* =========================================================
   SETUP EVENTS
========================================================= */

function setupEvents() {
if (
        termActive
    ) {

        termActive.addEventListener(

            "change",

            handleTermStatusChange

        );

    }


    if (
        termVacation
    ) {

        termVacation.addEventListener(

            "change",

            handleTermStatusChange

        );

    }


    if (
        newTermButton
    ) {

        newTermButton.addEventListener(

            "click",

            handleNewTerm

        );

    }
if (restoreBackupFile) {
        restoreBackupFile.addEventListener(
            "change",
            async event => {
                const file = event.target.files?.[0];
                if (!file) return;

                try {
                    const text = await file.text();
                    const backup = JSON.parse(text);

                    if (
                        !backup ||
                        backup.app !== "MUEEN" ||
                        !backup.localStorage
                    ) {
                        throw new Error("Invalid backup");
                    }

                    const confirmed =
                        await window.MueenUI.confirm(
                            "سيتم استبدال بيانات مُعين الحالية بالنسخة المختارة. يُنصح بإنشاء نسخة حالية قبل المتابعة.",
                            "تأكيد الاستعادة",
                            "استعادة البيانات"
                        );

                    if (!confirmed) {
                        return;
                    }

                    restoreBackupObject(backup);
                    window.MueenUI.toast("تمت استعادة النسخة الاحتياطية بنجاح.", "success");
                } catch (error) {
                    console.error("Mueen backup file restore:", error);
                    window.alert("ملف النسخة الاحتياطية غير صالح أو تالف.");
                }
            }
        );
    }

    if (addSettingsSubjectButton) {
        addSettingsSubjectButton.addEventListener(
            "click",
            () => openSettingsSubjectModal()
        );
    }

    [closeSettingsSubjectModal, cancelSettingsSubject].forEach(
        button => {
            button?.addEventListener(
                "click",
                closeSettingsSubjectModalWindow
            );
        }
    );

    settingsSubjectModal?.addEventListener(
        "click",
        event => {
            if (event.target === settingsSubjectModal) {
                closeSettingsSubjectModalWindow();
            }
        }
    );

    saveSettingsSubject?.addEventListener(
        "click",
        saveSettingsSubjectValue
    );

    settingsSubjectsList?.addEventListener(
        "click",
        event => {
            const edit =
                event.target.closest("[data-edit-settings-subject]");
            const del =
                event.target.closest("[data-delete-settings-subject]");

            if (edit) {
                openSettingsSubjectModal(
                    edit.dataset.editSettingsSubject
                );
            } else if (del) {
                deleteSettingsSubject(
                    del.dataset.deleteSettingsSubject
                );
            }
        }
    );


    if (exportAllDataButton) {
        exportAllDataButton.addEventListener(
            "click",
            exportAllMueenData
        );
    }

    backupDriveButton?.addEventListener("click", handleDriveBackup);
    restoreDriveButton?.addEventListener("click", handleDriveRestore);

    window.addEventListener(

        "storage",

        handleStorageChange

    );

}


/* =========================================================
   INITIALIZE
========================================================= */

function initSettings() {

    updateNotificationUI();

    updateTermStatusUI();

    updateLastBackupUI();

    renderSettingsSubjects();

    setupEvents();
    setupSupabaseBackup();

    setupNavigation();

    setupBackButton();

    setupTermEventListener();

}


/* =========================================================
   START
========================================================= */

if (
    document.readyState ===
    "loading"
) {

    document.addEventListener(

        "DOMContentLoaded",

        initSettings

    );

} else {

    initSettings();

}