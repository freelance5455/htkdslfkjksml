// اختبار دخان للخادم مع مزوّد وهمي (لا يحتاج مفاتيح حقيقية ولا إنترنت)
// التشغيل: node server/test/smoke.mjs
import http from "node:http";
import assert from "node:assert/strict";

const seen = { anthropic: [], openai: [], openaiChat: [], gemini: [], compat: [], cohere: [] };
let anthropicMode = "ok";
let geminiMode = "ok";

const fake = http.createServer(async (req, res) => {
  let body = ""; for await (const c of req) body += c;
  const j = (s, o) => { res.writeHead(s, { "content-type": "application/json" }); res.end(JSON.stringify(o)); };
  if (req.url === "/v1/messages") {
    seen.anthropic.push({ headers: req.headers, body: JSON.parse(body) });
    if (anthropicMode === "down") return j(500, { error: "boom" });
    if (anthropicMode === "search") return j(200, { content: [
      { type: "server_tool_use", id: "s1", name: "web_search", input: { query: "q" } },
      { type: "web_search_tool_result", tool_use_id: "s1", content: [{ type: "web_search_result", url: "https://example.org/a", title: "A" }, { type: "web_search_result", url: "https://example.org/a", title: "A" }] },
      { type: "text", text: "الجواب من الإنترنت" }], stop_reason: "end_turn" });
    if (anthropicMode === "pause") {
      const first = seen.anthropic.length === 1;
      return j(200, first
        ? { content: [{ type: "text", text: "أبحث..." }], stop_reason: "pause_turn" }
        : { content: [{ type: "text", text: "الخلاصة: " }, { type: "text", text: "يوم جميل" }], stop_reason: "end_turn" });
    }
    return j(200, { content: [{ type: "text", text: "رد تجريبي" }], stop_reason: "end_turn" });
  }
  if (req.url === "/v1/audio/transcriptions") {
    seen.openai.push({ auth: req.headers.authorization, size: body.length });
    return j(200, { text: "نص مفرّغ" });
  }
  if (req.url === "/v1/chat/completions") {
    seen.openaiChat.push({ auth: req.headers.authorization, body: JSON.parse(body) });
    return j(200, { choices: [{ message: { role: "assistant", content: " رد من ChatGPT " } }] });
  }
  if (req.url === "/groq/v1/chat/completions" || req.url === "/ds/chat/completions") {
    seen.compat.push({ url: req.url, auth: req.headers.authorization, body: JSON.parse(body) });
    return j(200, { choices: [{ message: { role: "assistant", content: "رد متوافق" } }] });
  }
  if (req.url === "/v2/chat") {
    seen.cohere.push({ auth: req.headers.authorization, body: JSON.parse(body) });
    return j(200, { message: { role: "assistant", content: [{ type: "text", text: "رد من Cohere" }] } });
  }
  if (req.url.startsWith("/v1beta/models/") && req.url.endsWith(":generateContent")) {
    seen.gemini.push({ key: req.headers["x-goog-api-key"], url: req.url, body: JSON.parse(body) });
    if (geminiMode === "down") return j(500, { error: "gemini-internal-detail" });
    return j(200, { candidates: [{ content: { role: "model", parts: [{ text: "رد من Gemini" }] } }] });
  }
  j(404, {});
});
await new Promise(r => fake.listen(0, r));
const up = `http://127.0.0.1:${fake.address().port}`;

process.env.JANNI_NO_LISTEN = "1";
process.env.ANTHROPIC_API_KEY = "sk-test-SECRET";
process.env.OPENAI_API_KEY = "sk-oa-SECRET";
process.env.ANTHROPIC_BASE_URL = up;
process.env.OPENAI_BASE_URL = up;
process.env.GEMINI_API_KEY = "gm-SECRET";
process.env.GEMINI_BASE_URL = up;
process.env.GROQ_API_KEY = "gq-SECRET";
process.env.GROQ_BASE_URL = up + "/groq/v1";
process.env.DEEPSEEK_API_KEY = "ds-SECRET";
process.env.DEEPSEEK_BASE_URL = up + "/ds";
process.env.COHERE_API_KEY = "co-SECRET";
process.env.COHERE_BASE_URL = up;
process.env.RATE_LIMIT_PER_MIN = "100";
process.env.ENABLE_WEB_SEARCH = "1";
const { server } = await import("../server.js");
await new Promise(r => server.listen(0, r));
const base = `http://127.0.0.1:${server.address().port}`;
const origin = "https://localhost";

const post = (obj, extra = {}) => fetch(base + "/", {
  method: "POST", headers: { "content-type": "application/json", origin, ...extra }, body: JSON.stringify(obj),
});

let passed = 0;
const t = async (name, fn) => { try { await fn(); passed++; console.log("PASS", name); } catch (e) { console.log("FAIL", name, "-", e.message); process.exitCode = 1; } };

await t("T1 health reports configuration without exposing keys", async () => {
  const r = await fetch(base + "/health", { headers: { origin } });
  const j = await r.json();
  assert.deepEqual(j.providers, ["anthropic", "gemini", "openai", "groq", "deepseek", "cohere"]);
  assert.equal(j.transcription, true);
  assert.ok(!JSON.stringify(j).includes("SECRET"));
});

await t("T13 providers action lists models and enabled state, never keys", async () => {
  const r = await post({ action: "providers" });
  assert.equal(r.status, 200);
  const j = await r.json();
  assert.equal(j.default, "anthropic");
  assert.equal(j.providers.length, 15);
  assert.deepEqual(j.providers.filter(p => p.enabled).map(p => p.id), ["anthropic", "gemini", "openai", "groq", "deepseek", "cohere"]);
  assert.ok(j.providers.some(p => p.id === "openrouter" && p.enabled === false));
  assert.ok(j.providers.every(p => typeof p.model === "string" && p.name));
  assert.ok(!JSON.stringify(j).includes("SECRET"));
});

await t("T14 gemini: key in header, system_instruction, model role, inline image", async () => {
  seen.gemini.length = 0;
  const r = await post({ action: "chat", provider: "gemini", name: "أبا", now: "2026-11-12T10:00:00Z",
    messages: [
      { role: "user", content: "ما هذه؟", image: { mime: "image/png", data: "iVBORw0KGgo=" } },
      { role: "assistant", content: "أظنها شجرة" },
      { role: "user", content: "وما لونها؟" }] });
  assert.equal(r.status, 200);
  const j = await r.json();
  assert.equal(j.reply, "رد من Gemini");
  assert.equal(j.provider, "gemini");
  const g = seen.gemini[0];
  assert.equal(g.key, "gm-SECRET");
  assert.ok(!g.url.includes("key="), "key must not be in the URL");
  assert.match(g.url, /\/v1beta\/models\/.+:generateContent$/);
  assert.ok(g.body.system_instruction.parts[0].text.includes("جني"));
  assert.deepEqual(g.body.contents.map(c => c.role), ["user", "model", "user"]);
  assert.deepEqual(g.body.contents[0].parts[0], { inline_data: { mime_type: "image/png", data: "iVBORw0KGgo=" } });
  assert.deepEqual(g.body.contents[2].parts, [{ text: "وما لونها؟" }]);
});

await t("T15 openai chat: bearer key, system first, image as data URL", async () => {
  seen.openaiChat.length = 0;
  const r = await post({ action: "chat", provider: "openai",
    messages: [{ role: "user", content: "مرحبا", image: { mime: "image/jpeg", data: "/9j/4AA=" } }] });
  assert.equal(r.status, 200);
  const j = await r.json();
  assert.equal(j.reply, "رد من ChatGPT");
  const o = seen.openaiChat[0];
  assert.equal(o.auth, "Bearer sk-oa-SECRET");
  assert.equal(o.body.messages[0].role, "system");
  assert.equal(o.body.messages[1].role, "user");
  assert.equal(o.body.messages[1].content[0].image_url.url, "data:image/jpeg;base64,/9j/4AA=");
});

await t("T16 unknown provider is rejected; default provider used when omitted", async () => {
  const bad = await post({ action: "chat", provider: "nope", messages: [{ role: "user", content: "x" }] });
  assert.equal(bad.status, 400);
  seen.gemini.length = 0;
  const def = await post({ action: "chat", messages: [{ role: "user", content: "x" }] });
  assert.equal(def.status, 200);
  assert.equal((await def.json()).provider, "anthropic");
});

await t("T17 gemini upstream failure returns 502 without leaking details", async () => {
  geminiMode = "down";
  try {
    const r = await post({ action: "chat", provider: "gemini", messages: [{ role: "user", content: "x" }] });
    assert.equal(r.status, 502);
    const text = await r.text();
    assert.ok(!text.includes("gemini-internal-detail"));
    assert.ok(!text.includes("gm-SECRET"));
  } finally { geminiMode = "ok"; }
});

await t("T18 OpenAI-compatible providers use their own URL, bearer key and model; no image for text-only ones", async () => {
  seen.compat.length = 0;
  let r = await post({ action: "chat", provider: "groq", messages: [{ role: "user", content: "مرحبا" }] });
  assert.equal(r.status, 200);
  assert.equal((await r.json()).reply, "رد متوافق");
  r = await post({ action: "chat", provider: "deepseek", messages: [{ role: "user", content: "مرحبا" }] });
  assert.equal(r.status, 200);
  assert.equal(seen.compat[0].url, "/groq/v1/chat/completions");
  assert.equal(seen.compat[0].auth, "Bearer gq-SECRET");
  assert.equal(seen.compat[0].body.model, "llama-3.3-70b-versatile");
  assert.equal(seen.compat[0].body.messages[0].role, "system");
  assert.equal(seen.compat[1].auth, "Bearer ds-SECRET");
  const img = await post({ action: "chat", provider: "groq", messages: [{ role: "user", content: "x", image: { mime: "image/png", data: "iVBORw0KGgo=" } }] });
  assert.equal(img.status, 400);
  const off = await post({ action: "chat", provider: "openrouter", messages: [{ role: "user", content: "x" }] });
  assert.equal(off.status, 503);
});

await t("T19 cohere v2 chat format", async () => {
  seen.cohere.length = 0;
  const r = await post({ action: "chat", provider: "cohere", messages: [{ role: "user", content: "مرحبا" }] });
  assert.equal(r.status, 200);
  assert.equal((await r.json()).reply, "رد من Cohere");
  assert.equal(seen.cohere[0].auth, "Bearer co-SECRET");
  assert.equal(seen.cohere[0].body.model, "command-a-03-2025");
});

await t("T2 chat sends history, system prompt, key only server-side, and returns reply", async () => {
  seen.anthropic.length = 0; anthropicMode = "ok";
  const r = await post({ action: "chat", name: "أبا يزيد", now: "2026-11-12T10:00:00Z",
    messages: [{ role: "user", content: "مرحبا" }, { role: "assistant", content: "أهلًا" }, { role: "user", content: "ما عاصمة السودان؟" }] });
  assert.equal(r.status, 200);
  const j = await r.json();
  assert.equal(j.reply, "رد تجريبي");
  const sent = seen.anthropic[0];
  assert.equal(sent.headers["x-api-key"], "sk-test-SECRET");
  assert.equal(sent.body.messages.length, 3);
  assert.equal(sent.body.model, "claude-haiku-5-5");
  assert.equal(sent.body.tools[0].type, "web_search_20250305");
  assert.equal(sent.body.tools[0].max_uses, 3);
  assert.match(sent.body.system, /أبا يزيد/);
  assert.equal(r.headers.get("access-control-allow-origin"), origin);
});

await t("T3 image block is forwarded for user turns only", async () => {
  seen.anthropic.length = 0;
  const r = await post({ action: "chat", messages: [{ role: "user", content: "ما هذا؟", image: { mime: "image/jpeg", data: "/9j/AA==" } }] });
  assert.equal(r.status, 200);
  const blk = seen.anthropic[0].body.messages[0].content;
  assert.equal(blk[0].type, "image"); assert.equal(blk[0].source.media_type, "image/jpeg");
  assert.equal(blk[1].text, "ما هذا؟");
});

await t("T4 bad image type and bad base64 are rejected", async () => {
  let r = await post({ action: "chat", messages: [{ role: "user", content: "x", image: { mime: "text/html", data: "AAAA" } }] });
  assert.equal(r.status, 400);
  r = await post({ action: "chat", messages: [{ role: "user", content: "x", image: { mime: "image/png", data: "<script>" } }] });
  assert.equal(r.status, 400);
});

await t("T5 conversation must end with a user message; leading assistant turns dropped", async () => {
  let r = await post({ action: "chat", messages: [{ role: "assistant", content: "x" }] });
  assert.equal(r.status, 400);
  seen.anthropic.length = 0;
  r = await post({ action: "chat", messages: [{ role: "assistant", content: "زائد" }, { role: "user", content: "a" }, { role: "user", content: "b" }] });
  assert.equal(r.status, 200);
  const msgs = seen.anthropic[0].body.messages;
  assert.equal(msgs[0].role, "user");
  assert.equal(msgs.length, 1);
});

await t("T6 pause_turn is continued and text blocks are joined", async () => {
  seen.anthropic.length = 0; anthropicMode = "pause";
  const r = await post({ action: "chat", messages: [{ role: "user", content: "ابحث" }] });
  const j = await r.json();
  anthropicMode = "ok";
  assert.equal(seen.anthropic.length, 2);
  assert.equal(seen.anthropic[1].body.messages.at(-1).role, "assistant");
  assert.equal(j.reply, "الخلاصة: يوم جميل");
});

await t("T7 upstream failure returns 502 without leaking details", async () => {
  anthropicMode = "down";
  const r = await post({ action: "chat", messages: [{ role: "user", content: "x" }] });
  anthropicMode = "ok";
  const txt = await r.text();
  assert.equal(r.status, 502);
  assert.ok(!txt.includes("boom") && !txt.includes("SECRET"));
});

await t("T8 transcription forwards audio with server-side key", async () => {
  const r = await post({ action: "transcribe", audio: Buffer.from("fake-audio").toString("base64"), mime: "audio/webm", language: "ar" });
  assert.equal(r.status, 200);
  assert.equal((await r.json()).text, "نص مفرّغ");
  assert.equal(seen.openai.at(-1).auth, "Bearer sk-oa-SECRET");
});

await t("T9 non-https origins get no CORS allow header", async () => {
  const r = await fetch(base + "/health", { headers: { origin: "https://evil.example" } });
  assert.equal(r.headers.get("access-control-allow-origin"), null);
});

await t("T10 unknown action and malformed JSON are rejected", async () => {
  let r = await post({ action: "delete_everything" });
  assert.equal(r.status, 400);
  r = await fetch(base + "/", { method: "POST", headers: { "content-type": "application/json" }, body: "{bad" });
  assert.equal(r.status, 400);
});

await t("T12 web search sources are appended as links, once each", async () => {
  anthropicMode = "search";
  const r = await post({ action: "chat", message: "ما أخبار اليوم؟" });
  anthropicMode = "ok";
  const j = await r.json();
  assert.ok(j.reply.startsWith("الجواب من الإنترنت"));
  assert.ok(j.reply.includes("المصادر:\n• https://example.org/a"));
  assert.equal(j.reply.split("https://example.org/a").length - 1, 1);
});

await t("T11 rate limit is enforced (separate process, limit=2)", async () => {
  const { spawn } = await import("node:child_process");
  const port = 18700 + Math.floor(Math.random() * 200);
  const child = spawn(process.execPath, ["server/server.js"], {
    env: { ...process.env, JANNI_NO_LISTEN: "0", PORT: String(port), RATE_LIMIT_PER_MIN: "2", ANTHROPIC_API_KEY: "k", ANTHROPIC_BASE_URL: up },
    stdio: ["ignore", "pipe", "pipe"],
  });
  try {
    await new Promise((res, rej) => { child.stdout.on("data", d => String(d).includes("listening") || String(d).includes("Janni") ? res() : null); child.on("error", rej); setTimeout(res, 1500); });
    const statuses = [];
    for (let i = 0; i < 3; i++) {
      const r = await fetch(`http://127.0.0.1:${port}/`, { method: "POST", headers: { "content-type": "application/json", origin }, body: JSON.stringify({ action: "chat", message: "hi" }) });
      statuses.push(r.status);
    }
    assert.deepEqual(statuses, [200, 200, 429]);
  } finally { child.kill(); }
});

server.close(); fake.close();
console.log(`\n${passed} tests passed` + (process.exitCode ? " (with failures)" : ""));
