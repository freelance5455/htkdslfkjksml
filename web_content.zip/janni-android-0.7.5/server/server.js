// مفكرة جني – خادم الذكاء الاصطناعي (Node 18+ بلا مكتبات خارجية)
// الخادم هو الوحيد الذي يحمل المفاتيح. التطبيق يرسل رسائله بصيغة واحدة، والخادم يحوّلها لكل مزوّد.
//
// المزوّدون (يُفعَّل كل واحد بوجود مفتاحه):
//   anthropic : ANTHROPIC_API_KEY   (Claude)        افتراضي النموذج: claude-haiku-5-5
//   gemini    : GEMINI_API_KEY      (Google Gemini)  افتراضي النموذج: gemini-3.8-flash
//   openai    : OPENAI_API_KEY      (ChatGPT)        افتراضي النموذج: gpt-4o-mini
//   مزوّدون متوافقون مع واجهة OpenAI (مفتاح لكل واحد، والنموذج يُغيَّر بـ <NAME>_MODEL):
//   groq GROQ_API_KEY | openrouter OPENROUTER_API_KEY | mistral MISTRAL_API_KEY | deepseek DEEPSEEK_API_KEY
//   qwen QWEN_API_KEY (أو DASHSCOPE_API_KEY) | huggingface HF_TOKEN | nvidia NVIDIA_API_KEY | cerebras CEREBRAS_API_KEY
//   sambanova SAMBANOVA_API_KEY | fireworks FIREWORKS_API_KEY | together TOGETHER_API_KEY
//   cohere COHERE_API_KEY (واجهة Cohere v2)
//
// متغيرات عامة:
//   DEFAULT_PROVIDER     المزوّد الافتراضي (مثل anthropic أو gemini أو groq ...)
//   CLAUDE_MODEL, GEMINI_MODEL, OPENAI_CHAT_MODEL   لتغيير النماذج
//   ENABLE_WEB_SEARCH=1  البحث في الإنترنت عبر Claude فقط
//   TRANSCRIBE_MODEL     نموذج التفريغ الصوتي عبر OpenAI (افتراضي whisper-1)
//   ALLOWED_ORIGINS      (افتراضي: https://localhost,capacitor://localhost,http://localhost)
//   RATE_LIMIT_PER_MIN   (افتراضي 30 لكل IP في الدقيقة)   TRUST_PROXY=1 خلف وكيل
//   PORT (افتراضي 8787)
//   ANTHROPIC_BASE_URL, GEMINI_BASE_URL, OPENAI_BASE_URL, ANTHROPIC_VERSION   للاختبار

import http from "node:http";

const cfg = {
  port: Number(process.env.PORT || 8787),
  defaultProvider: process.env.DEFAULT_PROVIDER || "",
  anthropicKey: process.env.ANTHROPIC_API_KEY || "",
  anthropicUrl: (process.env.ANTHROPIC_BASE_URL || "https://api.anthropic.com").replace(/\/$/, ""),
  anthropicVersion: process.env.ANTHROPIC_VERSION || "2023-06-01",
  claudeModel: process.env.CLAUDE_MODEL || "claude-haiku-5-5",
  geminiKey: process.env.GEMINI_API_KEY || "",
  geminiUrl: (process.env.GEMINI_BASE_URL || "https://generativelanguage.googleapis.com").replace(/\/$/, ""),
  geminiModel: process.env.GEMINI_MODEL || "gemini-3.8-flash",
  openaiKey: process.env.OPENAI_API_KEY || "",
  openaiUrl: (process.env.OPENAI_BASE_URL || "https://api.openai.com").replace(/\/$/, ""),
  openaiChatModel: process.env.OPENAI_CHAT_MODEL || "gpt-4o-mini",
  transcribeModel: process.env.TRANSCRIBE_MODEL || "whisper-1",
  webSearch: process.env.ENABLE_WEB_SEARCH === "1",
  webSearchMaxUses: Number(process.env.WEB_SEARCH_MAX_USES || 3),
  allowedOrigins: (process.env.ALLOWED_ORIGINS || "https://localhost,capacitor://localhost,http://localhost")
    .split(",").map(s => s.trim()).filter(Boolean),
  rateLimit: Number(process.env.RATE_LIMIT_PER_MIN || 30),
  trustProxy: process.env.TRUST_PROXY === "1",
};

// مزوّدون يتبعون صيغة OpenAI /chat/completions: المفتاح والنموذج والعنوان قابلة للتغيير من المتغيرات
const OAI_COMPAT = [
  { id: "groq", name: "Groq", env: ["GROQ_API_KEY"], url: "https://api.groq.com/openai/v1", model: "llama-3.3-70b-versatile", vision: false },
  { id: "openrouter", name: "OpenRouter", env: ["OPENROUTER_API_KEY"], url: "https://openrouter.ai/api/v1", model: "openrouter/auto", vision: false },
  { id: "mistral", name: "Mistral AI", env: ["MISTRAL_API_KEY"], url: "https://api.mistral.ai/v1", model: "mistral-small-latest", vision: true },
  { id: "deepseek", name: "DeepSeek", env: ["DEEPSEEK_API_KEY"], url: "https://api.deepseek.com", model: "deepseek-chat", vision: false },
  { id: "qwen", name: "Qwen (Alibaba)", env: ["QWEN_API_KEY", "DASHSCOPE_API_KEY"], url: "https://dashscope-intl.aliyuncs.com/compatible-mode/v1", model: "qwen-plus", vision: false },
  { id: "huggingface", name: "Hugging Face", env: ["HF_TOKEN", "HUGGINGFACE_API_KEY"], url: "https://router.huggingface.co/v1", model: "meta-llama/Llama-3.3-70B-Instruct", vision: false },
  { id: "nvidia", name: "NVIDIA", env: ["NVIDIA_API_KEY"], url: "https://integrate.api.nvidia.com/v1", model: "meta/llama-3.3-70b-instruct", vision: false },
  { id: "cerebras", name: "Cerebras", env: ["CEREBRAS_API_KEY"], url: "https://api.cerebras.ai/v1", model: "llama-3.3-70b", vision: false },
  { id: "sambanova", name: "SambaNova", env: ["SAMBANOVA_API_KEY"], url: "https://api.sambanova.ai/v1", model: "Meta-Llama-3.3-70B-Instruct", vision: false },
  { id: "fireworks", name: "Fireworks AI", env: ["FIREWORKS_API_KEY"], url: "https://api.fireworks.ai/inference/v1", model: "accounts/fireworks/models/llama-v3p3-70b-instruct", vision: false },
  { id: "together", name: "Together AI", env: ["TOGETHER_API_KEY"], url: "https://api.together.xyz/v1", model: "meta-llama/Llama-3.3-70B-Instruct-Turbo", vision: false },
].map(d => {
  const up = d.id.toUpperCase();
  return {
    ...d,
    key: d.env.map(n => process.env[n]).find(Boolean) || "",
    baseUrl: (process.env[up + "_BASE_URL"] || d.url).replace(/\/$/, ""),
    modelName: process.env[up + "_MODEL"] || d.model,
  };
});
const cohere = {
  key: process.env.COHERE_API_KEY || "",
  url: (process.env.COHERE_BASE_URL || "https://api.cohere.com").replace(/\/$/, ""),
  model: process.env.COHERE_MODEL || "command-a-03-2025",
};

const PROVIDERS = [
  { id: "anthropic", name: "Claude (Anthropic)", model: () => cfg.claudeModel, enabled: () => !!cfg.anthropicKey },
  { id: "gemini", name: "Gemini (Google)", model: () => cfg.geminiModel, enabled: () => !!cfg.geminiKey },
  { id: "openai", name: "ChatGPT (OpenAI)", model: () => cfg.openaiChatModel, enabled: () => !!cfg.openaiKey },
  ...OAI_COMPAT.map(d => ({ id: d.id, name: d.name, model: () => d.modelName, enabled: () => !!d.key })),
  { id: "cohere", name: "Cohere", model: () => cohere.model, enabled: () => !!cohere.key },
];
const providerById = id => PROVIDERS.find(p => p.id === id);
function defaultProviderId() {
  if (cfg.defaultProvider && providerById(cfg.defaultProvider)?.enabled()) return cfg.defaultProvider;
  return PROVIDERS.find(p => p.enabled())?.id || "";
}

const MAX_BODY = 12 * 1024 * 1024;
const MAX_MESSAGES = 30;
const MAX_TEXT = 4000;
const MAX_IMAGE_B64 = 6_000_000;
const MAX_AUDIO_BYTES = 8 * 1024 * 1024;
const IMAGE_TYPES = new Set(["image/jpeg", "image/png", "image/webp", "image/gif"]);
const UPSTREAM_TIMEOUT = 45_000;
const MAX_TOOL_ROUNDS = 3;

const SYSTEM_BASE = [
  "أنت جني، مساعد ذكي عربي يعمل داخل تطبيق «مفكرة جني».",
  "أجب بالعربية الواضحة والمختصرة ما لم يكتب المستخدم بلغة أخرى، واستخدم تنسيقًا بسيطًا (قوائم أو عناوين قصيرة) عند الحاجة.",
  "إذا أُرفقت صورة فصفها وأجب عن السؤال المتعلق بها، ولا تفترض ما لا يظهر فيها.",
  "لا تدّعِ أنك أضفت تذكيرًا أو مهمة أو ملاحظة إلى المفكرة، فهذه الأوامر تُنفَّذ محليًا في التطبيق، وإذا طلبها المستخدم فوجّهه إلى قولها بصيغة الأمر مثل «ذكرني بكذا بعد 10 دقائق».",
  "إذا كنت غير متأكد من معلومة حديثة فقل ذلك بوضوح.",
].join("\n");

// ---------- تحديد عدد الطلبات ----------
const hits = new Map();
function rateOk(ip) {
  const now = Date.now();
  const rec = hits.get(ip);
  if (!rec || now > rec.reset) { hits.set(ip, { count: 1, reset: now + 60_000 }); return true; }
  rec.count++;
  return rec.count <= cfg.rateLimit;
}
setInterval(() => { const now = Date.now(); for (const [k, v] of hits) if (now > v.reset) hits.delete(k); }, 60_000).unref();

// ---------- أدوات ----------
function corsHeaders(origin) {
  const h = { "Vary": "Origin", "Access-Control-Allow-Headers": "Content-Type", "Access-Control-Allow-Methods": "POST, GET, OPTIONS", "Access-Control-Max-Age": "600" };
  if (origin && cfg.allowedOrigins.includes(origin)) h["Access-Control-Allow-Origin"] = origin;
  return h;
}
function send(res, status, body, origin) {
  res.writeHead(status, { ...corsHeaders(origin), "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
  res.end(JSON.stringify(body));
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on("data", c => {
      size += c.length;
      if (size > MAX_BODY) { reject(Object.assign(new Error("too_large"), { status: 413 })); req.destroy(); return; }
      chunks.push(c);
    });
    req.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")));
    req.on("error", reject);
  });
}
const clip = (s, n) => String(s == null ? "" : s).slice(0, n);
const isB64 = s => typeof s === "string" && s.length > 0 && /^[A-Za-z0-9+/=\r\n]+$/.test(s);

// يحوّل الرسائل الواردة إلى شكل موحد: [{role, parts:[{type:"text",text}|{type:"image",mime,data}]}]
function buildMessages(input) {
  let list = Array.isArray(input.messages) ? input.messages : null;
  if (!list && typeof input.message === "string") list = [{ role: "user", content: input.message }];
  if (!list || list.length === 0) throw Object.assign(new Error("no_messages"), { status: 400 });
  if (list.length > MAX_MESSAGES) list = list.slice(-MAX_MESSAGES);

  const out = [];
  for (const m of list) {
    if (!m || (m.role !== "user" && m.role !== "assistant")) continue;
    const text = clip(m.content ?? m.text ?? "", MAX_TEXT);
    const parts = [];
    if (m.role === "user" && m.image) {
      const img = m.image;
      if (!IMAGE_TYPES.has(img.mime) || !isB64(img.data) || img.data.length > MAX_IMAGE_B64) {
        throw Object.assign(new Error("bad_image"), { status: 400 });
      }
      parts.push({ type: "image", mime: img.mime, data: img.data });
    }
    if (text.trim()) parts.push({ type: "text", text });
    if (parts.length === 0) continue;
    const last = out[out.length - 1];
    if (last && last.role === m.role) last.parts.push(...parts);
    else out.push({ role: m.role, parts });
  }
  while (out.length && out[0].role !== "user") out.shift();
  if (out.length === 0 || out[out.length - 1].role !== "user") throw Object.assign(new Error("no_user_message"), { status: 400 });
  return out;
}

async function postJson(url, headers, body) {
  return fetch(url, {
    method: "POST",
    headers: { "content-type": "application/json", ...headers },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(UPSTREAM_TIMEOUT),
  });
}
async function upstreamFail(res, who) {
  const errText = await res.text().catch(() => "");
  console.error(who, "upstream error", res.status, errText.slice(0, 300));
  throw Object.assign(new Error("upstream"), { status: res.status === 429 ? 429 : 502 });
}

// ---------- المزوّدون ----------
async function callAnthropic(messages, system) {
  const convo = messages.map(m => ({
    role: m.role,
    content: m.parts.map(p => p.type === "image"
      ? { type: "image", source: { type: "base64", media_type: p.mime, data: p.data } }
      : { type: "text", text: p.text }),
  }));
  const tools = cfg.webSearch ? [{ type: "web_search_20250305", name: "web_search", max_uses: cfg.webSearchMaxUses }] : undefined;
  let content = [];
  let current = convo;
  for (let round = 0; round <= MAX_TOOL_ROUNDS; round++) {
    const body = { model: cfg.claudeModel, max_tokens: 1024, system, messages: current };
    if (tools) body.tools = tools;
    const res = await postJson(`${cfg.anthropicUrl}/v1/messages`,
      { "x-api-key": cfg.anthropicKey, "anthropic-version": cfg.anthropicVersion }, body);
    if (!res.ok) await upstreamFail(res, "anthropic");
    const json = await res.json();
    content = json.content || [];
    if (json.stop_reason === "pause_turn" && round < MAX_TOOL_ROUNDS) {
      current = [...current, { role: "assistant", content }];
      continue;
    }
    break;
  }
  const text = content.filter(b => b.type === "text").map(b => b.text).join("").trim();
  const sources = [];
  for (const b of content) {
    if (b.type !== "web_search_tool_result" || !Array.isArray(b.content)) continue;
    for (const r of b.content) if (r && /^https?:\/\//.test(r.url) && !sources.includes(r.url)) sources.push(r.url);
  }
  const body = text || "لم أتمكن من توليد رد. حاول بصياغة أخرى.";
  return sources.length ? body + "\n\nالمصادر:\n" + sources.slice(0, 5).map(u => "• " + u).join("\n") : body;
}

async function callGemini(messages, system) {
  const contents = messages.map(m => ({
    role: m.role === "assistant" ? "model" : "user",
    parts: m.parts.map(p => p.type === "image"
      ? { inline_data: { mime_type: p.mime, data: p.data } }
      : { text: p.text }),
  }));
  const url = `${cfg.geminiUrl}/v1beta/models/${encodeURIComponent(cfg.geminiModel)}:generateContent`;
  const res = await postJson(url, { "x-goog-api-key": cfg.geminiKey },
    { system_instruction: { parts: [{ text: system }] }, contents, generationConfig: { maxOutputTokens: 1024 } });
  if (!res.ok) await upstreamFail(res, "gemini");
  const json = await res.json();
  const text = (json.candidates?.[0]?.content?.parts || []).map(p => p.text || "").join("").trim();
  return text || "لم أتمكن من توليد رد. حاول بصياغة أخرى.";
}

async function callOpenAI(messages, system) {
  const chat = [{ role: "system", content: system }];
  for (const m of messages) {
    const content = m.parts.map(p => p.type === "image"
      ? { type: "image_url", image_url: { url: `data:${p.mime};base64,${p.data}` } }
      : { type: "text", text: p.text });
    chat.push({ role: m.role, content: content.length === 1 && content[0].type === "text" ? content[0].text : content });
  }
  const res = await postJson(`${cfg.openaiUrl}/v1/chat/completions`,
    { Authorization: "Bearer " + cfg.openaiKey }, { model: cfg.openaiChatModel, max_completion_tokens: 1024, messages: chat });
  if (!res.ok) await upstreamFail(res, "openai");
  const json = await res.json();
  const text = String(json.choices?.[0]?.message?.content || "").trim();
  return text || "لم أتمكن من توليد رد. حاول بصياغة أخرى.";
}

// أي مزوّد متوافق مع OpenAI: Groq وOpenRouter وMistral وDeepSeek وQwen وHugging Face وNVIDIA وCerebras وSambaNova وFireworks وTogether
async function callOaiCompat(d, messages, system) {
  const chat = [{ role: "system", content: system }];
  for (const m of messages) {
    if (!d.vision && m.parts.some(p => p.type === "image")) throw Object.assign(new Error("image_not_supported"), { status: 400 });
    const content = m.parts.map(p => p.type === "image"
      ? { type: "image_url", image_url: { url: `data:${p.mime};base64,${p.data}` } }
      : { type: "text", text: p.text });
    chat.push({ role: m.role, content: content.length === 1 && content[0].type === "text" ? content[0].text : content });
  }
  const res = await postJson(`${d.baseUrl}/chat/completions`,
    { Authorization: "Bearer " + d.key }, { model: d.modelName, max_tokens: 1024, messages: chat });
  if (!res.ok) await upstreamFail(res, d.id);
  const json = await res.json();
  const text = String(json.choices?.[0]?.message?.content || "").trim();
  return text || "لم أتمكن من توليد رد. حاول بصياغة أخرى.";
}

async function callCohere(messages, system) {
  const chat = [{ role: "system", content: system }];
  for (const m of messages) {
    if (m.parts.some(p => p.type === "image")) throw Object.assign(new Error("image_not_supported"), { status: 400 });
    chat.push({ role: m.role, content: m.parts.map(p => p.text).join("\n") });
  }
  const res = await postJson(`${cohere.url}/v2/chat`,
    { Authorization: "Bearer " + cohere.key }, { model: cohere.model, max_tokens: 1024, messages: chat });
  if (!res.ok) await upstreamFail(res, "cohere");
  const json = await res.json();
  const text = (json.message?.content || []).filter(b => b.type === "text").map(b => b.text).join("").trim();
  return text || "لم أتمكن من توليد رد. حاول بصياغة أخرى.";
}

async function chatWith(providerId, messages, name, now) {
  const system = `${SYSTEM_BASE}\nالوقت الحالي: ${clip(now, 40) || new Date().toISOString()}. اسم المستخدم: ${clip(name, 60) || "غير معروف"}.`;
  if (providerId === "anthropic") return callAnthropic(messages, system);
  if (providerId === "gemini") return callGemini(messages, system);
  if (providerId === "openai") return callOpenAI(messages, system);
  if (providerId === "cohere") return callCohere(messages, system);
  const d = OAI_COMPAT.find(x => x.id === providerId);
  if (d) return callOaiCompat(d, messages, system);
  throw Object.assign(new Error("unknown_provider"), { status: 400 });
}

// ---------- التفريغ الصوتي (OpenAI، اختياري) ----------
async function transcribe(audioB64, mime, language) {
  if (!cfg.openaiKey) throw Object.assign(new Error("transcription_unavailable"), { status: 501 });
  if (!isB64(audioB64)) throw Object.assign(new Error("bad_audio"), { status: 400 });
  const buf = Buffer.from(audioB64, "base64");
  if (buf.length === 0 || buf.length > MAX_AUDIO_BYTES) throw Object.assign(new Error("bad_audio"), { status: 400 });
  const m = String(mime || "").toLowerCase();
  const ext = m.includes("ogg") ? "ogg" : m.includes("mp4") || m.includes("m4a") || m.includes("aac") ? "m4a"
    : m.includes("wav") ? "wav" : m.includes("mpeg") || m.includes("mp3") ? "mp3" : "webm";
  const fd = new FormData();
  fd.append("file", new Blob([buf], { type: mime || "audio/webm" }), "audio." + ext);
  fd.append("model", cfg.transcribeModel);
  fd.append("language", /^[a-z]{2}$/.test(language || "") ? language : "ar");
  const res = await fetch(`${cfg.openaiUrl}/v1/audio/transcriptions`, {
    method: "POST", headers: { Authorization: "Bearer " + cfg.openaiKey }, body: fd,
    signal: AbortSignal.timeout(60_000),
  });
  if (!res.ok) await upstreamFail(res, "transcribe");
  const json = await res.json();
  return String(json.text || "").trim();
}

// ---------- الخادم ----------
const server = http.createServer(async (req, res) => {
  const origin = req.headers.origin;
  if (req.method === "OPTIONS") { res.writeHead(204, corsHeaders(origin)); return res.end(); }
  if (req.method === "GET" && req.url === "/health") {
    return send(res, 200, { ok: true, providers: PROVIDERS.filter(p => p.enabled()).map(p => p.id), transcription: !!cfg.openaiKey }, origin);
  }
  if (req.method !== "POST") return send(res, 405, { error: "method_not_allowed" }, origin);

  const ip = (cfg.trustProxy && String(req.headers["x-forwarded-for"] || "").split(",")[0].trim()) || req.socket.remoteAddress || "unknown";
  if (!rateOk(ip)) return send(res, 429, { error: "rate_limited" }, origin);

  try {
    const input = JSON.parse(await readBody(req) || "{}");
    const action = input.action || "chat";

    if (action === "providers") {
      return send(res, 200, {
        default: defaultProviderId(),
        providers: PROVIDERS.map(p => ({ id: p.id, name: p.name, model: p.model(), enabled: p.enabled() })),
      }, origin);
    }
    if (action === "chat") {
      const id = input.provider || defaultProviderId();
      const p = providerById(id);
      if (!p) return send(res, 400, { error: "unknown_provider" }, origin);
      if (!p.enabled()) return send(res, 503, { error: "provider_not_configured" }, origin);
      const messages = buildMessages(input);
      const reply = await chatWith(id, messages, input.name, input.now);
      return send(res, 200, { reply, provider: id }, origin);
    }
    if (action === "transcribe") {
      const text = await transcribe(input.audio, input.mime, input.language);
      return send(res, 200, { text }, origin);
    }
    return send(res, 400, { error: "unknown_action" }, origin);
  } catch (e) {
    if (e instanceof SyntaxError) return send(res, 400, { error: "bad_json" }, origin);
    const status = e.status || (e.name === "TimeoutError" ? 504 : 500);
    if (status === 500) console.error("server error", e.name);
    return send(res, status, { error: e.message || "server_error" }, origin);
  }
});

if (process.env.JANNI_NO_LISTEN !== "1") {
  server.listen(cfg.port, () => console.log(`Janni AI server on :${cfg.port}`));
}

export { server, buildMessages };
