# CHAKRAVYUH — Android Release Build

This package keeps the existing CHAKRAVYUH app code/UI/gameplay and uses the supplied CHAKRAVYUH logo as the app icon.

- Application ID: `com.chakravuyh.app`
- Version: `1.0` / versionCode `1`
- minSdk: 23
- targetSdk: 35
- compileSdk: 35
- Android Gradle Plugin: 8.7.3
- Gradle: 8.9

## Build
Run `gradlew :app:assembleRelease` (or use `build-release.sh` / `build-release.bat`).
The APK will be under `app/build/outputs/apk/release/`.

The launcher first uses an installed Gradle, otherwise it bootstraps Gradle 8.9 from the official Gradle distribution URL. The build machine still needs an Android SDK with API 35 and the required Android build tools.

The app itself is unchanged in gameplay/UI logic; only the packaged logo asset and build-launcher completeness were adjusted.
