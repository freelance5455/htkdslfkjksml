TEST-ZONE — Offline Android App

This is an Android Studio project containing the TEST-ZONE Workout Split app entirely inside the APK.
It has NO INTERNET permission and loads index.html from the APK assets, so the installed app does not need internet access.
Workout edits use browser-style local storage inside the Android WebView and persist on the device.

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. Install app/build/outputs/apk/debug/app-debug.apk on the phone.
