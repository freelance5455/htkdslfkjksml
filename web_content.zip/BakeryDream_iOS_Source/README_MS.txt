BAKERY DREAM — SUMBER iOS

Kandungan:
- BakeryDream/BakeryDreamApp.swift: pembungkus SwiftUI + WKWebView
- BakeryDream/index.html: permainan HTML

CARA MEMBINA APLIKASI iOS:
1. Pada Mac, buka Xcode dan pilih File > New > Project > iOS > App.
2. Nama produk: BakeryDream; Interface: SwiftUI; Language: Swift.
3. Gantikan fail App Swift yang dijana dengan BakeryDreamApp.swift ini (pastikan hanya satu deklarasi @main).
4. Seret index.html ke dalam projek Xcode dan tandakan “Copy items if needed” serta sasaran aplikasi.
5. Pilih iPhone Simulator atau iPhone yang disambungkan, kemudian tekan Run.
6. Untuk pemasangan kepada orang lain, perlu tandatangan/provisioning dan pengedaran melalui TestFlight atau App Store mengikut syarat Apple.

Nota: Ini ialah kod sumber, BUKAN fail IPA yang siap dipasang. Membina dan menandatangani aplikasi iOS biasanya memerlukan Mac dengan Xcode. Fungsi permainan berasal daripada HTML sedia ada; ini tidak menambah grafik 3D sebenar.
