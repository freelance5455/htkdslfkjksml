import SwiftUI
import WebKit

@main
struct BakeryDreamApp: App {
    var body: some Scene {
        WindowGroup { BakeryGameView() }
    }
}

struct BakeryGameView: View {
    var body: some View {
        BakeryWebView()
            .ignoresSafeArea()
            .statusBarHidden(true)
    }
}

struct BakeryWebView: UIViewRepresentable {
    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        let webView = WKWebView(frame: .zero, configuration: config)
        webView.scrollView.bounces = false
        webView.scrollView.isScrollEnabled = false
        webView.isOpaque = false
        webView.backgroundColor = UIColor(red: 1, green: 0.96, blue: 0.91, alpha: 1)
        if let url = Bundle.main.url(forResource: "index", withExtension: "html") {
            webView.loadFileURL(url, allowingReadAccessTo: url.deletingLastPathComponent())
        }
        return webView
    }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}
