# Hands of Time
### Hands of Time is a strategic card game where players take on the role of time agents, navigating through a complex web of time anomalies.
 
to-do:
7. add functionality to Queens
8. game over Scene
9. game complete Scene
10. 
# 🔮 Anomaly Resolution Rulebook

---

## **Turn 1 – Temporal Trio**

1. **Required Cards**  
Play exactly **one Past card (2–4), one Present card (5–7), and one Future card (8–10)**.  
Suits may be any mix.  

2. **Wildcards (Expert Time Agents)**  
Q♥ and Q♦ may substitute for any one Past, Present, or Future card.  
Declare the substituted value when played.  

3. **Invalid Plays**  
Wrong cards are discarded immediately.  
Jacks and non-expert Queens cannot be used.  

4. **Round End**  
The anomaly is resolved once all three required cards are played.  

**Examples**  
- **Valid:** 2♣ → 6♦ → 9♠  
- **Valid:** Q♥(as3) → 7♣ → 10♦  
- **Invalid:** 2♣ → 3♦ → 4♠ (all Past; no Present/Future)  
- **Invalid:** 5♥ → 6♣ → J♠ (Jack not valid)  

**Quick Reference:** *Play 1 Past (2–4), 1 Present (5–7), 1 Future (8–10). Q♥/Q♦ may substitute.*  

---

## **Turn 2 – Parallel Pairs**

1. **Required Cards**  
Play **two pairs** of matching values.  
Each pair must come from **two different temporal groups** (Past, Present, Future).  

2. **Wildcards (Expert Time Agents)**  
Q♥ and Q♦ may stand in for one card in a pair.  

3. **Invalid Plays**  
Pairs from the same group do not qualify.  
Jacks and non-expert Queens cannot form pairs.  

4. **Round End**  
The anomaly is resolved once both pairs are played.  

**Examples**  
- **Valid:** 3♣ + 3♦ (Past) and 6♠ + 6♥ (Present)  
- **Valid:** 4♠ + Q♥(as4) (Past) and 9♦ + 9♣ (Future)  
- **Invalid:** 2♣ + 2♥ (Past) and 3♠ + 3♦ (Past only)  
- **Invalid:** 5♣ + 5♥ and Q♣ + Q♦ (Queens not valid)  

**Quick Reference:** *Play 2 pairs, each from a different temporal group. Q♥/Q♦ may substitute.*  

---

## **Turn 3 – Resource Recycle**

1. **Discard Draw**  
Draw one random card from the discard pile. Its **suit sets the requirement**.  

2. **Required Cards**  
Play **three fresh cards** of the same suit as the drawn card.  

3. **Wildcards (Expert Time Agents)**  
Q♥ and Q♦ may substitute for any numeric rank, but must still match the required suit.  

4. **Invalid Plays**  
Wrong suits are discarded.  
Jacks and non-expert Queens cannot be used.  

5. **Round End**  
The anomaly is resolved once three valid suit-matching cards are played.  

**Examples**  
- Discard reveals ♦  
- **Valid:** 4♦ → 6♦ → 8♦  
- **Valid:** 2♦ → Q♦(as7) → 9♦  
- **Invalid:** 3♦ → 5♣ → 6♦ (off-suit card)  
- **Invalid:** 7♦ → J♦ → 8♦ (Jack not valid)  

**Quick Reference:** *Draw 1 from discard → play 3 more of same suit. Q♥/Q♦ may substitute.*  

---

## **Turn 4 – Sequence Slip**

1. **Required Cards**  
Play three numeric cards (2–10) in **strict descending order**.  
All three must be of **different suits**.  

2. **Starting Condition**  
The first card must be higher than 3.  
The second card must be exactly 1 lower.  
The third card must be exactly 1 lower again.  

3. **Wildcards (Expert Time Agents)**  
Q♥ and Q♦ may substitute for any numeric rank.  
When used, they are declared as the required value.  

4. **Invalid Plays**  
Repeated suits are discarded.  
Jacks and non-expert Queens cannot be used.  

5. **Round End**  
The anomaly is resolved once three valid descending cards of different suits are played.  

**Examples**  
- **Valid:** 6♥ → 5♠ → 4♦  
- **Valid:** 9♣ → Q♥(as8) → 7♦  
- **Invalid:** 7♣ → 6♣ → 5♦ (suit repeated)  
- **Invalid:** 5♣ → 4♦ → 2♠ (gap between 4 and 2)  

**Quick Reference:** *Play 3 descending cards, different suits, starting above 3. Q♥/Q♦ may substitute.*  

---

## **Turn 5 – Chrono Chain**

1. **First Card**  
Begin by playing one of the three anomaly keys shown (firstCard, secondCard, or thirdCard).  
Alternatively, play an Expert Time Agent (Q♥/Q♦) as a wildcard, which counts as the third card.  

2. **Second Card**  
Must be exactly **+1 or -1** relative to the first card.  
If the first card was a wildcard, it counts as the third card, so the second must be one less.  

3. **Third Card**  
The direction is now locked.  
If first two were downward, third must be -1.  
If upward, third must be +1.  

4. **Wildcards (Expert Time Agents)**  
Q♥ and Q♦ may substitute at any step.  
They adapt to the sequence automatically.  

5. **Invalid Plays**  
Any card that breaks the step sequence cancels the attempt.  
Jacks and non-expert Queens cannot be used.  

6. **Round End**  
The anomaly is resolved once three valid cards are played in sequence.  

**Examples**  
- **Valid:** Key shows (7,8,9). Player plays 8♠ → 9♥ → 10♦  
- **Valid:** Key shows (4,5,6). Player plays 5♦ → 4♠ → Q♥(as3)  
- **Invalid:** Key shows (7,8,9). Player plays 7♣ → 9♠ → 10♦ (gap in sequence)  
- **Invalid:** Key shows (4,5,6). Player plays J♦ → 5♥ → 6♣ (Jack invalid)  

**Quick Reference:** *Start with a shown key (or Q♥/Q♦). Play 3 in +1/–1 sequence. Q♥/Q♦ may substitute.*  

---

## **Turn 6 – Four of a Suit**

1. **Required Cards**  
Play **four cards of the same suit**, values between 2–10.  

2. **Wildcards (Expert Time Agents)**  
Q♥ and Q♦ may substitute for any numeric rank, but must match the suit.  

3. **Invalid Plays**  
Mixed suits are discarded.  
Jacks and non-expert Queens cannot be used.  

4. **Round End**  
The anomaly is resolved once four valid cards of the same suit are played.  

**Examples**  
- **Valid:** 2♠ → 4♠ → 6♠ → 10♠  
- **Valid:** 3♥ → 5♥ → 7♥ → Q♥(as8)  
- **Invalid:** 4♦ → 6♦ → 8♦ → 9♣ (off-suit)  
- **Invalid:** 5♣ → 7♣ → 9♣ → J♣ (Jack invalid)  

**Quick Reference:** *Play 4 cards of the same suit (2–10). Q♥/Q♦ may substitute.*  

---

## **Turn 7 – Future Flow**

1. **First Card**  
Play any numeric card (2–10), or Q♥/Q♦ as a wildcard declared as a number.  

2. **Second Card**  
Must be exactly **+1 higher** than the first card.  

3. **Third Card**  
Must be exactly **+1 higher** than the second card.  

4. **Fourth Card**  
Must be exactly **+1 higher** than the third card.  

5. **Wildcards (Expert Time Agents)**  
Q♥ and Q♦ may substitute at any step.  
Non-expert Queens and Jacks cannot be used.  

6. **Invalid Plays**  
Any break in sequence cancels the attempt.  
Invalid cards are discarded.  

7. **Round End**  
The anomaly is resolved once four ascending cards are played.  

**Examples**  
- **Valid:** 5♣ → 6♦ → 7♥ → 8♠  
- **Valid:** 2♠ → 3♦ → Q♥(as4) → 5♣  
- **Valid:** 7♦ → 8♠ → 9♣ → Q♦(as10)  
- **Invalid:** 6♣ → 7♦ → 9♠ → 10♥ (gap)  
- **Invalid:** 4♠ → J♣ → 6♦ → 7♥ (Jack invalid)  
- **Invalid:** Q♣ → 5♦ → 6♥ → 7♠ (Q♣ not a wildcard)  

**Quick Reference:** *Play 4 cards in strict +1 ascending order (2–10). Only Q♥/Q♦ may substitute.*  

---

## **Turn 8 – Echo Effect**

1. **Required Cards**  
Play **three distinct pairs**.  
Each pair must share the same value.  
All three pairs must be different values.  

2. **Wildcards (Expert Time Agents)**  
Q♥ and Q♦ cannot substitute for any card in a pair.  

3. **Invalid Plays**  
Pairs of the same value do not qualify.  
Jacks and non-expert Queens cannot be used.  

4. **Round End**  
The anomaly is resolved once three distinct pairs are played.  

**Examples**  
- **Valid:** 2♣ + 2♦ / 5♥ + 5♠ / 9♣ + 9♦  
- **Valid:** 3♥ + Q♦(as3) / 6♣ + 6♦ / 10♠ + 10♥  
- **Invalid:** 4♣ + 4♦ / 4♠ + 4♥ / 7♣ + 7♠ (two pairs same value)  
- **Invalid:** 8♦ + 8♠ / 10♣ + Q♥ / 9♣ + 9♥ (Agents invalid)  

**Quick Reference:** *Play 3 pairs of different values. Q♥/Q♦ cannot substitute.*