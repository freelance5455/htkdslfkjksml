import { ManufacturerScene } from "./client/src/scenes/ManufacturerScene.js";
import { PreloadScene } from "./client/src/scenes/PreloadScene.js";
import { MenuScene } from "./client/src/scenes/MenuScene.js";
import { PlayScene } from "./client/src/scenes/PlayScene.js";
import { PauseScene } from "./client/src/scenes/PauseScene.js";
import { GameCompleteScene } from "./client/src/scenes/GameCompleteScene.js";
import { OptionsScene } from "./client/src/scenes/OptionsScene.js";
import { CreditsScene } from "./client/src/scenes/CreditsScene.js";
import { TutorialScene } from "./client/src/scenes/TutorialScene.js";
import { PlaybookScene } from "./client/src/scenes/PlaybookScene.js";
import { TurnEndedScene } from "./client/src/scenes/TurnEndedScene.js";
import { TurnCompleteScene } from "./client/src/scenes/TurnCompleteScene.js";
import { NextAnomalyScene } from "./client/src/scenes/NextAnomalyScene.js";
import { ResolvedPortalScene } from "./client/src/scenes/ResolvedPortalScene.js";
import { UnresolvedPortalScene } from "./client/src/scenes/UnresolvedPortalScene.js";
import { TransitionScene } from "./client/src/scenes/TransitionScene.js";
import { GameOverScene } from "./client/src/scenes/GameOverScene.js";
import { RewardedAdScene } from "./client/src/scenes/RewardedAdScene.js";


const GAME_WIDTH = innerWidth * 2;
const GAME_HEIGHT = innerHeight * 2;
const ZOOM_FACTOR = 1;


const SHARED_CONFIG = {
    width: GAME_WIDTH,
    height: GAME_HEIGHT,
    
    zoomFactor: ZOOM_FACTOR,
    
    topLeft: {
        x: 0,
        y: 0
    },
    
    topRight: {
        x: GAME_WIDTH,
        y: 0
    },
    
    bottomRight: {
        x: GAME_WIDTH,
        y: GAME_HEIGHT
    },
    
    debug: false
};


const config = {
    type: Phaser.CANVAS,
    
    ...SHARED_CONFIG,
    
    parent: "gameWrapper",
    
    backgroundColor: 0x210190,
    
    transparent: true,
    
    scale: {
        mode: Phaser.Scale.FIT,
        autoCenter: Phaser.Scale.CENTER_BOTH,
    },
    
    pixelArt: false,
    
    physics: {
        default: "arcade",
        
        arcade: {
            debug: SHARED_CONFIG.debug
        },
        
        matter: {
            debug: SHARED_CONFIG.debug
        }
    },
    
    scene: [
        new ManufacturerScene(SHARED_CONFIG),
        new PreloadScene(SHARED_CONFIG),
        new MenuScene(SHARED_CONFIG),
        new PlayScene(SHARED_CONFIG),
        new PauseScene(SHARED_CONFIG),
        new GameCompleteScene(SHARED_CONFIG),
        new OptionsScene(SHARED_CONFIG),
        new CreditsScene(SHARED_CONFIG),
        new TutorialScene(SHARED_CONFIG),
        new PlaybookScene(SHARED_CONFIG),
        new TurnCompleteScene(SHARED_CONFIG),
        new TurnEndedScene(SHARED_CONFIG),
        new NextAnomalyScene(SHARED_CONFIG),
        new ResolvedPortalScene(SHARED_CONFIG),
        new UnresolvedPortalScene(SHARED_CONFIG),
        new TransitionScene(SHARED_CONFIG),
        new GameOverScene(SHARED_CONFIG),
        new RewardedAdScene(SHARED_CONFIG)
    ]
};


window.game = new Phaser.Game(config);