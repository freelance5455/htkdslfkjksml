import { eventEmitter } from "../events/EventEmitter.js";
import { TurnEndedState } from "../states/TurnEndedState.js";
import { AnomalyToResolved } from "../movements/AnomalyToResolved.js";
import { getNonEmptyContainers } from "../utils/HelperFunctions.js";

const CARD_TITLES = {
    PAST_CARD: "Past Card",
    PRESENT_CARD: "Present Card",
    FUTURE_CARD: "Future Card",
    TIME_AGENT: "Time Agent",
    TIME_THIEF: "Time Thief"
};


export class Turn{
    constructor(scene){
        this.scene = scene;
        const { PreloadScene, TurnCompleteScene, PlayScene } = scene.game.scene.keys;
        this.turnCompleteScene = TurnCompleteScene;
        this.preloadScene = PreloadScene;
        this.playScene = PlayScene;
        const { deck, hand, anomalyPile, discard } = scene.gameplayUI;
        
        this.deck = deck;
        this.anomalyPile = anomalyPile;
        this.hand = hand;
        this.discard = discard;
        
        this.solvedObjectives = 0;
        this.CARD_TITLES = CARD_TITLES;
    }
    
    checkAnomalyResolved(){
        this.anomalyPile.scroll.checkboxGraphics.forEach((g)=>{
            if(g.name !== "") this.solvedObjectives++;
        })
        if(this.solvedObjectives=== this.anomalyPile.scroll.checkboxGraphics.length){
            if(!this.turnEndedState) this.turnEndedState = new TurnEndedState(this.playScene);
            this.turnEndedState.enter();
            eventEmitter.emit("TURN_COMPLETED");
        }
        else{
            const filledContainers = getNonEmptyContainers(this.hand.containers);
            if(this.deck.container.length === 0 && filledContainers.length <= 1){
                eventEmitter.emit("GAME_OVER");
            }
        }
        //EVENTEMITTER was emitting multipleTimes
        eventEmitter.off("TURN_COMPLETED");
        eventEmitter.once("TURN_COMPLETED", ()=>{
            //play turn completed sound
            this.preloadScene.audio.playerWinSound.play();

            //lock buttons
            this.playScene.gameplayUI.gameplayButtons.forEach(btn=>{
                this.playScene.inputLock.disableOne(btn.hitArea);
            })
            //lock cards
            const containers = getNonEmptyContainers(this.playScene.gameplayUI.hand.containers);
            containers.forEach(container=>{
                this.playScene.inputLock.disableOne(container.list[0]);
            })
            this.sendAnomalyToResolvedPile();
            this.enterTurnCompleteScene();
        })
        eventEmitter.off("GAME_OVER");
        eventEmitter.once("GAME_OVER", ()=>{
            //play turn completed sound
            this.preloadScene.audio.gameOverSound.play();
            this.scene.scene.start("GameOverScene");
        })
    }
    
    async doChoresBeforeEnteringTurnCompleteScene(){
        await this.sendAnomalyToResolvedPile();
    }
    
    sendAnomalyToResolvedPile(){
        return new Promise((resolve, reject) => {
            const command = new AnomalyToResolved(this.scene);
            this.playScene.commandHandler.execute(command);
        })
    }
    enterTurnCompleteScene(){
        return new Promise((resolve, reject) => {
            setTimeout(()=>{
                this.scene.scene.launch("TurnCompleteScene");
            }, 500)
        })
    }
    checkAnEmptyBox(){
        for(let i = 0; i < this.anomalyPile.scroll.checkboxGraphics.length; ++i){
            const graphics = this.anomalyPile.scroll.checkboxGraphics[i];
            if(!graphics.checked){
                //this.preloadScene.audio.play(this.preloadScene.audio.solveObjectiveSound);
                this.anomalyPile.scroll.checkBox(i);
                break;
            }
        }
    }
}