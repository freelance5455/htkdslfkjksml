//src/turns/ProgressMessage.js
export class ProgressMessage{

    constructor(scene){

        this.scene = scene;

        const { PlayScene } =
            scene.game.scene.keys;

        const {
            progressSectionRects,
            turnProgressMessageFontSize
        } = PlayScene.gameplayUI;

        this.fontSize =
            turnProgressMessageFontSize;

        this.sections =
            progressSectionRects;

        this.messages =
            scene.add.container(0, 0);
    }

    add(card){
       
        //SUIT
        let appendix;

        switch(card.getData("suit")){

            case "CLUB":
                appendix = "♣️";
                break;

            case "DIAMOND":
                appendix = "♦️";
                break;

            case "HEART":
                appendix = "♥️";
                break;

            case "SPADE":
                appendix = "♠️";
                break;
        }

        //VALUE
        let val;

        if(card.getData("value") === 11){
            val = "J";
        }
        else if(card.getData("value") === 12){
            val = "Q";
        }
        else{
            val = card.getData("value");
        }

        //POSITION
        if(this.messages.length < 8){

            const section =
                this.sections[this.messages.length];

            const msg =
                this.scene.add.text(
                    section.x,
                    section.y,
                    val + appendix,
                    {
                        fontSize: this.fontSize,
                        fontFamily: "myOtherFont",
                        color: "white"
                    }
                )
                .setOrigin(0)
                .setDepth(20);

            this.positionMessage(
                msg,
                section
            );

            this.messages.add(msg);
        }
        else{

            this.messages.removeAt(0, true);

            this.messages.list.forEach(
                (message, i) => {

                    this.positionMessage(
                        message,
                        this.sections[i]
                    );
                }
            );

            const index =
                this.messages.length;

            const section =
                this.sections[index];

            const msg =
                this.scene.add.text(
                    section.x,
                    section.y,
                    val + appendix,
                    {
                        fontSize: this.fontSize,
                        fontFamily: "myOtherFont",
                        color: "white"
                    }
                )
                .setOrigin(0)
                .setDepth(20);

            this.positionMessage(
                msg,
                section
            );
            
            this.messages.add(msg);
        }

        return this;
    }

    positionMessage(message, section){

        if(!message || !section){
            return;
        }

        message.setPosition(
            section.centerX -
            message.displayWidth / 2,
            section.centerY -
            message.displayHeight / 2
        );
    }

    updateLayout() {
    
    const { PlayScene } =
    this.scene.game.scene.keys;
    
    
    
    this.messages.setPosition(0, 0);
    this.messages.setScale(1, 1);
    this.messages.setRotation(0);
    
    this.messages.list.forEach(
        (message, index) => {
            
            const section =
                this.sections[index];
            
            if (!section) {
                console.log(
                    "NO SECTION FOR MESSAGE:",
                    index,
                    message.text
                );
                
                return;
            }
            
            message.setFontSize(
                this.fontSize
            );
            
            const newX =
                section.centerX -
                message.displayWidth / 2;
            
            const newY =
                section.centerY -
                message.displayHeight / 2;
            
            
            
            message.setPosition(
                newX,
                newY
            );
            
            message.setVisible(true);
            message.setActive(true);
        }
    );
    
    return this;
}

    clear(index){

        if(!this.messages[index]){
            return this;
        }

        this.messages[index]
            .setActive(false)
            .setVisible(false);

        this.messages[index].destroy();

        return this;
    }

    clearAll(){

        this.messages.destroy(true);

        this.messages =
            this.scene.add.container(0, 0);

        return this;
    }
}