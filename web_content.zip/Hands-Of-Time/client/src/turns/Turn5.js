import { Turn } from "./Turn.js";

export class Turn5 extends Turn{
    constructor(scene){
        super(scene);
    }
    
    executeFirstAction(card){
        this.firstCard = this.anomalyPile.container.list[0].getData("firstCard");
        this.secondCard = this.anomalyPile.container.list[0].getData("secondCard");
        this.thirdCard = this.anomalyPile.container.list[0].getData("thirdCard");
      
        if( ( ( (card.getData("value") < this.firstCard || card.getData("value") > this.thirdCard) &&
                (card.getData("title") !== this.CARD_TITLES.TIME_AGENT && card.getData("level") !== "EXPERT")) )&&
                this.playScene.registry.get("turn5_canProceed") === undefined){
                    alert("Play a Time Agent or one of "+ this.firstCard+ ", " + this.secondCard+", and "+ this.thirdCard);
                    return;
        }
        if((card.getData("value") >= this.firstCard || card.getData("value") <= this.secondCard) || card.getData("title") === this.CARD_TITLES.TIME_AGENT){
            this.playScene.registry.set("turn5_canProceed", 1);
            this.playScene.registry.inc("turn5_cardCounts", 1);
            
            if(card.getData("title") === this.CARD_TITLES.TIME_AGENT && card.getData("level") === "EXPERT"){
                const cardAttributes = {value: this.thirdCard}
                this.playScene.registry.get("turn5_cardsInfo").push(cardAttributes);
            }
            else{
                const cardAttributes = { value: card.getData("value") };
                this.playScene.registry.get("turn5_cardsInfo").push(cardAttributes);
            }
        }
        //if only one card has been played and is valid, check first box and play the sound
        if(this.playScene.registry.get("turn5_cardCounts") === 1){
            this.preloadScene.audio.play(this.preloadScene.audio.solveObjectiveSound);
            this.anomalyPile.scroll.checkBox(0);
        } 
    }
    executeSecondAction(card){
        const arrayOfCardsPlayed = this.playScene.registry.get("turn5_cardsInfo")
        const newCard = arrayOfCardsPlayed[arrayOfCardsPlayed.length-1] // same as 'card'
        const previousCard = arrayOfCardsPlayed[arrayOfCardsPlayed.length - 2];

        if(previousCard.value !== this.thirdCard){

            if( (newCard.value === previousCard.value+1 || newCard.value === previousCard.value-1 || newCard.value === 12) ){
                this.playScene.registry.inc("turn5_nextCheckboxProgress", 1);
                if(newCard.value === 12) newCard.value = this.secondCard;
                this.anomalyPile.scroll.checkBox(1);
                this.preloadScene.audio.play(this.preloadScene.audio.solveObjectiveSound);
            }
            else{
                arrayOfCardsPlayed.pop();
                this.preloadScene.audio.play(this.preloadScene.audio.errorSound);
                alert("The card (" +newCard.value +") you just played is more than 1 higher/lower than the first card ("+previousCard.value+")");
                return;
            }
        }
        else{
            newCard.value = previousCard.value-1;
            this.playScene.registry.inc("turn5_nextCheckboxProgress", 1);
            this.anomalyPile.scroll.checkBox(1);
            this.preloadScene.audio.play(this.preloadScene.audio.solveObjectiveSound);
        }
    }
executeThirdAction(card){
    const arrayOfCardsPlayed = this.playScene.registry.get("turn5_cardsInfo");
    const newCard = arrayOfCardsPlayed[arrayOfCardsPlayed.length-1]; 
    const secondCard = arrayOfCardsPlayed[arrayOfCardsPlayed.length - 2];
    const firstCard = arrayOfCardsPlayed[arrayOfCardsPlayed.length - 3];

    const isWild = (card.getData("value") === 12 && card.getData("level") === "EXPERT");

    // Wildcard is always valid
    if(isWild){
        this.playScene.registry.inc("turn5_nextCheckboxProgress", 1);
        this.anomalyPile.scroll.checkBox(2);
        this.preloadScene.audio.play(this.preloadScene.audio.solveObjectiveSound);
        return;
    }

    // Check the sequence direction
    if(secondCard.value === firstCard.value - 1){
        // descending sequence
        if(newCard.value === secondCard.value - 1){
            this.playScene.registry.inc("turn5_nextCheckboxProgress", 1);
            this.anomalyPile.scroll.checkBox(2);
            this.preloadScene.audio.play(this.preloadScene.audio.solveObjectiveSound);
        } else {
            arrayOfCardsPlayed.pop();
            this.preloadScene.audio.play(this.preloadScene.audio.errorSound);
            alert(`Invalid third card (${newCard.value}). Must be 1 less than the second card (${secondCard.value}) in descending order.`);
        }
    }
    else if(secondCard.value === firstCard.value + 1){
        // ascending sequence
        if(newCard.value === secondCard.value + 1){
            this.playScene.registry.inc("turn5_nextCheckboxProgress", 1);
            this.anomalyPile.scroll.checkBox(2);
            this.preloadScene.audio.play(this.preloadScene.audio.solveObjectiveSound);
        } else {
            arrayOfCardsPlayed.pop();
            this.preloadScene.audio.play(this.preloadScene.audio.errorSound);
            alert(`Invalid third card (${newCard.value}). Must be 1 greater than the second card (${secondCard.value}) in ascending order.`);
        }
    }
    else {
        // If somehow first/second don't establish a valid direction, reject.
        arrayOfCardsPlayed.pop();
        this.preloadScene.audio.play(this.preloadScene.audio.errorSound);
        alert(`Invalid sequence with first (${firstCard.value}) and second (${secondCard.value}). Third card can't be determined.`);
    }
}
    finishRound(){
        if(this.playScene.registry.get("turn5_nextCheckboxProgress") >= 2){
            this.preloadScene.audio.play(this.preloadScene.audio.solveObjectiveSound);
            this.anomalyPile.scroll.checkBox(1);
        }
        setTimeout(()=>{ this.checkAnomalyResolved(); }, 100)
    }
    solveObjectivesWith(card){
        
        this.playScene.registry.set("currentTurnIndex", 3);
        this.executeFirstAction(card);
        
        const arrayOfCardsPlayed = this.playScene.registry.get("turn5_cardsInfo");
        if(arrayOfCardsPlayed.length === 2){
            this.executeSecondAction(card);
        }
        if (arrayOfCardsPlayed.length >= 3) {
            this.executeThirdAction(card);
        }
        if (arrayOfCardsPlayed.length >= 7) {
            alert("WARNING⚠️  You have already played " + arrayOfCardsPlayed.length + " cards");
        }
        this.finishRound();
    }
}