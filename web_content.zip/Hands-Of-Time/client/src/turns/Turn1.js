import {Turn } from "./Turn.js";

export class Turn1 extends Turn{
    
    solveObjectivesWith(card){
        this.playScene.registry.set("currentTurnIndex", 0);

        if(card.getData("title")=== this.CARD_TITLES.PAST_CARD){
            this.preloadScene.audio.play(this.preloadScene.audio.solveObjectiveSound);
            this.anomalyPile.scroll.checkBox(0);
        }
        else if(card.getData("title") === this.CARD_TITLES.PRESENT_CARD){
            this.preloadScene.audio.play(this.preloadScene.audio.solveObjectiveSound);
            this.anomalyPile.scroll.checkBox(1); 
        }
        else if(card.getData("title") === this.CARD_TITLES.FUTURE_CARD){
            this.preloadScene.audio.play(this.preloadScene.audio.solveObjectiveSound);
            this.anomalyPile.scroll.checkBox(2);
        }
        else if(card.getData("title") === this.CARD_TITLES.TIME_AGENT){
            if(card.getData("level") === "EXPERT"){
                this.preloadScene.audio.play(this.preloadScene.audio.solveObjectiveSound);
                this.checkAnEmptyBox();
            }
            else{
                //its a novice, do nothing
            }
        }
        else if(card.getData("title") === this.CARD_TITLES.TIME_THIEF){
           // its a time thief, this is impossible;
        }
        else{
            alert("no title");
        }
        this.checkAnomalyResolved();
    }
}