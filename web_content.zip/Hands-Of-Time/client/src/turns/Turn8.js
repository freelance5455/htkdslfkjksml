import { Turn } from "./Turn.js";

export class Turn8 extends Turn{
    playFirstValidCard(card) {
        const title = card.getData("title");
        const value = card.getData("value");
    
        // --- TIME AGENTS are useless in Turn 8: always reject them ---
        if (title === this.CARD_TITLES.TIME_AGENT) {
            this.preloadScene.audio.play(this.preloadScene.audio.errorSound);
            alert("Time Agents (including Expert Agents) are useless for Turn 8. Play a non-face card (2–10).");
            return;
        }
    
        // Only accept numeric non-face cards 2..10
        if (typeof value !== "number" || value < 2 || value > 10) {
            this.preloadScene.audio.play(this.preloadScene.audio.errorSound);
            alert("Play any non-face card (2–10) to proceed.");
            return;
        }
    
        // Ensure the 9-slot container exists (card2 -> index 0 ... card10 -> index 8)
        if (!this.playScene.registry.get("turn8_allCards")) {
            const init = Array.from({ length: 9 }, () => ({ value: 0, resolved: false }));
            this.playScene.registry.set("turn8_allCards", init);
        }
    
        const cards = this.playScene.registry.get("turn8_allCards");
        const idx = value - 2; // map value 2..10 -> index 0..8
    
        cards[idx].value = (cards[idx].value || 0) + 1;
    
        // Persist in registry (safe even if registry stores by reference)
        this.playScene.registry.set("turn8_allCards", cards);
    
        // If this bucket gets to 2, resolve it
        if (cards[idx].value >= 2 && cards[idx].resolved === false) {
            cards[idx].resolved = true;
            // Persist change
            this.playScene.registry.set("turn8_allCards", cards);
    
            // trigger resolution UI / sound
            this.checkAnEmptyBox();
            this.preloadScene.audio.play(this.preloadScene.audio.solveObjectiveSound);
        }
    
        // mark that we can proceed (keeps legacy checks working)
        if (this.playScene.registry.get("turn8_canProceed") === undefined) {
            this.playScene.registry.set("turn8_canProceed", 1);
        } else {
            this.playScene.registry.inc("turn8_canProceed", 1);
        }
    }
    
    solveObjectivesWith(card) {
        this.playScene.registry.set("currentTurnIndex", 7);
        this.playFirstValidCard(card);
        setTimeout(() => { this.checkAnomalyResolved(); }, 100);
    }

}