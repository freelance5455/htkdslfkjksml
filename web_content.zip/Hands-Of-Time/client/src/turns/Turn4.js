import { Turn } from "./Turn.js";

export class Turn4 extends Turn{
    constructor(scene){
        super(scene);
    }
    
    executeFirstAction(card){
        // Reject non-expert Queens
        if(card.getData("title") === this.CARD_TITLES.TIME_AGENT && card.getData("level") !== "EXPERT"){
            alert("A non-expert Queen can't be used to resolve this anomaly.");
            this.preloadScene.audio.play(this.preloadScene.audio.errorSound);
            return;
        }
    
        if(((card.getData("value") < 4 &&
             card.getData("title") !== this.CARD_TITLES.TIME_AGENT)) &&
             this.playScene.registry.get("turn4_canProceed") === undefined){
            alert("Play an Expert Time Agent or any other card higher than 3 to proceed");
            this.preloadScene.audio.play(this.preloadScene.audio.errorSound);
            return;
        }
    
        if(card.getData("value") >=4 || card.getData("title") === this.CARD_TITLES.TIME_AGENT){
            this.playScene.registry.set("turn4_canProceed", 1);
            this.playScene.registry.inc("turn4_cardCounts", 1);
    
            let cardAttributes;
            if(card.getData("title") === this.CARD_TITLES.TIME_AGENT){
                cardAttributes = {
                    value: card.getData("value"), 
                    suit: "TimeAgent", 
                    display: `Time Agent (${card.getData("value")})`,
                    expert: (card.getData("level") === "EXPERT")
                };
            } else {
                cardAttributes = {
                    value: card.getData("value"), 
                    suit: card.getData("suit"),
                    display: `${card.getData("value")}${card.getData("suit")}`
                };
            }
    
            this.playScene.registry.get("turn4_cardsInfo").push(cardAttributes);
        }
    
        if(this.playScene.registry.get("turn4_cardCounts") === 1){
            this.preloadScene.audio.play(this.preloadScene.audio.solveObjectiveSound);
            this.anomalyPile.scroll.checkBox(0);
        } 
    }
    
    
    executeSecondAction(card){
        // Reject non-expert Queens
        if(card.getData("title") === this.CARD_TITLES.TIME_AGENT && card.getData("level") !== "EXPERT"){
            alert("A non-expert Queen can't be used to resolve this anomaly.");
            this.preloadScene.audio.play(this.preloadScene.audio.errorSound);
            return;
        }
    
        const arrayOfCardsPlayed = this.playScene.registry.get("turn4_cardsInfo");
        const newCard = arrayOfCardsPlayed[arrayOfCardsPlayed.length-1]; 
        const previousCard = arrayOfCardsPlayed[arrayOfCardsPlayed.length - 2];
    
        // If Expert Time Agent → assign relative value
        if(newCard.suit === "TimeAgent" && newCard.expert){
            newCard.value = previousCard.value - 1;
            newCard.display = `Expert Time Agent (${newCard.value})`;
        }
    
        let valid = false;
        if(previousCard.suit === "TimeAgent" || newCard.suit === "TimeAgent"){
            valid = (newCard.value < previousCard.value);
        } else {
            valid = (newCard.value < previousCard.value) && (newCard.suit !== previousCard.suit);
        }
    
        if(valid){
            this.playScene.registry.inc("turn4_nextCheckboxProgress", 1);
            this.preloadScene.audio.play(this.preloadScene.audio.solveObjectiveSound);
        } 
        else {
            arrayOfCardsPlayed.pop();
            this.playScene.registry.inc("turn4_cardCounts", -1);
    
            alert(
                `You played an invalid card.\n` +
                `Rule: Second card must be LOWER in rank and a DIFFERENT suit.\n` +
                `Previous card was: ${previousCard.display}`
            );
            this.preloadScene.audio.play(this.preloadScene.audio.errorSound);
        }
    }
    
    
    executeThirdAction(card){
        // Reject non-expert Queens
        if (card.getData("title") === this.CARD_TITLES.TIME_AGENT && card.getData("level") !== "EXPERT") {
            alert("A non-expert Queen can't be used to resolve this anomaly.");
            this.preloadScene.audio.play(this.preloadScene.audio.errorSound);
            return;
        }
    
        const arrayOfCardsPlayed = this.playScene.registry.get("turn4_cardsInfo");
        const newCard = arrayOfCardsPlayed[arrayOfCardsPlayed.length - 1];
        const previousCard = arrayOfCardsPlayed[arrayOfCardsPlayed.length - 2];
        const firstCard = arrayOfCardsPlayed[arrayOfCardsPlayed.length - 3];
    
        // If Expert Time Agent → assign relative value
        if (newCard.suit === "TimeAgent" && newCard.expert) {
            newCard.value = previousCard.value - 1;
            newCard.display = `Expert Time Agent (${newCard.value})`;
        }
    
        let valid = false;
    
        // Case: both first and second are wild → ignore suits, check descending only
        if (firstCard.suit === "TimeAgent" && firstCard.expert &&
            previousCard.suit === "TimeAgent" && previousCard.expert) {
            valid = newCard.value < previousCard.value;
        }
        // Case: first is wild, second is normal → check descending + suit vs second
        else if (firstCard.suit === "TimeAgent" && firstCard.expert) {
            valid = (newCard.value < previousCard.value) &&
                    (newCard.suit !== previousCard.suit);
        }
        // Case: second is wild, first is normal → check descending + suit vs first
        else if (previousCard.suit === "TimeAgent" && previousCard.expert) {
            valid = (newCard.value < previousCard.value) &&
                    (newCard.suit !== firstCard.suit);
        }
        // Case: neither is wild → check descending + suit vs both
        else {
            valid = (newCard.value < previousCard.value) &&
                    (newCard.suit !== previousCard.suit &&
                     newCard.suit !== firstCard.suit);
        }
    
        if (valid) {
            this.playScene.registry.inc("turn4_nextCheckboxProgress", 1);
        } else {
            arrayOfCardsPlayed.pop();
            this.playScene.registry.inc("turn4_cardCounts", -1);
    
            alert(
                `You played an invalid card.\n` +
                `Rule: Third card must be LOWER in rank and follow suit rules:\n` +
                `- If both earlier are wild: suits ignored.\n` +
                `- If one is wild: compare suits only with the non-wild.\n` +
                `- If none are wild: must differ from both.\n\n` +
                `Previous cards were: ${firstCard.display}, ${previousCard.display}`
            );
            this.preloadScene.audio.play(this.preloadScene.audio.errorSound);
        }
    }

finishRound(){
        if(this.playScene.registry.get("turn4_nextCheckboxProgress") >= 2){
            this.preloadScene.audio.play(this.preloadScene.audio.solveObjectiveSound);
            this.anomalyPile.scroll.checkBox(1);
        }
        setTimeout(()=>{ this.checkAnomalyResolved(); }, 100)
    }
    solveObjectivesWith(card){
        
        this.playScene.registry.set("currentTurnIndex", 3);
        this.executeFirstAction(card);
        
        const arrayOfCardsPlayed = this.playScene.registry.get("turn4_cardsInfo");
        if(arrayOfCardsPlayed.length === 2){
            this.executeSecondAction(card);
        }
        if (arrayOfCardsPlayed.length >= 3) {
            const arrayOfCardsPlayed = this.playScene.registry.get("turn4_cardsInfo");
            this.executeThirdAction(card);
        }
        if (arrayOfCardsPlayed.length >= 7) {
            alert("WARNING⚠️  You have already played " + arrayOfCardsPlayed.length + " cards");
        }
        this.finishRound();
    }
}