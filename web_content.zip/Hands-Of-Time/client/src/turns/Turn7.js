import { Turn } from "./Turn.js";

export class Turn7 extends Turn{
    constructor(scene){
        super(scene);
    }
    solveObjectivesWith(card) {
        this.playScene.registry.set("currentTurnIndex", 6);
    
        // Ensure the registry variables exist
        if (!this.playScene.registry.get("turn7_cardsInfo")) {
            this.playScene.registry.set("turn7_cardsInfo", []);
            this.playScene.registry.set("turn7_canProceed", 0);
            this.playScene.registry.set("turn7_nextCheckboxProgress", 0);
            this.playScene.registry.set("turn7_cardCounts", 0);
        }
    
        const cardTitle = card.getData("title");
        const cardLevel = card.getData("level");
        let cardValue = card.getData("value");
        const cardsPlayed = this.playScene.registry.get("turn7_cardsInfo");
    
        // --- FIRST ACTION ---
        if (cardsPlayed.length === 0) {
            // Expert Time Agent wildcard logic: first card defaults to 7
            if (cardTitle === this.CARD_TITLES.TIME_AGENT && cardLevel === "EXPERT") {
                cardValue = 7;
            }
    
            if (
                cardValue <= 7 ||
                (cardTitle === this.CARD_TITLES.TIME_AGENT && cardLevel === "EXPERT")
            ) {
                this.playScene.registry.set("turn7_canProceed", 1);
                this.playScene.registry.inc("turn7_cardCounts", 1);
                cardsPlayed.push({ value: cardValue });
    
                this.preloadScene.audio.play(this.preloadScene.audio.solveObjectiveSound);
                this.anomalyPile.scroll.checkBox(0);
            } else {
                this.preloadScene.audio.play(this.preloadScene.audio.errorSound);
                alert("Play any non-face card (2–7) or an Expert Time Agent to proceed.");
                return;
            }
        }
    
        // --- NEXT ACTIONS ---
        else {
            const prevCard = cardsPlayed[cardsPlayed.length - 1];
            const isExpertAgent = (cardTitle === this.CARD_TITLES.TIME_AGENT && cardLevel === "EXPERT");
    
            // Expert Time Agent acts as wildcard: value = prev + 1
            if (isExpertAgent) {
                cardValue = prevCard.value + 1;
            }
    
            if (Math.abs(cardValue - prevCard.value) <= 1) {
                cardsPlayed.push({ value: cardValue });
                this.playScene.registry.inc("turn7_nextCheckboxProgress", 1);
    
                const boxIndex = cardsPlayed.length - 1;
                this.anomalyPile.scroll.checkBox(boxIndex);
                this.preloadScene.audio.play(this.preloadScene.audio.solveObjectiveSound);
            } else {
                this.preloadScene.audio.play(this.preloadScene.audio.errorSound);
                alert(`The card (${cardValue}) you just played is more than ±1 from the last card (${prevCard.value}).`);
                return;
            }
        }
    
        // --- SAFETY LIMIT ---
        if (cardsPlayed.length >= 7) {
            alert(`⚠️ WARNING: You have already played ${cardsPlayed.length} cards`);
        }
    
        // --- FINISH ROUND CHECK ---
        this.finishRound();
    }

    finishRound() {
        const progress = this.playScene.registry.get("turn7_nextCheckboxProgress") || 0;
        // Adjust threshold as needed (2, 3, or 4 depending on anomaly difficulty)
        if (progress >= 2) {
            this.preloadScene.audio.play(this.preloadScene.audio.solveObjectiveSound);
            setTimeout(() => this.checkAnomalyResolved(), 150);
        }
    }
}