// src/ApplixirSDK.js

/**
 * Applixir SDK Loader & Wrapper
 * Provides a unified Promise-based rewarded ad function.
 */

const DEBUG = false; // Set true to see internal logs

function log(...args) {
    if (DEBUG) console.log(...args);
}

class ApplixirSDK {
  constructor() {
    this.sdkReady = false;
    this.sdkLoaded = false;

    // Will hold the Applixir `application` instance
    this.application = null;

    this.loadSDK();
  }

  loadSDK() {
    if (this.sdkLoaded) return;
    this.sdkLoaded = true;

    // Inject Applixir script if not already present
    if (!document.getElementById("applixir-sdk")) {
      const script = document.createElement("script");
      script.id = "applixir-sdk";
      script.type = "text/javascript";
      script.src = "https://cdn.applixir.com/applixir.app.v6.0.1.js";

      script.onload = () => {
        log("Applixir main script loaded.");

        this.initializeApplication();
      };

      script.onerror = () => {
        console.error("Failed to load Applixir SDK.");
      };

      document.head.appendChild(script);
    }
  }

  initializeApplication() {
  const initialize = () => {
    if (this.application || !window.Application) {
      return;
    }
    
    const options = {
      apiKey: "46108c2a-ccf2-4845-bf47-c5afb9afc5be",
      injectionElementId: "applixir-ad-container",
      
      adStatusCallbackFn: (status) => {
        //console.log("Applixir status:", status);
        this.handleAdStatus(status);
      },
      
      adErrorCallbackFn: (error) => {
       // console.error("Applixir error:", error);
        this.handleAdError(error);
      }
    };
    
    try {
      this.application = new window.Application(options);
      this.application.initialize();
      this.sdkReady = true;
      
      console.log("Applixir SDK initialized.");
    } catch (error) {
      console.error("Applixir initialization failed:", error);
      this.sdkReady = false;
    }
  };
  
  if (document.readyState === "complete") {
    initialize();
  } else {
    window.addEventListener("load", initialize, { once: true });
  }
}

  /**
   * Show a rewarded ad via Promise
   */
  showRewardedAd(onAdStarted = null) {
  if (!this.sdkReady || !this.application) {
    //console.warn("Applixir SDK is not ready.");
    return Promise.resolve(false);
  }
  
  if (this._resolveAd) {
    this._resolveAd(false);
  }
  
  return new Promise((resolve) => {
    let settled = false;
    
    const finish = (completed) => {
      if (settled) return;
      
      settled = true;
      
      clearTimeout(this._adTimeout);
      
      this._resolveAd = null;
      this._adTimeout = null;
      this._onAdStarted = null;
      
     /* console.log(
        "Applixir ad result:",
        completed ? "completed" : "not completed"
      );
      */
      resolve(completed);
    };
    
    this._resolveAd = finish;
    
    this._onAdStarted = () => {
      if (settled) return;
      
      clearTimeout(this._adTimeout);
      this._adTimeout = null;
      
      if (typeof onAdStarted === "function") {
        onAdStarted();
      }
    };
    
    this._adTimeout = setTimeout(() => {
      console.warn("Applixir timed out while retrieving ad.");
      finish(false);
    }, 15000);
    
    try {
     // console.log("Applixir: Opening rewarded ad...");
      this.application.openPlayer();
    } catch (error) {
     // console.error("Applixir could not open the player:", error);
      finish(false);
    }
  });
}

  /**
   * Handle Applixir Status Updates
   */
  handleAdStatus(status) {
  console.log("Applixir status received:", status);
  
  const type = typeof status === "string" ?
    status :
    status?.type;
  
  if (!this._resolveAd) return;
  
  switch (type) {
    case "ad-started":
    case "adStarted":
    case "started":
    case "start":
     // console.log("Applixir: Ad playback started.");
      
      if (this._onAdStarted) {
        this._onAdStarted();
        this._onAdStarted = null;
      }
      break;
      
    case "ad-watched":
    case "ad-completed":
    case "complete":
      this._resolveAd(true);
      break;
      
    case "no-ad":
    case "no-ad-available":
    case "ad-error":
    case "ad-closed":
    case "ad-skipped":
    case "error":
      this._resolveAd(false);
      break;
  }
}

  /**
   * Handle Applixir Errors
   */
  handleAdError(error) {
    if (this._resolveAd) {
      this._resolveAd(false);
      this._resolveAd = null;
    }
  }
}

// Create a global instance (replaces gameMonetize)
export const applixir = new ApplixirSDK();

// Export in case ES modules are used