import { BaseScene } from "./BaseScene.js";
import domUI from "../ui/domUIManager.js";
import { getNonEmptyContainers } from "../utils/HelperFunctions.js";

export class TurnEndedScene extends BaseScene {
    constructor(config) {
        super("TurnEndedScene", config);

        this.config = config;
        this.turnEndedMode = false;
    }

    destroyEvents() {
    }

    enter() {
        this.destroyEvents();

        this.registry.set(
            "TurnWasCompleted",
            "no"
        );
    }

    injectUI() {
        this.dom = domUI.show(`
            <section id="ht-turn-ended-root">

                <div id="ht-turn-ended-panel">

                    <div id="ht-turn-ended-header">
                        <h2>TURN ENDED</h2>

                        <p>
                            What would you like to do?
                        </p>
                    </div>

                    <div id="ht-turn-ended-buttons">

                        <button
                            id="ht-turn-ended-back-btn"
                        >
                            GO BACK IN TIME
                        </button>

                        <button
                            id="ht-turn-ended-return-btn"
                        >
                            RETURN
                        </button>

                        <button
                            id="ht-turn-ended-future-btn"
                        >
                            TO THE FUTURE
                        </button>

                    </div>

                </div>

            </section>
        `);
    }

    goBackInTime() {
    const button = this.dom.querySelector(
        "#ht-turn-ended-back-btn"
    );
    
    button.addEventListener("click", () => {
        this.preloadScene.audio.play(
            this.preloadScene.audio.buttonClickSound
        );
        
        this.registry.set(
            "comingFrom",
            "TurnEndedBackBtn"
        );
        
        this.scene.start("TransitionScene");
    });
}

resume() {
    const button = this.dom.querySelector(
        "#ht-turn-ended-return-btn"
    );
    
    button.addEventListener("click", () => {
        this.preloadScene.audio.play(
            this.preloadScene.audio.buttonClickSound
        );
        
        domUI.clear();
        
        this.scene.stop();
        this.scene.resume("PlayScene");
        
        this.playScene.gameplayUI.gameplayButtons
            .forEach(btn => {
                this.playScene.inputLock.enableOne(
                    btn.hitArea
                );
            });
        
        const containers = getNonEmptyContainers(
            this.playScene.gameplayUI.hand.containers
        );
        
        containers.forEach(container => {
            this.playScene.inputLock.enableOne(
                container.list[0]
            );
        });
        
        this.playScene.inputLock.enableOne(
            this.playScene.gameplayUI
            .anomalyPile
            .container
            .list[0]
        );
    });
}

goToTheFuture() {
    const button = this.dom.querySelector(
        "#ht-turn-ended-future-btn"
    );
    
    button.addEventListener("click", () => {
        this.preloadScene.audio.play(
            this.preloadScene.audio.buttonClickSound
        );
        
        this.registry.set(
            "comingFrom",
            "TurnEndedFutureBtn"
        );
        
        this.scene.start("TransitionScene");
    });
}

    create() {
        this.enter();

        const {
            PreloadScene,
            PlayScene
        } = this.game.scene.keys;

        this.preloadScene = PreloadScene;
        this.playScene = PlayScene;

        domUI.clear();

        this.injectUI();

        // Hide anomaly textbox
        this.playScene.anomalyTextbox.hide();

        // Lock gameplay buttons
        this.playScene.gameplayUI.gameplayButtons
            .forEach(btn => {
                this.playScene.inputLock.disableOne(
                    btn.hitArea
                );
            });

        // Lock hand cards
        const containers =
            getNonEmptyContainers(
                this.playScene.gameplayUI.hand.containers
            );

        containers.forEach(container => {
            this.playScene.inputLock.disableOne(
                container.list[0]
            );
        });

        // Lock current anomaly
        this.playScene.inputLock.disableOne(
            this.playScene.gameplayUI
                .anomalyPile
                .container
                .list[0]
        );

        this.goBackInTime();
        this.resume();
        this.goToTheFuture();
    }

    shutdown() {
        domUI.clear();
    }
}