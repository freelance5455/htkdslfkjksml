import { BaseScene } from "./BaseScene.js";
import AudioManager from "../managers/AudioManager.js";
import domUI from "../ui/domUIManager.js";

export class PreloadScene extends BaseScene {
    constructor(config) {
        super("PreloadScene", config);
        this.config = config;
        
        this.totalFiles = 0;
        this.loadedFiles = 0;
        this.text = "assets";
    }
    
    loadFiles() {
        this.text = "sounds";
        
        const audioFiles = [
           // ["menuSong", "/client/assets/audio/menu.mp3"],
            ["errorSound", "client/assets/audio/error_sound.wav"],
            ["clockTickSound", "client/assets/audio/clock.ogg"],
            ["playSong", "client/assets/audio/new_game.mp3"],
            ["gameOverSound", "client/assets/audio/game_over.ogg"],
            ["playerWinSound", "client/assets/audio/win_turn.mp3"],
            ["gameCompleteSound", "client/assets/audio/win_turn.mp3"],
            ["popUpSound", "client/assets/audio/pop_up.mp3"],
            ["shuffleSound", "client/assets/audio/card_shuffle.mp3"],
            ["buttonClickSound", "client/assets/audio/click.mp3"],
            ["drawSound", "client/assets/audio/draw.wav"],
            ["swooshSound", "client/assets/audio/card_swooshing.wav"],
            ["solveObjectiveSound", "client/assets/audio/solve_objective.wav"],
            ["swapSound", "client/assets/audio/card_swap.mp3"]
        ];
        
        audioFiles.forEach(file => {
            this.load.audio(...file);
        });
        
        this.text = "images";
        
        this.load.image(
            "scrollBody",
            "client/assets/images/scroll_body.png"
        );
        
        this.load.image(
            "scrollEnd",
            "client/assets/images/scroll_end.png"
        );
        
        this.load.image(
            "play_bg_landscape",
            "client/assets/images/play_bg_landscape.jpg"
        );
        
        this.load.image(
            "play_bg_portrait",
            "client/assets/images/play_bg_portrait.jpg"
        );
        
        this.load.spritesheet(
            "cards",
            "client/assets/images/cards.png",
            {
                frameWidth: 88,
                frameHeight: 128
            }
        );
    }
    
    preload() {
        domUI.clear();
        
        this.dom = domUI.show(`
            <div class="preload-screen">

                <div class="preload-progress">

                    <svg
                        class="preload-circle"
                        viewBox="0 0 120 120"
                    >
                        <circle
                            class="preload-circle-track"
                            cx="60"
                            cy="60"
                            r="52"
                        ></circle>

                        <circle
                            class="preload-circle-progress"
                            cx="60"
                            cy="60"
                            r="52"
                        ></circle>

                        <text
                            class="preload-percentage"
                            x="60"
                            y="60"
                        >
                            0%
                        </text>
                    </svg>

                </div>

                <div class="preload-loading-text">
                    Loading assets...
                </div>

                <div class="preload-wait-text">
                    Please wait
                </div>

            </div>
        `);
        
        this.loadingText = this.dom.querySelector(
            ".preload-loading-text"
        );
        
        this.loadingText2 = this.dom.querySelector(
            ".preload-wait-text"
        );
        
        this.progressCircle = this.dom.querySelector(
            ".preload-circle-progress"
        );
        
        this.percentageText = this.dom.querySelector(
            ".preload-percentage"
        );
        
        this.updateBackground();
        
        this.totalFiles = 0;
        this.loadedFiles = 0;
        
        this.registry.set("assetsTotal", 0);
        
        this.load.on("addfile", () => {
            this.totalFiles++;
            
            this.registry.inc("assetsTotal", 1);
        });
        
        this.load.on(
            "filecomplete",
            (key, type) => {
                this.loadedFiles++;
                
                const progress =
                    this.totalFiles > 0 ?
                    this.loadedFiles / this.totalFiles :
                    0;
                
                const percentage =
                    Math.ceil(progress * 100);
                
                this.progressCircle.style.strokeDashoffset =
                    326.73 - (326.73 * progress);
                
                this.percentageText.textContent =
                    percentage + "%";
                
                this.loadingText.textContent =
                    "Loading " + type + "...";
            }
        );
        
        this.load.on("complete", () => {
            this.loadedFiles = this.totalFiles;
            
            this.progressCircle.style.strokeDashoffset = 0;
            
            this.percentageText.textContent = "100%";
            
            this.loadingText.textContent =
                "Tap anywhere to continue";
            
            if (this.loadingText2) {
                this.loadingText2.remove();
                this.loadingText2 = null;
            }
            
            const screen =
                this.dom.querySelector(".preload-screen");
            
            screen.addEventListener(
                "pointerdown",
                this.handleContinue
            );
        });
        
        this.loadFiles();
    }
    
    create() {
        this.audio = new AudioManager(this);
        
        this.resizeHandler = () => {
            this.updateBackground();
        };
        
        window.addEventListener(
            "resize",
            this.resizeHandler
        );
    }
    
    handleContinue = () => {
        this.toggleFullscreen();
        
        this.shutdown();
        this.scene.start("MenuScene");
    };
    
    updateBackground() {
        if (!this.dom) {
            return;
        }
        
        const screen =
            this.dom.querySelector(".preload-screen");
        
        const isPortrait =
            window.innerHeight > window.innerWidth;
        
        screen.classList.toggle(
            "portrait",
            isPortrait
        );
        
        screen.classList.toggle(
            "landscape",
            !isPortrait
        );
    }
    
    toggleFullscreen() {
        if (!document.fullscreenElement) {
            document.documentElement.requestFullscreen();
        }
        else if (document.exitFullscreen) {
            document.exitFullscreen();
        }
    }
    
    shutdown() {
        if (this.resizeHandler) {
            window.removeEventListener(
                "resize",
                this.resizeHandler
            );
            
            this.resizeHandler = null;
        }
        
        if (this.dom) {
            const screen =
                this.dom.querySelector(".preload-screen");
            
            if (screen) {
                screen.removeEventListener(
                    "pointerdown",
                    this.handleContinue
                );
            }
        }
        
        domUI.clear();
    }
}