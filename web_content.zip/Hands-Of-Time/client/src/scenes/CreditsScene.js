import { BaseScene } from "./BaseScene.js";
import { eventEmitter } from "../events/EventEmitter.js";
import domUI from "../ui/domUIManager.js";

export class CreditsScene extends BaseScene {
    constructor(config) {
        super("CreditsScene", config);
        
        this.config = config;
    }
    
    injectUI() {
        this.dom = domUI.show(`
            <section id="ht-credits-root">

                <div id="ht-credits-panel">

                    <div id="ht-credits-header">
                        <h2>CREDITS</h2>
                    </div>

                    <div id="ht-credits-content">

                        <div class="ht-credits-section">
                            <h3>DEVELOPMENT</h3>
                            <p>ATP Game Studio</p>
                        </div>

                        <div class="ht-credits-section">
                            <h3>GAME</h3>
                            <p>Hands of Time</p>
                        </div>

                    </div>

                    <div id="ht-credits-buttons">

                        <button id="ht-credits-menu-btn">
                            MENU
                        </button>

                    </div>

                </div>

            </section>
        `);
        
        this.menuBtn =
            this.dom.querySelector("#ht-credits-menu-btn");
    }
    
    create() {
        domUI.clear();
        
        this.injectUI();
        
        this.initEvents();
        
        eventEmitter.off("CreditsToMenu");
        
        eventEmitter.once(
            "CreditsToMenu",
            () => {
                this.shutdown();
                this.scene.start("MenuScene");
            }
        );
    }
    
    initEvents() {
        this.menuBtn.addEventListener(
            "click",
            () => {
                eventEmitter.emit("CreditsToMenu");
            }
        );
    }
    
    shutdown() {
        domUI.clear();
    }
}