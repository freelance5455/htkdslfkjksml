import { BaseScene } from "./BaseScene.js";
import { eventEmitter } from "../events/EventEmitter.js";
import domUI from "../ui/domUIManager.js";
import NotificationModal from "../ui/NotificationModal.js";

export class PauseScene extends BaseScene {
    constructor(config) {
        super("PauseScene", config);

        this.config = config;
        this.gamePaused = false;
    }

    injectUI() {
        this.dom = domUI.show(`
            <section id="ht-pause-root">

                <div id="ht-pause-header">
                    <button id="ht-pause-resume-btn">X</button>
                    <div id="ht-pause-title">PAUSED</div>
                </div>

                <div id="ht-pause-buttons">

                    <button
                        id="ht-pause-options-btn"
                        disabled
                    >
                        OPTIONS
                    </button>

                    <button id="ht-pause-playbook-btn">
                        PLAYBOOK
                    </button>

                    <button
                        id="ht-pause-save-btn"
                        disabled
                    >
                        SAVE
                    </button>

                    <button id="ht-pause-menu-btn">
                        MENU
                    </button>

                </div>

            </section>
        `);

        this.resumeBtn =
            this.dom.querySelector("#ht-pause-resume-btn");

        this.optionsBtn =
            this.dom.querySelector("#ht-pause-options-btn");

        this.playbookBtn =
            this.dom.querySelector("#ht-pause-playbook-btn");

        this.saveBtn =
            this.dom.querySelector("#ht-pause-save-btn");

        this.menuBtn =
            this.dom.querySelector("#ht-pause-menu-btn");
    }

    create() {
        const { PreloadScene } =
            this.game.scene.keys;

        this.preloadScene = PreloadScene;

        domUI.clear();

        this.injectUI();

        this.handleGamePause();
    }

    handleGamePause() {
        const { PlayScene } =
            this.game.scene.keys;

        PlayScene.watch.stopWatch();

        this.gamePaused = true;

        this.resumeBtn.addEventListener(
    "click",
    () => {
        if (!this.gamePaused) {
            return;
        }

        domUI.clear();

        this.scene.stop();

        if (this.scene.isPaused("PlayScene")) {
            this.scene.resume("PlayScene");
        }

        this.gamePaused = false;
    },
    { once: true }
);

        this.playbookBtn.addEventListener(
    "click",
    () => {
         this.preloadScene.audio.popUpSound.play();

        domUI.clear();

        this.scene.stop();
        this.scene.launch("PlaybookScene");
    }
);

        this.menuBtn.addEventListener(
            "click",
            () => {
                //this.preloadScene.audio.popUpSound.play();

                NotificationModal.open({
                    title: "RETURN TO MENU?",
                    message:
                        "Are you sure you want to return to the menu?",
                    type: "warning",
                    showCancel: true,
                    confirmText: "Yes",
                    cancelText: "No",

                    onConfirm: () => {
                        this.registry.set(
                            "gamePaused",
                            true
                        );

                       // this.preloadScene.audio.popUpSound.play();

                        domUI.clear();

                        this.scene.stop();

                        this.scene.start("MenuScene");
                    }
                });
            }
        );

        this.optionsBtn.addEventListener(
            "click",
            () => {
                this.preloadScene.audio.popUpSound.play();

                this.scene.stop();

                this.scene.launch("OptionsScene");
            }
        );
    }

    shutdown() {
        domUI.clear();
    }
}