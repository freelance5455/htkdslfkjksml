import { BaseScene } from "./BaseScene.js";
import { eventEmitter } from "../events/EventEmitter.js";
import domUI from "../ui/domUIManager.js";

export class PlaybookScene extends BaseScene {
    constructor(config) {
        super("PlaybookScene", config);

        this.config = config;
        this.gamePaused = false;
        this.currentSlide = 0;
        this.handleKeyDown = null;
    }

    injectUI() {
        this.dom = domUI.show(`
            <section id="playbookScreen" class="playbook">

                <div class="playbook__panel">

                    <header class="playbook__header">
                        <h2 class="playbook__title">
                            Time-Travel Playbook
                        </h2>

                        <span class="playbook__subtitle">
                            Quick Reference
                        </span>
                    </header>

                    <div class="slider-wrapper">

                        <button class="slide-btn prev">
                            ⟵
                        </button>

                        <div class="slider">

                            <div
                                class="section"
                                id="rolesSection"
                            >
                                <h3>Card Roles</h3>

                                <div class="card-role-grid">

                                    <div class="card">
                                        <span class="label">
                                            2–4 Past
                                        </span>

                                        <span class="desc">
                                            Generate 1 resource
                                        </span>
                                    </div>

                                    <div class="card">
                                        <span class="label">
                                            5–7 Present
                                        </span>

                                        <span class="desc">
                                            Generate 2 resources
                                        </span>
                                    </div>

                                    <div class="card">
                                        <span class="label">
                                            8–10 Future
                                        </span>

                                        <span class="desc">
                                            Generate 3 resources
                                        </span>
                                    </div>

                                    <div class="card">
                                        <span class="label">
                                            Aces & Kings
                                        </span>

                                        <span class="desc">
                                            Time Anomalies
                                        </span>
                                    </div>

                                </div>
                            </div>

                            <div
                                class="section"
                                id="specialSection"
                            >
                                <h3>Special Cards</h3>

                                <div class="special-list">

                                    <div class="special">

                                        <div class="icon">
                                            J
                                        </div>

                                        <div class="body">

                                            <span class="title">
                                                Jack → Time Thief
                                            </span>

                                            <div class="small">
                                                ♣/♠ Steal 8 resources<br>
                                                ♥/♦ Force discard 1 card
                                            </div>

                                        </div>

                                    </div>

                                    <div class="special">

                                        <div class="icon">
                                            Q
                                        </div>

                                        <div class="body">

                                            <span class="title">
                                                Queen → Time Agent
                                            </span>

                                            <div class="small">
                                                ♣/♠ Novice: +5 resources<br>
                                                ♥/♦ Expert: Wild (acts as 2–10)
                                            </div>

                                        </div>

                                    </div>

                                </div>
                            </div>

                            <div
                                class="section"
                                id="anomaliesSection"
                            >
                                <h3>Resolving Anomalies</h3>

                                <p>
                                    Use card combinations and generated
                                    resources to resolve anomalies
                                    (click anomaly for examples).
                                    Failure to resolve = paradox!
                                </p>
                            </div>

                            <div
                                class="section"
                                id="tipsSection"
                            >
                                <h3>Quick Tips</h3>

                                <div class="tips">
                                    <ul>
                                        <li>
                                            Press Resolve button once to activate,
                                            press again to deactivate.
                                        </li>

                                        <li>
                                            Tap the Draw button to draw a card
                                            from Deck. Wait 0.5 seconds to tap again.
                                        </li>

                                        <li>
                                            Press Discard button once to activate,
                                            then tap on any card to discard it.
                                        </li>

                                        <li>
                                            When Swap button is activated,
                                            tapping on any card will send it to Deck.
                                            You get a random card in return.
                                        </li>

                                        <li>
                                            Use End button to end a turn and pick
                                            another anomaly.
                                        </li>

                                        <li>
                                            You can only check card info if all
                                            buttons are deactivated.
                                        </li>

                                        <li>
                                            Discarding Future cards = many
                                            resources generated
                                        </li>

                                        <li>
                                            Only discard when absolutely necessary.
                                        </li>

                                        <li>
                                            Save Expert Queens for emergencies
                                        </li>

                                        <li>
                                            Beware of Jacks disrupting resources
                                        </li>
                                    </ul>
                                </div>
                            </div>

                            <div
                                class="section"
                                id="rulebookSection"
                            >
                                <h3>
                                    🔮 Anomaly Resolution Rulebook
                                </h3>

                                <article class="turn">

                                    <h4>
                                        Turn 1 – Temporal Trio
                                    </h4>

                                    <ol>
                                        <li>
                                            <strong>Required Cards:</strong>
                                            One Past (2–4), one Present (5–7),
                                            and one Future (8–10).
                                        </li>

                                        <li>
                                            <strong>Wildcards:</strong>
                                            Q♥ and Q♦ may substitute for any card.
                                        </li>

                                        <li>
                                            <strong>Invalid Plays:</strong>
                                            Wrong cards discarded;
                                            Jacks/non-expert Queens not valid.
                                        </li>

                                        <li>
                                            <strong>Round End:</strong>
                                            Anomaly resolves when all three
                                            required cards are played.
                                        </li>
                                    </ol>

                                    <div class="examples">
                                        <strong>Examples:</strong>

                                        <ul>
                                            <li>
                                                ✅ 2♣ → 6♦ → 9♠
                                            </li>

                                            <li>
                                                ✅ Q♥(as3) → 7♣ → 10♦
                                            </li>

                                            <li>
                                                ❌ 2♣ → 3♦ → 4♠ (all Past)
                                            </li>
                                        </ul>
                                    </div>

                                    <p class="quickref">
                                        Quick Reference:
                                        1 Past, 1 Present, 1 Future.
                                        Q♥/Q♦ may substitute.
                                    </p>

                                </article>

                                <article class="turn">

                                    <h4>
                                        Turn 2 – Parallel Pairs
                                    </h4>

                                    <ol>
                                        <li>
                                            <strong>Required Cards:</strong>
                                            Two pairs of matching values from
                                            different temporal groups.
                                        </li>

                                        <li>
                                            <strong>Wildcards:</strong>
                                            Q♥/Q♦ may replace one card in a pair.
                                        </li>

                                        <li>
                                            <strong>Invalid Plays:</strong>
                                            Same-group pairs invalid;
                                            Jacks/non-expert Queens not allowed.
                                        </li>

                                        <li>
                                            <strong>Round End:</strong>
                                            Resolves after both pairs are played.
                                        </li>
                                    </ol>

                                    <div class="examples">
                                        <strong>Examples:</strong>

                                        <ul>
                                            <li>
                                                ✅ 3♣ + 3♦ & 6♠ + 6♥
                                            </li>

                                            <li>
                                                ❌ 2♣ + 2♥ (same group)
                                            </li>
                                        </ul>
                                    </div>

                                    <p class="quickref">
                                        Quick Reference:
                                        2 pairs, different groups.
                                        Q♥/Q♦ may substitute.
                                    </p>

                                </article>

                                <article class="turn">

                                    <h4>
                                        Turn 3 – Resource Recycle
                                    </h4>

                                    <ol>
                                        <li>
                                            <strong>Discard Draw:</strong>
                                            Draw one from discard;
                                            its suit sets the requirement.
                                        </li>

                                        <li>
                                            <strong>Required Cards:</strong>
                                            Play 3 cards of that same suit.
                                        </li>

                                        <li>
                                            <strong>Wildcards:</strong>
                                            Q♥/Q♦ may substitute if matching suit.
                                        </li>

                                        <li>
                                            <strong>Invalid Plays:</strong>
                                            Off-suit discarded;
                                            Jacks/non-expert Queens invalid.
                                        </li>
                                    </ol>

                                    <div class="examples">
                                        <strong>Examples:</strong>

                                        <ul>
                                            <li>
                                                ✅ 4♦ → 6♦ → 8♦
                                            </li>

                                            <li>
                                                ❌ 3♦ → 5♣ → 6♦ (off-suit)
                                            </li>
                                        </ul>
                                    </div>

                                    <p class="quickref">
                                        Quick Reference:
                                        Draw 1 → play 3 of same suit.
                                        Q♥/Q♦ may substitute.
                                    </p>

                                </article>

                                <article class="turn">

                                    <h4>
                                        Turn 4 – Sequence Slip
                                    </h4>

                                    <ol>
                                        <li>
                                            <strong>Required Cards:</strong>
                                            3 numeric (2–10) in descending order,
                                            all different suits.
                                        </li>

                                        <li>
                                            <strong>Wildcards:</strong>
                                            Q♥/Q♦ may substitute any numeric rank.
                                        </li>

                                        <li>
                                            <strong>Invalid Plays:</strong>
                                            Repeated suits or gaps break sequence.
                                        </li>
                                    </ol>

                                    <div class="examples">
                                        <strong>Examples:</strong>

                                        <ul>
                                            <li>
                                                ✅ 6♥ → 5♠ → 4♦
                                            </li>

                                            <li>
                                                ❌ 7♣ → 6♣ → 5♦ (repeated suit)
                                            </li>
                                        </ul>
                                    </div>

                                    <p class="quickref">
                                        Quick Reference:
                                        3 descending, all different suits.
                                    </p>

                                </article>

                                <article class="turn">

                                    <h4>
                                        Turn 5 – Chrono Chain
                                    </h4>

                                    <ol>
                                        <li>
                                            <strong>First Card:</strong>
                                            Start with a key card or Q♥/Q♦
                                            (acts as third).
                                        </li>

                                        <li>
                                            <strong>Second Card:</strong>
                                            +1 or –1 relative to the first.
                                        </li>

                                        <li>
                                            <strong>Third Card:</strong>
                                            Continue in same direction.
                                        </li>

                                        <li>
                                            <strong>Wildcards:</strong>
                                            Q♥/Q♦ may substitute anywhere.
                                        </li>
                                    </ol>

                                    <div class="examples">
                                        <strong>Examples:</strong>

                                        <ul>
                                            <li>
                                                ✅ 8♠ → 9♥ → 10♦
                                            </li>

                                            <li>
                                                ❌ 7♣ → 9♠ → 10♦ (gap)
                                            </li>
                                        </ul>
                                    </div>

                                    <p class="quickref">
                                        Quick Reference:
                                        Start with key/Q♥/Q♦ →
                                        play 3 in ±1 sequence.
                                    </p>

                                </article>

                                <article class="turn">

                                    <h4>
                                        Turn 6 – Four of a Suit
                                    </h4>

                                    <ol>
                                        <li>
                                            <strong>Required Cards:</strong>
                                            4 of the same suit (2–10).
                                        </li>

                                        <li>
                                            <strong>Wildcards:</strong>
                                            Q♥/Q♦ may substitute but must match suit.
                                        </li>

                                        <li>
                                            <strong>Invalid Plays:</strong>
                                            Mixed suits or Jacks/non-expert
                                            Queens invalid.
                                        </li>
                                    </ol>

                                    <div class="examples">
                                        <strong>Examples:</strong>

                                        <ul>
                                            <li>
                                                ✅ 2♠ → 4♠ → 6♠ → 10♠
                                            </li>

                                            <li>
                                                ❌ 4♦ → 6♦ → 8♦ → 9♣ (off-suit)
                                            </li>
                                        </ul>
                                    </div>

                                    <p class="quickref">
                                        Quick Reference:
                                        4 of same suit (2–10).
                                        Q♥/Q♦ may substitute.
                                    </p>

                                </article>

                                <article class="turn">

                                    <h4>
                                        Turn 7 – Future Flow
                                    </h4>

                                    <ol>
                                        <li>
                                            <strong>Required Cards:</strong>
                                            4 numeric cards (2–10) in ascending order.
                                        </li>

                                        <li>
                                            <strong>Wildcards:</strong>
                                            Only Q♥/Q♦ can substitute.
                                        </li>

                                        <li>
                                            <strong>Invalid Plays:</strong>
                                            Gaps or Jacks/non-expert Queens
                                            cancel attempt.
                                        </li>
                                    </ol>

                                    <div class="examples">
                                        <strong>Examples:</strong>

                                        <ul>
                                            <li>
                                                ✅ 5♣ → 6♦ → 7♥ → 8♠
                                            </li>

                                            <li>
                                                ❌ 6♣ → 7♦ → 9♠ → 10♥ (gap)
                                            </li>
                                        </ul>
                                    </div>

                                    <p class="quickref">
                                        Quick Reference:
                                        4 ascending (2–10).
                                        Only Q♥/Q♦ may substitute.
                                    </p>

                                </article>

                                <article class="turn">

                                    <h4>
                                        Turn 8 – Echo Effect
                                    </h4>

                                    <ol>
                                        <li>
                                            <strong>Required Cards:</strong>
                                            3 pairs of different values.
                                        </li>

                                        <li>
                                            <strong>Wildcards:</strong>
                                            Q♥/Q♦ cannot substitute in pairs.
                                        </li>

                                        <li>
                                            <strong>Invalid Plays:</strong>
                                            Duplicate-value pairs invalid;
                                            Jacks/non-expert Queens invalid.
                                        </li>
                                    </ol>

                                    <div class="examples">
                                        <strong>Examples:</strong>

                                        <ul>
                                            <li>
                                                ✅ 2♣ + 2♦ / 5♥ + 5♠ / 9♣ + 9♦
                                            </li>

                                            <li>
                                                ❌ 4♣ + 4♦ / 4♠ + 4♥ / 7♣ + 7♠
                                                (duplicate pairs)
                                            </li>
                                        </ul>
                                    </div>

                                    <p class="quickref">
                                        Quick Reference:
                                        3 pairs, different values.
                                        Q♥/Q♦ cannot substitute.
                                    </p>

                                </article>

                            </div>

                        </div>

                        <button class="slide-btn next">
                            ⟶
                        </button>

                    </div>

                    <footer class="playbook__footer">

                        <span>
                            Hands of Time © 2025
                        </span>

                        <button id="playbook_backBtn">
                            BACK
                        </button>

                    </footer>

                </div>

            </section>
        `);
    }

    setupSlider() {
        const slider =
            this.dom.querySelector(".slider");

        const slides =
            this.dom.querySelectorAll(".section");

        const nextBtn =
            this.dom.querySelector(".slide-btn.next");

        const prevBtn =
            this.dom.querySelector(".slide-btn.prev");

        this.currentSlide = 0;

        const totalSlides = slides.length;

        const updateSlide = () => {
            slider.style.transform =
                `translateX(-${this.currentSlide * 100}%)`;
        };

        nextBtn.addEventListener("click", () => {
            this.currentSlide =
                (this.currentSlide + 1) % totalSlides;

            updateSlide();
        });

        prevBtn.addEventListener("click", () => {
            this.currentSlide =
                (this.currentSlide - 1 + totalSlides) %
                totalSlides;

            updateSlide();
        });

        let startX = 0;
        let endX = 0;

        slider.addEventListener("touchstart", (event) => {
            startX = event.touches[0].clientX;
        });

        slider.addEventListener("touchmove", (event) => {
            endX = event.touches[0].clientX;
        });

        slider.addEventListener("touchend", () => {
            const diff = startX - endX;

            if (Math.abs(diff) <= 50) {
                return;
            }

            if (diff > 0) {
                this.currentSlide =
                    (this.currentSlide + 1) % totalSlides;
            } else {
                this.currentSlide =
                    (this.currentSlide - 1 + totalSlides) %
                    totalSlides;
            }

            updateSlide();
        });

        this.handleKeyDown = (event) => {
            if (event.key === "ArrowRight") {
                this.currentSlide =
                    (this.currentSlide + 1) % totalSlides;

                updateSlide();
            }

            if (event.key === "ArrowLeft") {
                this.currentSlide =
                    (this.currentSlide - 1 + totalSlides) %
                    totalSlides;

                updateSlide();
            }
        };

        document.addEventListener(
            "keydown",
            this.handleKeyDown
        );
    }

    processEvents() {
        const backBtn =
            this.dom.querySelector("#playbook_backBtn");

        backBtn.addEventListener(
            "click",
            () => {
                eventEmitter.emit("PlaybookToPause");
            }
        );

        eventEmitter.off("PlaybookToPause");

        eventEmitter.once(
            "PlaybookToPause",
            () => {
                 this.preloadScene.audio.popUpSound.play();

                this.scene.stop();
                this.scene.launch("PauseScene");
            }
        );
    }

    create() {
        const { PreloadScene } =
            this.game.scene.keys;

        this.preloadScene = PreloadScene;

        domUI.clear();

        this.injectUI();
        this.setupSlider();
        this.processEvents();
    }

    shutdown() {
        if (this.handleKeyDown) {
            document.removeEventListener(
                "keydown",
                this.handleKeyDown
            );

            this.handleKeyDown = null;
        }

        domUI.clear();
    }
}