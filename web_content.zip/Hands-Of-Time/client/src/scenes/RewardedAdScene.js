/**@type {import("../typings/phaser")} */
import { BaseScene } from "./BaseScene.js";
import { eventEmitter } from "../events/EventEmitter.js";
import domUI from "../ui/domUIManager.js";
import {applixir} from "../ApplixirSDK.js";

export class RewardedAdScene extends BaseScene {
    constructor(config) {
        super("RewardedAdScene", config);
        this.config = config;
    }

    enter() {
        domUI.clear();

        this.ui = domUI.show(`
            <div id="rewardedAdScreen" class="rewarded-ad-screen">

                <div class="rewarded-ad-content">

                    <h2>Watch an Ad</h2>

                    <p>
                        Watch a short advertisement to receive a bonus.
                    </p>

                    <div class="rewarded-ad-buttons">
                        <button
                            id="rewardedAdWatchBtn"
                            type="button"
                        >
                            WATCH AD
                        </button>

                        <button
                            id="rewardedAdCancelBtn"
                            type="button"
                        >
                            CANCEL
                        </button>
                    </div>

                </div>

            </div>
        `);

        this.rewardedAdScreen =
            this.ui.querySelector("#rewardedAdScreen");

        this.rewardedAdWatchBtn =
            this.ui.querySelector("#rewardedAdWatchBtn");

        this.rewardedAdCancelBtn =
            this.ui.querySelector("#rewardedAdCancelBtn");
    }

    create() {
        this.enter();
        this.initEvents();
        this.createLoadingOverlay();
        this.scene.pause("PlayScene");
    }

    createLoadingOverlay() {
        if (!this.rewardedAdScreen) {
            return;
        }

        this.loadingOverlay = document.createElement("div");
        this.loadingOverlay.id = "adLoadingOverlay";

        this.loadingOverlay.innerHTML = `
            <div class="loading-content">
                <div class="spinner"></div>
                <p>Retrieving Ad...</p>
            </div>
        `;

        this.rewardedAdScreen.appendChild(this.loadingOverlay);

        this.hideLoading();
    }

    showLoading() {
        if (this.loadingOverlay) {
            this.loadingOverlay.style.display = "flex";
        }
    }

    hideLoading() {
        if (this.loadingOverlay) {
            this.loadingOverlay.style.display = "none";
        }
    }

    initEvents() {
        if (!this.rewardedAdWatchBtn || !this.rewardedAdCancelBtn) {
            return;
        }

        this.rewardedAdWatchBtn.addEventListener(
            "click",
            () => {
                eventEmitter.emit("WatchAd");
            },
            { once: true }
        );

        eventEmitter.off("WatchAd");

        eventEmitter.once("WatchAd", async () => {
    this.showLoading();
    
    const adCompleted = await applixir.showRewardedAd(() => {
        this.hideLoading();
        
        // Hide the entire introductory screen during ad playback.
        if (this.rewardedAdScreen) {
            this.rewardedAdScreen.style.display = "none";
        }
    });
    
    this.hideLoading();
    
    if (adCompleted) {
        console.log(
            "Rewarded ad completed — granting player bonus."
        );
        
        const { gameplayUI, registry } =
        this.game.scene.keys.PlayScene;
        
        const currentDP =
            parseInt(gameplayUI.DPText.text) || 0;
        
        const currentSP =
            parseInt(gameplayUI.SPText.text) || 0;
        
        gameplayUI.DPText.setText(currentDP + 2);
        gameplayUI.SPText.setText(currentSP + 1);
        
        registry.set("DP", currentDP + 2);
        registry.set("SP", currentSP + 1);
        
        setTimeout(() => {
            domUI.clear();
            this.scene.stop("RewardedAdScene");
            this.scene.resume("PlayScene");
        }, 800);
    } else {
        console.log("Ad not completed or failed to load.");
        
        // Restore the introductory screen if the ad fails or is skipped.
        if (this.rewardedAdScreen) {
            this.rewardedAdScreen.style.display = "flex";
        }
    }
});

        this.rewardedAdCancelBtn.addEventListener(
            "click",
            () => {
                eventEmitter.emit("ResumePlayScene");
            },
            { once: true }
        );

        eventEmitter.off("ResumePlayScene");

        eventEmitter.once(
            "ResumePlayScene",
            () => {
                domUI.clear();
                this.scene.stop("RewardedAdScene");
                this.scene.resume("PlayScene");
            }
        );
    }

    shutdown() {
        eventEmitter.off("WatchAd");
        eventEmitter.off("ResumePlayScene");
        domUI.clear();
    }
}