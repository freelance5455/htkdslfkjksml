import { BaseScene } from "./BaseScene.js";
//command handler for card movements
import { CommandHandler } from "../CommandHandler.js";
//movements
import { DeckToHand } from "../movements/DeckToHand.js";
import { OutworldToAnomaly } from "../movements/OutworldToAnomaly.js";
import { HandToVacant } from "../movements/HandToVacant.js";
import { VisitorToHost } from "../movements/VisitorToHost.js";
import { HandToDiscard } from "../movements/HandToDiscard.js";
import { SwapWithDeck } from "../movements/SwapWithDeck.js";
import { RewardedHandToDiscard } from "../movements/RewardedHandToDiscard.js";

import { HandsOfTime } from "../HandsOfTime.js";
import { eventEmitter } from "../events/EventEmitter.js";
import { Time } from "../events/Time.js";

import { GameplayUI } from "../ui/GameplayUI.js";

//text boxes
import { RegularCardTextbox } from "../entities/textboxes/RegularCardTextbox.js";
import { AnomalyTextbox } from "../entities/textboxes/AnomalyTextbox.js";
//states
import { ResolveState, DrawState, DiscardState, SwapState, EndState} from "../states/gameplayButtons/ButtonStates.js";
import { DeckClickState } from "../states/DeckClickState.js";
//progress messages
import { ProgressMessage } from "../turns/ProgressMessage.js";
//tutorial manager
import { TutorialManager } from "../tutorials/TutorialManager.js";
import { InputLock } from "../utils/InputLock.js";


export class PlayScene extends BaseScene{
    constructor(config){
        super("PlayScene", config);
        this.config = {...config};
        this.commandHandler = new CommandHandler(this);
        this.handsOfTime = new HandsOfTime(this);
        this.textDisplayTimer = 0;
        this.textDisplayInterval = 2300;
        this.canDrawACard = false;
        this.inputLock = null;
    }
    initRegistry(){
        this.registry.set("currentTurnIndex", 0);
        
        this.registry.set("pastCardsDealt", 0);
        this.registry.set("presentCardsDealt", 0);
        this.registry.set("futureCardsDealt", 0);
        
        this.registry.set("pastPairHasSolvedAnomaly", 0);
        this.registry.set("presentPairHasSolvedAnomaly", 0);
        this.registry.set("futurePairHasSolvedAnomaly", 0);
        
        this.registry.set("pastTrioHasSolvedAnomaly", 0);
        this.registry.set("presentTrioHasSolvedAnomaly", 0);
        this.registry.set("futureTrioHasSolvedAnomaly", 0);
        
        this.registry.set("turn3_suitToMatchCount", 0);
        
        this.registry.set("turn4_cardsInfo", []);
        this.registry.set("turn4_cardCounts", 0);
        this.registry.set("turn4_nextCheckboxProgress", 0);
        
        this.registry.set("turn5_cardsInfo", []);
        this.registry.set("turn5_cardCounts", 0);
        this.registry.set("turn5_nextCheckboxProgress", 0);
        
        this.registry.set("turn6_cardsInfo", []);
        this.registry.set("turn6_cardCounts", 0);
        this.registry.set("turn6_nextCheckboxProgress", 0);
        
        this.registry.set("turn7_cardsInfo", []);
        this.registry.set("turn7_cardCounts", 0);
        this.registry.set("turn7_nextCheckboxProgress", 0);
        
        this.registry.set("turn8_allCards", [{value: 0, resolved: false}, {value: 0, resolved: false}, {value: 0, resolved: false}, {value: 0, resolved: false}, {value: 0, resolved: false}, {value: 0, resolved: false}, {value: 0, resolved: false}, {value: 0, resolved: false}, {value: 0, resolved: false}]);

    }
    
    showInterface() {
    this.initRegistry();
    
    this.backgroundImage =
    this.add.image(0, 0, "play_bg_portrait")
    .setOrigin(0)
    .setDepth(-10);
    
    this.updateBackgroundImage();
}
updateBackgroundImage() {
    const isPortrait =
        this.config.height > this.config.width;
    
    const texture =
        isPortrait ?
        "play_bg_portrait" :
        "play_bg_landscape";
    
    this.backgroundImage.setTexture(texture);
    
    this.backgroundImage.setDisplaySize(
        this.config.width,
        this.config.height
    );
}
    createCard(type, x, y){
        const card =  this.add.image(x,y,"cards").setName(type).setOrigin(0).setScale(1).setDepth(1)
        .setInteractive({draggable: true})
        return card
    }
    createPileRect(x, y, w, h){
        const rect = new Phaser.Geom.Rectangle(x, y, w, h);
        const graphics = this.add.graphics({lineStyle: {width: 1, color: "0xffffff"}});
        graphics.clear();
        graphics.strokeRectShape(rect).setDepth(0);
        return rect;
    }
    
    createDropZone(zoneType, x, y, w, h){
        const zone = this.add.zone(x, y, w, h).setRectangleDropZone(w, h)
        .setName(zoneType).setOrigin(0);
        if(this.config.debug){
            this.add.rectangle(x, y, w, h, 0x09144ff, 0.0).setDepth(0).setOrigin(0);
        }
        return zone;
    }
    
    handleDragEvent(){
        const { hand } = this.gameplayUI;
        this.input.on("dragstart", (pointer, gameobject, dragX, dragY)=>{
            let card = gameobject&& gameobject.type === "Image" ? gameobject : null;
            if(!card) return;
            let zoneType = card.getData("zone");
            switch(zoneType){
                case "hand":{
                    //hide box when dragging
                    this.regularCardTextbox.infoDisplayTimer = this.regularCardTextbox.infoDisplayInterval;
                    break;
                }
            } 
        }) 
        this.input.on("drag", (pointer, gameobject, dragX, dragY)=>{
            let card = gameobject&& gameobject.type === "Image" ? gameobject : null;
            if(!card) return;
            let zoneType = card.getData("zone");
            switch(zoneType){
                case "hand":{
                    card.setPosition(dragX, dragY);
                    //hide box when dragging
                    this.regularCardTextbox.infoDisplayTimer = this.regularCardTextbox.infoDisplayInterval;
                    break;
                }
            } 
        });
        this.input.on("dragend", (pointer, gameobject, dropped)=>{
           //for invalid moves, snap back to original location
           let card = gameobject&& gameobject.type === "Image" ? gameobject : null;
           if(!card) return; 
           let zoneType = card.getData("zone"); 
           const sourcePileIndex = card.getData("index");
           const sourceContainer = hand.containers[sourcePileIndex]; 
           
           switch(zoneType){
               case "hand":{
                   //rough movement
                   //if(!dropped) hand.handleMoveCardToWrongSpace(gameobject);
                   //smooth movement
                   if(!dropped){
                       const command = new HandToVacant(this, sourceContainer, sourceContainer);
                       this.commandHandler.execute(command);  
                   }
                     
               break;
               }
               default:{ break; }
           }
        })
        return this;
    }
    
    handleDropEvent(){
        const { hand } = this.gameplayUI;
        this.input.on("drop", (pointer, gameobject, dropZone)=>{
            switch(dropZone.name){
                //FOUNDATION DROP ZONE
                case "HandZone":{
                    const card = gameobject;
                    const sourcePileIndex = card.getData("index");
                    const targetPileIndex = dropZone.getData("index");
                    const sourceContainer = hand.containers[sourcePileIndex];
                    const targetContainer = hand.containers[targetPileIndex];
                    
                    //snap card back to (0,0) if dropped on same pile
                    if(sourcePileIndex===targetPileIndex){
                        //rough movement
                         //card.setPosition(0,0);
                        //smooth movement
                        const command = new HandToVacant(this, sourceContainer, sourceContainer);
                        this.commandHandler.execute(command); 
                    }
                    else{
                        //if target container is vacant , move
                        if(!targetContainer.length){
                            const command = new HandToVacant(this, sourceContainer, targetContainer);
                            this.commandHandler.execute(command); 
                        }
                        //if target container is occupied, swap
                        else{
                            const command = new VisitorToHost(this, sourceContainer, targetContainer);
                            this.commandHandler.execute(command); 
                        }
                    }
                break;
                }
                default:{
                    hand.handleMoveCardToWrongSpace(gameobject);
                }
            }
        })
        return this;
    }
    
    resolveAnomaly(){
        this.gameplayUI.resolveBtn.hitArea.on('pointerdown', ()=>{
            this.resolving = false;
            if(this.resolving) return;
            this.playButtonClick();
            //enter resolve button state
            if(!this.resolveState){ this.resolveState = new ResolveState(this); }
            this.resolveState.enter();

            this.gameplayUI.hand.containers.forEach((container, i)=>{
                if(container.length){
                    container.list.forEach(card=>{
                        card.removeAllListeners("pointerdown");
                        card.on("pointerdown", ()=>{
                            if(!this.gameplayUI.resolveBtn.active) return; 
                            const command = new HandToDiscard(this, container);
                            this.commandHandler.execute(command);
                        })
                    })
                }
            })
            this.resolving = true;
        })
    }
    deal(){
        let isCooldown = false;
        this.gameplayUI.drawBtn.hitArea.on('pointerdown', ()=>{
             if(isCooldown) return;
             this.playButtonClick();
            //enter recall button state
            if(!this.dealing) { this.drawState = new DrawState(this) }
            this.drawState.enter();
 
            this.drawACardFromDeck()
                .then(value=>{ return this.reduceDP() })
                .then(value=> {
                    isCooldown = true;
                    setTimeout(()=> isCooldown = false, 500);
                    this.displayRewardedAdScene();
                })
            
        })
    }
    swapWithDeck(){
        this.gameplayUI.swapBtn.hitArea.on('pointerdown', ()=>{
            this.swapping = false;
            if(this.swapping) return;
            this.playButtonClick();
            //enter swap button state
            if(!this.swapState) { this.swapState = new SwapState(this) }
            this.swapState.enter();
            const {hand} = this.gameplayUI;
            hand.containers.forEach((container, i)=>{
                if(container.length){
                    container.list.forEach(card=>{
                        card.removeAllListeners("pointerdown");
                        card.on("pointerdown", ()=>{
                            const { SPText } = this.gameplayUI;
                            if(parseInt(SPText.text) > 0){
                                SPText.text = parseInt(SPText.text) - 1;
                                if(!this.gameplayUI.swapBtn.active) return; 
                                const command = new SwapWithDeck(this, container);
                                this.commandHandler.execute(command);
                                //display ad
                                this.displayRewardedAdScene();
                            }
                            else{
                                return;
                            }

                        })
                    })
                }
            })
            this.swapping = true;
        })
    }
   
    discardAHand(){
        this.gameplayUI.discardBtn.hitArea.on('pointerdown', ()=>{
            this.discarding = false;
            if(this.discarding) return;
            this.playButtonClick();
            //enter diacard button state
            if(!this.discardState) { this.discardState = new DiscardState(this) }
            this.discardState.enter();
            
            this.gameplayUI.hand.containers.forEach((container, i)=>{
                if(container.length){
                    container.list.forEach(card=>{
                        card.removeAllListeners("pointerdown");
                        card.on("pointerdown", ()=>{
                            if(!this.gameplayUI.discardBtn.active) return; 
                            const command = new RewardedHandToDiscard(this, container);
                            this.commandHandler.execute(command);
                        })
                    })
                }
            }) 
            this.discarding = true;
        })
    }
    endTurn(){
        this.gameplayUI.endBtn.hitArea.on('pointerdown', ()=>{
            this.ending = false;
            if(this.ending) return;
            this.playButtonClick();
            //enter resolve button state
            if(!this.endState) { this.endState = new EndState(this) }
            this.endState.enter();
            //play turn completed sound
           // this.preloadScene.audio.playerWinSound.play();
            //pause current scene, enter turn ended scene
            if(!this.scene.isPaused("PlayScene")){
                this.scene.pause();
                this.scene.launch("TurnEndedScene")
            }
            
            this.ending = true;
        })
    }
    
    handleClickEvent(){
        //hand card clicked
        const { hand } = this.gameplayUI;
        //enter states for each of the five buttons
        //Resolve, Recall, Discard, Swap and End
        this.resolveAnomaly();
        this.deal();
        this.discardAHand();
        this.swapWithDeck();
        this.endTurn();
        //turn ended message buttons (back and next)
        this.input.on("pointerdown", (pointer, gameobject)=>{
            //console.clear();
            if(!gameobject[0]) return;
            //I'm tapping on a card image
            if(gameobject[0].type === "Image"){
                
                const zoneType = gameobject[0].getData("zone");
                const card = gameobject[0];
                switch(zoneType){
                        //drag event is very sensitive, it triggers at the slightest drag on the card
                        //to prevent textbox from disappearing immediately after pointerdown event,
                        //only display it after 50 milliseconds
                        //if drag function needs to kick in, it will have done so before 50 ms 
                    case "hand":{
                        //display if none of the gameplay buttons is in active state
                        let numberOfActiveButtons = 0;
                        this.gameplayUI.gameplayButtons.forEach(btn=>{
                            if(btn.active) numberOfActiveButtons++;
                        })
                        if(numberOfActiveButtons === 0)
                            setTimeout(()=>{ this.regularCardTextbox.show(card) }, 50) 
                    break;
                    }
                    case "anomaly":{
                        setTimeout(()=>{ 
                            this.anomalyTextbox.show(card);
                            this.anomalyTextbox.bringToTop(card.depth+1);
       
                        }, 50)
                    break;
                    }
                    case "portal":{
                        
                    break;
                    }
                    
                    case "deck":{
                    break;
                    }
                    case "discard":{
                      //  alert("discard")
                    break;
                    }
                    default:{ break; }
                }
            }
            else{ /*console.log("you're clicking on a " + gameobject[0].type + " gameobject")*/}
        })
        return this;
        
    }
    //STEPS involved in drawing card from deck
    //step 1: pick a card
    drawACardFromDeck(){
        const { DPText, hand } = this.gameplayUI;
        
        return new Promise((resolve, reject) => {
            const newPoints = parseInt(DPText.text);
            let targetContainer;
            
            for(let i = 0; i < hand.containers.length; ++i){
                const container = hand.containers[i];
                if(!container.length){
                    targetContainer = hand.containers[i];
                    break;
                }
            }
            if(!targetContainer && newPoints < 1) return null;
            else if(newPoints < 1) return null;
            else if(!targetContainer) return null;
            else{
                const command = new DeckToHand(this, 1);
                this.commandHandler.execute(command);
                resolve();
            }
        })
      
    }
    //step 2: reduce draw points by 1
    reduceDP(){
        const { DPText, DPRect, hand} = this.gameplayUI;
       
        //if there's no vacant container to deal into, return early
        //if there are no draw points available to player, return early
            //console.log(targetContainer, newPoints)
        return new Promise((resolve, reject)=>{
            
            setTimeout(()=>{
                let newPoints = parseInt(DPText.text) - 1;
                if(newPoints < 0){
                    reject("0 DP");
                }
                else{
                    DPText.setText(newPoints);
                    //DPText.setPosition(DPRect.centerX - DPText.displayWidth/2, DPRect.bottom - DPText.height - 10)
                    resolve();
                }
            }, 30)
        })
    }

    processEvents(){
        const { GameCompleteScene, PauseScene, TutorialScene } = this.game.scene.keys;
        //flags
        TutorialScene.tutorialMode = false;
        PauseScene.gamePaused = false;
        //TO PAUSE SCENE
        eventEmitter.on("PlayToPause", () => {
    
    
    this.lastAction = "";
    this.textDisplayTimer = this.textDisplayInterval;
    
    if (PauseScene.gamePaused) return;
    
    if (!this.scene.isPaused("PlayScene")) {
        
        
        this.scene.pause();
        this.scene.launch("PauseScene");
    }
    
    PauseScene.gamePaused = true;
});
        //TO TUTORIAL SCENE
        eventEmitter.on("PlayToTutorial", ()=>{
            //flags to avoid multiple event calling
            if(!TutorialScene.tutorialMode){
                this.scene.pause();
               // this.preloadScene.audio.popUpSound.play();
                this.scene.launch("TutorialScene");
                TutorialScene.tutorialMode = true;
            }
        }) 
        eventEmitter.on("GameComplete", ()=>{
            //PAUSE GAME
            if(!this.scene.isPaused("PlayScene")) this.scene.pause();
            this.scene.launch("GameCompleteScene");
            //this.preloadScene.audio.popUpSound.play();
            //this.preloadScene.audio.playSong.stop();
            GameCompleteScene.gamePaused = true;
        });
        eventEmitter.on("ToggleClockTick", ()=>{
            this.watch.canPlayTickSound = !this.watch.canPlayTickSound;
        });
    }
    //old school array shufling method 
    shuffle(array){
        let tempDeck = [];
        while(array.length){
            const randomPos = Math.floor(Math.random() * array.length);
            const randomCard = (array.splice(randomPos, 1))[0];
            tempDeck.push(randomCard);
        }
        array = tempDeck;
        tempDeck = [];
        return array;
    }
    getCardDimensions(){
        let card = this.createCard("null", 0,0);
        const originalWidth = card.displayWidth;
        const originalHeight = card.displayHeight;
        card.destroy();
        card = null;
        return {originalWidth, originalHeight}
    } 
    //STEPS in beginning first round
    //step 2nd to last
    showNewTurnMessage(){
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                this.gameplayUI.createNewTurnMessage(1);
                resolve();
            }, 100)
        })
    }
    //step last
    hideNewTurnMessage(){
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                this.gameplayUI.hideMessage();
                resolve();
            }, 1500)
        })
    } 
    //step 2
    sendAnomalyCardFromOutworld(){
        return new Promise((resolve, reject)=>{
            setTimeout(() => {
                const command = new OutworldToAnomaly(this);
                this.commandHandler.execute(command);
                resolve()
            }, 100)
        })
    }
    //step 3
    //addProgressMessage
    addProgressMessage(){
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                this.progressMessage = new ProgressMessage(this);
                resolve();
            }, 100)
        })
    }
    //step 4
    //send 5 cards to hand
    addTutorial(){
        return new Promise((resolve, reject) => {
            setTimeout(()=>{
                if(!localStorage.getItem("tutorialComplete") ){
                    this.tutorial = new TutorialManager(this);
                    this.tutorial.once("tutorialComplete", ()=> {
                        this.tutorial.inputLock.enableAll();
                        localStorage.setItem("tutorialComplete", true);
                        
                    });
                }
                resolve()
            }, 1600)
        })
    }
    //step 5
    //enable input lock on all previously disabled objects
    removeInputLock(){
        return new Promise((resolve, reject) => {
            //unlock buttons
            this.gameplayUI.gameplayButtons.forEach(btn=>{
                this.inputLock.enableAll();
            })
            setTimeout(()=> resolve(), 100);
        })
    }
    sendCardsToHand(){
        return new Promise((resolve, reject) => {
            setTimeout(()=>{
                const command = new DeckToHand(this, 8);
                this.commandHandler.execute(command);
                resolve();
            }, 100)
        })
    }
    
    removeJackFrom(container, discardableContainerIndexArra){
        container.list[0].setData("forcedToDiscard", true);
        const command = new HandToDiscard(this, container);
        this.commandHandler.execute(command);
        setTimeout(()=> discardableContainerIndexArra.shift(), 1000 );
    }
        
    async forceDiscard() {
        const containers = this.gameplayUI.hand.containers;
        let noviceJackContainers = [];
        let expertJackContainers = [];
    
        // Collect jacks
        for (let i = 0; i < containers.length; ++i) {
            const container = containers[i];
            if (container.length) {
                container.list.forEach(card => {
                    if (card.getData("value") === 11) {
                        const suit = card.getData("suit").toUpperCase().trim();
                        switch (suit) {
                            case "CLUB": case "SPADE":
                                noviceJackContainers.push(i);
                                break;
                            case "HEART": case "DIAMOND":
                                expertJackContainers.push(i);
                                break;
                        }
                    }
                });
            }
        }
        // Always lose resources
        noviceJackContainers.forEach(() => {
            this.loseResources();
            this.loseDPReward();
            this.loseSPReward();
        });
        expertJackContainers.forEach(() => {
            this.stealARandomCard();
            this.loseDPReward();
            this.loseSPReward();
        });
    
        // Helper to sequentially remove jacks with delay
        const removeSequentially = async (indices) => {
            while (indices.length > 0) {
                this.removeJackFrom(containers[indices[0]], indices);
                await new Promise(r => setTimeout(r, 1010));
            }
        };
    
        // Run them in order
        await removeSequentially(noviceJackContainers);
        await removeSequentially(expertJackContainers);
    
        // Done
        return Promise.resolve();
    }
    
    stealARandomCard(){
        //get random (non-jack) card
        //if unavailable, remove 2 DP and 2 RP
        const containers = this.gameplayUI.hand.containers;
        let qualifiedContainers = [];
        let expertJackContainers = [];
    
        // Collect jacks
        for (let i = 0; i < containers.length; ++i) {
            const container = containers[i];
            if (container.length) {
                container.list.forEach(card => {
                    if (card.getData("value") !== 11) {
                        qualifiedContainers.push(container);
                    }
                });
            }
        }
        if(qualifiedContainers.length > 0){
            return new Promise((resolve, reject) => {
                
                const randomContainer = qualifiedContainers[ Math.floor(Math.random()* qualifiedContainers.length) ];
                randomContainer.list[0].setData("forcedToDiscard", true);
                const command = new HandToDiscard(this, randomContainer);
                //remove a valid card such that it trails the Thief (hence, cause for 200 ms delay)
                setTimeout(()=> this.commandHandler.execute(command), 200)
                setTimeout(()=> resolve(), 1200);
            })
        }
        else{
            this.loseDPReward();
            this.loseSPReward();
        }
    }
    
    loseResources(){
        return new Promise((resolve, reject)=>{
            const { RPText, RPRect} = this.gameplayUI;
            const totalPoints = parseInt(RPText.text) - 8;
            
            RPText.setText(totalPoints);
            //RPText.setPosition(RPRect.centerX - RPText.displayWidth/2, RPRect.bottom - RPText.height - 10);
                setTimeout(()=>{ resolve() }, 300)
        })
    }
    
    loseDPReward(){
        return new Promise((resolve, reject)=>{
            const { DPText, DPRect} = this.gameplayUI;
            const newPoints = parseInt(DPText.text) - 2;
            DPText.setText(newPoints);
            this.displayRewardedAdScene();
            //DPText.setPosition(DPRect.centerX - DPText.displayWidth/2, DPRect.bottom - DPText.height - 10);
                setTimeout(()=>{ resolve() }, 300)
        })
    }
    
    loseSPReward(){
        const { SPText, SPRect} = this.gameplayUI;
 
        const totalPoints = parseInt(SPText.text) - (2);
        return new Promise((resolve, reject)=>{
            SPText.setText(totalPoints);
            this.displayRewardedAdScene();
            //SPText.setPosition(SPRect.centerX - SPText.displayWidth/2, SPRect.bottom - SPText.height - 10);
                setTimeout(()=>{ resolve() }, 300)
        })
    } 
    openScroll(){
        return new Promise((resolve, reject) => {
            this.gameplayUI.anomalyPile.scroll.tweenOpen();
            setTimeout(()=>{ resolve() }, 500)
        })
    }
    async beginFirstRound(){
        await this.sendAnomalyCardFromOutworld();
        await this.openScroll();
        await this.addProgressMessage();
        await this.sendCardsToHand();
        await this.addTutorial();
        await this.removeInputLock();
        await this.forceDiscard();
        await this.showNewTurnMessage();
        await this.hideNewTurnMessage();
        await this.pauseGame();

    }
    
    pauseGame(){
        const {PauseScene } = this.game.scene.keys;
        PauseScene.gamePaused = false;
        return new Promise((resolve, reject) => {
            this.gameplayUI.pauseButton.on("pointerdown", () => {
    
    if (!PauseScene.gamePaused) {
        
        this.scene.pause();
    }
    
    this.scene.launch("PauseScene");
    
    PauseScene.gamePaused = true;
});
            setTimeout(()=> resolve(), 10);
        })

    }

    displayRewardedAdScene(){
        const {DPText, SPText } = this.gameplayUI;
        if(parseInt(DPText.text) <= 0 && parseInt(SPText.text)<= 0){
            setTimeout(()=>{
                if(!this.registry.get("EnterRewardedAdScene")){
                    this.scene.pause();
                    this.scene.launch("RewardedAdScene");
                }
            }, 300)
        }
    }

    create() {
        
    const { PreloadScene } = this.game.scene.keys;
    
    this.preloadScene = PreloadScene;
    
    this.setGameSize();
    
    this.showInterface();
    
    this.graphics = this.add.graphics({
        lineStyle: {
            width: 1,
            color: 0xffffff
        }
    });
    
    this.gameplayUI = new GameplayUI(this);
    
    this.inputLock = new InputLock(this);
    
    this.gameplayUI.gameplayButtons.forEach(btn => {
        this.inputLock.disableOne(btn.hitArea);
    });
    
    this.watch = new Time(this);
    
    this.handsOfTime.newGame();
    
    this.beginFirstRound();
    
    this.handleClickEvent()
        .handleDragEvent()
        .handleDropEvent();
    
    this.regularCardTextbox =
        new RegularCardTextbox(this);
    
    this.anomalyTextbox =
        new AnomalyTextbox(this);
    
    this.scale.on(
        Phaser.Scale.Events.ORIENTATION_CHANGE,
        this.handleOrientationChange,
        this
    );
}
setGameSize() {
    const w = window.innerWidth * 2;
    const h = window.innerHeight * 2;

    this.config.width = w;
    this.config.height = h;

    this.scale.setGameSize(w, h);
}

handleOrientationChange() {
    this.setGameSize();

    if (this.gameplayUI) {
        this.time.delayedCall(0, () => {
            this.gameplayUI.updateLayout();

            if (this.backgroundImage) this.updateBackgroundImage();

            const nextAnomalyScene =
                this.scene.get("NextAnomalyScene");

            if (
                nextAnomalyScene &&
                nextAnomalyScene.scene.isActive()
            ) {
                return;
            }

            const resolvedPortalScene =
                this.scene.get("ResolvedPortalScene");

            if (
    resolvedPortalScene &&
    resolvedPortalScene.scene.isActive() &&
    resolvedPortalScene.closedPortals &&
    !resolvedPortalScene.resolving
) {
    resolvedPortalScene.closedPortals.resize();
}

            const unresolvedPortalScene =
                this.scene.get("UnresolvedPortalScene");

            if (
                unresolvedPortalScene &&
                unresolvedPortalScene.scene.isActive() &&
                unresolvedPortalScene.closedPortals  &&
                !unresolvedPortalScene.resolving 
            ) {
                unresolvedPortalScene.closedPortals.resize();
            }
        });
    }
}

shutdown() {
    this.scale.off(
        Phaser.Scale.Events.ORIENTATION_CHANGE,
        this.handleOrientationChange,
        this
    );
}
createPileRect(x, y, w, h) {
    const rect =
        new Phaser.Geom.Rectangle(
            x,
            y,
            w,
            h
        );
    
    const graphics =
        this.add.graphics({
            lineStyle: {
                width: 1,
                color: 0xffffff
            }
        });
    
    graphics.clear();
    
    graphics
        .strokeRectShape(rect)
        .setDepth(0);
    
    rect.graphics = graphics;
    
    return rect;
}
playButtonClick() {
    this.preloadScene.audio.play(
        this.preloadScene.audio.buttonClickSound
    );
}
    
    update(time, delta){
        this.regularCardTextbox.displayCardInfo(delta);
        this.anomalyTextbox.displayCardInfo(delta);
        this.gameplayUI.update(time, delta);
    }
}