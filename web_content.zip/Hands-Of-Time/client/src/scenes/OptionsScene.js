import { BaseScene } from "./BaseScene.js";
import { eventEmitter } from "../events/EventEmitter.js";
import domUI from "../ui/domUIManager.js";

export class OptionsScene extends BaseScene {
    constructor(config) {
        super("OptionsScene", config);
        
        this.config = config;
    }
    
    injectUI() {
        this.dom = domUI.show(`
            <section id="ht-options-root">

                <div id="ht-options-panel">

                    <div id="ht-options-header">
                        <h2>OPTIONS</h2>
                    </div>

                    <div id="ht-options-controls">

                        <div class="ht-options-control">
                            <label for="ht-options-sfx">
                                SOUND EFFECTS
                            </label>

                            <input
                                id="ht-options-sfx"
                                type="range"
                                min="0"
                                max="10"
                                value="10"
                            >
                        </div>

                        <div class="ht-options-control">
                            <label for="ht-options-music">
                                MUSIC
                            </label>

                            <input
                                id="ht-options-music"
                                type="range"
                                min="0"
                                max="10"
                                value="10"
                            >
                        </div>

                    </div>

                    <!-- LEGAL LINKS -->

                    <nav
                        id="ht-options-legal"
                        aria-label="Legal information"
                    >
                        <a
                            id="ht-options-privacy"
                            href="/privacy-policy.html"
                            target="_blank"
                            rel="noopener noreferrer"
                        >
                            PRIVACY POLICY
                        </a>

                        <span aria-hidden="true">|</span>

                        <a
                            id="ht-options-terms"
                            href="/terms-and-conditions.html"
                            target="_blank"
                            rel="noopener noreferrer"
                        >
                            TERMS &amp; CONDITIONS
                        </a>
                    </nav>

                    <div id="ht-options-buttons">

                        <button id="ht-options-menu-btn">
                            MENU
                        </button>

                    </div>

                </div>

            </section>
        `);
        
        this.sfxController =
            this.dom.querySelector("#ht-options-sfx");
        
        this.musicController =
            this.dom.querySelector("#ht-options-music");
        
        this.menuBtn =
            this.dom.querySelector("#ht-options-menu-btn");
        
        this.privacyLink =
            this.dom.querySelector("#ht-options-privacy");
        
        this.termsLink =
            this.dom.querySelector("#ht-options-terms");
    }
    
    create() {
        const { PreloadScene } =
        this.game.scene.keys;
        
        this.preloadScene = PreloadScene;
        
        domUI.clear();
        
        this.injectUI();
        
        this.initEvents();
    }
    
    initEvents() {
        const audioManager = this.preloadScene.audio;
        
        this.sfxController.addEventListener(
            "input",
            () => {
                const volume =
                    this.sfxController.value * 0.1;
                
                audioManager.sounds.forEach(sound => {
                    sound.volume = volume;
                });
            }
        );
        
        this.musicController.addEventListener(
            "input",
            () => {
                const volume =
                    this.musicController.value * 0.1;
                
                audioManager.songs.forEach(song => {
                    song.volume = volume;
                });
            }
        );
        
        // Legal links
        
        this.privacyLink.addEventListener(
            "click",
            () => {
                audioManager.play(
                    audioManager.buttonClickSound
                );
            }
        );
        
        this.termsLink.addEventListener(
            "click",
            () => {
                audioManager.play(
                    audioManager.buttonClickSound
                );
            }
        );
        
        // Return to Menu
        
        this.menuBtn.addEventListener(
            "click",
            () => {
                audioManager.play(
                    audioManager.buttonClickSound
                );
                
                eventEmitter.emit("OptionsToMenu");
            }
        );
        
        eventEmitter.once(
            "OptionsToMenu",
            () => {
                this.shutdown();
                this.scene.start("MenuScene");
            }
        );
    }
    
    shutdown() {
        domUI.clear();
    }
}