import { BaseScene } from "./BaseScene.js";
import { eventEmitter } from "../events/EventEmitter.js";
import domUI from "../ui/domUIManager.js";
import NotificationModal from "../ui/NotificationModal.js";

export class MenuScene extends BaseScene {
    constructor(config) {
        super("MenuScene", config);

        this.config = config;
        this.clicked = true;
        this.root = null;
    }

    create() {
        this.showInterface();
        this.registerEvents();
    }

    showInterface() {
        domUI.clear();

        this.injectUI();
        this.attachHandlers();
    }

    injectUI() {
        this.root = domUI.show(`
            <section
                id="ht-menu-root"
                class="ht-menu-screen"
            >
                <div class="ht-menu-content">

                    <div class="ht-menu-buttons">

                        <button
                            id="ht-menu-play-btn"
                            class="ht-menu-btn"
                        >
                            PLAY
                        </button>

                        <button
                            id="ht-menu-continue-btn"
                            class="ht-menu-btn"
                        >
                            CONTINUE
                        </button>

                        <button
                            id="ht-menu-options-btn"
                            class="ht-menu-btn"
                        >
                            OPTIONS
                        </button>

                        <button
                            id="ht-menu-leaderboard-btn"
                            class="ht-menu-btn"
                        >
                            LEADERBOARD
                        </button>

                        <button
                            id="ht-menu-credits-btn"
                            class="ht-menu-btn"
                        >
                            CREDITS
                        </button>

                        <button
                            id="ht-menu-exit-btn"
                            class="ht-menu-btn"
                        >
                            EXIT
                        </button>

                    </div>

                </div>
            </section>
        `);
    }

    attachHandlers() {
    const buttons = [
        ["#ht-menu-play-btn", "MenuToPlay"],
        ["#ht-menu-continue-btn", "MenuToContinue"],
        ["#ht-menu-options-btn", "MenuToOptions"],
        ["#ht-menu-credits-btn", "MenuToCredits"],
        ["#ht-menu-exit-btn", "MenuToExit"]
    ];
    
    this.buttonHandlers = [];
    
    const audioManager =
        this.game.scene.keys.PreloadScene?.audio;
    
    buttons.forEach(([selector, eventName]) => {
        const button = this.root.querySelector(selector);
        
        if (!button) {
            return;
        }
        
        const handler = () => {
            audioManager?.play(
                audioManager.buttonClickSound
            );
            
            eventEmitter.emit(eventName);
        };
        
        button.addEventListener("click", handler);
        
        this.buttonHandlers.push({
            button,
            handler
        });
    });
}

    registerEvents() {
        const { PreloadScene } =
            this.game.scene.keys;

        eventEmitter.off("MenuToPlay");
        eventEmitter.once("MenuToPlay", () => {
            if (this.registry.get("gamePaused")) {
                NotificationModal.open({
                    title: "RESTART GAME?",
                    message:
                        "You have a saved game. Restart?",
                    type: "warning",
                    showCancel: true,
                    confirmText: "Restart",
                    cancelText: "Cancel",
                    onConfirm: () => {
                        domUI.clear();
                        this.scene.start("PlayScene");
                    }
                });
            } else {
                domUI.clear();
                this.scene.start("PlayScene");
            }
        });

        eventEmitter.off("MenuToContinue");
        eventEmitter.once("MenuToContinue", () => {
            if (this.registry.get("gamePaused")) {
                domUI.clear();

                this.scene.stop();
                this.scene.resume("PlayScene");

                if (
                    PreloadScene.audio.menuSong.isPlaying
                ) {
                    PreloadScene.audio.menuSong.stop();
                }
            } else {
                domUI.clear();
                this.scene.start("PlayScene");
            }
        });

        eventEmitter.off("MenuToOptions");
        eventEmitter.once("MenuToOptions", () => {
            domUI.clear();
            this.scene.start("OptionsScene");
        });

        eventEmitter.off("MenuToCredits");
        eventEmitter.once("MenuToCredits", () => {
            domUI.clear();
            this.scene.start("CreditsScene");
        });

        eventEmitter.off("MenuToExit");
        eventEmitter.once("MenuToExit", () => {
            NotificationModal.open({
                title: "QUIT GAME?",
                message:
                    "Are you sure you want to quit?",
                type: "warning",
                showCancel: true,
                confirmText: "Quit",
                cancelText: "Cancel",
                onConfirm: () => {
                    window.close();
                }
            });
        });
    }

    shutdown() {
    if (this.buttonHandlers) {
        this.buttonHandlers.forEach(({ button, handler }) => {
            button.removeEventListener("click", handler);
        });
        
        this.buttonHandlers = [];
    }
    
    domUI.clear();
    
    eventEmitter.off("MenuToPlay");
    eventEmitter.off("MenuToContinue");
    eventEmitter.off("MenuToOptions");
    eventEmitter.off("MenuToCredits");
    eventEmitter.off("MenuToExit");
}
}