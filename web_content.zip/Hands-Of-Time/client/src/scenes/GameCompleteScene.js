import { BaseScene } from "./BaseScene.js";
import { eventEmitter } from "../events/EventEmitter.js";
import domUI from "../ui/domUIManager.js";

export class GameCompleteScene extends BaseScene {
    constructor(config) {
        super("GameCompleteScene", config);
        this.config = config;
        this.gamePaused = true;
    }
    
    create() {
        const { PreloadScene } = this.game.scene.keys;
        
        this.preloadScene = PreloadScene;
        
        domUI.clear();
        
        this.dom = domUI.show(`
            <div class="game-complete-screen">

                <div class="game-complete-content">

                    <h1 class="game-complete-title">
                        Game Complete
                    </h1>

                    <button
                        id="levelComplete_newGameBtn"
                        class="game-complete-btn"
                    >
                        New Game
                    </button>

                    <button
                        id="levelComplete_menuBtn"
                        class="game-complete-btn"
                    >
                        Menu
                    </button>

                </div>

            </div>
        `);
        
        this.handleGameComplete();
        this.processEvents();
    }
    
    processEvents() {
        const { PlayScene } = this.game.scene.keys;
        
        eventEmitter.once("GameCompleteToMenu", () => {
            if (this.gamePaused) {
                this.preloadScene.audio.popUpSound.play();
                PlayScene.watch.resetWatch(PlayScene.ui.timeText);
                this.shutdown();
                this.scene.start("TableSelectionScene");
                this.gamePaused = false;
            }
        });
        
        eventEmitter.once("GameCompleteToNewGame", () => {
            if (this.gamePaused) {
                PlayScene.watch.resetWatch(PlayScene.ui.timeText);
                this.scene.stop();
                this.preloadScene.audio.popUpSound.play();
                this.shutdown();
                this.scene.launch("PlayScene");
                this.gamePaused = false;
            }
        });
        
        eventEmitter.on("GameCompleteToRestart", () => {
            if (this.gamePaused) {
                PlayScene.watch
                    .resetWatch(PlayScene.ui.timeText)
                    .setUpWatch(PlayScene.ui.timeText);
                
                PlayScene.audio.popUpSound.play();
                PlayScene.solitaire.onClickRestartButton();
                PlayScene.commandHandler.reset();
                PlayScene.updateMoves();
                PlayScene.updateScore();
                
                this.shutdown();
                
                if (this.scene.isPaused("PlayScene")) {
                    this.scene.resume("PlayScene");
                }
                
                this.gamePaused = false;
            }
        });
    }
    
    handleGameComplete() {
        const { PlayScene } = this.game.scene.keys;
        
        PlayScene.watch.stopWatch();
        
        const newGameBtn = this.dom.querySelector(
            "#levelComplete_newGameBtn"
        );
        
        const menuBtn = this.dom.querySelector(
            "#levelComplete_menuBtn"
        );
        
        newGameBtn.addEventListener("click", () => {
            eventEmitter.emit("GameCompleteToNewGame");
        });
        
        menuBtn.addEventListener("click", () => {
            eventEmitter.emit("GameCompleteToMenu");
        });
    }
    
    shutdown() {
        domUI.clear();
    }
}