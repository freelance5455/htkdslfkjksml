import { BaseScene } from "./BaseScene.js";
import domUI from "../ui/domUIManager.js";

// movements
import { AnomalyToResolved } from "../movements/AnomalyToResolved.js";

export class TurnCompleteScene extends BaseScene {
    constructor(config) {
        super("TurnCompleteScene", config);

        this.config = config;
        this.turnCompleteMode = false;
    }

    destroyEvents() {
    }

    enter() {
        this.destroyEvents();

        this.registry.set(
            "TurnWasCompleted",
            "yes"
        );
    }

    injectUI() {
        this.dom = domUI.show(`
            <section id="ht-turn-complete-root">

                <div id="ht-turn-complete-panel">

                    <div id="ht-turn-complete-header">
                        <h2>TURN COMPLETE</h2>

                        <p>
                            The anomaly has been resolved.
                        </p>
                    </div>

                    <div id="ht-turn-complete-buttons">

                        <button
                            id="ht-turn-complete-back-btn"
                        >
                            GO BACK IN TIME
                        </button>

                        <button
                            id="ht-turn-complete-next-btn"
                        >
                            TO NEXT ANOMALY
                        </button>

                    </div>

                </div>

            </section>
        `);
    }

    goBackInTime() {
    const button = this.dom.querySelector(
        "#ht-turn-complete-back-btn"
    );
    
    button.addEventListener("click", () => {
        this.preloadScene.audio.play(
            this.preloadScene.audio.buttonClickSound
        );
        
        this.registry.set(
            "comingFrom",
            "TurnCompleteBackBtn"
        );
        
        this.scene.start("TransitionScene");
    });
}

goToNextAnomaly() {
    const button = this.dom.querySelector(
        "#ht-turn-complete-next-btn"
    );
    
    button.addEventListener("click", () => {
        this.preloadScene.audio.play(
            this.preloadScene.audio.buttonClickSound
        );
        
        this.registry.set(
            "comingFrom",
            "TurnCompleteNextBtn"
        );
        
        this.scene.start("TransitionScene");
    });
}

    // STEP 1
    // Send resolved anomaly to resolved pile
    castResolvedAnomalyOut() {
        return new Promise((resolve, reject) => {
            const command =
                new AnomalyToResolved(
                    this.playScene
                );

            this.playScene.commandHandler.execute(
                command
            );

            this.time.delayedCall(
                2000,
                resolve
            );
        });
    }

    // STEP 2
    // Send resolved card to Closed Portals
    sendResolvedCardToClosedPortal() {
        return new Promise((resolve, reject) => {
            this.playScene.gameplayUI
                .closedPortals
                .addResolvedCardToPortal();

            this.time.delayedCall(
                1100,
                resolve
            );
        });
    }

    // STEP 3
    // Enter go-back-in-time scene
    goToPortalSelection() {
        return new Promise((resolve, reject) => {
            this.scene.start(
                "GoBackInTimeScene"
            );

            this.time.delayedCall(
                100,
                resolve
            );
        });
    }

    async doChores() {
        await this.castResolvedAnomalyOut();
        await this.sendResolvedCardToClosedPortal();

        // await this.goToPortalSelection();
    }

    create() {
        
    // existing code...
        this.enter();

        const {
            PreloadScene,
            PlayScene
        } = this.game.scene.keys;

        this.preloadScene = PreloadScene;
        this.playScene = PlayScene;

        domUI.clear();

        this.injectUI();

        this.goToNextAnomaly();
        this.goBackInTime();
    }

    shutdown() {
        domUI.clear();
    }
}