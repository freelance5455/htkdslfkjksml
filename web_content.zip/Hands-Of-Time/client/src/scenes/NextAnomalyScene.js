import { BaseScene } from "./BaseScene.js";
import domUI from "../ui/domUIManager.js";

//Movements
import { OutworldToAnomaly } from "../movements/OutworldToAnomaly.js";
import { HandToDiscard } from "../movements/HandToDiscard.js";
import { HandToDeck } from "../movements/HandToDeck.js";
import { DeckToHand } from "../movements/DeckToHand.js";
import { RecycleMovement } from "../movements/RecycleMovement.js";

//Utils
import { getNonEmptyContainers } from "../utils/HelperFunctions.js";


export class NextAnomalyScene extends BaseScene {

    constructor(config) {
        super("NextAnomalyScene", config);

        this.config = config;

        this.turnEndedMode = false;
        this.recycling = false;
        this.retaining = false;
    }

    destroyEvents() {
    }

    enter() {
        this.destroyEvents();
    }

    injectUI() {

        this.dom = domUI.show(`
            <section id="ht-next-anomaly-root">

                <div id="ht-next-anomaly-panel">

                    <div id="ht-next-anomaly-buttons">

                        <button id="ht-next-anomaly-retain-btn">
                            RETAIN
                        </button>

                        <button id="ht-next-anomaly-recycle-btn">
                            RECYCLE
                        </button>

                        <button id="ht-next-anomaly-return-btn">
                            RETURN
                        </button>

                    </div>

                </div>

            </section>
        `);

        this.retainBtn =
            this.dom.querySelector(
                "#ht-next-anomaly-retain-btn"
            );

        this.recycleBtn =
            this.dom.querySelector(
                "#ht-next-anomaly-recycle-btn"
            );

        this.returnBtn =
            this.dom.querySelector(
                "#ht-next-anomaly-return-btn"
            );
    }

    goBackInTime() {

        this.returnBtn.addEventListener(
            "click",
            () => {

                domUI.clear();

                this.registry.set(
                    "comingFrom",
                    "GoToNextAnomalyBackBtn"
                );

                this.scene.start(
                    "TransitionScene"
                );
            }
        );
    }

    startNextTurn() {

        //RECYCLE button pressed
        this.recycleBtn.addEventListener(
            "click",
            () => {

                if (this.recycling) {
                    return;
                }

                this.recycling = true;

                domUI.clear();

                this.scene.stop();

                this.toNextSceneWithRecycle();
            }
        );

        //RETAIN button pressed
        this.retainBtn.addEventListener(
            "click",
            () => {

                if (this.retaining) {
                    return;
                }

                this.retaining = true;

                domUI.clear();

                this.scene.stop();

                this.toNextSceneWithRetain();
            }
        );
    }

    showInterstitialAd() {

        return new Promise((resolve) => {

            console.log(
                "Attempting to show interstitial ad..."
            );

            if (
                window.adSDK &&
                typeof window.adSDK.showInterstitial ===
                "function"
            ) {

                window.adSDK
                    .showInterstitial()
                    .then(() => {

                        console.log(
                            "Interstitial ad closed."
                        );

                        resolve();
                    })
                    .catch((err) => {

                        console.warn(
                            "Ad failed or not ready:",
                            err
                        );

                        resolve();
                    });

            }

            else if (
                typeof FBInstant !== "undefined"
            ) {

                FBInstant
                    .getInterstitialAdAsync(
                        "YOUR_PLACEMENT_ID"
                    )
                    .then(
                        (ad) =>
                            ad
                                .loadAsync()
                                .then(
                                    () => ad.showAsync()
                                )
                    )
                    .then(() => {

                        console.log(
                            "FB Instant interstitial closed."
                        );

                        resolve();
                    })
                    .catch((err) => {

                        console.warn(
                            "FB ad failed:",
                            err
                        );

                        resolve();
                    });

            }

            else {

                console.warn(
                    "No ad SDK detected. Skipping interstitial."
                );

                resolve();
            }
        });
    }

    get numberOfOccupiedContainers() {

        let num = 0;

        const { hand } =
            this.playScene.gameplayUI.piles;

        for (
            let i = 0;
            i < hand.containers.length;
            ++i
        ) {

            const container =
                hand.containers[i];

            if (container.length) {
                num++;
            }
        }

        return num;
    }

    hideSceneUI() {

        return new Promise(
            (resolve) => {

                domUI.clear();

                setTimeout(
                    () => {
                        resolve();
                    },
                    200
                );
            }
        );
    }

    resetRegistry() {

        return new Promise(
            (resolve) => {

                if (
                    this.scene.isPaused(
                        "PlayScene"
                    )
                ) {
                    this.scene.resume(
                        "PlayScene"
                    );
                }

                this.playScene.initRegistry();

                setTimeout(
                    () => {
                        resolve();
                    },
                    5
                );
            }
        );
    }

    recycleRemainingCards() {

        return new Promise(
            (resolve) => {

                const command =
                    new HandToDeck(
                        this.playScene
                    );

                this.playScene.commandHandler.execute(
                    command
                );

                setTimeout(
                    () => resolve(),
                    1000
                );
            }
        );
    }

    getDPReward() {

        return new Promise(
            (resolve) => {

                const {
                    DPText
                } = this.playScene.gameplayUI;

                const newPoints =
                    parseInt(DPText.text) + 3;

                DPText.setText(
                    newPoints
                );

                this.playScene.gameplayUI
                    .updateResourceTexts();

                setTimeout(
                    () => {
                        resolve();
                    },
                    300
                );
            }
        );
    }

    getRecycleRPReward() {

        let handPoints = 0;

        const {
            RPText,
            hand
        } = this.playScene.gameplayUI;

        hand.containers.forEach(
            (container) => {

                if (container.length) {

                    const card =
                        container.list[0];

                    const cardResource =
                        parseInt(
                            card.getData(
                                "resource"
                            )
                        );

                    if (cardResource) {
                        handPoints +=
                            cardResource;
                    }
                }
            }
        );

        const totalPoints =
            parseInt(RPText.text) +
            handPoints;

        return new Promise(
            (resolve) => {

                RPText.setText(
                    totalPoints
                );

                this.playScene.gameplayUI
                    .updateResourceTexts();

                setTimeout(
                    () => {
                        resolve();
                    },
                    300
                );
            }
        );
    }

    getAnomalyRPReward() {

        return new Promise(
            (resolve) => {

                const {
                    RPText
                } = this.playScene.gameplayUI;

                const anomaly =
                    this.playScene.gameplayUI
                        .anomalyPile
                        .container
                        .list[0];

                if (!anomaly) {
                    resolve();
                    return;
                }

                const anomalyPoint =
                    anomaly.getData(
                        "resource"
                    );

                const totalPoints =
                    parseInt(RPText.text) +
                    anomalyPoint;

                RPText.setText(
                    totalPoints
                );

                this.playScene.gameplayUI
                    .updateResourceTexts();

                setTimeout(
                    () => {
                        resolve();
                    },
                    300
                );
            }
        );
    }

    getSPReward() {

        const {
            SPText
        } = this.playScene.gameplayUI;

        const totalPoints =
            parseInt(SPText.text) + 3;

        return new Promise(
            (resolve) => {

                SPText.setText(
                    totalPoints
                );

                this.playScene.gameplayUI
                    .updateResourceTexts();

                setTimeout(
                    () => {
                        resolve();
                    },
                    300
                );
            }
        );
    }

    sendNextAnomalyDown() {

        return new Promise(
            (resolve) => {

                const command =
                    new OutworldToAnomaly(
                        this.playScene
                    );

                this.playScene.commandHandler.execute(
                    command
                );

                setTimeout(
                    () => resolve(),
                    1200
                );
            }
        );
    }

    shuffleDeck() {

        return new Promise(
            (resolve) => {

                const {
                    deck
                } = this.playScene.gameplayUI.piles;

                deck.container.shuffle();

                setTimeout(
                    () => resolve(),
                    1000
                );
            }
        );
    }

    sendCardsToHand() {

        return new Promise(
            (resolve) => {

                const num =
                    this.numberOfOccupiedContainers;

                if (num === 8) {
                    resolve();
                    return;
                }

                const numberOfCardsToDeal =
                    8 - num;

                const command =
                    new DeckToHand(
                        this.playScene,
                        numberOfCardsToDeal
                    );

                this.playScene.commandHandler.execute(
                    command
                );

                setTimeout(
                    () => resolve(),
                    1000
                );
            }
        );
    }

    enableInput() {

        return new Promise(
            (resolve) => {

                this.playScene.gameplayUI
                    .gameplayButtons
                    .forEach(
                        (btn) => {

                            this.playScene.inputLock
                                .enableOne(
                                    btn.hitArea
                                );
                        }
                    );

                const containers =
                    getNonEmptyContainers(
                        this.playScene.gameplayUI
                            .hand
                            .containers
                    );

                containers.forEach(
                    (container) => {

                        this.playScene.inputLock
                            .enableOne(
                                container.list[0]
                            );
                    }
                );

                setTimeout(
                    () => resolve(),
                    10
                );
            }
        );
    }

    showNewTurnMessage() {

        return new Promise(
            (resolve) => {

                const currentLevel =
                    this.playScene.gameplayUI
                        .anomalyPile
                        .container
                        .list[0]
                        .getData(
                            "level"
                        );

                this.playScene.gameplayUI
                    .createNewTurnMessage(
                        currentLevel
                    );

                setTimeout(
                    () => resolve(),
                    2000
                );
            }
        );
    }

    hideNewTurnMessage() {

        return new Promise(
            (resolve) => {

                this.playScene.gameplayUI
                    .hideMessage();

                setTimeout(
                    () => resolve(),
                    10
                );
            }
        );
    }

    clearOldProgressMessages() {

        return new Promise(
            (resolve) => {

                this.playScene.progressMessage
                    .clearAll();

                setTimeout(
                    () => resolve(),
                    100
                );
            }
        );
    }

    openScroll() {

        return new Promise(
            (resolve) => {

                this.playScene.gameplayUI
                    .anomalyPile
                    .scroll
                    .tweenOpen();

                setTimeout(
                    () => resolve(),
                    500
                );
            }
        );
    }

    closeScroll() {

        return new Promise(
            (resolve) => {

                this.playScene.gameplayUI
                    .anomalyPile
                    .scroll
                    .tweenClose();

                setTimeout(
                    () => resolve(),
                    500
                );
            }
        );
    }

    async toNextSceneWithRecycle() {

        await this.showInterstitialAd();

        await this.hideSceneUI();

        await this.clearOldProgressMessages();

        await this.closeScroll();

        await this.resetRegistry();

        //Get rewards.
        await this.getDPReward();

        await this.getSPReward();

        await this.getRecycleRPReward();

        await this.getAnomalyRPReward();

        //Recycle remaining cards.
        await this.recycleRemainingCards();

        await this.sendNextAnomalyDown();

        await this.openScroll();

        await this.shuffleDeck();

        await this.sendCardsToHand();

        await this.enableInput();

        //Extra functions for level 3.
        await this.shuffleDiscard();

        await this.recycleFromDiscard();

        //More functions for all levels.
        await this.showNewTurnMessage();

        await this.hideNewTurnMessage();
        this.destroyPortalScenes();
    }

    async toNextSceneWithRetain() {

        await this.showInterstitialAd();

        await this.hideSceneUI();

        await this.clearOldProgressMessages();

        await this.closeScroll();

        await this.resetRegistry();

        //Get rewards.
        await this.getDPReward();

        await this.getSPReward();

        await this.getAnomalyRPReward();

        //Send next anomaly down.
        await this.sendNextAnomalyDown();

        await this.openScroll();

        await this.shuffleDeck();

        await this.sendCardsToHand();

        await this.enableInput();

        //Extra functions for level 3.
        await this.shuffleDiscard();

        await this.recycleFromDiscard();

        //More functions for all levels.
        await this.forceDiscard();

        await this.showNewTurnMessage();

        await this.hideNewTurnMessage();
        this.destroyPortalScenes();
    }

    //TIME THIEF EFFECTS

    removeJackFrom(
        container,
        thiefContainer
    ) {

        container.list[0].setData(
            "forcedToDiscard",
            true
        );

        const command =
            new HandToDiscard(
                this.playScene,
                container
            );

        this.playScene.commandHandler.execute(
            command
        );

        setTimeout(
            () => thiefContainer.shift(),
            1000
        );
    }

    async forceDiscard() {

        const containers =
            this.playScene.gameplayUI
                .hand
                .containers;

        let noviceJackContainers = [];
        let expertJackContainers = [];

        //Collect jacks.
        for (
            let i = 0;
            i < containers.length;
            ++i
        ) {

            const container =
                containers[i];

            if (container.length) {

                container.list.forEach(
                    (card) => {

                        if (
                            card.getData(
                                "value"
                            ) === 11
                        ) {

                            const suit =
                                card
                                    .getData("suit")
                                    .toUpperCase()
                                    .trim();

                            switch (suit) {

                                case "CLUB":
                                case "SPADE":

                                    noviceJackContainers
                                        .push(i);

                                    break;

                                case "HEART":
                                case "DIAMOND":

                                    expertJackContainers
                                        .push(i);

                                    break;
                            }
                        }
                    }
                );
            }
        }

        noviceJackContainers.forEach(
            () => {

                this.loseResources();

                this.loseDPReward();

                this.loseSPReward();
            }
        );

        expertJackContainers.forEach(
            () => {

                this.stealARandomCard();

                this.loseDPReward();

                this.loseSPReward();
            }
        );

        const removeSequentially =
            async (indices) => {

                while (
                    indices.length > 0
                ) {

                    this.removeJackFrom(
                        containers[
                            indices[0]
                        ],
                        indices
                    );

                    await new Promise(
                        (resolve) =>
                            setTimeout(
                                resolve,
                                1010
                            )
                    );
                }
            };

        await removeSequentially(
            noviceJackContainers
        );

        await removeSequentially(
            expertJackContainers
        );

        return Promise.resolve();
    }

    stealARandomCard() {

        const containers =
            this.playScene.gameplayUI
                .hand
                .containers;

        let qualifiedContainers = [];

        //Collect non-jacks.
        for (
            let i = 0;
            i < containers.length;
            ++i
        ) {

            const container =
                containers[i];

            if (container.length) {

                container.list.forEach(
                    (card) => {

                        if (
                            card.getData(
                                "value"
                            ) !== 11
                        ) {

                            qualifiedContainers.push(
                                container
                            );
                        }
                    }
                );
            }
        }

        if (qualifiedContainers.length > 0) {

            return new Promise(
                (resolve) => {

                    const randomContainer =
                        qualifiedContainers[
                            Math.floor(
                                Math.random() *
                                qualifiedContainers.length
                            )
                        ];

                    randomContainer.list[0]
                        .setData(
                            "forcedToDiscard",
                            true
                        );

                    const command =
                        new HandToDiscard(
                            this.playScene,
                            randomContainer
                        );

                    setTimeout(
                        () => {

                            this.playScene
                                .commandHandler
                                .execute(command);

                        },
                        200
                    );

                    setTimeout(
                        () => resolve(),
                        1200
                    );
                }
            );
        }

        this.loseDPReward();
        this.loseSPReward();
    }

    loseResources() {

        return new Promise(
            (resolve) => {

                const {
                    RPText
                } = this.playScene.gameplayUI;

                const totalPoints =
                    parseInt(RPText.text) - 8;

                RPText.setText(
                    totalPoints
                );

                this.playScene.gameplayUI
                    .updateResourceTexts();

                setTimeout(
                    () => resolve(),
                    300
                );
            }
        );
    }

    loseDPReward() {

        return new Promise(
            (resolve) => {

                const {
                    DPText
                } = this.playScene.gameplayUI;

                const newPoints =
                    parseInt(DPText.text) - 2;

                DPText.setText(
                    newPoints
                );

                this.playScene.gameplayUI
                    .updateResourceTexts();

                setTimeout(
                    () => resolve(),
                    300
                );
            }
        );
    }

    loseSPReward() {

        const {
            SPText
        } = this.playScene.gameplayUI;

        const totalPoints =
            parseInt(SPText.text) - 2;

        return new Promise(
            (resolve) => {

                SPText.setText(
                    totalPoints
                );

                this.playScene.gameplayUI
                    .updateResourceTexts();

                setTimeout(
                    () => resolve(),
                    300
                );
            }
        );
    }

    shuffleDiscard() {

        return new Promise(
            (resolve) => {

                const turnIndex =
                    this.playScene.gameplayUI
                        .resolvedPile
                        .container
                        .list[0]
                        .getData(
                            "level"
                        ) - 1;

                if (turnIndex !== 2) {

                    setTimeout(
                        () => resolve(),
                        10
                    );

                }
                else {

                    setTimeout(
                        () => resolve(),
                        1000
                    );
                }
            }
        );
    }

    recycleFromDiscard() {

        return new Promise(
            (resolve) => {

                const turnIndex =
                    this.playScene.gameplayUI
                        .anomalyPile
                        .container
                        .list[0]
                        .getData(
                            "level"
                        ) - 1;

                if (turnIndex !== 2) {

                    setTimeout(
                        () => resolve(),
                        1
                    );

                }
                else {

                    const command =
                        new RecycleMovement(
                            this.playScene
                        );

                    this.playScene.commandHandler
                        .execute(command);

                    setTimeout(
                        () => resolve(),
                        1000
                    );
                }
            }
        );
    }
    destroyPortalScenes() {
    const resolvedPortalScene =
        this.scene.get("ResolvedPortalScene");

    if (
        resolvedPortalScene &&
        resolvedPortalScene.closedPortals
    ) {
        resolvedPortalScene.closedPortals.destroy();
        resolvedPortalScene.closedPortals = null;
    }

    const unresolvedPortalScene =
        this.scene.get("UnresolvedPortalScene");

    if (
        unresolvedPortalScene &&
        unresolvedPortalScene.closedPortals
    ) {
        unresolvedPortalScene.closedPortals.destroy();
        unresolvedPortalScene.closedPortals = null;
    }
} 

    create() {

        const {
            PreloadScene,
            PlayScene
        } = this.game.scene.keys;

        this.preloadScene =
            PreloadScene;

        this.playScene =
            PlayScene;

        domUI.clear();

        this.injectUI();

        //Disable gameplay buttons.
        this.playScene.gameplayUI
            .gameplayButtons
            .forEach(
                (btn) => {

                    this.playScene.inputLock
                        .disableOne(
                            btn.hitArea
                        );
                }
            );

        //Disable cards.
        const containers =
            getNonEmptyContainers(
                this.playScene.gameplayUI
                    .hand
                    .containers
            );

        containers.forEach(
            (container) => {

                this.playScene.inputLock
                    .disableOne(
                        container.list[0]
                    );
            }
        );

        this.enter();

        this.goBackInTime();

        this.startNextTurn();
    }

    shutdown() {
        domUI.clear();
    }

    initEvents() {
    }
}