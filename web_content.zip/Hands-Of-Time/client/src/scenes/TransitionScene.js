import { BaseScene } from "./BaseScene.js";
import { eventEmitter } from "../events/EventEmitter.js";
import domUI from "../ui/domUIManager.js";

export class TransitionScene extends BaseScene {
    constructor(config) {
        super("TransitionScene", config);

        this.config = config;
    }

    showInterface() {
        this.hideAllScreens();
        this.showOne(this.manufacturerScreen, "grid", 0);
    }

    preload() {
    }

    create() {
        
        this.timeout = 1;

        const comingFrom =
            this.registry.get("comingFrom");

        switch (comingFrom) {

            case "TurnCompleteBackBtn":
case "TurnEndedBackBtn": {

    domUI.clear();

    this.scene.stop("PauseScene");

    setTimeout(() => {
        this.scene.start("ResolvedPortalScene");
    }, this.timeout);

    break;
}

            case "TurnCompleteNextBtn": {
                domUI.clear();

    this.scene.stop("PauseScene");

    

    setTimeout(() => {
        

        this.scene.start("NextAnomalyScene");
    }, this.timeout);

    break;
}

            case "GoToNextAnomalyBackBtn": {

                setTimeout(() => {
                    this.scene.start("TurnCompleteScene");
                }, this.timeout);

                break;
            }

            case "TurnEndedFutureBtn": {
                domUI.clear();
                setTimeout(() => {
                    this.scene.start("UnresolvedPortalScene");
                }, this.timeout);

                break;
            }

            default: {
                break;
            }
        }
    }
}