/**@type {import("../typings/phaser")} */
import { BaseScene } from "./BaseScene.js";
import { eventEmitter } from "../events/EventEmitter.js";

//Movements
import { AnomalyToResolved } from "../movements/AnomalyToResolved.js";
import { OutworldToAnomaly } from "../movements/OutworldToAnomaly.js";
import { HandToDeck } from "../movements/HandToDeck.js";
import { HandToDiscard } from "../movements/HandToDiscard.js";
import { DeckToHand } from "../movements/DeckToHand.js";
import { DiscardToDeck } from "../movements/DiscardToDeck.js";
import { PortalToUnresolved } from "../movements/PortalToUnresolved.js";
import { AnomalyToUnresolved } from "../movements/AnomalyToUnresolved.js";
import { RecycleMovement } from "../movements/RecycleMovement.js";

//utils
import { applyGlowEffect, removeGlowEffect } from '../utils/GlowEffect.js';
import { getNonEmptyContainers, getEmptyContainers } from "../utils/HelperFunctions.js";
//portal
import { ClosedPortals } from "../entities/ClosedPortals.js";
import { AnomalyTextbox } from "../entities/textboxes/AnomalyTextbox.js";


export class ResolvedPortalScene extends BaseScene{
    constructor(config){
        super("ResolvedPortalScene", config);
        this.config = config;
        this.turnEndedMode = false;
        this.recycling = false;
        this.retaining = false;
    }
    
    enter(){
    this.resolving = false;

    this.closedPortals = new ClosedPortals(this);
    this.closedPortals.selectButton.deactivate().enterRestState();
    this.closedPortals.backButton.deactivate().enterRestState();
    this.addResolvedAnomaliesToPortal();
    this.portalTextbox = new AnomalyTextbox(this);
}
    showPortalCardInfo(){
        const containers = getNonEmptyContainers(this.closedPortals.portalContainers);
        for(let i = 0; i < containers.length; ++i){
            const portal = containers[i];
            if(portal.length){
                
                const card = portal.list[0];
                this.closedPortals.hitAreas[i].setInteractive({useHandCursor: true})
                .off("pointerdown")
                .on("pointerdown", ()=>{
                    
                    if(this.closedPortals.selectButton.active){
                        this.portalTextbox.hide();
                        return;
                    }
                    setTimeout(()=>{
                        this.portalTextbox.show(card);
                        this.portalTextbox.bringToTop(portal.depth);
                    }, 50)
                })
            }
        }
    }
    returnToTurnEndedScene(){
        this.closedPortals.backButton.hitArea.once("pointerdown", ()=>{
            this.preloadScene.audio.buttonClickSound.play();
            this.playScene.anomalyTextbox.hide();
            this.clearPortalsOnExit();
            this.scene.start("TurnEndedScene");
        })
    }
    returnToTurnCompleteScene(){
        this.closedPortals.backButton.hitArea.once("pointerdown", ()=>{
            this.preloadScene.audio.buttonClickSound.play();
            this.playScene.anomalyTextbox.hide();
            this.clearPortalsOnExit();
            this.scene.start("TurnCompleteScene");
        })
    }
    
    selectAnotherAnomaly(){
        this.resolving = false;
        //if all Portals are empty, play an error sound and return early
        const { portalContainers } = this.closedPortals;
        let occupiedPortalCount = 0;
        this.closedPortals.selectButton.hitArea.on("pointerdown", ()=>{
            this.preloadScene.audio.buttonClickSound.play();
            //close resolved-portal textbox first
            this.portalTextbox.hide();
            
            const containers = getNonEmptyContainers(this.closedPortals.portalContainers);
            if(containers.length === 0){
                if(this.closedPortals.selectButton.active) this.preloadScene.audio.play(this.preloadScene.audio.errorSound);
                return;
            }
            
            //get references to the last card clicked and the last portal visited
            for(let i = 0; i < containers.length; ++i){
                const portal = containers[i];
                    if(portal.length){
                        
                        const card = portal.list[0];
                        this.closedPortals.hitAreas[i].on("pointerdown", ()=>{
                            //if SELECT button is not active (red colour), return early
                            if(!this.closedPortals.selectButton.active) return;
                            if(this.resolving) return;
                            this.resolvePortalAnomaly(portal);
                            
                            //instantiate copy of same card in Resolved Pile
                            //will destroy later when not needed any longer by other functions
                            this.resolvedCard = this.playScene.gameplayUI.resolvedPile.container.list[i];
                        })
                }
            }
            
            
        })
    }
    openScroll(){
        return new Promise((resolve, reject) => {
            this.playScene.gameplayUI.anomalyPile.scroll.tweenOpen();
            setTimeout(()=>{ resolve() }, 500)
        })
    }
    closeScroll(){
        return new Promise((resolve, reject) => {
            this.playScene.gameplayUI.anomalyPile.scroll.tweenClose();
            setTimeout(()=>{ resolve() }, 500)
        })
    }
    
    async resolvePortalAnomaly(portal){
        this.resolving = true;
        await this.clearOldProgressMessages();
        await this.closeScroll();
        await this.sendAnomalyCardToOutworld();
        await this.returnDiscardCardsToDeck(portal);
        await this.sendPortalCardToOutworld(portal);
        await this.closePortal();
        await this.destroyClosedPortals();
        await this.recycleRemainingCards();
        await this.destroyResolvedCardFromPile();
        await this.sendNextAnomalyDown();
        await this.openScroll();
        await this.shuffleDeck();
        await this.sendCardsToHand();
        await this.removeInputLock();
        // extra functions for level 3
        await this.shuffleDiscard();
        await this.recycleFromDiscard();
        //
        await this.forceDiscard();
        await this.showNewTurnMessage();
        await this.hideNewTurnMessage();
    }
    //TIME THIEF  EFFECTS FUNCTIONS
    //A
    removeJackFrom(container, thiefContainer){
        container.list[0].setData("forcedToDiscard", true);
        const command = new HandToDiscard(this.playScene, container);
        this.playScene.commandHandler.execute(command);
        setTimeout(()=> thiefContainer.shift(), 1000 );
    }
    //B
    async forceDiscard() {
        const containers = this.playScene.gameplayUI.hand.containers;
        let noviceJackContainers = [];
        let expertJackContainers = [];
    
        // Collect jacks
        for (let i = 0; i < containers.length; ++i) {
            const container = containers[i];
            if (container.length) {
                container.list.forEach(card => {
                    if (card.getData("value") === 11) {
                        const suit = card.getData("suit").toUpperCase().trim();
                        switch (suit) {
                            case "CLUB": case "SPADE":
                                noviceJackContainers.push(i);
                                break;
                            case "HEART": case "DIAMOND":
                                expertJackContainers.push(i);
                                break;
                        }
                    }
                });
            }
        }
        // Always lose resources
        noviceJackContainers.forEach(() => {
            this.loseResources();
            this.loseDPReward();
            this.loseSPReward();
        });
        expertJackContainers.forEach(() => {
            this.stealARandomCard();
            this.loseDPReward();
            this.loseSPReward();
        });
    
        // Helper to sequentially remove jacks with delay
        const removeSequentially = async (indices) => {
            while (indices.length > 0) {
                this.removeJackFrom(containers[indices[0]], indices);
                await new Promise(r => setTimeout(r, 1010));
            }
        };
    
        // Run them in order
        await removeSequentially(noviceJackContainers);
        await removeSequentially(expertJackContainers);
    
        // Done
        return Promise.resolve();
    }
    //C
    stealARandomCard(){
        //get random (non-jack) card
        //if unavailable, remove 2 DP and 2 RP
        const containers = this.playScene.gameplayUI.hand.containers;
        let qualifiedContainers = [];
        let expertJackContainers = [];
    
        // Collect jacks
        for (let i = 0; i < containers.length; ++i) {
            const container = containers[i];
            if (container.length) {
                container.list.forEach(card => {
                    if (card.getData("value") !== 11) {
                        qualifiedContainers.push(container);
                    }
                });
            }
        }
        if(qualifiedContainers.length > 0){
            return new Promise((resolve, reject) => {
                
                const randomContainer = qualifiedContainers[ Math.floor(Math.random()* qualifiedContainers.length) ];
                randomContainer.list[0].setData("forcedToDiscard", true);
                const command = new HandToDiscard(this.playScene, randomContainer);
                //remove a valid card such that it trails the Thief (hence, cause for 200 ms delay)
                setTimeout(()=> this.playScene.commandHandler.execute(command), 200)
                setTimeout(()=> resolve(), 1200);
            })
        }
        else{
            this.loseDPReward();
            this.loseSPReward();
        }
    }
    //D
    loseResources(){
        
        return new Promise((resolve, reject)=>{
            const { RPText, RPRect} = this.playScene.gameplayUI;
            const totalPoints = parseInt(RPText.text) - 8;
            
            RPText.setText(totalPoints);
            RPText.setPosition(RPRect.centerX - RPText.displayWidth/2, RPRect.bottom - RPText.height - 10);
                setTimeout(()=>{ resolve() }, 300)
        })
    }
    //E
    loseDPReward(){
        return new Promise((resolve, reject)=>{
            const { DPText, DPRect} = this.playScene.gameplayUI;
            const newPoints = parseInt(DPText.text) - 2;
            DPText.setText(newPoints);
            DPText.setPosition(DPRect.centerX - DPText.displayWidth/2, DPRect.bottom - DPText.height - 10);
                setTimeout(()=>{ resolve() }, 300)
        })
    }
    //F
    loseSPReward(){
        const { SPText, SPRect} = this.playScene.gameplayUI;
 
        const totalPoints = parseInt(SPText.text) - (2);
        return new Promise((resolve, reject)=>{
            SPText.setText(totalPoints);
            SPText.setPosition(SPRect.centerX - SPText.displayWidth/2, SPRect.bottom - SPText.height - 10);
                setTimeout(()=>{ resolve() }, 300)
        })
    } 
    //STEP 5. return to Deck, cards previously used in resolving that Anomaly
    returnDiscardCardsToDeck(portal){
        return new Promise((resolve, reject) => {
            const command = new DiscardToDeck(this.playScene, portal);
            this.playScene.commandHandler.execute(command);
            setTimeout(()=>resolve(), command.timeout);
        })
    }
    //STEP 6: destroy resolved card from Resolved pile
    destroyResolvedCardFromPile(){
        return new Promise((resolve, reject) => {
            this.resolvedCard&& this.resolvedCard.destroy();
            setTimeout(()=>resolve(), 10);
        })
    }
    //step 2nd to last
    showNewTurnMessage(){
        return new Promise((resolve, reject) => {
            const currentLevel = this.playScene.gameplayUI.anomalyPile.container.list[0].getData("level");
            this.playScene.gameplayUI.createNewTurnMessage(currentLevel);
            setTimeout(()=>{ resolve() }, 2000)
        })
    }
    //step last
    hideNewTurnMessage(){
        return new Promise((resolve, reject) => {
            this.playScene.gameplayUI.hideMessage(); 
            setTimeout(()=>{ resolve() }, 10)
        })
    } 
    //STEP 1. remove current anomaly card
    sendAnomalyCardToOutworld(){
        return new Promise((resolve, reject) =>{
            const command = new AnomalyToUnresolved(this.playScene);
            this.playScene.commandHandler.execute(command);
            this.time.delayedCall(800, resolve);
        })
    }
    //STEP 2.remove portal card
    
    sendPortalCardToOutworld(portal){
        return new Promise((resolve, reject) =>{
            const command = new PortalToUnresolved(this.playScene, portal);
            this.playScene.commandHandler.execute(command);
            this.time.delayedCall(766, resolve);
        })
    }
    //STEP 2. close portal
    destroyClosedPortals() {
    return new Promise((resolve, reject) => {
        if (this.closedPortals) {
            this.closedPortals.destroy();
            this.closedPortals = null;
        }
        
        this.time.delayedCall(66, resolve);
    })
}
    closePortal(){
    return new Promise((resolve, reject) =>{
        this.clearPortalsOnExit();
        this.time.delayedCall(66, resolve);
    })
}
   //STEP 3: clear progress messages
    clearOldProgressMessages(){
        return new Promise((resolve, reject) => {
            this.playScene.progressMessage.clearAll();
            this.time.delayedCall(100, resolve);
        })
    }
    //STEP 4: return cards in hand to deck
    recycleRemainingCards(){
        return new Promise((resolve, reject)=>{
            const command = new HandToDeck(this.playScene);
            this.playScene.commandHandler.execute(command)
            this.time.delayedCall(500, resolve);
        })
    }
    //STEP 5: send next anomaly down
    sendNextAnomalyDown(){
        return new Promise((resolve, reject)=>{
            const command = new OutworldToAnomaly(this.playScene);
            this.playScene.commandHandler.execute(command);
            this.time.delayedCall(400, resolve);
        })
    }
    //STEP 6: shuffle deck
    shuffleDeck(){
        return new Promise((resolve, reject)=>{
            const { deck } = this.playScene.gameplayUI.piles;
           // this.preloadScene.audio.shuffleSound.play();
            deck.container.shuffle();
            this.time.delayedCall(1000, resolve);
        })
    }
    //STEP 7: send cards to hand
    sendCardsToHand(){
        return new Promise((resolve, reject)=>{
            let num = this.numberOfOccupiedContainers;
            if(num === 8) reolve();
            else{
                const numberOfCardsToDeal = 8 - num;
                const command = new DeckToHand(this.playScene, numberOfCardsToDeal);
                this.playScene.commandHandler.execute(command);
                setTimeout(()=>{ resolve() }, 1000);
            }
        })
    }
    //STEP 8: remove input lock
    removeInputLock(){
        return new Promise((resolve, reject) => {
            //unlock buttons and cards (return interactivity)
            this.playScene.gameplayUI.gameplayButtons.forEach(btn=>{
                this.playScene.inputLock.enableOne(btn.hitArea);
            })
            //cards
            const containers = getNonEmptyContainers(this.playScene.gameplayUI.hand.containers);
            containers.forEach(container=>{
                this.playScene.inputLock.enableOne(container.list[0]);
            })
            //current anomaly too
            this.playScene.inputLock.enableOne(this.playScene.gameplayUI.anomalyPile.container.list[0]);

            //if(this.scene.isPaused("PlayScene")) this.scene.resume("PlayScene");
            this.playScene.initRegistry();
            //this.scene.stop("ResolvedPortalScene");

            this.time.delayedCall(100, resolve);
        })
    }
    shuffleDiscard(){
        return new Promise((resolve, reject) => {
            const turnIndex = this.playScene.gameplayUI.anomalyPile.container.list[0].getData("level") - 1;
            
            if(turnIndex !== 2){
                this.time.delayedCall(1000, resolve);
            }
            else{
                this.preloadScene.audio.shuffleSound.play();
                this.time.delayedCall(10, resolve);
            }

        })
    }
    recycleFromDiscard(){
        return new Promise((resolve, reject)=>{
            const turnIndex = this.playScene.gameplayUI.anomalyPile.container.list[0].getData("level") - 1;
            if(turnIndex !== 2) {
               // console.log("not yet level 3");
                this.playScene.time.delayedCall(1, resolve);
            }
            else{
                const command = new RecycleMovement(this.playScene);
                this.playScene.commandHandler.execute(command);
                this.time.delayedCall(1000, resolve);
            }
            
        })
    }
    get numberOfOccupiedContainers(){
        let num = 0;
        const { hand  } = this.playScene.gameplayUI.piles;
        for(let i = 0; i < hand.containers.length; ++i){
            const container = hand.containers[i];
            if(container.length) num++;
        }
        return num;
    }
    
    addResolvedAnomaliesToPortal(){  
        let anomalyCounter = -1;  
        //get all resolved anomalies  
        const anomalies = this.playScene.gameplayUI.resolvedPile.container.list;  
        let anomaliesToBeAdded = anomalies.length;  
        //get one anomaly at a time, create a copy of it and send to the first empty portal  
        if(anomaliesToBeAdded === 0) return;  
        //loop through all the resolved anomalies  
        while(anomaliesToBeAdded > 0){  
            anomalyCounter++;  
            const anomaly = anomalies[anomalyCounter];  
            const portal = this.closedPortals.portalContainers[anomalyCounter];  
             //get the data of each anomaly  
            const card = this.playScene.createCard(portal.getData("ownerID")+"Card", true)  
                    .setDisplaySize(portal.width, portal.height)  
                    .setFrame(anomaly.getData("frame"))
                    .setInteractive({draggable: false, useHandCursor: true})
                card.setData({  
                x: card.x,  
                y: card.y,  
                sourceZone: "resolved",
                frame: anomaly.getData("frame"),  
                suit: anomaly.getData("suit"),  
                colour: anomaly.getData("colour"),  
                value: anomaly.getData("value"),  
                index: portal.getData("index"),  
                zone: "portal",  
                rect: new Phaser.Geom.Rectangle(portal.x, portal.y, portal.width, portal.height),  
                title: anomaly.getData("title"),  
                attributes: anomaly.getData("attributes"),  
                category: anomaly.getData("category"),  
                level: anomaly.getData("level"),
                firstCard: anomaly.getData("firstCard") || 0,
                secondCard: anomaly.getData("secondCard") || 0,
                thirdCard: anomaly.getData("thirdCard") || 0,
                reward: anomaly.getData("reward"),  
                objectives: anomaly.getData("objectives"),  
                resource: anomaly.getData("resource"),
                DP: anomaly.getData("DP"),
                SP: anomaly.getData("SP"),
            });  
            portal.add(card);  
            card.setPosition(0, 0);  
            anomaliesToBeAdded--; 
        }  
          
          
}
    loseResources(){
        
        return new Promise((resolve, reject)=>{
            const { RPText, RPRect} = this.playScene.gameplayUI;
            const totalPoints = parseInt(RPText.text) - 2;
            
            RPText.setText(totalPoints);
            RPText.setPosition(RPRect.centerX - RPText.displayWidth/2, RPRect.bottom - RPText.height - 10);
                setTimeout(()=>{ resolve() }, 300)
        })
    }
    loseDPReward(){
        return new Promise((resolve, reject)=>{
            const { DPText, DPRect} = this.playScene.gameplayUI;
            const newPoints = parseInt(DPText.text) - 2;
            DPText.setText(newPoints);
            DPText.setPosition(DPRect.centerX - DPText.displayWidth/2, DPRect.bottom - DPText.height - 10);
                setTimeout(()=>{ resolve() }, 300)
        })
    }
    
    loseSPReward(){
        const { SPText, SPRect} = this.playScene.gameplayUI;
 
        const totalPoints = parseInt(SPText.text) - (2);
        return new Promise((resolve, reject)=>{
            SPText.setText(totalPoints);
            SPText.setPosition(SPRect.centerX - SPText.displayWidth/2, SPRect.bottom - SPText.height - 10);
                setTimeout(()=>{ resolve() }, 300)
        })
    } 
    clearPortalsOnExit(){
        //destroy portal cards
        const portals = getNonEmptyContainers(this.closedPortals.portalContainers);
        if(portals.length === 0) return;
        portals.forEach(portal =>{
            portal.list.forEach(card=>{
                portal.remove(card, true);
            })
        })
    }
    create(){
        const { PreloadScene, PlayScene } = this.game.scene.keys;
        this.preloadScene = PreloadScene;
        this.playScene = PlayScene;
        this.enter();
        
        //resume play scene (not supposed to, but i've added ClosedPortal as part of PlayScene);
        //so, i just disable the necessary gameobjects
        if(this.scene.isPaused("PlayScene")){ this.scene.resume("PlayScene"); }
        //lock buttons and cards (remove interactivity)
        this.playScene.gameplayUI.gameplayButtons.forEach(btn=>{
            this.playScene.inputLock.disableOne(btn.hitArea);
        })
        
        //make each portal glow
        this.closedPortals.portalContainers.forEach((container, i)=>{
            if(container.length){
                const card = container.list[0];
                applyGlowEffect({
                    scene: this,
                    child: card,
                    index: container.getData("index"),
                    color: {r: 255, g: 0, b: 255 },
                    isLast: true,
                    onCompleteCallback: null
                })
            }
        })
        
        //Decide whether to return to TurnEnded/TurnComplete after BACK button had been pressed
        if(this.registry.get("TurnWasCompleted") === "yes"){
            this.returnToTurnCompleteScene();
        }
        else if(this.registry.get("TurnWasCompleted") === "no"){
            this.returnToTurnEndedScene();
        }
        else{
            console.log("turn was nada")
        }
        this.selectAnotherAnomaly();
        this.showPortalCardInfo();
    }
    
    update(time, delta){
        //update the button and anomaly card info
        if(this.closedPortals){
            this.closedPortals.selectButton.updateFontSize(0.75);
            Object.values(this.closedPortals.buttons).forEach(btn=>{
                btn.label.setFontSize(this.closedPortals.selectButton.currentFontSize);
                btn.changePosition();
            })
            this.portalTextbox.displayCardInfo(delta);
        }
        

    }
}