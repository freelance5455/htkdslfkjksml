import { BaseScene } from "./BaseScene.js";
import { eventEmitter } from "../events/EventEmitter.js";
import domUI from "../ui/domUIManager.js";

export class GameOverScene extends BaseScene {
    constructor(config) {
        super("GameOverScene", config);
        this.config = config;
    }
    
    create() {
        domUI.clear();
        
        this.dom = domUI.show(`
            <div class="game-over-screen">

                <div class="game-over-content">

                    <h1 class="game-over-title">
                        Game Over
                    </h1>

                    <p class="game-over-message">
                        Your game has ended.
                    </p>

                    <button
                        id="gameOverMenuBtn"
                        class="game-over-btn"
                    >
                        Menu
                    </button>

                </div>

            </div>
        `);
        
        this.initEvents();
    }
    
    initEvents() {
        const menuBtn = this.dom.querySelector(
            "#gameOverMenuBtn"
        );
        
        menuBtn.addEventListener("click", () => {
            eventEmitter.emit("GameOverToMenu");
        }, { once: true });
        
        eventEmitter.off("GameOverToMenu");
        
        eventEmitter.once("GameOverToMenu", () => {
            this.registry.remove("gamePaused");
            this.shutdown();
            this.scene.start("MenuScene");
        });
    }
    
    shutdown() {
        domUI.clear();
    }
}