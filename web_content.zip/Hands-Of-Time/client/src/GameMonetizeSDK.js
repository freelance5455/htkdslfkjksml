// src/GameMonetizeSDK.js

/**
 * GameMonetize SDK Loader & Wrapper
 * Handles loading the GameMonetize SDK and provides safe ad display calls.
 */
const DEBUG = false; // set to true for debugging

function log(...args) {
    if (DEBUG) console.log(...args);
}

class GameMonetizeSDK {
  constructor() {
    this.sdkReady = false;
    this.sdkLoaded = false;
    // Optional: silence GameMonetize-specific spam
    const originalLog = console.log;
    console.log = function (...args) {
      if (args[0]?.includes?.("GameMonetize.com")) return;
      originalLog.apply(console, args);
    };

    this.loadSDK();
  }

  loadSDK() {
    // Only load once
    if (this.sdkLoaded) return;
    this.sdkLoaded = true;

    window.SDK_OPTIONS = {
      gameId: "hg5xh7vy5wmte6v1g0k3302tqe40j47s",
      onEvent: (a) => {
        switch (a.name) {
          case "SDK_GAME_PAUSE":
            log("GameMonetize: Game paused for ad.");
            if (this.onPause) this.onPause();
            break;
          case "SDK_GAME_START":
            log("GameMonetize: Ad finished, resuming game.");
            if (this.onResume) this.onResume();
            break;
          case "SDK_READY":
            log("GameMonetize SDK ready ✅");
            this.sdkReady = true;
            if (this.onReady) this.onReady();
            break;
          case "SDK_ERROR":
            console.error("GameMonetize SDK error ❌");
            if (this.onError) this.onError();
            break;
        }
      },
    };

    // Inject SDK script if not already present
    (function (a, b, c) {
      const d = a.getElementsByTagName(b)[0];
      if (!a.getElementById(c)) {
        const s = a.createElement(b);
        s.id = c;
        s.src = "https://api.gamemonetize.com/sdk.js";
        d.parentNode.insertBefore(s, d);
      }
    })(document, "script", "gamemonetize-sdk");
  }

  /**
   * Show a rewarded ad (or banner if rewarded unavailable)
   */
  showRewardedAd() {
    if (!this.sdkReady) {
      console.warn("GameMonetize SDK not ready yet — using fallback");
      return Promise.resolve(false);
    }

    return new Promise((resolve) => {
      try {
        log("GameMonetize: Showing ad...");
        window.sdk.showBanner();

        // Simulate rewarded behavior since GameMonetize banners aren't interactive
        setTimeout(() => {
          log("GameMonetize: Ad completed.");
          resolve(true);
        }, 5000);
      } catch (err) {
        error("Error showing GameMonetize ad:", err);
        resolve(false);
      }
    });
  }
}

// Create a singleton instance for global reuse
const gameMonetize = new GameMonetizeSDK();