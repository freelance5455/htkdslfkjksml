export const tutorialSteps = [
    {text: 
        [
            "Greetings, adventurer! You're about to embark on a journey through the fabric of time!\n",
            "Here's a quick guide to walk you through the game timeline.",
        ],
    action: "welcome"
        
    },
    {text: 
        [
            "You have a sole objective: solve Time Anomalies.\n",
            "You can find the current Anomaly at the center of the screen. To resolve it, you must use specific card combinations using the cards in the Deck. \n",
            "Tap on the anomaly for more info and click next when you're done."
        ],
    action: "anomaly"
        
    },
    {text: 
        [
            "This is the Deck.\n",
            "You can draw a card from there or swap a card from your Hand with another in the Deck."
        ],
    action: "deck"
        
    },
    {text: 
        [
            "This is the Hand section.\n",
            "You have been dealt 5 cards from the Deck. Each card has specific attributes. Tap on a card for more info about it."
        ],
    action: "hand-tap"
        
    },
    {text: 
        [
            "You can also re-arrange the cards in your Hand to your liking. Simply drag and drop",
        ],
    action: "hand-drag"
    },
    {text: 
        [
            "Here is the Resolve button.\n",
            "A red Resolve button means you can start clicking on the cards in your Hand to resolve current Anomaly. \n",
            "Tap on it once to activate it. Once activated, its color becomes red.",
        ],
    action: "resolve"
    },
    {text: 
        [
            "You are handed a scroll containing the objectives that must be completed before resolving an Anomaly.",
        ],
    action: "scroll"
    },
    {text: 
        [
            "This is the Progress section.\n",
            "Use it to track the last eight (8) cards that you have played in the current turn."
        ],
    action: "progress"
    },
    {text: 
        [
            "This is the Rewards section.\n",
            "Draw Points show how many times you can draw from the deck. You can earn more by resolving anomalies."
        ],
    action: "rewards"
    },
    {text: 
        [
            "Tap anywhere in this section to pause the game.\n"
        ],
    action: "pause game"
        
    },
    {text: 
        [
            "You can always revisit this tutorial from the Menu Scene.\n",
            "Meanwhile, try not to mess much with the timeline. May your paradoxes be few and your victories be many!\n"
        ],
    action: "final message"
        
    },
    
   
];