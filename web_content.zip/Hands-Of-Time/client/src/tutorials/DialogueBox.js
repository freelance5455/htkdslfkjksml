// DialogueBox.js
// A simple dialogue box with typewriter effect for Phaser 3
// Emits "lineComplete" and "dialogueEnd" events

export class DialogueBox extends Phaser.Events.EventEmitter {
  constructor(scene, rect, contents) {
      super(); // enable event system
        
      this.scene = scene;
      this.rect = rect;
      //set font sizes
      this.setFontSize();
      
      //create background rect
      this.bgGraphics = this.scene.add.graphics({lineStyle: {width: 10, color: 0x210190}});
      this.bgGraphics.clear();
      this.bgGraphics.strokeRect(this.rect.x, this.rect.y, this.rect.width, this.rect.height);
      
      this.box = scene.add.rectangle(this.rect.x, this.rect.y, this.rect.width, this.rect.height, 0xffffff, 0.85).setOrigin(0).setDepth(1000);
      this.nextBtn = scene.add.text(this.rect.x + this.rect.width - 80, this.rect.y + this.rect.height - 70, "⏭️", 
          { fontSize: this.nextBtnFontSize}).setOrigin(0).setDepth(1001);
      //add text
      this.paddingX = 15;
      this.paddingY = 5;
      
      //event emitter
      this.box.setInteractive({useHandcursor: true}).on("pointerdown", ()=>{
          this.emit('dialogueEnd');
          this.finishDialogue();
      })
      
      this.contents = contents;
      
      this.text = scene.add.text(this.rect.x + this.paddingX, this.rect.y + this.paddingY, "", 
          { fontSize: this.textFontSize,
            fontFamily: "myOtherFont",
            color: "black",
            //align: "justify",
            lineSpacing: this.lineSpacing,
            wordWrap: {width: this.rect.width - this.paddingX*2},
           // stroke: "#210190",
           // strokeThickness: 3
          }
              
          ).setOrigin(0).setDepth(1000);
       
        //variables
        this.charIndex = 0;
        this.lineIndex = 0;
        this.isTyping = false;
        this.isSkipped = false;
  }
  
    start(){
        this.charIndex = 0;
        this.lineIndex = 0;
        this.isTyping = true;
        this.typeNextDialogue();
    }
    
    type(){
        this.text.setText(this.text.text + this.contents[this.lineIndex][this.charIndex])
        this.charIndex++;
    }
    goToNextLine(){
         this.charIndex = 0;
         this.lineIndex++;
         this.emit('lineComplete');
    }
    typeNextDialogue(){
        this.box.setInteractive({useHandcursor: true});
        this.text.setText("");
        this.typeWriterEvent = this.scene.time.addEvent({
            delay: 30,
            loop: true,
            callback: ()=>{
                //type the first line
                if(this.charIndex < this.contents[this.lineIndex]?.length){
                     this.type();
                }
                //once reached the end of the first line, go to the next line and type it
                else{
                    if(this.lineIndex < this.contents.length-1){
                        this.goToNextLine();
                        this.type();
                    }
                    //once reached the end of the last line, alert done
                    else{
                        this.typeWriterEvent.remove();
                        this.emit("dialogueEnd");
                        return;
                  }
              }
               
            }
        })
    }
  
  finishDialogue(){
      this.text.text = "";
      this.isTyping = false;
      this.isSkipped = true;
      this.typeWriterEvent.remove();
      let completeDialogue = "";
      this.contents.forEach((content, i)=>{
          completeDialogue+= content;
      })
     this.text.setText(completeDialogue);
     this.box.disableInteractive();
  }
  
  setAbove(overlay){
      if(overlay&& overlay.depth){
          this.bgGraphics.depth = overlay.depth+1;
          this.box.depth = overlay.depth+1;
          this.text.depth = overlay.depth+1;
          this.nextBtn.depth = overlay.depth+1;
      }
  }
  setFontSize(){
        if(screen.width < 800){
            this.textFontSize = 20 + "px";
            this.nextBtnFontSize = 40 + "px";
            this.lineSpacing = 8;
        }
        else if(screen.width < 1200){ 
            this.textFontSize = 23 + "px";
            this.nextBtnFontSize = 50 + "px";
            this.lineSpacing = 18;
        }
        else{
            this.textFontSize = 30+"px";
            this.nextBtnFontSize = 60+"px"; 
            this.lineSpacing = 28;
        } 
    }  
  resize(width, height){
      this.rect.width = width;
      this.rect.height = height;
      this.bgGraphics.clear();
      this.bgGraphics.strokeRect(this.scene.config.width/2 - width/2, this.rect.y, width, height);
  }
  reposition(x, y, overlay){
      this.setAbove(overlay);
      this.rect.x = x;
      this.rect.y = y;
      //bg boundingBox
      this.bgGraphics.clear();
      this.bgGraphics.strokeRect(x, y, this.rect.width, this.rect.height);
      this.box.setPosition(x, y);
      this.text.setPosition(x+this.paddingX, y+this.paddingY);
      this.nextBtn.setPosition(x + this.rect.width - 80, y + this.rect.height - 70)
  }
  resizeAndReposition(width, height, x, y){
    this.rect.width = width;
    this.rect.height = height;
    this.rect.x = x;
    this.rect.y = y;
    this.bgGraphics.clear();
    this.bgGraphics.strokeRect(x, y, width, height);
  }
}