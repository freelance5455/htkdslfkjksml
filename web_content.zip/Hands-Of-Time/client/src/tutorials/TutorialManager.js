// TutorialManager.js

import { tutorialSteps } from './TutorialSteps.js';
import { DialogueBox } from './DialogueBox.js';
import { CircularHighlight, RectangularHighlight } from "../utils/VisualCue.js";
import { InputLock } from '../utils/InputLock.js';

export class TutorialManager extends Phaser.Events.EventEmitter {
    constructor(scene) {
        super();
        this.scene = scene;
        this.steps = tutorialSteps;
        this.currentStepIndex = 0;
        this.dialogueBox = null;
        this.inputLock = null;
        this.isRunning = false;
        this.waitingForClick = false;
        
        this.spotlight = null;
        this.start();
    }

    start() {
        this.isRunning = true;
        this.inputLock = new InputLock(this.scene); // Lock everything
        this.showCurrentStep();
    }

    showCurrentStep() {
        if (this.currentStepIndex >= this.steps.length) {
            this.endTutorial();
            return;
        }

        const step = this.steps[this.currentStepIndex];

        // Setup dialogue box if not already present
        if (!this.dialogueBox) {
            this.width = this.scene.config.width*0.4;
            this.height = this.scene.config.height*0.4;
            this.x = this.scene.config.width/2 - this.width/2;
            this.y = 20;
            this.dialogueBox = new DialogueBox(this.scene, 
                new Phaser.Geom.Rectangle(this.x, this.y, this.width, this.height), 
                step.text
            );
        } else {
            this.dialogueBox.contents = step.text;
        }

        // Start typing
        this.dialogueBox.start();

        // Wait for typewriter to finish
        this.dialogueBox.once("dialogueEnd", () => {
            this.waitingForClick = true;

            // Attach click handler to box
            this.dialogueBox.nextBtn.setInteractive({useHandcursor: true}).once("pointerdown", () => {
                if (this.waitingForClick) {
                    this.waitingForClick = false;
                    this.handleNextActionAfter(step.action);
                }
            });
        });
    }

    handleNextActionAfter(action) {
        const { anomalyPile,
                deck,
                hand,
                handRect,
                resolveBtn,
                progressSectionGraphics, turnProgressRect,
                displayHeaders, displayTexts, displayRects,
                rightSection,
                rewardsSectionRect 
            
        } = this.scene.gameplayUI;
        
        switch (action) {
            case "welcome":
                
                //highlight anomaly container
                this.spotlight = new CircularHighlight(this.scene, anomalyPile, { });
                anomalyPile.container.setDepth(this.spotlight.depth+1)
                //change the dialogue box's position so it doesn't cover the anomaly
                this.dialogueBox.reposition(20, this.scene.config.height/2 - this.dialogueBox.rect.height/2, this.spotlight);
                //compel user to click on the spotlighted anomaly
                //to achieve this, remove interaction on the next button until user clicks the anomaly
                this.dialogueBox.nextBtn.setVisible(false);
                this.inputLock.enableOne(anomalyPile.container.list[0]);
                anomalyPile.container.list[0].on("pointerdown", ()=>{
                    this.spotlight.destroy(true);
                    this.dialogueBox.nextBtn.setVisible(true).once("pointerdown", ()=>{
                        this.inputLock.disableOne(anomalyPile.container.list[0]);
                        anomalyPile.container.setDepth(this.spotlight.targetOriginalDepth);
                    })
                })
                break;

            case "anomaly":{
                //highlight deck container
                this.spotlight = new CircularHighlight(this.scene, deck, { });
                deck.container.setDepth(this.spotlight.depth+1);
                this.dialogueBox.nextBtn.once("pointerdown", ()=> {
                    this.spotlight.destroy(true);
                    deck.container.setDepth(this.spotlight.targetOriginalDepth);
                })
                break;
            }
            case "deck":{
                this.spotlight = new RectangularHighlight(this.scene, handRect, {spotlightColor: 0xffff00})
                this.dialogueBox.reposition(
                    this.scene.config.width/2-this.dialogueBox.rect.width/2,
                    this.scene.config.height/2-this.dialogueBox.rect.height/2, 
                    this.spotlight);
                hand.containers.forEach(c=> c.setDepth(this.spotlight.depth+1))
                this.dialogueBox.nextBtn.once("pointerdown", ()=> {
                    //more code, like restore depth
                    hand.containers.forEach(c=> c.setDepth(this.spotlight.targetOriginalDepth))
                    this.spotlight.destroy(true);
                })
                break;
            }
            case "hand-tap":
                this.dialogueBox.nextBtn.once("pointerdown", ()=> {
                    this.spotlight.destroy(true);
                    //more code, like restore depth
                })
                break;
                
            case "hand-drag":
                this.spotlight = new CircularHighlight(this.scene, resolveBtn.rect, {})
                resolveBtn.graphics.setDepth(this.spotlight.depth+1);
                resolveBtn.label.setDepth(this.spotlight.depth+1);
                this.dialogueBox.nextBtn.once("pointerdown", ()=> {
                    //more code, like restore depth and destroy spotlight
                    resolveBtn.graphics.setDepth(this.spotlight.targetOriginalDepth);
                    resolveBtn.label.setDepth(this.spotlight.targetOriginalDepth);
                    this.spotlight.destroy(true);

                })
                
                break;
                
            case "resolve":{
                
                this.spotlight = new CircularHighlight(this.scene, anomalyPile.scroll.scrollRect, {});
                anomalyPile.scroll.top.setDepth(this.spotlight.depth+1);
                anomalyPile.scroll.body.setDepth(this.spotlight.depth+1);
                anomalyPile.scroll.bottom.setDepth(this.spotlight.depth+1);
                anomalyPile.scroll.contents.forEach(c=> c.setDepth(this.spotlight.depth+1) );
                anomalyPile.scroll.checkboxGraphics.forEach(c=> c.setDepth(this.spotlight.depth+1) );
                
                this.dialogueBox.reposition(this.scene.config.width/2 - this.dialogueBox.rect.width/2, 20, this.spotlight);
                this.dialogueBox.nextBtn.once("pointerdown", ()=> {
                    //more code, like restore depth and destroy spotlight
                    anomalyPile.scroll.top.setDepth(this.spotlight.targetOriginalDepth);
                    anomalyPile.scroll.body.setDepth(this.spotlight.targetOriginalDepth);
                    anomalyPile.scroll.bottom.setDepth(this.spotlight.targetOriginalDepth);
                    anomalyPile.scroll.contents.forEach(c=> c.setDepth(this.spotlight.targetOriginalDepth) );
                    anomalyPile.scroll.checkboxGraphics.forEach(c=> c.setDepth(this.spotlight.targetOriginalDepth) );

                    this.spotlight.destroy(true);

                })
                break;
            }
            case "scroll":
                this.spotlight = new RectangularHighlight(this.scene, turnProgressRect, {})
                this.dialogueBox.reposition(this.scene.config.width/2 - this.dialogueBox.rect.width/2, 80, this.spotlight);
                progressSectionGraphics.forEach(g=> g.setDepth(this.spotlight.depth+1) );
               // turnProgressHeader.setDepth(this.spotlight.depth+1)
                this.dialogueBox.nextBtn.once("pointerdown", ()=> {
                    //more code, like restore depth and destroy spotlight
                    progressSectionGraphics.forEach(g=> g.setDepth(this.spotlight.targetOriginalDepth) );
                 //   turnProgressHeader.setDepth(this.spotlight.targetOriginalDepth);
                    this.spotlight.destroy(true);

                })
                break;
            case "progress":{
                this.spotlight = new RectangularHighlight(this.scene, rewardsSectionRect, {})
                this.dialogueBox.reposition(this.scene.config.width/2 - this.dialogueBox.rect.width/2, 150, this.spotlight);
                    displayHeaders.forEach(h=> h.setDepth(this.spotlight.depth+1) );
                    displayTexts.forEach(t=> t.setDepth(this.spotlight.depth+1) );
                    this.dialogueBox.nextBtn.once("pointerdown", ()=> {
                        //more code, like restore depth and destroy spotlight
                        displayHeaders.forEach(h=> h.setDepth(this.spotlight.targetOriginalDepth) );
                        displayTexts.forEach(t=> t.setDepth(this.spotlight.targetOriginalDepth) );
                        
                        this.spotlight.destroy(true);
                })
                break;
            }
            case "rewards":{
                this.spotlight = new RectangularHighlight(this.scene, rightSection, {})
                this.dialogueBox.reposition(this.scene.config.width/2 - this.dialogueBox.rect.width/2, this.scene.config.height/2 - this.dialogueBox.rect.height/2, this.spotlight);
                this.dialogueBox.nextBtn.once("pointerdown", ()=> {
                        this.spotlight.destroy(true);
                })
                break;
            }
            case "pause game":{
                this.spotlight = new RectangularHighlight(this.scene, {x:-2000,y:-2000,width:0,height:0}, {})
                this.dialogueBox.reposition(this.scene.config.width/2 - this.dialogueBox.rect.width/2, this.scene.config.height/2 - this.dialogueBox.rect.height/2, this.spotlight);
                this.dialogueBox.nextBtn.once("pointerdown", ()=> {
                        this.spotlight.destroy(true);
                })
                break;
            }
            case "final message":
                // Final step — no special action needed
                break;

            default:
                console.warn("Unknown tutorial action:", action);
        }

        // Delay a bit before moving on
        this.scene.time.delayedCall(200, () => {
            this.nextStep();
        });
    }

    nextStep() {
        this.currentStepIndex++;
        this.showCurrentStep();
    }

    endTutorial() {
        //this.inputLock.enableAll();
        this.isRunning = false;
        if (this.dialogueBox) {
            this.dialogueBox.bgGraphics.destroy();
            this.dialogueBox.box.destroy();
            this.dialogueBox.text.destroy();
            this.dialogueBox.nextBtn.destroy();
        }
        this.emit("tutorialComplete");
    }
}