// visualCue.js

// 🔵 Circle spotlight/highlight
export class CircularHighlight extends Phaser.GameObjects.Container {
    constructor(scene, target, options = {}) {
        super(scene, 0, 0);
        scene.add.existing(this);
        this.targetOriginalDepth = target.depth || 0;
        const radius = (target.width > target.height) ? target.width/1.3 : target.height/1.3;  
        const darknessColor = options.darknessColor || 0x000000;  
        const darknessAlpha = options.darknessAlpha ?? 0.8;  
        const offsetX = target.width&& target.width/2 || 0;  
        const offsetY = target.height&& target.height/2 || 0;  
    
        // Darkness overlay  
        const darkness = scene.add.rectangle(  
            scene.scale.width / 2,  
            scene.scale.height / 2,  
            scene.scale.width,  
            scene.scale.height,  
            darknessColor,  
            darknessAlpha  
        );  
        darkness.setScrollFactor(0);  
        this.add(darkness);  
    
        // Target position  
        let x, y;  
        if (target?.getCenter) {  
            const c = target.getCenter();  
            x = c.x;  
            y = c.y + offsetY;  
        } else {  
            x = target.x + target.width/2;  
            y = target.y + target.height/2;  
        }  
    
        // Spotlight "hole"  
        const spotlight = scene.add.circle(x, y, radius, 0xffffff, 0.5); 
        this.add(spotlight);  
    
        // Ensure erase only affects darkness, not the world  
        this.setBlendMode(Phaser.BlendModes.NORMAL);  
    
        this.setDepth(9998); // Overlay layer
        
        
    } 
    destroy(fromScene) {  
        super.destroy(fromScene);  
    }

}

// 🟦 Rectangle spotlight/highlight
export class RectangularHighlight extends Phaser.GameObjects.Container {
    constructor(scene, target, options = {}) {
        super(scene, 0, 0);
        scene.add.existing(this);
        this.targetOriginalDepth =  options.depth || (target.depth ? target.depth : 0);
        const width = target.width || 150;
        const height = target.height || 100;
        const darknessColor = options.darknessColor || 0x000000;
        const darknessAlpha = options.darknessAlpha ?? 0.8;
        const offsetX = target.width*0.05;
        const offsetY = target.height*0.05;
        const spotlightColor = options.spotlightColor || 0xffffff;
        // Darkness overlay
        const darkness = scene.add.rectangle(
            scene.scale.width / 2,
            scene.scale.height / 2,
            scene.scale.width,
            scene.scale.height,
            darknessColor,
            darknessAlpha
        );
        darkness.setScrollFactor(0);
        this.add(darkness);

        // Target position
        let x = target.x, y = target.y;
        

        // Highlight "hole"
        const highlight = scene.add.rectangle(x - offsetX, y - offsetY, width + offsetX*2, height+offsetY*2, spotlightColor, 0.5).setOrigin(0);
        this.add(highlight);
        this.setBlendMode(Phaser.BlendModes.NORMAL);

        this.setDepth(9998); // Overlay layer
    }

    destroy(fromScene) {
        super.destroy(fromScene);
    }
}