export class InputLock {
    constructor(scene) {
        this.scene = scene;
        this.disabledObjects = new Set(); // use Set to avoid duplicates
    }

    // Disable input for a single game object
    disableOne(target) {
        if (target && target.disableInteractive) {
            target.disableInteractive();
            this.disabledObjects.add(target);
        }
    }

    // Disable input for multiple game objects (array)
    disableMultiple(targets) {
        if (!Array.isArray(targets)) return;
        targets.forEach(target => {
            if (target && target.disableInteractive) {
                target.disableInteractive();
                this.disabledObjects.add(target);
            }
        });
    }

    // Enable input for a single game object
    enableOne(target) {
        if (target && target.setInteractive) {
            target.setInteractive({ useHandCursor: true });
            this.disabledObjects.delete(target);
        }
    }

    // Enable input for multiple game objects (array)
    enableMultiple(targets) {
        if (!Array.isArray(targets)) return;
        targets.forEach(target => {
            if (target && target.setInteractive) {
                target.setInteractive({ useHandCursor: true });
                this.disabledObjects.delete(target);
            }
        });
    }

    // Disable input for ALL active game objects in the scene
    disableAll() {
        this.scene.children.list.forEach(obj => {
            if (obj.input && obj.disableInteractive) {
                obj.disableInteractive();
                this.disabledObjects.add(obj);
            }
        });
    }

    // Re-enable input for all previously disabled objects
    enableAll() {
        this.disabledObjects.forEach(obj => {
            if (obj && obj.setInteractive) {
                obj.setInteractive({ useHandCursor: true });
            }
        });

        // clear after restoring
        this.disabledObjects.clear();
    }
}