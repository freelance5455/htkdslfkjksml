export function applyGlowEffect({
    scene,
    child,
    index = 0,
    color = { r: 255, g: 255, b: 255 },
    isLast = false,
    onCompleteCallback = null
}) {
    // --- Keep visual position when changing origin ---
    if(!child.getData("originAdjusted")){
        child.x += child.getData("rect").width * 0.5;
        child.y += child.getData("rect").height * 0.5;
        child.setData("originAdjusted", true);
    }
    
    child.setOrigin(0.5);

    // Save original scale
    const baseScaleX = child.scaleX;
    const baseScaleY = child.scaleY;

    // Start smaller + invisible
    child.setAlpha(0);
    child.setScale(baseScaleX * 0.8, baseScaleY * 0.8);

    // 🌟 Fade + Grow-in (combined)
    if(!child || !child.getData('rect') || !child.getData('rect').width)return;
    scene.tweens.add({
        targets: child,
        alpha: 1,
        displayWidth: child.getData("rect").width*0.9,
        displayHeight: child.getData("rect").height*0.9,
        duration: 500,
        delay: index * 100,
        ease: "Back.Out",
        onComplete: () => {
            // After the intro tween finishes, start the glow effects

            // 🎨 Color pulse
            if(!child || !child.getData('rect') || !child.getData('rect').width)return;
            const colorTween = scene.tweens.addCounter({
                from: 0,
                to: 100,
                duration: 1000,
                yoyo: true,
                repeat: -1,
                ease: "Sine.InOut",
                delay: index * 100,
                onUpdate: tween => {
                    const value = Math.floor(tween.getValue());
                    const g = Phaser.Math.Clamp(color.g - value, 0, 255);
                    child.setTint(Phaser.Display.Color.GetColor(color.r, g, color.b));
                }
            });

            // 🌬️ Breathing scale
            const scaleTween = scene.tweens.add({
                targets: child,
                displayWidth: child.getData("rect").width*1,
                displayHeight: child.getData("rect").height*1,
                duration: 1200,
                yoyo: true,
                repeat: -1,
                ease: "Sine.InOut",
                delay: index * 100
            });

            child._glowTweens = [colorTween, scaleTween];

            if (isLast && onCompleteCallback) {
                onCompleteCallback();
            }
        }
    });
}


export function removeGlowEffect(scene, child, index = 0, isLast = false, onCompleteCallback = null) {
    // Stop glow tweens
    if(!child) return;
    if (child._glowTweens) {
        child._glowTweens.forEach(tween => {
            if (tween && tween.stop) tween.stop();
        });
        child._glowTweens = null;
    }

    // 🌙 Fade & shrink out with stagger
    scene.tweens.add({
        targets: child,
        alpha: { from: 1, to: 0 },
        scale: { from: child.scale, to: 0.8 },
        duration: 400,
        delay: index * 100,
        ease: "Sine.InOut",
        onComplete: () => {
            child.clearTint();
            child.setScale(1);
            child.setAlpha(1); // reset for next time

            if (isLast && onCompleteCallback) {
                onCompleteCallback();
            }
        }
    });
}