/**
 * Returns all non-empty Phaser 3 containers from an array.
 * 
 * @param {Phaser.GameObjects.Container[]} containers - Array of containers
 * @returns {Phaser.GameObjects.Container[]} - Filtered non-empty containers
 */
export function getNonEmptyContainers(containers) {
    if (!Array.isArray(containers)) return [];

    return containers.filter(container => 
        container instanceof Phaser.GameObjects.Container &&
        container.list &&
        container.list.length > 0
    );
}
export function getEmptyContainers(containers) {
    if (!Array.isArray(containers)) return [];

    return containers.filter(container => 
        container instanceof Phaser.GameObjects.Container &&
        container.list &&
        container.list.length === 0
    );
}