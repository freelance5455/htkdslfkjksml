// js/managers/ProgressManager.js

import NotificationModal from "../ui/NotificationModal.js";

export default class ProgressManager {
    static STORAGE_KEY = "quizProgress";

    static SUBJECTS = [
        "biology",
        "chemistry",
        "physics",
        "mathematics"
    ];

    static FORMATS = [
        "MCQ",
        "True/False",
        "Theory",
        "Practical"
    ];

    static GAME_MODES = [
        "LocalPassPlay",
        "LocalWiFi",
        "Online"
    ];

    static DIFFICULTIES = [
        "easy",
        "medium",
        "hard",
        "extreme"
    ];

    static LEVELS = [
        "Primary 1",
        "Primary 2",
        "Primary 3",
        "Primary 4",
        "Primary 5",
        "Primary 6",

        "JSS1",
        "JSS2",
        "JSS3",

        "SSS1",
        "SSS2",
        "SSS3",

        "100-Level",
        "200-Level",
        "300-Level",
        "400-Level"
    ];

    /* ==========================================================
       INITIALIZATION
    ========================================================== */

    static initialize() {
        if (!localStorage.getItem(this.STORAGE_KEY)) {
            localStorage.setItem(
                this.STORAGE_KEY,
                JSON.stringify(this.createDefaultData())
            );

            return;
        }

        /*
            Existing users may already have quizProgress
            saved before Game Mode progress was added.

            Make sure the new Game Mode structure exists
            without destroying their existing Test Mode data.
        */

        const data = JSON.parse(
            localStorage.getItem(this.STORAGE_KEY)
        );

        let changed = false;

        if (!data.gameModeProgress) {
            data.gameModeProgress =
                this.createGameModeProgress();

            changed = true;
        } else {
            const repaired =
                this.ensureGameModeProgress(
                    data.gameModeProgress
                );

            if (repaired) {
                changed = true;
            }
        }

        if (!Array.isArray(data.quizAttempts)) {
            data.quizAttempts = [];
            changed = true;
        }

        if (changed) {
            localStorage.setItem(
                this.STORAGE_KEY,
                JSON.stringify(data)
            );
        }
    }

    static getData() {
        this.initialize();

        return JSON.parse(
            localStorage.getItem(
                this.STORAGE_KEY
            )
        );
    }

    static saveData(data) {
        localStorage.setItem(
            this.STORAGE_KEY,
            JSON.stringify(data)
        );
    }

    /* ==========================================================
       DEFAULT DATA
    ========================================================== */

    static createDefaultData() {
        return {
            /*
                TEST MODE
            */

            overallSummary:
                this.createOverallSummary(),

            subjectMastery:
                this.createSubjectMastery(),

            gradeLevelMastery:
                this.createGradeLevelMastery(),

            streak: {
                current: 0,
                longest: 0,
                lastStudyDate: null
            },

            timeStats: {
                totalStudyTime: 0,
                longestSession: 0
            },

            quizAttempts: [],

            /*
                GAME MODE
            */

            gameModeProgress:
                this.createGameModeProgress()
        };
    }

    /* ==========================================================
       TEST MODE BUILDERS
    ========================================================== */

    static createMetric() {
        return {
            quizzesTaken: 0,
            questionsAnswered: 0,
            correctAnswers: 0,
            totalMarksObtained: 0,
            totalMarksPossible: 0,
            accuracy: 0,
            timeSpent: 0
        };
    }

    static createOverallSummary() {
        const summary = {};

        this.FORMATS.forEach(format => {
            summary[format] = {
                quizzesCompleted: 0,
                questionsAnswered: 0,
                correctAnswers: 0,
                totalMarksObtained: 0,
                totalMarksPossible: 0,
                accuracy: 0,
                studyTime: 0,
                topicsCovered: []
            };
        });

        return summary;
    }

    static createSubjectMastery() {
        const data = {};

        this.SUBJECTS.forEach(subject => {
            data[subject] = {};

            this.FORMATS.forEach(format => {
                data[subject][format] =
                    this.createMetric();
            });
        });

        return data;
    }

    static createGradeLevelMastery() {
        const data = {};

        this.LEVELS.forEach(level => {
            data[level] = {};

            this.SUBJECTS.forEach(subject => {
                data[level][subject] = {};

                this.FORMATS.forEach(format => {
                    data[level][subject][format] =
                        this.createMetric();
                });
            });
        });

        return data;
    }

    /* ==========================================================
       GAME MODE BUILDERS
    ========================================================== */

    static createGameModeMetric() {
        return {
            gamesCompleted: 0,

            totalQuestions: 0,
            correctAnswers: 0,
            wrongAnswers: 0,
            timedOut: 0,

            accuracy: 0,

            firstPlace: 0,
            secondPlace: 0,
            thirdPlace: 0,
            otherPlaces: 0,

            totalPlayers: 0,

            positionDistribution: {}
        };
    }

    static createGameModeProgress() {
        const data = {};

        this.GAME_MODES.forEach(gameMode => {
            data[gameMode] = {
                ...this.createGameModeMetric(),

                byDifficulty: {},

                byFormat: {},

                recentGames: []
            };

            this.DIFFICULTIES.forEach(difficulty => {
                data[gameMode].byDifficulty[difficulty] =
                    this.createGameModeMetric();
            });

            data[gameMode].byFormat.MCQ =
                this.createGameModeMetric();

            data[gameMode].byFormat["True/False"] =
                this.createGameModeMetric();
        });

        return data;
    }

    static ensureGameModeProgress(gameModeProgress) {
        let changed = false;

        this.GAME_MODES.forEach(gameMode => {
            if (!gameModeProgress[gameMode]) {
                gameModeProgress[gameMode] =
                    {
                        ...this.createGameModeMetric(),
                        byDifficulty: {},
                        byFormat: {},
                        recentGames: []
                    };

                changed = true;
            }

            const mode =
                gameModeProgress[gameMode];

            /*
                Repair main metric fields.
            */

            const defaultMetric =
                this.createGameModeMetric();

            for (const key of Object.keys(defaultMetric)) {
                if (
                    mode[key] === undefined ||
                    mode[key] === null
                ) {
                    mode[key] =
                        Array.isArray(
                            defaultMetric[key]
                        )
                            ? [
                                ...defaultMetric[key]
                            ]
                            : typeof defaultMetric[key] ===
                              "object"
                                ? {
                                    ...defaultMetric[key]
                                }
                                : defaultMetric[key];

                    changed = true;
                }
            }

            /*
                Difficulty buckets.
            */

            if (!mode.byDifficulty) {
                mode.byDifficulty = {};
                changed = true;
            }

            this.DIFFICULTIES.forEach(
                difficulty => {
                    if (
                        !mode.byDifficulty[
                            difficulty
                        ]
                    ) {
                        mode.byDifficulty[
                            difficulty
                        ] =
                            this.createGameModeMetric();

                        changed = true;
                    }
                }
            );

            /*
                Question format buckets.
            */

            if (!mode.byFormat) {
                mode.byFormat = {};
                changed = true;
            }

            [
                "MCQ",
                "True/False"
            ].forEach(format => {
                if (!mode.byFormat[format]) {
                    mode.byFormat[format] =
                        this.createGameModeMetric();

                    changed = true;
                }
            });

            /*
                Recent game history.
            */

            if (
                !Array.isArray(
                    mode.recentGames
                )
            ) {
                mode.recentGames = [];
                changed = true;
            }
        });

        return changed;
    }

    /* ==========================================================
       TEST MODE - RECORD OBJECTIVE QUIZ
    ========================================================== */

    static recordObjectiveQuiz(attempt) {
        this.initialize();

        const data =
            this.getData();

        const subject =
            attempt.subject;

        const rawLevel =
            attempt.level;

        const grade =
            attempt.grade || "";

        const level =
            this.normalizeLevel(
                rawLevel,
                grade
            );

        const format =
            this.normalizeFormat(
                attempt.format
            );

        const questions =
            attempt.questions || [];

        const totalQuestions =
            attempt.totalQuestions ||
            questions.length ||
            0;

        const attempted =
            questions.filter(
                q =>
                    q.selectedIndex !==
                        null &&
                    q.selectedIndex !==
                        undefined
            ).length;

        const correct =
            questions.filter(
                q =>
                    q.selectedIndex ===
                    q.answerIndex
            ).length;

        const wrong =
            attempted - correct;

        const skipped =
            totalQuestions -
            attempted;

        const timeSpent =
            attempt.timeSpent || 0;

        const accuracy =
            this.calculateAccuracy(
                format,
                correct,
                totalQuestions,
                null
            );

        const enrichedAttempt = {
            id:
                this.generateAttemptId(),

            timestamp:
                Date.now(),

            type:
                "objective",

            subject,
            level,
            grade,
            format,

            totalQuestions,
            attempted,
            correct,
            wrong,
            skipped,

            accuracy,
            timeSpent,

            topics:
                attempt.topics || []
        };

        data.quizAttempts.push(
            enrichedAttempt
        );

        this.updateStatistics(
            data,
            enrichedAttempt
        );

        this.saveData(data);
    }

    /* ==========================================================
       TEST MODE - RECORD THEORY QUIZ
    ========================================================== */

    static recordTheoryQuiz(attempt) {
        this.initialize();

        const data =
            this.getData();

        const subject =
            attempt.subject;

        const rawLevel =
            attempt.level;

        const grade =
            attempt.grade || "";

        const level =
            this.normalizeLevel(
                rawLevel,
                grade
            );

        const format =
            this.normalizeFormat(
                attempt.format
            );

        const totalQuestions =
            attempt.totalQuestions || 0;

        const totalMarks =
            attempt.totalMarks || 0;

        const correct =
            attempt.correct || 0;

        const timeSpent =
            attempt.timeSpent || 0;

        const wrong =
            Math.max(
                totalMarks - correct,
                0
            );

        const skipped = 0;

        const accuracy =
            this.calculateAccuracy(
                format,
                correct,
                totalQuestions,
                totalMarks
            );

        const enrichedAttempt = {
            id:
                this.generateAttemptId(),

            timestamp:
                Date.now(),

            type:
                "theory",

            subject,
            level,
            grade,
            format,

            totalQuestions,
            totalMarks,

            attempted:
                totalQuestions,

            correct,
            wrong,
            skipped,

            accuracy,
            timeSpent,

            topics:
                attempt.topics || []
        };

        data.quizAttempts.push(
            enrichedAttempt
        );

        this.updateStatistics(
            data,
            enrichedAttempt
        );

        this.saveData(data);
    }

    /* ==========================================================
       TEST MODE - PRACTICAL
    ========================================================== */

    static recordPracticalQuiz(attempt) {
        this.initialize();

        const data =
            this.getData();

        const subject =
            attempt.subject;

        const rawLevel =
            attempt.level;

        const grade =
            attempt.grade || "";

        const level =
            this.normalizeLevel(
                rawLevel,
                grade
            );

        const format =
            "Practical";

        const totalQuestions =
            attempt.totalQuestions || 0;

        const totalMarks =
            attempt.totalMarks || 0;

        const correct =
            attempt.correct || 0;

        const timeSpent =
            attempt.timeSpent || 0;

        const wrong =
            Math.max(
                totalMarks - correct,
                0
            );

        const skipped =
            attempt.skipped || 0;

        const accuracy =
            this.calculateAccuracy(
                format,
                correct,
                totalQuestions,
                totalMarks
            );

        const enrichedAttempt = {
            id:
                this.generateAttemptId(),

            timestamp:
                Date.now(),

            type:
                "practical",

            subject,
            level,
            grade,
            format,

            totalQuestions,
            totalMarks,

            attempted:
                Math.max(
                    totalQuestions -
                        skipped,
                    0
                ),

            correct,
            wrong,
            skipped,

            accuracy,
            timeSpent,

            topics:
                attempt.topics || []
        };

        data.quizAttempts.push(
            enrichedAttempt
        );

        this.updateStatistics(
            data,
            enrichedAttempt
        );

        this.saveData(data);
    }

    /* ==========================================================
       GAME MODE - LOCAL PASS & PLAY
    ========================================================== */

    static recordLocalPassPlayResult(result) {
        this.initialize();

        const data =
            this.getData();

        if (
            !data.gameModeProgress
        ) {
            data.gameModeProgress =
                this.createGameModeProgress();
        }

        this.ensureGameModeProgress(
            data.gameModeProgress
        );

        const gameMode =
            "LocalPassPlay";

        const mode =
            data.gameModeProgress[
                gameMode
            ];

        const difficulty =
            this.normalizeGameDifficulty(
                result.difficulty
            );

        const format =
            this.normalizeGameModeFormat(
                result.questionFormat
            );

        const attemptedQuestions =
            Array.isArray(
                result.attemptedQuestions
            )
                ? result.attemptedQuestions
                : [];

        const totalQuestions =
            Number(
                result.totalQuestions
            ) ||
            attemptedQuestions.length ||
            0;

        const correctAnswers =
            attemptedQuestions.filter(
                attempt =>
                    attempt.isCorrect === true
            ).length;

        const timedOut =
            attemptedQuestions.filter(
                attempt =>
                    attempt.timedOut === true
            ).length;

        const answered =
            attemptedQuestions.filter(
                attempt =>
                    attempt.selectedIndex !==
                        null &&
                    attempt.selectedIndex !==
                        undefined &&
                    attempt.selectedIndex !==
                        -1
            ).length;

        const wrongAnswers =
            Math.max(
                answered -
                    correctAnswers,
                0
            );

        const accuracy =
            totalQuestions === 0
                ? 0
                : Math.round(
                    (
                        correctAnswers /
                        totalQuestions
                    ) *
                    100
                );

        const players =
            Array.isArray(
                result.players
            )
                ? result.players
                : [];

        const rankings =
            Array.isArray(
                result.rankings
            )
                ? result.rankings
                : [];

        /*
            Update overall Local Pass & Play
            statistics.
        */

        this.updateGameModeMetric(
            mode,
            {
                totalQuestions,
                correctAnswers,
                wrongAnswers,
                timedOut,
                accuracy,
                playerCount:
                    players.length,
                rankings
            },
            false
        );

        /*
            Update difficulty statistics.
        */

        if (
            mode.byDifficulty[
                difficulty
            ]
        ) {
            this.updateGameModeMetric(
                mode.byDifficulty[
                    difficulty
                ],
                {
                    totalQuestions,
                    correctAnswers,
                    wrongAnswers,
                    timedOut,
                    accuracy,
                    playerCount:
                        players.length,
                    rankings
                },
                false
            );
        }

        /*
            Update question-format statistics.
        */

        if (
            mode.byFormat[
                format
            ]
        ) {
            this.updateGameModeMetric(
                mode.byFormat[
                    format
                ],
                {
                    totalQuestions,
                    correctAnswers,
                    wrongAnswers,
                    timedOut,
                    accuracy,
                    playerCount:
                        players.length,
                    rankings
                },
                false
            );
        }

        /*
            Save a compact history entry.

            No player identity is stored here because
            Local Pass & Play is device/game based.
        */

        mode.recentGames.unshift({
            id:
                this.generateGameAttemptId(),

            timestamp:
                Date.now(),

            difficulty,

            questionFormat:
                format,

            totalQuestions,

            correctAnswers,

            wrongAnswers,

            timedOut,

            accuracy,

            playerCount:
                players.length,

            positionDistribution:
                this.createPositionDistribution(
                    rankings
                ),

            rounds:
                Number(
                    result.rounds
                ) || 0,

            subjects:
                Array.isArray(
                    result.subjects
                )
                    ? [
                        ...result.subjects
                    ]
                    : []
        });

        this.limitRecentGames(
            mode
        );

        this.saveData(data);
    }

    /* ==========================================================
       GAME MODE - MULTIPLAYER
    ========================================================== */

    static recordMultiplayerResult(result) {
        this.initialize();

        const data =
            this.getData();

        if (
            !data.gameModeProgress
        ) {
            data.gameModeProgress =
                this.createGameModeProgress();
        }

        this.ensureGameModeProgress(
            data.gameModeProgress
        );

        const gameMode =
            this.normalizeGameMode(
                result.gameMode
            );

        /*
            Multiplayer progress must have a
            valid player ID.

            This prevents another player's result
            from accidentally being saved as ours.
        */

        const playerId =
            result.playerId ||
            null;

        if (!playerId) {
            console.warn(
                "ProgressManager: Multiplayer result ignored because playerId is missing."
            );

            return;
        }

        const rankings =
            Array.isArray(
                result.rankings
            )
                ? result.rankings
                : [];

        const myResult =
            rankings.find(
                player =>
                    String(
                        player.id
                    ) ===
                    String(
                        playerId
                    )
            );

        if (!myResult) {
            console.warn(
                "ProgressManager: Current player was not found in multiplayer rankings."
            );

            return;
        }

        const difficulty =
            this.normalizeGameDifficulty(
                result.difficulty
            );

        const format =
            this.normalizeGameModeFormat(
                result.questionFormat
            );

        const allAttempts =
            Array.isArray(
                result.attemptedQuestions
            )
                ? result.attemptedQuestions
                : [];

        /*
            Prefer attempts belonging to this player.

            Different backend versions may use
            different names for the player ID,
            so support the common forms.
        */

        const playerAttempts =
            allAttempts.filter(
                attempt => {
                    const attemptPlayerId =
                        attempt.playerId ??
                        attempt.player?.id ??
                        attempt.player?.playerId;

                    if (
                        attemptPlayerId ===
                            undefined ||
                        attemptPlayerId ===
                            null
                    ) {
                        return false;
                    }

                    return (
                        String(
                            attemptPlayerId
                        ) ===
                        String(
                            playerId
                        )
                    );
                }
            );

        /*
            If the backend does not attach a player ID
            to individual attempts, use the player's
            score only as a fallback for correct answers.

            This keeps the system functional without
            pretending that unidentified attempts belong
            to the current user.
        */

        let correctAnswers =
            playerAttempts.filter(
                attempt =>
                    attempt.isCorrect === true ||
                    attempt.correct === true
            ).length;

        let timedOut =
            playerAttempts.filter(
                attempt =>
                    attempt.timedOut === true
            ).length;

        let totalQuestions =
            playerAttempts.length;

        if (
            totalQuestions === 0
        ) {
            totalQuestions =
                this.getPlayerQuestionCount(
                    result,
                    myResult
                );

            correctAnswers =
                this.getPlayerCorrectCount(
                    result,
                    myResult
                );

            timedOut = 0;
        }

        const wrongAnswers =
            Math.max(
                totalQuestions -
                    correctAnswers -
                    timedOut,
                0
            );

        const accuracy =
            totalQuestions === 0
                ? 0
                : Math.round(
                    (
                        correctAnswers /
                        totalQuestions
                    ) *
                    100
                );

        const position =
            Number(
                myResult.rank
            ) || 0;

        const playerCount =
            rankings.length;

        const mode =
            data.gameModeProgress[
                gameMode
            ];

        /*
            Update overall multiplayer statistics.
        */

        this.updateGameModeMetric(
            mode,
            {
                totalQuestions,
                correctAnswers,
                wrongAnswers,
                timedOut,
                accuracy,
                playerCount,
                position
            },
            true
        );

        /*
            Update difficulty statistics.
        */

        if (
            mode.byDifficulty[
                difficulty
            ]
        ) {
            this.updateGameModeMetric(
                mode.byDifficulty[
                    difficulty
                ],
                {
                    totalQuestions,
                    correctAnswers,
                    wrongAnswers,
                    timedOut,
                    accuracy,
                    playerCount,
                    position
                },
                true
            );
        }

        /*
            Update question-format statistics.
        */

        if (
            mode.byFormat[
                format
            ]
        ) {
            this.updateGameModeMetric(
                mode.byFormat[
                    format
                ],
                {
                    totalQuestions,
                    correctAnswers,
                    wrongAnswers,
                    timedOut,
                    accuracy,
                    playerCount,
                    position
                },
                true
            );
        }

        /*
            Save the user's recent multiplayer games.
        */

        mode.recentGames.unshift({
            id:
                this.generateGameAttemptId(),

            timestamp:
                Date.now(),

            difficulty,

            questionFormat:
                format,

            totalQuestions,

            correctAnswers,

            wrongAnswers,

            timedOut,

            accuracy,

            position,

            playerCount,

            score:
                Number(
                    myResult.score
                ) || 0,

            rounds:
                Number(
                    result.rounds
                ) || 0,

            subjects:
                Array.isArray(
                    result.subjects
                )
                    ? [
                        ...result.subjects
                    ]
                    : []
        });

        this.limitRecentGames(
            mode
        );

        this.saveData(data);
    }

    /* ==========================================================
       GAME MODE METRIC UPDATE
    ========================================================== */

    static updateGameModeMetric(
        metric,
        stats,
        userSpecific
    ) {
        metric.gamesCompleted += 1;

        metric.totalQuestions +=
            Number(
                stats.totalQuestions
            ) || 0;

        metric.correctAnswers +=
            Number(
                stats.correctAnswers
            ) || 0;

        metric.wrongAnswers +=
            Number(
                stats.wrongAnswers
            ) || 0;

        metric.timedOut +=
            Number(
                stats.timedOut
            ) || 0;

        metric.totalPlayers +=
            Number(
                stats.playerCount
            ) || 0;

        /*
            Recalculate cumulative accuracy.
        */

        metric.accuracy =
            metric.totalQuestions === 0
                ? 0
                : Math.round(
                    (
                        metric.correctAnswers /
                        metric.totalQuestions
                    ) *
                    100
                );

        /*
            Position handling.

            Local Pass & Play:
                userSpecific = false
                Every player in the game contributes
                to the position distribution.

            Multiplayer:
                userSpecific = true
                Only the current user's position
                is recorded.
        */

        if (userSpecific) {
            this.recordPosition(
                metric,
                Number(
                    stats.position
                ) || 0
            );

            return;
        }

        const rankings =
            Array.isArray(
                stats.rankings
            )
                ? stats.rankings
                : [];

        rankings.forEach(
            player => {
                this.recordPosition(
                    metric,
                    Number(
                        player.rank
                    ) || 0
                );
            }
        );
    }

    /* ==========================================================
       POSITION STATISTICS
    ========================================================== */

    static recordPosition(
        metric,
        position
    ) {
        if (
            !position ||
            position < 1
        ) {
            return;
        }

        const key =
            String(position);

        if (
            !metric.positionDistribution[
                key
            ]
        ) {
            metric.positionDistribution[
                key
            ] = 0;
        }

        metric.positionDistribution[
            key
        ] += 1;

        if (position === 1) {
            metric.firstPlace += 1;
        } else if (
            position === 2
        ) {
            metric.secondPlace += 1;
        } else if (
            position === 3
        ) {
            metric.thirdPlace += 1;
        } else {
            metric.otherPlaces += 1;
        }
    }

    static createPositionDistribution(
        rankings
    ) {
        const distribution = {};

        if (
            !Array.isArray(
                rankings
            )
        ) {
            return distribution;
        }

        rankings.forEach(
            player => {
                const position =
                    Number(
                        player.rank
                    ) || 0;

                if (
                    position < 1
                ) {
                    return;
                }

                const key =
                    String(
                        position
                    );

                if (
                    !distribution[
                        key
                    ]
                ) {
                    distribution[
                        key
                    ] = 0;
                }

                distribution[
                    key
                ] += 1;
            }
        );

        return distribution;
    }

    /* ==========================================================
       MULTIPLAYER QUESTION FALLBACKS
    ========================================================== */

    static getPlayerQuestionCount(
        result,
        playerResult
    ) {
        /*
            If a player result already contains
            answered/correct information, use it.
        */

        const candidates = [
            playerResult?.questionsAnswered,
            playerResult?.totalQuestions,
            result?.playerQuestionsAnswered
        ];

        for (
            const value of candidates
        ) {
            if (
                Number.isFinite(
                    Number(value)
                ) &&
                Number(value) > 0
            ) {
                return Number(value);
            }
        }

        /*
            Fall back to the game's total questions.
        */

        return (
            Number(
                result.totalQuestions
            ) || 0
        );
    }

    static getPlayerCorrectCount(
        result,
        playerResult
    ) {
        const candidates = [
            playerResult?.correctAnswers,
            playerResult?.correct,
            result?.playerCorrectAnswers
        ];

        for (
            const value of candidates
        ) {
            if (
                Number.isFinite(
                    Number(value)
                ) &&
                Number(value) >= 0
            ) {
                return Number(value);
            }
        }

        /*
            The current multiplayer scoring system
            awards points for correct answers.

            Use score / 5 only as a final fallback,
            because MultiplayerPlayScene currently
            does not expose a per-player question
            count directly.
        */

        const score =
            Number(
                playerResult?.score
            );

        if (
            Number.isFinite(score) &&
            score >= 0
        ) {
            return Math.floor(
                score / 5
            );
        }

        return 0;
    }

    /* ==========================================================
       GAME MODE NORMALIZATION
    ========================================================== */

    static normalizeGameMode(
        gameMode
    ) {
        const value =
            String(
                gameMode || ""
            )
                .trim()
                .toLowerCase();

        switch (value) {
            case "localpassplay":
            case "local-pass-play":
            case "local pass play":
                return "LocalPassPlay";

            case "localwifi":
            case "local-wifi":
            case "local wi-fi":
            case "local wifi":
                return "LocalWiFi";

            case "online":
            case "online multiplayer":
            case "onlinemultiplayer":
                return "Online";

            default:
                return "LocalWiFi";
        }
    }

    static normalizeGameDifficulty(
        difficulty
    ) {
        const value =
            String(
                difficulty || ""
            )
                .trim()
                .toLowerCase();

        if (
            this.DIFFICULTIES.includes(
                value
            )
        ) {
            return value;
        }

        return "easy";
    }

    static normalizeGameModeFormat(
        format
    ) {
        const value =
            String(
                format || ""
            )
                .trim()
                .toLowerCase();

        if (
            value ===
                "true-or-false" ||
            value ===
                "true/false" ||
            value ===
                "true false" ||
            value ===
                "tf" ||
            value ===
                "truefalse"
        ) {
            return "True/False";
        }

        return "MCQ";
    }

    /* ==========================================================
       RECENT GAME HISTORY
    ========================================================== */

    static limitRecentGames(
        mode
    ) {
        const limit = 20;

        if (
            !Array.isArray(
                mode.recentGames
            )
        ) {
            mode.recentGames = [];
            return;
        }

        mode.recentGames =
            mode.recentGames.slice(
                0,
                limit
            );
    }

    /* ==========================================================
       TEST MODE STATISTICS
    ========================================================== */

    static updateStatistics(
        data,
        attempt
    ) {
        this.updateOverallSummary(
            data,
            attempt
        );

        this.updateSubjectMastery(
            data,
            attempt
        );

        this.updateGradeLevelMastery(
            data,
            attempt
        );

        this.updateStreak(
            data
        );

        this.updateTimeStats(
            data,
            attempt
        );
    }

    static normalizeLevel(
        level,
        grade
    ) {
        switch (level) {
            case "primary":
                return `Primary ${grade}`;

            case "junior_secondary":
                return `JSS${grade}`;

            case "senior_secondary":
                return `SSS${grade}`;

            case "university":
                return `${grade}-Level`;

            default:
                return level;
        }
    }

    static normalizeFormat(
        format
    ) {
        const value =
            String(
                format || ""
            )
                .trim()
                .toLowerCase();

        const formatMap = {
            mcq:
                "MCQ",

            "multiple choice":
                "MCQ",

            "multiple-choice":
                "MCQ",

            tf:
                "True/False",

            "true/false":
                "True/False",

            "true false":
                "True/False",

            truefalse:
                "True/False",

            theory:
                "Theory",

            practical:
                "Practical"
        };

        return (
            formatMap[value] ||
            null
        );
    }

    /* ==========================================================
       OVERALL SUMMARY
    ========================================================== */

    static updateOverallSummary(
        data,
        attempt
    ) {
        const summary =
            data.overallSummary;

        const format =
            this.normalizeFormat(
                attempt.format
            );

        if (
            !format ||
            !summary[format]
        ) {
            return;
        }

        const isObjective =
            format === "MCQ" ||
            format === "True/False";

        summary[format]
            .quizzesCompleted += 1;

        if (isObjective) {
            summary[format]
                .questionsAnswered +=
                attempt.totalQuestions ||
                0;

            summary[format]
                .correctAnswers +=
                attempt.correct ||
                0;
        } else {
            summary[format]
                .questionsAnswered +=
                attempt.totalQuestions ||
                0;

            summary[format]
                .totalMarksObtained +=
                attempt.correct ||
                0;

            summary[format]
                .totalMarksPossible +=
                attempt.totalMarks ||
                0;
        }

        summary[format]
            .studyTime +=
            attempt.timeSpent ||
            0;

        const topics =
            attempt.topics || [];

        for (
            const topic of topics
        ) {
            if (
                !summary[format]
                    .topicsCovered
                    .includes(
                        topic
                    )
            ) {
                summary[format]
                    .topicsCovered
                    .push(
                        topic
                    );
            }
        }

        if (isObjective) {
            const q =
                summary[format]
                    .questionsAnswered;

            const c =
                summary[format]
                    .correctAnswers;

            summary[format]
                .accuracy =
                q === 0
                    ? 0
                    : Math.round(
                        (
                            c / q
                        ) *
                        100
                    );
        } else {
            const obtained =
                summary[format]
                    .totalMarksObtained;

            const possible =
                summary[format]
                    .totalMarksPossible;

            summary[format]
                .accuracy =
                possible === 0
                    ? 0
                    : Math.round(
                        (
                            obtained /
                            possible
                        ) *
                        100
                    );
        }

        let totalQuestions = 0;
        let totalCorrect = 0;
        let totalStudyTime = 0;

        for (
            const f of this.FORMATS
        ) {
            totalQuestions +=
                summary[f]
                    .questionsAnswered;

            totalCorrect +=
                summary[f]
                    .correctAnswers;

            totalStudyTime +=
                summary[f]
                    .studyTime;
        }

        data.overallTotals = {
            totalQuestionsAnswered:
                totalQuestions,

            totalCorrectAnswers:
                totalCorrect,

            totalStudyTime
        };
    }

    /* ==========================================================
       SUBJECT MASTERY
    ========================================================== */

    static updateSubjectMastery(
        data,
        attempt
    ) {
        const subject =
            attempt.subject;

        const format =
            this.normalizeFormat(
                attempt.format
            );

        if (
            !subject ||
            !format
        ) {
            return;
        }

        if (
            !data.subjectMastery[
                subject
            ]
        ) {
            data.subjectMastery[
                subject
            ] = {};

            for (
                const f of this.FORMATS
            ) {
                data.subjectMastery[
                    subject
                ][f] =
                    this.createMetric();
            }
        }

        const metric =
            data.subjectMastery[
                subject
            ][format];

        if (!metric) {
            return;
        }

        metric.quizzesTaken += 1;

        const isObjective =
            format === "MCQ" ||
            format === "True/False";

        if (isObjective) {
            metric.questionsAnswered +=
                attempt.totalQuestions ||
                0;

            metric.correctAnswers +=
                attempt.correct ||
                0;
        } else {
            metric.questionsAnswered +=
                attempt.totalQuestions ||
                0;

            metric.totalMarksObtained +=
                attempt.correct ||
                0;

            metric.totalMarksPossible +=
                attempt.totalMarks ||
                0;
        }

        metric.timeSpent +=
            attempt.timeSpent ||
            0;

        if (isObjective) {
            metric.accuracy =
                this.calculateAccuracy(
                    format,
                    metric.correctAnswers,
                    metric.questionsAnswered
                );
        } else {
            metric.accuracy =
                metric.totalMarksPossible ===
                    0
                    ? 0
                    : Math.round(
                        (
                            metric.totalMarksObtained /
                            metric.totalMarksPossible
                        ) *
                        100
                    );
        }
    }

    /* ==========================================================
       GRADE / LEVEL MASTERY
    ========================================================== */

    static updateGradeLevelMastery(
        data,
        attempt
    ) {
        const level =
            attempt.level;

        const subject =
            attempt.subject;

        const format =
            this.normalizeFormat(
                attempt.format
            );

        if (
            !level ||
            !subject ||
            !format
        ) {
            return;
        }

        const isObjective =
            format === "MCQ" ||
            format === "True/False";

        const levelStore =
            data.gradeLevelMastery;

        if (
            !levelStore[level]
        ) {
            levelStore[level] = {};

            for (
                const s of this.SUBJECTS
            ) {
                levelStore[level][s] =
                    {};

                for (
                    const f of this.FORMATS
                ) {
                    levelStore[level][s][f] =
                        this.createMetric();
                }
            }
        }

        if (
            !levelStore[level][subject]
        ) {
            levelStore[level][subject] =
                {};

            for (
                const f of this.FORMATS
            ) {
                levelStore[level][subject][f] =
                    this.createMetric();
            }
        }

        const metric =
            levelStore[level][subject][format];

        if (!metric) {
            return;
        }

        metric.quizzesTaken += 1;

        if (isObjective) {
            metric.questionsAnswered +=
                attempt.totalQuestions ||
                0;

            metric.correctAnswers +=
                attempt.correct ||
                0;
        } else {
            metric.questionsAnswered +=
                attempt.totalQuestions ||
                0;

            metric.totalMarksObtained +=
                attempt.correct ||
                0;

            metric.totalMarksPossible +=
                attempt.totalMarks ||
                0;
        }

        metric.timeSpent +=
            attempt.timeSpent ||
            0;

        if (isObjective) {
            metric.accuracy =
                this.calculateAccuracy(
                    format,
                    metric.correctAnswers,
                    metric.questionsAnswered
                );
        } else {
            metric.accuracy =
                metric.totalMarksPossible ===
                    0
                    ? 0
                    : Math.round(
                        (
                            metric.totalMarksObtained /
                            metric.totalMarksPossible
                        ) *
                        100
                    );
        }
    }

    /* ==========================================================
       STREAK
    ========================================================== */

    static updateStreak(
        data
    ) {
        const streak =
            data.streak;

        const today =
            new Date();

        today.setHours(
            0,
            0,
            0,
            0
        );

        const lastDate =
            streak.lastStudyDate
                ? new Date(
                    streak.lastStudyDate
                )
                : null;

        if (lastDate) {
            lastDate.setHours(
                0,
                0,
                0,
                0
            );
        }

        if (!lastDate) {
            streak.current = 1;
            streak.longest = 1;
            streak.lastStudyDate =
                today.toISOString();

            return;
        }

        const diffTime =
            today - lastDate;

        const diffDays =
            Math.floor(
                diffTime /
                (
                    1000 *
                    60 *
                    60 *
                    24
                )
            );

        if (
            diffDays === 0
        ) {
            return;
        }

        if (
            diffDays === 1
        ) {
            streak.current += 1;
        } else {
            streak.current = 1;
        }

        if (
            streak.current >
            streak.longest
        ) {
            streak.longest =
                streak.current;
        }

        streak.lastStudyDate =
            today.toISOString();
    }

    /* ==========================================================
       TIME
    ========================================================== */

    static updateTimeStats(
        data,
        attempt
    ) {
        const stats =
            data.timeStats;

        const time =
            attempt.timeSpent ||
            0;

        stats.totalStudyTime +=
            time;

        if (
            time >
            stats.longestSession
        ) {
            stats.longestSession =
                time;
        }
    }

    /* ==========================================================
       HELPERS
    ========================================================== */

    static calculateAccuracy(
        format,
        correct,
        totalQuestions,
        totalMarks
    ) {
        const isObjective =
            format === "MCQ" ||
            format === "True/False";

        if (isObjective) {
            if (
                !totalQuestions ||
                totalQuestions === 0
            ) {
                return 0;
            }

            return Math.round(
                (
                    correct /
                    totalQuestions
                ) *
                100
            );
        }

        const marks =
            totalMarks || 0;

        if (
            marks === 0
        ) {
            return 0;
        }

        return Math.round(
            (
                correct /
                marks
            ) *
            100
        );
    }

    static formatTime(
        seconds
    ) {
        if (!seconds) {
            return "0m";
        }

        const h =
            Math.floor(
                seconds / 3600
            );

        const m =
            Math.floor(
                (
                    seconds % 3600
                ) / 60
            );

        return h > 0
            ? `${h}h ${m}m`
            : `${m}m`;
    }

    static generateAttemptId() {
        return (
            "att_" +
            Date.now() +
            "_" +
            Math.floor(
                Math.random() *
                9999
            )
        );
    }

    static generateGameAttemptId() {
        return (
            "game_" +
            Date.now() +
            "_" +
            Math.floor(
                Math.random() *
                9999
            )
        );
    }
}