export class RegularCardTextbox {
    constructor(scene) {
        this.card = undefined;
        this.scene = scene;
        this.config = scene.config;
        
        this.currentFontSize = 25;
        
        this.paddingX = 8;
        this.paddingY = 8;
        
        this.backgroundGraphics = this.scene.add.graphics().setDepth(0);
        this.titleGraphics = this.scene.add.graphics().setDepth(0);
        this.suitValueGraphics = this.scene.add.graphics().setDepth(0);
        this.attributeGraphics = this.scene.add.graphics().setDepth(0);
        
        this.setFontSize();
        
        this.titleLabel = scene.add.text(0, 0, "", {
            fontSize: this.titleFontSize,
            fontFamily: "myOtherFont",
            color: "white"
        }).setOrigin(0).setDepth(11);
        
        this.suitValueLabel = scene.add.text(0, 0, "", {
            fontSize: this.suitValueFontSize,
            fontFamily: "myOtherFont",
            color: "white"
        }).setOrigin(0).setDepth(11);
        
        this.attributeLabel = scene.add.text(0, 0, "", {
            fontSize: this.attributeFontSize,
            fontFamily: "myOtherOtherFont",
            color: "black"
        }).setOrigin(0).setDepth(11);
        
        this.infoDisplayTimer = 2000;
        this.infoDisplayInterval = 2000;
    }
    
    setFontSize() {
        if (this.config.width < 800) {
            this.titleFontSize = "35px";
            this.suitValueFontSize = "25px";
            this.attributeFontSize = "25px";
        }
        else if (this.config.width < 1200) {
            this.titleFontSize = "40px";
            this.suitValueFontSize = "30px";
            this.attributeFontSize = "30px";
        }
        else {
            this.titleFontSize = "45px";
            this.suitValueFontSize = "35px";
            this.attributeFontSize = "35px";
        }
    }
    
    getSuitValue(card) {
        const suit = card.getData("suit");
        const value = card.getData("value");
        
        const suitNames = {
            HEART: "Hearts",
            SPADE: "Spades",
            CLUB: "Clubs",
            DIAMOND: "Diamonds"
        };
        
        const valueNames = {
            1: "Ace",
            11: "Jack",
            12: "Queen",
            13: "King"
        };
        
        const valueName = valueNames[value] || value;
        const suitName = suitNames[suit] || suit;
        
        return `${valueName} of ${suitName}`;
    }
    
    setPosition(card) {
        this.card = card;
        
        const gameplayUI = this.scene.gameplayUI;
        
        if (!gameplayUI || !gameplayUI.middleSection) {
            return this;
        }
        
        const middle = gameplayUI.middleSection;
        
        this.width = middle.width * 0.60;
        
        const isPortrait = this.config.height > this.config.width;
        
        if (isPortrait) {
            this.x = middle.centerX - this.width / 2;
            this.y = middle.top + 5;
        }
        else {
            const resolved = gameplayUI.resolvedPile;
            
            this.x = middle.centerX - this.width / 2;
            this.y = resolved.rect.bottom + 10;
        }
        
        this.infoDisplayTimer = 0;
        
        return this;
    }
    
    show(card) {
        this.setPosition(card);
        this.changeText(card);
        
        return this;
    }
    
    hide() {
        this.backgroundGraphics.clear();
        this.titleGraphics.clear();
        this.suitValueGraphics.clear();
        this.attributeGraphics.clear();
        
        this.titleLabel.setVisible(false).setActive(false);
        this.suitValueLabel.setVisible(false).setActive(false);
        this.attributeLabel.setVisible(false).setActive(false);
        
        return this;
    }
    
    changeText(card) {
        this.titleLabel.setVisible(true).setActive(true);
        this.suitValueLabel.setVisible(true).setActive(true);
        this.attributeLabel.setVisible(true).setActive(true);
        
        this.titleLabel.setDepth(card.depth + 2);
        this.suitValueLabel.setDepth(card.depth + 2);
        this.attributeLabel.setDepth(card.depth + 2);
        
        this.titleLabel.setText(
            card.getData("title") || card.name || ""
        );
        
        this.suitValueLabel.setText(
            this.getSuitValue(card)
        );
        
        this.attributeLabel.setText(
            card.getData("attributes") || ""
        );
        
        this.attributeLabel.setWordWrapWidth(
            this.width - this.paddingX * 2,
            true
        );
        
        this.attributeLabel.setAlign("center");
        this.attributeLabel.setPadding(5, 5, 5, 5);
        
        this.titleLabel.setPosition(
            this.x + this.width / 2 - this.titleLabel.width / 2,
            this.y + this.paddingY
        );
        
        this.suitValueLabel.setPosition(
            this.x + this.width / 2 - this.suitValueLabel.width / 2,
            this.titleLabel.y + this.titleLabel.height + this.paddingY
        );
        
        this.attributeLabel.setPosition(
            this.x + this.width / 2 - this.attributeLabel.width / 2,
            this.suitValueLabel.y + this.suitValueLabel.height + this.paddingY * 2
        );
        
        const totalHeight =
            this.paddingY +
            this.titleLabel.height +
            this.paddingY +
            this.suitValueLabel.height +
            this.paddingY * 2 +
            this.attributeLabel.height +
            this.paddingY;
        
        this.backgroundGraphics.setDepth(card.depth + 1);
        this.titleGraphics.setDepth(card.depth + 1);
        this.suitValueGraphics.setDepth(card.depth + 1);
        this.attributeGraphics.setDepth(card.depth + 1);
        
        this.setBackgroundColor(
            this.x,
            this.y,
            this.width,
            totalHeight,
            0x000000,
            this.backgroundGraphics
        );
        
        this.setBackgroundColor(
            this.titleLabel.x - this.paddingX,
            this.titleLabel.y - this.paddingY / 2,
            this.titleLabel.width + this.paddingX * 2,
            this.titleLabel.height + this.paddingY,
            0x00aa00,
            this.titleGraphics
        );
        
        this.setBackgroundColor(
            this.suitValueLabel.x - this.paddingX,
            this.suitValueLabel.y - this.paddingY / 2,
            this.suitValueLabel.width + this.paddingX * 2,
            this.suitValueLabel.height + this.paddingY,
            0x303030,
            this.suitValueGraphics
        );
        
        this.setBackgroundColor(
            this.x + this.paddingX,
            this.attributeLabel.y,
            this.width - this.paddingX * 2,
            this.attributeLabel.height,
            0xffffff,
            this.attributeGraphics
        );
        
        return this;
    }
    
    align() {
        return this;
    }
    
    setBackgroundColor(x, y, width, height, color, graphics) {
        graphics.clear();
        
        graphics.fillStyle(color, 1);
        graphics.fillRoundedRect(x, y, width, height, 8);
        
        graphics.lineStyle(2, 0x303030, 1);
        graphics.strokeRoundedRect(x, y, width, height, 8);
        
        return this;
    }
    
    displayCardInfo(delta) {
        if (this.infoDisplayTimer < this.infoDisplayInterval) {
            this.infoDisplayTimer += delta;
        }
        else {
            this.infoDisplayTimer = this.infoDisplayInterval;
            this.hide();
        }
    }
}