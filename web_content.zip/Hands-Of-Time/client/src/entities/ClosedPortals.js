import { Button } from "../entities/Button.js";
import { applyGlowEffect } from "../utils/GlowEffect.js";
class DialogueBox {
    constructor(scene) {
        this.scene = scene;
        this.config = scene.config;

        const { PreloadScene, PlayScene } = scene.game.scene.keys;

        this.preloadScene = this.scene;
        this.playScene = PlayScene;

        this.depth = 0;

        this.containerGraphics = scene.add.graphics().setDepth(this.depth);

        this.portals = [];
        this.shown = false;

        this.container = this.createContainer(0x0000aa);

        this.createPortals();

        this.buttons = this.createButtons(this.container);

        this.showButtons();

        this.contents = [];

        Object.values(this.buttons).forEach(btn => {
            this.contents.push(btn.hitArea);
        });
    }

    getLayout() {
        const gameWidth = this.scene.scale.gameSize.width;
        const gameHeight = this.scene.scale.gameSize.height;

        const size = Math.min(gameWidth, gameHeight) * 0.95;

        const x = (gameWidth - size) * 0.5;
        const y = (gameHeight - size) * 0.5;

        const cardDimensions = this.playScene.getCardDimensions();
        const cardAspectRatio =
            cardDimensions.originalWidth / cardDimensions.originalHeight;

        const marginX = size * 0.05;
        const marginY = 10;

        const rows = 3;
        const cols = 3;

        const buttonHeight = size * 0.08;
        const buttonPaddingY = 10;
        const buttonAreaHeight = buttonHeight + buttonPaddingY;

        const paddingY = 20;

        const availablePortalHeight =
            size -
            marginY * 2 -
            buttonAreaHeight -
            20;

        const sectionHeight = Math.min(
            size * 0.28,
            (availablePortalHeight - paddingY * (rows - 1)) / rows
        );

        const sectionWidth = sectionHeight * cardAspectRatio;

        const availablePortalWidth =
            size - marginX * 2;

        const paddingX =
            (availablePortalWidth - sectionWidth * cols) /
            (cols - 1);

        return {
            x,
            y,
            size,
            marginX,
            marginY,
            rows,
            cols,
            sectionWidth,
            sectionHeight,
            paddingX,
            paddingY,
            buttonHeight,
            buttonPaddingY
        };
    }

    createPortals() {
        this.shown = true;

        const layout = this.getLayout();

        const {
            x,
            y,
            marginX,
            marginY,
            rows,
            cols,
            sectionWidth,
            sectionHeight,
            paddingX,
            paddingY
        } = layout;

        const portalX = x + marginX;
        const portalY = y + marginY;

        this.portalGraphics =
            this.scene.add.graphics()
                .setDepth(this.containerGraphics.depth + 1);

        this.portalRects = [];
        this.hitAreas = [];
        this.portalContainers = [];

        this.portalGraphics.clear();
        this.portalGraphics.lineStyle(3, 0xffffff);
        this.portalGraphics.fillStyle(0x2101aa, 0.7);

        for (let i = 0; i < cols; ++i) {
            for (let j = 0; j < rows; ++j) {
                const index = i * rows + j;

                const rectX =
                    portalX +
                    i * (sectionWidth + paddingX);

                const rectY =
                    portalY +
                    j * (sectionHeight + paddingY);

                const rect = new Phaser.Geom.Rectangle(
                    rectX,
                    rectY,
                    sectionWidth,
                    sectionHeight
                );

                this.portalRects.push(rect);

                this.portalGraphics.strokeRoundedRect(
                    rectX,
                    rectY,
                    sectionWidth,
                    sectionHeight,
                    8
                );

                this.portalGraphics.fillRoundedRect(
                    rectX,
                    rectY,
                    sectionWidth,
                    sectionHeight,
                    8
                );

                const container =
                    this.scene.add.container(
                        rectX,
                        rectY
                    )
                    .setSize(sectionWidth, sectionHeight)
                    .setDepth(this.containerGraphics.depth + 2);

                container.setData({
                    index
                });

                this.portalContainers.push(container);

                const hitArea =
                    this.scene.add.rectangle(
                        rectX,
                        rectY,
                        sectionWidth,
                        sectionHeight,
                        0xff00ff,
                        0.5
                    )
                    .setDepth(0)
                    .setOrigin(0)
                    .disableInteractive({
                        useHandCursor: true
                    });

                this.hitAreas.push(hitArea);
            }
        }

        return this;
    }

    resize() {
    const layout = this.getLayout();
    
    const {
        x,
        y,
        size,
        marginX,
        marginY,
        rows,
        cols,
        sectionWidth,
        sectionHeight,
        paddingX,
        paddingY,
        buttonHeight,
        buttonPaddingY
    } = layout;
    
    this.container.setTo(x, y, size, size);
    
    this.containerGraphics.clear();
    this.containerGraphics.fillStyle(0x0000aa, 0.85);
    this.containerGraphics.fillRoundedRect(x, y, size, size, 30);
    
    const portalX = x + marginX;
    const portalY = y + marginY;
    
    this.portalGraphics.clear();
    this.portalGraphics.lineStyle(3, 0xffffff);
    this.portalGraphics.fillStyle(0x2101aa, 0.7);
    
    for (let i = 0; i < cols; ++i) {
        for (let j = 0; j < rows; ++j) {
            const index = i * rows + j;
            
            const rectX =
                portalX +
                i * (sectionWidth + paddingX);
            
            const rectY =
                portalY +
                j * (sectionHeight + paddingY);
            
            this.portalRects[index].setTo(
                rectX,
                rectY,
                sectionWidth,
                sectionHeight
            );
            
            this.portalGraphics.strokeRoundedRect(
                rectX,
                rectY,
                sectionWidth,
                sectionHeight,
                8
            );
            
            this.portalGraphics.fillRoundedRect(
                rectX,
                rectY,
                sectionWidth,
                sectionHeight,
                8
            );
            
            const portalContainer = this.portalContainers[index];
            
            portalContainer
                .setPosition(rectX, rectY)
                .setSize(sectionWidth, sectionHeight);
            
            this.hitAreas[index]
                .setPosition(rectX, rectY)
                .setSize(sectionWidth, sectionHeight);
            
            portalContainer.list.forEach(card => {
                if (!card || !card.setDisplaySize) {
                    return;
                }
                
                const rect = card.getData("rect");
                
                if (rect) {
                    rect.setTo(
                        rectX,
                        rectY,
                        sectionWidth,
                        sectionHeight
                    );
                }
                
                if (card._glowTweens) {
                    card._glowTweens.forEach(tween => {
                        if (tween && tween.stop) {
                            tween.stop();
                        }
                    });
                    
                    card._glowTweens = null;
                }
                
                card.setDisplaySize(
                    sectionWidth,
                    sectionHeight
                );
                
                card.setPosition(
                    sectionWidth * 0.5,
                    sectionHeight * 0.5
                );
                
                applyGlowEffect({
                    scene: this.scene,
                    child: card,
                    index
                });
            });
        }
    }
    
    const buttonWidth = size * 0.3;
    
    const buttonY =
        y +
        size -
        buttonHeight -
        buttonPaddingY;
    
    const selectRect =
        new Phaser.Geom.Rectangle(
            x + 10,
            buttonY,
            buttonWidth,
            buttonHeight
        );
    
    const backRect =
        new Phaser.Geom.Rectangle(
            x +
            size -
            buttonWidth -
            10,
            buttonY,
            buttonWidth,
            buttonHeight
        );
    
    this.selectButton.graphics.clear();
    this.backButton.graphics.clear();
    
    this.selectButton.rect = selectRect;
    
    this.selectButton.hitArea
        .setPosition(
            selectRect.x,
            selectRect.y
        )
        .setSize(
            selectRect.width,
            selectRect.height
        );
    
    this.selectButton.changePosition();
    
    this.backButton.rect = backRect;
    
    this.backButton.hitArea
        .setPosition(
            backRect.x,
            backRect.y
        )
        .setSize(
            backRect.width,
            backRect.height
        );
    
    this.backButton.changePosition();
    
    this.selectButton.setBackgroundColor(
        0x22aa22,
        0x000000,
        1,
        4,
        1
    );
    
    this.backButton.setBackgroundColor(
        0x22aa22,
        0x000000,
        1,
        4,
        1
    );
    
    return this;
}

    destroy() {
        this.portalGraphics.destroy();
        this.containerGraphics.destroy();

        this.hitAreas.forEach(area => {
            area.destroy();
        });

        Object.values(this.buttons).forEach(button => {
            button.destroy();
        });
    }
}


export class ClosedPortals extends DialogueBox {

    createContainer(
        backgroundColor = 0xff0000,
        alpha = 0.85
    ) {
        const layout = this.getLayout();

        const rect = new Phaser.Geom.Rectangle(
            layout.x,
            layout.y,
            layout.size,
            layout.size
        );

        this.containerGraphics.fillStyle(
            backgroundColor,
            alpha
        );

        this.containerGraphics.fillRoundedRect(
            layout.x,
            layout.y,
            layout.size,
            layout.size,
            30
        );

        return rect;
    }

    createButtons(container) {
        const width = container.width * 0.3;
        const height = container.height * 0.08;

        const paddingX = 10;
        const paddingY = 10;

        const selectBtnRect =
            new Phaser.Geom.Rectangle(
                container.left + paddingX,
                container.bottom - height - paddingY,
                width,
                height
            );

        const backBtnRect =
            new Phaser.Geom.Rectangle(
                container.right - width - paddingX,
                container.bottom - height - paddingY,
                width,
                height
            );

        this.backButton =
            new Button(
                this.scene,
                backBtnRect,
                "BACK"
            );

        this.selectButton =
            new Button(
                this.scene,
                selectBtnRect,
                "SELECT"
            );

        return {
            back: this.backButton,
            select: this.selectButton
        };
    }

    hideButtons() {
        Object.values(this.buttons).forEach(btn => {
            btn.hidePartially();
        });
    }

    showButtons() {
        Object.values(this.buttons).forEach(btn => {
            btn.show(
                0x22aa22,
                0x000000,
                1,
                4,
                1,
                this.depth
            );
        });
    }
}