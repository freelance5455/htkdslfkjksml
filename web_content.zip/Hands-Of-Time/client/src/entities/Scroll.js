export class Scroll{
    constructor(
    scene,
    rect,
    middleSection,
    turnProgressRect
){
    this.scene = scene;
    this.config = scene.config;
    this.rect = rect;
    this.middleSection = middleSection;
    this.turnProgressRect = turnProgressRect;

    this.originalWidth = 10;
    this.originalHeight = 10;
    this.originalX = 0;
    this.originalY = 0;
}
    createScroll() {
    
    this.body =
        this.scene.add.image(
            0,
            0,
            "scrollBody"
        )
        .setTint(0xff00ff)
        .setOrigin(0, 0);
    
    this.top =
        this.scene.add.image(
            0,
            0,
            "scrollEnd"
        )
        .setTint(0xff00ff)
        .setOrigin(0, 0);
    
    this.bottom =
        this.scene.add.image(
            0,
            0,
            "scrollEnd"
        )
        .setTint(0xff00ff)
        .setOrigin(0, 0);
    
    this.marginY = 5;
    
    return this;
}

    
    setSize() {
    
    const isPortrait =
        this.config.height > this.config.width;
    
    this.marginY = 5;
    
    //The scroll is 60% of the
    //section containing the piles.
    this.width =
        this.middleSection.width * 0.60;
    
    this.x =
        this.middleSection.centerX -
        this.width / 2;
    
    //Start directly below the anomaly.
    this.y =
        this.rect.bottom;
    
    //Desired scroll height is 60% of
    //the pile section height.
    const desiredHeight =
        this.middleSection.height * 0.60;
    
    let availableHeight =
        desiredHeight;
    
    //The scroll must not enter the
    //Turn Progress section.
    if (isPortrait && this.turnProgressRect) {
        
        availableHeight =
            Math.min(
                desiredHeight,
                this.turnProgressRect.top -
                this.y -
                this.marginY * 2
            );
    }
    
    else if (!isPortrait) {
        
        availableHeight =
            Math.min(
                desiredHeight,
                this.config.height -
                this.y -
                this.marginY * 2
            );
    }
    
    this.height =
        Math.max(
            availableHeight,
            0
        );
    
    return this;
}
updateObjectivesPosition() {

    if (!this.body || !this.contents) {
        return;
    }

    this.setFontSize();

    this.textX =
        this.body.x +
        this.body.displayWidth * 0.1;

    this.textY =
        this.body.y + 10;

    if (this.headline) {

        this.headline.setFontSize(
            this.headlineFontSize
        );

        this.headline.setPosition(
            this.rect.centerX -
            this.headline.displayWidth / 2,
            this.textY
        );
    }

    if (this.texts) {

        this.texts.forEach(
            (text, index) => {

                text.setFontSize(
                    this.fontSize
                );

                text.setWordWrapWidth(
                    this.body.displayWidth * 0.8
                );

                if (index === 0) {

                    text.setPosition(
                        this.textX,
                        this.headline.y +
                        this.headline.displayHeight +
                        13
                    );

                }
                else {

                    text.setPosition(
                        this.textX,
                        this.texts[index - 1].y +
                        this.texts[index - 1].displayHeight +
                        10
                    );
                }
            }
        );
    }

    if (this.checkboxes && this.checkboxGraphics) {

        this.checkboxes.forEach(
            (rect, index) => {

                const text =
                    this.texts[index];

                if (!text) {
                    return;
                }

                rect.setTo(
                    this.body.x +
                    this.body.displayWidth * 0.9 -
                    5,
                    text.y +
                    text.displayHeight / 2 -
                    this.checkboxHeight / 2,
                    this.checkboxWidth,
                    this.checkboxHeight
                );

                const graphics =
                    this.checkboxGraphics[index];

                if (!graphics) {
                    return;
                }

                graphics.clear();

                if (graphics.checked) {

                    graphics.fillStyle(
                        0x000000
                    );

                    graphics.fillRectShape(
                        rect
                    );
                }
                else {

                    graphics.lineStyle(
                        2,
                        0xffffff
                    );

                    graphics.strokeRectShape(
                        rect
                    );
                }
            }
        );
    }

    return this;
}
    fit() {
    
    const endAspectRatio =
        this.top.displayWidth /
        this.top.displayHeight;
    
    const bodyAspectRatio =
        this.body.displayWidth /
        this.body.displayHeight;
    
    //Set new size of scroll ends.
    this.top.displayWidth =
        this.bottom.displayWidth =
        this.width;
    
    this.top.displayHeight =
        this.bottom.displayHeight =
        this.top.displayWidth /
        endAspectRatio;
    
    //Set new size of scroll body.
    this.body.displayWidth =
    this.top.displayWidth * 0.8;
    
    this.body.displayHeight =
        Math.max(
            this.height -
            this.top.displayHeight,
            0
        );
    
//Position top.
this.top.setPosition(
    this.rect.centerX -
    this.top.displayWidth / 2,
    this.y
);

//Position body.
this.body.setPosition(
    this.top.x +
    this.top.displayWidth * 0.1,
    this.top.y +
    this.top.displayHeight
);

//Position bottom.
this.bottom.setPosition(
    this.rect.centerX -
    this.bottom.displayWidth / 2,
    this.body.y +
    this.body.displayHeight -
    this.bottom.displayHeight
);
    
    this.scrollRect =
        new Phaser.Geom.Rectangle(
            this.top.x,
            this.top.y,
            this.top.displayWidth,
            (
                this.bottom.y +
                this.bottom.displayHeight
            ) -
            this.top.y
        );
    
    this.originalX =
        this.scrollRect.x;
    
    this.originalY =
        this.scrollRect.y;
    
    this.originalWidth =
        this.scrollRect.width;
    
    this.originalHeight =
        this.scrollRect.height;
    
    return this;
}
    
    setFontSize(){
        if(screen.width < 800){
            this.headlineFontSize = 22+"px";
            this.fontSize = 18+"px";
            this.checkboxWidth = this.checkboxHeight = 16;
        }
        else if(screen.width < 1200){ 
            this.headlineFontSize = 27+"px";
            this.fontSize = 23+"px";
            this.checkboxWidth = this.checkboxHeight = 20;
 
        }
        else{
            this.headlineFontSize = 32+"px";
            this.fontSize = 28+"px"; 
            this.checkboxWidth = this.checkboxHeight = 24;
        } 
    }  
    addObjectives(card){
        this.setFontSize();
        this.textX = this.body.x + this.body.displayWidth*0.1;
        this.textY = this.body.y + 10;
        
        this.texts = [];
        const objectives = card.getData("objectives");
        //headline
        this.headline = this.scene.add.text(0,0, "Objectives",
            {fontSize: this.headlineFontSize, fontFamily: "myOtherOtherFont", color: 'green'}
            ).setOrigin(0).setDepth(this.body.depth+1)
        this.headline.setPosition(this.rect.centerX - this.headline.displayWidth/2, this.textY);
        //objectives
        if(!objectives) return;
        for(let i = 0; i < Object.values(objectives).length; ++i){
            const objective = Object.values(objectives)[i];
            
            const text = this.scene.add.text(this.textX, this.textY, "👉🏿"+objective,
                {fontSize: this.fontSize, fontFamily: 'myOtherOtherFont', color: 'black'}
                ).setOrigin(0).setDepth(this.body.depth+1)
                 .setWordWrapWidth(this.body.displayWidth * 0.8);
            this.texts.push(text);
            
            if(i-1 < 0){
                text.setPosition(this.textX, this.headline.y + this.headline.displayHeight + 13);
            }
            else{
                text.setPosition(this.textX, this.texts[i-1].y + this.texts[i-1].displayHeight + 10);
            }
        }
        this.contents = [this.headline, ...this.texts];
        return this;
    }
    
    addCheckboxes(){
        this.checkboxes = [];
        this.checkboxGraphics = [];
        for(let i = 0; i < this.texts.length; ++i){
            const graphics = this.scene.add.graphics({lineStyle: {width: 2, color: 0xffffff}}).setDepth(this.body.depth+1);
            graphics.checked = false;
            this.checkboxGraphics.push(graphics);
            const rect = new Phaser.Geom.Rectangle(
                this.body.x + this.body.displayWidth*0.9 - 5,
                this.texts[i].y + this.texts[i].displayHeight/2 - this.checkboxHeight/2,
                this.checkboxWidth,
                this.checkboxHeight,
            );
            graphics.strokeRect(rect.x, rect.y, rect.width, rect.height);
            this.checkboxes.push(rect);
        }
        return this;
    }
    clearContents() {
    if (this.checkboxGraphics.length) {
        this.checkboxGraphics.forEach(g => {
            g.clear();
        });
    }
    
    if (this.contents) {
        this.contents.forEach(c => {
            c.destroy();
        });
    }
    
    this.contents = [];
    this.headline = null;
    this.texts = [];
    this.checkboxes = [];
    this.checkboxGraphics = [];
}
    
    checkBox(index){
        this.checkboxGraphics[index].clear();
        this.checkboxGraphics[index].fillStyle(0x000000);
        this.checkboxGraphics[index].fillRectShape(this.checkboxes[index]);
        this.checkboxGraphics[index].setName(index);
        this.checkboxGraphics[index].checked = true;
    }
    uncheckBox(box, index){
        this.checkboxGraphics[index].clear();
        this.checkboxGraphics[index].checked = false;
    }
    close(){
        this.body.displayHeight = 0;
        this.bottom.y = this.top.y + this.top.displayHeight;
        return this;
    }
    tweenClose(){
        this.scene.tweens.add({
            targets: this.body,
            displayHeight: 0,
            ease: 'Linear',
            repeat: 0,
            duration: 500
        })
        this.scene.tweens.add({
            targets: this.bottom,
            y: this.top.y + this.top.displayHeight,
            ease: 'Linear',
            repeat: 0,
            duration: 500
        })
        
        return this;
    } 
    tweenOpen(){
        this.scene.tweens.add({
            targets: this.body,
            displayHeight: this.originalHeight - this.top.displayHeight,
            ease: 'Linear',
            repeat: 0
        })
        this.scene.tweens.add({
            targets: this.bottom,
            y: this.originalY + this.originalHeight - this.top.displayHeight,
            ease: 'Linear',
            repeat: 0
        })
    }
    
}