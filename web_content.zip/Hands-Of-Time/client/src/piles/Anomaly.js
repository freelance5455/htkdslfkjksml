export class AnomalyPile {
    constructor(scene, id) {
        this.scene = scene;
        this.id = id;
        this.container = undefined;
    }
    
    create(x, y, w, h, containerIndex = 0) {
        
        this.x = x;
        this.y = y;
        this.width = w;
        this.height = h;
        this.containerIndex = containerIndex;
        
        //Pile rectangle.
        this.rect =
            this.scene.createPileRect(
                x,
                y,
                w,
                h
            );
        
        //Container.
        this.container =
            this.scene.add
            .container(x, y)
            .setSize(w, h)
            .setDepth(1);
        
        this.container.setData({
            index: containerIndex - 1,
            ownerID: this.id
        });
        
        //Drop zone.
        this.zone =
            this.scene.createDropZone(
                this.id + "Zone",
                x,
                y,
                w,
                h
            )
            .setDepth(0);
        
        this.zone.setData({
            index: containerIndex - 1
        });
        
        return this;
    }
}