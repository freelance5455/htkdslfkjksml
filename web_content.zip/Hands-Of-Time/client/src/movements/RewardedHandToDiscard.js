/*
    This class differs from HandToDiscard in two ways:
    1. when this class is executed(), the card goes straight to discard (does not resolve the current anomaly)
    2. Player immediately gets rewarded with the resource attached to the card
*/
import { Movement } from "./Movement.js"; 
import { getNonEmptyContainers } from "../utils/HelperFunctions.js";
import { eventEmitter } from "../events/EventEmitter.js";

export class RewardedHandToDiscard extends Movement{
    constructor(scene, sourceContainer){
        super(scene);
        this.id = "rewardedHandToDiscard";
        this.sourceContainer = sourceContainer;
        const {hand, deck, discard, anomalyPile} = this.scene.gameplayUI.piles;
        const { PreloadScene } = scene.game.scene.keys;
        this.preloadScene = PreloadScene;
        this.hand = hand;
        this.discard = discard;
        this.deck = deck;
        this.anomalyPile = anomalyPile;
        this.card = undefined;
    }
    
    execute(){
        this.preloadScene.audio.play(this.preloadScene.audio.swooshSound);
        const sourceContainer = this.sourceContainer;
        const targetContainer = this.discard.container;

        this.card = sourceContainer.list[sourceContainer.length-1];
        this.card.setFrame(this.card.getData("frame"));
        
        this.targetY = targetContainer.y - sourceContainer.y;
        this.targetX = targetContainer.x - sourceContainer.x;
       
        const points = [
            sourceContainer.x+sourceContainer.width, sourceContainer.y,
            this.anomalyPile.container.x - this.anomalyPile.container.width, this.anomalyPile.container.y + this.anomalyPile.container.height,
            this.anomalyPile.container.x + this.anomalyPile.container.width, this.anomalyPile.container.y + this.anomalyPile.container.height,
            targetContainer.x+targetContainer.width/2, targetContainer.y+targetContainer.height/2,
        ]
        const path = new Phaser.Curves.Path(sourceContainer.x, sourceContainer.y);
        path.splineTo(points);
        let follower = this.scene.add.follower(path, sourceContainer.x, sourceContainer.y, 'cards')
            .setDisplaySize(targetContainer.width, targetContainer.height)
            .setFrame(this.card.frame)
            .setDepth(sourceContainer.depth+1);
        //hide card until ready to destroy
        this.card.setVisible(false);
        
        follower.startFollow({
            duration: 1000,
            ease: 'Linear',
            rotateToPath: true,
            onComplete: ()=>{
                //destroy follower
                follower.destroy();
                follower = null;
                
                
                //reward player with
                //a. card's resource point
                this.getRPReward(this.card);
                //b. card's Draw point
                this.getDPReward(this.card);
                //c. card's Swap point
                this.getSPReward(this.card);
                //create a proper card
                const card = this.scene.createCard(targetContainer.getData("ownerID")+"Card")
                    .setInteractive({draggable: false})
                    .setDisplaySize(targetContainer.width, targetContainer.height)
                    .setFrame(this.card.getData("frame"));
                card.setData({
                    x: card.x,
                    y: card.y,
                    sourceZone: "marketZone",
                    frame: this.card.getData("frame"),
                    suit: this.card.getData("suit"),
                    colour: this.card.getData("colour"),
                    value: this.card.getData("value"),
                    index: targetContainer.getData("index"),
                    zone: "discard",
                    rect: new Phaser.Geom.Rectangle(targetContainer.x, targetContainer.y, targetContainer.width, targetContainer.height),
                    title: this.card.getData("title"),
                    attributes: this.card.getData("attributes"),
                    category: this.card.getData("category"),
                    level: this.card.getData("level"),
                    reward: this.card.getData("reward"),
                    resource: this.card.getData("resource"),
                    DP: this.card.getData("DP"),
                    SP: this.card.getData("SP"),
                    
                });
                
                targetContainer.add(card);
                card.setPosition(0, 0);
                card.setData({x: card.x, y: card.y}) 
                this.checkGameOver();
                
                sourceContainer.list.pop();
                this.card = null; 
            }
        })
    }
    
    getRPReward(card){
        const { RPText, RPRect} = this.scene.gameplayUI;
        const totalPoints = parseInt(RPText.text) + parseInt(card.getData("resource"));
        RPText.setText(totalPoints);
        RPText.setPosition(RPRect.centerX - RPText.displayWidth/2, RPRect.bottom - RPText.height - 10);
    }
    getSPReward(card){
        const { SPText, SPRect} = this.playScene.gameplayUI;
 
        const totalPoints = parseInt(SPText.text) + parseInt(card.getData("SP"));
        return new Promise((resolve, reject)=>{
            SPText.setText(totalPoints);
            SPText.setPosition(SPRect.centerX - SPText.displayWidth/2, SPRect.bottom - SPText.height - 10);
                setTimeout(()=>{ resolve() }, 300)
        })
    }
    
    getDPReward(card){
        return new Promise((resolve, reject)=>{
            const { DPText, DPRect} = this.playScene.gameplayUI;
            const newPoints = parseInt(DPText.text) + parseInt(card.getData("DP"));
            DPText.setText(newPoints);
            DPText.setPosition(DPRect.centerX - DPText.displayWidth/2, DPRect.bottom - DPText.height - 10);
                setTimeout(()=>{ resolve() }, 300)
        })
    }
    checkGameOver(){
        let solvedObjectives = 0;
        this.anomalyPile.scroll.checkboxGraphics.forEach((g)=>{
            if(g.name !== "") solvedObjectives++;
        })
        if(solvedObjectives < this.anomalyPile.scroll.checkboxGraphics.length){
            const filledContainers = getNonEmptyContainers(this.hand.containers);
            if(this.deck.container.length === 0 && filledContainers.length <= 1){
                eventEmitter.emit("GAME_OVER");
            }
        }
        eventEmitter.off("GAME_OVER");
        eventEmitter.once("GAME_OVER", ()=>{
            //play turn completed sound
            this.preloadScene.audio.gameOverSound.play();
            this.scene.scene.start("GameOverScene");
        })
    }
}