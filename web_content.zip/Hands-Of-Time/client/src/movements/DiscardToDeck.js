import { Movement } from "./Movement.js";

export class DiscardToDeck extends Movement{
    constructor(scene, portal){
        super(scene);
        this.id = "discardToDeck";
        this.movementCount = 0;
        this.numberOfRemainingCards = 0;
        this.timeout;
        this.portal = portal;
    }
    
    execute(){
        const {hand, deck, discard, anomalyPile, resolvedPile} = this.scene.gameplayUI.piles;
        
        const sourceContainer = discard.container;
        const targetContainer = deck.container;
        //get the data of cards used to resolve the past anomaly, bring to top and deal them to deck
        const registryCards = this.scene.registry.get("dealtCards");
        const currentAnomaly = this.portal.list[this.portal.length - 1];
        const anomalyLevel = parseInt(currentAnomaly.getData("level")) - 1;
        
        const cardsArray = registryCards[anomalyLevel];
        if(cardsArray.length === 0) return;
        
        this.timeout = cardsArray.length * 200;
        
        const topCard = cardsArray[cardsArray.length - 1];
        for(let i = 0; i < discard.container.length; ++i){
            const card = discard.container.list[i];
            
            if(topCard.value === card.getData("value") && topCard.suit === card.getData("suit")){
                //alert(topCard.value, topCard.suit)
                sourceContainer.bringToTop(card);
                this.card = card;
                break;
            }
        }
        //this.card = sourceContainer.list[sourceContainer.length-1];
        //play draw sound
        this.preloadScene.audio.play(this.preloadScene.audio.drawSound);
        
        this.targetY = targetContainer.y - sourceContainer.y;
        this.targetX = targetContainer.x - sourceContainer.x;
       
        this.scene.tweens.add({
            targets: this.card,
            y: this.targetY,
            x: this.targetX,
            displayWidth: targetContainer.width,
            displayHeight: targetContainer.height,
            duration: 100,
            onComplete: ()=>{
                //RE-COUNT deck
                deck.remainingCards++;
                deck.recount();
                
                const card = this.scene.createCard(targetContainer.getData("ownerID")+"Card", true)
                    .setDisplaySize(targetContainer.width, targetContainer.height)
                    .removeInteractive()
                    .setFrame(59);
                card.setData({
                    x: card.x,
                    y: card.y,
                    sourceZone: "DiscardZone",
                    frame: this.card.getData("frame"),
                    suit: this.card.getData("suit"),
                    colour: this.card.getData("colour"),
                    value: this.card.getData("value"),
                    index: targetContainer.getData("index"),
                    zone: "hand",
                    rect: new Phaser.Geom.Rectangle(targetContainer.x, targetContainer.y, targetContainer.width, targetContainer.height),
                    title: this.card.getData("title"),
                    attributes: this.card.getData("attributes"),
                    category: this.card.getData("category"),
                    level: this.card.getData("level"),
                    reward: this.card.getData("reward"),
                    resource: this.card.getData("resource"),
                    DP: this.card.getData("DP"),
                    SP: this.card.getData("SP"),
                });
                
                targetContainer.addAt(card, 0);
                card.setPosition(0, 0);
                targetContainer.list.forEach((card, i)=>{ card.setPosition(-i*0.5, 0.5) })
                card.setData({x: card.x, y: card.y}) 
                
                sourceContainer.remove(this.card, true);
                
                //pop the topmost card
                cardsArray.pop();
                if(cardsArray.length > 0){
                    return new Promise((resolve, reject) => {
                        this.execute();
                        setTimeout(()=>resolve(), 1000);
                    })
                }
            }
        })
    }
}