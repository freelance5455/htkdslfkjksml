import { Movement } from "./Movement.js";
import { HostToVisitor } from "./HostToVisitor.js";


export class VisitorToHost extends Movement{
    constructor(scene, sourceContainer, targetContainer){
        super(scene);
        this.id = "visitorToHost";
        this.sourceContainer = sourceContainer;
        this.targetContainer = targetContainer;
    }
    
    execute(){
        const {hand, deck, discard, anomalyPile} = this.scene.gameplayUI.piles;
        
        const sourceContainer = this.sourceContainer;
        const targetContainer = this.targetContainer;
        
        this.card = sourceContainer.list[sourceContainer.length-1];
        
        this.targetY = targetContainer.y - sourceContainer.y;
        this.targetX = targetContainer.x - sourceContainer.x;
       //if any of the gameplay buttons is activated or no card is available to move, return
        this.playScene.gameplayUI.gameplayButtons.forEach((btn, i)=>{ if(btn.active) return })
        if (!this.card) { return }
        
        this.scene.tweens.add({
            targets: this.card,
            y: this.targetY,
            x: this.targetX,
            displayWidth: targetContainer.width,
            displayHeight: targetContainer.height,
            duration: 100,
            onComplete: ()=>{
                const card = this.scene.createCard(targetContainer.getData("ownerID")+"Card", true)
                    .setDisplaySize(targetContainer.width, targetContainer.height)
                    .setFrame(this.card.getData("frame"));
                card.setData({
                    x: card.x,
                    y: card.y,
                    sourceZone: "HandZone",
                    frame: this.card.getData("frame"),
                    suit: this.card.getData("suit"),
                    colour: this.card.getData("colour"),
                    value: this.card.getData("value"),
                    index: targetContainer.getData("index"),
                    zone: "hand",
                    rect: new Phaser.Geom.Rectangle(targetContainer.x, targetContainer.y, targetContainer.width, targetContainer.height),
                    title: this.card.getData("title"),
                    attributes: this.card.getData("attributes"),
                    category: this.card.getData("category"),
                    level: this.card.getData("level"),
                    reward: this.card.getData("reward"),
                    resource: this.card.getData("resource"),
                    DP: this.card.getData("DP"),
                    SP: this.card.getData("SP"),
                });
                
                targetContainer.add(card);
                card.setPosition(0, 0);
                card.setData({x: card.x, y: card.y}) 
                
                sourceContainer.list.pop();
                this.card = null;
                
                
                const command = new HostToVisitor(this.scene, targetContainer, sourceContainer);
                this.scene.commandHandler.execute(command );
            }
        })
    }
}