export class Movement{
    constructor(scene){
        this.scene = scene;
        this.config = scene.config;
        this.graphics = scene.graphics;
        const { PreloadScene, PlayScene } = scene.game.scene.keys;
        this.preloadScene = PreloadScene;
        this.playScene = PlayScene;
    }
    
    execute(){}
    undo(){}
    redo(){}
}