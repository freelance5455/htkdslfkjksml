import { Movement } from "./Movement.js";

export class PortalToUnresolved extends Movement{
    constructor(scene, sourceContainer){
        super(scene);
        this.id = "portalToUnresolved";
        this.sourceContainer = sourceContainer;
    }
    
    execute(){
        const {hand, deck, discard, anomalyPile} = this.scene.gameplayUI.piles;
        const { outworlders } = this.scene.handsOfTime;

        const sourceContainer = this.sourceContainer;
        const targetContainer = outworlders;

        if(!sourceContainer) return;
        //get total time taken
        this.card = sourceContainer.list[sourceContainer.length-1];
        
        this.targetY = targetContainer.y - sourceContainer.y;
        this.targetX = targetContainer.x - sourceContainer.x;
       
        this.scene.tweens.add({
            targets: this.card,
            y: this.targetY,
            x: this.targetX,
            displayWidth: targetContainer.width,
            displayHeight: targetContainer.height,
            duration: 700,
            onComplete: ()=>{
                const card = this.scene.createCard(targetContainer.getData("ownerID")+"Card", true)
                    .setDisplaySize(targetContainer.width, targetContainer.height)
                    .setInteractive({draggable: false})
                    .setFrame(this.card.getData("frame"));
                card.setData({
                    x: this.card.x,
                    y: this.card.y,
                    sourceZone: "PortalZone",
                    frame: this.card.getData("frame"),
                    suit: this.card.getData("suit"),
                    colour: this.card.getData("colour"),
                    value: this.card.getData("value"),
                    index: targetContainer.getData("index"),
                    zone: "outworld",
                    rect: new Phaser.Geom.Rectangle(targetContainer.x, targetContainer.y, targetContainer.width, targetContainer.height),
                    title: this.card.getData("title"),
                    attributes: this.card.getData("attributes"),
                    category: this.card.getData("category"),
                    level: this.card.getData("level"),
                    firstCard: this.card.getData("firstCard") || 0,
                    secondCard: this.card.getData("secondCard") || 0,
                    thirdCard: this.card.getData("thirdCard") || 0,
                    reward: this.card.getData("reward"),
                    resource: this.card.getData("resource"),
                    objectives: this.card.getData("objectives"),
                    DP: this.card.getData("DP"),
                    SP: this.card.getData("SP"),
                    
                });
                targetContainer.add(card);
                card.setPosition(0, 0);
                card.setData({x: card.x, y: card.y}) 
                
                sourceContainer.remove(this.card, true);
            }
        })
    }
}