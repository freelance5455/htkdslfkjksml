import { GameplayButtonState } from "./GameplayButtonState.js";

export class ResolveState extends GameplayButtonState{
    enter(){
        this.gameplayButtons.forEach(btn=>{
            if(btn.id !== 'Resolve'){
                btn.active = false;
                btn.enterRestState();
            }
        })
        return this;
    }
}

export class DiscardState extends GameplayButtonState{
    enter(){
        this.gameplayButtons.forEach(btn=>{
            if(btn.id !== 'Discard'){
                btn.active = false;
                btn.enterRestState();
            }
        })
        return this;
    }
}

export class DrawState extends GameplayButtonState{
    enter(){
        this.gameplayButtons.forEach(btn=>{
            if(btn.id !== 'Draw'){
                btn.active = false;
                btn.enterRestState();
            }
            else{
                setTimeout(()=>{
                    btn.active = false;
                    btn.enterRestState(); 
                }, 50)
            }

        })
        return this;
    }
}

export class SwapState extends GameplayButtonState{
    enter(){
        this.gameplayButtons.forEach(btn=>{
            if(btn.id !== 'Swap'){
                btn.active = false;
                btn.enterRestState();
            }
        })
        return this;
    }
}

export class EndState extends GameplayButtonState{
    enter(){
        this.gameplayButtons.forEach(btn=>{
            if(btn.id !== 'End'){
                btn.active = false;
                btn.enterRestState();
            }
            else{
                setTimeout(()=>{
                    btn.active = false;
                    btn.enterRestState();
                }, 100)
            }
        })
        return this;
    }
}