منصور نیازي — ښکلی ماشین حساب

فایلونه:
- Calculator.html: د ماشین حساب کارېدونکې نسخه؛ د جمع، منفي، ضرب، تقسیم، سلنې، حذف او حسابونو تاریخ سره.
- assets/mansoor_niazi_poster.png: د ورکړل شوي ډیزاین انځور.
- AndroidStudioProject/: د Android Studio سورس کوډ پروژه.

د HTML ماشین حساب کارول:
1. ZIP فایل Extract کړئ.
2. Calculator.html او assets فولډر یو ځای وساتئ.
3. Calculator.html په Chrome کې خلاص کړئ. د انځور ښودلو لپاره assets فولډر باید ورسره پاتې وي.

د جوړونکي معلومات:
جوړونکی: منصور نیازي
د محمد جميل نيازي زوی
د جمعه خان نيازي لمسی
وردک ولایت، بند چک ولسوالۍ، عربانو دره، خانک خېلو کلی

یادونه: د Android APK فایل په دې چاپېریال کې نه دی کمپایل شوی. د APK لپاره AndroidStudioProject په Android Studio کې خلاص کړئ او Build > Build APK(s) وکاروئ.
