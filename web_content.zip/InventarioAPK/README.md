# Inventario Almacén Central - Proyecto Android

Este proyecto empaqueta el archivo HTML original como una aplicación Android mediante WebView.

## Contenido
- `app/src/main/assets/index.html`: aplicación HTML original.
- `app/src/main/java/.../MainActivity.java`: WebView que carga el HTML local.
- Configuración Gradle de Android Studio para generar APK.

## Cómo generar la APK
1. Extrae el ZIP.
2. Abre la carpeta `InventarioAPK` con Android Studio.
3. Espera a que Android Studio sincronice Gradle y descargue las dependencias necesarias.
4. Usa `Build > Build APK(s)` para generar una APK de prueba.
5. Para una APK firmada, usa `Build > Generate Signed App Bundle / APK`.

## Datos
La aplicación HTML usa `localStorage`, por lo que los datos se guardan localmente en el WebView del dispositivo.
