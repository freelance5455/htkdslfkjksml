const pageTransition = document.createElement("div");
pageTransition.className = "page-transition is-visible";
pageTransition.setAttribute("aria-hidden", "true");
document.body.appendChild(pageTransition);
document.body.classList.add("page-enter");

window.closeDialogWithAnimation = (dialog, onClosed) => {
    if (!dialog.open || dialog.classList.contains("is-closing")) {
        return;
    }

    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
        dialog.close();
        onClosed?.();
        return;
    }

    let fallbackTimer;
    const finishClosing = () => {
        window.clearTimeout(fallbackTimer);
        dialog.removeEventListener("animationend", handleAnimationEnd);
        dialog.classList.remove("is-closing");
        if (dialog.open) {
            dialog.close();
        }
        onClosed?.();
    };
    const handleAnimationEnd = event => {
        if (event.target === dialog && event.animationName === "dialog-fade-out") {
            finishClosing();
        }
    };

    dialog.addEventListener("animationend", handleAnimationEnd);
    dialog.classList.add("is-closing");
    fallbackTimer = window.setTimeout(finishClosing, 340);
};

requestAnimationFrame(() => {
    pageTransition.classList.remove("is-visible");
});

window.addEventListener("pageshow", event => {
    if (event.persisted) {
        pageTransition.classList.remove("is-visible");
    }
});

document.addEventListener("click", event => {
    const link = event.target.closest("a[href]");
    if (
        event.defaultPrevented ||
        !link ||
        event.button !== 0 ||
        event.metaKey ||
        event.ctrlKey ||
        event.shiftKey ||
        event.altKey ||
        link.target ||
        link.hasAttribute("download") ||
        link.getAttribute("aria-disabled") === "true"
    ) {
        return;
    }

    const destination = new URL(link.href, window.location.href);
    if (
        destination.origin !== window.location.origin ||
        destination.href === window.location.href ||
        (destination.pathname === window.location.pathname &&
            destination.search === window.location.search)
    ) {
        return;
    }

    event.preventDefault();

    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
        window.location.assign(destination.href);
        return;
    }

    const isMobile = window.matchMedia("(max-width: 600px)").matches;
    if (isMobile) {
        document.body.classList.add("page-leave");
        window.setTimeout(() => {
            pageTransition.classList.add("is-visible");
        }, 160);
    } else {
        pageTransition.classList.add("is-visible");
    }

    window.setTimeout(() => {
        window.location.assign(destination.href);
    }, isMobile ? 520 : 320);
});
