const params = new URLSearchParams(window.location.search);
const bookId = params.get("book");

const bookMessage = document.getElementById("bookMessage");
const chapterSelect = document.getElementById("chapterSelect");
const chapterOptions = document.getElementById("chapterOptions");
const startReading = document.getElementById("startReading");
let selectedChapter = "";

function extractChapterTitle(chapter, chapterNumber) {
    const heading = chapter.querySelector("h2, h3, h1")?.textContent.trim();
    if (heading) {
        return heading;
    }

    if (chapterNumber === 0) {
        const content = chapter.textContent.toLowerCase();
        return content.includes("auteur") ? "Mot de l’auteur" : "Avertissement";
    }

    return `Chapitre ${chapterNumber}`;
}

function setDescription(element, source) {
    const breaks = source.querySelectorAll("br");
    breaks.forEach(lineBreak => lineBreak.replaceWith("\n"));
    element.textContent = source.textContent.trim();
}

function updateReadingLink(book) {
    if (selectedChapter === "") {
        startReading.href = "#";
        startReading.setAttribute("aria-disabled", "true");
        return;
    }

    const query = new URLSearchParams({
        book: book.id,
        chapter: selectedChapter
    });
    startReading.href = `reader.html?${query.toString()}`;
    startReading.setAttribute("aria-disabled", "false");
}

function closeChapterOptions(returnFocus = false) {
    chapterOptions.hidden = true;
    chapterSelect.setAttribute("aria-expanded", "false");
    if (returnFocus) {
        chapterSelect.focus();
    }
}

function openChapterOptions(focusLast = false) {
    if (chapterSelect.disabled) {
        return;
    }

    chapterOptions.hidden = false;
    chapterSelect.setAttribute("aria-expanded", "true");
    const options = chapterOptions.querySelectorAll('[role="option"]');
    const selectedOption = chapterOptions.querySelector('[aria-selected="true"]');
    const target = focusLast
        ? options[options.length - 1]
        : selectedOption || options[0];
    options.forEach(option => {
        option.tabIndex = option === target ? 0 : -1;
    });
    target?.focus();
}

function selectChapter(option, book, returnFocus = true) {
    selectedChapter = option.dataset.chapter;
    chapterSelect.textContent = option.textContent;
    chapterOptions.querySelectorAll('[role="option"]').forEach(item => {
        item.setAttribute(
            "aria-selected",
            String(item === option)
        );
    });
    updateReadingLink(book);
    closeChapterOptions(returnFocus);
}

async function initializeBookDetails() {
    if (!bookId || !bookFolders.includes(bookId)) {
        bookMessage.textContent = "Livre introuvable.";
        return;
    }

    try {
        const catalog = await loadBookCatalog();
        const book = catalog.find(item => item.id === bookId);
        if (!book) {
            throw new Error("Le livre n’existe pas dans le catalogue.");
        }

        document.title = book.title;
        document.getElementById("bookTitle").textContent = book.title;
        document.getElementById("bookAuthor").textContent = book.author;

        const progressValue = Math.min(
            book.chapterCount,
            Math.max(0, BookStockPreferences.getProgress(book.id) || 0)
        );
        const bookProgress = document.getElementById("bookProgress");
        bookProgress.max = book.chapterCount;
        bookProgress.value = progressValue;
        bookProgress.classList.add(
            progressValue === book.chapterCount ? "is-complete" : "is-in-progress"
        );
        bookProgress.setAttribute(
            "aria-label",
            `Progression de lecture : ${progressValue} sur ${book.chapterCount} chapitres`
        );
        document.getElementById("bookProgressLabel").textContent =
            `${progressValue} / ${book.chapterCount} chapitres lus`;

        const cover = document.getElementById("bookCover");
        cover.src = book.cover;
        cover.alt = `Couverture de ${book.title}`;

        const infoResponse = await fetch(`books/${book.id}/info.html`);
        if (!infoResponse.ok) {
            throw new Error(`Chargement des informations impossible (${infoResponse.status}).`);
        }

        const infoDoc = new DOMParser().parseFromString(
            await infoResponse.text(),
            "text/html"
        );
        const info = infoDoc.getElementById("book-info");
        const infoTitle = info?.querySelector("#title")?.textContent.trim();
        const author = info?.querySelector("#author")?.textContent.trim();
        const description = info?.querySelector("#description");

        if (infoTitle) {
            document.getElementById("bookTitle").textContent = infoTitle;
            document.title = infoTitle;
        }
        if (author) {
            document.getElementById("bookAuthor").textContent = author;
        }
        if (description) {
            setDescription(document.getElementById("bookDescription"), description);
        }

        const contentResponse = await fetch(`books/${book.id}/content.html`);
        if (!contentResponse.ok) {
            throw new Error(`Chargement des chapitres impossible (${contentResponse.status}).`);
        }

        const contentDoc = new DOMParser().parseFromString(
            await contentResponse.text(),
            "text/html"
        );
        const chapters = Array.from(
            contentDoc.querySelectorAll('section[id^="chapter-"]')
        ).map(chapter => ({
            element: chapter,
            number: Number(chapter.id.slice("chapter-".length))
        })).filter(chapter =>
            Number.isInteger(chapter.number) &&
            chapter.number >= 0 &&
            (chapter.number !== 0 ||
                chapter.element.textContent.trim().length > 0)
        );
        const numberedChapters = chapters.filter(chapter => chapter.number > 0);

        if (numberedChapters.length !== book.chapterCount) {
            throw new Error(
                `Le catalogue annonce ${book.chapterCount} chapitres, ` +
                `mais ${numberedChapters.length} sont présents.`
            );
        }

        chapterOptions.replaceChildren();
        chapters.forEach(chapter => {
            const item = document.createElement("li");
            item.setAttribute("role", "none");
            const option = document.createElement("button");
            option.className = "chapter-option";
            option.type = "button";
            option.setAttribute("role", "option");
            option.dataset.chapter = String(chapter.number);
            option.textContent = chapter.number === 0
                ? extractChapterTitle(chapter.element, 0)
                : extractChapterTitle(chapter.element, chapter.number);
            item.appendChild(option);
            chapterOptions.appendChild(item);
        });

        if (chapters.length === 0) {
            chapterSelect.disabled = true;
            throw new Error("Aucun chapitre disponible dans le fichier du livre.");
        }

        const savedChapter = BookStockPreferences.getLastRead(book.id);
        const initialChapter = Number.isInteger(savedChapter) &&
            chapters.some(chapter => chapter.number === savedChapter)
            ? savedChapter
            : chapters.some(chapter => chapter.number === 1)
                ? 1
                : chapters[0].number;
        const initialOption = chapterOptions.querySelector(
            `[data-chapter="${initialChapter}"]`
        );

        document.getElementById("detailChapterCount").textContent =
            `${numberedChapters.length} chapitre${numberedChapters.length > 1 ? "s" : ""}` +
            (chapters.some(chapter => chapter.number === 0)
                ? " · avertissement ou mot de l’auteur disponible"
                : "");
        chapterSelect.disabled = false;
        selectChapter(initialOption, book, false);
    } catch (error) {
        bookMessage.textContent = "Impossible de charger la fiche du livre.";
        console.error("Erreur d'initialisation de la fiche du livre :", error);
    }
}

chapterSelect.addEventListener("click", () => {
    if (chapterOptions.hidden) {
        openChapterOptions();
    } else {
        closeChapterOptions();
    }
});

chapterSelect.addEventListener("keydown", event => {
    if (event.key === "ArrowDown" || event.key === "ArrowUp") {
        event.preventDefault();
        openChapterOptions(event.key === "ArrowUp");
    }
});

chapterOptions.addEventListener("click", event => {
    const option = event.target.closest('[role="option"]');
    if (option) {
        selectChapter(option, { id: bookId });
    }
});

chapterOptions.addEventListener("keydown", event => {
    const options = Array.from(
        chapterOptions.querySelectorAll('[role="option"]')
    );
    const currentIndex = options.indexOf(document.activeElement);
    let targetIndex = currentIndex;

    if (event.key === "Escape") {
        event.preventDefault();
        closeChapterOptions(true);
        return;
    }
    if (event.key === "ArrowDown") {
        targetIndex = (currentIndex + 1) % options.length;
    } else if (event.key === "ArrowUp") {
        targetIndex = (currentIndex - 1 + options.length) % options.length;
    } else if (event.key === "Home") {
        targetIndex = 0;
    } else if (event.key === "End") {
        targetIndex = options.length - 1;
    } else {
        return;
    }

    event.preventDefault();
    options.forEach((option, index) => {
        option.tabIndex = index === targetIndex ? 0 : -1;
    });
    options[targetIndex]?.focus();
});

document.addEventListener("click", event => {
    if (!event.target.closest(".chapter-select")) {
        closeChapterOptions();
    }
});

initializeBookDetails();
