const params = new URLSearchParams(window.location.search);
const bookId = params.get("book");

const bookMessage = document.getElementById("bookMessage");
const chapterSelect = document.getElementById("chapterSelect");
const startReading = document.getElementById("startReading");

function extractChapterTitle(chapter, chapterNumber) {
    const heading = chapter.querySelector("h2, h3, h1")?.textContent.trim();
    if (heading) {
        return heading;
    }

    if (chapterNumber === 0) {
        const content = chapter.textContent.toLowerCase();
        return content.includes("auteur") ? "Mot de l’auteur" : "Avertissement";
    }

    return `Chapitre ${chapterNumber}`;
}

function setDescription(element, source) {
    const breaks = source.querySelectorAll("br");
    breaks.forEach(lineBreak => lineBreak.replaceWith("\n"));
    element.textContent = source.textContent.trim();
}

function updateReadingLink(book) {
    const chapter = chapterSelect.value;
    if (chapter === "") {
        startReading.href = "#";
        startReading.setAttribute("aria-disabled", "true");
        return;
    }

    const query = new URLSearchParams({
        book: book.id,
        chapter
    });
    startReading.href = `reader.html?${query.toString()}`;
    startReading.setAttribute("aria-disabled", "false");
}

async function initializeBookDetails() {
    if (!bookId || !bookFolders.includes(bookId)) {
        bookMessage.textContent = "Livre introuvable.";
        chapterSelect.innerHTML = "";
        return;
    }

    try {
        const catalog = await loadBookCatalog();
        const book = catalog.find(item => item.id === bookId);
        if (!book) {
            throw new Error("Le livre n’existe pas dans le catalogue.");
        }

        document.title = book.title;
        document.getElementById("bookTitle").textContent = book.title;
        document.getElementById("bookAuthor").textContent = book.author;

        const cover = document.getElementById("bookCover");
        cover.src = book.cover;
        cover.alt = `Couverture de ${book.title}`;

        const infoResponse = await fetch(`books/${book.id}/info.html`);
        if (!infoResponse.ok) {
            throw new Error(`Chargement des informations impossible (${infoResponse.status}).`);
        }

        const infoDoc = new DOMParser().parseFromString(
            await infoResponse.text(),
            "text/html"
        );
        const info = infoDoc.getElementById("book-info");
        const infoTitle = info?.querySelector("#title")?.textContent.trim();
        const author = info?.querySelector("#author")?.textContent.trim();
        const description = info?.querySelector("#description");

        if (infoTitle) {
            document.getElementById("bookTitle").textContent = infoTitle;
            document.title = infoTitle;
        }
        if (author) {
            document.getElementById("bookAuthor").textContent = author;
        }
        if (description) {
            setDescription(document.getElementById("bookDescription"), description);
        }

        const contentResponse = await fetch(`books/${book.id}/content.html`);
        if (!contentResponse.ok) {
            throw new Error(`Chargement des chapitres impossible (${contentResponse.status}).`);
        }

        const contentDoc = new DOMParser().parseFromString(
            await contentResponse.text(),
            "text/html"
        );
        const chapters = Array.from(
            contentDoc.querySelectorAll('section[id^="chapter-"]')
        ).map(chapter => ({
            element: chapter,
            number: Number(chapter.id.slice("chapter-".length))
        })).filter(chapter =>
            Number.isInteger(chapter.number) &&
            chapter.number >= 0 &&
            (chapter.number !== 0 ||
                chapter.element.textContent.trim().length > 0)
        );
        const numberedChapters = chapters.filter(chapter => chapter.number > 0);

        if (numberedChapters.length !== book.chapterCount) {
            throw new Error(
                `Le catalogue annonce ${book.chapterCount} chapitres, ` +
                `mais ${numberedChapters.length} sont présents.`
            );
        }

        chapterSelect.replaceChildren();
        chapters.forEach(chapter => {
            const option = document.createElement("option");
            option.value = String(chapter.number);
            option.textContent = chapter.number === 0
                ? extractChapterTitle(chapter.element, 0)
                : extractChapterTitle(chapter.element, chapter.number);
            chapterSelect.appendChild(option);
        });

        if (chapters.length === 0) {
            chapterSelect.add(new Option("Aucun chapitre disponible", ""));
            chapterSelect.disabled = true;
            throw new Error("Aucun chapitre disponible dans le fichier du livre.");
        }

        const savedChapter = BookStockPreferences.getLastRead(book.id);
        if (
            Number.isInteger(savedChapter) &&
            chapters.some(chapter => chapter.number === savedChapter)
        ) {
            chapterSelect.value = String(savedChapter);
        } else if (chapters.some(chapter => chapter.number === 1)) {
            chapterSelect.value = "1";
        } else {
            chapterSelect.value = String(chapters[0].number);
        }

        document.getElementById("detailChapterCount").textContent =
            `${numberedChapters.length} chapitre${numberedChapters.length > 1 ? "s" : ""}` +
            (chapters.some(chapter => chapter.number === 0)
                ? " · avertissement ou mot de l’auteur disponible"
                : "");
        chapterSelect.disabled = false;
        updateReadingLink(book);
        chapterSelect.addEventListener("change", () => updateReadingLink(book));
    } catch (error) {
        bookMessage.textContent = "Impossible de charger la fiche du livre.";
        console.error("Erreur d'initialisation de la fiche du livre :", error);
    }
}

initializeBookDetails();
