const params = new URLSearchParams(window.location.search);
const bookId = params.get("book") || BookStockPreferences.getSelectedBook();

const chapterContent = document.getElementById("chapterContent");
const chapterTitle = document.getElementById("chapterTitle");
const chapterCounter = document.getElementById("chapterCounter");
const previousButton = document.getElementById("previousChapter");
const nextButton = document.getElementById("nextChapter");
const chapterMenu = document.getElementById("chapterMenu");
const chapterList = document.getElementById("chapterList");

let book = null;
let currentChapter = 1;
let contentDoc = null;
let chapterNumbers = [];

function getChapterTitle(chapter, chapterNumber) {
    const heading = chapter.querySelector("h2, h3, h1")?.textContent.trim();
    if (heading) {
        return heading;
    }

    if (chapterNumber === 0) {
        return chapter.textContent.toLowerCase().includes("auteur")
            ? "Mot de l’auteur"
            : "Avertissement";
    }

    return `Chapitre ${chapterNumber}`;
}

function buildChapterList() {
    const chapters = Array.from(
        contentDoc.querySelectorAll('section[id^="chapter-"]')
    ).map(chapter => ({
        element: chapter,
        number: Number(chapter.id.slice("chapter-".length))
    })).filter(chapter =>
        Number.isInteger(chapter.number) &&
        chapter.number >= 0 &&
        (chapter.number !== 0 || chapter.element.textContent.trim().length > 0)
    );

    chapterNumbers = chapters.map(chapter => chapter.number);

    chapters.forEach(chapter => {
        const item = document.createElement("li");
        const button = document.createElement("button");

        button.className = "chapter-list-button";
        button.type = "button";
        button.dataset.chapter = chapter.number;
        button.textContent = getChapterTitle(chapter.element, chapter.number);
        item.appendChild(button);
        chapterList.appendChild(item);
    });
}

async function initializeReader() {
    if (!bookId || !bookFolders.includes(bookId)) {
        chapterContent.textContent = "Aucun livre sélectionné.";
        return;
    }

    try {
        const books = await loadBookCatalog();
        book = books.find(item => item.id === bookId);

        if (!book) {
            chapterContent.textContent = "Livre introuvable.";
            return;
        }

        const response = await fetch(`books/${book.id}/content.html`);
        if (!response.ok) {
            throw new Error(`Chargement du contenu impossible (${response.status}).`);
        }

        const html = await response.text();
        contentDoc = new DOMParser().parseFromString(html, "text/html");

        const availableChapters = contentDoc.querySelectorAll(
            'section[id^="chapter-"]:not(#chapter-0)'
        ).length;
        if (availableChapters !== book.chapterCount) {
            throw new Error(
                `Le catalogue annonce ${book.chapterCount} chapitres, ` +
                `mais ${availableChapters} sont présents.`
            );
        }

        buildChapterList();

        const savedChapter = BookStockPreferences.getProgress(book.id);
        const requestedChapter = params.has("chapter")
            ? Number(params.get("chapter"))
            : null;
        if (
            Number.isInteger(requestedChapter) &&
            chapterNumbers.includes(requestedChapter)
        ) {
            currentChapter = requestedChapter;
        } else if (
            Number.isInteger(savedChapter) &&
            chapterNumbers.includes(savedChapter)
        ) {
            currentChapter = savedChapter;
        } else {
            currentChapter = 1;
        }

        document.getElementById("bookTitle").textContent = book.title;
        document.getElementById("backLink").href =
            `book.html?book=${encodeURIComponent(book.id)}`;
        displayChapter();
    } catch (error) {
        chapterContent.textContent =
            "Impossible de charger le livre. Vérifiez que ses fichiers sont disponibles.";
        console.error("Erreur d'initialisation du lecteur :", error);
    }
}

function displayChapter() {
    if (!book || !contentDoc) {
        return;
    }

    const chapter = contentDoc.getElementById(`chapter-${currentChapter}`);
    if (!chapter) {
        chapterContent.textContent = "Chapitre introuvable.";
        return;
    }

    chapterContent.textContent = Array.from(chapter.querySelectorAll("p"))
        .map(paragraph => {
            const copy = paragraph.cloneNode(true);
            copy.querySelectorAll("br").forEach(lineBreak => {
                lineBreak.replaceWith("\n");
            });
            return copy.textContent.trim();
        })
        .filter(Boolean)
        .join("\n\n");

    chapterTitle.textContent =
        getChapterTitle(chapter, currentChapter);
    chapterCounter.textContent = currentChapter === 0
        ? `0 / ${book.chapterCount}`
        : `${currentChapter} / ${book.chapterCount}`;
    const chapterIndex = chapterNumbers.indexOf(currentChapter);
    previousButton.disabled = chapterIndex <= 0;
    nextButton.disabled = chapterIndex === chapterNumbers.length - 1;
    chapterList.querySelectorAll("[data-chapter]").forEach(button => {
        if (Number(button.dataset.chapter) === currentChapter) {
            button.setAttribute("aria-current", "page");
        } else {
            button.removeAttribute("aria-current");
        }
    });

    try {
        BookStockPreferences.saveProgress(book.id, currentChapter);
    } catch (error) {
        console.error("Impossible d’enregistrer la progression du livre :", error);
    }
    window.scrollTo(0, 0);
}

document.querySelector(".close-menu-button").addEventListener("click", () => {
    chapterMenu.close();
});

chapterMenu.addEventListener("cancel", event => {
    event.preventDefault();
    chapterMenu.close();
});

document.addEventListener("keydown", event => {
    if (event.key === "Escape" && chapterMenu.open) {
        event.preventDefault();
        chapterMenu.close();
    }
});

chapterList.addEventListener("click", event => {
    const button = event.target.closest("[data-chapter]");
    if (!button) {
        return;
    }

    currentChapter = Number(button.dataset.chapter);
    displayChapter();
    chapterMenu.close();
});

previousButton.addEventListener("click", () => {
    const chapterIndex = chapterNumbers.indexOf(currentChapter);
    if (chapterIndex > 0) {
        currentChapter = chapterNumbers[chapterIndex - 1];
        displayChapter();
    }
});

nextButton.addEventListener("click", () => {
    const chapterIndex = chapterNumbers.indexOf(currentChapter);
    if (chapterIndex >= 0 && chapterIndex < chapterNumbers.length - 1) {
        currentChapter = chapterNumbers[chapterIndex + 1];
        displayChapter();
    }
});

initializeReader();
