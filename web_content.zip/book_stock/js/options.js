const optionLimits = {
    fontScale: { min: 0.5, max: 2 },
    lineScale: { min: 0.8, max: 1.3 }
};

const readingOptions = BookStockPreferences.getOptions();
const siteMenu = document.createElement("dialog");
siteMenu.id = "siteMenu";
siteMenu.className = "options-dialog";
siteMenu.setAttribute("aria-labelledby", "siteMenuTitle");
siteMenu.innerHTML = `
    <div class="options-dialog-header">
        <h2 id="siteMenuTitle">Menu</h2>
        <button class="options-close" type="button" aria-label="Fermer le menu">×</button>
    </div>
    <div class="site-menu-actions">
        <button class="site-menu-action" type="button" data-menu-action="options">
            Options
        </button>
        ${document.getElementById("chapterMenu")
            ? `<button class="site-menu-action" type="button" data-menu-action="chapters">
                   Chapitres
               </button>`
            : ""}
    </div>
`;
document.body.appendChild(siteMenu);

const optionsDialog = document.createElement("dialog");
optionsDialog.id = "readingOptions";
optionsDialog.className = "options-dialog reading-options-dialog";
optionsDialog.setAttribute("aria-labelledby", "optionsTitle");
optionsDialog.innerHTML = `
    <div class="options-dialog-header">
        <h2 id="optionsTitle">Options</h2>
        <button class="options-close" type="button" aria-label="Fermer les options">×</button>
    </div>
    <div class="options-controls">
        <div class="option-control">
            <span class="option-control-label" id="fontOptionLabel">Taille du texte</span>
            <div class="option-control-actions">
                <button class="option-adjust" type="button" data-option="fontScale"
                        data-step="-1" aria-label="Diminuer la taille du texte">−</button>
                <output class="option-value" id="fontScaleValue" aria-live="polite"></output>
                <button class="option-adjust" type="button" data-option="fontScale"
                        data-step="1" aria-label="Augmenter la taille du texte">+</button>
            </div>
        </div>
        <div class="option-control">
            <span class="option-control-label" id="lineOptionLabel">Espacement des lignes</span>
            <div class="option-control-actions">
                <button class="option-adjust" type="button" data-option="lineScale"
                        data-step="-1" aria-label="Réduire l’espacement des lignes">−</button>
                <output class="option-value" id="lineScaleValue" aria-live="polite"></output>
                <button class="option-adjust" type="button" data-option="lineScale"
                        data-step="1" aria-label="Augmenter l’espacement des lignes">+</button>
            </div>
        </div>
    </div>
    <p class="options-save-message" role="status"></p>
`;
document.body.appendChild(optionsDialog);

function updateOptionsDisplay() {
    document.documentElement.style.setProperty(
        "--reading-font-scale",
        readingOptions.fontScale
    );
    document.documentElement.style.setProperty(
        "--reading-line-scale",
        readingOptions.lineScale
    );

    document.getElementById("fontScaleValue").textContent =
        `${Math.round(readingOptions.fontScale * 100)} %`;
    document.getElementById("lineScaleValue").textContent =
        `${Math.round(readingOptions.lineScale * 100)} %`;

    optionsDialog.querySelectorAll("[data-option]").forEach(button => {
        const key = button.dataset.option;
        const step = Number(button.dataset.step) / 10;
        const nextValue = Math.round(
            (readingOptions[key] + step) * 10
        ) / 10;
        const limits = optionLimits[key];
        button.disabled = nextValue < limits.min || nextValue > limits.max;
    });
}

function saveOptions() {
    try {
        BookStockPreferences.saveOptions(readingOptions);
        optionsDialog.querySelector(".options-save-message").textContent = "";
    } catch (error) {
        console.error("Impossible d’enregistrer les options d’affichage :", error);
        optionsDialog.querySelector(".options-save-message").textContent =
            "Les réglages n’ont pas pu être enregistrés sur cet appareil.";
    }
}

document.querySelectorAll("[data-menu-trigger]").forEach(button => {
    button.addEventListener("click", () => siteMenu.showModal());
});

optionsDialog.querySelector(".options-close").addEventListener("click", () => {
    window.closeDialogWithAnimation(optionsDialog, () => siteMenu.showModal());
});

siteMenu.querySelector(".options-close").addEventListener("click", () => {
    window.closeDialogWithAnimation(siteMenu);
});

optionsDialog.addEventListener("cancel", event => {
    event.preventDefault();
    window.closeDialogWithAnimation(optionsDialog, () => siteMenu.showModal());
});

siteMenu.addEventListener("cancel", event => {
    event.preventDefault();
    window.closeDialogWithAnimation(siteMenu);
});

siteMenu.addEventListener("click", event => {
    if (event.target === siteMenu) {
        window.closeDialogWithAnimation(siteMenu);
        return;
    }

    const action = event.target.closest("[data-menu-action]")?.dataset.menuAction;
    if (!action) {
        return;
    }

    if (action === "options") {
        window.closeDialogWithAnimation(siteMenu, () => optionsDialog.showModal());
        return;
    }

    const chapterMenu = document.getElementById("chapterMenu");
    window.closeDialogWithAnimation(siteMenu, () => {
        if (!chapterMenu) {
            return;
        }

        chapterMenu.showModal();
        document.querySelector("#chapterList [aria-current='page']")
            ?.scrollIntoView({ block: "nearest" });
    });
});

optionsDialog.addEventListener("click", event => {
    if (event.target === optionsDialog) {
        window.closeDialogWithAnimation(optionsDialog, () => siteMenu.showModal());
        return;
    }

    const button = event.target.closest("[data-option]");
    if (!button) {
        return;
    }

    const key = button.dataset.option;
    const step = Number(button.dataset.step) / 10;
    const limits = optionLimits[key];
    const nextValue = Math.round((readingOptions[key] + step) * 10) / 10;

    if (nextValue < limits.min || nextValue > limits.max) {
        return;
    }

    readingOptions[key] = nextValue;
    updateOptionsDisplay();
    saveOptions();
});

updateOptionsDisplay();
