(function () {
    const storageKey = "book-stock-user-data";
    const legacyOptionsKey = "book-stock-reading-options";
    const defaultOptions = { fontScale: 1, lineScale: 1 };
    const limits = {
        fontScale: { min: 0.5, max: 2 },
        lineScale: { min: 0.5, max: 2 }
    };

    function validOption(value, limit) {
        return Number.isFinite(value) &&
            value >= limit.min &&
            value <= limit.max;
    }

    function emptyData() {
        return {
            version: 3,
            options: { ...defaultOptions },
            readChapters: {},
            lastRead: {},
            selectedBook: ""
        };
    }

    function normalizeData(data) {
        const normalized = emptyData();
        if (!data || typeof data !== "object") {
            return normalized;
        }

        if (
            data.options &&
            validOption(data.options.fontScale, limits.fontScale) &&
            validOption(data.options.lineScale, limits.lineScale)
        ) {
            normalized.options = {
                fontScale: data.options.fontScale,
                lineScale: data.options.lineScale
            };
        }

        if (data.readChapters && typeof data.readChapters === "object") {
            Object.entries(data.readChapters).forEach(([bookId, chapters]) => {
                if (
                    /^[\w-]+$/.test(bookId) &&
                    Array.isArray(chapters)
                ) {
                    normalized.readChapters[bookId] = Array.from(new Set(
                        chapters.filter(chapter =>
                            Number.isInteger(chapter) && chapter > 0
                        )
                    ));
                }
            });
        }

        if (data.progress && typeof data.progress === "object") {
            Object.entries(data.progress).forEach(([bookId, chapter]) => {
                if (
                    /^[\w-]+$/.test(bookId) &&
                    Number.isInteger(chapter) &&
                    chapter >= 0
                ) {
                    if (!Object.prototype.hasOwnProperty.call(
                        normalized.readChapters,
                        bookId
                    )) {
                        normalized.readChapters[bookId] = Array.from(
                            { length: chapter },
                            (_, index) => index + 1
                        );
                    }
                    if (!Object.prototype.hasOwnProperty.call(
                        normalized.lastRead,
                        bookId
                    )) {
                        normalized.lastRead[bookId] = chapter;
                    }
                }
            });
        }

        if (data.lastRead && typeof data.lastRead === "object") {
            Object.entries(data.lastRead).forEach(([bookId, chapter]) => {
                if (
                    /^[\w-]+$/.test(bookId) &&
                    Number.isInteger(chapter) &&
                    chapter >= 0
                ) {
                    normalized.lastRead[bookId] = chapter;
                }
            });
        }

        if (typeof data.selectedBook === "string") {
            normalized.selectedBook = data.selectedBook;
        }

        return normalized;
    }

    function writeData(data) {
        try {
            localStorage.setItem(storageKey, JSON.stringify(data));
        } catch (error) {
            console.error("Impossible d’enregistrer les préférences utilisateur :", error);
            throw error;
        }
    }

    function migrateLegacyData() {
        const data = emptyData();

        try {
            const legacyOptions = JSON.parse(
                localStorage.getItem(legacyOptionsKey)
            );
            if (
                legacyOptions &&
                validOption(legacyOptions.fontScale, limits.fontScale) &&
                validOption(legacyOptions.lineScale, limits.lineScale)
            ) {
                data.options = {
                    fontScale: legacyOptions.fontScale,
                    lineScale: legacyOptions.lineScale
                };
            }

            data.selectedBook = localStorage.getItem("selectedBook") || "";

            for (let index = 0; index < localStorage.length; index++) {
                const key = localStorage.key(index);
                if (!key || !key.startsWith("chapter-")) {
                    continue;
                }

                const bookId = key.slice("chapter-".length);
                const chapter = Number(localStorage.getItem(key));
                if (
                    /^[\w-]+$/.test(bookId) &&
                    Number.isInteger(chapter) &&
                    chapter >= 0
                ) {
                    data.readChapters[bookId] = Array.from(
                        { length: chapter },
                        (_, index) => index + 1
                    );
                    data.lastRead[bookId] = chapter;
                }
            }

            writeData(data);
        } catch (error) {
            console.error("Impossible de migrer les anciennes préférences :", error);
        }

        return data;
    }

    function readData() {
        try {
            const serialized = localStorage.getItem(storageKey);
            if (serialized === null) {
                return migrateLegacyData();
            }

            return normalizeData(JSON.parse(serialized));
        } catch (error) {
            console.error("Impossible de lire les préférences utilisateur :", error);
            return emptyData();
        }
    }

    window.BookStockPreferences = {
        getOptions() {
            return { ...readData().options };
        },

        saveOptions(options) {
            const data = readData();
            data.options = {
                fontScale: options.fontScale,
                lineScale: options.lineScale
            };
            writeData(data);
        },

        getProgress(bookId) {
            const data = readData();
            return data.readChapters[bookId]?.length || 0;
        },

        getLastRead(bookId) {
            const data = readData();
            return Object.prototype.hasOwnProperty.call(data.lastRead, bookId)
                ? data.lastRead[bookId]
                : null;
        },

        saveProgress(bookId, chapter) {
            if (
                !/^[\w-]+$/.test(bookId) ||
                !Number.isInteger(chapter) ||
                chapter < 0
            ) {
                throw new Error("Livre ou chapitre invalide pour la progression.");
            }

            const data = readData();
            const readChapters = data.readChapters[bookId] || [];
            if (chapter > 0 && !readChapters.includes(chapter)) {
                readChapters.push(chapter);
                readChapters.sort((first, second) => first - second);
            }
            data.readChapters[bookId] = readChapters;
            data.lastRead[bookId] = chapter;
            data.selectedBook = bookId;
            writeData(data);
        },

        saveLastRead(bookId, chapter) {
            if (
                !/^[\w-]+$/.test(bookId) ||
                !Number.isInteger(chapter) ||
                chapter < 0
            ) {
                throw new Error("Livre ou chapitre invalide pour le dernier chapitre lu.");
            }

            const data = readData();
            data.lastRead[bookId] = chapter;
            data.selectedBook = bookId;
            writeData(data);
        },

        getSelectedBook() {
            return readData().selectedBook;
        }
    };
})();
