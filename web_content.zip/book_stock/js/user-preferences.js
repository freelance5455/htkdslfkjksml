(function () {
    const storageKey = "book-stock-user-data";
    const legacyOptionsKey = "book-stock-reading-options";
    const defaultOptions = { fontScale: 1, lineScale: 1 };
    const limits = {
        fontScale: { min: 0.5, max: 2 },
        lineScale: { min: 0.8, max: 1.3 }
    };

    function validOption(value, limit) {
        return Number.isFinite(value) &&
            value >= limit.min &&
            value <= limit.max;
    }

    function emptyData() {
        return {
            version: 1,
            options: { ...defaultOptions },
            progress: {},
            selectedBook: ""
        };
    }

    function normalizeData(data) {
        const normalized = emptyData();
        if (!data || typeof data !== "object") {
            return normalized;
        }

        if (
            data.options &&
            validOption(data.options.fontScale, limits.fontScale) &&
            validOption(data.options.lineScale, limits.lineScale)
        ) {
            normalized.options = {
                fontScale: data.options.fontScale,
                lineScale: data.options.lineScale
            };
        }

        if (data.progress && typeof data.progress === "object") {
            Object.entries(data.progress).forEach(([bookId, chapter]) => {
                if (
                    /^[\w-]+$/.test(bookId) &&
                    Number.isInteger(chapter) &&
                    chapter >= 0
                ) {
                    normalized.progress[bookId] = chapter;
                }
            });
        }

        if (typeof data.selectedBook === "string") {
            normalized.selectedBook = data.selectedBook;
        }

        return normalized;
    }

    function writeData(data) {
        try {
            localStorage.setItem(storageKey, JSON.stringify(data));
        } catch (error) {
            console.error("Impossible d’enregistrer les préférences utilisateur :", error);
            throw error;
        }
    }

    function migrateLegacyData() {
        const data = emptyData();

        try {
            const legacyOptions = JSON.parse(
                localStorage.getItem(legacyOptionsKey)
            );
            if (
                legacyOptions &&
                validOption(legacyOptions.fontScale, limits.fontScale) &&
                validOption(legacyOptions.lineScale, limits.lineScale)
            ) {
                data.options = {
                    fontScale: legacyOptions.fontScale,
                    lineScale: legacyOptions.lineScale
                };
            }

            data.selectedBook = localStorage.getItem("selectedBook") || "";

            for (let index = 0; index < localStorage.length; index++) {
                const key = localStorage.key(index);
                if (!key || !key.startsWith("chapter-")) {
                    continue;
                }

                const bookId = key.slice("chapter-".length);
                const chapter = Number(localStorage.getItem(key));
                if (
                    /^[\w-]+$/.test(bookId) &&
                    Number.isInteger(chapter) &&
                    chapter >= 0
                ) {
                    data.progress[bookId] = chapter;
                }
            }

            writeData(data);
        } catch (error) {
            console.error("Impossible de migrer les anciennes préférences :", error);
        }

        return data;
    }

    function readData() {
        try {
            const serialized = localStorage.getItem(storageKey);
            if (serialized === null) {
                return migrateLegacyData();
            }

            return normalizeData(JSON.parse(serialized));
        } catch (error) {
            console.error("Impossible de lire les préférences utilisateur :", error);
            return emptyData();
        }
    }

    window.BookStockPreferences = {
        getOptions() {
            return { ...readData().options };
        },

        saveOptions(options) {
            const data = readData();
            data.options = {
                fontScale: options.fontScale,
                lineScale: options.lineScale
            };
            writeData(data);
        },

        getProgress(bookId) {
            const data = readData();
            return Object.prototype.hasOwnProperty.call(data.progress, bookId)
                ? data.progress[bookId]
                : null;
        },

        saveProgress(bookId, chapter) {
            if (
                !/^[\w-]+$/.test(bookId) ||
                !Number.isInteger(chapter) ||
                chapter < 0
            ) {
                throw new Error("Livre ou chapitre invalide pour la progression.");
            }

            const data = readData();
            data.progress[bookId] = chapter;
            data.selectedBook = bookId;
            writeData(data);
        },

        getSelectedBook() {
            return readData().selectedBook;
        }
    };
})();
