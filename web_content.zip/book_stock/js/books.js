const books = [
    {
        id: "livre1",
        title: "Blood Land",
        author: "Louis MATOSIN",
        chapterCount: 30,
        cover: "books/livre1/image/cover.jpg"
    }
];

const bookFolders = books.map(book => book.id);

async function loadBookCatalog() {
    return books;
}