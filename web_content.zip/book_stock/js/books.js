const books = [
    {
        id: "livre1",
        title: "Blood Land",
        author: "Louis MATOSIN",
        chapterCount: 30,
        cover: "books/livre1/image/cover.jpg",
        chapterWordCounts: {
            0: 149,
            1: 771,
            2: 771,
            3: 769,
            4: 1059,
            5: 1125,
            6: 1003,
            7: 1136,
            8: 1107,
            9: 1124,
            10: 1166,
            11: 1162,
            12: 1509,
            13: 1530,
            14: 1408,
            15: 1508,
            16: 1135,
            17: 1174,
            18: 2160,
            19: 1551,
            20: 2028,
            21: 3014,
            22: 2036,
            23: 2182,
            24: 2305,
            25: 1446,
            26: 1236,
            27: 6584,
            28: 2289,
            29: 3000,
            30: 1142
        }
    },
    {
        id: "livre2",
        title: "STILL OUT",
        author: "Louis MATOSIN",
        chapterCount: 1,
        cover: "books/livre2/image/cover.jpg",
        chapterWordCounts: {
            1: 4645
        }
    }
];

const bookFolders = books.map(book => book.id);

async function loadBookCatalog() {
    return books;
}