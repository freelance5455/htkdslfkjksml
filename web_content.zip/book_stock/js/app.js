const bookGrid = document.getElementById("bookGrid");

async function displayBooks() {

    const books = await loadBookCatalog();

    bookGrid.innerHTML = "";

    if (books.length === 0) {
        bookGrid.textContent = "Aucun livre disponible.";
        return;
    }

    books.forEach(book => {

        const card = document.createElement("a");
        card.className = "book";
        card.href = `book.html?book=${encodeURIComponent(book.id)}`;

        const cover = document.createElement("img");

        cover.src = book.cover;
        cover.alt = "Couverture de " + book.title;
        cover.loading = "lazy";

        const title = document.createElement("h2");
        title.textContent = book.title;

        const author = document.createElement("p");
        author.textContent = book.author;

        card.append(cover, title, author);
        bookGrid.appendChild(card);
    });
}

displayBooks().catch(error => {
    console.error("Impossible de charger la bibliothèque :", error);
    bookGrid.textContent = "Impossible de charger la bibliothèque.";
});