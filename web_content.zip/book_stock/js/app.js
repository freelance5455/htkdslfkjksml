const bookGrid = document.getElementById("bookGrid");

async function displayBooks() {

    const books = await loadBookCatalog();

    bookGrid.innerHTML = "";

    if (books.length === 0) {
        bookGrid.textContent = "Aucun livre disponible.";
        return;
    }

    books.forEach(book => {

        const card = document.createElement("a");
        card.className = "book";
        card.classList.add("is-entering");
        card.href = `book.html?book=${encodeURIComponent(book.id)}`;

        const cover = document.createElement("img");

        cover.src = book.cover;
        cover.alt = "Couverture de " + book.title;
        cover.loading = "lazy";

        const progressValue = Math.min(
            book.chapterCount,
            Math.max(0, BookStockPreferences.getProgress(book.id) || 0)
        );
        const progress = document.createElement("progress");
        progress.className = "book-progress-bar";
        if (progressValue === book.chapterCount) {
            progress.classList.add("is-complete");
        } else {
            progress.classList.add("is-in-progress");
        }
        progress.max = book.chapterCount;
        progress.value = progressValue;
        progress.setAttribute(
            "aria-label",
            `Progression de lecture : ${progressValue} sur ${book.chapterCount} chapitres`
        );

        const progressLabel = document.createElement("span");
        progressLabel.className = "book-progress-label";
        progressLabel.textContent =
            `${progressValue} / ${book.chapterCount} chapitres lus`;

        const progressSection = document.createElement("div");
        progressSection.className = "book-progress";
        progressSection.append(progress, progressLabel);

        const title = document.createElement("h2");
        title.textContent = book.title;

        const author = document.createElement("p");
        author.textContent = book.author;

        card.append(cover, progressSection, title, author);
        bookGrid.appendChild(card);
    });
}

displayBooks().catch(error => {
    console.error("Impossible de charger la bibliothèque :", error);
    bookGrid.textContent = "Impossible de charger la bibliothèque.";
});