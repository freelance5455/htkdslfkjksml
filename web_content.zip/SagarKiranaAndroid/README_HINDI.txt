SAGAR KIRANA STORE APK SOURCE PROJECT

यह APK-ready Android Studio project है। इस ZIP में दुकान का HTML ऐप assets/index.html के अंदर रखा है।

मोबाइल पर APK बनाने का सरल तरीका:
1) ZIP को extract करें।
2) Android Studio (कंप्यूटर) में SagarKiranaAndroid folder खोलें।
3) Gradle sync पूरा होने दें।
4) Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
5) APK app/build/outputs/apk/debug/app-debug.apk में मिलेगा।

नोट:
- यह source project है, compiled APK file नहीं।
- WhatsApp order feature के लिए HTML में STORE_WHATSAPP में दुकान का सही नंबर country code सहित भरना होगा।
- Demo PIN/admin controls यदि HTML में मौजूद हैं तो local device/browser तक सीमित हैं; यह multi-device secure server admin नहीं है।
- Product prices are demo values; actual shop prices must be updated.
