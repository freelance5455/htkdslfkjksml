TESSA AI STARTER PROJECT

This ZIP contains a simple HTML/CSS/JavaScript assistant interface.

Included:
- Time and date replies
- Text-to-speech where supported
- Optional browser speech recognition where supported
- Links that try to open YouTube and WhatsApp

Important:
This is a web app starter, not a complete native Android assistant.
It does not provide a reliable always-listening "Hi Tessa" wake word, locked-screen listening, or unrestricted access to contacts/files.
A ZIP-to-APK converter may not accept this project ZIP directly. Use a reputable HTML-to-APK/WebView builder that explicitly supports HTML/CSS/JavaScript projects, and review its permissions and privacy terms before uploading files.
