const statusEl = document.getElementById('status');
const form = document.getElementById('command-form');
const input = document.getElementById('command');
const listenButton = document.getElementById('listen');

function speak(text) {
  statusEl.textContent = text;
  if ('speechSynthesis' in window) {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1;
    window.speechSynthesis.speak(utterance);
  }
}
function handleCommand(raw) {
  const command = raw.toLowerCase().trim();
  if (!command) return;
  if (command.includes('time')) {
    speak('The time is ' + new Date().toLocaleTimeString([], {hour:'numeric', minute:'2-digit'}));
  } else if (command.includes('date') || command.includes('day')) {
    speak('Today is ' + new Date().toLocaleDateString([], {weekday:'long', year:'numeric', month:'long', day:'numeric'}));
  } else if (command.includes('open youtube')) {
    speak('Opening YouTube.');
    window.location.href = 'https://www.youtube.com/';
  } else if (command.includes('open whatsapp')) {
    speak('Trying to open WhatsApp.');
    window.location.href = 'https://wa.me/';
  } else if (command.includes('hello') || command.includes('hi tessa')) {
    speak('Hello! TESSA is ready. What do you need?');
  } else {
    speak('I can currently tell the time or date, and try opening YouTube or WhatsApp. More features can be added next.');
  }
}
form.addEventListener('submit', event => {
  event.preventDefault();
  handleCommand(input.value);
  input.value = '';
});
listenButton.addEventListener('click', () => {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    speak('Voice recognition is not supported in this browser. Please type your command instead.');
    return;
  }
  const recognition = new SpeechRecognition();
  recognition.lang = 'en-NG';
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;
  statusEl.textContent = 'Listening…';
  recognition.onresult = event => handleCommand(event.results[0][0].transcript);
  recognition.onerror = () => speak('I could not hear that. Try again or type your command.');
  recognition.start();
});
