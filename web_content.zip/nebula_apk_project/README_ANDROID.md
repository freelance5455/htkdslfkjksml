# Nébula AI — proyecto Android inicial

Este proyecto envuelve la versión web de Nébula AI en una aplicación Android con WebView. Es el **código fuente del proyecto Android**, no un APK ya compilado.

## Cómo generar el APK
1. Instala Android Studio en un ordenador.
2. Abre esta carpeta como proyecto existente.
3. Deja que Android Studio sincronice Gradle e instale el Android SDK 35 si lo solicita.
4. Ve a **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. El APK de prueba aparecerá normalmente en `app/build/outputs/apk/debug/app-debug.apk`.

## Requisitos y límites
- La app necesita conexión a internet para cargar Puter.js y llamar a los modelos disponibles.
- La disponibilidad de los modelos Grok depende de Puter y de la cuenta/proveedor; los identificadores de modelo pueden cambiar o no estar habilitados.
- Este proyecto aún no está compilado ni probado en un dispositivo Android. Antes de distribuirlo, hay que probar inicio de sesión, llamadas al modelo, almacenamiento y políticas de privacidad.
- Roleplay adulto: el diseño puede orientarse a usuarios adultos y a ficción madura entre adultos que consienten, pero las respuestas reales siguen sujetas a las reglas del modelo y del proveedor. No se promete contenido sin límites.
