# Nébula AI — Roleplay build

PWA móvil en español enfocada en narración interactiva. Incluye:
- Roleplay con prompt de sistema dedicado a continuidad, agencia del personaje del usuario, personajes con objetivos y progresión de escenas.
- Configuración de género, premisa, personaje del usuario, personaje de la IA y estilo narrativo.
- Fichas de personajes guardadas localmente.
- Constructor de mundos con reglas persistentes.
- Crónica/resumen de continuidad asistido por el modelo.
- Exportación de historia a TXT.
- Selector de modelos Grok de los identificadores compartidos.
- PWA: manifest, icono y service worker.

## Ejecutar
Servir por HTTP/HTTPS, no abrir como `file://`. Por ejemplo: `npx serve .`

## Instalar en Android
Publica todos los archivos en hosting HTTPS, abre la URL en Chrome Android y selecciona Instalar aplicación / Añadir a pantalla de inicio.

## Limitaciones de esta versión
- Requiere conexión para hablar con modelos.
- La disponibilidad de los modelos y las funciones depende de Puter.js y del proveedor.
- Los datos se guardan localmente en el navegador; no hay sincronización ni cuenta de usuario.
- La crónica es memoria resumida; no es memoria infinita perfecta. Revisa/edita el resumen para conservar los hechos esenciales.
- La app permite mucha libertad narrativa, pero no puede garantizar “sin ningún límite” ni saltarse las reglas del proveedor/modelo.
- No contiene claves secretas propias en el frontend; utiliza el SDK de Puter.js.
