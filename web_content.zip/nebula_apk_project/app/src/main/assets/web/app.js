(() => {
const $=id=>document.getElementById(id);
const MODEL_LABELS={"x-ai/grok-4.7":"Grok 4.7","x-ai/grok-4.6":"Grok 4.6","x-ai/grok-4.5":"Grok 4.5","x-ai/grok-4.3":"Grok 4.3","x-ai/grok-4.20":"Grok 4.20","x-ai/grok-4-1-fast-reasoning":"Grok 4.1 Fast Reasoning","x-ai/grok-4-1-fast-non-reasoning":"Grok 4.1 Fast","x-ai/grok-2":"Grok 2"};
let model=localStorage.getItem("nebula-roleplay-model")||"x-ai/grok-4.7", busy=false, page="roleplay";
let story=load("nebula-roleplay-current",{setup:null,turns:[],chronicle:""});
let characters=load("nebula-roleplay-characters",[]);
let world=load("nebula-roleplay-world",{name:"",description:"",rules:""});
let recap=story.chronicle||"";
function load(k,d){try{return JSON.parse(localStorage.getItem(k))??d}catch{return d}}
function save(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch{notify("No se pudo guardar. Quizá el almacenamiento está lleno.")}}
function notify(t){$("toast").textContent=t;$("toast").classList.add("show");clearTimeout(notify.timer);notify.timer=setTimeout(()=>$("toast").classList.remove("show"),2800)}
function setStatus(t){$("status").textContent=t}
function ready(){if(!window.puter?.ai){notify("Puter.js no cargó. Comprueba internet.");setStatus("Puter.js no disponible");return false}return true}
function setBusy(v){busy=v;$("sendAction").disabled=v;$("beginStory").disabled=v;$("sendAction").textContent=v?"…":"↑"}
function labelModel(){return MODEL_LABELS[model]||model}
function updateModel(){ $("modelName").textContent=labelModel();$("modelSelect").value=model}
function showPage(p){page=p;const ids={roleplay:"roleplayPage",characters:"charactersPage",world:"worldPage",chronicle:"chroniclePage"};Object.entries(ids).forEach(([k,id])=>$(id).classList.toggle("hidden",k!==p));document.querySelectorAll(".nav").forEach(b=>b.classList.toggle("active",b.dataset.page===p));$("pageTitle").textContent=({roleplay:"Roleplay libre",characters:"Personajes",world:"Constructor de mundos",chronicle:"Crónica e historia"})[p];$("sidebar").classList.remove("open")}
function systemPrompt(){
const s=story.setup||{};
const charText=characters.map(c=>`Personaje guardado: ${c.name}\nPersonalidad/voz: ${c.personality}\nObjetivos/miedos/secretos: ${c.secrets}`).join("\n\n");
return `Eres Nébula, un motor de narración interactiva y roleplay. Tu prioridad es crear una experiencia inmersiva, coherente, creativa y emocionalmente rica.
REGLAS DE ROLEPLAY:
- Narra en español salvo que el usuario pida otro idioma. Sigue el género, el tono y las reglas del mundo.
- El usuario controla exclusivamente a su personaje. No decidas sus pensamientos, palabras, sentimientos ni acciones importantes; deja espacio para que responda.
- Interpreta a los demás personajes con voces distintas, motivaciones, defectos, límites, recuerdos y objetivos propios. No hagas que todos estén de acuerdo con el usuario.
- Haz avanzar la escena: introduce consecuencias, cambios, tensión, detalles sensoriales y oportunidades de decisión. Evita resolver todo en una sola respuesta.
- Mantén continuidad de nombres, lugares, relaciones, heridas, objetos, promesas y acontecimientos. No reinicies la historia ni contradigas hechos establecidos sin motivo narrativo.
- No hables de ser una IA ni rompas la inmersión salvo que el usuario lo solicite. Evita finales genéricos como "¿qué haces ahora?" si la escena ya ofrece un punto claro de respuesta.
- Usa prosa y diálogos naturales, ajustados al estilo solicitado. No conviertas cada respuesta en una lista. No controles al personaje del usuario.
- La ficción puede explorar temas intensos y conflictos dramáticos, respetando límites de seguridad y sin presentar la ficción como instrucciones reales para causar daño.
CONFIGURACIÓN DE ESTA HISTORIA:
Género/ambiente: ${s.genre||"libre"}
Premisa: ${s.premise||"A construir con el usuario"}
Personaje del usuario: ${s.player||"Aún no definido"}
Personaje central de la IA: ${s.npc||"Personajes originales según la escena"}
Estilo: ${s.style||"Inmersivo y cinematográfico"}
MUNDO GUARDADO:
${world.name?`Nombre: ${world.name}\nDescripción: ${world.description}\nReglas: ${world.rules}`:"No hay un mundo guardado."}
PERSONAJES GUARDADOS:
${charText||"Ninguno por ahora."}
CRÓNICA / HECHOS ANTERIORES:
${story.chronicle||"La historia acaba de comenzar."}
Estas instrucciones orientan la narración; si el usuario define explícitamente una nueva dirección creativa, incorpórala manteniendo la continuidad.`;
}
function renderTurns(){
const root=$("transcript");root.replaceChildren();
for(const t of story.turns){const row=document.createElement("div");row.className="turn";const icon=document.createElement("div");icon.className="turn-icon";icon.textContent=t.role==="user"?"◉":"✦";const main=document.createElement("div");main.className="turn-main";const name=document.createElement("div");name.className="turn-name";name.textContent=t.role==="user"?"TU PERSONAJE":"NÉBULA · NARRACIÓN";const txt=document.createElement("div");txt.className="turn-text"+(t.role==="user"?" user":"");txt.textContent=t.content;main.append(name,txt);row.append(icon,main);root.append(row)}
root.scrollTop=root.scrollHeight;
}
function enterStory(){
const s={genre:$("genre").value.trim()||"Libre",premise:$("premise").value.trim(),player:$("player").value.trim()||"Personaje del usuario",npc:$("npc").value.trim()||"Personajes del mundo",style:$("style").value};
story={setup:s,turns:[],chronicle:""};save("nebula-roleplay-current",story);$("storyHeading").textContent=s.genre; $("intro").classList.add("hidden");$("setup").classList.add("hidden");$("playArea").classList.remove("hidden");renderTurns();
const starter="Comienza la primera escena de esta historia. Presenta el entorno y una situación interesante, introduce a los personajes necesarios y termina en un momento abierto para que el usuario pueda actuar. No decidas las acciones del personaje del usuario.";
sendTurn(starter,true);
}
async function sendTurn(text,opening=false){
if(busy)return;if(!ready())return;
if(!story.setup){$("setup").classList.remove("hidden");$("intro").classList.add("hidden");return}
const content=text.trim();if(!content)return;
story.turns.push({role:"user",content:opening?"[INSTRUCCIÓN DE INICIO DE ESCENA] "+content:content});
renderTurns();save("nebula-roleplay-current",story);$("actionInput").value="";setBusy(true);setStatus("La historia está tomando forma…");
const placeholder={role:"assistant",content:"La escena continúa…"};story.turns.push(placeholder);renderTurns();
try{
const prior=story.turns.slice(-30).map(t=>({role:t.role,content:t.content}));
const messages=[{role:"system",content:systemPrompt()},...prior];
const response=await puter.ai.chat(messages,{model});
const answer=response?.message?.content??response?.content??"El modelo devolvió una respuesta vacía.";
story.turns[story.turns.length-1]={role:"assistant",content:String(answer)};
save("nebula-roleplay-current",story);setStatus("Historia en curso · "+labelModel());
}catch(e){story.turns.pop();story.turns.pop();story.turns.push({role:"assistant",content:"No se pudo continuar el roleplay: "+(e?.message||String(e))+"\nComprueba la conexión y la disponibilidad del modelo."});setStatus("Error de conexión");}
finally{renderTurns();save("nebula-roleplay-current",story);setBusy(false);$("actionInput").focus()}
}
function showSetup(){ $("intro").classList.add("hidden");$("playArea").classList.add("hidden");$("setup").classList.remove("hidden");$("genre").value=story.setup?.genre||"Fantasía oscura";$("premise").value=story.setup?.premise||"";$("player").value=story.setup?.player||"";$("npc").value=story.setup?.npc||"";if(story.setup?.style)$("style").value=story.setup.style}
function renderCharacters(){const root=$("characterList");root.replaceChildren();characters.forEach((c,i)=>{const card=document.createElement("div");card.className="character-card";const h=document.createElement("h3");h.textContent=c.name;const p=document.createElement("p");p.textContent="Personalidad: "+c.personality+"\n\nObjetivos y secretos: "+c.secrets;const del=document.createElement("button");del.className="secondary";del.textContent="Eliminar";del.onclick=()=>{characters.splice(i,1);save("nebula-roleplay-characters",characters);renderCharacters()};card.append(h,p,del);root.append(card)})}
document.querySelectorAll("[data-page]").forEach(b=>b.addEventListener("click",()=>showPage(b.dataset.page)));
$("hamb").onclick=()=>$("sidebar").classList.toggle("open");
$("setupStart").onclick=showSetup;$("newStory").onclick=()=>{story={setup:null,turns:[],chronicle:""};save("nebula-roleplay-current",story);showPage("roleplay");$("intro").classList.remove("hidden");$("setup").classList.add("hidden");$("playArea").classList.add("hidden")};
$("backIntro").onclick=()=>{$("setup").classList.add("hidden");$("intro").classList.remove("hidden")};
$("beginStory").onclick=enterStory;
document.querySelectorAll("[data-genre]").forEach(b=>b.onclick=()=>{$("genre").value=b.dataset.genre;showSetup()});
$("sendAction").onclick=()=>sendTurn($("actionInput").value);
$("actionInput").addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();sendTurn($("actionInput").value)}});
$("saveCharacter").onclick=()=>{const name=$("charName").value.trim();if(!name){notify("Ponle un nombre al personaje.");return}characters.push({name,personality:$("charPersonality").value.trim(),secrets:$("charSecrets").value.trim()});save("nebula-roleplay-characters",characters);$("charName").value="";$("charPersonality").value="";$("charSecrets").value="";renderCharacters();notify("Personaje guardado en este dispositivo.")};
$("saveWorld").onclick=()=>{world={name:$("worldName").value.trim(),description:$("worldDescription").value.trim(),rules:$("worldRules").value.trim()};save("nebula-roleplay-world",world);$("worldSaved").textContent="Mundo guardado: "+world.name+"\nSe incluirá en las instrucciones de nuevas respuestas.";notify("Mundo guardado.")};
$("recapBtn").onclick=async()=>{if(!story.turns.length){notify("Todavía no hay escenas que resumir.");return}if(!ready())return;setBusy(true);setStatus("Resumiendo continuidad…");try{const transcript=story.turns.map(t=>(t.role==="user"?"USUARIO":"NÉBULA")+": "+t.content).join("\n\n");const r=await puter.ai.chat([{role:"system",content:"Resume una historia de roleplay en español para conservar continuidad. Incluye cronología breve, personajes y relaciones, hechos confirmados, objetos, secretos revelados, conflictos pendientes y el punto exacto donde quedó la escena. No inventes datos."},{role:"user",content:transcript}],{model});story.chronicle=r?.message?.content??"";save("nebula-roleplay-current",story);$("chronicleText").value=story.chronicle;recap=story.chronicle;notify("Crónica creada.")}catch(e){notify("No se pudo resumir: "+(e?.message||String(e)))}finally{setBusy(false);setStatus("Lista para crear")}};
$("saveChronicle").onclick=()=>{story.chronicle=$("chronicleText").value;save("nebula-roleplay-current",story);notify("Crónica guardada y lista para futuras escenas.")};
$("exportStory").onclick=()=>{const text=(story.setup?`NÉBULA AI — ${story.setup.genre}\nPremisa: ${story.setup.premise}\nTu personaje: ${story.setup.player}\nPersonaje de la IA: ${story.setup.npc}\n\n`:"")+story.turns.map(t=>(t.role==="user"?"TÚ":"NÉBULA")+"\n"+t.content).join("\n\n")+"\n\nCRÓNICA\n"+(story.chronicle||"Sin crónica");const blob=new Blob([text],{type:"text/plain;charset=utf-8"});const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download="nebula-historia.txt";a.click();URL.revokeObjectURL(url)};
$("settingsBtn").onclick=$("modelBtn").onclick=()=>$("settingsModal").classList.remove("hidden");$("closeSettings").onclick=()=>$("settingsModal").classList.add("hidden");$("settingsModal").onclick=e=>{if(e.target===$("settingsModal"))$("settingsModal").classList.add("hidden")};$("saveModel").onclick=()=>{model=$("modelSelect").value;localStorage.setItem("nebula-roleplay-model",model);updateModel();$("settingsModal").classList.add("hidden");notify("Modelo seleccionado: "+labelModel())};
updateModel();renderCharacters();
if(world.name){$("worldName").value=world.name;$("worldDescription").value=world.description;$("worldRules").value=world.rules;$("worldSaved").textContent="Mundo guardado: "+world.name}
$("chronicleText").value=story.chronicle||"";
if(story.setup){$("intro").classList.add("hidden");$("setup").classList.add("hidden");$("playArea").classList.remove("hidden");$("storyHeading").textContent=story.setup.genre;renderTurns()} 
if("serviceWorker"in navigator&&location.protocol.startsWith("http"))addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));
addEventListener("online",()=>setStatus("Conexión disponible"));addEventListener("offline",()=>setStatus("Sin conexión"));
})();