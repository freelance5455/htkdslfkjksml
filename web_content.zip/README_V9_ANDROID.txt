V9 Android Fix

این نسخه برای جلوگیری از خطای appassets.androidplatform.net ساخته شده است.
MainActivity مستقیماً file:///android_asset/index.html را باز می‌کند و دسترسی فایل WebView فعال است.
فایل index.html داخل android/app/src/main/assets قرار دارد.
برای ساخت APK از Android Studio پروژه android را باز کنید و Build APK بزنید.
