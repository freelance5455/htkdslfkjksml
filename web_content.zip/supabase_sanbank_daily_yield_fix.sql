-- Liquidação diária do CDI pelo servidor: sessão do próprio cliente, trava por conta,
-- crédito e extrato na mesma transação, sem escrituras financeiras feitas pelo APK.
BEGIN;

CREATE TABLE IF NOT EXISTS public.sanbank_yield_state (
  account text PRIMARY KEY REFERENCES public.sanbank_accounts(account) ON DELETE CASCADE,
  eligible_principal numeric(18,2) NOT NULL DEFAULT 0,
  observed_balance numeric(18,2) NOT NULL DEFAULT 0,
  idle_since timestamptz NOT NULL DEFAULT now(),
  last_settled_at timestamptz,
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.sanbank_yield_state ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.sanbank_yield_state FROM PUBLIC, anon, authenticated;

CREATE OR REPLACE FUNCTION public.sanbank_settle_daily_yield()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
DECLARE
  v_me text := public.sanbank_current_account();
  v_now timestamptz := clock_timestamp();
  v_account public.sanbank_accounts%ROWTYPE;
  v_state public.sanbank_yield_state%ROWTYPE;
  v_config public.sanbank_yield_config%ROWTYPE;
  v_config_payload jsonb := '{}'::jsonb;
  v_balance numeric(18,2);
  v_new_balance numeric(18,2);
  v_principal numeric(18,2);
  v_annual_percent numeric;
  v_product_percent numeric;
  v_grace_hours numeric;
  v_daily_rate numeric;
  v_period_start timestamptz;
  v_due_at timestamptz;
  v_days numeric;
  v_amount numeric(18,2) := 0;
  v_estimated_accrued numeric(18,6) := 0;
  v_settlement_id text;
  v_statement_payload jsonb;
  v_history_payload jsonb;
  v_history jsonb := '[]'::jsonb;
  v_next_extrato integer;
  v_next_history integer;
  v_credited boolean := false;
  v_reason text := 'sem_saldo_elegivel';
  v_idle_iso text;
  v_settled_iso text;
  v_due_iso text;
BEGIN
  IF v_me IS NULL THEN
    RAISE EXCEPTION 'SANBANK_SESSION_REQUIRED';
  END IF;
  IF public.sanbank_is_admin() THEN
    RETURN jsonb_build_object('ok', true, 'credited', false, 'reason', 'conta_administrativa');
  END IF;

  SELECT * INTO v_account
  FROM public.sanbank_accounts
  WHERE account = v_me
  FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'SANBANK_ACCOUNT_NOT_FOUND'; END IF;
  v_now := clock_timestamp();
  v_balance := greatest(coalesce(v_account.balance, 0), 0);

  -- A configuração administrativa mais recente (registro legado) tem prioridade.
  SELECT r.payload INTO v_config_payload
  FROM public.sanbank_legacy_records r
  WHERE r.source_tab = 'configuracoes_rendimento'
    AND coalesce(r.legacy_id, r.payload->>'id') = 'BALANCE_YIELD'
  ORDER BY r.source_row DESC
  LIMIT 1;

  SELECT * INTO v_config
  FROM public.sanbank_yield_config
  WHERE id = 'BALANCE_YIELD';

  BEGIN
    v_annual_percent := nullif(v_config_payload->>'cdi_annual_rate', '')::numeric;
  EXCEPTION WHEN OTHERS THEN v_annual_percent := NULL;
  END;
  IF v_annual_percent IS NULL THEN v_annual_percent := v_config.cdi_annual_rate; END IF;
  -- O cliente existente já normaliza taxas acima de 100% para a referência padrão.
  IF v_annual_percent IS NULL OR v_annual_percent <= 0 OR v_annual_percent > 100 THEN
    v_annual_percent := 14.65;
  END IF;

  BEGIN
    v_product_percent := nullif(v_config_payload->>'product_percent', '')::numeric;
  EXCEPTION WHEN OTHERS THEN v_product_percent := NULL;
  END;
  IF v_product_percent IS NULL THEN v_product_percent := coalesce(v_config.product_percent, 102); END IF;
  IF v_product_percent <= 0 OR v_product_percent > 200 THEN v_product_percent := 102; END IF;

  BEGIN
    v_grace_hours := nullif(v_config_payload->>'grace_hours', '')::numeric;
  EXCEPTION WHEN OTHERS THEN v_grace_hours := NULL;
  END;
  IF v_grace_hours IS NULL THEN v_grace_hours := coalesce(v_config.grace_hours, 24); END IF;
  IF v_grace_hours < 0 OR v_grace_hours > 720 THEN v_grace_hours := 24; END IF;

  INSERT INTO public.sanbank_yield_state(account, eligible_principal, observed_balance, idle_since, updated_at)
  VALUES (v_me, v_balance, v_balance, v_now, v_now)
  ON CONFLICT (account) DO NOTHING;

  SELECT * INTO v_state
  FROM public.sanbank_yield_state
  WHERE account = v_me
  FOR UPDATE;

  -- Qualquer mudança externa de saldo reinicia a carência com o saldo positivo atual.
  -- O bloqueio da conta e do estado evita créditos duplicados em chamadas concorrentes.
  IF abs(v_balance - coalesce(v_state.observed_balance, 0)) >= 0.005 THEN
    v_state.eligible_principal := v_balance;
    v_state.observed_balance := v_balance;
    v_state.idle_since := v_now;
    v_state.updated_at := v_now;
    UPDATE public.sanbank_yield_state
       SET eligible_principal = v_state.eligible_principal,
           observed_balance = v_state.observed_balance,
           idle_since = v_state.idle_since,
           updated_at = v_now
     WHERE account = v_me;
  END IF;

  v_principal := greatest(coalesce(v_state.eligible_principal, 0), 0);
  v_due_at := v_state.idle_since + make_interval(secs => (v_grace_hours * 3600)::double precision);
  v_daily_rate := (power(1::numeric + v_annual_percent / 100, 1::numeric / 365) - 1)
                  * v_product_percent / 100;

  IF v_principal <= 0 THEN
    v_reason := 'sem_saldo_elegivel';
  ELSIF v_now < v_due_at THEN
    v_reason := 'aguardando_carencia';
  ELSIF v_state.last_settled_at IS NOT NULL
        AND v_now < v_state.last_settled_at + interval '24 hours' THEN
    v_reason := 'aguardando_proxima_liquidacao';
  ELSE
    v_period_start := greatest(v_due_at, coalesce(v_state.last_settled_at, v_due_at));
    v_days := greatest(extract(epoch FROM (v_now - v_period_start)) / 86400, 0);
    v_amount := round(v_principal * (power(1::numeric + v_daily_rate, v_days) - 1), 2);
    IF v_amount < 0.01 THEN
      v_amount := 0;
      v_reason := 'rendimento_abaixo_de_um_centavo';
    ELSE
      v_settlement_id := 'CDI-' || v_me || '-' || to_char(v_now AT TIME ZONE 'UTC', 'YYYY-MM-DD');
      IF EXISTS (
        SELECT 1 FROM public.sanbank_legacy_records r
        WHERE r.source_tab = 'extrato'
          AND (r.legacy_id = v_settlement_id OR r.payload->>'id' = v_settlement_id)
      ) OR EXISTS (
        SELECT 1 FROM public.sanbank_statements s WHERE s.id = v_settlement_id
      ) OR EXISTS (
        SELECT 1 FROM public.sanbank_yield_history h WHERE h.id = v_settlement_id
      ) THEN
        v_state.last_settled_at := v_now;
        v_state.updated_at := v_now;
        UPDATE public.sanbank_yield_state
           SET last_settled_at = v_now, updated_at = v_now
         WHERE account = v_me;
        v_amount := 0;
        v_reason := 'liquidacao_ja_registrada';
      ELSE
        v_new_balance := round(v_account.balance + v_amount, 2);
        v_statement_payload := jsonb_build_object(
          'id', v_settlement_id,
          'account', v_me,
          'type', 'in',
          'title', 'Rendimento CDI 102%',
          'description', 'Rendimento CDI com liquidez diária após a carência configurada de 24 horas.',
          'amount', v_amount,
          'date', to_char(v_now AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"'),
          'transaction_type', 'RENDIMENTO_CDI',
          'yield_rate', v_product_percent::text || '% CDI',
          'yield_liquidity', 'diária',
          'yield_period_start', to_char(v_period_start AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"'),
          'yield_period_end', to_char(v_now AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"'),
          'yield_principal', v_principal
        );
        v_history_payload := jsonb_build_object(
          'id', v_settlement_id,
          'account', v_me,
          'amount', v_amount,
          'date', to_char(v_now AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"'),
          'yield_rate', v_product_percent::text || '% CDI',
          'yield_period_start', to_char(v_period_start AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"'),
          'yield_period_end', to_char(v_now AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"'),
          'yield_principal', v_principal
        );

        -- Serializa a alocação source_row dos dois históricos legados.
        LOCK TABLE public.sanbank_legacy_records IN SHARE ROW EXCLUSIVE MODE;
        UPDATE public.sanbank_accounts
           SET balance = v_new_balance,
               updated_at = v_now
         WHERE account = v_me;

        INSERT INTO public.sanbank_statements(id, account, type, title, description, amount, date, transaction_type, legacy_data)
        VALUES (v_settlement_id, v_me, 'in', 'Rendimento CDI 102%', v_statement_payload->>'description', v_amount,
                v_statement_payload->>'date', 'RENDIMENTO_CDI', v_statement_payload)
        ON CONFLICT (id) DO NOTHING;

        INSERT INTO public.sanbank_yield_history(id, account, amount, date, legacy_data)
        VALUES (v_settlement_id, v_me, v_amount, v_statement_payload->>'date', v_history_payload)
        ON CONFLICT (id) DO NOTHING;

        SELECT coalesce(max(source_row), 0) + 1 INTO v_next_extrato
        FROM public.sanbank_legacy_records WHERE source_tab = 'extrato';
        INSERT INTO public.sanbank_legacy_records(source_tab, source_row, legacy_id, account, payload)
        VALUES ('extrato', v_next_extrato, v_settlement_id, v_me, v_statement_payload);

        SELECT coalesce(max(source_row), 0) + 1 INTO v_next_history
        FROM public.sanbank_legacy_records WHERE source_tab = 'historico_rendimento_cdi';
        INSERT INTO public.sanbank_legacy_records(source_tab, source_row, legacy_id, account, payload)
        VALUES ('historico_rendimento_cdi', v_next_history, v_settlement_id, v_me, v_history_payload);

        v_state.eligible_principal := round(v_principal + v_amount, 2);
        v_state.observed_balance := v_new_balance;
        v_state.last_settled_at := v_now;
        v_state.updated_at := v_now;
        UPDATE public.sanbank_yield_state
           SET eligible_principal = v_state.eligible_principal,
               observed_balance = v_state.observed_balance,
               last_settled_at = v_state.last_settled_at,
               updated_at = v_now
         WHERE account = v_me;

        v_balance := v_new_balance;
        v_principal := v_state.eligible_principal;
        v_credited := true;
        v_reason := 'rendimento_creditado';
      END IF;
    END IF;
  END IF;

  v_idle_iso := to_char(v_state.idle_since AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"');
  v_settled_iso := CASE WHEN v_state.last_settled_at IS NULL THEN ''
    ELSE to_char(v_state.last_settled_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"') END;
  v_due_at := greatest(v_state.idle_since + make_interval(secs => (v_grace_hours * 3600)::double precision),
                       coalesce(v_state.last_settled_at + interval '24 hours', v_state.idle_since + make_interval(secs => (v_grace_hours * 3600)::double precision)));
  v_due_iso := to_char(v_due_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"');
  v_period_start := greatest(v_state.idle_since + make_interval(secs => (v_grace_hours * 3600)::double precision),
                             coalesce(v_state.last_settled_at, v_state.idle_since + make_interval(secs => (v_grace_hours * 3600)::double precision)));
  IF v_principal > 0 AND v_now > v_due_at THEN
    v_days := greatest(extract(epoch FROM (v_now - v_period_start)) / 86400, 0);
    v_estimated_accrued := greatest(v_principal * (power(1::numeric + v_daily_rate, v_days) - 1), 0);
  END IF;

  SELECT coalesce(jsonb_agg(q.record ORDER BY q.source_row DESC), '[]'::jsonb)
    INTO v_history
  FROM (
    SELECT r.source_row,
           r.payload || jsonb_build_object('id', coalesce(r.payload->>'id', r.legacy_id), 'account', coalesce(r.payload->>'account', r.account)) AS record
    FROM public.sanbank_legacy_records r
    WHERE r.source_tab = 'historico_rendimento_cdi'
      AND coalesce(r.account, r.payload->>'account') = v_me
    ORDER BY r.source_row DESC
    LIMIT 30
  ) q;

  RETURN jsonb_build_object(
    'ok', true,
    'credited', v_credited,
    'reason', v_reason,
    'amount', v_amount,
    'estimated_accrued', v_estimated_accrued,
    'balance', v_balance,
    'eligible_balance', v_principal,
    'cdi_annual_rate', v_annual_percent,
    'product_percent', v_product_percent,
    'grace_hours', v_grace_hours,
    'idle_since', v_idle_iso,
    'last_settled_at', v_settled_iso,
    'next_settlement_at', v_due_iso,
    'history', v_history
  );
END;
$$;

REVOKE ALL ON FUNCTION public.sanbank_settle_daily_yield() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.sanbank_settle_daily_yield() TO anon, authenticated;

COMMIT;
