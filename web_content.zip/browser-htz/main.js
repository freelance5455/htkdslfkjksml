const { app, BrowserWindow, session, ipcMain, shell } = require('electron');
const path = require('path');

// ---------- Velocidade ----------
app.commandLine.appendSwitch('enable-gpu-rasterization');
app.commandLine.appendSwitch('enable-zero-copy');
app.commandLine.appendSwitch('ignore-gpu-blocklist');
app.commandLine.appendSwitch('enable-features', 'VaapiVideoDecoder,CanvasOopRasterization');
app.commandLine.appendSwitch('disable-features', 'Translate,MediaRouter');

const PARTITION = 'persist:htz';

// Bloqueio leve de anúncios/rastreadores (acelera o carregamento)
const BLOCKED = [
  'doubleclick.net', 'googlesyndication.com', 'googleadservices.com',
  'google-analytics.com', 'googletagmanager.com', 'adservice.google.com',
  'facebook.net', 'connect.facebook.net', 'scorecardresearch.com',
  'taboola.com', 'outbrain.com', 'adnxs.com', 'criteo.com', 'hotjar.com',
  'ads.yahoo.com', 'amazon-adsystem.com', 'moatads.com', 'quantserve.com'
];
let blockEnabled = true;

let mainWindow;

function setupSession() {
  const ses = session.fromPartition(PARTITION);

  // User-Agent de Chrome normal (o Google não aceita "Electron" no login)
  const ua = ses.getUserAgent()
    .replace(/\sElectron\/[\d.]+/, '')
    .replace(/\s?browser-htz\/[\d.]+/i, '')
    .replace(/\s?Browser HTZ\/[\d.]+/i, '');
  ses.setUserAgent(ua);

  ses.webRequest.onBeforeRequest((details, callback) => {
    if (!blockEnabled) return callback({});
    try {
      const host = new URL(details.url).hostname;
      const hit = BLOCKED.some((d) => host === d || host.endsWith('.' + d));
      callback({ cancel: hit });
    } catch {
      callback({});
    }
  });

  ses.setPermissionRequestHandler((wc, permission, cb) => {
    const ok = ['fullscreen', 'clipboard-read', 'clipboard-sanitized-write', 'media', 'notifications'];
    cb(ok.includes(permission));
  });
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 700,
    minHeight: 450,
    backgroundColor: '#0f1115',
    title: 'Browser HTZ',
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      webviewTag: true,
      spellcheck: true
    }
  });

  mainWindow.setMenuBarVisibility(false);
  mainWindow.loadFile(path.join(__dirname, 'index.html'));
}

// Links que abrem nova janela dentro de uma aba -> viram nova aba
app.on('web-contents-created', (_e, contents) => {
  if (contents.getType() === 'webview') {
    contents.setWindowOpenHandler(({ url }) => {
      if (/^https?:/i.test(url) && mainWindow) {
        mainWindow.webContents.send('open-url', url);
      }
      return { action: 'deny' };
    });
  }
});

ipcMain.handle('set-block', (_e, value) => {
  blockEnabled = !!value;
  return blockEnabled;
});

ipcMain.handle('clear-data', async () => {
  const ses = session.fromPartition(PARTITION);
  await ses.clearCache();
  await ses.clearStorageData();
  return true;
});

ipcMain.handle('open-external', (_e, url) => {
  if (/^https?:/i.test(url)) shell.openExternal(url);
});

app.whenReady().then(() => {
  setupSession();
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
