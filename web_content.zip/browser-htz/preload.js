const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('htz', {
  onOpenUrl: (cb) => ipcRenderer.on('open-url', (_e, url) => cb(url)),
  setBlock: (v) => ipcRenderer.invoke('set-block', v),
  clearData: () => ipcRenderer.invoke('clear-data'),
  openExternal: (url) => ipcRenderer.invoke('open-external', url)
});
