(() => {
  const ENGINES = [
    { id: 'google',     name: 'Google',      home: 'https://www.google.com/',           search: 'https://www.google.com/search?q=' },
    { id: 'bing',       name: 'Bing',        home: 'https://www.bing.com/',             search: 'https://www.bing.com/search?q=' },
    { id: 'duckduckgo', name: 'DuckDuckGo',  home: 'https://duckduckgo.com/',           search: 'https://duckduckgo.com/?q=' },
    { id: 'brave',      name: 'Brave Search',home: 'https://search.brave.com/',         search: 'https://search.brave.com/search?q=' },
    { id: 'yahoo',      name: 'Yahoo',       home: 'https://search.yahoo.com/',         search: 'https://search.yahoo.com/search?p=' },
    { id: 'ecosia',     name: 'Ecosia',      home: 'https://www.ecosia.org/',           search: 'https://www.ecosia.org/search?q=' },
    { id: 'startpage',  name: 'Startpage',   home: 'https://www.startpage.com/',        search: 'https://www.startpage.com/do/search?q=' },
    { id: 'yandex',     name: 'Yandex',      home: 'https://yandex.com/',               search: 'https://yandex.com/search/?text=' }
  ];

  const QUICK = [
    { name: 'Google',     url: 'https://www.google.com/' },
    { name: 'YouTube',    url: 'https://www.youtube.com/' },
    { name: 'Gmail',      url: 'https://mail.google.com/' },
    { name: 'Maps',       url: 'https://maps.google.com/' },
    { name: 'Tradutor',   url: 'https://translate.google.com/' },
    { name: 'Bing',       url: 'https://www.bing.com/' },
    { name: 'DuckDuckGo', url: 'https://duckduckgo.com/' },
    { name: 'Brave',      url: 'https://search.brave.com/' },
    { name: 'Yahoo',      url: 'https://search.yahoo.com/' },
    { name: 'Wikipedia',  url: 'https://pt.wikipedia.org/' },
    { name: 'GitHub',     url: 'https://github.com/' },
    { name: 'Netflix',    url: 'https://www.netflix.com/' }
  ];

  const $ = (id) => document.getElementById(id);
  const tabsEl = $('tabs'), viewsEl = $('views'), addr = $('address'), engineSel = $('engine');
  const loadfill = $('loadfill'), toastEl = $('toast');

  let tabs = [];
  let activeId = null;
  let seq = 0;
  let favs = [];
  try { favs = JSON.parse(localStorage.getItem('htz_favs') || '[]'); } catch { favs = []; }
  let engine = localStorage.getItem('htz_engine') || 'google';
  if (!ENGINES.find((e) => e.id === engine)) engine = 'google';

  const curEngine = () => ENGINES.find((e) => e.id === engine);
  const favicon = (url) => {
    try { return 'https://www.google.com/s2/favicons?sz=32&domain=' + new URL(url).hostname; }
    catch { return ''; }
  };

  function toast(msg) {
    toastEl.textContent = msg;
    toastEl.classList.add('show');
    clearTimeout(toast.t);
    toast.t = setTimeout(() => toastEl.classList.remove('show'), 1800);
  }

  // ---------- Entrada inteligente: URL ou busca ----------
  function resolveInput(text) {
    text = text.trim();
    if (!text) return curEngine().home;
    if (/^(https?|file|about):/i.test(text)) return text;
    if (/^localhost(:\d+)?(\/.*)?$/i.test(text)) return 'http://' + text;
    if (/^[^\s]+\.[a-z]{2,}(:\d+)?([/?#].*)?$/i.test(text) && !/\s/.test(text)) return 'https://' + text;
    return curEngine().search + encodeURIComponent(text);
  }

  // ---------- Abas ----------
  function newTab(url, opts = {}) {
    const id = ++seq;
    const wv = document.createElement('webview');
    wv.setAttribute('partition', 'persist:htz');
    wv.setAttribute('allowpopups', 'true');
    wv.setAttribute('src', url || curEngine().home);
    wv.classList.add('hidden');
    viewsEl.appendChild(wv);

    const el = document.createElement('div');
    el.className = 'tab';
    el.innerHTML = '<img alt="" /><span class="t">Nova aba</span><span class="x" title="Fechar (Ctrl+W)">✕</span>';
    tabsEl.appendChild(el);

    const tab = { id, wv, el, title: 'Nova aba', url: url || curEngine().home, loading: false };
    tabs.push(tab);

    el.addEventListener('click', (e) => {
      if (e.target.classList.contains('x')) closeTab(id);
      else activate(id);
    });
    el.addEventListener('auxclick', (e) => { if (e.button === 1) closeTab(id); });

    wv.addEventListener('page-title-updated', (e) => {
      tab.title = e.title; el.querySelector('.t').textContent = e.title;
    });
    wv.addEventListener('page-favicon-updated', (e) => {
      if (e.favicons && e.favicons[0]) el.querySelector('img').src = e.favicons[0];
    });
    wv.addEventListener('did-start-loading', () => { tab.loading = true; if (activeId === id) progress(true); });
    wv.addEventListener('did-stop-loading', () => { tab.loading = false; if (activeId === id) progress(false); });
    const onNav = (e) => {
      if (e.isMainFrame === false) return;
      tab.url = e.url;
      if (activeId === id) { updateAddress(); updateStar(); }
    };
    wv.addEventListener('did-navigate', onNav);
    wv.addEventListener('did-navigate-in-page', onNav);
    wv.addEventListener('did-fail-load', (e) => {
      if (e.errorCode === -3 || !e.isMainFrame) return; // abortado
      wv.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(
        '<body style="font-family:system-ui;background:#0f1115;color:#e8ebf2;display:grid;place-items:center;height:100vh;margin:0">' +
        '<div style="text-align:center"><h2>Não foi possível abrir a página</h2><p style="color:#8b93a7">' +
        (e.errorDescription || 'Erro de rede') + '</p><p style="color:#8b93a7">' + e.validatedURL + '</p></div></body>'));
    });
    wv.addEventListener('enter-html-full-screen', () => { document.body.classList.add('fs'); });

    el.querySelector('img').src = favicon(tab.url);
    if (!opts.background) activate(id);
    return tab;
  }

  function activate(id) {
    activeId = id;
    tabs.forEach((t) => {
      const on = t.id === id;
      t.el.classList.toggle('active', on);
      t.wv.classList.toggle('hidden', !on);
    });
    updateAddress(); updateStar();
    const t = tabs.find((x) => x.id === id);
    progress(t && t.loading);
    t && t.el.scrollIntoView({ block: 'nearest', inline: 'nearest' });
  }

  function closeTab(id) {
    const i = tabs.findIndex((t) => t.id === id);
    if (i < 0) return;
    const [t] = tabs.splice(i, 1);
    t.wv.remove(); t.el.remove();
    if (!tabs.length) { newTab(); return; }
    if (activeId === id) activate(tabs[Math.max(0, i - 1)].id);
  }

  const active = () => tabs.find((t) => t.id === activeId);

  function progress(on) {
    if (on) {
      loadfill.style.opacity = 1; loadfill.style.width = '65%';
    } else {
      loadfill.style.width = '100%';
      setTimeout(() => { loadfill.style.opacity = 0; loadfill.style.width = '0'; }, 250);
    }
  }

  function updateAddress() {
    const t = active();
    if (document.activeElement !== addr) addr.value = t ? (t.url.startsWith('data:') ? '' : t.url) : '';
  }

  function updateStar() {
    const t = active();
    $('star').classList.toggle('fav', !!(t && favs.find((f) => f.url === t.url)));
    $('star').textContent = $('star').classList.contains('fav') ? '★' : '☆';
  }

  // ---------- Navegação ----------
  function go(text) {
    const t = active() || newTab();
    t.wv.loadURL(resolveInput(text)).catch(() => {});
  }

  addr.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { go(addr.value); addr.blur(); }
    if (e.key === 'Escape') { addr.blur(); updateAddress(); }
  });
  addr.addEventListener('focus', () => addr.select());
  addr.addEventListener('blur', updateAddress);

  $('back').onclick = () => { const t = active(); t && t.wv.canGoBack() && t.wv.goBack(); };
  $('forward').onclick = () => { const t = active(); t && t.wv.canGoForward() && t.wv.goForward(); };
  $('reload').onclick = () => { const t = active(); t && (t.loading ? t.wv.stop() : t.wv.reload()); };
  $('home').onclick = () => { const t = active(); t && t.wv.loadURL(curEngine().home); };
  $('newtab').onclick = () => { newTab(); addr.focus(); };

  // ---------- Favoritos ----------
  $('star').onclick = () => {
    const t = active(); if (!t) return;
    const i = favs.findIndex((f) => f.url === t.url);
    if (i >= 0) { favs.splice(i, 1); toast('Favorito removido'); }
    else { favs.push({ name: t.title || t.url, url: t.url }); toast('Adicionado aos favoritos'); }
    localStorage.setItem('htz_favs', JSON.stringify(favs));
    updateStar(); renderLauncher();
  };

  // ---------- Barra de atalhos (vários navegadores/buscadores) ----------
  function renderLauncher() {
    const box = $('launcher'); box.innerHTML = '';
    const make = (item, removable) => {
      const c = document.createElement('div');
      c.className = 'chip';
      c.innerHTML = '<img alt="" /><span></span>';
      c.querySelector('img').src = favicon(item.url);
      c.querySelector('span').textContent = item.name.length > 22 ? item.name.slice(0, 22) + '…' : item.name;
      c.title = item.url;
      c.addEventListener('click', () => go(item.url));
      c.addEventListener('auxclick', (e) => { if (e.button === 1) newTab(item.url); });
      if (removable) c.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        favs = favs.filter((f) => f.url !== item.url);
        localStorage.setItem('htz_favs', JSON.stringify(favs));
        renderLauncher(); updateStar(); toast('Favorito removido');
      });
      box.appendChild(c);
    };
    QUICK.forEach((q) => make(q, false));
    favs.forEach((f) => make(f, true));
  }

  // ---------- Buscador padrão ----------
  ENGINES.forEach((e) => {
    const o = document.createElement('option');
    o.value = e.id; o.textContent = e.name; engineSel.appendChild(o);
  });
  engineSel.value = engine;
  engineSel.onchange = () => {
    engine = engineSel.value; localStorage.setItem('htz_engine', engine);
    toast('Buscador: ' + curEngine().name);
  };

  // ---------- Bloqueio e limpeza ----------
  let blockOn = localStorage.getItem('htz_block') !== '0';
  const paintBlock = () => { $('block').classList.toggle('on', blockOn); };
  $('block').onclick = async () => {
    blockOn = !blockOn; localStorage.setItem('htz_block', blockOn ? '1' : '0');
    await window.htz.setBlock(blockOn); paintBlock();
    toast(blockOn ? 'Bloqueio de anúncios ligado' : 'Bloqueio de anúncios desligado');
  };
  $('menu').onclick = async () => {
    if (confirm('Limpar cache, cookies e dados de navegação?')) {
      await window.htz.clearData(); toast('Dados limpos'); tabs.forEach((t) => t.wv.reload());
    }
  };

  // ---------- Atalhos de teclado ----------
  window.addEventListener('keydown', (e) => {
    const ctrl = e.ctrlKey || e.metaKey;
    if (ctrl && e.key.toLowerCase() === 't') { e.preventDefault(); newTab(); addr.focus(); }
    else if (ctrl && e.key.toLowerCase() === 'w') { e.preventDefault(); closeTab(activeId); }
    else if (ctrl && e.key.toLowerCase() === 'l') { e.preventDefault(); addr.focus(); }
    else if (ctrl && e.key.toLowerCase() === 'r') { e.preventDefault(); $('reload').click(); }
    else if (e.altKey && e.key === 'ArrowLeft') { $('back').click(); }
    else if (e.altKey && e.key === 'ArrowRight') { $('forward').click(); }
    else if (ctrl && e.key === 'Tab') {
      e.preventDefault();
      const i = tabs.findIndex((t) => t.id === activeId);
      const n = e.shiftKey ? (i - 1 + tabs.length) % tabs.length : (i + 1) % tabs.length;
      activate(tabs[n].id);
    } else if (ctrl && /^[1-9]$/.test(e.key)) {
      const t = tabs[parseInt(e.key, 10) - 1]; if (t) { e.preventDefault(); activate(t.id); }
    }
  });

  // Links com target=_blank vindos do main
  window.htz.onOpenUrl((url) => newTab(url));

  // ---------- Início ----------
  window.htz.setBlock(blockOn);
  paintBlock();
  renderLauncher();
  newTab(curEngine().home);
})();
