# Browser HTZ

Navegador leve e rápido, com o **Google** dentro e vários outros buscadores/sites num só app.

## Recursos
- Abas ilimitadas (Ctrl+T, Ctrl+W, Ctrl+Tab, Ctrl+1..9, clique do meio abre/fecha)
- Google, Bing, DuckDuckGo, Brave Search, Yahoo, Ecosia, Startpage e Yandex — escolha o buscador padrão no seletor
- Barra de atalhos: Google, YouTube, Gmail, Maps, Tradutor, Bing, DuckDuckGo, Brave, Yahoo, Wikipedia, GitHub, Netflix
- Barra de endereço inteligente: digite um site ou uma pesquisa
- Favoritos (★) — clique direito num favorito para remover
- Bloqueio de anúncios e rastreadores (🛡) para carregar mais rápido
- Aceleração por GPU, sessão persistente (logins ficam salvos)
- Limpar cache/cookies (botão ⋯)

## Como rodar
Requer Node.js 18+.

```bash
npm install
npm start
```

## Como gerar o instalador
```bash
npm run build:win     # Windows (.exe)
npm run build:linux   # Linux (AppImage)
npm run build:mac     # macOS (.dmg)
```
O resultado fica na pasta `dist/`.

## Atalhos
| Ação | Atalho |
|---|---|
| Nova aba | Ctrl+T |
| Fechar aba | Ctrl+W |
| Ir para endereço | Ctrl+L |
| Recarregar | Ctrl+R |
| Voltar / Avançar | Alt+← / Alt+→ |
| Próxima aba | Ctrl+Tab |
