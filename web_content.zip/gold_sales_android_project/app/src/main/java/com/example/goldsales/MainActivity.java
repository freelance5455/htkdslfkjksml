package com.example.goldsales;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int REQ_BT = 1001;
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        webView.addJavascriptInterface(new PrinterBridge(), "AndroidPrinter");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN}, REQ_BT);
        }
    }

    private boolean hasBtPermission() { return Build.VERSION.SDK_INT < 31 || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED; }

    public class PrinterBridge {
        @JavascriptInterface public String getPairedPrinters() {
            try {
                if (!hasBtPermission()) return "[]";
                BluetoothAdapter a = BluetoothAdapter.getDefaultAdapter(); if (a == null) return "[]";
                Set<BluetoothDevice> devices = a.getBondedDevices(); JSONArray out = new JSONArray();
                for (BluetoothDevice d : devices) { JSONObject o=new JSONObject(); o.put("name", d.getName()==null?"Bluetooth Printer":d.getName()); o.put("address",d.getAddress()); out.put(o); }
                return out.toString();
            } catch(Exception e){return "[]";}
        }

        @JavascriptInterface public String printReceipt(String address, String text, int width) {
            if(!hasBtPermission()) return "Bluetooth permission မပေးရသေးပါ။";
            try {
                BluetoothAdapter a=BluetoothAdapter.getDefaultAdapter(); if(a==null) return "ဒီစက်မှာ Bluetooth မရှိပါ။";
                BluetoothDevice d=a.getRemoteDevice(address); a.cancelDiscovery();
                BluetoothSocket s=d.createRfcommSocketToServiceRecord(SPP_UUID); s.connect();
                OutputStream out=s.getOutputStream(); Bitmap bmp=makeReceiptBitmap(text, width); out.write(rasterCommand(bmp));
                out.write(new byte[]{0x0A,0x0A,0x0A,0x1D,0x56,0x00}); out.flush(); out.close(); s.close();
                runOnUiThread(()->Toast.makeText(MainActivity.this,"ဘောင်ချာထုတ်ပြီးပါပြီ",Toast.LENGTH_SHORT).show()); return "OK";
            }catch(Exception e){return "Printer ချိတ်/ထုတ်မရပါ: "+e.getMessage();}
        }

        @JavascriptInterface public String saveReceiptImage(String text) {
            try {
                Bitmap bmp=makeReceiptBitmap(text,576);
                String name="GoldReceipt_"+System.currentTimeMillis()+".png";
                ContentValues v=new ContentValues(); v.put(MediaStore.Images.Media.DISPLAY_NAME,name); v.put(MediaStore.Images.Media.MIME_TYPE,"image/png");
                if(Build.VERSION.SDK_INT>=29) v.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/GoldSales");
                Uri uri=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v); if(uri==null)return "Gallery ထဲသိမ်းမရပါ။";
                OutputStream os=getContentResolver().openOutputStream(uri); bmp.compress(Bitmap.CompressFormat.PNG,100,os); os.close();
                return "Gallery ထဲ PNG အဖြစ် သိမ်းပြီးပါပြီ";
            }catch(Exception e){return "Gallery သိမ်းမရပါ: "+e.getMessage();}
        }
    }

    private Bitmap makeReceiptBitmap(String text, int width) {
        int margin=20, textSize=24, lineH=34; Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); p.setColor(0xFF000000); p.setTextSize(textSize); p.setTypeface(Typeface.create("sans",Typeface.NORMAL));
        List<String> lines=new ArrayList<>();
        for(String raw:text.split("\\n",-1)) { String line=raw; if(line.isEmpty()){lines.add("");continue;} StringBuilder cur=new StringBuilder(); for(String w:raw.split("(?<=\\s)|(?=\\s)",-1)){if(p.measureText(cur.toString()+w)>width-margin*2 && cur.length()>0){lines.add(cur.toString());cur.setLength(0);}cur.append(w);} if(cur.length()>0)lines.add(cur.toString()); }
        int h=Math.max(120,margin*2+lines.size()*lineH); Bitmap b=Bitmap.createBitmap(width,h,Bitmap.Config.ARGB_8888); Canvas c=new Canvas(b); c.drawColor(0xFFFFFFFF); float y=margin+textSize;
        for(String l:lines){c.drawText(l,margin,y,p);y+=lineH;} return b;
    }

    private byte[] rasterCommand(Bitmap bmp) {
        int w=bmp.getWidth(), h=bmp.getHeight(); int bytesPerRow=(w+7)/8; ByteArrayOutputStream o=new ByteArrayOutputStream();
        o.write(0x1B);o.write(0x40); o.write(0x1D);o.write(0x76);o.write(0x30);o.write(0x00);o.write(bytesPerRow&255);o.write((bytesPerRow>>8)&255);o.write(h&255);o.write((h>>8)&255);
        for(int y=0;y<h;y++){for(int x=0;x<bytesPerRow*8;x+=8){int v=0;for(int bit=0;bit<8;bit++){int px=x+bit; if(px<w){int c=bmp.getPixel(px,y);int r=(c>>16)&255,g=(c>>8)&255,b=c&255;int lum=(r*299+g*587+b*114)/1000;if(lum<180)v|=(1<<(7-bit));}}o.write(v);}}return o.toByteArray();
    }
}
