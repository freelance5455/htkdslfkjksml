package com.example.goldsales;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int REQ_BT = 1001;
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        webView.addJavascriptInterface(new PrinterBridge(), "AndroidPrinter");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN}, REQ_BT);
        }
    }

    private boolean hasBtPermission() {
        return Build.VERSION.SDK_INT < 31 || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
    }

    public class PrinterBridge {
        @JavascriptInterface public String getPairedPrinters() {
            try {
                if (!hasBtPermission()) return "[]";
                BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
                if (adapter == null) return "[]";
                Set<BluetoothDevice> devices = adapter.getBondedDevices();
                JSONArray out = new JSONArray();
                for (BluetoothDevice d : devices) {
                    JSONObject o = new JSONObject();
                    o.put("name", d.getName() == null ? "Bluetooth Printer" : d.getName());
                    o.put("address", d.getAddress());
                    out.put(o);
                }
                return out.toString();
            } catch (Exception e) { return "[]"; }
        }

        @JavascriptInterface public String printText(String address, String text) {
            if (!hasBtPermission()) return "Bluetooth permission မပေးရသေးပါ။";
            try {
                BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
                if (adapter == null) return "ဒီစက်မှာ Bluetooth မရှိပါ။";
                BluetoothDevice device = adapter.getRemoteDevice(address);
                BluetoothSocket socket = device.createRfcommSocketToServiceRecord(SPP_UUID);
                adapter.cancelDiscovery();
                socket.connect();
                OutputStream out = socket.getOutputStream();
                out.write(new byte[]{0x1B, 0x40});
                out.write(text.getBytes(StandardCharsets.UTF_8));
                out.write(new byte[]{0x0A,0x0A,0x0A});
                out.write(new byte[]{0x1D,0x56,0x00});
                out.flush(); out.close(); socket.close();
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "ဘောင်ချာထုတ်ပြီးပါပြီ", Toast.LENGTH_SHORT).show());
                return "OK";
            } catch (Exception e) { return "Printer ချိတ်မရပါ: " + e.getMessage(); }
        }
    }
}
