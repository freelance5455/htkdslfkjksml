DAYFLOW NATIVE ANDROID PROJECT — PATCHED STARTER

What is included
- Existing DayFlow HTML/CSS/JS interface and local-device account storage.
- Native Android alarm and notification action source.
- Notification actions: Complete, Snooze 5 min, Dismiss.
- Complete actions are queued in native SharedPreferences and applied after the user logs in to DayFlow, so the action is not lost while the WebView is closed.
- Reminder alarms are rebuilt after a reminder fires and after device reboot.
- AndroidX Core dependency is declared for NotificationCompat and ActivityCompat.

Important limitations (please read)
- This is SOURCE CODE, not a compiled or tested APK. It has not been built on a device in this environment.
- No Gradle wrapper JAR is included. A Gradle installation/build environment is still required to compile it.
- Android 12+ exact alarms require the user to grant the "Alarms & reminders" special app access. This starter checks that access and skips exact scheduling if it is not granted; it does not yet open the settings page automatically.
- Android 13+ notification permission must be granted for notifications to appear.
- Battery optimization and phone-manufacturer restrictions can delay alarms. Force-stopping the app can prevent alarms until the app is opened again.
- Existing APKForge app data is not automatically transferred to this separate native app container. Local accounts and routines may need to be recreated.
- PIN login remains a local-only prototype, not secure cloud authentication.

Build setup
- Open this folder as an Android project in an Android Gradle build environment.
- Use Gradle 8.9 with Android Gradle Plugin 8.7.3 and JDK 17 (or a compatible newer Gradle/JDK combination supported by your IDE).
- Allow Gradle sync to download AndroidX Core 1.15.0 and Android build dependencies.
- Build an APK, install it, grant notification permission, and on Android 12+ grant DayFlow "Alarms & reminders" access.
- Test screen-off delivery, notification actions, app process closure, reboot, and task edits/deletions on the target phone.

Do not put real PINs, passwords, or private credentials into source files.
