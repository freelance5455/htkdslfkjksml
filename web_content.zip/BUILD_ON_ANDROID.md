# ITBN CAMP REPORT — Android APK Project

This is a real Android Gradle project. The HTML report is bundled as app assets and displayed in an Android WebView.

## Build on Android
1. Open/import this folder in an Android Gradle IDE that supports Gradle 8.x and Android Gradle Plugin 8.7.x.
2. Allow Gradle to download Android/Jetpack dependencies.
3. Choose the `app` module.
4. Build **APK** (debug is sufficient for personal installation).
5. Install the generated APK on the Android phone.

## Important
- The app does not need a web server to load the report; the HTML is packaged inside the APK.
- The HTML currently references Bootstrap, Bootstrap Icons, SheetJS, jsPDF and AutoTable from CDNs, so those export/UI libraries need internet access when the app uses them unless those libraries are later bundled locally.
- Record data uses the HTML app's localStorage, as in the supplied report.
