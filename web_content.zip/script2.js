document.addEventListener("DOMContentLoaded", () => {
    // Récupération des 4 fenêtres modales
    const fenetreCommentaires = document.getElementById("fenetreCommentaires");
    const fenetreBoite = document.getElementById("fenetreBoite");
    const fenetreCreation = document.getElementById("fenetreCreation");
    const fenetreProfil = document.getElementById("fenetreProfil");

    // Déclencheurs (Boutons d'ouverture)
    const btnCommentairesSidebar = document.getElementById("ouvrirCommentairesSidebar");
    const btnBoiteNav = document.getElementById("navBoite");
    const btnNouveau = document.getElementById("nouveauBouton");
    
    // On sélectionne l'onglet Profil en cherchant l'élément de la barre basse qui contient le texte "Profil"
    const itemsNav = document.querySelectorAll(".bottom-navigation .nav-item");
    let btnProfilNav = null;
    itemsNav.forEach(item => {
        const texte = item.querySelector("p") ? item.querySelector("p").innerText.trim() : "";
        if (texte === "Profil") btnProfilNav = item;
    });

    // Boutons de fermeture (Les croix)
    const btnFermerCommentaires = document.getElementById("fermerCommentaires");
    const btnFermerBoite = document.getElementById("fermerBoite");
    const btnFermerCreation = document.getElementById("fermerCreation");
    const btnFermerProfil = document.getElementById("fermerProfil");

    // Données pour le module Commentaires
    const zoneListeCommentaires = document.getElementById("zoneListeCommentaires");
    const champTexteCommentaire = document.getElementById("champTexteCommentaire");
    const btnPublierCommentaire = document.getElementById("btnPublierCommentaire");
    const commentaireVide = document.getElementById("commentaireVide");

    // Liste des vidéos pour le swipe
    const listeVideos = ["video1.mp4", "video2.mp4", "video3.mp4"];
    let indexActuel = 0;
    let yDepart = 0;
    let yFin = 0;

    // ==========================================
    // LOGIQUE DE COMMUTATION DES FENÊTRES (MODALES)
    // ==========================================
    function masquerToutesLesFenitres() {
        if (fenetreCommentaires) fenetreCommentaires.classList.remove("visible");
        if (fenetreBoite) fenetreBoite.classList.remove("visible");
        if (fenetreCreation) fenetreCreation.classList.remove("visible");
        if (fenetreProfil) fenetreProfil.classList.remove("visible");
    }

    if (btnCommentairesSidebar && fenetreCommentaires) {
        btnCommentairesSidebar.addEventListener("click", (e) => {
            e.stopPropagation(); masquerToutesLesFenitres(); fenetreCommentaires.classList.add("visible");
        });
    }

    if (btnBoiteNav && fenetreBoite) {
        btnBoiteNav.addEventListener("click", (e) => {
            e.stopPropagation(); masquerToutesLesFenitres(); fenetreBoite.classList.add("visible");
        });
    }

    if (btnNouveau && fenetreCreation) {
        btnNouveau.addEventListener("click", (e) => {
            e.stopPropagation(); masquerToutesLesFenitres(); fenetreCreation.classList.add("visible");
        });
    }

    if (btnProfilNav && fenetreProfil) {
        btnProfilNav.addEventListener("click", (e) => {
            e.stopPropagation(); masquerToutesLesFenitres(); fenetreProfil.classList.add("visible");
        });
    }

    // Gestion des fermetures (clic sur la croix)
    if (btnFermerCommentaires) btnFermerCommentaires.addEventListener("click", () => fenetreCommentaires.classList.remove("visible"));
    if (btnFermerBoite) btnFermerBoite.addEventListener("click", () => fenetreBoite.classList.remove("visible"));
    if (btnFermerCreation) btnFermerCreation.addEventListener("click", () => fenetreCreation.classList.remove("visible"));
    if (btnFermerProfil) btnFermerProfil.addEventListener("click", () => fenetreProfil.classList.remove("visible"));

    // ==========================================
    // MODULE DE PUBLICATION DES COMMENTAIRES
    // ==========================================
    if (btnPublierCommentaire && champTexteCommentaire && zoneListeCommentaires) {
        const executerPublication = () => {
            const texteSaisi = champTexteCommentaire.value.trim();
            if (texteSaisi !== "") {
                if (commentaireVide) commentaireVide.style.display = "none";
                const nouvelleBulle = document.createElement("div");
                nouvelleBulle.classList.add("bulle-commentaire");
                nouvelleBulle.innerText = texteSaisi;
                zoneListeCommentaires.appendChild(nouvelleBulle);
                champTexteCommentaire.value = "";
                zoneListeCommentaires.scrollTop = zoneListeCommentaires.scrollHeight;
            }
        };
        btnPublierCommentaire.addEventListener("click", (e) => { e.stopPropagation(); executerPublication(); });
        champTexteCommentaire.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); executerPublication(); } });
    }

    // ==========================================
    // CAPTURE DU GLISSEMENT DE VIDÉO (SWIPE)
    // ==========================================
    window.addEventListener("touchstart", (e) => { yDepart = e.touches.clientY; }, { passive: true });
    window.addEventListener("touchmove", (e) => { if (e.cancelable) e.preventDefault(); }, { passive: false });
    window.addEventListener("touchend", (e) => {
        yFin = e.changedTouches.clientY;
        const diffY = yDepart - yFin;
        const sensibilite = 50;

        if (diffY > sensibilite && indexActuel < listeVideos.length - 1) {
            indexActuel++; changerDeVideoAnimation("haut");
        } else if (diffY < -sensibilite && indexActuel > 0) {
            indexActuel--; changerDeVideoAnimation("bas");
        }
    }, { passive: true });

    function changerDeVideoAnimation(direction) {
        const lecteurVideo = document.getElementById("lecteurVideoTikTok");
        const statutVideo = document.getElementById("statutVideo");
        const compteurLikes = document.getElementById("compteurLikes");

        if (lecteurVideo) {
            lecteurVideo.style.transform = direction === "haut" ? "translateY(-100%)" : "translateY(100%)";
            lecteurVideo.style.opacity = "0";
            setTimeout(() => {
                lecteurVideo.src = listeVideos[indexActuel];
                lecteurVideo.load();
                lecteurVideo.style.transform = direction === "haut" ? "translateY(100%)" : "translateY(-100%)";
                setTimeout(() => {
                    lecteurVideo.style.transform = "translateY(0)"; lecteurVideo.style.opacity = "1"; lecteurVideo.play().catch(() => {});
                }, 50);
                if (statutVideo) statutVideo.innerText = `▶ Vidéo ${indexActuel + 1} en cours de lecture...`;
                if (compteurLikes) compteurLikes.innerText = (Math.floor(Math.random() * 80) + 10) + "k";
            }, 250);
        }
    }

    // Gestion de surbrillance de l'onglet actif de la barre basse
    itemsNav.forEach(item => {
        item.addEventListener("click", () => {
            itemsNav.forEach(el => el.classList.remove("active"));
            item.classList.add("active");
            const texte = item.querySelector("p") ? item.querySelector("p").innerText.trim() : "";
            if (texte === "Accueil" || texte === "Amis") {
                masquerToutesLesFenitres();
            }
        });
    });    // ==========================================
    // LOGIQUE DU PROFIL (MODIFIER & S'ABONNER)
    // ==========================================
    const btnModifierProfil = document.getElementById("btnModifierProfil");
    const nomUtilisateurProfil = document.getElementById("nomUtilisateurProfil");
    const btnSuivreProfil = document.getElementById("btnSuivreProfil");
    const compteurAbonnes = document.getElementById("compteurAbonnes");

    // 1. Action du bouton "Modifier le profil"
    if (btnModifierProfil && nomUtilisateurProfil) {
        btnModifierProfil.addEventListener("click", () => {
            // Demande à l'utilisateur d'écrire son nouveau nom dans une boîte système
            const nouveauNom = prompt("Entrez votre nouveau nom d'utilisateur :", nomUtilisateurProfil.innerText);
            
            // Si l'utilisateur a écrit quelque chose et cliqué sur OK
            if (nouveauNom !== null && nouveauNom.trim() !== "") {
                nomUtilisateurProfil.innerText = nouveauNom.trim();
            }
        });
    }

    // 2. Action du bouton "S'abonner"
    if (btnSuivreProfil) {
        let estAbonne = false;

        btnSuivreProfil.addEventListener("click", () => {
            if (!estAbonne) {
                // Si on s'abonne : le bouton change de couleur et le compteur augmente fictivement
                btnSuivreProfil.innerText = "Abonné";
                btnSuivreProfil.style.backgroundColor = "#e1e1e1";
                btnSuivreProfil.style.color = "#000000";
                if (compteurAbonnes) compteurAbonnes.innerText = "45.3k";
                estAbonne = true;
            } else {
                // Si on se désabonne : retour à l'état initial
                btnSuivreProfil.innerText = "S'abonner";
                btnSuivreProfil.style.backgroundColor = "#fe2c55";
                btnSuivreProfil.style.color = "#ffffff";
                if (compteurAbonnes) compteurAbonnes.innerText = "45.2k";
                estAbonne = false;
            }
        });
  