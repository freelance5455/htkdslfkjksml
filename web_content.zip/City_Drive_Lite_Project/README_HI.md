# City Drive Lite – Android/Web Game Project

यह एक छोटा, ओरिजिनल 2D कार-ड्राइविंग गेम डेमो है। यह Dr. Driving का क्लोन नहीं है।

## चलाने का तरीका
1. ZIP को Extract करें।
2. `index.html` को Chrome में खोलें।
3. मोबाइल पर स्क्रीन के बटन से कार चलाएँ; कंप्यूटर पर Arrow keys इस्तेमाल करें।

## Android APK बनाने का आसान रास्ता
- इस प्रोजेक्ट को Android Studio में एक WebView ऐप के अंदर रखें।
- `app/src/main/assets/` फ़ोल्डर बनाएँ और `index.html` उसमें कॉपी करें।
- WebView में `file:///android_asset/index.html` लोड करें।
- ऐप को Build > Build APK(s) से APK में बदलें।

## फ़ाइलें
- `index.html` – पूरा गेम (HTML, CSS और JavaScript)
- `README_HI.md` – हिंदी निर्देश

नोट: APK बनाने के लिए Android Studio वाला Android प्रोजेक्ट/Gradle सेटअप अलग से चाहिए। यह ZIP अभी चलने योग्य वेब-गेम सोर्स है।
