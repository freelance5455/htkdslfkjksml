// Web: leave empty to use same-origin /api.
// Android/cloud: set this before app loads, e.g. https://YOUR-DOMAIN.example
window.MRKHRASANI_API_BASE = window.MRKHRASANI_API_BASE || '';
