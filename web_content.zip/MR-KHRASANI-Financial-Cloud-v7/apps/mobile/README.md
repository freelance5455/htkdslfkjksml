# Android wrapper

This folder is the Capacitor Android build layer for MR.KHRASANI.

Prerequisites on the build machine:
- Node.js 22 LTS or compatible
- JDK 21
- Android Studio / Android SDK
- Android Platform 36
- Android Build Tools matching the installed AGP

Build steps:
1. `npm install`
2. `npx cap sync android`
3. `npx cap open android`
4. In Android Studio, build a signed Release APK.

For a local Gradle build after Android has been generated:
`cd android && ./gradlew assembleRelease`

The desired distributable is a signed Release APK. A single APK should be built after validating the minimum supported Android version and device architectures.
