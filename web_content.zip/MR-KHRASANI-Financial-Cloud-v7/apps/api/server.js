const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { SQLITE_PATH, withTransaction, withRead, openDb, loadState, saveState } = require('./lib/persistence');

const ROOT = path.resolve(__dirname, '../web');
const STORE = path.resolve(__dirname, 'store.json');
const PORT = Number(process.env.PORT || 8080);
const SESSION_TTL_MS = 1000 * 60 * 60 * 12;
const DEMO_USERS = [
  {id:'usr_admin',username:'admin',displayName:'مدیر سیستم',role:'manager',password:process.env.ADMIN_PASSWORD || 'Admin123!'},
  {id:'usr_accountant',username:'accountant',displayName:'حسابدار',role:'accountant',password:process.env.ACCOUNTANT_PASSWORD || 'Accountant123!'},
  {id:'usr_sales',username:'sales',displayName:'کارشناس فروش',role:'sales',password:process.env.SALES_PASSWORD || 'Sales123!'}
];
const ROLE_PERMISSIONS = {
  manager:['*'],
  accountant:['dashboard','persons.read','persons.write','products.read','products.write','sales.read','sales.write','purchases.read','purchases.write','receipts.read','receipts.write','payments.read','payments.write','cheques.read','cheques.write','reports.read','accounting.read','day.close','day.reopen','audit.read','backup.write','export.read'],
  sales:['dashboard','persons.read','persons.write','products.read','sales.read','sales.write','receipts.read','receipts.write','cheques.read','cheques.write','reports.read']
};

const mime = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon'
};

function readDb() {
  return withRead((state) => state);
}
function writeDb(db) {
  const sqlite = openDb();
  try {
    sqlite.exec('BEGIN IMMEDIATE');
    saveState(sqlite, db, 7);
    sqlite.exec('COMMIT');
  } catch (e) {
    try { sqlite.exec('ROLLBACK'); } catch {}
    throw e;
  } finally {
    sqlite.close();
  }
}
function sqliteBackup(target) {
  const sqlite = openDb();
  try {
    sqlite.exec('PRAGMA wal_checkpoint(FULL);');
    fs.copyFileSync(SQLITE_PATH, target);
  } finally { sqlite.close(); }
}

function id(prefix) { return `${prefix}_${crypto.randomUUID().slice(0, 8)}`; }
function now() { return new Date().toISOString(); }
function json(res, status, data) {
  res.writeHead(status, {'content-type':'application/json; charset=utf-8','cache-control':'no-store'});
  res.end(JSON.stringify(data));
}
function body(req) {
  return new Promise((resolve,reject)=>{
    let raw='';
    req.on('data', c => { raw += c; if(raw.length > 2_000_000) req.destroy(); });
    req.on('end', ()=> { try { resolve(raw ? JSON.parse(raw) : {}); } catch(e){ reject(new Error('JSON نامعتبر است.')); } });
    req.on('error', reject);
  });
}
function sessionFrom(req, db){
  const raw=req.headers.authorization||''; if(!raw.startsWith('Bearer ')) return null;
  const token=raw.slice(7); const s=(db.sessions||[]).find(x=>x.token===token && x.expiresAt>Date.now());
  if(!s) return null; return db.users.find(u=>u.id===s.userId && u.active) || null;
}
function hasPermission(user, permission){ if(!user) return false; const p=ROLE_PERMISSIONS[user.role]||[]; return p.includes('*') || p.includes(permission); }
function requireAuth(req,db,permission){ const user=sessionFrom(req,db); if(!user) throw Object.assign(new Error('ورود به سیستم الزامی است.'),{status:401}); if(permission && !hasPermission(user,permission)) throw Object.assign(new Error('دسترسی برای این عملیات مجاز نیست.'),{status:403}); return user; }
function safeUser(user){ return {id:user.id,username:user.username,displayName:user.displayName,role:user.role}; }
function ensureSeedUsers(db){ db.users ||= []; for(const u of DEMO_USERS){ if(!db.users.some(x=>x.username===u.username)) db.users.push({id:u.id,username:u.username,displayName:u.displayName,role:u.role,active:true}); } }
function audit(db, action, entityType, entityId, oldData, newData, reason='') {
  db.auditLogs.push({id:id('log'), action, entityType, entityId, oldData, newData, reason, userId:'demo-manager', createdAt:now()});
}
function dayClosed(db, date) { return db.dailyCloses.some(x => x.date === date && x.status === 'closed'); }
function requireOpen(db, date) {
  if(dayClosed(db,date)) throw new Error('این روز بسته شده است و ویرایش مستقیم مجاز نیست.');
}
function addJournal(db, type, date, description, lines, refType, refId, isManual=false) {
  const debit = lines.reduce((s,x)=>s+Number(x.debit||0),0);
  const credit = lines.reduce((s,x)=>s+Number(x.credit||0),0);
  if(Math.round(debit*100) !== Math.round(credit*100)) throw new Error('سند نامتوازن است؛ جمع بدهکار و بستانکار باید برابر باشد.');
  const entry = {id:id('je'), documentNo:`J-${String(db.journalEntries.length+1).padStart(6,'0')}`, date, type, description, refType, refId, isManual, status:'posted', lines, createdAt:now()};
  db.journalEntries.push(entry); return entry;
}
function rebuildJournals(db) {
  db.journalEntries = [];
  for(const s of db.sales){
    const line = [{account:'120101', debit:Number(s.finalAmount), credit:0, detail:s.customerId},{account:'410101', debit:0, credit:Number(s.finalAmount), detail:null}];
    addJournal(db,'SALE',s.date,`فروش فاکتور ${s.invoiceNo}`,line,'sale',s.id);
  }
  for(const p of db.purchases){
    const line = [{account:'510101', debit:Number(p.finalAmount), credit:0, detail:null},{account:'210101', debit:0, credit:Number(p.finalAmount), detail:p.supplierId}];
    addJournal(db,'PURCHASE',p.date,`خرید فاکتور ${p.invoiceNo}`,line,'purchase',p.id);
  }
  for(const r of db.receipts){
    const src = db.sources.find(x=>x.id===r.sourceId) || {accountCode:'110999'};
    addJournal(db,'RECEIPT',r.date,`دریافت فاکتور ${r.invoiceNo || '-'}`,[{account:src.accountCode,debit:Number(r.amount),credit:0,detail:null},{account:'120101',debit:0,credit:Number(r.amount),detail:r.customerId}],'receipt',r.id);
  }
  for(const p of db.payments){
    const src = db.sources.find(x=>x.id===p.sourceId) || {accountCode:'110999'};
    addJournal(db,'PAYMENT',p.date,`پرداخت ${p.invoiceNo || ''}`,[{account:'210101',debit:Number(p.amount),credit:0,detail:p.supplierId||null},{account:src.accountCode,debit:0,credit:Number(p.amount),detail:null}],'payment',p.id);
  }
}
function rebuildStock(db) {
  db.stockMovements = [];
  for(const p of db.purchases||[]) for(const i of p.items||[]) db.stockMovements.push({id:id('stm'),date:p.date,productId:i.productId,qty:Number(i.qty),type:'purchase',refId:p.id});
  for(const s of db.sales||[]) for(const i of s.items||[]) db.stockMovements.push({id:id('stm'),date:s.date,productId:i.productId,qty:-Number(i.qty),type:'sale',refId:s.id});
}
function stockSummary(db) {
  const map={};
  for(const m of db.stockMovements||[]) map[m.productId]=(map[m.productId]||0)+Number(m.qty);
  return (db.products||[]).map(p=>({...p,stock:Number(map[p.id]||0)}));
}
function summary(db, date) {
  const sales = db.sales.filter(x=>x.date===date).reduce((s,x)=>s+Number(x.finalAmount),0);
  const receipts = db.receipts.filter(x=>x.date===date).reduce((s,x)=>s+Number(x.amount),0);
  const payments = db.payments.filter(x=>x.date===date).reduce((s,x)=>s+Number(x.amount),0);
  const invoiceBalances = db.sales.map(s=>{
    const got = db.receipts.filter(r=>r.invoiceNo===s.invoiceNo && r.customerId===s.customerId).reduce((a,r)=>a+Number(r.amount),0);
    return {...s, received:got, balance:Math.max(0,Number(s.finalAmount)-got)};
  });
  const openInvoices = invoiceBalances.filter(x=>x.balance>0);
  const customerBalances = {};
  for(const s of db.sales) customerBalances[s.customerId]=(customerBalances[s.customerId]||0)+Number(s.finalAmount);
  for(const r of db.receipts) customerBalances[r.customerId]=(customerBalances[r.customerId]||0)-Number(r.amount);
  const mismatches = [];
  const unbalanced = db.journalEntries.some(j=>Math.abs(j.lines.reduce((a,l)=>a+Number(l.debit),0)-j.lines.reduce((a,l)=>a+Number(l.credit),0))>0);
  if(unbalanced) mismatches.push({type:'تراز',amount:0,description:'حداقل یک سند حسابداری نامتوازن است.'});
  const duplicateInvoices = [...new Set(db.sales.map(x=>x.invoiceNo))].filter(no=>db.sales.filter(x=>x.invoiceNo===no).length>1);
  if(duplicateInvoices.length) mismatches.push({type:'فاکتور تکراری',amount:duplicateInvoices.length,description:`شماره فاکتور تکراری: ${duplicateInvoices.join('، ')}`});
  const negativeStock=stockSummary(db).filter(x=>Number(x.stock)<0);
  if(negativeStock.length) mismatches.push({type:'موجودی منفی',amount:negativeStock.reduce((a,x)=>a+Math.abs(Number(x.stock)),0),description:`موجودی منفی برای ${negativeStock.length} کالا وجود دارد.`});
  const closed = dayClosed(db,date);
  return {date,sales,receipts,payments,openInvoices:openInvoices.length,openInvoiceAmount:openInvoices.reduce((a,x)=>a+x.balance,0),customerBalances,mismatches,closed};
}


function dateValue(v){ return String(v||'').replace(/-/g,'/'); }
function inRange(date, from, to){ const d=dateValue(date); return (!from || d>=dateValue(from)) && (!to || d<=dateValue(to)); }
function personName(db,idv){ return (db.persons||[]).find(x=>x.id===idv)?.name || '---'; }
function invoiceBalance(db, invoiceNo, customerId){
  const sale=db.sales.find(x=>x.invoiceNo===String(invoiceNo) && x.customerId===customerId);
  if(!sale) return null;
  const got=db.receipts.filter(r=>r.invoiceNo===sale.invoiceNo && r.customerId===sale.customerId).reduce((a,r)=>a+Number(r.amount),0);
  return {sale, received:got, balance:Number(sale.finalAmount)-got};
}
function supplierInvoiceBalance(db, invoiceNo, supplierId){
  const purchase=db.purchases.find(x=>x.invoiceNo===String(invoiceNo) && x.supplierId===supplierId);
  if(!purchase) return null;
  const paid=db.payments.filter(r=>r.invoiceNo===purchase.invoiceNo && r.supplierId===purchase.supplierId).reduce((a,r)=>a+Number(r.amount),0);
  return {purchase, paid, balance:Number(purchase.finalAmount)-paid};
}
function chequeDays(dueDate, today){
  if(!dueDate) return {days:0,label:'---',state:'unknown'};
  const a=String(today||'').split('/').map(Number), b=String(dueDate).split('/').map(Number);
  if(a.length!==3 || b.length!==3 || a.some(Number.isNaN) || b.some(Number.isNaN)) return {days:0,label:'نامعتبر',state:'unknown'};
  // Persian calendar approximation for operational display: ordinal by year/month/day.
  const ord=x=>x[0]*372+x[1]*31+x[2]; const diff=ord(b)-ord(a);
  if(diff>0) return {days:diff,label:`${diff} روز مانده`,state:'pending'};
  if(diff<0) return {days:Math.abs(diff),label:`${Math.abs(diff)} روز تأخیر`,state:'overdue'};
  return {days:0,label:'سررسید امروز',state:'due'};
}
function ledgerReport(db, accountCode, from, to){
  const rows=[];
  for(const j of db.journalEntries||[]) if(inRange(j.date,from,to)) for(const l of j.lines||[]) if(!accountCode || l.account===accountCode) rows.push({date:j.date,documentNo:j.documentNo,description:j.description,account:l.account,detail:l.detail||'',debit:Number(l.debit||0),credit:Number(l.credit||0),balance:Number(l.debit||0)-Number(l.credit||0)});
  let running=0; return rows.map(r=>({...r,running:running+=r.balance}));
}

async function api(req,res) {
  const url = new URL(req.url,'http://localhost');
  const p = url.pathname;
  let db = readDb();
  try {
    ensureSeedUsers(db);
    const data = await body(req);
    if(req.method==='GET' && p==='/api/health') return json(res,200,{ok:true,app:'MR.KHRASANI',version:'0.7.0',mode:'transactional-persistence',database:'sqlite'});
    if(req.method==='POST' && p==='/api/auth/login'){ const username=String(data.username||'').trim(); const password=String(data.password||''); const du=DEMO_USERS.find(u=>u.username===username); if(!du || du.password!==password) throw Object.assign(new Error('نام کاربری یا رمز عبور نادرست است.'),{status:401}); const user=db.users.find(u=>u.username===username); const token=crypto.randomBytes(32).toString('hex'); db.sessions=db.sessions.filter(x=>x.expiresAt>Date.now()); db.sessions.push({token,userId:user.id,createdAt:Date.now(),expiresAt:Date.now()+SESSION_TTL_MS}); writeDb(db); return json(res,200,{token,user:safeUser(user),expiresAt:Date.now()+SESSION_TTL_MS}); }
    if(req.method==='POST' && p==='/api/auth/logout'){ const u=sessionFrom(req,db); db.sessions=(db.sessions||[]).filter(x=>x.token!==(req.headers.authorization||'').slice(7)); writeDb(db); return json(res,200,{ok:true,user:u?safeUser(u):null}); }
    if(req.method==='GET' && p==='/api/auth/me'){ const u=requireAuth(req,db); return json(res,200,{user:safeUser(u),permissions:ROLE_PERMISSIONS[u.role]||[]}); }

    if(req.method==='GET' && p==='/api/bootstrap'){ requireAuth(req,db,'dashboard'); return json(res,200,{persons:db.persons,products:db.products,sources:db.sources,sales:db.sales,purchases:db.purchases,receipts:db.receipts,payments:db.payments,chequesReceived:db.chequesReceived,chequesIssued:db.chequesIssued,auditLogs:db.auditLogs,stock:stockSummary(db),receiptAllocations:db.receiptAllocations||[],paymentAllocations:db.paymentAllocations||[]}); }
    if(req.method==='GET' && p==='/api/summary'){ requireAuth(req,db,'dashboard'); return json(res,200,summary(db,url.searchParams.get('date')||'1405/06/31')); }
    if(req.method==='GET' && p==='/api/reports/stock'){ requireAuth(req,db,'reports.read'); return json(res,200,stockSummary(db)); }
    if(req.method==='GET' && p==='/api/reports/cheques'){ requireAuth(req,db,'cheques.read'); return json(res,200,[...(db.chequesReceived||[]).map(x=>({...x,kind:'received'})),...(db.chequesIssued||[]).map(x=>({...x,kind:'issued'}))]); }
    if(req.method==='GET' && p==='/api/reports/open-invoices') { requireAuth(req,db,'reports.read');
      const all = db.sales.map(s=>{
        const got=db.receipts.filter(r=>r.invoiceNo===s.invoiceNo&&r.customerId===s.customerId).reduce((a,r)=>a+Number(r.amount),0);
        return {...s,received:got,balance:Number(s.finalAmount)-got};
      }).filter(x=>x.balance>0);
      return json(res,200,all);
    }

    if(req.method==='GET' && p==='/api/reports/customer-balances') { requireAuth(req,db,'reports.read');
      const from=url.searchParams.get('from')||''; const to=url.searchParams.get('to')||''; const map={};
      for(const s of db.sales.filter(x=>inRange(x.date,from,to))) map[s.customerId]=(map[s.customerId]||0)+Number(s.finalAmount);
      for(const r of db.receipts.filter(x=>inRange(x.date,from,to))) map[r.customerId]=(map[r.customerId]||0)-Number(r.amount);
      return json(res,200,Object.entries(map).map(([idv,b])=>({personId:idv,person:personName(db,idv),balance:b})).filter(x=>x.balance!==0).sort((a,b)=>b.balance-a.balance));
    }
    if(req.method==='GET' && p==='/api/reports/supplier-balances') { requireAuth(req,db,'reports.read');
      const from=url.searchParams.get('from')||''; const to=url.searchParams.get('to')||''; const map={};
      for(const s of db.purchases.filter(x=>inRange(x.date,from,to))) map[s.supplierId]=(map[s.supplierId]||0)+Number(s.finalAmount);
      for(const r of db.payments.filter(x=>inRange(x.date,from,to))) map[r.supplierId]=(map[r.supplierId]||0)-Number(r.amount);
      return json(res,200,Object.entries(map).map(([idv,b])=>({personId:idv,person:personName(db,idv),balance:b})).filter(x=>x.balance!==0).sort((a,b)=>b.balance-a.balance));
    }
    if(req.method==='GET' && p==='/api/reports/ledger'){ requireAuth(req,db,'accounting.read'); return json(res,200,ledgerReport(db,url.searchParams.get('account')||'',url.searchParams.get('from')||'',url.searchParams.get('to')||'')); }
    if(req.method==='GET' && p==='/api/reports/open-invoices-range') { requireAuth(req,db,'reports.read');
      const from=url.searchParams.get('from')||''; const to=url.searchParams.get('to')||'';
      return json(res,200,db.sales.filter(s=>inRange(s.date,from,to)).map(s=>{const b=invoiceBalance(db,s.invoiceNo,s.customerId);return {...s,customer:personName(db,s.customerId),received:b.received,balance:Math.max(0,b.balance)};}).filter(x=>x.balance>0));
    }
    if(req.method==='GET' && p==='/api/reports/cheques-detailed') { requireAuth(req,db,'cheques.read');
      const today=url.searchParams.get('today')||'';
      return json(res,200,[...(db.chequesReceived||[]).map(x=>({...x,kind:'received',person:personName(db,x.personId),days:chequeDays(x.dueDate,today)})),...(db.chequesIssued||[]).map(x=>({...x,kind:'issued',person:personName(db,x.personId),days:chequeDays(x.dueDate,today)}))]);
    }
    if(req.method==='GET' && p==='/api/reports/trial-balance') { requireAuth(req,db,'accounting.read');
      const map={}; for(const j of db.journalEntries||[]) for(const l of j.lines||[]){ map[l.account] ||= {account:l.account,debit:0,credit:0}; map[l.account].debit+=Number(l.debit||0); map[l.account].credit+=Number(l.credit||0); }
      const rows=Object.values(map).map(x=>({...x,balance:x.debit-x.credit})); return json(res,200,{rows,totalDebit:rows.reduce((a,x)=>a+x.debit,0),totalCredit:rows.reduce((a,x)=>a+x.credit,0)});
    }
    if(req.method==='GET' && p==='/api/audit'){ requireAuth(req,db,'audit.read'); return json(res,200,db.auditLogs.slice(-100).reverse()); }

    if(req.method==='POST' && p==='/api/persons'){
      requireAuth(req,db,'persons.write');
      if(!data.name) throw new Error('نام شخص الزامی است.');
      const x={id:id('per'),code:String(db.persons.length+1).padStart(5,'0'),name:data.name,type:data.type||'customer',mobile:data.mobile||'',notes:data.notes||'',createdAt:now()};
      db.persons.push(x); audit(db,'CREATE','person',x.id,null,x); writeDb(db); return json(res,201,x);
    }
    if(req.method==='POST' && p==='/api/products'){
      requireAuth(req,db,'products.write');
      if(!data.name) throw new Error('نام کالا الزامی است.');
      const x={id:id('prd'),code:String(db.products.length+1).padStart(6,'0'),name:data.name,unit:data.unit||'عدد',barcode:data.barcode||'',price:Number(data.price||0),createdAt:now()};
      db.products.push(x); audit(db,'CREATE','product',x.id,null,x); writeDb(db); return json(res,201,x);
    }
    if(req.method==='POST' && p==='/api/sales'){
      requireAuth(req,db,'sales.write');
      requireOpen(db,data.date);
      if(!data.invoiceNo||!data.customerId||!Array.isArray(data.items)||!data.items.length) throw new Error('شماره فاکتور، مشتری و حداقل یک کالا الزامی است.');
      const items=data.items.map(i=>({productId:i.productId,qty:Number(i.qty),unitPrice:Number(i.unitPrice),amount:Number(i.qty)*Number(i.unitPrice)}));
      const gross=items.reduce((a,i)=>a+i.amount,0), discount=Number(data.discount||0), freight=Number(data.freight||0), tax=Number(data.tax||0), finalAmount=gross-discount+freight+tax;
      if(finalAmount<0) throw new Error('مبلغ نهایی نمی‌تواند منفی باشد.');
      const x={id:id('sal'),invoiceNo:String(data.invoiceNo),date:data.date,customerId:data.customerId,items,grossAmount:gross,discount:Number(data.discount||0),freight:Number(data.freight||0),tax:Number(data.tax||0),finalAmount,status:'posted',createdAt:now(),updatedAt:now()};
      db.sales.push(x); rebuildJournals(db); audit(db,'CREATE','sale',x.id,null,x); writeDb(db); return json(res,201,x);
    }
    if(req.method==='PUT' && p.startsWith('/api/sales/')){
      requireAuth(req,db,'sales.write');
      const saleId=p.split('/').pop(); const old=db.sales.find(x=>x.id===saleId); if(!old) return json(res,404,{error:'فروش یافت نشد.'});
      requireOpen(db,old.date); const idx=db.sales.findIndex(x=>x.id===saleId);
      const merged={...old,...data,items:Array.isArray(data.items)?data.items:old.items};
      const items=merged.items.map(i=>({productId:i.productId,qty:Number(i.qty),unitPrice:Number(i.unitPrice),amount:Number(i.qty)*Number(i.unitPrice)}));
      const gross=items.reduce((a,i)=>a+i.amount,0), discount=Number(merged.discount||0), freight=Number(merged.freight||0), tax=Number(merged.tax||0);
      merged.items=items; merged.grossAmount=gross; merged.finalAmount=gross-discount+freight+tax; merged.updatedAt=now();
      db.sales[idx]=merged; rebuildJournals(db); audit(db,'UPDATE','sale',saleId,old,merged,'ویرایش قبل از بستن روز'); writeDb(db); return json(res,200,merged);
    }
    if(req.method==='POST' && p==='/api/purchases') {
      requireAuth(req,db,'purchases.write');
      requireOpen(db,data.date);
      if(!data.invoiceNo||!data.supplierId||!Array.isArray(data.items)||!data.items.length) throw new Error('شماره فاکتور، تأمین‌کننده و حداقل یک قلم خرید الزامی است.');
      const items=data.items.map(i=>({productId:i.productId,qty:Number(i.qty),unitPrice:Number(i.unitPrice),amount:Number(i.qty)*Number(i.unitPrice)}));
      if(items.some(i=>i.qty<=0||i.unitPrice<0)) throw new Error('تعداد باید بیشتر از صفر و قیمت معتبر باشد.');
      const gross=items.reduce((a,i)=>a+i.amount,0), discount=Number(data.discount||0), freight=Number(data.freight||0), tax=Number(data.tax||0), finalAmount=gross-discount+freight+tax;
      const x={id:id('pur'),invoiceNo:String(data.invoiceNo),date:data.date,supplierId:data.supplierId,items,grossAmount:gross,discount,freight,tax,finalAmount,status:'posted',createdAt:now(),updatedAt:now()};
      db.purchases.push(x); rebuildStock(db); rebuildJournals(db); audit(db,'CREATE','purchase',x.id,null,x); writeDb(db); return json(res,201,x);
    }
    if(req.method==='PUT' && p.startsWith('/api/purchases/')) {
      requireAuth(req,db,'purchases.write');
      const pid=p.split('/').pop(), old=db.purchases.find(x=>x.id===pid); if(!old) return json(res,404,{error:'خرید یافت نشد.'});
      requireOpen(db,old.date); const next={...old,...data,items:Array.isArray(data.items)?data.items:old.items};
      const items=next.items.map(i=>({productId:i.productId,qty:Number(i.qty),unitPrice:Number(i.unitPrice),amount:Number(i.qty)*Number(i.unitPrice)}));
      next.items=items; next.grossAmount=items.reduce((a,i)=>a+i.amount,0); next.discount=Number(next.discount||0); next.freight=Number(next.freight||0); next.tax=Number(next.tax||0); next.finalAmount=next.grossAmount-next.discount+next.freight+next.tax; next.updatedAt=now();
      db.purchases[db.purchases.findIndex(x=>x.id===pid)]=next; rebuildStock(db); rebuildJournals(db); audit(db,'UPDATE','purchase',pid,old,next,'ویرایش قبل از بستن روز'); writeDb(db); return json(res,200,next);
    }
    if(req.method==='POST' && p==='/api/receipts'){
      requireAuth(req,db,'receipts.write');
      requireOpen(db,data.date); if(!data.invoiceNo||!data.customerId||!data.sourceId||!Number(data.amount)) throw new Error('شماره فاکتور، مشتری، منبع و مبلغ الزامی است.');
      const sale=db.sales.find(x=>x.invoiceNo===String(data.invoiceNo)&&x.customerId===data.customerId); if(!sale) throw new Error('فاکتور پیدا نشد.');
      const prev=db.receipts.filter(r=>r.invoiceNo===sale.invoiceNo&&r.customerId===sale.customerId).reduce((a,r)=>a+Number(r.amount),0); const balance=Number(sale.finalAmount)-prev;
      if(Number(data.amount)>balance) throw new Error(`دریافت بیش از مانده فاکتور است. مانده مجاز: ${balance.toLocaleString('fa-IR')} ریال`);
      const x={id:id('rec'),receiptNo:`R-${String(db.receipts.length+1).padStart(5,'0')}`,date:data.date,invoiceNo:String(data.invoiceNo),customerId:data.customerId,sourceId:data.sourceId,amount:Number(data.amount),description:data.description||'',createdAt:now(),updatedAt:now()};
      db.receipts.push(x); db.receiptAllocations ||= []; db.receiptAllocations.push({id:id('ral'),receiptId:x.id,invoiceNo:x.invoiceNo,amount:x.amount}); rebuildJournals(db); audit(db,'CREATE','receipt',x.id,null,x); writeDb(db); return json(res,201,{...x,newBalance:balance-Number(data.amount)});
    }
    if(req.method==='POST' && p==='/api/payments'){
      requireAuth(req,db,'payments.write');
      requireOpen(db,data.date); if(!data.sourceId||!data.supplierId||!Number(data.amount)) throw new Error('تأمین‌کننده، منبع و مبلغ الزامی است.');
      if(data.invoiceNo){ const b=supplierInvoiceBalance(db,data.invoiceNo,data.supplierId); if(!b) throw new Error('فاکتور خرید پیدا نشد.'); if(Number(data.amount)>b.balance) throw new Error(`پرداخت بیش از مانده فاکتور خرید است. مانده مجاز: ${b.balance.toLocaleString('fa-IR')} ریال`); }
      const x={id:id('pay'),paymentNo:`P-${String(db.payments.length+1).padStart(5,'0')}`,date:data.date,supplierId:data.supplierId,sourceId:data.sourceId,invoiceNo:data.invoiceNo||'',amount:Number(data.amount),description:data.description||'',createdAt:now(),updatedAt:now()};
      db.payments.push(x); db.paymentAllocations ||= []; if(x.invoiceNo) db.paymentAllocations.push({id:id('pal'),paymentId:x.id,invoiceNo:x.invoiceNo,amount:x.amount}); rebuildJournals(db); audit(db,'CREATE','payment',x.id,null,x); writeDb(db); return json(res,201,x);
    }
    if(req.method==='PUT' && p.startsWith('/api/receipts/')){
      requireAuth(req,db,'receipts.write');
      const rid=p.split('/').pop(); const old=db.receipts.find(x=>x.id===rid); if(!old) return json(res,404,{error:'دریافت یافت نشد.'});
      requireOpen(db,old.date); const next={...old,...data,amount:Number(data.amount||old.amount),updatedAt:now()};
      const sale=db.sales.find(x=>x.invoiceNo===next.invoiceNo&&x.customerId===next.customerId); if(!sale) throw new Error('فاکتور مرتبط پیدا نشد.');
      const others=db.receipts.filter(x=>x.id!==rid&&x.invoiceNo===next.invoiceNo&&x.customerId===next.customerId).reduce((a,r)=>a+Number(r.amount),0); const balance=Number(sale.finalAmount)-others;
      if(next.amount>balance) throw new Error(`مبلغ جدید از مانده مجاز بیشتر است: ${balance.toLocaleString('fa-IR')} ریال`);
      db.receipts[db.receipts.findIndex(x=>x.id===rid)]=next; rebuildJournals(db); audit(db,'UPDATE','receipt',rid,old,next,'ویرایش قبل از بستن روز'); writeDb(db); return json(res,200,next);
    }
    if(req.method==='PUT' && p.startsWith('/api/payments/')){
      requireAuth(req,db,'payments.write');
      const pid=p.split('/').pop(); const old=db.payments.find(x=>x.id===pid); if(!old) return json(res,404,{error:'پرداخت یافت نشد.'});
      requireOpen(db,old.date); const next={...old,...data,amount:Number(data.amount||old.amount),updatedAt:now()};
      db.payments[db.payments.findIndex(x=>x.id===pid)]=next; rebuildJournals(db); audit(db,'UPDATE','payment',pid,old,next,'ویرایش قبل از بستن روز'); writeDb(db); return json(res,200,next);
    }
    if(req.method==='POST' && p==='/api/cheques'){
      requireAuth(req,db,'cheques.write');
      requireOpen(db,data.date); if(!data.kind||!data.personId||!data.amount||!data.dueDate) throw new Error('نوع، شخص، مبلغ و تاریخ سررسید الزامی است.');
      const target=data.kind==='received'?db.chequesReceived:db.chequesIssued; const x={id:id('chq'),number:String(data.number||''),personId:data.personId,amount:Number(data.amount),date:data.date,dueDate:data.dueDate,status:'in_progress',bank:data.bank||'',description:data.description||'',createdAt:now(),updatedAt:now()}; target.push(x); audit(db,'CREATE',data.kind==='received'?'cheque_received':'cheque_issued',x.id,null,x); writeDb(db); return json(res,201,x);
    }
    if(req.method==='POST' && p==='/api/cheques/status'){
      requireAuth(req,db,'cheques.write');
      const kind=data.kind, target=kind==='received'?db.chequesReceived:db.chequesIssued, x=target.find(q=>q.id===data.id); if(!x) throw new Error('چک پیدا نشد.');
      requireOpen(db,x.date); x.status=data.status||x.status; x.clearedDate=data.clearedDate||x.clearedDate||null; x.updatedAt=now(); audit(db,'UPDATE',kind==='received'?'cheque_received':'cheque_issued',x.id,{...x,status:data.status},x,'تغییر وضعیت چک'); rebuildJournals(db); writeDb(db); return json(res,200,x);
    }
    if(req.method==='POST' && p==='/api/daily-close'){
      requireAuth(req,db,'day.close');
      const date=data.date; if(!date) throw new Error('تاریخ روز مشخص نیست.'); const s=summary(db,date);
      if(s.mismatches.length) throw new Error(`بستن روز ممکن نیست؛ ${s.mismatches.length} مورد مغایرت/خطا وجود دارد.`);
      if(dayClosed(db,date)) return json(res,200,{ok:true,alreadyClosed:true});
      const x={id:id('day'),date,status:'closed',closedBy:'demo-manager',closedAt:now(),reopenReason:null}; db.dailyCloses.push(x); audit(db,'CLOSE_DAY','daily_close',x.id,null,x); writeDb(db); return json(res,200,x);
    }
    if(req.method==='POST' && p==='/api/daily-reopen'){
      requireAuth(req,db,'day.reopen');
      const date=data.date, reason=data.reason||''; const x=db.dailyCloses.find(x=>x.date===date&&x.status==='closed'); if(!x) throw new Error('روز بسته‌شده پیدا نشد.');
      x.status='reopened'; x.reopenReason=reason; x.reopenedBy='demo-manager'; x.reopenedAt=now(); audit(db,'REOPEN_DAY','daily_close',x.id,{status:'closed'},x,reason); writeDb(db); return json(res,200,x);
    }
    if(req.method==='GET' && p==='/api/export/json'){ requireAuth(req,db,'export.read'); return json(res,200,{exportedAt:now(),company:db.company,fiscalYears:db.fiscalYears,persons:db.persons,products:db.products,sources:db.sources,sales:db.sales,purchases:db.purchases,receipts:db.receipts,payments:db.payments,chequesReceived:db.chequesReceived,chequesIssued:db.chequesIssued,journalEntries:db.journalEntries,stockMovements:db.stockMovements}); }
    if(req.method==='POST' && p==='/api/backup'){ requireAuth(req,db,'backup.write'); const backupPath=path.resolve(__dirname,'backups'); fs.mkdirSync(backupPath,{recursive:true}); const stamp=new Date().toISOString().replace(/[:.]/g,'-'); const jsonFile=path.join(backupPath,`backup-${stamp}.json`); const dbFile=path.join(backupPath,`backup-${stamp}.sqlite`); fs.writeFileSync(jsonFile,JSON.stringify(db,null,2)); writeDb(db); sqliteBackup(dbFile); audit(db,'BACKUP','database',null,null,{json:path.basename(jsonFile),sqlite:path.basename(dbFile)}); writeDb(db); return json(res,201,{ok:true,jsonFile:path.basename(jsonFile),sqliteFile:path.basename(dbFile)}); }
    if(req.method==='POST' && p==='/api/reset-demo'){
      requireAuth(req,db,'backup.write');
      db={persons:[],products:[],sources:db.sources,sales:[],purchases:[],receipts:[],payments:[],chequesReceived:[],chequesIssued:[],journalEntries:[],dailyCloses:[],auditLogs:[],stockMovements:[],receiptAllocations:[],paymentAllocations:[]}; writeDb(db); return json(res,200,{ok:true});
    }
    return json(res,404,{error:'مسیر API پیدا نشد.'});
  } catch(e) { return json(res,e.status||400,{error:e.message||'خطای نامشخص'}); }
}

let writeQueue=Promise.resolve();
function enqueueMutation(fn){
  const run=writeQueue.then(fn,fn);
  writeQueue=run.catch(()=>{});
  return run;
}

const server=http.createServer((req,res)=>{
  if(req.url.startsWith('/api/')) {
    if(req.method==='GET') return api(req,res);
    return enqueueMutation(()=>api(req,res));
  }
  let p=new URL(req.url,'http://localhost').pathname; if(p==='/') p='/index.html';
  const file=path.join(ROOT,p);
  if(!file.startsWith(ROOT)||!fs.existsSync(file)){res.writeHead(404);return res.end('Not found');}
  res.writeHead(200,{'content-type':mime[path.extname(file)]||'application/octet-stream','cache-control':'no-store'});
  fs.createReadStream(file).pipe(res);
});
server.listen(PORT,()=>console.log(`MR.KHRASANI v0.7 running on http://localhost:${PORT}`));
