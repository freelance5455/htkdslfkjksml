#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
command -v node >/dev/null || { echo "Node.js لازم است."; exit 1; }
command -v adb >/dev/null || { echo "Android SDK/adb یافت نشد. APK در این محیط قابل Build نیست."; exit 2; }
command -v gradle >/dev/null || { echo "Gradle یافت نشد. Android Studio/Gradle را نصب کنید."; exit 3; }
cd "$ROOT/apps/mobile"
npm install
npx cap add android || true
npx cap sync android
cd android
gradle assembleRelease
