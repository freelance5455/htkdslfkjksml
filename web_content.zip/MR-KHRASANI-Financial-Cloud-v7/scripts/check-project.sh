#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
for f in \
  "$root/apps/web/index.html" \
  "$root/apps/web/app.js" \
  "$root/apps/web/style.css" \
  "$root/apps/api/server.js" \
  "$root/apps/api/store.json" \
  "$root/database/schema.sql" \
  "$root/apps/mobile/capacitor.config.ts"; do
  test -f "$f" || { echo "Missing: $f"; exit 1; }
done
node --check "$root/apps/api/server.js"
node --check "$root/scripts/smoke-test.js"
echo "PROJECT CHECK OK"
