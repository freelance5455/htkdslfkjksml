const http=require('http');
const base=process.env.BASE_URL||'http://127.0.0.1:8096';
function req(path,opt={}){return new Promise((resolve,reject)=>{const u=new URL(path,base);const r=http.request(u,{method:opt.method||'GET',headers:{'content-type':'application/json',...(opt.headers||{})}},res=>{let s='';res.on('data',d=>s+=d);res.on('end',()=>{let j={};try{j=JSON.parse(s)}catch{};resolve({status:res.statusCode,body:j})})});r.on('error',reject);if(opt.body)r.write(JSON.stringify(opt.body));r.end()})}
(async()=>{
 let r=await req('/api/health'); if(r.status!==200||!r.body.ok) throw Error('health failed');
 r=await req('/api/bootstrap'); if(r.status!==401) throw Error('unauthenticated bootstrap should be blocked');
 r=await req('/api/auth/login',{method:'POST',body:{username:'admin',password:'Admin123!'}}); if(r.status!==200||!r.body.token) throw Error('login failed');
 const auth={authorization:'Bearer '+r.body.token};
 r=await req('/api/auth/me',{headers:auth}); if(r.status!==200||r.body.user.role!=='manager') throw Error('me failed');
 r=await req('/api/bootstrap',{headers:auth}); if(r.status!==200) throw Error('authenticated bootstrap failed');
 r=await req('/api/export/json',{headers:auth}); if(r.status!==200) throw Error('export failed');
 console.log('V0.6 SMOKE TEST OK');
})().catch(e=>{console.error(e.message);process.exit(1)})
