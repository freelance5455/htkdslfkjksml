# Build guide

## Web/API prototype
Requires Node.js 20+.

```bash
cd apps/api
npm start
```
Then open http://localhost:8080

## PostgreSQL
Create a PostgreSQL database and run `database/schema.sql`.

## Android
The Android wrapper is planned with Capacitor. A complete signed APK cannot be produced in this environment because the Android SDK/Gradle toolchain is not installed. On a build machine with Android Studio/SDK:

1. install Node 20+
2. install Android SDK + API 36 + build-tools
3. add Capacitor Android platform
4. configure production API URL
5. build signed release APK

The production build must use HTTPS and a protected server-side database; do not ship database credentials in the APK.
