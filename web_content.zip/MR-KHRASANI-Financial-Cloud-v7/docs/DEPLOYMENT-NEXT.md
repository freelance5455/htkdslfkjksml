# Deployment next step

`docker-compose.yml` is an infrastructure scaffold for PostgreSQL + Node.

Before production use, the API must switch its persistence provider from `store.json` to PostgreSQL and the web assets must be served from the API container or a separate web container. Do not expose PostgreSQL publicly in production; keep it on a private network.
