# Implementation status — v0.2.0

## Implemented in this stage
- Single-company model
- Persian RTL responsive UI
- Person and product creation
- Sales creation
- Purchase form placeholder
- Invoice-linked receipts
- Receipt amount validation against invoice balance
- Multi-source receipts by separate receipt rows
- Payments
- Basic cheque creation
- Journal generation for sales/purchases/receipts/payments
- Trial-balance invariant check at journal level
- Daily control summary
- Daily close and lock
- Direct edit of sales/receipts/payments before a closed day
- Audit trail for create/update/close/reopen
- Open-invoice report
- Android/Capacitor build layer definition

## Demo persistence
The current API stage uses a local JSON store (`apps/api/store.json`) so the workflow can run without a database service.

## Production database migration
The schema already exists in `database/schema.sql`. The next engineering stage should replace the JSON repository with PostgreSQL transactions and migrations, keeping the same API contract.

## Not yet final
- Full multi-line purchase UI
- Full multi-line sales UI
- Stock movement engine
- Full chart of accounts editor
- Tax rule engine / electronic invoicing integration
- Full cheque lifecycle
- Excel import/export execution
- PDF reporting
- Cloud object storage
- Production auth / MFA / password recovery
- Automated backups and restore UI
- Full Android native project generation and signed APK
