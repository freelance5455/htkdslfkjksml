# API contract v0.1

GET /api/health
GET /api/persons?q=
POST /api/persons
PATCH /api/persons/:id
GET /api/products?q=
POST /api/sales
PATCH /api/sales/:id
GET /api/sales/:id/balance
POST /api/receipts
PATCH /api/receipts/:id
POST /api/payments
POST /api/cheques/received
POST /api/cheques/issued
GET /api/reports/trial-balance?from=&to=
GET /api/reports/open-invoices?from=&to=
GET /api/reports/person/:id?from=&to=
POST /api/daily-close/check
POST /api/daily-close
POST /api/daily-close/reopen
GET /api/audit-logs
POST /api/import/excel/validate
POST /api/import/excel/commit
GET /api/export/:report
