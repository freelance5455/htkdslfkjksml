# Android Release

The project includes an Android-ready web/mobile configuration. The final APK must be built on a machine with Android SDK + Gradle/Android Studio because those toolchains are not available in the current build environment.

Before release set `window.MRKHRASANI_API_BASE` in `apps/web/app-config.js` to the HTTPS production API URL. Do not embed database credentials in the APK.

Recommended build path:
1. Install Node 20+ and Android Studio.
2. Install Android SDK platform/build-tools matching the project's compile SDK.
3. Generate/sync Capacitor Android project.
4. Configure a signed release key.
5. Build `assembleRelease`.
6. Install and smoke-test login, sale, receipt, daily close, reports and logout on a real Android device.
