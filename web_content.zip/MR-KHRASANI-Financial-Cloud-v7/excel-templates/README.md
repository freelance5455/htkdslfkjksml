Templates to be added in the implementation phase:
persons.xlsx, products.xlsx, sales.xlsx, purchases.xlsx, receipts.xlsx, payments.xlsx
