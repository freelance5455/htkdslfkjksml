# MR.KHRASANI Financial Cloud v0.6

سامانه تک‌شرکتی مدیریت مالی، حسابداری، فروش، خرید، دریافت/پرداخت، چک و انبار با رابط فارسی RTL.

## این نسخه چه چیزی را جلو برده است؟

### 1) احراز هویت و سطح دسترسی
- ورود کاربر از طریق API
- نشست ۱۲ ساعته
- نقش‌های `manager`، `accountant` و `sales`
- کنترل دسترسی در سمت سرور برای جلوگیری از دور زدن محدودیت‌ها از طریق رابط کاربری

### 2) زیرساخت Cloud-ready
- متادیتای شرکت و سال مالی
- API مستقل از رابط کاربری
- مسیر Export JSON
- مسیر Backup
- migration آماده PostgreSQL در `database/v0.6-cloud-migration.sql`

### 3) هسته مالی نسخه‌های قبلی حفظ شده
- فروش و خرید چندقلمی در API
- موجودی و گردش کالا
- دریافت و پرداخت فاکتوری
- تخصیص دریافت/پرداخت
- چک دریافتی و پرداختی
- سند دوبل
- تراز آزمایشی
- گزارش مانده مشتری و تأمین‌کننده
- فاکتورهای باز
- کنترل موجودی منفی
- بستن و بازگشایی روز
- Audit Trail

## حساب‌های توسعه
این حساب‌ها فقط برای محیط توسعه هستند:

| نقش | نام کاربری | رمز پیش‌فرض |
|---|---|---|
| مدیر | `admin` | `Admin123!` |
| حسابدار | `accountant` | `Accountant123!` |
| فروش | `sales` | `Sales123!` |

در محیط واقعی باید رمزها با متغیرهای محیطی جایگزین شوند و ذخیره‌سازی JSON با PostgreSQL تعویض شود.

## اجرای محلی

```bash
cd apps/api
npm start
```

سپس مرورگر را روی `http://localhost:8080` باز کنید.

## تست

```bash
PORT=8099 node apps/api/server.js
BASE_URL=http://127.0.0.1:8099 node scripts/smoke-test-v6.js
```

## مرز Production
این نسخه **Cloud-ready است، اما هنوز Deployment ابری Production نیست**. داده‌های عملیاتی در این مرحله همچنان در `apps/api/store.json` ذخیره می‌شوند. migration PostgreSQL آماده است تا در مرحله بعد persistence واقعی، transactionهای دیتابیس، مدیریت session و backup سمت سرور جایگزین شوند.

برای Production باید حداقل موارد زیر اعمال شود:
- HTTPS
- PostgreSQL
- password hashing استاندارد
- session token hash شده در DB
- rate limiting ورود
- مدیریت Secret
- backup رمزنگاری‌شده
- transaction برای عملیات مالی
- لاگ و مانیتورینگ سرور
- محدودسازی CORS

## Android
پروژه Capacitor در `apps/mobile` آماده نگه داشته شده است. ساخت APK Release نیازمند Android SDK/Gradle و signing key است و در این محیط ادعای APK ساخته‌شده نمی‌شود.
