AUTOVITRINE — PROTÓTIPO HTML

COMO TESTAR
1. Extraia o ZIP.
2. Abra index.html em um navegador para uma prévia básica.
3. Para instalar como PWA e testar o service worker, publique a pasta em hospedagem HTTPS (ex.: Vercel ou Netlify).

O QUE ESTA VERSÃO TEM
- Página inicial e catálogo responsivo
- Pesquisa simples e filtros por categoria
- Favoritos salvos no navegador do dispositivo
- Detalhes e ficha técnica básica
- Área administrativa demonstrativa
- Cadastro e exclusão de anúncios salvos no localStorage
- Estrutura inicial de PWA

LIMITAÇÕES IMPORTANTES
- Os carros iniciais são exemplos demonstrativos.
- Cadastro e favoritos ficam somente no navegador/dispositivo atual. Ainda não há sincronização entre aparelhos.
- O botão "Preparar ficha com IA" é apenas uma demonstração; não consulta uma IA nem fontes externas.
- A área administrativa ainda não tem login ou proteção real. Não publique com dados privados.
- O visualizador 3D é um espaço reservado; para funcionar de verdade é necessário carregar um modelo GLB específico e licenciado para cada carro.
- Não há backend, banco de dados, armazenamento de imagens, WhatsApp ou integração com serviços externos.

PARA VIRAR APLICATIVO
Este HTML pode servir como base para um PWA ou ser empacotado com Capacitor para Android/iOS. Para publicar nas lojas, ainda será necessário configurar o projeto nativo, ícones, permissões, política de privacidade, testes e contas de desenvolvedor. O ZIP não é um APK/IPA pronto.

PRÓXIMA ETAPA RECOMENDADA
Conectar Supabase para login administrativo, banco de dados compartilhado e upload das fotos/modelos 3D; depois integrar o serviço de IA no servidor, sem expor chaves secretas no HTML.
