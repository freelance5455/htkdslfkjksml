<?php
// --- 1. DATA COLLECTION ---
$orderId = $_REQUEST['orderid'] ?? 'N/A';
$amount = $_REQUEST['amount'] ?? '0.00';
$userId = $_REQUEST['userid'] ?? 'N/A';
$userEmail = $_REQUEST['email'] ?? 'Not Provided';

// Set Indian Time Zone
date_default_timezone_set('Asia/Kolkata');
$currentDate = date('d M, Y h:i A');

// --- LOG FILE ---
$logFile = 'telegram_log.txt';

// --- 2. TELEGRAM NOTIFICATION SYSTEM ---
if ($amount > 0) {
    
    $botToken = "8995963268:AAEB7MUXvgPN2lgqPJ9oMiOdx6yMVh9V4hU";
    $chatId = "8591379261";

    // --- UPGRADED MESSAGE DESIGN ---
    $message = "💎 *PAYMENT SUCCESSFUL* 💎\n\n";
    $message .= "━━━━━━━━━━━━━━━━━━━━\n";
    $message .= "💰 *Amount:* ₹" . number_format($amount, 2) . "\n";
    $message .= "🆔 *Transaction ID:* `" . $orderId . "`\n";
    $message .= "👤 *User ID:* `" . $userId . "`\n";
    if($userEmail != 'Not Provided') {
        $message .= "📧 *Email:* " . $userEmail . "\n";
    }
    $message .= "📅 *Date:* " . $currentDate . "\n";
    $message .= "━━━━━━━━━━━━━━━━━━━━\n";
    $message .= "✅ *Status:* SUCCESSFUL\n";
    $message .= "💵 *Payment Received & Added to Wallet*\n";
    $message .= "━━━━━━━━━━━━━━━━━━━━\n";
    $message .= "🎯 *VC Gateway* | India's Best Payment Gateway";

    $data = [
        'chat_id' => $chatId,
        'text' => $message,
        'parse_mode' => 'Markdown'
    ];

    // --- SMART SENDER FUNCTION ---
    $endpoints = [
        "https://api.telegram.org/bot$botToken/sendMessage",
        "https://149.154.167.220/bot$botToken/sendMessage",
        "https://91.108.56.113/bot$botToken/sendMessage"
    ];

    $sent = false;
    $responseLog = [];

    foreach ($endpoints as $index => $url) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ["Host: api.telegram.org"]);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        
        $result = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        // --- LOG EACH ATTEMPT ---
        $logEntry = "[" . date('Y-m-d H:i:s') . "] ";
        $logEntry .= "Attempt " . ($index + 1) . " | ";
        $logEntry .= "URL: " . parse_url($url, PHP_URL_HOST) . " | ";
        $logEntry .= "HTTP Code: $httpCode | ";
        
        if ($httpCode == 200 && $result) {
            $response = json_decode($result, true);
            if (isset($response['ok']) && $response['ok'] === true) {
                $logEntry .= "✅ SUCCESS! Message sent.\n";
                $sent = true;
                $responseLog[] = $logEntry;
                break;
            } else {
                $logEntry .= "❌ API Error: " . ($response['description'] ?? 'Unknown error') . "\n";
                $responseLog[] = $logEntry;
            }
        } else {
            $logEntry .= "❌ FAILED | ";
            if ($curlError) {
                $logEntry .= "CURL Error: $curlError\n";
            } else {
                $logEntry .= "Response: " . substr($result, 0, 200) . "\n";
            }
            $responseLog[] = $logEntry;
        }
    }

    // --- FINAL LOG ---
    if ($sent) {
        $log = "[" . date('Y-m-d H:i:s') . "] ✅ SUCCESS: Payment notification sent to Telegram!\n";
        $log .= "Order ID: $orderId | Amount: ₹$amount | User: $userId\n";
        $log .= "------------------------------------------------\n";
    } else {
        $log = "[" . date('Y-m-d H:i:s') . "] ❌ FAILED: Could not send Telegram notification!\n";
        $log .= "Order ID: $orderId | Amount: ₹$amount | User: $userId\n";
        $log .= "All attempts failed.\n";
        $log .= "------------------------------------------------\n";
    }
    
    // Write to log file
    file_put_contents($logFile, $log, FILE_APPEND);
    
    // Also write detailed attempts
    if (!empty($responseLog)) {
        file_put_contents($logFile, implode("", $responseLog), FILE_APPEND);
        file_put_contents($logFile, "------------------------------------------------\n", FILE_APPEND);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Payment Success</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        :root {
            --bg-primary: #05051E;
            --bg-secondary: #141432;
            --card-bg: #151530;
            --text-primary: #FFFFFF;
            --text-secondary: #A0A0B8;
            --accent-cyan: #00E0FF;
            --accent-pink: #FF3D71;
            --btn-green: #4CAF50;
            --border-color: #2a2a4a;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
            -webkit-tap-highlight-color: transparent;
        }

        body {
            background: var(--bg-primary);
            color: var(--text-primary);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }

        .success-card {
            width: 100%;
            max-width: 420px;
            background: var(--bg-secondary);
            border-radius: 24px;
            padding: 32px 24px 28px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
            text-align: center;
            position: relative;
            border: 1px solid var(--border-color);
            animation: fadeInUp 0.5s cubic-bezier(0.16, 1, 0.3, 1);
            overflow: hidden;
        }

        .success-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 80%;
            height: 4px;
            background: linear-gradient(90deg, var(--btn-green), var(--accent-cyan));
            border-radius: 0 0 10px 10px;
        }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .icon-wrapper {
            width: 96px;
            height: 96px;
            margin: 8px auto 18px;
            background: rgba(76, 175, 80, 0.12);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 2px solid rgba(76, 175, 80, 0.4);
            position: relative;
            animation: popIn 0.6s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            box-shadow: 0 0 30px rgba(76, 175, 80, 0.2);
        }

        @keyframes popIn {
            0% { transform: scale(0); opacity: 0; }
            100% { transform: scale(1); opacity: 1; }
        }

        .icon-wrapper i {
            font-size: 46px;
            color: var(--btn-green);
        }

        .icon-wrapper .confetti {
            position: absolute;
            width: 100%;
            height: 100%;
            border-radius: 50%;
            border: 2px solid rgba(0, 224, 255, 0.25);
            animation: confettiRing 2s ease-out infinite;
        }

        @keyframes confettiRing {
            0% { transform: scale(1); opacity: 1; }
            100% { transform: scale(1.5); opacity: 0; }
        }

        .dot {
            position: absolute;
            width: 6px;
            height: 6px;
            border-radius: 50%;
            animation: floatDot 2s ease-out infinite;
        }
        .dot:nth-child(2) { top: -5px; left: 20%; animation-delay: 0.2s; background: var(--accent-cyan); }
        .dot:nth-child(3) { top: -5px; right: 20%; animation-delay: 0.4s; background: var(--btn-green); }
        .dot:nth-child(4) { bottom: -5px; left: 15%; animation-delay: 0.6s; background: var(--accent-pink); }
        .dot:nth-child(5) { bottom: -5px; right: 15%; animation-delay: 0.8s; background: var(--accent-cyan); }

        @keyframes floatDot {
            0% { transform: translateY(0) scale(1); opacity: 1; }
            100% { transform: translateY(-20px) scale(0); opacity: 0; }
        }

        .success-title {
            font-size: 24px;
            font-weight: 700;
            color: var(--text-primary);
            letter-spacing: -0.3px;
            margin-bottom: 6px;
        }

        .success-sub {
            font-size: 14px;
            color: var(--text-secondary);
            margin-bottom: 20px;
        }
        .success-sub i {
            color: var(--accent-cyan);
            margin-right: 4px;
        }

        .amount-box {
            background: linear-gradient(135deg, rgba(0, 224, 255, 0.15), rgba(76, 175, 80, 0.15));
            padding: 18px;
            border-radius: 16px;
            margin-bottom: 20px;
            border: 1px solid rgba(0, 224, 255, 0.3);
        }
        .amount-label {
            font-size: 11px;
            font-weight: 600;
            color: var(--text-secondary);
            text-transform: uppercase;
            letter-spacing: 1.5px;
        }
        .amount-val {
            font-size: 34px;
            font-weight: 700;
            color: var(--accent-cyan);
            letter-spacing: -0.5px;
            line-height: 1.2;
            margin-top: 4px;
            text-shadow: 0 0 20px rgba(0, 224, 255, 0.4);
        }
        .amount-val i {
            font-size: 22px;
            margin-right: 4px;
        }

        .details-grid {
            width: 100%;
            background: var(--card-bg);
            border-radius: 14px;
            padding: 14px 18px;
            border: 1px solid var(--border-color);
            margin-bottom: 20px;
            text-align: left;
        }
        .d-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 9px 0;
            border-bottom: 1px solid var(--border-color);
            gap: 8px;
        }
        .d-row:last-child {
            border-bottom: none;
            padding-bottom: 0;
        }
        .d-label {
            font-size: 13px;
            font-weight: 500;
            color: var(--text-secondary);
            white-space: nowrap;
        }
        .d-label i {
            width: 18px;
            margin-right: 6px;
            color: var(--accent-cyan);
        }
        .d-val {
            font-size: 13px;
            font-weight: 600;
            color: var(--text-primary);
            text-align: right;
            word-break: break-all;
        }
        .d-val .order-id {
            font-family: 'Courier New', monospace;
            color: var(--accent-cyan);
            font-size: 12px;
            background: rgba(0, 224, 255, 0.1);
            padding: 3px 10px;
            border-radius: 6px;
            border: 1px solid rgba(0, 224, 255, 0.25);
            display: inline-block;
            max-width: 100%;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .status-badge {
            background: rgba(76, 175, 80, 0.15);
            color: var(--btn-green);
            padding: 3px 14px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 700;
            border: 1px solid rgba(76, 175, 80, 0.4);
            display: inline-block;
        }
        .status-badge i {
            margin-right: 4px;
            font-size: 10px;
        }

        .wallet-msg {
            padding: 12px 14px;
            background: rgba(76, 175, 80, 0.1);
            border-radius: 12px;
            border: 1px solid rgba(76, 175, 80, 0.3);
            font-size: 13px;
            color: #4CAF50;
            font-weight: 600;
            margin-bottom: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        .wallet-msg i {
            font-size: 14px;
        }

        .btn-action {
            width: 100%;
            padding: 16px;
            border-radius: 50px;
            border: none;
            background: linear-gradient(90deg, var(--accent-cyan), #0099CC);
            color: #000;
            font-size: 15px;
            font-weight: 700;
            cursor: pointer;
            text-decoration: none;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            transition: transform 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                        box-shadow 0.25s ease;
            box-shadow: 0 8px 25px rgba(0, 224, 255, 0.35);
            text-transform: uppercase;
            letter-spacing: 1px;
            will-change: transform;
        }
        .btn-action:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 35px rgba(0, 224, 255, 0.5);
        }
        .btn-action:active {
            transform: scale(0.97);
        }
        .btn-action i {
            font-size: 14px;
        }

        @media (max-width: 480px) {
            .success-card {
                padding: 26px 18px 22px;
            }
            .icon-wrapper {
                width: 80px;
                height: 80px;
                margin-bottom: 14px;
            }
            .icon-wrapper i {
                font-size: 38px;
            }
            .success-title {
                font-size: 20px;
            }
            .success-sub {
                font-size: 13px;
            }
            .amount-val {
                font-size: 28px;
            }
            .d-label, .d-val {
                font-size: 12px;
            }
        }
    </style>
</head>
<body>

    <div class="success-card">

        <div class="icon-wrapper">
            <span class="confetti"></span>
            <span class="dot"></span>
            <span class="dot"></span>
            <span class="dot"></span>
            <span class="dot"></span>
            <i class="fa-regular fa-circle-check"></i>
        </div>

        <h1 class="success-title">Payment Successful!</h1>
        <p class="success-sub">
            <i class="fa-regular fa-circle-check"></i> 
            Your payment has been received successfully.
        </p>

        <div class="amount-box">
            <div class="amount-label">Amount Added</div>
            <div class="amount-val"><i class="fa-solid fa-indian-rupee-sign"></i> <?= number_format($amount, 2) ?></div>
        </div>

        <div class="details-grid">
            <div class="d-row">
                <span class="d-label"><i class="fa-solid fa-id-card"></i> Transaction ID</span>
                <span class="d-val"><span class="order-id"><?= htmlspecialchars($orderId) ?></span></span>
            </div>
            <div class="d-row">
                <span class="d-label"><i class="fa-regular fa-clock"></i> Date & Time</span>
                <span class="d-val"><?= $currentDate ?></span>
            </div>
            <div class="d-row">
                <span class="d-label"><i class="fa-regular fa-circle"></i> Status</span>
                <span class="d-val"><span class="status-badge"><i class="fa-regular fa-circle-check"></i> COMPLETED</span></span>
            </div>
        </div>

        <div class="wallet-msg">
            <i class="fa-regular fa-circle-check"></i>
            ₹<?= number_format($amount, 2) ?> has been added to your wallet!
        </div>

        <a href="index.html" class="btn-action">
            <i class="fa-solid fa-arrow-right"></i> GO TO DASHBOARD
        </a>

    </div>

</body>
</html>