# NABD — Real Firebase starter

تم ربط واجهة NABD الحالية بـ Firebase Authentication + Cloud Firestore.

## ما أصبح حقيقيًا في هذه النسخة
- إنشاء حساب بالبريد وكلمة المرور.
- تسجيل الدخول.
- إنشاء ملف مستخدم في `users`.
- عرض مستخدمي NABD المسجلين.
- بدء محادثة مع مستخدم آخر.
- إرسال الرسائل وحفظها في Firestore.
- استقبال الرسائل لحظيًا عبر `onSnapshot`.

## إعداد Firebase (مرة واحدة)
من Firebase Console لمشروع `nabed-99bc4`:

1. Authentication → Sign-in method → فعّل **Email/Password**.
2. Firestore Database → Create database.
3. استخدم `firestore.rules` الموجودة في هذه الحزمة لقواعد Firestore.

> لا ترسل كلمات مرور Firebase أو Service Account JSON إلى أي شخص. إعدادات Firebase Web الموجودة في التطبيق مناسبة للتطبيقات الويب، لكن الأمان الحقيقي يعتمد على Authentication وFirestore Security Rules.

## APK
هذه النسخة ما زالت تعتمد على WebView/CDN، لذلك يجب أن يكون الهاتف متصلًا بالإنترنت عند استخدام Firebase وموارد الواجهة.

لبناء APK عبر Expo/EAS من مجلد `nabd-apk`:
```bash
npm install
npm install -g eas-cli
eas login
eas build -p android --profile preview
```

## الخطوة التالية
بعد اختبار حسابين، يمكن إضافة الصور والملفات والصوت، الإشعارات، الحالات المحفوظة في Firestore/Storage، ثم المكالمات WebRTC الحقيقية.
