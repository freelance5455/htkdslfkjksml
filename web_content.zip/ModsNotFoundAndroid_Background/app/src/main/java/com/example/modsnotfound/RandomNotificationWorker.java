package com.example.modsnotfound;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.work.Worker;
import androidx.work.WorkerParameters;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;
import androidx.work.ExistingWorkPolicy;

import java.util.Random;
import java.util.concurrent.TimeUnit;

public class RandomNotificationWorker extends Worker {
    private static final String CHANNEL_ID = "mod_messages";
    private static final String WORK_NAME = "random_mod_notifications";

    private static final String[] MESSAGES = {
        "Моды ждут",
        "Быстрее🙂",
        "Я нашел интересный мод: attempts playback",
        "Скачиваеться модов: 3"
    };

    public RandomNotificationWorker(Context context, WorkerParameters params) {
        super(context, params);
    }

    @Override
    public Result doWork() {
        Context context = getApplicationContext();

        if (Build.VERSION.SDK_INT >= 33 &&
                context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            return Result.success();
        }

        showRandomNotification(context);
        scheduleNext(context);
        return Result.success();
    }

    private void showRandomNotification(Context context) {
        NotificationManager manager =
            (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "Уведомления о модах",
                NotificationManager.IMPORTANCE_DEFAULT
            );
            channel.setDescription("Случайные сообщения приложения");
            manager.createNotificationChannel(channel);
        }

        String message = MESSAGES[new Random().nextInt(MESSAGES.length)];

        Intent openApp = new Intent(context, MainActivity.class);
        PendingIntent pending = PendingIntent.getActivity(
            context, 0, openApp,
            PendingIntent.FLAG_UPDATE_CURRENT |
                (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0)
        );

        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
            ? new Notification.Builder(context, CHANNEL_ID)
            : new Notification.Builder(context);

        Notification notification = builder
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Mods Not Found")
            .setContentText(message)
            .setStyle(new Notification.BigTextStyle().bigText(message))
            .setAutoCancel(true)
            .setContentIntent(pending)
            .build();

        manager.notify(new Random().nextInt(100000), notification);
    }

    private void scheduleNext(Context context) {
        long delayMinutes = 1 + new Random().nextInt(5);

        OneTimeWorkRequest next =
            new OneTimeWorkRequest.Builder(RandomNotificationWorker.class)
                .setInitialDelay(delayMinutes, TimeUnit.MINUTES)
                .build();

        WorkManager.getInstance(context).enqueueUniqueWork(
            WORK_NAME, ExistingWorkPolicy.REPLACE, next
        );
    }
}
