package com.example.modsnotfound;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.work.ExistingWorkPolicy;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;

import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {
    private static final String WORK_NAME = "random_mod_notifications";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        WebView webView = new WebView(this);
        webView.setWebViewClient(new WebViewClient());
        webView.getSettings().setJavaScriptEnabled(true);
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");

        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
        } else {
            scheduleNotifications();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == 100 && results.length > 0 &&
                results[0] == PackageManager.PERMISSION_GRANTED) {
            scheduleNotifications();
        }
    }

    private void scheduleNotifications() {
        // WorkManager сохраняет задачу, даже если приложение закрыть или перезапустить телефон.
        // Android может немного сдвигать время выполнения ради экономии батареи.
        long delayMinutes = 1 + (long)(Math.random() * 5);

        OneTimeWorkRequest request =
            new OneTimeWorkRequest.Builder(RandomNotificationWorker.class)
                .setInitialDelay(delayMinutes, TimeUnit.MINUTES)
                .build();

        WorkManager.getInstance(getApplicationContext()).enqueueUniqueWork(
            WORK_NAME, ExistingWorkPolicy.KEEP, request
        );
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}
