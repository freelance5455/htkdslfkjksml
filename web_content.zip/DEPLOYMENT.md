# Production checklist
- Use managed PostgreSQL.
- Use HTTPS.
- Set a long random JWT_SECRET and unique admin password.
- Back up PostgreSQL.
- Configure real MAZO HUB shipping fees, returns, privacy and terms.
- Add real product images through Admin or your production object storage/CDN.
- Test COD checkout and stock deduction in staging before opening orders.
- Add your preferred hosting/reverse proxy and domain.
