# SOCIAL BOOST — Production Deployment & Android APK Guide

## 1. Architecture Overview
- **Frontend**: React 19 + TypeScript + Tailwind CSS v4 + Motion (`src/`)
- **Backend**: Node.js + Express (`server.ts`, `server/routes.ts`, `server/payments.ts`, `server/security.ts`)
- **Database**: SQLite via `better-sqlite3` (`server/db.ts`) with relational tables: `users`, `admin_accounts`, `services`, `orders`, `payments`, `transactions`, `refunds`, `support_tickets`, `payment_settings`, and `audit_logs`.
- **Payment Security**:
  - Prices are calculated authoritatively on the server using `(Selected quantity ÷ Reference quantity) × Reference price`.
  - Direct UPI QR / Merchant UPI ID payments are verified by the administrator (`rudra@1941`) against the 12-digit UTR reference before fulfillment.
  - Razorpay live gateway payments are verified via HMAC-SHA256 webhook signature (`POST /api/webhooks/razorpay`).

## 2. Production Deployment Steps
1. Configure environment secrets (never commit `.env` or secret keys):
   - `NODE_ENV=production`
   - `PORT=3000`
   - `SESSION_SECRET=<64-char random hex>`
   - `DATABASE_PATH=/var/data/social_boost.db`
2. Build and start the server:
   ```bash
   npm install
   npm run build
   npm start
   ```

## 3. Enabling Automatic Razorpay Verification (Optional)
1. Complete Razorpay merchant KYC, business entity verification, and platform policy compliance review.
2. Set server-side secrets:
   - `PAYMENT_MODE=razorpay`
   - `RAZORPAY_KEY_ID=rzp_live_...`
   - `RAZORPAY_KEY_SECRET=...`
   - `RAZORPAY_WEBHOOK_SECRET=...`
3. Configure Razorpay Dashboard webhook URL:
   - Endpoint: `https://<your-production-domain>/api/webhooks/razorpay`
   - Subscribe to: `payment.captured`, `payment.pending`, and `payment.failed`

## 4. Building the Android APK (`android/` Project Included)
This repository already includes the configured Capacitor Android project (`capacitor.config.ts` and `android/`).

### Option A: Local Build (Android Studio / Gradle with Java 21 & Android SDK)
```bash
# Point the APK at your live HTTPS backend URL, build & sync:
CAPACITOR_SERVER_URL="https://your-production-domain.com" npm run apk:sync

# Compile the APK:
cd android
./gradlew assembleDebug
# Or signed release APK:
./gradlew assembleRelease
```
The compiled APK is saved at `android/app/build/outputs/apk/debug/app-debug.apk`.

### Option B: Cloud Build via GitHub Actions
Push this project to GitHub and run the included **Build Android APK** workflow (`.github/workflows/build-android-apk.yml`) to download `app-debug.apk` directly from GitHub Actions artifacts without installing Android Studio locally.
