IL MIO RICETTARIO — INSTALLAZIONE SUL TELEFONO

IMPORTANTE:
Il file HTML può essere aperto subito, ma per installarlo come vera PWA
(Android, icona nella schermata Home e modalità app) deve essere pubblicato
su un indirizzo HTTPS.

OPZIONE SEMPLICE DA TELEFONO — NETLIFY:
1. Apri Chrome sul telefono e vai su https://app.netlify.com/drop
2. Crea/accedi al tuo account Netlify.
3. Carica l'intera cartella contenuta in questo ZIP (non solo l'HTML).
4. Netlify genera un link HTTPS.
5. Apri quel link con Chrome.
6. Premi "Installa sul telefono" quando compare, oppure Chrome ⋮ → Aggiungi alla schermata Home.

FILE IMPORTANTI:
- Il_Mio_Ricettario.html = app
- manifest.webmanifest = configurazione installazione
- sw.js = funzionamento offline/cache
- icon-192.png e icon-512.png = icone

SALVATAGGIO:
Le ricette sono salvate localmente nel browser del telefono. Usa Gestione →
Esporta per creare periodicamente un backup JSON.

NOTA:
Non è un APK nativo. È una PWA: sul telefono si comporta come un'app,
senza Android Studio. Per trasformarla in APK vero serve successivamente un
servizio di wrapping/compilazione.
