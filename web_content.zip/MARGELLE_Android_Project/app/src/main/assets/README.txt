MARGELLE Store — quick start

1) Open index.html in a browser to preview the store.
2) Demo products and prices are sample placeholders. Edit the `products` array near the bottom of index.html to add the real catalog.
3) WhatsApp checkout is connected to 01120939380 (Egypt international format: 201120939380).
4) This is a front-end starter store. It does not process card payments, calculate shipping, or include a secure admin dashboard/database. Orders are sent to WhatsApp for manual confirmation.
5) To publish, upload index.html to a static hosting service (for example Netlify or GitHub Pages). Replace sample product cards with real photos and verified prices before publishing.
