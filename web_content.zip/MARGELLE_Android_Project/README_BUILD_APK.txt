MARGELLE Android project
========================

This is an Android Studio project wrapping your supplied MARGELLE website in an Android WebView app.

Build an APK:
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. Open the extracted MARGELLE_Android_Project folder in Android Studio.
4. Allow Gradle sync/downloads.
5. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio will show the APK location (usually app/build/outputs/apk/debug/app-debug.apk).

The website files are in app/src/main/assets/.
The launcher icon is generated from margelle-logo.png.
WhatsApp links open externally.

Important:
- This is an Android Studio project, not a compiled APK yet.
- Building requires Android Studio/Android SDK and an internet connection for Gradle downloads.
- The supplied website is bundled locally. WhatsApp ordering needs internet.
