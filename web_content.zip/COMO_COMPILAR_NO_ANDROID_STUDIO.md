# 📱 Como Compilar o Viana Connect VPN no Android Studio (Com Ligação VPN Real)

Este projeto contém o serviço nativo **`android.net.VpnService`** para Android, que cria a interface de rede virtual real (**`tun0`**) no seu aparelho e ativa o ícone de chave (**🔑**) na barra de status.

---

## 🛠️ Passo a Passo para Gerar o APK no Android Studio:

### 1. Baixar e Descompactar
- Baixe o arquivo **`VianaConnectVPN-AndroidStudio-Project.zip`**.
- Descompacte (extraia) a pasta no seu computador.

### 2. Abrir no Android Studio
1. Abra o **Android Studio** (qualquer versão recente: Flamingo, Giraffe, Hedgehog, Iguana, etc.).
2. Na tela inicial, clique em **Open** (ou no menu superior: **File > Open**).
3. Selecione a pasta descompactada (**`VianaConnectVPN`**).
4. O Android Studio vai reconhecer o projeto Gradle e baixar as dependências automaticamente (leva de 1 a 2 minutos no primeiro acesso).

### 3. Gerar o APK
1. No menu superior do Android Studio, clique em:
   👉 **Build** > **Build Bundle(s) / APK(s)** > **Build APK(s)**
2. Aguarde alguns segundos até o Gradle compilar.
3. No canto inferior direito aparecerá uma notificação:
   `APK(s) generated successfully for 1 module`.
4. Clique na opção azul **`locate`**.
5. O seu arquivo APK estará pronto dentro da pasta:
   📂 `app/build/outputs/apk/debug/app-debug.apk`

---

## 📲 Como Usar no Telefone:
1. Envie o arquivo `app-debug.apk` para o seu celular Android (via WhatsApp, Cabo USB ou Google Drive).
2. Toque no arquivo para **Instalar**.
3. Abra o **Viana Connect VPN** e toque no botão grande de **LIGAR / CONECTAR**.
4. O Android exibirá a janela oficial do sistema:
   > *"Viana Connect VPN quer configurar uma conexão VPN que permite monitorar o tráfego de rede."*
5. Clique em **OK / Aceitar**.
6. A chavezinha (**🔑**) aparecerá no topo do seu celular e a conexão estará **100% ativa e roteando os dados do telefone**!
