《公式靶场》手机编译说明

这个工程已经包含游戏 HTML：
app/src/main/assets/index.html

建议使用 AndroidIDE 在 Android 手机上打开本工程并编译 APK。
MT 管理器用于后续查看、替换 HTML、重签名，不负责从 Gradle 工程直接编译 APK。

手机步骤：
1. 解压本工程。
2. 用 AndroidIDE 导入工程根目录（包含 settings.gradle 的目录）。
3. 等待 Gradle 同步完成；如果提示下载 Android SDK/Gradle/依赖，允许下载。
4. 执行 Build/构建 APK。
5. APK 一般会出现在 app/build/outputs/apk/debug/ 或 release/。
6. 安装 APK。

游戏已配置：
- 横屏
- 全屏沉浸式
- JavaScript
- DOM Storage
- WebView 硬件加速
- Internet 权限
- WebGL 所需的硬件加速环境

注意：游戏当前 HTML 使用 Three.js 和 PeerJS 的 HTTPS CDN，因此首次运行需要联网。

如果只想更新游戏：替换 app/src/main/assets/index.html，然后重新 Build APK。
