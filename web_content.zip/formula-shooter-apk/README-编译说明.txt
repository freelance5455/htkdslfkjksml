《公式靶场》APK 工程 v1.1
本版本新增：手机触屏按键布局设置。主菜单点击“📱 手机按键设置”，可拖动开火/滑铲/瞄准/跳/换弹/换枪/视角按钮，调整大小，恢复默认并保存。布局保存到手机本地。
Android Studio 打开工程后：Build -> Generate App Bundles or APKs -> Generate APKs。
联机房间仍需要互联网；单机游戏主体内置在 APK。
