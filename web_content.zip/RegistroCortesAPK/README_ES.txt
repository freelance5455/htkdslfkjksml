REGISTRO DE CORTES - PROYECTO ANDROID

Este proyecto empaqueta la página final con los 22 cortes actuales.
Incluye SAW 9, SAW 7, BENTUBE y VNOSE, guardado automático con IndexedDB y respaldo/restauración.

IMPORTANTE:
- El APK no se puede compilar en este entorno porque aquí no está instalado el SDK/Gradle de Android.
- El proyecto está preparado para abrirse en Android Studio y generar el APK.

PASOS EN ANDROID STUDIO:
1. Abre Android Studio.
2. File > Open y selecciona la carpeta RegistroCortes.
3. Espera a que Gradle termine de sincronizar.
4. Build > Build App Bundle(s) / APK(s) > Build APK(s).
5. El APK quedará en app/build/outputs/apk/debug/app-debug.apk.

RESPALDOS:
- En la app pulsa RESPALDO. El JSON se guarda en Descargas.
- En otro teléfono instala el APK, abre Restaurar y selecciona ese JSON.
