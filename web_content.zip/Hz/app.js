
"use strict";

/* =========================================
   PINK SALE BOOK
   Sales / Orders / Inventory / Debts
========================================= */

const DB_KEY = "pink_sale_book_v2";
const THEME_KEY = "pink_sale_theme_v2";
const CALC_HISTORY_KEY = "pink_sale_calc_history_v1";

const $ = id => document.getElementById(id);
const number = value => Number(value || 0);
const money = value => number(value).toLocaleString("en-US") + " ကျပ်";
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
const today = () => new Date().toISOString().slice(0, 10);

const METHOD_LABELS = {
  Cash: "လက်ငင်း",
  KPay: "KPay",
  WavePay: "WavePay"
};

function emptyDB() {
  return { products: [], sales: [], orders: [] };
}

function loadDB() {
  try {
    const data = JSON.parse(localStorage.getItem(DB_KEY));
    if (!data || typeof data !== "object") return emptyDB();

    const result = {
      products: Array.isArray(data.products) ? data.products : [],
      sales: Array.isArray(data.sales) ? data.sales : [],
      orders: Array.isArray(data.orders) ? data.orders : []
    };

    result.sales.forEach(sale => {
      sale.paid = number(sale.paid);
      sale.due = Math.max(0, number(sale.total) - sale.paid);

      if (!Array.isArray(sale.payments)) {
        sale.payments = sale.paid > 0 ? [{
          id: uid(),
          amount: sale.paid,
          method: sale.method || "Cash",
          date: sale.date || new Date().toISOString(),
          type: "initial"
        }] : [];
      }

      sale.payments.forEach(payment => {
        payment.amount = number(payment.amount);
        if (!METHOD_LABELS[payment.method]) payment.method = "Cash";
      });
    });

    return result;
  } catch (error) {
    console.error("Database load error:", error);
    return emptyDB();
  }
}

let db = loadDB();
let activePaymentMethod = "Cash";
let modalCallback = null;

function saveDB() {
  try {
    localStorage.setItem(DB_KEY, JSON.stringify(db));
    return true;
  } catch (error) {
    toast("စာရင်းသိမ်းဆည်းမရပါ။ ဖုန်း Storage စစ်ဆေးပါ");
    console.error(error);
    return false;
  }
}

function toast(message) {
  const el = $("toast");
  el.textContent = message;
  el.classList.add("show");
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => el.classList.remove("show"), 2600);
}

function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, char => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[char]);
}

function getProduct(id) {
  return db.products.find(product => product.id === id);
}

function getSale(id) {
  return db.sales.find(sale => sale.id === id);
}

function getMethodLabel(method) {
  return METHOD_LABELS[method] || "လက်ငင်း";
}

function reservedQty(productId, excludeOrderId = null) {
  return db.orders
    .filter(order =>
      order.productId === productId &&
      order.status === "pending" &&
      order.id !== excludeOrderId
    )
    .reduce((sum, order) => sum + number(order.qty), 0);
}

function availableStock(product) {
  return Math.max(0, number(product.stock) - reservedQty(product.id));
}

function totalPaid(sale) {
  return number(sale.paid);
}

function saleDue(sale) {
  return Math.max(0, number(sale.total) - totalPaid(sale));
}

function recognizedValues(sale) {
  const total = number(sale.total);
  const paid = Math.min(total, totalPaid(sale));
  const ratio = total > 0 ? paid / total : 0;
  const fullCost = number(sale.costTotal);
  const fullProfit = number(sale.profit);

  return {
    revenue: paid,
    capital: fullCost * ratio,
    profit: fullProfit * ratio,
    due: Math.max(0, total - paid)
  };
}

function allPayments() {
  const result = [];

  db.sales.forEach(sale => {
    (sale.payments || []).forEach(payment => {
      if (number(payment.amount) <= 0) return;

      result.push({
        ...payment,
        saleId: sale.id,
        productName: sale.productName,
        customer: sale.customer || "",
        phone: sale.phone || "",
        saleTotal: number(sale.total)
      });
    });
  });

  return result.sort((a, b) => new Date(b.date) - new Date(a.date));
}

/* =========================================
   MODAL SYSTEM
========================================= */

function openModal(title, body, actions, callback = null) {
  $("modalTitle").textContent = title;
  $("modalBody").innerHTML = body;
  $("modalActions").innerHTML = actions;
  $("appModal").classList.remove("hidden");
  modalCallback = callback;
}

function closeModal() {
  $("appModal").classList.add("hidden");
  $("modalBody").innerHTML = "";
  $("modalActions").innerHTML = "";
  modalCallback = null;
}

$("modalClose").addEventListener("click", closeModal);

$("appModal").addEventListener("click", event => {
  if (event.target === $("appModal")) closeModal();
});

function confirmAction(title, message, action) {
  openModal(
    title,
    `<p class="modal-text">${escapeHTML(message)}</p>`,
    `<button class="secondary-btn" id="modalCancel">မလုပ်တော့ပါ</button>
     <button class="primary-btn" id="modalConfirm">အတည်ပြုမည်</button>`
  );

  $("modalCancel").onclick = closeModal;
  $("modalConfirm").onclick = () => {
    closeModal();
    action();
  };
}

/* =========================================
   NAVIGATION
========================================= */

function showPage(pageId) {
  document.querySelectorAll(".page").forEach(page =>
    page.classList.remove("active")
  );

  document.querySelectorAll(".nav-btn").forEach(button =>
    button.classList.remove("active")
  );

  const targetPage = $(pageId);
  if (!targetPage) return;

  targetPage.classList.add("active");

  document.querySelector(
    `.nav-btn[data-page="${pageId}"]`
  )?.classList.add("active");

  window.scrollTo({ top: 0, behavior: "smooth" });
  renderAll();
}

document.querySelectorAll(".nav-btn").forEach(button => {
  button.addEventListener("click", () => showPage(button.dataset.page));
});

$("openDebtPage").addEventListener("click", () => showPage("debtsPage"));
$("backToDashboard").addEventListener("click", () => showPage("dashboardPage"));

/* =========================================
   THEME
========================================= */

function applyTheme(theme) {
  document.documentElement.dataset.theme = theme;

  $("themeBtn").innerHTML = theme === "dark"
    ? '<i class="fa-solid fa-sun"></i>'
    : '<i class="fa-solid fa-moon"></i>';

  localStorage.setItem(THEME_KEY, theme);
}

applyTheme(localStorage.getItem(THEME_KEY) || "light");

$("themeBtn").addEventListener("click", () => {
  applyTheme(
    document.documentElement.dataset.theme === "dark" ? "light" : "dark"
  );
});

/* =========================================
   CALCULATOR
========================================= */

let calcExpression = "";
let calcJustEvaluated = false;
let calcHistory = loadCalcHistory();

function loadCalcHistory() {
  try {
    const saved = JSON.parse(localStorage.getItem(CALC_HISTORY_KEY));
    return Array.isArray(saved) ? saved : [];
  } catch {
    return [];
  }
}

function saveCalcHistory() {
  try {
    localStorage.setItem(CALC_HISTORY_KEY, JSON.stringify(calcHistory));
  } catch (error) {
    console.error("Calculator history save error:", error);
  }
}

function formatCalcNumber(value) {
  if (!Number.isFinite(value)) return "Error";
  if (Object.is(value, -0)) value = 0;

  return Number(value.toPrecision(12)).toLocaleString("en-US", {
    maximumFractionDigits: 10
  });
}

function prettyExpression(expression) {
  return expression
    .replace(/\*/g, "×")
    .replace(/\//g, "÷")
    .replace(/-/g, "−");
}

function updateCalculatorDisplay() {
  $("calcExpression").textContent =
    calcExpression ? prettyExpression(calcExpression) : "0";

  if (!calcExpression) {
    $("calcResult").textContent = "0";
    return;
  }

  try {
    const result = calculateExpression(calcExpression);
    $("calcResult").textContent = formatCalcNumber(result);
  } catch {
    $("calcResult").textContent = "";
  }
}

function openCalculator() {
  $("calculatorModal").classList.remove("hidden");
  updateCalculatorDisplay();
  renderCalcHistory();
}

function closeCalculator() {
  $("calculatorModal").classList.add("hidden");
}

$("calculatorBtn").addEventListener("click", openCalculator);
$("calculatorClose").addEventListener("click", closeCalculator);

$("calculatorModal").addEventListener("click", event => {
  if (event.target === $("calculatorModal")) closeCalculator();
});

function tokenizeExpression(expression) {
  const tokens = [];
  let i = 0;

  while (i < expression.length) {
    const char = expression[i];

    if (/\s/.test(char)) {
      i++;
      continue;
    }

    if (/[0-9.]/.test(char)) {
      let text = "";
      let dots = 0;

      while (i < expression.length && /[0-9.]/.test(expression[i])) {
        if (expression[i] === ".") dots++;
        text += expression[i++];
      }

      if (dots > 1 || text === ".") throw new Error("Invalid number");
      tokens.push(Number(text));
      continue;
    }

    if ("+-*/()%".includes(char)) {
      tokens.push(char);
      i++;
      continue;
    }

    throw new Error("Invalid character");
  }

  return tokens;
}

function calculateExpression(expression) {
  const tokens = tokenizeExpression(expression);
  let position = 0;

  function parsePrimary() {
    const token = tokens[position];

    if (token === "+") {
      position++;
      return parsePrimary();
    }

    if (token === "-") {
      position++;
      return -parsePrimary();
    }

    if (token === "(") {
      position++;
      const value = parseAddSub();

      if (tokens[position] !== ")") throw new Error("Missing bracket");
      position++;
      return parsePostfix(value);
    }

    if (typeof token === "number") {
      position++;
      return parsePostfix(token);
    }

    throw new Error("Expected number");
  }

  function parsePostfix(value) {
    while (tokens[position] === "%") {
      position++;
      value = value / 100;
    }
    return value;
  }

  function parseMulDiv() {
    let value = parsePrimary();

    while (tokens[position] === "*" || tokens[position] === "/") {
      const operator = tokens[position++];
      const right = parsePrimary();

      if (operator === "*") value *= right;
      else {
        if (right === 0) throw new Error("Divide by zero");
        value /= right;
      }
    }

    return value;
  }

  function parseAddSub() {
    let value = parseMulDiv();

    while (tokens[position] === "+" || tokens[position] === "-") {
      const operator = tokens[position++];
      const right = parseMulDiv();

      if (operator === "+") value += right;
      else value -= right;
    }

    return value;
  }

  if (!tokens.length) throw new Error("Empty expression");

  const result = parseAddSub();

  if (position !== tokens.length || !Number.isFinite(result)) {
    throw new Error("Invalid expression");
  }

  return result;
}

function currentNumberStart(expression) {
  let i = expression.length - 1;

  while (i >= 0 && /[0-9.]/.test(expression[i])) i--;

  return i + 1;
}

function addCalcNumber(value) {
  if (calcJustEvaluated) {
    calcExpression = "";
    calcJustEvaluated = false;
  }

  const last = calcExpression.slice(-1);

  if (last === ")") {
    calcExpression += "*" + value;
  } else {
    const start = currentNumberStart(calcExpression);
    const current = calcExpression.slice(start);

    if (current === "0") {
      calcExpression = calcExpression.slice(0, start) + value;
    } else {
      calcExpression += value;
    }
  }

  updateCalculatorDisplay();
}

function addCalcDecimal() {
  if (calcJustEvaluated) {
    calcExpression = "";
    calcJustEvaluated = false;
  }

  const last = calcExpression.slice(-1);

  if (last === ")") {
    calcExpression += "*0.";
  } else {
    const start = currentNumberStart(calcExpression);
    const current = calcExpression.slice(start);

    if (!current.includes(".")) {
      calcExpression += current ? "." : "0.";
    }
  }

  updateCalculatorDisplay();
}

function addCalcOperator(operator) {
  if (!calcExpression) {
    if (operator === "-") {
      calcExpression = "-";
      updateCalculatorDisplay();
    }
    return;
  }

  calcJustEvaluated = false;

  const last = calcExpression.slice(-1);

  if ("+-*/".includes(last)) {
    if (operator === "-" && last !== "-") {
      calcExpression += operator;
    } else {
      calcExpression = calcExpression.slice(0, -1) + operator;
    }
  } else if (last === "(") {
    if (operator === "-") calcExpression += operator;
  } else {
    calcExpression += operator;
  }

  updateCalculatorDisplay();
}

function addCalcParenthesis() {
  if (calcJustEvaluated) {
    calcExpression = "";
    calcJustEvaluated = false;
  }

  const openCount = (calcExpression.match(/\(/g) || []).length;
  const closeCount = (calcExpression.match(/\)/g) || []).length;
  const last = calcExpression.slice(-1);

  if (!calcExpression || "/*-+".includes(last) || last === "(") {
    calcExpression += "(";
  } else if (openCount > closeCount && !"+-*/(".includes(last)) {
    calcExpression += ")";
  } else {
    calcExpression += "*(";
  }

  updateCalculatorDisplay();
}

function addCalcPercent() {
  if (!calcExpression) return;

  const last = calcExpression.slice(-1);
  if (/[0-9)]/.test(last)) {
    calcExpression += "%";
    calcJustEvaluated = false;
    updateCalculatorDisplay();
  }
}

function calcBackspace() {
  calcExpression = calcExpression.slice(0, -1);
  calcJustEvaluated = false;
  updateCalculatorDisplay();
}

function clearCalculator() {
  calcExpression = "";
  calcJustEvaluated = false;
  updateCalculatorDisplay();
}

function calculateNow() {
  if (!calcExpression) return;

  try {
    const result = calculateExpression(calcExpression);
    const formatted = formatCalcNumber(result);

    calcHistory.unshift({
      expression: calcExpression,
      result: formatted,
      time: new Date().toISOString()
    });

    calcHistory = calcHistory.slice(0, 30);
    saveCalcHistory();

    $("calcExpression").textContent = prettyExpression(calcExpression) + " =";
    $("calcResult").textContent = formatted;

    calcExpression = String(Number(result.toPrecision(12)));
    calcJustEvaluated = true;

    renderCalcHistory();
  } catch (error) {
    toast(error.message === "Divide by zero"
      ? "သုညနဲ့ စားလို့မရပါ"
      : "တွက်ချက်မှု မှားယွင်းနေပါတယ်");
  }
}

function renderCalcHistory() {
  $("calcHistoryList").innerHTML = calcHistory.length
    ? calcHistory.map((item, index) => `
      <div class="calc-history-item">
        <button type="button" data-history-index="${index}">
          <span class="calc-history-expression">${escapeHTML(prettyExpression(item.expression))}</span>
          <span class="calc-history-answer">= ${escapeHTML(item.result)}</span>
        </button>
      </div>
    `).join("")
    : '<div class="calc-history-empty">မှတ်တမ်းမရှိသေးပါ</div>';
}

$("calcHistoryList").addEventListener("click", event => {
  const button = event.target.closest("[data-history-index]");
  if (!button) return;

  const item = calcHistory[Number(button.dataset.historyIndex)];
  if (!item) return;

  calcExpression = String(item.result).replace(/,/g, "");
  calcJustEvaluated = true;
  updateCalculatorDisplay();
});

$("clearCalcHistory").addEventListener("click", () => {
  calcHistory = [];
  saveCalcHistory();
  renderCalcHistory();
});

$("calculatorModal").addEventListener("click", event => {
  const button = event.target.closest("[data-calc]");
  if (!button) return;

  const type = button.dataset.calc;

  if (type === "number") addCalcNumber(button.dataset.value);
  if (type === "decimal") addCalcDecimal();
  if (type === "operator") addCalcOperator(button.dataset.value);
  if (type === "parenthesis") addCalcParenthesis();
  if (type === "percent") addCalcPercent();
  if (type === "backspace") calcBackspace();
  if (type === "clear") clearCalculator();
  if (type === "equals") calculateNow();
});

document.addEventListener("keydown", event => {
  if ($("calculatorModal").classList.contains("hidden")) return;

  if (/^[0-9]$/.test(event.key)) {
    addCalcNumber(event.key);
  } else if (event.key === ".") {
    addCalcDecimal();
  } else if (["+", "-", "*", "/"].includes(event.key)) {
    addCalcOperator(event.key);
  } else if (event.key === "%") {
    addCalcPercent();
  } else if (event.key === "Enter" || event.key === "=") {
    event.preventDefault();
    calculateNow();
  } else if (event.key === "Backspace") {
    calcBackspace();
  } else if (event.key === "Escape") {
    closeCalculator();
  } else if (event.key === "(" || event.key === ")") {
    addCalcParenthesis();
  }
});

/* =========================================
   PRODUCT OPTIONS
========================================= */

function refreshProductOptions() {
  $("productOptions").innerHTML = db.products.map(product =>
    `<option value="${escapeHTML(product.name)}"></option>`
  ).join("");
}

function refreshOrderProducts() {
  $("orderProduct").innerHTML =
    '<option value="">ပစ္စည်းရွေးပါ</option>' +
    db.products.map(product =>
      `<option value="${escapeHTML(product.id)}">
        ${escapeHTML(product.name)} — ရောင်းနိုင် ${availableStock(product)} ခု
      </option>`
    ).join("");
}

function findProductByName(name) {
  return db.products.find(product =>
    String(product.name).trim().toLowerCase() ===
    String(name).trim().toLowerCase()
  );
}

/* =========================================
   SALE PRODUCT AUTOCOMPLETE
========================================= */

$("saleProductSearch").addEventListener("input", () => {
  const product = findProductByName($("saleProductSearch").value);
  $("saleProductId").value = product ? product.id : "";

  if (!product) {
    $("selectedProductInfo").textContent = "စာရင်းထဲရှိ ပစ္စည်းအမည်ကို ရွေးချယ်ပါ";
    updateSaleTotal();
    return;
  }

  $("salePrice").value = number(product.price);

  $("selectedProductInfo").innerHTML = `
    <strong>${escapeHTML(product.name)}</strong><br>
    ဝယ်ဈေး ${money(product.cost)} · ရောင်းဈေး ${money(product.price)}<br>
    လက်ကျန် ${number(product.stock)} ခု ·
    အော်ဒါချန်ထား ${reservedQty(product.id)} ခု<br>
    <strong>ရောင်းနိုင် ${availableStock(product)} ခု</strong>
  `;

  updateSaleTotal();
});

["saleQty", "salePrice", "salePaid"].forEach(id => {
  $(id).addEventListener("input", updateSaleTotal);
});

function updateSaleTotal() {
  const total = number($("salePrice").value) * number($("saleQty").value);
  const paid = number($("salePaid").value);

  $("saleGrandTotal").textContent = money(total);
  $("saleDue").textContent = money(Math.max(0, total - paid));
}

/* =========================================
   PAYMENT RECORD
========================================= */

function addPayment(sale, amount, method, type = "payment") {
  amount = number(amount);
  if (amount <= 0) return;

  if (!Array.isArray(sale.payments)) sale.payments = [];

  sale.payments.push({
    id: uid(),
    amount,
    method,
    date: new Date().toISOString(),
    type
  });

  sale.paid = sale.payments.reduce(
    (sum, payment) => sum + number(payment.amount), 0
  );

  sale.due = Math.max(0, number(sale.total) - sale.paid);
}

/* =========================================
   DIRECT SALE
========================================= */

$("saleForm").addEventListener("submit", event => {
  event.preventDefault();

  const product = getProduct($("saleProductId").value);

  if (!product ||
      findProductByName($("saleProductSearch").value)?.id !== product.id) {
    return toast("ကုန်ပစ္စည်းစာရင်းထဲမှ ပစ္စည်းတစ်ခု ရွေးပါ");
  }

  const qty = number($("saleQty").value);
  const price = number($("salePrice").value);
  const paid = number($("salePaid").value);
  const total = qty * price;

  const method =
    document.querySelector('input[name="saleMethod"]:checked')?.value || "Cash";

  if (!Number.isInteger(qty) || qty < 1 ||
      !Number.isFinite(price) || price < 0 ||
      !Number.isFinite(paid) || paid < 0) {
    return toast("အရေအတွက်နဲ့ ငွေပမာဏ မှန်ကန်စွာထည့်ပါ");
  }

  if (qty > availableStock(product)) {
    return toast(`ရောင်းနိုင်သော လက်ကျန် ${availableStock(product)} ခုသာရှိပါတယ်`);
  }

  if (paid > total) return toast("လက်ခံရငွေက ရောင်းရငွေထက် မများရပါ");

  const sale = {
    id: uid(),
    productId: product.id,
    productName: product.name,
    qty,
    costPerUnit: number(product.cost),
    price,
    total,
    costTotal: number(product.cost) * qty,
    profit: (price - number(product.cost)) * qty,
    method,
    paid: 0,
    due: total,
    payments: [],
    customer: $("saleCustomer").value.trim(),
    phone: $("salePhone").value.trim(),
    date: new Date().toISOString(),
    source: "direct"
  };

  addPayment(sale, paid, method, "initial");
  db.sales.unshift(sale);
  product.stock = number(product.stock) - qty;

  if (!saveDB()) return;

  $("saleForm").reset();
  $("saleQty").value = 1;
  $("saleProductId").value = "";
  $("selectedProductInfo").textContent = "ကုန်ပစ္စည်းရွေးချယ်ပါ";
  updateSaleTotal();

  renderAll();
  toast("အရောင်းစာရင်းသွင်းပြီးပါပြီ");
});

/* =========================================
   ORDERS
========================================= */

$("orderProduct").addEventListener("change", () => {
  const product = getProduct($("orderProduct").value);
  if (product) $("orderPrice").value = number(product.price);
});

$("orderForm").addEventListener("submit", event => {
  event.preventDefault();

  const product = getProduct($("orderProduct").value);
  const qty = number($("orderQty").value);
  const price = number($("orderPrice").value);

  if (!product) return toast("ပစ္စည်းရွေးချယ်ပါ");

  if (!Number.isInteger(qty) || qty < 1 || price < 0) {
    return toast("အချက်အလက်စစ်ဆေးပါ");
  }

  if (qty > availableStock(product)) {
    return toast(`အော်ဒါတင်နိုင်သော ပစ္စည်း ${availableStock(product)} ခုသာရှိပါတယ်`);
  }

  db.orders.unshift({
    id: uid(),
    productId: product.id,
    productName: product.name,
    qty,
    price,
    total: qty * price,
    customer: $("orderCustomer").value.trim(),
    phone: $("orderPhone").value.trim(),
    note: $("orderNote").value.trim(),
    date: new Date().toISOString(),
    status: "pending"
  });

  if (!saveDB()) return;

  $("orderForm").reset();
  $("orderQty").value = 1;

  renderAll();
  toast("အော်ဒါတင်ပြီးပါပြီ။ ပစ္စည်းလက်ကျန် မလျှော့သေးပါ");
});

/* =========================================
   DISPATCH ORDER
========================================= */

function dispatchOrder(orderId) {
  const order = db.orders.find(item =>
    item.id === orderId && item.status === "pending"
  );

  if (!order) return;

  const product = getProduct(order.productId);

  if (!product || number(product.stock) < number(order.qty)) {
    return toast("လက်ကျန်ပစ္စည်း မလုံလောက်ပါ");
  }

  openModal(
    "ပစ္စည်းပို့ပြီး အရောင်းသွင်းမည်",
    `
      <p class="modal-text">
        ပစ္စည်း - <strong>${escapeHTML(order.productName)}</strong><br>
        အရေအတွက် - ${number(order.qty)} ခု<br>
        စုစုပေါင်း - <strong>${money(order.total)}</strong>
      </p>
      <label class="modal-label">ငွေလက်ခံနည်းလမ်း ရွေးပါ</label>
      <div class="modal-methods">
        <label class="modal-method"><input type="radio" name="dispatchMethod" value="Cash" checked><span>လက်ငင်း</span></label>
        <label class="modal-method"><input type="radio" name="dispatchMethod" value="KPay"><span>KPay</span></label>
        <label class="modal-method"><input type="radio" name="dispatchMethod" value="WavePay"><span>WavePay</span></label>
      </div>
      <label class="modal-label">လက်ခံရရှိငွေ</label>
      <input id="dispatchPaid" type="number" min="0" step="any" value="${number(order.total)}">
      <p class="modal-text">ကျန်ငွေကို အကြွေးစာရင်းထဲ အလိုအလျောက် ထည့်ပေးပါမယ်။</p>
    `,
    `
      <button class="secondary-btn" id="dispatchCancel">မလုပ်တော့ပါ</button>
      <button class="primary-btn" id="dispatchConfirm">ပစ္စည်းပို့ပြီး</button>
    `
  );

  $("dispatchCancel").onclick = closeModal;

  $("dispatchConfirm").onclick = () => {
    const method =
      document.querySelector('input[name="dispatchMethod"]:checked')?.value || "Cash";
    const paid = Number($("dispatchPaid").value);

    if (!Number.isFinite(paid) || paid < 0 || paid > number(order.total)) {
      return toast("လက်ခံရငွေ မှန်ကန်စွာထည့်ပါ");
    }

    const sale = {
      id: uid(),
      productId: order.productId,
      productName: order.productName,
      qty: number(order.qty),
      costPerUnit: number(product.cost),
      price: number(order.price),
      total: number(order.total),
      costTotal: number(product.cost) * number(order.qty),
      profit: (number(order.price) - number(product.cost)) * number(order.qty),
      method,
      paid: 0,
      due: number(order.total),
      payments: [],
      customer: order.customer || "",
      phone: order.phone || "",
      date: new Date().toISOString(),
      source: "order",
      orderId: order.id
    };

    addPayment(sale, paid, method, "initial");
    db.sales.unshift(sale);
    product.stock = number(product.stock) - number(order.qty);
    order.status = "dispatched";
    order.dispatchedAt = new Date().toISOString();

    if (!saveDB()) return;

    closeModal();
    renderAll();
    toast("ပစ္စည်းပို့ပြီး အရောင်းစာရင်းထဲ ထည့်ပြီးပါပြီ");
  };
}

function cancelOrder(orderId) {
  const order = db.orders.find(item =>
    item.id === orderId && item.status === "pending"
  );

  if (!order) return;

  confirmAction(
    "အော်ဒါပယ်ဖျက်မည်",
    `${order.productName} အော်ဒါကို ပယ်ဖျက်မှာ သေချာပါသလား။`,
    () => {
      order.status = "cancelled";
      saveDB();
      renderAll();
      toast("အော်ဒါပယ်ဖျက်ပြီးပါပြီ");
    }
  );
}

/* =========================================
   DEBT PAYMENT
========================================= */

function payDebt(saleId) {
  const sale = getSale(saleId);
  if (!sale || saleDue(sale) <= 0) return;

  const remaining = saleDue(sale);

  openModal(
    "အကြွေးပေးချေမည်",
    `
      <p class="modal-text">
        ပစ္စည်း - <strong>${escapeHTML(sale.productName)}</strong><br>
        ဝယ်သူ - ${escapeHTML(sale.customer || "မဖော်ပြ")}<br>
        ဖုန်း - ${escapeHTML(sale.phone || "မဖော်ပြ")}<br>
        အကြွေးကျန် - <strong class="debt-amount">${money(remaining)}</strong>
      </p>
      <label class="modal-label">ပေးချေမှုနည်းလမ်း ရွေးပါ</label>
      <div class="modal-methods">
        <label class="modal-method"><input type="radio" name="debtMethod" value="Cash" checked><span>လက်ငင်း</span></label>
        <label class="modal-method"><input type="radio" name="debtMethod" value="KPay"><span>KPay</span></label>
        <label class="modal-method"><input type="radio" name="debtMethod" value="WavePay"><span>WavePay</span></label>
      </div>
      <label class="modal-label">ပေးချေမည့်ငွေ</label>
      <input id="debtPayAmount" type="number" min="0" step="any" value="${remaining}">
      <p class="modal-text">အကြွေးအပြည့်ပေးချေပါက အကြွေးစာရင်းမှ ပျောက်သွားပါမယ်။</p>
    `,
    `
      <button class="secondary-btn" id="debtCancel">မလုပ်တော့ပါ</button>
      <button class="primary-btn" id="debtConfirm">ပေးချေမှု သိမ်းမည်</button>
    `
  );

  $("debtCancel").onclick = closeModal;

  $("debtConfirm").onclick = () => {
    const method =
      document.querySelector('input[name="debtMethod"]:checked')?.value || "Cash";
    const amount = Number($("debtPayAmount").value);

    if (!Number.isFinite(amount) || amount <= 0 || amount > saleDue(sale)) {
      return toast("ပေးချေမည့်ငွေကို မှန်ကန်စွာထည့်ပါ");
    }

    addPayment(sale, amount, method, "debt");

    if (!saveDB()) return;

    closeModal();
    renderAll();

    if (saleDue(sale) <= 0) toast("အကြွေးအပြည့်ပေးချေပြီးပါပြီ");
    else toast("တစ်စိတ်တစ်ပိုင်း ပေးချေမှုသိမ်းပြီးပါပြီ");
  };
}

/* =========================================
   PRODUCT MANAGEMENT
========================================= */

$("productForm").addEventListener("submit", event => {
  event.preventDefault();

  const id = $("productEditId").value;
  const name = $("productName").value.trim();
  const cost = number($("productCost").value);
  const price = number($("productPrice").value);
  const stock = number($("productStock").value);

  if (!name || cost < 0 || price < 0 ||
      !Number.isInteger(stock) || stock < 0) {
    return toast("ကုန်ပစ္စည်းအချက်အလက် မှန်ကန်စွာထည့်ပါ");
  }

  const duplicate = db.products.find(product =>
    product.name.toLowerCase() === name.toLowerCase() &&
    product.id !== id
  );

  if (duplicate) return toast("ဒီပစ္စည်းအမည် ရှိပြီးသားပါ");

  if (id) {
    const product = getProduct(id);
    if (!product) return;

    if (stock < reservedQty(id)) {
      return toast(`အော်ဒါအတွက် ${reservedQty(id)} ခု ချန်ထားရပါတယ်`);
    }

    Object.assign(product, { name, cost, price, stock });
    toast("ပစ္စည်းပြင်ဆင်ပြီးပါပြီ");
  } else {
    db.products.push({
      id: uid(),
      name,
      cost,
      price,
      stock,
      createdAt: new Date().toISOString()
    });
    toast("ပစ္စည်းအသစ် ထည့်ပြီးပါပြီ");
  }

  resetProductForm();
  saveDB();
  renderAll();
});

function editProduct(id) {
  const product = getProduct(id);
  if (!product) return;

  $("productEditId").value = id;
  $("productName").value = product.name;
  $("productCost").value = product.cost;
  $("productPrice").value = product.price;
  $("productStock").value = product.stock;

  $("productSubmitBtn").innerHTML = '<i class="fa-solid fa-pen"></i> ပြင်ဆင်မည်>';
  $("cancelProductEdit").classList.remove("hidden");
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function resetProductForm() {
  $("productForm").reset();
  $("productEditId").value = "";
  $("productSubmitBtn").innerHTML = '<i class="fa-solid fa-plus"></i> ပစ္စည်းထည့်မည်>';
  $("cancelProductEdit").classList.add("hidden");
}

$("cancelProductEdit").addEventListener("click", resetProductForm);

function deleteProduct(id) {
  const product = getProduct(id);
  if (!product) return;

  if (reservedQty(id) > 0) {
    return toast("စောင့်ဆိုင်းအော်ဒါရှိသော ပစ္စည်းကို ဖျက်၍မရပါ");
  }

  confirmAction(
    "ပစ္စည်းဖျက်မည်",
    `${product.name} ကို ဖျက်မှာ သေချာပါသလား။`,
    () => {
      db.products = db.products.filter(item => item.id !== id);
      saveDB();
      renderAll();
      toast("ပစ္စည်းဖျက်ပြီးပါပြီ");
    }
  );
}

/* =========================================
   DELETE SALE
========================================= */

function deleteSale(id) {
  const sale = getSale(id);
  if (!sale) return;

  confirmAction(
    "အရောင်းမှတ်တမ်းဖျက်မည်",
    "ဒီအရောင်းမှတ်တမ်းကို ဖျက်မှာ သေချာပါသလား။ ပစ္စည်းလက်ကျန်ကို ပြန်ပေါင်းပေးပါမယ်။ ငွေလက်ခံမှတ်တမ်းလည်း ဖယ်ရှားသွားပါမယ်။",
    () => {
      const product = getProduct(sale.productId);

      if (product) {
        product.stock = number(product.stock) + number(sale.qty);
      }

      if (sale.source === "order" && sale.orderId) {
        const order = db.orders.find(item => item.id === sale.orderId);

        if (order) {
          order.status = "pending";
          delete order.dispatchedAt;
        }
      }

      db.sales = db.sales.filter(item => item.id !== id);
      saveDB();
      renderAll();
      toast("အရောင်းမှတ်တမ်း ဖျက်ပြီးပါပြီ");
    }
  );
}

/* =========================================
   DATE FORMAT
========================================= */

function dateText(value) {
  if (!value) return "";

  return new Date(value).toLocaleString("en-GB", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit"
  });
}

/* =========================================
   DEBT CARD HTML
========================================= */

function debtCardHTML(sale) {
  const due = saleDue(sale);

  return `
    <div class="record-card debt-card">
      <div class="record-top">
        <div>
          <div class="record-title">${escapeHTML(sale.productName)}</div>
          <div class="record-sub">${dateText(sale.date)}</div>
        </div>
        <div class="record-amount debt-amount">${money(due)}</div>
      </div>
      <div class="record-details">
        <span>ဝယ်သူ ${escapeHTML(sale.customer || "မဖော်ပြ")}</span>
        <span>ဖုန်း ${escapeHTML(sale.phone || "မဖော်ပြ")}</span>
        <span>ရောင်းရငွေ ${money(sale.total)}</span>
        <span>လက်ခံပြီး ${money(sale.paid)}</span>
      </div>
      <div class="record-actions">
        <button class="small-btn success" onclick="payDebt('${sale.id}')">
          <i class="fa-solid fa-circle-check"></i> ပေးချေပြီးပြီ
        </button>
      </div>
    </div>
  `;
}

/* =========================================
   DASHBOARD
========================================= */

function renderDashboard() {
  let revenue = 0;
  let capital = 0;
  let profit = 0;
  let debt = 0;

  db.sales.forEach(sale => {
    const values = recognizedValues(sale);
    revenue += values.revenue;
    capital += values.capital;
    profit += values.profit;
    debt += values.due;
  });

  const stock = db.products.reduce(
    (sum, product) => sum + number(product.stock), 0
  );

  const stockValue = db.products.reduce(
    (sum, product) => sum + number(product.stock) * number(product.cost), 0
  );

  const pending = db.orders.filter(order => order.status === "pending").length;

  $("totalCapital").textContent = money(capital);
  $("totalRevenue").textContent = money(revenue);
  $("totalProfit").textContent = money(profit);
  $("totalStock").textContent = stock.toLocaleString() + " ခု";
  $("stockValue").textContent = "တန်ဖိုး " + money(stockValue);
  $("pendingOrders").textContent = pending.toLocaleString() + " ခု";
  $("totalDebt").textContent = money(debt);
}

/* =========================================
   SEPARATE DEBT PAGE
========================================= */

function renderDebts() {
  const debts = db.sales.filter(sale => saleDue(sale) > 0);
  const totalDebt = debts.reduce((sum, sale) => sum + saleDue(sale), 0);

  $("debtPageTotal").textContent = money(totalDebt);
  $("debtPageCount").textContent = debts.length.toLocaleString() + " ခု ကျန်ရှိ";

  $("debtsList").innerHTML = debts.length
    ? debts.map(debtCardHTML).join("")
    : '<div class="empty"><i class="fa-solid fa-circle-check"></i><br>အကြွေးကျန် မရှိပါ</div>';
}

/* =========================================
   SALES LIST
========================================= */

function renderSales() {
  const query = $("salesSearch").value.trim().toLowerCase();

  const sales = db.sales.filter(sale =>
    String(sale.productName).toLowerCase().includes(query) ||
    String(sale.customer || "").toLowerCase().includes(query) ||
    String(sale.phone || "").includes(query)
  );

  $("salesList").innerHTML = sales.length
    ? sales.map(sale => {
        const values = recognizedValues(sale);

        return `
          <div class="record-card">
            <div class="record-top">
              <div>
                <div class="record-title">${escapeHTML(sale.productName)}</div>
                <div class="record-sub">${dateText(sale.date)}</div>
              </div>
              <div class="record-amount">${money(values.revenue)}</div>
            </div>
            <div class="record-details">
              <span>အရေအတွက် ${number(sale.qty)} ခု</span>
              <span>ရောင်းရငွေ ${money(sale.total)}</span>
              <span>လက်ခံပြီး ${money(sale.paid)}</span>
              <span>အကြွေး ${money(saleDue(sale))}</span>
              <span>ရရှိပြီးအမြတ် ${money(values.profit)}</span>
              <span>အရင်း ${money(values.capital)}</span>
              ${sale.customer ? `<span>ဝယ်သူ ${escapeHTML(sale.customer)}</span>` : ""}
            </div>
            ${saleDue(sale) > 0 ? `
              <div class="record-actions">
                <button class="small-btn success" onclick="payDebt('${sale.id}')">
                  <i class="fa-solid fa-money-bill-wave"></i> အကြွေးပေးချေမည်
                </button>
                <button class="small-btn danger" onclick="deleteSale('${sale.id}')">
                  <i class="fa-solid fa-trash"></i> ဖျက်မည်
                </button>
              </div>
            ` : `
              <div class="record-actions">
                <span class="paid-status">အကြွေးရှင်းပြီး</span>
                <button class="small-btn danger" onclick="deleteSale('${sale.id}')">
                  <i class="fa-solid fa-trash"></i> ဖျက်မည်
                </button>
              </div>
            `}
          </div>
        `;
      }).join("")
    : '<div class="empty">အရောင်းစာရင်း မရှိသေးပါ</div>';
}

/* =========================================
   ORDER LIST
========================================= */

function renderOrders() {
  const orders = db.orders.filter(order => order.status === "pending");

  $("ordersList").innerHTML = orders.length
    ? orders.map(order => `
      <div class="record-card">
        <div class="record-top">
          <div>
            <div class="record-title">${escapeHTML(order.productName)}</div>
            <div class="record-sub">အော်ဒါတင်ချိန် ${dateText(order.date)}</div>
          </div>
          <div class="record-amount">${money(order.total)}</div>
        </div>
        <div class="record-details">
          <span>အရေအတွက် ${number(order.qty)} ခု</span>
          <span>ဝယ်သူ ${escapeHTML(order.customer || "မဖော်ပြ")}</span>
          <span>ဖုန်း ${escapeHTML(order.phone || "မဖော်ပြ")}</span>
          <span>မှတ်ချက် ${escapeHTML(order.note || "-")}</span>
        </div>
        <div class="record-actions">
          <button class="small-btn success" onclick="dispatchOrder('${order.id}')">
            <i class="fa-solid fa-truck-fast"></i> ပစ္စည်းပို့ပြီး
          </button>
          <button class="small-btn danger" onclick="cancelOrder('${order.id}')">
            <i class="fa-solid fa-xmark"></i> ပယ်ဖျက်
          </button>
        </div>
      </div>
    `).join("")
    : '<div class="empty">စောင့်ဆိုင်းနေသော အော်ဒါမရှိပါ</div>';
}

/* =========================================
   PRODUCT LIST
========================================= */

function renderProducts() {
  const query = $("productSearch").value.trim().toLowerCase();

  const products = db.products.filter(product =>
    product.name.toLowerCase().includes(query)
  );

  $("productsList").innerHTML = products.length
    ? products.map(product => `
      <div class="record-card">
        <div class="record-top">
          <div>
            <div class="record-title">${escapeHTML(product.name)}</div>
            <div class="record-sub">
              ဝယ်ဈေး ${money(product.cost)} · ရောင်းဈေး ${money(product.price)}
            </div>
          </div>
          <div class="record-amount">${number(product.stock)} ခု</div>
        </div>
        <div class="record-details">
          <span>အော်ဒါချန်ထား ${reservedQty(product.id)} ခု</span>
          <span>ရောင်းနိုင် ${availableStock(product)} ခု</span>
          <span>လက်ကျန်အရင်းတန်ဖိုး ${money(number(product.stock) * number(product.cost))}</span>
        </div>
        <div class="record-actions">
          <button class="small-btn" onclick="editProduct('${product.id}')">
            <i class="fa-solid fa-pen"></i> ပြင်မည်
          </button>
          <button class="small-btn danger" onclick="deleteProduct('${product.id}')">
            <i class="fa-solid fa-trash"></i> ဖျက်မည်
          </button>
        </div>
      </div>
    `).join("")
    : '<div class="empty">ကုန်ပစ္စည်း မရှိသေးပါ</div>';
}

/* =========================================
   PAYMENT HISTORY
========================================= */

function renderPayments() {
  const records = allPayments().filter(
    payment => payment.method === activePaymentMethod
  );

  const total = records.reduce(
    (sum, payment) => sum + number(payment.amount), 0
  );

  $("paymentTitle").textContent =
    getMethodLabel(activePaymentMethod) + " စုစုပေါင်းလက်ခံငွေ";

  $("paymentTotal").textContent = money(total);

  $("paymentsList").innerHTML = records.length
    ? records.map(payment => `
      <div class="record-card">
        <div class="record-top">
          <div>
            <div class="record-title">${escapeHTML(payment.productName)}</div>
            <div class="record-sub">${dateText(payment.date)}</div>
          </div>
          <div class="record-amount">${money(payment.amount)}</div>
        </div>
        <div class="record-details">
          <span>ဝယ်သူ ${escapeHTML(payment.customer || "မဖော်ပြ")}</span>
          <span>ငွေလက်ခံနည်း ${getMethodLabel(payment.method)}</span>
          <span>အမျိုးအစား ${payment.type === "debt" ? "အကြွေးပေးချေမှု" : "အရောင်းငွေ"}</span>
          <span>ရောင်းရငွေ ${money(payment.saleTotal)}</span>
        </div>
      </div>
    `).join("")
    : '<div class="empty">ဒီငွေပေးချေမှုအမျိုးအစားအတွက် စာရင်းမရှိသေးပါ</div>';
}

/* =========================================
   RENDER ALL
========================================= */

function renderAll() {
  refreshProductOptions();
  refreshOrderProducts();
  renderDashboard();
  renderDebts();
  renderSales();
  renderOrders();
  renderProducts();
  renderPayments();
}

/* =========================================
   PAYMENT TABS
========================================= */

document.querySelectorAll(".payment-tab").forEach(button => {
  button.addEventListener("click", () => {
    activePaymentMethod = button.dataset.method;

    document.querySelectorAll(".payment-tab").forEach(tab =>
      tab.classList.remove("active")
    );

    button.classList.add("active");
    renderPayments();
  });
});

/* =========================================
   SEARCH
========================================= */

$("salesSearch").addEventListener("input", renderSales);
$("productSearch").addEventListener("input", renderProducts);

/* =========================================
   INITIAL START
========================================= */

$("saleQty").value = 1;
$("orderQty").value = 1;
updateSaleTotal();
renderAll();
