"use strict";

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

const STORAGE_KEYS = {
  language: "skillbridge_language",
  savedJobs: "skillbridge_saved_jobs",
  customJobs: "skillbridge_custom_jobs",
  applications: "skillbridge_applications",
  cvData: "skillbridge_cv_data",
  interviewDrafts: "skillbridge_interview_drafts"
};

const STATUS_LABELS = {
  applied: { bn: "আবেদন করা হয়েছে", en: "Applied" },
  interview: { bn: "ইন্টারভিউ", en: "Interview" },
  offer: { bn: "অফার পেয়েছি", en: "Offer received" },
  rejected: { bn: "প্রত্যাখ্যাত", en: "Rejected" }
};

const VAULT_CATEGORIES = {
  certificate: { bn: "সার্টিফিকেট / মার্কশিট", en: "Certificates" },
  cv: { bn: "CV ও কভার লেটার", en: "CV & Letters" },
  identity: { bn: "ছবি ও আইডি ডকুমেন্ট", en: "Photos & IDs" },
  other: { bn: "অন্যান্য ফাইল", en: "Other files" }
};

function readStorage(key, fallback) {
  try {
    const value = localStorage.getItem(key);
    return value ? JSON.parse(value) : fallback;
  } catch (error) {
    console.warn("Storage read error:", error);
    return fallback;
  }
}

function writeStorage(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch (error) {
    showToast(
      language === "bn"
        ? "ব্রাউজার স্টোরেজ পূর্ণ। ব্যাকআপ ডাউনলোড করে পুরোনো ডেটা পরিষ্কার করো।"
        : "Browser storage full. Export a backup and clear old items."
    );
    return false;
  }
}

let toastTimer = null;
function showToast(message) {
  const toast = $("#toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2800);
}

let language = localStorage.getItem(STORAGE_KEYS.language) || "bn";
let savedJobs = readStorage(STORAGE_KEYS.savedJobs, []);
let customJobs = readStorage(STORAGE_KEYS.customJobs, []);
let applications = readStorage(STORAGE_KEYS.applications, []);
let interviewDrafts = readStorage(STORAGE_KEYS.interviewDrafts, {});
let cvData = readStorage(STORAGE_KEYS.cvData, {
  name: "",
  role: "",
  email: "",
  phone: "",
  address: "",
  portfolio: "",
  template: "modern",
  photo: "",
  summary: "",
  education: "",
  skills: "",
  experience: "",
  projects: ""
});

const defaultJobs = [
  {
    id: "demo-1",
    titleBn: "কাস্টমার সার্ভিস প্রতিনিধি",
    titleEn: "Customer Service Representative",
    company: "Demo Company",
    locationBn: "ঢাকা",
    locationEn: "Dhaka",
    type: "Full-time",
    typeBn: "ফুল-টাইম",
    detailBn: "গ্রাহকের প্রশ্নের উত্তর দেওয়া, অর্ডার/সার্ভিস আপডেট জানানো ও সেবা সহায়তা।",
    detailEn: "Respond to customer inquiries, provide service updates and support."
  },
  {
    id: "demo-2",
    titleBn: "জুনিয়র গ্রাফিক ডিজাইনার",
    titleEn: "Junior Graphic Designer",
    company: "Sample Studio",
    locationBn: "রিমোট",
    locationEn: "Remote",
    type: "Remote",
    typeBn: "রিমোট",
    detailBn: "সোশ্যাল মিডিয়া পোস্ট, ব্যানার ও ডিজিটাল কনটেন্ট ডিজাইন তৈরি করা।",
    detailEn: "Design social media graphics, banners and digital content."
  },
  {
    id: "demo-3",
    titleBn: "ডাটা এন্ট্রি সহকারী",
    titleEn: "Data Entry Assistant",
    company: "Example Services",
    locationBn: "বাংলাদেশ",
    locationEn: "Bangladesh",
    type: "Part-time",
    typeBn: "পার্ট-টাইম",
    detailBn: "স্প্রেডশিট বা সিস্টেমে নির্ভুলভাবে তথ্য সাজানো, যাচাই এবং এন্ট্রি করা।",
    detailEn: "Organize, verify and enter structured data accurately."
  },
  {
    id: "demo-4",
    titleBn: "ফিল্ড অপারেশনস ও ডেলিভারি কোঅর্ডিনেটর",
    titleEn: "Field Operations & Delivery Coordinator",
    company: "Metro Logistics Sample",
    locationBn: "ঢাকা",
    locationEn: "Dhaka",
    type: "Full-time",
    typeBn: "ফুল-টাইম",
    detailBn: "দৈনিক কার্যক্রম সমন্বয়, সময়মতো রিপোর্টিং ও টিম সাপোর্ট।",
    detailEn: "Coordinate daily operations, timely reporting and team support."
  }
];

const questions = [
  {
    bn: "নিজের সম্পর্কে বলুন।",
    en: "Tell me about yourself.",
    tipBn: "বর্তমান শিক্ষা বা কাজ, মূল ৩টি দক্ষতা এবং এই পদে কেন আগ্রহী তা ৪৫-৬০ সেকেন্ডে গুছিয়ে বলো।",
    tipEn: "Cover your education/work background, top 3 skills, and why you want this role in 45–60 seconds.",
    sampleBn: "আমার নাম [নাম]। আমি [শিক্ষা/বিষয়] নিয়ে পড়াশোনা করছি এবং [কাজের ধরন]-এ বাস্তব অভিজ্ঞতা অর্জন করেছি। সময়মতো কাজ শেষ করা, পরিষ্কার যোগাযোগ এবং চাপের মধ্যেও শান্ত থেকে সমাধান বের করা আমার মূল শক্তি।",
    sampleEn: "My name is [Name]. I am pursuing [Education] and have hands-on experience in [Field]. My core strengths are clear communication, punctuality, and staying calm under pressure."
  },
  {
    bn: "আপনার সবচেয়ে শক্তিশালী দক্ষতা কোনটি?",
    en: "What is your strongest skill?",
    tipBn: "একটি দক্ষতা বেছে নিয়ে বাস্তব কাজের একটি উদাহরণ দাও।",
    tipEn: "Pick one core skill and back it up with a real example.",
    sampleBn: "আমার সবচেয়ে শক্তিশালী দক্ষতা হলো দ্রুত সমস্যা সমাধান ও গ্রাহকদের সাথে ধৈর্য ধরে যোগাযোগ করা। পূর্বের কাজে প্রতিদিন অনেক ক্লায়েন্ট বা কাস্টমারের সমস্যা সময়মতো সমাধান করতে পেরেছি।",
    sampleEn: "My strongest skill is fast problem-solving paired with patient customer communication. In my previous role, I consistently resolved daily client issues on schedule."
  },
  {
    bn: "আপনি এই চাকরিটি কেন করতে চান?",
    en: "Why do you want this job?",
    tipBn: "প্রতিষ্ঠানের কাজের ধরন এবং নিজের দক্ষতা ও শেখার লক্ষ্যের মিল দেখাও।",
    tipEn: "Connect what the role needs with your skills and growth goals.",
    sampleBn: "এই পদটির দায়িত্বগুলো আমার বর্তমান দক্ষতার সাথে সরাসরি মিলে যায়। পাশাপাশি আপনাদের প্রতিষ্ঠানে কাজ করে আমি আরও নতুন কিছু শিখতে এবং দীর্ঘমেয়াদে অবদান রাখতে চাই।",
    sampleEn: "The responsibilities of this role match my strengths directly, and I want to grow my skills while contributing long-term value to your team."
  },
  {
    bn: "কঠিন বা চাপের পরিস্থিতি কীভাবে সামলান?",
    en: "How do you handle a difficult situation?",
    tipBn: "পরিস্থিতি কী ছিল, কী পদক্ষেপ নিয়েছ এবং কী ফলাফল এসেছে—এই ৩ ধাপে বলো।",
    tipEn: "Use Situation -> Action -> Result structure.",
    sampleBn: "চাপের সময়ে আমি প্রথমে মূল সমস্যাটা আলাদা করি, অগ্রাধিকার ঠিক করি এবং ধাপে ধাপে সমাধান করি। এতে ভুল কম হয় এবং নির্ধারিত সময়ের মধ্যেই কাজ শেষ করা যায়।",
    sampleEn: "Under pressure, I break the issue down, prioritize urgent tasks first, and execute calmly step by step so deadlines are met accurately."
  },
  {
    bn: "আগামী কয়েক বছরে নিজেকে কোথায় দেখতে চান?",
    en: "Where do you see yourself in the next few years?",
    tipBn: "বাস্তবসম্মত উন্নতি এবং দায়িত্ব নেওয়ার আগ্রহ দেখাও।",
    tipEn: "Show realistic growth and willingness to take responsibility.",
    sampleBn: "আগামী ২-৩ বছরে আমি এই কাজের প্রতিটি দিক দক্ষতার সাথে আয়ত্ত করে প্রতিষ্ঠানের আরও বড় দায়িত্ব নেওয়ার যোগ্য হয়ে উঠতে চাই।",
    sampleEn: "Over the next 2–3 years, I want to master every aspect of this role and grow into a dependable team contributor with greater responsibility."
  },
  {
    bn: "আপনার দুর্বলতা কী এবং তা কীভাবে কাটিয়ে উঠছেন?",
    en: "What is a weakness you are working to improve?",
    tipBn: "এমন একটি বিষয় বলো যা কাজের ক্ষতি করে না, এবং তা উন্নত করতে কী করছ তা জানাও।",
    tipEn: "Share a genuine growth area and the habit you use to improve it.",
    sampleBn: "আগে আমি একসাথে অনেক কাজ নিখুঁত করতে গিয়ে একটু বেশি সময় নিতাম। এখন প্রতিদিনের কাজের তালিকা ও সময় ভাগ করে নেওয়ায় গতি ও মান দুটোই বেড়েছে।",
    sampleEn: "I used to spend extra time perfecting small details. Now I use daily checklists and time blocks to balance speed with accuracy."
  },
  {
    bn: "আমরা আপনাকেই কেন নিয়োগ দেব?",
    en: "Why should we hire you?",
    tipBn: "দায়িত্ববোধ, শেখার গতি এবং কাজের প্রতি নিষ্ঠা তুলে ধরো।",
    tipEn: "Highlight reliability, fast learning, and commitment.",
    sampleBn: "আমি দ্রুত নতুন কাজ শিখতে পারি, দায়িত্ব নিয়ে কাজ শেষ করি এবং দলের সবার সাথে মিলেমিশে কাজ করতে অভ্যস্ত। আপনারা আমাকে সুযোগ দিলে প্রথম দিন থেকেই আন্তরিকভাবে কাজ করব।",
    sampleEn: "I learn quickly, take ownership of tasks, and collaborate smoothly with teams. If given the chance, I will bring strong work ethic from day one."
  },
  {
    bn: "আপনার কি আমাদের কাছে কোনো প্রশ্ন আছে?",
    en: "Do you have any questions for us?",
    tipBn: "কাজের প্রত্যাশা বা শেখার সুযোগ নিয়ে একটি স্মার্ট প্রশ্ন করো।",
    tipEn: "Ask a thoughtful question about expectations or growth.",
    sampleBn: "এই পদে যোগ দেওয়ার পর প্রথম এক মাসে আমার কাছ থেকে আপনারা কোন বিষয়টি সবচেয়ে বেশি আশা করবেন?",
    sampleEn: "What would success look like for someone in this role during the first 30 days?"
  }
];

/* =========================================================
   HIGH-SPEED INDEXEDDB FILE VAULT (LARGE STORAGE CAPACITY)
   ========================================================= */
const DB_NAME = "SkillBridgeProVaultDB";
const DB_VERSION = 1;
const STORE_NAME = "files";

function openVaultDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: "id" });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function saveFilesToVault(fileList, category) {
  const files = [...fileList];
  if (!files.length) return;

  const progressWrap = $("#uploadProgressWrap");
  const progressBar = $("#uploadProgressBar");
  const progressPercent = $("#uploadProgressPercent");
  const progressLabel = $("#uploadProgressLabel");

  progressWrap.hidden = false;
  progressBar.style.width = "0%";

  const db = await openVaultDB();

  for (let i = 0; i < files.length; i++) {
    const file = files[i];
    const pct = Math.round(((i + 0.5) / files.length) * 100);
    progressBar.style.width = `${pct}%`;
    progressPercent.textContent = `${pct}%`;
    progressLabel.textContent = language === "bn"
      ? `দ্রুত সংরক্ষণ হচ্ছে (${i + 1}/${files.length}): ${file.name}`
      : `Saving (${i + 1}/${files.length}): ${file.name}`;

    const record = {
      id: makeId(),
      name: file.name,
      type: file.type || "application/octet-stream",
      size: file.size,
      category,
      createdAt: Date.now(),
      blob: file
    };

    await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, "readwrite");
      tx.objectStore(STORE_NAME).put(record);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  progressBar.style.width = "100%";
  progressPercent.textContent = "100%";
  setTimeout(() => {
    progressWrap.hidden = true;
  }, 450);

  await renderVault();
  renderHomeStats();
  showToast(
    language === "bn"
      ? `${files.length}টি ফাইল দ্রুত ভল্টে সেভ হয়েছে!`
      : `${files.length} file(s) saved rapidly to Vault!`
  );
}

async function getAllVaultFiles() {
  const db = await openVaultDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readonly");
    const req = tx.objectStore(STORE_NAME).getAll();
    req.onsuccess = () => resolve((req.result || []).sort((a, b) => b.createdAt - a.createdAt));
    req.onerror = () => reject(req.error);
  });
}

async function deleteVaultFile(id) {
  const db = await openVaultDB();
  await new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite");
    tx.objectStore(STORE_NAME).delete(id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
  await renderVault();
  renderHomeStats();
  showToast(language === "bn" ? "ফাইল মুছে ফেলা হয়েছে" : "File deleted");
}

async function clearVaultDB() {
  const db = await openVaultDB();
  await new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite");
    tx.objectStore(STORE_NAME).clear();
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

function formatBytes(bytes) {
  if (!bytes) return "0 B";
  const units = ["B", "KB", "MB", "GB"];
  const idx = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
  return `${(bytes / Math.pow(1024, idx)).toFixed(idx === 0 ? 0 : 1)} ${units[idx]}`;
}

async function renderVault() {
  const allFiles = await getAllVaultFiles();
  const totalBytes = allFiles.reduce((sum, f) => sum + (f.size || 0), 0);

  let quotaText = language === "bn" ? "বড় লোকাল স্টোরেজ" : "Large Local Vault";
  if (navigator.storage && navigator.storage.estimate) {
    try {
      const est = await navigator.storage.estimate();
      if (est.quota) {
        quotaText = formatBytes(est.quota);
      }
    } catch (_) {}
  }

  $("#storageStats").innerHTML = `
    <div class="stat-box"><strong>${allFiles.length}</strong><span>${language === "bn" ? "মোট ফাইল" : "Total Files"}</span></div>
    <div class="stat-box"><strong>${formatBytes(totalBytes)}</strong><span>${language === "bn" ? "ব্যবহৃত জায়গা" : "Used Space"}</span></div>
    <div class="stat-box"><strong>${quotaText}</strong><span>${language === "bn" ? "মোট স্টোরেজ ক্ষমতা" : "Storage Capacity"}</span></div>
    <div class="stat-box"><strong>⚡ Instant</strong><span>${language === "bn" ? "অফলাইন অ্যাক্সেস" : "Offline Access"}</span></div>
  `;

  const query = ($("#vaultSearchInput")?.value || "").trim().toLowerCase();
  const catFilter = $("#vaultCategoryFilter")?.value || "all";

  const filtered = allFiles.filter((file) => {
    const matchesQuery = !query || file.name.toLowerCase().includes(query);
    const matchesCat = catFilter === "all" || file.category === catFilter;
    return matchesQuery && matchesCat;
  });

  const container = $("#vaultFileList");
  container.innerHTML = "";

  if (!filtered.length) {
    container.innerHTML = `<p class="empty-state">${
      language === "bn"
        ? "ভল্টে কোনো ফাইল পাওয়া যায়নি। ওপরে ক্লিক করে বা ফাইল টেনে এনে আপলোড করো।"
        : "No files in vault yet. Drop or select files above to store them."
    }</p>`;
    return;
  }

  filtered.forEach((file) => {
    const catLabel = VAULT_CATEGORIES[file.category]
      ? (language === "bn" ? VAULT_CATEGORIES[file.category].bn : VAULT_CATEGORIES[file.category].en)
      : file.category;

    const card = document.createElement("article");
    card.className = "job-card";
    card.innerHTML = `
      <h3>${escapeHTML(file.name)} <span class="tag-pill">${escapeHTML(catLabel)}</span></h3>
      <p class="job-meta">${formatBytes(file.size)} · ${escapeHTML(file.type)} · ${new Date(file.createdAt).toLocaleDateString()}</p>
      <div class="job-actions">
        <button type="button" data-preview-file="${file.id}">${language === "bn" ? "দেখো (Preview)" : "Preview"}</button>
        <button type="button" data-download-file="${file.id}">${language === "bn" ? "ডাউনলোড" : "Download"}</button>
        <button type="button" data-delete-file="${file.id}">${language === "bn" ? "মুছে ফেলো" : "Delete"}</button>
      </div>
    `;
    container.appendChild(card);
  });
}

/* =========================================================
   CORE UI, CV STUDIO, COVER LETTER, JOBS, TRACKER & INTERVIEW
   ========================================================= */
let questionIndex = 0;
let timerSeconds = 60;
let timerInterval = null;

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, (char) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  })[char]);
}

function applyLocalizedAttributes() {
  document.documentElement.lang = language === "bn" ? "bn" : "en";

  $$("[data-bn][data-en]").forEach((element) => {
    element.textContent = language === "bn" ? element.dataset.bn : element.dataset.en;
  });

  $$("[data-placeholder-bn][data-placeholder-en]").forEach((element) => {
    element.placeholder = language === "bn"
      ? element.dataset.placeholderBn
      : element.dataset.placeholderEn;
  });

  $("#languageBtn").textContent = language === "bn" ? "English" : "বাংলা";
}

function setLanguage(nextLanguage) {
  language = nextLanguage;
  localStorage.setItem(STORAGE_KEYS.language, language);
  applyLocalizedAttributes();
  renderHomeStats();
  renderCvPreview();
  renderJobs();
  renderApplications();
  renderQuestion();
  renderVault();
}

function showPage(pageId) {
  $$(".page").forEach((page) => page.classList.toggle("active", page.id === pageId));
  $$(".tab").forEach((tab) => {
    const isActive = tab.dataset.tab === pageId;
    tab.classList.toggle("active", isActive);
    tab.setAttribute("aria-selected", String(isActive));
  });
  window.scrollTo({ top: 0, behavior: "smooth" });
}

async function renderHomeStats() {
  const container = $("#homeQuickStats");
  if (!container) return;
  let vaultCount = 0;
  try {
    const files = await getAllVaultFiles();
    vaultCount = files.length;
  } catch (_) {}

  const cvStatus = cvData.name.trim()
    ? (language === "bn" ? "প্রস্তুত" : "Ready")
    : (language === "bn" ? "খালি" : "Empty");

  container.innerHTML = `
    <div class="stat-box"><strong>${cvStatus}</strong><span>${language === "bn" ? "CV প্রোফাইল" : "CV Profile"}</span></div>
    <div class="stat-box"><strong>${vaultCount}</strong><span>${language === "bn" ? "ভল্ট ফাইল" : "Vault Files"}</span></div>
    <div class="stat-box"><strong>${applications.length}</strong><span>${language === "bn" ? "মোট আবেদন" : "Applications"}</span></div>
    <div class="stat-box"><strong>${savedJobs.length}</strong><span>${language === "bn" ? "সেভ করা জব" : "Saved Jobs"}</span></div>
  `;
}

function syncCvInputs() {
  $("#cvName").value = cvData.name || "";
  $("#cvRole").value = cvData.role || "";
  $("#cvEmail").value = cvData.email || "";
  $("#cvPhone").value = cvData.phone || "";
  $("#cvAddress").value = cvData.address || "";
  $("#cvPortfolio").value = cvData.portfolio || "";
  $("#cvTemplate").value = cvData.template || "modern";
  $("#cvSummary").value = cvData.summary || "";
  $("#cvEducation").value = cvData.education || "";
  $("#cvSkills").value = cvData.skills || "";
  $("#cvExperience").value = cvData.experience || "";
  $("#cvProjects").value = cvData.projects || "";
}

function renderCvPreview() {
  const preview = $("#cvPreview");
  preview.className = `cv-preview theme-${cvData.template || "modern"}`;

  const name = cvData.name.trim() || (language === "bn" ? "তোমার পূর্ণ নাম" : "Your Full Name");
  const role = cvData.role.trim();
  const contactItems = [cvData.email, cvData.phone, cvData.address, cvData.portfolio]
    .map((v) => (v || "").trim())
    .filter(Boolean);

  const skillsList = (cvData.skills || "")
    .split(/,|
/)
    .map((s) => s.trim())
    .filter(Boolean);

  const skillsHTML = skillsList.length
    ? `<div class="skill-chips">${skillsList.map((s) => `<span class="skill-chip">${escapeHTML(s)}</span>`).join("")}</div>`
    : `<p>—</p>`;

  preview.innerHTML = `
    <div class="cv-header">
      <div>
        <h2>${escapeHTML(name)}</h2>
        ${role ? `<p class="cv-role">${escapeHTML(role)}</p>` : ""}
        ${contactItems.length ? `<p class="cv-meta">${escapeHTML(contactItems.join("  •  "))}</p>` : ""}
      </div>
      ${cvData.photo ? `<img class="cv-avatar" src="${cvData.photo}" alt="Profile Photo">` : ""}
    </div>

    ${cvData.summary.trim() ? `
      <h3>${language === "bn" ? "ক্যারিয়ার সারসংক্ষেপ" : "Career Summary"}</h3>
      <p>${escapeHTML(cvData.summary.trim()).replace(/
/g, "<br>")}</p>
    ` : ""}

    <h3>${language === "bn" ? "শিক্ষাগত যোগ্যতা" : "Education"}</h3>
    <p>${escapeHTML(cvData.education.trim() || "—").replace(/
/g, "<br>")}</p>

    <h3>${language === "bn" ? "দক্ষতা" : "Core Skills"}</h3>
    ${skillsHTML}

    <h3>${language === "bn" ? "অভিজ্ঞতা" : "Experience"}</h3>
    <p>${escapeHTML(cvData.experience.trim() || "—").replace(/
/g, "<br>")}</p>

    ${cvData.projects.trim() ? `
      <h3>${language === "bn" ? "প্রজেক্ট / প্রশিক্ষণ / ভাষা" : "Projects / Training / Languages"}</h3>
      <p>${escapeHTML(cvData.projects.trim()).replace(/
/g, "<br>")}</p>
    ` : ""}
  `;
}

function saveCvFromForm() {
  cvData = {
    ...cvData,
    name: $("#cvName").value,
    role: $("#cvRole").value,
    email: $("#cvEmail").value,
    phone: $("#cvPhone").value,
    address: $("#cvAddress").value,
    portfolio: $("#cvPortfolio").value,
    template: $("#cvTemplate").value,
    summary: $("#cvSummary").value,
    education: $("#cvEducation").value,
    skills: $("#cvSkills").value,
    experience: $("#cvExperience").value,
    projects: $("#cvProjects").value
  };
  writeStorage(STORAGE_KEYS.cvData, cvData);
  renderCvPreview();
  renderHomeStats();
}

function compressImageToDataURL(file, maxSize = 260) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const scale = Math.min(1, maxSize / Math.max(img.width, img.height));
        const canvas = document.createElement("canvas");
        canvas.width = Math.round(img.width * scale);
        canvas.height = Math.round(img.height * scale);
        const ctx = canvas.getContext("2d");
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL("image/jpeg", 0.84));
      };
      img.onerror = reject;
      img.src = reader.result;
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function generateCoverLetter() {
  const company = $("#clCompany").value.trim() || (language === "bn" ? "[প্রতিষ্ঠানের নাম]" : "[Company Name]");
  const position = $("#clPosition").value.trim() || (language === "bn" ? "[পদের নাম]" : "[Job Position]");
  const manager = $("#clManager").value.trim() || (language === "bn" ? "নিয়োগকর্তা / HR ম্যানেজার" : "Hiring Manager");
  const highlight = $("#clHighlight").value.trim();

  const applicantName = cvData.name.trim() || (language === "bn" ? "[আপনার নাম]" : "[Your Name]");
  const applicantPhone = cvData.phone.trim() || "+880 1XXX-XXXXXX";
  const applicantEmail = cvData.email.trim() || "name@example.com";
  const skillsText = cvData.skills.trim() || (language === "bn" ? "যোগাযোগ দক্ষতা, সময়ানুবর্তিতা ও সমস্যা সমাধান" : "communication, punctuality, and problem-solving");

  if (language === "bn") {
    $("#coverOutput").value = `বরাবর,
${manager}
${company}

বিষয়: ${position} পদের জন্য আবেদন।

জনাব/জনাবা,

আমি অত্যন্ত আগ্রহের সাথে ${company}-এর "${position}" পদের জন্য আবেদন করছি। আমার শিক্ষাগত যোগ্যতা ও ব্যবহারিক অভিজ্ঞতা আমাকে এই দায়িত্বটি দক্ষতার সাথে পালনে প্রস্তুত করেছে।

আমার মূল দক্ষতার মধ্যে রয়েছে ${skillsText}। ${highlight ? `বিশেষভাবে, ${highlight} বিষয়ে আমার বাস্তব অভিজ্ঞতা রয়েছে। ` : ""}আমি দ্রুত নতুন কাজ শিখতে পারি এবং দলের সাথে সমন্বয় করে নির্ধারিত সময়ের মধ্যে সেরা ফলাফল দিতে প্রতিশ্রুতিবদ্ধ।

আমার সংযুক্ত CV-তে বিস্তারিত তথ্য দেওয়া হয়েছে। একটি সাক্ষাৎকারের সুযোগ পেলে আমি কীভাবে আপনার প্রতিষ্ঠানে অবদান রাখতে পারি তা সরাসরি জানাতে পারব।

বিনীত নিবেদক,
${applicantName}
ফোন: ${applicantPhone}
ইমেইল: ${applicantEmail}`;
  } else {
    $("#coverOutput").value = `Dear ${manager},

I am writing to express my strong interest in the ${position} position at ${company}. With my background and practical skills, I am confident in my ability to contribute effectively to your team from day one.

My core strengths include ${skillsText}. ${highlight ? `In particular, I bring hands-on experience in ${highlight}. ` : ""}I am a fast learner, reliable under deadlines, and committed to delivering high-quality work.

Please find my CV attached for further details. I would welcome the opportunity to discuss how my skills align with the needs of ${company} in an interview.

Sincerely,
${applicantName}
Phone: ${applicantPhone}
Email: ${applicantEmail}`;
  }
}

function getAllJobs() {
  return [...customJobs, ...defaultJobs];
}

function renderJobs() {
  const container = $("#jobList");
  const query = ($("#jobSearchInput")?.value || "").trim().toLowerCase();
  const selectedType = $("#jobTypeFilter")?.value || "all";
  const onlySaved = Boolean($("#onlySavedJobs")?.checked);

  const filtered = getAllJobs().filter((job) => {
    const title = `${job.titleBn} ${job.titleEn}`.toLowerCase();
    const location = `${job.locationBn} ${job.locationEn}`.toLowerCase();
    const company = job.company.toLowerCase();

    const matchesQuery = !query || title.includes(query) || location.includes(query) || company.includes(query);
    const matchesType = selectedType === "all" || job.type === selectedType;
    const matchesSaved = !onlySaved || savedJobs.includes(job.id);

    return matchesQuery && matchesType && matchesSaved;
  });

  container.innerHTML = "";

  if (!filtered.length) {
    container.innerHTML = `<p class="empty-state">${
      language === "bn" ? "কোনো চাকরি মেলেনি। ফিল্টার পরিবর্তন করে দেখো।" : "No matching jobs found."
    }</p>`;
    return;
  }

  filtered.forEach((job) => {
    const isSaved = savedJobs.includes(job.id);
    const card = document.createElement("article");
    card.className = "job-card";

    const title = language === "bn" ? job.titleBn : job.titleEn;
    const location = language === "bn" ? job.locationBn : job.locationEn;
    const typeLabel = language === "bn" ? job.typeBn : job.type;
    const detail = language === "bn" ? job.detailBn : job.detailEn;
    const saveLabel = isSaved
      ? (language === "bn" ? "সেভ করা হয়েছে" : "Saved")
      : (language === "bn" ? "সেভ করো" : "Save job");

    card.innerHTML = `
      <h3>${escapeHTML(title)} ${job.isCustom ? `<span class="tag-pill">${language === "bn" ? "নিজস্ব" : "Custom"}</span>` : ""}</h3>
      <p class="job-meta">${escapeHTML(job.company)} · ${escapeHTML(location)} · ${escapeHTML(typeLabel)}</p>
      <p>${escapeHTML(detail)}</p>
      <div class="job-actions">
        <button type="button" class="${isSaved ? "saved" : ""}" data-save-job="${job.id}">${saveLabel}</button>
        <button type="button" data-track-job="${job.id}">${language === "bn" ? "আবেদনের তালিকায় যোগ" : "Add to tracker"}</button>
        <button type="button" data-cover-job="${job.id}">${language === "bn" ? "কভার লেটার বানাও" : "Write Cover Letter"}</button>
        ${job.isCustom ? `<button type="button" data-delete-custom-job="${job.id}">${language === "bn" ? "মুছুন" : "Delete"}</button>` : ""}
      </div>
    `;
    container.appendChild(card);
  });
}

function renderStats() {
  const statsEl = $("#trackerStats");
  const counts = {
    total: applications.length,
    interview: applications.filter((a) => a.status === "interview").length,
    offer: applications.filter((a) => a.status === "offer").length,
    active: applications.filter((a) => a.status === "applied" || a.status === "interview").length
  };

  statsEl.innerHTML = `
    <div class="stat-box"><strong>${counts.total}</strong><span>${language === "bn" ? "মোট আবেদন" : "Total applications"}</span></div>
    <div class="stat-box"><strong>${counts.active}</strong><span>${language === "bn" ? "চলমান প্রক্রিয়া" : "Active pipeline"}</span></div>
    <div class="stat-box"><strong>${counts.interview}</strong><span>${language === "bn" ? "ইন্টারভিউ" : "Interviews"}</span></div>
    <div class="stat-box"><strong>${counts.offer}</strong><span>${language === "bn" ? "অফার" : "Offers"}</span></div>
  `;
}

function renderApplications() {
  renderStats();
  renderHomeStats();
  const container = $("#applicationList");
  container.innerHTML = "";

  if (!applications.length) {
    container.innerHTML = `<p class="empty-state">${
      language === "bn" ? "এখনো কোনো আবেদন যোগ করা হয়নি।" : "No applications added yet."
    }</p>`;
    return;
  }

  applications.forEach((application) => {
    const card = document.createElement("article");
    card.className = "application-card";

    const optionsHTML = Object.entries(STATUS_LABELS)
      .map(([key, labels]) => {
        const selected = application.status === key ? "selected" : "";
        const text = language === "bn" ? labels.bn : labels.en;
        return `<option value="${key}" ${selected}>${escapeHTML(text)}</option>`;
      })
      .join("");

    card.innerHTML = `
      <h3>${escapeHTML(application.name)}</h3>
      ${application.note ? `<p class="job-meta">📝 ${escapeHTML(application.note)}</p>` : ""}
      <div class="job-actions">
        <select class="status-select" data-status-id="${application.id}" aria-label="${language === "bn" ? "আবেদনের অবস্থা" : "Application status"}">
          ${optionsHTML}
        </select>
        <button type="button" data-delete-application="${application.id}">
          ${language === "bn" ? "মুছে ফেলো" : "Delete"}
        </button>
      </div>
    `;
    container.appendChild(card);
  });
}

function updateWordCount() {
  const text = $("#answerBox").value.trim();
  const words = text ? text.split(/\s+/).length : 0;
  $("#answerWordCount").textContent = language === "bn" ? `${words} শব্দ` : `${words} words`;
}

function renderQuestion() {
  const question = questions[questionIndex];
  $("#questionCount").textContent = language === "bn"
    ? `প্রশ্ন ${questionIndex + 1} / ${questions.length}`
    : `Question ${questionIndex + 1} / ${questions.length}`;

  $("#questionText").textContent = language === "bn" ? question.bn : question.en;
  $("#answerBox").value = interviewDrafts[questionIndex] || "";
  $("#answerTip").hidden = true;
  $("#answerTip").innerHTML = "";
  $("#answerFeedback").hidden = true;
  $("#answerFeedback").innerHTML = "";
  updateWordCount();
}

function resetTimer() {
  clearInterval(timerInterval);
  timerInterval = null;
  timerSeconds = 60;
  $("#timerDisplay").textContent = "01:00";
  $("#toggleTimerBtn").textContent = language === "bn" ? "টাইমার চালু" : "Start Timer";
}

function toggleTimer() {
  if (timerInterval) {
    resetTimer();
    return;
  }
  $("#toggleTimerBtn").textContent = language === "bn" ? "থামান" : "Stop";
  timerInterval = setInterval(() => {
    timerSeconds--;
    const mins = String(Math.floor(Math.max(0, timerSeconds) / 60)).padStart(2, "0");
    const secs = String(Math.max(0, timerSeconds) % 60).padStart(2, "0");
    $("#timerDisplay").textContent = `${mins}:${secs}`;
    if (timerSeconds <= 0) {
      clearInterval(timerInterval);
      timerInterval = null;
      $("#toggleTimerBtn").textContent = language === "bn" ? "আবার চালু" : "Restart";
      showToast(language === "bn" ? "১ মিনিট শেষ! দারুণ প্র্যাকটিস হয়েছে।" : "1 minute finished! Great practice.");
    }
  }, 1000);
}

/* =========================================================
   EVENT LISTENERS
   ========================================================= */
$("#languageBtn").addEventListener("click", () => {
  setLanguage(language === "bn" ? "en" : "bn");
});

$$(".tab").forEach((tab) => {
  tab.addEventListener("click", () => showPage(tab.dataset.tab));
});

$$("[data-go]").forEach((element) => {
  element.addEventListener("click", (event) => {
    event.preventDefault();
    showPage(element.dataset.go);
  });
});

// CV Studio
$("#cvForm").addEventListener("input", saveCvFromForm);
$("#cvTemplate").addEventListener("change", saveCvFromForm);
$("#cvForm").addEventListener("submit", (event) => {
  event.preventDefault();
  saveCvFromForm();
  $("#cvPreview").scrollIntoView({ behavior: "smooth", block: "start" });
  showToast(language === "bn" ? "CV আপডেট হয়েছে" : "CV updated");
});

$("#cvPhotoInput").addEventListener("change", async (event) => {
  const file = event.target.files && event.target.files[0];
  if (!file) return;
  try {
    cvData.photo = await compressImageToDataURL(file);
    writeStorage(STORAGE_KEYS.cvData, cvData);
    renderCvPreview();
    showToast(language === "bn" ? "ছবি যুক্ত হয়েছে" : "Photo added");
  } catch (err) {
    showToast(language === "bn" ? "ছবি প্রসেস করা যায়নি" : "Could not process photo");
  }
});

$("#removePhotoBtn").addEventListener("click", () => {
  cvData.photo = "";
  $("#cvPhotoInput").value = "";
  writeStorage(STORAGE_KEYS.cvData, cvData);
  renderCvPreview();
  showToast(language === "bn" ? "ছবি সরানো হয়েছে" : "Photo removed");
});

$("#fillDemoCvBtn").addEventListener("click", () => {
  cvData = {
    ...cvData,
    name: language === "bn" ? "তানজিম ইসলাম" : "Tanzim Islam",
    role: language === "bn" ? "অপারেশনস ও কাস্টমার সাপোর্ট এক্সিকিউটিভ" : "Operations & Customer Support Executive",
    email: "tanzim.career@example.com",
    phone: "+880 1700-000000",
    address: language === "bn" ? "মিরপুর, ঢাকা" : "Mirpur, Dhaka",
    portfolio: "linkedin.com/in/tanzim-career",
    summary: language === "bn"
      ? "সময়ানুবর্তী, দায়িত্বশীল এবং দ্রুত সমস্যা সমাধানে দক্ষ। গ্রাহক সেবা ও দৈনিক অপারেশনস পরিচালনায় বাস্তব অভিজ্ঞতাসম্পন্ন।"
      : "Punctual, dependable, and skilled in fast problem-solving with hands-on experience in customer support and daily operations.",
    education: language === "bn"
      ? "উচ্চ মাধ্যমিক (HSC) — বাংলাদেশ উন্মুক্ত বিশ্ববিদ্যালয়"
      : "Higher Secondary Certificate (HSC) — Bangladesh Open University",
    skills: "Customer Service, Delivery Operations, MS Office, Data Entry, Time Management, Bengali & English",
    experience: language === "bn"
      ? "ডেলিভারি ও অপারেশনস এক্সিকিউটিভ — Steadfast Courier (বর্তমান)
• নির্ধারিত সময়ে পার্সেল ডেলিভারি, ক্যাশ-অন-ডেলিভারি হিসাব ও গ্রাহক সমন্বয়।"
      : "Delivery & Operations Executive — Steadfast Courier (Present)
• Managed timely parcel operations, COD reconciliation, and customer coordination.",
    projects: language === "bn"
      ? "কম্পিউটার অফিস অ্যাপ্লিকেশন প্রশিক্ষণ • বাংলা ও ইংরেজি যোগাযোগ"
      : "Computer Office Applications Training • Fluent in Bengali & English"
  };
  writeStorage(STORAGE_KEYS.cvData, cvData);
  syncCvInputs();
  renderCvPreview();
  renderHomeStats();
  showToast(language === "bn" ? "নমুনা CV তথ্য বসানো হয়েছে" : "Sample CV filled");
});

$("#resetCvBtn").addEventListener("click", () => {
  cvData = {
    name: "",
    role: "",
    email: "",
    phone: "",
    address: "",
    portfolio: "",
    template: "modern",
    photo: "",
    summary: "",
    education: "",
    skills: "",
    experience: "",
    projects: ""
  };
  $("#cvPhotoInput").value = "";
  writeStorage(STORAGE_KEYS.cvData, cvData);
  syncCvInputs();
  renderCvPreview();
  renderHomeStats();
  showToast(language === "bn" ? "CV ফর্ম খালি করা হয়েছে" : "CV reset");
});

$("#copyCvTextBtn").addEventListener("click", async () => {
  const text = $("#cvPreview").innerText.trim();
  if (!text) return;
  await navigator.clipboard.writeText(text);
  showToast(language === "bn" ? "CV লেখা কপি হয়েছে" : "CV text copied");
});

$("#printCvBtn").addEventListener("click", () => {
  if (!cvData.name.trim()) {
    $("#cvName").focus();
    showToast(language === "bn" ? "আগে নিজের নাম লিখুন" : "Enter your name first");
    return;
  }
  window.print();
});

// Cover Letter
$("#coverForm").addEventListener("submit", (event) => {
  event.preventDefault();
  generateCoverLetter();
  showToast(language === "bn" ? "কভার লেটার তৈরি হয়েছে" : "Cover letter generated");
});

$("#copyCoverBtn").addEventListener("click", async () => {
  const text = $("#coverOutput").value.trim();
  if (!text) return;
  await navigator.clipboard.writeText(text);
  showToast(language === "bn" ? "কভার লেটার কপি হয়েছে" : "Cover letter copied");
});

// High-Speed File Vault
const dropzone = $("#fileDropzone");
const vaultInput = $("#vaultFileInput");

dropzone.addEventListener("click", () => vaultInput.click());
dropzone.addEventListener("keydown", (event) => {
  if (event.key === "Enter" || event.key === " ") {
    event.preventDefault();
    vaultInput.click();
  }
});

dropzone.addEventListener("dragover", (event) => {
  event.preventDefault();
  dropzone.classList.add("dragover");
});

dropzone.addEventListener("dragleave", () => dropzone.classList.remove("dragover"));
dropzone.addEventListener("drop", async (event) => {
  event.preventDefault();
  dropzone.classList.remove("dragover");
  if (event.dataTransfer?.files?.length) {
    await saveFilesToVault(event.dataTransfer.files, $("#vaultUploadCategory").value);
  }
});

vaultInput.addEventListener("change", async (event) => {
  if (event.target.files?.length) {
    await saveFilesToVault(event.target.files, $("#vaultUploadCategory").value);
    vaultInput.value = "";
  }
});

$("#vaultSearchInput").addEventListener("input", renderVault);
$("#vaultCategoryFilter").addEventListener("change", renderVault);

let activePreviewUrl = null;
$("#vaultFileList").addEventListener("click", async (event) => {
  const previewBtn = event.target.closest("[data-preview-file]");
  const downloadBtn = event.target.closest("[data-download-file]");
  const deleteBtn = event.target.closest("[data-delete-file]");

  if (deleteBtn) {
    await deleteVaultFile(deleteBtn.dataset.deleteFile);
    return;
  }

  const targetId = previewBtn?.dataset.previewFile || downloadBtn?.dataset.downloadFile;
  if (!targetId) return;

  const files = await getAllVaultFiles();
  const record = files.find((f) => f.id === targetId);
  if (!record) return;

  const url = URL.createObjectURL(record.blob);

  if (downloadBtn) {
    const a = document.createElement("a");
    a.href = url;
    a.download = record.name;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
    return;
  }

  if (previewBtn) {
    if (activePreviewUrl) URL.revokeObjectURL(activePreviewUrl);
    activePreviewUrl = url;
    $("#modalFileName").textContent = record.name;
    const body = $("#modalBody");
    body.innerHTML = "";

    if (record.type.startsWith("image/")) {
      const img = document.createElement("img");
      img.src = url;
      img.alt = record.name;
      body.appendChild(img);
    } else if (record.type === "application/pdf" || record.type.startsWith("text/")) {
      const frame = document.createElement("iframe");
      frame.src = url;
      body.appendChild(frame);
    } else {
      body.innerHTML = `<p>${
        language === "bn"
          ? "এই ফাইল ফরম্যাট ব্রাউজারে সরাসরি প্রিভিউ হয় না। নিচের ডাউনলোড বাটন ব্যবহার করো।"
          : "Direct browser preview is unavailable for this format. Use Download instead."
      }</p>`;
    }
    $("#previewModal").hidden = false;
  }
});

$("#closeModalBtn").addEventListener("click", () => {
  $("#previewModal").hidden = true;
  if (activePreviewUrl) {
    URL.revokeObjectURL(activePreviewUrl);
    activePreviewUrl = null;
  }
});

// Jobs
$("#customJobForm").addEventListener("submit", (event) => {
  event.preventDefault();
  const title = $("#customJobTitle").value.trim();
  const company = $("#customJobCompany").value.trim();
  const loc = $("#customJobLocation").value.trim() || "Bangladesh";
  if (!title || !company) return;

  customJobs.unshift({
    id: makeId(),
    isCustom: true,
    titleBn: title,
    titleEn: title,
    company,
    locationBn: loc,
    locationEn: loc,
    type: "Full-time",
    typeBn: "ফুল-টাইম",
    detailBn: "ব্যবহারকারীর যোগ করা চাকরির তথ্য।",
    detailEn: "User-added job opportunity."
  });

  writeStorage(STORAGE_KEYS.customJobs, customJobs);
  $("#customJobForm").reset();
  renderJobs();
  showToast(language === "bn" ? "নতুন চাকরি তালিকায় যোগ হয়েছে" : "Job added to list");
});

$("#jobSearchInput").addEventListener("input", renderJobs);
$("#jobTypeFilter").addEventListener("change", renderJobs);
$("#onlySavedJobs").addEventListener("change", renderJobs);

$("#jobList").addEventListener("click", (event) => {
  const saveButton = event.target.closest("[data-save-job]");
  const trackButton = event.target.closest("[data-track-job]");
  const coverButton = event.target.closest("[data-cover-job]");
  const delCustomButton = event.target.closest("[data-delete-custom-job]");

  if (saveButton) {
    const id = saveButton.dataset.saveJob;
    const exists = savedJobs.includes(id);
    savedJobs = exists ? savedJobs.filter((jobId) => jobId !== id) : [...savedJobs, id];
    writeStorage(STORAGE_KEYS.savedJobs, savedJobs);
    renderJobs();
    renderHomeStats();
    showToast(
      language === "bn"
        ? (exists ? "সেভ তালিকা থেকে সরানো হয়েছে" : "চাকরি সেভ করা হয়েছে")
        : (exists ? "Removed from saved" : "Job saved")
    );
  }

  if (trackButton) {
    const job = getAllJobs().find((item) => item.id === trackButton.dataset.trackJob);
    if (!job) return;
    const title = language === "bn" ? job.titleBn : job.titleEn;
    applications.unshift({
      id: makeId(),
      name: `${job.company} — ${title}`,
      status: "applied",
      note: new Date().toLocaleDateString()
    });
    writeStorage(STORAGE_KEYS.applications, applications);
    renderApplications();
    showPage("tracker");
    showToast(language === "bn" ? "আবেদন ট্র্যাকারে যুক্ত হয়েছে" : "Added to tracker");
  }

  if (coverButton) {
    const job = getAllJobs().find((item) => item.id === coverButton.dataset.coverJob);
    if (!job) return;
    $("#clCompany").value = job.company;
    $("#clPosition").value = language === "bn" ? job.titleBn : job.titleEn;
    generateCoverLetter();
    showPage("cover");
    showToast(language === "bn" ? "কভার লেটার তৈরি হয়েছে" : "Cover letter ready");
  }

  if (delCustomButton) {
    customJobs = customJobs.filter((j) => j.id !== delCustomButton.dataset.deleteCustomJob);
    writeStorage(STORAGE_KEYS.customJobs, customJobs);
    renderJobs();
    showToast(language === "bn" ? "কাস্টম চাকরি মুছে ফেলা হয়েছে" : "Custom job deleted");
  }
});

// Tracker
$("#trackerForm").addEventListener("submit", (event) => {
  event.preventDefault();
  const name = $("#applicationName").value.trim();
  const status = $("#applicationStatus").value;
  const note = $("#applicationNote").value.trim();
  if (!name) return;

  applications.unshift({ id: makeId(), name, status, note });
  writeStorage(STORAGE_KEYS.applications, applications);
  $("#trackerForm").reset();
  $("#applicationStatus").value = "applied";
  renderApplications();
  showToast(language === "bn" ? "আবেদন যুক্ত হয়েছে" : "Application added");
});

$("#applicationList").addEventListener("change", (event) => {
  const select = event.target.closest("[data-status-id]");
  if (!select) return;
  const target = applications.find((item) => item.id === select.dataset.statusId);
  if (!target) return;
  target.status = select.value;
  writeStorage(STORAGE_KEYS.applications, applications);
  renderStats();
  showToast(language === "bn" ? "অবস্থা আপডেট হয়েছে" : "Status updated");
});

$("#applicationList").addEventListener("click", (event) => {
  const button = event.target.closest("[data-delete-application]");
  if (!button) return;
  applications = applications.filter((item) => item.id !== button.dataset.deleteApplication);
  writeStorage(STORAGE_KEYS.applications, applications);
  renderApplications();
  showToast(language === "bn" ? "আবেদন মুছে ফেলা হয়েছে" : "Application removed");
});

// Interview Coach
$("#answerBox").addEventListener("input", () => {
  interviewDrafts[questionIndex] = $("#answerBox").value;
  writeStorage(STORAGE_KEYS.interviewDrafts, interviewDrafts);
  updateWordCount();
});

$("#toggleTimerBtn").addEventListener("click", toggleTimer);

$("#evaluateAnswerBtn").addEventListener("click", () => {
  const text = $("#answerBox").value.trim();
  const words = text ? text.split(/\s+/).length : 0;
  const box = $("#answerFeedback");
  box.hidden = false;

  if (words < 10) {
    box.innerHTML = language === "bn"
      ? `<strong>স্কোর: ৪০/১০০</strong> — উত্তরটি আরও একটু বিস্তারিত করো (অন্তত ২০-৪০ শব্দ)। নিজের দক্ষতা ও বাস্তব উদাহরণ যোগ করো।`
      : `<strong>Score: 40/100</strong> — Expand your answer to at least 20–40 words with a concrete example.`;
  } else if (words < 28) {
    box.innerHTML = language === "bn"
      ? `<strong>স্কোর: ৭৫/১০০</strong> — ভালো শুরু! আরেকটি বাস্তব উদাহরণ বা ফলাফল যোগ করলে উত্তরটি ৯০+ মানের হবে।`
      : `<strong>Score: 75/100</strong> — Solid start! Adding one concrete result or example will push this to 90+.`;
  } else {
    box.innerHTML = language === "bn"
      ? `<strong>স্কোর: ৯২/১০০</strong> — চমৎকার ও পরিমিত উত্তর (${words} শব্দ)! আত্মবিশ্বাসের সাথে এটি বলার অনুশীলন করো।`
      : `<strong>Score: 92/100</strong> — Well-structured response (${words} words)! Practice delivering it clearly.`;
  }
});

$("#showTipBtn").addEventListener("click", () => {
  const q = questions[questionIndex];
  const tipBox = $("#answerTip");
  tipBox.innerHTML = language === "bn"
    ? `<div><strong>💡 পরামর্শ:</strong> ${escapeHTML(q.tipBn)}</div><div><strong>✅ নমুনা উত্তর:</strong> ${escapeHTML(q.sampleBn)}</div>`
    : `<div><strong>💡 Tip:</strong> ${escapeHTML(q.tipEn)}</div><div><strong>✅ Sample Answer:</strong> ${escapeHTML(q.sampleEn)}</div>`;
  tipBox.hidden = false;
});

$("#nextQuestionBtn").addEventListener("click", () => {
  resetTimer();
  questionIndex = (questionIndex + 1) % questions.length;
  renderQuestion();
});

$("#prevQuestionBtn").addEventListener("click", () => {
  resetTimer();
  questionIndex = (questionIndex - 1 + questions.length) % questions.length;
  renderQuestion();
});

// Full JSON Backup & Restore
$("#backupExportBtn").addEventListener("click", () => {
  const payload = {
    exportedAt: new Date().toISOString(),
    app: "SkillBridge AI Pro",
    cvData,
    savedJobs,
    customJobs,
    applications,
    interviewDrafts
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `SkillBridge_Backup_${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
  showToast(language === "bn" ? "ব্যাকআপ ফাইল ডাউনলোড হয়েছে" : "Backup exported");
});

$("#backupImportInput").addEventListener("change", async (event) => {
  const file = event.target.files?.[0];
  if (!file) return;
  try {
    const parsed = JSON.parse(await file.text());
    if (parsed.cvData) cvData = parsed.cvData;
    if (Array.isArray(parsed.savedJobs)) savedJobs = parsed.savedJobs;
    if (Array.isArray(parsed.customJobs)) customJobs = parsed.customJobs;
    if (Array.isArray(parsed.applications)) applications = parsed.applications;
    if (parsed.interviewDrafts) interviewDrafts = parsed.interviewDrafts;

    writeStorage(STORAGE_KEYS.cvData, cvData);
    writeStorage(STORAGE_KEYS.savedJobs, savedJobs);
    writeStorage(STORAGE_KEYS.customJobs, customJobs);
    writeStorage(STORAGE_KEYS.applications, applications);
    writeStorage(STORAGE_KEYS.interviewDrafts, interviewDrafts);

    syncCvInputs();
    renderCvPreview();
    renderJobs();
    renderApplications();
    renderQuestion();
    showToast(language === "bn" ? "ব্যাকআপ সফলভাবে রিস্টোর হয়েছে!" : "Backup restored!");
  } catch (err) {
    showToast(language === "bn" ? "সঠিক ব্যাকআপ JSON ফাইল দিন" : "Invalid backup file");
  }
  event.target.value = "";
});

// Clear All
$("#clearDataBtn").addEventListener("click", async () => {
  const confirmation = confirm(
    language === "bn"
      ? "তোমার সেভ করা CV, ফাইল ভল্ট, চাকরি ও আবেদন তালিকার সব তথ্য মুছে ফেলতে চাও?"
      : "Delete all saved CV data, File Vault items, jobs, and applications?"
  );
  if (!confirmation) return;

  savedJobs = [];
  customJobs = [];
  applications = [];
  interviewDrafts = {};
  cvData = {
    name: "",
    role: "",
    email: "",
    phone: "",
    address: "",
    portfolio: "",
    template: "modern",
    photo: "",
    summary: "",
    education: "",
    skills: "",
    experience: "",
    projects: ""
  };

  writeStorage(STORAGE_KEYS.savedJobs, savedJobs);
  writeStorage(STORAGE_KEYS.customJobs, customJobs);
  writeStorage(STORAGE_KEYS.applications, applications);
  writeStorage(STORAGE_KEYS.interviewDrafts, interviewDrafts);
  writeStorage(STORAGE_KEYS.cvData, cvData);
  await clearVaultDB();

  syncCvInputs();
  renderCvPreview();
  renderJobs();
  renderApplications();
  renderQuestion();
  await renderVault();
  showToast(language === "bn" ? "সব তথ্য পরিষ্কার করা হয়েছে" : "All data cleared");
});

function makeId() {
  if (window.crypto && typeof window.crypto.randomUUID === "function") {
    return window.crypto.randomUUID();
  }
  return `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

// Init
syncCvInputs();
setLanguage(language);
generateCoverLetter();
