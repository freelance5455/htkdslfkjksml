// Copies the local AI engine (llama.cpp WebAssembly) into www/vendor/wllama
// so the app works fully offline inside Android.
const fs = require('fs'), path = require('path');
const src = path.join(__dirname, '..', 'node_modules', '@wllama', 'wllama', 'esm');
const dst = path.join(__dirname, '..', 'www', 'vendor', 'wllama');
if (!fs.existsSync(src)) { console.error('Run "npm install" first.'); process.exit(1); }
fs.rmSync(dst, { recursive: true, force: true });
fs.cpSync(src, dst, { recursive: true });
for (const f of ['index.js', 'single-thread/wllama.wasm', 'multi-thread/wllama.wasm'])
  console.log((fs.existsSync(path.join(dst, f)) ? 'OK      ' : 'MISSING ') + f);
