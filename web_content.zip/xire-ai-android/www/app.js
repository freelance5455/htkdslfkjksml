const $=id=>document.getElementById(id),LOGO="assets/logo.png";
document.querySelectorAll('.L').forEach(i=>i.src=LOGO);
const ls={get(k,d){try{const v=localStorage.getItem(k);return v?JSON.parse(v):d}catch(e){return d}},set(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}};
let user=ls.get('x_user',null),chats=ls.get('x_chats',[]),cur=null,cfg=ls.get('x_cfg',{len:512}),busy=false,eng=null,loaded=null;
/* IndexedDB model store */
const db=new Promise((ok,no)=>{try{const r=indexedDB.open('xire',1);r.onupgradeneeded=()=>r.result.createObjectStore('models',{keyPath:'name'});r.onsuccess=()=>ok(r.result);r.onerror=()=>no(r.error)}catch(e){no(e)}});
const tx=async(m,f)=>{const d=await db;return new Promise((ok,no)=>{const t=d.transaction('models',m),s=t.objectStore('models'),q=f(s);t.oncomplete=()=>ok(q&&q.result);t.onerror=()=>no(t.error)})};
const listModels=()=>tx('readonly',s=>s.getAll()).catch(()=>[]);
const mb=n=>(n/1048576).toFixed(n>1e9?0:1)+' MB';
async function refreshModels(){const ms=await listModels()||[];const sel=$('model'),keep=sel.value;
 sel.innerHTML=ms.length?ms.map(m=>`<option>${esc(m.name)}</option>`).join(''):'<option value="">No model – tap ＋</option>';if(keep)sel.value=keep;
 $('ml').innerHTML=ms.length?ms.map(m=>`<div class="mi">▣ ${esc(m.name)}<small>${mb(m.size)}</small><button class="btn d" style="padding:4px 12px" data-d="${esc(m.name)}">Remove</button></div>`).join(''):'<div style="color:var(--mu);font-size:14px">No models yet.</div>';
 $('ml').querySelectorAll('[data-d]').forEach(b=>b.onclick=async()=>{await tx('readwrite',s=>s.delete(b.dataset.d));if(loaded===b.dataset.d){loaded=null;eng=null}refreshModels()})}
function esc(s){return String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]))}
async function addModel(f){if(!/\.gguf$/i.test(f.name)){alert('Please choose a .gguf model file.');return}const bar=$('bar');bar.style.display='block';bar.firstChild.style.width='0';
 try{bar.firstChild.style.width='60%';
  await tx('readwrite',s=>s.put({name:f.name,size:f.size,blob:f}));bar.firstChild.style.width='100%';setTimeout(()=>$('mo').classList.remove('on'),700)}
 catch(e){alert('Could not store this model on the device (storage full or blocked).')}
 setTimeout(()=>bar.style.display='none',500);await refreshModels();$('model').value=f.name}
$('plus').onclick=openModels;$('ma').onclick=()=>$('fi').click();
$('fi').onchange=e=>{if(e.target.files[0])addModel(e.target.files[0]);e.target.value=''};
function openSet(id){$('sn').value=user.name;$('sa').value=user.age;$('sl').value=cfg.len;$('setp').classList.add('on');$('side').classList.remove('open');if(id)setTimeout(()=>$(id).scrollIntoView({behavior:'smooth'}),60)}
function openModels(){$('mo').classList.add('on');$('side').classList.remove('open')}
$('nm').onclick=$('om').onclick=openModels;$('mx').onclick=()=>$('mo').classList.remove('on');$('gl').onclick=e=>{e.preventDefault();$('mo').classList.remove('on');openSet('gi')};
document.querySelectorAll('.ov').forEach(o=>o.addEventListener('mousedown',e=>{if(e.target===o&&o.id!=='ob')o.classList.remove('on')}));$('ns').onclick=()=>openSet();
/* Engine (llama.cpp WASM via wllama) */
async function getEngine(name){if(eng&&loaded===name)return eng;
 const B=new URL('vendor/wllama/',location.href).href;
 const {Wllama}=await import(B+'index.js');
 const w=new Wllama({'single-thread/wllama.wasm':B+'single-thread/wllama.wasm','multi-thread/wllama.wasm':B+'multi-thread/wllama.wasm'});
 const rec=await tx('readonly',s=>s.get(name));if(!rec)throw new Error('Model file not found. Add it again.');
 await w.loadModel([rec.blob],{n_ctx:2048});eng=w;loaded=name;return w}
/* UI */
function save(){ls.set('x_chats',chats.slice(0,60))}
function hero(){$('w').innerHTML=`<div id="hero"><img src="${LOGO}" alt=""><h1>Back at it, ${esc(user.name)}</h1><p>Add a model with ＋, then start chatting.</p></div>`}
function bubble(r,t,meta,gen){const d=document.createElement('div');d.className='m '+(r==='user'?'u':'a')+(gen?' gen':'');
 if(r==='user'){d.innerHTML='<div></div>';d.firstChild.textContent=t}
 else{d.innerHTML=`<img src="${LOGO}" alt=""><div class="b"><div class="t"></div></div>`;if(t)d.querySelector('.t').innerHTML=fmt(t);if(meta)foot(d,meta)}
 $('w').appendChild(d);$('msgs').scrollTop=1e9;return d.querySelector('.t')||d}
function inl(p){return esc(p.replace(/^\n+|\n+$/g,'')).replace(/`([^`\n]+)`/g,'<code>$1</code>').replace(/\*\*([^*\n]+)\*\*/g,'<b>$1</b>')}
function fmt(s){let h='';s.split('```').forEach((p,i)=>{if(i%2===0){if(p.trim())h+=inl(p)}else{const nl=p.indexOf('\n');let lang='',code=p;if(nl>=0&&/^[\w+#.-]*$/.test(p.slice(0,nl).trim())){lang=p.slice(0,nl).trim();code=p.slice(nl+1)}else if(nl<0&&/^[\w+#.-]*$/.test(p)){lang=p;code=''}
 h+=`<div class="cb"><div class="ch"><span>${esc(lang||'code')}</span><button class="cc">Copy</button></div><pre><code>${esc(code.replace(/\n$/,''))}</code></pre></div>`}});return h}
function foot(d,m){document.querySelectorAll('.rg').forEach(x=>x.remove());const s=(m.ms||0)/1000,f=document.createElement('div');f.className='ft';
 f.innerHTML=`<button class="fb cp" title="Copy"><svg viewBox="0 0 24 24"><rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V6a2 2 0 0 1 2-2h9"/></svg></button><button class="fb rg" title="Write again"><svg viewBox="0 0 24 24"><path d="M20 12a8 8 0 1 1-2.3-5.7M20 4v5h-5"/></svg></button><span>${m.tok||0} tokens · ${s.toFixed(1)}s${m.tok&&s?' · '+(m.tok/s).toFixed(1)+' tok/s':''}</span>`;
 f.querySelector('.cp').onclick=()=>{try{navigator.clipboard.writeText(m.t)}catch(e){}};f.querySelector('.rg').onclick=regen;d.querySelector('.b').appendChild(f)}
async function regen(){if(busy)return;const c=chats.find(x=>x.id===cur);if(!c||!c.m.length)return;const name=$('model').value;if(!name){openModels();return}
 if(c.m[c.m.length-1].r==='assistant')c.m.pop();const l=document.querySelector('#w .m.a:last-child');if(l)l.remove();save();await gen(c,name)}
$('w').addEventListener('click',e=>{const b=e.target.closest('.cc');if(!b)return;try{navigator.clipboard.writeText(b.closest('.cb').querySelector('code').textContent).then(()=>{b.textContent='Copied ✓';setTimeout(()=>b.textContent='Copy',1300)})}catch(x){}});
function render(){const c=chats.find(x=>x.id===cur);$('w').innerHTML='';if(!c||!c.m.length)return hero();c.m.forEach(m=>bubble(m.r,m.t,m.r==='assistant'&&m.ms!=null?m:null))}
function renderList(){$('list').innerHTML='';chats.forEach(c=>{const b=document.createElement('div');b.className='nav'+(c.id===cur?' on':'');b.innerHTML=`<span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1">${esc(c.t)}</span><button class="x" data-x="1" title="Options">⋯</button>`;
 b.onclick=e=>{const x=e.target.closest('[data-x]');if(x){e.stopPropagation();menu(x,c);return}cur=c.id;renderList();render();$('side').classList.remove('open')};$('list').appendChild(b)})}
function closeMenu(){document.querySelectorAll('.pm').forEach(x=>x.remove())}
function menu(btn,c){closeMenu();const r=btn.getBoundingClientRect(),m=document.createElement('div');m.className='pm';m.style.top=r.bottom+4+'px';m.style.left=Math.max(8,Math.min(r.left,window.innerWidth-170))+'px';
 m.innerHTML='<button data-a="r"><svg viewBox="0 0 24 24"><path d="M4 20h4L19 9l-4-4L4 16v4zM13 7l4 4"/></svg>Rename</button><button data-a="d" class="dl"><svg viewBox="0 0 24 24"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/></svg>Delete</button>';
 m.onclick=e=>{const a=e.target.closest('button');if(!a)return;closeMenu();if(a.dataset.a==='r')ask('Rename chat',c.t,v=>{c.t=v.slice(0,60);save();renderList()});else ask('Delete this chat?',null,()=>{chats=chats.filter(x=>x.id!==c.id);if(cur===c.id)cur=null;save();renderList();render()},'Delete')};
 document.body.appendChild(m);setTimeout(()=>document.addEventListener('click',closeMenu,{once:true}),0)}
function ask(title,val,cb,ok){const i=$('dgi'),y=$('dgok');$('dgt').textContent=title;i.style.display=val===null?'none':'block';i.value=val||'';y.textContent=ok||'Save';y.className='btn '+(val===null?'d':'p');$('dg').classList.add('on');if(val!==null)setTimeout(()=>{i.focus();i.select()},60);
 y.onclick=()=>{const v=i.value.trim();if(val!==null&&!v)return;$('dg').classList.remove('on');cb(v)};$('dgno').onclick=()=>$('dg').classList.remove('on');i.onkeydown=e=>{if(e.key==='Enter')y.click()}}
function newChat(){cur=null;renderList();render();$('side').classList.remove('open');$('in').focus()}
$('nc').onclick=newChat;const toggleSide=()=>{const s=$('side');window.innerWidth>760?s.style.marginLeft=s.style.marginLeft?'':'-272px':s.classList.toggle('open')};$('tg').onclick=$('sc2').onclick=toggleSide;$('main').addEventListener('click',e=>{if(window.innerWidth<=760&&!e.target.closest('#tg'))$('side').classList.remove('open')});
$('in').oninput=function(){this.style.height='auto';this.style.height=this.scrollHeight+'px';$('send').disabled=!this.value.trim()||busy};
$('in').onkeydown=e=>{if(e.key==='Enter'&&!e.shiftKey&&window.innerWidth>760){e.preventDefault();go()}};
$('send').onclick=go;
async function go(){const t=$('in').value.trim();if(!t||busy)return;const name=$('model').value;
 if(!name){openModels();return}
 let c=chats.find(x=>x.id===cur);if(!c){c={id:Date.now(),t:t.slice(0,32),m:[]};chats.unshift(c);cur=c.id;$('w').innerHTML='';renderList()}
 c.m.push({r:'user',t});bubble('user',t);$('in').value='';$('in').style.height='auto';await gen(c,name)}
async function gen(c,name){busy=true;$('send').disabled=true;
 const el=bubble('assistant','',null,true);el.innerHTML=`<span class="ld">${loaded===name?'Thinking…':'Loading model into memory…'}</span>`;let out='',n=0,t0=performance.now();
 try{const w=await getEngine(name);t0=performance.now();
  const msgs=[{role:'system',content:`You are XIRE AI, a helpful assistant running locally on the user's device. The user's name is ${user.name}. Answer directly and concisely. Put any code in markdown fenced blocks with a language tag.`},...c.m.slice(-12).map(m=>({role:m.r==='user'?'user':'assistant',content:m.t}))];
  await w.createChatCompletion(msgs,{nPredict:cfg.len,sampling:{temp:.7,top_p:.9},onNewToken:(a,b,txt)=>{out=txt;n++;el.innerHTML=fmt(txt);$('msgs').scrollTop=1e9}});
  const meta={r:'assistant',t:out||'(no reply)',tok:n,ms:Math.round(performance.now()-t0)};c.m.push(meta);el.innerHTML=fmt(meta.t);foot(el.closest('.m'),meta)}
 catch(e){el.closest('.m').classList.add('e');el.textContent='Could not run the model: '+(e.message||e)+'. Make sure the file is a valid .gguf model and this page can load the engine.'}
 el.closest('.m').classList.remove('gen');busy=false;$('send').disabled=!$('in').value.trim();save()}
/* Profile / settings */
function paint(){$('un').textContent=user.name;$('av').textContent=user.name[0].toUpperCase()}
$('ogo').onclick=()=>{const n=$('on').value.trim(),a=+$('oa').value;if(!n||!a||a<1||a>120){$('on').style.borderColor=n?'':'#b3402f';$('oa').style.borderColor=a?'':'#b3402f';return}
 user={name:n,age:a};ls.set('x_user',user);$('ob').classList.remove('on');paint();render()};
$('me').onclick=()=>openSet();
$('ss').onclick=()=>{const n=$('sn').value.trim(),a=+$('sa').value;if(!n||!a)return;user={name:n,age:a};cfg.len=Math.min(4096,Math.max(32,+$('sl').value||512));ls.set('x_user',user);ls.set('x_cfg',cfg);paint();render();const b=$('ss');b.textContent='Saved ✓';setTimeout(()=>b.textContent='Save changes',1400)};
$('sback').onclick=()=>$('setp').classList.remove('on');
$('sc').onclick=()=>ask('Delete all chats?',null,()=>{chats=[];cur=null;save();renderList();render()},'Delete all');
function theme(t){ls.set('x_theme',t);const r=document.documentElement;t==='system'?r.removeAttribute('data-theme'):r.setAttribute('data-theme',t);document.querySelectorAll('[data-t]').forEach(b=>b.classList.toggle('on',b.dataset.t===t))}
document.querySelectorAll('[data-t]').forEach(b=>b.onclick=()=>theme(b.dataset.t));theme(ls.get('x_theme','system'));
refreshModels();renderList();
if(user){paint();render()}else{$('ob').classList.add('on')}
