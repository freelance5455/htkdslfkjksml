# XIRE AI – Android app (HTML + CSS + JavaScript)

Private AI chat that runs a `.gguf` model on the phone. Nothing is sent to a server.

Files: `www/index.html` (screens), `www/style.css` (design), `www/app.js` (logic + AI engine),
`www/assets/logo.png`, `resources/` (app icon). Capacitor wraps `www/` into an Android app.

## Build the APK (on a computer)
1. Install **Node.js 18+**, **Android Studio** (it includes the Android SDK and JDK).
2. In this folder run:
   ```
   npm install
   npm run setup
   npm run open
   ```
   `setup` copies the AI engine into the app (offline), creates the `android/` project and the app icon.
3. Android Studio opens. Wait for Gradle sync, then **Build > Build Bundle(s)/APK(s) > Build APK(s)**.
   The APK is in `android/app/build/outputs/apk/debug/`. Copy it to the phone and install it
   (allow "install unknown apps"). Or plug the phone in (USB debugging) and press Run.
4. After changing any file in `www/`: `npm run sync`, then rebuild.

## Use
1. Open the app, enter your name and age.
2. Download a small instruct model in **.gguf** (Q4_K_M) from https://huggingface.co/models?library=gguf&sort=trending
   (e.g. Qwen2.5 0.5B / 1.5B Instruct, Llama 3.2 1B Instruct).
3. In the app tap **＋**, choose the file. It is copied into the app's storage.
4. Pick the model next to the send button and chat. The first reply loads the model.

## Notes
- Best sizes: 0.5B–1.5B (Q4). 3B+ is slow and may run out of memory on phones.
- The engine runs on the CPU inside the Android WebView (single-thread), so speed is modest.
  For much faster speed a native llama.cpp (Kotlin/C++) version is the next step.
- If `npm run vendor` prints MISSING lines, the engine package layout changed; send me the output.
