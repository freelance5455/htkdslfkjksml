# Precifica+ Android v2.0.0 — guia de compilação

## O que é
Este pacote contém o projeto-fonte Android; não contém um APK já compilado. O aplicativo carrega o HTML localmente e guarda os dados no armazenamento privado do app. Esta edição remove as funções de importar e exportar: não há exportação de planilhas em PDF/XLS/JSON, exportação/importação de backup, importação de planilhas nem instalação de atualização por arquivo. Os dados são guardados no armazenamento privado do aplicativo e não são sincronizados com outras plataformas.

## Como abrir e gerar o APK
1. Instale o Android Studio e, pelo SDK Manager, instale uma versão recente do Android SDK compatível com o projeto.
2. Extraia o ZIP para uma pasta normal do computador.
3. No Android Studio, escolha **Open** e selecione a pasta `PrecificaPlusAndroid` (a pasta que contém `settings.gradle`).
4. Aguarde a sincronização do Gradle. Se solicitado, aceite a instalação das ferramentas de compilação.
5. Para gerar um APK de teste, use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Quando terminar, use o aviso **Locate** ou procure em `app/build/outputs/apk/debug/`. O arquivo de teste costuma se chamar `app-debug.apk`.
7. Transfira o APK ao celular e permita a instalação de apps dessa origem quando o Android solicitar. Para distribuição pública, gere uma versão assinada em **Build > Generate Signed Bundle / APK**.

## Onde alterar o aplicativo
- `app/src/main/assets/public/index.html`: interface, estilos e lógica JavaScript.
- `app/src/main/java/studios/becout/precificaplus/MainActivity.java`: atividade Android e configuração do WebView.
- `app/src/main/AndroidManifest.xml`: permissões e configuração declarada do app.
- `app/build.gradle`: versão, identificador e configuração de compilação.
- `app/src/main/res/mipmap-*`: ícones em diferentes densidades.

Depois de editar o HTML, salve o arquivo e gere o APK novamente. Não remova a ponte/configuração do WebView sem testar todas as funções.

## Dados e cuidados
Os dados do app Android são isolados dos dados do navegador e do Windows. Desinstalar o app ou limpar seus dados pode apagá-los. Como não há importação/exportação de dados no aplicativo, preserve a instalação e seus dados ao atualizar: mantenha o mesmo applicationId e aumente versionCode nas versões futuras. Desinstalar o app ou limpar seus dados pode apagar os registros. Faça uma cópia do projeto-fonte antes de grandes mudanças. Não inclua chaves ou senhas no código-fonte.

## Solução de problemas
- **Falha na sincronização:** confira a conexão, a versão do Android Studio e os SDKs indicados pelo erro.
- **APK não instala:** confira a arquitetura/versão mínima do Android e remova uma instalação conflitante se necessário.
- **Tela branca:** confira o HTML em `assets/public/index.html` e os logs do Logcat.

O projeto-fonte precisa ser compilado no Android Studio; este ZIP, por si só, não é um APK.

## Edição Android sem importação/exportação

A versão Android mantém os dados localmente com `NativeStorage` (SharedPreferences) e não contém ações de importar/exportar planilhas, arquivos de atualização ou backups. Para compilar: use Android Studio com Android SDK 35 e JDK 17; abra esta pasta e selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**. O APK de teste é criado em `app/build/outputs/apk/debug/`.
