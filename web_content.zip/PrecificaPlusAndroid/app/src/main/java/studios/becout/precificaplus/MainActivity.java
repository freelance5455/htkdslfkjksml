package studios.becout.precificaplus;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

public final class MainActivity extends Activity {
    private WebView webView;
    private SharedPreferences storage;
    private static final String PREFS = "precifica_plus_local_storage";
    private static final String START_URL = "file:///android_asset/public/index.html";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(247, 248, 250));
        getWindow().setNavigationBarColor(Color.rgb(247, 248, 250));
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        storage = getSharedPreferences(PREFS, MODE_PRIVATE);
        FrameLayout root = new FrameLayout(this);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(247, 248, 250));
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(false);
        webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        webView.getSettings().setSupportMultipleWindows(false);
        webView.addJavascriptInterface(new NativeStorage(), "NativeStorage");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                // Keep this offline application inside the bundled assets only.
                return !(url.startsWith("file:///android_asset/public/") || url.startsWith("about:blank"));
            }
        });
        root.addView(webView, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);
        if (savedInstanceState != null) webView.restoreState(savedInstanceState); else webView.loadUrl(START_URL);
    }

    @Override public void onSaveInstanceState(Bundle outState) { super.onSaveInstanceState(outState); if (webView != null) webView.saveState(outState); }
    @Override public void onBackPressed() {
        if (webView != null) webView.evaluateJavascript("(function(){return window.handleNativeBack?window.handleNativeBack():false})()", value -> {
            if (!"true".equals(value)) MainActivity.super.onBackPressed();
        }); else super.onBackPressed();
    }

    public final class NativeStorage {
        @JavascriptInterface public String getItem(String key) { return storage.getString(key, null); }
        @JavascriptInterface public void setItem(String key, String value) { storage.edit().putString(key, value).apply(); }
        @JavascriptInterface public void removeItem(String key) { storage.edit().remove(key).apply(); }
        @JavascriptInterface public void clear() { storage.edit().clear().apply(); }
    }
}
