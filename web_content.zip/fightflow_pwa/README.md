# FIGHTFLOW – Smartphone-Web-App

Dies ist ein installierbarer PWA-Prototyp für Android und iPhone.

## Lokal ansehen
Öffne `index.html` im Browser. Für Installations-/Offline-Funktionen muss die App über HTTPS oder localhost bereitgestellt werden.

## Auf dem Smartphone installieren
1. Veröffentliche den Inhalt dieses Ordners bei einem HTTPS-Webhost (z. B. GitHub Pages oder Netlify).
2. Android: Website in Chrome öffnen → Menü → „App installieren“ oder „Zum Startbildschirm hinzufügen“.
3. iPhone: Website in Safari öffnen → Teilen → „Zum Home-Bildschirm“.

## Enthalten
- Onboarding und Kämpferprofil
- Dashboard und Tages-Trainingsplan
- Abhakbare Trainings-Checkliste
- Trainingsnotiz und Profilverwaltung
- Lokale Speicherung im Browser
- PWA-Manifest und einfacher Offline-Cache

## Noch nicht enthalten
Kein echtes Benutzerkonto, keine Cloud-Synchronisierung, kein KI-Coach, keine Push-Nachrichten und keine Veröffentlichung in App Store/Google Play. Trainingsvorschläge sind allgemeine Beispiele und ersetzen keine Betreuung durch qualifizierte Trainer. Vor intensiver Belastung die Übungen mit einem Coach abstimmen.
