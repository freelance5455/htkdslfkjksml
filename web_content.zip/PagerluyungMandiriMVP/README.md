# PAGERLUYUNG MANDIRI — Android MVP

MVP aplikasi Android offline-first berbasis WebView. Fitur demo: login warga/admin, Bank Sampah (foto timbangan + saldo lokal), riwayat dan verifikasi, Maggot, Kompos, 1 Rumah 5 Tanaman, notifikasi, profil desa.

## Build APK
Buka folder ini di Android Studio, tunggu Gradle sync, lalu pilih **Build > Build APK(s)**. APK debug biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.

## Catatan produksi
Data saat ini tersimpan lokal di perangkat. Untuk versi produksi perlu backend/database, autentikasi, storage foto, verifikasi pengurus, push notification, audit log, dan role/permission server-side.
