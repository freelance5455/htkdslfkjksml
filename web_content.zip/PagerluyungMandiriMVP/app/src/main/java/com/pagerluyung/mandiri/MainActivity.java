package com.pagerluyung.mandiri;
import android.app.Activity; import android.os.Bundle; import android.webkit.*; import android.view.*; import android.content.*; import android.net.Uri;
public class MainActivity extends Activity {
 WebView web; ValueCallback<Uri[]> upload;
 @Override public void onCreate(Bundle b){super.onCreate(b); web=new WebView(this); web.getSettings().setJavaScriptEnabled(true); web.getSettings().setDomStorageEnabled(true); web.setWebChromeClient(new WebChromeClient(){@Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> cb,FileChooserParams p){upload=cb; Intent i=p.createIntent(); try{startActivityForResult(i,1001);}catch(Exception e){upload=null;return false;} return true;}}); web.loadUrl("file:///android_asset/index.html"); setContentView(web);}
 @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==1001&&upload!=null){upload.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(c,d));upload=null;}}
 @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}
