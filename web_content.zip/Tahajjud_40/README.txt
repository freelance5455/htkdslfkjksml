TAHAJJUD 40 — Android telefon uchun

Bu hozircha APK emas, balki internet talab qilmaydigan, bitta HTML fayldan iborat mini-ilova.

Ishlatish:
1. ZIP faylni telefonda ochib, index.html faylini chiqaring.
2. index.html faylini Chrome orqali oching.
3. Belgilar va zikr hisoblagichi shu brauzerda saqlanadi.

Eslatma: Chrome versiyasi va telefon sozlamalariga qarab HTML faylni bosh ekranga ilova sifatida qo‘shish imkoniyati farq qilishi mumkin. Haqiqiy APK yaratish uchun Android SDK/Android Studio orqali build qilish kerak.
