MY AI STUDIO — eerste PWA-prototipe

Hierdie is die eerste gebruikerskoppelvlak. Dit genereer nog nie prente nie en is nog nie aan ComfyUI gekoppel nie.

LÊERS
- index.html: app se inhoud
- styles.css: voorkoms en uitleg
- app.js: knoppies en installasiegedrag
- manifest.json: PWA-app besonderhede
- service-worker.js: kas vir heropening/offline UI
- icons/icon.svg: app-ikoon

BELANGRIK
'n PWA moet deur localhost of HTTPS gelaai word om dienswerker/installeerfunksies te gebruik.
Moenie net index.html dubbelklik en verwag dat installasie werk nie.

Volgende stap: begin 'n plaaslike webbediener op die PC, toets in die browser, en dan toets op Android op dieselfde Wi-Fi. ComfyUI en afstandtoegang word eers later ingestel.
