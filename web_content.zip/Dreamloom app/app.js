const promptEl = document.querySelector("#prompt");
const negativeEl = document.querySelector("#negativePrompt");
const statusEl = document.querySelector("#status");
const generateBtn = document.querySelector("#generateBtn");
const installBtn = document.querySelector("#installBtn");
let installPrompt = null;

// This first version is a UI prototype. ComfyUI connection is added later.
generateBtn.addEventListener("click", () => {
  const prompt = promptEl.value.trim();
  if (!prompt) {
    statusEl.textContent = "Tik eers 'n beskrywing van jou prent in.";
    promptEl.focus();
    return;
  }
  statusEl.textContent = "Jou prompt is gereed. Ons koppel ComfyUI in 'n latere stap; geen prent is nog gegenereer nie.";
});

window.addEventListener("beforeinstallprompt", (event) => {
  event.preventDefault();
  installPrompt = event;
  installBtn.hidden = false;
});
installBtn.addEventListener("click", async () => {
  if (!installPrompt) return;
  installPrompt.prompt();
  await installPrompt.userChoice;
  installPrompt = null;
  installBtn.hidden = true;
});

if ("serviceWorker" in navigator && location.protocol !== "file:") {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("./service-worker.js").catch((err) => {
      console.warn("Service worker kon nie registreer nie:", err);
    });
  });
}
