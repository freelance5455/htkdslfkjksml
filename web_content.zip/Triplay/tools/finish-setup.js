// Runs after "npm install" + "cap sync". Adds the Gradle wrapper files (gradlew / gradlew.bat / gradle-wrapper.jar)
// from Capacitor's own official Android template, only if they are missing. Safe to run many times.
const fs = require('fs');
const path = require('path');
const cp = require('child_process');

const root = path.join(__dirname, '..');
const android = path.join(root, 'android');
const jar = path.join(android, 'gradle', 'wrapper', 'gradle-wrapper.jar');

function done(msg) { console.log(msg); process.exit(0); }

if (fs.existsSync(jar) && fs.existsSync(path.join(android, 'gradlew'))) done('Gradle wrapper already present - OK.');

try {
  const tpl = path.join(root, 'node_modules', '@capacitor', 'cli', 'assets', 'android-template.tar.gz');
  if (!fs.existsSync(tpl)) done('(info) Capacitor template not found - Android Studio will download Gradle by itself. OK.');
  const tmp = path.join(root, '.tmp-template');
  fs.rmSync(tmp, { recursive: true, force: true });
  fs.mkdirSync(tmp, { recursive: true });
  cp.execSync('tar -xzf "' + tpl + '" -C "' + tmp + '"', { stdio: 'ignore' });
  const base = fs.existsSync(path.join(tmp, 'android-template')) ? path.join(tmp, 'android-template') : tmp;
  const copyIfMissing = (rel) => {
    const from = path.join(base, rel), to = path.join(android, rel);
    if (fs.existsSync(from) && !fs.existsSync(to)) {
      fs.mkdirSync(path.dirname(to), { recursive: true });
      fs.copyFileSync(from, to);
      console.log('added ' + rel);
    }
  };
  copyIfMissing(path.join('gradle', 'wrapper', 'gradle-wrapper.jar'));
  copyIfMissing('gradlew');
  copyIfMissing('gradlew.bat');
  try { fs.chmodSync(path.join(android, 'gradlew'), 0o755); } catch (e) {}
  fs.rmSync(tmp, { recursive: true, force: true });
  done('Gradle wrapper ready - OK.');
} catch (e) {
  done('(info) Could not add Gradle wrapper files (' + e.message + '). Android Studio will download Gradle by itself. OK.');
}
