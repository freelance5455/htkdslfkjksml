#!/bin/bash
cd "$(dirname "$0")"
echo "=== TRIPLAY - one time setup ==="
if ! command -v node >/dev/null 2>&1; then echo "Node.js nahi mila. https://nodejs.org se LTS (22+) install karo."; exit 1; fi
MAJOR=$(node -p "process.versions.node.split('.')[0]")
if [ "$MAJOR" -lt 22 ]; then echo "Node $MAJOR purana hai. Node 22+ chahiye."; exit 1; fi
npm install && npx cap sync android && node tools/finish-setup.js && \
echo "DONE! Android Studio > File > Open > 'android' folder chuno."
