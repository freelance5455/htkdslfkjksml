# ============================================================================
#  TRIPLAY - R8 / ProGuard rules (release build: minifyEnabled + shrinkResources)
# ============================================================================

# ---- Capacitor core (needed: plugins are found by reflection / annotations) ----
-keep class com.getcapacitor.** { *; }
-keep @com.getcapacitor.annotation.CapacitorPlugin public class * {
    @com.getcapacitor.annotation.PermissionCallback <methods>;
    @com.getcapacitor.annotation.ActivityCallback <methods>;
    @com.getcapacitor.PluginMethod public <methods>;
}
-keep public class * extends com.getcapacitor.Plugin { *; }
-dontwarn com.getcapacitor.**

# ---- Cordova compatibility layer ----
-keep class org.apache.cordova.** { *; }
-dontwarn org.apache.cordova.**

# ---- JavaScript <-> Java bridge (WebView calls these by name) ----
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# ---- This app ----
-keep class com.ashitech.triplay.** { *; }

# ---- Useful crash reports in Play Console ----
-keepattributes *Annotation*, Signature, InnerClasses, EnclosingMethod, SourceFile, LineNumberTable
-renamesourcefileattribute SourceFile

# ---- ADS (baad me): AdMob / AppLovin / Unity apni consumer rules khud saath laate hain.
#      Agar kisi ad SDK ke baad release build me crash aaye to us SDK ki "ProGuard" doc se rule yahan add karo.
# -keep class com.google.android.gms.ads.** { *; }
# -keep class com.applovin.** { *; }
# -keep class com.unity3d.ads.** { *; }
