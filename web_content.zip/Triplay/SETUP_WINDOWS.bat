@echo off
title Triplay - One time setup
cd /d "%~dp0"
echo ==============================================
echo   TRIPLAY - one time setup (2-5 minute)
echo ==============================================
echo.
where node >nul 2>&1
if errorlevel 1 goto nonode
node -e "process.exit(parseInt(process.versions.node)<22?1:0)"
if errorlevel 1 goto oldnode
echo [1/3] Downloading Capacitor (internet chahiye)...
call npm install
if errorlevel 1 goto fail
echo.
echo [2/3] Copying game files into the Android project...
call npx cap sync android
if errorlevel 1 goto fail
echo.
echo [3/3] Finishing...
node tools\finish-setup.js
echo.
echo ==============================================
echo   DONE!  Ab Android Studio kholo ->
echo   File ^> Open ^> is folder ke andar ka "android" folder chuno.
echo ==============================================
pause
exit /b 0
:nonode
echo Node.js install nahi hai. https://nodejs.org se "LTS" (version 22 ya upar) download karke install karo,
echo phir is file ko dobara double-click karo.
pause
exit /b 1
:oldnode
echo Aapka Node.js purana hai. Capacitor 8 ke liye Node 22 ya upar chahiye.
node -v
echo https://nodejs.org se naya "LTS" install karo, phir ye file dobara chalao.
pause
exit /b 1
:fail
echo.
echo Kuch error aaya. Internet check karo aur ye file dobara chalao. Error upar likha hai.
pause
exit /b 1
