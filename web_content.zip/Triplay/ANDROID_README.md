# TRIPLAY - Android (Capacitor 8) Project

App: **Triplay** | Package ID: **com.ashitech.triplay** | Support: ashishkumarmp233@gmail.com
Games: Arrow Puzzle, Ludo, Cubex Blaster | Orientation: Portrait | Min Android 7.0 (API 24) | Target Android 16 (API 36)

---------------------------------------------------------------------
## A. PEHLI BAAR (sirf ek baar) - 3 cheezein install karo

1. **Node.js LTS (version 22 ya upar)** -> https://nodejs.org  (Next-Next karke install)
2. **Android Studio "Otter" (2025.2.1) ya naya** -> https://developer.android.com/studio
   (Isme JDK 21 apne aap aata hai - alag se kuch install nahi karna.)
3. Internet on rakho (pehli baar Capacitor aur Gradle download hote hain, ~10-15 minute).

## B. SETUP (2-5 minute)

1. ZIP ko **extract** karo (Desktop par, folder ka naam simple rakho, jaise `Triplay`).
2. **Windows:** `SETUP_WINDOWS.bat` par double-click.  **Mac/Linux:** terminal me `./SETUP_MAC_LINUX.sh`.
   Ye khud `npm install` aur `npx cap sync android` chalata hai. Aakhir me "DONE" aayega.

## C. ANDROID STUDIO ME 3 BUTTONS (.aab banane ke liye)

**Button 1 - File > Open** -> is project ke andar ka **`android`** folder chuno (poora Triplay nahi, sirf `android`) -> OK.
Neeche progress bar (Gradle sync) khatam hone do (pehli baar 5-15 min). Agar "Trust project" pooche to **Trust** dabao.

**Button 2 - Build > Generate Signed App Bundle / APK...** -> **Android App Bundle** chuno -> **Next**.

**Button 3 - Next > (Create new... se keystore banao) > Next > "release" chuno > Create/Finish.**
Keystore banate waqt: ek file ka naam (jaise `triplay.jks`), password do, alias `triplay`, validity 25+ saal, apna naam bharo.

Kuch der me neeche "Generate Signed Bundle: locate" aayega -> **locate** dabao.
Tumhari file: `android/app/release/app-release.aab`  -> yehi Play Console me upload karni hai.

> **BAHUT ZAROORI:** `.jks` keystore file aur uska password **kisi safe jagah (Google Drive + pen drive)** me backup rakho.
> Ye kho gayi to game ka update kabhi nahi daal paoge. Play Console me **"Play App Signing"** ON rakho (default hai).

Update daalna ho to: `android/app/build.gradle` me `versionCode` +1 karo (1 -> 2 -> 3) aur wahi 3 buttons dobara.

## D. GAME ME BADLAV KARNA HO TO

Game files `www/` me hain: `www/index.html`, `www/css/style.css`, `www/js/game.js`.
Badlav ke baad: `npx cap sync android` (ya SETUP file dobara chalao), phir Android Studio me naya .aab banao.

---------------------------------------------------------------------
## E. ADS - abhi kya hai aur baad me kahan code dalna hai

Abhi sab ads **TEST** hain (HTML ka "TEST BANNER AD" + demo pop-up). Koi asli SDK nahi laga.
Sab kuch `www/js/game.js` ke **sabse upar** ("ADS HOOKS") me 4 functions se jata hai:

| Function | Kab call hota hai (pehle se connected) |
|---|---|
| `window.showBannerAd()` / `hideBannerAd()` | Arrow, Ludo, Cubex gameplay khulne / band hone par |
| `window.showInterstitialAd(onClosed)` | Arrow: har 4th level complete - Cubex: har 3rd level complete - Ludo: game over / result ke baad |
| `window.showRewardedAd(callback)` | Extra life, hint, bomb, undo-type reward, Ludo bonus, free coins. `callback(true)` = video poora dekha (reward do), `callback(false)` = nahi |

Har function ke andar `>>> PUT REAL ... CODE HERE <<<` likha hai - bas wahin AdMob ka code paste karna.

### Baad me AdMob + AppLovin + Unity (Mediation) kaise lagana
1. **AdMob** account banao -> app add karo (package `com.ashitech.triplay`) -> 3 ad units banao (Banner, Interstitial, Rewarded).
2. AdMob console > **Mediation** me AppLovin aur Unity Ads ko waterfall/bidding me jodo (network ke keys wahin se milte hain).
3. Ek Capacitor AdMob plugin install karo, jaise `@capacitor-community/admob` (Capacitor 8 wala version) -> `npm install` -> `npx cap sync android`.
4. `android/app/src/main/AndroidManifest.xml` me AdMob **APPLICATION_ID** wala commented block khol do (asli App ID daalo).
5. `android/app/build.gradle` me mediation adapters jodo (`com.google.ads.mediation:applovin`, `com.google.ads.mediation:unity`) - latest version Google ki "Mediation adapters" page par milta hai.
6. `game.js` ke 4 hooks me commented example ko asli ad unit IDs ke saath active karo; neeche wali "TEST MODE" line hata do.
7. Test karte waqt **sirf TEST ad IDs** (ya `isTesting:true`) use karo. Apne asli ads khud mat dabao (account ban ho sakta hai).
8. Release se pehle: Play Console > App content > **Ads = Yes**, **Advertising ID = Yes**, aur EU/UK users ke liye Google **UMP (consent)** form AdMob console me on karo.

Android me banner ki asli height 50-90 dp ho sakti hai. Plugin se height mile to `window.TPSetBannerHeight(px)` call karo - hint button aur game screen apne aap upar adjust ho jayenge.

---------------------------------------------------------------------
## F. SECURITY: ProGuard / R8 (Java side) - pehle se ON hai

`android/app/build.gradle` me release build ke liye pehle se:
`minifyEnabled = true` aur `shrinkResources = true`. Rules `android/app/proguard-rules.pro` me hain (Capacitor, WebView bridge, app package).
Agar ad SDK jodne ke baad release build crash kare to us SDK ki ProGuard rule `proguard-rules.pro` me add karo.

### game.js ko obfuscate karna ho (OPTIONAL) - in naamo ko EXCLUDE karna hai
Ye 4 naam kabhi rename nahi hone chahiye (Android/ad code inhe naam se bulata hai):
- `showBannerAd`
- `showInterstitialAd`
- `showRewardedAd`
- `hideBannerAd`
Saath me ye bhi: `TPNativeAds`, `TP_AD_CONFIG`, `TPSetBannerHeight`, `showAdPrivacyOptions`.
Ready config: `javascript-obfuscator.config.json` (inme ye sab "reservedNames" me pehle se likhe hain).
Command (pehle `www/js/game.js` ka backup rakho, phir poora game test karo):
```
npx javascript-obfuscator www/js/game.js --output www/js/game.js --config javascript-obfuscator.config.json
npx cap sync android
```
Note: game ke andar Cubex ka code ek string me hai, config me `stringArray:false` isliye rakha hai taaki wo na toote.

---------------------------------------------------------------------
## G. PLAY CONSOLE CHECKLIST (privacy / policy)

- **Privacy Policy URL (zaroori):** `store_assets/privacy-policy.html` ko kisi free jagah host karo (GitHub Pages / Google Sites) aur URL Play Console me daalo. (Chahe to `www/js/game.js` me `window.TP_PRIVACY_URL = '...'` set karo to wo app ke andar bhi dikhega.)
- **Data safety form:** Device ID (Advertising ID) - collected, shared with ad partners - purpose: Advertising. Baaki sab "No". (Game progress sirf phone me rehta hai.)
- **Target audience:** 13+ rakha gaya hai (app me yahi likha hai). Agar bachon (13 se kam) ko bhi target karna ho to Families Policy lagti hai aur sirf certified ad networks chalte hain - ye alag decision hai.
- **Content rating:** questionnaire bharo (Ludo/puzzle: no violence).
- **Ads declaration:** "Contains ads" = Yes.
- **Store graphics:** `store_assets/icon-512.png` aur `feature-graphic-1024x500.png` ready hain. Phone screenshots tumhe khud lene honge (kam se kam 2).
- **Tablets/foldables:** Android 16 par bade screens (600dp+) par orientation lock ignore ho sakta hai; game responsive hai.

## H. FOLDER KA NAKSHA
```
Triplay/
  package.json, capacitor.config.json   (App Name = Triplay, Package ID = com.ashitech.triplay)
  SETUP_WINDOWS.bat / SETUP_MAC_LINUX.sh
  www/  index.html  css/style.css  js/game.js        <- game
  android/                                           <- Android Studio me yahi open karna
    app/build.gradle  app/proguard-rules.pro  app/src/main/AndroidManifest.xml
    app/src/main/java/com/ashitech/triplay/MainActivity.java
    app/src/main/res/  (icons, splash, strings, styles)
  store_assets/  icon-512.png  feature-graphic-1024x500.png  privacy-policy.html
```
