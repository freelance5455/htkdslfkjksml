const button = document.querySelector('#check');
button.addEventListener('click', async () => {
  const status = document.querySelector('#status');
  const base = document.querySelector('#api').value.trim().replace(/\/$/, '');
  status.textContent = 'Checking…';
  try {
    const response = await fetch(`${base}/health`, { method: 'GET' });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data = await response.json();
    status.textContent = `Connected: ${data.service}; AI connected: ${data.ai_connected}`;
  } catch (error) {
    status.textContent = `Connection failed: ${error.message}. Start the backend and allow local network access.`;
  }
});
