package com.rima.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Ink = Color(0xFF32142D)
private val Muted = Color(0xFF966D87)
private val Coral = Color(0xFFFF6A3D)
private val Cream = Color(0xFFFFF0E9)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var ttsReady = false
    private val prefs by lazy { getSharedPreferences("rima_settings", MODE_PRIVATE) }
    private val askMic = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        log(if (granted) "Microphone permission granted" else "Microphone permission denied")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        if (SpeechRecognizer.isRecognitionAvailable(this)) speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        setContent { RimaApp(
            getVoice = { prefs.getString("voice", "hi-IN-female") ?: "hi-IN-female" },
            setVoice = { prefs.edit().putString("voice", it).apply(); log("Voice preference locked: $it") },
            getProvider = { prefs.getString("provider", "Gemini (backend needed)") ?: "Gemini (backend needed)" },
            setProvider = { prefs.edit().putString("provider", it).apply(); log("Provider preference changed") },
            getEndpoint = { prefs.getString("endpoint", "") ?: "" },
            setEndpoint = { prefs.edit().putString("endpoint", it).apply() },
            getMemory = { JSONArray(prefs.getString("memory", "[]") ?: "[]").let { a -> (0 until a.length()).map { a.optString(it) } } },
            addMemory = { note -> val a = JSONArray(prefs.getString("memory", "[]") ?: "[]"); a.put(note); prefs.edit().putString("memory", a.toString()).apply(); log("Local memory note added") },
            clearMemory = { prefs.edit().remove("memory").apply(); log("Local memory cleared") },
            getLogs = { JSONArray(prefs.getString("logs", "[]") ?: "[]").let { a -> (0 until a.length()).map { a.optString(it) }.reversed() } },
            clearLogs = { prefs.edit().putString("logs", "[]").apply() },
            speak = { speakHindi(it) },
            listen = { startListening() },
            micGranted = { ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED },
            requestMic = { askMic.launch(Manifest.permission.RECORD_AUDIO) },
            openApp = { target -> openSafeTarget(target) }
        ) }
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) {
            val result = tts?.setLanguage(Locale.forLanguageTag("hi-IN"))
            tts?.setSpeechRate(0.96f)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) log("Hindi TTS unavailable; install Hindi voice data")
        } else log("TTS initialization failed")
    }

    private fun speakHindi(text: String) {
        if (!ttsReady) { log("TTS is not ready"); return }
        val desired = prefs.getString("voice", "hi-IN-female")
        val voices = tts?.voices.orEmpty().filter { it.locale.language == "hi" }
        // Keep the chosen preference fixed; don't silently switch voices.
        val chosen = voices.firstOrNull { v -> desired == v.name || (desired == "hi-IN-female" && v.name.contains("female", true)) }
        if (chosen != null) tts?.voice = chosen
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "rima_reply")
    }

    private fun startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            askMic.launch(Manifest.permission.RECORD_AUDIO); return
        }
        val recognizer = speechRecognizer ?: run { log("Speech recognition is unavailable on this device"); return }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { log("Listening started") }
            override fun onResults(results: Bundle?) {
                val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (words.isNotBlank()) {
                    log("Recognized: $words")
                    val reply = when {
                        words.contains("समय") -> "माफ़ कीजिए, समय के लिए अपने फ़ोन की घड़ी देखें।"
                        words.contains("यूट्यूब") -> { openSafeTarget("YouTube"); "यूट्यूब खोलने का अनुरोध किया है।" }
                        words.contains("क्रोम") || words.contains("ब्राउज़र") -> { openSafeTarget("Browser"); "ब्राउज़र खोलने का अनुरोध किया है।" }
                        words.contains("नमस्ते") || words.contains("हेलो") -> "नमस्ते! मैं रीमा हूँ। बताइए, मैं आपकी क्या सहायता करूँ?"
                        else -> "मैंने सुना: $words। अभी एआई उत्तर सेवा कनेक्ट नहीं है। सेटिंग्स में सुरक्षित बैकएंड जोड़ें।"
                    }
                    speakHindi(reply)
                } else log("No speech recognized")
            }
            override fun onError(error: Int) { log("Speech recognition error: $error") }
            override fun onBeginningOfSpeech() {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { log("Listening ended") }
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onRmsChanged(rmsdB: Float) {}
        })
        recognizer.startListening(intent)
    }

    private fun openSafeTarget(target: String) {
        try {
            val intent = when (target) {
                "YouTube" -> packageManager.getLaunchIntentForPackage("com.google.android.youtube")
                "Browser" -> Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.google.com"))
                else -> null
            }
            if (intent != null) startActivity(intent) else log("$target app not found or unsupported")
        } catch (e: Exception) { log("Could not open $target: ${e.message}") }
    }

    private fun log(message: String) {
        val a = JSONArray(prefs.getString("logs", "[]") ?: "[]")
        val stamp = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        a.put("$stamp  $message")
        while (a.length() > 100) a.remove(0)
        prefs.edit().putString("logs", a.toString()).apply()
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
private fun RimaApp(
    getVoice: () -> String, setVoice: (String) -> Unit,
    getProvider: () -> String, setProvider: (String) -> Unit,
    getEndpoint: () -> String, setEndpoint: (String) -> Unit,
    getMemory: () -> List<String>, addMemory: (String) -> Unit, clearMemory: () -> Unit,
    getLogs: () -> List<String>, clearLogs: () -> Unit,
    speak: (String) -> Unit, listen: () -> Unit, micGranted: () -> Boolean,
    requestMic: () -> Unit, openApp: (String) -> Unit
) {
    var tab by remember { mutableStateOf("Home") }
    var voice by remember { mutableStateOf(getVoice()) }
    var provider by remember { mutableStateOf(getProvider()) }
    var endpoint by remember { mutableStateOf(getEndpoint()) }
    var note by remember { mutableStateOf("") }
    var memoryRefresh by remember { mutableIntStateOf(0) }
    var logsRefresh by remember { mutableIntStateOf(0) }
    MaterialTheme(colorScheme = lightColorScheme(primary = Coral, background = Cream, surface = Color(0xFFFFFAF7))) {
        Scaffold(containerColor = Cream, bottomBar = {
            NavigationBar(containerColor = Color(0xFFFFFAF7)) {
                listOf("Home", "Chat", "Settings", "Logs").forEach { item ->
                    NavigationBarItem(selected = tab == item, onClick = { tab = item }, icon = {
                        Text(when(item) { "Home" -> "⌂"; "Chat" -> "▤"; "Settings" -> "⚙"; else -> "◷" })
                    }, label = { Text(item) })
                }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)) {
                Text("RIMA", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, color = Ink)
                Text("Your Hindi AI companion", color = Muted)
                Spacer(Modifier.height(14.dp))
                when (tab) {
                    "Home" -> {
                        Text("Good evening!", style = MaterialTheme.typography.titleLarge, color = Ink)
                        Spacer(Modifier.height(6.dp))
                        Orb()
                        Text("RIMA • READY WHEN YOU ARE", modifier = Modifier.align(Alignment.CenterHorizontally), color = Muted, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { if (micGranted()) listen() else requestMic() }, modifier = Modifier.fillMaxWidth()) { Text("🎙  बोलने के लिए टैप करें") }
                        OutlinedButton(onClick = { speak("नमस्ते! मैं रीमा हूँ। मैं आपकी सहायता के लिए तैयार हूँ।") }, modifier = Modifier.fillMaxWidth()) { Text("आवाज़ जाँचें") }
                        Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                            Column(Modifier.padding(16.dp)) {
                                Text("Quick actions", fontWeight = FontWeight.Bold, color = Ink)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(onClick = { openApp("YouTube") }, modifier = Modifier.weight(1f)) { Text("YouTube") }
                                    OutlinedButton(onClick = { openApp("Browser") }, modifier = Modifier.weight(1f)) { Text("Browser") }
                                }
                            }
                        }
                        Text("AI answers need a backend connection. This starter never pretends that an API is connected.", color = Muted, style = MaterialTheme.typography.bodySmall)
                    }
                    "Chat" -> {
                        Text("Hindi conversation", style = MaterialTheme.typography.titleLarge, color = Ink)
                        Text("अभी स्थानीय वॉइस डेमो उपलब्ध है। वास्तविक एआई चैट के लिए बैकएंड जोड़ना बाकी है।", color = Muted)
                        Button(onClick = { speak("नमस्ते! मैं रीमा हूँ। वास्तविक एआई चैट सेवा अभी कनेक्ट नहीं है।") }) { Text("हिंदी में जवाब सुनें") }
                    }
                    "Settings" -> {
                        Text("Settings & Intelligence", style = MaterialTheme.typography.titleLarge, color = Ink)
                        Text("Voice preference is saved locally and will not silently change.", color = Muted)
                        Spacer(Modifier.height(8.dp))
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                            Column(Modifier.padding(14.dp)) {
                                Text("Hindi voice preference", fontWeight = FontWeight.Bold)
                                listOf("hi-IN-female", "hi-IN-default").forEach { v ->
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        RadioButton(selected = voice == v, onClick = { voice = v; setVoice(v) })
                                        Column {
                                            Text(if (v == "hi-IN-female") "Female Hindi (if installed)" else "Device Hindi default")
                                            Text(if (v == "hi-IN-female") "Android voice availability varies" else "No gender guarantee", color = Muted, style = MaterialTheme.typography.bodySmall)
                                        }
                                    }
                                }
                                Divider()
                                Text("AI provider", fontWeight = FontWeight.Bold)
                                listOf("Gemini (backend needed)", "Groq (backend needed)", "OpenAI-compatible backend").forEach { p ->
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        RadioButton(selected = provider == p, onClick = { provider = p; setProvider(p) })
                                        Text(p)
                                    }
                                }
                                OutlinedTextField(value = endpoint, onValueChange = { endpoint = it; setEndpoint(it) }, label = { Text("Backend HTTPS URL (optional)") }, modifier = Modifier.fillMaxWidth())
                                Text("API keys are intentionally not requested here. Never embed a production secret in the APK.", color = Muted, style = MaterialTheme.typography.bodySmall)
                                Spacer(Modifier.height(8.dp))
                                Text("Permissions", fontWeight = FontWeight.Bold)
                                Text("Microphone: ${if (micGranted()) "Granted" else "Not granted"}")
                                OutlinedButton(onClick = requestMic) { Text("Request microphone permission") }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                            Column(Modifier.padding(14.dp)) {
                                Text("Local memory bank", fontWeight = FontWeight.Bold)
                                OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("Add a non-sensitive note") }, modifier = Modifier.fillMaxWidth())
                                Button(onClick = { if (note.isNotBlank()) { addMemory(note.trim()); note = ""; memoryRefresh++ } }) { Text("Save note") }
                                key(memoryRefresh) {
                                    getMemory().forEach { Text("• $it", color = Ink) }
                                }
                                TextButton(onClick = { clearMemory(); memoryRefresh++ }) { Text("Clear memory") }
                            }
                        }
                    }
                    else -> {
                        Text("Local event logs", style = MaterialTheme.typography.titleLarge, color = Ink)
                        Text("Logs stay on this device; maximum 100 events.", color = Muted)
                        key(logsRefresh) {
                            LazyColumn(Modifier.weight(1f)) {
                                items(getLogs()) { item -> Text(item, modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp), color = Ink) }
                            }
                        }
                        OutlinedButton(onClick = { clearLogs(); logsRefresh++ }) { Text("Clear logs") }
                    }
                }
            }
        }
    }
}

@Composable
private fun Orb() {
    val transition = rememberInfiniteTransition(label = "orb")
    val pulse by transition.animateFloat(initialValue = 0.94f, targetValue = 1.06f, animationSpec = infiniteRepeatable(tween(1800), RepeatMode.Reverse), label = "pulse")
    Box(Modifier.fillMaxWidth().height(290.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(270.dp).scale(pulse)) {
            drawCircle(Brush.radialGradient(listOf(Color(0xFFFFB5CB), Color(0xFFF5D9F2), Color.Transparent)), radius = size.minDimension / 2)
            drawCircle(Color(0xFFB77CC8).copy(alpha = .55f), radius = size.minDimension * .43f, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.dp.toPx()))
            drawCircle(Brush.radialGradient(listOf(Color(0xFFFFF7FC), Color(0xFFF7B8D1), Color(0xFFDB83B2))), radius = size.minDimension * .34f)
            for (i in 0..160) {
                val angle = i * 2.399
                val r = size.minDimension * (.08f + (i % 31) / 100f)
                val x = center.x + kotlin.math.cos(angle).toFloat() * r
                val y = center.y + kotlin.math.sin(angle).toFloat() * r
                drawCircle(Color(0xFFAD477F).copy(alpha = .65f), radius = (i % 3 + 1).dp.toPx() / 2, center = androidx.compose.ui.geometry.Offset(x, y))
            }
        }
    }
}
