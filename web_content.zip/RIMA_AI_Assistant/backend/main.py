"""RIMA backend starter. AI provider calls are intentionally not implemented yet.
Run locally: python -m venv .venv && pip install -r requirements.txt
uvicorn main:app --host 127.0.0.1 --port 8000
"""
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import Literal

app = FastAPI(title="RIMA AI Assistant API", version="0.1.0")

class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=8000)
    language: Literal["hi-IN", "en-US", "auto"] = "hi-IN"

class ChatResponse(BaseModel):
    reply: str
    provider_status: str

@app.get("/health")
def health():
    return {"status": "ok", "service": "rima-api", "ai_connected": False}

@app.post("/api/chat", response_model=ChatResponse)
def chat(req: ChatRequest):
    # Deliberately fails honestly until a provider adapter is configured.
    raise HTTPException(status_code=503, detail="AI provider is not configured. Add a server-side provider adapter and environment-based secret before using chat.")

@app.get("/api/capabilities")
def capabilities():
    return {
        "implemented": ["health check", "request validation"],
        "not_implemented": ["provider chat adapter", "streaming audio", "weather", "web research", "user authentication", "database-backed memory"]
    }
