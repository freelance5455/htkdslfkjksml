# RIMA AI Assistant — Source Starter Pack

This ZIP contains a native Kotlin/Jetpack Compose Android starter, an optional Python FastAPI backend skeleton, a tiny HTML/CSS/JavaScript backend health dashboard, and a master build prompt/checklist.

## Honest status
- Android app source: starter implementation included; not compiled or device-tested in this environment.
- RIMA branding: included in Android UI.
- Hindi speech recognition/TTS: initial Android API integration included; exact voice availability depends on installed device voices.
- Voice preference persistence: preference is stored; a permanent identical voice across all devices cannot be guaranteed by Android. Missing selected voice must be surfaced rather than silently substituted.
- Orb: animated 2D Compose effect, not a true 3D model.
- Memory and logs: local SharedPreferences storage in this starter; not encrypted and not suitable for secrets.
- App shortcuts: limited to opening YouTube/browser via standard intents.
- AI chat: not connected. Provider name/endpoint fields are configuration placeholders only.
- Python backend: health endpoint works when run; `/api/chat` intentionally returns HTTP 503 until a server-side provider adapter is implemented.
- JavaScript dashboard: backend health-check UI only; it does not provide an AI chat service.
- Real weather, Gemini Live streaming, live web research, biometric protection, full Accessibility automation, encrypted database, authentication, auto-updates, and production API integration: not implemented or not verified.
- No APK is included or claimed to have been built.

## Android build
1. Install Android Studio, JDK 17, and Android SDK Platform 35.
2. Open the `RIMA_AI_Assistant` folder in Android Studio.
3. Let Gradle sync finish; resolve any SDK download prompts.
4. Connect an Android device with USB debugging enabled or start an emulator.
5. Click **Run** to install a debug build. To create an APK, choose **Build → Build APK(s)**. Android Studio will report the generated path only if the build succeeds.

## Optional Python backend (development only)
```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --host 127.0.0.1 --port 8000
```
Open `http://127.0.0.1:8000/health` to test. The chat endpoint is deliberately unconfigured. Do not expose this development server to the public internet.

## Optional JavaScript dashboard
Open `web-dashboard/index.html` in a browser and enter the backend URL. Browser access to localhost and CORS behavior may vary; configure CORS intentionally if serving the dashboard from a different origin.

See `MASTER_BUILD_PROMPT.md` for the full feature specification and acceptance checklist.
