# RIMA AI Assistant — Master Build Prompt

Build a production-minded **native Android app in Kotlin + Jetpack Compose** named RIMA, inspired by the supplied Jarvis screenshots but branded RIMA everywhere. Default conversation and speech output must be standard/pure Hindi (`hi-IN`) with a warm natural female voice when the device actually provides one. Preserve the user's exact voice selection across app restarts and updates; never silently switch voices. If unavailable, show an explicit error and let the user choose another voice.

## Architecture
- Android client: Kotlin, Jetpack Compose, Android SpeechRecognizer/TTS, DataStore or encrypted storage where appropriate.
- Optional backend: Python FastAPI, provider adapters kept server-side, secrets supplied via environment variables, authentication and rate limits before production.
- Optional developer dashboard: plain HTML/CSS/JavaScript; never put provider secrets in browser storage.
- Keep app UI and backend capabilities separate. Do not label a capability “working” unless implemented and tested.

## Required screens
1. Home: RIMA logo, animated orb, listen/stop, status, weather only when a real weather service is connected, shortcuts.
2. Chat: Hindi conversation, text input, mic input, cancel/interrupt, retry, timestamps and clear-chat.
3. Settings: voice lock, language, speech speed/volume, provider/model, backend URL, connection test, API usage/error status.
4. Memory: list/search/edit/delete/export user-approved memories; opt-in saving; avoid sensitive data by default.
5. Permissions: real runtime permission state and Android settings links; never claim a permission is granted based on UI state alone.
6. Phone control: allowlisted intents for opening apps/websites and media. For SMS/calls, create a reviewable draft or explicit confirmation; do not send silently.
7. Activity logs: local event log, redact secrets, clear/export controls.
8. Privacy/security: data controls, deletion, privacy explanation, biometric gate for sensitive settings where supported, no hidden recording.
9. Updates/About: app version, changelog, update checks only when a real update service exists.
10. Prompt/code library: searchable categories and copy-all control if included.

## Safe automation rules
- Use official Android intents and permission-gated APIs. Accessibility automation must be opt-in, visibly enabled by the user, limited to user-requested actions, and documented. Never bypass device security, lock screens, account protections, or permission prompts.
- Foreground microphone use must be visible and stoppable. Respect Android background execution and notification requirements.
- Use HTTPS for remote services. Do not hard-code keys in the APK. Add request timeouts, error handling, redacted logs, and retry limits.

## Acceptance tests
- Voice preference survives app restart and no silent fallback occurs.
- Hindi voice availability is detected and explained accurately.
- Denied microphone permission produces a clear recovery path.
- Backend health check distinguishes reachable API from configured AI provider.
- Memory can be added, viewed, and deleted.
- Browser/YouTube shortcuts either open successfully or show a clear error.
- No UI falsely claims weather, AI, 3D, biometric, automation, or update features are active when they are not.
- Build debug APK and test on a real Android device; record SDK, device, Android version, and results.

## Delivery requirements
Deliver full source, setup steps, environment template, test checklist, and a list of implemented / partial / not implemented functions. Do not claim an APK is built, an API is connected, or features are verified without evidence from a successful build/test.
