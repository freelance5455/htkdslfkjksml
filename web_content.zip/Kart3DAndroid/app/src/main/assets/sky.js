// سماء ذكية: قبة سماء + غيوم + دورة نهار/غروب + مدير طقس + مزاج الشمس
import * as THREE from 'three';
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const sm = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t) };
const D2R = Math.PI / 180;

// ارتفاع الشمس (بالدرجات) أول السباق ← آخره لكل مسار
const ARC = { canyon: [16, -2], classic: [32, 58], snow: [42, 50], tunnel: [52, 30], beach: [58, 66] };
const DUR = 240;

export const Sky = {
  elev: 40, az: 0, dir: new THREE.Vector3(0, 1, 0), ldir: new THREE.Vector3(.4, .8, .3).normalize(),
  lit: 1, warm: 0, night: 0, sunCol: new THREE.Color(0xffffff),
  mood: 'happy', look: { x: 0, y: -1 }, ex: { sm: 1, op: 0, br: 0, lid: 0, sh: 0 }
};
const MOODS = {
  happy: { sm: 1, op: 0, br: 0, lid: 0, sh: 0 }, thrill: { sm: 1, op: 1, br: .5, lid: 0, sh: 0 },
  cool: { sm: .7, op: 0, br: 0, lid: 0, sh: 1 }, sad: { sm: -1, op: 0, br: -.6, lid: .25, sh: 0 },
  shock: { sm: 0, op: 1, br: .8, lid: 0, sh: 0 }, sleepy: { sm: .2, op: 0, br: 0, lid: .75, sh: 0 }
};

let dome, domeMat, clouds = [], cloudMat, cam, theme = 'classic', az0 = 0, hold = 0;
const _a = new THREE.Color(0xff9a55), _n = new THREE.Color(0x141a38), _w = new THREE.Color(0xffffff), _z = new THREE.Color(0x2f78c8);
const _v = new THREE.Vector3(), _s = new THREE.Vector3();

function cloudTex() {
  const c = document.createElement('canvas'); c.width = 512; c.height = 256; const g = c.getContext('2d');
  for (let k = 0; k < 4; k++) {
    const ox = (k % 2) * 256, oy = (k >> 1) * 128;
    for (let i = 0; i < 16; i++) {
      const x = ox + 40 + Math.random() * 176, y = oy + 52 + Math.random() * 30 - Math.abs(x - ox - 128) * .12, r = 22 + Math.random() * 26;
      const gr = g.createRadialGradient(x, y, 0, x, y, r); gr.addColorStop(0, 'rgba(255,255,255,.9)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
      g.fillStyle = gr; g.fillRect(x - r, y - r, r * 2, r * 2);
    }
  }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}

export function init(scene, camera) {
  cam = camera;
  domeMat = new THREE.ShaderMaterial({
    side: THREE.BackSide, depthWrite: false, depthTest: false, fog: false,
    uniforms: { hor: { value: new THREE.Color() }, zen: { value: new THREE.Color() }, sd: { value: new THREE.Vector3(0, 1, 0) }, sc: { value: new THREE.Color() }, nt: { value: 0 }, cl: { value: 0 } },
    vertexShader: 'varying vec3 vP;void main(){vP=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);gl_Position.z=gl_Position.w;}',
    fragmentShader: `uniform vec3 hor,zen,sd,sc;uniform float nt,cl;varying vec3 vP;
float h(vec3 p){return fract(sin(dot(p,vec3(12.9898,78.233,37.719)))*43758.5453);}
void main(){vec3 d=normalize(vP);float y=max(d.y,0.);vec3 c=mix(hor,zen,pow(y,.5));
float s=max(dot(d,sd),0.);c+=sc*(pow(s,700.)*2.5+pow(s,24.)*.5*(1.-cl)+pow(s,5.)*.14*(1.-cl));
float st=step(.9968,h(floor(d*150.)))*nt*smoothstep(.08,.45,d.y)*(1.-cl);c+=vec3(st);
c=mix(hor,c,smoothstep(-.04,.1,d.y));gl_FragColor=vec4(c,1.);
#include <tonemapping_fragment>
#include <colorspace_fragment>
}`
  });
  dome = new THREE.Mesh(new THREE.SphereGeometry(300, 24, 16), domeMat); dome.renderOrder = -10; dome.frustumCulled = false; scene.add(dome);
  cloudMat = new THREE.SpriteMaterial({ map: cloudTex(), fog: false, depthWrite: false, transparent: true, opacity: .8 });
  for (let i = 0; i < 24; i++) {
    const m = cloudMat.clone(); m.map = cloudMat.map.clone(); m.map.needsUpdate = true; m.map.repeat.set(.5, .5); m.map.offset.set((i % 2) * .5, ((i >> 1) % 2) * .5);
    const s = new THREE.Sprite(m); const w = 80 + Math.random() * 70; s.scale.set(w, w * .5, 1);
    s.userData = { a: Math.random() * 6.283, r: 120 + Math.random() * 170, y: 85 + Math.random() * 60, k: i / 24, sp: .6 + Math.random() * .8 };
    s.renderOrder = -5; scene.add(s); clouds.push(s);
  }
}

// عند بناء المسار: الشمس تبدأ أمام اللاعب قليلًا لليسار كما في الواجهة السابقة
export function reset(T, startHeading) { theme = T.id; az0 = startHeading - .3; hold = 0; Sky.mood = 'happy'; Object.assign(Sky.ex, MOODS.happy) }

// مصبوغ لون الأفق حسب الغروب/الليل قبل تأثير الطقس
export function tint(base, out) {
  out.copy(base); out.lerp(_a, Sky.warm * .55); out.lerp(_n, Sky.night * .85); return out;
}

export function update(dt, t, c) {
  const arc = ARC[theme] || ARC.classic, p = clamp(c.raceT / DUR, 0, 1);
  Sky.elev = arc[0] + (arc[1] - arc[0]) * p; Sky.az = az0 + c.raceT * .004;
  const e = Sky.elev * D2R, ce = Math.cos(e);
  Sky.dir.set(Math.sin(Sky.az) * ce, Math.sin(e), Math.cos(Sky.az) * ce);
  // اتجاه الضوء: لا ينزل تحت 32° كي تبقى دقة الظلال سليمة
  const le = Math.max(e, 32 * D2R), lc = Math.cos(le); Sky.ldir.set(Math.sin(Sky.az) * lc, Math.sin(le), Math.cos(Sky.az) * lc);
  const day = sm(2, 24, Sky.elev); Sky.warm = (1 - day) * sm(-8, 3, Sky.elev); Sky.night = 1 - sm(-8, 2, Sky.elev); Sky.lit = .12 + .88 * sm(-6, 18, Sky.elev);
  Sky.sunCol.copy(_w).lerp(_a, Sky.warm * .8);

  // مدير الطقس: غيوم + لون القبة
  const W = c.W, g = clamp(W.cloud * .55 + W.rain * .25 + W.storm * .35, 0, 1), fog = c.scene.fog ? c.scene.fog.color : _w;
  const u = domeMat.uniforms; u.hor.value.copy(fog);
  u.zen.value.copy(fog).lerp(_z, (1 - g) * day * .55).lerp(_n, Sky.night * .8 + W.storm * .35);
  u.sd.value.copy(Sky.dir); u.sc.value.copy(Sky.sunCol); u.nt.value = Sky.night; u.cl.value = clamp(W.cloud * 1.1, 0, 1);
  dome.position.copy(cam.position);
  const n = Math.round(24 * clamp(.22 + W.cloud * .78, 0, 1)), tc = _w.clone().lerp(_a, Sky.warm * .7).lerp(_n, Sky.night * .6).multiplyScalar(1 - .6 * W.storm - .2 * W.rain);
  clouds.forEach((s, i) => {
    const d = s.userData; s.visible = i < n && c.tun < .4; if (!s.visible) return;
    const a = d.a + t * .004 * d.sp; s.position.set(cam.position.x + Math.sin(a) * d.r, d.y, cam.position.z + Math.cos(a) * d.r);
    s.material.color.copy(tc); s.material.opacity = (.45 + .5 * W.cloud) * (i < 5 ? .7 : 1);
  });

  // ذكاء الشمس: اختيار المزاج
  let m = 'happy';
  if (c.spin > 0) { m = 'shock'; hold = 1.2 }
  else if (hold > 0) { hold -= dt; m = 'shock' }
  else if (W.storm > .1 || W.rain > .25) m = 'sad';
  else if (Sky.elev < 8) m = 'sleepy';
  else if (c.boost > 0 || (c.rank <= 1 && c.raceT > 3)) m = 'thrill';
  else if (W.cloud < .3 && Sky.elev > 38) m = 'cool';
  Sky.mood = m; const tg = MOODS[m], k = 1 - Math.exp(-6 * dt);
  for (const q in tg) Sky.ex[q] += (tg[q] - Sky.ex[q]) * k;
  // العينان تتبعان كارت اللاعب
  _s.copy(Sky.dir).multiplyScalar(300).add(cam.position).project(cam); _v.copy(c.player).project(cam);
  const dx = _v.x - _s.x, dy = _v.y - _s.y, L = Math.hypot(dx, dy) || 1;
  Sky.look.x += (dx / L - Sky.look.x) * k; Sky.look.y += (dy / L - Sky.look.y) * k;
}

// طقس موجَّه: يختار التالي حسب المسار ومركز اللاعب (المتصدر يواجه جوًا أصعب، والمتأخر يُمنح صحوًا)
const NEXT = { clear: ['cloudy'], cloudy: ['clear', 'rain'], rain: ['cloudy', 'storm'], storm: ['rain'] };
const TW = { beach: { rain: .4, storm: .3 }, snow: { rain: .8, storm: .6 }, canyon: { rain: .5, storm: .5 } };
export function nextWeather(cur, c) {
  const o = NEXT[cur], tw = TW[c.theme] || {}, lead = c.rank <= 2, back = c.rank >= c.n - 2;
  const w = o.map(s => {
    let v = 1; const bad = s === 'rain' || s === 'storm';
    if (bad) v *= (tw[s] ?? 1) * (lead ? 1.6 : back ? .5 : 1) * (c.lap >= c.laps ? 1.3 : 1);
    else if (back) v *= 1.6;
    return v;
  });
  let r = Math.random() * w.reduce((a, b) => a + b, 0);
  for (let i = 0; i < o.length; i++) { r -= w[i]; if (r <= 0) return o[i] }
  return o[0];
}
