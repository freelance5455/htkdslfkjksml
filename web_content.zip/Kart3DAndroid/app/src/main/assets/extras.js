// إضافات: سائق متحرك + كلام + شمس بوجه + ملابس + سيارات + تفاصيل العوالم
import * as THREE from 'three';
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const V = (x, y, z) => new THREE.Vector3(x, y, z);
export const OUTFITS = [
  { n: 'أصلي' },
  { n: 'أحمر', c: 0xd32f2f, p: 0x263238, s: 0xffffff, hat: 'cap', hc: 0xd32f2f },
  { n: 'بحّار', c: 0x1565c0, p: 0xf5f5f5, s: 0x3e2723, hat: 'sailor', hc: 0xffffff },
  { n: 'أخضر', c: 0x2e7d32, p: 0x5d4037, s: 0xffd600, hat: 'helmet', hc: 0x1b5e20 },
  { n: 'ملكي', c: 0xffb300, p: 0x6a1b9a, s: 0x6a1b9a, hat: 'crown', hc: 0xffd600 },
  { n: 'نينجا', c: 0x212121, p: 0x212121, s: 0xb71c1c, hat: 'band', hc: 0xc62828 }
];
export const CARS = ['كارت', 'سيارة سباق', 'شاحنة وحش', 'سيارة فضائية'];

// ---------- السائق: عجلة قيادة + أيدي + رأس + فم ----------
export const Talk = { on: false, wave: 0, t: 0, idle: 6, pb: false, ps: false, pr: 1, pl: 1, pw: 'clear', el: null, started: false };
export function dress(g, oi, ci) {
  const roll = g.userData.roll, m = roll.getObjectByName('world'); if (!m) return;
  const Z = V(0, 0, 0), N = n => m.getObjectByName(n), o = OUTFITS[oi] || OUTFITS[0];
  const col = (ns, c) => ns.forEach(n => { const q = N(n); if (q && q.material && q.material.color) q.material.color.set(c) });
  if (o.c != null) { col(['character_body', 'arm', 'arm_1'], o.c); col(['leg', 'leg_1'], o.p); col(['shoe', 'shoe_1'], o.s) }
  const ctr = n => { const q = N(n); q.geometry.computeBoundingBox(); return q.geometry.boundingBox.getCenter(V(0, 0, 0)) };
  const wrap = (par, pp, names, p) => { const w = new THREE.Group(); w.position.copy(p).sub(pp); par.add(w); names.forEach(n => { const q = N(n); if (q) { q.position.copy(p).negate(); w.add(q) } }); return w };
  const HC = ctr('head'), MC = ctr('mouth'), BC = ctr('character_body');
  // تجميع السائق حول مركز المقعد ثم تصغيره كوحدة واحدة؛ الملابس والرأس والأطراف تبقى متناسقة.
  const bodyG = wrap(m, Z, ['character_body'], BC);
  const headG = wrap(m, Z, ['head', 'ear', 'ear_1', 'hair', 'hair_1', 'hair_2', 'hair_3', 'muzzle', 'nose', 'eye_white', 'pupil', 'eye_white_1', 'pupil_1', 'mouth', 'tooth', 'tooth_1', 'tooth_2', 'tooth_3'], HC);
  const mouthG = wrap(headG, HC, ['mouth', 'tooth', 'tooth_1', 'tooth_2', 'tooth_3'], MC);
  const armL = wrap(m, Z, ['arm'], V(-.045, .55, 2.55)), armR = wrap(m, Z, ['arm_1'], V(.045, .55, 2.55));
  const wheel = wrap(m, Z, ['steering_wheel'], ctr('steering_wheel'));
  const wheels = [['tire', 'hub'], ['tire_1', 'hub_1'], ['tire_2', 'hub_2'], ['tire_3', 'hub_3']].map(p => N(p[0]) ? wrap(m, Z, p, ctr(p[0])) : null).filter(Boolean);
  const legs = [['leg', 'shoe'], ['leg_1', 'shoe_1']].map(p => wrap(m, Z, p, ctr(p[0])));
  const fitRoot = new THREE.Group(); fitRoot.name = 'driver_fit'; fitRoot.position.copy(BC); m.add(fitRoot);
  for (const part of [bodyG, headG, armL, armR, wheel, ...legs]) { const p = part.position.clone(); fitRoot.add(part); part.position.copy(p.sub(BC)) }
  fitRoot.scale.setScalar(.82);
  // قبعات
  const M = (c, e) => new THREE.MeshStandardMaterial({ color: c, roughness: .6, emissive: e || 0 });
  const hatG = new THREE.Group(); headG.add(hatG);
  const headMesh = N('head'); headMesh.geometry.computeBoundingBox();
  const headDims = headMesh.geometry.boundingBox.getSize(V(0, 0, 0));
  const hatFit = clamp(Math.max(headDims.x, headDims.y, headDims.z) / 1.78, .86, 1.12); hatG.scale.setScalar(hatFit);
  const add = (geo, c, x, y, z, rx) => { const q = new THREE.Mesh(geo, M(c)); q.position.set(x, y, z); if (rx) q.rotation.x = rx; q.castShadow = true; hatG.add(q); return q };
  const H = Math.PI / 2;
  if (o.hat === 'cap') { add(new THREE.CylinderGeometry(.88, .9, .32, 18), o.hc, 0, 0, .92, H); add(new THREE.BoxGeometry(.9, .7, .08), o.hc, 0, .85, .8) }
  if (o.hat === 'sailor') { add(new THREE.CylinderGeometry(.82, .86, .38, 18), o.hc, 0, 0, .95, H); add(new THREE.CylinderGeometry(.84, .84, .1, 18), 0x1565c0, 0, 0, .8, H) }
  if (o.hat === 'helmet') add(new THREE.SphereGeometry(.98, 18, 10, 0, Math.PI * 2, 0, H), o.hc, 0, 0, .28, H);
  if (o.hat === 'crown') { add(new THREE.CylinderGeometry(.72, .78, .4, 14), o.hc, 0, 0, .98, H); for (let i = 0; i < 5; i++) { const a = i * Math.PI * 2 / 5; add(new THREE.ConeGeometry(.16, .4, 6), o.hc, Math.cos(a) * .72, Math.sin(a) * .72, 1.35, H) } }
  if (o.hat === 'band') { const b = add(new THREE.CylinderGeometry(.83, .83, .2, 18, 1, true), o.hc, 0, 0, .38, H); b.material.side = THREE.DoubleSide }
  // سيارات
  const pivot = roll.children[0], sc = pivot && pivot.scale ? pivot.scale.x : 1;
  const A = (geo, c, x, y, z, e) => { const q = new THREE.Mesh(geo, e === 'b' ? new THREE.MeshBasicMaterial({ color: c }) : M(c, e)); q.position.set(x, y, z); q.castShadow = true; roll.add(q); return q };
  if (ci === 1) { pivot.scale.multiply(V(1.1, .85, 1)); A(new THREE.BoxGeometry(1.8, .08, .5), 0x222222, 0, 1.0, -1.05); A(new THREE.BoxGeometry(.08, .45, .08), 0x222222, .6, .78, -1.05); A(new THREE.BoxGeometry(.08, .45, .08), 0x222222, -.6, .78, -1.05); A(new THREE.BoxGeometry(2, .06, .5), 0xf5f5f5, 0, .2, 1.35) }
  if (ci === 2) { pivot.position.y += .32; wheels.forEach(w => w.scale.setScalar(1.45)); A(new THREE.BoxGeometry(.08, .8, .08), 0x333333, .75, 1.8, -.4); A(new THREE.BoxGeometry(.08, .8, .08), 0x333333, -.75, 1.8, -.4); A(new THREE.BoxGeometry(1.6, .08, .08), 0x333333, 0, 2.2, -.4); for (let i = -1.5; i <= 1.5; i += 1) A(new THREE.SphereGeometry(.1, 8, 6), 0xffee88, i * .45, 2.3, -.4, 'b') }
  if (ci === 3) { col(['kart_body'], 0x26c6da); const gl = new THREE.Mesh(new THREE.TorusGeometry(1, .07, 8, 28), new THREE.MeshBasicMaterial({ color: 0x00e5ff })); gl.rotation.x = H; gl.position.y = .12; roll.add(gl); A(new THREE.ConeGeometry(.2, .9, 4), 0x00e5ff, .85, .6, -1.15, 0x0097a7).rotation.x = -H; A(new THREE.ConeGeometry(.2, .9, 4), 0x00e5ff, -.85, .6, -1.15, 0x0097a7).rotation.x = -H;
    const dome = new THREE.Mesh(new THREE.SphereGeometry(1.15, 14, 10), new THREE.MeshBasicMaterial({ color: 0x9be7ff, transparent: true, opacity: .2, depthWrite: false })); dome.position.set(0, 1.2, -.1); roll.add(dome) }
  g.userData.rig = { wheels, legs, armL, armR, wheel, headG, mouthG, sc };
}
export function anim(k, dt, t) {
  const r = k.g.userData.rig; if (!r || !(dt > 0)) return;
  const s = clamp(k.sa || 0, -.6, .6), v = Math.max(0, k.speed), f = Math.min(1, dt * 14), P = k.isP;
  r.wheel.rotation.y += (s * 2.2 - r.wheel.rotation.y) * f;
  const bob = Math.sin(t * 13 + k.phase) * .05 * (.3 + v / 24), wv = P && Talk.wave > 0;
  r.armL.rotation.y = r.wheel.rotation.y * .45 + bob;
  r.armR.rotation.y = wv ? -.95 + Math.sin(t * 15) * .45 : r.wheel.rotation.y * .45 - bob;
  r.headG.rotation.z = -s * 1.6 + Math.sin(t * 1.7 + k.phase) * .1;
  r.headG.rotation.x = Math.sin(t * 11 + k.phase) * .025 * (v / 24);
  const mt = P && Talk.on, tg = mt ? .45 + Math.abs(Math.sin(t * 17)) * (.6 + .5 * Math.sin(t * 6.1)) : 1;
  r.mouthG.scale.z += (tg - r.mouthG.scale.z) * Math.min(1, dt * 30);
  r.legs.forEach((leg, i) => { leg.rotation.x = Math.sin(t * 13 + k.phase + i * Math.PI) * .025 * Math.min(1, v / 8) });
  const sp = v * dt / (.68 * r.sc); for (const w of r.wheels) w.rotation.x -= sp;
}

// ---------- كلام السائق ----------
const L = {
  start: ['يلا نسابق! أنا جاهز!', 'اليوم سأفوز، شدّوا الأحزمة!'],
  boost: ['نيترو! ههههه', 'طيّارة مو سيارة!', 'يا سلام على هالسرعة!'],
  hit: ['آآآه! مين رمى هذي؟', 'يا ويلي، دوّخني!'],
  lead: ['أنا الأول! ما أحد يلحقني!', 'الصدارة لي!'],
  lose: ['لا لا لا، راح أرجع لهم!', 'اتركوني أتجاوزكم!'],
  lap: ['لفة جديدة! كمّلوا!', 'ما أحلى هالحلبة!'],
  rain: ['المطر نزل! انتبهوا، الطريق زلق', 'ياي، الجو ممطر!'],
  storm: ['عاصفة! الله يستر!'],
  clear: ['الشمس رجعت تبتسم لنا!'],
  idle: ['أحب قيادة السيارات!', 'هذي سيارتي المفضلة', 'شو أحلى من السباق؟', 'تأمّلوا الشمس، تبتسم لنا!', 'أنا سائق ماهر، صح؟', 'سمعتوا العصافير؟ ما أجمل الجو!', 'ثبّتوا عجلة القيادة، هذي منعطف!', 'ما في أسرع مني اليوم'],
  tun: ['واو، نفق! الصوت يتردد هنا', 'الإنارة جميلة داخل النفق!'], out: ['طلعنا من النفق، يا سلام الشمس!']
};
const pk = a => a[Math.floor(Math.random() * a.length)];
export function initTalk() {
  const e = document.createElement('div'); e.id = 'talk';
  e.style.cssText = 'position:fixed;z-index:11;top:54px;left:50%;transform:translateX(-50%);background:#fff;color:#222;padding:7px 16px;border-radius:18px;font-weight:bold;font-size:15px;opacity:0;transition:opacity .2s;pointer-events:none;max-width:60vw;direction:rtl;box-shadow:0 3px 12px #0006';
  document.body.appendChild(e); Talk.el = e;
}
export const Voice = { ctx: null, dest: null, on: true };
const FORM = [[800, 1200], [300, 2300], [350, 800], [500, 1000], [400, 1900]];
// أصوات رد فعل قصيرة ومختلفة الطبقة لتمييز السائقين الآليين عن محرك اللاعب.
export function racerSfx(kind, rank = 2) {
  const c = Voice.ctx, dest = Voice.dest;
  if (!c || !dest) return;
  const base = (kind === 'hit' ? 390 : kind === 'boost' ? 620 : 500) + (3 - rank) * 36;
  const notes = kind === 'hit' ? [[1, .12, .8], [.72, .17, .65]] : [[1, .08, .7], [1.28, .11, .55]];
  let at = c.currentTime + .01;
  for (const [mul, dur, vol] of notes) {
    const o = c.createOscillator(), f = c.createBiquadFilter(), g = c.createGain();
    o.type = 'sawtooth'; o.frequency.setValueAtTime(base * mul * 1.18, at); o.frequency.exponentialRampToValueAtTime(Math.max(90, base * mul * .82), at + dur);
    f.type = 'bandpass'; f.frequency.value = kind === 'hit' ? 780 : 1150; f.Q.value = 1.2;
    g.gain.setValueAtTime(.0001, at); g.gain.linearRampToValueAtTime(.085 * vol, at + .018); g.gain.exponentialRampToValueAtTime(.0001, at + dur);
    o.connect(f); f.connect(g); g.connect(dest); o.start(at); o.stop(at + dur + .02); at += dur * .72;
  }
}
function babble(text) {   // صوت كرتوني مولَّد: يعمل دائمًا حتى بدون محرك نطق عربي
  const c = Voice.ctx; if (!c || !Voice.dest) return;
  const n = Math.max(4, Math.min(26, Math.round(text.length * .6))); let t = c.currentTime + .03; const base = 250 + Math.random() * 40;
  for (let i = 0; i < n; i++) {
    const f0 = base * (1 + .28 * Math.sin(i * .85) + (Math.random() - .5) * .18) * (i === n - 1 ? .8 : 1), fm = FORM[Math.floor(Math.random() * 5)], d = .075 + Math.random() * .06;
    const o = c.createOscillator(); o.type = 'sawtooth'; o.frequency.setValueAtTime(f0 * 1.06, t); o.frequency.linearRampToValueAtTime(f0, t + d);
    const g = c.createGain(); g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(.55, t + .018); g.gain.linearRampToValueAtTime(0, t + d);
    for (const fr of fm) { const bp = c.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = fr; bp.Q.value = 7; const pg = c.createGain(); pg.gain.value = fr === fm[0] ? 1 : .6; o.connect(bp); bp.connect(pg); pg.connect(g) }
    g.connect(Voice.dest); o.start(t); o.stop(t + d + .02); t += d + (i % 4 === 3 ? .07 : .02);
  }
}
function speak(text) {
  let ok = false;
  try { if (window.AndroidBridge && window.AndroidBridge.speak) ok = window.AndroidBridge.speak(text, 1.35, 1.0) } catch (e) { }
  if (ok) return;
  try {
    const vs = window.speechSynthesis && speechSynthesis.getVoices ? speechSynthesis.getVoices() : [];
    if (vs.some(v => /^ar/i.test(v.lang))) { const u = new SpeechSynthesisUtterance(text); u.lang = 'ar-SA'; u.pitch = 1.4; u.rate = 1.05; speechSynthesis.cancel(); speechSynthesis.speak(u); return }
  } catch (e) { }
  babble(text);
}
export function say(text, snd) {
  Talk.el.textContent = '💬 ' + text; Talk.el.style.opacity = 1;
  Talk.t = .8 + text.length * .075; Talk.on = true; Talk.wave = 1.3; Talk.idle = 5 + Math.random() * 3;
  if (snd && Voice.on) speak(text);
}
export function tick(dt, p) {
  if (!Talk.el) return;
  if (Talk.t > 0) { Talk.t -= dt; if (Talk.t <= 0) { Talk.on = false; Talk.el.style.opacity = 0 } }
  if (Talk.wave > 0) Talk.wave -= dt;
  if (!p.race) { Talk.started = false; return }
  if (!Talk.started) { Talk.started = true; Talk.pb = p.boost; Talk.ps = p.spin; Talk.pr = p.rank; Talk.pl = p.lap; Talk.pw = p.wx; Talk.pt = p.tun; say(pk(L.start), p.sound); return }
  let l = null;
  if (p.spin && !Talk.ps) l = L.hit; else if (p.boost && !Talk.pb) l = L.boost;
  else if (p.rank === 1 && Talk.pr > 1) l = L.lead; else if (p.rank > Talk.pr && p.rank > 2) l = L.lose;
  else if (p.lap !== Talk.pl) l = L.lap; else if (p.tun && !Talk.pt) l = L.tun; else if (!p.tun && Talk.pt) l = L.out; else if (p.wx !== Talk.pw && L[p.wx]) l = L[p.wx];
  Talk.pb = p.boost; Talk.ps = p.spin; Talk.pr = p.rank; Talk.pl = p.lap; Talk.pw = p.wx; Talk.pt = p.tun;
  Talk.idle -= dt;
  if (!l && Talk.idle <= 0 && !Talk.on) l = L.idle;
  if (l && (!Talk.on || l !== L.idle)) say(pk(l), p.sound);
}

// ---------- الشمس بعين وفم (تعبيرات يقودها ذكاء السماء) ----------
let sun = null, sunParts = null; const _d = V(0, 0, 0);
export function initSky(scene) {
  const B = (c, o) => new THREE.MeshBasicMaterial(Object.assign({ color: c, fog: false, depthWrite: false }, o || {}));
  const g = new THREE.Group(), face = new THREE.Group(), rays = new THREE.Group(); g.add(rays, face);
  const circ = (r, c, x, y, z, o, par) => { const q = new THREE.Mesh(new THREE.CircleGeometry(r, 32), B(c, o)); q.position.set(x, y, z); (par || face).add(q); return q };
  const glow = circ(40, 0xffb300, 0, 0, -.5, { transparent: true, opacity: .28 });
  circ(26, 0xffd21f, 0, 0, 0);
  for (let i = 0; i < 12; i++) { const a = i * Math.PI / 6, q = new THREE.Mesh(new THREE.ConeGeometry(4.2, 15, 3), B(0xffa000)); q.position.set(Math.cos(a) * 36, Math.sin(a) * 36, -.2); q.rotation.z = a - Math.PI / 2; rays.add(q) }
  const eyes = [], pup = [], brows = [];
  for (const sx of [-1, 1]) {
    const e = new THREE.Group(); e.position.set(sx * 9, 6, .5); face.add(e); circ(5.2, 0xffffff, 0, 0, 0, null, e); pup.push(circ(2.7, 0x111111, 0, 0, .1, null, e)); eyes.push(e); circ(4.2, 0xff6f6f, sx * 16, -4, .3, { transparent: true, opacity: .55 });
    const br = new THREE.Mesh(new THREE.PlaneGeometry(9, 1.8), B(0x7a2a00)); br.position.set(sx * 9, 14, .7); br.userData.sx = sx; face.add(br); brows.push(br);
  }
  const shades = new THREE.Group(); shades.position.z = 1.2; face.add(shades);
  for (const sx of [-1, 1]) { const l = new THREE.Mesh(new THREE.CircleGeometry(7, 20), B(0x111111)); l.position.set(sx * 9, 6, 0); l.scale.y = .8; shades.add(l) }
  const bridge = new THREE.Mesh(new THREE.PlaneGeometry(6, 1.6), B(0x111111)); bridge.position.set(0, 7, 0); shades.add(bridge);
  const mouth = new THREE.Mesh(new THREE.TorusGeometry(10, 1.5, 8, 24, Math.PI), B(0x7a2a00)); mouth.position.set(0, -4, .6); mouth.rotation.z = Math.PI; face.add(mouth);
  const open = new THREE.Mesh(new THREE.CircleGeometry(7, 20), B(0x5a1500)); open.position.set(0, -9, .55); face.add(open);
  g.scale.setScalar(.85); g.renderOrder = -1; scene.add(g); sun = g; sunParts = { rays, eyes, pup, mouth, open, brows, shades, glow };
}
export function skyTick(dt, t, W, camera, K) {
  if (!sun) return;
  const vis = clamp(1 - W.cloud * 1.15, 0, 1); sun.visible = vis > .04 && K.elev > -3;
  _d.copy(K.dir).multiplyScalar(300);
  sun.position.copy(camera.position).add(_d); sun.quaternion.copy(camera.quaternion);
  sun.scale.setScalar(.85 * (.55 + .45 * vis) * (1 + .25 * clamp(1 - K.elev / 30, 0, 1)));
  const P = sunParts, x = K.ex;
  P.rays.rotation.z = t * (.3 + .5 * x.op);
  P.glow.material.opacity = .28 + .12 * Math.sin(t * 2.2) * x.op;
  P.mouth.scale.y = x.sm; P.mouth.position.y = x.sm < 0 ? -14 : -4; P.mouth.visible = x.op < .6;
  P.open.visible = x.op > .08; P.open.scale.set(.6 + .4 * x.op, .15 + .85 * x.op, 1);
  const bl = (Math.sin(t * 1.9 + Math.sin(t * .7) * 3) > .965 ? .1 : 1) * (1 - x.lid * .85); P.eyes.forEach(e => e.scale.y = Math.max(.08, bl));
  P.brows.forEach(b => { b.rotation.z = -b.userData.sx * x.br * .45; b.position.y = 14 + x.br * 2 });
  P.shades.visible = x.sh > .05; P.shades.scale.setScalar(.4 + .6 * x.sh);
  P.pup.forEach(p => p.position.set(K.look.x * 1.9, K.look.y * 1.6 - .3, .1));
}

// ---------- تفاصيل العوالم ----------
function groundTex() {
  const c = document.createElement('canvas'); c.width = c.height = 512; const g = c.getContext('2d'); g.fillStyle = '#ececec'; g.fillRect(0, 0, 512, 512);
  for (let i = 0; i < 8500; i++) { const v = 200 + Math.random() * 55 | 0; g.fillStyle = `rgb(${v},${v},${v})`; g.fillRect(Math.random() * 512, Math.random() * 512, 1 + Math.random() * 4, 1 + Math.random() * 4) }
  const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(110, 110); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; return t;
}
let roadsideLife = null;
const lifeObj = new THREE.Object3D(), lifeEuler = new THREE.Euler(0, 0, 0, 'YXZ');
function lifeInst(world, geo, count) {
  const m = new THREE.InstancedMesh(geo, new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: .86 }), count);
  m.count = count; m.castShadow = true; m.receiveShadow = false; m.frustumCulled = false; m.userData.dyn = true; world.add(m); return m;
}
function lifeMatrix(m, i, x, y, z, yaw, sx, sy, sz, rx = 0) {
  lifeObj.position.set(x, y, z); lifeEuler.set(rx, yaw, 0, 'YXZ'); lifeObj.rotation.copy(lifeEuler); lifeObj.scale.set(sx, sy, sz); lifeObj.updateMatrix(); m.setMatrixAt(i, lifeObj.matrix);
}
function buildRoadsideLife(x) {
  const { world, T, pts, N, DS, R, HALF, WALLOFF } = x, humanN = 36, animalN = 24;
  const person = {
    body: lifeInst(world, new THREE.CylinderGeometry(.29, .36, .86, 7), humanN),
    head: lifeInst(world, new THREE.SphereGeometry(.27, 8, 6), humanN),
    arm: lifeInst(world, new THREE.CylinderGeometry(.095, .12, .62, 5), humanN * 2),
    leg: lifeInst(world, new THREE.CylinderGeometry(.12, .14, .66, 5), humanN * 2)
  };
  const skin = [0xffd0a1, 0xc68650, 0xe7ad7a, 0x9b5f3d];
  const clothes = [0xe53935, 0x1e88e5, 0x43a047, 0xffb300, 0x8e24aa, 0xffffff];
  const people = Array.from({ length: humanN }, (_, i) => {
    let p = R() * N, tries = 0;
    while (T.tunnels && T.tunnels.some(([a, b]) => p >= a * N && p <= b * N) && tries++ < 30) p = R() * N;
    person.body.setColorAt(i, new THREE.Color(clothes[Math.floor(R() * clothes.length)]));
    person.head.setColorAt(i, new THREE.Color(skin[Math.floor(R() * skin.length)]));
    for (let k = 0; k < 2; k++) { person.arm.setColorAt(i * 2 + k, new THREE.Color(skin[(i + k) % skin.length])); person.leg.setColorAt(i * 2 + k, new THREE.Color(0x28323d)) }
    return { p, side: i % 2 ? 1 : -1, lane: HALF + WALLOFF + 3.5 + R() * 2.8, dir: R() < .5 ? -1 : 1, speed: .32 + R() * .55, phase: R() * Math.PI * 2, wave: R() }
  });
  const animalTone = T.theme === 'snow' ? 0xe9e0d4 : T.theme === 'beach' ? 0x55a86a : T.theme === 'canyon' ? 0xb58a58 : T.theme === 'tunnel' ? 0x8b7762 : 0xa26e43;
  const animal = {
    body: lifeInst(world, new THREE.SphereGeometry(1, 9, 7), animalN),
    shell: T.theme === 'beach' ? lifeInst(world, new THREE.SphereGeometry(1, 9, 6), animalN) : null,
    head: lifeInst(world, new THREE.SphereGeometry(.34, 8, 6), animalN),
    ear: lifeInst(world, new THREE.ConeGeometry(.14, .48, 5), animalN * 2),
    leg: lifeInst(world, new THREE.CylinderGeometry(.09, .12, .42, 5), animalN * 4),
    tail: lifeInst(world, new THREE.SphereGeometry(.17, 6, 5), animalN)
  };
  for (let i = 0; i < animalN; i++) {
    animal.body.setColorAt(i, new THREE.Color(animalTone)); animal.head.setColorAt(i, new THREE.Color(animalTone));
    animal.ear.setColorAt(i * 2, new THREE.Color(T.theme === 'snow' ? 0xd5c7b9 : animalTone)); animal.ear.setColorAt(i * 2 + 1, new THREE.Color(T.theme === 'snow' ? 0xd5c7b9 : animalTone));
    animal.tail.setColorAt(i, new THREE.Color(T.theme === 'snow' ? 0xb5a99d : 0x6c4c32));
    for (let k = 0; k < 4; k++) animal.leg.setColorAt(i * 4 + k, new THREE.Color(animalTone));
    if (animal.shell) animal.shell.setColorAt(i, new THREE.Color(0x8a5d3b));
  }
  for (const m of Object.values(person)) if (m.instanceColor) m.instanceColor.needsUpdate = true;
  for (const m of Object.values(animal)) if (m && m.instanceColor) m.instanceColor.needsUpdate = true;
  const creatures = Array.from({ length: animalN }, (_, i) => {
    let p = R() * N, tries = 0;
    while (T.tunnels && T.tunnels.some(([a, b]) => p >= a * N && p <= b * N) && tries++ < 30) p = R() * N;
    return { p, side: i % 2 ? 1 : -1, lane: HALF + WALLOFF + 6 + R() * 7, dir: R() < .5 ? -1 : 1, speed: .45 + R() * .7, phase: R() * Math.PI * 2 }
  });
  const sample = p => { p = ((p % N) + N) % N; const i = Math.floor(p), f = p - i, a = pts[i], b = pts[(i + 1) % N]; let tx = a.tx + (b.tx - a.tx) * f, tz = a.tz + (b.tz - a.tz) * f, l = Math.hypot(tx, tz) || 1; return { x: a.x + (b.x - a.x) * f, z: a.z + (b.z - a.z) * f, nx: a.nx + (b.nx - a.nx) * f, nz: a.nz + (b.nz - a.nz) * f, tx: tx / l, tz: tz / l } };
  const avoidTunnel = (p, dir) => {
    if (T.tunnels) for (const [a, b] of T.tunnels) { const lo = a * N, hi = b * N; if (p >= lo && p <= hi) p = dir > 0 ? hi + 2 : lo - 2 }
    return ((p % N) + N) % N;
  };
  return { person, people, animal, creatures, DS, N, theme: T.theme, sample, avoidTunnel };
}
export function lifeTick(dt, t) {
  const l = roadsideLife; if (!l) return;
  const { person, people, animal, creatures, DS, N, theme, sample, avoidTunnel } = l;
  for (let i = 0; i < people.length; i++) {
    const q = people[i]; q.p = avoidTunnel(q.p + q.dir * q.speed * dt / DS, q.dir);
    const p = sample(q.p), yaw = Math.atan2(p.tx, p.tz) + (q.dir < 0 ? Math.PI : 0), x = p.x + p.nx * q.side * q.lane, z = p.z + p.nz * q.side * q.lane, ph = t * 4 + q.phase;
    const bob = Math.abs(Math.sin(ph)) * .045;
    lifeMatrix(person.body, i, x, 1.12 + bob, z, yaw, 1, 1, 1);
    lifeMatrix(person.head, i, x, 1.76 + bob, z, yaw, 1, 1, 1);
    for (let k = 0; k < 2; k++) {
      const s = k ? 1 : -1, swing = Math.sin(ph + k * Math.PI) * .36;
      lifeMatrix(person.arm, i * 2 + k, x + p.nx * s * .39, 1.18 + bob, z + p.nz * s * .39, yaw, 1, 1, 1, swing + (q.wave > .75 && Math.sin(ph * .7) > .4 ? -.55 : 0));
      lifeMatrix(person.leg, i * 2 + k, x + p.nx * s * .16, .43 + bob, z + p.nz * s * .16, yaw, 1, 1, 1, -swing * .75);
    }
  }
  for (let i = 0; i < creatures.length; i++) {
    const q = creatures[i]; q.p = avoidTunnel(q.p + q.dir * q.speed * dt / DS, q.dir);
    const p = sample(q.p), yaw = Math.atan2(p.tx, p.tz) + (q.dir < 0 ? Math.PI : 0), x = p.x + p.nx * q.side * q.lane, z = p.z + p.nz * q.side * q.lane, ph = t * 5 + q.phase;
    const bob = Math.max(0, Math.sin(ph)) * .035;
    lifeMatrix(animal.body, i, x, .55 + bob, z, yaw, .68, .43, .98);
    if (animal.shell) lifeMatrix(animal.shell, i, x, .78 + bob, z - .04, yaw, .53, .24, .72);
    lifeMatrix(animal.head, i, x + p.tx * .77, .67 + bob, z + p.tz * .77, yaw, .9, .85, 1);
    for (let k = 0; k < 2; k++) lifeMatrix(animal.ear, i * 2 + k, x + p.nx * (k ? .19 : -.19) + p.tx * .88, .98 + bob, z + p.nz * (k ? .19 : -.19) + p.tz * .88, yaw, 1, theme === 'beach' ? .45 : 1.1, 1, (k ? 1 : -1) * .12);
    for (let k = 0; k < 4; k++) { const side = k % 2 ? 1 : -1, front = k < 2 ? 1 : -1; lifeMatrix(animal.leg, i * 4 + k, x + p.nx * side * .4 + p.tx * front * .55, .27 + bob, z + p.nz * side * .4 + p.tz * front * .55, yaw, 1, 1, 1, Math.sin(ph + k * Math.PI / 2) * .18) }
    lifeMatrix(animal.tail, i, x - p.tx, .72 + bob, z - p.tz, yaw, 1, 1, 1);
  }
  for (const m of Object.values(person)) m.instanceMatrix.needsUpdate = true;
  for (const m of Object.values(animal)) if (m) m.instanceMatrix.needsUpdate = true;
}
export function decor(x) {
  const { world, T, pts, N, R, scatter, dmin, inst, put, done, groundMat, HALF, WALLOFF, DS } = x, th = T.theme;
  const S = THREE.SphereGeometry, C = THREE.CylinderGeometry, K = THREE.ConeGeometry, B = THREE.BoxGeometry;
  groundMat.map = groundTex(); groundMat.needsUpdate = true; Tun.rng = null; if (T.tunnels) tunnel(x);
  // أعمدة إنارة على جانبي الطريق
  { const st = Math.max(3, Math.round(26 / DS)), n = Math.ceil(N / st) * 2, po = inst(n, new C(.12, .16, 4.2, 6), 0, true), bu = inst(n, new S(.38, 8, 6), 0, false);
    for (let i = 0; i < N; i += st) for (const sd of [-1, 1]) { const p = pts[i], d = HALF + WALLOFF + 1.4; put(po, p.x + p.nx * sd * d, 2.1, p.z + p.nz * sd * d, 0, 1, 1, 1, 0x3a4048); put(bu, p.x + p.nx * sd * d, 4.4, p.z + p.nz * sd * d, 0, 1, 1, 1, 0xfff0a0) }
    done(po); done(bu) }
  // غيوم
  { const n = 26, cl = inst(n * 5, new S(1, 8, 6), 0, false);
    for (let i = 0; i < n; i++) { const a = R() * 6.28, d = 60 + R() * 150, cx = Math.cos(a) * d, cz = Math.sin(a) * d, cy = 42 + R() * 28;
      for (let j = 0; j < 5; j++) { const s = 6 + R() * 6; put(cl, cx + (j - 2) * 7 + R() * 3, cy + R() * 2, cz + R() * 4, 0, s * 1.3, s * .6, s, 0xffffff) } }
    done(cl) }
  const pond = (cnt, col) => { const L = scatter(cnt, dmin + 4, 50), pd = inst(L.length, new C(1, 1, .05, 20), 0, false); L.forEach(([a, b]) => put(pd, a, .02, b, 0, 5 + R() * 7, 1, 5 + R() * 7, col)); done(pd) };
  if (th === 'classic') {
    const L = scatter(16, dmin + 8, 45), wl = inst(L.length, new B(4.4, 3.2, 4.4), 0, true), rf = inst(L.length, new K(3.7, 2.4, 4), 0, true);
    L.forEach(([a, b]) => { const y = R() * 6; put(wl, a, 1.6, b, y, 1, 1, 1, [0xf5e6c8, 0xe8b4b4, 0xb7d7e8][Math.floor(R() * 3)]); put(rf, a, 4.4, b, y + Math.PI / 4, 1, 1, 1, 0xb23a2e) }); done(wl); done(rf);
    const F = scatter(180, HALF + WALLOFF + 1.5, 16), fl = inst(F.length, new S(.3, 6, 5), 0, false); F.forEach(([a, b]) => put(fl, a, .3, b, 0, 1, 1, 1, [0xff6f91, 0xffd54f, 0xffffff, 0xba68c8][Math.floor(R() * 4)])); done(fl);
    const Bs = scatter(70, dmin, 30), bs = inst(Bs.length, new S(1.2, 8, 6), 0, true); Bs.forEach(([a, b]) => put(bs, a, .8, b, 0, 1, .8, 1, 0x2f7a3a)); done(bs); pond(5, 0x3aa8e0);
  }
  if (th === 'canyon') {
    const L = scatter(46, dmin, 50), tk = inst(L.length, new C(.45, .55, 3.4, 8), 0, true), ar = inst(L.length * 2, new C(.28, .3, 1.5, 6), 0, true);
    L.forEach(([a, b]) => { const s = .8 + R() * .7; put(tk, a, 1.7 * s, b, 0, s, s, s, 0x3f8a4a); put(ar, a + .7 * s, 2.3 * s, b, 0, s, s, s, 0x3f8a4a); put(ar, a - .7 * s, 1.9 * s, b, 0, s, s, s, 0x3f8a4a) }); done(tk); done(ar);
    const Bs = scatter(60, dmin - 2, 40), bs = inst(Bs.length, new S(.9, 6, 5), 0, true); Bs.forEach(([a, b]) => put(bs, a, .5, b, 0, 1, .6, 1, 0x9a7b45)); done(bs);
  }
  if (th === 'snow') {
    const L = scatter(100, dmin, 48), tr = inst(L.length, new C(.3, .45, 2, 6), 0, false), c1 = inst(L.length, new K(2.2, 3, 8), 0, true), c2 = inst(L.length, new K(1.6, 2.6, 8), 0, true), c3 = inst(L.length, new K(1, 2, 8), 0, true);
    L.forEach(([a, b]) => { const s = .8 + R() * .8; put(tr, a, s, b, 0, s, s, s, 0x5d4037); put(c1, a, 3.2 * s, b, 0, s, s, s, 0x2e6b4a); put(c2, a, 5 * s, b, 0, s, s, s, 0xe8f1f5); put(c3, a, 6.8 * s, b, 0, s, s, s, 0xffffff) }); done(tr); done(c1); done(c2); done(c3);
    const Sm = scatter(14, dmin - 2, 34), b1 = inst(Sm.length, new S(1.1, 10, 8), 0, true), b2 = inst(Sm.length, new S(.8, 10, 8), 0, true), b3 = inst(Sm.length, new S(.55, 10, 8), 0, true), cr = inst(Sm.length, new K(.12, .7, 6), 0, false);
    Sm.forEach(([a, b]) => { const y = R() * 6; put(b1, a, 1.1, b, 0, 1, 1, 1, 0xffffff); put(b2, a, 2.6, b, 0, 1, 1, 1, 0xffffff); put(b3, a, 3.7, b, 0, 1, 1, 1, 0xffffff); put(cr, a + Math.sin(y) * .5, 3.7, b + Math.cos(y) * .5, y, 1, 1, 1, 0xff7a1a) }); done(b1); done(b2); done(b3); done(cr);
    const Ic = scatter(60, dmin - 2, 44), ic = inst(Ic.length, new THREE.IcosahedronGeometry(1, 0), 0, true); Ic.forEach(([a, b]) => { const s = .6 + R() * 1.6; put(ic, a, s * .6, b, R() * 6, s, s * 1.3, s, 0xa9d6f0) }); done(ic);
    const M = scatter(14, HALF + WALLOFF + 40, 90), mt = inst(M.length, new K(1, 1, 9), 0, true); M.forEach(([a, b]) => { const r = 14 + R() * 12, h = 26 + R() * 24; put(mt, a, h / 2, b, R() * 6, r, h, r, 0xf4f8fb) }); done(mt);
  }
  if (th === 'tunnel') {
    const L = scatter(90, 30, 44), tr = inst(L.length, new C(.3, .45, 2.2, 6), 0, false), c1 = inst(L.length, new K(2.1, 3.6, 8), 0, true), c2 = inst(L.length, new K(1.5, 3, 8), 0, true);
    L.forEach(([a, b]) => { const s = .8 + R() * .9; put(tr, a, 1.1 * s, b, 0, s, s, s, 0x5d4037); put(c1, a, 3.6 * s, b, 0, s, s, s, 0x24593a); put(c2, a, 5.7 * s, b, 0, s, s, s, 0x2f6e44) }); done(tr); done(c1); done(c2);
    const Rk = scatter(70, 28, 40), rk = inst(Rk.length, new THREE.DodecahedronGeometry(1, 0), 0, true); Rk.forEach(([a, b]) => { const s = .9 + R() * 2.2; put(rk, a, s * .5, b, R() * 6, s, s * .8, s * (.7 + R() * .6), R() < .5 ? 0x7d8288 : 0x646a72) }); done(rk);
    const M = scatter(18, 60, 110), mt = inst(M.length, new K(1, 1, 7), 0, true); M.forEach(([a, b]) => { const r = 18 + R() * 16, h = 34 + R() * 40; put(mt, a, h / 2, b, R() * 6, r, h, r, R() < .5 ? 0x7b8794 : 0x6a7684) }); done(mt);
    const sp = scatter(26, 24, 30), sg = inst(sp.length, new B(.3, .3, .3), 0, false); sp.forEach(([a, b]) => put(sg, a, .15, b, 0, 1, 1, 1, 0xff7043)); done(sg);
  }
  if (th === 'beach') {
    const L = scatter(70, dmin, 48), tk = inst(L.length, new C(.28, .4, 6, 7), 0, true), cr = inst(L.length, new S(1, 8, 6), 0, true), lf = inst(L.length * 3, new K(2.6, .5, 5), 0, true);
    L.forEach(([a, b]) => { const s = .8 + R() * .5, y = R() * 6; put(tk, a, 3 * s, b, 0, s, s, s, 0x8d6e43); put(cr, a, 6.2 * s, b, 0, 2.4 * s, .55 * s, 2.4 * s, 0x2e9e4f); for (let q = 0; q < 3; q++) put(lf, a, 6.5 * s, b, y + q * 1.05, s, s, s * 1.5, 0x3fb24f) }); done(tk); done(cr); done(lf);
    const U = scatter(18, dmin - 2, 28), po = inst(U.length, new C(.07, .07, 2.8, 5), 0, true), cp = inst(U.length, new K(1.9, .9, 10), 0, true);
    U.forEach(([a, b]) => { put(po, a, 1.4, b, 0, 1, 1, 1, 0xffffff); put(cp, a, 3, b, R() * 6, 1, 1, 1, R() < .5 ? 0xe53935 : 0xffd600) }); done(po); done(cp);
    const Cs = scatter(14, dmin - 3, 36), cs = inst(Cs.length, new K(1.5, 2.2, 8), 0, true); Cs.forEach(([a, b]) => put(cs, a, 1.1, b, 0, 1, 1, 1, 0xd9bf80)); done(cs);
    const Bl = scatter(12, HALF + WALLOFF + 2, 22), bl = inst(Bl.length, new S(.8, 10, 8), 0, true); Bl.forEach(([a, b]) => put(bl, a, .8, b, 0, 1, 1, 1, [0xff5252, 0x40c4ff, 0xffeb3b][Math.floor(R() * 3)])); done(bl);
    pond(8, 0x35b6e8);
    const sea = new THREE.Mesh(new THREE.RingGeometry(215, 620, 48), new THREE.MeshStandardMaterial({ color: 0x1fa3d8, roughness: .25, metalness: .1 })); sea.rotation.x = -Math.PI / 2; sea.position.y = -.08; world.add(sea);
  }
  roadsideLife = buildRoadsideLife(x);
}

// ================= النفق (تصميم متكامل) =================
export const Tun = { amt: 0, tg: 0 };
const PROF = (() => { const P = [[-11.4, 0]]; for (let k = 0; k <= 16; k++) { const a = Math.PI - Math.PI * k / 16; P.push([11.4 * Math.cos(a), 3.5 + 9.5 * Math.sin(a)]) } P.push([11.4, 0]); return P })();
const OUT = PROF.map(([x, y]) => [x * 1.85, Math.max(-.1, y * 1.4 - .1)]);
function build(pos, nor, col, idx, mat) {   // يضبط اتجاه كل مثلث ليواجه الناظم (إضاءة صحيحة)
  for (let k = 0; k < idx.length; k += 3) {
    const a = idx[k] * 3, b = idx[k + 1] * 3, c = idx[k + 2] * 3;
    const ux = pos[b] - pos[a], uy = pos[b + 1] - pos[a + 1], uz = pos[b + 2] - pos[a + 2], vx = pos[c] - pos[a], vy = pos[c + 1] - pos[a + 1], vz = pos[c + 2] - pos[a + 2];
    if ((uy * vz - uz * vy) * nor[a] + (uz * vx - ux * vz) * nor[a + 1] + (ux * vy - uy * vx) * nor[a + 2] < 0) { const t = idx[k + 1]; idx[k + 1] = idx[k + 2]; idx[k + 2] = t }
  }
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute('normal', new THREE.Float32BufferAttribute(nor, 3)); if (col) g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3)); g.setIndex(idx);
  const m = new THREE.Mesh(g, mat); m.frustumCulled = false; return m;
}
function shell(pts, N, a, b, rows, nf, cf, mat) {
  const pos = [], nor = [], col = [], idx = [], R = rows.length, c = new THREE.Color();
  for (let i = a; i < b; i++) {
    const base = pos.length / 3;
    for (const p of [pts[i % N], pts[(i + 1) % N]]) for (let j = 0; j < R; j++) { const r = rows[j], n = nf(j, r); pos.push(p.x + p.nx * r[0], r[1], p.z + p.nz * r[0]); nor.push(p.nx * n[0], n[1], p.nz * n[0]); c.set(cf(i, j, r)); col.push(c.r, c.g, c.b) }
    for (let j = 0; j < R - 1; j++) { const v = base + j; idx.push(v, v + 1, v + R, v + 1, v + R + 1, v + R) }
  }
  return build(pos, nor, col, idx, mat);
}
function signTex(txt, bg, fg) {
  const c = document.createElement('canvas'); c.width = 512; c.height = 112; const g = c.getContext('2d');
  g.fillStyle = bg; g.fillRect(0, 0, 512, 112); g.strokeStyle = fg; g.lineWidth = 6; g.strokeRect(6, 6, 500, 100);
  g.fillStyle = fg; g.font = 'bold 58px Arial'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(txt, 256, 58);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}
export function tunnel(x) {
  const { world, T, pts, N, DS } = x, any = T.tunnels; if (!any) return;
  const nI = (j, r) => { const cy = clamp(r[1], 0, 3.5), dx = -r[0], dy = cy - r[1], l = Math.hypot(dx, dy) || 1; return [dx / l, dy / l] };
  const nO = (j, r) => { const dx = r[0] / 441, dy = r[1] / 330, l = Math.hypot(dx, dy) || 1; return [dx / l, dy / l] };
  const mIn = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: .8, metalness: .05 }), mOut = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 1, flatShading: true });
  const mLed = new THREE.MeshBasicMaterial({ color: 0x35e6ff }), mAmb = new THREE.MeshBasicMaterial({ color: 0xffb347 });
  const rock = new THREE.Color(0x777b82), grass = new THREE.Color(0x587a4c), cc = new THREE.Color();
  for (const [fa, fb] of any) {
    const a = Math.round(fa * N), b = Math.round(fb * N); Tun.rng = Tun.rng || []; Tun.rng.push([a, b]);
    // الجدار الداخلي مع ألواح متبادلة
    const ins = shell(pts, N, a, b, PROF, nI, (i, j, r) => r[1] < 3.6 ? (Math.floor(i * DS / 6) % 2 ? 0x707a85 : 0x66707b) : (Math.floor(i * DS / 7) % 2 ? 0xb4bcc4 : 0xa3acb5), mIn);
    world.add(ins);
    // الجبل من الخارج (تدرّج صخر ← عشب)
    const mound = shell(pts, N, a, b, OUT, nO, (i, j, r) => { cc.copy(rock).lerp(grass, clamp(r[1] / 16, 0, 1)); const h = ((i * 73 + j * 37) % 11) / 11 - .5; return cc.clone().multiplyScalar(1 + h * .22).getHex() }, mOut);
    world.add(mound);
    // واجهتا المدخل والمخرج
    for (const [ri, sg] of [[a, -1], [b, 1]]) {
      const p = pts[ri % N], pos = [], nor = [], idx = [];
      for (let j = 0; j < PROF.length; j++) for (const r of [PROF[j], OUT[j]]) { pos.push(p.x + p.nx * r[0], r[1], p.z + p.nz * r[0]); nor.push(sg * p.tx, 0, sg * p.tz) }
      for (let j = 0; j < PROF.length - 1; j++) { const v = j * 2; idx.push(v, v + 1, v + 2, v + 1, v + 3, v + 2) }
      const fc = build(pos, nor, null, idx, new THREE.MeshStandardMaterial({ color: 0xc8cdd2, roughness: .9 })); world.add(fc);
    }
    // لافتة المدخل
    { const p = pts[a % N], sn = new THREE.Mesh(new THREE.PlaneGeometry(12, 2.6), new THREE.MeshBasicMaterial({ map: signTex('نفق الجبل  TUNNEL', '#1b2a3a', '#ffd400') }));
      sn.position.set(p.x - p.tx * .25, 14.8, p.z - p.tz * .25); sn.rotation.y = Math.atan2(-p.tx, -p.tz); world.add(sn);
      const q = pts[(b - 14) % N], ex = new THREE.Mesh(new THREE.PlaneGeometry(7, 1.6), new THREE.MeshBasicMaterial({ map: signTex('المخرج  EXIT', '#0b6b2f', '#ffffff') }));
      ex.position.set(q.x, 10.2, q.z); ex.rotation.y = Math.atan2(-q.tx, -q.tz); world.add(ex);
      const hang = new THREE.Mesh(new THREE.BoxGeometry(.1, 2, .1), new THREE.MeshBasicMaterial({ color: 0x333333 })); hang.position.set(q.x, 11.6, q.z); world.add(hang) }
    // شريط LED على الجدران
    for (const sd of [-1, 1]) world.add(shell(pts, N, a, b, [[sd * 11.3, 2.9], [sd * 11.3, 3.3]], () => [-sd, 0], () => sd > 0 ? 0x35e6ff : 0xff4fd8, new THREE.MeshBasicMaterial({ vertexColors: true })));
    // مصابيح السقف (متوهجة) + عواكس جانبية
    const st = Math.max(2, Math.round(7 / DS)), cnt = Math.ceil((b - a) / st), lm = new THREE.InstancedMesh(new THREE.BoxGeometry(.5, .14, 2.8), new THREE.MeshBasicMaterial({ color: 0xfff2c4 }), cnt * 2), rf = new THREE.InstancedMesh(new THREE.BoxGeometry(.3, .3, .9), new THREE.MeshBasicMaterial({ color: 0xffffff }), cnt * 2), m4 = new THREE.Matrix4(), e = new THREE.Euler(), qq = new THREE.Quaternion(), vv = new THREE.Vector3(), sv = new THREE.Vector3(1, 1, 1);
    let k = 0, k2 = 0; for (let i = a + 1; i < b - 1; i += st) for (const sd of [-1, 1]) { const p = pts[i % N], yaw = Math.atan2(p.tx, p.tz); qq.setFromEuler(e.set(0, yaw, 0));
      m4.compose(vv.set(p.x + p.nx * sd * 4.6, 12.1, p.z + p.nz * sd * 4.6), qq, sv); lm.setMatrixAt(k++, m4);
      m4.compose(vv.set(p.x + p.nx * sd * 11.1, 1.7, p.z + p.nz * sd * 11.1), qq, sv); rf.setMatrixAt(k2, m4); rf.setColorAt(k2++, cc.set(Math.floor(i / st) % 2 ? 0xff8a1f : 0xff3b30)) }
    lm.count = k; rf.count = k2; lm.instanceMatrix.needsUpdate = true; rf.instanceMatrix.needsUpdate = true; if (rf.instanceColor) rf.instanceColor.needsUpdate = true; world.add(lm, rf);
  }
}
export function tunTick(dt, idx, N) {
  let t = 0; if (Tun.rng) for (const [a, b] of Tun.rng) if (idx >= a && idx <= b) t = Math.max(t, clamp(Math.min(idx - a, b - idx) / 5, 0, 1));
  Tun.tg = t; Tun.amt += (t - Tun.amt) * Math.min(1, dt * 4);
}

// ================= الطيور وزقزقتها =================
let birds = null; const _f = V(0, 0, 0), _r = V(0, 0, 0);
export function initBirds(scene) {
  const bm = new THREE.MeshBasicMaterial({ color: 0x20262e }), wm = new THREE.MeshBasicMaterial({ color: 0x2b323c, side: THREE.DoubleSide }), bg = new THREE.SphereGeometry(.3, 8, 6);
  bg.scale(1, .9, 2.4); const wg = new THREE.PlaneGeometry(2.1, .85); wg.rotateX(-Math.PI / 2); wg.translate(1.05, 0, 0);
  const g = new THREE.Group(); g.visible = false; scene.add(g); birds = { g, list: [] };
  for (let i = 0; i < 10; i++) { const b = new THREE.Group(), body = new THREE.Mesh(bg, bm), wl = new THREE.Mesh(wg, wm), wr = new THREE.Mesh(wg, wm); wl.scale.x = -1; wl.position.y = wr.position.y = .1; b.add(body, wl, wr); g.add(b); birds.list.push({ b, wl, wr, f: i % 2, k: Math.floor(i / 2), ph: Math.random() * 6 }) }
}
export function birdsTick(dt, t, camera, hide) {
  if (!birds) return; birds.g.visible = !hide; if (hide) return;
  _f.set(0, 0, -1).applyQuaternion(camera.quaternion); _f.y = 0; _f.normalize(); _r.set(-_f.z, 0, _f.x);
  for (const o of birds.list) {
    const s = o.f ? -1 : 1, u = ((t * (6.5 + o.f * 1.5) + o.f * 150) % 320) - 160, side = o.k % 2 ? 1 : -1, j = Math.ceil(o.k / 2);
    const lat = (u - j * 3.1) * s, fw = (85 + o.f * 22) + side * j * 2.4, up = 27 + o.f * 9 + Math.sin(t * .5 + o.f * 2) * 3 + Math.sin(t * 2 + o.ph) * .6;
    o.b.position.set(camera.position.x + _f.x * fw + _r.x * lat, camera.position.y + up - 6, camera.position.z + _f.z * fw + _r.z * lat);
    o.b.rotation.y = Math.atan2(_r.x * s, _r.z * s); o.b.rotation.z = Math.sin(t * 2 + o.ph) * .08;
    const fl = Math.sin(t * 11 + o.ph) * .75; o.wr.rotation.z = fl; o.wl.rotation.z = -fl;
  }
}
let chT = 2;
export function birdSound(dt, ctx, dest, on) {
  if (!ctx || !on) return; chT -= dt; if (chT > 0) return; chT = 1.1 + Math.random() * 3;
  const bursts = 1 + Math.floor(Math.random() * 3), pan = ctx.createStereoPanner ? ctx.createStereoPanner() : null; if (pan) { pan.pan.value = Math.random() * 1.6 - .8; pan.connect(dest) }
  let t = ctx.currentTime + .02; const base = 2300 + Math.random() * 1800, out = pan || dest;
  for (let b = 0; b < bursts; b++) { const n = 2 + Math.floor(Math.random() * 4); for (let i = 0; i < n; i++) {
    const f = base * (1 + (Math.random() - .5) * .35), d = .05 + Math.random() * .05, o = ctx.createOscillator(), g = ctx.createGain(); o.type = 'sine';
    o.frequency.setValueAtTime(f, t); o.frequency.exponentialRampToValueAtTime(f * (Math.random() < .5 ? 1.45 : .7), t + d);
    g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(.04, t + .012); g.gain.linearRampToValueAtTime(0, t + d); o.connect(g); g.connect(out); o.start(t); o.stop(t + d + .02); t += d + .035 } t += .16 }
}

// ================= موسيقى السباق =================
export function music(ctx, dest, st) {
  const bus = ctx.createGain(); bus.gain.value = .8; const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 12000;
  const dl = ctx.createDelay(1); dl.delayTime.value = .3; const fb = ctx.createGain(); fb.gain.value = .36; const wet = ctx.createGain(); wet.gain.value = .1;
  bus.connect(lp); lp.connect(dest); lp.connect(dl); dl.connect(fb); fb.connect(dl); dl.connect(wet); wet.connect(dest);
  const F = (type, f) => { const q = ctx.createBiquadFilter(); q.type = type; q.frequency.value = f; q.connect(bus); return q }, bassF = F('lowpass', 650), leadF = F('lowpass', 4200), padF = F('lowpass', 1400), arpF = F('lowpass', 3000);
  const nb = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate), nd = nb.getChannelData(0); for (let i = 0; i < nd.length; i++) nd[i] = Math.random() * 2 - 1;
  const bpm = 140, s16 = 60 / bpm / 4, hz = n => 440 * Math.pow(2, (n - 69) / 12);
  const note = (f, t, d, type, v, to, det) => { const o = ctx.createOscillator(), g = ctx.createGain(); o.type = type; o.frequency.value = f; if (det) o.detune.value = det; g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(v, t + .008); g.gain.setValueAtTime(v, t + Math.max(.01, d * .6)); g.gain.linearRampToValueAtTime(0, t + d); o.connect(g); g.connect(to); o.start(t); o.stop(t + d + .02) };
  const noise = (t, d, ft, fq, v) => { const s = ctx.createBufferSource(); s.buffer = nb; const f = ctx.createBiquadFilter(); f.type = ft; f.frequency.value = fq; const g = ctx.createGain(); g.gain.setValueAtTime(v, t); g.gain.exponentialRampToValueAtTime(.001, t + d); s.connect(f); f.connect(g); g.connect(bus); s.start(t, Math.random() * .5, d + .02) };
  const kick = t => { const o = ctx.createOscillator(), g = ctx.createGain(); o.frequency.setValueAtTime(160, t); o.frequency.exponentialRampToValueAtTime(42, t + .13); g.gain.setValueAtTime(.5, t); g.gain.exponentialRampToValueAtTime(.001, t + .22); o.connect(g); g.connect(bus); o.start(t); o.stop(t + .25) };
  const ROOT = [45, 41, 48, 43, 45, 41, 43, 40], CH = [[57, 60, 64], [53, 57, 60], [60, 64, 67], [55, 59, 62], [57, 60, 64], [53, 57, 60], [55, 59, 62], [56, 59, 64]], BP = [0, 0, 12, 0, 0, 0, 12, 7];
  const MEL = [[76, 0, 76, 72, 74, 0, 72, 69], [77, 0, 77, 74, 72, 0, 69, 72], [79, 0, 76, 79, 84, 0, 79, 76], [74, 0, 74, 71, 67, 71, 74, 0], [81, 0, 76, 0, 72, 76, 81, 0], [77, 0, 72, 0, 69, 72, 77, 0], [74, 76, 79, 0, 83, 79, 74, 0], [80, 0, 76, 0, 71, 74, 76, 0]];
  const play = (step, t) => {
    const bar = Math.floor(step / 16) % 8, s = step % 16;
    if (s % 4 === 0 || (s === 10 && bar % 2)) kick(t); if (s === 4 || s === 12) { noise(t, .16, 'bandpass', 1900, .22); note(190, t, .1, 'triangle', .1, bus) }
    if (s % 2 === 0) noise(t, .04, 'highpass', 7500, s % 4 === 2 ? .07 : .045); else noise(t, .025, 'highpass', 9000, .02); if (s === 14) noise(t, .16, 'highpass', 7000, .06); if (bar === 0 && s === 0) noise(t, 1.2, 'highpass', 5000, .09);
    if (s % 2 === 0) note(hz(ROOT[bar] + BP[s / 2]), t, s16 * 1.7, 'sawtooth', .17, bassF);
    note(hz(CH[bar][[0, 1, 2, 1][s % 4]] + 12), t, s16 * .8, 'square', .02, arpF);
    if (s === 0) for (const n of CH[bar]) note(hz(n), t, s16 * 15, 'sawtooth', .014, padF, (n % 3 - 1) * 6);
    if (s % 2 === 0) { const m = MEL[bar][s / 2]; if (m) { note(hz(m), t, s16 * 1.9, 'square', .035, leadF); note(hz(m), t, s16 * 1.9, 'sawtooth', .014, leadF, 8) } }
  };
  let step = 0, next = ctx.currentTime + .1;
  setInterval(() => {
    const q = st(); lp.frequency.setTargetAtTime(q.tun > .5 ? 1500 : 12000, ctx.currentTime, .15); wet.gain.setTargetAtTime(.1 + .3 * q.tun, ctx.currentTime, .2);
    while (next < ctx.currentTime + .35) { if (q.on) play(step, next); next += s16; step++ }
  }, 100);
}
