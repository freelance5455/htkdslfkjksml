// فيزياء المركبة (نموذج دراجة + قوة احتكاك الإطارات) — بدون Three.js أو DOM لتسهيل الاختبار.
// الاتجاه: h = الزاوية من محور +z نحو +x. الأمام=(sin h, cos h) واليمين=(cos h, -sin h).
// steer>0 = يمين = نقصان h.
export const DT = 1 / 120;            // خطوة الفيزياء الثابتة
export const PH = {
  ACCEL: 15, BRAKE: 24, GRIP: 34, WB: 2.0,
  YAWACC: 16, SA_RATE: 3.4, SA_BACK: 5.2,
  DRIFT_YAW: 1.2, DRIFT_SA: 1.1, DRIFT_GRIP: 1.12, SCRUB: .1
};
const TAU = Math.PI * 2;
export const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
export const wrap = a => ((a + Math.PI) % TAU + TAU) % TAU - Math.PI;

export function resetBody(K) {
  K.vx = K.vz = K.yr = K.sa = K.aF = K.aL = 0; K.speed = 0; K.vl = 0;
  K.pitch = K.pv = K.roll = K.rv = 0;
}

/** تحريك المركبة خطوة واحدة. c={steer,gas,brake,drift,coast}  e={vmax,wet,off} */
export function stepVehicle(K, c, dt, e) {
  const sh = Math.sin(K.h), ch = Math.cos(K.h);
  let vf = K.vx * sh + K.vz * ch;
  const vf0 = vf;
  const wet = e.wet || 0, boost = K.boost > 0;
  const maxV = e.vmax * (boost ? 1.38 : 1) * (e.off ? .55 : 1);

  // ---- طولي: محرك / فرامل / مقاومة ----
  if (c.gas && !(K.stall > 0)) {
    const r = Math.max(0, vf) / maxV;
    vf += PH.ACCEL * (boost ? 2.2 : 1) * Math.max(0, 1 - r * r) * dt;
  } else {
    const sp = Math.abs(vf);
    vf -= Math.sign(vf) * Math.min(sp, ((c.coast || 0) || (1.6 + .0045 * sp * sp)) * dt);
  }
  if (c.brake && vf > 0) vf = Math.max(0, vf - PH.BRAKE * (1 - .3 * wet) * dt);
  if (c.drift) vf = Math.max(0, vf - 3.5 * dt);
  if (e.off) vf -= Math.min(Math.max(vf, 0), 2.2 * dt);            // مقاومة التربة
  if (vf > maxV) vf = Math.max(maxV, vf - (e.off ? 30 : 14) * dt);   // تلاشي النيترو/الخروج عن الطريق
  if (vf < 0) vf = Math.min(0, vf + 20 * dt);

  // ---- التوجيه: زاوية العجلات تتحرك بمعدل محدود وتقلّ مع السرعة ----
  const sp = Math.max(vf, 0), dr = c.drift;
  const saMax = (.62 * (dr ? PH.DRIFT_SA : 1)) / (1 + Math.pow(sp / 11, 1.5));
  const saT = clamp(c.steer || 0, -1, 1) * saMax;
  const rate = (Math.abs(saT) > Math.abs(K.sa) || saT * K.sa < 0) ? PH.SA_RATE : PH.SA_BACK;
  K.sa += clamp(saT - K.sa, -rate * dt, rate * dt);

  // دائرة احتكاك مبسطة: التسارع/الفرملة يستهلكان جزءًا من تماسك الإطارات المتاح للانعطاف.
  const longUse = clamp(Math.abs((vf - vf0) / dt) / PH.BRAKE, 0, .82);
  const combinedGrip = Math.sqrt(Math.max(.3, 1 - longUse * longUse));
  const grip = PH.GRIP * combinedGrip * (1 - .18 * wet) * (e.off ? .62 : 1) * (dr ? PH.DRIFT_GRIP : 1);
  let yrT = -(sp / PH.WB) * Math.tan(K.sa) * (dr ? PH.DRIFT_YAW : 1);
  // حدّ الدوران بقدرة الإطارات (تحت التوجيه عند السرعات العالية)
  const yrCap = (grip * 1.2) / Math.max(sp, 5);
  yrT = clamp(yrT, -yrCap, yrCap);
  // منع الانزلاق الزائد: كلما زادت زاوية الانزلاق تتشبّث الإطارات وتقلّ الدورة
  const slip0 = Math.atan2(K.vl || 0, Math.max(sp, 2));
  if (yrT * slip0 > 0 && Math.abs(slip0) > .3) yrT *= clamp(1 - (Math.abs(slip0) - .3) / .3, 0, 1);
  K.yr += clamp(yrT - K.yr, -PH.YAWACC * dt, PH.YAWACC * dt);
  K.h += K.yr * dt;

  // ---- جانبي: السرعة تحتفظ بالقصور الذاتي، والإطارات تقتل الانزلاق ضمن حدّ الاحتكاك ----
  const sh2 = Math.sin(K.h), ch2 = Math.cos(K.h);
  // إعادة تحليل سرعة العالم (vx,vz) في إطار الجسم الجديد ثم استبدال المركّبة الطولية بـ vf
  let vfw = K.vx * sh2 + K.vz * ch2, vl = K.vx * ch2 - K.vz * sh2;
  // تطبيق التغيّر الطولي المحسوب أعلاه (vf - vf0) على المركّبة الطولية الجديدة
  vfw += vf - vf0;
  const kill = clamp(-vl * (1 - Math.exp(-dt * 18)), -grip * dt, grip * dt);
  vl += kill;
  const av = Math.abs(vl);
  if (av > 1) vfw -= Math.min(Math.max(vfw, 0), (av - 1) * PH.SCRUB * dt);   // خسارة سرعة بسبب الانزلاق
  K.vx = vfw * sh2 + vl * ch2;
  K.vz = vfw * ch2 - vl * sh2;
  K.vl = vl;
  K.x += K.vx * dt; K.z += K.vz * dt;
  K.speed = Math.max(0, vfw);

  // تسارعات مُرشَّحة لحركة الهيكل (انحناء/ميلان)
  const k = Math.min(1, dt * 10);
  K.aF += ((vfw - vf0) / dt - K.aF) * k;
  K.aL += ((-K.yr * sp) - K.aL) * k;          // موجب = تسارع نحو اليمين
}

export function scaleVel(K, f) { K.vx *= f; K.vz *= f; K.speed *= f; }

/** تحديد موضع المركبة على المسار */
export function locate(K, tr) {
  const { pts, N, ds } = tr;
  let best = K.idx, bd = 1e18;
  for (let o = -16; o <= 16; o++) { const i = (K.idx + o + N) % N, p = pts[i], dx = K.x - p.x, dz = K.z - p.z, d = dx * dx + dz * dz; if (d < bd) { bd = d; best = i; } }
  if (bd > 900) { bd = 1e18; for (let i = 0; i < N; i++) { const p = pts[i], dx = K.x - p.x, dz = K.z - p.z, d = dx * dx + dz * dz; if (d < bd) { bd = d; best = i; } } }
  let di = best - K.idx; if (di > N / 2) di -= N; if (di < -N / 2) di += N;
  K.cum += di; K.idx = best;
  const p = pts[best], dx = K.x - p.x, dz = K.z - p.z;
  K.lat = dx * p.nx + dz * p.nz; K.along = dx * p.tx + dz * p.tz; K.prog = K.cum + K.along / ds;
}

/** ارتطام بالجدار: ارتداد + احتكاك + محاذاة للمسار. يعيد سرعة الاصطدام العمودية. */
export function wallBounce(K, p, WALL, dt) {
  const lat = K.lat; if (Math.abs(lat) <= WALL) return 0;
  const sg = Math.sign(lat), ex = Math.abs(lat) - WALL, ox = p.nx * sg, oz = p.nz * sg;
  K.x -= ox * ex; K.z -= oz * ex;
  const vn = K.vx * ox + K.vz * oz;
  if (vn > 0) { K.vx -= 1.28 * vn * ox; K.vz -= 1.28 * vn * oz; }
  // احتكاك مع الجدار: خفيف عند الانزلاق الموازي، قوي عند الارتطام المباشر
  const f = Math.max(.5, 1 - dt * (.6 + .12 * Math.max(0, vn))); K.vx *= f; K.vz *= f;   // الاحتكاك يتناسب مع قوة الضغط على الجدار
  // دفع الأنف ليتوازى مع الجدار
  const th = Math.atan2(p.tx, p.tz), d = wrap(th - K.h);
  if (Math.abs(d) < 2.4) K.h += d * Math.min(1, dt * 7);
  K.speed = Math.max(0, K.vx * Math.sin(K.h) + K.vz * Math.cos(K.h));
  return Math.max(0, vn);
}

/** تصادم كارتين (دائرتان): فصل + دفع حسب الزخم. يعيد سرعة الاقتراب. */
export function kartBump(a, b, minD) {
  const dx = b.x - a.x, dz = b.z - a.z, d = Math.hypot(dx, dz);
  if (d >= minD || d < 1e-3) return -1;
  const ux = dx / d, uz = dz / d, ov = (minD - d) * .5;
  a.x -= ux * ov; a.z -= uz * ov; b.x += ux * ov; b.z += uz * ov;
  const rel = (b.vx - a.vx) * ux + (b.vz - a.vz) * uz;       // <0 = يقتربان
  if (rel < 0) {
    const j = -(1 + .35) * rel * .5;
    a.vx -= j * ux; a.vz -= j * uz; b.vx += j * ux; b.vz += j * uz;
    // ركلة دوران صغيرة من المماس
    const rt = (b.vx - a.vx) * uz - (b.vz - a.vz) * ux;
    a.yr += clamp(rt * .05, -.6, .6); b.yr += clamp(rt * .05, -.6, .6);
    return -rel;
  }
  return 0;
}

export function samp(tr, p) {
  const { pts, N } = tr; p = ((p % N) + N) % N; const i = Math.floor(p), f = p - i, a = pts[i], b = pts[(i + 1) % N];
  return { x: a.x + (b.x - a.x) * f, z: a.z + (b.z - a.z) * f, nx: a.nx + (b.nx - a.nx) * f, nz: a.nz + (b.nz - a.nz) * f };
}

/** سائق آلي: ملاحقة نقطة أمامية + التحكم بالسرعة حسب الانحناء. يملأ c ويحدّث K.latT. */
export function aiControl(K, tr, env, dt, t, karts, c) {
  const { N, DS, Rla } = tr, HALF = env.half;
  const i = ((Math.floor(K.prog) % N) + N) % N;
  let lt = K.lane + Math.sin(t * .45 + K.phase) * 2.2;
  for (const o of karts) { if (o === K) continue; const dp = (o.prog - K.prog) * DS; if (dp > 0 && dp < 7 && Math.abs(o.lat - K.lat) < 3.2) lt = K.lat >= o.lat ? o.lat + 3.6 : o.lat - 3.6; }
  lt = clamp(lt, -(HALF - 2.2), HALF - 2.2);
  K.latT += clamp(lt - K.latT, -4 * dt, 4 * dt);
  const look = clamp(6 + K.speed * .6, 7, 24), sp = samp(tr, K.prog + look / DS);
  const err = wrap(Math.atan2(sp.x + sp.nx * K.latT - K.x, sp.z + sp.nz * K.latT - K.z) - K.h);
  c.steer = clamp(-(err * 2.4 - K.yr * .3), -1, 1);
  let tv = Math.min(K.base, Math.sqrt(env.latAcc * (1 - .18 * env.wet) * Rla[i])) * env.gapMul;
  tv *= 1 + .008 * K.fruit; if (K.boost > 0) tv *= 1.3;
  tv *= clamp(1 - Math.abs(err) * .7, .45, 1);
  c.gas = K.speed < tv; c.brake = K.speed > tv + 1.5; c.drift = false; c.coast = 0;
  return tv;
}
