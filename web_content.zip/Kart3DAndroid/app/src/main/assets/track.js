// بيانات المسارات + بناء خط المنتصف (بدون اعتماد على Three.js)
export const ROAD = 15;
const ell = (rx, rz, n) => Array.from({ length: n }, (_, i) => { const a = i * 2 * Math.PI / n; return [rx * Math.sin(a), rz * Math.cos(a)]; });

export const TRACKS = [
  { id: 'canyon', name: 'وادي الغروب', laps: 3,
    sky: 0xf2b27a, ground: 0xc9a46a, fog: [90, 260], tree: 0, rock: 1,
    ctrl: [[0,-70],[58,-74],[104,-46],[110,2],[80,34],[88,76],[44,106],[-6,94],[-34,58],[-76,60],[-112,22],[-102,-30],[-54,-60]] },
  { id: 'classic', name: 'الحلبة الخضراء', laps: 3,
    sky: 0x8fc8ef, ground: 0x4f873f, fog: [90, 260], tree: 1, rock: 0,
    ctrl: ell(48, 72, 14) },
];

export function buildTrack(ctrl, N = 520) {
  const n = ctrl.length, S = 48, dense = [];
  for (let i = 0; i < n; i++) {
    const p0 = ctrl[(i - 1 + n) % n], p1 = ctrl[i], p2 = ctrl[(i + 1) % n], p3 = ctrl[(i + 2) % n];
    for (let k = 0; k < S; k++) {
      const u = k / S, u2 = u * u, u3 = u2 * u, q = [0, 0];
      for (let a = 0; a < 2; a++)
        q[a] = 0.5 * (2 * p1[a] + (-p0[a] + p2[a]) * u + (2 * p0[a] - 5 * p1[a] + 4 * p2[a] - p3[a]) * u2 + (-p0[a] + 3 * p1[a] - 3 * p2[a] + p3[a]) * u3);
      dense.push(q);
    }
  }
  const M = dense.length, cum = [0];
  for (let i = 1; i <= M; i++) { const a = dense[i - 1], b = dense[i % M]; cum.push(cum[i - 1] + Math.hypot(b[0] - a[0], b[1] - a[1])); }
  const L = cum[M], pts = [];
  let j = 0;
  for (let i = 0; i < N; i++) {
    const s = i * L / N;
    while (cum[j + 1] < s) j++;
    const f = (s - cum[j]) / (cum[j + 1] - cum[j]), a = dense[j], b = dense[(j + 1) % M];
    pts.push({ x: a[0] + (b[0] - a[0]) * f, z: a[1] + (b[1] - a[1]) * f });
  }
  for (let i = 0; i < N; i++) {
    const a = pts[(i - 1 + N) % N], b = pts[(i + 1) % N], p = pts[i];
    let tx = b.x - a.x, tz = b.z - a.z; const l = Math.hypot(tx, tz); tx /= l; tz /= l;
    p.tx = tx; p.tz = tz; p.nx = tz; p.nz = -tx; // normal = يمين اتجاه السير
  }
  for (let i = 0; i < N; i++) { // نصف قطر الانحناء
    const a = pts[(i - 3 + N) % N], b = pts[i], c = pts[(i + 3) % N];
    const ab = Math.hypot(b.x - a.x, b.z - a.z), bc = Math.hypot(c.x - b.x, c.z - b.z), ca = Math.hypot(a.x - c.x, a.z - c.z);
    const area2 = Math.abs((b.x - a.x) * (c.z - a.z) - (b.z - a.z) * (c.x - a.x));
    b.R = area2 < 1e-6 ? 1e4 : (ab * bc * ca) / (2 * area2);
  }
  return { pts, N, L, ds: L / N };
}
