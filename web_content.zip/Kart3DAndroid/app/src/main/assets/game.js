import * as THREE from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import * as SkeletonUtils from 'three/addons/utils/SkeletonUtils.js';
import {TRACKS,ROAD,buildTrack} from './track.js';
import * as PX from './physics.js';
import * as X from './extras.js';
import * as K from './sky.js';

const $=id=>document.getElementById(id);
const VW=()=>Math.max(innerWidth,innerHeight),VH=()=>Math.min(innerWidth,innerHeight);
const TAU=Math.PI*2, clamp=(v,a,b)=>Math.max(a,Math.min(b,v)), wrap=a=>((a+Math.PI)%TAU+TAU)%TAU-Math.PI;
const store={get(k,d){try{const v=localStorage.getItem('k3d_'+k);return v===null?d:JSON.parse(v)}catch(e){return d}},set(k,v){try{localStorage.setItem('k3d_'+k,JSON.stringify(v))}catch(e){}}};
const cfg={kart:store.get('kart',0),track:store.get('track',0),diff:store.get('diff',1),sound:store.get('sound',true),tilt:store.get('tilt',0),wx:store.get('wx',0),cam:store.get('cam',0),outfit:store.get('outfit',0),car:store.get('car',0),voice:store.get('voice',0)};X.Voice.on=cfg.voice===0;
if(cfg.track>=TRACKS.length)cfg.track=0;
const vib=ms=>{try{window.AndroidBridge&&window.AndroidBridge.vibrate(ms)}catch(e){}};
const fmt=t=>{if(t==null||!isFinite(t))return '--:--.--';const m=Math.floor(t/60),s=t-m*60;return String(m).padStart(2,'0')+':'+s.toFixed(2).padStart(5,'0')};

const HALF=ROAD/2, WALLOFF=3.2, WALL=HALF+WALLOFF-.6;
const MAX=24,LATACC=27,STEP=PX.DT;
const TINTS=[null,0xe34a35,0x1976d2,0x2e9e4f,0xffc107,0x7b1fa2];
const SWATCH=['#dddddd','#e34a35','#1976d2','#2e9e4f','#ffc107','#7b1fa2'];
const AI_SPECS=[{name:'ليث',tint:0x1976d2,k:1.0},{name:'نورة',tint:0xffc107,k:.965},{name:'فارس',tint:0x7b1fa2,k:.93}];
const DIFF=[.80,.90,.99];
const CAMS=[[9.2,6.2,'عادية'],[6.2,3.8,'قريبة'],[12.5,8.4,'بعيدة']];

// ---------- المشهد ----------
const scene=new THREE.Scene();
const camera=new THREE.PerspectiveCamera(62,VW()/VH(),.5,380);   // near=.5 يرفع دقة العمق 5× ويمنع وميض الطبقات (z-fighting)
const renderer=new THREE.WebGLRenderer({antialias:true,powerPreference:'high-performance',stencil:false});
// جودة عالية افتراضيًا حتى 2× على الأجهزة القوية، مع خفض تلقائي للدقة عند هبوط الأداء.
const PRS=[2,1.75,1.5,1.25,1,.85,.7],PRMAX=Math.min(devicePixelRatio||1,2);
const perf={lvl:Math.max(0,PRS.findIndex(v=>v<=PRMAX)),acc:0,n:0,ok:0,cool:3,lowered:0,noUp:false,fps:60};
function setRes(){const pr=Math.min(PRS[perf.lvl],PRMAX);renderer.setPixelRatio(pr);renderer.setSize(VW(),VH())}
setRes();
renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFShadowMap;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.3;renderer.outputColorSpace=THREE.SRGBColorSpace;document.body.appendChild(renderer.domElement);
const hemi=new THREE.HemisphereLight(0xe9f8ff,0x5a4a36,2.0);scene.add(hemi);
const sun=new THREE.DirectionalLight(0xffffff,2.5);sun.castShadow=true;scene.add(sun,sun.target);
sun.shadow.mapSize.set(2048,2048);Object.assign(sun.shadow.camera,{left:-30,right:30,top:30,bottom:-30,near:1,far:140});sun.shadow.camera.updateProjectionMatrix();
sun.shadow.bias=-.0006;sun.shadow.normalBias=.05;
// تثبيت كاميرا الظل على شبكة texel لمنع اهتزاز/سباحة حواف الظلال أثناء الحركة
const LD=new THREE.Vector3(30,55,20).normalize(),LR=new THREE.Vector3().crossVectors(new THREE.Vector3(0,1,0),LD).normalize(),LU=new THREE.Vector3().crossVectors(LD,LR).normalize(),TEXEL=60/2048,_sv=new THREE.Vector3(),UPV=new THREE.Vector3(0,1,0);
function snapSun(p){LR.crossVectors(UPV,LD).normalize();LU.crossVectors(LD,LR).normalize();const a=Math.round(p.dot(LR)/TEXEL)*TEXEL,b=Math.round(p.dot(LU)/TEXEL)*TEXEL,d=p.dot(LD);sun.target.position.copy(LR).multiplyScalar(a).addScaledVector(LU,b).addScaledVector(LD,d);sun.position.copy(sun.target.position).addScaledVector(LD,70);sun.target.updateMatrixWorld();}
const world=new THREE.Group();scene.add(world);X.initSky(scene);K.init(scene,camera);X.initBirds(scene);X.initTalk();

// جسيمات (غبار/شرر/لهب)
const PN=260,pPos=new Float32Array(PN*3).fill(0),pCol=new Float32Array(PN*3),pVel=new Float32Array(PN*3),pLife=new Float32Array(PN);let pHead=0;
for(let i=0;i<PN;i++)pPos[i*3+1]=-50;
const pGeo=new THREE.BufferGeometry();pGeo.setAttribute('position',new THREE.BufferAttribute(pPos,3));pGeo.setAttribute('color',new THREE.BufferAttribute(pCol,3));
const pPoints=new THREE.Points(pGeo,new THREE.PointsMaterial({size:.5,vertexColors:true,transparent:true,opacity:.85,depthWrite:false}));pPoints.frustumCulled=false;scene.add(pPoints);
function emit(x,y,z,vx,vy,vz,life,r,g,b){const i=pHead;pHead=(pHead+1)%PN;pPos[i*3]=x;pPos[i*3+1]=y;pPos[i*3+2]=z;pVel[i*3]=vx;pVel[i*3+1]=vy;pVel[i*3+2]=vz;pCol[i*3]=r;pCol[i*3+1]=g;pCol[i*3+2]=b;pLife[i]=life}
function updParticles(dt){for(let i=0;i<PN;i++){if(pLife[i]>0){pLife[i]-=dt;if(pLife[i]<=0){pPos[i*3+1]=-50}else{pPos[i*3]+=pVel[i*3]*dt;pPos[i*3+1]+=pVel[i*3+1]*dt;pPos[i*3+2]+=pVel[i*3+2]*dt;pVel[i*3+1]-=9*dt}}}pGeo.attributes.position.needsUpdate=true;pGeo.attributes.color.needsUpdate=true}

// ---------- بناء العالم ----------
let groundMat=null,roadMat=null;const wBase={sky:new THREE.Color(),ground:new THREE.Color()};
let T,trk,pts,N,DS,Rla,pads=[],boxes=[],fruits=[],fruitMesh=null,builtTrack=-1,mini={bg:null,s:1,ox:0,oz:0,minX:0,minZ:0};
const _o=new THREE.Object3D(),_c=new THREE.Color();
function rng(seed){return()=>{seed|=0;seed=seed+0x6D2B79F5|0;let t=Math.imul(seed^seed>>>15,1|seed);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
function setFruit(f,v){_o.position.set(f.x,.9,f.z);_o.rotation.set(0,0,0);_o.scale.setScalar(v?1:1e-4);_o.updateMatrix();fruitMesh.setMatrixAt(f.i,_o.matrix);fruitMesh.instanceMatrix.needsUpdate=true}
function disposeWorld(){world.traverse(o=>{if(o.geometry)o.geometry.dispose();if(o.material){(Array.isArray(o.material)?o.material:[o.material]).forEach(m=>{if(m.map)m.map.dispose();m.dispose()})}});world.clear();pads=[];boxes=[];fruits=[];fruitMesh=null}
function samp(p){p=((p%N)+N)%N;const i=Math.floor(p),f=p-i,a=pts[i],b=pts[(i+1)%N];return{x:a.x+(b.x-a.x)*f,z:a.z+(b.z-a.z)*f,tx:a.tx+(b.tx-a.tx)*f,tz:a.tz+(b.tz-a.tz)*f,nx:a.nx+(b.nx-a.nx)*f,nz:a.nz+(b.nz-a.nz)*f}}
const rgb=h=>{_c.set(h);return[_c.r,_c.g,_c.b]};
// شريط هندسي متصل على امتداد المسار. rows=[[إزاحة,ارتفاع],...]، ترتيب المثلثات يُضبط تلقائيًا ليواجه الاتجاه nrm (إضاءة وظلال صحيحة).
function strip(rows,nrm,colFn,opt){opt=opt||{};const pos=[],nor=[],col=[],idx=[],R=rows.length;
  for(let i=0;i<N;i++){const cc=colFn(i),b=pos.length/3;
    for(const pp of [pts[i],pts[(i+1)%N]])for(const r of rows){pos.push(pp.x+pp.nx*r[0],r[1],pp.z+pp.nz*r[0]);const n=nrm(pp);nor.push(n[0],n[1],n[2]);col.push(cc[0],cc[1],cc[2])}
    idx.push(b,b+1,b+R,b+1,b+R+1,b+R)}
  // كشف الاتجاه من أول رباعي
  const n0=nrm(pts[0]),A=[pos[0],pos[1],pos[2]],B=[pos[3],pos[4],pos[5]],C=[pos[3*R],pos[3*R+1],pos[3*R+2]],u=[B[0]-A[0],B[1]-A[1],B[2]-A[2]],v=[C[0]-A[0],C[1]-A[1],C[2]-A[2]];
  const cx=u[1]*v[2]-u[2]*v[1],cy=u[2]*v[0]-u[0]*v[2],cz=u[0]*v[1]-u[1]*v[0];
  if(cx*n0[0]+cy*n0[1]+cz*n0[2]<0)for(let k=0;k<idx.length;k+=6){idx[k+1]=idx[k]+R;idx[k+2]=idx[k]+1;idx[k+3]=idx[k]+1;idx[k+4]=idx[k]+R;idx[k+5]=idx[k]+R+1}
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));g.setAttribute('normal',new THREE.Float32BufferAttribute(nor,3));g.setAttribute('color',new THREE.Float32BufferAttribute(col,3));g.setIndex(idx);
  const mt=new THREE.MeshStandardMaterial({color:opt.color==null?0xffffff:opt.color,vertexColors:true,roughness:.95});
  if(opt.po){mt.polygonOffset=true;mt.polygonOffsetFactor=-2;mt.polygonOffsetUnits=-2}
  const m=new THREE.Mesh(g,mt);m.receiveShadow=true;world.add(m);return m}
function inst(count,geo,color,cast){const m=new THREE.InstancedMesh(geo,new THREE.MeshStandardMaterial({color:0xffffff,roughness:.9}),count);m.castShadow=!!cast;m.receiveShadow=true;world.add(m);m.userData.k=0;return m}
function put(m,x,y,z,ry,sx,sy,sz,col){const k=m.userData.k++;_o.position.set(x,y,z);_o.rotation.set(0,ry,0);_o.scale.set(sx,sy,sz);_o.updateMatrix();m.setMatrixAt(k,_o.matrix);m.setColorAt(k,_c.set(col))}
function done(m){m.count=m.userData.k;m.instanceMatrix.needsUpdate=true;if(m.instanceColor)m.instanceColor.needsUpdate=true}
function checkerTex(){const c=document.createElement('canvas');c.width=128;c.height=32;const g=c.getContext('2d');for(let x=0;x<16;x++)for(let y=0;y<4;y++){g.fillStyle=(x+y)%2?'#fff':'#111';g.fillRect(x*8,y*8,8,8)}const t=new THREE.CanvasTexture(c);t.magFilter=THREE.NearestFilter;return t}
function arrowTex(){const c=document.createElement('canvas');c.width=64;c.height=128;const g=c.getContext('2d');g.fillStyle='#1b1f24';g.fillRect(0,0,64,128);g.strokeStyle='#ffd400';g.lineWidth=9;for(let k=0;k<3;k++){const y=100-k*34;g.beginPath();g.moveTo(8,y);g.lineTo(32,y-26);g.lineTo(56,y);g.stroke()}return new THREE.CanvasTexture(c)}

function buildWorld(ti){
  disposeWorld();T=TRACKS[ti];trk=buildTrack(T.ctrl);pts=trk.pts;N=trk.N;DS=trk.ds;builtTrack=ti;
  scene.background=new THREE.Color(T.sky);scene.fog=new THREE.Fog(T.sky,T.fog[0],T.fog[1]);
  sun.position.set(30,55,20);K.reset(T,Math.atan2(pts[0].tx,pts[0].tz));
  Rla=new Float32Array(N);for(let i=0;i<N;i++){let m=1e9;for(let k=0;k<32;k++)m=Math.min(m,pts[(i+k)%N].R);Rla[i]=Math.max(m,8)}
  trk.DS=DS;trk.Rla=Rla;
  wBase.sky.set(T.sky);wBase.ground.set(T.ground);groundMat=new THREE.MeshStandardMaterial({color:T.ground,roughness:1});const ground=new THREE.Mesh(new THREE.PlaneGeometry(900,900),groundMat);ground.rotation.x=-Math.PI/2;ground.position.y=-.12;ground.receiveShadow=true;world.add(ground);
  const UP=()=>[0,1,0],WH=[1,1,1];
  roadMat=strip([[-HALF,0],[HALF,0]],UP,()=>WH,{color:0x30343a}).material;
  strip([[HALF-.9,.03],[HALF-.55,.03]],UP,()=>WH,{po:1});strip([[-HALF+.55,.03],[-HALF+.9,.03]],UP,()=>WH,{po:1});
  const wc=(T.rock?[0xf0e2c8,0xb5653a]:[0xe8ecef,0x9aa3ab]).map(rgb),kc=[rgb(0xd82b2b),rgb(0xffffff)],wd=HALF+WALLOFF-.25;
  for(const sd of [-1,1]){   // حواف وجدران متصلة بلا فجوات ولا تداخل عند المنعطفات
    const kcol=i=>kc[Math.floor(i*DS/2.5)%2],wcol=i=>wc[Math.floor(i*DS/8)%2];
    strip([[sd*HALF,.06],[sd*(HALF+.9),.06]],UP,kcol);
    strip([[sd*wd,0],[sd*wd,1]],p=>[-sd*p.nx,0,-sd*p.nz],wcol);
    strip([[sd*wd,1],[sd*(wd+.5),1]],UP,wcol);
    strip([[sd*(wd+.5),1],[sd*(wd+.5),0]],p=>[sd*p.nx,0,sd*p.nz],wcol)}
  const stp=Math.max(2,Math.round(5/DS)),ds=inst(Math.ceil(N/stp),new THREE.BoxGeometry(.3,.03,2.4),0,false);
  for(let i=0;i<N;i+=stp){const p=pts[i];put(ds,p.x,.05,p.z,Math.atan2(p.tx,p.tz),1,1,1,0xffffff)}
  done(ds);
  // خط البداية + بوابة
  const p0=pts[0],ry0=Math.atan2(p0.tx,p0.tz),sg=new THREE.Group();sg.position.set(p0.x,.05,p0.z);sg.rotation.y=ry0;world.add(sg);
  const sl=new THREE.Mesh(new THREE.PlaneGeometry(ROAD,2.4),new THREE.MeshBasicMaterial({map:checkerTex(),polygonOffset:true,polygonOffsetFactor:-3,polygonOffsetUnits:-3}));sl.rotation.x=-Math.PI/2;sg.add(sl);
  const pm=new THREE.MeshStandardMaterial({color:0x333a44});
  for(const sd of [-1,1]){const pl=new THREE.Mesh(new THREE.BoxGeometry(.6,7,.6),pm);pl.position.set(sd*(HALF+1.6),3.5,0);sg.add(pl)}
  const bm=new THREE.Mesh(new THREE.BoxGeometry(ROAD+4,.9,.7),new THREE.MeshStandardMaterial({color:0xd82b2b}));bm.position.y=7;sg.add(bm);
  // منصات التسريع
  const at=arrowTex();
  for(const f of [.2,.5,.78]){const idx=Math.round(f*N)%N,p=pts[idx],g=new THREE.Group();g.position.set(p.x,.055,p.z);g.rotation.y=Math.atan2(p.tx,p.tz);
    const pl=new THREE.Mesh(new THREE.PlaneGeometry(4.5,7),new THREE.MeshBasicMaterial({map:at,polygonOffset:true,polygonOffsetFactor:-3,polygonOffsetUnits:-3}));pl.rotation.set(-Math.PI/2,0,Math.PI);g.add(pl);world.add(g);pads.push({idx,lat:0})}
  // صناديق العناصر
  const bg=new THREE.BoxGeometry(1.3,1.3,1.3),bmat=new THREE.MeshStandardMaterial({color:0xffd400,emissive:0x664400,roughness:.4});
  for(const f of [.1,.33,.6,.85])for(const lt of [-4,0,4]){const p=pts[Math.round(f*N)%N],m=new THREE.Mesh(bg,bmat);m.position.set(p.x+p.nx*lt,1.3,p.z+p.nz*lt);m.userData.dyn=true;world.add(m);boxes.push({mesh:m,x:m.position.x,z:m.position.z,cd:0})}
  // ثمار (تعبئة السرعة: ١٠ ثمار = سرعة وأسلحة معزّزة)
  {const fg=new THREE.SphereGeometry(.45,10,8),fm=new THREE.MeshStandardMaterial({color:0xff8a1f,emissive:0x7a3300,roughness:.5}),FR=rng(99+ti);
   fruitMesh=new THREE.InstancedMesh(fg,fm,54);fruitMesh.frustumCulled=false;world.add(fruitMesh);
   for(let c=0;c<18;c++){const base=Math.round((c+.5)*N/18)%N,lt0=(FR()-.5)*8;for(let q=0;q<3;q++){const p=pts[(base+q*3)%N];fruits.push({i:fruits.length,x:p.x+p.nx*lt0,z:p.z+p.nz*lt0,cd:0})}}
   fruits.forEach(f=>setFruit(f,true))}
  // الديكور
  const R=rng(7+ti*13);
  const far=(x,z,min)=>{const m2=min*min;for(let i=0;i<N;i+=3){const dx=pts[i].x-x,dz=pts[i].z-z;if(dx*dx+dz*dz<m2)return false}return true};
  const scatter=(count,min,maxD)=>{const out=[];let tries=0;while(out.length<count&&tries<count*30){tries++;const p=pts[Math.floor(R()*N)],sd=R()<.5?-1:1,d=min+R()*maxD,x=p.x+p.nx*sd*d,z=p.z+p.nz*sd*d;if(Math.abs(x)<420&&Math.abs(z)<420&&far(x,z,min))out.push([x,z])}return out};
  const dmin=HALF+WALLOFF+5;
  if(T.tree){const L=scatter(110,dmin,45),tr=inst(L.length,new THREE.CylinderGeometry(.3,.45,2.2,7),0,false),cr=inst(L.length,new THREE.ConeGeometry(1.9,4.2,8),0,true);
    L.forEach(([x,z])=>{const s=.8+R()*.8;put(tr,x,1.1*s,z,0,s,s,s,0x70452b);put(cr,x,(2.2+2.1)*s,z,R()*3,s,s,s,R()<.5?0x2d6a34:0x3b7d3a)});done(tr);done(cr)}
  if(T.rock){const L=scatter(90,dmin-1,50),rk=inst(L.length,new THREE.DodecahedronGeometry(1,0),0,true);
    L.forEach(([x,z])=>{const s=1.2+R()*2,h=.6+R()*1.2;put(rk,x,s*h*.5,z,R()*6,s,s*h,s*(.7+R()*.6),R()<.5?0xa8804f:0x8a6a42)});done(rk);
    const M=scatter(16,HALF+WALLOFF+35,90),ms=inst(M.length,new THREE.CylinderGeometry(.8,1,1,9),0,true);
    M.forEach(([x,z])=>{const r=9+R()*9,h=14+R()*16;put(ms,x,h/2-.12,z,R()*6,r,h,r,R()<.5?0xb5653a:0xc47a4a)});done(ms)}
  X.decor({world,T,pts,N,R,scatter,dmin,inst,put,done,groundMat,HALF,WALLOFF,DS});
  world.traverse(o=>{if(!o.userData.dyn){o.matrixAutoUpdate=false;o.updateMatrix()}});   // العالم ثابت: لا حاجة لإعادة حساب المصفوفات كل إطار
  buildMini();
}
function buildMini(){const c=document.createElement('canvas');c.width=c.height=110;const g=c.getContext('2d');let a=1e9,b=-1e9,d=1e9,e=-1e9;
  pts.forEach(p=>{a=Math.min(a,p.x);b=Math.max(b,p.x);d=Math.min(d,p.z);e=Math.max(e,p.z)});
  const s=(110-16)/Math.max(b-a,e-d);mini.s=s;mini.ox=8+(94-(b-a)*s)/2;mini.oz=8+(94-(e-d)*s)/2;mini.minX=a;mini.minZ=d;
  g.fillStyle='rgba(0,0,0,.45)';g.fillRect(0,0,110,110);g.strokeStyle='#fff';g.lineWidth=5;g.lineJoin='round';g.beginPath();
  pts.forEach((p,i)=>{const [x,y]=mm(p.x,p.z);i?g.lineTo(x,y):g.moveTo(x,y)});g.closePath();g.stroke();g.strokeStyle='#555';g.lineWidth=3;g.stroke();mini.bg=c}
function mm(x,z){return[mini.ox+(x-mini.minX)*mini.s,mini.oz+(z-mini.minZ)*mini.s]}

// ---------- الكارتات ----------
let glbScene=null,karts=[],player=null;
function loadGLB(){return new Promise(res=>{try{new GLTFLoader().load('kart_character.glb',g=>res(g.scene),undefined,()=>res(null))}catch(e){res(null)}})}
function tintObj(root,tint){root.traverse(o=>{if(o.isMesh){const f=m=>{const c=m.clone();if(tint!=null&&c.color)c.color.multiply(new THREE.Color(tint));return c};o.material=Array.isArray(o.material)?o.material.map(f):f(o.material);o.castShadow=true;o.receiveShadow=true}})}
function fallbackKart(parent,color){const mat=(c,r=.7)=>new THREE.MeshStandardMaterial({color:c,roughness:r});
  const body=new THREE.Mesh(new THREE.BoxGeometry(1.55,.48,2.25),mat(color,.62));body.position.y=.4;body.castShadow=true;parent.add(body);
  const nose=new THREE.Mesh(new THREE.BoxGeometry(1.05,.25,.45),mat(0x222222));nose.position.set(0,.55,.78);parent.add(nose);
  const seat=new THREE.Mesh(new THREE.BoxGeometry(.78,.45,.72),mat(0x202020));seat.position.set(0,.8,-.2);parent.add(seat);
  for(const x of [-.9,.9])for(const z of [-.72,.72]){const w=new THREE.Mesh(new THREE.CylinderGeometry(.3,.3,.25,12),mat(0x111111));w.rotation.z=Math.PI/2;w.position.set(x,.3,z);w.castShadow=true;parent.add(w)}}
function makeModel(tint,fallbackColor){
  const g=new THREE.Group(),roll=new THREE.Group();roll.rotation.order='YXZ';g.add(roll);
  if(glbScene){
    const wrapper=new THREE.Group();wrapper.rotation.y=Math.PI;const m=SkeletonUtils.clone(glbScene);m.rotation.x=-Math.PI/2;wrapper.add(m);wrapper.updateMatrixWorld(true);
    const b=new THREE.Box3().setFromObject(wrapper),size=b.getSize(new THREE.Vector3()),c=b.getCenter(new THREE.Vector3());
    wrapper.position.set(-c.x,-b.min.y,-c.z);const pivot=new THREE.Group();pivot.add(wrapper);pivot.scale.setScalar(2.4/size.z);roll.add(pivot);tintObj(m,tint);
  }else fallbackKart(roll,tint==null?fallbackColor:tint);
  const fl=new THREE.Mesh(new THREE.ConeGeometry(.28,1.5,8),new THREE.MeshBasicMaterial({color:0xffa216}));fl.rotation.x=-Math.PI/2;fl.position.set(0,.55,-1.9);fl.visible=false;roll.add(fl);
  const sh=new THREE.Mesh(new THREE.SphereGeometry(1.9,16,12),new THREE.MeshBasicMaterial({color:0x66ccff,transparent:true,opacity:.28,depthWrite:false}));sh.position.y=.9;sh.visible=false;g.add(sh);
  g.userData={roll,flame:fl,shield:sh};return g}
function mk(isP,tint,spec){const g=makeModel(tint,0xe34a35);X.dress(g,isP?cfg.outfit:1+Math.floor(Math.random()*5),isP?cfg.car:Math.floor(Math.random()*4));scene.add(g);return{g,isP,spec,x:0,z:0,h:0,speed:0,px:0,pz:0,ph:0,vx:0,vz:0,yr:0,sa:0,vl:0,aF:0,aL:0,pitch:0,pv:0,roll:0,rv:0,steerV:0,prog:0,cum:0,idx:0,lat:0,along:0,boost:0,latT:0,lane:0,phase:Math.random()*6,off:false,wall:false,item:false,driftT:0,dv:0,base:MAX,fruit:0,spin:0,spinA:0,shield:0,immune:0,hy:0,hv:0,dm:0,chain:0,chainT:0,aiT:0,rank:1,stall:0,brk:false}}
function createKarts(){karts.forEach(k=>scene.remove(k.g));karts=[];player=mk(true,TINTS[cfg.kart],null);karts.push(player);AI_SPECS.forEach(s=>karts.push(mk(false,s.tint,s)))}

// ---------- الحالة ----------
const S={phase:'menu',paused:false,t:0,cd:0,lastN:-1,goT:0,raceT:0,lapStart:0,lap:1,msgT:0,orb:0,rank:1,wrongT:0,lastBump:0,doneT:0};
const input={left:false,right:false,gas:false,brake:false};const NOIN={left:false,right:false,gas:false,brake:false};
const padIn={left:false,right:false,gas:false,brake:false,ax:0},MI={left:false,right:false,gas:false,brake:false},pp={c:false,t:false,o:false};
let tilt=0,shake=0;
function msg(t,s=1.8){const e=$('msg');e.textContent=t;e.style.opacity=1;S.msgT=s}
function showCD(t){const e=$('countdown');e.textContent=t;e.style.display='grid'}

function placeGrid(){
  const slot=[2,0,1,3];
  karts.forEach((k,i)=>{const s=slot[i],prog=-Math.round(9*(s+1)/DS),lat=s%2?3.2:-3.2,sp=samp(prog);
    k.cum=prog;k.prog=prog;k.idx=((prog%N)+N)%N;k.lat=lat;k.lane=lat;k.latT=lat;k.x=sp.x+sp.nx*lat;k.z=sp.z+sp.nz*lat;k.h=Math.atan2(sp.tx,sp.tz);k.speed=0;k.boost=0;k.item=false;k.driftT=0;k.wall=false;k.off=false;k.along=0;k.fruit=0;k.spin=0;k.spinA=0;k.shield=0;k.immune=0;k.hy=0;k.hv=0;k.dm=0;k.chain=0;k.chainT=0;k.aiT=0;k.stall=0;k.brk=false;PX.resetBody(k);k.px=k.x;k.pz=k.z;k.ph=k.h;k.steerV=0;
    if(!k.isP)k.base=MAX*DIFF[cfg.diff]*k.spec.k;});
  syncKarts(1,0);snapCamera();
}
function syncKarts(alpha,dt){
  for(const k of karts){
    const x=k.px+(k.x-k.px)*alpha,z=k.pz+(k.z-k.pz)*alpha,h=k.ph+PX.wrap(k.h-k.ph)*alpha,u=k.g.userData,sp=Math.max(0,k.speed);
    // هيكل المركبة: نوابض للانحناء الأمامي/الخلفي (تسارع/فرملة) والميلان الجانبي (انعطاف)
    if(dt>0){const pT=clamp(-k.aF*.0042,-.07,.1),rT=clamp(k.aL*.0032,-.11,.11);
      k.pv+=((pT-k.pitch)*170-k.pv*12)*dt;k.pitch+=k.pv*dt;k.rv+=((rT-k.roll)*170-k.rv*12)*dt;k.roll+=k.rv*dt}
    let pn=0,rn=0,bn=0;if(k.off&&sp>3){const a=Math.min(1,sp/MAX);pn=Math.sin(S.t*43+k.phase)*.012*a;rn=Math.sin(S.t*37+k.phase*2)*.016*a;bn=Math.abs(Math.sin(S.t*23+k.phase))*.05*a}
    X.anim(k,dt,S.t);
    k.g.position.set(x,(k.hy||0)+bn,z);k.g.rotation.y=h;
    u.flame.visible=k.boost>0;u.shield.visible=k.shield>0&&(k.shield>1.5||Math.floor(S.t*8)%2===0);
    u.roll.rotation.set(k.pitch+pn,(k.isP?k.dv:0)+k.spinA,k.roll+rn)}}
const camSt={yaw:0,dist:9.2};
function snapCamera(){const k=player,cm=CAMS[cfg.cam]||CAMS[0];camSt.yaw=k.h;camSt.dist=cm[0];camera.position.set(k.x-Math.sin(k.h)*cm[0],cm[1],k.z-Math.cos(k.h)*cm[0]);camera.lookAt(k.x,1.4,k.z)}
// كاميرا مطاردة: الزاوية تلحق بين اتجاه السيارة واتجاه حركتها الفعلي (ترى الانزلاق)، والمسافة صلبة بلا تأخير خطّي
function followCam(dt){const k=player,cm=CAMS[cfg.cam]||CAMS[0],sp=Math.hypot(k.vx,k.vz);let tg=k.h;if(sp>5)tg=k.h+PX.wrap(Math.atan2(k.vx,k.vz)-k.h)*.5;
  camSt.yaw+=PX.wrap(tg-camSt.yaw)*(1-Math.exp(-dt*6));
  camSt.dist+=(cm[0]*(1+.05*k.speed/MAX)+(k.boost>0?1.8:0)-camSt.dist)*(1-Math.exp(-dt*4));
  const px=k.g.position.x,pz=k.g.position.z,sy=Math.sin(camSt.yaw),cy=Math.cos(camSt.yaw);
  camera.position.set(px-sy*camSt.dist,cm[1],pz-cy*camSt.dist);
  const fov=62+(k.boost>0?10:0)+k.speed/MAX*4;if(Math.abs(camera.fov-fov)>.03){camera.fov+=(fov-camera.fov)*(1-Math.exp(-dt*5));camera.updateProjectionMatrix()}
  if(shake>0){camera.position.x+=(Math.random()-.5)*shake;camera.position.y+=(Math.random()-.5)*shake*.6;shake=Math.max(0,shake-dt*2.2)}
  camera.lookAt(px+sy*2,1.4,pz+cy*2)}
function resetRace(){S.paused=false;S.t=0;S.lap=1;S.raceT=0;S.lapStart=0;S.rank=1;S.wrongT=0;S.lastN=-1;S.goT=0;player.steerV=0;document.body.classList.remove('podiumShowing');
  $('finish').style.display='none';$('pause').style.display='none';$('countdown').style.display='none';$('wrong').style.display='none';
  boxes.forEach(b=>{b.cd=0;b.mesh.visible=true});fruits.forEach(f=>{f.cd=0;setFruit(f,true)});clearWeapons();S.wrongV=false;S.gasT=0;weatherReset();placeGrid();hud(true)}
function applyScene(){if(builtTrack!==cfg.track)buildWorld(cfg.track);createKarts();placeGrid()}
function startRace(){try{const de=document.documentElement;const lk=()=>{try{screen.orientation&&screen.orientation.lock&&screen.orientation.lock('landscape').catch(function(){})}catch(e){}};if(de.requestFullscreen&&!document.fullscreenElement){de.requestFullscreen().then(lk).catch(lk)}else lk()}catch(e){}audioInit();audioResume();if(builtTrack!==cfg.track||!player)applyScene();else createKarts();resetRace();document.body.classList.remove('menu');S.phase='count';S.cd=3;$('menu').style.display='none';msg('',0)}
function toMenu(){S.phase='menu';S.paused=false;document.body.classList.add('menu');applyScene();resetRace();$('menu').style.display='flex';$('countdown').style.display='none';menuInfo()}
function pause(){if(S.phase!=='race'&&S.phase!=='count')return;S.paused=true;$('pause').style.display='grid'}
function resume(){S.paused=false;$('pause').style.display='none'}
window.__pause=pause;
window.onBack=()=>{if(S.phase==='menu')return false;if(S.paused){toMenu();return true}if(S.phase==='done'){toMenu();return true}pause();return true};
document.addEventListener('visibilitychange',()=>{if(document.hidden)pause()});

// ---------- الطقس ----------
const WX={
  clear:{cloud:0,rain:0,storm:0,dur:[18,26],ic:'☀️',nm:'صافٍ',m:'☀️ الجو صافٍ'},
  cloudy:{cloud:.85,rain:0,storm:0,dur:[10,15],ic:'☁️',nm:'غائم',m:'☁️ الغيوم تتجمّع'},
  rain:{cloud:1,rain:.75,storm:0,dur:[20,28],ic:'🌧️',nm:'ممطر',m:'🌧️ بدأ المطر – الطريق صار زلقًا'},
  storm:{cloud:1,rain:1,storm:1,dur:[16,22],ic:'⛈️',nm:'عاصفة',m:'⛈️ عاصفة رعدية!'}};
const WNEXT={clear:['cloudy'],cloudy:['clear','rain','rain'],rain:['cloudy','storm','storm'],storm:['rain']};
const W={state:'clear',t:0,dur:20,cloud:0,rain:0,storm:0,wet:0,flash:0,flashT:4,reflash:0,thunderT:0,shown:''};
const RN=900,rD=new Float32Array(RN*3),rPos=new Float32Array(RN*6);
const rGeo=new THREE.BufferGeometry();rGeo.setAttribute('position',new THREE.BufferAttribute(rPos,3));
const rMat=new THREE.LineBasicMaterial({color:0xcfe3f2,transparent:true,opacity:.4,depthWrite:false});
const rLines=new THREE.LineSegments(rGeo,rMat);rLines.frustumCulled=false;rLines.visible=false;scene.add(rLines);
for(let i=0;i<RN;i++){rD[i*3]=(Math.random()-.5)*60;rD[i*3+1]=Math.random()*28;rD[i*3+2]=(Math.random()-.5)*60}
const _tunC=new THREE.Color(0x141a24),_gray=new THREE.Color(0x7f8a93),_dark=new THREE.Color(0x1b222a),_flashC=new THREE.Color(0xe6eeff),_tmp=new THREE.Color(),_rd0=new THREE.Color(0x30343a),_rd1=new THREE.Color(0x1b1f24);
const pick=a=>a[Math.floor(Math.random()*a.length)],rr=r=>r[0]+Math.random()*(r[1]-r[0]);
function weatherReset(){W.state='clear';W.t=0;W.dur=rr(WX.clear.dur);W.cloud=W.rain=W.storm=W.wet=0;W.flash=0;W.flashT=4;W.reflash=0;W.thunderT=0;W.shown='';applyWeather()}
function setWeather(st){W.state=st;W.t=0;W.dur=rr(WX[st].dur);msg(WX[st].m,2.6)}
function applyWeather(){
  if(!T||!groundMat||!roadMat||!scene.fog)return;
  const g=clamp(W.cloud*.55+W.rain*.25+W.storm*.35,0,1);
  K.tint(wBase.sky,_tmp).lerp(_gray,g*.8).lerp(_dark,W.storm*.55);
  if(W.flash>0)_tmp.lerp(_flashC,Math.min(1,W.flash)*.75);
  const tn=X.Tun.amt;if(tn>0)_tmp.lerp(_tunC,tn*.9);
  scene.background.copy(_tmp);scene.fog.color.copy(_tmp);
  scene.fog.near=T.fog[0]*(1-.6*g);scene.fog.far=Math.max(110,T.fog[1]*(1-.45*g-.15*W.storm))*(1-.45*tn);
  hemi.intensity=(2.0*(1-.4*g)*(.45+.55*K.Sky.lit)+W.flash*2.5)*(1-.4*tn);sun.intensity=2.5*(1-.85*g)*(1-.92*tn)*K.Sky.lit;sun.color.copy(K.Sky.sunCol);
  groundMat.color.copy(wBase.ground).multiplyScalar(1-.35*W.wet);
  roadMat.color.copy(_rd0).lerp(_rd1,W.wet);roadMat.roughness=.95-.6*W.wet}
const wrapB=(v,c)=>c+(((v-c+30)%60)+60)%60-30;
function updRain(dt){
  const n=Math.floor(W.rain*RN),vis=n>8;rLines.visible=vis;if(!vis)return;
  rMat.opacity=.22+.3*W.rain;rGeo.setDrawRange(0,n*2);
  const cx=camera.position.x,cz=camera.position.z,vx=-5*dt,vy=-38*dt,vz=-2*dt;
  for(let i=0;i<n;i++){const j=i*3;let x=rD[j]+vx,y=rD[j+1]+vy,z=rD[j+2]+vz;if(y<0)y+=28;x=wrapB(x,cx);z=wrapB(z,cz);rD[j]=x;rD[j+1]=y;rD[j+2]=z;
    const k=i*6;rPos[k]=x;rPos[k+1]=y;rPos[k+2]=z;rPos[k+3]=x+.17;rPos[k+4]=y+1.35;rPos[k+5]=z+.07}
  rGeo.attributes.position.needsUpdate=true}
function updateWeather(dt){
  if(S.phase==='race'&&cfg.wx===0){W.t+=dt;if(W.t>=W.dur)setWeather(K.nextWeather(W.state,{theme:T.id,rank:S.rank,n:karts.length,lap:S.lap,laps:T.laps}))}
  const tg=WX[W.state],r=.18*dt,mv=(v,t)=>v+clamp(t-v,-r,r);
  W.cloud=mv(W.cloud,tg.cloud);W.rain=mv(W.rain,tg.rain);W.storm=mv(W.storm,tg.storm);
  W.wet+=clamp(clamp(W.rain*1.4,0,1)-W.wet,-.045*dt,.12*dt);
  if(W.storm>.6){W.flashT-=dt;if(W.flashT<=0){W.flash=1;W.flashT=3+Math.random()*6;W.thunderT=.4+Math.random()*1.2;if(Math.random()<.5)W.reflash=.16}}
  if(W.reflash>0){W.reflash-=dt;if(W.reflash<=0)W.flash=.8}
  W.flash=Math.max(0,W.flash-dt*3.5);
  if(W.thunderT>0){W.thunderT-=dt;if(W.thunderT<=0){W.thunderT=0;thunder()}}
  applyWeather();updRain(dt);
  const dom=W.storm>.5?'storm':W.rain>.35?'rain':W.cloud>.4?'cloudy':'clear';
  if(dom!==W.shown){W.shown=dom;$('wx').textContent=WX[dom].ic+' '+WX[dom].nm}}

// ---------- الصوت ----------
const A={ctx:null,master:null,eng:null,engF:null,engG:null,eng2:null,eng2F:null,eng2G:null,skid:null,skidF:null,skidG:null,rainG:null};
function audioInit(){if(A.ctx)return;try{const C=window.AudioContext||window.webkitAudioContext;A.ctx=new C();A.master=A.ctx.createGain();A.master.gain.value=cfg.sound?1:0;A.master.connect(A.ctx.destination);
  const o=A.ctx.createOscillator();o.type='sawtooth';const f=A.ctx.createBiquadFilter();f.type='lowpass';f.frequency.value=400;const g=A.ctx.createGain();g.gain.value=0;o.connect(f);f.connect(g);g.connect(A.master);o.start();A.eng=o;A.engF=f;A.engG=g;
  const o2=A.ctx.createOscillator();o2.type='triangle';const f2=A.ctx.createBiquadFilter();f2.type='lowpass';f2.frequency.value=700;const g2=A.ctx.createGain();g2.gain.value=0;o2.connect(f2);f2.connect(g2);g2.connect(A.master);o2.start();A.eng2=o2;A.eng2F=f2;A.eng2G=g2;
  const sk=A.ctx.createOscillator();sk.type='sawtooth';const sf=A.ctx.createBiquadFilter();sf.type='bandpass';sf.frequency.value=1200;sf.Q.value=.8;const sg=A.ctx.createGain();sg.gain.value=0;sk.connect(sf);sf.connect(sg);sg.connect(A.master);sk.start();A.skid=sk;A.skidF=sf;A.skidG=sg;
  X.Voice.ctx=A.ctx;X.Voice.dest=A.master;startMusic();rainAudioInit()}catch(e){A.ctx=null}}
function rainAudioInit(){const n=A.ctx.sampleRate*2,b=A.ctx.createBuffer(1,n,A.ctx.sampleRate),d=b.getChannelData(0);for(let i=0;i<n;i++)d[i]=Math.random()*2-1;
  const s=A.ctx.createBufferSource();s.buffer=b;s.loop=true;const f=A.ctx.createBiquadFilter();f.type='highpass';f.frequency.value=1800;const g=A.ctx.createGain();g.gain.value=0;s.connect(f);f.connect(g);g.connect(A.master);s.start();A.rainG=g}
function thunder(){vib(40);if(!A.ctx||!cfg.sound)return;const n=Math.floor(A.ctx.sampleRate*1.6),buf=A.ctx.createBuffer(1,n,A.ctx.sampleRate),d=buf.getChannelData(0);for(let i=0;i<n;i++)d[i]=(Math.random()*2-1)*Math.pow(1-i/n,2);
  const s=A.ctx.createBufferSource();s.buffer=buf;const f=A.ctx.createBiquadFilter();f.type='lowpass';f.frequency.value=260;const g=A.ctx.createGain();g.gain.value=.9;s.connect(f);f.connect(g);g.connect(A.master);s.start()}
function audioResume(){if(A.ctx&&A.ctx.state==='suspended')A.ctx.resume()}
function setSound(on){cfg.sound=on;store.set('sound',on);if(A.master)A.master.gain.value=on?1:0;$('snd').textContent=on?'🔊':'🔇'}
function tone(f,t,d,type,v,slide){if(!A.ctx)return;const o=A.ctx.createOscillator(),g=A.ctx.createGain();o.type=type;o.frequency.setValueAtTime(f,t);if(slide)o.frequency.exponentialRampToValueAtTime(Math.max(30,f+slide),t+d);g.gain.setValueAtTime(v,t);g.gain.exponentialRampToValueAtTime(.001,t+d);o.connect(g);g.connect(A.master);o.start(t);o.stop(t+d+.03)}
function beep(f,d=.2,type='square',v=.12,slide=0){if(A.ctx&&cfg.sound)tone(f,A.ctx.currentTime,d,type,v,slide)}
function crashSfx(){if(!A.ctx||!cfg.sound)return;const n=Math.floor(A.ctx.sampleRate*.25),buf=A.ctx.createBuffer(1,n,A.ctx.sampleRate),d=buf.getChannelData(0);for(let i=0;i<n;i++)d[i]=(Math.random()*2-1)*(1-i/n);const s=A.ctx.createBufferSource();s.buffer=buf;const g=A.ctx.createGain();g.gain.value=.3;s.connect(g);g.connect(A.master);s.start()}
function startMusic(){X.music(A.ctx,A.master,()=>({on:cfg.sound&&!S.paused&&S.phase!=='done',tun:X.Tun.amt}))}

// ---------- الإدخال ----------
function bind(id,key){const e=$(id);const dn=ev=>{ev.preventDefault();input[key]=true;e.classList.add('down');try{e.setPointerCapture(ev.pointerId)}catch(x){}};const up=ev=>{ev.preventDefault();input[key]=false;e.classList.remove('down')};
  e.addEventListener('pointerdown',dn);['pointerup','pointercancel'].forEach(t=>e.addEventListener(t,up))}
['left','right','gas','brake'].forEach(k=>bind(k,k));
function tap(id,fn){const e=$(id);e.addEventListener('pointerdown',ev=>{ev.preventDefault();e.classList.add('down');fn()});['pointerup','pointercancel','pointerleave'].forEach(t=>e.addEventListener(t,()=>e.classList.remove('down')))}
tap('itemBtn',()=>useItem());tap('tri',()=>cycleCam());
function cycleCam(){if(S.phase==='menu')return;cfg.cam=(cfg.cam+1)%CAMS.length;store.set('cam',cfg.cam);msg('📷 الكاميرا: '+CAMS[cfg.cam][2],1);snapCamera()}
// يد بلايستيشن (Gamepad API): ✕ تسارع، □ فرامل/انجراف، ○ نيترو، △ كاميرا، Options إيقاف، عصا/D-pad للتوجيه
function pollPad(){let g=null;try{const l=navigator.getGamepads?navigator.getGamepads():[];for(let i=0;i<l.length;i++){if(l[i]&&l[i].connected){g=l[i];break}}}catch(e){}
  if(!g){padIn.left=padIn.right=padIn.gas=padIn.brake=false;padIn.ax=0;return}
  const b=i=>!!(g.buttons[i]&&g.buttons[i].pressed),ax=g.axes[0]||0;
  padIn.left=b(14);padIn.right=b(15);padIn.gas=b(0)||b(7);padIn.brake=b(2)||b(6);padIn.ax=Math.abs(ax)>.18?ax:0;
  const c=b(1),t=b(3),o=b(9);if(c&&!pp.c)useItem();if(t&&!pp.t)cycleCam();if(o&&!pp.o){S.paused?resume():pause()}pp.c=c;pp.t=t;pp.o=o}
addEventListener('contextmenu',e=>e.preventDefault());
addEventListener('pointerdown',()=>{audioInit();audioResume()},{passive:true});
addEventListener('keydown',e=>{const k=e.key;if(['ArrowLeft','a','ArrowRight','d','ArrowUp','w','ArrowDown','s',' '].includes(k))e.preventDefault();
  if(k==='ArrowLeft'||k==='a')input.left=true;if(k==='ArrowRight'||k==='d')input.right=true;if(k==='ArrowUp'||k==='w')input.gas=true;if(k==='ArrowDown'||k==='s')input.brake=true;if(k===' ')useItem();if(k==='Escape'||k==='p')S.paused?resume():pause()});
addEventListener('keyup',e=>{const k=e.key;if(k==='ArrowLeft'||k==='a')input.left=false;if(k==='ArrowRight'||k==='d')input.right=false;if(k==='ArrowUp'||k==='w')input.gas=false;if(k==='ArrowDown'||k==='s')input.brake=false});
addEventListener('devicemotion',e=>{const a=e.accelerationIncludingGravity;if(!a||a.x==null)return;const ang=(screen.orientation&&screen.orientation.angle)||0;
  const sx=ang===90?-a.y:(ang===270||ang===-90)?a.y:ang===180?-a.x:a.x;let t=clamp(-sx/9.8*2.2,-1,1);if(Math.abs(t)<.1)t=0;tilt=t});
function useItem(){if(S.phase!=='race'||S.paused||!player.item||player.spin>0)return;fireItem(player)}
// ---------- العناصر والأسلحة (على طراز سباقات الكارت: قنبلة، جرعة، صاروخ موجَّه، درع، نيترو) ----------
const IT={turbo:{ic:'🚀',nm:'نيترو'},shield:{ic:'🛡️',nm:'درع'},bomb:{ic:'💣',nm:'قنبلة'},potion:{ic:'🧪',nm:'جرعة'},missile:{ic:'🎯',nm:'صاروخ'}};
const WGT={first:{bomb:3,potion:3,shield:3,turbo:1},mid:{bomb:2,potion:2,shield:2,turbo:2,missile:2},last:{missile:4,turbo:4,potion:1,shield:1}};
function rollItem(K){const t=K.rank<=1?WGT.first:K.rank>=karts.length?WGT.last:WGT.mid;let s=0;for(const k in t)s+=t[k];let r=Math.random()*s;for(const k in t){r-=t[k];if(r<=0)return k}return 'turbo'}
const wpn=new THREE.Group();scene.add(wpn);const projs=[],hazs=[];
const gBomb=new THREE.BoxGeometry(1.2,1.2,1.2),mBomb=new THREE.MeshStandardMaterial({color:0xd32f2f,emissive:0x550000}),gPot=new THREE.SphereGeometry(.55,10,8),mPot=new THREE.MeshStandardMaterial({color:0x39ff6a,emissive:0x0a6a20}),gMis=new THREE.ConeGeometry(.35,1.6,8),mMis=new THREE.MeshStandardMaterial({color:0xeeeeee,emissive:0x333333});
function nearestAhead(K){let b=null,bd=1e9;for(const o of karts){if(o===K)continue;const d=o.prog-K.prog;if(d>0&&d<bd){bd=d;b=o}}return b}
function mkProj(type){const g=new THREE.Group();if(type==='missile'){const m=new THREE.Mesh(gMis,mMis);m.rotation.x=Math.PI/2;g.add(m)}else g.add(new THREE.Mesh(gPot,mPot));g.visible=false;wpn.add(g);return g}
function fireItem(K){
  const type=K.item;if(!type)return;const up=K.fruit>=10,n=up?3:1;K.item=false;
  if(!K.isP&&cfg.sound)X.racerSfx(type==='turbo'?'boost':'item',K.rank);
  if(type==='turbo'){K.boost=Math.max(K.boost,up?3.4:2.2);if(K.isP){beep(300,.5,'sawtooth',.15,600);vib(40);msg(up?'🚀 نيترو فائق!':'🚀 نيترو!',1)}}
  else if(type==='shield'){K.shield=up?10:5;if(K.isP){beep(500,.3,'triangle',.12,300);msg('🛡️ درع!',1)}}
  else if(type==='bomb'){for(let i=0;i<n;i++){const m=new THREE.Mesh(gBomb,mBomb);m.position.y=.7;wpn.add(m);hazs.push({m,x:K.x-Math.sin(K.h)*(3+i*2.6),z:K.z-Math.cos(K.h)*(3+i*2.6),age:0,life:30,r:up?2.6:2.1,owner:K});}
    if(K.isP){beep(200,.2,'square',.12,-60);msg(up?'💣 ثلاث قنابل!':'💣 قنبلة خلفك',1)}}
  else{for(let i=0;i<n;i++){projs.push({type,owner:K,off:n===1?0:(i-1)*.22,age:-i*.18,life:type==='missile'?5:2.4,live:false,m:mkProj(type),x:0,z:0,h:0,sp:0,tg:null})}
    if(K.isP){beep(type==='missile'?700:400,.25,'sawtooth',.12,-200);msg(type==='missile'?(up?'🎯 ثلاثة صواريخ!':'🎯 صاروخ!'):(up?'🧪 ثلاث جرع!':'🧪 جرعة!'),1)}}
}
function boom(x,z){for(let i=0;i<16;i++)emit(x,.8,z,(Math.random()-.5)*10,2+Math.random()*6,(Math.random()-.5)*10,.5,1,.45+Math.random()*.3,.1);const dx=x-player.x,dz=z-player.z;if(dx*dx+dz*dz<1600)crashSfx()}
function hitKart(K){
  if(K.immune>0||K.spin>0)return;
  if(K.shield>0){K.shield=0;K.immune=.8;if(K.isP){beep(250,.2,'square',.12);msg('🛡️ الدرع حماك!',1)}return}
  K.spin=1.3;K.immune=2.8;PX.scaleVel(K,.25);K.boost=0;K.driftT=0;K.dm=0;K.chain=0;K.fruit=Math.max(0,K.fruit-3);
  if(K.isP){shake=.7;vib(70)}else if(cfg.sound)X.racerSfx('hit',K.rank)}
function clearWeapons(){projs.forEach(p=>wpn.remove(p.m));projs.length=0;hazs.forEach(h=>wpn.remove(h.m));hazs.length=0}
function updateWeapons(dt){
  for(const k of karts){if(k.immune>0)k.immune-=dt;if(k.shield>0)k.shield-=dt;if(k.spin>0){k.spin-=dt;k.spinA=k.spin>0?(1-k.spin/1.3)*TAU*2:0}}
  for(let i=projs.length-1;i>=0;i--){const p=projs[i];p.age+=dt;if(p.age<0)continue;const O=p.owner;
    if(!p.live){p.live=true;p.h=O.h+p.off;p.x=O.x+Math.sin(p.h)*2.4;p.z=O.z+Math.cos(p.h)*2.4;p.sp=p.type==='missile'?46:Math.max(O.speed,18)+24;if(p.type==='missile')p.tg=nearestAhead(O);p.m.visible=true}
    if(p.type==='missile'&&p.tg){p.h+=clamp(wrap(Math.atan2(p.tg.x-p.x,p.tg.z-p.z)-p.h),-4.5*dt,4.5*dt)}
    p.x+=Math.sin(p.h)*p.sp*dt;p.z+=Math.cos(p.h)*p.sp*dt;p.m.position.set(p.x,.9,p.z);p.m.rotation.y=p.h;
    let hit=false;for(const k of karts){if(k===O&&p.age<.6)continue;const dx=k.x-p.x,dz=k.z-p.z;if(dx*dx+dz*dz<5.5){hitKart(k);hit=true;break}}
    if(hit||p.age>p.life){boom(p.x,p.z);wpn.remove(p.m);projs.splice(i,1)}}
  for(let i=hazs.length-1;i>=0;i--){const h=hazs[i];h.age+=dt;h.m.position.set(h.x,.7+Math.sin(S.t*4+i)*.08,h.z);h.m.rotation.y+=dt*2;let hit=false;
    for(const k of karts){if(k===h.owner&&h.age<1)continue;const dx=k.x-h.x,dz=k.z-h.z;if(dx*dx+dz*dz<h.r*h.r&&!(k.immune>0||k.spin>0)){hitKart(k);hit=true;break}}
    if(hit||h.age>h.life){boom(h.x,h.z);wpn.remove(h.m);hazs.splice(i,1)}}
}

// ---------- الفيزياء (التفاصيل في physics.js) ----------
function interact(K){
  for(const pd of pads){let di=K.idx-pd.idx;di=((di+N/2)%N+N)%N-N/2;if(Math.abs(di)<3.5/DS&&Math.abs(K.lat-pd.lat)<3){if(K.boost<.3&&K.isP){beep(520,.25,'square',.12,500);vib(25)}K.boost=Math.max(K.boost,1.3)}}
  for(const b of boxes){if(b.cd>0)continue;const dx=b.x-K.x,dz=b.z-K.z;if(dx*dx+dz*dz<6.8){if(K.item)continue;K.item=rollItem(K);K.aiT=1+Math.random()*3;if(K.isP){beep(660,.15,'triangle',.15,400);vib(20);msg('📦 '+IT[K.item].ic+' '+IT[K.item].nm+' – اضغط ○',1.4)}b.cd=5;b.mesh.visible=false}}
  for(const f of fruits){if(f.cd>0)continue;const dx=f.x-K.x,dz=f.z-K.z;if(dx*dx+dz*dz<4.4){if(K.fruit>=10)continue;K.fruit++;f.cd=8;setFruit(f,false);if(K.isP){beep(900+K.fruit*40,.07,'triangle',.08);if(K.fruit===10)msg('🍊 ١٠ ثمار! سرعة وأسلحة معزّزة ★',2)}}}}
const WALLV=WALL,_cin={steer:0,gas:false,brake:false,drift:false,coast:0},_env={vmax:MAX,wet:0,off:false},_cai={steer:0,gas:false,brake:false,drift:false,coast:0},_aenv={half:HALF,latAcc:LATACC,wet:0,gapMul:1};
function updatePlayer(dt,live){
  const K=player,stun=K.spin>0,pf=dt*60;let inp=NOIN;if(live&&!stun){MI.left=input.left||padIn.left;MI.right=input.right||padIn.right;MI.gas=input.gas||padIn.gas;MI.brake=input.brake||padIn.brake;inp=MI}
  let steer=(inp.right?1:0)-(inp.left?1:0);if(live&&!stun&&padIn.ax)steer=clamp(steer+padIn.ax,-1,1);if(live&&!stun&&cfg.tilt)steer=clamp(steer+tilt*(cfg.tilt===2?-1:1),-1,1);
  if(inp.brake&&!K.brk&&K.hy<.02&&K.speed>MAX*.3){K.hv=5.4;beep(260,.08,'square',.06,200)}K.brk=inp.brake;
  if(K.hy>0||K.hv>0){K.hv-=24*dt;K.hy=Math.max(0,K.hy+K.hv*dt);if(K.hy===0)K.hv=0}
  const drifting=live&&!stun&&inp.brake&&Math.abs(steer)>.1&&K.speed>MAX*.55;
  if(K.stall>0)K.stall-=dt;
  _cin.steer=steer;_cin.gas=live&&!stun&&inp.gas;_cin.brake=live&&inp.brake&&!drifting;_cin.drift=drifting;_cin.coast=live?0:12;
  _env.vmax=MAX*(1+.008*K.fruit);_env.wet=W.wet;_env.off=K.off;
  PX.stepVehicle(K,_cin,dt,_env);
  if(K.boost>0)K.boost-=dt;
  if(drifting){K.driftT+=dt;const was=K.dm;K.dm=Math.min(1,K.dm+(1/1.6)*(1+.35*K.chain)*dt);if(was<1&&K.dm>=1){beep(760,.12,'triangle',.1,300);msg('🔥 جاهز! اترك □',.8);vib(15)}
    if(Math.random()<.7*pf){const c=K.dm>=1?[.4,.8,1]:K.dm>.5?[1,.35,.05]:[1,.65,.1];emit(K.x-Math.sin(K.h)*1.1,.2,K.z-Math.cos(K.h)*1.1,(Math.random()-.5)*4,1+Math.random()*2,(Math.random()-.5)*4,.4,c[0],c[1],c[2])}}
  else{if(K.driftT>0){const m=K.dm;
      if(m>=1){K.chain=Math.min(3,K.chain+1);K.boost=Math.max(K.boost,1.5+.3*K.chain);K.chainT=.45;msg('🔥 تيربو ×'+K.chain,1);beep(420+K.chain*80,.3,'sawtooth',.12,500);vib(20)}
      else if(m>.55){K.boost=Math.max(K.boost,.9);K.chain=0;msg('⚡ تسريع انجراف',1);beep(380,.2,'sawtooth',.1,300)}
      else K.chain=0;
      K.driftT=0;K.dm=0}
    if(K.chainT>0){K.chainT-=dt;if(K.chainT<=0)K.chain=0}}
  PX.locate(K,trk);K.off=Math.abs(K.lat)>HALF+.6;
  const inW=Math.abs(K.lat)>WALLV,sg=Math.sign(K.lat),vn=PX.wallBounce(K,pts[K.idx],WALLV,dt);
  if(inW){if(!K.wall){K.wall=true;if(vn>3){crashSfx();shake=Math.max(shake,Math.min(.9,.15+vn*.04));vib(Math.min(70,20+vn*3))}K.rv-=sg*Math.min(vn,16)*.05}}else K.wall=false;
  if(K.off&&K.speed>4&&Math.random()<.8*pf){const g=_gc.set(T.ground);emit(K.x,.2,K.z,(Math.random()-.5)*3,1.5+Math.random()*2,(Math.random()-.5)*3,.6,g.r*1.1,g.g*1.1,g.b*1.1)}
  if(K.boost>0&&Math.random()<.8*pf)emit(K.x-Math.sin(K.h)*1.8,.55,K.z-Math.cos(K.h)*1.8,(Math.random()-.5),.5,(Math.random()-.5),.3,1,.7,.15);
  K.steerV=steer;K.dv+=((drifting?steer*-.25:0)-K.dv)*Math.min(1,dt*8);
  interact(K);
  const fw=Math.sin(K.h)*pts[K.idx].tx+Math.cos(K.h)*pts[K.idx].tz;
  if(live&&fw<-.3&&K.speed>4){S.wrongT+=dt}else S.wrongT=Math.max(0,S.wrongT-dt*2);
  const wv=S.wrongT>1;if(wv!==S.wrongV){S.wrongV=wv;$('wrong').style.display=wv?'block':'none'}
}
const _gc=new THREE.Color();
// الخصوم يستخدمون نفس نموذج الفيزياء (احتكاك، قصور ذاتي، ارتطام) ويقودهم متحكّم ملاحقة نقطة أمامية
function updateAI(K,dt){
  if(K.item){K.aiT-=dt;if(K.aiT<=0)fireItem(K)}
  const gap=(K.prog-player.prog)*DS;_aenv.gapMul=gap>70?.9:gap<-70?1.07:1;_aenv.wet=W.wet;
  PX.aiControl(K,trk,_aenv,dt,S.t,karts,_cai);
  if(K.spin>0){_cai.gas=false;_cai.brake=false;_cai.steer=0}
  _env.vmax=K.base*_aenv.gapMul*(1+.008*K.fruit);_env.wet=W.wet;_env.off=K.off;
  PX.stepVehicle(K,_cai,dt,_env);if(K.boost>0)K.boost-=dt;
  PX.locate(K,trk);K.off=Math.abs(K.lat)>HALF+.6;
  PX.wallBounce(K,pts[K.idx],WALLV,dt);
  interact(K)}
function collisions(){
  for(let i=0;i<karts.length;i++)for(let j=i+1;j<karts.length;j++){const a=karts[i],b=karts[j],imp=PX.kartBump(a,b,2.5);
    if(imp>0&&(a.isP||b.isP)&&S.t-S.lastBump>.35){S.lastBump=S.t;beep(120,.12,'square',.14,-40);vib(25);shake=Math.max(shake,Math.min(.5,.1+imp*.03))}}}

// ---------- الواجهة ----------
const hudc={};
function hset(id,v){if(hudc[id]!==v){hudc[id]=v;$(id).textContent=v}}
function hud(force){if(force)for(const k in hudc)delete hudc[k];
  hset('speed',Math.round(player.speed*7.2));hset('lap',Math.max(1,Math.min(T.laps,S.lap))+'/'+T.laps);hset('position',S.rank+'/'+karts.length);hset('time',fmt(S.raceT));
  if(force)S.bestTxt=fmt(store.get('lap_'+T.id,null));hset('best',S.bestTxt);
  $('itemBtn').classList.toggle('ready',!!player.item);
  hset('itm',player.item?IT[player.item].ic+(player.fruit>=10?'★':''):'—');hset('fr',player.fruit);
  const sd=player.dm>0||player.driftT>0,dw=$('dwrap'),df=$('dfill');dw.style.opacity=sd?'1':'0';df.style.width=Math.round(player.dm*100)+'%';df.style.background=player.dm>=1?'#4dd2ff':player.dm>.5?'#ff7a1a':'#ffc21a'}
function drawMini(){const c=$('mini'),g=c.getContext('2d');g.clearRect(0,0,110,110);if(mini.bg)g.drawImage(mini.bg,0,0);
  for(let i=karts.length-1;i>=0;i--){const k=karts[i],[x,y]=mm(k.x,k.z);g.beginPath();g.arc(x,y,k.isP?5:3.5,0,TAU);g.fillStyle=k.isP?'#ff3b30':'#'+(k.spec.tint.toString(16).padStart(6,'0'));g.fill();if(k.isP){g.strokeStyle='#fff';g.lineWidth=2;g.stroke()}}}
let podiumScene=null,podiumCamera=null,podiumRenderer=null,podiumFallback=false,podiumWidth=0,podiumHeight=0,podiumDpr=0,podiumCarRoot=null,podiumCars=[],podiumConfetti=null,podiumConfettiData=[];
const podiumTmp=new THREE.Object3D();
function rankTexture(place,color){const c=document.createElement('canvas');c.width=256;c.height=256;const g=c.getContext('2d');g.fillStyle='#'+color.toString(16).padStart(6,'0');g.fillRect(0,0,256,256);g.strokeStyle='#ffffffcc';g.lineWidth=12;g.strokeRect(8,8,240,240);g.fillStyle=place===1?'#392600':'#14202a';g.font='900 190px Arial';g.textAlign='center';g.textBaseline='middle';g.fillText(String(place),128,128);const t=new THREE.CanvasTexture(c);t.colorSpace=THREE.SRGBColorSpace;return t}
function resizePodiumRenderer(){if(!podiumRenderer||!podiumCamera)return;const c=$('podiumCanvas'),w=c.clientWidth,h=c.clientHeight;if(!w||!h)return;const dpr=Math.min(devicePixelRatio||1,1.25);if(w!==podiumWidth||h!==podiumHeight||dpr!==podiumDpr){podiumWidth=w;podiumHeight=h;podiumDpr=dpr;podiumRenderer.setPixelRatio(dpr);podiumRenderer.setSize(w,h,false);podiumCamera.aspect=w/h;podiumCamera.zoom=clamp(1.2+(w/h-3)*.035,1.2,1.3);podiumCamera.updateProjectionMatrix()}}
function ensurePodiumScene(){if(podiumScene)return;
  podiumScene=new THREE.Scene();podiumScene.background=new THREE.Color(0x07131f);podiumScene.fog=new THREE.Fog(0x07131f,35,75);
  podiumCamera=new THREE.PerspectiveCamera(36,3,.1,100);podiumCamera.position.set(0,5.9,14);podiumCamera.lookAt(0,2.3,0);
  try{podiumRenderer=new THREE.WebGLRenderer({canvas:$('podiumCanvas'),antialias:true,powerPreference:'low-power'});podiumRenderer.setPixelRatio(Math.min(devicePixelRatio||1,1.25));podiumRenderer.outputColorSpace=THREE.SRGBColorSpace;podiumRenderer.toneMapping=THREE.ACESFilmicToneMapping;podiumRenderer.toneMappingExposure=1.15;podiumRenderer.shadowMap.enabled=true;podiumRenderer.shadowMap.type=THREE.PCFSoftShadowMap;resizePodiumRenderer()}
  catch(e){podiumFallback=true;$('podiumCanvas').style.display='none';console.warn('3D podium canvas unavailable; rendering podium in the main scene',e)}
  const hemi=new THREE.HemisphereLight(0xb8e8ff,0x1a2330,2.3),key=new THREE.DirectionalLight(0xfff0d3,3.2),fill=new THREE.DirectionalLight(0x65bdff,2.4),gold=new THREE.PointLight(0xffbd42,55,30,2),blue=new THREE.PointLight(0x287bff,32,28,2);
  key.position.set(-7,12,8);fill.position.set(7,7,5);gold.position.set(0,8,4);blue.position.set(0,6,-5);podiumScene.add(hemi,key,fill,gold,blue);
  const floor=new THREE.Mesh(new THREE.PlaneGeometry(180,180),new THREE.MeshStandardMaterial({color:0x091521,roughness:.94,metalness:.08}));floor.rotation.x=-Math.PI/2;floor.position.y=-.43;floor.receiveShadow=true;podiumScene.add(floor);
  const disk=new THREE.Mesh(new THREE.CylinderGeometry(7.8,8.1,.34,64),new THREE.MeshStandardMaterial({color:0x162b3a,roughness:.44,metalness:.48}));disk.position.y=-.25;disk.receiveShadow=true;podiumScene.add(disk);
  const rim=new THREE.Mesh(new THREE.TorusGeometry(7.5,.075,10,80),new THREE.MeshStandardMaterial({color:0xffc342,metalness:.68,roughness:.25,emissive:0x704200}));rim.rotation.x=Math.PI/2;rim.position.y=-.075;podiumScene.add(rim);
  const halo=new THREE.Mesh(new THREE.TorusGeometry(5.8,.055,10,80),new THREE.MeshBasicMaterial({color:0x3caaff,transparent:true,opacity:.75}));halo.position.set(0,4.7,-4.3);podiumScene.add(halo);
  const places=[{n:2,x:-4.15,h:1.5,c:0xc5d2dc},{n:1,x:0,h:2.55,c:0xffc32d},{n:3,x:4.15,h:1.05,c:0xb97648}];
  for(const p of places){const mat=new THREE.MeshStandardMaterial({color:p.c,roughness:.28,metalness:.38}),block=new THREE.Mesh(new THREE.BoxGeometry(3.55,p.h,3.05),mat);block.position.set(p.x,p.h/2,-.18);block.castShadow=true;block.receiveShadow=true;podiumScene.add(block);
    const plate=new THREE.Mesh(new THREE.PlaneGeometry(1.15,.88),new THREE.MeshBasicMaterial({map:rankTexture(p.n,p.c)}));plate.position.set(p.x,p.h*.54,1.36);podiumScene.add(plate);
    const trim=new THREE.Mesh(new THREE.BoxGeometry(3.48,.07,.08),new THREE.MeshBasicMaterial({color:p.c}));trim.position.set(p.x,p.h-.03,1.36);podiumScene.add(trim)}
  podiumCarRoot=new THREE.Group();podiumScene.add(podiumCarRoot);
  const colors=[0xffd54f,0x42b5ff,0xff7043,0x69f0ae,0xce93d8],geo=new THREE.BoxGeometry(.13,.22,.055),mat=new THREE.MeshStandardMaterial({color:0xffffff,roughness:.5});podiumConfetti=new THREE.InstancedMesh(geo,mat,72);podiumConfetti.frustumCulled=false;podiumScene.add(podiumConfetti);
  podiumConfettiData=Array.from({length:72},(_,i)=>{podiumConfetti.setColorAt(i,new THREE.Color(colors[i%colors.length]));return{x:(Math.random()-.5)*14,z:-2+Math.random()*5,y:Math.random()*7,speed:.65+Math.random()*1.5,phase:Math.random()*TAU,spin:Math.random()*TAU}});if(podiumConfetti.instanceColor)podiumConfetti.instanceColor.needsUpdate=true;
}
function cloneNode(root,copy,target){const path=[];let n=target;while(n&&n!==root){const p=n.parent;if(!p)return null;path.unshift(p.children.indexOf(n));n=p}if(n!==root)return null;let q=copy;for(const i of path){if(i<0||!q.children[i])return null;q=q.children[i]}return q}
function buildPodium3D(board){ensurePodiumScene();podiumCarRoot.clear();podiumCars=[];
  const spots=[{k:board[1],place:2,x:-4.15,y:1.5},{k:board[0],place:1,x:0,y:2.55},{k:board[2],place:3,x:4.15,y:1.05}];
  for(const s of spots){if(!s.k)continue;const mesh=SkeletonUtils.clone(s.k.g);mesh.position.set(s.x,s.y,-.18);mesh.rotation.set(0,0,0);mesh.scale.setScalar(.9);if(mesh.children[1])mesh.children[1].visible=false;if(mesh.children[2])mesh.children[2].visible=false;podiumCarRoot.add(mesh);
    const old=s.k.g.userData.rig;let rig=null;if(old){rig={...old,wheels:(old.wheels||[]).map(q=>cloneNode(s.k.g,mesh,q)).filter(Boolean),legs:(old.legs||[]).map(q=>cloneNode(s.k.g,mesh,q)).filter(Boolean),armL:cloneNode(s.k.g,mesh,old.armL),armR:cloneNode(s.k.g,mesh,old.armR),wheel:cloneNode(s.k.g,mesh,old.wheel),headG:cloneNode(s.k.g,mesh,old.headG),mouthG:cloneNode(s.k.g,mesh,old.mouthG)};mesh.userData.rig=rig}
    const roll=s.k.g.userData.roll&&cloneNode(s.k.g,mesh,s.k.g.userData.roll);if(roll)roll.rotation.set(0,0,0);
    podiumCars.push({mesh,rig,baseY:s.y,x:s.x,phase:Math.random()*TAU,heading:s.place===2 ? .1 : s.place===3 ? -.1 : 0,fake:{g:mesh,isP:s.k.isP,speed:2.4,sa:0,phase:Math.random()*6}})
  }
}
function renderPodium3D(now){if(!podiumScene)return;const t=now*.001;
  for(const q of podiumCars){q.fake.speed=2.2+Math.sin(t+q.phase)*.25;q.fake.sa=Math.sin(t*1.3+q.phase)*.045;if(q.rig&&q.rig.wheel&&q.rig.armL&&q.rig.armR&&q.rig.headG&&q.rig.mouthG)X.anim(q.fake,1/60,t);q.mesh.position.y=q.baseY+Math.sin(t*2+q.phase)*.035;q.mesh.rotation.y=q.heading+Math.sin(t*.7+q.phase)*.035}
  if(podiumConfetti){for(let i=0;i<podiumConfettiData.length;i++){const q=podiumConfettiData[i],y=.35+((q.y+t*q.speed)%6.4);podiumTmp.position.set(q.x+Math.sin(t+q.phase)*.28,y,q.z);podiumTmp.rotation.set(t*1.4+q.spin,t*.8+q.phase,t*1.7+q.spin);podiumTmp.scale.setScalar(.7+Math.sin(t*3+q.phase)*.2);podiumTmp.updateMatrix();podiumConfetti.setMatrixAt(i,podiumTmp.matrix)}podiumConfetti.instanceMatrix.needsUpdate=true}
  resizePodiumRenderer();if(podiumRenderer)podiumRenderer.render(podiumScene,podiumCamera);else renderer.render(podiumScene,podiumCamera)
}
function buildPodium(board){
  const podium=$('podium');podium.innerHTML='';
  const slots=[{k:board[1],place:2,cls:'second',label:'الوصيف'},{k:board[0],place:1,cls:'first',label:'البطل'},{k:board[2],place:3,cls:'third',label:'المركز الثالث'}];
  for(const d of slots){if(!d.k)continue;const k=d.k,color=k.isP?(TINTS[cfg.kart]||0xe34a35):((k.spec&&k.spec.tint)||0x607d8b);
    const slot=document.createElement('div');slot.className='podiumSlot '+d.cls;slot.dir='rtl';slot.setAttribute('role','listitem');
    const avatar=document.createElement('div');avatar.className='racerAvatar';avatar.textContent='🏎️';avatar.style.setProperty('--kart','#'+color.toString(16).padStart(6,'0'));avatar.style.setProperty('--medal',d.place===1?'#ffd54f':d.place===2?'#dce8ef':'#d99562');
    const info=document.createElement('div');info.className='racerInfo';const name=document.createElement('div');name.className='racerName';name.textContent=k.isP?'أنت':((k.spec&&k.spec.name)||'متسابق');
    const label=document.createElement('div');label.className='racerLabel';label.textContent=d.label;info.appendChild(name);info.appendChild(label);
    const rank=document.createElement('strong');rank.textContent=String(d.place);rank.style.color=d.place===1?'#ffd54f':d.place===2?'#dce8ef':'#e9a16e';slot.appendChild(avatar);slot.appendChild(info);slot.appendChild(rank);podium.appendChild(slot);
  }
}
function burstConfetti(){const layer=$('confettiLayer'),colors=['#ffd54f','#ff5252','#40c4ff','#69f0ae','#ffffff','#ce93d8'];layer.innerHTML='';
  for(let i=0;i<52;i++){const q=document.createElement('i');q.style.setProperty('--x',(Math.random()*100)+'%');q.style.setProperty('--c',colors[i%colors.length]);q.style.setProperty('--r',(Math.random()*360)+'deg');q.style.setProperty('--drift',((Math.random()-.5)*180)+'px');q.style.setProperty('--d',(2.4+Math.random()*2.2)+'s');q.style.setProperty('--delay',(Math.random()*.8)+'s');layer.appendChild(q)}}
function podiumFanfare(won){if(!A.ctx||!cfg.sound)return;const seq=won?[523,659,784,1047]:[440,554,659],at=A.ctx.currentTime+.08;seq.forEach((f,i)=>tone(f,at+i*.14,.22,'triangle',.12,18))}
function finish(){
  S.phase='done';S.doneT=1.2;const t=S.raceT,lt=t-S.lapStart,bl=store.get('lap_'+T.id,null),br=store.get('race_'+T.id,null);
  let extra='';if(bl==null||lt<bl){store.set('lap_'+T.id,lt)}if(br==null||t<br){store.set('race_'+T.id,t);extra='<br>🌟 رقم قياسي جديد!'}
  const board=[...karts].sort((a,b)=>a.rank-b.rank||b.prog-a.prog),r=player.rank;
  buildPodium(board);buildPodium3D(board);burstConfetti();$('podiumTitle').textContent=r===1?'أنت بطل السباق!':r<=3?'مبروك منصة التتويج!':'أبطال السباق';
  $('podiumSub').textContent=r===1?'وصلت إلى خط النهاية في الصدارة — تستحق الكأس!':'ترتيب المتسابقين عند خط النهاية';
  $('finishText').innerHTML='نتيجتك: المركز '+r+' من '+karts.length+'<br>الزمن: '+fmt(t)+' &nbsp; • &nbsp; أفضل لفة: '+fmt(store.get('lap_'+T.id,null))+extra;
  beep(r===1?880:440,.6,'triangle',.18);podiumFanfare(r===1);vib(80);
}
function menuInfo(){$('bestInfo').textContent='أفضل سباق: '+fmt(store.get('race_'+TRACKS[cfg.track].id,null))+'  •  أفضل لفة: '+fmt(store.get('lap_'+TRACKS[cfg.track].id,null))}
function chips(id,labels,get,set,sw){const el=$(id);el.innerHTML='';labels.forEach((l,i)=>{const b=document.createElement('button');b.className='chip'+(get()===i?' on':'');if(sw){b.style.background=sw[i];b.classList.add('sw')}else b.textContent=l;b.onclick=()=>{set(i);chips(id,labels,get,set,sw)};el.appendChild(b)})}
function buildMenu(){
  chips('cTrack',TRACKS.map(t=>t.name),()=>cfg.track,i=>{cfg.track=i;store.set('track',i);if(S.phase==='menu'){applyScene();resetRace();menuInfo()}});
  chips('cKart',TINTS.map(()=>''),()=>cfg.kart,i=>{cfg.kart=i;store.set('kart',i);if(S.phase==='menu'){createKarts();placeGrid()}},SWATCH);
  chips('cOutfit',X.OUTFITS.map(o=>o.n),()=>cfg.outfit,i=>{cfg.outfit=i;store.set('outfit',i);if(S.phase==='menu'){createKarts();placeGrid()}});
  chips('cCar',X.CARS,()=>cfg.car,i=>{cfg.car=i;store.set('car',i);if(S.phase==='menu'){createKarts();placeGrid()}});
  chips('cVoice',['يتكلم','صامت'],()=>cfg.voice,i=>{cfg.voice=i;store.set('voice',i);X.Voice.on=i===0;if(i===0&&A.ctx)X.say('مرحبا! أنا جاهز للسباق',cfg.sound)});
  chips('cDiff',['سهل','متوسط','صعب'],()=>cfg.diff,i=>{cfg.diff=i;store.set('diff',i)});
  chips('cCtl',['أزرار PS','إمالة','إمالة معكوسة'],()=>cfg.tilt,i=>{cfg.tilt=i;store.set('tilt',i)});
  chips('cWx',['متغيّر','صافٍ فقط'],()=>cfg.wx,i=>{cfg.wx=i;store.set('wx',i)});
  chips('cSnd',['صوت','صامت'],()=>cfg.sound?0:1,i=>setSound(i===0));
}
$('startBtn').onclick=startRace;$('restart').onclick=()=>{if(S.phase!=='menu')startRace()};$('finishRestart').onclick=startRace;$('finishMenu').onclick=toMenu;
$('pResume').onclick=resume;$('pRestart').onclick=startRace;$('pMenu').onclick=toMenu;$('pauseBtn').onclick=()=>{S.paused?resume():pause()};
$('snd').onclick=()=>{audioInit();audioResume();setSound(!cfg.sound);buildMenu()};

// ---------- التحديث الرئيسي ----------
// منطق اللعبة والفيزياء بخطوة ثابتة (120Hz) ⇒ سلوك ثابت مهما تغيّر معدل الإطارات، والرسم يُستوفى بين الخطوتين لحركة سلسة 60fps
function step(dt){
  if(S.phase==='done'&&$('finish').style.display==='grid')return;
  S.t+=dt;
  if(S.phase==='count'){S.cd-=dt;const g0=input.gas||padIn.gas;S.gasT=g0?(S.gasT||0)+dt:0;const n=Math.ceil(S.cd);if(n!==S.lastN){S.lastN=n;if(n>0){showCD(String(n));beep(440,.18)}}
    if(S.cd<=0){S.phase='race';showCD('GO!');beep(880,.5,'square',.2);S.goT=.7;S.raceT=0;S.lapStart=0;if(g0){if(S.gasT<1){player.boost=Math.max(player.boost,1.4);msg('🚀 انطلاقة مثالية!',1.4)}else{player.stall=.9;msg('💨 انطلاق مبكّر… العجلات تدور',1.4)}}}}
  else if(S.phase==='race'){S.raceT+=dt;if(S.goT>0){S.goT-=dt;if(S.goT<=0)$('countdown').style.display='none'}}
  const live=S.phase==='race';
  if(S.phase==='race'||S.phase==='done'){
    updateWeapons(dt);updatePlayer(dt,live);for(const k of karts)if(!k.isP)updateAI(k,dt);collisions();
    for(const k of karts){let q=1;for(const o of karts)if(o!==k&&o.prog>k.prog)q++;k.rank=q}S.rank=player.rank;
    const lap=Math.max(1,Math.min(T.laps,Math.floor(player.prog/N)+1));
    if(S.phase==='race'){
      if(lap>S.lap){const lt=S.raceT-S.lapStart;S.lapStart=S.raceT;S.lap=lap;const bl=store.get('lap_'+T.id,null);let t='اللفة '+(lap-1)+': '+fmt(lt);if(bl==null||lt<bl){store.set('lap_'+T.id,lt);S.bestTxt=fmt(lt);t+=' ⭐'}msg(lap===T.laps?'🏁 اللفة الأخيرة! • '+t:t,2.4);beep(660,.2,'triangle',.12)}
      if(player.prog>=T.laps*N)finish()}
    else{S.doneT-=dt;if(S.doneT<=0&&$('finish').style.display!=='grid'){$('finish').style.display='grid';document.body.classList.add('podiumShowing');resizePodiumRenderer()}}
  }
}
let hudT=0,miniT=0;
function frame(dt,alpha){
  if(S.msgT>0){S.msgT-=dt;if(S.msgT<=0)$('msg').style.opacity=0}
  for(const b of boxes){if(b.cd>0){b.cd-=dt;if(b.cd<=0)b.mesh.visible=true}b.mesh.rotation.y+=dt*2;b.mesh.position.y=1.3+Math.sin(S.t*3+b.x)*.15}
  for(const f of fruits)if(f.cd>0){f.cd-=dt;if(f.cd<=0)setFruit(f,true)}
  updateWeather(dt);
  syncKarts(alpha,dt);
  X.lifeTick(dt,S.t);
  const pk=player,gp=pk.g.position;
  if(pk.speed>10&&W.wet>.3&&Math.random()<W.wet*.6)emit(gp.x-Math.sin(pk.h)*1.3+(Math.random()-.5),.15,gp.z-Math.cos(pk.h)*1.3+(Math.random()-.5),(Math.random()-.5)*2,1+Math.random()*1.5,(Math.random()-.5)*2,.35,.8,.88,1);
  updParticles(dt);
  if(S.phase==='menu'){S.orb+=dt*.35;camera.position.set(gp.x+Math.sin(S.orb)*11,5.5,gp.z+Math.cos(S.orb)*11);camera.lookAt(gp.x,1,gp.z)}
  else followCam(dt);
  K.update(dt,S.t,{scene,W,raceT:S.phase==='race'?S.raceT:0,boost:player.boost,spin:player.spin,rank:S.rank,tun:X.Tun.amt,player:gp});LD.copy(K.Sky.ldir);snapSun(gp);X.skyTick(dt,S.t,W,camera,K.Sky);X.tunTick(dt,player.idx,N);rLines.visible=rLines.visible&&X.Tun.amt<.5;
  {const tt=performance.now()/1000,sky=W.rain>.3||X.Tun.amt>.4;X.birdsTick(dt,tt,camera,sky);X.birdSound(dt,A.ctx,A.master,cfg.sound&&!S.paused&&S.phase!=='done'&&!sky&&W.cloud<.8)}
  X.tick(dt,{race:S.phase==='race'&&!S.paused,boost:player.boost>0,spin:player.spin>0,rank:S.rank,lap:S.lap,wx:W.state,sound:cfg.sound,tun:X.Tun.tg>.5});
  hudT+=dt;if(hudT>.066){hudT=0;hud(false)}
  miniT+=dt;if(miniT>.033){miniT=0;drawMini()}
}
function engineAudio(){if(!A.ctx||!A.engG)return;const run=(S.phase==='race'||S.phase==='count'||(S.phase==='done'&&$('finish').style.display!=='grid'))&&!S.paused&&cfg.sound,v=run?Math.min(1,player.speed/(MAX*1.3)):0,t=A.ctx.currentTime;
  A.engG.gain.setTargetAtTime(run?.05+.06*v:0,t,.05);A.eng.frequency.setTargetAtTime(48+v*140+(player.boost>0?25:0),t,.05);A.engF.frequency.setTargetAtTime(300+v*900,t,.05);
  if(A.eng2G){A.eng2G.gain.setTargetAtTime(run?.018+.035*v:0,t,.06);A.eng2.frequency.setTargetAtTime(88+v*265+(player.boost>0?35:0),t,.06);A.eng2F.frequency.setTargetAtTime(380+v*1050,t,.06)}
  if(A.skidG){const slip=clamp(Math.abs(player.vl||0)/8+(player.driftT>0?.35:0)+(player.off?.18:0),0,1);A.skidG.gain.setTargetAtTime(run?slip*.075:0,t,.045);A.skid.frequency.setTargetAtTime(380+slip*430,t,.045);A.skidF.frequency.setTargetAtTime(850+slip*1400,t,.045)}
  if(A.rainG)A.rainG.gain.setTargetAtTime(run?W.rain*.09:0,t,.25)}
// قياس الأداء وضبط دقة العرض تلقائيًا للحفاظ على ~60fps
function perfTick(raw){
  if(S.paused||document.hidden||raw>.25)return;
  perf.acc+=raw;perf.n++;
  if(perf.acc<1)return;
  const avg=perf.acc/perf.n;perf.fps=1/avg;perf.acc=0;perf.n=0;
  if(perf.cool>0){perf.cool--;return}
  if(avg>.0195&&perf.lvl<PRS.length-1){perf.lvl++;perf.cool=3;perf.ok=0;perf.noUp=perf.lowered++>0;setRes()}
  else if(avg<.0185){if(++perf.ok>=25&&perf.lvl>perf.top&&!perf.noUp){perf.lvl--;perf.cool=3;perf.ok=0;setRes()}}
  else perf.ok=0}
perf.top=Math.max(0,PRS.findIndex(v=>v<=PRMAX));
let lastT=0,acc=0;
function animate(now){requestAnimationFrame(animate);
  if(!lastT){lastT=now;return}
  const raw=(now-lastT)/1000;lastT=now;if(!(raw>0))return;
  perfTick(raw);pollPad();
  if(!S.paused){
    acc+=Math.min(raw,.1);let n=0;
    while(acc>=STEP&&n<10){for(const k of karts){k.px=k.x;k.pz=k.z;k.ph=k.h}step(STEP);acc-=STEP;n++}
    if(n>=10)acc=0;
    frame(Math.min(raw,.05),acc/STEP)}
  engineAudio();renderer.render(scene,camera);if(S.phase==='done'&&$('finish').style.display==='grid'&&podiumScene)renderPodium3D(now)}
addEventListener('resize',()=>{camera.aspect=VW()/VH();camera.updateProjectionMatrix();renderer.setSize(VW(),VH());resizePodiumRenderer()});

(async function init(){
  glbScene=await loadGLB();
  buildMenu();setSound(cfg.sound);
  toMenu();
  window.__ready=true;$('loading').style.display='none';animate();
})().catch(e=>{const l=$('loading');l.style.display='grid';l.innerHTML='حدث خطأ أثناء التشغيل<br><small>'+(e&&e.message||e)+'</small>'});
