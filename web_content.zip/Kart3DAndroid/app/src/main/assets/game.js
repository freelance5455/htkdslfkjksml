import * as THREE from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import * as SkeletonUtils from 'three/addons/utils/SkeletonUtils.js';
import {TRACKS,ROAD,buildTrack} from './track.js';

const $=id=>document.getElementById(id);
const VW=()=>Math.max(innerWidth,innerHeight),VH=()=>Math.min(innerWidth,innerHeight);
const TAU=Math.PI*2, clamp=(v,a,b)=>Math.max(a,Math.min(b,v)), wrap=a=>((a+Math.PI)%TAU+TAU)%TAU-Math.PI;
const store={get(k,d){try{const v=localStorage.getItem('k3d_'+k);return v===null?d:JSON.parse(v)}catch(e){return d}},set(k,v){try{localStorage.setItem('k3d_'+k,JSON.stringify(v))}catch(e){}}};
const cfg={kart:store.get('kart',0),track:store.get('track',0),diff:store.get('diff',1),sound:store.get('sound',true),tilt:store.get('tilt',0),wx:store.get('wx',0),cam:store.get('cam',0)};
if(cfg.track>=TRACKS.length)cfg.track=0;
const vib=ms=>{try{window.AndroidBridge&&window.AndroidBridge.vibrate(ms)}catch(e){}};
const fmt=t=>{if(t==null||!isFinite(t))return '--:--.--';const m=Math.floor(t/60),s=t-m*60;return String(m).padStart(2,'0')+':'+s.toFixed(2).padStart(5,'0')};

const HALF=ROAD/2, WALLOFF=3.2, WALL=HALF+WALLOFF-.6;
const MAX=24,ACCEL=15,DRAG=4.2,BRAKE=24,STEER=1.9,LATACC=34;
const TINTS=[null,0xe34a35,0x1976d2,0x2e9e4f,0xffc107,0x7b1fa2];
const SWATCH=['#dddddd','#e34a35','#1976d2','#2e9e4f','#ffc107','#7b1fa2'];
const AI_SPECS=[{tint:0x1976d2,k:1.0},{tint:0xffc107,k:.965},{tint:0x7b1fa2,k:.93}];
const DIFF=[.80,.90,.99];
const CAMS=[[9.2,6.2,'عادية'],[6.2,3.8,'قريبة'],[12.5,8.4,'بعيدة']];

// ---------- المشهد ----------
const scene=new THREE.Scene();
const camera=new THREE.PerspectiveCamera(62,VW()/VH(),.1,420);
const renderer=new THREE.WebGLRenderer({antialias:true,powerPreference:'high-performance'});
renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));renderer.setSize(VW(),VH());
renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;document.body.appendChild(renderer.domElement);
const hemi=new THREE.HemisphereLight(0xe9f8ff,0x5a4a36,2.0);scene.add(hemi);
const sun=new THREE.DirectionalLight(0xffffff,2.5);sun.castShadow=true;scene.add(sun,sun.target);
sun.shadow.mapSize.set(1024,1024);Object.assign(sun.shadow.camera,{left:-30,right:30,top:30,bottom:-30,near:1,far:140});sun.shadow.camera.updateProjectionMatrix();
const world=new THREE.Group();scene.add(world);

// جسيمات (غبار/شرر/لهب)
const PN=260,pPos=new Float32Array(PN*3).fill(0),pCol=new Float32Array(PN*3),pVel=new Float32Array(PN*3),pLife=new Float32Array(PN);let pHead=0;
for(let i=0;i<PN;i++)pPos[i*3+1]=-50;
const pGeo=new THREE.BufferGeometry();pGeo.setAttribute('position',new THREE.BufferAttribute(pPos,3));pGeo.setAttribute('color',new THREE.BufferAttribute(pCol,3));
const pPoints=new THREE.Points(pGeo,new THREE.PointsMaterial({size:.5,vertexColors:true,transparent:true,opacity:.85,depthWrite:false}));pPoints.frustumCulled=false;scene.add(pPoints);
function emit(x,y,z,vx,vy,vz,life,r,g,b){const i=pHead;pHead=(pHead+1)%PN;pPos[i*3]=x;pPos[i*3+1]=y;pPos[i*3+2]=z;pVel[i*3]=vx;pVel[i*3+1]=vy;pVel[i*3+2]=vz;pCol[i*3]=r;pCol[i*3+1]=g;pCol[i*3+2]=b;pLife[i]=life}
function updParticles(dt){for(let i=0;i<PN;i++){if(pLife[i]>0){pLife[i]-=dt;if(pLife[i]<=0){pPos[i*3+1]=-50}else{pPos[i*3]+=pVel[i*3]*dt;pPos[i*3+1]+=pVel[i*3+1]*dt;pPos[i*3+2]+=pVel[i*3+2]*dt;pVel[i*3+1]-=9*dt}}}pGeo.attributes.position.needsUpdate=true;pGeo.attributes.color.needsUpdate=true}

// ---------- بناء العالم ----------
let groundMat=null,roadMat=null;const wBase={sky:new THREE.Color(),ground:new THREE.Color()};
let T,trk,pts,N,DS,Rla,pads=[],boxes=[],builtTrack=-1,mini={bg:null,s:1,ox:0,oz:0,minX:0,minZ:0};
const _o=new THREE.Object3D(),_c=new THREE.Color();
function rng(seed){return()=>{seed|=0;seed=seed+0x6D2B79F5|0;let t=Math.imul(seed^seed>>>15,1|seed);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
function disposeWorld(){world.traverse(o=>{if(o.geometry)o.geometry.dispose();if(o.material){(Array.isArray(o.material)?o.material:[o.material]).forEach(m=>{if(m.map)m.map.dispose();m.dispose()})}});world.clear();pads=[];boxes=[]}
function samp(p){p=((p%N)+N)%N;const i=Math.floor(p),f=p-i,a=pts[i],b=pts[(i+1)%N];return{x:a.x+(b.x-a.x)*f,z:a.z+(b.z-a.z)*f,tx:a.tx+(b.tx-a.tx)*f,tz:a.tz+(b.tz-a.tz)*f,nx:a.nx+(b.nx-a.nx)*f,nz:a.nz+(b.nz-a.nz)*f}}
function ribbon(a,b,y,color){const pos=[],idx=[],nor=[];for(let i=0;i<=N;i++){const p=pts[i%N];pos.push(p.x+p.nx*a,y,p.z+p.nz*a,p.x+p.nx*b,y,p.z+p.nz*b);nor.push(0,1,0,0,1,0);if(i<N){const k=i*2;idx.push(k,k+1,k+2,k+1,k+3,k+2)}}
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));g.setAttribute('normal',new THREE.Float32BufferAttribute(nor,3));g.setIndex(idx);
  const m=new THREE.Mesh(g,new THREE.MeshStandardMaterial({color,roughness:.95,side:THREE.DoubleSide}));m.receiveShadow=true;world.add(m);return m}
function inst(count,geo,color,cast){const m=new THREE.InstancedMesh(geo,new THREE.MeshStandardMaterial({color:0xffffff,roughness:.9}),count);m.castShadow=!!cast;m.receiveShadow=true;world.add(m);m.userData.k=0;return m}
function put(m,x,y,z,ry,sx,sy,sz,col){const k=m.userData.k++;_o.position.set(x,y,z);_o.rotation.set(0,ry,0);_o.scale.set(sx,sy,sz);_o.updateMatrix();m.setMatrixAt(k,_o.matrix);m.setColorAt(k,_c.set(col))}
function done(m){m.count=m.userData.k;m.instanceMatrix.needsUpdate=true;if(m.instanceColor)m.instanceColor.needsUpdate=true}
function checkerTex(){const c=document.createElement('canvas');c.width=128;c.height=32;const g=c.getContext('2d');for(let x=0;x<16;x++)for(let y=0;y<4;y++){g.fillStyle=(x+y)%2?'#fff':'#111';g.fillRect(x*8,y*8,8,8)}const t=new THREE.CanvasTexture(c);t.magFilter=THREE.NearestFilter;return t}
function arrowTex(){const c=document.createElement('canvas');c.width=64;c.height=128;const g=c.getContext('2d');g.fillStyle='#1b1f24';g.fillRect(0,0,64,128);g.strokeStyle='#ffd400';g.lineWidth=9;for(let k=0;k<3;k++){const y=100-k*34;g.beginPath();g.moveTo(8,y);g.lineTo(32,y-26);g.lineTo(56,y);g.stroke()}return new THREE.CanvasTexture(c)}

function buildWorld(ti){
  disposeWorld();T=TRACKS[ti];trk=buildTrack(T.ctrl);pts=trk.pts;N=trk.N;DS=trk.ds;builtTrack=ti;
  scene.background=new THREE.Color(T.sky);scene.fog=new THREE.Fog(T.sky,T.fog[0],T.fog[1]);
  sun.position.set(30,55,20);
  Rla=new Float32Array(N);for(let i=0;i<N;i++){let m=1e9;for(let k=0;k<32;k++)m=Math.min(m,pts[(i+k)%N].R);Rla[i]=Math.max(m,8)}
  wBase.sky.set(T.sky);wBase.ground.set(T.ground);groundMat=new THREE.MeshStandardMaterial({color:T.ground,roughness:1});const ground=new THREE.Mesh(new THREE.PlaneGeometry(900,900),groundMat);ground.rotation.x=-Math.PI/2;ground.position.y=-.12;ground.receiveShadow=true;world.add(ground);
  roadMat=ribbon(-HALF,HALF,0,0x30343a).material;ribbon(HALF-.9,HALF-.55,.025,0xffffff);ribbon(-HALF+.55,-HALF+.9,.025,0xffffff);
  const wc=T.rock?[0xf0e2c8,0xb5653a]:[0xe8ecef,0x9aa3ab];
  const half=N/2, cb=inst(half*2,new THREE.BoxGeometry(.9,.1,2*DS+.15),0,false), wl=inst(half*2,new THREE.BoxGeometry(.5,1,2*DS+.2),0,false), ds=inst(Math.ceil(N/4),new THREE.BoxGeometry(.3,.03,2.4),0,false);
  for(let i=0;i<N;i+=2){const p=pts[i],ry=Math.atan2(p.tx,p.tz),j=i/2;
    for(const sd of [-1,1]){
      put(cb,p.x+p.nx*sd*(HALF+.45),.05,p.z+p.nz*sd*(HALF+.45),ry,1,1,1,j%2?0xffffff:0xd82b2b);
      put(wl,p.x+p.nx*sd*(HALF+WALLOFF),.5,p.z+p.nz*sd*(HALF+WALLOFF),ry,1,1,1,wc[Math.floor(j/3)%2]);}
    if(i%4===0)put(ds,p.x,.03,p.z,ry,1,1,1,0xffffff);}
  done(cb);done(wl);done(ds);
  // خط البداية + بوابة
  const p0=pts[0],ry0=Math.atan2(p0.tx,p0.tz),sg=new THREE.Group();sg.position.set(p0.x,.04,p0.z);sg.rotation.y=ry0;world.add(sg);
  const sl=new THREE.Mesh(new THREE.PlaneGeometry(ROAD,2.4),new THREE.MeshBasicMaterial({map:checkerTex()}));sl.rotation.x=-Math.PI/2;sg.add(sl);
  const pm=new THREE.MeshStandardMaterial({color:0x333a44});
  for(const sd of [-1,1]){const pl=new THREE.Mesh(new THREE.BoxGeometry(.6,7,.6),pm);pl.position.set(sd*(HALF+1.6),3.5,0);sg.add(pl)}
  const bm=new THREE.Mesh(new THREE.BoxGeometry(ROAD+4,.9,.7),new THREE.MeshStandardMaterial({color:0xd82b2b}));bm.position.y=7;sg.add(bm);
  // منصات التسريع
  const at=arrowTex();
  for(const f of [.2,.5,.78]){const idx=Math.round(f*N)%N,p=pts[idx],g=new THREE.Group();g.position.set(p.x,.045,p.z);g.rotation.y=Math.atan2(p.tx,p.tz);
    const pl=new THREE.Mesh(new THREE.PlaneGeometry(4.5,7),new THREE.MeshBasicMaterial({map:at}));pl.rotation.set(-Math.PI/2,0,Math.PI);g.add(pl);world.add(g);pads.push({idx,lat:0})}
  // صناديق العناصر
  const bg=new THREE.BoxGeometry(1.3,1.3,1.3),bmat=new THREE.MeshStandardMaterial({color:0xffd400,emissive:0x664400,roughness:.4});
  for(const f of [.1,.33,.6,.85])for(const lt of [-4,0,4]){const p=pts[Math.round(f*N)%N],m=new THREE.Mesh(bg,bmat);m.position.set(p.x+p.nx*lt,1.3,p.z+p.nz*lt);world.add(m);boxes.push({mesh:m,x:m.position.x,z:m.position.z,cd:0})}
  // الديكور
  const R=rng(7+ti*13);
  const far=(x,z,min)=>{const m2=min*min;for(let i=0;i<N;i+=3){const dx=pts[i].x-x,dz=pts[i].z-z;if(dx*dx+dz*dz<m2)return false}return true};
  const scatter=(count,min,maxD)=>{const out=[];let tries=0;while(out.length<count&&tries<count*30){tries++;const p=pts[Math.floor(R()*N)],sd=R()<.5?-1:1,d=min+R()*maxD,x=p.x+p.nx*sd*d,z=p.z+p.nz*sd*d;if(Math.abs(x)<420&&Math.abs(z)<420&&far(x,z,min))out.push([x,z])}return out};
  const dmin=HALF+WALLOFF+5;
  if(T.tree){const L=scatter(110,dmin,45),tr=inst(L.length,new THREE.CylinderGeometry(.3,.45,2.2,7),0,false),cr=inst(L.length,new THREE.ConeGeometry(1.9,4.2,8),0,true);
    L.forEach(([x,z])=>{const s=.8+R()*.8;put(tr,x,1.1*s,z,0,s,s,s,0x70452b);put(cr,x,(2.2+2.1)*s,z,R()*3,s,s,s,R()<.5?0x2d6a34:0x3b7d3a)});done(tr);done(cr)}
  if(T.rock){const L=scatter(90,dmin-1,50),rk=inst(L.length,new THREE.DodecahedronGeometry(1,0),0,true);
    L.forEach(([x,z])=>{const s=1.2+R()*2,h=.6+R()*1.2;put(rk,x,s*h*.5,z,R()*6,s,s*h,s*(.7+R()*.6),R()<.5?0xa8804f:0x8a6a42)});done(rk);
    const M=scatter(16,HALF+WALLOFF+35,90),ms=inst(M.length,new THREE.CylinderGeometry(.8,1,1,9),0,true);
    M.forEach(([x,z])=>{const r=9+R()*9,h=14+R()*16;put(ms,x,h/2-.12,z,R()*6,r,h,r,R()<.5?0xb5653a:0xc47a4a)});done(ms)}
  buildMini();
}
function buildMini(){const c=document.createElement('canvas');c.width=c.height=110;const g=c.getContext('2d');let a=1e9,b=-1e9,d=1e9,e=-1e9;
  pts.forEach(p=>{a=Math.min(a,p.x);b=Math.max(b,p.x);d=Math.min(d,p.z);e=Math.max(e,p.z)});
  const s=(110-16)/Math.max(b-a,e-d);mini.s=s;mini.ox=8+(94-(b-a)*s)/2;mini.oz=8+(94-(e-d)*s)/2;mini.minX=a;mini.minZ=d;
  g.fillStyle='rgba(0,0,0,.45)';g.fillRect(0,0,110,110);g.strokeStyle='#fff';g.lineWidth=5;g.lineJoin='round';g.beginPath();
  pts.forEach((p,i)=>{const [x,y]=mm(p.x,p.z);i?g.lineTo(x,y):g.moveTo(x,y)});g.closePath();g.stroke();g.strokeStyle='#555';g.lineWidth=3;g.stroke();mini.bg=c}
function mm(x,z){return[mini.ox+(x-mini.minX)*mini.s,mini.oz+(z-mini.minZ)*mini.s]}

// ---------- الكارتات ----------
let glbScene=null,karts=[],player=null;
function loadGLB(){return new Promise(res=>{try{new GLTFLoader().load('kart_character.glb',g=>res(g.scene),undefined,()=>res(null))}catch(e){res(null)}})}
function tintObj(root,tint){root.traverse(o=>{if(o.isMesh){const f=m=>{const c=m.clone();if(tint!=null&&c.color)c.color.multiply(new THREE.Color(tint));return c};o.material=Array.isArray(o.material)?o.material.map(f):f(o.material);o.castShadow=true;o.receiveShadow=true}})}
function fallbackKart(parent,color){const mat=(c,r=.7)=>new THREE.MeshStandardMaterial({color:c,roughness:r});
  const body=new THREE.Mesh(new THREE.BoxGeometry(1.55,.48,2.25),mat(color,.62));body.position.y=.4;body.castShadow=true;parent.add(body);
  const nose=new THREE.Mesh(new THREE.BoxGeometry(1.05,.25,.45),mat(0x222222));nose.position.set(0,.55,.78);parent.add(nose);
  const seat=new THREE.Mesh(new THREE.BoxGeometry(.78,.45,.72),mat(0x202020));seat.position.set(0,.8,-.2);parent.add(seat);
  for(const x of [-.9,.9])for(const z of [-.72,.72]){const w=new THREE.Mesh(new THREE.CylinderGeometry(.3,.3,.25,12),mat(0x111111));w.rotation.z=Math.PI/2;w.position.set(x,.3,z);w.castShadow=true;parent.add(w)}}
function makeModel(tint,fallbackColor){
  const g=new THREE.Group(),roll=new THREE.Group();g.add(roll);
  if(glbScene){
    const wrapper=new THREE.Group();wrapper.rotation.y=Math.PI;const m=SkeletonUtils.clone(glbScene);m.rotation.x=-Math.PI/2;wrapper.add(m);wrapper.updateMatrixWorld(true);
    const b=new THREE.Box3().setFromObject(wrapper),size=b.getSize(new THREE.Vector3()),c=b.getCenter(new THREE.Vector3());
    wrapper.position.set(-c.x,-b.min.y,-c.z);const pivot=new THREE.Group();pivot.add(wrapper);pivot.scale.setScalar(2.4/size.z);roll.add(pivot);tintObj(m,tint);
  }else fallbackKart(roll,tint==null?fallbackColor:tint);
  const fl=new THREE.Mesh(new THREE.ConeGeometry(.28,1.5,8),new THREE.MeshBasicMaterial({color:0xffa216}));fl.rotation.x=-Math.PI/2;fl.position.set(0,.55,-1.9);fl.visible=false;roll.add(fl);
  g.userData={roll,flame:fl};return g}
function mk(isP,tint,spec){const g=makeModel(tint,0xe34a35);scene.add(g);return{g,isP,spec,x:0,z:0,h:0,speed:0,prog:0,cum:0,idx:0,lat:0,along:0,boost:0,latT:0,lane:0,phase:Math.random()*6,off:false,wall:false,item:false,driftT:0,dv:0,base:MAX}}
function createKarts(){karts.forEach(k=>scene.remove(k.g));karts=[];player=mk(true,TINTS[cfg.kart],null);karts.push(player);AI_SPECS.forEach(s=>karts.push(mk(false,s.tint,s)))}

// ---------- الحالة ----------
const S={phase:'menu',paused:false,t:0,cd:0,lastN:-1,goT:0,raceT:0,lapStart:0,lap:1,msgT:0,orb:0,rank:1,wrongT:0,lastBump:0,doneT:0};
const input={left:false,right:false,gas:false,brake:false};const NOIN={left:false,right:false,gas:false,brake:false};
const padIn={left:false,right:false,gas:false,brake:false,ax:0},MI={left:false,right:false,gas:false,brake:false},pp={c:false,t:false,o:false};
let tilt=0,shake=0;
function msg(t,s=1.8){const e=$('msg');e.textContent=t;e.style.opacity=1;S.msgT=s}
function showCD(t){const e=$('countdown');e.textContent=t;e.style.display='grid'}

function placeGrid(){
  const slot=[2,0,1,3];
  karts.forEach((k,i)=>{const s=slot[i],prog=-Math.round(9*(s+1)/DS),lat=s%2?3.2:-3.2,sp=samp(prog);
    k.cum=prog;k.prog=prog;k.idx=((prog%N)+N)%N;k.lat=lat;k.lane=lat;k.latT=lat;k.x=sp.x+sp.nx*lat;k.z=sp.z+sp.nz*lat;k.h=Math.atan2(sp.tx,sp.tz);k.speed=0;k.boost=0;k.item=false;k.driftT=0;k.wall=false;k.off=false;k.along=0;
    if(!k.isP)k.base=MAX*DIFF[cfg.diff]*k.spec.k;});
  syncKarts(0);snapCamera();
}
function syncKarts(dt){for(const k of karts){k.g.position.set(k.x,0,k.z);k.g.rotation.y=k.h;const u=k.g.userData;u.flame.visible=k.boost>0;
  if(k.isP){const sf=k.speed/MAX;u.roll.rotation.z=-k.steerV*.06*sf||0;u.roll.rotation.y=k.dv}}}
function snapCamera(){const k=player,cm=CAMS[cfg.cam]||CAMS[0];camera.position.set(k.x-Math.sin(k.h)*cm[0],cm[1],k.z-Math.cos(k.h)*cm[0]);camera.lookAt(k.x,1.4,k.z)}
function resetRace(){S.paused=false;S.t=0;S.lap=1;S.raceT=0;S.lapStart=0;S.rank=1;S.wrongT=0;S.lastN=-1;S.goT=0;player.steerV=0;
  $('finish').style.display='none';$('pause').style.display='none';$('countdown').style.display='none';$('wrong').style.display='none';
  boxes.forEach(b=>{b.cd=0;b.mesh.visible=true});weatherReset();placeGrid();hud(true)}
function applyScene(){if(builtTrack!==cfg.track)buildWorld(cfg.track);createKarts();placeGrid()}
function startRace(){try{const de=document.documentElement;const lk=()=>{try{screen.orientation&&screen.orientation.lock&&screen.orientation.lock('landscape').catch(function(){})}catch(e){}};if(de.requestFullscreen&&!document.fullscreenElement){de.requestFullscreen().then(lk).catch(lk)}else lk()}catch(e){}audioInit();audioResume();if(builtTrack!==cfg.track||!player)applyScene();else createKarts();resetRace();document.body.classList.remove('menu');S.phase='count';S.cd=3;$('menu').style.display='none';msg('',0)}
function toMenu(){S.phase='menu';S.paused=false;document.body.classList.add('menu');applyScene();resetRace();$('menu').style.display='flex';$('countdown').style.display='none';menuInfo()}
function pause(){if(S.phase!=='race'&&S.phase!=='count')return;S.paused=true;$('pause').style.display='grid'}
function resume(){S.paused=false;$('pause').style.display='none'}
window.__pause=pause;
window.onBack=()=>{if(S.phase==='menu')return false;if(S.paused){toMenu();return true}if(S.phase==='done'){toMenu();return true}pause();return true};
document.addEventListener('visibilitychange',()=>{if(document.hidden)pause()});

// ---------- الطقس ----------
const WX={
  clear:{cloud:0,rain:0,storm:0,dur:[18,26],ic:'☀️',nm:'صافٍ',m:'☀️ الجو صافٍ'},
  cloudy:{cloud:.85,rain:0,storm:0,dur:[10,15],ic:'☁️',nm:'غائم',m:'☁️ الغيوم تتجمّع'},
  rain:{cloud:1,rain:.75,storm:0,dur:[20,28],ic:'🌧️',nm:'ممطر',m:'🌧️ بدأ المطر – الطريق صار زلقًا'},
  storm:{cloud:1,rain:1,storm:1,dur:[16,22],ic:'⛈️',nm:'عاصفة',m:'⛈️ عاصفة رعدية!'}};
const WNEXT={clear:['cloudy'],cloudy:['clear','rain','rain'],rain:['cloudy','storm','storm'],storm:['rain']};
const W={state:'clear',t:0,dur:20,cloud:0,rain:0,storm:0,wet:0,flash:0,flashT:4,reflash:0,thunderT:0,shown:''};
const RN=900,rD=new Float32Array(RN*3),rPos=new Float32Array(RN*6);
const rGeo=new THREE.BufferGeometry();rGeo.setAttribute('position',new THREE.BufferAttribute(rPos,3));
const rMat=new THREE.LineBasicMaterial({color:0xcfe3f2,transparent:true,opacity:.4,depthWrite:false});
const rLines=new THREE.LineSegments(rGeo,rMat);rLines.frustumCulled=false;rLines.visible=false;scene.add(rLines);
for(let i=0;i<RN;i++){rD[i*3]=(Math.random()-.5)*60;rD[i*3+1]=Math.random()*28;rD[i*3+2]=(Math.random()-.5)*60}
const _gray=new THREE.Color(0x7f8a93),_dark=new THREE.Color(0x1b222a),_flashC=new THREE.Color(0xe6eeff),_tmp=new THREE.Color(),_rd0=new THREE.Color(0x30343a),_rd1=new THREE.Color(0x1b1f24);
const pick=a=>a[Math.floor(Math.random()*a.length)],rr=r=>r[0]+Math.random()*(r[1]-r[0]);
function weatherReset(){W.state='clear';W.t=0;W.dur=rr(WX.clear.dur);W.cloud=W.rain=W.storm=W.wet=0;W.flash=0;W.flashT=4;W.reflash=0;W.thunderT=0;W.shown='';applyWeather()}
function setWeather(st){W.state=st;W.t=0;W.dur=rr(WX[st].dur);msg(WX[st].m,2.6)}
function applyWeather(){
  if(!T||!groundMat||!roadMat||!scene.fog)return;
  const g=clamp(W.cloud*.55+W.rain*.25+W.storm*.35,0,1);
  _tmp.copy(wBase.sky).lerp(_gray,g*.8).lerp(_dark,W.storm*.55);
  if(W.flash>0)_tmp.lerp(_flashC,Math.min(1,W.flash)*.75);
  scene.background.copy(_tmp);scene.fog.color.copy(_tmp);
  scene.fog.near=T.fog[0]*(1-.6*g);scene.fog.far=Math.max(110,T.fog[1]*(1-.45*g-.15*W.storm));
  hemi.intensity=2.0*(1-.4*g)+W.flash*2.5;sun.intensity=2.5*(1-.85*g);
  groundMat.color.copy(wBase.ground).multiplyScalar(1-.35*W.wet);
  roadMat.color.copy(_rd0).lerp(_rd1,W.wet);roadMat.roughness=.95-.6*W.wet}
const wrapB=(v,c)=>c+(((v-c+30)%60)+60)%60-30;
function updRain(dt){
  const n=Math.floor(W.rain*RN),vis=n>8;rLines.visible=vis;if(!vis)return;
  rMat.opacity=.22+.3*W.rain;rGeo.setDrawRange(0,n*2);
  const cx=camera.position.x,cz=camera.position.z,vx=-5*dt,vy=-38*dt,vz=-2*dt;
  for(let i=0;i<n;i++){const j=i*3;let x=rD[j]+vx,y=rD[j+1]+vy,z=rD[j+2]+vz;if(y<0)y+=28;x=wrapB(x,cx);z=wrapB(z,cz);rD[j]=x;rD[j+1]=y;rD[j+2]=z;
    const k=i*6;rPos[k]=x;rPos[k+1]=y;rPos[k+2]=z;rPos[k+3]=x+.17;rPos[k+4]=y+1.35;rPos[k+5]=z+.07}
  rGeo.attributes.position.needsUpdate=true}
function updateWeather(dt){
  if(S.phase==='race'&&cfg.wx===0){W.t+=dt;if(W.t>=W.dur)setWeather(pick(WNEXT[W.state]))}
  const tg=WX[W.state],r=.18*dt,mv=(v,t)=>v+clamp(t-v,-r,r);
  W.cloud=mv(W.cloud,tg.cloud);W.rain=mv(W.rain,tg.rain);W.storm=mv(W.storm,tg.storm);
  W.wet+=clamp(clamp(W.rain*1.4,0,1)-W.wet,-.045*dt,.12*dt);
  if(W.storm>.6){W.flashT-=dt;if(W.flashT<=0){W.flash=1;W.flashT=3+Math.random()*6;W.thunderT=.4+Math.random()*1.2;if(Math.random()<.5)W.reflash=.16}}
  if(W.reflash>0){W.reflash-=dt;if(W.reflash<=0)W.flash=.8}
  W.flash=Math.max(0,W.flash-dt*3.5);
  if(W.thunderT>0){W.thunderT-=dt;if(W.thunderT<=0){W.thunderT=0;thunder()}}
  applyWeather();updRain(dt);
  const dom=W.storm>.5?'storm':W.rain>.35?'rain':W.cloud>.4?'cloudy':'clear';
  if(dom!==W.shown){W.shown=dom;$('wx').textContent=WX[dom].ic+' '+WX[dom].nm}}

// ---------- الصوت ----------
const A={ctx:null,master:null,eng:null,engF:null,engG:null,rainG:null};
function audioInit(){if(A.ctx)return;try{const C=window.AudioContext||window.webkitAudioContext;A.ctx=new C();A.master=A.ctx.createGain();A.master.gain.value=cfg.sound?1:0;A.master.connect(A.ctx.destination);
  const o=A.ctx.createOscillator();o.type='sawtooth';const f=A.ctx.createBiquadFilter();f.type='lowpass';f.frequency.value=400;const g=A.ctx.createGain();g.gain.value=0;o.connect(f);f.connect(g);g.connect(A.master);o.start();A.eng=o;A.engF=f;A.engG=g;startMusic();rainAudioInit()}catch(e){A.ctx=null}}
function rainAudioInit(){const n=A.ctx.sampleRate*2,b=A.ctx.createBuffer(1,n,A.ctx.sampleRate),d=b.getChannelData(0);for(let i=0;i<n;i++)d[i]=Math.random()*2-1;
  const s=A.ctx.createBufferSource();s.buffer=b;s.loop=true;const f=A.ctx.createBiquadFilter();f.type='highpass';f.frequency.value=1800;const g=A.ctx.createGain();g.gain.value=0;s.connect(f);f.connect(g);g.connect(A.master);s.start();A.rainG=g}
function thunder(){vib(40);if(!A.ctx||!cfg.sound)return;const n=Math.floor(A.ctx.sampleRate*1.6),buf=A.ctx.createBuffer(1,n,A.ctx.sampleRate),d=buf.getChannelData(0);for(let i=0;i<n;i++)d[i]=(Math.random()*2-1)*Math.pow(1-i/n,2);
  const s=A.ctx.createBufferSource();s.buffer=buf;const f=A.ctx.createBiquadFilter();f.type='lowpass';f.frequency.value=260;const g=A.ctx.createGain();g.gain.value=.9;s.connect(f);f.connect(g);g.connect(A.master);s.start()}
function audioResume(){if(A.ctx&&A.ctx.state==='suspended')A.ctx.resume()}
function setSound(on){cfg.sound=on;store.set('sound',on);if(A.master)A.master.gain.value=on?1:0;$('snd').textContent=on?'🔊':'🔇'}
function tone(f,t,d,type,v,slide){if(!A.ctx)return;const o=A.ctx.createOscillator(),g=A.ctx.createGain();o.type=type;o.frequency.setValueAtTime(f,t);if(slide)o.frequency.exponentialRampToValueAtTime(Math.max(30,f+slide),t+d);g.gain.setValueAtTime(v,t);g.gain.exponentialRampToValueAtTime(.001,t+d);o.connect(g);g.connect(A.master);o.start(t);o.stop(t+d+.03)}
function beep(f,d=.2,type='square',v=.12,slide=0){if(A.ctx&&cfg.sound)tone(f,A.ctx.currentTime,d,type,v,slide)}
function crashSfx(){if(!A.ctx||!cfg.sound)return;const n=Math.floor(A.ctx.sampleRate*.25),buf=A.ctx.createBuffer(1,n,A.ctx.sampleRate),d=buf.getChannelData(0);for(let i=0;i<n;i++)d[i]=(Math.random()*2-1)*(1-i/n);const s=A.ctx.createBufferSource();s.buffer=buf;const g=A.ctx.createGain();g.gain.value=.3;s.connect(g);g.connect(A.master);s.start()}
function startMusic(){let step=0,next=A.ctx.currentTime+.1;const spb=60/132/2,bass=[55,55,55,73.4,65.4,65.4,65.4,82.4],lead=[0,440,0,523,0,659,523,0,0,392,0,494,0,587,494,0];
  setInterval(()=>{if(!A.ctx)return;while(next<A.ctx.currentTime+.3){if(cfg.sound&&!S.paused&&S.phase!=='done'){tone(bass[step%8],next,spb*.9,'triangle',.07);const l=lead[step%16];if(l)tone(l,next,spb*.8,'square',.025)}next+=spb;step++}},100)}

// ---------- الإدخال ----------
function bind(id,key){const e=$(id);const dn=ev=>{ev.preventDefault();input[key]=true;e.classList.add('down');try{e.setPointerCapture(ev.pointerId)}catch(x){}};const up=ev=>{ev.preventDefault();input[key]=false;e.classList.remove('down')};
  e.addEventListener('pointerdown',dn);['pointerup','pointercancel'].forEach(t=>e.addEventListener(t,up))}
['left','right','gas','brake'].forEach(k=>bind(k,k));
function tap(id,fn){const e=$(id);e.addEventListener('pointerdown',ev=>{ev.preventDefault();e.classList.add('down');fn()});['pointerup','pointercancel','pointerleave'].forEach(t=>e.addEventListener(t,()=>e.classList.remove('down')))}
tap('itemBtn',()=>useItem());tap('tri',()=>cycleCam());
function cycleCam(){if(S.phase==='menu')return;cfg.cam=(cfg.cam+1)%CAMS.length;store.set('cam',cfg.cam);msg('📷 الكاميرا: '+CAMS[cfg.cam][2],1);snapCamera()}
// يد بلايستيشن (Gamepad API): ✕ تسارع، □ فرامل/انجراف، ○ نيترو، △ كاميرا، Options إيقاف، عصا/D-pad للتوجيه
function pollPad(){let g=null;try{const l=navigator.getGamepads?navigator.getGamepads():[];for(let i=0;i<l.length;i++){if(l[i]&&l[i].connected){g=l[i];break}}}catch(e){}
  if(!g){padIn.left=padIn.right=padIn.gas=padIn.brake=false;padIn.ax=0;return}
  const b=i=>!!(g.buttons[i]&&g.buttons[i].pressed),ax=g.axes[0]||0;
  padIn.left=b(14);padIn.right=b(15);padIn.gas=b(0)||b(7);padIn.brake=b(2)||b(6);padIn.ax=Math.abs(ax)>.18?ax:0;
  const c=b(1),t=b(3),o=b(9);if(c&&!pp.c)useItem();if(t&&!pp.t)cycleCam();if(o&&!pp.o){S.paused?resume():pause()}pp.c=c;pp.t=t;pp.o=o}
addEventListener('contextmenu',e=>e.preventDefault());
addEventListener('pointerdown',()=>{audioInit();audioResume()},{passive:true});
addEventListener('keydown',e=>{const k=e.key;if(['ArrowLeft','a','ArrowRight','d','ArrowUp','w','ArrowDown','s',' '].includes(k))e.preventDefault();
  if(k==='ArrowLeft'||k==='a')input.left=true;if(k==='ArrowRight'||k==='d')input.right=true;if(k==='ArrowUp'||k==='w')input.gas=true;if(k==='ArrowDown'||k==='s')input.brake=true;if(k===' ')useItem();if(k==='Escape'||k==='p')S.paused?resume():pause()});
addEventListener('keyup',e=>{const k=e.key;if(k==='ArrowLeft'||k==='a')input.left=false;if(k==='ArrowRight'||k==='d')input.right=false;if(k==='ArrowUp'||k==='w')input.gas=false;if(k==='ArrowDown'||k==='s')input.brake=false});
addEventListener('devicemotion',e=>{const a=e.accelerationIncludingGravity;if(!a||a.x==null)return;const ang=(screen.orientation&&screen.orientation.angle)||0;
  const sx=ang===90?-a.y:(ang===270||ang===-90)?a.y:ang===180?-a.x:a.x;let t=clamp(-sx/9.8*2.2,-1,1);if(Math.abs(t)<.1)t=0;tilt=t});
function useItem(){if(S.phase!=='race'||S.paused||!player.item)return;player.item=false;player.boost=Math.max(player.boost,2.2);beep(300,.5,'sawtooth',.15,600);vib(40);msg('🚀 نيترو!',1)}

// ---------- الفيزياء ----------
function trackState(K){let best=K.idx,bd=1e18;
  for(let o=-16;o<=16;o++){const i=(K.idx+o+N)%N,p=pts[i],dx=K.x-p.x,dz=K.z-p.z,d=dx*dx+dz*dz;if(d<bd){bd=d;best=i}}
  if(bd>900){bd=1e18;for(let i=0;i<N;i++){const p=pts[i],dx=K.x-p.x,dz=K.z-p.z,d=dx*dx+dz*dz;if(d<bd){bd=d;best=i}}}
  let di=best-K.idx;if(di>N/2)di-=N;if(di<-N/2)di+=N;K.cum+=di;K.idx=best;
  const p=pts[best],dx=K.x-p.x,dz=K.z-p.z;K.lat=dx*p.nx+dz*p.nz;K.along=dx*p.tx+dz*p.tz;K.prog=K.cum+K.along/DS}
function interact(K){
  for(const pd of pads){let di=K.idx-pd.idx;di=((di+N/2)%N+N)%N-N/2;if(Math.abs(di)<3.5/DS&&Math.abs(K.lat-pd.lat)<3){if(K.boost<.3&&K.isP){beep(520,.25,'square',.12,500);vib(25)}K.boost=Math.max(K.boost,1.3)}}
  for(const b of boxes){if(b.cd>0)continue;const dx=b.x-K.x,dz=b.z-K.z;if(dx*dx+dz*dz<6.8){if(K.isP){if(K.item)continue;K.item=true;beep(660,.15,'triangle',.15,400);vib(20);msg('📦 عنصر نيترو – اضغط ○',1.4)}else K.boost=Math.max(K.boost,1.5);b.cd=5;b.mesh.visible=false}}}
function updatePlayer(dt,live){
  const K=player;let inp=NOIN;if(live){MI.left=input.left||padIn.left;MI.right=input.right||padIn.right;MI.gas=input.gas||padIn.gas;MI.brake=input.brake||padIn.brake;inp=MI}
  let steer=(inp.right?1:0)-(inp.left?1:0);if(live&&padIn.ax)steer=clamp(steer+padIn.ax,-1,1);if(live&&cfg.tilt)steer=clamp(steer+tilt*(cfg.tilt===2?-1:1),-1,1);
  const drifting=live&&inp.brake&&Math.abs(steer)>.1&&K.speed>MAX*.55;
  const maxV=MAX*(K.boost>0?1.38:1)*(K.off?.55:1);
  if(live&&inp.gas)K.speed+=ACCEL*(K.boost>0?2.2:1)*dt;else K.speed-=(live?DRAG:12)*dt;
  if(live&&inp.brake&&!drifting)K.speed-=BRAKE*(1-.3*W.wet)*dt;if(drifting)K.speed-=3.5*dt;
  if(K.speed>maxV)K.speed=Math.max(maxV,K.speed-(K.off?30:14)*dt);K.speed=Math.max(0,K.speed);
  if(K.boost>0)K.boost-=dt;
  if(drifting){K.driftT+=dt;if(Math.random()<.7)emit(K.x-Math.sin(K.h)*1.1,.2,K.z-Math.cos(K.h)*1.1,(Math.random()-.5)*4,1+Math.random()*2,(Math.random()-.5)*4,.4,1,.65,.1)}
  else if(K.driftT>0){if(K.driftT>2){K.boost=Math.max(K.boost,1.6);msg('🔥 انجراف قوي!',1);beep(420,.3,'sawtooth',.12,500)}else if(K.driftT>1){K.boost=Math.max(K.boost,.9);msg('⚡ تسريع انجراف',1);beep(380,.2,'sawtooth',.1,300)}K.driftT=0}
  if(K.speed>.2)K.h-=steer*STEER*(1-.2*W.wet)*dt*(.35+.9*K.speed/MAX)*(drifting?1.6:1);
  K.x+=Math.sin(K.h)*K.speed*dt;K.z+=Math.cos(K.h)*K.speed*dt;
  trackState(K);K.off=Math.abs(K.lat)>HALF+.6;
  if(Math.abs(K.lat)>WALL){const sg=Math.sign(K.lat),ex=Math.abs(K.lat)-WALL,p=pts[K.idx];K.x-=p.nx*sg*ex;K.z-=p.nz*sg*ex;K.h+=wrap(Math.atan2(p.tx,p.tz)-K.h)*.2;
    if(!K.wall){K.wall=true;if(K.speed>8){crashSfx();shake=.5;vib(45)}}K.speed*=Math.max(.5,1-dt*5)}else K.wall=false;
  if(K.off&&K.speed>4&&Math.random()<.8){const g=new THREE.Color(T.ground);emit(K.x,.2,K.z,(Math.random()-.5)*3,1.5+Math.random()*2,(Math.random()-.5)*3,.6,g.r*1.1,g.g*1.1,g.b*1.1)}
  if(K.boost>0&&Math.random()<.8)emit(K.x-Math.sin(K.h)*1.8,.55,K.z-Math.cos(K.h)*1.8,(Math.random()-.5),.5,(Math.random()-.5),.3,1,.7,.15);
  K.steerV=steer;K.dv+=((drifting?steer*-.45:0)-K.dv)*Math.min(1,dt*8);
  interact(K);
  const fw=Math.sin(K.h)*pts[K.idx].tx+Math.cos(K.h)*pts[K.idx].tz;
  if(live&&fw<-.3&&K.speed>4){S.wrongT+=dt}else S.wrongT=Math.max(0,S.wrongT-dt*2);
  $('wrong').style.display=S.wrongT>1?'block':'none';
}
function updateAI(K,dt){
  const i=((Math.floor(K.prog)%N)+N)%N;let tv=Math.min(K.base,Math.sqrt(LATACC*(1-.18*W.wet)*Rla[i]));
  const gap=(K.prog-player.prog)*DS;if(gap>70)tv*=.9;else if(gap<-70)tv*=1.07;
  if(K.boost>0){tv*=1.3;K.boost-=dt}
  K.speed+=clamp(tv-K.speed,-22*dt,12*dt);K.prog+=K.speed*dt/DS;
  let lt=K.lane+Math.sin(S.t*.45+K.phase)*2.2;
  for(const o of karts){if(o===K)continue;const dp=(o.prog-K.prog)*DS;if(dp>0&&dp<7&&Math.abs(o.lat-K.lat)<3.2)lt=K.lat>=o.lat?o.lat+3.6:o.lat-3.6}
  K.latT=clamp(lt,-(HALF-2.2),HALF-2.2);K.lat+=clamp(K.latT-K.lat,-5*dt,5*dt);
  const sp=samp(K.prog);K.x=sp.x+sp.nx*K.lat;K.z=sp.z+sp.nz*K.lat;K.h=Math.atan2(sp.tx,sp.tz);K.idx=((Math.round(K.prog)%N)+N)%N;
  interact(K);
}
function separate(a,b,wa,wb){const dx=b.x-a.x,dz=b.z-a.z,d=Math.hypot(dx,dz);if(d>=2.5||d<1e-3)return false;const ov=2.5-d,ux=dx/d,uz=dz/d;
  if(a.isP){a.x-=ux*ov*wa;a.z-=uz*ov*wa}else{const p=pts[a.idx];a.lat-=(ux*p.nx+uz*p.nz)*ov*wa}
  if(b.isP){b.x+=ux*ov*wb;b.z+=uz*ov*wb}else{const p=pts[b.idx];b.lat+=(ux*p.nx+uz*p.nz)*ov*wb}
  return true}
function collisions(){
  for(let i=1;i<karts.length;i++){const o=karts[i];
    if(separate(player,o,.55,.45)){if(player.prog<o.prog)player.speed=Math.min(player.speed,Math.max(0,o.speed*.92));else o.speed*=.93;
      if(S.t-S.lastBump>.35){S.lastBump=S.t;beep(120,.12,'square',.14,-40);vib(25);shake=Math.max(shake,.25)}}
    for(let j=i+1;j<karts.length;j++)separate(o,karts[j],.5,.5)}
}

// ---------- الواجهة ----------
const hudc={};
function hset(id,v){if(hudc[id]!==v){hudc[id]=v;$(id).textContent=v}}
function hud(force){if(force)for(const k in hudc)delete hudc[k];
  hset('speed',Math.round(player.speed*7.2));hset('lap',Math.max(1,Math.min(T.laps,S.lap))+'/'+T.laps);hset('position',S.rank+'/'+karts.length);hset('time',fmt(S.raceT));
  if(force)S.bestTxt=fmt(store.get('lap_'+T.id,null));hset('best',S.bestTxt);
  $('itemBtn').classList.toggle('ready',!!player.item)}
function drawMini(){const c=$('mini'),g=c.getContext('2d');g.clearRect(0,0,110,110);if(mini.bg)g.drawImage(mini.bg,0,0);
  for(let i=karts.length-1;i>=0;i--){const k=karts[i],[x,y]=mm(k.x,k.z);g.beginPath();g.arc(x,y,k.isP?5:3.5,0,TAU);g.fillStyle=k.isP?'#ff3b30':'#'+(k.spec.tint.toString(16).padStart(6,'0'));g.fill();if(k.isP){g.strokeStyle='#fff';g.lineWidth=2;g.stroke()}}}
function finish(){
  S.phase='done';S.doneT=1.2;const t=S.raceT,lt=t-S.lapStart,bl=store.get('lap_'+T.id,null),br=store.get('race_'+T.id,null);
  let extra='';if(bl==null||lt<bl){store.set('lap_'+T.id,lt)}if(br==null||t<br){store.set('race_'+T.id,t);extra='<br>🌟 رقم قياسي جديد!'}
  const r=S.rank;$('finishText').innerHTML='المركز '+r+' من '+karts.length+(r===1?' 🏆':'')+'<br>الزمن: '+fmt(t)+'<br>أفضل لفة: '+fmt(store.get('lap_'+T.id,null))+extra;
  beep(r===1?880:440,.6,'triangle',.18);vib(80);
}
function menuInfo(){$('bestInfo').textContent='أفضل سباق: '+fmt(store.get('race_'+TRACKS[cfg.track].id,null))+'  •  أفضل لفة: '+fmt(store.get('lap_'+TRACKS[cfg.track].id,null))}
function chips(id,labels,get,set,sw){const el=$(id);el.innerHTML='';labels.forEach((l,i)=>{const b=document.createElement('button');b.className='chip'+(get()===i?' on':'');if(sw){b.style.background=sw[i];b.classList.add('sw')}else b.textContent=l;b.onclick=()=>{set(i);chips(id,labels,get,set,sw)};el.appendChild(b)})}
function buildMenu(){
  chips('cTrack',TRACKS.map(t=>t.name),()=>cfg.track,i=>{cfg.track=i;store.set('track',i);if(S.phase==='menu'){applyScene();resetRace();menuInfo()}});
  chips('cKart',TINTS.map(()=>''),()=>cfg.kart,i=>{cfg.kart=i;store.set('kart',i);if(S.phase==='menu'){createKarts();placeGrid()}},SWATCH);
  chips('cDiff',['سهل','متوسط','صعب'],()=>cfg.diff,i=>{cfg.diff=i;store.set('diff',i)});
  chips('cCtl',['أزرار PS','إمالة','إمالة معكوسة'],()=>cfg.tilt,i=>{cfg.tilt=i;store.set('tilt',i)});
  chips('cWx',['متغيّر','صافٍ فقط'],()=>cfg.wx,i=>{cfg.wx=i;store.set('wx',i)});
  chips('cSnd',['صوت','صامت'],()=>cfg.sound?0:1,i=>setSound(i===0));
}
$('startBtn').onclick=startRace;$('restart').onclick=()=>{if(S.phase!=='menu')startRace()};$('finishRestart').onclick=startRace;$('finishMenu').onclick=toMenu;
$('pResume').onclick=resume;$('pRestart').onclick=startRace;$('pMenu').onclick=toMenu;$('pauseBtn').onclick=()=>{S.paused?resume():pause()};
$('snd').onclick=()=>{audioInit();audioResume();setSound(!cfg.sound);buildMenu()};

// ---------- التحديث الرئيسي ----------
function update(dt){
  S.t+=dt;
  if(S.phase==='count'){S.cd-=dt;const n=Math.ceil(S.cd);if(n!==S.lastN){S.lastN=n;if(n>0){showCD(String(n));beep(440,.18)}}
    if(S.cd<=0){S.phase='race';showCD('GO!');beep(880,.5,'square',.2);S.goT=.7;S.raceT=0;S.lapStart=0}}
  else if(S.phase==='race'){S.raceT+=dt;if(S.goT>0){S.goT-=dt;if(S.goT<=0)$('countdown').style.display='none'}}
  if(S.msgT>0){S.msgT-=dt;if(S.msgT<=0)$('msg').style.opacity=0}
  const live=S.phase==='race';
  if(S.phase==='race'||S.phase==='done'){
    updatePlayer(dt,live);for(const k of karts)if(!k.isP)updateAI(k,dt);collisions();
    const order=karts.slice().sort((a,b)=>b.prog-a.prog);S.rank=order.indexOf(player)+1;
    const lap=Math.max(1,Math.min(T.laps,Math.floor(player.prog/N)+1));
    if(S.phase==='race'){
      if(lap>S.lap){const lt=S.raceT-S.lapStart;S.lapStart=S.raceT;S.lap=lap;const bl=store.get('lap_'+T.id,null);let t='اللفة '+(lap-1)+': '+fmt(lt);if(bl==null||lt<bl){store.set('lap_'+T.id,lt);S.bestTxt=fmt(lt);t+=' ⭐'}msg(lap===T.laps?'🏁 اللفة الأخيرة! • '+t:t,2.4);beep(660,.2,'triangle',.12)}
      if(player.prog>=T.laps*N)finish()}
    else{S.doneT-=dt;if(S.doneT<=0&&$('finish').style.display!=='grid')$('finish').style.display='grid'}
  }
  for(const b of boxes){if(b.cd>0){b.cd-=dt;if(b.cd<=0)b.mesh.visible=true}b.mesh.rotation.y+=dt*2;b.mesh.position.y=1.3+Math.sin(S.t*3+b.x)*.15}
  updateWeather(dt);
  if(player.speed>10&&W.wet>.3&&Math.random()<W.wet*.6)emit(player.x-Math.sin(player.h)*1.3+(Math.random()-.5),.15,player.z-Math.cos(player.h)*1.3+(Math.random()-.5),(Math.random()-.5)*2,1+Math.random()*1.5,(Math.random()-.5)*2,.35,.8,.88,1);
  syncKarts(dt);updParticles(dt);
  if(S.phase==='menu'){S.orb+=dt*.35;const k=player;camera.position.set(k.x+Math.sin(S.orb)*11,5.5,k.z+Math.cos(S.orb)*11);camera.lookAt(k.x,1,k.z)}
  else{const k=player,cm=CAMS[cfg.cam]||CAMS[0],beh=new THREE.Vector3(-Math.sin(k.h)*cm[0],cm[1],-Math.cos(k.h)*cm[0]),tg=k.g.position.clone().add(beh);
    camera.position.lerp(tg,1-Math.pow(.0008,dt));const fov=62+(k.boost>0?10:0)+k.speed/MAX*4;if(Math.abs(camera.fov-fov)>.05){camera.fov+=(fov-camera.fov)*Math.min(1,dt*5);camera.updateProjectionMatrix()}
    if(shake>0){camera.position.x+=(Math.random()-.5)*shake;camera.position.y+=(Math.random()-.5)*shake*.6;shake=Math.max(0,shake-dt*2.2)}
    camera.lookAt(k.x,1.4,k.z)}
  sun.target.position.copy(player.g.position);sun.position.copy(player.g.position).add(new THREE.Vector3(30,55,20));
  hud(false);drawMini();
}
function engineAudio(){if(!A.ctx||!A.engG)return;const run=(S.phase==='race'||S.phase==='done'||S.phase==='count')&&!S.paused&&cfg.sound,v=run?Math.min(1,player.speed/(MAX*1.3)):0,t=A.ctx.currentTime;
  A.engG.gain.setTargetAtTime(run?.05+.06*v:0,t,.05);A.eng.frequency.setTargetAtTime(48+v*140+(player.boost>0?25:0),t,.05);A.engF.frequency.setTargetAtTime(300+v*900,t,.05);if(A.rainG)A.rainG.gain.setTargetAtTime(run?W.rain*.09:0,t,.25)}
const clock=new THREE.Clock();
function animate(){requestAnimationFrame(animate);const dt=Math.min(clock.getDelta(),.05);pollPad();if(!S.paused)update(dt);engineAudio();renderer.render(scene,camera)}
addEventListener('resize',()=>{camera.aspect=VW()/VH();camera.updateProjectionMatrix();renderer.setSize(VW(),VH())});

(async function init(){
  glbScene=await loadGLB();
  buildMenu();setSound(cfg.sound);
  toMenu();
  window.__ready=true;$('loading').style.display='none';animate();
})().catch(e=>{const l=$('loading');l.style.display='grid';l.innerHTML='حدث خطأ أثناء التشغيل<br><small>'+(e&&e.message||e)+'</small>'});
