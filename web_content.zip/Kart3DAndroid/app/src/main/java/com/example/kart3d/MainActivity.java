package com.example.kart3d;

import android.app.Activity;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.ValueCallback;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends Activity {
  private WebView w;

  /** جسر بسيط للاهتزاز من JavaScript. */
  public static class Bridge {
    private final Context c;
    Bridge(Context c) { this.c = c; }
    @SuppressWarnings("deprecation")
    @JavascriptInterface public void vibrate(int ms) {
      try {
        Vibrator v = (Vibrator) c.getSystemService(Context.VIBRATOR_SERVICE);
        if (v == null || !v.hasVibrator()) return;
        int d = Math.max(5, Math.min(ms, 300));
        if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(d, VibrationEffect.DEFAULT_AMPLITUDE));
        else v.vibrate(d);
      } catch (Exception ignored) {}
    }
  }

  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    w = new WebView(this);
    w.setBackgroundColor(Color.BLACK);
    w.setOverScrollMode(View.OVER_SCROLL_NEVER);
    w.setVerticalScrollBarEnabled(false);
    w.setHorizontalScrollBarEnabled(false);
    WebSettings s = w.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setAllowFileAccess(false);
    s.setMediaPlaybackRequiresUserGesture(false);
    w.addJavascriptInterface(new Bridge(this), "AndroidBridge");

    // تقديم ملفات assets عبر https حتى تعمل وحدات ES وfetch لملف .glb
    final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
        .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
        .build();
    w.setWebViewClient(new WebViewClient() {
      @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
        return loader.shouldInterceptRequest(r.getUrl());
      }
      @Override public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail d) {
        runOnUiThread(new Runnable() { @Override public void run() { recreate(); } });
        return true;
      }
    });
    setContentView(w);
    w.loadUrl("https://appassets.androidplatform.net/assets/index.html");
  }

  @Override public void onWindowFocusChanged(boolean hasFocus) {
    super.onWindowFocusChanged(hasFocus);
    if (!hasFocus) return;
    if (Build.VERSION.SDK_INT >= 30) {
      WindowInsetsController c = getWindow().getInsetsController();
      if (c != null) {
        c.hide(WindowInsets.Type.systemBars());
        c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
      }
    } else {
      getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
          | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN
          | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
          | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }
  }

  @Override public void onBackPressed() {
    if (w == null) { super.onBackPressed(); return; }
    w.evaluateJavascript("window.onBack?window.onBack():false", new ValueCallback<String>() {
      @Override public void onReceiveValue(String v) {
        if (!"true".equals(v)) MainActivity.super.onBackPressed();
      }
    });
  }

  @Override protected void onPause() {
    super.onPause();
    if (w != null) { w.evaluateJavascript("window.__pause&&window.__pause()", null); w.onPause(); }
  }
  @Override protected void onResume() { super.onResume(); if (w != null) w.onResume(); }
  @Override protected void onDestroy() { if (w != null) { w.destroy(); w = null; } super.onDestroy(); }
}
