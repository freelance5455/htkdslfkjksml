package com.example.kart3d;

import android.app.Activity;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.speech.tts.TextToSpeech;
import java.util.Locale;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.ValueCallback;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends Activity {
  private WebView w;
  private Bridge bridge;

  /** جسر بسيط للاهتزاز من JavaScript. */
  public static class Bridge {
    private final Context c;
    TextToSpeech tts; boolean ttsOk = false;
    Bridge(Context c) { this.c = c; }
    /** نطق عربي حقيقي عبر محرك TTS في أندرويد؛ يعيد false إن لم تتوفر لغة عربية فتعمل بدائل JS. */
    @JavascriptInterface public boolean speak(String text, float pitch, float rate) {
      try {
        if (!ttsOk || tts == null) return false;
        tts.setPitch(pitch); tts.setSpeechRate(rate);
        if (Build.VERSION.SDK_INT >= 21) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "k3d");
        else tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
        return true;
      } catch (Exception e) { return false; }
    }
    @JavascriptInterface public void stopSpeak() { try { if (tts != null) tts.stop(); } catch (Exception ignored) {} }
    @SuppressWarnings("deprecation")
    @JavascriptInterface public void vibrate(int ms) {
      try {
        Vibrator v = (Vibrator) c.getSystemService(Context.VIBRATOR_SERVICE);
        if (v == null || !v.hasVibrator()) return;
        int d = Math.max(5, Math.min(ms, 300));
        if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(d, VibrationEffect.DEFAULT_AMPLITUDE));
        else v.vibrate(d);
      } catch (Exception ignored) {}
    }
  }

  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON | WindowManager.LayoutParams.FLAG_FULLSCREEN);
    // تثبيت معدل التحديث على 60Hz: أنعم وأكثر ثباتًا من التذبذب بين 48/90/120 على الشاشات المتغيّرة
    WindowManager.LayoutParams rp = getWindow().getAttributes();
    rp.preferredRefreshRate = 60f;
    getWindow().setAttributes(rp);
    // ملء الشاشة بالكامل: الرسم خلف أشرطة النظام وحول القصّة (النوتش)
    if (Build.VERSION.SDK_INT >= 30) getWindow().setDecorFitsSystemWindows(false);
    if (Build.VERSION.SDK_INT >= 28) {
      WindowManager.LayoutParams lp = getWindow().getAttributes();
      lp.layoutInDisplayCutoutMode = Build.VERSION.SDK_INT >= 30
          ? WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
          : WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
      getWindow().setAttributes(lp);
    }
    getWindow().setStatusBarColor(Color.TRANSPARENT);
    getWindow().setNavigationBarColor(Color.TRANSPARENT);
    w = new WebView(this);
    w.setBackgroundColor(Color.BLACK);
    w.setLayerType(View.LAYER_TYPE_HARDWARE, null);   // تسريع عتادي لطبقة WebView
    w.setOverScrollMode(View.OVER_SCROLL_NEVER);
    w.setVerticalScrollBarEnabled(false);
    w.setHorizontalScrollBarEnabled(false);
    WebSettings s = w.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setAllowFileAccess(false);
    s.setMediaPlaybackRequiresUserGesture(false);
    final Bridge br = new Bridge(this);
    br.tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
      @Override public void onInit(int st) {
        if (st != TextToSpeech.SUCCESS) return;
        int r = br.tts.setLanguage(new Locale("ar"));
        br.ttsOk = (r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED);
      }
    });
    bridge = br;
    w.addJavascriptInterface(br, "AndroidBridge");

    // تقديم ملفات assets عبر https حتى تعمل وحدات ES وfetch لملف .glb
    final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
        .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
        .build();
    w.setWebViewClient(new WebViewClient() {
      @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
        return loader.shouldInterceptRequest(r.getUrl());
      }
      @Override public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail d) {
        runOnUiThread(new Runnable() { @Override public void run() { recreate(); } });
        return true;
      }
    });
    setContentView(w);
    // إعادة إخفاء الأشرطة تلقائيًا إذا ظهرت (سحب من الحافة)
    getWindow().getDecorView().setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
      @Override public android.view.WindowInsets onApplyWindowInsets(View v, android.view.WindowInsets insets) {
        v.post(new Runnable() { @Override public void run() { hideBars(); } });
        return v.onApplyWindowInsets(insets);
      }
    });
    w.loadUrl("https://appassets.androidplatform.net/assets/index.html");
  }

  private void hideBars() {
    if (Build.VERSION.SDK_INT >= 30) {
      WindowInsetsController c = getWindow().getInsetsController();
      if (c != null) {
        c.hide(WindowInsets.Type.systemBars());
        c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
      }
    } else {
      getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
          | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN
          | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
          | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }
  }

  @Override public void onWindowFocusChanged(boolean hasFocus) {
    super.onWindowFocusChanged(hasFocus);
    if (hasFocus) hideBars();
  }

  @Override public void onBackPressed() {
    if (w == null) { super.onBackPressed(); return; }
    w.evaluateJavascript("window.onBack?window.onBack():false", new ValueCallback<String>() {
      @Override public void onReceiveValue(String v) {
        if (!"true".equals(v)) MainActivity.super.onBackPressed();
      }
    });
  }

  @Override protected void onPause() {
    super.onPause();
    if (bridge != null) bridge.stopSpeak();
    if (w != null) { w.evaluateJavascript("window.__pause&&window.__pause()", null); w.onPause(); }
  }
  @Override protected void onResume() { super.onResume(); hideBars(); if (w != null) w.onResume(); }
  @Override protected void onDestroy() { if (bridge != null && bridge.tts != null) { bridge.tts.stop(); bridge.tts.shutdown(); } if (w != null) { w.destroy(); w = null; } super.onDestroy(); }
}
