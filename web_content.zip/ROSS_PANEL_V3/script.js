const toggles = [...document.querySelectorAll('.toggle')];
const counter = document.getElementById('activeCount');

function updateCount() {
  const active = toggles.filter(button => button.getAttribute('aria-pressed') === 'true').length;
  counter.textContent = `${active} ACTIVE`;
}

toggles.forEach(button => {
  button.addEventListener('click', () => {
    const enabled = button.getAttribute('aria-pressed') !== 'true';
    button.setAttribute('aria-pressed', String(enabled));
    button.textContent = enabled ? 'ON' : 'OFF';
    updateCount();
  });
});

document.getElementById('resetBtn').addEventListener('click', () => {
  toggles.forEach(button => {
    button.setAttribute('aria-pressed', 'false');
    button.textContent = 'OFF';
  });
  updateCount();
});

updateCount();
