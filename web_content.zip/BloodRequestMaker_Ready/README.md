# Blood Request Maker

A simple Android app for creating a 9:16 blood-request poster and saving/sharing it.

Features:
- No login
- No database or cloud storage
- Patient name, hospital/place, blood group, city, full address, phone/WhatsApp
- 9:16 PNG poster
- Save to Pictures/BloodRequestMaker
- Android share sheet
- AdMob interstitial shown before save/share
- GitHub Actions workflow builds a debug APK

Important: the included AdMob IDs are Google's TEST IDs. Replace them with your own AdMob IDs before publishing.
