# AdMob configuration

This build intentionally uses Google's official test App ID and test interstitial ID so it can be tested safely.

Before publishing on Google Play, replace:

1. In `app/src/main/AndroidManifest.xml`, the `com.google.android.gms.ads.APPLICATION_ID` value with your own AdMob App ID.
2. In `MainActivity.java`, `TEST_INTERSTITIAL` with your own Interstitial Ad Unit ID.

Google's test interstitial ID is `ca-app-pub-3940256099942544/1033173712` and must not be used for monetization in a published app.
