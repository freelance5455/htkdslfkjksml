# Privacy Policy — Blood Request Maker

Last updated: [DATE]

Blood Request Maker creates blood-request poster images on the user's device. The app does not require an account and does not use a cloud database for blood requests.

The app includes Google Mobile Ads (AdMob). Google may collect and use device and advertising information to provide and measure ads according to Google's policies. Before publishing, replace this template with a complete privacy policy that accurately reflects your final app configuration and your AdMob/consent settings.

Contact: [YOUR EMAIL]
