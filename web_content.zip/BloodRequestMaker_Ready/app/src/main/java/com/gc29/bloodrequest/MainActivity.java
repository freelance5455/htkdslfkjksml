package com.gc29.bloodrequest;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.LoadAdError;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private static final String TEST_INTERSTITIAL = "ca-app-pub-3940256099942544/1033173712";
    private WebView web;
    private InterstitialAd interstitialAd;
    private Runnable pendingAction;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MobileAds.initialize(this, status -> loadInterstitial());

        web = new WebView(this);
        web.setWebViewClient(new WebViewClient());
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        web.addJavascriptInterface(new AppBridge(), "AndroidApp");
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);
    }

    private void loadInterstitial() {
        AdRequest request = new AdRequest.Builder().build();
        InterstitialAd.load(this, TEST_INTERSTITIAL, request,
            new InterstitialAdLoadCallback() {
                @Override public void onAdLoaded(InterstitialAd ad) {
                    interstitialAd = ad;
                    interstitialAd.setFullScreenContentCallback(new com.google.android.gms.ads.FullScreenContentCallback() {
                        @Override public void onAdDismissedFullScreenContent() {
                            interstitialAd = null;
                            runPendingAction();
                            loadInterstitial();
                        }
                        @Override public void onAdFailedToShowFullScreenContent(AdError error) {
                            interstitialAd = null;
                            runPendingAction();
                            loadInterstitial();
                        }
                    });
                }
                @Override public void onAdFailedToLoad(LoadAdError error) {
                    interstitialAd = null;
                }
            });
    }

    private void withAd(Runnable action) {
        pendingAction = action;
        if (interstitialAd != null) {
            interstitialAd.show(this);
        } else {
            runPendingAction();
            loadInterstitial();
        }
    }

    private void runPendingAction() {
        Runnable action = pendingAction;
        pendingAction = null;
        if (action != null) action.run();
    }

    private Bitmap decodeDataUrl(String dataUrl) {
        try {
            String base64 = dataUrl.substring(dataUrl.indexOf(',') + 1);
            byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
            return BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
        } catch (Exception e) { return null; }
    }

    private void saveToGallery(Bitmap bitmap) {
        String name = "blood-request-" + System.currentTimeMillis() + ".png";
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.DISPLAY_NAME, name);
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
        values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/BloodRequestMaker");
        Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        if (uri == null) { Toast.makeText(this, "تصویر محفوظ نہیں ہو سکی", Toast.LENGTH_SHORT).show(); return; }
        try (OutputStream out = getContentResolver().openOutputStream(uri)) {
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
            Toast.makeText(this, "پوسٹر فون میں محفوظ ہوگیا", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            getContentResolver().delete(uri, null, null);
            Toast.makeText(this, "تصویر محفوظ نہیں ہو سکی", Toast.LENGTH_SHORT).show();
        }
    }

    private void shareBitmap(Bitmap bitmap) {
        try {
            File dir = new File(getCacheDir(), "shared");
            if (!dir.exists()) dir.mkdirs();
            File file = new File(dir, "blood-request.png");
            try (FileOutputStream out = new FileOutputStream(file)) {
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
            }
            Uri uri = FileProvider.getUriForFile(this, "com.gc29.bloodrequest.fileprovider", file);
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("image/png");
            send.putExtra(Intent.EXTRA_STREAM, uri);
            send.putExtra(Intent.EXTRA_TEXT, "خون کی فوری ضرورت ہے — براہِ کرم مدد کریں۔");
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(send, "پوسٹر شیئر کریں"));
        } catch (Exception e) {
            Toast.makeText(this, "شیئر نہیں ہو سکا", Toast.LENGTH_SHORT).show();
        }
    }

    private class AppBridge {
        @JavascriptInterface public void savePoster(final String dataUrl) {
            final Bitmap bitmap = decodeDataUrl(dataUrl);
            if (bitmap == null) { runOnUiThread(() -> Toast.makeText(MainActivity.this, "پوسٹر تیار نہیں ہوا", Toast.LENGTH_SHORT).show()); return; }
            runOnUiThread(() -> withAd(() -> saveToGallery(bitmap)));
        }
        @JavascriptInterface public void sharePoster(final String dataUrl) {
            final Bitmap bitmap = decodeDataUrl(dataUrl);
            if (bitmap == null) { runOnUiThread(() -> Toast.makeText(MainActivity.this, "پوسٹر تیار نہیں ہوا", Toast.LENGTH_SHORT).show()); return; }
            runOnUiThread(() -> withAd(() -> shareBitmap(bitmap)));
        }
    }

    @Override protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
