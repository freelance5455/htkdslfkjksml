# Ngoding Bareng Multi-Model v2 — Android WebView

## Isi paket
- `index.html`: UI untuk WebView, enam profil visual AI, riwayat chat lokal, ringkasan proyek, dan URL backend.
- `server.js`: backend Node.js yang kompatibel dengan format request dari `index.html`, menggunakan OpenRouter.
- `package.json`: perintah untuk menjalankan server.
- `.env.example`: contoh variabel lingkungan. Jangan unggah API key ke HTML atau APK.

## Penting: profil bukan enam model berbeda
Flash, GPT · Seimbang, Claude · Analitis, Reviewer, Coder, dan Creative adalah profil gaya kerja. Backend contoh memakai OpenRouter untuk semuanya. Untuk memakai provider/model yang benar-benar berbeda, tambahkan adapter provider dan mapping model di `server.js`.

## Bagian A — uji HTML di HP
1. Unduh dan ekstrak ZIP.
2. Buka `index.html` dengan editor HTML atau preview HTML yang tersedia di perangkat.
3. Coba menu Pilih mode AI, Ruang proyek, dan riwayat chat. Tanpa backend, jawaban yang muncul hanya demo lokal.

## Bagian B — hubungkan AI asli
Backend Node.js perlu dijalankan pada layanan hosting yang mendukung Node.js (bukan di WebView itu sendiri).
1. Buat akun OpenRouter dan buat API key pada dashboard resminya.
2. Deploy folder ini ke hosting Node.js yang mendukung environment variables. Upload `server.js` dan `package.json`; `index.html` boleh ikut diunggah untuk tes browser.
3. Atur environment variable `OPENROUTER_API_KEY` di dashboard hosting. Opsional: `MODEL_FAST`, `MODEL_CODER`, `MODEL_ANALYST`, dan `MODEL_REVIEWER`. Default memakai `openrouter/free`.
4. Start command: `npm start`. Gunakan Node.js 18 atau lebih baru.
5. Tes `https://ALAMAT-SERVER/api/health`. Respons sehat berbentuk JSON dengan `ok: true`; `configured` harus `true` setelah API key dipasang.
6. Di Ngoding Bareng, ketuk tombol mode saat ini → Koneksi AI → isi `https://ALAMAT-SERVER/api/chat` → Simpan koneksi.
7. Kirim pesan tes. Bila gagal, periksa URL, log hosting, kuota model, dan API key di dashboard hosting.

## Free tier dan keamanan
- `openrouter/free` mengarahkan ke model gratis yang tersedia, tetapi ketersediaan, batas permintaan, dan performa bisa berubah. Periksa halaman harga dan batas resmi OpenRouter sebelum mengandalkannya.
- Jangan masukkan `OPENROUTER_API_KEY` ke `index.html`, APK, atau percakapan publik. Simpan hanya sebagai environment variable server.
- Endpoint contoh ini memiliki CORS terbuka untuk memudahkan prototipe. Untuk aplikasi publik, tambahkan autentikasi/rate limit dan batasi origin sesuai kebutuhan.
- Kirim hanya data proyek yang memang perlu dikirim ke penyedia AI. Jangan masukkan kata sandi, token, atau informasi sensitif.

## Menaruh HTML ke APK WebView
Jika memakai app builder, cari bagian seperti **Local HTML / Assets / WebView files**, lalu masukkan `index.html` ke aset aplikasi. Jika memakai Android Studio, dokumentasi Android merekomendasikan memuat aset lokal melalui `WebViewAssetLoader` dan `https://appassets.androidplatform.net/assets/index.html`.

Untuk koneksi internet pada APK Android native, aplikasi harus memiliki izin `android.permission.INTERNET`. WebView perlu mengaktifkan JavaScript dan DOM storage untuk menjalankan UI dan menyimpan riwayat lokal. Nama menu dan langkah persis bergantung pada app builder yang digunakan.
