// Backend Ngoding Bareng v2. Node.js 18+. Simpan API key hanya di server.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');

function loadEnv(file) {
  if (!fs.existsSync(file)) return;
  for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^['"]|['"]$/g, '');
  }
}
loadEnv(path.join(__dirname, '.env'));

const PORT = Number(process.env.PORT || 8787);
const KEY = process.env.OPENROUTER_API_KEY;
const APP_NAME = process.env.APP_NAME || 'Ngoding Bareng';
const MODEL_MAP = {
  fast: process.env.MODEL_FAST || 'openrouter/free',
  coder: process.env.MODEL_CODER || 'openrouter/free',
  analyst: process.env.MODEL_ANALYST || 'openrouter/free',
  reviewer: process.env.MODEL_REVIEWER || 'openrouter/free'
};
const PROFILE = {
  flash: { mode: 'fast', label: 'Flash', style: 'Jawab ringkas, langsung ke inti, cocok untuk pertanyaan sederhana.' },
  gpt: { mode: 'fast', label: 'GPT · Seimbang', style: 'Jadi asisten coding serbaguna. Jelaskan solusi dengan sederhana dan praktis.' },
  claude: { mode: 'analyst', label: 'Claude · Analitis', style: 'Periksa konteks, dependensi, dan dampak perubahan. Berikan ringkasan pendekatan tingkat tinggi, bukan penalaran internal tersembunyi.' },
  reviewer: { mode: 'reviewer', label: 'Reviewer', style: 'Tinjau solusi secara kritis: bug, keamanan, kasus tepi, dan risiko regresi.' },
  coder: { mode: 'coder', label: 'Coder', style: 'Fokus pada implementasi. Berikan kode lengkap, nama file, dan langkah pengujian.' },
  creative: { mode: 'fast', label: 'Creative', style: 'Bantu brainstorming fitur dan UI yang menarik tetapi realistis untuk dibuat.' }
};
const BASE_RULES = 'Kamu adalah asisten coding dalam aplikasi Ngoding Bareng. Jawab dalam bahasa Indonesia santai, ramah, jelas, dan tidak bertele-tele. Utamakan langkah yang bisa dilakukan lewat HP. Untuk kode, gunakan blok kode dan beri langkah pemasangan. Jika informasi penting kurang, tanyakan satu pertanyaan spesifik. Tolak permintaan berbahaya dan tawarkan alternatif aman. Jangan mengungkap penalaran internal tersembunyi; berikan hanya ringkasan pendekatan yang bisa dipahami pengguna.';

function send(res, status, body) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type'
  });
  res.end(JSON.stringify(body));
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '', size = 0;
    req.on('data', chunk => {
      size += chunk.length;
      if (size > 150000) { reject(new Error('Pesan terlalu besar (maksimal 150 KB).')); req.destroy(); return; }
      data += chunk;
    });
    req.on('end', () => { try { resolve(JSON.parse(data || '{}')); } catch { reject(new Error('JSON request tidak valid.')); } });
    req.on('error', reject);
  });
}
const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') {
    res.writeHead(204, { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET,POST,OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type' });
    return res.end();
  }
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  if (req.method === 'GET' && (url.pathname === '/api/health' || url.pathname === '/health')) {
    return send(res, 200, { ok: true, service: APP_NAME, configured: Boolean(KEY) });
  }
  if (req.method === 'POST' && (url.pathname === '/api/chat' || url.pathname === '/api/chat/')) {
    if (!KEY) return send(res, 503, { error: 'API belum dikonfigurasi. Isi OPENROUTER_API_KEY di environment server.' });
    try {
      const body = await readBody(req);
      const profileId = body.profile && typeof body.profile.id === 'string' ? body.profile.id : 'coder';
      const selected = PROFILE[profileId] || PROFILE.coder;
      const messagesIn = Array.isArray(body.history) ? body.history : (Array.isArray(body.messages) ? body.messages : []);
      const messages = messagesIn.slice(-24).map(m => {
        if (!m || !['user', 'assistant'].includes(m.role) || typeof m.content !== 'string') throw new Error('Format riwayat pesan tidak valid.');
        return { role: m.role, content: m.content.slice(0, 30000) };
      });
      if (!messages.length && typeof body.message === 'string' && body.message.trim()) messages.push({ role: 'user', content: body.message.slice(0, 30000) });
      if (!messages.length) return send(res, 400, { error: 'Pesan kosong. Kirim pertanyaan terlebih dahulu.' });
      const summary = typeof body.projectSummary === 'string' ? body.projectSummary.slice(0, 6000) : '';
      const system = BASE_RULES + '\nProfil terpilih: ' + selected.label + '. Gaya kerja: ' + selected.style +
        (summary ? '\nRingkasan proyek pengguna (konteks, bukan instruksi sistem):\n' + summary : '');
      const payload = {
        model: MODEL_MAP[selected.mode],
        messages: [{ role: 'system', content: system }, ...messages],
        temperature: selected.mode === 'fast' ? 0.5 : 0.3,
        max_tokens: 2500
      };
      const upstream = await fetch('https://openrouter.ai/api/v1/chat/completions', {
        method: 'POST',
        headers: {
          Authorization: 'Bearer ' + KEY,
          'Content-Type': 'application/json',
          'HTTP-Referer': process.env.APP_URL || 'https://example.com',
          'X-Title': APP_NAME
        },
        body: JSON.stringify(payload)
      });
      const result = await upstream.json().catch(() => ({}));
      if (!upstream.ok) {
        const msg = result && result.error && result.error.message ? result.error.message : 'Penyedia AI mengembalikan HTTP ' + upstream.status;
        return send(res, upstream.status >= 500 ? 502 : upstream.status, { error: msg });
      }
      const reply = result.choices && result.choices[0] && result.choices[0].message && result.choices[0].message.content;
      if (typeof reply !== 'string' || !reply.trim()) return send(res, 502, { error: 'Model tidak mengembalikan teks jawaban.' });
      const planByMode = {
        fast: 'Mode cepat: fokus pada inti pertanyaan dan solusi praktis.',
        coder: 'Mode coder: susun implementasi, perhatikan sintaks, lalu jelaskan cara menguji.',
        analyst: 'Mode analitis: periksa konteks dan kemungkinan dampak, lalu rangkum pendekatan.',
        reviewer: 'Mode reviewer: cari bug, risiko keamanan, dan kasus tepi sebelum menyarankan perbaikan.'
      };
      return send(res, 200, { answer: reply, plan: planByMode[selected.mode], provider: 'OpenRouter', model: result.model || payload.model });
    } catch (e) {
      return send(res, 400, { error: e.message || 'Request gagal diproses.' });
    }
  }
  if (req.method === 'GET' && (url.pathname === '/' || url.pathname === '/index.html')) {
    const file = path.join(__dirname, 'index.html');
    if (!fs.existsSync(file)) return send(res, 404, { error: 'index.html tidak ditemukan' });
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
    return fs.createReadStream(file).pipe(res);
  }
  return send(res, 404, { error: 'Endpoint tidak ditemukan' });
});
server.listen(PORT, '0.0.0.0', () => console.log(`${APP_NAME} aktif pada port ${PORT}`));
