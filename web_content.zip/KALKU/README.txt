KALKU - Prototype
1. Ouvri index.html nan navigatè telefòn nan.
2. Sou Chrome Android: meni ⋮ > Add to Home screen / Ajoute sou ekran dakèy.
3. Ikòn lan ka parèt kòm yon aplikasyon web sou telefòn nan.
