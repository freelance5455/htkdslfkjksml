# Socle 2.7 — Clauses contractuelles, marché des transferts et immersion visuelle

## Contrats des damistes
- Ajout d'une clause libératoire, d'une prime d'apparition, d'une prime de fidélité, d'une revalorisation annuelle plafonnée à 20 % et d'une clause de non-transfert.
- La signature conserve les clauses négociées, la saison de signature et la saison d'expiration.
- La signature alimente le journal de carrière et renforce le moral du damiste.
- Les montants de demande restent des estimations de simulation, pas des barèmes historiques.

## Marché des transferts
- Les offres sont initiées depuis le club dirigé vers un autre club.
- Le moteur utilise un échange damiste contre damiste, avec indemnité facultative, afin de préserver la règle de deux damistes exactement par club.
- Le club vendeur accepte selon la valeur sportive reçue et la compensation, ou selon la clause libératoire du damiste ciblé.
- Les clauses de non-transfert sont respectées tant que la clause libératoire applicable n'est pas atteinte.
- La finalisation déplace les joueurs et leurs contrats, transfère l'indemnité, recalcule les masses salariales et met à jour le moral et la confiance de la direction.
- Les transferts sont idempotents et archivés dans l'historique des décisions du manager.

## Immersion visuelle
- Ajout d'une commande de vue immersive sur le damier : perspective CSS accentuée, inclinaison, profondeur visuelle et ombres renforcées.
- Cette vue reste une amélioration 2.5D du plateau. Elle ne constitue pas encore un moteur 3D temps réel photoréaliste avec personnages animés, stades modélisés et caméra libre.

## Préservation
- Les huit moteurs de compétition ont été comparés par empreinte SHA-256 avec le Socle 2.6 : fichiers inchangés.
- Les effectifs sont toujours validés à exactement deux damistes par club.
- Les nouvelles propriétés de gestion sont ajoutées par migration douce des sauvegardes.

## Vérifications
- 162 tests automatisés réussis.
- Syntaxe de tous les fichiers JavaScript contrôlée avec `node --check`.
- Le test navigateur headless n'a pas abouti dans l'environnement de validation ; la vérification visuelle complète reste donc à effectuer.
