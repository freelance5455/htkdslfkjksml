ULTRA TECH — Android UI assets v1.1
===================================
This is the full existing HTML/CSS/JS dashboard UI with its assets, ready for an Android WebView/HTML-to-APK workflow; it is NOT a compiled APK or native XML app.

To use login, data, and WebSocket, load the UI through the server at http://YOUR_SERVER:21090/app (same origin), or adapt the WebView wrapper to keep the same-origin authentication/session/API paths. Simply opening index.html with file:// is not a working server integration.

New: logout button in the three-dot tools menu redirects to login after successful server logout; project token copy button in project arrangement mode.
No existing widgets or layout assets removed.
