ABDXSensi Heavy

Open index.html in a modern Android browser.
Features:
- Three independent sections: Heavy/High, Panel/Abnormal, Brazilian.
- Brand/model search with device-aware deterministic profiles and fallback.
- Separate Free Fire and Free Fire MAX generation.
- Generate, Copy, Save, Load and Clear saved profiles.
- Device Settings and DPI recommendation.
- Offline: no external libraries or network required.

This is a fan-made sensitivity guide. It does not modify Free Fire files or provide automatic headshots.
