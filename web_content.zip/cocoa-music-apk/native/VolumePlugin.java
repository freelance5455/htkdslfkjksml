package com.cocoa.music;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.AudioManager;
import android.os.Build;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "Volume")
public class VolumePlugin extends Plugin {
    private AudioManager am;
    private BroadcastReceiver receiver;

    @Override
    public void load() {
        am = (AudioManager) getContext().getSystemService(Context.AUDIO_SERVICE);
        receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context c, Intent i) {
                int type = i.getIntExtra("android.media.EXTRA_VOLUME_STREAM_TYPE", -1);
                if (type == AudioManager.STREAM_MUSIC) {
                    notifyListeners("volume", state());
                }
            }
        };
        IntentFilter f = new IntentFilter("android.media.VOLUME_CHANGED_ACTION");
        if (Build.VERSION.SDK_INT >= 33) {
            getContext().registerReceiver(receiver, f, Context.RECEIVER_EXPORTED);
        } else {
            getContext().registerReceiver(receiver, f);
        }
    }

    private JSObject state() {
        int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        int cur = am.getStreamVolume(AudioManager.STREAM_MUSIC);
        JSObject o = new JSObject();
        o.put("value", max > 0 ? ((double) cur) / max : 0.0);
        o.put("max", max);
        return o;
    }

    @PluginMethod
    public void get(PluginCall call) {
        call.resolve(state());
    }

    @PluginMethod
    public void set(PluginCall call) {
        Double v = call.getDouble("value");
        if (v == null) {
            call.reject("value required");
            return;
        }
        try {
            int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
            double clamped = Math.max(0.0, Math.min(1.0, v));
            am.setStreamVolume(AudioManager.STREAM_MUSIC, (int) Math.round(clamped * max), 0);
        } catch (Exception e) {
            // игнорируем (например, режим «не беспокоить»)
        }
        call.resolve(state());
    }

    @Override
    protected void handleOnDestroy() {
        try {
            getContext().unregisterReceiver(receiver);
        } catch (Exception e) {
            // уже снят
        }
    }
}
