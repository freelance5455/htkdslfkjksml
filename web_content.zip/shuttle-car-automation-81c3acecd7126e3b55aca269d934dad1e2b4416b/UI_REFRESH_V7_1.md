# Shuttle Car Automation — UI Refresh v7.1 CAD Edition

## Interface changes
- Reworked the visual language toward a precision industrial CAD workstation: drafting grids, orthographic cues, mechanical copper accents, clearer hierarchy and tighter navigation.
- Refined the main dashboard hero, equipment visualization stage, metric cards, navigation rail and responsive layout.
- Added a persistent print action in the top application bar. It prints the currently displayed operational page / allows the system print dialog to save as PDF.
- Removed the Reports Center from navigation and removed its page, daily-report archive and report-generation controls from the user interface.
- Kept operational records, local backup/restore, equipment, batteries, faults, maintenance, connectivity and security workflows intact.

## Important engineering boundary
The 3D assemblies remain illustrative reference models unless replaced with approved OEM drawings and verified dimensions. The visual refresh does not create a live PLC connection or turn unverified values into telemetry.

## Validation note
Source-level UI changes are included. A production build and Android APK were not generated in this environment because dependency installation did not complete before the package manager timed out. Run `npm ci`, `npm run check`, `npm test`, and `npm run build` in the repository CI or a Node environment matching the package engine requirements before installing an APK.
