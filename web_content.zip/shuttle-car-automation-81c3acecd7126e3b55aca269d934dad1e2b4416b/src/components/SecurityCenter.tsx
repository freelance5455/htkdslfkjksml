import { FormEvent, useEffect, useMemo, useState } from 'react';
import type { Language, Role, User } from '../types';
import { canPerformAction } from '../security/permissions';
import StorageMigrationPanel from './StorageMigrationPanel';
import StorageMigrationRollbackPanel from './StorageMigrationRollbackPanel';
import { appendAuditRecordAsync, archiveAuditRecordsAsync, auditRecordsToCsv, filterAuditRecords, readAllAuditRecordsAsync, readAuditArchivesAsync, verifyAuditLedgerAsync, type AuditRecord } from '../security/auditLog';
import {
  authenticateLocalAccountAsync,
  createLocalAccountAsync,
  endLocalSession,
  listLocalAccountsAsync,
  localAccountRegistryErrorAsync,
  updateLocalAccountAsync,
  setLocalAccountDisabledAsync,
  changeLocalAccountPasswordAsync,
  generateTemporaryPassword,
  type LocalAccountSummary
} from '../security/localAuth';

const roles: Role[] = ['Admin', 'Supervisor', 'Maintenance Engineer', 'Technician', 'Operator', 'Viewer'];

export default function SecurityCenter({
  language,
  currentUser,
  onSessionChange,
  beforeStorageOperation,
  onStorageLockChange,
  onStorageMigrationComplete
}: {
  language: Language;
  currentUser: User;
  onSessionChange: (user: User | null) => void;
  beforeStorageOperation?: () => Promise<void>;
  onStorageLockChange?: (locked: boolean) => void;
  onStorageMigrationComplete?: () => void;
}) {
  const ar = language === 'ar';
  const [accounts, setAccounts] = useState<LocalAccountSummary[]>([]);
  const [registryError, setRegistryError] = useState<string | null>(null);
  const [accountsReady, setAccountsReady] = useState(false);
  const [auditIntegrity, setAuditIntegrity] = useState<{
    valid: boolean;
    activeChecked: number;
    archivedChecked: number;
    archiveCount: number;
    brokenArchiveIndex: number | null;
    brokenRecordIndex: number | null;
    reason?: string;
  } | null>(null);
  const [auditRecords, setAuditRecords] = useState<AuditRecord[]>([]);
  const [auditQuery, setAuditQuery] = useState('');
  const [auditActionFilter, setAuditActionFilter] = useState('');
  const [auditEntityFilter, setAuditEntityFilter] = useState('');
  const [auditBusy, setAuditBusy] = useState(false);
  const [login, setLogin] = useState({ identity: '', password: '' });
  const [newAccount, setNewAccount] = useState({ name: '', email: '', username: '', role: 'Maintenance Engineer' as Role, password: '', confirm: '' });
  const [editingAccountId, setEditingAccountId] = useState<string | null>(null);
  const [accountDraft, setAccountDraft] = useState({ name: '', email: '', username: '', role: 'Viewer' as Role });
  const [temporaryPasswordNotice, setTemporaryPasswordNotice] = useState<{ username: string; password: string } | null>(null);
  const [passwordForm, setPasswordForm] = useState({ current: '', next: '', confirm: '' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [securityTab, setSecurityTab] = useState<'users' | 'audit' | 'storage' | 'settings'>('users');
  const isAuthenticated = currentUser.isAuthenticated;
  const isAdministrator = isAuthenticated && !currentUser.mustChangePassword && (currentUser.role === 'Super Admin' || currentUser.role === 'Admin');
  const isSuperAdmin = isAuthenticated && !currentUser.mustChangePassword && currentUser.role === 'Super Admin';
  const canBootstrap = accountsReady && accounts.length === 0 && !registryError;
  const canManageAccounts = canBootstrap || (!registryError && isAuthenticated && !currentUser.mustChangePassword && currentUser.role === 'Super Admin');

  const refresh = async () => {
    try {
      const [nextAccounts, nextRegistryError] = await Promise.all([
        listLocalAccountsAsync(),
        localAccountRegistryErrorAsync()
      ]);
      setAccounts(nextAccounts);
      setRegistryError(nextRegistryError);
    } catch (reason) {
      setAccounts([]);
      setRegistryError(reason instanceof Error ? reason.message : 'Local account registry is unavailable.');
    } finally {
      setAccountsReady(true);
    }

    try {
      const result = await verifyAuditLedgerAsync();
      setAuditIntegrity(result);
      setAuditRecords(result.valid ? await readAllAuditRecordsAsync() : []);
    } catch (reason) {
      setAuditIntegrity({
        valid: false, activeChecked: 0, archivedChecked: 0, archiveCount: 0,
        brokenArchiveIndex: null, brokenRecordIndex: null,
        reason: reason instanceof Error ? reason.message : 'Audit ledger could not be read.'
      });
      setAuditRecords([]);
    }
  };

  useEffect(() => { void refresh(); }, []);

  const recentAudit = useMemo(() => filterAuditRecords(auditRecords, {
    query: auditQuery, action: auditActionFilter, entityType: auditEntityFilter
  }).slice(-100).reverse(), [auditRecords, auditQuery, auditActionFilter, auditEntityFilter]);

  const auditActions = useMemo(() => [...new Set(auditRecords.map(record => record.action))].sort(), [auditRecords]);
  const auditEntities = useMemo(() => [...new Set(auditRecords.map(record => record.entityType))].sort(), [auditRecords]);

  const downloadAuditFile = (fileName: string, content: string, mimeType: string) => {
    const url = URL.createObjectURL(new Blob([content], { type: mimeType }));
    const link = document.createElement('a');
    link.href = url;
    link.download = fileName;
    link.click();
    URL.revokeObjectURL(url);
  };

  const exportAuditJson = async () => {
    setAuditBusy(true);
    setError('');
    try {
      const integrity = await verifyAuditLedgerAsync();
      if (!integrity.valid) throw new Error(integrity.reason || 'Audit ledger integrity verification failed.');
      const [records, archives] = await Promise.all([
        readAllAuditRecordsAsync(),
        readAuditArchivesAsync()
      ]);
      downloadAuditFile(
        `shuttle-audit-ledger-${new Date().toISOString().replace(/[:.]/g, '-')}.json`,
        JSON.stringify({ format: 'shuttle-audit-ledger-export', exportedAt: new Date().toISOString(), integrity, archiveCount: archives.length, archives, records }, null, 2),
        'application/json'
      );
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'Audit JSON export failed.');
    } finally {
      setAuditBusy(false);
      await refresh();
    }
  };

  const exportAuditCsv = async () => {
    setAuditBusy(true);
    setError('');
    try {
      const integrity = await verifyAuditLedgerAsync();
      if (!integrity.valid) throw new Error(integrity.reason || 'Audit ledger integrity verification failed.');
      const records = await readAllAuditRecordsAsync();
      downloadAuditFile(`shuttle-audit-ledger-${new Date().toISOString().replace(/[:.]/g, '-')}.csv`, auditRecordsToCsv(records), 'text/csv;charset=utf-8');
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'Audit CSV export failed.');
    } finally {
      setAuditBusy(false);
      await refresh();
    }
  };

  const archiveActiveAudit = async () => {
    if (!isAuthenticated || currentUser.role !== 'Super Admin') {
      setError(ar ? 'أرشفة سجل التدقيق متاحة للمسؤول الأعلى فقط.' : 'Only the Super Admin can archive the active audit ledger.');
      return;
    }
    const accepted = window.confirm(ar
      ? 'سيتم نقل جميع أحداث السجل النشط إلى أرشيف مترابط ببصمة SHA-256. لن تُحذف السجلات. هل تريد المتابعة؟'
      : 'Archive all active audit events into a SHA-256 chained archive? Records are retained, not deleted. Continue?');
    if (!accepted) return;
    setAuditBusy(true);
    setError('');
    try {
      const archive = await archiveAuditRecordsAsync();
      downloadAuditFile(
        `shuttle-audit-archive-${archive.id}.json`,
        JSON.stringify({ format: 'shuttle-audit-archive-export', exportedAt: new Date().toISOString(), archive }, null, 2),
        'application/json'
      );
      await refresh();
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'Audit archive failed. Original records were retained when recovery was possible.');
      await refresh();
    } finally {
      setAuditBusy(false);
    }
  };

  const submitLogin = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError('');
    setBusy(true);
    try {
      const result = await authenticateLocalAccountAsync(login.identity, login.password);
      if (!result.ok) {
        const message = result.reason === 'locked'
          ? (ar ? 'تم إيقاف المحاولات مؤقتًا لمدة دقيقة.' : 'Sign-in is temporarily locked for one minute.')
          : result.reason === 'disabled'
            ? (ar ? 'هذا الحساب معطل. اطلب من المسؤول الأعلى إعادة تفعيله.' : 'This account is disabled. Ask the Super Admin to reactivate it.')
            : (ar ? 'اسم المستخدم أو كلمة المرور غير صحيحة.' : 'The username/email or password is incorrect.');
        setError(message);
        return;
      }
      await appendAuditRecordAsync({
        actorId: result.account.id, actorRole: result.account.role, action: 'LOCAL_LOGIN',
        entityType: 'account', entityId: result.account.id,
        detail: result.session.mustChangePassword ? 'Local device session started; password change is required.' : 'Local device session started.'
      });
      onSessionChange({
        id: result.account.id, name: result.account.name, email: result.account.email,
        role: result.account.role, isAuthenticated: true, mustChangePassword: result.session.mustChangePassword
      });
      setLogin({ identity: '', password: '' });
      setError(result.session.mustChangePassword
        ? (ar ? 'كلمة المرور مؤقتة. غيّرها الآن قبل استخدام بقية التطبيق.' : 'This is a temporary password. Change it now before using the rest of the application.')
        : '');
      await refresh();
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : (ar ? 'تعذر تسجيل الدخول.' : 'Sign-in failed.'));
    } finally {
      setBusy(false);
    }
  };

  const submitCreate = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError('');
    if (newAccount.password !== newAccount.confirm) {
      setError(ar ? 'تأكيد كلمة المرور غير مطابق.' : 'Password confirmation does not match.');
      return;
    }
    if (!canManageAccounts) {
      setError(ar ? 'إنشاء الحسابات متاح للمسؤول الأعلى فقط.' : 'Only an authenticated Super Admin can create additional local accounts.');
      return;
    }
    setBusy(true);
    try {
      const actor = canBootstrap ? undefined : { id: currentUser.id, role: currentUser.role };
      await appendAuditRecordAsync({
        actorId: canBootstrap ? 'LOCAL-BOOTSTRAP' : currentUser.id,
        actorRole: canBootstrap ? 'Super Admin' : currentUser.role,
        action: canBootstrap ? 'LOCAL_ADMIN_BOOTSTRAP_REQUESTED' : 'LOCAL_ACCOUNT_CREATE_REQUESTED',
        entityType: 'account', entityId: newAccount.username.trim().toLowerCase(),
        detail: `Local account provisioning requested for ${newAccount.username}.`
      });
      const account = await createLocalAccountAsync({
        name: newAccount.name, email: newAccount.email, username: newAccount.username,
        role: canBootstrap ? 'Super Admin' : newAccount.role, password: newAccount.password
      }, globalThis.crypto, new Date(), actor);
      await appendAuditRecordAsync({
        actorId: canBootstrap ? account.id : currentUser.id,
        actorRole: canBootstrap ? 'Super Admin' : currentUser.role,
        action: canBootstrap ? 'LOCAL_ADMIN_BOOTSTRAPPED' : 'LOCAL_ACCOUNT_CREATED',
        entityType: 'account', entityId: account.id, detail: `Created local account ${account.username}.`
      });
      if (canBootstrap) {
        const signedIn = await authenticateLocalAccountAsync(account.username, newAccount.password);
        if (signedIn.ok) {
          onSessionChange({
            id: signedIn.account.id, name: signedIn.account.name, email: signedIn.account.email,
            role: signedIn.account.role, isAuthenticated: true, mustChangePassword: false
          });
        }
      }
      setNewAccount({ name: '', email: '', username: '', role: 'Maintenance Engineer', password: '', confirm: '' });
      setError('');
      await refresh();
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : (ar ? 'تعذر إنشاء الحساب.' : 'Account creation failed.'));
    } finally {
      setBusy(false);
    }
  };

  const beginAccountEdit = (account: LocalAccountSummary) => {
    setEditingAccountId(account.id);
    setAccountDraft({ name: account.name, email: account.email, username: account.username, role: account.role });
    setTemporaryPasswordNotice(null);
  };

  const saveAccountEdit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!editingAccountId || currentUser.role !== 'Super Admin' || !isAuthenticated) return;
    setBusy(true);
    setError('');
    try {
      await appendAuditRecordAsync({
        actorId: currentUser.id, actorRole: currentUser.role, action: 'LOCAL_ACCOUNT_UPDATE_REQUESTED',
        entityType: 'account', entityId: editingAccountId, detail: 'Local account identity/role update requested.'
      });
      await updateLocalAccountAsync(editingAccountId, accountDraft, { id: currentUser.id, role: currentUser.role });
      await appendAuditRecordAsync({
        actorId: currentUser.id, actorRole: currentUser.role, action: 'LOCAL_ACCOUNT_UPDATED',
        entityType: 'account', entityId: editingAccountId, detail: 'Local account identity/role updated.'
      });
      setEditingAccountId(null);
      await refresh();
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'Account update failed.');
    } finally {
      setBusy(false);
    }
  };

  const toggleAccountStatus = async (account: LocalAccountSummary) => {
    if (!isAuthenticated || currentUser.role !== 'Super Admin') return;
    const disabling = !account.disabledAt;
    const accepted = window.confirm(ar
      ? (disabling ? `هل تريد تعطيل الحساب ${account.username}؟ سيتم إلغاء جلساته الحالية.` : `هل تريد إعادة تفعيل الحساب ${account.username}؟`)
      : (disabling ? `Disable local account ${account.username}? Existing local sessions will be invalidated.` : `Reactivate local account ${account.username}?`));
    if (!accepted) return;
    setBusy(true);
    setError('');
    try {
      await appendAuditRecordAsync({
        actorId: currentUser.id, actorRole: currentUser.role,
        action: disabling ? 'LOCAL_ACCOUNT_DISABLE_REQUESTED' : 'LOCAL_ACCOUNT_REACTIVATE_REQUESTED',
        entityType: 'account', entityId: account.id, detail: 'Account status change requested.'
      });
      await setLocalAccountDisabledAsync(account.id, disabling, { id: currentUser.id, role: currentUser.role });
      await appendAuditRecordAsync({
        actorId: currentUser.id, actorRole: currentUser.role,
        action: disabling ? 'LOCAL_ACCOUNT_DISABLED' : 'LOCAL_ACCOUNT_REACTIVATED',
        entityType: 'account', entityId: account.id, detail: 'Account status updated; credential version incremented.'
      });
      await refresh();
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'Account status update failed.');
    } finally {
      setBusy(false);
    }
  };

  const resetAccountPassword = async (account: LocalAccountSummary) => {
    if (!isAuthenticated || currentUser.role !== 'Super Admin' || account.id === currentUser.id) return;
    const accepted = window.confirm(ar
      ? `هل تريد إصدار كلمة مرور مؤقتة جديدة للحساب ${account.username}؟ ستُلغى الجلسات السابقة ويجب على المستخدم تغييرها عند الدخول.`
      : `Issue a temporary password for ${account.username}? Existing sessions will be invalidated and the user must change it at next sign-in.`);
    if (!accepted) return;
    setBusy(true);
    setError('');
    try {
      const temporaryPassword = generateTemporaryPassword();
      await appendAuditRecordAsync({
        actorId: currentUser.id, actorRole: currentUser.role, action: 'LOCAL_PASSWORD_RESET_REQUESTED',
        entityType: 'account', entityId: account.id, detail: 'Super Admin requested a temporary password reset.'
      });
      await changeLocalAccountPasswordAsync(account.id, '', temporaryPassword, { id: currentUser.id, role: currentUser.role });
      await appendAuditRecordAsync({
        actorId: currentUser.id, actorRole: currentUser.role, action: 'LOCAL_PASSWORD_RESET',
        entityType: 'account', entityId: account.id, detail: 'Temporary password issued; password change is required on next login.'
      });
      setTemporaryPasswordNotice({ username: account.username, password: temporaryPassword });
      await refresh();
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'Password reset failed.');
    } finally {
      setBusy(false);
    }
  };

  const submitPasswordChange = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!isAuthenticated) return;
    setError('');
    if (passwordForm.next !== passwordForm.confirm) {
      setError(ar ? 'تأكيد كلمة المرور الجديدة غير مطابق.' : 'New password confirmation does not match.');
      return;
    }
    if (passwordForm.next.length < 12 || passwordForm.next.length > 128) {
      setError(ar ? 'يجب أن تتكون كلمة المرور من 12 إلى 128 حرفًا.' : 'Password must contain 12–128 characters.');
      return;
    }
    setBusy(true);
    try {
      await appendAuditRecordAsync({
        actorId: currentUser.id, actorRole: currentUser.role, action: 'LOCAL_PASSWORD_CHANGE_REQUESTED',
        entityType: 'account', entityId: currentUser.id, detail: 'User initiated a password change.'
      });
      await changeLocalAccountPasswordAsync(
        currentUser.id, passwordForm.current, passwordForm.next,
        { id: currentUser.id, role: currentUser.role }
      );
      // The credential version has changed. Drop the old UI identity before
      // attempting a new session; a failed audit write must leave the user out.
      endLocalSession();
      onSessionChange(null);
      const signedIn = await authenticateLocalAccountAsync(currentUser.email, passwordForm.next);
      if (!signedIn.ok) throw new Error('Password changed, but a new local session could not be established. Sign in again.');
      await appendAuditRecordAsync({
        actorId: currentUser.id, actorRole: currentUser.role, action: 'LOCAL_PASSWORD_CHANGED',
        entityType: 'account', entityId: currentUser.id, detail: 'Password updated; previous local sessions invalidated.'
      });
      setPasswordForm({ current: '', next: '', confirm: '' });
      setError('');
      onSessionChange({
        id: signedIn.account.id, name: signedIn.account.name, email: signedIn.account.email,
        role: signedIn.account.role, isAuthenticated: true, mustChangePassword: false
      });
      await refresh();
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'Password change failed.');
    } finally {
      setBusy(false);
    }
  };

  const signOut = async () => {
    try {
      await appendAuditRecordAsync({
        actorId: currentUser.id, actorRole: currentUser.role, action: 'LOCAL_LOGOUT',
        entityType: 'account', entityId: currentUser.id, detail: 'Local device session ended.'
      });
    } catch { /* Preserve the ability to end a local session if audit storage is unavailable. */ }
    endLocalSession();
    onSessionChange(null);
    await refresh();
  };

  return <div className="security-center">
    <div className="security-overview surface-card">
      <div className="security-status-mark"><span/></div>
      <div className="security-overview-copy">
        <span className="eyebrow">LOCAL IDENTITY / ACCESS CONTROL</span>
        <h2>{ar ? 'مركز الهوية والأمان المحلي' : 'Local Identity & Security Center'}</h2>
        <p>{ar
          ? 'حسابات محلية بكلمات مرور مشتقة تشفيريًا، وجلسة مؤقتة وسجل تدقيق مترابط.'
          : 'Device-local accounts with derived password hashes, expiring sessions and a tamper-evident audit chain.'}</p>
      </div>
      <span className={'security-state-pill ' + (isAuthenticated ? 'is-authenticated' : 'is-guest')}>
        {isAuthenticated ? (ar ? 'جلسة موثقة محليًا' : 'LOCAL SESSION ACTIVE') : (ar ? 'وضع زائر' : 'GUEST / PREVIEW')}
      </span>
    </div>

    {isAdministrator && <nav className="security-management-tabs" role="tablist" aria-label={ar ? 'تبويبات مركز الأمان' : 'Security center tabs'}>
      <button type="button" role="tab" aria-selected={securityTab === 'users'} className={securityTab === 'users' ? 'selected' : ''} onClick={() => setSecurityTab('users')}>{ar ? 'المستخدمون' : 'Users'}</button>
      <button type="button" role="tab" aria-selected={securityTab === 'audit'} className={securityTab === 'audit' ? 'selected' : ''} onClick={() => setSecurityTab('audit')}>{ar ? 'سجل التدقيق' : 'Audit'}</button>
      <button type="button" role="tab" aria-selected={securityTab === 'storage'} className={securityTab === 'storage' ? 'selected' : ''} onClick={() => setSecurityTab('storage')}>{ar ? 'إدارة التخزين' : 'Storage Management'}</button>
      <button type="button" role="tab" aria-selected={securityTab === 'settings'} className={securityTab === 'settings' ? 'selected' : ''} onClick={() => setSecurityTab('settings')}>{ar ? 'الإعدادات' : 'Settings'}</button>
    </nav>}

    {isAuthenticated ? <>
      {(!isAdministrator || securityTab === 'settings') && <>
      <div className="surface-card security-session-card">
        <div><span className="eyebrow">SIGNED-IN IDENTITY</span><h3>{currentUser.name}</h3><p>{currentUser.email} · {currentUser.role}</p></div>
        <button className="btn-danger" type="button" onClick={() => void signOut()}>{ar ? 'تسجيل الخروج' : 'Sign out'}</button>
      </div>
      <form className="surface-card stack-form security-form" onSubmit={submitPasswordChange}>
        <div className="card-head"><div><span className="eyebrow">ACCOUNT CREDENTIALS</span><h3>{currentUser.mustChangePassword ? (ar ? 'يجب تغيير كلمة المرور المؤقتة' : 'Temporary password change required') : (ar ? 'تغيير كلمة المرور' : 'Change password')}</h3></div></div>
        {currentUser.mustChangePassword && <p className="security-error" role="status">{ar ? 'لا يمكنك استخدام بقية التطبيق حتى تستبدل كلمة المرور المؤقتة.' : 'The rest of the app remains locked until you replace this temporary password.'}</p>}
        <label>{ar ? 'كلمة المرور الحالية' : 'Current password'}<input type="password" value={passwordForm.current} onChange={event => setPasswordForm({ ...passwordForm, current: event.target.value })} autoComplete="current-password" minLength={12} maxLength={128} required/></label>
        <label>{ar ? 'كلمة المرور الجديدة' : 'New password'}<input type="password" value={passwordForm.next} onChange={event => setPasswordForm({ ...passwordForm, next: event.target.value })} autoComplete="new-password" minLength={12} maxLength={128} required/></label>
        <label>{ar ? 'تأكيد كلمة المرور الجديدة' : 'Confirm new password'}<input type="password" value={passwordForm.confirm} onChange={event => setPasswordForm({ ...passwordForm, confirm: event.target.value })} autoComplete="new-password" minLength={12} maxLength={128} required/></label>
        <button className="btn-primary" type="submit" disabled={busy}>{ar ? 'حفظ كلمة المرور الجديدة' : 'Update password'}</button>
      </form>
      </>}
      {isSuperAdmin && securityTab === 'users' && <form className="surface-card stack-form security-form" onSubmit={submitCreate}>
        <div className="card-head"><div><span className="eyebrow">LOCAL ACCOUNT PROVISIONING</span><h3>{ar ? 'إنشاء حساب مستخدم' : 'Create a local user account'}</h3></div></div>
        <label>{ar ? 'الاسم الكامل' : 'Full name'}<input value={newAccount.name} onChange={event => setNewAccount({ ...newAccount, name: event.target.value })} autoComplete="name" required/></label>
        <label>{ar ? 'البريد الإلكتروني' : 'Email'}<input type="email" value={newAccount.email} onChange={event => setNewAccount({ ...newAccount, email: event.target.value })} autoComplete="email" required/></label>
        <label>{ar ? 'اسم المستخدم' : 'Username'}<input value={newAccount.username} onChange={event => setNewAccount({ ...newAccount, username: event.target.value })} autoComplete="username" minLength={3} maxLength={32} pattern="[A-Za-z0-9._-]+" required/></label>
        <label>{ar ? 'الدور' : 'Role'}<select value={newAccount.role} onChange={event => setNewAccount({ ...newAccount, role: event.target.value as Role })}>{roles.map(role => <option key={role} value={role}>{role}</option>)}</select></label>
        <label>{ar ? 'كلمة مرور أولية' : 'Initial password'}<input type="password" value={newAccount.password} onChange={event => setNewAccount({ ...newAccount, password: event.target.value })} autoComplete="new-password" minLength={12} maxLength={128} required/></label>
        <label>{ar ? 'تأكيد كلمة المرور' : 'Confirm password'}<input type="password" value={newAccount.confirm} onChange={event => setNewAccount({ ...newAccount, confirm: event.target.value })} autoComplete="new-password" minLength={12} maxLength={128} required/></label>
        <button className="btn-primary" type="submit" disabled={busy || !canManageAccounts}>{ar ? 'إنشاء الحساب' : 'Create account'}</button>
      </form>}
    </> : <div className="security-forms-grid">
      <form className="surface-card stack-form security-form" onSubmit={submitLogin}>
        <div className="card-head"><div><span className="eyebrow">EXISTING LOCAL IDENTITY</span><h3>{ar ? 'تسجيل الدخول' : 'Sign in'}</h3></div></div>
        <label>{ar ? 'اسم المستخدم أو البريد الإلكتروني' : 'Username or email'}<input value={login.identity} onChange={event => setLogin({ ...login, identity: event.target.value })} autoComplete="username" required/></label>
        <label>{ar ? 'كلمة المرور' : 'Password'}<input type="password" value={login.password} onChange={event => setLogin({ ...login, password: event.target.value })} autoComplete="current-password" required/></label>
        <button className="btn-primary" type="submit" disabled={busy || accounts.length === 0 || Boolean(registryError)}>{busy ? (ar ? 'جارٍ التحقق…' : 'Verifying…') : (ar ? 'دخول آمن محلي' : 'Sign in locally')}</button>
        {accounts.length === 0 && !registryError && <p className="muted-text">{ar ? 'أنشئ حساب المسؤول الأول من النموذج المقابل لبدء استخدام تسجيل الدخول.' : 'Create the first local administrator account in the adjacent form to enable sign-in.'}</p>}
      </form>

      <form className="surface-card stack-form security-form" onSubmit={submitCreate}>
        <div className="card-head"><div><span className="eyebrow">{canBootstrap ? 'FIRST-DEVICE SETUP' : 'ACCOUNT PROVISIONING'}</span><h3>{canBootstrap ? (ar ? 'إنشاء المسؤول الأول' : 'Bootstrap first administrator') : (ar ? 'إنشاء حساب محلي' : 'Create local account')}</h3></div></div>
        <label>{ar ? 'الاسم الكامل' : 'Full name'}<input value={newAccount.name} onChange={event => setNewAccount({ ...newAccount, name: event.target.value })} autoComplete="name" required/></label>
        <label>{ar ? 'البريد الإلكتروني' : 'Email'}<input type="email" value={newAccount.email} onChange={event => setNewAccount({ ...newAccount, email: event.target.value })} autoComplete="email" required/></label>
        <label>{ar ? 'اسم المستخدم' : 'Username'}<input value={newAccount.username} onChange={event => setNewAccount({ ...newAccount, username: event.target.value })} autoComplete="username" minLength={3} maxLength={32} pattern="[A-Za-z0-9._-]+" required/></label>
        {!canBootstrap && <label>{ar ? 'الدور' : 'Role'}<select value={newAccount.role} onChange={event => setNewAccount({ ...newAccount, role: event.target.value as Role })}>{roles.map(role => <option key={role}>{role}</option>)}</select></label>}
        <label>{ar ? 'كلمة المرور (12 حرفًا على الأقل)' : 'Password (12 characters minimum)'}<input type="password" value={newAccount.password} onChange={event => setNewAccount({ ...newAccount, password: event.target.value })} autoComplete="new-password" minLength={12} maxLength={128} required/></label>
        <label>{ar ? 'تأكيد كلمة المرور' : 'Confirm password'}<input type="password" value={newAccount.confirm} onChange={event => setNewAccount({ ...newAccount, confirm: event.target.value })} autoComplete="new-password" minLength={12} maxLength={128} required/></label>
        <button className="btn-primary" type="submit" disabled={busy || !canManageAccounts}>{busy ? (ar ? 'جارٍ الحفظ…' : 'Saving…') : (ar ? 'حفظ الحساب وبدء الجلسة' : 'Save account & start session')}</button>
        {!canManageAccounts && <p className="muted-text">{ar ? 'يلزم تسجيل دخول المسؤول الأعلى لإضافة حسابات أخرى.' : 'An authenticated Super Admin must sign in before additional accounts can be provisioned.'}</p>}
      </form>
    </div>}

    {registryError && <div className="security-error" role="alert">{ar ? `توقف إنشاء الحسابات لحماية السجلات الحالية: ${registryError}` : `Account provisioning is locked to protect existing identities: ${registryError}`}</div>}
    {error && <div className="security-error" role="alert">{error}</div>}

    {(securityTab === 'audit' || securityTab === 'users' || !isAdministrator) && <div className="security-integrity-grid">
      {(!isAdministrator || securityTab === 'audit') && <section className="surface-card security-integrity-card">
        <span className="eyebrow">AUDIT CHAIN / SHA-256</span>
        <div className="integrity-heading"><h3>{ar ? 'سلامة سجل التدقيق' : 'Audit log integrity'}</h3><span className={'integrity-indicator ' + (auditIntegrity?.valid ? 'valid' : 'invalid')}/></div>
        <strong>{auditIntegrity === null ? (ar ? 'جارٍ الفحص' : 'Checking…') : auditIntegrity.valid ? (ar ? 'سلسلة السجل سليمة' : 'CHAIN VERIFIED') : (ar ? 'تم اكتشاف تغيير' : 'TAMPERING DETECTED')}</strong>
        <p>{auditIntegrity
          ? `${auditIntegrity.archivedChecked + auditIntegrity.activeChecked} ${ar ? 'سجل تم فحصه' : 'records verified'} · ${auditIntegrity.archiveCount} ${ar ? 'أرشيف' : 'archives'}`
          : (ar ? 'يتم فحص السجلات المحفوظة على هذا الجهاز.' : 'Verifying records stored on this device.')}</p>
        {auditIntegrity && !auditIntegrity.valid && <p className="security-error">{auditIntegrity.reason || (ar ? `أرشيف: ${auditIntegrity.brokenArchiveIndex ?? '—'} · سجل: ${auditIntegrity.brokenRecordIndex ?? '—'}` : `Archive: ${auditIntegrity.brokenArchiveIndex ?? '—'} · record: ${auditIntegrity.brokenRecordIndex ?? '—'}`)}</p>}
      </section>}
      {isAdministrator && securityTab === 'users' && <section className="surface-card security-integrity-card">
        <span className="eyebrow">LOCAL ACCOUNTS / DEVICE ONLY</span>
        <div className="integrity-heading"><h3>{ar ? 'الحسابات المسجلة' : 'Registered accounts'}</h3><strong>{accounts.length}</strong></div>
        {accounts.length === 0 ? <p>{ar ? 'لم يتم إنشاء حسابات بعد.' : 'No local accounts have been created yet.'}</p> : accounts.map(account => <div className="local-account-row local-account-managed-row" key={account.id}>
          <div><strong>{account.name}</strong><span>{account.username} · {account.role} · {account.disabledAt ? (ar ? 'معطل' : 'Disabled') : (ar ? 'نشط' : 'Active')}</span></div>
          {isSuperAdmin && <div className="local-account-actions">
            <button type="button" className="btn-secondary" disabled={busy} onClick={() => beginAccountEdit(account)}>{ar ? 'تعديل' : 'Edit'}</button>
            {account.id !== currentUser.id && <>
              <button type="button" className="btn-secondary" disabled={busy} onClick={() => void toggleAccountStatus(account)}>{account.disabledAt ? (ar ? 'إعادة تفعيل' : 'Reactivate') : (ar ? 'تعطيل' : 'Disable')}</button>
              <button type="button" className="btn-secondary" disabled={busy} onClick={() => void resetAccountPassword(account)}>{ar ? 'إعادة تعيين كلمة المرور' : 'Reset password'}</button>
            </>}
          </div>}
        </div>)}
      </section>}
      {!isAdministrator && isAuthenticated && <section className="surface-card security-integrity-card"><span className="eyebrow">LOCAL IDENTITY</span><h3>{ar ? 'الحساب الحالي' : 'Current account'}</h3><p>{currentUser.name} · {currentUser.role}</p></section>}
    </div>}

    {isSuperAdmin && securityTab === 'users' && editingAccountId && <form className="surface-card stack-form security-account-editor" onSubmit={saveAccountEdit}>
      <div className="card-head"><div><span className="eyebrow">ACCOUNT ADMINISTRATION</span><h3>{ar ? 'تعديل بيانات الحساب' : 'Edit local account'}</h3></div></div>
      <label>{ar ? 'الاسم' : 'Name'}<input value={accountDraft.name} onChange={event => setAccountDraft({ ...accountDraft, name: event.target.value })} required/></label>
      <label>{ar ? 'البريد الإلكتروني' : 'Email'}<input type="email" value={accountDraft.email} onChange={event => setAccountDraft({ ...accountDraft, email: event.target.value })} required/></label>
      <label>{ar ? 'اسم المستخدم' : 'Username'}<input value={accountDraft.username} onChange={event => setAccountDraft({ ...accountDraft, username: event.target.value })} minLength={3} maxLength={32} pattern="[A-Za-z0-9._-]+" required/></label>
      <label>{ar ? 'الدور' : 'Role'}<select value={accountDraft.role} onChange={event => setAccountDraft({ ...accountDraft, role: event.target.value as Role })}>{(['Super Admin', ...roles] as Role[]).map(role => <option key={role} value={role}>{role}</option>)}</select></label>
      <div className="audit-toolbar-actions">
        <button className="btn-primary" type="submit" disabled={busy}>{ar ? 'حفظ' : 'Save changes'}</button>
        <button className="btn-secondary" type="button" disabled={busy} onClick={() => setEditingAccountId(null)}>{ar ? 'إلغاء' : 'Cancel'}</button>
      </div>
    </form>}
    {isSuperAdmin && securityTab === 'users' && temporaryPasswordNotice && <section className="surface-card security-account-editor">
      <div className="card-head"><div><span className="eyebrow">ONE-TIME TEMPORARY CREDENTIAL</span><h3>{ar ? 'كلمة المرور المؤقتة' : 'Temporary password'}</h3></div></div>
      <p>{ar ? 'أرسل كلمة المرور للمستخدم عبر وسيلة آمنة. سيُطلب منه تغييرها عند تسجيل الدخول التالي. لن تظهر مرة أخرى بعد إخفائها.' : 'Deliver this password through an approved secure channel. The user must change it at next sign-in. It will not be shown again after dismissal.'}</p>
      <p><strong>{temporaryPasswordNotice.username}</strong></p>
      <code className="temporary-password-value">{temporaryPasswordNotice.password}</code>
      <button className="btn-secondary" type="button" onClick={() => setTemporaryPasswordNotice(null)}>{ar ? 'إخفاء كلمة المرور' : 'Dismiss temporary password'}</button>
    </section>}
    {isAdministrator && securityTab === 'storage' && <section className="security-storage-management" aria-label={ar ? 'إدارة التخزين' : 'Storage Management'}>
      <div className="surface-card security-storage-intro">
        <span className="eyebrow">LOCAL DATABASE / CONTROLLED OPERATIONS</span>
        <h3>{ar ? 'إدارة محرك التخزين والترحيل العكسي' : 'Storage engine and reverse migration'}</h3>
        <p>{ar ? 'لا يبدأ الترحيل تلقائيًا. إنشاء النسخة الاحتياطية وبدء الترحيل والرجوع العكسي إجراءات يدوية موثقة للمسؤول.' : 'Migration is never automatic. Backup creation, migration start and reverse migration are explicit administrator-triggered actions.'}</p>
      </div>
      <StorageMigrationPanel
        language={language}
        canMigrate={isSuperAdmin && canPerformAction(currentUser, 'settings.manage')}
        beforeBackup={beforeStorageOperation}
        onLockChange={onStorageLockChange}
        onMigrationComplete={onStorageMigrationComplete}
      />
      <StorageMigrationRollbackPanel
        language={language}
        canRollback={isSuperAdmin && canPerformAction(currentUser, 'storage.rollback')}
        beforeRollback={beforeStorageOperation}
      />
    </section>}

    {isAdministrator && securityTab === 'audit' && <section className="surface-card security-audit-list">
      <div className="card-head"><div><span className="eyebrow">AUDIT LEDGER / ARCHIVES / EXPORT</span><h3>{ar ? 'سجل التدقيق والأرشيف' : 'Audit ledger & archives'}</h3></div><span className="counter">{recentAudit.length} / {auditRecords.length}</span></div>
      <div className="audit-toolbar">
        <label>{ar ? 'بحث' : 'Search'}<input value={auditQuery} onChange={event => setAuditQuery(event.target.value)} placeholder={ar ? 'بحث في الحدث أو المستخدم أو السجل' : 'Search action, user or record'}/></label>
        <label>{ar ? 'العملية' : 'Action'}<select value={auditActionFilter} onChange={event => setAuditActionFilter(event.target.value)}><option value="">{ar ? 'كل العمليات' : 'All actions'}</option>{auditActions.map(action => <option key={action}>{action}</option>)}</select></label>
        <label>{ar ? 'نوع السجل' : 'Entity type'}<select value={auditEntityFilter} onChange={event => setAuditEntityFilter(event.target.value)}><option value="">{ar ? 'كل الأنواع' : 'All types'}</option>{auditEntities.map(entity => <option key={entity}>{entity}</option>)}</select></label>
      </div>
      <div className="audit-toolbar-actions">
        <button className="btn-secondary" type="button" disabled={auditBusy || !auditIntegrity?.valid} onClick={() => void exportAuditJson()}>{ar ? 'تصدير JSON' : 'Export JSON'}</button>
        <button className="btn-secondary" type="button" disabled={auditBusy || !auditIntegrity?.valid} onClick={() => void exportAuditCsv()}>{ar ? 'تصدير CSV' : 'Export CSV'}</button>
        {currentUser.role === 'Super Admin' && <button className="btn-primary" type="button" disabled={auditBusy || !auditIntegrity?.valid || auditIntegrity.activeChecked === 0} onClick={() => void archiveActiveAudit()}>{auditBusy ? (ar ? 'جارٍ التنفيذ…' : 'Working…') : (ar ? 'أرشفة السجل النشط' : 'Archive active ledger')}</button>}
      </div>
      {recentAudit.length === 0 ? <p className="muted-text">{ar ? 'لا توجد أحداث تطابق الفلاتر الحالية.' : 'No audit events match the current filters.'}</p> : recentAudit.map(record => <div className="audit-event-row" key={record.id}><div><strong>{record.action}</strong><span>{record.actorId} · {record.actorRole} · {record.entityType} · {record.entityId}</span>{record.detail && <small>{record.detail}</small>}</div><time>{new Intl.DateTimeFormat(ar ? 'ar-EG' : 'en-GB', { dateStyle: 'short', timeStyle: 'short' }).format(new Date(record.timestamp))}</time></div>)}
      <p className="muted-text">{ar
        ? 'الأرشيف والسجل نشطان على هذا الجهاز. تصدير JSON يحفظ بيانات الأرشيف وسلسلة البصمات؛ الاحتفاظ المحلي يظل مقيداً بسعة المتصفح ولا يمثل تخزيناً مركزياً.'
        : 'Archives and active events are stored on this device. JSON export contains archive manifests and hash chains. Local retention remains limited by browser storage quota and is not centralized storage.'}</p>
    </section>}

    {(!isAdministrator || securityTab === 'settings') && <div className="notice-inline"><span>ⓘ</span>{ar
      ? 'تنبيه: هذا نظام هوية محلي على الجهاز نفسه. لا يوفر إدارة مركزية أو استعادة حسابات أو صلاحيات خادمية؛ يجب استخدام خادم هوية وصلاحيات خلفية قبل نشر متعدد المستخدمين أو عبر الشبكة.'
      : 'Security boundary: this is device-local identity only. It does not provide centralized identity, remote revocation or server-side authorization. A shared or networked deployment requires a trusted identity provider and backend permission enforcement.'}</div>}
  </div>;
}
