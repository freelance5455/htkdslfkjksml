package com.badro.app

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.os.Environment
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.*
import android.provider.MediaStore
import android.util.Base64
import android.widget.Toast
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import android.webkit.ValueCallback
import android.net.Uri
import java.io.IOException

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private val PICK_BACKUP = 44

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.layoutParams = ViewGroup.LayoutParams(-1, -1)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.addJavascriptInterface(BadroBridge(), "BadroAndroid")
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(v: WebView?, cb: ValueCallback<Array<Uri>>?, params: FileChooserParams?): Boolean {
                fileCallback?.onReceiveValue(null); fileCallback = cb
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/json" }
                startActivityForResult(i, PICK_BACKUP); return true
            }
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class BadroBridge {
        @JavascriptInterface fun printHtml(html: String) { runOnUiThread { createPrintJob(html) } }
        @JavascriptInterface fun saveFile(base64: String, filename: String, mimeType: String) {
            Thread {
                try {
                    val bytes = Base64.decode(base64, Base64.DEFAULT)
                    val cleanName = filename.replace(Regex("[^\\p{L}\\p{N}._-]"), "_").ifBlank { "BADRO-file" }
                    val values = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, cleanName)
                        put(MediaStore.Downloads.MIME_TYPE, mimeType)
                        put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                    }
                    val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: throw IOException("تعذر إنشاء الملف")
                    contentResolver.openOutputStream(uri)?.use { it.write(bytes) } ?: throw IOException("تعذر حفظ الملف")
                    runOnUiThread { Toast.makeText(this@MainActivity, "تم حفظ الملف في مجلد التنزيلات: $cleanName", Toast.LENGTH_LONG).show() }
                } catch (e: Exception) { runOnUiThread { Toast.makeText(this@MainActivity, "فشل حفظ الملف: ${e.message}", Toast.LENGTH_LONG).show() } }
            }.start()
        }
    }

    private fun createPrintJob(html: String) {
        val printWeb = WebView(this)
        printWeb.settings.javaScriptEnabled = false
        printWeb.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                try {
                    val manager = getSystemService(PRINT_SERVICE) as PrintManager
                    val adapter = view.createPrintDocumentAdapter("BADRO-Fatwa")
                    manager.print("BADRO - PDF", adapter, PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setResolution(PrintAttributes.Resolution("pdf", "PDF", 300, 300)).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build())
                } catch (e: Exception) { Toast.makeText(this@MainActivity, "تعذر فتح حفظ PDF: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }
        printWeb.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null)
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_BACKUP) {
            val result = if (resultCode == Activity.RESULT_OK && data?.data != null) arrayOf(data.data!!) else null
            fileCallback?.onReceiveValue(result); fileCallback = null
        }
    }
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }
}
