# v78 - the freefall: smoother, softer, and scored

Removed: the film grain.

Picture (all overlay-side; the raytraced shaders are untouched):
- Real bloom: the lit frame is copied small every frame, keyed to its brights and blurred back over the picture, stronger in lightning and heat (planet limb, glass highlights and the holograms now glow).
- A faint teal-above / amber-below film grade.
- Zero-g dust and grit drifting through the window light in shots 2-5.
- Every shot now dips to black at its start and end instead of snapping (the final white-out is unchanged).
- Render resolution ~14% sharper than v77, and it now climbs back after a frame-rate stutter instead of staying low.
- A tiny "double-tap to skip" hint at the start.

Sound (rebuilt, still all synthesised in Web Audio, still renderable offline):
- Cabin reverb (generated impulse response) and stereo placement on every voice.
- A score: a slow dark chord under each of shots 1-6, a rising riser under the plunge, a soft chime as the hologram wakes, a riser into every cut and a deep boom on it.
- Stick-slip hull creaks, long metal groans, hull pings, a better two-tone alarm.
- Breathing from shot 2 on, getting faster and shallower; the heartbeat from v76 sits under it.
- Thunder now cracks, then rolls with panned reflections.
- A plasma hiss bed that grows with the heat in the plunge.
- After the white-out: the ringing in the ears, then a very low call from the deep under the closing card (the Leviathan).

Verified: syntax, full-timeline dry run with stubbed DOM / GL / Web Audio (no errors). Not verified: how it sounds and looks on a real device (loudness balance and reverb amount are the first things I would tune).
