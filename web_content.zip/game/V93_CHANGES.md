# v93: taller, more dramatic mountain ranges

Scale reminder (game.js UNITS_PER_METER): 4.25 world units = 1 real metre (the 8.5-unit player = 2 m).
Terrain comments that say "km" are really thousands of units, so the old 2.4k relief cap was only about 565 m of real relief.

## terrain_core.js
- RELIEF_CAP 2400 -> 7200, new RELIEF_KNEE 0.80 (was 0.78).
- New PEAK_GAIN = 2.3: multiplies only HIGH relief (smoothstep 700..2400), so lowlands and foothills are unchanged
  while the biggest massifs stand clear of ordinary ranges.
- Land soft cap: softCap(h, 4600, .72) from 3300  ->  softCap(h, 9400, .66) from 5200.
- MAX_MOUNTAIN_HEIGHT 10500 -> 13000 (used by chunk_core.js).
- Variety-layer fade at altitude moved from 5200..8200 to 9500..13000.
- CRAGS relief threshold 1900 -> 2600, SCREE 1500 -> 1900 (otherwise all new relief becomes crags).

## Measured (seed 424242, macro map; the units are world units)
- Tallest non-polar peak: 4373 -> 7596 (about 1.0 km -> 1.8 km real).
- Land height p99: 2673 -> 3701. p50 and p90 barely move (690 -> 696, 1598 -> 1651).
- Macro slope p99: 33 -> 38 degrees; share of land steeper than 45 degrees: 0.09% -> 0.48%.
- Micro cliff share (22-unit step): 11.3% -> 11.1% (unchanged).
- test_v59 (2 seeds) and test_chunks: NaN 0, shared chunk edges match.

## Not verified
- audit_walk.mjs fails on BOTH v92 (109/173) and v93 (149/188); not a regression signal either way.
- Nothing was rendered in a browser. Cloud lift is unchanged (cap 4000), so the tallest peaks now rise above the cloud deck.
