# v80 - the freefall: a continuous dive, audible ambience, no more whoosh

freefall_cinematic.js only.

Bugs fixed
- "Doing nothing, then suddenly very fast": shots 6-7 used the real 71 km/s on a 136,000 km planet (visually frozen), then at cloud contact the picture was stretched 250:1 (54,000 km of visual depth in 250 km of real depth). Now the camera flies ONE straight line along the velocity vector. Speed is continuous across the contact: a slow accelerating fall in shot 6, a faster one in the last 8 s before contact, then the air brakes it smoothly (exponential, 6 s) down to a slow sink. The streak particles follow the same speed. Peak/step check: 3.08 -> 3.09 -> 3.08 u/s over the contact.
- "Clouds moving away, like leaving the giant": the cloud shader offset its pattern by uFlow * view direction. uFlow was decaying, so the whole cloud field slid away from you (about 8 u/s, faster than the ship moved in). The pattern is now fixed in the world, with only a very slow weather drift; you fly through it.
- Camera now looks along the direction it travels (the old camera looked 57-degree-steep along the velocity but moved straight down), so the clouds expand from where you are heading instead of sliding sideways.
- Shake no longer steps on at cloud contact; it builds over ~2.5 s, with a single jolt at the first touch.

Sound
- Overall level: the quiet shots are about 13 dB louder than v79 (about -19 dBFS RMS instead of -32). Output chain is now compressor -> make-up -> hard limiter (peak stays below clipping).
- The old ambient bed was a 31-70 Hz drone, which laptop and phone speakers cannot play. New bed: a slowly breathing cabin tone built from partials at 110-660 Hz plus a soft air-handler murmur. Pads, riser and heartbeat got mid-range bodies for the same reason.
- The whoosh is gone: the breathing noise bursts (every 2-4 s), the noise sweep on every cut and the constant roar in shot 1 / the storm. The roar now follows the speed through the air (hit at contact, falls as the ship slows), with slow gusts instead of a flat level.
- New: a deep impact when the ship touches the air.

Not verified: real-GPU look and how it sounds on a real device (levels were measured from the offline render). Visual speed in shots 6-7 is stylised; the HUD still shows the real figures.
