# v99 - foot puffs, touch look inertia, biome arrival

- **Foot puffs:** pooled soft sprites (44, no per-puff allocation) kicked up by footfalls and landings. Sand and snow puff, mud flicks
  darker clods, wading splashes, bare stone only dusts when running; grass stays clean. Running = more, bigger, thrown backward.
  Landings throw a ring scaled by fall speed. Dimmed at dusk/night so snow doesn't glow. Code: before `updateVfxParticles`.
- **Touch look inertia:** lift your finger mid-swipe and the view coasts and settles in about 0.15 s instead of stopping dead.
  Ignored in cutscenes/tutorial/pause; a new touch cancels it. Constants: 0.85 (carry) and -7 (decay) in updatePlayer.
- **Biome arrival:** after you stay in a new biome for ~1.2 s the colour grade leans toward that biome's palette (its ground colour,
  normalised and mostly washed back to white) with a 5% lift, rising over ~1 s and easing away over ~5 s. First biome after load is
  silent. Added `arrival` / `arrivalTint` uniforms to the grade shader; peak strength is the 0.6 in the arrival block.
