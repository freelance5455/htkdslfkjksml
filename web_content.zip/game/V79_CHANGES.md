# v79 - the freefall follows real physics (~6 hours, real time inside each shot)

freefall_cinematic.js only. Distances are unchanged (1 unit = 3,400 km; giant radius 136,000 km, 167 units from the moon).

One ballistic model now drives the camera, the clock and every readout:
- Lift-off: a 3 g burn (~17 min). It cuts when the stabilizers go; after that only the giant's gravity acts.
- Giant: GM = 4.8e8 km^3/s^2 (about 3.8 Jupiter masses, ~27 m/s^2 at the cloud tops), integrated numerically.
- Sideways speed at burnout is 10 km/s, so the ship falls on a curved path: arrival at ~MET 6 h 06 min, ~71 km/s, ~57 degrees steep.
- The moon keeps orbiting the giant at ~29 km/s, so it slides about 64 degrees sideways and shrinks behind you.
- Shots sit at MET 0:00:50, 0:35, 1:40, 3:10, 4:45, 6:02, and the plunge 8 s before cloud contact. Time inside each shot runs 1:1, so the giant barely changes in a shot (it only grows across the cuts).
- Ship attitude: slow constant tumble rates (no torque, no damping in vacuum) instead of eased swoops.
- Telemetry is computed from the model: MET, altitude / distance to cloud tops, velocity in km/s, distance to the moon, g-load and depth in the plunge. The HUD no longer claims 72 hours.
- Plunge in real time: the air removes 71 km/s in ~12 s (hundreds of g, which is the point). Heat, shake, rumble and roar start only at cloud contact. Shot 6 is vacuum (no rumble or hiss).
- Stars no longer twinkle in vacuum. The engine drone plays only during the burn; the coast has only a quiet life-support hum.
- Shots are longer (30-34 s, plunge 46 s, ~246 s total) with 1.5 s cuts; lightning moved to after cloud contact.

Stylisation (flagged): the storm's visual depth is stretched so the cloud interior can be seen; readouts show the real depth.
Verified: syntax, numeric dry run of the whole timeline, 4 headless stills. Not verified: audio balance, real-GPU look, and the 3.5 min as a whole.
