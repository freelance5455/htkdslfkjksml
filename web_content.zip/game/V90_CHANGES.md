# v90 - the flower mobile, Phase 1 (door -> warehouse -> build -> drive -> arrival)
`game.js` passes a syntax check and the page loads without errors, but I could not play it (a headless full-game boot never gets past the start screen). What I did test: the warehouse movement/collision logic in Node (spawn, doorway and all six interaction points are reachable), and the cockpit overlay look in a stub page. Please playtest the whole path.

## The flow
1. **Note.** It now also says to find the overgrown hatch near the shelter. A hatch generates on dry, fairly flat land 420-600 units (a few hundred feet) from the shelter, buried in vegetation, with a waypoint + beacon. If no spot is found, the old on-foot trip is used instead.
2. **Boundary.** From the note until the vehicle is built, the player is kept within 260 units of the line between the shelter and the hatch (the AI warns, rate-limited).
3. **Warehouse** (underground, same approach as the shelter room, with its own collision): a drafting table with the **blueprint** and four parts: **levitation coil** (rusted crate, cut open with the laser, costs 6 charge), **spin bearing ring** (a dormant blue-eyed service drone wakes and hands it over), **petal panels** (the AI decodes a wall lock), **core cradle** (top shelf, hooked with the laser's tether). A HUD shows "Blueprint / Parts n/4".
4. **Assemble.** With everything, the AI marks a pad 30-60 units from the shelter; interact on it to build the **flower mobile** (a spinning ring of eight petals around a glowing pod).
5. **Drive.** Board it and drive from the inside: a petal-canopy cockpit overlay and a speed / km-to-city readout. It hovers over ground and water at about 120 units/s (boost 1.5x) with a little momentum; thrust follows your view. Warmth does not drain while driving. A save made while driving resumes driving.
6. **Story city.** The nearest city at least 7 km away; if none, the farthest. Reaching it plays the existing arrival scene, which removes the vehicle.
- New prompt: "Press E: ..." on desktop and the context button on mobile.

## Not done yet (Phase 2)
The lodged vehicle in a second warehouse entrance, the modules the AI installs as weapons, the Kefenkline ambush with a restart checkpoint, and the tracking chip that sends them to the city's main entrance. The drive is currently just a drive.
