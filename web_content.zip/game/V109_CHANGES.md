# v109 - breadcrumbs in the story text (text only; the dream and everything else untouched)

Goal: let the player start to piece the story together without being told it. No names, no relationships, no verdict on who did it, nothing the AI's final reveal needs to say first.

1. diary_page_1: adds "She sat in the second row and never once looked up. Ren wasn't in the room. Nobody would tell me whether he was kept away or stayed away." (someone close believes the verdict; Ren's absence is ambiguous)
2. diary_page_2: adds two fragments. "The streets get straighter every month and everyone says how safe it feels. Ren and I still take the crooked way home... he says the straight streets make him feel counted." (the order is wrong, and the walks matter). "I wake with my fist shut again. Ren used to tease me about it." (ties to "my hand still closed" after the dream)
3. keepsake_locket: the two sets of initials are now one engraved neatly, one scratched in afterwards, uneven, "by a hand still learning its letters". (the player can start to wonder who made it; the locket still doesn't open)
4. runTribunalScene (game.js): one new AI line after "So I stood by...": the timeline was "too clean... A real night is never that tidy." (the record was made, not found)
5. log_voyage_dream (game.js): adds "I keep turning over the small hand. It didn't pull away. It just stopped holding on." (the hearing's hand slip reads as a loss, not a rejection)

Not changed: dream_cinematic.js, the v108 waking lines, the locket mechanic, any save data.
Not verified: how the longer diary pages fit the artifact card, and the extra AI line with the browser voice. The game could not be booted here; JSON parses and game.js passes a syntax check.
Cut on purpose: naming the sister or the relationship, a line from Ren, anything that says what the locket holds.
