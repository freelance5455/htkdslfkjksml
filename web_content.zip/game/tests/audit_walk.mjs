// v56: can a player on foot actually get from the gate to places in an ordinary city? Walk BFS paths through the nav graph with the real collider.
import { TerrainCore } from '../terrain_core.js';
import * as V from '../valley_sites.js';
import { generateCity, planToCols, makeNatGrid } from '../city_core.js';
import { CityCollider } from '../city_collide.js';
import { PLANET_R } from '../planet_core.js';
const seed = +(process.argv[2] || 424242), nSites = +(process.argv[3] || 6), nT = +(process.argv[4] || 40), T = new TerrainCore(seed), o = {}, d = [0, 0, 0], sites = V.findSites(T, seed).sites.filter(s => !s.citadel);
let tot = 0, bad = 0; const H = 8.5;
for (const S of sites.slice(0, nSites)) {
  const nat3 = (x, z) => { V.localToDir(S, x, -z, d); return T.sample3(d[0] * PLANET_R, d[1] * PLANET_R, d[2] * PLANET_R, o); }, nat = makeNatGrid(S, nat3, 20), ground = (x, z) => V.valleyHeight(S, x, -z, nat(x, z));
  const city = generateCity(S, nat), cols = planToCols(city), col = new CityCollider(cols), N = city.nodes;
  const inSolid = N.map(n => col.solidAt(n.x, n.z, n.y + 1, n.y + 7));
  const bfs = (from, to) => { const prev = new Int32Array(N.length).fill(-2); prev[from] = -1; const q = [from]; for (let h = 0; h < q.length; h++) { const a = q[h]; if (a === to) break; for (const b of N[a].adj) if (prev[b] === -2 && !inSolid[b]) { prev[b] = a; q.push(b); } } if (prev[to] === -2) return null; const p = []; for (let c = to; c >= 0; c = prev[c]) p.push(c); return p.reverse(); };
  let rs = 12345 + S.id; const rnd = () => (rs = (rs * 1664525 + 1013904223) >>> 0) / 4294967296;
  let fails = 0, ok = 0; const why = {};
  for (let k = 0; k < nT; k++) {
    const to = Math.floor(rnd() * N.length), from = city.gateNode >= 0 ? city.gateNode : 0, p = bfs(from, to); if (!p || p.length < 3 || inSolid[from]) continue;
    const m = { x: N[from].x, z: N[from].z, y: N[from].y + H + 0.3 }; let good = true;
    for (const nid of p.slice(1)) {
      const tx = N[nid].x, tz = N[nid].z; let steps = 0;
      while (Math.hypot(tx - m.x, tz - m.z) > 3 && steps < 300) { steps++; const dx = tx - m.x, dz = tz - m.z, l = Math.hypot(dx, dz), px = m.x, py = m.y, pz = m.z; m.x += dx / l * 1.5; m.z += dz / l * 1.5; m.y -= 1.0; col.resolve(m, px, py, pz, H, 1.8, 1, 2.4); const g = ground(m.x, m.z); if (m.y - H <= g) m.y = g + H; }
      for (let z = 0; z < 25; z++) { const px = m.x, py = m.y, pz = m.z; m.y -= 1.0; col.resolve(m, px, py, pz, H, 1.8, 1, 2.4); const g = ground(m.x, m.z); if (m.y - H <= g) m.y = g + H; }   // settle (a steep ramp reaches the node's xz before its height)
      const dy = (m.y - H) - N[nid].y;
      if (steps >= 300) { good = false; const key = 'stuck kind' + N[nid].kind; why[key] = (why[key] || 0) + 1; if ((why[key]) === 1) console.log(`  site ${S.id} stuck going to node ${nid} kind ${N[nid].kind} at ${m.x.toFixed(0)},${m.z.toFixed(0)} y ${(m.y - H).toFixed(1)} want ${N[nid].y.toFixed(1)}`); break; }
      if (Math.abs(dy) > 9) { good = false; const key = 'height off ' + (dy > 0 ? 'above' : 'below') + ' kind' + N[nid].kind; why[key] = (why[key] || 0) + 1; if (why[key] === 1) console.log(`  site ${S.id} height ${dy.toFixed(1)} at node ${nid} kind ${N[nid].kind} (${N[nid].x.toFixed(0)},${N[nid].z.toFixed(0)})`); break; }
    }
    if (good) ok++; else fails++;
  }
  tot += ok + fails; bad += fails; console.log(`site ${S.id} ${city.arche}: walked ${ok + fails} paths, failed ${fails} ${JSON.stringify(why)}`);
}
console.log('TOTAL failed', bad, '/', tot);
