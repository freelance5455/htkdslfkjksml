import * as L from '../city_life.js';
import { mulberry } from '../valley_sites.js';
const life = { poi: { homes: Array.from({length: 50}, (_, i) => ({x:i,z:i})), works: [{x:1,z:1}], shops: [], docks: [], plazas: [] } };
const res = L.makeResidents(12345, 48, life);
console.log('names', res.slice(0,4).map(r=>`${r.name}/${r.color}/${r.job}`).join(', '), '| blue', res.filter(r=>r.color==='blue').length, 'green', res.filter(r=>r.color==='green').length, '| faction', new Set(res.map(r=>r.faction)));
console.log('city names', [1,2,3,4,5].map(L.cityName).join(', '));
for (const t of [0.1,0.25,0.4,0.55,0.7,0.85,0.95]) console.log(t, L.slotOf(t).slot);
const r = mulberry(5);
for (const md of [false, true]) { const ctx={machineDestroyed:md, night:false, cityName:'Kamo'}; console.log(md?'AFTER':'BEFORE', '|', L.greeting(res[0],ctx,r), '|', L.ambientLine(res[1],ctx,r), '|', L.chatterPair(res[0],res[1],ctx,r).join(' / ')); console.log('  empire topic:', L.topics(res[0],ctx).find(t=>t.id==='empire').reply.slice(0,70)); }
const e = L.makeEconomy(777); console.log('quote 10 wood->piezo', JSON.stringify(L.quote(e,'wood','piezoQuartz',10)), 'quote 3 piezo->wood', JSON.stringify(L.quote(e,'piezoQuartz','wood',3)));
const before = e.demand.piezoQuartz; const q = L.execute(e,'piezoQuartz','wood',5); console.log('exec', JSON.stringify(q), 'demand piezo', before.toFixed(3), '->', e.demand.piezoQuartz.toFixed(3), 'stock wood', e.stock.wood);
// no free-money loop: round trip should lose value
let a = 20; const x = L.quote(e,'wood','stone',a); const y = L.quote(e,'stone','wood',x.got); console.log('round trip wood->stone->wood', a, '->', y.got);
