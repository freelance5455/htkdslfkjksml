import { TerrainCore } from '../terrain_core.js';
import { PLANET_R } from '../planet_core.js';
const seed = +process.argv[2] || 424242, T = new TerrainCore(seed), o = {};
const W = 360, H = 180; const hs = [], st = { n: 0, land: 0, isleLand: 0, hotLand: 0, collLand: 0, sysT: [0,0,0,0], arcN: 0, trN: 0 };
for (let j = 0; j < H; j++) { const lat = (0.5 - (j + 0.5) / H) * Math.PI; if (Math.abs(lat) > 1.35) continue; const cl = Math.cos(lat);
  for (let i = 0; i < W; i++) { const lon = ((i + 0.5) / W - 0.5) * 2 * Math.PI;
    const h = T._terrain(cl * Math.sin(lon) * PLANET_R, Math.sin(lat) * PLANET_R, cl * Math.cos(lon) * PLANET_R, 1, o);
    st.n++; if (h > 0) { st.land++; hs.push(h); if (o.isle > 0.4) st.isleLand++; if (o.collAmt > 0.3) st.collLand++; }
    if (o.arcAmt > 0.15) st.arcN++; st.sysT[o.sysT]++; } }
hs.sort((a, b) => a - b); const q = p => hs[Math.floor(p * (hs.length - 1))] | 0;
console.log('land %', (100 * st.land / st.n).toFixed(1), 'height p50/p90/p99/max', q(.5), q(.9), q(.99), q(1));
console.log('isle-driven land share', (st.isleLand / st.land).toFixed(3), 'collision land share', (st.collLand / st.land).toFixed(3), 'arc zone %', (100 * st.arcN / st.n).toFixed(1), 'sysT', st.sysT.join(','));
