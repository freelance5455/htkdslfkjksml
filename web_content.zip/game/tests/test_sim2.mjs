// v53: drone behaviour metrics - overlap, shared paths, activity. Compares the new sim with the v52 sim on the same city.
import { TerrainCore } from '../terrain_core.js';
import * as V from '../valley_sites.js';
import { generateCity, planToLife, makeNatGrid } from '../city_core.js';
import { makeResidents } from '../city_life.js';
import { CitySim } from '../city_sim.js';
import { CitySim as OldSim } from './old_sim.mjs';
import { PLANET_R } from '../planet_core.js';
const seed = 424242, T = new TerrainCore(seed), o = {}, d = [0, 0, 0];
const S = V.findSites(T, seed).sites[3];
const nat = makeNatGrid(S, (x, z) => { V.localToDir(S, x, -z, d); return T.sample3(d[0] * PLANET_R, d[1] * PLANET_R, d[2] * PLANET_R, o); }, 20);
const city = generateCity(S, nat), life = planToLife(city), res = makeResidents(S.seedN, 96, life);
function run(Cls, label) {
    const sim = new Cls(life, res, { cityName: 'Test', seed: S.seedN, maxDrones: 64 }); sim.activate(0.40);
    const player = { x: 5000, z: 5000 }; let frames = 0, overlapPairs = 0, pairs = 0, walking = 0, samples = 0, nanB = 0, moved = 0, inside = 0;
    const visited = new Set(), cellHits = new Map(); let sameLine = 0, lineChecks = 0;
    const last = sim.drones.map(dr => [dr.x, dr.z]);
    for (let step = 0; step < 6000; step++) {   // 10 simulated minutes at dt 0.1 (a game day is ~9 real minutes), daytime advancing
        const dayTime = (0.40 + step * 0.1 / 555) % 1;
        sim.step(0.1, dayTime, false, false, player);
        if (step % 10) continue; frames++;
        const D = sim.drones;
        for (let i = 0; i < D.length; i++) { const a = D[i]; if (!isFinite(a.x + a.z + a.y)) nanB++; if (a.state === 'walk') walking++; samples++; moved += Math.hypot(a.x - last[i][0], a.z - last[i][1]); last[i] = [a.x, a.z];
            if (!a.asleep) { const k = Math.floor(a.x / 20) + ',' + Math.floor(a.z / 20); visited.add(k); }
            for (let j = i + 1; j < D.length; j++) { const b = D[j]; if (a.asleep && b.asleep) continue; pairs++; if (Math.hypot(a.x - b.x, a.z - b.z) < 4.5) overlapPairs++; } }
    }
    console.log(`${label}: drones ${sim.drones.length} | body overlap (<4.5u) ${(100 * overlapPairs / pairs).toFixed(3)}% of pair-samples | walking ${(100 * walking / samples).toFixed(0)}% | distinct 20u cells visited ${visited.size} | mean travel per sample ${(moved / samples).toFixed(1)}u | NaN ${nanB}`);
}
run(OldSim, 'v52 sim'); run(CitySim, 'v53 sim');
