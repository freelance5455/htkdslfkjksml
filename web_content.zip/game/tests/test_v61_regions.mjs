import { TerrainCore } from '../terrain_core.js';
import { PLANET_R } from '../planet_core.js';
for (const seed of [424242, 7, 99991]) {
  const T = new TerrainCore(seed), o = {}, W = 360, H = 180, cnt = [0,0,0,0], land = [0,0,0,0], rough = [0,0,0,0], rn = [0,0,0,0]; let nan = 0; const names = new Set(), feats = {};
  let prev = new Float32Array(W);
  for (let j = 0; j < H; j++) { const lat = (0.5 - (j + .5) / H) * Math.PI, cl = Math.cos(lat), sl = Math.sin(lat);
    for (let i = 0; i < W; i++) { const lon = ((i + .5) / W - .5) * 2 * Math.PI; const X = cl * Math.sin(lon) * PLANET_R, Y = sl * PLANET_R, Z = cl * Math.cos(lon) * PLANET_R;
      let h = T._terrain(X, Y, Z, 1, o); if (!isFinite(h)) nan++; h += T._variety(X, Y, Z, h, o).dh;
      const r = T.regionInfo(o); cnt[r.tag]++; names.add(r.region); if (r.feature) feats[r.kind] = (feats[r.kind] || 0) + 1;
      if (h > 0) { land[r.tag]++; if (i > 0 && prev[i-1] > 0) { rough[r.tag] += Math.abs(h - prev[i-1]); rn[r.tag]++; } } prev[i] = h; } }
  const L = T.landmarks();
  console.log('seed', seed, 'NaN', nan, '| area% young/old/karst/glac', cnt.map(c => (100 * c / (W * H)).toFixed(0)).join('/'), '| land cells', land.join('/'), '| mean |dh| per cell on land', rough.map((v, k) => (v / Math.max(1, rn[k])).toFixed(0)).join('/'));
  console.log('  regions named', names.size, '| feature cells', JSON.stringify(feats), '| landmarks', L.length, 'e.g.', L.slice(0, 3).map(l => l.name + ' (' + l.kind + ')').join(', '), '|', L.filter(l => l.kind === 'arc').slice(0, 2).map(l => l.name).join(', '), '|', L.filter(l => l.kind === 'chain').slice(0, 2).map(l => l.name).join(', '));
}
