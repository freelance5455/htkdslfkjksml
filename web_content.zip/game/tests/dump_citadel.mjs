import { city, S } from './test_citadel.mjs';
import fs from 'fs';
const CATS = ['wallBox','wallCyl','plainBox','plainCyl','gable','dome','cone','arch','glow','baseBox','glassDome','orgCyl','orgDome','orgCone','glowCyl','glassCyl'];
const out = [];
const ci = (c) => { const i = CATS.indexOf(c); return i >= 0 ? i : (c[0] === 't' ? 100 : 101); };
for (const p of city.pieces) out.push(ci(p.cat), p.x, p.y, p.z, p.yaw, p.sx, p.sy, p.sz, p.color[0], p.color[1], p.color[2], p.pitch, p.roll);
fs.writeFileSync('/tmp/cit.f32', Buffer.from(new Float32Array(out).buffer));
fs.writeFileSync('/tmp/cit.json', JSON.stringify({ F: S.floorH, tun: city.tunnel, cols: Array.from(city.cols).length / 9 }));
