import { TerrainCore } from '../terrain_core.js';
import * as V from '../valley_sites.js';
import { generateCity, planToCols, makeNatGrid } from '../city_core.js';
import { CityCollider } from '../city_collide.js';
import { PLANET_R } from '../planet_core.js';
const seed = 424242, T = new TerrainCore(seed), o = {}, d = [0,0,0];
const sites = V.findSites(T, seed).sites, N = +(process.argv[2] || 8);
let fail = 0, nd = 0; const ck = (m, ok) => { if (!ok) { fail++; console.log('  FAIL', m); } };
for (const S of sites.slice(0, N)) {
  const nat3 = (x, z) => { V.localToDir(S, x, -z, d); return T.sample3(d[0]*PLANET_R, d[1]*PLANET_R, d[2]*PLANET_R, o); };
  const nat = makeNatGrid(S, nat3, 20), city = generateCity(S, nat), ground = (x, z) => V.valleyHeight(S, x, -z, nat(x, z));
  const cols = planToCols(city), col = new CityCollider(cols);
  // 1. walk into every dome from the foot of its ramp
  const domeP = city.pieces.filter(p => p.cat === 'glassDome');
  let entered = 0;
  for (const p of domeP) {
    const dm = city.domes[domeP.indexOf(p)]; if (!dm) continue; nd++;
    const dx = Math.cos(dm.hd), dz = Math.sin(dm.hd), sB = dm.PR + dm.len + 4;
    const m = { x: dm.x + dx * sB, z: dm.z + dz * sB, y: 0 }; const g0 = col.floorAt(m.x, m.z, 1e9, 0); m.y = Math.max(g0, ground(m.x, m.z)) + 8.5 + 0.05;
    for (let i = 0; i < 400; i++) {
      const px = m.x, py = m.y, pz = m.z; m.x -= dx * 1.2; m.z -= dz * 1.2; m.y -= 1.0;   // walk toward the centre, gravity
      const r = col.resolve(m, px, py, pz, 8.5, 1.8, 1, 2.4);
      // keep on ground if not grounded
    }
    const dist = Math.hypot(m.x - dm.x, m.z - dm.z);
    if (dist < dm.rd * 0.35) entered++; else console.log(`  dome ${S.id}: stopped ${dist.toFixed(0)} from centre (rd ${dm.rd.toFixed(0)}) y ${m.y.toFixed(1)} yP ${dm.yP.toFixed(1)}`);
  }
  ck(`site ${S.id} domes enterable ${entered}/${domeP.length}`, entered === domeP.length);
  // 2. a wall piece is never far from the built-up city
  const walls = city.pieces.filter(p => p.cat === 'plainBox' && Math.abs(p.sz - 8.4) < 0.01);
  const gaps = walls.map(w => { let best = 1e9; for (const b of city.buildings) best = Math.min(best, Math.hypot(b.x - w.x, b.z - w.z) - Math.hypot(b.w, b.d) / 2); for (const q of city.domes) best = Math.min(best, Math.hypot(q.x - w.x, q.z - w.z) - q.PR); return best; }).sort((a, b) => a - b);
  const med = gaps.length ? gaps[gaps.length >> 1] : 0;
  // 3. floating audit: lowest piece point above ground with nothing under it
  const grid = new Map(), key = (i, j) => i * 7919 + j; const boxes = city.pieces.filter(p => (p.cat === 'wallBox' || p.cat === 'baseBox' || p.cat === 'plainBox' || p.cat === 'plainCyl' || p.cat === 'wallCyl') && !p.pitch && !p.roll);
  for (const q of boxes) { const r = Math.hypot(q.sx, q.sz) / 2; for (let i = Math.floor((q.x - r) / 40); i <= Math.floor((q.x + r) / 40); i++) for (let j = Math.floor((q.z - r) / 40); j <= Math.floor((q.z + r) / 40); j++) { const k = key(i, j); (grid.get(k) || grid.set(k, []).get(k)).push(q); } }
  let fl = 0, cand = 0;
  for (const p of city.pieces) {
    if (!(p.cat === 'wallBox' || p.cat === 'baseBox' || p.cat === 'plainBox' || p.cat === 'plainCyl' || p.cat === 'wallCyl' || p.cat === 'cone' || p.cat === 'dome') || p.pitch || p.roll) continue;
    const g = ground(p.x, p.z); if (p.y - g < 5) continue; cand++;
    let sup = false; for (const q of grid.get(key(Math.floor(p.x / 40), Math.floor(p.z / 40))) || []) { if (q === p) continue; const c = Math.cos(q.yaw), s = Math.sin(q.yaw), dx = p.x - q.x, dz = p.z - q.z, u = dx * c + dz * s, v = -dx * s + dz * c; if (Math.abs(u) <= q.sx / 2 + 1.5 && Math.abs(v) <= q.sz / 2 + 1.5 && p.y >= q.y - 1.5 && p.y <= q.y + q.sy + 2.5) { sup = true; break; } }
    if (!sup) { fl++; (globalThis.UN || (globalThis.UN = {}))[p.cat + ':' + (p.sy < 3 ? 'thin' : p.sy < 12 ? 'mid' : 'tall')] = ((globalThis.UN || {})[p.cat + ':' + (p.sy < 3 ? 'thin' : p.sy < 12 ? 'mid' : 'tall')] || 0) + 1; }
  }
  console.log(`site ${S.id} ${city.arche} B${city.buildings.length} domes${domeP.length} conn${city.stats.connectors} greens${city.stats.greens} wallGapMed${med.toFixed(0)} floatCand${cand} unsupported${fl}`);
  ck(`site ${S.id} wall gap median ${med.toFixed(0)} < 60`, !walls.length || med < 60);   // v56: was 45; junction repair shifts lot spacing by 1-2 units
}
console.log(JSON.stringify(globalThis.UN)); console.log('domes tested', nd, fail ? 'FAIL ' + fail : 'ALL OK'); process.exit(fail ? 1 : 0);
