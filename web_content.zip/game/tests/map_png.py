import sys, numpy as np
from PIL import Image
f, W, out = sys.argv[1], int(sys.argv[2]), sys.argv[3]
H = int(sys.argv[4]) if len(sys.argv) > 4 else W // 2
a = np.fromfile(f, dtype=np.float32).reshape(H, W, 3)
h = a[:, :, 0]
img = np.zeros((H, W, 3), np.float32)
# ocean: depth shading; land: hypsometric
d = np.clip(-h / 5000, 0, 1)
ocean = np.stack([0.02 + 0.10 * (1 - d), 0.10 + 0.40 * (1 - d), 0.25 + 0.55 * (1 - d)], -1)
t = np.clip(h / 2400, 0, 1)[..., None]
low = np.array([0.35, 0.60, 0.25]); mid = np.array([0.60, 0.52, 0.33]); hi = np.array([0.95, 0.95, 0.95])
land = np.where(t < 0.5, low + (mid - low) * (t / 0.5), mid + (hi - mid) * ((t - 0.5) / 0.5))
img = np.where((h > 0)[..., None], land, ocean)
Image.fromarray((np.clip(img, 0, 1) * 255).astype(np.uint8)).save(out)
print('land frac', float((h > 0).mean()), 'max', float(h.max()), 'min', float(h.min()))
