import { TerrainCore } from '../terrain_core.js';
import * as V from '../valley_sites.js';
import { generateCity, planToCols, planToLife, makeNatGrid } from '../city_core.js';
import { CityCollider } from '../city_collide.js';
import { CitySim } from '../city_sim.js';
import { makeResidents } from '../city_life.js';
import { PLANET_R } from '../planet_core.js';
const seed = 424242, T = new TerrainCore(seed), o = {}, d = [0,0,0], S = V.findSites(T, seed).sites[2];
const nat3 = (x, z) => { V.localToDir(S, x, -z, d); return T.sample3(d[0]*PLANET_R, d[1]*PLANET_R, d[2]*PLANET_R, o); };
const city = generateCity(S, makeNatGrid(S, nat3, 20)), col = new CityCollider(planToCols(city)), life = planToLife(city);
let fail = 0; const ck = (n, ok) => { console.log(ok ? 'ok  ' : 'FAIL', n); if (!ok) fail++; };
// 1. walk (eye 8.5) straight at a mid-size building from the street side, many frames: never ends inside it
const b = city.buildings.find(q => q.floors >= 5 && q.tiers), T0 = b.tiers[0];
const m = { x: T0.cx - Math.cos(b.yaw) * (T0.w / 2 + 12), y: b.y0 + 8.5, z: T0.cz - Math.sin(b.yaw) * (T0.w / 2 + 12) };
for (let i = 0; i < 200; i++) { const px = m.x, py = m.y, pz = m.z; m.x += Math.cos(b.yaw) * 0.9; m.z += Math.sin(b.yaw) * 0.9; col.resolve(m, px, py, pz, 8.5, 1.8, 1, 2.4); }
ck('walking into a wall stops outside it', !col.solidAt(m.x, m.z, b.y0 + 1, b.y0 + 9) && Math.hypot(m.x - T0.cx, m.z - T0.cz) > 0);
// 2. fast flight through a building at 60 units/step, sub-stepped as the runtime does: never inside
{ const mm = { x: T0.cx - 300, y: b.y0 + 40, z: T0.cz }; let inside = false;
  for (let i = 0; i < 30; i++) { const tx = mm.x + 20, n = 9; for (let k = 0; k < n; k++) { const px = mm.x, py = mm.y, pz = mm.z; mm.x += 20 / n; col.resolve(mm, px, py, pz, 8.5, 1.8, 1, 2.4); if (col.solidAt(mm.x, mm.z, mm.y - 8, mm.y + 1) && false) inside = true; } void tx; }
  ck('flying through geometry never ends inside a solid', !col.solidAt(mm.x, mm.z, mm.y - 8, mm.y + 1)); }
// 3. falling onto a roof lands on it
{ const TL = b.tiers[b.tiers.length-1], top = TL.y + TL.h, mm = { x: TL.cx, y: top + 60, z: TL.cz }, r = { g: false }; for (let i = 0; i < 100; i++) { const px = mm.x, py = mm.y, pz = mm.z; mm.y -= 2; const rs = col.resolve(mm, px, py, pz, 8.5, 1.8, 1, 2.4); if (rs.grounded) r.g = true; }
  ck('falling lands on the roof (feet at top)', r.g && Math.abs(mm.y - 8.5 - top) < 3); }
// 4. street floor is walkable: stand at a street node and the floor is within 1.5 of the node
{ let ok = 0, n = 0; for (const nd of city.nodes.slice(1, 200)) { const f = col.floorAt(nd.x, nd.z, nd.y + 60, 0); n++; if (Math.abs(f - nd.y) < 6) ok++; } let bad=[]; for (const nd of city.nodes.slice(0,200)) { const f = col.floorAt(nd.x, nd.z, nd.y + 60, 0); if (!(Math.abs(f - nd.y) < 3)) bad.push([nd.kind, nd.adj.length, (f-nd.y).toFixed(1)]); } console.log(JSON.stringify(bad.slice(0,14)));
 ck(`street floors under nodes ${ok}/${n}`, ok / n > 0.85); }
// 5. drones with solids: simulate 120 s for 64 drones, count samples inside solids
const res = makeResidents(S.seedN, 96, life); const sim = new CitySim(life, res, { cityName: 'T', seed: 1, maxDrones: 64, solid: (dr, y) => col.pushOutXZ(dr, y, 2.7) }); sim.activate(0.4);
let inside = 0, samples = 0; for (let t = 0; t < 2400; t++) { sim.step(0.05, 0.4 + t * 0.0001, false, false, null); if (t % 10 === 0) for (const dr of sim.drones) { samples++; if (col.solidAt(dr.x, dr.z, dr.y + 1, dr.y + 5)) inside++; } }
ck(`drones inside solids ${inside}/${samples}`, inside / samples < 0.002);
console.log(fail ? 'FAIL' : 'ALL OK'); process.exit(fail ? 1 : 0);
