import sys, os, subprocess, time
from playwright.sync_api import sync_playwright
srv = subprocess.Popen([sys.executable, '-m', 'http.server', '8767', '--directory', os.path.join(os.path.dirname(__file__), '..')], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(1)
try:
    with sync_playwright() as p:
        b = p.chromium.launch(args=['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--no-sandbox', '--autoplay-policy=no-user-gesture-required'])
        pg = b.new_page(viewport={'width': 844, 'height': 390}); logs = []
        pg.on('console', lambda m: logs.append(m.text)); pg.on('pageerror', lambda e: logs.append('PAGEERR ' + str(e)))
        pg.goto('http://localhost:8767/tests/ff_cine_blank.html'); pg.wait_for_timeout(500)
        pg.evaluate("""() => { window.__log=[]; const ctx = new AudioContext();
          window.c = window.mk({ getAudioContext: () => ctx });
          window.p = window.c.play({ whileBlack: async () => { window.__log.push('whileBlack'); }, onLeave: () => window.__log.push('LEAVE') }).then(() => window.__log.push('resolved')); }""")
        pg.wait_for_timeout(3000)
        vis = lambda: pg.evaluate("getComputedStyle(document.querySelector('#ffCine .ff-pause')).display")
        print('prompt before double-tap:', vis())
        pg.mouse.click(400, 150); pg.wait_for_timeout(120); pg.mouse.click(400, 150); pg.wait_for_timeout(400)
        print('prompt after double-tap:', vis())
        pg.wait_for_timeout(4000)
        print('still active after 4s paused:', pg.evaluate('window.c.active'))
        pg.click('#ffCine .ff-resume'); pg.wait_for_timeout(400)
        print('prompt after Keep watching:', vis())
        pg.keyboard.press('Space'); pg.wait_for_timeout(600)
        print('Space did not end it:', pg.evaluate('window.c.active'))
        pg.mouse.click(400, 150); pg.wait_for_timeout(120); pg.mouse.click(400, 150); pg.wait_for_timeout(300)
        pg.click('#ffCine .ff-leave'); pg.wait_for_timeout(300)
        print('log:', pg.evaluate('window.__log'))
        print('console:', [l for l in logs if 'GPU stall' not in l][:6])
        b.close()
finally:
    srv.terminate()
