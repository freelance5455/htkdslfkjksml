# Renders moments of the dream to PNGs (headless Chromium + SwiftShader).
# usage: python3 dream_shots.py OUTDIR t1 t2 ...      (t = seconds on the dream timeline)
import sys, os, subprocess, time
from playwright.sync_api import sync_playwright
out = sys.argv[1]; times = [float(x) for x in sys.argv[2:]]
os.makedirs(out, exist_ok=True)
srv = subprocess.Popen([sys.executable, '-m', 'http.server', '8766', '--directory', os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(1)
try:
    with sync_playwright() as p:
        b = p.chromium.launch(args=['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--no-sandbox'])
        pg = b.new_page(viewport={'width': int(os.environ.get('DR_W', 640)), 'height': int(os.environ.get('DR_H', 360))})
        logs = []; pg.on('console', lambda m: logs.append(m.text)); pg.on('pageerror', lambda e: logs.append('PAGEERR ' + str(e)))
        pg.goto('http://localhost:8766/tests/dream_harness.html'); pg.wait_for_timeout(2000)
        err = pg.evaluate('window.__err || null')
        if err: print('MOUNT ERROR:', err); print(logs); sys.exit(1)
        for t in times:
            s = time.time(); pg.evaluate(f'window.dream.debug.renderAt({t})'); pg.wait_for_timeout(250)
            f = os.path.join(out, f't_{t:06.2f}.png'); pg.screenshot(path=f, timeout=150000); print('ok', f, round(time.time() - s, 1), 's')
        if logs: print('LOGS', logs[:6])
        b.close()
finally:
    srv.terminate()
