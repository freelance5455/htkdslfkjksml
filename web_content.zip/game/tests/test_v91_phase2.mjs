// v91 Phase 2 logic test. Loads the real flower-mobile region of game.js (from "let flowerStage = 0" up to handleInteractKey) into a
// sandbox with minimal stubs for THREE / the DOM / the rest of the game, then plays the whole Phase 2 path:
//   lodge -> second warehouse -> three modules -> assemble -> fit (weapons) -> drive on -> ambush -> restart -> aftermath -> arrival gate.
// It cannot check how anything looks (there is no WebGL here); it checks that every step is reachable and the state machine holds.
//   node tests/test_v91_phase2.mjs
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const src = fs.readFileSync(path.join(here, '..', 'game.js'), 'utf8');
const a = src.indexOf('let flowerStage = 0,'), b = src.indexOf('function handleInteractKey()');
assert(a > 0 && b > a, 'region markers not found');
const region = src.slice(a, b);

// ---------- stubs ----------
class V3 {
    constructor(x = 0, y = 0, z = 0) { this.x = x; this.y = y; this.z = z; }
    set(x, y, z) { this.x = x; this.y = y; this.z = z; return this; }
    copy(v) { this.x = v.x; this.y = v.y; this.z = v.z; return this; }
    clone() { return new V3(this.x, this.y, this.z); }
    addScaledVector(v, s) { this.x += v.x * s; this.y += v.y * s; this.z += v.z * s; return this; }
    lerp(v, t) { this.x += (v.x - this.x) * t; this.y += (v.y - this.y) * t; this.z += (v.z - this.z) * t; return this; }
    lerpVectors(a, b, t) { this.x = a.x + (b.x - a.x) * t; this.y = a.y + (b.y - a.y) * t; this.z = a.z + (b.z - a.z) * t; return this; }
    distanceTo(v) { return Math.hypot(this.x - v.x, this.y - v.y, this.z - v.z); }
    length() { return Math.hypot(this.x, this.y, this.z); }
    normalize() { const l = this.length() || 1; this.x /= l; this.y /= l; this.z /= l; return this; }
    applyAxisAngle(ax, ang) { const c = Math.cos(ang), s = Math.sin(ang), x = this.x, z = this.z; this.x = x * c + z * s; this.z = -x * s + z * c; return this; }   // about +y
    applyQuaternion() { return this; }
}
class Euler { constructor() { this.x = 0; this.y = 0; this.z = 0; } set(x, y, z) { this.x = x; this.y = y; this.z = z; return this; } copy(e) { this.x = e.x; this.y = e.y; this.z = e.z; return this; } clone() { return new Euler().copy(this); } }
class Obj {
    constructor() { this.position = new V3(); this.rotation = new Euler(); this.scale = { setScalar() {}, set() {} }; this.children = []; this.visible = true; this.name = ''; this.material = { opacity: 1, dispose() {} }; this.geometry = { dispose() {} }; this.intensity = 1; }
    add(c) { this.children.push(c); return c; }
    remove(c) { const i = this.children.indexOf(c); if (i >= 0) this.children.splice(i, 1); }
    getObjectByName(n) { const f = (o) => { if (o.name === n) return o; for (const c of o.children) { const r = f(c); if (r) return r; } return null; }; return f(this); }
    lookAt() {}
}
const THREE = new Proxy({ Vector3: V3, Euler }, { get(t, k) { if (k in t) return t[k]; return class extends Obj { constructor() { super(); this.userData = {}; } }; } });
const elStub = () => ({ classList: { add() {}, remove() {}, toggle() {}, contains: () => false }, dataset: {}, style: {}, textContent: '', innerHTML: '' });
const log = [];
const state = {
    THREE, Math, Array, Object, Number, Promise, console, performance,
    player: { position: new V3(0, 30, 0), velocity: new V3(), yaw: 0, pitch: 0, height: 1.7, cameraY: 30, isGrounded: false, isUnderwater: false },
    camera: { position: new V3(), quaternion: { copy() {} }, getWorldDirection(v) { v.set(0, 0, -1); return v; } },
    clock: { t: 0, getElapsedTime() { return this.t; } },
    scene: { add() {}, remove() {} },
    document: { getElementById: elStub, pointerLockElement: null, exitPointerLock() {} },
    _lookEuler: new Euler(), _lookQuat: { setFromEuler() {} }, _upAxis: new V3(0, 1, 0),
    getEnvironmentAt: () => ({ height: 20 }), WATER_LEVEL: 0,
    shelterPos: { x: 0, z: 0 }, insideShelterInterior: false, insideShelter: false, dayTimeFrozen: false, cutsceneActive: false, isPaused: false, introActive: false,
    boatBoarded: false, playerPlatform: 'desktop', aiIsSpeaking: false, laserCharge: 18, drones: [], droneProjectiles: [], nightAttackActive: false, dronesTotalSpawned: 0,
    currentDroneTarget: null, DRONE_DAMAGE_PER_HIT: 100 / 3, valeBeacon: null, flowerMobileDummy: 0,
    sleep: () => Promise.resolve(), spawnBurst() {}, triggerShake() {}, writeCurrentSave() {}, updateToolChargeHud() {}, updateMobileInteractButton() {},
    playLine: async (t) => { log.push(t); }, speakLine: (t) => { log.push(t); return Promise.resolve(); }, addLog: (id) => { log.push('LOG:' + id); },
    makeShelterSurfaceTexture: () => ({ repeat: { set() {} } }), makeWardenDroneMesh: () => new Obj(), makeDroneMesh: () => new Obj(), makeWildDroneMesh: () => new Obj(),
    disposeGroupDeep() {}, clearHoloPath() {}, clearValeBeacon() {}, startValeWaypoint() {}, playSfxVoice() {}, playImpactSparkSfx() {}, updateDroneStatusHud() {},
    makeDroneEntry: (mesh, type) => ({ mesh, type, hp: type === 'warden' ? 160 : 100, alive: true, dying: false, state: 'seek', stateT: 0 }),
    destroyDrone: (d) => { d.alive = false; d.dying = true; },
    valePlaced: () => ({ cx: 6000, cz: 0, gnd: 1, site: { Rf: 200 } }),
};
const ctx = new Proxy(state, { has: (t, k) => typeof k === 'string' && k in t, get: (t, k) => t[k], set: (t, k, v) => { t[k] = v; return true; } });
const api = new Function('ctx', `with (ctx) { ${region}
  return { get: (n) => eval(n), set: (n, v) => eval(n + ' = v'), fns: { updateFlowerStory, updateFlowerDrive, runLodgeScene, enterLodgeWarehouse, exitLodgeWarehouse, pryFocusCrate, cutRelayCage, digResonatorRack, inspectBench, assembleModules, fitAssemblyToVehicle, boardFlowerMobile, startAmbush, restartAmbush, runAmbushAftermath, flowerArrivalOk, updateVehicleWeapons, whResolve, spawnAmbushDrones, flowerTarget, refreshFlowerHud, takeModule } }; }`)(ctx);
const { fns } = api, G = (n) => api.get(n), S = (n, v) => api.set(n, v);
let pass = 0; const ok = (c, m) => { assert(c, m); pass++; console.log('  ok -', m); };

// ---------- 1. the second warehouse's layout ----------
console.log('layout');
const R = G('WH2_RECTS'), O = G('WH2_OBST'), EX = G('WH2_EXIT');
S('whLayoutId', 2);
const walkable = (x, z) => { const r = fns.whResolve(x, z); return Math.hypot(r[0] - x, r[1] - z) < 0.05; };
const spawn = [EX.x, EX.z - 4];
ok(walkable(...spawn), 'the entry point is walkable');
const cell = 0.5, key = (x, z) => Math.round(x / cell) + ',' + Math.round(z / cell), seen = new Set([key(...spawn)]), q = [spawn];
while (q.length) { const [x, z] = q.shift(); for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { const nx = x + dx * cell, nz = z + dz * cell, k = key(nx, nz); if (!seen.has(k) && walkable(nx, nz)) { seen.add(k); q.push([nx, nz]); } } }
const reach = (px, pz, rad) => { for (const k of seen) { const [cx, cz] = k.split(',').map(Number); if (Math.hypot(cx * cell - px, cz * cell - pz) < rad) return true; } return false; };
for (const [name, x, z, rad] of [['focus crate', -15, -10, 5], ['relay cage', 0, -24, 5], ['resonator rack', 16, 9, 5], ['workbench', 0, 0, 6], ['exit', EX.x, EX.z, 5]]) ok(reach(x, z, rad), name + ' is reachable from the entry on foot');
// the interaction priority: the point where two prompts overlap must not hide one of them (bench vs everything else is the only overlap that matters)
ok(Math.hypot(0 - -15, 0 - -10) > 6 + 5 - 4 && Math.hypot(0 - 0, 0 - -24) > 6 + 5 - 4, 'the workbench radius does not swallow another station');
S('whLayoutId', 1);

// ---------- 2. the whole path ----------
console.log('path');
S('flowerStage', 4); S('flowerBuilt', true); S('flowerPad', { x: 0, z: 0, groundY: 20 }); S('flowerDriving', true); S('flowerRouteTotal', 6000);
state.player.position.set(0, 30, 0); state.player.yaw = Math.atan2(-6000, 0) + 0;   // forward = (-sin yaw, 0, -cos yaw): yaw = -pi/2 heads +x
state.player.yaw = -Math.PI / 2;
ok(G('ambushStage') === 0, 'starts at ambushStage 0');
let tick = (dt = 0.05) => { state.clock.t += dt; fns.updateFlowerStory(dt); };
// drive toward the city at full speed until the lodge triggers (55% of the route is covered at x = 2700)
let guard = 0;
while (!G('lodgeGlide') && guard++ < 4000) { fns.updateFlowerDrive(0.05, 0, -1, false); tick(); }
const lodgeX = state.player.position.x;
ok(G('lodgeGlide') && lodgeX > 2600 && lodgeX < 3300, 'the lodge triggers around 55% of the way (x=' + Math.round(lodgeX) + ')');
guard = 0; while (G('ambushStage') === 0 && guard++ < 2000) { fns.updateFlowerDrive(0.05, 0, -1, false); tick(); await Promise.resolve(); }
for (let i = 0; i < 50; i++) await Promise.resolve();
ok(G('ambushStage') === 1 && !G('flowerDriving') && G('lodgeSite'), 'the vehicle loses power and lodges: stage 1, on foot');
ok(Math.hypot(state.player.position.x - G('lodgeSite').x, state.player.position.z - G('lodgeSite').z) > 10, 'the player is put on the ground clear of the vehicle');
ok(G('flowerTarget')().kind === 'lodge', 'the waypoint now points at the lodge');
// walk up to the entrance and go in
state.player.position.set(G('lodgeSite').x, 25, G('lodgeSite').z + 10);
await fns.enterLodgeWarehouse();
ok(G('insideWarehouse') && G('whLayoutId') === 2, 'inside the second warehouse');
await fns.inspectBench();
await fns.assembleModules(); ok(G('ambushStage') === 1, 'assembling with no modules does nothing');
await fns.pryFocusCrate(); await fns.cutRelayCage(); await fns.digResonatorRack();
ok(G('lodgeModules').length === 3, 'all three modules can be collected');
ok(state.laserCharge === 14, 'the relay cage costs 4 laser charge');
state.laserCharge = 2; S('lodgeModules', G('lodgeModules').filter((m) => m !== 'relay')); await fns.cutRelayCage(); ok(!G('lodgeModules').includes('relay'), 'with too little charge the cage stays shut'); state.laserCharge = 18; await fns.cutRelayCage();
await fns.assembleModules(); ok(G('ambushStage') === 2, 'assembled: stage 2');
fns.exitLodgeWarehouse(); ok(!G('insideWarehouse'), 'climbed out again');
await fns.fitAssemblyToVehicle();
ok(G('ambushStage') === 3 && G('weaponsOnline'), 'the vehicle is freed and armed: stage 3, weapons online');
ok(G('flowerTarget')().kind === 'city', 'the waypoint is back on the city');
ok(log.some((l) => /Weapons|emitters|Emitters/.test(l)), 'the AI says what the modules are');
await fns.boardFlowerMobile(); ok(G('flowerDriving'), 'boarded again');
ok(fns.flowerArrivalOk() === false && G('ambushStage') === 4 && G('drones').length === 7, 'reaching the city early starts the ambush instead of the arrival scene (7 drones)');
for (let i = 0; i < 30; i++) await Promise.resolve();

// ---------- 3. the fight ----------
console.log('fight');
ok(G('drones').filter((d) => d.type === 'raider').length === 5 && G('drones').filter((d) => d.type === 'warden').length === 2, 'five raiders and two wardens');
const cp = { ...G('ambushCheckpoint') };
state.player.position.set(cp.x + 300, 30, cp.z);
S('vehicleFiring', true); S('flowerDriving', true);
let shots = 0;
for (const d of state.drones) { state.currentDroneTarget = d; const hp0 = d.hp; guard = 0; while (d.alive && guard++ < 50) { state.clock.t += 0.2; fns.updateVehicleWeapons(0.2); shots++; } ok(!d.alive, d.type + ' goes down to the petal shots (' + Math.round(hp0 / (100 / 3 * 0.9)) + ' shots needed)'); if (!d.alive && d === state.drones[0]) break; }
for (const d of state.drones) { state.currentDroneTarget = d; guard = 0; while (d.alive && guard++ < 50) { state.clock.t += 0.2; fns.updateVehicleWeapons(0.2); } }
ok(state.drones.every((d) => !d.alive), 'all seven can be destroyed by the vehicle weapons');
// death: restart from the checkpoint with the full wave
state.drones.forEach((d, i) => { if (i < 3) d.alive = true; });
fns.restartAmbush();
ok(G('drones').length === 7 && G('drones').every((d) => d.alive) && Math.abs(state.player.position.x - cp.x) < 1e-6, 'dying restarts the fight from its start, with the whole wave again');
// win
state.drones.forEach((d) => { d.alive = false; });
await fns.runAmbushAftermath();
ok(G('ambushStage') === 5 && log.includes('LOG:log_flower_ambush'), 'winning moves to stage 5 and logs it');
ok(fns.flowerArrivalOk() === true, 'after the ambush the city arrival is allowed');

// ---------- 4. never trap the player ----------
console.log('arrival gate');
S('ambushStage', 1); S('flowerDriving', false); ok(fns.flowerArrivalOk() === true, 'on foot (vehicle left behind) the arrival is never blocked');
S('ambushStage', 0); S('flowerDriving', true); ok(fns.flowerArrivalOk() === true && G('ambushStage') === 5, 'driving with no lodge ever found (no dry land): the ambush is skipped');
S('flowerStage', -1); S('ambushStage', 3); S('flowerDriving', true); ok(fns.flowerArrivalOk() === true, 'the no-vehicle fallback route is untouched');
console.log('\n' + pass + ' checks passed');
