# Renders the cinematic frame by frame to /tmp/vid/f_#####.jpg (resumable). usage: python3 ff_cine_video_frames.py [fps] [w] [h]
import sys, os, subprocess, time
from playwright.sync_api import sync_playwright
fps = int(sys.argv[1]) if len(sys.argv) > 1 else 24; W = int(sys.argv[2]) if len(sys.argv) > 2 else 960; H = int(sys.argv[3]) if len(sys.argv) > 3 else 540
os.makedirs('/tmp/vid', exist_ok=True)
srv = subprocess.Popen([sys.executable, '-m', 'http.server', '8768', '--directory', os.path.join(os.path.dirname(__file__), '..')], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(1)
try:
    with sync_playwright() as p:
        b = p.chromium.launch(args=['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--no-sandbox'])
        pg = b.new_page(viewport={'width': W, 'height': H})
        pg.goto('http://localhost:8768/tests/ff_cine_harness.html'); pg.wait_for_timeout(1500)
        dur = pg.evaluate('window.cine.debug.duration'); n = int(dur * fps); t0 = time.time(); done = 0
        for i in range(n):
            f = f'/tmp/vid/f_{i:05d}.jpg'
            if os.path.exists(f): continue
            pg.evaluate(f'window.cine.debug.renderAt({i / fps})')
            pg.screenshot(path=f, type='jpeg', quality=93); done += 1
            if done % 20 == 0: open('/tmp/vid/progress.txt', 'w').write(f'{i+1}/{n} {round((time.time()-t0)/done,2)}s/frame')
        open('/tmp/vid/progress.txt', 'w').write(f'DONE {n}/{n}'); b.close()
finally:
    srv.terminate()
