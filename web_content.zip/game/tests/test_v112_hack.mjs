// v112 headless test for leviathan_hack.js (console, hack, break, green lights, blast door). No WebGL: three.js is replaced by the same stub
// test_v111_leviathan.mjs uses.     node tests/test_v112_hack.mjs
import fs from 'node:fs'; import os from 'node:os'; import path from 'node:path'; import assert from 'node:assert/strict'; import { fileURLToPath, pathToFileURL } from 'node:url';
const here = path.dirname(fileURLToPath(import.meta.url));
const read = (f) => fs.readFileSync(path.join(here, '..', f), 'utf8');
const v111 = fs.readFileSync(path.join(here, 'test_v111_leviathan.mjs'), 'utf8');
const stub = v111.match(/const stub = `([\s\S]*?)`;/)[1];
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'hack-'));
fs.writeFileSync(path.join(tmp, 'three_stub.mjs'), stub);
fs.writeFileSync(path.join(tmp, 'ocean_surface.mjs'), 'export function registerShaderFallback(){}\n');
let core = read('leviathan_core.js'), hack = read('leviathan_hack.js');
for (const [name, src] of [['leviathan_core', core], ['leviathan_hack', hack]]) for (const n of new Set([...src.matchAll(/THREE\.(\w+)/g)].map(m => m[1]))) assert(new RegExp('\\b' + n + '\\b').test(stub), name + ' uses THREE.' + n + ' which the stub lacks');
core = core.replace("import * as THREE from 'three';", "import * as THREE from './three_stub.mjs';").replace("'./ocean_surface.js'", "'./ocean_surface.mjs'").replace("'./leviathan_sky.js'", "'./leviathan_sky.mjs'");
fs.copyFileSync(path.join(here, '..', 'leviathan_sky.js'), path.join(tmp, 'leviathan_sky.mjs'));
hack = hack.replace("import * as THREE from 'three';", "import * as THREE from './three_stub.mjs';").replace("'./leviathan_core.js'", "'./leviathan_core.mjs'");
fs.writeFileSync(path.join(tmp, 'leviathan_core.mjs'), core); fs.writeFileSync(path.join(tmp, 'leviathan_hack.mjs'), hack);
const { createLeviathan, LAYOUT: L } = await import(pathToFileURL(path.join(tmp, 'leviathan_core.mjs')).href);
const { createHack, HACK } = await import(pathToFileURL(path.join(tmp, 'leviathan_hack.mjs')).href);
let ok = 0; const pass = (m) => { ok++; console.log('  ok  ' + m); };

const events = [], hevents = [];
const lev = createLeviathan({ onEvent: (n) => events.push(n), getAudioContext: () => null, getVolume: () => 1 });
lev.build(); const meshesBefore = []; lev.scene.traverse(o => { if (o.geometry) meshesBefore.push(o); });
const hack_ = createHack(lev, { onEvent: (n) => hevents.push(n) });
assert(hack_.state === 'idle' && !hack_.built); hack_.build(); hack_.build(); assert(hack_.built); pass('hack module builds (twice is harmless)');
let added = 0, tris = 0; lev.scene.traverse(o => { if (o.geometry && o.geometry.attributes && o.geometry.attributes.position && !meshesBefore.includes(o)) { added++; const g = o.geometry, n = g.attributes.position.array.length / 3; if (g.index) { tris += g.index.array.length / 3; for (const i of g.index.array) assert(i < n, 'index out of range in ' + o.name); }
    for (const k of ['position', 'normal']) if (g.attributes[k]) for (const v of g.attributes[k].array) assert(Number.isFinite(v), 'NaN in ' + k + ' of ' + o.name); } });
console.log('      added draw calls (non-instanced meshes):', added, ' triangles:', tris); assert(added >= 8 && added <= 30 && tris > 300); pass('geometry integrity; the extra draw calls stay low');
const lights = []; lev.scene.traverse(o => { if (o.intensity !== undefined && o.decay !== undefined) lights.push(o); }); console.log('      lights now:', lights.length); assert(lights.length <= 9); pass('light count stays bounded (' + lights.length + ')');

// ---- collision ----
const walkable = (x, z) => { const r = lev.resolve(x, z); return Math.abs(r[0] - x) < 1e-6 && Math.abs(r[1] - z) < 1e-6; };
const C = HACK.console, st = HACK.stand;
assert(walkable(st.x, st.z), 'the terminal stand point is not walkable'); assert(!walkable(C.x, L.cor.z1 - 6), 'can walk through the console'); assert(!walkable(C.x + 10, L.cor.z1 - 10), 'can walk through the console pedestal');
assert(walkable(C.x, L.cor.z1 - 18), 'cannot stand in front of the console'); pass('console is solid, the stand point in front of it is walkable');
assert(!walkable(L.doorX + 3, (L.cor.z0 + L.cor.z1) / 2) && !walkable(L.doorX - 40, (L.cor.z0 + L.cor.z1) / 2), 'the closed door can be walked through'); pass('the closed door cannot be walked through');
const reach = (fromX, fromZ, pred) => { const G = 2, key = (x, z) => x + ',' + z, q = [[fromX, fromZ]], seen = new Set([key(fromX, fromZ)]); while (q.length) { const [x, z] = q.shift(); if (pred(x, z)) return true; for (const [dx, dz] of [[G, 0], [-G, 0], [0, G], [0, -G]]) { const nx = x + dx, nz = z + dz, k = key(nx, nz); if (seen.has(k) || !walkable(nx, nz)) continue; seen.add(k); q.push([nx, nz]); } } return false; };
assert(reach(L.exit.x, L.exit.z, (x, z) => Math.hypot(x - st.x, z - st.z) < 3), 'the stand point is not reachable from the hatch'); pass('the stand point is reachable from the hatch');
assert(!reach(L.exit.x, L.exit.z, (x) => x < L.doorX), 'something beyond the door is reachable while it is closed'); pass('nothing beyond the door is reachable while it is closed');

// ---- the interaction table ----
const mid = (L.cor.z0 + L.cor.z1) / 2, ia = (x, z) => hack_.interaction(x, z);
assert(!ia(st.x, st.z) && !hack_.markTarget(), 'idle: nothing to do and nothing marked'); assert(ia(L.doorX + 20, mid).id === 'door-sealed'); assert(!ia(0, 0)); pass('idle: only "try the door" at the door; nothing is marked');
assert(hack_.reveal() && hack_.state === 'found' && !hack_.reveal()); assert(ia(st.x, st.z).id === 'hack' && ia(st.x, st.z).btn === 'Hack'); assert(!ia(-200, mid), 'hack prompt shows too far from the console');
const mt = hack_.markTarget(); assert(mt.kind === 'console' && mt.x === C.x); pass('found: the console is marked and offers Hack (only near it)');
assert(!hack_.breakIt() || true); // (breakIt allowed from hacking too; found is not allowed)
assert(hack_.state === 'found'); assert(!hack_.garble(), 'garble before hacking'); assert(hack_.beginHack() && hack_.state === 'hacking' && !hack_.beginHack());
assert(hack_.garble() && hack_.state === 'garbled'); assert(ia(st.x, st.z).id === 'break' && ia(st.x, st.z).btn === 'Break'); assert(hack_.markTarget().kind === 'console'); pass('hacking -> garbled: the prompt becomes Break');

// ---- compass / look maths used by game.js (copied formulas) ----
const lookYaw = (px, pz, tx, tz) => Math.atan2(-(tx - px), -(tz - pz)), heading = (yaw) => ((-yaw * 180 / Math.PI) % 360 + 360) % 360, relOf = (px, pz, yaw, tx, tz) => { const b = Math.atan2(tx - px, -(tz - pz)) * 180 / Math.PI; return ((b - heading(yaw) + 540) % 360) - 180; };
for (const [px, pz] of [[-200, -140], [-300, -150], [-375, -140], [-430, -125], [-460, -165]]) for (const [tx, tz] of [[C.x, C.z], [HACK.door.x, HACK.door.z]]) { const y = lookYaw(px, pz, tx, tz); assert(Math.abs(relOf(px, pz, y, tx, tz)) < 1e-6, 'compass bearing disagrees with the look-at yaw'); }
assert(Math.abs(relOf(-300, -140, Math.PI / 2, C.x, C.z) - (-16.4)) < 0.5, 'facing west the south-wall console should be on the left (-16 deg)'); assert(relOf(-300, -140, Math.PI / 2, C.x, C.z) < 0); pass('compass bearing and the look-at yaw agree; left/right is the right way round');

// ---- the break ----
const dt = 1 / 60, run = (sec, f) => { for (let i = 0; i < Math.round(sec / dt); i++) { lev.update(dt, cam, null); hack_.update(dt); if (f) f(i * dt); } };
const cam = { position: { x: 0, y: 0, z: 0, set(x, y, z) { this.x = x; this.y = y; this.z = z; }, copy() {} }, rotation: { x: 0, y: 0, z: 0, order: 'XYZ', set() {} }, quaternion: { x: 0, y: 0, z: 0, w: 1, copy() { return this; } } };
lev.begin(); hack_.setState('idle', true); hack_.reveal(); hack_.beginHack(); hack_.garble(); lev.setAlarm(0.3);
const lampBefore = [mats().lampOn.color.r, mats().lampOn.color.g, mats().lampOn.color.b]; function mats() { return lev.mats; }
assert(lampBefore[0] > lampBefore[1], 'lamps should start amber');
run(1, () => {}); assert(hack_.state === 'garbled' && Math.abs(hack_.green) < 1e-9 && hack_.blackout === 0); pass('while garbled nothing else changes: the lights stay amber, no blackout');
assert(hack_.breakIt() && hack_.state === 'breaking' && !hack_.breakIt());
let tBroken = -1, maxBlack = 0, sawDarkLamp = false, alarmAtDark = null, nanFound = false, maxShake = 0, prevGreen = 0, greenMono = true;
const lightsList = []; lev.scene.traverse(o => { if (o.intensity !== undefined && o.decay !== undefined) lightsList.push(o); });
run(4.5, (t) => { maxBlack = Math.max(maxBlack, hack_.blackout); maxShake = Math.max(maxShake, hack_.shake); if (hack_.blackout > 0.9 && mats().lampOn.color.g < 0.1) sawDarkLamp = true; if (hack_.blackout > 0.9 && alarmAtDark === null) alarmAtDark = lev.state.alarm;
    if (hack_.green + 1e-9 < prevGreen) greenMono = false; prevGreen = hack_.green; if (tBroken < 0 && hevents.includes('hack:broken')) tBroken = t;
    for (const l of lightsList) if (!Number.isFinite(l.intensity)) nanFound = true; for (const k of ['r', 'g', 'b']) if (!Number.isFinite(mats().lampOn.color[k]) || !Number.isFinite(mats().redPulse.color[k]) || !Number.isFinite(mats().lampFlick.color[k])) nanFound = true; });
assert(!nanFound, 'NaN in a light or lamp colour'); assert(tBroken > 3.3 && tBroken < 3.6, 'hack:broken fired at ' + tBroken); assert(hevents.filter(e => e === 'hack:broken').length === 1); pass('break timeline: "hack:broken" fires once, at ' + tBroken.toFixed(2) + ' s; no NaN anywhere');
assert(maxBlack > 0.99 && sawDarkLamp, 'there was no blackout'); assert(alarmAtDark === 0 && lev.state.alarm === 0, 'the alarm is not silenced'); assert(maxShake > 1.5); assert(greenMono); pass('blackout reaches full dark, the alarm drops to 0, the camera shake is large, green only ever rises');
assert(hack_.state === 'unlocked' && hack_.green === 1 && hack_.blackout === 0); const lc = mats().lampOn.color; assert(lc.g > lc.r * 2 && lc.g > 1.5, 'lamps are not green'); assert(mats().redPulse.color.g > mats().redPulse.color.r, 'status panels are not green'); pass('afterwards: lamps and status panels are green, the alarm lights are off');
assert(lev.parts.alarmA.intensity === 0 && lev.parts.alarmB.intensity === 0); assert(Math.abs(lev.parts.corB.intensity - lev.parts.corA.intensity) < 1e-6, 'corridor light still flickers'); pass('alarm lights are exactly 0; the corridor light no longer flickers');
const mk = hack_.markTarget(); assert(mk.kind === 'door' && mk.label === 'DOOR'); assert(ia(L.doorX + 20, mid).id === 'door' && ia(L.doorX + 20, mid).btn === 'Open'); assert(!ia(st.x, st.z), 'the console still offers something after it is broken'); pass('the door is marked and offers Open; the broken console offers nothing');

// ---- the door ----
const wl = lev.walk.length; assert(hack_.openDoor() && hack_.state === 'opening' && !hack_.openDoor());
let tOpen = -1, panelOk = true, prevK = 0; run(4, (t) => { if (hack_.doorProgress + 1e-9 < prevK) panelOk = false; prevK = hack_.doorProgress; if (tOpen < 0 && hevents.includes('door:opened')) tOpen = t; });
assert(tOpen > 2.7 && tOpen < 3.0 && panelOk, 'door:opened at ' + tOpen); assert(hack_.state === 'open' && hack_.markTarget() === null && !ia(L.doorX + 20, mid)); assert(lev.walk.length === wl + 1); pass('door opens in ' + tOpen.toFixed(2) + ' s, monotonically; no marker, no prompt, passage becomes walkable');
const p0 = hack_.parts.panels[0].position.z, p1 = hack_.parts.panels[1].position.z; assert(Math.abs(p0 + HACK.doorSlide) < 1e-6 && Math.abs(p1 - HACK.doorSlide) < 1e-6, 'panels did not slide fully'); pass('the two panels slide apart by ' + HACK.doorSlide);
assert(walkable(L.doorX + 3, mid) && walkable(L.doorX - 100, mid), 'cannot walk through the open door'); assert(!walkable(L.doorX + 7, L.cor.z0 + 3) && !walkable(L.doorX + 7, L.cor.z1 - 3), 'jamb posts are not solid'); assert(reach(L.exit.x, L.exit.z, (x) => x < L.doorX - 72), 'cannot reach the room beyond'); pass('the open door is walkable, the jambs stay solid, the room beyond is reachable from the hatch');
events.length = 0; lev.update(dt, { position: { set() {}, copy() {} }, rotation: { set() {} }, quaternion: { copy() { return this; } } }, { position: { x: L.doorX - 100, y: 8.5, z: mid } }); assert(events.includes('zone:beyond')); pass('walking through fires zone:beyond');

// ---- resume states ----
for (const [s, open] of [['unlocked', false], ['open', true]]) { const lv = createLeviathan({ onEvent() {}, getAudioContext: () => null }); lv.build(); const h = createHack(lv, {}); h.build(); lv.begin(); h.setState(s, true); lv.update(dt, cam, null); h.update(dt);
    assert(h.state === s && lv.state.alarm === 0 && h.green === 1); assert(open ? h.doorProgress === 1 && lv.walk.length === 3 : h.doorProgress === 0 && lv.walk.length === 2); assert(lv.interaction(0, 0) === null); if (!open) assert(h.interaction(L.doorX + 20, mid).id === 'door'); else assert(h.interaction(L.doorX + 20, mid) === null); }
pass('resuming straight into "unlocked" and "open" puts everything in place (alarm 0, green, door and passage right)');

// ---- pausing ----
const lv2 = createLeviathan({ onEvent() {}, getAudioContext: () => null }); lv2.build(); const h2 = createHack(lv2, {}); h2.build(); h2.setState('idle'); h2.reveal(); h2.beginHack(); h2.garble(); h2.breakIt(); for (let i = 0; i < 600; i++) h2.update(0); assert(h2.state === 'breaking' && h2.green === 0); pass('dt = 0 (paused) makes no progress');
// ---- idle is a no-op for the look of v111 ----
const lv3 = createLeviathan({ onEvent() {}, getAudioContext: () => null }); lv3.build(); const h3 = createHack(lv3, {}); h3.build(); lv3.begin(); const a0 = lv3.parts.alarmA.intensity; for (let i = 0; i < 30; i++) { lv3.update(dt, cam, null); h3.update(dt); }
assert(Math.abs(lv3.mats.lampOn.color.r - 1.6) < 1e-9 && Math.abs(lv3.mats.lampOn.color.g - 1.0) < 1e-9 && lv3.parts.alarmA.intensity > 0 && lv3.state.alarm === 0.3); pass('while idle the amber lamps and alarm lights are untouched');
// ---- the view outside (storm backdrop shader + cycle) ----
{ const fs_ = read('leviathan_sky.js').match(/const STORM_FS = `([\s\S]*?)`;/)[1];
  for (const fn of ['immersed', 'seaColor', 'skyBase', 'moonDisc', 'emerged']) assert(new RegExp('vec3 ' + fn + '\\(').test(fs_), 'missing shader function ' + fn);
  assert((fs_.match(/\{/g) || []).length === (fs_.match(/\}/g) || []).length && (fs_.match(/\(/g) || []).length === (fs_.match(/\)/g) || []).length, 'unbalanced braces/parens in the storm shader');
  for (const u of ['uTime', 'uFlash', 'uFlashDir', 'uSeed', 'uSteps', 'uClear', 'uSunDir', 'uMoonDir']) { assert(new RegExp('uniform [a-z0-9]+ [^;]*\\b' + u + '\\b').test(fs_), 'shader does not declare ' + u); assert(new RegExp(u + ':\\s*\\{').test(core), 'material does not supply ' + u); }
  assert(!/smoothstep\(\s*1\.0\s*,\s*0\.\d+/.test(fs_), 'smoothstep with edge0 > edge1 is undefined in GLSL');
  const nums = fs_.replace(/\/\/.*$/gm, '').match(/(?<![\w.])\d+(?![\w.])/g) || []; assert(nums.every(n => true));
  const bad = fs_.replace(/\/\/.*$/gm, '').match(/[^\w.]\d+\s*[*+\/-]\s*\d*\.\d|[^\w.]\d*\.\d+\s*[*+\/-]\s*\d+(?![\w.\d])/g); assert(!bad, 'int/float mixing in the shader: ' + bad);
  pass('storm shader: functions, uniforms (declared and supplied) and brackets all present; no undefined smoothstep ranges; no int/float mixing'); }
{ const sk = lev.skyClear; let mn = 9, mx = -9, prev = sk(0), maxStep = 0; for (let t = 0; t <= 300; t += 0.05) { const v = sk(t); mn = Math.min(mn, v); mx = Math.max(mx, v); maxStep = Math.max(maxStep, Math.abs(v - prev)); prev = v; }
  assert(mn === 0 && mx === 1 && maxStep < 0.02, 'sky cycle is not smooth: step ' + maxStep); assert(sk(0) === 0 && sk(20) === 1 && sk(90) === 0 && Math.abs(sk(100) - sk(0)) < 1e-9);
  let clearT = 0; for (let t = 0; t < 100; t += 0.1) if (sk(t) > 0.99) clearT += 0.1; console.log('      clear sky for', clearT.toFixed(0), 's of every 100 s'); assert(clearT > 50 && clearT < 70); pass('the sky cycle: immersed -> rises (10 s) -> clear -> sinks (12 s), smooth, repeating; clear about 55 s in 100'); }
{ const lv = createLeviathan({ onEvent() {}, getAudioContext: () => null }); lv.build(); lv.begin(); const c2 = { position: { x: 0, y: 0, z: 0, set() {}, copy() {} }, rotation: { x: 0, y: 0, z: 0, order: 'XYZ', set() {} }, quaternion: { copy() { return this; } } };
  for (let i = 0; i < 60 * 20; i++) lv.update(1 / 60, c2, null); const u = lv.parts.storm.material.uniforms; assert(u.uClear.value === 1 && u.uTime.value > 19); lv.setSky(0); lv.update(1 / 60, c2, null); assert(u.uClear.value === 0); lv.setSky(null); pass('uClear follows the cycle every frame and can be overridden'); }
console.log('\n' + ok + ' checks passed'); fs.rmSync(tmp, { recursive: true, force: true });
