# Measures a rendered dream WAV: peak, RMS per scene, band balance, stereo width, clipping, DC; optional spectrogram PNG.
# usage: python3 dream_audio_analyze.py a.wav [b.wav ...] [--png out.png]
import sys, wave, numpy as np
from scipy import signal
SC = [('kitchen', 1.2, 27.2), ('green', 27.2, 91.2), ('corridor', 91.2, 115.2), ('hearing', 115.2, 145.2), ('drift', 145.2, 173.2), ('water', 173.2, 201.2), ('end', 201.2, 206.2)]
def load(p):
    w = wave.open(p); n = w.getnframes(); sr = w.getframerate(); ch = w.getnchannels()
    a = np.frombuffer(w.readframes(n), dtype=np.int16).reshape(-1, ch).astype(np.float32) / 32768
    return sr, a
def db(x): return 20 * np.log10(max(x, 1e-9))
args = [a for a in sys.argv[1:] if not a.startswith('--')]
png = sys.argv[sys.argv.index('--png') + 1] if '--png' in sys.argv else None
if png: args = [a for a in args if a != png]
bands = [(20, 120), (120, 500), (500, 2000), (2000, 6000), (6000, 16000)]
for p in args:
    sr, a = load(p); L, R = a[:, 0], a[:, 1]
    print('==', p, 'dur %.1fs' % (len(a) / sr), 'peak L %.3f R %.3f' % (np.abs(L).max(), np.abs(R).max()), 'clipped samples', int((np.abs(a) > 0.999).sum()), 'DC %.5f' % a.mean())
    m = (L + R) / 2
    for name, t0, t1 in SC:
        i0, i1 = int(t0 * sr), min(len(a), int(t1 * sr))
        if i1 <= i0: continue
        seg = a[i0:i1]; ms = m[i0:i1]; rms = np.sqrt((seg ** 2).mean())
        f, P = signal.welch(ms, sr, nperseg=4096); tot = P.sum() + 1e-18
        bl = ' '.join('%5.1f' % (10 * np.log10(P[(f >= lo) & (f < hi)].sum() / tot + 1e-12)) for lo, hi in bands)
        cor = np.corrcoef(seg[:, 0], seg[:, 1])[0, 1] if seg.std() > 1e-6 else 1
        side = np.sqrt((((seg[:, 0] - seg[:, 1]) / 2) ** 2).mean()) / (np.sqrt((((seg[:, 0] + seg[:, 1]) / 2) ** 2).mean()) + 1e-9)
        print('  %-9s rms %6.1f dB peak %6.1f dB  corr %5.2f side/mid %4.2f  bands(20-120,120-500,.5-2k,2-6k,6-16k) %s' % (name, db(rms), db(np.abs(seg).max()), cor, side, bl))
if png:
    import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
    fig, axs = plt.subplots(len(args), 1, figsize=(16, 3.4 * len(args)), squeeze=False)
    for ax, p in zip(axs[:, 0], args):
        sr, a = load(p); m = a.mean(1); f, t, S = signal.spectrogram(m, sr, nperseg=2048, noverlap=1536)
        ax.pcolormesh(t, f, 10 * np.log10(S + 1e-12), vmin=-120, vmax=-40, shading='auto', cmap='magma'); ax.set_yscale('symlog', linthresh=200); ax.set_ylim(30, 16000); ax.set_title(p.split('/')[-1])
        for name, t0, t1 in SC: ax.axvline(t0, color='w', lw=0.5, alpha=0.5); ax.text(t0 + 0.5, 20000 if False else 9000, name, color='w', fontsize=8)
    plt.tight_layout(); plt.savefig(png, dpi=70); print('wrote', png)
