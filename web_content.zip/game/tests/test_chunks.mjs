import { TerrainCore } from '../terrain_core.js';
import * as V from '../valley_sites.js';
import { ChunkBuilder, CHUNK_SIZE } from '../chunk_core.js';
import { faceOfGeo, geoToChart } from '../planet_core.js';
const seed = 424242, T = new TerrainCore(seed), sites = V.findSites(T, seed).sites;
const withV = new ChunkBuilder(seed, sites), without = new ChunkBuilder(seed, []);
let totalFail = 0;
for (const S of sites.slice(0, 3)) {
  const face = faceOfGeo(...S.dir), c = {x:0,z:0}; geoToChart(face, ...S.dir, c);
  const gx = Math.round(c.x / CHUNK_SIZE), gz = Math.round(c.z / CHUNK_SIZE);
  const job = { key: `${gx},${gz}`, face, gx, gz, S: 320, edge: [0,0,0,0] };
  let t0 = performance.now(); const a = withV.buildTerrain(job).out; const tTerr = performance.now() - t0;
  const b = without.buildTerrain({ ...job }).out;
  // heights near site centre
  const ps = withV.valleys.placed(face).find(p => p.site === S);
  const V1 = 321, vs = CHUNK_SIZE / 320, offX = gx*CHUNK_SIZE - CHUNK_SIZE/2, offZ = gz*CHUNK_SIZE - CHUNK_SIZE/2;
  let nan = 0, minF = 1e9, maxF = -1e9, nF = 0, changed = 0;
  for (let i = 0; i < a.height.length; i++) { if (!isFinite(a.height[i])) nan++; }
  for (let iz = 0; iz < V1; iz++) for (let ix = 0; ix < V1; ix++) { const x = offX + ix*vs, z = offZ + iz*vs, r = Math.hypot(x-ps.cx, z-ps.cz)*ps.gnd, h = a.height[iz*V1+ix], lc = V.toLocal(ps, x, z, {a:0,n:0}); if (r < V.floorRadius(S, lc.a, lc.n)*0.9) { minF=Math.min(minF,h); maxF=Math.max(maxF,h); nF++; } if (Math.abs(a.height[iz*V1+ix]-b.height[iz*V1+ix])>1) changed++; }
  // scatter
  t0 = performance.now(); const sa = withV.buildScatter({ ...job, lod: 0 }).out; const tSc = performance.now() - t0; const sb = without.buildScatter({ ...job, lod: 0 }).out;
  const cnt = (o) => Object.values(o.cats).reduce((s,f)=>s+f.length/16,0);
  let inside = 0; for (const k in sa.cats) { const f = sa.cats[k]; for (let i=0;i<f.length;i+=16){ const x=f[i+12], z=f[i+14]; const lc = V.toLocal(ps, x+gx*CHUNK_SIZE, z+gz*CHUNK_SIZE, {a:0,n:0}); if (V.clearHere(S, lc.a, lc.n)) inside++; } }
  // note: scatter instance positions are world (chart) coords already
  let insideB = 0; for (const k in sb.cats) { const f = sb.cats[k]; for (let i=0;i<f.length;i+=16){ const x=f[i+12], z=f[i+14]; const lc = V.toLocal(ps, x, z, {a:0,n:0}); if (V.clearHere(S, lc.a, lc.n)) insideB++; } }
  // recompute inside for A in world coords
  let insideA = 0; for (const k in sa.cats) { const f = sa.cats[k]; for (let i=0;i<f.length;i+=16){ const x=f[i+12], z=f[i+14]; const lc = V.toLocal(ps, x, z, {a:0,n:0}); if (V.clearP(S, lc.a, lc.n) >= 1) insideA++; } }
  console.log(`site ${S.id} face ${face}: terrain ${tTerr.toFixed(0)}ms NaN=${nan}, floor(r<0.9Rf) min..max ${minF.toFixed(1)}..${maxF.toFixed(1)} (spread ${(maxF-minF).toFixed(1)}), vertices changed ${changed}; scatter ${tSc.toFixed(0)}ms props with valley ${cnt(sa)} vs without ${cnt(sb)}; props inside clear radius: with=${insideA} without=${insideB}`);
  if (nan || insideA) totalFail++;
  // city + road via the builder
  t0 = performance.now(); const cj = withV.buildCity({ siteId: S.id }); console.log(`   buildCity ${(performance.now()-t0).toFixed(0)}ms, transfer buffers ${cj.tr.length}, buildings ${cj.out.life.meta.stats.buildings}, cats ${Object.keys(cj.out.inst.cats).length}`);
}
// edge continuity between two adjacent valley chunks
{
  const S = sites[3], face = faceOfGeo(...S.dir), c = {x:0,z:0}; geoToChart(face, ...S.dir, c); const gx = Math.round(c.x/CHUNK_SIZE), gz = Math.round(c.z/CHUNK_SIZE);
  const A = withV.buildTerrain({ key:'a', face, gx, gz, S:320, edge:[0,0,0,0] }).out, B = withV.buildTerrain({ key:'b', face, gx:gx+1, gz, S:320, edge:[0,0,0,0] }).out;
  let md = 0; for (let iz=0; iz<=320; iz++) md = Math.max(md, Math.abs(A.height[iz*321+320] - B.height[iz*321]));
  console.log('shared-edge max height diff between neighbouring chunks', md.toFixed(4));
}
// roads through builder
{ const t0 = performance.now(); const r = withV.buildRoad({ a: 0, b: 1 }); console.log('buildRoad via ChunkBuilder', r.out.road && r.out.road.ok ? 'ok' : 'no route (expected when not land-linked)', (performance.now()-t0).toFixed(0)+'ms'); }
console.log(totalFail ? 'FAILURES: '+totalFail : 'all chunk checks passed');
