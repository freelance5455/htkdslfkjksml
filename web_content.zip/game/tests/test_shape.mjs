// v53: the terrain under a city must stay the natural terrain (no stamped bowl): measure how much valleyHeight differs from the natural ground.
import { TerrainCore } from '../terrain_core.js';
import * as V from '../valley_sites.js';
import { PLANET_R } from '../planet_core.js';
const seed = +process.argv[2] || 424242, T = new TerrainCore(seed), o = {}, d = [0, 0, 0];
const r = V.findSites(T, seed);
const nat = (S, a, n) => { V.localToDir(S, a, n, d); return T.sample3(d[0] * PLANET_R, d[1] * PLANET_R, d[2] * PLANET_R, o); };
let worstMean = 0;
for (const S of r.sites.slice(0, 12)) {
    let sum = 0, cnt = 0, mx = 0, plateau = 0, plateauN = 0, slopeSum = 0, slopeN = 0;
    for (let a = -S.rimR; a <= S.rimR; a += 40) for (let n = -S.rimR; n <= S.rimR; n += 40) {
        const rr = Math.hypot(a, n); if (rr > S.rimR) continue;
        const h = nat(S, a, n), v = V.valleyHeight(S, a, n, h), dd = Math.abs(v - h); sum += dd; cnt++; mx = Math.max(mx, dd);
        if (rr < 150) { plateau += dd; plateauN++; }
        if (rr < S.Rf) { const sl = Math.hypot(nat(S, a + 20, n) - nat(S, a - 20, n), nat(S, a, n + 20) - nat(S, a, n - 20)) / 40; slopeSum += sl; slopeN++; }
    }
    worstMean = Math.max(worstMean, sum / cnt);
    console.log(`site ${S.id}: footprint r ${Math.min(...S.ft) | 0}..${Math.max(...S.ft) | 0} (mean ${S.Rf}) rim ${S.rimR} | ground moved: mean ${(sum / cnt).toFixed(1)} u, max ${mx.toFixed(0)} u, hub square ${(plateau / plateauN).toFixed(1)} u | mean natural slope inside the city ${(slopeSum / slopeN).toFixed(2)} | gate@${(S.passAng * 57.3) | 0} deg`);
}
console.log('worst mean change', worstMean.toFixed(1), worstMean < 12 ? 'OK: terrain stays natural' : 'WARNING: terrain heavily modified');
