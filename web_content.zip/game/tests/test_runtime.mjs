// Smoke test of city_runtime.js with a stub three.js + stub DOM (no WebGL here): catches logic / typo errors, NOT rendering problems.
import { TerrainCore } from '../terrain_core.js';
import * as V from '../valley_sites.js';
import { ChunkBuilder } from '../chunk_core.js';
import { faceOfGeo, geoToChart } from '../planet_core.js';

const mk = (name, extra = {}) => class { constructor(...a) { this.args = a; this.name = name; this.position = new Vec(); this.rotation = new Vec(); this.scale = new Vec(1,1,1); this.children = []; this.userData = {}; Object.assign(this, extra); if (name === 'Sprite') this.material = a[0]; if (name === 'Mesh') { this.geometry = a[0]; this.material = a[1]; } } add(o) { this.children.push(o); return this; } remove(o) { this.children = this.children.filter(c => c !== o); } updateMatrixWorld() {} translate() { return this; } scale_() { return this; } rotateX() { return this; } computeVertexNormals() {} setAttribute() {} setIndex() {} dispose() {} };
class Vec { constructor(x=0,y=0,z=0){this.x=x;this.y=y;this.z=z;} set(x,y,z){this.x=x;this.y=y;this.z=z;return this;} project(){ this.x=0;this.y=0;this.z=0.5; return this; } }
class Geo { constructor(){} translate(){return this;} scale(){return this;} rotateX(){return this;} computeVertexNormals(){} setAttribute(){} setIndex(){} dispose(){} }
class IM { constructor(g,m,n){ this.geometry=g; this.material=m; this.count=n; this.instanceMatrix={array:new Float32Array(n*16),needsUpdate:false,setUsage(){}}; this.instanceColor=null; this.userData={}; this.visible=true; } setMatrixAt(){} setColorAt(){} }
const THREE = { Group: mk('Group'), InstancedMesh: IM, BoxGeometry: Geo, CylinderGeometry: Geo, ConeGeometry: Geo, SphereGeometry: Geo, BufferGeometry: Geo, ExtrudeGeometry: Geo, Shape: class { moveTo(){} lineTo(){} quadraticCurveTo(){} },
  Float32BufferAttribute: class {}, BufferAttribute: class { constructor(a){ this.array=a; } }, InstancedBufferAttribute: class { constructor(a){ this.array=a; } }, MeshStandardMaterial: class { constructor(o){ Object.assign(this,o); this.userData={}; } }, MeshBasicMaterial: class { constructor(o){ Object.assign(this,o); this.userData={}; } },
  SpriteMaterial: class { constructor(o){ Object.assign(this,o); } }, Sprite: mk('Sprite', {}), Mesh: mk('Mesh', {}), CanvasTexture: class {}, Color: class { constructor(c){ this.c=c; } }, Matrix4: class { compose(){return this;} }, Quaternion: class { setFromAxisAngle(){return this;} }, Vector3: Vec,
  DynamicDrawUsage: 1, AdditiveBlending: 2, DoubleSide: 2, ShaderMaterial: class { constructor(o){ Object.assign(this,o); } } };
// stub DOM
const els = []; const mkEl = () => { const e = { getContext(){ return { createRadialGradient(){ return { addColorStop(){} }; }, fillRect(){} }; }, style: {}, children: [], className: '', innerHTML: '', textContent: '', appendChild(c){ this.children.push(c); return c; }, addEventListener(){}, querySelector(sel){ return mkEl(); }, set onclick(f){ this._click = f; } }; els.push(e); return e; };
globalThis.document = { createElement: () => mkEl(), head: { appendChild(){} }, body: { appendChild(){} }, pointerLockElement: null };
globalThis.window = { addEventListener(){}, innerWidth: 1280, innerHeight: 720 };
const { CityWorld } = await import('../city_runtime.js');

const seed = 424242, T = new TerrainCore(seed), sites = V.findSites(T, seed).sites, builder = new ChunkBuilder(seed, sites), valleys = new V.ValleyField(sites);
const S = sites[3], face = faceOfGeo(...S.dir), c = { x: 0, z: 0 }; geoToChart(face, ...S.dir, c);
const player = new Vec(c.x + 300, 2500, c.z + 100);   // 300 units from centre: inside sim radius
const inv = { wood: 20, stone: 10, piezoQuartz: 4, siliconFerrite: 0, bioFluorite: 2, ventMinerals: 1 };
let dayTime = 0.4, time = 0, paused = false, jobs = 0;
const world = new CityWorld({ THREE, scene: new THREE.Group(), camera: {}, sites, valleys, getFace: () => face, getPlayer: () => player, getDayTime: () => dayTime, getNight: () => 0, getTime: () => time, getGround: () => 2300, machineDestroyed: () => false, isPaused: () => paused, pause: (p) => { paused = p; },
  postJob: (type, job, cb) => { jobs++; const r = type === 'city' ? builder.buildCity(job) : builder.buildRoad(job); cb(r.out); }, inv: { get: k => inv[k] || 0, add: (k, n) => { inv[k] = (inv[k] || 0) + n; } } });
let errs = 0;
for (let f = 0; f < 600; f++) { try { world.update(0.05); } catch (e) { errs++; if (errs < 3) console.log('update error', e.stack.split('\n').slice(0,3).join(' | ')); } time += 0.05; dayTime = (dayTime + 0.0002) % 1; }
const rec = world.rec(S);
console.log('city state', rec.state, '| meshes', Object.keys(rec.meshes).join(','), '| sim drones', rec.sim ? rec.sim.drones.length : 0, '| jobs posted', jobs, '| update errors', errs);
console.log('instanced draw count', world.dm.body.count, '| beacons', world.recs.size, '| bubbles in last frame', world.bubblesToShow.length);
// LOD: move far
player.x = c.x + 9000; for (let f=0; f<3; f++) world.update(0.05);
console.log('LOD @9000: wall visible', rec.meshes.wallBox.visible, 'glow visible', rec.meshes.glow.visible, 'sky visible', rec.meshes.sky ? rec.meshes.sky.visible : 'n/a', '| sim dropped', rec.sim === null);
player.x = c.x + 25000; for (let f=0; f<3; f++) world.update(0.05);
console.log('LOD @25000: wall visible', rec.meshes.wallBox.visible, 'sky visible', rec.meshes.sky ? rec.meshes.sky.visible : 'n/a', 'beacon visible', rec.beacon.spr.visible);
// interaction + trade
player.x = c.x + 250; player.z = c.z; for (let f = 0; f < 200; f++) { world.update(0.05); time += 0.05; if (world.hover) break; }
console.log('hover target', world.hover ? world.hover.kind : 'none');
if (world.hover && world.hover.kind === 'res') {
  const ok = world.tryInteract(); console.log('tryInteract', ok, 'uiOpen', world.uiOpen, 'paused', paused);
  world.openTrade(rec, world.hover ? world.hover.d : rec.sim.drones[0]);
  // simulate trade using economy directly through the same API the button uses
  const before = { ...inv }; const econ = rec.econ; const { quote, execute } = await import('../city_life.js');
  const q = quote(econ, 'wood', 'piezoQuartz', 10); const r = execute(econ, 'wood', 'piezoQuartz', 10); if (r.ok) { world.ctx.inv.add('wood', -10); world.ctx.inv.add('piezoQuartz', r.got); }
  console.log('trade 10 wood ->', r.got, 'piezo; inventory wood', before.wood, '->', inv.wood, 'piezo', before.piezoQuartz, '->', inv.piezoQuartz);
  world.closeUI(); console.log('after close: uiOpen', world.uiOpen, 'paused', paused);
}
console.log('state roundtrip', JSON.stringify(Object.keys(world.getState().econ)));
console.log(errs ? 'FAIL' : 'runtime smoke test passed');
// ---- talk / trade path: stand next to an awake drone ----
{
  player.x = c.x; player.z = c.z; for (let f = 0; f < 5; f++) world.update(0.05);
  const ps = world.valleys.placed(face).find(p => p.site === S), w = { x: 0, z: 0 };
  const d = rec.sim.drones.find(d => !d.asleep); world.toWorld(ps, d.x + 4, d.z, w); player.x = w.x; player.z = w.z;
  world.update(0.05);
  console.log('hover now', world.hover && world.hover.kind, world.hover && world.hover.d && world.hover.d.res.name);
  console.log('prompt text', world.promptEl.textContent, '| display', world.promptEl.style.display);
  console.log('tryInteract ->', world.tryInteract(), '| uiOpen', world.uiOpen, '| game paused', paused, '| panel display', world.panel.style.display, '| buttons built', world.panel.children.length);
  world.openTrade(rec, d); console.log('trade panel built OK; closing'); world.closeUI();
  // machine destroyed: dialogue switches
  const { topics, greeting } = await import('../city_life.js');
  console.log('machine flag false/true empire reply differs:', topics(d.res, {machineDestroyed:false,cityName:'X'})[3].reply !== topics(d.res, {machineDestroyed:true,cityName:'X'})[3].reply);
  // bubbles: run a while with player nearby and count
  let seen = 0; for (let f = 0; f < 400; f++) { world.update(0.05); time += 0.05; seen = Math.max(seen, world.bubblesToShow.length); }
  console.log('max bubbles on screen over 20s near drones', seen);
}
// ---- v54: player collision through the runtime (local<->chart round trip) ----
{
  const ps = world.valleys.placed(face).find(p => p.site === S), w = { x: 0, z: 0 }; player.x = c.x; player.z = c.z; world.update(0.05);
  const col = rec.col; let landed = false;
  const bb = rec.data.life.poi.homes[0]; world.toWorld(ps, bb.x, bb.z, w);
  const pl = { position: { x: w.x, y: bb.y + 400, z: w.z }, height: 8.5, velocity: { y: -50 }, cameraY: bb.y + 400, isGrounded: false };
  for (let i = 0; i < 200; i++) { const py = pl.position.y; pl.position.y -= 4; world.collidePlayer(pl, pl.position.x, py, pl.position.z); if (pl.isGrounded) { landed = true; break; } }
  console.log('player falling onto a city lands:', landed, 'y', pl.position.y.toFixed(1), 'col boxes', col.n);
  if (!landed) { console.log('FAIL collide'); process.exit(1); }
}
