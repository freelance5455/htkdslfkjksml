#!/bin/sh
# usage: crop_shade.sh seed lon0 lon1 lat0 lat1 W out.png [exaggeration]   (dumps a window, then hillshades it)
D=$(dirname "$0"); B=$(mktemp -d)/c.bin
HW=$(node "$D/map_crop.mjs" $1 $2 $3 $4 $5 $6 "$B") || exit 1
H=$(echo $HW | cut -d' ' -f2)
PLANET_R=278521.15041081683 python3 -I "$D/map_shade.py" "$B" $6 $H $2 $3 $4 $5 $7 ${8:-6}
