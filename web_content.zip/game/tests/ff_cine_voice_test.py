# Plays the whole cinematic headless with a mock speakLine and prints when each line was spoken. usage: python3 ff_cine_voice_test.py [vale|novale]
import sys, os, subprocess, time, json
from playwright.sync_api import sync_playwright
vale = (sys.argv[1] if len(sys.argv) > 1 else 'vale') == 'vale'
srv = subprocess.Popen([sys.executable, '-m', 'http.server', '8766', '--directory', os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(1)
try:
    with sync_playwright() as p:
        b = p.chromium.launch(args=['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--no-sandbox'])
        pg = b.new_page(viewport={'width': 256, 'height': 144})
        errs = []; pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('console', lambda m: errs.append(m.text) if m.type == 'error' else None)
        pg.goto('http://localhost:8766/tests/ff_cine_voice_test.html'); pg.wait_for_timeout(1000)
        pg.evaluate(f'window.run({str(vale).lower()}).then(() => window.__done = true)')
        pg.wait_for_function('window.__done === true', timeout=400000)
        for l in pg.evaluate('window.log'): print(l['at'], '|', l['text'])
        print('ERRORS', errs[:5]); b.close()
finally:
    srv.terminate()
