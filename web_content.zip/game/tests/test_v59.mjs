// v59 Step 1: plate-driven land. Reports land share, landmass hierarchy, and surface continuity (cliff share) for several seeds.
import { TerrainCore } from '../terrain_core.js';
import { PLANET_R } from '../planet_core.js';
const seeds = process.argv.slice(2).map(Number); if (!seeds.length) seeds.push(424242, 7, 99991);
const D = Math.PI / 180;
for (const seed of seeds) {
    const T = new TerrainCore(seed), o = {};
    const W = 360, H = 180, land = new Uint8Array(W * H), hh = new Float32Array(W * H);
    const P = (i, j) => { const lat = (0.5 - (j + .5) / H) * Math.PI, lon = ((i + .5) / W - .5) * 2 * Math.PI, cl = Math.cos(lat); return [cl * Math.sin(lon) * PLANET_R, Math.sin(lat) * PLANET_R, cl * Math.cos(lon) * PLANET_R]; };
    let nl = 0, n = 0, nan = 0;
    for (let j = 8; j < H - 8; j++) for (let i = 0; i < W; i++) { const p = P(i, j), h = T._terrain(p[0], p[1], p[2], 1, o); if (!Number.isFinite(h)) nan++; hh[j * W + i] = h; land[j * W + i] = h > 0 ? 1 : 0; n++; if (h > 0) nl++; }
    // landmass labelling (flood fill, wraps in longitude)
    const lab = new Int32Array(W * H), sizes = []; let L = 0;
    for (let s0 = 0; s0 < W * H; s0++) { if (!land[s0] || lab[s0]) continue; L++; let cnt = 0; const st = [s0]; lab[s0] = L;
        while (st.length) { const c = st.pop(); cnt++; const x = c % W, y = (c / W) | 0; for (const [dx, dy] of [[1,0],[-1,0],[0,1],[0,-1]]) { const nx = (x + dx + W) % W, ny = y + dy; if (ny < 0 || ny >= H) continue; const k = ny * W + nx; if (land[k] && !lab[k]) { lab[k] = L; st.push(k); } } }
        sizes.push(cnt); }
    sizes.sort((a, b) => b - a); const tot = sizes.reduce((a, b) => a + b, 0);
    const small = sizes.filter(s => s <= 4).length, med = sizes.filter(s => s > 4 && s <= 60).length, big = sizes.filter(s => s > 60).length;
    // cliffs: land slope over 22-unit steps on random points
    let cl = 0, cn = 0, hs = [];
    for (let k = 0; k < 40000; k++) { const lat = Math.asin(2 * Math.random() - 1) * 0.95, lon = Math.random() * 6.283, c = Math.cos(lat);
        const x = c * Math.sin(lon) * PLANET_R, y = Math.sin(lat) * PLANET_R, z = c * Math.cos(lon) * PLANET_R;
        const h0 = T._terrain(x, y, z, 1, o); if (h0 < 5) continue; const h1 = T._terrain(x + 22, y, z, 1, o), h2 = T._terrain(x, y, z + 22, 1, o);
        cn++; hs.push(h0); if (Math.hypot(h1 - h0, h2 - h0) / 22 > 3) cl++; }
    hs.sort((a, b) => a - b); const q = p => hs[Math.floor(p * (hs.length - 1))] | 0;
    console.log(`seed ${seed}: land ${(100 * nl / n).toFixed(1)}% | landmasses ${sizes.length} (big ${big}, medium ${med}, islets ${small}) | largest ${(100 * sizes[0] / tot).toFixed(0)}% of land | land height p50/p90/p99 ${q(.5)}/${q(.9)}/${q(.99)} | cliffs ${(100 * cl / cn).toFixed(3)}% | NaN ${nan}`);
}
