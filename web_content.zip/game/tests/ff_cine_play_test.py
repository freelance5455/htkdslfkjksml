import sys, os, subprocess, time
from playwright.sync_api import sync_playwright
srv = subprocess.Popen([sys.executable, '-m', 'http.server', '8766', '--directory', os.path.join(os.path.dirname(__file__), '..')], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(1)
try:
    with sync_playwright() as p:
        b = p.chromium.launch(args=['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--no-sandbox', '--autoplay-policy=no-user-gesture-required'])
        pg = b.new_page(viewport={'width': 844, 'height': 390}); logs = []
        pg.on('console', lambda m: logs.append(m.text)); pg.on('pageerror', lambda e: logs.append('PAGEERR ' + str(e)))
        pg.goto('http://localhost:8766/tests/ff_cine_blank.html'); pg.wait_for_timeout(500)
        pg.evaluate("""() => { window.__log=[]; const ctx = new AudioContext();
          window.c = window.mk({ getAudioContext: () => ctx });
          window.p = window.c.play({ whileBlack: async () => { window.__log.push('whileBlack'); } }).then(() => window.__log.push('resolved')); }""")
        pg.wait_for_timeout(9000)
        print('active mid-play:', pg.evaluate('window.c.active'), 'flag:', pg.evaluate('window.__ffCineActive'))
        pg.evaluate('window.c.skip()'); pg.wait_for_timeout(2500)
        print('log:', pg.evaluate('window.__log'), 'active:', pg.evaluate('window.c.active'), 'flag:', pg.evaluate('window.__ffCineActive'))
        pg.wait_for_timeout(1200); print('overlay removed:', pg.evaluate("!document.getElementById('ffCine')"))
        print('console:', [l for l in logs if 'GPU stall' not in l][:6])
        b.close()
finally:
    srv.terminate()
