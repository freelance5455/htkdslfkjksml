// Smoke test of city_runtime.js with a stub three.js + stub DOM (no WebGL here): catches logic / typo errors, NOT rendering problems.
import { TerrainCore } from '../terrain_core.js';
import * as V from '../valley_sites.js';
import { ChunkBuilder } from '../chunk_core.js';
import { faceOfGeo, geoToChart } from '../planet_core.js';

const mk = (name, extra = {}) => class { constructor(...a) { this.args = a; this.name = name; this.position = new Vec(); this.rotation = new Vec(); this.scale = new Vec(1,1,1); this.children = []; this.userData = {}; Object.assign(this, extra); if (name === 'Sprite') this.material = a[0]; if (name === 'Mesh') { this.geometry = a[0]; this.material = a[1]; } } add(o) { this.children.push(o); return this; } remove(o) { this.children = this.children.filter(c => c !== o); } updateMatrixWorld() {} translate() { return this; } scale_() { return this; } rotateX() { return this; } computeVertexNormals() {} setAttribute() {} setIndex() {} dispose() {} };
class Vec { constructor(x=0,y=0,z=0){this.x=x;this.y=y;this.z=z;} set(x,y,z){this.x=x;this.y=y;this.z=z;return this;} project(){ this.x=0;this.y=0;this.z=0.5; return this; } }
class Geo { constructor(){} translate(){return this;} scale(){return this;} rotateX(){return this;} computeVertexNormals(){} setAttribute(){} setIndex(){} dispose(){} }
class IM { constructor(g,m,n){ this.geometry=g; this.material=m; this.count=n; this.instanceMatrix={array:new Float32Array(n*16),needsUpdate:false,setUsage(){}}; this.instanceColor=null; this.userData={}; this.visible=true; } setMatrixAt(){} setColorAt(){} }
const THREE0 = { Group: mk('Group'), InstancedMesh: IM, BoxGeometry: Geo, CylinderGeometry: Geo, ConeGeometry: Geo, SphereGeometry: Geo, BufferGeometry: Geo, ExtrudeGeometry: Geo, Shape: class { moveTo(){} lineTo(){} quadraticCurveTo(){} },
  Float32BufferAttribute: class {}, BufferAttribute: class { constructor(a){ this.array=a; } }, InstancedBufferAttribute: class { constructor(a){ this.array=a; } }, MeshStandardMaterial: class { constructor(o){ Object.assign(this,o); this.userData={}; } }, MeshBasicMaterial: class { constructor(o){ Object.assign(this,o); this.userData={}; } },
  SpriteMaterial: class { constructor(o){ Object.assign(this,o); } }, Sprite: mk('Sprite', {}), Mesh: mk('Mesh', {}), CanvasTexture: class {}, Color: class { constructor(c){ this.c=c; } }, Matrix4: class { compose(){return this;} }, Quaternion: class { setFromAxisAngle(){return this;} }, Vector3: Vec,
  DynamicDrawUsage: 1, AdditiveBlending: 2, DoubleSide: 2 };
THREE0.ShaderMaterial = class { constructor(o) { Object.assign(this, o); } }; THREE0.Points = class { constructor(g, m) { this.geometry = g; this.material = m; this.visible = true; this.position = new Vec(); } }; THREE0.PointsMaterial = class { constructor(o) { Object.assign(this, o); } };
const THREE = new Proxy(THREE0, { get: (t, k) => k in t ? t[k] : (typeof k === 'string' && /^[A-Z]/.test(k) ? (t[k] = mk(k)) : undefined) });
// stub DOM
const els = []; const mkEl = () => { const e = { getContext(){ return { createRadialGradient(){ return { addColorStop(){} }; }, fillRect(){} }; }, style: {}, children: [], className: '', innerHTML: '', textContent: '', appendChild(c){ this.children.push(c); return c; }, addEventListener(){}, querySelector(sel){ return mkEl(); }, set onclick(f){ this._click = f; } }; els.push(e); return e; };
globalThis.document = { createElement: () => mkEl(), head: { appendChild(){} }, body: { appendChild(){} }, pointerLockElement: null };
globalThis.window = { addEventListener(){}, innerWidth: 1280, innerHeight: 720 };
const { CityWorld } = await import('../city_runtime.js');

const seed = 424242, T = new TerrainCore(seed), sites = V.findSites(T, seed).sites, builder = new ChunkBuilder(seed, sites), valleys = new V.ValleyField(sites);
const S = sites.find(s => s.citadel), face = faceOfGeo(...S.dir), c = { x: 0, z: 0 }; geoToChart(face, ...S.dir, c);
const player = new Vec(c.x + 300, S.floorH + 400, c.z + 100);   // 300 units from centre: inside sim radius
const inv = { wood: 20, stone: 10, piezoQuartz: 4, siliconFerrite: 0, bioFluorite: 2, ventMinerals: 1 };
let dayTime = 0.4, time = 0, paused = false, jobs = 0;
const world = new CityWorld({ THREE, scene: new THREE.Group(), camera: {}, sites, valleys, getFace: () => face, getPlayer: () => player, getDayTime: () => dayTime, getNight: () => 0, getTime: () => time, getGround: () => 2300, machineDestroyed: () => false, isPaused: () => paused, pause: (p) => { paused = p; },
  postJob: (type, job, cb) => { jobs++; const r = type === 'city' ? builder.buildCity(job) : builder.buildRoad(job); cb(r.out); }, inv: { get: k => inv[k] || 0, add: (k, n) => { inv[k] = (inv[k] || 0) + n; } } });
let errs = 0;
for (let f = 0; f < 700; f++) { try { world.update(0.05); } catch (e) { errs++; if (errs < 4) console.log('update error', e.stack.split('\n').slice(0, 4).join(' | ')); } time += 0.05; }
const rec = world.rec(S);
console.log('citadel state', rec.state, '| name', rec.name, '| meshes', Object.keys(rec.meshes).length, '| sim drones', rec.sim ? rec.sim.drones.length : 0, '| errors', errs, '| beam', !!rec.cbeam, '| sparkles', !!rec.sparkles, '| tunnel', !!rec.tunnel);
console.log('instance counts: org', rec.meshes.orgCyl && rec.meshes.orgCyl.count, 'tp3', rec.meshes.tp3 && rec.meshes.tp3.count, 'glowCyl', rec.meshes.glowCyl && rec.meshes.glowCyl.count);
// tunnel detection: stand in the bore and outside it
const ps = world.valleys.placed(face).find(p => p.site === S), t = rec.tunnel, w = { x: 0, z: 0 };
const at = (s, l, y) => { world.toWorld(ps, t.tx * s - t.tz * l, t.tz * s + t.tx * l, w); const p = new Vec(w.x, y, w.z); return p; };
const mid = (t.sIn + t.sOut) / 2, yM = t.yT - t.gt * (mid - t.sIn) + (rec.yOff || 0); console.log('yOff', rec.yOff);
console.log('inTunnel in the bore', world.inTunnel(at(mid, 0, yM + 8.5 + 1)), '| outside (beside)', world.inTunnel(at(mid, 200, yM + 8.5 + 1)), '| above the mountain', world.inTunnel(at(mid, 0, yM + 400)), '| on the promenade', world.inTunnel(at(t.sIn - 100, 0, t.yT + 9 + (rec.yOff || 0))));
// LOD + far beam
player.x = c.x + 30000; for (let f = 0; f < 4; f++) world.update(0.05);
console.log('LOD @30000: beam visible', rec.cbeam.grp.visible, 'sparkles', rec.sparkles.visible, 'orgCyl visible', rec.meshes.orgCyl.visible);
player.x = c.x + 200000; for (let f = 0; f < 4; f++) world.update(0.05);
console.log('@200000: beam visible', rec.cbeam.grp.visible);
console.log(errs ? 'FAIL' : 'citadel runtime smoke test passed'); process.exit(errs ? 1 : 0);
