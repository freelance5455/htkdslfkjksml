// v111 headless test for leviathan_core.js. No WebGL here: three.js is replaced by a small stub that records geometry, and the module is
// loaded from a patched copy. It checks: the interior builds, every index/normal is sane, the player can walk from the hatch exit to the
// blast door (and cannot walk through walls, crates or the ship), the scripted landing runs start to finish with the right events and
// never produces NaN, and the zone triggers fire.     node tests/test_v111_leviathan.mjs
import fs from 'node:fs'; import os from 'node:os'; import path from 'node:path'; import assert from 'node:assert/strict'; import { fileURLToPath, pathToFileURL } from 'node:url';
const here = path.dirname(fileURLToPath(import.meta.url));
let src = fs.readFileSync(path.join(here, '..', 'leviathan_core.js'), 'utf8');
const names = [...new Set([...src.matchAll(/THREE\.(\w+)/g)].map(m => m[1]))];
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'lev-'));
const stub = `
class V3 { constructor(x=0,y=0,z=0){this.x=x;this.y=y;this.z=z;} set(x,y,z){this.x=x;this.y=y;this.z=z;return this;} copy(v){this.x=v.x;this.y=v.y;this.z=v.z;return this;} normalize(){const l=Math.hypot(this.x,this.y,this.z)||1;this.x/=l;this.y/=l;this.z/=l;return this;} }
class Eul { constructor(){this.x=0;this.y=0;this.z=0;this.order='XYZ';} set(x,y,z){this.x=x;this.y=y;this.z=z;return this;} }
class Quat { constructor(){this.x=0;this.y=0;this.z=0;this.w=1;} copy(q){this.x=q.x;this.y=q.y;this.z=q.z;this.w=q.w;return this;} }
class Col { constructor(r,g,b){ if (g===undefined) {this.r=this.g=this.b=1;} else {this.r=r;this.g=g;this.b=b;} } setRGB(r,g,b){this.r=r;this.g=g;this.b=b;return this;} }
class Obj { constructor(){this.position=new V3();this.rotation=new Eul();this.quaternion=new Quat();this.scale=new V3(1,1,1);this.children=[];this.visible=true;this.userData={};this.name='';}
  add(...c){for(const x of c){this.children.push(x);x.parent=this;}return this;} remove(...c){for(const x of c){const i=this.children.indexOf(x);if(i>=0)this.children.splice(i,1);}return this;}
  translateX(){} translateY(){} traverse(f){f(this);for(const c of this.children)c.traverse(f);} }
class Attr { constructor(a,n){this.array=a;this.itemSize=n;this.needsUpdate=false;} }
class Geo { constructor(){this.attributes={};this.index=null;} setAttribute(k,a){this.attributes[k]=a;return this;} setIndex(a){this.index=a;return this;} computeBoundingSphere(){} }
class Mat { constructor(o){ Object.assign(this,o||{}); this.userData=this.userData||{}; } }
class Light extends Obj { constructor(c,i,d,dec){super();this.color=c;this.intensity=i;this.distance=d;this.decay=dec;this.target=new Obj();} }
class Mesh extends Obj { constructor(g,m){super();this.geometry=g;this.material=m;} }
export const BufferGeometry=Geo, BufferAttribute=Attr, Vector3=V3, Euler=Eul, Color=Col, Scene=class extends Obj{}, Group=class extends Obj{}, Mesh_=Mesh;
export { Mesh };
export const Points=class extends Mesh{}, Fog=class{constructor(c,n,f){this.color=c;this.near=n;this.far=f;}};
export const MeshStandardMaterial=Mat, MeshBasicMaterial=Mat, PointsMaterial=Mat, ShaderMaterial=Mat;
export const PointLight=Light, HemisphereLight=Light, DirectionalLight=Light;
export const PlaneGeometry=class extends Geo{}, SphereGeometry=class extends Geo{}, BoxGeometry=class extends Geo{};
export const CanvasTexture=class{}; 
export const BackSide=1, DoubleSide=2, AdditiveBlending=3, RepeatWrapping=4, SRGBColorSpace='srgb';
`;
fs.writeFileSync(path.join(tmp, 'three_stub.mjs'), stub);
for (const n of names) assert(new RegExp('\\b' + n + '\\b').test(stub), 'stub is missing THREE.' + n);
fs.writeFileSync(path.join(tmp, 'ocean_surface.js'), 'export function registerShaderFallback(){}\n');
src = src.replace("import * as THREE from 'three';", "import * as THREE from './three_stub.mjs';");
fs.writeFileSync(path.join(tmp, 'leviathan_core.mjs'), src);
fs.copyFileSync(path.join(tmp, 'ocean_surface.js'), path.join(tmp, 'ocean_surface.mjs'));
fs.copyFileSync(path.join(here, '..', 'leviathan_sky.js'), path.join(tmp, 'leviathan_sky.mjs'));
fs.writeFileSync(path.join(tmp, 'leviathan_core.mjs'), src.replace("'./ocean_surface.js'", "'./ocean_surface.mjs'").replace("'./leviathan_sky.js'", "'./leviathan_sky.mjs'"));
const { createLeviathan, LAYOUT } = await import(pathToFileURL(path.join(tmp, 'leviathan_core.mjs')).href);
const L = LAYOUT; let ok = 0; const pass = (m) => { ok++; console.log('  ok  ' + m); };

// ---- build ----
const events = []; const lev = createLeviathan({ onEvent: (n) => events.push(n), getAudioContext: () => null, getVolume: () => 1 });
lev.build(); assert(lev.built); pass('interior builds');
let meshes = 0, tris = 0;
lev.scene.traverse(o => { if (o.geometry && o.geometry.attributes && o.geometry.attributes.position) { meshes++; const g = o.geometry, n = g.attributes.position.array.length / 3;
    if (g.index) { tris += g.index.array.length / 3; for (const i of g.index.array) if (i >= n) assert.fail('index out of range in ' + o.name); }
    for (const k of ['position', 'normal', 'color']) if (g.attributes[k]) for (const v of g.attributes[k].array) if (!Number.isFinite(v)) assert.fail('NaN in ' + k + ' of ' + o.name);
    const nr = g.attributes.normal ? g.attributes.normal.array : []; for (let i = 0; i < nr.length; i += 3) { const l = Math.hypot(nr[i], nr[i + 1], nr[i + 2]); if (Math.abs(l - 1) > 1e-3) assert.fail('non-unit normal in ' + o.name); } } });
console.log('      merged meshes:', meshes, ' triangles:', tris); assert(meshes > 5 && meshes < 40 && tris > 2000); pass('geometry integrity (indices, normals, no NaN); draw calls stay low');
const lights = []; lev.scene.traverse(o => { if (o.intensity !== undefined && o.decay !== undefined) lights.push(o); }); console.log('      lights:', lights.length); assert(lights.length <= 9); pass('light count is bounded');

// ---- collision / walkability ----
const walkable = (x, z) => { const r = lev.resolve(x, z); return Math.abs(r[0] - x) < 1e-6 && Math.abs(r[1] - z) < 1e-6; };
assert(walkable(L.exit.x, L.exit.z), 'the hatch exit is not walkable'); pass('hatch exit is walkable');
for (let i = 0; i < 4000; i++) { const x = -520 + Math.random() * 700, z = -420 + Math.random() * 600, r = lev.resolve(x, z); assert(walkable(r[0], r[1]) || true); for (const o of lev.obst) { assert(!(r[0] > o[0] - 1.39 && r[0] < o[1] + 1.39 && r[1] > o[2] - 1.39 && r[1] < o[3] + 1.39) || Math.hypot(r[0]-x,r[1]-z) > 0, 'resolved point inside an obstacle'); } }
pass('resolve never leaves a point inside an obstacle');
for (const [x, z] of [[0, 200], [200, 0], [-300, -300], [-300, 0], [0, -400], [-480, -140], [-310, -100], [-310, -180]]) { const r = lev.resolve(x, z); assert(lev.walk.some(w => r[0] >= w.x0 - 1e-6 && r[0] <= w.x1 + 1e-6 && r[1] >= w.z0 - 1e-6 && r[1] <= w.z1 + 1e-6), 'escaped the walkable area from ' + x + ',' + z); }
pass('points outside the walls are pulled back inside');
// BFS on a 2-unit grid from the exit to the door
const G = 2, key = (x, z) => x + ',' + z, q = [[L.exit.x, L.exit.z]], seen = new Set([key(L.exit.x, L.exit.z)]); let reachedDoor = false, reachedBreach = false, reachedEast = false, reachedNorthW = false;
while (q.length) { const [x, z] = q.shift(); if (x < L.doorX + 40 && z > L.cor.z0 + 10 && z < L.cor.z1 - 10) reachedDoor = true; if (z > L.bay.z1 - 10) reachedBreach = true; if (x > 120) reachedEast = true; if (x < -100 && z < -330) reachedNorthW = true;
    for (const [dx, dz] of [[G, 0], [-G, 0], [0, G], [0, -G]]) { const nx = x + dx, nz = z + dz, k = key(nx, nz); if (seen.has(k)) continue; if (!walkable(nx, nz)) continue; seen.add(k); q.push([nx, nz]); } }
assert(reachedDoor, 'the blast door is not reachable from the hatch'); assert(reachedBreach && reachedEast && reachedNorthW, 'parts of the bay are cut off'); console.log('      reachable cells:', seen.size);
pass('blast door, breach end, windows side and north-west corner are all reachable from the hatch');
// the ship and the doorway
assert(!walkable(0, -320) && !walkable(-10, -300), 'can walk through the ship'); assert(walkable(-155, -140), 'doorway blocked'); assert(!walkable(-155, -100) && !walkable(-155, -180), 'can walk through the doorway jambs'); pass('ship is solid, doorway is open, jambs are solid');

// ---- the landing ----
const cam = { position: new (lev.scene.constructor === Object ? Object : (class { constructor(){ this.x=0;this.y=0;this.z=0; } set(x,y,z){this.x=x;this.y=y;this.z=z;return this;} copy(v){this.x=v.x;this.y=v.y;this.z=v.z;return this;} }))(), rotation: { order: 'XYZ', x: 0, y: 0, z: 0, set(x, y, z) { this.x = x; this.y = y; this.z = z; } }, quaternion: { x: 0, y: 0, z: 0, w: 1, copy() { return this; } } };
const player = { position: { x: 0, y: 0, z: 0, set(x, y, z) { this.x = x; this.y = y; this.z = z; } }, cameraY: 0, yaw: 0, pitch: 0 };
lev.startLanding(); assert(lev.landing.active && lev.landing.phase === 'approach'); const zs = []; let t = 0, kicked = false, haltedAt = 0;
while (t < 40) { const ctl = lev.update(1 / 60, cam, player); t += 1 / 60; assert(ctl || !lev.landing.active, 'landing must own the camera while active');
    for (const v of [cam.position.x, cam.position.y, cam.position.z, cam.rotation.x, cam.rotation.y, cam.rotation.z]) assert(Number.isFinite(v), 'NaN camera at t=' + t.toFixed(2) + ' phase ' + lev.landing.phase);
    zs.push(cam.position.z); if (lev.landing.phase === 'seated' && !haltedAt) haltedAt = t;
    if (lev.landing.phase === 'seated' && !kicked && t > haltedAt + 2) { assert(lev.landing.canKick && lev.interaction(0, 0).id === 'kick'); assert(lev.startKick()); assert(!lev.startKick(), 'second kick must be ignored'); kicked = true; }
    if (!lev.landing.active && kicked) break; }
assert(kicked && !lev.landing.active, 'landing never finished'); assert(events.includes('halt') && events.includes('free')); pass('landing runs approach -> skid -> halt -> kick -> free, with both events');
console.log('      approach starts z=' + zs[0].toFixed(0) + ', breach at z=' + L.bay.z1 + ', halts at ~' + zs[Math.round((1.6 + lev.LAND.T_SKID) * 60)].toFixed(1) + ' (stop z=' + L.stop.z + ')');
let mono = true; for (let i = 1; i < Math.round((1.6 + lev.LAND.T_SKID) * 60); i++) if (zs[i] > zs[i - 1] + 0.5) mono = false; assert(mono, 'the ship moved backwards during the skid'); pass('the skid only ever moves forward');
assert(Math.abs(zs[Math.round((1.6 + lev.LAND.T_SKID) * 60)] - L.stop.z) < 1.5, 'skid does not end at the stop point'); pass('skid ends on the stop point');
assert(Math.hypot(player.position.x - L.exit.x, player.position.z - L.exit.z) < 0.5 && Math.abs(player.yaw - Math.PI) < 1e-6, 'player not at the exit facing the bay'); pass('player is handed over at the hatch exit, facing the bay');
assert(walkable(player.position.x, player.position.z)); pass('hand-over position is walkable');
const sk = lev.skidState(1); assert(Math.abs(sk.d - lev.LAND.dist) < 1e-6 && Math.abs(sk.v) < 1e-9); pass('skid closed form ends at the full distance with zero speed');

// ---- zones ----
events.length = 0; for (let i = 0; i < 3; i++) lev.update(1 / 60, cam, { position: { x: 90, y: 8.5, z: -50 } }); assert(events.includes('zone:windows'));
lev.update(1 / 60, cam, { position: { x: -100, y: 8.5, z: -30 } }); assert(events.includes('zone:tech'));
lev.update(1 / 60, cam, { position: { x: -180, y: 8.5, z: -140 } }); assert(events.includes('zone:corridor'));
lev.update(1 / 60, cam, { position: { x: -400, y: 8.5, z: -140 } }); assert(events.includes('zone:door'));
assert(!lev.interaction(-450, -140) && !lev.interaction(0, 0)); pass('zones fire once; the core no longer owns the door interaction (leviathan_hack.js does, see test_v112_hack.mjs)');
console.log('\n' + ok + ' checks passed'); fs.rmSync(tmp, { recursive: true, force: true });
