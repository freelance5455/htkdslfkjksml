import sys, os, subprocess, time
from playwright.sync_api import sync_playwright
srv = subprocess.Popen([sys.executable, '-m', 'http.server', '8766', '--directory', os.path.join(os.path.dirname(__file__), '..')], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL); time.sleep(1)
try:
    with sync_playwright() as p:
        b = p.chromium.launch(args=['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--no-sandbox', '--autoplay-policy=no-user-gesture-required'])
        pg = b.new_page(viewport={'width': 640, 'height': 300}); logs = []
        pg.on('console', lambda m: logs.append(m.type + ': ' + m.text)); pg.on('pageerror', lambda e: logs.append('PAGEERR ' + str(e)))
        pg.goto('http://localhost:8766/tests/ff_cine_play.html')
        for i in range(120):
            pg.wait_for_timeout(1000)
            r = pg.evaluate('window.__result')
            if i in (3, 10, 20, 30): print(i, 'active=', pg.evaluate('window.cine.active'), 'cover=', pg.evaluate("!!document.getElementById('ffCine')"))
            if r != 'running': break
        print('RESULT', r, '| whileBlack:', pg.evaluate('window.__log'), '| root removed:', pg.evaluate("!document.getElementById('ffCine')"), '| __ffCineActive:', pg.evaluate('window.__ffCineActive'))
        print('LOGS', logs[:8]); b.close()
finally: srv.terminate()
