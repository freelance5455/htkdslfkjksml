# Renders moments of the freefall cinematic to PNGs (headless Chromium + SwiftShader).
# usage: python3 ff_cine_shots.py OUTDIR t1 t2 t3 ...      (t = seconds on the cinematic timeline; the game dir must be served)
import sys, os, subprocess, time
from playwright.sync_api import sync_playwright
out = sys.argv[1]; times = [float(x) for x in sys.argv[2:]]
os.makedirs(out, exist_ok=True)
srv = subprocess.Popen([sys.executable, '-m', 'http.server', '8765', '--directory', os.path.join(os.path.dirname(__file__), '..')], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(1)
try:
    with sync_playwright() as p:
        b = p.chromium.launch(args=['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--no-sandbox'])
        pg = b.new_page(viewport={'width': int(os.environ.get('FF_W', 1280)), 'height': int(os.environ.get('FF_H', 600))})
        logs = []; pg.on('console', lambda m: logs.append(m.text)); pg.on('pageerror', lambda e: logs.append('PAGEERR ' + str(e)))
        pg.goto('http://localhost:8765/tests/ff_cine_harness.html'); pg.wait_for_timeout(1500)
        err = pg.evaluate('window.__err || null')
        if err: print('MOUNT ERROR:', err); print(logs); sys.exit(1)
        import json, os as _o
        pre = _o.environ.get('FF_PRE')
        if pre: pg.evaluate(pre)
        for t in times:
            s = time.time(); pg.evaluate(f'window.cine.debug.renderAt({t})'); pg.wait_for_timeout(300)
            f = os.path.join(out, f't_{t:06.2f}.png'); pg.screenshot(path=f); print('ok', f, round(time.time() - s, 1), 's')
        if logs: print('LOGS', logs[:5])
        b.close()
finally:
    srv.terminate()
