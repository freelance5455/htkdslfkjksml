import { TerrainCore } from '../terrain_core.js';
import * as V from '../valley_sites.js';
import { PLANET_R } from '../planet_core.js';
const seeds = process.argv.length > 2 ? process.argv.slice(2).map(Number) : [424242, 1, 99];
let fail = 0; const ck = (m, ok) => { if (!ok) { fail++; console.log('  FAIL', m); } };
for (const seed of seeds) {
  const T = new TerrainCore(seed), t0 = Date.now(), r = V.findSites(T, seed), ms = Date.now() - t0;
  const cit = r.sites.filter(s => s.citadel); ck(`seed ${seed}: exactly one citadel (${cit.length})`, cit.length === 1);
  const S = cit[0]; if (!S) continue;
  const C = S.cit, o = {}, d = [0, 0, 0];
  const nat = (a, n) => { V.localToDir(S, a, n, d); return T.sample3(d[0] * PLANET_R, d[1] * PLANET_R, d[2] * PLANET_R, o); };
  console.log(`seed ${seed}: ${r.sites.length} sites (${ms} ms) citadel id ${S.id} floorH ${S.floorH} th ${(C.th * 57.3).toFixed(0)}deg sIn ${C.sIn.toFixed(0)} sOut ${C.sOut.toFixed(0)} sEnd ${C.sEnd.toFixed(0)} Rv ${C.Rv.toFixed(0)} Rc ${C.Rc.toFixed(0)} rim ${C.rim.toFixed(0)} yT ${C.yT.toFixed(0)} len ${(C.sOut-C.sIn).toFixed(0)} road ${(C.sEnd-C.sOut).toFixed(0)} links ${S.links.length}`);
  // axis profile: ground height vs s, vs tunnel floor + roof
  let bad = 0, minCover = 1e9, line = [];
  for (let s = C.sIn + 12; s < C.sOut - 12; s += 10) { const a = C.ca * s, n = C.sa * s, h = V.valleyHeight(S, a, n, nat(a, n)); const yb = V.citProfile(C, s); minCover = Math.min(minCover, h - (yb + 54)); if (h < yb + 54 + 10) bad++; }
  ck(`seed ${seed}: rock cover over the bore (min ${minCover.toFixed(0)})`, bad === 0);
  { let worst = -1e9; for (let s = C.sIn - 250; s < C.sIn; s += 10) { const a = C.ca * s, n = C.sa * s; worst = Math.max(worst, V.valleyHeight(S, a, n, nat(a, n)) - C.yT); } ck(`seed ${seed}: promenade cutting open (max ${worst.toFixed(1)} above deck)`, worst < 0.5); }
  for (const s of [0, 800, 1600, 2300, 2800, C.sIn, (C.sIn + C.sOut) / 2, C.sOut, C.sOut + 200, C.sOut + 800, C.sEnd, C.sEnd + 400]) { const a = C.ca * s, n = C.sa * s; line.push(`${s.toFixed(0)}:${(V.valleyHeight(S, a, n, nat(a, n)) - S.floorH).toFixed(0)}`); }
  console.log('  axis (s:height above floor)', line.join(' '));
  // rim height + floor stats around
  let hs = [], fl = []; for (let k = 0; k < 72; k++) { const a = k * Math.PI / 36; let mx = 0; for (let r2 = 2500; r2 < 6000; r2 += 100) mx = Math.max(mx, V.valleyHeight(S, Math.cos(a) * r2, Math.sin(a) * r2, nat(Math.cos(a) * r2, Math.sin(a) * r2)) - S.floorH); hs.push(mx); }
  for (let r2 = 0; r2 < 2000; r2 += 100) for (let k = 0; k < 12; k++) { const a = k * Math.PI / 6; fl.push(V.valleyHeight(S, Math.cos(a) * r2, Math.sin(a) * r2, nat(Math.cos(a) * r2, Math.sin(a) * r2)) - S.floorH); }
  console.log(`  rim crest min ${Math.min(...hs).toFixed(0)} max ${Math.max(...hs).toFixed(0)}; core floor (r<2000) ${Math.min(...fl).toFixed(0)}..${Math.max(...fl).toFixed(0)}`);
  // max slope of the ground along the axis between the centre and sEnd + 600 and along 8 other radial lines
  let ms2 = 0; for (let s = 0; s < C.sEnd + 600; s += 12) if ((s < C.sIn - 12 || s > C.sOut + 30) && s < C.sEnd + 40)   /* v64: the natural mountain above the bore is not a walking surface */ { const a = C.ca * s, n = C.sa * s, a2 = C.ca * (s + 12), n2 = C.sa * (s + 12); ms2 = Math.max(ms2, Math.abs(V.valleyHeight(S, a2, n2, nat(a2, n2)) - V.valleyHeight(S, a, n, nat(a, n))) / 12); }
  console.log(`  max slope along the tunnel axis line ${ms2.toFixed(2)}`);
  ck(`seed ${seed}: axis slope walkable`, ms2 < 1.2);
}
console.log(fail ? 'FAIL ' + fail : 'ALL OK'); process.exit(fail ? 1 : 0);
