// Dumps an equirectangular height map (macro terrain, detail 0) as raw float32 for map_png.py.
// usage: node map_dump.mjs [seed] [W] [out.bin] [mode: macro|full]
import { TerrainCore } from '../terrain_core.js';
import { PLANET_R } from '../planet_core.js';
import fs from 'fs';
const seed = +process.argv[2] || 424242, W = +process.argv[3] || 720, out = process.argv[4] || '/tmp/map.bin', H = W / 2;
const T = new TerrainCore(seed), a = new Float32Array(W * H * 3);
const o = {};
for (let j = 0; j < H; j++) {
    const lat = (0.5 - (j + 0.5) / H) * Math.PI, cl = Math.cos(lat), sl = Math.sin(lat);
    for (let i = 0; i < W; i++) {
        const lon = ((i + 0.5) / W - 0.5) * 2 * Math.PI;
        const X = cl * Math.sin(lon) * PLANET_R, Y = sl * PLANET_R, Z = cl * Math.cos(lon) * PLANET_R;
        const h = T._terrain(X, Y, Z, 1, o);
        const k = (j * W + i) * 3; a[k] = h; a[k + 1] = o.cv; a[k + 2] = (o.arcAmt || 0) + 2 * (o.trenchAmt || 0);
    }
}
fs.writeFileSync(out, Buffer.from(a.buffer));
console.log('wrote', out, W, H);
