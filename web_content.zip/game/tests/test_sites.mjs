import { TerrainCore } from '../terrain_core.js';
import { findSites, SITE_GRID } from '../valley_sites.js';
import { PLANET_R, geoToChart, faceOfGeo } from '../planet_core.js';
const seeds = [1, 12345, 987654321, 424242, 31337, 2718281828, 99, 777777];
for (const seed of seeds) {
  const T = new TerrainCore(seed);
  const r = findSites(T, seed);
  const r2 = findSites(new TerrainCore(seed), seed);   // determinism: fresh generator, identical list
  const same = JSON.stringify(r.sites.map(s=>[s.dir,s.floorH,s.Rf,s.passAng])) === JSON.stringify(r2.sites.map(s=>[s.dir,s.floorH,s.Rf,s.passAng]));
  const cells = new Set(r.sites.map(s=>s.cell));
  const faces = new Set(r.sites.map(s=>s.cell.split(':')[0]));
  // nearest-neighbour distances
  const nn = r.sites.map(a => Math.min(...r.sites.filter(b=>b!==a).map(b => Math.hypot(a.dir[0]-b.dir[0],a.dir[1]-b.dir[1],a.dir[2]-b.dir[2])*PLANET_R)));
  console.log(`seed ${seed}: ${r.sites.length} sites, ${r.stats.ms.toFixed(0)} ms, stage1 ${r.stats.stage1}/${r.stats.cells} cells, finished ${r.stats.finished}, relaxed ${r.stats.relaxed}, deterministic=${same}, unique cells=${cells.size}, faces=[${[...faces]}], floorH ${Math.round(Math.min(...r.sites.map(s=>s.floorH)))}..${Math.round(Math.max(...r.sites.map(s=>s.floorH)))}, NN km ${(Math.min(...nn)/4250).toFixed(0)}..${(Math.max(...nn)/4250).toFixed(0)}`);
}
