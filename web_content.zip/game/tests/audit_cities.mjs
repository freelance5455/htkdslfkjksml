// v56 audit of ordinary cities: the kinds of faults a player would actually see or trip over.
import { TerrainCore } from '../terrain_core.js';
import * as V from '../valley_sites.js';
import { generateCity, planToCols, planToLife, makeNatGrid } from '../city_core.js';
import { CityCollider } from '../city_collide.js';
import { PLANET_R } from '../planet_core.js';
const seed = +(process.argv[2] || 424242), T = new TerrainCore(seed), o = {}, d = [0, 0, 0], sites = V.findSites(T, seed).sites.filter(s => !s.citadel);
const nS = +(process.argv[3] || 8), tot = {};
const add = (k, v) => { tot[k] = (tot[k] || 0) + v; };
for (const S of sites.slice(0, nS)) {
  const nat3 = (x, z) => { V.localToDir(S, x, -z, d); return T.sample3(d[0] * PLANET_R, d[1] * PLANET_R, d[2] * PLANET_R, o); };
  const nat = makeNatGrid(S, nat3, 20), ground = (x, z) => V.valleyHeight(S, x, -z, nat(x, z));
  const city = generateCity(S, nat), col = new CityCollider(planToCols(city));
  const B = city.buildings, rep = { id: S.id, arche: city.arche, B: B.length };
  // 1 building-vs-building footprint overlap (tier 0 boxes, SAT)
  const corners = (b) => { const t = b.tiers ? b.tiers[0] : { cx: b.x, cz: b.z, w: b.w, d: b.d }, c = Math.cos(b.yaw), s = Math.sin(b.yaw), hw = t.w / 2, hd = t.d / 2; return [[-hw, -hd], [hw, -hd], [hw, hd], [-hw, hd]].map(([u, v]) => [t.cx + u * c - v * s, t.cz + u * s + v * c]); };
  const sat = (A, Bc) => { for (const P of [A, Bc]) for (let i = 0; i < 4; i++) { const ax = P[(i + 1) % 4][1] - P[i][1], az = -(P[(i + 1) % 4][0] - P[i][0]); let a0 = 1e9, a1 = -1e9, b0 = 1e9, b1 = -1e9; for (const p of A) { const v = p[0] * ax + p[1] * az; a0 = Math.min(a0, v); a1 = Math.max(a1, v); } for (const p of Bc) { const v = p[0] * ax + p[1] * az; b0 = Math.min(b0, v); b1 = Math.max(b1, v); } if (a1 <= b0 + 1e-6 || b1 <= a0 + 1e-6) return false; } return true; };
  const grid = new Map(), K = (i, j) => i * 9973 + j; B.forEach((b, i) => { const r = Math.hypot(b.w, b.d) / 2; for (let a = Math.floor((b.x - r) / 80); a <= Math.floor((b.x + r) / 80); a++) for (let c = Math.floor((b.z - r) / 80); c <= Math.floor((b.z + r) / 80); c++) { const k = K(a, c); (grid.get(k) || grid.set(k, []).get(k)).push(i); } });
  let ov = 0; const seen = new Set(); for (const l of grid.values()) for (let a = 0; a < l.length; a++) for (let c = a + 1; c < l.length; c++) { const i = l[a], j = l[c], key = i * 100000 + j; if (seen.has(key)) continue; seen.add(key); const A = B[i], Bb = B[j]; if (A.top <= Bb.y0 + 1 || Bb.top <= A.y0 + 1) continue; if (sat(corners(A), corners(Bb))) ov++; }
  rep.overlap = ov; add('overlap', ov);
  // 2 floating / buried foundations
  let flt = 0, bur = 0; for (const b of B) { const cs = corners(b); let gmin = 1e9, gmax = -1e9; for (const p of cs) { const g = ground(p[0], p[1]); gmin = Math.min(gmin, g); gmax = Math.max(gmax, g); } if (b.y0 - gmin > 3.5) flt++; if (gmax - b.y0 > 5) bur++; }
  rep.floating = flt; rep.buried = bur; add('floating', flt); add('buried', bur);
  // 3 edges through solids (walkers / drones would clip)
  let thru = 0, ed = 0; for (const e of city.edges) { const a = city.nodes[e.a], b = city.nodes[e.b], n = Math.max(1, Math.ceil(Math.hypot(b.x - a.x, b.z - a.z) / 4)); ed++; for (let q = 0; q <= n; q++) { const t = q / n, y = a.y + (b.y - a.y) * t; if (col.solidAt(a.x + (b.x - a.x) * t, a.z + (b.z - a.z) * t, y + 1, y + 7)) { thru++; break; } } }
  rep.edgesThroughSolids = thru + '/' + ed; add('edgesThru', thru); add('edges', ed);
  // 4 nodes with no floor
  let nf = 0; for (const nd of city.nodes) { const f = col.floorAt(nd.x, nd.z, nd.y + 40, 0); if (!(Math.abs(f - nd.y) < 6)) nf++; } rep.noFloor = nf + '/' + city.nodes.length; add('noFloor', nf); add('nodes', city.nodes.length);
  // 5 components
  const N = city.nodes.length, comp = new Int32Array(N).fill(-1); let nc = 0, small = 0; for (let i = 0; i < N; i++) if (comp[i] < 0) { const q = [i]; comp[i] = nc; let c = 0; while (q.length) { const a = q.pop(); c++; for (const b of city.nodes[a].adj) if (comp[b] < 0) { comp[b] = nc; q.push(b); } } if (c < 20) small += c; nc++; }
  rep.components = nc; rep.isolatedNodes = small; add('components', nc - 1); add('isolated', small);
  // 6 doors: POI doors with no walkable floor within 4 / inside a solid
  let dbad = 0, dn = 0; for (const h of city.poi.homes.concat(city.poi.shops, city.poi.works)) { if (!h.door) continue; dn++; const f = col.floorAt(h.door[0], h.door[1], (h.y || 0) + 30, 0); if (col.solidAt(h.door[0], h.door[1], (h.y || 0) + 1, (h.y || 0) + 7) || !isFinite(f)) dbad++; } rep.doorsBlocked = dbad + '/' + dn; add('doorsBad', dbad); add('doors', dn);
  console.log(JSON.stringify(rep));
}
console.log('TOTAL', JSON.stringify(tot));
