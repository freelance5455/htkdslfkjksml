// =====================================================================================
// city_sim.js - drone movement / routine / chatter simulation for ONE city (pure logic; tested headless).
// Works in the city's chart-independent PLAN space (x east, z south, y world height). The runtime (city_runtime.js) only renders it.
// Only active while the player is near (the runtime creates a CitySim on approach and drops it when the player leaves) and capped.
// =====================================================================================
import { mulberry } from '../valley_sites.js';
import { slotOf, slotGoal, ambientLine, chatterPair, greeting, JOBS } from '../city_life.js';

export class Nav {
    constructor(life) {
        this.life = life; const N = life.nodes.length / 4; this.N = N; this.adj = Array.from({ length: N }, () => []);
        for (let i = 0; i < life.edges.length; i += 2) { const a = life.edges[i], b = life.edges[i + 1]; this.adj[a].push(b); this.adj[b].push(a); }
        this.cache = new Map();
    }
    x(i) { return this.life.nodes[i * 4]; } y(i) { return this.life.nodes[i * 4 + 1]; } z(i) { return this.life.nodes[i * 4 + 2]; }
    nearest(x, z) { let b = 0, bd = 1e30; const n = this.life.nodes; for (let i = 0; i < this.N; i++) { const d = (n[i * 4] - x) ** 2 + (n[i * 4 + 2] - z) ** 2; if (d < bd) { bd = d; b = i; } } return b; }
    path(a, b) {
        if (a === b) return [a];
        const key = a * 65536 + b, c = this.cache.get(key); if (c) return c;
        const dist = new Float32Array(this.N).fill(1e30), prev = new Int32Array(this.N).fill(-1), done = new Uint8Array(this.N); dist[a] = 0;
        for (let it = 0; it < this.N; it++) {      // N ~ 400-700: a linear-scan Dijkstra is fine (and cached)
            let u = -1, ud = 1e30; for (let i = 0; i < this.N; i++) if (!done[i] && dist[i] < ud) { ud = dist[i]; u = i; }
            if (u < 0 || u === b) break; done[u] = 1;
            for (const v of this.adj[u]) { const d = ud + Math.hypot(this.x(u) - this.x(v), this.z(u) - this.z(v)) + Math.abs(this.y(u) - this.y(v)) * 2.5; if (d < dist[v]) { dist[v] = d; prev[v] = u; } }
        }
        const out = []; if (prev[b] < 0) { out.push(a); } else { for (let v = b; v >= 0; v = prev[v]) out.push(v); out.reverse(); }
        if (this.cache.size > 3000) this.cache.clear(); this.cache.set(key, out); return out;
    }
}
function placeOnPath(nav, path, f) {   // point at fraction f of a node path
    if (path.length === 1) return { x: nav.x(path[0]), y: nav.y(path[0]), z: nav.z(path[0]), i: 0 };
    let L = 0; const seg = []; for (let i = 0; i + 1 < path.length; i++) { const l = Math.hypot(nav.x(path[i + 1]) - nav.x(path[i]), nav.z(path[i + 1]) - nav.z(path[i])); seg.push(l); L += l; }
    let t = Math.max(0, Math.min(1, f)) * L;
    for (let i = 0; i < seg.length; i++) { if (t <= seg[i] || i === seg.length - 1) { const u = seg[i] ? Math.min(1, t / seg[i]) : 0; return { x: nav.x(path[i]) + (nav.x(path[i + 1]) - nav.x(path[i])) * u, y: nav.y(path[i]) + (nav.y(path[i + 1]) - nav.y(path[i])) * u, z: nav.z(path[i]) + (nav.z(path[i + 1]) - nav.z(path[i])) * u, i }; } t -= seg[i]; }
    return { x: nav.x(path[0]), y: nav.y(path[0]), z: nav.z(path[0]), i: 0 };
}

export class CitySim {
    constructor(life, residents, opts) {
        this.life = life; this.nav = new Nav(life); this.res = residents; this.cityName = opts.cityName; this.maxDrones = opts.maxDrones || 48;
        this.r = mulberry(opts.seed ^ 0x51a1); this.drones = []; this.chatT = 1.5; this.bubbles = 0; this.maxBubbles = opts.maxBubbles || 7;
        this.ctx = { machineDestroyed: false, night: false, cityName: this.cityName };
        // resolve POIs once
        const nav = this.nav, P = life.poi;
        this.homeNode = (res) => res.home >= 0 && P.homes[res.home] ? nav.nearest(P.homes[res.home].door[0], P.homes[res.home].door[1]) : 0;
        const byKind = (k) => P.works.filter(w => w.kind === k);
        this.workNodes = {};
        const nodesOf = (arr) => arr.map(o => nav.nearest(o.door ? o.door[0] : o.x, o.door ? o.door[1] : o.z));
        this.workNodes.dock = nodesOf(P.docks); this.workNodes.workshop = nodesOf(byKind('workshop')); this.workNodes.office = nodesOf(byKind('office')); this.workNodes.tank = nodesOf(byKind('tank')); this.workNodes.shop = nodesOf(P.shops);
        const px0 = P.plazas[0] ? P.plazas[0].x : 0, pz0 = P.plazas[0] ? (P.plazas[0].z || 0) : 0;
        // v47: many gathering spots around the plaza (was 3, so a dozen drones piled onto the same node)
        this.workNodes.plaza = [...new Set([0, nav.nearest(px0 + 20, 0), nav.nearest(-25, 20), nav.nearest(px0 + 14, pz0 + 14), nav.nearest(px0 - 14, pz0 + 14), nav.nearest(px0 + 14, pz0 - 14), nav.nearest(px0 - 14, pz0 - 14), nav.nearest(px0, pz0 + 24), nav.nearest(px0, pz0 - 24), nav.nearest(px0 + 28, pz0), nav.nearest(px0 - 28, pz0)])];
        this.anyWork = [].concat(this.workNodes.shop, this.workNodes.workshop, this.workNodes.office, this.workNodes.dock);
    }
    goalNode(res, goal) {
        if (goal.kind === 'home') return this.homeNode(res);
        if (goal.kind === 'plaza') { const a = this.workNodes.plaza; return a[res.seed % a.length]; }
        if (goal.kind === 'wander') return (res.seed >>> 3) % this.nav.N;
        const job = JOBS.find(j => j.id === res.job); let arr = this.workNodes[job.place]; if (!arr || !arr.length) arr = this.anyWork.length ? this.anyWork : [0];
        return arr[res.workIdx % arr.length];
    }
    // place a drone where its routine says it is "now"
    spawnAt(res, dayTime) {
        const { slot, t } = slotOf(dayTime, res.shiftShift), nav = this.nav, home = this.homeNode(res), work = this.goalNode(res, { kind: 'work' }), plaza = this.goalNode(res, { kind: 'plaza' });
        let path, f = 1, goal = slotGoal(res, slot), gn = this.goalNode(res, goal);
        if (slot === 'commuteWork') { path = nav.path(home, work); f = t; gn = work; }
        else if (slot === 'commuteHome') { const from = this.goalNode(res, slotGoal(res, 'evening')); path = nav.path(from, home); f = t; gn = home; }
        else if (slot === 'lunch') { path = nav.path(work, plaza); f = Math.min(1, t * 3); gn = plaza; }
        else if (slot === 'evening') { path = nav.path(plaza, gn); f = Math.min(1, t * 3); }
        else { path = [gn]; f = 1; }
        const p = placeOnPath(nav, path, f);
        const d = { res, x: p.x, y: p.y, z: p.z, yaw: this.r() * 6.28, slot, goalNode: gn, path: nav.path(nav.nearest(p.x, p.z), gn), pi: 1, state: 'idle', idleT: this.r() * 4, bubble: null, bobPh: this.r() * 6.28, asleep: slot === 'sleep', greetT: 0, talk: false, cargo: false };
        if (d.path.length > 1 && f < 1) d.state = 'walk';
        return d;
    }
    activate(dayTime) { this.drones.length = 0; for (let i = 0; i < Math.min(this.maxDrones, this.res.length); i++) this.drones.push(this.spawnAt(this.res[i], dayTime)); }
    say(d, text, dur = 3.6) { if (d.bubble) return false; if (this.bubbles >= this.maxBubbles) return false; d.bubble = { text, t: dur }; this.bubbles++; return true; }
    step(dt, dayTime, night, machineDestroyed, player) {
        this.ctx.night = night; this.ctx.machineDestroyed = machineDestroyed;
        const nav = this.nav;
        for (const d of this.drones) {
            const s = slotOf(dayTime, d.res.shiftShift);
            if (s.slot !== d.slot) {   // routine changed: head to the new goal
                d.slot = s.slot; d.asleep = false; const g = this.goalNode(d.res, slotGoal(d.res, s.slot));
                if (g !== d.goalNode || d.state === 'idle') { d.goalNode = g; d.path = nav.path(nav.nearest(d.x, d.z), g); d.pi = d.path.length > 1 ? 1 : 0; if (d.path.length > 1) d.state = 'walk'; }
            }
            if (d.bubble) { d.bubble.t -= dt; if (d.bubble.t <= 0) { d.bubble = null; this.bubbles = Math.max(0, this.bubbles - 1); } }
            d.bobPh += dt * 2.2;
            if (d.talk) { d.state = 'idle'; if (player) d.yaw = Math.atan2(player.x - d.x, player.z - d.z) - Math.PI / 2; continue; }
            if (d.state === 'walk') {
                const tgt = d.path[d.pi]; if (tgt === undefined) { d.state = 'idle'; continue; }
                const tx = nav.x(tgt), tz = nav.z(tgt), dx = tx - d.x, dz = tz - d.z, dist = Math.hypot(dx, dz), sp = d.res.speed * (s.slot.startsWith('commute') ? 3.2 : 1.4);   // a game day is ~9 real minutes: commutes must finish inside their window
                if (dist < 1.2) { d.pi++; if (d.pi >= d.path.length) { d.state = 'idle'; d.idleT = 2 + this.r() * 6; d.asleep = d.slot === 'sleep'; } }
                else { const k = Math.min(dist, sp * dt) / dist; d.x += dx * k; d.z += dz * k; d.y += (nav.y(tgt) - d.y) * Math.min(1, dt * 3); d.yaw = Math.atan2(dz, dx) * -1; }
            } else {
                d.idleT -= dt;
                if (d.idleT <= 0 && !d.asleep) {
                    d.idleT = 3 + this.r() * 6;
                    const cur = nav.nearest(d.x, d.z), away = Math.hypot(nav.x(d.goalNode) - d.x, nav.z(d.goalNode) - d.z);
                    if (away > (d.slot === 'sleep' ? 2 : 25)) {   // strayed, or stopped mid-route (e.g. to chat): carry on to the routine goal
                        d.path = nav.path(cur, d.goalNode); d.pi = d.path.length > 1 ? 1 : 0; if (d.path.length > 1) d.state = 'walk';
                    } else if (d.slot !== 'sleep' && this.r() < 0.8) {   // v47: restless in EVERY waking slot: stroll a few nodes around the spot, then drift back
                        let n = cur; const path = [cur], steps = 1 + Math.floor(this.r() * 3);
                        for (let k = 0; k < steps; k++) { const nb = nav.adj[n]; if (!nb.length) break; n = nb[Math.floor(this.r() * nb.length)]; if (path[path.length - 1] !== n) path.push(n); }
                        if (path.length > 1) { d.path = path; d.pi = 1; d.state = 'walk'; }
                    } else d.yaw += (this.r() - 0.5) * 1.6;
                }
            }
            // player nearby: greet (once per ~45 s)
            if (player) { d.greetT -= dt; const pd = Math.hypot(player.x - d.x, player.z - d.z); if (pd < 17 && d.greetT <= 0 && !d.asleep && !d.bubble) { if (this.say(d, greeting(d.res, this.ctx, this.r), 4.2)) { d.greetT = 45; if (d.state === 'idle') d.yaw = Math.atan2(player.x - d.x, player.z - d.z) - Math.PI / 2; } } }
        }
        // v47: soft separation so drones never stand inside each other
        const D = this.drones;
        for (let i = 0; i < D.length; i++) { const a = D[i]; if (a.asleep || a.talk) continue;
            for (let j = i + 1; j < D.length; j++) { const b = D[j]; if (b.asleep || b.talk) continue;
                let dx = b.x - a.x, dz = b.z - a.z; const q = dx * dx + dz * dz; if (q >= 3.24) continue;
                let dist = Math.sqrt(q); if (dist < 0.01) { const an = (i * 2.399 + j) % 6.283; dx = Math.cos(an); dz = Math.sin(an); dist = 0.01; }
                const push = (1.8 - dist) * Math.min(1, dt * 3) * 0.5, ux = dx / Math.max(dist, 0.01), uz = dz / Math.max(dist, 0.01);
                a.x -= ux * push; a.z -= uz * push; b.x += ux * push; b.z += uz * push; } }
        // ambient chatter between drones
        this.chatT -= dt;
        if (this.chatT <= 0) {
            this.chatT = 2 + this.r() * 3;
            const awake = this.drones.filter(d => !d.asleep && !d.bubble && !d.talk && (!player || Math.hypot(player.x - d.x, player.z - d.z) < 90));
            if (awake.length >= 2) {
                const a = awake[Math.floor(this.r() * awake.length)];
                const b = awake.find(o => o !== a && Math.hypot(o.x - a.x, o.z - a.z) < 20);
                if (b && this.r() < 0.7) { const L = chatterPair(a.res, b.res, this.ctx, this.r); this.say(a, L[0], 3); b.pendingLine = { at: 3.0, text: L[1] }; a.pendingLine = { at: 6.0, text: L[2] }; a.pendingBorn = 0; b.pendingBorn = 0; if (a.state === 'walk') { a.state = 'idle'; a.idleT = 7; } }
                else if (this.r() < 0.5) this.say(a, ambientLine(a.res, this.ctx, this.r), 4);
            }
        }
        for (const d of this.drones) if (d.pendingLine) { d.pendingBorn += dt; if (d.pendingBorn >= d.pendingLine.at) { this.say(d, d.pendingLine.text, 3); d.pendingLine = null; } }
    }
    nearestDrone(px, pz, maxD) { let b = null, bd = maxD * maxD; for (const d of this.drones) { if (d.asleep) continue; const q = (d.x - px) ** 2 + (d.z - pz) ** 2; if (q < bd) { bd = q; b = d; } } return b; }
}
