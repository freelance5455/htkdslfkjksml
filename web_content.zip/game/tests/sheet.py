import sys, glob
from PIL import Image
files = sorted(glob.glob(sys.argv[1] + '/t_*.png')); cols = int(sys.argv[2]); out = sys.argv[3]
ims = [Image.open(f).crop((160, 40, 1120, 560)).resize((480, 260)) for f in files]
rows = (len(ims) + cols - 1) // cols
S = Image.new('RGB', (480 * cols, 260 * rows))
for i, im in enumerate(ims): S.paste(im, ((i % cols) * 480, (i // cols) * 260))
S.save(out); print(len(ims), 'frames ->', out)
