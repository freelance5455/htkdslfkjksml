import { TerrainCore } from '../terrain_core.js';
import * as V from '../valley_sites.js';
import { ChunkBuilder, CHUNK_SIZE } from '../chunk_core.js';
import { faceOfGeo, geoToChart } from '../planet_core.js';
const seed = +(process.argv[2] || 424242), T = new TerrainCore(seed), sites = V.findSites(T, seed).sites;
const S = sites.find(s => s.citadel), cb = new ChunkBuilder(seed, sites);
let fail = 0; const ck = (m, ok) => { if (!ok) { fail++; console.log('FAIL', m); } };
const face = faceOfGeo(...S.dir), c = { x: 0, z: 0 }; geoToChart(face, ...S.dir, c);
const gx = Math.round(c.x / CHUNK_SIZE), gz = Math.round(c.z / CHUNK_SIZE);
let t0 = performance.now(); const a = cb.buildTerrain({ key: 'k', face, gx, gz, S: 320, edge: [0, 0, 0, 0] }).out; console.log('terrain', (performance.now() - t0) | 0, 'ms');
let nan = 0; for (const h of a.height) if (!isFinite(h)) nan++; ck('terrain finite', nan === 0);
t0 = performance.now(); const cj = cb.buildCity({ siteId: S.id }); console.log('buildCity', (performance.now() - t0) | 0, 'ms, transfer', cj.tr.length, 'tunnel', !!cj.out.tunnel, 'beam', !!cj.out.beam, 'meta', JSON.stringify(cj.out.life.meta).slice(0, 220));
ck('tunnel in output', !!cj.out.tunnel); ck('multiLevel life', cj.out.life.meta.multiLevel === true);
const nb = Object.values(cj.out.inst.cats || {}).reduce((s, f) => s + f.length / 19, 0); console.log('instances', nb | 0, 'cats', Object.keys(cj.out.inst.cats || {}).length);
// scatter near the city centre must be clear of trees under the core
const sa = cb.buildScatter({ key: 'k', face, gx, gz, S: 320, edge: [0, 0, 0, 0], lod: 0 }).out; let inside = 0, tot = 0; const ps = cb.valleys.placed(face).find(p => p.site === S);
for (const k in sa.cats) { const f = sa.cats[k]; for (let i = 0; i < f.length; i += 16) { const l = V.toLocal(ps, f[i + 12], f[i + 14], { a: 0, n: 0 }); tot++; if (Math.hypot(l.a, l.n) < S.cit.Rclear * 0.75) inside++; } }
console.log('scatter instances', tot, 'inside core', inside); ck('core clear of scatter', inside === 0);
console.log(fail ? 'FAIL' : 'ALL OK'); process.exit(fail ? 1 : 0);
