import { TerrainCore } from '../terrain_core.js';
import * as V from '../valley_sites.js';
import { makeNatGrid, planToInstances, planToLife, planToCols, planToRoad } from '../city_core.js';
import { generateCitadel } from '../citadel_core.js';
import { PLANET_R } from '../planet_core.js';
const seed = +(process.argv[2] || 424242), T = new TerrainCore(seed), o = {}, d = [0, 0, 0];
const sites = V.findSites(T, seed).sites, S = sites.find(s => s.citadel);
const nat3 = (x, z) => { V.localToDir(S, x, -z, d); return T.sample3(d[0] * PLANET_R, d[1] * PLANET_R, d[2] * PLANET_R, o); };
let t0 = Date.now(); const nat = makeNatGrid(S, nat3, 60); const tn = Date.now() - t0;
t0 = Date.now(); const city = generateCitadel(S, nat); const tg = Date.now() - t0;
t0 = Date.now(); const inst = planToInstances(city), life = planToLife(city), cols = planToCols(city), road = planToRoad(city); const tp = Date.now() - t0;
const counts = {}; for (const p of city.pieces) counts[p.cat] = (counts[p.cat] || 0) + 1;
console.log(`natgrid ${tn}ms generate ${tg}ms pack ${tp}ms; pieces ${city.pieces.length} cols ${cols.length / 9} nodes ${city.nodes.length} edges ${city.edges.length} roadV ${road.pos.length / 3}`);
console.log(JSON.stringify(city.stats)); console.log(JSON.stringify(counts));
let bad = 0; for (const p of city.pieces) if (![p.x, p.y, p.z, p.yaw, p.sx, p.sy, p.sz, p.pitch, p.roll].every(Number.isFinite) || !(p.cat in inst.cats)) bad++;
console.log('bad pieces', bad);
// connectivity
const N = city.nodes.length, comp = new Int32Array(N).fill(-1); let nc = 0; const sizes = []; for (let i = 0; i < N; i++) if (comp[i] < 0) { const q = [i]; comp[i] = nc; let c = 0; while (q.length) { const a = q.pop(); c++; for (const b of city.nodes[a].adj) if (comp[b] < 0) { comp[b] = nc; q.push(b); } } sizes.push(c); nc++; }
console.log('components', nc, sizes.slice(0, 6).join(','), 'gateNode comp', comp[city.gateNode], 'hub comp', comp[0]);
console.log('layers', JSON.stringify(city.layers));
globalThis.__city = city; export { city, S, nat, cols };
