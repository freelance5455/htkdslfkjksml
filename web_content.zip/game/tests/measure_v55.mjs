import { TerrainCore } from '../terrain_core.js';
import * as V from '../valley_sites.js';
import { generateCity, makeNatGrid } from '../city_core.js';
import { PLANET_R } from '../planet_core.js';
const seed = 424242, T = new TerrainCore(seed), o = {}, d = [0,0,0];
const sites = V.findSites(T, seed).sites, N = +(process.argv[2] || 4);
for (const S of sites.slice(0, N)) {
  const nat3 = (x, z) => { V.localToDir(S, x, -z, d); return T.sample3(d[0]*PLANET_R, d[1]*PLANET_R, d[2]*PLANET_R, o); };
  const nat = makeNatGrid(S, nat3, 20);
  const city = generateCity(S, nat);
  const ground = (x, z) => V.valleyHeight(S, x, -z, nat(x, z));
  // wall gap: for wall pieces (plainBox, sy>6, sz 5.2) distance from nearest building edge
  const walls = city.pieces.filter(p => p.cat==='plainBox' && Math.abs(p.sz-8.4)<0.01);
  let gaps = [];
  for (const w of walls) { let best = 1e9; for (const b of city.buildings) { const dd = Math.hypot(b.x-w.x,b.z-w.z) - Math.hypot(b.w,b.d)/2; if (dd<best) best=dd; } gaps.push(best); }
  gaps.sort((a,b)=>a-b);
  const med = gaps.length?gaps[gaps.length>>1]:0, mx = gaps.length?gaps[gaps.length-1]:0;
  // floating: pieces whose bottom is above local ground by > 1.5 with no supporting piece beneath (approx: lamps, huts)
  let float = 0, tot = 0;
  for (const p of city.pieces) { if (!(p.cat==='plainCyl'||p.cat==='plainBox'||p.cat==='wallBox'||p.cat==='baseBox')) continue; if (p.pitch||p.roll) continue; const g = ground(p.x,p.z); if (p.y - g > 3 && p.y - g < 60) { /* candidate */ const sup = city.pieces.some(q => q!==p && q.cat==='baseBox' && Math.abs(q.x-p.x)<q.sx/2+1 && Math.abs(q.z-p.z)<q.sz/2+1 && q.y<=p.y+0.5 && q.y+q.sy>=p.y-0.5); } tot++; }
  const bw = city.buildings.map(b=>b.w*b.d), meanW = city.buildings.reduce((s,b)=>s+Math.sqrt(b.w*b.d),0)/city.buildings.length, meanFl = city.buildings.reduce((s,b)=>s+b.floors,0)/city.buildings.length;
  let rmax=0; for (const b of city.buildings) rmax=Math.max(rmax,Math.hypot(b.x,b.z));
  const Rf = S.Rf;
  console.log(`site ${S.id} ${city.arche} B${city.buildings.length} Rf${Rf} rBldgMax${rmax.toFixed(0)} wallPieces${walls.length} wallGap med${med.toFixed(0)} max${mx.toFixed(0)} meanFootprint${meanW.toFixed(1)} meanFloors${meanFl.toFixed(1)} fh${city.buildings[0].fh.toFixed(1)} domes${city.stats.domes} conn${city.stats.connectors} greens${city.stats.greens} styles ${city.edgeStyles.join(',')} pieces${city.pieces.length}`);
  // distance from each wall piece to nearest building OR dome edge
  const dm=city.pieces.filter(p=>p.cat==='glassDome'); let g2=[]; for(const w of walls){let best=1e9; for(const b of city.buildings){const dd=Math.hypot(b.x-w.x,b.z-w.z)-Math.hypot(b.w,b.d)/2; if(dd<best)best=dd;} for(const q of dm){const dd=Math.hypot(q.x-w.x,q.z-w.z)-q.sx*0.7; if(dd<best)best=dd;} g2.push(best);} g2.sort((a,b)=>a-b); console.log('   wall gap incl domes: med',g2.length?g2[g2.length>>1].toFixed(0):'-','p90',g2.length?g2[Math.floor(g2.length*0.9)].toFixed(0):'-');
}
