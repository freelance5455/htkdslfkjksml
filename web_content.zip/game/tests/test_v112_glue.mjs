// v112 glue test: runs the REAL Leviathan block of game.js (levSay ... levBeyond) against the real leviathan_core.js + leviathan_hack.js
// (stub three.js) with mocked browser globals, and plays the whole corridor sequence: AI talks while you walk -> console found and marked ->
// camera turns -> Hack -> unreadable -> Break -> alarms down, lights green, door marked -> Open -> walk through -> end card.
// Also checks the kick-button fix.      node tests/test_v112_glue.mjs
import fs from 'node:fs'; import os from 'node:os'; import path from 'node:path'; import assert from 'node:assert/strict'; import { fileURLToPath, pathToFileURL } from 'node:url';
const here = path.dirname(fileURLToPath(import.meta.url)); const read = (f) => fs.readFileSync(path.join(here, '..', f), 'utf8');
const stub = fs.readFileSync(path.join(here, 'test_v111_leviathan.mjs'), 'utf8').match(/const stub = `([\s\S]*?)`;/)[1];
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'glue-')); fs.writeFileSync(path.join(tmp, 'three_stub.mjs'), stub); fs.writeFileSync(path.join(tmp, 'ocean_surface.mjs'), 'export function registerShaderFallback(){}\n');
fs.writeFileSync(path.join(tmp, 'leviathan_core.mjs'), read('leviathan_core.js').replace("import * as THREE from 'three';", "import * as THREE from './three_stub.mjs';").replace("'./ocean_surface.js'", "'./ocean_surface.mjs'").replace("'./leviathan_sky.js'", "'./leviathan_sky.mjs'"));
fs.writeFileSync(path.join(tmp, 'leviathan_hack.mjs'), read('leviathan_hack.js').replace("import * as THREE from 'three';", "import * as THREE from './three_stub.mjs';").replace("'./leviathan_core.js'", "'./leviathan_core.mjs'"));
fs.copyFileSync(path.join(here, '..', 'leviathan_sky.js'), path.join(tmp, 'leviathan_sky.mjs'));
const { createLeviathan, LAYOUT: L } = await import(pathToFileURL(path.join(tmp, 'leviathan_core.mjs')).href); const { createHack, HACK } = await import(pathToFileURL(path.join(tmp, 'leviathan_hack.mjs')).href);
const game = read('game.js'), a = game.indexOf('        const LEV_HIDE_IDS'), b = game.indexOf('        // ===========================================================================================\n        // v68 THE VALE'); assert(a > 0 && b > a);
const slice = game.slice(a, b);
let ok = 0; const pass = (m) => { ok++; console.log('  ok  ' + m); };
const wait = async (pred, what, ms = 8000) => { const t0 = Date.now(); while (!pred()) { if (Date.now() - t0 > ms) assert.fail('timed out waiting for ' + what); await new Promise(r => setTimeout(r, 2)); } };

function makeEnv() {
    const els = {}; const mkEl = (id) => { const e = { id, style: {}, children: [], _cls: new Set(), textContent: '', className: '', visible: false,
        classList: { add: (c) => { e._cls.add(c); if (c === 'visible') e.visible = true; }, remove: (c) => { e._cls.delete(c); if (c === 'visible') e.visible = false; }, toggle: (c, on) => { if (on) e.classList.add(c); else e.classList.remove(c); } },
        appendChild(c) { e.children.push(c); }, querySelector: (q) => mkEl(q), set innerHTML(v) {} }; return e; };
    const env = { els, spoken: [], cards: [], logs: [], saves: 0, isPaused: false, cutsceneActive: false, introActive: false, photoRequested: false, playerPlatform: 'mobile', dayTimeFrozen: false, sfxCtx: null, sfxVolumeScale: 1, respawnPoint: { x: 1, y: 2, z: 3 }, window: { __ffCineActive: false, innerWidth: 800, innerHeight: 400 }, console,
        document: { getElementById: (id) => els[id] || (els[id] = mkEl(id)), createElement: (t) => mkEl(t), body: { appendChild() {} } }, performance: { now: () => Date.now() }, THREE: { Vector3: class { set(x, y, z) { this.x = x; this.y = y; this.z = z; return this; } project() { this.x = 0.1; this.y = 0; this.z = 0.5; return this; } } },
        player: { position: { x: 0, y: 0, z: 0, set(x, y, z) { this.x = x; this.y = y; this.z = z; } }, velocity: { set() {} }, yaw: 0, pitch: 0, cameraY: 0, isUnderwater: false, isGrounded: false },
        camera: { position: { x: 0, y: 0, z: 0, set(x, y, z) { this.x = x; this.y = y; this.z = z; }, copy(v) { this.x = v.x; this.y = v.y; this.z = v.z; } }, rotation: { x: 0, y: 0, z: 0, order: 'YXZ', set(x, y, z) { this.x = x; this.y = y; this.z = z; } }, quaternion: { copy() { return this; } }, updateMatrixWorld() {} },
        composer: { passes: [{ scene: 'WORLD' }], render() {} }, renderer: { compile() {} }, compassEl: Object.assign(mkEl('compass'), { clientWidth: 260 }),
        createLeviathan: (d) => createLeviathan(Object.assign({}, d, { getAudioContext: () => null })), createHack, initSfxEngine() {}, syncTimeSlider() {}, showAiEntity() { env.orb = true; }, updateCompass() {}, updateAutoCineBars() {}, capturePhoto() {}, updatePlayer() {},
        sleep: (ms) => new Promise(r => setTimeout(r, Math.min(ms, 400) / 40)), playLine: async (t) => { env.spoken.push(t); await new Promise(r => setTimeout(r, 4)); },
        addLog: (id, t) => env.logs.push(id), chapterCard: (t) => env.cards.push(t), writeCurrentSave() { env.saves++; }, updateMobileInteractButton() { env.btnCalls = (env.btnCalls || 0) + 1; env.__api && (env.els.harvestBtn = env.els.harvestBtn || mkEl('harvestBtn'), env.els.harvestBtn.visible = !!env.__api.interact()); } };
    return env;
}
function load(env) {
    const pre = 'let leviathanStage = 0, levActive = false, levReturn = null, levInteract = null, levWorldScene = null, levHidden = [], levBusy = false, levQueue = Promise.resolve(), levCapTok = 0, levLastIt = "", levBob = 0, lev = null, levHack = null, levLook = null, levScriptOn = false, levMarkEls = null, levNetEl = null, levSayAt = 0, levOnBroken = null, levOnOpened = null, levShakeOn = false;\n';
    const post = '\nreturn { tryEnterLeviathan, levPlaceAt, levFrame, levEvent, levFreed, get stage() { return leviathanStage; }, set stage(v) { leviathanStage = v; }, get active() { return levActive; }, get interact() { return levInteract; }, interact: () => levInteract, hack: () => levHack, lev: () => lev, busy: () => levBusy, look: () => levLook, net: () => levNetEl, marks: () => levMarkEls };';
    const f = new Function('env', 'with (env) {\n' + pre + slice + post + '\n}'); const api = f(env); env.__api = api; return api;
}

// ================= the kick button =================
{
    const env = makeEnv(), g = load(env); assert(await g.tryEnterLeviathan('landing')); assert(env.orb, 'the AI orb is revealed on entering'); env.isPaused = false; env.cutsceneActive = true;
    let frames = 0; const tick = setInterval(() => { g.levFrame(1 / 30); frames++; }, 1);
    await wait(() => g.lev().landing.canKick, 'the ship to halt', 20000); await wait(() => g.interact() && g.interact().btn === 'Kick', 'the Kick prompt'); assert(env.els.flowerPrompt.visible && env.els.harvestBtn.visible); pass('landing: the Kick prompt and button appear once the ship has halted');
    g.interact().action(); assert(g.interact() === null && !env.els.harvestBtn.visible && !env.els.flowerPrompt.visible && env.els.flowerPrompt.textContent === ''); pass('pressing Kick hides the prompt and the button at once');
    await wait(() => !g.lev().landing.active, 'the kick to finish', 20000); await new Promise(r => setTimeout(r, 60)); assert(g.interact() === null && !env.els.harvestBtn.visible && !env.els.flowerPrompt.visible, 'Kick came back'); pass('and it never comes back during the kick or afterwards'); clearInterval(tick);
}

// ================= the whole corridor sequence =================
const env = makeEnv(), g = load(env); env.isPaused = false; g.stage = 3;
assert(await g.tryEnterLeviathan('resume')); g.levPlaceAt(3); assert(g.hack().state === 'idle' && env.orb); pass('resume at the corridor: hack idle, orb revealed');
const P = env.player, mid = (L.cor.z0 + L.cor.z1) / 2; let walkTo = null;
env.updatePlayer = (dt) => { if (walkTo) { const dx = walkTo.x - P.position.x, d = Math.abs(dx); if (d < 2) walkTo = null; else P.position.x += Math.sign(dx) * Math.min(d, 60 * dt); } camera_sync(); };
const camera_sync = () => { env.camera.position.set(P.position.x, P.position.y, P.position.z); env.camera.rotation.set(P.pitch, P.yaw, 0); };
const tick = setInterval(() => { try { g.levFrame(1 / 30); } catch (e) { console.error(e); process.exit(1); } }, 1);
walkTo = { x: -230 };   // the player walks down the corridor while the AI talks
await wait(() => env.spoken.length >= 1, 'the first line'); await wait(() => env.spoken.some(t => /That reading again/.test(t)), 'the corridor line'); pass('entering the corridor starts the AI talking');
await wait(() => g.net() && /probing/i.test(g.net().textContent), 'the "probing" chip'); await wait(() => g.net() && /partial/i.test(g.net().textContent), 'local access chip'); assert(g.hack().state === 'idle'); pass('the AI probes the network, then reports local access (chip on screen), console not yet marked');
await wait(() => g.hack().state === 'found', 'the console to be found'); assert(env.spoken.some(t => /service console/.test(t))); pass('the AI finds a console and marks it');
await wait(() => g.look() !== null, 'the camera turn'); await wait(() => g.look() === null, 'the camera turn to finish'); { const C = HACK.console, dx = C.x - P.position.x, dz = C.z - P.position.z, want = Math.atan2(-dx, -dz); assert(Math.abs(Math.atan2(Math.sin(P.yaw - want), Math.cos(P.yaw - want))) < 0.02, 'camera not pointing at the console'); assert(P.pitch > -0.5 && P.pitch < 0.8); } pass('the camera swings round and ends pointing at the console');
await wait(() => g.marks() && g.marks().mk.style.display === 'block' && g.marks().cm.style.display === 'block'); assert(g.marks().label.textContent.includes('CONSOLE') && /\d+ m/.test(g.marks().dist.textContent)); pass('the marker is shown on the compass strip and on screen, with a label and a distance');
await wait(() => g.busy() === false && env.spoken.some(t => /press Hack/.test(t))); walkTo = { x: HACK.stand.x }; P.position.z = mid;
try { await wait(() => g.interact() && g.interact().btn === 'Hack', 'the Hack prompt', 3000); } catch (e) { console.log('DBG', P.position.x, P.position.z, walkTo, g.busy(), !!g.look(), env.isPaused, g.hack().state, g.hack().interaction(P.position.x, P.position.z)); throw e; } pass('near the console: the Hack prompt');
g.interact().action(); await wait(() => g.hack().state === 'hacking', 'hacking'); assert(g.busy() && g.look() && g.look().hold); assert(g.interact() === null); pass('Hack: the camera is pinned on the screen, nothing else can be pressed');
await wait(() => g.hack().state === 'garbled', 'garbled'); assert(env.spoken.includes("You know what? You can't possibly figure this out. How about we just break it?")); assert(g.look() === null && !g.busy()); pass('the screen is unreadable, the AI says "you know what? ... break it", control returns');
await wait(() => g.interact() && g.interact().btn === 'Break', 'the Break prompt'); pass('the Break button appears');
const alarmBefore = g.lev().state.alarm; g.interact().action(); assert(g.busy());
await wait(() => g.hack().state === 'unlocked', 'unlocked'); await wait(() => g.stage === 4, 'stage 4'); assert(g.lev().state.alarm === 0 && alarmBefore > 0.2 && env.logs.includes('log_leviathan_console') && env.saves > 0); pass('Break: alarms go to 0 (were ' + alarmBefore + '), progress saved (stage 4), log entry added');
await wait(() => env.spoken.some(t => /gone green/.test(t)) && env.spoken.some(t => /door is marked/.test(t))); await wait(() => g.look() === null && !g.busy(), 'the swing to the door'); { const D = HACK.door, dx = D.x - P.position.x, dz = D.z - P.position.z, want = Math.atan2(-dx, -dz); assert(Math.abs(Math.atan2(Math.sin(P.yaw - want), Math.cos(P.yaw - want))) < 0.02, 'camera not pointing at the door'); } pass('the AI says everything has gone green and the door is marked; the camera swings to the door');
await wait(() => g.marks().mk.style.display === 'block' && g.marks().mk.classList && g.marks().label.textContent.includes('DOOR')); pass('the door is marked on the compass and on screen');
walkTo = { x: L.doorX + 25 }; await wait(() => g.interact() && g.interact().btn === 'Open', 'the Open prompt'); g.interact().action();
await wait(() => g.hack().state === 'open', 'the door to open', 12000); await wait(() => g.stage === 5); assert(env.spoken.some(t => /Go through/.test(t))); pass('Open: the door slides open, stage 5 saved');
walkTo = { x: L.doorX - 80 }; await wait(() => env.cards.includes('TO BE CONTINUED'), 'the end card', 12000); await wait(() => g.stage === 9 && !g.active, 'the return to the shelter', 12000); pass('walking through ends this version: card, then back to the shelter, stage 9'); clearInterval(tick);
console.log('\n      AI lines, in order:'); for (const t of env.spoken) console.log('       - ' + t);
console.log('\n' + ok + ' checks passed'); fs.rmSync(tmp, { recursive: true, force: true }); process.exit(0);
