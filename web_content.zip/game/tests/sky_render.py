"""Compile and render the Leviathan sky shader (leviathan_sky.js) in headless Chromium (software WebGL2) and save PNGs.
   python3 tests/sky_render.py [outdir]     - prints any GLSL compile/link error, and renders a set of views.
   No three.js needed: the fragment shader gets the same prefix three.js adds; the vertex stage just builds vDir from a camera."""
import sys, os, json, base64, subprocess
from playwright.sync_api import sync_playwright
here = os.path.dirname(os.path.abspath(__file__)); root = os.path.dirname(here)
out = sys.argv[1] if len(sys.argv) > 1 else '/tmp/sky_out'; os.makedirs(out, exist_ok=True)
subprocess.check_call(['node', '-e', "import('%s/leviathan_sky.js').then(m=>{require('fs').writeFileSync('/tmp/storm.frag', m.STORM_FS)})" % root])
frag = open('/tmp/storm.frag').read()
frag = frag.replace('gl_FragColor = vec4(col, 1.0);', 'col = col * 0.9; col = (col * (2.51 * col + 0.03)) / (col * (2.43 * col + 0.59) + 0.14); col = pow(clamp(col, 0.0, 1.0), vec3(1.0 / 2.2)); gl_FragColor = vec4(col, 1.0);')
FS = '#version 300 es\nprecision highp float;\nout highp vec4 pc_fragColor;\n#define gl_FragColor pc_fragColor\n#define varying in\n' + frag
VS = '''#version 300 es
in vec2 aPos; uniform vec3 uCamDir; uniform vec3 uCamRight; uniform vec3 uCamUp; uniform float uTanHalf; uniform float uAspect; out vec3 vDir;
void main(){ vDir = uCamDir + uCamRight * aPos.x * uTanHalf * uAspect + uCamUp * aPos.y * uTanHalf; gl_Position = vec4(aPos, 0.0, 1.0); }'''
HTML = '<canvas id=c width=960 height=540></canvas>'
JS = '''
(args) => {
  const [VS, FS] = args; const c = document.getElementById('c'); const gl = c.getContext('webgl2', {preserveDrawingBuffer: true});
  const mk = (t, s) => { const sh = gl.createShader(t); gl.shaderSource(sh, s); gl.compileShader(sh); if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) throw new Error((t === gl.VERTEX_SHADER ? 'VERTEX: ' : 'FRAGMENT: ') + gl.getShaderInfoLog(sh)); return sh; };
  const p = gl.createProgram(); gl.attachShader(p, mk(gl.VERTEX_SHADER, VS)); gl.attachShader(p, mk(gl.FRAGMENT_SHADER, FS)); gl.linkProgram(p);
  if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error('LINK: ' + gl.getProgramInfoLog(p));
  gl.useProgram(p); const b = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, b); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1,-1, 3,-1, -1,3]), gl.STATIC_DRAW);
  const loc = gl.getAttribLocation(p, 'aPos'); gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
  const U = (n) => gl.getUniformLocation(p, n);
  window.renderView = (o) => {
    const az = o.az * Math.PI / 180, el = o.el * Math.PI / 180; const dir = [Math.cos(el) * Math.cos(az), Math.sin(el), Math.cos(el) * Math.sin(az)];
    const cr = (a, b) => [a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]]; const nm = (a) => { const l = Math.hypot(...a); return a.map(x => x / l); };
    const right = nm(cr(dir, [0,1,0])), up = cr(right, dir);
    gl.uniform3fv(U('uCamDir'), dir); gl.uniform3fv(U('uCamRight'), right); gl.uniform3fv(U('uCamUp'), up);
    gl.uniform1f(U('uTanHalf'), Math.tan(o.fov * Math.PI / 360)); gl.uniform1f(U('uAspect'), 960 / 540);
    gl.uniform1f(U('uTime'), o.time); gl.uniform1f(U('uFlash'), o.flash || 0); gl.uniform3fv(U('uFlashDir'), nm(o.flashDir || [0.7, 0.25, -0.3])); gl.uniform1f(U('uSeed'), o.seed || 0.3);
    gl.uniform1f(U('uClear'), o.clear); gl.uniform1f(U('uSteps'), o.steps || 20); gl.uniform3fv(U('uSunDir'), nm([0.89, 0.44, -0.12])); gl.uniform3fv(U('uMoonDir'), nm([0.93, 0.20, 0.30]));
    gl.viewport(0, 0, 960, 540); gl.drawArrays(gl.TRIANGLES, 0, 3); gl.finish();
    return c.toDataURL('image/png');
  };
  return 'ok';
}
'''
views = [
 ('immersed_east',    dict(az=0,   el=5,   fov=75, time=12,  clear=0.0)),
 ('immersed_flash',   dict(az=0,   el=10,  fov=75, time=12,  clear=0.0, flash=1.0, seed=0.6, flashDir=[0.9, 0.2, 0.1])),
 ('immersed_rift',    dict(az=18,  el=11,  fov=60, time=44,  clear=0.0)),
 ('rising',           dict(az=0,   el=0,   fov=75, time=28,  clear=0.5)),
 ('clear_east_low',   dict(az=0,   el=-4,  fov=75, time=60,  clear=1.0)),
 ('clear_moon',       dict(az=17,  el=11,  fov=40, time=60,  clear=1.0)),
 ('moon_centered',   dict(az=17.9, el=11.2, fov=12, time=60, clear=1.0)),
 ('moon_fov40',      dict(az=17.9, el=11.2, fov=40, time=60, clear=1.0)),
 ('moon_fov75',      dict(az=17.9, el=11.2, fov=75, time=60, clear=1.0)),
 ('clear_horizon',    dict(az=-20, el=4,   fov=75, time=60,  clear=1.0)),
 ('clear_down',       dict(az=0,   el=-25, fov=75, time=60,  clear=1.0)),
 ('clear_up',         dict(az=0,   el=40,  fov=75, time=60,  clear=1.0)),
]
if len(sys.argv) > 2: views = [v for v in views if v[0] in sys.argv[2:]]
import time as _t
with sync_playwright() as pw:
    br = pw.chromium.launch(args=['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'])
    pg = br.new_page(viewport={'width': 960, 'height': 540}); pg.set_content(HTML)
    try: print(pg.evaluate(JS, [VS, FS]), '- shader compiled and linked')
    except Exception as e: print('SHADER ERROR:\n' + str(e)[:3000]); sys.exit(1)
    for name, o in views:
        t0 = _t.time(); url = pg.evaluate('(o) => window.renderView(o)', o); dt = _t.time() - t0
        open(os.path.join(out, name + '.png'), 'wb').write(base64.b64decode(url.split(',')[1])); print('  %-16s %.1fs' % (name, dt))
    br.close()
