import { TerrainCore } from '../terrain_core.js';
import * as V from '../valley_sites.js';
import { buildRoad, planRoads } from '../city_roads.js';
for (const seed of [1, 12345, 987654321, 424242, 31337, 2718281828, 99, 777777]) {
  const T = new TerrainCore(seed), sites = V.findSites(T, seed).sites, pairs = planRoads(sites);
  let ok = 0, tms = 0, out = [];
  for (const p of pairs) { const r = buildRoad(T, sites[p.a], sites[p.b]); tms += r.ms; if (r.ok) { ok++; out.push(`${p.a}-${p.b}:${(r.len/4250).toFixed(0)}km@${r.slopeLimit}`); } }
  console.log(`seed ${seed}: ${sites.length} sites, ${pairs.length} candidate pairs, ${ok} routable [${out.join(' ')}], total ${tms.toFixed(0)}ms`);
}
