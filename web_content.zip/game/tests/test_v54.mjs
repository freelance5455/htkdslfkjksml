import { TerrainCore } from '../terrain_core.js';
import * as V from '../valley_sites.js';
import { generateCity, planToInstances, planToLife, planToCols, planToRoad, makeNatGrid } from '../city_core.js';
import { CityCollider } from '../city_collide.js';
import { PLANET_R } from '../planet_core.js';
const seed = 424242, T = new TerrainCore(seed), o = {}, d = [0,0,0];
const sites = V.findSites(T, seed).sites, N = +(process.argv[2] || 8);
const inObb=(b,x,z,pad)=>{const c=Math.cos(b.yaw),s=Math.sin(b.yaw),dx=x-b.x,dz=z-b.z,u=dx*c+dz*s,v=-dx*s+dz*c;return Math.abs(u)<=b.w/2+pad&&Math.abs(v)<=b.d/2+pad;};
let fail = 0;
for (const S of sites.slice(0, N)) {
  const nat3 = (x, z) => { V.localToDir(S, x, -z, d); return T.sample3(d[0]*PLANET_R, d[1]*PLANET_R, d[2]*PLANET_R, o); };
  const t0 = performance.now(), city = generateCity(S, makeNatGrid(S, nat3, 20)), t1 = performance.now();
  const inst = planToInstances(city), life = planToLife(city), cols = planToCols(city), road = planToRoad(city), col = new CityCollider(cols);
  let bad = 0, tot = 0;
  for (const e of city.edges) { if (e.t === 2) continue; const A = city.nodes[e.a], B = city.nodes[e.b], L = Math.hypot(B.x-A.x, B.z-A.z), n = Math.ceil(L/4);
    for (let k = 0; k <= n; k++) { const x = A.x+(B.x-A.x)*k/n, z = A.z+(B.z-A.z)*k/n; tot++; for (const b of city.buildings) { if (Math.abs(b.x-x)>40||Math.abs(b.z-z)>40) continue; if (inObb(b,x,z,e.w*0.35)) { bad++; break; } } } }
  // connectivity
  const NN = city.nodes.length, seen = new Uint8Array(NN), q = [0]; seen[0] = 1; let c = 1; while (q.length) { const a = q.pop(); for (const b of city.nodes[a].adj) if (!seen[b]) { seen[b] = 1; c++; q.push(b); } }
  // collider sanity: a player standing in the middle of a street must be on a floor, and not inside a building
  let nanC = 0; for (let i = 0; i < cols.length; i++) if (!Number.isFinite(cols[i])) nanC++;
  const nanR = road.pos.some(v => !Number.isFinite(v));
  const hub = col.floorAt(0, 0, 1e9, 0);
  console.log(`site ${S.id} ${city.arche} B${city.buildings.length} cols${cols.length/9} roadV${road.pos.length/3} onStreet ${(100*bad/tot).toFixed(2)}% conn ${c}/${NN} gate${seen[city.gateNode]?'Y':'N'} nan${nanC}/${nanR} ${city.stats.edgeStyles} spurs${city.spurs} outp${city.outposts} ${JSON.stringify(city.edgeStats)} maxF${city.stats.maxFloors} gen ${(t1-t0).toFixed(0)}ms`);
  if (bad || c !== NN || !seen[city.gateNode] || nanC || nanR) fail++;
}
console.log(fail ? 'FAIL ' + fail : 'ALL OK');
process.exit(fail ? 1 : 0);
