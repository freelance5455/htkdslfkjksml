import { TerrainCore } from '../terrain_core.js';
import * as V from '../valley_sites.js';
import { generateCity, planToLife, makeNatGrid } from '../city_core.js';
import { makeResidents } from '../city_life.js';
import { CitySim } from '../city_sim.js';
import { PLANET_R } from '../planet_core.js';
const seed = 424242, T = new TerrainCore(seed), o={}, d=[0,0,0];
const S = V.findSites(T, seed).sites[3];
const nat = makeNatGrid(S, (x,z)=>{ V.localToDir(S,x,-z,d); return T.sample3(d[0]*PLANET_R,d[1]*PLANET_R,d[2]*PLANET_R,o); }, 20);
const city = generateCity(S, nat), life = planToLife(city), res = makeResidents(S.seedN, 60, life);
let t0 = performance.now();
const sim = new CitySim(life, res, { cityName: 'Test', seed: S.seedN, maxDrones: 48 });
sim.activate(0.30); console.log('activate ms', (performance.now()-t0).toFixed(1), 'drones', sim.drones.length);
const player = { x: 0, z: 30 };
let bubbles = 0, maxB = 0, lines = new Set(), t = 0; const dt = 0.1;
const stats = {};
t0 = performance.now();
for (let hour = 0; hour < 24; hour += 0.1) {
  const dayTime = (0.30 + hour / 24) % 1;
  for (let k = 0; k < 6; k++) { sim.step(dt, dayTime, dayTime < 0.25 || dayTime > 0.75, hour > 12, player); for (const d of sim.drones) if (d.bubble) lines.add(d.bubble.text); maxB = Math.max(maxB, sim.bubbles); }
  if (Math.abs(hour % 4) < 0.05) { const slotCount = {}; for (const dr of sim.drones) slotCount[dr.state + (dr.asleep?'(zzz)':'')] = (slotCount[dr.state + (dr.asleep?'(zzz)':'')]||0)+1; stats[hour.toFixed(0)+'h dayTime '+dayTime.toFixed(2)] = JSON.stringify(slotCount); }
}
console.log('sim wall ms for 24h*60 steps', (performance.now()-t0).toFixed(0));
console.log(stats); console.log('distinct lines', lines.size, 'max concurrent bubbles', maxB, 'sample:', [...lines].slice(0,4));
let bad = 0, maxR = 0; for (const dr of sim.drones) { if (!isFinite(dr.x+dr.y+dr.z)) bad++; maxR = Math.max(maxR, Math.hypot(dr.x, dr.z)); } console.log('NaN drones', bad, 'max radius from centre', maxR.toFixed(0), 'Rf', S.Rf.toFixed(0), 'rim', S.rimR.toFixed(0));
// at night all should be home/asleep
sim.activate(0.05); const asleep = sim.drones.filter(d=>d.asleep).length; console.log('activate at 0.05 asleep', asleep, '/', sim.drones.length);
