# Lifecycle test for dream_cinematic.js in headless Chromium: play -> double-tap pause -> Keep watching -> Leave fires -> skip -> whileBlack -> overlay removed.
import sys, os, subprocess, time
from playwright.sync_api import sync_playwright
srv = subprocess.Popen([sys.executable, '-m', 'http.server', '8768', '--directory', os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(1)
ok = True
def check(name, cond):
    global ok; print(('PASS ' if cond else 'FAIL ') + name); ok = ok and bool(cond)
try:
    with sync_playwright() as p:
        b = p.chromium.launch(args=['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--no-sandbox', '--autoplay-policy=no-user-gesture-required'])
        pg = b.new_page(viewport={'width': 480, 'height': 270}); logs = []
        pg.on('console', lambda m: logs.append(m.text)); pg.on('pageerror', lambda e: logs.append('PAGEERR ' + str(e)))
        pg.goto('http://localhost:8768/tests/dream_harness.html'); pg.wait_for_timeout(1000)
        pg.evaluate('window.dream.debug.unmount()')
        pg.evaluate('''() => {
            const ctx = new (window.AudioContext || window.webkitAudioContext)();
            window.__ev = { black: 0, leave: 0, done: false, ctx };
            window.dream2 = null;
            import('/dream_cinematic.js').then(m => {
                window.dream2 = m.createDreamCinematic({ getAudioContext: () => ctx });
                window.dream2.play({ whileBlack: async () => { window.__ev.black++; }, onLeave: () => { window.__ev.leave++; } }).then(() => { window.__ev.done = true; });
            });
        }''')
        pg.wait_for_timeout(4500)
        check('overlay mounted and active', pg.evaluate('!!document.getElementById("drCine") && window.dream2.active'))
        check('window.__ffCineActive set', pg.evaluate('window.__ffCineActive === true'))
        check('audio context running', pg.evaluate('window.__ev.ctx.state') == 'running')
        for _ in range(2): pg.mouse.click(240, 100); pg.wait_for_timeout(60)
        pg.wait_for_timeout(300)
        check('double-tap opens pause', pg.evaluate('document.querySelector("#drCine .dr-pause").classList.contains("on")'))
        check('audio suspended while paused', pg.evaluate('window.__ev.ctx.state') == 'suspended')
        pg.click('#drCine .dr-resume'); pg.wait_for_timeout(300)
        check('Keep watching resumes', not pg.evaluate('document.querySelector("#drCine .dr-pause").classList.contains("on")') and pg.evaluate('window.__ev.ctx.state') == 'running')
        pg.keyboard.press('Space'); pg.keyboard.press('Enter'); pg.wait_for_timeout(300)
        check('Space/Enter do not end it', pg.evaluate('window.dream2.active'))
        pg.keyboard.press('Escape'); pg.wait_for_timeout(200)
        pg.click('#drCine .dr-leave'); pg.wait_for_timeout(200)
        check('Leave fires the leave callback', pg.evaluate('window.__ev.leave') == 1)
        pg.keyboard.press('Escape'); pg.wait_for_timeout(200)
        pg.evaluate('window.dream2.skip()'); pg.wait_for_timeout(2500)
        check('whileBlack ran exactly once', pg.evaluate('window.__ev.black') == 1)
        check('play() resolved', pg.evaluate('window.__ev.done'))
        check('overlay removed', pg.evaluate('!document.getElementById("drCine")'))
        check('__ffCineActive cleared', pg.evaluate('window.__ffCineActive === false'))
        errs = [l for l in logs if 'ERR' in l.upper() and 'clamped' not in l]
        check('no page errors', not errs)
        if errs: print(errs[:5])
        b.close()
finally:
    srv.terminate()
print('ALL PASS' if ok else 'SOME FAILED'); sys.exit(0 if ok else 1)
