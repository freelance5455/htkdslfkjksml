// v94: statistical check of the weather FRONTS layer. Extracts wxFieldAt from game.js and samples it on stub climates, with fronts off vs on.
import fs from 'fs';
import { SimplexNoise, mulberry32 } from '../noise_core.js';
const src = fs.readFileSync(new URL('../game.js', import.meta.url), 'utf8');
const a = src.indexOf('function wxFieldAt'), b = src.indexOf('// Rebuilt in slices (8 rows per call)');
const fnSrc = src.slice(a, b);
const mk = (frontK, clim, seed) => {
  const simplex = new SimplexNoise(mulberry32(seed));
  const _wxClamp01 = (v) => v < 0 ? 0 : v > 1 ? 1 : v;
  const _wxSS = (a, b, x) => { const t = _wxClamp01((x - a) / (b - a)); return t * t * (3 - 2 * t); };
  const WX = { fM: [1,0,0,1], fT: [0,0], o1x: 0, o1z: 0, o2x: 0, o2z: 0, bias: 0.12, precipGate: 1, stormGate: 1, forceWarm: -1, rainForce: 0, frontK, t: 0, _c: {} };
  const wxClimateAt = (x, z, out) => { Object.assign(out, { t: clim.t, m: clim.m, h: clim.h || 300, hm: clim.h || 300, land: 1, jet: 0, jp: 0, wx: 1, wz: 0, lift: 0, shadow: 0, rel: 200 }); };
  const f = new Function('simplex','WX','wxClimateAt','_wxClamp01','_wxSS', fnSrc + '; return wxFieldAt;')(simplex, WX, wxClimateAt, _wxClamp01, _wxSS);
  return { f, WX };
};
const clims = { tropic: { t: 0.75, m: 0.8 }, temperate: { t: 0.5, m: 0.6 }, dryish: { t: 0.62, m: 0.35 }, cold: { t: 0.36, m: 0.55 } };
for (const [name, clim] of Object.entries(clims)) for (const fk of [0, 1]) {
  const { f, WX } = mk(fk, clim, 1234);
  const N = 6000, o = {}; const c = { snow: 0, rain: 0, storm: 0, dustFront: 0, coldF: 0, hotF: 0, precip: 0 };
  for (let i = 0; i < N; i++) {
    WX.t = Math.random() * 2e5; WX.o1x = Math.random() * 4e5; WX.o1z = Math.random() * 4e5; WX.o2x = WX.o1x * 0.6; WX.o2z = WX.o1z * 0.6;
    f(Math.random() * 3e5, Math.random() * 3e5, o);
    if (o.precip > 0.3) { if (o.warm < 0.4) c.snow++; else c.rain++; }
    if (o.storm > 0.45) c.storm++;
    if (o.hotF > 0.75 && o.m0 < 0.45) c.dustFront++;
    if (o.coldF > 0.5) c.coldF++; if (o.hotF > 0.5) c.hotF++;
  }
  const pc = (k) => (100 * c[k] / N).toFixed(1) + '%';
  console.log(`${name.padEnd(10)} fronts=${fk}  rain ${pc('rain')}  snow ${pc('snow')}  storm ${pc('storm')}  dust-front ${pc('dustFront')}  (cold air ${pc('coldF')}, hot air ${pc('hotF')})`);
}
