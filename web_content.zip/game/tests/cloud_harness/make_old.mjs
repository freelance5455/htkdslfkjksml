// Builds the ORIGINAL (pre-overhaul) cumulus shader from a pristine copy of game.js, so the CPU harness can render A/B comparisons.
// usage: node make_old.mjs <path to original game.js> <outdir>
import fs from 'node:fs';
const [,, gamePath, outDir] = process.argv;
const src = fs.readFileSync(gamePath, 'utf8');
const a = src.indexOf('        const WX_GLSL_COMMON = `');
const b = src.indexOf('        // Thin planar cloud sheets built from the same noise volume.');
const code = src.slice(a, b);
const pre = `const WX_MAP_N = 56; const WX_CLOUD_BASE = 1400; const NIGHT_LOOK = { cloudMinVisibility: 0.34, cloudOvercastVisibility: 0.80 };\nconst WX_CLOUD_TOP = 11000;\n`;
const mod = pre + code + `\nexport { wxCumulusShaders };`;
fs.mkdirSync(outDir, { recursive: true });
fs.writeFileSync(outDir + '/_old_mod.mjs', mod);
const { wxCumulusShaders } = await import(outDir + '/_old_mod.mjs');
fs.writeFileSync(outDir + '/old_cumulus.frag', wxCumulusShaders(false).fragmentShader);
console.log('old shader written');
