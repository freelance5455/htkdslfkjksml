// CPU renderer for the cloud shaders (see build_harness.py). Not the game - a deterministic stand-in for the GPU so the sky can be looked at
// and compared (old vs new) without a browser. Usage:
//   harness <scene> <variant:old|new|lite> <out.ppm> [width height] [key=value ...]
#include "shaders_gen.inc"
#include <cstdio>
#include <cstdlib>
#include <string>
#include <map>
#include <fstream>
#include <sstream>

vec3 cameraPosition; mat4 viewMatrix; vec4 gl_FragCoord; vec4 gl_FragColor; float gl_FragDepth; bool gDiscard;

static std::vector<uint8_t> noiseData, wxMapData, wxTerrData;
static float lin(float c) { return c <= 0.04045f ? c / 12.92f : powf((c + 0.055f) / 1.055f, 2.4f); }
static vec3 hex(unsigned h) { return vec3(lin(((h >> 16) & 255) / 255.f), lin(((h >> 8) & 255) / 255.f), lin((h & 255) / 255.f)); }

// ---------- tiny value noise for the synthetic weather map ----------
static float hsh(int x, int y, int s) { unsigned h = (unsigned)(x * 374761393 + y * 668265263 + s * 1274126177); h = (h ^ (h >> 13)) * 1274126177u; return ((h ^ (h >> 16)) & 0xffff) / 65535.f; }
static float vn(float x, float y, int s) { int ix = (int)floorf(x), iy = (int)floorf(y); float fx = x - ix, fy = y - iy; fx = fx * fx * (3 - 2 * fx); fy = fy * fy * (3 - 2 * fy);
    return mix(mix(hsh(ix, iy, s), hsh(ix + 1, iy, s), fx), mix(hsh(ix, iy + 1, s), hsh(ix + 1, iy + 1, s), fx), fy); }
static float fbm(float x, float y, int s) { return 0.55f * vn(x, y, s) + 0.28f * vn(x * 2.1f, y * 2.1f, s + 7) + 0.17f * vn(x * 4.3f, y * 4.3f, s + 13); }

struct Scene { std::string name; float camY = 90, yaw = 0, pitch = 10, fov = 62; float sunEl = 45, sunAz = 150; std::string wx = "fair"; float grey = 0; float night = 0; float wind = 0;
    float camX = 0, camZ = 0; std::string sky = "day"; };

static void buildMaps(const Scene& S) {
    const int N = 56; wxMapData.assign(N * N * 4, 0); wxTerrData.assign(N * N * 4, 0);
    for (int j = 0; j < N; j++) for (int i = 0; i < N; i++) {
        float wx = ((i + 0.5f) / N * 2 - 1) * 42000.f, wz = ((j + 0.5f) / N * 2 - 1) * 42000.f;
        float f = fbm(wx / 14000.f + 3.3f, wz / 14000.f - 1.7f, 11);
        float cover = 0, precip = 0, storm = 0;
        if (S.wx == "fair") cover = clamp((f - 0.30f) * 2.4f, 0.f, 1.f) * 0.85f + 0.10f;
        else if (S.wx == "cumulus") cover = 0.30f + 0.34f * clamp((f - 0.28f) * 3.0f, 0.f, 1.f);
        else if (S.wx == "broken") cover = clamp((f - 0.20f) * 2.6f, 0.f, 1.f) * 0.8f + 0.2f;
        else if (S.wx == "overcast") { cover = 0.96f; }
        else if (S.wx == "rain") { cover = 0.97f; precip = clamp((fbm(wx / 9000.f + 7.f, wz / 9000.f, 5) - 0.35f) * 2.5f, 0.f, 1.f) * 0.8f; }
        else if (S.wx == "showers") { cover = clamp((f - 0.15f) * 2.6f, 0.f, 1.f) * 0.75f + 0.25f; float pr = fbm(wx / 7000.f + 9.f, wz / 7000.f + 4.f, 5); precip = clamp((pr - 0.52f) * 5.f, 0.f, 1.f) * smoothstep(0.55f, 0.85f, cover) * 0.9f; }
        else if (S.wx == "storm") {
            float d = sqrtf((wx - 3000) * (wx - 3000) + (wz - 14000) * (wz - 14000)); float k = expf(-(d * d) / (2 * 7000.f * 7000.f));
            cover = clamp(0.45f + k * 0.7f + (f - 0.5f) * 0.6f, 0.f, 1.f); storm = clamp(k * 1.2f, 0.f, 1.f) * smoothstep(0.5f, 0.8f, cover); precip = storm * 0.95f;
        }
        uint8_t* p = &wxMapData[(j * N + i) * 4]; p[0] = (uint8_t)(clamp(cover, 0.f, 1.f) * 255); p[1] = (uint8_t)(clamp(precip, 0.f, 1.f) * 255); p[2] = (uint8_t)(clamp(storm, 0.f, 1.f) * 255); p[3] = 255;
        uint8_t* q = &wxTerrData[(j * N + i) * 4]; q[0] = (uint8_t)(0.02f * 255); q[1] = (uint8_t)(100.f / 8000.f * 255); q[2] = 0; q[3] = 0;
    }
}

template <class NS> static void setCommon(const Scene& S, vec3 L, vec3 sunCol, vec3 fog, vec3 zen, vec3 mid, vec3 hor, bool sky) {}

#define SET_UNIFORMS(NS, WINDOFF) do { \
    NS::sunDir = L; NS::sunColor = sunCol; NS::fogColor = fog; NS::u_time = 120.f; NS::nightFactor = S.night; NS::windOff = WINDOFF; NS::windDir = vec2(0.8f, 0.6f); \
    NS::grey = S.grey; NS::wxM4 = vec4(1, 0, 0, 1); NS::noiseTex.data = noiseData.data(); NS::noiseTex.N = 48; NS::wxMap.data = wxMapData.data(); NS::wxMap.N = 56; \
    NS::wxTerr.data = wxTerrData.data(); NS::wxTerr.N = 56; NS::wxInfo = vec3(0, 0, 42000.f); NS::wxLightning = vec4(0, 0, 0, 0); NS::wxFlash = 0; } while (0)

// three.js ACESFilmicToneMapping (Stephen Hill fit) at the game's exposure (1.22), then linear -> sRGB
static vec3 acesTone(vec3 c) {
    c = c * (1.22f / 0.6f);
    const float I[3][3] = { { 0.59719f, 0.35458f, 0.04823f }, { 0.07600f, 0.90834f, 0.01566f }, { 0.02840f, 0.13383f, 0.83777f } };   // rows (= GLSL columns transposed)
    const float O[3][3] = { { 1.60475f, -0.53108f, -0.07367f }, { -0.10208f, 1.10813f, -0.00605f }, { -0.00327f, -0.07276f, 1.07602f } };
    float v[3], r[3];
    for (int i = 0; i < 3; i++) v[i] = I[i][0] * c.x + I[i][1] * c.y + I[i][2] * c.z;
    for (int i = 0; i < 3; i++) { float x = v[i]; v[i] = (x * (x + 0.0245786f) - 0.000090537f) / (x * (0.983729f * x + 0.4329510f) + 0.238081f); }
    for (int i = 0; i < 3; i++) { float x = O[i][0] * v[0] + O[i][1] * v[1] + O[i][2] * v[2]; x = clamp(x, 0.f, 1.f); r[i] = x <= 0.0031308f ? x * 12.92f : 1.055f * powf(x, 1 / 2.4f) - 0.055f; }
    return vec3(r[0], r[1], r[2]);
}

int main(int argc, char** argv) {
    if (argc < 4) { fprintf(stderr, "usage\n"); return 1; }
    std::string sceneName = argv[1], variant = argv[2], outPath = argv[3]; int W = 480, H = 270; int ai = 4;
    if (argc >= 6 && isdigit(argv[4][0])) { W = atoi(argv[4]); H = atoi(argv[5]); ai = 6; }
    Scene S; S.name = sceneName;
    for (int i = ai; i < argc; i++) { std::string a = argv[i]; size_t e = a.find('='); if (e == std::string::npos) continue; std::string k = a.substr(0, e), v = a.substr(e + 1); float f = (float)atof(v.c_str());
        if (k == "camY") S.camY = f; else if (k == "yaw") S.yaw = f; else if (k == "pitch") S.pitch = f; else if (k == "fov") S.fov = f; else if (k == "sunEl") S.sunEl = f; else if (k == "sunAz") S.sunAz = f;
        else if (k == "wx") S.wx = v; else if (k == "grey") S.grey = f; else if (k == "night") S.night = f; else if (k == "sky") S.sky = v; else if (k == "camX") S.camX = f; else if (k == "camZ") S.camZ = f; }
    { std::ifstream nf("/tmp/cloudgl/noise48.bin", std::ios::binary); noiseData.assign(48 * 48 * 48 * 4, 0); nf.read((char*)noiseData.data(), noiseData.size()); if (!nf) { fprintf(stderr, "noise48.bin missing\n"); return 1; } }
    buildMaps(S);

    float el = S.sunEl * 3.14159265f / 180.f, az = S.sunAz * 3.14159265f / 180.f;
    vec3 L(cosf(el) * sinf(az), sinf(el), cosf(el) * cosf(az));
    vec3 zen, mid, hor, sunCol, fog;
    if (S.sky == "day") { zen = hex(0x0c58dd); mid = hex(0x2f8ff5); hor = hex(0x8fd4ff); sunCol = hex(0xfff8e6); fog = hex(0x8fd4ff); }
    else if (S.sky == "sunset") { zen = hex(0x2e1a4a); mid = hex(0xe2547a); hor = hex(0xff7a38); sunCol = hex(0xffab4a); fog = hex(0xff7a38); }
    else { zen = hex(0x040d24); mid = hex(0x0c1c48); hor = hex(0x162a5c); sunCol = hex(0xa6bde8); fog = hex(0x162a5c); }
    vec3 groundCol = hex(0x4a7a3a);

    cameraPosition = vec3(S.camX, S.camY, S.camZ);
    float yaw = S.yaw * 3.14159265f / 180.f, pitch = S.pitch * 3.14159265f / 180.f, tanH = tanf(S.fov * 0.5f * 3.14159265f / 180.f);
    vec3 fwd(sinf(yaw) * cosf(pitch), sinf(pitch), cosf(yaw) * cosf(pitch)); vec3 right = normalize(vec3(cosf(yaw), 0, -sinf(yaw))); vec3 up = vec3(fwd.y * right.z - fwd.z * right.y * 0, 0, 0);
    // up = right x fwd
    up = vec3(right.y * fwd.z - right.z * fwd.y, right.z * fwd.x - right.x * fwd.z, right.x * fwd.y - right.y * fwd.x) * -1.f;
    if (up.y < 0) up = up * -1.f;

    bool isOld = variant == "old", isLite = variant == "lite";
    std::vector<float> img((size_t)W * H * 3);
    for (int py = 0; py < H; py++) for (int px = 0; px < W; px++) {
        float sx = ((px + 0.5f) / W * 2 - 1) * tanH * (float)W / H, sy = (1 - (py + 0.5f) / H * 2) * tanH;
        vec3 rd = normalize(fwd + right * sx + up * sy);
        // ---- background: sky gradient, sun, ground ----
        vec3 col;
        float e = rd.y;
        if (e >= 0) {
            col = mix(hor, mid, smoothstep(0.0f, 0.30f, e)); col = mix(col, zen, smoothstep(0.25f, 0.95f, e));
            float cs = dot(rd, L); col = col + sunCol * (powf(fmaxf(cs, 0.f), 900.f) * 6.f + powf(fmaxf(cs, 0.f), 10.f) * 0.10f + powf(fmaxf(cs, 0.f), 60.f) * 0.20f) * (1.f - S.night);
        } else {
            float dist = (cameraPosition.y + 1.f) / fmaxf(-e, 0.01f); vec3 g = groundCol * (0.25f + 0.75f * fmaxf(L.y, 0.f)) * (1.f - 0.7f * S.night);
            col = mix(g, fog, 1.f - expf(-dist / 24000.f));
        }
        gl_FragCoord = vec4((float)px + 0.5f, (float)(H - py) - 0.5f, 0.5f, 1.f);
        // ---- thin layers (straight alpha): cirrus then alto-stratocumulus ----
        struct PL { const char* n; float alt; } pls[2] = { { "cirrus", 7400 }, { "alto", 4300 } };
        for (int li = 0; li < 2; li++) {
            float alt = pls[li].alt; if (rd.y <= 0.0005f) continue; float tt = (alt - cameraPosition.y) / rd.y; vec3 hit = cameraPosition + rd * tt;
            gDiscard = false; gl_FragColor = vec4(0, 0, 0, 0);
            if (li == 0) {
                SET_UNIFORMS(cirrus, vec2(-2200.f, -1800.f)); cirrus::skyZen = zen; cirrus::skyMid = mid; cirrus::skyHor = hor;
                cirrus::vWorldPos = hit; cirrus::vLocalXZ = vec2(hit.x - cameraPosition.x, hit.z - cameraPosition.z); cirrus::shader_main();
            } else {
                SET_UNIFORMS(alto, vec2(-1400.f, -900.f)); alto::skyZen = zen; alto::skyMid = mid; alto::skyHor = hor;
                alto::vWorldPos = hit; alto::vLocalXZ = vec2(hit.x - cameraPosition.x, hit.z - cameraPosition.z); alto::shader_main();
            }
            if (!gDiscard) { float a = gl_FragColor.w; col = vec3(gl_FragColor.x, gl_FragColor.y, gl_FragColor.z) * a + col * (1.f - a); }
        }
        // ---- volumetric slab (premultiplied) ----
        gDiscard = false; gl_FragColor = vec4(0, 0, 0, 0);
        if (isOld) {
            SET_UNIFORMS(old_cumulus, vec2(0, 0)); old_cumulus::windOff = vec2(-600.f, -400.f); old_cumulus::quality = 1.f; old_cumulus::floorY = 100; old_cumulus::rainBot = 1; old_cumulus::rainIn = 0; old_cumulus::vDir = rd; old_cumulus::shader_main();
        } else if (isLite) {
            SET_UNIFORMS(cumulus_lite, vec2(0, 0)); cumulus_lite::windOff = vec2(-600.f, -400.f); cumulus_lite::quality = 1.f; cumulus_lite::floorY = 100; cumulus_lite::rainBot = 1; cumulus_lite::rainIn = 0;
            cumulus_lite::skyZen = zen; cumulus_lite::skyMid = mid; cumulus_lite::skyHor = hor; cumulus_lite::groundCol = groundCol; cumulus_lite::vDir = rd; cumulus_lite::shader_main();
        } else {
            SET_UNIFORMS(cumulus, vec2(0, 0)); cumulus::windOff = vec2(-600.f, -400.f); cumulus::quality = 1.f; cumulus::floorY = 100; cumulus::rainBot = 1; cumulus::rainIn = 0;
            cumulus::skyZen = zen; cumulus::skyMid = mid; cumulus::skyHor = hor; cumulus::groundCol = groundCol; cumulus::vDir = rd; cumulus::shader_main();
        }
        if (!gDiscard) { float a = gl_FragColor.w; col = vec3(gl_FragColor.x, gl_FragColor.y, gl_FragColor.z) + col * (1.f - a); }
        vec3 o = acesTone(col);
        float* d = &img[((size_t)py * W + px) * 3]; d[0] = o.x; d[1] = o.y; d[2] = o.z;
    }
    FILE* f = fopen(outPath.c_str(), "wb"); fprintf(f, "P6\n%d %d\n255\n", W, H);
    for (size_t i = 0; i < img.size(); i++) { int v = (int)(clamp(img[i], 0.f, 1.f) * 255.f + 0.5f); fputc(v, f); } fclose(f);
    return 0;
}
