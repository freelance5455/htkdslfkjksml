// Generates the cloud GLSL (and the noise volume) from cloud_shaders.js into an output directory, for the CPU harness / inspection.
import { wxCumulusShaders, wxLayeredShaders, wxBuildCloudNoiseData } from '../../cloud_shaders.js';
import fs from 'node:fs';
const out = process.argv[2] || '/tmp/cloudgl';
fs.mkdirSync(out, { recursive: true });
const env = { MAP_N: 56, BASE: 1400, TOP: 11000, nightMin: 0.34, nightOver: 0.80 };
const full = wxCumulusShaders(false, env), lite = wxCumulusShaders(true, env);
fs.writeFileSync(out + '/cumulus.frag', full.fragmentShader);
fs.writeFileSync(out + '/cumulus_lite.frag', lite.fragmentShader);
const planes = [
  { name: 'cirrus', kind: 2, altitude: 7400, scale: 5200, softness: 0.16, densityPow: 1.4, opacity: 0.34, shadowCol: 'vec3(0.62, 0.62, 0.72)', litCol: 'vec3(1.0, 0.97, 0.92)', rank: 1, wind: 'windOffHi' },
  { name: 'alto', kind: 1, altitude: 4300, scale: 6200, softness: 0.26, densityPow: 0.9, opacity: 0.58, shadowCol: 'vec3(0.46, 0.49, 0.58)', litCol: 'vec3(0.97, 0.96, 0.98)', rank: 2, wind: 'windOffMid' },
];
for (const cfg of planes) fs.writeFileSync(`${out}/${cfg.name}.frag`, wxLayeredShaders({ ...cfg, edgeStart: 150000 * 0.28, edgeEnd: 150000 * 0.5 }, env).fragmentShader);
if (process.argv[3] === 'noise') fs.writeFileSync(out + '/noise48.bin', Buffer.from(wxBuildCloudNoiseData(48)));
console.log('wrote', fs.readdirSync(out).join(', '));
