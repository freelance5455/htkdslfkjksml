# Cloud harness (CPU stand-in for the GPU)
    node tests/cloud_harness/gen_glsl.mjs /tmp/cloudgl noise        # generate GLSL + noise volume
    node tests/cloud_harness/make_old.mjs <old game.js> /tmp/cloudgl  # optional: pre-v57 shader for A/B
    python3 tests/cloud_harness/build_harness.py /tmp/cloudgl /tmp/cloudbuild   # compiles the GLSL as C++ (catches typos), links renderer
    /tmp/cloudbuild/harness <name> new|old|lite out.ppm 640 360 camY=90 yaw=20 pitch=10 sunEl=42 sunAz=215 wx=cumulus|fair|broken|overcast|rain|showers|storm sky=day|sunset|night
Needs g++ and the file /tmp/cloudgl/noise48.bin. Not bit-exact with a GPU, but the same maths.
