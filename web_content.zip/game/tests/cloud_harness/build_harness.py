#!/usr/bin/env python3
"""Compiles the generated cloud GLSL as C++ (through a small GLSL shim) and links the CPU renderer in main.cpp.
Catches syntax / type / undeclared-identifier errors in the shaders without a GPU, and renders test frames.
usage: build_harness.py <glsl dir> <build dir>   (glsl dir comes from gen_glsl.mjs; old_cumulus.frag is optional)"""
import re, sys, os, subprocess, itertools
gl_dir, out = sys.argv[1], sys.argv[2]
os.makedirs(out, exist_ok=True)
here = os.path.dirname(os.path.abspath(__file__))

shaders = {n: os.path.join(gl_dir, n + '.frag') for n in ['cumulus', 'cumulus_lite', 'cirrus', 'alto', 'old_cumulus']}
shaders = {k: v for k, v in shaders.items() if os.path.exists(v)}

SW = re.compile(r'\.([xyzwrgba]{2,4})\b')
def convert(txt):
    txt = re.sub(r'precision\s+\w+\s+\w+\s*;', '', txt)
    txt = re.sub(r'\buniform\s+', '', txt)
    txt = re.sub(r'\bvarying\s+', '', txt)
    txt = txt.replace('void main()', 'void shader_main()')
    txt = re.sub(r'\btime\b', 'u_time', txt)
    txt = re.sub(r'\bnear\b', 'nearK', txt)
    sw = set(SW.findall(txt))
    txt = SW.sub(lambda m: '.' + m.group(1) + '()', txt)
    # the shim has no swizzle lvalues: rewrite the one pattern the original shader used
    txt = re.sub(r'(\w+)\.xz\(\)\s*\+=\s*([^;]+);', r'{ vec2 _sw = \2; \1.x += _sw.x; \1.z += _sw.y; }', txt)
    return txt, sw

body = {}; allsw = set()
for name, path in shaders.items():
    t, sw = convert(open(path).read()); body[name] = t; allsw |= sw

idx = {'x': 0, 'y': 1, 'z': 2, 'w': 3, 'r': 0, 'g': 1, 'b': 2, 'a': 3}
vt = {1: 'float', 2: 'vec2', 3: 'vec3', 4: 'vec4'}
def swz_methods(n):
    res = []
    for s in sorted(allsw):
        if max(idx[c] for c in s) < n:
            comps = ', '.join('c[%d]' % idx[c] for c in s)
            res.append('    %s %s() const { return %s(%s); }' % (vt[len(s)], s, vt[len(s)], comps))
    return '\n'.join(res)

def vec_struct(n):
    names = ['x', 'y', 'z', 'w'][:n]; alt = ['r', 'g', 'b', 'a'][:n]
    T = 'vec%d' % n
    s = 'struct %s {\n    union { struct { float %s; }; struct { float %s; }; float c[%d]; };\n' % (
        T, '; float '.join(names), '; float '.join(alt), n)
    # NOTE: anonymous-struct unions give x/r aliasing only if declared per-component; use explicit members + c[] via reference trick
    return None

# explicit, simple definition (components as members; c[] accessed via pointer arithmetic helper)
def make_vec(n):
    T = 'vec%d' % n
    names = ['x', 'y', 'z', 'w'][:n]; alt = ['r', 'g', 'b', 'a'][:n]
    lines = ['struct %s {' % T]
    lines.append('    union { float c[%d]; struct { %s }; struct { %s }; };' % (
        n, ' '.join('float %s;' % v for v in names), ' '.join('float %s;' % v for v in alt)))
    lines.append('    %s() { for (int i = 0; i < %d; i++) c[i] = 0.f; }' % (T, n))
    lines.append('    %s(float s) { for (int i = 0; i < %d; i++) c[i] = s; }' % (T, n))
    if n == 2: lines.append('    vec2(float a, float b) { c[0] = a; c[1] = b; }')
    if n == 3:
        lines.append('    vec3(float a, float b, float d) { c[0] = a; c[1] = b; c[2] = d; }')
        lines.append('    vec3(vec2 v, float d) { c[0] = v.c[0]; c[1] = v.c[1]; c[2] = d; }')
        lines.append('    vec3(float a, vec2 v) { c[0] = a; c[1] = v.c[0]; c[2] = v.c[1]; }')
    if n == 4:
        lines.append('    vec4(float a, float b, float d, float e) { c[0] = a; c[1] = b; c[2] = d; c[3] = e; }')
        lines.append('    vec4(vec3 v, float e) { c[0] = v.c[0]; c[1] = v.c[1]; c[2] = v.c[2]; c[3] = e; }')
    lines.append('    float& operator[](int i) { return c[i]; }')
    lines.append(swz_methods(n))
    lines.append('};')
    return '\n'.join(lines)

ops = []
for n in (2, 3, 4):
    T = 'vec%d' % n
    for op in '+-*/':
        ops.append('inline %s operator%s(const %s& a, const %s& b) { %s r; for (int i = 0; i < %d; i++) r.c[i] = a.c[i] %s b.c[i]; return r; }' % (T, op, T, T, T, n, op))
        ops.append('inline %s operator%s(const %s& a, float b) { %s r; for (int i = 0; i < %d; i++) r.c[i] = a.c[i] %s b; return r; }' % (T, op, T, T, n, op))
        ops.append('inline %s operator%s(float a, const %s& b) { %s r; for (int i = 0; i < %d; i++) r.c[i] = a %s b.c[i]; return r; }' % (T, op, T, T, n, op))
    ops.append('inline %s operator-(const %s& a) { %s r; for (int i = 0; i < %d; i++) r.c[i] = -a.c[i]; return r; }' % (T, T, T, n))
    for op in '+-*/':
        ops.append('inline %s& operator%s=(%s& a, const %s& b) { for (int i = 0; i < %d; i++) a.c[i] %s= b.c[i]; return a; }' % (T, op, T, T, n, op))
        ops.append('inline %s& operator%s=(%s& a, float b) { for (int i = 0; i < %d; i++) a.c[i] %s= b; return a; }' % (T, op, T, n, op))
    ops.append('inline float dot(const %s& a, const %s& b) { float s = 0; for (int i = 0; i < %d; i++) s += a.c[i] * b.c[i]; return s; }' % (T, T, n))
    ops.append('inline float length(const %s& a) { return sqrtf(dot(a, a)); }' % T)
    ops.append('inline %s normalize(const %s& a) { return a / length(a); }' % (T, T))
    for fn in ['exp', 'floor', 'fract', 'abs', 'sqrt']:
        f = {'exp': 'expf', 'floor': 'floorf', 'fract': 'FRACT', 'abs': 'fabsf', 'sqrt': 'sqrtf'}[fn]
        if fn == 'fract':
            ops.append('inline %s fract(const %s& a) { %s r; for (int i = 0; i < %d; i++) r.c[i] = a.c[i] - floorf(a.c[i]); return r; }' % (T, T, T, n))
        elif fn == 'abs':
            continue
        else:
            ops.append('inline %s %s(const %s& a) { %s r; for (int i = 0; i < %d; i++) r.c[i] = %s(a.c[i]); return r; }' % (T, fn, T, T, n, f))
    ops.append('inline %s mix(const %s& a, const %s& b, float t) { return a + (b - a) * t; }' % (T, T, T))
    ops.append('inline %s mix(const %s& a, const %s& b, const %s& t) { %s r; for (int i = 0; i < %d; i++) r.c[i] = a.c[i] + (b.c[i] - a.c[i]) * t.c[i]; return r; }' % (T, T, T, T, T, n))
    ops.append('inline %s clamp(const %s& a, float lo, float hi) { %s r; for (int i = 0; i < %d; i++) r.c[i] = fminf(fmaxf(a.c[i], lo), hi); return r; }' % (T, T, T, n))
    ops.append('inline %s clamp(const %s& a, const %s& lo, const %s& hi) { %s r; for (int i = 0; i < %d; i++) r.c[i] = fminf(fmaxf(a.c[i], lo.c[i]), hi.c[i]); return r; }' % (T, T, T, T, T, n))
    ops.append('inline %s max(const %s& a, float b) { %s r; for (int i = 0; i < %d; i++) r.c[i] = fmaxf(a.c[i], b); return r; }' % (T, T, T, n))
    ops.append('inline %s min(const %s& a, float b) { %s r; for (int i = 0; i < %d; i++) r.c[i] = fminf(a.c[i], b); return r; }' % (T, T, T, n))
    ops.append('inline %s max(const %s& a, const %s& b) { %s r; for (int i = 0; i < %d; i++) r.c[i] = fmaxf(a.c[i], b.c[i]); return r; }' % (T, T, T, T, n))

shim = '''// generated by build_harness.py - GLSL shim for the CPU cloud harness
#pragma once
#include <cmath>
#include <cstdint>
#include <cstring>
#include <vector>
#define abs(x) fabsf(x)
%s
%s
%s
%s
inline float fract(float x) { return x - floorf(x); }
inline float mix(float a, float b, float t) { return a + (b - a) * t; }
inline float clamp(float x, float lo, float hi) { return fminf(fmaxf(x, lo), hi); }
inline float smoothstep(float a, float b, float x) { float t = clamp((x - a) / (b - a), 0.f, 1.f); return t * t * (3.f - 2.f * t); }
inline float step(float e, float x) { return x < e ? 0.f : 1.f; }
inline float max(float a, float b) { return a > b ? a : b; }
inline float min(float a, float b) { return a < b ? a : b; }
inline float sign(float x) { return x > 0 ? 1.f : (x < 0 ? -1.f : 0.f); }
struct mat2 { float m[4]; mat2(float a, float b, float c, float d) { m[0] = a; m[1] = b; m[2] = c; m[3] = d; } };
inline vec2 operator*(const mat2& M, const vec2& v) { return vec2(M.m[0] * v.x + M.m[2] * v.y, M.m[1] * v.x + M.m[3] * v.y); }
struct mat4 { };
inline mat4 operator*(const mat4&, const mat4&) { return mat4(); }
inline vec4 operator*(const mat4&, const vec4& v) { return vec4(v.x * 0.f, 0.f, 0.5f, 1.f); }
struct sampler3D { const uint8_t* data = nullptr; int N = 0; };
struct sampler2D { const uint8_t* data = nullptr; int N = 0; };
inline vec4 texel3(const sampler3D& s, int i, int j, int k) {
    int N = s.N; i = ((i %% N) + N) %% N; j = ((j %% N) + N) %% N; k = ((k %% N) + N) %% N;
    const uint8_t* p = s.data + (((size_t)k * N + j) * N + i) * 4; return vec4(p[0] / 255.f, p[1] / 255.f, p[2] / 255.f, p[3] / 255.f);
}
inline vec4 textureLod(const sampler3D& s, vec3 uv, float) {
    float N = (float)s.N; float x = uv.x * N - 0.5f, y = uv.y * N - 0.5f, z = uv.z * N - 0.5f;
    float fx = floorf(x), fy = floorf(y), fz = floorf(z); float tx = x - fx, ty = y - fy, tz = z - fz;
    int i = (int)fx, j = (int)fy, k = (int)fz;
    vec4 c00 = mix(texel3(s, i, j, k), texel3(s, i + 1, j, k), tx), c10 = mix(texel3(s, i, j + 1, k), texel3(s, i + 1, j + 1, k), tx);
    vec4 c01 = mix(texel3(s, i, j, k + 1), texel3(s, i + 1, j, k + 1), tx), c11 = mix(texel3(s, i, j + 1, k + 1), texel3(s, i + 1, j + 1, k + 1), tx);
    return mix(mix(c00, c10, ty), mix(c01, c11, ty), tz);
}
inline vec4 texel2(const sampler2D& s, int i, int j) {
    int N = s.N; i = i < 0 ? 0 : (i >= N ? N - 1 : i); j = j < 0 ? 0 : (j >= N ? N - 1 : j);
    const uint8_t* p = s.data + ((size_t)j * N + i) * 4; return vec4(p[0] / 255.f, p[1] / 255.f, p[2] / 255.f, p[3] / 255.f);
}
inline vec4 textureLod(const sampler2D& s, vec2 uv, float) {
    float N = (float)s.N; float x = uv.x * N - 0.5f, y = uv.y * N - 0.5f; float fx = floorf(x), fy = floorf(y); float tx = x - fx, ty = y - fy;
    int i = (int)fx, j = (int)fy;
    return mix(mix(texel2(s, i, j), texel2(s, i + 1, j), tx), mix(texel2(s, i, j + 1), texel2(s, i + 1, j + 1), tx), ty);
}
extern vec3 cameraPosition; extern mat4 viewMatrix; extern vec4 gl_FragCoord; extern vec4 gl_FragColor; extern float gl_FragDepth; extern bool gDiscard;
#define discard do { gDiscard = true; return; } while (0)
''' % (make_vec(2), make_vec(3), make_vec(4), '\n'.join(ops))
# the ops reference vec types in order; make_vec(3) uses vec2 and make_vec(4) uses vec3, so declaration order is fine
open(os.path.join(out, 'glsl_shim.h'), 'w').write(shim)

parts = []
for name, t in body.items():
    parts.append('namespace %s {\n%s\n}\n' % (name, t))
open(os.path.join(out, 'shaders_gen.inc'), 'w').write('#include "glsl_shim.h"\n' + '\n'.join(parts))

cmd = ['g++', '-std=c++17', '-O2', '-ffast-math', '-fno-trapping-math', '-w', '-I', out, os.path.join(here, 'main.cpp'), '-o', os.path.join(out, 'harness')]
print(' '.join(cmd)); r = subprocess.run(cmd, capture_output=True, text=True)
sys.stdout.write(r.stdout); sys.stderr.write(r.stderr[:6000])
sys.exit(r.returncode)
