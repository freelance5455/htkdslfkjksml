import { city, S, nat, cols } from './test_citadel.mjs';
import { CityCollider } from '../city_collide.js';
import { valleyHeight, citProfile } from '../valley_sites.js';
const col = new CityCollider(cols), C = S.cit, H = 8.5;
const ground = (x, z) => valleyHeight(S, x, -z, nat(x, z));
const t = city.tunnel, inTun = (x, y, z) => { const s = x * t.tx + z * t.tz, l = -x * t.tz + z * t.tx; if (s < t.sA - 3 || s > t.sB + 3 || Math.abs(l) > t.hw + 2) return false; const yf = t.yT - t.gt * Math.max(0, s - t.sIn), feet = y - H; return feet > yf - 8 && feet < yf + t.ht + 8; };
const N = city.nodes; let fail = 0; const ck = (m, ok) => { if (!ok) { fail++; console.log('FAIL', m); } };
const bfs = (from, to) => { const prev = new Int32Array(N.length).fill(-2); prev[from] = -1; const q = [from]; for (let h = 0; h < q.length; h++) { const a = q[h]; if (a === to) break; for (const b of N[a].adj) if (prev[b] === -2) { prev[b] = a; q.push(b); } } if (prev[to] === -2) return null; const p = []; for (let c = to; c >= 0; c = prev[c]) p.push(c); return p.reverse(); };
const m = { x: N[city.gateNode].x, y: 0, z: N[city.gateNode].z }; m.y = N[city.gateNode].y + H + 0.5;
let cur = city.gateNode, worst = 0;
const walkTo = (id) => {
  const p = bfs(cur, id); if (!p) { ck(`path to ${id}`, false); return false; }
  for (const nid of p.slice(1)) {
    const tx = N[nid].x, tz = N[nid].z; let steps = 0;
    while (Math.hypot(tx - m.x, tz - m.z) > 3 && steps < 400) {
      steps++; const dx = tx - m.x, dz = tz - m.z, l = Math.hypot(dx, dz), px = m.x, py = m.y, pz = m.z; m.x += dx / l * 1.5; m.z += dz / l * 1.5; m.y -= 1.0;
      const r = col.resolve(m, px, py, pz, H, 1.8, 1, 2.4);
      const g = ground(m.x, m.z); if (m.y - H <= g && !inTun(m.x, m.y, m.z)) m.y = g + H;
      if (m.y < -1e4) return false;
    }
    if (steps >= 400) { ck(`stuck walking to node ${nid} (lv ${N[nid].lv}) at ${m.x.toFixed(0)},${m.z.toFixed(0)} y ${m.y.toFixed(1)} want ${N[nid].y.toFixed(1)}`, false); return false; }
    const dy = Math.abs((m.y - H) - N[nid].y); worst = Math.max(worst, dy);
    if (dy > 7) { console.log('  path tail:', p.slice(Math.max(0, p.indexOf(nid) - 8), p.indexOf(nid) + 1).map(i => `${i}(lv${N[i].lv},k${N[i].kind},y${N[i].y.toFixed(0)})`).join(' ')); ck(`node ${nid} lv ${N[nid].lv}: feet ${(m.y - H).toFixed(1)} vs node ${N[nid].y.toFixed(1)}`, false); return false; }
  }
  cur = id; return true;
};
// targets: the gate plaza ring node, then one node on every level, then every spiral top
const pick = (lv) => N.filter(n => n.lv === lv && n.kind !== 5).sort((a, b) => Math.hypot(a.x, a.z) - Math.hypot(b.x, b.z))[3].id;
const order = [3, 4, 5, 3, 2, 1, 0]; let reached = 0;
// first leg: out of the road end, through the tunnel, along the promenade onto the Skyterrace
const tunNode = N.filter(n => n.lv === 3 && n.kind === 2).sort((a, b) => (b.x * t.tx + b.z * t.tz) - (a.x * t.tx + a.z * t.tz)).slice(-1)[0];
if (walkTo(tunNode.id)) { reached++; console.log('walked the whole tunnel + promenade to the Skyterrace ring; worst height error', worst.toFixed(1)); }
for (const lv of order) { if (walkTo(pick(lv))) { reached++; } else break; }
console.log('legs reached', reached, '/', order.length + 1);
ck('all legs', reached === order.length + 1);
console.log(fail ? 'FAIL ' + fail : 'ALL OK'); process.exit(fail ? 1 : 0);
