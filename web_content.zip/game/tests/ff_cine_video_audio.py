import sys, os, subprocess, time, base64
from playwright.sync_api import sync_playwright
srv = subprocess.Popen([sys.executable, '-m', 'http.server', '8767', '--directory', os.path.join(os.path.dirname(__file__), '..')], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(1)
try:
    with sync_playwright() as p:
        b = p.chromium.launch(args=['--no-sandbox'])
        pg = b.new_page(); pg.goto('http://localhost:8767/tests/ff_cine_blank.html'); pg.wait_for_timeout(500)
        b64 = pg.evaluate("async () => await window.mk({}).debug.renderAudioOffline(44100)")
        open('/tmp/ff_audio.s16', 'wb').write(base64.b64decode(b64)); b.close()
finally:
    srv.terminate()
