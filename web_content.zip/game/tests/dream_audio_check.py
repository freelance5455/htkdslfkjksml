# Renders the dream soundtrack offline in headless Chromium (stereo, 44.1 kHz, beds steered by the real timeline) and writes a WAV.
# usage: python3 dream_audio_check.py out.wav [fromSeconds toSeconds]
import sys, os, subprocess, time, base64, wave
from playwright.sync_api import sync_playwright
out = sys.argv[1] if len(sys.argv) > 1 else 'dream_audio.wav'
t0 = float(sys.argv[2]) if len(sys.argv) > 2 else 0
t1 = sys.argv[3] if len(sys.argv) > 3 else 'undefined'
SR = 44100
srv = subprocess.Popen([sys.executable, '-m', 'http.server', '8767', '--directory', os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(1)
try:
    with sync_playwright() as p:
        b = p.chromium.launch(args=['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--no-sandbox'])
        pg = b.new_page(); logs = []; pg.on('console', lambda m: logs.append(m.text)); pg.on('pageerror', lambda e: logs.append('PAGEERR ' + str(e)))
        pg.goto('http://localhost:8767/tests/dream_harness.html'); pg.wait_for_timeout(1500)
        t = time.time(); data = pg.evaluate('window.dream.debug.renderAudioOffline(%d, %s, %s)' % (SR, t1, t0)); print('rendered in', round(time.time() - t, 1), 's')
        raw = base64.b64decode(data)
        with wave.open(out, 'wb') as w: w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(raw)
        print('wrote', out, len(raw) // 4 / SR, 's'); print([l for l in logs][:12]); b.close()
finally:
    srv.terminate()
