// Height map of a lon/lat window: node map_crop.mjs seed lon0 lon1 lat0 lat1 pixelsAcross out.bin
const { TerrainCore } = await import(process.env.TERRAIN_MOD || '../terrain_core.js');   // TERRAIN_MOD=PATH_TO_OLD_terrain_core.js renders another version
import { PLANET_R } from '../planet_core.js';
import fs from 'fs';
const [seed, lon0, lon1, lat0, lat1, W, out] = [+process.argv[2], +process.argv[3], +process.argv[4], +process.argv[5], +process.argv[6], +process.argv[7], process.argv[8]];
const H = Math.round(W * (lat1 - lat0) / ((lon1 - lon0) * Math.cos((lat0 + lat1) / 2 * Math.PI / 180)));
const T = new TerrainCore(seed), a = new Float32Array(W * H * 3), o = {}, D = Math.PI / 180;
for (let j = 0; j < H; j++) { const lat = (lat1 - (j + .5) / H * (lat1 - lat0)) * D, cl = Math.cos(lat), sl = Math.sin(lat);
  for (let i = 0; i < W; i++) { const lon = (lon0 + (i + .5) / W * (lon1 - lon0)) * D;
    const X = cl * Math.sin(lon) * PLANET_R, Y = sl * PLANET_R, Z = cl * Math.cos(lon) * PLANET_R;
    let h = T._terrain(X, Y, Z, 1, o); if (process.env.FULL) h += T._variety(X, Y, Z, h, o).dh;   // FULL=1: add the game's regional variety layer (what the player sees, minus micro relief)
    const k = (j * W + i) * 3; a[k] = h; a[k + 1] = o.ridgeU || 0; a[k + 2] = o.ridgeKind || 0; } }
fs.writeFileSync(out, Buffer.from(a.buffer)); console.log(W, H);
