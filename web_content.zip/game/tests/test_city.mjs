import { TerrainCore } from '../terrain_core.js';
import * as V from '../valley_sites.js';
import { generateCity, planToInstances, planToLife, makeNatGrid } from '../city_core.js';
import { PLANET_R } from '../planet_core.js';
const seed = 424242, T = new TerrainCore(seed), o = {}, d = [0,0,0];
const sites = V.findSites(T, seed).sites;
const rows = [];
for (const S of sites) {
  const t0 = performance.now();
  const nat3 = (x, z) => { V.localToDir(S, x, -z, d); return T.sample3(d[0]*PLANET_R, d[1]*PLANET_R, d[2]*PLANET_R, o); };
  const nat = makeNatGrid(S, nat3, 20);
  const t1 = performance.now();
  const city = generateCity(S, nat);
  const t2 = performance.now();
  const inst = planToInstances(city); const life = planToLife(city);
  // connectivity of street graph from hub
  const N = city.nodes.length, seen = new Uint8Array(N), q = [0]; seen[0] = 1; let c = 1;
  while (q.length) { const a = q.pop(); for (const b of city.nodes[a].adj) if (!seen[b]) { seen[b] = 1; c++; q.push(b); } }
  const reachGate = seen[city.gateNode];
  // overlap check (pairs)
  let ov = 0; const B = city.buildings;
  for (let i = 0; i < B.length; i++) for (let j = i+1; j < B.length; j++) { if (Math.hypot(B[i].x-B[j].x, B[i].z-B[j].z) > 60) continue; const A=B[i], Cc=B[j]; const dx=A.x-Cc.x, dz=A.z-Cc.z; if (Math.hypot(dx,dz) < Math.min(A.w,A.d,Cc.w,Cc.d)*0.5) ov++; }
  const totalInst = Object.values(inst.cats).reduce((s,k)=>s+k.m.length/16,0);
  const hs = B.map(b=>b.floors*b.fh); 
  rows.push([S.id, city.arche, city.palette, city.hubKind, B.length, totalInst, N, `${c}/${N}`, reachGate?'gate✓':'gate✗', Math.max(...hs).toFixed(0), city.stats.towers, city.stats.bridges, 'cont'+city.stats.contours+' mega'+city.stats.megas+' sbr'+city.stats.streetBridges, 'ov'+ov, `nat ${(t1-t0).toFixed(0)}ms gen ${(t2-t1).toFixed(0)}ms`]);
  if (S.id === 0) { const bytes = Object.values(inst.cats).reduce((s,k)=>s+k.m.byteLength+k.c.byteLength,0); console.log('site0 instance bytes', bytes, 'counts', JSON.stringify(inst.counts)); }
}
for (const r of rows) console.log(r.join(' | '));
