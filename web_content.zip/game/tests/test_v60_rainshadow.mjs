// v60: rain shadow check. For high ridge crests, compare rainfall OFF units upwind with OFF units downwind (wind from the existing jet/wind model).
// usage: node test_v60_rainshadow.mjs [seed] [terrain module path]
import { PLANET_R } from '../planet_core.js';
const OFF = +(process.env.OFF || 30000), seed = +process.argv[2] || 424242, mod = process.argv[3] || '../terrain_core.js';
const { TerrainCore } = await import(mod);
const T = new TerrainCore(seed), o = {}, R = PLANET_R, up = [0, 0, 0], dn = [0, 0, 0], r = [0, 0];
let n = 0, wet = 0, dry = 0, ratio = [], shadowN = 0;
const rain = p => { T.rainDir(p[0], p[1], p[2], r); return r[0]; };
for (let j = 0; j < 3000000 && n < 200; j++) {
    const lat = Math.asin(2 * ((j * 0.6180339887) % 1) - 1) * 0.8, lon = (((j * 0.7548776662) % 1) - 0.5) * 6.2831853, cl = Math.cos(lat);
    const X = cl * Math.sin(lon) * R, Y = Math.sin(lat) * R, Z = cl * Math.cos(lon) * R;
    const h = T._terrain(X, Y, Z, 0, o); if (h < 1100) continue;
    const d = [X / R, Y / R, Z / R]; T._stepUpwind(d[0], d[1], d[2], OFF, up); T._stepUpwind(d[0], d[1], d[2], -OFF, dn);
    const hu = T._terrain(up[0] * R, up[1] * R, up[2] * R, 0, o), hd = T._terrain(dn[0] * R, dn[1] * R, dn[2] * R, 0, o);
    if (hu < 5 || hd < 5 || h - hu < 500 || h - hd < 500) continue;      // a true ridge cross-section: the point stands >= 500 above both sides, both on land
    const pu = rain(up), pd = rain(dn); n++; wet += pu; dry += pd; ratio.push(pd / Math.max(1, pu)); if (pd < 0.8 * pu) shadowN++;
}
ratio.sort((a, b) => a - b);
console.log(`seed ${seed}: ${n} crest points | mean rain upwind ${(wet / n) | 0} mm, downwind ${(dry / n) | 0} mm | median lee/windward ratio ${ratio[n >> 1].toFixed(2)} | lee drier by >20% at ${(100 * shadowN / n).toFixed(0)}% of crests`);
