# Hillshaded relief render of a map_crop.mjs dump: python3 -I map_shade.py in.bin W H lon0 lon1 lat0 lat1 out.png [exaggeration]
import sys, numpy as np
from PIL import Image
f, W, H = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]); lon0, lon1, lat0, lat1 = map(float, sys.argv[4:8]); out = sys.argv[8]
ex = float(sys.argv[9]) if len(sys.argv) > 9 else 5.0
R = float(__import__("os").environ.get("PLANET_R", "2367000"))
a = np.fromfile(f, dtype=np.float32).reshape(H, W, 3); h = a[:, :, 0]
latc = np.radians((lat0 + lat1) / 2)
dx = np.radians(lon1 - lon0) * R * np.cos(latc) / W; dy = np.radians(lat1 - lat0) * R / H
gy, gx = np.gradient(h, dy, dx)
az, alt = np.radians(315), np.radians(40)
sl = np.arctan(ex * np.hypot(gx, gy)); asp = np.arctan2(gy, -gx)
shade = np.clip(np.sin(alt) * np.cos(sl) + np.cos(alt) * np.sin(sl) * np.cos(az - asp), 0, 1)
t = np.clip(h / 3600, 0, 1)[..., None]
c = [np.array(x) for x in ([.32, .55, .24], [.62, .56, .34], [.55, .46, .38], [.97, .97, .97])]
land = np.where(t < .15, c[0] + (c[1] - c[0]) * (t / .15), np.where(t < .5, c[1] + (c[2] - c[1]) * ((t - .15) / .35), c[2] + (c[3] - c[2]) * ((t - .5) / .5)))
d = np.clip(-h / 5000, 0, 1)
ocean = np.stack([.03 + .10 * (1 - d), .12 + .40 * (1 - d), .28 + .55 * (1 - d)], -1)
img = np.where((h > 0)[..., None], land * (0.35 + 0.75 * shade[..., None]), ocean * (0.85 + 0.3 * shade[..., None]))
Image.fromarray((np.clip(img, 0, 1) * 255).astype(np.uint8)).save(out); print('ok', out)
