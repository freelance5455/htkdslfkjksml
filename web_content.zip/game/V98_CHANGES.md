# v98 - small touches

- **Forgiving jump:** 0.12 s coyote time (you can still jump just after walking off an edge) and a 0.12 s jump buffer (a tap just
  before landing still jumps). No double jump.
- **Idle breathing:** the camera has a very slow, tiny breathing sway while standing still, so a pause never feels frozen.
- **Sprint vignette:** soft darkening at the screen edges while you run on foot; eases in/out over about a second.
- **Wind rush:** the ambient wind swells with sprint speed and fast falls (the existing wind bed, one extra term).
- **Haptics:** short vibrations on jump, sprint toggle, and heavy landings. Settings > Haptics On/Off (touch devices that support
  vibrate(), i.e. Android browsers; iOS ignores it). Saved with options.
