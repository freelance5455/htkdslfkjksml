# v57 - CLOUD OVERHAUL
NOT run on a GPU: the new GLSL was compiled and rendered through a CPU harness (tests/cloud_harness). If the console shows `[clouds] shader error`, the game already falls back to the lite cumulus shader; report the log.

## Code
Cloud GLSL moved from game.js into **cloud_shaders.js** (noise volume, common GLSL, cumulus slab, cirrus/alto sheets). game.js imports it and passes the 3 sky colours (zenith/mid/horizon) + ground colour as new uniforms.

## Look
- **Real lighting contrast**: the old clouds all rendered at ~0.85-0.9 brightness (flat white). Now multiple-scattering octaves (bright soft interiors, deep self-shadow), a silver-lining lobe near the sun, shaded sides lit by the ACTUAL sky (blue by day, rose/amber at dusk, dim blue at night) plus a muted bounce of the land colour on undersides.
- **Shape**: a ~1 km puff octave in the cloud body (separate billows instead of one lobe), curl-warped three-octave erosion (finest octave only near the camera), erosion calmer with distance (no more confetti), soft translucent edges (less stipple), overcast decks vary in thickness (mottled).
- **Rainbow**: primary + faint secondary bow inside rain shafts the sun reaches, opposite the sun, when it is below ~40 deg.
- Distant clouds pick up sun-side haze. Cirrus gets extra fibre octave, alto an extra ripple octave, both get sunset tinting, sky-coloured shadows, sun glow + silver lining.
- Wet/storm undersides: neutral slate instead of blue.
Cost: about the same march budget; +1 texture fetch per step (puff) and +1 near the camera (finest erosion; skipped in lite).
