# v92 - the ocean crossing rebuilt as cinematic beats
Not playtested in a browser (this environment cannot load three.js). Checked: `node --check game.js`, identifier existence. Please playtest the whole crossing.

## What changed
The crossing used to be minutes of real-time autopilot over empty water. It is now:
1. **Departure shot** (about 9 s, letterbox + title card "THE LONG WATER"): camera starts low on the shore, the boat gathers way, camera cranes up and back as the land shrinks.
2. **Sky time-lapse per leg** (~14 s, letterbox stays up): the camera tips back to look straight up, the sun, moons and stars race across the sky as the ship clock runs forward (a small readout shows clock, hours at sea and % of route, plus three log lines and an omen line), the clouds stream past at up to 45x speed, then the camera tips back down on the new water. The boat is carried to the next stop while you are looking straight up, so the move is never seen. The game clock really advances (7 h, 6 h, 8 h, then on to the next sunrise, so you arrive at dawn). Tap / Space / Enter / E speeds it up.
3. **The stops are unchanged** (storm dive at 25%, wreck + monolith + drone chase at 45%, memorial + disc at 75%), now introduced with title cards. Leaving a stop (Resume) starts the next passage.
4. **Arrival shot at dawn** (about 11 s orbit, title card "AS FAR AS THE WATER GOES"), then the existing arrival line.
- The boat no longer travels in real time; between legs it just rides the swell. A save reloaded mid-crossing starts the next leg by itself.
- The boat can no longer be re-boarded after arrival.

## Reusable cinematic toolkit (in game.js, v92 block)
`cineBars(on)`, `chapterCard(title, sub, kicker, ms)`, `runShot(seconds, (k, dt) => { ...move camera... })`. Shots are driven from `animate()` while the game is paused. Use them for other scenes.

## Tunables
`VOYAGE_LEG_HOURS`, `VOYAGE_LEGS` (card text), in `voyagePassage`: shot length (14 s), `SKY_LAPSE` peak (45), `PITCH_UP` (1.3 rad), `PLACE_K` (when the boat is moved), shot durations in `voyageDeparture` / `voyageArrival`.

`wxStep` now also runs while paused if `SKY_LAPSE` > 0, and scales weather time and cloud drift by `1 + SKY_LAPSE`.

## Time-of-day fixes (second pass)
- **Dusk hold re-armed forever.** `boatQuestActive` stayed true after the voyage ended, so the clock was clamped to 0.749 (dusk) again and the sky could never get past it. It now only applies until the voyage starts (`oceanRoutePlayerT <= 0`). This bug is in v91 too.
- **Each leg now lands at a set time of day** (`VOYAGE_ARRIVE_AT`): storm just after sunrise, wreck in the afternoon, memorial next morning, open ocean at the next dawn. Boarding is still at dusk, so the nights pass inside the time-lapses and every dive is in daylight. Before, the legs were fixed hours from wherever you boarded, which landed the first stop around 01:00.
- The storm-clear line no longer says "sunlight" at night.
- **Sky time-lapse camera** now faces the part of the sky the sun and moons cross (the equator point at your longitude), pitched about 46 degrees, and pans with them from rising to setting. It used to stare at the zenith, which is empty most of the time.

## The clock vs the sky (root cause, third pass)
The sun's spin angle was computed from `lunarDays + dayTime`, but `lunarDays` is a day counter that starts at 0.8 (and the eclipse debug jump sets it to a fraction too). So the sun sat 0.8 of a day away from the clock: at the default start dayTime 0.40 ("morning") the sky was really pre-dawn, noon fell at dayTime 0.7, and every scripted "sunrise" (dayTime 0.24) happened around midnight. Present since the real-sky rewrite (v57). Fix: `skySunLon()` now subtracts `skyPhase()` (the fractional part of lunarDays). Local noon is exactly dayTime 0.5, sunrise/sunset exactly 0.25 / 0.75, for any lunarDays and any longitude. Moons and the giant are positioned relative to the sun, so eclipse and moon-phase timing are unchanged. Verified numerically against `planet_core.js` on 2000 random places and dates (sun above the horizon exactly when dayTime is in 0.25..0.75). Old saves load with their clock unchanged and the sky corrected to match it.
Not changed: within about 5 degrees of a pole the existing "sun fixed in space" rule still lets the local clock drift as you walk.

## Debug: Jump to Chapter (step 1 of the polish pass)
Debug panel (tap the debug button as before) has a new "Jump to Chapter" block: 1 Shelter Built, 2 Flag Raised, 3 Boat Recipe, 4 Boat At Shore, 5 After Voyage. It copies the current world (same seed and face) into a new "DEBUG: ..." save slot with the story flags, inventory and position for that stage, then reloads the page straight into it through the normal Continue path (`applyLoadedSave`). The slot you were playing is untouched. Stand on dry land when you press it. For 4, a coast must be within 4 km of the shelter. Stage 5 puts you a short walk from the shelter with every voyage artifact owned; the Vale note scene plays when you get close. The later beats (hatch, flower mobile, ambush, Vale city) follow naturally from there, and the existing Vale City teleports still work.
Also fixed: a save reloaded after launching the boat but before boarding had no ocean route (only mid-voyage saves stored one), so boarding could not sail. Boarding now charts the route first if it is missing.
Untested in a browser. If a stage looks wrong, tell me which one and what you see.

## Opening-story pass (step 2 of the polish pass)
- **Letterbox bars on every scripted scene.** Whenever `cutsceneActive` is true (not during the wake-up intro or the freefall, which have their own), black bars slide in and subtitles lift above them. One driver, `updateAutoCineBars()`, covers all ~27 dialogue scenes.
- **`focusShot(getTarget, {dur, radius, height, sweep, onFrame})`**: a reusable "look at this" beat. The camera glides from the player's eye to a vantage orbiting the target, holds, and glides back to the exact player view (no snap). Runs while the game is paused, shares the one shot slot with the voyage shots.
- **First night:** title card "THE FIRST NIGHT", you blink awake twice, and the door thud shakes the screen.
- **First sunrise:** title card "FIRST LIGHT" over the existing sunrise camera.
- **Second attack:** title card "THEY'RE BACK" and a shake when the two bigger readings are announced.
- **Shuttle fragment** (boat recipe): the fragment now stays in the world and the camera orbits it while the AI explains, instead of it vanishing and the AI talking over a static view.
- **Boat built:** title card "SEAWORTHY".
- **Boat launch:** the boat drops from 10 units onto the water with a splash and bob while the camera circles it, title card "LAUNCH".
Untested in a browser: camera heights, orbit radii and shot lengths are the first things to tune if something frames badly.

## Scale + floating pass (step 3)
Measured first. Eye height is 8.5 units and a storey is ~17.5 (so the storeys are fine), but the human-scale details were about half size: shelter bed 1.6 units high, desk 1.6, exit door 6; city shopfront 4.4 tall, awning at 8.2, door lamp at 6.5, street lamps 11 high.
- **Shelter interior:** bed ~2x taller, desk and dye table ~2.2x, monitor re-proportioned, exit door ~1.75x taller and wider (now ~10 units), wall clock raised to clear the taller monitor. Interaction points and radii are unchanged. (`rescaleProps` in `buildShelterInteriorMesh`.)
- **City doors:** every building now has a visible doorway (frame + door slab, ~11-12.6 units tall) with a wall lamp bolted above it. Before, the POI "door" had no door at all.
- **City details:** shopfront glow 4.4 -> 9 tall, awning raised to 10.8, street lamps 11 -> 20 high with bigger heads.
- **Floating things:** audited all generated city pieces for support (tests in /tmp not shipped; method: every untilted piece must touch the ground or another piece within 0.9 units). The culprits were the loose 1.4-unit glow cube floating 2.5 units in front of doors (removed, replaced by the wall lamp) and the scrap-bridge lanterns floating 6 units mid-span (now on their own post). Floating pieces went from ~144 to ~6-16 per four cities; what is left is a few thin neon strips and 1-2 overhead wires per city.
- Existing tests still pass (test_city, test_collide, test_runtime, test_life); audit_cities metrics are unchanged within noise.
- **Not changed:** building footprints, street widths and the shelter's outer shell. Scaling those means regenerating the whole city plan (and terrain flattening radii) at a new scale, which needs a real look at it in game first.
