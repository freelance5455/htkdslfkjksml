# v107 - the dream, visuals upgrade (dream_cinematic.js, shader only)

## Step 1 - light in the air
- Light shafts shaped like the real openings: kitchen window, corridor moon windows and doorway glow, the hall's roof opening and far door, the sea's surface rays, the green's low sun through the trees (warm while wild, cold cyan once tidied).
- Floating dust: motes fixed in the world, so they slide with parallax as you walk; brightest inside the beams.
- Glow round every emissive (lines of light, panels, console lamps, the locket), collected during the march.
- Ground mist in the green (the valley recedes in layers). New grade: gentle filmic shoulder, per-scene cool/warm split toning, soft halation.

## Step 2 - each place gets its own light
- Kitchen: warm rim light on furniture and the child from the window; steam rising off the cup on the table.
- Green: fireflies (golden while wild, cyan data-motes once tidied); the tidied ground becomes glossy tile with a sun glint; pillars, slabs and the gate get cyan edge light.
- Corridor: warm rim light on the shelves from the door; the door's reflection runs down the floor.
- Hearing: the ring's light pools on the floor; watchers get cool rim light; wet-floor reflection of the far door.
- Water: caustic light on everything below the surface, fading with depth. Drift: moon-blue rim light and motes.

## Step 3 - the cuts carry their own light
- Eyelid wake: the lid edge catches warm light and red-gold bleeds through the closed lid.
- Sun bloom: an anamorphic streak, a faint star of rays and two lens ghosts build as the sun swallows the window.
- Gate glitch: a bright scan band sweeps the frame, channels slip apart.
- Third blow: gold light leaks through the cracks of the shattering picture; shard edges get a prismatic fringe.
- Plunge: heat blooms at the rim; a pressure ring and a flash of foam run out from the splash.
- Cost: measured against v106 on the same frames (software GL, relative only): about +16% overall (+7% green to +27% water). The existing adaptive render scale still guards slow devices.

## Step 4a - a more painterly paint
- Brush strokes follow each surface (long along the form, short across it), sized to stay similar on screen near and far; each stroke carries its own load of paint and a slight warm/cool tint.
- Dry brush: the paper shows through the brightest lights. Wet edges where one wash meets the next. Outlines pool darker, richer pigment instead of flat grey.
- Skies are brushed in wide washes. The paper itself now has fibres (visible in the lights) and tooth (pigment settles into it in the darks).
- Cost vs v106 (software GL, relative): about +21% overall with steps 1-4a.

## Step 4b - the water ending (modest)
- Marine snow: pale motes drift in the water, brightest where the surface rays fall.
- The small figure gets a soft halo and a faint star of rays as it comes down out of the light (hard to see against the bright opening in stills; judge it in motion).
- Tried and cut: a whale crossing the dark (it vanished into the haze even with the fog cut) and a gold light trail behind the falling locket (it rendered as a dark hairline). Neither is in this build.

Not verified: motion, speed on a phone, the steam (hidden behind the hologram in my test frames), caustics (the sample frame looks up at the surface).
