# v74 - Freefall cinematic rebuild (Phase 1 of 3: foundation)
- Seven shots with a hard cut to black between each (no fades): leaving the moon, deep space, midway, swinging round the giant, closing in, skimming the clouds, the plunge. About 145 s, skippable as before.
- One shared space scene: the moon and the giant exist at real distances (the same in-game giant shader), so both are visible together and shrink/grow as the ship moves. The ship follows curved paths.
- The cockpit is now a real raytraced 3D room (window with a strut, side ports, dash with screens and LEDs, cracked glass). The pilot's head wanders, glances sideways, and the eyelids droop and close, so the view is never centred and only glimpses get through.
- Sun direction is derived from the flight path so the lift-off is in daylight and the approach side of the giant is lit.
- Same API as v73 (createFreefallCinematic, play, skip), so game.js is unchanged.
- Still the v73 stand-in: the cloud interior and the crash (Phase 2), game-accurate moon look and audio retiming (Phase 3).

## Revision 2 (phases 1+2 merged)
- Final flash now whites out the whole screen (cockpit included), then cuts to black.
- Vision starts blurry/unfocused and the head wanders; each shot the pilot then locks onto something (moon/giant/ahead), tightens focus, and leans toward the glass. Shake is small and only builds in the crash, with a jolt per lightning strike.
- Removed the screen-fixed orange/white speck layer (the "debris" overlay) that moved with the camera.
- Shots are about 30% longer (~185 s) and start well after the previous one ended; each shot's speed only increases until the cut (no easing out).
- Scale: the approach to the giant is gradual (about 3 giant-radii out down to cloud-top height over four shots), then the ship sinks through cloud tops into a dense, rough, orange volumetric cloud interior with lightning, turning red as it crashes.
- Audio: quieter master, lower rattle/roar/thunder/alarm levels in the last shot.

## Revision 3
- Turbulence/shake/heat/rumble/rattle now exist ONLY inside an atmosphere: the first seconds over the moon, and the final plunge, building with the air's density. Shots 2-6 (vacuum) are smooth, with no creaks or rattling; only the engine hum and the pilot's own drifting head.
- The final plunge is steep (nose down) and the clouds now stream toward the ship (before, they streamed away, which read as leaving the clouds). Speed keeps rising to the cut.
- Bigger giant: radius 40 moon-radii (was 16), so it fills the view on approach. Ship roll/tumble is much slower so the bodies feel massive instead of toy-like.

## Revision 4
- The pilot's gaze is aimed at the giant (or the moon, only in the first seconds of shot 2 while it is still beside the ship) instead of drifting into dark corners; the "lost" phase is short and stays around the windows.
- Stronger scale progression across shots: the giant is about 300 moon-radii away at first (a small disc in a side port), then 90-130 units out, then swings round and grows shot by shot until it fills the windows; the ship covers more ground per second in the later shots.

## Revision 5
- The sky in space is now the game's own night sky: its Milky Way (dust lanes, nebulae), Andromeda, six layers of coloured twinkle-free stars and the wandering stars, ported straight from game.js's sky shader (renamed to avoid clashes). Replaces the earlier simple star field.

## Revision 6
- The giant's size now matches the game's sky (radius 11000 at distance 46000, about 13.8 degrees across from the moon's surface); earlier revisions had it about half that size at the start. It then grows shot by shot as the ship approaches.

## Revision 7
- No more exponential speed-up: the climb off the moon is a steady, slow quadratic-ish rise (the moon stays huge and fills the view for most of shot 1), and every other shot's acceleration exponent is now gentle (1.15-1.3 instead of 1.4-1.8). Distances covered per shot are smaller, so the bodies shrink and grow slowly, like real massive objects.
