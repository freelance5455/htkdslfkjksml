# v112 - THE LEVIATHAN, the corridor console (on top of v111)

## Fixes
- **Kick button stayed on screen** after the kick. The prompt/button were never re-evaluated once the kick began; they now hide at once (`levClearInteract`) and stay hidden.
- **The AI's blue ball never showed inside the Leviathan.** The orb only turned on in the very first boot sequence, so after any reload (or a debug jump) it never appeared anywhere. It is now switched on when a save loads and when you enter the Leviathan.

## New: the door is no longer "walk up and try it"
1. You walk down the corridor and the AI talks: it says it will try the local network, probes (a small chip under the compass shows `LOCAL NETWORK - probing`, `handshake`, `LOCAL ACCESS - partial`), gets local access, and finds a service console on the south wall.
2. It marks the console: your camera swings round to point at it, a diamond appears on the compass strip (with an arrow at the edge when it is out of view) and on screen (label + distance), and a cyan beam rises from the console.
3. Walk up, press **Hack**. The camera steps up to the screen; the AI bridges in; the screen floods with script nobody can read. The AI: "You know what? You can't possibly figure this out. How about we just break it?"
4. A **Break** button appears. Press it: the screen cracks, sparks, blackout, the alarm cuts out, then every lamp, status panel and the corridor light turn green. The door is marked (compass, on-screen symbol, green beam) and the camera swings to it.
5. **Open** the door: the two halves slide apart, the passage behind lights up green. Walking through ends this version (card, back to the shelter), as before.
- The old "Try the blast door" -> "to be continued" is gone. "Try the door" before the console is done just gets a short AI line.

## New: the view outside the windows
The backdrop is no longer just swirling gas. The Leviathan now drifts through the storm on a 100 s cycle:
- **Immersed** (about 23 s): the old swirling gas on every side.
- **Rising** (10 s): it lifts out of the cloud tops.
- **Clear** (about 55 s): a sea of cloud tops running to the horizon below (seen in perspective, lit from the sun's side, hazing out at the horizon), the open atmosphere above (amber at the horizon, dusk violet overhead, high streaks, a few stars, the sun's glare) and **the tiny moon** (a small lit disc with ocean, land, cloud and a thin blue rim). Look east out of the bay windows, a little above the horizon and slightly to the right of straight ahead.
- **Sinking** (12 s) back into the cloud. The bay's sunlight is a little stronger while the sky is clear.
- Debug: `leviathanDebug.sky(1)` forces clear, `sky(0)` forces immersed, `sky(null)` returns to the cycle. Timings: `SKY` at the top of `leviathan_core.js`; moon size/direction: `uMoonDir` and `r` in `moonDisc`.
- Not verified without a GPU: the shader has never been compiled. If it fails you get a flat storm colour and `[leviathan] shader "storm" failed` in the console; please send me that line.

## Files
- `leviathan_hack.js` (new): console, screen textures, marker beam, door panels, the passage behind the door, state machine (`idle > found > hacking > garbled > breaking > unlocked > opening > open`), power/lighting changes. No custom shaders.
- `leviathan_core.js` (small): door panels removed from the static batch (the frame stays), `export Batch`, `audio.tone`, `emitSpark` exposed, `zone:beyond`, zones reset on re-entry, door interaction removed.
- `game.js` (Leviathan block): corridor script, camera turns, compass + on-screen marker, network chip, Hack/Break/Open actions, kick and orb fixes, saves.
- `styles.css`: marker and chip styles. `index.html`: two new debug buttons.

## Saves
`leviathanStage`: 3 corridor (the script replays), **4 console broken, door unlocked** (resume with green lights, door marked), **5 door open**, 9 finished.

## Debug
Chapter buttons: "8 Leviathan: Corridor (hack)" and "9 Leviathan: Door unlocked". Console: `leviathanDebug.hackState('idle'|'found'|'unlocked'|'open')`.

## Tests run here (no GPU)
- `tests/test_v112_hack.mjs` (24 checks): geometry integrity, draw calls (+18), lights (7), collision, state machine, timings (break 3.4 s, door 2.8 s), blackout/alarm/green, resume states, pause, idle looks like v111.
- `tests/test_v112_glue.mjs` (18 checks): runs the real Leviathan block of game.js with mocked browser globals and plays the whole sequence, plus the kick-button fix.
- `test_v111_leviathan.mjs` (updated) and `test_v91_phase2.mjs` still pass.

## NOT verified (no GPU)
How it looks and sounds: console and screen glyphs, beam brightness, the green colour balance, blackout length, marker placement on a phone screen, audio levels, speech length of the lines (the AI's voice is slow, so the pre-console talk takes roughly a minute). Tunables: timings in `TIMELINE`/`HACK` at the top of `leviathan_hack.js`; line text in `levCorridorScript` / `levDoHack` / `levDoBreak` in `game.js`.
