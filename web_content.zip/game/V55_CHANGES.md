# v55 - bigger buildings, a fused walled-city mass, farmland domes, walls that hug the city, graded wild edge (NOT run in a browser/GPU; verified headless: tests/test_v55.mjs + all older tests)

## Scale ("my height is over two windows")
- Footprints were ~15 units (3.7 m) wide and a floor 11 units (2.6 m) with a 8.5-unit player. Now: lots ~2.2x, floors 17-18.4 units, windows one row per floor and about player height (shader cell 11 x 17.5).
- Streets wider (base 20-26), level step, node spacing, hub (420-720 tall, wider footprint, bigger plaza + flat hub ground 84), gate (x1.5), lamps (11 high), bridge rails/posts taller, towers 18-48 floors, mega stacks 34-62.
- Fewer, bigger buildings per city (~200-650 instead of 800-2100).

## Kowloon / Walled-City feel
- Solid link blocks between neighbouring buildings: over a street they start 5-9 floors up (covered streets, sky mostly hidden), elsewhere they run to the ground (fused mass). 36-190 per city.
- Many more skybridges (240 cap, longer, wider), tighter lot packing, more wires. Street nodes now sit ON the street surface.

## Farmland domes (enterable)
- 3-6 per city (when the land allows), chosen BEFORE the streets so streets route around them, just inside the outline. Glass dome on ribs, airlock tunnel, solid podium, ramp up from the ground, beds / orchard rows, grow-lights, central mast.
- Collision: a shell of stacked wall bands with a gap only at the tunnel; headless test walks into every dome.
- New instance category `glassDome` (translucent material in city_runtime.js).

## Walls and outlines
- Wall radius follows where buildings/domes REALLY end (per-direction table + 13 units), not the nominal footprint edge. Wall sectors keep buildings up to the wall. Walls taller (36), towers bigger.
- Trees/rocks/grass: hard cut replaced by a graded clearing (valley_sites.js clearP): fully clear in the built core, thinning out past the city edge. Plus up to ~260 generated trees and rocks standing in gaps among the outer buildings.

## Floating
- Lamps now have poles that reach the real ground; gate pylons/huts have foundations; flags and barricade stakes sunk; plaza slab sunk 14; foundations 3-9 units deeper.
- If something still floats, send a screenshot + distance (likely the coarse far terrain LOD).

## Files: city_core.js, city_runtime.js, valley_sites.js, chunk_core.js, tests/test_v55.mjs (new), tests/test_chunks.mjs, tests/measure_v55.mjs (new)
Saved games: city layouts change (economy state still loads).
