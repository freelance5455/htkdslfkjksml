# v50 - valleys that follow the land, cities that follow the valleys

Before: every Vale valley was a stamped bowl (flat circle + rising walls, only wobbled in v48), so the terrain was made for the city.
Now the valley is derived from the natural ground and the city is laid out against whatever floor that gives.

## valley_sites.js
- Sites slide downhill into the nearest natural hollow (settleDir, two passes) before they are measured.
- `shapeSite()` gives each kept site three 64-entry tables around its centre:
  - `ft` floor radius: limited by a smooth random lobe (bays, necks, fingers) and by the real ground (the floor stops where natural terrain climbs out of the floor level; it runs on along natural gullies). Floor outline max/min radius is about 2.2x on average (was 1.2x in v49).
  - `wr` wall rise, `ww` wall width: broad ramps in some directions, steep faces in others.
- Floor level follows the local ground (median of the natural height inside the floor) instead of the median of a 1000-unit ring, so a valley on a rise is not dug into the hill.
- Walls only ADD earth where the natural ground is lower than the enclosing wall; higher natural ground (cliffs, ridges) is kept. Added earth fades back to natural by Rb.
- The pass is re-picked from the real floor edge: the direction whose natural ground needs the gentlest walk out (`passR` = floor radius there).
- Sites are re-centred on the centroid of their floor (up to 3 passes) so the hub is not at the end of a long tongue.
- API: `floorRadius`, new `rimRadius`, `clearHere`; `cityWeight` and `ValleyField.clearAt` use the irregular floor / rim. `S.Rf` is now the MEAN floor radius, `S.Rmin` the smallest, `S.Rbase` the nominal one.

## city_core.js
- All four layouts run to the LOCAL floor edge: radial ring k sits at k/rings of the local floor radius (rings stretch into bays and pinch at necks); grid and fishbone extend until they hit the edge; organic points are sampled over the real outline; skyline and districts are scaled by the local radius.
- Terraces start at the local edge and follow the natural contour to the local rim (128 rays, bigger jump tolerance).
- NEW climber streets (5-12 per city): from the floor edge each street picks, step by step, the heading that gains the most height under a street grade (0.33-0.45); when the wall is too steep it bends sideways and contours (switchbacks); it joins any terrace or street it meets. Frontage lots then line these streets, so the city climbs the walls along the gentle spurs.
- Frontage and infill use the local floor edge / rim; landmarks are placed relative to the local edge.

## city_roads.js: the road leaves through the pass at `passR`.
## tests/test_chunks.mjs: floor and clear-footprint checks use the irregular floor edge.

## Measured (seed 424242, 33 sites)
- Floor p99 slope 0.09 (was 0.08), wall/outside p99 slope 1.62 (was 1.74), floor relief 2.2 units, enclosure 90-100% of directions.
- Average 1173 buildings per city (was 1239), 0 overlaps, every street graph fully connected and reaching its gate.
- test_sites / test_chunks / test_city / test_sim / test_life / test_roads2 / test_runtime pass.
- Site search is slower: about 3.0-3.8 s cold in Node (was 2.0-2.8 s).
- Checked with top-down plan renders from the real terrain + generator; NOT checked in a browser.
- Saved games / existing seeds: sites move and valleys change shape.
