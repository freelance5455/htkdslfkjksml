# v58 - PERFORMANCE PASS + LONGER INTRO
Not run on a GPU (no browser/GPU in the build environment). The cloud change was verified by rendering the old and new GLSL through the CPU harness: output is byte-identical.

## Performance (no resolution change, no visual change)
- **Cloud march (cloud_shaders.js)**: cloud geometry/size is computed once per march step instead of once per density tap (about 10 times per step). Empty-sky steps (no cloud, no anvil, no rain) now skip the noise fetches entirely. Same pixels as v57.
- **Sun shadow blur (game.js, updateEnvironment)**: the VSM blur runs twice over the 4096x4096 shadow map every frame with 20 taps even at small radii, where taps were under 1 texel apart. Taps now scale with the blur radius (8-20, ~1.6 texel spacing): same soft edge, roughly half the blur cost at the usual radii.

## Loading / intro
- Loader progress can no longer outrun an 8 s ramp (LOADER_MIN_LOAD_MS), so the satellites fill at a readable pace.
- Credits ("Set in the same universe..." / "Created By Majrik Zaffran"): start 1.4 s after load (was 0.6), second line 1.3 s later (was 0.5), both hold 6.2 s (was 2.2).
- Logo hold before the zoom: 2.8 s (was 1.3).
- Total: roughly 10-12 s longer than v57. Tap/key still skips the credit and logo holds.

## Bug fix found while testing in a browser: credits were being skipped for everyone
The "tap/key skips the credit and logo holds" listener was live from page load, so the clicks on Continue / New Game / Begin set the skip flag before loading even started. Every hold was skipped for every player, which is why the credits flashed past. Skip is now armed only once the credits begin. Headless timeline after the fix: loader 100% at ~9 s, credits visible ~7 s, logo, then zoom.
