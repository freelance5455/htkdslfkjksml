// =====================================================================================
// city_sim.js - drone movement / routine / chatter simulation for ONE city (pure logic; tested headless).
// Works in the city's chart-independent PLAN space (x east, z south, y world height). The runtime (city_runtime.js) only renders it.
// Only active while the player is near (the runtime creates a CitySim on approach and drops it when the player leaves) and capped.
// v53: drones no longer stack up and march in file.
//   * every drone walks in its OWN LANE beside the street's centre line (right-hand traffic: opposite flows take opposite sides) and
//     stops on its own spot around a destination, so two drones never share a line or a standing point
//   * hard body separation (the body is ~5.4 units wide): neighbours steer apart, a drone slows behind one in front of it
//   * every drone keeps its own agenda: after each stop it picks a new destination (errand to another workplace, plaza, shop, a bridge or
//     lookout, a random corner of town, a visit to a friend) instead of drifting back to one node; the day routine only decides the mix
//   * A* with a heap (the streets now climb the slopes and carry ~1000 nodes)
// =====================================================================================
import { mulberry } from './valley_sites.js';
import { slotOf, slotGoal, ambientLine, chatterPair, greeting, JOBS } from './city_life.js';

class Heap {
    constructor() { this.a = []; }
    push(k, v) { const a = this.a; a.push([k, v]); let i = a.length - 1; while (i > 0) { const p = (i - 1) >> 1; if (a[p][0] <= a[i][0]) break; [a[p], a[i]] = [a[i], a[p]]; i = p; } }
    pop() { const a = this.a, top = a[0], last = a.pop(); if (a.length) { a[0] = last; let i = 0; for (;;) { const l = 2 * i + 1, r = l + 1; let m = i; if (l < a.length && a[l][0] < a[m][0]) m = l; if (r < a.length && a[r][0] < a[m][0]) m = r; if (m === i) break; [a[m], a[i]] = [a[i], a[m]]; i = m; } } return top; }
    get size() { return this.a.length; }
}
export class Nav {
    constructor(life) {
        this.life = life; const N = life.nodes.length / 4; this.N = N; this.multi = !!(life.meta && life.meta.multiLevel); this.adj = Array.from({ length: N }, () => []); this.wm = new Map();
        for (let i = 0; i < life.edges.length; i += 2) { const a = life.edges[i], b = life.edges[i + 1], w = life.ew ? life.ew[i / 2] : 10; this.adj[a].push(b); this.adj[b].push(a); this.wm.set(a * 65536 + b, w); this.wm.set(b * 65536 + a, w); }
        this.cache = new Map(); this.cell = 40; this.grid = new Map();
        for (let i = 0; i < N; i++) { const k = this._k(life.nodes[i * 4], life.nodes[i * 4 + 2]); let l = this.grid.get(k); if (!l) this.grid.set(k, l = []); l.push(i); }
    }
    _k(x, z) { return Math.floor(x / this.cell) * 100003 + Math.floor(z / this.cell); }
    x(i) { return this.life.nodes[i * 4]; } y(i) { return this.life.nodes[i * 4 + 1]; } z(i) { return this.life.nodes[i * 4 + 2]; }
    width(a, b) { return this.wm.get(a * 65536 + b) || 10; }
    nearest(x, z, y) {
        const n = this.life.nodes, c = this.cell, ML = this.multi && y !== undefined; let b = -1, bd = 1e30;
        for (let r = 1; r <= 6 && b < 0; r++) {   // widen the ring of cells until something is found, then verify with the next ring
            for (let i = -r; i <= r; i++) for (let j = -r; j <= r; j++) { const l = this.grid.get((Math.floor(x / c) + i) * 100003 + Math.floor(z / c) + j); if (!l) continue; for (const k of l) { const d = (n[k * 4] - x) ** 2 + (n[k * 4 + 2] - z) ** 2 + (ML ? ((n[k * 4 + 1] - y) * 4) ** 2 : 0); if (d < bd) { bd = d; b = k; } } }
        }
        if (b < 0) { for (let i = 0; i < this.N; i++) { const d = (n[i * 4] - x) ** 2 + (n[i * 4 + 2] - z) ** 2; if (d < bd) { bd = d; b = i; } } }
        return b < 0 ? 0 : b;
    }
    path(a, b) {
        if (a === b) return [a];
        const key = a * 65536 + b, c = this.cache.get(key); if (c) return c;
        const dist = new Map([[a, 0]]), prev = new Map(), h = new Heap(); h.push(0, a); const bx = this.x(b), bz = this.z(b);
        while (h.size) {
            const [f, u] = h.pop(), du = dist.get(u); if (u === b) break;
            if (f - Math.hypot(this.x(u) - bx, this.z(u) - bz) > du + 1e-3) continue;
            for (const v of this.adj[u]) { const d = du + Math.hypot(this.x(u) - this.x(v), this.z(u) - this.z(v)) + Math.abs(this.y(u) - this.y(v)) * 2.5; if (d < (dist.get(v) ?? 1e30)) { dist.set(v, d); prev.set(v, u); h.push(d + Math.hypot(this.x(v) - bx, this.z(v) - bz), v); } }
        }
        const out = []; if (!prev.has(b)) out.push(a); else { for (let v = b; v !== undefined; v = prev.get(v)) out.push(v); out.reverse(); }
        if (this.cache.size > 4000) this.cache.clear(); this.cache.set(key, out); return out;
    }
}
const SEP = 6.2;   // two drone bodies (~5.4 wide) must not overlap

export class CitySim {
    constructor(life, residents, opts) {
        this.life = life; this.nav = new Nav(life); this.res = residents; this.cityName = opts.cityName; this.maxDrones = opts.maxDrones || 64;
        this.r = mulberry(opts.seed ^ 0x51a1); this.drones = []; this.chatT = 1.5; this.bubbles = 0; this.maxBubbles = opts.maxBubbles || 7; this.solid = opts.solid || null;
        this.ctx = { machineDestroyed: false, night: false, cityName: this.cityName };
        const nav = this.nav, P = life.poi;
        this.homeNode = (res) => res.home >= 0 && P.homes[res.home] ? nav.nearest(P.homes[res.home].door[0], P.homes[res.home].door[1], P.homes[res.home].y) : 0;
        const byKind = (k) => P.works.filter(w => w.kind === k);
        const nodesOf = (arr) => arr.map(o => nav.nearest(o.door ? o.door[0] : o.x, o.door ? o.door[1] : o.z, o.y));
        this.workNodes = { dock: nodesOf(P.docks), workshop: nodesOf(byKind('workshop')), office: nodesOf(byKind('office')), tank: nodesOf(byKind('tank')), shop: nodesOf(P.shops) };
        this.viewNodes = nodesOf(P.views || []);
        const px0 = P.plazas[0] ? P.plazas[0].x : 0, pz0 = P.plazas[0] ? (P.plazas[0].z || 0) : 0, pr = P.plazas[0] ? (P.plazas[0].r || 40) : 40;
        const sp = []; for (let k = 0; k < 14; k++) { const a = k * 2.399, rr = pr * (0.3 + 0.7 * ((k * 0.37) % 1)); sp.push(nav.nearest(px0 + Math.cos(a) * rr, pz0 + Math.sin(a) * rr, P.plazas[0] ? P.plazas[0].y : undefined)); }
        this.workNodes.plaza = [...new Set([0, ...sp])];
        this.anyWork = [].concat(this.workNodes.shop, this.workNodes.workshop, this.workNodes.office, this.workNodes.dock);
        // streets that are narrow carry fewer lanes; precompute nothing else - lanes are per drone
    }
    goalNode(res, goal) {
        if (goal.kind === 'home') return this.homeNode(res);
        if (goal.kind === 'plaza') { const a = this.workNodes.plaza; return a[res.seed % a.length]; }
        if (goal.kind === 'wander') return (res.seed >>> 3) % this.nav.N;
        const job = JOBS.find(j => j.id === res.job); let arr = this.workNodes[job.place]; if (!arr || !arr.length) arr = this.anyWork.length ? this.anyWork : [0];
        return arr[res.workIdx % arr.length];
    }
    _rn(n) { return Math.floor(this.r() * n); }
    // a fresh destination for a drone, from its slot: the routine decides the mix, never a single fixed node
    pickDest(d, slot) {
        const nav = this.nav, r = this.r(), N = nav.N, cur = nav.nearest(d.x, d.z, d.y), pick = (a) => a.length ? a[this._rn(a.length)] : -1;
        let g = -1;
        if (slot === 'sleep') g = this.homeNode(d.res);
        else if (slot === 'commuteWork') g = this.goalNode(d.res, { kind: 'work' });
        else if (slot === 'commuteHome') g = this.homeNode(d.res);
        else if (slot === 'work' || slot === 'work2') {
            if (r < 0.4) g = this.goalNode(d.res, { kind: 'work' }); else if (r < 0.65) g = pick(this.anyWork); else if (r < 0.8) g = pick(this.workNodes.plaza); else g = this._near(cur, 140);
        } else if (slot === 'lunch') { if (r < 0.55) g = pick(this.workNodes.plaza); else if (r < 0.85) g = pick(this.workNodes.shop); else g = this._near(cur, 120); }
        else {   // evening
            if (r < 0.28) g = pick(this.workNodes.plaza); else if (r < 0.5) g = pick(this.viewNodes); else if (r < 0.65) g = pick(this.workNodes.shop); else if (r < 0.8) { const o = this.drones[this._rn(this.drones.length)]; g = o && o !== d ? nav.nearest(o.x, o.z, o.y) : -1; } else g = this._rn(N);
        }
        if (g < 0) g = this._rn(N);
        // do not pick a spot another drone is already standing at
        for (let t = 0; t < 3; t++) { let taken = false; for (const o of this.drones) if (o !== d && Math.hypot(nav.x(g) - o.x, nav.z(g) - o.z) < SEP * 1.5) { taken = true; break; } if (!taken) break; g = this._near(g, 100); }
        return g;
    }
    // a random node within `rad` of node n (walk a few edges)
    _near(n, rad) { const nav = this.nav; let c = n; for (let k = 0, steps = 2 + this._rn(6); k < steps; k++) { const nb = nav.adj[c]; if (!nb.length) break; const nx = nb[this._rn(nb.length)]; if (Math.hypot(nav.x(nx) - nav.x(n), nav.z(nx) - nav.z(n)) > rad) break; c = nx; } return c; }
    _go(d, g) { const nav = this.nav, cur = nav.nearest(d.x, d.z, d.y); d.goalNode = g; d.path = nav.path(cur, g); d.pi = d.path.length > 1 ? 1 : 0; d.leg = -1; if (d.path.length > 1) d.state = 'walk'; else { d.state = 'idle'; d.idleT = 1 + this.r() * 3; } }
    // place a drone where its routine says it is "now"
    spawnAt(res, dayTime, i) {
        const { slot } = slotOf(dayTime, res.shiftShift), nav = this.nav, r = this.r;
        const d = { res, x: 0, y: 0, z: 0, yaw: r() * 6.28, slot, goalNode: 0, path: [0], pi: 0, state: 'idle', idleT: r() * 6, bubble: null, bobPh: r() * 6.28, asleep: slot === 'sleep', greetT: 0, talk: false, cargo: false,
            lane: (0.12 + r() * 0.3) * (r() < 0.5 ? 1 : -1), speedK: 0.8 + r() * 0.45, leg: -1, spot: [(r() - 0.5) * 5, (r() - 0.5) * 5], vx: 0, vz: 0 };
        const start = slot === 'sleep' ? this.homeNode(res) : this._rn(nav.N);   // awake drones start scattered over the whole town, not queued at their jobs
        d.x = nav.x(start) + d.spot[0]; d.z = nav.z(start) + d.spot[1]; d.y = nav.y(start); d.goalNode = start;
        if (!d.asleep) { this._go(d, this.pickDest(d, slot)); } return d;
    }
    activate(dayTime) { this.drones.length = 0; for (let i = 0; i < Math.min(this.maxDrones, this.res.length); i++) this.drones.push(this.spawnAt(this.res[i], dayTime, i)); }
    say(d, text, dur = 3.6) { if (d.bubble) return false; if (this.bubbles >= this.maxBubbles) return false; d.bubble = { text, t: dur }; this.bubbles++; return true; }
    step(dt, dayTime, night, machineDestroyed, player) {
        this.ctx.night = night; this.ctx.machineDestroyed = machineDestroyed;
        const nav = this.nav, D = this.drones;
        for (const d of D) {
            const s = slotOf(dayTime, d.res.shiftShift);
            if (s.slot !== d.slot) { d.slot = s.slot; d.asleep = false; if (!d.talk) this._go(d, this.pickDest(d, s.slot)); }
            if (d.bubble) { d.bubble.t -= dt; if (d.bubble.t <= 0) { d.bubble = null; this.bubbles = Math.max(0, this.bubbles - 1); } }
            d.bobPh += dt * 2.2;
            if (d.talk) { d.state = 'idle'; if (player) d.yaw = Math.atan2(player.x - d.x, player.z - d.z) - Math.PI / 2; continue; }
            if (d.state === 'walk') {
                const tgt = d.path[d.pi]; if (tgt === undefined) { d.state = 'idle'; continue; }
                // the point to steer to: the node, shifted into this drone's lane (right-hand traffic: the lane flips with the direction of travel)
                const prevN = d.path[Math.max(0, d.pi - 1)], ax = nav.x(prevN), az = nav.z(prevN), bx = nav.x(tgt), bz = nav.z(tgt);
                let ex = bx - ax, ez = bz - az; const el = Math.hypot(ex, ez) || 1; ex /= el; ez /= el;
                const w = nav.width(prevN, tgt), lat = d.lane * Math.min(w, 22) * 0.5, last = d.pi === d.path.length - 1;
                let tx = bx + (-ez) * lat, tz = bz + ex * lat; if (last) { tx = bx + d.spot[0]; tz = bz + d.spot[1]; }
                const dx = tx - d.x, dz = tz - d.z, dist = Math.hypot(dx, dz), commute = s.slot.startsWith('commute');
                let sp = d.res.speed * d.speedK * (commute ? 2.6 : 1.4);
                // queueing: slow down for a drone just ahead
                let ahead = 1; for (const o of D) { if (o === d) continue; const ox = o.x - d.x, oz = o.z - d.z, q = ox * ox + oz * oz; if (q > 100) continue; if ((ox * dx + oz * dz) / (Math.sqrt(q) * dist + 1e-6) > 0.7) ahead = Math.min(ahead, Math.sqrt(q) / 10); }
                sp *= Math.max(0.35, ahead);
                if (dist < 1.6) { d.pi++; if (d.pi >= d.path.length) { d.state = 'idle'; d.idleT = 2 + this.r() * 7; d.asleep = d.slot === 'sleep'; d.spot = [(this.r() - 0.5) * 6, (this.r() - 0.5) * 6]; } }
                else { const k = Math.min(dist, sp * dt) / dist; d.x += dx * k; d.z += dz * k; d.y += (nav.y(tgt) - d.y) * Math.min(1, dt * 3); d.yaw = Math.atan2(dz, dx) * -1; }
            } else {
                d.idleT -= dt;
                if (d.idleT <= 0 && !d.asleep) {   // done standing: a new errand (the routine only shapes the mix)
                    d.idleT = 3 + this.r() * 5;
                    if (d.slot === 'sleep') { const home = this.homeNode(d.res); if (Math.hypot(nav.x(home) - d.x, nav.z(home) - d.z) > 8) this._go(d, home); else d.asleep = true; }
                    else if (this.r() < 0.85) this._go(d, this.pickDest(d, d.slot)); else d.yaw += (this.r() - 0.5) * 1.6;
                }
            }
            // player nearby: greet (once per ~45 s)
            if (player) { d.greetT -= dt; const pd = Math.hypot(player.x - d.x, player.z - d.z); if (pd < 17 && d.greetT <= 0 && !d.asleep && !d.bubble) { if (this.say(d, greeting(d.res, this.ctx, this.r), 4.2)) { d.greetT = 45; if (d.state === 'idle') d.yaw = Math.atan2(player.x - d.x, player.z - d.z) - Math.PI / 2; } } }
        }
        // body separation: neighbours steer apart (hard minimum SEP); sleepers and talkers stay put, the others yield to them
        for (let i = 0; i < D.length; i++) { const a = D[i];
            for (let j = i + 1; j < D.length; j++) { const b = D[j];
                let dx = b.x - a.x, dz = b.z - a.z; const q = dx * dx + dz * dz; if (q >= SEP * SEP) continue;
                let dist = Math.sqrt(q); if (dist < 0.01) { const an = (i * 2.399 + j) % 6.283; dx = Math.cos(an); dz = Math.sin(an); dist = 0.01; }
                const push = (SEP - dist) * Math.min(1, dt * 6), ux = dx / dist, uz = dz / dist, af = a.asleep || a.talk, bf = b.asleep || b.talk;
                if (af && bf) continue; const wa = af ? 0 : bf ? 1 : 0.5, wb = bf ? 0 : af ? 1 : 0.5;
                a.x -= ux * push * wa; a.z -= uz * push * wa; b.x += ux * push * wb; b.z += uz * push * wb; } }
        // v54: hard walls - a drone is never inside a building / pier / wall (streets are floors and do not block)
        if (this.solid) for (const d of D) if (!d.asleep && d.state !== 'idle' || !d.asleep && !d.talk) this.solid(d, d.y);
        // ambient chatter between drones: two drones close together stop, face each other, trade lines
        this.chatT -= dt;
        if (this.chatT <= 0) {
            this.chatT = 2 + this.r() * 3;
            const awake = D.filter(d => !d.asleep && !d.bubble && !d.talk && (!player || Math.hypot(player.x - d.x, player.z - d.z) < 90));
            if (awake.length >= 2) {
                const a = awake[Math.floor(this.r() * awake.length)];
                const b = awake.find(o => o !== a && Math.hypot(o.x - a.x, o.z - a.z) < 20);
                if (b && this.r() < 0.7) { const L = chatterPair(a.res, b.res, this.ctx, this.r); this.say(a, L[0], 3); b.pendingLine = { at: 3.0, text: L[1] }; a.pendingLine = { at: 6.0, text: L[2] }; a.pendingBorn = 0; b.pendingBorn = 0;
                    for (const [p, q] of [[a, b], [b, a]]) { p.state = 'idle'; p.idleT = 7; p.yaw = Math.atan2(q.x - p.x, q.z - p.z) - Math.PI / 2; } }
                else if (this.r() < 0.5) this.say(a, ambientLine(a.res, this.ctx, this.r), 4);
            }
        }
        for (const d of D) if (d.pendingLine) { d.pendingBorn += dt; if (d.pendingBorn >= d.pendingLine.at) { this.say(d, d.pendingLine.text, 3); d.pendingLine = null; } }
    }
    nearestDrone(px, pz, maxD) { let b = null, bd = maxD * maxD; for (const d of this.drones) { if (d.asleep) continue; const q = (d.x - px) ** 2 + (d.z - pz) ** 2; if (q < bd) { bd = q; b = d; } } return b; }
}
