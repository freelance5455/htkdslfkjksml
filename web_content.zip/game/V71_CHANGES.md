# v71 - the small tremor (ambient beat)
Not run in a browser; `game.js` passes a syntax check.

## What changed
- **A small tremor, once.** After the first night attack is resolved, in daylight and with nothing hostile or scripted going on (no cutscene, no fight, not on the boat or underwater, not in the shelter, AI not mid-line), the game counts time the player spends walking on foot. After 90-150 s of walking the ground shudders: a gentle screen shake (`triggerShake(0.16, 2.8)`) with a low rumble, no particles and no damage.
- **The AI's read-out.** It says it is a small tremor with no damage, checks the wave data, and notes the crust carried it too fast for a body this size: Earth-like gravity on a too-small moon means it is extraordinarily dense for its size. It would like to know what is inside, but not today. Uses `speakLine` directly (like the gas-giant stare), so the game never pauses and the player keeps moving.
- New log entry "A Small Tremor". Saved as `tremorSceneDone`; set as soon as the scene starts so a reload mid-scene does not repeat it.
- Knobs: `TREMOR_WALK_SECONDS_MIN/MAX`, the shake and rumble in `runSmallTremorScene`, the gating in `tremorQuietEnough`.
