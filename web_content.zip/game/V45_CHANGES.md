# v45 - hidden valley city-states (Vale Compact)

Lore: drones that broke from the empire fled into small high valleys, built cities, trade and jobs, and are NOT linked to the great machine.
After it is destroyed they are relieved, but stay in their valleys.

## New files
- valley_sites.js - site finder + valley terrain shaper (pure maths; shared by main thread, workers, tests)
- city_core.js    - procedural city generator (street graph, terraces, buildings from a piece library, hub landmark, bridges, gate, flags)
- city_roads.js   - terrain-aware road router between two city gates (A* on a coarse grid, avoids water / steep / hostile ground)
- city_life.js    - drone identities (blue/green), jobs, interests, daily routine, dialogue (before/after the machine), barter economy
- city_sim.js     - drone nav graph, movement, routines, ambient chatter, greetings (pure; only run near the player, capped at 48/city)
- city_runtime.js - three.js side: instanced meshes, LOD, window shader, far beacon, drones, DOM chat bubbles, dialogue + trade UI, roads, cargo drones
- tests/          - headless Node tests (run from tests/: `node test_sites.mjs` etc.); package.json is only there so Node treats the .js files as ES modules

## Changed files
- chunk_core.js: valley shaping in terrain + scatter (heights, paving tint, trees/props cleared inside footprint); buildCity / buildRoad jobs.
  ChunkBuilder(seed, sites).
- terrain_worker.js: init carries `sites`; new 'city' and 'road' messages.
- game.js: imports; findSites at init; valley shaping inside getEnvironmentRaw (same function the workers use, so mesh, collision and
  props agree); TPOOL.post() for city/road jobs; CityWorld created before the loop and updated each frame; E talks to a drone first;
  `greatMachineDestroyed` flag (saved/loaded) + onGreatMachineDestroyed() hook; city trade state saved; HUD line with distance to the
  nearest Vale city; `window.cityDebug` (tp(i), tpNearest(), setMachineDestroyed(true), sites, world).

## How it works
1. SITES: coarse grid, 24x24 cells per cube face, 2 hashed candidates per cell, at most one site per cell, all randomness hashed from
   (seed, home face, i, j). Sites are stored as unit directions, so crossing a face edge never re-rolls them. 6-10 per world (per-seed target),
   at least 4 guaranteed (rules relax if needed). Candidates must be high land, inland, with a gentle pass.
   Scoring also favours big landmasses and land-linked neighbours so some city-states form small leagues that roads can join.
2. VALLEY: floor (r 380-560) flattened to +-1.1 units, walls rise 220-370 above the floor, rim, blend back to natural terrain, one narrow,
   curved pass whose ramp follows the natural ground profile.
3. CITY: generated once per site in chart-independent plan space; one group transform per chart. Archetype (grid/radial/organic/fishbone),
   palette (8), hub landmark (spire/dome hall/ziggurat/clock tower/light tree), terrace levels with stairways, frontage + interior lots,
   skybridges, hub plaza with pool + arch bridge or market, gate on the pass, secondary landmarks, faction flags.
   ~900-1700 buildings, ~4-10k pieces per city, ~0.5 MB.
4. LOD: FULL < 4200 units (windows, lamps, streets, shadows < 2400), MID < 13000 (walls + roofs), SKY < 60000 (emissive tower silhouettes), plus a
   glow beacon (sprite + light shaft) visible out to 90000 units.
5. DRONES: blue/green, 64 residents per city, 48 simulated while the player is within 1500 units; sleep / commute / work / lunch / evening.
   Chat bubbles (DOM, max 8): ambient pair chatter, solo lines, greetings. E / tap prompt opens a conversation; "Let us trade" opens barter.
6. TRADE: barter on your existing resources (wood, stone, piezo-quartz, silicon-ferrite, bio-fluorite, vent minerals). Per-city demand and stock,
   10% spread in the city's favour, prices move with each trade and relax over time; round trips always lose value.
7. ROADS: between land-linked city pairs <= 100 km. Ribbon tiles are built within ~3 km of the player; cargo drones (3-8 per road) walk them
   (position computed from game time, only the ones within ~1.8 km are drawn, cap 22).
8. FACTION: all Vale drones are `faction: 'vale'`. The empire-collapse hook only touches other factions. v44 contains no great-machine
   story event, so I added the flag and hook; call `cityDebug.setMachineDestroyed(true)` to see the relief dialogue.

## Measured headless (Node)
- Sites per planet over 8 seeds: 6-10 (7,6,7,10,8,9,8,8), deterministic (two fresh generators give identical lists), one site per cell, spread over 3-6 faces.
  Time: 0.8-1.8 s for a cold generator (includes the generator's own climate warm-up); ~0.2 s when warm.
- Valley: floor spread 2.2 units, closed bowl with one pass; chunk shared edges differ by 0.0000; 0 NaN; props inside clear radius 0
  (3699-7682 without the valley). Steepest ground outside the floor is up to ~3.5 per unit at some sites (natural cliffs next to the rim).
- City generation 0.1-0.5 s each; no overlapping footprints; every street graph connected to the hub and gate.
- 24 h drone simulation: no NaN, drones stay in the valley, all asleep at 0.05, 38 distinct chatter lines, <= 5 bubbles at once.
- Stub-three.js runtime smoke test: city loads, LODs switch, sim starts/stops, prompt, dialogue, trade, close/unpause all run without errors.

## NOT tested (needs a browser)
- Any real rendering: the window/night shader, instanced meshes, beacon look, shadows, performance/frame rate with a city on screen,
  how the cities and valley walls look, bubble placement, panel layout on phones. I could only run logic with a stub three.js.
- Real worker pool behaviour (city jobs are queued with terrain jobs), the fallback path, save/load with cityState, and the cube-face handover
  with a city on screen (only the transform recompute is designed for it).
- Roads / cargo drones in-game: only the router was tested headless. On 4 of 8 test seeds NO pair of cities is land-linked (the world is
  mostly islands), so those worlds have no roads at all; the others have one ~20 km road.
- You may want to tune: FULL_D/MID_D in city_runtime.js, maxBuildings in generateCity, RF_MIN/RF_MAX and rimRise in valley_sites.js.
## Known limits
- "Always there to trade": every world has 6-10 city-states, but they sit on high ground and may be on another island from your spawn. The HUD shows
  the distance to the nearest one; cityDebug.tpNearest() jumps to it.
- Valley passes are narrow and curved but still a notch roughly 30-45 degrees wide at the rim top.
- Terrain colours inside the valley use a paving tint; no separate biome for the valley floor.

# v46 - more city-states, syllable names
- valley_sites.js: ~30 sites per world (per-seed target 28-32; measured 28-33 over 8 seeds, 1.4-2.0 s cold). SITE_MIN_SEP 60000 -> 42000, wider candidate pools,
  relaxed score threshold, new TOP-UP pass fills to the target from relaxed candidates. Still deterministic, one site per cell.
- city_life.js: cityName() is now syllable-based: [onset]+vowel+[coda]; first syllable can start with a vowel, any syllable can close on a consonant,
  1-4 syllables, ~25% get a head/tail word ("High X", "X Reach"). cityName(seedN, usedSet) re-rolls deterministically to avoid duplicate names in a world
  (city_runtime passes a set). droneName uses the same syllables.
- Teleport: use the existing cityDebug.tp(i) / tpNearest() from your debug menu.
