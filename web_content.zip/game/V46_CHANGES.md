# v46 - Vale city debug teleport, broader mountains

## Debug menu (index.html, styles.css, game.js)
- Two new buttons under the teleport presets: "Vale City: Nearest" (closest site anywhere on the sphere, not just the current cube face) and
  "Vale City: Next" (cycles through every site in order). Both land on the site centre and close the panel; the status line shows "Vale city N of M".
- `cityDebug.tp(i)` / `tpNearest()` still work from the console.

## Mountains (terrain_core.js)
- New `MTN_SPAN = 0.5`: horizontal scale of the mountain ridge noise and of the range-belt placement field. Ridges are about twice as long/wide, belts broader.
- Highland ramp inland widened (highPeakFactor ss 0.08..0.40 -> 0.08..0.46), ridge octave gain 0.42 -> 0.36, micro-relief boost on mountains 1.6 -> 0.9.
- Measured (seed 424242, land above 1200 units, 60-unit baseline): slope p90 1.64 -> 1.32, p99 3.87 -> 3.21; at a 250-unit baseline p90 1.49 -> 1.22, p99 3.34 -> 2.77.
  Height p99 about the same (6480 -> 6600), max 9270 -> 9380, median mountain height unchanged (~1700).
- Not checked in a browser. Terrain changes the world for existing seeds: mountains move, so saved games will see different ground.
