const c=document.getElementById('game'),x=c.getContext('2d');
let W=0,H=0,D=Math.max(1,Math.min(2,devicePixelRatio||1));function resize(){W=innerWidth;H=innerHeight;c.width=Math.floor(W*D);c.height=Math.floor(H*D);x.setTransform(D,0,0,D,0,0)}addEventListener('resize',resize);resize();
const world={w:11050,h:5600};
const zones=[{name:'Pradaria',start:0,end:650,cost:0,skin:0,bg:'#5b9c54',accent:'#a8ed7b'},{name:'Bosque Azul',start:650,end:1300,cost:100,skin:1,bg:'#356f76',accent:'#7fe3ff'},{name:'Deserto Dourado',start:1300,end:1950,cost:300,skin:2,bg:'#b58a3f',accent:'#ffe38e'},{name:'Pantano Neon',start:1950,end:2600,cost:650,skin:3,bg:'#624a74',accent:'#f9a0ff'},{name:'Geleira',start:2600,end:3250,cost:1200,skin:4,bg:'#6590b1',accent:'#dbfbff'},{name:'Vulcao',start:3250,end:3900,cost:2000,skin:5,bg:'#70392f',accent:'#ffb06f'},{name:'Lagoa Doce',start:3900,end:4550,cost:3000,skin:6,bg:'#b35c9a',accent:'#ffd7ef'},{name:'Montanha Roxa',start:4550,end:5200,cost:4200,skin:7,bg:'#59476f',accent:'#d4a7ff'},{name:'Caverna Esmeralda',start:5200,end:5850,cost:5600,skin:8,bg:'#285d4a',accent:'#7dffc4'},{name:'Vale Neon',start:5850,end:6500,cost:7200,skin:9,bg:'#253d73',accent:'#70e8ff'},{name:'Ceu Prisma',start:6500,end:7150,cost:9000,skin:10,bg:'#6852a0',accent:'#ffe8ff'},{name:'Reino Pinhata',start:7150,end:7800,cost:11000,skin:11,bg:'#8f3f64',accent:'#ffd36a'},{name:'Ilhas Flutuantes',start:7800,end:8450,cost:13500,skin:12,bg:'#4c78a8',accent:'#dff6ff'},{name:'Floresta Cristal',start:8450,end:9100,cost:16500,skin:13,bg:'#2e6b72',accent:'#aaffee'},{name:'Reino das Estrelas',start:9100,end:9750,cost:20000,skin:14,bg:'#292452',accent:'#ffe58a'},{name:'Pantanal',start:9750,end:10400,cost:24000,skin:15,bg:'#3b5e45',accent:'#8fd36c'},{name:'Lamaçal Profundo',start:10400,end:11050,cost:30000,skin:16,bg:'#355044',accent:'#8fe36c'}];
const skins=[
{name:'Folha Viva',a:'#5cf06d',b:'#169c42',c:'#c6ff7a',pattern:'spots'},
{name:'Oceano',a:'#55e9ff',b:'#1970d1',c:'#dbfbff',pattern:'waves'},
{name:'Imperial',a:'#ffd75a',b:'#cb6d0d',c:'#fff3ae',pattern:'bands'},
{name:'Neon X',a:'#ff55d5',b:'#7036ff',c:'#7effff',pattern:'rings'},
{name:'Glacial',a:'#ddfbff',b:'#52b5ef',c:'#fff',pattern:'crystal'},
{name:'Magma',a:'#ff6a45',b:'#9f1f12',c:'#ffd264',pattern:'flame'},
{name:'Galáxia',a:'#a87bff',b:'#202060',c:'#65e8ff',pattern:'galaxy'},
{name:'Esmeralda',a:'#52f59b',b:'#087a58',c:'#d8ffe8',pattern:'scales'},
{name:'Solar',a:'#ffdb5c',b:'#f16a1d',c:'#fff1a3',pattern:'sun'},
{name:'Aurora',a:'#63ffd4',b:'#7f56ff',c:'#ff72d6',pattern:'aurora'},
{name:'Tempestade',a:'#9ed0ff',b:'#25365f',c:'#dff6ff',pattern:'storm'},
{name:'Prisma',a:'#ff7ac6',b:'#58e7ff',c:'#fff27a',pattern:'prism'},
{name:'Nuvem',a:'#dff6ff',b:'#6ca9e8',c:'#fff',pattern:'waves'},
{name:'Cristal',a:'#7affd5',b:'#247c88',c:'#eaffff',pattern:'crystal'},
{name:'Estelar',a:'#b59cff',b:'#24205e',c:'#ffe88a',pattern:'galaxy'},
{name:'Pantanal',a:'#63dc73',b:'#246646',c:'#dfff9b',pattern:'scales'},
{name:'Lama Verde',a:'#7be66a',b:'#31553f',c:'#d7ff9a',pattern:'scales'},
{name:'Brilhante Solaris',a:'#fff7a8',b:'#ffcf33',c:'#ffffff',pattern:'shine',special:true,rarity:'LENDÁRIA'},
{name:'Brilhante Oceano',a:'#9ffcff',b:'#198cff',c:'#ffffff',pattern:'shine',special:true,rarity:'LENDÁRIA'},
{name:'Brilhante Neon',a:'#ff9cf8',b:'#7b4dff',c:'#73ffff',pattern:'shine',special:true,rarity:'ÉPICA'},
{name:'Brilhante Magma',a:'#ffd36b',b:'#ff4b22',c:'#fff6c2',pattern:'shine',special:true,rarity:'ÉPICA'},
{name:'Brilhante Cristal',a:'#dfffff',b:'#73ffd8',c:'#ffffff',pattern:'shine',special:true,rarity:'MÍTICA'},
{name:'Brilhante Prata',a:'#ffffff',b:'#7f8c9d',c:'#d9f3ff',pattern:'metal',special:true,rarity:'LENDÁRIA'},
{name:'Brilhante Lamaçal',a:'#e0ff8a',b:'#3b8c58',c:'#ffffff',pattern:'shine',special:true,rarity:'MÍTICA'}
];
const colors=['#ef6a6a','#f5b83d','#8ad85d','#63c6e8','#b77af2','#ff79bd','#f4f4f4','#ff8f3d','#6ee7b7','#d9a7ff'];
const names=['Pipoca','Jujuba','Tico','Luna','Biscoito','Nino','Fafa','Zig','Mimo','Pingo','Nuvem','Caju','Dengo','Zuzu','Bidu','Mia','Bilu','Tutu','Kiko','Lili','Trovao','Manga','Kiwi','Pudim','Jade','Neca','Rubi','Fumaca','Pixel','Bambam'];
const aiKinds=['pastadora','exploradora','duelista','cercadora','interceptadora','curiosa','dominante','patrulheira'];
const SNAKE_CAP=30,HUNTER_COUNT=5;
const hunterTypes=[{name:'Aguia Batedora',speed:108,size:38},{name:'Aguia Rastreadora',speed:96,size:42},{name:'Aguia Guardiã',speed:86,size:46},{name:'Aguia Cacadora',speed:118,size:44},{name:'Aguia Alfa',speed:132,size:52}];
const SAFE_STORE={_data:Object.create(null),get(k){
  if(this._data[k]!==undefined)return this._data[k];
  try{const v=localStorage.getItem(k);if(v!==null){this._data[k]=v;return v}}catch(e){}
  try{const v=sessionStorage.getItem(k);if(v!==null){this._data[k]=v;return v}}catch(e){}
  return null;
},set(k,v){
  const val=String(v);this._data[k]=val;
  try{localStorage.setItem(k,val)}catch(e){}
  try{sessionStorage.setItem(k,val)}catch(e){}
}};
const rnd=(a,b)=>a+Math.random()*(b-a),dist=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y),clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
function hashText(s){let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}return (h>>>0).toString(16)}function accountKey(n){return 'wormAccount_'+hashText(n.trim().toLowerCase())}
function stage(l){return l<3?'Filhote':l<6?'Jovem':l<10?'Adulta':l<16?'Gigante':'Anciã'}function zoneAt(px){for(let i=0;i<zones.length;i++)if(px>=zones[i].start&&px<zones[i].end)return i;return zones.length-1}
let worm=null,player2=null,critters=[],hunters=[],foods=[],coins=[],particles=[],cam={x:0,y:0},keys={},joystick={x:0,y:0};
const MAX_ONLINE_PLAYERS=6;
let remotePlayers={},localNetId='',roomHostId='',hostConns=new Map();
let running=false,last=0,energy=100,boosting=false,stationary=false,spawnClock=0,largestId=-1;let gameMode=null;let foodCollisionClock=0,npcCombatClock=0;
let playerName='',accountKeySaved='',loggedIn=false,money=0,best=8,unlocked=0,selectedSkin=0,turboLevel=1,agilityLevel=1,lavaPotion=0,hunterActive=true,adminBoost=false,score=0,chatMessages=[];
let portalCharges=0,coinMagnetCharges=0,growthPotionCharges=0,xpBoostCharges=0,eventTokens=0,lastZone=-1,autoSaveTimer=0;
let noticeTimer=0,multiStatusTimer=0,loginStatusTimer=0,lastKillNoticeAt=0;
let activeEvent='normal',eventTimer=0,eventSchedule=22,lavaSpots=[],audioCtx=null,audioMaster=null,lavaEatClock=0,lastLavaWarnAt=0,lavaProtection=0,lavaDamageClock=0;let lavaExitLake={x:3825,y:2800,rx:300,ry:180};let lavaTexture=new Image();lavaTexture.src='lava-texture.jpg';
function showNotice(msg,ms=4000){const el=document.getElementById('notice');if(!el)return;clearTimeout(noticeTimer);el.textContent=msg;el.classList.add('show');const ttl=Math.min(4000,Math.max(800,ms));noticeTimer=setTimeout(()=>el.classList.remove('show'),ttl)}
function showKillNotice(msg){const now=Date.now();if(now-lastKillNoticeAt<5000)return;lastKillNoticeAt=now;showNotice(msg,4000)}
function ensureAudio(){try{if(!audioCtx)audioCtx=new (window.AudioContext||window.webkitAudioContext)();if(!audioMaster){audioMaster=audioCtx.createGain();audioMaster.gain.value=1.8;audioMaster.connect(audioCtx.destination)}if(audioCtx.state==='suspended')audioCtx.resume()}catch(e){}}
function tone(freq,dur=.12,type='sine',vol=.09,endFreq=freq*1.2){ensureAudio();if(!audioCtx)return;const t=audioCtx.currentTime,o=audioCtx.createOscillator(),g=audioCtx.createGain();o.type=type;o.frequency.setValueAtTime(freq,t);o.frequency.exponentialRampToValueAtTime(Math.max(30,endFreq),t+dur*.75);g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(vol,t+.012);g.gain.exponentialRampToValueAtTime(.0001,t+dur);o.connect(g);g.connect(audioMaster||audioCtx.destination);o.start(t);o.stop(t+dur)}
function melody(freqs=[440,660,880]){freqs.forEach((f,i)=>setTimeout(()=>tone(f,.13,'triangle',.08,f*1.06),i*72))}
function buySound(){melody([520,720,940])}
function eventSound(){melody([280,420,620,900])}
function eatSound(){tone(440,.08,'sine',.055,620)}
function coinSound(){tone(760,.09,'triangle',.07,980)}
function evolveSound(){melody([360,520,740,1040])}
function portalSound(){melody([240,360,560,820,1180])}
function areaSound(){melody([220,330,494,660])}
function warningSound(){tone(160,.24,'sawtooth',.07,90)}
function showLoginMsg(msg){const el=document.getElementById('playerLoginError');if(!el)return;clearTimeout(loginStatusTimer);el.textContent=msg;loginStatusTimer=setTimeout(()=>{el.textContent=''},4000)}
function profileDefault(n,p){return {name:n,passHash:hashText(p),money:0,best:8,unlocked:0,skin:0,turbo:1,agility:1,lavaPotion:0,portalCharges:0,coinMagnetCharges:0,growthPotionCharges:0,xpBoostCharges:0,eventTokens:0,swampPotion:0,hunters:true,adminBoost:false}}
function register(name,pass){const n=name.trim().slice(0,18),k=accountKey(n);if(SAFE_STORE.get(k))return {error:'Essa conta já está registrada. Use LOGIN.'};const p=profileDefault(n,pass);SAFE_STORE.set(k,JSON.stringify(p));return {key:k,p}}
function login(name,pass){const n=name.trim().slice(0,18),k=accountKey(n),raw=SAFE_STORE.get(k);if(!raw){const p=profileDefault(n,pass);SAFE_STORE.set(k,JSON.stringify(p));return {key:k,p,created:true}}try{const p=JSON.parse(raw);if(p.passHash!==hashText(pass))return {error:'Senha incorreta.'};return {key:k,p}}catch(e){return {error:'Conta corrompida.'}}}
function applyProfile(k,p){accountKeySaved=k;playerName=p.name;money=p.money||0;best=p.best||8;unlocked=clamp(p.unlocked||0,0,zones.length-1);selectedSkin=clamp(p.skin||0,0,unlocked);turboLevel=clamp(p.turbo||1,1,5);agilityLevel=clamp(p.agility||1,1,5);lavaPotion=Math.max(0,Number(p.lavaPotion||0));portalCharges=Math.max(0,Number(p.portalCharges||0));coinMagnetCharges=Math.max(0,Number(p.coinMagnetCharges||0));growthPotionCharges=Math.max(0,Number(p.growthPotionCharges||0));xpBoostCharges=Math.max(0,Number(p.xpBoostCharges||0));eventTokens=Math.max(0,Number(p.eventTokens||0));window.__swampPotion=Math.max(0,Number(p.swampPotion||0));hunterActive=p.hunters!==false;adminBoost=p.adminBoost===true;loggedIn=true;lastZone=-1}
function save(){if(!loggedIn)return;let raw={};try{raw=JSON.parse(SAFE_STORE.get(accountKeySaved)||'{}')}catch(e){}let p={...raw,name:playerName,passHash:raw.passHash||'',money:Math.floor(money),best,unlocked,skin:selectedSkin,turbo:turboLevel,agility:agilityLevel,lavaPotion,portalCharges,coinMagnetCharges,growthPotionCharges,xpBoostCharges,eventTokens,swampPotion:Number(window.__swampPotion||0),hunters:hunterActive,adminBoost};SAFE_STORE.set(accountKeySaved,JSON.stringify(p))}
function rebuildBody(a){a.body=[];const sp=Math.max(10,a.r*.78);for(let i=0;i<a.len;i++)a.body.push({x:a.x-Math.cos(a.ang)*sp*i,y:a.y-Math.sin(a.ang)*sp*i})}
function smoothBody(a){const sp=Math.max(10,a.r*.78);if(!a.body.length)return rebuildBody(a);a.body.unshift({x:a.x,y:a.y});for(let i=1;i<a.body.length;i++){const p=a.body[i-1],q=a.body[i],dx=p.x-q.x,dy=p.y-q.y,d=Math.hypot(dx,dy)||1;if(d>sp){const f=(d-sp)/d;q.x+=dx*f;q.y+=dy*f}}while(a.body.length<a.len)a.body.push({...a.body[a.body.length-1]});while(a.body.length>a.len)a.body.pop()}
function makeSnake(i){let len=Math.floor(rnd(5,13));if(i%7===3||i%11===0)len=Math.floor(rnd(17,29));return {id:i,name:names[i%names.length],x:0,y:0,r:10+Math.sqrt(len)*1.9,len,level:1,xp:0,ang:rnd(-Math.PI,Math.PI),speed:rnd(34,58),color:colors[i%colors.length],skinIndex:(i*3)%skins.length,skinName:skins[(i*3)%skins.length].name,mood:['curiosa','calma','competitiva','aventureira'][i%4],trait:['gulosa','veloz','estrategica','observadora'][i%4],aiKind:aiKinds[i%aiKinds.length],body:[],orbit:rnd(-3.14,3.14),orbitDir:i%2?1:-1,think:rnd(.2,.7),kills:0,wallet:0,currentZone:0,bubble:'',bubbleT:0,pattern:skins[(i*3)%skins.length].pattern,hp:40,maxHp:40}}
function randomPoint(minFromPlayer=0){for(let i=0;i<80;i++){const p={x:rnd(140,world.w-140),y:rnd(140,world.h-140)};if(!worm||dist(p,worm)>minFromPlayer)return p}return {x:rnd(160,world.w-160),y:rnd(160,world.h-160)}}
function spawnOne(){if(critters.length>=SNAKE_CAP)return;const id=critters.length?Math.max(...critters.map(a=>a.id))+1:0,a=makeSnake(id),p=randomPoint(420);a.x=p.x;a.y=p.y;a.currentZone=zoneAt(a.x);rebuildBody(a);critters.push(a)}
function spawnSnakes(){critters=[];while(critters.length<SNAKE_CAP)spawnOne()}
function spawnHunters(){hunters=[];if(!worm)return;for(let i=0;i<HUNTER_COUNT;i++){let p=randomPoint(850);let tries=0;while(dist(p,worm)<800&&tries++<80)p=randomPoint(850);hunters.push({id:i,x:p.x,y:p.y,phase:rnd(0,6.28),type:hunterTypes[i],alert:1})}}
function addFood(){const r=Math.random();const x0=rnd(90,world.w-90),y0=rnd(90,world.h-90),zi=zoneAt(x0);const areaKind=zi===15?'tadpole':(zi===16?'tadpole':('food'+zi));foods.push({x:x0,y:y0,r:rnd(5,10),v:r<.72?1:r<.94?2:5,h:rnd(0,360),areaKind,zone:zi})}
function spawnFood(){foods=[];for(let i=0;i<220;i++)addFood()}
function spawnLava(){lavaSpots=[];for(let i=0;i<26;i++)lavaSpots.push({x:rnd(3320,3835),y:rnd(180,world.h-180),r:rnd(34,72),phase:rnd(0,6.28)})}
const EVENT_DEFS={
 normal:{name:'Sem evento',desc:'Mapa normal.',xp:1,coin:0,color:'#bfeec4'},
 candy:{name:'Chuva de Doces',desc:'Comidas doces em cascata.',xp:1.8,coin:2,color:'#ff8fc8'},
 neon:{name:'Noite Neon',desc:'Mapa brilhante e comida valiosa.',xp:2,coin:2,color:'#7cf7ff'},
 golden:{name:'Corrida do Ouro',desc:'Moedas especiais aparecem pelo mapa.',xp:1.5,coin:5,color:'#ffd65c'},
 rainbow:{name:'Festival Prisma',desc:'Comidas prismáticas dão bônus.',xp:2.4,coin:3,color:'#d6a2ff'},
 coinstorm:{name:'Tempestade de Moedas',desc:'Uma chuva de moedas atravessa a arena.',xp:1.2,coin:1,color:'#ffe26d'},
 treasure:{name:'Caça ao Tesouro',desc:'Baús escondidos dão recompensas grandes.',xp:1.3,coin:2,color:'#ffbd5c'},
 portalrush:{name:'Corrida dos Portais',desc:'Portais temporários encurtam o caminho.',xp:1.7,coin:2,color:'#75b9ff'},
 eclipse:{name:'Eclipse Sombrio',desc:'A arena escurece e itens raros brilham.',xp:2.1,coin:4,color:'#a89aff'},
 glacier:{name:'Festival de Gelo',desc:'Comidas congeladas aparecem em trilhas.',xp:2.2,coin:3,color:'#9fe8ff'},
 volcano:{name:'Erupção Vulcânica',desc:'O Vulcão ganha focos extras de lava.',xp:2.5,coin:6,color:'#ff744d'},
 mobheist:{name:'Roubo de Mob',desc:'Mobs errantes aparecem: pegue o token do mob e entregue a sua coleção.',xp:2.7,coin:8,color:'#c5ff67'},
 mega:{name:'Mega Comilança',desc:'Comidas gigantes valem muito corpo.',xp:3.2,coin:8,color:'#ff9d4d'}
};
function currentEvent(){return EVENT_DEFS[activeEvent]||EVENT_DEFS.normal}
let eventObjects={coins:[],chests:[],portals:[],mobs:[],mega:[],aurora:[]};
function clearEventObjects(){eventObjects={coins:[],chests:[],portals:[],mobs:[],mega:[],aurora:[]}}
function pInt(n){return Math.floor(Math.random()*n)}
function spawnEventObjects(){clearEventObjects();if(activeEvent==='coinstorm'){for(let i=0;i<65;i++)eventObjects.coins.push({x:rnd(120,world.w-120),y:rnd(120,world.h-120),value:5+pInt(18),r:7})}if(activeEvent==='treasure'){for(let i=0;i<10;i++)eventObjects.chests.push({x:rnd(120,world.w-120),y:rnd(120,world.h-120),open:false})}if(activeEvent==='portalrush'){for(let i=0;i<8;i++)eventObjects.portals.push({x:rnd(180,world.w-180),y:rnd(160,world.h-160),spin:rnd(0,6.28)})}if(activeEvent==='mobheist'){for(let i=0;i<8;i++)eventObjects.mobs.push({x:rnd(200,world.w-200),y:rnd(160,world.h-160),vx:rnd(-18,18),vy:rnd(-18,18),phase:rnd(0,6.28),kind:i%4})}if(activeEvent==='mega'){for(let i=0;i<12;i++)eventObjects.mega.push({x:rnd(160,world.w-160),y:rnd(160,world.h-160),r:rnd(18,30),v:12,h:rnd(0,360)})}if(activeEvent==='aurora'){for(let i=0;i<9;i++)eventObjects.aurora.push({x:rnd(140,world.w-140),y:rnd(140,world.h-140),r:rnd(70,120),phase:rnd(0,6.28)})}}
function startEvent(id,duration=120,remote=false){if(!EVENT_DEFS[id])id='normal';activeEvent=id;eventTimer=Math.max(0,Number(duration||120));spawnFood();spawnEventObjects();if(!remote){eventSound();if(window.__playEventMusic)window.__playEventMusic();showNotice(`EVENTO: ${currentEvent().name} • ${Math.ceil(eventTimer)}s`,4000)}}
function stopEvent(){activeEvent='normal';eventTimer=0;clearEventObjects();spawnFood();showNotice('Evento encerrado. O mapa voltou ao normal.',4000)}
function eventReward(mult=1){const reward=Math.round((45+eventTokens*12)*mult);money+=reward;eventTokens=0;save();showNotice(`Evento concluído! +${reward} moedas`,4000);coinSound()}
function usePortalAt(o){
  if(!worm)return;
  const next=Math.min(zones.length-1,unlocked+1);
  if(next===unlocked){showNotice('Você já liberou todas as áreas.',3000);return}
  if(next===5&&lavaPotion<=0){showNotice('🔥 Portal bloqueado: precisa de Poção de Lava para entrar no Vulcão.',3000);return}
  const cost=zones[next].cost;
  if(money<cost){showNotice(`Faltam ${Math.max(0,Math.ceil(cost-money))} moedas para ${zones[next].name}.`,3000);return}
  if(next===5)lavaPotion--;
  money-=cost;
  unlocked=next;
  selectedSkin=zones[next].skin;
  worm.x=zones[next].start+280;
  worm.y=clamp(worm.y,240,world.h-240);
  worm.color=skins[selectedSkin].a;
  worm.skinIndex=selectedSkin;
  worm.skinName=skins[selectedSkin].name;
  worm.pattern=skins[selectedSkin].pattern;
  lavaProtection=next===5?30:0;
  rebuildBody(worm);
  portalSound();
  save();
  renderStore();
  updateHud();
  showNotice(`🌀 Portal: ${zones[next].name}!`,4000);
}
function updateEventObjects(dt){
 for(const o of eventObjects.mobs){o.x=clamp(o.x+o.vx*dt,120,world.w-120);o.y=clamp(o.y+o.vy*dt,120,world.h-120);o.phase+=dt*4;if(dist(worm,o)<worm.r+28){eventTokens++;money+=110;addXp(worm,80);addParticle(o.x,o.y,'#baff63',18);showNotice('ROUBO DE MOB! +110 moedas e token de evento',3000);buySound();eventSound();o.x=-999;save()}}
 for(const o of eventObjects.coins){if(o.x<0)continue;if(coinMagnetCharges>0&&dist(worm,o)<260){o.x+=(worm.x-o.x)*Math.min(1,dt*3);o.y+=(worm.y-o.y)*Math.min(1,dt*3)}if(dist(worm,o)<worm.r+o.r+6){money+=o.value;eventTokens++;coinSound();o.x=-999;save()}}
 for(const o of eventObjects.chests){if(!o.open&&dist(worm,o)<worm.r+30){o.open=true;const val=450+pInt(751);money+=val;eventTokens+=2;addXp(worm,160);showNotice(`BAÚ ABERTO! +${val} moedas`,3000);buySound();save()}}
 for(const o of eventObjects.portals){o.spin+=dt*5;if(o.x>=0&&dist(worm,o)<worm.r+34){usePortalAt(o);o.x=-999}}
 for(const o of eventObjects.mega){if(o.x>=0&&dist(worm,o)<worm.r+o.r){const gain=10+pInt(22);addXp(worm,gain*10);worm.len+=gain;worm.r=Math.min(40,10+Math.sqrt(worm.len)*1.9);rebuildBody(worm);eventTokens++;showNotice(`MEGA COMIDA! +${gain} corpo`,3000);eatSound();o.x=-999}}
 if(activeEvent==='candy'&&Math.random()<dt*1.8){addFood();eventTokens++}
 if(activeEvent==='golden'&&Math.random()<dt*1.2){coins.push({x:rnd(120,world.w-120),y:rnd(120,world.h-120),r:11,value:25+pInt(40),life:40,pulse:rnd(0,6)});eventTokens++}
 if(activeEvent==='rainbow'&&Math.random()<dt*.8){eventObjects.mega.push({x:rnd(160,world.w-160),y:rnd(160,world.h-160),r:rnd(24,34),v:18,h:rnd(0,360)});eventTokens++}
 if(activeEvent==='glacier'&&Math.random()<dt*1.4){eventObjects.mega.push({x:rnd(160,world.w-160),y:rnd(160,world.h-160),r:rnd(18,27),v:10,h:210});eventTokens++}
 if(activeEvent==='eclipse'&&Math.random()<dt*.45&&dist(worm,{x:clamp(worm.x+rnd(-300,300),120,world.w-120),y:clamp(worm.y+rnd(-300,300),120,world.h-120)})<420){eventTokens++;addXp(worm,18)}
 if(activeEvent==='volcano'&&Math.random()<dt*.9)lavaSpots.push({x:rnd(3320,3835),y:rnd(220,world.h-220),r:rnd(34,72),phase:rnd(0,6.28)})
 if(activeEvent==='aurora')for(const o of eventObjects.aurora)o.phase+=dt*2;
}
function updateEvent(dt){if(activeEvent==='normal'){const canSchedule=gameMode==='bots'||(gameMode==='multiplayer'&&multiRole==='host');if(canSchedule){eventSchedule-=dt;if(eventSchedule<=0&&running){const ids=Object.keys(EVENT_DEFS).filter(id=>id!=='normal'&&!(gameMode==='multiplayer'&&id==='mobheist'));const pick=ids[Math.floor(Math.random()*ids.length)];eventSchedule=150;startEvent(pick,110,false)}}return}eventTimer-=dt;updateEventObjects(dt);if(eventTimer<=0){if(eventTokens>0)eventReward(1);stopEvent();eventSchedule=18}}
function makePlayer2(){const p={id:'player2',name:'Jogador 2',x:worm.x+300,y:worm.y+160,r:13,len:8,level:1,xp:0,ang:Math.PI,body:[],energy:100,kills:0,color:'#74d9ff'};rebuildBody(p);return p}
function resetRun(){coins=[];particles=[];clearEventObjects();worm={id:'player',name:playerName||'Você',x:Math.min(world.w/2,zones[unlocked].start+520),y:world.h/2,r:13,len:8,level:1,xp:0,ang:0,body:[],kills:0,wallet:0,color:skins[selectedSkin].a};rebuildBody(worm);player2=null;remotePlayers={};if(gameMode==='multiplayer')netAlive=true;energy=100;score=0;stationary=false;boosting=false;spawnClock=0;spawnLava();spawnFood();critters=[];hunters=[];lavaProtection=0;lavaDamageClock=0;activeEvent='normal';eventTimer=0;eventSchedule=22;eventTokens=0;if(gameMode==='bots')spawnSnakes();if(gameMode==='bots'&&hunterActive)spawnHunters();cam.x=worm.x-W/2;cam.y=worm.y-H/2;document.getElementById('gameOver').style.display='none';document.getElementById('hint').textContent='Dica: pegue moedas, use a Loja e fique de olho nos eventos.';updateHud()}
function setGameActive(active){document.body.classList.toggle('game-active',!!active);const a=document.getElementById('betaAttack');const m=document.getElementById('menuToggle');if(a)a.style.setProperty('display',active?'block':'none','important');if(m)m.style.setProperty('display',active?'block':'none','important');if(!active){document.body.classList.remove('modal-open','menuCollapsed')}}
function showIdleMenu(){document.body.classList.remove('modal-open');setGameActive(false);running=false;gameMode=null;setGameActive(false);document.body.classList.remove('local-multi');document.getElementById('gameOver').style.display='none';document.querySelectorAll('.modal').forEach(m=>m.style.display='none');document.getElementById('multiLobby').style.display='none';const s=document.getElementById('start'),m=document.getElementById('startMenu');if(loggedIn){s.style.display='none';m.style.display='grid';document.getElementById('menuPlayerName').textContent=playerName}else{m.style.display='none';s.style.display='grid'}}
function closeMainMenus(){running=false;setGameActive(false);document.getElementById('start').style.display='none';document.getElementById('startMenu').style.display='none';document.querySelectorAll('.modal').forEach(m=>m.style.display='none');document.getElementById('gameOver').style.display='none'}
function begin(mode){document.body.classList.remove('modal-open');if(!loggedIn||(mode!=='bots'&&mode!=='multiplayer')){showIdleMenu();return}if(mode==='multiplayer'&&multiRole==='guest'&&(!peerConn||!multiConnected)){showNotice('Conecte-se a uma sala primeiro.',4000);return}closeMainMenus();gameMode=mode;resetRun();running=true;setGameActive(true);updateMultiRoomHud();const h=document.getElementById('modeLabel');if(h)h.textContent=mode==='bots'?'MODO BOTS':'MULTIPLAYER ONLINE';last=performance.now();lastNet=0;areaSound();worldDraw();requestAnimationFrame(loop)}
function currentCredentials(){return {n:document.getElementById('playerName').value.trim(),p:document.getElementById('playerPass').value,err:document.getElementById('playerLoginError')}}
function enterMainMenu(){showIdleMenu();document.getElementById('menuPlayerName').textContent=playerName;document.getElementById('beginnerTip').textContent='Dica de iniciante: coma as comidas pequenas, pegue moedas no caminho e só enfrente cobras maiores quando tiver espaço.';ensureAudio();tone(520,.12,'triangle',.06,760)}
function doRegister(){const {n,p}=currentCredentials();if(n.length<2||p.length<4){showLoginMsg('Use nome de 2+ caracteres e senha de 4+.');return}const r=register(n,p);if(r.error){showLoginMsg(r.error);return}applyProfile(r.key,r.p);window.__applyProfileExtras?.(r.p);document.getElementById('accountStatus').textContent=`Conectado: ${playerName}`;enterMainMenu()}
function doLogin(){const {n,p}=currentCredentials();if(n.length<2||p.length<4){showLoginMsg('Use nome de 2+ caracteres e senha de 4+.');return}const r=login(n,p);if(r.error){showLoginMsg(r.error);return}applyProfile(r.key,r.p);window.__applyProfileExtras?.(r.p);document.getElementById('accountStatus').textContent=r.created?`Conta criada e conectada: ${playerName}`:`Conectado: ${playerName}`;enterMainMenu()}
document.getElementById('agilityBuy').onclick=buyAgility;document.getElementById('spinBuy')?.addEventListener('click',()=>{if(money>=4500){money-=4500;if(window.__unlockAttackLevel)window.__unlockAttackLevel(2);save();showNotice('🌀 Ataque Giro comprado!',2500);buySound();renderStore();updateHud()}});document.getElementById('dashBuy')?.addEventListener('click',()=>{if(money>=7500){money-=7500;if(window.__unlockAttackLevel)window.__unlockAttackLevel(3);save();showNotice('⚡ Investida comprada!',2500);buySound();renderStore();updateHud()}});document.getElementById('mass5').onclick=()=>buyMass(5,700);document.getElementById('mass20').onclick=()=>buyMass(20,2200);document.getElementById('mass50').onclick=()=>buyMass(50,5000);document.getElementById('lavaPotionBuy').onclick=buyLavaPotion;document.getElementById('doRegister').onclick=e=>{e.preventDefault();doRegister()};document.getElementById('doLogin').onclick=e=>{e.preventDefault();doLogin()};document.getElementById('playerPass').onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();doLogin()}};document.getElementById('playerName').onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();doLogin()}};document.getElementById('playBots').onclick=e=>{e.preventDefault();if(loggedIn){closeNetwork();closeMainMenus();begin('bots')}};function openMultiMenu(){if(!loggedIn)return;closeNetwork();setGameActive(false);running=false;gameMode=null;document.getElementById('start').style.display='none';document.getElementById('startMenu').style.display='none';document.querySelectorAll('.modal').forEach(m=>m.style.display='none');const lobby=document.getElementById('multiLobby');if(lobby){document.body.classList.add('modal-open');lobby.style.display='grid'}}document.getElementById('playMulti').onclick=e=>{e.preventDefault();openMultiMenu()};
function toggleStationary(){stationary=!stationary;const b=document.getElementById('still');b.classList.toggle('on',stationary);b.textContent=stationary?'ANDANDO':'PARADO'}
function playerInput(){let ax=(keys.d?1:0)-(keys.a?1:0),ay=(keys.s?1:0)-(keys.w?1:0);if(gameMode!=='multiplayer'){if(keys.arrowright||keys.right)ax=1;if(keys.arrowleft||keys.left)ax=-1;if(keys.arrowdown||keys.down)ay=1;if(keys.arrowup||keys.up)ay=-1}if(joystick.x||joystick.y){ax=joystick.x;ay=joystick.y}return [ax,ay]}
function updatePlayer(dt){if(stationary)return;let [ax,ay]=playerInput();if(ax||ay)worm.ang=Math.atan2(ay,ax);const turbo=boosting&&energy>1,turboSpeed=235+turboLevel*20+agilityLevel*12+(adminBoost?70:0),speed=turbo?turboSpeed:132+worm.level*1.25+agilityLevel*5;if(turbo)energy=Math.max(0,energy-dt*Math.max(10,22-turboLevel*2));else energy=Math.min(100,energy+dt*11);const ox=worm.x,oy=worm.y;const prevZone=zoneAt(ox);worm.x=clamp(worm.x+Math.cos(worm.ang)*speed*dt,40,world.w-40);worm.y=clamp(worm.y+Math.sin(worm.ang)*speed*dt,40,world.h-40);const z=zoneAt(worm.x);
// Entrada no Vulcão sempre exige Poção de Lava. O requisito é checado
// antes de cobrar o desbloqueio para não gastar moedas e depois expulsar o jogador.
const enteringVolcano = z===5 && prevZone!==5 && lavaProtection<=0;
if(enteringVolcano && lavaPotion<=0){
  worm.x=ox; worm.y=oy;
  if(Date.now()-lastLavaWarnAt>2200){
    lastLavaWarnAt=Date.now();
    warningSound();
    showNotice('🧪 Para ENTRAR no Vulcão você precisa de uma Poção de Lava.',3500);
  }
  return;
}

// Desbloqueio de área: com dinheiro suficiente, atravessar a fronteira libera
// imediatamente a área e cobra uma única vez.
if(z>unlocked){
  const cost=zones[z].cost;
  if(money<cost){
    worm.x=ox; worm.y=oy;
    const faltam=Math.max(0,Math.ceil(cost-money));
    if(Date.now()-lastLavaWarnAt>1800){
      lastLavaWarnAt=Date.now();
      warningSound();
      showNotice(`🔒 ${zones[z].name} bloqueada. Faltam ${faltam} moedas.`,3200);
    }
    return;
  }
  money-=cost;
  unlocked=z;
  selectedSkin=zones[z].skin;
  worm.color=skins[selectedSkin].a;
  worm.skinIndex=selectedSkin;
  worm.skinName=skins[selectedSkin].name;
  worm.pattern=skins[selectedSkin].pattern;
  save();
  showUnlock(z);
  renderStore();
  updateHud();
}

if(enteringVolcano){
  lavaPotion--;
  lavaProtection=30;
  lavaDamageClock=0;
  showNotice('🧪 Poção usada! Você pode entrar no Vulcão por 30s.',3000);
  buySound();
  save();
  updateHud();
}

if(z!==lastZone){if(lastZone!==-1)areaSound();lastZone=z}
worm.body.unshift({x:worm.x,y:worm.y});
const sp=Math.max(9,worm.r*.72);
while(worm.body.length<worm.len)worm.body.push({...worm.body[worm.body.length-1]});
while(worm.body.length>worm.len)worm.body.pop()}
function updatePlayer2(dt){if(!player2)return;let ax=(keys.l?1:0)-(keys.j?1:0),ay=(keys.k?1:0)-(keys.i?1:0);if(keys.right||keys.arrowright)ax=1;if(keys.left||keys.arrowleft)ax=-1;if(keys.down||keys.arrowdown)ay=1;if(keys.up||keys.arrowup)ay=-1;if(ax||ay)player2.ang=Math.atan2(ay,ax);player2.x=clamp(player2.x+Math.cos(player2.ang)*145*dt,40,world.w-40);player2.y=clamp(player2.y+Math.sin(player2.ang)*145*dt,40,world.h-40);player2.body.unshift({x:player2.x,y:player2.y});while(player2.body.length<player2.len)player2.body.push({...player2.body[player2.body.length-1]});while(player2.body.length>player2.len)player2.body.pop()}
function addXp(a,n){a.xp+=n;let need=40+a.level*28;while(a.xp>=need){a.xp-=need;const oldLen=a.len;a.level++;a.len+=a.id==='player'?2:1;a.r=Math.min(40,10+Math.sqrt(a.len)*1.9);a.speed=Math.min(96,a.speed+1.4);if(a.id!=='player'){a.maxHp=Math.max(20,a.len*3+a.level*10);a.hp=Math.min(a.maxHp,(a.hp||a.maxHp)+8);if(a.level%3===0){a.skinIndex=((a.skinIndex??0)+1)%skins.length;const sk=skins[a.skinIndex];a.skinName=sk.name;a.color=sk.a;a.pattern=sk.pattern;a.bubble=`EVOLUIU: ${sk.name}`;a.bubbleT=1.8;}}if(a.id==='player'){if(a.level===30){if(window.__unlockAttackLevel)window.__unlockAttackLevel(2);if(window.awardAchievement)window.awardAchievement('level30');showNotice('🌀 Ataque Giro desbloqueado no nível 30!',3500);evolveSound()}if(a.level===60){if(window.__unlockAttackLevel)window.__unlockAttackLevel(3);showNotice('⚡ Investida desbloqueada no nível 60!',3500);evolveSound()}const reward=Math.max(5,Math.ceil(oldLen/3));money+=reward;save();showNotice(`EVOLUÇÃO! +${reward} moedas`,4000);evolveSound()}else{a.bubble='EVOLUI';a.bubbleT=1.7}need=40+a.level*28;addParticle(a.x,a.y,'#e9bdff',10)}}
function addParticle(px,py,col,n=8){for(let i=0;i<n;i++)particles.push({x:px,y:py,vx:rnd(-70,70),vy:rnd(-70,70),life:rnd(.35,.8),col})}
function steer(a,tx,ty,dt,turn){let wanted=Math.atan2(ty-a.y,tx-a.x),d=wanted-a.ang;while(d>Math.PI)d-=Math.PI*2;while(d<-Math.PI)d+=Math.PI*2;a.ang+=clamp(d,-turn*dt,turn*dt)}
function dangerToPlayer(a){if(!worm)return false;for(let i=4;i<Math.min(worm.body.length,55);i+=4)if(dist(a,worm.body[i])<70)return true;return dist(a,worm)<140}
function npcAI(a,dt){a.think-=dt;if(a.think<=0){a.think=rnd(.2,.55);a.orbit+=rnd(-.8,.8)}const pd=dist(worm,a);let target=a.foodTarget&&a.foodTarget.x>0?a.foodTarget:null;if((a.foodThink||0)<=0){a.foodThink=.22;let bestD=600;target=null;for(let fi=0;fi<foods.length;fi+=4){const f=foods[fi];if(f.x<0)continue;const d=dist(a,f);if(d<bestD){bestD=d;target=f}}a.foodTarget=target}let coinTarget=null,coinD=500;for(let ci=0;ci<coins.length;ci+=2){const cc=coins[ci];const d=dist(a,cc);if(d<coinD){coinD=d;coinTarget=cc}}a.foodThink=(a.foodThink||0)-dt;let enemy=null,enemyD=950;for(const b of critters){if(b===a)continue;const d=dist(a,b);if(d<enemyD){enemyD=d;enemy=b}}
 let tx=a.x+Math.cos(a.ang)*120,ty=a.y+Math.sin(a.ang)*120;
 // Cobras neutras não perseguem o jogador: elas procuram comida/moedas e mantêm distância.
 if(!a.damageDealer){
   if(coinTarget){tx=coinTarget.x;ty=coinTarget.y}
   else if(target){tx=target.x;ty=target.y}
   else {tx=a.x+Math.cos(a.orbit)*260;ty=a.y+Math.sin(a.orbit)*260}
   if(pd<210){const away=Math.atan2(a.y-worm.y,a.x-worm.x);tx=a.x+Math.cos(away)*260;ty=a.y+Math.sin(away)*260}
   steer(a,tx,ty,dt,2.2);a.x=clamp(a.x+Math.cos(a.ang)*a.speed*.9*dt,90,world.w-90);a.y=clamp(a.y+Math.sin(a.ang)*a.speed*.9*dt,90,world.h-90);a.currentZone=zoneAt(a.x);smoothBody(a);return
 }
 if(coinTarget){tx=coinTarget.x;ty=coinTarget.y}
 else if(a.aiKind==='pastadora'){if(target){tx=target.x;ty=target.y}}
 else if(a.aiKind==='duelista'||a.aiKind==='dominante'){if(enemy&&enemy.len<a.len){tx=enemy.x;ty=enemy.y}else if(pd<850){tx=worm.x;ty=worm.y}else if(target){tx=target.x;ty=target.y}}
 else if(a.aiKind==='cercadora'&&a.len>15){const ang=a.orbit+a.id*.73,rad=150+Math.min(90,a.len*2);if(pd<900){tx=worm.x+Math.cos(ang)*rad;ty=worm.y+Math.sin(ang)*rad}else if(target){tx=target.x;ty=target.y}}
 else if(a.aiKind==='interceptadora'&&pd<1000){tx=worm.x+Math.cos(worm.ang)*130;ty=worm.y+Math.sin(worm.ang)*130}
 else if(a.aiKind==='patrulheira'){tx=a.x+Math.cos(a.orbit)*280;ty=a.y+Math.sin(a.orbit)*280}
 else if(target){tx=target.x;ty=target.y}
 if(a.damageDealer&&pd<1250){tx=worm.x;ty=worm.y}
 if(dangerToPlayer(a)&&!a.damageDealer&&a.aiKind!=='cercadora'){const away=Math.atan2(a.y-worm.y,a.x-worm.x);tx=a.x+Math.cos(away)*220;ty=a.y+Math.sin(away)*220}
 steer(a,tx,ty,dt,a.aiKind==='cercadora'?2.0:3.0);if(Math.random()<dt*.7)a.ang+=rnd(-.2,.2);const mul=a.aiKind==='interceptadora'?1.08:a.aiKind==='cercadora'?.95:1;a.x=clamp(a.x+Math.cos(a.ang)*a.speed*mul*dt,90,world.w-90);a.y=clamp(a.y+Math.sin(a.ang)*a.speed*mul*dt,90,world.h-90);a.currentZone=zoneAt(a.x);smoothBody(a)}
function segmentHit(head,body,start,threshold){for(let i=Math.max(1,start);i<body.length;i++){if(dist(head,body[i])<threshold)return i}return -1}
function dropCoins(px,py,total){const count=Math.min(14,Math.max(3,Math.ceil(total/6)));let left=total;for(let i=0;i<count;i++){const v=i===count-1?left:Math.max(1,Math.floor(total/count));left-=v;coins.push({x:px+rnd(-26,26),y:py+rnd(-26,26),r:9,value:v,life:45,pulse:rnd(0,6)})}}
function defeatNpc(a){worm.kills=(worm.kills||0)+1;addXp(worm,Math.max(20,a.len*8));dropCoins(a.x,a.y,Math.max(5,Math.round(a.len*2+a.level*3)));addParticle(a.x,a.y,'#ffd65b',18);critters=critters.filter(v=>v!==a);showKillNotice(`${a.name} caiu! Pegue as moedas que ela deixou.`)}
function resolveNpcCombat(){const deaths=new Set();for(const a of critters){for(const b of critters){if(a===b)continue;if(segmentHit(a.body[0],b.body,4,Math.max(9,(a.r+b.r)*.48))>=0){deaths.add(a.id);b.kills=(b.kills||0)+1;addXp(b,Math.max(20,a.len*9));b.bubble=`Venci ${a.name}`;b.bubbleT=1.8;break}}}for(const id of deaths){const victim=critters.find(v=>v.id===id);if(victim){dropCoins(victim.x,victim.y,Math.max(4,Math.round(victim.len*1.7)));addParticle(victim.x,victim.y,'#f9c94d',12)}}critters=critters.filter(a=>!deaths.has(a.id))}
function hunterAI(h,dt){const target=worm;if(!target)return;const bd=dist(h,target);const tx=target.x+Math.cos(target.ang)*Math.min(170,bd*.42),ty=target.y+Math.sin(target.ang)*Math.min(170,bd*.42);steer(h,tx,ty,dt,3.5);h.x=clamp(h.x+Math.cos(h.ang||0)*h.type.speed*(bd>700?1.45:1.75)*dt,50,world.w-50);h.y=clamp(h.y+Math.sin(h.ang||0)*h.type.speed*1.12*dt,50,world.h-50);h.phase+=dt*5;if(dist(h,worm)<h.type.size*.55+worm.r){ensureAudio();melody([740,520,360,240,160]);tone(90,.8,'sawtooth',.28,55);showNotice(`🦅 ${h.type.name} te pegou!`,1400);die('Uma águia te alcançou.');return}}
function updateHunters(dt){if(gameMode!=='bots'||!hunterActive)return;hunters.forEach(h=>hunterAI(h,dt))}
function checkPlayerCombat(){for(const a of [...critters]){if(segmentHit(a.body[0],worm.body,3,Math.max(10,(worm.r+a.r)*.56))>=0){defeatNpc(a)}if(segmentHit(worm.body[0],a.body,3,Math.max(10,(worm.r+a.r)*.56))>=0){die('Sua cabeça bateu na cauda de uma cobra.');return true}}return false}
function collectCoins(){for(let i=coins.length-1;i>=0;i--){const cc=coins[i];cc.pulse+=.12;cc.life-=1/60;if(cc.life<=0){coins.splice(i,1);continue}if(dist(worm,cc)<worm.r+cc.r+5){money+=cc.value;coinSound();coins.splice(i,1);save();continue}if(player2&&dist(player2,cc)<player2.r+cc.r+5){coins.splice(i,1);continue}for(const a of critters){if(dist(a,cc)<a.r+cc.r+5){a.wallet+=cc.value;coins.splice(i,1);break}}}}
function refillSnakes(dt){if(gameMode!=='bots')return;const n=critters.length;if(n>=SNAKE_CAP)return;const interval=n<=10?.2:n<=15?.36:0.65;spawnClock+=dt;if(spawnClock>=interval){spawnClock=0;const burst=n<=10?3:n<=15?2:1;for(let i=0;i<burst&&critters.length<SNAKE_CAP;i++)spawnOne()}}
function update(dt){if(!running||!worm)return;window.__monsterTick?.(dt);updateEvent(dt);autoSaveTimer+=dt;if(autoSaveTimer>8){autoSaveTimer=0;save()};updatePlayer(dt);if(gameMode==='multiplayer'){if(checkOnlineCombat())return}else updatePlayer2(dt);updateHunters(dt);foodCollisionClock-=dt;if(foodCollisionClock<=0){foodCollisionClock=.05;for(const f of foods){if(f.x>0&&dist(worm,f)<worm.r+f.r+5){const ev=currentEvent();addXp(worm,f.v*7*ev.xp*((xpBoostCharges>0||xpBoostTime>0)?1.35:1));if(ev.coin)money+=ev.coin;f.x=-999;eatSound();updateHud();break}}}lavaEatClock=Math.max(0,lavaEatClock-dt);for(const lv of lavaSpots)lv.phase+=dt*2;if(gameMode==='bots'){for(const a of critters){npcAI(a,dt);if((a.foodHitClock||0)<=0){a.foodHitClock=.08;for(let fi=0;fi<foods.length;fi+=3){const f=foods[fi];if(f.x>0&&dist(a,f)<a.r+f.r+4){addXp(a,f.v*7);f.x=-999;break}}}a.foodHitClock-=dt}npcCombatClock-=dt;if(npcCombatClock<=0){npcCombatClock=.08;resolveNpcCombat()}if(checkPlayerCombat())return;refillSnakes(dt)}collectCoins();foods=foods.filter(f=>f.x>0);while(foods.length<220)addFood();for(const p of particles){p.x+=p.vx*dt;p.y+=p.vy*dt;p.life-=dt}particles=particles.filter(p=>p.life>0);for(const a of critters)if(a.bubbleT>0)a.bubbleT-=dt;cam.x+=(worm.x-W/2-cam.x)*.08;cam.y+=(worm.y-H/2-cam.y)*.08;cam.x=clamp(cam.x,0,Math.max(0,world.w-W));cam.y=clamp(cam.y,0,Math.max(0,world.h-H));const all=[worm,...onlineList(),...critters];largestId=all.reduce((id,a)=>{const cur=all.find(v=>v.id===id);return !cur||a.len>cur.len?a.id:id},-1);best=Math.max(best,worm.len);updateHud()}
function skinFor(a){if(a.id==='player')return skins[selectedSkin];if(a.id==='player2')return {a:'#6ed7ff',b:'#1f7fbd',c:'#c5f7ff',pattern:'waves'};if(Number.isInteger(a.skinIndex)&&skins[a.skinIndex])return skins[a.skinIndex];return {a:a.color,b:a.color,c:'#fff',pattern:a.pattern}}
function drawWorm(a){const body=a.body||[],s=skinFor(a),h=body[0]||a;if(body.length){for(let i=body.length-1;i>=0;i--){const b=body[i],t=i/Math.max(1,body.length-1);let col=s.a;if(s.pattern==='bands')col=Math.floor(i/3)%2?s.a:s.b;else if(s.pattern==='rings')col=i%4===0?s.c:s.a;else if(s.pattern==='waves')col=i%2?s.a:s.b;else if(s.pattern==='flame')col=i%4<2?s.a:s.b;else if(s.pattern==='galaxy')col=i%5===0?s.c:s.b;else if(s.pattern==='scales')col=i%3===0?s.c:s.a;else if(s.pattern==='sun')col=i%4<2?s.a:s.b;else if(s.pattern==='aurora')col=i%3===0?s.c:(i%3===1?s.a:s.b);else if(s.pattern==='storm')col=i%4===0?s.c:s.b;else if(s.pattern==='prism')col=['#ff6aa9','#73e6ff','#ffe56a','#9cff77'][i%4];else if(s.pattern==='shine')col=i%4===0?s.c:(i%4===1?s.a:s.b);else if(s.pattern==='metal')col=i%3===0?s.c:(i%3===1?s.a:s.b);x.fillStyle=col;x.beginPath();x.arc(b.x,b.y,Math.max(5,a.r*(.92-t*.08)),0,Math.PI*2);x.fill();if(i%4===0){x.fillStyle='#ffffff55';x.beginPath();x.arc(b.x-a.r*.22,b.y-a.r*.22,Math.max(1.5,a.r*.12),0,Math.PI*2);x.fill()}}}x.fillStyle=s.b;x.beginPath();x.arc(h.x,h.y,a.r*1.05,0,Math.PI*2);x.fill();x.fillStyle=s.a;x.beginPath();x.arc(h.x,h.y,a.r*.76,0,Math.PI*2);x.fill();x.fillStyle='#102015';x.beginPath();x.arc(h.x+Math.cos(a.ang+0.55)*5,h.y+Math.sin(a.ang+0.55)*5,2.7,0,Math.PI*2);x.arc(h.x+Math.cos(a.ang-0.55)*5,h.y+Math.sin(a.ang-0.55)*5,2.7,0,Math.PI*2);x.fill();x.fillStyle='#fff';x.font='800 11px system-ui';x.textAlign='center';x.fillText(`${a.name}${a.id==='player'?' • VOCÊ':''} • Lv.${a.level}${a.id!=='player'&&a.skinName?` • ${a.skinName}`:''}`,h.x,h.y-a.r-10);if(a.id===largestId){x.fillStyle='#ffe37a';x.font='900 12px system-ui';x.fillText('👑 TOP 1',h.x,h.y-a.r-25)}}
function drawEventObjects(){for(const o of eventObjects.coins){if(o.x<0)continue;x.fillStyle='#ffe066';x.beginPath();x.arc(o.x,o.y,o.r+Math.sin(performance.now()/140+o.x)*2,0,Math.PI*2);x.fill();x.fillStyle='#765400';x.font='900 9px system-ui';x.textAlign='center';x.textBaseline='middle';x.fillText('$',o.x,o.y)}for(const o of eventObjects.chests){if(o.open)continue;x.fillStyle='#8b572a';x.fillRect(o.x-16,o.y-12,32,24);x.fillStyle='#ffd65c';x.fillRect(o.x-3,o.y-12,6,24);x.fillRect(o.x-16,o.y-2,32,4)}for(const o of eventObjects.portals){if(o.x<0)continue;x.save();x.translate(o.x,o.y);x.rotate(o.spin);x.strokeStyle='#82d8ff';x.lineWidth=7;x.beginPath();x.ellipse(0,0,28,18,0,0,Math.PI*2);x.stroke();x.strokeStyle='#d9a5ff';x.lineWidth=3;x.beginPath();x.ellipse(0,0,19,12,0,0,Math.PI*2);x.stroke();x.restore()}for(const o of eventObjects.mobs){if(o.x<0)continue;x.save();x.translate(o.x,o.y+Math.sin(o.phase)*5);x.fillStyle=['#b86bff','#6de8ff','#7cff86','#ffd05c'][o.kind];x.beginPath();x.arc(0,0,20,0,Math.PI*2);x.fill();x.fillStyle='#fff';x.beginPath();x.arc(-7,-3,4,0,Math.PI*2);x.arc(7,-3,4,0,Math.PI*2);x.fill();x.fillStyle='#172018';x.beginPath();x.arc(-7,-3,2,0,Math.PI*2);x.arc(7,-3,2,0,Math.PI*2);x.fill();x.fillStyle='#fff';x.font='900 10px system-ui';x.textAlign='center';x.fillText('MOB',0,-27);x.restore()}for(const o of eventObjects.mega){if(o.x<0)continue;x.fillStyle='#ff8c54';x.beginPath();x.arc(o.x,o.y,o.r,0,Math.PI*2);x.fill();x.globalAlpha=.28;x.beginPath();x.arc(o.x,o.y,o.r*1.8,0,Math.PI*2);x.fill();x.globalAlpha=1}for(const o of eventObjects.aurora){const g=x.createRadialGradient(o.x,o.y,0,o.x,o.y,o.r);g.addColorStop(0,'#d2ffef77');g.addColorStop(1,'#8c63ff00');x.fillStyle=g;x.beginPath();x.arc(o.x,o.y,o.r,0,Math.PI*2);x.fill()}}
function drawHunter(h){x.save();x.translate(h.x,h.y);x.rotate(Math.sin(h.phase)*.08);const z=h.type.size;x.fillStyle='#3a2b22';x.beginPath();x.moveTo(0,z*.15);x.quadraticCurveTo(-z*1.45,-z*.95,-z*1.8,-z*.25);x.quadraticCurveTo(-z*1.05,-z*.2,-z*.35,z*.3);x.quadraticCurveTo(-z*1.35,z*.25,-z*1.55,z*.75);x.quadraticCurveTo(-z*.55,z*.5,0,z*.32);x.quadraticCurveTo(z*.55,z*.5,z*1.55,z*.75);x.quadraticCurveTo(z*1.35,z*.25,z*.35,z*.3);x.quadraticCurveTo(z*1.05,-z*.2,z*1.8,-z*.25);x.quadraticCurveTo(z*1.45,-z*.95,0,z*.15);x.fill();x.fillStyle='#ececec';x.beginPath();x.arc(0,-z*.25,z*.34,0,Math.PI*2);x.fill();x.fillStyle='#d6a22f';x.beginPath();x.moveTo(0,-z*.12);x.lineTo(z*.55,-z*.02);x.lineTo(0,z*.08);x.closePath();x.fill();x.fillStyle='#111';x.beginPath();x.arc(-z*.12,-z*.32,z*.045,0,Math.PI*2);x.arc(z*.12,-z*.32,z*.045,0,Math.PI*2);x.fill();x.fillStyle='#fff';x.font='900 11px system-ui';x.textAlign='center';x.fillText(h.type.name,0,z+18);x.restore()}
function drawFood(f){let c='#ff6d6d',label='';if(f.areaKind==='honey'){c=['#f5a623','#ffd45c','#fff0a3'][Math.floor(f.h/120)%3];label='🍯'}else if(f.areaKind==='tadpole'){c=['#79d66f','#b5ff8c','#4ca86b'][Math.floor(f.h/120)%3];label='🐟'}else if(f.kind==='candy')c=['#ff5f9a','#ffd15a','#7af0ff'][Math.floor(f.h/90)%3];else if(f.kind==='neon')c=['#ff4df0','#59f4ff','#9dff58','#ffe45a'][Math.floor(f.h/90)%4];else if(f.kind==='golden')c='#ffd24a';else if(f.kind==='rainbow')c=['#ff5d5d','#ffb84d','#f8ef54','#6ee66a','#62d5ff','#a77bff'][Math.floor(f.h/60)%6];else c=['#ff6d6d','#ffcf4d','#7ee57a','#7fd9ff'][Math.floor(f.h/90)%4];x.fillStyle=c;x.beginPath();x.arc(f.x,f.y,f.r,0,Math.PI*2);x.fill();x.globalAlpha=.35;x.fillStyle=c;x.beginPath();x.arc(f.x,f.y,f.r*1.8,0,Math.PI*2);x.fill();x.globalAlpha=1;if(label){x.font='900 12px system-ui';x.textAlign='center';x.textBaseline='middle';x.fillText(label,f.x,f.y-1)}}
function drawLava(lv){x.fillStyle='#ef4a1a';x.globalAlpha=.85;x.beginPath();x.ellipse(lv.x,lv.y,lv.r,lv.r*.62,Math.sin(lv.phase)*.15,0,Math.PI*2);x.fill();x.fillStyle='#ffd35a';x.globalAlpha=.7;x.beginPath();x.ellipse(lv.x+Math.sin(lv.phase)*6,lv.y-4,lv.r*.55,lv.r*.25,0,0,Math.PI*2);x.fill();x.globalAlpha=1}
function worldDraw(){const cz=zoneAt(cam.x+W/2);x.fillStyle=zones[cz].bg;x.fillRect(0,0,W,H);x.save();x.translate(-cam.x,-cam.y);for(const z of zones){x.fillStyle=z.bg;x.fillRect(z.start,0,z.end-z.start,world.h)}if(lavaTexture.complete&&lavaTexture.naturalWidth){x.save();x.beginPath();x.rect(zones[5].start,0,zones[5].end-zones[5].start,world.h);x.clip();x.globalAlpha=.88;const tw=520,th=347;for(let ty=0;ty<world.h;ty+=th){for(let tx=zones[5].start;tx<zones[5].end;tx+=tw){x.drawImage(lavaTexture,tx,ty,tw,th)}}x.globalAlpha=1;x.restore()}for(let i=Math.floor(cam.x/120)*120;i<cam.x+W+120;i+=120){x.strokeStyle='#ffffff10';x.beginPath();x.moveTo(i,cam.y);x.lineTo(i,cam.y+H);x.stroke()}if(zoneAt(cam.x+W/2)===5){lavaSpots.forEach(drawLava);x.fillStyle='#8f2419';x.globalAlpha=.9;x.beginPath();x.ellipse(lavaExitLake.x,lavaExitLake.y,lavaExitLake.rx,lavaExitLake.ry,0,0,Math.PI*2);x.fill();x.fillStyle='#ff8b24';x.globalAlpha=.55;x.beginPath();x.ellipse(lavaExitLake.x,lavaExitLake.y,lavaExitLake.rx*.72,lavaExitLake.ry*.58,0,0,Math.PI*2);x.fill();x.globalAlpha=1;x.fillStyle='#fff0b0';x.font='900 18px system-ui';x.textAlign='center';x.fillText('🌋 LAGO DE LAVA • POÇÃO NECESSÁRIA',lavaExitLake.x,lavaExitLake.y); }if(window.__drawMonsterAreaTerrain)window.__drawMonsterAreaTerrain();drawEventObjects();for(const f of foods){if(f.x<0)continue;if(f.x<cam.x-40||f.x>cam.x+W+40||f.y<cam.y-40||f.y>cam.y+H+40)continue;drawFood(f)}if(activeEvent!=='normal'){x.fillStyle=currentEvent().color||'#fff';x.font='900 14px system-ui';x.textAlign='center';x.fillText(`EVENTO: ${currentEvent().name} • ${Math.ceil(eventTimer)}s`,cam.x+W/2,cam.y+36);if(activeEvent==='eclipse'){x.fillStyle='#09051d55';x.fillRect(cam.x,cam.y,W,H)}if(activeEvent==='neon'){x.fillStyle='#5cfaff12';x.fillRect(cam.x,cam.y,W,H)}}for(const cc of coins){if(cc.x<cam.x-50||cc.x>cam.x+W+50||cc.y<cam.y-50||cc.y>cam.y+H+50)continue;x.fillStyle='#ffd54d';x.beginPath();x.ellipse(cc.x,cc.y,cc.r*.7,cc.r,0,0,Math.PI*2);x.fill();x.fillStyle='#855d00';x.font='900 10px system-ui';x.textAlign='center';x.textBaseline='middle';x.fillText('$',cc.x,cc.y)}if(gameMode==='bots'&&hunterActive)hunters.forEach(drawHunter);if(window.__drawMonsterAreas)window.__drawMonsterAreas();if(gameMode==='bots')critters.forEach(drawWorm);for(const a of onlineList())drawWorm(a);if(worm)drawWorm(worm);for(const p of particles){x.globalAlpha=Math.max(0,p.life/.8);x.fillStyle=p.col;x.beginPath();x.arc(p.x,p.y,4,0,Math.PI*2);x.fill()}x.globalAlpha=1;x.restore()}

function updateHud(){document.getElementById('stats').textContent=`Tamanho: ${worm?Math.round((Number(worm.len)||8)*100)/100:8} • ${score} pts`;document.getElementById('evo').textContent=`${stage(worm?worm.level:1)} • Lv.${worm?worm.level:1}`;document.getElementById('xp').style.width=Math.min(100,((worm?worm.xp:0)/(40+(worm?worm.level:1)*28))*100)+'%';document.getElementById('zone').textContent=zones[zoneAt(worm?worm.x:0)].name;document.getElementById('money').textContent=Math.floor(money);document.getElementById('best').textContent=best;if(!skins[selectedSkin])selectedSkin=0;document.getElementById('skinName').textContent=skins[selectedSkin].name;document.getElementById('userName').textContent=playerName||'Visitante';document.getElementById('snakeCount').textContent=gameMode==='bots'?`${critters.length}/${SNAKE_CAP}`:gameMode==='multiplayer'?`${Math.min(MAX_ONLINE_PLAYERS,1+onlineList().length)}/${MAX_ONLINE_PLAYERS}`:'0';document.getElementById('hunterCount').textContent=gameMode==='bots'&&hunterActive?hunters.length:0;const evEl=document.getElementById('eventHud');if(evEl)evEl.textContent=activeEvent==='normal'?'EVENTO: normal':`EVENTO: ${currentEvent().name} • ${Math.ceil(eventTimer)}s`;const lpEl=document.getElementById('lavaPotionHud');if(lpEl)lpEl.textContent=`Poções de lava: ${lavaPotion}`}
function showUnlock(i){if(window.awardAchievement)window.awardAchievement('area');const p=document.getElementById('areaPanel');p.style.display='block';document.getElementById('areaTitle').textContent=`${zones[i].name} liberada`;document.getElementById('areaUnlock').textContent=`Skin ${skins[i].name} equipada.`;showNotice(`${zones[i].name} liberada • Skin ${skins[i].name} equipada.`);setTimeout(()=>p.style.display='none',4000)}
function wipeOnDeath(){money=0;unlocked=0;selectedSkin=0;activeEvent='normal';eventTimer=0;clearEventObjects();portalCharges=0;coinMagnetCharges=0;growthPotionCharges=0;xpBoostCharges=0;eventTokens=0;save()}
function die(msg){running=false;setGameActive(false);wipeOnDeath();document.getElementById('deathText').textContent=msg;document.getElementById('gameOver').style.display='grid'}
function openModal(id){document.querySelectorAll('.modal').forEach(m=>m.style.display='none');const el=document.getElementById(id);if(!el)return;document.body.classList.add('modal-open');el.style.display='grid';if(id==='store')renderStore();if(id==='rank')renderRank();if(id==='hunters')renderHunters();if(id==='chat')renderChat()}
function buyTurbo(){const cost=[0,350,800,1800,3500][turboLevel];if(turboLevel>=5||money<cost){showNotice('Moedas insuficientes para o turbo.',4000);return}money-=cost;turboLevel++;buySound();save();renderStore();updateHud();showNotice(`Turbo agora é nível ${turboLevel}.`,4000)}
function buyAgility(){const cost=[0,450,1000,2200,4000][agilityLevel];if(agilityLevel>=5||money<cost){showNotice('Moedas insuficientes para agilidade.',4000);return}money-=cost;agilityLevel++;buySound();save();renderStore();updateHud();showNotice(`Agilidade agora é nível ${agilityLevel}.`,4000)}
function buyMass(amount,cost){if(!worm){showNotice('Comece uma partida primeiro para comprar massa.',4000);return}if(money<cost){showNotice('Moedas insuficientes para comprar massa.',4000);return}money-=cost;worm.len+=amount;worm.r=Math.min(40,10+Math.sqrt(worm.len)*1.9);rebuildBody(worm);buySound();save();renderStore();updateHud();showNotice(`+${amount} de corpo comprado por ${cost} moedas.`,4000)}
function buyLavaPotion(){const cost=5000;if(money<cost){showNotice('A Poção de Lava custa 5.000 moedas.',4000);return}money-=cost;lavaPotion++;buySound();save();renderStore();updateHud();showNotice('Poção de Lava comprada. Você pode comer lava no Vulcão.',4000)}
function buyItem(key,cost){if(money<cost){showNotice('Moedas insuficientes.',4000);warningSound();return}money-=cost;if(key==='portal')portalCharges++;if(key==='magnet')coinMagnetCharges++;if(key==='growth')growthPotionCharges++;if(key==='xp')xpBoostCharges++;buySound();save();renderStore();updateHud();showNotice('Item comprado e salvo na conta.',4000)}
function usePortal(){if(!worm||portalCharges<=0){showNotice('Sem Portal de Área.',4000);return}const next=Math.min(zones.length-1,unlocked+1);if(next===unlocked){showNotice('Você já liberou a última área.',4000);return}if(next===5&&lavaPotion<=0){showNotice('🔥 Esse portal atravessa a área de lava. Você precisa de uma Poção de Lava.',3500);return}portalCharges--;if(next===5)lavaPotion--;unlocked=next;selectedSkin=next;worm.x=zones[next].start+300;worm.color=skins[selectedSkin].a;rebuildBody(worm);portalSound();areaSound();save();renderStore();updateHud();showNotice(`Portal ativado: ${zones[next].name}!${next===6?' A poção te protegeu do fogo.':''}`,4000)}
function useGrowthPotion(){if(growthPotionCharges<=0||!worm){showNotice('Sem Poção de Crescimento.',4000);return}growthPotionCharges--;growthPotionTime=30;save();renderStore();updateHud();showNotice('🧪 Poção de Corpo ativa por 30s!',2500);evolveSound()}
function useXpBoost(){if(xpBoostCharges<=0||!worm){showNotice('Sem Poção de XP.',4000);return}xpBoostCharges--;xpBoostTime=30;save();renderStore();updateHud();showNotice('🧪 Poção de XP ativa por 30s!',2500);evolveSound()}
function renderStore(){const grid=document.getElementById('skinGrid');if(!grid)return;grid.innerHTML='';for(let i=0;i<skins.length;i++){const ok=i<=unlocked,b=document.createElement('button');b.className='skinCard'+(i===selectedSkin?' selected':'')+(ok?'':' locked');b.disabled=!ok;b.innerHTML=`<span class="skinPreview pattern-${skins[i].pattern}" style="--a:${skins[i].a};--b:${skins[i].b};--c:${skins[i].c}"></span><span><b>${skins[i].name}</b><small>${ok?'Desbloqueada':'Desbloqueie a área correspondente'}</small></span>`;b.onclick=()=>{selectedSkin=i;if(worm)worm.color=skins[i].a;buySound();save();renderStore()};grid.appendChild(b)}const cost=[0,350,800,1800,3500][turboLevel]||0;document.getElementById('turboInfo').textContent=turboLevel>=5?'Nível MAX':`Nível ${turboLevel}/5 • Próximo ${cost} moedas`;const bt=document.getElementById('turboBuy');bt.disabled=turboLevel>=5||money<cost;bt.textContent=turboLevel>=5?'MAX':`UPGRADE • ${cost}`;const agCost=[0,450,1000,2200,4000][agilityLevel]||0;const ai=document.getElementById('agilityInfo');if(ai)ai.textContent=agilityLevel>=5?'Nível MAX':`Nível ${agilityLevel}/5 • Próximo ${agCost} moedas`;const ab=document.getElementById('agilityBuy');if(ab){ab.disabled=agilityLevel>=5||money<agCost;ab.textContent=agilityLevel>=5?'MAX':`UPGRADE • ${agCost}`}const lp=document.getElementById('lavaPotionInfo');if(lp)lp.textContent=`Você possui ${lavaPotion}`;const pi=document.getElementById('portalInfo');if(pi)pi.textContent=`Você possui ${portalCharges}`;const mi=document.getElementById('swampPotionInfo');if(mi)mi.textContent=`Você possui ${window.__swampPotion||0} • Permite entrar no Pantanal`;const gi=document.getElementById('growthInfo');if(gi)gi.textContent=`Você possui ${growthPotionCharges}`;const xi=document.getElementById('xpInfo');if(xi)xi.textContent=`Você possui ${xpBoostCharges}`;const mb1=document.getElementById('mass5');if(mb1)mb1.disabled=money<700;const mb2=document.getElementById('mass20');if(mb2)mb2.disabled=money<2200;const mb3=document.getElementById('mass50');if(mb3)mb3.disabled=money<5000} 

function renderRank(){const all=[...(worm?[worm]:[]),...onlineList(),...critters],sorted=all.slice().sort((a,b)=>(b.len-a.len)||(b.level-a.level)||((b.kills||0)-(a.kills||0)));const list=sorted.slice(0,18);const myPos=worm?sorted.findIndex(a=>a.id==='player')+1:0;document.getElementById('rankPlayer').textContent=`Sua posição: ${myPos||'-'}º • ${worm?worm.name:playerName||'Você'} • ${worm?worm.len:8} corpo • Lv.${worm?worm.level:1}`;document.getElementById('rankList').innerHTML=list.map((a,i)=>`<div class="row"><b>#${i+1}${a===sorted[0]?' 👑':''}</b><span>${a.name}${a.id==='player'?' • VOCÊ':''}</span><small>Lv.${a.level} • ${a.len} corpo • ${a.kills||0} vitórias • ${a.currentZone!==undefined?(zones[a.currentZone]?.name||'Online'):'Online'}</small></div>`).join('');document.getElementById('rankMeta').textContent=myPos>18?`Você está em ${myPos}º lugar agora. O ranking usa o tamanho real das cobras; a maior fica no topo com coroa.`:'O ranking usa o tamanho real das cobras; a maior fica no topo com coroa.'}
function renderHunters(){document.getElementById('hunterList').innerHTML=hunterTypes.map((t,i)=>`<div class="row hunterRow"><span class="hunterMini"></span><span><b>${t.name}</b><small>${hunters[i]?'NO MAPA':'FORA DO MAPA'} • velocidade ${t.speed}</small></span><small>${hunterActive?'ATIVA':'PAUSADA'}</small></div>`).join('')}
function npcReply(text){const q=text.toLowerCase(),a=critters[Math.floor(Math.random()*Math.max(1,critters.length))]||{name:'Luna',mood:'curiosa',trait:'observadora',level:1,len:8,currentZone:0};if(q.includes('onde'))return `${a.name}: eu estou em ${zones[a.currentZone||0].name}.`;if(q.includes('águia'))return `${a.name}: as águias estão caçando de verdade.`;if(q.includes('coroa'))return `${a.name}: quem crescer mais sobe para o topo.`;if(q.includes('morrer'))return `${a.name}: cauda é perigo. Eu também tenho que desviar.`;if(q.includes('oi')||q.includes('ola')||q.includes('olá'))return `${a.name}: oi! Estou no nível ${a.level} e tenho ${a.len} de corpo.`;return `${a.name}: sou ${a.trait}. Estou explorando o mapa e procurando moedas.`}
function renderChat(){const box=document.getElementById('chatLog');box.innerHTML=chatMessages.slice(-18).map(m=>`<div class="chatLine ${m.me?'me':''}"><b>${m.me?'Você':m.name}</b><span>${m.text}</span></div>`).join('');box.scrollTop=box.scrollHeight}
function sendChat(){const input=document.getElementById('chatInput'),t=input.value.trim();if(!t)return;chatMessages.push({me:true,name:playerName,text:t});if(gameMode==='multiplayer'){sendNetworkChat(t)}else{const r=npcReply(t),p=r.indexOf(':');chatMessages.push({me:false,name:r.slice(0,p),text:r.slice(p+1).trim()})}input.value='';renderChat()}
function adminAction(a){if(a==='events'){openModal('adminEvents');return}if(a==='coins'){money+=5000;showNotice('+5.000 moedas de ADM.',4000);buySound()}if(a==='areas'){unlocked=zones.length-1;selectedSkin=unlocked}if(a==='snakes'&&gameMode==='bots'){while(critters.length<SNAKE_CAP)spawnOne()}if(a==='hunters'&&gameMode==='bots'){hunterActive=!hunterActive;if(hunterActive&&hunters.length!==HUNTER_COUNT)spawnHunters()}if(a==='boost')adminBoost=!adminBoost;if(a==='evolve'){critters.forEach(s=>{s.level+=3;s.len+=4;s.r=10+Math.sqrt(s.len)*1.9;s.xp=0;s.bubble='EVOLUIU';s.bubbleT=1.5;rebuildBody(s)})}if(a==='eagles'&&gameMode==='bots'){hunterActive=true;spawnHunters()}if(a==='rankpush')critters.forEach(s=>s.kills=(s.kills||0)+3);if(a==='spawnElite'){const ss=makeSnake(99+Math.floor(Math.random()*500));ss.name='Elite';ss.len=35;ss.level=12;ss.r=10+Math.sqrt(ss.len)*1.9;ss.color='#fff';ss.x=rnd(200,world.w-200);ss.y=rnd(200,world.h-200);rebuildBody(ss);if(critters.length<SNAKE_CAP)critters.push(ss)}if(a==='clearChat')chatMessages=[];if(a==='reset'){money=0;unlocked=0;selectedSkin=0;turboLevel=1;agilityLevel=1;lavaPotion=0;adminBoost=false;save();resetRun()}save();updateHud();renderStore();renderRank();renderHunters()}
function adminStartEvent(id){if(id==='stop'){stopEvent();document.getElementById('adminEvents').style.display='none';return}startEvent(id,120,false);document.getElementById('adminEvents').style.display='none'}
function openAdminLogin(){openModal('adminLogin');document.getElementById('adminPass').value='';document.getElementById('adminError').textContent=''}
function enterAdmin(){const p=document.getElementById('adminPass').value;if(p!=='21435648q'){document.getElementById('adminError').textContent='Senha incorreta.';return}document.getElementById('adminLogin').style.display='none';document.getElementById('admin').style.display='grid'}
document.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>{const id=b.dataset.close;document.getElementById(id).style.display='none';if(![...document.querySelectorAll('.modal')].some(m=>getComputedStyle(m).display!=='none'))document.body.classList.remove('modal-open');if(id==='multiLobby'&&!running)showIdleMenu()});function exitToMain(){document.body.classList.remove('menuCollapsed','modal-open');const mt=document.getElementById('menuToggle');if(mt)mt.textContent='☰ BOTÕES';closeNetwork();running=false;boosting=false;stationary=false;setGameActive(false);document.querySelectorAll('.modal').forEach(m=>m.style.display='none');document.getElementById('gameOver').style.display='none';document.getElementById('modeLabel').textContent='NENHUM MODO';showIdleMenu();worldDraw()}document.getElementById('exitGame').onclick=exitToMain;document.getElementById('exitGameMenu').onclick=exitToMain;document.getElementById('openStore').onclick=()=>openModal('store');document.getElementById('openRank').onclick=()=>openModal('rank');document.getElementById('openHunters').onclick=()=>openModal('hunters');document.getElementById('openChat').onclick=()=>openModal('chat');document.getElementById('openHow').onclick=()=>openModal('howto');document.getElementById('openAdmin').onclick=openAdminLogin;document.getElementById('menuEvents').onclick=()=>openModal('adminEvents');document.getElementById('menuHow').onclick=()=>openModal('howto');document.getElementById('turboBuy').onclick=buyTurbo;document.getElementById('portalBuy').onclick=()=>buyItem('portal',1800);document.getElementById('portalUse').onclick=usePortal;document.getElementById('swampPotionBuy')?.addEventListener('click',()=>window.buySwampPotion?.());document.getElementById('growthBuy').onclick=()=>buyItem('growth',3000);document.getElementById('growthUse').onclick=useGrowthPotion;document.getElementById('xpBuy').onclick=()=>buyItem('xp',2200);document.getElementById('xpUse').onclick=useXpBoost;document.getElementById('chatSend').onclick=sendChat;document.getElementById('chatInput').onkeydown=e=>{if(e.key==='Enter')sendChat()};document.getElementById('adminEnter').onclick=enterAdmin;document.getElementById('adminPass').onkeydown=e=>{if(e.key==='Enter')enterAdmin()};document.querySelectorAll('[data-admin]').forEach(b=>b.onclick=()=>adminAction(b.dataset.admin));document.querySelectorAll('[data-event]').forEach(b=>b.onclick=()=>adminStartEvent(b.dataset.event));['pointerdown','touchstart','mousedown','keydown'].forEach(evt=>addEventListener(evt,ensureAudio,{once:true}));window.addEventListener('orientationchange',()=>setTimeout(resize,120));
document.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;ensureAudio();},false);
document.getElementById('restart').onclick=()=>{document.getElementById('gameOver').style.display='none';if(gameMode)begin(gameMode);else showIdleMenu()};document.getElementById('still').onclick=toggleStationary;document.getElementById('boost').onpointerdown=()=>boosting=true;['pointerup','pointercancel','pointerleave','touchend','touchcancel'].forEach(e=>document.getElementById('boost').addEventListener(e,()=>boosting=false));document.getElementById('boost').ontouchstart=()=>boosting=true;
const joy=document.getElementById('joy'),knob=joy.querySelector('.knob');function joyMove(e){const r=joy.getBoundingClientRect(),px=e.clientX-r.left-r.width/2,py=e.clientY-r.top-r.height/2,m=Math.hypot(px,py)||1,q=Math.min(48,m);joystick.x=px/m*q/48;joystick.y=py/m*q/48;knob.style.transform=`translate(${joystick.x*48}px,${joystick.y*48}px)`}function joyEnd(){joystick.x=0;joystick.y=0;knob.style.transform=''}joy.onpointerdown=e=>{if(joy.setPointerCapture)joy.setPointerCapture(e.pointerId);joyMove(e)};joy.onpointermove=e=>{if(e.buttons)joyMove(e)};joy.onpointerup=joyEnd;joy.onpointercancel=joyEnd;joy.ontouchstart=e=>{if(e.touches&&e.touches[0])joyMove(e.touches[0])};joy.ontouchmove=e=>{if(e.touches&&e.touches[0]){joyMove(e.touches[0]);e.preventDefault()}};joy.ontouchend=joyEnd;joy.ontouchcancel=joyEnd;
let peer=null,peerConn=null,multiRole='',multiConnected=false,multiReady=false,lastNet=0,peerLoading=null,netAlive=true;
function onlineList(){return Object.values(remotePlayers).filter(v=>v&&!v.dead)}
function syncPlayer2(){const first=onlineList()[0]||null;player2=first||null}
function ensurePeerLibrary(){
  if(window.Peer)return Promise.resolve();
  if(peerLoading)return peerLoading;
  peerLoading=new Promise((resolve,reject)=>{
    const sc=document.createElement('script');
    sc.src='https://unpkg.com/peerjs@1.5.5/dist/peerjs.min.js';
    sc.async=true;
    const timer=setTimeout(()=>{sc.remove();reject(new Error('Tempo esgotado para carregar o multiplayer.'))},12000);
    sc.onload=()=>{clearTimeout(timer);window.Peer?resolve():reject(new Error('PeerJS não carregou.'))};
    sc.onerror=()=>{clearTimeout(timer);reject(new Error('Internet/Wi-Fi necessária para o multiplayer.'))};
    document.head.appendChild(sc);
  }).finally(()=>{peerLoading=null});
  return peerLoading;
}
function setMultiStatus(t){const b=document.getElementById('roomInfo');if(b&&t)b.textContent=t;if(t)showNotice(t,4000)}
function updateMultiRoomHud(){const el=document.getElementById('multiRoomHud'),val=document.getElementById('multiRoomCodeValue');if(!el||!val)return;const code=(roomHostId||localNetId||'').replace(/^worm-/,'').toUpperCase();const show=gameMode==='multiplayer'&&multiConnected&&code;el.style.display=show?'flex':'none';if(show)val.textContent=code}
function copyMultiRoomCode(){const code=(roomHostId||localNetId||'').replace(/^worm-/,'').toUpperCase();if(!code)return;const done=()=>{showNotice('📋 Código da sala copiado: '+code,2200)};try{if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(code).then(done).catch(()=>{const ta=document.createElement('textarea');ta.value=code;ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.select();document.execCommand('copy');ta.remove();done()})}else{const ta=document.createElement('textarea');ta.value=code;ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.select();document.execCommand('copy');ta.remove();done()}}catch(e){showNotice('Código da sala: '+code,2500)}}

function localNetState(){return {type:'state',id:localNetId||((peer&&peer.id)||playerName||'player'),name:playerName||'Jogador',x:worm?.x||200,y:worm?.y||200,ang:worm?.ang||0,len:worm?.len||8,level:worm?.level||1,color:worm?.color||'#5cf06d',kills:worm?.kills||0,currentZone:worm?zoneAt(worm.x):0,alive:!!running,eventId:activeEvent,eventTimer:eventTimer}}
function makeRemote(d){return {id:d.id||d.playerId||('remote-'+Math.random().toString(36).slice(2)),name:d.name||'Jogador',x:Number(d.x)||200,y:Number(d.y)||200,r:13,len:Number(d.len)||8,level:Number(d.level)||1,xp:0,ang:Number(d.ang)||0,body:[],kills:Number(d.kills)||0,color:d.color||'#74d9ff',currentZone:Number(d.currentZone)||0,dead:d.alive===false}}
function applyRemoteState(d){
  if(!d||!d.id||d.id===localNetId)return;
  let a=remotePlayers[d.id];
  if(!a){if(Object.keys(remotePlayers).length>=MAX_ONLINE_PLAYERS-1)return;a=makeRemote(d);remotePlayers[d.id]=a}
  a.name=d.name||a.name;a.x=Number(d.x)||a.x;a.y=Number(d.y)||a.y;a.ang=Number(d.ang)||a.ang;a.len=Math.max(8,Number(d.len)||a.len);a.level=Math.max(1,Number(d.level)||a.level);a.kills=Number(d.kills)||0;a.color=d.color||a.color;a.currentZone=Number(d.currentZone)||0;a.dead=d.alive===false;smoothBody(a);syncPlayer2();
  if(d.eventId&&multiRole==='guest'&&d.eventId!==activeEvent)startEvent(d.eventId,Number(d.eventTimer||120),true);
}
function sendTo(conn,msg){try{if(conn&&conn.open)conn.send(msg)}catch(e){}}
function broadcastHost(msg,exceptPeer=''){for(const [id,conn] of hostConns){if(id!==exceptPeer)sendTo(conn,msg)}}
function broadcastSnapshot(conn){const players=[localNetState(),...onlineList().map(a=>({type:'state',id:a.id,name:a.name,x:a.x,y:a.y,ang:a.ang,len:a.len,level:a.level,color:a.color,kills:a.kills||0,currentZone:a.currentZone,alive:!a.dead,eventId:activeEvent,eventTimer:eventTimer}))];sendTo(conn,{type:'snapshot',players})}
function removeRemote(id){if(!id)return;delete remotePlayers[id];syncPlayer2();updateHud();renderRank()}
function onNetworkData(d,conn){
  if(!d||!d.type)return;
  if(d.type==='state'){
    if(d.id===localNetId)return;
    applyRemoteState(d);
    if(multiRole==='host')broadcastHost(d,conn?.peer||'');
    return;
  }
  if(d.type==='snapshot'){
    (d.players||[]).forEach(v=>applyRemoteState(v));
    setMultiStatus(`Sala conectada • ${Math.min(MAX_ONLINE_PLAYERS,1+onlineList().length)}/${MAX_ONLINE_PLAYERS} jogadores`);
    if(!running)begin('multiplayer');
    return;
  }
  if(d.type==='chat'){
    if(d.id===localNetId)return;
    chatMessages.push({me:false,name:d.name||'Jogador',text:String(d.text||'')});renderChat();
    if(multiRole==='host')broadcastHost(d,conn?.peer||'');
    return;
  }
  if(d.type==='leave'){
    removeRemote(d.id);if(multiRole==='host')broadcastHost(d,conn?.peer||'');return;
  }
  if(d.type==='death'&&d.id===localNetId){netAlive=false;running=false;setGameActive(false);wipeOnDeath();document.getElementById('deathText').textContent=d.reason||'Você foi derrubado por outro jogador.';document.getElementById('gameOver').style.display='grid';return}
}
function wireHostConnection(conn){
  hostConns.set(conn.peer,conn);
  conn.on('open',()=>{broadcastSnapshot(conn);setMultiStatus(`Jogador conectado • ${Math.min(MAX_ONLINE_PLAYERS,1+hostConns.size)}/${MAX_ONLINE_PLAYERS}`)});
  conn.on('data',d=>onNetworkData(d,conn));
  conn.on('close',()=>{hostConns.delete(conn.peer);removeRemote(conn.peer);broadcastHost({type:'leave',id:conn.peer},conn.peer);setMultiStatus(`Jogador saiu • ${Math.min(MAX_ONLINE_PLAYERS,1+hostConns.size)}/${MAX_ONLINE_PLAYERS}`)});
  conn.on('error',()=>{hostConns.delete(conn.peer);removeRemote(conn.peer);setMultiStatus('Um jogador perdeu a conexão.')});
}
function netSend(){
  if(!worm||!peer||!multiConnected)return;
  const d=localNetState();
  if(multiRole==='host')broadcastHost(d);
  else sendTo(peerConn,d);
}
function sendNetworkChat(text){
  const d={type:'chat',id:localNetId,name:playerName||'Jogador',text:String(text||'')};
  if(multiRole==='host')broadcastHost(d);else sendTo(peerConn,d);
}
function closeNetwork(){
  try{for(const c of hostConns.values())c.close()}catch(e){}hostConns.clear();
  try{if(peerConn)peerConn.close()}catch(e){}peerConn=null;
  try{if(peer)peer.destroy()}catch(e){}peer=null;
  remotePlayers={};player2=null;localNetId='';roomHostId='';multiRole='';multiConnected=false;multiReady=false;netAlive=true;updateMultiRoomHud();
}
function createOnlineRoom(){
  if(!loggedIn)return;setMultiStatus('Carregando multiplayer...');
  ensurePeerLibrary().then(()=>{
    closeNetwork();multiRole='host';netAlive=true;
    const id='worm-'+Math.random().toString(36).slice(2,8);
    peer=new Peer(id);
    peer.on('open',pid=>{localNetId=pid;roomHostId=pid;const code=pid.replace('worm-','').toUpperCase();document.getElementById('roomCode').value=code;multiConnected=true;multiReady=true;document.getElementById('multiLobby').style.display='none';document.body.classList.remove('modal-open');setMultiStatus(`SALA ${code} • você é o anfitrião • até ${MAX_ONLINE_PLAYERS} jogadores`);begin('multiplayer');updateMultiRoomHud()});
    peer.on('connection',conn=>{if(hostConns.size>=MAX_ONLINE_PLAYERS-1){sendTo(conn,{type:'full'});try{conn.close()}catch(e){}return}wireHostConnection(conn)});
    peer.on('disconnected',()=>{setMultiStatus('Servidor de sinalização desconectado. Tentando reconectar...');try{peer.reconnect()}catch(e){}});
    peer.on('error',e=>setMultiStatus('Erro multiplayer: '+(e?.type||'conexão')));
  }).catch(e=>setMultiStatus(e.message||'Não foi possível ativar o multiplayer.'));
}
function joinOnlineRoom(){
  const code=document.getElementById('roomCode').value.trim().toLowerCase().replace(/^worm-/,'');
  if(code.length<3){setMultiStatus('Digite o código da sala.');return}
  ensurePeerLibrary().then(()=>{
    closeNetwork();multiRole='guest';netAlive=true;setMultiStatus('Conectando à sala...');
    peer=new Peer();
    peer.on('open',pid=>{
      localNetId=pid;const conn=peer.connect('worm-'+code,{reliable:true});peerConn=conn;
      const timeout=setTimeout(()=>{if(!multiConnected)setMultiStatus('Não foi possível entrar. Confira o código e a internet.');},10000);
      conn.on('open',()=>{clearTimeout(timeout);multiConnected=true;multiReady=true;roomHostId='worm-'+code;sendTo(conn,{type:'hello',id:pid,name:playerName});document.getElementById('multiLobby').style.display='none';document.body.classList.remove('modal-open');setMultiStatus('Conectado à sala. Você entrou como jogador real. Código: '+code);begin('multiplayer');netSend();updateMultiRoomHud()});
      conn.on('data',d=>{if(d?.type==='full'){setMultiStatus('Sala cheia.');return}onNetworkData(d,conn)});
      conn.on('close',()=>{multiConnected=false;running=false;gameMode=null;setGameActive(false);closeNetwork();showIdleMenu();setMultiStatus('O anfitrião encerrou a sala.')});
      conn.on('error',()=>setMultiStatus('Falha na conexão com a sala.'));
    });
    peer.on('error',e=>setMultiStatus('Não encontrou essa sala: '+(e?.type||'erro')));
    peer.on('disconnected',()=>{try{peer.reconnect()}catch(e){}});
  }).catch(e=>setMultiStatus(e.message||'Multiplayer precisa de internet/Wi-Fi.'));
}
function checkOnlineCombat(){
  if(gameMode!=='multiplayer'||multiRole!=='host'||!running||!worm)return false;
  const players=[{id:localNetId||'host',ref:worm},...onlineList().map(a=>({id:a.id,ref:a}))];
  for(const a of players){for(const b of players){if(a===b||!a.ref||!b.ref||b.ref.dead)continue;const headA=a.ref.body?.[0]||a.ref,tailB=(b.ref.body||[]).slice(4);if(!tailB.length)continue;if(segmentHit(headA,tailB,3,Math.max(10,(a.ref.r+b.ref.r)*.56))>=0){if(a.id===localNetId||a.id==='host'){die('Sua cabeça bateu na cauda de outro jogador.');return true}const target=hostConns.get(a.id);remotePlayers[a.id].dead=true;sendTo(target,{type:'death',id:a.id,reason:'Sua cabeça bateu na cauda de outro jogador.'})}}}
  return false;
}
document.getElementById('createRoom').onclick=createOnlineRoom;
document.getElementById('joinRoom').onclick=joinOnlineRoom;
document.getElementById('cancelMulti').onclick=()=>{closeNetwork();document.getElementById('multiLobby').style.display='none';document.body.classList.remove('modal-open');showIdleMenu()};document.getElementById('copyRoomCode')?.addEventListener('click',copyMultiRoomCode);
addEventListener('keydown',e=>{const k=e.key.toLowerCase();keys[k]=1;if(e.key===' '){boosting=true;e.preventDefault()}if(k==='p')toggleStationary();if(k==='l')openModal('store');if(k==='r')openModal('rank');if(k==='h')openModal('hunters');if(k==='c')openModal('chat');if(k==='t')openModal('howto');if(k==='m')openAdminLogin()});addEventListener('keyup',e=>{const k=e.key.toLowerCase();keys[k]=0;if(e.key===' ')boosting=false});
function loop(t){if(!running)return;const dt=Math.min(.033,(t-last)/1000);last=t;try{update(dt);worldDraw()}catch(err){console.error('Loop error:',err);showNotice('⚠️ Ocorreu um erro no jogo. A partida continua.',2200)}if(running)requestAnimationFrame(loop)}
updateHud();
setGameActive(false);
showIdleMenu();
window.__wormBooted=true;

window.addEventListener('beforeunload',()=>save());document.addEventListener('visibilitychange',()=>{if(document.hidden)save()});


/* ===== BETA FUSÃO — SISTEMA DE VIDA / DANO / COMBATE / PINHATA ===== */
(function(){
  const style=document.createElement('style');
  style.textContent=`
    #menuBtns{top:250px;right:10px;max-width:230px;z-index:120}
    .miniBtn{position:relative;z-index:121;pointer-events:auto}
    .still{bottom:132px!important}.menuToggle{position:fixed;left:10px;right:auto;top:310px;transform:none;z-index:122;border:1px solid #ffffff33;border-radius:12px;padding:7px 10px;background:#07140ef2;color:#fff;font-weight:1000;pointer-events:auto;box-shadow:0 8px 18px #0005}
    .betaAction{bottom:102px}
    body:not(.game-active) #betaAttack,body:not(.game-active) #menuToggle{display:none!important;visibility:hidden!important;pointer-events:none!important}
    .menuCollapsed #menuBtns{display:none!important}.menuCollapsed #openAbilities{display:none!important}
    .modal-open #menuBtns,.modal-open .action,.modal-open .menuToggle,.modal-open #openAbilities,.modal-open #betaAttack{display:none!important;visibility:hidden!important;pointer-events:none!important}
    @media(max-width:700px){.menuToggle{top:310px;left:10px} #menuBtns{top:247px;right:10px;max-width:230px}.betaAction{bottom:190px;right:18px!important}}
    @media (orientation:portrait){.menuToggle{top:310px;left:10px} #menuBtns{top:247px;right:10px;max-width:230px}.betaAction{bottom:190px;right:18px!important}}
    @media (max-height:650px){.menuToggle{top:235px} #menuBtns{top:170px}.betaAction{bottom:155px;right:18px!important}}
    .betaHud{position:fixed;left:10px;top:92px;display:flex;gap:7px;flex-wrap:wrap;max-width:48vw;pointer-events:none}
    .betaPill{background:#07140ee8;border:1px solid #ffffff20;border-radius:12px;padding:7px 10px;font-weight:900;font-size:11px;backdrop-filter:blur(6px)}
    .hpOuter{width:170px;height:13px;background:#16090dcc;border:1px solid #ffffff25;border-radius:999px;overflow:hidden;margin-top:5px}
    .hpFill{height:100%;width:100%;background:linear-gradient(90deg,#ff4f65,#ff9d4f,#7ee66f);transition:width .15s}
    .betaAction{position:fixed;right:112px;bottom:25px;width:94px;height:54px;border:1px solid #ffffff33;border-radius:14px;background:#e75d5d;color:#fff;font-weight:1000;pointer-events:auto;z-index:15}
    .betaAction.on{background:#6fd66c;color:#09200b}
    .eventBanner{position:fixed;left:50%;top:44px;transform:translateX(-50%);z-index:75;text-align:center;pointer-events:none;font-weight:1000;text-shadow:0 2px 8px #000;display:none}
    .eventCountdown{font-size:30px;line-height:1}
    .eventSmall{font-size:12px;margin-top:4px}
    .abilityGrid{display:grid;grid-template-columns:1fr 1fr;gap:9px}
    .abilityCard{padding:12px;border-radius:14px;border:1px solid #ffffff18;background:#ffffff07}
    .abilityCard.active{border-color:#8ce67d;background:#17371d}
    .abilityCard button{margin-top:8px;border:0;border-radius:10px;padding:8px 10px;font-weight:1000;background:#f1c54d}
    .rankTabs{display:flex;gap:8px;margin-bottom:10px}
    .rankTabs button{border:1px solid #ffffff18;background:#ffffff08;color:#fff;border-radius:10px;padding:8px 10px;font-weight:900}
    .rankTabs button.on{background:#6fd66c;color:#09200b}
    .betaArrow{position:fixed;z-index:70;pointer-events:none;font-size:30px;display:none;filter:drop-shadow(0 2px 5px #000)}
  `;
  document.head.appendChild(style);

  const ui=document.getElementById('ui');
  const beta=document.createElement('div'); beta.className='betaHud';
  beta.innerHTML=`<div class="betaPill">❤️ VIDA <div class="hpOuter"><div id="betaHp" class="hpFill"></div></div><div id="betaHpText">100 / 100</div></div><div class="betaPill">⚔️ DANO <span id="betaDamage">1</span></div><div class="betaPill">🍬 HABILIDADE <span id="betaAbilityState">ATIVA</span></div>`;
  ui.appendChild(beta);
  const act=document.createElement('button'); act.id='betaAttack'; act.className='betaAction on'; act.textContent='💥 ATAQUE ON'; document.body.appendChild(act);
  const menuToggle=document.createElement('button'); menuToggle.id='menuToggle'; menuToggle.className='menuToggle'; menuToggle.textContent='☰ BOTÕES'; document.body.appendChild(menuToggle); menuToggle.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();document.body.classList.toggle('menuCollapsed');menuToggle.textContent=document.body.classList.contains('menuCollapsed')?'☰ MOSTRAR':'☰ BOTÕES';ensureAudio();buySound()});
  const banner=document.createElement('div'); banner.className='eventBanner'; banner.id='betaEventBanner'; banner.innerHTML='<div id="betaEventTitle">PINHATA MALIGNA</div><div id="betaEventCountdown" class="eventCountdown"></div><div id="betaEventSmall" class="eventSmall"></div>'; document.body.appendChild(banner);

  let hp=100,maxHp=100,damage=1,attackEnabled=true,attackCooldown=0,damageCooldown=0,healCooldown=0;
  let attackLevel=0, candyEvent=false, pinata=null, pinataCountdown=0, pinataMusicT=0, candyLakes=[], wormDamageKinds=new Set();
  let growthPotionTime=0,xpBoostTime=0;
  let rankMode='size';
  const oldSave=save, oldApply=applyProfile, oldProfileDefault=profileDefault;
  const oldResetRun=resetRun, oldBegin=begin, oldUpdate=update, oldUpdateEvent=updateEvent, oldDie=die;
  const oldDefeatNpc=defeatNpc, oldCheckPlayerCombat=checkPlayerCombat, oldCheckOnlineCombat=checkOnlineCombat;

  function playPinataSound(){
    ensureAudio();
    if(!audioCtx)return;
    const t=audioCtx.currentTime;
    [180,240,320,210,140].forEach((f,i)=>{
      const o=audioCtx.createOscillator(),g=audioCtx.createGain();
      o.type=i%2?'sawtooth':'square';o.frequency.setValueAtTime(f,t+i*.055);
      g.gain.setValueAtTime(.0001,t+i*.055);g.gain.exponentialRampToValueAtTime(.055,t+i*.055+.01);g.gain.exponentialRampToValueAtTime(.0001,t+i*.055+.12);
      o.connect(g);g.connect(audioMaster||audioCtx.destination);o.start(t+i*.055);o.stop(t+i*.055+.13);
    });
  }
  function playEventMusic(){
    const seq=[392,494,587,659,587,494,440,523];
    seq.forEach((f,i)=>setTimeout(()=>{if(running)tone(f,.12,'triangle',.035,f*1.03)},i*110));
  }
  window.__playEventMusic=playEventMusic;
  window.__unlockAttackLevel=(n)=>{attackLevel=Math.max(attackLevel,Number(n)||0);updateBetaHud();};
  function ensureStats(){
    if(!worm)return;
    // Protege o tamanho contra valores corrompidos/infinitos e crescimento acidental.
    worm.len=Number.isFinite(Number(worm.len))?clamp(Number(worm.len),8,300):8;
    worm.level=Number.isFinite(Number(worm.level))?clamp(Math.floor(Number(worm.level)),1,999):1;
    const oldMax=maxHp;
    maxHp=Math.max(50,100+worm.len*4+worm.level*10);
    if(!Number.isFinite(hp)) hp=maxHp;
    if(maxHp>oldMax && hp>=oldMax-0.5) hp=maxHp;
    hp=Math.max(0,Math.min(hp,maxHp));
    damage=Math.max(1,1+attackLevel+(adminBoost?2:0));
  }
  function updateBetaHud(){
    if(!worm)return;
    ensureStats();
    const f=document.getElementById('betaHp'); if(f)f.style.width=(hp/maxHp*100)+'%';
    const t=document.getElementById('betaHpText'); if(t)t.textContent=`${Math.ceil(hp)} / ${Math.ceil(maxHp)}`;
    const d=document.getElementById('betaDamage');if(d)d.textContent=damage;
    const s=document.getElementById('betaAbilityState');if(s)s.textContent=attackEnabled?'ATIVA':'DESLIGADA';
    const lp=document.getElementById('lavaPotionHud');if(lp)lp.textContent=`Poções de lava: ${lavaPotion}`+(zoneAt(worm.x)===5?` • Proteção: ${Math.ceil(lavaProtection)}s`:'');
    act.textContent=attackEnabled?'💥 ATAQUE ON':'💥 ATAQUE OFF';act.classList.toggle('on',attackEnabled);
  }
  function hurtPlayer(amount,reason='Você levou dano.'){
    if(!worm||!running)return;
    damageCooldown=Math.max(damageCooldown,.35);
    hp=Math.max(0,hp-amount);
    warningSound();
    addParticle(worm.x,worm.y,'#ff596b',12);
    showNotice(`${reason} -${Math.ceil(amount)} HP`,1200);
    if(hp<=0){ oldDie.call(window,`Sua vida acabou. ${reason}`); }
    updateBetaHud();
  }
  function healPlayer(amount){
    if(!worm||hp>=maxHp)return false;
    hp=Math.min(maxHp,hp+amount); eatSound(); updateBetaHud(); return true;
  }
  window.__healPlayer=(amount)=>healPlayer(amount); window.__getBetaHealth=()=>({hp,maxHp});
  function growFood(f){
    if(!worm)return;
    // Cada alimento é consumido uma única vez. O tamanho cresce de forma controlada.
    const missing=Math.max(0,maxHp-hp);
    const healValue = f.v>=5 ? 14 : (f.v>=2 ? 8 : 4);
    if(missing>0){
      healPlayer(Math.min(missing,healValue));
    }
    const grow = f.v>=5 ? 1.15 : (f.v>=2 ? 0.65 : 0.35);
    worm.len = clamp(Number(worm.len)||8,8,300);
    worm.len = Math.min(300, worm.len + grow);
    worm.r=Math.min(40,10+Math.sqrt(worm.len)*1.9);
    rebuildBody(worm);
  }

  window.save=function(){
    if(!loggedIn)return oldSave.call(window);
    let raw={};try{raw=JSON.parse(SAFE_STORE.get(accountKeySaved)||'{}')}catch(e){}
    raw.betaHp=Math.max(1,hp);raw.attackLevel=attackLevel;raw.attackEnabled=attackEnabled;
    SAFE_STORE.set(accountKeySaved,JSON.stringify({...raw,name:playerName,passHash:raw.passHash||'',money:Math.floor(money),best,unlocked,skin:selectedSkin,turbo:turboLevel,agility:agilityLevel,lavaPotion,portalCharges,coinMagnetCharges,growthPotionCharges,xpBoostCharges,eventTokens,swampPotion:Number(window.__swampPotion||0),hunters:hunterActive,adminBoost}));
  };
  window.applyProfile=function(k,p){
    oldApply.call(window,k,p);
    attackLevel=Math.max(0,Number(p.attackLevel||0));attackEnabled=p.attackEnabled!==false;
    hp=Number(p.betaHp||100);ensureStats();
  };
  window.profileDefault=function(n,p){
    const q=oldProfileDefault.call(window,n,p);q.betaHp=100;q.attackLevel=0;q.attackEnabled=true;return q;
  };
  window.__getCombatStats=function(){return {damage:Number(damage)||1,attackEnabled:attackEnabled!==false}};
  window.__hurtPlayer=function(amount,reason){hurtPlayer(amount,reason)};
  window.__applyBetaProfile=function(p){attackLevel=Math.max(0,Number(p.attackLevel||0));attackEnabled=p.attackEnabled!==false;hp=Number(p.betaHp||100);ensureStats()};

  act.onclick=()=>{attackEnabled=!attackEnabled;updateBetaHud();buySound();showNotice(attackEnabled?'Cabeçada ativada.':'Cabeçada desativada.',1800)};

  function setupAbilities(){
    let modal=document.getElementById('abilities');
    if(modal)return;
    modal=document.createElement('div');modal.id='abilities';modal.className='modal';
    modal.innerHTML=`<div class="modalCard"><div class="modalHead"><h2>⚔️ Habilidades de Ataque</h2><button class="close" data-close="abilities">×</button></div><div class="sub">Compre melhorias de dano e ative/desative a habilidade durante a partida.</div><div id="abilityGrid" class="abilityGrid"></div></div>`;
    document.body.appendChild(modal);
    modal.querySelector('.close').onclick=()=>{modal.style.display='none';document.body.classList.remove('modal-open')};
    const btn=document.createElement('button');btn.id='openAbilities';btn.className='miniBtn';btn.textContent='ATAQUES';document.getElementById('menuBtns').appendChild(btn);btn.onclick=()=>{document.body.classList.add('modal-open');modal.style.display='grid';renderAbilities()};
  }
  function renderAbilities(){
    const g=document.getElementById('abilityGrid');if(!g)return;
    const levels=[1,2,3,4,5];const costs=[450,950,1800,3500,6000];
    g.innerHTML=`<div class="abilityCard ${attackEnabled?'active':''}"><b>💥 Cabeçada</b><div class="sub">Bate com a cabeça, causa seu dano e lança o alvo para trás.</div><button id="toggleHead">${attackEnabled?'DESATIVAR':'ATIVAR'}</button></div>`+
      levels.map((n,i)=>`<div class="abilityCard ${attackLevel>=n?'active':''}"><b>⚔️ +${n} dano</b><div class="sub">${attackLevel>=n?'Comprado':'Custa '+costs[i]+' moedas'}</div><button ${attackLevel>=n||money<costs[i]?'disabled':''} data-dmg="${n}" data-cost="${costs[i]}">${attackLevel>=n?'COMPRADO':'COMPRAR'}</button></div>`).join('');
    g.querySelector('#toggleHead').onclick=()=>{attackEnabled=!attackEnabled;updateBetaHud();renderAbilities()};
    g.querySelectorAll('[data-dmg]').forEach(b=>b.onclick=()=>{const n=+b.dataset.dmg,cost=+b.dataset.cost;if(money<cost)return;money-=cost;attackLevel=Math.max(attackLevel,n);buySound();save();renderAbilities();updateBetaHud();updateHud();showNotice(`Dano aumentado para +${attackLevel}.`,1800)});
    const skills=[['🌀 Ataque Giro',2,4500,'giro'],['⚡ Investida',3,7500,'dash']];
    for(const [name,lvl,cost,key] of skills){const card=document.createElement('div');card.className='abilityCard '+(attackLevel>=lvl?'active':'');card.innerHTML=`<b>${name}</b><div class="sub">${attackLevel>=lvl?'Desbloqueada':'Compre por '+cost+' moedas ou alcance o nível '+(lvl===2?30:60)}</div><button ${attackLevel>=lvl||money<cost?'disabled':''}>${attackLevel>=lvl?'DESBLOQUEADA':'COMPRAR'}</button>`;card.querySelector('button').onclick=()=>{if(money<cost)return;money-=cost;attackLevel=Math.max(attackLevel,lvl);buySound();save();renderAbilities();updateBetaHud();showNotice(`${name} desbloqueado!`,1800)};g.appendChild(card)}
  }
  setupAbilities();

  // Loja: itens e utilidades. Habilidades de ataque ficam somente em ATAQUES.
  document.getElementById('spinBuy')?.closest('.upgrade')?.remove();
  document.getElementById('dashBuy')?.closest('.upgrade')?.remove();
  const store=document.getElementById('store');
  if(store){
    const box=store.querySelector('.modalCard');
    if(box&&!box.querySelector('.betaStore')){
      const d=document.createElement('div');d.className='betaStore';
      d.innerHTML=`<div class="upgrade"><div><b>❤️ Vida máxima</b><small>A comida recupera vida antes de virar crescimento.</small></div><button class="buy" id="betaHealthInfo">INFO</button></div>`;
      box.insertBefore(d,box.firstChild);
      document.getElementById('betaHealthInfo').onclick=()=>showNotice('A comida é dividida: se faltar vida, parte cura e parte aumenta o corpo; com vida cheia, toda a comida aumenta o corpo.',3500);
    }
  }

  // Corrige o reset para não começar com HP baixo.
  window.resetRun=function(){
    oldResetRun.call(window);
    ensureStats();
    hp=maxHp;
    candyEvent=false;pinata=null;pinataCountdown=0;candyLakes=[];attackCooldown=0;damageCooldown=0;wormDamageKinds=new Set();
    updateBetaHud();
  };

  // O ataque dos inimigos também passa a usar vida.
  window.defeatNpc=function(a){
    if(!a)return;
    a.hp=Number.isFinite(a.hp)?a.hp:Math.max(12,a.len*4+a.level*8);
    const hit=damage;
    a.hp-=hit;
    addParticle(a.x,a.y,'#ffdd68',8);
    showNotice(`Cabeçada em ${a.name}: -${hit} HP`,700);
    const kx=Math.cos(worm.ang),ky=Math.sin(worm.ang);
    a.x=clamp(a.x+kx*(18+hit*4),50,world.w-50);a.y=clamp(a.y+ky*(18+hit*4),50,world.h-50);
    if(a.hp<=0){
      worm.kills=(worm.kills||0)+1;addXp(worm,Math.max(20,a.len*8));dropCoins(a.x,a.y,Math.max(5,Math.round(a.len*2+a.level*3)));addParticle(a.x,a.y,'#ffd65b',18);critters=critters.filter(v=>v!==a);showKillNotice(`${a.name} caiu! +1 eliminação.`);
    }
  };

  // Colisões: cabeçada causa dano; inimigos marcados como agressivos causam dano.
  window.checkPlayerCombat=function(){
    if(!worm)return false;
    for(const a of [...critters]){
      if(!a.body?.length)continue;
      const contactRadius=Math.max(20,(worm.r+a.r)*.72+10);
      const headContact=dist(a,worm)<contactRadius;
      if(a.damageDealer && headContact && damageCooldown<=0){
        hurtPlayer(Math.max(5,a.damage||6),`${a.name} veio direto para te atacar`);
        const away=Math.atan2(worm.y-a.y,worm.x-a.x);
        worm.x=clamp(worm.x+Math.cos(away)*18,40,world.w-40);
        worm.y=clamp(worm.y+Math.sin(away)*18,40,world.h-40);
      }
      if(segmentHit(worm.body[0],a.body,3,Math.max(10,(worm.r+a.r)*.56))>=0 && attackEnabled && attackCooldown<=0){
        attackCooldown=.38;window.defeatNpc(a);playPinataSound();
      }
    }
    return false;
  };

  // Dá variedade: apenas algumas minhocas causam dano.
  const oldSpawnOne=spawnOne;
  window.spawnOne=function(){
    oldSpawnOne.call(window);
    const a=critters[critters.length-1];
    if(a){
      a.damageDealer=Math.random()<.32;
      a.damage=a.damageDealer?(4+Math.floor(Math.random()*7)):0;
      if(!Number.isInteger(a.skinIndex))a.skinIndex=(a.id*3)%skins.length;
      const sk=skins[a.skinIndex];a.skinName=sk.name;a.color=sk.a;a.pattern=sk.pattern;
      a.hp=Math.max(20,a.len*3+a.level*10);
      a.maxHp=a.hp;
    }
  };

  // Vida/food é processada antes da rotina antiga consumir a comida.
  window.update=function(dt){
    if(!running||!worm)return;
    ensureStats();
    damageCooldown=Math.max(0,damageCooldown-dt);attackCooldown=Math.max(0,attackCooldown-dt);healCooldown=Math.max(0,healCooldown-dt);
    // Processa somente um alimento por ciclo e marca-o como consumido antes da rotina antiga.
    // Isso evita que o mesmo alimento seja aplicado dezenas de vezes em um único segundo.
    for(const f of foods){
      if(f.x>0&&dist(worm,f)<worm.r+f.r+5){
        const ev=currentEvent();
        const xpMult=(xpBoostCharges>0||xpBoostTime>0)?1.35:1;
        addXp(worm,f.v*7*ev.xp*xpMult);
        if(ev.coin)money+=ev.coin;
        f.x=-999;
        growFood(f);
        eatSound();
        updateHud();
        break;
      }
    }
    oldUpdate.call(window,dt);
    ensureStats();
    if(zoneAt(worm.x)===5){
      if(lavaProtection>0){lavaProtection=Math.max(0,lavaProtection-dt);lavaDamageClock=0;}
      else {lavaDamageClock=Math.max(0,lavaDamageClock-dt);if(lavaDamageClock<=0){lavaDamageClock=1.15;hurtPlayer(4,'🔥 O Vulcão está queimando você');}}
    } else {lavaDamageClock=0;}
    // Dano da lagoa de doce e lentidão.
    if(candyEvent){
      let inLake=false;
      for(const l of candyLakes){if(dist(worm,l)<l.r+worm.r){inLake=true;break}}
      if(inLake){
        worm.__candySlow=.38;
        if(healCooldown<=0){hurtPlayer(2,'Lagoa de doces');healCooldown=.45}
      }else worm.__candySlow=0;
    }
    updateBetaHud(); updatePinataHud();
  };

  // Pequena redução de velocidade durante a lagoa.
  const oldPlayer=updatePlayer;
  window.updatePlayer=function(dt){
    if(worm&&worm.__candySlow){const saveAg=agilityLevel;agilityLevel=Math.max(0,agilityLevel-2);oldPlayer.call(window,dt*.38);agilityLevel=saveAg}
    else oldPlayer.call(window,dt);
  };

  // Pinhata maligna: countdown de 10s, cenário de doce, lagoas, seta e cabeçada.
  function makePinata(){
    const p=randomPoint(650);
    pinata={x:p.x,y:p.y,r:48,hp:120,maxHp:120,phase:0,vx:0,vy:0,hitCd:0};
    for(let i=0;i<10;i++)candyLakes.push({x:rnd(100,world.w-100),y:rnd(100,world.h-100),r:rnd(90,180),phase:rnd(0,6.28)});
  }
  function startPinataBeta(){
    activeEvent='pinhata';eventTimer=120;pinataCountdown=10;candyEvent=true;makePinata();eventSound();playPinataSound();showNotice('🍭 PINHATA MALIGNA chegando em 10 segundos!',4500);updatePinataHud();
  }
  function stopPinataBeta(){
    activeEvent='normal';eventTimer=0;pinata=null;candyEvent=false;candyLakes=[];pinataCountdown=0;
    const b=document.getElementById('betaEventBanner');if(b)b.style.display='none';showNotice('Evento Pinhata encerrado.',2200);
  }
  function updatePinata(dt){
    if(!pinata)return;
    if(pinataCountdown>0){
      pinataCountdown-=dt;
      if(pinataCountdown<=0){pinataCountdown=0;showNotice('🍬 A PINHATA MALIGNA NASCEU! Dê cabeçadas!',3000);playPinataSound();playEventMusic()}
      return;
    }
    pinata.phase+=dt*3;pinata.hitCd=Math.max(0,pinata.hitCd-dt);const pd=dist(worm,pinata);if(pd>pinata.r+worm.r+12){const wanted=Math.atan2(worm.y-pinata.y,worm.x-pinata.x);pinata.x=clamp(pinata.x+Math.cos(wanted)*115*dt,80,world.w-80);pinata.y=clamp(pinata.y+Math.sin(wanted)*115*dt,80,world.h-80)}else if(pinata.hitCd<=0){pinata.hitCd=.9;hurtPlayer(9,'🍭 A Pinhata Maligna bateu em você!');const away=Math.atan2(worm.y-pinata.y,worm.x-pinata.x);worm.x=clamp(worm.x+Math.cos(away)*34,40,world.w-40);worm.y=clamp(worm.y+Math.sin(away)*34,40,world.h-40);playPinataSound()}
    if(pinata.vx||pinata.vy){pinata.x=clamp(pinata.x+pinata.vx*dt,80,world.w-80);pinata.y=clamp(pinata.y+pinata.vy*dt,80,world.h-80);pinata.vx*=Math.pow(.04,dt);pinata.vy*=Math.pow(.04,dt)}
    if(dist(worm,pinata)<worm.r+pinata.r && attackEnabled && attackCooldown<=0 && pinata.hitCd<=0){
      attackCooldown=.45;pinata.hitCd=.5;pinata.hp-=damage;pinata.vx=Math.cos(worm.ang)*(160+damage*20);pinata.vy=Math.sin(worm.ang)*(160+damage*20);
      addParticle(pinata.x,pinata.y,'#ffde72',20);playPinataSound();showNotice(`💥 Cabeçada! Pinhata -${damage} HP`,900);
      worm.x=clamp(worm.x-Math.cos(worm.ang)*24,40,world.w-40);worm.y=clamp(worm.y-Math.sin(worm.ang)*24,40,world.h-40);
      if(pinata.hp<=0){worm.kills=(worm.kills||0)+1;money+=600;eventTokens+=5;addXp(worm,300);showNotice('🎉 PINHATA DERROTADA! +600 moedas',3500);window.__pinataKills=(window.__pinataKills||0)+1;if(window.awardAchievement)window.awardAchievement('pinata');buySound();stopPinataBeta();save()}
    }
    if(Math.random()<dt*.06)playEventMusic();
    if(eventTimer<=0)stopPinataBeta();
  }
  function updatePinataHud(){
    const b=document.getElementById('betaEventBanner'),ct=document.getElementById('betaEventCountdown'),sm=document.getElementById('betaEventSmall');
    if(activeEvent!=='pinhata'){if(b)b.style.display='none';return}
    if(b)b.style.display='block';
    if(ct)ct.textContent=pinataCountdown>0?Math.ceil(pinataCountdown)+'s':'⚡ ATAQUE A PINHATA ⚡';
    if(sm)sm.textContent=pinataCountdown>0?'Prepare-se! O cenário de doce está chegando.':`Vida da Pinhata: ${Math.ceil(pinata?.hp||0)} / ${pinata?.maxHp||120}`;
    if(pinata&&pinataCountdown<=0){
      const sx=pinata.x-cam.x,sy=pinata.y-cam.y;
      const a=document.getElementById('betaArrow');if(a){a.style.display='block';a.style.left=clamp(sx-15,8,W-40)+'px';a.style.top=clamp(sy-75,8,H-70)+'px';}
    }
  }

  // Desenha a pinhata maligna e as lagoas sobre o mundo.
  const oldWorldDrawPinata=worldDraw;
  window.worldDraw=function(){
    oldWorldDrawPinata.call(window);
    if(activeEvent!=='pinhata')return;
    x.save();x.translate(-cam.x,-cam.y);
    // cenário de doce em toda a área visível
    x.fillStyle='#ffb6df25';x.fillRect(cam.x,cam.y,W,H);
    for(const l of candyLakes){
      x.fillStyle='#ff72c655';x.beginPath();x.arc(l.x,l.y,l.r,0,Math.PI*2);x.fill();
      x.fillStyle='#fff0fb55';x.beginPath();x.arc(l.x-l.r*.25,l.y-l.r*.2,l.r*.35,0,Math.PI*2);x.fill();
      x.fillStyle='#ffffffaa';x.font='900 13px system-ui';x.textAlign='center';x.fillText('🍬',l.x,l.y);
    }
    if(pinata){
      const bob=Math.sin(pinata.phase)*6;
      x.save();x.translate(pinata.x,pinata.y+bob);
      x.fillStyle='#7d194d';x.beginPath();x.ellipse(0,0,48,35,0,0,Math.PI*2);x.fill();
      x.fillStyle='#ff4f9d';for(let i=0;i<7;i++){x.save();x.rotate(i*Math.PI/3.5);x.fillRect(-6,-55,12,24);x.restore()}
      x.fillStyle='#ffd75a';x.fillRect(-32,-10,64,7);x.fillStyle='#54e8ff';x.fillRect(-28,2,56,7);
      x.fillStyle='#fff';x.beginPath();x.arc(-16,-3,9,0,Math.PI*2);x.arc(16,-3,9,0,Math.PI*2);x.fill();
      x.fillStyle='#111';x.beginPath();x.arc(-16,-3,4,0,Math.PI*2);x.arc(16,-3,4,0,Math.PI*2);x.fill();
      x.fillStyle='#2b0820';x.beginPath();x.arc(0,13,15,0,Math.PI);x.fill();
      x.fillStyle='#fff';x.font='900 12px system-ui';x.textAlign='center';x.fillText('PINHATA MALIGNA',0,-68);
      x.fillStyle='#140512';x.fillRect(-55,-84,110,9);x.fillStyle='#ff5470';x.fillRect(-55,-84,110*(pinata.hp/pinata.maxHp),9);
      x.restore();
    }
    x.restore();
  };

  // Redesenha barra de vida dos inimigos e dos jogadores.
  const oldDrawWorm=drawWorm;
  window.drawWorm=function(a){
    oldDrawWorm.call(window,a);
    if(!a||!a.body?.[0])return;
    const hpv=Number.isFinite(a.hp)?a.hp:null,max=Number.isFinite(a.maxHp)?a.maxHp:null;
    if(hpv!==null&&max){
      const h=a.body[0],bw=54,bh=7;
      x.fillStyle='#160b0dcc';x.fillRect(h.x-bw/2,h.y-a.r-31,bw,bh);
      x.fillStyle='#ff6174';x.fillRect(h.x-bw/2,h.y-a.r-31,bw*Math.max(0,hpv/max),bh);
      x.strokeStyle='#fff6';x.strokeRect(h.x-bw/2,h.y-a.r-31,bw,bh);
    }
  };

  // Pinhata via ADM e evento automático.
  const oldStartEvent=startEvent;
  window.startEvent=function(id,duration=120,remote=false){
    if(id==='pinhata'){startPinataBeta();return}
    return oldStartEvent.call(window,id,duration,remote);
  };
  const oldStopEvent=stopEvent;
  window.stopEvent=function(){
    if(activeEvent==='pinhata'){stopPinataBeta();return}
    return oldStopEvent.call(window);
  };

  // Botão ADM do evento.
  const adminGrid=document.querySelector('#adminEvents .adminGrid');
  if(adminGrid&&!adminGrid.querySelector('[data-event="pinhata"]')){
    const b=document.createElement('button');b.className='adminBtn';b.dataset.event='pinhata';b.innerHTML='🍭 PINHATA MALIGNA<small>10s de preparação + lagoas de doce.</small>';
    b.onclick=()=>startPinataBeta();adminGrid.insertBefore(b,adminGrid.firstChild);
  }

  // Ranking: mantém o ranking antigo e acrescenta o de eliminações.
  const rankModal=document.getElementById('rank');
  if(rankModal){
    const card=rankModal.querySelector('.modalCard');
    if(card&&!card.querySelector('.rankTabs')){
      const tabs=document.createElement('div');tabs.className='rankTabs';
      tabs.innerHTML='<button class="on" data-rm="size">📏 MAIORES</button><button data-rm="kills">💥 MAIS MATARAM</button>';
      card.insertBefore(tabs,card.querySelector('.rows'));
      tabs.querySelectorAll('button').forEach(b=>b.onclick=()=>{rankMode=b.dataset.rm;tabs.querySelectorAll('button').forEach(q=>q.classList.remove('on'));b.classList.add('on');renderBetaRank()});
    }
  }
  function renderBetaRank(){
    const rows=document.getElementById('rankList');if(!rows)return;
    const all=[...(worm?[worm]:[]),...onlineList(),...critters];
    const sorted=all.slice().sort((a,b)=>rankMode==='kills'?((b.kills||0)-(a.kills||0))||((b.len||0)-(a.len||0)):((b.len||0)-(a.len||0))||((b.level||0)-(a.level||0)));
    rows.innerHTML=sorted.slice(0,18).map((a,i)=>`<div class="row"><b>#${i+1}</b><span>${a.name}${a.id==='player'?' • VOCÊ':''}</span><small>${rankMode==='kills'?'💥 '+(a.kills||0)+' eliminações':'📏 '+Math.floor(a.len)+' corpo • Lv.'+(a.level||1)}</small></div>`).join('');
    const meta=document.getElementById('rankMeta');if(meta)meta.textContent=rankMode==='kills'?'Ranking separado por eliminações.':'Ranking tradicional por tamanho.';
  }
  const oldRenderRank=renderRank;
  window.renderRank=function(){oldRenderRank.call(window);renderBetaRank()};

  // Multiplayer: envia HP/dano e deixa o host aplicar dano sem morte instantânea.
  const oldLocalNetState=localNetState;
  window.localNetState=function(){const d=oldLocalNetState.call(window);d.hp=hp;d.maxHp=maxHp;d.damage=damage;return d};
  const oldMakeRemote=makeRemote;
  window.makeRemote=function(d){const a=oldMakeRemote.call(window,d);a.hp=Number(d.hp||100);a.maxHp=Number(d.maxHp||100);a.damage=Number(d.damage||1);return a};
  const oldApplyRemoteState=applyRemoteState;
  window.applyRemoteState=function(d){oldApplyRemoteState.call(window,d);const a=remotePlayers[d.id];if(a){a.hp=Number(d.hp||a.hp||100);a.maxHp=Number(d.maxHp||a.maxHp||100);a.damage=Number(d.damage||a.damage||1)}};

  // Eventos normais continuam; o Pinhata é uma chance extra e também pode ser acionado pelo ADM.
  let betaSchedule=55;
  const oldUE=updateEvent;
  window.updateEvent=function(dt){
    if(activeEvent==='pinhata'){eventTimer-=dt;updatePinata(dt);updatePinataHud();return}
    oldUE.call(window,dt);
    betaSchedule-=dt;
    if((gameMode==='bots'||(gameMode==='multiplayer'&&multiRole==='host'))&&betaSchedule<=0&&running&&activeEvent==='normal'){
      betaSchedule=95;
      if(Math.random()<.55)startPinataBeta();
    }
  };

  // Ao entrar em partida, garante as propriedades de inimigos.
  const oldBegin2=begin;
  window.begin=function(mode){oldBegin2.call(window,mode);ensureStats();hp=maxHp;critters.forEach(a=>{a.damageDealer=Math.random()<.32;a.damage=a.damageDealer?(4+Math.floor(Math.random()*7)):0;if(!Number.isInteger(a.skinIndex))a.skinIndex=(a.id*3)%skins.length;const sk=skins[a.skinIndex];a.skinName=sk.name;a.color=sk.a;a.pattern=sk.pattern;a.hp=Math.max(20,a.len*3+a.level*10);a.maxHp=a.hp});updateBetaHud()};

  // sons extras em ações já existentes
  document.addEventListener('click',e=>{
    if(e.target.closest('button')){ensureAudio(); if(e.target.closest('#betaAttack'))return; tone(300,.035,'square',.025,360)}
  },true);
  // ===== BETA 2: menus, poções temporizadas e ADM organizado =====
  const betaStyle=document.createElement('style');
  betaStyle.textContent=`
    .menuToggle{display:none!important;left:10px!important;right:auto!important;top:310px!important}
    body.game-active:not(.modal-open) .menuToggle{display:block!important}
    .menuCollapsed #menuToggle{display:block!important}
    #menuBtns{z-index:118!important}
    .modal-open #menuToggle,.modal-open #menuBtns,.modal-open #openAbilities{display:none!important}
    .betaAction{display:none!important;right:18px!important;bottom:190px!important;width:88px!important;height:50px!important;z-index:121!important}
    body.game-active:not(.modal-open) .betaAction{display:block!important}
    .abilityGrid{display:grid;grid-template-columns:1fr 1fr;gap:10px}
    .abilityCard{background:#ffffff08;border:1px solid #ffffff16;border-radius:14px;padding:12px}
    .abilityCard.active{border-color:#77e477;background:#17341d}
    .adminTabs{display:flex;gap:7px;flex-wrap:wrap;margin:8px 0 12px}.adminTab{border:1px solid #ffffff18;background:#ffffff08;color:#fff;border-radius:10px;padding:8px 11px;font-weight:900}.adminTab.on{background:#75dc72;color:#09200b}
    @media(max-width:700px){.menuToggle{left:10px!important;right:auto!important;top:310px!important}.abilityGrid{grid-template-columns:1fr}}
  `;
  document.head.appendChild(betaStyle);
  // Ataques ficam exclusivamente no menu ATAQUES, não na Loja.
  ['spinBuy','dashBuy','betaDamageBuy'].forEach(id=>{const e=document.getElementById(id);if(e){const p=e.closest('.upgrade')||e.parentElement;if(p)p.style.display='none'}});
  // Botão de menus só existe na gameplay.
  const menuToggle2=document.getElementById('menuToggle');
  const syncMenuVisibility=()=>{if(!menuToggle2)return;const ok=document.body.classList.contains('game-active')&&!document.body.classList.contains('modal-open');menuToggle2.style.setProperty('display',ok?'block':'none','important')};
  new MutationObserver(syncMenuVisibility).observe(document.body,{attributes:true,attributeFilter:['class']});syncMenuVisibility();

  // Poções temporárias: corpo e XP têm duração.
  const baseUpdateForPotions=window.update;
  window.update=function(dt){
    if(running){
      if(growthPotionTime>0)growthPotionTime=Math.max(0,growthPotionTime-dt);
      if(xpBoostTime>0)xpBoostTime=Math.max(0,xpBoostTime-dt);
    }
    baseUpdateForPotions.call(window,dt);
    if(worm){const before=attackLevel;if(worm.level>=30)attackLevel=Math.max(attackLevel,2);if(worm.level>=60)attackLevel=Math.max(attackLevel,3);if(worm.level>=90)attackLevel=Math.max(attackLevel,4);if(worm.level>=120)attackLevel=Math.max(attackLevel,5);if(attackLevel!==before){showNotice('⚔️ Nova habilidade de ataque liberada pelo nível!',2200);save();renderAbilities();}}
    const gf=document.getElementById('growthInfo');if(gf)gf.textContent=`Você possui ${growthPotionCharges}${growthPotionTime>0?' • '+Math.ceil(growthPotionTime)+'s':''}`;
    const xf=document.getElementById('xpInfo');if(xf)xf.textContent=`Você possui ${xpBoostCharges}${xpBoostTime>0?' • '+Math.ceil(xpBoostTime)+'s':''}`;
  };
  const oldGrowFood= growFood;
  growFood=function(f){oldGrowFood(f);if(growthPotionTime>0&&worm){worm.len=Math.min(300,Math.max(8,Number(worm.len)||8)+Math.max(.5,f.v*.25));worm.r=Math.min(40,10+Math.sqrt(worm.len)*1.9);rebuildBody(worm)}};
  // ADM organizado em categorias + subir nível/desbloquear tudo.
  const admin=document.getElementById('admin');
  if(admin&&!admin.querySelector('.adminTabs')){
    const card=admin.querySelector('.modalCard');const grid=admin.querySelector('.adminGrid');
    const tabs=document.createElement('div');tabs.className='adminTabs';tabs.innerHTML='<button class="adminTab on" data-cat="player">👤 JOGADOR</button><button class="adminTab" data-cat="world">🌍 MUNDO</button><button class="adminTab" data-cat="events">🎉 EVENTOS</button><button class="adminTab" data-cat="system">⚙️ SISTEMA</button>';card.insertBefore(tabs,grid);
    const cats={coins:'player',areas:'world',level:'player',unlock:'player',snakes:'world',hunters:'world',boost:'player',evolve:'world',eagles:'world',rankpush:'player',events:'events',spawnElite:'world',clearChat:'system',reset:'system'};
    grid.querySelectorAll('[data-admin]').forEach(b=>{b.dataset.cat=cats[b.dataset.admin]||'system'});
    const extra=[['level','⬆️ +30 NÍVEIS','Sobe 30 níveis e libera recompensas.'],['unlock','🔓 DESBLOQUEAR TUDO','Libera áreas, skins e habilidades.']];
    for(const [id,title,desc] of extra){const b=document.createElement('button');b.className='adminBtn';b.dataset.admin=id;b.dataset.cat='player';b.innerHTML=`${title}<small>${desc}</small>`;grid.appendChild(b)}
    const filter=cat=>{grid.querySelectorAll('[data-admin]').forEach(b=>b.style.display=b.dataset.cat===cat?'block':'none');tabs.querySelectorAll('.adminTab').forEach(t=>t.classList.toggle('on',t.dataset.cat===cat))};tabs.querySelectorAll('.adminTab').forEach(t=>t.onclick=()=>filter(t.dataset.cat));filter('player');
    grid.querySelectorAll('[data-admin]').forEach(b=>b.onclick=()=>adminAction(b.dataset.admin));
  }
  const oldAdminAction=adminAction;
  window.adminAction=function(a){if(a==='level'){if(worm){const target=Math.max(1,worm.level+30);worm.level=target;worm.xp=0;worm.len=Math.min(300,worm.len+60);worm.r=Math.min(40,10+Math.sqrt(worm.len)*1.9);rebuildBody(worm);if(window.__unlockAttackLevel){if(worm.level>=30)window.__unlockAttackLevel(2);if(worm.level>=60)window.__unlockAttackLevel(3);if(worm.level>=90)window.__unlockAttackLevel(4);if(worm.level>=120)window.__unlockAttackLevel(5);}ensureStats();updateHud();showNotice('⬆️ ADM: +30 níveis!',2500);save()}return}if(a==='unlock'){unlocked=zones.length-1;selectedSkin=unlocked;attackLevel=5;turboLevel=5;agilityLevel=5;lavaPotion=Math.max(lavaPotion,5);money+=50000;save();renderStore();renderAbilities();updateHud();showNotice('🔓 ADM: tudo desbloqueado!',3000);return}oldAdminAction.call(window,a)};
  document.querySelectorAll('#adminEvents [data-event]').forEach(b=>b.onclick=()=>adminStartEvent(b.dataset.event));
  

  setInterval(()=>{if(running){updateBetaHud();updateMultiRoomHud()}},500);
})();



/* ===== SISTEMA DE CONQUISTAS ===== */
(function(){
  const ACH = {
    pinata:{name:'Quebra-Pinhata',desc:'Derrote uma Pinhata Maligna.',icon:'🍭',rewardSkin:23},
    tadpole:{name:'Caçador de Girinos',desc:'Coma seu primeiro girino no Pantanal.',icon:'🐸'},
    area:{name:'Novo Território',desc:'Desbloqueie uma nova área.',icon:'🗺️'},
    firstkill:{name:'Primeiro Abate',desc:'Derrote a primeira criatura.',icon:'⚔️'},
    level30:{name:'Veterano',desc:'Chegue ao nível 30.',icon:'⭐',rewardSkin:17,level:30},
    coin100:{name:'Cofre Cheio',desc:'Junte 100 moedas.',icon:'🪙'}
  };
  for(let lv=1;lv<=100;lv++){
    const rewards={30:17,60:18,90:19,100:20};
    ACH['level_'+lv]={name:`Nível ${lv}`,desc:`Alcance o nível ${lv}.`,icon:lv%10===0?'🏆':'⭐',level:lv,rewardSkin:rewards[lv]};
  }
  for(let k=1;k<=30;k++) ACH['kills_'+k]={name:`Caçador ${k}`,desc:`Derrote ${k} criaturas.`,icon:k%5===0?'💀':'⚔️',kills:k};
  for(let a=1;a<=17;a++) ACH['area_'+a]={name:`Explorador ${a}`,desc:`Desbloqueie ${a} áreas.`,icon:a%5===0?'🗺️':'🧭',areas:a};
  const hard=[
    ['giant','Gigante','Chegue a tamanho 150.','🐍',18],
    ['ancient','Anciã','Chegue ao nível 100.','👑',20],
    ['frog_slayer','Guardião do Pantanal','Derrote o Sapo Rei do Pantanal.','🐸',24],
    ['pinata_master','Mestre da Pinhata','Derrote 3 Pinhatas.','🍭',23],
    ['swamp_master','Rei do Pantanal','Coma 25 girinos no Pantanal.','🐸',24],
    ['perfect_explorer','Explorador Perfeito','Desbloqueie todas as áreas.','🌎',20]
  ];
  for(const [id,name,desc,icon,rewardSkin] of hard) ACH[id]={name,desc,icon,rewardSkin};
  // Toda conquista entrega uma recompensa uma única vez. Conquistas especiais também podem liberar skins.
  for(const a of Object.values(ACH)){ if(a.rewardCoins===undefined) a.rewardCoins = Math.max(25, Math.min(2500, 25 + (a.level||a.kills||a.areas||0)*10)); }
  let unlockedAchievements=new Set();
  let claimedAchievementRewards=new Set();
  let achToastTimer=0;
  function loadAchievements(p){
    unlockedAchievements=new Set(Array.isArray(p?.achievements)?p.achievements:[]);
    claimedAchievementRewards=new Set(Array.isArray(p?.achievementRewards)?p.achievementRewards:[]);
    window.__achievementSkinUnlocks=new Set(Array.isArray(p?.achievementSkins)?p.achievementSkins:[]);
  }
  window.__applyAchievements=loadAchievements;
  function saveAchievements(){
    if(!loggedIn||!accountKeySaved)return;
    let raw={};try{raw=JSON.parse(SAFE_STORE.get(accountKeySaved)||'{}')}catch(e){}
    raw.achievements=[...unlockedAchievements];raw.achievementRewards=[...claimedAchievementRewards];raw.achievementSkins=[...(window.__achievementSkinUnlocks||new Set())];SAFE_STORE.set(accountKeySaved,JSON.stringify(raw));
  }
  function unlockRewardSkin(index,name){
    if(!Number.isInteger(index)||index<0||index>=skins.length)return;
    window.__achievementSkinUnlocks=window.__achievementSkinUnlocks||new Set();
    const set=window.__achievementSkinUnlocks;const before=set.has(index);set.add(index);
    if(!before){showNotice(`✨ Skin desbloqueada: ${skins[index].name}`,3500);buySound();}
    try{let raw={};try{raw=JSON.parse(SAFE_STORE.get(accountKeySaved)||'{}')}catch(e){}raw.achievementSkins=[...set];SAFE_STORE.set(accountKeySaved,JSON.stringify(raw))}catch(e){}
  }
  window.awardAchievement=function(id){
    if(!ACH[id]||unlockedAchievements.has(id))return false;
    unlockedAchievements.add(id);
    const a=ACH[id];
    if(!claimedAchievementRewards.has(id)){
      const reward=Math.max(0,Math.floor(a.rewardCoins||0));
      money+=reward;
      claimedAchievementRewards.add(id);
      if(a.rewardSkin!==undefined)unlockRewardSkin(a.rewardSkin,a.name);
      showNotice(`🏆 ${a.name} • recompensa +${reward} moedas${a.rewardSkin!==undefined?' + skin':''}`,4200);
    }else{
      showNotice(`🏆 CONQUISTA DESBLOQUEADA: ${a.icon} ${a.name}`,4200);
    }
    saveAchievements();save();evolveSound();renderAchievements();updateHud();return true;
  };
  window.getAchievements=function(){return ACH}
  const oldApply=window.applyProfile;
  window.applyProfile=function(k,p){oldApply.call(window,k,p);loadAchievements(p)};
  const oldDefault=window.profileDefault;
  window.profileDefault=function(n,p){const q=oldDefault.call(window,n,p);q.achievements=[];return q};
  const oldSave=window.save;
  window.save=function(){oldSave.call(window);saveAchievements()};
  let achievementTab='all';
  function renderAchievements(){
    const list=document.getElementById('achievementList');if(!list)return;
    list.innerHTML='';const total=Object.keys(ACH).length,got=unlockedAchievements.size;
    const head=document.getElementById('achievementMeta');if(head)head.textContent=`${got}/${total} conquistas desbloqueadas • recompensas ganhas uma única vez`;
    document.getElementById('achTabAll')?.classList.toggle('on',achievementTab==='all');
    document.getElementById('achTabRewards')?.classList.toggle('on',achievementTab==='rewards');
    const entries=Object.entries(ACH).filter(([id])=>achievementTab==='all'||unlockedAchievements.has(id));
    if(!entries.length){list.innerHTML='<div class="row"><b>🎁</b><span><b>Nenhuma conquista desbloqueada ainda</b><small>Desbloqueie conquistas para receber recompensas.</small></span><small>0</small></div>';return;}
    for(const [id,a] of entries){
      const on=unlockedAchievements.has(id),claimed=claimedAchievementRewards.has(id);
      const reward=`+${Math.floor(a.rewardCoins||0)} moedas${a.rewardSkin!==undefined?' • skin especial':''}`;
      const row=document.createElement('div');row.className='row'+(on?' achievementOn':'');
      row.innerHTML=`<b>${a.icon}</b><span><b>${a.name}</b><small>${a.desc}<br>🎁 ${reward}</small></span><small>${on?(claimed?'RECOMPENSA RECEBIDA':'DESBLOQUEADA'):'BLOQUEADA'}</small>`;
      list.appendChild(row);
    }
  }
  document.getElementById('achTabAll')?.addEventListener('click',()=>{achievementTab='all';renderAchievements()});
  document.getElementById('achTabRewards')?.addEventListener('click',()=>{achievementTab='rewards';renderAchievements()});
  window.renderAchievements=renderAchievements;
  document.getElementById('openAchievements')?.addEventListener('click',()=>{openModal('achievements');renderAchievements()});
  document.getElementById('menuAchievements')?.addEventListener('click',()=>{openModal('achievements');renderAchievements()});
  // Primeira criatura derrotada: observa o contador do jogador sem depender do tipo de inimigo.
  let lastKills=0,lastUnlocked=0,lastHiveSize=0,lastTad=26;
  function watch(){
    if(!worm)return;
    const kills=Number(worm.kills||0), level=Number(worm.level||1);
    if(kills>lastKills){lastKills=kills;awardAchievement('firstkill');}
    if((money||0)>=100)awardAchievement('coin100');
    for(let lv=1;lv<=level&&lv<=100;lv++)awardAchievement('level_'+lv);
    for(let k=1;k<=kills&&k<=30;k++)awardAchievement('kills_'+k);
    if(typeof unlocked==='number'){for(let a=1;a<=unlocked+1&&a<=17;a++)awardAchievement('area_'+a);}
    if(level>=30)awardAchievement('level30');
    
    
    
    
    if(level>=100)awardAchievement('ancient');
    if((worm.len||0)>=150)awardAchievement('giant');
    if(typeof unlocked==='number'&&unlocked>=zones.length-1)awardAchievement('perfect_explorer');
    if((window.__pinataKills||0)>=1)awardAchievement('pinata');
    if((window.__pinataKills||0)>=3)awardAchievement('pinata_master');
    
    if((window.__tadpoleEaten||0)>=25)awardAchievement('swamp_master');
  }


  // Portal segue para as novas áreas; apenas o Vulcão consome Poção de Lava.
  const prevUsePortalAt=window.usePortalAt;
  window.usePortalAt=function(o){return prevUsePortalAt.call(window,o)};

  const blocks=document.querySelectorAll('[data-event="apocalypse"]');blocks.forEach(b=>b.remove());
  const evText=document.querySelector('#adminEvents .sub');if(evText)evText.textContent='Eventos temporários do mapa. As áreas Pantanal e Lamaçal Profundo fazem parte do jogo permanente.';

  // Se o jogador entra na área nova, atualiza o nome/skin normalmente.
  let lastMonsterZone=-1;setInterval(()=>{if(!running||!worm)return;const z=zoneAt(worm.x);if(z!==lastMonsterZone){lastMonsterZone=z;if(z===15)showNotice('🐸 Você entrou no PANTANAL. Os sapos atacam tudo, menos as águias.',3500);if(z===16)showNotice('🌿 Você entrou no LAMAÇAL PROFUNDO.',3000)}},350);
  setInterval(watch,500);
})();


/* ===== CORREÇÃO FINAL: VISIBILIDADE DA MINHOCA DO JOGADOR ===== */
(function(){
  const enhancedWorldDraw = window.worldDraw;
  const enhancedUpdate = window.update;
  const basePlayerDraw = drawWorm;

  function sanitizePlayer(){
    if(!worm) return;
    if(!Number.isFinite(worm.x)) worm.x=Math.min(world.w/2, zones[Math.max(0,Math.min(unlocked,zones.length-1))].start+520);
    if(!Number.isFinite(worm.y)) worm.y=world.h/2;
    if(!Number.isFinite(worm.r)||worm.r<8||worm.r>40) worm.r=13;
    if(!Number.isFinite(worm.len)||worm.len<8||worm.len>300) worm.len=8;
    if(!Number.isFinite(worm.ang)) worm.ang=0;
    if(!Number.isFinite(worm.level)||worm.level<1) worm.level=1;
    const skinIndexOk=Number.isInteger(selectedSkin)&&selectedSkin>=0&&selectedSkin<skins.length;
    if(!skinIndexOk) selectedSkin=0;
    if(!worm.color||typeof worm.color!=='string') worm.color=skins[selectedSkin].a;
    if(!Array.isArray(worm.body)||!worm.body.length || !worm.body.every(b=>Number.isFinite(b.x)&&Number.isFinite(b.y))){
      rebuildBody(worm);
    }
  }

  drawWorm=function(a){
    if(!a) return;
    if(a===worm) sanitizePlayer();
    basePlayerDraw(a);
    if(a===worm && a.body && a.body[0]){
      const h=a.body[0];
      x.save();
      x.globalAlpha=1;
      x.strokeStyle='#ffffff';
      x.lineWidth=3.5;
      x.beginPath();
      x.arc(h.x,h.y,Math.max(15,a.r+5),0,Math.PI*2);
      x.stroke();
      x.fillStyle='#ffffff';
      x.font='900 12px system-ui';
      x.textAlign='center';
      x.fillText('VOCÊ',h.x,h.y-a.r-24);
      x.restore();
    }
  };

  // O loop usava as funções locais. Conecta-o às versões aprimoradas dos módulos.
  update=function(dt){
    sanitizePlayer();
    if(typeof enhancedUpdate==='function') enhancedUpdate.call(window,dt);
    sanitizePlayer();
    if(worm){
      const tx=clamp(worm.x-W/2,0,Math.max(0,world.w-W));
      const ty=clamp(worm.y-H/2,0,Math.max(0,world.h-H));
      cam.x += (tx-cam.x)*Math.min(1,dt*8);
      cam.y += (ty-cam.y)*Math.min(1,dt*8);
    }
  };

  function drawPlayerEmergency(){
    if(!worm) return;
    sanitizePlayer();
    // Desenha diretamente em coordenadas de tela. Isso evita que uma transformação
    // de câmera/bioma ou uma camada posterior esconda a minhoca.
    const sx=worm.x-cam.x, sy=worm.y-cam.y;
    if(sx<-80||sx>W+80||sy<-80||sy>H+80){
      cam.x=clamp(worm.x-W/2,0,Math.max(0,world.w-W));
      cam.y=clamp(worm.y-H/2,0,Math.max(0,world.h-H));
    }
    const px=worm.x-cam.x, py=worm.y-cam.y, r=Math.max(10,Math.min(34,worm.r||13));
    x.save();
    x.globalAlpha=1;
    x.lineWidth=4;
    x.strokeStyle='#ffffff';
    x.fillStyle=worm.color||'#5cf06d';
    x.beginPath(); x.arc(px,py,r+3,0,Math.PI*2); x.stroke();
    x.beginPath(); x.arc(px,py,r,0,Math.PI*2); x.fill();
    x.fillStyle='#169c42'; x.beginPath(); x.arc(px,py,r*.72,0,Math.PI*2); x.fill();
    const ex=Math.cos(worm.ang||0), ey=Math.sin(worm.ang||0);
    x.fillStyle='#102015';
    x.beginPath(); x.arc(px+ex*r*.35-ey*r*.35,py+ey*r*.35+ex*r*.35,3,0,Math.PI*2);
    x.arc(px+ex*r*.35+ey*r*.35,py+ey*r*.35-ex*r*.35,3,0,Math.PI*2); x.fill();
    x.fillStyle='#fff'; x.font='900 12px system-ui'; x.textAlign='center';
    x.fillText('VOCÊ • Lv.'+(worm.level||1),px,py-r-16);
    x.restore();
  }

  worldDraw=function(){
    if(typeof enhancedWorldDraw==='function') enhancedWorldDraw.call(window);
    drawPlayerEmergency();
  };

  // Reforça a visibilidade imediatamente ao iniciar uma partida.
  const oldBeginLocal=begin;
  begin=function(mode){
    oldBeginLocal(mode);
    sanitizePlayer();
    if(worm){cam.x=clamp(worm.x-W/2,0,Math.max(0,world.w-W));cam.y=clamp(worm.y-H/2,0,Math.max(0,world.h-H));}
  };

  sanitizePlayer();
})();


/* ===== PERSONALIZAÇÃO DE SKIN + CONQUISTAS RECOMPENSÁVEIS ===== */
(function(){
  const style=document.createElement('style');
  style.textContent=`
    .achievementTabs{display:flex;gap:8px;margin:8px 0 12px;flex-wrap:wrap}.achievementTabs button{border:1px solid #ffffff18;background:#ffffff08;color:#fff;border-radius:10px;padding:8px 10px;font-weight:900}.achievementTabs button.on{background:#6fd66c;color:#09200b}
    .skinCustomizeBtn{margin-top:8px!important}
    .customSkinGrid{display:grid;grid-template-columns:1fr 1fr;gap:9px}
    .customSkinCard{display:flex;gap:10px;align-items:center;text-align:left;padding:10px;border-radius:14px;border:1px solid #ffffff18;background:#ffffff07;color:#fff;min-height:74px;width:100%}
    .customSkinCard.selected{border-color:#8ce67d;background:#183b20}
    .customSkinCard.locked{opacity:.42}
    .customSkinPreview{width:64px;height:30px;border-radius:999px;display:block;flex:0 0 auto;border:2px solid #fff8;background:repeating-linear-gradient(115deg,var(--a) 0 8px,var(--b) 8px 16px,var(--c) 16px 22px);box-shadow:0 0 12px var(--c)}
    .customSkinCard b{display:block}.customSkinCard small{display:block;color:#a9c5ae;font-size:10px;margin-top:2px}
    #customSkinButton{position:relative}
    @media(max-width:700px){.customSkinGrid{grid-template-columns:1fr}}
    /* POSIÇÃO FINAL DA HUD: seguir o padrão do print */
    .menuToggle{left:16px!important;right:auto!important;top:350px!important}
    #menuBtns{right:12px!important;left:auto!important;top:350px!important;bottom:auto!important;max-width:250px!important}
    @media(max-height:650px){.menuToggle{top:300px!important}#menuBtns{top:300px!important}}
  `;
  document.head.appendChild(style);

  function skinUnlocked(i){
    if(i<=unlocked)return true;
    return (window.__achievementSkinUnlocks||new Set()).has(i);
  }
  function createCustomization(){
    if(document.getElementById('skinCustomize'))return;
    const modal=document.createElement('div');modal.id='skinCustomize';modal.className='modal';
    modal.innerHTML=`<div class="modalCard"><div class="modalHead"><h2>🎨 Personalizar Skin</h2><button class="close">X</button></div><p class="sub">Use skins das áreas ou desbloqueie skins raras com conquistas difíceis.</p><div id="customSkinMeta" class="sub"></div><div id="customSkinGrid" class="customSkinGrid"></div></div>`;
    document.body.appendChild(modal);
    modal.querySelector('.close').onclick=()=>{modal.style.display='none';if(![...document.querySelectorAll('.modal')].some(m=>getComputedStyle(m).display!=='none'))document.body.classList.remove('modal-open')};
  }
  function renderCustomization(){
    createCustomization();
    const grid=document.getElementById('customSkinGrid'),meta=document.getElementById('customSkinMeta');if(!grid)return;
    grid.innerHTML='';
    let owned=0;
    skins.forEach((s,i)=>{
      const ok=skinUnlocked(i);if(ok)owned++;
      const reward=s.rewardAchievement?`Conquista: ${s.rewardAchievement}`:(s.special?'Conquista difícil':'Área '+(i+1));
      const b=document.createElement('button');b.className='customSkinCard'+(i===selectedSkin?' selected':'')+(ok?'':' locked');b.disabled=!ok;
      b.innerHTML=`<span class="customSkinPreview" style="--a:${s.a};--b:${s.b};--c:${s.c}"></span><span><b>${s.name}${s.special?' ✨':''}</b><small>${ok?(s.rarity||'Desbloqueada'):reward}</small></span>`;
      b.onclick=()=>{if(!skinUnlocked(i))return;selectedSkin=i;if(worm){worm.color=skins[i].a;worm.skinIndex=i;worm.skinName=skins[i].name;worm.pattern=skins[i].pattern;}save();updateHud();renderCustomization();buySound();showNotice(`🎨 Skin equipada: ${skins[i].name}`,1800)};
      grid.appendChild(b);
    });
    meta.textContent=`${owned}/${skins.length} skins liberadas • ${[...document.querySelectorAll('#skinCustomize .customSkinCard.locked')].length} bloqueadas`;
  }
  function openCustomization(){createCustomization();document.querySelectorAll('.modal').forEach(m=>m.style.display='none');document.body.classList.add('modal-open');document.getElementById('skinCustomize').style.display='grid';renderCustomization();}
  const menu=document.getElementById('menuBtns');
  if(menu&&!document.getElementById('customSkinButton')){
    const btn=document.createElement('button');btn.id='customSkinButton';btn.className='miniBtn skinCustomizeBtn';btn.textContent='SKINS';btn.onclick=openCustomization;menu.appendChild(btn);
  }
  const startGrid=document.querySelector('#startMenu .menuGrid');
  if(startGrid&&!document.getElementById('menuCustomSkin')){
    const b=document.createElement('button');b.id='menuCustomSkin';b.className='miniBtn';b.textContent='PERSONALIZAR SKIN';b.onclick=openCustomization;startGrid.insertBefore(b,document.getElementById('menuAchievements'));
  }
  // Persist special skins through the existing account layer.
  const oldApply=window.applyProfile;
  window.applyProfile=function(k,p){oldApply.call(window,k,p);window.__achievementSkinUnlocks=new Set(Array.isArray(p?.achievementSkins)?p.achievementSkins:[]);if(Number.isInteger(p?.skin)&&p.skin>=zones.length&&window.__achievementSkinUnlocks.has(p.skin)&&skins[p.skin]){selectedSkin=p.skin;}if(worm&&skins[selectedSkin]){worm.color=skins[selectedSkin].a;worm.skinIndex=selectedSkin;worm.skinName=skins[selectedSkin].name;worm.pattern=skins[selectedSkin].pattern;}};
  const oldSave=window.save;
  window.save=function(){oldSave.call(window);if(!loggedIn||!accountKeySaved)return;let raw={};try{raw=JSON.parse(SAFE_STORE.get(accountKeySaved)||'{}')}catch(e){}raw.achievementSkins=[...(window.__achievementSkinUnlocks||new Set())];SAFE_STORE.set(accountKeySaved,JSON.stringify(raw));};
})();
