'use strict';
const T=16,VH=144,R=9;let VW=256;
const $=i=>document.getElementById(i),cv=$('c'),cx=cv.getContext('2d'),B=document.body;
const WN=['الربيع','الثلج','البركان','الصحراء','الغابة','المحيط','الجبال','الليل','السماء','القلعة الأخيرة'];
const PAL=[
{s:['#4fb8ff','#d4f3ff'],g:'#7a4d24',t:'#52c23c',f1:'#9bdc9a',f2:'#5fb86a',sh:'hills'},
{s:['#9fb8d8','#eaf3ff'],g:'#6d86a8',t:'#ffffff',f1:'#cddcf0',f2:'#9fb4d0',sh:'tri'},
{s:['#2a0c0c','#c4401a'],g:'#3a2a2a',t:'#8a2a14',f1:'#4a1c14',f2:'#2e1410',sh:'tri'},
{s:['#ffb85a','#ffe9a8'],g:'#d9a95a',t:'#f1cf84',f1:'#e8bd70',f2:'#cf9b52',sh:'dune'},
{s:['#2c6b4a','#9fd08a'],g:'#4d3320',t:'#2f8a3a',f1:'#2f7a45',f2:'#1f5a35',sh:'tree'},
{s:['#2a8ad8','#8fe0f0'],g:'#d9c28a',t:'#f0dca0',f1:'#3aa0c8',f2:'#2a7ab0',sh:'dune'},
{s:['#7aa0d8','#d0e0f0'],g:'#6a6460',t:'#8a8480',f1:'#9aa4b4',f2:'#707a8c',sh:'tri'},
{s:['#05051a','#2a2a5a'],g:'#2a2438',t:'#4a3a7a',f1:'#1a1a3a',f2:'#10102a',sh:'tree'},
{s:['#6ac8ff','#ffffff'],g:'#dfe8f8',t:'#ffffff',f1:'#bfe6ff',f2:'#9fd0f8',sh:'hills'},
{s:['#0a0a10','#2a1a2a'],g:'#2a2a30',t:'#555560',f1:'#18181f',f2:'#101015',sh:'tree'}];
const BK=[0,0,1,1,2,2,3,3,4,5],BNAME=['حارس الدرع القرمزي','فارس اللهب الأزرق','سيد الظلام البنفسجي','ملك السلاسل','الساحر العجوز','العقل المدبّر'];
const EC=['#e0402a','#5aa0ff','#ff7a1a','#c9a030','#8a4ad0','#ff5aa0','#8a8a8a','#a060ff','#e8e8ff','#e02050'];
// ---------- save ----------
const KEY='icsv1';let SV={};try{SV=JSON.parse(localStorage.getItem(KEY)||'{}')||{}}catch(e){}
SV.u=SV.u||0;SV.last=SV.last||0;SV.has=!!SV.has;
SV.s=Object.assign({music:true,mv:.7,sfx:true,sv:.8,side:'left',size:1,op:.65,run:true,layout:0,pix:true},SV.s||{});
const S=SV.s,save=()=>{try{localStorage.setItem(KEY,JSON.stringify(SV))}catch(e){}};
// ---------- audio ----------
const bgm=new Audio('assets/iron_claw_strike.mp3');bgm.loop=true;let started=false;
function applyAudio(){bgm.volume=S.mv;if(S.music&&started)bgm.play().catch(()=>{});else bgm.pause()}
let AC=null;function ac(){if(!AC)try{AC=new(window.AudioContext||window.webkitAudioContext)()}catch(e){}if(AC&&AC.state=='suspended')AC.resume();return AC}
function tone(f1,f2,d,ty='square',v=.25,t0=0){if(!S.sfx)return;const a=ac();if(!a)return;const o=a.createOscillator(),g=a.createGain(),t=a.currentTime+t0;o.type=ty;o.frequency.setValueAtTime(f1,t);o.frequency.exponentialRampToValueAtTime(Math.max(20,f2),t+d);g.gain.setValueAtTime(v*S.sv,t);g.gain.exponentialRampToValueAtTime(.001,t+d);o.connect(g);g.connect(a.destination);o.start(t);o.stop(t+d)}
const SFX={jump:()=>tone(280,640,.16),coin:()=>{tone(988,988,.07);tone(1319,1319,.16,'square',.25,.07)},stomp:()=>tone(240,60,.16,'sawtooth'),hurt:()=>tone(520,50,.55,'sawtooth'),boss:()=>tone(160,40,.3),click:()=>tone(700,900,.05),
win:()=>[523,659,784,1047].forEach((f,i)=>tone(f,f,.2,'square',.25,i*.14)),life:()=>[660,880,1320].forEach((f,i)=>tone(f,f,.1,'square',.25,i*.08))};
// ---------- input ----------
const IN={},K={};
addEventListener('keydown',e=>{K[e.code]=1;if(e.code=='Escape'||e.code=='KeyP')togglePause();if(/^(Space|Arrow)/.test(e.code))e.preventDefault()});
addEventListener('keyup',e=>K[e.code]=0);
['gesturestart','contextmenu','dblclick'].forEach(n=>addEventListener(n,e=>e.preventDefault()));
function bind(el,k){const dn=e=>{e.preventDefault();try{el.setPointerCapture(e.pointerId)}catch(_){}IN[k]=1;el.classList.add('on')},up=()=>{IN[k]=0;el.classList.remove('on')};el.addEventListener('pointerdown',dn);['pointerup','pointercancel','lostpointercapture'].forEach(n=>el.addEventListener(n,up))}
bind($('bj'),'tj');bind($('br'),'tr');bind($('dl'),'dl');bind($('dr'),'dr');
const joy=$('joy'),knob=$('knob');let jid=null;
function jm(e){const r=joy.getBoundingClientRect(),Rr=r.width/2,dx=e.clientX-r.left-Rr,dy=e.clientY-r.top-Rr,m=Math.hypot(dx,dy)||1,k=Math.min(1,m/Rr),nx=dx/m*k,ny=dy/m*k;knob.style.transform=`translate(${nx*Rr*.5}px,${ny*Rr*.5}px)`;IN.ax=Math.abs(nx)<.18?0:nx}
joy.addEventListener('pointerdown',e=>{e.preventDefault();jid=e.pointerId;try{joy.setPointerCapture(jid)}catch(_){}jm(e)});
joy.addEventListener('pointermove',e=>{if(e.pointerId==jid)jm(e)});
const jr=e=>{if(e.pointerId==jid){jid=null;IN.ax=0;knob.style.transform=''}};['pointerup','pointercancel'].forEach(n=>joy.addEventListener(n,jr));
function readIn(){const kb=(K.ArrowRight||K.KeyD?1:0)-(K.ArrowLeft||K.KeyA?1:0),dp=(IN.dr?1:0)-(IN.dl?1:0);
 return{ax:IN.ax||dp||kb,jump:!!(IN.tj||K.Space||K.ArrowUp||K.KeyW||K.KeyZ),run:!!(IN.tr||K.ShiftLeft||K.ShiftRight||K.KeyX)}}
function applyCtl(){const m=Math.min(innerWidth,innerHeight),s=S.size,L=S.side=='left',p=m*.05,J=m*.36*s,Bj=m*.27*s,Br=m*.18*s,a=L?'left':'right',o=L?'right':'left';
 const place=(el,w,h,side,x,y)=>{Object.assign(el.style,{width:w+'px',height:h+'px',left:'auto',right:'auto',bottom:y+'px'});el.style[side]=x+'px'};
 place(joy,J,J,a,p,p);place($('dp'),J*1.5,J*.6,a,p,p);place($('bj'),Bj,Bj,o,p,p);place($('br'),Br,Br,o,p+Bj+8,p+Bj*.15);
 $('ctl').style.opacity=S.op;joy.style.display=S.layout==0?'block':'none';$('dp').style.display=S.layout==1?'flex':'none';$('br').style.display=S.run?'block':'none';
 B.classList.toggle('pix',S.pix);B.classList.toggle('smooth',!S.pix)}
// ---------- sprites ----------
const SP={};['idle','run0','run1','run2','run3','jumpA','jumpB','fall','land','hurt','win'].forEach(n=>{const i=new Image();i.src='assets/sprites/'+n+'.png';SP[n]=i});
const BS=[];for(let k=0;k<6;k++)BS.push(['i','m'].map(n=>{const i=new Image();i.src='assets/sprites/b'+k+n+'.png';return i}));
// ---------- level generation ----------
function rng(s){return()=>{s|=0;s=s+0x6D2B79F5|0;let t=Math.imul(s^s>>>15,1|s);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
const ESZ={0:[14,12],1:[12,12],2:[14,10],3:[14,14]};
function gen(w,l){
 const r=rng(w*977+l*131+7),d=(w*5+l)/49,boss=l==4,N=boss?124:100+l*14+w*3,g=[];
 for(let i=0;i<N;i++)g.push(new Uint8Array(R));
 const L={w,l,N,g,coins:[],es:[],mv:[],water:w==5&&l>0,ice:w==1,cp:-1,boss,rocks:w==6};let gh=7;
 const sl=(x,y,t=1)=>{if(x>=0&&x<N&&y>=0&&y<R)g[x][y]=t},gr=(a,b)=>{for(let x=a;x<b;x++)for(let y=gh;y<R;y++)sl(x,y)};
 const cr=(x,y,n)=>{for(let i=0;i<n;i++)L.coins.push({x:(x+i)*T+8,y:y*T+8,c:0})};
 const en=c=>{const pool=[0];if(d>.05||w>0)pool.push(1,0);if(w>1||l>1)pool.push(2);if(d>.25||w>2)pool.push(3);const t=pool[r()*pool.length|0],z=ESZ[t];L.es.push({t,w:z[0],h:z[1],x:c*T,y:t==2?(gh-3)*T:gh*T-z[1]-1})};
 gr(0,10);let x=10,cpd=0,scd=0;const end=N-(boss?36:14);
 while(x<end){
  if(!cpd&&x>N*.5){gr(x,x+5);L.cp=(x+2)*T;x+=5;cpd=1;continue}
  if(!scd&&x>N*.25){gh=7;gr(x,x+13);sl(x+2,gh-2,4);sl(x+4,gh-4,4);for(let i=6;i<11;i++)sl(x+i,gh-6,4);cr(x+6,gh-7,5);cr(x+1,gh-1,1);x+=13;scd=1;continue}
  const t=r();
  if(t<.3){const len=3+(r()*5|0);gr(x,x+len);cr(x,gh-2,len);if(len>3&&r()<.35+d*.5)en(x+(len>>1));x+=len}
  else if(t<.5){const gw=Math.min(4,2+(r()*(1+d*2.5)|0));cr(x,gh-3,gw);if(w==2||w==9)L.es.push({t:4,w:8,h:8,x:(x+gw/2)*T-4,y:VH+10,tm:r()*60|0});x+=gw;gr(x,x+4);x+=4}
  else if(t<.62){if(gh>5&&r()<.55)gh--;else if(gh<7)gh++;const len=4+(r()*3|0);gr(x,x+len);cr(x+1,gh-2,len-2);if(r()<.4)en(x+len-2);x+=len}
  else if(t<.72&&d>.04){const len=6,sw=1+(r()*(1+d*2)|0);gr(x,x+len);for(let i=0;i<sw;i++)sl(x+2+i,gh-1,2);cr(x+1,gh-3,sw+2);x+=len}
  else if(t<.86){for(let k=0;k<2;k++){const py=gh-2-k%2*1,px=x+1+k*4;sl(px,py);sl(px+1,py);cr(px,py-1,2)}x+=9;gr(x,x+3);x+=3}
  else{L.mv.push({x:x*T+4,y:gh*T,w:32,h:8,x0:x*T+4,x1:(x+9)*T-36,v:.55+d*.5,d:1,dx:0});cr(x+3,gh-3,3);x+=9;gr(x,x+4);x+=4}
 }
 if(boss){gh=7;gr(x,N);L.arena=x*T;g[N-1].fill(1);L.fx=(N-7)*T;L.es.push({t:9,w:30,h:36,x:(N-9)*T,y:7*T-37,hp:3+(w>>1),k:BK[w]})}
 else{gr(x,N);L.fx=(N-6)*T}
 L.fy=gh*T;return L}
// ---------- state ----------
let mode='menu',L=null,P={},G={lives:5,score:0,coins:0},lv=0,cam=0,fr=0,curW=0,E=[],PT=[],RK=[],rkT=60,cpOn=false,resp={x:24,y:0},from='menu';
const sol=(x,y)=>{if(x<0||x>=L.N)return true;if(y<0||y>=R)return false;const v=L.g[x][y];return v==1||v==4};
function mvX(o,dx){o.x+=dx;const x0=Math.floor(o.x/T),x1=Math.floor((o.x+o.w-.01)/T),y0=Math.floor(o.y/T),y1=Math.floor((o.y+o.h-.01)/T);for(let y=y0;y<=y1;y++){if(dx>0&&sol(x1,y)){o.x=x1*T-o.w;return true}if(dx<0&&sol(x0,y)){o.x=(x0+1)*T;return true}}return false}
function mvY(o,dy){o.y+=dy;const x0=Math.floor(o.x/T),x1=Math.floor((o.x+o.w-.01)/T),y0=Math.floor(o.y/T),y1=Math.floor((o.y+o.h-.01)/T);for(let x=x0;x<=x1;x++){if(dy>0&&sol(x,y1)){o.y=y1*T-o.h;o.vy=0;return true}if(dy<0&&sol(x,y0)){o.y=(y0+1)*T;o.vy=0;return false}}return false}
function startLevel(i){lv=Math.max(0,Math.min(49,i));const w=lv/5|0,l=lv%5;L=gen(w,l);curW=w;buildSky();cpOn=false;G.lc=0;RK=[];PT=[];
 P={x:24,y:7*T-23,w:12,h:22,vx:0,vy:0,f:1,g:false,co:0,jb:0,jh:false,dead:false,win:false,lt:0,dt:0,wt:0,ride:null};resp={x:24,y:P.y};
 spawnE();cam=0;SV.last=lv;save();setMode('play');applyAudio();hud(true)}
function spawnE(){E=L.es.map(e=>Object.assign({mhp:e.hp,dir:-1,vx:0,vy:0,dead:0,tm:e.tm||(40+(Math.random()*60|0)),sp:.4+(L.w+L.l/3)*.03,ox:e.x,oy:e.y,ph:Math.random()*6,hit:0,go:false},e))}
function die(){if(P.dead||P.win)return;P.dead=true;P.vy=-4;P.dt=0;G.lives--;SFX.hurt();hud(true)}
function pt(x,y,c,n=6){for(let i=0;i<n;i++)PT.push({x,y,vx:(Math.random()-.5)*3,vy:-Math.random()*2.5,l:25,c})}
function upd(){
 fr++;for(const m of L.mv){m.dx=m.v*m.d;m.x+=m.dx;if(m.x<m.x0){m.x=m.x0;m.d=1}if(m.x>m.x1){m.x=m.x1;m.d=-1}}
 for(const q of PT){q.x+=q.vx;q.y+=q.vy;q.vy+=.15;q.l--}PT=PT.filter(q=>q.l>0);
 const p=P;
 if(p.dead){p.vy+=.25;p.y+=p.vy;if(++p.dt>80){if(G.lives<=0){gameOver();return}p.x=resp.x;p.y=resp.y;p.vx=p.vy=0;p.dead=false;spawnE();RK=[];cam=Math.max(0,p.x-VW*.4)}return}
 const inp=p.win?{ax:0,jump:false,run:false}:readIn(),sp=(inp.run?2.1:1.45)*(L.water?.7:1),tgt=inp.ax*sp,ac_=p.g?(L.ice?.04:.16):.09,fr_=L.ice&&p.g?.02:.2;
 if(Math.abs(tgt)>.05){p.vx+=Math.max(-ac_,Math.min(ac_,tgt-p.vx));p.f=tgt>0?1:-1}else p.vx+=Math.max(-fr_,Math.min(fr_,-p.vx));
 if(inp.jump&&!p.jh)p.jb=7;p.jh=inp.jump;if(p.jb>0)p.jb--;
 if(p.g||L.water)p.co=6;else if(p.co>0)p.co--;
 if(p.jb>0&&p.co>0){p.vy=L.water?-3.2:-(4.55+Math.abs(p.vx)*.12);p.g=false;p.jb=0;p.co=0;SFX.jump()}
 if(!inp.jump&&p.vy<-1.8&&!L.water)p.vy=-1.8;
 p.vy=Math.min(L.water?2:5,p.vy+(L.water?.12:.23));
 if(p.ride)mvX(p,p.ride.dx);p.ride=null;
 if(mvX(p,p.vx))p.vx=0;
 const pb=p.y+p.h,wasG=p.g,vy0=p.vy;p.g=mvY(p,p.vy);
 if(p.vy>=0)for(const m of L.mv)if(pb<=m.y+3&&p.y+p.h>=m.y&&p.x+p.w>m.x+2&&p.x<m.x+m.w-2){p.y=m.y-p.h;p.vy=0;p.g=true;p.ride=m}
 if(!wasG&&p.g&&vy0>2){p.lt=8;pt(p.x+6,p.y+p.h,'#fff',3)}if(p.lt>0)p.lt--;
 if(p.y>VH+30){die();return}
 const x0=Math.floor(p.x/T),x1=Math.floor((p.x+p.w-.01)/T),y0=Math.floor(p.y/T),y1=Math.floor((p.y+p.h-.01)/T);
 for(let x=x0;x<=x1;x++)for(let y=y0;y<=y1;y++)if(x>=0&&x<L.N&&y>=0&&y<R&&L.g[x][y]==2&&p.y+p.h>y*T+8){die();return}
 for(const c of L.coins)if(!c.c&&Math.abs(c.x-p.x-6)<10&&Math.abs(c.y-p.y-11)<14){c.c=1;G.coins++;G.lc++;G.score+=10;SFX.coin();pt(c.x,c.y,'#ffd21a',4);if(G.coins%100==0){G.lives++;SFX.life()}hud(true)}
 if(L.cp>0&&!cpOn&&p.x>L.cp){cpOn=true;resp={x:L.cp,y:7*T-23};SFX.coin()}
 const bs=E.find(e=>e.t==9),open=!bs||bs.dead;
 if(bs&&!bs.go&&p.x>L.arena+4*T)bs.go=true;
 if(open&&!p.win&&p.x+p.w>L.fx){p.win=true;SFX.win();G.score+=500}
 if(p.win&&++p.wt>110){complete();return}
 // enemies
 const cc=cam+VW/2;
 for(const e of E){
  if(e.dead){e.dead++;continue}
  if(e.t==9&&!e.go)continue;
  if(Math.abs(e.x-cc)>VW/2+100)continue;
  if(e.t==0||e.t==3||e.t==1||e.t==9){
   e.vy=Math.min(4,e.vy+.2);
   if(e.t==1){if(e.g&&--e.tm<=0){e.vy=-3.8;e.dir=p.x<e.x?-1:1;e.tm=60+Math.random()*40|0}if(!e.g)mvX(e,e.dir*.8)}
   else if(e.t==9){e.dir=p.x<e.x?-1:1;if(e.g&&--e.tm<=0){e.vy=-5.2;e.tm=80+Math.random()*30|0}mvX(e,e.dir*(e.g?.45+L.w*.04:1.3));e.x=Math.max(L.arena+16,Math.min((L.N-3)*T-e.w,e.x));if(e.hit>0)e.hit--}
   else{if(mvX(e,e.dir*e.sp))e.dir*=-1}
   e.g=mvY(e,e.vy);
   if(e.g&&(e.t==0||e.t==3)){const fx=e.dir>0?e.x+e.w+1:e.x-1;if(!sol(Math.floor(fx/T),Math.floor((e.y+e.h+2)/T)))e.dir*=-1}
   if(e.y>VH+40)e.dead=99;
  }else if(e.t==2){e.x+=e.dir*.5;if(Math.abs(e.x-e.ox)>40)e.dir*=-1;e.y=e.oy+Math.sin(fr*.06+e.ph)*14}
  else if(e.t==4){if(e.y>=VH+10&&e.vy>=0){e.y=VH+10;if(--e.tm<0){e.vy=-(4.2+Math.random()*.8);e.tm=40+Math.random()*60|0}}else{e.vy+=.12;e.y+=e.vy;if(e.y>VH+10){e.y=VH+10;e.vy=0}}}
  if(p.x+p.w-2>e.x&&p.x+2<e.x+e.w&&p.y+p.h>e.y+1&&p.y<e.y+e.h-1){
   const stomp=e.t!=3&&e.t!=4;
   if(stomp&&p.vy>0&&pb<=e.y+7){
    p.vy=inp.jump?-4.4:-3;SFX.stomp();pt(e.x+e.w/2,e.y,'#fff',5);
    if(e.t==9){if(e.hit<=0){e.hp--;e.hit=50;SFX.boss();if(e.hp<=0){e.dead=1;G.score+=1000;SFX.win();pt(e.x+14,e.y+14,'#ffd21a',30)}}}
    else{e.dead=1;G.score+=100}hud(true)
   }else if(!(e.t==9&&e.hit>0)){die();return}
  }
 }
 // rocks
 if(L.rocks){if(--rkT<=0){rkT=Math.max(35,130-lv*2-Math.random()*40);RK.push({x:cam+Math.random()*VW,y:-8,vy:0})}
  for(const k of RK){k.vy=Math.min(4,k.vy+.1);k.y+=k.vy;if(sol(Math.floor(k.x/T),Math.floor((k.y+4)/T)))k.y=999;if(Math.abs(k.x-p.x-6)<8&&Math.abs(k.y-p.y-11)<12){die();return}}RK=RK.filter(k=>k.y<VH);}
 cam+=(Math.max(0,Math.min(L.N*T-VW,p.x-VW*.4))-cam)*.12;
 if(fr%6==0)hud();
}
// ---------- drawing ----------
const sky=document.createElement('canvas');
function buildSky(){sky.width=VW;sky.height=VH;const k=sky.getContext('2d'),P_=PAL[curW],gd=k.createLinearGradient(0,0,0,VH);gd.addColorStop(0,P_.s[0]);gd.addColorStop(1,P_.s[1]);k.fillStyle=gd;k.fillRect(0,0,VW,VH);
 const r=rng(curW+5);if(curW==7||curW==9||curW==2){k.fillStyle='#fff';for(let i=0;i<50;i++)k.fillRect(r()*VW|0,r()*70|0,1,1)}
 if(curW==7){k.fillStyle='#ffffcc';k.fillRect(VW-50,18,14,14);k.fillStyle='#d8d8a8';k.fillRect(VW-46,22,3,3)}
 if([0,3,5,6].includes(curW)){k.fillStyle='#fff3a0';k.fillRect(30,16,16,16)}
 if(curW==0||curW==8||curW==5||curW==6){k.fillStyle='#ffffffcc';for(let i=0;i<4;i++){const x=r()*VW|0,y=10+r()*40|0;k.fillRect(x,y,30,6);k.fillRect(x+6,y-4,16,4)}}}
function layer(col,sc,base,amp,ty){cx.fillStyle=col;const o=cam*sc;for(let x=0;x<VW;x+=4){const wx=x+o;let h;
 if(ty=='hills')h=amp*(.55+.3*Math.sin(wx*.025)+.15*Math.sin(wx*.07));
 else if(ty=='tri'){const q=((wx/46)%2+2)%2;h=amp*(q<1?q:2-q)*(.7+.3*Math.sin(wx*.013))}
 else if(ty=='dune')h=amp*(.5+.4*Math.sin(wx*.018)+.1*Math.sin(wx*.05));
 else{const q=Math.floor(wx/10);h=amp*(.35+((q*37%5+5)%5)/8)*((wx%10+10)%10<7?1:.2)}
 cx.fillRect(x,base-h,4,h+8)}}
const AM=[];for(let i=0;i<36;i++)AM.push({x:Math.random()*400,y:Math.random()*VH,s:Math.random()});
function amb(){const w=curW;if(w==0||w==6||w==9&&0)return;cx.fillStyle=['','#fff','#ff9a3a','#e8c880','#9ad07a','#bfe8ff','','#ffff88','#ffffff','#c070ff'][w]||'#fff';
 for(const a of AM){let x=a.x,y=a.y;if(w==1){a.y+=.4+a.s*.6;a.x+=Math.sin(fr*.03+a.s*9)*.3}else if(w==3){a.x-=2+a.s*2;a.y+=.1}else if(w==5||w==2||w==9){a.y-=.3+a.s*.5}else if(w==7){a.x+=Math.sin(fr*.02+a.s*20)*.4;a.y+=Math.cos(fr*.025+a.s*20)*.3}else if(w==4){a.y+=.3;a.x+=Math.sin(fr*.03+a.s*9)*.4}else{a.y+=.1;a.x+=.2}
  if(a.y>VH)a.y=0;if(a.y<0)a.y=VH;if(a.x<0)a.x=VW;if(a.x>VW)a.x=0;cx.fillRect(a.x|0,a.y|0,w==3?3:2,w==3?1:2)}}
function deco(x,y,tx){const h=(tx*7919)%11;if(h>2)return;const w=curW,b=y;
 const f=(c,a,b2,c2,d)=>{cx.fillStyle=c;cx.fillRect(x+a,y+b2,c2,d)};
 if(w==0){f('#2a8a2a',7,-4,1,4);f(['#ff4a6a','#fff','#ffd21a'][h],5,-8,5,4)}
 else if(w==1){f('#5a3a1a',7,-4,2,4);f('#2a6a4a',3,-10,10,6);f('#fff',5,-12,6,3)}
 else if(w==2){f('#ff6a1a',4,-5,8,5);f('#ffd21a',6,-3,4,3)}
 else if(w==3){f('#2a7a3a',7,-12,3,12);f('#2a7a3a',3,-8,4,2);f('#2a7a3a',3,-8,2,-4+4);f('#2a7a3a',10,-9,4,2)}
 else if(w==4){f('#e8e0c0',7,-4,3,4);f('#d03a3a',4,-8,9,4);f('#fff',6,-7,2,2)}
 else if(w==5){f('#ff5a8a',5,-8,2,8);f('#ff5a8a',9,-6,2,6);f('#ff8aaa',7,-10,2,10)}
 else if(w==6){f('#585450',4,-6,9,6);f('#7a7670',5,-6,4,2)}
 else if(w==7){f('#4a3a2a',7,-4,2,4);f('#8aff8a',5,-9,6,5);f('#d8ffd8',7,-7,2,2)}
 else if(w==8){f('#fff',3,-5,10,5);f('#dff0ff',6,-8,6,3)}
 else{f('#3a3a42',6,-10,4,10);f('#ff8a1a',6,-14,4,4);f('#ffd21a',7,-12,2,2)}}
function tile(x,y,t,tx,ty){const P_=PAL[curW];
 if(t==2){cx.fillStyle='#000';cx.beginPath();for(let i=0;i<2;i++){cx.moveTo(x+i*8,y+T);cx.lineTo(x+i*8+4,y+7);cx.lineTo(x+i*8+8,y+T)}cx.fill();cx.fillStyle='#d0d0d8';for(let i=0;i<2;i++){cx.beginPath();cx.moveTo(x+i*8+1,y+T);cx.lineTo(x+i*8+4,y+9);cx.lineTo(x+i*8+7,y+T);cx.fill()}return}
 cx.fillStyle=P_.g;cx.fillRect(x,y,T,T);
 if(t==4){cx.fillStyle='#ffd21a55';cx.fillRect(x,y,T,T);cx.strokeStyle='#ffd21a';cx.strokeRect(x+.5,y+.5,T-1,T-1);return}
 const top=!sol(tx,ty-1),h=(tx*7+ty*13)%5;
 cx.fillStyle='rgba(0,0,0,.18)';cx.fillRect(x+3+h*2,y+7+(h&1)*4,3,2);cx.fillRect(x,y+T-1,T,1);cx.fillRect(x+T-1,y,1,T);
 if(top){cx.fillStyle=P_.t;cx.fillRect(x,y,T,4);cx.fillStyle='rgba(0,0,0,.2)';cx.fillRect(x,y+4,T,1);deco(x,y,tx)}}
function ent(e){const x=Math.round(e.x),y=Math.round(e.y),c=EC[curW],f=(col,a,b,w,h)=>{cx.fillStyle=col;cx.fillRect(x+a,y+b,w,h)};
 if(e.dead){if(e.t!=9)f(c,0,e.h-3,e.w,3);return}
 const bl=(fr>>3)&1,d=e.dir>0?1:0;
 if(e.t==0){f('#000',-1,1,e.w+2,e.h);f(c,0,2,e.w,e.h-4);f(c,2,0,e.w-4,3);f('#fff',2+d*5,3,4,4);f('#000',3+d*5+(d?1:0),4,2,3);f('#222',bl?0:3,e.h-3,5,3);f('#222',e.w-5-(bl?0:3),e.h-3,5,3)}
 else if(e.t==1){const air=!e.g;f('#000',-1,air?-1:2,e.w+2,e.h-(air?0:2));f(c,0,air?0:3,e.w,e.h-(air?3:5));f('#fff',1,air?1:4,3,3);f('#fff',e.w-4,air?1:4,3,3);f('#000',2+d,air?2:5,1,2);f('#000',e.w-3+d,air?2:5,1,2);f('#222',0,e.h-3,3,3);f('#222',e.w-3,e.h-3,3,3)}
 else if(e.t==2){const wy=bl?-4:2;f('#000',-1,2,e.w+2,e.h-1);f(c,1,3,e.w-2,e.h-3);f('#fff',-5,wy+3,6,3);f('#fff',e.w-1,wy+3,6,3);f('#000',-5,wy+3,6,1);f('#000',e.w-1,wy+3,6,1);f('#fff',3,4,3,3);f('#fff',e.w-6,4,3,3);f('#000',4,5,1,2);f('#000',e.w-5,5,1,2)}
 else if(e.t==3){f('#000',-1,-1,e.w+2,e.h+2);f('#2a2a30',0,0,e.w,e.h);f('#d0d0d8',e.w/2-1,-4,2,4);f('#d0d0d8',-3,e.h/2-1,3,2);f('#d0d0d8',e.w,e.h/2-1,3,2);f('#d0d0d8',3,-3,2,3);f('#d0d0d8',e.w-5,-3,2,3);f('#ff2a2a',3,4,3,3);f('#ff2a2a',e.w-6,4,3,3)}
 else if(e.t==4){f('#ff6a1a',0,0,8,8);f('#ffd21a',2,2,4,4);f('#ff6a1a',3,e.vy<0?8:-4,2,4)}
 else{const fl=e.hit>0&&(fr>>2&1);if(fl)return;const im=BS[e.k][(!e.g||(e.go&&(fr>>4&1)))?1:0];if(im.naturalWidth){cx.save();cx.translate(x+e.w/2,y+e.h+1);cx.scale(e.dir>0?1:-1,1);cx.drawImage(im,-im.naturalWidth/2,-im.naturalHeight);cx.restore();return}f('#000',-2,-2,e.w+4,e.h+2);f(c,0,0,e.w,e.h);f('#ffd21a',2,-6,e.w-4,5);f('#ffd21a',2,-9,3,3);f('#ffd21a',e.w-5,-9,3,3);f('#ffd21a',e.w/2-1,-9,3,3);f('#fff',4+d*6,6,8,7);f('#fff',e.w-14+d*6,6,8,7);f('#000',6+d*6,8,3,4);f('#000',e.w-12+d*6,8,3,4);f('#000',5,e.h-8,e.w-10,3)}}
function drawFlag(){const x=L.fx,y=L.fy,bs=E.find(e=>e.t==9),open=!bs||bs.dead;cx.fillStyle='#000';cx.fillRect(x-1,y-49,4,49);cx.fillStyle='#ddd';cx.fillRect(x,y-48,2,48);cx.fillStyle='#000';cx.fillRect(x-2,y-51,6,5);
 if(open){const o=Math.sin(fr*.1)*2;cx.fillStyle='#000';cx.fillRect(x+2,y-47,20,14);cx.fillStyle='#ffd21a';cx.fillRect(x+2,y-46,18+o,12);cx.fillStyle='#000';cx.fillRect(x+7,y-43,4,6)}
 else{cx.fillStyle='#555';cx.fillRect(x+2,y-46,16,10);cx.fillStyle='#000';cx.fillRect(x+6,y-43,8,4)}
 if(L.cp>0){const c=L.cp;cx.fillStyle='#000';cx.fillRect(c,L.fy-25,3,25);cx.fillStyle=cpOn?'#ffd21a':'#cc3333';cx.fillRect(c+3,L.fy-25,10,7)}}
function drawP(){const p=P,n=p.win?'win':p.dead?'hurt':!p.g?(p.vy<-1?'jumpA':p.vy<1?'jumpB':'fall'):p.lt>0?'land':Math.abs(p.vx)>.25?'run'+((fr/(Math.abs(p.vx)>1.7?5:8)|0)%4):'idle',im=SP[n];
 if(!im.naturalWidth){cx.fillStyle='#ffd21a';cx.fillRect(p.x,p.y,p.w,p.h);return}
 const k=n=='idle'||n=='win'?1:1.28;cx.save();cx.translate(Math.round(p.x+p.w/2),Math.round(p.y+p.h+1));cx.scale(p.f,1);cx.drawImage(im,-im.naturalWidth*k/2,-im.naturalHeight*k,im.naturalWidth*k,im.naturalHeight*k);cx.restore()}
function draw(){
 cx.drawImage(sky,0,0);const P_=PAL[curW];
 if(mode=='menu'){layer(P_.f2,.2,100,60,P_.sh);layer(P_.f1,.45,118,40,P_.sh);cx.fillStyle=P_.t;cx.fillRect(0,VH-26,VW,4);cx.fillStyle=P_.g;cx.fillRect(0,VH-22,VW,22);amb();return}
 layer(P_.f2,.2,100,60,P_.sh);layer(P_.f1,.45,114,40,P_.sh);
 const cm=Math.floor(cam);cx.save();cx.translate(-cm,0);
 if(curW==2||curW==9){cx.fillStyle='#ff5a1a';for(let x=cm;x<cm+VW;x+=8)cx.fillRect(x,VH-9+Math.sin(x*.2+fr*.1)*2,8,12);cx.fillStyle='#ffd21a';cx.fillRect(cm,VH-3,VW,3)}
 else if(curW==5){cx.fillStyle='#1a5a9a';cx.fillRect(cm,VH-10,VW,10)}
 const t0=Math.floor(cm/T),t1=t0+Math.ceil(VW/T)+1;
 for(let x=t0;x<=t1&&x<L.N;x++){if(x<0)continue;for(let y=0;y<R;y++){const t=L.g[x][y];if(t)tile(x*T,y*T,t,x,y)}}
 for(const c of L.coins)if(!c.c){const k=Math.abs(Math.sin(fr*.1+c.x)),w=2+k*6;cx.fillStyle='#000';cx.fillRect(c.x-w/2-1,c.y-6,w+2,12);cx.fillStyle='#ffd21a';cx.fillRect(c.x-w/2,c.y-5,w,10);cx.fillStyle='#fff6a0';cx.fillRect(c.x-w/2+1,c.y-4,Math.max(1,w/3),4)}
 for(const m of L.mv){cx.fillStyle='#000';cx.fillRect(m.x-1,m.y-1,m.w+2,m.h+2);cx.fillStyle='#ffd21a';cx.fillRect(m.x,m.y,m.w,3);cx.fillStyle='#444';cx.fillRect(m.x,m.y+3,m.w,5)}
 drawFlag();for(const e of E)if(e.x>cm-40&&e.x<cm+VW+40&&!(e.dead>20))ent(e);
 cx.fillStyle='#7a7670';for(const k of RK){cx.fillStyle='#000';cx.fillRect(k.x-5,k.y-5,10,10);cx.fillStyle='#8a8680';cx.fillRect(k.x-4,k.y-4,8,8)}
 drawP();for(const q of PT){cx.fillStyle=q.c;cx.fillRect(q.x|0,q.y|0,2,2)}
 cx.restore();amb();const bb=E.find(e=>e.t==9&&e.go&&!e.dead);if(bb){const w=Math.min(160,VW-60),x=(VW-w)/2;cx.fillStyle='#000';cx.fillRect(x-2,16,w+4,9);cx.fillStyle='#552';cx.fillRect(x,18,w,5);cx.fillStyle='#ffd21a';cx.fillRect(x,18,w*bb.hp/bb.mhp,5);cx.font='bold 8px sans-serif';cx.textAlign='center';cx.direction='rtl';cx.fillStyle='#000';cx.fillText(BNAME[bb.k],VW/2+1,35);cx.fillStyle='#fff';cx.fillText(BNAME[bb.k],VW/2,34)}
 if(L.water){cx.fillStyle='rgba(20,100,200,.25)';cx.fillRect(0,0,VW,VH)}}
// ---------- flow ----------
let last=0,acc=0;
function loop(t){requestAnimationFrame(loop);acc+=Math.min(100,t-last);last=t;while(acc>=16.67){acc-=16.67;if(mode=='play')upd();else if(mode=='menu'){cam+=.5;fr++}}draw()}
function hud(f){$('hw').textContent=`${WN[lv/5|0]} ${(lv/5|0)+1}-${lv%5+1}`;$('hs').textContent=G.score;$('hc').textContent=G.coins;$('hl').textContent=Math.max(0,G.lives)}
function setMode(m){mode=m;B.dataset.m=m;const s=$('scr');s.style.display=(m=='play')?'none':'flex'}
const btn=(a,t,x='')=>`<button class="btn" data-a="${a}" ${x}>${t}</button>`;
function show(n){SFX.click();const s=$('scr');B.classList.remove('cfg');
 if(n=='menu'){curW=0;buildSky();setMode('menu');from='menu';s.innerHTML=`<div class="menu"><div class="col"><h1>ضربة المخلب<br>الحديدي</h1>${btn('new','ابدأ اللعبة')}${btn('cont','متابعة',SV.has?'':'disabled')}${btn('worlds','اختيار العالم')}${btn('set','الإعدادات')}</div><img class="hero" src="assets/sprites/big.png"></div>`}
 else if(n=='worlds'){s.innerHTML=`<h2>اختيار العالم</h2><div class="grid">${WN.map((w,i)=>btn('w'+i,`${i+1}<br>${w}`,i*5<=SV.u?'':'disabled')).join('')}</div>${btn('menu','العودة للقائمة الرئيسية')}`}
 else if(n.startsWith('lvl')){const w=+n.slice(3);s.innerHTML=`<h2>${WN[w]} — اختيار المرحلة</h2><div class="grid">${[0,1,2,3,4].map(l=>btn('l'+(w*5+l),(l==4?'👑 ':'')+(l+1),w*5+l<=SV.u?'':'disabled')).join('')}</div>${btn('worlds','اختيار العالم')}`}
 else if(n=='set'){B.classList.add('cfg');const tg=(k,t)=>`<div class="row"><span>${t}</span>${btn('t'+k,S[k]?'تشغيل':'إيقاف','style="min-width:0;padding:.3vh 2vh"')}</div>`,rg=(k,t,mn,mx,st)=>`<div class="row"><span>${t}</span><input type="range" data-k="${k}" min="${mn}" max="${mx}" step="${st}" value="${S[k]}"></div>`;
  s.innerHTML=`<h2>الإعدادات</h2><div class="panel">${tg('music','الموسيقى')}${rg('mv','مستوى الصوت',0,1,.05)}${tg('sfx','المؤثرات الصوتية')}${rg('sv','مستوى المؤثرات',0,1,.05)}
  <div class="row"><span>التحكم: عصا التحكم</span>${btn('side',S.side=='left'?'يسار':'يمين','style="min-width:0;padding:.3vh 2vh"')}</div>
  <div class="row"><span>نمط التحكم</span>${btn('layout',S.layout?'أسهم':'عصا','style="min-width:0;padding:.3vh 2vh"')}</div>
  ${rg('size','حجم الأزرار',.6,1.4,.05)}${rg('op','شفافية الأزرار',.2,1,.05)}${tg('run','زر الركض')}
  <div class="row"><span>ملء الشاشة</span>${btn('fs','تبديل','style="min-width:0;padding:.3vh 2vh"')}</div>
  <div class="row"><span>نمط البكسل</span>${btn('tpix',S.pix?'حاد':'ناعم','style="min-width:0;padding:.3vh 2vh"')}</div>
  <div class="row"><span>اللغة</span><span>العربية</span></div></div>${btn('back','العودة')}`}
 else if(n=='pause'){setMode('pause');from='pause';s.innerHTML=`<h2>إيقاف مؤقت</h2>${btn('res','استئناف')}${btn('rst','إعادة المرحلة')}${btn('set','الإعدادات')}${btn('menu','العودة للقائمة الرئيسية')}`}
 else if(n=='done'){const fin=lv==49;s.innerHTML=`<h2>${fin?'مبروك! أنهيت اللعبة':'المرحلة مكتملة'}</h2><div style="font-size:clamp(14px,4vh,22px);font-weight:bold">النقاط: ${G.score} &nbsp; العملات: ${G.lc}</div>${fin?'':btn('next',lv%5==4?'العالم التالي':'المرحلة التالية')}${btn('rst','إعادة المرحلة')}${btn('menu','العودة للقائمة الرئيسية')}`}
 else if(n=='over'){s.innerHTML=`<h2>انتهت اللعبة</h2><div style="font-size:clamp(14px,4vh,22px);font-weight:bold">النقاط: ${G.score}</div>${btn('rst','إعادة المرحلة')}${btn('menu','العودة للقائمة الرئيسية')}`}
 s.style.display='flex'}
function begin(i,fresh){started=true;ac();applyAudio();if(fresh||G.lives<=0){G.lives=5;G.score=0;G.coins=0}startLevel(i)}
function complete(){mode='done';B.dataset.m='done';SV.u=Math.min(49,Math.max(SV.u,lv+1));SV.last=Math.min(49,lv+1);SV.has=true;SV.hi=Math.max(SV.hi||0,G.score);save();show('done')}
function gameOver(){mode='over';B.dataset.m='over';show('over')}
function togglePause(){if(mode=='play')show('pause');else if(mode=='pause'&&$('scr').querySelector('[data-a=res]'))act('res')}
function act(a){
 if(a=='new')begin(0,true);else if(a=='cont')begin(SV.last,true);else if(a=='worlds')show('worlds');else if(a=='set'){show('set')}
 else if(a=='menu'){show('menu')}else if(a=='back'){show(from)}
 else if(a=='res'){SFX.click();setMode('play')}else if(a=='rst')begin(lv,G.lives<=0)
 else if(a=='next')begin(lv+1,false);
 else if(a[0]=='w'&&a.length<=3)show('lvl'+a.slice(1));else if(a[0]=='l')begin(+a.slice(1),true);
 else if(a=='tmusic'||a=='tsfx'||a=='trun'||a=='tpix'){const k=a.slice(1);S[k]=!S[k];save();applyAudio();applyCtl();show('set')}
 else if(a=='side'){S.side=S.side=='left'?'right':'left';save();applyCtl();show('set')}
 else if(a=='layout'){S.layout^=1;save();applyCtl();show('set')}
 else if(a=='fs'){try{const d=document.documentElement;if(document.fullscreenElement)document.exitFullscreen();else{(d.requestFullscreen||d.webkitRequestFullscreen).call(d);screen.orientation&&screen.orientation.lock&&screen.orientation.lock('landscape').catch(()=>{})}}catch(e){}}}
$('scr').addEventListener('click',e=>{const b=e.target.closest('[data-a]');if(b&&!b.disabled)act(b.dataset.a)});
$('scr').addEventListener('input',e=>{const k=e.target.dataset.k;if(k){S[k]=+e.target.value;save();applyAudio();applyCtl()}});
$('pb').addEventListener('click',()=>{if(mode=='play')show('pause')});
document.addEventListener('visibilitychange',()=>{if(document.hidden){bgm.pause();if(mode=='play')show('pause')}else applyAudio()});
function rs(){VW=Math.max(230,Math.min(340,Math.round(VH*innerWidth/innerHeight)));cv.width=VW;cv.height=VH;const sc=Math.min(innerWidth/VW,innerHeight/VH);cv.style.width=VW*sc+'px';cv.style.height=VH*sc+'px';cx.imageSmoothingEnabled=false;buildSky();applyCtl()}
addEventListener('resize',rs);rs();show('menu');requestAnimationFrame(loop);
