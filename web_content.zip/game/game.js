import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

const container = document.getElementById('game-container');

// ==========================================
// 1. CENA E RENDERIZADOR PS1 (ASPECT RATIO DINÂMICO SEM ACHATAR)
// ==========================================
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x1a232a);
scene.fog = new THREE.FogExp2(0x1a232a, 0.015);

const camera = new THREE.PerspectiveCamera(55, container.clientWidth / container.clientHeight, 0.1, 1000);
const renderer = new THREE.WebGLRenderer({ antialias: false });
renderer.setPixelRatio(1);

function resizeGame() {
    const width = container.clientWidth;
    const height = container.clientHeight;
    renderer.setSize(width, height);
    camera.aspect = width / height;
    camera.updateProjectionMatrix();
}

container.appendChild(renderer.domElement);
resizeGame();
window.addEventListener('resize', resizeGame);

// Grupos das Seções
const menuGroup = new THREE.Group();
const section1Group = new THREE.Group();
const section2Group = new THREE.Group();
const section3Group = new THREE.Group();

scene.add(menuGroup);
scene.add(section1Group);
scene.add(section2Group);
scene.add(section3Group);

section1Group.visible = false;
section2Group.visible = false;
section3Group.visible = false;

// Luzes
const ambientLight = new THREE.AmbientLight(0xddeeff, 0.6);
scene.add(ambientLight);

const sunLight = new THREE.DirectionalLight(0xffeedd, 0.7);
sunLight.position.set(20, 40, 20);
scene.add(sunLight);

// Lanterna do Jogador
const flashlight = new THREE.SpotLight(0xffffff, 25, 35, Math.PI / 4, 0.5, 1);
flashlight.visible = false;
scene.add(flashlight);
scene.add(flashlight.target);

// Helper de Setas 3D PS1
function createArrowMesh(scale = 1) {
    const mesh = new THREE.Mesh(
        new THREE.ConeGeometry(0.4 * scale, 1.0 * scale, 4),
        new THREE.MeshStandardMaterial({ color: 0xffcc00, emissive: 0xffaa00, flatShading: true })
    );
    mesh.rotation.x = Math.PI;
    return mesh;
}

// Setas de Objetivo
const npcArrow = createArrowMesh();
section2Group.add(npcArrow);

const windowArrow = createArrowMesh(0.8);
windowArrow.position.set(0, 2.5, -3.2);
section3Group.add(windowArrow);

const exitGateArrow = createArrowMesh(1.5);
exitGateArrow.visible = false;
section2Group.add(exitGateArrow);

// Sistema de Colisões
let currentColliders = [];
let section1Colliders = [];
let section2Colliders = [];
let section3Colliders = [];

function addBox(colliders, x, y, z, w, h, d) {
    const box = new THREE.Box3().setFromCenterAndSize(new THREE.Vector3(x, y, z), new THREE.Vector3(w, h, d));
    colliders.push(box);
}

// ==========================================
// CENA DO MENU PRINCIPAL (PERSEGUIÇÃO LINEAR + ÁRBORES DE Fundo)
// ==========================================
const menuFloor = new THREE.Mesh(
    new THREE.PlaneGeometry(80, 40),
    new THREE.MeshStandardMaterial({ color: 0x0f1810, flatShading: true })
);
menuFloor.rotation.x = -Math.PI / 2;
menuGroup.add(menuFloor);

// Árvores de fundo no Menu
for (let i = -30; i <= 30; i += 6) {
    const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.4, 3, 5), new THREE.MeshStandardMaterial({ color: 0x221105 }));
    trunk.position.set(i + (Math.random() - 0.5) * 2, 1.5, -8 + (Math.random() - 0.5) * 2);
    const foliage = new THREE.Mesh(new THREE.ConeGeometry(2, 4, 5), new THREE.MeshStandardMaterial({ color: 0x0a220a, flatShading: true }));
    foliage.position.set(trunk.position.x, 4, trunk.position.z);
    menuGroup.add(trunk, foliage);
}

// Bonecos do Menu
const menuNegiGroup = new THREE.Group();
const menuNegiMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.45, 1.7, 6), new THREE.MeshStandardMaterial({ color: 0x0088ff, flatShading: true }));
menuNegiMesh.position.y = 0.85;
const menuNegiHead = new THREE.Mesh(new THREE.SphereGeometry(0.3, 6, 6), new THREE.MeshStandardMaterial({ color: 0xffccaa, flatShading: true }));
menuNegiHead.position.y = 1.8;
menuNegiGroup.add(menuNegiMesh, menuNegiHead);
menuGroup.add(menuNegiGroup);

const menuEnemyGroup = new THREE.Group();
const mEnemyBody = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.6, 2.2, 6), new THREE.MeshStandardMaterial({ color: 0x050505, flatShading: true }));
mEnemyBody.position.y = 1.1;
const mEnemyEyes = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.2, 0.2), new THREE.MeshStandardMaterial({ color: 0xff0000, emissive: 0xff0000 }));
mEnemyEyes.position.set(0, 1.8, 0.35);
menuEnemyGroup.add(mEnemyBody, mEnemyEyes);
menuGroup.add(menuEnemyGroup);

// ==========================================
// SEÇÃO 1: ESTRADA E ABERTURA NA MONTANHA
// ==========================================
const baseGround1 = new THREE.Mesh(
    new THREE.PlaneGeometry(120, 100),
    new THREE.MeshStandardMaterial({ color: 0x22381b, roughness: 0.9, flatShading: true })
);
baseGround1.rotation.x = -Math.PI / 2;
section1Group.add(baseGround1);

const road = new THREE.Mesh(
    new THREE.BoxGeometry(40, 0.1, 5),
    new THREE.MeshStandardMaterial({ color: 0x3d3d3d, roughness: 0.8, flatShading: true })
);
road.position.set(12, 0.05, 0);
section1Group.add(road);

addBox(section1Colliders, 12, 5, -5, 60, 10, 4); 
addBox(section1Colliders, 12, 5, 5, 60, 10, 4);  

// Montanhas com fenda/passagem para o caminho de pedras
for (let i = -10; i <= 35; i += 8) {
    if (i >= 20 && i <= 28) continue; // Abertura na montanha na área de transição
    const hill = new THREE.Mesh(
        new THREE.ConeGeometry(7, 6, 5),
        new THREE.MeshStandardMaterial({ color: 0x1c2b17, flatShading: true })
    );
    hill.position.set(i, 3, -8);
    section1Group.add(hill);
}

for (let x = -2; x <= 22; x += 2.5) {
    const fencePost = new THREE.Mesh(new THREE.BoxGeometry(0.2, 1.4, 0.2), new THREE.MeshStandardMaterial({ color: 0x4a321a }));
    fencePost.position.set(x, 0.7, 2.8);
    section1Group.add(fencePost);
}

const stonePath = new THREE.Mesh(
    new THREE.BoxGeometry(6, 0.1, 22),
    new THREE.MeshStandardMaterial({ color: 0x555555, roughness: 0.9, flatShading: true })
);
stonePath.position.set(25, 0.05, -12);
section1Group.add(stonePath);

// ==========================================
// SEÇÃO 2: VILA, RITUAL OCULTO & 8 VELAS
// ==========================================
const villageFloor = new THREE.Mesh(new THREE.PlaneGeometry(120, 120), new THREE.MeshStandardMaterial({ color: 0x1b2b17, flatShading: true }));
villageFloor.rotation.x = -Math.PI / 2;
villageFloor.position.set(50, 0, -40);
section2Group.add(villageFloor);

// RITUAL NO MEIO DA VILA (50, 0, -40) - Visível só na perseguição
const ritualGroup = new THREE.Group();
ritualGroup.position.set(50, 0, -40);

const ritualAltar = new THREE.Mesh(
    new THREE.CylinderGeometry(3.5, 4, 0.4, 8),
    new THREE.MeshStandardMaterial({ color: 0x332222, flatShading: true })
);
ritualAltar.position.y = 0.2;
ritualGroup.add(ritualAltar);

const fireMesh = new THREE.Mesh(
    new THREE.ConeGeometry(1.0, 2.0, 5),
    new THREE.MeshStandardMaterial({ color: 0xff4400, emissive: 0xff2200, flatShading: true })
);
fireMesh.position.y = 1.2;
ritualGroup.add(fireMesh);

const ritualLight = new THREE.PointLight(0xff4400, 12, 18);
ritualLight.position.y = 2.0;
ritualGroup.add(ritualLight);

// 8 Velas ao redor do ritual
const candles = [];
for (let i = 0; i < 8; i++) {
    const angle = (i / 8) * Math.PI * 2;
    const cx = Math.cos(angle) * 3.0;
    const cz = Math.sin(angle) * 3.0;

    const candleStick = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 0.6), new THREE.MeshStandardMaterial({ color: 0xeeeeee }));
    candleStick.position.set(cx, 0.5, cz);

    const candleFlame = new THREE.Mesh(new THREE.SphereGeometry(0.12), new THREE.MeshStandardMaterial({ color: 0xff8800, emissive: 0xff5500 }));
    candleFlame.position.set(cx, 0.85, cz);
    candleFlame.visible = false;

    ritualGroup.add(candleStick, candleFlame);
    candles.push({ flame: candleFlame, lit: false });
}

ritualGroup.visible = false; // Invisível no início
section2Group.add(ritualGroup);
addBox(section2Colliders, 50, 1, -40, 7, 2, 7);

// Portão de Fuga
const exitGatePos = new THREE.Vector3(85, 0, -55);
const gateMesh = new THREE.Mesh(
    new THREE.BoxGeometry(6, 3.5, 0.4),
    new THREE.MeshStandardMaterial({ color: 0x664422, flatShading: true })
);
gateMesh.position.set(exitGatePos.x, 1.75, exitGatePos.z);
section2Group.add(gateMesh);

// Limites da Vila
addBox(section2Colliders, 50, 2, -100, 120, 10, 2);
addBox(section2Colliders, 50, 2, 20, 120, 10, 2);
addBox(section2Colliders, -10, 2, -40, 2, 10, 120);
addBox(section2Colliders, 110, 2, -40, 2, 10, 120);

const houses = [];
function createHouse(x, z, isGuestHouse) {
    const group = new THREE.Group();
    group.position.set(x, 0, z);

    const houseMesh = new THREE.Mesh(new THREE.BoxGeometry(8, 4, 8), new THREE.MeshStandardMaterial({ color: 0x5a3d23, flatShading: true }));
    houseMesh.position.y = 2; group.add(houseMesh);

    const roof = new THREE.Mesh(new THREE.ConeGeometry(6.5, 2.5, 4), new THREE.MeshStandardMaterial({ color: 0x38190c, flatShading: true }));
    roof.position.y = 5.25; roof.rotation.y = Math.PI / 4; group.add(roof);

    const door = new THREE.Mesh(new THREE.BoxGeometry(1.8, 2.8, 0.2), new THREE.MeshStandardMaterial({ color: 0x241105 }));
    door.position.set(0, 1.4, 4.05); group.add(door);

    section2Group.add(group);
    addBox(section2Colliders, x, 2, z, 8.2, 4, 8.2);

    houses.push({ x, z, doorPos: new THREE.Vector3(x, 0, z + 4.5), isGuestHouse });
}

createHouse(35, -25, false);
createHouse(65, -25, false);
createHouse(55, -45, true); 

// Garota (NPC)
const girlNPCGroup = new THREE.Group();
const girlBody = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.4, 1.2), new THREE.MeshStandardMaterial({ color: 0xcc3333, flatShading: true }));
girlBody.position.y = 0.6;
const girlHead = new THREE.Mesh(new THREE.SphereGeometry(0.3), new THREE.MeshStandardMaterial({ color: 0xffccaa, flatShading: true }));
girlHead.position.y = 1.3;
girlNPCGroup.add(girlBody, girlHead);
girlNPCGroup.position.set(38, 0, -20);
section2Group.add(girlNPCGroup);

// Monstro Perseguidor PS1
const enemyGroup = new THREE.Group();
const enemyBody = new THREE.Mesh(new THREE.CylinderGeometry(0.4, 0.5, 2.0, 6), new THREE.MeshStandardMaterial({ color: 0x111111, roughness: 0.2, flatShading: true }));
enemyBody.position.y = 1.0;
const enemyEyes = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.15, 0.2), new THREE.MeshStandardMaterial({ color: 0xff0000, emissive: 0xff0000 }));
enemyEyes.position.set(0, 1.6, 0.3);
enemyGroup.add(enemyBody, enemyEyes);
enemyGroup.position.set(25, 0, -25);
enemyGroup.visible = false;
section2Group.add(enemyGroup);

// Amuletos
const amulets = [
    { pos: new THREE.Vector3(38, 0.5, -20), collected: false, mesh: null, arrow: null },
    { pos: new THREE.Vector3(68, 0.5, -40), collected: false, mesh: null, arrow: null },
    { pos: new THREE.Vector3(35, 0.5, -55), collected: false, mesh: null, arrow: null }
];

amulets.forEach(a => {
    const gem = new THREE.Mesh(new THREE.OctahedronGeometry(0.35), new THREE.MeshStandardMaterial({ color: 0x00ffff, emissive: 0x00aaaa, flatShading: true }));
    gem.position.copy(a.pos);
    gem.visible = false;
    section2Group.add(gem);
    a.mesh = gem;

    const arrow = createArrowMesh(0.7);
    arrow.position.set(a.pos.x, a.pos.y + 1.8, a.pos.z);
    arrow.visible = false;
    section2Group.add(arrow);
    a.arrow = arrow;
});

// ==========================================
// SEÇÃO 3: INTERIOR DO QUARTO
// ==========================================
const roomFloor = new THREE.Mesh(new THREE.PlaneGeometry(8, 8), new THREE.MeshStandardMaterial({ color: 0x3d2715, flatShading: true }));
roomFloor.rotation.x = -Math.PI / 2;
section3Group.add(roomFloor);

const intWallMat = new THREE.MeshStandardMaterial({ color: 0x593e25, flatShading: true });
const wB = new THREE.Mesh(new THREE.BoxGeometry(8, 4, 0.3), intWallMat); wB.position.set(0, 2, -4); section3Group.add(wB);
const wF = new THREE.Mesh(new THREE.BoxGeometry(8, 4, 0.3), intWallMat); wF.position.set(0, 2, 4); section3Group.add(wF);
const wL = new THREE.Mesh(new THREE.BoxGeometry(0.3, 4, 8), intWallMat); wL.position.set(-4, 2, 0); section3Group.add(wL);
const wR = new THREE.Mesh(new THREE.BoxGeometry(0.3, 4, 8), intWallMat); wR.position.set(4, 2, 0); section3Group.add(wR);

const bedGroup = new THREE.Group();
const bedFrame = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.5, 3.2), new THREE.MeshStandardMaterial({ color: 0x4a2a12, flatShading: true }));
bedFrame.position.y = 0.25;
const mattress = new THREE.Mesh(new THREE.BoxGeometry(2.0, 0.4, 3.0), new THREE.MeshStandardMaterial({ color: 0xeeeeee, flatShading: true }));
mattress.position.y = 0.6;
const pillow = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.2, 0.8), new THREE.MeshStandardMaterial({ color: 0xcc3333, flatShading: true }));
pillow.position.set(0, 0.8, -1.0);

bedGroup.add(bedFrame, mattress, pillow);
bedGroup.position.set(-2.5, 0, 1.5);
section3Group.add(bedGroup);
addBox(section3Colliders, -2.5, 0.5, 1.5, 2.4, 1.0, 3.4);

const windowGlass = new THREE.Mesh(new THREE.BoxGeometry(2, 2, 0.05), new THREE.MeshStandardMaterial({ color: 0x4477aa, emissive: 0x112233 }));
windowGlass.position.set(0, 2, -3.8);
section3Group.add(windowGlass);

addBox(section3Colliders, 0, 2, -4, 8, 4, 0.6);
addBox(section3Colliders, 0, 2, 4, 8, 4, 0.6);
addBox(section3Colliders, -4, 2, 0, 0.6, 4, 8);
addBox(section3Colliders, 4, 2, 0, 0.6, 4, 8);

// ==========================================
// JOGADOR PRINCIPAL
// ==========================================
let negiPlayer = null;
const loader = new GLTFLoader();

loader.load('character.glb', (gltf) => {
    negiPlayer = gltf.scene;
    negiPlayer.position.set(0, 0, 0);
    negiPlayer.scale.set(2.5, 2.5, 2.5);
    scene.add(negiPlayer);
}, undefined, () => {
    const group = new THREE.Group();
    const body = new THREE.Mesh(new THREE.BoxGeometry(0.8, 1.8, 0.6), new THREE.MeshStandardMaterial({ color: 0x0088ff, flatShading: true }));
    body.position.y = 0.9; group.add(body);
    negiPlayer = group;
    scene.add(negiPlayer);
});

let gameState = "MENU";
let isPaused = false;
let isRunning = false;
let currentSection = 1;
currentColliders = section1Colliders;
let firstPersonYaw = Math.PI;
let ritualTimer = 0;

const ui = document.getElementById('ui');
const speaker = document.getElementById('speaker');
const dialogText = document.getElementById('dialog-text');
const nextBtn = document.getElementById('next-btn');

function showDialog(who, text) {
    ui.style.display = 'block';
    speaker.innerText = who + ":";
    dialogText.innerText = text;
}

function loadSection(sectionNum) {
    menuGroup.visible = false;
    section1Group.visible = (sectionNum === 1);
    section2Group.visible = (sectionNum === 2);
    section3Group.visible = (sectionNum === 3);
    currentSection = sectionNum;

    if (sectionNum === 1) currentColliders = section1Colliders;
    if (sectionNum === 2) currentColliders = section2Colliders;
    if (sectionNum === 3) currentColliders = section3Colliders;
}

// ANIMAÇÃO PROCEDURAL
function animateProcedural(mesh, moving, running, time) {
    if (!mesh) return;

    if (moving) {
        const speedMultiplier = running ? 18 : 11;
        const bounceHeight = running ? 0.22 : 0.12;
        const tilt = running ? 0.15 : 0.08;

        mesh.position.y = Math.abs(Math.sin(time * speedMultiplier)) * bounceHeight;
        mesh.rotation.z = Math.sin(time * (speedMultiplier / 2)) * tilt;
        mesh.rotation.x = tilt;
    } else {
        const breatheSpeed = 3;
        mesh.position.y = Math.sin(time * breatheSpeed) * 0.03;
        mesh.rotation.z = 0;
        mesh.rotation.x = 0;
    }
}

// CONTROLES DE PAUSA E INTERFACE
const pauseBtn = document.getElementById('pause-btn');
const pauseOverlay = document.getElementById('pause-overlay');
const resumeBtn = document.getElementById('resume-btn');
const menuBtn = document.getElementById('menu-btn');

function togglePause() {
    if (gameState === "MENU") return;
    isPaused = !isPaused;
    pauseOverlay.style.display = isPaused ? 'flex' : 'none';
}

pauseBtn.onclick = togglePause;
resumeBtn.onclick = togglePause;
menuBtn.onclick = () => location.reload();

// CORRIDA
const runBtn = document.getElementById('run-btn');
const setRun = (active) => {
    isRunning = active;
    if (active) runBtn.classList.add('active');
    else runBtn.classList.remove('active');
};

runBtn.addEventListener('pointerdown', (e) => { e.preventDefault(); setRun(true); });
window.addEventListener('pointerup', () => setRun(false));

function applyGraphicsSettings(quality) {
    if (quality === 'low') {
        renderer.shadowMap.enabled = false;
        renderer.setPixelRatio(0.65);
        scene.fog.density = 0.025;
    } else if (quality === 'medium') {
        renderer.shadowMap.enabled = false;
        renderer.setPixelRatio(1.0);
        scene.fog.density = 0.015;
    } else if (quality === 'high') {
        renderer.shadowMap.enabled = true;
        renderer.shadowMap.type = THREE.PCFSoftShadowMap;
        renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
        scene.fog.density = 0.010;
        sunLight.castShadow = true;
        flashlight.castShadow = true;
    }
}

document.getElementById('start-game-btn').onclick = function() {
    const quality = document.getElementById('graphics-select').value;
    applyGraphicsSettings(quality);
    document.getElementById('main-menu').style.display = 'none';
    document.getElementById('story-overlay').style.display = 'flex';
};

document.getElementById('start-story-btn').onclick = function() {
    document.getElementById('story-overlay').style.display = 'none';
    document.getElementById('chapter-title').style.display = 'block';
    loadSection(1);
    gameState = "SECTION_1_2D";
};

nextBtn.onclick = function(e) {
    e.preventDefault();
    ui.style.display = 'none';

    if (gameState === "TALK_ROAD") {
        gameState = "DESCENDING";
    } else if (gameState === "TALK_GIRL") {
        gameState = "EXPLORE_VILLAGE";
    } else if (gameState === "LOOK_WINDOW_DIALOG") {
        loadSection(2);

        if (negiPlayer) {
            negiPlayer.visible = true;
            negiPlayer.position.set(55, 0, -40); 
            negiPlayer.rotation.y = 0;
        }

        gameState = "NIGHT_ESCAPE";
        ritualGroup.visible = true; // APARECE O RITUAL NA PERSEGUIÇÃO

        scene.background = new THREE.Color(0x0a0f1d);
        scene.fog = new THREE.FogExp2(0x0a0f1d, 0.02);
        ambientLight.color = new THREE.Color(0x445577);
        ambientLight.intensity = 0.5;
        flashlight.visible = true;

        girlNPCGroup.visible = false;
        npcArrow.visible = false;
        
        enemyGroup.visible = true;
        enemyGroup.position.set(25, 0, -25);

        amulets.forEach(a => {
            if (!a.collected) {
                a.mesh.visible = true;
                a.arrow.visible = true;
            }
        });
        exitGateArrow.visible = true;

        const inv = document.getElementById('inventory');
        if (inv) inv.style.display = 'block';

        const title = document.getElementById('chapter-title');
        if (title) title.innerText = "CAPITULO 2: A FUGA DO RITUAL";

        camTarget.set(49, 8, -32);
        camLook.set(55, 1, -40);
        camera.position.copy(camTarget);
        camera.lookAt(camLook);
    }
};

// JOYSTICK
const joystickZone = document.getElementById('joystick-zone');
const joystickKnob = document.getElementById('joystick-knob');
let joystickInput = { x: 0, y: 0 };
let joystickActive = false;

function handleJoystick(evt) {
    if (!joystickActive) return;
    const touch = evt.touches ? evt.touches[0] : evt;
    const rect = joystickZone.getBoundingClientRect();
    let dx = touch.clientX - (rect.left + rect.width / 2);
    let dy = touch.clientY - (rect.top + rect.height / 2);
    const dist = Math.hypot(dx, dy);
    const maxR = 35;
    if (dist > maxR) { dx = (dx / dist) * maxR; dy = (dy / dist) * maxR; }
    joystickKnob.style.transform = `translate(${dx}px, ${dy}px)`;
    joystickInput = dist < 5 ? { x: 0, y: 0 } : { x: dx / maxR, y: dy / maxR };
}

joystickZone.addEventListener('pointerdown', (e) => { joystickActive = true; handleJoystick(e); });
window.addEventListener('pointermove', handleJoystick);
window.addEventListener('pointerup', () => { joystickActive = false; joystickKnob.style.transform = 'translate(0,0)'; joystickInput = { x: 0, y: 0 }; });

document.getElementById('action-btn').addEventListener('click', () => {
    if (!negiPlayer || isPaused) return;

    if (currentSection === 2 && gameState === "EXPLORE_VILLAGE") {
        if (negiPlayer.position.distanceTo(girlNPCGroup.position) < 3.5) {
            gameState = "TALK_GIRL";
            showDialog("Garota", "Podes descansar no casarão do fundo (Casa 3). Vai lá!");
            return;
        }

        const guestHouse = houses.find(h => h.isGuestHouse);
        if (negiPlayer.position.distanceTo(guestHouse.doorPos) < 3.5) {
            loadSection(3);
            negiPlayer.position.set(0, 0, 2);
            firstPersonYaw = Math.PI;
            if (negiPlayer) negiPlayer.visible = false;

            gameState = "INSIDE_HOUSE";
            showDialog("Negi", "Entrei no quarto. Que barulho estranho é esse lá fora? Vou olhar pela janela!");
            return;
        }
    }

    if (currentSection === 3 && gameState === "INSIDE_HOUSE") {
        if (negiPlayer.position.distanceTo(new THREE.Vector3(0, 0, -3.5)) < 3.0) {
            gameState = "LOOK_WINDOW_DIALOG";
            showDialog("Negi", "O QUE?! Eles estão acendendo as velas do ritual! PRECISO ACHAR OS AMULETOS ANTES QUE AS 8 VELAS SE ACENDAM!");
            return;
        }
    }
});

function canMoveTo(newPos) {
    const pBox = new THREE.Box3().setFromCenterAndSize(newPos, new THREE.Vector3(0.7, 1.8, 0.7));
    for (let box of currentColliders) {
        if (box.intersectsBox(pBox)) return false;
    }
    return true;
}

// GAME OVER
function triggerGameOver(reason = "O MONSTRO TE PEGOU") {
    gameState = "GAME_OVER";
    if (document.getElementById('game-over-screen')) return;

    const gameOverOverlay = document.createElement('div');
    gameOverOverlay.id = 'game-over-screen';
    gameOverOverlay.style.cssText = `
        position: absolute; top: 0; left: 0; width: 100%; height: 100%;
        background: radial-gradient(circle, #330000 0%, #050000 95%);
        display: flex; flex-direction: column; justify-content: center; align-items: center;
        z-index: 9999; color: white; font-family: 'Press Start 2P', monospace; text-align: center;
    `;
    gameOverOverlay.innerHTML = `
        <div class="ps1-border" style="border-color: #ff0000; box-shadow: inset 0 0 20px #ff0000;">
            <h1 style="color: #ff0000; font-size: 1.5rem; text-shadow: 4px 4px 0px #550000; margin-bottom: 20px;">VOCE MORREU</h1>
            <p style="color: #aaa; font-size: 0.55rem; line-height: 1.6; margin-bottom: 30px;">${reason}</p>
            <button id="restart-btn" class="ps1-btn">CONTINUAR</button>
        </div>
    `;
    container.appendChild(gameOverOverlay);
    document.getElementById('restart-btn').onclick = () => location.reload();
}

// VITÓRIA
function triggerVictory() {
    gameState = "VICTORY";
    if (document.getElementById('victory-screen')) return;

    const winOverlay = document.createElement('div');
    winOverlay.id = 'victory-screen';
    winOverlay.style.cssText = `
        position: absolute; top: 0; left: 0; width: 100%; height: 100%;
        background: radial-gradient(circle, #002200 0%, #000500 95%);
        display: flex; flex-direction: column; justify-content: center; align-items: center;
        z-index: 9999; color: white; font-family: 'Press Start 2P', monospace; text-align: center;
    `;
    winOverlay.innerHTML = `
        <div class="ps1-border" style="border-color: #00ff00; box-shadow: inset 0 0 20px #00ff00;">
            <h1 style="color: #00ff00; font-size: 1.3rem; text-shadow: 4px 4px 0px #005500; margin-bottom: 20px;">VOCE ESCAPOU!</h1>
            <p style="color: #aaa; font-size: 0.55rem; line-height: 1.6; margin-bottom: 30px;">NEGI CONSEGUIU QUEBRAR O SELO E ESCAPAR COM VIDA.</p>
            <button id="win-restart-btn" class="ps1-btn" style="background: #008800; border-color: #00ff00;">MENU PRINCIPAL</button>
        </div>
    `;
    container.appendChild(winOverlay);
    document.getElementById('win-restart-btn').onclick = () => location.reload();
}

// LOOP PRINCIPAL
let camTarget = new THREE.Vector3();
let camLook = new THREE.Vector3();

function animate() {
    requestAnimationFrame(animate);
    if (isPaused) return;

    const time = Date.now() * 0.005;

    // --- TELA DE MENU PRINCIPAL (PERSEGUIÇÃO EM LINHA RETA) ---
    if (gameState === "MENU") {
        const posX = Math.sin(time * 0.8) * 12;

        // Negi foge na frente
        menuNegiGroup.position.set(posX, 0, 0);
        menuNegiGroup.rotation.y = Math.cos(time * 0.8) > 0 ? Math.PI / 2 : -Math.PI / 2;
        animateProcedural(menuNegiGroup, true, true, time);

        // Monstro atrás perseguindo
        const enemyOffsetX = posX - (Math.cos(time * 0.8) > 0 ? 3.5 : -3.5);
        menuEnemyGroup.position.set(enemyOffsetX, 0, 0);
        menuEnemyGroup.rotation.y = menuNegiGroup.rotation.y;

        camera.position.set(0, 3, 10);
        camera.lookAt(0, 1.2, 0);
    }

    if (negiPlayer && gameState !== "GAME_OVER" && gameState !== "VICTORY" && gameState !== "MENU") {
        let isMoving = false;
        const baseSpeed = isRunning ? 0.24 : 0.14;

        // SEÇÃO 1
        if (gameState === "SECTION_1_2D") {
            if (Math.abs(joystickInput.x) > 0.1) {
                isMoving = true;
                const nextX = negiPlayer.position.x + joystickInput.x * baseSpeed;
                if (canMoveTo(new THREE.Vector3(nextX, 0, 0))) {
                    negiPlayer.position.x = nextX;
                    negiPlayer.rotation.y = joystickInput.x > 0 ? Math.PI / 2 : -Math.PI / 2;
                }
            }
            animateProcedural(negiPlayer, isMoving, isRunning, time);

            camTarget.set(negiPlayer.position.x, 3, 10);
            camLook.set(negiPlayer.position.x, 1.5, 0);

            if (negiPlayer.position.x >= 24) {
                gameState = "TALK_ROAD";
                showDialog("Negi", "A estrada principal esta bloqueada... vou ter que descer por esse caminho de pedras na fenda da montanha!");
            }
        }
        else if (gameState === "DESCENDING") {
            negiPlayer.position.z -= baseSpeed;
            negiPlayer.rotation.y = Math.PI;
            animateProcedural(negiPlayer, true, isRunning, time);

            if (negiPlayer.position.z <= -10) {
                loadSection(2);
                negiPlayer.position.set(30, 0, -15);
                gameState = "EXPLORE_VILLAGE";
            }
        }

        // SEÇÃO 2 (VILA)
        else if ((gameState === "EXPLORE_VILLAGE" || gameState === "NIGHT_ESCAPE") && currentSection === 2) {
            if (Math.abs(joystickInput.x) > 0.05 || Math.abs(joystickInput.y) > 0.05) {
                isMoving = true;
                const angle = -Math.PI / 4;
                const mx = joystickInput.x * Math.cos(angle) - joystickInput.y * Math.sin(angle);
                const mz = joystickInput.x * Math.sin(angle) + joystickInput.y * Math.cos(angle);

                const nextPos = negiPlayer.position.clone().add(new THREE.Vector3(mx * baseSpeed, 0, mz * baseSpeed));

                if (canMoveTo(nextPos)) {
                    negiPlayer.position.copy(nextPos);
                    negiPlayer.rotation.y = Math.atan2(mx, mz);
                }
            }

            animateProcedural(negiPlayer, isMoving, isRunning, time);

            if (gameState === "EXPLORE_VILLAGE") {
                npcArrow.visible = true;
                npcArrow.position.set(girlNPCGroup.position.x, 2.2 + Math.sin(time) * 0.2, girlNPCGroup.position.z);
                npcArrow.rotation.y += 0.03;
            }
        }

        // SEÇÃO 3 (QUARTO)
        else if (currentSection === 3 && gameState === "INSIDE_HOUSE") {
            firstPersonYaw -= joystickInput.x * 0.04;

            windowArrow.position.y = 2.4 + Math.sin(time) * 0.15;
            windowArrow.rotation.y += 0.03;

            if (Math.abs(joystickInput.y) > 0.1) {
                const moveSpeed = -joystickInput.y * (isRunning ? 0.14 : 0.08);
                const forwardX = Math.sin(firstPersonYaw) * moveSpeed;
                const forwardZ = Math.cos(firstPersonYaw) * moveSpeed;

                const nextPos = negiPlayer.position.clone().add(new THREE.Vector3(forwardX, 0, forwardZ));
                if (canMoveTo(nextPos)) {
                    negiPlayer.position.copy(nextPos);
                }
            }
        }

        // FUGA NOTURNA E ACENDIMENTO DAS 8 VELAS
        if (gameState === "NIGHT_ESCAPE") {
            const monsterSpeed = 0.065; 
            const dir = new THREE.Vector3().subVectors(negiPlayer.position, enemyGroup.position).normalize();
            enemyGroup.position.add(dir.multiplyScalar(monsterSpeed));
            enemyGroup.lookAt(negiPlayer.position);

            exitGateArrow.position.set(exitGatePos.x, 4.5 + Math.sin(time) * 0.3, exitGatePos.z);
            exitGateArrow.rotation.y += 0.03;

            // Timer para acender as 8 velas gradualmente (1 vela a cada ~6 segundos)
            ritualTimer += 0.016; // aprox 60fps
            const litCount = Math.min(8, Math.floor(ritualTimer / 6));

            for (let i = 0; i < 8; i++) {
                if (i < litCount && !candles[i].lit) {
                    candles[i].lit = true;
                    candles[i].flame.visible = true;
                }
            }

            // Se as 8 velas acenderem -> Ritual concluído (Derrota)
            if (litCount >= 8) {
                triggerGameOver("AS 8 VELAS DO RITUAL SE ACENDERAM E SUA ALMA FOI SELADA!");
            }

            let collectedCount = 0;
            amulets.forEach(a => {
                if (!a.collected) {
                    a.arrow.position.y = a.pos.y + 1.8 + Math.sin(time) * 0.15;
                    a.arrow.rotation.y += 0.03;

                    if (negiPlayer.position.distanceTo(a.pos) < 2.0) {
                        a.collected = true;
                        a.mesh.visible = false;
                        a.arrow.visible = false;
                    }
                } else {
                    collectedCount++;
                }
            });

            const countElem = document.getElementById('amulet-count');
            if (countElem) countElem.innerText = `${collectedCount}`;

            if (collectedCount === 3 && negiPlayer.position.distanceTo(exitGatePos) < 3.5) {
                triggerVictory();
            }

            if (enemyGroup.position.distanceTo(negiPlayer.position) < 1.3) {
                triggerGameOver("O MONSTRO DA VILA TE PEGOU!");
            }
        }

        // CÂMERA
        if (currentSection === 1 || currentSection === 2) {
            if (gameState !== "SECTION_1_2D") {
                camTarget.set(negiPlayer.position.x - 6, negiPlayer.position.y + 8, negiPlayer.position.z + 8);
                camLook.set(negiPlayer.position.x, negiPlayer.position.y + 1, negiPlayer.position.z);
            }
            camera.position.lerp(camTarget, 0.1);
            camera.lookAt(camLook);
        } 
        else if (currentSection === 3) {
            camera.position.set(negiPlayer.position.x, 1.6, negiPlayer.position.z);
            const lookDir = new THREE.Vector3(
                negiPlayer.position.x + Math.sin(firstPersonYaw),
                1.6,
                negiPlayer.position.z + Math.cos(firstPersonYaw)
            );
            camera.lookAt(lookDir);
        }

        flashlight.position.set(negiPlayer.position.x, negiPlayer.position.y + 1.8, negiPlayer.position.z);
        const forward = new THREE.Vector3(0, 0, 1).applyAxisAngle(new THREE.Vector3(0, 1, 0), negiPlayer.rotation.y);
        flashlight.target.position.copy(negiPlayer.position).add(forward.multiplyScalar(10));
    }

    renderer.render(scene, camera);
}

animate();