# v110 - OCEAN OVERHAUL (merged on top of v109 "breadcrumbs")

Everything about the sea and the Ocean Voyage rebuilt. No animals or wildlife anywhere (by request).

## New files
- `ocean_surface.js` - the sea surface. World-space swell (sharp crests, broad troughs) generated from ONE wave table for both the vertex shader and the JS twin (`oceanHeight` / `oceanGrad`), so the boat now rides the water you actually see (the old shader used local coordinates that travelled with the player and never matched `getWaterWaveY`). Radial mesh (dense under the camera, sparse at the horizon, ~18k verts instead of 262k). Fine chop normals, sun glitter, sky reflection, whitecaps (more in storms), shore foam bands, depth colouring from a shore-depth map (`ShoreMap`, built incrementally from the real terrain, 1 row per frame), Snell's window when looking up from below.
- `ocean_assets.js` - painterly canvas textures, merge/loft helpers, sway shader, and the new BOAT: lofted plank hull, deck, aft cabin with lit windows, mast with patched lateen sail and pennant (flutter in the vertex shader), bow lantern, running lights, and the piezo-quartz drive glowing at the stern. Pitches and rolls with the real wave slope.
- `ocean_seabed.js` - every dive stop is now a SEAMOUNT: sculpted floor, sand ripples, caustics, kelp forests, seagrass, crystal gardens, rock arches, falling away into the abyss. Rebuilt wreck (lofted broken fuselage, wing, fin, torn ribs, cockpit, dying nav light), monolith (hewn basalt, glowing inlay, plaque), memorial (leaning obelisk, toppled capstone, drifting cloth strips, lantern posts), disc case, hydrothermal vents (chimneys, sulphur crust, glowing throats, plume).

## game.js
- Water material/mesh/uniforms replaced; `getWaterWaveY` now uses `oceanHeight` (storm amplitude via `getWaterAmp()`).
- `makeBoatMesh()` uses the new boat (scale 0.78 so existing camera shots still frame it); `updateBoatRig()` tilts it to the swell; the old whole-object roll writes are gone. Wake is longer, wider and starts at the stern.
- `spawnLandmarkCluster()` builds seamounts + new landmarks; interaction anchors (`monolithPos`, `wreckPos`, `memorialPos`, `discCasePos`, `ventPositions`) moved onto the new objects. Sea floor is solid for the diver. Landmark animations tick each frame.

## Safety net
Written without access to a GPU. If any new shader fails to compile, `installShaderFallback` drops that material to plain three.js shading and logs the GLSL error to the console (look for `[ocean] shader ... failed`), instead of the sea disappearing. Please send me that log if you ever see it.

## Tests run here
Node: wave gradient vs finite difference, ocean mesh winding, shader patch assembly (all includes replaced, all uniforms supplied, braces balanced), and a stub-three smoke test constructing every new object. Not run: anything on a real GPU.
