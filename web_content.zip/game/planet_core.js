// =====================================================================================
// planet_core.js - the world is a SPHERE (cube-sphere: six face charts).
//
// CUBE-SPHERE (v33): the ground you walk on is one of six square CHARTS (faces of a cube projected onto the sphere with the
// equiangular mapping). Each chart is a flat (x, z) plane exactly like before, so all physics / chunking / collision are
// untouched, but there is NO antimeridian and NO pole pinch: you cross from face to face. A chart is addressed by
// (face, x, z) with |x|,|z| <= CHART_HALF (= a quarter of a great circle / 2 = C/8). Beyond that the formula keeps working
// for a while (it is just the same sphere seen through a stretched chart), which is what lets chunks stream across a face
// edge before the player is handed over to the neighbouring chart (see resolveChart + recenterWorldIfNeeded in game.js).
// Face 0 is centred on the original spawn (32 deg N, lon 0) with x = east, z = south, so the start of the world is unchanged.
// The terrain generator (terrain_core.js) still thinks in an equirectangular lon/lat "map" space; chartToMap() turns a chart
// point into that space (map x = lon * R, map z = (LAT0 - lat) * R).
//
// ORIGINAL NOTES (equirectangular model, still the generator's coordinate system) ----
//
// Map model: an equirectangular unwrapping of the sphere (see the note on poles in game.js notes).
//   * x runs EAST and WRAPS with period PLANET_C (the equator's circumference). Walk far enough east
//     and you arrive back where you started. All terrain/river/prop lookups wrap x, so there is no edge.
//   * z runs SOUTH (compass north is -z). Latitude = PLANET_LAT0 - z / PLANET_R. The two poles are the
//     world's hard limits: the walkable band stops at +-POLE_LIMIT_DEG, behind rising polar ice.
//   * The world is the SPHERE 3500 km -> see PLANET_C below for the size actually used and why.
//   * The ground is rendered as a locally-flat tangent patch around the viewer (so all existing physics,
//     chunking and collision stay exact) and the shaders bend it away below the horizon by d^2/(2R) so you
//     can see the planet curve (see the project_vertex patch in game.js).
//   * Sun/day-night is global: the sun sits over one meridian, so one hemisphere is lit and the other dark.
//     Local solar time at longitude lon is  T = T_universal + lon/(2*pi)  (east of you is later in the day).
// Shared by game.js, river_core.js and the river worker (pure maths only).
// =====================================================================================
export const PLANET_UNITS_PER_METER = 4.25;                     // must match UNITS_PER_METER in game.js
// WORLD SIZE: 500 chunk columns of 3500 units = 1,750,000 units around the equator (~412 km at 4.25 units/m).
// Chosen for float32 safety: the player is always re-centred into [-C/2, C/2), so no coordinate ever exceeds ~875,000
// (float32 spacing 0.0625 there, vs 0.5 at the 7M a 3500 km world would need). WebGL has no float64, so this is the
// largest "round" circumference that keeps instance matrices, shader world-positions and shadows visually exact.
export const PLANET_CHUNK_COLS = 500;
export const PLANET_C = PLANET_CHUNK_COLS * 3500;               // 1,750,000 world units
export const PLANET_CIRC_M = PLANET_C / PLANET_UNITS_PER_METER; // ~411.8 km
export const PLANET_R = PLANET_C / (2 * Math.PI);               // ~2,367,000 world units
export const PLANET_HALF_C = PLANET_C / 2;
export const PLANET_LAT0 = 32 * Math.PI / 180;                  // the original origin (spawn region) sits at 32 deg N
export const POLE_LIMIT_DEG = 87.5;                             // impassable beyond this latitude
export const PLANET_SEAM_W = 100000;                            // width of the antimeridian blend band (world units)
export const AXIAL_TILT_DEG = 0;                                // 0 = permanent equinox (day/night exactly 12h everywhere).
                                                                // >0 enables seasons; gameplay clocks assume 0, so it's opt-in.
export const YEAR_DAYS = 48;                                    // game days per year when AXIAL_TILT_DEG > 0

// x wrapped into [-C/2, C/2)
export function wrapX(x) { return x - PLANET_C * Math.floor((x + PLANET_HALF_C) / PLANET_C); }
// shortest signed difference on the wrapped axis
export function wrapD(d) { return d - PLANET_C * Math.round(d / PLANET_C); }
// latitude (radians, +north) of map z
export function latOfZ(z) { return PLANET_LAT0 - z / PLANET_R; }
export function zOfLat(lat) { return (PLANET_LAT0 - lat) * PLANET_R; }
// longitude (radians, 0 at map x = 0, +east)
export function lonOfX(x) { return (x / PLANET_C) * 2 * Math.PI; }
export const POLE_Z_NORTH = zOfLat(POLE_LIMIT_DEG * Math.PI / 180); // most northerly walkable z (negative)
export const POLE_Z_SOUTH = zOfLat(-POLE_LIMIT_DEG * Math.PI / 180);
// 0..1 how deep into the polar caps a latitude is (0 below 62 deg, 1 at the walkable limit)
export function polarness(lat) {
    const a = Math.abs(lat) * 180 / Math.PI;
    const t = Math.min(1, Math.max(0, (a - 62) / (POLE_LIMIT_DEG - 62)));
    return t * t * (3 - 2 * t);
}

// Local direction to the sun as (east, up, north) for solar time dayTime (0..1, noon = 0.5), latitude lat,
// and day-of-year phase (only used when AXIAL_TILT_DEG > 0). Writes into out [e,u,n]; returns elevation sin.
export function sunEUN(out, dayTime, lat, dayCount) {
    const H = (dayTime - 0.5) * 2 * Math.PI;
    const decl = AXIAL_TILT_DEG === 0 ? 0 : (AXIAL_TILT_DEG * Math.PI / 180) * Math.sin(2 * Math.PI * (dayCount + dayTime) / YEAR_DAYS);
    const sd = Math.sin(decl), cd = Math.cos(decl), sl = Math.sin(lat), cl = Math.cos(lat), cH = Math.cos(H);
    out[0] = -cd * Math.sin(H);
    out[1] = sl * sd + cl * cd * cH;
    out[2] = cl * sd - sl * cd * cH;
    return out[1];
}


// =====================================================================================
// CUBE-SPHERE CHARTS
// geo frame: +Y = spin axis (north), dir = (cos(lat) sin(lon), sin(lat), cos(lat) cos(lon)).
// =====================================================================================
export const CHART_HALF = PLANET_R * Math.PI / 4;      // half the width of a face chart (a face spans 90 degrees)
export const FACE_COUNT = 6;

function _cross(a, b) { return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]; }
function _neg(a) { return [-a[0], -a[1], -a[2]]; }
function _rotAbout(v, k, ang) { // Rodrigues rotation of v about unit axis k
    const c = Math.cos(ang), s = Math.sin(ang), kd = k[0] * v[0] + k[1] * v[1] + k[2] * v[2], kx = _cross(k, v);
    return [v[0] * c + kx[0] * s + k[0] * kd * (1 - c), v[1] * c + kx[1] * s + k[1] * kd * (1 - c), v[2] * c + kx[2] * s + k[2] * kd * (1 - c)];
}
// Each face: n = outward normal (chart centre), e1 = chart +x direction, e2 = chart +z direction; always e1 x n = e2
// (the same handedness as east x up = south), so every chart is a proper right-handed three.js ground plane.
export const FACES = (() => {
    const sl = Math.sin(PLANET_LAT0), cl = Math.cos(PLANET_LAT0);
    const n0 = [0, sl, cl], east = [1, 0, 0], north = [0, cl, -sl];
    const f = [];
    for (let k = 0; k < 4; k++) {                          // the four faces around the "spawn belt"
        const a = k * Math.PI / 2;
        const n = _rotAbout(n0, north, a), e1 = _rotAbout(east, north, a);
        f.push({ n, e1, e2: _cross(e1, n) });
    }
    f.push({ n: north, e1: east, e2: _cross(east, north) });             // the face "above" spawn
    const sn = _neg(north); f.push({ n: sn, e1: east, e2: _cross(east, sn) }); // the face "below" spawn
    return f;
})();

// chart (face, x, z) -> unit direction in the geo frame; valid while |x|,|z| < R*pi/2
export function chartToGeo(face, x, z, out) {
    const F = FACES[face], u = Math.tan(x / PLANET_R), w = Math.tan(z / PLANET_R);
    const dx = F.n[0] + u * F.e1[0] + w * F.e2[0], dy = F.n[1] + u * F.e1[1] + w * F.e2[1], dz = F.n[2] + u * F.e1[2] + w * F.e2[2];
    const il = 1 / Math.sqrt(dx * dx + dy * dy + dz * dz);
    out[0] = dx * il; out[1] = dy * il; out[2] = dz * il; return out;
}
// unit direction -> chart coordinates of `face` (out.x, out.z); returns false if the direction is on the far side of the face
export function geoToChart(face, dx, dy, dz, out) {
    const F = FACES[face], p = dx * F.n[0] + dy * F.n[1] + dz * F.n[2];
    if (p <= 1e-6) return false;
    out.x = PLANET_R * Math.atan((dx * F.e1[0] + dy * F.e1[1] + dz * F.e1[2]) / p);
    out.z = PLANET_R * Math.atan((dx * F.e2[0] + dy * F.e2[1] + dz * F.e2[2]) / p);
    return true;
}
export function faceOfGeo(dx, dy, dz) {
    let best = 0, bd = -2;
    for (let i = 0; i < 6; i++) { const F = FACES[i], d = dx * F.n[0] + dy * F.n[1] + dz * F.n[2]; if (d > bd) { bd = d; best = i; } }
    return best;
}
const _g = [0, 0, 0];
// chart point -> the generator's equirectangular map space (out.x = lon * R in [-C/2, C/2), out.z = (LAT0 - lat) * R)
export function chartToMap(face, x, z, out) {
    chartToGeo(face, x, z, _g);
    out.x = Math.atan2(_g[0], _g[2]) * PLANET_R;
    out.z = (PLANET_LAT0 - Math.asin(_g[1] > 1 ? 1 : (_g[1] < -1 ? -1 : _g[1]))) * PLANET_R;
    return out;
}
export function latOfChart(face, x, z) { chartToGeo(face, x, z, _g); return Math.asin(_g[1] > 1 ? 1 : (_g[1] < -1 ? -1 : _g[1])); }
export function lonOfChart(face, x, z) { chartToGeo(face, x, z, _g); return Math.atan2(_g[0], _g[2]); }
// map (lon/lat) -> chart point on a given face
export function mapToChart(face, xm, zm, out) {
    const lon = xm / PLANET_R, lat = PLANET_LAT0 - zm / PLANET_R, cl = Math.cos(lat);
    return geoToChart(face, cl * Math.sin(lon), Math.sin(lat), cl * Math.cos(lon), out);
}
// lat/lon (radians) -> { face, x, z } (the face that owns that point)
export function chartOfLatLon(lat, lon, out) {
    const cl = Math.cos(lat), dx = cl * Math.sin(lon), dy = Math.sin(lat), dz = cl * Math.cos(lon);
    out.face = faceOfGeo(dx, dy, dz); geoToChart(out.face, dx, dy, dz, out); return out;
}
// Angle psi (radians) of the chart's +x axis measured from true EAST toward true NORTH at (face, x, z).
// At spawn psi = 0 (x = east, -z = north). Used to turn (east, up, north) vectors into chart (x, y, z) vectors.
const _ga = [0, 0, 0], _gb = [0, 0, 0];
export function chartPsi(face, x, z) {
    const e = 40;
    chartToGeo(face, x - e, z, _ga); chartToGeo(face, x + e, z, _gb);
    const tx = _gb[0] - _ga[0], ty = _gb[1] - _ga[1], tz = _gb[2] - _ga[2];
    chartToGeo(face, x, z, _g);
    const sl = _g[1], cl = Math.sqrt(Math.max(1e-12, 1 - sl * sl)), sLon = _g[0] / cl, cLon = _g[2] / cl;
    const Ex = cLon, Ey = 0, Ez = -sLon, Nx = -sl * sLon, Ny = cl, Nz = -sl * cLon;
    return Math.atan2(tx * Nx + ty * Ny + tz * Nz, tx * Ex + ty * Ey + tz * Ez);
}

// If (x, z) has left the face's square, hand over to the neighbouring chart. out = { face, x, z, phi } where phi is the
// rotation about +Y (three.js sense: x' = x cos + z sin, z' = -x sin + z cos) that maps old-chart directions onto new-chart
// directions (always a multiple of 90 degrees). Returns false if no handover is needed.
const _hp = { x: 0, z: 0 }, _hq = { x: 0, z: 0 };
export function resolveChart(face, x, z, out) {
    if (Math.abs(x) <= CHART_HALF && Math.abs(z) <= CHART_HALF) return false;
    chartToGeo(face, x, z, _g);
    const nf = faceOfGeo(_g[0], _g[1], _g[2]);
    if (nf === face) return false;
    geoToChart(nf, _g[0], _g[1], _g[2], _hp);
    chartToGeo(face, x + 25, z, _ga);
    geoToChart(nf, _ga[0], _ga[1], _ga[2], _hq);
    const dx = _hq.x - _hp.x, dz = _hq.z - _hp.z;
    let phi = Math.atan2(-dz, dx);
    phi = Math.round(phi / (Math.PI / 2)) * (Math.PI / 2);
    out.face = nf; out.x = _hp.x; out.z = _hp.z; out.phi = phi; return true;
}
// latitude (radians) beyond which the walkable band ends (the polar caps)
export const POLE_LIMIT_RAD = POLE_LIMIT_DEG * Math.PI / 180;
