// leviathan_hack.js - v112 THE LEVIATHAN, part 1b: the console, the hack, the break, the green lights and the blast door.
//
// What this is: everything in the corridor that CHANGES. leviathan_core.js builds the static interior; this module adds, on top of it,
//   - the service console on the corridor's south wall (a garbled screen, a marker beam, a light),
//   - the two sliding panels of the blast door and the short passage behind it,
//   - the state machine that drives them:   idle -> found -> hacking -> garbled -> breaking -> unlocked -> opening -> open
//   - the break sequence (sparks, blackout, the alarms going silent, every lamp turning green), the door sounds and the camera shake value.
// It owns no game state and no DOM. game.js drives it (reveal / beginHack / garble / breakIt / openDoor), reads markTarget() to draw the
// compass and on-screen marker, and gets 'hack:broken' and 'door:opened' events back through deps.onEvent.
//
// Written without a GPU: no custom shaders here, only plain three.js materials, so there is nothing that can fail to compile.
import * as THREE from 'three';
import { LAYOUT as L, Batch } from './leviathan_core.js';

const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
const lerp = (a, b, t) => a + (b - a) * t;
const ease = (x) => { x = clamp(x, 0, 1); return x * x * (3 - 2 * x); };
function rng(seed) { let a = (seed >>> 0) || 1; return function () { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
const setCol = (o, r, g, b) => { const c = o && o.color; if (c && c.setRGB) c.setRGB(r, g, b); };
const baseCol = (o) => { const c = o && o.color; return (c && c.setRGB && typeof c.r === 'number') ? { r: c.r, g: c.g, b: c.b } : null; };   // the colour a light was created with (linear), so idle looks exactly like v111
const mixCol = (o, base, r, g, b, k) => { if (base && k > 0) setCol(o, lerp(base.r, r, k), lerp(base.g, g, k), lerp(base.b, b, k)); };

// ---------------------------------------------------------------------------------------------------------------------------------
// Layout. The console stands against the corridor's solid (+z) wall, between two sealed side doors, and faces the corridor.
// ---------------------------------------------------------------------------------------------------------------------------------
const WALL_Z = L.cor.z1, MID_Z = (L.cor.z0 + L.cor.z1) / 2;
export const HACK = {
    console: { x: -375, y: 15.5, z: WALL_Z - 8.4 },          // centre of the screen
    stand: { x: -375, z: MID_Z },                            // where the player is placed while hacking (22 units from the screen)
    door: { x: L.doorX + 8, y: 40, z: MID_Z },               // centre of the blast door
    nearConsole: 58, nearDoorX: 48,
    stubLen: 130, doorSlide: 29.5, doorOpenT: 2.8
};
const TIMELINE = { hit: 0.0, dark0: 0.3, dark1: 0.45, lightsBack: 1.6, lightsFull: 1.9, greenStart: 1.6, greenEnd: 3.0, done: 3.4 };

// ---------------------------------------------------------------------------------------------------------------------------------
// Canvas textures for the screen (skipped without a document, i.e. in the node tests)
// ---------------------------------------------------------------------------------------------------------------------------------
function makeTex(w, h, draw) {
    if (typeof document === 'undefined') return null;
    const c = document.createElement('canvas'); c.width = w; c.height = h; draw(c.getContext('2d'), w, h);
    const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4; return t;
}
// Pseudo-script: rows of little glyphs made from random strokes on a 3x4 lattice. Not a language, which is the point.
function drawGlyphs(g, w, h, rgb, seed, frame) {
    const r = rng(seed); g.fillStyle = '#03080a'; g.fillRect(0, 0, w, h);
    const cw = 15, ch = 19, cols = Math.floor((w - 20) / cw); g.lineCap = 'round'; g.lineJoin = 'round';
    for (let row = 0; row * ch < h; row++) {
        const y = row * ch + 4, start = r() < 0.35 ? (r() * 5) | 0 : 0, n = Math.max(4, cols - start - ((r() * 9) | 0));
        if (r() < 0.22) { g.fillStyle = 'rgba(' + rgb + ',0.16)'; g.fillRect(10 + start * cw, y - 2, n * cw, ch - 3); }
        for (let c = 0; c < n; c++) {
            if (r() < 0.14) continue;
            const x = 12 + (start + c) * cw, P = (i, j) => [x + i * 4.6, y + j * 4.1];
            g.strokeStyle = 'rgba(' + rgb + ',' + (0.55 + r() * 0.45).toFixed(2) + ')'; g.lineWidth = 1.6; g.beginPath();
            const segs = 2 + ((r() * 3) | 0); for (let k = 0; k < segs; k++) { const a = P((r() * 3) | 0, (r() * 4) | 0), b = P((r() * 3) | 0, (r() * 4) | 0); g.moveTo(a[0], a[1]); g.lineTo(b[0], b[1]); }
            g.stroke();
        }
    }
    if (frame) { g.strokeStyle = 'rgba(' + frame + ',0.9)'; g.lineWidth = 5; g.strokeRect(3, 3, w - 6, h - 6); }
}
function drawCrack(g, w, h) {
    const r = rng(404); g.fillStyle = '#010203'; g.fillRect(0, 0, w, h);
    const cx = w * 0.46, cy = h * 0.52; g.lineCap = 'round';
    for (let i = 0; i < 17; i++) {
        let a = (i / 17) * 6.283 + r() * 0.3, x = cx, y = cy, len = 40 + r() * 190; g.strokeStyle = 'rgba(190,225,235,' + (0.25 + r() * 0.5).toFixed(2) + ')'; g.lineWidth = 1 + r() * 1.6; g.beginPath(); g.moveTo(x, y);
        for (let s = 0; s < 8 && len > 0; s++) { const st = 14 + r() * 26; a += (r() - 0.5) * 0.7; x += Math.cos(a) * st; y += Math.sin(a) * st; len -= st; g.lineTo(x, y); }
        g.stroke();
    }
    g.fillStyle = 'rgba(80,200,230,0.5)'; for (let i = 0; i < 26; i++) g.fillRect(r() * w, r() * h, 2 + r() * 3, 2 + r() * 9);
    g.fillStyle = 'rgba(255,90,40,0.5)'; for (let i = 0; i < 6; i++) g.fillRect(cx + (r() - 0.5) * 60, cy + (r() - 0.5) * 60, 2, 2 + r() * 6);
}
function drawBeam(g, w, h) {
    const gr = g.createLinearGradient(0, 0, 0, h); gr.addColorStop(0, 'rgba(255,255,255,0)'); gr.addColorStop(0.18, 'rgba(255,255,255,0.55)'); gr.addColorStop(0.7, 'rgba(255,255,255,0.28)'); gr.addColorStop(1, 'rgba(255,255,255,0.7)');
    g.fillStyle = gr; g.fillRect(0, 0, w, h);
    const gx = g.createLinearGradient(0, 0, w, 0); gx.addColorStop(0, 'rgba(0,0,0,1)'); gx.addColorStop(0.5, 'rgba(0,0,0,0)'); gx.addColorStop(1, 'rgba(0,0,0,1)');
    g.globalCompositeOperation = 'destination-out'; g.fillStyle = gx; g.fillRect(0, 0, w, h); g.globalCompositeOperation = 'source-over';
}

// ---------------------------------------------------------------------------------------------------------------------------------
// createHack(lev, deps)   lev = the object createLeviathan() returned (after build()).   deps.onEvent(name): 'hack:broken', 'door:opened'
// ---------------------------------------------------------------------------------------------------------------------------------
export function createHack(lev, deps) {
    deps = deps || {};
    const walk = lev.walk, obst = lev.obst, mats = lev.mats, parts = lev.parts, audio = lev.audio, scene = lev.scene;
    const own = {};            // materials, lights and meshes this module owns
    let built = false, state = 'idle', st = 0, T = 0, green = 0, blackout = 0, shake = 0, stubOpen = 0, doorK = 0, sparkAcc = 0, wasState = '';
    const flags = {};

    function build() {
        if (built) return; built = true;
        own.base = { hemi: baseCol(parts.hemi), corA: baseCol(parts.corA), corB: baseCol(parts.corB) };
        const C = HACK.console, B = new Batch(311), cx = C.x, dx = L.doorX, cor = L.cor, T0 = L.T;

        // ---- the console ----
        B.box(cx - 17, cx + 17, 0, 9, WALL_Z - 14, WALL_Z, mats.ironDark, 24);                      // pedestal
        B.rbox(cx, 9.6, WALL_Z - 11, 33, 2, 12, 0, 0.28, 0, mats.iron, 24);                         // sloped desk
        for (let i = -3; i <= 3; i++) B.rbox(cx + i * 4.2, 11.2, WALL_Z - 11.6, 3, 0.6, 3.6, 0, 0.28, 0, mats.brass, 10);   // keys
        B.box(cx - 15, cx + 15, 9, 23, WALL_Z - 8, WALL_Z, mats.ironDark, 24);                      // screen housing
        for (const [x0, x1, y0, y1] of [[cx - 13.5, cx + 13.5, 9.2, 10.4], [cx - 13.5, cx + 13.5, 20.6, 21.8], [cx - 13.5, cx - 12.3, 9.2, 21.8], [cx + 12.3, cx + 13.5, 9.2, 21.8]]) B.box(x0, x1, y0, y1, WALL_Z - 8.9, WALL_Z - 7.9, mats.brass, 10);   // bezel
        for (const o of [-6, 6]) B.box(cx + o - 1.4, cx + o + 1.4, 23, L.cor.h, WALL_Z - 2.4, WALL_Z, mats.ironDark, 20);   // cable runs up to the ceiling
        B.box(cx - 15, cx + 15, 22.6, 24, WALL_Z - 7, WALL_Z - 1, mats.hazard, 20);
        B.build(scene, 'console');
        obst.push([cx - 17, cx + 17, WALL_Z - 14, WALL_Z]);

        own.texAmber = makeTex(384, 224, (g, w, h) => drawGlyphs(g, w, h, '255,170,80', 71, '255,150,60'));
        own.texCyan = makeTex(384, 224, (g, w, h) => drawGlyphs(g, w, h, '110,235,255', 72, '90,220,255'));
        own.texCrack = makeTex(384, 224, drawCrack);
        own.screenMat = new THREE.MeshBasicMaterial({ map: own.texAmber || null, color: new THREE.Color(0.3, 0.3, 0.3), toneMapped: false, fog: false }); own.screenMat.name = 'hackScreen';
        own.screen = new THREE.Mesh(new THREE.PlaneGeometry(26.4, 11.2), own.screenMat); own.screen.name = 'hackScreen';
        own.screen.position.set(cx, C.y, C.z); own.screen.rotation.y = Math.PI; own.screen.frustumCulled = false; scene.add(own.screen);   // faces -z, toward the corridor

        own.light = new THREE.PointLight(0xffa860, 0, 170, 1); own.light.position.set(cx, 20, WALL_Z - 22); scene.add(own.light);

        // ---- the marker beam: two crossed additive planes (moved to the door once the door is the objective) ----
        own.beamTex = makeTex(32, 128, drawBeam);
        own.beamMat = new THREE.MeshBasicMaterial({ map: own.beamTex || null, color: new THREE.Color(0.3, 0.9, 1.2), transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, toneMapped: false, fog: false }); own.beamMat.name = 'hackBeam';
        own.beam = new THREE.Group(); own.beam.name = 'hackBeam';
        for (let i = 0; i < 2; i++) { const m = new THREE.Mesh(new THREE.PlaneGeometry(9, 62), own.beamMat); m.rotation.y = i * Math.PI / 2; m.frustumCulled = false; own.beam.add(m); }
        own.beam.visible = false; scene.add(own.beam);

        // ---- the blast door: two sliding halves, a red/green seam, then the passage behind it ----
        own.seamMat = new THREE.MeshBasicMaterial({ color: new THREE.Color(2.2, 0.15, 0.08), toneMapped: false, fog: false }); own.seamMat.name = 'doorSeam';
        own.panels = [];
        for (const side of [0, 1]) {
            const g = new THREE.Group(); g.name = 'doorPanel' + side; const P = new Batch(320 + side);
            const z0 = side === 0 ? cor.z0 : MID_Z + 0.8, z1 = side === 0 ? MID_Z - 0.8 : cor.z1, edge = side === 0 ? z1 : z0;
            P.box(dx, dx + 6, 0, 72, z0, z1, mats.iron, 24);
            for (const y of [18, 38, 58]) { P.box(dx + 6, dx + 7.2, y - 1.3, y + 1.3, z0, z1, mats.ironDark, 20); for (const z of [side === 0 ? cor.z0 + 12 : cor.z1 - 12]) P.box(dx + 6, dx + 11, y - 2, y + 2, z - 2, z + 2, mats.brass, 12); }
            P.box(dx + 6, dx + 7.6, 0, 72, edge - (side === 0 ? 3.2 : 0), edge + (side === 0 ? 0 : 3.2), mats.hazard, 24);
            P.build(g, 'door' + side);
            const seam = new THREE.Mesh(new THREE.BoxGeometry(0.9, 64, 0.9), own.seamMat); seam.position.set(dx + 7.6, 36, edge + (side === 0 ? -0.5 : 0.5)); seam.frustumCulled = false; g.add(seam);
            scene.add(g); own.panels.push(g);
        }

        // the passage behind the door (built dark; its lamps come on as the door opens)
        const S = HACK.stubLen, sx0 = dx - S, Q = new Batch(330);
        own.stubLamp = new THREE.MeshBasicMaterial({ color: new THREE.Color(0.02, 0.03, 0.03), toneMapped: false, fog: false }); own.stubLamp.name = 'stubLamp'; own.stubLamp.userData = { noTint: true };
        Q.box(sx0 - T0, dx, -4, 0, cor.z0 - T0, cor.z1 + T0, mats.floor, 40);
        Q.box(sx0 - T0, dx, cor.h, cor.h + 5, cor.z0 - T0, cor.z1 + T0, mats.ironDark, 60);
        Q.box(sx0 - T0, dx, 0, cor.h + 5, cor.z0 - T0, cor.z0, mats.iron, 40); Q.box(sx0 - T0, dx, 0, cor.h + 5, cor.z1, cor.z1 + T0, mats.iron, 40);
        Q.box(sx0 - T0, sx0, 0, cor.h + 5, cor.z0 - T0, cor.z1 + T0, mats.ironDark, 40);            // the far bulkhead
        for (let x = dx - 14; x > sx0 + 6; x -= 28) { Q.box(x - 1.6, x + 1.6, 0, cor.h, cor.z0, cor.z0 + 3, mats.brass, 20); Q.box(x - 1.6, x + 1.6, cor.h - 3, cor.h, cor.z0, cor.z1, mats.brass, 20); Q.box(x - 1.6, x + 1.6, 0, cor.h, cor.z1 - 3, cor.z1, mats.brass, 20); }
        for (let x = dx - 24; x > sx0 + 16; x -= 28) Q.box(x - 5, x + 5, cor.h - 3.2, cor.h - 1.2, MID_Z - 3, MID_Z + 3, own.stubLamp, 8);
        Q.box(sx0, sx0 + 4, 0, 60, cor.z0 + 6, cor.z1 - 6, mats.hazard, 24); Q.box(sx0 + 3.6, sx0 + 4.6, 20, 46, MID_Z - 12, MID_Z + 12, own.stubLamp, 8);
        Q.box(sx0 + 4, sx0 + 8, 0, 4, cor.z0, cor.z1, mats.hazard, 24);
        Q.build(scene, 'stub');
    }

    // ---- screen --------------------------------------------------------------------------------------------------------------------
    let screenMode = '';
    function setScreen(mode) {
        if (!built || mode === screenMode) return; screenMode = mode;
        const m = own.screenMat, map = mode === 'amber' ? own.texAmber : mode === 'cyan' ? own.texCyan : own.texCrack;
        if (map) { m.map = map; m.needsUpdate = true; }
    }
    function brightness() {
        const t = T;
        switch (state) {
            case 'idle': return 0.3 + 0.1 * Math.sin(t * 9) * Math.sin(t * 2.3) + (Math.sin(t * 41) > 0.93 ? 0.25 : 0);
            case 'found': return 0.85 + 0.2 * Math.sin(t * 3.2);
            case 'hacking': return 1.25 + 0.25 * Math.sin(t * 17);
            case 'garbled': return 1.1 + (Math.sin(t * 23) > 0.6 ? 0.5 : 0) + 0.15 * Math.sin(t * 5);
            case 'breaking': return st < 0.12 ? 3.5 : st < 0.7 ? (Math.sin(st * 60) > 0 ? 0.9 : 0.1) : 0.08;
            default: return 0.2 + (Math.sin(T * 13) > 0.97 ? 0.5 : 0);      // dead, with the odd flicker
        }
    }

    // ---- state ---------------------------------------------------------------------------------------------------------------------
    function go(s) { state = s; st = 0; for (const k of Object.keys(flags)) delete flags[k]; }
    function reveal() { if (state !== 'idle') return false; go('found'); setScreen('amber'); audio.tone({ f0: 660, dur: 0.25, gain: 0.16 }); audio.tone({ f0: 990, dur: 0.35, gain: 0.14, at: 0.16 }); audio.tone({ f0: 1320, dur: 0.5, gain: 0.1, at: 0.34 }); return true; }
    function beginHack() { if (state !== 'found') return false; go('hacking'); setScreen('cyan'); audio.tone({ f0: 220, f1: 880, dur: 1.4, gain: 0.1, type: 'sawtooth' }); return true; }
    function garble() { if (state !== 'hacking') return false; go('garbled'); audio.tone({ f0: 300, f1: 90, dur: 0.6, gain: 0.12, type: 'square' }); return true; }
    function breakIt() { if (state !== 'garbled' && state !== 'hacking') return false; go('breaking'); return true; }
    function openDoor() { if (state !== 'unlocked') return false; go('opening'); return true; }
    // resume / debug: jump straight to a state with everything already in place
    function setState(s, instant) {
        if (!built) return;
        if (s === 'idle') { go('idle'); green = 0; blackout = 0; doorK = 0; stubOpen = 0; setScreen('amber'); removeStubWalk(); applyDoor(); return; }   // (the alarm level is the core's: begin() / startLanding() set it)
        if (s === 'found') { go('found'); setScreen('amber'); return; }
        if (s === 'unlocked' || s === 'open') {
            go(s === 'open' ? 'open' : 'unlocked'); green = 1; blackout = 0; setScreen('crack'); lev.setAlarm(0); lev.setAmbient(0.12);
            doorK = s === 'open' ? 1 : 0; stubOpen = doorK; applyDoor(); if (s === 'open') ensureStubWalk();
        }
    }
    function ensureStubWalk() { if (own.walkRect) return; own.walkRect = { x0: L.doorX - HACK.stubLen, x1: L.doorX + 16, z0: L.cor.z0, z1: L.cor.z1 }; walk.push(own.walkRect); }
    function removeStubWalk() { if (!own.walkRect) return; const i = walk.indexOf(own.walkRect); if (i >= 0) walk.splice(i, 1); own.walkRect = null; }
    function applyDoor() {
        if (!built) return; const k = ease(doorK), slide = HACK.doorSlide * k;
        own.panels[0].position.z = -slide; own.panels[1].position.z = slide;
        parts.corB.position.set(lerp(-400, -510, k), 60, MID_Z);
    }

    // ---- what the player can do right now -----------------------------------------------------------------------------------------
    function interaction(px, pz) {
        if (!built) return null;
        const nearCon = Math.hypot(px - HACK.console.x, pz - WALL_Z) < HACK.nearConsole && pz > L.cor.z0 && pz < L.cor.z1;
        const nearDoor = px < L.doorX + HACK.nearDoorX && pz > L.cor.z0 && pz < L.cor.z1;
        if (state === 'found' && nearCon) return { label: 'Hack the console', btn: 'Hack', id: 'hack' };
        if (state === 'garbled' && nearCon) return { label: 'Break the console', btn: 'Break', id: 'break' };
        if (state === 'unlocked' && nearDoor) return { label: 'Open the blast door', btn: 'Open', id: 'door' };
        if ((state === 'idle' || state === 'found' || state === 'hacking' || state === 'garbled') && nearDoor) return { label: 'Try the blast door', btn: 'Try', id: 'door-sealed' };
        return null;
    }
    // The objective to mark on the compass and on screen, or null.
    function markTarget() {
        if (!built) return null;
        if (state === 'found' || state === 'hacking' || state === 'garbled') return { kind: 'console', label: 'CONSOLE', x: HACK.console.x, y: HACK.console.y + 4, z: HACK.console.z, color: '#7fe8ff' };
        if (state === 'unlocked') return { kind: 'door', label: 'DOOR', x: HACK.door.x, y: HACK.door.y, z: HACK.door.z, color: '#6dffa6' };
        return null;
    }

    // ---- per frame (call after lev.update) ---------------------------------------------------------------------------------------
    function sparkBurst(n, power) {
        const C = HACK.console;
        for (let i = 0; i < n; i++) lev.emitSpark(C.x + (Math.random() - 0.5) * 20, C.y + (Math.random() - 0.5) * 8, C.z - 2, (Math.random() - 0.5) * 40 * power, (Math.random() - 0.2) * 34 * power, -8 - Math.random() * 40 * power, 0.5 + Math.random() * 0.9);
    }
    function update(dt) {
        if (!built) return;
        dt = Math.min(dt, 0.1); T += dt; st += dt; shake = Math.max(0, shake - dt * 2.4);

        // the break timeline
        if (state === 'breaking') {
            const t = st, TL = TIMELINE;
            if (!flags.hit) { flags.hit = 1; shake = 2.4; setScreen('crack'); sparkBurst(46, 1); lev.screenFlash(0.5, '#cfeeff'); audio.thump({ f0: 170, f1: 36, dur: 0.55, gain: 0.9 }); audio.burst({ dur: 0.45, gain: 0.7, lo: 600, hi: 9000 }); audio.burst({ dur: 0.8, gain: 0.3, lo: 3000, hi: 10000, at: 0.08 }); }
            if (t > 0.35 && !flags.sp2) { flags.sp2 = 1; sparkBurst(22, 0.6); }
            if (t > TL.dark0 && !flags.dark) { flags.dark = 1; lev.setAlarm(0); lev.setAmbient(0.03); shake = Math.max(shake, 1.2); audio.thump({ f0: 90, f1: 24, dur: 1.2, gain: 0.7 }); audio.tone({ f0: 520, f1: 38, dur: 1.1, gain: 0.12, type: 'sawtooth' }); }
            if (t > TL.lightsBack && !flags.up) { flags.up = 1; lev.setAmbient(0.12); audio.tone({ f0: 55, f1: 110, dur: 1.8, gain: 0.22 }); audio.tone({ f0: 330, dur: 0.6, gain: 0.16, at: 0.1 }); audio.tone({ f0: 495, dur: 0.6, gain: 0.16, at: 0.3 }); audio.tone({ f0: 660, dur: 0.9, gain: 0.16, at: 0.5 }); lev.screenFlash(0.25, '#9dffc2'); }
            blackout = t < TL.dark0 ? 0 : t < TL.dark1 ? ease((t - TL.dark0) / (TL.dark1 - TL.dark0)) : t < TL.lightsBack ? 1 : t < TL.lightsFull ? 1 - ease((t - TL.lightsBack) / (TL.lightsFull - TL.lightsBack)) : 0;
            green = t < TL.greenStart ? 0 : ease((t - TL.greenStart) / (TL.greenEnd - TL.greenStart));
            if (t >= TL.done) { go('unlocked'); green = 1; blackout = 0; if (deps.onEvent) deps.onEvent('hack:broken'); }
        } else if (state === 'unlocked' || state === 'opening' || state === 'open') {
            green = 1;
            if (state !== 'open' && Math.random() < dt * 1.2) sparkBurst(2, 0.35);   // the dead console sputters
        }

        // the door
        if (state === 'opening') {
            if (!flags.snd) { flags.snd = 1; audio.thump({ f0: 80, f1: 30, dur: 0.6, gain: 0.7 }); audio.creak({ f: 85, dur: 2.6, gain: 0.2 }); audio.burst({ dur: 2.4, gain: 0.16, lo: 120, hi: 1400, at: 0.1 }); audio.tone({ f0: 70, f1: 46, dur: 2.6, gain: 0.12, type: 'triangle' }); shake = Math.max(shake, 0.5); }
            doorK = clamp(st / HACK.doorOpenT, 0, 1); stubOpen = ease(doorK); shake = Math.max(shake, 0.35 * Math.sin(doorK * Math.PI));
            if (Math.random() < dt * 10) lev.emitSpark(L.doorX + 8, 70, MID_Z + (Math.random() - 0.5) * 50, (Math.random() - 0.5) * 6, -4, (Math.random() - 0.5) * 8, 0.8);
            applyDoor();
            if (doorK >= 0.35) ensureStubWalk();
            if (doorK >= 1) { go('open'); audio.thump({ f0: 70, f1: 26, dur: 0.7, gain: 0.8 }); shake = Math.max(shake, 0.9); if (deps.onEvent) deps.onEvent('door:opened'); }
        }

        // screen, light, beam
        const b = brightness(); setCol(own.screenMat, b, b, b);
        const sp = state === 'found' ? 0.06 : state === 'hacking' ? 0.7 : state === 'garbled' ? 1.1 : state === 'idle' ? 0.02 : 0;
        for (const tx of [own.texAmber, own.texCyan]) if (tx && sp) tx.offset.y = (tx.offset.y + sp * dt) % 1;
        const lt = own.light;
        if (state === 'idle') { lt.intensity = 16 + 8 * Math.sin(T * 7) * Math.sin(T * 2.7); setCol(lt, 1.0, 0.65, 0.35); }
        else if (state === 'found') { lt.intensity = 55 + 25 * Math.sin(T * 3.2); setCol(lt, 0.4, 0.9, 1.0); }
        else if (state === 'hacking' || state === 'garbled') { lt.intensity = 85 + 30 * Math.sin(T * 17); setCol(lt, 0.4, 0.9, 1.0); }
        else if (state === 'breaking') { lt.intensity = Math.max(0, 200 * Math.exp(-st * 5)); setCol(lt, 1.0, 0.5, 0.3); }
        else lt.intensity = 0;
        // beam: at the console while it is the objective, at the door once that is
        const bt = markTarget(), pulse = 0.55 + 0.45 * Math.sin(T * 3);
        if (bt) {
            const toDoor = bt.kind === 'door';
            own.beam.visible = true; own.beam.position.set(toDoor ? L.doorX + 16 : HACK.console.x, toDoor ? 42 : 55, toDoor ? MID_Z : WALL_Z - 9);
            own.beam.scale.set(toDoor ? 1.6 : 1, toDoor ? 1.3 : 1, toDoor ? 1.6 : 1);
            setCol(own.beamMat, toDoor ? 0.25 : 0.3, toDoor ? 1.3 : 0.9, toDoor ? 0.6 : 1.2); own.beamMat.opacity = (toDoor ? 0.4 : 0.5) * (0.6 + 0.4 * pulse) * (state === 'hacking' ? 0.4 : 1);
        } else own.beam.visible = false;

        applyPower();
        stubLampLevel();
    }

    // The power state: alarms, lamps and lights. Runs AFTER lev.update every frame, because the core rewrites its own flicker each frame.
    function applyPower() {
        const g = ease(green), k = blackout, dim = 1 - 0.95 * k;
        // lamps (the corridor and the bay share these materials)
        setCol(mats.lampOn, lerp(1.6, 0.45, g) * dim, lerp(1.0, 1.7, g) * dim, lerp(0.55, 0.8, g) * dim);
        { const c = mats.lampFlick.color; if (c) setCol(mats.lampFlick, lerp(c.r, 0.45, g) * dim, lerp(c.g, 1.7, g) * dim, lerp(c.b, 0.8, g) * dim); }
        { const c = mats.redPulse.color, p = 0.5 + 0.5 * Math.sin(T * 3.4); if (c) setCol(mats.redPulse, lerp(c.r, 0.1, g) * dim, lerp(c.g, 0.8 + 0.6 * p, g) * dim, lerp(c.b, 0.35, g) * dim); }
        // lights
        mixCol(parts.corA, own.base.corA, 0.12, 1.0, 0.36, g); mixCol(parts.corB, own.base.corB, 0.12, 1.0, 0.36, g);
        parts.corA.intensity *= (1 - 0.93 * k); parts.corB.intensity *= (1 - 0.93 * k);
        if (g > 0) parts.corB.intensity = lerp(parts.corB.intensity, parts.corA.intensity, g);   // steady, no flicker once the power is stable
        parts.alarmA.intensity *= (1 - k); parts.alarmB.intensity *= (1 - k);
        parts.hemi.intensity *= (1 - 0.6 * k); mixCol(parts.hemi, own.base.hemi, 0.14, 0.6, 0.32, g);
        // the door seam: red while it is sealed, green once it is not
        const p = 0.5 + 0.5 * Math.sin(T * (g > 0.5 ? 2.2 : 3.4));
        setCol(own.seamMat, lerp(0.4 + 1.9 * p, 0.1, g) * dim, lerp(0.05, 0.9 + 0.7 * p, g) * dim, lerp(0.03, 0.35, g) * dim);
    }
    function stubLampLevel() { const s = stubOpen; setCol(own.stubLamp, 0.02 + 0.45 * s, 0.03 + 1.7 * s, 0.03 + 0.8 * s); }

    return {
        build, update, interaction, markTarget, reveal, beginHack, garble, breakIt, openDoor, setState,
        get state() { return state; }, get shake() { return shake; }, get built() { return built; },
        get doorProgress() { return doorK; }, get green() { return green; }, get blackout() { return blackout; },
        consolePos: HACK.console, doorPos: HACK.door, stand: HACK.stand, parts: own
    };
}
