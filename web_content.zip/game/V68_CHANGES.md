# v68 - the Vale phase (story step 1 of 6)
Not run in a browser; `game.js` passes a syntax check and every identifier the new code uses exists. Please playtest the Vale beat first.

## What changed
- **Note on the hatch.** After the player owns the disc and walks back to the shelter (within 16 units), the AI finds a folded note pinned to the hatch. The note is shown on screen, the AI reacts ("cautiously optimistic"), a holo path plus a tall light column appear pointing at the story city, and a log entry is added.
- **Story city.** The Vale city nearest the shelter on the current face (never the Rogues' Citadel). Saved as `valeSiteIdx`, so reloads keep it. If there is no Vale city on the face, the game falls back to the old swarm-at-the-shelter-door.
- **Arrival scene** (walk inside about 0.8 of the valley floor radius): the AI's blue-optics line, the Vale explain who they are (Empire, the mutation, no free will, the human theory), the three names (Iolhweapl B Minor A, Giant Minor One, NewTerra) and the nature reserve, a trade beat (stand-in: full LMT recharge), the starship reveal (a simple placeholder mesh), the Leviathan briefing, "someone needs to fly it", and the AI's beach line.
- **The swarm now hits the city.** Alarm, red broadcast overlay, the AI's translation ("this city is paying for it"), the leader's "We cannot ask you to fight alone. Take them.", then the existing swarm spawns with 5 allied blue Vale drones that chip at the escort (never the transport) and drop out one by one.
- **Aftermath** (transport down): "The landing pad is open. Go. We will handle the rest." then the existing Punch it / freefall beat; the freefall card now says starship. The ship and allies are removed.
- New speaker support in `speakLine` (`{speaker:'VALE LEADER'}`): own caption colour, no AI orb. New `#valeNote` element and `#aiCaption.vale` style.
- Save: `valeStage`, `valeSiteIdx`. A reload mid-fight returns the player to stage 1 (the arrival check re-spawns the swarm).

## Not done yet (next steps in order)
2. Storm rewrite (dive to the vents, anchored boat, "your survival takes absolute priority") and discovery order.
3. Tribunal decree + the AI's confession, tied into the diary pages / photo / locket (Ren thread).
4. Text fixes (centuries -> millennia / about two centuries) and the missing disc audio file.
5. Early plants for the ending. 6. Post-swarm handoff.
Trade is only a recharge for now; a real upgrade shop is not built. The starship and the "weathered Aurelian settlement" at the city centre are not modelled yet.
