# v66 - an ordinary city fills the ground around (and under) the Rogues' Citadel
Not run in a browser. Headless: test_citadel, _site, _walk, _chunks, _runtime, test_chunks, test_v59, test_sites pass on seeds 424242 / 1 / 5 / 99 (seed 7 leaves one lone street node unlinked; harmless).
- **Ground streets** (citadel_core.js): rings and radials continue outward from the Roots' last ring to the edge of the meadow (`citEdge` = 90% of the measured outline `rvT`). Radials are re-spaced band by band so blocks stay ~270 wide. Streets keep out of the promenade/tunnel corridor, steep ground and the ground footprint of ramps.
- **Ordinary blocks** on every ground street (the Roots' own as well as the new ones), then block interiors: the same stepped wall boxes, gables, flat roofs with clutter, neon, AC boxes and storefront glow as the other cities, in one of their palettes (picked by seed). Under a deck they are capped to the clearance; outside the decks they climb to towers (14-28 floors, ~7% of lots beyond r 1750). They thin out toward the meadow edge. Cap `MAXG` = 6500 lots (about 2800-3600 per world).
- The citadel itself is untouched: pylons, Roots lots, trees and lawns now avoid the new streets/blocks; the enchanted groves, crystals and lanterns start where the city ends.
- **Terrain scatter** (valley_sites.js): `clearP` / `clearHere` / `clearRadius` follow the ground city's edge per direction instead of a 1850 circle, so the forest no longer grows through the streets; the wild creeps back over 260 units past the edge.
- Stray-street linking now works on the ground level beyond the Roots (height tolerance 140, reach 520).
- Speed: citadel generation ~1.2 s -> ~2-3.5 s (worker, once per world). Pieces ~50k -> ~71-79k. `nearestNode` checks distance before its costly filter; `Grid.near` reuses one Set.
- `city_core.js`: `PALETTES` is now exported.
- Knobs: `MAXG`, lot sizes in the frontage loop, `makeG` (floors / tower chance), `cityEdge` factor 0.9 in `citEdge`.

## v66b - the city reaches the very edge of the valley
- `citEdge` is now the full measured meadow outline (was 90%); streets/lots may climb slopes up to ~0.45 grade (lots tolerate 12 + 0.5 x footprint of fall), and thinning only starts at 94% of the edge. Where the valley wall is a sheer cliff (it starts at r ~1900 on some sides) the city simply runs up to the foot of it.
- Rings run to the edge (8 on seed 424242), `MAXG` 9500 (about 3400-4000 lots per world). The corridor around the promenade is narrower. Waterfall feet and groves now start beyond the city edge.
- Terrain scatter clearing follows the same edge.

## v66c - the sun no longer swings when you walk near a pole (game.js, spin clock)
Cause: in the spin-clock bookkeeping (search "SPHERE: hard limits + local solar time") any frame where the longitude changed by >= 0.0005 turn was treated as a teleport and `skyUT -= dl` was applied, to keep local time. Near a pole one step changes longitude hugely (R ~ 2.37M units: a 5-unit step within ~1.6 km of the pole qualifies), so every step dragged skyUT - which the sun, moon, gas giant and stars are read from - round the sky against your walking direction. Now that compensation (and the held-clock one) is scaled by `poleK = 1 - smoothstep(1.05, 1.35, |lat|)`, so within ~15 degrees of a pole the sun stays fixed in space and only the real, tiny horizon tilt (distance / planet radius) remains.
Side note, not changed: `dayTime` (the local clock used by isNightTime etc.) still follows longitude, so it flips by half a day if you cross the exact pole.
