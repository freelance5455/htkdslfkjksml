# v85 - step 5: the last plants for the ending
`game.js` passes a syntax check; the locket JSON parses. Not run in a browser.

- **The Rift (gas-giant plant).** Before the Vale phase, the first time the player keeps the gas giant in clear view for about 3 seconds (above the horizon, looking at its disc, in a quiet moment: after the first night, daylight, no fight or cutscene, on foot), the AI points out a dark rift in its storm bands just below the equator that has not moved since they woke: "Weather does not hold still like that. Something is feeding that storm, or keeping it in place." It uses `speakLine` directly (the game never pauses), plays once, adds the log entry "A Storm That Holds Still", and is saved as `giantGlanceDone`. If the Vale phase starts first, the plant is skipped. This sets up the Leviathan in the storm and the cinematic's Rift.
- **The locket (payoff hook).** The locket's description and the AI's pickup line now say there is a sensor plate under the corrosion, worn smooth, made to answer one pulse, which the AI thinks is the player's. It chooses not to force it yet. This gives a later phase a way to open it when the player's heart rate is right, and echoes the photo line where the AI notices the player's pulse spiking.

## Plants now in place
Survival directive: boot sequence (v84), storm dive (v69), cinematic card (v76). AI core in the suit: boot sequence (v84). Dense moon: tremor (v71). Leviathan's storm: the Rift (v85). Locket mechanism: v85.

## Still open
A real Phase 6 handoff (the player is placed back at the shelter after the fall until then).
