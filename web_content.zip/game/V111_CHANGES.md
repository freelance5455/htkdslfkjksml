# v111 - THE LEVIATHAN, part 1: landing and the flight-deck bay (on top of v110)

Replaces the "put the player back at the shelter" stand-in at the end of the freefall. After the last black the player now crashes into the Leviathan.

## New file
- `leviathan_core.js` - the whole interior, in its own THREE.Scene (game.js swaps it into the composer's RenderPass while you are inside; terrain, sea, sky and weather are not updated or drawn). Contains: the flight-deck bay (300 x 520 units, 190 high; tall storm windows along the east wall, the torn forcefield breach, the buckled north bulkhead, scorched runway, stripped hulls and crates, dead drones, salvaged plates with the A.S.S. mark and Aurelian script), the wreck of the Vale starship with a kickable hatch, the first corridor (270 long, windows on the south side) ending in a sealed blast door, a storm backdrop shader with lightning, sparks/dust/fire particles, alarm and fire lights, synthesised audio (ambient bed, alarm, scrape, thunder, impacts), the scripted landing, collision, and zone triggers. About 32 draw calls.

## game.js (small hooks only)
- `whileBlack` of the freefall now enters the interior (`tryEnterLeviathan`) instead of teleporting to the shelter.
- The landing: fly in through the breach, forcefield flash, skid down the runway, halt against the bulkhead, AI line, "Kick the hatch open" (E / Kick button), step out, chapter card "THE LEVIATHAN", log entry.
- On foot: flat floor, own collision, soft bob, stone footsteps. The "I don't recognize this readout" lines fire in the bay, at the windows, at the stripped hulls and in the corridor. Reaching the corridor saves a checkpoint.
- Save: `leviathanStage` (0 none, 1 landing, 2 bay, 3 corridor, 9 v111 finished). A reload resumes at the checkpoint; while inside, the saved position is the shelter.
- Fallbacks: if the interior fails to build, or throws on any frame, the player is put back at the shelter with the old line, and the error is logged as `[leviathan] ...`.
- At the blast door (end of the corridor) v111 ends: AI line, a "To be continued" card, then back to the shelter with stage 9. Cutting the door is v112.

## Debug (console)
`leviathanDebug.enter()` (full landing), `.enterBay()` (skip the landing), `.leave()`, `.setLight(k)` (scale the ambient/storm light). Light levels live in the `LIGHT` table at the top of `leviathan_core.js`.

## Tests run here
`node tests/test_v111_leviathan.mjs` (stub three.js): geometry integrity, bounded lights and draw calls, hatch -> door -> breach -> windows all reachable, ship/jambs solid, the whole landing simulated start to finish with no NaN, correct stop point and hand-over, zones fire once. `tests/test_v91_phase2.mjs` still passes.

## NOT verified (no GPU here)
How anything looks or sounds: light intensities, the storm shader (if it fails you get a flat storm colour and `[leviathan] shader "storm" failed` in the console), cockpit framing, sparks, audio levels, and whether the interior holds frame rate on phones.

## Debug menu fix
- Chapter jumps failed silently (their messages sit at the bottom of a long panel). Every refusal or error now also shows as a toast and scrolls the status line into view; a missing save or being inside the Leviathan are now reported instead of ignored.
- New buttons: "6 Leviathan: Landing" and "7 Leviathan: Bay" (a DEBUG save that resumes inside the Leviathan).

## Performance probe (for the "very slow from the start" report)
- `[perf]` lines in the console every 5 s for the first minute (or call `perfReport()`): frame ms, CPU ms before the draw (`logicMs`), CPU ms issuing the draw (`submitMs`), draw calls, triangles, shader programs, pixel ratio, shore-map ms.
- The ocean shore map (the only per-frame cost v110 added to the main loop) now has a time budget: a slow row makes it rest for a few frames.
- Nothing from v111 runs outside the Leviathan: the interior is only built when you enter it.

## Debug jump + terrain diagnostics
- The chapter jumps used the old `isLandAt()` (a separate noise formula that no longer matches the real terrain), so they could refuse while you stood on dry land. They now test the real terrain height (and say the height and water level if they still refuse); the "boat at shore" jump finds its shore the same way.
- `perfReport()` / `[perf]` now also shows terrain-worker count, whether the main-thread fallback is active, worker errors and the chunk/apply/scatter queue lengths. Add `?perf` to the page URL for a live on-screen readout.

## Debug jump: stuck photosensitivity screen
- A chapter jump reloads the page straight into the generated save, which skipped `showEpilepsyScreen()`. The warning is visible by default and only that function wires its Continue button, so it stayed on top with a dead button while the game loaded behind it. The jump path now hides it. (The reload also drops fullscreen; browsers only allow re-entering it from a click, so use the fullscreen button afterwards.)
