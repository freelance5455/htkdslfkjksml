# v73 - the Freefall cinematic
Rendered and checked headless (SwiftShader) frame by frame, plus an end-to-end play/skip test. Not yet seen on a real phone GPU.

## What changed
The placeholder "Freefall" card after the Phase 5 launch is replaced by a silent, three-shot cinematic with black between:
1. **Rear window.** Low over a procedural world with a pink horizon and thin atmosphere; the sky goes black; the moon falls away with continents, shallows, clouds, a lit limb, a dim night side with a few cool blue city lights, and stars. The ship slowly tumbles.
2. **Cracked canopy.** The gas giant, suddenly close, with the Rift storm swirling and violet lightning. The canopy strut sits in frame.
3. **The plunge.** Right above the Rift, the planet fills the view; the sky burns orange, heat flares at the edges, a red alarm glow pulses, then dark billowing storm clouds with lightning bolts, a white-out, and black.
- Audio is the shuttle only: an engine drone, hull rumble and creaks, rattling panels, alarm beeps, wind roar, thunder. Game music and SFX are muted during it and restored after.
- The screen "turns on" at the start of each shot (a bright line opening with a flicker).
- After the last black the player is still put back at the shelter (a stand-in until Phase 6).
- Falls back to the old card if WebGL2 is unavailable. Escape, Space, or a double-tap skips it. In the console: `playFreefallCinematic()` previews it.

## Files
- New `freefall_cinematic.js` (self-contained: its own overlay, WebGL2 canvas and audio). `game.js` changes: import, one instance beside the SFX engine, the swap in `runPhase4Aftermath`, and skipping the world render while it plays.
- `tests/ff_cine_shots.py` renders any moment to a PNG; `tests/ff_cine_play_test.py` runs the full play/skip path.

## Knobs
Timeline constants at the top of `freefall_cinematic.js` (shot lengths, lightning times). The moon's start position is `MOON_DIR`.

## Revision (slower, bigger scale)
The first cut crossed too much distance too fast, so the worlds felt small. Retimed to about 79 s: shot 1 is a ~30 s gradual climb (rough and loud with a second cloud layer streaking by for parallax, then the air thins, the sky goes black, the moon shrinks slowly, and ship debris drifts past in near-silence); shot 2 (~15 s) shows the small crescent moon far behind and a giant that barely grows; shot 3 (~25 s) is a long, slow descent, with the heat, orange sky and storm building gradually and the lightning starting distant. The black cuts carry the passage of time. Audio cues retimed to match (rattle and roar die away in space).
The MP4 was NOT re-rendered for this revision (about 45 min of rendering); the frame/audio scripts in `tests/` do it.

## Known / next
- Total length is about 79 s, skippable. Slow devices lower the render resolution automatically.
- The audio is synthesized and I could not listen to it: check levels on a real device.
- The next part (arriving at the Leviathan) is not built; it should start from the final black.
