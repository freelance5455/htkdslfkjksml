import { FORMATIONS, PLAYERS, PLAYERS_BY_ID, effectivePlayer } from '../data/players.js';
// Outcomes are resolved only for shots that actually cross the goal mouth.
// Calibrated to 40% goal / 30% parry / 30% catch at 22.35 m/s, 9.14 m, GK 90.
export function shotOutcomeOdds(keeper, distanceMeters, speedMetersPerSecond, shooting = 75, power = 0.75) {
    const skill = bounds((shooting - 40) / 59, 0, 1);
    const close = bounds((17 - distanceMeters) / 14, 0, 1);
    const pace = bounds((speedMetersPerSecond - 20) / 33, 0, 1);
    const force = bounds(power, 0, 1);
    // Elite finishers at point-blank range with a fully charged shot should score almost always.
    const base = .12 + skill * .24 + close * .30 + pace * .10 + force * .13 - (keeper - 70) * .003;
    const eliteBonus = skill * .11 * close * force;
    const goal = bounds(base + eliteBonus, .045, .985);
    const parry = (1 - goal) * .75;
    return { goal, parry, catch: 1 - goal - parry };
}
const FIELD_X = 52.5, FIELD_Z = 34, GOAL_Z = 3.66;
const bounds = (v, a, b) => Math.max(a, Math.min(b, v));
const len = (x, z) => Math.hypot(x, z) || 1;
const distance = (a, b) => Math.hypot(a.x - b.x, a.z - b.z);
export const BASE_FORMATION = { GK: [-48, 0], LB: [-33, -25], CB: [-37, -10], RB: [-33, 25], CDM: [-19, 0], CM: [-16, 12], CAM: [-9, 0], LM: [-15, -28], RM: [-15, 28], LW: [-7, -26], RW: [-7, 26], ST: [-6, 0] };
function formationCoords(roles) {
    const count = {};
    return roles.map((role, i) => {
        count[role] = (count[role] || 0) + 1;
        if (role === 'CB')
            return [-38, count[role] === 1 ? -11 : count[role] === 2 ? 11 : 0];
        if (role === 'CM')
            return [-18, count[role] === 1 ? -15 : count[role] === 2 ? 15 : 0];
        if (role === 'CDM')
            return [-23, count[role] === 1 ? -9 : 9];
        if (role === 'CAM')
            return [-9, count[role] === 1 ? 0 : count[role] === 2 ? -12 : 12];
        if (role === 'ST')
            return [-7, count[role] === 1 ? -7 : 7];
        if (role === 'LM')
            return [-15, -26];
        if (role === 'RM')
            return [-15, 26];
        return BASE_FORMATION[role] || [-16, (i - 5) * 5];
    });
}
function makeTeam(ids, side, formation, training) { const coords = formationCoords(FORMATIONS[formation] || FORMATIONS['4-3-3']); return ids.map((id, i) => { const c = coords[i], card = side === 0 ? effectivePlayer(PLAYERS_BY_ID.get(id), training[id] || 0) : PLAYERS_BY_ID.get(id); return { id, card, side, slot: i, x: c[0] * (side === 0 ? 1 : -1), z: c[1] * (side === 0 ? 1 : -1), vx: 0, vz: 0, face: side === 0 ? 0 : Math.PI, stamina: 100, skillUntil: 0, cooldown: 0, aiTimer: 0.6 + i * .14, anim: 0 }; }); }
export class MatchEngine {
    people;
    ball = null;
    ballPos = [0, .23, 0];
    ballVelocity = [0, 0, 0];
    phase = 'kickoff';
    pausedFrom = 'playing';
    half = 1;
    clock = 0;
    score = [0, 0];
    selected = 9;
    joystick = { x: 0, z: 0 };
    keeperHold = 0;
    holder = 9;
    releaseGuard = 0;
    possessionSince = 0;
    lastKicker = -1;
    lastKickType = 'pass';
    intendedReceiver = -1;
    pendingOffside = null;
    passTarget = null;
    shotDownAt = 0;
    lastTouch = 0;
    lastTouchSlot = 9;
    charge = 0;
    aiming = { x: 52, z: 0 };
    held = new Set();
    manualShot = false;
    lastShot = null;
    setPieceAim = null;
    setPiecePower = .82;
    setPieceChargeStart = 0;
    setPieceCharging = false;
    parryPending = null;
    notice = 'KICKOFF';
    noticeUntil = 1.5;
    goalTimer = 0;
    resumeTimer = 0;
    restartTimer = 0;
    restartPlaced = false;
    restartName = '';
    restartSide = 0;
    restartX = 0;
    restartZ = 0;
    lastScorer = '';
    goalScorers = [];
    playerActions = Array.from({ length: 22 }, () => ({ goals: 0, shots: 0, passes: 0, tackles: 0 }));
    statShots = [0, 0];
    statPasses = [0, 0];
    statSaves = [0, 0];
    statTackles = [0, 0];
    possessions = [1, 1];
    frames = [];
    frameClock = 0;
    replayFrames = [];
    replayProgress = 0;
    elapsed = 0;
    aiLevel = 0;
    settings;
    tactic;
    formation;
    onView = null;
    onWhistle = null;
    uiClock = 0;
    constructor(squad, training, formation, rank, settings, tactic, chemistry = 72, captain = -1) {
        this.aiLevel = Math.min(18, Math.max(0, rank));
        this.settings = settings;
        this.tactic = tactic;
        this.formation = formation;
        // Opponent rating is calibrated by division. Diamond 3 = rank 14, Champion = 18.
        const targetOverall = (r) => r <= 14 ? Math.round(48 + r * (40 / 14)) : Math.round(88 + (r - 14) * (11 / 4));
        const wanted = targetOverall(this.aiLevel);
        const roles = FORMATIONS[formation] || FORMATIONS['4-3-3'];
        const opponent = roles.map((role, index) => {
            const options = PLAYERS.filter(p => (p.position === role || (role === 'RM' && p.position === 'RW') || (role === 'LM' && p.position === 'LW')) && !squad.includes(p.id)).sort((a, b) => Math.abs(a.overall - (wanted + (index % 3 - 1) * 4)) - Math.abs(b.overall - (wanted + (index % 3 - 1) * 4)));
            return options[0].id;
        });
        // A local unique-id list avoids duplicate opponents.
        const seen = new Set();
        opponent.forEach((id, i) => { if (seen.has(id)) {
            const alt = PLAYERS.filter(p => (p.position === roles[i] || (roles[i] === 'RM' && p.position === 'RW') || (roles[i] === 'LM' && p.position === 'LW')) && !seen.has(p.id)).sort((a, b) => Math.abs(a.overall - wanted) - Math.abs(b.overall - wanted))[0];
            opponent[i] = alt.id;
        } seen.add(opponent[i]); });
        const home = makeTeam(squad, 0, formation, training);
        const boost = Math.round((chemistry - 65) / 13);
        home.forEach((p, i) => { const rightRole = roles[i] === p.card.position; const fit = rightRole ? 0 : -4; const captainBonus = p.id === captain ? 2 : 0; const bump = (n) => bounds(n + boost + fit + captainBonus, 25, 99); p.card = { ...p.card, passing: bump(p.card.passing), dribbling: bump(p.card.dribbling), defending: bump(p.card.defending), physical: bump(p.card.physical), stamina: bump(p.card.stamina) }; });
        this.people = [...home, ...makeTeam(opponent, 1, formation, {})];
        // Normalize every opposing card to the selected rank. Otherwise limited real
        // player pools at some positions cap high divisions in the 70s/80s.
        this.people.slice(11).forEach(p => {
            const delta = wanted - p.card.overall;
            const adjust = (v) => bounds(Math.round(v + delta), 20, 99);
            p.card = { ...p.card, overall: wanted, pace: adjust(p.card.pace), passing: adjust(p.card.passing), shooting: adjust(p.card.shooting), dribbling: adjust(p.card.dribbling), defending: adjust(p.card.defending), physical: adjust(p.card.physical), stamina: adjust(p.card.stamina), keeper: adjust(p.card.keeper) };
        });
        this.selected = 9;
        this.resetKickoff(0);
    }
    attackDir(side) { return (side === 0 ? 1 : -1) * (this.half === 1 ? 1 : -1); }
    get stats() { const total = this.possessions[0] + this.possessions[1]; return { shots: this.statShots[0], shotsAgainst: this.statShots[1], passes: this.statPasses[0], passesAgainst: this.statPasses[1], possession: Math.round(this.possessions[0] / total * 100), tackles: this.statTackles[0], saves: this.statSaves[0] }; }
    view() { return { phase: this.phase, clock: this.clock, half: this.half, score: [...this.score], homePossession: this.stats.possession, stats: this.stats, notice: this.notice, noticeUntil: this.noticeUntil, charge: this.charge, selected: this.selected, holding: this.holder === null ? null : this.people[this.holder].side, setPiece: this.restartName, goalScorers: [...this.goalScorers], playerRatings: this.people.slice(0, 11).map((p, i) => { const a = this.playerActions[i]; return { name: p.card.name, goals: a.goals, shots: a.shots, passes: a.passes, tackles: a.tackles, rating: Math.min(10, Math.round((6 + a.goals * 1.6 + a.shots * .35 + a.passes * .07 + a.tackles * .4) * 10) / 10) }; }).sort((a, b) => b.rating - a.rating), replay: this.phase === 'goal' }; }
    announce(message, duration = 2.2) { this.notice = message; this.noticeUntil = duration; }
    attachBall(ball) { this.ball = ball; this.ball.setTranslation({ x: 0, y: .23, z: 0 }, true); this.ball.setLinvel({ x: 0, y: 0, z: 0 }, true); }
    placeBall(x, y, z) { this.ballPos = [x, y, z]; if (this.ball) {
        this.ball.setTranslation({ x, y, z }, true);
        this.ball.setLinvel({ x: 0, y: 0, z: 0 }, true);
        this.ball.setAngvel({ x: 0, y: 0, z: 0 }, true);
    } }
    setAim(x, z) {
        this.aiming.x = bounds(x, -FIELD_X - 3, FIELD_X + 3);
        this.aiming.z = bounds(z, -FIELD_Z - 3, FIELD_Z + 3);
        if (this.phase === 'restart' && (this.restartName === 'CORNER' || this.restartName === 'FREE KICK') && this.restartSide === 0 && this.restartPlaced)
            this.setPieceAim = { x: this.aiming.x, z: this.aiming.z };
    }
    cornerDown() { if (this.phase === 'restart' && (this.restartName === 'CORNER' || this.restartName === 'FREE KICK') && this.restartSide === 0 && this.restartPlaced) {
        this.setPieceCharging = true;
        this.setPieceChargeStart = Date.now();
    } }
    cornerUp() { if (!this.setPieceCharging)
        return; this.setPieceCharging = false; this.setPiecePower = bounds(.38 + (Date.now() - this.setPieceChargeStart) / 1400, .38, 1); this.restartTimer = 0; this.takeRestart(); }
    keyDown(code) {
        this.held.add(code);
        if (code === 'Escape' || code === 'KeyP') {
            this.togglePause();
            return;
        }
        if (this.phase !== 'playing')
            return;
        if (code === 'Space') {
            if (this.isAttacking() && this.holder === this.selected)
                this.doSkill();
            else
                this.tackle();
        }
        if (code === 'KeyE')
            this.selectDefender();
        if (code === 'ShiftLeft' && !this.isAttacking())
            this.tackle();
    }
    keyUp(code) { this.held.delete(code); }
    isAttacking() { return this.holder !== null && this.people[this.holder].side === 0; }
    setJoystick(x, z) { this.joystick = { x: bounds(x, -1, 1), z: bounds(z, -1, 1) }; }
    actionSkill() { if (this.phase !== 'playing')
        return; if (this.isAttacking() && this.holder === this.selected)
        this.doSkill();
    else
        this.selectDefender(); }
    actionSprint() { if (this.phase === 'playing' && !this.isAttacking())
        this.tackle(); }
    togglePause() { if (this.phase === 'paused') {
        this.phase = this.pausedFrom;
    }
    else if (['playing', 'restart', 'kickoff'].includes(this.phase)) {
        this.pausedFrom = this.phase;
        this.phase = 'paused';
    } }
    start() { this.phase = 'kickoff'; this.resumeTimer = 0; this.finishKickoff(); }
    secondHalf() { this.half = 2; this.clock = 45 * 60; this.resetKickoff(1); this.people.forEach(p => { p.stamina = 85; }); this.phase = 'kickoff'; this.resumeTimer = 3; this.announce('SECOND HALF', 3); }
    resetKickoff(side) {
        this.pendingOffside = null;
        this.lastShot = null;
        const coords = formationCoords(FORMATIONS[this.formation]);
        this.people.forEach((p) => { const c = coords[p.slot]; p.x = c[0] * this.attackDir(p.side); p.z = c[1] * this.attackDir(p.side); p.face = this.attackDir(p.side) > 0 ? 0 : Math.PI; p.vx = 0; p.vz = 0; p.stamina = Math.min(100, p.stamina + 12); p.aiTimer = .5; });
        this.holder = side === 0 ? 9 : 20;
        this.possessionSince = this.elapsed;
        this.selected = 9;
        this.keeperHold = 0;
        this.releaseGuard = 0;
        this.intendedReceiver = -1;
        this.passTarget = null;
        this.placeBall(0, .23, 0);
        this.people[this.holder].x = -this.attackDir(side);
        this.people[this.holder].z = 0;
        this.lastTouch = side;
    }
    finishKickoff() {
        if (this.holder === null)
            return;
        const kicker = this.people[this.holder];
        const dir = this.attackDir(kicker.side);
        const mates = this.people.filter(p => p.side === kicker.side && p.slot !== 0 && p.slot !== kicker.slot);
        const receiver = mates.sort((a, b) => Math.hypot(a.x - (kicker.x - dir * 8), a.z) - Math.hypot(b.x - (kicker.x - dir * 8), b.z))[0];
        this.phase = 'playing';
        this.possessionSince = this.elapsed - 1;
        // Kickoff automatically goes backward. No user dribbling or first touch is needed.
        this.kick(kicker, { x: receiver.x, z: receiver.z }, 'pass', .55);
        this.announce('KICKOFF', 1.3);
    }
    selectDefender() { const choices = this.people.slice(0, 11).filter(p => p.slot !== 0).sort((a, b) => distance(a, { x: this.ballPos[0], z: this.ballPos[2] }) - distance(b, { x: this.ballPos[0], z: this.ballPos[2] })); this.selected = choices[0].slot; }
    doSkill() { const p = this.people[this.selected]; if (p.cooldown > 0 || p.stamina < 2)
        return; p.skillUntil = .55; p.cooldown = 2; p.stamina = Math.max(0, p.stamina - .9); this.announce('SKILL MOVE', .5); }
    tackle() {
        if (this.phase !== 'playing')
            return;
        const p = this.people[this.selected];
        if (p.cooldown > 0 || p.stamina < 8)
            return;
        const carrier = this.holder === null ? null : this.people[this.holder];
        if (carrier?.side === 1) {
            const d = distance(p, carrier);
            if (d < 4.5) {
                const direction = { x: (carrier.x - p.x) / len(carrier.x - p.x, carrier.z - p.z), z: (carrier.z - p.z) / len(carrier.x - p.x, carrier.z - p.z) };
                p.x = bounds(p.x + direction.x * .7, -51, 51);
                p.z = bounds(p.z + direction.z * .7, -32, 32);
                p.face = Math.atan2(direction.z, direction.x);
                const advantage = (p.card.defending + (.5 + p.stamina / 200) * p.card.physical) / 2;
                const beaten = (carrier.card.dribbling + carrier.card.physical) / 2;
                this.statTackles[0]++;
                if (advantage + Math.random() * 34 - 11 > beaten) {
                    this.playerActions[this.selected].tackles++;
                    this.pokeAway(p, carrier);
                    this.announce('TACKLE WON', 1);
                }
                else if (Math.random() < .13)
                    this.foul(0, carrier.x, carrier.z);
                else
                    this.announce('TACKLE MISSED', .8);
            }
            else
                this.announce('OUT OF REACH', .6);
        }
        else if (this.holder === null && distance(p, { x: this.ballPos[0], z: this.ballPos[2] }) < 2.8) {
            this.holder = this.selected;
            this.possessionSince = this.elapsed;
            this.lastTouch = 0;
        }
        p.cooldown = .85;
        p.stamina = Math.max(0, p.stamina - .6);
    }
    pokeAway(defender, carrier) {
        const dir = this.attackDir(defender.side);
        const other = this.people.filter(o => o.side === defender.side && o.slot !== 0 && o.slot !== defender.slot).sort((a, b) => distance(a, defender) - distance(b, defender))[0];
        const dx = (other?.x ?? (carrier.x + dir * 14)) - carrier.x, dz = (other?.z ?? (carrier.z + 4)) - carrier.z;
        const L = len(dx, dz), vx = dx / L * 20, vz = dz / L * 20;
        this.holder = null;
        this.releaseGuard = .28;
        this.lastKicker = defender.side * 11 + defender.slot;
        this.lastKickType = 'pass';
        this.intendedReceiver = other ? other.side * 11 + other.slot : -1;
        this.passTarget = other ? { x: other.x, z: other.z } : null;
        this.lastTouch = defender.side;
        this.lastTouchSlot = defender.slot;
        this.placeBall(carrier.x + dx / L * .8, .35, carrier.z + dz / L * .8);
        this.ballVelocity = [vx, .6, vz];
        this.ball?.setLinvel({ x: vx, y: .6, z: vz }, true);
        this.onWhistle?.('kick');
    }
    touchShotDown() { if (this.phase === 'playing' && this.isAttacking() && this.holder === this.selected) {
        this.charge = .001;
        this.shotDownAt = Date.now();
    } }
    touchShotUp() {
        if (this.phase !== 'playing' || this.charge === 0)
            return;
        const duration = Math.max(this.charge, (Date.now() - this.shotDownAt) / 1000);
        this.charge = 0;
        const p = this.people[this.selected];
        if (this.holder !== this.selected || p.side !== 0)
            return;
        const face = { x: Math.cos(p.face), z: Math.sin(p.face) };
        if (duration < .18) {
            const mates = this.people.slice(0, 11).filter(t => t.slot !== p.slot && t.slot !== 0).map(t => ({ p: t, forward: (t.x - p.x) * face.x + (t.z - p.z) * face.z, side: Math.abs((t.x - p.x) * face.z - (t.z - p.z) * face.x) })).filter(t => t.forward > 1).sort((a, b) => a.side - b.side);
            const t = mates[0]?.p;
            this.kick(p, t ? { x: t.x + t.vx * .23, z: t.z + t.vz * .23 } : { x: p.x + face.x * 18, z: p.z + face.z * 18 }, 'pass', .75);
        }
        else
            this.kick(p, { x: p.x + face.x * 50, z: p.z + face.z * 50 }, 'shot', bounds(.48 + (duration - .18) * .48, .48, 1));
    }
    mouseDown() { if (this.phase === 'playing' && this.isAttacking() && this.holder === this.selected) {
        this.charge = .001;
        this.shotDownAt = Date.now();
    } }
    mouseUp() {
        if (this.phase !== 'playing' || this.charge === 0)
            return;
        const duration = Math.max(this.charge, (Date.now() - this.shotDownAt) / 1000);
        this.charge = 0;
        if (this.holder !== this.selected || this.people[this.selected].side !== 0)
            return;
        if (duration < .18)
            this.playerPass();
        else
            this.playerShot(duration);
    }
    playerPass() {
        const p = this.people[this.selected], dirX = this.aiming.x - p.x, dirZ = this.aiming.z - p.z, angle = Math.atan2(dirZ, dirX);
        const mates = this.people.slice(0, 11).filter(t => t.slot !== p.slot && t.slot !== 0);
        const candidates = mates.map(t => {
            const d = distance(p, t), da = Math.abs(Math.atan2(Math.sin(Math.atan2(t.z - p.z, t.x - p.x) - angle), Math.cos(Math.atan2(t.z - p.z, t.x - p.x) - angle)));
            const openness = Math.min(...this.people.slice(11).map(o => distance(o, t)));
            return { p: t, score: da * 18 + Math.abs(d - 18) * .23 - Math.min(4, openness) * .7 };
        }).sort((a, b) => a.score - b.score);
        const mate = candidates[0]?.p;
        const target = mate && candidates[0].score < 22 ? { x: mate.x + mate.vx * .25, z: mate.z + mate.vz * .25 } : this.aiming;
        this.kick(p, target, 'pass', .75);
    }
    playerShot(duration) {
        const p = this.people[this.selected];
        const power = bounds(.48 + (duration - .18) * .48, .48, 1);
        // Aim exactly where the cursor points: no magnetism toward the goal.
        const dx = this.aiming.x - p.x, dz = this.aiming.z - p.z;
        const target = Math.hypot(dx, dz) > 2 ? { x: this.aiming.x, z: this.aiming.z } : { x: p.x + Math.cos(p.face) * 40, z: p.z + Math.sin(p.face) * 40 };
        this.kick(p, target, 'shot', power);
    }
    cancelShot() { this.charge = 0; }
    kick(p, target, type, power) {
        if (this.phase !== 'playing' || this.holder !== p.side * 11 + p.slot || this.elapsed - this.possessionSince < .35)
            return;
        let aimed = { ...target };
        if (type === 'shot') {
            const goalX = this.attackDir(p.side) * 52.5;
            const forward = (target.x - p.x) * (goalX - p.x) > 0;
            const angle = Math.atan2(target.z - p.z, target.x - p.x);
            const goalAngle = Math.atan2(-p.z, goalX - p.x);
            const diff = Math.atan2(Math.sin(goalAngle - angle), Math.cos(goalAngle - angle));
            // Gentle assist only for goalward shots, not crosses or shots aimed elsewhere.
            if (forward && Math.abs(diff) < .30) {
                const assisted = angle + diff * .22;
                const length = Math.hypot(target.x - p.x, target.z - p.z);
                aimed = { x: p.x + Math.cos(assisted) * length, z: p.z + Math.sin(assisted) * length };
            }
        }
        const dx = aimed.x - p.x, dz = aimed.z - p.z, d = len(dx, dz), accuracy = bounds((type === 'shot' ? p.card.shooting : p.card.passing) / 100, 0, 1);
        // The lowest shooting rating means only up to 5 degrees off aim, never a 90-degree miss.
        const maxError = (type === 'shot' ? 5 : 4) * (1 - accuracy) * Math.PI / 180 * (type === 'shot' && p.side === 1 ? .48 : 1);
        const drift = (Math.random() * 2 - 1) * maxError, tx = dx / d * Math.cos(drift) - dz / d * Math.sin(drift), tz = dx / d * Math.sin(drift) + dz / d * Math.cos(drift);
        const speed = type === 'shot' ? (30 + power * 27) * (.8 + .2 * accuracy) * (p.side === 1 ? .93 : 1) : type === 'cross' ? 18 + power * 21 : 34 + p.card.passing * .07;
        const goalDistance = Math.abs(this.attackDir(p.side) * FIELD_X - p.x);
        const closeShot = type === 'shot' && goalDistance < 16;
        const lift = type === 'shot' ? (closeShot ? .65 + power * .65 : (p.side === 1 ? 1.2 : 2.1) + power * (p.side === 1 ? 1.2 : 2.8)) : type === 'cross' ? 3 + power * 7 : .24;
        // Flag potential offside positions at the moment the ball is played.
        // No whistle until an offside teammate actually touches or plays the ball.
        this.pendingOffside = type === 'pass' ? this.offsideCandidates(p) : null;
        this.lastShot = type === 'shot' ? { side: p.side, distance: Math.abs(this.attackDir(p.side) * FIELD_X - p.x), speed, shooting: p.card.shooting, power } : null;
        this.holder = null;
        this.lastTouch = p.side;
        this.lastTouchSlot = p.slot;
        this.lastKicker = p.side * 11 + p.slot;
        this.lastKickType = type;
        this.releaseGuard = .28;
        this.passTarget = type === 'pass' ? { ...target } : null;
        const receiver = type === 'pass' ? this.people.filter(o => o.side === p.side && o.slot !== p.slot && o.slot !== 0).sort((a, b) => distance(a, target) - distance(b, target))[0] : null;
        this.intendedReceiver = receiver && distance(receiver, target) < 12 ? receiver.side * 11 + receiver.slot : -1;
        // Place the ball beyond the foot to prevent the kicker immediately re-catching it.
        this.placeBall(p.x + tx * 1.55, .38, p.z + tz * 1.55);
        this.ballVelocity = [tx * speed, lift, tz * speed];
        this.ball?.setLinvel({ x: tx * speed, y: lift, z: tz * speed }, true);
        this.ball?.setAngvel({ x: tz * 6, y: 3 * (Math.random() - .5), z: -tx * 6 }, true);
        if (type === 'shot') {
            this.statShots[p.side]++;
            this.playerActions[p.side * 11 + p.slot].shots++;
            this.announce(p.side === 0 ? 'SHOT!' : 'OPPOSITION SHOT', 1.2);
        }
        else {
            this.statPasses[p.side]++;
            this.playerActions[p.side * 11 + p.slot].passes++;
        }
        this.onWhistle?.('kick');
    }
    offsideCandidates(p) {
        const dir = this.attackDir(p.side);
        const defenders = this.people.filter(a => a.side !== p.side).map(a => a.x * dir).sort((a, b) => b - a);
        const line = Math.max(0, defenders[1] ?? 0);
        const players = new Set(this.people.filter(a => a.side === p.side && a.slot !== p.slot && a.x * dir > Math.max(0, line) + .01 && a.x * dir > p.x * dir + .01).map(a => a.side * 11 + a.slot));
        return players.size ? { side: p.side, players } : null;
    }
    isOffside(p, target) {
        const dir = this.attackDir(p.side);
        const defenders = this.people.filter(a => a.side !== p.side).map(a => a.x * dir).sort((a, b) => b - a);
        const line = defenders[1] || 0;
        const receiver = this.people.filter(a => a.side === p.side && a.slot !== p.slot).sort((a, b) => Math.hypot(a.x - target.x, a.z - target.z) - Math.hypot(b.x - target.x, b.z - target.z))[0];
        return !!receiver && receiver.x * dir > Math.max(0, p.x * dir, line) + 1.5 && Math.hypot(receiver.x - target.x, receiver.z - target.z) < 10;
    }
    foul(aggressor, x, z) {
        const other = (1 - aggressor);
        const inBox = (other === 0 ? x > 36 : x < -36) && Math.abs(z) < 20.2;
        this.restart(inBox ? 'PENALTY' : 'FREE KICK', other, inBox ? (other === 0 ? 41.5 : -41.5) : x, z);
        this.onWhistle?.('whistle');
    }
    restart(name, side, x, z) { this.pendingOffside = null; this.phase = 'restart'; this.restartName = name; this.restartSide = side; this.restartX = bounds(x, -52.5, 52.5); this.restartZ = bounds(z, -34, 34); this.setPieceAim = null; this.setPiecePower = .82; this.setPieceCharging = false; this.lastShot = null; this.restartTimer = 4; this.restartPlaced = false; this.holder = null; this.releaseGuard = 0; this.intendedReceiver = -1; this.passTarget = null; this.placeBall(this.restartX, .23, this.restartZ); this.announce(name, 2); this.onWhistle?.('whistle'); }
    stageRestart() {
        const side = this.restartSide;
        const taker = this.people.filter(p => p.side === side).sort((a, b) => distance(a, { x: this.restartX, z: this.restartZ }) - distance(b, { x: this.restartX, z: this.restartZ }))[0];
        taker.x = bounds(this.restartX - this.attackDir(side) * (this.restartName === 'THROW-IN' ? 0.4 : 1.2), -52.5, 52.5);
        taker.z = this.restartName === 'THROW-IN' ? this.restartZ - Math.sign(this.restartZ) * .35 : this.restartZ;
        taker.vx = 0;
        taker.vz = 0;
        this.arrangeSetPiece(taker);
        if (this.restartName === 'FREE KICK' || this.restartName === 'PENALTY')
            this.enforceSetPieceSpace(taker, 9.15);
        this.placeBall(this.restartX, .23, this.restartZ);
        this.announce(`${this.restartName} · READY`, 2);
    }
    // Organize both teams before the second whistle, keeping the taker stationary.
    arrangeSetPiece(taker) {
        const attacker = this.people.filter(p => p.side === this.restartSide && p !== taker && p.slot !== 0);
        const defender = this.people.filter(p => p.side !== this.restartSide && p.slot !== 0);
        const isCorner = this.restartName === 'CORNER', isThrow = this.restartName === 'THROW-IN';
        const direction = this.attackDir(this.restartSide);
        const targetX = isCorner ? direction * 45 : this.restartX;
        const targetZ = isCorner ? 0 : this.restartZ;
        const setPosition = (p, x, z) => { p.x = bounds(x, -50.5, 50.5); p.z = bounds(z, -31.5, 31.5); p.vx = 0; p.vz = 0; };
        if (isCorner) {
            // Eight outfield attackers flood the box; two stay behind to recycle possession.
            attacker.forEach((p, i) => setPosition(p, i < 8 ? targetX - direction * (3 + (i % 3) * 1.7) : targetX - direction * (23 + (i - 8) * 6), i < 8 ? (i - 3.5) * 3.8 : (i - 8) * 10 - 5));
            defender.forEach((p, i) => setPosition(p, targetX - direction * (3 + (i % 4) * 3.2), (i - 4.5) * 3.9));
        }
        else if (isThrow) {
            attacker.forEach((p, i) => { if (i < 2)
                setPosition(p, targetX + direction * (4 + i * 4), targetZ - Math.sign(targetZ || 1) * (5 + i * 4)); });
            defender.forEach((p, i) => { if (i < 2)
                setPosition(p, targetX + direction * (6 + i * 3), targetZ - Math.sign(targetZ || 1) * (7 + i * 4)); });
        }
        else if (this.restartName === 'FREE KICK') {
            attacker.forEach((p, i) => setPosition(p, targetX + direction * (8 + (i % 5) * 4), targetZ + (i - 4.5) * 4));
            defender.forEach((p, i) => setPosition(p, targetX + direction * (12 + (i % 4) * 3), targetZ + (i - 4.5) * 4.5));
        }
        else if (this.restartName === 'GOAL KICK') {
            attacker.forEach((p, i) => setPosition(p, -direction * (30 - (i % 4) * 15), (i - 4.5) * 6));
            defender.forEach((p, i) => setPosition(p, -direction * (8 - (i % 4) * 14), (i - 4.5) * 6));
        }
        else if (this.restartName === 'PENALTY') {
            attacker.forEach((p, i) => setPosition(p, targetX - direction * (13 + i % 3 * 2), (i - 4.5) * 4));
            defender.forEach((p, i) => setPosition(p, targetX - direction * (15 + i % 3 * 2), (i - 4.5) * 4));
        }
    }
    enforceSetPieceSpace(taker, radius = 9.15) { for (const p of this.people) {
        if (p.side === taker.side)
            continue;
        const dx = p.x - this.restartX, dz = p.z - this.restartZ;
        const d = len(dx, dz);
        if (d < radius) {
            p.x = bounds(this.restartX + dx / d * radius, -51, 51);
            p.z = bounds(this.restartZ + dz / d * radius, -33, 33);
            p.vx = 0;
            p.vz = 0;
        }
    } }
    takeRestart() {
        const side = this.restartSide;
        const choices = this.people.filter(p => p.side === side);
        const taker = [...choices].sort((a, b) => distance(a, { x: this.restartX, z: this.restartZ }) - distance(b, { x: this.restartX, z: this.restartZ }))[0];
        taker.x = bounds(this.restartX - this.attackDir(side) * .7, -52.5, 52.5);
        taker.z = this.restartZ - (this.restartName === 'THROW-IN' ? Math.sign(this.restartZ) * .35 : 0);
        this.holder = taker.side * 11 + taker.slot;
        this.possessionSince = this.elapsed - 1;
        this.lastTouch = side;
        this.lastTouchSlot = taker.slot;
        this.phase = 'playing';
        if (side === 0 && taker.slot !== 0)
            this.selected = taker.slot;
        if (this.restartName === 'CORNER') {
            const aim = side === 0 ? (this.setPieceAim ?? { x: this.attackDir(side) * 41, z: 0 }) : { x: this.attackDir(side) * 41, z: (Math.random() - .5) * 9 };
            // Cross is not auto-aimed for the player: direction and power come from the pointer.
            this.kick(taker, aim, 'cross', side === 0 ? this.setPiecePower : .8);
        }
        else if (this.restartName === 'FREE KICK' && side === 0) {
            const aim = this.setPieceAim ?? { x: this.attackDir(side) * 54, z: 0 };
            const power = this.setPiecePower;
            const forward = (aim.x - taker.x) * this.attackDir(side);
            const goalDistance = Math.abs(this.attackDir(side) * 54 - taker.x);
            const shooting = forward > 0 && goalDistance < 39 && Math.abs(aim.z) < 12 && power >= .57;
            this.kick(taker, aim, shooting ? 'shot' : 'pass', power);
        }
        else if (this.restartName === 'THROW-IN') {
            const target = this.choosePass(taker);
            if (target)
                this.kick(taker, { x: target.x, z: target.z }, 'pass', .65);
        }
        else if (this.restartName === 'PENALTY') {
            const goalX = this.attackDir(side) * 54;
            this.kick(taker, { x: goalX, z: (Math.random() - .5) * 4.2 }, 'shot', .86);
        }
        else if (side === 1) {
            const target = this.choosePass(taker);
            if (target)
                this.kick(taker, target, 'pass', .45);
        }
        else
            this.announce('PLAY RESUMED', .8);
        this.restartName = '';
    }
    choosePass(p) {
        const mates = this.people.filter(a => a.side === p.side && a.slot !== p.slot && a.slot !== 0), opponents = this.people.filter(a => a.side !== p.side);
        const dir = this.attackDir(p.side);
        const scored = mates.map(t => {
            const d = distance(p, t), progress = (t.x - p.x) * dir, space = Math.min(...opponents.map(o => distance(o, t)));
            const pathX = t.x - p.x, pathZ = t.z - p.z, L = Math.max(1, pathX * pathX + pathZ * pathZ);
            const laneRisk = opponents.reduce((worst, o) => {
                const k = bounds(((o.x - p.x) * pathX + (o.z - p.z) * pathZ) / L, 0, 1);
                if (k < .08 || k > .94)
                    return worst;
                const gap = Math.hypot(o.x - (p.x + pathX * k), o.z - (p.z + pathZ * k));
                return Math.max(worst, gap < 2.3 ? 1 : gap < 4.2 ? .45 : 0);
            }, 0);
            const ahead = t.x * dir > 48 ? 17 : 0;
            // Reward useful progress, but heavily penalize traffic, tight marking and low-percentage long balls.
            const score = bounds(progress, -18, 24) * .42 + Math.min(space, 11) * 2.3 - Math.abs(d - 14) * .65 - laneRisk * 31 - (space < 3 ? 22 : 0) - ahead - (d > 35 ? 20 : 0);
            return { t, score, space, laneRisk, d };
        }).sort((a, b) => b.score - a.score);
        return scored[0]?.t;
    }
    // Prefer a nearby, unmarked defender with a clear passing lane.
    chooseKeeperOutlet(g) {
        const opponents = this.people.filter(o => o.side !== g.side && o.slot !== 0);
        const choices = this.people.filter(t => t.side === g.side && t.slot !== 0).map(t => {
            const d = distance(g, t), nearest = Math.min(...opponents.map(o => distance(o, t)));
            const vx = t.x - g.x, vz = t.z - g.z, L = Math.max(1, vx * vx + vz * vz);
            const blocked = opponents.some(o => { const k = bounds(((o.x - g.x) * vx + (o.z - g.z) * vz) / L, 0, 1); return k > .08 && k < .92 && Math.hypot(o.x - (g.x + vx * k), o.z - (g.z + vz * k)) < 3; });
            return { t, score: nearest * 2 - Math.abs(d - 12) * 1.4 - (blocked ? 35 : 0) + (t.slot <= 4 ? 8 : 0) - (d > 30 ? 35 : 0) };
        }).sort((a, b) => b.score - a.score);
        return choices[0]?.t;
    }
    aiDecision(p) {
        if (this.holder !== p.side * 11 + p.slot)
            return;
        const dir = this.attackDir(p.side), goalX = dir * 52.5, dGoal = Math.abs(p.x - goalX), level = p.side === 1 ? this.aiLevel / 18 * .78 : .6;
        const defenders = this.people.filter(o => o.side !== p.side && o.slot !== 0);
        const pressure = Math.min(...defenders.map(o => distance(o, p)));
        const timeOnBall = this.elapsed - this.possessionSince;
        // The first touch must settle. AI never chains an instant one-touch pass.
        if (timeOnBall < .35) {
            p.aiTimer = .14;
            return;
        }
        const goalLane = defenders.every(o => { const k = bounds((o.x - p.x) / (goalX - p.x || 1), 0, 1); return k <= .05 || k >= .95 || Math.abs(o.z - (p.z - p.z * k)) > 3.1; });
        const shootChance = dGoal < 12 ? .65 : dGoal < 21 ? .47 : dGoal < 29 ? .25 : dGoal < 35 ? .06 : 0;
        if (dGoal < 35 && Math.abs(p.z) < 21 && (goalLane || dGoal < 23) && Math.random() < Math.min(.68, shootChance * (.45 + level * .65))) {
            this.kick(p, { x: goalX + dir * 2, z: bounds((Math.random() - .5) * 2, -2, 2) }, 'shot', bounds(.88 + level * .12, .88, 1));
            return;
        }
        // Carry into space and create a shooting opportunity rather than ping-ponging.
        if (pressure > 5.2 && dGoal > 11) {
            p.aiTimer = .4 + Math.random() * .55;
            return;
        }
        const receiver = this.choosePass(p);
        if (receiver) {
            const space = Math.min(...defenders.map(o => distance(o, receiver)));
            const advance = (receiver.x - p.x) * dir;
            const goodPass = space > 3.5 && distance(p, receiver) < 29 && (advance > -7 || pressure < 3);
            if (goodPass && Math.random() < (pressure < 3 ? .55 + level * .24 : .22 + level * .26)) {
                this.kick(p, { x: receiver.x + receiver.vx * .2, z: receiver.z + receiver.vz * .2 }, 'pass', .7);
                return;
            }
        }
        p.aiTimer = .35 + Math.random() * .4;
    }
    adjustBall() { if (this.ball) {
        const a = this.ball.translation(), v = this.ball.linvel();
        this.ballPos = [a.x, a.y, a.z];
        this.ballVelocity = [v.x, v.y, v.z];
    } }
    simulate(dt) {
        if (this.phase === 'paused' || this.phase === 'half' || this.phase === 'full')
            return;
        this.elapsed += dt;
        this.releaseGuard = Math.max(0, this.releaseGuard - dt);
        this.noticeUntil = Math.max(0, this.noticeUntil - dt);
        if (this.phase === 'goal') {
            this.goalTimer -= dt;
            this.replayProgress += dt;
            if (this.replayFrames.length) {
                const position = Math.min(this.replayFrames.length - 1, (this.replayProgress / 3.1) * (this.replayFrames.length - 1));
                const lo = Math.floor(position), hi = Math.min(this.replayFrames.length - 1, lo + 1), t = position - lo;
                const a = this.replayFrames[lo], b = this.replayFrames[hi];
                if (a && b) {
                    a.people.forEach(([x, z], i) => { this.people[i].x = x + (b.people[i][0] - x) * t; this.people[i].z = z + (b.people[i][1] - z) * t; });
                    this.placeBall(a.ball[0] + (b.ball[0] - a.ball[0]) * t, a.ball[1] + (b.ball[1] - a.ball[1]) * t, a.ball[2] + (b.ball[2] - a.ball[2]) * t);
                }
            }
            if (this.goalTimer <= 0) {
                this.resetKickoff(this.lastTouch === 0 ? 1 : 0);
                this.phase = 'kickoff';
                this.resumeTimer = 3;
                this.frames = [];
                this.announce('KICKOFF IN 3', 3);
            }
            return;
        }
        if (this.phase === 'kickoff') {
            if (this.resumeTimer > 0) {
                this.resumeTimer -= dt;
                if (this.resumeTimer <= 0)
                    this.finishKickoff();
            }
            return;
        }
        if (this.phase === 'restart') {
            this.restartTimer -= dt;
            if (this.restartTimer <= 2 && !this.restartPlaced) {
                this.restartPlaced = true;
                this.stageRestart();
            }
            if (this.restartPlaced && (this.restartName === 'FREE KICK' || this.restartName === 'PENALTY')) {
                const taker = this.people.filter(p => p.side === this.restartSide).sort((a, b) => distance(a, { x: this.restartX, z: this.restartZ }) - distance(b, { x: this.restartX, z: this.restartZ }))[0];
                this.enforceSetPieceSpace(taker);
            }
            if (this.restartTimer <= 0) {
                if ((this.restartName === 'CORNER' || this.restartName === 'FREE KICK') && this.restartSide === 0) {
                    this.restartTimer = .016;
                    this.announce(this.restartName === 'CORNER' ? 'CORNER · AIM AND HOLD TO CROSS' : 'FREE KICK · AIM AND HOLD TO SHOOT OR PASS', .5);
                }
                else
                    this.takeRestart();
            }
            return;
        }
        const gameRate = 30;
        this.clock += dt * gameRate;
        if (this.clock >= (this.half === 1 ? 2700 : 5400)) {
            this.clock = this.half === 1 ? 2700 : 5400;
            this.phase = this.half === 1 ? 'half' : 'full';
            this.charge = 0;
            this.onWhistle?.('whistle');
            return;
        }
        if (this.charge > 0)
            this.charge = Math.min(2.3, this.charge + dt);
        this.adjustBall();
        // Shot outcomes are decided at the goal line, not by a proximity-based keeper trap.
        // Non-shot loose balls can still be gathered normally by the goalkeeper.
        if (this.holder !== null) {
            if (this.holder < 11 && this.holder !== 0 && this.selected !== this.holder)
                this.selected = this.holder % 11;
            this.intendedReceiver = -1;
            this.passTarget = null;
            const h = this.people[this.holder];
            this.possessions[h.side] += dt;
            if (h.slot === 0) {
                this.keeperHold -= dt;
                if (this.keeperHold <= 0 && this.elapsed - this.possessionSince >= .35) {
                    const receiver = this.chooseKeeperOutlet(h);
                    if (receiver)
                        this.kick(h, { x: receiver.x + receiver.vx * .18, z: receiver.z + receiver.vz * .18 }, 'pass', .55);
                    else
                        this.kick(h, { x: h.x + this.attackDir(h.side) * 16, z: 0 }, 'pass', .55);
                }
            }
        }
        else if (this.ballPos[1] < 2.8 && Math.abs(this.ballPos[0]) <= 54 && Math.abs(this.ballPos[2]) <= 35)
            this.findLooseBall();
        this.movePlayers(dt);
        if (this.holder !== null) {
            const p = this.people[this.holder];
            const lead = Math.min(1.3, 1 + .05 * Math.hypot(p.vx, p.vz));
            this.placeBall(p.x + Math.cos(p.face) * lead, .25, p.z + Math.sin(p.face) * lead);
            this.ballVelocity = [p.vx, 0, p.vz];
        }
        else {
            this.adjustBall();
            this.checkBoundary();
        }
        this.frameClock += dt;
        if (this.frameClock > .13) {
            this.frameClock = 0;
            this.frames.push({ ball: [...this.ballPos], people: this.people.map(p => [p.x, p.z]) });
            if (this.frames.length > 35)
                this.frames.shift();
        }
        this.uiClock += dt;
        if (this.uiClock > .12) {
            this.uiClock = 0;
            this.onView?.(this.view());
        }
    }
    findLooseBall() {
        const target = { x: this.ballPos[0], z: this.ballPos[2] }, speed = Math.hypot(this.ballVelocity[0], this.ballVelocity[2]);
        const candidates = this.people.filter(p => distance(p, target) < (p.side * 11 + p.slot === this.intendedReceiver ? 1.85 : 1.5) && (this.releaseGuard <= 0 || p.side * 11 + p.slot !== this.lastKicker))
            .sort((a, b) => ((a.side * 11 + a.slot === this.intendedReceiver) ? -2 : distance(a, target)) - ((b.side * 11 + b.slot === this.intendedReceiver) ? -2 : distance(b, target)));
        for (const winner of candidates) {
            if (winner.slot === 0 && (Math.abs(winner.x) < 34 || this.lastKickType === 'shot'))
                continue;
            // Players must get in front of a fast moving ball; they cannot catch shots by proximity alone.
            if (this.lastKickType === 'shot' && speed > 36 && winner.slot !== 0 && Math.random() < .7)
                continue;
            if (this.releaseGuard > .12 && winner.side * 11 + winner.slot !== this.intendedReceiver)
                continue;
            if (this.pendingOffside) {
                const flagged = this.pendingOffside.side === winner.side && this.pendingOffside.players.has(winner.side * 11 + winner.slot);
                this.pendingOffside = null;
                if (flagged) {
                    this.restart('OFFSIDE', (1 - winner.side), winner.x, winner.z);
                    return;
                }
            }
            this.holder = winner.side * 11 + winner.slot;
            this.possessionSince = this.elapsed;
            this.lastTouch = winner.side;
            this.lastTouchSlot = winner.slot;
            this.releaseGuard = 0;
            this.intendedReceiver = -1;
            this.passTarget = null;
            this.lastShot = null;
            if (winner.slot === 0) {
                this.keeperHold = .88 + Math.random() * .20;
                this.statSaves[winner.side]++;
                this.announce(winner.side === 0 ? 'GREAT SAVE' : 'OPPOSITION SAVE', 1.3);
            }
            if (winner.side === 0 && winner.slot !== 0)
                this.selected = winner.slot;
            return;
        }
    }
    checkBoundary() {
        const [x, y, z] = this.ballPos;
        if (Math.abs(x) > FIELD_X + .6) {
            if (Math.abs(z) < GOAL_Z && y < 2.65) {
                const attacking = (x > 0) === (this.attackDir(0) > 0) ? 0 : 1, defending = (1 - attacking);
                if (this.lastShot && this.lastShot.side === attacking) {
                    const goalie = this.people[defending * 11];
                    const odds = shotOutcomeOdds(goalie.card.keeper, this.lastShot.distance, this.lastShot.speed, this.lastShot.shooting, this.lastShot.power);
                    const roll = Math.random();
                    this.lastShot = null;
                    if (roll < odds.goal) {
                        this.goal(attacking);
                        return;
                    }
                    this.statSaves[defending]++;
                    this.lastTouch = defending;
                    this.lastTouchSlot = 0;
                    if (roll < odds.goal + odds.parry) {
                        const cornerZ = (Math.random() < .5 ? -FIELD_Z : FIELD_Z);
                        this.parryPending = { side: attacking, x: x > 0 ? FIELD_X : -FIELD_X, z: cornerZ, timer: .55 };
                        this.placeBall(x > 0 ? FIELD_X - 1 : -FIELD_X + 1, .65, bounds(z, -3, 3));
                        const deflectX = x > 0 ? -9 : 9, deflectZ = Math.sign(cornerZ) * (12 + Math.random() * 12);
                        this.ballVelocity = [deflectX, 1.5, deflectZ];
                        this.ball?.setLinvel({ x: deflectX, y: 1.5, z: deflectZ }, true);
                        this.announce('PARRIED!', .6);
                        return;
                    }
                    this.pendingOffside = null;
                    this.holder = defending * 11;
                    this.possessionSince = this.elapsed;
                    this.keeperHold = .75;
                    goalie.x = x > 0 ? 49 : -49;
                    goalie.z = bounds(z, -2.8, 2.8);
                    this.placeBall(goalie.x, .8, goalie.z);
                    this.announce('GOALKEEPER CATCH', 1.4);
                    return;
                }
                this.goal(attacking);
                return;
            }
            const defending = (x > 0) === (this.attackDir(0) > 0) ? 1 : 0;
            const attacking = (1 - defending);
            if (this.lastTouch === defending)
                this.restart('CORNER', attacking, x > 0 ? 52.5 : -52.5, z < 0 ? -34 : 34);
            else
                this.restart('GOAL KICK', defending, x > 0 ? 46 : -46, z < 0 ? -7 : 7);
            return;
        }
        if (Math.abs(z) > FIELD_Z + .6)
            this.restart('THROW-IN', (1 - this.lastTouch), bounds(x, -52.3, 52.3), z > 0 ? 34 : -34);
    }
    goal(side) {
        this.score[side]++;
        this.lastTouch = side;
        const scorer = this.people[this.lastTouchSlot + side * 11];
        this.lastScorer = scorer?.card.name || 'Own goal';
        if (scorer && scorer.side === side)
            this.playerActions[side * 11 + scorer.slot].goals++;
        if (side === 0)
            this.goalScorers.push(`${Math.floor(this.clock / 60)}' ${this.lastScorer}`);
        this.replayFrames = this.frames.slice();
        this.replayProgress = 0;
        this.goalTimer = 4;
        this.phase = 'goal';
        this.charge = 0;
        this.announce(`GOAL! ${this.score[0]} - ${this.score[1]}`, 4);
        this.onWhistle?.('goal');
        this.ball?.setLinvel({ x: 0, y: 0, z: 0 }, true);
    }
    movePlayers(dt) {
        const holder = this.holder !== null ? this.people[this.holder] : null;
        const bx = holder?.x ?? this.ballPos[0], bz = holder?.z ?? this.ballPos[2];
        const formation = formationCoords(FORMATIONS[this.formation]);
        const closeToBall = (side) => this.people.filter(p => p.side === side && p.slot !== 0)
            .sort((a, b) => distance(a, { x: bx, z: bz }) - distance(b, { x: bx, z: bz }));
        // Commit more defenders to dangerous attacking carriers, but do not swarm deep defenders.
        const threat = holder ? Math.max(0, -holder.x * this.attackDir(holder.side) + 12) : 0;
        const pressCount = holder && holder.slot >= 7 && threat > 20 ? 3 : holder && holder.slot <= 4 ? 1 : 2;
        const pressers = [closeToBall(0).slice(0, holder?.side === 1 ? pressCount : 2), closeToBall(1).slice(0, holder?.side === 0 ? pressCount : 2)];
        const marks = new Map();
        // Pick unique marking assignments rather than sending everyone to the ball.
        for (const side of [0, 1]) {
            if (holder?.side === side)
                continue;
            const opponents = this.people.filter(o => o.side !== side && o.slot !== 0), taken = new Set();
            for (const p of this.people.filter(o => o.side === side && o.slot !== 0 && !pressers[side].includes(o))) {
                const base = formation[p.slot], dir = this.attackDir(side);
                const shapeX = dir * (base[0] + bounds((bx * dir + 28) * .39, -5, 25));
                const shapeZ = base[1] * dir * .77 + bz * .23;
                const candidate = opponents.filter(o => !taken.has(o.slot)).sort((a, b) => distance(a, { x: shapeX, z: shapeZ }) - distance(b, { x: shapeX, z: shapeZ }))[0];
                if (candidate && distance(candidate, { x: shapeX, z: shapeZ }) < 38) {
                    marks.set(side * 11 + p.slot, candidate);
                    taken.add(candidate.slot);
                }
            }
        }
        for (const p of this.people) {
            p.cooldown = Math.max(0, p.cooldown - dt);
            p.skillUntil = Math.max(0, p.skillUntil - dt);
            p.aiTimer -= dt;
            const index = p.side * 11 + p.slot, hasBall = this.holder === index;
            const dir = this.attackDir(p.side), base = formation[p.slot];
            const attacking = holder?.side === p.side, defending = holder !== null && holder.side !== p.side;
            const isHuman = p.side === 0 && p.slot === this.selected && p.slot !== 0;
            const inputX = bounds((this.held.has('KeyD') ? 1 : 0) - (this.held.has('KeyA') ? 1 : 0) + this.joystick.x, -1, 1);
            const inputZ = bounds((this.held.has('KeyS') ? 1 : 0) - (this.held.has('KeyW') ? 1 : 0) + this.joystick.z, -1, 1);
            const usingInput = isHuman && Math.hypot(inputX, inputZ) > .08;
            let tx = p.x, tz = p.z;
            if (isHuman) {
                if (usingInput) {
                    const mag = len(inputX, inputZ);
                    tx = p.x + inputX / mag * 10;
                    tz = p.z + inputZ / mag * 10;
                }
                else {
                    tx = p.x;
                    tz = p.z;
                    p.vx = 0;
                    p.vz = 0;
                }
            }
            else if (hasBall && p.slot === 0) {
                tx = dir * -47;
                tz = bounds(p.z, -5, 5);
            }
            else if (hasBall) {
                const pressure = Math.min(...this.people.filter(o => o.side !== p.side).map(o => distance(o, p)));
                tx = bounds(p.x + dir * 13, -49, 49);
                tz = p.z + (Math.abs(p.z) > 24 ? -Math.sign(p.z) * 5 : 0);
                if (pressure < 3.5)
                    tz = p.z + Math.sin(this.elapsed * 2.4 + p.slot) * 6;
                if (!isHuman && p.aiTimer <= 0) {
                    this.aiDecision(p);
                    p.aiTimer = .55 + Math.random() * .32;
                }
            }
            else if (holder?.slot === 0 && holder.side !== p.side) {
                // Retreat fully outside the opposing keeper's penalty area.
                const boxEdge = this.attackDir(holder.side) * -36;
                tx = this.attackDir(holder.side) > 0 ? Math.max(p.x, boxEdge + 2.4) : Math.min(p.x, boxEdge - 2.4);
                tz = bounds(p.z, -27, 27);
            }
            else if (p.slot === 0) {
                const goalX = -dir * 46;
                tx = goalX + (bx - goalX) * .1;
                tz = bounds(bz * .6, -6.2, 6.2);
                if (!holder && Math.abs(bx - dir * -52.5) < 16 && Math.abs(bz) < 21 && this.ballPos[1] < 2.4) {
                    tx = bx;
                    tz = bz;
                }
            }
            else {
                // Both teams shift their whole shape with possession, while maintaining width and depth.
                const ballProgress = bx * dir;
                const advance = attacking ? bounds((ballProgress + 29) * .74 + Math.max(0, ballProgress - 15) * .65, 0, 65) : bounds((ballProgress + 29) * .23, -12, 15);
                const depth = attacking ? (p.slot <= 4 ? .78 : p.slot <= 7 ? .96 : 1) : p.slot <= 4 ? .88 : p.slot <= 7 ? .96 : 1;
                const tacticChange = p.side === 0 ? (this.tactic === 'Attacking' ? 4 : this.tactic === 'Defensive' ? -4 : 0) : 0;
                tx = bounds(dir * (base[0] + advance * depth + (attacking ? 2 : 0) + tacticChange), -49, 49);
                const spread = attacking ? 1 : .68;
                tz = bounds(base[1] * dir * spread + bz * (attacking ? .23 : .28), -30, 30);
                if (attacking) {
                    // Forwards and wide players continue through their lanes, even when the user dribbles ahead.
                    if (p.slot >= 7) {
                        const gap = (tx - bx) * dir;
                        tx = bounds(tx + dir * bounds(12 - gap, 0, 9), -49, 49);
                        tz = bounds(tz + Math.sin(this.elapsed * .9 + p.slot) * 1.5, -31, 31);
                        const nearest = this.people.filter(o => o.side !== p.side && o.slot !== 0).sort((a, b) => distance(a, { x: tx, z: tz }) - distance(b, { x: tx, z: tz }))[0];
                        if (nearest && distance(nearest, { x: tx, z: tz }) < 6) {
                            const away = tz - nearest.z || ((p.slot % 2) ? 1 : -1);
                            tz = bounds(tz + Math.sign(away) * Math.min(5, 6 - distance(nearest, { x: tx, z: tz })), -30, 30);
                        }
                    }
                }
                else {
                    const press = pressers[p.side].includes(p);
                    if (press && distance(p, { x: bx, z: bz }) < 30) {
                        tx = bx - dir * (p.slot % 2 === 0 ? 1.7 : 2.6);
                        tz = bz + (p.slot % 2 === 0 ? 1.5 : -1.5);
                    }
                    else {
                        const mark = marks.get(index);
                        if (mark) {
                            tx = tx * .18 + (mark.x - dir * 2.1) * .82;
                            tz = tz * .18 + mark.z * .82;
                        }
                    }
                }
                if (!holder) {
                    // Anticipate where the moving ball can be reached, not where it was last frame.
                    const chase = pressers[p.side].includes(p);
                    const reserved = index === this.intendedReceiver;
                    if (chase || reserved) {
                        const ballSpeed = Math.hypot(this.ballVelocity[0], this.ballVelocity[2]);
                        const t = bounds(distance(p, { x: bx, z: bz }) / (ballSpeed + 10), .08, .8);
                        const predicted = { x: bounds(bx + this.ballVelocity[0] * t * .75, -51, 51), z: bounds(bz + this.ballVelocity[2] * t * .75, -32, 32) };
                        const intercept = reserved && this.passTarget ? this.passTarget : predicted;
                        tx = intercept.x;
                        tz = intercept.z;
                    }
                }
            }
            // The intended receiver attacks the passing lane before the ball arrives.
            if (!hasBall && index === this.intendedReceiver && this.holder === null && this.passTarget) {
                tx = bounds(this.passTarget.x, -51, 51);
                tz = bounds(this.passTarget.z, -32, 32);
            }
            const dx = tx - p.x, dz = tz - p.z, L = len(dx, dz);
            const userSprint = isHuman && (this.held.has('ShiftLeft') || this.held.has('TouchSprint'));
            const aiSprint = !isHuman && p.stamina > 22 && p.slot !== 0 && (p.side === 0 || hasBall || Math.random() < .12 + this.aiLevel * .047) && ((hasBall && Math.min(...this.people.filter(o => o.side !== p.side && o.slot !== 0).map(o => distance(o, p))) > 3 && Math.abs(p.x * this.attackDir(p.side)) < 39)
                || (defending && pressers[p.side].includes(p) && distance(p, { x: bx, z: bz }) > 3 && distance(p, { x: bx, z: bz }) < 24)
                || (this.holder === null && (pressers[p.side].includes(p) || index === this.intendedReceiver) && distance(p, { x: bx, z: bz }) > 5));
            const sprint = (userSprint || aiSprint) && p.stamina > 4;
            const anticipating = index === this.intendedReceiver;
            const speed = (3.45 + p.card.pace * .052) * (p.side === 1 ? .90 + this.aiLevel * .009 : 1) * (sprint ? 1.43 : 1) * (hasBall ? .89 : 1) * (p.skillUntil > 0 ? 1.45 : 1) * (p.stamina < 22 ? .76 : 1) * (anticipating ? 1.12 : 1);
            const targetVX = L > .35 ? dx / L * speed : 0, targetVZ = L > .35 ? dz / L * speed : 0;
            const acceleration = (hasBall ? 13 : anticipating ? 22 : 16) * (aiSprint ? 1.13 : 1) * dt;
            p.vx += (targetVX - p.vx) * Math.min(1, acceleration);
            p.vz += (targetVZ - p.vz) * Math.min(1, acceleration);
            p.x = bounds(p.x + p.vx * dt, -51.2, 51.2);
            p.z = bounds(p.z + p.vz * dt, -32.4, 32.4);
            const realSpeed = Math.hypot(p.vx, p.vz);
            if (realSpeed > .15)
                p.face = Math.atan2(p.vz, p.vx);
            if (sprint)
                p.stamina = Math.max(0, p.stamina - (16 - p.card.stamina * .045) * dt * (.1 / .6));
            else
                p.stamina = Math.min(100, p.stamina + (realSpeed > 4 ? 1 : realSpeed > 1 ? 4.4 : 16) * dt);
            p.anim += realSpeed * dt * .92;
            // Only opposing AI defenders tackle automatically. Human teammates mark and press,
            // but stealing the ball requires a human E / Sprint-Tackle action.
            if (p.side === 1 && defending && holder && holder.slot !== 0 && distance(p, holder) < 3.25 && p.cooldown <= 0) {
                const quality = (p.card.defending * .65 + p.card.physical * .35) - (holder.card.dribbling * .7 + holder.card.physical * .3);
                const opportunity = Math.max(.008, (quality + 45) / 260) * dt * 8 * (.07 + Math.pow(this.aiLevel / 18, 1.5) * .88);
                if (Math.random() < opportunity) {
                    p.cooldown = 1.4 - this.aiLevel * .025;
                    this.statTackles[1]++;
                    if (Math.random() < .095) {
                        this.foul(1, holder.x, holder.z);
                        return;
                    }
                    this.playerActions[index].tackles++;
                    this.pokeAway(p, holder);
                    this.announce('OPPOSITION TACKLE', .8);
                }
            }
        }
        this.separatePlayers();
        if (this.holder !== null && this.people[this.holder].side === 1 && this.settings.autoSwitch) {
            const closest = this.people.slice(0, 11).filter(p => p.slot !== 0).sort((a, b) => distance(a, { x: bx, z: bz }) - distance(b, { x: bx, z: bz }))[0];
            if (closest && distance(closest, { x: bx, z: bz }) + 4 < distance(this.people[this.selected], { x: bx, z: bz }) && distance(this.people[this.selected], { x: bx, z: bz }) > 9)
                this.selected = closest.slot;
        }
    }
    separatePlayers() {
        // No player-to-player collision response: softly maintain personal space instead.
        const spacing = 1.48;
        for (let i = 0; i < this.people.length; i++)
            for (let j = i + 1; j < this.people.length; j++) {
                const a = this.people[i], b = this.people[j], dx = a.x - b.x, dz = a.z - b.z, d = Math.hypot(dx, dz);
                if (d >= spacing)
                    continue;
                const nx = d > .001 ? dx / d : Math.cos((i + j) * 2.4), nz = d > .001 ? dz / d : Math.sin((i + j) * 2.4);
                const overlap = (spacing - d) * .5;
                const aHolding = this.holder === i, bHolding = this.holder === j;
                const aPart = aHolding ? 0 : bHolding ? 2 : 1, bPart = bHolding ? 0 : aHolding ? 2 : 1;
                a.x = bounds(a.x + nx * overlap * aPart, -51.2, 51.2);
                a.z = bounds(a.z + nz * overlap * aPart, -32.4, 32.4);
                b.x = bounds(b.x - nx * overlap * bPart, -51.2, 51.2);
                b.z = bounds(b.z - nz * overlap * bPart, -32.4, 32.4);
            }
    }
}
