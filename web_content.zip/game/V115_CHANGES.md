# v115 - the ink cinematic replaces the look-around wake-up

`ink_intro.js` (your file) is wired in. New game only; loading a save is unchanged.

## Flow
1. When the world starts rendering behind the loader, the camera is **parked on its final view** (water-facing, eye-line) and `introActive` is on (input/HUD/weather stay locked as before). Chunks stream in around that exact view during the whole loader zoom.
2. At the loader's full-white beat, `startInkIntro()` runs `InkIntro`. Its opaque #f3fff5 overlay matches the flash, so the loader fades out unseen beneath it. This is about 1.1 s earlier than the old hand-off.
3. The intro asks for a capture; `serveInkCapture()` (called in `animate()` right after `composer.render()`, so no `preserveDrawingBuffer` is needed) waits until the chunks within 2 of the player have built and the apply queue is empty (6 stable frames), capped at 4 s, then hands over the real frame.
4. Ink draws, colour washes, dissolve to the live game, then `finishIntroSequence()` does what the old camera tail did: HUD ripple, "Waking Up" log, tutorial box.
Tap/click/key skips. Any failure hands off anyway.

## Fix inside ink_intro.js
`run()` set `this.fx = null`, and the proc state treated `fx === null` as "not enough edges", so the intro faded out immediately on its first frame, every time. Now it uses a `genDone` flag. This is the only change to your file.

## Verified / not verified
- Checked in headless Chromium with a synthetic beach frame: pulse, ink, wash, dissolve, onDone at about 15 s. Existing tests pass, `node --check` is clean.
- NOT run: the real game end to end. Software WebGL crashed the page here, so the capture timing and hand-off on a real GPU are unseen. Tune `CAPTURE_AT`, the 4 s cap, and `INK_CFG` timings after one real run.

## Ink look pass (all in ink_intro.js)
- **Draw order:** the longest flat contour (horizon / shoreline) is chosen as the main line and drawn first; the other contours follow nearest-to-it first, then outward; faint edges are delayed so the foreground fills in last.
- **Contour strokes:** the sharp-detail brush strokes now trace the real edges (local tangent walk over the drawn-edge mask) and start in the same order the ink was drawn, instead of landing at random. The wide colour washes tilt with the horizon angle.
- **Paper grain:** multiplied over the painted areas only, fading out before the dissolve.
- **Settle:** starts about 3.5% zoomed with a faint sway and eases to exactly 1.0 by the dissolve, so it lands on the live view with no jump.
- Knobs in `INK_CFG`: `DRIFT`, `GRAIN`, `CONTOUR_STROKES`. Set `DRIFT` and `GRAIN` to 0 to turn them off.
- Checked only on a synthetic beach frame (no errors, about 15 s); not yet seen on a real captured frame.

## Dreamy / painterly pass (v117, ink_intro.js)
- **Oil-paint copy:** a Kuwahara filter (half-res, integral images, done inside the analysis slices) gives flat painted patches with kept edges; 260 small dabs are painted from it, laid horizon-outward.
- **Dream tint:** lavender/rose soft-light tint baked into the underpainting (now softer, 1/9 res, lifted) and the dabs. The final wash is still the true frame, so the hand-off is unchanged.
- **Wet glow:** a soft screen-blend bloom around the painting while it is wet, gone before the dissolve.
- **Motes:** cool sparks lift off the pen tip as it draws, then slow warm specks drift up while colour goes on; all gone before the dissolve.
- **Canvas weave** added to the paper grain; the ink glow is unchanged.
- Knobs: `DABS`, `TINT`, `BLOOM`, `MOTES`, plus the earlier `GRAIN`, `DRIFT`, `CONTOUR_STROKES`. Not seen on a real game frame yet, and the Kuwahara cost on a phone is unmeasured (it runs in 9 ms slices while the screen is black).
