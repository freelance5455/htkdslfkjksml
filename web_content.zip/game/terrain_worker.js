// terrain_worker.js - one of a pool of workers that build terrain chunks (heights, colours, biome weights, river water
// surface, tree/grass scatter) off the main thread. See chunk_core.js. Protocol:
//   main -> worker: {type:'init', seed, sites}   (sites = valley city-state sites from valley_sites.js findSites, computed once on the main thread)
//   main -> worker: {type:'city', id, job:{siteId}} -> {type:'city', id, out}   (v45: whole city as instanced data)
//   main -> worker: {type:'road', id, job:{a,b}}  -> {type:'road', id, out}     (v45: road polyline between two cities)
//   main -> worker: {type:'terrain', id, job}   -> worker: {type:'terrain', id, out}
//   main -> worker: {type:'scatter', id, job}   -> worker: {type:'scatter', id, out}
import { ChunkBuilder } from './chunk_core.js';
let cb = null;
self.onmessage = (e) => {
    const m = e.data;
    try {
        if (m.type === 'init') { cb = new ChunkBuilder(m.seed, m.sites); self.postMessage({ type: 'ready' }); }
        else if (!cb) return;
        else if (m.type === 'terrain') { const r = cb.buildTerrain(m.job); self.postMessage({ type: 'terrain', id: m.id, out: r.out }, r.tr); }
        else if (m.type === 'scatter') { const r = cb.buildScatter(m.job); self.postMessage({ type: 'scatter', id: m.id, out: r.out }, r.tr); }
        else if (m.type === 'city') { const r = cb.buildCity(m.job); self.postMessage({ type: 'city', id: m.id, out: r.out }, r.tr); }
        else if (m.type === 'road') { const r = cb.buildRoad(m.job); self.postMessage({ type: 'road', id: m.id, out: r.out }, r.tr); }
        else if (m.type === 'forget') { cb.lattices.delete(m.key); }
    } catch (err) { self.postMessage({ type: 'error', id: m.id, message: String(err && err.stack || err) }); }
};
