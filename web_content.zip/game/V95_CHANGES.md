# v95 - painterly look + soft cel shading

Art direction: slight painterly style with soft cel shading, no hard outlines.

- **Soft cel shading** (game.js, next to the fog-ramp chunk patch): the sun/moon diffuse term is stepped into 4 broad bands with
  smoothstepped edges, then blended 72% toward the stepped value so slopes still read as round. It is patched once into
  `lights_physical_pars_fragment`, so terrain, props, cities, boat and player all get it. Only diffuse is banded; specular,
  hemisphere fill, shadows, fog and emissive crystals are untouched. Knobs: `NW_CEL_BANDS`, `NW_CEL_MIX`.
  If the three.js chunk text ever changes, it logs `[style] soft cel shading skipped` and the game renders as before.
- **Painterly pass** (new `PaintShader`, runs after OutputPass and before the colour grade): slow brush-wobble on sampling,
  8-tap edge-preserving blur, cool-violet shadows / warm highlights, faint fixed canvas grain. HUD is unaffected.
  Runtime control from the console: `nwPaint(0)` off, `nwPaint(0.8)` default, `nwPaint(1.3)` heavier.

Not yet verified on a GPU in this build environment (no three.js or network here), so check the first run for shader errors.

## v95 revision: less blur
Painterly blur radius 2.0 -> 1.1 px, brush wobble 2.6 -> 0.9 px, blur weights made much more edge-sensitive (70 -> 220),
45% of the original detail added back after blurring, overall mix 0.88 -> 0.80. The flat-patch look stays but edges stay crisp.
