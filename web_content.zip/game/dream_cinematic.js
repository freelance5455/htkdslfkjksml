// =====================================================================================================================
// v103 THE DREAM, REBUILT. A wordless dream the pilot has while drifting on the long water, between the wreck and the memorial.
// Painterly, real-time 3D: one full-screen raymarched fragment shader (own WebGL2 canvas, same overlay approach as the freefall
// cinematic) with brush-stroke wobble, pigment-pooled outlines, posterised washes and paper grain, now laid over a second
// layer: clean light-lines, holograms and grids. The old (wild, hand-made, unorganised) and the new (tidy, lit, sorted) sit in
// the same frame on purpose: the dreamer is the one who does not fit the tidy world, and the world that judged them was never
// the one they remember. First person, no HUD, no captions, no dialogue. The voices are synthesised (glottal source + formant
// filters + syllable rhythm): they sound like people talking in another room, but say nothing.
//
//   1 THE KITCHEN   warm light, a small person who turns and runs to you, a hand that finds yours; you walk to the window and the sun swallows it
//   2 THE GREEN     an untidy, ancient, wild dawn. The small person leads you on. Then a ring of light sweeps outward from you and
//                   tidies the world as it passes: trees straighten into pillars, ground becomes tile, stones become slabs, panels
//                   light up. You walk through all of it in one unbroken take and reach a gate
//   3 THE CORRIDOR  an archive at midnight, a clock that is wrong, a door that keeps backing away with the small figure in front of it
//   4 THE HEARING   a round hall of tall pale watchers with glowing faces under a ring of light; the small hand slips out of yours
//   5 THE DRIFT     the cabin of an unpowered shuttle: a photo, a page, a locket floating; a green and blue moon in the window,
//                   growing; the burn, the shake, the white
//   6 THE WATER     the hall is under the sea; the watchers wash away; the locket falls; light overhead and a small figure in it
//
// Every cut has its own way of changing, borrowed from how the freefall cinematic moves between shots: eyelids and focus pulls,
// a bloom that is the sun in the window, a glitch tear at the gate, a blink, a shattering, a plunge with streaks and a splash.
// Nothing pops: people step out of light or are drawn in by a scan line, hands rise in from below the frame, the world's
// new objects come up exactly where the wave of light is passing, and everything far away is simply further than the haze.
// Head bob is locked to the distance walked (one soft rise and fall per footstep) so it always agrees with the speed.
//
// v107 step 4b: the water ending (marine snow, the figure resolving in a halo of light). v107 step 4a: a more painterly paint (strokes follow the surface, each its own load of paint, dry brush, wet edges, pooled pigment, paper fibres and tooth). v107 step 3: the cuts carry their own light (lid-edge glow, sun streak + ghosts, glitch scan, shard fringe, plunge heat + splash ring). v107 step 2: per-scene light (steam, fireflies + glossy tile, rim lights, wet floors, caustics). v107: light in the air (window/moon/ring/surface shafts, floating dust, glow round every emissive, ground mist), filmic grade.
//
// Test it headless with tests/dream_harness.html + tests/dream_shots.py (renders any moment to a PNG).
// =====================================================================================================================

// ---- timeline (seconds) ----------------------------------------------------------------------------------------------
const SD = [26, 64, 24, 30, 28, 28];      // 1 kitchen, 2 the green (wild -> grid), 3 corridor, 4 hearing, 5 drift, 6 water
const SID = [0, 4, 1, 2, 5, 3];           // which picture (shader scene) each of them uses
const NS = SD.length, T_BLACK0 = 1.2, D_END = 5.0;
const T_IN = [3.6, 3.2, 1.5, 2.8, 3.4, 3.4], T_OUT = [3.4, 1.8, 2.0, 3.4, 4.6, 0];   // how long each scene's opening / closing change lasts
const TS = [], TE = [];
{ let t = T_BLACK0; for (const d of SD) { TS.push(t); TE.push(t + d); t += d; } }
const T_END = TE[NS - 1] + D_END;

const clamp01 = (x) => Math.max(0, Math.min(1, x));
const smooth = (a, b, x) => { const t = clamp01((x - a) / (b - a)); return t * t * (3 - 2 * t); };
const mix = (a, b, t) => a + (b - a) * t;
const eio = (k) => { k = clamp01(k); return k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2; };
const add3 = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
const mul3 = (a, s) => [a[0] * s, a[1] * s, a[2] * s];
const mix3 = (a, b, t) => [mix(a[0], b[0], t), mix(a[1], b[1], t), mix(a[2], b[2], t)];
const dot3 = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const cross3 = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const norm3 = (a) => { const l = Math.hypot(a[0], a[1], a[2]) || 1; return [a[0] / l, a[1] / l, a[2] / l]; };
const hash1 = (n) => { const x = Math.sin(n * 127.1) * 43758.5453123; return x - Math.floor(x); };
const wob = (t, s) => Math.sin(t * 1.3 * s) * 0.5 + Math.sin(t * 2.9 * s + 1.7) * 0.3 + Math.sin(t * 5.3 * s + 4.2) * 0.2;

// Camera basis: yaw 0 looks down -z; f = (sin y cos p, sin p, -cos y cos p)
function basis(yaw, pitch, roll) {
    const cy = Math.cos(yaw), sy = Math.sin(yaw), cp = Math.cos(pitch), sp = Math.sin(pitch);
    const f = [sy * cp, sp, -cy * cp];
    let r = norm3(cross3(f, [0, 1, 0]));
    let u = cross3(r, f);
    const cr = Math.cos(roll), sr = Math.sin(roll);
    return { f, r: add3(mul3(r, cr), mul3(u, sr)), u: add3(mul3(u, cr), mul3(r, -sr)) };
}

// ---- walking: one soft rise and fall of the head per footstep, locked to the distance actually walked ---------------------
// (v102 bobbed at a fixed 1.7-1.8 Hz and 2-3 cm whatever the speed, so a slow walk looked like a fast, jittery one.)
const STEP = 0.74;                                                      // metres per footstep
function bobOf(d, spd) {
    const k = smooth(0.04, 0.85, Math.abs(spd)), ph = Math.PI * d / STEP;       // ph advances pi per step
    return { y: Math.cos(2 * ph) * 0.0085 * k, x: Math.sin(ph) * 0.0065 * k, roll: Math.sin(ph) * 0.0017 * k, pitch: Math.cos(2 * ph) * 0.0016 * k, k };
}
const walkBob = (fn, lt) => bobOf(fn(lt), (fn(lt) - fn(lt - 0.12)) / 0.12);
const childBob = (d, spd) => Math.abs(Math.sin(Math.PI * d / 0.5)) * 0.04 * smooth(0.04, 0.5, Math.abs(spd));
const rampDist = (lt, v, ramp) => { if (lt <= 0) return 0; const u = lt / ramp; return lt < ramp ? v * ramp * (u * u * u - u * u * u * u * 0.5) : v * ramp * 0.5 + v * (lt - ramp); };
const KD = (l) => 2.85 * eio((l - 0.5) / 17.5) + 2.45 * smooth(21.5, 26.0, l);        // the kitchen: across the room, then on to the window
const CD = (l) => rampDist(l, 1.0, 1.6);                                              // the corridor
const HD = (l) => 2.6 * eio((l - 19) / 8.5);                                          // the hearing: the last steps
const W_WAVE0 = 22, W_WAVE_V = 5.2, W_END_SPD = 0.5;                                  // the green: when the ring of light leaves you, and how fast it travels (m/s)
const W_SP = (lt) => 1.02 * smooth(0, 4.5, lt) * (1 - W_END_SPD * smooth(54, 63, lt)) * (1 + 0.05 * Math.sin(lt * 0.35));
const W_TAB = (() => { const a = [0], dt = 0.05; for (let i = 1; i <= Math.ceil(SD[1] / dt) + 4; i++) a.push(a[i - 1] + 0.5 * (W_SP((i - 1) * dt) + W_SP(i * dt)) * dt); return a; })();
const WD = (lt) => { const x = Math.max(0, lt) / 0.05, i = Math.min(W_TAB.length - 2, Math.floor(x)); return W_TAB[i] + (W_TAB[i + 1] - W_TAB[i]) * (x - i); };
const GATE_Z = -(WD(SD[1]) + 0.2);                                                    // the gate stands where the walk ends
const pathH = (z) => 0.22 * Math.sin(z * 0.23 + 1.0) + 0.10 * Math.sin(z * 0.61);     // the ground along the path (the shader has the same function)
const orgAtJS = (d, lt) => { const R = Math.max(0, (lt - W_WAVE0) * W_WAVE_V); return 1 - smooth(R - 9, R, d); };   // how tidy the world is, d metres from you

// where the child's hand is when it is held out, and where it is when it is not
const S_CLOCKZ = -9.2;
const CHILD_ARM = [0.15, 1.02, 0.26];
const HALL_GAVEL = [18.6, 21.6, 26.6];

// ---- the choreography: everything the picture and the sound need, as a pure function of the clock ------------------------
function stateAt(t) {
    const S = { t, on: false, idx: 0, shot: 0, lt: 0, k: 0, pos: [0, 1.6, 0], f: [0, 0, -1], r: [1, 0, 0], u: [0, 1, 0], tanFov: 0.66,
        warp: 0, black: 1, white: 0, flash: 0, lean: 0, water: -5, dis: 0, light: 1, sq: 0,
        hA: [0, 0, 0], hB: [0, 0, 0], hOn: [0, 0], child: { on: 0, pos: [0, 0, 0], yaw: 0, s: 1, arm: 0 }, locket: [0, 0, 0, 0],
        doorZ: -10, clockZ: -9, hand2: 0, beat: 0, sub: 0,
        lid: 0, blur: 0, glitch: 0, shatter: 0, streak: 0, bubble: 0, heat: 0, sunB: 0, waveR: 0, orgSky: 0, gateZ: GATE_Z, moon: [0.06, 0.34, 0, 0], gd: [-0.26, -0.3, -1], org: 0 };
    if (t < 0 || t >= T_END) return S;
    let i = 0; for (let j = 0; j < NS; j++) if (t >= TS[j]) i = j;
    if (t < TS[0]) { S.black = 1; S.lid = 1; return S; }
    const lt = t - TS[i], dur = SD[i], k = lt / dur;
    S.on = true; S.idx = i; S.shot = SID[i]; S.lt = lt; S.k = k;
    const pin = clamp01(lt / T_IN[i]), pout = T_OUT[i] ? clamp01((lt - (dur - T_OUT[i])) / T_OUT[i]) : 0;
    let yaw = 0, pitch = 0, roll = 0, pos = [0, 1.6, 0], fov = 0.66;
    const nowA = (a, b) => smooth(a, b, lt);
    const lower = (v, bs, on) => add3(v, mul3(bs.u, -0.62 * (1 - on)));            // hands rise in from below the frame instead of appearing

    if (i === 0) {                                                   // ---------- the kitchen
        const z = 2.7 - KD(lt), bb = walkBob(KD, lt);
        pos = [0.25 - 0.18 * nowA(0.5, 18) + wob(lt, 0.3) * 0.02 + bb.x, 1.56 + bb.y + Math.sin(lt * 0.8) * 0.006, z];
        const toWin = nowA(22, 26);
        yaw = 0.05 + wob(lt, 0.35) * 0.05 - 0.55 * nowA(7.5, 9.5) * (1 - nowA(11, 13)) + 0.1 * nowA(12, 14) + 0.03 * toWin;
        pitch = -0.02 + wob(lt + 3, 0.3) * 0.02 + bb.pitch - 0.56 * nowA(15.5, 20.5) * (1 - nowA(21.4, 23.8)) + 0.03 * toWin;
        roll = wob(lt, 0.25) * 0.012 + bb.roll;
        S.light = 1; fov = 0.7 - 0.05 * nowA(16, 21) - 0.1 * nowA(23, 26);
        const run = nowA(13.6, 17.6), onward = nowA(21.5, 26.0);
        const cz = mix(-1.9, -0.85, eio(run)) - 2.45 * onward, cx = mix(0.08, 0.2, run);
        const cdf = (l) => 1.05 * eio(smooth(13.6, 17.6, l)) + 2.45 * smooth(21.5, 26.0, l), cdist = cdf(lt), cspd = (cdf(lt) - cdf(lt - 0.12)) / 0.12;
        S.child = { on: 1, pos: [cx, childBob(cdist, cspd), cz], yaw: 0, s: 1, arm: nowA(16.5, 18.4) };
        // faces away at first, turns round to you, and once it has your hand turns to the window with you
        const faceYaw = Math.atan2(pos[0] - cx, pos[2] - cz);
        S.child.yaw = mix(mix(Math.PI + 0.1, faceYaw, eio(nowA(4.6, 8.0))), Math.PI, eio(nowA(21.3, 23.6)));
        const cp = S.child.pos, c = Math.cos(S.child.yaw), s = Math.sin(S.child.yaw);
        const ax = CHILD_ARM[0], az = CHILD_ARM[2];
        S.hB = [cp[0] + ax * c + az * s, cp[1] + CHILD_ARM[1], cp[2] - ax * s + az * c];
        const bs = basis(yaw, pitch, roll);
        const rest = add3(add3(pos, mul3(bs.f, 0.5)), add3(mul3(bs.r, 0.22), mul3(bs.u, -0.36)));
        const meet = nowA(18.2, 21.6), hOnA = nowA(17.6, 18.6);
        S.hA = lower(mix3(rest, S.hB, eio(meet) * 0.93), bs, hOnA);
        S.hB = lower(S.hB, bs, nowA(16.7, 17.7));
        S.hOn = [hOnA > 0.001 ? 1 : 0, 1];
    } else if (i === 1) {                                            // ---------- the green: wild, then tidied by a ring of light, one unbroken walk
        const d = WD(lt), spd = (d - WD(lt - 0.12)) / 0.12, bb = bobOf(d, spd);
        const meander = 0.55 * Math.sin(d * 0.085) * (1 - nowA(40, 58));
        pos = [meander + bb.x, 1.62 + pathH(-d) * (1 - orgAtJS(1.7, lt)) + bb.y, -d];
        const g1 = nowA(8.2, 10.2) * (1 - nowA(13, 15)), g2 = nowA(17, 19.5) * (1 - nowA(22, 24.5));
        const g3 = nowA(31, 33.5) * (1 - nowA(37, 39.5)), g4 = nowA(43, 45.5) * (1 - nowA(49.5, 52)), end = nowA(53, 62);
        const calm = 1 - end;
        yaw = wob(lt, 0.3) * 0.035 + calm * (-0.62 * g1 + 0.42 * g3 + 0.28 * g4);
        pitch = -0.015 + wob(lt + 3, 0.3) * 0.02 + bb.pitch + calm * (0.5 * g2 + 0.12 * g3 + 0.55 * g4) + 0.05 * end;
        roll = wob(lt, 0.2) * 0.01 + bb.roll;
        fov = 0.72 + 0.04 * g4 - 0.04 * end;
        S.light = 1; S.waveR = Math.max(0, (lt - W_WAVE0) * W_WAVE_V); S.orgSky = nowA(26, 46); S.org = orgAtJS(1.7, lt);
        // the small person: runs ahead along the path, points out the old tree and the sky, and waits for you in the gate
        const lead = 2.4 + 0.5 * Math.sin(lt * 0.21) - 1.3 * nowA(50, 62);
        const cd = d + lead, cspd = spd;
        const cxw = (0.5 + 0.55 * Math.sin(lt * 0.37)) * (1 - nowA(50, 60)), czw = -cd;
        const stand = eio(nowA(54, 60));
        const cx = mix(cxw, 0.0, stand), cz = mix(czw, GATE_Z - 0.1, stand);
        const gy = pathH(cz) * (1 - orgAtJS(Math.abs(cz + d), lt));
        S.child = { on: 1, pos: [cx, gy + childBob(cd, cspd) * (1 - stand), cz], yaw: Math.PI + 0.25 * Math.sin(lt * 0.5) * (1 - stand), s: 1, arm: 0 };
        const toYou = Math.atan2(pos[0] - cx, pos[2] - cz);
        S.child.yaw = mix(S.child.yaw, toYou, eio(nowA(56, 60)));
        const point = nowA(9.0, 10.4) * (1 - nowA(13.2, 14.6)) + nowA(43.6, 45.0) * (1 - nowA(49.2, 50.6));
        S.child.arm = point;
        const sideDir = lt < 30 ? -1 : 0.5, upDir = lt < 30 ? 0.15 : 0.75;
        S.hB = [cx + sideDir * 0.5, S.child.pos[1] + 0.5 + upDir * 0.6, cz - 0.08]; S.hOn = [0, point > 0.002 ? 1 : 0];
        S.hB = lower(S.hB, basis(yaw, pitch, roll), point);
    } else if (i === 2) {                                            // ---------- the corridor
        const z = -CD(lt), bb = walkBob(CD, lt);
        pos = [wob(lt, 0.4) * 0.03 + bb.x, 1.6 + bb.y, z];
        const gz = nowA(3.4, 5.4) * (1 - nowA(10.4, 12.6)), distC = Math.max(0.9, z - S_CLOCKZ);
        const yawC = Math.min(1.2, Math.atan2(1.7, distC)), pitC = Math.min(0.36, Math.atan2(1.1, distC));
        yaw = wob(lt + 1, 0.3) * 0.04 + yawC * gz - 0.05 * nowA(14, 20);
        pitch = 0.02 + wob(lt + 5, 0.3) * 0.02 + bb.pitch + pitC * gz - 0.06 * nowA(15, 22);
        roll = wob(lt, 0.2) * 0.02 + 0.03 * nowA(12, 22) + bb.roll;
        fov = 0.68 + 0.08 * nowA(10, 22);
        S.doorZ = z - (13 + 0.62 * lt + 2.5 * nowA(12, 22)); S.clockZ = -9.2;
        S.child = { on: 1, pos: [0.0, 0, S.doorZ + 0.9], yaw: 0, s: 1, arm: 0 };
        S.light = 1; S.beat = nowA(10, 22);
    } else if (i === 3) {                                            // ---------- the hearing
        const bb = walkBob(HD, lt), walk = HD(lt);
        pos = [wob(lt, 0.3) * 0.03 + bb.x, 1.62 + Math.sin(lt * 0.9) * 0.008 + bb.y, walk];
        const sweep = nowA(0.2, 3.8), up = Math.sin(Math.PI * nowA(0.4, 3.4));
        yaw = Math.PI + 0.8 * Math.sin(2 * Math.PI * sweep) + wob(lt, 0.4) * 0.02;
        pitch = 0.04 + 0.3 * up - 0.3 * nowA(10.2, 11.6) * (1 - nowA(13.4, 15.2)) + 0.03 * wob(lt + 2, 0.5) + bb.pitch;
        roll = wob(lt, 0.2) * 0.014 + bb.roll;
        fov = 0.74 - 0.06 * nowA(12, 20);
        S.lean = eio(nowA(2, 17)) * 0.8 + 0.2 * nowA(17, 25);
        let fl = 0; for (const g of HALL_GAVEL) if (lt >= g) fl = Math.max(fl, Math.exp(-(lt - g) * 3.2));
        S.flash = fl; S.light = 1 - 0.97 * nowA(HALL_GAVEL[2], HALL_GAVEL[2] + 2.0);
        // the child steps out of the white door at the end of the aisle, walks up to you, takes your hand, and is drawn away again
        const walkIn = eio(nowA(3.6, 10.2)), away = eio(nowA(13.8, 26.6));
        const cz2 = 16.5 - 15.5 * walkIn + 15.7 * away, appear = nowA(3.0, 5.6);
        const cdf = (l) => 15.5 * eio(smooth(3.6, 10.2, l)) + 15.7 * eio(smooth(13.8, 26.6, l)), cdist = cdf(lt), cspd = (cdf(lt) - cdf(lt - 0.12)) / 0.12;
        S.child = { on: appear, pos: [0.0, childBob(cdist * 0.55, cspd * 0.55), cz2], yaw: 0, s: 1, arm: nowA(8.8, 10.4) };
        S.child.yaw = Math.atan2(pos[0], pos[2] - cz2);
        const toCam = norm3([pos[0], 0, pos[2] - cz2]);
        S.hB = [toCam[0] * 0.42, 0.78 + S.child.pos[1], cz2 + toCam[2] * 0.42];
        const bs = basis(yaw, pitch, roll), slip = eio(nowA(13.8, 18.5));
        const home = add3(add3(pos, mul3(bs.f, 0.62)), add3(mul3(bs.r, 0.08), mul3(bs.u, -0.16)));
        S.hA = lower(mix3(add3(S.hB, [-0.05, 0.01, -0.04]), add3(home, mul3(bs.f, 0.16 * slip)), nowA(14.5, 19)), bs, nowA(9.4, 10.8));
        S.hB = lower(S.hB, bs, nowA(8.8, 9.6) );
        S.hOn = [1, 1];
    } else if (i === 4) {                                            // ---------- the drift
        const pl = pout, shk = 0.004 + 0.05 * pl * pl;
        pos = [wob(lt, 0.2) * 0.02 + shk * Math.sin(t * 47) * 0.5, 1.4 + Math.sin(lt * 0.5) * 0.012 + shk * Math.sin(t * 61 + 1.0), 0.3];
        const gp = nowA(5.0, 7.8) * (1 - nowA(10.5, 13)), gd = nowA(13, 16) * (1 - nowA(18.5, 21)), gh = nowA(1.9, 3.4) * (1 - nowA(5.2, 6.8));
        yaw = wob(lt, 0.25) * 0.03 - 0.62 * gp + 0.55 * gd + 0.0;
        pitch = 0.04 + wob(lt + 3, 0.25) * 0.02 + 0.08 * gp + 0.1 * gd - 0.34 * gh;
        roll = wob(lt, 0.18) * 0.02 + shk * Math.sin(t * 53 + 2.0) * 1.6;
        fov = 0.7 - 0.05 * pl;
        S.light = 1;
        const bs = basis(yaw, pitch, roll), L0 = [0.2, 1.02, 0.1];
        const rise = nowA(1.9, 3.4), drop = nowA(6.0, 7.8);
        S.hA = lower(add3(L0, [0.0, -0.075, 0.03]), bs, rise); S.hA = add3(S.hA, mul3(bs.u, -0.6 * drop));
        S.hOn = [rise > 0.001 && drop < 0.999 ? 1 : 0, 0];
        const lp = mix3(L0, [0.34, 1.55, -0.45], eio(nowA(6.2, 19))), fl = eio(nowA(6.2, 19));
        S.locket = [lp[0] + Math.sin(lt * 0.7) * 0.05 * fl, lp[1] + Math.sin(lt * 0.5) * 0.03 * fl, lp[2], 1];
        // v104: the freefall, backwards. The giant (the same planet, the same sky) starts as a curved wall of cloud right under the canopy and falls away
        // behind the ship; the moon comes up out of the dark ahead and, in the last seconds, fills the glass.
        const gA = 0.3 + 0.9 * Math.exp(-lt / 6.5), ge = 0.45 - 0.17 * smooth(0, 16, lt) - gA;     // angular radius of the giant, and its centre's elevation (the limb stays near the top of the window)
        S.gd = norm3([-0.26 * Math.cos(ge), Math.sin(ge), -Math.cos(ge)]);
        S.moon = [0.03 + 0.07 * smooth(2, 21, lt) + 1.2 * Math.pow(pl, 2.4), gA, 0.2 * smooth(0, 23, lt), 0.06 * Math.sin(lt * 0.17) + 0.4 * pl * pl];
        S.heat = smooth(0.12, 0.75, pl); S.streak = smooth(0.35, 1.0, pl);
    } else {                                                         // ---------- the water
        const wl = mix(5.4, 9.3, eio(nowA(0, 21.5)));
        S.water = wl; S.dis = nowA(1.0, 15); S.sq = nowA(10, 24); S.lean = 0.7 + 0.2 * nowA(0, 5);
        const climb = Math.max(0, wl - 1.9 - 1.62);
        const drift = eio(nowA(7, 21));
        pos = [-1.6 * drift + wob(lt, 0.3) * 0.05, 1.62 + climb + Math.sin(lt * 0.9) * 0.02, wob(lt + 8, 0.25) * 0.05];
        pos[1] = Math.min(pos[1], 7.5);
        yaw = 0.2 + 0.5 * nowA(0, 14) + wob(lt, 0.3) * 0.03;
        pitch = 0.02 + 0.9 * eio(nowA(5.5, 16)) + 0.04 * wob(lt, 0.4);
        // in the last part the eyes find the small figure on the surface
        const look = eio(nowA(13.5, 21)), cx = 0.05, cy = wl + 0.25;
        const tyaw = Math.atan2(cx - pos[0], -(0 - pos[2])), tpit = Math.atan2(cy - pos[1], Math.hypot(cx - pos[0], 0 - pos[2]));
        yaw = mix(yaw, tyaw, look); pitch = mix(pitch, tpit, look);
        roll = wob(lt, 0.2) * 0.02;
        fov = 0.74 - 0.08 * nowA(14, 24);
        S.light = 1;
        // the locket: it never left you. It starts at your open hand, then it falls away
        const bs0 = basis(0.2, 0.02, 0);
        const camY0 = 1.62 + Math.max(0, wl - 1.9 - 1.62);
        const lp0 = add3(add3([0, 1.62 + Math.max(0, 5.4 - 3.52), 0], mul3(bs0.f, 0.6)), add3(mul3(bs0.r, 0.22), [0, -0.2, 0]));
        const fall = Math.max(0, lt - 0.8);
        S.locket = [lp0[0] + Math.sin(lt * 1.3) * 0.06, lp0[1] - 0.45 * fall - 0.05 * Math.pow(fall, 1.3), lp0[2], 1 - smooth(14, 17, lt)];
        void camY0;
        // the small figure comes down out of the light: scan-line in, scale up, then it stands in the opening and reaches
        const reach = nowA(17.0, 22), come = nowA(13.0, 17.0);
        S.child = { on: nowA(13.2, 16.4), pos: [cx, wl - 1.0 + 2.2 * (1 - eio(come)), 0.0], yaw: 0, s: 1.45, arm: reach };
        S.child.yaw = Math.atan2(pos[0] - cx, pos[2] - 0.0);
        const toCam = norm3([pos[0] - cx, 0, pos[2]]);
        S.hB = [cx + toCam[0] * 0.3, wl - 0.95 - 0.35 * (1 - reach), toCam[2] * 0.3];
        const bs = basis(yaw, pitch, roll);
        const A0 = add3(add3(pos, mul3(bs.f, 0.55)), add3(mul3(bs.r, 0.14), mul3(bs.u, -0.12)));
        S.hA = lower(mix3(A0, S.hB, eio(nowA(21.0, 25.2)) * 0.92), bs, nowA(19.0, 20.6));
        S.hB = lower(S.hB, bs, reach);
        S.hOn = [nowA(19.0, 20.6) > 0.001 ? 1 : 0, reach > 0.001 ? 1 : 0];
        S.white = nowA(24.8, 27.8);
    }
    const bs2 = basis(yaw, pitch, roll);
    S.pos = pos; S.f = bs2.f; S.r = bs2.r; S.u = bs2.u; S.tanFov = fov;

    // ---- the cuts. Each one is different, and each is made from what is in the picture --------------------------------------------
    S.black = 0;
    if (i === 0) {          // in: eyes open from sleep (a half-open, a blink, then open) with a focus pull. Out: the sun in the window blooms and takes the room
        const open = 0.55 * smooth(0, 0.3, pin) - 0.42 * Math.sin(Math.PI * clamp01((pin - 0.42) / 0.16)) + 0.45 * smooth(0.6, 1, pin);
        S.lid = 1 - clamp01(open); S.blur = 7 * Math.pow(1 - smooth(0.1, 1, pin), 1.5); S.black = 1 - smooth(0, 0.12, pin);
        S.sunB = smooth(0.1, 1, pout); S.white = smooth(0.5, 1, pout);
    } else if (i === 1) {   // in: the white thins out and the same sun is straight ahead (match on the sun). Out: a glitch tears through the gate
        S.white = 1 - smooth(0, 0.9, pin); S.sunB = 1 - smooth(0, 0.8, pin); S.blur = 5 * Math.pow(1 - smooth(0, 1, pin), 2);
        S.glitch = Math.pow(pout, 1.4); S.white = Math.max(S.white, smooth(0.84, 0.95, pout) * 0.75); S.black = smooth(0.94, 1.0, pout);
    } else if (i === 2) {   // in: the glitch resolves into the corridor, a block at a time. Out: a slow blink, the lids come down and the picture goes soft
        S.glitch = Math.pow(1 - pin, 2); S.black = 1 - smooth(0, 0.25, pin);
        S.lid = smooth(0, 0.92, pout); S.blur = 6 * pout; S.black = Math.max(S.black, smooth(0.93, 1.0, pout));
    } else if (i === 3) {   // in: lids lift slowly, focus comes back. Out: the third blow; white, shards, and the shards go dark one by one
        S.lid = 1 - smooth(0.04, 1, pin); S.blur = 6 * Math.pow(1 - pin, 1.5);
        S.shatter = pout; S.white = Math.exp(-pout * 9) * 0.85 * (pout > 0 ? 1 : 0); S.black = smooth(0.78, 1.0, pout);
    } else if (i === 4) {   // in: out of the dark, eyes adjusting. Out: the plunge. Heat on the glass, streaks, the shake, a flash
        S.black = Math.pow(1 - smooth(0, 0.8, pin), 1.4); S.blur = 4 * (1 - pin) * (1 - pin);
        S.white = smooth(0.9, 1.0, pout);
    } else {                // in: the white falls away into water, bubbles lift past, focus comes back. End: bright, then nothing
        S.white = Math.max(S.white, 1 - smooth(0, 0.45, pin)); S.bubble = 1 - smooth(0.2, 1, pin); S.blur = 7 * Math.pow(1 - smooth(0, 1, pin), 1.5);
        S.black = smooth(dur, dur + 2.4, lt);
    }
    return S;
}

// ---- the painting: one raymarched fragment shader for all four scenes -------------------------------------------------------
const VERT = `#version 300 es
void main() { vec2 p = vec2((gl_VertexID << 1) & 2, gl_VertexID & 2); gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0); }`;

const FRAG = `#version 300 es
precision highp float;
out vec4 oc;
uniform vec2 uRes; uniform float uTime, uLT, uK, uTanFov, uWarp, uBlack, uWhite, uFlash, uLean, uWater, uDis, uLight, uSq, uDoorZ, uClockZ, uBeat;
uniform float uWaveR, uOrgSky, uLid, uGlitch, uShatter, uStreak, uBubble, uHeat, uSunB, uGateZ, uSkyYaw, uSkyRoll;
uniform vec2 uMoon;
uniform vec3 uGD;
uniform int uShot;
uniform vec3 uCam, uF, uR, uU, uHandA, uHandB, uChildPos;
uniform vec2 uHandOn;
uniform vec4 uChild;      // x yaw, y scale, z arm, w on
uniform vec4 uLocket;     // xyz position, w on

float h31(vec3 p) { p = fract(p * 0.1031); p += dot(p, p.zyx + 31.32); return fract((p.x + p.y) * p.z); }
float vn(vec3 p) { vec3 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f);
    return mix(mix(mix(h31(i), h31(i + vec3(1,0,0)), f.x), mix(h31(i + vec3(0,1,0)), h31(i + vec3(1,1,0)), f.x), f.y),
               mix(mix(h31(i + vec3(0,0,1)), h31(i + vec3(1,0,1)), f.x), mix(h31(i + vec3(0,1,1)), h31(i + vec3(1,1,1)), f.x), f.y), f.z); }
float fbm(vec3 p) { return 0.5 * vn(p) + 0.25 * vn(p * 2.03 + 7.1) + 0.125 * vn(p * 4.1 + 3.3); }

float sdBox(vec3 p, vec3 b) { vec3 q = abs(p) - b; return length(max(q, 0.0)) + min(max(q.x, max(q.y, q.z)), 0.0); }
float sdCap(vec3 p, vec3 a, vec3 b, float r) { vec3 pa = p - a, ba = b - a; float h = clamp(dot(pa, ba) / dot(ba, ba), 0.0, 1.0); return length(pa - ba * h) - r; }
float sdRC(vec3 p, float r1, float r2, float h) {
    vec2 q = vec2(length(p.xz), p.y); float b = (r1 - r2) / h; float a = sqrt(1.0 - b * b); float k = dot(q, vec2(-b, a));
    if (k < 0.0) return length(q) - r1; if (k > a * h) return length(q - vec2(0.0, h)) - r2; return dot(q, vec2(a, b)) - r1; }
float smin(float a, float b, float k) { float h = max(k - abs(a - b), 0.0) / k; return min(a, b) - h * h * k * 0.25; }
vec2 opU(vec2 a, vec2 b) { return a.x < b.x ? a : b; }
mat2 rot(float a) { float c = cos(a), s = sin(a); return mat2(c, -s, s, c); }

// ---- people and hands -------------------------------------------------------------------------------------------------
vec2 child(vec3 p) {
    if (uChild.w < 0.01) return vec2(1e5, 0.0);
    float e = smoothstep(0.0, 1.0, uChild.w);                              // 0..1: how much of the child is there
    vec3 q = p - uChildPos; float s = uChild.y * (0.55 + 0.45 * e);
    float bound = length(q) - 1.9 * s - 0.5;
    if (bound > 0.4) return vec2(bound, 7.0);
    mat2 R = rot(uChild.x);
    vec3 hb = uHandB - uChildPos; hb.xz = hb.xz * R; hb /= s;       // world hand into the child's frame (inverse turn)
    q.xz = q.xz * R; q /= s;
    float d = sdRC(q, 0.19, 0.1, 0.62);
    d = smin(d, length(q - vec3(0.0, 0.82, 0.0)) - 0.135, 0.07);
    d = min(d, sdCap(q, vec3(-0.06, 0.18, 0.0), vec3(-0.065, 0.0, 0.02), 0.034));
    d = min(d, sdCap(q, vec3(0.06, 0.18, 0.0), vec3(0.065, 0.0, 0.0), 0.034));
    d = smin(d, sdCap(q, vec3(-0.12, 0.6, 0.0), vec3(-0.17, 0.3, 0.02), 0.03), 0.05);
    vec3 tip = mix(vec3(0.17, 0.3, 0.02), hb, uChild.z);
    d = smin(d, sdCap(q, vec3(0.12, 0.6, 0.0), tip, 0.03), 0.05);
    // it arrives the way things arrive in a dream with a machine in it: a bright scan line climbs the body, solid below it, nothing above
    float front = e * 1.55 - 0.3;
    float cut = q.y - front + (1.0 - smoothstep(0.8, 1.0, e)) * 0.35 * vn(q * 7.0 + 3.0);
    float dd = max(d * s, cut * 0.12);
    return vec2(dd, (e < 0.999 && cut > -0.14) ? 11.0 : 7.0);
}
float sdHand(vec3 p, vec3 c, float s, float flip, float on) {
    vec3 d = p - c;
    float bd = length(d) - 0.17 * s;
    if (on < 0.01) return 1e5;
    if (bd > 0.05) return bd;
    vec3 q = vec3(dot(d, uR), dot(d, uU), dot(d, uF) * flip) / s;
    float h = (length(q / vec3(0.052, 0.017, 0.058)) - 1.0) * 0.017;
    float f = sdCap(q, vec3(-0.032, 0.0, 0.04), vec3(-0.037, 0.003, 0.108), 0.0095);
    f = min(f, sdCap(q, vec3(-0.011, 0.0, 0.045), vec3(-0.012, 0.004, 0.122), 0.01));
    f = min(f, sdCap(q, vec3(0.011, 0.0, 0.045), vec3(0.013, 0.004, 0.117), 0.0098));
    f = min(f, sdCap(q, vec3(0.032, 0.0, 0.04), vec3(0.038, 0.003, 0.100), 0.009));
    float th = sdCap(q, vec3(0.042, -0.004, 0.0), vec3(0.078, 0.002, 0.05), 0.0108);
    return smin(smin(h, f, 0.014), th, 0.014) * s;
}
vec2 locket(vec3 p) {
    if (uLocket.w < 0.01) return vec2(1e5, 0.0);
    float sc = smoothstep(0.0, 1.0, uLocket.w);
    vec3 q = (p - uLocket.xyz) / max(sc, 0.05);
    if (length(q) > 0.5) return vec2((length(q) - 0.45) * sc, 9.0);
    q.xz = q.xz * rot(uTime * 0.9);
    q.yz = q.yz * rot(0.5 + sin(uTime * 0.7) * 0.25);
    float d = max(length(q.xy) - 0.065, abs(q.z) - 0.012);
    d = min(d, sdCap(q, vec3(0.0, 0.06, 0.0), vec3(0.03, 0.2, 0.0), 0.004));
    d = min(d, sdCap(q, vec3(0.0, 0.06, 0.0), vec3(-0.03, 0.2, 0.0), 0.004));
    d = min(d, sdCap(q, vec3(0.03, 0.2, 0.0), vec3(0.0, 0.34, 0.01), 0.004));
    d = min(d, sdCap(q, vec3(-0.03, 0.2, 0.0), vec3(0.0, 0.34, -0.01), 0.004));
    return vec2(d * sc, 9.0);
}

// ---- scene 1: the kitchen ---------------------------------------------------------------------------------------------
vec2 map1(vec3 p) {
    float inner = sdBox(p - vec3(0.0, 1.6, 0.0), vec3(3.4, 1.6, 3.4));
    float shell = max(-inner, inner - 0.4);
    float win = sdBox(p - vec3(0.0, 1.55, -3.6), vec3(1.45, 1.05, 0.6));
    vec2 r = vec2(max(shell, -win), 1.0);
    r = opU(r, vec2(p.z + 7.0, 4.0));                                   // the evening outside the window
    // table, chairs, cup, blocks, rug, lanterns
    vec3 t = p - vec3(-1.7, 0.0, -0.5);
    float tab = sdBox(t - vec3(0.0, 0.66, 0.0), vec3(0.85, 0.035, 0.5)) - 0.01;
    tab = min(tab, sdCap(t, vec3(-0.75, 0.0, -0.4), vec3(-0.75, 0.65, -0.4), 0.035));
    tab = min(tab, sdCap(t, vec3(0.75, 0.0, -0.4), vec3(0.75, 0.65, -0.4), 0.035));
    tab = min(tab, sdCap(t, vec3(-0.75, 0.0, 0.4), vec3(-0.75, 0.65, 0.4), 0.035));
    tab = min(tab, sdCap(t, vec3(0.75, 0.0, 0.4), vec3(0.75, 0.65, 0.4), 0.035));
    r = opU(r, vec2(tab, 2.0));
    vec3 c1 = p - vec3(-1.7, 0.0, 0.55);
    float ch = sdBox(c1 - vec3(0.0, 0.42, 0.0), vec3(0.24, 0.025, 0.24));
    ch = min(ch, sdBox(c1 - vec3(0.0, 0.8, 0.24), vec3(0.24, 0.3, 0.02)));
    ch = min(ch, sdCap(c1, vec3(-0.2, 0.0, -0.2), vec3(-0.2, 0.42, -0.2), 0.02));
    ch = min(ch, sdCap(c1, vec3(0.2, 0.0, -0.2), vec3(0.2, 0.42, -0.2), 0.02));
    ch = min(ch, sdCap(c1, vec3(-0.2, 0.0, 0.2), vec3(-0.2, 0.42, 0.2), 0.02));
    ch = min(ch, sdCap(c1, vec3(0.2, 0.0, 0.2), vec3(0.2, 0.42, 0.2), 0.02));
    r = opU(r, vec2(ch, 2.0));
    vec3 c2 = p - vec3(-0.75, 0.0, -0.55); c2.xz = c2.xz * rot(0.5);
    float ch2 = sdBox(c2 - vec3(0.0, 0.42, 0.0), vec3(0.24, 0.025, 0.24));
    ch2 = min(ch2, sdBox(c2 - vec3(0.0, 0.8, -0.24), vec3(0.24, 0.3, 0.02)));
    ch2 = min(ch2, sdCap(c2, vec3(-0.2, 0.0, -0.2), vec3(-0.2, 0.42, -0.2), 0.02));
    ch2 = min(ch2, sdCap(c2, vec3(0.2, 0.0, 0.2), vec3(0.2, 0.42, 0.2), 0.02));
    r = opU(r, vec2(ch2, 2.0));
    float cup = max(length(t.xz - vec2(0.2, 0.1)) - 0.045, abs(t.y - 0.74) - 0.04);
    r = opU(r, vec2(cup, 6.0));
    float bl = sdBox(p - vec3(0.7, 0.07, -0.75), vec3(0.07)) - 0.005;
    bl = min(bl, sdBox((p - vec3(0.84, 0.06, -0.62)).xyz, vec3(0.06)) - 0.005);
    bl = min(bl, sdBox(p - vec3(0.74, 0.19, -0.74), vec3(0.06)) - 0.005);
    r = opU(r, vec2(bl, 6.0));
    float rug = max(length((p.xz - vec2(0.1, -0.6)) * vec2(0.8, 1.0)) - 1.7, abs(p.y - 0.012) - 0.012);
    r = opU(r, vec2(rug, 5.0));
    for (int i = 0; i < 4; i++) {
        float fi = float(i);
        vec3 lp = vec3(-1.7 + fi * 1.15, 2.55 - 0.12 * sin(fi * 2.1), -1.9 + 0.5 * sin(fi * 1.7));
        float l = length(p - lp) - 0.11;
        r = opU(r, vec2(l, 4.0));
        r = opU(r, vec2(sdCap(p, lp, vec3(lp.x, 3.2, lp.z), 0.004), 1.0));
        r = opU(r, vec2(length(vec2(length((p - lp).xz) - 0.17, p.y - lp.y)) - 0.006, 12.0));                  // a ring of light round each lantern
    }
    // a small hologram of the moon above the table (three slow rings and a core), a lit panel on the wall, a drone that hovers in the corner
    vec3 g = p - vec3(-1.5, 1.2 + 0.03 * sin(uTime * 0.9), -0.5);
    float gr;
    if (length(g) < 0.4) {
        vec3 g1 = g; g1.xz = g1.xz * rot(uTime * 0.5);
        gr = length(vec2(length(g1.xz) - 0.2, g1.y)) - 0.0055;
        vec3 g2 = g1; g2.yz = g2.yz * rot(1.5708); gr = min(gr, length(vec2(length(g2.xz) - 0.2, g2.y)) - 0.0055);
        vec3 g3 = g1; g3.xy = g3.xy * rot(0.8); gr = min(gr, length(vec2(length(g3.xz) - 0.2, g3.y)) - 0.0055);
        gr = min(gr, length(g) - 0.035);
    } else gr = length(g) - 0.38;
    r = opU(r, vec2(gr, 12.0));
    r = opU(r, vec2(sdBox(p - vec3(3.375, 1.5, -0.9), vec3(0.012, 0.45, 0.7)), 12.0));
    vec3 dq = p - vec3(1.9 + 0.25 * sin(uTime * 0.4), 2.3 + 0.08 * sin(uTime * 0.9), -1.3 + 0.3 * cos(uTime * 0.4));
    r = opU(r, vec2(length(dq) - 0.1, 6.0));
    r = opU(r, vec2(length(vec2(length(dq.xz) - 0.15, dq.y)) - 0.006, 12.0));
    return r;
}

// ---- scene 2: the corridor --------------------------------------------------------------------------------------------
vec2 map2(vec3 p) {
    float w = min(2.2 - abs(p.x), 4.6 - p.y);
    float endw = max(p.z - (uDoorZ - 1.0), (uDoorZ - 1.5) - p.z);        // the end wall, a thin slab
    float door = sdBox(p - vec3(0.0, 1.15, uDoorZ - 1.25), vec3(0.62, 1.15, 0.6));
    float cell = mod(p.z + 0.9, 1.8) - 0.9;
    float sh = 1e5, cry = 1e5;
    for (int s = 0; s < 2; s++) {
        float sx = s == 0 ? -1.0 : 1.0;
        vec3 q = vec3(p.x * sx - 1.98, p.y - 1.7, cell);
        float body = sdBox(q, vec3(0.2, 1.7, 0.72));
        float cy = mod(p.y + 0.14, 0.56) - 0.28;
        float slot = sdBox(vec3(q.x + 0.12, cy, q.z), vec3(0.14, 0.2, 0.62));
        sh = min(sh, max(body, -slot));
        float slotId = floor((p.y + 0.14) / 0.56) + 7.0 * floor((p.z + 0.9) / 1.8) + 31.0 * float(s);
        if (h31(vec3(slotId, 3.0, 1.0)) > 0.35) cry = min(cry, sdBox(vec3(q.x + 0.1, cy, q.z), vec3(0.03, 0.035, 0.16)));   // a data crystal glowing in the slot
    }
    float rib = sdBox(vec3(p.x, p.y - 4.35, mod(p.z + 1.8, 3.6) - 1.8), vec3(2.3, 0.28, 0.12));
    vec2 r = vec2(w, 1.0);
    r.x = min(r.x, p.y);                                                // floor and ceiling and walls
    float inside = min(r.x, endw);
    r = vec2(inside, 1.0);
    r.x = max(r.x, -door);
    r = opU(r, vec2(sh, 2.0));
    r = opU(r, vec2(cry, 12.0)); r = opU(r, vec2(rib, 1.0));
    r = opU(r, vec2(p.z - (uDoorZ - 4.5), 4.0));                         // the light behind the door
    // the clock on the right wall
    vec3 q = p - vec3(1.7, 2.7, uClockZ);
    float cl = max(length(q.yz) - 0.72, abs(q.x) - 0.05);
    r = opU(r, vec2(cl, 8.0));
    float ang = floor(uTime * 1.0) * 0.5236 + sin(uTime * 14.0) * 0.012 * step(0.5, fract(uTime));
    vec2 hq = q.zy * rot(-ang);
    float hands = min(sdBox(vec3(q.x - 0.0, hq.y - 0.3, hq.x), vec3(0.06, 0.34, 0.018)), sdBox(vec3(q.x, q.y - 0.17, q.z), vec3(0.06, 0.17, 0.03)));
    r = opU(r, vec2(hands, 6.0));
    return r;
}

// ---- scenes 3 and 4: the round hall -----------------------------------------------------------------------------------
vec2 figures(vec3 p, float r) {
    float kk = clamp(floor((r - 6.0) / 3.0), 0.0, 2.0);
    float rc = 7.5 + 3.0 * kk, hh = 0.7 * (kk + 1.0);
    float n = 14.0 + 6.0 * kk, sz = 6.2831853 / n;
    float a = atan(p.z, p.x), id = floor(a / sz + 0.5), la = a - id * sz;
    float aa = a - 1.5707963; aa = aa - 6.2831853 * floor(aa / 6.2831853 + 0.5);
    if (abs(aa) < 0.20) return vec2(1e5, 0.0);                           // the aisle stays open
    vec3 q = vec3(r * cos(la) - rc, p.y - hh, r * sin(la));
    float h = h31(vec3(id, kk, 3.0));
    float tall = 2.15 + 0.35 * h;
    q.x += uLean * 0.13 * q.y * q.y * (0.8 + 0.4 * h);
    q.z += sin(uTime * 0.4 + id) * 0.02 * q.y;
    float body = sdRC(q, 0.46, 0.15, tall);
    body = smin(body, sdCap(q, vec3(0.0, tall * 0.8, -0.42), vec3(0.0, tall * 0.8, 0.42), 0.15), 0.25);
    float head = length((q - vec3(0.0, tall + 0.2, 0.0)) * vec3(1.0, 0.82, 1.0)) - 0.2;
    float dd = 0.0;
    if (uShot == 3) {
        float keep = fbm(p * 2.2 + vec3(0.0, uTime * 0.08, 0.0));
        dd = (uDis * 0.8 - keep) * 0.55;
        body = max(body, dd); head = max(head, dd - 0.02);
    }
    return head < body ? vec2(head, 8.0) : vec2(body, 3.0);
}
vec2 map3(vec3 p) {
    float r = length(p.xz);
    vec2 res = vec2(p.y, 0.0);
    float kk = clamp(floor((r - 6.0) / 3.0), 0.0, 2.0);
    float rc = 7.5 + 3.0 * kk, hh = 0.7 * (kk + 1.0);
    float tier = max(abs(r - rc) - 1.5, p.y - hh);
    if (p.z > 0.0) tier = max(tier, 1.5 - abs(p.x));
    res = opU(res, vec2(tier, 2.0));
    float doorHole = sdBox(p - vec3(0.0, 1.5, 17.3), vec3(1.3, 1.5, 1.2));
    float wall = max(abs(r - 17.3) - 0.3, -doorHole);
    res = opU(res, vec2(wall, 1.0));
    float holeR = mix(r, max(abs(p.x), abs(p.z)) * 1.05, uSq);
    float ceil2 = max(abs(p.y - 10.3) - 0.3, 2.5 - holeR);
    res = opU(res, vec2(ceil2, 1.0));                                    // a thin roof with one opening
    res = opU(res, vec2(14.0 - p.y, 4.0));                                // the sky above the opening
    res = opU(res, vec2(22.0 - p.z, 4.0));                                // the light beyond the door
    if (uShot == 2) {            // two slow rings of light under the opening, turning against each other
        vec3 q = p - vec3(0.0, 9.6, 0.0); float a = atan(q.z, q.x);
        float d1 = max(length(vec2(length(q.xz) - 4.3, q.y)) - 0.05, sin(a * 10.0 + uTime * 0.4) * 0.5 - 0.1);
        float d2 = max(length(vec2(length(q.xz) - 3.0, q.y - 0.4)) - 0.04, sin(a * 7.0 - uTime * 0.5) * 0.5 - 0.1);
        res = opU(res, vec2(min(d1, d2), 12.0));
    }
    if (r > 5.0 && r < 15.5) res = opU(res, figures(p, r));
    return res;
}

// ---- the green (shader scene 4): wild and ancient at first, then tidied by a ring of light that leaves you and travels outward ----
float pathH(float z) { return 0.22 * sin(z * 0.23 + 1.0) + 0.10 * sin(z * 0.61); }
float orgAt(float d) { return 1.0 - smoothstep(uWaveR - 9.0, uWaveR, d); }          // 0 wild .. 1 tidy, d metres from you
float terr(vec2 xz, float o) {
    float side = smoothstep(2.6, 15.0, abs(xz.x));
    float hill = 1.5 * sin(xz.x * 0.085 + 1.7 * sin(xz.y * 0.047)) + 0.9 * sin(xz.y * 0.12 + xz.x * 0.06 + 2.0) + 0.5 * sin(xz.x * 0.21 + xz.y * 0.17) + 1.2;
    return mix(pathH(xz.y) + side * hill, 0.0, o);
}
vec2 treeAt(vec3 p, vec2 cell) {
    const float CS = 12.0;
    float h = h31(vec3(cell, 5.0)), h2 = h31(vec3(cell, 9.0)), h3 = h31(vec3(cell, 13.0));
    vec2 cg = (cell + 0.5) * CS;
    if (h > 0.8 || abs(cg.x) < 6.0) return vec2(1e5, 0.0);
    vec2 cw = cg + (vec2(h2, h3) - 0.5) * 0.4 * CS;
    float o = orgAt(length(vec3(cw.x, 6.0, cw.y) - uCam));                          // the whole tree changes together, when the ring reaches it
    vec2 c = mix(cw, cg, o);
    vec3 q = p - vec3(c.x, terr(c, o), c.y);
    if (length(q.xz) > 8.0) return vec2(length(q.xz) - 7.5, 21.0);
    float H = 11.0 + 7.0 * h;
    float lean = (1.0 - o) * (h2 - 0.5) * 0.14;
    q.xz += q.y * vec2(lean, -lean * 0.7);
    float rad = 0.55 + 0.45 * h3;
    float flare = (1.0 - o) * 0.9 * exp(-max(q.y, 0.0) * 0.9);
    float trunkR = (rad + flare) * (1.0 - 0.35 * clamp(q.y / H, 0.0, 1.0));
    float trunk = max(mix(length(q.xz) - trunkR, max(abs(q.x), abs(q.z)) - 0.48, o), max(-q.y, q.y - H));
    vec3 cq = q - vec3(0.0, H + 1.2, 0.0);
    float bs = (3.0 + 1.2 * h) * (1.0 - o);
    float blob = length(cq * vec3(1.0, 1.6, 1.0)) - bs;
    vec3 c2 = cq - vec3(4.0 * (h2 - 0.5), -1.5, 3.2 * (h3 - 0.5));
    blob = smin(blob, length(c2 * vec3(1.0, 1.5, 1.0)) - bs * 0.72, 1.2);
    blob += (1.0 - o) * 0.22 * sin(p.x * 1.7) * sin(p.y * 1.9 + 1.0) * sin(p.z * 1.6);
    float cano = blob * 0.8;
    if (o > 0.02) cano = min(cano, length(vec2(length(cq.xz) - 1.6, cq.y)) - 0.11 * o);   // the leaves become a thin ring of light
    return trunk < cano ? vec2(trunk, 21.0) : vec2(cano, 22.0);
}
vec2 trees(vec3 p) {
    if (p.y > 30.0) return vec2(p.y - 29.0, 21.0);
    const float CS = 12.0;
    vec2 g = p.xz / CS, c0 = floor(g), f = g - c0;
    vec2 s = vec2(f.x > 0.5 ? 1.0 : -1.0, f.y > 0.5 ? 1.0 : -1.0);
    vec2 r = treeAt(p, c0);
    r = opU(r, treeAt(p, c0 + vec2(s.x, 0.0)));
    r = opU(r, treeAt(p, c0 + vec2(0.0, s.y)));
    r = opU(r, treeAt(p, c0 + s));
    return r;
}
vec2 stones(vec3 p) {
    const float SS = 19.0;
    vec2 c0 = floor(p.xz / SS), cg = (c0 + 0.5) * SS;
    float h = h31(vec3(c0, 31.0));
    if (h > 0.5 || abs(cg.x) < 7.0) return vec2(1e5, 0.0);
    float h2 = h31(vec3(c0, 37.0)), h3 = h31(vec3(c0, 41.0));
    vec2 cw = cg + (vec2(h2, h3) - 0.5) * 0.45 * SS;
    float o = orgAt(length(vec3(cw.x, 2.0, cw.y) - uCam));
    vec2 c = mix(cw, cg, o);
    vec3 q = p - vec3(c.x, terr(c, o) - 0.3, c.y);
    if (length(q) > 9.0) return vec2(length(q) - 8.0, 23.0);
    q.xz = q.xz * rot(mix(h3 * 3.14159, 0.0, o));
    q.xy = q.xy * rot((h2 - 0.5) * 0.4 * (1.0 - o));
    vec3 ext = vec3(0.7 + 0.5 * h, 2.2 + 2.4 * h2, 0.4 + 0.3 * h3);
    float rr = 0.28 * (1.0 - o) + 0.03;
    float d = sdBox(q - vec3(0.0, ext.y, 0.0), ext - rr) - rr;
    d += (1.0 - o) * 0.12 * vn(q * 2.3 + c.x);
    return vec2(d, 23.0);
}
vec2 panels(vec3 p) {                                                              // light panels: they open exactly where the ring of light is passing
    const float PZ = 13.0;
    float cz = floor(p.z / PZ);
    vec2 best = vec2(1e5, 0.0);
    for (int sI = 0; sI < 2; sI++) {
        float sd = sI == 0 ? -1.0 : 1.0;
        float h = h31(vec3(cz, sd, 63.0));
        vec3 c = vec3(sd * (4.8 + 2.2 * h), 3.0 + 0.5 * h + 0.18 * sin(uTime * 0.6 + cz * 2.0 + sd), (cz + 0.5) * PZ + (h - 0.5) * 4.0);
        float sc = smoothstep(0.45, 1.0, orgAt(length(c - uCam)));
        if (sc < 0.02 || h > 0.85) continue;
        vec3 q = (p - c) / sc;
        if (length(q) > 3.0) { best = opU(best, vec2((length(q) - 2.6) * sc, 24.0)); continue; }
        q.xz = q.xz * rot(sd * 0.35);
        best = opU(best, vec2((sdBox(q, vec3(0.03, 1.15, 0.9)) - 0.02) * sc, 24.0));
    }
    return best;
}
vec2 gate(vec3 p) {                                                                // the old stone gate at the end of the path
    vec3 q = p - vec3(0.0, 0.0, uGateZ);
    if (abs(q.z) > 6.0 || q.y > 14.0) return vec2(max(abs(q.z) - 5.0, q.y - 13.0), 25.0);
    float o = orgAt(length(vec3(0.0, 4.0, uGateZ) - uCam));
    q.y -= pathH(uGateZ) * (1.0 - o);
    float pill = sdBox(vec3(abs(q.x) - 2.5, q.y - 5.0, q.z), vec3(0.65 - 0.1 * o, 5.0, 0.75)) - 0.15 * (1.0 - o);
    float lint = sdBox(q - vec3(0.0, 10.4, 0.0), vec3(3.9, 0.7, 0.85)) - 0.12 * (1.0 - o);
    float d = min(pill, lint) + (1.0 - o) * 0.1 * vn(q * 1.7);
    return vec2(d, 25.0);
}
vec2 map4(vec3 p) {
    float o = orgAt(length(p - uCam));
    vec2 r = vec2((p.y - terr(p.xz, o)) * 0.6, 20.0);
    r = opU(r, trees(p)); r = opU(r, stones(p)); r = opU(r, panels(p)); r = opU(r, gate(p));
    return r;
}

// ---- the drift (shader scene 5): the cabin of an unpowered shuttle -------------------------------------------------------------
vec2 map5(vec3 p) {
    // a small survey shuttle: a rounded tube with a wide curved canopy in the nose, timber lining, bronze trim, ribs, a sloped console
    vec3 c = p - vec3(0.0, 1.25, -0.1);
    float tube = (length(vec2(c.x / 1.55, c.y / 1.38)) - 1.0) * 1.25;
    float inner = max(tube, abs(c.z) - 2.0);
    float shell = max(-inner, inner - 0.32);
    float wsd = (length(vec2(p.x / 1.27, (p.y - 1.38) / 1.02)) - 1.0) * 0.74;          // the canopy: one wide oval, open to the sky
    float hole = max(wsd, abs(p.z + 2.25) - 0.55);
    vec2 pc = vec2(p.y - 1.5, p.z + 0.75);
    float hole2 = max(length(pc) - 0.27, abs(abs(p.x) - 1.7) - 0.5);                  // two round side ports
    vec2 r = vec2(max(shell, -min(hole, hole2)), 26.0);
    r = opU(r, vec2(max(abs(wsd) - 0.05, abs(p.z + 2.08) - 0.1), 27.0));                // canopy frame
    r = opU(r, vec2(max(abs(length(pc) - 0.31) - 0.035, abs(abs(p.x) - 1.5) - 0.1), 27.0));   // port rings
    for (int i = 0; i < 2; i++) {                                                      // canopy struts, leaning in toward the top
        float sx = i == 0 ? -1.0 : 1.0;
        r = opU(r, vec2(sdCap(p, vec3(sx * 0.7, 2.3, -2.02), vec3(sx * 0.46, 0.7, -2.02), 0.03), 27.0));
    }
    r = opU(r, vec2(sdCap(p, vec3(0.0, 2.3, -2.0), vec3(0.0, 2.08, -2.0), 0.05), 27.0));
    float cz = mod(p.z + 0.35, 1.05) - 0.525;                                          // ribs follow the curve of the hull
    r = opU(r, vec2(max(max(abs(tube + 0.08) - 0.08, abs(cz) - 0.075), abs(c.z) - 1.95), 26.0));
    r = opU(r, vec2(sdCap(p, vec3(0.62, 2.3, -1.7), vec3(0.62, 2.3, 1.7), 0.045), 27.0));       // a conduit along the roof
    r = opU(r, vec2(sdBox(p - vec3(0.0, 0.24, -0.1), vec3(1.05, 0.035, 1.9)), 27.0));            // deck plate
    // the console: sloped, rounded, with a lit strip, two sticks
    vec3 q = p - vec3(0.0, 0.52, -1.5); q.yz = q.yz * rot(-0.42);
    r = opU(r, vec2(sdBox(q, vec3(1.0, 0.2, 0.36)) - 0.03, 31.0));
    r = opU(r, vec2(sdBox(q - vec3(0.0, 0.236, 0.05), vec3(0.62, 0.006, 0.17)), 30.0));
    r = opU(r, vec2(sdBox(q - vec3(-0.78, 0.236, 0.05), vec3(0.14, 0.006, 0.17)), 30.0));
    r = opU(r, vec2(sdBox(q - vec3(0.78, 0.236, 0.05), vec3(0.14, 0.006, 0.17)), 30.0));
    r = opU(r, vec2(sdBox(p - vec3(0.0, 0.3, -1.55), vec3(1.0, 0.24, 0.3)) - 0.02, 31.0));
    for (int i = 0; i < 7; i++) r = opU(r, vec2(sdBox(q - vec3(-0.66 + 0.22 * float(i), 0.24, -0.2), vec3(0.06, 0.012, 0.03)), 29.0));
    // what floats: a photo, a page
    vec3 q1 = p - vec3(-0.55 + 0.08 * sin(uTime * 0.3), 1.5 + 0.1 * sin(uTime * 0.4 + 1.0), -1.0 + 0.05 * sin(uTime * 0.2));
    if (length(q1) < 0.3) { q1.xz = q1.xz * rot(uTime * 0.25); q1.yz = q1.yz * rot(uTime * 0.19 + 0.6); r = opU(r, vec2(sdBox(q1, vec3(0.13, 0.095, 0.004)) - 0.004, 28.0)); }
    else r = opU(r, vec2(length(q1) - 0.25, 28.0));
    vec3 q2 = p - vec3(0.62 + 0.06 * sin(uTime * 0.27 + 2.0), 1.25 + 0.1 * sin(uTime * 0.37), -0.8 + 0.06 * sin(uTime * 0.23));
    if (length(q2) < 0.3) { q2.xz = q2.xz * rot(-uTime * 0.2 + 1.0); q2.xy = q2.xy * rot(uTime * 0.23); r = opU(r, vec2(sdBox(q2, vec3(0.1, 0.14, 0.002)) - 0.003, 28.0)); }
    else r = opU(r, vec2(length(q2) - 0.25, 28.0));
    return r;
}

vec2 mapAll(vec3 p) {
    vec3 w = p + 0.02 * sin(p.yzx * 1.9 + uTime * 0.35 + float(uShot));
    vec2 r;
    if (uShot == 0) r = map1(w); else if (uShot == 1) r = map2(w); else if (uShot == 4) r = map4(p); else if (uShot == 5) r = map5(w); else r = map3(w);
    r = opU(r, child(p));
    r = opU(r, vec2(sdHand(p, uHandA, 1.25, 1.0, uHandOn.x), 6.0));
    r = opU(r, vec2(sdHand(p, uHandB, 0.7, -1.0, uHandOn.y), 7.0));
    r = opU(r, locket(p));
    return r;
}

vec3 calcN(vec3 p) {
    const vec2 e = vec2(1.0, -1.0) * 0.5773 * 0.004;
    return normalize(e.xyy * mapAll(p + e.xyy).x + e.yyx * mapAll(p + e.yyx).x + e.yxy * mapAll(p + e.yxy).x + e.xxx * mapAll(p + e.xxx).x);
}
float softShadow(vec3 ro, vec3 rd, float tmax) {
    float res = 1.0, t = 0.05;
    for (int i = 0; i < 18; i++) { if (uShot == 4 && i > 9) break; float h = mapAll(ro + rd * t).x; res = min(res, 7.0 * h / t); t += clamp(h, 0.06, 0.8); if (res < 0.02 || t > tmax) break; }
    return clamp(res, 0.0, 1.0);
}
float calcAO(vec3 p, vec3 n) {
    float o = 0.0, sc = 1.0;
    for (int i = 1; i <= 3; i++) { float h = 0.06 * float(i) * float(i); o += (h - mapAll(p + n * h).x) * sc; sc *= 0.6; }
    return clamp(1.0 - 2.2 * o, 0.0, 1.0);
}

// ---- the paint ---------------------------------------------------------------------------------------------------------
vec3 ramp(vec3 a, vec3 b, vec3 c, vec3 d, float x) {
    x = clamp(x, 0.0, 1.0);
    return x < 0.4 ? mix(a, b, x / 0.4) : (x < 0.75 ? mix(b, c, (x - 0.4) / 0.35) : mix(c, d, (x - 0.75) / 0.25));
}
float raySph(vec3 rd, vec3 c, float R) { float b = dot(rd, c); float d = b * b - (dot(c, c) - R * R); return d < 0.0 ? -1.0 : b - sqrt(d); }
float wrapPi(float a) { return a - 6.2831853 * floor((a + 3.1415927) / 6.2831853); }
// the night: the same dense, coloured stars, Milky Way and dust as the freefall, laid on as dabs of paint
vec3 driftStars(vec3 rd) {
    vec3 col = vec3(0.004, 0.006, 0.014);
    vec3 N = normalize(vec3(0.42, 0.74, -0.52));
    float mw = dot(rd, N), band = exp(-mw * mw / 0.045);
    float dust = fbm(rd * 3.2 + 4.0), lane = smoothstep(0.52, 0.66, fbm(rd * 6.5 + 11.0));
    col += vec3(0.07, 0.075, 0.12) * band * (0.5 + 0.9 * dust) * (1.0 - 0.7 * lane * band);
    col += vec3(0.1, 0.05, 0.09) * smoothstep(0.55, 0.85, fbm(rd * 2.0 + 20.0)) * band * 0.9;       // a pink nebula in the band
    col += vec3(0.03, 0.06, 0.12) * smoothstep(0.5, 0.9, fbm(rd * 1.6 + 40.0)) * 0.8;
    for (int k = 0; k < 3; k++) {
        float sc = k == 0 ? 48.0 : (k == 1 ? 110.0 : 260.0);
        vec3 sp = rd * sc, id = floor(sp), f = fract(sp) - 0.5;
        float h = h31(id + float(k) * 17.0);
        float thr = (k == 0 ? 0.90 : (k == 1 ? 0.93 : 0.955)) - band * (k == 2 ? 0.06 : 0.03);
        vec3 off = (vec3(h31(id + 1.7), h31(id + 4.3), h31(id + 9.1)) - 0.5) * 0.6;
        float rad = k == 0 ? 0.26 : (k == 1 ? 0.2 : 0.15);
        float s = step(thr, h) * smoothstep(rad, 0.0, length(f - off));
        float ci = h31(id + 31.0), br = (h - thr) / (1.0 - thr);
        vec3 tint = ci < 0.12 ? vec3(1.0, 0.55, 0.32) : (ci < 0.5 ? vec3(1.0, 0.88, 0.66) : (ci < 0.85 ? vec3(0.9, 0.93, 1.0) : vec3(0.62, 0.76, 1.0)));
        col += tint * s * (0.3 + 1.5 * br * br) * (0.8 + 0.2 * sin(uTime * (1.2 + 3.0 * ci) + h * 80.0));
    }
    return col;
}
// the gas giant of the freefall: same bands, same palette (deep brown, rust, ochre, cream, ivory, slate poles), the great storm, the same limb veil, painted
vec3 driftGiant(vec3 n, vec3 V, vec3 gd, float gW) {
    vec3 SUN = normalize(vec3(-0.45, 0.35, 0.75));
    vec3 nc0 = -gd; float near = smoothstep(0.35, 0.95, gW);
    vec3 pole = normalize(mix(vec3(0.22, 0.94, 0.26), vec3(0.22, 0.55, -0.6), near)), e1 = normalize(cross(pole, vec3(0.31, 0.12, 0.94))), e2 = cross(pole, e1);
    vec3 nc = -gd;
    float lonC = atan(dot(nc, e2), dot(nc, e1));
    float lat = dot(n, pole), lon = atan(dot(n, e2), dot(n, e1)), aLat = abs(lat);
    float lo = wrapPi(lon - lonC) + uTime * 0.0035 * (0.55 * sin(lat * 7.0) + 0.9 * cos(lat * 3.1 + 0.6) + 0.35);
    // the great storm: an oval of dark rust turning in the southern deck, with the bands bending round it
    vec2 ds = vec2((lo - 0.35) * cos(lat) * 0.62, lat + 0.3);
    float sf = exp(-dot(ds, ds) / 0.06);
    float sang = 5.0 * sf;
    vec2 dr = vec2(cos(sang) * ds.x - sin(sang) * ds.y, sin(sang) * ds.x + cos(sang) * ds.y);
    float turbA = fbm(vec3(lo * 1.6, lat * 7.0, uTime * 0.01));
    float u = (lat + (turbA - 0.5) * 0.085 + (dr.y - ds.y) * 0.45) * 15.0;
    float id = floor(u), f = fract(u);
    float edge = 1.0 - abs(2.0 * f - 1.0);
    u += (fbm(vec3(lo * 3.0, lat * 40.0, 4.0)) - 0.5) * 0.55 * (1.0 - edge) * (1.0 - edge);
    id = floor(u); f = fract(u);
    float t0 = h31(vec3(id * 3.17, 1.3, 2.0)), t1 = h31(vec3((id + 1.0) * 3.17, 1.3, 2.0));
    float tone = mix(t0, t1, smoothstep(0.30, 0.70, f));
    float stroke = vn(vec3(lo * 9.0, lat * 150.0, 3.0)), fine = fbm(vec3(lo * 4.0, lat * 70.0, 6.0));
    float cells = fbm(vec3(lo * 11.0, lat * 26.0, uTime * 0.02) + 2.0);
    tone = clamp(tone * 0.72 + (fine - 0.5) * 0.5 + (cells - 0.5) * 0.22 + (stroke - 0.5) * 0.18 + 0.14, 0.0, 1.0);
    tone = mix(tone, floor(tone * 7.0 + 0.5) / 7.0, 0.35);                          // soft washes: the tone steps like layered paint
    vec3 cDeep = vec3(0.17, 0.095, 0.075), cRust = vec3(0.47, 0.22, 0.13), cOchre = vec3(0.71, 0.45, 0.21), cCream = vec3(0.86, 0.73, 0.54), cIvory = vec3(0.93, 0.88, 0.76);
    vec3 b = mix(cDeep, cRust, smoothstep(0.05, 0.38, tone));
    b = mix(b, cOchre, smoothstep(0.30, 0.60, tone));
    b = mix(b, cCream, smoothstep(0.55, 0.82, tone));
    b = mix(b, cIvory, smoothstep(0.80, 1.0, tone));
    float cool = smoothstep(0.38, 0.86, aLat) * (0.35 + 0.5 * fbm(vec3(lo * 2.0, lat * 9.0, 8.0))) * (1.0 - 0.9 * near);
    b = mix(b, vec3(0.30, 0.37, 0.46) * (0.55 + tone * 0.75), clamp(cool, 0.0, 0.75));
    float sw = 0.5 + 0.5 * sin(atan(dr.y, dr.x) * 2.0 + length(dr) * 26.0 - uTime * 0.05);
    b = mix(b, mix(vec3(0.17, 0.08, 0.09), vec3(0.46, 0.24, 0.26), sw), smoothstep(0.25, 0.8, sf) * 0.85);
    b = mix(b, vec3(0.92, 0.84, 0.74), (1.0 - smoothstep(0.0, 0.07, abs(sf - 0.32))) * 0.35);
    // close to the deck: warped billows and mottled cells, like the last seconds of the dive, run backwards
    if (near > 0.001) {
        vec3 w = vec3(fbm(n * 9.0 + 1.0), fbm(n * 9.0 + 7.0), fbm(n * 9.0 + 13.0)) - 0.5;
        vec3 np = n + w * 0.12;
        float dd = fbm(np * 38.0) * 0.9 + fbm(np * 120.0) * 0.5 - 0.7;
        float bil = smoothstep(0.52, 0.68, fbm(np * 24.0 + 5.0));
        b *= 1.0 + clamp(dd * 0.9, -0.4, 0.4) * near;
        b = mix(b, mix(b, vec3(0.95, 0.82, 0.62), 0.55), bil * 0.5 * near);
        b = mix(b, b * vec3(1.2, 0.85, 0.65), clamp(dd, 0.0, 0.5) * near);
    }
    float NdotL = dot(n, SUN), lightAmt = smoothstep(-0.22, 0.42, NdotL);
    float tbN = (NdotL - 0.04) / 0.20, termBand = exp(-tbN * tbN);
    vec3 night = b * vec3(0.085, 0.07, 0.085) + vec3(0.006, 0.007, 0.012);
    vec3 day = b * (0.6 + 0.6 * clamp(NdotL, 0.0, 1.0));
    vec3 col = mix(night, day, lightAmt);
    col += vec3(0.62, 0.26, 0.10) * termBand * 0.2 * smoothstep(-0.2, 0.3, NdotL + 0.25) * (0.4 + 0.6 * tone);
    float vn2 = max(dot(n, V), 0.0);
    col *= mix(mix(0.45, 0.8, near), 1.0, pow(vn2, 0.45));
    float fres = pow(1.0 - vn2, 2.6), sunSide = clamp(NdotL * 1.3 + 0.35, 0.0, 1.0);
    col += mix(vec3(0.85, 0.46, 0.24), vec3(0.5, 0.66, 0.92), smoothstep(0.1, 0.8, NdotL)) * fres * sunSide * 0.42;
    col = mix(col, vec3(0.16, 0.07, 0.04), smoothstep(0.78, 1.0, 1.0 - vn2) * 0.25);   // a pooled dark edge, like wet paint at the limb
    return col * (1.1 + 0.45 * near) * mix(vec3(1.0), vec3(1.1, 0.97, 0.88), near);
}
vec3 driftSky(vec3 rd) {
    rd.xz = rd.xz * rot(uSkyYaw); rd.xy = rd.xy * rot(uSkyRoll);
    vec3 col = driftStars(rd);
    vec3 gd = normalize(uGD), SUN = normalize(vec3(-0.45, 0.35, 0.75));
    float gAng = min(uMoon.y, 1.5), gR = sin(gAng);
    float tg = raySph(rd, gd, gR);
    float sepA = acos(clamp(dot(rd, gd), -1.0, 1.0));
    if (tg > 0.0) {
        vec3 n = normalize(rd * tg - gd);
        col = driftGiant(n, -rd, gd, uMoon.y);
    } else {                                                                       // the thin amber and blue air above the limb
        float over = sepA - gAng;
        float glow = exp(-over * mix(26.0, 9.0, smoothstep(0.1, 0.6, uMoon.y)));
        float sideL = clamp(dot(normalize(rd - gd * dot(rd, gd)), normalize(SUN - gd * dot(SUN, gd) + 0.0001)) * 0.5 + 0.55, 0.0, 1.0);
        col += mix(vec3(0.85, 0.46, 0.24), vec3(0.45, 0.62, 0.95), 0.4 * sideL) * glow * (0.15 + 0.55 * sideL);
    }
    vec3 MD = normalize(vec3(0.2, 0.06, -1.0));                                    // the moon: green and blue, and nothing should be there
    float mAng = min(uMoon.x, 1.5), tm = raySph(rd, MD, sin(mAng));
    if (tm > 0.0) {
        vec3 n = normalize(rd * tm - MD), nn = n; nn.xz = nn.xz * rot(uTime * 0.02);
        float fq = 2.6 * (1.0 + 3.0 * smoothstep(0.3, 1.2, uMoon.x));
        float land = smoothstep(0.5, 0.56, fbm(nn * fq + 1.0));
        vec3 sea = mix(vec3(0.02, 0.16, 0.3), vec3(0.04, 0.34, 0.4), smoothstep(0.3, 0.5, fbm(nn * fq + 1.0)));
        vec3 gr = mix(vec3(0.1, 0.36, 0.14), vec3(0.45, 0.4, 0.22), smoothstep(0.55, 0.8, fbm(nn * fq * 1.7)));
        vec3 sc = mix(sea, gr, land);
        sc = mix(sc, vec3(0.9, 0.95, 1.0), smoothstep(0.8, 0.92, abs(nn.y)));
        float cl = smoothstep(0.54, 0.72, fbm(nn * fq * 1.5 + vec3(uTime * 0.01, 0.0, 0.0)));
        sc = mix(sc, vec3(0.95, 0.97, 1.0), cl * 0.85);
        sc *= 0.9 + 0.2 * vn(vec3(nn.xz * 40.0, nn.y * 12.0));                     // brush
        float dif = clamp(dot(n, SUN) * 1.3 + 0.12, 0.0, 1.0);
        col = sc * (0.05 + 1.15 * dif) + vec3(0.25, 0.55, 1.0) * pow(1.0 - clamp(dot(n, -rd), 0.0, 1.0), 3.0) * (0.15 + 0.7 * dif);
    } else {
        float over = acos(clamp(dot(rd, MD), -1.0, 1.0)) - mAng;
        col += vec3(0.2, 0.5, 1.0) * exp(-over * 40.0) * 0.28;
    }
    col = mix(col, vec3(1.0, 0.5, 0.2) * (1.0 + 0.6 * vn(rd * 8.0 + uTime)), uHeat * 0.6);
    return col;
}
vec3 driftPaint(vec3 rd, vec2 uv) {
    vec3 w = vec3(vn(vec3(uv * 7.0, 1.0)), vn(vec3(uv * 7.0 + 5.0, 2.0)), vn(vec3(uv * 7.0 + 9.0, 3.0))) - 0.5;      // wet paper: the sky is laid down in dabs and does not sit perfectly still
    vec3 c = driftSky(normalize(rd + w * 0.012));
    float lum = dot(c, vec3(0.3, 0.55, 0.15));
    c = mix(c, c * (floor(lum * 9.0 + 0.5) / 9.0 + 0.02) / (lum + 0.02), 0.3);
    c *= 0.92 + 0.16 * vn(vec3(uv * vec2(70.0, 38.0), 4.0));
    return c;
}
vec3 skyCol(vec3 rd, vec3 p) {
    if (uShot == 4) {
        float e = rd.y;
        vec3 d = mix(vec3(1.0, 0.45, 0.25), vec3(1.0, 0.82, 0.55), smoothstep(-0.05, 0.3, e));
        d = mix(d, vec3(0.45, 0.58, 0.78), smoothstep(0.25, 0.8, e));
        vec3 sd = normalize(vec3(0.0, 0.07, -1.0)); float sdot = dot(rd, sd);
        d += vec3(1.0, 0.65, 0.3) * pow(max(sdot, 0.0), 12.0) * 0.9;
        d = mix(d, vec3(1.3, 1.2, 1.0) * 1.7, smoothstep(0.9965, 0.9985, sdot));
        vec3 gdir = normalize(vec3(0.55, 0.38, -0.75)); float gdd = acos(clamp(dot(rd, gdir), -1.0, 1.0)), gR = 0.5;
        if (gdd < gR) {                                                            // an unfamiliar thing in the sky: a banded giant
            float band = 0.5 + 0.5 * sin((rd.y - gdir.y) * 38.0 + 3.0 * sin(rd.x * 9.0));
            vec3 gc = mix(vec3(0.85, 0.62, 0.42), vec3(0.95, 0.85, 0.7), band) * (0.55 + 0.45 * smoothstep(-0.2, 0.5, (rd.x - gdir.x) * -1.0 + 0.3));
            d = mix(d, gc, smoothstep(gR, gR - 0.06, gdd) * 0.92);
        }
        d = mix(d, d * vec3(0.78, 0.97, 1.1) + vec3(0.0, 0.04, 0.07), uOrgSky);
        d += vec3(0.5, 0.95, 1.0) * smoothstep(0.014, 0.0, abs(rd.y - (0.55 - 0.7 * rd.x * rd.x))) * uOrgSky * 1.4;   // the ring that comes on once the world is tidy
        return d * 1.2;
    }
    if (uShot == 0) {
        float e = rd.y;
        vec3 c = mix(vec3(1.0, 0.42, 0.22), vec3(1.0, 0.8, 0.5), smoothstep(-0.12, 0.32, e));
        c = mix(c, vec3(0.95, 0.55, 0.5), 0.35 * smoothstep(0.2, 0.5, e) * fbm(vec3(rd.xy * 5.0, 1.0)));
        vec3 sd = normalize(vec3(0.12, 0.02, -1.0)); float sdot = dot(rd, sd);
        c += vec3(1.0, 0.6, 0.25) * pow(max(sdot, 0.0), 14.0) * 0.9;
        c = mix(c, vec3(1.2, 1.1, 0.9) * 1.6, smoothstep(0.9975, 0.9992, sdot));
        float hill = -0.075 + 0.03 * sin(rd.x * 11.0 + 1.0) + 0.02 * sin(rd.x * 27.0);
        c = mix(c, vec3(0.3, 0.1, 0.16), smoothstep(0.012, -0.004, e - hill));
        // far off on the ridge: the spires of a city with lit windows, and the thin arc of a ring across the sky
        float sxx = rd.x / max(-rd.z, 0.2) * 5.0, cI = floor(sxx), fxx = fract(sxx) - 0.5;
        float hsp = 0.014 + 0.07 * h31(vec3(cI, 2.0, 5.0)), ab = e - hill;
        float spire = smoothstep(0.03, 0.0, abs(fxx) - 0.06 * (1.0 - clamp(ab / hsp, 0.0, 1.0))) * step(0.0, ab) * step(ab, hsp) * step(0.4, h31(vec3(cI, 1.0, 5.0)));
        c = mix(c, vec3(0.28, 0.12, 0.2), spire);
        c += vec3(1.0, 0.8, 0.4) * spire * step(0.8, h31(vec3(floor(rd.y * 180.0), cI, 4.0))) * 0.8;
        c += vec3(1.0, 0.85, 0.7) * smoothstep(0.012, 0.0, abs(rd.y - (0.42 - 0.9 * rd.x * rd.x))) * 0.5;
        return c * 1.35;
    }
    if (uShot == 1) { return vec3(1.0, 0.78, 0.45) * 1.5 * (0.8 + 0.4 * fbm(p * 0.4 + uTime * 0.05)); }
    if (uShot == 2) { return vec3(0.9, 0.95, 1.0) * 1.6; }
    return mix(vec3(1.0, 0.8, 0.45), vec3(1.0, 0.95, 0.8), 0.5 + 0.5 * fbm(p * 0.2)) * 1.6;
}

// ---- v107 light in the air: shafts, floating dust, glow ---------------------------------------------------------------
// lightIn(p): how much of the scene's key light reaches the air at p (colour * 0..~1.5), shaped like the real openings:
// the kitchen window, the corridor's moon windows and doorway, the hall's roof opening and far door, the sea's surface, the green's low sun.
vec3 lightIn(vec3 p) {
    if (uShot == 0) {
        vec3 Lk = normalize(vec3(0.08, 0.28, -1.0)); float s = (-3.45 - p.z) / Lk.z; if (s < 0.0 || abs(p.x) > 3.4 || p.y < 0.0 || p.y > 3.2) return vec3(0.0);
        vec3 q = p + Lk * s; vec2 w = abs(q.xy - vec2(0.0, 1.55)) - vec2(1.45, 1.05);
        float m = smoothstep(0.16, -0.12, max(w.x, w.y));
        return vec3(1.0, 0.68, 0.36) * m * (0.45 + 0.55 * smoothstep(9.0, 0.5, s));
    }
    if (uShot == 1) {
        vec3 Lk = normalize(vec3(-0.5, 1.0, 0.1)); float s = (-2.3 - p.x) / Lk.x; vec3 o = vec3(0.0);
        if (s > 0.0 && p.y < 4.6) { vec3 q = p + Lk * s; float zz = mod(q.z + 1.2, 3.6) - 1.8;
            o += vec3(0.5, 0.66, 1.0) * smoothstep(0.62, 0.38, abs(zz)) * smoothstep(2.8, 3.1, q.y) * smoothstep(4.5, 4.2, q.y) * 1.25; }
        vec3 dv = vec3(0.0, 1.2, uDoorZ - 1.5) - p; o += vec3(1.0, 0.7, 0.36) * 1.7 / (1.0 + 0.05 * dot(dv, dv));
        return o;
    }
    if (uShot == 2) {
        float rr = length(p.xz); float hole = mix(rr, max(abs(p.x), abs(p.z)) * 1.05, uSq);
        float cyl = smoothstep(2.9, 2.2, hole) * smoothstep(0.0, 2.5, p.y) * step(p.y, 10.4);
        vec3 dv = vec3(0.0, 1.5, 18.0) - p; float dl = 2.4 / (1.0 + 0.025 * dot(dv, dv)) * smoothstep(-2.0, 6.0, p.z);
        return vec3(0.72, 0.88, 1.0) * cyl * 1.25 + vec3(1.0, 0.94, 0.82) * dl;
    }
    if (uShot == 3) {
        float dep = uWater - p.y; if (dep < 0.0) return vec3(0.0);
        vec3 q = p + vec3(0.0, 1.0, 0.02) * dep;
        float ray = smoothstep(0.42, 0.82, fbm(vec3(q.xz * 0.5, uTime * 0.09)) * 1.7);
        return vec3(0.55, 1.0, 0.85) * ray * exp(-dep * 0.075) * 1.5;
    }
    if (uShot == 4) {
        vec3 Lk = normalize(vec3(0.05, 0.16, -1.0)); vec3 u = normalize(cross(vec3(0.0, 1.0, 0.0), Lk)); vec3 v = cross(Lk, u);
        float a = dot(p, u), b = dot(p, v); float org = orgAt(length(p - uCam));
        float gaps = vn(vec3(a * 0.55, b * 0.16, 3.0 + uTime * 0.03)) * 0.65 + vn(vec3(a * 1.1, b * 0.3, 9.0)) * 0.35;
        float sh = smoothstep(0.42 - 0.12 * org, 0.78 - 0.2 * org, gaps);
        sh *= exp(-max(p.y, 0.0) * 0.14);
        return mix(vec3(1.0, 0.7, 0.4), vec3(0.45, 0.9, 1.0), org) * sh * 1.5;
    }
    return vec3(0.5, 0.58, 0.8) * 0.5;
}
vec3 airFx(vec3 ro, vec3 rd, float tHit, vec3 L) {
    float rng = min(tHit, uShot == 4 ? 42.0 : (uShot == 2 ? 26.0 : (uShot == 3 ? 34.0 : (uShot == 5 ? 7.0 : 14.0))));
    float k = uShot == 0 ? 0.05 : (uShot == 1 ? 0.03 : (uShot == 2 ? 0.028 : (uShot == 3 ? 0.04 : (uShot == 4 ? 0.014 : 0.01))));
    float ph = 0.45 + 1.8 * pow(clamp(dot(rd, L), 0.0, 1.0), 4.0);
    float j = h31(vec3(gl_FragCoord.xy, 3.0));
    vec3 acc = vec3(0.0);
    for (int i = 0; i < 12; i++) {
        float tt = (float(i) + j) * (rng / 12.0); vec3 p = ro + rd * tt;
        acc += lightIn(p) * (0.75 + 0.6 * vn(p * 1.25 + vec3(0.0, uTime * 0.04, uTime * 0.03)));
    }
    acc *= (rng / 12.0) * k * ph;
    // dust: motes fixed in the world (they slide with parallax as you walk), fading in and out as they cross their own depth shell
    float pxA = uTanFov * 1.6 / uRes.y;
    for (int kk = 0; kk < 4; kk++) {
        float fk = float(kk); float dk = 1.1 + fk * fk * 0.9 + fk * 1.1;
        if (dk > tHit - 0.15) continue;
        float cs = 0.35 + 0.25 * dk; vec3 pw = ro + rd * dk, ci = floor(pw / cs);
        vec3 hh = vec3(h31(ci + fk * 17.0), h31(ci.yzx + 3.7 + fk * 17.0), h31(ci.zxy + 8.1 + fk * 17.0));
        if (hh.x > 0.6) continue;
        vec3 dp = (ci + 0.2 + 0.6 * hh) * cs + 0.07 * cs * vec3(sin(uTime * 0.3 + hh.x * 40.0), sin(uTime * 0.23 + hh.y * 40.0), sin(uTime * 0.27 + hh.z * 40.0));
        vec3 dv = dp - ro; float dd = dot(dv, rd); if (dd > tHit - 0.05 || dd < 0.3) continue;
        float perp = length(dv - rd * dd), r = pxA * dd * (0.9 + 1.4 * hh.y);
        float m = smoothstep(r, 0.0, perp); m *= m * smoothstep(0.55 * cs, 0.12 * cs, abs(dd - dk)) * (0.6 + 0.4 * sin(uTime * (0.8 + hh.z * 2.0) + hh.x * 30.0));
        acc += (lightIn(dp) * 1.3 + vec3(0.05, 0.05, 0.06)) * m * smoothstep(0.3, 1.6, dd);
    }
    if (uShot == 4) {
        for (int kk = 0; kk < 3; kk++) {
            float fk = float(kk); float dk = 3.0 + fk * 5.5 + fk * fk * 2.0; if (dk > tHit - 0.3) continue;
            float cs = 1.6 + 0.9 * fk; vec3 pw = ro + rd * dk, ci = floor(pw / cs);
            if (ci.y < 0.0 || ci.y * cs > 3.5) continue;
            vec3 hh = vec3(h31(ci + fk * 5.0 + 40.0), h31(ci.yzx + 41.7), h31(ci.zxy + 42.1)); if (hh.x > 0.4) continue;
            vec3 dp = (ci + 0.2 + 0.6 * hh) * cs; dp.xz += 0.3 * vec2(sin(uTime * 0.35 + hh.x * 30.0), cos(uTime * 0.3 + hh.z * 30.0)); dp.y += 0.2 * sin(uTime * 0.6 + hh.z * 20.0);
            vec3 dv = dp - ro; float dd = dot(dv, rd); if (dd > tHit - 0.2 || dd < 1.0) continue;
            float perp = length(dv - rd * dd), r = pxA * dd * (1.6 + 1.6 * hh.y);
            float m = smoothstep(r * 3.2, 0.0, perp); m = m * m * m * smoothstep(0.5 * cs, 0.1 * cs, abs(dd - dk));
            float fl = 0.35 + 0.65 * pow(0.5 + 0.5 * sin(uTime * (1.0 + 2.0 * hh.z) + hh.x * 40.0), 2.0);
            acc += mix(vec3(1.0, 0.8, 0.35), vec3(0.4, 0.95, 1.0), orgAt(length(dv))) * m * fl * 2.4;
        }
    }
    if (uShot == 3) {
        for (int kk = 0; kk < 3; kk++) {
            float fk = float(kk); float dk = 2.5 + fk * 4.0 + fk * fk * 1.5; if (dk > tHit - 0.3) continue;
            float cs = 1.2 + 0.8 * fk; vec3 pw = ro + rd * dk, ci = floor(pw / cs);
            vec3 hh = vec3(h31(ci + fk * 7.0 + 60.0), h31(ci.yzx + 61.7), h31(ci.zxy + 62.1)); if (hh.x > 0.5) continue;
            vec3 dp = (ci + 0.2 + 0.6 * hh) * cs + 0.3 * vec3(sin(uTime * 0.2 + hh.x * 30.0), sin(uTime * 0.17 + hh.y * 30.0), cos(uTime * 0.22 + hh.z * 30.0));
            if (dp.y > uWater) continue;
            vec3 dv = dp - ro; float dd = dot(dv, rd); if (dd > tHit - 0.2 || dd < 0.8) continue;
            float perp = length(dv - rd * dd), r = pxA * dd * (1.2 + 1.2 * hh.y);
            float m = smoothstep(r * 2.2, 0.0, perp); m = m * m * smoothstep(0.5 * cs, 0.1 * cs, abs(dd - dk));
            acc += (vec3(0.5, 0.85, 0.8) * 0.3 + lightIn(dp) * 0.9) * m * 1.6;
        }
    }
    return acc;
}
vec3 glowOf(float gm) {
    if (gm > 10.5 && gm < 13.5) return vec3(0.25, 0.85, 1.0);
    if (gm > 23.5 && gm < 24.5) return vec3(0.25, 0.85, 1.0);
    if (gm > 8.5 && gm < 10.5) return vec3(1.0, 0.75, 0.35);
    if (gm > 28.5 && gm < 30.5) return vec3(0.9, 0.6, 0.3);
    return vec3(0.0);
}

void main() {
    vec2 uv = (gl_FragCoord.xy - 0.5 * uRes) / uRes.y;
    vec2 uv0 = uv;
    // wet paper: the whole picture wobbles like a watercolour drying, and swims when the dream changes
    vec2 wv = vec2(vn(vec3(uv * 5.0, uTime * 0.12)), vn(vec3(uv * 5.0 + 9.1, uTime * 0.12))) - 0.5;
    uv += wv * 0.006 * (1.0 + uWarp * 5.0);
    if (uWarp > 0.001) { float r2 = dot(uv, uv); uv = uv * rot(uWarp * (0.35 + r2 * 1.6) * sin(uTime * 0.7 + 1.0)); uv *= 1.0 - 0.18 * uWarp; }
    uv *= 1.0 - 0.22 * uStreak * uStreak;                                          // the plunge pulls the picture in
    if (uGlitch > 0.001) {                                                         // tearing: whole bands of the picture slide sideways
        float rr = h31(vec3(floor(gl_FragCoord.y / (uRes.y * 0.045)), floor(uTime * 14.0), 1.0));
        uv.x += (rr - 0.5) * 0.5 * uGlitch * step(0.45, rr);
        uv.y += (h31(vec3(floor(gl_FragCoord.x / (uRes.x * 0.08)), floor(uTime * 9.0), 2.0)) - 0.5) * 0.06 * uGlitch * uGlitch;
    }
    float shardE = 0.0, shardM = 1.0;
    if (uShatter > 0.001) {                                                        // shards: every piece flies off on its own and goes dark in its own time
        vec2 g = uv * 6.5, gi = floor(g), gf = fract(g); float d1 = 9.0, d2 = 9.0; vec2 bid = vec2(0.0);
        for (int j = -1; j <= 1; j++) for (int i = -1; i <= 1; i++) {
            vec2 o = vec2(float(i), float(j)); vec2 hc = vec2(h31(vec3(gi + o, 1.0)), h31(vec3(gi + o, 2.0)));
            float d = length(o + hc - gf);
            if (d < d1) { d2 = d1; d1 = d; bid = gi + o; } else if (d < d2) d2 = d;
        }
        vec2 hv = vec2(h31(vec3(bid, 3.0)), h31(vec3(bid, 4.0))) - 0.5;
        float s = uShatter;
        uv += hv * s * s * 1.6; uv = uv * rot(hv.x * s * s * 1.2);
        shardE = smoothstep(0.1, 0.0, d2 - d1);
        shardM = 1.0 - smoothstep(0.3, 0.9, s + (h31(vec3(bid, 5.0)) - 0.5) * 0.6);
    }
    vec3 ro = uCam, rd = normalize(uF + uTanFov * 1.6 * (uv.x * uR + uv.y * uU));
    float tmax = uShot == 0 ? 16.0 : (uShot == 4 ? 80.0 : (uShot == 5 ? 12.0 : 46.0));
    float t = 0.02; vec2 res = vec2(0.0); bool hit = false; vec3 glowAcc = vec3(0.0);
    for (int i = 0; i < 80; i++) {
        vec3 p = ro + rd * t; res = mapAll(p);
        { vec3 gc = glowOf(res.y); if (gc.x + gc.y + gc.z > 0.0) glowAcc += gc * exp(-res.x * 7.0) * min(res.x * 0.85 + 0.01, 0.6) * 0.28; }
        if (res.x < 0.0016 * t) { hit = true; break; }
        t += res.x * 0.85; if (t > tmax) break;
    }
    if (!hit && t < tmax && res.x < 0.02 * t + 0.01) hit = true;
    vec3 col; float tHit = hit ? t : tmax;
    vec3 L, Lc, amb, fogc; float fogd;
    vec3 pA, pB, pC, pD;
    if (uShot == 0) { L = normalize(vec3(0.08, 0.28, -1.0)); Lc = vec3(1.9, 1.15, 0.6); amb = vec3(0.3, 0.2, 0.26); fogc = vec3(1.0, 0.66, 0.42); fogd = 0.035;
        pA = vec3(0.16, 0.07, 0.12); pB = vec3(0.62, 0.28, 0.2); pC = vec3(0.98, 0.7, 0.4); pD = vec3(1.0, 0.93, 0.7); }
    else if (uShot == 1) { L = normalize(vec3(-0.5, 1.0, 0.1)); Lc = vec3(0.34, 0.44, 0.8); amb = vec3(0.12, 0.15, 0.3); fogc = vec3(0.04, 0.05, 0.12); fogd = 0.05;
        pA = vec3(0.02, 0.03, 0.09); pB = vec3(0.12, 0.19, 0.38); pC = vec3(0.5, 0.58, 0.8); pD = vec3(1.0, 0.86, 0.6); }
    else if (uShot == 2) { L = normalize(vec3(0.02, 1.0, 0.03)); Lc = vec3(1.4, 1.42, 1.5); amb = vec3(0.17, 0.2, 0.27); fogc = vec3(0.07, 0.08, 0.11); fogd = 0.03;
        pA = vec3(0.02, 0.025, 0.045); pB = vec3(0.2, 0.24, 0.32); pC = vec3(0.62, 0.68, 0.76); pD = vec3(1.0, 1.0, 1.0); }
    else if (uShot == 4) { L = normalize(vec3(0.05, 0.16, -1.0)); Lc = mix(vec3(2.1, 1.35, 0.7), vec3(1.5, 1.75, 1.95), uOrgSky); amb = mix(vec3(0.34, 0.38, 0.36), vec3(0.3, 0.4, 0.5), uOrgSky); fogc = mix(vec3(1.0, 0.62, 0.4), vec3(0.72, 0.76, 0.8), uOrgSky); fogd = 0.017;
        pA = vec3(0.04, 0.07, 0.07); pB = vec3(0.18, 0.34, 0.28); pC = vec3(0.86, 0.72, 0.45); pD = vec3(1.0, 0.92, 0.7); }
    else if (uShot == 5) { float gK = min(uMoon.y, 1.2), mK = clamp(sin(min(uMoon.x, 1.5)) * 2.0 / (sin(min(uMoon.x, 1.5)) * 2.0 + sin(gK) + 0.05), 0.0, 1.0);
        vec3 wl = mix(vec3(1.9, 1.1, 0.55) * (0.55 + 0.7 * gK), vec3(0.5, 0.8, 1.0) * 1.5, mK);
        L = normalize(vec3(0.0, 0.1, -1.0)); Lc = mix(wl, vec3(2.0, 0.8, 0.25), uHeat); amb = mix(vec3(0.1, 0.075, 0.07), vec3(0.06, 0.085, 0.12), mK); fogc = vec3(0.0); fogd = 0.0;
        pA = mix(vec3(0.03, 0.015, 0.02), vec3(0.0, 0.01, 0.03), mK); pB = mix(vec3(0.24, 0.12, 0.09), vec3(0.07, 0.14, 0.24), mK); pC = mix(vec3(0.82, 0.5, 0.3), vec3(0.5, 0.65, 0.85), mK); pD = vec3(1.0, 0.93, 0.8); }
    else { L = normalize(vec3(0.0, 1.0, 0.02)); Lc = vec3(1.3, 1.1, 0.75); amb = vec3(0.2, 0.34, 0.4); fogc = vec3(0.04, 0.15, 0.19); fogd = 0.05;
        pA = vec3(0.01, 0.05, 0.08); pB = vec3(0.06, 0.28, 0.34); pC = vec3(0.45, 0.72, 0.68); pD = vec3(1.0, 0.92, 0.65); }
    float edgeW = 0.0;
    if (hit) {
        vec3 p = ro + rd * t, n = calcN(p); float m = res.y;
        vec3 sRef = normalize(mix(vec3(0.0, 1.0, 0.0), vec3(1.0, 0.0, 0.3), smoothstep(0.6, 0.95, abs(n.y))));
        vec3 tA = normalize(cross(n, sRef)), tB = cross(n, tA);                   // the brush travels along the surface
        float sa = dot(p, tA), sb = dot(p, tB); float sz = 1.0 / (0.55 + 0.075 * t);     // strokes keep a similar size on screen near and far
        float brush = vn(vec3(sa * 3.2 * sz, sb * 11.0 * sz, 2.0 + floor(res.y) * 1.3));      // the stroke itself: long along the form
        float bristle = vn(vec3(sa * 1.5 * sz, sb * 58.0 * sz, 7.0));                          // hair lines inside it
        float strokeTone = h31(vec3(floor(sb * 4.5 * sz + 0.6 * vn(vec3(sa * 0.5 * sz, sb * sz, 1.0))), floor(sa * 0.3 * sz), res.y));   // every stroke carries its own load of paint
        vec3 alb = vec3(0.6);
        vec3 emis = vec3(0.0);
        float orgH = uShot == 4 ? orgAt(length(p - ro)) : 0.0;
        if (m > 19.5) {
            if (m < 20.5) {            // ground: moss, grass and bare earth, then dark tile with light in the seams
                vec3 g1 = mix(vec3(0.13, 0.27, 0.12), vec3(0.3, 0.34, 0.15), vn(vec3(p.xz * 0.55, 1.0)));
                g1 = mix(g1, vec3(0.4, 0.31, 0.19), smoothstep(0.55, 0.8, vn(vec3(p.xz * 0.21, 5.0)))) * (0.8 + 0.4 * vn(vec3(p.xz * 3.1, 2.0)));
                alb = mix(g1, vec3(0.13, 0.15, 0.19), orgH);
                vec2 sf = fract(p.xz / 4.0); float se = min(min(sf.x, 1.0 - sf.x), min(sf.y, 1.0 - sf.y)) * 4.0;
                emis += vec3(0.2, 0.8, 1.0) * (smoothstep(0.1, 0.0, se) * 0.9 + smoothstep(0.5, 0.0, abs(p.x)) * 0.45) * orgH * (0.7 + 0.5 * sin(p.z * 0.4 - uTime * 2.0));
            } else if (m < 21.5) {     // trunk -> pillar
                alb = mix(mix(vec3(0.3, 0.22, 0.16), vec3(0.18, 0.13, 0.1), vn(vec3(p.xz * 1.7, p.y * 0.35))), vec3(0.14, 0.16, 0.2), orgH);
                emis += vec3(0.25, 0.9, 1.0) * smoothstep(0.06, 0.0, abs(fract(p.y * 0.35) - 0.5) - 0.42) * orgH * 1.3;
            } else if (m < 22.5) {     // canopy -> ring of light
                alb = mix(mix(vec3(0.13, 0.33, 0.16), vec3(0.4, 0.5, 0.2), vn(vec3(p * 0.7))), vec3(0.1, 0.12, 0.16), orgH);
                emis += vec3(0.5, 1.0, 1.0) * orgH * 1.5;
            } else if (m < 23.5) {     // stone -> slab with glyphs
                vec3 st = mix(vec3(0.42, 0.43, 0.38), vec3(0.28, 0.36, 0.22), smoothstep(0.4, 0.7, vn(p * 1.3)) * (1.0 - orgH));
                alb = mix(st, vec3(0.12, 0.14, 0.19), orgH);
                emis += vec3(0.25, 0.85, 1.0) * step(0.6, h31(floor(p * 2.2))) * step(0.5, fract(p.y * 0.6)) * orgH * 1.2;
            } else if (m < 24.5) {     // light panel
                alb = vec3(0.02, 0.05, 0.07);
                float rows = step(0.55, h31(floor(vec3(p.y * 7.0, p.z * 6.0 + p.x * 6.0, floor(uTime * 1.5)))));
                emis += vec3(0.3, 0.9, 1.0) * (0.35 + 0.65 * rows + smoothstep(0.08, 0.0, abs(fract(p.y * 0.7 - uTime * 0.2) - 0.5) - 0.42));
            } else if (m < 25.5) {     // the gate: mossy stone, then dark stone with a light running up its inner faces
                alb = mix(vec3(0.38, 0.35, 0.3) * (0.8 + 0.4 * vn(p * 1.5)), vec3(0.14, 0.16, 0.2), orgH);
                emis += vec3(0.3, 0.9, 1.0) * smoothstep(1.2, 0.0, abs(abs(p.x) - 2.0)) * 0.7 * (0.5 + 0.5 * step(0.5, fract(p.y * 0.8 - uTime * 0.3))) * orgH;
            } else if (m < 26.5) {     // cabin wall: timber below, metal above
                alb = mix(vec3(0.22, 0.15, 0.11) * (0.8 + 0.4 * vn(p * vec3(2.0, 18.0, 2.0))), vec3(0.12, 0.15, 0.2), smoothstep(1.2, 1.9, p.y));
            } else if (m < 27.5) {     // metal; hot when the air is
                alb = vec3(0.42, 0.3, 0.17) * (0.8 + 0.4 * vn(p * 14.0));          // bronze trim
                emis += vec3(1.5, 0.6, 0.16) * uHeat * 1.3;
            } else if (m < 28.5) {     // photo, page
                alb = vec3(0.9, 0.8, 0.62) * (0.85 + 0.15 * step(0.5, fract(p.x * 20.0)));
            } else if (m > 30.5) {     // console body: dark painted metal
                alb = vec3(0.13, 0.12, 0.14) * (0.8 + 0.4 * vn(p * vec3(30.0, 4.0, 30.0)));
            } else if (m > 29.5) {     // console screens: a cold grid and slow amber bars
                alb = vec3(0.01, 0.02, 0.03);
                vec2 g = p.xz * 46.0; float gl = smoothstep(0.06, 0.0, min(abs(fract(g.x) - 0.5), abs(fract(g.y) - 0.5)) - 0.44);
                float bar = step(fract(p.x * 9.0 + 0.3), 0.55) * step(h31(vec3(floor(p.x * 9.0), 3.0, floor(uTime * 0.5))), 0.7);
                emis += vec3(0.2, 0.7, 0.85) * (0.05 + 0.22 * gl) * (1.0 - 0.6 * uHeat) + vec3(1.0, 0.6, 0.2) * bar * smoothstep(0.0, 0.2, fract(p.z * 6.0)) * 0.3;
            } else {                   // lamps on the console, failing
                alb = vec3(0.05);
                emis += mix(vec3(1.0, 0.55, 0.15), vec3(0.2, 0.9, 1.0), step(0.5, fract(p.x * 3.3))) * (0.25 + 0.75 * step(0.5, fract(uTime * 0.6 + p.x * 2.0))) * (1.0 - 0.7 * uHeat);
            }
        } else if (m > 10.5 && m < 13.5) {   // light: the child's scan line (11), lines of light (12)
            alb = vec3(0.03, 0.05, 0.07);
            if (m < 11.5) emis = vec3(0.6, 1.0, 1.0) * 1.8;
            else {
                vec3 hc = mix(vec3(0.3, 0.95, 1.0), vec3(1.0, 0.4, 0.9), step(0.8, h31(floor(vec3(p.y * 1.79, p.z * 0.55, sign(p.x))))) * float(uShot == 1));
                float pu = uShot == 1 ? 0.35 + 0.9 * (0.5 + 0.5 * sin(p.z * 0.9 - uTime * 2.4)) : 1.0 + 0.3 * sin(uTime * 2.0 + p.y * 9.0 + p.z * 5.0);
                emis = hc * 1.2 * pu;
            }
        } else if (m < 0.5) alb = uShot == 0 ? vec3(0.55, 0.38, 0.28) : (uShot == 1 ? vec3(0.25, 0.28, 0.4) : vec3(0.42, 0.4, 0.42));
        else if (m < 1.5) alb = uShot == 0 ? mix(vec3(0.3, 0.42, 0.42), vec3(0.95, 0.7, 0.52), smoothstep(0.85, 1.05, p.y)) : (uShot == 1 ? vec3(0.34, 0.38, 0.52) : vec3(0.34, 0.36, 0.42));
        else if (m < 2.5) alb = uShot == 0 ? vec3(0.62, 0.38, 0.22) : (uShot == 1 ? vec3(0.2, 0.2, 0.3) : vec3(0.3, 0.24, 0.2));
        else if (m < 3.5) alb = vec3(0.22, 0.25, 0.34);
        else if (m < 4.5) { alb = vec3(0.0); emis = skyCol(rd, p); }
        else if (m < 5.5) alb = vec3(0.6, 0.25, 0.28) * (0.8 + 0.4 * step(0.5, fract(length(p.xz) * 2.5)));
        else if (m < 6.5) alb = vec3(0.85, 0.7, 0.52);
        else if (m < 7.5) alb = uShot == 3 ? vec3(0.95, 0.85, 0.7) : vec3(0.95, 0.78, 0.6);
        else if (m < 8.5) { alb = m > 7.9 && uShot == 1 ? vec3(0.85, 0.88, 0.95) : vec3(0.78, 0.76, 0.72); if (uShot == 1) emis = vec3(0.5, 0.55, 0.7) * 0.8; }
        else { alb = vec3(0.9, 0.7, 0.25); emis = vec3(1.0, 0.8, 0.4) * (0.35 + 1.6 * pow(max(0.0, sin(uTime * 3.1 + p.x * 40.0)), 24.0)); }
        // moonlit windows and light pools in the corridor, a warm doorway
        float wallish = (1.0 - abs(n.y));
        if (uShot == 1 && m < 1.5 && wallish > 0.8 && abs(p.x) > 2.0) {
            float zz = mod(p.z + 1.2, 3.6) - 1.8;
            if (p.y > 2.9 && p.y < 4.3 && abs(zz) < 0.55) emis = vec3(0.55, 0.65, 0.95) * 1.5;
        }
        if (uShot == 1 && m < 1.5 && n.y > 0.9 && p.y < 0.2) emis += vec3(0.3, 0.95, 1.0) * smoothstep(0.03, 0.0, abs(p.x) - 0.02) * (0.4 + 0.6 * (0.5 + 0.5 * sin(p.z * 1.4 - uTime * 3.0)));   // a line of light along the floor, toward the door
        if (uShot == 4 && uWaveR > 0.5) emis += vec3(0.35, 0.95, 1.0) * smoothstep(3.2, 0.0, abs(length(p - ro) - (uWaveR - 3.5))) * 1.7 * (1.0 - smoothstep(70.0, 100.0, uWaveR));   // the ring of light itself
        n = normalize(n + (brush - 0.5) * 0.16 * (1.0 - abs(n.y) * 0.3));
        float dif = clamp(dot(n, L) * 0.5 + 0.5, 0.0, 1.0); dif *= dif;
        float sh = (uShot == 1 || uShot == 5) ? 1.0 : softShadow(p + n * 0.03, L, 22.0);
        float ao = calcAO(p, n);
        vec3 lit = alb * (amb * (0.55 + 0.45 * n.y) * ao + Lc * dif * sh * ao * uLight * (uShot == 1 ? 0.6 : 1.0));
        if (uShot == 1) {   // light pooling out of the doorway and falling on the floor from the windows
            vec3 dv = vec3(0.0, 1.2, uDoorZ - 1.5) - p; float dl = length(dv);
            lit += alb * vec3(1.0, 0.7, 0.35) * max(0.0, dot(n, dv / dl) * 0.6 + 0.4) * 2.4 / (1.0 + 0.06 * dl * dl) * ao;
            if (m < 0.5 || (m < 1.5 && n.y > 0.8)) { float zz = mod(p.z + 1.2, 3.6) - 1.8; float pool = smoothstep(0.9, 0.2, abs(zz)) * smoothstep(2.1, 0.5, abs(p.x)); lit += alb * vec3(0.3, 0.4, 0.8) * pool * 0.9; }
        }
        if (uShot == 0) { vec3 wv2 = vec3(0.0, 1.75, -3.4) - p; lit += alb * vec3(1.0, 0.6, 0.3) * 0.5 * smoothstep(8.0, 0.0, length(wv2)) * ao; }
        if (uShot == 2 || uShot == 3) { lit += alb * vec3(0.7, 0.75, 0.85) * uFlash * 1.2 * ao; }
        if (m > 5.9 && m < 7.5) lit += alb * vec3(1.0, 0.8, 0.62) * (uShot == 2 ? 0.7 : (uShot == 3 ? 0.08 : 0.5)) * max(dot(n, -rd), 0.0);
        if (uShot == 2 && m > 6.5 && m < 7.5) lit += vec3(0.7, 0.42, 0.2) * 0.45;
        if (m > 6.5 && m < 7.5) { lit += vec3(1.0, 0.75, 0.45) * pow(1.0 - abs(dot(n, rd)), 2.0) * (uShot == 3 ? 0.9 : 0.5); }
        if (uShot == 2 && m > 7.9 && m < 8.5) { lit += vec3(0.5, 0.55, 0.65) * (0.5 + 0.5 * dif); emis += vec3(0.4, 0.85, 1.0) * smoothstep(0.55, 0.9, dot(n, normalize(vec3(-p.x, 0.0, -p.z)))) * 0.9; }   // faces glow toward the middle of the hall
        if (uShot == 5) { vec3 wv5 = vec3(0.0, 1.4, -2.1) - p; lit += alb * Lc * 1.5 * (0.3 + max(dot(n, normalize(wv5)), 0.0)) / (1.0 + 0.35 * dot(wv5, wv5)); }
        {   // v107 step 2: each place gets its own light on its own surfaces
            float fr = pow(1.0 - abs(dot(n, rd)), 3.0);
            if (uShot == 0) lit += alb * vec3(1.0, 0.62, 0.3) * fr * (0.5 + 0.5 * max(dot(n, L), 0.0)) * 0.55 * ao;
            else if (uShot == 1) {
                vec3 dvn = normalize(vec3(0.0, 1.2, uDoorZ - 1.5) - p);
                lit += alb * vec3(1.0, 0.7, 0.36) * pow(1.0 - abs(dot(n, rd)), 2.0) * max(dot(n, dvn), 0.0) * 1.1 * ao;
                if (n.y > 0.85) { float dz = uDoorZ - p.z; emis += vec3(1.0, 0.7, 0.36) * smoothstep(1.3, 0.0, abs(p.x)) * pow(1.0 - abs(rd.y), 2.5) * 0.55 / (1.0 + 0.015 * dz * dz); }
            }
            else if (uShot == 2) {
                if (m < 0.5 && n.y > 0.8) { lit += alb * vec3(0.7, 0.85, 1.0) * smoothstep(6.5, 3.0, length(p.xz)) * 0.8;
                    emis += vec3(1.0, 0.94, 0.82) * smoothstep(1.5, 0.0, abs(p.x)) * pow(1.0 - abs(rd.y), 2.5) * 0.6 * step(0.0, p.z) / (1.0 + 0.01 * (18.0 - p.z) * (18.0 - p.z)); }
                if ((m > 2.5 && m < 3.5) || (m > 7.9 && m < 8.5)) lit += vec3(0.6, 0.8, 1.0) * pow(1.0 - abs(dot(n, rd)), 2.0) * (0.35 + 0.65 * max(n.y, 0.0)) * 0.7;
            }
            else if (uShot == 3) {
                float c1 = 1.0 - abs(2.0 * vn(vec3(p.xz * 1.2 + vec2(p.y * 0.4, 0.0), uTime * 0.22)) - 1.0), c2 = 1.0 - abs(2.0 * vn(vec3(p.zx * 2.1, uTime * 0.31 + 5.0)) - 1.0);
                float cau2 = smoothstep(0.7, 0.97, c1 * c2 + 0.25 * c1);
                lit += alb * vec3(0.7, 1.0, 0.85) * cau2 * 2.2 * max(n.y * 0.7 + 0.3, 0.0) * exp(-max(uWater - p.y, 0.0) * 0.05) * ao;
            }
            else if (uShot == 4) {
                if (m > 19.5 && m < 20.5 && orgH > 0.02) { vec3 rr = reflect(rd, n); vec3 sk = mix(vec3(0.9, 0.55, 0.35), vec3(0.35, 0.55, 0.85), clamp(rr.y * 2.5, 0.0, 1.0));
                    float f2 = 0.04 + 0.9 * pow(1.0 - abs(dot(n, rd)), 4.0); emis += (sk * 0.6 + vec3(2.0, 1.6, 1.2) * pow(max(dot(rr, L), 0.0), 50.0)) * f2 * orgH; }
                if (m > 20.5) emis += vec3(0.3, 0.9, 1.0) * fr * orgH * 0.55;
            }
            else if (uShot == 5) lit += alb * vec3(0.5, 0.7, 1.0) * fr * 0.5 * ao;
        }
        col = lit + emis;
        // paint: luminance through the scene palette, soft posterised washes, strokes
        float lum = dot(col, vec3(0.3, 0.55, 0.15));
        vec3 pal = ramp(pA, pB, pC, pD, lum * 0.8);
        col = mix(col, pal * (0.5 + 0.9 * clamp(lum, 0.0, 1.5)), uShot == 0 ? 0.3 : 0.45);
        float q = floor(clamp(lum, 0.0, 1.6) * 5.0 + (vn(vec3(p * 1.7)) - 0.5) * 0.5) / 5.0;
        col *= mix(1.0, (q + 0.08) / (lum + 0.08), 0.4);
        col *= 0.8 + 0.4 * brush;
        col *= (0.84 + 0.32 * strokeTone) * mix(vec3(0.96, 0.98, 1.04), vec3(1.04, 1.0, 0.95), strokeTone);
        col = mix(col, vec3(1.0, 0.96, 0.88) * (0.55 + 0.45 * clamp(lum, 0.0, 1.2)), smoothstep(0.5, 0.18, bristle) * smoothstep(0.5, 1.0, lum) * 0.4);   // dry brush: the paper shows through the lights
        float bf = fract(clamp(lum, 0.0, 1.6) * 5.0 + (vn(vec3(p * 1.7)) - 0.5) * 0.5);
        col *= 1.0 - 0.08 * (smoothstep(0.1, 0.0, bf) + smoothstep(0.9, 1.0, bf));                                              // a wet edge where one wash meets the next
        float rim = pow(1.0 - abs(dot(n, rd)), 2.5);
        col = mix(col, pA * 0.8, rim * 0.35);
    } else {
        col = uShot == 5 ? driftPaint(rd, uv0) : (uShot == 4 ? skyCol(rd, ro) : fogc * 0.7);
        if (uShot != 5) col *= 0.88 + 0.24 * vn(vec3(uv0 * vec2(2.2, 15.0) + vec2(0.0, uTime * 0.02), 5.0)) * (0.7 + 0.6 * vn(vec3(uv0 * vec2(0.9, 5.0), 8.0)));
    }
    // depth discontinuities become pooled pigment: a soft dark line round every shape
    float dt = fwidth(tHit) / (tHit + 0.6);
    edgeW = smoothstep(0.03, 0.22, dt);
    { vec3 dk = col * col * 0.75 + pA * 0.18;                                       // pigment pools at the edge: darker and richer, not grey
      col = mix(col, dk, edgeW * 0.62 * (0.6 + 0.8 * vn(vec3(uv * 60.0, 1.0)))); }
    // haze: a wash of the scene's colour with distance
    float fog = 1.0 - exp(-tHit * fogd);
    // the water
    if (uShot == 3) {
        float uw = 0.0; float tw = 1e5;
        if (rd.y != 0.0) tw = (uWater - ro.y) / rd.y;
        if (ro.y < uWater) uw = (rd.y > 0.0 && tw > 0.0) ? min(tHit, tw) : tHit;
        else if (tw > 0.0 && tw < tHit) uw = tHit - tw;
        vec3 wc = vec3(0.04, 0.2, 0.25);
        float depthLight = exp(-max(0.0, uWater - (ro.y + rd.y * min(tHit, 40.0))) * 0.11);
        float a = (1.0 - exp(-uw * 0.09));
        wc *= 0.5 + 1.2 * depthLight;
        col = mix(col, wc * (1.0 + 0.4 * vn(vec3(uv * 4.0, uTime * 0.3))), a * 0.95);
        if (tw > 0.0 && tw < tHit) {
            vec3 sp = ro + rd * tw; float rip = fbm(vec3(sp.xz * 1.8, uTime * 0.25));
            float fres = pow(1.0 - clamp(abs(rd.y), 0.0, 1.0), 2.0);
            col += vec3(1.0, 0.9, 0.6) * (0.2 + 0.5 * rip) * (0.25 + fres) * (ro.y > uWater ? 0.8 : 0.45);
        }
        float cau = pow(0.5 + 0.5 * sin(vn(vec3(ro.xz + rd.xz * tHit, uTime * 0.2)) * 18.0), 6.0);
        if (ro.y < uWater) col += vec3(0.5, 0.7, 0.5) * cau * 0.12 * a;
    }
    col = mix(col, fogc, fog * (hit ? 0.75 : 0.0));
    if (uShot == 4) { float mist = 1.0 - exp(-min(tHit, 60.0) * 0.011 * exp(-max(ro.y + rd.y * tHit * 0.5, 0.0) * 0.45)); col = mix(col, fogc * 1.08, mist * 0.5); }   // ground mist: the valley goes back in layers
    col += (airFx(ro, rd, tHit, L) * uLight + glowAcc) * (1.0 - clamp(uWhite, 0.0, 1.0));
    if (uShot == 3 && uChild.w > 0.01) {
        vec3 cd = normalize(uChildPos + vec3(0.0, 0.8 * uChild.y, 0.0) - ro); float fw = dot(cd, uF);
        if (fw > 0.05) { vec2 su = vec2(dot(cd, uR), dot(cd, uU)) / fw / (uTanFov * 1.6); vec2 dv3 = uv0 - su; float ds = length(dv3), an2 = atan(dv3.y, dv3.x);
            col += vec3(0.75, 1.0, 0.95) * uChild.w * (0.28 * exp(-ds * ds * 16.0) + 0.1 * exp(-ds * 2.6) + 0.09 * pow(abs(cos(an2 * 5.0 + uTime * 0.15)), 30.0) * exp(-ds * 3.0)) * (1.0 - clamp(uWhite, 0.0, 1.0)); }
    }
    if (uShot == 0) {
        vec2 oc2 = ro.xz - vec2(-1.5, -0.4); float a2 = dot(rd.xz, rd.xz);
        if (a2 > 1e-4) { float ts = -dot(oc2, rd.xz) / a2; float py = ro.y + rd.y * ts;
            if (ts > 0.1 && ts < tHit && py > 0.78 && py < 2.4) {
                float hs = py - 0.78; vec2 q2 = oc2 + rd.xz * ts - 0.1 * vec2(sin(hs * 3.2 + uTime * 0.7), cos(hs * 2.7 + uTime * 0.5));
                float rad = 0.035 + 0.13 * hs, thick = clamp(rad / sqrt(a2) * 2.5, 0.0, 1.0);
                float st = smoothstep(rad, 0.0, length(q2)) * smoothstep(1.7, 0.3, hs) * (0.55 + 0.9 * vn(vec3(q2 * 9.0, hs * 2.5 - uTime * 0.5)));
                col += vec3(1.0, 0.82, 0.62) * st * thick * 0.5 * (1.0 - clamp(uWhite, 0.0, 1.0));
            } }
    }
    // grade, paper grain, soft vignette
    col *= 1.0 + uFlash * 0.4;
    { vec3 a = col * 0.95; vec3 aces = clamp((a * (2.51 * a + 0.03)) / (a * (2.43 * a + 0.59) + 0.14), 0.0, 1.0);
      col = mix(col / (1.0 + col * 0.45), aces, 0.25); }
    col = pow(max(col, 0.0), vec3(0.9));
    {   // each dream has its own grade: cool shadows under warm light, warm light under cold shadow
        float lg = dot(col, vec3(0.3, 0.55, 0.15));
        vec3 gS = uShot == 0 ? vec3(0.93, 0.97, 1.08) : (uShot == 1 ? vec3(0.94, 0.96, 1.12) : (uShot == 2 ? vec3(0.95, 0.98, 1.1) : (uShot == 3 ? vec3(0.9, 1.03, 1.06) : (uShot == 4 ? vec3(0.92, 1.0, 1.06) : vec3(0.94, 0.95, 1.1)))));
        vec3 gH = uShot == 0 ? vec3(1.07, 1.0, 0.9) : (uShot == 1 ? vec3(1.06, 1.0, 0.92) : (uShot == 2 ? vec3(1.0, 1.02, 1.06) : (uShot == 3 ? vec3(1.06, 1.03, 0.92) : (uShot == 4 ? vec3(1.08, 1.0, 0.9) : vec3(1.07, 1.0, 0.92)))));
        col *= mix(gS, gH, smoothstep(0.04, 0.8, lg));
        col = mix(vec3(lg), col, 1.1);
        col += max(col - 0.85, 0.0) * 0.1;                                          // halation round the brightest things
    }
    float paper = vn(vec3(gl_FragCoord.xy * 0.55, 2.0)) * 0.5 + vn(vec3(gl_FragCoord.xy * 0.13, 7.0)) * 0.5;
    col *= 0.95 + 0.1 * paper;
    { float fib = vn(vec3(gl_FragCoord.x * 0.9, gl_FragCoord.y * 0.07, 5.0)) * 0.5 + vn(vec3(gl_FragCoord.x * 0.07, gl_FragCoord.y * 0.9, 6.0)) * 0.5;
      float lg2 = dot(col, vec3(0.3, 0.55, 0.15)), gran = smoothstep(0.55, 0.85, vn(vec3(gl_FragCoord.xy * 0.8, 4.0)));
      col *= 1.0 - 0.07 * (fib - 0.5) * 2.0 * smoothstep(0.2, 0.8, lg2);
      col *= 1.0 - 0.14 * gran * (1.0 - smoothstep(0.1, 0.7, lg2)); }
    float vg = dot(uv, uv); col *= 1.0 - smoothstep(0.18, 0.75, vg) * 0.55;
    if (uSunB > 0.001) {                                                           // the sun in the window blooms (and is the same sun that is straight ahead in the green)
        vec3 sd = uShot == 0 ? normalize(vec3(0.12, 0.02, -1.0)) : normalize(vec3(0.0, 0.07, -1.0));
        float fw = dot(sd, uF); vec2 su = vec2(dot(sd, uR), dot(sd, uU)) / max(fw, 0.05) / (uTanFov * 1.6);
        float dsu = length(uv0 - su);
        col += vec3(1.0, 0.78, 0.45) * uSunB * (1.4 * exp(-dsu * dsu * 7.0) + 0.5 * exp(-dsu * 2.2));
        vec2 dv2 = uv0 - su;
        col += vec3(1.0, 0.7, 0.4) * uSunB * 0.75 * exp(-abs(dv2.y) * 34.0) * exp(-abs(dv2.x) * 1.5);                 // anamorphic streak
        float an = atan(dv2.y, dv2.x); col += vec3(1.0, 0.85, 0.6) * uSunB * 0.22 * pow(abs(cos(an * 3.0 + 0.4)), 36.0) * exp(-dsu * 2.6);   // a soft star of rays
        for (int g = 0; g < 2; g++) { float fg = float(g); vec2 gp = -su * (0.45 + 0.5 * fg); float gd = length(uv0 - gp);   // ghosts: lens reflections on the far side of the frame
            col += mix(vec3(0.4, 0.8, 1.0), vec3(1.0, 0.55, 0.3), fg) * uSunB * uSunB * (0.10 - 0.04 * fg) * smoothstep(0.085 + 0.05 * fg, 0.06 + 0.05 * fg, gd) * (0.5 + 0.5 * smoothstep(0.05, 0.0, abs(gd - (0.07 + 0.05 * fg)))); }
    }
    if (uStreak > 0.001) {                                                         // burning in: streaks from the centre, heat at the edges
        float ang = atan(uv0.y, uv0.x), rad = length(uv0);
        float ln = h31(vec3(floor(ang * 80.0), floor(uTime * 22.0), 3.0));
        float sl = smoothstep(0.5, 1.0, ln) * smoothstep(0.08, 0.7, rad) * uStreak;
        col = mix(col, vec3(1.0, 0.45, 0.12) * 1.1, 0.35 * uStreak * smoothstep(0.05, 0.75, rad));
        col += vec3(1.0, 0.72, 0.4) * sl * 1.8;
        col += vec3(1.0, 0.45, 0.12) * uStreak * 0.14 * smoothstep(0.25, 0.95, rad);
    }
    if (uBubble > 0.001) {
        float rr0 = length(uv0), ringP = (1.0 - uBubble) * 1.3;                    // the splash's pressure ring and a flash of foam
        col += vec3(0.5, 0.9, 1.0) * smoothstep(0.05, 0.0, abs(rr0 - ringP)) * uBubble * uBubble * 0.45 + vec3(0.8, 1.0, 1.0) * smoothstep(0.9, 1.0, uBubble) * 0.08;
    }
    if (uBubble > 0.001) {                                                         // the splash: bubbles lift past the lens
        for (int b = 0; b < 16; b++) {
            float fb = float(b);
            vec2 bp = vec2((h31(vec3(fb, 1.0, 7.0)) - 0.5) * 1.7 + sin(uLT * 2.0 + fb) * 0.02, fract(h31(vec3(fb, 3.0, 7.0)) + uLT * (0.15 + 0.25 * h31(vec3(fb, 2.0, 7.0))) * 0.4) - 0.5);
            float rr = 0.012 + 0.03 * h31(vec3(fb, 4.0, 7.0)), dd = length(uv0 - bp) - rr;
            col += vec3(0.7, 0.95, 1.0) * smoothstep(0.004, 0.0, abs(dd)) * 0.55 * uBubble + vec3(0.5, 0.8, 0.9) * smoothstep(0.0, -rr, dd) * 0.05 * uBubble;
        }
    }
    if (uShatter > 0.001) { col += vec3(1.0, 0.97, 0.9) * shardE * 1.4 * uShatter; col *= shardM;
        col += (vec3(1.0, 0.72, 0.4) * shardE * 0.55 + vec3(0.4, 0.8, 1.0) * shardE * shardE * 0.25) * uShatter * (1.0 - shardM * 0.5); }
    col = mix(col, vec3(1.0, 0.97, 0.9), clamp(uWhite, 0.0, 1.0));
    if (uGlitch > 0.001) {                                                         // slabs of flat light, a colour split, scan lines
        float tb = h31(vec3(floor(gl_FragCoord.y / (uRes.y * 0.05)), floor(uTime * 12.0), 9.0));
        float ta = step(0.9 - 0.25 * uGlitch, tb) * step(h31(vec3(floor(gl_FragCoord.x / (uRes.x * 0.18)), floor(uTime * 12.0), 8.0)), 0.5 + 0.4 * uGlitch);
        col = mix(col, vec3(0.2, 0.95, 1.0) * 1.1 + 0.2, ta * 0.6 * uGlitch);
        col.r += uGlitch * 0.15 * step(0.7, tb); col.b += uGlitch * 0.12 * step(0.5, h31(vec3(floor(gl_FragCoord.y / (uRes.y * 0.02)), floor(uTime * 20.0), 5.0)));
        col *= 1.0 - 0.18 * uGlitch * step(0.5, fract(gl_FragCoord.y * 0.5));
        float sy = fract(uTime * 0.8) * 1.4 - 0.7;
        col += vec3(0.3, 1.0, 1.0) * smoothstep(0.02, 0.0, abs(uv0.y - sy)) * uGlitch * 0.7 + vec3(1.0, 0.3, 0.9) * smoothstep(0.012, 0.0, abs(uv0.y - sy - 0.03)) * uGlitch * 0.35;
        col.g *= 1.0 - 0.1 * uGlitch * step(0.6, h31(vec3(floor(gl_FragCoord.y / (uRes.y * 0.03)), floor(uTime * 16.0), 11.0)));
    }
    if (uLid > 0.001) {                                                            // eyelids: an eye-shaped slit that opens and closes
        float o = 1.0 - uLid, c = uv0.x * uv0.x * 0.9, lim = o * (0.78 - c * 0.3);
        float mk = smoothstep(lim, lim - 0.04, abs(uv0.y - 0.04 * uLid));
        col = mix(col, vec3(0.35, 0.08, 0.05), smoothstep(lim - 0.09, lim, abs(uv0.y)) * 0.7 * min(1.0, uLid * 3.0));
        col += vec3(1.0, 0.62, 0.4) * smoothstep(0.035, 0.0, abs(abs(uv0.y - 0.04 * uLid) - lim)) * 0.28 * min(1.0, uLid * 2.0) * step(0.001, lim);
        col *= mk;
        col += vec3(0.55, 0.12, 0.06) * 0.22 * uLid * (1.0 - mk * 0.0) * smoothstep(0.0, 0.5, 1.0 - abs(uv0.y) * 1.5) * (1.0 - mk) ;
    }
    col = mix(col, vec3(0.0), clamp(uBlack, 0.0, 1.0));
    oc = vec4(col, 1.0);
}`;
// ---- audio ------------------------------------------------------------------------------------------------------------------
// People are made from a glottal source (a sawtooth with vibrato and jitter), three formant filters that glide between vowels, a
// breath-noise layer for consonants, and a syllable rhythm with phrase pauses and falling pitch. Heard through a low-pass (a wall,
// a door, a hall, the water) and a long reverb, they are unmistakably people talking, and no one is saying anything.
const VOWELS = [[730, 1090, 2440], [530, 1840, 2480], [270, 2290, 3010], [570, 840, 2410], [300, 870, 2240], [660, 1720, 2410], [490, 1350, 1690]];
const WHO = {
    woman: { f0: 205, fs: 1.14, q: 1.0, breath: 0.10 },
    man:   { f0: 112, fs: 0.95, q: 1.0, breath: 0.08 },
    deep:  { f0: 92,  fs: 0.9,  q: 1.0, breath: 0.07 },
    child: { f0: 330, fs: 1.30, q: 1.1, breath: 0.12 },
};
// A phrase of speech-shaped gibberish: [{t, d, v:[f1,f2,f3], a, p0, p1, b}] in seconds from 0
function speechScore(seed, dur, o) {
    const rnd = (() => { let s = seed * 9301 + 49297; return () => { s = (s * 9301 + 49297) % 233280; return s / 233280; }; })();
    const rate = o.rate || 4.5, out = []; let t = o.t0 || 0;
    while (t < dur) {
        const nSyl = 3 + Math.floor(rnd() * 7);                          // a phrase
        const base = 1 + (rnd() - 0.5) * 0.18 + (o.lift || 0);
        for (let i = 0; i < nSyl && t < dur; i++) {
            const d = (0.09 + rnd() * 0.15) / (rate / 4.5), shape = 1 - i / nSyl;
            const stress = (i === 1 || (rnd() < 0.18)) ? 1.18 : 1.0;
            const v = VOWELS[Math.floor(rnd() * VOWELS.length)];
            const p0 = base * (1 + (o.flat ? 0.0 : 0.09) * shape) * stress * (1 + (o.mono ? 0 : (rnd() - 0.5) * 0.08));
            out.push({ t, d, v, a: (0.55 + rnd() * 0.45) * (stress > 1 ? 1.2 : 1), p0, p1: p0 * (o.flat ? 1.0 : (0.96 - 0.05 * (i === nSyl - 1 ? 1 : 0))), b: rnd() < 0.45 ? 1 : 0, f: rnd() < 0.25 ? 1 : 0 });
            t += d * (0.9 + rnd() * 0.5);
        }
        t += (o.pause || 0.35) * (0.4 + rnd() * 1.3);                    // breath between phrases
        if (o.rise && rnd() < 0.2) t += 0.2;
    }
    return out;
}
function laughScore(n, o) {
    const out = []; let t = 0; const period = 1 / (o.hz || 5.2);
    for (let i = 0; i < n; i++) {
        const k = i / Math.max(1, n - 1), p = (o.p0 || 1.25) * (1 - 0.25 * k);
        out.push({ t, d: period * (i === n - 1 ? 1.6 : 0.62), v: [820 - 90 * k, 1200 + 60 * k, 2900], a: (1 - 0.45 * k) * (o.a || 1), p0: p, p1: p * 0.93, b: 1, f: 0, laugh: 1 });
        t += period * (1 + (Math.random() - 0.5) * 0.12) * (1 + 0.1 * k);
    }
    return out;
}

// footfall times for a walk: one per STEP of distance, when the head is at the bottom of its bob (so sound, bob and picture agree)
function footTimes(fn, dur) {
    const out = []; let n = Math.floor(fn(0) / STEP - 0.5);
    for (let lt = 0.02; lt <= dur; lt += 0.02) { const cur = fn(lt) / STEP - 0.5; if (Math.floor(cur) > n) { n = Math.floor(cur); out.push([lt, clamp01(((fn(lt) - fn(lt - 0.1)) / 0.1) / 0.9), n & 1]); } }
    return out;
}

// note names -> Hz, so the score reads like a score
const NOTE_IDX = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };
const hz = (n) => { const m = /^([A-G])([#b]?)(-?\d)$/.exec(n); return 440 * Math.pow(2, (NOTE_IDX[m[1]] + (m[2] === '#' ? 1 : (m[2] === 'b' ? -1 : 0)) + (+m[3] + 1) * 12 - 69) / 12); };
const hzs = (s) => s.split(' ').map(hz);

// A synthetic room: decorrelated stereo noise with an exponential decay, a tail that darkens as it dies (a0 -> a1 is the low-pass
// coefficient), a pre-delay, a slow or fast bloom, and a few early reflections (ms, gain) so the room has walls, not just a tail.
function makeIR(ctx, o) {
    const sr = o.sr || ctx.sampleRate, n = Math.floor(sr * o.secs), b = ctx.createBuffer(2, n, sr), pre = o.pre || 0, build = o.build || 0.01;
    for (let c = 0; c < 2; c++) {
        const d = b.getChannelData(c); let lp = 0;
        for (let i = 0; i < n; i++) {
            const t = i / sr, x = i / n, u = clamp01((t - pre) / build), a = o.a0 + (o.a1 - o.a0) * (1 - Math.exp(-t / (o.secs * 0.3)));
            lp += (Math.random() * 2 - 1 - lp) * a;
            d[i] = t < pre ? 0 : lp * Math.sqrt((2 - a) / a) * 0.5 * Math.pow(1 - x, o.decay) * u * u * (3 - 2 * u);
        }
        for (const [ms, g] of (o.early || [])) { const k = Math.floor((pre + ms / 1000 + c * 0.0011 + (hash1(ms * 3.1 + c) - 0.5) * 0.0008) * sr), sg = hash1(ms + c * 9.7) < 0.3 ? -1 : 1; if (k > 1 && k < n - 2) { d[k - 1] += 0.25 * sg * g; d[k] += 0.5 * sg * g; d[k + 1] += 0.25 * sg * g; } }
    }
    return b;
}

// everything that is expensive to build and the same every time: made once per audio context
const AUDIO_CACHE = new WeakMap();
function audioAssets(ctx) {
    let A = AUDIO_CACHE.get(ctx); if (A) return A;
    const sr = ctx.sampleRate, n = sr * 8, stereo = (fn) => { const b = ctx.createBuffer(2, n, sr); for (let c = 0; c < 2; c++) fn(b.getChannelData(c)); return b; };
    A = { waves: {} };
    // the old "everything" noise (a little white, a lot of low-passed white), but 8 s long and different in each ear
    A.base = stereo((d) => { let l = 0; for (let i = 0; i < n; i++) { const w = Math.random() * 2 - 1; l = 0.97 * l + 0.03 * w; d[i] = w * 0.6 + l * 3.0; } });
    A.pink = stereo((d) => { let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0; for (let i = 0; i < n; i++) { const w = Math.random() * 2 - 1; b0 = 0.99886 * b0 + w * 0.0555179; b1 = 0.99332 * b1 + w * 0.0750759; b2 = 0.969 * b2 + w * 0.153852; b3 = 0.8665 * b3 + w * 0.3104856; b4 = 0.55 * b4 + w * 0.5329522; b5 = -0.7616 * b5 - w * 0.016898; d[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + w * 0.5362) * 0.32; b6 = w * 0.115926; } });
    A.brown = stereo((d) => { let l = 0; for (let i = 0; i < n; i++) { l = (l + 0.02 * (Math.random() * 2 - 1)) / 1.02; d[i] = l * 6.0; } });
    A.irA = makeIR(ctx, { secs: 1.1, decay: 3.0, pre: 0.003, build: 0.004, a0: 0.55, a1: 0.14, early: [[2.3, 0.5], [4.1, 0.42], [6.7, 0.36], [9.2, 0.3], [13, 0.22], [17, 0.18], [23, 0.12]] });                    // a room: kitchen, cabin
    A.irB = makeIR(ctx, { secs: 2.4, decay: 2.9, pre: 0.028, build: 0.05, a0: 0.5, a1: 0.07, early: [[11, 0.4], [19, 0.33], [31, 0.3], [44, 0.24], [58, 0.2], [79, 0.15]] });                          // a hall: corridor, the hearing
    A.irC = makeIR(ctx, { secs: 2.2, decay: 2.6, pre: 0.012, build: 0.12, a0: 0.28, a1: 0.05 });                                                                                                            // dark, slow to bloom: the water, the light
    AUDIO_CACHE.set(ctx, A); return A;
}

// which space each scene sits in: [room, hall, dream] send levels, and how much of the echo (ping-pong delay) it gets
const SPACES = [[1.0, 0.12, 0.0], [0.25, 0.55, 0.12], [0.1, 1.0, 0.1], [0.04, 1.0, 0.12], [1.0, 0.0, 0.25], [0.15, 0.25, 1.0]];
const ECHO = [0.5, 0.95, 0.9, 0.15, 0.45, 0.8];

function createAudio(ctx) {
    const AS = audioAssets(ctx);
    const mk = (type, f, q) => { const b = ctx.createBiquadFilter(); b.type = type; try { b.frequency.automationRate = 'k-rate'; b.Q.automationRate = 'k-rate'; b.detune.automationRate = 'k-rate'; b.gain.automationRate = 'k-rate'; } catch (e) {} b.frequency.value = f; if (q !== undefined) b.Q.value = q; return b; };   // v106: k-rate, so a gliding formant does not recompute its coefficients on every sample
    const G = (v) => { const g = ctx.createGain(); g.gain.value = v; return g; };
    const nodes = [];                                                    // everything that never stops by itself: stopped at the end
    const keep = (n) => { nodes.push(n); return n; };

    // ---- the bus: everything -> sum -> sub-cut -> "eyes" muffle -> air -> master -> glue compressor -> limiter -> soft clip -> out ---------------
    const master = G(0);
    const comp = ctx.createDynamicsCompressor(); comp.threshold.value = -24; comp.knee.value = 12; comp.ratio.value = 6; comp.attack.value = 0.01; comp.release.value = 0.25;
    const lim = ctx.createDynamicsCompressor(); lim.threshold.value = -14; lim.knee.value = 0; lim.ratio.value = 20; lim.attack.value = 0.002; lim.release.value = 0.1;
    const clip = ctx.createWaveShaper(); { const c = new Float32Array(2049); for (let i = 0; i < 2049; i++) c[i] = Math.tanh((i / 1024 - 1) * 1.2) / Math.tanh(1.2); clip.curve = c; }
    const outG = G(0.32);
    const sum = G(1), subCut = mk('highpass', 30, 0.7), muffle = mk('lowpass', 19000, 0.6), air = mk('highshelf', 8500); air.gain.value = 2.5;
    sum.connect(subCut); subCut.connect(muffle); muffle.connect(air); air.connect(master); master.connect(comp); comp.connect(lim); lim.connect(clip); clip.connect(outG); outG.connect(ctx.destination);
    const dry = G(1); dry.connect(sum);
    // three rooms, each fed by its own send; the scene decides how much of each is open
    const rvIn = G(1), rvSend = [], rvConv = [], rvOut = G(0.6); rvOut.connect(sum);
    [AS.irA, AS.irB, AS.irC].forEach((ir) => { const s = G(0), cv = ctx.createConvolver(); cv.buffer = ir; rvIn.connect(s); s.connect(cv); cv.connect(rvOut); rvSend.push(s); rvConv.push(cv); });
    // a dark ping-pong echo for the bells and the music
    const dlyIn = G(0), dlp = mk('lowpass', 3000, 0.5), dl = ctx.createDelay(2), dr = ctx.createDelay(2), dfb = G(0.5), pL = ctx.createStereoPanner ? ctx.createStereoPanner() : G(1), pR = ctx.createStereoPanner ? ctx.createStereoPanner() : G(1);
    dl.delayTime.value = 0.34; dr.delayTime.value = 0.52; if (pL.pan) { pL.pan.value = -0.65; pR.pan.value = 0.65; }
    dlyIn.connect(dlp); dlp.connect(dl); dl.connect(dr); dr.connect(dfb); dfb.connect(dl); dl.connect(pL); dr.connect(pR); pL.connect(sum); pR.connect(sum);

    try { const L = ctx.listener; for (const k of ['positionX', 'positionY', 'positionZ', 'forwardX', 'forwardY', 'forwardZ', 'upX', 'upY', 'upZ']) if (L[k]) L[k].automationRate = 'k-rate'; } catch (e) {}

    // a source goes to: the dry bus (panned, or placed in space for headphones), the rooms, and the echo
    const send = (src, dryAmt, wetAmt, pan, echoAmt) => {
        let tail = src, wetFrom = null;
        if (pan && typeof pan === 'object') {                            // placed in the world (HRTF); the listener follows the camera
            try {
                const p = ctx.createPanner(); p.panningModel = pan.eq ? 'equalpower' : 'HRTF'; p.distanceModel = 'inverse'; p.refDistance = 1; p.rolloffFactor = 0;
                try { for (const k of ['positionX', 'positionY', 'positionZ', 'orientationX', 'orientationY', 'orientationZ']) if (p[k]) p[k].automationRate = 'k-rate'; } catch (e) {}   // v106: the listener moves every frame; sample-accurate angles for every placed voice were the hearing's biggest cost
                if (p.positionX) { p.positionX.value = pan.x; p.positionY.value = pan.y || 0; p.positionZ.value = pan.z; } else p.setPosition(pan.x, pan.y || 0, pan.z);
                src.connect(p); tail = p; wetFrom = src;
                if (pan.ref) pan.ref.node = p;
            } catch (e) { const sp = ctx.createStereoPanner(); sp.pan.value = Math.max(-1, Math.min(1, pan.x / 6)); src.connect(sp); tail = sp; }
        } else if (pan !== undefined && ctx.createStereoPanner) { const p = ctx.createStereoPanner(); p.pan.value = Math.max(-1, Math.min(1, pan)); src.connect(p); tail = p; }
        const d = G(dryAmt); tail.connect(d); d.connect(dry);
        if (wetAmt) { const w = G(wetAmt); (wetFrom || tail).connect(w); w.connect(rvIn); }
        if (echoAmt) { const e = G(echoAmt); (wetFrom || tail).connect(e); e.connect(dlyIn); }
        return tail;
    };

    // the music's own buses: one per send recipe, so the whole score can be ducked (the dark) and hushed (the third blow) together
    const mbus = {};
    const msend = (src, dryAmt, wetAmt, pan, echoAmt) => {
        const key = dryAmt + '/' + wetAmt + '/' + (echoAmt || 0); let b = mbus[key]; if (!b) { b = mbus[key] = G(1); send(b, dryAmt, wetAmt, undefined, echoAmt); }
        if (pan && ctx.createStereoPanner) { const p = ctx.createStereoPanner(); p.pan.value = Math.max(-1, Math.min(1, pan)); src.connect(p); p.connect(b); } else src.connect(b);
    };
    // finite noise (started when it is needed, stopped when it is done) or an endless bed; kinds: base, pink, brown
    const noise = (at, len, kind) => {
        const s = ctx.createBufferSource(); s.buffer = AS[kind || 'base']; s.loop = true; const st = Math.max(0, at === undefined ? 0 : at);
        s.start(st, Math.random() * 6.5); if (len !== undefined) s.stop(st + len); else keep(s); return s;
    };
    const glotWave = (tilt, evenCut) => { const key = tilt + '/' + evenCut; if (AS.waves[key]) return AS.waves[key]; const N = 48, re = new Float32Array(N + 1), im = new Float32Array(N + 1); for (let n = 1; n <= N; n++) im[n] = Math.pow(n, -tilt) * (n % 2 ? 1 : evenCut); return (AS.waves[key] = ctx.createPeriodicWave(re, im)); };
    const TILT = { woman: [1.3, 0.75], man: [1.2, 0.8], deep: [1.15, 0.8], child: [1.1, 0.85] };

    // ---- a person: plays a score through formant filters ---------------------------------------------------------------
    // (v105: a rounder glottal source, five formants instead of three, tiny consonant bursts, a little pitch drift; voices placed around
    // the listener are heard with HRTF, so the watchers really do stand around you)
    function person(at, score, who, o) {
        const W = WHO[who] || WHO.woman, end = at + (score.length ? score[score.length - 1].t + score[score.length - 1].d + 0.6 : 0.2);
        let stopAt = end; if (o.cutAt) stopAt = Math.min(stopAt, o.cutAt);
        const dist = o.dist === undefined ? 0.3 : o.dist, f0 = W.f0 * (o.pitch || 1), tail = stopAt + 0.5, life = tail - at + 0.1;
        const lite = !!o.lite, nF = lite ? 3 : 5;                      // v106: a background voice is a murmur: three formants, no jitter oscillator, no consonant bursts
        const osc = ctx.createOscillator(); const tl = TILT[who] || TILT.woman; osc.setPeriodicWave(glotWave(tl[0], tl[1])); osc.frequency.value = f0;
        const vib = ctx.createOscillator(); vib.frequency.value = 4.6 + Math.random() * 1.2; const vg = G(f0 * 0.009); vib.connect(vg); vg.connect(osc.frequency);
        const jit = lite ? null : ctx.createOscillator(); if (jit) { jit.frequency.value = 7.3 + Math.random() * 3; const jg = G(f0 * 0.004); jit.connect(jg); jg.connect(osc.frequency); }
        const glot = G(1); osc.connect(glot);
        const nz = noise(at, life), nbp = mk('bandpass', 3800, 0.9), ng = G(0); nz.connect(nbp); nbp.connect(ng);
        const sum2 = G(1), fs = [], FG = [1.0, 0.8, 0.55, 0.3, 0.16], FQ = [5, 9, 11, 12, 12], FX = [0, 0, 0, 3400, 4600];
        for (let i = 0; i < nF; i++) { const b = mk('bandpass', (i < 3 ? VOWELS[0][i] : FX[i]) * W.fs, FQ[i] * W.q); const g = G(FG[i]); glot.connect(b); if (i < 3) nz.connect(b); b.connect(g); g.connect(sum2); fs.push(b); }
        const amp = G(0); sum2.connect(amp); ng.connect(amp);
        const m1 = mk('lowpass', mix(7200, 420, dist) * (o.open || 1), 0.5), m2 = mk('lowpass', mix(9000, 700, dist) * (o.open || 1), 0.4);
        amp.connect(m1); m1.connect(m2);
        const tb = lite ? null : mk('bandpass', 2600, 1.4), tg = lite ? null : G(0); if (tb) { nz.connect(tb); tb.connect(tg); tg.connect(m1); }          // consonant bursts
        const gain = G(0); m2.connect(gain); send(gain, (o.gain || 0.5) * (1 - 0.55 * dist), (o.wet === undefined ? 0.25 + 0.7 * dist : o.wet) * (o.gain || 0.5), o.pos || o.pan, 0.06 * (o.gain || 0.5));
        osc.start(at); vib.start(at); if (jit) jit.start(at);
        gain.gain.setValueAtTime(0, at); gain.gain.linearRampToValueAtTime(1, at + (o.fadeIn || 0.15));
        if (o.fadeOut) { gain.gain.setValueAtTime(1, o.fadeOut[0]); gain.gain.linearRampToValueAtTime(0, o.fadeOut[1]); }
        for (const s of score) {
            const t0 = at + s.t; if (t0 > stopAt) break;
            for (let i = 0; i < 3; i++) fs[i].frequency.setTargetAtTime(s.v[i] * W.fs, Math.max(at, t0 - 0.015), 0.022);
            osc.frequency.setTargetAtTime(f0 * s.p0, Math.max(at, t0 - 0.02), 0.03);
            osc.frequency.setTargetAtTime(f0 * s.p1, t0 + s.d * 0.4, 0.06);
            const pk = (o.amp || 1) * s.a * (s.laugh ? 1.25 : 0.8);
            amp.gain.setTargetAtTime(pk, t0, s.laugh ? 0.008 : 0.016);
            amp.gain.setTargetAtTime(0.0, t0 + s.d * (s.laugh ? 0.5 : 0.72), s.laugh ? 0.03 : 0.035);
            ng.gain.setTargetAtTime((s.b ? W.breath * 2.2 : W.breath * 0.4) * (o.breath || 1) * (s.laugh ? 2.0 : 1), t0 - 0.02, 0.01);
            ng.gain.setTargetAtTime(0, t0 + s.d * 0.3, 0.03);
            if (s.f) { nbp.frequency.setValueAtTime(4800 + Math.random() * 2200, t0 - 0.03); ng.gain.setTargetAtTime(W.breath * 5 * (o.breath || 1), t0 - 0.03, 0.006); ng.gain.setTargetAtTime(0, t0 + 0.02, 0.02); }
            if (tb && !s.laugh && s.a > 0.8) { tb.frequency.setValueAtTime(1800 + hash1(t0 * 7.3) * 2800, t0 - 0.012); tg.gain.setValueAtTime(0, t0 - 0.012); tg.gain.linearRampToValueAtTime(0.1 * (o.amp || 1) * (1 - 0.7 * dist), t0 - 0.008); tg.gain.exponentialRampToValueAtTime(0.0005, t0 + 0.02); }
        }
        if (o.fadeOut) gain.gain.setValueAtTime(0, Math.max(o.fadeOut[1], at + 0.2)); else { gain.gain.setValueAtTime(1, Math.max(at + 0.16, stopAt)); gain.gain.linearRampToValueAtTime(0, tail); }   // (v106: a voice that has already faded out must not jump back up)
        osc.stop(tail + 0.05); vib.stop(tail + 0.05); if (jit) jit.stop(tail + 0.05);
    }
    const talk = (at, dur, who, seed, o = {}) => person(at, speechScore(seed, dur, o), who, o);
    const laugh = (at, n, o = {}) => person(at, laughScore(n, o), 'child', Object.assign({ gain: 0.7 }, o));

    // ---- little sounds --------------------------------------------------------------------------------------------------
    function bell(at, f, vel, dec, o = {}) {
        const g = G(0); const parts = [[1, 1], [2.76, 0.28], [5.4, 0.1], [8.9, 0.04]];
        for (const [m, a] of parts) { if (f * m > 12000) continue; const os = ctx.createOscillator(); os.type = 'sine'; os.frequency.value = f * m * (1 + (o.detune || 0) * (Math.random() - 0.5)); if (o.bend) os.frequency.linearRampToValueAtTime(f * m * o.bend, at + dec); const ag = G(a); os.connect(ag); ag.connect(g); os.start(at); os.stop(at + dec + 0.1); }
        g.gain.setValueAtTime(0, at); g.gain.linearRampToValueAtTime(vel, at + 0.004); g.gain.exponentialRampToValueAtTime(0.0008, at + dec);
        const lp = o.lp ? mk('lowpass', o.lp) : null; if (lp) { g.connect(lp); send(lp, 0.6, 0.9, o.pan, o.echo === undefined ? 0.22 : o.echo); } else send(g, 0.6, 0.9, o.pan, o.echo === undefined ? 0.22 : o.echo);
    }
    // the music box: a steel tine. A cantilever rings at 1, 6.27 and 17.5 times its note, which is that bright, glassy "pling"
    function box(at, f, vel, dec = 3.0, o = {}) {
        const g = G(1);
        for (const [m, a, ds] of [[1, 1, 1], [6.267, 0.2, 0.3], [17.55, 0.06, 0.1]]) {
            if (f * m > 15000) continue; const os = ctx.createOscillator(); os.type = 'sine'; os.frequency.value = f * m * (1 + (hash1(f * m + at) - 0.5) * 0.002);
            const ag = G(0); ag.gain.setValueAtTime(0, at); ag.gain.linearRampToValueAtTime(vel * a, at + 0.0025); ag.gain.exponentialRampToValueAtTime(0.0004, at + dec * ds); os.connect(ag); ag.connect(g); os.start(at); os.stop(at + dec * ds + 0.05);
        }
        const nz = noise(at, 0.03), bp = mk('bandpass', Math.min(9000, f * 5), 1.4), pg = G(0); nz.connect(bp); bp.connect(pg); pg.gain.setValueAtTime(0, at); pg.gain.linearRampToValueAtTime(vel * 0.6, at + 0.001); pg.gain.exponentialRampToValueAtTime(0.0004, at + 0.014); pg.connect(g);
        msend(g, 0.7, 0.8, o.pan, o.echo === undefined ? 0.4 : o.echo);
    }
    function thud(at, f0, f1, len, vel, o = {}) {
        const os = ctx.createOscillator(); os.type = 'sine'; os.frequency.setValueAtTime(f0, at); os.frequency.exponentialRampToValueAtTime(f1, at + len * 0.8);
        const g = G(0); g.gain.setValueAtTime(0, at); g.gain.linearRampToValueAtTime(vel, at + 0.006); g.gain.exponentialRampToValueAtTime(0.001, at + len);
        os.connect(g); os.start(at); os.stop(at + len + 0.05);
        if (o.knock) { const nz = noise(at, 0.12), bp = mk('bandpass', o.knock, 0.8), ng = G(0); nz.connect(bp); bp.connect(ng); ng.gain.setValueAtTime(0, at); ng.gain.linearRampToValueAtTime(vel * 0.9, at + 0.003); ng.gain.exponentialRampToValueAtTime(0.001, at + 0.09); send(ng, 0.7, o.wet === undefined ? 0.5 : o.wet, o.pan); }
        send(g, 0.9, o.wet === undefined ? 0.5 : o.wet, o.pan);
    }
    function click(at, f, vel, pan) {
        const nz = noise(at, 0.07), bp = mk('bandpass', f, 3), g = G(0); nz.connect(bp); bp.connect(g);
        g.gain.setValueAtTime(0, at); g.gain.linearRampToValueAtTime(vel, at + 0.002); g.gain.exponentialRampToValueAtTime(0.0008, at + 0.05);
        send(g, 0.8, 0.35, pan);
        const os = ctx.createOscillator(); os.frequency.value = f * 0.42; const og = G(0); os.connect(og); og.gain.setValueAtTime(0, at); og.gain.linearRampToValueAtTime(vel * 0.35, at + 0.002); og.gain.exponentialRampToValueAtTime(0.0005, at + 0.09); os.start(at); os.stop(at + 0.1); send(og, 0.8, 0.4, pan);
    }
    function patter(at, n, gap, vel, pan) { for (let i = 0; i < n; i++) { click(at + i * gap + (i % 2) * 0.03, 260 + (i % 3) * 40, vel * (0.7 + 0.3 * Math.sin(i * 1.7)), pan); } }
    function breath(at, len, vel, f) {
        const nz = noise(at, len + 0.1, 'pink'), bp = mk('bandpass', f, 0.7), g = G(0); nz.connect(bp); bp.connect(g);
        g.gain.setValueAtTime(0, at); g.gain.linearRampToValueAtTime(vel, at + len * 0.4); g.gain.linearRampToValueAtTime(0, at + len); send(g, 0.8, 0.3, 0);
    }
    function bubble(at, f, vel, pan) {
        const os = ctx.createOscillator(); os.type = 'sine'; os.frequency.setValueAtTime(f, at); os.frequency.exponentialRampToValueAtTime(f * 2.3, at + 0.055);
        const g = G(0); g.gain.setValueAtTime(0, at); g.gain.linearRampToValueAtTime(vel, at + 0.006); g.gain.exponentialRampToValueAtTime(0.0005, at + 0.07); os.connect(g); os.start(at); os.stop(at + 0.09); send(g, 0.7, 0.7, pan);
    }
    function bird(at, kind, f, pan, vel, lp) {                          // a few species of the dawn chorus
        const g = G(0), out = lp ? mk('lowpass', lp, 0.5) : null; if (out) g.connect(out);
        const tone = (t0, f0, f1, len, v, fm) => {
            const os = ctx.createOscillator(); os.type = 'sine'; os.frequency.setValueAtTime(f0, t0); os.frequency.exponentialRampToValueAtTime(f1, t0 + len);
            if (fm) { const m = ctx.createOscillator(); m.frequency.value = fm[0]; const mg = G(fm[1]); m.connect(mg); mg.connect(os.frequency); m.start(t0); m.stop(t0 + len + 0.05); }
            const eg = G(0); eg.gain.setValueAtTime(0, t0); eg.gain.linearRampToValueAtTime(v, t0 + Math.min(0.012, len * 0.3)); eg.gain.exponentialRampToValueAtTime(0.0005, t0 + len); os.connect(eg); eg.connect(g); os.start(t0); os.stop(t0 + len + 0.05);
        };
        if (kind === 0) { for (let j = 0; j < 3; j++) tone(at + j * 0.21, f * 1.2, f * 0.86, 0.17, vel); }
        else if (kind === 1) { tone(at, f, f * 1.05, 0.55, vel * 0.8, [38, f * 0.1]); }
        else if (kind === 2) { tone(at, f * 0.5, f * 0.44, 0.32, vel); tone(at + 0.4, f * 0.46, f * 0.38, 0.4, vel * 0.9); }
        else { tone(at, f, f * 1.38, 0.09, vel); tone(at + 0.16, f * 1.05, f * 1.45, 0.08, vel * 0.8); }
        send(out || g, 0.7, 0.55, pan, 0.18);
    }
    function creak(at, f, vel, pan) {
        const os = ctx.createOscillator(); os.type = 'sawtooth'; os.frequency.setValueAtTime(f, at); os.frequency.linearRampToValueAtTime(f * 1.5, at + 0.28); os.frequency.linearRampToValueAtTime(f * 1.2, at + 0.42);
        const bp = mk('bandpass', f * 5.5, 7), g = G(0), am = ctx.createOscillator(); am.frequency.value = 33; const ag = G(0.5); am.connect(ag); ag.connect(g.gain);
        g.gain.setValueAtTime(0, at); g.gain.linearRampToValueAtTime(vel * 0.5, at + 0.05); g.gain.linearRampToValueAtTime(0, at + 0.44); os.connect(bp); bp.connect(g); os.start(at); os.stop(at + 0.46); am.start(at); am.stop(at + 0.46); send(g, 0.8, 0.3, pan);
    }
    function shard(at, f, vel, pan) {
        const os = ctx.createOscillator(); os.type = 'sine'; os.frequency.value = f; const g = G(0); const dec = 0.12 + hash1(f) * 0.35;
        g.gain.setValueAtTime(0, at); g.gain.linearRampToValueAtTime(vel, at + 0.0015); g.gain.exponentialRampToValueAtTime(0.0004, at + dec); os.connect(g); os.start(at); os.stop(at + dec + 0.05);
        if (f * 2.41 < 14000) { const o2 = ctx.createOscillator(); o2.type = 'sine'; o2.frequency.value = f * 2.41; const g2 = G(0.35); o2.connect(g2); g2.connect(g); o2.start(at); o2.stop(at + dec + 0.05); }   // v106: the upper partial used to land above Nyquist and fold back as a hiss send(g, 0.7, 0.7, pan, 0.1);
    }
    function crash(at, dur, vel) {                                       // a wall of noise that closes down: surf, a plunge
        const nz = noise(at, dur + 0.1, 'pink'), lp = mk('lowpass', 9000, 0.7), g = G(0); nz.connect(lp); lp.connect(g);
        lp.frequency.setValueAtTime(9000, at); lp.frequency.exponentialRampToValueAtTime(260, at + dur);
        g.gain.setValueAtTime(0, at); g.gain.linearRampToValueAtTime(vel, at + 0.04); g.gain.exponentialRampToValueAtTime(0.002, at + dur); send(g, 0.9, 0.6, 0);
    }
    function tear(at, dur, vel) {                                        // a digital tear: chopped noise that falls in pitch
        const nz = noise(at, dur + 0.1), bp = mk('bandpass', 3400, 6), g = G(0), am = ctx.createOscillator(); am.type = 'square'; am.frequency.value = 19; const ag = G(0.5); am.connect(ag); ag.connect(g.gain);
        bp.frequency.setValueAtTime(3400, at); bp.frequency.exponentialRampToValueAtTime(380, at + dur); g.gain.setValueAtTime(0, at); g.gain.linearRampToValueAtTime(vel * 0.5, at + dur * 0.2); g.gain.linearRampToValueAtTime(0, at + dur);
        nz.connect(bp); bp.connect(g); am.start(at); am.stop(at + dur + 0.1); send(g, 0.8, 0.4, 0);
    }

    // ---- the orchestra: strings, a cello, a choir ---------------------------------------------------------------------------------
    // Everything played here is the music of the dream; it is never louder than the dream's own sounds, only wider and slower.
    function strings(at, notes, dur, vel, o = {}) {
        const att = o.att === undefined ? Math.min(3.5, dur * 0.35) : o.att, rel = o.rel || 2.2, end = at + dur, n = notes.length, life = dur + rel + 0.2;
        const lfo = ctx.createOscillator(); lfo.frequency.value = 0.15 + hash1(at) * 0.2; const lg = G(7); lfo.connect(lg); lfo.start(at); lfo.stop(at + life);
        notes.forEach((f, i) => {
            const g = G(0), lp = mk('lowpass', 400, 0.6), l0 = o.lp0 || 380, l1 = o.lp1 || 1700;
            lp.frequency.setValueAtTime(l0, at); lp.frequency.linearRampToValueAtTime(l1, at + att * 1.6); lp.frequency.linearRampToValueAtTime(l0 * 1.3, end + rel);
            for (const dt of [-6, 5]) { const os = ctx.createOscillator(); os.type = (f < 140 || i % 2) ? 'sawtooth' : 'triangle'; os.frequency.value = f; os.detune.value = dt + (i - n / 2) * 1.5; lg.connect(os.detune); const og = G(0.5); os.connect(og); og.connect(lp); os.start(at); os.stop(at + life); }
            const v = vel / Math.sqrt(n); lp.connect(g);
            g.gain.setValueAtTime(0, at); g.gain.linearRampToValueAtTime(v, at + att); g.gain.setValueAtTime(v, Math.max(at + att, end - 0.02)); g.gain.linearRampToValueAtTime(0, end + rel);
            msend(g, 0.5, o.wet === undefined ? 0.8 : o.wet, (o.pan || 0) + (n > 1 ? (i / (n - 1) - 0.5) * (o.spread === undefined ? 0.7 : o.spread) : 0), o.echo === undefined ? 0.08 : o.echo);
        });
    }
    function bowed(at, f, dur, vel, o = {}) {                            // a solo bowed string: vibrato that arrives late, body resonances, a breath of bow noise
        const att = o.att || 0.25, rel = o.rel || 0.5, end = at + dur, life = dur + rel + 0.2;
        const g = G(0), lp = mk('lowpass', f * 3, 0.7), b1 = mk('peaking', 300, 1.2), b2 = mk('peaking', 620, 1.5); b1.gain.value = 6; b2.gain.value = 4;
        const vib = ctx.createOscillator(); vib.frequency.value = 5.0 + hash1(f) * 0.9; const vg = G(0); vib.connect(vg); vg.gain.setValueAtTime(0, at); vg.gain.linearRampToValueAtTime(f * (o.vib === undefined ? 0.007 : o.vib), at + 0.5 + att);
        for (const dt of [-5, 4]) { const os = ctx.createOscillator(); os.type = 'sawtooth'; os.frequency.value = f; os.detune.value = dt; vg.connect(os.frequency); const og = G(0.5); os.connect(og); og.connect(lp); os.start(at); os.stop(at + life); }
        vib.start(at); vib.stop(at + life);
        lp.frequency.setValueAtTime(f * 1.6, at); lp.frequency.linearRampToValueAtTime(f * (o.bright || 5.5), at + att + 0.3); lp.frequency.linearRampToValueAtTime(f * 3, end);
        lp.connect(b1); b1.connect(b2); b2.connect(g);
        g.gain.setValueAtTime(0, at); g.gain.linearRampToValueAtTime(vel, at + att); g.gain.setValueAtTime(vel, Math.max(at + att, end - 0.05)); g.gain.linearRampToValueAtTime(0, end + rel);
        const nz = noise(at, life, 'pink'), nb = mk('bandpass', Math.min(5000, f * 9), 1.2), ng = G(0); nz.connect(nb); nb.connect(ng); ng.gain.setValueAtTime(0, at); ng.gain.linearRampToValueAtTime(vel * 0.06, at + att * 0.5); ng.gain.linearRampToValueAtTime(vel * 0.012, at + att + 0.3); ng.gain.linearRampToValueAtTime(0, end + rel * 0.5); ng.connect(g);
        msend(g, 0.55, 0.85, o.pan === undefined ? 0 : o.pan, 0.15);
    }
    function choir(at, notes, dur, vel, o = {}) {                        // a held "ah" that opens: glottal sources through the vowel formants
        const att = o.att || Math.min(3.5, dur * 0.4), rel = o.rel || 1.8, end = at + dur, life = dur + rel + 0.2, v0 = o.v0 || [300, 870, 2240], v1 = o.v1 || [730, 1090, 2440];
        const out = G(0); out.gain.setValueAtTime(0, at); out.gain.linearRampToValueAtTime(vel, at + att); out.gain.setValueAtTime(vel, Math.max(at + att, end - 0.02)); out.gain.linearRampToValueAtTime(0, end + rel);
        const vib = ctx.createOscillator(); vib.frequency.value = 5.2; const vg = G(0); vib.connect(vg); vg.gain.setValueAtTime(0, at); vg.gain.linearRampToValueAtTime(0.0055, at + att + 0.8); vib.start(at); vib.stop(at + life);
        notes.forEach((f, i) => {
            const os = ctx.createOscillator(); os.setPeriodicWave(glotWave(1.25, 0.8)); os.frequency.value = f; os.detune.value = (i - 1) * 5; const vgi = G(f); vg.connect(vgi); vgi.connect(os.frequency);
            for (let k = 0; k < 3; k++) { const b = mk('bandpass', v0[k], k === 0 ? 5 : 9), bg = G(k === 0 ? 1 : (k === 1 ? 0.7 : 0.45)); b.frequency.setValueAtTime(v0[k], at); b.frequency.linearRampToValueAtTime(v1[k], at + dur * 0.8); os.connect(b); b.connect(bg); bg.connect(out); }
            os.start(at); os.stop(at + life);
        });
        msend(out, 0.45, 1.0, o.pan === undefined ? 0 : o.pan, 0.25);
    }
    function shimmer(at, dur, f, vel, pan) {                             // glass: slow, detuned, high, the air of a place that is lit
        const g = G(0); g.gain.setValueAtTime(0, at); g.gain.linearRampToValueAtTime(vel, at + dur * 0.4); g.gain.linearRampToValueAtTime(0, at + dur);
        const hp = mk('highpass', 1800, 0.5); hp.connect(g);
        [1, 1.5, 2.0, 3.01].forEach((m, i) => { const os = ctx.createOscillator(); os.type = 'sine'; os.frequency.value = f * m * (1 + (i - 1.5) * 0.002); const tr = ctx.createOscillator(); tr.frequency.value = 0.3 + i * 0.17; const tg2 = G(0.4 / (i + 1)), og = G(0.6 / (i + 1)); tr.connect(tg2); tg2.connect(og.gain); os.connect(og); og.connect(hp); os.start(at); os.stop(at + dur + 0.1); tr.start(at); tr.stop(at + dur + 0.1); });
        msend(g, 0.4, 0.9, pan === undefined ? 0 : pan, 0.3);
    }

    // ---- the beds: the ground the dream stands on. Each is steered by the scene (see update) ---------------------------------
    const bedNoise = (kind, ...chain) => { let n = noise(undefined, undefined, kind); for (const f of chain) { n.connect(f); n = f; } return n; };
    const roomG = G(0); bedNoise('base', mk('lowpass', 420, 0.4)).connect(roomG); send(roomG, 0.6, 0.2);                                  // room tone
    const fridgeG = G(0), fLP = mk('lowpass', 520, 0.5); for (const f of [50, 100.3, 150.6]) { const os = ctx.createOscillator(); os.type = 'sine'; os.frequency.value = f; const g = G(f === 50 ? 0.5 : 0.25); os.connect(g); g.connect(fLP); os.start(); keep(os); } fLP.connect(fridgeG); send(fridgeG, 0.8, 0.15, -0.8);
    const windG = G(0), windBP = mk('bandpass', 520, 0.5); bedNoise('pink', windBP).connect(windG); send(windG, 0.6, 0.5);                     // wind
    const rustleG = G(0); { const hp = mk('highpass', 2400, 0.5), lfo = ctx.createOscillator(), lg = G(0.35), mg = G(0.65); lfo.frequency.value = 0.17; lfo.connect(lg); lg.connect(mg.gain); lfo.start(); keep(lfo); bedNoise('pink', hp).connect(mg); mg.connect(rustleG); send(rustleG, 0.7, 0.3); }   // grass in the wind
    const insG = G(0); { const bp = mk('bandpass', 5300, 2.5), am = G(0.5), lfo = ctx.createOscillator(), lg = G(0.5); lfo.frequency.value = 29; lfo.connect(lg); lg.connect(am.gain); lfo.start(); keep(lfo); bedNoise('base', bp).connect(am); am.connect(insG); send(insG, 0.8, 0.3); }   // insects at dawn
    const humG = G(0), humLP = mk('lowpass', 900, 0.5); for (const f of [110, 165.4, 220.8]) { const os = ctx.createOscillator(); os.type = 'sine'; os.frequency.value = f; const g = G(0.3); os.connect(g); g.connect(humLP); os.start(); keep(os); } humLP.connect(humG); send(humG, 0.6, 0.6, 0);   // the tidy world hums
    const drG = G(0), drLP = mk('lowpass', 160, 0.7); for (let i = 0; i < 3; i++) { const o = ctx.createOscillator(); o.type = 'sawtooth'; o.frequency.value = 55 * [1, 1.0595, 1.4983][i]; const g = G(0.25); o.connect(g); g.connect(drLP); o.start(); keep(o); } drLP.connect(drG); send(drG, 0.7, 0.3, 0);   // the dark drone
    const hvacG = G(0); bedNoise('brown', mk('bandpass', 170, 0.9)).connect(hvacG); send(hvacG, 0.7, 0.4);                                    // the archive breathes
    const cabinG = G(0), cLP = mk('lowpass', 900, 0.5); for (const f of [118, 236.7, 355]) { const os = ctx.createOscillator(); os.type = 'sine'; os.frequency.value = f; const g = G(f === 118 ? 0.5 : 0.2); os.connect(g); g.connect(cLP); os.start(); keep(os); } bedNoise('pink', mk('bandpass', 320, 0.7)).connect(cLP); cLP.connect(cabinG); send(cabinG, 0.8, 0.3);   // the shuttle's fan
    const roarG = G(0), roarBP = mk('bandpass', 300, 0.6); bedNoise('pink', roarBP).connect(roarG); send(roarG, 0.9, 0.3);                    // the plunge: wind on the glass
    const rattleG = G(0); { const bp = mk('bandpass', 1100, 1.2), am = G(0.5), lfo = ctx.createOscillator(), lg = G(0.5); lfo.type = 'square'; lfo.frequency.value = 41; lfo.connect(lg); lg.connect(am.gain); lfo.start(); keep(lfo); bedNoise('base', bp).connect(am); am.connect(rattleG); send(rattleG, 0.9, 0.2); }   // panels shaking
    const watG = G(0), watLP = mk('lowpass', 500, 0.6); bedNoise('brown', watLP).connect(watG); send(watG, 0.7, 0.4);                         // water
    const whaleG = G(0), whaleF = ctx.createOscillator(); { whaleF.type = 'sine'; whaleF.frequency.value = 82; const l = ctx.createOscillator(); l.frequency.value = 0.07; const lg = G(14); l.connect(lg); lg.connect(whaleF.frequency); l.start(); keep(l); const h = ctx.createOscillator(); h.type = 'sine'; h.frequency.value = 164.5; const hg = G(0.35); const l2 = ctx.createOscillator(); l2.frequency.value = 0.07; const l2g = G(28); l2.connect(l2g); l2g.connect(h.frequency); l2.start(); keep(l2); whaleF.connect(whaleG); h.connect(hg); hg.connect(whaleG); whaleF.start(); h.start(); keep(whaleF); keep(h); send(whaleG, 0.5, 1.0, 0, 0.3); }   // something large, far away, singing
    const whisperG = G(0); { const bp = mk('bandpass', 5200, 1.1), am = G(0.5), l1 = ctx.createOscillator(), l1g = G(0.5); l1.frequency.value = 3.3; l1.connect(l1g); l1g.connect(am.gain); l1.start(); keep(l1); bedNoise('base', bp).connect(am); am.connect(whisperG); send(whisperG, 0.6, 0.9); }   // the watchers lean in and whisper
    const doorG = G(0), doorRef = {}, dLP = mk('lowpass', 900, 0.5); for (const f of [118, 236.5]) { const os = ctx.createOscillator(); os.type = 'sine'; os.frequency.value = f; const g = G(f === 118 ? 0.5 : 0.2); os.connect(g); g.connect(dLP); os.start(); keep(os); } dLP.connect(doorG); send(doorG, 0.9, 0.3, { x: 0, y: 1.2, z: -12, ref: doorRef }, 0.1);   // the lit door's hum, placed in space

    // ---- the score of events: [timeline seconds, fn(at)] -------------------------------------------------------------------------
    const ev = [];
    function step(at, k, side, surf) {   // a heel and a toe: wood, earth, tile, stone
        const pan = side ? 0.14 : -0.14, j = 0.94 + 0.12 * hash1(at * 13.7), wet = surf === 3 ? 0.55 : (surf === 2 ? 0.3 : (surf === 1 ? 0.2 : 0.12));
        thud(at, 95 * j, 56, 0.12, 0.05 * k, { knock: surf === 2 ? 2300 : (surf === 0 ? 1000 : (surf === 3 ? 1500 : 450)), wet, pan });
        thud(at + 0.07, 140 * j, 85, 0.06, 0.022 * k, { wet: wet * 0.6, pan });
        if (surf === 1) { const nz = noise(at - 0.02, 0.2, 'pink'), bp = mk('bandpass', 2600, 0.8), g = G(0); nz.connect(bp); bp.connect(g); bp.frequency.setValueAtTime(2600, at); bp.frequency.exponentialRampToValueAtTime(1100, at + 0.14); g.gain.setValueAtTime(0, Math.max(0, at - 0.02)); g.gain.linearRampToValueAtTime(0.03 * k, at + 0.03); g.gain.linearRampToValueAtTime(0, at + 0.16); send(g, 0.8, 0.2, pan); }
        else if (surf === 2) click(at + 0.005, 3400, 0.04 * k, pan);
        else if (surf === 3) click(at + 0.004, 2100, 0.05 * k, pan);
        else if (hash1(at * 3.3) < 0.14) creak(at + 0.05, 110 + hash1(at) * 40, 0.03 * k, pan);
    }
    function sweep(at, dur, f0, f1, vel, q = 2.5, pan = 0) {   // a band of noise that travels: a wave of light, a roar
        const nz = noise(at, dur + 0.1), bp = mk('bandpass', f0, q), g = G(0); nz.connect(bp); bp.connect(g);
        bp.frequency.setValueAtTime(f0, at); bp.frequency.exponentialRampToValueAtTime(f1, at + dur);
        g.gain.setValueAtTime(0, at); g.gain.linearRampToValueAtTime(vel, at + dur * 0.5); g.gain.linearRampToValueAtTime(0, at + dur); send(g, 0.8, 0.5, pan);
    }
    function swell(at, dur, f0, f1, vel) {
        const os = ctx.createOscillator(); os.type = 'sine'; os.frequency.setValueAtTime(f0, at); os.frequency.exponentialRampToValueAtTime(f1, at + dur);
        const g = G(0); os.connect(g); g.gain.setValueAtTime(0, at); g.gain.linearRampToValueAtTime(vel, at + dur * 0.85); g.gain.linearRampToValueAtTime(0, at + dur); os.start(at); os.stop(at + dur + 0.1); send(g, 0.8, 0.4, 0);
    }
    function glitchBurst(at, n, vel) { for (let j = 0; j < n; j++) click(at + j * 0.034 + (j % 3) * 0.01, 2400 + hash1(j * 7 + at) * 4200, vel * (0.5 + 0.5 * hash1(j * 3.1)), (hash1(j) - 0.5) * 1.4); }
    const E = (t, fn) => ev.push({ t, fn, done: false });
    const A = TS;
    const MOT = [659.25, 783.99, 880.0, 783.99, 659.25, 587.33, 523.25];                    // the music-box tune of the kitchen: E G A G E D C
    const up2 = Math.pow(2, 2 / 12), MOT_D = MOT.map((f) => f * up2);                        // the same tune, a tone higher, in the green
    for (const [lt, k, sd] of footTimes(KD, SD[0])) E(A[0] + lt, (at) => step(at, k, sd, 0));
    for (const [lt, k, sd] of footTimes(WD, SD[1])) E(A[1] + lt, (at) => step(at, k, sd, lt < 28 ? 1 : 2));
    for (const [lt, k, sd] of footTimes(CD, SD[2])) E(A[2] + lt, (at) => step(at, k, sd, 3));
    for (const [lt, k, sd] of footTimes(HD, SD[3])) E(A[3] + lt, (at) => step(at, k, sd, 3));
    // 0 · waking: a breath in the dark, the room swells up and comes into focus (the muffle opens with the picture)
    E(0.15, (at) => { breath(at, 0.9, 0.05, 1300); sweep(at + 0.1, 1.6, 180, 2400, 0.05, 0.8); });
    // 1 · the kitchen
    E(A[0] - 1.0, (at) => {
        talk(at, 23, 'woman', 11, { rate: 3.6, dist: 0.5, pan: -0.55, gain: 0.34, pause: 0.7, wet: 0.35 });
        talk(at + 1.6, 22, 'man', 23, { rate: 3.2, dist: 0.55, pan: 0.6, gain: 0.3, pause: 0.9, wet: 0.35, t0: 1.3 });
    });
    for (const [lt, n] of [[6.2, 5], [10.6, 6], [15.2, 4]]) E(A[0] + lt, (at) => laugh(at, n, { dist: 0.12, pan: 0.0, gain: 0.55, hz: 5.0 + Math.random() }));
    E(A[0] + 8.2, (at) => talk(at, 3.2, 'child', 41, { rate: 5.0, dist: 0.1, pan: 0.05, gain: 0.34, lift: 0.02, pause: 0.5 }));
    E(A[0] + 14.0, (at) => patter(at, 18, 0.19, 0.12, 0));
    for (let j = 0; j < 25; j++) E(A[0] + 0.4 + j, (at) => click(at, j % 2 ? 1500 : 2000, 0.03, 0.75));                      // the kitchen clock is right
    for (let j = 0; j < 16; j++) E(A[0] + 2.5 + j * 1.35 + hash1(j * 2.2) * 0.9, (at) => bubble(at, 200 + hash1(j * 5.1) * 230, 0.011, -0.7));   // something simmers
    for (const lt of [5.3, 9.7, 19.1]) E(A[0] + lt, (at) => bell(at, 3100 + hash1(lt) * 600, 0.011, 0.4, { lp: 7000, pan: -0.6, echo: 0.04 }));   // a dish, set down
    for (const [lt, kd, f, pn] of [[1.5, 3, 4200, 0.8], [6.8, 0, 2600, 0.7], [11.6, 3, 4600, -0.7], [17.4, 1, 3000, 0.8]]) E(A[0] + lt, (at) => bird(at, kd, f, pn, 0.03, 3800));   // outside, through the glass
    E(A[0] + 2.4, (at) => MOT.forEach((f, i) => box(at + i * 0.62, f, 0.1, 3.4)));
    E(A[0] + 12.8, (at) => MOT.forEach((f, i) => box(at + i * 0.58, f, 0.085, 3.2)));
    E(A[0] + 0.0, (at) => strings(at, hzs('C3 G3 E4 B4 D5'), 10.5, 0.075, { lp0: 360, lp1: 1500, att: 2.5 }));
    E(A[0] + 8.5, (at) => strings(at, hzs('A2 E3 G3 C4 B4'), 10, 0.075, { lp0: 360, lp1: 1500, att: 2.2 }));
    E(A[0] + 17.0, (at) => strings(at, hzs('F2 C3 E4 A4 B4'), 8, 0.075, { lp0: 380, lp1: 1800, att: 2.0 }));
    E(A[0] + 13.6, (at) => bowed(at, hz('G3'), 5.2, 0.05, { att: 0.5, rel: 1.2, pan: -0.2 }));   // the small hand is coming: a cello breathes in
    E(A[0] + 21.0, (at) => strings(at, hzs('G2 D3 E4 A4 D5'), 6.6, 0.085, { lp0: 400, lp1: 3600, att: 4.0, rel: 2.5 }));
    E(A[0] + 20.6, (at) => choir(at, hzs('D4 F#4 A4'), 6.4, 0.04, { att: 3.6, rel: 2.0 }));
    E(A[0] + 22.0, (at) => sweep(at, 4.2, 600, 3600, 0.08, 1.2));
    E(A[0] + 22.0, (at) => shimmer(at, 6.0, 2093, 0.016));
    E(A[0] + 22.6, (at) => [783.99, 1174.66, 1567.98].forEach((f, i) => bell(at + i * 0.3, f, 0.05, 3.2, { lp: 5000 })));
    E(A[0] + 22.5, (at) => sweep(at, 3.6, 2000, 9000, 0.04, 0.9));
    // 2 · the green: an ancient dawn, then a ring of light that tidies it
    for (let j = 0; j < 40; j++) {
        const lt = 0.8 + j * 0.9 + hash1(j * 3.7) * 0.9; if (lt > 38) break;
        const kind = Math.floor(hash1(j * 1.9 + 4) * 4), f = [2300, 3100, 1500, 4200][kind] * (0.9 + hash1(j) * 0.2), fade = 1 - smooth(22, 38, lt);
        E(A[1] + lt, (at) => bird(at, kind, f, (hash1(j * 3) - 0.5) * 1.8, 0.05 * fade, 7200));
    }
    E(A[1] + 6.0, (at) => laugh(at, 4, { dist: 0.5, pan: 0.3, gain: 0.35, hz: 5.0 }));
    E(A[1] + 9.2, (at) => talk(at, 2.2, 'child', 47, { rate: 5.0, dist: 0.35, pan: -0.3, gain: 0.3, pause: 0.4 }));
    E(A[1] + 14.5, (at) => laugh(at, 5, { dist: 0.55, pan: -0.2, gain: 0.32, hz: 4.8 }));
    E(A[1] + 0.0, (at) => strings(at, hzs('D2 A2'), 14, 0.07, { lp0: 300, lp1: 900, att: 4.5, spread: 0.2 }));
    E(A[1] + 3.2, (at) => shimmer(at, 12, 1760, 0.012));
    E(A[1] + 12.0, (at) => strings(at, hzs('D2 A2 E3 B3'), 11, 0.075, { lp0: 330, lp1: 1300, att: 3.5 }));
    E(A[1] + 21.0, (at) => choir(at, hzs('D4 F#4 A4 C#5'), 14, 0.045, { att: 4.0, rel: 3.0 }));
    E(A[1] + 21.4, (at) => sweep(at, 9.0, 160, 2600, 0.16, 1.4));
    E(A[1] + 21.4, (at) => sweep(at + 0.4, 8.0, 900, 7200, 0.045, 1.0, 0.3));                // the ring, with air in it
    E(A[1] + 21.4, (at) => swell(at, 9.0, 55, 110, 0.12));
    E(A[1] + 22.0, (at) => strings(at, hzs('D2 A2 F#3 C#4 E4 B4'), 13, 0.09, { lp0: 380, lp1: 2600, att: 3.5, rel: 3 }));
    E(A[1] + 24.0, (at) => MOT_D.forEach((f, i) => bowed(at + i * 1.15, f * 0.5, 1.5, 0.05, { att: 0.3, rel: 0.8, pan: -0.15 })));   // the tune again, a tone higher, on a cello: the world has grown
    [523.25, 659.25, 783.99, 987.77, 1174.66, 1318.51, 1567.98, 1975.53, 2349.32].forEach((f, j) => E(A[1] + 22.6 + j * 0.8, (at) => bell(at, f, 0.05, 3.2, { lp: 4800, pan: j % 2 ? 0.4 : -0.4 })));
    for (let j = 0; j < 8; j++) E(A[1] + 31 + j * 1.9, (at) => { bell(at, 2093 * (1 + (j % 3) * 0.25), 0.028, 0.5, { lp: 5200, pan: j % 2 ? 0.7 : -0.7 }); bell(at + 0.12, 2793, 0.02, 0.4, { lp: 5200, pan: j % 2 ? 0.7 : -0.7 }); });
    for (let j = 0; j < 22; j++) E(A[1] + 27 + j * 1.35 + hash1(j * 4.4) * 0.6, (at) => click(at, 3800 + hash1(j * 2.7) * 2600, 0.022, (hash1(j * 8.1) - 0.5) * 1.8));   // the tidy world ticks
    E(A[1] + 34.0, (at) => strings(at, hzs('B1 F#2 B3 D4 A4 C#5'), 13, 0.08, { lp0: 380, lp1: 2200, att: 3.0 }));
    E(A[1] + 38.0, (at) => { [0, 1, 2, 3, 4, 3, 2, 1].forEach((k2, i) => box(at + i * 0.75, hz(['D5', 'F#5', 'A5', 'D6', 'F#5'][k2 % 5]), 0.028, 3.0, { pan: i % 2 ? 0.45 : -0.45 })); });
    E(A[1] + 43.6, (at) => talk(at, 2.4, 'child', 59, { rate: 5.0, dist: 0.3, pan: 0.2, gain: 0.28, pause: 0.4 }));
    E(A[1] + 46.0, (at) => strings(at, hzs('G2 D3 B3 F#4 A4'), 12, 0.08, { lp0: 400, lp1: 2400, att: 3.0 }));
    E(A[1] + 52.0, (at) => swell(at, 10.0, 98, 196, 0.14));
    E(A[1] + 55.0, (at) => strings(at, hzs('D2 A2 D3 F#3 A3 E4'), 9.5, 0.09, { lp0: 420, lp1: 2800, att: 3.0, rel: 1.5 }));
    E(A[1] + 55.0, (at) => choir(at, hzs('D3 A3 D4 F#4'), 8.6, 0.045, { att: 3.0, rel: 1.2 }));
    E(TE[1] - T_OUT[1], (at) => { glitchBurst(at, 22, 0.14); tear(at, 1.7, 0.1); });
    E(TE[1] - 1.0, (at) => [2349.32, 1975.53, 1567.98, 1318.51, 1046.5].forEach((f, i) => bell(at + i * 0.07, f, 0.04, 0.5, { lp: 5000, pan: (i - 2) * 0.35 })));   // the world's chimes, going out
    // 3 · the corridor
    E(A[2], (at) => glitchBurst(at, 10, 0.08));
    for (let i = 0; i < 20; i++) { const tt = A[2] + 2 + i * 1.0 + (i > 8 && i < 13 ? (i % 2 ? 0.22 : -0.12) : 0); if (i === 12 || i === 15) continue; E(tt, (at) => click(at, i % 2 ? 1300 : 1700, 0.16, 0.7)); }
    E(A[2] + 11.5, (at) => { click(at, 1700, 0.18, 0.7); click(at + 0.11, 1700, 0.15, 0.7); click(at + 0.24, 1700, 0.12, 0.7); });
    E(A[2] + 1.0, (at) => {
        talk(at, 20, 'man', 61, { rate: 5.2, dist: 0.8, pan: -0.9, gain: 0.5, pause: 0.3, wet: 0.9, lift: -0.02 });
        talk(at + 2.4, 18, 'woman', 73, { rate: 5.6, dist: 0.85, pan: 0.9, gain: 0.45, pause: 0.28, wet: 0.95 });
        talk(at + 6.0, 14, 'deep', 83, { rate: 5.0, dist: 0.8, pan: -0.3, gain: 0.45, pause: 0.35, wet: 0.9 });
    });
    for (const [lt, d, g] of [[4.6, 0.55, 0.5], [12.8, 0.72, 0.4], [19.6, 0.88, 0.32]]) E(A[2] + lt, (at) => laugh(at, 4, { dist: d, pan: 0.0, gain: g, hz: 4.6, wet: 1.0 }));
    for (let i = 0; i < 14; i++) E(A[2] + 10.5 + i * (0.95 - i * 0.025), (at) => { thud(at, 78, 46, 0.22, 0.34 * (0.5 + i / 14), { wet: 0.35 }); thud(at + 0.28, 66, 42, 0.2, 0.22 * (0.5 + i / 14), { wet: 0.35 }); });
    for (const lt of [2.6, 6.1, 9.4, 14.8, 18.3, 21.0]) E(A[2] + lt, (at) => { const nz = noise(at, 0.5, 'pink'), bp = mk('bandpass', 4600 + hash1(lt) * 1500, 0.9), g = G(0); nz.connect(bp); bp.connect(g); g.gain.setValueAtTime(0, at); g.gain.linearRampToValueAtTime(0.035, at + 0.06); g.gain.linearRampToValueAtTime(0, at + 0.4); send(g, 0.8, 0.5, (hash1(lt * 2.3) - 0.5) * 1.8); });   // paper, somewhere in the shelves
    E(A[2] + 0.0, (at) => strings(at, hzs('A1 E2 Bb2 F3'), 13, 0.08, { lp0: 280, lp1: 800, att: 3.5 }));
    E(A[2] + 11.0, (at) => strings(at, hzs('A1 Eb2 A2 Eb3 Bb3'), 15, 0.085, { lp0: 280, lp1: 1000, att: 3.5, rel: 3 }));
    E(A[2] + 3.0, (at) => hzs('C5 D5 E5 G5 A5 G5 E5').forEach((f, i) => box(at + i * 0.9, (i === 3 ? f * 0.944 : f) * 0.978, 0.045, 3.4, { pan: 0.5 - i * 0.16, echo: 0.8 })));   // the tune backwards, a little flat, with one wrong note
    E(A[2] + 20.0, (at) => bowed(at, hz('A2'), 4.2, 0.04, { att: 1.0, rel: 1.5, vib: 0.012, bright: 3.5 }));
    // 4 · the hearing
    // v106: the watchers are a murmur, not a crowd: four voices (was eight), far off, muffled, quiet, fading in and out, placed with the cheap
    // panner. The speaker (the one voice that matters) is the only one heard with HRTF, and now clearly the loudest.
    [['deep', 0.9], ['woman', 1.0], ['man', 0.93], ['woman', 0.88]].forEach(([w, p], i) => {
        const th = (i + 0.5) / 4 * Math.PI * 2, r = 6.0 + (i % 2) * 1.2;
        E(A[3] - 0.5 + 0.9 * i, (at) => talk(at, 30.0 - 0.9 * i, w, 100 + i * 17, { rate: 2.4 + 0.3 * (i % 3), dist: 0.78, pos: { x: Math.sin(th) * r, y: 1.9, z: -Math.cos(th) * r, eq: true }, gain: 0.11, pause: 0.7, wet: 0.55, breath: 1.2, pitch: p, lite: true, fadeIn: 3.5, fadeOut: [at + 25.0, at + 29.0] }));
    });
    E(A[3] + 6.0, (at) => talk(at, 12.3, 'deep', 211, { rate: 3.1, dist: 0.35, pos: { x: -2.6, y: 1.7, z: 5.2 }, gain: 0.5, pause: 0.45, wet: 0.7, flat: true, mono: true, pitch: 0.92 }));
    E(A[3] + 4.2, (at) => talk(at, 5.0, 'child', 71, { rate: 5.0, dist: 0.4, pan: 0.0, gain: 0.26, pause: 0.5 }));
    E(A[3] + 10.8, (at) => laugh(at, 3, { dist: 0.1, gain: 0.5, hz: 4.6 }));
    E(A[3] + 16.2, (at) => laugh(at, 2, { dist: 0.75, gain: 0.3, hz: 4.0, wet: 0.8 }));
    for (const g of HALL_GAVEL) E(A[3] + g, (at) => { thud(at, 120, 54, 0.7, 0.38, { knock: 900, wet: 0.5 }); });   // v106: no 28-38 Hz content (phones cannot play it; it only slams the limiter)
    for (const g of [HALL_GAVEL[0], HALL_GAVEL[1]]) E(A[3] + g, (at) => strings(at, hzs('C2 G2 Db3'), 2.6, 0.075, { lp0: 260, lp1: 1500, att: 0.08, rel: 1.8 }));
    E(A[3] + HALL_GAVEL[2], (at) => {
        [2400, 3100, 1900, 4200, 2750, 3600].forEach((f, i) => bell(at + i * 0.05, f, 0.06, 1.6, { lp: 9000, detune: 0.02, pan: (i - 2.5) * 0.35 }));
        sweep(at, 1.6, 6000, 900, 0.1, 0.8); thud(at, 72, 42, 1.4, 0.4, { wet: 0.6 });
    });
    const SHARD_T = (j) => 0.04 + j * 0.045 + hash1(j * 3.3) * 0.05 + j * j * 0.0012, NSH = 30;
    for (let j0 = 0; j0 < NSH; j0 += 6) E(A[3] + HALL_GAVEL[2] + SHARD_T(j0), (at) => { for (let j = j0; j < Math.min(NSH, j0 + 6); j++) shard(at + SHARD_T(j) - SHARD_T(j0), 2600 + hash1(j * 7.7) * 7600, 0.04 * (1 - j / 42), (hash1(j * 2.1) - 0.5) * 1.9); });   // the glass of it, falling (v106: 30 pieces, in five small batches)
    for (let i = 0; i < 22; i++) E(A[3] + 1.0 + i * 1.15, (at) => thud(at, 72, 50, 0.3, 0.07 + 0.1 * (i / 22), { wet: 0.25 }));   // v106: lighter and above 50 Hz, one event per beat
    E(A[3] + 0.0, (at) => strings(at, hzs('C2 G2 C3 Db3 G3'), 16, 0.08, { lp0: 240, lp1: 1000, att: 4.0, spread: 0.3 }));
    E(A[3] + 14.0, (at) => strings(at, hzs('C2 Gb2 C3 Db3 G3'), 13, 0.085, { lp0: 240, lp1: 1200, att: 3.0, spread: 0.3 }));
    E(A[3] + 2.0, (at) => bowed(at, hz('C2'), 15.5, 0.06, { att: 2.5, rel: 1.0, vib: 0.004, bright: 3.5 }));
    // 5 · the drift
    for (let j = 0; j < 14; j++) E(A[4] + 1.5 + j * 1.55, (at) => { thud(at, 58, 38, 0.18, 0.1, { wet: 0.4 }); thud(at + 0.24, 52, 36, 0.16, 0.06, { wet: 0.4 }); });
    for (const lt of [3.2, 8.7, 12.4, 17.1]) E(A[4] + lt, (at) => click(at, 600 + hash1(lt) * 500, 0.09, hash1(lt * 3) - 0.5));
    for (const [lt, p] of [[4.4, -0.7], [10.1, 0.8], [15.6, -0.5]]) E(A[4] + lt, (at) => creak(at, 70 + hash1(lt) * 30, 0.05, p));         // the hull, settling
    for (const [lt, p] of [[6.6, 0.6], [13.3, -0.8], [16.9, 0.4]]) E(A[4] + lt, (at) => bell(at, 1900 + hash1(lt * 2) * 900, 0.014, 1.4, { lp: 7500, pan: p, echo: 0.1 }));   // cooling metal
    E(A[4] + 2.0, (at) => swell(at, 14, 880, 1320, 0.018));
    for (let j = 0; j < 4; j++) E(A[4] + 19.5 + j * 0.8, (at) => bell(at, 1567.98, 0.04, 0.6, { lp: 4200 }));
    E(A[4] + 22.0, (at) => sweep(at, 6.0, 200, 2800, 0.24, 0.6));
    E(A[4] + 23.0, (at) => swell(at, 5.0, 40, 90, 0.22));
    E(A[4] + 0.0, (at) => strings(at, hzs('A1 E2 A2 E3'), 13.5, 0.07, { lp0: 330, lp1: 900, att: 4.0, spread: 0.3 }));
    E(A[4] + 12.0, (at) => strings(at, hzs('A1 E2 C3 G3 B3'), 11.5, 0.075, { lp0: 330, lp1: 1200, att: 3.0 }));
    E(A[4] + 19.5, (at) => strings(at, hzs('A1 E2 A2 C#3 E3 A3 E4'), 9.0, 0.11, { lp0: 320, lp1: 4800, att: 5.5, rel: 1.0 }));
    E(A[4] + 3.4, (at) => hzs('E6 D6 C6').forEach((f, i) => box(at + i * 1.1, f, 0.03, 3.4, { pan: 0.3 - i * 0.3, echo: 0.9 })));   // the tune, far off
    E(TE[4] - 0.6, (at) => { thud(at, 90, 30, 1.2, 0.7, { knock: 1200, wet: 0.7 }); sweep(at, 1.2, 5000, 400, 0.2, 0.7); crash(at, 2.2, 0.16); });
    // 6 · the water
    for (let j = 0; j < 44; j++) { const lt = 0.1 + j * 0.075 + j * j * 0.0033 + hash1(j) * 0.1; E(A[5] + lt, (at) => bubble(at, 260 + hash1(j * 9.1) * 700, 0.02 * (1 - lt / 8), (hash1(j * 4) - 0.5) * 1.8)); }
    for (let j = 0; j < 14; j++) E(A[5] + 2.0 + j * 1.6 + hash1(j * 6.6) * 0.9, (at) => bubble(at, 180 + hash1(j * 3.3) * 300, 0.01, (hash1(j * 5) - 0.5) * 1.6));
    E(A[5], (at) => {
        const crowd = [['deep', 0.85], ['man', 0.9], ['woman', 0.82], ['deep', 1.0]];
        crowd.forEach(([w, p], i) => talk(at + 0.2 * i, 11, w, 300 + i * 13, { rate: 2.4, dist: 0.92, pan: -0.8 + i * 0.5, gain: 0.28, pause: 0.7, wet: 1.0, breath: 1.4, pitch: p }));
    });
    E(A[5] + 6.4, (at) => { [3136, 4186, 3520].forEach((f, i) => bell(at + i * 0.09, f, 0.05, 2.6, { lp: 3600 })); bell(at + 0.35, 1568, 0.07, 3.2, { lp: 1800, bend: 0.97 }); });
    E(A[5] + 9.0, (at) => MOT.slice(0, 5).forEach((f, i) => { bell(at + i * 1.15, f * 0.5, 0.075, 4.2, { detune: 0.012, bend: 0.985, lp: 2600 }); bowed(at + i * 1.15, f * 0.25, 1.6, 0.045, { att: 0.35, rel: 1.0, vib: 0.009, bright: 4, pan: 0.1 }); }));   // slowed, low, unfinished
    E(A[5] + 14.6, (at) => {
        talk(at, 10, 'woman', 11, { rate: 3.3, dist: 0.8, pan: -0.5, gain: 0.34, pause: 0.7, wet: 1.0 });
        talk(at + 1.2, 9, 'man', 23, { rate: 3.0, dist: 0.82, pan: 0.5, gain: 0.3, pause: 0.9, wet: 1.0 });
    });
    E(A[5] + 17.6, (at) => laugh(at, 5, { dist: 0.45, gain: 0.8, hz: 4.8, wet: 0.9 }));
    E(A[5] + 0.0, (at) => strings(at, hzs('A2 E3 B3 C4 E4'), 10, 0.07, { lp0: 300, lp1: 1000, att: 3.5, spread: 0.5 }));
    E(A[5] + 9.0, (at) => strings(at, hzs('F2 C3 A3 E4'), 9, 0.07, { lp0: 320, lp1: 1300, att: 3.0 }));
    E(A[5] + 17.0, (at) => strings(at, hzs('C3 G3 E4 G4 B4'), 11.5, 0.095, { lp0: 400, lp1: 3800, att: 5.0, rel: 3.5 }));
    E(A[5] + 17.5, (at) => choir(at, hzs('E4 G4 B4 D5'), 9.4, 0.05, { att: 4.0, rel: 3.0 }));
    E(A[5] + 4.0, (at) => shimmer(at, 14, 2637, 0.01));
    E(TE[5] - 3.3, (at) => { const os = ctx.createOscillator(); os.type = 'sine'; os.frequency.value = 392; const o2 = ctx.createOscillator(); o2.frequency.value = 587.33; const g = G(0); os.connect(g); o2.connect(g); g.gain.setValueAtTime(0, at); g.gain.linearRampToValueAtTime(0.09, at + 2.8); g.gain.linearRampToValueAtTime(0, at + 6.0); os.start(at); o2.start(at); os.stop(at + 6.1); o2.stop(at + 6.1); send(g, 0.6, 0.9, 0); });
    E(TE[5] - 3.0, (at) => choir(at, hzs('G3 D4 G4'), 5.2, 0.05, { att: 2.6, rel: 2.2, v0: [730, 1090, 2440], v1: [570, 840, 2410] }));
    E(TE[5] + 0.9, (at) => { breath(at, 0.85, 0.08, 1500); });
    for (let i = 0; i < 6; i++) E(TE[5] + 1.2 + i * 0.5, (at) => { thud(at, 62, 42, 0.2, 0.22 * (1 - i * 0.12), { wet: 0.3 }); thud(at + 0.2, 54, 40, 0.18, 0.14 * (1 - i * 0.12), { wet: 0.3 }); });

    // continuous steering from the picture's state
    const setListener = (S, tc) => {
        const L = ctx.listener; if (!L) return; const hall = S.on && (S.idx === 2 || S.idx === 3), p = hall ? S.pos : [0, 0, 0], f = hall ? S.f : [0, 0, -1], u = hall ? S.u : [0, 1, 0];
        try {
            if (L.positionX) { L.positionX.setTargetAtTime(p[0], tc, 0.02); L.positionY.setTargetAtTime(p[1], tc, 0.02); L.positionZ.setTargetAtTime(p[2], tc, 0.02); L.forwardX.setTargetAtTime(f[0], tc, 0.03); L.forwardY.setTargetAtTime(f[1], tc, 0.03); L.forwardZ.setTargetAtTime(f[2], tc, 0.03); L.upX.setTargetAtTime(u[0], tc, 0.03); L.upY.setTargetAtTime(u[1], tc, 0.03); L.upZ.setTargetAtTime(u[2], tc, 0.03); }
            else { L.setPosition(p[0], p[1], p[2]); L.setOrientation(f[0], f[1], f[2], u[0], u[1], u[2]); }
        } catch (e) {}
    };
    function update(S, tcAt) {
        const tc = tcAt === undefined ? ctx.currentTime : tcAt, sh = S.on ? (S.idx || 0) : -1, tg = (p, v, tau = 0.4) => p.setTargetAtTime(v, tc, tau);
        master.gain.setTargetAtTime(S.on ? 0.6 : 0, tc, S.on ? 0.8 : 0.5);
        const duck = 1 - 0.65 * S.black, pl = S.streak || 0;
        const sub = sh === 5 && S.water > S.pos[1], wl = sh === 5 ? Math.max(0.0, Math.min(1, (S.water + 0.5) / 6)) : 0;
        // the rooms: each scene stands in its own space; under the water everything is in the dark one
        const sp = SPACES[Math.max(0, sh)]; rvSend.forEach((s, i) => tg(s.gain, sh < 0 ? 0 : (sub ? [0.1, 0.2, 1.0][i] : sp[i]), 0.6)); tg(dlyIn.gain, sh < 0 ? 0 : ECHO[sh], 0.6);
        // the ears follow the eyes: a blur or a closing lid muffles the whole mix, and the water takes the highs away
        const m = clamp01(Math.max((S.blur || 0) / 7, (S.lid || 0) * 0.8)); let cut = 19000 * Math.pow(0.03, m); if (sub) cut = Math.min(cut, 650 + 500 * (1 - wl)); muffle.frequency.setTargetAtTime(cut, tc, 0.07);
        // music: ducked in the dark, and gone at the third blow
        const hush = sh === 3 && S.lt > HALL_GAVEL[2] - 0.05 ? 0 : 1; for (const k in mbus) mbus[k].gain.setTargetAtTime(duck * hush, tc, hush ? 0.6 : 0.05);
        tg(drG.gain, (sh === 2 ? 0.07 + 0.08 * S.beat : (sh === 3 ? 0.07 + 0.07 * Math.min(1, S.k * 1.2) * (S.light > 0.5 ? 1 : 0.6) : (sh === 4 ? 0.05 + 0.1 * pl : 0))) * duck, 0.9);
        tg(roomG.gain, (sh === 0 ? 0.09 : (sh === 2 ? 0.05 : 0)) * duck, 0.9);
        tg(fridgeG.gain, (sh === 0 ? 0.03 : 0) * duck, 0.9);
        tg(windG.gain, (sh === 1 ? 0.07 * (1 - 0.6 * (S.orgSky || 0)) : 0) * duck, 1.2);
        windBP.frequency.setTargetAtTime(420 + 260 * Math.sin(S.t * 0.23) + 600 * (S.orgSky || 0), tc, 0.8);
        tg(rustleG.gain, (sh === 1 ? 0.03 * (1 - (S.orgSky || 0)) : 0) * duck, 1.2);
        tg(insG.gain, (sh === 1 ? 0.012 * (1 - smooth(0.0, 0.6, S.orgSky || 0)) * smooth(0, 3, S.lt) : 0) * duck, 1.5);
        tg(humG.gain, (sh === 1 ? 0.10 * (S.orgSky || 0) : 0) * duck, 1.5);
        tg(hvacG.gain, (sh === 2 ? 0.07 : 0) * duck, 1.0);
        tg(cabinG.gain, (sh === 4 ? 0.04 * (1 - 0.7 * pl) : 0) * duck, 1.0);
        tg(roarG.gain, (sh === 4 ? 0.20 * Math.pow(pl, 1.5) : 0) * duck, 0.3); roarBP.frequency.setTargetAtTime(250 + 2400 * pl, tc, 0.3);
        tg(rattleG.gain, (sh === 4 ? 0.09 * (S.heat || 0) : 0) * duck, 0.2);
        tg(watG.gain, (sh === 5 ? (0.05 + 0.16 * wl * (sub ? 1.0 : 0.7)) : 0) * duck, 0.8);
        watLP.frequency.setTargetAtTime(sub ? 260 : 700 + 400 * wl, tc, 0.6);
        tg(whaleG.gain, (sh === 5 ? 0.04 * smooth(2, 8, S.lt) * (1 - smooth(18, 23, S.lt)) * (sub ? 1 : 0.4) : 0) * duck, 1.2);
        tg(whisperG.gain, (sh === 3 && hush ? 0.012 + 0.03 * (S.lean || 0) : 0) * duck, 0.8);
        // the door's hum: it backs away down the corridor (placed in the world; the listener walks)
        tg(doorG.gain, (sh === 2 ? 0.06 * (1 - 0.7 * smooth(10, 24, S.lt)) : 0) * duck, 0.6);
        if (doorRef.node && sh === 2) { try { const pn = doorRef.node; if (pn.positionZ) { pn.positionX.setTargetAtTime(0, tc, 0.05); pn.positionY.setTargetAtTime(1.2, tc, 0.05); pn.positionZ.setTargetAtTime(S.doorZ, tc, 0.05); } else pn.setPosition(0, 1.2, S.doorZ); } catch (e) {} }
        dry.gain.setTargetAtTime(sh === 5 && sub ? 0.5 : 1, tc, 0.5);
        setListener(S, tc);
    }
    return {
        update,
        // timeline t -> fire the events that are due (real-time); lookahead keeps the scheduled starts ahead of the clock
        tick(t, S) { const tc = ctx.currentTime; for (const e of ev) if (!e.done && t >= e.t - 0.25) { e.done = true; try { e.fn(tc + Math.max(0, e.t - t)); } catch (err) { console.warn('dream audio', err); } } update(S); },
        // offline render: every event at its own time
        scheduleAll(from = 0) { for (const e of ev) { e.done = true; if (e.t < from) continue; try { e.fn(Math.max(0, e.t - from)); } catch (err) { console.warn('dream audio', err); } } },
        stop() {
            const tc = ctx.currentTime; try { master.gain.cancelScheduledValues(tc); master.gain.setTargetAtTime(0, tc, 0.25); } catch (e) {}
            setTimeout(() => { for (const n of nodes) { try { n.stop(); } catch (e) {} try { n.disconnect(); } catch (e) {} } try { master.disconnect(); comp.disconnect(); lim.disconnect(); clip.disconnect(); outG.disconnect(); sum.disconnect(); rvOut.disconnect(); for (const c of rvConv) c.disconnect(); pL.disconnect(); pR.disconnect(); } catch (e) {} }, 1200);
        },
    };
}


// ---- the overlay -------------------------------------------------------------------------------------------------------------
const CSS = `
#drCine { position: fixed; inset: 0; z-index: 9000; background: #000; opacity: 0; transition: none; overflow: hidden; touch-action: none; user-select: none; }
#drCine.on { opacity: 1; }
#drCine canvas.dr-cv { position: absolute; inset: 0; width: 100%; height: 100%; display: block; }
#drCine .dr-bloom { position: absolute; inset: 0; width: 100%; height: 100%; opacity: .55; mix-blend-mode: screen; filter: blur(2.4vmin) saturate(1.3) brightness(.9); pointer-events: none; }
#drCine .dr-bar { position: absolute; left: 0; right: 0; height: 0; background: #000; z-index: 3; pointer-events: none; transition: height 2.2s ease; }
#drCine.bars .dr-bar { height: 6.5vh; }
#drCine .dr-bar.t { top: 0; } #drCine .dr-bar.b { bottom: 0; }
#drCine .dr-hint { position: absolute; left: 0; right: 0; text-align: center; bottom: calc(6.5vh + 1.2vmin); font: 500 clamp(8px, 1.2vmin, 12px)/1 'Courier New', ui-monospace, monospace; letter-spacing: .34em; text-transform: uppercase; color: #b8b0c4; opacity: 0; z-index: 2; pointer-events: none; transition: opacity 1.6s; }
#drCine .dr-pause { position: absolute; inset: 0; display: none; align-items: center; justify-content: center; background: rgba(0,0,0,.74); z-index: 60; pointer-events: auto; }
#drCine .dr-pause.on { display: flex; }
#drCine .dr-pause-box { max-width: 86vw; width: 420px; text-align: center; color: #e4dcee; font-family: 'Courier New', ui-monospace, monospace; padding: 26px 22px; border: 1px solid rgba(200,180,230,.4); background: rgba(12,8,20,.88); }
#drCine .dr-pause-title { letter-spacing: .5em; font-size: 15px; margin-bottom: 14px; color: #fff; }
#drCine .dr-pause-text { font-size: 13px; line-height: 1.6; margin-bottom: 20px; opacity: .85; }
#drCine .dr-pause-btns { display: flex; gap: 12px; justify-content: center; }
#drCine .dr-pause-btns button { flex: 1; font: inherit; font-size: 13px; letter-spacing: .12em; padding: 12px 8px; color: #f0eaf8; background: rgba(80,60,110,.55); border: 1px solid rgba(200,180,230,.55); cursor: pointer; touch-action: manipulation; }
#drCine .dr-pause-btns .dr-leave { background: rgba(110,40,40,.5); border-color: rgba(230,150,150,.55); }
`;

export function createDreamCinematic(opts = {}) {
    const getAudioContext = opts.getAudioContext || (() => null);
    const testGL = (() => { try { const c = document.createElement('canvas'); return !!c.getContext('webgl2'); } catch (e) { return false; } })();
    let blurKey = '', root = null, cv = null, gl = null, prog = null, U = {}, bloom = null, bctx = null, bFrame = 0;
    let paused = false, pauseStart = 0, cineCtx = null, onLeaveCb = null, audio = null, active = false, skipRequested = false;
    let rafId = 0, renderScale = 1, baseScale = 1, fastFrames = 0, slowFrames = 0, lastTs = 0, startTs = 0, blackDone = false;

    function mount() {
        if (!document.getElementById('drCineStyle')) { const s = document.createElement('style'); s.id = 'drCineStyle'; s.textContent = CSS; document.head.appendChild(s); }
        root = document.createElement('div'); root.id = 'drCine';
        root.innerHTML = '<canvas class="dr-cv"></canvas><canvas class="dr-bloom" width="256" height="144"></canvas><div class="dr-bar t"></div><div class="dr-bar b"></div><div class="dr-hint">double-tap to pause</div>' +
            '<div class="dr-pause"><div class="dr-pause-box"><div class="dr-pause-title">PAUSED</div><div class="dr-pause-text">Leave the game? When you come back, this scene starts over from the beginning.</div><div class="dr-pause-btns"><button type="button" class="dr-resume">Keep watching</button><button type="button" class="dr-leave">Leave</button></div></div></div>';
        document.body.appendChild(root);
        cv = root.querySelector('.dr-cv'); bloom = root.querySelector('.dr-bloom'); try { bctx = bloom.getContext('2d'); } catch (e) { bctx = null; }
        gl = cv.getContext('webgl2', { antialias: false, alpha: false, powerPreference: 'high-performance', preserveDrawingBuffer: !!opts.preserveDrawingBuffer });
        if (!gl) throw new Error('WebGL2 unavailable');
        const mk = (type, src) => { const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s); if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error('dream shader: ' + gl.getShaderInfoLog(s)); return s; };
        prog = gl.createProgram(); gl.attachShader(prog, mk(gl.VERTEX_SHADER, VERT)); gl.attachShader(prog, mk(gl.FRAGMENT_SHADER, FRAG)); gl.linkProgram(prog);
        if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error('dream link: ' + gl.getProgramInfoLog(prog));
        gl.useProgram(prog); gl.bindVertexArray(gl.createVertexArray());
        ['uRes', 'uTime', 'uLT', 'uK', 'uTanFov', 'uWarp', 'uBlack', 'uWhite', 'uFlash', 'uLean', 'uWater', 'uDis', 'uLight', 'uSq', 'uDoorZ', 'uClockZ', 'uBeat', 'uWaveR', 'uOrgSky', 'uLid', 'uGlitch', 'uShatter', 'uStreak', 'uBubble', 'uHeat', 'uSunB', 'uGateZ', 'uSkyYaw', 'uSkyRoll', 'uMoon', 'uGD', 'uShot', 'uCam', 'uF', 'uR', 'uU', 'uHandA', 'uHandB', 'uChildPos', 'uHandOn', 'uChild', 'uLocket'].forEach(n => { U[n] = gl.getUniformLocation(prog, n); });
        renderScale = Math.max(0.5, Math.min(window.devicePixelRatio || 1, 1.5) * 0.7); baseScale = renderScale;
        resize(); window.addEventListener('resize', resize);
    }
    function resize() {
        if (!cv) return;
        const w = Math.max(2, Math.floor(window.innerWidth * renderScale)), h = Math.max(2, Math.floor(window.innerHeight * renderScale));
        if (cv.width !== w || cv.height !== h) { cv.width = w; cv.height = h; }
    }
    function unmount() {
        window.removeEventListener('resize', resize);
        if (gl) { const ext = gl.getExtension('WEBGL_lose_context'); if (ext) ext.loseContext(); }
        if (root && root.parentNode) root.parentNode.removeChild(root);
        root = cv = gl = prog = bloom = bctx = null; U = {};
    }
    function draw(S) {
        if (!gl) return;
        gl.viewport(0, 0, cv.width, cv.height);
        if (!S.on) { gl.clearColor(0, 0, 0, 1); gl.clear(gl.COLOR_BUFFER_BIT); return; }
        gl.uniform2f(U.uRes, cv.width, cv.height); gl.uniform1f(U.uTime, S.t); gl.uniform1f(U.uLT, S.lt); gl.uniform1f(U.uK, S.k);
        gl.uniform1f(U.uTanFov, S.tanFov); gl.uniform1f(U.uWarp, S.warp); gl.uniform1f(U.uBlack, S.black); gl.uniform1f(U.uWhite, S.white);
        gl.uniform1f(U.uFlash, S.flash); gl.uniform1f(U.uLean, S.lean); gl.uniform1f(U.uWater, S.water); gl.uniform1f(U.uDis, S.dis); gl.uniform1f(U.uLight, S.light);
        gl.uniform1f(U.uSq, S.sq); gl.uniform1f(U.uDoorZ, S.doorZ); gl.uniform1f(U.uClockZ, S.clockZ); gl.uniform1f(U.uBeat, S.beat); gl.uniform1i(U.uShot, S.shot);
        gl.uniform3fv(U.uCam, S.pos); gl.uniform3fv(U.uF, S.f); gl.uniform3fv(U.uR, S.r); gl.uniform3fv(U.uU, S.u);
        gl.uniform3fv(U.uHandA, S.hA); gl.uniform3fv(U.uHandB, S.hB); gl.uniform2f(U.uHandOn, S.hOn[0], S.hOn[1]);
        gl.uniform3fv(U.uChildPos, S.child.pos); gl.uniform4f(U.uChild, S.child.yaw, S.child.s, S.child.arm, S.child.on);
        gl.uniform4fv(U.uLocket, S.locket);
        gl.uniform1f(U.uWaveR, S.waveR); gl.uniform1f(U.uOrgSky, S.orgSky); gl.uniform1f(U.uLid, S.lid); gl.uniform1f(U.uGlitch, S.glitch); gl.uniform1f(U.uShatter, S.shatter);
        gl.uniform1f(U.uStreak, S.streak); gl.uniform1f(U.uBubble, S.bubble); gl.uniform1f(U.uHeat, S.heat); gl.uniform1f(U.uSunB, S.sunB); gl.uniform1f(U.uGateZ, S.gateZ);
        gl.uniform1f(U.uSkyYaw, S.moon[2]); gl.uniform1f(U.uSkyRoll, S.moon[3]); gl.uniform2f(U.uMoon, S.moon[0], S.moon[1]); gl.uniform3fv(U.uGD, S.gd);
        if (cv) { const px = S.blur * (window.innerHeight / 360), key = px > 0.3 ? px.toFixed(1) : ''; if (key !== blurKey) { blurKey = key; cv.style.filter = key ? 'blur(' + key + 'px)' : ''; } }
        gl.drawArrays(gl.TRIANGLES, 0, 3);
        if (bctx && (opts.preserveDrawingBuffer || (bFrame++ & 1) === 0)) { try { bctx.drawImage(cv, 0, 0, 256, 144); } catch (e) { bctx = null; } }
    }
    function finish(resolve, whileBlack) {
        active = false; paused = false; cancelAnimationFrame(rafId);
        const done = async () => {
            if (audio) { audio.stop(); audio = null; }
            document.removeEventListener('keydown', onKey);
            if (!blackDone) { blackDone = true; try { if (whileBlack) await whileBlack(); } catch (e) { console.error(e); } }
            draw({ on: false });
            if (root) { root.style.transition = 'opacity .8s ease'; root.classList.remove('on'); setTimeout(unmount, 900); }
            window.__ffCineActive = false;
            resolve();
        };
        done();
    }
    function setPaused(on) {
        if (!active || on === paused) return;
        paused = on;
        const pe = root && root.querySelector('.dr-pause');
        if (on) { pauseStart = performance.now(); try { if (cineCtx) cineCtx.suspend(); } catch (e) {} if (pe) pe.classList.add('on'); }
        else { startTs += performance.now() - pauseStart; lastTs = 0; slowFrames = 0; fastFrames = 0; try { if (cineCtx) cineCtx.resume(); } catch (e) {} if (pe) pe.classList.remove('on'); }
    }
    const onKey = (e) => { if (e.key === 'Escape') setPaused(!paused); };

    function frame(now, resolve, whileBlack) {
        if (!active) return;
        rafId = requestAnimationFrame((n) => frame(n, resolve, whileBlack));
        if (paused) return;
        const t = (now - startTs) / 1000;
        if (lastTs) {                                                    // keep it smooth on slow devices
            const dt = now - lastTs;
            if (dt > 38) { slowFrames++; fastFrames = 0; } else if (dt < 19) { fastFrames++; slowFrames = 0; } else { slowFrames = 0; fastFrames = 0; }
            if (slowFrames > 14 && renderScale > 0.42) { renderScale = Math.max(0.42, renderScale * 0.85); slowFrames = 0; resize(); }
            else if (fastFrames > 150 && renderScale < baseScale) { renderScale = Math.min(baseScale, renderScale * 1.08); fastFrames = 0; resize(); }
        }
        lastTs = now;
        if (skipRequested || t >= T_END) { finish(resolve, whileBlack); return; }
        const S = stateAt(t);
        draw(S);
        if (audio) audio.tick(t, S);
        if (root) { root.classList.toggle('bars', t > 0.8); const h = root.querySelector('.dr-hint'); if (h) h.style.opacity = (t > 4 && t < 12) ? 0.5 : 0; }
        if (!blackDone && t >= TE[NS - 1] + 4.0) { blackDone = true; Promise.resolve().then(() => whileBlack && whileBlack()).catch((e) => console.error(e)); }
    }

    return {
        supported: testGL,
        get active() { return active; },
        skip() { skipRequested = true; },
        // Plays the whole dream. whileBlack runs once the picture has gone to black for the last time, just before the cover fades out.
        play(o = {}) {
            return new Promise(async (resolve) => {
                if (!testGL) { resolve(); return; }
                try { mount(); } catch (e) { console.error(e); try { unmount(); } catch (e2) {} resolve(); return; }
                active = true; skipRequested = false; blackDone = false; window.__ffCineActive = true;
                let tapT = 0; onLeaveCb = typeof o.onLeave === 'function' ? o.onLeave : null;
                root.addEventListener('pointerdown', (e) => {
                    if (e.target && e.target.closest && e.target.closest('.dr-pause')) return;
                    const n = performance.now(); if (!paused && n - tapT < 450) { setPaused(true); tapT = 0; return; } tapT = n;
                });
                const rb = root.querySelector('.dr-resume'), lb = root.querySelector('.dr-leave');
                if (rb) rb.addEventListener('click', (e) => { e.stopPropagation(); setPaused(false); });
                if (lb) lb.addEventListener('click', (e) => { e.stopPropagation(); if (onLeaveCb) onLeaveCb(); });
                document.addEventListener('keydown', onKey);
                const ctx = getAudioContext(); cineCtx = ctx || null;
                if (ctx) { try { if (ctx.state === 'suspended') ctx.resume(); audio = createAudio(ctx); } catch (e) { console.warn('dream audio failed', e); audio = null; } }
                root.getBoundingClientRect(); root.classList.add('on');
                await new Promise(r => setTimeout(r, 120));
                startTs = performance.now(); lastTs = 0; slowFrames = 0;
                rafId = requestAnimationFrame((n) => { startTs = n; frame(n, resolve, o.whileBlack); });
            });
        },
        debug: {
            stateAt, duration: T_END, marks: { TS, TE },
            mount() { mount(); root.classList.add('on'); root.style.transition = 'none'; root.style.opacity = '1'; },
            renderAt(t) { const S = stateAt(t); draw(S); return S.shot; },
            unmount,
            // Renders the whole soundtrack offline and returns it as base64 16-bit PCM (mono mix of the left channel) for inspection.
            // Renders the whole soundtrack offline (stereo, interleaved 16-bit PCM, base64), with the beds steered by the real timeline.
            async renderAudioOffline(sr = 44100, len = T_END, from = 0) {
                const ctx = new OfflineAudioContext(2, Math.ceil(sr * (len - from)), sr);
                const a = createAudio(ctx); a.scheduleAll(from);
                for (let t = from; t < len; t += 0.1) a.update(stateAt(t), t - from);
                const buf = await ctx.startRendering(); const L = buf.getChannelData(0), R = buf.getChannelData(1), pcm = new Int16Array(L.length * 2);
                for (let i = 0; i < L.length; i++) { pcm[2 * i] = Math.max(-1, Math.min(1, L[i])) * 32767; pcm[2 * i + 1] = Math.max(-1, Math.min(1, R[i])) * 32767; }
                const u8 = new Uint8Array(pcm.buffer); let bin = ''; for (let i = 0; i < u8.length; i += 0x8000) bin += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000));
                return btoa(bin);
            },
        },
    };
}
