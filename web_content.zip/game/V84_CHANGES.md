# v84 - the last story fixes
`game.js` passes a syntax check; the artifact JSON parses. Not run in a browser.

- **Obelisk line fixed.** It still said the AI did not know whose machine it was, which contradicted the confession that now comes first. It now reads: "...I'm one of those machines, the kind no court would ever hear. I'm still working out what I'm for. For now, I think the answer is you."
- **Vale leader's launch line.** The mixed signal (asked to destroy the Leviathan, then handed an escape course) is now explicit: "The ship is yours, and so is the choice. We asked you to finish this war, but we will not hold you to it. The course is set... Live."
- **Early plant.** At the end of the boot sequence the AI says its core sits in the housing on the player's back (the only place it runs) and that one directive survived the fall: "your survival takes absolute priority". This is the first plant of the line the storm and the cinematic card pay off, and it sets up the physical core for a later ejection.

## Not done
- The gas-giant storm plant: this build has no gas-giant look beat to hang it on.
- The locket payoff and a real Phase 6 handoff: the player is still placed back at the shelter after the fall until Phase 6 exists.
