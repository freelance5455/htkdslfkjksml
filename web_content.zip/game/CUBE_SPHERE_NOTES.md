# v34 - cube-sphere world, stage 2a: true 3D terrain generator

## What changed since v33
- terrain_core.js is now a 3D SPHERE generator. Every landform is a function of P = unit direction * PLANET_R (3D simplex noise,
  analytic-gradient ridged noise, spherical plate Voronoi, hotspot/seamount point lists). No lon/lat map, no antimeridian seam blend,
  no east-west squeezing at high latitude (measured E-W/N-S feature ratio: ~1.0 at every latitude; the old generator was 2.1x at 70N, 3.2x at 80N).
- API: sample3 / sampleSmooth3 / microAt3 / classify3 / warm3 / rainDir / macroHeight3 / wetness3 / isHostile3 (P in world units).
  The old (map x,z) names remain as wrappers for the not-yet-ported river code.
- Plates: 32 jittered Fibonacci sites (exactly 47% continental), each with an Euler-pole rotation (relative velocity varies along a boundary).
- Climate cache (height + rainfall) lives on the six face lattices (~4970-unit nodes, 2-node margin); the rain-bearing wind is integrated
  over the sphere following the prevailing wind of the latitude it passes over. Climate is still driven by true latitude.
- Fixed two latent cliff bugs in the original generator: (1) a hard switch at continentalness 0.1 (up to 2.5 km step where a trench meets a
  coast), (2) plate-boundary contributions were summed only from the nearest plate's side, so a Voronoi edge near a triple junction had a
  different landform set on each side. Now: pair formulation + roles follow the jittered boundary. Cliffs > 150 m per 10 units:
  ~0.04% of steps (old) -> ~0.001% (new).
- chunk_core.js / game.js: chart -> chartToGeo -> P; the seam cross-fade code is gone. Spawn ring search limited to 380k units.

## Consequences
- The world content is different everywhere (new noise field), including near face 0's old centre. Seeds produce different worlds than v33.
- Per-sample cost: sampleSmooth ~7 us (old 26 us), classify ~3 us, microAt ~0.18 us (old 0.10 us).

## Still to do (stage 2b+)
- Rivers (tracing, carving, water ribbons) still need porting to the charts; RIVERS_ENABLED stays false.
- Chart distortion (~0.7x ground units across face edges), props re-roll once at a face edge, old saves load into face 0 coordinates.
- NOT play-tested in a browser (no network for three.js here); generator, chunk builder and face-edge continuity verified headless in Node.

# v35 - archipelago world + smoother land (terrain tuning only)
Tuning constants are at the top of the class section in terrain_core.js (CONT_FRAC, COAST_ROUGH, SEA_BIAS, HOTSPOT_DENSITY, UPLIFT_SCALE, RIDGE_OCTS).
- Land: ~55% -> ~25% (23-27% over 5 seeds); largest landmass 91% -> ~30% of all land, ~180 separate landmasses at 1.5 deg sampling.
  Fewer/smaller continental plates (30%), more broken coastlines, 2.75x the volcanic island chains.
- Roughness: median land slope 0.24 -> 0.12 (14 deg -> 7 deg), 90th percentile 0.89 -> 0.47, slopes steeper than 45 deg 8% -> 2.6% (mountains only).
  Rounder ridge crests, 5 instead of 8 ridge octaves, mountains x0.6, gentler hills / spines / terraces / gullies / micro relief.
- Fixed a NaN from fractional powers of (1 - |noise|) (the 3D noise can slightly exceed 1).
- Re-verified: cliffs >150 m per 10 units: 0 of 180k; chunk builds clean; face-edge heights agree to 1e-10; a spawn site exists on all 8 seeds tried.

# v36 - phase three: rivers and the other systems on the sphere
## Rivers (rivers are ON again: RIVERS_ENABLED = true)
- river_core.js: rivers are TRACED ON THE SPHERE (steepest descent of the macro height along great circles, heading carried by parallel
  transport, meanders as lateral great-circle offsets, valley-snap sideways on the sphere). Output = 3D unit vectors (stride 8).
  Source cells are cells of each face's chart; a spring is accepted only inside its own face so no river is traced twice.
- riverToChart(face, ...) turns a sphere river into the planar chart of the face the player is on (widths scaled by the local chart
  length ratio). riverCellsForRect(face, rect, reach) lists the source cells (of any face) that can send a river into a chart rectangle,
  so rivers flow straight across cube-face edges (verified: the same curve in both charts to ~0.002 units).
- river_carve.js / chunk_core.js: all wrap-around code removed (the chart is planar).
- game.js RIVERS manager: requests [face,cx,cz] cells, caches the traced SPHERE rivers (cache3), converts to the current chart, and on a face
  handover calls rebuildForFace(): nothing is re-traced, the cached rivers are only converted again, nearest the player first.
- river_worker.js speaks the new [face,cx,cz] protocol.
## Weather / clouds
- The weather noise now lives in a canonical frame u = M*chart + t that is updated at every handover (wxHandover), so storms and cloud decks
  stay put when you cross a face edge (the algebra is exact: 1e-10 drift over 12 chained handovers). The cloud shaders use the same frame
  (uniform wxM4). The per-chart climate cache is cleared on handover. Wind direction is rotated into the current chart.
## Misc
- Prop hashing / destroyed-prop keys no longer wrap. (Scatter lattices are still per-chart, so trees near the player re-roll once on a handover.)
## Verified headless (no browser): river tracing (downhill, valid), edge-crossing rivers identical in both charts, real RIVERS manager run end to
   end (request -> trace -> finish -> export -> carve -> query -> handover -> rebuild), chunk builder with real river data (carve + water mesh,
   no NaN), weather frame algebra, terrain regression (0 cliffs / 40k steps). NOT tested in a browser.

# v38 - broken-up, mountain-spined landmasses (terrain_core.js, one small game.js change)
Continents were big discs around "continental plates" (flat interiors, one landmass was ~40-50% of all land). Land is now generated independently of the plates:
- `_buildLandmasses()`: ~215 jittered sites, each (gated by an ocean-basin noise so some regions are open ocean and others archipelagos) starts a wandering,
  gently curving CHAIN of overlapping discs. Radius pinches and swells along the chain (straits / separate islands), chains taper at the ends, ~30% sprout a
  shorter branch (peninsulas / feather ridges). Stored in a SphereIndex; `_terrain` sums them into landness L and spine strength S.
- A mountain spine runs down the middle of every chain (SPINE_UPLIFT, per-landmass strength 0.45-1.0) on top of a smooth swell, so flanks stay walkable.
- Plate-boundary uplift is kept at TECT_UPLIFT = 45% (and damped further on land that is not on a continental plate); active-margin land boost x0.25.
- Hotspot chains: 3x longer (7 volcanoes, slower decay) and taller so they surface as proper island chains; cones are much lower where they sit on a landmass.
- UPLIFT_SCALE 0.60 -> 0.66. Fixed a NaN (negative noise to a fractional power in arc cones).
- game.js: spawn search accepts smaller islands (neighbour ring 4000 -> 2500 units, max neighbour height 700 -> 1100).
Measured (5 seeds): land 25-33% (was ~23%); ~770 landmasses (was ~110-200); largest = 13-25% of land (was 38-51%); median land slope 0.13 -> 0.20,
p90 0.45 -> 0.65 (55 deg climb limit = 1.43); 40+ biomes on land; spawn site found on 10/10 seeds; chunk builder clean (0 NaN).
Tuning knobs (top of terrain_core.js): SPINE_SITES / SPINE_KEEP (how many chains), LAND_THRESH (land vs sea), SPINE_UPLIFT, TECT_UPLIFT, UPLIFT_SCALE.
NOT play-tested in a browser.

# v38b - the "not fixed" list from the cube-sphere passes
- Props no longer re-roll on a face crossing: buildScatter now works from ONE lattice per cube face (nodes at multiples of SCATTER_STEP in the HOME
  chart of each point). Every random number is hashed from (home face, home lattice index); nodes of the current chart beyond its edge are skipped and
  supplied by the neighbouring face's lattice, mapped into the current chart. Verified: props seen from face 0 and from face 1 across the same edge
  are the same trees (5080 of 5344 matched, the rest fall outside the second window). Tree-density noise is now 3D (sphere) noise.
- Destroyed props: propKey is (home face, home lattice index, resource), so a tree you cut stays cut on both sides of an edge (5069/5080 keys agree;
  the ~0.2% that differ sit exactly on the seam line). Old save keys keep the same format.
- River tracing: workers min(3, cores/3) -> min(4, cores/2). Tracing cost measured: 0.59 ms/cell (2400 cells, 731 rivers) in the new world.
- NOT changed: chart stretch near face edges (inherent to a cube-sphere chart; widths of rivers are already compensated).

# v39 - rivers, deltas, lakes, gentler terrain (NOT play-tested in a browser; verified headless only)
- Rivers: no waterfall staircase (one smooth, never-rising surface); channel depth 2-10 units; calmer meanders; rivers start/end on gentler slopes;
  carve is a shallow trough with banks sized to the river width (no levees, no 520-unit walls); springs from 22 units up, shorter rivers kept.
- Delta: last ~14 points fan out (x3.6 width), surface settles to sea level, banks turn to murky mud/swamp (chunk_core.js).
- River shader rewritten (game.js, materials.river): no waves, depth colour, flow streaks, thin foam, fades into ocean colour at the mouth.
- Terrain (terrain_core.js): softer terraces/escarpments/gullies/badlands/pillars; foothill curve (FOOT_EXP); coastal beach + plain; coast noise fades
  inland; narrower mountain spine (SPINE_NARROW); lakes + ponds (LAKE_T, POND_T): ~5-6% of land is inland water in headless sampling.

# v39b - archipelago clusters (terrain_core.js, _buildLandmasses)
- CLUSTER_FRAC (0.55) of landmass sites now become a cluster: a hero island (45% are 'peak islands' with one big mountain rising straight from the sea,
  spine uplift x1.9), 3-8 satellite islands of mixed size (some with twins), and 3-7 rocky islets / sea stacks. The rest stay as chains.
- Wide shallow shelf (shelfW 0.12-0.26) so channels and lagoons between islands stay shallow; LAND_THRESH 0.29 -> 0.32 keeps land at ~33%.

# v40b - hidden / enchanted valleys (terrain_core.js)
- A rare smooth noise field (VALLEY_T = 0.80; lower = more valleys) makes closed inland basins: flat low floor, wall of mountains all the way round
  (no gaps), only where the ground is well inland. ~1-2% of land in headless sampling; never forced. New biome ENCHANTED_VALLEY (vivid green/teal/gold tints,
  trees + flowers, fluorite crystals). Rivers that run into one end in a lake on the floor via the normal tracer.
- v40c: valleys made smaller/narrower: field frequency 0.000034 -> 0.000052, VALLEY_T 0.80 -> 0.77 (keeps ~1-2% of land), wall height 1050+450 -> 850+350.

# v43 - V15-style terrain, no rivers (terrain_core.js, one flag in game.js)
Goal: get the calm, believable, rolling look of the old v15 generator back, keeping v42's sphere, climate, ~85 biomes and ocean features.
- LAND: the disc-chain / archipelago-cluster landmass model (v37-v39) is gone. Continents are the v15 construction (6-octave domain-warped fbm at
  0.000014, ragged-coast noise, scattered island-chain mask) evaluated as 3D noise on the sphere. Tuning: CONT_FREQ, CONT_BIAS (0.17 -> ~30% land).
- MOUNTAINS: v15-style inland belts (foothills -> ranges, gated by a low-frequency range field; need properly inland ground) feed v42's eroded ridged
  relief (RANGE_UPLIFT). Plate-boundary uplift is full strength offshore but is damped on land and fades in gradually inland (LAND_TECT_DAMP, landTaper),
  so there is no wall of mountains at a coast. Hill amplitude HILL_AMP gives v15-style rolling ground.
- OCEAN: seafloor tectonics (ridges, arcs, plateaus, seamounts) can build the floor up but are squeezed below the waterline; only hotspot volcanoes and the
  island-chain mask make new islands (no more spiky rock islands in every shallow sea).
- FIXED a coast cliff: the ocean-floor extras were gated off at cv < 0.02 while their mask was still ~0.6 there (up to 1.5 km step at every coast).
- REMOVED: gullies/dells in _variety, lakes and ponds (LAKES_ENABLED = false), land-based arc cones and most land volcanoes (volc x0.12 on land).
- RIVERS: RIVERS_ENABLED = false in game.js. No tracing, no workers, no carving, no water ribbons. (river_*.js files are kept only because chunk_core.js
  imports a noise class from river_core.js.)
- Headless numbers (3 seeds, v42 -> v43; v15 for reference): land 32% -> 30% (v15 29%); land height p50/p90/p99 480/1800/3700 -> 350/1230/3000 (v15 520/1400/2430);
  slope per 40 units p90 0.65 -> 0.38 (v15 0.54), p99 2.4 -> 1.0 (v15 1.1); share of ground steeper than the 55 deg climb limit 3.0% -> 0.3% (v15 0.2%);
  cliffs (>3 per unit at 22-unit steps) 0.58% -> 0.07% of land cells; biomes reached in 100k samples: 84 of 87 (v42: 85 of 87). Chunk builder: 0 NaN.
- NOT play-tested in a browser (no three.js / network here); generator and chunk builder verified headless in Node.
