# v97 - terrain pace, soft head bob, better footstep audio

**Terrain-dependent speed** (updatePlayer, right after the base speed is built)
- Slope: softened Tobler hiking curve on the grade along your direction of travel. Gentle downhill is a touch faster (x1.1),
  uphill slows (about x0.68 at 20% grade, floor x0.5), steep descents also slow a little (braking).
- Surface: sand x0.9, snow x0.84 (on top of the existing deep-snow slow), mud x0.78. Wading in shallow water slows up to 30%.
- The multiplier is low-passed (about 0.3 s) so ridges and biome edges ease in. Does not apply while flying or swimming.

**Soft head bob** (replaces the old single sine)
- Phase is locked to the real footfalls (the same accumulator that fires the footstep sound), so the eye dips as each foot lands.
- Vertical: one cycle per step, ~0.085 half-range walking to ~0.16 sprinting (old bob was 0.25). A faint alternating roll (<=0.3 deg)
  gives the left/right weight shift. Eases in/out, shrinks at very low speed. Landing adds a short soft dip scaled by fall speed.
- Running strides are 40% longer, so cadence rises less than before.

**Sounds**
- Footsteps are heel + toe pairs, alternate left/right (small stereo offset), vary slightly in pitch each step, get louder/brighter
  with a soft cloth rustle when running. New per-surface texture: grass swish, sand hiss, snow crunch, stone tick + grit, mud squelch,
  wading splash/droplets (shallow water now sounds like water, not ground).
- Landing thud scales with fall speed, with a low body thump on big drops.
- Soft breathing (three fading breaths) after a sprint of 6+ seconds.
- Sprint button gives a soft click.
- playNoiseBurst gained optional delay / rate / pan options.

Tuning knobs: the 1.9 exponent and 0.5 / 1.1 clamps (slope), the surface multipliers, `amp` and roll constants (bob).
Not run on a GPU or in a browser in this build environment.
