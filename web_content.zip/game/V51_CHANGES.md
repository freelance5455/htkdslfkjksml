# v51 - face-crossing and teleport fixes (NOT run in a browser: no three.js / network in the authoring environment)

## Cube-face handover (game.js recenterWorldIfNeeded)
- The city root (CityWorld.root) was in scene.children, so every handover rotated/translated it, while the cities inside were also re-placed in the
  new chart coordinates -> double transform, cities displaced/rotated, and it accumulated on every crossing. Objects with userData.noHandover are now skipped
  (the city root sets it); CityWorld.onChartChange() resets the root.
- Hysteresis: handover only once the player is 1200 units PAST the face edge (CHART_HANDOVER_HYST). Before, jittering over the seam rebuilt the whole world each time.
- Old terrain meshes are kept as stand-ins (LEGACY_CHUNKS, moved rigidly with the world, raised 1.5 units) until the new chunks under them are ready at target detail
  (max 9 s), instead of deleting all ground. Trees/props of the old chart are dropped immediately.
- chartChangedRefresh(): weather climate cache cleared and the 56x56 weather map rebuilt synchronously (a half-finished slice pass mixed two charts and the
  shaders read it around the old centre), lightning cleared, valley-mist basin map invalidated, city world told. Also run after a debug teleport.
- Plankton points hold world coordinates and are fixed up explicitly; moons are no longer rotated.

## Teleport
- Previously left weather map / climate / mist / city state in the old chart.

## Cities
- Sites not part of the current chart are hidden (they kept stale coordinates from another face).
- Watchdog: a city job not answered in 9 s is built on the main thread; failures are logged ([Vale] ...) and the HUD "VALE CITY" line shows the state
  of a nearby city when it is not ready (building / failed (reason)).
- Verified headless: city generation for all sites on 4 seeds (0 failures), structured-clone + transfer of worker output, placement on the valley floor,
  stub runtime with face switches. Existing tests pass.

# v52 additions (city never appearing even on the spawn face)
- Not face related: investigated the whole city path (sites -> worker job -> structured clone -> meshes -> placement). Everything verified headless
  (real worker module in a Node worker thread, cloned/transferred output, placement vs chunk terrain within ~1 unit on the floor). The remaining untested piece is the GPU.
- CityWorld._shaderCheck: after ~6 frames on screen, reads the wall material's program diagnostics; if the window shader failed to compile it logs the GLSL error
  and swaps in a plain material.
- HUD "VALE CITY" line now always shows a status within 12 km: building <seconds> / ready shader:ok|FAILED vis:1|0 / failed (reason).
