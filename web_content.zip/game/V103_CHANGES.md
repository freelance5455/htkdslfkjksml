# v103 — the dream, rebuilt (dream_cinematic.js)

- Length 1:45 -> about 3:26. Six scenes: kitchen, THE GREEN (new: wild ancient dawn that a ring of light tidies into a grid world, one unbroken walk, ends at a gate), corridor, hearing, THE DRIFT (new: shuttle cabin, floating photo/page/locket, moon + giant in the window, plunge), water.
- Old + new in one frame: painterly look kept, but holograms, light-lines, glowing faces, data crystals, a ring of light, spires and an orbital arc are laid over it.
- Head bob is locked to distance walked (one soft rise/fall per footstep, ~1 cm instead of 2-3 cm, no fixed 1.7 Hz). Footstep sounds use the same step times.
- No pop-ins: child scans in / steps out of the door light, hands rise in from below the frame, locket scales out of the palm, the green's new objects appear as the wave passes, distant things sit behind haze.
- Each cut is different: eyelid wake + focus pull, sun bloom (match cut on the sun), glitch tear at the gate, slow blink, shatter on the third blow, plunge streaks + splash bubbles.
- Timeline/shader scene ids differ (SID); game.js hook unchanged (createDreamCinematic API the same).
