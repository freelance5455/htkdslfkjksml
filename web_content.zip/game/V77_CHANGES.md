# v77 - holographic telemetry

freefall_cinematic.js: the telemetry is now real 3D geometry inside the raytraced cockpit instead of a flat DOM overlay.
- Two projected panels (mission elapsed time + status on the left, altitude -> giant limb distance -> pressure/skin temperature on the right), each drawn as three depth-layered planes for volumetric ghosting, with scanlines, corner brackets and occasional glitch tears.
- A rotating wire globe above the dash with a ship marker that spirals inward over the whole fall, wrapped in a canopy-integrity ring (ticks, fills with the remaining %).
- Everything is intersected from the pilot's head, so it parallaxes with head movement and lean, goes soft when the pilot's vision blurs, flickers with the power and goes red-orange with the alarm.
- Panel text is painted to two small canvas textures (10 Hz) and sampled in the shader. Panels shrink and move in for portrait screens.
- Fallback: if the hologram shader fails to compile/link or the textures fail, the flat v76 HUD is used automatically.

Verified: syntax, shader source injection and brace balance, full-timeline dry run with a stubbed DOM/GL (no errors). NOT verified on a real GPU: the GLSL has never been compiled by a real driver, and placement/brightness has not been seen.
