// ocean_seabed.js - v109 OCEAN OVERHAUL, part 3: the sea floor and the three dive sites.
// The old floor was a cylinder mound under hand-placed boxes. Now each stop is a SEAMOUNT: a sculpted plateau with sand ripples, rock
// outcrops, caustics dancing on it, kelp forests, crystal gardens, falling away into the abyss at its rim. The
// wreck, the monolith and the memorial are rebuilt as real objects, grown over by what lives there.
import * as THREE from 'three';
import { GB, loftGeo, paintMat, swayMaterial, rng, fbm, vnoise, lerp, clamp, smooth, SEA_TIME, canvasTex, metalTexture, stoneTexture } from './ocean_assets.js';
import { registerShaderFallback, dropCustomShader } from './ocean_surface.js';

export const SEAMOUNT_R = 340;            // plateau + shoulder radius
export const SEAMOUNT_SKIRT = 900;        // outer edge of the mesh, deep in the dark
export const CAUSTIC = { value: 1 };      // 0..1 daylight reaching the floor (game drives it)

// ---- height field (local coordinates, y relative to the plateau datum) --------------------------------------------------------------
export function seamountHeight(x, z, seed) {
    const r = Math.hypot(x, z);
    const plateau = 1 - smooth(SEAMOUNT_R * 0.52, SEAMOUNT_R * 1.05, r);               // 1 on the plateau, 0 past the rim
    let h = (fbm(x * 0.004, z * 0.004, seed, 4) - 0.5) * 34 * (0.35 + 0.65 * (1 - plateau * 0.5));
    h += (fbm(x * 0.02, z * 0.02, seed + 9, 3) - 0.5) * 6;
    const ridge = 1 - Math.abs(vnoise(x * 0.012, z * 0.012, seed + 21) * 2 - 1);        // ridged rock outcrops
    h += Math.pow(ridge, 5) * 26 * smooth(70, 200, r) * (0.4 + plateau * 0.6);
    h *= 0.35 + 0.65 * smooth(0, 80, r);                                                // calm sand at the centre where the site stands
    const drop = smooth(SEAMOUNT_R * 0.60, SEAMOUNT_R * 1.15, r);
    h -= drop * drop * 420 + smooth(SEAMOUNT_R * 1.1, SEAMOUNT_SKIRT, r) * 380;
    return h;
}

const SEA_FLOOR_VERT_MARK = '// OCEANFX:seabed';
function seabedMaterial() {
    const m = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 1.0, metalness: 0.0 });
    m.onBeforeCompile = function (shader) {
        shader.uniforms.uSeaTime = SEA_TIME; shader.uniforms.uCaus = CAUSTIC;
        shader.vertexShader = shader.vertexShader
            .replace('#include <common>', `#include <common>\n${SEA_FLOOR_VERT_MARK}\nvarying vec3 vSeaWP;`)
            .replace('#include <begin_vertex>', `#include <begin_vertex>\n    vSeaWP = (modelMatrix * vec4(transformed, 1.0)).xyz;`);
        shader.fragmentShader = shader.fragmentShader
            .replace('#include <common>', `#include <common>
${SEA_FLOOR_VERT_MARK}
uniform float uSeaTime;
uniform float uCaus;
varying vec3 vSeaWP;
float sbCaustic(vec2 p, float t) {
    vec2 q = p;
    float a = 0.0;
    for (int i = 0; i < 3; i++) {
        q += vec2(sin(q.y * 1.7 + t * 0.7 + float(i)), cos(q.x * 1.5 - t * 0.6 + float(i) * 1.3)) * 0.55;
        a += 1.0 - abs(sin(q.x * 2.1) * sin(q.y * 2.3));
    }
    return pow(clamp(a / 3.0, 0.0, 1.0), 7.0);
}
float sbHash(vec2 p) { p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }`)
            .replace('#include <color_fragment>', `#include <color_fragment>
    {
        // sand ripples + painted speckle on the albedo
        float rip = sin(vSeaWP.x * 0.55 + sin(vSeaWP.z * 0.11) * 2.2 + vSeaWP.z * 0.18) * 0.5 + 0.5;
        float spk = sbHash(floor(vSeaWP.xz * 0.9));
        diffuseColor.rgb *= 0.90 + 0.12 * rip + 0.10 * (spk - 0.5);
    }`)
            .replace('#include <emissivemap_fragment>', `#include <emissivemap_fragment>
    {
        float depthK = exp(-max(0.0, -vSeaWP.y) / 95.0);
        float cs = sbCaustic(vSeaWP.xz * 0.035, uSeaTime) * depthK * uCaus;
        totalEmissiveRadiance += vec3(0.30, 0.52, 0.60) * cs * 0.9;
    }`);
    };
    m.customProgramCacheKey = () => 'sea-bed-v1';
    registerShaderFallback(SEA_FLOOR_VERT_MARK.replace('// ', ''), () => dropCustomShader(m, 'seabed'));
    return m;
}

export function makeSeamount(seed) {
    const rings = 76, segs = 128, R1 = SEAMOUNT_SKIRT;
    const pos = new Float32Array((1 + rings * segs) * 3), col = new Float32Array((1 + rings * segs) * 3);
    const radii = []; for (let i = 0; i < rings; i++) { const t = (i + 1) / rings; radii.push(R1 * Math.pow(t, 1.55)); }
    const c = new THREE.Color();
    const sand = new THREE.Color(0xcdb987), sandDk = new THREE.Color(0x9c8a62), alg = new THREE.Color(0x4f6a4a), rock = new THREE.Color(0x5b5a58), rockWarm = new THREE.Color(0x7a6a56), abyss = new THREE.Color(0x0a1626);
    const H = (x, z) => seamountHeight(x, z, seed);
    const put = (vi, x, z) => {
        const h = H(x, z); pos[vi * 3] = x; pos[vi * 3 + 1] = h; pos[vi * 3 + 2] = z;
        const e = 6, sl = Math.hypot(H(x + e, z) - H(x - e, z), H(x, z + e) - H(x, z - e)) / (2 * e);   // slope
        const n = fbm(x * 0.03, z * 0.03, seed + 3, 3), r = Math.hypot(x, z);
        c.copy(sand).lerp(sandDk, clamp(n * 1.3 - 0.2, 0, 1));
        c.lerp(alg, clamp(smooth(60, 200, r) * (n - 0.35) * 2.2, 0, 0.6));
        c.lerp(sl > 0.35 ? rockWarm : rock, smooth(0.18, 0.55, sl));
        c.lerp(abyss, smooth(-70, -330, h));
        col[vi * 3] = c.r; col[vi * 3 + 1] = c.g; col[vi * 3 + 2] = c.b;
    };
    put(0, 0, 0);
    for (let i = 0; i < rings; i++) for (let s = 0; s < segs; s++) { const th = (s / segs) * Math.PI * 2; put(1 + i * segs + s, Math.cos(th) * radii[i], Math.sin(th) * radii[i]); }
    const idx = [], vid = (r, s) => 1 + r * segs + (s % segs);
    for (let s = 0; s < segs; s++) idx.push(0, vid(0, s + 1), vid(0, s));
    for (let i = 0; i < rings - 1; i++) for (let s = 0; s < segs; s++) { const a0 = vid(i, s), a1 = vid(i, s + 1), b0 = vid(i + 1, s), b1 = vid(i + 1, s + 1); idx.push(a0, a1, b0, a1, b1, b0); }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3)); g.setAttribute('color', new THREE.BufferAttribute(col, 3)); g.setIndex(idx); g.computeVertexNormals();
    const mesh = new THREE.Mesh(g, seabedMaterial()); mesh.receiveShadow = true; mesh.frustumCulled = false;
    return { mesh, heightAt: H };
}

// ---- flora ---------------------------------------------------------------------------------------------------------------------------
function ribbon(w, h, segs, bend) {
    return loftGeo(segs, 1, (a, b) => { const t = a; return [(b - 0.5) * w * (1 - t * 0.85) + Math.sin(t * 3 + bend) * w * 0.8 * t, t * h, Math.cos(t * 2.4 + bend) * w * 0.5 * t]; });
}
export function scatterFlora(heightAt, seed, opts) {
    opts = opts || {}; const R = rng(seed * 7 + 1), out = new THREE.Group();
    const kelp = new GB(seed + 1), reef = new GB(seed + 2), glow = new GB(seed + 3), rocks = new GB(seed + 4), grass = new GB(seed + 5);
    const place = (minR, maxR, tries) => { for (let i = 0; i < 30; i++) { const a = R() * 6.2832, r = lerp(minR, maxR, Math.sqrt(R())); const x = Math.cos(a) * r, z = Math.sin(a) * r; return [x, z, heightAt(x, z)]; } };
    // kelp forests: a few dense stands with a clearing around the site
    const stands = opts.kelpStands || 5;
    for (let s = 0; s < stands; s++) {
        const a = R() * 6.2832, r = 110 + R() * 150, cx = Math.cos(a) * r, cz = Math.sin(a) * r;
        for (let k = 0; k < 16; k++) {
            const x = cx + (R() - 0.5) * 70, z = cz + (R() - 0.5) * 70, y = heightAt(x, z), hgt = 28 + R() * 42, w = 3 + R() * 2.5;
            kelp.add(ribbon(w, hgt, 7, R() * 6), { p: [x, y - 1, z], r: [0, R() * 6.28, 0], c: 0x3c5a22, c2: R() < 0.3 ? 0x9a9a3a : 0x6f8c34, jit: 0.1, sway: 7 });
            if (R() < 0.6) kelp.add(ribbon(w * 0.8, hgt * 0.8, 6, R() * 6), { p: [x + 1.5, y - 1, z + 1], r: [0, R() * 6.28, 0], c: 0x34501f, c2: 0x7a9a3c, sway: 6 });
            if (R() < 0.5) kelp.sph(1.2, { p: [x, y + hgt * 0.45, z], c: 0x6a7a2c }, 5, 4);     // float bladders
        }
    }
    // mineral gardens: crystal spires, mossy boulders and stacked slabs (no animals anywhere in the sea)
    const pal = [0x35c9b8, 0x5ab4ff, 0xb084ff, 0x7a8a96, 0x6a9a8a, 0x8a7ab0, 0x4aa8c8];
    const gardens = opts.gardens || 7;
    for (let gI = 0; gI < gardens; gI++) {
        const a = R() * 6.2832, r = 60 + R() * 190, cx = Math.cos(a) * r, cz = Math.sin(a) * r, base = pal[Math.floor(R() * pal.length)], alt = pal[Math.floor(R() * pal.length)];
        const n = 14 + Math.floor(R() * 12);
        for (let k = 0; k < n; k++) {
            const x = cx + (R() - 0.5) * 55, z = cz + (R() - 0.5) * 55, y = heightAt(x, z), kind = R(), col = R() < 0.7 ? base : alt, sc = 0.8 + R() * 1.8;
            if (kind < 0.35) {          // branching
                for (let b = 0; b < 5; b++) { const ang = R() * 6.28, tilt = 0.3 + R() * 0.7, hh = (5 + R() * 6) * sc; reef.cyl(0.25 * sc, 0.9 * sc, hh, 5, { p: [x + Math.cos(ang) * 1.2 * sc, y + hh * 0.5, z + Math.sin(ang) * 1.2 * sc], r: [Math.sin(ang) * tilt, 0, Math.cos(ang) * tilt], c: col, c2: 0xffffff, jit: 0.15, sway: 0.4 }); }
            } else if (kind < 0.6) {    // brain / boulder
                reef.ico(3.2 * sc, 1, { p: [x, y + 0.8 * sc, z], s: [1, 0.62, 1], c: col, c2: new THREE.Color(col).lerp(new THREE.Color(0xffffff), 0.3), jit: 0.18 });
            } else if (kind < 0.82) {   // table / plate
                reef.cyl(4.5 * sc, 0.4 * sc, 0.8 * sc, 8, { p: [x, y + 4.5 * sc, z], c: col, c2: 0xffffff, jit: 0.12 }); reef.cyl(0.7 * sc, 1.1 * sc, 4.5 * sc, 6, { p: [x, y + 2.2 * sc, z], c: 0x6a5a4a });
            } else {                    // spire
                reef.cone(1.6 * sc, 9 * sc, 6, { p: [x, y + 4.0 * sc, z], r: [(R() - 0.5) * 0.3, R() * 3, (R() - 0.5) * 0.3], c: col, c2: 0xffffff, jit: 0.15 });
            }
        }
    }
    // rocks: faceted boulders, arches and tumbled slabs
    const rockN = opts.rocks || 70;
    for (let i = 0; i < rockN; i++) {
        const a = R() * 6.2832, r = 30 + R() * 300, x = Math.cos(a) * r, z = Math.sin(a) * r, y = heightAt(x, z), sc = 2 + Math.pow(R(), 2.5) * 16, wc = R() < 0.4;
        rocks.ico(sc, 0, { p: [x, y + sc * 0.25, z], r: [R() * 3, R() * 6, R() * 3], s: [1 + R() * 0.7, 0.6 + R() * 0.5, 1 + R() * 0.6], c: wc ? 0x76675a : 0x585a5c, c2: wc ? 0x8f7c68 : 0x72767a, jit: 0.2 });
        if (sc > 9 && R() < 0.7) for (let k = 0; k < 4; k++) reef.cone(sc * 0.08, sc * 0.4, 6, { p: [x + (R() - 0.5) * sc, y + sc * (0.5 + R() * 0.3), z + (R() - 0.5) * sc], r: [(R() - 0.5), 0, (R() - 0.5)], c: pal[Math.floor(R() * pal.length)], c2: 0xffffff });   // crystal on big rocks
    }
    for (let i = 0; i < 6; i++) {       // arches
        const a = R() * 6.2832, r = 90 + R() * 200, x = Math.cos(a) * r, z = Math.sin(a) * r, y = heightAt(x, z), s = 9 + R() * 7, ry = R() * 6.28;
        const dx = Math.cos(ry), dz = Math.sin(ry);
        rocks.ico(s * 0.7, 0, { p: [x - dx * s, y + s * 0.6, z - dz * s], s: [1, 1.6, 1], c: 0x5a5c5c, c2: 0x7a7468 }); rocks.ico(s * 0.7, 0, { p: [x + dx * s, y + s * 0.6, z + dz * s], s: [1, 1.6, 1], c: 0x585a5a, c2: 0x7a7468 });
        rocks.box(s * 2.8, s * 0.55, s * 0.9, { p: [x, y + s * 1.7, z], r: [0, -ry, 0.04], c: 0x606262, c2: 0x80786c });
    }
    // seagrass on the sand
    for (let i = 0; i < 260; i++) {
        const a = R() * 6.2832, r = 20 + R() * 300, x = Math.cos(a) * r, z = Math.sin(a) * r, y = heightAt(x, z);
        grass.add(ribbon(0.9, 5 + R() * 6, 4, R() * 6), { p: [x, y, z], r: [0, R() * 6.28, 0], c: 0x3a6a3a, c2: 0x8ac45a, sway: 3.2 });
    }
    const mk = (gb, mat) => { const m = new THREE.Mesh(gb.build(), mat); m.castShadow = false; m.receiveShadow = true; out.add(m); return m; };
    mk(kelp, swayMaterial(paintMat({ roughness: 0.8, side: THREE.DoubleSide }), 1.0, 1.0, 'kelp'));
    mk(reef, swayMaterial(paintMat({ roughness: 0.85 }), 0.55, 0.9, 'reef'));
    const glowMesh = mk(glow, swayMaterial(new THREE.MeshBasicMaterial({ vertexColors: true }), 0.9, 1.3, 'glow'));
    mk(rocks, paintMat({ roughness: 0.95, flatShading: true }));
    mk(grass, swayMaterial(paintMat({ roughness: 0.9, side: THREE.DoubleSide }), 0.9, 1.5, 'grass'));
    out.userData.glowMesh = glowMesh;
    return out;
}

// ---- landmarks ---------------------------------------------------------------------------------------------------------------------
function plaqueTex(lines, hue) {
    return canvasTex(512, 256, (g, w, h) => {
        g.fillStyle = '#10181c'; g.fillRect(0, 0, w, h); g.strokeStyle = hue; g.lineWidth = 3; g.strokeRect(10, 10, w - 20, h - 20);
        g.fillStyle = hue; g.textAlign = 'center'; g.font = 'bold 30px serif';
        lines.forEach((l, i) => g.fillText(l, w / 2, 70 + i * 44));
    }, 1, 1);
}
function growOver(gb, R, cx, cz, h0, h1, spread, n, heightAt, y0) {
    const pal = [0x4a6a3a, 0x5a7a4a, 0x6a8a5a, 0x3a5a4a];
    for (let i = 0; i < n; i++) { const a = R() * 6.28, rr = R() * spread, x = cx + Math.cos(a) * rr, z = cz + Math.sin(a) * rr, y = (heightAt ? heightAt(x, z) : y0) + lerp(h0, h1, R()); gb.ico(0.5 + R() * 1.2, 0, { p: [x, y, z], c: pal[Math.floor(R() * 4)] }); }
}

// THE WRECK: a broken survey shuttle. Lofted fuselage, torn at the break, ribs and stringers showing, one wing and a fin, a cockpit that
// still has a dying nav light, half buried, moss and kelp all over it.
export function makeWreck(heightAt, seed) {
    const R = rng(seed), g = new THREE.Group(), metal = metalTexture();
    const fusFn = (len, r0, r1, ragged) => (a, b) => {
        const th = b * Math.PI * 2, z = a * len, t = a;
        const prof = Math.sin(Math.PI * Math.pow(t, 0.7)) * 0.9 + 0.1;
        const rr = lerp(r0, r1, t) * (0.45 + 0.55 * prof) * (1 + (ragged ? 0.03 * Math.sin(th * 5 + t * 9) : 0));
        return [Math.cos(th) * rr * 1.15, Math.sin(th) * rr * (Math.sin(th) < 0 ? 0.8 : 1.0), z];
    };
    const front = new THREE.Mesh(loftGeo(18, 20, fusFn(34, 9.5, 8.0, true), true), new THREE.MeshStandardMaterial({ map: metal, color: 0xb8c0c8, roughness: 0.62, metalness: 0.55, side: THREE.DoubleSide }));
    const rear = new THREE.Mesh(loftGeo(12, 20, fusFn(20, 7.5, 3.4, true), true), front.material);
    front.castShadow = rear.castShadow = true; front.receiveShadow = rear.receiveShadow = true;
    const fg = new THREE.Group(), rg = new THREE.Group(); g.add(fg, rg);
    fg.add(front); rg.add(rear);
    // torn ends: ribs, stringers and hanging cables
    const det = new GB(seed + 5), rib = 0x8a8f94, rust = 0x7a4a2c;
    for (let i = 0; i < 9; i++) { const a = (i / 9) * 6.28, rr = 6 + R() * 2.2; det.box(0.5, 0.5, 3 + R() * 7, { p: [Math.cos(a) * rr, Math.sin(a) * rr * 0.9, 34 + 1.5 + R() * 2], r: [R() * 0.5, R() * 0.5, 0], c: rust, c2: rib }); }
    for (let k = 0; k < 4; k++) det.tor(7.6 - k * 0.4, 0.28, { p: [0, 0, 6 + k * 8], r: [0, 0, 0], c: rib }, 4, 18);
    for (let i = 0; i < 12; i++) det.cyl(0.12, 0.12, 6 + R() * 10, 4, { p: [(R() - 0.5) * 9, (R() - 0.5) * 7, 36 + R() * 3], r: [R() * 1.2, 0, R() * 1.2], c: 0x23262a, sway: 2.2 });
    fg.add(new THREE.Mesh(det.build(), swayMaterial(paintMat({ roughness: 0.7, metalness: 0.3 }), 0.8, 1.0, 'wreckdet')));
    // cockpit glass, dying nav light, engine block, wing, fin
    const cock = new THREE.Mesh(new THREE.SphereGeometry(5.2, 12, 8, 0, 6.28, 0, 1.2), new THREE.MeshStandardMaterial({ color: 0x1c3c48, roughness: 0.1, metalness: 0.6, transparent: true, opacity: 0.8 }));
    cock.position.set(0, 4.4, 4.5); cock.scale.set(1, 0.8, 1.6); fg.add(cock);
    const navMat = new THREE.MeshBasicMaterial({ color: 0x66ffee }); const nav = new THREE.Mesh(new THREE.SphereGeometry(0.6, 6, 5), navMat); nav.position.set(0, 9.2, 14); fg.add(nav);
    const navLight = new THREE.PointLight(0x66ffee, 1.4, 70, 2); navLight.position.copy(nav.position); fg.add(navLight);
    const wing = new GB(seed + 6);
    wing.box(34, 1.0, 12, { p: [20, -1, 6], r: [0, -0.25, -0.12], c: 0x9aa2a8, c2: 0xb8c0c4 }); wing.box(10, 0.8, 7, { p: [31, -0.4, 14], r: [0, -0.25, -0.12], c: 0x6a7076 });
    wing.cyl(3.3, 3.8, 14, 10, { p: [18, -3.4, 4], r: [Math.PI / 2, 0, 0], c: 0x4a4a4e, c2: 0x7a5a3a });
    fg.add(new THREE.Mesh(wing.build(), paintMat({ roughness: 0.6, metalness: 0.5, flatShading: true })));
    const fin = new GB(seed + 7); fin.box(1.0, 18, 11, { p: [0, 10, 8], r: [0.1, 0, 0.12], c: 0x8a9298, c2: 0xb0b8bc }); rg.add(new THREE.Mesh(fin.build(), paintMat({ roughness: 0.6, metalness: 0.5, flatShading: true })));
    // growth: moss, algae and kelp on the metal
    const gr = new GB(seed + 8); const pal = [0x4a6a3a, 0x5a7a4a, 0x6a8a5a, 0x3a5a4a, 0x7a8a6a];
    for (let i = 0; i < 90; i++) { const a = R() * 6.28, z = R() * 33, rr = 8.2 * (0.6 + 0.4 * Math.sin(Math.PI * Math.pow(z / 34, 0.7))); gr.ico(0.5 + R() * 1.4, 0, { p: [Math.cos(a) * rr * 1.1, Math.sin(a) * rr * 0.95, z], c: pal[Math.floor(R() * 5)], jit: 0.2 }); }
    for (let i = 0; i < 12; i++) { const z = 2 + R() * 30; gr.add(ribbon(2.4, 14 + R() * 12, 6, R() * 6), { p: [(R() - 0.5) * 8, 8 + R(), z], r: [0, R() * 6.28, 0], c: 0x3c5a22, c2: 0x7a9a3a, sway: 5 }); }
    fg.add(new THREE.Mesh(gr.build(), swayMaterial(paintMat({ roughness: 0.85, side: THREE.DoubleSide }), 0.7, 1.0, 'wreckgrow')));
    // pose: nose-down in the sand, rear section broken off, rolled
    fg.rotation.set(0.10, 0.0, 0.32); fg.position.set(0, 7, -20);
    rg.rotation.set(-0.08, 0.5, -0.55); rg.position.set(26, 5.5, 52);
    g.userData.update = (t) => { const k = 0.5 + 0.5 * Math.sin(t * 2.2) * Math.sin(t * 0.7 + 1); navMat.color.setRGB(0.4 * (0.3 + k), 1.0 * (0.3 + k), 0.93 * (0.3 + k)); navLight.intensity = 0.2 + 1.5 * k; if (R() < 0.001) navLight.intensity = 0; };
    g.userData.interactLocal = new THREE.Vector3(0, 8, 36);   // on the torn break of the forward section (fg-local)
    return g;
}

// THE MONOLITH: a tall, chamfered slab of dark basalt-glass with a pale carved plaque and glowing inlay seams, ringed by fallen stone and kelp. It hums (the light pulses slowly).
export function makeMonolith(heightAt, seed) {
    const R = rng(seed), g = new THREE.Group(), H = 120, W = 17, D = 9;
    const geo = loftGeo(14, 8, (a, b) => {   // rough-hewn: taper with noise, square section rounded at the corners
        const th = b * Math.PI * 2, y = a * H, t = a, sx = Math.cos(th), sz = Math.sin(th), n = 1 + (vnoise(y * 0.08, th * 2, seed) - 0.5) * 0.12;
        const k = (1 - t * 0.18) * n, px = Math.sign(sx) * Math.pow(Math.abs(sx), 0.4) * W * 0.5 * k, pz = Math.sign(sz) * Math.pow(Math.abs(sz), 0.4) * D * 0.5 * k;
        return [px, y + (a > 0.98 ? -a * 3 * (R() - 0.2) : 0), pz];
    }, true);
    const body = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ map: stoneTexture(), color: 0x59656c, roughness: 0.55, metalness: 0.15, flatShading: true, side: THREE.DoubleSide }));
    body.castShadow = true; body.receiveShadow = true; g.add(body);
    const inlayMat = new THREE.MeshBasicMaterial({ color: 0x57e0ff, transparent: true, opacity: 0.9 });
    const inl = new GB(seed + 2);
    for (let i = 0; i < 6; i++) inl.box(0.35, H * (0.3 + R() * 0.5), 0.35, { p: [(i - 2.5) * 2.6, H * 0.45 + R() * 10, D * 0.5 + 0.1], c: 0x57e0ff });
    for (let i = 0; i < 9; i++) inl.box(2 + R() * 4, 0.3, 0.3, { p: [(R() - 0.5) * 12, 14 + R() * 90, D * 0.5 + 0.15], c: 0x57e0ff });
    const inlay = new THREE.Mesh(inl.build(), inlayMat); g.add(inlay);
    const plaque = new THREE.Mesh(new THREE.PlaneGeometry(10, 5), new THREE.MeshBasicMaterial({ map: plaqueTex(['THE FIRST WITNESS', 'WE WERE HERE', 'AND WE WERE MANY'], '#9be8ff'), transparent: false }));
    plaque.position.set(0, 22, D * 0.5 + 0.3); g.add(plaque);
    const base = new GB(seed + 3);
    for (let i = 0; i < 10; i++) { const a = i / 10 * 6.28 + R(), r = 8 + R() * 6; base.ico(3 + R() * 5, 0, { p: [Math.cos(a) * r, 1.5 + R() * 2, Math.sin(a) * r], r: [R() * 3, R() * 3, 0], s: [1.2, 0.7, 1], c: 0x585a5c, c2: 0x7a7468, jit: 0.2 }); }
    growOver(base, R, 0, 0, 0, 24, 12, 70, null, 0);
    for (let i = 0; i < 9; i++) base.add(ribbon(2.6, 20 + R() * 20, 6, R() * 6), { p: [Math.cos(i) * 12, 0, Math.sin(i) * 12], r: [0, R() * 6.28, 0], c: 0x3c5a22, c2: 0x7a9a3a, sway: 6 });
    g.add(new THREE.Mesh(base.build(), swayMaterial(paintMat({ roughness: 0.9, side: THREE.DoubleSide }), 0.9, 1.0, 'monobase')));
    const light = new THREE.PointLight(0x57e0ff, 3.0, 220, 2); light.position.set(0, 30, 14); g.add(light);
    g.userData.update = (t) => { const p = 0.5 + 0.5 * Math.sin(t * 0.9); inlayMat.opacity = 0.55 + 0.45 * p; light.intensity = 2.0 + 2.0 * p; };
    g.userData.beamPos = new THREE.Vector3(0, H + 10, 0); g.userData.height = H;
    return g;
}

// THE MEMORIAL: a weathered, leaning obelisk on stepped stone, a toppled capstone, lantern posts, and strips of cloth still tied to it, drifting.
export function makeMemorial(heightAt, seed) {
    const R = rng(seed), g = new THREE.Group(), H = 70;
    const geo = loftGeo(10, 4, (a, b) => { const th = (b + 0.125) * Math.PI * 2, y = a * H, k = 1 - a * 0.45; return [Math.sign(Math.cos(th)) * 5.2 * k + (vnoise(y * 0.1, th, seed) - 0.5) * 0.8, y, Math.sign(Math.sin(th)) * 5.2 * k + (vnoise(y * 0.1, th + 4, seed) - 0.5) * 0.8]; }, true);
    const body = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ map: stoneTexture(), color: 0xb7b09c, roughness: 0.85, flatShading: true, side: THREE.DoubleSide }));
    body.castShadow = true; body.receiveShadow = true; body.rotation.z = 0.05; g.add(body);
    const st = new GB(seed + 1);
    for (let i = 0; i < 3; i++) st.box(24 - i * 6, 2, 24 - i * 6, { p: [0, 1 + i * 2, 0], c: 0x8a867a, c2: 0xa8a290, jit: 0.15 });
    st.box(5, 7, 5, { p: [26, 3, 14], r: [0.3, 0.6, 1.2], c: 0x9a9684 }); st.cone(4.2, 7, 4, { p: [30, 4.5, 12], r: [1.4, 0.7, 0.2], c: 0xaaa690 });   // toppled capstone
    for (const [x, z] of [[-17, 6], [16, -12], [-9, -17]]) { st.cyl(0.5, 0.7, 9, 6, { p: [x, 4.5, z], c: 0x4a3a2c }); st.box(1.8, 1.8, 1.8, { p: [x, 9.5, z], c: 0x2a2a2a }); }
    growOver(st, R, 0, 0, 0, 14, 14, 55, null, 0);
    g.add(new THREE.Mesh(st.build(), paintMat({ roughness: 0.92, flatShading: true })));
    const cloth = new GB(seed + 2);
    for (let i = 0; i < 9; i++) { const y = 10 + R() * 40, a = R() * 6.28; cloth.add(ribbon(1.4, 9 + R() * 8, 6, R() * 6), { p: [Math.cos(a) * 4.2, y, Math.sin(a) * 4.2], r: [3.14, a, 0], c: [0xd7d2c4, 0x2fb8b0, 0xd9a24a, 0xb04a5a][i % 4], sway: 5 }); }
    g.add(new THREE.Mesh(cloth.build(), swayMaterial(paintMat({ roughness: 0.9, side: THREE.DoubleSide }), 1.1, 1.3, 'cloth')));
    const plaque = new THREE.Mesh(new THREE.PlaneGeometry(6, 3), new THREE.MeshBasicMaterial({ map: plaqueTex(['MAY THIS STONE', 'STAY UNTOUCHED'], '#e8d8a8') })); plaque.position.set(0, 12, 5.5); g.add(plaque);
    const lamp = new THREE.PointLight(0xffc27a, 1.8, 130, 2); lamp.position.set(-17, 11, 6); g.add(lamp);
    g.userData.update = (t) => { lamp.intensity = 1.5 + 0.35 * Math.sin(t * 1.3) * Math.sin(t * 0.37); };
    g.userData.beamPos = new THREE.Vector3(0, H + 8, 0); g.userData.height = H;
    return g;
}

// THE DISC CASE: a glass dome on a plinth with a gold disc turning slowly, lit from inside.
export function makeDiscCase() {
    const g = new THREE.Group(), st = new GB(77);
    st.cyl(5.2, 6.2, 2.4, 10, { p: [0, 1.2, 0], c: 0x6a6a6e, c2: 0x8a8a90 }); st.cyl(4.2, 4.6, 1.2, 10, { p: [0, 2.9, 0], c: 0x3a3a3e });
    g.add(new THREE.Mesh(st.build(), paintMat({ roughness: 0.6, metalness: 0.4 })));
    const dome = new THREE.Mesh(new THREE.SphereGeometry(4.3, 16, 10, 0, 6.28, 0, Math.PI / 2), new THREE.MeshPhysicalMaterial({ color: 0xbfe8ff, transparent: true, opacity: 0.22, roughness: 0.05, metalness: 0, side: THREE.DoubleSide, depthWrite: false }));
    dome.position.y = 3.5; g.add(dome);
    const disc = new THREE.Mesh(new THREE.CylinderGeometry(2.6, 2.6, 0.18, 24), new THREE.MeshStandardMaterial({ color: 0xffd36a, emissive: 0xffa21a, emissiveIntensity: 0.9, roughness: 0.25, metalness: 0.9 }));
    disc.position.y = 5.2; disc.rotation.x = 0.35; g.add(disc);
    const light = new THREE.PointLight(0xffd27a, 2.2, 70, 2); light.position.y = 6; g.add(light);
    g.userData.update = (t) => { disc.rotation.y = t * 0.6; disc.position.y = 5.2 + Math.sin(t * 1.1) * 0.25; light.intensity = 1.8 + 0.6 * Math.sin(t * 1.9); };
    return g;
}

// A HYDROTHERMAL VENT: black-smoker chimneys with glowing throats, sulphur crust and a rising plume of particles.
export function makeVent(seed) {
    const R = rng(seed), g = new THREE.Group(), gb = new GB(seed + 1), glow = new GB(seed + 2);
    for (let i = 0; i < 4; i++) {
        const a = R() * 6.28, r = i === 0 ? 0 : 6 + R() * 7, x = Math.cos(a) * r, z = Math.sin(a) * r, h = 18 + R() * 30 - r * 0.8, w = 3.5 + R() * 3;
        gb.cyl(w * 0.55, w * 1.5, h, 8, { p: [x, h / 2, z], r: [(R() - 0.5) * 0.18, 0, (R() - 0.5) * 0.18], c: 0x1c1816, c2: 0x3b2a1e, jit: 0.25 });
        gb.cyl(w * 0.62, w * 0.55, 1.4, 8, { p: [x, h + 0.2, z], c: 0x6a4a1e });
        glow.cyl(w * 0.42, w * 0.42, 0.6, 8, { p: [x, h + 0.8, z], c: 0xff8a2a });
        for (let k = 0; k < 6; k++) gb.ico(1.2 + R() * 1.6, 0, { p: [x + (R() - 0.5) * w * 2, R() * h * 0.7, z + (R() - 0.5) * w * 2], c: 0xc9a83a, c2: 0xe6d46a, jit: 0.2 });   // sulphur crust
    }
    g.add(new THREE.Mesh(gb.build(), swayMaterial(paintMat({ roughness: 0.95, flatShading: true }), 0.7, 1.4, 'vent')));
    g.add(new THREE.Mesh(glow.build(), new THREE.MeshBasicMaterial({ vertexColors: true })));
    const light = new THREE.PointLight(0xff7a2a, 3.0, 120, 2); light.position.y = 14; g.add(light);
    const N = 70, pg = new THREE.BufferGeometry(), pp = new Float32Array(N * 3), ph = new Float32Array(N);
    for (let i = 0; i < N; i++) { ph[i] = R(); }
    pg.setAttribute('position', new THREE.BufferAttribute(pp, 3));
    const plume = new THREE.Points(pg, new THREE.PointsMaterial({ color: 0x2a2624, size: 5, transparent: true, opacity: 0.5, depthWrite: false, sizeAttenuation: true }));
    plume.frustumCulled = false; g.add(plume);
    const top = 30;
    g.userData.update = (t) => {
        for (let i = 0; i < N; i++) { const k = (ph[i] + t * 0.12) % 1; pp[i * 3] = Math.sin(i * 7.1 + k * 4) * (2 + k * 9); pp[i * 3 + 1] = top + k * 70; pp[i * 3 + 2] = Math.cos(i * 3.7 + k * 4) * (2 + k * 9); }
        pg.getAttribute('position').needsUpdate = true; light.intensity = 2.5 + 0.8 * Math.sin(t * 3.1) * Math.sin(t * 1.3);
    };
    return g;
}
