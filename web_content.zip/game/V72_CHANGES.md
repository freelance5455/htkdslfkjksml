# v72 - step 0: text fixes
Not run in a browser; `game.js` passes a syntax check and all artifact JSON parses.

## What changed
- **Obelisk**: "Three centuries of strangers" -> "Two centuries" (carvings run 2563-2781, 218 years).
- **Union marker**: "centuries-old English translation" -> "millennia-old" (it dates from about 2560; the present is 7644).
- **Disc text now matches the story.** It was described as a "witness statement" and the pickup line said its filer was "on your side of the timeline". Both contradicted the story and lore (a lighthearted recording from 2500: train jokes, Little Guy and Archerie). Description and pickup line rewritten. Correction (v72b): the 2781 date is only the Academic Society's ownership stamp. The recording itself is from March 2500, with Archerie and Little Guy, both dead by May 2500, so the description now says the recording is much older than the case. If the witness-statement idea was deliberate, revert `artifacts/disc.json`.
- **Disc audio left blank on purpose** (to be recorded with the show's voice actors; expected at `audio/aurelian_disc_recording.mp3`). The Play button no longer gets stuck on "playing" when the file is missing.
- Not changed: the "centuries of sea growth" comment in the code (not player-facing).

## Next: step 1, AI abilities
