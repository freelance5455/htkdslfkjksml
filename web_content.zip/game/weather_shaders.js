// =====================================================================================
// weather_shaders.js - every GLSL string used by the weather overhaul (game.js imports this).
//
// Kept in its own file so the shaders can be compiled and rendered in isolation (see the
// verification notes in the project README) without booting the whole game.
//
// Conventions shared by every shader here:
//   * They are used with THREE.ShaderMaterial, so three.js supplies: modelMatrix, viewMatrix,
//     projectionMatrix, cameraPosition, and the logarithmic-depth uniform/defines. The game
//     renders with logarithmicDepthBuffer:true, so every shader that depth-tests against the
//     terrain must write a matching log depth value (LOGDEPTH_* snippets below).
//   * The weather map texture (RGBA8, world-space, re-centred on the player) carries:
//         R = cloud coverage 0..1     G = precipitation 0..1
//         B = convective storm 0..1   A = dust / sandstorm 0..1
// =====================================================================================

export const LOGDEPTH_V_PARS = `
#ifdef USE_LOGDEPTHBUF
    varying float vFragDepth;
#endif`;
export const LOGDEPTH_V = `
#ifdef USE_LOGDEPTHBUF
    vFragDepth = 1.0 + gl_Position.w;
#endif`;
export const LOGDEPTH_F_PARS = `
#ifdef USE_LOGDEPTHBUF
    uniform float logDepthBufFC;
    varying float vFragDepth;
#endif`;
export const LOGDEPTH_F = `
#ifdef USE_LOGDEPTHBUF
    gl_FragDepth = log2(vFragDepth) * logDepthBufFC * 0.5;
#endif`;

// Noise shared by the cloud shaders AND the terrain's cloud-shadow code, so a shadow on the
// ground lines up with the cloud that casts it. (Same hash family the rest of the game uses.)
export const CS_NOISE = `
float cs_hash(vec3 p) { p = fract(p * 0.3183099 + 0.1); p *= 17.0; return fract(p.x * p.y * p.z * (p.x + p.y + p.z)); }
float cs_noise(vec3 x) {
    vec3 i = floor(x); vec3 f = fract(x); f = f * f * (3.0 - 2.0 * f);
    return mix(mix(mix(cs_hash(i), cs_hash(i + vec3(1.0, 0.0, 0.0)), f.x),
                   mix(cs_hash(i + vec3(0.0, 1.0, 0.0)), cs_hash(i + vec3(1.0, 1.0, 0.0)), f.x), f.y),
               mix(mix(cs_hash(i + vec3(0.0, 0.0, 1.0)), cs_hash(i + vec3(1.0, 0.0, 1.0)), f.x),
                   mix(cs_hash(i + vec3(0.0, 1.0, 1.0)), cs_hash(i + vec3(1.0, 1.0, 1.0)), f.x), f.y), f.z);
}
float cs_fbm3(vec3 p) {
    float v = 0.5 * cs_noise(p);
    p = p * 2.03 + vec3(1.7, 9.2, 3.1);
    v += 0.25 * cs_noise(p);
    p = p * 2.03 + vec3(8.3, 2.8, 5.5);
    v += 0.125 * cs_noise(p);
    return v / 0.875;
}
`;

export const WX_MAP_FETCH = `
uniform sampler2D uWxMap; uniform vec2 uWxCenter; uniform float uWxSize;
vec4 wxFetch(vec2 xz) {
    vec2 uv = (xz - uWxCenter) / uWxSize + 0.5;
    return texture2D(uWxMap, clamp(uv, vec2(0.002), vec2(0.998)));
}
`;

// One screen-covering proxy sphere centred on the camera: every pixel casts its own view ray in
// the fragment shader, so clouds exist in every direction (including overhead / from inside the
// layer), and the fragment writes its own depth so terrain, mountains and the gas giant occlude
// (and are occluded by) clouds correctly.
export const CLOUD_VERT = `
varying vec3 vWorldPos;
void main() {
    vec4 wp = modelMatrix * vec4(position, 1.0);
    vWorldPos = wp.xyz;
    gl_Position = projectionMatrix * viewMatrix * wp;
}
`;

// ---------------------------------------------------------------------------------------
// Volumetric cloud deck (cumulus -> stratus -> nimbostratus -> cumulonimbus, all one shader).
// What kind of cloud forms where is decided purely by the weather map, so a fair-weather sky
// grows puffy cumulus, a warm front thickens into a dark rain-bearing ceiling with grey rain
// curtains hanging under it, and a storm cell towers up into an anvil-topped cumulonimbus.
// A dust channel adds tan sandstorm walls hugging the ground.
// ---------------------------------------------------------------------------------------
export function makeVolumeFrag(steps) {
    return `
${LOGDEPTH_F_PARS}
${CS_NOISE}
${WX_MAP_FETCH}
#define STEPS ${steps | 0}
uniform vec3 uCam; uniform mat4 uViewProj;
uniform vec3 uOff; uniform float uTime;
uniform float uBaseY; uniform float uSlabBot; uniform float uSlabTop;
uniform vec3 uLDir; uniform vec3 uSunCol; uniform float uLLevel;
uniform vec3 uAmbTop; uniform vec3 uAmbBot; uniform float uAmbLevel;
uniform vec3 uFogCol; uniform float uHaze; uniform float uMaxDist;
uniform float uLightning; uniform vec3 uLightPos;
uniform float uSigma; uniform float uOpacity;
varying vec3 vWorldPos;

float cloudBaseOf(vec4 w) { return uBaseY - 380.0 * w.g - 120.0 * w.b; }
float cloudThickOf(vec4 w) {
    float strat = smoothstep(0.66, 0.95, w.r) * (1.0 - w.b);
    return mix(1500.0, 620.0, strat) + w.b * 5600.0 + w.g * 500.0;
}

float cloudDensity(vec3 p, vec4 w, float detail) {
    float cov = w.r;
    float st = w.b;
    float strat = smoothstep(0.66, 0.95, cov) * (1.0 - st);
    float base = cloudBaseOf(w);
    float thick = cloudThickOf(w);
    float h = (p.y - base) / thick;
    if (h < -0.02 || h > 1.02) return 0.0;
    float prof = smoothstep(0.0, 0.10 + 0.10 * strat, h)
               * (1.0 - smoothstep(0.50 + 0.32 * strat + 0.36 * st, 1.0, h));
    vec3 q = (p + uOff) / vec3(2500.0, 1700.0, 2500.0);
    q.xz /= mix(1.0, 1.9, strat);
    float n = cs_fbm3(q);
    n = clamp((n - 0.5) * 1.75 + 0.5, 0.0, 1.0);
    // threshold falls as coverage rises; storm cells spread out into an anvil near their top
    float thr = 0.80 - 0.60 * cov - st * 0.12 - st * 0.30 * smoothstep(0.55, 0.95, h);
    float d = smoothstep(thr, thr + 0.17, n);
    d = mix(d, d * smoothstep(0.15, 0.80, n), strat);
    d *= prof;
    if (detail > 0.5 && d > 0.002 && d < 0.95) {
        float e = cs_noise(q * vec3(3.7, 4.3, 3.7) + vec3(0.0, uTime * 0.012, 0.0));
        d = clamp(d - (1.0 - e) * 0.32 * (1.0 - d * 0.6), 0.0, 1.0);
    }
    return d;
}

// Grey rain curtains hanging beneath precipitating cloud bases (the distant "rain shaft" look).
float curtainDensity(vec3 p, vec4 w, float base) {
    float pr = w.g;
    if (pr < 0.04 || p.y > base + 60.0) return 0.0;
    float vert = smoothstep(base - 2100.0, base - 150.0, p.y) * (1.0 - smoothstep(base - 150.0, base + 60.0, p.y));
    float streak = smoothstep(0.30, 0.78, cs_noise(vec3((p.x + uOff.x) * 0.0032, p.y * 0.00045, (p.z + uOff.z) * 0.0032)));
    return pr * vert * streak * 0.6;
}

// Sandstorm wall: dense tan dust hugging the ground with a ragged top edge.
float dustDensity(vec3 p, vec4 w) {
    float du = w.a;
    if (du < 0.04) return 0.0;
    float rag = 0.7 + 0.6 * cs_noise(vec3((p.x + uOff.x) * 0.0007, 0.0, (p.z + uOff.z) * 0.0007));
    float hgt = 1.0 - smoothstep(200.0, 2300.0 * rag, p.y);
    float n = cs_fbm3(vec3(p.x + uOff.x, p.y * 1.6, p.z + uOff.z) / 900.0);
    return du * hgt * smoothstep(0.25, 0.70, n) * 1.5;
}

void main() {
    vec3 rd = normalize(vWorldPos - uCam);
    float sy = rd.y;
    if (abs(sy) < 1e-3) sy = sy < 0.0 ? -1e-3 : 1e-3;
    float t0 = (uSlabBot - uCam.y) / sy;
    float t1 = (uSlabTop - uCam.y) / sy;
    float tN = max(min(t0, t1), 0.0);
    float tF = max(t0, t1);
    if (tF <= tN || tN > uMaxDist) discard;
    float dt = min((tF - tN) / float(STEPS), 650.0);
    float jit = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));

    float sunCos = dot(rd, uLDir);
    float fwd = pow(clamp(sunCos * 0.5 + 0.5, 0.0, 1.0), 6.0);
    float phase = 0.65 + 2.4 * fwd;

    vec3 acc = vec3(0.0);
    float accA = 0.0;
    float firstHit = -1.0;

    for (int i = 0; i < STEPS; i++) {
        float t = tN + (float(i) + jit) * dt;
        vec3 p = uCam + rd * t;
        vec4 w = wxFetch(p.xz);
        float base = cloudBaseOf(w);
        float detail = t < 9000.0 ? 1.0 : 0.0;
        float d = cloudDensity(p, w, detail);
        float dc = curtainDensity(p, w, base);
        float dd = dustDensity(p, w);
        float dtot = d + dc + dd;
        if (dtot > 0.004) {
            float thick = cloudThickOf(w);
            float hh = clamp((p.y - base) / thick, 0.0, 1.0);
            float dark = mix(1.0, 0.30, clamp(w.b * 0.85 + w.g * 0.75, 0.0, 1.0));
            vec3 cloudCol = vec3(0.0);
            if (d > 0.01) {
                float od = cloudDensity(p + uLDir * 220.0, w, 0.0)
                         + cloudDensity(p + uLDir * 560.0, w, 0.0)
                         + cloudDensity(p + uLDir * 1100.0, w, 0.0);
                float le = exp(-od * 1.25);
                le = max(le, 0.16 * exp(-od * 0.3));
                vec3 amb = mix(uAmbBot, uAmbTop, 0.25 + 0.75 * hh) * uAmbLevel * (0.55 + 0.45 * smoothstep(0.0, 0.5, hh));
                vec3 direct = uSunCol * (uLLevel * le * phase);
                cloudCol = (amb + direct) * dark;
                float lf = uLightning * exp(-length(p.xz - uLightPos.xz) / 4500.0);
                cloudCol += vec3(0.62, 0.74, 1.0) * lf * (0.25 + 0.75 * le) * (0.4 + 0.6 * d);
            }
            vec3 curtCol = mix(vec3(0.40, 0.44, 0.50), uAmbTop, 0.25) * (0.25 + 0.75 * uAmbLevel) * 0.85;
            vec3 dustCol = vec3(0.70, 0.54, 0.34) * (0.30 + 0.70 * uAmbLevel) * (0.45 + 0.55 * uLLevel);
            vec3 c = (cloudCol * d + curtCol * dc + dustCol * dd) / dtot;
            float a = 1.0 - exp(-dtot * dt * uSigma);
            acc += (1.0 - accA) * c * a;
            accA += (1.0 - accA) * a;
            if (firstHit < 0.0 && accA > 0.08) firstHit = t;
            if (accA > 0.985) break;
        }
    }
    if (accA < 0.004) discard;

    vec3 col = acc / accA;
    float tHit = firstHit < 0.0 ? 0.5 * (tN + tN + dt * float(STEPS)) : firstHit;
    float fogA = 1.0 - exp(-pow(tHit / uHaze, 1.35));
    col = mix(col, uFogCol, clamp(fogA, 0.0, 0.95));
    float fade = 1.0 - smoothstep(0.65 * uMaxDist, uMaxDist, tN);
    float alpha = clamp(accA * uOpacity * fade, 0.0, 1.0);

    vec4 clip = uViewProj * vec4(uCam + rd * tHit, 1.0);
    #ifdef USE_LOGDEPTHBUF
        gl_FragDepth = log2(1.0 + clip.w) * logDepthBufFC * 0.5;
    #else
        gl_FragDepth = clamp(clip.z / clip.w * 0.5 + 0.5, 0.0, 1.0);
    #endif
    gl_FragColor = vec4(col, alpha);
}
`;
}

// ---------------------------------------------------------------------------------------
// Thin 2D cloud sheets. kind 'alto' = altocumulus / altostratus veil (~5 km),
// kind 'cirrus' = wind-combed ice filaments + cirrostratus that thickens AHEAD of an
// approaching front (so the sky genuinely tells you weather is coming).
// ---------------------------------------------------------------------------------------
export function makeLayerFrag(kind) {
    const isCirrus = kind === 'cirrus';
    return `
${LOGDEPTH_F_PARS}
${CS_NOISE}
${WX_MAP_FETCH}
uniform vec3 uCam; uniform mat4 uViewProj;
uniform vec3 uOff; uniform float uTime; uniform float uAlt; uniform vec2 uWDir; uniform float uWindMul;
uniform vec3 uLDir; uniform vec3 uSunCol; uniform float uLLevel;
uniform vec3 uAmbTop; uniform float uAmbLevel;
uniform vec3 uFogCol; uniform float uHaze; uniform float uMaxDist;
varying vec3 vWorldPos;

void main() {
    vec3 rd = normalize(vWorldPos - uCam);
    if (rd.y < 0.012 || uCam.y > uAlt - 50.0) discard;
    float t = (uAlt - uCam.y) / rd.y;
    if (t > uMaxDist) discard;
    vec3 p = uCam + rd * t;
    vec2 pxz = p.xz + uOff.xz * uWindMul;
    vec2 wd = normalize(uWDir);
    float dens;
    float tint = 0.0;
    ${isCirrus ? `
    vec2 a = vec2(dot(pxz, wd), dot(pxz, vec2(-wd.y, wd.x)));
    vec3 q = vec3(a.x / 26000.0, a.y / 4200.0, uTime * 0.004);
    q.y += (cs_noise(q * vec3(0.8, 1.5, 1.0) + 3.3) - 0.5) * 1.1;
    float n = cs_fbm3(q);
    float fib = cs_noise(vec3(a.x / 9000.0, a.y / 650.0, 1.7));
    n = clamp((n - 0.5) * 1.6 + 0.5 + (fib - 0.5) * 0.35, 0.0, 1.0);
    float front = max(wxFetch(p.xz - wd * 26000.0).g * 0.9, wxFetch(p.xz - wd * 16000.0).b);
    float cover = clamp(0.10 + 0.55 * front + 0.18 * cs_noise(vec3(pxz * 0.00002, 9.1)), 0.0, 1.0);
    float thr = 0.78 - 0.55 * cover;
    float d = smoothstep(thr, thr + 0.22, n);
    float veil = smoothstep(0.35, 0.9, front) * 0.55;
    dens = max(d * 0.8, veil * (0.6 + 0.4 * n)) * 0.72;
    ` : `
    float n = cs_fbm3(vec3(pxz.x / 1500.0, uTime * 0.006, pxz.y / 1100.0));
    n = clamp((n - 0.5) * 1.7 + 0.5, 0.0, 1.0);
    float c = wxFetch(p.xz - wd * 9000.0).r;
    float cover = clamp(0.12 + 0.88 * c * c + 0.2 * (cs_noise(vec3(pxz.x * 0.00003, 4.0, pxz.y * 0.00003)) - 0.5), 0.0, 1.0);
    float thr = 0.80 - 0.60 * cover;
    float d = smoothstep(thr, thr + 0.18, n);
    float veil = smoothstep(0.75, 0.99, c) * 0.85;
    dens = max(d * 0.9, veil * (0.55 + 0.45 * n)) * 0.78;
    tint = veil;
    `}
    if (dens < 0.004) discard;

    float fwd = pow(max(dot(rd, uLDir), 0.0), 6.0);
    vec3 col = uAmbTop * uAmbLevel * ${isCirrus ? '0.55' : '0.62'} + uSunCol * uLLevel * (${isCirrus ? '0.75' : '0.55'} + 0.6 * fwd);
    col = mix(col, vec3(dot(col, vec3(0.333))) * vec3(0.92, 0.95, 1.0), tint * 0.55);
    float fogA = 1.0 - exp(-pow(t / (uHaze * 1.6), 1.35));
    col = mix(col, uFogCol, clamp(fogA, 0.0, 0.9));
    float fade = 1.0 - smoothstep(0.6 * uMaxDist, uMaxDist, t);

    vec4 clip = uViewProj * vec4(p, 1.0);
    #ifdef USE_LOGDEPTHBUF
        gl_FragDepth = log2(1.0 + clip.w) * logDepthBufFC * 0.5;
    #else
        gl_FragDepth = clamp(clip.z / clip.w * 0.5 + 0.5, 0.0, 1.0);
    #endif
    gl_FragColor = vec4(col, clamp(dens * fade, 0.0, 1.0));
}
`;
}

// ---------------------------------------------------------------------------------------
// Rain: camera-wrapped box of camera-facing streak quads, fully GPU animated. Drop positions
// come from a wrapped hash of static per-drop seeds + accumulated wind/fall offsets (uOff) so
// nothing ever teleports when wind speed changes or the player moves.
// ---------------------------------------------------------------------------------------
export const RAIN_VERT = `
attribute vec4 aSeed;
attribute vec2 aCorner;
uniform vec3 uCam; uniform vec3 uOff;
uniform float uBox; uniform float uHeight; uniform float uLen; uniform float uIntensity;
uniform float uPx; uniform float uFall; uniform vec2 uWindV; uniform vec3 uPlane;
uniform float uNear; uniform float uFar; uniform float uAlphaMul;
varying float vA; varying float vSide;
${LOGDEPTH_V_PARS}
void main() {
    if (aSeed.w > uIntensity) { gl_Position = vec4(2.0, 2.0, 2.0, 1.0); vA = 0.0; vSide = 0.0;
        #ifdef USE_LOGDEPTHBUF
            vFragDepth = 1.0;
        #endif
        return; }
    vec2 rel = mod(aSeed.xz * uBox + uOff.xz - uCam.xz, uBox) - 0.5 * uBox;
    float hy = mod(aSeed.y * uHeight - uOff.y, uHeight);
    vec3 head = vec3(uCam.x + rel.x, uCam.y - 0.30 * uHeight + hy, uCam.z + rel.y);
    vec3 vel = vec3(uWindV.x, -uFall, uWindV.y);
    vec3 tail = head - vel * uLen;
    vec3 pos = mix(head, tail, aCorner.x);
    vec3 axis = normalize(head - tail);
    vec3 toCam = uCam - pos;
    float dist = length(toCam);
    vec3 side = cross(axis, toCam / max(dist, 0.001));
    float sl = length(side);
    side = sl > 1e-4 ? side / sl : vec3(1.0, 0.0, 0.0);
    pos += side * aCorner.y * dist * uPx * 0.5;
    float gY = uPlane.z + uPlane.x * (head.x - uCam.x) + uPlane.y * (head.z - uCam.z);
    float edge = smoothstep(0.0, 5.0, hy) * (1.0 - smoothstep(uHeight - 8.0, uHeight, hy));
    vA = uAlphaMul * edge
       * smoothstep(0.0, 0.7, head.y - gY)
       * smoothstep(uNear, uNear * 3.0, dist)
       * (1.0 - smoothstep(uFar * 0.55, uFar, dist))
       * mix(1.0, 0.25, aCorner.x);
    vSide = aCorner.y;
    gl_Position = projectionMatrix * viewMatrix * vec4(pos, 1.0);
    ${LOGDEPTH_V}
}
`;
export const RAIN_FRAG = `
uniform vec3 uColor;
varying float vA; varying float vSide;
${LOGDEPTH_F_PARS}
void main() {
    ${LOGDEPTH_F}
    float e = 1.0 - smoothstep(0.35, 1.0, abs(vSide));
    float a = vA * e;
    if (a < 0.004) discard;
    gl_FragColor = vec4(uColor, a);
}
`;

// ---------------------------------------------------------------------------------------
// Generic soft point sprites riding the same wrapped-box scheme: used for snowflakes, wind-blown
// dust / leaves / ash, sun-lit pollen motes, and night fireflies. Behaviour is driven entirely by
// uniforms (size, swirl, pulse, colour) so one shader serves all of them.
// ---------------------------------------------------------------------------------------
export const POINTS_VERT = `
attribute vec4 aSeed;
uniform vec3 uCam; uniform vec3 uOff;
uniform float uBox; uniform float uHeight; uniform float uYOff; uniform float uSize; uniform float uScale;
uniform float uTime; uniform float uIntensity; uniform float uSwirl; uniform float uPulse;
uniform float uNear; uniform float uFar; uniform float uAlphaMul; uniform vec3 uPlane; uniform float uGroundFade;
varying float vA;
${LOGDEPTH_V_PARS}
void main() {
    if (aSeed.w > uIntensity) { gl_Position = vec4(2.0, 2.0, 2.0, 1.0); vA = 0.0; gl_PointSize = 1.0;
        #ifdef USE_LOGDEPTHBUF
            vFragDepth = 1.0;
        #endif
        return; }
    vec2 rel = mod(aSeed.xz * uBox + uOff.xz - uCam.xz, uBox) - 0.5 * uBox;
    float hy = mod(aSeed.y * uHeight - uOff.y, uHeight);
    float ph = aSeed.x * 43.0 + aSeed.z * 17.0;
    vec3 sw = uSwirl * vec3(sin(uTime * 1.3 + ph) + 0.5 * sin(uTime * 2.9 + ph * 2.0),
                            0.15 * sin(uTime * 2.1 + ph),
                            cos(uTime * 1.1 + ph * 1.3) + 0.5 * cos(uTime * 3.3 + ph));
    vec3 pos = vec3(uCam.x + rel.x, uCam.y + uYOff + hy, uCam.z + rel.y) + sw;
    vec4 mv = viewMatrix * vec4(pos, 1.0);
    float dist = -mv.z;
    gl_Position = projectionMatrix * mv;
    float sz = uSize * (0.55 + 0.9 * fract(aSeed.w * 7.31));
    gl_PointSize = clamp(sz * uScale / max(dist, 0.1), 1.0, 26.0);
    float gY = uPlane.z + uPlane.x * (pos.x - uCam.x) + uPlane.y * (pos.z - uCam.z);
    float edge = smoothstep(0.0, 3.0, hy) * (1.0 - smoothstep(uHeight - 4.0, uHeight, hy));
    float pulse = mix(1.0, 0.5 + 0.5 * sin(uTime * (1.0 + aSeed.z * 2.0) + aSeed.w * 30.0), uPulse);
    vA = uAlphaMul * edge * pulse
       * mix(1.0, smoothstep(0.0, 0.6, pos.y - gY), uGroundFade)
       * smoothstep(uNear, uNear * 4.0, dist)
       * (1.0 - smoothstep(uFar * 0.55, uFar, dist));
    ${LOGDEPTH_V}
}
`;
export const POINTS_FRAG = `
uniform vec3 uColor;
varying float vA;
${LOGDEPTH_F_PARS}
void main() {
    ${LOGDEPTH_F}
    float r = length(gl_PointCoord - 0.5) * 2.0;
    float a = smoothstep(1.0, 0.2, r) * vA;
    if (a < 0.004) discard;
    gl_FragColor = vec4(uColor, a);
}
`;

// Rain-drop impact rings on the ground plane.
export const SPLASH_VERT = `
attribute vec4 aSeed;
uniform vec3 uCam; uniform vec3 uPlane;
uniform float uBox; uniform float uTime; uniform float uRate; uniform float uScale; uniform float uIntensity; uniform float uFar;
varying float vA; varying float vLife;
${LOGDEPTH_V_PARS}
float sp_h(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
void main() {
    if (aSeed.w > uIntensity) { gl_Position = vec4(2.0, 2.0, 2.0, 1.0); vA = 0.0; vLife = 0.0; gl_PointSize = 1.0;
        #ifdef USE_LOGDEPTHBUF
            vFragDepth = 1.0;
        #endif
        return; }
    float tt = uTime * uRate + aSeed.z * 9.0 + aSeed.x * 3.0;
    float cyc = floor(tt);
    float life = tt - cyc;
    vec2 rnd = vec2(sp_h(aSeed.xy + cyc * 0.37), sp_h(aSeed.yx + cyc * 1.91 + 5.0));
    vec2 anchor = floor(uCam.xz / uBox + 0.5) * uBox - 0.5 * uBox;
    vec2 xz = anchor + rnd * uBox;
    float y = uPlane.z + uPlane.x * (xz.x - uCam.x) + uPlane.y * (xz.y - uCam.z) + 0.04;
    vec4 mv = viewMatrix * vec4(xz.x, y, xz.y, 1.0);
    float dist = -mv.z;
    gl_Position = projectionMatrix * mv;
    float radius = 0.06 + 0.30 * life;
    gl_PointSize = clamp(radius * 2.0 * uScale / max(dist, 0.1), 2.0, 40.0);
    vA = pow(1.0 - life, 1.6) * 0.75 * (1.0 - smoothstep(uFar * 0.4, uFar, dist)) * smoothstep(0.5, 2.0, dist);
    vLife = life;
    ${LOGDEPTH_V}
}
`;
export const SPLASH_FRAG = `
uniform vec3 uColor;
varying float vA; varying float vLife;
${LOGDEPTH_F_PARS}
void main() {
    ${LOGDEPTH_F}
    float r = length(gl_PointCoord - 0.5) * 2.0;
    float ring = smoothstep(0.45, 0.7, r) * (1.0 - smoothstep(0.82, 1.0, r));
    float a = ring * vA;
    if (a < 0.004) discard;
    gl_FragColor = vec4(uColor, a);
}
`;

// ---------------------------------------------------------------------------------------
// Terrain hooks: cloud shadows, snow accumulation and puddle wetness (injected into the existing
// terrain material via onBeforeCompile). Uniforms are shared objects owned by game.js.
// ---------------------------------------------------------------------------------------
export const TERRAIN_FRAG_PARS = `
${CS_NOISE}
${WX_MAP_FETCH}
uniform vec3 uCOff; uniform vec3 uLDirW; uniform float uCShade; uniform float uCBase; uniform float uSnow;
float wxCloudShade(vec3 wp) {
    vec3 sd = uLDirW;
    if (uCShade < 0.01 || sd.y < 0.12) return 1.0;
    float tt = (uCBase + 600.0 - wp.y) / sd.y;
    vec3 cp = wp + sd * max(tt, 0.0);
    vec4 w = wxFetch(cp.xz);
    vec3 q = (cp + uCOff) / vec3(2500.0, 1700.0, 2500.0);
    float n = clamp((cs_fbm3(q) - 0.5) * 1.75 + 0.5, 0.0, 1.0);
    float thr = 0.80 - 0.60 * w.r;
    float d = smoothstep(thr, thr + 0.17, n);
    return 1.0 - 0.38 * d * uCShade;
}
`;
// Replaces the terrain's existing wetness line: adds distance falloff, then cloud shade + snow.
export const TERRAIN_WET_SNOW_HEAD = `
    float wetL = wet * (1.0 - smoothstep(1500.0, 10000.0, length(vViewPosition)));
    diffuseColor.rgb *= 1.0 - 0.32 * wetL; roughnessFactor = mix(roughnessFactor, 0.16, wetL * 0.85);
    diffuseColor.rgb *= wxCloudShade(vWorldPos);
`;
export const TERRAIN_SNOW_TAIL = `
    { float snowL = uSnow * (1.0 - smoothstep(1500.0, 12000.0, length(vViewPosition)));
      if (snowL > 0.001) {
        vec3 nw = inverseTransformDirection(normal, viewMatrix);
        float upF = smoothstep(0.30, 0.80, nw.y + (noise(vWorldPos * 0.35) - 0.5) * 0.35);
        float sn = snowL * upF;
        diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.93, 0.95, 0.98), sn * 0.92);
        roughnessFactor = mix(roughnessFactor, 0.85, sn);
      } }
`;

// ---------------------------------------------------------------------------------------
// Exponential HEIGHT fog, patched into three's global fog chunks so every fogged material
// (terrain, water, trees, grass, rocks...) gets valley mist, rain haze and dust pall for free.
// Parameters arrive through one shared uniform vec4: x = ground density (per metre),
// y = falloff per metre of altitude, z = altitude where density equals x.
// ---------------------------------------------------------------------------------------
export function patchFogChunks(THREE) {
    const C = THREE.ShaderChunk;
    const a = C.fog_pars_vertex, b = C.fog_vertex, c = C.fog_pars_fragment, d = C.fog_fragment;
    if (!a || !b || !c || !d) return false;
    if (a.includes('vFogWY')) return true; // already patched
    const nb = b.replace('vFogDepth = - mvPosition.z;',
        'vFogDepth = - mvPosition.z;\n\tvFogWY = cameraPosition.y + dot(vec3(viewMatrix[0][1], viewMatrix[1][1], viewMatrix[2][1]), mvPosition.xyz);');
    const nd = d.replace('gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );',
        `{
        float hf_b = uHFog.y;
        float hf_dy = vFogWY - cameraPosition.y;
        float hf_ey = clamp(hf_b * hf_dy, -4.0, 30.0);
        float hf_cam = exp(clamp(-hf_b * (cameraPosition.y - uHFog.z), -6.0, 6.0));
        float hf_int = abs(hf_ey) > 0.001 ? (1.0 - exp(-hf_ey)) / hf_ey : 1.0;
        float hf_f = 1.0 - exp(-uHFog.x * vFogDepth * hf_cam * hf_int);
        fogFactor = 1.0 - (1.0 - fogFactor) * (1.0 - clamp(hf_f, 0.0, 0.97));
    }
    gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );`);
    if (nb === b || nd === d) return false;
    C.fog_pars_vertex = a.replace('varying float vFogDepth;', 'varying float vFogDepth;\n\tvarying float vFogWY;');
    C.fog_vertex = nb;
    C.fog_pars_fragment = c.replace('varying float vFogDepth;', 'varying float vFogDepth;\n\tvarying float vFogWY;\n\tuniform vec4 uHFog;');
    C.fog_fragment = nd;
    return true;
}
