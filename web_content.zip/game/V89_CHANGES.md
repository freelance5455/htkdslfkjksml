# v89 - your new freefall cinematic merged in
(Numbered v89 because your player file's own notes already use v83-v88 for the cinematic.)
`freefall_cinematic.js` is now the module from your NewTerra-Freefall-Player.html (honest altitude, volumetric cloud deck, zonal shear bands, lightning forks and blooms, lit fog inside the cloud, voice with moods, and the varied lines), with the earlier pause / leave / no-skip changes re-applied on top. The standalone player's own start screen is not part of the game build.
- `game.js` now gives the cinematic a mood-capable voice (`ffSpeakLine(text, mood)` + `ffCancelVoice`, the same code as in your player), instead of the game's normal AI voice, so the moods work in-game.
- Re-ran `tests/ff_cine_pause_test.py`: double-tap pauses, Keep watching resumes, Space does not skip, Leave fires.
