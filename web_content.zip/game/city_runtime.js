// =====================================================================================
// city_runtime.js - the main-thread half of the valley city-states (three.js + DOM). game.js creates ONE CityWorld.
//   * Requests each city from a chunk worker (instanced data), builds a few InstancedMeshes per city and KEEPS them (they do not depend
//     on terrain chunks, so chunk rebuilds / LOD changes never touch them). One group transform per chart; a cube-face crossing only
//     re-computes that transform.
//   * LOD by distance: FULL (all pieces, windows, shadows) < 4200 units, MID (walls + roofs only) < 13000, SKY (emissive tower
//     silhouettes) < 60000, plus a glow beacon (sprite + light shaft) that is always visible so a valley can be spotted from a ridge.
//   * Drones (blue / green) are simulated by city_sim.js ONLY while the player is within ~1500 units, capped; chat bubbles are DOM.
//   * Dialogue + barter UI (DOM), roads between land-linked cities (ribbon tiles built near the player) with cargo drones.
// NOT browser-tested in the authoring environment (no WebGL / three.js available there): see V45_CHANGES.md.
// =====================================================================================
import { placeSite, h32 } from './valley_sites.js';
import { geoToChart, chartToGeo, PLANET_R } from './planet_core.js';
import { planRoads } from './city_roads.js';
import { CitySim } from './city_sim.js';
import { CityCollider } from './city_collide.js';
import { TAPERS, FLARES } from './city_core.js';
import { makeResidents, cityName, topics, makeEconomy, quote, execute, relax, RESOURCES, RES_NAME, FACTION, FACTION_NAME, JOBS } from './city_life.js';

const BUILD_DIST = 40000, FULL_D = 4200, MID_D = 13000, FAR_D = 34000, SKY_D = 70000, SIM_ON = 1700, SIM_OFF = 2700, MAX_DRONES_TOTAL = 140, DRONES_PER_CITY = 64;
const hexToLin = (h) => { const s2l = (c) => c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4); return [s2l(((h >> 16) & 255) / 255), s2l(((h >> 8) & 255) / 255), s2l((h & 255) / 255)]; };

export class CityWorld {
    constructor(ctx) {
        this.ctx = ctx; this.THREE = ctx.THREE; this.recs = new Map(); this.face = -1; this.root = new this.THREE.Group(); this.root.name = 'cityWorld'; this.root.userData.noHandover = true; ctx.scene.add(this.root);   // v51: game.js's face handover must NOT move/rotate this root (children are placed in chart coords every time the face changes)
        
        this.sites = ctx.sites; this.valleys = ctx.valleys; this.econState = {}; this.geo = null; this.t = 0; this.talking = null; this.uiOpen = false;
        this.roads = []; this.roadsRequested = false; this.roadScan = 0; this.cargo = []; this.bubbleEls = []; this.hover = null;
        this._buildGeometry(); this._buildDroneMeshes(); this._injectUI();
    }
    // ------------------------------------------------------------------ geometry library (shared by every city)
    _buildGeometry() {
        const T = this.THREE, G = {};
        G.box = new T.BoxGeometry(1, 1, 1).translate(0, 0.5, 0);
        G.cyl = new T.CylinderGeometry(0.5, 0.5, 1, 12).translate(0, 0.5, 0);
        G.cone = new T.ConeGeometry(0.5, 1, 10).translate(0, 0.5, 0);
        G.dome = new T.SphereGeometry(0.5, 14, 8, 0, Math.PI * 2, 0, Math.PI / 2).scale(1, 2, 1);
        { // gable prism: ridge along x, base 1x1, height 1
            const p = [[-.5, 0, -.5], [.5, 0, -.5], [.5, 0, .5], [-.5, 0, .5], [-.5, 1, 0], [.5, 1, 0]], tri = [[0, 4, 1], [1, 4, 5], [3, 2, 5], [3, 5, 4], [0, 3, 4], [1, 5, 2], [0, 1, 2], [0, 2, 3]], v = [];
            for (const t of tri) for (const i of t) v.push(...p[i]);
            const g = new T.BufferGeometry(); g.setAttribute('position', new T.Float32BufferAttribute(v, 3)); g.computeVertexNormals(); G.gable = g;
        }
        { // arch bridge: 1 long (x) x 1 high (y) x 1 wide (z), arched opening underneath
            const s = new T.Shape(); s.moveTo(-.5, 0); s.lineTo(-.36, 0); s.lineTo(-.36, .35); s.quadraticCurveTo(-.36, .74, 0, .74); s.quadraticCurveTo(.36, .74, .36, .35); s.lineTo(.36, 0); s.lineTo(.5, 0); s.lineTo(.5, 1); s.lineTo(-.5, 1); s.lineTo(-.5, 0);
            G.arch = new T.ExtrudeGeometry(s, { depth: 1, bevelEnabled: false, curveSegments: 8 }).translate(0, 0, -0.5);
        }
        // v56: the Rogues' Citadel's smooth shells (high segment counts: they are big and sleek) + tapered / flared frusta
        G.orgCyl = new T.CylinderGeometry(0.5, 0.5, 1, 40).translate(0, 0.5, 0);
        G.orgCone = new T.ConeGeometry(0.5, 1, 32).translate(0, 0.5, 0);
        G.orgDome = new T.SphereGeometry(0.5, 36, 14, 0, Math.PI * 2, 0, Math.PI / 2).scale(1, 2, 1);
        G.glowCyl = new T.CylinderGeometry(0.5, 0.5, 1, 28).translate(0, 0.5, 0);
        G.glassCyl = new T.CylinderGeometry(0.5, 0.5, 1, 32, 1, true).translate(0, 0.5, 0);
        TAPERS.forEach((q, i) => { G['tp' + i] = new T.CylinderGeometry(0.5 * q, 0.5, 1, 32).translate(0, 0.5, 0); });
        FLARES.forEach((q, i) => { G['fl' + i] = new T.CylinderGeometry(0.5 * q, 0.5, 1, 32).translate(0, 0.5, 0); });
        this.geo = G;
        // drone parts
        this.dGeo = { body: new T.SphereGeometry(0.5, 12, 8).scale(5.4, 4.4, 5.4).translate(0, 2.6, 0), eye: new T.SphereGeometry(0.5, 8, 6).scale(1.6, 1.6, 1.6).translate(2.5, 3.2, 0), glow: new T.ConeGeometry(0.5, 1, 8).scale(3.2, 2.4, 3.2).translate(0, 0.3, 0).rotateX(Math.PI), ant: new T.CylinderGeometry(0.12, 0.12, 3, 5).translate(0, 6.6, 0), crate: new T.BoxGeometry(4, 3, 4).translate(0, 2.0, -3.2) };
    }
    _wallMaterial(warm) {
        const T = this.THREE, m = new T.MeshStandardMaterial({ color: 0xffffff, roughness: 0.86, metalness: 0.02 });
        const U = { uWin: { value: new T.Color(warm ? 0xffc27a : 0x9fdcff) }, uNight: { value: 0 }, uGlass: { value: new T.Color(0x1d2630) }, uWet: { value: 0 } };
        m.userData.U = U;
        m.onBeforeCompile = (sh) => {
            Object.assign(sh.uniforms, U);
            sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vCP; varying vec3 vCN; varying float vSeed;')
                .replace('#include <begin_vertex>', `#include <begin_vertex>
                #ifdef USE_INSTANCING
                  vec3 isc = vec3(length(instanceMatrix[0].xyz), length(instanceMatrix[1].xyz), length(instanceMatrix[2].xyz));
                  vSeed = fract(sin(dot(instanceMatrix[3].xz, vec2(12.9898, 78.233))) * 43758.5453);
                #else
                  vec3 isc = vec3(1.0); vSeed = 0.0;
                #endif
                vCP = position * isc; vCN = normal;`);
            sh.fragmentShader = sh.fragmentShader.replace('#include <common>', '#include <common>\nvarying vec3 vCP; varying vec3 vCN; varying float vSeed; uniform vec3 uWin; uniform vec3 uGlass; uniform float uNight; uniform float uWet;')
                .replace('#include <color_fragment>', `#include <color_fragment>
                float cFacade = 1.0 - step(0.6, abs(vCN.y));
                vec2 cUV = vec2(abs(vCN.x) > abs(vCN.z) ? vCP.z : vCP.x, vCP.y);
                vec2 cCell = vec2(11.0, 17.5), cId = floor(cUV / cCell), cF = fract(cUV / cCell);
                float cWin = step(0.17, cF.x) * step(cF.x, 0.83) * step(0.26, cF.y) * step(cF.y, 0.82) * cFacade * step(14.0, vCP.y);
                float cRnd = fract(sin(dot(cId + vSeed * 37.0, vec2(41.3, 289.1))) * 43758.5);
                float cLit = cWin * step(0.45, cRnd);
                diffuseColor.rgb *= 1.0 - 0.2 * (1.0 - step(0.08, cF.y)) * cFacade;
                diffuseColor.rgb = mix(diffuseColor.rgb, uGlass, cWin * 0.8);
                diffuseColor.rgb *= mix(0.62, 1.0, smoothstep(0.0, 90.0, vCP.y)) * (1.0 - 0.32 * uWet);`)
                .replace('#include <emissivemap_fragment>', '#include <emissivemap_fragment>\ntotalEmissiveRadiance += uWin * cLit * (0.05 + uNight * (0.7 + 0.8 * cRnd));');
        };
        m.customProgramCacheKey = () => 'cityWall';
        this._mist(m);
        return m;
    }
    // v54: the same fog / rain haze / valley mist the land gets (game.js wxAttachValleyMist). Basic (unlit) materials get the view-space varying it needs.
    _mist(m, basic) {
        if (!this.ctx.attachMist) return m;
        if (basic) {
            m.onBeforeCompile = (sh) => { sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vViewPosition;').replace('#include <fog_vertex>', '#include <fog_vertex>\nvViewPosition = - mvPosition.xyz;'); sh.fragmentShader = sh.fragmentShader.replace('#include <common>', '#include <common>\nvarying vec3 vViewPosition;'); };
            m.customProgramCacheKey = () => 'cityBasicFog';
        }
        this.ctx.attachMist(m); return m;
    }
    _buildDroneMeshes() {
        const T = this.THREE, cap = MAX_DRONES_TOTAL + 40, mk = (g, mat) => { const m = new T.InstancedMesh(g, mat, cap); m.count = 0; m.frustumCulled = false; m.instanceMatrix.setUsage(T.DynamicDrawUsage); m.instanceColor = new T.InstancedBufferAttribute(new Float32Array(cap * 3), 3); this.root.add(m); return m; };
        this.dm = { body: mk(this.dGeo.body, this._mist(new T.MeshStandardMaterial({ color: 0xffffff, roughness: 0.4, metalness: 0.5 }))), eye: mk(this.dGeo.eye, this._mist(new T.MeshBasicMaterial({ color: 0xffffff }), true)), glow: mk(this.dGeo.glow, this._mist(new T.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.8 }), true)), ant: mk(this.dGeo.ant, this._mist(new T.MeshStandardMaterial({ color: 0xffffff, roughness: 0.6 }))), crate: mk(this.dGeo.crate, this._mist(new T.MeshStandardMaterial({ color: 0xffffff, roughness: 0.9 }))) };
        this.dCols = { blue: new T.Color(0x3b8be8), green: new T.Color(0x3ccf78), blueG: new T.Color(0x7cc4ff), greenG: new T.Color(0x8dffb8), crate: new T.Color(0x8a6a48) };
    }
    // ------------------------------------------------------------------ UI (DOM)
    _injectUI() {
        const css = document.createElement('style');
        css.textContent = `
        #cityBubbles{position:fixed;inset:0;pointer-events:none;z-index:40;overflow:hidden}
        .cityBubble{position:absolute;max-width:230px;transform:translate(-50%,-100%);padding:6px 10px;border-radius:12px;font:12px/1.3 system-ui,sans-serif;color:#0d1a24;background:rgba(235,248,255,.93);box-shadow:0 2px 8px rgba(0,0,0,.35);border:2px solid #3b8be8;transition:opacity .15s}
        .cityBubble.green{border-color:#3ccf78;background:rgba(236,255,244,.93)}
        .cityBubble b{display:block;font-size:10px;opacity:.65;margin-bottom:1px}
        .cityBubble:after{content:'';position:absolute;left:50%;bottom:-8px;margin-left:-6px;border:6px solid transparent;border-top-color:#3b8be8;border-bottom:0}
        .cityBubble.green:after{border-top-color:#3ccf78}
        #cityPrompt{position:fixed;left:50%;bottom:22%;transform:translateX(-50%);padding:8px 14px;border-radius:10px;background:rgba(10,20,30,.78);color:#dff3ff;font:14px system-ui,sans-serif;z-index:45;display:none;pointer-events:auto;cursor:pointer;border:1px solid #3b8be8}
        #cityPanel{position:fixed;left:50%;top:50%;transform:translate(-50%,-50%);width:min(440px,94vw);max-height:88vh;overflow:auto;background:rgba(12,22,32,.96);color:#e3f3ff;border:2px solid #3b8be8;border-radius:14px;padding:14px;z-index:60;display:none;font:14px system-ui,sans-serif;box-shadow:0 8px 40px rgba(0,0,0,.6)}
        #cityPanel h3{margin:0 0 2px;font-size:17px} #cityPanel .sub{opacity:.65;font-size:12px;margin-bottom:10px}
        #cityPanel .say{background:rgba(59,139,232,.12);padding:10px;border-radius:10px;margin:8px 0;min-height:44px}
        #cityPanel button{display:block;width:100%;margin:6px 0;padding:11px;border-radius:9px;border:1px solid #3b8be8;background:rgba(59,139,232,.18);color:#e3f3ff;font:14px system-ui,sans-serif;cursor:pointer;text-align:left}
        #cityPanel button.sel{background:#3b8be8;color:#04121e} #cityPanel button:active{filter:brightness(1.3)}
        #cityPanel .row{display:flex;gap:6px;flex-wrap:wrap} #cityPanel .row button{width:auto;flex:1 1 30%;text-align:center;padding:8px 4px;font-size:12px}
        #cityPanel .quote{margin:10px 0;padding:10px;background:rgba(60,207,120,.12);border-radius:10px}
        #cityPanel input[type=range]{width:100%}`;
        document.head.appendChild(css);
        const mkdiv = (id) => { const d = document.createElement('div'); d.id = id; document.body.appendChild(d); return d; };
        this.bubbleHost = mkdiv('cityBubbles'); this.promptEl = mkdiv('cityPrompt'); this.panel = mkdiv('cityPanel');
        this.promptEl.addEventListener('click', () => this.tryInteract()); this.promptEl.addEventListener('touchstart', (e) => { e.preventDefault(); this.tryInteract(); }, { passive: false });
        window.addEventListener('keydown', (e) => { if (e.key === 'Escape' && this.uiOpen) { this.closeUI(); } });
    }
    // ------------------------------------------------------------------ per-site records / loading
    rec(site) {
        let r = this.recs.get(site.id);
        if (!r) {
            const accentBlue = h32(site.seedN, 1, 2, 3) < 0.5;
            r = { site, state: 'idle', name: site.citadel ? "Rogues' Citadel" : cityName(site.seedN, this._usedNames || (this._usedNames = new Set())), group: null, meshes: {}, mat: null, data: null, sim: null, face: -1, econ: null, residents: null, beacon: null, accent: accentBlue ? 0x4fb4ff : 0x4dffb0 };
            r.econ = this.econState[site.id] || (this.econState[site.id] = makeEconomy(site.seedN));
            this.recs.set(site.id, r);
        }
        return r;
    }
    _request(r) {
        r.state = 'building'; r.reqAt = performance.now(); const tok = r.tok = (r.tok || 0) + 1;
        this.ctx.postJob('city', { siteId: r.site.id }, (out) => { if (r.tok === tok) this._onCity(r, out); }, () => { if (r.tok !== tok) return; r.state = 'idle'; r.retryAt = this.t + 20; console.warn('[Vale] city job failed in the worker, retrying:', r.name); });
    }
    // v52: the window shader is the one piece nobody could test without a GPU. If its program failed to compile the walls would silently not draw,
    // so after the city has been on screen for a few frames look at the program's diagnostics and swap in a plain material when it is broken.
    _shaderCheck(r) {
        const rd = this.ctx.getRenderer && this.ctx.getRenderer(); if (!rd || r.shaderOk !== undefined || !r.group.visible) return;
        r._chk = (r._chk || 0) + 1; if (r._chk < 6) return;
        const pr = rd.properties && rd.properties.get(r.wallMat), prog = pr && pr.currentProgram; if (!prog) return;
        r.shaderOk = !(prog.diagnostics && prog.diagnostics.runnable === false);
        if (r.shaderOk) return;
        const dg = prog.diagnostics; console.error('[Vale] the city window shader failed to compile - using plain walls.', dg && dg.programLog, dg && dg.vertexShader && dg.vertexShader.log, dg && dg.fragmentShader && dg.fragmentShader.log);
        const T = this.THREE, plain = new T.MeshStandardMaterial({ color: 0xffffff, roughness: 0.86, metalness: 0.02 });
        for (const k of ['wallBox', 'wallCyl']) if (r.meshes[k]) r.meshes[k].material = plain;
        r.wallMat = { userData: { U: { uNight: { value: 0 } } } };
    }
    // one line of status for the HUD
    statusLine(site) {
        const r = this.recs.get(site.id); if (!r) return 'not requested';
        const age = r.reqAt ? ((performance.now() - r.reqAt) / 1000).toFixed(0) + 's' : '-';
        return r.state + (r.err ? ' (' + r.err + ')' : '') + (r.state === 'building' ? ' ' + age : '') + (r.state === 'ready' ? ' shader:' + (r.shaderOk === undefined ? '?' : r.shaderOk ? 'ok' : 'FAILED') + ' vis:' + (r.group && r.group.visible ? 1 : 0) : '');
    }
    // v51: if the worker never answers (or answers with something broken) build the city on the main thread instead, once
    _watchdog(r) {
        if (r.state !== 'building' || r.localTried || performance.now() - r.reqAt < 9000 || !this.ctx.buildLocal) return;
        r.localTried = true; r.tok++;
        try { const out = this.ctx.buildLocal('city', { siteId: r.site.id }); console.warn('[Vale] worker was too slow for ' + r.name + ' - built it on the main thread'); this._onCity(r, out); }
        catch (e) { console.error('[Vale] local city build failed', e); r.state = 'failed'; r.err = String(e && e.message || e); }
    }
    _onCity(r, out) {
        try { this._onCity2(r, out); }
        catch (e) { console.error('[Vale] building the city meshes failed for ' + r.name, e); r.state = 'failed'; r.err = String(e && e.message || e); if (r.group) { this.root.remove(r.group); r.group = null; r.meshes = {}; } }
    }
    _onCity2(r, out) {
        if (!out || out.empty) { r.state = 'failed'; r.err = 'empty'; return; }
        const T = this.THREE, G = this.geo, d = out.inst, life = out.life; r.data = out; r.life = life;
        const g = new T.Group(); g.name = 'city_' + r.site.id; r.group = g; this.root.add(g);
        const wallMat = this._wallMaterial(life.meta.warmWindows); r.wallMat = wallMat;
        const plainMat = this._mist(new T.MeshStandardMaterial({ color: 0xffffff, roughness: 0.92 })), glowMat = this._mist(new T.MeshBasicMaterial({ color: 0xffffff }), true), skyMat = this._mist(new T.MeshStandardMaterial({ color: 0xffffff, roughness: 0.8, emissive: new T.Color(r.accent), emissiveIntensity: 0.0 }));
        const glassMat = this._mist(new T.MeshStandardMaterial({ color: 0xffffff, roughness: 0.12, metalness: 0.15, transparent: true, opacity: 0.2, depthWrite: false, side: T.DoubleSide, emissive: new T.Color(0x1d4a3a), emissiveIntensity: 0.35 }));
        r.plainMat = plainMat; r.skyMat = skyMat; r.glassMat = glassMat;
        const pearlMat = this._mist(new T.MeshStandardMaterial({ color: 0xffffff, roughness: 0.34, metalness: 0.22, emissive: new T.Color(0x0b3a36), emissiveIntensity: 0.0 })); r.pearlMat = pearlMat;
        const kinds = { wallBox: [G.box, wallMat, 'far', true], wallCyl: [G.cyl, wallMat, 'far', true], gable: [G.gable, plainMat, 'mid', true], dome: [G.dome, plainMat, 'mid', true], cone: [G.cone, plainMat, 'mid', false], plainBox: [G.box, plainMat, 'full', false], baseBox: [G.box, plainMat, 'far', false], plainCyl: [G.cyl, plainMat, 'full', false], arch: [G.arch, plainMat, 'full', false], glow: [G.box, glowMat, 'full', false], glassDome: [G.dome, glassMat, 'mid', false],
            orgCyl: [G.orgCyl, pearlMat, 'mid', true], orgDome: [G.orgDome, pearlMat, 'mid', true], orgCone: [G.orgCone, pearlMat, 'mid', false], glowCyl: [G.glowCyl, glowMat, 'full', false], glassCyl: [G.glassCyl, glassMat, 'far', false] };
        TAPERS.forEach((q, i) => { kinds['tp' + i] = [G['tp' + i], pearlMat, 'mid', true]; }); FLARES.forEach((q, i) => { kinds['fl' + i] = [G['fl' + i], pearlMat, 'mid', true]; });
        for (const k in d.cats) {
            const [geo, mat, tier, cast] = kinds[k], n = d.cats[k].m.length / 16, im = new T.InstancedMesh(geo, mat, n);
            im.instanceMatrix.array.set(d.cats[k].m); im.instanceMatrix.needsUpdate = true;
            im.instanceColor = new T.InstancedBufferAttribute(d.cats[k].c, 3);
            im.frustumCulled = false; im.userData.tier = tier; im.userData.cast = cast; im.receiveShadow = k !== 'glow' && k !== 'glassDome' && k !== 'glowCyl' && k !== 'glassCyl'; if (k === 'glassDome' || k === 'glassCyl') im.renderOrder = 3; g.add(im); r.meshes[k] = im;
        }
        if (d.sky.n) { const im = new T.InstancedMesh(G.box, skyMat, d.sky.n); im.instanceMatrix.array.set(d.sky.m); im.instanceMatrix.needsUpdate = true; im.instanceColor = new T.InstancedBufferAttribute(d.sky.c, 3); im.frustumCulled = false; g.add(im); r.meshes.sky = im; }
        if (out.road && out.road.idx && out.road.idx.length) {   // v54: the street surfaces, one mesh
            const rg = new T.BufferGeometry(); rg.setAttribute('position', new T.BufferAttribute(out.road.pos, 3)); rg.setAttribute('normal', new T.BufferAttribute(out.road.nor, 3)); rg.setAttribute('color', new T.BufferAttribute(out.road.col, 3)); rg.setIndex(new T.BufferAttribute(out.road.idx, 1));
            if (!this._roadSurfMat) this._roadSurfMat = this._mist(new T.MeshStandardMaterial({ color: 0xffffff, vertexColors: true, roughness: 0.94, side: T.DoubleSide }));
            const rm = new T.Mesh(rg, this._roadSurfMat); rm.frustumCulled = false; rm.receiveShadow = true; rm.userData.tier = 'mid'; g.add(rm); r.meshes.roadSurf = rm;
        }
        r.col = out.cols && out.cols.length ? new CityCollider(out.cols) : null; r.probes = out.probes || null; r.yOff = 0; r.tunnel = out.tunnel || null; r.beamData = out.beam || null;
        if (r.site.citadel) this._makeCitadelFx(r);
        r.residents = makeResidents(r.site.seedN, 96, life);
        this._placeGroup(r); if (!r.site.citadel) this._makeBeacon(r, d.beacon);
        r.state = 'ready';
    }
    // ------------------------------------------------------------------ v56: the Rogues' Citadel's beam (12 000 m), glow and enchanted sparkles
    _citadelBeam(r) {
        if (r.cbeam) return r.cbeam; const T = this.THREE, H = 51000;
        const vs = `varying float vY; varying vec3 vN; varying vec3 vV; void main(){ vY = position.y / ${H.toFixed(1)}; vec4 mv = modelViewMatrix * vec4(position, 1.0); vN = normalize(normalMatrix * normal); vV = normalize(-mv.xyz); gl_Position = projectionMatrix * mv; }`;
        const fs = `uniform float uTime; uniform float uNight; uniform float uA; uniform float uHaze; varying float vY; varying vec3 vN; varying vec3 vV;
          void main(){ float f = pow(abs(dot(normalize(vN), normalize(vV))), 1.6); float mixv = 0.5 + 0.5 * sin(vY * 11.0 - uTime * 0.45); vec3 blue = vec3(0.12, 0.62, 1.0), green = vec3(0.16, 1.0, 0.52); vec3 c = mix(blue, green, mixv);
            float pulse = 0.62 + 0.38 * sin(vY * 190.0 - uTime * 2.2); float top = 1.0 - smoothstep(0.86, 1.0, vY); float low = smoothstep(0.0, 0.004, vY);
            float a = f * pulse * top * low * uA * (0.62 + 0.55 * uNight) * (1.0 - 0.6 * uHaze); gl_FragColor = vec4(c * (1.0 + 0.5 * f), a); }`;
        const mk = (rad, rad2, A, seg) => { const m = new T.ShaderMaterial({ vertexShader: vs, fragmentShader: fs, transparent: true, depthWrite: false, blending: T.AdditiveBlending, side: T.DoubleSide, fog: false, uniforms: { uTime: { value: 0 }, uNight: { value: 0 }, uA: { value: A }, uHaze: { value: 0 } } }); const me = new T.Mesh(new T.CylinderGeometry(rad2, rad, H, seg, 1, true).translate(0, H / 2, 0), m); me.frustumCulled = false; me.renderOrder = 6; return me; };
        const core = mk(5.5, 4.2, 1.9, 20), halo = mk(32, 20, 0.55, 28), wide = mk(120, 70, 0.16, 28);
        const grp = new T.Group(); grp.add(core, halo, wide); this.root.add(grp);
        // base glow + upper glow sprites
        const spr = new T.Sprite(new T.SpriteMaterial({ map: this._glowTex || (this._makeGlowTex(), this._glowTex), color: new T.Color(0x4fd8ff), transparent: true, depthWrite: false, blending: T.AdditiveBlending, fog: false, opacity: 0.5 })); spr.scale.set(1500, 1500, 1); spr.renderOrder = 5; this.root.add(spr);
        r.cbeam = { grp, mats: [core.material, halo.material, wide.material], spr, H }; return r.cbeam;
    }
    _makeGlowTex() { const T = this.THREE, c = document.createElement('canvas'); c.width = c.height = 128; const x = c.getContext('2d'), gr = x.createRadialGradient(64, 64, 0, 64, 64, 64); gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(0.25, 'rgba(255,255,255,.45)'); gr.addColorStop(1, 'rgba(255,255,255,0)'); x.fillStyle = gr; x.fillRect(0, 0, 128, 128); this._glowTex = new T.CanvasTexture(c); }
    _makeCitadelFx(r) {
        const T = this.THREE; this._citadelBeam(r);
        if (r.sparkles) return; const N = 1800, pos = new Float32Array(N * 3), ph = new Float32Array(N); let seed = r.site.seedN >>> 0; const rnd = () => { seed = (seed + 0x6D2B79F5) >>> 0; let t = seed; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
        for (let i = 0; i < N; i++) { const a = rnd() * 6.2832, rr = 200 + Math.sqrt(rnd()) * 3600; pos[i * 3] = Math.cos(a) * rr; pos[i * 3 + 1] = r.site.floorH + 6 + Math.pow(rnd(), 1.6) * 950; pos[i * 3 + 2] = Math.sin(a) * rr; ph[i] = rnd() * 6.28; }
        const g = new T.BufferGeometry(); g.setAttribute('position', new T.BufferAttribute(pos, 3)); g.setAttribute('ph', new T.BufferAttribute(ph, 1));
        const m = new T.ShaderMaterial({ transparent: true, depthWrite: false, blending: T.AdditiveBlending, fog: false, uniforms: { uTime: { value: 0 }, uNight: { value: 0 }, uPx: { value: 700 } },
            vertexShader: `attribute float ph; uniform float uTime; uniform float uPx; varying float vT; varying float vH; void main(){ vec3 p = position; p.y += sin(uTime * 0.4 + ph * 3.0) * 7.0; p.x += sin(uTime * 0.23 + ph) * 9.0; p.z += cos(uTime * 0.19 + ph * 2.0) * 9.0; vec4 mv = modelViewMatrix * vec4(p, 1.0); gl_Position = projectionMatrix * mv; vT = 0.5 + 0.5 * sin(uTime * 1.3 + ph * 5.0); vH = fract(ph * 0.318); gl_PointSize = clamp(uPx * (4.0 + 3.0 * vH) / max(1.0, -mv.z), 1.5, 16.0); }`,
            fragmentShader: `uniform float uNight; varying float vT; varying float vH; void main(){ vec2 q = gl_PointCoord - 0.5; float d = length(q); if (d > 0.5) discard; float a = (1.0 - d * 2.0); a *= a; vec3 c = mix(vec3(0.3, 0.9, 1.0), vec3(0.45, 1.0, 0.6), vH); gl_FragColor = vec4(c, a * (0.25 + 0.75 * vT) * (0.35 + 0.65 * uNight)); }` });
        const pts = new T.Points(g, m); pts.frustumCulled = false; pts.renderOrder = 7; r.group.add(pts); r.sparkles = pts;
    }
    // is the player inside the Citadel's mountain tunnel? (game.js skips the terrain snap + slope limit there: the bore runs UNDER the heightfield)
    inTunnel(pos) {
        const recs = this._tunRecs; if (!recs || !recs.length) return false; const face = this.ctx.getFace();
        for (const r of recs) {
            const t = r.tunnel, ps = r.ps; if (!t || !ps || r.face !== face) continue; const l = this.toLocal(ps, pos.x, pos.z, { x: 0, z: 0 });
            const s = l.x * t.tx + l.z * t.tz, lat = -l.x * t.tz + l.z * t.tx; if (s < t.sA - 3 || s > t.sB + 3 || Math.abs(lat) > t.hw + 2) continue;
            const yf = (t.yT - t.gt * Math.max(0, s - t.sIn)) + (r.yOff || 0), feet = pos.y - (this.ctx.getPlayer().height || 8.5);
            if (feet > yf - 8 && feet < yf + t.ht + 8) return true;
        }
        return false;
    }
    _makeBeacon(r, b) {
        const T = this.THREE; if (r.beacon) return;
        if (!this._glowTex) { const c = document.createElement('canvas'); c.width = c.height = 128; const x = c.getContext('2d'), gr = x.createRadialGradient(64, 64, 0, 64, 64, 64); gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(0.25, 'rgba(255,255,255,.45)'); gr.addColorStop(1, 'rgba(255,255,255,0)'); x.fillStyle = gr; x.fillRect(0, 0, 128, 128); this._glowTex = new T.CanvasTexture(c); }
        const col = new T.Color(r.accent), spr = new T.Sprite(new T.SpriteMaterial({ map: this._glowTex, color: col, transparent: true, depthWrite: false, blending: T.AdditiveBlending, fog: false, opacity: 0.5 }));
        spr.scale.set(1100, 1100, 1); spr.renderOrder = 5;
        const shaft = new T.Mesh(new T.CylinderGeometry(7, 22, 1500, 10, 1, true).translate(0, 750, 0), new T.MeshBasicMaterial({ color: col, transparent: true, opacity: 0.16, depthWrite: false, blending: T.AdditiveBlending, fog: false, side: T.DoubleSide }));
        shaft.renderOrder = 4;
        this.root.add(spr); this.root.add(shaft); r.beacon = { spr, shaft, y: b ? b.y : r.site.floorH + 300 };
    }
    _placeGroup(r) {
        const ps = this.valleys.placed(this.ctx.getFace()).find(p => p.site === r.site); if (!ps) return false;
        r.ps = ps; r.face = this.ctx.getFace();
        if (r.probes && r.probes.length) this._fitGround(r, ps);
        if (r.group) { r.group.position.set(ps.cx, r.yOff || 0, ps.cz); r.group.rotation.set(0, -ps.psi, 0); r.group.scale.set(1 / ps.gnd, 1, 1 / ps.gnd); r.group.updateMatrixWorld(true); }
        if (r.beacon) { r.beacon.spr.position.set(ps.cx, r.beacon.y + (r.yOff || 0), ps.cz); r.beacon.shaft.position.set(ps.cx, r.site.floorH, ps.cz); }
        if (r.cbeam) { r.cbeam.grp.position.set(ps.cx, r.site.floorH + (r.yOff || 0), ps.cz); r.cbeam.grp.scale.set(1 / ps.gnd, 1, 1 / ps.gnd); r.cbeam.spr.position.set(ps.cx, r.site.floorH + (r.yOff || 0) + 120, ps.cz); }
        return true;
    }
    // v54: compare the generator's ground with the REAL ground at ~150 building spots; a systematic offset (chart/sphere registration) is removed by moving the whole city
    _fitGround(r, ps) {
        const pr = r.probes, w = { x: 0, z: 0 }, d = []; for (let i = 0; i + 2 < pr.length; i += 3) { this.toWorld(ps, pr[i], pr[i + 1], w); const g = this.ctx.getGround(w.x, w.z); if (Number.isFinite(g)) d.push(pr[i + 2] - g); }
        if (d.length < 20) { r.yOff = 0; return; } d.sort((a, b) => a - b); const med = d[d.length >> 1];
        r.fitMed = med; r.yOff = Math.abs(med) > 0.6 && Math.abs(med) < 40 ? -med : 0;
    }
    // v54: player collision against every nearby city's solids (called from game.js updatePlayer after the move; (px,py,pz) = where the player was)
    collidePlayer(pl, px, py, pz) {
        const recs = this._colRecs; if (!recs || !recs.length) return; const P = pl.position, face = this.ctx.getFace();
        for (const r of recs) {
            const ps = r.ps; if (!ps || r.face !== face || !r.col) continue;
            const a = this.toLocal(ps, px, pz, { x: 0, z: 0 }), b = this.toLocal(ps, P.x, P.z, { x: 0, z: 0 }), yo = r.yOff || 0, R = r.col.reach + 12;
            if (Math.hypot(a.x, a.z) > R && Math.hypot(b.x, b.z) > R) continue;
            const y0 = py - yo, y1 = P.y - yo, dx = b.x - a.x, dz = b.z - a.z, dy = y1 - y0, len = Math.hypot(dx, dz, dy), n = len > 400 ? 1 : Math.min(120, Math.max(1, Math.ceil(len / 2.2)));
            const m = { x: a.x, y: y0, z: a.z }; let grounded = false, hit = false;
            for (let k = 1; k <= n; k++) {
                const qx = m.x, qy = m.y, qz = m.z; m.x += dx / n; m.y += dy / n; m.z += dz / n;
                const res = r.col.resolve(m, qx, qy, qz, pl.height, 1.8, 1.0, 2.4); if (res.hit) hit = true; if (res.grounded) grounded = true;
            }
            if (!hit) continue;
            const w = this.toWorld(ps, m.x, m.z, { x: 0, z: 0 }), ny = m.y + yo, ddy = ny - P.y;
            P.x = w.x; P.z = w.z; P.y = ny; pl.cameraY += ddy;
            if (grounded && pl.velocity.y <= 0) { pl.velocity.y = 0; pl.isGrounded = true; } else if (ddy < -0.01 && pl.velocity.y > 0) pl.velocity.y = 0;
        }
    }
    // plan (local) <-> chart helpers for a placed site
    toWorld(ps, lx, lz, out) { out.x = ps.cx + (lx * ps.c - lz * ps.s) / ps.gnd; out.z = ps.cz + (lx * ps.s + lz * ps.c) / ps.gnd; return out; }
    toLocal(ps, x, z, out) { const dx = x - ps.cx, dz = z - ps.cz; out.x = (dx * ps.c + dz * ps.s) * ps.gnd; out.z = (-dx * ps.s + dz * ps.c) * ps.gnd; return out; }

    // ------------------------------------------------------------------ per-frame
    update(dt) {
        const ctx = this.ctx, P = ctx.getPlayer(), face = ctx.getFace(); this.t += dt;
        const tunRecs = []; const placed = this.valleys.placed(face), night = ctx.getNight(), dayTime = ctx.getDayTime(), md = ctx.machineDestroyed();
        this.droneN = 0; this.crateN = 0; this.bubblesToShow = []; const colRecs = []; const haze = this.ctx.getHaze ? this.ctx.getHaze() : 0, wet = this.ctx.getWet ? this.ctx.getWet() : 0;
        let nearest = null;
        const seen = this._seen || (this._seen = new Set()); seen.clear();
        for (const ps of placed) {
            const r = this.rec(ps.site), dx = P.x - ps.cx, dz = P.z - ps.cz, dist = Math.hypot(dx, dz) * ps.gnd;
            seen.add(r); this._watchdog(r);
            if (r.state === 'idle' && dist < BUILD_DIST && (!r.retryAt || this.t > r.retryAt)) this._request(r);
            if (r.site.citadel) { if (!r.cbeam) { this._citadelBeam(r); this._placeGroup(r); } }
            else if (!r.beacon && r.state !== 'ready') { this._makeBeacon(r, null); this._placeGroup(r); }
            if (r.face !== face) this._placeGroup(r);
            r.dist = dist;
            if (r.beacon) { const far = dist > 1800 && dist < 90000; r.beacon.spr.visible = far; r.beacon.shaft.visible = far; const hz = 1 - Math.min(0.88, haze * 1.1); r.beacon.spr.material.opacity = (0.18 + 0.6 * night) * hz; r.beacon.shaft.material.opacity = (0.05 + 0.2 * night) * hz; const sc = Math.max(700, dist * 0.04); r.beacon.spr.scale.set(sc, sc, 1); }
            if (r.cbeam) {   // v56: the Citadel's beam is visible from anywhere on the chart; its look follows night / haze
                const hz = Math.min(0.9, haze), vis = dist < 400000; r.cbeam.grp.visible = vis; r.cbeam.spr.visible = vis && dist > 2500;
                for (const m of r.cbeam.mats) { m.uniforms.uTime.value = this.t; m.uniforms.uNight.value = night; m.uniforms.uHaze.value = hz; }
                r.cbeam.spr.material.opacity = (0.22 + 0.5 * night) * (1 - hz); const sc = Math.max(1200, dist * 0.05); r.cbeam.spr.scale.set(sc, sc, 1);
            }
            if (r.state !== 'ready') continue;
            // LOD (the Citadel is ~5x the size of an ordinary city: its rings scale up)
            const LK = r.site.citadel ? 2.6 : 1, full = dist < FULL_D * LK, mid = dist < MID_D * LK, far = dist < FAR_D * LK, sky = dist < SKY_D * LK;
            if (r.tunnel && dist < 9000) tunRecs.push(r);
            if (r.sparkles) { r.sparkles.visible = dist < 7500; r.sparkles.material.uniforms.uTime.value = this.t; r.sparkles.material.uniforms.uNight.value = night; }
            if (r.pearlMat) r.pearlMat.emissiveIntensity = 0.05 + 0.5 * night;
            r.group.visible = sky;
            if (r.col && dist < r.col.reach + 700) colRecs.push(r);
            for (const k in r.meshes) { const m = r.meshes[k], t = m.userData.tier; m.visible = k === 'sky' ? (!far) : (t === 'full' ? full : t === 'far' ? far : mid); const cs = full && dist < 2400 * LK && m.userData.cast; if (m.castShadow !== cs) m.castShadow = cs; }
            this._shaderCheck(r);
            r.wallMat.userData.U.uNight.value = night; if (r.wallMat.userData.U.uWet) r.wallMat.userData.U.uWet.value = wet;
            r.skyMat.emissiveIntensity = 0.15 + night * 0.9;
            // drone simulation only near the player
            if (dist < SIM_ON * (r.site.citadel ? 1.7 : 1) && !r.sim && this.droneN + DRONES_PER_CITY <= MAX_DRONES_TOTAL) { r.sim = new CitySim(r.life, r.residents, { cityName: r.name, seed: r.site.seedN, maxDrones: DRONES_PER_CITY, solid: r.col ? (d, y) => r.col.pushOutXZ(d, y, 2.7) : null }); r.sim.activate(dayTime); }
            if (r.sim && dist > SIM_OFF * (r.site.citadel ? 1.7 : 1)) { for (const d of r.sim.drones) if (d.bubble) { d.bubble = null; } r.sim = null; if (this.talking && this.talking.rec === r) this.closeUI(); }
            if (r.sim) {
                const pl = this.toLocal(ps, P.x, P.z, { x: 0, z: 0 });
                if (!this.uiOpen) r.sim.step(dt, dayTime, night > 0.5, md, pl); else r.sim.step(dt * 0.0, dayTime, night > 0.5, md, null);
                this._renderSimDrones(r, ps, P, dayTime);
                if (!this.uiOpen) { const d = r.sim.nearestDrone(pl.x, pl.z, 16); if (d) { const best = nearest; const dd = Math.hypot(d.x - pl.x, d.z - pl.z); if (!best || dd < best.dd) nearest = { r, d, ps, dd, kind: 'res' }; } }
            }
        }
        // v51: a site that is not part of this chart (far side of the planet / beyond the face) keeps stale chart coordinates from another face: hide it
        for (const r of this.recs.values()) {
            if (seen.has(r)) continue;
            if (r.group) r.group.visible = false;
            if (r.beacon) { r.beacon.spr.visible = false; r.beacon.shaft.visible = false; }
            if (r.cbeam) { r.cbeam.grp.visible = false; r.cbeam.spr.visible = false; }
            if (r.sim) { for (const d of r.sim.drones) if (d.bubble) d.bubble = null; r.sim = null; if (this.talking && this.talking.rec === r) this.closeUI(); }
            r.face = -1;
        }
        this.hover = nearest; this._colRecs = colRecs; this._tunRecs = tunRecs;
        this._updateRoads(dt, P, face, night);
        this._flushDrones();
        this._updatePrompt(P);
        this._updateBubbles(P);
        if (this._relaxT === undefined) this._relaxT = this.t; if (this.t - this._relaxT > 120) { const days = (this.t - this._relaxT) / 555; this._relaxT = this.t; for (const r of this.recs.values()) relax(r.econ, r.site.seedN, days); }
    }
    // ------------------------------------------------------------------ drones: instanced rendering
    _pushDrone(x, y, z, yaw, color, cargo, bubbleOwner) {
        if (this.droneN >= MAX_DRONES_TOTAL + 40) return -1;
        const T = this.THREE, i = this.droneN++, dm = this.dm, m = this._m4 || (this._m4 = new T.Matrix4()), q = this._q || (this._q = new T.Quaternion()), v = this._v || (this._v = new T.Vector3()), s = this._s || (this._s = new T.Vector3(1, 1, 1)), up = this._up || (this._up = new T.Vector3(0, 1, 0));
        q.setFromAxisAngle(up, yaw); v.set(x, y, z); m.compose(v, q, s);
        dm.body.setMatrixAt(i, m); dm.eye.setMatrixAt(i, m); dm.glow.setMatrixAt(i, m); dm.ant.setMatrixAt(i, m);
        const blue = color === 'blue', c = blue ? this.dCols.blue : this.dCols.green, g = blue ? this.dCols.blueG : this.dCols.greenG;
        dm.body.setColorAt(i, c); dm.glow.setColorAt(i, g); dm.eye.setColorAt(i, g); dm.ant.setColorAt(i, c);
        if (cargo) { dm.crate.setMatrixAt(this.crateN, m); dm.crate.setColorAt(this.crateN, this.dCols.crate); this.crateN++; }
        return i;
    }
    _renderSimDrones(r, ps, P, dayTime) {
        const w = this._w || (this._w = { x: 0, z: 0 });
        for (const d of r.sim.drones) {
            this.toWorld(ps, d.x, d.z, w);
            const bob = Math.sin(d.bobPh) * 0.5, hy = d.y + d.res.hover + bob - (d.asleep ? d.res.hover - 0.2 : 0);
            this._pushDrone(w.x, hy, w.z, d.yaw - ps.psi, d.res.color, false);
            d._wx = w.x; d._wy = hy + 8; d._wz = w.z;
            if (d.bubble && Math.hypot(w.x - P.x, w.z - P.z) < 130) this.bubblesToShow.push({ x: w.x, y: hy + 8, z: w.z, text: d.bubble.text, name: d.res.name, color: d.res.color, t: d.bubble.t });
        }
    }
    _flushDrones() {
        const dm = this.dm, n = this.droneN | 0;
        for (const k of ['body', 'eye', 'glow', 'ant']) { dm[k].count = n; dm[k].instanceMatrix.needsUpdate = true; if (dm[k].instanceColor) dm[k].instanceColor.needsUpdate = true; }
        dm.crate.count = this.crateN | 0; dm.crate.instanceMatrix.needsUpdate = true; if (dm.crate.instanceColor) dm.crate.instanceColor.needsUpdate = true;
        this.crateN = 0;
    }
    // ------------------------------------------------------------------ bubbles + prompt
    _updateBubbles(P) {
        const cam = this.ctx.camera, T = this.THREE, v = this._pv || (this._pv = new T.Vector3()), host = this.bubbleHost, els = this.bubbleEls;
        let used = 0;
        for (const b of this.bubblesToShow.slice(0, 8)) {
            v.set(b.x, b.y, b.z).project(cam);
            if (v.z > 1 || v.z < -1 || Math.abs(v.x) > 1.1 || Math.abs(v.y) > 1.1) continue;
            let el = els[used]; if (!el) { el = document.createElement('div'); el.className = 'cityBubble'; host.appendChild(el); els.push(el); }
            used++; el.style.display = ''; el.className = 'cityBubble ' + (b.color === 'green' ? 'green' : '');
            el.style.left = ((v.x * 0.5 + 0.5) * window.innerWidth) + 'px'; el.style.top = ((-v.y * 0.5 + 0.5) * window.innerHeight) + 'px'; el.style.opacity = Math.min(1, b.t * 2);
            const html = `<b>${b.name}</b>${b.text}`; if (el._h !== html) { el.innerHTML = html; el._h = html; }
        }
        for (let i = used; i < els.length; i++) els[i].style.display = 'none';
    }
    _updatePrompt(P) {
        const h = this.hover, el = this.promptEl;
        if (!h || this.uiOpen || this.ctx.isPaused()) { el.style.display = 'none'; return; }
        const job = h.kind === 'res' ? JOBS.find(j => j.id === h.d.res.job).title : 'Cargo hauler', name = h.kind === 'res' ? h.d.res.name : h.cd.name;
        el.style.display = 'block'; el.textContent = `E / tap  -  Talk to ${name} (${job})`;
    }
    // ------------------------------------------------------------------ interaction + UI
    tryInteract() {
        if (this.uiOpen) return true;
        const h = this.hover; if (!h) return false;
        if (h.kind === 'cargo') { this._cargoSay(h.cd); return true; }
        this.openConversation(h.r, h.d, h.ps); return true;
    }
    _ctxLife(r) { return { machineDestroyed: this.ctx.machineDestroyed(), night: this.ctx.getNight() > 0.5, cityName: r.name }; }
    openConversation(r, d, ps) {
        d.talk = true; this.talking = { rec: r, d }; this.uiOpen = true; this.ctx.pause(true);
        const job = JOBS.find(j => j.id === d.res.job);
        this._renderDialog(r, d, `${d.res.name}: ${this._greet(r, d)}`, job);
    }
    _greet(r, d) { const md = this.ctx.machineDestroyed(); return md ? 'You... you are the one from the sky? Please, ask me anything.' : 'Quietly, traveller. What can I do for you?'; }
    _renderDialog(r, d, sayText, job) {
        const md = this.ctx.machineDestroyed(), P = this.panel, tp = topics(d.res, this._ctxLife(r));
        P.style.display = 'block';
        P.innerHTML = `<h3>${d.res.name} <span style="color:${d.res.color === 'blue' ? '#7cc4ff' : '#8dffb8'}">&#9679;</span></h3><div class="sub">${job.title} &middot; ${r.name} &middot; ${r.site.citadel ? 'the Rogues' : FACTION_NAME}${md ? ' &middot; the empire has fallen' : ''}</div><div class="say">${sayText.replace(/^[^:]+: /, '')}</div>`;
        for (const t of tp) { const b = document.createElement('button'); b.textContent = t.label; b.onclick = () => { if (t.action === 'trade') this.openTrade(r, d); else if (t.action === 'close') this.closeUI(); else this._renderDialog(r, d, `${d.res.name}: ${t.reply}`, job); }; P.appendChild(b); }
    }
    openTrade(r, d) {
        const P = this.panel, inv = this.ctx.inv, econ = r.econ; let give = RESOURCES.find(k => inv.get(k) > 0) || 'wood', get = RESOURCES.find(k => k !== give) || 'stone', qty = 1;
        const draw = () => {
            const have = inv.get(give); qty = Math.max(0, Math.min(qty, have));
            const q = quote(econ, give, get, qty);
            P.innerHTML = `<h3>Trade with ${d.res.name}</h3><div class="sub">${r.name} market &middot; barter, no currency</div><div><b>You give</b></div><div class="row" id="ctGive"></div><div style="margin-top:8px"><b>You get</b></div><div class="row" id="ctGet"></div>
              <div style="margin-top:8px">Amount: <b>${qty}</b> / ${have} <input type="range" id="ctQty" min="0" max="${have}" value="${qty}"></div>
              <div class="quote">${qty > 0 ? (q.got > 0 ? `${qty} ${RES_NAME[give]} &rarr; <b>${q.got} ${RES_NAME[get]}</b>${q.capped ? ' (all they have)' : ''}<br><span style="opacity:.7;font-size:12px">rate ${q.rate.toFixed(2)} &middot; their stock of ${RES_NAME[get]}: ${econ.stock[get]}</span>` : 'That is not enough for even one. Offer more.') : 'Choose an amount.'}</div>
              <button id="ctGo" ${q.ok ? '' : 'disabled style="opacity:.4"'}>Make the trade</button><button id="ctBack">Back to conversation</button>`;
            const mk = (host, cur, fn, showHave) => { const el = P.querySelector(host); for (const k of RESOURCES) { const b = document.createElement('button'); b.textContent = `${RES_NAME[k]}${showHave ? ' (' + inv.get(k) + ')' : ''}`; if (k === cur) b.className = 'sel'; b.onclick = () => { fn(k); draw(); }; el.appendChild(b); } };
            mk('#ctGive', give, (k) => { give = k; if (get === k) get = RESOURCES.find(x => x !== k); qty = Math.min(qty, inv.get(k)); }, true);
            mk('#ctGet', get, (k) => { get = k; if (give === k) give = RESOURCES.find(x => x !== k); }, false);
            P.querySelector('#ctQty').oninput = (e) => { qty = parseInt(e.target.value, 10) || 0; draw(); };
            P.querySelector('#ctBack').onclick = () => this.openConversation(r, d, null);
            P.querySelector('#ctGo').onclick = () => { if (!q.ok) return; const res = execute(econ, give, get, qty); if (res.ok) { inv.add(give, -qty); inv.add(get, res.got); this.ctx.onTrade && this.ctx.onTrade(r.name, give, qty, get, res.got); } qty = 0; draw(); };
        };
        draw();
    }
    closeUI() { if (this.talking) { this.talking.d.talk = false; this.talking = null; } this.panel.style.display = 'none'; this.uiOpen = false; this.ctx.pause(false); }

    // ------------------------------------------------------------------ roads + cargo drones
    _requestRoads() {
        if (this.roadsRequested) return; this.roadsRequested = true;
        const pairs = planRoads(this.sites);
        for (const p of pairs) { const road = { a: p.a, b: p.b, state: 'building', pts: null, tiles: new Map(), chartFace: -1, cd: [] }; this.roads.push(road); this.ctx.postJob('road', { a: p.a, b: p.b }, (out) => this._onRoad(road, out), () => { road.state = 'failed'; }); }
    }
    _onRoad(road, out) {
        if (!out || !out.road || !out.road.ok) { road.state = 'failed'; return; }
        road.pts = out.road.pts; road.len = out.road.len; road.state = 'ready';
        const A = this.rec(this.sites[road.a]), B = this.rec(this.sites[road.b]), n = Math.max(3, Math.min(8, Math.round(road.len / 25000)));
        for (let i = 0; i < n; i++) { const sd = this.sites[road.a].seedN ^ (i * 2654435761); road.cd.push({ name: ['Hauler', 'Carrier', 'Runner', 'Tug'][i & 3] + '-' + (10 + Math.floor(h32(sd, 1, 2, 3) * 89)), phase: h32(sd, 4, 5, 6), speed: 8 + h32(sd, 7, 8, 9) * 5, color: i & 1 ? 'blue' : 'green', toward: i & 1, from: A.name, to: B.name, say: 0, faction: FACTION }); }
    }
    _roadChart(road, face) {   // directions -> chart (x,z) + cumulative ground length, once per face
        if (road.chartFace === face) return true;
        const n = road.pts.length / 3, xs = new Float64Array(n), zs = new Float64Array(n), cum = new Float64Array(n), c = { x: 0, z: 0 }; let ok = true;
        for (let i = 0; i < n; i++) { if (!geoToChart(face, road.pts[i * 3], road.pts[i * 3 + 1], road.pts[i * 3 + 2], c)) { ok = false; c.x = 1e9; c.z = 1e9; } xs[i] = c.x; zs[i] = c.z; }
        for (let i = 1; i < n; i++) cum[i] = cum[i - 1] + Math.hypot(road.pts[i * 3] - road.pts[i * 3 - 3], road.pts[i * 3 + 1] - road.pts[i * 3 - 2], road.pts[i * 3 + 2] - road.pts[i * 3 - 1]) * PLANET_R;
        road.cx = xs; road.cz = zs; road.cum = cum; road.chartFace = face;
        for (const t of road.tiles.values()) { this.root.remove(t.mesh); t.mesh.geometry.dispose(); } road.tiles.clear();
        return ok;
    }
    _updateRoads(dt, P, face, night) {
        if (!this.roadsRequested && this.sites.length > 1 && this.t > 3) this._requestRoads();
        const T = this.THREE; let cargoShown = 0;
        for (const road of this.roads) {
            if (road.state !== 'ready') continue;
            this._roadChart(road, face);
            const n = road.cx.length, TILE = 12;
            // nearest vertex (scan every 0.4 s)
            road._scanT = (road._scanT || 0) - dt;
            if (road._scanT <= 0) { road._scanT = 0.4; let bi = -1, bd = 1e30; for (let i = 0; i < n; i += 2) { const d = (road.cx[i] - P.x) ** 2 + (road.cz[i] - P.z) ** 2; if (d < bd) { bd = d; bi = i; } } road._near = bi; road._nearD = Math.sqrt(bd); }
            if (road._near >= 0 && road._nearD < 3200) {
                const t0 = Math.floor(road._near / TILE);
                for (let ti = Math.max(0, t0 - 4); ti <= Math.min(Math.floor((n - 2) / TILE), t0 + 4); ti++) if (!road.tiles.has(ti)) road.tiles.set(ti, this._makeTile(road, ti, TILE));
            }
            for (const [ti, t] of road.tiles) { const mid = Math.min(n - 1, ti * TILE + TILE / 2); if (Math.hypot(road.cx[mid] - P.x, road.cz[mid] - P.z) > 5200) { this.root.remove(t.mesh); t.mesh.geometry.dispose(); road.tiles.delete(ti); } }
            // cargo drones (only those near the player; deterministic from game time so they are "everywhere along the road" without simulating them)
            if (road._nearD < 2400) {
                const L = road.len, tm = this.ctx.getTime();
                for (const cd of road.cd) {
                    if (cargoShown >= 22) break;
                    const u = ((cd.phase * 2 * L + cd.speed * tm) % (2 * L)), s = u < L ? u : 2 * L - u, fwd = u < L, sg = (cd.toward ? L - s : s);
                    // binary search cumulative length
                    let lo = 0, hi = n - 1; while (hi - lo > 1) { const m = (lo + hi) >> 1; if (road.cum[m] < sg) lo = m; else hi = m; }
                    const f = (sg - road.cum[lo]) / Math.max(1e-6, road.cum[hi] - road.cum[lo]); let x = road.cx[lo] + (road.cx[hi] - road.cx[lo]) * f, z = road.cz[lo] + (road.cz[hi] - road.cz[lo]) * f;
                    const dd = Math.hypot(x - P.x, z - P.z); if (dd > 1800) continue;
                    const lane = ((cd.phase * 7919) % 1 - 0.5) * 9, ln = Math.hypot(road.cx[hi] - road.cx[lo], road.cz[hi] - road.cz[lo]) || 1, ox = -(road.cz[hi] - road.cz[lo]) / ln * lane * (fwd !== !!cd.toward ? 1 : -1), oz = (road.cx[hi] - road.cx[lo]) / ln * lane * (fwd !== !!cd.toward ? 1 : -1);
                    x += ox; z += oz;
                    const y = this.ctx.getGround(x, z) + 3.2 + Math.sin(tm * 2 + cd.phase * 20) * 0.4, dir = (fwd !== !!cd.toward) ? 1 : -1;
                    const yaw = Math.atan2(-(road.cz[hi] - road.cz[lo]) * dir, (road.cx[hi] - road.cx[lo]) * dir);
                    this._pushDrone(x, y, z, yaw, cd.color, true); cargoShown++;
                    if (dd < 14 && !this.uiOpen) { if (!this.hover) this.hover = { kind: 'cargo', cd, dd }; }
                    if (dd < 40) { cd.say -= dt; if (cd.say <= 0) { cd.say = 14 + Math.random() * 10; cd._bub = { text: `Hauling cargo from ${cd.from} to ${cd.to}.`, t: 4 }; } }
                    if (cd._bub) { cd._bub.t -= dt; if (cd._bub.t > 0) this.bubblesToShow.push({ x, y: y + 8, z, text: cd._bub.text, name: cd.name, color: cd.color, t: cd._bub.t }); else cd._bub = null; }
                }
            }
        }
    }
    _cargoSay(cd) { cd._bub = { text: this.ctx.machineDestroyed() ? 'Roads are safer now that the empire is gone. Still, I stay in the valleys.' : 'Cargo for the other city. I cannot stop. Try the markets in town.', t: 5 }; }
    _makeTile(road, ti, TILE) {
        const T = this.THREE, n = road.cx.length, i0 = ti * TILE, i1 = Math.min(n - 1, i0 + TILE), W = 5.5, pos = [], idx = [], getG = this.ctx.getGround;
        let prev = null;
        for (let i = i0; i <= i1; i++) {
            const a = Math.max(0, i - 1), b = Math.min(n - 1, i + 1), dx = road.cx[b] - road.cx[a], dz = road.cz[b] - road.cz[a], l = Math.hypot(dx, dz) || 1, nx = -dz / l, nz = dx / l, x = road.cx[i], z = road.cz[i];
            for (const s of [-1, 1]) { const px = x + nx * W * s, pz = z + nz * W * s; pos.push(px, getG(px, pz) + 0.45, pz); }
            if (prev !== null) { const k = (i - i0) * 2; idx.push(k - 2, k - 1, k, k - 1, k + 1, k); } prev = i;
        }
        const g = new T.BufferGeometry(); g.setAttribute('position', new T.Float32BufferAttribute(pos, 3)); g.setIndex(idx); g.computeVertexNormals();
        const m = new T.Mesh(g, this._roadMat || (this._roadMat = new T.MeshStandardMaterial({ color: 0x8a7d68, roughness: 1, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 })));
        m.frustumCulled = false; m.receiveShadow = true; this.root.add(m); return { mesh: m };
    }
    // v51: the player's chart changed (cube-face handover or teleport): the root must be identity (children carry chart coordinates), every city re-places itself
    onChartChange() {
        this.root.position.set(0, 0, 0); if (this.root.quaternion) this.root.quaternion.set(0, 0, 0, 1); this.root.rotation.set(0, 0, 0); this.root.scale.set(1, 1, 1); this.root.updateMatrixWorld(true);
        for (const r of this.recs.values()) r.face = -1;
        if (this.talking) this.closeUI();
    }
    stateOf(site) { const r = this.recs.get(site.id); return r ? (r.state + (r.err ? ' (' + r.err + ')' : '')) : 'not requested'; }
    // ------------------------------------------------------------------ save / debug
    getState() { return { econ: this.econState }; }
    setState(s) { if (s && s.econ) this.econState = s.econ; for (const r of this.recs.values()) r.econ = this.econState[r.site.id] || (this.econState[r.site.id] = makeEconomy(r.site.seedN)); }
    nearestSite(x, z, face) { return this.valleys.nearest(face, x, z); }
}
