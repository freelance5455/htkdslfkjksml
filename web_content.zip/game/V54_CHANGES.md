# v54 - cities that stand in the weather, end gracefully, and can be touched (NOT run in a browser/GPU; verified headless: tests/test_v54.mjs, test_collide.mjs, test_runtime.mjs + all older tests)

## Root cause found: ~27% of every street ran THROUGH buildings
Lots were only checked against other buildings, never against streets. Measured on 5 cities: 26-30% of street length inside a building, ~25% of buildings sitting on a street.
That is the "roads are random blocks" look, and why drones went inside buildings (they follow those streets). accept() now rejects any lot a street crosses: 0.00% now.

## Streets
- Flat streets are ONE continuous ribbon mesh per city (asphalt/cobble, curbs, centre dashes on main roads, retaining skirts to the real ground, junction pads) instead of a chain of jittered boxes.
- Stairs keep their treads (one colour per flight) and are walkable ramps.

## Fog / rain
City materials (walls, roofs, glow, sky silhouettes, roads, drones) now go through the same wxAttachValleyMist the terrain/trees use: weather height-fog, rain haze, valley mist. Before they only had the linear scene fog (which starts ~1.8 km out in rain), so cities stayed crisp inside rain/fog.
Beacon glow fades with haze. Walls darken a little when wet (uWet).

## Collision (city_collide.js, new)
- Player (walking AND flying, sub-stepped so fast flight cannot tunnel): walls, foundations, hub, gate, wall/towers, bridge decks, piers push you out; you land on roofs, stairs, street surfaces, bridges; you bump your head under a deck.
- ~7-14k oriented boxes per city (solid pieces + street floors + stair ramps + bridge decks + piers), spatial hash.
- Drones: hard push-out from every solid (0 of 15360 samples inside a solid in the 120 s test).
- Hook: game.js updatePlayer -> CITIES.collidePlayer after the move.

## Floating / buried buildings
- 5x5 footprint sampling (+margin), foundations always present and 6-16 units deeper (the far terrain LODs are coarse), piers for edge buildings on drops.
- Runtime ground-fit: ~150 probe points compare generator ground with the real getGround; a systematic offset moves the whole city (r.fitMed in debug).
- If buildings still float at some distance, the cause is the coarse terrain LOD mesh; send a screenshot + distance.

## City edges (per-sector, random per city, can mix): sprawl (outer spurs + thinning shacks) / curtain wall with towers and gate gaps / stilts + rope-bridge lookouts / terraced farmland / ruins.
Lots thin out smoothly past 90% of the outline; heights fall to 1-5 floors.

## "Feels small"
- Walls/foundations now draw out to 34 km (before: 13 km, then only a few spikes) so a city keeps its whole mass from far away.
- Taller skyline: hub 300-520, mega stacks 28-52 floors, towers up to 40.
- Wall shader: darker street-level base fading up (depth cue), plus the fog above for atmospheric depth.
- Edge sprawl widens the footprint.
- If it still feels small when flying, that's speed vs size: tell me your fly speed and I'll scale city radii.

## Files: city_collide.js (new), city_core.js, city_runtime.js, city_sim.js, chunk_core.js, game.js (3 small hooks), tests/test_v54.mjs, tests/test_collide.mjs, tests/test_runtime.mjs (stub).
Saved games: city layouts change (economy state still loads).
