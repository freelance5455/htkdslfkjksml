// ink_intro.js - v115: the new-game "ink" cinematic (replaces the old look-around wake-up).
//
// Total darkness. One thin blue line begins to draw - the AI's first faint pulse - and sketches the real view
// the player is about to wake into (shoreline, waves, horizon) like ink on paper. Then colour washes in, stroke by
// stroke, and the painting resolves into the live beach view and hands off to the game.
//
// How it works (all on a 2D canvas laid over the live game, nothing here touches WebGL):
//   1. cover()   - an opaque white canvas continues the loader's white-out, then fades to black.
//   2. run()     - the game renders its real first view behind the overlay; requestCapture() hands us that frame.
//   3. analysis  - edge detection (blur -> Sobel -> thinning -> hysteresis), then every edge pixel gets a "draw time"
//                  from a breadth-first walk along the edges starting at the END of the longest contour, so the first
//                  thing you see is one thin line growing, which then branches out into the whole drawing. Runs in
//                  small slices across frames so nothing stutters (the screen is black while it works anyway).
//   4. ink       - pixels appear in walk order; the newest ones are bright, older ones settle to blue; soft glow.
//   5. colour    - big dry-brush strokes (bristles, ragged ends) reveal a softened copy of the frame, starting at the
//                  horizon and working up and down; then smaller strokes reveal the sharp copy.
//   6. resolve   - the canvas dissolves to the live game and onDone() fires.
// Tap / click / any key skips it. If anything goes wrong it fades out and hands off anyway - it can never trap the player.

export const INK_CFG = {
    FADE: 1.5,            // white -> black
    CAPTURE_AT: 0.5,      // when (s) the real frame is requested
    MIN_DARK: 2.0,        // earliest the first pulse can appear
    INK_START: 1.0,       // (all below are seconds after the first pulse, T)
    INK_END: 7.2,
    COL_START: 4.4,
    ROW_SPAN: 3.2,
    DETAIL_START: 6.4,
    DETAIL_END: 9.2,
    WASH_START: 8.6,
    RES_START: 9.8,
    RES_END: 11.9,
    LINE_COLOR: [88, 164, 255],
    FAILSAFE_S: 45,
    SKIP_ARM_S: 1.0,
    DRIFT: 0.035,         // the painting starts this much zoomed in and settles to 1.0 by the dissolve (so it lands exactly on the live view)
    GRAIN: 0.17,          // paper grain strength on the painted areas (fades out before the dissolve)
    CONTOUR_STROKES: 46,  // detail strokes that follow the real edges
    DABS: 260,            // small oil-paint dabs (painted from the stylised copy), laid horizon-outward
    TINT: 0.34,           // dreamy lavender/rose tint baked into the underpainting and dabs (the final wash is the true frame)
    BLOOM: 0.2,          // soft glow around the painting while it is wet
    MOTES: 1,             // drifting light motes (0 = off)
};
function sprite(rgb) {
    const c = document.createElement('canvas'); c.width = c.height = 32; const g = c.getContext('2d');
    const gr = g.createRadialGradient(16, 16, 0, 16, 16, 16);
    gr.addColorStop(0, `rgba(${rgb},1)`); gr.addColorStop(0.25, `rgba(${rgb},0.55)`); gr.addColorStop(1, `rgba(${rgb},0)`);
    g.fillStyle = gr; g.fillRect(0, 0, 32, 32); return c;
}

function mulberry32(a) { return function () { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
const clamp01 = x => x < 0 ? 0 : x > 1 ? 1 : x;
const smooth = x => { x = clamp01(x); return x * x * (3 - 2 * x); };

export class InkIntro {
    constructor(cfg) {
        this.cfg = Object.assign({}, INK_CFG, cfg || {});
        this.rng = mulberry32((Date.now() ^ 0x9e3779b9) >>> 0);
        this.state = 'idle';
        this.t = 0; this.T = -1;
        this.done = false;
        this.raf = 0;
        this.manual = false;
    }

    // ---- 1. overlay ------------------------------------------------------------------------------------------
    cover() {
        if (this.root) return;
        const root = document.createElement('div');
        root.id = 'inkIntro';
        root.style.cssText = 'position:fixed;left:0;top:0;width:100%;height:100%;z-index:99999;pointer-events:none;background:transparent;cursor:none;overflow:hidden;';
        const cv = document.createElement('canvas');
        cv.width = 480; cv.height = 270;
        cv.style.cssText = 'position:absolute;left:0;top:0;width:100%;height:100%;display:block;';
        root.appendChild(cv);
        const hint = document.createElement('div');
        hint.textContent = 'tap to skip';
        hint.style.cssText = 'position:absolute;left:0;right:0;bottom:max(18px,env(safe-area-inset-bottom));text-align:center;font:12px/1 system-ui,sans-serif;letter-spacing:.18em;text-transform:uppercase;color:rgba(150,190,255,.0);transition:color 1.2s;';
        root.appendChild(hint);
        document.body.appendChild(root);
        this.root = root; this.cv = cv; this.dc = cv.getContext('2d'); this.hint = hint;
        this.dc.fillStyle = '#f3fff5'; this.dc.fillRect(0, 0, cv.width, cv.height);   // same white as the loader's flash
    }

    // ---- 2. lifecycle ----------------------------------------------------------------------------------------
    // opts: { audio: {ctx, out, reverb}|null, requestCapture(fn(srcCanvas)), onDone(), manual?: bool }
    run(opts) {
        this.cover();
        this.opts = opts; this.audio = opts.audio || null; this.manual = !!opts.manual;
        this.state = 'fade'; this.t = 0; this.T = -1;
        this.captureRequested = false; this.frame = null; this.gen = null; this.fx = null; this.genDone = false;
        this.wallStart = performance.now(); this.last = this.wallStart;
        this._onSkip = (e) => { if (e && e.type === 'keydown' && (e.key === 'Tab' || e.key === 'Shift' || e.key === 'Control' || e.key === 'Alt' || e.key === 'Meta')) return; this.skip(); };
        for (const ev of ['pointerdown', 'keydown', 'touchstart']) window.addEventListener(ev, this._onSkip, true);
        this._loop = (now) => {
            if (this.done) return;
            const dt = Math.min(0.1, Math.max(0, (now - this.last) / 1000)); this.last = now;
            try { this.step(dt); } catch (err) { console.error('[ink intro] failed, handing off', err); this._finish(); return; }
            if (!this.done) this.raf = requestAnimationFrame(this._loop);
        };
        if (!this.manual) this.raf = requestAnimationFrame(this._loop);
    }

    skip() {
        if (this.done || this.skipped || this.t < this.cfg.SKIP_ARM_S) return;
        this.skipped = true;
        if (this.state === 'show' && this.T < this.cfg.RES_START - 0.2) { this.speed = 5; }
        else if (this.state !== 'show' && this.state !== 'out') { this._beginOut(0.5); }
    }

    _beginOut(dur) { this.state = 'out'; this.outT = 0; this.outDur = dur; this.outFrom = this.root ? parseFloat(this.root.style.opacity || '1') : 1; }

    _finish() {
        if (this.done) return; this.done = true;
        cancelAnimationFrame(this.raf);
        for (const ev of ['pointerdown', 'keydown', 'touchstart']) window.removeEventListener(ev, this._onSkip, true);
        this._audioStop();
        if (this.root && this.root.parentNode) this.root.parentNode.removeChild(this.root);
        const cb = this.opts && this.opts.onDone; if (cb) { try { cb(); } catch (e) { console.error(e); } }
    }

    // ---- 3. per-frame driver ---------------------------------------------------------------------------------
    step(dt) {
        if (this.done) return;
        const C = this.cfg;
        if ((performance.now() - this.wallStart) / 1000 > C.FAILSAFE_S) { this._finish(); return; }
        this.t += dt;
        if (this.state === 'fade') {
            const k = smooth(this.t / C.FADE), w = 243 * (1 - k);
            this.dc.fillStyle = `rgb(${w | 0},${(255 * (1 - k)) | 0},${(245 * (1 - k)) | 0})`;
            this.dc.fillRect(0, 0, this.cv.width, this.cv.height);
            if (!this.captureRequested && this.t >= C.CAPTURE_AT) {
                this.captureRequested = true;
                this.opts.requestCapture((src) => this._onCapture(src));
            }
            if (this.t >= C.FADE && this.frame) this.state = 'proc';
            if (this.t > 6 && !this.frame) { this._beginOut(0.6); }
        }
        if (this.state === 'proc') {
            if (!this.gen) this.gen = this._analyze(this.frame);
            if (!this.genDone) {
                const t0 = performance.now();
                while (performance.now() - t0 < 9) {
                    const r = this.gen.next();
                    if (r.done) { this.genDone = true; this.fx = r.value; break; }
                }
            }
            if (this.genDone) {
                // fx === null means the generator found "not enough edges" (a flat frame): fade out and hand off.
                if (!this.fx) this._beginOut(0.6);
                else if (this.t >= C.MIN_DARK) this._startShow();
            }
        }
        if (this.state === 'show') {
            const sp = this.speed || 1;
            this.T += dt * sp;
            this._renderShow(dt * sp);
            if (this.T >= C.RES_END) this._finish();
        }
        if (this.state === 'out') {
            this.outT += dt;
            const k = smooth(this.outT / this.outDur);
            this.root.style.opacity = String(this.outFrom * (1 - k));
            if (this.outT >= this.outDur) this._finish();
        }
    }

    _onCapture(src) {
        try {
            const sw = src.width, sh = src.height;
            const long = 960, sc = long / Math.max(sw, sh);
            const W = Math.max(64, Math.round(sw * Math.min(1, sc))), H = Math.max(64, Math.round(sh * Math.min(1, sc)));
            const f = document.createElement('canvas'); f.width = W; f.height = H;
            const fx = f.getContext('2d', { willReadFrequently: true });
            fx.imageSmoothingQuality = 'high';
            fx.drawImage(src, 0, 0, W, H);
            this.frame = f;
        } catch (e) { console.error('[ink intro] capture failed', e); this.frame = null; }
    }

    // ---- 4. analysis (generator: yields between slices) --------------------------------------------------------
    *_analyze(frame) {
        const W = frame.width, H = frame.height, N = W * H;
        const d = frame.getContext('2d', { willReadFrequently: true }).getImageData(0, 0, W, H).data;
        const ch = [new Float32Array(N), new Float32Array(N), new Float32Array(N)];
        for (let i = 0, j = 0; i < N; i++, j += 4) { ch[0][i] = d[j]; ch[1][i] = d[j + 1]; ch[2][i] = d[j + 2]; }
        yield;
        const tmp = new Float32Array(N);
        const box = (a) => {
            for (let y = 0; y < H; y++) { const o = y * W; for (let x = 0; x < W; x++) { const l = x > 0 ? a[o + x - 1] : a[o + x], r = x < W - 1 ? a[o + x + 1] : a[o + x]; tmp[o + x] = (l + a[o + x] + r) / 3; } }
            for (let y = 0; y < H; y++) { const o = y * W, u = y > 0 ? o - W : o, dn = y < H - 1 ? o + W : o; for (let x = 0; x < W; x++) a[o + x] = (tmp[u + x] + tmp[o + x] + tmp[dn + x]) / 3; }
        };
        for (let c = 0; c < 3; c++) { box(ch[c]); box(ch[c]); yield; }
        // Sobel on all three channels: magnitude from the sum of squares, direction from the signed sums.
        const mag = new Float32Array(N), dir = new Uint8Array(N);
        for (let y = 2; y < H - 2; y++) {
            for (let x = 2; x < W - 2; x++) {
                const i = y * W + x; let sx = 0, sy = 0, sq = 0;
                for (let c = 0; c < 3; c++) {
                    const a = ch[c];
                    const gx = (a[i - W + 1] + 2 * a[i + 1] + a[i + W + 1]) - (a[i - W - 1] + 2 * a[i - 1] + a[i + W - 1]);
                    const gy = (a[i + W - 1] + 2 * a[i + W] + a[i + W + 1]) - (a[i - W - 1] + 2 * a[i - W] + a[i - W + 1]);
                    sx += gx; sy += gy; sq += gx * gx + gy * gy;
                }
                mag[i] = Math.sqrt(sq);
                const ax = Math.abs(sx), ay = Math.abs(sy);
                dir[i] = ay < ax * 0.4142 ? 0 : ay > ax * 2.4142 ? 2 : (sx * sy > 0 ? 1 : 3);
            }
            if ((y & 63) === 0) yield;
        }
        // Thresholds from the magnitude histogram.
        let mx = 1; for (let i = 0; i < N; i++) if (mag[i] > mx) mx = mag[i];
        const hist = new Uint32Array(512);
        for (let i = 0; i < N; i++) hist[Math.min(511, (mag[i] / mx * 511) | 0)]++;
        let acc = 0, hb = 511; const target = N * 0.945;
        for (let b = 0; b < 512; b++) { acc += hist[b]; if (acc >= target) { hb = b; break; } }
        const high = Math.max(8, (hb + 1) / 511 * mx), low = high * 0.5;
        yield;
        // Non-maximum suppression -> thin lines.
        const cand = new Uint8Array(N);
        const off = [[1, -1, 1, -1], [W + 1, -(W + 1), 0, 0], [W, -W, 0, 0], [W - 1, -(W - 1), 0, 0]];
        for (let y = 2; y < H - 2; y++) {
            for (let x = 2; x < W - 2; x++) {
                const i = y * W + x, m = mag[i]; if (m < low) continue;
                const dd = dir[i];
                let a, b;
                if (dd === 0) { a = mag[i + 1]; b = mag[i - 1]; }
                else if (dd === 1) { a = mag[i + W + 1]; b = mag[i - W - 1]; }
                else if (dd === 2) { a = mag[i + W]; b = mag[i - W]; }
                else { a = mag[i + W - 1]; b = mag[i - W + 1]; }
                if (m >= a && m >= b) cand[i] = m >= high ? 2 : 1;
            }
            if ((y & 127) === 0) yield;
        }
        // Hysteresis: keep weak edges only if they touch a strong one.
        const keep = new Uint8Array(N), stack = new Int32Array(N);
        let sp = 0;
        for (let i = 0; i < N; i++) if (cand[i] === 2) { keep[i] = 1; stack[sp++] = i; }
        while (sp > 0) {
            const p = stack[--sp];
            for (let k = 0; k < 8; k++) {
                const q = p + (k === 0 ? -W - 1 : k === 1 ? -W : k === 2 ? -W + 1 : k === 3 ? -1 : k === 4 ? 1 : k === 5 ? W - 1 : k === 6 ? W : W + 1);
                if (q >= 0 && q < N && cand[q] === 1 && !keep[q]) { keep[q] = 1; stack[sp++] = q; }
            }
        }
        yield;
        let K = 0; for (let i = 0; i < N; i++) if (keep[i]) K++;
        if (K < 60) return null;
        // Components (linking across gaps of up to 2 px), BFS hop distance from a start pixel.
        const out = new Int32Array(K), lab = new Int32Array(N).fill(-1), dist = new Int32Array(N);
        const comps = [];
        let pos = 0;
        const NB = []; for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) if (dx || dy) NB.push([dx, dy]);
        const bfs = (startPix, mark, base, stampArr, stampVal) => {
            let head = base, tail = base;
            out[tail++] = startPix; stampArr[startPix] = stampVal; dist[startPix] = 0;
            while (head < tail) {
                const p = out[head++], px = p % W, py = (p / W) | 0, dp = dist[p] + 1;
                for (let k = 0; k < NB.length; k++) {
                    const nx = px + NB[k][0], ny = py + NB[k][1];
                    if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
                    const q = ny * W + nx;
                    if (keep[q] && stampArr[q] !== stampVal && (mark === null || lab[q] === mark)) { stampArr[q] = stampVal; dist[q] = dp; out[tail++] = q; }
                }
            }
            return tail;
        };
        let scanned = 0;
        for (let i = 0; i < N; i++) {
            if (!keep[i] || lab[i] >= 0) continue;
            const id = comps.length, base = pos;
            const end = bfs(i, null, base, lab, id);
            comps.push({ id, base, size: end - base, far: out[end - 1], first: i });
            pos = end;
            if ((++scanned & 15) === 0) yield;
        }
        yield;
        // Large components: re-walk from the far END so the line is drawn tip-to-tip instead of from the middle.
        const mark2 = new Int32Array(N).fill(-1);
        const dist1 = dist;   // single dist array: the second walk simply overwrites it within the component
        for (const c of comps) {
            if (c.size < 300) continue;
            const tmpOut = out.slice(c.base, c.base + c.size);
            // second BFS writes into the same out segment (same set of pixels, new order)
            let head = c.base, tail = c.base;
            out[tail++] = c.far; mark2[c.far] = c.id; dist[c.far] = 0;
            while (head < tail) {
                const p = out[head++], px = p % W, py = (p / W) | 0, dp = dist[p] + 1;
                for (let k = 0; k < NB.length; k++) {
                    const nx = px + NB[k][0], ny = py + NB[k][1];
                    if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
                    const q = ny * W + nx;
                    if (keep[q] && lab[q] === c.id && mark2[q] !== c.id) { mark2[q] = c.id; dist[q] = dp; out[tail++] = q; }
                }
            }
            c.first = c.far;
            yield;
        }
        // Order components by size; drop dust; cap the total so the drawing stays a drawing.
        const sorted = comps.filter(c => c.size >= 18).sort((a, b) => b.size - a.size);
        if (!sorted.length) return null;
        const cap = Math.round(N * 0.05);
        const used = []; let tot = 0;
        for (const c of sorted) { if (tot + c.size > cap && used.length) continue; used.push(c); tot += c.size; }
        // Per-contour stats: where it sits and how horizontal it is. The horizon / shoreline (long and flat) is drawn first,
        // then contours nearest to it, then the rest outward; faint detail edges are delayed so the foreground fills in last.
        const stats = (c) => {
            let sx = 0, sy = 0, x0 = W, x1 = 0, y0 = H, y1 = 0;
            for (let j = 0; j < c.size; j++) { const p = out[c.base + j], x = p % W, y = (p / W) | 0; sx += x; sy += y; if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
            c.cx = sx / c.size; c.cy = sy / c.size; c.bw = x1 - x0 + 1; c.bh = y1 - y0 + 1; c.hz = c.bw / (c.bw + c.bh);
        };
        for (const c of used) stats(c);
        let main = used[0];
        for (let k = 1; k < Math.min(4, used.length); k++) if (used[k].size * (0.5 + used[k].hz) > main.size * (0.5 + main.hz)) main = used[k];
        let Dm = 1; for (let j = 0; j < main.size; j++) Dm = Math.max(Dm, dist[out[main.base + j]]);
        const mainY = main.cy;
        const restC = used.filter(c => c !== main);
        for (const c of restC) c.pr = 0.55 * Math.min(1, Math.abs(c.cy - mainY) / (H * 0.5)) + 0.45 * (1 - Math.min(1, c.size / main.size)) - 0.12 * c.hz;
        restC.sort((a, b) => a.pr - b.pr);
        used.length = 0; used.push(main, ...restC);
        // direction of the main contour (principal axis), used to tilt the colour washes with the horizon
        let mxx = 0, mxy = 0, myy = 0;
        for (let j = 0; j < main.size; j++) { const p = out[main.base + j], dx = (p % W) - main.cx, dy = ((p / W) | 0) - main.cy; mxx += dx * dx; mxy += dx * dy; myy += dy * dy; }
        let angle = 0.5 * Math.atan2(2 * mxy, mxx - myy);
        if (main.hz < 0.6 || Math.abs(angle) > 0.5) angle = 0;
        const n = used.length;
        const P = tot, pix = new Int32Array(P), keyArr = new Float32Array(P), tier = new Uint8Array(P), edge = new Uint8Array(N);
        let w = 0, sumY = 0;
        used.forEach((c, r) => {
            const offset = r === 0 ? 0 : Dm * 0.08 + ((r - 1) / Math.max(1, n - 1)) * Dm * 0.9;
            for (let j = 0; j < c.size; j++) {
                const p = out[c.base + j];
                const m = mag[p] / high, tr = m < 1.0 ? 0 : m < 1.8 ? 1 : 2;
                pix[w] = p; keyArr[w] = offset + dist[p] + this.rng() * 0.6 + (tr === 0 ? Dm * 0.05 : 0); tier[w] = tr; edge[p] = 1;
                if (r === 0) sumY += (p / W) | 0;
                w++;
            }
        });
        yield;
        const pack = new Float64Array(P);
        for (let i = 0; i < P; i++) pack[i] = Math.round(keyArr[i] * 8) * 2097152 + i;
        pack.sort();
        const order = new Int32Array(P), keys = new Float32Array(P), tiers = new Uint8Array(P);
        for (let i = 0; i < P; i++) {
            const idx = pack[i] % 2097152; order[i] = pix[idx]; keys[i] = keyArr[idx]; tiers[i] = tier[idx];
        }
        const Kmax = keys[P - 1] + 1;
        const seedP = order[0];
        const rowY = Math.min(H * 0.72, Math.max(H * 0.28, sumY / Math.max(1, main.size)));
        yield;
        // Painterly copy: a generalised Kuwahara filter (each pixel takes the mean of the calmest of its four neighbouring
        // quadrants) on a half-size copy, via integral images. Flat oil-paint patches with kept edges; the upscale softens it further.
        const hw = W >> 1, hh = H >> 1, scv = document.createElement('canvas'); scv.width = hw; scv.height = hh;
        const scx = scv.getContext('2d', { willReadFrequently: true }); scx.imageSmoothingQuality = 'high'; scx.drawImage(frame, 0, 0, hw, hh);
        const px = scx.getImageData(0, 0, hw, hh).data, S = hw + 1, SZ = S * (hh + 1);
        const iR = new Float64Array(SZ), iG = new Float64Array(SZ), iB = new Float64Array(SZ), iL = new Float64Array(SZ), iQ = new Float64Array(SZ);
        for (let y = 0; y < hh; y++) {
            let rr = 0, gg = 0, bb = 0, ll = 0, qq = 0;
            for (let x = 0; x < hw; x++) {
                const j = (y * hw + x) * 4, r = px[j], g = px[j + 1], b = px[j + 2], l = 0.299 * r + 0.587 * g + 0.114 * b;
                rr += r; gg += g; bb += b; ll += l; qq += l * l;
                const k = (y + 1) * S + x + 1, u = y * S + x + 1;
                iR[k] = iR[u] + rr; iG[k] = iG[u] + gg; iB[k] = iB[u] + bb; iL[k] = iL[u] + ll; iQ[k] = iQ[u] + qq;
            }
            if ((y & 31) === 31) yield;
        }
        const bx = (a, x0, y0, x1, y1) => a[(y1 + 1) * S + x1 + 1] - a[y0 * S + x1 + 1] - a[(y1 + 1) * S + x0] + a[y0 * S + x0];
        const KR = 3, styl = new Uint8ClampedArray(hw * hh * 4);
        for (let y = 0; y < hh; y++) {
            for (let x = 0; x < hw; x++) {
                let best = 1e30, mr = 0, mg = 0, mb = 0;
                for (let q = 0; q < 4; q++) {
                    const x0 = Math.max(0, q & 1 ? x : x - KR), x1 = Math.min(hw - 1, q & 1 ? x + KR : x), y0 = Math.max(0, q & 2 ? y : y - KR), y1 = Math.min(hh - 1, q & 2 ? y + KR : y);
                    const cnt = (x1 - x0 + 1) * (y1 - y0 + 1), mL = bx(iL, x0, y0, x1, y1) / cnt, v = bx(iQ, x0, y0, x1, y1) / cnt - mL * mL;
                    if (v < best) { best = v; mr = bx(iR, x0, y0, x1, y1) / cnt; mg = bx(iG, x0, y0, x1, y1) / cnt; mb = bx(iB, x0, y0, x1, y1) / cnt; }
                }
                const j = (y * hw + x) * 4; styl[j] = mr; styl[j + 1] = mg; styl[j + 2] = mb; styl[j + 3] = 255;
            }
            if ((y & 15) === 15) yield;
        }
        return { W, H, P, order, keys, tiers, edge, angle, styl, hw, hh, Kmax, seed: { x: seedP % W, y: (seedP / W) | 0 }, rowY, mainSize: main.size, comps: n };
    }

    // ---- 5. the show -----------------------------------------------------------------------------------------
    _startShow() {
        const fx = this.fx, W = fx.W, H = fx.H, C = this.cfg;
        this.state = 'show'; this.T = 0; this.speed = this.skipped ? 5 : 1;
        this.cv.width = W; this.cv.height = H;
        const mk = (w, h) => { const c = document.createElement('canvas'); c.width = Math.max(2, w | 0); c.height = Math.max(2, h | 0); return [c, c.getContext('2d')]; };
        [this.trail, this.tctx] = mk(W, H);
        [this.heads, this.hctx] = mk(W, H);
        [this.paint, this.pctx] = mk(W, H);
        [this.g2, this.g2c] = mk(W / 2, H / 2); [this.g4, this.g4c] = mk(W / 4, H / 4); [this.g8, this.g8c] = mk(W / 8, H / 8);
        // Soft "underpainting": the frame downsampled hard and scaled back up, lifted and a little saturated, then tinted dreamy.
        [this.under, this.uctx] = mk(W, H);
        const [sm, smc] = mk(W / 9, H / 9);
        smc.imageSmoothingQuality = 'high'; smc.drawImage(this.frame, 0, 0, sm.width, sm.height);
        this.uctx.imageSmoothingEnabled = true; this.uctx.imageSmoothingQuality = 'high';
        try { if ('filter' in this.uctx) this.uctx.filter = 'saturate(1.2) contrast(1.04) brightness(1.05)'; } catch (e) { }
        this.uctx.drawImage(sm, 0, 0, W, H);
        try { this.uctx.filter = 'none'; } catch (e) { }
        // Oil-painted copy (from the analysis) for the dabs
        [this.styl, this.sctx] = mk(W, H);
        { const [hc, hx] = mk(fx.hw, fx.hh); hx.putImageData(new ImageData(fx.styl, fx.hw, fx.hh), 0, 0);
          this.sctx.imageSmoothingEnabled = true; this.sctx.imageSmoothingQuality = 'high';
          try { if ('filter' in this.sctx) this.sctx.filter = 'saturate(1.18) contrast(1.06)'; } catch (e) { }
          this.sctx.drawImage(hc, 0, 0, W, H); try { this.sctx.filter = 'none'; } catch (e) { } }
        const tint = (ctx, a) => {
            ctx.globalCompositeOperation = 'soft-light'; ctx.fillStyle = `rgba(150,160,255,${a})`; ctx.fillRect(0, 0, W, H);
            ctx.globalCompositeOperation = 'screen'; ctx.fillStyle = `rgba(255,205,235,${(a * 0.1).toFixed(3)})`; ctx.fillRect(0, 0, W, H);
            ctx.globalCompositeOperation = 'source-over';
        };
        if (C.TINT > 0) { tint(this.uctx, C.TINT); tint(this.sctx, C.TINT * 0.6); }
        this.patUnder = this.pctx.createPattern(this.under, 'no-repeat');
        this.patStyl = this.pctx.createPattern(this.styl, 'no-repeat');
        this.patSharp = this.pctx.createPattern(this.frame, 'no-repeat');
        // paper grain: a small tile of near-white noise, multiplied over the painted areas only (multiply leaves black alone)
        try {
            const g = document.createElement('canvas'); g.width = g.height = 128; const gx = g.getContext('2d'), id = gx.createImageData(128, 128);
            for (let i = 0; i < 128 * 128; i++) { const gx0 = i & 127, gy0 = i >> 7, v = Math.max(150, Math.min(255, 206 + Math.floor(this.rng() * 40) + 9 * Math.sin(gx0 * 0.7854) * Math.sin(gy0 * 0.7854))); id.data[i * 4] = v; id.data[i * 4 + 1] = v; id.data[i * 4 + 2] = v - 5; id.data[i * 4 + 3] = 255; }
            gx.putImageData(id, 0, 0); this.patGrain = this.dc.createPattern(g, 'repeat');
        } catch (e) { this.patGrain = null; }
        [this.pb4, this.pb4c] = mk(W / 4, H / 4); [this.pb8, this.pb8c] = mk(W / 8, H / 8);
        this.sprB = sprite('170,215,255'); this.sprG = sprite('255,226,170'); this.motes = [];
        this.ptr = 0; this.lastTier = -1; this.pxPerSec = 0;
        this.tctx.fillStyle = '#58a4ff';
        this.tierStyle = ['rgba(88,164,255,0.55)', 'rgba(96,172,255,0.82)', 'rgba(150,205,255,1)'];
        this._buildStrokes();
        this.fired = {};
        this._audioStartPen();
        if (this.hint) { this.hint.style.color = 'rgba(150,190,255,.38)'; setTimeout(() => { if (this.hint) this.hint.style.color = 'rgba(150,190,255,0)'; }, 4200); }
    }

    _buildStrokes() {
        const fx = this.fx, W = fx.W, H = fx.H, C = this.cfg, R = this.rng;
        const strokes = [];
        const mkStroke = (pts, thick, nb, ts, dur, pat) => {
            const n = pts.length - 1, nx = [], ny = [];
            for (let i = 0; i <= n; i++) {
                const a = pts[Math.max(0, i - 1)], b = pts[Math.min(n, i + 1)];
                let tx = b[0] - a[0], ty = b[1] - a[1]; const l = Math.hypot(tx, ty) || 1;
                nx.push(-ty / l); ny.push(tx / l);
            }
            const bristles = [];
            for (let j = 0; j < nb; j++) {
                const off = ((j + 0.5) / nb - 0.5) * thick * (0.95 + R() * 0.12);
                const u0 = R() * 0.07, u1 = 1 - R() * R() * 0.14;
                bristles.push({ off, w: thick / nb * 1.75, u0, u1 });
            }
            return { pts, nx, ny, n, thick, bristles, ts, dur, pat, u: 0 };
        };
        // Pass 1: wide horizontal washes of the soft underpainting, from the horizon outward, alternating up/down.
        const tilt = Math.tan(fx.angle || 0), thick = H * (0.085 + R() * 0.02), spacing = thick * 0.52;
        const rows = [0]; for (let k = 1; k * spacing < H * 0.8 + thick; k++) { rows.push(k, -k); }
        const rowList = rows.map(k => fx.rowY + k * spacing).filter(y => y > -thick && y < H + thick);
        const gap = Math.min(0.3, Math.max(0.07, C.ROW_SPAN / Math.max(1, rowList.length - 1)));
        rowList.forEach((y0, idx) => {
            const dir = idx % 2 ? 1 : -1, pts = [], A = thick * (0.12 + R() * 0.16), f = 0.5 + R() * 0.9, ph = R() * 6.28;
            for (let i = 0; i <= 32; i++) {
                const u = i / 32, x = dir > 0 ? -0.06 * W + u * 1.12 * W : 1.06 * W - u * 1.12 * W;
                pts.push([x, y0 + (x - W * 0.5) * tilt + A * Math.sin(u * 6.283 * f + ph)]);
            }
            strokes.push(mkStroke(pts, thick * (0.9 + R() * 0.25), 9, C.COL_START + idx * gap + R() * 0.06, 0.8 + R() * 0.35, this.patUnder));
        });
        // Pass 1b: small oil dabs from the painted copy, laid horizon-outward so the picture builds up from the middle.
        for (let s = 0; s < C.DABS; s++) {
            const x = R() * W, y = R() * H, th = H * (0.018 + R() * 0.03), len = W * (0.035 + R() * 0.07);
            const a = (R() < 0.8 ? (R() - 0.5) * 1.0 : 1.2 + R() * 0.5) + (fx.angle || 0), kap = (R() - 0.5) * 0.8, pts = [];
            for (let i = 0; i <= 8; i++) { const u = i / 8 - 0.5, aa = a + kap * u; pts.push([x + Math.cos(aa) * len * u, y + Math.sin(aa) * len * u]); }
            const ts = C.COL_START + 0.8 + Math.min(1, Math.abs(y - fx.rowY) / (H * 0.6)) * (C.DETAIL_END - C.COL_START - 1.9) + R() * 0.3;
            strokes.push(mkStroke(pts, th, 5, ts, 0.25 + R() * 0.3, this.patStyl));
        }
        // Pass 2: strokes that follow the real edges (traced along the contour tangent), started in the order the ink was drawn,
        // so the sharp detail repaints horizon-first just like the line work did.
        const nd = C.CONTOUR_STROKES, idxs = [];
        for (let s = 0; s < nd; s++) idxs.push(Math.floor(fx.P * Math.min(0.999, (s + R()) / nd)));
        idxs.sort((a, b) => a - b);
        idxs.forEach((ix, s) => {
            const pp = fx.order[ix], sx = pp % W, sy = (pp / W) | 0;
            const th = H * (0.03 + R() * 0.03);
            let pts = this._traceContour(sx, sy, 11, Math.max(5, W * 0.011));
            if (!pts) { const a = (R() - 0.5) * 0.7, len = W * 0.14; pts = []; for (let i = 0; i <= 8; i++) { const u = i / 8 - 0.5; pts.push([sx + Math.cos(a) * len * u, sy + Math.sin(a) * len * u]); } }
            const ts = C.DETAIL_START + (s / nd) * (C.DETAIL_END - C.DETAIL_START - 0.5) + R() * 0.15;
            strokes.push(mkStroke(pts, th, 6, ts, 0.35 + R() * 0.25, this.patSharp));
        });
        strokes.sort((a, b) => a.ts - b.ts);
        this.strokes = strokes;
    }

    // Local edge direction (angle mod pi) and centre of the drawn edge pixels around (x, y), or null if there is no line there.
    _edgeLocal(x, y, r) {
        const fx = this.fx, W = fx.W, H = fx.H, e = fx.edge;
        let n = 0, sx = 0, sy = 0;
        const x0 = Math.max(0, Math.round(x) - r), x1 = Math.min(W - 1, Math.round(x) + r), y0 = Math.max(0, Math.round(y) - r), y1 = Math.min(H - 1, Math.round(y) + r);
        for (let yy = y0; yy <= y1; yy++) for (let xx = x0; xx <= x1; xx++) if (e[yy * W + xx]) { n++; sx += xx; sy += yy; }
        if (n < 6) return null;
        const cx = sx / n, cy = sy / n; let a = 0, b = 0, c = 0;
        for (let yy = y0; yy <= y1; yy++) for (let xx = x0; xx <= x1; xx++) if (e[yy * W + xx]) { const dx = xx - cx, dy = yy - cy; a += dx * dx; b += dx * dy; c += dy * dy; }
        return { ang: 0.5 * Math.atan2(2 * b, a - c), cx, cy };
    }
    // Walks both ways along the contour from (sx, sy) and returns the polyline (null when the line is too short or too broken).
    _traceContour(sx, sy, stepsEach, step) {
        const r = Math.max(5, Math.round(this.fx.W / 110)), first = this._edgeLocal(sx, sy, r);
        if (!first) return null;
        const walk = (head0) => {
            const pts = []; let x = sx, y = sy, h = head0;
            for (let i = 0; i < stepsEach; i++) {
                const t = this._edgeLocal(x, y, r); if (!t) break;
                let a = t.ang; if (Math.cos(a - h) < 0) a += Math.PI;
                h = h + Math.atan2(Math.sin(a - h), Math.cos(a - h)) * 0.6;   // gentle turning keeps the stroke smooth
                x += Math.cos(h) * step + (t.cx - x) * 0.25; y += Math.sin(h) * step + (t.cy - y) * 0.25;
                if (x < 0 || y < 0 || x >= this.fx.W || y >= this.fx.H) break;
                pts.push([x, y]);
            }
            return pts;
        };
        const fwd = walk(first.ang), back = walk(first.ang + Math.PI).reverse();
        const pts = back.concat([[sx, sy]], fwd);
        return pts.length >= 5 ? pts : null;
    }

    _strokePoint(s, u, off) {
        const f = clamp01(u) * s.n, i = Math.min(s.n - 1, Math.floor(f)), t = f - i;
        const x = s.pts[i][0] + (s.pts[i + 1][0] - s.pts[i][0]) * t, y = s.pts[i][1] + (s.pts[i + 1][1] - s.pts[i][1]) * t;
        const nx = s.nx[i] + (s.nx[i + 1] - s.nx[i]) * t, ny = s.ny[i] + (s.ny[i + 1] - s.ny[i]) * t;
        return [x + nx * off, y + ny * off];
    }

    _advanceStrokes(T) {
        const pc = this.pctx; pc.lineCap = 'round'; pc.lineJoin = 'round';
        for (const s of this.strokes) {
            if (s.ts > T) break;
            if (s.u >= 1) continue;
            const uB = smooth((T - s.ts) / s.dur), uA = s.u;
            if (uB <= uA) continue;
            if (uA === 0 && !s.started) { s.started = true; if (s.thick > this.fx.H * 0.07) this._audioSwoosh(); }
            pc.strokeStyle = s.pat;
            const steps = Math.max(1, Math.ceil((uB - uA) * s.n));
            for (const b of s.bristles) {
                const a = Math.max(uA, b.u0), e = Math.min(uB, b.u1);
                if (e <= a) continue;
                pc.lineWidth = b.w; pc.beginPath();
                for (let k = 0; k <= steps; k++) { const p = this._strokePoint(s, a + (e - a) * k / steps, b.off); if (k === 0) pc.moveTo(p[0], p[1]); else pc.lineTo(p[0], p[1]); }
                pc.stroke();
            }
            s.u = uB;
        }
    }

    _renderShow(dt) {
        const fx = this.fx, C = this.cfg, T = this.T, W = fx.W, H = fx.H, dc = this.dc;
        // --- ink: reveal pixels up to the front ---
        const u = clamp01((T - C.INK_START) / (C.INK_END - C.INK_START));
        const front = fx.Kmax * Math.pow(u, 1.5);
        const tc = this.tctx; const p0 = this.ptr;
        while (this.ptr < fx.P && fx.keys[this.ptr] <= front) {
            const i = this.ptr++, p = fx.order[i], tr = fx.tiers[i];
            if (tr !== this.lastTier) { tc.fillStyle = this.tierStyle[tr]; this.lastTier = tr; }
            tc.fillRect((p % W) - 0.3, ((p / W) | 0) - 0.3, 1.6, 1.6);
        }
        const revealed = this.ptr - p0;
        this.pxPerSec += ((dt > 0 ? revealed / dt : 0) - this.pxPerSec) * Math.min(1, dt * 6);
        // heads: the newest pixels burn brighter, then settle
        const hc = this.hctx; hc.clearRect(0, 0, W, H);
        if (this.ptr > 0 && this.ptr < fx.P) {
            const M = Math.min(110, this.ptr);
            for (let k = 0; k < M; k++) {
                const i = this.ptr - 1 - k, p = fx.order[i], a = Math.pow(1 - k / M, 1.6);
                hc.fillStyle = `rgba(205,235,255,${(0.85 * a).toFixed(3)})`;
                hc.fillRect((p % W) - 1, ((p / W) | 0) - 1, 2.6, 2.6);
            }
        }
        // --- colour ---
        if (T >= C.COL_START) this._advanceStrokes(T);
        if (T >= C.WASH_START) {
            const pc = this.pctx; pc.globalAlpha = 1 - Math.exp(-dt * 3.2);
            pc.drawImage(this.frame, 0, 0); pc.globalAlpha = 1;
        }
        // --- composite ---
        dc.globalCompositeOperation = 'source-over'; dc.globalAlpha = 1; dc.fillStyle = '#000'; dc.fillRect(0, 0, W, H);
        if (T >= C.COL_START) dc.drawImage(this.paint, 0, 0);
        if (T >= C.COL_START && this.patGrain && C.GRAIN > 0) {
            const ga = C.GRAIN * (1 - smooth((T - C.WASH_START) / (C.RES_START - C.WASH_START)));
            if (ga > 0.004) { dc.globalCompositeOperation = 'multiply'; dc.globalAlpha = ga; dc.fillStyle = this.patGrain; dc.fillRect(0, 0, W, H); dc.globalCompositeOperation = 'source-over'; dc.globalAlpha = 1; }
        }
        if (T >= C.COL_START && C.BLOOM > 0) {
            const bk = C.BLOOM * (1 - smooth((T - C.WASH_START) / (C.RES_START - C.WASH_START)));
            if (bk > 0.004) {
                this.pb4c.clearRect(0, 0, this.pb4.width, this.pb4.height); this.pb4c.drawImage(this.paint, 0, 0, this.pb4.width, this.pb4.height);
                this.pb8c.clearRect(0, 0, this.pb8.width, this.pb8.height); this.pb8c.drawImage(this.pb4, 0, 0, this.pb8.width, this.pb8.height);
                dc.globalCompositeOperation = 'screen'; dc.imageSmoothingEnabled = true; dc.imageSmoothingQuality = 'high';
                dc.globalAlpha = bk; dc.drawImage(this.pb8, 0, 0, W, H); dc.globalAlpha = bk * 0.6; dc.drawImage(this.pb4, 0, 0, W, H);
                dc.globalCompositeOperation = 'source-over'; dc.globalAlpha = 1;
            }
        }
        const vis = T < C.INK_END - 0.2 ? 1 : 1 - 0.65 * smooth((T - (C.INK_END - 0.2)) / (C.RES_START - C.INK_END + 0.2));
        if (this.ptr > 0) {
            this.g2c.clearRect(0, 0, this.g2.width, this.g2.height); this.g2c.drawImage(this.trail, 0, 0, this.g2.width, this.g2.height);
            this.g2c.drawImage(this.heads, 0, 0, this.g2.width, this.g2.height);
            this.g4c.clearRect(0, 0, this.g4.width, this.g4.height); this.g4c.drawImage(this.g2, 0, 0, this.g4.width, this.g4.height);
            this.g8c.clearRect(0, 0, this.g8.width, this.g8.height); this.g8c.drawImage(this.g4, 0, 0, this.g8.width, this.g8.height);
            dc.globalCompositeOperation = 'lighter'; dc.imageSmoothingEnabled = true; dc.imageSmoothingQuality = 'high';
            dc.globalAlpha = 0.9 * vis; dc.drawImage(this.g8, 0, 0, W, H); dc.drawImage(this.g8, 0, 0, W, H);
            dc.globalAlpha = 0.8 * vis; dc.drawImage(this.g4, 0, 0, W, H); dc.drawImage(this.g4, 0, 0, W, H);
            dc.globalAlpha = vis; dc.drawImage(this.trail, 0, 0);
            dc.globalAlpha = 1; dc.drawImage(this.heads, 0, 0);
        }
        if (C.MOTES) this._renderMotes(dt, T);
        // --- the first pulse ---
        if (T >= 0 && T < C.INK_START + 1.4) {
            const beat = (t0) => T > t0 ? Math.exp(-(T - t0) * 3.0) : 0;
            const amp = Math.min(1, beat(0.15) + 0.65 * beat(0.72));
            const fade = T < 0.1 ? T / 0.1 : 1, fadeOut = clamp01(1 - (T - (C.INK_START + 0.5)) / 0.9);
            const r = (5 + 30 * amp) * (H / 540 + 0.4), a = (0.12 + 0.88 * amp) * fade * fadeOut;
            const g = dc.createRadialGradient(fx.seed.x, fx.seed.y, 0, fx.seed.x, fx.seed.y, r);
            g.addColorStop(0, `rgba(170,215,255,${a.toFixed(3)})`); g.addColorStop(0.35, `rgba(88,164,255,${(a * 0.5).toFixed(3)})`); g.addColorStop(1, 'rgba(40,100,255,0)');
            dc.globalCompositeOperation = 'lighter'; dc.fillStyle = g; dc.beginPath(); dc.arc(fx.seed.x, fx.seed.y, r, 0, 6.283); dc.fill();
            dc.fillStyle = `rgba(210,235,255,${(0.9 * fade * fadeOut).toFixed(3)})`; dc.beginPath(); dc.arc(fx.seed.x, fx.seed.y, 1.6, 0, 6.283); dc.fill();
        }
        dc.globalCompositeOperation = 'source-over'; dc.globalAlpha = 1;
        // --- hand-off dissolve ---
        const k = smooth((T - C.RES_START) / (C.RES_END - C.RES_START));
        this.root.style.opacity = String(1 - k);
        // --- settle: starts slightly zoomed with a faint sway, eases to exactly 1.0 by the dissolve so it lands on the live view ---
        if (C.DRIFT) {
            const u = 1 - smooth(T / C.RES_START), sc = 1 + C.DRIFT * u;
            this.cv.style.transform = `translate(${(Math.sin(T * 0.31) * 0.35 * u).toFixed(3)}%,${(Math.cos(T * 0.23) * 0.25 * u).toFixed(3)}%) scale(${sc.toFixed(4)})`;
        }
        // --- sound cues ---
        this._audioCues(T);
    }

    // Drifting light motes: sparks lifted off the pen as it draws (cool blue), then slow warm specks while the colour goes on.
    _renderMotes(dt, T) {
        const fx = this.fx, C = this.cfg, W = fx.W, H = fx.H, dc = this.dc, R = this.rng, m = this.motes;
        const fade = 1 - smooth((T - (C.RES_START - 1.0)) / 1.0);
        if (fade > 0 && dt > 0 && m.length < 220) {
            if (this.ptr > 0 && T < C.INK_END + 0.8) {
                const nsp = Math.min(3, this.pxPerSec / 2500);
                for (let k = 0; k < nsp; k++) if (R() < nsp - k + 0.2) {
                    const p = fx.order[Math.max(0, this.ptr - 1 - Math.floor(R() * 160))];
                    m.push({ x: p % W, y: (p / W) | 0, vx: (R() - 0.5) * 6, vy: -(4 + R() * 12), life: 0, max: 2 + R() * 2.5, r: 1.6 + R() * 3.2, g: 0, ph: R() * 6.28 });
                }
            }
            if (T >= C.COL_START - 0.5 && R() < dt * 30) m.push({ x: R() * W, y: H * (0.3 + R() * 0.7), vx: (R() - 0.5) * 5, vy: -(3 + R() * 7), life: 0, max: 3 + R() * 3, r: 2.2 + R() * 5, g: 1, ph: R() * 6.28 });
        }
        dc.globalCompositeOperation = 'lighter';
        for (let i = m.length - 1; i >= 0; i--) {
            const o = m[i]; o.life += dt; if (o.life >= o.max) { m.splice(i, 1); continue; }
            const k = o.life / o.max, a = Math.sin(Math.PI * k) * (0.55 + 0.45 * Math.sin(T * 2.3 + o.ph)) * fade;
            o.x += (o.vx + Math.sin(T * 0.8 + o.ph) * 4) * dt; o.y += o.vy * dt;
            if (a <= 0.01) continue;
            const sz = o.r * 4 * (H / 540); dc.globalAlpha = Math.min(1, a * (o.g ? 0.55 : 0.8));
            dc.drawImage(o.g ? this.sprG : this.sprB, o.x - sz / 2, o.y - sz / 2, sz, sz);
        }
        dc.globalAlpha = 1; dc.globalCompositeOperation = 'source-over';
    }

    // ---- 6. sound (Web Audio, quiet; goes through the game's SFX bus when given one) --------------------------
    _noise() {
        const a = this.audio; if (!a) return null;
        if (!this._nbuf) { const n = a.ctx.sampleRate * 2, b = a.ctx.createBuffer(1, n, a.ctx.sampleRate), d = b.getChannelData(0); for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1; this._nbuf = b; }
        return this._nbuf;
    }
    _tone(freq, o) {
        const a = this.audio; if (!a) return; const ctx = a.ctx, now = ctx.currentTime;
        const { type = 'sine', attack = 0.05, hold = 0.2, release = 1.5, gain = 0.1, lp0 = 600, lp1 = 2000, detune = 0, rev = true } = o;
        const osc = ctx.createOscillator(); osc.type = type; osc.frequency.value = freq; osc.detune.value = detune;
        const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.Q.value = 0.5; f.frequency.setValueAtTime(lp0, now); f.frequency.linearRampToValueAtTime(lp1, now + attack + hold);
        const g = ctx.createGain(); g.gain.setValueAtTime(0.0001, now); g.gain.linearRampToValueAtTime(gain, now + attack); g.gain.setValueAtTime(gain, now + attack + hold); g.gain.exponentialRampToValueAtTime(0.0001, now + attack + hold + release);
        osc.connect(f); f.connect(g); g.connect(a.out); if (rev && a.reverb) g.connect(a.reverb);
        osc.start(now); osc.stop(now + attack + hold + release + 0.1);
    }
    _thump() {
        const a = this.audio; if (!a) return; const ctx = a.ctx, now = ctx.currentTime;
        const osc = ctx.createOscillator(); osc.type = 'sine'; osc.frequency.setValueAtTime(74, now); osc.frequency.exponentialRampToValueAtTime(34, now + 0.4);
        const g = ctx.createGain(); g.gain.setValueAtTime(0.0001, now); g.gain.linearRampToValueAtTime(0.32, now + 0.012); g.gain.exponentialRampToValueAtTime(0.0001, now + 0.7);
        osc.connect(g); g.connect(a.out); if (a.reverb) g.connect(a.reverb); osc.start(now); osc.stop(now + 0.8);
    }
    _swoosh() { this._audioSwoosh(); }
    _audioSwoosh() {
        const a = this.audio; if (!a) return; const buf = this._noise(); const ctx = a.ctx, now = ctx.currentTime;
        const src = ctx.createBufferSource(); src.buffer = buf; src.loop = true;
        const bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.Q.value = 1.1; bp.frequency.setValueAtTime(420, now); bp.frequency.exponentialRampToValueAtTime(2200, now + 0.75);
        const g = ctx.createGain(); g.gain.setValueAtTime(0.0001, now); g.gain.linearRampToValueAtTime(0.045, now + 0.25); g.gain.exponentialRampToValueAtTime(0.0001, now + 0.95);
        src.connect(bp); bp.connect(g); g.connect(a.out); if (a.reverb) g.connect(a.reverb);
        src.start(now, Math.random() * 1.5); src.stop(now + 1.0);
    }
    _audioStartPen() {
        const a = this.audio; if (!a) return; const ctx = a.ctx;
        const src = ctx.createBufferSource(); src.buffer = this._noise(); src.loop = true;
        const hp = ctx.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 1800;
        const bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 3600; bp.Q.value = 2.2;
        const g = ctx.createGain(); g.gain.value = 0;
        src.connect(hp); hp.connect(bp); bp.connect(g); g.connect(a.out);
        src.start(); this.pen = { src, g, bp };
    }
    _audioStop() {
        if (this.pen) { try { this.pen.g.gain.setTargetAtTime(0, this.audio.ctx.currentTime, 0.1); this.pen.src.stop(this.audio.ctx.currentTime + 0.5); } catch (e) { } this.pen = null; }
    }
    _audioCues(T) {
        if (!this.audio) return; const C = this.cfg, f = this.fired, ctx = this.audio.ctx;
        if (this.pen) {
            const rate = this.pxPerSec, on = (T > C.INK_START && T < C.INK_END + 0.3) ? Math.min(1, rate / 9000) : 0;
            this.pen.g.gain.setTargetAtTime(0.03 * on, ctx.currentTime, 0.08);
            this.pen.bp.frequency.setTargetAtTime(2600 + Math.min(2600, rate * 0.3), ctx.currentTime, 0.1);
        }
        if (!f.b1 && T >= 0.15) { f.b1 = 1; this._thump(); this._tone(1318.5, { attack: 0.01, hold: 0.05, release: 2.6, gain: 0.018, lp0: 3000, lp1: 5000 }); }
        if (!f.b2 && T >= 0.72) { f.b2 = 1; this._thump(); }
        if (!f.pad && T >= C.INK_START + 0.3) { f.pad = 1; this._tone(110, { attack: 4.0, hold: 3.5, release: 4.5, gain: 0.07, lp0: 160, lp1: 520 }); this._tone(164.81, { attack: 4.5, hold: 3.0, release: 4.5, gain: 0.04, lp0: 200, lp1: 700, detune: 5 }); }
        if (!f.chord && T >= C.COL_START) {
            f.chord = 1;
            [146.83, 220, 329.63, 369.99, 493.88].forEach((fr, i) => this._tone(fr, { attack: 2.6 + i * 0.25, hold: 4.2, release: 4.5, gain: 0.04 - i * 0.004, lp0: 700, lp1: 2600, detune: (i - 2) * 4 }));
        }
        if (!f.bell && T >= C.RES_START) { f.bell = 1; this._tone(880, { attack: 0.02, hold: 0.1, release: 3.8, gain: 0.05, lp0: 4000, lp1: 6000 }); this._tone(1318.5, { attack: 0.02, hold: 0.1, release: 3.2, gain: 0.025, lp0: 4000, lp1: 6000, detune: 4 }); }
    }
}
