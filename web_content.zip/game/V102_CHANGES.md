# v102: the dream

New `dream_cinematic.js` (self-contained like the freefall cinematic: its own overlay, WebGL2 canvas and Web Audio). `game.js` changes: one import, one instance beside the freefall one, `startVoyageDream()`, a hook in `voyagePassage`, and a saved flag `voyageDreamSeen`. Nothing else touched.

## Where it happens
On the long overnight leg **"NOTHING BUT SEA"** (after the wreck, before the memorial). Half-way through that sky time-lapse the pilot drifts off: the time-lapse freezes under the dream and carries on when it ends. Plays once per voyage (saved). Afterwards a log entry ("Asleep on the Water") is added and the companion says one line on waking.
Dev preview: `playDreamCinematic()` in the console, or open `preview_dream.html`.

## The dream (about 1 min 45 s, no dialogue, no captions)
Real 3D (one raymarched shader), first person with head sway, painted: brush-stroke wobble, ink-pooled outlines, posterised washes, paper grain, soft bloom. The scene smears and dips to black at each cut, the way dreams change.
1. **The kitchen** (warm, sunset): a small figure faces the window with its back to you, turns, runs to you, raises a hand. Your hand rises to meet it.
2. **The corridor** (midnight blue): endless shelves, a clock whose hands are wrong, a lit door that keeps backing away with the small figure in front of it.
3. **The hearing** (cold): a round hall of tall pale watchers who lean in. You hold the small hand. A flat voice reads. Three blows. The small hand slips away; the child shrinks down the aisle toward a white door. The light goes out.
4. **The water**: the hall floods and the watchers wash away into paint. A locket sinks past. You rise toward a square of light (the kitchen window) where the small figure stands, one hand reaching down. White, then black, then a breath and a heartbeat.

## Sound
All synthesised. People are a glottal source + three formant filters gliding between vowels + breath noise + syllable rhythm with phrase pauses, heard through low-passes and a long reverb: two grown-ups in the next room, a child's laugh, a murmuring crowd with one flat reader, muffled underwater. Also: a music-box tune that returns slowed and unfinished in the water, a wrong clock, heartbeat, gavel blows, water bed. The world's music and SFX are ducked for the duration and restored the moment the picture goes black the last time.

## Controls / behaviour
Same as the freefall cinematic: double-tap or Esc pauses, "Keep watching" resumes, "Leave" saves and reloads (the dream restarts from the top next time). Space/Enter do not skip it. Render scale adapts to frame time. If WebGL2 is missing, the dream is skipped and the voyage carries on.

## Tests (in `tests/`)
- `dream_harness.html` + `dream_shots.py OUTDIR t1 t2 ...`: renders any moment (seconds on the dream timeline, 0-106) to a PNG.
- `dream_play_test.py`: play / double-tap pause / resume / leave / skip lifecycle (all pass).
- `dream_audio_check.py`: renders the soundtrack offline to a WAV.

## Not verified
The full game could not be booted in the build sandbox (it loads three.js from a CDN), so the trigger inside the real voyage has only been checked by syntax and by reading the code. The sound has been checked by levels and spectrogram, not by ear.

## Tuning
Timeline at the top of `dream_cinematic.js` (`SD` scene lengths, `TRN` cut length). Trigger point: `k >= 0.5` in the `voyagePassage` hook. Choreography is the pure function `stateAt(t)`.
