# v96 - touch controls overhaul (on top of v95 painterly + cel look)

- **Settings > Controls Device** (in-game Settings and main-menu Options): Touch or Keyboard + Mouse. Saved with the other options
  and also set by the tutorial's platform choice. A controller is still picked up automatically when connected.
- **Walk by default on touch.** The joystick no longer auto-sprints when pushed far (that only stays on for Keyboard + Mouse mode).
- **Sprint button** (two arrows, bottom-right): a toggle. Tap = run and it stays lit amber; tap again = walk. Shares state with the
  gamepad's run toggle, and is cleared when you switch device.
- **Jump button** (up arrow, bottom-right, right of sprint): same as Space; also swims/flies up where Space does. Hold = repeat jump.
- Both buttons are excluded from the joystick/look touch zones so tapping them never steers the camera. Tutorial "Move" text updated.
- Files: index.html (buttons + settings rows), styles.css (end of file), game.js (`CONTROLS DEVICE + TOUCH BUTTONS` block before
  `setupTouchControls`).
