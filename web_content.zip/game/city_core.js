// =====================================================================================
// city_core.js - procedural valley CITY generator (pure maths: no three.js, no DOM). Runs in the chunk workers (city job) and in Node tests.
//
// v53 REWRITE - a hillside megacity that grows on the land it finds (see V53_CHANGES.md)
//   * Plan space: x = ground units EAST of the site centre, z = ground units SOUTH, y = world height. The whole city is placed with ONE group
//     transform per chart. The terrain under it is the natural terrain (valley_sites.js only smooths it a little and levels the hub square).
//   * STREETS FOLLOW THE SLOPE: spokes that climb at a street grade (bending into switchbacks where the ground is steep), CONTOUR streets that
//     run level along the hillside at fixed height steps, stairways joining the levels, and real bridges where a street pair faces each other
//     across a gully. Retaining walls under every street cut into the slope.
//   * BUILDINGS ARE BUILT INTO THE SLOPE: the body sits at the middle of its footprint's height range, so the uphill half is buried in the hill
//     and the downhill side stands on a foundation block that reaches the lowest ground (no building ever hovers).
//   * KOWLOON-STYLE VERTICAL DENSITY: 3..14-storey blocks everywhere, 14..34-storey towers in several clusters, stepped crowns, cantilevered
//     floors, rooftop shacks / tanks / antennas / gardens, AC boxes, balconies, neon signs, scaffolding, pipes, overhead wires.
//   * SCRAP BRIDGES: only between two real anchor points (wall to wall at a floor both buildings have, or street to street across a real gap),
//     never through another building, never into the ground. Mismatched planks, truss, posts, rails, tarps, guy wires, trestle legs.
//   * Piece conventions: yaw is the direction (cos yaw, sin yaw) in plan space (x, z) - the SAME convention the footprint / overlap tests use.
//     (Before v53 the renderer used the mirrored convention, so every rotated street and building was drawn mirrored.)
//     pitch tilts the long (x) axis up (+) or down, roll banks about x.
// OUTPUT: planToInstances() -> { cats:{ name:{ m: Float32Array(16n), c: Float32Array(3n) } }, sky, beacon, ... } + planToLife() for the drones.
// =====================================================================================
import { valleyHeight, floorRadius, rimRadius, NA, mulberry, h32 } from './valley_sites.js';

const s2l = (c) => c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
const hexLin = (hex) => [s2l(((hex >> 16) & 255) / 255), s2l(((hex >> 8) & 255) / 255), s2l((hex & 255) / 255)];
const clamp = (x, a, b) => x < a ? a : x > b ? b : x;
const lerp = (a, b, t) => a + (b - a) * t;

// v56 additions (the Rogues' Citadel): smooth high-res shells (orgCyl / orgDome / orgCone), tapered frusta tp0..tp6 (top radius = 0.92..0.24 of the base),
// flared frusta fl0..fl3 (top radius = 1.14..1.8 x the base), round glow rings (glowCyl) and translucent glass cylinders (glassCyl)
export const TAPERS = [0.92, 0.82, 0.72, 0.62, 0.5, 0.38, 0.24], FLARES = [1.14, 1.3, 1.5, 1.8];
export const CITY_CATS = ['wallBox', 'wallCyl', 'plainBox', 'plainCyl', 'gable', 'dome', 'cone', 'arch', 'glow', 'baseBox', 'glassDome',
    'orgCyl', 'orgDome', 'orgCone', 'glowCyl', 'glassCyl', ...TAPERS.map((_, i) => 'tp' + i), ...FLARES.map((_, i) => 'fl' + i)];
export const ARCHETYPES = ['basin', 'terraced', 'cliffside', 'spur'];
export const PALETTES = [
    { name: 'sandstone', walls: [0xd9c4a0, 0xc9a97a, 0xe6d5b5, 0xb88c60, 0xcdb48c], roofs: [0x9a4a32, 0x7a3b28, 0x5e4a3a, 0xa8603c], trim: 0x6d5a44, glass: 0xffc977 },
    { name: 'slate', walls: [0x8d97a3, 0x6f7b88, 0xaeb7c1, 0x59636e, 0x7f8a96], roofs: [0x394350, 0x2c3540, 0x4a5a6a, 0x33404d], trim: 0x2a313a, glass: 0xaee3ff },
    { name: 'whitewash', walls: [0xf0ece4, 0xe4ddd0, 0xd6cfc4, 0xc9c2b8, 0xf6f2ea], roofs: [0x2d7d86, 0x2a6a7a, 0x3a8f88, 0x1f6672], trim: 0x8a8378, glass: 0xfff0b0 },
    { name: 'copper', walls: [0x8a5a45, 0x6b4636, 0xa07050, 0x7d513e, 0x93654d], roofs: [0x2f8f7a, 0x3a6e66, 0x274a4a, 0x3d9a84], trim: 0x3b2a22, glass: 0xffb36a },
    { name: 'basalt', walls: [0x3a3f48, 0x2b2f38, 0x4a505c, 0x22262e, 0x525966], roofs: [0x1a1d24, 0x2a2f3a, 0x14171c], trim: 0x6b7280, glass: 0x7ff0d0 },
    { name: 'moss', walls: [0x6f8a5e, 0x5a7550, 0x8aa070, 0x4d6a48, 0x7c9568], roofs: [0x7a5a3a, 0x5a4430, 0x8a6a46], trim: 0x3c4a34, glass: 0xdfffa0 },
    { name: 'terracotta', walls: [0xc9704a, 0xb85f3c, 0xd98a60, 0xa5532f, 0xe09a70], roofs: [0x6a3a2a, 0x7a4a34, 0x4a2c22], trim: 0x5a3a2a, glass: 0xffd27a },
    { name: 'azure', walls: [0x6c93b8, 0x547ba3, 0x8aaed0, 0x42688e, 0x9ab8d4], roofs: [0xe8e4da, 0xcfc9bb, 0x2e4a66], trim: 0x2c3e52, glass: 0xc8f0ff },
    // v53: the dense-stack palettes - weathered concrete and painted corrugated metal
    { name: 'concrete', walls: [0x9a9a92, 0x84857e, 0xa8a69c, 0x6f726e, 0x8d8f86, 0x7c8a82], roofs: [0x5a5e5c, 0x6b4a3a, 0x4a5a5e], trim: 0x3a3d3c, glass: 0xffd9a0 },
    { name: 'rustbelt', walls: [0x8a5a44, 0x6a7a80, 0x9a8a6a, 0x5a6a70, 0x7a4a3a, 0x8a7a60], roofs: [0x7a3a26, 0x4a5a64, 0x5e4a3a], trim: 0x2f2a26, glass: 0xffc27a }
];
const HUB_KINDS = ['spire', 'domeHall', 'ziggurat', 'clock', 'lightTree'];
// scrap colours (sRGB hex): rusted iron, galvanised, painted metal, tarps, rope
const SCRAP = [0x8a4b2d, 0x6e3b26, 0x9a5a35, 0x6b7078, 0x7d838a, 0x4f5a62, 0x3f5f78, 0xb08a2a, 0x5a4a3a, 0x7a2f26];
const TARP = [0x2f8fb0, 0xd9812b, 0xb8412f, 0x3a9a6a, 0xd8c24a, 0x6a4aa8];

// ---------------------------------------------------------------------------------- geometry helpers
function obbCorners(o) { const c = Math.cos(o.yaw), s = Math.sin(o.yaw), hx = o.w / 2, hz = o.d / 2; return [[-hx, -hz], [hx, -hz], [hx, hz], [-hx, hz]].map(([x, z]) => [o.x + x * c - z * s, o.z + x * s + z * c]); }
function obbOverlap(A, B, pad) {
    const ax = [[Math.cos(A.yaw), Math.sin(A.yaw)], [-Math.sin(A.yaw), Math.cos(A.yaw)], [Math.cos(B.yaw), Math.sin(B.yaw)], [-Math.sin(B.yaw), Math.cos(B.yaw)]];
    const ca = A._c || (A._c = obbCorners(A)), cb = B._c || (B._c = obbCorners(B));
    for (const [nx, nz] of ax) {
        let a0 = 1e18, a1 = -1e18, b0 = 1e18, b1 = -1e18;
        for (const p of ca) { const d = p[0] * nx + p[1] * nz; if (d < a0) a0 = d; if (d > a1) a1 = d; }
        for (const p of cb) { const d = p[0] * nx + p[1] * nz; if (d < b0) b0 = d; if (d > b1) b1 = d; }
        if (a1 + pad < b0 || b1 + pad < a0) return false;
    }
    return true;
}
function inObb(o, x, z, pad) { const c = Math.cos(o.yaw), s = Math.sin(o.yaw), dx = x - o.x, dz = z - o.z, u = dx * c + dz * s, v = -dx * s + dz * c; return Math.abs(u) <= o.w / 2 + pad && Math.abs(v) <= o.d / 2 + pad; }
class Grid {   // spatial hash of objects with a bounding radius
    constructor(cell) { this.cell = cell; this.m = new Map(); }
    _k(i, j) { return i * 73856093 ^ j * 19349663; }
    add(o, r) { const c = this.cell; for (let i = Math.floor((o.x - r) / c); i <= Math.floor((o.x + r) / c); i++) for (let j = Math.floor((o.z - r) / c); j <= Math.floor((o.z + r) / c); j++) { const k = this._k(i, j); let l = this.m.get(k); if (!l) this.m.set(k, l = []); l.push(o); } }
    near(x, z, r) { const out = new Set(), c = this.cell; for (let i = Math.floor((x - r) / c); i <= Math.floor((x + r) / c); i++) for (let j = Math.floor((z - r) / c); j <= Math.floor((z + r) / c); j++) { const l = this.m.get(this._k(i, j)); if (l) for (const o of l) out.add(o); } return out; }
}
function distSeg(px, pz, ax, az, bx, bz) { const dx = bx - ax, dz = bz - az, l2 = dx * dx + dz * dz || 1, t = clamp(((px - ax) * dx + (pz - az) * dz) / l2, 0, 1), qx = ax + dx * t - px, qz = az + dz * t - pz; return Math.sqrt(qx * qx + qz * qz); }
class Heap {
    constructor() { this.a = []; }
    push(k, v) { const a = this.a; a.push([k, v]); let i = a.length - 1; while (i > 0) { const p = (i - 1) >> 1; if (a[p][0] <= a[i][0]) break; [a[p], a[i]] = [a[i], a[p]]; i = p; } }
    pop() { const a = this.a, top = a[0], last = a.pop(); if (a.length) { a[0] = last; let i = 0; for (;;) { const l = 2 * i + 1, r = l + 1; let m = i; if (l < a.length && a[l][0] < a[m][0]) m = l; if (r < a.length && a[r][0] < a[m][0]) m = r; if (m === i) break; [a[m], a[i]] = [a[i], a[m]]; i = m; } } return top; }
    get size() { return this.a.length; }
}

// ---------------------------------------------------------------------------------- the generator
// nat(x, z): NATURAL ground height at plan point (x east, z south).  Returns the plan.
export function generateCity(S, nat, opts = {}) {
    const rnd = mulberry(S.seedN ^ 0x5bd1e995), R = (a, b) => a + (b - a) * rnd(), pick = (arr) => arr[Math.floor(rnd() * arr.length) % arr.length];
    const ground = (x, z) => valleyHeight(S, x, -z, nat(x, z));
    const hubY = ground(0, 0);
    const lowestUnder = (x, z, w, d, yaw) => { const c = Math.cos(yaw), s = Math.sin(yaw), hw = w / 2 + 0.6, hd = d / 2 + 0.6; let lo = 1e18, hi = -1e18; for (let i = 0; i < 5; i++) for (let j = 0; j < 5; j++) { const px = (i / 2 - 1) * hw, pz = (j / 2 - 1) * hd, y = ground(x + px * c - pz * s, z + px * s + pz * c); if (y < lo) lo = y; if (y > hi) hi = y; } return [lo, hi]; };
    const skirt = (lo, hi) => 9 + Math.min(16, (hi - lo) * 0.45);
    const edgeR = (a) => floorRadius(S, Math.cos(a), -Math.sin(a));          // reach of the dense city toward plan angle a (plan z = -n)
    const rimAtA = (a) => rimRadius(S, Math.cos(a), -Math.sin(a));
    const ang = (x, z) => Math.atan2(z, x), edgeXZ = (x, z) => edgeR(ang(x, z)), rimXZ = (x, z) => rimAtA(ang(x, z));
    const inDense = (x, z, k) => Math.hypot(x, z) <= edgeXZ(x, z) * k, inRim = (x, z, k) => Math.hypot(x, z) <= rimXZ(x, z) * k;
    let RcMax = 0; for (let i = 0; i < NA; i++) RcMax = Math.max(RcMax, S.ft[i]);
    const maxB = opts.maxBuildings || 4200;
    const pal = PALETTES[Math.floor(h32(S.seedN, 12, 4, 6) * PALETTES.length)], hubKind = HUB_KINDS[Math.floor(h32(S.seedN, 13, 5, 7) * HUB_KINDS.length)];
    const arche = (S.meanSlope || 0.4) < 0.32 ? 'basin' : (S.meanSlope || 0.4) < 0.5 ? 'terraced' : (S.meanSlope || 0.4) < 0.8 ? 'cliffside' : 'spur';
    const warmWin = rnd() < 0.5;
    const city = { seed: S.seedN, arche, palette: pal.name, hubKind, floorH: hubY, Rf: S.Rf, Rc: S.Rf, warmWindows: warmWin, buildings: [], pieces: [], nodes: [], edges: [], poi: { homes: [], shops: [], works: [], plazas: [], docks: [], towers: [], gates: [], views: [] }, stats: {} };
    const cols = { walls: pal.walls.map(hexLin), roofs: pal.roofs.map(hexLin), trim: hexLin(pal.trim), glass: hexLin(pal.glass) };
    const ACC = [hexLin(0x2f9fe8), hexLin(0x2ed3a1), hexLin(0x4fc3f7), hexLin(0x45e08a)];   // blue / green accents (the drone colours)
    const accent = pick(ACC), accent2 = pick(ACC);
    const NEON = [hexLin(0xff4f8b), hexLin(0x35e0ff), hexLin(0xffd23a), hexLin(0x7dff6a), hexLin(0xff8a2a), hexLin(0xb06bff)];
    const jit = (c, a) => { const k = 1 + (rnd() - 0.5) * a; return [clamp(c[0] * k, 0, 1), clamp(c[1] * k, 0, 1), clamp(c[2] * k, 0, 1)]; };
    const scrapCol = () => jit(hexLin(pick(SCRAP)), 0.25), tarpCol = () => jit(hexLin(pick(TARP)), 0.2);

    // ---------- piece emit ----------
    let skipCol = false;      // pieces emitted while this is on (stair treads, ...) get no collider of their own
    const P = (cat, x, y, z, yaw, sx, sy, sz, color, pitch = 0, roll = 0) => city.pieces.push({ cat, x, y, z, yaw, sx, sy, sz, color, pitch, roll, nc: skipCol });
    const COL = city.cols = [];   // explicit colliders (floors, decks, piers); planToCols() adds the solid pieces. 9 numbers each: see city_collide.js
    const addCol = (cx, cz, yaw, hw, hd, yBot, y0, y1, kind = 0) => { COL.push(cx, cz, yaw, hw, hd, yBot, y0, y1, kind); };
    // a box whose long (x) axis runs from p0 to p1 (any 3D direction), cross-section t1 (tall) x t2 (wide), centred on the segment
    const beam = (cat, x0, y0, z0, x1, y1, z1, t1, t2, color) => {
        const dx = x1 - x0, dy = y1 - y0, dz = z1 - z0, hz = Math.hypot(dx, dz), L = Math.hypot(hz, dy); if (L < 0.05) return;
        const yaw = hz > 1e-6 ? Math.atan2(dz, dx) : 0, pitch = Math.atan2(dy, hz), cp = Math.cos(pitch), sp = Math.sin(pitch);
        const ux = -Math.cos(yaw) * sp, uy = cp, uz = -Math.sin(yaw) * sp;       // the box's local up vector (its origin is the base-centre)
        P(cat, (x0 + x1) / 2 - ux * t1 / 2, (y0 + y1) / 2 - uy * t1 / 2, (z0 + z1) / 2 - uz * t1 / 2, yaw, L, t1, t2, color, pitch, 0);
    };

    // ---------- STREET GRAPH ----------
    const nodes = city.nodes, edges = city.edges, nGrid = new Grid(40);
    const addNode = (x, z, kind = 0, lv = 0, y = null) => { const n = { id: nodes.length, x, z, y: y === null ? ground(x, z) : y, kind, lv, adj: [] }; nodes.push(n); nGrid.add(n, 0); return n.id; };
    const hasEdge = (a, b) => nodes[a].adj.includes(b);
    const addEdge = (a, b, w, lvl = 0, t = 0) => { if (a === b || hasEdge(a, b) || (domes.length && crossDome(nodes[a].x, nodes[a].z, nodes[b].x, nodes[b].z))) return false; edges.push({ a, b, w, lvl, t }); nodes[a].adj.push(b); nodes[b].adj.push(a); return true; };
    const nodeNear = (x, z, maxD, filt) => { let b = -1, bd = maxD * maxD; for (const n of nGrid.near(x, z, maxD)) { if (filt && !filt(n)) continue; const d = (n.x - x) ** 2 + (n.z - z) ** 2; if (d < bd) { bd = d; b = n.id; } } return b; };
    const hubN = addNode(0, 0, 1, 0, hubY);
    const sw0 = R(20, 26);          // base street width (v55: wider - the buildings are ~2x bigger now)
    // level step between contour streets: smaller on flat ground so contours stay close enough to carry a street grid
    const STEP = (S.meanSlope || 0.4) < 0.3 ? 34 : (S.meanSlope || 0.4) < 0.5 ? 42 : 50;
    const lvOf = (y) => Math.round((y - hubY) / STEP);
    const plazaR = R(46, 66);

    // generic slope-aware walker: from node s with heading h0, step by CL; at each step choose the heading that scores best among those
    // under the grade limit (so it bends into switchbacks where the ground is steep); joins any street it meets.
    const DLS = [0, 0.2, -0.2, 0.42, -0.42, 0.7, -0.7, 1.05, -1.05, 1.45, -1.45];
    const walk = (s, h0, o) => {
        const CL = o.CL || 28; let x = nodes[s].x, z = nodes[s].z, y = nodes[s].y, h = h0, last = s; const own = [s];
        for (let st = 0; st < (o.max || 80); st++) {
            let best = null, bs = -1e18;
            for (const dl of DLS) {
                const ha = h + dl, qx = x + Math.cos(ha) * CL, qz = z + Math.sin(ha) * CL;
                if (!o.inside(qx, qz) || inDome(qx, qz)) continue;
                const qy = ground(qx, qz), grade = Math.abs(qy - y) / CL; if (grade > o.grade) continue;
                const sc = o.progress(x, z, qx, qz) - Math.abs(dl) * 6 - grade * 10; if (sc > bs) { bs = sc; best = { qx, qz, qy, dl }; }
            }
            if (!best) break;
            if (o.minProgress !== undefined && bs < o.minProgress) break;
            h += best.dl * 0.6;
            const hit = nodeNear(best.qx, best.qz, 16, (n) => !own.slice(-3).includes(n.id));
            if (hit >= 0 && st > 1) { if (Math.abs(nodes[hit].y - y) / Math.max(8, Math.hypot(nodes[hit].x - x, nodes[hit].z - z)) < o.grade * 1.4) addEdge(last, hit, o.w, lvOf(y), 0); break; }
            const id = addNode(best.qx, best.qz, o.kind || 0, lvOf(best.qy)); addEdge(last, id, o.w, lvOf(best.qy), 0); own.push(id); last = id; x = best.qx; z = best.qz; y = best.qy;
            if (o.done && o.done(x, z)) break;
        }
        return last;
    };
    // ---- the gate (on the natural pass road) and the road to it
    const passPts = (S.passPts && S.passPts.length > 1) ? S.passPts.map(p => [p[0], -p[1]]) : [[Math.cos(S.passAng) * S.Rf, -Math.sin(S.passAng) * S.Rf], [Math.cos(S.passAng) * (S.Rf + 80), -Math.sin(S.passAng) * (S.Rf + 80)]];
    const gx = passPts[0][0], gz = passPts[0][1], gyaw = Math.atan2(passPts[1][1] - passPts[0][1], passPts[1][0] - passPts[0][0]), gateY = ground(gx, gz);
    // ---------- v55: ARTIFICIAL FARMLAND DOMES - sites chosen BEFORE the streets (streets route around them), right inside the outline ----------
    const domes = [];
    {
        const want = 3 + Math.floor(rnd() * 4), gAng = Math.atan2(gz, gx);
        for (let tr = 0; tr < 500 && domes.length < want; tr++) {
            const a = R(0, 6.2832), rd = R(84, 128), PR = rd + 34, e = edgeR(a), r = e * R(0.7, 1.0) - PR * 0.55; if (r < PR * 1.3 + 60) continue;
            const x = Math.cos(a) * r, z = Math.sin(a) * r; if (!inRim(x, z, 0.92)) continue;
            if (Math.hypot(x - gx, z - gz) < PR + 120 || domes.some(q => Math.hypot(q.x - x, q.z - z) < q.PR + PR + 60)) continue;
            const [lo, hi] = lowestUnder(x, z, PR * 1.8, PR * 1.8, 0); if (hi - lo > 56) continue;
            const yP = lo + (hi - lo) * 0.5 + 1; let hd = 0, hs = 1e18;
            for (let q = 0; q < 4; q++) { const h = q * Math.PI / 2, px = x + Math.cos(h) * (PR + 40), pz = z + Math.sin(h) * (PR + 40), sc = Math.abs(ground(px, pz) - yP) + 0.02 * Math.hypot(px, pz); if (sc < hs) { hs = sc; hd = h; } }
            const dx = Math.cos(hd), dz = Math.sin(hd), yE = ground(x + dx * (PR + 40), z + dz * (PR + 40)), len = clamp(Math.abs(yE - yP) / 0.3, 14, 70);
            domes.push({ x, z, rd, PR, yP, hd, len, lo, hi, kind: domes.length % 3, box: { x, z, yaw: 0, w: PR * 2 + 10, d: PR * 2 + 10 }, rampBox: { x: x + dx * (PR + len / 2), z: z + dz * (PR + len / 2), yaw: hd, w: len + 6, d: 34 } });
        }
        city.domeSites = domes.length;
    }
    const inDome = (x, z) => { for (const dm of domes) { const dx = x - dm.x, dz = z - dm.z, rr = dm.PR * 1.0 + 6; if (dx * dx + dz * dz < rr * rr) return true; } return false; };
    const crossDome = (ax, az, bx, bz) => { for (const dm of domes) if (distSeg(dm.x, dm.z, ax, az, bx, bz) < dm.PR + 6) return true; return false; };
    { // hub -> gate: steered walk (the main boulevard)
        const gt = Math.hypot(gx, gz);
        const last = walk(hubN, Math.atan2(gz, gx), { grade: 0.34, w: sw0 * 1.45, kind: 1, max: 140, CL: 38, inside: (x, z) => inRim(x, z, 0.995) || Math.hypot(x - gx, z - gz) < 60, progress: (px, pz, qx, qz) => (Math.hypot(px - gx, pz - gz) - Math.hypot(qx - gx, qz - gz)) * 1.2, done: (x, z) => Math.hypot(x - gx, z - gz) < 36 });
        city.gateNode = addNode(gx, gz, 2, lvOf(gateY), gateY); addEdge(last, city.gateNode, sw0 * 1.45, lvOf(gateY), 0);
        if (Math.hypot(nodes[last].x - gx, nodes[last].z - gz) > 90) { /* the walk could not reach the gate under the grade limit: a steep stair finishes it */ }
        void gt;
    }
    // ---- spokes: main streets that climb the slopes (the radial skeleton of the town)
    const nSp = Math.floor(R(5, 9));
    for (let m = 0; m < nSp; m++) {
        const a0 = (m + R(0.1, 0.9)) / nSp * 2 * Math.PI;
        walk(hubN, a0, { grade: R(0.3, 0.4), w: sw0 * R(1.0, 1.25), kind: 1, max: 90, CL: 34, inside: (x, z) => inDense(x, z, 0.97), progress: (px, pz, qx, qz) => (Math.hypot(qx, qz) - Math.hypot(px, pz)) * 0.9 });
    }
    // ---- contour streets: level streets along the hillside at fixed height steps
    const gradAt = (x, z) => { const e = 7; return [(ground(x + e, z) - ground(x - e, z)) / (2 * e), (ground(x, z + e) - ground(x, z - e)) / (2 * e)]; };
    let gMin = hubY, gMax = hubY;
    for (let k = 0; k < 24; k++) { const a = k * Math.PI / 12, e = edgeR(a); for (let r = 40; r < e; r += 60) { const y = ground(Math.cos(a) * r, Math.sin(a) * r); gMin = Math.min(gMin, y); gMax = Math.max(gMax, y); } }
    const lvMin = Math.max(-5, lvOf(gMin)), lvMax = Math.min(14, lvOf(gMax)), contours = [];
    const traceDir = (x, z, Y, sign) => {
        const pts = []; const CL = 26;
        for (let i = 0; i < 150; i++) {
            const g = gradAt(x, z), m = Math.hypot(g[0], g[1]); if (m < 0.05 || m > 1.2) break;
            let nx = x + (-g[1] / m) * sign * CL, nz = z + (g[0] / m) * sign * CL;
            for (let k = 0; k < 2; k++) { const y1 = ground(nx, nz), gg = gradAt(nx, nz), mm = Math.max(0.05, Math.hypot(gg[0], gg[1])); nx += gg[0] / mm * (Y - y1) / mm * 0.9; nz += gg[1] / mm * (Y - y1) / mm * 0.9; }
            if (!inDense(nx, nz, 0.97) || inDome(nx, nz) || Math.abs(ground(nx, nz) - Y) > 3.5) break;
            x = nx; z = nz; pts.push([x, z]);
        }
        return pts;
    };
    for (let lv = lvMin; lv <= lvMax; lv++) {
        const Y = hubY + lv * STEP;
        for (let j = 0; j < 72; j++) {
            const a = j * Math.PI / 36 + 0.02 * lv, ca = Math.cos(a), sa = Math.sin(a), e = edgeR(a) * 0.95;
            let prev = ground(ca * 20, sa * 20) - Y;
            for (let r = 28; r < e; r += 10) {
                const cur = ground(ca * r, sa * r) - Y;
                if ((prev < 0) !== (cur < 0)) {
                    const sx = ca * (r - 5), sz = sa * (r - 5);
                    // already a street of this level (or a spoke) within 24 units? then this arc is covered
                    if (nodeNear(sx, sz, 34, (n) => Math.abs(n.y - Y) < 9) < 0) {
                        const fw = traceDir(sx, sz, Y, 1), bk = traceDir(sx, sz, Y, -1), chain = bk.reverse().concat([[sx, sz]], fw);
                        if (chain.length >= 4) {
                            let lastId = -1;
                            for (const p of chain) {
                                let id = nodeNear(p[0], p[1], 13, (n) => Math.abs(n.y - ground(p[0], p[1])) < 6);
                                if (id < 0) id = addNode(p[0], p[1], 3 + Math.max(0, lv - lvMin), lv);
                                if (lastId >= 0 && id !== lastId) addEdge(lastId, id, sw0 * 0.8, lv, 0);
                                lastId = id;
                            }
                            contours.push(chain.length);
                        }
                    }
                    break;
                }
                prev = cur;
            }
        }
    }
    // ---- stairways and ramps between levels
    { const cand = nodes.filter(n => n.kind >= 3);
      for (const n of cand) {
          if (n.id % 3 !== 0) continue;
          let best = -1, bc = 1e18;
          for (const m of nGrid.near(n.x, n.z, 110)) {
              if (m.id === n.id || m.kind < 1 || hasEdge(n.id, m.id)) continue;
              const dy = Math.abs(m.y - n.y), d = Math.hypot(m.x - n.x, m.z - n.z); if (dy < 9 || dy > STEP * 1.8 || d < 16 || d > 108) continue;
              const c = d + 1.4 * dy + (m.kind === n.kind ? 0 : 6); if (c < bc) { bc = c; best = m.id; }
          }
          if (best >= 0) addEdge(n.id, best, R(5, 8), lvOf(n.y), 1);
      }
    }
    // ---------- v54: HOW THE CITY ENDS. The outline is cut into angular sectors; each ends its own way (and a sector can end in more than one):
    //   sprawl   - outer spur streets with low shacks that thin out with distance
    //   wall     - a curtain wall that follows the outline, towers, a gap (with gate towers) wherever a street leaves
    //   stilts   - edge buildings on piers where the ground falls away + rope-bridge lookouts thrown out over the drop
    //   terraces - strips of terraced farmland with a few huts
    //   ruins    - broken wall stubs, stumps and rubble that fade out into the wild
    const SECTOR_STYLES = ['sprawl', 'sprawl', 'wall', 'wall', 'stilts', 'terraces', 'ruins'];
    const nSec = 6 + Math.floor(R(0, 5)), secPh = R(0, 6.2832), secStyle = [];
    for (let k = 0; k < nSec; k++) { let st = pick(SECTOR_STYLES); if (k > 0 && st === secStyle[k - 1] && rnd() < 0.7) st = pick(SECTOR_STYLES); secStyle.push(st); }
    const secOf = (x, z) => Math.floor((((Math.atan2(z, x) - secPh) % 6.2832) + 6.2832) % 6.2832 / 6.2832 * nSec) % nSec;
    secStyle[secOf(passPts[0][0], passPts[0][1])] = 'wall';                       // the gate sits in a wall
    if (!secStyle.includes('sprawl')) secStyle[(secOf(passPts[0][0], passPts[0][1]) + 1 + Math.floor(rnd() * (nSec - 1))) % nSec] = 'sprawl';
    const styleAt = (x, z) => secStyle[secOf(x, z)];
    city.edgeStyles = secStyle.slice();
    { // outer spurs: short streets that carry the city out past its dense edge
        const cand = nodes.filter(n => n.kind >= 1 && n.adj.length <= 3 && Math.hypot(n.x, n.z) > edgeXZ(n.x, n.z) * 0.6 && Math.hypot(n.x, n.z) < edgeXZ(n.x, n.z) * 1.02);
        for (let i = cand.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [cand[i], cand[j]] = [cand[j], cand[i]]; }
        let nSpur = 0;
        for (const n of cand) {
            if (nSpur >= 24) break;
            const st = styleAt(n.x, n.z); if (st === 'wall' || nodeNear(n.x, n.z, 64, (m) => m.kind === 4) >= 0) continue;
            const ha = Math.atan2(n.z, n.x) + R(-0.6, 0.6), steps = Math.floor(R(4, st === 'sprawl' ? 14 : 8));
            const last = walk(n.id, ha, { grade: 0.42, w: sw0 * R(0.45, 0.62), kind: 4, max: steps, CL: 28, minProgress: 0.5, inside: (x, z) => inRim(x, z, 0.9) && styleAt(x, z) !== 'wall', progress: (px, pz, qx, qz) => (Math.hypot(qx, qz) - Math.hypot(px, pz)) * 0.9 });
            if (last !== n.id) nSpur++;
        }
        city.spurs = nSpur;
    }
    // ---- stitch stray components to the hub component so every street leads somewhere
    for (let pass = 0; pass < 14; pass++) {
        const comp = new Int32Array(nodes.length).fill(-1); let nc = 0;
        for (let i = 0; i < nodes.length; i++) if (comp[i] < 0) { const q = [i]; comp[i] = nc; while (q.length) { const a = q.pop(); for (const b of nodes[a].adj) if (comp[b] < 0) { comp[b] = nc; q.push(b); } } nc++; }
        if (nc === 1) break;
        let merged = false;
        for (let c = 0; c < nc; c++) {
            if (c === comp[0]) continue;
            const cand = [];
            for (let i = 0; i < nodes.length; i++) if (comp[i] === c) for (const m of nGrid.near(nodes[i].x, nodes[i].z, 420)) { if (comp[m.id] !== comp[0]) continue; cand.push([(nodes[i].x - m.x) ** 2 + (nodes[i].z - m.z) ** 2 + (nodes[i].y - m.y) ** 2 * 2, i, m.id]); }
            cand.sort((p, q) => p[0] - q[0]);
            for (let k = 0; k < Math.min(cand.length, 60); k++) if (addEdge(cand[k][1], cand[k][2], sw0 * 0.6, lvOf(nodes[cand[k][1]].y), 1)) { merged = true; break; }
        }
        if (!merged) break;
    }

    // v55: drop nodes left without any street (a contour chain cut by a farm dome) and renumber
    { const keep = nodes.filter(n => n.id === 0 || n.adj.length > 0);
      if (keep.length !== nodes.length) { const map = new Int32Array(nodes.length).fill(-1); keep.forEach((n, i) => { map[n.id] = i; }); for (const e of edges) { e.a = map[e.a]; e.b = map[e.b]; } for (const n of keep) n.adj = n.adj.map(x => map[x]); nodes.length = 0; keep.forEach((n, i) => { n.id = i; nodes.push(n); }); city.gateNode = map[city.gateNode]; nGrid.m.clear(); for (const n of nodes) nGrid.add(n, 0); } }
    // ---------- reserved ground + REAL BRIDGES between streets that face each other across a gully ----------
    const placed = [], bGrid = new Grid(40);
    const reserve = (o) => { o._c = null; placed.push(o); bGrid.add(o, Math.hypot(o.w, o.d) / 2 + 2); };
    reserve({ x: gx, z: gz, yaw: gyaw, w: 34, d: 60 });                    // the gate
    const pathCost = (a, b, cap) => { const dist = new Map([[a, 0]]), h = new Heap(); h.push(0, a); while (h.size) { const [dd, u] = h.pop(); if (dd > (dist.get(u) ?? 1e18)) continue; if (u === b) return dd; if (dd > cap) break; for (const v of nodes[u].adj) { const nd = dd + Math.hypot(nodes[u].x - nodes[v].x, nodes[u].z - nodes[v].z) + Math.abs(nodes[u].y - nodes[v].y) * 2; if (nd < (dist.get(v) ?? 1e18)) { dist.set(v, nd); h.push(nd, v); } } } return Infinity; };
    const gapB = [];
    { const cand = [];
      for (const n of nodes) {
          if (n.kind < 1) continue;
          for (const m of nGrid.near(n.x, n.z, 120)) {
              if (m.id <= n.id || m.kind < 1 || hasEdge(n.id, m.id)) continue;
              const d = Math.hypot(m.x - n.x, m.z - n.z); if (d < 30 || d > 118 || Math.abs(m.y - n.y) > d * 0.22) continue;
              let maxGap = 0, ok = true;
              for (let k = 1; k < 10; k++) { const t = k / 10, x = lerp(n.x, m.x, t), z = lerp(n.z, m.z, t), yd = lerp(n.y, m.y, t), g = ground(x, z); if (g > yd - 1.2) { ok = false; break; } maxGap = Math.max(maxGap, yd - g); }
              if (!ok || maxGap < 9) continue;
              const pc = pathCost(n.id, m.id, d * 3.2), ratio = pc === Infinity ? 4 : pc / d; if (ratio < 1.8) continue;
              cand.push({ n, m, d, ratio, maxGap });
          }
      }
      cand.sort((a, b) => b.ratio - a.ratio || b.maxGap - a.maxGap);
      for (const c of cand) {
          if (gapB.length >= 26) break;
          const mx = (c.n.x + c.m.x) / 2, mz = (c.n.z + c.m.z) / 2; if (gapB.some(g => Math.hypot(g.mx - mx, g.mz - mz) < 30)) continue;
          const bw = R(3.6, 5.2); gapB.push({ n: c.n, m: c.m, mx, mz, bw, d: c.d });
          addEdge(c.n.id, c.m.id, bw, lvOf(c.n.y), 2); reserve({ x: mx, z: mz, yaw: Math.atan2(c.m.z - c.n.z, c.m.x - c.n.x), w: c.d, d: bw + 8 });
      }
      // v54: lookout outposts thrown out over the fall-off of 'stilts' sectors (a rope bridge to a platform on piers)
      { let nOut = 0;
        for (const n of nodes.slice()) {
            if (nOut >= 5) break; if (n.kind < 1 || styleAt(n.x, n.z) !== 'stilts' || Math.hypot(n.x, n.z) < edgeXZ(n.x, n.z) * 0.7 || rnd() < 0.45) continue;
            const base = Math.atan2(n.z, n.x);
            for (let tr = 0; tr < 7; tr++) {
                const a = base + R(-0.8, 0.8), d = R(46, 98), x1 = n.x + Math.cos(a) * d, z1 = n.z + Math.sin(a) * d; if (!inRim(x1, z1, 0.93) || ground(x1, z1) > n.y - 6) continue;
                let ok = true, maxGap = 0; for (let k = 1; k < 10; k++) { const t = k / 10, gg = ground(lerp(n.x, x1, t), lerp(n.z, z1, t)); if (gg > n.y - 1.5) { ok = false; break; } maxGap = Math.max(maxGap, n.y - gg); }
                const mx = (n.x + x1) / 2, mz = (n.z + z1) / 2; if (!ok || maxGap < 7 || gapB.some(g => Math.hypot(g.mx - mx, g.mz - mz) < 40)) continue;
                const mid = addNode(x1, z1, 4, lvOf(n.y), n.y), bw = R(3.6, 4.8); addEdge(n.id, mid, bw, lvOf(n.y), 2);
                reserve({ x: mx, z: mz, yaw: Math.atan2(z1 - n.z, x1 - n.x), w: d, d: bw + 8 }); reserve({ x: x1, z: z1, yaw: 0, w: 18, d: 18 });
                gapB.push({ n, m: nodes[mid], mx, mz, bw, d, outpost: true }); nOut++; break;
            }
        }
        city.outposts = nOut;
      }
    }
    // a scrap bridge from (x0,z0) at height yA to (x1,z1) at height yB: mismatched planks on a truss, posts + rails + rope, tarps, brackets, guy wires, lantern, trestle legs
    const emitBridge = (x0, z0, yA, x1, z1, yB, bw, o = {}) => {
        const dx = x1 - x0, dz = z1 - z0, L = Math.hypot(dx, dz), ux = dx / L, uz = dz / L, nx = -uz, nz = ux, yaw = Math.atan2(dz, dx), pitch = Math.atan2(yB - yA, L);
        const yAt = (t) => yA + (yB - yA) * t, at = (t, off = 0) => [x0 + dx * t + nx * off, z0 + dz * t + nz * off], ext = 1.0, slope = (yB - yA) / L;
        const sx0 = x0 - ux * ext, sz0 = z0 - uz * ext, sx1 = x1 + ux * ext, sz1 = z1 + uz * ext, sy0 = yA - slope * ext, sy1 = yB + slope * ext;
        const dark = hexLin(0x3a3d40), rope = hexLin(0x2a2420), steel = hexLin(0x5d636a);
        { const nC = Math.max(1, Math.ceil((L + 2 * ext) / 10)); for (let k = 0; k < nC; k++) { const t0 = k / nC, t1 = (k + 1) / nC, ya0 = sy0 + (sy1 - sy0) * t0, ya1 = sy0 + (sy1 - sy0) * t1, ax = sx0 + (sx1 - sx0) * t0, az = sz0 + (sz1 - sz0) * t0, bx = sx0 + (sx1 - sx0) * t1, bz = sz0 + (sz1 - sz0) * t1; addCol((ax + bx) / 2, (az + bz) / 2, yaw, Math.hypot(bx - ax, bz - az) / 2 + 0.1, bw * 0.47, Math.min(ya0, ya1) - 0.9, ya0 + 0.45, ya1 + 0.45, 1); } }
        beam('baseBox', sx0, sy0 - 0.4, sz0, sx1, sy1 - 0.4, sz1, 0.8, bw * 0.94, scrapCol());                              // the deck frame
        const nP = Math.max(2, Math.ceil(L / 3.2));
        for (let k = 0; k < nP; k++) { const t = (k + 0.5) / nP, [px, pz] = at(t); P('plainBox', px, yAt(t), pz, yaw + R(-0.05, 0.05), L / nP * R(0.8, 1.0) + 0.25, R(0.3, 0.5), bw * R(0.86, 1.0), rnd() < 0.12 ? tarpCol() : scrapCol(), pitch, R(-0.05, 0.05)); }   // patchwork planks
        if (L > 14) { const nS = Math.max(2, Math.round(L / 5.5)); for (const sg of [-1, 1]) { const off = sg * (bw / 2 - 0.3); const [ax, az] = at(0, off), [bx, bz] = at(1, off); beam('plainBox', ax, yA - 3.4, az, bx, yB - 3.4, bz, 0.6, 0.6, steel); beam('plainBox', ax, yA - 0.8, az, bx, yB - 0.8, bz, 0.5, 0.5, steel);
            for (let k = 0; k < nS; k++) { const t0 = k / nS, t1 = (k + 1) / nS, [p0x, p0z] = at(t0, off), [p1x, p1z] = at(t1, off); if (k & 1) beam('plainBox', p0x, yAt(t0) - 3.4, p0z, p1x, yAt(t1) - 0.8, p1z, 0.35, 0.35, dark); else beam('plainBox', p0x, yAt(t0) - 0.8, p0z, p1x, yAt(t1) - 3.4, p1z, 0.35, 0.35, dark); } } }
        else for (const sg of [-1, 1]) for (const [t, dir] of [[0, 1], [1, -1]]) { const [qx, qz] = at(t, sg * (bw / 2 - 0.3)), [rx, rz] = at(t + dir * 3.4 / L, sg * (bw / 2 - 0.3)); beam('plainBox', qx, yAt(t) - 3.6, qz, rx, yAt(t + dir * 3.4 / L) - 0.8, rz, 0.4, 0.4, dark); }
        const nPost = Math.max(2, Math.round(L / 4.5));
        for (const sg of [-1, 1]) { const off = sg * (bw / 2 - 0.2);
            for (let k = 0; k <= nPost; k++) { const t = k / nPost, [px, pz] = at(t, off); P('plainCyl', px, yAt(t), pz, 0, 0.5, 5.2 + R(-0.2, 0.3), 0.5, dark); }
            const [ax, az] = at(0, off), [bx, bz] = at(1, off); beam('plainBox', ax, yA + 5.2, az, bx, yB + 5.2, bz, 0.4, 0.4, steel); beam('plainBox', ax, yA + 2.6, az, bx, yB + 2.6, bz, 0.2, 0.2, rope); }
        if (L > 10 && rnd() < 0.6) { const sg = rnd() < 0.5 ? -1 : 1, t0 = R(0.1, 0.4), t1 = Math.min(0.95, t0 + R(0.25, 0.5)), [ax, az] = at(t0, sg * (bw / 2 - 0.25)), [bx, bz] = at(t1, sg * (bw / 2 - 0.25)); beam('plainBox', ax, yAt(t0) + 0.4, az, bx, yAt(t1) + 0.4, bz, 2.9, 0.12, tarpCol()); }
        for (const [t, dir] of [[0, 1], [1, -1]]) { const [qx, qz] = at(t); P('baseBox', qx - ux * dir * 0.2, yAt(t) - 2.6, qz - uz * dir * 0.2, yaw, 0.8, 3.0, bw + 1.0, steel);   // brackets
            if (o.guy !== false) for (const sg of [-1, 1]) { const [wx, wz] = at(t + dir * Math.min(0.3, 9 / L), sg * (bw / 2 - 0.2)), [vx, vz] = at(t, sg * (bw / 2 - 0.2)); beam('plainBox', wx, yAt(t + dir * Math.min(0.3, 9 / L)) + 3.6, wz, vx, yAt(t) + 11, vz, 0.14, 0.14, dark); } }
        { const [mx, mz] = at(0.5, (rnd() < 0.5 ? -1 : 1) * (bw / 2 - 0.2)); P('plainCyl', mx, yAt(0.5), mz, 0, 0.5, 6.4, 0.5, dark); P('glow', mx, yAt(0.5) + 5.9, mz, 0, 2.0, 2.0, 2.0, hexLin(0xffc27a)); }   // v92: the lantern sits on its own post (it used to float mid-span, 6 units above the deck)
        let lastLeg = -99;
        for (let t = 0.12; t < 0.9; t += 0.06) {
            const [cx, cz] = at(t), g = ground(cx, cz), yd = yAt(t); if (yd - g < 7 || (t - lastLeg) * L < 13) continue;
            if (o.noLegs) continue; lastLeg = t; const lg = [];
            for (const sg of [-1, 1]) { const [lx, lz] = at(t, sg * (bw / 2 - 0.5)), gl = ground(lx, lz); P('baseBox', lx, gl - 1.5, lz, yaw, 0.9, yd - 0.8 - (gl - 1.5), 0.9, scrapCol()); lg.push([lx, lz, gl]); }
            const ym = (yd + Math.min(lg[0][2], lg[1][2])) / 2; beam('plainBox', lg[0][0], ym - 2, lg[0][1], lg[1][0], ym + 2, lg[1][1], 0.35, 0.35, dark); beam('plainBox', lg[0][0], ym + 2, lg[0][1], lg[1][0], ym - 2, lg[1][1], 0.35, 0.35, dark);
            if (yd - g > 16) { const [fx, fz] = at(t - 0.03, 0), [hx, hz] = at(t + 0.03, 0); beam('plainBox', fx, g, fz, hx, yd - 3, hz, 0.4, 0.4, dark); }
        }
    };

    // ---------- v56: JUNCTIONS WHERE STREETS CROSS ----------
    // Two streets that cross in plan without sharing a node used to just overlap: z-fighting road ribbons at the same height, or - when a few units apart - one street's
    // retaining wall / embankment standing in the other (the player is blocked, the drones path through it). Every such crossing (not a real bridge, < 14 apart in height)
    // becomes a junction node (reusing an endpoint when it is within 4 units) at the mean height, and both streets are split there.
    { const segInt = (a, b, c, d) => { const rx = b.x - a.x, rz = b.z - a.z, sx = d.x - c.x, sz = d.z - c.z, den = rx * sz - rz * sx; if (Math.abs(den) < 1e-9) return null; const t = ((c.x - a.x) * sz - (c.z - a.z) * sx) / den, u = ((c.x - a.x) * rz - (c.z - a.z) * rx) / den; return t > 0.01 && t < 0.99 && u > 0.01 && u < 0.99 ? [t, u] : null; };
      const g2 = new Map(), K = (i, j) => i * 7919 + j; edges.forEach((e, i) => { if (e.t === 2) return; const a = nodes[e.a], b = nodes[e.b]; for (let x = Math.floor(Math.min(a.x, b.x) / 40); x <= Math.floor(Math.max(a.x, b.x) / 40); x++) for (let z = Math.floor(Math.min(a.z, b.z) / 40); z <= Math.floor(Math.max(a.z, b.z) / 40); z++) { const k = K(x, z); let l = g2.get(k); if (!l) g2.set(k, l = []); l.push(i); } });
      const seenP = new Set(), cross = []; for (const l of g2.values()) for (let i = 0; i < l.length; i++) for (let j = i + 1; j < l.length; j++) {
          const ia = Math.min(l[i], l[j]), ib = Math.max(l[i], l[j]), key = ia * 1000003 + ib; if (seenP.has(key)) continue; seenP.add(key);
          const ea = edges[ia], eb = edges[ib]; if (ea.a === eb.a || ea.a === eb.b || ea.b === eb.a || ea.b === eb.b) continue;
          const A = nodes[ea.a], B = nodes[ea.b], C = nodes[eb.a], D = nodes[eb.b], r = segInt(A, B, C, D); if (!r) continue;
          const ya = A.y + (B.y - A.y) * r[0], yb = C.y + (D.y - C.y) * r[1]; if (Math.abs(ya - yb) >= 14) continue;
          const La0 = Math.hypot(B.x - A.x, B.z - A.z), Lb0 = Math.hypot(D.x - C.x, D.z - C.z), ends = [[A.y, r[0] * La0], [B.y, (1 - r[0]) * La0], [C.y, r[1] * Lb0], [D.y, (1 - r[1]) * Lb0]];
          let lo = -1e9, hi = 1e9; for (const [ye, le] of ends) { lo = Math.max(lo, ye - 0.45 * le); hi = Math.min(hi, ye + 0.45 * le); }   // keep the four half-streets walkable
          if (lo > hi || Math.abs(B.y - A.y) > 0.5 * La0 || Math.abs(D.y - C.y) > 0.5 * Lb0) continue;   // stairs / over-steep streets: no junction can make those walkable
          const mean = (ya + yb) / 2, yj = Math.min(hi, Math.max(lo, mean));
          cross.push({ ia, ib, t: r[0], u: r[1], x: A.x + (B.x - A.x) * r[0], z: A.z + (B.z - A.z) * r[0], y: yj, dy: Math.abs(ya - yb) }); }
      cross.sort((p, q) => p.ia - q.ia || p.ib - q.ib || p.t - q.t);
      const splits = new Map(), pushSplit = (ei, t, node) => { const e = edges[ei]; if (node === e.a || node === e.b) return; let l = splits.get(ei); if (!l) splits.set(ei, l = []); l.push({ t, node }); };
      let nJ = 0; for (const c of cross) {
          const ea = edges[c.ia], eb = edges[c.ib], La = Math.hypot(nodes[ea.b].x - nodes[ea.a].x, nodes[ea.b].z - nodes[ea.a].z), Lb = Math.hypot(nodes[eb.b].x - nodes[eb.a].x, nodes[eb.b].z - nodes[eb.a].z);
          const dyc = c.dy, minL = Math.min(c.t * La, (1 - c.t) * La, c.u * Lb, (1 - c.u) * Lb);
          if (minL < 2 || (minL < 4 && dyc > 2.5)) continue;     // a sliver of street between two heights would be a cliff: leave this one alone
          let j = -1; { const near = nodeNear(c.x, c.z, 2.5, (n) => n.junction); if (near >= 0) j = near; }
          if (j < 0) { j = addNode(c.x, c.z, 1, ea.lvl, c.y); nodes[j].junction = true; } nJ++;
          pushSplit(c.ia, c.t, j); pushSplit(c.ib, c.u, j); }
      let nSplit = 0; for (const [ei, list] of splits) {
          const e = edges[ei]; list.sort((p, q) => p.t - q.t); const chain = [e.a]; for (const sp of list) if (chain[chain.length - 1] !== sp.node) chain.push(sp.node); if (chain[chain.length - 1] !== e.b) chain.push(e.b); else if (chain.length > 1 && chain[chain.length - 2] === e.b) chain.pop();
          if (chain.length < 3) continue; const a0 = e.a, b0 = e.b; nodes[a0].adj = nodes[a0].adj.filter(q => q !== b0); nodes[b0].adj = nodes[b0].adj.filter(q => q !== a0);
          e.b = chain[1]; nodes[chain[0]].adj.push(chain[1]); nodes[chain[1]].adj.push(chain[0]);
          for (let q = 1; q + 1 < chain.length; q++) { const a = chain[q], b = chain[q + 1]; if (a === b || nodes[a].adj.includes(b)) continue; edges.push({ a, b, w: e.w, lvl: e.lvl, t: e.t }); nodes[a].adj.push(b); nodes[b].adj.push(a); nSplit++; } }
      city.junctionsAdded = nJ; }

    // ---------- STREET SURFACES + LAMPS ----------
    const cobble = hexLin(0x6c6a66), cobble2 = hexLin(0x77746e), asphalt = hexLin(0x4a4a4c), rail = hexLin(0x55595e);
    const segGrid = new Grid(60), segs = [];
    const flatAt = (x, z) => { const g = gradAt(x, z); return Math.hypot(g[0], g[1]); };
    const flatEdges = [];
    for (const e of edges) {
        const A = nodes[e.a], B = nodes[e.b], dx = B.x - A.x, dz = B.z - A.z, L = Math.hypot(dx, dz); if (L < 1) continue;
        const yawE = Math.atan2(dz, dx), nx = -dz / L, nz = dx / L;
        const seg = { ax: A.x, az: A.z, bx: B.x, bz: B.z, ya: A.y, yb: B.y, w: e.w, yaw: yawE, L, lvl: e.lvl, t: e.t, mx: (A.x + B.x) / 2, mz: (A.z + B.z) / 2, nx, nz };
        segs.push(seg); segGrid.add({ x: seg.mx, z: seg.mz, seg }, L / 2 + e.w);
        if (e.t === 2) continue;                       // a bridge: drawn by the bridge code
        const nSub = Math.max(1, Math.ceil(L / 26)), steep = Math.abs(B.y - A.y) / L > 0.38 || e.t === 1 && Math.abs(B.y - A.y) / L > 0.3;
        const main = e.w > sw0 * 1.2, col = main ? asphalt : (rnd() < 0.5 ? cobble : cobble2);
        if (!steep) { flatEdges.push({ e, A, B, L, main, col: jit(col, 0.06) }); continue; }   // v54: drawn below as one continuous ribbon
        const stairCol = jit(cobble2, 0.08);
        for (let k = 0; k < nSub; k++) {   // a stairway: steps with rails
            const t0 = k / nSub, t1 = (k + 1) / nSub, x0 = A.x + dx * t0, z0 = A.z + dz * t0, x1 = A.x + dx * t1, z1 = A.z + dz * t1, y0 = ground(x0, z0), y1 = ground(x1, z1), sl = Math.hypot(x1 - x0, z1 - z0), hw = e.w / 2;
            const rise = y1 - y0, ns = Math.max(2, Math.round(Math.abs(rise) / 2.0));
            skipCol = true;
            for (let q = 0; q < ns; q++) { const u = (q + 0.5) / ns, yy = lerp(y0, y1, q / ns); P('plainBox', lerp(x0, x1, u), yy - 0.4, lerp(z0, z1, u), yawE, sl / ns + 0.15, Math.abs(rise) / ns + 1.0, e.w * 0.9, jit(stairCol, 0.04)); }
            skipCol = false;
            addCol((x0 + x1) / 2, (z0 + z1) / 2, yawE, sl / 2 + 0.15, e.w * 0.46, Math.min(y0, y1) - 1.5, y0 + 0.5, y1 + 0.5, 1);   // the flight as a ramp the player can climb
            for (const sg of [-1, 1]) { const ox = nx * hw * 0.95 * sg, oz = nz * hw * 0.95 * sg; beam('plainBox', x0 + ox, y0 + 4.2, z0 + oz, x1 + ox, y1 + 4.2, z1 + oz, 0.4, 0.4, rail); P('plainCyl', x0 + ox, y0, z0 + oz, 0, 0.45, 4.2, 0.45, rail); }
        }
    }
    // ---- v54: the flat streets as ONE continuous ribbon mesh (asphalt / cobble, curbs, centre dashes, retaining skirts, junction pads).
    // Before, every street was a chain of separately jittered boxes with different thicknesses: they read as random blocks, and ~27% of their
    // length ran straight through buildings (the lots never looked at the other streets - see accept() below).
    const road = city.road = { pos: [], nor: [], col: [], idx: [] };
    const UP = [0, 1, 0], skirtCol = hexLin(0x55524c), curbCol = hexLin(0x8b887e), paintCol = hexLin(0xd9cc84);
    const quad = (p0, p1, p2, p3, color, hint) => {
        const ax = p1[0] - p0[0], ay = p1[1] - p0[1], az = p1[2] - p0[2], bx = p3[0] - p0[0], by = p3[1] - p0[1], bz = p3[2] - p0[2];
        let nx = ay * bz - az * by, ny = az * bx - ax * bz, nz = ax * by - ay * bx; const l = Math.hypot(nx, ny, nz) || 1; nx /= l; ny /= l; nz /= l;
        let q = [p0, p1, p2, p3]; if (nx * hint[0] + ny * hint[1] + nz * hint[2] < 0) { q = [p0, p3, p2, p1]; nx = -nx; ny = -ny; nz = -nz; }
        const base = road.pos.length / 3; for (const p of q) { road.pos.push(p[0], p[1], p[2]); road.nor.push(nx, ny, nz); road.col.push(color[0], color[1], color[2]); }
        road.idx.push(base, base + 1, base + 2, base, base + 2, base + 3);
    };
    {
        const NN = nodes.length, flatDeg = new Int32Array(NN), nodeHW = new Float32Array(NN), nodeCol = new Array(NN), nodeY = new Float32Array(NN), bridgeNode = new Uint8Array(NN);
        for (const f of flatEdges) for (const id of [f.e.a, f.e.b]) { flatDeg[id]++; if (f.e.w / 2 > nodeHW[id]) { nodeHW[id] = f.e.w / 2; nodeCol[id] = f.col; } }
        for (const e of edges) if (e.t === 2) { bridgeNode[e.a] = 1; bridgeNode[e.b] = 1; }
        for (let i = 0; i < NN; i++) { if (!flatDeg[i]) continue; const n = nodes[i], r = nodeHW[i]; let m = ground(n.x, n.z); for (let k = 0; k < 8; k++) { const a = k * Math.PI / 4; m = Math.max(m, ground(n.x + Math.cos(a) * r, n.z + Math.sin(a) * r)); } nodeY[i] = bridgeNode[i] ? n.y : m + 0.12; if (!bridgeNode[i]) n.y = nodeY[i]; }   // v55: the node now sits ON the street surface (lamps, doors, drones follow it)
        for (const f of flatEdges) {
            const { e, A, B, L, main, col } = f, hw = e.w / 2, ux = (B.x - A.x) / L, uz = (B.z - A.z) / L, nx = -uz, nz = ux, n = Math.max(2, Math.ceil(L / 7)), seg = L / n, S = [];
            for (let k = 0; k <= n; k++) { const t = k / n, x = A.x + (B.x - A.x) * t, z = A.z + (B.z - A.z) * t, gl = ground(x + nx * hw, z + nz * hw), gr = ground(x - nx * hw, z - nz * hw); S.push({ x, z, gl, gr, raw: Math.max(gl, gr, ground(x, z)) }); }
            let sm = S.map(q => q.raw); for (let it = 0; it < 2; it++) { const o = sm; sm = o.map((v, i) => i === 0 || i === n ? v : (o[i - 1] + 2 * v + o[i + 1]) / 4); }
            const yA = nodeY[e.a], yB = nodeY[e.b];
            for (let k = 0; k <= n; k++) { const t = k / n, lin = yA + (yB - yA) * t; S[k].y = k === 0 ? yA : k === n ? yB : Math.max(lin, sm[k] + 0.12); }
            const cutA = flatDeg[e.a] >= 3 ? nodeHW[e.a] * 1.05 : 0, cutB = flatDeg[e.b] >= 3 ? nodeHW[e.b] * 1.05 : 0, cw = 0.6;
            for (let k = 0; k < n; k++) {
                const a = S[k], b = S[k + 1], curb = k * seg >= cutA && (k + 1) * seg <= L - cutB, lift = curb ? 0.2 : 0;
                const aL = [a.x + nx * hw, a.y, a.z + nz * hw], aR = [a.x - nx * hw, a.y, a.z - nz * hw], bL = [b.x + nx * hw, b.y, b.z + nz * hw], bR = [b.x - nx * hw, b.y, b.z - nz * hw];
                quad(aL, aR, bR, bL, col, UP);
                const lo = Math.min(a.gl, a.gr, b.gl, b.gr);
                // retaining skirts down to the ground on both sides
                const dL = Math.min(a.gl, b.gl) - 1.6, dR = Math.min(a.gr, b.gr) - 1.6;
                quad([aL[0], a.y + lift, aL[2]], [bL[0], b.y + lift, bL[2]], [bL[0], Math.min(dL, b.y - 0.6), bL[2]], [aL[0], Math.min(dL, a.y - 0.6), aL[2]], skirtCol, [nx, 0, nz]);
                quad([aR[0], a.y + lift, aR[2]], [bR[0], b.y + lift, bR[2]], [bR[0], Math.min(dR, b.y - 0.6), bR[2]], [aR[0], Math.min(dR, a.y - 0.6), aR[2]], skirtCol, [-nx, 0, -nz]);
                if (curb) for (const sg of [-1, 1]) {
                    const o1 = hw, o0 = hw - cw, hx = nx * sg, hz = nz * sg;
                    quad([a.x + hx * o0, a.y + 0.2, a.z + hz * o0], [a.x + hx * o1, a.y + 0.2, a.z + hz * o1], [b.x + hx * o1, b.y + 0.2, b.z + hz * o1], [b.x + hx * o0, b.y + 0.2, b.z + hz * o0], curbCol, UP);
                    quad([a.x + hx * o0, a.y, a.z + hz * o0], [b.x + hx * o0, b.y, b.z + hz * o0], [b.x + hx * o0, b.y + 0.2, b.z + hz * o0], [a.x + hx * o0, a.y + 0.2, a.z + hz * o0], curbCol, [-hx, 0, -hz]);
                }
                if (main && curb && (k & 1) === 0) { const q0 = 0.2, q1 = 0.78, c0 = [a.x + (b.x - a.x) * q0, a.y + (b.y - a.y) * q0 + 0.04, a.z + (b.z - a.z) * q0], c1 = [a.x + (b.x - a.x) * q1, a.y + (b.y - a.y) * q1 + 0.04, a.z + (b.z - a.z) * q1];
                    quad([c0[0] + nx * 0.18, c0[1], c0[2] + nz * 0.18], [c0[0] - nx * 0.18, c0[1], c0[2] - nz * 0.18], [c1[0] - nx * 0.18, c1[1], c1[2] - nz * 0.18], [c1[0] + nx * 0.18, c1[1], c1[2] + nz * 0.18], paintCol, UP); }
                addCol((a.x + b.x) / 2, (a.z + b.z) / 2, Math.atan2(b.z - a.z, b.x - a.x), seg / 2 + 0.4, hw + 0.4, lo - 1.5, a.y + 0.05, b.y + 0.05, 1);
            }
        }
        for (let i = 0; i < NN; i++) {   // junction / bend pads: an octagon over the node, a hair above the ribbons' ends
            if (flatDeg[i] < 2) continue; const n = nodes[i], r = nodeHW[i] * 1.04, y = nodeY[i] + 0.03, P8 = []; for (let k = 0; k < 8; k++) { const a = k * Math.PI / 4; P8.push([n.x + Math.cos(a) * r, y, n.z + Math.sin(a) * r]); }
            const c = [n.x, y, n.z]; for (let k = 0; k < 8; k += 2) quad(c, P8[k], P8[(k + 1) % 8], P8[(k + 2) % 8], nodeCol[i], UP);
        }
    }
    // lamps at nodes (every other node with degree >= 2)
    for (let i = 0; i < nodes.length; i++) { const n = nodes[i]; if (n.adj.length < 2 || (i & 1)) continue; const m = nodes[n.adj[0]], dx = m.x - n.x, dz = m.z - n.z, L = Math.hypot(dx, dz) || 1, off = 8 + (edges.find(e => e.a === i || e.b === i) || { w: 14 }).w * 0.4, ox = -dz / L * off, oz = dx / L * off, gl = ground(n.x + ox, n.z + oz), by = Math.min(gl, n.y) - 1.5; P('plainCyl', n.x + ox, by, n.z + oz, 0, 1.3, n.y + 20 - by, 1.3, cols.trim); P('glow', n.x + ox, n.y + 20, n.z + oz, 0, 3.0, 3.0, 3.0, jit(hexLin(0xffe2a8), 0.2)); }   // v92: 20 units tall (was 11, barely above the 8.5-unit eye)

    // ---------- foundations ----------
    // v54: 5x5 samples over the footprint (and a margin: the far terrain LODs are coarse), skirts that go well below the lowest ground
    const found = (x, z, w, d, yaw, yTop, color) => { const [lo, hi] = lowestUnder(x, z, w, d, yaw), sk = skirt(lo, hi); if (yTop - lo > 0.7) P('baseBox', x, lo - sk, z, yaw, w + 0.8, yTop - lo + sk + 0.2, d + 0.8, color || cols.trim); };

    // ---------- HUB PLAZA + LANDMARK ----------
    const hubH = R(420, 720), kw = clamp(Math.sqrt(hubH / 230), 0.9, 1.6), fl = hubY;
    let hubR = plazaR;
    P('plainCyl', 0, fl - 14, 0, 0, plazaR * 2, 15.9, plazaR * 2, jit(cobble2, 0.1));
    P('plainCyl', 0, fl + 0.4, 0, 0, plazaR * 1.92, 0.3, plazaR * 1.92, jit(hexLin(0x9a968c), 0.1));
    if (hubKind === 'spire') {
        const w0 = R(34, 44) * kw * 1.3; hubR = Math.max(hubR, w0 * 0.8); P('plainCyl', 0, fl, 0, 0, w0, 18, w0, cols.trim); P('wallCyl', 0, fl + 18, 0, 0, w0 * 0.74, hubH * 0.5, w0 * 0.74, jit(cols.walls[0], 0.1));
        P('wallCyl', 0, fl + 18 + hubH * 0.5, 0, 0, w0 * 0.5, hubH * 0.3, w0 * 0.5, jit(cols.walls[1], 0.1)); P('cone', 0, fl + 18 + hubH * 0.8, 0, 0, w0 * 0.42, hubH * 0.32, w0 * 0.42, jit(cols.roofs[0], 0.1));
        for (let k = 0; k < 4; k++) P('glow', 0, fl + 18 + hubH * (0.3 + k * 0.15), 0, 0, w0 * 0.8 - k * 4, 1.6, w0 * 0.8 - k * 4, accent);
        P('glow', 0, fl + 18 + hubH * 1.1, 0, 0, 2.4, 22, 2.4, accent2);
        for (let k = 0; k < 6; k++) { const a = k * Math.PI / 3, rr = w0 * 0.62; beam('plainBox', Math.cos(a) * rr, fl + 20, Math.sin(a) * rr, Math.cos(a) * rr * 0.3, fl + 18 + hubH * 0.45, Math.sin(a) * rr * 0.3, 1.2, 1.2, cols.trim); }   // flying buttresses
    } else if (hubKind === 'domeHall') {
        const w0 = R(84, 104); hubR = Math.max(hubR, w0 * 1.5); P('plainCyl', 0, fl, 0, 0, w0, 34, w0, jit(cols.walls[2], 0.08)); P('dome', 0, fl + 34, 0, 0, w0 * 0.95, w0 * 0.62, w0 * 0.95, jit(cols.roofs[0], 0.1)); P('glow', 0, fl + 34 + w0 * 0.62, 0, 0, 3, 18, 3, accent);
        for (let k = 0; k < 4; k++) { const a = k * Math.PI / 2 + Math.PI / 4, mx = Math.cos(a) * w0 * 1.0, mz = Math.sin(a) * w0 * 1.0, mh = 80 + hubH * 0.12; found(mx, mz, 8, 8, 0, fl, cols.trim); P('plainCyl', mx, fl, mz, 0, 5, mh, 5, cols.walls[3]); P('cone', mx, fl + mh, mz, 0, 6, 22, 6, cols.roofs[1]); P('glow', mx, fl + mh + 20, mz, 0, 1.4, 6, 1.4, accent2); }
    } else if (hubKind === 'ziggurat') {
        let w0 = R(112, 136), y = fl; hubR = Math.max(hubR, w0 * 0.75); const nT = 7; for (let k = 0; k < nT; k++) { const hh = hubH / nT; P('wallBox', 0, y, 0, 0, w0, hh, w0, jit(cols.walls[k % cols.walls.length], 0.08)); P('glow', 0, y + hh - 0.6, 0, 0, w0 + 1, 1, w0 + 1, accent); y += hh; w0 *= 0.74; }
        P('glow', 0, y, 0, 0, 5, 30, 5, accent2);
    } else if (hubKind === 'clock') {
        const w0 = R(36, 46) * kw * 1.3; hubR = Math.max(hubR, w0); P('wallBox', 0, fl, 0, 0, w0, hubH * 0.8, w0, jit(cols.walls[0], 0.08)); P('gable', 0, fl + hubH * 0.8, 0, 0, w0 * 1.1, hubH * 0.22, w0 * 1.1, cols.roofs[0]);
        for (const [ox, oz, yy] of [[w0 / 2 + 0.6, 0, 0], [-w0 / 2 - 0.6, 0, 0], [0, w0 / 2 + 0.6, 1], [0, -w0 / 2 - 0.6, 1]]) P('glow', ox, fl + hubH * 0.66, oz, yy ? Math.PI / 2 : 0, 1.2, w0 * 0.5, w0 * 0.5, jit(hexLin(0xfff2c0), 0.1));
    } else {   // lightTree: a trunk with branching platforms and glowing orbs
        const tr = R(22, 30); hubR = Math.max(hubR, 78); P('plainCyl', 0, fl, 0, 0, tr, hubH * 0.7, tr, jit(cols.walls[3], 0.1));
        for (let k = 0; k < 16; k++) { const a = k * 2.399, rr = 24 + (k % 5) * 12, y = fl + hubH * (0.25 + 0.05 * k); P('plainBox', Math.cos(a) * rr * 0.5, y, Math.sin(a) * rr * 0.5, a, rr, 2.4, 6, cols.trim); P('glow', Math.cos(a) * rr, y + 2.4, Math.sin(a) * rr, 0, 7, 7, 7, k & 1 ? accent : accent2); }
        P('glow', 0, fl + hubH * 1.05, 0, 0, 16, 16, 16, accent);
    }
    reserve({ x: 0, z: 0, yaw: 0, w: hubR * 2 + 10, d: hubR * 2 + 10 });
    city.poi.plazas.push({ x: 0, z: 0, y: fl, r: plazaR, kind: 'hub' });
    city.hubHeight = hubH;
    // hub plaza decor: reflecting pool + arch bridge, market stalls
    if (rnd() < 0.8) { const pr = plazaR * 0.55, px = plazaR * 0.35, pz = plazaR * 0.1; P('glow', px, fl + 0.55, pz, 0, pr, 0.4, pr * 0.7, jit(accent, 0.2)); P('plainBox', px, fl + 0.2, pz, 0, pr + 4, 1.2, pr * 0.7 + 4, cols.trim); P('arch', px, fl + 1.5, pz, 0, pr * 0.7 + 4, 9, 7, jit(cols.walls[2], 0.08)); }
    for (let k = 0; k < 12; k++) { const a = R(0, 6.28), rr = plazaR * R(0.55, 0.92), x = Math.cos(a) * rr, z = Math.sin(a) * rr; P('plainBox', x, fl, z, a, 8, 3.2, 5, jit(cols.walls[k % 5], 0.1)); P('plainBox', x, fl + 3.2, z, a, 9.4, 0.5, 6.4, tarpCol()); city.poi.views.push({ x, z, y: fl, kind: 'stall' }); }

    // ---------- DENSITY FIELD: several clusters of tall stacks, falling off toward the edge of the city ----------
    const noiseF = R(0.004, 0.009), nph = [R(0, 99), R(0, 99), R(0, 99)];
    const vn = (x, z) => 0.5 + 0.25 * Math.sin(x * noiseF + nph[0]) * Math.cos(z * noiseF * 1.3 + nph[1]) + 0.25 * Math.sin((x + z) * noiseF * 2.1 + nph[2]);
    const peaks = []; { const nPk = Math.floor(R(3, 7)); for (let k = 0, tries = 0; k < nPk && tries < 80; tries++) { const a = R(0, 6.2832), rr = R(0.1, 0.78) * edgeR(a), x = Math.cos(a) * rr, z = Math.sin(a) * rr; if (flatAt(x, z) > 0.75) continue; if (peaks.some(p => Math.hypot(p.x - x, p.z - z) < 160)) continue; peaks.push({ x, z, str: R(0.7, 1), sg: R(120, 230) }); k++; } }
    const D = (x, z) => { const r = Math.hypot(x, z), e = edgeXZ(x, z); let d = Math.pow(Math.max(0, 1 - r / e), 1.1) * 0.82; for (const p of peaks) { const q = ((x - p.x) ** 2 + (z - p.z) ** 2) / (2 * p.sg * p.sg); if (q < 6) d = Math.max(d, p.str * Math.exp(-q)); } return clamp(d + (vn(x, z) - 0.5) * 0.3, 0, 1); };
    const distKind = (x, z) => { const v = vn(x * 1.7 + 40, z * 1.7), r = Math.hypot(x, z) / edgeXZ(x, z); if (r > 0.82 && v > 0.55) return 'work'; if (v < 0.3) return 'work'; if (v > 0.66 && r < 0.65) return 'market'; return 'home'; };

    // ---------- BUILDINGS ----------
    const makeBuilding = (x, z, yaw, w, d, lvl, forceTower) => {
        const dd = D(x, z), r = rnd(), dk = distKind(x, z), belt = Math.hypot(x, z) > edgeXZ(x, z) * 0.96;
        let kind = 'house', floors;
        if (forceTower) { kind = 'tower'; floors = Math.round(R(34, 62)); }
        else if (belt) floors = 2 + Math.floor(rnd() * 4);
        else if (dd > 0.5 && r < 0.08 + (dd - 0.5) * 1.3) { kind = 'tower'; floors = Math.round(lerp(18, 48, clamp((dd - 0.5) / 0.5, 0, 1)) * R(0.75, 1.15)); w *= 1.12; d *= 1.12; }
        else if (dk === 'work' && r < 0.5) { if (rnd() < 0.28) { kind = 'tank'; floors = 2 + Math.floor(rnd() * 3); const q = Math.min(w, d) * 0.85; w = d = q; } else { kind = 'workshop'; floors = 2 + Math.floor(rnd() * 4); w *= 1.15; d *= 1.1; } }
        else if (dk === 'market' && r < 0.5) { kind = 'shop'; floors = Math.max(3, Math.round(lerp(4, 11, dd) * R(0.8, 1.2))); }
        else floors = Math.max(3, Math.round(lerp(4, 16, Math.pow(dd, 0.9)) * R(0.7, 1.25)));
        const out = Math.hypot(x, z) / edgeXZ(x, z);
        if (!forceTower && out > 1.0) { if (kind === 'tower' || kind === 'shop') kind = 'house'; floors = Math.max(1, Math.min(floors, Math.round(lerp(5, 1, clamp((out - 1) / 0.7, 0, 1))))); }   // v54: fade out
        return { x, z, yaw, w, d, floors, fh: R(17, 18.4), kind, lvl, ci: Math.floor(rnd() * 6), dk, dd, belt, stilts: out > 0.8 && styleAt(x, z) === 'stilts' };
    };
    // v54: past 90% of the outline the lots thin out (sprawl keeps more), and a wall sector keeps everything inside its wall
    const edgeFall = (x, z) => { const out = Math.hypot(x, z) / edgeXZ(x, z); if (out <= 0.9) return false; const st = styleAt(x, z); if (st === 'wall') return out > 1.02; return rnd() < clamp((out - 0.9) * (st === 'sprawl' ? 1.1 : 1.9), 0, 0.93); };
    const slopeOK = (b) => { const [lo, hi] = lowestUnder(b.x, b.z, b.w, b.d, b.yaw); b.yLo = lo; b.yHi = hi; b.y0 = lo + (hi - lo) * 0.5 + 0.3; return hi - lo < 12 + 0.5 * Math.min(b.w, b.d) + (b.belt ? 6 : 0) + (b.stilts ? 10 : 0); };
    const free = (b, pad) => { for (const o of bGrid.near(b.x, b.z, Math.hypot(b.w, b.d) / 2 + 4)) if (obbOverlap(b, o, pad)) return false; return true; };
    const nearStreet = (x, z, minD) => { for (const o of segGrid.near(x, z, 70)) { const sg = o.seg; if (sg.t === 2) continue; if (distSeg(x, z, sg.ax, sg.az, sg.bx, sg.bz) < sg.w / 2 + minD) return true; } return false; };
    const nearestSeg = (x, z) => { let best = null, bd = 1e18; for (const o of segGrid.near(x, z, 90)) { const sg = o.seg; if (sg.t === 2) continue; const dd = distSeg(x, z, sg.ax, sg.az, sg.bx, sg.bz); if (dd < bd) { bd = dd; best = sg; } } return best ? { sg: best, d: bd } : null; };
    const limAt = (x, z) => rimXZ(x, z) * 0.93;
    const onStreet = (b) => {   // v54: does any ground street (or stair) run through this lot?
        const rr = Math.hypot(b.w, b.d) / 2 + 4;
        for (const o of segGrid.near(b.x, b.z, rr + 30)) {
            const sg = o.seg; if (sg.t === 2 || distSeg(b.x, b.z, sg.ax, sg.az, sg.bx, sg.bz) > rr + sg.w / 2) continue;
            const n = Math.max(1, Math.ceil(sg.L / 3));
            for (let k = 0; k <= n; k++) if (inObb(b, sg.ax + (sg.bx - sg.ax) * k / n, sg.az + (sg.bz - sg.az) * k / n, sg.w / 2 + 0.3)) return true;
        }
        return false;
    };
    const accept = (b) => { if (city.buildings.length >= maxB) return false; if (!slopeOK(b)) return false; if (!free(b, 0.35)) return false; if (onStreet(b)) return false; b._c = null; b.top = b.y0 + b.floors * b.fh; city.buildings.push(b); placed.push(b); bGrid.add(b, Math.hypot(b.w, b.d) / 2 + 2); return true; };
    for (const dm of domes) { reserve(dm.box); reserve(dm.rampBox); }   // v55: the farm domes were chosen before the streets; nothing else may grow on them
    // the stacks: clusters of 3-5 very tall towers built close together (bridged later); positioned on the density peaks
    city.megas = 0;
    for (const pk of peaks) {
        if (rnd() < 0.2 || city.megas >= 5) continue;
        const n = 3 + Math.floor(rnd() * 3), base = R(0, 6.28); let got = 0;
        for (let k = 0, tries = 0; k < n && tries < 40; tries++) {
            const a = base + k * 2.0 + R(-0.5, 0.5), rr = k === 0 ? 0 : R(86, 130), x = pk.x + Math.cos(a) * rr, z = pk.z + Math.sin(a) * rr;
            if (!inDense(x, z, 0.85)) continue;
            const b = makeBuilding(x, z, base * 0.3 + R(-0.12, 0.12), R(58, 88), R(58, 88), 0, true); b.mega = city.megas + 1;
            if (accept(b)) { k++; got++; } 
        }
        if (got >= 2) city.megas++;
    }
    // frontage lots along every street (both sides), tight
    for (const sg of segs) {
        if (sg.t === 2 || Math.abs(sg.yb - sg.ya) / sg.L > 0.36) continue;
        const dx = (sg.bx - sg.ax) / sg.L, dz = (sg.bz - sg.az) / sg.L, nx = -dz, nz = dx;
        for (const side of [1, -1]) {
            let t = rnd() * 10;
            while (t < sg.L) {
                const dd0 = D(sg.mx, sg.mz), w = R(24, 54 + 22 * dd0), d = R(30, 60 + 18 * dd0), tc = t + w / 2; t += w + R(0.2, 1.0);
                if (tc > sg.L) break;
                const off = sg.w / 2 + d / 2 + R(0.5, 1.5), x = sg.ax + dx * tc + nx * side * off, z = sg.az + dz * tc + nz * side * off;
                if (Math.hypot(x, z) > limAt(x, z) || edgeFall(x, z)) continue;
                if (!accept(makeBuilding(x, z, sg.yaw, w, d, sg.lvl, false))) { const w2 = w * 0.8, d2 = d * 0.65, off2 = sg.w / 2 + d2 / 2 + 0.8; accept(makeBuilding(sg.ax + dx * tc + nx * side * off2, sg.az + dz * tc + nz * side * off2, sg.yaw, w2, d2, sg.lvl, false)); }
            }
        }
    }
    // interior fill: random lots between streets, only where a street is near enough to reach the door
    for (let tries = 0; tries < 20000 && city.buildings.length < maxB; tries++) {
        const a = R(0, 6.2832), rr = (RcMax * 1.25) * Math.sqrt(rnd()), x = Math.cos(a) * rr, z = Math.sin(a) * rr, w = R(20, 44), d = R(20, 44);
        if (Math.hypot(x, z) > limAt(x, z) || edgeFall(x, z)) continue;
        const ns = nearestSeg(x, z); if (!ns || ns.d > 130 || ns.d < ns.sg.w / 2 + Math.max(w, d) * 0.5 + 0.5) continue;
        accept(makeBuilding(x, z, ns.sg.yaw + R(-0.1, 0.1), w, d, 0, false));
    }

    // ---------- v54: edge features per sector ----------
    const nearAnyStreet = (x, z, pad) => { for (const o of segGrid.near(x, z, 60)) { const sg = o.seg; if (sg.t === 2) continue; if (distSeg(x, z, sg.ax, sg.az, sg.bx, sg.bz) < sg.w / 2 + pad) return true; } return false; };
    const stone = hexLin(0x6e6a62), stoneD = hexLin(0x57534c);
    const wallTower = (x, z, yTop, a) => {
        const o = { x, z, yaw: 0, w: 22, d: 22 }; if (!free(o, 0.4)) return; reserve(o); const lo = ground(x, z) - 9;
        P('plainCyl', x, lo, z, 0, 18, yTop + 16 - lo, 18, jit(stone, 0.1)); P('plainCyl', x, yTop + 16, z, 0, 22, 2, 22, jit(stoneD, 0.1)); P('cone', x, yTop + 18, z, 0, 20, 20, 20, cols.roofs[0]);
        P('glow', x + Math.cos(a) * 9.4, yTop + 8, z + Math.sin(a) * 9.4, 0, 2.4, 2.4, 2.4, hexLin(0xffc27a)); city.poi.views.push({ x, z, y: yTop + 16.4, kind: 'lookout' });
    };
    // v55: where the built-up city REALLY ends, per direction (buildings + farm domes), so walls hug it instead of standing at the footprint's nominal edge
    const NB = 128, extT = new Float32Array(NB), binOf = (a) => Math.floor((((a % 6.2832) + 6.2832) % 6.2832) / 6.2832 * NB) % NB;
    { const push = (x, z, rad) => { const rr = Math.hypot(x, z), a = Math.atan2(z, x), span = Math.max(1, Math.ceil(Math.atan2(rad, Math.max(rr, 1)) / (6.2832 / NB))), v = rr + rad, b0 = binOf(a); for (let j = -span; j <= span; j++) { const k = (b0 + j + NB) % NB; if (v > extT[k]) extT[k] = v; } };
      for (const b of city.buildings) push(b.x, b.z, Math.hypot(b.w, b.d) / 2); for (const dm of domes) push(dm.x, dm.z, dm.PR * 1.2);
      for (let k = 0; k < NB; k++) if (!extT[k]) extT[k] = edgeR((k + 0.5) / NB * 6.2832) * 0.85;
      const t1 = Float32Array.from(extT); for (let k = 0; k < NB; k++) { let m = 0; for (let j = -2; j <= 2; j++) m = Math.max(m, t1[(k + j + NB) % NB] * (1 - 0.01 * Math.abs(j))); extT[k] = m; }
      for (let it = 0; it < 3; it++) { const t2 = Float32Array.from(extT); for (let k = 0; k < NB; k++) extT[k] = 0.25 * t2[(k + NB - 1) % NB] + 0.5 * t2[k] + 0.25 * t2[(k + 1) % NB]; } }
    const extAt = (a) => { const f = (((a % 6.2832) + 6.2832) % 6.2832) / 6.2832 * NB, k = Math.floor(f), t = f - k; return extT[k % NB] * (1 - t) + extT[(k + 1) % NB] * t; };
    const wallRAt = (a) => Math.min(extAt(a) + 13, rimAtA(a) * 0.95);
    city.edgeStats = { walls: 0, towers: 0, fields: 0, huts: 0, ruins: 0 };
    for (let k = 0; k < nSec; k++) {
        const st = secStyle[k]; if (st === 'sprawl' || st === 'stilts') continue;
        const a0 = secPh + k * 6.2832 / nSec, a1 = a0 + 6.2832 / nSec;
        if (st === 'wall') {   // a curtain wall that follows the outline, 11-unit pieces, towers every 6th
            const pts = []; for (let a = a0; a < a1 + 0.0001;) { const r = wallRAt(a); pts.push([Math.cos(a) * r, Math.sin(a) * r, a]); a += 16 / r; }
            const n = pts.length, blk = pts.map(q => nearAnyStreet(q[0], q[1], 14));
            const topRaw = pts.map(q => { let m = -1e9; for (const o of [-6, 0, 6]) m = Math.max(m, ground(q[0] + Math.cos(q[2]) * o, q[1] + Math.sin(q[2]) * o)); return m + 36; });
            const top = topRaw.map((v, i) => { let sm = 0; for (let j = -3; j <= 3; j++) sm += topRaw[clamp(i + j, 0, n - 1)]; return Math.max(sm / 7, v - 4); });
            for (let i = 0; i + 1 < n; i++) {
                if (blk[i] || blk[i + 1]) { if (blk[i] !== blk[i + 1]) { const j = blk[i] ? i + 1 : i; wallTower(pts[j][0], pts[j][1], top[j], pts[j][2]); city.edgeStats.towers++; } continue; }
                const p0 = pts[i], p1 = pts[i + 1], dx = p1[0] - p0[0], dz = p1[1] - p0[1], len = Math.hypot(dx, dz), yaw = Math.atan2(dz, dx), cx = (p0[0] + p1[0]) / 2, cz = (p0[1] + p1[1]) / 2;
                const o = { x: cx, z: cz, yaw, w: len + 1, d: 9.6 }; if (!free(o, 0.4)) continue; reserve(o);
                const lo = Math.min(ground(p0[0], p0[1]), ground(p1[0], p1[1]), ground(cx, cz)) - 9, tp = (top[i] + top[i + 1]) / 2;
                P('plainBox', cx, lo, cz, yaw, len + 0.8, tp - lo, 8.4, jit(stone, 0.1)); P('plainBox', cx, tp, cz, yaw, len + 0.8, 1.2, 10.2, jit(stoneD, 0.08));
                const nx2 = -dz / len, nz2 = dx / len; for (let q = 0; q < 3; q++) { const f = (q + 0.5) / 3 - 0.5; for (const sg of [-1, 1]) P('plainBox', cx + dx * f + nx2 * sg * 4.4, tp + 1.2, cz + dz * f + nz2 * sg * 4.4, yaw, 4.2, 3.4, 1.8, jit(stone, 0.1)); }
                city.edgeStats.walls++; if (i % 6 === 3) { wallTower(p0[0], p0[1], top[i], pts[i][2]); city.edgeStats.towers++; }
            }
        } else if (st === 'terraces') {   // strips of terraced fields with a few huts
            const FC = [hexLin(0x6fa043), hexLin(0xbca24a), hexLin(0x7a5a38), hexLin(0x4f8a3c), hexLin(0xa8b84a)];
            for (let ring = 0; ring < 3; ring++) for (let a = a0 + 0.01; a < a1 - 0.01;) {
                const r = edgeR(a) * (1.06 + ring * 0.075) + 6 + ring * 4, x = Math.cos(a) * r, z = Math.sin(a) * r, len = R(10, 16), wd = R(4.5, 6.5); a += (len + 0.8) / r;
                if (r > rimXZ(x, z) * 0.9 || nearAnyStreet(x, z, 7)) continue;
                const yaw = Math.atan2(Math.cos(a), -Math.sin(a)), o = { x, z, yaw, w: len, d: wd }; if (!free(o, 0.8)) continue; reserve(o);
                const [lo, hi] = lowestUnder(x, z, len, wd, yaw), fc = jit(FC[Math.floor(rnd() * FC.length)], 0.12), tp = hi + 0.6;
                P('plainBox', x, lo - 2.5, z, yaw, len, tp - lo + 2.5, wd, jit(FC[2], 0.1)); P('plainBox', x, tp - 0.15, z, yaw, len - 0.4, 0.5, wd - 0.5, fc);
                city.edgeStats.fields++;
                if (rnd() < 0.1) { const hc = jit(cols.walls[Math.floor(rnd() * cols.walls.length)], 0.1); P('wallBox', x, tp, z, yaw, 7, 5.4, 6, hc); P('gable', x, tp + 5.4, z, yaw, 8, 3.6, 7, jit(cols.roofs[0], 0.1)); city.edgeStats.huts++; }
            }
        } else if (st === 'ruins') {   // broken wall stubs, stumps and rubble that fade into the wild
            const cnt = Math.floor((a1 - a0) / 6.2832 * 120 + 14);
            for (let q = 0; q < cnt; q++) {
                const a = R(a0, a1), t = Math.pow(rnd(), 0.8), rim = rimXZ(Math.cos(a), Math.sin(a)), r = lerp(edgeR(a) * 0.98, Math.max(edgeR(a) * 1.05, rim * 0.86), t), x = Math.cos(a) * r, z = Math.sin(a) * r;
                if (rnd() < t * 0.7 || nearAnyStreet(x, z, 4)) continue;
                const o = { x, z, yaw: R(0, 3.14), w: 12, d: 12 }; if (!free(o, 0.5)) continue; reserve(o); const g = ground(x, z), kind = rnd();
                if (kind < 0.45) P('plainBox', x, g - 4, z, o.yaw, R(6, 14), R(3, 11) + 4, R(2.6, 4), jit(stoneD, 0.2), 0, R(-0.05, 0.05));
                else if (kind < 0.75) { const dd = R(6, 9); P('plainCyl', x, g - 4, z, 0, dd, R(8, 26) + 4, dd, jit(stone, 0.2)); }
                else for (let m = 0; m < 5; m++) P('plainBox', x + R(-5, 5), g - 1, z + R(-5, 5), R(0, 3.14), R(1.5, 4.5), R(1.6, 4.5), R(1.5, 4.5), jit(stoneD, 0.25), R(-0.4, 0.4), R(-0.4, 0.4));
                city.edgeStats.ruins++;
            }
        }
    }
    // a lookout outpost at the far end of a rope bridge: platform on piers, a hut, rails, a lantern, an antenna
    const outpostDeck = (g) => {
        const m = g.m, sk = 8, py = m.y;
        P('plainBox', m.x, py - 0.9, m.z, 0, 14, 0.9, 14, scrapCol()); addCol(m.x, m.z, 0, 7, 7, py - 0.9, py, py, 1);
        for (const sx of [-1, 1]) for (const sz of [-1, 1]) { const px = m.x + sx * 6.2, pz = m.z + sz * 6.2, gl = ground(px, pz); P('baseBox', px, gl - sk, pz, 0, 1.6, py - gl + sk - 0.9, 1.6, scrapCol()); addCol(px, pz, 0, 0.8, 0.8, gl - sk, py - 0.9, py - 0.9, 0); P('plainCyl', px, py, pz, 0, 0.4, 3.4, 0.4, rail); }
        P('plainBox', m.x + 2, py, m.z, 0, 5.2, 3.4, 4.2, scrapCol()); P('gable', m.x + 2, py + 3.4, m.z, 0, 6, 2.2, 5, cols.roofs[0]); P('glow', m.x - 2.5, py + 3.6, m.z, 0, 1.2, 1.2, 1.2, hexLin(0xffc27a));
        P('plainCyl', m.x - 5, py, m.z + 5, 0, 0.5, R(12, 22), 0.5, cols.trim); city.poi.views.push({ x: m.x, z: m.z, y: py + 0.4, kind: 'lookout' });
    };

    // ---------- BUILDING -> PIECES ----------
    const accentBy = (i) => i & 1 ? accent : accent2;
    const loc = (b, u, v) => { const c = Math.cos(b.yaw), s = Math.sin(b.yaw); return [b.x + u * c - v * s, b.z + u * s + v * c]; };
    // which facade faces the nearest street, and where the door is (2.5 units outside it)
    const doorFor = (b) => {
        const ns = nearestSeg(b.x, b.z); let dirx = 0, dirz = 1;
        if (ns) { const sg = ns.sg, t = clamp(((b.x - sg.ax) * (sg.bx - sg.ax) + (b.z - sg.az) * (sg.bz - sg.az)) / (sg.L * sg.L), 0, 1), sx = sg.ax + (sg.bx - sg.ax) * t, sz = sg.az + (sg.bz - sg.az) * t, dl = Math.hypot(sx - b.x, sz - b.z) || 1; dirx = (sx - b.x) / dl; dirz = (sz - b.z) / dl; }
        const c = Math.cos(b.yaw), s = Math.sin(b.yaw), du = dirx * c + dirz * s, dv = -dirx * s + dirz * c, side = Math.abs(du) > Math.abs(dv) ? (du > 0 ? 0 : 1) : (dv > 0 ? 2 : 3);
        const u = side < 2 ? (side === 0 ? 1 : -1) * (b.w / 2 + 2.5) : 0, v = side >= 2 ? (side === 2 ? 1 : -1) * (b.d / 2 + 2.5) : 0;
        return { side, door: loc(b, u, v) };
    };
    // a piece stuck to facade `s` (0 +u, 1 -u, 2 +v, 3 -v) of tier T: t in [-1,1] along it, `depth` out of the wall (extra = how far it sinks into it)
    const fac = (b, T, s, t, y, depth, span, h, cat, color, extra = 0) => {
        const alongU = s < 2, half = alongU ? T.w / 2 : T.d / 2, tang = (alongU ? T.d : T.w) / 2 * t, nrm = (s === 0 || s === 2) ? 1 : -1, off = nrm * (half + depth / 2 - extra);
        const du = alongU ? off : tang, dv = alongU ? tang : off, c = Math.cos(b.yaw), sn = Math.sin(b.yaw);
        P(cat, T.cx + du * c - dv * sn, y, T.cz + du * sn + dv * c, b.yaw, alongU ? depth : span, h, alongU ? span : depth, color);
    };
    const GREY = [hexLin(0x8a8d90), hexLin(0x6a6e72), hexLin(0xa0a2a0)];
    const treeAt = (x, y, z, sz) => { P('plainCyl', x, y, z, 0, Math.max(0.8, sz * 0.12), sz * 0.8, Math.max(0.8, sz * 0.12), hexLin(0x4a3a2a)); if (rnd() < 0.5) P('dome', x, y + sz * 0.6, z, 0, sz, sz * 0.8, sz, jit(hexLin(0x3f7a38), 0.3)); else P('cone', x, y + sz * 0.5, z, 0, sz * 0.9, sz * 1.5, sz * 0.9, jit(hexLin(0x356a3a), 0.3)); };
    const roofClutter = (b, T, yTop, tower) => {
        const sm = Math.min(T.w, T.d), cy = Math.cos(b.yaw), sy = Math.sin(b.yaw), put = () => { const u = R(-1, 1) * (T.w / 2 - 2.5), v = R(-1, 1) * (T.d / 2 - 2.5); return [T.cx + u * cy - v * sy, T.cz + u * sy + v * cy]; };
        if (sm < 9) return;
        if (rnd() < 0.35) { const [x, z] = put(), d0 = R(3.5, 5.5); P('plainBox', x, yTop, z, b.yaw, d0 * 0.85, 1.6, d0 * 0.85, cols.trim); P('plainCyl', x, yTop + 1.6, z, 0, d0, R(3.5, 5), d0, jit(hexLin(rnd() < 0.5 ? 0x5a7a8a : 0x6a6a64), 0.25)); }
        if (rnd() < 0.5) { const [x, z] = put(), sw = R(5, 9), sd = R(4, 7), sh = R(3, 4.2); P('plainBox', x, yTop, z, b.yaw + R(-0.2, 0.2), sw, sh, sd, scrapCol()); P('plainBox', x, yTop + sh, z, b.yaw, sw + 0.6, 0.4, sd + 0.6, cols.trim); if (rnd() < 0.5) P('glow', x + sw * 0.52, yTop + 1.2, z, 0, 0.3, 1.6, 1.0, hexLin(0xffc27a)); }
        const nA = tower ? 1 + Math.floor(rnd() * 3) : (rnd() < 0.45 ? 1 : 0);
        for (let k = 0; k < nA; k++) { const [x, z] = put(), hh = R(10, tower ? 34 : 20); P('plainCyl', x, yTop, z, 0, 0.55, hh, 0.55, cols.trim); P('plainBox', x, yTop + hh * 0.72, z, b.yaw + k, 6, 0.3, 0.3, cols.trim); if (tower || rnd() < 0.3) P('glow', x, yTop + hh, z, 0, 1.1, 1.1, 1.1, rnd() < 0.6 ? hexLin(0xff3a2a) : [1, 1, 1]); }
        if (rnd() < 0.22) { const [x, z] = put(); P('dome', x, yTop, z, 0, 4.2, 1.9, 4.2, jit(GREY[0], 0.1)); }
        if (rnd() < 0.2 && T.w > 12) { const [x, z] = put(), L = Math.min(9, T.w * 0.5); for (const sg of [-1, 1]) P('plainCyl', x + sg * L / 2 * cy, yTop, z + sg * L / 2 * sy, 0, 0.4, 4, 0.4, cols.trim); beam('plainBox', x - L / 2 * cy, yTop + 3.8, z - L / 2 * sy, x + L / 2 * cy, yTop + 3.8, z + L / 2 * sy, 0.1, 0.1, [0.05, 0.05, 0.05]); for (let q = 0; q < 4; q++) { const f = (q + 0.5) / 4; P('plainBox', x + (f - 0.5) * L * cy, yTop + 1.9, z + (f - 0.5) * L * sy, b.yaw, 1.2, 1.9, 0.12, tarpCol()); } }
        if (b.floors <= 9 && rnd() < 0.1 && T.w > 12 && T.d > 12) { const g0 = hexLin(0x4f7a3c); P('plainBox', T.cx, yTop, T.cz, b.yaw, T.w - 1.6, 0.9, T.d - 1.6, jit(g0, 0.3)); const nt = 2 + Math.floor(rnd() * 3); for (let k = 0; k < nt; k++) { const [x, z] = put(); treeAt(x, yTop + 0.9, z, R(4, 6)); } city.poi.views.push({ x: T.cx, z: T.cz, y: yTop + 0.9, kind: 'garden' }); }
    };
    const scaffold = (b, T, s, yBase, nF) => {
        const alongU = s < 2, span = alongU ? T.d : T.w, nP = Math.max(3, Math.floor(span / 5)), col = hexLin(0x8a7a5a), steel = hexLin(0x6a6e72);
        for (let k = 0; k <= nP; k++) { const t = (k / nP * 2 - 1) * 0.94; fac(b, T, s, t, yBase, 1.4, 0.5, nF * b.fh, 'plainCyl', k & 1 ? col : steel, -0.6); }
        for (let f = 0; f <= nF; f += 2) { const y = yBase + Math.min(f, nF) * b.fh; fac(b, T, s, 0, y, 1.4, span * 0.94, 0.4, 'plainBox', steel, -0.6); if (f < nF) fac(b, T, s, 0, y + 1.0, 1.9, span * 0.9, 0.3, 'plainBox', col, -0.2); }
    };
    const towers = [];
    for (let bi = 0; bi < city.buildings.length; bi++) {
        const b = city.buildings[bi]; b.i = bi;
        const dr = doorFor(b), y0 = b.y0, H = b.floors * b.fh, wall = jit(cols.walls[b.ci % cols.walls.length], 0.16), roof = jit(cols.roofs[(b.ci + bi) % cols.roofs.length], 0.12);
        { const sk = skirt(b.yLo, b.yHi);   // foundation / retaining block down to the lowest ground (v54: always, and deeper)
          if (b.stilts && y0 - b.yLo > 5) {   // an edge building on a steep fall-off: a slab on piers instead of a solid block
              P('plainBox', b.x, y0 - 0.9, b.z, b.yaw, b.w + 0.8, 0.9, b.d + 0.8, jit(cols.trim, 0.2));
              const cy = Math.cos(b.yaw), sy = Math.sin(b.yaw);
              for (const su of [-1, 1]) for (const sv of [-1, 1]) { const px = b.x + su * (b.w / 2 - 0.5) * cy - sv * (b.d / 2 - 0.5) * sy, pz = b.z + su * (b.w / 2 - 0.5) * sy + sv * (b.d / 2 - 0.5) * cy, gl = ground(px, pz); P('baseBox', px, gl - sk, pz, b.yaw, 1.6, y0 - gl + sk - 0.9, 1.6, scrapCol()); addCol(px, pz, b.yaw, 0.8, 0.8, gl - sk, y0 - 0.9, y0 - 0.9, 0); }
              const gm = ground(b.x, b.z); P('baseBox', b.x, gm - sk, b.z, b.yaw, 1.4, y0 - gm + sk - 0.9, 1.4, scrapCol()); addCol(b.x, b.z, b.yaw, 0.7, 0.7, gm - sk, y0 - 0.9, y0 - 0.9, 0);
          } else P('baseBox', b.x, b.yLo - sk, b.z, b.yaw, b.w + 0.8, y0 - b.yLo + sk + 0.6, b.d + 0.8, jit(cols.trim, 0.2)); }
        const doorY = y0 + 0.5;
        if (b.kind === 'tank') {
            P('wallCyl', b.x, y0, b.z, 0, b.w, H, b.w, wall); P('dome', b.x, y0 + H, b.z, 0, b.w, b.w * 0.45, b.w, roof);
            city.poi.works.push({ x: b.x, z: b.z, y: y0, yaw: b.yaw, kind: 'tank', door: dr.door, bi }); b.tiers = [{ cx: b.x, cz: b.z, w: b.w, d: b.w, y: y0, h: H }]; continue;
        }
        // body: 1-3 stepped tiers
        const nT = b.floors >= 20 ? 3 : b.floors >= 9 ? 2 : 1, tiers = []; let rem = b.floors, yy = y0, ku = 1, kv = 1, ou = 0, ov = 0;
        for (let t = 0; t < nT; t++) {
            const last = t === nT - 1, n = last ? rem : Math.max(3, Math.round(rem * R(0.45, 0.65))), [cx, cz] = loc(b, ou, ov), T = { cx, cz, w: b.w * ku, d: b.d * kv, y: yy, h: n * b.fh };
            P('wallBox', cx, yy, cz, b.yaw, T.w, T.h, T.d, t === 0 ? wall : jit(cols.walls[(b.ci + t) % cols.walls.length], 0.14)); tiers.push(T); yy += T.h; rem -= n;
            const k1 = R(0.8, 0.93), k2 = R(0.8, 0.95); ou += R(-1, 1) * (1 - k1) * b.w * 0.5; ov += R(-1, 1) * (1 - k2) * b.d * 0.5; ku *= k1; kv *= k2;
        }
        b.tiers = tiers; const T0 = tiers[0], TT = tiers[tiers.length - 1], yTop = yy;
        // cantilevered floors: boxes that stick out of the facade (the Kowloon silhouette)
        if (b.floors >= 6) for (let q = Math.floor(R(0, 2.8)); q > 0; q--) {
            const s = rnd() < 0.5 ? dr.side : Math.floor(rnd() * 4), fk = 2 + Math.floor(rnd() * Math.max(1, Math.min(tiers[0].h / b.fh - 3, b.floors - 4))), nf = 1 + Math.floor(rnd() * 3), e = R(1.5, 4), span = (s < 2 ? T0.d : T0.w) * R(0.35, 0.75), t = R(-0.4, 0.4);
            fac(b, T0, s, t, y0 + fk * b.fh, e * 2, span, nf * b.fh, 'wallBox', jit(cols.walls[(b.ci + q + 2) % cols.walls.length], 0.18), e);
        }
        // v92: a visible, human-scale doorway (the POI "door" used to have nothing there). ~11 units tall for the 8.5-unit eye height, with a wall lamp
        // bolted above it. Both are attached to the facade (the old door lamp was a loose 1.4-unit glow cube floating 2.5 units in front of the wall).
        { const sp = dr.side < 2 ? T0.d : T0.w, dw = Math.min(6.2, sp * 0.45), fw = dw + 2.2;
          fac(b, T0, dr.side, 0, y0 + 0.6, 0.55, fw, 12.6, 'plainBox', cols.trim, 0.1);
          fac(b, T0, dr.side, 0, y0 + 0.6, 1.0, dw, 11.0, 'plainBox', jit(hexLin(0x2a2e33), 0.25), 0.0);
          fac(b, T0, dr.side, 0, y0 + 13.4, 1.4, 2.2, 1.6, 'glow', jit([1, 0.82, 0.55], 0.15), 0.1); }
        // facade: storefront glow + neon signs, awning, AC boxes, balconies, pipes, scaffolding
        if (b.kind === 'shop' || (b.dd > 0.3 && rnd() < 0.4)) {
            fac(b, T0, dr.side, 0, y0 + 1.0, 0.5, (dr.side < 2 ? T0.d : T0.w) * 0.8, 9.0, 'glow', jit(hexLin(0xffd9a0), 0.3), 0.1);
            fac(b, T0, dr.side, R(-0.5, 0.5), y0 + 10.8, 3.2, (dr.side < 2 ? T0.d : T0.w) * R(0.5, 0.85), 0.5, 'plainBox', tarpCol(), -0.4);
        }
        if (b.dd > 0.25 && rnd() < 0.55) { const ns = 1 + Math.floor(rnd() * 2); for (let k = 0; k < ns; k++) { const c = pick(NEON), hh = R(5, 12), sd = rnd() < 0.7 ? dr.side : Math.floor(rnd() * 4); fac(b, T0, sd, rnd() < 0.5 ? -0.85 : 0.85, y0 + R(7, Math.max(8, Math.min(T0.h - hh - 2, 36))), 1.3, 0.8, hh, 'glow', c, -0.1); } }
        { const nAC = Math.min(9, Math.floor(R(0.1, 0.8) * b.floors * 0.7)); for (let k = 0; k < nAC; k++) fac(b, T0, rnd() < 0.6 ? dr.side : Math.floor(rnd() * 4), R(-0.9, 0.9), y0 + b.fh * (1 + Math.floor(rnd() * Math.max(1, T0.h / b.fh - 1))) + 1.5, 1.9, 2.6, 1.8, 'plainBox', jit(pick(GREY), 0.15), -0.1); }
        if (b.floors >= 4 && rnd() < 0.3) { const s = Math.floor(rnd() * 4), nb = 1 + Math.floor(rnd() * 3); for (let k = 0; k < nb; k++) { const y = y0 + b.fh * (2 + Math.floor(rnd() * Math.max(1, T0.h / b.fh - 2))), sp = (s < 2 ? T0.d : T0.w) * R(0.4, 0.8); fac(b, T0, s, R(-0.3, 0.3), y, 3.0, sp, 0.5, 'plainBox', jit(cols.trim, 0.2), 0); fac(b, T0, s, 0, y + 2.1, 0.3, sp, 0.3, 'plainBox', rail, 2.7); } }
        if (rnd() < 0.25) { const s = Math.floor(rnd() * 4); fac(b, T0, s, rnd() < 0.5 ? -0.96 : 0.96, y0, 0.9, 0.9, Math.min(T0.h, H) * R(0.6, 1.0), 'plainCyl', jit(hexLin(0x7a4a32), 0.3), -0.2); }
        if (b.floors >= 5 && rnd() < 0.07) scaffold(b, T0, dr.side, y0 + b.fh * R(0, 1.5), Math.min(5, Math.floor(T0.h / b.fh) - 1));
        // roof + the crown
        if (b.kind === 'tower') {
            if (rnd() < 0.4) P('cone', TT.cx, yTop, TT.cz, b.yaw, TT.w * 0.6, TT.w * 1.4, TT.d * 0.6, roof); else { P('plainBox', TT.cx, yTop, TT.cz, b.yaw, TT.w + 1, 1.4, TT.d + 1, cols.trim); roofClutter(b, TT, yTop + 1.4, true); }
            P('glow', T0.cx, y0 + T0.h * 0.5, T0.cz, b.yaw, T0.w + 0.5, 0.9, T0.d + 0.5, jit(accentBy(bi + 1), 0.2));
            towers.push(b); city.poi.towers.push({ x: b.x, z: b.z, y: yTop, h: H }); city.poi.works.push({ x: b.x, z: b.z, y: y0, yaw: b.yaw, kind: 'office', door: dr.door, bi });
        } else if (b.kind === 'workshop') {
            P('gable', T0.cx, yTop, T0.cz, b.yaw, T0.w + 1, b.fh * 1.6, T0.d + 1, roof); if (rnd() < 0.7) P('plainCyl', T0.cx + T0.w * 0.25, yTop, T0.cz, 0, 2.4, b.fh * 3.2, 2.4, cols.trim);
            P('glow', T0.cx, y0 + 3.5, T0.cz, b.yaw, T0.w + 0.5, 0.8, T0.d + 0.5, [1.0, 0.45, 0.12]); city.poi.works.push({ x: b.x, z: b.z, y: y0, yaw: b.yaw, kind: 'workshop', door: dr.door, bi });
        } else {
            const style = b.floors <= 6 && rnd() < 0.5 ? 'gable' : b.floors <= 5 && rnd() < 0.15 ? 'dome' : 'flat', sm = Math.min(TT.w, TT.d);
            if (style === 'gable') { if (TT.w >= TT.d) P('gable', TT.cx, yTop, TT.cz, b.yaw, TT.w + 1, b.fh * R(0.9, 1.6), TT.d + 1, roof); else P('gable', TT.cx, yTop, TT.cz, b.yaw + Math.PI / 2, TT.d + 1, b.fh * R(0.9, 1.6), TT.w + 1, roof); }
            else if (style === 'dome') P('dome', TT.cx, yTop, TT.cz, 0, sm * 0.95, sm * 0.4, sm * 0.95, roof);
            else { P('plainBox', TT.cx, yTop, TT.cz, b.yaw, TT.w + 0.8, 1.2, TT.d + 0.8, roof); roofClutter(b, TT, yTop + 1.2, false); }
            if (b.kind === 'shop') city.poi.shops.push({ x: b.x, z: b.z, y: y0, yaw: b.yaw, door: dr.door, bi });
            else { city.poi.homes.push({ x: b.x, z: b.z, y: y0, yaw: b.yaw, door: dr.door, bi }); if (rnd() < 0.1) city.poi.shops.push({ x: b.x, z: b.z, y: y0, yaw: b.yaw, door: dr.door, bi }); }
        }
        void doorY;
    }
    // overhead wires: sagging cables between nearby tall roofs
    { let nW = 0; const tall = city.buildings.filter(b => b.floors >= 7 && b.tiers);
      for (const A of tall) { if (nW > 140) break; for (const o of bGrid.near(A.x, A.z, 120)) { if (o === A || !o.tiers || o.floors < 7 || o.i < A.i || rnd() > 0.2) continue; const d = Math.hypot(o.x - A.x, o.z - A.z); if (d < 40 || d > 120) continue;
          const ta = A.tiers[A.tiers.length - 1], tb = o.tiers[o.tiers.length - 1], ya = ta.y + ta.h + 2, yb = tb.y + tb.h + 2, mx = (ta.cx + tb.cx) / 2, mz = (ta.cz + tb.cz) / 2, my = (ya + yb) / 2 - d * 0.04, wc = [0.04, 0.04, 0.04];
          beam('plainBox', ta.cx, ya, ta.cz, mx, my, mz, 0.2, 0.2, wc); beam('plainBox', mx, my, mz, tb.cx, yb, tb.cz, 0.2, 0.2, wc); nW++; } } }

    // ---------- SCRAP BRIDGES between buildings: wall to wall at a floor both have, never through a building, never into the ground ----------
    city.bridges = [];
    const tierAt = (b, y) => { for (const t of b.tiers) if (y >= t.y - 0.1 && y <= t.y + t.h + 0.1) return t; return null; };
    const rayHit = (T, dx, dz, yaw) => { const c = Math.cos(yaw), s = Math.sin(yaw), du = Math.abs(dx * c + dz * s), dv = Math.abs(-dx * s + dz * c); return Math.min(du < 1e-6 ? 1e9 : T.w / 2 / du, dv < 1e-6 ? 1e9 : T.d / 2 / dv); };
    const blocked = (x0, z0, x1, z1, y, A, B) => {
        const L = Math.hypot(x1 - x0, z1 - z0), n = Math.ceil(L / 3.5);
        for (let i = 1; i < n; i++) {
            const t = i / n, x = lerp(x0, x1, t), z = lerp(z0, z1, t); if (ground(x, z) > y - 2.4) return true;
            for (const o of bGrid.near(x, z, 6)) { if (o === A || o === B || o.top === undefined) continue; if (y > o.y0 - 4 && y < o.top + 3 && inObb(o, x, z, 2.5)) return true; }
        }
        return false;
    };
    const bridgedN = new Map(); let nBr = 0;
    for (const A of city.buildings) {
        if (nBr >= 240) break; if (!A.tiers || A.floors < 4 || A.kind === 'tank') continue;
        for (const o of bGrid.near(A.x, A.z, 150)) {
            if (o === A || o.top === undefined || o.i <= A.i || !o.tiers || o.floors < 4 || o.kind === 'tank') continue;
            if ((bridgedN.get(A.i) || 0) >= 3 || (bridgedN.get(o.i) || 0) >= 3) continue;
            const d0 = Math.hypot(o.x - A.x, o.z - A.z), mega = A.mega && A.mega === o.mega; if (d0 < 24 || d0 > 150 || rnd() > (mega ? 1 : 0.45)) continue;
            const lowY = Math.max(A.y0, o.y0) + 26, hiY = Math.min(A.top, o.top) - 16; if (hiY < lowY) continue;
            for (let tr = 0; tr < (mega ? 3 : 1); tr++) {
                const k = Math.ceil((lowY - A.y0) / A.fh + rnd() * ((hiY - lowY) / A.fh)), y = Math.min(hiY, A.y0 + k * A.fh + 0.4), TA = tierAt(A, y), TB = tierAt(o, y); if (!TA || !TB) continue;
                const vx = TB.cx - TA.cx, vz = TB.cz - TA.cz, dd = Math.hypot(vx, vz), ux = vx / dd, uz = vz / dd, tA = rayHit(TA, ux, uz, A.yaw), tB = rayHit(TB, -ux, -uz, o.yaw), L = dd - tA - tB;
                if (L < 8 || L > 90) continue;
                const p0 = [TA.cx + ux * tA, TA.cz + uz * tA], p1 = [TB.cx - ux * tB, TB.cz - uz * tB], mx = (p0[0] + p1[0]) / 2, mz = (p0[1] + p1[1]) / 2;
                if (blocked(p0[0], p0[1], p1[0], p1[1], y, A, o)) continue;
                if (city.bridges.some(q => Math.abs(q.y - y) < 14 && Math.hypot(q.mx - mx, q.mz - mz) < 26)) continue;
                emitBridge(p0[0], p0[1], y, p1[0], p1[1], y, R(6.5, 10), {});
                city.bridges.push({ ax: p0[0], az: p0[1], bx: p1[0], bz: p1[1], y, mx, mz }); city.poi.views.push({ x: mx, z: mz, y: y + 0.4, kind: 'bridge' });
                bridgedN.set(A.i, (bridgedN.get(A.i) || 0) + 1); bridgedN.set(o.i, (bridgedN.get(o.i) || 0) + 1); nBr++;
            }
        }
    }
    // ---------- the street bridges (chosen before the buildings, so nothing stands in their way) ----------
    for (const g of gapB) { const n = g.n, m = g.m; found(n.x, n.z, g.bw + 3, 5, Math.atan2(m.z - n.z, m.x - n.x), n.y - 0.3, cols.trim); found(m.x, m.z, g.bw + 3, 5, Math.atan2(m.z - n.z, m.x - n.x), m.y - 0.3, cols.trim); emitBridge(n.x, n.z, n.y, m.x, m.z, m.y, g.bw, {}); if (g.outpost) outpostDeck(g); city.bridges.push({ ax: n.x, az: n.z, bx: m.x, bz: m.z, y: (n.y + m.y) / 2, mx: g.mx, mz: g.mz, street: true }); city.poi.views.push({ x: g.mx, z: g.mz, y: (n.y + m.y) / 2 + 0.4, kind: 'bridge' }); }

    // ---------- v55: THE WALLED-CITY EFFECT - buildings fused into one mass. Solid link blocks across the gaps between neighbours; over a street they start
    // high up (a covered street, the sky mostly hidden), elsewhere they run down to the ground. ----------
    city.connectors = 0;
    {
        const done = new Set(), cnt = new Map(); let nC = 0;
        for (const A of city.buildings) {
            if (nC >= 700) break; if (!A.tiers || A.kind === 'tank' || A.floors < 3) continue;
            for (const o of bGrid.near(A.x, A.z, Math.hypot(A.w, A.d) / 2 + 70)) {
                if (o === A || o.top === undefined || !o.tiers || o.kind === 'tank' || o.floors < 3) continue;
                const key = A.i < o.i ? A.i * 100000 + o.i : o.i * 100000 + A.i; if (done.has(key)) continue; done.add(key);
                if ((cnt.get(A.i) || 0) >= 4 || (cnt.get(o.i) || 0) >= 4) continue;
                const TA = A.tiers[0], TB = o.tiers[0], vx = TB.cx - TA.cx, vz = TB.cz - TA.cz, dd = Math.hypot(vx, vz); if (dd < 1) continue;
                const ux = vx / dd, uz = vz / dd, al = (b) => Math.max(Math.abs(ux * Math.cos(b.yaw) + uz * Math.sin(b.yaw)), Math.abs(-ux * Math.sin(b.yaw) + uz * Math.cos(b.yaw)));
                if (al(A) < 0.94 || al(o) < 0.94) continue;
                const tA = rayHit(TA, ux, uz, A.yaw), tB = rayHit(TB, -ux, -uz, o.yaw), L = dd - tA - tB; if (L < 1.2 || L > 42) continue;
                const p0 = [TA.cx + ux * tA, TA.cz + uz * tA], p1 = [TB.cx - ux * tB, TB.cz - uz * tB], mx = (p0[0] + p1[0]) / 2, mz = (p0[1] + p1[1]) / 2;
                let street = false; for (let k = 0; k <= 4; k++) if (nearAnyStreet(lerp(p0[0], p1[0], k / 4), lerp(p0[1], p1[1], k / 4), 2)) { street = true; break; }
                if (rnd() > (street ? 0.6 : 0.5)) continue;
                const base0 = Math.max(A.y0, o.y0), topY = Math.min(A.top, o.top) - A.fh * Math.floor(R(0, 3));
                const gLow = Math.min(ground(p0[0], p0[1]), ground(p1[0], p1[1]), ground(mx, mz));
                const bottom = street ? base0 + A.fh * Math.floor(R(5, 9)) : gLow - 6;
                if (topY - bottom < A.fh * 1.6) continue;
                const wC = clamp(Math.min(TA.w, TA.d, TB.w, TB.d) * R(0.45, 0.85), 8, 46), yaw = Math.atan2(uz, ux), box = { x: mx, z: mz, yaw, w: L + 3, d: wC };
                let clash = false; for (const q of bGrid.near(mx, mz, L / 2 + wC + 30)) { if (q === A || q === o || q.top === undefined) continue; if (q.y0 > topY || q.top < bottom) continue; if (obbOverlap(box, q, 0.3)) { clash = true; break; } }
                if (clash) continue;
                P('wallBox', mx, bottom, mz, yaw, L + 3, topY - bottom, wC, jit(cols.walls[(A.ci + 1) % cols.walls.length], 0.16));
                if (street) P('glow', mx, bottom - 0.5, mz, yaw, L * 0.8, 0.7, wC * 0.45, jit(hexLin(0xffd9a0), 0.3));
                cnt.set(A.i, (cnt.get(A.i) || 0) + 1); cnt.set(o.i, (cnt.get(o.i) || 0) + 1); nC++;
            }
        }
        city.connectors = nC;
    }
    // ---------- v55: THE FARMLAND DOMES (enterable): podium, glass dome on ribs, an airlock tunnel, beds / orchard rows, grow-lights ----------
    const emitDome = (dm) => {
        const { x, z, rd, PR, yP, hd, len } = dm, H = rd * 0.72, [lo, hi] = lowestUnder(x, z, PR * 1.8, PR * 1.8, 0), sk = skirt(lo, hi), dx = Math.cos(hd), dz = Math.sin(hd), px = -dz, pz = dx;
        const steel = hexLin(0x6a737c), soil = hexLin(0x4a3524), concrete = jit(hexLin(0x8d8f88), 0.08), glassT = jit(hexLin(0xa8f0d8), 0.1);
        P('baseBox', x, lo - sk, z, 0, PR * 2, yP - lo + sk, PR * 2, concrete);                                   // the podium: solid, top = yP
        P('plainCyl', x, yP, z, 0, rd * 1.94, 0.3, rd * 1.94, soil);
        P('glassDome', x, yP, z, 0, rd * 2, H, rd * 2, glassT);
        const NSEG = 64, FB = [0, 0.34, 0.6, 0.82, 1.0], doorHalf = Math.asin(Math.min(0.9, 14 / rd)) + Math.PI / NSEG;
        for (let bnd = 0; bnd < 4; bnd++) {   // collision shell: stacked bands of short wall boxes (the lowest band has the door gap)
            const fm = (FB[bnd] + FB[bnd + 1]) / 2, rho = rd * Math.sqrt(1 - fm * fm), y0 = yP + H * FB[bnd], y1 = yP + H * FB[bnd + 1];
            for (let k = 0; k < NSEG; k++) {
                const am = (k + 0.5) / NSEG * 6.2832; let da = Math.abs(((am - hd + Math.PI * 3) % 6.2832) - Math.PI); if (bnd === 0 && da < doorHalf) continue;
                const hwS = rho * Math.sin(Math.PI / NSEG) + 0.4, cr = rho * Math.cos(Math.PI / NSEG);
                addCol(x + Math.cos(am) * cr, z + Math.sin(am) * cr, am + Math.PI / 2, hwS, 1.3, y0, y1, y1, 0);
            }
        }
        for (const f of [0.34, 0.6, 0.82]) { const rr = rd * Math.sqrt(1 - f * f), yy = yP + H * f; for (let k = 0; k < 28; k++) { const a0 = k / 28 * 6.2832, a1 = (k + 1) / 28 * 6.2832; beam('plainBox', x + Math.cos(a0) * rr, yy, z + Math.sin(a0) * rr, x + Math.cos(a1) * rr, yy, z + Math.sin(a1) * rr, 1.0, 1.0, steel); } }
        for (let m = 0; m < 12; m++) { const th = m / 12 * 6.2832; for (let k = 0; k < 6; k++) { const f0 = k / 6 * 0.97, f1 = (k + 1) / 6 * 0.97, r0 = rd * Math.sqrt(1 - f0 * f0), r1 = rd * Math.sqrt(1 - f1 * f1); beam('plainBox', x + Math.cos(th) * r0, yP + H * f0, z + Math.sin(th) * r0, x + Math.cos(th) * r1, yP + H * f1, z + Math.sin(th) * r1, 1.1, 1.1, steel); } }
        // the airlock tunnel through the glass (side walls + roof are solid boxes; the floor is the podium)
        { const s0 = rd - 6, s1 = rd + 26, cl = (s0 + s1) / 2, cx = x + dx * cl, cz = z + dz * cl, Lt = s1 - s0, wc = jit(cols.walls[2], 0.08);
          for (const sg of [-1, 1]) P('wallBox', cx + px * 13.2 * sg, yP, cz + pz * 13.2 * sg, hd, Lt, 22, 2.4, wc);
          P('wallBox', cx, yP + 22, cz, hd, Lt, 2.6, 29, jit(cols.trim, 0.1)); P('glow', cx, yP + 21.4, cz, hd, Lt - 2, 0.7, 6, hexLin(0xfff0c0));
          P('glow', x + dx * (s1 + 0.4), yP + 11, z + dz * (s1 + 0.4), hd, 0.6, 14, 24.4, accent); }
        // the ramp from the street / ground up to the podium (a collider ramp + a visible slab + retaining blocks)
        { const sA = PR, sB = PR + len, ex = x + dx * sB, ez = z + dz * sB, yS = ground(ex, ez) + 0.2, cxr = x + dx * (sA + sB) / 2, czr = z + dz * (sA + sB) / 2;
          addCol(cxr, czr, hd, len / 2, 11.5, Math.min(yP, yS) - 3, yP, yS, 1);
          beam('plainBox', x + dx * sA, yP - 0.7, z + dz * sA, ex, yS - 0.7, ez, 1.4, 23, jit(concrete, 0.05));
          for (const f of [0.34, 0.68]) { const sx = sA + len * f, qx = x + dx * sx, qz = z + dz * sx, gl = ground(qx, qz), yt = yP + (yS - yP) * f - 1.4; if (yt - gl > 1) P('baseBox', qx, gl - 6, qz, hd, 3, yt - gl + 6, 24, jit(cols.trim, 0.1)); } }
        // inside
        const cropC = [hexLin(0x5fae3c), hexLin(0xc9b23e), hexLin(0x7a4aa0), hexLin(0x3f8f4a), hexLin(0xb8483a), hexLin(0x8fc24a)];
        for (let v = -0.86 * rd, bi = 0; v <= 0.86 * rd; v += 13, bi++) {
            if (Math.abs(v) < 11) continue;
            const c = Math.sqrt(Math.max(0, (0.88 * rd) ** 2 - v * v)); if (c < 20) continue;
            for (const sg of [-1, 1]) {
                const Lb = c - 12, sm = sg * (12 + Lb / 2), bx = x + dx * sm + px * v, bz = z + dz * sm + pz * v; if (Lb < 8) continue;
                P('plainBox', bx, yP, bz, hd, Lb, 1.3, 8, soil);
                if ((bi + (sg > 0 ? 1 : 0) + dm.kind) % 4 === 0) { for (let q = 0; q < Math.floor(Lb / 17); q++) { const sq = sm - Lb / 2 + (q + 0.5) * 17; treeAt(x + dx * sq + px * v, yP + 1.0, z + dz * sq + pz * v, R(8, 12)); } }
                else P('plainBox', bx, yP + 1.3, bz, hd, Lb - 1, R(0.8, 3.2), 6.6, jit(cropC[(bi + dm.kind + (sg > 0 ? 3 : 0)) % cropC.length], 0.15));
            }
        }
        P('plainCyl', x, yP, z, 0, 8, H * 0.78, 8, steel); P('glow', x, yP + H * 0.78, z, 0, 22, 2.4, 22, hexLin(0xff6ad5));   // the central mast + sun-lamp
        for (let k = 0; k < 8; k++) { const a = k / 8 * 6.2832 + 0.3; P('glow', x + Math.cos(a) * rd * 0.55, yP + H * 0.5, z + Math.sin(a) * rd * 0.55, a, 9, 0.9, 2.4, k & 1 ? hexLin(0xff6ad5) : hexLin(0x6ab8ff)); }
        city.poi.views.push({ x, z, y: yP + 1.2, kind: 'garden' });
    };
    for (const dm of domes) emitDome(dm);
    city.domes = domes.map(({ x, z, rd, PR, yP, hd, len, kind }) => ({ x, z, rd, PR, yP, hd, len, kind }));
    // ---------- v55: a little wild among the outskirts: trees and rocks that stand in the gaps (they fade into the real scatter outside) ----------
    city.greens = 0;
    { let nG = 0; const RK = [hexLin(0x77756e), hexLin(0x5f5d57), hexLin(0x8a8378)];
      for (let tr = 0; tr < 3200 && nG < 260; tr++) {
          const a = R(0, 6.2832), e = edgeR(a), rim = rimAtA(a), r = lerp(e * 0.5, Math.max(e * 1.04, rim * 0.92), Math.pow(rnd(), 0.75)), x = Math.cos(a) * r, z = Math.sin(a) * r;
          if (styleAt(x, z) === 'wall' && r > wallRAt(a) - 10) continue; if (!inRim(x, z, 0.93)) continue;
          const pr = 0.06 + 0.9 * Math.pow(clamp((r - e * 0.55) / (e * 0.55), 0, 1), 1.4); if (rnd() > pr) continue;
          const tree = rnd() < 0.6, sz = tree ? R(11, 20) : R(7, 17), o = { x, z, yaw: 0, w: sz + 6, d: sz + 6 };
          if (nearAnyStreet(x, z, 10 + sz * 0.5) || !free(o, 0.6)) continue; reserve(o); const g = ground(x, z);
          if (tree) treeAt(x, g - 1.4, z, sz);
          else { const k = RK[Math.floor(rnd() * 3)]; P('dome', x, g - 2, z, 0, sz, sz * R(0.45, 0.8) + 2, sz * R(0.8, 1.1), jit(k, 0.15)); if (rnd() < 0.6) P('dome', x + R(-0.7, 0.7) * sz, g - 2, z + R(-0.7, 0.7) * sz, 0, sz * 0.5, sz * 0.4 + 2, sz * 0.55, jit(k, 0.2)); }
          nG++;
      }
      city.greens = nG; }
    // ---------- gate: two pylons + lintel + guard huts + barricade, on the pass road ----------
    { const gy = ground(gx, gz), nx = -Math.sin(gyaw), nz = Math.cos(gyaw);
      for (const sg of [-1, 1]) { const px = gx + nx * 26 * sg, pz = gz + nz * 26 * sg, hx = gx + nx * 40 * sg, hz = gz + nz * 40 * sg;
          found(px, pz, 14, 14, gyaw, gy, cols.trim); P('wallBox', px, gy, pz, gyaw, 14, 78, 14, jit(cols.walls[1], 0.1)); P('cone', px, gy + 78, pz, 0, 12, 18, 12, cols.roofs[0]);
          found(hx, hz, 12, 12, gyaw, gy, cols.trim); P('plainBox', hx, gy, hz, gyaw, 12, 12, 12, scrapCol()); P('plainBox', hx, gy + 12, hz, gyaw, 13.5, 0.9, 13.5, cols.trim); }
      P('plainBox', gx, gy + 62, gz, gyaw, 12, 12, 52, cols.trim); P('glow', gx, gy + 74, gz, gyaw, 6, 1.8, 54, accent);
      for (let k = 0; k < 4; k++) { const off = (k - 1.5) * 12; beam('plainBox', gx + nx * off - Math.cos(gyaw) * 7, gy - 4, gz + nz * off - Math.sin(gyaw) * 7, gx + nx * off + Math.cos(gyaw) * 7, gy + 6, gz + nz * off + Math.sin(gyaw) * 7, 1.2, 1.2, scrapCol()); }   // scrap barricade stakes
      city.poi.gates.push({ x: gx, z: gz, y: gy, yaw: gyaw });
      const flag = (x, z, yaw, h) => { const y = ground(x, z); P('plainCyl', x, y - 4, z, 0, 1.4, h + 4, 1.4, cols.trim); P('plainBox', x, y + h - 9, z, yaw + Math.PI / 2, 12, 4.5, 0.5, hexLin(0x2f8fe8)); P('plainBox', x, y + h - 13.5, z, yaw + Math.PI / 2, 12, 4.5, 0.5, hexLin(0x2fcf7a)); P('glow', x, y + h - 11.5, z, yaw, 2.2, 2.2, 0.7, [1, 1, 1]); };
      flag(plazaR * 0.9, -plazaR * 0.2, 0.3, 46); flag(gx + nx * 30, gz + nz * 30, gyaw, 40); }
    // docks / depots along the gate road
    for (const f of [0.55, 0.7, 0.85]) { const o = nodeNear(gx * f, gz * f, 140); if (o >= 0) { const n = nodes[o]; city.poi.docks.push({ x: n.x, z: n.z, y: n.y }); } }
    // secondary landmarks on the hillside belt: turbines, an observatory dome, a lighthouse, an obelisk
    const nLm = Math.floor(R(3, 6));
    for (let k = 0; k < nLm; k++) {
        const a = R(0, 6.28), rr = R(edgeR(a) * 0.9, Math.max(edgeR(a) * 1.0, rimAtA(a) * 0.9)), x = Math.cos(a) * rr, z = Math.sin(a) * rr; if (flatAt(x, z) > 0.8 || placed.some(o => o.w && Math.hypot(o.x - x, o.z - z) < Math.hypot(o.w, o.d) / 2 + 20)) continue;
        const gy = ground(x, z), kind = pick(['turbine', 'dome', 'beacon', 'obelisk']); found(x, z, 12, 12, 0, gy, cols.trim);
        if (kind === 'turbine') { P('plainCyl', x, gy, z, 0, 2.2, 54, 2.2, cols.trim); for (let q = 0; q < 3; q++) P('plainBox', x, gy + 54, z, a + q * 2.094, 32, 1.2, 3, jit(cols.walls[0], 0.1)); P('glow', x, gy + 55, z, 0, 3, 3, 3, accent); }
        else if (kind === 'dome') { P('plainCyl', x, gy, z, 0, 22, 12, 22, cols.walls[2]); P('dome', x, gy + 12, z, 0, 22, 14, 22, cols.roofs[1]); }
        else if (kind === 'beacon') { P('plainCyl', x, gy, z, 0, 6, 70, 6, cols.trim); P('glow', x, gy + 70, z, 0, 8, 8, 8, accent2); }
        else { P('plainBox', x, gy, z, a, 5, 60, 5, cols.walls[2]); P('cone', x, gy + 60, z, a, 5, 14, 5, accent); }
        city.poi.views.push({ x, z, y: gy + 1, kind: 'lookout' });
    }
    { city.probes = []; const stp = Math.max(1, Math.floor(city.buildings.length / 150)); for (let i = 0; i < city.buildings.length; i += stp) { const b = city.buildings[i]; city.probes.push(b.x, b.z, ground(b.x, b.z)); } }   // for the runtime ground-fit check
    // beacon for the far-view silhouette: highest point of the hub landmark
    city.beacon = { x: 0, y: fl + hubH * 1.15, z: 0, color: accent, color2: accent2 };
    city.stats = { buildings: city.buildings.length, pieces: city.pieces.length, nodes: nodes.length, edges: edges.length, contours: contours.length, towers: towers.length, megas: city.megas, bridges: city.bridges.length, streetBridges: gapB.length, homes: city.poi.homes.length, shops: city.poi.shops.length, works: city.poi.works.length, maxFloors: Math.max(0, ...city.buildings.map(b => b.floors)), edgeStyles: secStyle.join(','), spurs: city.spurs, outposts: city.outposts, edge: city.edgeStats, domes: domes.length, connectors: city.connectors || 0, greens: city.greens || 0 };
    return city;
}

// ---------------------------------------------------------------------------------- pieces -> typed instance arrays
// Matrix = Ry(-yaw) * Rz(pitch) * Rx(roll) with scale on the local axes. yaw is the plan direction (cos yaw, sin yaw) of the local +x axis
// (three.js' Ry maps +x to (cos, 0, -sin), hence the minus). pitch tilts +x up; roll banks about x.
function writeM(a, o, x, y, z, yaw, pitch, roll, sx, sy, sz) {
    const cy = Math.cos(yaw), sy_ = -Math.sin(yaw), cp = Math.cos(pitch), sp = Math.sin(pitch), cr = Math.cos(roll), sr = Math.sin(roll);
    // Rz*Rx rows
    const a00 = cp, a01 = -sp * cr, a02 = sp * sr, a10 = sp, a11 = cp * cr, a12 = -cp * sr, a20 = 0, a21 = sr, a22 = cr;
    // Ry * (Rz*Rx):  Ry = [[cy,0,sy],[0,1,0],[-sy,0,cy]]
    const r00 = cy * a00 + sy_ * a20, r01 = cy * a01 + sy_ * a21, r02 = cy * a02 + sy_ * a22;
    const r10 = a10, r11 = a11, r12 = a12;
    const r20 = -sy_ * a00 + cy * a20, r21 = -sy_ * a01 + cy * a21, r22 = -sy_ * a02 + cy * a22;
    a[o] = r00 * sx; a[o + 1] = r10 * sx; a[o + 2] = r20 * sx; a[o + 3] = 0;
    a[o + 4] = r01 * sy; a[o + 5] = r11 * sy; a[o + 6] = r21 * sy; a[o + 7] = 0;
    a[o + 8] = r02 * sz; a[o + 9] = r12 * sz; a[o + 10] = r22 * sz; a[o + 11] = 0;
    a[o + 12] = x; a[o + 13] = y; a[o + 14] = z; a[o + 15] = 1;
}
// Geometry conventions (shared with city_runtime.js): box/gable/cyl/cone/dome have their BASE at y = 0 and unit extents
// (cyl / cone / dome: sx, sz are full DIAMETERS), arch: unit footprint 1 (length) x 1 (height) x 1 (width), base at y = 0.
export function planToInstances(city) {
    const count = {}; for (const c of CITY_CATS) count[c] = 0;
    for (const p of city.pieces) count[p.cat]++;
    const cats = {}; for (const c of CITY_CATS) if (count[c]) cats[c] = { m: new Float32Array(count[c] * 16), c: new Float32Array(count[c] * 3), n: 0 };
    // far "skyline" set: the tall wall boxes only (drawn emissive from far away)
    const sky = [];
    for (const p of city.pieces) {
        const k = cats[p.cat], i = k.n++;
        writeM(k.m, i * 16, p.x, p.y, p.z, p.yaw, p.pitch, p.roll, p.sx, p.sy, p.sz);
        k.c[i * 3] = p.color[0]; k.c[i * 3 + 1] = p.color[1]; k.c[i * 3 + 2] = p.color[2];
        if ((p.cat === 'wallBox' || p.cat === 'wallCyl') && p.sy > 90) sky.push(p);
    }
    const skyM = new Float32Array(sky.length * 16), skyC = new Float32Array(sky.length * 3);
    sky.forEach((p, i) => { writeM(skyM, i * 16, p.x, p.y, p.z, p.yaw, 0, 0, p.sx, p.sy, p.sz); skyC.set(p.color, i * 3); });
    for (const c in cats) delete cats[c].n;
    return { cats, sky: { m: skyM, c: skyC, n: sky.length }, beacon: city.beacon, counts: count };
}
// v54: colliders = explicit ones (street floors, stair ramps, bridge decks, piers) + every solid-looking flat piece (walls, foundations, stout cylinders, big boxes)
export function planToCols(city) {
    const out = city.cols.slice();
    for (const p of city.pieces) {
        if (p.nc || Math.abs(p.pitch) > 0.02 || Math.abs(p.roll) > 0.02) continue;
        const c = p.cat; if (c !== 'wallBox' && c !== 'baseBox' && c !== 'wallCyl' && c !== 'plainBox' && c !== 'plainCyl' && c !== 'orgCyl') continue;
        const cyl = c === 'wallCyl' || c === 'plainCyl' || c === 'orgCyl'; let hx = p.sx / 2, hz = p.sz / 2; if (cyl) { hx *= 0.85; hz *= 0.85; }
        if (c === 'plainBox' || c === 'plainCyl') { if (Math.min(hx, hz) * 2 < 3.5 || p.sy < 3.0) continue; } else if (Math.min(hx, hz) < 1.0 || p.sy < 2.5) continue;
        out.push(p.x, p.z, p.yaw, hx, hz, p.y, p.y + p.sy, p.y + p.sy, 0);
    }
    return new Float32Array(out);
}
// v54: the street surface mesh (indexed triangles, per-vertex colour + normal)
export function planToRoad(city) { const r = city.road; return { pos: new Float32Array(r.pos), nor: new Float32Array(r.nor), col: new Float32Array(r.col), idx: new Uint32Array(r.idx) }; }
// compact data the main thread needs for life (nav graph, POIs, plazas)
export function planToLife(city) {
    const N = city.nodes.length, nodes = new Float32Array(N * 4), E = city.edges.length, edges = new Uint32Array(E * 2), ew = new Float32Array(E);
    city.nodes.forEach((n, i) => { nodes[i * 4] = n.x; nodes[i * 4 + 1] = n.y; nodes[i * 4 + 2] = n.z; nodes[i * 4 + 3] = n.kind; });
    city.edges.forEach((e, i) => { edges[i * 2] = e.a; edges[i * 2 + 1] = e.b; ew[i] = e.w; });
    const slim = (l, n) => l.slice(0, n).map(o => ({ x: o.x, y: o.y, z: o.z, door: o.door, kind: o.kind }));
    return { nodes, edges, ew, hubNode: 0, gateNode: city.gateNode, poi: { homes: slim(city.poi.homes, 500), shops: slim(city.poi.shops, 260), works: slim(city.poi.works, 360), docks: city.poi.docks, plazas: city.poi.plazas, gates: city.poi.gates, towers: city.poi.towers.slice(0, 60), views: slim(city.poi.views, 120) },
             meta: { edgeStyles: city.edgeStyles, arche: city.arche, palette: city.palette, hubKind: city.hubKind, hubHeight: city.hubHeight, floorH: city.floorH, Rc: city.Rc, Rf: city.Rf, warmWindows: city.warmWindows, stats: city.stats }, bridges: city.bridges.map(b => ({ ax: b.ax, az: b.az, bx: b.bx, bz: b.bz, y: b.y })) };
}
// natural-height grid helper for workers/tests: bilinear grid over the valley box from an exact sampler nat3(x, z)
export function makeNatGrid(S, nat3, step = 20) {
    const half = Math.max(S.Rb * 0.75 + 60, (S.rimR || 0) + 100), n = Math.ceil(2 * half / step) + 1, g = new Float32Array(n * n);
    for (let j = 0; j < n; j++) for (let i = 0; i < n; i++) g[j * n + i] = nat3(-half + i * step, -half + j * step);
    const f = (x, z) => {
        let fx = (x + half) / step, fz = (z + half) / step; fx = clamp(fx, 0, n - 1.001); fz = clamp(fz, 0, n - 1.001);
        const i = Math.floor(fx), j = Math.floor(fz), tx = fx - i, tz = fz - j, o = j * n + i;
        return (g[o] * (1 - tx) + g[o + 1] * tx) * (1 - tz) + (g[o + n] * (1 - tx) + g[o + n + 1] * tx) * tz;
    };
    f.samples = n * n; return f;
}
