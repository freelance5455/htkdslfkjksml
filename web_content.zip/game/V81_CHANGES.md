# v81 - the strike, the AI's voice, the trajectory

freefall_cinematic.js and game.js. No other files touched.

Story
- The AI never wanted the Leviathan. Phase 4: when the Vale ask for a pilot, the AI now says it does not think you should do it, and that the Vale seem perfectly evolved for what they are doing.
- Launch: the Vale leader sets the course (swing around the giant, let its gravity throw you out of the system). The AI says they are flying home, not flying the mission. In flight it says: "We are not doing the Vale's plan. Your safety comes first... We go back to civilization. I will keep you underground until your case resurfaces."
- The hit used to be announced in the game just before the cinematic ("something just clipped the hull"). It now happens ON SCREEN in shot 1, so that line is replaced by a calm one ("Stabilizers are holding. The burn is clean.").
- Phase 6 hook: after the fall the AI says "I did not want this for you. But if we have to be here, we finish it." The log entry says the same.
- If the player never met the Vale (fallback launch from the wrecked transport), the Vale-specific lines are swapped or skipped.

Shot 1 (the strike)
- The pilot is wide awake from the first frame (no blur, no heavy lids).
- A speck of debris shows in the front window for 1.7 s: a pinprick that swells and streaks toward you.
- Impact at 25 s: white flash, expanding glare, sparks, a hard shake and the crack across the glass. The ship tumbles (the roll builds to about two turns in 3 s), the head is thrown, hits the frame at +0.75 s, the vision smears and the eyelids shut by +1.7 s. Then black.
- The hologram reads STABILIZERS ONLINE / CANOPY 100% until the hit, then OFFLINE / 58%.
- Shot 1 is 28.5 s (was 34 s) so the black after the hit is not long. Everything after it keeps its own timing.

The AI's voice
- Uses the game's own speakLine (slow, low voice) through a new `speakLine` option on createFreefallCinematic. The game's caption lives under the cinematic's layer, so the cinematic draws a copy of it (same look) plus the pulsing orb while a line plays.
- 19 lines, one at a time. The first words of shot 2 are "Oh, you woke up." Hope, then the burn attempt (shot 3), then the truth (shot 5: "I was wrong. The flyby has become an entry. I am sorry."), then "Brace. Whatever happens, you come first."
- A line that cannot start in its window is dropped instead of talking over the next shot. The strike cuts the voice off mid-word. Skip (Esc / Space / double tap) stops the voice.

Feed and trajectory (shots 2 to 7)
- The left hologram panel is now a TRAJECTORY display: the planned slingshot (dashed) over the giant, the real path (solid) running into it, the ship on the real path and a ring where it should be. (The MET clock is only shown in shot 1.)
- The bottom row alternates every 4 s between NUTRIENT FEED ACTIVE and STABILIZERS OFFLINE.
- Sound: a soft hiss and a small blip every 6.5 s for the feed drip, a rising whine for the speck, crack / deep hit / thump / groan for the strike.

Test helpers
- tests/ff_cine_voice_test.py plays the whole cinematic headless with a mock speakLine and prints when each line was spoken (arg: vale | novale).
- debug.renderAt now also draws the overlay layer (speck, hologram text); debug.say(text) shows a caption.

Not verified
- How the browser's voice sounds and how long each line really takes (the scheduler waits for each line to finish, but the timings were checked with a mock voice of 95 ms per character).
- Real-GPU look of the strike and the hologram (checked with software rendering only).
