// leviathan_core.js - v111 THE LEVIATHAN, part 1: the crash landing, the flight-deck bay and the first corridor.
//
// What this is: a self-contained interior. It owns its own THREE.Scene (game.js swaps it into the composer's RenderPass while the player is
// inside, so the terrain, sea, sky and weather are never drawn or updated), its own collision (flat floor, union of rectangles, AABB
// obstacles - the same idea as the warehouse), its own synthesised audio, and the scripted landing. It does not touch game state; game.js
// passes in the few hooks it needs (see createLeviathan below).
//
// Coordinates are local to the interior: floor at y = 0, +x east (the storm windows), -z north (the bulkhead the ship ends against),
// the breach in the +z wall, the corridor leaving through the west wall. 5 units is about a metre (the player's eye is 8.5).
//
// Written without a GPU. The storm backdrop is the only custom shader; if it fails to compile it falls back to a flat storm colour and
// logs the GLSL error as "[leviathan] shader ... failed". Light intensities live in LIGHT below, so they can be tuned without reading code.
import * as THREE from 'three';
import { registerShaderFallback } from './ocean_surface.js';
import { STORM_VS, STORM_FS } from './leviathan_sky.js';

const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
const lerp = (a, b, t) => a + (b - a) * t;
const smooth = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
function rng(seed) { let a = (seed >>> 0) || 1; return function () { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

// ---------------------------------------------------------------------------------------------------------------------------------
// Layout (all numbers in one place). Walls are LAYOUT.T thick and sit OUTSIDE the walkable rectangles.
// ---------------------------------------------------------------------------------------------------------------------------------
export const LAYOUT = {
    T: 12,
    bay: { x0: -150, x1: 150, z0: -380, z1: 140, h: 190 },
    breach: { x0: -80, x1: 80, y0: 22, y1: 132 },        // the torn forcefield opening in the +z wall
    door: { z0: -170, z1: -110, h: 80 },                  // west doorway into the corridor
    cor: { x0: -470, x1: -150, z0: -170, z1: -110, h: 85 },
    ship: { x0: -18, x1: 18, z0: -362, z1: -282, h: 24 }, // the wreck of the Vale starship
    hatch: { z0: -322, z1: -302, y0: 2, y1: 20 },         // dented hatch in the ship's west side
    stop: { x: 0, y: 11.5, z: -346 },                     // where the landing ends (the cockpit eye)
    exit: { x: -34, y: 8.5, z: -312 },                    // where the player steps out
    approachZ: 520,                                       // landing camera starts outside the breach
    eye: 8.5,
    doorX: -470                                           // the sealed blast door at the end of the corridor
};
const L = LAYOUT;

// The view outside: the Leviathan drifts through the storm. It is immersed (swirling gas on every side), rises out of the cloud tops (a sea of cloud
// below, the open atmosphere above, the tiny moon), holds there, then sinks back in. skyClear(t) is 0 immersed .. 1 clear. Cycle length SKY.P seconds.
const SKY = { P: 100, rise: 10, hold: 55, sink: 12 };
function skyClear(t) { const p = ((t % SKY.P) + SKY.P) % SKY.P, e = (x) => x * x * (3 - 2 * x); if (p < SKY.rise) return e(p / SKY.rise); if (p < SKY.rise + SKY.hold) return 1; if (p < SKY.rise + SKY.hold + SKY.sink) return 1 - e((p - SKY.rise - SKY.hold) / SKY.sink); return 0; }

const LIGHT = {   // tune here
    hemi: 0.85, storm: 1.0, stormFlash: 2.4, alarm: 150, fire: 130, corridor: 110, cockpit: 40
};

// Landing timeline (seconds)
const LAND = { T_APPROACH: 1.6, T_SKID: 7.0, P: 1.4, V_APPROACH: 250, T_KICK: 3.4 };
LAND.dist = L.bay.z1 - L.stop.z;                           // skid distance from the breach plane to the stop
LAND.v0 = LAND.dist * (LAND.P + 1) / LAND.T_SKID;

// ---------------------------------------------------------------------------------------------------------------------------------
// Static geometry batcher: axis-aligned and rotated boxes, merged per material, with world-scaled UVs and a little per-box tint.
// ---------------------------------------------------------------------------------------------------------------------------------
const FACES = [   // normal, u, v  (u x v = normal, so the winding is outward)
    [[1, 0, 0], [0, 1, 0], [0, 0, 1]], [[-1, 0, 0], [0, 0, 1], [0, 1, 0]],
    [[0, 1, 0], [0, 0, 1], [1, 0, 0]], [[0, -1, 0], [1, 0, 0], [0, 0, 1]],
    [[0, 0, 1], [1, 0, 0], [0, 1, 0]], [[0, 0, -1], [0, 1, 0], [1, 0, 0]]
];
function rotMat(ry, rx, rz) {   // R = Ry * Rx * Rz, row-major 3x3
    const cy = Math.cos(ry), sy = Math.sin(ry), cx = Math.cos(rx), sx = Math.sin(rx), cz = Math.cos(rz), sz = Math.sin(rz);
    const Ry = [cy, 0, sy, 0, 1, 0, -sy, 0, cy], Rx = [1, 0, 0, 0, cx, -sx, 0, sx, cx], Rz = [cz, -sz, 0, sz, cz, 0, 0, 0, 1];
    const mul = (A, B) => { const o = new Array(9); for (let r = 0; r < 3; r++) for (let c = 0; c < 3; c++) o[r * 3 + c] = A[r * 3] * B[c] + A[r * 3 + 1] * B[3 + c] + A[r * 3 + 2] * B[6 + c]; return o; };
    return mul(mul(Ry, Rx), Rz);
}
const rv = (R, v) => [R[0] * v[0] + R[1] * v[1] + R[2] * v[2], R[3] * v[0] + R[4] * v[1] + R[5] * v[2], R[6] * v[0] + R[7] * v[1] + R[8] * v[2]];

export class Batch {
    constructor(seed) { this.m = new Map(); this.r = rng(seed || 11); }
    _acc(mat) { let a = this.m.get(mat); if (!a) { a = { p: [], n: [], u: [], c: [], i: [], v: 0 }; this.m.set(mat, a); } return a; }
    box(x0, x1, y0, y1, z0, z1, mat, ts) { return this.rbox((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2, Math.abs(x1 - x0), Math.abs(y1 - y0), Math.abs(z1 - z0), 0, 0, 0, mat, ts); }
    rbox(cx, cy, cz, sx, sy, sz, ry, rx, rz, mat, ts) {
        if (!(sx > 0 && sy > 0 && sz > 0)) return;
        const a = this._acc(mat), R = rotMat(ry || 0, rx || 0, rz || 0), h = [sx / 2, sy / 2, sz / 2], tile = ts || 40;
        const ox = this.r() * 7, oz = this.r() * 7, tint = (mat.userData && mat.userData.noTint) ? 1 : 0.88 + this.r() * 0.2;
        for (let f = 0; f < 6; f++) {
            const [n, u, v] = FACES[f];
            const ax = n[0] ? 0 : n[1] ? 1 : 2, au = u[0] ? 0 : u[1] ? 1 : 2, av = v[0] ? 0 : v[1] ? 1 : 2;
            const du = h[au] * 2, dv = h[av] * 2, nn = rv(R, n), base = a.v;
            for (let k = 0; k < 4; k++) {
                const su = (k === 1 || k === 2) ? 1 : -1, sv = (k >= 2) ? 1 : -1;
                const lp = [n[0] * h[ax] + u[0] * su * h[au] + v[0] * sv * h[av], n[1] * h[ax] + u[1] * su * h[au] + v[1] * sv * h[av], n[2] * h[ax] + u[2] * su * h[au] + v[2] * sv * h[av]];
                const wp = rv(R, lp);
                a.p.push(cx + wp[0], cy + wp[1], cz + wp[2]); a.n.push(nn[0], nn[1], nn[2]);
                a.u.push(ox + (su > 0 ? du : 0) / tile, oz + (sv > 0 ? dv : 0) / tile); a.c.push(tint, tint, tint);
            }
            a.i.push(base, base + 1, base + 2, base, base + 2, base + 3); a.v += 4;
        }
    }
    build(parent, name) {
        const meshes = [];
        for (const [mat, a] of this.m) {
            const g = new THREE.BufferGeometry();
            g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(a.p), 3));
            g.setAttribute('normal', new THREE.BufferAttribute(new Float32Array(a.n), 3));
            g.setAttribute('uv', new THREE.BufferAttribute(new Float32Array(a.u), 2));
            g.setAttribute('color', new THREE.BufferAttribute(new Float32Array(a.c), 3));
            g.setIndex(new THREE.BufferAttribute(a.v > 65535 ? new Uint32Array(a.i) : new Uint16Array(a.i), 1));
            if (g.computeBoundingSphere) g.computeBoundingSphere();
            mat.vertexColors = true;
            const mesh = new THREE.Mesh(g, mat); mesh.name = (name || 'lev') + ':' + (mat.name || 'mat'); mesh.frustumCulled = false;
            parent.add(mesh); meshes.push(mesh);
        }
        return meshes;
    }
}

// ---------------------------------------------------------------------------------------------------------------------------------
// Painted canvas textures (skipped when there is no document, e.g. in the node tests)
// ---------------------------------------------------------------------------------------------------------------------------------
function canvasTex(w, h, draw) {
    if (typeof document === 'undefined') return null;
    const c = document.createElement('canvas'); c.width = w; c.height = h;
    draw(c.getContext('2d'), w, h);
    const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4; return t;
}
function smudges(g, w, h, r, n, a0, a1, dark) {
    for (let i = 0; i < n; i++) {
        g.globalAlpha = a0 + r() * (a1 - a0); g.fillStyle = r() < dark ? '#000' : '#fff';
        const x = r() * w, y = r() * h, rw = 4 + r() * 30, rh = 3 + r() * 16; g.fillRect(x, y, rw, rh);
    }
    g.globalAlpha = 1;
}
function plateTex(base, seam, seed, rust) {
    return canvasTex(256, 256, (g, w, h) => {
        const r = rng(seed);
        g.fillStyle = base; g.fillRect(0, 0, w, h);
        smudges(g, w, h, r, 220, 0.03, 0.09, 0.62);
        if (rust) { for (let i = 0; i < 26; i++) { const x = r() * w; g.globalAlpha = 0.06 + r() * 0.12; g.fillStyle = r() < 0.5 ? '#8a4a22' : '#5a2c18'; g.fillRect(x, r() * h * 0.5, 2 + r() * 6, 20 + r() * 130); } g.globalAlpha = 1; }
        g.strokeStyle = seam; g.lineWidth = 3; g.globalAlpha = 0.85;
        g.strokeRect(2, 2, w - 4, h - 4); g.beginPath(); g.moveTo(w / 2, 0); g.lineTo(w / 2, h); g.moveTo(0, h / 2); g.lineTo(w, h / 2); g.stroke(); g.globalAlpha = 1;
        g.fillStyle = 'rgba(0,0,0,0.5)';
        for (const [x, y] of [[10, 10], [w - 10, 10], [10, h - 10], [w - 10, h - 10], [w / 2 + 10, h / 2 + 10], [w / 2 - 10, h / 2 - 10], [w / 2 + 10, h / 2 - 10], [w / 2 - 10, h / 2 + 10]]) { g.beginPath(); g.arc(x, y, 3, 0, 6.283); g.fill(); }
    });
}
function floorTex(seed) {
    return canvasTex(256, 256, (g, w, h) => {
        const r = rng(seed); g.fillStyle = '#3b3733'; g.fillRect(0, 0, w, h);
        smudges(g, w, h, r, 260, 0.04, 0.11, 0.7);
        g.strokeStyle = 'rgba(0,0,0,0.55)'; g.lineWidth = 2;
        for (let i = -h; i < w + h; i += 32) { g.beginPath(); g.moveTo(i, 0); g.lineTo(i + h, h); g.stroke(); g.beginPath(); g.moveTo(i + h, 0); g.lineTo(i, h); g.stroke(); }
        g.strokeStyle = 'rgba(255,200,150,0.07)'; g.lineWidth = 1;
        for (let i = -h; i < w + h; i += 32) { g.beginPath(); g.moveTo(i + 2, 0); g.lineTo(i + h + 2, h); g.stroke(); }
        g.strokeStyle = '#201d1a'; g.lineWidth = 4; g.strokeRect(0, 0, w, h);
    });
}
function hazardTex() {
    return canvasTex(128, 64, (g, w, h) => {
        g.fillStyle = '#d9a21b'; g.fillRect(0, 0, w, h); g.fillStyle = '#17130f';
        for (let x = -h; x < w + h; x += 32) { g.beginPath(); g.moveTo(x, h); g.lineTo(x + 16, h); g.lineTo(x + 16 + h, 0); g.lineTo(x + h, 0); g.closePath(); g.fill(); }
        smudges(g, w, h, rng(5), 90, 0.06, 0.22, 0.8);
    });
}
function crackTex() {
    return canvasTex(512, 320, (g, w, h) => {
        const r = rng(3); g.clearRect(0, 0, w, h); g.strokeStyle = 'rgba(235,225,215,0.9)'; g.lineCap = 'round';
        for (const [cx, cy] of [[w * 0.62, h * 0.38], [w * 0.2, h * 0.7], [w * 0.85, h * 0.8]]) {
            for (let k = 0; k < 11; k++) {
                let a = r() * 6.283, x = cx, y = cy; g.lineWidth = 1 + r() * 1.6; g.beginPath(); g.moveTo(x, y);
                for (let s = 0; s < 9; s++) { a += (r() - 0.5) * 0.7; const l = 14 + r() * 38; x += Math.cos(a) * l; y += Math.sin(a) * l; g.lineTo(x, y); }
                g.stroke();
            }
        }
        g.globalAlpha = 0.18; g.fillStyle = '#d8c8b8'; g.fillRect(0, 0, w, h);
    });
}
function emblemTex(kind) {   // salvaged hull plates: the Advanced Space Systems mark, and angular Aurelian script
    return canvasTex(256, 128, (g, w, h) => {
        const r = rng(kind === 'ass' ? 21 : 22); g.fillStyle = '#46505a'; g.fillRect(0, 0, w, h); smudges(g, w, h, r, 120, 0.04, 0.12, 0.6);
        g.strokeStyle = '#cfd6d9'; g.fillStyle = '#cfd6d9'; g.lineWidth = 3;
        if (kind === 'ass') {
            g.beginPath(); g.arc(52, 64, 34, 0, 6.283); g.stroke();
            g.beginPath(); g.arc(52, 64, 34, Math.PI * 0.5, Math.PI * 1.5); g.fill();
            g.font = 'bold 22px monospace'; g.textBaseline = 'middle'; g.fillText('A.S.S.', 100, 40); g.font = '12px monospace'; g.fillText('ADVANCED SPACE', 100, 70); g.fillText('SYSTEMS', 100, 86);
        } else {
            for (let row = 0; row < 3; row++) { let x = 18; while (x < w - 24) { const l = 8 + r() * 22; g.beginPath(); g.moveTo(x, 30 + row * 34); g.lineTo(x + l * 0.4, 14 + row * 34 + r() * 8); g.lineTo(x + l, 34 + row * 34); g.stroke(); x += l + 8 + r() * 8; } }
        }
        g.globalAlpha = 0.28; g.fillStyle = '#2a1608'; for (let i = 0; i < 12; i++) g.fillRect(r() * w, r() * h * 0.4, 3 + r() * 6, 20 + r() * 80); g.globalAlpha = 1;
    });
}

// The storm / sky behind the glass lives in leviathan_sky.js (STORM_VS / STORM_FS), so it can be compiled and rendered on its own in tests/sky_render.py.

// ---------------------------------------------------------------------------------------------------------------------------------
// Synthesised audio. Everything is built on the game's own AudioContext, into one master gain that follows the game's SFX volume.
// ---------------------------------------------------------------------------------------------------------------------------------
function makeAudio(deps) {
    let ctx = null, master = null, noise = null, amb = null, alarm = null, scrape = null, started = false;
    function init() {
        if (!ctx) { try { ctx = deps.getAudioContext && deps.getAudioContext(); } catch (e) { ctx = null; } }
        if (!ctx) return false;
        master = ctx.createGain(); master.gain.value = 0; master.connect(ctx.destination);
        if (noise) return true;
        const len = ctx.sampleRate * 2, buf = ctx.createBuffer(1, len, ctx.sampleRate), d = buf.getChannelData(0);
        for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
        noise = buf; return true;
    }
    const nsrc = (loop) => { const s = ctx.createBufferSource(); s.buffer = noise; s.loop = !!loop; if (loop) s.loopStart = Math.random() * 0.5; return s; };
    function start() {
        if (started || !init()) return; started = true;
        // ambient: air handling (band-limited noise), a low machine bed and a slow beating tonal pair
        const ag = ctx.createGain(); ag.gain.value = 0; ag.connect(master);
        const n = nsrc(true), bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 520; bp.Q.value = 0.4;
        const lfo = ctx.createOscillator(), lg = ctx.createGain(); lfo.frequency.value = 0.07; lg.gain.value = 160; lfo.connect(lg); lg.connect(bp.frequency);
        n.connect(bp); bp.connect(ag); n.start(); lfo.start();
        const o1 = ctx.createOscillator(), o2 = ctx.createOscillator(), o3 = ctx.createOscillator(), og = ctx.createGain(); og.gain.value = 0.05;
        o1.type = 'sine'; o1.frequency.value = 55; o2.type = 'triangle'; o2.frequency.value = 110.4; o3.type = 'sine'; o3.frequency.value = 221.5;
        o1.connect(og); o2.connect(og); o3.connect(og); og.connect(ag); o1.start(); o2.start(); o3.start();
        amb = { g: ag, nodes: [n, lfo, o1, o2, o3] };
        // alarm: two-tone square through a low-pass, gated by an LFO
        const al = ctx.createGain(); al.gain.value = 0; al.connect(master);
        const sq = ctx.createOscillator(); sq.type = 'square'; sq.frequency.value = 440; const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 1100;
        const gate = ctx.createGain(); gate.gain.value = 0.5; const gl = ctx.createOscillator(), glg = ctx.createGain(); gl.frequency.value = 1.15; glg.gain.value = 0.5; gl.connect(glg); glg.connect(gate.gain);
        const fm = ctx.createOscillator(), fg = ctx.createGain(); fm.type = 'square'; fm.frequency.value = 1.15; fg.gain.value = 65; fm.connect(fg); fg.connect(sq.frequency);
        sq.connect(lp); lp.connect(gate); gate.connect(al); sq.start(); gl.start(); fm.start();
        alarm = { g: al, nodes: [sq, gl, fm] };
        // scrape: noise band-passed by speed, plus a thin screech
        const sg = ctx.createGain(); sg.gain.value = 0; sg.connect(master);
        const sn = nsrc(true), sb = ctx.createBiquadFilter(); sb.type = 'bandpass'; sb.frequency.value = 800; sb.Q.value = 1.1; sn.connect(sb); sb.connect(sg); sn.start();
        const sc = ctx.createOscillator(); sc.type = 'sawtooth'; sc.frequency.value = 1300; const scg = ctx.createGain(); scg.gain.value = 0.12; sc.connect(scg); scg.connect(sg); sc.start();
        scrape = { g: sg, bp: sb, saw: sc, nodes: [sn, sc] };
    }
    const t0 = () => ctx.currentTime;
    function levels(o) {   // {ambient, alarm, scrape, scrapeHz, volume}
        if (!ctx || !started) return;
        const v = (typeof deps.getVolume === 'function' ? deps.getVolume() : 1);
        master.gain.setTargetAtTime(0.9 * clamp(v, 0, 1), t0(), 0.15);
        if (o.ambient !== undefined) amb.g.gain.setTargetAtTime(o.ambient, t0(), 0.4);
        if (o.alarm !== undefined) alarm.g.gain.setTargetAtTime(o.alarm, t0(), 0.2);
        if (o.scrape !== undefined) {
            scrape.g.gain.setTargetAtTime(o.scrape, t0(), 0.08);
            if (o.scrapeHz) { scrape.bp.frequency.setTargetAtTime(o.scrapeHz, t0(), 0.08); scrape.saw.frequency.setTargetAtTime(o.scrapeHz * 1.6, t0(), 0.08); }
        }
    }
    function burst(o) {   // noise burst: {dur, gain, lo, hi, at}
        if (!ctx || !started) return; const t = t0() + (o.at || 0);
        const s = nsrc(false), g = ctx.createGain(), hp = ctx.createBiquadFilter(), lp = ctx.createBiquadFilter();
        hp.type = 'highpass'; hp.frequency.value = o.lo || 60; lp.type = 'lowpass'; lp.frequency.value = o.hi || 4000;
        g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(o.gain || 0.5, t + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, t + (o.dur || 0.4));
        s.connect(hp); hp.connect(lp); lp.connect(g); g.connect(master); s.start(t, Math.random()); s.stop(t + (o.dur || 0.4) + 0.05);
    }
    function thump(o) {   // sine drop: {f0, f1, dur, gain, at}
        if (!ctx || !started) return; const t = t0() + (o.at || 0);
        const os = ctx.createOscillator(), g = ctx.createGain(); os.type = 'sine';
        os.frequency.setValueAtTime(o.f0 || 90, t); os.frequency.exponentialRampToValueAtTime(o.f1 || 30, t + (o.dur || 0.5));
        g.gain.setValueAtTime(o.gain || 0.7, t); g.gain.exponentialRampToValueAtTime(0.0001, t + (o.dur || 0.5)); os.connect(g); g.connect(master); os.start(t); os.stop(t + (o.dur || 0.5) + 0.05);
    }
    function creak(o) {   // slow metal groan: {f, dur, gain, at}
        if (!ctx || !started) return; const t = t0() + (o.at || 0), dur = o.dur || 1.6;
        const os = ctx.createOscillator(), g = ctx.createGain(), lp = ctx.createBiquadFilter(); os.type = 'sawtooth'; lp.type = 'lowpass'; lp.frequency.value = 520;
        os.frequency.setValueAtTime(o.f || 140, t); os.frequency.linearRampToValueAtTime((o.f || 140) * (0.62 + Math.random() * 0.2), t + dur);
        g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(o.gain || 0.12, t + dur * 0.3); g.gain.linearRampToValueAtTime(0.0001, t + dur);
        os.connect(lp); lp.connect(g); g.connect(master); os.start(t); os.stop(t + dur + 0.05);
    }
    function tone(o) {   // pitched blip / sweep: {f0, f1, dur, gain, at, type}
        if (!ctx || !started) return; const t = t0() + (o.at || 0), dur = o.dur || 0.4;
        const os = ctx.createOscillator(), g = ctx.createGain(); os.type = o.type || 'sine';
        os.frequency.setValueAtTime(o.f0 || 440, t); if (o.f1) os.frequency.exponentialRampToValueAtTime(o.f1, t + dur);
        g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(o.gain || 0.2, t + Math.min(0.03, dur * 0.3)); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
        os.connect(g); g.connect(master); os.start(t); os.stop(t + dur + 0.05);
    }
    function thunder(strength, delay) { burst({ dur: 2.4 + strength * 1.2, gain: 0.25 + strength * 0.45, lo: 30, hi: 260, at: delay || 0.4 }); thump({ f0: 62, f1: 28, dur: 1.8, gain: 0.25 * strength, at: (delay || 0.4) + 0.05 }); }
    function stop() {   // fade out and release; start() can be called again later
        if (!ctx || !started) return; started = false;
        const m = master, all = [].concat(amb ? amb.nodes : [], alarm ? alarm.nodes : [], scrape ? scrape.nodes : []);
        try { m.gain.setTargetAtTime(0, t0(), 0.2); } catch (e) { /* ignore */ }
        amb = alarm = scrape = null;
        setTimeout(() => { for (const n of all) { try { n.stop(); } catch (e) { /* ignore */ } } try { m.disconnect(); } catch (e) { /* ignore */ } }, 1000);
    }
    return { start, levels, burst, thump, creak, tone, thunder, stop, get ready() { return started; } };
}

// ---------------------------------------------------------------------------------------------------------------------------------
// createLeviathan(deps)
//   deps.getAudioContext() -> AudioContext | null      deps.getVolume() -> 0..1 (the game's SFX volume scale)
//   deps.onEvent(name, data)                           'halt' (the ship has stopped), 'free' (the player may walk), 'zone:<name>'
// ---------------------------------------------------------------------------------------------------------------------------------
export function createLeviathan(deps) {
    deps = deps || {};
    const scene = new THREE.Scene();
    const walk = [], obst = [];
    const S = { built: false, t: 0, flash: 0, nextBolt: 4, boltT: 99, boltAmp: 1, shake: 0, shakeT: 0, camShake: [0, 0, 0], alarm: 0, ambient: 0.2, zones: {} };
    const parts = {}, mats = {};
    const audio = makeAudio(deps);
    const landing = { active: false, phase: 'idle', t: 0, kickT: 0, canKick: false };
    let overlay = null, flashEl = null, fadeEl = null;
    let sparks = null, dust = null, flames = null;

    // ---- collision ------------------------------------------------------------------------------------------------------------------------
    function resolve(lx, lz) {
        let best = null, bd = 1e12;
        for (const r of walk) {
            const m = 1.0, cx = Math.max(r.x0 + m, Math.min(r.x1 - m, lx)), cz = Math.max(r.z0 + m, Math.min(r.z1 - m, lz)), d = (cx - lx) ** 2 + (cz - lz) ** 2;
            if (d < bd) { bd = d; best = [cx, cz]; }
        }
        let x = best[0], z = best[1];
        for (const o of obst) {
            const e = 1.4;
            if (x > o[0] - e && x < o[1] + e && z > o[2] - e && z < o[3] + e) {
                const dl = x - (o[0] - e), dr = (o[1] + e) - x, dt = z - (o[2] - e), db = (o[3] + e) - z, mn = Math.min(dl, dr, dt, db);
                if (mn === dl) x = o[0] - e; else if (mn === dr) x = o[1] + e; else if (mn === dt) z = o[2] - e; else z = o[3] + e;
            }
        }
        return [x, z];
    }

    // ---- materials ------------------------------------------------------------------------------------------------------------------------
    function makeMaterials() {
        const std = (name, o) => { const m = new THREE.MeshStandardMaterial(Object.assign({ roughness: 0.85, metalness: 0.2 }, o)); m.name = name; return m; };
        const basic = (name, o) => { const m = new THREE.MeshBasicMaterial(o); m.name = name; m.userData = { noTint: true }; m.toneMapped = false; m.fog = false; return m; };
        mats.iron = std('iron', { color: 0xffffff, map: plateTex('#4b4641', '#1d1a17', 31, true), roughness: 0.82, metalness: 0.35 });
        mats.ironDark = std('ironDark', { color: 0xffffff, map: plateTex('#322e2b', '#14110f', 32, true), roughness: 0.9, metalness: 0.3 });
        mats.brass = std('brass', { color: 0xb98a46, roughness: 0.45, metalness: 0.8 });
        mats.floor = std('floor', { color: 0xffffff, map: floorTex(33), roughness: 0.55, metalness: 0.45 });
        mats.scorch = std('scorch', { color: 0x14100d, roughness: 0.9, metalness: 0.1 });
        mats.puddle = std('puddle', { color: 0x1a1512, roughness: 0.12, metalness: 0.6 });
        mats.rust = std('rust', { color: 0x7a4326, roughness: 0.95, metalness: 0.2 });
        mats.crateA = std('crateA', { color: 0x6b3a2a, roughness: 0.9, metalness: 0.25 });
        mats.crateB = std('crateB', { color: 0x3f5648, roughness: 0.9, metalness: 0.25 });
        mats.crateC = std('crateC', { color: 0x44505e, roughness: 0.9, metalness: 0.25 });
        mats.hazard = std('hazard', { color: 0xffffff, map: hazardTex(), roughness: 0.8, metalness: 0.2 });
        mats.glass = std('glass', { color: 0x2a1209, roughness: 0.1, metalness: 0.3, transparent: true, opacity: 0.14, depthWrite: false });
        mats.hull = std('hull', { color: 0xffffff, map: plateTex('#6d6a66', '#2a2724', 34, false), roughness: 0.6, metalness: 0.55 });
        mats.hullBurn = std('hullBurn', { color: 0x2b2420, roughness: 0.8, metalness: 0.4 });
        mats.plateAss = std('plateAss', { color: 0xffffff, map: emblemTex('ass'), roughness: 0.6, metalness: 0.5 });
        mats.plateAur = std('plateAur', { color: 0xffffff, map: emblemTex('aur'), roughness: 0.6, metalness: 0.5 });
        mats.droneBody = std('droneBody', { color: 0x2c2724, roughness: 0.6, metalness: 0.6 });
        mats.lampOn = basic('lampOn', { color: new THREE.Color(1.6, 1.0, 0.55) });
        mats.lampFlick = basic('lampFlick', { color: new THREE.Color(1.6, 1.0, 0.55) });
        mats.lampDead = basic('lampDead', { color: 0x1a1210 });
        mats.red = basic('red', { color: new THREE.Color(2.2, 0.15, 0.08) });
        mats.redPulse = basic('redPulse', { color: new THREE.Color(2.2, 0.15, 0.08) });
        mats.eye = basic('eye', { color: new THREE.Color(0.7, 0.05, 0.03) });
        mats.ember = basic('ember', { color: new THREE.Color(2.0, 0.7, 0.2) });
        mats.field = basic('field', { color: new THREE.Color(0.5, 1.3, 1.7), transparent: true, opacity: 0.35, side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending });
        mats.far = new THREE.MeshBasicMaterial({ color: 0x1a0d08 }); mats.far.name = 'far'; mats.far.userData = { noTint: true }; mats.far.fog = false;
        mats.beacon = basic('beacon', { color: new THREE.Color(2.5, 0.2, 0.1) });
    }

    // ---- wall with windows ----------------------------------------------------------------------------------------------------------------
    function windowedWall(B, axis, f0, f1, s0, s1, h, centers, ww, wy0, wy1, wallMat) {
        const put = (a0, a1, y0, y1, m) => axis === 'x' ? B.box(f0, f1, y0, y1, a0, a1, m, 40) : B.box(a0, a1, y0, y1, f0, f1, m, 40);
        put(s0, s1, 0, wy0, wallMat); put(s0, s1, wy1, h, wallMat);
        let cur = s0; for (const c of centers.slice().sort((a, b) => a - b)) { put(cur, c - ww / 2, wy0, wy1, wallMat); cur = c + ww / 2; }
        put(cur, s1, wy0, wy1, wallMat);
        for (const c of centers) {
            const a = c - ww / 2, b = c + ww / 2, my = (wy0 + wy1) / 2;
            put(a - 1.4, a + 1.4, wy0, wy1, mats.brass); put(b - 1.4, b + 1.4, wy0, wy1, mats.brass);
            put(a, b, wy0 - 1.4, wy0 + 1.4, mats.brass); put(a, b, wy1 - 1.4, wy1 + 1.4, mats.brass);
            put(c - 0.9, c + 0.9, wy0, wy1, mats.brass); put(a, b, my - 0.9, my + 0.9, mats.brass);
            const gm = (f0 + f1) / 2; if (axis === 'x') B.box(gm - 0.2, gm + 0.2, wy0, wy1, a, b, mats.glass, 40); else B.box(a, b, wy0, wy1, gm - 0.2, gm + 0.2, mats.glass, 40);
        }
    }

    // ---- build ----------------------------------------------------------------------------------------------------------------------------
    function build() {
        if (S.built) return scene;
        makeMaterials();
        const bay = L.bay, cor = L.cor, T = L.T, B = new Batch(101), r = rng(77);
        scene.fog = new THREE.Fog(0x1b0e08, 140, 1250);

        // walkable rectangles
        walk.push({ x0: bay.x0, x1: bay.x1, z0: bay.z0, z1: bay.z1 });
        walk.push({ x0: L.doorX + 14, x1: cor.x1 + 6, z0: cor.z0, z1: cor.z1 });   // overlaps the bay by 6 so the doorway is continuous

        // floors and ceilings
        B.box(bay.x0 - T, bay.x1 + T, -4, 0, bay.z0 - T, bay.z1 + T, mats.floor, 40);
        B.box(cor.x0 - T, cor.x1, -4, 0, cor.z0 - T, cor.z1 + T, mats.floor, 40);
        B.box(bay.x0 - T, bay.x1 + T, bay.h, bay.h + 6, bay.z0 - T, bay.z1 + T, mats.ironDark, 60);
        B.box(cor.x0 - T, cor.x1, cor.h, cor.h + 5, cor.z0 - T, cor.z1 + T, mats.ironDark, 60);

        // bay walls: east (storm windows), west (doorway), north (bulkhead), south (the breach)
        const winC = [80, -10, -100, -190, -280];
        windowedWall(B, 'x', bay.x1, bay.x1 + T, bay.z0 - T, bay.z1 + T, bay.h, winC, 56, 28, 150, mats.iron);
        // west wall with the doorway
        B.box(bay.x0 - T, bay.x0, 0, bay.h, L.door.z1, bay.z1 + T, mats.iron, 40);
        B.box(bay.x0 - T, bay.x0, 0, bay.h, bay.z0 - T, L.door.z0, mats.iron, 40);
        B.box(bay.x0 - T, bay.x0, L.door.h, bay.h, L.door.z0, L.door.z1, mats.iron, 40);
        for (const z of [L.door.z0 - 2, L.door.z1 + 2]) B.box(bay.x0 - T - 2, bay.x0 + 2, 0, L.door.h + 2, z - 2, z + 2, mats.hazard, 24);
        B.box(bay.x0 - T - 2, bay.x0 + 2, L.door.h, L.door.h + 4, L.door.z0 - 4, L.door.z1 + 4, mats.hazard, 24);
        // north bulkhead, with the buckled apron the ship ran into
        B.box(bay.x0 - T, bay.x1 + T, 0, bay.h, bay.z0 - T, bay.z0, mats.ironDark, 40);
        for (let i = -3; i <= 3; i++) B.box(i * 38 - 1.5, i * 38 + 1.5, 0, bay.h, bay.z0, bay.z0 + 3, mats.brass, 40);
        B.rbox(-14, 18, -366, 40, 36, 3.5, 0.18, 0.05, 0.03, mats.hullBurn, 30); B.rbox(16, 22, -365, 36, 44, 3.5, -0.2, -0.04, 0.05, mats.ironDark, 30);
        B.rbox(0, 5, -367, 70, 10, 4, 0.02, 0.0, 0.06, mats.hullBurn, 30);
        // south wall with the breach
        const br = L.breach;
        B.box(bay.x0 - T, br.x0, 0, bay.h, bay.z1, bay.z1 + T, mats.iron, 40); B.box(br.x1, bay.x1 + T, 0, bay.h, bay.z1, bay.z1 + T, mats.iron, 40);
        B.box(br.x0, br.x1, 0, br.y0, bay.z1, bay.z1 + T, mats.iron, 40); B.box(br.x0, br.x1, br.y1, bay.h, bay.z1, bay.z1 + T, mats.iron, 40);
        for (let i = 0; i < 9; i++) {   // torn, bent beams hanging into the breach
            const x = lerp(br.x0 + 6, br.x1 - 6, r()), top = r() < 0.5, y = top ? br.y1 - 4 - r() * 12 : br.y0 + 3 + r() * 6, len = 12 + r() * 30;
            B.rbox(x, y, bay.z1 - 2 - r() * 4, 3 + r() * 3, len, 3, 0, (r() - 0.5) * 0.6, (r() - 0.5) * 0.7, i % 2 ? mats.hullBurn : mats.rust, 30);
        }
        B.box(br.x0 - 5, br.x0 + 1, br.y0 - 4, br.y1 + 4, bay.z1 - 3, bay.z1 + 2, mats.brass, 30); B.box(br.x1 - 1, br.x1 + 5, br.y0 - 4, br.y1 + 4, bay.z1 - 3, bay.z1 + 2, mats.brass, 30);

        // corridor walls: south side has the storm windows, north side is solid with sealed side doors
        const cx1 = cor.x1 - T;   // the corridor's own walls stop where the bay's west wall begins
        windowedWall(B, 'z', cor.z0 - T, cor.z0, cor.x0 - T, cx1, cor.h, [-205, -273, -341, -409], 44, 12, 72, mats.iron);
        B.box(cor.x0 - T, cx1, 0, cor.h, cor.z1, cor.z1 + T, mats.iron, 40);
        for (const x of [-235, -330, -420]) { B.box(x - 12, x + 12, 0, 54, cor.z1 - 2, cor.z1 + 1, mats.ironDark, 30); B.box(x - 14, x - 12, 0, 56, cor.z1 - 3, cor.z1 + 2, mats.brass, 30); B.box(x + 12, x + 14, 0, 56, cor.z1 - 3, cor.z1 + 2, mats.brass, 30); B.box(x - 2, x + 2, 24, 28, cor.z1 - 3.5, cor.z1 - 2, mats.red, 10); }
        for (let x = cx1 - 12; x > cor.x0; x -= 24) { B.box(x - 1.6, x + 1.6, 0, cor.h, cor.z0, cor.z0 + 3, mats.brass, 30); B.box(x - 1.6, x + 1.6, cor.h - 3, cor.h, cor.z0, cor.z1, mats.brass, 30); B.box(x - 1.6, x + 1.6, 0, cor.h, cor.z1 - 3, cor.z1, mats.brass, 30); }
        // the blast door's FRAME (the two sliding panels, the console and the room beyond are built by leviathan_hack.js so they can open)
        const dx = L.doorX;
        B.box(dx - T, dx, 72, cor.h + 5, cor.z0 - T, cor.z1 + T, mats.ironDark, 40);   // wall above the opening
        B.box(dx + 5, dx + 9, 72, 78, cor.z0, cor.z1, mats.hazard, 24); B.box(dx + 5, dx + 9, 0, 4, cor.z0, cor.z1, mats.hazard, 24);
        for (const z of [cor.z0 + 4, cor.z1 - 4]) { B.box(dx + 5, dx + 9, 0, 78, z - 3, z + 3, mats.brass, 24); }
        obst.push([dx + 5, dx + 9, cor.z0, cor.z0 + 7], [dx + 5, dx + 9, cor.z1 - 7, cor.z1]);   // the jamb posts are solid

        // ceiling beams, girders, gantry, lamps
        for (let z = bay.z0 + 20; z < bay.z1; z += 40) B.box(bay.x0, bay.x1, bay.h - 14, bay.h, z - 3, z + 3, mats.ironDark, 40);
        for (const x of [-100, 0, 100]) B.box(x - 4, x + 4, bay.h - 22, bay.h - 14, bay.z0, bay.z1, mats.ironDark, 40);
        B.box(bay.x0, bay.x1, 148, 158, -60 - 5, -60 + 5, mats.iron, 40); B.box(-8, 8, 138, 148, -66, -54, mats.brass, 20);
        for (let i = 0; i < 3; i++) B.box(-0.6 + i * 3 - 3, 0.6 + i * 3 - 3, 90, 138, -61, -59, mats.ironDark, 8);
        B.rbox(0, 80, -60, 14, 14, 14, 0.3, 0, 0, mats.rust, 14);
        const lampsFlick = [], lampsDead = [];
        for (let z = bay.z0 + 40; z < bay.z1 - 20; z += 80) for (const x of [-100, -50, 50, 100]) {
            const m = ((Math.round(z) + Math.round(x)) % 3 === 0) ? mats.lampDead : ((Math.round(z / 80) + (x > 0 ? 1 : 0)) % 4 === 0 ? mats.lampFlick : mats.lampOn);
            B.box(x - 7, x + 7, bay.h - 16, bay.h - 14, z - 5, z + 5, m, 10);
        }
        for (let x = cor.x1 - 40; x > cor.x0 + 20; x -= 64) B.box(x - 6, x + 6, cor.h - 3, cor.h - 1, (cor.z0 + cor.z1) / 2 - 3, (cor.z0 + cor.z1) / 2 + 3, ((x | 0) % 3 === 0) ? mats.lampFlick : mats.lampOn, 10);

        // runway: lane lines, the skid and the scorch where the ship ended
        for (const x of [-46, 46]) B.box(x - 2, x + 2, 0, 0.25, bay.z0 + 30, bay.z1, mats.hazard, 24);
        for (let z = bay.z1 - 10; z > bay.z0 + 40; z -= 36) B.box(-1, 1, 0, 0.2, z - 8, z, mats.hazard, 24);
        B.box(-13, 13, 0.05, 0.3, bay.z0 + 24, bay.z1 - 8, mats.scorch, 30);
        for (const dxs of [-9, -3.5, 4, 8.5]) B.box(dxs - 0.8, dxs + 0.8, 0.12, 0.45, bay.z0 + 28 + r() * 40, bay.z1 - 30 - r() * 60, mats.hullBurn, 30);
        B.box(-9, 9, 0.15, 0.5, L.stop.z - 20, L.stop.z + 40, mats.scorch, 20);
        for (let i = 0; i < 24; i++) B.box(-10 + r() * 20, -10 + r() * 20 + 1.2, 0.3, 0.9, L.stop.z - 18 + r() * 60, L.stop.z - 18 + r() * 60 + 1.2, mats.ember, 4);
        for (let i = 0; i < 7; i++) { const x = (r() - 0.5) * 200, z = bay.z0 + 50 + r() * 380, w = 12 + r() * 18; B.box(x - w, x + w, 0.06, 0.12, z - w * 0.6, z + w * 0.6, mats.puddle, 20); }

        // columns along the west wall; the stolen-tech graveyard (crates, salvaged plates, dead drones) in two west clusters
        for (let z = bay.z0 + 40; z < bay.z1 - 20; z += 90) { if (z > L.door.z0 - 16 && z < L.door.z1 + 16) continue; B.box(bay.x0, bay.x0 + 16, 0, bay.h - 14, z - 8, z + 8, mats.ironDark, 30); B.box(bay.x0, bay.x0 + 18, 30, 34, z - 9, z + 9, mats.brass, 20); obst.push([bay.x0, bay.x0 + 16, z - 8, z + 8]); }
        const crate = (x, z, w, d, h, m, rot, y0) => { const yy = y0 || 0; B.rbox(x, yy + h / 2, z, w, h, d, rot || 0, 0, 0, m, 24); B.box(x - w / 2 - 0.4, x + w / 2 + 0.4, yy + h * 0.45, yy + h * 0.55, z - d / 2 - 0.4, z + d / 2 + 0.4, mats.ironDark, 16); if (!y0) { const e = Math.abs(Math.sin(rot || 0)) * Math.max(w, d) * 0.25; obst.push([x - w / 2 - e, x + w / 2 + e, z - d / 2 - e, z + d / 2 + e]); } };
        const mm = [mats.crateA, mats.crateB, mats.crateC, mats.rust];
        for (const [x, z] of [[-128, -300], [-100, -270], [-130, -255], [-112, -228], [-95, -215], [-130, -200], [-70, -330]]) { const w = 22 + r() * 10, d = 18 + r() * 8, h = 14 + r() * 10, m = mm[(r() * 4) | 0]; crate(x, z, w, d, h, m, (r() - 0.5) * 0.5); if (r() < 0.6) crate(x + (r() - 0.5) * 4, z, w * 0.8, d * 0.8, 12 + r() * 6, mm[(r() * 4) | 0], (r() - 0.5) * 0.8, h); }
        for (const [x, z] of [[-130, -80], [-104, -52], [-128, -20], [-98, 4], [-126, 28], [-110, 70], [-132, 100]]) { const w = 22 + r() * 10, d = 18 + r() * 8, h = 14 + r() * 10, m = mm[(r() * 4) | 0]; crate(x, z, w, d, h, m, (r() - 0.5) * 0.5); if (r() < 0.5) crate(x + (r() - 0.5) * 4, z, w * 0.8, d * 0.8, 12 + r() * 6, mm[(r() * 4) | 0], (r() - 0.5) * 0.8, h); }
        for (const [x, y, z, ry, m] of [[-118, 13, -312, 0.6, mats.plateAss], [-120, 16, -258, -0.4, mats.plateAur], [-114, 12, -14, 0.5, mats.plateAss], [-92, 15, 50, -0.7, mats.plateAur]]) B.rbox(x, y, z, 2, 18, 30, ry, 0, 0.12, m, 30);
        for (let i = 0; i < 6; i++) {   // dead drones: a low body, three sail blades and a dark eye
            const x = -130 + r() * 60, z = bay.z0 + 80 + r() * 380, a = r() * 6.283;
            B.rbox(x, 2.4, z, 6, 4, 6, a, 0, 0, mats.droneBody, 12); B.rbox(x + Math.cos(a) * 3, 1.1, z + Math.sin(a) * 3, 9, 0.5, 2.4, a + 1.0, 0.0, 0.5, mats.droneBody, 12);
            B.rbox(x - Math.sin(a) * 4, 0.9, z + Math.cos(a) * 4, 8, 0.5, 2.2, a - 0.8, 0.0, -0.4, mats.droneBody, 12); B.box(x - 0.8, x + 0.8, 2.2, 3.2, z - 3.2, z - 3.0, mats.eye, 4);
        }
        // debris from the breach, fallen onto the runway edge
        for (let i = 0; i < 14; i++) B.rbox((r() - 0.5) * 150, 1 + r() * 3, bay.z1 - 15 - r() * 60, 3 + r() * 9, 1 + r() * 5, 3 + r() * 10, r() * 6, (r() - 0.5) * 0.5, (r() - 0.5) * 0.5, i % 3 ? mats.hullBurn : mats.rust, 20);
        // red status panels
        for (const [x, z] of [[-148, 100], [-148, -50], [-148, -330], [148, 120], [148, -360]]) B.box(x - (x < 0 ? -2 : 4) - 0.5, x - (x < 0 ? -2 : 4) + 0.5, 40, 50, z - 6, z + 6, mats.redPulse, 8);

        // the ship wreck
        buildShip(B, r);

        // distant spires beyond the glass, and the gantry rings
        for (let i = 0; i < 46; i++) {
            const a = r() * 6.283, d = 900 + r() * 1700, x = Math.cos(a) * d, z = Math.sin(a) * d, h = 160 + r() * 800, w = 14 + r() * 50;
            B.box(x - w, x + w, -300, h, z - w, z + w, mats.far, 100);
            if (r() < 0.5) B.box(x - w * 1.8, x + w * 1.8, h * 0.6, h * 0.6 + 10, z - w * 1.8, z + w * 1.8, mats.far, 100);
            if (r() < 0.7) B.box(x - 3, x + 3, h, h + 8, z - 3, z + 3, mats.beacon, 4);
        }
        B.build(scene, 'lev');

        // the glow of the torn forcefield: a few flickering shards in the breach
        parts.field = [];
        for (let i = 0; i < 7; i++) {
            const w = 14 + r() * 40, h = 10 + r() * 38, m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), mats.field);
            m.position.set(lerp(br.x0 + 12, br.x1 - 12, r()), lerp(br.y0 + 8, br.y1 - 8, r()), bay.z1 + 3 + r() * 2); m.rotation.z = (r() - 0.5) * 0.8; m.userData.phase = r() * 6.283; scene.add(m); parts.field.push(m);
        }

        // the storm: a sphere that follows the camera
        const sm = new THREE.ShaderMaterial({ vertexShader: STORM_VS, fragmentShader: STORM_FS, side: THREE.BackSide, depthTest: true, depthWrite: false, fog: false, uniforms: { uSeed: { value: 0.3 }, uSteps: { value: 12 }, uTime: { value: 0 }, uFlash: { value: 0 }, uFlashDir: { value: new THREE.Vector3(0.7, 0.3, -0.4) }, uClear: { value: 0 }, uSunDir: { value: new THREE.Vector3(0.89, 0.44, -0.12).normalize() }, uMoonDir: { value: new THREE.Vector3(0.93, 0.20, 0.30).normalize() } } });
        sm.name = 'stormBackdrop'; mats.storm = sm;
        try { registerShaderFallback('LEVFX:storm', () => { console.error('[leviathan] shader "storm" failed to compile; using a flat storm colour.'); const flat = new THREE.MeshBasicMaterial({ color: 0x5a2208, side: THREE.BackSide, depthTest: true, depthWrite: false, fog: false }); if (parts.storm) parts.storm.material = flat; }); } catch (e) { /* ignore */ }
        parts.storm = new THREE.Mesh(new THREE.SphereGeometry(9000, 24, 14), sm); parts.storm.renderOrder = 1000;   // after the opaque meshes, with the depth test on: only pixels seen through windows and the breach are ever shaded
        parts.storm.frustumCulled = false; scene.add(parts.storm);

        // lights
        parts.hemi = new THREE.HemisphereLight(0xb6703f, 0x2a1810, LIGHT.hemi); scene.add(parts.hemi);
        parts.sun = new THREE.DirectionalLight(0xff8a3a, LIGHT.storm); parts.sun.position.set(300, 150, -40); scene.add(parts.sun); scene.add(parts.sun.target);
        const pl = (col, I, dist, x, y, z) => { const p = new THREE.PointLight(col, I, dist, 1); p.position.set(x, y, z); scene.add(p); return p; };
        parts.alarmA = pl(0xff2a1a, LIGHT.alarm, 320, 0, 60, L.stop.z + 40);
        parts.alarmB = pl(0xff2a1a, LIGHT.alarm, 320, 0, 70, L.bay.z1 - 40);
        parts.fire = pl(0xff8a30, LIGHT.fire, 220, 0, 8, L.stop.z + 30);
        parts.corA = pl(0xffb070, LIGHT.corridor, 280, -250, 60, (L.cor.z0 + L.cor.z1) / 2);
        parts.corB = pl(0xff9050, LIGHT.corridor, 280, -400, 60, (L.cor.z0 + L.cor.z1) / 2);
        parts.cockpit = pl(0xff6a3a, 0, 60, 0, 0, 0);

        buildParticles(r);
        buildCockpit();
        S.built = true; return scene;
    }

    // ---- the wreck of the Vale starship ---------------------------------------------------------------------------------------------------
    function buildShip(B2, r) {
        const sh = L.ship, hz = L.hatch, W = sh.x1, ship = new Batch(202), hullM = mats.hull;
        const t = 1.6;
        ship.box(-W, W, 0.4, 2, sh.z0, sh.z1, mats.ironDark, 30);                                // floor
        ship.box(-W, W, sh.h - 1.6, sh.h, sh.z0 + 6, sh.z1, hullM, 30);                          // roof (open over the cockpit)
        ship.box(W - t, W, 2, sh.h, sh.z0, sh.z1, hullM, 30);                                     // east side
        ship.box(-W, -W + t, 2, hz.y0 + 0.01, sh.z0, sh.z1, hullM, 30);                           // west side: below the hatch
        ship.box(-W, -W + t, hz.y1, sh.h, sh.z0, sh.z1, hullM, 30);                               // above
        ship.box(-W, -W + t, hz.y0, hz.y1, sh.z0, hz.z0, hullM, 30); ship.box(-W, -W + t, hz.y0, hz.y1, hz.z1, sh.z1, hullM, 30);
        ship.box(-W, W, 2, sh.h, sh.z1 - t, sh.z1, hullM, 30);                                    // rear bulkhead
        ship.box(-4, 4, 2, 7, sh.z0 + 12, sh.z0 + 18, mats.ironDark, 20);                         // the pilot's seat and console
        ship.rbox(0, 5, sh.z0 + 6, 28, 3, 9, 0, -0.35, 0, mats.ironDark, 20);
        ship.box(-14, 14, 3, 5, sh.z0 + 22, sh.z0 + 24, mats.brass, 20);
        // wings and tail fins, snapped and bent
        ship.rbox(30, 5, -314, 26, 1.6, 24, -0.25, 0.0, -0.3, mats.hullBurn, 30);   // east wing stub only: the west side is the hatch
        ship.rbox(0, 20, sh.z1 + 2, 1.6, 20, 18, 0.0, 0.0, 0.18, hullM, 30);
        // burn marks and a split plate on the roof
        ship.rbox(6, sh.h + 0.4, -330, 16, 0.4, 24, 0.3, 0, 0, mats.hullBurn, 20);
        const hullMeshes = ship.build(scene, 'ship');
        parts.ship = new THREE.Group(); parts.ship.name = 'ship'; scene.remove(...hullMeshes); for (const m of hullMeshes) parts.ship.add(m);
        // the hatch door: a dented plate that can be kicked off
        const hatch = new THREE.Mesh(new THREE.BoxGeometry(1.4, hz.y1 - hz.y0, hz.z1 - hz.z0), hullM);
        hatch.position.set(-W + 0.7, (hz.y0 + hz.y1) / 2, (hz.z0 + hz.z1) / 2); hatch.rotation.z = 0.02; parts.hatch = hatch; parts.ship.add(hatch);
        parts.ship.visible = false; scene.add(parts.ship);
        obst.push([-W - 2, W + 2, sh.z0 - 10, sh.z1 + 2]);
    }

    // ---- the cockpit (parented to the camera's pose, not to the scene graph proper) ---------------------------------------------------------
    function buildCockpit() {
        const g = new THREE.Group(); g.name = 'cockpit'; const dark = new THREE.MeshStandardMaterial({ color: 0x1b1816, roughness: 0.7, metalness: 0.5 });
        const add = (geo, m, x, y, z, rx, ry, rz) => { const o = new THREE.Mesh(geo, m); o.position.set(x, y, z); o.rotation.set(rx || 0, ry || 0, rz || 0); g.add(o); return o; };
        add(new THREE.BoxGeometry(11, 1.4, 3.2), dark, 0, -2.5, -5.0, -0.32, 0, 0);
        add(new THREE.BoxGeometry(0.5, 7.0, 0.5), dark, -4.3, 0.1, -5.0, 0, 0, 0.16); add(new THREE.BoxGeometry(0.5, 7.0, 0.5), dark, 4.3, 0.1, -5.0, 0, 0, -0.16);
        add(new THREE.BoxGeometry(9.6, 0.5, 0.5), dark, 0, 3.0, -5.0, 0, 0, 0);
        add(new THREE.BoxGeometry(0.35, 3.6, 0.35), dark, 1.2, 1.3, -5.0, 0, 0, 0.05);
        const glass = new THREE.MeshBasicMaterial({ map: crackTex(), transparent: true, opacity: 0.8, depthWrite: false, fog: false, color: 0xffffff }); glass.toneMapped = false;
        add(new THREE.PlaneGeometry(9, 5.8), glass, 0, 0.3, -4.9);
        parts.leds = []; const ledRed = new THREE.MeshBasicMaterial({ color: 0xff2a1a }), ledAmb = new THREE.MeshBasicMaterial({ color: 0xffb050 }); ledRed.toneMapped = ledAmb.toneMapped = false;
        for (let i = 0; i < 9; i++) { const led = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.18, 0.18), i % 3 === 0 ? ledRed : ledAmb); led.position.set(-3.8 + i * 0.95, -2.18 + (i % 2) * 0.12, -4.45); led.rotation.x = -0.32; g.add(led); parts.leds.push(led); }
        g.visible = false; parts.cockpitGroup = g; scene.add(g);
    }

    // ---- particles --------------------------------------------------------------------------------------------------------------------------
    function makePoints(n, size, color, additive, opacity) {
        const geo = new THREE.BufferGeometry(); const pos = new Float32Array(n * 3), col = new Float32Array(n * 3);
        geo.setAttribute('position', new THREE.BufferAttribute(pos, 3)); geo.setAttribute('color', new THREE.BufferAttribute(col, 3));
        const m = new THREE.PointsMaterial({ size, color, vertexColors: true, transparent: true, opacity: opacity === undefined ? 1 : opacity, depthWrite: false, sizeAttenuation: true, fog: false });
        if (additive) m.blending = THREE.AdditiveBlending; m.toneMapped = false;
        const pts = new THREE.Points(geo, m); pts.frustumCulled = false; scene.add(pts);
        return { pts, pos, col, n, vel: new Float32Array(n * 3), life: new Float32Array(n), max: new Float32Array(n), head: 0 };
    }
    function buildParticles(r) {
        sparks = makePoints(260, 1.3, 0xffb060, true);
        for (let i = 0; i < sparks.n; i++) sparks.pos[i * 3 + 1] = -9999;
        dust = makePoints(220, 0.45, 0xffc890, false, 0.5);
        for (let i = 0; i < dust.n; i++) { const inCor = i % 3 === 0; dust.pos[i * 3] = inCor ? lerp(L.cor.x0, L.cor.x1, r()) : lerp(L.bay.x0, L.bay.x1, r()); dust.pos[i * 3 + 1] = 4 + r() * (inCor ? 70 : 150); dust.pos[i * 3 + 2] = inCor ? lerp(L.cor.z0, L.cor.z1, r()) : lerp(L.bay.z0, L.bay.z1, r()); dust.col[i * 3] = 0.8 + r() * 0.2; dust.col[i * 3 + 1] = 0.55 + r() * 0.15; dust.col[i * 3 + 2] = 0.35; dust.vel[i * 3] = (r() - 0.5) * 1.2; dust.vel[i * 3 + 1] = (r() - 0.5) * 0.6; dust.vel[i * 3 + 2] = (r() - 0.5) * 1.2; }
        flames = makePoints(90, 3.6, 0xff7a20, true, 0.9);
        for (let i = 0; i < flames.n; i++) flames.life[i] = 0, flames.pos[i * 3 + 1] = -9999;
    }
    const FIRES = [[-22, 0, L.stop.z + 28], [22, 0, L.stop.z + 40], [-60, 0, L.bay.z1 - 40], [64, 0, L.bay.z1 - 30], [-124, 24, -224]];
    function emitSpark(x, y, z, vx, vy, vz, life) {
        const s = sparks, i = s.head; s.head = (s.head + 1) % s.n;
        s.pos[i * 3] = x; s.pos[i * 3 + 1] = y; s.pos[i * 3 + 2] = z; s.vel[i * 3] = vx; s.vel[i * 3 + 1] = vy; s.vel[i * 3 + 2] = vz; s.life[i] = s.max[i] = life;
    }
    function updateParticles(dt, camPos) {
        const s = sparks;
        for (let i = 0; i < s.n; i++) {
            if (s.life[i] <= 0) { if (s.pos[i * 3 + 1] > -9000) { s.pos[i * 3 + 1] = -9999; s.col[i * 3] = s.col[i * 3 + 1] = s.col[i * 3 + 2] = 0; } continue; }
            s.life[i] -= dt; s.vel[i * 3 + 1] -= 90 * dt;
            s.pos[i * 3] += s.vel[i * 3] * dt; s.pos[i * 3 + 1] += s.vel[i * 3 + 1] * dt; s.pos[i * 3 + 2] += s.vel[i * 3 + 2] * dt;
            if (s.pos[i * 3 + 1] < 0.2) { s.pos[i * 3 + 1] = 0.2; s.vel[i * 3 + 1] *= -0.35; s.vel[i * 3] *= 0.7; s.vel[i * 3 + 2] *= 0.7; }
            const k = clamp(s.life[i] / s.max[i], 0, 1); s.col[i * 3] = k; s.col[i * 3 + 1] = k * 0.6; s.col[i * 3 + 2] = k * 0.25;
        }
        s.pts.geometry.attributes.position.needsUpdate = true; s.pts.geometry.attributes.color.needsUpdate = true;
        const d = dust;
        for (let i = 0; i < d.n; i++) {
            d.pos[i * 3] += d.vel[i * 3] * dt; d.pos[i * 3 + 1] += d.vel[i * 3 + 1] * dt; d.pos[i * 3 + 2] += d.vel[i * 3 + 2] * dt;
            const cor = i % 3 === 0, x0 = cor ? L.cor.x0 : L.bay.x0, x1 = cor ? L.cor.x1 : L.bay.x1, z0 = cor ? L.cor.z0 : L.bay.z0, z1 = cor ? L.cor.z1 : L.bay.z1, hh = cor ? 75 : 170;
            if (d.pos[i * 3] < x0 || d.pos[i * 3] > x1) d.vel[i * 3] *= -1; if (d.pos[i * 3 + 2] < z0 || d.pos[i * 3 + 2] > z1) d.vel[i * 3 + 2] *= -1; if (d.pos[i * 3 + 1] < 3 || d.pos[i * 3 + 1] > hh) d.vel[i * 3 + 1] *= -1;
        }
        d.pts.geometry.attributes.position.needsUpdate = true; d.pts.geometry.attributes.color.needsUpdate = true;
        const f = flames;   // a few small fires that flicker and rise
        for (let i = 0; i < f.n; i++) {
            if (f.life[i] <= 0) {
                if (Math.random() < dt * 6) { const fp = FIRES[(Math.random() * FIRES.length) | 0]; f.pos[i * 3] = fp[0] + (Math.random() - 0.5) * 8; f.pos[i * 3 + 1] = fp[1] + 0.5; f.pos[i * 3 + 2] = fp[2] + (Math.random() - 0.5) * 8; f.vel[i * 3] = (Math.random() - 0.5) * 3; f.vel[i * 3 + 1] = 10 + Math.random() * 14; f.vel[i * 3 + 2] = (Math.random() - 0.5) * 3; f.life[i] = f.max[i] = 0.5 + Math.random() * 0.7; }
                else { f.pos[i * 3 + 1] = -9999; f.col[i * 3] = f.col[i * 3 + 1] = f.col[i * 3 + 2] = 0; }
                continue;
            }
            f.life[i] -= dt; f.pos[i * 3] += f.vel[i * 3] * dt; f.pos[i * 3 + 1] += f.vel[i * 3 + 1] * dt; f.pos[i * 3 + 2] += f.vel[i * 3 + 2] * dt;
            const k = clamp(f.life[i] / f.max[i], 0, 1); f.col[i * 3] = k * 1.2; f.col[i * 3 + 1] = k * k * 0.6; f.col[i * 3 + 2] = k * k * k * 0.15;
        }
        f.pts.geometry.attributes.position.needsUpdate = true; f.pts.geometry.attributes.color.needsUpdate = true;
    }

    // ---- DOM overlays (white flash, black fade) ---------------------------------------------------------------------------------------------
    function mountOverlay() {
        if (typeof document === 'undefined' || overlay) return;
        overlay = document.createElement('div'); overlay.id = 'levOverlay'; overlay.style.cssText = 'position:fixed;inset:0;pointer-events:none;z-index:45;';
        flashEl = document.createElement('div'); flashEl.style.cssText = 'position:absolute;inset:0;opacity:0;background:#cfeeff;';
        fadeEl = document.createElement('div'); fadeEl.style.cssText = 'position:absolute;inset:0;opacity:0;background:#000;transition:opacity .6s ease;';
        overlay.appendChild(flashEl); overlay.appendChild(fadeEl); document.body.appendChild(overlay);
    }
    let flashLevel = 0, flashCol = '#cfeeff';
    function screenFlash(level, col) { flashLevel = Math.max(flashLevel, level); if (col && flashEl) flashEl.style.background = col; }
    function fade(to, ms) { if (!fadeEl) return; fadeEl.style.transition = 'opacity ' + (ms || 600) + 'ms ease'; fadeEl.style.opacity = String(to); }

    // ---- landing ----------------------------------------------------------------------------------------------------------------------------
    const ease = (x) => { x = clamp(x, 0, 1); return x * x * (3 - 2 * x); };
    function skidState(s) {   // s in 0..1 -> distance travelled and speed (closed form of v = v0 (1-s)^P)
        const P = LAND.P, d = LAND.dist * (1 - Math.pow(1 - s, P + 1)), v = LAND.v0 * Math.pow(1 - s, P);
        return { d, v };
    }
    const KICK_KEYS = [   // t(s), x, y, z, yaw, pitch, roll
        [0.0, L.stop.x, L.stop.y, L.stop.z, 0, 0, 0],
        [0.45, L.stop.x + 0.3, L.stop.y - 0.2, L.stop.z + 1.4, 0, 0.16, 0.02],
        [0.75, L.stop.x - 0.5, L.stop.y - 0.4, L.stop.z + 2.4, 0.05, -0.06, -0.04],
        [1.45, -6, 10.4, -332, 0.7, -0.05, 0.03],
        [2.15, -16, 9.2, -318, 1.45, -0.07, 0.0],
        [2.9, -28, 8.7, -313, 1.9, -0.02, 0.0],
        [3.4, L.exit.x, L.exit.y, L.exit.z, Math.PI, 0, 0]
    ];
    function kickPose(t, out) {
        let i = 0; while (i < KICK_KEYS.length - 2 && t > KICK_KEYS[i + 1][0]) i++;
        const a = KICK_KEYS[i], b = KICK_KEYS[i + 1], k = ease((t - a[0]) / (b[0] - a[0]));
        for (let j = 0; j < 6; j++) out[j] = lerp(a[j + 1], b[j + 1], k);
        return out;
    }
    function startLanding() {
        S.zones = {}; build(); mountOverlay(); audio.start();
        landing.active = true; landing.phase = 'approach'; landing.t = 0; landing.kickT = 0; landing.canKick = false;
        parts.ship.visible = false; parts.cockpitGroup.visible = true; parts.hatch.rotation.set(0, 0, 0.02); parts.hatch.position.set(-L.ship.x1 + 0.7, (L.hatch.y0 + L.hatch.y1) / 2, (L.hatch.z0 + L.hatch.z1) / 2);
        S.alarm = 1; S.shake = 0.5; parts.hatchFall = 0; parts.hatchDone = false; fade(0, 10);
    }
    function startKick() {
        if (!landing.active || landing.phase !== 'seated' || landing.kickT > 0) return false;
        landing.phase = 'kick'; landing.kickT = 1e-6; landing.canKick = false; landing.kicked = false; landing.hid = false; return true;
    }
    function setPoseFromLanding(dt, cam, player) {
        const pose = [0, 0, 0, 0, 0, 0];
        landing.t += dt;
        let speed = 0;
        if (landing.phase === 'approach') {
            const k = clamp(landing.t / LAND.T_APPROACH, 0, 1), z = L.approachZ - (L.approachZ - L.bay.z1) * k;
            pose[0] = Math.sin(landing.t * 2.3) * 3; pose[1] = lerp(48, 12, ease(k)); pose[2] = z; pose[3] = Math.sin(landing.t * 1.7) * 0.03; pose[4] = lerp(-0.1, 0.02, k); pose[5] = Math.sin(landing.t * 3.1) * 0.07 * (1 - k * 0.5);
            speed = LAND.V_APPROACH; S.shake = 0.35 + k * 0.3;
            if (landing.t >= LAND.T_APPROACH) {   // through the forcefield
                landing.phase = 'skid'; landing.t = 0; screenFlash(1, '#bfeaff'); S.shake = 2.2; audio.burst({ dur: 0.9, gain: 0.8, lo: 200, hi: 7000 }); audio.thump({ f0: 140, f1: 34, dur: 0.8, gain: 0.9 }); audio.burst({ dur: 0.5, gain: 0.35, lo: 2500, hi: 9000, at: 0.05 });
            }
        }
        if (landing.phase === 'skid') {
            const s = clamp(landing.t / LAND.T_SKID, 0, 1), sk = skidState(s);
            pose[0] = 0; pose[2] = L.bay.z1 - sk.d; const vk = sk.v / LAND.v0;
            pose[1] = L.stop.y + 1.2 * Math.exp(-landing.t * 4) * Math.cos(landing.t * 18) + 0.15 * Math.sin(landing.t * 41) * vk;
            pose[3] = Math.sin(landing.t * 9.0) * 0.012 * vk + 0.015 * Math.sin(landing.t * 2.1); pose[4] = -0.05 * (1 - s) + Math.sin(landing.t * 33) * 0.008 * vk; pose[5] = Math.sin(landing.t * 12.7) * 0.02 * vk;
            speed = sk.v; S.shake = 0.25 + 1.4 * vk;
            for (let i = 0; i < Math.floor(vk * 5 + 0.3 + Math.random()); i++) { const side = (Math.random() - 0.5) * 20; emitSpark(side, 0.6 + Math.random() * 3, pose[2] - 14 - Math.random() * 30, (Math.random() - 0.5) * 24 - speed * 0.08, 8 + Math.random() * 26, (Math.random() - 0.4) * 22 + speed * 0.1, 0.5 + Math.random() * 0.8); }
            if (s >= 1) { landing.phase = 'seated'; landing.t = 0; landing.canKick = true; S.shake = 0.25; parts.ship.visible = true; audio.creak({ f: 150, dur: 2.2, gain: 0.16 }); audio.burst({ dur: 1.6, gain: 0.14, lo: 3500, hi: 9000, at: 0.2 }); audio.thump({ f0: 70, f1: 28, dur: 1.2, gain: 0.5 }); if (deps.onEvent) deps.onEvent('halt'); }
        }
        if (landing.phase === 'seated') {
            const t = landing.t;
            pose[0] = L.stop.x + Math.sin(t * 0.9) * 0.1; pose[1] = L.stop.y + Math.sin(t * 1.2) * 0.05; pose[2] = L.stop.z; pose[3] = Math.sin(t * 0.5) * 0.01; pose[4] = Math.sin(t * 0.37) * 0.015; pose[5] = Math.sin(t * 0.6) * 0.004;
            S.shake = Math.max(0.05, S.shake * Math.exp(-dt * 1.4)); if (Math.random() < dt * 0.5) { audio.creak({ f: 110 + Math.random() * 80, dur: 1.2 + Math.random(), gain: 0.07 }); S.shake += 0.25; }
            if (Math.random() < dt * 5) emitSpark(L.stop.x + (Math.random() - 0.5) * 8, 14 + Math.random() * 6, L.stop.z - 8, (Math.random() - 0.5) * 6, 2, (Math.random() - 0.5) * 6, 0.7);
        }
        if (landing.phase === 'kick') {
            landing.kickT += dt; const t = landing.kickT; kickPose(t, pose);
            if (!landing.kicked && t > 0.45) { landing.kicked = true; S.shake = 2.4; screenFlash(0.55, '#ffd9a0'); audio.thump({ f0: 160, f1: 40, dur: 0.5, gain: 0.9 }); audio.burst({ dur: 0.6, gain: 0.7, lo: 300, hi: 5000 }); audio.creak({ f: 260, dur: 0.7, gain: 0.2 }); parts.hatchFall = 0.0001; }
            if (!landing.hid && t > 0.9) { landing.hid = true; parts.cockpitGroup.visible = false; screenFlash(0.35, '#ffd9a0'); }
            if (parts.hatchFall) {
                parts.hatchFall += dt; const k = Math.min(1, parts.hatchFall / 0.55);
                parts.hatch.position.set(-L.ship.x1 - 5 * k, lerp((L.hatch.y0 + L.hatch.y1) / 2, 0.9, k * k), (L.hatch.z0 + L.hatch.z1) / 2 - 2 * k); parts.hatch.rotation.set(0, 0, 0.02 + 1.5 * k * k);
                if (k >= 1 && !parts.hatchDone) { parts.hatchDone = true; audio.thump({ f0: 90, f1: 38, dur: 0.4, gain: 0.5 }); audio.burst({ dur: 0.35, gain: 0.3, lo: 600, hi: 4500 }); }
            }
            S.shake = Math.max(0.06, S.shake * Math.exp(-dt * 2.2));
            if (t >= LAND.T_KICK) { landing.active = false; landing.phase = 'done'; parts.hatchFall = 0; S.shake = 0; if (player) { player.yaw = Math.PI; player.pitch = 0; } if (deps.onEvent) deps.onEvent('free'); }
        }
        // apply the pose; shake offsets are mine (the game's screen-shake is only read inside updatePlayer)
        const sh = S.shake, tt = S.t * 31;
        const ox = (Math.sin(tt * 1.3) + Math.sin(tt * 2.9)) * 0.22 * sh, oy = (Math.sin(tt * 1.7) + Math.cos(tt * 3.3)) * 0.22 * sh, roll = Math.sin(tt * 0.9) * 0.012 * sh;
        cam.position.set(pose[0] + ox, pose[1] + oy, pose[2]);
        if (player) { player.position.set(pose[0], pose[1], pose[2]); player.cameraY = pose[1]; }
        cam.rotation.order = 'YXZ'; cam.rotation.set(pose[4] + Math.sin(tt * 2.1) * 0.006 * sh, pose[3], pose[5] + roll);
        if (player) { player.yaw = pose[3]; player.pitch = pose[4]; }
        if (parts.cockpitGroup.visible) {
            const cg = parts.cockpitGroup; cg.position.copy(cam.position); cg.quaternion.copy(cam.quaternion);
            cg.translateX(Math.sin(tt * 3.7) * 0.03 * sh); cg.translateY(Math.cos(tt * 4.1) * 0.03 * sh);
            parts.cockpit.position.copy(cam.position); parts.cockpit.intensity = LIGHT.cockpit * (0.7 + 0.3 * Math.sin(S.t * 9));
            parts.leds.forEach((l, i) => { l.visible = ((S.t * (1.5 + i * 0.37)) % 1) < 0.7; });
        } else parts.cockpit.intensity = 0;
        return speed;
    }

    // ---- per-frame --------------------------------------------------------------------------------------------------------------------------
    // Returns true while the landing owns the camera (the game then skips its own player update).
    function update(dt, cam, player) {
        if (!S.built) return false;
        dt = Math.min(dt, 0.1); S.t += dt;
        // lightning: random strikes, each two or three quick pulses
        S.nextBolt -= dt;
        if (S.nextBolt <= 0) { S.nextBolt = 3 + Math.random() * 7; S.boltT = 0; S.seed = Math.random() * 10; S.boltAmp = 0.55 + Math.random() * 0.6; parts.storm.material.uniforms && parts.storm.material.uniforms.uFlashDir.value.set(Math.random() - 0.5 + 0.6, Math.random() * 0.7 - 0.1, Math.random() - 0.5).normalize(); audio.thunder(S.boltAmp, 0.3 + Math.random() * 1.4); }
        S.boltT += dt; const bt = S.boltT;
        S.flash = bt > 3 ? 0 : S.boltAmp * Math.max(Math.exp(-bt * 16), bt > 0.18 ? 0.8 * Math.exp(-(bt - 0.18) * 14) : 0, bt > 0.4 ? 0.6 * Math.exp(-(bt - 0.4) * 10) : 0);
        S.clear = (S.skyOverride !== undefined && S.skyOverride !== null) ? S.skyOverride : skyClear(S.t);
        const u = parts.storm.material.uniforms; if (u) {
            u.uTime.value = S.t; u.uFlash.value = S.flash; if (u.uClear) u.uClear.value = S.clear; if (u.uSeed) u.uSeed.value = S.seed || 0.3;
            // quality governor: the cloud sea is the expensive part of the sky. If frames are slow while it is on screen, march it with fewer steps
            // (never below 8); if there is plenty of headroom, creep back up (never above 22).
            if (u.uSteps) { S.dtAvg = (S.dtAvg || 0.016) * 0.97 + dt * 0.03; if (S.clear > 0.2) { if (S.dtAvg > 0.034) S.qSteps = Math.max(6, (S.qSteps || 12) - 0.2); else if (S.dtAvg < 0.021) S.qSteps = Math.min(14, (S.qSteps || 12) + 0.04); } u.uSteps.value = Math.round(S.qSteps || 12); }
        }
        parts.sun.intensity = LIGHT.storm * (0.85 + 0.15 * Math.sin(S.t * 0.7)) * (1 + 0.35 * S.clear) + LIGHT.stormFlash * S.flash;   // sunlight breaks in when the view is clear
        parts.hemi.intensity = LIGHT.hemi + 0.9 * S.flash;
        // flickers and pulses
        const fl = (Math.sin(S.t * 23) * Math.sin(S.t * 7.3) > 0.35 || Math.sin(S.t * 53) > 0.93) ? 0.15 : 1; mats.lampFlick.color.setRGB(1.6 * fl, 1.0 * fl, 0.55 * fl);
        const pul = 0.5 + 0.5 * Math.sin(S.t * 3.4); mats.redPulse.color.setRGB(0.4 + 1.9 * pul, 0.04, 0.02);
        parts.alarmA.intensity = LIGHT.alarm * S.alarm * (0.25 + 0.75 * Math.max(0, Math.sin(S.t * 3.4))); parts.alarmB.intensity = LIGHT.alarm * S.alarm * (0.25 + 0.75 * Math.max(0, Math.sin(S.t * 3.4 + 2.2)));
        parts.fire.intensity = LIGHT.fire * (0.7 + 0.3 * Math.sin(S.t * 13) * Math.sin(S.t * 5.1)); parts.fire.position.x = Math.sin(S.t * 1.7) * 6;
        parts.corA.intensity = LIGHT.corridor * (0.8 + 0.2 * Math.sin(S.t * 2.2)); parts.corB.intensity = LIGHT.corridor * (0.5 + 0.5 * (Math.sin(S.t * 31) > -0.7 ? 1 : 0.2));
        for (const m of parts.field) m.material.opacity = 0.35, m.visible = Math.sin(S.t * 14 + m.userData.phase) > -0.25;
        mats.field.opacity = (0.18 + 0.22 * Math.abs(Math.sin(S.t * 6.5))) * (landing.active && landing.phase !== 'seated' && landing.phase !== 'kick' ? 1.4 : 1);
        // overlay flash decay
        if (flashEl) { flashLevel = Math.max(0, flashLevel - dt * 2.6); flashEl.style.opacity = String(Math.min(1, flashLevel)); }
        parts.storm.position.copy(cam.position);
        // sound beds (one call per frame)
        let ctl = false, scrapeG = 0, scrapeHz = 0;
        if (landing.active) {
            const speed = setPoseFromLanding(dt, cam, player); ctl = true;
            const vk = clamp(speed / 170, 0, 1.3);
            if (landing.phase === 'skid') { scrapeG = 0.5 * vk; scrapeHz = 260 + 900 * vk; }
        } else if (S.alarm > 0.3) S.alarm = Math.max(0.3, S.alarm - dt * 0.05);
        audio.levels({ ambient: landing.active && landing.phase === 'skid' ? 0.04 : S.ambient, alarm: S.alarm * (landing.active ? 0.16 : 0.07), scrape: scrapeG, scrapeHz });
        updateParticles(dt, cam.position);
        // zones
        if (player && !landing.active && deps.onEvent) {
            const px = player.position.x, pz = player.position.z, z = S.zones;
            if (!z.windows && px > 60) { z.windows = 1; deps.onEvent('zone:windows'); }
            if (!z.tech && px < -85 && pz > -260 && pz < 60) { z.tech = 1; deps.onEvent('zone:tech'); }
            if (!z.corridor && px < L.cor.x1 - 20) { z.corridor = 1; deps.onEvent('zone:corridor'); }
            if (!z.door && px < L.doorX + 90) { z.door = 1; deps.onEvent('zone:door'); }
            if (!z.beyond && px < L.doorX - 70) { z.beyond = 1; deps.onEvent('zone:beyond'); }   // only reachable once the door is open
        }
        return ctl;
    }

    // What the player can interact with right now, or null.
    function interaction(px, pz) {
        if (landing.active) return landing.canKick ? { label: 'Kick the hatch open', btn: 'Kick', id: 'kick' } : null;
        return null;
    }
    function begin(o) {   // enter without the landing (resume): build, start the sound, show the wreck
        S.zones = {}; build(); mountOverlay(); audio.start(); fade(0, 10); parts.ship.visible = true; parts.cockpitGroup.visible = false; parts.cockpit.intensity = 0;
        landing.active = false; landing.phase = 'done'; S.alarm = 0.3; return true;
    }
    function leave() { audio.stop(); fade(0, 10); landing.active = false; if (flashEl) flashEl.style.opacity = '0'; flashLevel = 0; }
    function setAmbient(v) { S.ambient = v; }
    function setAlarm(v) { S.alarm = v; }
    function dispose() { audio.stop(); if (overlay && overlay.parentNode) overlay.parentNode.removeChild(overlay); overlay = flashEl = fadeEl = null; }

    return {
        scene, build, begin, leave, resolve, update, interaction, startLanding, startKick, fade, screenFlash, setAmbient, setAlarm, dispose, emitSpark, skyClear, setSky(v) { S.skyOverride = v; },
        get landing() { return landing; }, get built() { return S.built; }, parts, mats, state: S,
        layout: LAYOUT, walk, obst, audio, skidState, kickPose, LAND
    };
}
