# v67 - dead code removed (rivers, lakes, unused helpers)
Behaviour is unchanged. Checked by hashing the output of the chunk builder before and after (terrain at 3 detail levels with edge stitching, scatter at 2 tiers,
two cities, the Citadel and the site list, on seeds 424242 and 1): 158 outputs, 0 differences. test_chunks, test_v59, test_sites, test_citadel, _site, _walk, _chunks, _runtime pass.
Not run in a browser.
- **Rivers removed** (they were switched off in v43 and never came back). Deleted `river_core.js`, `river_carve.js`, `river_worker.js`. Removed from `game.js`: the whole RIVERS manager
  (tracing queue, worker pool, carve, delta/confluence logic, spatial hash, chunk export, dirty-chunk rebuilds), the river water material and shader, the river mesh in terrain chunks, and the player's
  river swim / current code. `getEnvironmentAt` no longer takes a river mode (the `-1` "height only" call still works) and no longer returns `riverTn`.
  Removed from `chunk_core.js`: river carve, bank/bed colouring, delta mud, river ribbon builder, scatter exclusion near rivers. Chunk jobs no longer carry river arrays.
- The seeded PRNG and simplex noise that `chunk_core.js` borrowed from `river_core.js` now live in `noise_core.js`.
- **Lakes removed** (`terrain_core.js`): `LAKES_ENABLED`, `LAKE_T`, `POND_T` and the lake / pond block. Also the river-era `macroHeight3` and the lon/lat map wrappers (`sample`, `macroHeight`, `wetness`, `isHostile`, `_mapP`).
- **Unused helpers removed** from `game.js`: planet-wrap imports (`wrapX`, `wrapD`, `polarness`, `sunEUN`, `chartToMap`...), `eunToWorld`, `continentnessLand`, `softCap`, `hashRandom`, `easeOutQuint`, `biomeClassOf`, `ckOf`, `_mapTmp`, `MAX_MOUNTAIN_HEIGHT`, `icePalette`.
- Left in on purpose: `ensureLightningRig` / `buildLightningBoltPoints` (an unfinished lightning feature, not dead code), and the old tests in `tests/`.
- Net: about 600 lines of code and 3 files removed.
