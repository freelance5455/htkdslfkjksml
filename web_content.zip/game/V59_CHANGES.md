# v59 - STEP 1: TECTONIC FOUNDATIONS & ARCHIPELAGOS (terrain_core.js only)
NOT run in a browser/GPU. Verified headless in Node (tests/test_v59.mjs, plus the older test_sites / test_chunks / test_shape, all passing) and by rendering height maps (tests/map_dump.mjs, map_crop.mjs, map_png.py).

## What changed
- **Plate-driven landmasses.** Every plate now has a crust level: continental plates high (thick crust highest), micro-continents low (big islands and shelves), oceanic plates deep. Levels are blended with a soft Voronoi weight, so they are continuous at triple junctions. Organic noise then floods parts of continental plates (gulfs, seas, ragged coasts) and lifts parts of oceanic ones.
- **Dispersed continents.** ~70% of the continental plates are picked so they do not touch (a few neighbours are allowed, so collisions still happen). Result: several separate continents with real ocean basins, not one supercontinent.
- **Boundary uplift.** Collisions and subduction margins thicken the crust (long, thick ranges); the confetti "scattered island-chain mask" is removed.
- **Hierarchical archipelagos.** Island systems come from tectonic lines only (arcs, rift chains, thick-crust patches, continental fringes). Along each line three noise scales are thresholded against the line's strength: a few large MAIN islands (with their own relief), SATELLITES that only occur near mains and taper off along the line, and a few ISLETS/reefs. Between systems: open ocean.
- **Boundary-specific shapes.**
  - Ocean/ocean convergence: island arc on the overriding plate that bows away from the trench toward both ends (curved), with a deeper outer trench.
  - Continent collisions: long thick range along the boundary (crust thickening + extra relief).
  - Spreading ridges: ~55% surface as a straight island chain along the axis; islands get smaller/lower with distance along the chain (age gradient).
  - Hotspots: straight chains, young end big and tall, each older volcano smaller and lower (0.8x per step), then drowned (shallow swell/reef shelf around each). Outlines are noise-warped, not discs. Chains are fewer (density 0.30 -> 0.14) and 9 volcanoes long.
- Inland mountain belts are weighted toward plate boundaries (still some elsewhere).

## New fields on the terrain sample (for later steps): `isle`, `sysT` (1 arc, 2 rift chain, 3 fringe), `hotAge`, `riftAge`, `arcCurve`, `collAmt`, `crustCv`, `contW`.
## Tuning knobs (top of terrain_core.js): CONT_FRAC, CRUST_SW, ARC_L, ISLE_AMP, NOISE_CONT, LAND_BIAS, HOTSPOT_DENSITY, HOT_K / HOT_DX.

## Measured (3-4 seeds, 1-degree grid)
- Land 27-31% (v58: 28%). Largest landmass 19-39% of all land (v58: 5%; the first plate-driven draft was 60-88%). Big landmasses 11-19 per world, ~210-320 landmasses incl. islets (v58: 865 tiny blobs).
- Land height p50/p90/p99 ~ 640-800 / 1600-2300 / 2900-5100 (v58: 356 / 1363 / 3693). Medians are higher because continental crust is now thicker; Step 2 sets the real height scaling and the ~2.4 km relief cap.
- Cliffs (>3 per unit at 22-unit steps): 6.4-7.9% vs 9.7% for v58 under the same measurement (no new discontinuities). 0 NaN. Spawn-suitable temperate lowland exists on all 6 seeds tried (~1.1-1.4% of the globe).

## Known / left for later steps
- Mountains are still the old noise ridges on top of the new uplift: real boundary ridges with crest/spurs/rain shadow = Step 2. Rock/biome/coast character per region = Step 3. Seafloor squiggles and biome blending = Step 4.
- Seeds produce different worlds than v58 (land is rebuilt); saved games will see different ground.

## v59b - number tuning (feedback: ranges not chain-like, wants denser world with realistic confetti islands)
- Denser islands: HOTSPOT_DENSITY 0.14 -> 0.26; continental-fringe / thick-crust strength 0.52 -> 0.60 (amp 800 -> 1000); oceanic crust -0.62..-0.32 -> -0.58..-0.24; satellite / islet thresholds lowered (more satellites and islets near every main island).
- Chain-like mountains: inland belts now follow plate boundaries much more (boundary weight floor 0.35 -> 0.12, boundary zones wider 70k/60k -> 90k/80k, belts start at lower continentalness); collision range height 3000 -> 3500.
- LAND_BIAS 0 -> 0.14 to keep land near a third. Measured (4 seeds): land 33-36%, ~390-480 landmasses (20-36 big), largest 21-40% of land, open ocean >9 deg from land only ~5-10% of the map; cliff share ~11% (v58: 9.7%).
