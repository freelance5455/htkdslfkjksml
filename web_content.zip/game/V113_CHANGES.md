# v113 - THE LEVIATHAN, the view outside (on top of your v112 console build)

Your v112 (console, hack, break, green lights, door, the sky cycle) is untouched except where listed. This version only rebuilds what you see through the windows and the breach.

## The sky shader moved to its own file: `leviathan_sky.js`
`leviathan_core.js` now imports `STORM_VS` / `STORM_FS` from it. It can be compiled and rendered **on its own**: `python3 tests/sky_render.py [outdir] [view names]` loads it in headless Chromium (software WebGL2, no three.js), prints any GLSL error, and writes PNGs of nine views. The shader compiled and linked on the first run here, and every picture in `Leviathan_sky_previews.png` is a real render of it. (Earlier in this project I said I could not see anything without a GPU; software WebGL turned out to work, so from here on the sky is verified by eye. The rest of the interior still is not.)

## What it looks like now
- **Inside the storm (about 23 s of every 100):** dark, billowing cloud in six lit layers with real depth, glowing orange from the depths below, hard-lit rims, a slow churning flow. Lightning lights the cloud from inside and draws a jagged, forked bolt (a new random shape and place every strike).
- **Glimpses of the moon:** every ~57 s the cloud thins in the moon's direction and the Earth-like moon shows through the rift, then closes again.
- **Rising / sinking:** the storm thins as the Leviathan lifts out, rather than cross-fading two pictures.
- **Above the clouds (about 55 s):** a cloud sea raymarched as a height field (towering cumulonimbus, creased billows, soft sunlit cream and lavender shade, self-shadowing toward the low sun, a slow cyclone, glowing gaps in the deck, haze), under a dusk sky that goes amber at the horizon to violet to near-black indigo, with cirrus, a towering cloud bank on the horizon, drifting puffs, stars and a hard sun with glare.
- **The moon** is now a proper Earth: warped continents, shallow and deep ocean, ice caps, a slowly moving cloud layer, a sun glint on the sea, a lit blue atmosphere rim with an orange terminator, and a faint halo. It slowly spins. Clouds drift across it, so you only ever see it in pieces.

## Performance (you reported very slow frame rates earlier, so this matters)
- The sky sphere is now drawn **after** the walls with the depth test on, so only pixels actually seen through windows and the breach are shaded. Before, the whole screen paid for the sky every frame, even where a wall covered it.
- A **quality governor** lowers the cloud-sea march (22 steps down to 8) while the sky is clear and frames take longer than about 34 ms, and raises it again when there is headroom (`leviathanDebug` can still force `sky(1)` / `sky(0)` / `sky(null)`).
- Not measured: I can render the shader here but cannot time it on a real GPU. If the clear phase stutters, tell me the device and I will cheapen it further (fewer layers, lower octave counts).

## Not verified
Inside the real game (three.js, the composer, bloom): the depth-tested sphere relies on the sky always being farther than any wall in the logarithmic depth buffer, which it is by construction, but I have not seen it run. The preview PNGs use a simple tone curve, not the game's.

## Tests
`test_v111_leviathan` (15), `test_v112_hack` (27, shader checks updated to the new uniforms and functions), `test_v112_glue` (18) all pass. `tests/sky_render.py` is the compile-and-look check for the sky.
