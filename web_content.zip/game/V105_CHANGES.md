# v105 - the dream's soundtrack, rebuilt (dream_cinematic.js, audio section only)

- Three rooms instead of one reverb (kitchen/cabin, hall/corridor, dark water/light); each scene opens its own, plus a dark ping-pong echo for bells and music.
- The mix now follows the picture: a blur or closing eyelid muffles everything (focus pulls you can hear), the water takes the highs, the music is ducked in the dark and stops dead at the third blow.
- Voices: rounder glottal source, five formants, consonant bursts, pitch drift. The hearing's watchers stand in a ring around you (HRTF); the listener turns with the camera. The lit door's hum recedes down the corridor in 3D.
- Scored music, all synthesised: strings per scene (C home -> D green -> clusters in the hall -> open fifths in the drift -> resolved water), a bowed cello carrying the music-box tune, a choir at the sun bloom / the ring / the light. The music box now has real tine partials (the missing 6-16 kHz air).
- New ambience: kitchen clock/fridge/simmer/dishes/birds through glass; dawn chorus, grass, insects; paper in the archive; whispers; cabin fan, creaks, plunge roar and rattle; bubbles, a distant whale; designed cut sounds (glass shards, digital tear, plunge crash).
- Footsteps: heel + toe, per-surface texture. Noise sources are now stopped when finished (before, every click left a looping noise node running to the end).
- Tests: dream_audio_check.py now renders stereo 44.1 kHz steered by the real timeline; dream_audio_analyze.py measures levels/bands/stereo.
Not verified: by ear, on a phone, or the whole 3:26 render (only 0-30 s rendered: peak -4.5 dB, no clipping). The three convolvers cost more CPU than the old one; if a phone struggles, shorten irB/irC in audioAssets.
- v105b: master cut about 9 dB (out gain 0.7->0.32, master 0.7->0.6, limiter -8->-14 dB, reverb return 0.9->0.6) after reports of clipping; long reverbs shortened (3.2 s / 2.6 s) to ease CPU.
