HOW TO ADD BACKGROUND MUSIC
============================
1. Drop your audio files (mp3, ogg, wav, etc.) into this "music" folder.
2. Open playlist.json and list their filenames as a JSON array, e.g.:

   [
     "drift-one.mp3",
     "hollow-wind.mp3",
     "night-theme.ogg"
   ]

That's it. As soon as you spawn into the world, a random track from that list
starts playing at 50% volume. Each track plays all the way to its natural
end (nothing fades it out early), then there's exactly one minute of silence,
then another random track starts. And so on for the whole session.

If playlist.json is empty (or missing), no music plays - the rest of the
game works fine either way.
