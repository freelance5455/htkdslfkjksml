// =====================================================================================
// chunk_core.js - everything expensive about building one terrain chunk, as pure maths (no three.js, no DOM).
// Runs inside terrain_worker.js (a pool of them), so the main thread only ever uploads finished typed arrays.
//
// WHY IT IS FAST
//   * The tectonic/climate terrain function costs ~55 us per call. The old code called it for every one of the
//     103,000 vertices of a nearby chunk, then 3x more for every one of 102,000 tree/grass scatter points - on the
//     main thread, ~20 s per chunk. Now the smooth part of the terrain (everything except the 3-octave micro relief,
//     which is cheap) is evaluated on a coarse 43.75-unit lattice (7k nodes) and bicubically interpolated; the
//     micro relief, colours and scatter run per vertex at ~1-2 us each.  Mean interpolation error is
//     ~0.1 world units (worst case ~12 on a razor crest).
//   * Coarse "preview" tiers (<= 80 segments) skip the lattice and sample the vertices exactly, so a chunk appears
//     within a few milliseconds and is refined afterwards.
//   * Because it all happens in workers, any number of chunks build in parallel and nothing ever blocks a frame.
// =====================================================================================
import { TerrainCore, BIOMES, BIOME_BY_NAME, MAX_MOUNTAIN_HEIGHT } from './terrain_core.js';
import { PLANET_C, PLANET_R, CHART_HALF, chartToGeo, geoToChart } from './planet_core.js';
import { SimplexNoise, mulberry32 } from './noise_core.js';
import { ValleyField, localToDir } from './valley_sites.js';
import { generateCity, planToInstances, planToLife, planToCols, planToRoad, makeNatGrid } from './city_core.js';
import { generateCitadel } from './citadel_core.js';
import { buildRoad } from './city_roads.js';

export const CHUNK_SIZE = 3500;
const HALF = CHUNK_SIZE / 2;
const WATER_LEVEL = 0;
const LS = CHUNK_SIZE / 80;            // lattice spacing (43.75)
const LM = 2;                           // lattice margin nodes on every side
const NL = 80 + 1 + 2 * LM;             // 85 nodes per side
const SCATTER_STEP = CHUNK_SIZE / 320;
const NO_SLOPE_DARK = BIOMES.map(b => /DUNES|BADLANDS|SPIRES|MESA|SALT|KARST|ICE SHEET|GLACIER|ASH PLAINS/.test(b.name));

const s2l = (c) => c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
const hexLin = (hex) => [s2l(((hex >> 16) & 255) / 255), s2l(((hex >> 8) & 255) / 255), s2l((hex & 255) / 255)];
const SLOPE_ROCK = hexLin(0x3b3a38);
const ss = (a, b, x) => { const t = Math.max(0, Math.min(1, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
function softCap(x, cap, kf = 0.9) { const knee = cap * kf; if (x <= knee) return x; const r = cap - knee; return knee + r * (1 - Math.exp(-(x - knee) / r)); }
const cr = (p0, p1, p2, p3, t) => p1 + 0.5 * t * (p2 - p0 + t * (2 * p0 - 5 * p1 + 4 * p2 - p3 + t * (3 * (p1 - p2) + p3 - p0)));

// ---- tiny quaternion / matrix helpers (replace THREE.Object3D for scatter instance matrices) ----
function composeM(o, i, px, py, pz, x, y, z, w, sx, sy, sz) {
    const x2 = x + x, y2 = y + y, z2 = z + z, xx = x * x2, xy = x * y2, xz = x * z2, yy = y * y2, yz = y * z2, zz = z * z2, wx = w * x2, wy = w * y2, wz = w * z2;
    o.push((1 - (yy + zz)) * sx, (xy + wz) * sx, (xz - wy) * sx, 0, (xy - wz) * sy, (1 - (xx + zz)) * sy, (yz + wx) * sy, 0,
           (xz + wy) * sz, (yz - wx) * sz, (1 - (xx + yy)) * sz, 0, px, py, pz, 1);
}

export class ChunkBuilder {
    constructor(seed, sites) {
        this.seed = seed >>> 0;
        this.sites = sites || []; this.valleys = new ValleyField(this.sites); this._vl = null;   // v45: hidden valley city-states (valley_sites.js)
        this.T = new TerrainCore(this.seed);
        this.simplex = new SimplexNoise(mulberry32(this.seed));
        this.lattices = new Map();      // chunk key -> lattice (LRU)
        this.face = 0; this._g = [0, 0, 0];   // current cube-sphere chart; (x,z) everywhere in this class are CHART coords
        this._o = {}; this._o2 = {};
        this._r = { hs: 0, rough: 0, r: 0, g: 0, b: 0, id: 0, prop: 0, swamp: 0 };
        this._ra = { hs: 0, rough: 0, r: 0, g: 0, b: 0, id: 0, prop: 0, swamp: 0 };
        this._rb = { hs: 0, rough: 0, r: 0, g: 0, b: 0, id: 0, prop: 0, swamp: 0 };
    }
    hashRandom(x, z, salt) {
        // v44: integer avalanche hash (the old fract(sin()) version was ~16% of all worker time). Deterministic across workers.
        let a = Math.imul((x * 64) | 0, 0x27d4eb2d) ^ Math.imul((z * 64) | 0, 0x165667b1) ^ Math.imul((salt | 0) + 1, 0x9e3779b1) ^ (this.seed | 0);
        a = Math.imul(a ^ (a >>> 15), 0x85ebca6b); a = Math.imul(a ^ (a >>> 13), 0xc2b2ae35); a ^= a >>> 16;
        return (a >>> 0) / 4294967296;
    }

    // Jobs carry the chart (cube face) they were cut from. Lattices are keyed by chunk index only, so drop them when the face changes.
    _setFace(f) { f = f | 0; if (f !== this.face) { this.face = f; this.lattices.clear(); } }

    // ---- one exact (non-interpolated) terrain evaluation. v34: the generator is a true 3D sphere function, so a chart point is just
    // turned into its point on the sphere (no lon/lat map, no antimeridian seam cross-fade). ----
    _node(x, z) {
        const g = this._g; chartToGeo(this.face, x, z, g);
        const X = g[0] * PLANET_R, Y = g[1] * PLANET_R, Z = g[2] * PLANET_R, T = this.T, o = this._o, R = this._r;
        T.sampleSmooth3(X, Y, Z, o);
        R.hs = o.hs; R.rough = o.rough;
        const finalH = softCap(o.hs + T.microAt3(X, Y, Z, o.rough), MAX_MOUNTAIN_HEIGHT);
        T.classify3(X, Y, Z, finalH, o);
        R.r = s2l(o.rgb[0]); R.g = s2l(o.rgb[1]); R.b = s2l(o.rgb[2]);
        R.id = o.biomeId; R.prop = o.prop; R.swamp = o.swamp;
        return R;
    }
    // micro relief at a chart point
    _micro(x, z, rough) {
        const g = this._g; chartToGeo(this.face, x, z, g);
        return this.T.microAt3(g[0] * PLANET_R, g[1] * PLANET_R, g[2] * PLANET_R, rough);
    }
    // exact final (pre-river) height
    exactHeight(x, z) { const R = this._node(x, z); let h = softCap(R.hs + this._micro(x, z, R.rough), MAX_MOUNTAIN_HEIGHT); if (this._vl && this._vl.length) h = this.valleys.apply(this._vl, x, z, h); return h; }

    // ---- lattice ----
    getLattice(key, gx, gz) {
        let L = this.lattices.get(key);
        if (L) { this.lattices.delete(key); this.lattices.set(key, L); return L; }
        const n = NL * NL;
        L = { x0: gx * CHUNK_SIZE - HALF - LM * LS, z0: gz * CHUNK_SIZE - HALF - LM * LS,
              hs: new Float32Array(n), rough: new Float32Array(n), rgb: new Float32Array(n * 3),
              cls: new Uint8Array(n), prop: new Uint8Array(n), bid: new Uint8Array(n), swamp: new Float32Array(n) };
        for (let j = 0; j < NL; j++) for (let i = 0; i < NL; i++) {
            const R = this._node(L.x0 + i * LS, L.z0 + j * LS), k = j * NL + i;
            L.hs[k] = R.hs; L.rough[k] = R.rough; L.rgb[k * 3] = R.r; L.rgb[k * 3 + 1] = R.g; L.rgb[k * 3 + 2] = R.b;
            L.bid[k] = R.id; L.cls[k] = BIOMES[R.id].cls; L.prop[k] = R.prop; L.swamp[k] = R.swamp;
        }
        this.lattices.set(key, L);
        if (this.lattices.size > 40) this.lattices.delete(this.lattices.keys().next().value);
        return L;
    }
    // bicubic smooth height from a lattice (x,z are unwrapped world coords consistent with the lattice origin); NaN when outside
    latH(L, x, z) {
        const fx = (x - L.x0) / LS, fz = (z - L.z0) / LS;
        if (fx < 1 || fz < 1 || fx >= NL - 2 || fz >= NL - 2) return NaN;
        const ix = Math.floor(fx), iz = Math.floor(fz), tx = fx - ix, tz = fz - iz, H = L.hs;
        let r0, r1, r2, r3, o;
        o = (iz - 1) * NL + ix; r0 = cr(H[o - 1], H[o], H[o + 1], H[o + 2], tx);
        o += NL; r1 = cr(H[o - 1], H[o], H[o + 1], H[o + 2], tx);
        o += NL; r2 = cr(H[o - 1], H[o], H[o + 1], H[o + 2], tx);
        o += NL; r3 = cr(H[o - 1], H[o], H[o + 1], H[o + 2], tx);
        return cr(r0, r1, r2, r3, tz);
    }
    latRough(L, x, z) {
        const fx = (x - L.x0) / LS, fz = (z - L.z0) / LS, ix = Math.floor(fx), iz = Math.floor(fz), tx = fx - ix, tz = fz - iz, o = iz * NL + ix, H = L.rough;
        return (H[o] * (1 - tx) + H[o + 1] * tx) * (1 - tz) + (H[o + NL] * (1 - tx) + H[o + NL + 1] * tx) * tz;
    }
    // final (pre-river) height from the lattice
    latFinal(L, x, z) {
        const hs = this.latH(L, x, z);
        if (hs !== hs) return this.exactHeight(x, z);
        let h = softCap(hs + this._micro(x, z, this.latRough(L, x, z)), MAX_MOUNTAIN_HEIGHT);
        if (this._vl && this._vl.length) h = this.valleys.apply(this._vl, x, z, h);
        return h;
    }

    // ================================================================= TERRAIN TIER =================================================================
    // job: { key, gx, gz, S, edge:[back,front,left,right] (neighbour segment counts, 0 = none), }
    buildTerrain(job) {
        const t0 = performance.now(); this._setFace(job.face);
        const S = job.S, V1 = S + 1, V = V1 * V1, vs = CHUNK_SIZE / S;
        const offX = job.gx * CHUNK_SIZE, offZ = job.gz * CHUNK_SIZE;
        const vl = this._vl = this.valleys.near(this.face, offX - HALF - 40, offX + HALF + 40, offZ - HALF - 40, offZ + HALF + 40), VF = this.valleys;
        const useLat = S >= 160;
        const L = useLat ? this.getLattice(job.key, job.gx, job.gz) : null;
        const T = this.T;
        const height = new Float32Array(V), col = new Float32Array(V * 3), cls = new Uint8Array(V), swamp = new Float32Array(V), bid = new Uint8Array(V);
        const clsW = useLat ? new Float32Array(V * 8) : null;

        const evalVertex = (ix, iz, store) => {
            const x = offX - HALF + ix * vs, z = offZ - HALF + iz * vs, i = iz * V1 + ix;
            let h, r, g, b, id, swp, wcls = null;
            if (useLat) {
                const fx = (x - L.x0) / LS, fz = (z - L.z0) / LS;
                const hs = this.latH(L, x, z);
                h = softCap(hs + this._micro(x, z, this.latRough(L, x, z)), MAX_MOUNTAIN_HEIGHT);
                const jx = Math.floor(fx), jz = Math.floor(fz), tx = fx - jx, tz = fz - jz, o = jz * NL + jx;
                const w00 = (1 - tx) * (1 - tz), w10 = tx * (1 - tz), w01 = (1 - tx) * tz, w11 = tx * tz;
                const c = L.rgb;
                r = c[o * 3] * w00 + c[(o + 1) * 3] * w10 + c[(o + NL) * 3] * w01 + c[(o + NL + 1) * 3] * w11;
                g = c[o * 3 + 1] * w00 + c[(o + 1) * 3 + 1] * w10 + c[(o + NL) * 3 + 1] * w01 + c[(o + NL + 1) * 3 + 1] * w11;
                b = c[o * 3 + 2] * w00 + c[(o + 1) * 3 + 2] * w10 + c[(o + NL) * 3 + 2] * w01 + c[(o + NL + 1) * 3 + 2] * w11;
                swp = L.swamp[o] * w00 + L.swamp[o + 1] * w10 + L.swamp[o + NL] * w01 + L.swamp[o + NL + 1] * w11;
                id = L.bid[(tx > 0.5 ? o + 1 : o) + (tz > 0.5 ? NL : 0)];
                if (store) { const cw = clsW, q = i * 8; cw.fill(0, q, q + 8); cw[q + L.cls[o]] += w00; cw[q + L.cls[o + 1]] += w10; cw[q + L.cls[o + NL]] += w01; cw[q + L.cls[o + NL + 1]] += w11; }
            } else {
                const R = this._node(x, z);
                h = softCap(R.hs + this._micro(x, z, R.rough), MAX_MOUNTAIN_HEIGHT);
                r = R.r; g = R.g; b = R.b; id = R.id; swp = R.swamp;
            }
            if (vl.length) {   // v45 valley city-state: shaped floor / walls / pass, paved tint inside the city footprint
                h = VF.apply(vl, x, z, h);
                const cw = VF.cityAt(vl, x, z);
                if (cw > 0) { const k = cw * 0.4; r += (0.30 - r) * k; g += (0.28 - g) * k; b += (0.25 - b) * k; }
                const ew = VF.enchantAt(vl, x, z); if (ew > 0) { const k = ew * 0.5; r += (0.16 - r) * k; g += (0.56 - g) * k; b += (0.34 - b) * k; }   // v56: the Citadel's enchanted valley is lush green-teal   // v53: lighter tint (the city covers slopes now; the buildings carry the look)
            }
            const cls0 = BIOMES[id].cls;
            height[i] = h; col[i * 3] = r; col[i * 3 + 1] = g; col[i * 3 + 2] = b; cls[i] = cls0; swamp[i] = swp; bid[i] = id < 0 ? 255 : id;
            if (store && !useLat) { /* one-hot handled later */ }
        };

        for (let iz = 0; iz < V1; iz++) for (let ix = 0; ix < V1; ix++) evalVertex(ix, iz, true);

        // ---- border stitching: the finer side of a border snaps onto the coarser neighbour's edge (see game.js history) ----
        const stitch = (nSegs, idx) => {
            if (!nSegs || nSegs >= S) return;
            const ratio = S / nSegs;
            for (let k = 0; k <= S; k += ratio) { // shared vertices: re-sample exactly as the coarser neighbour does
                const p = idx(k), ix = p % V1, iz = (p / V1) | 0;
                evalVertex(ix, iz, true);
            }
            for (let k = 0; k <= S; k++) {
                if (k % ratio === 0) continue;
                const kLow = Math.floor(k / ratio) * ratio, kHigh = Math.min(S, kLow + ratio), t = (k - kLow) / (kHigh - kLow);
                const a = idx(k), lo = idx(kLow), hi = idx(kHigh);
                height[a] = height[lo] + (height[hi] - height[lo]) * t;
                for (let c = 0; c < 3; c++) col[a * 3 + c] = col[lo * 3 + c] + (col[hi * 3 + c] - col[lo * 3 + c]) * t;
                if (useLat) for (let c = 0; c < 8; c++) clsW[a * 8 + c] = clsW[lo * 8 + c] + (clsW[hi * 8 + c] - clsW[lo * 8 + c]) * t;
            }
        };
        const e = job.edge || [0, 0, 0, 0];
        stitch(e[0], k => k);
        stitch(e[1], k => V1 * (V1 - 1) + k);
        stitch(e[2], k => k * V1);
        stitch(e[3], k => k * V1 + (V1 - 1));

        // ---- normals from the (stitched) height grid ----
        const nrm = new Float32Array(V * 3);
        for (let iz = 0; iz < V1; iz++) for (let ix = 0; ix < V1; ix++) {
            const i = iz * V1 + ix, xl = ix > 0 ? i - 1 : i, xr = ix < S ? i + 1 : i, zl = iz > 0 ? i - V1 : i, zr = iz < S ? i + V1 : i;
            const dx = (height[xr] - height[xl]) / ((xr - xl || 1) * vs), dz = (height[zr] - height[zl]) / (((zr - zl) / V1 || 1) * vs);
            const il = 1 / Math.sqrt(dx * dx + 1 + dz * dz);
            nrm[i * 3] = -dx * il; nrm[i * 3 + 1] = il; nrm[i * 3 + 2] = -dz * il;
        }

        // ---- final colours (slope darkening + fine dither) and biome weights ----
        const bwA = new Float32Array(V * 3), bwB = new Float32Array(V * 3), bwC = new Float32Array(V * 2), bwD = swamp;
        for (let iz = 0; iz < V1; iz++) for (let ix = 0; ix < V1; ix++) {
            const i = iz * V1 + ix;
            let r = col[i * 3], g = col[i * 3 + 1], b = col[i * 3 + 2];
            const h = height[i], id = bid[i];
            if (h > WATER_LEVEL + 30 && !(id !== 255 && NO_SLOPE_DARK[id])) {
                const steep = Math.max(0, Math.min(1, (1.0 - nrm[i * 3 + 1] - 0.25) * 4.0));
                if (steep > 0) { r += (SLOPE_ROCK[0] - r) * steep; g += (SLOPE_ROCK[1] - g) * steep; b += (SLOPE_ROCK[2] - b) * steep; }
            }
            const x = offX - HALF + ix * vs, z = offZ - HALF + iz * vs;
            const d = 1 + this.simplex.noise2D(x * 0.5, z * 0.5) * 0.035;
            col[i * 3] = r * d; col[i * 3 + 1] = g * d; col[i * 3 + 2] = b * d;
            if (useLat) {
                const q = i * 8;
                bwA[i * 3] = clsW[q]; bwA[i * 3 + 1] = clsW[q + 1]; bwA[i * 3 + 2] = clsW[q + 2];
                bwB[i * 3] = clsW[q + 3]; bwB[i * 3 + 1] = clsW[q + 4]; bwB[i * 3 + 2] = clsW[q + 5];
                bwC[i * 2] = clsW[q + 6]; bwC[i * 2 + 1] = clsW[q + 7];
            } else {
                const c = cls[i];
                if (c < 3) bwA[i * 3 + c] = 1; else if (c < 6) bwB[i * 3 + c - 3] = 1; else bwC[i * 2 + c - 6] = 1;
            }
        }

        const out = { key: job.key, S, height, normal: nrm, color: col, bwA, bwB, bwC, bwD, ms: 0 };
        const tr = [height.buffer, nrm.buffer, col.buffer, bwA.buffer, bwB.buffer, bwC.buffer];
        out.ms = performance.now() - t0;
        return { out, tr };
    }

    // ================================================================= SCATTER (trees, rocks, grass...) =================================================================
    // job: { key, gx, gz, lod (0 = full grid + grass, 1 = every 4th point) }
    buildScatter(job) {
        const t0 = performance.now(); this._setFace(job.face);
        const offX = job.gx * CHUNK_SIZE, offZ = job.gz * CHUNK_SIZE, lod = job.lod;
        const vl = this._vl = this.valleys.near(this.face, offX - HALF - 40, offX + HALF + 40, offZ - HALF - 40, offZ + HALF + 40), VF = this.valleys;
        const L = this.getLattice(job.key, job.gx, job.gz);
        const cats = ['dec', 'pine', 'mush', 'cactus', 'kelp', 'rock', 'crystal', 'ice', 'acacia', 'jungle', 'vent', 'boulder', 'flower', 'shrub', 'piezo', 'silicon', 'fluorite', 'grassLush', 'grassDry', 'grassForest', 'lushShrub', 'swampTree', 'swampLog', 'reed', 'swampGrass'];
        const D = {}; for (const c of cats) D[c] = [];
        const steps = Math.round(CHUNK_SIZE / SCATTER_STEP);
        const simplex = this.simplex, hr = (x, z, s) => this.hashRandom(x, z, s);

        const heightAt = (x, z) => this.latFinal(L, x, z);
        const mat = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
        // FACE-INDEPENDENT SCATTER (v38): every candidate point belongs to ONE lattice - the lattice of the cube face (chart) that
        // contains it (its "home" chart; spacing SCATTER_STEP, nodes at integer multiples). All random numbers are hashed from the
        // HOME face + home lattice index, never from the chart the player happens to stand on, so a tree has the same position, size
        // and kind whichever chart is current (no re-roll on a face crossing), and its destroyed-prop key is the same on both sides.
        // Nodes of this chart that lie beyond its edge are skipped here and supplied by the neighbouring face's lattice instead.
        const nodes = [];   // flat: x, z (this chart), home x, home z (home chart), home face
        {
            const F = this.face, CH = CHART_HALF, minX = offX - HALF, minZ = offZ - HALF, maxX = minX + CHUNK_SIZE, maxZ = minZ + CHUNK_SIZE;
            const inside = minX >= -CH && maxX <= CH && minZ >= -CH && maxZ <= CH;
            for (let gx = 0; gx < steps; gx++) {
                const wx = minX + gx * SCATTER_STEP;
                if (!inside && Math.abs(wx) > CH) continue;
                for (let gz = 0; gz < steps; gz++) {
                    const wz = minZ + gz * SCATTER_STEP;
                    if (!inside && Math.abs(wz) > CH) continue;
                    nodes.push(wx, wz, wx, wz, F);
                }
            }
            if (!inside) {
                const g = this._g, c = { x: 0, z: 0 };
                for (let f = 0; f < 6; f++) {
                    if (f === F) continue;
                    let bx0 = 1e18, bx1 = -1e18, bz0 = 1e18, bz1 = -1e18, any = false;
                    for (let a = 0; a <= 16; a++) for (let b = 0; b <= 16; b++) {
                        chartToGeo(F, minX + CHUNK_SIZE * a / 16, minZ + CHUNK_SIZE * b / 16, g);
                        if (!geoToChart(f, g[0], g[1], g[2], c)) continue;
                        any = true; if (c.x < bx0) bx0 = c.x; if (c.x > bx1) bx1 = c.x; if (c.z < bz0) bz0 = c.z; if (c.z > bz1) bz1 = c.z;
                    }
                    if (!any) continue;
                    const i0 = Math.max(Math.ceil((bx0 - 3 * SCATTER_STEP) / SCATTER_STEP), Math.ceil(-CH / SCATTER_STEP)), i1 = Math.min(Math.floor((bx1 + 3 * SCATTER_STEP) / SCATTER_STEP), Math.floor(CH / SCATTER_STEP));
                    const j0 = Math.max(Math.ceil((bz0 - 3 * SCATTER_STEP) / SCATTER_STEP), Math.ceil(-CH / SCATTER_STEP)), j1 = Math.min(Math.floor((bz1 + 3 * SCATTER_STEP) / SCATTER_STEP), Math.floor(CH / SCATTER_STEP));
                    for (let i = i0; i <= i1; i++) for (let j = j0; j <= j1; j++) {
                        const hx = i * SCATTER_STEP, hz = j * SCATTER_STEP;
                        chartToGeo(f, hx, hz, g);
                        if (!geoToChart(F, g[0], g[1], g[2], c)) continue;
                        if (c.x < minX || c.x >= maxX || c.z < minZ || c.z >= maxZ) continue;
                        nodes.push(c.x, c.z, hx, hz, f);
                    }
                }
            }
        }
        const gTmp = [0, 0, 0];
        const FOREST_PROP = { 1: 1, 2: 1, 4: 1, 9: 1, 11: 1, 12: 1, 18: 1 };   // props that make forests (clump noise applies)
        const PROP_DENSITY = { 1: 0.075, 2: 0.072, 4: 0.07, 9: 0.085, 11: 0.075, 12: 0.06, 18: 0.08, 8: 0.05, 16: 0.055 };   // per-node tree chance (was a flat 0.045 everywhere)
        // v75 RESOURCE PATCHES: every biome now has patches of the three crystals, wood groves and stone outcrops. The world is cut into
        // PATCH_CELL squares; each cell hashes to at most one patch (kind, jittered centre, radius), cached per cell for this job.
        const PATCH_CELL = 380, patchMemo = new Map(), PATCH_KINDS = ['piezo', 'silicon', 'fluorite', 'wood', 'stone'];
        const patchOf = (cx, cz) => {
            const key = cx * 131071 + cz; let pc = patchMemo.get(key);
            if (pc !== undefined) return pc;
            const kx = cx + this.face * 7919, u = hr(kx, cz, 201);
            if (u >= 0.80) pc = null;
            else {
                pc = { kind: u < 0.17 ? 0 : u < 0.34 ? 1 : u < 0.51 ? 2 : u < 0.65 ? 3 : 4,
                       px: (cx + 0.2 + 0.6 * hr(kx, cz, 202)) * PATCH_CELL, pz: (cz + 0.2 + 0.6 * hr(kx, cz, 203)) * PATCH_CELL,
                       R: 70 + 50 * hr(kx, cz, 204), nat: hr(kx, cz, 205) };
            }
            patchMemo.set(key, pc); return pc;
        };
        for (let nI = 0; nI < nodes.length; nI += 5) {
            {
                const worldX = nodes[nI], worldZ = nodes[nI + 1], hX_ = nodes[nI + 2], hZ_ = nodes[nI + 3], hF_ = nodes[nI + 4];
                // v44 scatter tiers: 0 = full grid + grass, 1 = checkerboard half, 2 = every 4th node (subset of tier 1)
                const six = Math.round(hX_ / SCATTER_STEP), siz = Math.round(hZ_ / SCATTER_STEP);
                if (lod === 1 && ((six + siz) & 1)) continue;
                if (lod >= 2 && ((six & 1) || (siz & 1))) continue;
                if (vl.length) { const cp = VF.clearP(vl, worldX, worldZ); if (cp >= 1 || (cp > 0 && hr(hX_ + hF_ * 100003.7, hZ_, 97) < cp)) continue; }   // v55: graded - clear inside the city, thinning out past its edge (was a hard cut)
                const hh = (sl) => hr(hX_ + hF_ * 100003.7, hZ_, sl);
                let salt = 1; const rnd = () => hh(salt++);

                // --- v44 cheap pre-roll: decide from hashes + the lattice BEFORE any height / gradient / carve work, so the ~90% of nodes
                // that end up empty cost almost nothing (the scatter job was dominated by evaluating 3 heights for every node) ---
                const fx = (worldX - L.x0) / LS + (hh(91) - 0.5) * 0.9, fz = (worldZ - L.z0) / LS + (hh(92) - 0.5) * 0.9;
                const ni = Math.round(fz) * NL + Math.round(fx);
                const propId0 = L.prop[ni], bid = L.bid[ni];
                const r0 = hh(0);
                let gsalt = 700; const grnd = () => hh(gsalt++);
                let gType = 0;
                if (lod === 0) {
                    const propId = propId0;
                    if (propId === 2) { if (grnd() < 0.26) gType = 1; else if (grnd() < 0.09) gType = 2; }
                    else if (propId === 8) { if (grnd() < 0.20) gType = 3; }
                    else if (propId === 1) { if (grnd() < 0.22) gType = 4; }
                    else if (propId === 9) { if (grnd() < 0.24) gType = 4; }
                    else if (propId === 4) { const gr = grnd(); if (gr < 0.24) gType = 5; else if (gr < 0.52) gType = 6; }
                    else if (propId === 11 || propId === 18) { if (grnd() < (propId === 18 ? 0.30 : 0.24)) gType = 4; }
                    else if (propId === 12) { if (grnd() < 0.10) gType = 4; }
                    else if (propId === 13) { const gr = grnd(); if (gr < 0.18) gType = 1; else if (gr < 0.23) gType = 2; }
                    else if (propId === 14) { if (grnd() < 0.10) gType = 3; }
                    else if (propId === 15) { if (grnd() < 0.30) gType = 3; }
                    else if (propId === 16) { if (grnd() < 0.16) gType = 3; }
                }
                let rkind = -1;   // v75: which resource patch (index into PATCH_KINDS) this node falls in and rolled a spawn for
                { const pcx = Math.floor(worldX / PATCH_CELL), pcz = Math.floor(worldZ / PATCH_CELL), pc = patchOf(pcx, pcz);
                  if (pc) { const dx = worldX - pc.px, dz = worldZ - pc.pz, d2 = (dx * dx + dz * dz) / (pc.R * pc.R);
                    if (d2 < 1) {
                      let kind = pc.kind; const bcn = BIOMES[bid]; if (kind <= 2 && bcn && bcn.crystal && pc.nat < 0.3) kind = bcn.crystal === 'piezo' ? 0 : bcn.crystal === 'silicon' ? 1 : 2;
                      const dens = kind <= 2 ? 0.15 : kind === 3 ? 0.20 : 0.13;
                      if (hh(300) < dens * (1 - d2)) rkind = kind;
                    } } }
                const forest = FOREST_PROP[propId0] === 1;
                let prob = PROP_DENSITY[propId0]; if (prob === undefined) prob = 0.045; prob *= 1.3;   // v64: denser, fuller country
                if (!gType && rkind < 0 && r0 > (forest ? prob * 1.9 : prob)) continue;

                // --- environment at this point (smooth lattice + micro) ---
                const h = this.latFinal(L, worldX, worldZ);
                const gradEps = 6;
                const hX = heightAt(worldX + gradEps, worldZ), hZ = heightAt(worldX, worldZ + gradEps);
                const gX = (hX - h) / gradEps, gZ = (hZ - h) / gradEps;
                const nl = 1 / Math.sqrt(gX * gX + 1 + gZ * gZ), nxn = -gX * nl, nyn = nl, nzn = -gZ * nl;
                if (nyn < 0.75) continue;
                const propId = propId0;

                // orientation shared by everything placed here
                let qx, qy, qz, qw;
                { const lx = nxn * 0.4, ly = 0.6 + nyn * 0.4, lz = nzn * 0.4, ll = 1 / Math.sqrt(lx * lx + ly * ly + lz * lz);
                  const vx = lx * ll, vy = ly * ll, vz = lz * ll; qx = vz; qy = 0; qz = -vx; qw = 1 + vy; const ql = 1 / Math.sqrt(qx * qx + qz * qz + qw * qw); qx *= ql; qz *= ql; qw *= ql; }
                const place = (cat, ang, sx, sy, sz, py) => {
                    // q * rotY(ang)
                    const s = Math.sin(ang / 2), c = Math.cos(ang / 2);
                    const rx = qx * c - qz * s, ry = qy * c + qw * s, rz = qz * c + qx * s, rw = qw * c - qy * s;
                    composeM(D[cat], 0, worldX, py === undefined ? h : py, worldZ, rx, ry, rz, rw, sx, sy, sz);
                };

                // --- ground cover (LOD0 only; gType was rolled in the pre-roll) ---
                if (lod === 0 && h > WATER_LEVEL) {
                    if (gType) {
                        const ang = grnd() * Math.PI * 2, gs = 0.6 + grnd() * 0.9;
                        const cat = gType === 1 ? 'grassLush' : gType === 2 ? 'lushShrub' : gType === 3 ? 'grassDry' : gType === 5 ? 'reed' : gType === 6 ? 'swampGrass' : 'grassForest';
                        place(cat, ang, gs, gs, gs);
                    }
                }

                if (rkind >= 0) {   // v75: resource patch node - replaces whatever would normally grow here
                    if (h > WATER_LEVEL) {
                        const ra = rnd() * Math.PI * 2, rs = 0.7 + rnd() * 0.8;
                        if (rkind <= 2) place(PATCH_KINDS[rkind], ra, rs, rs * (0.9 + rnd() * 0.5), rs);
                        else if (rkind === 3) { const pid = propId0; place((pid === 3 || pid === 8 || pid === 16) ? 'acacia' : (pid === 6 || pid === 7 || pid === 12 || pid === 17 || pid === 10) ? 'pine' : 'dec', ra, rs, rs, rs); }
                        else place('boulder', ra, rs * 0.9, rs * 0.9, rs * 0.9);
                    }
                    continue;
                }
                if (forest) {
                    // v44 groves and clearings: a 600-unit noise field scales the tree chance 0.35x (glade) .. 1.8x (thick grove)
                    chartToGeo(this.face, worldX, worldZ, gTmp);
                    const cl = this.T.N(gTmp[0] * PLANET_R, gTmp[1] * PLANET_R, gTmp[2] * PLANET_R, 0.0016, 31, -31);
                    const k = Math.min(1, Math.max(0, (cl + 0.45) / 1.0)); prob *= 0.35 + 1.45 * k * k * (3 - 2 * k);
                }
                if (r0 > prob) continue;
                const ang0 = rnd() * Math.PI * 2, rScale = (0.5 + rnd() * 0.7) * (lod >= 2 ? 1.45 : lod === 1 ? 1.12 : 1);
                const P = (cat) => place(cat, ang0, rScale, rScale, rScale);

                if (propId === 5 || propId === 19 || propId === 20) {
                    const KELP_BASE_HEIGHT = 80, waterDepth = WATER_LEVEL - h;
                    if (waterDepth > (propId === 5 ? 30 : 8)) {
                        const desiredScale = propId === 19 ? 0.25 + rnd() * 0.2 : (propId === 20 ? (rnd() < 0.5 ? 0.3 + rnd() * 0.3 : 0.9 + rnd() * 0.8) : 1 + rnd() * 1.5);
                        const maxFitScale = Math.max(0.25, (waterDepth - 10) / KELP_BASE_HEIGHT);
                        place('kelp', ang0, 1, Math.min(desiredScale, maxFitScale), 1);
                    }
                }
                else if (propId === 4) {
                    const r4 = rnd();
                    if (r4 < 0.58) P('swampTree'); else if (r4 < 0.70) P('swampLog'); else if (r4 < 0.86) P('lushShrub'); else if (r4 < 0.90) P('mush');
                }
                else if (propId === 3) { if (rnd() < 0.1) P('cactus'); else if (rnd() < 0.06) P('shrub'); }
                else if (propId === 6) { if (rnd() < 0.16) P('crystal'); }
                else if (propId === 7) { if (rnd() < 0.08) P('ice'); }
                else if (propId === 1) { P('pine'); if (rnd() < 0.04) P('boulder'); }
                else if (propId === 2) {
                    chartToGeo(this.face, worldX, worldZ, gTmp); const density = this.T.N(gTmp[0] * PLANET_R, gTmp[1] * PLANET_R, gTmp[2] * PLANET_R, 0.015, 7, 7);
                    if (density > -0.2) P('dec'); else if (rnd() < 0.25) P('flower');
                }
                else if (propId === 8) { if (rnd() < 0.16) P('acacia'); else if (rnd() < 0.08) P('shrub'); }
                else if (propId === 9) { if (rnd() < 0.85) P('jungle'); else if (rnd() < 0.2) P('flower'); }
                else if (propId === 11) { if (rnd() < 0.55) P('dec'); else P('pine'); if (rnd() < 0.03) P('boulder'); }
                else if (propId === 18) { const r18 = rnd(); if (r18 < 0.46) P('pine'); else if (r18 < 0.86) P('dec'); else if (r18 < 0.93) P('mush'); else P('lushShrub'); }
                else if (propId === 12) { if (rnd() < 0.55) P('pine'); else if (rnd() < 0.12) P('boulder'); }
                else if (propId === 13) { if (rnd() < 0.3) P('flower'); else if (rnd() < 0.12) P('boulder'); }
                else if (propId === 14) { if (rnd() < 0.35) P('shrub'); else if (rnd() < 0.10) P('boulder'); }
                else if (propId === 15) { if (rnd() < 0.08) P('shrub'); else if (rnd() < 0.05) P('flower'); }
                else if (propId === 16) { const r16 = rnd(); if (r16 < 0.5) P('shrub'); else if (r16 < 0.72) P('pine'); else if (r16 < 0.8) P('acacia'); }
                else if (propId === 17) { if (rnd() < 0.22) P('boulder'); }
                else if (propId === 10) { if (rnd() < 0.4) P('vent'); }
                else if (propId === 0 && h > 700) { if (rnd() < 0.05) P('boulder'); }


                if (h > WATER_LEVEL && rnd() < 0.03) {
                    const s = 0.8 + rnd() * 2.0, ex = rnd() * Math.PI, ey = rnd() * Math.PI;
                    const s1 = Math.sin(ex / 2), c1 = Math.cos(ex / 2), s2 = Math.sin(ey / 2), c2 = Math.cos(ey / 2);
                    composeM(D.rock, 0, worldX, h - 1, worldZ, s1 * c2, c1 * s2, s1 * s2, c1 * c2, s, s * 0.6, s);
                }
            }
        }
        const res = { key: job.key, cats: {}, colors: {}, ms: 0, tier: lod }, tr = [];
        const SMALL = { flower: 1, shrub: 1, mush: 1, lushShrub: 1, swampLog: 1, grassLush: 1, grassDry: 1, grassForest: 1, reed: 1, swampGrass: 1, rock: 1 };
        for (const c of cats) {
            if (lod >= 1 && SMALL[c]) continue;
            const a = D[c]; if (!a.length) continue;
            const f = new Float32Array(a); res.cats[c] = f; tr.push(f.buffer);
            if (c === 'grassLush' || c === 'grassDry' || c === 'grassForest' || c === 'reed' || c === 'swampGrass') {
                const n = a.length / 16, cc = new Float32Array(n * 3);
                for (let i = 0; i < n; i++) {
                    const ex = a[i * 16 + 12], ez = a[i * 16 + 14];
                    const br = 0.82 + hr(ex, ez, 555) * 0.36, warm = (hr(ex, ez, 771) - 0.5) * 0.12;
                    cc[i * 3] = br + warm * 0.5; cc[i * 3 + 1] = br; cc[i * 3 + 2] = br - warm * 0.3;
                }
                res.colors[c] = cc; tr.push(cc.buffer);
            }
        }
        res.ms = performance.now() - t0;
        return { out: res, tr };
    }
    // ================================================================= CITY (v45) =================================================================
    // job: { siteId }. Generates the whole city of one valley site in its chart-independent plan space and returns typed instance data.
    buildCity(job) {
        const t0 = performance.now(), S = this.sites[job.siteId]; if (!S) return { out: { siteId: job.siteId, empty: true }, tr: [] };
        const T = this.T, d = [0, 0, 0], o = {};
        const nat3 = (x, z) => { localToDir(S, x, -z, d); return T.sample3(d[0] * PLANET_R, d[1] * PLANET_R, d[2] * PLANET_R, o); };
        const nat = makeNatGrid(S, nat3, S.citadel ? 60 : 20), city = S.citadel ? generateCitadel(S, nat) : generateCity(S, nat), inst = planToInstances(city), life = planToLife(city), cols = planToCols(city), road = planToRoad(city), probes = new Float32Array(city.probes || []);
        if (S.citadel) { life.meta.multiLevel = true; life.meta.citadel = true; }   // v56: the Rogues' Citadel (see citadel_core.js)
        const tr = [];
        for (const k in inst.cats) { tr.push(inst.cats[k].m.buffer, inst.cats[k].c.buffer); }
        tr.push(inst.sky.m.buffer, inst.sky.c.buffer, life.nodes.buffer, life.edges.buffer, life.ew.buffer, cols.buffer, road.pos.buffer, road.nor.buffer, road.col.buffer, road.idx.buffer, probes.buffer);
        return { out: { siteId: job.siteId, inst, life, cols, road, probes, tunnel: city.tunnel || null, beam: city.beam || null, layers: city.layers || null, ms: performance.now() - t0 }, tr };
    }
    // job: { a: siteId, b: siteId } -> road polyline between two city gates (see city_roads.js)
    buildRoad(job) {
        const t0 = performance.now(), A = this.sites[job.a], B = this.sites[job.b]; if (!A || !B) return { out: { a: job.a, b: job.b, empty: true }, tr: [] };
        const r = buildRoad(this.T, A, B);
        const tr = r.pts ? [r.pts.buffer] : [];
        return { out: { a: job.a, b: job.b, road: r, ms: performance.now() - t0 }, tr };
    }

}
