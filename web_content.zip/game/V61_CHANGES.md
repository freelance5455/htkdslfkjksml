# v61 - STEP 2 REFINEMENT: calmer land, readable ranges, natural volcanic chains (terrain_core.js only)
Small tuning pass, no structural changes. Tests (test_sites, test_chunks, test_shape, test_v59, test_v60_rainshadow) pass; land stats unchanged. Not run in a browser.
- **Less hilly/jagged:** the regional 'carved relief' layer in `_variety` (the main source of grain) is now ~12% strength on lowlands and foothills and full strength only on ranges (`rangeK`); regional ruggedness 1.1 -> 0.66; sharp spines only in ranges. Ranges now stand out from smooth plains.
- **Ranges look like ranges:** broad foothill pedestal under each crest, a third lower outer range on collisions/cordilleras, deeper (0.72 -> 0.82) and more frequent longitudinal valleys/basins.
- **Volcanic chains / islands:** chains meander and bend, spacing is uneven, outlines use two noise scales (bays, headlands, lobes), wider reef shelf (swell 0.30 -> 0.36, reach 2.4 -> 2.8 radii). cosReach widened to match.
Knobs: `rangeK` / `(0.12 + 0.88 * rangeK)` in `_variety`; `g3`, pedestal 0.13, `0.82 * vv` in `_ridge`; `bend`, `0.30/0.35 * HOT_DX` lateral terms in `_buildHotspots`.
