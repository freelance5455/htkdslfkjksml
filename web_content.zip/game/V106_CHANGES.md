# v106 - the hearing no longer overloads the audio (dream_cinematic.js, audio section only)

Report: when the council scene (the hearing) starts, the dream gets extremely loud, the audio glitches into popping and then stops.

Cause (found by reading the graph and rendering the scene offline):
- Eight background watchers talked at once (gain 0.3 each, the speaker was 0.55), so the crowd was ~4x louder than the one voice that matters, and the compressor then lifted the whole thing.
- Every placed voice was an HRTF panner, and the listener moves every frame in the hall. With a-rate listener/panner params each of the nine panners recomputed its angles on every sample. Every voice also carried 5 gliding biquads whose coefficients were recomputed per sample while they glided.
- 22 heartbeat thumps were created in one frame, and the third blow created ~300 nodes in one frame (46 glass shards, each with an oscillator above Nyquist that folded back as a hiss). Gavel/thump energy at 28-40 Hz (inaudible on a phone) slammed the 2 ms limiter, which is what pops.

Changes:
- Crowd: 8 -> 4 voices, far off (dist 0.78: muffled), gain 0.3 -> 0.11, slower and sparser, fade in over 3.5 s and out before the end, cheap equal-power panner, "lite" voice (3 formants, no jitter oscillator, no consonant bursts). The speaker is the only HRTF voice and is now clearly the loudest. Child/laughs a little lower.
- All biquads and all panner/listener parameters are k-rate (once per 128 frames instead of per sample). Applies to every scene.
- Heartbeat: one event per beat, 72->50 Hz (was 62->40), softer. Gavels 120->54 Hz at 0.38 (was 110->38 at 0.55). Final blow 72->42 Hz at 0.4 (was 70->28 at 0.6). Drone and whisper bed in the hall lowered.
- Glass: 30 pieces (was 46), spread over five small batches; the upper partial is skipped when it would pass Nyquist.
- Reverb tails shortened (hall 3.2 -> 2.4 s, dark 2.6 -> 2.2 s) as v105 suggested for slow phones.
- Fixed: a voice given fadeOut jumped back to full gain at its end.

Measured offline (hearing scene, 33 s, headless Chromium): render time 31.8 s -> 20.7 s, no samples above Nyquist, no new clicks, first 6 s of the scene 4-8 dB quieter, level during the scene ~1.5-2 dB lower after the compressor. Not verified: by ear, or on a phone.
