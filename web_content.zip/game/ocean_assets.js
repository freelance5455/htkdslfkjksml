// ocean_assets.js - v109 OCEAN OVERHAUL, part 2: shared geometry tools, painterly canvas textures and the boat.
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { registerShaderFallback, dropCustomShader } from './ocean_surface.js';

// ---- small utilities -------------------------------------------------------------------------------------------------------------
export function rng(seed) { let a = (seed >>> 0) || 1; return function () { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
function hash2(ix, iz, s) { let h = (ix * 374761393 + iz * 668265263 + s * 1442695041) | 0; h = Math.imul(h ^ (h >>> 13), 1274126177); return ((h ^ (h >>> 16)) >>> 0) / 4294967296; }
export function vnoise(x, z, s) {
    const ix = Math.floor(x), iz = Math.floor(z), fx = x - ix, fz = z - iz, ux = fx * fx * (3 - 2 * fx), uz = fz * fz * (3 - 2 * fz);
    const a = hash2(ix, iz, s), b = hash2(ix + 1, iz, s), c = hash2(ix, iz + 1, s), d = hash2(ix + 1, iz + 1, s);
    return (a + (b - a) * ux) + ((c + (d - c) * ux) - (a + (b - a) * ux)) * uz;
}
export function fbm(x, z, s, oct) { let v = 0, a = 0.5, f = 1; for (let i = 0; i < (oct || 4); i++) { v += a * vnoise(x * f, z * f, s + i * 17); a *= 0.5; f *= 2.03; } return v; }
export const lerp = (a, b, t) => a + (b - a) * t;
export const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
export const smooth = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };

export function canvasTex(w, h, draw, repeatX, repeatY, srgb) {
    if (typeof document === 'undefined') return null;
    const c = document.createElement('canvas'); c.width = w; c.height = h;
    const g = c.getContext('2d'); draw(g, w, h);
    const t = new THREE.CanvasTexture(c);
    t.wrapS = t.wrapT = THREE.RepeatWrapping; if (repeatX) t.repeat.set(repeatX, repeatY || repeatX);
    if (srgb !== false) t.colorSpace = THREE.SRGBColorSpace;
    t.anisotropy = 4; return t;
}
// brushy speckle used on every painted surface so nothing reads as a flat colour
function grain(g, w, h, n, alpha, lo, hi, r) {
    const rr = r || rng(7);
    for (let i = 0; i < n; i++) {
        const v = Math.floor(lo + rr() * (hi - lo)); g.fillStyle = `rgba(${v},${v},${v},${alpha * (0.3 + rr() * 0.7)})`;
        const x = rr() * w, y = rr() * h; g.fillRect(x, y, 1 + rr() * 5, 1 + rr() * 1.4);
    }
}

// ---- geometry builder: merge many transformed primitives into one draw call, with vertex colour (+gradient), per-face paint jitter and a
// "sway" weight attribute (0 at the root, 1 at the tip) that the sway shader reads --------------------------------------------------
const _m = new THREE.Matrix4(), _q = new THREE.Quaternion(), _e = new THREE.Euler(), _s = new THREE.Vector3(), _p = new THREE.Vector3(), _c = new THREE.Color(), _c2 = new THREE.Color();
export class GB {
    constructor(seed) { this.parts = []; this.r = rng(seed || 3); }
    // geo: any BufferGeometry. o: { p:[x,y,z], r:[rx,ry,rz], s:[sx,sy,sz]|n, c:hex|Color, c2: top colour (vertical gradient across the geometry), jit: 0..1, sway: weight }
    add(geo, o) {
        o = o || {};
        let g = geo.index ? geo.toNonIndexed() : geo.clone();
        g.deleteAttribute('uv'); if (g.getAttribute('uv1')) g.deleteAttribute('uv1');
        if (!g.getAttribute('normal')) g.computeVertexNormals();
        g.computeBoundingBox(); const y0 = g.boundingBox.min.y, y1 = g.boundingBox.max.y, hh = Math.max(1e-5, y1 - y0);
        const pos = g.getAttribute('position'), n = pos.count;
        const col = new Float32Array(n * 3), sw = new Float32Array(n);
        _c.set(o.c === undefined ? 0x888888 : o.c); _c2.set(o.c2 === undefined ? (o.c === undefined ? 0x888888 : o.c) : o.c2);
        const jit = o.jit === undefined ? 0.12 : o.jit;
        for (let i = 0; i < n; i += 3) {
            const fj = 1 + (this.r() - 0.5) * 2 * jit;
            for (let k = 0; k < 3; k++) {
                const t = (pos.getY(i + k) - y0) / hh;
                col[(i + k) * 3] = lerp(_c.r, _c2.r, t) * fj; col[(i + k) * 3 + 1] = lerp(_c.g, _c2.g, t) * fj; col[(i + k) * 3 + 2] = lerp(_c.b, _c2.b, t) * fj;
                sw[i + k] = o.sway ? o.sway * Math.pow(t, 1.5) : 0;
            }
        }
        g.setAttribute('color', new THREE.BufferAttribute(col, 3)); g.setAttribute('aSway', new THREE.BufferAttribute(sw, 1));
        const s = o.s === undefined ? [1, 1, 1] : (typeof o.s === 'number' ? [o.s, o.s, o.s] : o.s), r = o.r || [0, 0, 0], p = o.p || [0, 0, 0];
        _q.setFromEuler(_e.set(r[0], r[1], r[2], 'YXZ')); _m.compose(_p.set(p[0], p[1], p[2]), _q, _s.set(s[0], s[1], s[2]));
        g.applyMatrix4(_m); this.parts.push(g); return this;
    }
    box(w, h, d, o) { return this.add(new THREE.BoxGeometry(w, h, d), o); }
    cyl(rt, rb, h, seg, o) { return this.add(new THREE.CylinderGeometry(rt, rb, h, seg || 8), o); }
    cone(r, h, seg, o) { return this.add(new THREE.ConeGeometry(r, h, seg || 6), o); }
    ico(r, det, o) { return this.add(new THREE.IcosahedronGeometry(r, det || 0), o); }
    sph(r, o, ws, hs) { return this.add(new THREE.SphereGeometry(r, ws || 8, hs || 6), o); }
    tor(r, t, o, ts, ss) { return this.add(new THREE.TorusGeometry(r, t, ts || 6, ss || 14), o); }
    build() {
        if (!this.parts.length) return new THREE.BufferGeometry();
        const g = mergeGeometries(this.parts, false); this.parts.forEach(p => p.dispose()); this.parts = [];
        g.computeBoundingSphere(); return g;
    }
}

// ---- lofted surface: fn(u, v) -> [x, y, z] for u,v in [0,1]. closedV wraps v (rings) ----------------------------------------------
export function loftGeo(nu, nv, fn, closedV) {
    const pos = new Float32Array((nu + 1) * (nv + 1) * 3), uv = new Float32Array((nu + 1) * (nv + 1) * 2);
    let o = 0, q = 0;
    for (let i = 0; i <= nu; i++) for (let j = 0; j <= nv; j++) {
        const p = fn(i / nu, j / nv); pos[o++] = p[0]; pos[o++] = p[1]; pos[o++] = p[2]; uv[q++] = i / nu; uv[q++] = j / nv;
    }
    const idx = [];
    for (let i = 0; i < nu; i++) for (let j = 0; j < nv; j++) {
        const a = i * (nv + 1) + j, b = (i + 1) * (nv + 1) + j, c = a + 1, d = b + 1;
        idx.push(a, b, c, c, b, d);
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3)); g.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
    g.setIndex(idx); g.computeVertexNormals(); return g;
}

// ---- sway / flutter shader for plants, cloth, flags (uniform `uSeaTime` is shared and set by the owner) -------------------------
export const SEA_TIME = { value: 0 };
export function swayMaterial(base, amount, speed, marker) {
    base.onBeforeCompile = function (shader) {
        shader.uniforms.uSeaTime = SEA_TIME;
        shader.vertexShader = shader.vertexShader
            .replace('#include <common>', `#include <common>
// OCEANFX:${marker || 'sway'}
uniform float uSeaTime;
attribute float aSway;`)
            .replace('#include <begin_vertex>', `#include <begin_vertex>
    {
        float swPh = position.x * 0.09 + position.z * 0.07;
        float swT = uSeaTime * ${(speed || 1).toFixed(3)};
        transformed.x += (sin(swT + swPh) + 0.5 * sin(swT * 1.7 + swPh * 2.1)) * aSway * ${(amount || 1).toFixed(3)};
        transformed.z += (cos(swT * 0.8 + swPh * 1.3)) * aSway * ${((amount || 1) * 0.7).toFixed(3)};
    }`);
    };
    base.customProgramCacheKey = () => 'sea-sway-' + (marker || 'sway') + amount + speed;
    registerShaderFallback('OCEANFX:' + (marker || 'sway'), () => dropCustomShader(base, marker || 'sway'));
    return base;
}

// ---- painterly canvas textures ---------------------------------------------------------------------------------------------------
let _tex = {};
export function plankTexture() {
    if (_tex.plank !== undefined) return _tex.plank;
    return _tex.plank = canvasTex(256, 256, (g, w, h) => {
        const r = rng(11), n = 8, ph = h / n;
        for (let i = 0; i < n; i++) {
            const b = 150 + r() * 50; g.fillStyle = `rgb(${b},${b * 0.78},${b * 0.55})`; g.fillRect(0, i * ph, w, ph);
            for (let k = 0; k < 26; k++) {   // long grain strokes
                const y = i * ph + r() * ph, x = r() * w, len = 30 + r() * 110, d = (r() - 0.5) * 40;
                g.strokeStyle = `rgba(${60 + d},${42 + d * 0.7},${24 + d * 0.5},${0.12 + r() * 0.18})`; g.lineWidth = 0.6 + r() * 1.4;
                g.beginPath(); g.moveTo(x, y); g.bezierCurveTo(x + len * 0.3, y + (r() - 0.5) * 3, x + len * 0.7, y + (r() - 0.5) * 3, x + len, y); g.stroke();
            }
            g.fillStyle = 'rgba(30,18,8,0.55)'; g.fillRect(0, i * ph, w, 2);          // seam
            const nx = r() * w; g.fillStyle = 'rgba(40,40,44,0.7)'; g.fillRect(nx, i * ph + ph * 0.5, 2.5, 2.5);   // nail head
        }
        grain(g, w, h, 900, 0.18, 20, 230, r);
    }, 2, 2);
}
export function sailTexture() {
    if (_tex.sail !== undefined) return _tex.sail;
    return _tex.sail = canvasTex(256, 256, (g, w, h) => {
        const r = rng(23); g.fillStyle = '#d8ccb0'; g.fillRect(0, 0, w, h);
        const patches = [['#c9b48a', 0, 0, 120, 100], ['#9db3a6', 130, 20, 110, 130], ['#d9c9a4', 20, 130, 90, 110], ['#b99a76', 150, 160, 100, 90], ['#8aa6b0', 70, 70, 60, 60]];
        patches.forEach(([c, x, y, pw, ph]) => { g.fillStyle = c; g.fillRect(x, y, pw, ph); g.strokeStyle = 'rgba(70,52,34,0.7)'; g.setLineDash([5, 4]); g.lineWidth = 1.5; g.strokeRect(x + 3, y + 3, pw - 6, ph - 6); g.setLineDash([]); });
        for (let i = 0; i < 18; i++) { g.strokeStyle = 'rgba(120,100,78,0.22)'; g.lineWidth = 1; const x = (i / 18) * w; g.beginPath(); g.moveTo(x, 0); g.lineTo(x + (r() - 0.5) * 8, h); g.stroke(); }
        grain(g, w, h, 1200, 0.2, 60, 235, r);
    });
}
export function metalTexture() {
    if (_tex.metal !== undefined) return _tex.metal;
    return _tex.metal = canvasTex(256, 256, (g, w, h) => {
        const r = rng(31); g.fillStyle = '#7e868e'; g.fillRect(0, 0, w, h);
        for (let i = 0; i < 4; i++) for (let j = 0; j < 4; j++) {               // riveted panels
            const x = i * 64, y = j * 64, v = 110 + r() * 40; g.fillStyle = `rgb(${v},${v + 6},${v + 12})`; g.fillRect(x + 2, y + 2, 60, 60);
            g.strokeStyle = 'rgba(20,24,28,0.8)'; g.lineWidth = 2; g.strokeRect(x + 1, y + 1, 62, 62);
            g.fillStyle = 'rgba(30,34,38,0.7)'; [[6, 6], [56, 6], [6, 56], [56, 56]].forEach(([dx, dy]) => g.fillRect(x + dx, y + dy, 3, 3));
        }
        for (let i = 0; i < 40; i++) { g.fillStyle = `rgba(${90 + r() * 60},${50 + r() * 30},${25},${0.05 + r() * 0.12})`; g.beginPath(); g.ellipse(r() * w, r() * h, 8 + r() * 30, 4 + r() * 14, r() * 3, 0, 7); g.fill(); }   // rust blooms
        grain(g, w, h, 1500, 0.25, 30, 220, r);
    }, 2, 2);
}
export function stoneTexture() {
    if (_tex.stone !== undefined) return _tex.stone;
    return _tex.stone = canvasTex(256, 256, (g, w, h) => {
        const r = rng(41); g.fillStyle = '#5e666a'; g.fillRect(0, 0, w, h);
        for (let i = 0; i < 70; i++) { const v = 70 + r() * 60; g.fillStyle = `rgba(${v},${v + 6},${v + 8},0.35)`; g.beginPath(); g.ellipse(r() * w, r() * h, 10 + r() * 36, 5 + r() * 16, r() * 3, 0, 7); g.fill(); }
        for (let i = 0; i < 24; i++) { g.strokeStyle = 'rgba(20,24,26,0.35)'; g.lineWidth = 1 + r() * 1.5; g.beginPath(); let x = r() * w, y = r() * h; g.moveTo(x, y); for (let k = 0; k < 5; k++) { x += (r() - 0.5) * 50; y += (r() - 0.5) * 50; g.lineTo(x, y); } g.stroke(); }
        grain(g, w, h, 1600, 0.22, 20, 230, r);
    }, 2, 2);
}

export const PAINT = { rough: 0.92 };
export function paintMat(opts) {
    return new THREE.MeshStandardMaterial(Object.assign({ vertexColors: true, roughness: PAINT.rough, metalness: 0.04 }, opts || {}));
}

// ================================================================================================================================
// THE BOAT.  Faces +Z, origin at the waterline amidships, ~36 units long (eye height in this game is 8.5, so this is a small ship, not a dinghy).
// A hull lofted from stations (curved planking, flared sides, raised prow, transom stern), deck, aft cabin with a glowing window, a mast
// with a patched lateen sail and pennant (they flutter in the vertex shader), a bow lantern, and the piezo-quartz drive at the stern.
// Everything hangs off `rig`, which the game tilts to the swell. Nothing sits at the centre line near the camera.
// ================================================================================================================================
const HULL_L = 18;
function hullHalfW(u) { return u >= 0 ? 5.6 * Math.pow(1 - Math.pow(u, 2.2), 0.6) : Math.sqrt(Math.pow(5.1 * Math.pow(1 - Math.pow(-u, 3.0), 0.5), 2) + 5.76); }
function hullKeel(u) { return -1.9 + (u > 0 ? 2.6 : 1.6) * Math.pow(Math.abs(u), 2.5); }
function hullSheer(u) { return 3.4 + (u > 0 ? 3.6 * Math.pow(u, 3.0) : 0.9 * Math.pow(-u, 2.5)); }
export const BOAT_DECK_Y = 2.3;

export function makeBoat() {
    const root = new THREE.Group(), rig = new THREE.Group(); root.add(rig);
    const anim = [];   // update callbacks
    const plank = plankTexture();

    // hull: sp in [0,1] runs gunwale(left) -> keel -> gunwale(right)
    const hullGeo = loftGeo(34, 14, (u01, sp) => {
        const u = u01 * 2 - 1, s = sp * 2 - 1, t = Math.abs(s), side = s < 0 ? -1 : 1;
        const w = hullHalfW(u), k = hullKeel(u), sh = hullSheer(u), phi = t * Math.PI / 2;
        return [side * w * Math.pow(Math.sin(phi), 0.78), k + (sh - k) * Math.pow(t, 1.15), u * HULL_L];
    });
    // paint: tar-black below the waterline, weathered planks above, a faded teal strake near the rail
    {
        const pos = hullGeo.getAttribute('position'), col = new Float32Array(pos.count * 3), c = new THREE.Color(), r = rng(5);
        for (let i = 0; i < pos.count; i++) {
            const y = pos.getY(i); const j = 0.9 + r() * 0.2;
            if (y < 0.15) c.setRGB(0.10, 0.12, 0.11).lerp(_c2.setRGB(0.12, 0.30, 0.22), 0.4 * Math.max(0, 1 - (y + 1.9) / 2)); // algae
            else if (y > hullSheer(pos.getZ(i) / HULL_L) - 1.1) c.setRGB(0.20, 0.52, 0.50);
            else c.setRGB(0.80, 0.62, 0.42);
            col[i * 3] = c.r * j; col[i * 3 + 1] = c.g * j; col[i * 3 + 2] = c.b * j;
        }
        hullGeo.setAttribute('color', new THREE.BufferAttribute(col, 3));
    }
    const uvs = hullGeo.getAttribute('uv'); for (let i = 0; i < uvs.count; i++) uvs.setXY(i, uvs.getX(i) * 4, uvs.getY(i) * 3);
    const hull = new THREE.Mesh(hullGeo, new THREE.MeshStandardMaterial({ map: plank, vertexColors: true, roughness: 0.85, metalness: 0.02, side: THREE.DoubleSide }));
    hull.castShadow = true; hull.receiveShadow = true; rig.add(hull);

    // deck
    const deckGeo = loftGeo(34, 2, (u01, v) => { const u = u01 * 2 - 1, w = hullHalfW(u) * 0.9; return [(v * 2 - 1) * w, BOAT_DECK_Y, u * HULL_L * 0.985]; });
    const du = deckGeo.getAttribute('uv'); for (let i = 0; i < du.count; i++) du.setXY(i, du.getY(i) * 3, du.getX(i) * 6);
    const deck = new THREE.Mesh(deckGeo, new THREE.MeshStandardMaterial({ map: plank, color: 0xcdb08a, roughness: 0.9, side: THREE.DoubleSide }));
    deck.receiveShadow = true; rig.add(deck);

    // wood details (one merged mesh, vertex-coloured)
    const wood = new GB(9), dark = 0x4a3524, mid = 0x7a5836, lite = 0xa07a4c, brass = 0xb08a3e, rope = 0xb59c6a;
    for (let i = -16; i <= 16; i += 2) {        // gunwale rail: boxes following the sheer
        const u = i / HULL_L, w = hullHalfW(u) * 0.99, y = hullSheer(u) + 0.15, u2 = (i + 2) / HULL_L, y2 = hullSheer(Math.min(1, u2));
        const len = Math.hypot(2, y2 - y) + 0.1, pitch = Math.atan2(y2 - y, 2);
        for (const sd of [-1, 1]) wood.box(0.55, 0.45, len, { p: [sd * w, y + (y2 - y) / 2, i + 1], r: [-pitch, 0, 0], c: dark, c2: mid });
    }
    for (const z of [-9, -2.5, 4.5, 10.5]) {    // thwarts (benches) and knees
        const w = hullHalfW(z / HULL_L) * 0.9, y = BOAT_DECK_Y + 1.9;
        wood.box(w * 2, 0.45, 1.5, { p: [0, y, z], c: mid, c2: lite });
        for (const sd of [-1, 1]) wood.box(0.5, 1.9, 0.6, { p: [sd * w * 0.9, BOAT_DECK_Y + 1.0, z], c: dark });
    }
    // bow: carved stem post, a curl, the lantern hook
    wood.box(0.9, 4.5, 1.2, { p: [0, hullSheer(1) + 0.8, HULL_L - 0.6], r: [0.35, 0, 0], c: dark, c2: mid });
    wood.tor(1.2, 0.3, { p: [0, hullSheer(1) + 3.6, HULL_L + 0.2], r: [0, Math.PI / 2, 0], c: lite }, 6, 12);
    wood.box(0.3, 3.2, 0.3, { p: [0, hullSheer(1) + 5.6, HULL_L - 1.2], c: dark });
    wood.box(0.3, 0.3, 1.6, { p: [0, hullSheer(1) + 7.0, HULL_L - 0.4], c: dark });
    // aft cabin: planked shed, slanted roof, door and window openings read as dark panels
    wood.box(8.4, 4.6, 8.6, { p: [0, BOAT_DECK_Y + 2.3, -12.4], c: mid, c2: lite });
    wood.box(9.6, 0.5, 10.0, { p: [0, BOAT_DECK_Y + 5.0, -12.4], r: [0.07, 0, 0], c: dark, c2: mid });
    wood.box(3.0, 3.6, 0.2, { p: [0, BOAT_DECK_Y + 1.9, -8.02], c: 0x1b1612 });                                // door
    for (const sd of [-1, 1]) wood.box(0.2, 1.6, 2.4, { p: [sd * 4.22, BOAT_DECK_Y + 3.0, -12.4], c: 0x16202a });   // windows (the glow is separate)
    wood.cyl(0.35, 0.35, 5.5, 8, { p: [3.4, BOAT_DECK_Y + 7.4, -10.4], c: 0x3a3430 });                           // stove pipe
    // stern post and rudder
    wood.box(0.7, 3.0, 1.0, { p: [0, 3.6, -HULL_L + 0.6], c: dark });
    wood.box(0.5, 4.2, 2.2, { p: [0, -0.4, -HULL_L - 0.8], r: [0.15, 0, 0], c: mid });
    // cargo and clutter, away from the centre line: barrels, crates, rope coils, two oars, fenders
    for (const [x, z] of [[3.6, 8.0], [3.8, 5.6], [-3.6, 11.5]]) { wood.cyl(1.05, 1.0, 2.5, 10, { p: [x, BOAT_DECK_Y + 1.25, z], c: 0x6a4a2c, c2: 0x8a6a40 }); wood.tor(1.03, 0.1, { p: [x, BOAT_DECK_Y + 0.7, z], r: [Math.PI / 2, 0, 0], c: 0x2a2a2c }, 4, 12); wood.tor(1.03, 0.1, { p: [x, BOAT_DECK_Y + 1.9, z], r: [Math.PI / 2, 0, 0], c: 0x2a2a2c }, 4, 12); }
    wood.box(2.4, 1.8, 2.4, { p: [-3.7, BOAT_DECK_Y + 0.9, 6.5], r: [0, 0.3, 0], c: 0x8a6a40, c2: 0xa88458 });
    wood.box(1.9, 1.5, 1.9, { p: [-3.9, BOAT_DECK_Y + 2.55, 6.7], r: [0, -0.2, 0], c: 0x7a5a38 });
    wood.tor(1.5, 0.35, { p: [3.4, BOAT_DECK_Y + 0.4, 0.5], r: [Math.PI / 2, 0, 0], c: rope, c2: 0x8f7a4c }, 6, 14);
    wood.tor(1.1, 0.3, { p: [3.4, BOAT_DECK_Y + 0.8, 0.5], r: [Math.PI / 2, 0, 0], c: rope }, 6, 14);
    wood.cyl(0.14, 0.14, 22, 5, { p: [-5.0, BOAT_DECK_Y + 2.0, 1], r: [Math.PI / 2, 0, 0.04], c: lite });      // oars along the rail
    wood.box(0.3, 0.3, 4.5, { p: [-5.05, BOAT_DECK_Y + 2.3, 11.6], c: lite });
    wood.cyl(0.14, 0.14, 22, 5, { p: [5.0, BOAT_DECK_Y + 2.0, 1], r: [Math.PI / 2, 0, -0.04], c: lite });
    wood.box(0.3, 0.3, 4.5, { p: [5.05, BOAT_DECK_Y + 2.3, 11.6], c: lite });
    for (const z of [-5, 3, 12]) for (const sd of [-1, 1]) wood.sph(0.6, { p: [sd * hullHalfW(z / HULL_L) * 1.03, 2.2, z], c: 0x4a5a64, c2: 0x6a7a84 }, 6, 5);   // fenders
    // mast (aft of the camera: it never blocks the view ahead), boom and yard
    wood.cyl(0.38, 0.55, 40, 8, { p: [0, BOAT_DECK_Y + 20, -6.0], c: mid, c2: dark });
    wood.cyl(0.2, 0.2, 31, 6, { p: [0, BOAT_DECK_Y + 28.5, -10.5], r: [-1.02, 0, 0], c: dark, c2: mid });    // lateen yard, sloping aft
    wood.box(1.0, 0.8, 1.0, { p: [0, BOAT_DECK_Y + 41, -6.0], c: brass });
    for (const sd of [-1, 1]) { wood.cyl(0.08, 0.08, 28, 4, { p: [sd * 2.6, BOAT_DECK_Y + 18, -3.5], r: [0, 0, sd * -0.1 - 0.0], c: 0x2a2018 }); }   // shrouds
    const woodMesh = new THREE.Mesh(wood.build(), paintMat({ roughness: 0.9 })); woodMesh.castShadow = true; woodMesh.receiveShadow = true; rig.add(woodMesh);

    // sail + pennant (flutter in the vertex shader; the leading edge is pinned by aSway = 0)
    const sailGeo = loftGeo(12, 12, (a, b) => {
        // triangle between mast head, yard end and the boom foot; a = along the yard, b = down
        const tipZ = -6.0 - 25 * a, tipY = BOAT_DECK_Y + 41 - 24 * a * 0.85;
        const x = Math.sin(b * Math.PI) * 1.6 * (1 - a * 0.4) * 0.6;
        return [x, lerp(tipY, BOAT_DECK_Y + 6 + 5 * a, b), lerp(tipZ, -6.0 - 8 * a, b * 0.6)];
    });
    const sw = new Float32Array(sailGeo.getAttribute('position').count), su = sailGeo.getAttribute('uv');
    for (let i = 0; i < sw.length; i++) sw[i] = Math.min(1, (su.getX(i) * 0.9 + su.getY(i) * 0.4)) * 0.9;
    sailGeo.setAttribute('aSway', new THREE.BufferAttribute(sw, 1));
    const sail = new THREE.Mesh(sailGeo, swayMaterial(new THREE.MeshStandardMaterial({ map: sailTexture(), roughness: 0.95, side: THREE.DoubleSide }), 1.1, 1.6, 'sail'));
    sail.castShadow = true; rig.add(sail);
    const flagGeo = loftGeo(6, 2, (a, b) => [0, BOAT_DECK_Y + 41.2 + (b - 0.5) * 1.8 * (1 - a), -6.0 - a * 8]);
    const fw = new Float32Array(flagGeo.getAttribute('position').count), fu = flagGeo.getAttribute('uv'); for (let i = 0; i < fw.length; i++) fw[i] = fu.getX(i) * 1.5;
    flagGeo.setAttribute('aSway', new THREE.BufferAttribute(fw, 1));
    const flag = new THREE.Mesh(flagGeo, swayMaterial(new THREE.MeshStandardMaterial({ color: 0x23a7a0, emissive: 0x0b3a38, roughness: 0.9, side: THREE.DoubleSide }), 1.4, 4.0, 'flag')); rig.add(flag);

    // lights you can see: bow lantern, cabin windows, running lights (emissive materials; the point lights are tiny and cheap)
    const lampMat = new THREE.MeshBasicMaterial({ color: 0xffc46a }), glassMat = new THREE.MeshBasicMaterial({ color: 0xffb455 });
    const lantern = new THREE.Mesh(new THREE.SphereGeometry(0.75, 8, 6), lampMat); lantern.position.set(0, hullSheer(1) + 5.6, HULL_L + 0.1); rig.add(lantern);
    const lanternLight = new THREE.PointLight(0xffb866, 1.2, 70, 2); lanternLight.position.copy(lantern.position); rig.add(lanternLight);
    for (const sd of [-1, 1]) { const w = new THREE.Mesh(new THREE.PlaneGeometry(2.0, 1.2), glassMat); w.position.set(sd * 4.33, BOAT_DECK_Y + 3.0, -12.4); w.rotation.y = sd * Math.PI / 2; rig.add(w); }
    const cabinLight = new THREE.PointLight(0xffa455, 1.0, 50, 2); cabinLight.position.set(0, BOAT_DECK_Y + 3.4, -12.4); rig.add(cabinLight);
    const portMat = new THREE.MeshBasicMaterial({ color: 0xff4a3a }), stbdMat = new THREE.MeshBasicMaterial({ color: 0x3aff8a });
    const pl = new THREE.Mesh(new THREE.SphereGeometry(0.35, 6, 5), portMat), sl = new THREE.Mesh(new THREE.SphereGeometry(0.35, 6, 5), stbdMat);
    pl.position.set(-hullHalfW(0.7 / 1) * 0.0 - 4.2, hullSheer(0.25) + 0.9, 4.5); sl.position.set(4.2, hullSheer(0.25) + 0.9, 4.5); rig.add(pl, sl);

    // THE DRIVE: piezo-quartz crystals in a brass-and-wood cradle at the stern, glowing, with cables to the cabin
    const drive = new THREE.Group(); drive.position.set(0, BOAT_DECK_Y, -HULL_L + 3.2); rig.add(drive);
    const cradle = new GB(13); cradle.box(5.2, 1.0, 3.4, { p: [0, 0.5, 0], c: dark, c2: mid }); cradle.box(5.6, 0.4, 3.8, { p: [0, 1.15, 0], c: brass });
    for (const sd of [-1, 1]) { cradle.box(0.5, 3.0, 0.5, { p: [sd * 2.4, 2.2, 1.4], c: brass }); cradle.box(0.5, 3.0, 0.5, { p: [sd * 2.4, 2.2, -1.4], c: brass }); }
    cradle.tor(2.7, 0.22, { p: [0, 3.0, 0], r: [Math.PI / 2, 0, 0], c: brass }, 5, 18);
    drive.add(new THREE.Mesh(cradle.build(), paintMat({ roughness: 0.5, metalness: 0.5 })));
    const quartzMat = new THREE.MeshStandardMaterial({ color: 0x9fe8ff, emissive: 0x39b6ff, emissiveIntensity: 1.6, roughness: 0.15, metalness: 0.1, transparent: true, opacity: 0.92, flatShading: true });
    const crystals = [[0, 0, 4.4, 0, 0, 0.95], [-1.1, 0.5, 3.2, 0.25, 0.3, 0.7], [1.2, -0.3, 3.4, -0.3, 0.2, 0.75], [0.3, 1.0, 2.6, 0.1, -0.4, 0.55], [-0.6, -1.0, 2.8, 0.35, 0.1, 0.6]];
    const qGroup = new THREE.Group(); qGroup.position.y = 2.0; drive.add(qGroup);
    crystals.forEach(([x, z, h, rx, rz, rad]) => {
        const body = new THREE.Mesh(new THREE.CylinderGeometry(rad * 0.8, rad, h, 6), quartzMat), tip = new THREE.Mesh(new THREE.ConeGeometry(rad * 0.8, h * 0.4, 6), quartzMat);
        const g = new THREE.Group(); body.position.y = h / 2; tip.position.y = h + h * 0.2; g.add(body, tip); g.position.set(x, 0, z); g.rotation.set(rx, 0, rz); qGroup.add(g);
    });
    const driveLight = new THREE.PointLight(0x4cc0ff, 2.2, 90, 2); driveLight.position.set(0, 5, 0); drive.add(driveLight);
    anim.push((t) => { const p = 0.5 + 0.5 * Math.sin(t * 1.7); quartzMat.emissiveIntensity = 1.3 + 0.7 * p; driveLight.intensity = 1.8 + 0.9 * p; lanternLight.intensity = 1.1 + 0.15 * Math.sin(t * 7.3) * Math.sin(t * 2.9); qGroup.rotation.y = t * 0.15; });

    root.userData.rig = rig; root.userData.length = HULL_L * 2; root.userData.lanternLight = lanternLight; root.userData.cabinLight = cabinLight; root.userData.driveLight = driveLight;
    root.userData.update = (t) => { for (const f of anim) f(t); };
    return root;
}
