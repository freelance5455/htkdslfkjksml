# v53 - cities that grow on the land (NOT run in a browser: no three.js / GPU in the authoring environment; everything below was verified headless)

## The big find: every rotated street and building was drawn MIRRORED
city_core.js built footprints / streets / doors with yaw = direction (cos, sin) in plan (x, z), but the instance matrix used three.js' Ry, which maps +x to (cos, -sin).
Any street or building not axis-aligned was drawn mirrored about its own position (diagonal streets ran across their own nodes, buildings did not line up with streets).
Fixed in writeM (now Ry(-yaw)*Rz(pitch)*Rx(roll); pitch tilts the long axis, roll banks). This alone explains much of the "weird valley of shapes".

## Terrain: the city adapts to the land (valley_sites.js)
- No more stamped bowl, no added walls, no carved pass. shapeSite() MEASURES the natural ground (60-unit height grid) and derives the footprint:
  dense reach `ft[64]` follows ridges/spurs/gullies and stops at cliffs (slope limit per site 0.62-0.92, max ~280 units above the hub), hillside belt `ww[64]`.
- The ONLY terrain change: inside the footprint the ground is pulled 60% toward a smoothed copy of itself (bumps out, slopes stay) and the hub square is levelled.
  Measured: mean ground change 1-4 units (v52 moved hundreds), hub square 3-20 units.
- Hub = the gentlest ground near the footprint centroid. Gate = a slope-aware walk out to lower ground (`passPts`), used by city_core and city_roads.
- Site finder scores enclosure, relief (some steepness wanted) and buildable share instead of "flat circle"; ~10% cheaper (no ray scans).
- API unchanged (valleyHeight, cityWeight, clearHere, floorRadius, rimRadius, ValleyField); new fields sg/sgN/sgStep/passPts/meanSlope.

## City generator rewrite (city_core.js)
- Streets follow the slope: climbing spokes with switchbacks, contour streets at fixed height steps, stairways between levels, retaining-wall thickness under every street.
- Buildings built INTO the slope (body at mid height of the footprint, foundation block to the lowest ground). Checked against the exact terrain: 0 hovering buildings.
- Vertical density: 3-14 storeys everywhere, 14-36 storey towers in 3-6 clusters, stepped crowns, cantilevered floors, rooftop shacks/tanks/antennas/dishes/laundry/gardens,
  AC boxes, balconies, neon signs, awnings, pipes, scaffolding, overhead wires. Up to ~4200 buildings, ~15-40k pieces per city, still a handful of instanced meshes.
- Scrap bridges (see below), 2 new palettes (concrete, rustbelt), taller hub landmarks, scrap barricade at the gate.
- New piece category `baseBox` (foundations, bridge frames, abutments) drawn in the MID LOD too, so buildings never hover at distance.

## Bridges
- Building-to-building: wall to wall at a floor both buildings have, deck level taken from the tier that exists at that height, never through another building, never into the ground.
- Street-to-street across real gullies (chosen BEFORE buildings, corridor reserved, added to the nav graph so drones cross them).
- Each bridge: frame, mismatched planks, truss, posts, rails, rope, tarps, brackets, guy wires, lantern, trestle legs where the ground is far below.

## Drones (city_sim.js)
- Own lane beside the street centre line (right-hand traffic), own standing spot, hard body separation (6.2 units), queueing behind a drone in front.
- Every stop picks a new errand (other workplace, plaza, shop, bridge/lookout, a friend, a random corner); awake drones start scattered over the whole town.
- Heap A* with spatial-hash nearest node. Cargo haulers on roads get lanes too. 64 drones per city (was 48), 96 residents.
- tests/test_sim2.mjs, same city: body overlap 0.306% -> 0.000% of pair samples, walking 58% -> 80%, more ground covered.

## Other
- Window shader: faint floor banding. Terrain tint under cities lighter (0.7 -> 0.4).
- Tests: test_city / test_shape updated, new test_sim2.mjs (+ tests/old_sim.mjs, the v52 sim for comparison). All pass.
- Not touched: empire / night / wild drones in game.js.
- Saved games: sites, valleys and cities change shape (the economy state still loads).
