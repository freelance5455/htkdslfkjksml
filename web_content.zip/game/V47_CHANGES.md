# v47 - drone movement, mobile dialogue taps, taller cities

(The previous v47 zip only had the debug teleport + mountain changes from V46_CHANGES.md; this build adds the rest and replaces it.)

## Mobile: dialogue / trade buttons did nothing (game.js)
- Cause: the game's document-level touch handlers call preventDefault() on every touch that isn't on a whitelisted UI element, which also cancels the
  browser's tap -> click. #cityPanel (speech options, trade) and #cityPrompt were not on the whitelist, so taps on "Tell me about the moon" etc. never became clicks.
- Fix: both are now whitelisted in handleTouchStart and handleTouchMove.

## Drones piling up / standing still (city_sim.js)
- Causes: only 3 plaza gathering nodes, jobs map onto a handful of work nodes, working drones only rotated on the spot, and a drone that stopped to
  chat in the middle of a route never resumed it (it stayed idle where it stopped).
- Now: 11 plaza spots; every awake drone strolls 1-3 nodes around its spot every few seconds and drifts back when >25 units away; interrupted routes resume;
  soft separation keeps drones ~1.8 units apart.

## Cities (city_core.js)
- Ordinary buildings 1.3x taller; skyline hub up to 95-175 (was 70-130); more towers (threshold sk 0.28 -> 0.22).
- Tighter street frontage gaps and setbacks, more infill attempts with smaller lots, max 3400 buildings (was 2600).
- Measured over the 32 sites of seed 424242: 1175 -> 1222 buildings average. The valley floor was already nearly full (about 80% of infill attempts were
  rejected for overlap), so the change you will notice is mainly height. For a bigger count the lots themselves would have to get smaller.
- Not checked in a browser.
