// ocean_surface.js - v109 OCEAN OVERHAUL, part 1: the sea surface.
//
// What this replaces: a flat 512x512 plane with three summed sines (in LOCAL coordinates, so the swell travelled with the player and
// never matched the JS boat-float twin), one tint and a fresnel sparkle.
//
// What it is now:
//  * Sharp-crested, broad-trough swell trains in WORLD coordinates. The vertex shader and the JS twin (oceanHeight / oceanGrad) are
//    generated from the same table (OCEAN_LONG), so the boat rides exactly the water you see.
//  * A radial mesh: dense under the camera, sparse at the horizon (the old plane had ~120 unit spacing everywhere).
//  * Analytic normals, plus four fine chop trains that exist only in the fragment shader (they carry the glitter and the paint texture).
//  * A shore-depth map (ShoreMap) sampled from the real terrain around the player: turquoise shallows, deep indigo, wash lines and foam at
//    the beach, whitecaps on crests (more in a storm).
//  * A proper view from below: Snell's window and the dark mirror outside it.
// The painterly look is the game's own post pass (v95); the water just gives it bold shapes to chew on (hard-edged foam blotches,
// stepped wash bands).
import * as THREE from 'three';

// ---- wave table. a = travel direction (rad), L = wavelength (world units), A = amplitude (units), p = phase offset -------------------
export const OCEAN_G = 190;                       // "gravity" in world units: omega = sqrt(g k). Gives the old swell its ~1.5 rad/s.
export const OCEAN_LONG = [
    { a: 0.35, L: 520, A: 3.2, p: 0.0 },
    { a: -0.55, L: 330, A: 2.0, p: 1.7 },
    { a: 1.10, L: 240, A: 1.2, p: 4.1 },
];
// fine trains: fragment shader only (slope carriers; their amplitude is a fiction chosen for the slope, they never move the surface)
export const OCEAN_FINE = [
    { a: 0.10, L: 120, A: 1.6, p: 0.5 },
    { a: 0.90, L: 70, A: 1.0, p: 2.3 },
    { a: -0.80, L: 38, A: 0.6, p: 5.1 },
    { a: 2.00, L: 21, A: 0.3, p: 3.3 },
];
const SHAPE_Q = 1.8, SHAPE_MEAN = 0.40, SHAPE_GAIN = 1.9;   // crest profile (pow-sharpened): same numbers are written into the GLSL

function prep(list) {
    return list.map(w => { const k = 2 * Math.PI / w.L; return { dx: Math.cos(w.a), dz: Math.sin(w.a), k, om: Math.sqrt(OCEAN_G * k), A: w.A, p: w.p }; });
}
const LONG = prep(OCEAN_LONG);

function shape(th) { const sh = 0.5 + 0.5 * Math.sin(th); return (Math.pow(sh, SHAPE_Q) - SHAPE_MEAN) * SHAPE_GAIN; }
function shapeD(th) { const sh = 0.5 + 0.5 * Math.sin(th); return SHAPE_GAIN * SHAPE_Q * 0.5 * Math.pow(sh, SHAPE_Q - 1) * Math.cos(th); }

// JS twin of the vertex shader. amp = storm multiplier (the game's stormAmp), t = globalTime.
export function oceanHeight(x, z, t, amp) {
    let h = 0;
    for (let i = 0; i < LONG.length; i++) { const w = LONG[i]; h += w.A * shape(w.k * (w.dx * x + w.dz * z) - w.om * t + w.p); }
    return h * amp;
}
// d(height)/dx, d(height)/dz
const _g = [0, 0];
export function oceanGrad(x, z, t, amp, out) {
    let gx = 0, gz = 0;
    for (let i = 0; i < LONG.length; i++) {
        const w = LONG[i], d = w.A * w.k * shapeD(w.k * (w.dx * x + w.dz * z) - w.om * t + w.p);
        gx += w.dx * d; gz += w.dz * d;
    }
    const o = out || _g; o[0] = gx * amp; o[1] = gz * amp; return o;
}

// ---- mesh -----------------------------------------------------------------------------------------------------------------------
// Pure array builder (so it can be unit-tested without THREE). Rings are spaced ~linear near the centre then geometric.
export function buildOceanMeshArrays(outerR, segs) {
    segs = segs || 144;
    const radii = [];
    let r = 6;
    while (r < 72) { radii.push(r); r += 6; }                 // 6..72 every 6 units: resolves the 240-unit swell ~40x
    const g = 1.052;
    while (r < outerR) { radii.push(r); r *= g; }
    radii.push(outerR);
    const nRing = radii.length;
    const pos = new Float32Array((1 + nRing * segs) * 3);
    let o = 3;                                                 // vertex 0 = centre (0,0,0)
    for (let i = 0; i < nRing; i++) for (let s = 0; s < segs; s++) {
        const th = (s / segs) * Math.PI * 2; pos[o++] = Math.cos(th) * radii[i]; pos[o++] = 0; pos[o++] = Math.sin(th) * radii[i];
    }
    const idx = [];
    const vid = (ring, s) => 1 + ring * segs + (s % segs);
    for (let s = 0; s < segs; s++) idx.push(0, vid(0, s + 1), vid(0, s));              // centre fan, wound to face +Y
    for (let i = 0; i < nRing - 1; i++) for (let s = 0; s < segs; s++) {
        const a0 = vid(i, s), a1 = vid(i, s + 1), b0 = vid(i + 1, s), b1 = vid(i + 1, s + 1);
        idx.push(a0, a1, b0, a1, b1, b0);
    }
    return { positions: pos, indices: (pos.length / 3 > 65535) ? new Uint32Array(idx) : new Uint16Array(idx), ringCount: nRing };
}
export function buildOceanGeometry(outerR, segs) {
    const m = buildOceanMeshArrays(outerR, segs);
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(m.positions, 3));
    geo.setIndex(new THREE.BufferAttribute(m.indices, 1));
    geo.boundingSphere = new THREE.Sphere(new THREE.Vector3(0, 0, 0), outerR * 1.2);
    return geo;
}

// ---- GLSL ------------------------------------------------------------------------------------------------------------------------
const f6 = (x) => { const s = x.toFixed(6); return s; };
function waveConsts(prefix, list) {
    let s = '';
    prep(list).forEach((w, i) => {
        s += `const vec2 ${prefix}D${i} = vec2(${f6(w.dx)}, ${f6(w.dz)});\n`
          + `const float ${prefix}K${i} = ${f6(w.k)};\nconst float ${prefix}W${i} = ${f6(w.om)};\n`
          + `const float ${prefix}A${i} = ${f6(w.A)};\nconst float ${prefix}P${i} = ${f6(w.p)};\n`;
    });
    return s;
}
function glslShared() {
    let s = waveConsts('OL_', OCEAN_LONG) + waveConsts('OF_', OCEAN_FINE);
    s += `
float owShape(float th) { float sh = 0.5 + 0.5 * sin(th); return (pow(sh, ${f6(SHAPE_Q)}) - ${f6(SHAPE_MEAN)}) * ${f6(SHAPE_GAIN)}; }
float owShapeD(float th) { float sh = 0.5 + 0.5 * sin(th); return ${f6(SHAPE_GAIN * SHAPE_Q * 0.5)} * pow(sh, ${f6(SHAPE_Q - 1)}) * cos(th); }
float owHeightLong(vec2 p, float t) {
    float h = 0.0;
`;
    OCEAN_LONG.forEach((w, i) => { s += `    h += OL_A${i} * owShape(OL_K${i} * dot(OL_D${i}, p) - OL_W${i} * t + OL_P${i});\n`; });
    s += `    return h;
}
vec2 owGradLong(vec2 p, float t) {
    vec2 g = vec2(0.0);
`;
    OCEAN_LONG.forEach((w, i) => { s += `    g += OL_D${i} * (OL_A${i} * OL_K${i} * owShapeD(OL_K${i} * dot(OL_D${i}, p) - OL_W${i} * t + OL_P${i}));\n`; });
    s += `    return g;
}
vec2 owGradFine(vec2 p, float t) {
    vec2 g = vec2(0.0);
`;
    OCEAN_FINE.forEach((w, i) => { s += `    g += OF_D${i} * (OF_A${i} * OF_K${i} * owShapeD(OF_K${i} * dot(OF_D${i}, p) - OF_W${i} * t + OF_P${i}));\n`; });
    s += `    return g;
}
`;
    return s;
}

const VERT_COMMON = `
// OCEANFX:water
uniform float time;
uniform float stormAmp;
varying vec3 vWaterWorldPos;
varying float vWaveH;
` + glslShared();

const FRAG_COMMON = `
// OCEANFX:water
uniform float time;
uniform float stormAmp;
uniform vec3 sunColor;
uniform vec3 uSunDir;
uniform vec3 uSkyHorizon;
uniform vec3 uSkyZenith;
uniform vec3 uCShallow;
uniform vec3 uCMid;
uniform vec3 uCDeep;
uniform float uLight;
uniform float uSunVis;
uniform sampler2D uShore;
uniform vec3 uShoreInfo;
varying vec3 vWaterWorldPos;
varying float vWaveH;
` + glslShared() + `
float owHash(vec2 p) { p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }
float owNoise(vec2 p) {
    vec2 i = floor(p); vec2 f = fract(p); f = f * f * (3.0 - 2.0 * f);
    float a = owHash(i); float b = owHash(i + vec2(1.0, 0.0)); float c = owHash(i + vec2(0.0, 1.0)); float d = owHash(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}
float owDepth(vec2 p) {
    vec2 uv = (p - uShoreInfo.xy) / (uShoreInfo.z * 2.0) + 0.5;
    if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) return 900.0;
    return texture2D(uShore, uv).r * 600.0 - 60.0;
}
`;

const SKY_FALLBACK = null;

// Builds the onBeforeCompile for the water material. `ctx.uniforms` is filled with the live uniform objects.
export function makeWaterPatch(ctx) {
    return function (shader) {
        const u = ctx.uniforms;
        shader.uniforms.time = u.time; shader.uniforms.stormAmp = u.stormAmp; shader.uniforms.sunColor = u.sunColor;
        shader.uniforms.uSunDir = u.uSunDir; shader.uniforms.uSkyHorizon = u.uSkyHorizon; shader.uniforms.uSkyZenith = u.uSkyZenith;
        shader.uniforms.uCShallow = u.uCShallow; shader.uniforms.uCMid = u.uCMid; shader.uniforms.uCDeep = u.uCDeep;
        shader.uniforms.uLight = u.uLight; shader.uniforms.uSunVis = u.uSunVis; shader.uniforms.uShore = u.uShore; shader.uniforms.uShoreInfo = u.uShoreInfo;
        ctx.shader = shader;

        shader.vertexShader = shader.vertexShader
            .replace('#include <common>', '#include <common>\n' + VERT_COMMON)
            .replace('#include <beginnormal_vertex>', `#include <beginnormal_vertex>
    vec3 owWP = (modelMatrix * vec4(position, 1.0)).xyz;
    float owFade = 1.0 - smoothstep(1500.0, 3400.0, distance(owWP.xz, cameraPosition.xz));
    float owAmp = stormAmp * owFade;
    vec2 owG = owGradLong(owWP.xz, time) * owAmp;
    objectNormal = normalize(vec3(-owG.x, 1.0, -owG.y));`)
            .replace('#include <begin_vertex>', `#include <begin_vertex>
    transformed.y += owHeightLong(owWP.xz, time) * owAmp;
    vWaveH = transformed.y;
    vWaterWorldPos = (modelMatrix * vec4(transformed, 1.0)).xyz;`);

        shader.fragmentShader = shader.fragmentShader
            .replace('#include <common>', '#include <common>\n' + FRAG_COMMON)
            .replace('#include <color_fragment>', `#include <color_fragment>
    float owD = owDepth(vWaterWorldPos.xz);
    {
        float dS = smoothstep(0.0, 70.0, owD);
        float dD = smoothstep(40.0, 520.0, owD);
        vec3 wc = mix(uCShallow, uCMid, dS);
        wc = mix(wc, uCDeep, dD);
        float crest = clamp(vWaveH / (5.0 * stormAmp), 0.0, 1.0);
        wc += vec3(0.010, 0.060, 0.050) * crest * (0.4 + 0.6 * uLight);
        diffuseColor.rgb = wc;
        diffuseColor.a = mix(0.58, 0.94, dS);
    }`)
            .replace('#include <normal_fragment_maps>', `#include <normal_fragment_maps>
    vec3 owN = vec3(0.0, 1.0, 0.0);
    {
        float owDist = distance(vWaterWorldPos.xz, cameraPosition.xz);
        float longFade = 1.0 - smoothstep(1500.0, 3400.0, owDist);
        float fineFade = 1.0 - smoothstep(250.0, 2400.0, owDist);
        vec2 gg = owGradLong(vWaterWorldPos.xz, time) * (stormAmp * longFade) + owGradFine(vWaterWorldPos.xz, time) * (fineFade * (0.65 + 0.35 * stormAmp));
        owN = normalize(vec3(-gg.x, 1.0, -gg.y));
        normal = normalize((viewMatrix * vec4(owN, 0.0)).xyz) * faceDirection;
    }`)
            .replace('#include <opaque_fragment>', `
    {
        vec2 owP = vWaterWorldPos.xz;
        vec3 owV = normalize(cameraPosition - vWaterWorldPos);
        float owLight = clamp(uLight, 0.0, 1.0);
        if (gl_FrontFacing) {
            // sky on the water
            vec3 owR = reflect(-owV, owN);
            float fr = pow(1.0 - clamp(dot(owV, owN), 0.0, 1.0), 4.0);
            vec3 skyRefl = mix(uSkyHorizon, uSkyZenith, pow(clamp(owR.y, 0.0, 1.0), 0.6)) * (0.30 + 0.70 * owLight);
            outgoingLight = mix(outgoingLight, skyRefl, fr * 0.78);
            // sun glitter: hard little diamonds (reads as brush flecks after the painterly pass) + a broad sheen
            float sd = max(dot(owR, uSunDir), 0.0);
            float glit = smoothstep(0.9960, 0.9993, sd);
            float sheen = pow(sd, 36.0) * 0.30;
            outgoingLight += sunColor * (glit * 2.6 + sheen) * uSunVis;
            // foam: crest whitecaps (more in a storm), wash bands on the shore, hard painted edges
            float n1 = owNoise(owP * 0.045 + vec2(time * 0.05, -time * 0.03));
            float n2 = owNoise(owP * 0.16 - vec2(time * 0.11, time * 0.07));
            float blotch = n1 * 0.65 + n2 * 0.35;
            float thr = 4.3 - 1.4 * clamp((stormAmp - 1.0) / 1.6, 0.0, 1.0);
            float crestFoam = smoothstep(thr, thr + 1.1, vWaveH / max(stormAmp, 0.5) * 1.0 + (blotch - 0.5) * 2.6);
            float shoreMask = 1.0 - smoothstep(0.0, 34.0, owD);
            float band = 0.5 + 0.5 * sin(owD * 0.30 - time * 1.5 + blotch * 3.0);
            float shoreFoam = shoreMask * smoothstep(0.55, 0.62, band * (0.55 + 0.45 * blotch) + (1.0 - smoothstep(0.0, 6.0, owD)) * 0.5);
            float foam = clamp(max(crestFoam * 0.9, shoreFoam), 0.0, 1.0);
            foam = smoothstep(0.35, 0.55, foam);
            vec3 foamCol = vec3(0.90, 0.96, 1.0) * (0.34 + 0.66 * owLight);
            outgoingLight = mix(outgoingLight, foamCol, foam * 0.92);
            diffuseColor.a = max(diffuseColor.a, foam);
        } else {
            // looking up at the surface from below: Snell's window, mirror outside it
            float ca = abs(owV.y);
            float win = smoothstep(0.56, 0.72, ca);
            vec3 under = mix(vec3(0.010, 0.050, 0.085), vec3(0.030, 0.150, 0.230), 0.5 + 0.5 * owN.y) * (0.25 + 0.75 * owLight);
            vec3 bright = (uSkyHorizon * 0.55 + uSkyZenith * 0.45) * (0.45 + 0.55 * owLight) + sunColor * pow(max(dot(-owV, uSunDir), 0.0), 8.0) * 0.5 * uSunVis;
            outgoingLight = mix(under, bright, win * 0.85);
            diffuseColor.a = 0.9;
        }
    }
#include <opaque_fragment>`);
    };
}

export function makeWaterUniforms() {
    return {
        time: { value: 0 }, stormAmp: { value: 1 }, sunColor: { value: new THREE.Color(0xfff6dc) },
        uSunDir: { value: new THREE.Vector3(0, 1, 0) },
        uSkyHorizon: { value: new THREE.Color(0.55, 0.70, 0.85) }, uSkyZenith: { value: new THREE.Color(0.20, 0.38, 0.70) },
        uCShallow: { value: new THREE.Color().setRGB(0.24, 0.72, 0.68, THREE.SRGBColorSpace) },
        uCMid: { value: new THREE.Color().setRGB(0.10, 0.40, 0.52, THREE.SRGBColorSpace) },
        uCDeep: { value: new THREE.Color().setRGB(0.03, 0.14, 0.30, THREE.SRGBColorSpace) },
        uLight: { value: 1 }, uSunVis: { value: 1 },
        uShore: { value: null }, uShoreInfo: { value: new THREE.Vector3(0, 0, 1) },
    };
}

// ---- shore depth map ----------------------------------------------------------------------------------------------------------
// A (N x N) map of "metres under the waterline" (negative = land) around the player, built incrementally from the real terrain so the
// frame never stalls: `rowsPerFrame` rows per update. R channel = (depth + 60) / 600. The finished map is swapped in whole, together with
// its centre, so the shader never sees a half-built map.
export class ShoreMap {
    constructor(opt) {
        opt = opt || {};
        this.N = opt.N || 112; this.half = opt.half || 1400; this.waterLevel = opt.waterLevel || 0;
        this.rowsPerFrame = opt.rowsPerFrame || 1; this.rebuildDist = opt.rebuildDist || 380;
        const n = this.N * this.N * 4;
        this.data = new Uint8Array(n); this.stage = new Uint8Array(n);
        for (let i = 0; i < n; i += 4) { this.data[i] = 255; this.data[i + 1] = 255; this.data[i + 2] = 255; this.data[i + 3] = 255; }
        this.tex = new THREE.DataTexture(this.data, this.N, this.N, THREE.RGBAFormat, THREE.UnsignedByteType);
        this.tex.magFilter = THREE.LinearFilter; this.tex.minFilter = THREE.LinearFilter;
        this.tex.wrapS = this.tex.wrapT = THREE.ClampToEdgeWrapper || THREE.ClampToEdgeWrapping;
        this.tex.needsUpdate = true;
        this.cx = 1e9; this.cz = 1e9;       // centre of the map currently shown (nothing yet)
        this.job = null;                    // { cx, cz, row }
        this.allDeep = false;
    }
    encode(h) { const d = this.waterLevel - h; return Math.max(0, Math.min(255, Math.round((d + 60) / 600 * 255))); }
    // heightFn(x, z) -> terrain height. px,pz = player/camera position.
    update(px, pz, heightFn) {
        if (!this.job) {
            const dx = px - this.cx, dz = pz - this.cz;
            const need = (dx * dx + dz * dz) > this.rebuildDist * this.rebuildDist;
            if (!need) return;
            if (this.allDeep && (dx * dx + dz * dz) < 900 * 900) return;   // open sea: nothing to see, don't pay for it
            this.job = { cx: px, cz: pz, row: 0, minD: 1e9 };
        }
        const J = this.job, N = this.N, cell = (this.half * 2) / N, t0 = (typeof performance !== 'undefined') ? performance.now() : 0;
        // v111: hard time budget (the terrain sampler can be slow on weak devices); the map just takes more frames to finish
        this.skip = (this.skip || 0) > 0 ? this.skip - 1 : 0; if (this.skip > 0) return;
        for (let r = 0; r < this.rowsPerFrame && J.row < N; r++, J.row++) {
            const z = J.cz - this.half + (J.row + 0.5) * cell;
            for (let i = 0; i < N; i++) {
                const x = J.cx - this.half + (i + 0.5) * cell;
                const v = this.encode(heightFn(x, z));
                const o = (J.row * N + i) * 4; this.stage[o] = v; this.stage[o + 1] = v; this.stage[o + 2] = v; this.stage[o + 3] = 255;
                const d = (v / 255) * 600 - 60; if (d < J.minD) J.minD = d;
            }
        }
        if (t0) { const ms = performance.now() - t0; this.lastMs = ms; if (ms > 3) this.skip = Math.min(20, Math.ceil(ms / 3)); }   // a slow row: rest for a few frames
        if (J.row >= N) {
            this.data.set(this.stage); this.tex.needsUpdate = true;
            this.cx = J.cx; this.cz = J.cz; this.allDeep = J.minD > 150; this.job = null;
        }
    }
    info(out) { out.set(this.cx, this.cz, this.half); return out; }
    // forget everything (teleports): the next update restarts at the new position
    reset() { this.cx = 1e9; this.cz = 1e9; this.job = null; this.allDeep = false; }
}

// ---- shader failure safety net ---------------------------------------------------------------------------------------------------
// This build could not be run on a GPU where it was written. If any ocean shader fails to compile, the material that owns it drops its
// custom shader (renders with plain three.js lighting) and the console says why, instead of the whole sea vanishing.
const _fallbacks = new Map(), _fired = new Set();
export function registerShaderFallback(marker, fn) { _fallbacks.set(marker, fn); }
export function installShaderFallback(renderer) {
    if (!renderer || !renderer.debug) return;
    const prev = renderer.debug.onShaderError;
    renderer.debug.onShaderError = function (gl, program, vs, fs) {
        try {
            const vsrc = gl.getShaderSource(vs) || '', fsrc = gl.getShaderSource(fs) || '', src = vsrc + fsrc;
            for (const [marker, fn] of _fallbacks) {
                if (src.indexOf(marker) >= 0 && !_fired.has(marker)) {
                    _fired.add(marker);
                    console.error('[ocean] shader "' + marker + '" failed to compile; falling back to the plain material.\n' + (gl.getShaderInfoLog(fs) || '') + '\n' + (gl.getShaderInfoLog(vs) || ''));
                    try { fn(); } catch (e) { console.error('[ocean] fallback failed', e); }
                }
            }
        } catch (e) { /* ignore */ }
        if (typeof prev === 'function') prev(gl, program, vs, fs);
    };
}
export function dropCustomShader(material, key) {
    material.onBeforeCompile = function () { };
    material.customProgramCacheKey = function () { return 'ocean-plain-' + key; };
    material.needsUpdate = true;
}
