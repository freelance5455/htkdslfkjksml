# v44 - terrain relief, denser forests, fast trees

## Terrain (terrain_core.js)
- New eroded-relief layer (slope-damped ridged noise, 1-9 km): spurs, saddles, valleys; slow "highland" field varies amplitude regionally.
- Rolling relief now reaches the lowlands/spawn plains (old code faded all hills below ~100 units height). Fades out at the beach so coasts stay clean.
- Bolder ground texture (250-unit mound octave), micro relief fades near the shoreline.
- Mountains: ranges start nearer the coast, wider coverage, slightly higher uplift (tails kept in check: p99 slope ~2.2).
- Bug fix: rare NaN height (pow of slightly negative noise in karst/pillar terrain) that could punch holes in the mesh.

## Trees / props (chunk_core.js, game.js)
- Tree chance 0.045 -> 0.05-0.085 by biome, modulated by groves/clearings noise (0.35x..1.8x). More ground cover in forests.
- Scatter tiers: 0 (<1.3 chunks) full + grass; 1 half density; 2 quarter density, bigger trees, out to ~5.6 chunks. Tiers 1-2 use low-poly trees, no shadows.
- Worker cost: cheap pre-roll skips height/gradient work for empty points; fast integer hash replaces fract(sin()).
- Scheduling: nearby tree jobs go to workers before far terrain jobs; trees are kept when a chunk is rebuilt (LOD change / edge stitch) instead of vanishing and re-scattering; loading screen also waits for the 3x3 chunks' trees.
- Spawn flatness tolerance 2.5 -> 3.5.
