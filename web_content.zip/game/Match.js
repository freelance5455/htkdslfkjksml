import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { Suspense, useEffect, useMemo, useRef, useState } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { Physics, BallCollider, RigidBody } from '@react-three/rapier';
import { Line } from '@react-three/drei';
import { Vector3, Plane, Raycaster, Vector2 } from 'three';
import { ArrowLeft, Pause, Play } from 'lucide-react';
import { calculateMatchCoins, teamChemistry, useGame } from '../store.js';
import { rankName } from '../data/players.js';
import { MatchEngine } from './engine.js';
import { Stadium, FootballAvatar } from './Stadium.js';
import ClubBadge from '../ui/ClubBadge.js';
function MatchCamera({ engine }) {
    const { camera, gl } = useThree();
    const ray = useMemo(() => new Raycaster(), []), pointer = useMemo(() => new Vector2(), []), plane = useMemo(() => new Plane(new Vector3(0, 1, 0), 0), []);
    const hit = useMemo(() => new Vector3(), []);
    const smooth = useRef(new Vector3(0, 29, 49));
    const look = useRef(new Vector3(0, 1.4, 0));
    useEffect(() => { const move = (e) => { const rect = gl.domElement.getBoundingClientRect(); pointer.set((e.clientX - rect.left) / rect.width * 2 - 1, -(e.clientY - rect.top) / rect.height * 2 + 1); ray.setFromCamera(pointer, camera); if (ray.ray.intersectPlane(plane, hit))
        engine.setAim(hit.x, hit.z); }; gl.domElement.addEventListener('pointermove', move); gl.domElement.addEventListener('pointerdown', move); return () => { gl.domElement.removeEventListener('pointermove', move); gl.domElement.removeEventListener('pointerdown', move); }; }, [camera, engine, gl, ray, pointer, plane, hit]);
    const vel = useRef(new Vector3()), target = useRef(new Vector3());
    useFrame((_, rawDt) => {
        const dt = Math.min(rawDt, .05), mode = engine.settings.camera;
        const height = mode === 'Wide' ? 46 : mode === 'Close' ? 25 : 31, away = mode === 'Wide' ? 61 : mode === 'Close' ? 37 : 49;
        // A damped camera pivot with a velocity cap avoids jerky changes on passes,
        // abrupt holder switches, and replay transitions. No per-frame allocations.
        // Close camera translates down the near touchline with play, maintaining
        // enough horizontal separation to avoid the overhead angle near that sideline.
        const ballZ = engine.ballPos[2];
        const farSide = Math.max(0, Math.min(1, (-ballZ - 4) / 30));
        const cameraZ = mode === 'Close' ? Math.max(37, Math.min(59, 46 + ballZ * .35)) : Math.max(4, Math.min(15, ballZ * .22)) + away - 14 + farSide * 8;
        const zoomHeight = mode === 'Close' ? height : height + farSide * 4;
        target.current.set(Math.max(-38, Math.min(38, engine.ballPos[0] * .76)), zoomHeight, cameraZ);
        const dx = target.current.x - smooth.current.x, dy = target.current.y - smooth.current.y, dz = target.current.z - smooth.current.z;
        const k = 2.4, damping = 3.4;
        vel.current.x += (dx * k - vel.current.x * damping) * dt;
        vel.current.y += (dy * k - vel.current.y * damping) * dt;
        vel.current.z += (dz * k - vel.current.z * damping) * dt;
        vel.current.clampLength(0, 9.5);
        smooth.current.addScaledVector(vel.current, dt);
        const a = 1 - Math.exp(-dt * 1.7);
        look.current.x += (Math.max(-40, Math.min(40, engine.ballPos[0] * .79)) - look.current.x) * a;
        look.current.y += (1.4 - look.current.y) * a;
        look.current.z += (engine.ballPos[2] * (mode === 'Close' ? .65 : .62) - look.current.z) * a;
        camera.position.copy(smooth.current);
        camera.lookAt(look.current);
    });
    return null;
}
function FrameTicker({ engine, notify }) { const n = useRef(0); useFrame((_, dt) => { const delta = Math.min(.04, dt); engine.simulate(delta); n.current += delta; if (n.current > .1) {
    n.current = 0;
    notify(engine.view());
} }); return null; }
function Ball({ engine }) {
    const ref = useRef(null);
    useEffect(() => { if (ref.current)
        engine.attachBall(ref.current); }, [engine]);
    return _jsxs(RigidBody, { ref: ref, position: [0, .275, 0], colliders: false, mass: .43, restitution: .58, friction: .54, linearDamping: .15, angularDamping: .25, ccd: true, children: [_jsx(BallCollider, { args: [.275] }), _jsxs("mesh", { castShadow: true, children: [_jsx("sphereGeometry", { args: [.275, 24, 16] }), _jsx("meshStandardMaterial", { color: "#f7f7ef", roughness: .42 })] }), _jsxs("mesh", { scale: 1.003, rotation: [.3, .1, 0], children: [_jsx("icosahedronGeometry", { args: [.273, 1] }), _jsx("meshBasicMaterial", { color: "#223c39", wireframe: true, transparent: true, opacity: .32 })] })] });
}
function BallGroundMarker({ engine }) { const marker = useRef(null); useFrame(() => { if (marker.current) {
    marker.current.position.set(engine.ballPos[0], .055, engine.ballPos[2]);
    marker.current.visible = engine.phase !== 'full';
} }); return _jsxs("group", { ref: marker, rotation: [-Math.PI / 2, 0, 0], children: [_jsxs("mesh", { children: [_jsx("ringGeometry", { args: [1.29, 1.65, 48] }), _jsx("meshBasicMaterial", { color: "#ffdf25", transparent: true, opacity: .9, depthWrite: false })] }), _jsxs("mesh", { children: [_jsx("circleGeometry", { args: [1.29, 48] }), _jsx("meshBasicMaterial", { color: "#ffe34b", transparent: true, opacity: .095, depthWrite: false })] })] }); }
function GameWorld({ engine, notify, frozen, venue }) {
    return _jsxs(_Fragment, { children: [_jsx("color", { attach: "background", args: [venue.time === 'Night' ? '#101b35' : venue.time === 'Evening' ? '#e4a47a' : venue.time === 'Morning' ? '#c9e2ed' : '#a8c6bf'] }), _jsx("fog", { attach: "fog", args: [venue.time === 'Night' ? '#26344b' : '#a8c6bf', 145, 270] }), _jsx(Suspense, { fallback: null, children: _jsxs(Physics, { gravity: [0, -9.81, 0], timeStep: 1 / 60, paused: frozen, children: [_jsx(Stadium, { graphics: engine.settings.graphics, variant: venue.stadium, time: venue.time }), _jsx(Ball, { engine: engine })] }) }), _jsx(BallGroundMarker, { engine: engine }), _jsx(WeatherParticles, { weather: venue.weather }), engine.people.map((p, i) => _jsx(FootballAvatar, { p: p, engine: engine }, `${p.side}-${i}`)), _jsx(FrameTicker, { engine: engine, notify: notify }), _jsx(MatchCamera, { engine: engine }), _jsx(AimLine, { engine: engine })] });
}
function AimLine({ engine }) { const player = engine.people[engine.selected]; const visible = engine.holder === engine.selected && engine.phase === 'playing'; return visible ? _jsx(Line, { points: [[player.x, .19, player.z], [engine.aiming.x, .19, engine.aiming.z]], color: "#e5f2a3", lineWidth: 1.4, dashed: true, dashSize: .55, gapSize: .4, transparent: true, opacity: .8 }) : null; }
function MiniMap({ engine }) { return _jsxs("div", { className: "mini-map", children: [_jsx("div", { className: "mini-half" }), _jsx("div", { className: "mini-circle" }), engine.people.map((p, i) => _jsx("span", { className: `map-dot ${p.side === 0 ? 'mine' : 'theirs'}`, style: { left: `${(p.x + 52.5) / 105 * 100}%`, top: `${(p.z + 34) / 68 * 100}%` } }, i)), _jsx("span", { className: "map-ball", style: { left: `${(engine.ballPos[0] + 52.5) / 105 * 100}%`, top: `${(engine.ballPos[2] + 34) / 68 * 100}%` } })] }); }
function minutes(t) { const m = Math.floor(t / 60), s = Math.floor(t % 60); return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`; }
function Stat({ label, left, right }) { return _jsxs("div", { className: "match-stat", children: [_jsx("b", { children: left }), _jsx("span", { children: label }), _jsx("b", { children: right })] }); }
function GoalOverlay({ view }) { return _jsxs("div", { className: "goal-hud", children: [_jsx("div", { children: "GOAL" }), _jsxs("strong", { children: [view.score[0], " : ", view.score[1]] }), _jsx("small", { children: "REPLAY" })] }); }
function endSound(type) { const AudioCtor = window.AudioContext; if (!AudioCtor)
    return; const ctx = new AudioCtor(); const tone = (freq, start, dur, vol) => { const osc = ctx.createOscillator(), gain = ctx.createGain(); osc.frequency.value = freq; osc.type = 'sine'; gain.gain.setValueAtTime(vol, ctx.currentTime + start); gain.gain.exponentialRampToValueAtTime(.001, ctx.currentTime + start + dur); osc.connect(gain); gain.connect(ctx.destination); osc.start(ctx.currentTime + start); osc.stop(ctx.currentTime + start + dur); }; if (type === 'goal') {
    tone(490, 0, .15, .06);
    tone(720, .15, .25, .07);
}
else if (type === 'whistle') {
    tone(1200, 0, .16, .026);
}
else
    tone(140, 0, .085, .025); setTimeout(() => { void ctx.close(); }, 800); }
function MobileControls({ engine }) {
    const [isTouch, setIsTouch] = useState(() => typeof window !== 'undefined' && window.matchMedia('(pointer: coarse)').matches);
    const [origin, setOrigin] = useState({ x: 86, y: 103 });
    const [stick, setStick] = useState({ x: 0, y: 0 });
    const active = useRef(null);
    const center = useRef({ x: 86, y: 0 });
    const sprintId = useRef(null);
    const shotId = useRef(null);
    useEffect(() => { const f = () => setIsTouch(window.matchMedia('(pointer: coarse)').matches); window.addEventListener('resize', f); return () => window.removeEventListener('resize', f); }, []);
    useEffect(() => () => { engine.setJoystick(0, 0); engine.keyUp('TouchSprint'); }, [engine]);
    if (!isTouch)
        return null;
    const begin = (e) => { if (active.current !== null)
        return; e.preventDefault(); active.current = e.pointerId; e.currentTarget.setPointerCapture(e.pointerId); const anchor = { x: 86, y: window.innerHeight - 103 }; const d = Math.hypot(e.clientX - anchor.x, e.clientY - anchor.y); const c = d > 19 ? { x: e.clientX, y: e.clientY } : anchor; center.current = c; setOrigin({ x: c.x, y: window.innerHeight - c.y }); move(e, c); };
    const move = (e, c = center.current) => { if (active.current !== e.pointerId)
        return; e.preventDefault(); const dx = e.clientX - c.x, dy = e.clientY - c.y, d = Math.max(1, Math.hypot(dx, dy)), scale = Math.min(1, 57 / d); const x = dx * scale, y = dy * scale; setStick({ x, y }); engine.setJoystick(x / 57, y / 57); };
    const end = (e) => { if (active.current !== e.pointerId)
        return; active.current = null; engine.setJoystick(0, 0); setStick({ x: 0, y: 0 }); setOrigin({ x: 86, y: 103 }); };
    return _jsxs("div", { className: "mobile-game-controls", children: [_jsx("div", { className: "joystick-capture", onPointerDown: begin, onPointerMove: move, onPointerUp: end, onPointerCancel: end, "aria-label": "Movement joystick" }), _jsx("div", { className: "joystick-base", style: { left: origin.x, bottom: origin.y }, children: _jsx("div", { className: "joystick-thumb", style: { transform: `translate(${stick.x}px,${stick.y}px)` } }) }), _jsxs("div", { className: "mobile-actions", children: [_jsx("button", { className: "mobile-action shoot-action", onPointerDown: e => { e.preventDefault(); shotId.current = e.pointerId; e.currentTarget.setPointerCapture(e.pointerId); engine.phase === 'restart' ? engine.cornerDown() : engine.touchShotDown(); }, onPointerUp: e => { if (shotId.current === e.pointerId) {
                            shotId.current = null;
                            engine.phase === 'restart' ? engine.cornerUp() : engine.touchShotUp();
                        } }, onPointerCancel: () => { shotId.current = null; engine.cancelShot(); }, children: "PASS / SHOOT" }), _jsx("button", { className: "mobile-action skill-action", onPointerDown: e => { e.preventDefault(); engine.actionSkill(); }, children: "SKILL / SWITCH" }), _jsx("button", { className: "mobile-action sprint-action", onPointerDown: e => { e.preventDefault(); sprintId.current = e.pointerId; e.currentTarget.setPointerCapture(e.pointerId); engine.keyDown('TouchSprint'); engine.actionSprint(); }, onPointerUp: e => { if (sprintId.current === e.pointerId) {
                            sprintId.current = null;
                            engine.keyUp('TouchSprint');
                        } }, onPointerCancel: () => { sprintId.current = null; engine.keyUp('TouchSprint'); }, children: "SPRINT / TACKLE" })] }), _jsx("span", { className: "touch-tip", children: "Tap for a firm ground pass \u00B7 Hold for a lofted shot" })] });
}
function WeatherParticles({ weather }) { const positions = useMemo(() => { let seed = 117; const a = new Float32Array(450 * 3); for (let i = 0; i < a.length; i++) {
    seed = (seed * 1664525 + 1013904223) >>> 0;
    a[i] = i % 3 === 0 ? (seed / 4294967296 - .5) * 145 : i % 3 === 1 ? (seed / 4294967296) * 32 : (seed / 4294967296 - .5) * 100;
} return a; }, []); const ref = useRef(null); useFrame((_, dt) => { if (!ref.current)
    return; const a = ref.current.geometry.attributes.position; for (let i = 0; i < a.count; i++) {
    let y = a.getY(i) - dt * (weather === 'Rain' ? 18 : 3.2);
    if (y < .2)
        y += 30;
    a.setY(i, y);
} a.needsUpdate = true; }); if (weather === 'Sunny')
    return null; return _jsxs("points", { ref: ref, children: [_jsx("bufferGeometry", { children: _jsx("bufferAttribute", { attach: "attributes-position", args: [positions, 3] }) }), _jsx("pointsMaterial", { color: weather === 'Snow' ? '#ffffff' : '#b7d9ed', size: weather === 'Snow' ? .18 : .075, transparent: true, opacity: .65, depthWrite: false })] }); }
export default function Match({ onExit, mode = 'ranked' }) {
    const game = useGame();
    const engine = useMemo(() => new MatchEngine(game.squad, game.training, game.formation, mode === 'ranked' ? game.rank : 5, game.settings, game.tactic, teamChemistry(game.squad, game.formation), game.captain), []);
    const [venue] = useState(() => ({ stadium: Math.floor(Math.random() * 3), time: ['Morning', 'Day', 'Evening', 'Night'][Math.floor(Math.random() * 4)], weather: ['Sunny', 'Rain', 'Snow'][Math.floor(Math.random() * 3)] }));
    const [opponentBadge] = useState(() => Math.floor(Math.random() * 20));
    const [view, setView] = useState(engine.view());
    const [confirmed, setConfirmed] = useState(false);
    const [walkout, setWalkout] = useState(true);
    const [resultShown, setResultShown] = useState(false);
    useEffect(() => { const timer = window.setTimeout(() => { setWalkout(false); engine.start(); setView(engine.view()); }, 5000); return () => window.clearTimeout(timer); }, [engine]);
    useEffect(() => {
        engine.onWhistle = type => { if (game.settings.sound)
            try {
                endSound(type);
            }
            catch { } ; };
        const down = (e) => { if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code))
            e.preventDefault(); if (!e.repeat)
            engine.keyDown(e.code); };
        const up = (e) => engine.keyUp(e.code);
        const clickDown = (e) => { if (e.pointerType === 'mouse' && e.button === 0 && e.target instanceof HTMLCanvasElement)
            engine.phase === 'restart' ? engine.cornerDown() : engine.mouseDown(); };
        const clickUp = (e) => { if (e.pointerType === 'mouse')
            engine.phase === 'restart' ? engine.cornerUp() : engine.mouseUp(); };
        const blur = () => { engine.held.clear(); if (engine.phase === 'playing')
            engine.togglePause(); };
        window.addEventListener('keydown', down);
        window.addEventListener('keyup', up);
        window.addEventListener('pointerdown', clickDown);
        window.addEventListener('pointerup', clickUp);
        window.addEventListener('pointercancel', clickUp);
        window.addEventListener('blur', blur);
        return () => { window.removeEventListener('keydown', down); window.removeEventListener('keyup', up); window.removeEventListener('pointerdown', clickDown); window.removeEventListener('pointerup', clickUp); window.removeEventListener('pointercancel', clickUp); window.removeEventListener('blur', blur); };
    }, [engine]);
    const finalize = () => { if (resultShown)
        return; game.endMatch({ home: engine.score[0], away: engine.score[1], stats: engine.stats, scorers: engine.goalScorers, mode }); setResultShown(true); onExit(); };
    const player = engine.people[view.selected], gameOver = view.phase === 'full';
    return _jsxs("div", { className: "match-wrapper", children: [_jsx(Canvas, { shadows: game.settings.graphics === 'High', dpr: [1, game.settings.graphics === 'Low' ? 1 : game.settings.graphics === 'Medium' ? 1.25 : 1.5], camera: { position: [0, 29, 49], fov: 53, near: .2, far: 350 }, gl: { antialias: true, powerPreference: 'high-performance' }, children: _jsx(GameWorld, { engine: engine, notify: setView, venue: venue, frozen: view.phase === 'paused' || view.phase === 'half' || view.phase === 'full' }) }), _jsxs("div", { className: "scoreboard", children: [_jsx("span", { className: "score-clock", children: minutes(view.clock) }), _jsxs("span", { className: "score-side", children: [_jsx(ClubBadge, { id: game.clubBadge, size: 22 }), _jsx("strong", { title: game.clubName, children: game.clubName.slice(0, 3).toUpperCase() }), " ", _jsx("span", { className: "score-num", children: view.score[0] })] }), _jsx("span", { className: "score-divider", children: ":" }), _jsxs("span", { className: "score-side", children: [_jsx("span", { className: "score-num", children: view.score[1] }), " ", _jsx("strong", { children: "CPU" }), _jsx(ClubBadge, { id: opponentBadge, size: 22 })] }), _jsx("span", { className: "score-period", children: view.half === 1 ? '1ST' : '2ND' })] }), _jsx(MobileControls, { engine: engine }), _jsx("button", { className: "match-pause", onClick: () => { engine.togglePause(); setView(engine.view()); }, "aria-label": "Pause match", children: _jsx(Pause, { size: 18 }) }), game.settings.minimap && _jsx(MiniMap, { engine: engine }), _jsxs("div", { className: "match-bottom", children: [_jsxs("div", { className: "controlled-info", children: [_jsx("div", { className: "jersey-square", children: player.card.position }), _jsxs("div", { children: [_jsx("b", { children: player.card.name }), _jsxs("small", { children: [player.card.overall, " OVR \u00B7 ", Math.round(player.stamina), "% stamina"] }), _jsx("div", { className: "stamina-bar", children: _jsx("i", { style: { width: `${player.stamina}%` } }) })] })] }), _jsx("div", { className: "controls-reminder", children: "WASD Move\u3000\u00B7\u3000Shift Sprint / Tackle\u3000\u00B7\u3000Click Ground Pass\u3000\u00B7\u3000Hold Click Lofted Shot\u3000\u00B7\u3000Space Skill / Tackle\u3000\u00B7\u3000E Switch" })] }), view.charge > 0 && _jsxs("div", { className: "power-holder", children: [_jsx("span", { children: "SHOT POWER" }), _jsx("div", { className: "power-track", children: _jsx("div", { style: { width: `${Math.min(100, view.charge / 1.7 * 100)}%` } }) })] }), view.noticeUntil > 0 && (view.phase === 'playing' || view.phase === 'kickoff' || view.phase === 'restart') && _jsx("div", { className: "match-notice", children: view.notice }), view.phase === 'goal' && _jsx(GoalOverlay, { view: view }), walkout && _jsx("div", { className: "match-modal-shade", children: _jsxs("div", { className: "walkout-card", children: [_jsx("span", { className: "eyebrow", children: mode === 'ranked' ? 'RANKED MATCH' : 'FRIENDLY MATCH' }), _jsxs("h1", { children: [_jsx(ClubBadge, { id: game.clubBadge, size: 47 }), " ", game.clubName, " ", _jsx("span", { children: "vs" }), " ", _jsx(ClubBadge, { id: opponentBadge, size: 47 }), " Challengers"] }), _jsxs("p", { children: [mode === 'ranked' ? rankName(game.rank) : 'Unranked', " \u00B7 11v11 \u00B7 ", game.formation, " \u00B7 ", ['Emerald Arena', 'Harbor Park', 'Summit Stadium'][venue.stadium], " \u00B7 ", venue.time, " \u00B7 ", venue.weather] }), _jsxs("div", { className: "lineup-comparison", children: [_jsxs("div", { children: [_jsx("h3", { children: game.clubName }), engine.people.slice(0, 11).map(p => _jsxs("div", { children: [_jsx("small", { children: p.card.position }), _jsx("span", { children: p.card.name }), _jsx("b", { children: p.card.overall })] }, p.slot))] }), _jsxs("div", { children: [_jsxs("h3", { children: [_jsx(ClubBadge, { id: opponentBadge, size: 24 }), " CHALLENGERS"] }), engine.people.slice(11).map(p => _jsxs("div", { children: [_jsx("small", { children: p.card.position }), _jsx("span", { children: p.card.name }), _jsx("b", { children: p.card.overall })] }, p.slot))] })] }), _jsx("div", { className: "lineup-countdown", children: "Kickoff automatically in 5 seconds" })] }) }), (view.phase === 'paused' || view.phase === 'half' || gameOver) && !walkout && _jsx("div", { className: "match-modal-shade", children: _jsx("div", { className: "match-dialog", children: view.phase === 'paused' ? _jsxs(_Fragment, { children: [_jsx("span", { className: "eyebrow", children: "MATCH PAUSED" }), _jsx("h2", { children: "Pause menu" }), _jsxs("p", { children: ["Current score: ", view.score[0], " - ", view.score[1]] }), _jsxs("button", { className: "btn-primary block", onClick: () => { engine.togglePause(); setView(engine.view()); }, children: [_jsx(Play, { size: 16 }), " Resume match"] }), _jsxs("button", { className: "btn-secondary block", onClick: () => setConfirmed(true), children: [_jsx(ArrowLeft, { size: 16 }), " Leave match"] }), confirmed && _jsxs("div", { className: "confirm-leave", children: [_jsx("p", { children: "Leaving now forfeits the match and counts as a ranked loss." }), _jsx("button", { className: "btn-danger", onClick: () => { game.endMatch({ home: engine.score[0], away: Math.max(engine.score[0] + 1, engine.score[1]), stats: engine.stats, scorers: engine.goalScorers, mode }); onExit(); }, children: "Forfeit & leave" }), _jsx("button", { className: "btn-text", onClick: () => setConfirmed(false), children: "Cancel" })] })] }) :
                        _jsxs(_Fragment, { children: [_jsx("span", { className: "eyebrow", children: gameOver ? 'FULL TIME' : 'HALF TIME' }), _jsxs("h2", { children: [view.score[0], " ", _jsx("span", { className: "light", children: "-" }), " ", view.score[1]] }), _jsxs("p", { children: [game.clubName, " vs Challengers"] }), _jsxs("div", { className: "match-stats-list", children: [_jsx(Stat, { label: "Possession", left: `${view.stats.possession}%`, right: `${100 - view.stats.possession}%` }), _jsx(Stat, { label: "Shots", left: view.stats.shots, right: view.stats.shotsAgainst }), _jsx(Stat, { label: "Passes", left: view.stats.passes, right: view.stats.passesAgainst }), _jsx(Stat, { label: "Saves", left: view.stats.saves, right: engine.statSaves[1] })] }), gameOver && _jsxs("div", { className: "ratings-list", children: [_jsx("h3", { children: "Top performers" }), view.playerRatings.slice(0, 3).map(p => _jsxs("div", { children: [_jsx("span", { children: p.name }), _jsx("b", { children: p.rating.toFixed(1) })] }, p.name)), view.goalScorers.length > 0 && _jsxs("p", { children: ["Goals: ", view.goalScorers.join(' · ')] })] }), gameOver ? _jsxs(_Fragment, { children: [_jsxs("div", { className: "full-reward", children: [view.score[0] > view.score[1] ? 'VICTORY' : view.score[0] < view.score[1] ? 'DEFEAT' : 'DRAW', " \u00B7 ", rankName(game.rank), " \u00B7 ", calculateMatchCoins(view.score[0], view.score[1], view.stats, mode) >= 0 ? '+' : '', calculateMatchCoins(view.score[0], view.score[1], view.stats, mode).toLocaleString(), " coins"] }), _jsx("button", { className: "btn-primary block", onClick: finalize, children: "Collect rewards & return to lobby" })] }) : _jsxs("button", { className: "btn-primary block", onClick: () => { engine.secondHalf(); setView(engine.view()); }, children: ["Start second half ", _jsx(Play, { size: 16 })] })] }) }) })] });
}
