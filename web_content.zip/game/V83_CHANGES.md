# v83 - the Freefall cinematic can no longer be skipped; pause, leave, and restart on rejoin
`freefall_cinematic.js` and `game.js`. Both pass a syntax check, and a headless test (`tests/ff_cine_pause_test.py`) confirms: double-tap opens the prompt, the scene stays active while paused, Keep watching resumes, Space no longer ends it, and Leave fires the leave callback. The full save -> quit -> rejoin path through the game has NOT been run in a browser yet.

## What changed
- **No skipping.** Double-tap and Space no longer skip. The hint under the picture now says "double-tap to pause".
- **Pause.** Double-tap (or Escape on desktop) freezes the picture and the timeline, suspends the synth, and pauses the voice where the browser allows it. A prompt asks: "Leave the game? When you come back, this scene starts over from the beginning." Buttons: Keep watching / Leave. Resuming continues from exactly where it stopped (the clock is shifted by the paused time).
- **Leave** saves and returns to the main menu (the same save + reload as "Return to Main Menu").
- **Rejoin.** The save now holds `freefallPending` (1 = the Vale version, 2 = the fallback launch). It is set just before the cinematic starts and cleared at the last black, when the player is teleported back to the shelter. If a save is loaded with it set, the cinematic plays again from the top about 1.5 s after loading, then the rest runs as normal (back at the shelter, the AI's "We're down" line, the log entry).
- `runPhase4Aftermath` now ends by calling the new `runFreefallSequence(vale)`, which holds the cinematic and everything after it.
