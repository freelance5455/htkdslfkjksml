// leviathan_sky.js - the view outside the Leviathan's windows (shader source only, so a test page can compile and render it without three.js).
//
// One sphere that follows the camera. Three looks, blended by uClear (0..1):
//   immersed (0): inside the storm. Layered, lit, swirling cloud slabs with an orange glow below, lightning that lights the cloud from within
//                 and a visible bolt, and now and then a rift that opens toward the moon so it can be glimpsed through the cloud.
//   emerged  (1): above the clouds. A cloud sea raymarched as a height field (towers, valleys, a slow cyclone, shadows, haze), a violet-to-amber
//                 sky with cirrus and a horizon cloud bank, the sun, stars, and the Earth-like moon (continents, oceans, ice, cloud bands,
//                 sun glint, an atmosphere rim) with cloud puffs drifting across it.
// The sphere is drawn AFTER the opaque geometry with the depth test on, so only the pixels actually seen through windows and the breach are shaded.
export const STORM_VS = `// LEVFX:storm
varying vec3 vDir;
void main() { vDir = position; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`;

export const STORM_FS = `// LEVFX:storm
varying vec3 vDir;
uniform float uTime; uniform float uFlash; uniform vec3 uFlashDir; uniform float uSeed; uniform float uClear; uniform float uSteps;
uniform vec3 uSunDir; uniform vec3 uMoonDir;

float hash13(vec3 p) { p = fract(p * 0.3183099 + 0.1); p *= 17.0; return fract(p.x * p.y * p.z * (p.x + p.y + p.z)); }
float vnoise(vec3 x) {
    vec3 i = floor(x); vec3 f = fract(x); f = f * f * (3.0 - 2.0 * f);
    return mix(mix(mix(hash13(i), hash13(i + vec3(1.0, 0.0, 0.0)), f.x), mix(hash13(i + vec3(0.0, 1.0, 0.0)), hash13(i + vec3(1.0, 1.0, 0.0)), f.x), f.y),
               mix(mix(hash13(i + vec3(0.0, 0.0, 1.0)), hash13(i + vec3(1.0, 0.0, 1.0)), f.x), mix(hash13(i + vec3(0.0, 1.0, 1.0)), hash13(i + vec3(1.0, 1.0, 1.0)), f.x), f.y), f.z);
}
float fbm3(vec3 p) { float a = 0.5; float s = 0.0; for (int i = 0; i < 3; i++) { s += a * vnoise(p); p = p * 2.02 + vec3(1.7, 9.2, 3.1); a *= 0.5; } return s / 0.875; }
float fbm4(vec3 p) { float a = 0.5; float s = 0.0; for (int i = 0; i < 4; i++) { s += a * vnoise(p); p = p * 2.02 + vec3(1.7, 9.2, 3.1); a *= 0.5; } return s / 0.9375; }
float h21(vec2 p) { p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }
float n2(vec2 x) {
    vec2 i = floor(x); vec2 f = fract(x); f = f * f * (3.0 - 2.0 * f);
    return mix(mix(h21(i), h21(i + vec2(1.0, 0.0)), f.x), mix(h21(i + vec2(0.0, 1.0)), h21(i + vec2(1.0, 1.0)), f.x), f.y);
}
float f2a(vec2 p) { float s = 0.5 * n2(p); p = p * 2.03 + vec2(17.1, 9.3); s += 0.25 * n2(p); return s / 0.75; }
float f2b(vec2 p) { float s = 0.5 * n2(p); p = p * 2.03 + vec2(17.1, 9.3); s += 0.25 * n2(p); p = p * 2.03 + vec2(17.1, 9.3); s += 0.125 * n2(p); return s / 0.875; }
float f2c(vec2 p) { float s = 0.5 * n2(p); p = p * 2.03 + vec2(17.1, 9.3); s += 0.25 * n2(p); p = p * 2.03 + vec2(17.1, 9.3); s += 0.125 * n2(p); p = p * 2.03 + vec2(17.1, 9.3); s += 0.0625 * n2(p); return s / 0.9375; }

float bl2(vec2 p) { float s = 0.5 * abs(2.0 * n2(p) - 1.0); p = p * 2.03 + vec2(17.1, 9.3); s += 0.25 * abs(2.0 * n2(p) - 1.0); return s / 0.75; }
float bl3(vec2 p) { float s = 0.5 * abs(2.0 * n2(p) - 1.0); p = p * 2.03 + vec2(17.1, 9.3); s += 0.25 * abs(2.0 * n2(p) - 1.0); p = p * 2.03 + vec2(17.1, 9.3); s += 0.125 * abs(2.0 * n2(p) - 1.0); return s / 0.875; }

// ---------------------------------------------------------------------------------------------------------------------------------
// the Earth-like moon: continents, oceans, ice caps, cloud bands, sun glint, thin blue air
// ---------------------------------------------------------------------------------------------------------------------------------
const float MOON_R = 0.034;
vec3 moonDisc(vec3 d, vec3 base) {
    vec3 m = normalize(uMoonDir);
    if (dot(d, m) < 0.85) return base;
    vec3 T = normalize(cross(m, vec3(0.0, 1.0, 0.0))); vec3 B = cross(T, m);
    vec2 uv = vec2(dot(d, T), dot(d, B)) / MOON_R;
    float rr = length(uv);
    if (rr > 2.2) return base;
    vec3 sunV = normalize(uSunDir);
    vec3 L = normalize(vec3(dot(sunV, T), dot(sunV, B), dot(sunV, m)));
    float lim = clamp(1.0 - 0.0, 0.0, 1.0);
    // halo of air beyond the limb
    float halo = exp(-max(rr - 1.0, 0.0) * 9.0) * smoothstep(0.7, 1.0, rr);
    vec3 col = base + vec3(0.30, 0.55, 1.00) * halo * (0.10 + 0.40 * clamp(dot(normalize(vec3(uv, 0.2)), L) + 0.4, 0.0, 1.0));
    if (rr < 1.0) {
        vec3 n = vec3(uv, sqrt(max(1.0 - rr * rr, 0.0)));
        float a = uTime * 0.012;
        vec3 sp = vec3(n.x * cos(a) + n.z * sin(a), n.y, -n.x * sin(a) + n.z * cos(a));
        vec3 warp = vec3(fbm3(sp * 2.6 + 4.0), fbm3(sp * 2.6 + 9.0), fbm3(sp * 2.6 + 15.0));
        float w = fbm4(sp * 2.1 + warp * 0.9);
        float land = smoothstep(0.505, 0.535, w);
        float lat = abs(sp.y);
        float ice = smoothstep(0.80, 0.92, lat + 0.16 * (fbm3(sp * 7.0) - 0.5));
        float dry = fbm3(sp * 3.4 + 11.0) + (1.0 - lat) * 0.1;
        vec3 landCol = mix(vec3(0.10, 0.26, 0.09), vec3(0.50, 0.40, 0.24), smoothstep(0.42, 0.62, dry));
        landCol = mix(landCol, vec3(0.62, 0.58, 0.52), smoothstep(0.60, 0.72, w));
        vec3 oceanCol = mix(vec3(0.015, 0.07, 0.22), vec3(0.06, 0.34, 0.50), smoothstep(0.40, 0.505, w));
        vec3 surf = mix(oceanCol, landCol, land);
        surf = mix(surf, vec3(0.92, 0.95, 1.0), ice);
        float cw = fbm4(sp * 3.0 + vec3(uTime * 0.006, 0.0, 0.0) + warp * 1.2);
        float cmask = smoothstep(0.50, 0.72, cw);
        float ndl = dot(n, L);
        float soft = smoothstep(-0.06, 0.45, ndl);
        vec3 V = vec3(0.0, 0.0, 1.0); vec3 H = normalize(L + V);
        float glint = pow(max(dot(n, H), 0.0), 110.0) * (1.0 - land) * (1.0 - cmask) * (1.0 - ice) * 1.8;
        surf = mix(surf, vec3(0.97, 0.97, 1.0), cmask * 0.88);
        float rim = pow(1.0 - n.z, 3.0);
        vec3 atm = vec3(0.30, 0.58, 1.00) * rim * (0.15 + 1.3 * soft) + vec3(1.00, 0.45, 0.16) * rim * smoothstep(-0.25, 0.05, ndl) * (1.0 - soft) * 0.8;
        vec3 moon = surf * (0.02 + 1.35 * soft) * vec3(1.0, 0.93, 0.85) + vec3(1.0, 0.85, 0.65) * glint + atm;
        col = mix(col, moon, 1.0 - smoothstep(0.965, 1.0, rr));
    }
    return col;
}

// ---------------------------------------------------------------------------------------------------------------------------------
// the open sky
// ---------------------------------------------------------------------------------------------------------------------------------
vec3 skyBase(vec3 d) {
    float h = clamp(d.y, 0.0, 1.0);
    vec3 horiz = vec3(1.10, 0.48, 0.14); vec3 low = vec3(0.70, 0.22, 0.16); vec3 mid = vec3(0.24, 0.10, 0.24); vec3 zen = vec3(0.012, 0.022, 0.085);
    vec3 col = mix(horiz, low, smoothstep(0.0, 0.06, h));
    col = mix(col, mid, smoothstep(0.04, 0.26, h));
    col = mix(col, zen, smoothstep(0.20, 0.85, h));
    vec3 sv = normalize(uSunDir); float s = max(dot(d, sv), 0.0);
    col += vec3(1.0, 0.55, 0.20) * (pow(s, 6.0) * 0.16 + pow(s, 30.0) * 0.45 + pow(s, 300.0) * 2.6 + pow(s, 3000.0) * 12.0);
    float sg = hash13(floor(d * 300.0));
    col += vec3(0.80, 0.85, 1.00) * step(0.9993, sg) * smoothstep(0.25, 0.65, h) * 1.1;
    return col;
}
vec3 skyClouds(vec3 d, vec3 col) {
    vec3 sv = normalize(uSunDir); float sunAmt = max(dot(d, sv), 0.0);
    // high cirrus streaks, violet away from the sun and gold toward it
    vec2 q = d.xz / (max(d.y, 0.02) + 0.1) * 1.4 + vec2(uTime * 0.01, 0.0);
    float ci = smoothstep(0.52, 0.82, f2b(q * vec2(1.0, 3.2) + 3.0)) * smoothstep(0.02, 0.25, d.y) * 0.45;
    col = mix(col, mix(vec3(0.38, 0.18, 0.30), vec3(1.0, 0.58, 0.30), pow(sunAmt, 2.0) * 0.8 + 0.1), ci);
    // a bank of towering cloud along the horizon: flat bases, billowing tops, lit from the sun's side, dark where it faces away
    float prof = 1.0 - smoothstep(0.02, 0.34, d.y);
    float n = fbm4(vec3(d.x * 5.5, d.y * 12.0, d.z * 5.5) + vec3(uTime * 0.008, 0.0, 0.0));
    float field = n * 0.85 + prof * 0.45 - 0.12;
    float dens = smoothstep(0.50, 0.64, field);
    float edge = smoothstep(0.50, 0.64, field) - smoothstep(0.56, 0.74, field);
    float lightK = clamp(0.06 + 1.15 * pow(sunAmt, 1.6) + 0.30 * smoothstep(0.0, 0.28, d.y) * smoothstep(0.55, 0.30, n), 0.0, 1.0);
    vec3 bankCol = mix(vec3(0.07, 0.03, 0.06), vec3(0.95, 0.46, 0.22), lightK);
    bankCol += vec3(1.0, 0.70, 0.38) * edge * (0.15 + 1.1 * pow(sunAmt, 2.0));
    col = mix(col, bankCol, dens * 0.95 * (1.0 - smoothstep(0.30, 0.55, d.y)));
    // loose puffs that drift across the sky (and sometimes across the moon)
    float pf = smoothstep(0.58, 0.74, fbm3(d * 15.0 + vec3(uTime * 0.025, 0.0, 0.0)));
    float band = smoothstep(0.04, 0.12, d.y) * (1.0 - smoothstep(0.35, 0.60, d.y));
    col = mix(col, mix(vec3(0.16, 0.07, 0.13), vec3(1.0, 0.62, 0.36), lightK), pf * band * 0.85);
    return col;
}

// ---------------------------------------------------------------------------------------------------------------------------------
// the cloud sea below: a height field marched from above, lit by the low sun, with a slow cyclone
// ---------------------------------------------------------------------------------------------------------------------------------
vec2 swirlXZ(vec2 p) {
    vec2 c = vec2(1500.0, -2600.0); vec2 v = p - c; float r = length(v);
    float a = 1.5 * exp(-r / 2400.0) + uTime * 0.010 * exp(-r / 2600.0);
    float s = sin(a); float co = cos(a);
    return c + vec2(co * v.x - s * v.y, s * v.x + co * v.y);
}
float seaCheap(vec2 p) {
    p = swirlXZ(p) + vec2(uTime * 4.0, -uTime * 2.4);
    float base = f2b(p * 0.0030);
    float tower = smoothstep(0.50, 0.78, f2a(p * 0.0017 + 31.0));
    float lump = bl2(p * 0.0085 + 7.0);
    return max(95.0 * base * base + 55.0 * lump * (0.5 + 0.5 * base) + 200.0 * pow(tower, 1.5) - 20.0, 0.0);
}
float seaFull(vec2 p) {
    p = swirlXZ(p) + vec2(uTime * 4.0, -uTime * 2.4);
    float base = f2c(p * 0.0030);
    float tower = smoothstep(0.50, 0.78, f2b(p * 0.0017 + 31.0));
    float lump = bl3(p * 0.0085 + 7.0);
    float puff = bl3(p * 0.024 + 3.0);
    return max(95.0 * base * base + 55.0 * lump * (0.5 + 0.5 * base) + 28.0 * puff * (0.35 + 0.65 * smoothstep(0.1, 0.6, base)) + 200.0 * pow(tower, 1.5) * (0.8 + 0.2 * puff) - 20.0, 0.0);
}
vec3 seaColor(vec3 d) {
    vec3 ro = vec3(0.0, 800.0, 0.0);
    float ay = max(-d.y, 0.004);
    float t = (ro.y - 330.0) / ay;
    float tPrev = t;
    int steps = int(uSteps);
    float h = 0.0; vec3 pos = ro + d * t;
    for (int i = 0; i < 14; i++) {
        if (i >= steps || t > 16000.0) break;
        pos = ro + d * t;
        h = seaCheap(pos.xz);
        float dh = pos.y - h;
        if (dh < 2.0 + t * 0.0008) break;
        tPrev = t;
        t += max(3.0 + t * 0.012, dh * 0.6);
    }
    for (int j = 0; j < 4; j++) {   // bisect between the last two samples so the surface is smooth instead of stepped
        float tm = 0.5 * (tPrev + t);
        vec3 pm = ro + d * tm;
        if (pm.y - seaCheap(pm.xz) < 0.0) t = tm; else tPrev = tm;
    }
    pos = ro + d * t;
    h = seaFull(pos.xz);
    vec3 sun = normalize(uSunDir);
    vec3 n = vec3(0.0, 1.0, 0.0);
    if (t < 6000.0) {
        float e = 7.0;
        float hx = seaFull(pos.xz + vec2(e, 0.0)) - seaFull(pos.xz - vec2(e, 0.0));
        float hz = seaFull(pos.xz + vec2(0.0, e)) - seaFull(pos.xz - vec2(0.0, e));
        n = normalize(vec3(-hx, 2.0 * e, -hz));
    }
    float height01 = clamp(h / 300.0, 0.0, 1.0);
    n = normalize(mix(vec3(0.0, 1.0, 0.0), n, 0.8));
    float dif = clamp(dot(n, sun) * 0.5 + 0.5, 0.0, 1.0); dif = dif * dif * dif;
    float sh = 1.0;
    vec2 sdir = sun.xz / max(length(sun.xz), 0.05); float srise = sun.y / max(length(sun.xz), 0.05);
    for (int k = 1; k <= 4; k++) {
        float dist = float(k) * float(k) * 28.0;
        float over = seaCheap(pos.xz + sdir * dist) - (h + srise * dist);
        sh *= 1.0 - smoothstep(0.0, 34.0, over) * 0.45;
    }
    // soft, scattering cloud: cream where the sun hits, dusty lavender in the shade, never black
    vec3 shadeCol = vec3(0.13, 0.07, 0.15); vec3 litCol = vec3(1.35, 0.78, 0.46);
    vec3 col = mix(shadeCol, litCol, dif * sh);
    col *= mix(vec3(0.34, 0.26, 0.32), vec3(1.0, 0.96, 0.92), smoothstep(0.0, 0.50, height01));
    col += vec3(1.0, 0.62, 0.30) * pow(1.0 - n.y, 2.0) * dif * sh * 0.35;     // sunlit edges
    col *= 0.85 + 0.30 * smoothstep(0.3, 0.9, n.y);
    // holes in the deck show the glowing depths
    col = mix(col, mix(vec3(0.42, 0.06, 0.02), vec3(1.0, 0.34, 0.07), smoothstep(0.0, 16.0, h)) * 0.85, (1.0 - smoothstep(0.0, 18.0, h)) * 0.92);
    // lightning blooms inside the cloud tops
    float lp = smoothstep(0.42, 0.80, f2a(pos.xz * 0.0035 + uSeed * 13.0));
    col += vec3(0.70, 0.80, 1.00) * uFlash * lp * (1.2 - 0.7 * height01);
    float hz2 = 1.0 - exp(-t * 0.00011);
    return mix(col, vec3(0.92, 0.40, 0.17), clamp(hz2, 0.0, 1.0));
}

// ---------------------------------------------------------------------------------------------------------------------------------
// inside the storm: lit cloud slabs in depth, a glow below, lightning, and rifts toward the moon
// ---------------------------------------------------------------------------------------------------------------------------------
vec3 cloudWarp(vec3 p) {
    float t = uTime;
    return 0.55 * (vec3(vnoise(p * 0.8 + vec3(0.0, t * 0.05, 0.0)), vnoise(p * 0.8 + vec3(5.2, 1.3, t * 0.04)), vnoise(p * 0.8 + vec3(2.1, t * 0.03, 7.7))) - 0.5);
}
float cloudAt(vec3 q) { return fbm4(q * 1.25 + vec3(uTime * 0.03, 0.0, uTime * 0.02)); }
vec3 boltColor(vec3 d) {
    vec3 f = normalize(uFlashDir);
    float az = atan(d.z, d.x) - atan(f.z, f.x); az = mod(az + 3.14159265, 6.2831853) - 3.14159265;
    float cosEl = sqrt(max(1.0 - d.y * d.y, 0.0001));
    float x = az * cosEl;
    float y = d.y;
    float jag = 0.020 * sin(y * 31.0 + uSeed * 7.0) + 0.011 * sin(y * 83.0 + uSeed * 3.0) + 0.005 * sin(y * 171.0);
    float dist = abs(x - jag);
    float fork = abs(x - jag - 0.06 * (y - f.y + 0.1) - 0.012 * sin(y * 64.0)) + step(y, f.y - 0.05) * 1.0;
    float span = smoothstep(f.y - 0.55, f.y - 0.45, y) * (1.0 - smoothstep(f.y + 0.38, f.y + 0.46, y));
    float core = exp(-dist * 160.0) + 0.5 * exp(-fork * 200.0);
    float glow = exp(-dist * 18.0) * 0.35;
    return vec3(0.85, 0.90, 1.0) * (core + glow) * span;
}
vec3 immersed(vec3 d, float thin) {
    vec3 mdir = normalize(uMoonDir);
    float rift = smoothstep(0.55, 0.95, 0.5 + 0.5 * sin(uTime * 0.11 + 1.3)) * exp(-pow(acos(clamp(dot(d, mdir), -1.0, 1.0)), 2.0) / 0.10);
    vec3 glow = vec3(0.30, 0.095, 0.03) * (0.35 + 0.65 * (0.5 - 0.5 * d.y));
    vec3 bg = moonDisc(d, glow * 0.5);
    vec3 L = normalize(vec3(0.25, 0.85, -0.25));
    float dens0 = 1.0 - thin;
    vec3 acc = vec3(0.0); float trans = 1.0;
    for (int i = 0; i < 3; i++) {
        float fi = float(i) * 2.0;   // v114: 3 layers (was 6) spaced twice as far apart, to cut compile and draw cost
        float k = 1.0 + fi * 0.9;
        vec3 p = d * k * 1.5 + vec3(fi * 3.7, fi * 1.3, fi * 0.9);
        vec3 q = p + cloudWarp(p);
        float c = cloudAt(q);
        float c2 = cloudAt(q + L * 0.25);
        float dens = smoothstep(0.43, 0.63, c) * dens0 * (1.0 - rift * 0.95);
        float a = clamp(dens * 0.72, 0.0, 0.9);
        float lit = clamp((c - c2) * 7.0 + 0.45, 0.0, 1.0);        // cloud faces toward the light are brighter
        float down = clamp(0.5 - 0.5 * d.y, 0.0, 1.0);             // the glowing depths light everything from below
        float depthFade = 1.0 - 0.07 * fi;
        vec3 amb = vec3(0.030, 0.012, 0.009) + vec3(0.55, 0.19, 0.06) * down * down * smoothstep(0.40, 0.72, c);
        vec3 colSlab = amb * (0.5 + lit) + vec3(1.0, 0.50, 0.16) * pow(lit, 4.0) * (0.10 + 0.55 * down) * depthFade;
        float inner = uFlash * 0.5 * (0.4 + 0.9 * lit) * (0.35 + 0.65 * smoothstep(0.40, 0.70, c));
        colSlab += vec3(1.0, 0.80, 0.66) * inner * (0.30 + 0.70 * max(dot(d, normalize(uFlashDir)), 0.0));
        acc += trans * a * colSlab; trans *= (1.0 - a);
    }
    vec3 col = acc + trans * bg;
    col += boltColor(d) * uFlash * 1.2 * mix(1.0, 0.3, thin);
    return col;
}
vec3 emerged(vec3 d) {
    vec3 col;
    if (d.y < 0.0) col = seaColor(d);
    else { col = skyBase(d); col = moonDisc(d, col); col = skyClouds(d, col); }
    float band = 1.0 - smoothstep(0.0, 0.035, abs(d.y));
    return mix(col, vec3(1.0, 0.50, 0.20) * 0.8, band * 0.55);
}

void main() {
    vec3 d = normalize(vDir);
    float cl = clamp(uClear, 0.0, 1.0);
    vec3 col;
    if (cl < 0.001) col = immersed(d, 0.0);
    else if (cl > 0.999) col = emerged(d);
    else col = mix(immersed(d, cl), emerged(d), smoothstep(0.15, 0.90, cl));
    gl_FragColor = vec4(col, 1.0);
}`;
