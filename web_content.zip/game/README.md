# RPG Sprite Game (HTML5 Canvas, mobile touch)

## اجرا / How to run
Open `index.html` in a browser (or serve the folder with any static server, e.g. `python3 -m http.server`).
Wrap as APK later by hosting the folder on a website / WebView.

## Controls
- Mobile: left virtual joystick = move, **Jump**, **Sit** buttons.
- Desktop test: WASD / arrows, Space = jump, C = sit.

## Structure
```
index.html          page + touch UI
css/style.css       UI styling
js/game.js          whole engine (input, physics, camera, render)
assets/front_px.png side_px.png back_px.png   native pixel-art sprites (transparent bg, used by game)
assets/hires/       same sprites upscaled 8x (nearest) for editing
docs/PROJECT_NOTES.md   full context for another AI / developer
```
