# v49 - irregular valleys

Before: valleyHeight shaped the floor and walls purely by distance from the centre, so every Vale valley was a perfect round bowl.

## valley_sites.js
- New `wobble(S, a, n, r)`: three smooth angular noises (harmonics 2-7, phases from the site seed, twisting slightly with radius) drive
  1. flat BAYS: the floor edge runs out to as much as +24% of the wall width in some directions (`floorRadius(S, a, n)` exported),
  2. wall WIDTH 0.82-1.12x: broad gentle slopes in some directions, narrower steeper ones in others,
  3. rim RISE 0.78-1.24x: the rim stands higher in some directions.
- The floor inside Rf, the pass and everything outside Rb are unchanged (the pass still uses the original Rf).

## city_core.js
- The city fills the irregular floor: frontage lots and infill use `floorRadius` instead of the circle Rc (infill samples out to 1.13 Rc).
- Bug found and fixed on the way: skyline() took a negative number to the power 1.6 outside Rc (NaN building heights); now clamped.

## Measured (seed 424242, 32 sites)
- Average buildings per city 1239 (was 1222), 0 overlaps, every street graph reaches its gate, 0 non-finite pieces over 235k.
- test_shape / test_chunks / test_sim / test_runtime pass; drones now roam up to ~750 units from the centre (was ~590) because the floor is wider in bays.
- Not checked in a browser; the images were made with a software renderer from the real terrain and city generator.
