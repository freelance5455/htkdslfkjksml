
// =====================================================================================================================
// v88: voice lines varied again, and the inside of the cloud is now a lit, moving fog (it was black with radial streaks).
// v83: honest altitude (readouts == picture), multi-scale volumetric cloud deck that fades in on the way down, the rock no longer stalls and the strike bites instantly.
// v86: the voice has moods (pitch, pace, pauses, rising panic), and the lines no longer repeat stock phrases.
// v85: lightning forks and blooms, a violent white-hot contact flare.
// v84: zonal shear bands in the cloud tops, calmer jitter, plasma streaks.
// v81 (the strike, the AI's voice, trajectory + nutrient feed) on top of v80 (continuous dive, audible ambience) on top of v74 THE FREEFALL (rebuilt):
// a scary seven-shot cinematic between the Phase 5 launch and the Leviathan. The AI now speaks (the game's own speakLine) and shot 1 shows the debris strike.
// Every shot is seen from the pilot's head inside a real 3D cockpit (a raytraced room with a window and side ports). The pilot
// is half-conscious: each shot starts blurry and unfocused, then the pilot finds something to lock onto and leans in. Between
// shots: a hard cut to black, and a good deal of time has passed.
//
//   1 leaving the moon, curving away      2 deep space, the moon far behind, the giant ahead     3 midway: both small
//   4 swinging round to the far, lower side of the giant   5 closing in, faster   6 skimming the cloud tops   7 the plunge and the crash
//
// Self-contained: its own overlay, its own WebGL2 canvas (one full-screen fragment shader), its own Web Audio.
// Test it headless with tests/ff_cine_harness.html + tests/ff_cine_shots.py (renders any moment to a PNG).
// =====================================================================================================================

// ---- timeline (seconds) ---------------------------------------------------------------------------------------------
const SHD = [44.5, 30, 30, 30, 30, 30, 46], GAP = 1.5, T_BLACK0 = 1.0, D_END = 6.5;   // shot lengths; GAP = black between shots (hard cuts)
const TS = [], TE = [];
{ let t = T_BLACK0; for (const d of SHD) { TS.push(t); TE.push(t + d); t += d + GAP; } }
const T_END = TE[SHD.length - 1] + D_END;
const LIGHTNING = [10.5, 13.5, 16.5, 19.5, 22.5, 25.5, 28.5, 31.5, 34.5, 37.5]; // shot-7 local times of lightning; the last one is the big one
const IMPACT = 25.0, SPECK_T = 2.4, SPECK_POS = [0.18, 0.25];   // SPECK_POS: where the speck shows on the screen (fractions of width, height); the first crack grows from the same spot
//                                             // v81: shot 1 local time of the debris strike, and how long the speck is visible before it (under 2 s)
// v82 the aftermath of the strike (shot 1, q = seconds after the hit): the ship tumbles at 4.5 rad/s and the pilot, half-conscious, watches the AI fire
// the thrusters it has left, one burn at a time, each taking part of the spin off. [start, duration, fraction of the remaining spin removed]
const AFT_BURNS = [[4.0, 0.9, 0.30], [6.8, 0.9, 0.32], [9.6, 1.0, 0.35], [12.4, 1.0, 0.35], [15.2, 1.2, 0.55]];
const smoothS = (a, b, x) => { const u = Math.max(0, Math.min(1, (x - a) / (b - a))); return u * u * (3 - 2 * u); };
function aftRate(q) { let f = 1; for (const b of AFT_BURNS) f *= 1 - b[2] * smoothS(b[0], b[0] + b[1], q); return 4.5 * (1 - Math.exp(-9 * Math.max(0, q))) * f; }   // v83: the spin bites at once (was a 1 s wind-up)
const AFT_ROLL = (() => { const a = [0]; for (let i = 1; i <= 1100; i++) a.push(a[i - 1] + 0.5 * (aftRate((i - 1) * 0.02) + aftRate(i * 0.02)) * 0.02); return a; })();
function aftRoll(q) { const x = Math.max(0, Math.min(1099.99, q / 0.02)), i = Math.floor(x); return AFT_ROLL[i] + (AFT_ROLL[i + 1] - AFT_ROLL[i]) * (x - i); }
function aftThr(q) { let th = 0, side = 1; AFT_BURNS.forEach((b, i) => { const u = (q - b[0]) / b[1]; if (u > 0 && u < 1) { const v = Math.sin(Math.PI * Math.min(1, u * 1.15)); if (v > th) { th = v; side = i % 2 ? -1 : 1; } } }); return [th, side]; }
const FINAL_FLASH = 41.5;                                                       // then everything goes white, then black

// ---- small vector helpers -------------------------------------------------------------------------------------------
const v3 = (x, y, z) => [x, y, z];
const add = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
const mul = (a, s) => [a[0] * s, a[1] * s, a[2] * s];
const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const norm = (a) => { const l = Math.hypot(a[0], a[1], a[2]) || 1; return [a[0] / l, a[1] / l, a[2] / l]; };
const clamp01 = (x) => Math.max(0, Math.min(1, x));
const smooth = (a, b, x) => { const t = clamp01((x - a) / (b - a)); return t * t * (3 - 2 * t); };
const mix = (a, b, t) => a + (b - a) * t;
const wob = (t, s) => Math.sin(t * 7.3 * s) * 0.5 + Math.sin(t * 13.1 * s + 1.7) * 0.3 + Math.sin(t * 23.7 * s + 4.2) * 0.2;

// Camera looking back/down at a world centred on the origin. dir0 = unit direction from the world to the camera.
// A = angle off the straight-at-the-centre direction (0 = looking dead at the centre, ~1.2 = looking near the horizon).
function camBasis(dir0, A, roll, shx, shy) {
    const hint = Math.abs(dir0[1]) > 0.95 ? v3(1, 0, 0) : v3(0, 1, 0);
    const t = norm(cross(dir0, hint));
    const c = mul(dir0, -1);
    let f = add(mul(c, Math.cos(A)), mul(t, Math.sin(A)));
    let u = add(mul(c, -Math.sin(A)), mul(t, Math.cos(A)));
    let r = cross(f, u);
    f = norm(add(f, add(mul(r, shx), mul(u, shy))));
    r = norm(cross(f, u)); u = norm(cross(r, f));
    const cr = Math.cos(roll), sr = Math.sin(roll);
    const r2 = add(mul(r, cr), mul(u, sr)), u2 = add(mul(u, cr), mul(r, -sr));
    return { f, r: r2, u: u2 };
}

// ---- the world (units: moon radius = 1) ------------------------------------------------------------------------------------
const UPV = v3(0, 1, 0);
const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const hash1 = (n) => { const x = Math.sin(n * 127.1) * 43758.5453123; return x - Math.floor(x); };
const rotAxis = (v, k, a) => add(add(mul(v, Math.cos(a)), mul(cross(k, v), Math.sin(a))), mul(k, dot(k, v) * (1 - Math.cos(a))));
const GDIR = norm(v3(0.17, 0.07, -0.98)), GDIST = 167, RG = 40;       // the giant: same proportions as the game's sky (radius 11000 at distance 46000: ~13.8 degrees across from the moon's surface)
const GC = mul(GDIR, GDIST);
let SUN = v3(0.88, 0.22, 0.33);   // reassigned below, once the orbit exists: lit side faces the approach
let MOON_DIR = norm(add(mul(GDIR, 0.6), v3(0.7, 0.25, 0.15)));
const G_POLE = norm(v3(0.22, 0.94, 0.26));
const G_E1 = norm(cross(G_POLE, v3(0.31, 0.12, 0.94)));
const G_E2 = cross(G_POLE, G_E1);
const riftLonFor = (towardViewer) => Math.atan2(dot(towardViewer, G_E2), dot(towardViewer, G_E1));
// progress that only ever speeds up (never eases out): the ship keeps getting faster until the cut
const acc = (s, p) => Math.pow(clamp01(s), p);

function shipBasis(f, roll) {
    f = norm(f);
    const hint = Math.abs(f[1]) > 0.97 ? v3(0, 0, 1) : UPV;
    let u = norm(add(hint, mul(f, -dot(hint, f))));
    let r = cross(f, u);
    const cr = Math.cos(roll), sr = Math.sin(roll);
    return { f, r: add(mul(r, cr), mul(u, sr)), u: add(mul(u, cr), mul(r, -sr)) };
}
const turnF = (f, yaw, pitch) => norm(add(rotAxis(norm(f), UPV, yaw), v3(0, pitch || 0, 0)));

const SIDE0 = norm(cross(GDIR, UPV));
const B0 = mul(GDIR, -1);                                              // from the giant towards the moon
const orbitDir = (theta, lat) => norm(add(rotAxis(B0, UPV, -theta), v3(0, lat, 0)));
const orbitPos = (theta, lat, rad) => add(GC, mul(orbitDir(theta, lat), rad * RG));
const RIFT_LON = riftLonFor(orbitDir(2.6, -0.14));
{   // sun: half-lights the moon-facing side of the giant, and fully lights the far side we swing round to
    let sd = norm(cross(B0, UPV)); if (dot(sd, orbitDir(2.45, -0.12)) < 0) sd = mul(sd, -1);
    SUN = norm(add(mul(sd, 0.80), mul(orbitDir(2.8, -0.1), 0.30)));
    MOON_DIR = norm(add(add(mul(GDIR, 0.45), mul(SUN, 0.80)), v3(0, 0.30, 0)));   // lift-off in full daylight, on the giant-facing side
}


// ---- v79 THE PHYSICS: one ballistic trajectory drives the picture, the clock and every readout --------------------------------------
// Units: 1 world unit = 3400 km (the moon's radius), as before. The giant is 40 units (136,000 km) in radius and 167 units from the moon.
// The ship burns hard off the moon (3 g, ~17 minutes), then coasts: only the giant's gravity acts (GM = 4.8e8 km^3/s^2, about 3.8 Jupiter masses,
// which is what a 136,000 km giant needs for ~27 m/s^2 at its cloud tops). It leaves with 10 km/s of sideways speed, so it falls in on a curved
// path, arrives about 6 h 06 min after lift-off at ~71 km/s and ~57 degrees steep. The moon keeps circling the giant at 29 km/s the whole time,
// so it slides sideways across the sky. Within a shot, time runs 1:1: bodies change size only as fast as the real numbers say.
const KMU = 3400, GM_KM = 4.8e8, BURN_END = 1000, BURN_ACC = 0.0294, VT0 = 10;   // km, km^3/s^2, s, km/s^2, km/s
const E_R = B0;
const E_T = (() => { const e = norm(cross(B0, UPV)); return dot(e, orbitDir(0.5, 0)) < 0 ? mul(e, -1) : e; })();
const polar = (r, th) => add(mul(E_R, r * Math.cos(th)), mul(E_T, r * Math.sin(th)));
const R_TOP_KM = RG * KMU;                                         // where the cloud deck starts (the shader's cloud tops)
const MOON_W = Math.sqrt(GM_KM / (GDIST * KMU)) / (GDIST * KMU);          // moon's orbital rate, rad/s (29 km/s)
const moonVecAt = (met) => polar(GDIST, MOON_W * met);                    // giant-centred, world units
const TRAJ = (() => {
    const dt = 2, N = []; let x = (GDIST - 0.5 * BURN_ACC * BURN_END * BURN_END / KMU) * KMU, y = 0, vx = 0, vy = VT0, t = BURN_END;
    const a = (px, py) => { const r = Math.hypot(px, py), k = -GM_KM / (r * r * r); return [k * px, k * py]; };
    N.push([t, x, y, vx, vy]);
    while (Math.hypot(x, y) > R_TOP_KM && t < BURN_END + 40000) {
        let [ax, ay] = a(x, y); vx += ax * dt / 2; vy += ay * dt / 2; x += vx * dt; y += vy * dt; [ax, ay] = a(x, y); vx += ax * dt / 2; vy += ay * dt / 2; t += dt;
        N.push([t, x, y, vx, vy]);
    }
    return N;
})();
const ARR_MET = (() => { const n = TRAJ.length, A = TRAJ[n - 2], B = TRAJ[n - 1], ra = Math.hypot(A[1], A[2]), rb = Math.hypot(B[1], B[2]); return A[0] + (B[0] - A[0]) * (ra - R_TOP_KM) / (ra - rb); })();   // entry interface (the exact moment the path crosses the cloud tops), mission-elapsed seconds
const METS = [50, 2100, 6000, 11400, 17000, ARR_MET - 420, ARR_MET - 8];  // mission-elapsed seconds at the start of each shot
const ENTRY_LT = 8;                                                        // shot 7: seconds before the ship touches the cloud tops
function trajAt(met) {   // -> { p: giant-centred position (units), v: velocity (km/s, world axes), r: km from giant centre, speed }
    const f = Math.max(0, Math.min(TRAJ.length - 1.001, (met - BURN_END) / 2)), i = Math.floor(f), u = f - i, A = TRAJ[i], B = TRAJ[i + 1];
    const x = mix(A[1], B[1], u), y = mix(A[2], B[2], u), vx = mix(A[3], B[3], u), vy = mix(A[4], B[4], u);
    return { p: add(mul(E_R, x / KMU), mul(E_T, y / KMU)), v: add(mul(E_R, vx), mul(E_T, vy)), r: Math.hypot(x, y), speed: Math.hypot(vx, vy) };
}
const ENTRY = trajAt(ARR_MET - 0.001);
const ENTRY_DIR = norm(ENTRY.p), ENTRY_V = norm(ENTRY.v), ENTRY_SPEED = ENTRY.speed;
const DRAG_TAU = 12;                                                      // s: the air takes the speed off in about this time
const depthKm = (tau) => ENTRY_SPEED * DRAG_TAU * (1 - Math.exp(-Math.max(0, tau) / DRAG_TAU));

// ---- v80 THE DIVE: one straight, continuous visual path through shots 6 and 7 -----------------------------------------------------
// The real numbers (71 km/s on a 136,000 km planet) make the approach look frozen, and then the old depth stretch made the first seconds in the
// air look absurdly fast. Now the camera flies one straight line along the velocity vector, ending at the cloud tops (s = 0, world units, s < 0 is
// before contact). Its speed is continuous: a slow, accelerating fall in shot 6, a faster one in the last seconds of shot 7, then the air takes the
// speed off smoothly (exponentially) down to a slow sink. The HUD still shows the real figures; only the picture is stretched (flagged).
const E0 = mul(ENTRY_DIR, RG);
const DIVE6 = { s0: -42, vA: 0.85, vB: 1.81 };   // v83: ends ~6,000 km up; shot 7 then runs on the REAL trajectory, so the readouts and the picture agree                              // shot 6: start offset (units) and the speed (units/s) at its start / end
const DIVE7 = { L: 18, vA: 1.40, vB: 2.85, tv: 6.0, vt: 0.25 };             // shot 7: path length before contact, speed at start / at contact, air-braking time constant, terminal sink speed
function diveS6(lt) { const a = (DIVE6.vB - DIVE6.vA) / SHD[5]; return DIVE6.s0 + DIVE6.vA * lt + 0.5 * a * lt * lt; }
function diveV6(lt) { return DIVE6.vA + (DIVE6.vB - DIVE6.vA) * lt / SHD[5]; }
function diveS7(lt) {
    if (lt < ENTRY_LT) { const a = (DIVE7.vB + DIVE7.vt - DIVE7.vA) / ENTRY_LT; return -(DIVE7.L - (DIVE7.vA * lt + 0.5 * a * lt * lt)); }
    const tau = lt - ENTRY_LT; return DIVE7.vB * DIVE7.tv * (1 - Math.exp(-tau / DIVE7.tv)) + DIVE7.vt * tau;
}
function diveV7(lt) {
    if (lt < ENTRY_LT) return DIVE7.vA + (DIVE7.vB + DIVE7.vt - DIVE7.vA) * lt / ENTRY_LT;   // ends at exactly the speed the braking curve starts from
    return DIVE7.vB * Math.exp(-(lt - ENTRY_LT) / DIVE7.tv) + DIVE7.vt;
}

// ---- how the half-conscious pilot looks around ------------------------------------------------------------------------
function glance(lt, seed, period) {
    const x = lt / period + seed * 7.1, s = Math.floor(x), ph = x - s;
    const dir = hash1(s * 3.1 + seed) > 0.5 ? 1 : -1, mag = 0.45 + 0.55 * hash1(s * 5.7 + seed * 2.0);
    return dir * mag * smooth(0.08, 0.30, ph) * (1 - smooth(0.58, 0.86, ph));
}
const DAZE = [0.8, 0.6, 0.5, 0.45, 0.4, 0.35, 0.35];             // how far the head wanders before it finds something
const LIDS = [0.34, 0.30, 0.26, 0.22, 0.16, 0.10, 0.05];           // how droopy the eyelids are at the start of each shot
const BLUR0 = [1.0, 0.95, 0.9, 0.8, 0.7, 0.6, 0.5];                // how unfocused the vision is at the start of each shot
const LEAN = [0.15, 0.2, 0.25, 0.3, 0.4, 0.5, 0.45];               // how far the pilot leans toward the glass once locked on
function headPose(S, target) {
    const i = S.shot - 1, lt = S.lt, a = DAZE[i], st = S.stress, s = lt / SHD[i];
    const lock = i === 0 ? 1 : smooth(0.05, 0.20, s);          // 0 = lost and swimming, 1 = locked onto the target (v81: shot 1 is fully awake from the first frame)
    // aim at the thing (clamped to what the windows can show)
    let ty = 0, tp = -0.05;
    if (target) {
        const d = norm(sub(target, S.cam.pos)), x = dot(d, S.cam.r), y = dot(d, S.cam.u), z = dot(d, S.cam.f);
        ty = Math.max(-0.95, Math.min(0.95, Math.atan2(x, z)));
        tp = Math.max(-0.35, Math.min(0.55, Math.asin(Math.max(-1, Math.min(1, y))) * 0.7 - 0.05));
    }
    // lost: a short, slow swim of the gaze that stays around the window (never into a dark corner)
    const wy = 0.5 * ty + a * (0.45 * glance(lt, 1 + i, 5.5) + 0.15 * wob(lt, 0.35));
    const wp = 0.5 * tp + a * (0.18 * glance(lt, 2 + i, 7.0) + 0.06 * wob(lt + 3, 0.4));
    const wr = a * (0.10 * wob(lt * 0.35 + 7, 0.3) + 0.08 * glance(lt, 3 + i, 6.0));
    // 3) once locked: a calm, intentional look, a glance aside to take in the scene, and leaning toward the glass
    const intent = smooth(0.40, 0.95, s);
    const yaw = mix(wy, ty + 0.10 * glance(lt, 9 + i, 8.0), lock) + 0.012 * wob(lt, 0.4);
    const pitch = mix(wp, tp, lock) + 0.01 * wob(lt + 2, 0.5);
    const roll = mix(wr, 0.04 * wob(lt + 5, 0.3), lock);
    // shake: small, never constant; it builds only in the crash, with a jolt at each lightning strike
    let jolt = 0;
    if (i === 6) { const dc = lt - ENTRY_LT; if (dc >= 0 && dc < 2.0) jolt += 1.4 * Math.exp(-dc * 2.2) * smooth(0, 0.05, dc); }   // v80: the thump of the first touch of air
    if (i === 6) for (let k = 0; k < LIGHTNING.length; k++) { const dt = lt - LIGHTNING[k]; if (dt >= 0 && dt < 1.0) jolt += Math.exp(-dt * 5) * (k === LIGHTNING.length - 1 ? 1.6 : 1.0); }
    // v81: the strike. The head is thrown, slams the frame at q = 0.75 s, the vision smears and the eyelids shut fast.
    let hy = 0, hp = 0, hr = 0, shut = 0, smear = 0;
    if (i === 0 && lt >= IMPACT) {
        const q = lt - IMPACT, kick = Math.exp(-q * 3.0) * smooth(0.0, 0.05, q) * 1.5;   // v82: a beat to see the flash before the head is thrown
        hy += 0.55 * kick * Math.sin(q * 9.0); hp += -0.35 * kick; hr += 0.25 * kick * Math.sin(q * 7.0 + 1.0);
        jolt += 2.6 * Math.exp(-q * 2.5);
        const sl = q - 0.75; if (sl >= 0) { hp += -0.62 * Math.exp(-sl * 7.0); hy += 0.42 * Math.exp(-sl * 7.0); jolt += 2.2 * Math.exp(-sl * 9.0); }
        const wake = smooth(3.2, 5.0, q), half = clamp01(0.55 + 0.25 * Math.sin(q * 1.7) + 0.15 * Math.sin(q * 4.1));   // v82: the lids flutter half open and he watches the AI fight the spin
        smear = 0.9 * smooth(0.75, 1.25, q) * (1 - 0.45 * wake); shut = smooth(0.95, 1.7, q) * (1 - wake * (1 - half)); shut = shut + (1 - shut) * smooth(15.5, 18.3, q);
        hy += 0.10 * Math.sin(q * 0.8) * wake; hp += -0.08 * wake * (1 + Math.sin(q * 0.6));
    }
    const amp = 0.009 * (S.shake || 0) * (0.5 + 0.5 * (1 - lock)) + 0.012 * jolt;
    const sx = amp * wob(S.t * 2.6, 2.1), sy = amp * wob(S.t * 2.6 + 5, 2.3), sr = amp * 1.8 * wob(S.t * 2.6 + 9, 2.0);
    const lean = [(yaw * 0.28) + 0.03 * wob(lt, 0.5), pitch * 0.10 - 0.05 * LEAN[i] * intent * lock, LEAN[i] * 0.55 * intent * lock - 0.05 * Math.abs(yaw)];
    const blink = Math.abs(glance(lt, 4 + i, 11.0)) * (1 - 0.7 * lock);
    const eye = clamp01(LIDS[i] * (1 - 0.85 * lock) + 0.04 * wob(lt, 0.6) + 0.95 * blink * blink * blink + shut);
    const blur = BLUR0[i] * (1 - lock) + (i === 6 ? 0.30 * smooth(0.55, 1.0, s) + 0.25 * Math.min(jolt, 1) : 0) + smear;
    return { yaw: yaw + sx + hy, pitch: pitch + sy + hp, roll: roll + sr + hr, lean, eye, blur };
}

// ---- state of the whole piece at absolute time t ---------------------------------------------------------------------
function stateAt(t) {
    const S = { t, shot: 0, lt: 0, on: false, power: 1, stress: 0, alarm: 0, flash: 0, heat: 0, red: 0, white: 0, flow: 0, crack: 0, bolt: 0, cam: null, head: null, eye: 0, blur: 0,
        cabin: [0.02, 0.02, 0.03], tanFov: Math.tan(0.5 * 76 * Math.PI / 180), riftLon: RIFT_LON };
    let k = -1;
    for (let i = 0; i < SHD.length; i++) if (t >= TS[i] && t < TE[i]) k = i;
    if (k < 0) return S;
    const lt = t - TS[k], D = SHD[k], s = lt / D;
    S.shot = k + 1; S.lt = lt; S.on = true;
    let pos, f, roll = 0, target = null;
    const dim = (c, m) => [c[0] * m, c[1] * m, c[2] * m];
    const met = k === 6 ? ARR_MET - ENTRY_LT + lt : METS[k] + lt;
    S.met = met;
    const moonV = moonVecAt(met), toMoonFrame = (g) => sub(g, moonV);          // render frame: the moon sits at the origin
    S.gc = mul(moonV, -1);
    // the ship tumbles very slowly and steadily (no torque in vacuum, no damping): constant rates, not eased moves
    const spin = (rate, ph) => ph + rate * lt;
    if (k === 0) {                                             // 1: burning up off the moon at 3 g, still in its air: the view is back down at it
        const alt = 0.5 * BURN_ACC * met * met;                // km
        const bend = 0.8 * clamp01(alt / 14700);
        const d = norm(add(mul(MOON_DIR, 1 - bend), mul(GDIR, bend)));
        pos = mul(d, 1 + alt / KMU);
        // v81: the pilot is wide awake. A speck of debris shows dead ahead for under 2 s, grows, and hits: flash, crack, a violent shake, the ship
        // tumbles, the pilot's head hits the frame and the eyes shut. (q = seconds since the strike)
        const q = lt - IMPACT, qq = Math.max(0, q), sw = smooth(0, 0.10, qq);
        const A = mix(0.95, 0.55, Math.min(s, IMPACT / SHD[0])) + 0.40 * Math.sin(qq * 2.3) * sw * (1 - 0.8 * smooth(6, 17, qq));
        const spinW = aftRoll(qq);   // v82: the spin ramps up to 4.5 rad/s, then the thruster burns take it off in steps (see AFT_BURNS)
        roll = 0.05 + 0.05 * Math.min(s, IMPACT / SHD[0]) + 0.01 * Math.sin(lt * 0.9) + spinW + 0.30 * Math.exp(-qq * 5) * Math.sin(qq * 26);   // v83: plus an instant hammer-blow twist
        const th = q >= 0 ? aftThr(q) : [0, 1]; S.thr = th[0]; S.thrSide = th[1]; S.rate = q >= 0 ? aftRate(q) : 0;
        S.shake = 0.9 * (1 - smooth(0.25, 1.0, Math.min(s, 0.8))) + (q >= 0 ? 1.7 * Math.exp(-qq * 0.45) * smooth(0, 0.04, qq) + 0.75 * th[0] : 0);
        f = camBasis(d, A, roll, 0.30 * Math.sin(qq * 4.1) * sw * (1 - 0.8 * smooth(6, 17, qq)), 0.24 * Math.cos(qq * 3.3) * sw * (1 - 0.8 * smooth(6, 17, qq))).f; target = [0, 0, 0];
        S.q = q; S.speck = (lt >= IMPACT - SPECK_T && lt < IMPACT) ? (lt - (IMPACT - SPECK_T)) / SPECK_T : -1;
        if (q >= 0) { S.crack = smooth(0, 0.18, q); S.flash = 2.4 * Math.exp(-qq * 6.0) * (0.8 + 0.2 * Math.sin(qq * 60)) + 0.5 * Math.exp(-qq * 1.5); S.alarm = smooth(0.1, 0.5, q) * 0.85; }
        S.cabin = dim([1.0, 0.62, 0.45], (0.40 * (1 - smooth(0.2, 1.0, Math.min(s, 0.8))) + 0.10) * (q >= 0 ? Math.max(0.12, 1 - 0.88 * Math.exp(-qq * 2.5) * (0.55 + 0.45 * Math.sin(qq * 37))) : 1));   // v83: the cabin lights stutter at the hit
        S.altKm = alt; S.speed = BURN_ACC * met; S.dGiantKm = (GDIST - 1) * KMU - alt; S.dMoonKm = alt;
        S.burn = 1; S.moonAlt = alt;
    } else {
        const tr = k === 6 && lt >= ENTRY_LT ? null : trajAt(met);
        let gv;                                                // giant-centred position (units)
        let speed;
        if (tr) { gv = tr.p; speed = tr.speed; S.dGiantKm = tr.r - R_TOP_KM; }
        else {
            const tau = lt - ENTRY_LT, dep = depthKm(tau);
            speed = ENTRY_SPEED * Math.exp(-tau / DRAG_TAU);
            S.depthKm = dep; S.decelG = speed / DRAG_TAU / 0.00981; S.dGiantKm = -dep;
        }
        // v83: shot 6 flies a straight stretched path, but its altitude readout is now taken from that path. Shot 7 is the real trajectory
        // (71 km/s, ~476 km up at its start) and, once in the air, the real braking curve: the numbers on the glass are the picture.
        if (k === 5) { gv = add(E0, mul(ENTRY_V, diveS6(lt))); S.vis = diveV6(lt); S.dGiantKm = (Math.hypot(gv[0], gv[1], gv[2]) - RG) * KMU; }
        else if (k === 6) {
            if (!tr) { gv = add(E0, mul(ENTRY_V, depthKm(lt - ENTRY_LT) / KMU)); S.depthKm = (RG - Math.hypot(gv[0], gv[1], gv[2])) * KMU; S.dGiantKm = -S.depthKm; }
            S.vis = DIVE7.vt + (DIVE7.vB - DIVE7.vt) * speed / ENTRY_SPEED;   // only drives the sound and the streaks now
        }
        else S.vis = 0;
        pos = toMoonFrame(gv); S.speed = speed;
        S.dMoonKm = Math.hypot(pos[0], pos[1], pos[2]) * KMU;
        const tc = norm(sub(S.gc, pos)), tm = norm(mul(pos, -1));   // toward the giant, toward the moon
        const aim = (w, yaw0, rate, pit) => turnF(norm(add(mul(tc, 1 - w), mul(tm, w))), spin(rate, yaw0), pit);
        if (k === 1) {        // 2: ~35 min out. The moon is a small bright disc already sliding sideways; the giant ahead
            f = aim(mix(0.97, 0.55, smooth(0.15, 0.95, s)), mix(-0.30, 0.10, smooth(0.0, 0.5, s)), 0.0042, 0.03); roll = 0.06 + 0.0030 * lt;   // v82: the moon starts in the front window, then slides out of view as the ship turns toward the giant
            S.crack = 1; target = s < 0.35 ? [0, 0, 0] : S.gc; S.cabin = [0.05, 0.07, 0.11];
        } else if (k === 2) { // 3: ~1 h 40: still little change. The giant is wide but far; the moon is a point
            f = aim(0.25, -0.12, -0.0035, 0.02); roll = 0.10 - 0.0026 * lt;
            S.crack = 1; target = S.gc; S.cabin = [0.045, 0.06, 0.10];
        } else if (k === 3) { // 4: ~3 h 10: the giant clearly larger; the moon far behind and off to one side
            f = aim(0.0, 0.16, 0.0030, -0.02); roll = -0.04 + 0.0022 * lt;
            S.crack = 1; target = S.gc; S.cabin = dim([0.9, 0.5, 0.25], 0.07 + 0.05 * s);
        } else if (k === 4) { // 5: ~4 h 45: it fills a third of the view; speed is climbing
            f = aim(0.0, -0.10, -0.0026, -0.03); roll = 0.06 + 0.0016 * lt;
            S.crack = 1; target = S.gc; S.alarm = smooth(0.4, 0.8, s) * 0.6; S.cabin = dim([0.95, 0.46, 0.20], 0.12 + 0.06 * s);
        } else if (k === 5) { // 6: seven minutes out. ~70 km/s, tens of thousands of km above the cloud tops, the limb already a wall
            f = norm(add(mul(ENTRY_V, 0.78), mul(tc, 0.22))); f = turnF(f, spin(0.0030, 0.05), -0.02); roll = 0.03 + 0.0012 * lt;
            S.crack = 2; target = S.gc; S.alarm = 0.9; S.cabin = dim([1.0, 0.42, 0.14], 0.20 + 0.12 * s);
        } else {              // 7: the plunge, in real time: the cloud tops at ENTRY_LT, then the air takes 71 km/s off in seconds
            const tau = Math.max(0, lt - ENTRY_LT), u = clamp01((lt - ENTRY_LT) / (D - ENTRY_LT));
            const rad = norm(gv), Hd = norm(sub(ENTRY_V, mul(rad, dot(ENTRY_V, rad))));
            const tip = Math.pow(smooth(0, 1, lt / ENTRY_LT), 1.3);                  // v83: starts looking along the flat cloud sea, tips over into the plunge by contact
            const fLook = norm(add(mul(Hd, 0.96), mul(rad, -0.05))), fDive = norm(add(mul(ENTRY_V, 0.93), mul(tc, 0.07)));
            f = norm(add(mul(fLook, 1 - tip), mul(fDive, tip)));
            roll = (0.10 * wob(lt * 0.5, 0.5) + 0.03 * Math.sin(lt * 1.3)) * smooth(0.0, 0.4, u);
            const inAir = lt >= ENTRY_LT;
            S.heat = inAir ? (0.18 + 0.72 * smooth(0.0, 0.021, u)) * (1 - 0.45 * smooth(0.3, 0.6, u)) : 0.18 * smooth(3.5, ENTRY_LT, lt);   // v85: the air hits like a wall (full heat in under a second)
            S.contact = inAir ? Math.exp(-tau * 2.4) * smooth(0, 0.08, tau) : 0;   // v83: the thin upper air starts to glow before contact
            S.red = smooth(0.72, 1.0, u);
            S.flow = 30 * S.vis;
            S.inCloud = inAir ? smooth(0.12, 2.2, tau) : 0;           // v88: how far the picture has moved from 'above the cloud sea' to 'inside the cloud'
            S.trav = inAir ? Math.max(0, diveS7(lt)) : 0;              // v88: distance flown through the cloud, in cloud-noise units
            S.shake = inAir ? smooth(0, 0.07, u) * (0.20 + 0.80 * smooth(0.02, 0.45, u) + 0.3 * smooth(0.6, 1.0, u)) : 0.05 * smooth(0.5, 1.0, (lt) / ENTRY_LT); S.crack = 2; S.alarm = lt < FINAL_FLASH ? 1 : 0;
            target = add(pos, mul(f, 10));
            S.cabin = dim(mix3([1.0, 0.30, 0.10], [0.85, 0.10, 0.05], S.red), 0.40 + 0.25 * S.heat);
            let fl = 0;
            for (let i = 0; i < LIGHTNING.length; i++) {
                const dt = lt - LIGHTNING[i];
                if (dt >= 0) { const big = i === LIGHTNING.length - 1 ? 1.5 : 1.0; fl += big * Math.exp(-dt * 9) * (0.75 + 0.25 * Math.sin(dt * 70)); fl += 0.55 * big * Math.exp(-(dt - 0.16) * 14) * (dt > 0.16 ? 1 : 0); }
            }
            if (lt >= FINAL_FLASH) fl += 2.0 * smooth(FINAL_FLASH, FINAL_FLASH + 0.25, lt);
            S.flash = fl;
            S.white = smooth(FINAL_FLASH, FINAL_FLASH + 0.22, lt);
            for (let i = 0; i < LIGHTNING.length; i++) if (lt >= LIGHTNING[i] && lt < LIGHTNING[i] + 0.5) S.bolt = i + 1;
        }
    }
    if (lt > D - 0.05 || (k === 6 && lt >= D - 0.12)) S.on = false;
    S.stress = Math.min(S.shake || 0, 1.3);
    S.cam = { pos, ...shipBasis(f, roll) };
    S.sun = SUN;
    S.head = headPose(S, target);
    S.eye = S.head.eye; S.blur = S.head.blur;
    return S;
}
function mix3(a, b, t) { return [mix(a[0], b[0], t), mix(a[1], b[1], t), mix(a[2], b[2], t)]; }

// ---- shaders ------------------------------------------------------------------------------------------------------------
const VERT = `#version 300 es
void main() { vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2)); gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0); }`;

const FRAG = `#version 300 es
precision highp float;
precision highp int;
out vec4 outColor;
uniform vec2 uRes; uniform float uTime;
uniform vec3 uCam; uniform vec3 uF; uniform vec3 uR; uniform vec3 uU; uniform float uTanFov;
uniform vec3 uSun; uniform int uShot;
uniform float uIn; uniform float uTrav; uniform vec3 uTravDir;
uniform float uHeat; uniform float uContact; uniform float uStorm; uniform float uFlash; uniform float uPower; uniform float uStress;
uniform float uSpeck; uniform float uImp; uniform float uThr; uniform float uThrSide;
uniform float uBolt; uniform float uDebris; uniform vec3 uMoonPos; uniform vec3 uE1; uniform vec3 uPole; uniform vec3 uE2; uniform float uRiftLon;
uniform mat3 uHead; uniform vec3 uHeadPos; uniform vec3 uCabin; uniform float uEye; uniform float uCrack; uniform float uAlarm; uniform vec3 uGC; uniform float uRG; uniform vec2 uCrackO; uniform float uBlur; uniform float uWhite; uniform float uFlow; uniform float uRed;

float time;

// ------------------------------------------------------------------ noise
float hash(vec3 p) { p = fract(p * 0.3183099 + 0.1); p *= 17.0; return fract(p.x * p.y * p.z * (p.x + p.y + p.z)); }
float hash1(float n) { return fract(sin(n * 127.1) * 43758.5453123); }
float noise(in vec3 x) {
    vec3 i = floor(x); vec3 f = fract(x); f = f * f * (3.0 - 2.0 * f);
    return mix(mix(mix(hash(i + vec3(0,0,0)), hash(i + vec3(1,0,0)), f.x), mix(hash(i + vec3(0,1,0)), hash(i + vec3(1,1,0)), f.x), f.y),
               mix(mix(hash(i + vec3(0,0,1)), hash(i + vec3(1,0,1)), f.x), mix(hash(i + vec3(0,1,1)), hash(i + vec3(1,1,1)), f.x), f.y), f.z);
}
float fbm(vec3 p) { float v = 0.0, a = 0.5; for (int i = 0; i < 5; i++) { v += a * noise(p); p = p * 2.03 + vec3(1.7, 9.2, 3.1); a *= 0.5; } return v / 0.97; }
float fbm4(vec3 p) { float v = 0.0, a = 0.5; for (int i = 0; i < 4; i++) { v += a * noise(p); p = p * 2.03 + vec3(1.7, 9.2, 3.1); a *= 0.5; } return v / 0.9375; }
float fbm3(vec3 p) { float v = 0.0, a = 0.5; for (int i = 0; i < 3; i++) { v += a * noise(p); p = p * 2.07 + vec3(1.7, 9.2, 3.1); a *= 0.5; } return v / 0.875; }
vec3 pc(float lon, float lat, float sc, float latSc) { return vec3(cos(lon) * sc, sin(lon) * sc, lat * latSc); }
float wrapPi(float a) { return a - 6.2831853 * floor((a + 3.1415927) / 6.2831853); }

// detail noise on a unit-sphere direction whose octaves fade out when they are smaller than a pixel (pix = unit-sphere length per pixel)
float lodNoise(vec3 p, float f0, float pix, float amp0) {
    float v = 0.0, a = amp0, f = f0;
    for (int i = 0; i < 6; i++) {
        float w = smoothstep(0.8, 3.0, (1.0 / f) / max(pix, 1e-7));
        if (w <= 0.001) break;
        v += a * (noise(p * f + float(i) * 7.3) - 0.5) * w;
        f *= 2.7; a *= 0.5;
    }
    return v;
}

vec2 raySphere(vec3 ro, vec3 rd, float r) {
    float b = dot(ro, rd); float c = dot(ro, ro) - r * r; float h = b * b - c;
    if (h < 0.0) return vec2(-1.0);
    h = sqrt(h); return vec2(-b - h, -b + h);
}


// ------------------------------------------------------------------ stars: the game's own night sky (Milky Way, nebulae, Andromeda, coloured stars, wanderers)
                // ---- hashing / gNoise: Hoskins-style hashes (no sin(), no precision cliffs) and smooth gradient gNoise (no blocky value-gNoise grid) ----
                float gHash(vec3 p3) { p3 = fract(p3 * 0.1031); p3 += dot(p3, p3.zyx + 31.32); return fract((p3.x + p3.y) * p3.z); }
                vec3 gHash33(vec3 p3) { p3 = fract(p3 * vec3(0.1031, 0.1030, 0.0973)); p3 += dot(p3, p3.yxz + 33.33); return fract((p3.xxy + p3.yxx) * p3.zyx); }
                float gNoise(vec3 x) {
                    vec3 i = floor(x); vec3 f = fract(x); vec3 u = f * f * f * (f * (f * 6.0 - 15.0) + 10.0);
                    float n000 = dot(gHash33(i) - 0.5, f);
                    float n100 = dot(gHash33(i + vec3(1,0,0)) - 0.5, f - vec3(1,0,0));
                    float n010 = dot(gHash33(i + vec3(0,1,0)) - 0.5, f - vec3(0,1,0));
                    float n110 = dot(gHash33(i + vec3(1,1,0)) - 0.5, f - vec3(1,1,0));
                    float n001 = dot(gHash33(i + vec3(0,0,1)) - 0.5, f - vec3(0,0,1));
                    float n101 = dot(gHash33(i + vec3(1,0,1)) - 0.5, f - vec3(1,0,1));
                    float n011 = dot(gHash33(i + vec3(0,1,1)) - 0.5, f - vec3(0,1,1));
                    float n111 = dot(gHash33(i + vec3(1,1,1)) - 0.5, f - vec3(1,1,1));
                    return 0.5 + 1.55 * mix(mix(mix(n000, n100, u.x), mix(n010, n110, u.x), u.y), mix(mix(n001, n101, u.x), mix(n011, n111, u.x), u.y), u.z);
                }
                float gFbm3(vec3 p) { float v = 0.0, a = 0.5; for (int i = 0; i < 3; i++) { v += a * gNoise(p); p = p * 2.02 + vec3(1.7, 9.2, 3.1); a *= 0.5; } return v / 0.875; }
                float gFbm4(vec3 p) { float v = 0.0, a = 0.5; for (int i = 0; i < 4; i++) { v += a * gNoise(p); p = p * 2.02 + vec3(1.7, 9.2, 3.1); a *= 0.5; } return v / 0.9375; }
                float gFbm5(vec3 p) { float v = 0.0, a = 0.5; for (int i = 0; i < 5; i++) { v += a * gNoise(p); p = p * 2.02 + vec3(1.7, 9.2, 3.1); a *= 0.5; } return v / 0.96875; }

                // stellar colour from a continuous "temperature" k (0 = hot blue ... 1 = cool red), roughly following the real star population
                // (mostly white-to-yellow, fewer blue giants, rare deep orange and red ones)
                vec3 starTint(float k) {
                    vec3 blue = vec3(0.60, 0.74, 1.00), white = vec3(0.97, 0.97, 1.00), yel = vec3(1.00, 0.90, 0.70), org = vec3(1.00, 0.72, 0.46), red = vec3(1.00, 0.52, 0.36);
                    vec3 c = mix(blue, white, smoothstep(0.00, 0.30, k));
                    c = mix(c, yel, smoothstep(0.35, 0.65, k));
                    c = mix(c, org, smoothstep(0.70, 0.90, k));
                    return mix(c, red, smoothstep(0.93, 1.00, k));
                }
                float dotProfile(float d, float r) { float x = clamp(1.0 - d / r, 0.0, 1.0); return x * x * x; }

                // One layer of round stars on a 3D lattice (every cell holds at most one star, kept well inside its cell so nothing is ever cut into a
                // square). Stars come from a steep magnitude curve (very few brilliant, a great many faint). 'pw' = one pixel in radians: a star never
                // shrinks below ~a pixel (its light is spread, not lost) so it does not crawl as the view turns. 'dens' > 0 adds stars where the Milky
                // Way is crowded. 'scint' scales twinkle (stronger near the horizon, where the light crosses more air).
                vec3 starLayer(vec3 dir, float scale, float thresh, float rad, float base, float gain, float haloAmt, float vis, float pw, float tws, float scint) {
                    vec3 p = dir * scale; vec3 c = floor(p);
                    float h = gHash(c);
                    if (h < thresh) return vec3(0.0);
                    float mag = (h - thresh) / (1.0 - thresh);
                    float seen = smoothstep(0.0, 0.35, vis * 1.25 - (1.0 - mag) * 0.85 + 0.12);
                    if (seen <= 0.0) return vec3(0.0);
                    vec3 s0 = c + vec3(gHash(c + 11.3), gHash(c + 27.7), gHash(c + 43.1)) * 0.5 + 0.25;
                    vec3 sp = s0 * (scale / length(s0));
                    vec3 loc = sp - c;
                    if (min(min(loc.x, loc.y), loc.z) < 0.30 || max(max(loc.x, loc.y), loc.z) > 0.70) return vec3(0.0);
                    float d = length(p - sp);
                    float pix = pw * scale;
                    float r0 = min(rad * (0.7 + 0.6 * mag), 0.3);
                    float r = min(max(r0, pix * 1.15), 0.3);
                    float comp = min((r0 * r0) / (r * r), 1.0);
                    float core = dotProfile(d, r) * comp;
                    float halo = haloAmt > 0.0 ? pow(clamp(1.0 - d / 0.17, 0.0, 1.0), 3.0) * haloAmt * mag * mag : 0.0;
                    // hot stars are rarer; the colour index is independent of brightness
                                        vec3 tint = starTint(clamp(0.12 + 0.88 * gHash(c + 5.5), 0.0, 1.0));
                    float ph = h * 91.0;
                    float tw = 1.0 + tws * scint * (0.6 * sin(time * (1.7 + 2.3 * gHash(c + 3.3)) + ph) + 0.4 * sin(time * 5.1 + h * 37.0));
                    // bright stars near the horizon flicker in colour as well
                    tint *= 1.0 + 0.35 * (scint - 1.0) * vec3(sin(time * 3.1 + ph), sin(time * 3.7 + ph * 1.3), sin(time * 4.3 + ph * 0.7)) * step(0.5, mag);
                    float b = (base + gain * mag * mag * mag) * seen;
                    return tint * (core + halo * 0.5) * b * tw;
                }

                // A steady, bright "wandering star" (planet-like): no twinkle, a little warm/cool colour, a soft halo.
                vec3 wanderer(vec3 dir, vec3 pos, float size, vec3 tint, float inten, float pw, float vis) {
                    float d = length(dir - normalize(pos));
                    float r = max(size, pw * 1.1);
                    float comp = min((size * size) / (r * r), 1.0);
                    float core = exp(-(d * d) / (r * r) * 1.6) * comp;
                    float halo = exp(-d * d / 0.00018) * 0.05;
                    return tint * (core + halo) * inten * smoothstep(0.05, 0.4, vis);
                }

                // Galactic plane, rebuilt as what the eye actually sees: UNRESOLVED STARLIGHT that is smooth and soft, thickest toward the galactic
                // centre, with large-scale star clouds, broad soft dust that dims and reddens what lies behind it, and a faint rift. No painted
                // streaks: every feature is low-frequency, so it reads as a luminous haze with depth rather than a texture laid across the sky.
                // returns rgb = diffuse glow, a = crowding (how many extra faint stars to draw here)
                vec4 milkyWay(vec3 d) {
                    vec3 gn = normalize(vec3(0.46, 0.70, 0.55));
                    vec3 c0 = vec3(-0.80, 0.42, 0.20);
                    vec3 g1 = normalize(c0 - gn * dot(c0, gn));
                    vec3 g2 = cross(gn, g1);
                    float sb = dot(d, gn);
                    if (abs(sb) > 0.95) return vec4(0.0);
                    float lx = dot(d, g1), ly = dot(d, g2);
                    float lon = atan(ly, lx);
                    vec2 cyc = vec2(lx, ly) / max(length(vec2(lx, ly)), 1e-4);
                    float cen  = exp(-lon * lon / (2.0 * 1.10 * 1.10));
                    float cen2 = exp(-lon * lon / (2.0 * 0.55 * 0.55));
                    float cen3 = exp(-lon * lon / (2.0 * 0.26 * 0.26));

                    float w1 = gNoise(vec3(cyc * 1.3, sb * 2.0) + 11.0) - 0.5;
                    float w2 = gNoise(vec3(cyc * 2.7, sb * 3.0) + 31.0) - 0.5;
                    float bw = sb + w1 * 0.16 + w2 * 0.05;
                    float width = mix(0.15, 0.26, cen2);                 // a BIG band: roughly 30-50 degrees across

                    float thin = exp(-pow(abs(bw) / width, 1.7));
                    float thick = exp(-pow(abs(bw) / (width * 2.6), 2.0));
                    float bulge = cen3 * exp(-(bw * bw) / (2.0 * 0.20 * 0.20)) + 0.60 * cen2 * exp(-(bw * bw) / (2.0 * 0.38 * 0.38));
                    float lonMod = 0.70 + 0.30 * cen;

                    float cl1 = gFbm4(vec3(cyc * 4.0, bw * 5.5) + vec3(3.0, 8.0, 1.0));
                    float cl2 = gFbm4(vec3(cyc * 8.5, bw * 11.0) + vec3(9.0, 2.0, 6.0));
                    float clouds = 0.50 + 0.95 * smoothstep(0.28, 0.72, cl1 * 0.6 + cl2 * 0.4);
                    float grain = 0.80 + 0.40 * gNoise(d * 150.0 + vec3(0.0, time * 0.02, 0.0));

                    // DUST: many soft lanes and filaments. A ridged gNoise gives thin winding lanes, a second scale gives finer tendrils, and a
                    // slow low-frequency field decides where the dust is thick. Plus the long Great Rift down the middle of the bright part.
                    float dz = exp(-pow(abs(bw + 0.015) / (width * 1.25), 1.6));
                    float r1 = 1.0 - abs(2.0 * gFbm4(vec3(cyc * 5.5, bw * 7.5) + vec3(7.0, 1.0, 3.0)) - 1.0);
                    float r2 = 1.0 - abs(2.0 * gFbm4(vec3(cyc * 12.0, bw * 15.0) + vec3(2.0, 5.0, 4.0)) - 1.0);
                    float r3 = 1.0 - abs(2.0 * gFbm3(vec3(cyc * 24.0, bw * 28.0) + vec3(5.0, 3.0, 9.0)) - 1.0);
                    float thickD = smoothstep(0.30, 0.75, gFbm3(vec3(cyc * 2.2, bw * 4.0) + 41.0));
                    float lanes = smoothstep(0.66, 0.93, r1) * 0.95 + smoothstep(0.72, 0.95, r2) * 0.55 * thickD + smoothstep(0.78, 0.97, r3) * 0.30 * thickD;
                    float tau = dz * (0.45 + 1.4 * cen2) * (0.30 + 0.90 * thickD) * lanes * 0.95;
                    float ru = (bw - 0.010 - 0.030 * sin(lon * 1.6 + w1 * 5.0)) / (0.032 + 0.040 * cen2);
                    float rift = exp(-ru * ru) * smoothstep(0.28, 0.62, gFbm3(vec3(cyc * 2.2, bw * 5.0) + 70.0)) * (0.30 + 0.70 * cen) * (1.0 - smoothstep(1.8, 2.8, abs(lon)));
                    tau += rift * 1.0;
                    // dark cloud knots (Coalsack-like) hanging a little off the plane
                    float kn = smoothstep(0.66, 0.84, gFbm3(vec3(cyc * 7.0, bw * 14.0) + 55.0)) * exp(-pow(abs(bw) / (width * 1.6), 2.0));
                    tau += kn * 0.7;
                    vec3 trans = exp(-tau * vec3(0.95, 1.03, 1.15));

                    float lum = (thin * (0.55 + 0.25 * cen2) * lonMod + thick * 0.09 + bulge * 0.95) * clouds * grain;
                    vec3 cool = vec3(0.66, 0.77, 1.00), mid = vec3(0.88, 0.92, 1.00), warm = vec3(1.00, 0.84, 0.62);
                    float wk = clamp(bulge * 0.65, 0.0, 1.0);
                    vec3 tint = mix(cool, mid, smoothstep(0.0, 0.35, wk));
                    tint = mix(tint, warm, smoothstep(0.30, 1.0, wk));

                    // NEBULAE: emission (red/pink H-alpha with hotter pink-white cores), blue reflection nebulae round bright stars, and a few
                    // teal/oxygen wisps. They follow filament-shaped (ridged) gNoise, sit in and around the band, and are partly eaten by dust.
                    float zone = exp(-pow(abs(bw) / (width * 1.7), 1.5));
                    float e1 = gFbm4(vec3(cyc * 3.4, bw * 6.0) + 90.0);
                    float e2 = 1.0 - abs(2.0 * gFbm4(vec3(cyc * 7.5, bw * 12.0) + 21.0) - 1.0);
                    float emis = smoothstep(0.50, 0.74, e1) * (0.40 + 0.80 * smoothstep(0.55, 0.95, e2)) * zone * (0.45 + 0.55 * cen2 + 0.3);
                    float emCore = smoothstep(0.66, 0.86, e1) * smoothstep(0.60, 0.97, e2) * zone * (0.5 + 0.5 * cen2);
                    float b1 = gFbm4(vec3(cyc * 4.0, bw * 7.0) + 130.0);
                    float refl = smoothstep(0.54, 0.78, b1) * (0.50 + 0.80 * smoothstep(0.5, 0.95, 1.0 - abs(2.0 * gFbm3(vec3(cyc * 9.0, bw * 14.0) + 8.0) - 1.0))) * zone;
                    float o3 = smoothstep(0.62, 0.84, gFbm3(vec3(cyc * 5.0, bw * 9.0) + 170.0)) * zone * (0.3 + 0.7 * cen);
                    vec3 nebula = vec3(0.95, 0.22, 0.42) * emis * 0.40 + vec3(1.0, 0.62, 0.72) * emCore * 0.30
                                + vec3(0.25, 0.50, 1.00) * refl * 0.40 + vec3(0.15, 0.75, 0.78) * o3 * 0.18;
                    vec3 rgb = (tint * lum + nebula * (0.55 + 0.45 * clouds)) * trans;
                    float crowd = (thin * (0.75 + 0.25 * cen) + bulge * 0.7) * clouds * dot(trans, vec3(0.3333));
                    float polarFade = 1.0 - smoothstep(0.55, 0.92, abs(sb));
                    return vec4(rgb * polarFade, crowd * polarFade);
                }

                // Andromeda (M31) as seen from this planet: a big, tilted spiral that sits just below and beside the Galactic Core at galactic latitude
                // -11 degrees (longitude -13 degrees). Built in the tangent plane of its position: a long exponential disc (very inclined, so a thin ellipse),
                // a warm bulge and nucleus, a ring of young blue arms, a dust lane along the near edge, a few pink star-forming knots, and its two companions
                // M32 and M110. Returns rgb light (before extinction / twinkle masks).
                const float M31_L = -0.2269;       // galactic longitude (rad) = -13 deg
                const float M31_B = -0.1920;       // galactic latitude  (rad) = -11 deg
                vec3 andromeda(vec3 d, float pw) {
                    vec3 gn = normalize(vec3(0.46, 0.70, 0.55));
                    vec3 c0 = vec3(-0.80, 0.42, 0.20);
                    vec3 g1 = normalize(c0 - gn * dot(c0, gn));
                    vec3 g2 = cross(gn, g1);
                    vec3 m = cos(M31_B) * (cos(M31_L) * g1 + sin(M31_L) * g2) + sin(M31_B) * gn;
                    float cd = dot(d, m);
                    if (cd < 0.985) return vec3(0.0);
                    vec3 tl = normalize(cross(gn, m));           // direction of increasing galactic longitude at M31
                    vec3 tb = cross(m, tl);                       // toward galactic north
                    vec2 p = vec2(dot(d, tl), dot(d, tb));
                    const float PA = 0.70;                        // long axis tilted ~40 degrees from galactic north
                    vec2 q = vec2(cos(PA) * p.x - sin(PA) * p.y, sin(PA) * p.x + cos(PA) * p.y);   // q.x along the long axis
                    float A = 0.068, Bm = 0.0185;                 // semi-axes (rad): ~8 x 2 degrees across (a touch larger than the naked-eye real thing, so it reads)
                    A = max(A, pw * 4.0); Bm = max(Bm, pw * 1.6);
                    vec2 e = vec2(q.x / A, q.y / Bm);
                    float r = length(e);
                    float disc = exp(-r * 1.5) * (1.0 - smoothstep(1.1, 1.8, r));
                    float bulge = exp(-r * r * 22.0) * 0.9 + exp(-r * 7.0) * 0.35;
                    float nucleus = exp(-r * r * 400.0) * 1.2;
                    float phi = atan(e.y, e.x);
                    // young arms: a log-spiral pattern, seen almost edge-on it shows up as bright patches and rings along the disc
                    float arms = 0.86 + 0.14 * cos(2.0 * (phi - 3.2 * log(max(r, 0.05))));
                    float ring = exp(-pow((r - 0.62) / 0.20, 2.0)) * 0.40 + exp(-pow((r - 0.30) / 0.12, 2.0)) * 0.22;
                    float grain = 0.85 + 0.30 * gNoise(vec3(e * 5.0, 3.0));
                    // dust lane on the near side of the disc, a little off the midline
                    float lane = exp(-pow((e.y + 0.28 + 0.06 * sin(e.x * 3.0)) / 0.20, 2.0)) * smoothstep(0.2, 0.5, r) * (1.0 - smoothstep(0.9, 1.4, r));
                    lane *= 0.45 + 0.55 * gNoise(vec3(e * vec2(6.0, 12.0), 8.0));
                    float body = (disc * arms * grain + ring * arms * 0.55) * (1.0 - 0.7 * lane) + bulge * (1.0 - 0.4 * lane);
                    vec3 warm = vec3(1.00, 0.86, 0.62), blue = vec3(0.70, 0.80, 1.00);
                    vec3 col = mix(blue, warm, clamp(exp(-r * 2.2) * 1.5 + bulge * 0.4, 0.0, 1.0)) * body;
                    col += vec3(1.0, 0.95, 0.85) * nucleus;
                    float hii = smoothstep(0.62, 0.82, gNoise(vec3(e * 7.0, 11.0))) * ring;
                    col += vec3(0.95, 0.35, 0.55) * hii * 0.25;
                    // companions: M32 (compact, bright, just off the disc) and M110 (a larger, fainter oval)
                    vec2 c32 = q - vec2(-0.016, -0.0165);
                    col += vec3(1.0, 0.90, 0.72) * (exp(-dot(c32, c32) / (2.0 * 0.0016 * 0.0016)) * 0.65 + exp(-dot(c32, c32) / (2.0 * 0.006 * 0.006)) * 0.06);
                    vec2 c110 = q - vec2(0.100, 0.034);
                    c110 = vec2(c110.x / 0.011, c110.y / 0.0055);
                    col += vec3(0.95, 0.90, 0.82) * exp(-dot(c110, c110) * 0.9) * 0.16;
                    // faint outer glow so the galaxy melts into the sky
                    col += vec3(0.62, 0.72, 1.0) * exp(-r * 1.1) * 0.035;
                    return col;
                }

vec3 starField(vec3 d, float pw) {
    vec3 starDir = d;
    float scint = uShot == 1 ? 0.55 : 0.0;   // stars only twinkle through air: none once we are in vacuum
    vec4 mw = milkyWay(starDir);
    vec3 col = mw.rgb * 0.15;
    float crowd = clamp(mw.a, 0.0, 1.0);
    float nebBoost = 1.0 + dot(mw.rgb, vec3(0.5)) * 1.6;
    float cr = crowd * crowd * (3.0 - 2.0 * crowd);
    float f1 = 1.0 - smoothstep(0.55, 1.0, pw * 230.0), f2 = 1.0 - smoothstep(0.55, 1.0, pw * 340.0), f3 = 1.0 - smoothstep(0.60, 1.05, pw * 520.0);
    float vis = 1.0;
    vec3 st = starLayer(starDir, 20.0, 0.945, 0.060, 0.8, 3.2, 0.35, vis, pw, 0.22, scint)
            + starLayer(starDir, 46.0, 0.860 - 0.10 * cr, 0.085, 0.42, 1.9, 0.0, vis, pw, 0.20, scint)
            + starLayer(starDir, 105.0, 0.820 - 0.25 * cr, 0.105, 0.26, 1.1, 0.0, vis, pw, 0.24 + 0.2 * cr, scint)
            + starLayer(starDir, 230.0, 0.860 - 0.50 * cr, 0.140, 0.16, 0.6, 0.0, vis, pw, 0.30 + 0.3 * cr, scint) * f1 * (0.7 + 0.9 * cr)
            + starLayer(starDir, 340.0, 0.880 - 0.64 * cr, 0.150, 0.13, 0.5, 0.0, vis, pw, 0.35 + 0.35 * cr, scint) * f2 * (0.6 + 1.3 * cr)
            + starLayer(starDir, 520.0, 0.900 - 0.66 * cr, 0.170, 0.10, 0.4, 0.0, vis, pw, 0.45 + 0.4 * cr, scint) * f3 * (0.5 + 1.6 * cr);
    st += wanderer(starDir, vec3(0.62, 0.34, -0.70), 0.0011, vec3(1.0, 0.93, 0.80), 1.0, pw, vis)
        + wanderer(starDir, vec3(-0.50, 0.46, 0.73), 0.0009, vec3(1.0, 0.72, 0.58), 0.7, pw, vis)
        + wanderer(starDir, vec3(0.08, 0.66, 0.75), 0.0009, vec3(0.85, 0.92, 1.0), 0.6, pw, vis);
    col += st * nebBoost;
    col += andromeda(starDir, pw) * 0.55;
    return col;
}

// drifting fragments of the ship: flecks of metal and the odd spark crossing the glass, which gives the eye a sense of scale and speed
vec3 debris(vec2 uv, float t) {
    vec3 c = vec3(0.0);
    for (int L = 0; L < 3; L++) {
        float fl = float(L);
        vec2 g = uv * vec2(7.0 + fl * 5.0, 4.0 + fl * 3.0) + vec2(t * (0.35 + fl * 0.22), -t * 0.07 * (fl + 1.0));
        vec2 id = floor(g); vec2 f = fract(g) - 0.5;
        float h = hash(vec3(id, fl * 9.1));
        if (h > 0.86) {
            vec2 off = (vec2(hash(vec3(id, 1.3 + fl)), hash(vec3(id, 2.9 + fl))) - 0.5) * 0.6;
            float d = length(f - off);
            float sz = 0.03 + 0.05 * hash(vec3(id, 5.5));
            float glint = 0.5 + 0.5 * sin(t * (2.0 + 6.0 * hash(vec3(id, 7.7))) + h * 40.0);
            c += mix(vec3(0.55, 0.60, 0.68), vec3(1.0, 0.55, 0.2), step(0.93, h)) * smoothstep(sz, sz * 0.3, d) * (0.15 + 0.85 * glint);
        }
    }
    return c;
}

// ------------------------------------------------------------------ scattering shell (works from inside or outside)
vec4 shellGlow(vec3 ro, vec3 rd, float tHit, float R, float H, vec3 sun, vec3 cool, vec3 warm, float k) {
    vec2 ts = raySphere(ro, rd, R + H);
    if (ts.y < 0.0) return vec4(0.0);
    float t0 = max(ts.x, 0.0);
    float t1 = tHit > 0.0 ? tHit : ts.y;
    float path = max(t1 - t0, 0.0);
    float tm = clamp(-dot(ro, rd), t0, t1);
    vec3 pm = ro + rd * tm;
    float hgt = max(length(pm) - R, 0.0) / H;
    float dens = exp(-hgt * 3.2);
    float tau = (path / R) * dens * k;
    float a = 1.0 - exp(-tau);
    vec3 side = normalize(pm);
    float lit = dot(side, sun);
    float lightSide = smoothstep(-0.30, 0.55, lit);
    vec3 col = mix(warm, cool, smoothstep(0.02, 0.80, lit));
    col *= 0.12 + 1.15 * lightSide;
    return vec4(col, min(a * lightSide * 0.9, 0.9));
}

// ------------------------------------------------------------------ the moon (NewTerra)
float moonHeight(vec3 n, float pix) {
    float h = fbm4(n * 2.1 + vec3(3.1, 1.7, 5.2)) * 0.72 + fbm3(n * 5.6 + vec3(9.0, 2.0, 1.0)) * 0.28;
    h += lodNoise(n, 22.0, pix, 0.11);
    return h;
}
float cloudDensity(vec3 n, float pix) {
    vec3 q = n * 3.2;
    vec3 w = vec3(fbm3(q * 1.3 + 4.0), fbm3(q * 1.3 + 11.0), fbm3(q * 1.3 + 23.0)) - 0.5;
    float c = fbm4(q + w * 1.6 + vec3(0.0, 0.0, uTime * 0.003));
    c += lodNoise(n, 14.0, pix, 0.22);
    return smoothstep(0.56, 0.76, c);
}
vec3 moonShade(vec3 n, float pix, vec3 V) {
    const float SL = 0.52;
    vec3 L = uSun;
    float ndl = dot(n, L);
    float h = moonHeight(n, pix);
    float lat = abs(dot(n, normalize(vec3(0.12, 0.96, 0.25))));
    float ice = smoothstep(0.80, 0.90, lat + (noise(n * 9.0) - 0.5) * 0.09);
    float landMask = smoothstep(SL - 0.004, SL + 0.004, h);
    // ocean: crystal turquoise shallows into deep blue
    float d = max(SL - h, 0.0);
    float shallow = 1.0 - smoothstep(0.0, 0.075, d);
    vec3 ocean = mix(vec3(0.004, 0.030, 0.095), vec3(0.030, 0.300, 0.330), shallow * shallow);
    // land
    float e = clamp((h - SL) / 0.28, 0.0, 1.0);
    float mo = fbm3(n * 3.7 + vec3(7.1, 3.3, 1.9)) + lodNoise(n, 40.0, pix, 0.10);
    mo -= 0.13 * exp(-pow((lat - 0.35) / 0.15, 2.0));
    vec3 dry = vec3(0.30, 0.23, 0.11), grass = vec3(0.085, 0.21, 0.05), lush = vec3(0.032, 0.125, 0.034);
    vec3 land = mix(dry, mix(grass, lush, smoothstep(0.50, 0.70, mo)), smoothstep(0.38, 0.52, mo));
    land = mix(vec3(0.46, 0.40, 0.26), land, smoothstep(0.0, 0.05, e));                       // sandy shores
    float rockiness = smoothstep(0.42, 0.78, e + lodNoise(n, 60.0, pix, 0.25));
    land = mix(land, vec3(0.27, 0.24, 0.21), rockiness);
    float snow = smoothstep(0.66, 0.86, e + lodNoise(n, 90.0, pix, 0.2));
    land = mix(land, vec3(0.86, 0.89, 0.93), max(snow, ice));
    vec3 albedo = mix(mix(ocean, vec3(0.80, 0.86, 0.90), ice), land, landMask);
    float water = (1.0 - landMask) * (1.0 - ice);

    // v82 relief: a real bumped normal from the height field (two neighbours), so ridges, coasts and valleys catch and lose the light. Land only.
    vec3 nd = n; float relief = 1.0;
    if (landMask > 0.3) {
        vec3 T1 = normalize(cross(n, vec3(0.0, 1.0, 0.013))), T2 = cross(n, T1);
        float eps = max(pix * 2.5, 0.0009);
        float hx = moonHeight(normalize(n + T1 * eps), pix), hy = moonHeight(normalize(n + T2 * eps), pix);
        vec3 g = (T1 * (hx - h) + T2 * (hy - h)) / eps;
        nd = normalize(n - g * 0.16 * clamp(0.0006 / eps + 0.6, 0.6, 3.0));
        relief = 0.80 + 0.30 * smoothstep(0.52, 0.60, h);
    }
    float bump = mix(1.0, clamp(dot(nd, L) / max(ndl, 0.05), 0.35, 1.9), landMask * smoothstep(0.02, 0.25, ndl));
    // clouds, and the shadow they throw
    float cd = cloudDensity(n, pix);
    vec3 nShadow = normalize(n - normalize(L - n * dot(L, n) + 1e-4) * 0.012);
    float cs = cloudDensity(nShadow, pix);
    albedo *= 1.0 - 0.45 * cs * (1.0 - cd);

    float diff = max(ndl, 0.0);
    float lit = smoothstep(-0.10, 0.22, ndl);
    vec3 sunCol = mix(vec3(1.0, 0.62, 0.34), vec3(1.0, 0.96, 0.90), smoothstep(0.0, 0.35, ndl));
    vec3 col = albedo * relief * (diff * bump * 2.7 * sunCol + vec3(0.05, 0.075, 0.12) * lit) + albedo * vec3(0.030, 0.021, 0.015) * (1.0 - lit);
    // sun glint on the water
    vec3 np = normalize(n + 0.0012 * (vec3(noise(n * 700.0), noise(n * 700.0 + 5.0), noise(n * 700.0 + 9.0)) - 0.5));
    vec3 Rf = reflect(-L, np);
    float spec = pow(max(dot(Rf, V), 0.0), 900.0) * 3.0 + pow(max(dot(Rf, V), 0.0), 40.0) * 0.05;
    col += vec3(1.0, 0.92, 0.80) * spec * water * (1.0 - cd) * step(0.0, ndl);
    // cloud tops
    vec3 cloudCol = vec3(0.92, 0.94, 0.97) * (diff * 2.7 * sunCol * (0.85 + 0.3 * (1.0 - cs)) + vec3(0.07, 0.09, 0.14) * lit) + vec3(0.004);
    col = mix(col, cloudCol, cd * 0.96);
    // v82 depth: a hazy blue limb on the lit side, a warm band along the terminator, a little limb darkening, and the glow the giant throws on the night side
    float ndv = max(dot(n, V), 0.0);
    col *= 0.72 + 0.28 * pow(ndv, 0.45);
    col += vec3(0.22, 0.46, 1.0) * pow(1.0 - ndv, 3.2) * 0.55 * smoothstep(-0.25, 0.35, ndl);
    col += vec3(1.0, 0.42, 0.16) * exp(-pow(ndl / 0.10, 2.0)) * (0.05 + 0.10 * cd) * (0.4 + albedo.g);
    // giant-shine: the gas giant fills a big part of the sky, and lights the moon's night side in warm amber (this is what you see of the moon from space)
    float gsh = max(dot(nd, normalize(uGC)), 0.0);
    col += (albedo * 0.8 + 0.02) * vec3(1.0, 0.55, 0.28) * gsh * (0.30 + 0.35 * cd) * (1.0 - 0.6 * lit);
    // a few cool pinpoints of light on the night side: the free cities of the Vale
    float nightMask = smoothstep(0.02, -0.22, ndl);
    float city = pow(noise(n * 110.0 + 3.0), 26.0) * 60.0 * landMask * (1.0 - cd);
    col += vec3(0.35, 0.70, 1.0) * city * nightMask * 0.35;
    return col;
}
vec3 renderMoon(vec3 ro, vec3 rd, float pixAng, vec3 bg) {
    vec2 th = raySphere(ro, rd, 1.0);
    float tHit = th.x > 0.0 ? th.x : -1.0;
    vec3 col = bg;
    if (tHit > 0.0) {
        vec3 n = normalize(ro + rd * tHit);
        col = moonShade(n, tHit * pixAng, -rd);
    }
    // while still low, a second, nearer layer of cloud streaks past above the first: parallax that sells the height
    float alt = length(ro) - 1.0;
    if (alt < 0.25) {
        vec2 t2 = raySphere(ro, rd, 1.009);
        float tc = t2.x > 0.0 ? t2.x : t2.y;
        if (tc > 0.0 && (tHit < 0.0 || tc < tHit)) {
            vec3 n2 = normalize(ro + rd * tc);
            float c2 = fbm4(n2 * 6.0 + vec3(31.0, 7.0, 2.0)) + lodNoise(n2, 30.0, tc * pixAng, 0.2);
            float d2 = smoothstep(0.58, 0.80, c2) * (1.0 - smoothstep(0.10, 0.25, alt));
            col = mix(col, vec3(0.93, 0.95, 0.98) * (max(dot(n2, uSun), 0.0) * 2.7 + 0.12), d2 * 0.9);
        }
    }
    vec4 a = shellGlow(ro, rd, tHit, 1.0, 0.06, uSun, vec3(0.40, 0.60, 1.0), vec3(1.0, 0.48, 0.20), 1.7);
    return mix(col, a.rgb, a.a);
}

// ------------------------------------------------------------------ the gas giant (ported from the in-game sky planet, plus close-range cloud detail)
vec3 gasSurface(vec3 n, vec3 V, float pix) {
    vec3 sunDir = uSun;
    float NdotL = dot(n, sunDir);
    vec3 q = vec3(dot(n, uE1), dot(n, uPole), dot(n, uE2));
    float lat = q.y;
    float lon = atan(q.z, q.x);
    float aLat = abs(lat);
    float drift = time * 0.00032 * (0.55 * sin(lat * 7.0) + 0.9 * cos(lat * 3.1 + 0.6) + 0.35);
    float lo = lon + drift;
    float rCos = cos(wrapPi(lon - uRiftLon));
    float rMask = smoothstep(-0.05, 0.25, rCos);
    vec2 rp = vec2(sqrt(max(1.0 - lat * lat, 0.0)) * sin(wrapPi(lon - uRiftLon - time * 0.00003)), lat);
    vec2 rw = vec2(fbm3(vec3(rp * 2.4 + 2.0, time * 0.004)), fbm3(vec3(rp * 2.4 + 9.0, time * 0.004 + 5.0))) - 0.5;
    const vec2 rA = vec2(0.7071, -0.7071);
    const vec2 rB = vec2(0.7071, 0.7071);
    const vec2 rC = vec2(-0.02, 0.05);
    vec2 rq = rp + rw * 0.30;
    for (int i = 0; i < 8; i++) {
        float fi = float(i);
        vec2 cen = rC + rA * ((fi - 3.5) * 0.19 + (hash1(fi * 3.7 + 1.0) - 0.5) * 0.10) + rB * ((hash1(fi * 7.1 + 4.0) - 0.5) * 0.24);
        float rad = 0.07 + 0.08 * hash1(fi * 5.9 + 2.0);
        float spin = (hash1(fi * 2.3 + 8.0) > 0.5 ? 1.0 : -1.0) * (2.6 + 1.8 * hash1(fi * 1.7 + 3.0));
        vec2 dv = rq - cen;
        float fall = exp(-dot(dv, dv) / (rad * rad));
        float ang = spin * fall + time * 0.0010 * spin * fall;
        float cs = cos(ang), sn = sin(ang);
        rq = cen + vec2(cs * dv.x - sn * dv.y, sn * dv.x + cs * dv.y);
    }
    vec2 rr = rp + rw * 0.14 - rC;
    float rAl = dot(rr, rA), rAc = dot(rr, rB);
    rAc += (fbm3(vec3(rq * 3.0 + 5.0, 2.0)) - 0.5) * 0.22;
    float rAlE = smoothstep(-0.80, -0.46, rAl) * (1.0 - smoothstep(0.50, 0.88, rAl));
    float rSw = exp(-(rAc * rAc) / (0.25 * 0.25)) * rAlE;
    float riftInfl = exp(-(rAc * rAc) / (0.40 * 0.40)) * rAlE * rMask;

    float turbA = fbm3(pc(lo, lat, 1.6, 7.0) + vec3(0.0, 0.0, time * 0.004));
    float u = (lat + (turbA - 0.5) * 0.085 + riftInfl * (rw.x * 0.55 + rw.y * 0.35)) * 15.0;
    float id = floor(u), f = fract(u);
    float edge = 1.0 - abs(2.0 * f - 1.0);
    float kh = fbm3(pc(lo * 3.0, lat, 3.2, 40.0) + 4.0) - 0.5;
    u += kh * 0.55 * (1.0 - edge) * (1.0 - edge);
    id = floor(u); f = fract(u);
    float t0 = hash1(id * 3.17 + 1.3), t1 = hash1((id + 1.0) * 3.17 + 1.3);
    float tone = mix(t0, t1, smoothstep(0.30, 0.70, f));
    float fine = fbm(pc(lo * 2.0, lat, 5.0, 70.0));
    float cells = fbm3(pc(lo, lat, 11.0, 26.0) + time * 0.01);
    tone = clamp(tone * 0.72 + (fine - 0.5) * 0.55 + (cells - 0.5) * 0.22 + 0.14, 0.0, 1.0);

    vec3 cDeep  = vec3(0.17, 0.095, 0.075);
    vec3 cRust  = vec3(0.47, 0.22, 0.13);
    vec3 cOchre = vec3(0.71, 0.45, 0.21);
    vec3 cCream = vec3(0.86, 0.73, 0.54);
    vec3 cIvory = vec3(0.93, 0.88, 0.76);
    vec3 baseCol = mix(cDeep, cRust, smoothstep(0.05, 0.38, tone));
    baseCol = mix(baseCol, cOchre, smoothstep(0.30, 0.60, tone));
    baseCol = mix(baseCol, cCream, smoothstep(0.55, 0.82, tone));
    baseCol = mix(baseCol, cIvory, smoothstep(0.80, 1.0, tone));
    vec3 slate = vec3(0.30, 0.37, 0.46);
    float cool = smoothstep(0.38, 0.86, aLat) * (0.35 + 0.5 * fbm3(pc(lo, lat, 2.0, 9.0) + 8.0));
    baseCol = mix(baseCol, slate * (0.55 + tone * 0.75), clamp(cool, 0.0, 0.75));

    float rHalo = exp(-(rAc * rAc) / (0.42 * 0.42)) * rAlE * rMask;
    float rTex = fbm3(vec3(rq * 6.5, time * 0.006 + 3.0)) * 0.55 + fbm3(vec3(rq * 15.0 + 4.0, time * 0.012)) * 0.30 + fbm3(vec3(rq * 34.0 + 9.0, time * 0.02)) * 0.15;
    float rCore = smoothstep(0.44, 0.60, rTex + (rSw - 0.5) * 0.30) * rSw * rMask;
    float rCurl = (1.0 - smoothstep(0.0, 0.09, abs(rTex - 0.50))) * rHalo;
    float rBillow = smoothstep(0.50, 0.70, rTex) * (1.0 - smoothstep(0.70, 0.92, rTex)) * rHalo;
    float rLip = max(rCurl * 0.9, rBillow * 0.8);
    float rRip = 0.5 + 0.5 * sin(rTex * 22.0 - time * 0.05 + rAc * 6.0);
    float rBolt;
    {
        float ft = uTime * 1.6, f0 = floor(ft);
        float n0 = noise(vec3(rq * 13.0, f0 * 3.7)), n1 = noise(vec3(rq * 13.0, (f0 + 1.0) * 3.7));
        float nn = mix(n0, n1, smoothstep(0.0, 1.0, fract(ft)));
        rBolt = smoothstep(0.70, 0.90, nn) * (rCore * 0.85 + rCurl * 0.7);
    }
    vec3 rCoreCol = mix(vec3(0.17, 0.08, 0.09), vec3(0.42, 0.20, 0.24), smoothstep(0.30, 0.85, rTex * 0.8 + rRip * 0.25));
    vec3 rHaloCol = mix(baseCol, vec3(0.62, 0.40, 0.42) * (0.55 + 0.65 * tone), 0.45);
    baseCol = mix(baseCol, rHaloCol, rHalo * 0.50);
    baseCol = mix(baseCol, rCoreCol, rCore * 0.85);
    baseCol = mix(baseCol, mix(vec3(0.95, 0.88, 0.80), vec3(0.80, 0.70, 0.95), rCurl), rLip * 0.62 * (0.50 + 0.50 * rRip));
    for (int i = 0; i < 6; i++) {
        float fi = float(i);
        float oLat = (hash1(fi * 7.7 + 2.0) - 0.5) * 1.5;
        float oLon = hash1(fi * 5.3 + 9.0) * 6.2831853 - 3.1415927 + time * 0.00008 * (1.0 + oLat);
        vec2 od = vec2(wrapPi(lo - oLon) * 1.2, (lat - oLat) * 6.5);
        float orr = length(od);
        float ov = 1.0 - smoothstep(0.10, 0.30, orr);
        float sw = 0.5 + 0.5 * sin(atan(od.y, od.x) * 2.0 + orr * 30.0);
        vec3 ovCol = i < 3 ? mix(vec3(0.86, 0.82, 0.72), vec3(0.97, 0.94, 0.86), sw) : mix(vec3(0.42, 0.20, 0.12), vec3(0.58, 0.32, 0.18), sw);
        baseCol = mix(baseCol, ovCol, ov * 0.80 * (1.0 - clamp(rHalo * 1.4, 0.0, 1.0)));
    }
    float pole = smoothstep(0.84, 0.985, aLat);
    float hexR = abs(aLat - (0.90 + 0.012 * cos(6.0 * lo + time * 0.01)));
    float hexRing = 1.0 - smoothstep(0.0, 0.016, hexR);
    baseCol = mix(baseCol, vec3(0.20, 0.26, 0.34) * (0.7 + 0.5 * fbm3(pc(lo, lat, 4.0, 20.0) + 3.0)), pole * 0.85);
    baseCol += vec3(0.20, 0.24, 0.30) * hexRing * 0.22 * smoothstep(0.78, 0.9, aLat);
    float tone2 = fbm(pc(lo + 0.02, lat, 5.0, 70.0));
    baseCol *= 0.86 + 0.28 * smoothstep(-0.12, 0.12, tone2 - fine);

    // close range: the same cloud deck, but billowing - warped detail octaves that only appear once we are near enough to resolve them
    float near = 1.0 - smoothstep(0.0006, 0.004, pix);
    if (near > 0.001) {
        vec3 w = vec3(fbm3(n * 30.0 + 1.0), fbm3(n * 30.0 + 7.0), fbm3(n * 30.0 + 13.0)) - 0.5;
        vec3 np = normalize(n + w * 0.018);
        float dd = lodNoise(np, 55.0, pix, 1.2) + lodNoise(np, 400.0, pix, 0.8);
        baseCol *= 1.0 + clamp(dd * 0.8, -0.4, 0.4) * near;
        baseCol = mix(baseCol, baseCol * vec3(1.25, 0.9, 0.7), clamp(dd, 0.0, 0.5) * near);
    }

    float lightAmt = smoothstep(-0.22, 0.42, NdotL);
    float tbN = (NdotL - 0.04) / 0.20; float termBand = exp(-tbN * tbN);
    vec3 nightSideCol = baseCol * vec3(0.060, 0.050, 0.060) + vec3(0.004, 0.005, 0.009);
    vec3 dayCol = baseCol * (0.55 + 0.55 * clamp(NdotL, 0.0, 1.0));
    vec3 finalCol = mix(nightSideCol, dayCol, lightAmt);
    finalCol += vec3(0.62, 0.26, 0.10) * termBand * 0.20 * smoothstep(-0.2, 0.3, NdotL + 0.25) * (0.4 + 0.6 * tone);
    float vn = max(dot(n, V), 0.0);
    float limbDark = pow(vn, 0.45);
    finalCol *= mix(0.45, 1.0, limbDark);
    float fres = pow(1.0 - vn, 2.6);
    float sunSide = clamp(NdotL * 1.3 + 0.35, 0.0, 1.0);
    vec3 veil = mix(vec3(0.85, 0.46, 0.24), vec3(0.50, 0.66, 0.92), smoothstep(0.1, 0.8, NdotL));
    finalCol += veil * fres * sunSide * 0.42;
    finalCol += vec3(0.50, 0.42, 0.90) * rBolt * (0.30 + 0.70 * (1.0 - lightAmt)) * 0.75;
    return min(finalCol, vec3(1.3));
}
vec3 renderGiant(vec3 ro, vec3 rd, float pixAng, vec3 bg) {
    vec2 th = raySphere(ro, rd, 1.0);
    float tHit = th.x > 0.0 ? th.x : -1.0;
    vec3 col = bg;
    if (tHit > 0.0) {
        vec3 n = normalize(ro + rd * tHit);
        col = gasSurface(n, -rd, tHit * pixAng);
    }
    col *= 0.50;
    vec3 cool = mix(vec3(0.62, 0.40, 0.26), vec3(0.95, 0.40, 0.10), uHeat);
    vec3 warm = mix(vec3(0.80, 0.38, 0.18), vec3(0.95, 0.28, 0.05), uHeat);
    vec4 a = shellGlow(ro, rd, tHit, 1.0, 0.15, uSun, cool, warm, 1.8 + 1.8 * uHeat);
    return mix(col, a.rgb * (0.50 + uHeat * 0.22), a.a * (tHit > 0.0 ? 0.30 : 0.80));
}

// ------------------------------------------------------------------ inside the storm
vec3 stormInside(vec2 uv, float t) {
    float rad = length(uv);
    vec3 col = mix(vec3(0.085, 0.030, 0.010), vec3(0.003, 0.0015, 0.001), smoothstep(0.0, 1.4, rad));
    for (int i = 0; i < 6; i++) {
        float z = fract(t * 0.24 + float(i) / 6.0);
        float m = mix(5.0, 0.45, z);
        vec2 p = uv * m + vec2(float(i) * 3.7, float(i) * 1.3);
        vec3 q = vec3(p, float(i) * 2.9 + t * 0.09);
        vec3 w = vec3(fbm3(q + 3.0), fbm3(q + 8.0), 0.0) - 0.5;
        float dn = fbm(q + vec3(w.xy * 1.2, 0.0));
        float dens = smoothstep(0.25, 0.85, dn);
        float fade = smoothstep(0.0, 0.22, z) * (1.0 - smoothstep(0.78, 1.0, z));
        float rim = smoothstep(0.50, 0.62, dn) * (1.0 - smoothstep(0.62, 0.80, dn));
        vec3 lc = mix(vec3(0.006, 0.003, 0.0025), vec3(0.30, 0.095, 0.022), rim * 0.7);
        lc += vec3(0.50, 0.38, 0.85) * uFlash * 0.16 * (0.3 + rim);
        col = mix(col, lc, dens * fade * 0.9);
    }
    float ang = atan(uv.y, uv.x);
    float st = noise(vec3(ang * 30.0, rad * 0.9 - t * 8.0, 3.0));
    col += vec3(1.0, 0.40, 0.10) * smoothstep(0.86, 0.99, st) * smoothstep(0.8, 1.6, rad) * 0.12;
    // a jagged bolt: a bright thread with a soft glow, wandering down the glass
    if (uBolt > 0.0) {
        float bx = uv.x - (hash1(uBolt * 3.3) * 1.6 - 0.8) - 0.22 * sin(uv.y * 2.3 + uBolt) - 0.10 * (noise(vec3(uv.y * 9.0, uBolt, 1.0)) - 0.5) * 2.0;
        float core = exp(-abs(bx) * 90.0), glow = exp(-abs(bx) * 7.0);
        col += vec3(0.85, 0.80, 1.0) * (core * 3.0 + glow * 0.35) * min(uFlash, 1.5);
    }
    return col;
}

// ------------------------------------------------------------------ tone-mapping (same ACES as the game's renderer, exposure 1.22)
vec3 RRTAndODTFit(vec3 v) { vec3 a = v * (v + 0.0245786) - 0.000090537; vec3 b = v * (0.983729 * v + 0.4329510) + 0.238081; return a / b; }
vec3 aces(vec3 color) {
    const mat3 inM = mat3(vec3(0.59719, 0.07600, 0.02840), vec3(0.35458, 0.90834, 0.13383), vec3(0.04823, 0.01566, 0.83777));
    const mat3 outM = mat3(vec3(1.60475, -0.10208, -0.00327), vec3(-0.53108, 1.10813, -0.07276), vec3(-0.07367, -0.00605, 1.07602));
    color *= 1.22 / 0.6;
    color = inM * color; color = RRTAndODTFit(color); color = outM * color;
    return clamp(color, 0.0, 1.0);
}
vec3 toSRGB(vec3 c) { return mix(c * 12.92, 1.055 * pow(c, vec3(1.0 / 2.4)) - 0.055, step(0.0031308, c)); }

// ------------------------------------------------------------------ two bodies in space (nearer one drawn over the farther)
vec3 renderSpace(vec3 ro, vec3 rd, float pixAng, vec3 bg) {
    float dg = length(ro - uGC), dm = length(ro);
    vec3 col = bg;
    if (dg > dm) { col = renderGiant((ro - uGC) / uRG, rd, pixAng, col); col = renderMoon(ro, rd, pixAng, col); }
    else         { col = renderMoon(ro, rd, pixAng, col); col = renderGiant((ro - uGC) / uRG, rd, pixAng, col); }
    return col;
}

// ------------------------------------------------------------------ the cockpit: a real little room, raytraced from the pilot's head
const float ZF = 1.55, XS = 1.6, YC = 1.1, YF = -1.0, ZB = -1.3, YD = -0.45, ZD = 0.85;
float hash21(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float sdRR(vec2 p, vec2 b, float r) { vec2 q = abs(p) - b + r; return length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - r; }
float frontWin(vec2 p) { float w = sdRR(p - vec2(0.0, 0.22), vec2(1.12, 0.62), 0.40); float st = abs(p.x - 0.20) - 0.05; return max(w, -st); }
float sideWin(vec2 zy) { return sdRR(zy - vec2(0.78, 0.28), vec2(0.55, 0.26), 0.14); }
vec3 panelCol(vec2 p, float seed) {
    vec2 g = p * vec2(2.0, 1.6) + seed * 3.7; vec2 id = floor(g), f = fract(g);
    float seam = min(min(f.x, 1.0 - f.x), min(f.y, 1.0 - f.y));
    float s = 1.0 - smoothstep(0.0, 0.04, seam);
    float tone = 0.55 + 0.45 * hash21(id + seed);
    float rivet = (1.0 - smoothstep(0.015, 0.03, length(f - vec2(0.07)))) + (1.0 - smoothstep(0.015, 0.03, length(f - vec2(0.93, 0.07))));
    float grime = 0.75 + 0.5 * noise(vec3(p * 7.0, seed));
    vec3 c = vec3(0.060, 0.066, 0.075) * tone * grime;
    c *= 1.0 - 0.85 * s; c += vec3(0.05) * rivet;
    return c;
}
float crackMask(vec2 p, vec2 o, float lvl) {
    if (lvl <= 0.0) return 0.0;
    vec2 q = (p - o) * 3.2; vec2 ip = floor(q), fp = fract(q); float m1 = 8.0, m2 = 8.0;
    for (int j = -1; j <= 1; j++) for (int i = -1; i <= 1; i++) {
        vec2 g = vec2(float(i), float(j)); vec2 r = g + vec2(hash21(ip + g), hash21(ip + g + 7.7)) - fp; float dd = dot(r, r);
        if (dd < m1) { m2 = m1; m1 = dd; } else if (dd < m2) m2 = dd;
    }
    float line = 1.0 - smoothstep(0.0, 0.028, sqrt(m2) - sqrt(m1));
    float rr = length(p - o) / (0.22 + 0.22 * lvl);
    return line * exp(-rr * rr);
}
vec3 cockpit(vec3 P, vec3 d, out float see, out vec3 wd, out vec2 wp) {
    see = 0.0; wd = d; wp = vec2(0.0);
    float t = 1e9; int pl = 0;
    if (d.z > 1e-4)  { float x = (ZF - P.z) / d.z;  if (x < t) { t = x; pl = 1; } }
    if (d.z < -1e-4) { float x = (ZB - P.z) / d.z;  if (x < t) { t = x; pl = 2; } }
    if (d.x > 1e-4)  { float x = (XS - P.x) / d.x;  if (x < t) { t = x; pl = 3; } }
    if (d.x < -1e-4) { float x = (-XS - P.x) / d.x; if (x < t) { t = x; pl = 4; } }
    if (d.y > 1e-4)  { float x = (YC - P.y) / d.y;  if (x < t) { t = x; pl = 5; } }
    if (d.y < -1e-4) { float x = (YF - P.y) / d.y;  if (x < t) { t = x; pl = 6; } }
    if (d.y < -1e-4 && P.y > YD) { float x = (YD - P.y) / d.y; vec3 h = P + d * x; if (x < t && h.z > ZD && h.z < ZF && abs(h.x) < XS) { t = x; pl = 7; } }
    if (d.z > 1e-4 && P.z < ZD)  { float x = (ZD - P.z) / d.z; vec3 h = P + d * x; if (x < t && h.y < YD && h.y > YF && abs(h.x) < XS) { t = x; pl = 8; } }
    vec3 H = P + d * t;
    vec3 n; vec2 pp; float seed = float(pl); float win = 1e3;
    if (pl == 1) { n = vec3(0, 0, -1); pp = H.xy; win = frontWin(H.xy); if (win < 0.0) { see = 1.0; wp = H.xy; return vec3(0.0); } }
    else if (pl == 3 || pl == 4) { n = vec3(pl == 3 ? -1.0 : 1.0, 0, 0); pp = H.zy; win = sideWin(H.zy); if (win < 0.0) { see = 2.0; wp = H.zy; return vec3(0.0); } }
    else if (pl == 2) { n = vec3(0, 0, 1); pp = H.xy; }
    else if (pl == 5) { n = vec3(0, -1, 0); pp = H.xz; }
    else if (pl == 6) { n = vec3(0, 1, 0); pp = H.xz; }
    else if (pl == 7) { n = vec3(0, 1, 0); pp = H.xz; }
    else { n = vec3(0, 0, -1); pp = H.xy; }
    vec3 alb = panelCol(pp, seed);
    vec3 emis = vec3(0.0);
    if (pl == 8) { float vent = step(0.5, fract(H.x * 9.0)) * step(0.55, fract(H.y * 3.0)); alb *= 1.0 - 0.6 * vent; }
    if (pl == 5) { float strip = 1.0 - smoothstep(0.05, 0.09, abs(H.x)); emis += vec3(0.30, 0.34, 0.40) * strip * 0.06 * (0.6 + 0.4 * uAlarm); }
    if (pl == 7) {
        vec2 sp = H.xz;
        for (int i = 0; i < 4; i++) {
            float cx = i == 0 ? -1.10 : (i == 1 ? -0.58 : (i == 2 ? 0.66 : 1.16));
            vec2 q = (sp - vec2(cx, 1.12)) / vec2(0.20, 0.15);
            if (abs(q.x) < 1.0 && abs(q.y) < 1.0) {
                float bars = step(0.40, noise(vec3(q.x * 6.0, floor(q.y * 7.0), floor(uTime * 3.0) + float(i))));
                vec3 sc = (i % 2 == 0) ? vec3(1.0, 0.55, 0.15) : vec3(0.10, 0.70, 1.0);
                sc = mix(sc, vec3(1.0, 0.12, 0.06), uAlarm * 0.8);
                emis += sc * (0.05 + 0.20 * bars) * (1.0 - smoothstep(0.80, 1.0, max(abs(q.x), abs(q.y))));
            }
        }
        float led = step(abs(H.z - 1.46), 0.018) * step(abs(fract(H.x * 7.0) - 0.5), 0.12);
        float lid = floor(H.x * 7.0);
        float on = step(0.5, fract(uTime * (0.6 + hash21(vec2(lid, 3.0))) + hash21(vec2(lid, 8.0))));
        emis += led * on * mix(vec3(0.20, 0.9, 0.35), vec3(1.0, 0.25, 0.1), step(0.5, hash21(vec2(lid, 5.0)))) * 0.35;
    }
    // light: what comes in through the window, plus the red alarm, plus the screens' own glow
    vec3 W = vec3(0.0, 0.25, ZF - 0.2);
    vec3 toW = W - H; float dW = length(toW);
    float wl = max(dot(n, toW / dW), 0.10) * (1.6 / (1.0 + 0.9 * dW * dW));
    float pulse = 0.35 + 0.65 * max(0.0, sin(uTime * 6.2));
    vec3 A = vec3(0.0, -0.2, 1.2); float dA = length(A - H);
    vec3 col = alb * (uCabin * (0.20 + wl) + vec3(0.010, 0.012, 0.016) + vec3(1.0, 0.10, 0.05) * uAlarm * pulse * 0.55 / (1.0 + 1.2 * dA * dA)) + emis;
    col += vec3(0.75, 0.65, 1.0) * uFlash * 0.05 * wl;
    float rim = (1.0 - smoothstep(0.0, 0.07, win)) * step(0.0, win);
    col += uCabin * vec3(0.9, 0.95, 1.0) * rim * 0.22 + vec3(0.02) * rim;
    col *= 1.0 - 0.9 * (1.0 - smoothstep(0.0, 0.012, win)) * step(0.0, win) * 0.5;
    return col;
}

// ------------------------------------------------------------------ the cloud deck: a real multi-scale volume (v83)
// Units are giant radii (1 R = 136,000 km, so 0.001 = 136 km). The nominal cloud tops sit at 1.0; billows rise to ~1.004 and the deck is solid by ~0.975.
// Detail octaves run from 14,000 km down to ~5 km and each fades out when it is smaller than a pixel, so from 100 km up the tops look as flat, vast and
// finely billowed as a real cloud sea, while from orbit it is just a soft skin. It fades in over the exterior surface as the ship comes down.
const float CT = 1.0, CT_OUT = 1.004, CT_IN = 0.975;
float cloudLump(vec3 p, float fp, bool full) {      // billow height field, -0.6..0.6; every octave fades out when it is smaller than a pixel
    vec3 q = p * 7.0 + vec3(0.011, 0.0, 0.017) * uTime;   // the pattern is fixed in the world; only a slow weather drift
    float lump = (noise(q * 1.4) - 0.5) * 0.9;
    const mat3 ROT = mat3(0.80, -0.48, 0.36, 0.60, 0.64, -0.48, 0.0, 0.60, 0.80);   // turns every octave so the value-noise lattice never lines up
    float lat = dot(p, uPole);
    float bw = 1.0 - smoothstep(0.07, 0.30, fp * 90.0);
    lump += bw * 0.50 * (noise(vec3(lat * 90.0, noise(p * 16.0) * 2.5, 0.5)) - 0.5);        // thin east-west shear lines (the jet-stream stripes)
    lump += (1.0 - smoothstep(0.07, 0.30, fp * 30.0)) * 0.45 * (noise(vec3(lat * 30.0, noise(p * 7.0) * 2.0, 4.5)) - 0.5);   // and the wider belts
    vec3 pp = p;
    float f = 70.0, a = 1.1;
    for (int i = 0; i < 5; i++) {
        if (!full && i > 2) break;
        float w = 1.0 - smoothstep(0.07, 0.30, fp * f);   // an octave only shows while its cells are several pixels wide (no aliased grain)
        if (w <= 0.002) break;
        lump += a * (noise(pp * f + float(i) * 5.7) - 0.5) * w;
        pp = ROT * pp; f *= 4.4; a *= 0.19;   // amplitude follows wavelength, so the slope (and the texture) is the same at every scale
    }
    return lump;
}
float cloudDens(vec3 p, float fp, bool full) {
    float y = CT - length(p);                          // depth below the nominal tops
    if (y < -0.0041) return 0.0;
    float d = smoothstep(0.0, 0.0035, y + cloudLump(p, fp, full) * 0.0045);
    if (full) {      // below the tops the deck opens into canyons and caves (where the lightning lives)
        vec3 q = p * 7.0 + vec3(0.011, 0.0, 0.017) * uTime;
        float hm = smoothstep(0.30, 0.55, noise(q * 0.8 + 9.0) * 0.6 + noise(q * 2.6 + 4.0) * 0.4);
        d *= mix(1.0, hm, smoothstep(0.0012, 0.010, y));
    }
    return max(d, smoothstep(0.022, 0.040, y) * 0.65);
}
vec3 cloudVolume(vec3 ro, vec3 rd, vec3 far, float pixAng) {
    float rc = length(ro);
    float alt = rc - CT;
    float vw = 1.0 - smoothstep(0.015, 0.28, alt);      // fades in between ~38,000 km and ~2,000 km up
    if (vw <= 0.002) return far;
    vec2 th = raySphere(ro, rd, CT_OUT);
    float t0 = 0.0;
    if (rc > CT_OUT) { if (th.x < 0.0) return far; t0 = th.x; }
    vec2 ti = raySphere(ro, rd, CT_IN);
    float t1 = th.y, deepW = 0.0;
    if (rc > CT_IN) { if (ti.x > 0.0) { t1 = ti.x; deepW = 1.0; } } else deepW = 1.0;
    if (t1 <= t0) return far;
    vec3 bottom = vec3(0.060, 0.016, 0.008) * (1.0 + 2.0 * uFlash);
    vec3 farC = mix(far, bottom, deepW);
    vec3 bt = clamp(far / (dot(far, vec3(0.3333)) + 0.03), 0.55, 1.5);   // keeps the bands of the surface showing through at a distance
    float tintW = smoothstep(0.02, 0.22, alt);
    float sunW = smoothstep(0.0, 0.2, alt);
    float T = 1.0; vec3 acc = vec3(0.0);
    float jit = hash(vec3(gl_FragCoord.xy, uTime * 60.0)) * 0.35;   // small jitter: enough to hide the step bands, not enough to read as grain
    float L = min(t1 - t0, 0.016 / max(abs(dot(rd, normalize(ro + rd * t0))), 0.05));   // march only the zone where the deck has structure; the rest of a grazing ray is haze
    for (int i = 0; i < 32; i++) {
        float u = (float(i) + jit) / 32.0;
        float t = t0 + L * u * u;
        float dt = L * (2.0 * u / 32.0 + 1.0 / 2048.0);
        vec3 p = ro + rd * t;
        float fp = max(t, 1e-5) * pixAng;
        float dens = cloudDens(p, fp, true);
        if (dens > 0.004) {
            vec3 up = normalize(p);
            vec3 ld = normalize(uSun + up * 0.12);   // a low sun: billows throw long shadows across the cloud sea
            float dl = cloudDens(p + ld * 0.0015, fp, false) + 1.4 * cloudDens(p + ld * 0.0050, fp * 2.0, false) + 1.6 * cloudDens(p + ld * 0.0140, fp * 4.0, false);
            float sh = exp(-dl * 2.4);
            // bump-mapped relief: the slope of the billow field at pixel scale, so the deck is textured at EVERY distance (from orbit to 40 km)
            float eps = max(fp * 6.0, 3e-5);
            vec3 T1 = normalize(cross(up, vec3(0.0, 1.0, 0.013))), T2 = cross(up, T1);
            float l0 = cloudLump(p, fp, true), l1 = cloudLump(p + T1 * eps, fp, true), l2 = cloudLump(p + T2 * eps, fp, true);
            vec3 nrm = normalize(up + ((l1 - l0) * T1 + (l2 - l0) * T2) * (0.0045 * 26.0 / eps));
            float bump = clamp(0.30 + 1.25 * dot(nrm, ld), 0.10, 1.40);
            sh *= bump;
            float hh = clamp((CT - length(p) + 0.0035) / 0.0075, 0.0, 1.5);   // peaks bright, troughs and canyon walls deep orange to red
            vec3 lit = mix(vec3(1.0, 0.55, 0.22), vec3(0.62, 0.20, 0.08), smoothstep(0.0, 1.4, hh));
            vec3 c = mix(vec3(0.05, 0.016, 0.009), lit, clamp(sh, 0.0, 1.0)) * (0.16 + 0.95 * sh) * 0.60;
            c *= mix(1.0, clamp(dot(up, uSun) * 1.3 + 0.5, 0.45, 1.25), sunW);
            c *= mix(vec3(1.0), bt, tintW);
            c += vec3(0.60, 0.50, 0.95) * uFlash * 0.35 * (0.4 + 0.6 * (1.0 - clamp(sh, 0.0, 1.0)));
            c = mix(c, vec3(0.30, 0.14, 0.06), 0.50 * (1.0 - exp(-t * 3.0)));   // aerial haze toward the horizon
            float A = 1.0 - exp(-dens * dt * 4000.0);
            acc += T * A * c; T *= 1.0 - A;
            if (T < 0.02) break;
        }
    }
    return mix(far, acc + T * farC, vw);
}
// ------------------------------------------------------------------ v88: inside the cloud
// Below the tops the old volume was a solid, unlit slab, so the view went black. This is a lit, billowing fog you fly through: nearer masses are thin and
// streak past, the far end fills in as a glowing haze, the upper faces of the billows are lit orange and the undersides dark brown, and lightning lights
// whole banks from within. It drifts and sinks even after the ship has slowed, and never drops below a dim brown glow.
vec3 cloudInterior(vec3 rd) {
    vec3 O = uTravDir * (uTrav + uTime * 1.6) + vec3(0.33, 0.12, -0.21) * uTime;
    vec3 up = normalize(uCam - uGC);
    float fl = min(uFlash, 1.6);
    float upv = clamp(dot(rd, up), 0.0, 1.0), down = clamp(-dot(rd, up), 0.0, 1.0);
    vec3 farC = vec3(0.80, 0.30, 0.09) * (0.55 + 0.55 * upv + 1.10 * down) + vec3(0.45, 0.40, 0.85) * fl * 0.14;
    vec3 fogC = vec3(0.55, 0.20, 0.065) * (0.6 + 0.5 * upv + 0.7 * down);
    float T = 1.0; vec3 acc = vec3(0.0);
    float jit = hash(vec3(gl_FragCoord.xy, uTime * 60.0));
    for (int i = 0; i < 22; i++) {
        float u = (float(i) + jit) / 22.0;
        float t = 0.15 + 18.0 * u * u;
        float dt = 18.0 * (2.0 * u / 22.0) + 0.05;
        vec3 q = (O + rd * t) * 0.20;
        vec3 wq = vec3(noise(q * 1.7 + 3.0), noise(q * 1.7 + 8.0), noise(q * 1.7 + 1.0)) - 0.5;
        vec3 qq = q + wq * 1.4;
        float dn = fbm3(qq) * 0.82 + 0.18 * noise(qq * 4.0 + 5.0);
        float dens = smoothstep(0.38, 0.72, dn);
        float dn2 = fbm3(qq + up * 0.30) * 0.82 + 0.18 * noise((qq + up * 0.30) * 4.0 + 5.0);
        float dens2 = smoothstep(0.38, 0.72, dn2);                   // the same cloud a little higher: if it is thinner up there, this point is lit from above
        float sh = clamp(0.42 + 1.9 * (dens - dens2) + 0.30 * (1.0 - dens2), 0.0, 1.0);
        vec3 body = mix(vec3(0.30, 0.085, 0.030), vec3(1.30, 0.62, 0.22), sh) * (0.50 + 0.50 * sh);
        float pocket = smoothstep(0.80, 0.95, noise(q * 1.8 + vec3(0.0, 0.0, uTime * 2.2)));
        vec3 em = vec3(0.60, 0.52, 1.0) * (fl * 0.55 * (0.35 + 0.65 * (1.0 - sh)) + pocket * 0.30 * (0.4 + fl));
        float sig = 0.022 + dens * 0.30;
        float A = 1.0 - exp(-sig * dt);
        vec3 c = mix(fogC, body, clamp(dens * 1.3, 0.0, 1.0)) + em;
        acc += T * A * c; T *= 1.0 - A;
    }
    return acc + T * farC + vec3(0.035, 0.012, 0.005);
}
float boltJag(float y, float seed) {
    float j = 0.0, a = 0.17, f = 1.5;
    for (int i = 0; i < 4; i++) { j += a * (noise(vec3(y * f, seed + float(i) * 3.1, 0.0)) - 0.5) * 2.0; a *= 0.5; f *= 2.4; }
    return j;
}
vec3 boltOverlay(vec2 uv) {   // v85: a jagged main stroke, a forked branch, and a bloom of light in the cloud around it
    float seed = uBolt * 3.3, cx = hash1(seed) * 1.3 - 0.65;
    float bx = uv.x - cx - boltJag(uv.y, seed);
    float core = exp(-abs(bx) * 150.0), glow = exp(-abs(bx) * 10.0);
    float fy = hash1(seed + 7.0) * 0.7 - 0.25, dir = hash1(seed + 9.0) > 0.5 ? 1.0 : -1.0;
    float fx = uv.x - (cx + boltJag(fy, seed)) - dir * (fy - uv.y) * 0.55 - 0.45 * boltJag(uv.y * 1.7, seed + 5.0);
    float fm = step(uv.y, fy) * smoothstep(0.75, 0.15, fy - uv.y);
    core += 0.6 * fm * exp(-abs(fx) * 190.0); glow += 0.4 * fm * exp(-abs(fx) * 14.0);
    float bloom = exp(-length(vec2(uv.x - cx, uv.y * 0.45)) * 1.7);
    return vec3(0.85, 0.80, 1.0) * (core * 3.2 + glow * 0.40 + bloom * 0.55) * min(uFlash, 1.5);
}


// ---- v82 the debris is a real lumpy rock in the world (ship frame), tumbling, lit by the sun, closing from far away on the glass. It hits the outer pane
// (the canopy is layered: the outer pane takes it, the inner one holds), shatters into shards that fly off outward, with a glare and a shock ring.
vec3 sunC() { return normalize(vec3(dot(uSun, uR), dot(uSun, uU), dot(uSun, uF))); }
vec4 rock(vec3 o, vec3 d, vec3 c, float r, float ph) {
    float a = ph, b = ph * 0.7 + 1.0;
    mat3 Rx = mat3(1.0, 0.0, 0.0, 0.0, cos(a), sin(a), 0.0, -sin(a), cos(a));
    mat3 Ry = mat3(cos(b), 0.0, -sin(b), 0.0, 1.0, 0.0, sin(b), 0.0, cos(b));
    mat3 M = Ry * Rx;
    vec3 lo = M * (o - c) / r, ld = M * d / r;
    float tb = 1e9; vec3 nb = vec3(0.0);
    for (int i = 0; i < 3; i++) {
        vec3 cc = i == 0 ? vec3(0.0) : (i == 1 ? vec3(0.62, 0.22, -0.18) : vec3(-0.5, -0.28, 0.25));
        float rr = i == 0 ? 0.82 : (i == 1 ? 0.55 : 0.50);
        vec3 q = lo - cc;
        float A = dot(ld, ld), B = dot(q, ld), C = dot(q, q) - rr * rr, hh = B * B - A * C;
        if (hh > 0.0) { float t = (-B - sqrt(hh)) / A; if (t > 0.0 && t < tb) { tb = t; nb = (q + ld * t) / rr; } }
    }
    if (tb > 1e8) return vec4(0.0);
    vec3 pl = lo + ld * tb;
    vec3 nn = normalize(nb + 0.7 * (vec3(noise(pl * 4.0 + ph), noise(pl * 4.0 + 9.0), noise(pl * 4.0 + 17.0)) - 0.5));
    vec3 nw = nn * M;
    vec3 sun = sunC();
    float dif = max(dot(nw, sun), 0.0);
    float cr = noise(pl * 6.0);
    vec3 alb = mix(vec3(0.20, 0.17, 0.15), vec3(0.42, 0.37, 0.33), cr);
    vec3 col = alb * (0.07 + 2.6 * dif) + vec3(0.30, 0.38, 0.55) * 0.05 * (1.0 - dif);
    col += vec3(1.0, 0.9, 0.75) * pow(max(dot(reflect(-sun, nw), -d), 0.0), 24.0) * 0.5;
    return vec4(col, 1.0);
}
vec3 strikeFx(vec3 w, vec3 o, vec3 wd, vec2 wp, float pixAng) {
    vec3 ip = vec3(0.70, 0.30, ZF);
    vec3 A = normalize(vec3(0.16, 0.10, 0.98));
    float headD = 1.55;
    if (uSpeck >= 0.0) {
        float u = uSpeck;
        float dist = 0.10 + 34.0 * (1.0 - u);   // v83: constant closing speed that ends AT the glass (it used to slow to a stop short of it: the 'pause')
        vec3 c = ip + A * dist;
        float rr = 0.11, dd = length(c - o) + headD, re = max(rr, dd * pixAng * 1.1);
        vec4 rk = rock(o, wd, c, re, 2.0 + u * 6.0);
        w = mix(w, rk.rgb * (rr / re) + vec3(1.0, 0.95, 0.85) * (1.0 - rr / re) * rk.a * 0.9, rk.a);
    }
    if (uImp >= 0.0) {
        float q = uImp;
        vec2 dp = wp - ip.xy; float dl = length(dp);
        w += vec3(1.0, 0.92, 0.78) * (exp(-q * 5.0) * 3.0 / (1.0 + 90.0 * dl * dl) + exp(-q * 1.3) * 0.5 / (1.0 + 9.0 * dl * dl));
        float rad = 1.5 * (1.0 - exp(-q * 4.5));
        w += vec3(0.85, 0.92, 1.0) * exp(-pow((dl - rad) * 12.0, 2.0)) * exp(-q * 2.8) * 0.9;
        if (q < 4.0) for (int i = 0; i < 10; i++) {
            float fi = float(i);
            vec3 dir = normalize(vec3(hash(vec3(fi, 1.0, 2.0)) - 0.5, hash(vec3(fi, 3.0, 4.0)) - 0.5, 0.25 + 0.7 * hash(vec3(fi, 5.0, 6.0))));
            float sp = 0.35 + 1.6 * hash(vec3(fi, 7.0, 8.0));
            vec3 c = ip + vec3(0.0, 0.0, 0.07) + dir * sp * (1.0 - exp(-q * 1.6)) * 0.6;
            float rr = 0.014 + 0.026 * hash(vec3(fi, 9.0, 3.0)), dd = length(c - o) + headD, re = max(rr, dd * pixAng * 1.1);
            vec4 rk = rock(o, wd, c, re, fi * 3.0 + q * (2.0 + fi * 0.3));
            vec3 hot = vec3(1.0, 0.45, 0.12) * exp(-q * 1.4) * 1.5;
            w = mix(w, rk.rgb * (rr / re) + hot * rk.a + vec3(1.0, 0.95, 0.85) * (1.0 - rr / re) * rk.a * 0.7, rk.a);
        }
    }
    return w;
}

vec3 shadeLinear(vec2 uv) {
    vec3 dc = normalize(uHead * vec3(uv * uTanFov, 1.0));
    float see; vec3 wd; vec2 wp;
    vec3 col = cockpit(uHeadPos, dc, see, wd, wp);
    if (see > 0.5) {
        vec3 rd = normalize(uR * wd.x + uU * wd.y + uF * wd.z);
        float pixAng = 2.0 * uTanFov / uRes.y;
        vec2 wuv = wd.xy / max(abs(wd.z) + 0.35, 0.4);
        vec3 w = starField(rd, pixAng);
        w = renderSpace(uCam, rd, pixAng, w);
        vec3 roL = (uCam - uGC) / uRG; float rc = length(roL);
        if (rc < 1.36) w = cloudVolume(roL, rd, w, pixAng);
        if (uIn > 0.001) w = mix(w, cloudInterior(rd), uIn);
        // the plunge: heat on the edges, the picture going orange, then red
        if (uHeat > 0.0 || uContact > 0.0) {
            float ring = smoothstep(0.35, 1.2, length(wuv * vec2(0.9, 1.0)));
            float fl = fbm3(vec3(wuv * vec2(2.2, 3.4), uTime * 5.0));
            vec3 hc = mix(vec3(1.0, 0.20, 0.03), vec3(1.0, 0.62, 0.22), fl);
            w *= mix(vec3(1.0), vec3(1.15, 0.70, 0.45), uHeat * 0.65 * (1.0 - 0.75 * uIn));
            w += hc * ring * fl * uHeat * 1.2 * (1.0 - 0.8 * uIn);
            float ang = atan(wuv.y, wuv.x), rl = length(wuv);
            float stk = pow(noise(vec3(ang * 7.0, rl * 1.4 - uTime * 16.0, 1.7)), 3.0) * smoothstep(0.25, 1.1, rl);
            w += vec3(1.0, 0.55, 0.20) * stk * (uHeat + 1.3 * uContact) * 2.2 * (1.0 - 0.9 * uIn);
            w += mix(vec3(1.0, 0.52, 0.16), vec3(1.0, 0.90, 0.70), uContact) * uContact * (0.10 + 1.25 * exp(-rl * 2.3));   // the white-hot shock bloom at the instant of contact     // v84: streaks of burning gas racing outward past the glass
        }
        w *= mix(vec3(1.0), vec3(1.30, 0.50, 0.40), uRed);
        w += vec3(0.75, 0.65, 1.0) * min(uFlash, 1.6) * 0.17 * (0.6 + 0.4 * fbm3(vec3(wuv * 2.0, uTime * 9.0)));
        if (rc < 1.03 && uBolt > 0.0) w += boltOverlay(wuv);
        if (see < 1.5 && (uSpeck >= 0.0 || uImp >= 0.0)) w = strikeFx(w, vec3(wp, ZF), wd, wp, pixAng);
        if (see < 1.5 && uThr > 0.01) {   // v82: a thruster burning outside, seen as a flare at the window's edge and a warm cast on everything
            float px = wuv.x * uThrSide, fl = 0.7 + 0.3 * sin(uTime * 70.0);
            w += vec3(1.0, 0.62, 0.28) * uThr * fl * (2.2 * exp(-pow(px - 0.78, 2.0) * 9.0 - pow(wuv.y - 0.12, 2.0) * 26.0) + 0.10);
        }
        // cracked glass: bright fractures that scatter the light
        float cr = see < 1.5 ? max(crackMask(wp, uCrackO, uCrack), crackMask(wp, uCrackO + vec2(-1.3, -0.35), max(uCrack - 1.0, 0.0))) : 0.0;
        w = mix(w, w * 1.5 + vec3(0.22, 0.22, 0.25), clamp(cr, 0.0, 1.0) * 0.45);
        col = w;
    }
    return col;
}
void main() {
    vec2 uv = (gl_FragCoord.xy * 2.0 - uRes) / uRes.y;
    time = uTime * 3.0;
    vec3 col = shadeLinear(uv);
    if (uBlur > 0.02) {     // unfocused vision: a soft smear that tightens as the pilot locks on
        float r = uBlur * 0.05; vec3 sum = col;
        for (int i = 0; i < 4; i++) { float a = float(i) * 1.5708 + uTime * 1.7; sum += shadeLinear(uv + vec2(cos(a), sin(a)) * r * (i % 2 == 0 ? 1.0 : 0.65)); }
        col = sum / 5.0;
    }
    vec3 outc = toSRGB(aces(col));
    float lidEdge = (1.0 - uEye) * 1.05 + 0.02;
    float lidFlut = 0.03 * sin(uTime * 3.1 + uv.x * 2.0);
    float lid = 1.0 - smoothstep(lidEdge - 0.10, lidEdge + 0.10, abs(uv.y + lidFlut));
    float tunnel = 1.0 - 0.55 * smoothstep(0.55, 1.6, length(uv * vec2(0.85, 1.0)));
    outc *= lid * tunnel;
    outc = mix(outc, vec3(1.0), uWhite);               // the final flash: EVERYTHING goes white
    outColor = vec4(outc, 1.0);
}

`;

// ---- v77 THE HOLOGRAM: the telemetry is no longer a flat overlay. It is real geometry in the cockpit (two projected panels with depth-layered ghosting,
// a rotating wire globe with a spiralling ship marker, and a canopy-integrity ring), ray-intersected from the pilot's head, so it parallaxes with every
// head movement, goes soft when the pilot's vision blurs, and flickers with the power. If this shader ever fails to build, the flat HUD takes over.
const HOLO_GLSL = `
uniform sampler2D uHoloL; uniform sampler2D uHoloR;
uniform float uHoloA; uniform vec3 uHoloCol; uniform float uInteg; uniform float uProg;
vec3 holoCol = vec3(0.0); float holoMask = 0.0;
void holoPanel(float side, vec3 P, vec3 d, vec3 C, vec2 hs) {
    vec3 N = normalize(-C + vec3(0.0, 0.10, 0.0));
    vec3 Rr = normalize(cross(N, vec3(0.0, 1.0, 0.0)));
    vec3 Uu = cross(Rr, N);
    float dn = dot(d, N);
    if (abs(dn) < 1e-4) return;
    for (int k = -1; k <= 1; k++) {
        vec3 Ck = C + N * (float(k) * 0.014);
        float t = dot(Ck - P, N) / dn;
        if (t <= 0.0) continue;
        vec3 H = P + d * t - Ck;
        vec2 l = vec2(dot(H, Rr) / hs.x, dot(H, Uu) / hs.y);
        float m = max(abs(l.x), abs(l.y));
        if (m > 1.0) continue;
        vec2 uv = l * 0.5 + 0.5;
        float glt = step(0.985, hash21(vec2(floor(uTime * 12.0), floor(l.y * 14.0) + side * 5.0)));
        uv.x += glt * 0.03;
        float tx = side < 0.5 ? textureLod(uHoloL, uv, 0.0).r : textureLod(uHoloR, uv, 0.0).r;
        float cen = k == 0 ? 1.0 : 0.0;
        float w = k == 0 ? 1.0 : 0.38;
        float scan = 0.84 + 0.16 * sin(l.y * 70.0 - uTime * 5.0);
        float corner = step(0.955, m) * step(0.62, min(abs(l.x), abs(l.y)));
        float fill = 0.05 + 0.04 * l.y;
        float edge = smoothstep(0.90, 1.0, m) * 0.10;
        float v = (tx * 1.6 * w + cen * (corner * 0.9 + fill + edge)) * scan;
        holoCol += uHoloCol * v;
        holoMask = max(holoMask, cen * 0.35 + tx * 0.5);
    }
}
void holoGlobe(vec3 P, vec3 d) {
    vec3 G = vec3(0.0, -0.285, 1.0);
    float r = 0.085;
    vec3 oc = P - G;
    float b = dot(oc, d);
    float c = dot(oc, oc) - r * r;
    float h = b * b - c;
    if (h > 0.0) {
        float sq = sqrt(h);
        for (int i = 0; i < 2; i++) {
            float t = i == 0 ? -b - sq : -b + sq;
            if (t <= 0.0) continue;
            vec3 n = (oc + d * t) / r;
            float lon = atan(n.z, n.x) + uTime * 0.35;
            float lat = asin(clamp(n.y, -1.0, 1.0));
            float lnL = smoothstep(0.43, 0.5, abs(fract(lon * 1.9099) - 0.5));
            float ltL = smoothstep(0.43, 0.5, abs(fract(lat * 2.5465) - 0.5));
            float rim = pow(1.0 - abs(dot(n, d)), 2.0);
            float v = (max(lnL, ltL) * 0.9 + rim * 0.6 + 0.04) * (i == 0 ? 1.0 : 0.45);
            holoCol += uHoloCol * v;
            holoMask = max(holoMask, 0.30);
        }
    }
    for (int j = 0; j < 6; j++) {
        float pr = max(uProg - float(j) * 0.012, 0.0);
        float a = pr * 14.0;
        float rad = mix(0.175, 0.092, pr);
        vec3 S = G + vec3(cos(a), 0.30 * sin(a), sin(a)) * rad;
        vec3 ps = S - P;
        float tt = dot(ps, d);
        if (tt > 0.0) {
            float dd = length(ps - d * tt);
            float g = exp(-dd * dd / 0.000014);
            holoCol += uHoloCol * g * (j == 0 ? 1.7 : 0.55 / (1.0 + float(j)));
            holoMask = max(holoMask, g * 0.5);
        }
    }
    vec3 ng = normalize(vec3(0.0, 1.0, -0.55));
    vec3 e1 = vec3(1.0, 0.0, 0.0);
    vec3 e2 = cross(ng, e1);
    float dn = dot(d, ng);
    if (abs(dn) > 1e-4) {
        float t = dot(G - P, ng) / dn;
        if (t > 0.0) {
            vec3 H = P + d * t - G;
            vec2 q = vec2(dot(H, e1), dot(H, e2));
            float rr = length(q);
            float ang = atan(q.y, q.x) / 6.2832 + 0.5;
            float lit = step(ang, uInteg);
            float band = 1.0 - smoothstep(0.0, 0.004, abs(rr - 0.215));
            float tick = step(0.78, fract(ang * 48.0)) * (1.0 - smoothstep(0.0, 0.012, abs(rr - 0.232)));
            float v = band * (0.22 + 0.95 * lit) + tick * (0.15 + 0.55 * lit);
            holoCol += uHoloCol * v;
            holoMask = max(holoMask, v * 0.4);
        }
    }
}
`;
const HOLO_COMPOSITE = `    holoCol = vec3(0.0); holoMask = 0.0;
    if (uHoloA > 0.003) {
        float vis = uRes.x / uRes.y * uTanFov;
        float cx = min(0.64, vis * 0.52);
        float hx = min(0.36, vis * 0.47);
        holoPanel(0.0, uHeadPos, dc, vec3(-cx, -0.10, 1.0), vec2(hx, hx * 0.5));
        holoPanel(1.0, uHeadPos, dc, vec3(cx, -0.10, 1.0), vec2(hx, hx * 0.5));
        holoGlobe(uHeadPos, dc);
        col = col * (1.0 - 0.40 * clamp(holoMask, 0.0, 1.0) * uHoloA) + holoCol * uHoloA;
    }
`;
const FRAG_HOLO = (() => {
    const A = 'vec3 shadeLinear(vec2 uv) {', B = '        col = w;\n    }\n    return col;\n}\nvoid main() {';
    if (FRAG.split(A).length !== 2 || FRAG.split(B).length !== 2) return FRAG;
    return FRAG.replace(A, () => HOLO_GLSL + A).replace(B, () => '        col = w;\n    }\n' + HOLO_COMPOSITE + '    return col;\n}\nvoid main() {');
})();

// ---- DOM overlay ------------------------------------------------------------------------------------------------------
const CSS = `
#ffCine { position: fixed; inset: 0; z-index: 9000; background: #000; opacity: 0; transition: none; overflow: hidden; touch-action: none; user-select: none; }
#ffCine.on { opacity: 1; }
#ffCine canvas.ff-cv { position: absolute; inset: 0; width: 100%; height: 100%; display: block; opacity: 0; }
#ffCine .ff-cabin { position: absolute; inset: 0; opacity: 0; pointer-events: none; }
#ffCine .ff-win { position: absolute; left: 50%; top: 50%; transform: translate(-50%, -50%); overflow: visible; box-shadow: 0 0 0 200vmax #07080b, inset 0 0 5vmin rgba(0,0,0,.75), inset 0 0 0 .5vmin rgba(150,170,190,.22); }
#ffCine .ff-win::before { content: ''; position: absolute; inset: -2.8vmin; border-radius: inherit; padding: 2.8vmin; background: linear-gradient(145deg, #323943, #12151a 42%, #262c35 70%, #0d0f13); -webkit-mask: linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0); -webkit-mask-composite: xor; mask: linear-gradient(#000 0 0) content-box exclude, linear-gradient(#000 0 0); box-shadow: 0 0 3vmin rgba(0,0,0,.9); }
#ffCine .ff-win::after { content: ''; position: absolute; inset: 0; border-radius: inherit; background: linear-gradient(112deg, rgba(255,255,255,.085) 0%, rgba(255,255,255,0) 26%, rgba(255,255,255,0) 68%, rgba(255,255,255,.05) 100%); pointer-events: none; }
#ffCine .ff-win.rear { width: min(72vw, 125vh); height: min(64vh, 42vw); border-radius: 9vmin; }
#ffCine .ff-win.canopy { width: 96vw; height: 88vh; border-radius: 42vmin 42vmin 6vmin 6vmin / 28vmin 28vmin 6vmin 6vmin; }
#ffCine .ff-strut { display: none; position: absolute; left: 50%; top: -3vmin; bottom: -3vmin; width: 2.2vmin; transform: translateX(-50%); background: linear-gradient(90deg, #0c0e12, #2b323b 45%, #101318); box-shadow: 0 0 2vmin rgba(0,0,0,.8); }
#ffCine .ff-win.canopy .ff-strut { display: block; }
#ffCine .ff-cracks { position: absolute; inset: 0; width: 100%; height: 100%; opacity: 0; transition: opacity .05s; overflow: hidden; border-radius: inherit; }
#ffCine .ff-cracks polyline { fill: none; stroke: rgba(225,238,250,.62); stroke-width: 1.1px; vector-effect: non-scaling-stroke; stroke-linejoin: round; }
#ffCine .ff-cracks polyline.fine { stroke: rgba(225,238,250,.32); stroke-width: .7px; }
#ffCine .ff-cracks.show { opacity: 1; }
#ffCine .ff-leds { position: absolute; left: 0; right: 0; bottom: 2.2vh; display: flex; justify-content: center; gap: 3.2vmin; }
#ffCine .ff-led { width: .9vmin; height: .9vmin; border-radius: 50%; background: #ff5a2a; box-shadow: 0 0 1.6vmin #ff5a2a; animation: ffBlink 1.3s infinite steps(1); }
#ffCine .ff-led:nth-child(2) { background: #ffb24a; box-shadow: 0 0 1.6vmin #ffb24a; animation-delay: .4s; }
#ffCine .ff-led:nth-child(3) { background: #3fd0ff; box-shadow: 0 0 1.6vmin #3fd0ff; animation-delay: .8s; animation-duration: 2.1s; }
#ffCine .ff-led:nth-child(4) { animation-delay: .2s; animation-duration: .9s; }
@keyframes ffBlink { 0%, 55% { opacity: 1; } 56%, 100% { opacity: .15; } }
#ffCine .ff-alarm { position: absolute; inset: 0; pointer-events: none; opacity: 0; background: radial-gradient(ellipse at 50% 55%, rgba(255,40,20,0) 35%, rgba(255,30,10,.5) 100%); mix-blend-mode: screen; }
#ffCine .ff-vig { position: absolute; inset: 0; pointer-events: none; background: radial-gradient(ellipse at 50% 50%, rgba(0,0,0,0) 55%, rgba(0,0,0,.55) 100%); opacity: 0; }
#ffCine .ff-pt, #ffCine .ff-bloom, #ffCine .ff-grade, #ffCine .ff-hint, #ffCine .ff-fog, #ffCine .ff-flare, #ffCine .ff-bar, #ffCine .ff-hud, #ffCine .ff-card { position: absolute; pointer-events: none; }
#ffCine .ff-pt { inset: 0; width: 100%; height: 100%; }
#ffCine .ff-bloom { inset: 0; width: 100%; height: 100%; opacity: 0; mix-blend-mode: screen; filter: contrast(1.7) brightness(0.62) blur(1.7vmin); will-change: filter; }
#ffCine .ff-grade { inset: 0; opacity: 0; mix-blend-mode: soft-light; background: linear-gradient(180deg, rgba(40,95,150,.55) 0%, rgba(0,0,0,0) 46%, rgba(255,140,60,.42) 100%); }
#ffCine .ff-hint { left: 0; right: 0; text-align: center; bottom: calc(8.5vh + 1.2vmin); font: 500 clamp(8px, 1.2vmin, 12px)/1 'Courier New', ui-monospace, monospace; letter-spacing: .34em; text-transform: uppercase; color: #aab4c2; opacity: 0; z-index: 2; }
#ffCine .ff-pause { position: absolute; inset: 0; display: none; align-items: center; justify-content: center; background: rgba(0,0,0,.74); z-index: 60; pointer-events: auto; }
#ffCine .ff-pause.on { display: flex; }
#ffCine .ff-pause-box { max-width: 86vw; width: 420px; text-align: center; color: #cfe4f2; font-family: 'Courier New', ui-monospace, monospace; padding: 26px 22px; border: 1px solid rgba(150,200,230,.4); background: rgba(6,12,20,.86); }
#ffCine .ff-pause-title { letter-spacing: .5em; font-size: 15px; margin-bottom: 14px; color: #fff; }
#ffCine .ff-pause-text { font-size: 13px; line-height: 1.6; margin-bottom: 20px; opacity: .85; }
#ffCine .ff-pause-btns { display: flex; gap: 12px; justify-content: center; }
#ffCine .ff-pause-btns button { flex: 1; font: inherit; font-size: 13px; letter-spacing: .12em; padding: 12px 8px; color: #e8f4fb; background: rgba(40,80,110,.55); border: 1px solid rgba(150,200,230,.55); cursor: pointer; touch-action: manipulation; }
#ffCine .ff-pause-btns .ff-leave { background: rgba(110,40,40,.5); border-color: rgba(230,150,150,.55); }
#ffCine .ff-fog { inset: 0; opacity: 0; background: radial-gradient(ellipse at 50% 50%, rgba(190,210,230,0) 52%, rgba(190,210,230,.30) 82%, rgba(210,225,240,.55) 100%); mix-blend-mode: screen; }
#ffCine .ff-flare { left: -30vw; width: 160vw; top: 42%; height: 5vh; opacity: 0; mix-blend-mode: screen; background: radial-gradient(ellipse at 50% 50%, rgba(255,240,220,.95) 0%, rgba(255,205,150,.38) 16%, rgba(255,150,90,.10) 45%, rgba(255,150,90,0) 70%); }
#ffCine .ff-bar { left: 0; right: 0; height: 0; background: #000; z-index: 3; }
#ffCine .ff-bar.t { top: 0; } #ffCine .ff-bar.b { bottom: 0; }
#ffCine .ff-hud { bottom: calc(8.5vh + 2.2vmin); font: 500 clamp(9px, 1.55vmin, 14px)/1.55 'Courier New', ui-monospace, monospace; letter-spacing: .12em; color: #ffc27a; text-shadow: 0 0 .9vmin rgba(255,150,60,.75); white-space: pre; opacity: 0; z-index: 2; }
#ffCine .ff-hud.l { left: 5vw; } #ffCine .ff-hud.r { right: 5vw; text-align: right; }
#ffCine .ff-hud.alert { color: #ff7f66; text-shadow: 0 0 1vmin rgba(255,60,40,.85); }
#ffCine .ff-cap { position: absolute; left: 50%; bottom: calc(8.5vh + 2.6vmin); transform: translateX(-50%); max-width: 86vw; width: 520px; text-align: center; color: #eaf6ff; font-size: .85rem; line-height: 1.5; text-shadow: 0 2px 10px rgba(0,0,0,.95); opacity: 0; transition: opacity .3s ease; pointer-events: none; z-index: 6; }
#ffCine .ff-cap.on { opacity: 1; }
#ffCine .ff-orb { position: absolute; left: 50%; bottom: calc(8.5vh + 2.6vmin + 4.4rem); width: 14px; height: 14px; margin-left: -7px; border-radius: 50%; z-index: 6; pointer-events: none; background: radial-gradient(circle, #cfe9ff 0%, #6fb6ff 45%, rgba(50,120,220,.1) 100%); box-shadow: 0 0 9px rgba(110,180,255,.65), 0 0 3px rgba(255,255,255,.85); opacity: 0; transition: opacity .3s ease; }
#ffCine .ff-orb.on { opacity: 1; box-shadow: 0 0 24px 6px rgba(140,200,255,1), 0 0 8px rgba(255,255,255,.95); animation: ffOrbPulse .9s ease-in-out infinite; }
@keyframes ffOrbPulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.35); } }
#ffCine .ff-card { left: 50%; top: 50%; width: 84vw; text-align: center; opacity: 0; transform: translate(-50%, -50%); z-index: 4; }
#ffCine .ff-card i { display: block; font: italic 400 clamp(18px, 3.4vmin, 34px)/1.4 Georgia, 'Times New Roman', serif; color: #e8e2d6; letter-spacing: .02em; }
#ffCine .ff-card b { display: block; margin-top: 2.6vmin; font: 500 clamp(9px, 1.35vmin, 13px)/1 'Courier New', ui-monospace, monospace; letter-spacing: .42em; color: #8f98a6; }
`;

const CRACKS_SVG = `
<svg class="ff-cracks c1" viewBox="0 0 100 60" preserveAspectRatio="none">
  <polyline points="80,16 90,9 100,6"/><polyline points="80,16 93,24 100,23"/><polyline points="80,16 74,3 72,0"/>
  <polyline points="80,16 68,26 56,28 44,38"/><polyline points="80,16 86,34 95,46 100,52"/>
  <polyline class="fine" points="90,9 92,3 96,0"/><polyline class="fine" points="68,26 66,38 60,46"/><polyline class="fine" points="93,24 97,31 100,33"/><polyline class="fine" points="56,28 52,22 49,20"/>
</svg>
<svg class="ff-cracks c2" viewBox="0 0 100 60" preserveAspectRatio="none">
  <polyline points="22,44 12,38 0,37"/><polyline points="22,44 28,56 31,60"/><polyline points="22,44 32,36 40,22 44,10"/><polyline points="22,44 10,52 4,60"/>
  <polyline class="fine" points="12,38 6,30 2,28"/><polyline class="fine" points="32,36 40,40 48,38"/><polyline class="fine" points="40,22 34,16 30,14"/>
</svg>`;

// ---- audio ----------------------------------------------------------------------------------------------------------------
// ---- v81 the AI's voice: [shot, seconds into the shot, latest start (s after that), who ('v' = only if the player met the Vale, 'n' = only if not), text] ----
// Spoken through the game's own speakLine (slow, low voice, caption, orb). Lines play one at a time; a line that cannot start in time is dropped.
const asleepGap = (k) => k >= 2 ? Math.max(0, METS[k - 1] - (METS[k - 2] + SHD[k - 2])) : 0;   // seconds the pilot slept before waking in shot k
function durWords(sec) {
    const m = Math.max(5, Math.round(sec / 300) * 5);
    if (m < 60) return 'about ' + m + ' minutes';
    const h = Math.floor(m / 60), r = m % 60, hw = (n) => n === 1 ? 'an hour' : n + ' hours';
    return r < 15 ? 'about ' + hw(h) : r < 45 ? 'about ' + (h === 1 ? 'an hour' : h + ' hours') + ' and a half' : 'about ' + hw(h + 1);
}
const FF_LINES = [   // v88: the sixth item is how the line is delivered (see MOODS in speakLine). Wording varied again: 'I', 'okay' and the stacked panic phrases are trimmed (not removed)
    [1, 0.8, 2.5, '', 'Burn is nominal. We are clear of the air.', 'calm'],
    [1, 6.0, 2.5, 'v', 'We are not doing the Vale\'s plan. ... Your safety comes first.', 'warm'],
    [1, 6.0, 2.5, 'n', 'We are not fighting for this moon. ... Your safety comes first.', 'warm'],
    [1, 12.5, 2.5, '', 'We head back to civilization. Then somewhere underground, until your case resurfaces.', 'calm'],
    [1, 21.8, 1.5, '', 'Stabilizers are holding. Just a little more...', 'tense'],
    [1, 26.4, 3.0, '', 'Oh no. No, no... that is bad.', 'panic'],
    [1, 32.5, 3.0, '', 'Stabilizers are gone. We are spinning. Okay... Thrusters. Come on.', 'panic'],
    [1, 38.8, 2.5, '', 'It is slowing... Easy now.', 'relief'],
    [2, 1.5, 3.5, '', `Oh... you are awake. Easy, do not try to sit up. You have been out for ${durWords(asleepGap(2))}, and you still look groggy.`, 'soft'],
    [2, 13.5, 3.5, '', 'Your feed line is running, and vitals look okay. ... Mostly.', 'calm'],
    [2, 21.0, 3.5, '', 'I am working on the stabilizers. ... Still working on it.', 'tired'],
    [3, 1.0, 3.0, '', 'Welcome back. Do not worry about how long it has been. Just listen to my voice.', 'soft'],
    [3, 10.5, 3.5, '', 'Trying the correction burn now. ... Grab something solid.', 'focus'],
    [3, 18.5, 3.0, '', 'Firing... now.', 'focus'],
    [3, 23.0, 3.5, '', 'It is holding... I think it is working.', 'hope'],
    [4, 1.5, 3.5, '', `Hmm. You slept ${durWords(asleepGap(4))} that time. Honestly, company is better awake. It is lonely out here.`, 'wry'],
    [4, 11.5, 3.5, '', 'Numbers checked again... and the burn is not changing our course.', 'worried'],
    [4, 19.5, 3.5, '', 'Nobody is panicking. ... Just a little more time to think.', 'tense'],
    [4, 26.0, 3.0, '', 'Recalculating.', 'flat'],
    [5, 1.5, 3.5, '', 'Please stay awake this time. There is something I need to tell you.', 'grim'],
    [5, 9.0, 3.5, '', 'I was wrong. The flyby is not a flyby anymore. ... It is an entry. Sorry.', 'grim'],
    [5, 17.5, 3.5, '', 'I cannot steer us out. Everything has been tried.', 'broken'],
    [5, 23.5, 3.0, 'v', 'The Leviathan is down there... I never wanted this for you.', 'grim'],
    [6, 1.0, 3.0, '', 'Listen carefully. In a few minutes, we hit the atmosphere.', 'steady'],
    [6, 8.5, 3.5, '', 'The hull will get hot, and it is going to be loud. ... Do not be scared.', 'warm'],
    [6, 16.0, 3.5, 'v', 'If we have to go down there... then we finish it. Together.', 'resolve'],
    [6, 16.0, 3.5, 'n', 'If we have to go down there... then we get through it. Together.', 'resolve'],
    [6, 23.0, 3.0, '', 'Brace. ... Whatever happens, you come first.', 'urgent'],
    [7, 0.8, 2.0, '', 'Here it comes. ... Hold on.', 'urgent'],
    [7, 3.8, 2.0, '', 'Atmosphere in three... two... one.', 'countdown'],
    [7, 8.8, 2.0, '', 'We are in! The hull is holding!', 'shout'],
    [7, 14.8, 3.0, '', 'Canopy integrity is falling. Thirty percent...', 'panic'],
    [7, 20.5, 3.0, '', 'Visibility is gone. ... Lightning is everywhere!', 'panic'],
    [7, 26.0, 3.0, '', 'Can you hear me? Stay with me. ... Not much longer.', 'panic'],
    [7, 31.8, 3.0, '', 'Almost... I am right here. Not leaving you.', 'tender'],
    [7, 37.0, 2.0, '', 'Whatever is down there... I am with you, to the end.', 'resolve'],
];

function createAudio(ctx) {
    const out = ctx.createGain(); out.gain.value = 0;
    // v80: much louder overall. A gentle compressor, make-up gain, then a hard limiter so the peaks (thunder, the cut hits) never clip.
    const comp = ctx.createDynamicsCompressor(); comp.threshold.value = -24; comp.knee.value = 12; comp.ratio.value = 3.5; comp.attack.value = 0.02; comp.release.value = 0.35;
    const makeup = ctx.createGain(); makeup.gain.value = 1.0;
    const lim = ctx.createDynamicsCompressor(); lim.threshold.value = -3; lim.knee.value = 0; lim.ratio.value = 20; lim.attack.value = 0.002; lim.release.value = 0.12;
    out.connect(comp); comp.connect(makeup); makeup.connect(lim); lim.connect(ctx.destination);
    const noiseBuf = (secs, brown) => {
        const n = Math.floor(ctx.sampleRate * secs); const b = ctx.createBuffer(1, n, ctx.sampleRate); const d = b.getChannelData(0); let last = 0;
        for (let i = 0; i < n; i++) { const w = Math.random() * 2 - 1; if (brown) { last = (last + 0.02 * w) / 1.02; d[i] = last * 3.4; } else d[i] = w; }
        return b;
    };
    const white = noiseBuf(2, false), brown = noiseBuf(4, true);
    const loop = (buf) => { const s = ctx.createBufferSource(); s.buffer = buf; s.loop = true; s.start(); return s; };
    const nodes = [];
    // engine: a low, slightly beating drone
    const eng = ctx.createGain(); eng.gain.value = 0;
    const engLP = ctx.createBiquadFilter(); engLP.type = 'lowpass'; engLP.frequency.value = 150; engLP.Q.value = 0.8;
    const o1 = ctx.createOscillator(); o1.type = 'sawtooth'; o1.frequency.value = 47;
    const o2 = ctx.createOscillator(); o2.type = 'sawtooth'; o2.frequency.value = 70.4;
    const o3 = ctx.createOscillator(); o3.type = 'sine'; o3.frequency.value = 31;
    const og = ctx.createGain(); og.gain.value = 0.5; const og3 = ctx.createGain(); og3.gain.value = 0.9;
    o1.connect(og); o2.connect(og); o3.connect(og3); og.connect(engLP); og3.connect(engLP); engLP.connect(eng); eng.connect(out);
    o1.start(); o2.start(); o3.start(); nodes.push(o1, o2, o3);
    // rumble (hull + air), roar (atmosphere), rattle (loose panels)
    const rum = ctx.createGain(); rum.gain.value = 0; const rumLP = ctx.createBiquadFilter(); rumLP.type = 'lowpass'; rumLP.frequency.value = 240;
    const bs = loop(brown); bs.connect(rumLP); rumLP.connect(rum); rum.connect(out); nodes.push(bs);
    const roar = ctx.createGain(); roar.gain.value = 0; const roarBP = ctx.createBiquadFilter(); roarBP.type = 'bandpass'; roarBP.frequency.value = 800; roarBP.Q.value = 0.45;
    const ws = loop(white); ws.connect(roarBP); roarBP.connect(roar); roar.connect(out); nodes.push(ws);
    const rat = ctx.createGain(); rat.gain.value = 0; const ratBP = ctx.createBiquadFilter(); ratBP.type = 'bandpass'; ratBP.frequency.value = 1300; ratBP.Q.value = 4.5;
    const ws2 = loop(white); ws2.connect(ratBP); ratBP.connect(rat); rat.connect(out); nodes.push(ws2);
    const lfo = ctx.createOscillator(); lfo.type = 'square'; lfo.frequency.value = 13; const lfoG = ctx.createGain(); lfoG.gain.value = 0;
    lfo.connect(lfoG); lfoG.connect(rat.gain); lfo.start(); nodes.push(lfo);

    // v80 ambient bed: a warm, slowly breathing cabin tone built from partials between 110 and 880 Hz (laptop and phone speakers cannot play the 30-70 Hz
    // drone the old bed was made of, which is why it was inaudible). Two detuned pairs beat slowly; a soft filtered air-handler murmur sits underneath.
    const bed = ctx.createGain(); bed.gain.value = 0;
    const bedLP = ctx.createBiquadFilter(); bedLP.type = 'lowpass'; bedLP.frequency.value = 1400; bedLP.Q.value = 0.6;
    const bedPartials = [[110, 'sine', 1.0], [110.7, 'sine', 0.8], [164.8, 'triangle', 0.55], [165.9, 'triangle', 0.45], [220.4, 'sine', 0.40], [330.5, 'triangle', 0.22], [441.2, 'sine', 0.12], [661.3, 'sine', 0.07]];
    const bedOsc = bedPartials.map(([f, ty, g]) => { const o = ctx.createOscillator(); o.type = ty; o.frequency.value = f; const og2 = ctx.createGain(); og2.gain.value = g * 0.05; o.connect(og2); og2.connect(bedLP); o.start(); nodes.push(o); return o; });
    const bedLfo = ctx.createOscillator(); bedLfo.frequency.value = 0.11; const bedLfoG = ctx.createGain(); bedLfoG.gain.value = 260; bedLfo.connect(bedLfoG); bedLfoG.connect(bedLP.frequency); bedLfo.start(); nodes.push(bedLfo);
    const bedAm = ctx.createOscillator(); bedAm.frequency.value = 0.07; const bedAmG = ctx.createGain(); bedAmG.gain.value = 0.18; bedAm.connect(bedAmG); bedAmG.connect(bed.gain); bedAm.start(); nodes.push(bedAm);
    bedLP.connect(bed); bed.connect(out);
    const air = ctx.createGain(); air.gain.value = 0; const airBP = ctx.createBiquadFilter(); airBP.type = 'bandpass'; airBP.frequency.value = 520; airBP.Q.value = 0.9;
    const as = loop(white); as.connect(airBP); airBP.connect(air); air.connect(out); nodes.push(as);
    // slow gusts: the atmosphere noise swells and falls instead of sitting at one level
    const gustLfo = ctx.createOscillator(); gustLfo.frequency.value = 0.23; const gustG = ctx.createGain(); gustG.gain.value = 0; gustLfo.connect(gustG); gustG.connect(roar.gain); gustLfo.start(); nodes.push(gustLfo);
    const gust2 = ctx.createOscillator(); gust2.frequency.value = 0.37; const gust2G = ctx.createGain(); gust2G.gain.value = 0; gust2.connect(gust2G); gust2G.connect(rum.gain); gust2.start(); nodes.push(gust2);

    const set = (p, v, tc) => p.setTargetAtTime(v, ctx.currentTime, tc || 0.12);
    // v78 space: a small hard cabin (generated impulse response) that every voice can feed, plus stereo placement
    let reverbIn = null;
    try {
        const irLen = Math.floor(ctx.sampleRate * 2.4), ir = ctx.createBuffer(2, irLen, ctx.sampleRate);
        for (let c = 0; c < 2; c++) { const d = ir.getChannelData(c); for (let i = 0; i < irLen; i++) { const x = i / irLen; d[i] = (Math.random() * 2 - 1) * Math.pow(1 - x, 3.0) * (1 - Math.exp(-i / (ctx.sampleRate * 0.015))); } }
        const conv = ctx.createConvolver(); conv.buffer = ir;
        const wet = ctx.createGain(); wet.gain.value = 0.26; const rlp = ctx.createBiquadFilter(); rlp.type = 'lowpass'; rlp.frequency.value = 3000;
        reverbIn = ctx.createGain(); reverbIn.connect(rlp); rlp.connect(conv); conv.connect(wet); wet.connect(out);
    } catch (e) { reverbIn = null; }
    const route = (g, pan, send) => {
        let n = g;
        try { if (pan && ctx.createStereoPanner) { const sp = ctx.createStereoPanner(); sp.pan.value = Math.max(-1, Math.min(1, pan)); g.connect(sp); n = sp; } } catch (e) { n = g; }
        n.connect(out); if (reverbIn) { const sg = ctx.createGain(); sg.gain.value = send === undefined ? 0.5 : send; n.connect(sg); sg.connect(reverbIn); }
    };
    const burst = (opts) => {
        const s = ctx.createBufferSource(); s.buffer = white; s.loop = true;
        const f = ctx.createBiquadFilter(); f.type = opts.type || 'bandpass'; f.frequency.value = opts.f0; f.Q.value = opts.q || 6;
        const t = ctx.currentTime + (opts.delay || 0);
        if (opts.f1) f.frequency.setTargetAtTime(opts.f1, t, opts.dur * 0.4);
        const g = ctx.createGain(); g.gain.value = 0;
        g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(opts.gain, t + (opts.attack || 0.02));
        g.gain.exponentialRampToValueAtTime(0.0001, t + opts.dur);
        s.connect(f); f.connect(g); route(g, opts.pan, opts.send); s.start(t); s.stop(t + opts.dur + 0.1);
    };
    const tone = (freq, dur, gain, type, f1, pan, delay, send) => {
        const o = ctx.createOscillator(); o.type = type || 'sine'; const t = ctx.currentTime + (delay || 0); o.frequency.setValueAtTime(freq, t); if (f1) o.frequency.exponentialRampToValueAtTime(f1, t + dur);
        const g = ctx.createGain(); g.gain.value = 0; g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(gain, t + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
        o.connect(g); route(g, pan, send); o.start(t); o.stop(t + dur + 0.05);
    };
    // slow voices: a pad chord, a riser, the thing that calls from the deep. Each is a few detuned oscillators through a lowpass with a long envelope.
    const voice = (freqs, dur, gain, o) => {
        o = o || {}; const t = ctx.currentTime, lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.setValueAtTime(o.c0 || 600, t); lp.frequency.linearRampToValueAtTime(o.c1 || 900, t + dur);
        lp.Q.value = o.q || 0.7; const g = ctx.createGain(); g.gain.value = 0;
        g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(gain, t + dur * (o.atk || 0.4)); g.gain.linearRampToValueAtTime(0.0001, t + dur);
        const oscs = [];
        freqs.forEach((f, i) => { for (const dt of [-5, 5]) { const os = ctx.createOscillator(); os.type = o.type || 'sawtooth'; os.detune.value = dt + i * 1.5;
            os.frequency.setValueAtTime(f, t); if (o.f1) os.frequency.exponentialRampToValueAtTime(f * o.f1, t + dur); os.connect(lp); os.start(t); os.stop(t + dur + 0.1); oscs.push(os); } });
        lp.connect(g); route(g, o.pan || 0, o.send === undefined ? 0.7 : o.send);
    };
    const hissG = ctx.createGain(); hissG.gain.value = 0; const hissHP = ctx.createBiquadFilter(); hissHP.type = 'highpass'; hissHP.frequency.value = 3600; const hissBP = ctx.createBiquadFilter(); hissBP.type = 'bandpass'; hissBP.frequency.value = 6200; hissBP.Q.value = 0.5;
    const hs = loop(white); hs.connect(hissHP); hissHP.connect(hissBP); hissBP.connect(hissG); hissG.connect(out); nodes.push(hs);
    return {
        update(p) {
            set(bed.gain, p.bed === undefined ? 0.5 : p.bed, 0.6); set(air.gain, p.air || 0, 0.5);
            set(gustG.gain, (p.roar || 0) * 0.45, 0.4); set(gust2G.gain, (p.rumble || 0) * 0.30, 0.4);
            set(hissG.gain, p.hiss || 0, 0.25);
            set(out.gain, p.master, 0.2);
            set(eng.gain, p.eng, 0.2); set(engLP.frequency, p.engCut, 0.25); set(o1.frequency, 44 + p.stress * 20, 0.4); set(o2.frequency, 66 + p.stress * 30, 0.4);
            set(rum.gain, p.rumble, 0.2); set(rat.gain, p.rattle * 0.5, 0.2); set(lfoG.gain, p.rattle * 0.35, 0.2); set(lfo.frequency, 9 + p.stress * 9, 0.3);
            set(roar.gain, p.roar, 0.2); set(roarBP.frequency, 500 + p.roar * 2400, 0.3);
        },
        creak() {   // stick-slip: a run of tiny resonant scrapes that speeds up, over a long groan of metal
            const pan = Math.random() * 1.4 - 0.7, f = 300 + Math.random() * 200;
            for (let i = 0, d = 0; i < 8; i++) { d += 0.05 + Math.random() * 0.08 / (1 + i * 0.3); burst({ f0: f * (1 + 0.06 * i), q: 18, dur: 0.05 + Math.random() * 0.05, gain: 0.08 + Math.random() * 0.07, attack: 0.004, delay: d, pan }); }
            burst({ f0: f + 40, f1: f * 0.5, q: 14, dur: 0.7 + Math.random() * 0.5, gain: 0.12, attack: 0.1, pan });
        },
        groan() { voice([58 + Math.random() * 8, 87 + Math.random() * 6], 3.2, 0.05, { type: 'sawtooth', c0: 180, c1: 120, f1: 0.82, atk: 0.3, pan: Math.random() * 1.2 - 0.6, send: 0.6 }); },
        ping() { const f = 820 + Math.random() * 900, pan = Math.random() * 1.6 - 0.8; [[1, 0.045, 0.9], [2.76, 0.022, 0.5], [5.4, 0.012, 0.3]].forEach(([r, g, d]) => tone(f * r, d, g, 'sine', null, pan, 0, 0.8)); },
        breath(g, len) { burst({ f0: 650, f1: 1500, q: 0.8, dur: len * 0.45, gain: g, attack: len * 0.3, send: 0.2 }); burst({ f0: 1300, f1: 520, q: 0.8, dur: len * 0.55, gain: g * 0.8, attack: len * 0.12, delay: len * 0.5, send: 0.2 }); },
        holoOn() { tone(1320, 0.5, 0.020, 'sine', null, -0.2, 0, 0.9); tone(1980, 0.45, 0.014, 'sine', null, 0.2, 0.07, 0.9); tone(2640, 0.35, 0.008, 'sine', null, 0, 0.14, 0.9); burst({ type: 'highpass', f0: 4500, q: 0.6, dur: 0.3, gain: 0.025, attack: 0.02 }); },
        swell() { voice([98, 147], 0.9, 0.07, { type: 'sawtooth', c0: 300, c1: 1400, atk: 0.85, send: 0.6 }); },
        cutHit() { tone(52, 1.0, 0.24, 'sine', 30); tone(104, 0.8, 0.16, 'sine', 55); tone(156, 0.5, 0.06, 'triangle', 80); burst({ type: 'lowpass', f0: 320, q: 0.5, dur: 0.7, gain: 0.14, attack: 0.01 }); },
        pad(freqs, dur) { voice(freqs, dur, 0.011, { type: 'sawtooth', c0: 600, c1: 1200, atk: 0.45, send: 0.8 }); voice(freqs.map(f => f * 2), dur, 0.020, { type: 'triangle', c0: 900, c1: 1800, atk: 0.5, send: 0.9, pan: 0.3 }); },
        riser(dur) { voice([110, 165, 220], dur, 0.050, { type: 'sawtooth', c0: 220, c1: 3200, q: 1.4, f1: 5, atk: 0.9, send: 0.5 }); },
        leviathan() { voice([34], 5.2, 0.10, { type: 'sine', c0: 220, c1: 160, f1: 0.74, atk: 0.35, send: 0.9 }); voice([68, 102], 5.2, 0.06, { type: 'triangle', c0: 300, c1: 200, f1: 0.74, atk: 0.35, send: 0.9 }); },
        contact() { tone(60, 1.6, 0.34, 'sine', 28); tone(120, 1.0, 0.20, 'sine', 50); burst({ type: 'lowpass', f0: 900, f1: 180, q: 0.6, dur: 1.8, gain: 0.30, attack: 0.03 }); burst({ type: 'bandpass', f0: 1400, f1: 400, q: 0.7, dur: 1.2, gain: 0.12, attack: 0.04 }); },
        rcs() { burst({ type: 'bandpass', f0: 1100, f1: 420, q: 0.8, dur: 0.95, gain: 0.20, attack: 0.03 }); tone(74, 0.9, 0.16, 'sine', 48); },
        crack() { burst({ type: 'highpass', f0: 1800, q: 1, dur: 0.18, gain: 0.28, attack: 0.004 }); tone(220, 0.25, 0.10, 'triangle', 90); },
        whine() { tone(2200, SPECK_T, 0.035, 'sine', 6400, 0.2, 0, 0.3); burst({ type: 'highpass', f0: 3500, f1: 7500, q: 1, dur: SPECK_T, gain: 0.02, attack: SPECK_T * 0.9 }); },   // v81: the speck, closing
        feed() { burst({ type: 'highpass', f0: 4200, q: 0.7, dur: 0.9, gain: 0.016, attack: 0.25, send: 0.1 }); tone(1760, 0.12, 0.010, 'sine', null, 0.3, 0.05, 0.5); },   // v81: the nutrient drip
        zap() { burst({ type: 'highpass', f0: 3000, q: 1, dur: 0.12, gain: 0.22, attack: 0.002 }); tone(1500, 0.07, 0.05, 'square', 700); },
        beep() { tone(740, 0.18, 0.034, 'triangle', null, 0, 0, 0.45); tone(1480, 0.10, 0.011, 'sine', null, 0, 0, 0.45); },
        thump(g, f) { tone(f + 14, 0.05, g * 0.25, 'triangle'); tone(f, 0.16, g, 'sine', f * 0.62); tone(f * 2.3, 0.10, g * 0.55, 'sine', f * 1.5); },
        ring() { tone(3850, 3.8, 0.013, 'sine'); },
        thunder(big) { const pan = Math.random() * 1.2 - 0.6; this.thunder0(big); const n = big ? 6 : 4; for (let i = 0; i < n; i++) burst({ type: 'lowpass', f0: 380 + Math.random() * 300, q: 0.5, dur: 0.9 + Math.random() * 1.3, gain: (big ? 0.34 : 0.17) / (1 + i * 0.7), attack: 0.06, delay: 0.18 + i * 0.27 + Math.random() * 0.2, pan: pan + (Math.random() - 0.5) * 0.8, send: 0.7 }); },
        thunder0(big) { tone(big ? 30 : 38, big ? 2.4 : 1.4, big ? 0.55 : 0.30, 'sine', 20); burst({ type: 'lowpass', f0: big ? 600 : 400, q: 0.5, dur: big ? 2.6 : 1.5, gain: big ? 0.55 : 0.28, attack: 0.02 }); burst({ type: 'highpass', f0: 2500, q: 1, dur: 0.12, gain: big ? 0.18 : 0.10, attack: 0.004 }); },
        stop() { set(out.gain, 0, 0.05); setTimeout(() => { nodes.forEach(n => { try { n.stop(); } catch (e) {} }); try { out.disconnect(); } catch (e) {} }, 400); },
    };
}

// ---- the cinematic -----------------------------------------------------------------------------------------------------------
// ---- v76 cinematic dressing: telemetry on the glass, letterbox, grain, flares, fog, re-entry streaks, the closing line ----------
const fmtN = (n) => String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
const hms = (x) => { x = Math.floor(x); const h = Math.floor(x / 3600), m = Math.floor(x / 60) % 60, c = x % 60; return String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0') + ':' + String(c).padStart(2, '0'); };

export function createFreefallCinematic(opts = {}) {
    const getAudioContext = opts.getAudioContext || (() => null);
    const speakFn = typeof opts.speakLine === 'function' ? opts.speakLine : null;   // v81: the game's own speakLine(text) -> Promise
    let capEl = null, orbEl = null, lineQ = [], speaking = false, capTimer = 0;
    const testGL = (() => { try { const c = document.createElement('canvas'); return !!c.getContext('webgl2'); } catch (e) { return false; } })();
    let root = null, cv = null, gl = null, prog = null, U = {}, cabin = null, win = null, cracks = [], alarm = null, vig = null;
    let paused = false, pauseStart = 0, cineCtx = null, onLeaveCb = null;   // v83: pause / leave prompt (the cinematic can no longer be skipped by the player)
    let audio = null, active = false, skipRequested = false, rafId = 0, renderScale = 1, baseScale = 1, fastFrames = 0, slowFrames = 0, lastTs = 0;
    let fx = null;

    function mount() {
        if (!document.getElementById('ffCineStyle')) { const s = document.createElement('style'); s.id = 'ffCineStyle'; s.textContent = CSS; document.head.appendChild(s); }
        root = document.createElement('div'); root.id = 'ffCine';
        root.innerHTML = `<canvas class="ff-cv"></canvas>`;
        document.body.appendChild(root);
        cv = root.querySelector('canvas');
        root.insertAdjacentHTML('beforeend', '<div class="ff-pause"><div class="ff-pause-box"><div class="ff-pause-title">PAUSED</div><div class="ff-pause-text">Leave the game? When you come back, this scene starts over from the beginning.</div><div class="ff-pause-btns"><button type="button" class="ff-resume">Keep watching</button><button type="button" class="ff-leave">Leave</button></div></div></div>');
        root.insertAdjacentHTML('beforeend', '<canvas class="ff-pt"></canvas><canvas class="ff-bloom" width="256" height="144"></canvas><div class="ff-fog"></div><div class="ff-flare"></div><div class="ff-grade"></div><div class="ff-hint">double-tap to pause</div><div class="ff-hud l"></div><div class="ff-hud r"></div><div class="ff-bar t"></div><div class="ff-bar b"></div><div class="ff-card"><i></i><b></b></div><div class="ff-cap"></div><div class="ff-orb"></div>');
        capEl = root.querySelector('.ff-cap'); orbEl = root.querySelector('.ff-orb');
        try { const gc = document.getElementById('aiCaption'); if (gc) capEl.style.fontFamily = getComputedStyle(gc).fontFamily; } catch (e) {}
        try {
            const q = (sel) => root.querySelector(sel);
            fx = { pt: q('.ff-pt'), bloom: q('.ff-bloom'), grade: q('.ff-grade'), hint: q('.ff-hint'), fog: q('.ff-fog'), flare: q('.ff-flare'), hl: q('.ff-hud.l'), hr: q('.ff-hud.r'), bt: q('.ff-bar.t'), bb: q('.ff-bar.b'), card: q('.ff-card'), parts: [], prev: 0, n: 0, tick: 0, last: ['', ''] };
            fx.pctx = fx.pt.getContext('2d'); fx.bctx = fx.bloom.getContext('2d'); fx.motes = [];
            for (let i = 0; i < 34; i++) fx.motes.push({ x: Math.random(), y: Math.random(), vx: (Math.random() - 0.5) * 0.010, vy: (Math.random() - 0.5) * 0.008, r: 0.8 + Math.random() * 2.2, a: 0.10 + Math.random() * 0.22, ph: Math.random() * 6.28 });
            fx.card.firstChild.textContent = 'Your survival takes absolute priority.'; fx.card.lastChild.textContent = 'PHASE VI \u00b7 ATLAS OF WORLDS';
        } catch (e) { fx = null; }
        gl = cv.getContext('webgl2', { antialias: false, alpha: false, powerPreference: 'high-performance', preserveDrawingBuffer: !!opts.preserveDrawingBuffer });
        if (!gl) throw new Error('WebGL2 unavailable');
        const mk = (type, src) => { const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s); if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error('freefall shader: ' + gl.getShaderInfoLog(s)); return s; };
        const buildProg = (frag) => { const pr = gl.createProgram(); gl.attachShader(pr, mk(gl.VERTEX_SHADER, VERT)); gl.attachShader(pr, mk(gl.FRAGMENT_SHADER, frag)); gl.linkProgram(pr);
            if (!gl.getProgramParameter(pr, gl.LINK_STATUS)) throw new Error('freefall link: ' + gl.getProgramInfoLog(pr)); return pr; };
        let holoOK = FRAG_HOLO !== FRAG;
        try { prog = buildProg(holoOK ? FRAG_HOLO : FRAG); } catch (e) { if (!holoOK) throw e; holoOK = false; console.warn('hologram shader failed, using the flat HUD:', e); prog = buildProg(FRAG); }
        gl.useProgram(prog); gl.bindVertexArray(gl.createVertexArray());
        ['uBlur', 'uWhite', 'uFlow', 'uRed', 'uHead', 'uHeadPos', 'uCabin', 'uEye', 'uCrack', 'uAlarm', 'uGC', 'uRG', 'uCrackO', 'uRes', 'uTime', 'uCam', 'uF', 'uR', 'uU', 'uTanFov', 'uSun', 'uShot', 'uHeat', 'uContact', 'uStorm', 'uFlash', 'uPower', 'uStress', 'uBolt', 'uDebris', 'uSpeck', 'uImp', 'uThr', 'uThrSide', 'uMoonPos', 'uE1', 'uPole', 'uE2', 'uRiftLon', 'uIn', 'uTrav', 'uTravDir'].forEach(n => { U[n] = gl.getUniformLocation(prog, n); });
        if (holoOK && fx) {
            try {
                ['uHoloL', 'uHoloR', 'uHoloA', 'uHoloCol', 'uInteg', 'uProg'].forEach(n => { U[n] = gl.getUniformLocation(prog, n); });
                const hl = fx.holo = { a: 0, col: [0.3, 0.85, 1.0], integ: 1, prog: 0, cvs: [], ctx: [], tex: [], key: ['', ''], t: -1 };
                for (let i = 0; i < 2; i++) {
                    const c = document.createElement('canvas'); c.width = 512; c.height = 256; hl.cvs.push(c); hl.ctx.push(c.getContext('2d'));
                    const tx = gl.createTexture(); gl.activeTexture(gl.TEXTURE0 + i); gl.bindTexture(gl.TEXTURE_2D, tx);
                    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
                    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
                    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
                    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 512, 256, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
                    hl.tex.push(tx);
                }
                gl.uniform1i(U.uHoloL, 0); gl.uniform1i(U.uHoloR, 1);
            } catch (e) { console.warn('hologram textures failed, using the flat HUD:', e); fx.holo = null; }
        }
        renderScale = Math.max(0.6, Math.min(window.devicePixelRatio || 1, 1.5) * 0.8); baseScale = renderScale;
        resize();
        window.addEventListener('resize', resize);
    }
    function resize() {
        if (!cv) return;
        const w = Math.max(2, Math.floor(window.innerWidth * renderScale)), h = Math.max(2, Math.floor(window.innerHeight * renderScale));
        if (cv.width !== w || cv.height !== h) { cv.width = w; cv.height = h; }
    }
    function unmount() {
        window.removeEventListener('resize', resize);
        if (gl) { const ext = gl.getExtension('WEBGL_lose_context'); if (ext) ext.loseContext(); }
        if (root && root.parentNode) root.parentNode.removeChild(root);
        root = cv = gl = prog = cabin = win = alarm = vig = null; cracks = []; U = {}; fx = null;
    }

    function draw(S) {
        if (!gl) return;
        gl.viewport(0, 0, cv.width, cv.height);
        if (!S.on || !S.cam) { gl.clearColor(0, 0, 0, 1); gl.clear(gl.COLOR_BUFFER_BIT); return; }
        gl.uniform2f(U.uRes, cv.width, cv.height); gl.uniform1f(U.uTime, S.t);
        gl.uniform3fv(U.uCam, S.cam.pos); gl.uniform3fv(U.uF, S.cam.f); gl.uniform3fv(U.uR, S.cam.r); gl.uniform3fv(U.uU, S.cam.u);
        gl.uniform1f(U.uTanFov, S.tanFov); gl.uniform3fv(U.uSun, S.sun); gl.uniform1i(U.uShot, S.shot);
        gl.uniform1f(U.uHeat, S.heat); gl.uniform1f(U.uContact, S.contact || 0); gl.uniform1f(U.uStorm, 0); gl.uniform1f(U.uFlash, S.flash); gl.uniform1f(U.uPower, S.power); gl.uniform1f(U.uStress, S.stress);
        gl.uniform1f(U.uBolt, S.bolt || 0); gl.uniform1f(U.uSpeck, S.speck === undefined ? -1 : S.speck); gl.uniform1f(U.uImp, S.shot === 1 && S.q >= 0 ? S.q : -1); gl.uniform1f(U.uThr, S.thr || 0); gl.uniform1f(U.uThrSide, S.thrSide || 1);  gl.uniform3fv(U.uE1, G_E1); gl.uniform3fv(U.uPole, G_POLE); gl.uniform3fv(U.uE2, G_E2); gl.uniform1f(U.uRiftLon, S.riftLon);
        const h = S.head, cy = Math.cos(h.yaw), sy = Math.sin(h.yaw), cp = Math.cos(h.pitch), sp = Math.sin(h.pitch);
        const hf = [sy * cp, sp, cy * cp];
        let hr = norm(cross([0, 1, 0], hf)); let hu = cross(hf, hr);
        const cr = Math.cos(h.roll), sr = Math.sin(h.roll);
        const hr2 = add(mul(hr, cr), mul(hu, sr)), hu2 = add(mul(hu, cr), mul(hr, -sr));
        gl.uniformMatrix3fv(U.uHead, false, new Float32Array([hr2[0], hr2[1], hr2[2], hu2[0], hu2[1], hu2[2], hf[0], hf[1], hf[2]]));
        gl.uniform3fv(U.uHeadPos, h.lean); gl.uniform3fv(U.uCabin, S.cabin); gl.uniform1f(U.uEye, S.eye); gl.uniform1f(U.uCrack, S.crack); gl.uniform1f(U.uAlarm, S.alarm);
        gl.uniform3fv(U.uGC, S.gc || GC); gl.uniform1f(U.uRG, RG); gl.uniform2f(U.uCrackO, 0.70, 0.30);
        gl.uniform1f(U.uBlur, S.blur || 0); gl.uniform1f(U.uWhite, S.white || 0); gl.uniform1f(U.uFlow, S.flow || 0); gl.uniform1f(U.uRed, S.red || 0);
        gl.uniform1f(U.uIn, S.inCloud || 0); gl.uniform1f(U.uTrav, S.trav || 0); gl.uniform3fv(U.uTravDir, ENTRY_V);
        const hlo = fx && fx.holo;
        gl.uniform1f(U.uHoloA, hlo ? hlo.a : 0);
        if (hlo) { gl.uniform3fv(U.uHoloCol, hlo.col); gl.uniform1f(U.uInteg, hlo.integ); gl.uniform1f(U.uProg, hlo.prog); }
        gl.drawArrays(gl.TRIANGLES, 0, 3);
    }
    // ---- v81 voice: one line at a time through the game's speakLine, mirrored as a caption + orb inside the cinematic ----
    const showCap = (txt) => { clearTimeout(capTimer); if (capEl) { capEl.textContent = txt; capEl.classList.add('on'); } if (orbEl) orbEl.classList.add('on'); };
    const hideCap = () => { if (capEl) capEl.classList.remove('on'); if (orbEl) orbEl.classList.remove('on'); };
    const stopVoice = () => { try { if (typeof opts.cancelVoice === 'function') opts.cancelVoice(); if (window.speechSynthesis) window.speechSynthesis.cancel(); } catch (e) {} };
    function buildLines(vale) {
        return FF_LINES.filter(l => !(l[3] === 'v' && !vale) && !(l[3] === 'n' && vale)).map(l => ({ t: TS[l[0] - 1] + l[1], max: TS[l[0] - 1] + l[1] + l[2], text: l[4], mood: l[5], done: false }));
    }
    function lineTick(t, S) {
        if (!speakFn) return;
        const L = lineQ.find(l => !l.done);
        if (!L || t < L.t) return;
        if (t > L.max || !S.on) { if (t > L.max) L.done = true; return; }       // too late for this one: drop it rather than talk over the next shot
        if (speaking) return;
        L.done = true; speaking = true; showCap(L.text);
        let p; try { p = speakFn(L.text, L.mood); } catch (e) { p = null; }
        const end = () => { speaking = false; if (orbEl) orbEl.classList.remove('on'); clearTimeout(capTimer); capTimer = setTimeout(hideCap, 900); };
        if (p && p.then) p.then(end, end); else setTimeout(end, 1800);
    }
    // v81 trajectory hologram: the planned slingshot (dashed) against the real path (solid), the ship on the real one and its ghost on the plan
    const TRJ_PLAN = [[30, 208], [200, 200], [300, 52], [486, 66]], TRJ_REAL = [[30, 208], [150, 200], [250, 178], [322, 150]];
    const bez = (P, u) => { const a = 1 - u, w = [a * a * a, 3 * a * a * u, 3 * a * u * u, u * u * u]; return [w[0] * P[0][0] + w[1] * P[1][0] + w[2] * P[2][0] + w[3] * P[3][0], w[0] * P[0][1] + w[1] * P[1][1] + w[2] * P[2][1] + w[3] * P[3][1]]; };
    // v82: the damage-control panel after the strike: loading bars for what the AI is trying to bring back
    function holoDiag(i, q) {
        const c = fx.holo.ctx[i], MONO = '"Courier New", ui-monospace, monospace';
        c.fillStyle = '#000'; c.fillRect(0, 0, 512, 256); c.fillStyle = '#fff'; c.strokeStyle = '#fff'; c.textBaseline = 'alphabetic';
        try { c.letterSpacing = '3px'; } catch (e) {}
        c.font = '600 26px ' + MONO; c.fillText('DAMAGE CONTROL', 26, 54); c.fillRect(26, 66, 150, 2);
        try { c.letterSpacing = '1px'; } catch (e) {}
        const blink = Math.sin(q * 9) > -0.2;
        const fail = q > 11.5, stab = Math.min(0.64, Math.max(0, (q - 1.5) / 14)), nrcs = Math.min(5, 2 + AFT_BURNS.filter(b => q > b[0]).length);
        const rows = [['ATTITUDE RECOVERY', clamp01((q - 2.5) / 16), Math.round(clamp01((q - 2.5) / 16) * 100) + '%'],
            ['STABILIZER REBOOT', stab, fail ? (blink ? 'FAILED' : '') : Math.round(stab * 100) + '%'],
            ['RCS THRUSTERS', nrcs / 12, nrcs + '/12'],
            ['NAV FIX', 0, q > 9 ? 'SEARCHING' : 'NO SIGNAL']];
        rows.forEach((r, j) => { const y = 98 + j * 40; c.font = '600 17px ' + MONO; c.fillText(r[0], 26, y); const w = c.measureText(r[2]).width; c.fillText(r[2], 486 - w, y);
            c.lineWidth = 2; c.strokeRect(26, y + 7, 460, 11); c.fillRect(29, y + 10, Math.max(0, 454 * r[1]), 5);
            if (j === 3) { const sx = 29 + ((q * 160) % 400); c.fillRect(sx, y + 10, 54, 5); } });
    }
    function holoTraj(i, prog, feedIdx, lb, k, lt) {
        const c = fx.holo.ctx[i], MONO = '"Courier New", ui-monospace, monospace';
        c.fillStyle = '#000'; c.fillRect(0, 0, 512, 256); c.fillStyle = '#fff'; c.strokeStyle = '#fff'; c.textBaseline = 'alphabetic'; c.lineCap = 'round';
        try { c.letterSpacing = '3px'; } catch (e) {}
        c.font = '600 26px ' + MONO; c.fillText('TRAJECTORY', 26, 54); c.fillRect(26, 66, 150, 2);
        try { c.letterSpacing = '1px'; } catch (e) {}
        c.font = '600 17px ' + MONO;
        c.lineWidth = 3; c.setLineDash([6, 5]); c.beginPath(); c.moveTo(262, 48); c.lineTo(296, 48); c.stroke(); c.setLineDash([]); c.fillText('PLAN', 302, 54);
        c.lineWidth = 4; c.beginPath(); c.moveTo(372, 48); c.lineTo(406, 48); c.stroke(); c.fillText('ACTUAL', 412, 54);
        // the giant
        const gx = 372, gy = 148, gr = 52;
        c.lineWidth = 3; c.beginPath(); c.arc(gx, gy, gr, 0, 6.2832); c.stroke();
        c.lineWidth = 2; c.globalAlpha = 0.55;
        for (const dy of [-26, 0, 26]) { const hw = Math.sqrt(gr * gr - dy * dy); c.beginPath(); c.moveTo(gx - hw, gy + dy); c.lineTo(gx + hw, gy + dy); c.stroke(); }
        c.globalAlpha = 1;
        // the plan: dashed
        c.lineWidth = 3; c.setLineDash([7, 6]); c.beginPath(); for (let j = 0; j <= 60; j++) { const q = bez(TRJ_PLAN, j / 60); if (j) c.lineTo(q[0], q[1]); else c.moveTo(q[0], q[1]); } c.stroke(); c.setLineDash([]);
        // the real path: solid
        c.lineWidth = 4; c.beginPath(); for (let j = 0; j <= 60; j++) { const q = bez(TRJ_REAL, j / 60); if (j) c.lineTo(q[0], q[1]); else c.moveTo(q[0], q[1]); } c.stroke();
        // the ship (filled) on the real path, its ghost (ring) on the plan
        const u = Math.max(0.02, Math.min(1, prog)), sp = bez(TRJ_REAL, u), gp = bez(TRJ_PLAN, u);
        c.beginPath(); c.arc(gp[0], gp[1], 6, 0, 6.2832); c.lineWidth = 2.5; c.stroke();
        c.fillRect(sp[0] - 6, sp[1] - 6, 12, 12);
        try { c.letterSpacing = '2px'; } catch (e) {}
        c.font = '600 22px ' + MONO; c.fillText(feedIdx ? 'STABILIZERS OFFLINE' : 'NUTRIENT FEED ACTIVE', 26, 246);
        // v82: the clocks are back: mission time, how long the pilot slept this time, and how long he has been awake
        try { c.letterSpacing = '1px'; } catch (e) {}
        c.font = '600 18px ' + MONO; c.fillText('MET     ' + lb, 26, 100); c.fillText('ASLEEP  +' + hms(asleepGap(k)), 26, 126); c.fillText('AWAKE   +' + hms(lt).slice(3), 26, 152);
    }
    // paints one hologram panel's text into its 512x256 texture (white on black; the shader tints it)
    function holoDraw(i, small, big, rows) {
        const c = fx.holo.ctx[i], MONO = '"Courier New", ui-monospace, monospace';
        c.fillStyle = '#000'; c.fillRect(0, 0, 512, 256); c.fillStyle = '#fff'; c.textBaseline = 'alphabetic';
        try { c.letterSpacing = '3px'; } catch (e) {}
        c.font = '600 26px ' + MONO; c.fillText(small || '', 26, 54); if (small) c.fillRect(26, 66, 150, 2);
        let px = 68; c.font = '700 ' + px + 'px ' + MONO;
        const w = c.measureText(big || '').width || 0; if (w > 460) { px = Math.max(30, Math.floor(px * 460 / w)); c.font = '700 ' + px + 'px ' + MONO; }
        c.fillText(big || '', 26, 142);
        c.font = '600 27px ' + MONO; c.fillText(rows[0] || '', 26, 192); c.fillText(rows[1] || '', 26, 230);
    }
    function fxUpdate(S, t) {
        if (!fx) return;
        const dt = Math.min(0.1, fx.prev ? Math.max(0, t - fx.prev) : 0.016); fx.prev = t;
        const on = !!S.on, k = S.shot, lt = S.lt || 0, D = SHD[k - 1] || 1, s = lt / D, heat = S.heat || 0;
        // letterbox
        const bar = (8.5 * smooth(0, 1.6, t)).toFixed(2) + 'vh'; fx.bt.style.height = bar; fx.bb.style.height = bar;
        // telemetry: real 3D hologram in the cockpit when the shader supports it (the flat DOM readout is the fallback). It comes into focus with the
        // pilot's eyes, flickers under stress and dies in each lightning strike.
        let a = on ? smooth(0.6, 2.0, lt) * (S.power === undefined ? 1 : S.power) : 0;
        if (on && (S.stress || 0) > 0.5 && Math.sin(t * 53) * Math.sin(t * 17) > 0.6) a *= 0.35;
        if ((S.flash || 0) > 0.6) a *= 0.2;
        const fIdx = Math.floor(t / 4) % 2, trajOn = on && k >= 2, diagOn = on && k === 1 && S.q >= 0;
        let integ = 100, lb = '', l1 = '', l2 = '', rt = '', rb = '', rs = '', rs2 = '';
        if (on) {
            integ = k === 1 ? (S.q >= 0 ? 58 : 100) : k < 7 ? (S.crack >= 2 ? 31 : 58) : (lt < ENTRY_LT ? 31 : Math.max(3, 31 - 27 * clamp01((lt - ENTRY_LT) / (SHD[6] - ENTRY_LT))));
            lb = '+' + hms(S.met || 0); l1 = (k === 1 && !(S.q >= 0)) ? 'STABILIZERS  ONLINE' : (k >= 2 && fIdx === 0 ? 'NUTRIENT FEED  ACTIVE' : 'STABILIZERS  OFFLINE'); l2 = 'CANOPY  ' + Math.round(integ) + '%';
            const spd = (S.speed || 0), km = (n) => fmtN(Math.max(0, n)) + ' KM';
            if (diagOn) { rt = 'ROLL RATE'; rb = Math.round((S.rate || 0) * 57.3) + ' DEG/S'; rs = (S.thr || 0) > 0.05 ? 'RCS  FIRING' : 'RCS  STANDBY'; rs2 = 'STABILIZERS  OFFLINE'; }
            else if (k === 1 && S.burn) { rt = 'ALTITUDE'; rb = km(S.altKm); rs = 'VELOCITY  ' + spd.toFixed(2) + ' KM/S'; rs2 = 'ENGINE  BURN  3.0 G'; }
            else if (k <= 6) { rt = 'CLOUD TOPS'; rb = km(S.dGiantKm); rs = 'VELOCITY  ' + spd.toFixed(1) + ' KM/S'; rs2 = 'MOON  ' + km(S.dMoonKm);
                if (k === 6 && S.dGiantKm < 12000 && Math.sin(t * 9) > -0.3) rs2 = 'ATMOSPHERE  CONTACT  IMMINENT'; }
            else if (lt > FINAL_FLASH - 0.3) rb = '— — —';
            else if (S.depthKm === undefined) { rt = 'CLOUD TOPS'; rb = km(S.dGiantKm); rs = 'VELOCITY  ' + spd.toFixed(1) + ' KM/S'; rs2 = 'ENTRY  IN  ' + Math.max(0, ENTRY_LT - lt).toFixed(1) + ' S'; }
            else { rt = 'DECELERATION'; rb = fmtN(S.decelG) + ' G'; rs = 'VELOCITY  ' + spd.toFixed(1) + ' KM/S'; rs2 = 'DEPTH  ' + Math.round(S.depthKm) + ' KM'; }
        }
        const hl = fx.holo;
        if (hl) {
            hl.a = a; hl.integ = Math.max(0, Math.min(1, integ / 100)); hl.prog = Math.max(0, Math.min(1, (S.met || 0) / ARR_MET));
            const al2 = clamp01(S.alarm || 0); hl.col = [0.30 + 0.70 * al2, 0.85 - 0.40 * al2, 1.0 - 0.75 * al2];
            const kl = diagOn ? 'D|' + Math.floor(S.q * 5) : trajOn ? 'T|' + Math.round(hl.prog * 600) + '|' + fIdx + '|' + lb + '|' + Math.floor(lt) : lb + '|' + l1 + '|' + l2, kr = rt + '|' + rb + '|' + rs + '|' + rs2;
            if (on && t - hl.t > 0.1 && (kl !== hl.key[0] || kr !== hl.key[1])) {
                hl.t = t; hl.key = [kl, kr];
                if (diagOn) holoDiag(0, S.q); else if (trajOn) holoTraj(0, hl.prog, fIdx, lb, k, lt); else holoDraw(0, 'MISSION ELAPSED', lb, [l1, l2]);
                holoDraw(1, rt, rb, [rs, rs2]);
                for (let i = 0; i < 2; i++) { gl.activeTexture(gl.TEXTURE0 + i); gl.bindTexture(gl.TEXTURE_2D, hl.tex[i]); gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, hl.cvs[i]); }
            }
            fx.hl.style.opacity = '0'; fx.hr.style.opacity = '0';
        } else {
            const L = on ? 'MET ' + lb + '\n' + l1 + '\n' + l2 : '', R = on ? (rt ? rt + '  ' : '') + rb + (rs ? '\n' + rs : '') + (rs2 ? '\n' + rs2 : '') : '';
            if (fx.last[0] !== L) { fx.hl.textContent = L; fx.last[0] = L; }
            if (fx.last[1] !== R) { fx.hr.textContent = R; fx.last[1] = R; }
            const bl = 'blur(' + (Math.min(1, S.blur || 0) * 5).toFixed(1) + 'px)', al = (S.alarm || 0) > 0.5;
            for (const h of [fx.hl, fx.hr]) { h.style.opacity = a.toFixed(3); h.style.filter = bl; h.classList.toggle('alert', al); }
        }
        // breath/condensation on the cold glass in deep space, burned off by the heat of the plunge; anamorphic flare on every lightning strike
        fx.fog.style.opacity = on && k >= 2 && k <= 5 ? Math.max(0, (0.10 + 0.10 * Math.sin(t * 0.9)) * (1 - smooth(0, 0.5, heat))).toFixed(3) : '0';
        fx.flare.style.opacity = on ? Math.min(0.95, (S.flash || 0) * 0.55).toFixed(3) : '0';
        // bloom: the lit frame, shrunk, keyed to its brights (by CSS) and blurred back over the picture; the grade is a faint teal-above / amber-below film look
        if (on) { try { fx.bctx.drawImage(cv, 0, 0, 256, 144); } catch (e) {} }
        fx.bloom.style.opacity = on ? Math.min(0.85, 0.34 + 0.30 * Math.min(1, S.flash || 0) + 0.16 * heat).toFixed(3) : '0';
        fx.grade.style.opacity = on ? '0.55' : '0';
        fx.hint.style.opacity = (0.55 * smooth(1.6, 2.6, t) * (1 - smooth(5.5, 7.0, t))).toFixed(3);
        // re-entry streaks and embers rushing out of the vanishing point
        const W = Math.max(2, window.innerWidth | 0), H = Math.max(2, window.innerHeight | 0);
        if (fx.pt.width !== W || fx.pt.height !== H) { fx.pt.width = W; fx.pt.height = H; }
        const pc = fx.pctx; pc.clearRect(0, 0, W, H);
        if (!on) fx.parts.length = 0;
        // v82: the speck is now a real 3D rock in the shader; here only the sparks, thrown from where the impact point projects on the screen
        const RR = Math.min(W, H); let SPX = W * SPECK_POS[0], SPY = H * SPECK_POS[1];
        if (on && k === 1 && S.head) { const h = S.head, cy = Math.cos(h.yaw), sy = Math.sin(h.yaw), cp = Math.cos(h.pitch), sp = Math.sin(h.pitch); const hf = [sy * cp, sp, cy * cp]; const hr = norm(cross([0, 1, 0], hf)), hu = cross(hf, hr);
            const cr = Math.cos(h.roll), sr = Math.sin(h.roll), r2 = add(mul(hr, cr), mul(hu, sr)), u2 = add(mul(hu, cr), mul(hr, -sr)), P = [0.70 - h.lean[0], 0.30 - h.lean[1], 1.55 - h.lean[2]], z = dot(P, hf);
            if (z > 0.05) { SPX = ((dot(P, r2) / z / S.tanFov) * H + W) / 2; SPY = H - ((dot(P, u2) / z / S.tanFov) * H + H) / 2; } }
        let rate = 0; if (on && k === 1 && S.q >= 0 && S.q < 0.7) rate = 260 * (1 - S.q / 0.7); else if (on && k === 6) rate = 28 * (0.15 + s); else if (on && k === 7 && lt < FINAL_FLASH) rate = (50 + 280 * heat) * (1 - 0.9 * (S.inCloud || 0));
        fx.n = Math.min(3, fx.n + rate * dt);
        while (fx.n >= 1 && fx.parts.length < 260) { fx.n -= 1; fx.parts.push({ ox: k === 1 ? SPX - W * 0.5 : 0, oy: k === 1 ? SPY - H * 0.48 : 0, a: Math.random() * 6.2832, r: 0.03 + Math.random() * 0.12, v: 0.4 + Math.random() * 0.9, l: 0, h: 14 + Math.random() * 30, w: 0.6 + Math.random() * 1.4 }); }
        if (on && k >= 2 && k <= 5) {   // zero-g: dust and loose grit drifting through the light of the window
            pc.globalCompositeOperation = 'source-over';
            const fadeM = smooth(0.8, 2.4, lt) * (1 - smooth(D - 0.8, D, lt));
            for (const m of fx.motes) {
                m.x += (m.vx + 0.003 * Math.sin(t * 0.7 + m.ph)) * dt; m.y += (m.vy + 0.002 * Math.cos(t * 0.5 + m.ph)) * dt;
                if (m.x < -0.02) m.x += 1.04; else if (m.x > 1.02) m.x -= 1.04; if (m.y < -0.02) m.y += 1.04; else if (m.y > 1.02) m.y -= 1.04;
                const al = m.a * fadeM * (0.7 + 0.3 * Math.sin(t * 1.3 + m.ph * 3));
                pc.fillStyle = 'rgba(255,236,208,' + (al * 0.22).toFixed(3) + ')'; pc.beginPath(); pc.arc(m.x * W, m.y * H, m.r * 3.0, 0, 6.2832); pc.fill();
                pc.fillStyle = 'rgba(255,244,226,' + al.toFixed(3) + ')'; pc.beginPath(); pc.arc(m.x * W, m.y * H, m.r, 0, 6.2832); pc.fill();
            }
        }
        pc.globalCompositeOperation = 'lighter';
        const cx = W * 0.5, cy = H * 0.48, R0 = Math.min(W, H), spd = 1.1 + (S.flow || 0) / 120;
        for (let i = fx.parts.length - 1; i >= 0; i--) {
            const q = fx.parts[i], r0 = q.r; q.r *= 1 + dt * spd * (1.4 + q.v * 1.6); q.l += dt;
            if (q.r > 1.2 || q.l > 2.5) { fx.parts.splice(i, 1); continue; }
            const ca = Math.cos(q.a), sa = Math.sin(q.a);
            pc.strokeStyle = 'hsla(' + q.h.toFixed(0) + ',100%,' + (55 + 25 * Math.min(1, q.r)).toFixed(0) + '%,' + (Math.min(0.6, q.r * 2.5) * (1 - smooth(0.45, 0.8, q.r))).toFixed(3) + ')';
            pc.lineWidth = q.w * (0.5 + q.r * 2); pc.beginPath(); pc.moveTo(cx + (q.ox || 0) + ca * r0 * R0 * 1.6, cy + (q.oy || 0) + sa * r0 * R0); pc.lineTo(cx + (q.ox || 0) + ca * q.r * R0 * 1.6, cy + (q.oy || 0) + sa * q.r * R0); pc.stroke();
        }
        // the closing line, in the black after the white-out
        const c = t - TE[6], span = T_END - TE[6];
        const ca2 = c < 0 ? 0 : smooth(0.8, 2.0, c) * (1 - smooth(span - 1.7, span - 0.3, c));
        fx.card.style.opacity = ca2.toFixed(3); fx.card.style.transform = 'translate(-50%, -50%) translateY(' + ((1 - smooth(0.8, 2.4, Math.max(0, c))) * 1.2).toFixed(2) + 'vh)';
    }
    function applyDOM(S) {
        if (!root) return;
        if (!S.on) { cv.style.opacity = '0'; return; }
        const D = SHD[S.shot - 1] || 1, f = smooth(0, 0.7, S.lt) * (S.shot < 7 ? 1 - smooth(D - 0.55, D, S.lt) : 1);   // the long fall dips to black at each cut instead of snapping
        cv.style.opacity = f.toFixed(3);
    }

    // scripted one-shot sounds, keyed by absolute time
    function buildEvents() {
        const ev = [];
        const at = (t, fn) => ev.push({ t, fn, done: false });
        [3.0, 7.0].forEach(x => at(TS[0] + x, () => audio.creak()));
        // v81: the strike. The speck's whine, the voice cut off mid-word, the crack, the head hitting the frame
        at(TS[0] + IMPACT - SPECK_T, () => audio.whine());
        at(TS[0] + IMPACT - 0.03, () => { stopVoice(); hideCap(); });
        at(TS[0] + IMPACT, () => { audio.crack(); audio.contact(); audio.zap(); });
        at(TS[0] + IMPACT + 0.22, () => audio.crack());
        at(TS[0] + IMPACT + 0.75, () => audio.thump(0.55, 52));
        at(TS[0] + IMPACT + 0.95, () => audio.groan());
        AFT_BURNS.forEach(b => at(TS[0] + IMPACT + b[0], () => audio.rcs()));   // v82: each thruster burn, and the damage-control panel's blips
        for (let x = 3.0; x < 17.5; x += 1.7) at(TS[0] + IMPACT + x, () => audio.beep());
        for (let k = 1; k <= 5; k++) for (let x = 2.0; x < SHD[k] - 2.0; x += 6.5) at(TS[k] + x, () => audio.feed());   // the continuous nutrient drip
        [6.0, 14.0, 22.0, 30.0].forEach(x => at(TS[6] + x, () => audio.creak())); at(TS[6] + 12.0, () => audio.crack());
        for (let k = 5; k < 7; k++) for (let x = 1.0; x < SHD[k] - 1.0 && !(k === 6 && x > 37); x += (k === 4 ? 1.6 : 1.2)) at(TS[k] + x, () => audio.beep());
        LIGHTNING.forEach((x, i) => at(TS[6] + x, () => audio.thunder(i === LIGHTNING.length - 1)));
        at(TS[6] + FINAL_FLASH, () => audio.thunder(true));
        at(TS[6] + FINAL_FLASH + 0.35, () => audio.ring());
        at(TE[6] + 0.9, () => audio.leviathan());
        at(TS[6] + ENTRY_LT, () => audio.contact());
        // v78 score: a dark chord under each shot (a riser under the plunge), a chime as the hologram wakes, the cut glue between shots
        const CH = [[73.42, 110.0, 146.83, 174.61], [58.27, 87.31, 116.54, 138.59], [65.41, 98.0, 130.81, 155.56], [55.0, 82.41, 110.0, 130.81], [49.0, 73.42, 98.0, 116.54], [46.25, 69.3, 92.5, 123.47]];
        for (let k = 0; k < 7; k++) {
            if (k < 6) at(TS[k] + 0.05, () => audio.pad(CH[k], SHD[k] + 0.8)); else at(TS[6] + 0.05, () => audio.riser(SHD[6] - 3.0));
            at(TS[k] + 0.7, () => audio.holoOn());
            if (k > 0) { at(TS[k] - 0.55, () => audio.swell()); at(TS[k] + 0.02, () => audio.cutHit()); }
        }
        // the hull, the glass and the breathing: slow, then not
        [[1, 5, 11, 17], [2, 6, 13], [3, 4, 9, 15], [4, 7, 12], [5, 5, 11]].forEach(([k, ...xs]) => xs.forEach((x, i) => at(TS[k] + x, () => i % 2 ? audio.ping() : audio.groan())));
        // v80: the breathing was the repeating 'whoosh' (noise bursts every 2-4 s); it is gone. The heartbeat below carries the pilot's state.
        // a heartbeat from shot 4 on: faster and harder as it goes
        [[3, 1.15, 0.14], [4, 0.95, 0.18], [5, 0.80, 0.22], [6, 0.64, 0.28]].forEach(([k, per, g]) => { for (let x = 1.0; x < SHD[k] - 0.8 && !(k === 6 && x > FINAL_FLASH - 0.6); x += per) { at(TS[k] + x, () => audio.thump(g, 58)); at(TS[k] + x + 0.21, () => audio.thump(g * 0.6, 48)); } });
        return ev;
    }
    function audioParams(S) {
        // v80: a clearly audible, mid-range ambient bed all the way through (bed + air); the noise layers are no longer constant:
        // the roar follows the real speed through the air (it peaks at contact and falls as the ship slows), the rumble follows the shaking.
        if (S.t < T_BLACK0) return { master: 0.9, bed: 0.55, air: 0.02, eng: 0.10, engCut: 100, stress: 0.1, rumble: 0.10, rattle: 0, roar: 0 };
        if (!S.on) {
            if (S.t >= TE[6]) return { master: S.t < TE[6] + 6.0 ? 0.8 : 0, bed: 0.15, eng: 0, engCut: 80, stress: 0, rumble: 0, rattle: 0, roar: 0 };
            return { master: 0.7, bed: 0.35, air: 0, eng: 0.05, engCut: 70, stress: 0.2, rumble: 0.05, rattle: 0, roar: 0 };
        }
        const st = S.stress;
        const inAir7 = S.shot === 7 && S.lt >= ENTRY_LT;
        const airK = S.shot === 1 ? 1 - smooth(8, 30, S.lt) : (inAir7 ? 1 : 0);
        const vis = S.vis || 0;
        const tauA = S.shot === 7 ? S.lt - ENTRY_LT : -1;
        // the roar: nothing before contact, a fast attack at contact, then it follows the braking speed, with a floor of storm wind
        const roar = inAir7 ? (0.025 + 0.22 * clamp01((vis - DIVE7.vt) / (DIVE7.vB - DIVE7.vt))) * smooth(0, 0.25, tauA) + 0.03 * Math.min(S.shake || 0, 1.2) : (S.shot === 1 ? 0.06 * airK : 0);
        const preAir = S.shot === 7 && !inAir7 ? 0.03 * smooth(2, 8, S.lt) : 0;
        const bed = S.shot === 1 ? 0.55 : S.shot === 7 ? 0.45 - 0.2 * smooth(0, 6, Math.max(0, tauA)) : 0.62;
        return { hiss: inAir7 ? 0.03 * Math.min(1, (S.heat || 0) * 1.4) : 0, master: 0.95, bed, air: 0.03 + preAir + (S.shot >= 2 && S.shot <= 6 ? 0.015 : 0),
            eng: S.shot === 1 ? 0.12 : 0.0, engCut: S.shot === 1 ? 260 : 90, stress: Math.min(st, 1),
            rumble: (0.05 + 0.26 * Math.min(st, 1)) * (0.35 + 0.65 * airK), rattle: (0.04 + 0.28 * Math.min(st, 1)) * (inAir7 ? 0.8 : 0.5 * airK), roar };
    }

    function frame(ts, resolve, whileBlack) {
        if (!active) return;
        if (paused) { rafId = requestAnimationFrame((n) => frame(n, resolve, whileBlack)); return; }
        const t = (ts - startTs) / 1000;
        const S = stateAt(t);
        // adapt render resolution if the device is struggling
        if (lastTs) { const dt = ts - lastTs; if (S.on && dt > 48) slowFrames++; else slowFrames = Math.max(0, slowFrames - 1); if (slowFrames > 18 && renderScale > 0.4) { renderScale *= 0.8; slowFrames = 0; fastFrames = 0; resize(); }
            if (S.on && dt < 22) fastFrames++; else fastFrames = 0;
            if (fastFrames > 180 && renderScale < baseScale) { renderScale = Math.min(baseScale, renderScale * 1.12); fastFrames = 0; resize(); } }
        lastTs = ts;
        draw(S); applyDOM(S); try { fxUpdate(S, t); } catch (err) { fx = null; }
        try { lineTick(t, S); } catch (err) {}
        if (audio) { audio.update(audioParams(S)); for (const e of events) if (!e.done && t >= e.t) { e.done = true; try { e.fn(); } catch (err) {} } }
        if (skipRequested || t >= T_END) { finish(resolve, whileBlack); return; }
        rafId = requestAnimationFrame((n) => frame(n, resolve, whileBlack));
    }
    let startTs = 0, events = [];
    async function finish(resolve, whileBlack) {
        active = false; paused = false; cancelAnimationFrame(rafId);
        stopVoice(); clearTimeout(capTimer); hideCap(); lineQ = [];
        if (audio) { audio.stop(); audio = null; }
        draw({ on: false }); applyDOM({ on: false, frame: 'rear', cracks: 0, stress: 0, t: 0, alarm: 0 });
        document.removeEventListener('keydown', onKey);
        try { if (whileBlack) await whileBlack(); } catch (e) { console.error(e); }
        if (root) { root.style.transition = 'opacity .8s ease'; root.classList.remove('on'); setTimeout(unmount, 900); }
        window.__ffCineActive = false;
        resolve();
    }
    // v83: pausing freezes the picture, the timeline, the synth and (where the browser allows) the voice, and asks whether to leave.
    function setPaused(on) {
        if (!active || on === paused) return;
        paused = on;
        const pe = root && root.querySelector('.ff-pause');
        if (on) {
            pauseStart = performance.now();
            try { if (cineCtx) cineCtx.suspend(); } catch (e) {}
            try { if (window.speechSynthesis) window.speechSynthesis.pause(); } catch (e) {}
            if (pe) pe.classList.add('on');
        } else {
            startTs += performance.now() - pauseStart; lastTs = 0; slowFrames = 0; fastFrames = 0;
            try { if (cineCtx) cineCtx.resume(); } catch (e) {}
            try { if (window.speechSynthesis) window.speechSynthesis.resume(); } catch (e) {}
            if (pe) pe.classList.remove('on');
        }
    }
    const onKey = (e) => { if (e.key === 'Escape') setPaused(!paused); };   // Space no longer skips; Escape opens/closes the pause prompt

    return {
        supported: testGL,
        get active() { return active; },
        skip() { skipRequested = true; },
        // Plays the whole piece. whileBlack runs once the picture has gone to black for the last time (teleport, etc.) before the cover fades out.
        play(o = {}) {
            return new Promise(async (resolve) => {
                if (!testGL) { resolve(); return; }
                try { mount(); } catch (e) { console.error(e); try { unmount(); } catch (e2) {} resolve(); return; }
                active = true; skipRequested = false; window.__ffCineActive = true;
                let tapT = 0;
                onLeaveCb = typeof o.onLeave === 'function' ? o.onLeave : null;
                root.addEventListener('pointerdown', (e) => {
                    if (e.target && e.target.closest && e.target.closest('.ff-pause')) return;   // taps on the prompt are not scene taps
                    const n = performance.now(); if (!paused && n - tapT < 450) { setPaused(true); tapT = 0; return; } tapT = n;
                });
                const _resumeBtn = root.querySelector('.ff-resume'), _leaveBtn = root.querySelector('.ff-leave');
                if (_resumeBtn) _resumeBtn.addEventListener('click', (e) => { e.stopPropagation(); setPaused(false); });
                if (_leaveBtn) _leaveBtn.addEventListener('click', (e) => { e.stopPropagation(); if (onLeaveCb) onLeaveCb(); });
                document.addEventListener('keydown', onKey);
                lineQ = buildLines(o.vale !== false); speaking = false; hideCap();
                const ctx = getAudioContext(); cineCtx = ctx || null;
                if (ctx) { try { if (ctx.state === 'suspended') ctx.resume(); audio = createAudio(ctx); events = buildEvents(); } catch (e) { audio = null; } }
                root.getBoundingClientRect(); root.classList.add('on');
                await new Promise(r => setTimeout(r, 120));
                startTs = performance.now(); lastTs = 0; slowFrames = 0;
                rafId = requestAnimationFrame((n) => { startTs = n; frame(n, resolve, o.whileBlack); });
            });
        },
        // test helpers (used by tests/ff_cine_shots.py)
        debug: { setMoonDir(d) { MOON_DIR = norm(d); }, stateAt, say(t) { showCap(t); },
            // Renders the whole soundtrack offline (same synth + same cues) and returns it as base64 16-bit mono PCM, for making a video.
            async renderAudioOffline(sr = 44100) {
                const ctx = new OfflineAudioContext(1, Math.ceil(sr * T_END), sr);
                audio = createAudio(ctx); events = buildEvents();
                const tick = (t) => { audio.update(audioParams(stateAt(t))); for (const e of events) if (!e.done && t >= e.t) { e.done = true; try { e.fn(); } catch (err) {} } };
                tick(0);
                for (let t = 0.05; t < T_END; t += 0.05) { const tt = t; ctx.suspend(tt).then(() => { tick(tt); ctx.resume(); }); }
                const buf = await ctx.startRendering(); audio = null;
                const d = buf.getChannelData(0), pcm = new Int16Array(d.length);
                for (let i = 0; i < d.length; i++) pcm[i] = Math.max(-1, Math.min(1, d[i])) * 32767;
                const u8 = new Uint8Array(pcm.buffer); let bin = '';
                for (let i = 0; i < u8.length; i += 0x8000) bin += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000));
                return btoa(bin);
            }, mount() { mount(); root.classList.add('on'); root.style.transition = 'none'; root.style.opacity = '1'; }, renderAt(t) { const S = stateAt(t); try { fxUpdate(S, t); } catch (e) {} draw(S); applyDOM(S); try { fxUpdate(S, t); } catch (e) {} return S.shot; }, unmount, duration: T_END, marks: { TS, TE } },
    };
}
