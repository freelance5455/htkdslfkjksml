# v82 - time passed, a real 3D speck, a longer strike

freefall_cinematic.js only.

- Time passed is back: from shot 2 on, the left hologram shows MET, ASLEEP (how long the pilot slept) and AWAKE (time since waking).
- Every wake-up, the AI says how long you were out (computed from the real gaps), that you still seem sleepy, and asks you to stay awake.
- The speck is now a real lumpy, tumbling, sun-lit 3D rock in the shader (no 2D overlay). It closes over 2.4 s and hits the OUTER pane of the layered canopy (the inner pane holds, which is why you survive), with a glare, a shock ring and 10 shards flying off.
- Shot 1 is 16 s longer: after the hit the ship spins at 4.5 rad/s while the AI fires its remaining thrusters in 5 burns, each taking part of the spin off (flare in the window, shake, sound), a DAMAGE CONTROL panel with loading bars (attitude recovery, stabilizer reboot that fails, RCS count, nav search) and a roll-rate readout. The pilot's lids flutter half open, then close. 3 new AI lines.
- Not verified: voice timing on a real device, real-GPU look.
- The moon has more depth: normals bumped from the height field so ridges and coasts catch the light, a blue hazy limb, limb darkening, a warm terminator and faint giant-glow on the night side.
- Dialogue rewritten: more human, with pauses, desperation during the hit, thinking aloud, varied wake-ups (the sleep time is mentioned only twice), and 9 lines across the descent and entry.
- Shot 2 now opens with the moon in the front window (amber giant-shine on its night side), sliding out of view as the ship turns to the giant.
