# v70 - the decree and the AI's confession (story step 3 of 6)
Not run in a browser; `game.js` passes a syntax check.

## What changed
- **Decree scene** (`runTribunalScene`): plays once, right after the player takes the last of the four personal items from the shuttle wreck (photo, both diary pages, locket). The exile decree shows on the red lens overlay, then the note left with it ("We know you didn't do it...") in the note panel.
- **The AI's confession**: it remembers it spent the last of the shuttle's power turning toward the green moon, then reveals it was with the player that day and knew the truth, but by law an AI cannot testify, collect evidence, speak in a proceeding, or have its records used; it could only help, barely. A door "left open for the one coming home from the shops" hints at Ren's mother without naming the relation. It reads the diary line "I hid the true record where only the sea could keep it" as meaning the AI itself is the record. New log entry "The Sentence". Saved as `tribunalSceneDone`.
- The boat-retreat chase timer no longer runs during cutscenes, so the confession cannot be interrupted by the chase.
- `runPhase4BroadcastOverlay` takes optional text and hold time.
- `diary_page_2.json` pickup line reworded so it no longer implies a stranger wrote the page (the confession treats the player as the writer).

## Still to do
4. Text fixes (centuries -> millennia / about two centuries) and the missing disc audio file. 5. Early plants for the ending (and the locket / photo payoffs). 6. Post-swarm handoff.
