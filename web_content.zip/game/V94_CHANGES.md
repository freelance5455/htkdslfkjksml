# v94: fronts, exposure, forecast (weather now matters)

Why: only rain ever showed up. Snow needed a cold climate, dust a hot arid one, and thunderstorms a rare noise peak, so a temperate
spawn never saw anything else. And weather was scenery: nothing in the game reacted to it.

## game.js
- FRONTS (wxFieldAt): three advected noise fields (air mass, instability, stable air) shift the LOCAL temperature and moisture for a while:
  cold outbreaks (up to -0.30 temp, +cloud, +moisture) bring snow to temperate ground; hot dry spells (+0.20 temp, -0.34 moisture) kill rain and
  lift dust; unstable pockets raise thunderstorm odds; stable damp air pools into fog banks (mostly dawn/dusk/night). They are advected with
  the clouds, so they roll in and move on. Only in 'auto' weather; the K presets behave exactly as before (WX.frontK eases to 0).
- Dust: a hot front adds dust anywhere (strong in arid country, only haze in wet country). Fog banks feed the existing fog.
- EXPOSURE: rain soaks you (playerWet), cold + wet + wind leak warmth by day and the warmth no longer regenerates while exposed. Weather alone
  floors warmth at 30 in daytime (you shiver and slow down instead of dying); at night soaked/cold multiplies the normal night drain.
  Snow depth slows you. Shelter, warehouse, boat, flower vehicle and scripted storms protect fully.
- HUD: status line above the warmth bar (DAMP, SOAKED, COLD, FREEZING, DUST, GALE, SHIVERING).
- FORECAST: weather is advected, so the game samples upwind (20/45/80/130/200 s ahead) and warns about the first storm cell, snow squall,
  rain front or dust wall with an ETA and a direction relative to where you are facing.
- Lightning: in a storm, ~7% of strikes land 30-140 units from you (a scare, no damage).

## Measured (tests/test_v94_fronts.mjs, share of sampled points; fronts off -> on)
- temperate: rain 6.6 -> 3.7%, snow 0 -> 3.0%, thunderstorm 1.1 -> 2.0%
- dry/hot: dust fronts 0 -> 14.6%
- cold: snow 5.2 -> 5.5%; tropics essentially unchanged (storm 7.4 -> 7.1%)

## Not verified
- Nothing was run in a browser. Syntax check passes; the front maths was tested headlessly. Exposure, HUD, forecast text and the lightning
  near-miss are untested in play. Tuning knobs: the 0.30 / 0.20 / 0.34 front magnitudes, the 0.40 instability weight, WEATHER_WARMTH_FLOOR.
