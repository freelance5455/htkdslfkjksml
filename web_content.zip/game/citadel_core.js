// =====================================================================================
// citadel_core.js - THE ROGUES' CITADEL generator (pure maths: no three.js, no DOM). One per world. Same output contract as generateCity()
// (pieces / cols / nodes / edges / poi / road mesh / beacon) so the instancing, collision, life and runtime code is shared.
//
// WHAT IT BUILDS (plan space: x = ground units EAST of the site centre, z = SOUTH, y = world height; see valley_sites.js for the ground)
//   * six LEVELS: the Roots (the meadow floor), then decks at +105 / +205 / +300 (the SKYTERRACE: parks + plazas, the tunnel's level) / +415 / +530
//     above the floor. Each deck is an organic outline (low harmonics), a ring of slabs that is walkable (row colliders), edged by a smooth
//     fascia + parapet, carried on flared pylons. Upper decks have a hub hole around the spire.
//   * SPIRAL ASCENTS: helical ramps (7-10 % grade) wound round a shaft in a circular well cut through the upper deck - the only way between levels.
//   * the SPIRE: one slim megastructure at the centre - a glass sheath around the beam, twisting ribs, ring nodes - that continues as a thin
//     sheathed needle to 12 000 m (51 000 units). The beam itself (blue -> green) is drawn by the runtime from city.beam.
//   * the TUNNEL: a straight bore under the saddle of the mountain ring, from the OUTER portal (end of the graded road) to the INNER portal,
//     which opens onto a promenade that runs straight into the Skyterrace.
//   * organic, sleek architecture: pearl shells, twisting ellipse towers, stepped garden terraces, conservatories, canopies; bioluminescent
//     trees, glowing pools, waterfalls and crystals in the enchanted valley.
// =====================================================================================
import { valleyHeight, citProfile, citSurface, citEdge, mulberry, h32 } from './valley_sites.js';
import { TAPERS, FLARES, PALETTES } from './city_core.js';

const s2l = (c) => c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
const hexLin = (hex) => [s2l(((hex >> 16) & 255) / 255), s2l(((hex >> 8) & 255) / 255), s2l((hex & 255) / 255)];
const clamp = (x, a, b) => x < a ? a : x > b ? b : x;
const lerp = (a, b, t) => a + (b - a) * t;
const ss = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
const TAU = Math.PI * 2;
export const CIT = { YT: 300, HT: 54, WT: 34, WR: 46, FH: 18, SPIRE_TOP: 51000, DECK: 14 };
// level heights above the floor, and outline radii. Level 0 is the ground.
const LEVELS = [
    { dy: 0, R: 1700, rIn: 0, name: 'Roots' },
    { dy: 105, R: 1450, rIn: 270, name: 'Lowmarket' },
    { dy: 205, R: 1660, rIn: 270, name: 'Guildworks' },
    { dy: 300, R: 2250, rIn: 270, name: 'Skyterrace' },
    { dy: 415, R: 1200, rIn: 230, name: 'Highgardens' },
    { dy: 530, R: 640, rIn: 200, name: 'Crown' },
];
const PEARL = [0xf3f1e8, 0xe9f0ec, 0xe2ebf0, 0xf0e9dc, 0xdfe8e3, 0xeae6f0].map(hexLin);
const TEAL = hexLin(0x35d8c0), AQUA = hexLin(0x3ea8ff), LEAF = hexLin(0x3fbf7a), LIME = hexLin(0x8be860), GOLD = hexLin(0xe7d29a), DEEP = hexLin(0x1b3b4a), WARM = hexLin(0xffd9a0), VIOLET = hexLin(0x9a7bff);
const DECKC = [hexLin(0xb9b2a2), hexLin(0xc7c0ae), hexLin(0xd4cdb9), hexLin(0xccd4cc), hexLin(0xd9d2c0), hexLin(0xe2dccc)];

class Grid {
    constructor(cell) { this.cell = cell; this.m = new Map(); }
    _k(i, j) { return i * 73856093 ^ j * 19349663; }
    add(o, r) { const c = this.cell; for (let i = Math.floor((o.x - r) / c); i <= Math.floor((o.x + r) / c); i++) for (let j = Math.floor((o.z - r) / c); j <= Math.floor((o.z + r) / c); j++) { const k = this._k(i, j); let l = this.m.get(k); if (!l) this.m.set(k, l = []); l.push(o); } }
    near(x, z, r) { const out = this._o || (this._o = new Set()); out.clear(); const c = this.cell;   // v65: one reusable Set per grid (no nested queries on the same grid)
         for (let i = Math.floor((x - r) / c); i <= Math.floor((x + r) / c); i++) for (let j = Math.floor((z - r) / c); j <= Math.floor((z + r) / c); j++) { const l = this.m.get(this._k(i, j)); if (l) for (const o of l) out.add(o); } return out; }
}

export function generateCitadel(S, nat, opts = {}) {
    const C = S.cit, rnd = mulberry(S.seedN ^ 0x91e10da5), R = (a, b) => a + (b - a) * rnd(), pick = (arr) => arr[Math.floor(rnd() * arr.length) % arr.length];
    const F = S.floorH;
    const ground = (x, z) => valleyHeight(S, x, -z, nat(x, z));
    const city = { seed: S.seedN, citadel: true, arche: 'citadel', palette: 'pearl', hubKind: 'spire', floorH: F, Rf: S.Rf, Rc: S.Rf, warmWindows: true, buildings: [], pieces: [], nodes: [], edges: [], poi: { homes: [], shops: [], works: [], plazas: [], docks: [], towers: [], gates: [], views: [] }, stats: {}, bridges: [], probes: [] };
    // plan axis of the tunnel: local (a east, n north) -> plan (x = a, z = -n)
    const tx = C.ca, tz = -C.sa, yawT = Math.atan2(tz, tx), px = -tz, pz = tx;     // (px, pz): lateral, to the left of the axis
    const axisPt = (s, l = 0) => [tx * s + px * l, tz * s + pz * l];
    // ---------- piece emit ----------
    let skipCol = false;
    const P = (cat, x, y, z, yaw, sx, sy, sz, color, pitch = 0, roll = 0) => city.pieces.push({ cat, x, y, z, yaw, sx, sy, sz, color, pitch, roll, nc: skipCol });
    const COL = city.cols = [];
    const addCol = (cx, cz, yaw, hw, hd, yBot, y0, y1, kind = 0) => { COL.push(cx, cz, yaw, hw, hd, yBot, y0, y1, kind); };
    const beam = (cat, x0, y0, z0, x1, y1, z1, t1, t2, color) => {
        const dx = x1 - x0, dy = y1 - y0, dz = z1 - z0, hz = Math.hypot(dx, dz), L = Math.hypot(hz, dy); if (L < 0.05) return;
        const yaw = hz > 1e-6 ? Math.atan2(dz, dx) : 0, pitch = Math.atan2(dy, hz), cp = Math.cos(pitch), sp = Math.sin(pitch);
        const ux = -Math.cos(yaw) * sp, uy = cp, uz = -Math.sin(yaw) * sp;
        P(cat, (x0 + x1) / 2 - ux * t1 / 2, (y0 + y1) / 2 - uy * t1 / 2, (z0 + z1) / 2 - uz * t1 / 2, yaw, L, t1, t2, color, pitch, 0);
    };
    const jit = (c, a) => { const k = 1 + (rnd() - 0.5) * a; return [clamp(c[0] * k, 0, 1), clamp(c[1] * k, 0, 1), clamp(c[2] * k, 0, 1)]; };
    const tpCat = (ratio) => { // nearest taper / flare category for top/bottom radius ratio
        if (ratio >= 1) { let bi = 0, bd = 9; FLARES.forEach((f, i) => { const d = Math.abs(f - ratio); if (d < bd) { bd = d; bi = i; } }); return 'fl' + bi; }
        let bi = 0, bd = 9; TAPERS.forEach((f, i) => { const d = Math.abs(f - ratio); if (d < bd) { bd = d; bi = i; } }); return 'tp' + bi;
    };
    // a frustum from radius r0 (bottom) to r1 (top), possibly elliptical (ex = x-stretch factor), as the nearest available cat
    const frustum = (x, y, z, yaw, r0, r1, h, color, ex = 1) => {
        const ratio = r1 / r0; if (Math.abs(ratio - 1) < 0.045) { P('orgCyl', x, y, z, yaw, r0 * 2 * ex, h, r0 * 2, color); return; }
        P(tpCat(ratio), x, y, z, yaw, r0 * 2 * ex, h, r0 * 2, color);
    };

    // ---------- the levels ----------
    const lay = LEVELS.map((L, i) => ({ i, y: F + L.dy, R: L.R * R(0.97, 1.04), rIn: L.rIn, ph: [R(0, TAU), R(0, TAU), R(0, TAU)], amp: [R(0.05, 0.1), R(0.03, 0.06), R(0.015, 0.035)], holes: [], name: L.name }));
    const outline = (L, phi) => L.R * (1 + L.amp[0] * Math.sin(3 * phi + L.ph[0]) + L.amp[1] * Math.sin(5 * phi + L.ph[1]) + L.amp[2] * Math.sin(8 * phi + L.ph[2]));
    const sIn = C.sIn, promW = 40;
    // the Skyterrace carries the tunnel promenade: a strip along the axis from the deck out to the inner portal
    const inLayer = (L, x, z, margin = 0) => {
        if (L.i === 0) return Math.hypot(x, z) < L.R - margin;
        const r = Math.hypot(x, z), phi = Math.atan2(z, x);
        let ok = r >= L.rIn + margin && r <= outline(L, phi) - margin;
        if (!ok && L.i === 3) { const s = x * tx + z * tz, l = x * px + z * pz; if (s > 1300 && s < sIn + 12 && Math.abs(l) < promW - margin) ok = true; }
        if (!ok) return false;
        for (const h of L.holes) if (Math.hypot(x - h.x, z - h.z) < h.r + margin) return false;
        return true;
    };
    const topAt = (x, z, below) => {   // top of the highest deck under (x, z) that is below `below`, else the ground
        let y = ground(x, z); for (const L of lay) if (L.i > 0 && L.y < below - 4 && L.y > y && inLayer(L, x, z, 0)) y = L.y; return y;
    };
    city.layers = lay.map(L => ({ i: L.i, y: L.y, R: L.R, rIn: L.rIn, name: L.name }));
    city.tunnel = { x0: 0, z0: 0, tx, tz, sA: sIn - 18, sB: C.sOut + 6, hw: CIT.WT + 6, yT: C.yT, gt: C.gt, sIn, sOut: C.sOut, ht: CIT.HT };

    // ---------- SPIRAL ASCENT PLAN (before the slabs: each one cuts a well through the deck above it) ----------
    const SP_RHO = 62, SP_HOLE = 108, SP_W = 30, SP_G = 0.09;
    const spirals = []; let promEnd = 0;
    for (let k = 0; k < 5; k++) {
        const lo = lay[k], up = lay[k + 1], want = k === 4 ? 3 : 4;
        for (let tr = 0, got = 0; tr < 900 && got < want; tr++) {
            const mg = up.i === 5 ? 118 : 150, a = R(0, TAU), r = R(Math.max(up.rIn, lo.rIn) + mg, Math.min(lo.R, up.R) - mg - 20), x = Math.cos(a) * r, z = Math.sin(a) * r;
            if (!inLayer(lo, x, z, mg) || !inLayer(up, x, z, mg)) continue;
            if (k === 2 && Math.abs(x * px + z * pz) < promW + 160 && x * tx + z * tz > 1000) continue;
            if (spirals.some(q => Math.hypot(q.x - x, q.z - z) < (up.i === 5 ? 250 : 360))) continue;
            const dyU = up.y - lo.y, len = dyU / SP_G, turns = len / (TAU * SP_RHO), dir = rnd() < 0.5 ? 1 : -1, th0 = R(0, TAU);
            const yLo = k === 0 ? ground(x, z) : lo.y, len2 = (up.y - yLo) / SP_G;
            spirals.push({ k, x, z, dir, th0, yLo, yUp: up.y, len: len2, turns: len2 / (TAU * SP_RHO), id: spirals.length });
            up.holes.push({ x, z, r: SP_HOLE }); got++;
        }
    }
    city.spirals = spirals.length;
    // ---------- SLABS: row colliders (walkable) + row visuals, a smooth fascia along every edge, parapets ----------
    const decks = lay.slice(1), fasc = [];
    const ROW = 16;
    const slabRows = (L) => {
        const R0 = (L.i === 3 ? Math.max(L.R * 1.12, sIn + 60) : L.R * 1.12), col = DECKC[L.i];
        let nRows = 0;
        for (let zc = -R0 + ROW / 2; zc < R0; zc += ROW) {
            let x0 = null;
            for (let x = -R0; x <= R0 + 8; x += 8) {
                const inn = x <= R0 && inLayer(L, x, zc, 0) && inLayer(L, x, zc - ROW / 2 + 1, 0) && inLayer(L, x, zc + ROW / 2 - 1, 0);
                if (inn && x0 === null) x0 = x; else if (!inn && x0 !== null) {
                    const x1 = x - 8, len = x1 - x0 + 8; if (len > 6) { const cx = (x0 + x1) / 2; P('plainBox', cx, L.y - CIT.DECK, zc, 0, len, CIT.DECK, ROW + 0.3, jit(col, 0.03)); addCol(cx, zc, 0, len / 2, ROW / 2 + 0.15, L.y - CIT.DECK - 2, L.y, L.y, 1); nRows++; } x0 = null;
                }
            }
        }
        return nRows;
    };
    for (const L of decks) { skipCol = true; L.rows = slabRows(L); skipCol = false; }
    // fascia + parapet along a closed or open polyline of boundary points. inward = +1 when the deck lies on the left of travel
    const edgeStrip = (L, pts, closed, inwardOf, gapTest) => {
        const n = pts.length, col = DECKC[L.i], glass = hexLin(0xbfe8f0);
        for (let i = 0; i < (closed ? n : n - 1); i++) {
            const p0 = pts[i], p1 = pts[(i + 1) % n], dx = p1[0] - p0[0], dz = p1[1] - p0[1], len = Math.hypot(dx, dz); if (len < 0.5) continue;
            const yaw = Math.atan2(dz, dx), mx = (p0[0] + p1[0]) / 2, mz = (p0[1] + p1[1]) / 2, [ix, iz] = inwardOf(mx, mz);
            const cx = mx + ix * 2, cz = mz + iz * 2;
            P('plainBox', cx, L.y - 19, cz, yaw, len + 1.2, 19, 18, jit(col, 0.05)); P('glow', mx + ix * 8.5, L.y - 17, mz + iz * 8.5, yaw, len, 0.7, 0.8, i % 9 === 0 ? AQUA : TEAL);
            if (gapTest && gapTest(mx, mz)) continue;
            const px2 = mx + ix * 5, pz2 = mz + iz * 5;
            P('plainBox', px2, L.y, pz2, yaw, len + 0.4, 5.5, 1.2, jit(glass, 0.05)); P('glow', px2, L.y + 5.5, pz2, yaw, len + 0.4, 0.6, 1.5, i % 4 === 0 ? TEAL : AQUA);
            addCol(px2, pz2, yaw, len / 2 + 0.4, 1.0, L.y, L.y + 5.5, L.y + 5.5, 0);
        }
    };
    const spGap = (x, z) => { for (const s of spirals) { if (s.landX === undefined) continue; if (Math.hypot(x - s.landX, z - s.landZ) < 24) return true; } return false; };
    for (const s of spirals) { const th = s.th0 + s.dir * s.turns * TAU; s.thE = th; s.landX = s.x + Math.cos(th) * (SP_HOLE - 2); s.landZ = s.z + Math.sin(th) * (SP_HOLE - 2); }
    for (const L of decks) {
        const step = 17; let pts = [], pts2 = [];
        for (let a = 0; a < TAU; ) { const r = outline(L, a); pts.push([Math.cos(a) * r, Math.sin(a) * r, a]); a += step / r; }
        const inside = (m) => (L.i === 3 && (m[0] * tx + m[1] * tz) > 1280 && Math.abs(m[0] * px + m[1] * pz) < promW + 8);
        // split the outer boundary into runs not swallowed by the promenade attachment
        let run = []; const runs = []; for (const p of pts) { if (inside(p)) { if (run.length > 1) runs.push(run); run = []; } else run.push(p); } if (run.length > 1) runs.push(run);
        if (L.i === 3 && runs.length >= 2) { const first = runs[0], last = runs[runs.length - 1]; if (Math.hypot(first[0][0] - last[last.length - 1][0], first[0][1] - last[last.length - 1][1]) < step * 2.5) { runs[0] = last.concat(first); runs.pop(); } }
        if (L.i !== 3) runs.length = 0, runs.push(pts.concat([pts[0]]));
        for (const rn of runs) edgeStrip(L, rn, false, (x, z) => { const l = Math.hypot(x, z) || 1; return [-x / l, -z / l]; }, null);
        if (L.rIn > 0) { const ring = []; for (let a = 0; a < TAU; a += 16 / L.rIn) ring.push([Math.cos(a) * L.rIn, Math.sin(a) * L.rIn]); edgeStrip(L, ring, true, (x, z) => { const l = Math.hypot(x, z) || 1; return [x / l, z / l]; }, null); }
        for (const h of L.holes) { const ring = [], rn = Math.max(14, 16 / h.r); for (let a = 0; a < TAU; a += rn) ring.push([h.x + Math.cos(a) * h.r, h.z + Math.sin(a) * h.r]); edgeStrip(L, ring, true, (x, z) => { const dx = x - h.x, dz = z - h.z, l = Math.hypot(dx, dz) || 1; return [dx / l, dz / l]; }, spGap); }
        if (L.i === 3) {   // the promenade's two sides + the end cap at the inner portal
            const sA = (() => { let s = 1300; while (s < sIn && inLayer(L, tx * s + px * (promW - 2), tz * s + pz * (promW - 2), 0) && Math.hypot(tx * s, tz * s) < outline(L, Math.atan2(tz * s, tx * s)) + 5) s += 4; return s - 20; })();
            for (const sg of [-1, 1]) { const ln = []; for (let s = sA; s <= sIn + 12; s += 16) ln.push(axisPt(s, sg * promW)); edgeStrip(L, ln, false, () => [-px * sg, -pz * sg], null); }
            promEnd = sA;
        }
    }

    // ---------- helpers: a round platform with floor colliders ----------
    const discFloor = (cx, cz, r, y, thick, color, cat = 'orgCyl') => {
        P(cat, cx, y - thick, cz, 0, r * 2, thick, r * 2, color);
        for (let zc = -r + 8; zc < r; zc += 16) { const half = Math.sqrt(Math.max(0, r * r - (Math.abs(zc) + 8) ** 2)); if (half > 4) addCol(cx, cz + zc, 0, half, 8.2, y - thick - 2, y, y, 1); }
    };
    const solidCyl = (x, z, r, y0, y1) => addCol(x, z, 0, r * 0.8, r * 0.8, y0, y1, y1, 0);

    // ---------- SPIRAL ASCENTS (ramp + rails + shaft + landing) ----------
    const spNodes = [];
    for (const s of spirals) {
        const n = Math.max(8, Math.ceil(s.len / 9)), pt = (t) => { const th = s.th0 + s.dir * s.turns * TAU * t; return [s.x + Math.cos(th) * SP_RHO, s.yLo + (s.yUp - s.yLo) * t, s.z + Math.sin(th) * SP_RHO, th]; };
        const colr = jit(hexLin(0xd8d2c0), 0.05);
        let prev = pt(0);
        for (let i = 1; i <= n; i++) {
            const cur = pt(i / n), dx = cur[0] - prev[0], dz = cur[2] - prev[2], L = Math.hypot(dx, dz), yaw = Math.atan2(dz, dx);
            skipCol = true; beam('plainBox', prev[0], prev[1] - 1.2, prev[2], cur[0], cur[1] - 1.2, cur[2], 2.4, SP_W, colr); skipCol = false;
            addCol((prev[0] + cur[0]) / 2, (prev[2] + cur[2]) / 2, yaw, L / 2 + 0.4, SP_W / 2, Math.min(prev[1], cur[1]) - 3, prev[1], cur[1], 1);
            for (const sg of [-1, 1]) {   // rails on the inner / outer edge
                const f0 = (SP_RHO + sg * (SP_W / 2 - 0.8)) / SP_RHO; const a0 = [s.x + (prev[0] - s.x) * f0, s.z + (prev[2] - s.z) * f0], a1 = [s.x + (cur[0] - s.x) * f0, s.z + (cur[2] - s.z) * f0];
                beam('glow', a0[0], prev[1] + 4.4, a0[1], a1[0], cur[1] + 4.4, a1[1], 0.6, 0.7, sg > 0 ? TEAL : AQUA);
                if (i % 4 === 0) P('plainBox', a1[0], cur[1] - 0.5, a1[1], yaw, 0.6, 5, 0.6, jit(PEARL[0], 0.1));
            }
            if (i % 14 === 0) { const mx = (cur[0] + s.x) / 2, mz = (cur[2] + s.z) / 2; beam('plainBox', s.x + (cur[0] - s.x) * 0.36, cur[1] - 2.2, s.z + (cur[2] - s.z) * 0.36, cur[0], cur[1] - 2.4, cur[2], 1.6, 1.6, jit(PEARL[1], 0.1)); void mx; }
            if (i % 3 === 0) spNodes.push({ s, x: cur[0], y: cur[1], z: cur[2], t: i / n });
            prev = cur;
        }
        // shaft + glow rings, landing at the top
        P('orgCyl', s.x, s.yLo - 2, s.z, 0, 44, s.yUp - s.yLo + 6, 44, jit(PEARL[2], 0.05)); solidCyl(s.x, s.z, 22, s.yLo - 2, s.yUp + 4);
        for (let y = s.yLo + 16; y < s.yUp - 6; y += 26) P('glowCyl', s.x, y, s.z, 0, 46, 1.4, 46, (y / 26 | 0) & 1 ? TEAL : AQUA);
        P('orgCyl', s.x, s.yUp + 4, s.z, 0, 52, 3, 52, jit(PEARL[3], 0.04)); P('glowCyl', s.x, s.yUp + 7, s.z, 0, 24, 14, 24, s.k & 1 ? LEAF : AQUA);
        const e = pt(1), lx = Math.cos(e[3]), lz = Math.sin(e[3]), r1 = SP_HOLE + 26, ex = s.x + lx * r1, ez = s.z + lz * r1;   // the landing runs well onto the deck (rows end up to 16 short of a hole's rim)
        skipCol = true; beam('plainBox', e[0], s.yUp - 1.2, e[2], ex, s.yUp - 1.2, ez, 2.4, SP_W + 4, colr); skipCol = false;
        addCol((e[0] + ex) / 2, (e[2] + ez) / 2, Math.atan2(ez - e[2], ex - e[0]), Math.hypot(ex - e[0], ez - e[2]) / 2 + 0.6, (SP_W + 4) / 2, s.yUp - 3, s.yUp, s.yUp, 1);
        s.top = { x: s.x + lx * (SP_HOLE + 40), z: s.z + lz * (SP_HOLE + 40), y: s.yUp }; s.bot = pt(0);
        P('glow', s.x + lx * (SP_HOLE - 8), s.yUp + 12, s.z + lz * (SP_HOLE - 8), e[3], 1.4, 12, 28, s.k & 1 ? TEAL : LEAF);
        city.poi.views.push({ x: s.x, z: s.z, y: s.yUp + 0.4, kind: 'spiral' });
    }

    const pylons = [];
    city.pylons = pylons.length;

    // ---------- THE SPIRE: slim megastructure, glass sheath round the beam, twisting ribs, ring nodes, a sheathed needle to 12 000 m ----------
    const SP_H = 2600, topY = F + CIT.SPIRE_TOP;
    { const gy = Math.max(...[0, 1, 2, 3, 4, 5, 6, 7].map(k => ground(Math.cos(k * 0.785) * 240, Math.sin(k * 0.785) * 240)), F) + 0.6;
      P('orgCyl', 0, F - 40, 0, 0, 480, gy - F + 40, 480, jit(DECKC[2], 0.04)); P('glowCyl', 0, gy, 0, 0, 436, 0.5, 436, jit(TEAL, 0.1));
      for (let zc = -228; zc < 232; zc += 16) { const half = Math.sqrt(Math.max(0, 240 * 240 - (Math.abs(zc) + 8) ** 2)); addCol(0, zc, 0, half, 8.2, F - 42, gy, gy, 1); }
      city.heartY = gy; }
    P('glassCyl', 0, F, 0, 0, 40, SP_H, 40, hexLin(0xbdf2e8)); P('orgCyl', 0, F, 0, 0, 56, 28, 56, PEARL[0]); P('glowCyl', 0, F + 28, 0, 0, 58, 2, 58, TEAL); solidCyl(0, 0, 28, F, F + 28);
    const ribPt = (k, t) => { const rho = 26 + 150 * Math.pow(1 - t, 2.2), th = k * (TAU / 6) + 2.4 * t; return [Math.cos(th) * rho, F + SP_H * Math.pow(t, 1.05), Math.sin(th) * rho, rho]; };
    for (let k = 0; k < 6; k++) {
        let prev = ribPt(k, 0); const NS = 44;
        P('orgCyl', prev[0], F - 4, prev[2], 0, 40, 10, 40, PEARL[2]); solidCyl(prev[0], prev[2], 20, F - 4, F + 80);
        for (let i = 1; i <= NS; i++) { const t = i / NS, cur = ribPt(k, t), th = 3 + 7 * (1 - t); beam('plainBox', prev[0], prev[1], prev[2], cur[0], cur[1], cur[2], th, th, jit(PEARL[k % 3], 0.05)); if (i % 4 === 0) beam('glow', prev[0], prev[1] + th * 0.5, prev[2], cur[0], cur[1] + th * 0.5, cur[2], 0.8, th + 0.6, k & 1 ? TEAL : AQUA); prev = cur; }
    }
    for (const t of [0.08, 0.17, 0.27, 0.38, 0.5, 0.63, 0.78, 0.92]) { const p = ribPt(0, t), rho = 26 + 150 * Math.pow(1 - t, 2.2), y = p[1]; P('orgCyl', 0, y, 0, 0, rho * 2 + 20, 4, rho * 2 + 20, jit(PEARL[1], 0.05)); P('glowCyl', 0, y + 4, 0, 0, rho * 2 + 22, 1.6, rho * 2 + 22, (t * 100 | 0) & 1 ? LEAF : AQUA);
        for (let k = 0; k < 6; k++) { const a = ribPt(k, t), b = ribPt((k + 1) % 6, t); beam('plainBox', a[0], a[1], a[2], b[0], b[1], b[2], 1.6, 1.6, PEARL[4]); } }
    P('orgCone', 0, F + SP_H, 0, 0, 44, 220, 44, PEARL[0]); P('glowCyl', 0, F + SP_H + 220, 0, 0, 14, 60, 14, AQUA);
    // the needle: a thin glass sheath all the way up, with ring nodes every ~300 m
    P('glassCyl', 0, F + SP_H, 0, 0, 24, topY - F - SP_H, 24, hexLin(0xbdf2e8));
    for (let y = F + SP_H + 1275, k = 0; y < topY - 200; y += 1275, k++) { P('orgCyl', 0, y, 0, 0, 38, 34, 38, PEARL[k % 3]); P('glowCyl', 0, y + 34, 0, 0, 70, 2.5, 70, k & 1 ? LEAF : AQUA); for (let q = 0; q < 3; q++) { const a = q * TAU / 3 + k; beam('plainBox', 0, y + 34, 0, Math.cos(a) * 33, y + 34 - 90, Math.sin(a) * 33, 2.4, 2.4, PEARL[2]); } }
    P('glowCyl', 0, topY - 110, 0, 0, 120, 4, 120, LEAF); P('glowCyl', 0, topY - 70, 0, 0, 60, 70, 60, [0.8, 1, 0.95]); P('orgCone', 0, topY, 0, 0, 30, 140, 30, PEARL[0]);
    city.beam = { x: 0, z: 0, y0: F, y1: topY, rInner: 5, rOuter: 15 };
    city.poi.towers.push({ x: 0, z: 0, y: F + SP_H, h: SP_H }); city.poi.plazas.push({ x: 0, z: 0, y: city.heartY, r: 220, kind: 'hub' });

    // ---------- THE TUNNEL: a straight bore under the saddle, inner portal (Skyterrace side) to outer portal ----------
    const posAt = (s, l, y) => { const p = axisPt(s, l); return [p[0], y, p[1]]; };
    const tunnelCol = jit(hexLin(0xc9c4b4), 0.03), tunnelWall = jit(PEARL[4], 0.03);
    { const sA = sIn - 18, sB = C.sOut + 6, WT = CIT.WT, HT = CIT.HT; let k = 0;
      for (let s0 = sA; s0 < sB; s0 += 40, k++) {
        const s1 = Math.min(sB, s0 + 40), y0 = citProfile(C, s0), y1 = citProfile(C, s1), L = s1 - s0, m = axisPt((s0 + s1) / 2, 0), ym = (y0 + y1) / 2, a0 = posAt(s0, 0, y0), a1 = posAt(s1, 0, y1);
        skipCol = true;
        beam('plainBox', a0[0], y0 - 1.5, a0[2], a1[0], y1 - 1.5, a1[2], 3, 2 * WT + 8, tunnelCol);
        addCol(m[0], m[1], yawT, L / 2 + 0.4, WT + 3, Math.min(y0, y1) - 4, y0, y1, 1);
        for (const sg of [-1, 1]) {
            const w0 = posAt(s0, sg * (WT + 2.5), y0 + (HT - 8) / 2), w1 = posAt(s1, sg * (WT + 2.5), y1 + (HT - 8) / 2), wm = axisPt((s0 + s1) / 2, sg * (WT + 2.5));
            beam('plainBox', w0[0], w0[1] - 2, w0[2], w1[0], w1[1] - 2, w1[2], HT - 4, 5, tunnelWall); addCol(wm[0], wm[1], yawT, L / 2 + 0.4, 2.7, Math.min(y0, y1) - 3, y0 + HT - 4, y1 + HT - 4, 0);
            for (const [lat, hh, tt, ww] of [[WT - 1, HT - 14, 8, 8], [WT - 8, HT - 6, 8, 10]]) { const c0 = posAt(s0, sg * lat, y0 + hh), c1 = posAt(s1, sg * lat, y1 + hh); beam('plainBox', c0[0], c0[1], c0[2], c1[0], c1[1], c1[2], tt, ww, tunnelWall); }
            const g0 = posAt(s0 + 8, sg * (WT - 0.5), y0 + 17), g1 = posAt(s1 - 8, sg * (WT - 0.5), y1 + 17); beam('glow', g0[0], g0[1], g0[2], g1[0], g1[1], g1[2], 9, 0.7, k & 1 ? TEAL : AQUA);
            const e0 = posAt(s0, sg * (WT - 3), y0 + 0.2), e1 = posAt(s1, sg * (WT - 3), y1 + 0.2); beam('glow', e0[0], e0[1], e0[2], e1[0], e1[1], e1[2], 0.4, 1.3, LEAF);
        }
        const r0 = posAt(s0, 0, y0 + HT - 1), r1 = posAt(s1, 0, y1 + HT - 1); beam('plainBox', r0[0], r0[1], r0[2], r1[0], r1[1], r1[2], 7, 2 * (WT + 3), tunnelCol);
        addCol(m[0], m[1], yawT, L / 2 + 0.4, WT + 4, ym + HT - 5, y0 + HT + 4, y1 + HT + 4, 0);
        const l0 = posAt(s0 + 4, 0, y0 + HT - 5.4), l1 = posAt(s1 - 4, 0, y1 + HT - 5.4); beam('glow', l0[0], l0[1], l0[2], l1[0], l1[1], l1[2], 0.7, 9, k % 3 === 0 ? AQUA : TEAL);
        skipCol = false;
      }
      // portals: a flared arch frame facing out of / into the mountain
      const portal = (s, face) => {
          const y = citProfile(C, s), Wp = WT + 16, hh = HT - 2;
          for (const sg of [-1, 1]) { const c = posAt(s, sg * Wp, y - 8), q = axisPt(s, sg * Wp); frustum(c[0], c[1], c[2], 0, 15, 11, HT + 44, jit(PEARL[0], 0.04)); solidCyl(q[0], q[1], 13, y - 8, y + HT + 36); P('glowCyl', c[0], y + HT + 36, c[2], 0, 13, 2, 13, TEAL); }
          let prev = null; const N = 26;
          for (let i = 0; i <= N; i++) { const th = Math.PI * i / N, l = Math.cos(th) * Wp, h = y + hh + Math.sin(th) * (Wp * 0.62), cur = posAt(s, l, h); if (prev) { beam('plainBox', prev[0], prev[1], prev[2], cur[0], cur[1], cur[2], 8, 18, jit(PEARL[1], 0.03)); const w0 = posAt(s + face * 9.2, Math.cos(Math.PI * (i - 1) / N) * (Wp - 7), y + hh + Math.sin(Math.PI * (i - 1) / N) * (Wp * 0.62 - 4)), w1 = posAt(s + face * 9.2, Math.cos(th) * (Wp - 7), y + hh + Math.sin(th) * (Wp * 0.62 - 4)); beam('glow', w0[0], w0[1], w0[2], w1[0], w1[1], w1[2], 1.4, 0.8, i & 1 ? TEAL : AQUA); } prev = cur; }
          const k0 = posAt(s, 0, y + hh + Wp * 0.62 + 4); P('glow', k0[0], k0[1], k0[2], yawT, 1.6, 10, 10, LEAF);
      };
      portal(sIn - 14, -1); portal(C.sOut + 2, 1);
      // the outer road bed: a slab on the graded profile from the outer portal to where the road meets the ground
      for (let s0 = C.sOut, kk = 0; s0 < C.sEnd; s0 += 36, kk++) {
          const s1 = Math.min(C.sEnd, s0 + 36), y0 = citProfile(C, s0), y1 = citProfile(C, s1), a0 = posAt(s0, 0, y0 + 0.6), a1 = posAt(s1, 0, y1 + 0.6), m = axisPt((s0 + s1) / 2, 0), L = s1 - s0;
          skipCol = true; beam('plainBox', a0[0], a0[1] - 3, a0[2], a1[0], a1[1] - 3, a1[2], 3.6, 2 * (CIT.WR - 6), jit(hexLin(0x6f6c66), 0.05)); skipCol = false;
          addCol(m[0], m[1], yawT, L / 2 + 0.4, CIT.WR - 6, Math.min(y0, y1) - 4, y0 + 0.6, y1 + 0.6, 1);
          for (const sg of [-1, 1]) { const q0 = posAt(s0, sg * (CIT.WR - 8), y0 + 0.9), q1 = posAt(s1, sg * (CIT.WR - 8), y1 + 0.9); beam('glow', q0[0], q0[1], q0[2], q1[0], q1[1], q1[2], 0.4, 1.2, kk & 1 ? TEAL : LEAF); if (kk % 3 === 0) { const pl = posAt(s0, sg * (CIT.WR - 4), y0); P('plainCyl', pl[0], pl[1] - 2, pl[2], 0, 1.2, 14, 1.2, PEARL[3]); P('glow', pl[0], pl[1] + 12, pl[2], 0, 3, 3, 3, WARM); } }
      }
      { const q0 = axisPt(C.sEnd, 0), q1 = axisPt(C.sEnd + 40, 0), y0 = citProfile(C, C.sEnd) + 0.6, y1 = ground(q1[0], q1[1]) + 0.2, m = axisPt(C.sEnd + 20, 0);   // the road's last ramp meets the ground
        skipCol = true; beam('plainBox', q0[0], y0 - 3, q0[1], q1[0], y1 - 3, q1[1], 3.6, 2 * (CIT.WR - 6), jit(hexLin(0x6f6c66), 0.05)); skipCol = false;
        addCol(m[0], m[1], yawT, 20.4, CIT.WR - 6, Math.min(y0, y1) - 4, y0, y1, 1); }
      city.poi.gates.push({ x: axisPt(C.sOut + 120, 0)[0], z: axisPt(C.sOut + 120, 0)[1], y: citProfile(C, C.sOut + 120), yaw: yawT });
    }
    // promenade supports: slender pylons down to the ground wherever the strip floats
    for (let s = 1500; s < sIn - 230; s += 150) for (const sg of [-1, 1]) {
        const q = axisPt(s, sg * (promW - 12)), gy = ground(q[0], q[1]), H = CIT.YT + F - CIT.DECK - gy; if (H < 24 || Math.hypot(q[0], q[1]) < 2150) continue;
        frustum(q[0], gy - 2, q[1], 0, 16, 10, Math.min(H * 0.4, 60) + 2, PEARL[2]); P('orgCyl', q[0], gy + Math.min(H * 0.4, 60), q[1], 0, 20, H - Math.min(H * 0.4, 60) - 28, 20, PEARL[2]); frustum(q[0], F + CIT.YT - CIT.DECK - 28, q[1], 0, 10, 17, 28, PEARL[2]); solidCyl(q[0], q[1], 14, gy - 2, F + CIT.YT - CIT.DECK);
    }
    // sample ground-level extents for later placement
    city.cutting = { sFrom: sIn - 250, sTo: sIn };

    // ---------- STREETS: per level, rings + curved spokes (a nautilus plan). Nodes / edges for the drones, ribbons for the eye ----------
    const occ = lay.map(() => new Grid(70));
    // v65: every GROUND street (the Roots' own and the new outer ones) is registered as a chain of short segments, for the ground city's lots
    const distSeg = (qx, qz, ax, az, bx, bz) => { const dx = bx - ax, dz = bz - az, l2 = dx * dx + dz * dz || 1, t = clamp(((qx - ax) * dx + (qz - az) * dz) / l2, 0, 1), ex = ax + dx * t - qx, ez = az + dz * t - qz; return Math.sqrt(ex * ex + ez * ez); };
    const G0 = [], gseg = new Grid(60);
    const addGChain = (pts, w, isNew) => {
        G0.push({ pts, w });
        for (let i = 0; i + 1 < pts.length; i++) { const a = pts[i], b = pts[i + 1], L = Math.hypot(b[0] - a[0], b[1] - a[1]); if (L < 0.2) continue; const sg = { x: (a[0] + b[0]) / 2, z: (a[1] + b[1]) / 2, ax: a[0], az: a[1], bx: b[0], bz: b[1], w, L, isNew: !!isNew, yaw: Math.atan2(b[1] - a[1], b[0] - a[0]) }; gseg.add(sg, L / 2 + w / 2); }
    };
    const nearGStreet = (x, z, pad, onlyNew) => { for (const sg of gseg.near(x, z, pad + 40)) { if (onlyNew && !sg.isNew) continue; if (distSeg(x, z, sg.ax, sg.az, sg.bx, sg.bz) < sg.w / 2 + pad) return true; } return false; };
    const nodes = city.nodes, edges = city.edges, road = city.road = { pos: [], nor: [], col: [], idx: [] };
    const addNode = (x, z, y, kind, lv) => { nodes.push({ id: nodes.length, x, z, y, kind, lv, adj: [] }); return nodes.length - 1; };
    const addEdge = (a, b, w, t = 0) => { if (a === b || nodes[a].adj.includes(b)) return; edges.push({ a, b, w, lvl: nodes[a].lv, t }); nodes[a].adj.push(b); nodes[b].adj.push(a); };
    const ribbon = (pts, w, yOf, color) => {
        for (let i = 0; i + 1 < pts.length; i++) {
            const a = pts[i], b = pts[i + 1], dx = b[0] - a[0], dz = b[1] - a[1], l = Math.hypot(dx, dz); if (l < 0.2) continue; const nx = -dz / l * w / 2, nz = dx / l * w / 2, ya = yOf(a[0], a[1]), yb = yOf(b[0], b[1]), base = road.pos.length / 3;
            road.pos.push(a[0] + nx, ya, a[1] + nz, a[0] - nx, ya, a[1] - nz, b[0] - nx, yb, b[1] - nz, b[0] + nx, yb, b[1] + nz);
            for (let q = 0; q < 4; q++) { road.nor.push(0, 1, 0); road.col.push(color[0], color[1], color[2]); }
            road.idx.push(base, base + 1, base + 2, base, base + 2, base + 3);
        }
    };
    const levelY = (L) => (x, z) => L.i === 0 ? ground(x, z) + 0.25 : L.y + 0.18;
    const paveCol = [hexLin(0xeee8d8), hexLin(0xe6efe2), hexLin(0xdde8ec), hexLin(0xefe6d2), hexLin(0xe2e9dd), hexLin(0xf1ede0)];
    for (const L of lay) {
        const Rm = L.R * 0.9, r0 = L.i === 0 ? 300 : Math.max(L.rIn + 130, 230), step = R(185, 225), rings = []; for (let r = r0; r < Rm; r += step) rings.push(r);
        L.rings = rings; L.r0 = r0; L.K = Math.max(8, Math.round(Rm / 105)); L.sw = R(0.25, 0.5) * (L.i & 1 ? 1 : -1); L.phik = []; for (let k = 0; k < L.K; k++) L.phik.push(k / L.K * TAU + R(-0.04, 0.04));
        L.spokeAng = (k, r) => L.phik[k] + L.sw * (r - r0) / 1000;
        const Y = levelY(L), N = []; const w1 = 16, w2 = 13, ok = (x, z) => inLayer(L, x, z, 20) && !spirals.some(q => q.k === L.i && Math.hypot(q.x - x, q.z - z) < 104);   // streets keep out of the footprint of a ramp that starts on this level
        for (let j = 0; j < rings.length; j++) { N.push([]); for (let k = 0; k < L.K; k++) { const r = rings[j], a = L.spokeAng(k, r), x = Math.cos(a) * r, z = Math.sin(a) * r; N[j].push(ok(x, z) ? addNode(x, z, Y(x, z), j % 2 ? 3 : 1, L.i) : -1); } }
        const chain = (pa, pb, line, w, kindW) => {   // sub-divided polyline between two intersection nodes (pts from `line(t)`), edges only if every sample is inside
            const len = line.len, n = Math.max(1, Math.ceil(len / 64)), ids = [pa]; const pts = [[nodes[pa].x, nodes[pa].z]];
            for (let q = 1; q < n; q++) { const [x, z] = line.at(q / n); if (!ok(x, z)) return false; ids.push(addNode(x, z, Y(x, z), 4, L.i)); pts.push([x, z]); }
            ids.push(pb); pts.push([nodes[pb].x, nodes[pb].z]);
            for (let q = 0; q + 1 < ids.length; q++) addEdge(ids[q], ids[q + 1], w, 0);
            const fine = [pts[0]]; for (let q = 1; q <= n * 4; q++) fine.push(line.at(q / (n * 4))); fine[fine.length - 1] = pts[pts.length - 1]; ribbon(fine, w, Y, paveCol[L.i % paveCol.length]); if (L.i === 0) addGChain(fine, w, false); return true;
        };
        for (let j = 0; j < rings.length; j++) for (let k = 0; k < L.K; k++) {
            const r = rings[j], a = N[j][k], b = N[j][(k + 1) % L.K]; if (a < 0 || b < 0) continue;
            const a0 = L.spokeAng(k, r); let a1 = L.spokeAng((k + 1) % L.K, r); while (a1 < a0) a1 += TAU; while (a1 - a0 > TAU) a1 -= TAU;
            chain(a, b, { len: r * (a1 - a0), at: (t) => { const an = lerp(a0, a1, t); return [Math.cos(an) * r, Math.sin(an) * r]; } }, w1);
        }
        for (let k = 0; k < L.K; k++) for (let j = 0; j + 1 < rings.length; j++) {
            const a = N[j][k], b = N[j + 1][k]; if (a < 0 || b < 0) continue; const r0_ = rings[j], r1_ = rings[j + 1];
            chain(a, b, { len: (r1_ - r0_) * 1.05, at: (t) => { const r = lerp(r0_, r1_, t), an = L.spokeAng(k, r); return [Math.cos(an) * r, Math.sin(an) * r]; } }, w2);
        }
        L.N = N; L.nodeIdx = nodes.filter(n => n.lv === L.i).map(n => n.id);
    }
    // ---------- v65: THE GROUND CITY, part 1 - ordinary streets over the whole valley floor ----------
    // Rings and radials continue outward from the Roots' last ring to the edge of the meadow (citEdge). Radials are re-spaced band by band so the blocks stay ~270 wide.
    const cityEdge = (x, z) => citEdge(C, x, -z);
    const onCorr = (x, z, pad) => (x * tx + z * tz) > 1300 && Math.abs(x * px + z * pz) < promW + 40 + pad;     // the promenade / tunnel corridor keeps its own ground
    const g0Slope = (x, z) => Math.hypot(ground(x + 18, z) - ground(x - 18, z), ground(x, z + 18) - ground(x, z - 18)) / 36;
    const groundCityOK = (x, z, m = 0) => { const r = Math.hypot(x, z); return r < cityEdge(x, z) - m && r > 275 && !onCorr(x, z, m) && g0Slope(x, z) < 0.45; };
    {
        const L0 = lay[0], lastRing = L0.rings[L0.rings.length - 1], w1n = 19, w2n = 15, ringsG = [], rMaxG = Math.max(...C.rvT);
        for (let r = lastRing + R(190, 230); r < rMaxG - 30; r += R(185, 235)) ringsG.push(r);
        const ringNodes = ringsG.map(() => []);
        const okS = (x, z) => groundCityOK(x, z, 30) && !spirals.some(q => q.k === 0 && Math.hypot(q.x - x, q.z - z) < 104);
        const nodeAtRing = (j, ang) => {
            const r = ringsG[j]; let a = ang % TAU; if (a < 0) a += TAU;
            for (const q of ringNodes[j]) { let d = a - q.a; d -= TAU * Math.floor((d + Math.PI) / TAU); if (Math.abs(d) * r < 46) return q.id; }
            const x = Math.cos(a) * r, z = Math.sin(a) * r; if (!okS(x, z)) return -1;
            const id = addNode(x, z, ground(x, z) + 0.25, j % 2 ? 3 : 1, 0); ringNodes[j].push({ a, id }); return id;
        };
        const chainG = (pa, pb, at, len, w) => {   // at(t) -> [x, z]; intermediate nodes every ~64 units; false when any sample is off the usable ground
            const n = Math.max(1, Math.ceil(len / 64)), ids = [pa], fine = [[nodes[pa].x, nodes[pa].z]];
            for (let q = 1; q <= n * 4; q++) { const p = at(q / (n * 4)); if (q < n * 4 && !okS(p[0], p[1])) return false; fine.push(p); }
            fine[fine.length - 1] = [nodes[pb].x, nodes[pb].z];
            for (let q = 1; q < n; q++) { const p = at(q / n); ids.push(addNode(p[0], p[1], ground(p[0], p[1]) + 0.25, 4, 0)); }
            ids.push(pb); for (let q = 0; q + 1 < ids.length; q++) addEdge(ids[q], ids[q + 1], w, 0);
            ribbon(fine, w, (x, z) => ground(x, z) + 0.25, hexLin(0x54575c)); addGChain(fine, w, true);
            for (let q = 0; q < fine.length; q += 2) occ[0].add({ x: fine[q][0], z: fine[q][1], r: w / 2 + 3 }, w / 2 + 3);
            return true;
        };
        const radial = (na, nb, w) => { const A = nodes[na], B = nodes[nb]; if (na < 0 || nb < 0 || na === nb) return; chainG(na, nb, (t) => [lerp(A.x, B.x, t), lerp(A.z, B.z, t)], Math.hypot(B.x - A.x, B.z - A.z), w); };
        // band -1: the Roots' outer spokes run on to the first new ring
        if (ringsG.length) for (let k = 0; k < L0.K; k++) { const na = L0.N[L0.rings.length - 1][k]; if (na < 0) continue; const nb = nodeAtRing(0, Math.atan2(nodes[na].z, nodes[na].x)); radial(na, nb, w1n); }
        for (let j = 0; j + 1 < ringsG.length; j++) {
            const mid = (ringsG[j] + ringsG[j + 1]) / 2, n = Math.max(L0.K, Math.round(TAU * mid / 265)), ph = R(0, TAU);
            for (let i = 0; i < n; i++) { if (rnd() < 0.05) continue; const a = ph + (i + R(-0.15, 0.15)) / n * TAU, na = nodeAtRing(j, a), nb = nodeAtRing(j + 1, a); radial(na, nb, w2n); }
        }
        for (let j = 0; j < ringsG.length; j++) {
            const r = ringsG[j], list = ringNodes[j].slice().sort((p, q) => p.a - q.a), m = list.length; if (m < 2) continue;
            for (let i = 0; i < m; i++) { const p = list[i], q = list[(i + 1) % m]; let a1 = q.a; while (a1 <= p.a) a1 += TAU; if (a1 - p.a > 1.2 && m > 2) continue; chainG(p.id, q.id, (t) => { const an = lerp(p.a, a1, t); return [Math.cos(an) * r, Math.sin(an) * r]; }, r * (a1 - p.a), w1n); }
        }
        city.stats.groundRings = ringsG.length;
    }
    const nearestNode = (x, z, y, maxD, filt) => { let b = -1, bd = maxD * maxD; for (const n of nodes) { const d = (n.x - x) ** 2 + (n.z - z) ** 2 + ((n.y - y) * 2) ** 2; if (d >= bd) continue; if (filt && !filt(n)) continue; bd = d; b = n.id; } return b; };   // v65: distance first (the filters are costly and the ground city added ~1100 nodes)
    // a straight link is only legal while every sample of it stays on the deck (not over a hole / off the edge)
    const segOK = (lv, x0, z0, x1, z1) => { const L = lay[lv], n = Math.max(1, Math.ceil(Math.hypot(x1 - x0, z1 - z0) / 8)); for (let q = 0; q <= n; q++) { const qx = lerp(x0, x1, q / n), qz = lerp(z0, z1, q / n); if (!inLayer(L, qx, qz, 9) && !(lv === 0 && Math.hypot(qx, qz) < cityEdge(qx, qz) && !onCorr(qx, qz, 0))) return false; } return true; };   // v65: the ground level also reaches the outer city
    // spiral chains. Approach lanes leave the ramp's start from BEHIND it (the ramp rises away from the start, so the clear side is the one it has not yet climbed)
    const angOf = (x, z, s) => Math.atan2(z - s.z, x - s.x), angD = (a, b) => { let d = a - b; d -= TAU * Math.floor((d + Math.PI) / TAU); return Math.abs(d); };
    for (const s of spirals) {
        const aS = s.th0 - s.dir * 0.14, aE = s.thE;
        const wayX = s.x + Math.cos(aS) * 108, wayZ = s.z + Math.sin(aS) * 108;
        const lowN = nearestNode(wayX, wayZ, s.yLo, 420, (n) => n.lv === s.k && Math.hypot(n.x - s.x, n.z - s.z) > 112 && angD(angOf(n.x, n.z, s), aS) < 1.1 && segOK(s.k, wayX, wayZ, n.x, n.z));
        const upN = nearestNode(s.top.x, s.top.z, s.yUp, 420, (n) => n.lv === s.k + 1 && Math.hypot(n.x - s.x, n.z - s.z) > 112 && angD(angOf(n.x, n.z, s), aE) < 1.1 && segOK(s.k + 1, s.top.x, s.top.z, n.x, n.z));
        const lane = (lv, x0, z0, x1, z1) => { const n = Math.max(1, Math.ceil(Math.hypot(x1 - x0, z1 - z0) / 14)); for (let q = 0; q <= n; q++) occ[lv].add({ x: lerp(x0, x1, q / n), z: lerp(z0, z1, q / n), r: 20 }, 20); ribbon([[x0, z0], [x1, z1]], 18, levelY(lay[lv]), paveCol[lv % paveCol.length]); };
        const mine = spNodes.filter(q => q.s === s).sort((a, b) => a.t - b.t);
        let prev = -1;
        if (lowN >= 0) { const w = addNode(wayX, wayZ, s.yLo + 0.3, 5, s.k); addEdge(lowN, w, 24, 1); lane(s.k, wayX, wayZ, nodes[lowN].x, nodes[lowN].z); lane(s.k, s.bot[0], s.bot[2], wayX, wayZ); prev = addNode(s.bot[0], s.bot[2], s.yLo + 0.3, 5, s.k); addEdge(w, prev, 24, 1); }
        for (const q of mine) { const id = addNode(q.x, q.z, q.y + 0.3, 5, s.k); if (prev >= 0) addEdge(prev, id, 24, 1); prev = id; }
        { const ca = Math.cos(s.thE), sa = Math.sin(s.thE); for (const rr of [SP_RHO, SP_HOLE + 6]) { const id = addNode(s.x + ca * rr, s.z + sa * rr, s.yUp + 0.3, 5, s.k + 1); if (prev >= 0) addEdge(prev, id, 24, 1); prev = id; } }
        const lid = addNode(s.top.x, s.top.z, s.yUp + 0.3, 5, s.k + 1); if (prev >= 0) addEdge(prev, lid, 24, 1); if (upN >= 0) { addEdge(lid, upN, 24, 1); lane(s.k + 1, s.top.x, s.top.z, nodes[upN].x, nodes[upN].z); }
        s.nodeTop = lid;
    }
    // promenade + tunnel + road chain: from the Skyterrace ring out to the end of the road
    { const L3 = lay[3]; let prev = nearestNode(tx * (L3.rings[L3.rings.length - 1] || 1500), tz * (L3.rings[L3.rings.length - 1] || 1500), L3.y, 400, (n) => n.lv === 3);
      const s0 = L3.rings[L3.rings.length - 1] || 1500; const pts = [];
      for (let s = s0 + 40; s < sIn + 30; s += 70) pts.push(posAt(s, 0, L3.y + 0.3)); for (const p of pts) { const id = addNode(p[0], p[2], p[1], 2, 3); if (prev >= 0) addEdge(prev, id, 24, 2); prev = id; }
      const tun = []; for (let s = sIn + 30; s < C.sEnd + 40; s += 80) tun.push(posAt(Math.min(s, C.sEnd + 20), 0, s > C.sEnd ? ground(axisPt(Math.min(s, C.sEnd + 20), 0)[0], axisPt(Math.min(s, C.sEnd + 20), 0)[1]) + 0.5 : citProfile(C, s) + 0.5)); for (const p of tun) { const id = addNode(p[0], p[2], p[1], 2, 3); addEdge(prev, id, 26, 2); prev = id; }
      city.gateNode = prev; city.poi.docks.push({ x: nodes[prev].x, z: nodes[prev].z, y: nodes[prev].y });
      ribbon(pts.map(p => [p[0], p[2]]).concat([axisPt(sIn + 12, 0)]), 2 * promW - 14, () => L3.y + 0.2, paveCol[3]); }
    // connect any stray component to the main one (nearest pair)
    for (let pass = 0; pass < 20; pass++) {
        const comp = new Int32Array(nodes.length).fill(-1); let nc = 0; for (let i = 0; i < nodes.length; i++) if (comp[i] < 0) { const q = [i]; comp[i] = nc; while (q.length) { const a = q.pop(); for (const b of nodes[a].adj) if (comp[b] < 0) { comp[b] = nc; q.push(b); } } nc++; }
        if (nc === 1) break; let did = false;
        for (let c = 0; c < nc; c++) { if (c === comp[0]) continue; let bd = 1e18, ba = -1, bb = -1; for (const n of nodes) { if (comp[n.id] !== c) continue; for (const m of nodes) { if (comp[m.id] === c || m.lv !== n.lv || Math.abs(m.y - n.y) > (n.lv === 0 ? 140 : 4)) continue; const d = (n.x - m.x) ** 2 + (n.z - m.z) ** 2; if (d < bd && segOK(n.lv, n.x, n.z, m.x, m.z)) { bd = d; ba = n.id; bb = m.id; } } } if (ba >= 0 && bd < 520 * 520) { addEdge(ba, bb, 12, 1); did = true; } }
        if (!did) break;
    }
    city.edgeStyles = ['citadel'];

    // ---------- BUILDINGS: organic, sleek. Lots along the ring streets of every level ----------
    const FH = CIT.FH;
    const accents = [TEAL, AQUA, LEAF, TEAL, AQUA, GOLD, VIOLET], crowns = [LEAF, TEAL, PEARL[0], AQUA, hexLin(0x6fd6a0)];
    const freeAt = (L, x, z, r) => { for (const o of occ[L.i].near(x, z, r + 60)) if (Math.hypot(o.x - x, o.z - z) < r + o.r + 2.5) return false; return true; };
    const spiralNear = (x, z, pad) => { for (const s of spirals) if (Math.hypot(s.x - x, s.z - z) < SP_HOLE + pad) return true; return false; };
    const onSpoke = (L, x, z, pad) => { const r = Math.hypot(x, z), ph = Math.atan2(z, x); for (let k = 0; k < L.K; k++) { let d = ph - L.spokeAng(k, r); d -= TAU * Math.floor((d + Math.PI) / TAU); if (r * Math.abs(d) < 8 + pad) return true; } return false; };
    const onRing = (L, x, z, pad) => { const r = Math.hypot(x, z); for (const rr of L.rings) if (Math.abs(r - rr) < 9 + pad) return true; return false; };
    const onStrip = (x, z, pad) => (x * tx + z * tz) > 1280 && Math.abs(x * px + z * pz) < promW + pad;
    const nearPylon = (L, x, z, pad) => { for (const p of pylons) if ((p.base === L.i) && Math.hypot(p.x - x, p.z - z) < p.r + pad) return true; return false; };
    const clearAbove = (L, x, z) => { let c = 1e9; for (const U of lay) if (U.i > L.i && inLayer(U, x, z, -2)) c = Math.min(c, U.y - CIT.DECK - L.y - 10); for (const U of lay) if (U.i > L.i) for (const h of U.holes) if (Math.hypot(h.x - x, h.z - z) < h.r + 40) c = Math.min(c, 60); return c; };
    const baseY = (L, x, z, w, d, yaw) => { if (L.i > 0) return L.y; const c = Math.cos(yaw), s = Math.sin(yaw); let hi = -1e9, lo = 1e9; for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) { const gx = (i - 1) * w / 2, gz = (j - 1) * d / 2, g = ground(x + gx * c - gz * s, z + gx * s + gz * c); hi = Math.max(hi, g); lo = Math.min(lo, g); } return [hi, lo]; };
    let nB = 0, nTower = 0;
    const doorFor = (x, z, yaw, w, d, face) => { const a = face; return [x + Math.cos(a) * (Math.max(w, d) / 2 + 2.5), z + Math.sin(a) * (Math.max(w, d) / 2 + 2.5)]; };
    const bld = (L, kind, x, z, yaw, w, d, fl, face) => {
        const bY = baseY(L, x, z, w, d, yaw); let y = L.y; if (L.i === 0) { y = bY[0] + 0.4; P('orgCyl', x, bY[1] - 14, z, yaw, Math.min(w, d) * 0.98 + 2, y - bY[1] + 14, Math.min(w, d) * 0.98 + 2, jit(DECKC[0], 0.1)); }
        const body = jit(PEARL[(nB + (rnd() * 6 | 0)) % PEARL.length], 0.05), acc = pick(accents), crown = pick(crowns), cy = Math.cos(yaw), sy = Math.sin(yaw);
        let H = 0, a = w / 2, b = d / 2, ex = 1;
        if (kind === 'pod') {
            const r = Math.min(w, d) / 2 * 0.9; H = fl * FH;
            P('orgCyl', x, y, z, 0, 2 * r + 2, 4, 2 * r + 2, jit(GOLD, 0.1)); frustum(x, y + 4, z, 0, r, r * 0.84, H - 4, body);
            for (let q = 2; q * FH < H - 8; q += 2) { const rr = lerp(r, r * 0.84, (q * FH - 4) / (H - 4)); P('glowCyl', x, y + q * FH, z, 0, 2 * rr + 1, 1.1, 2 * rr + 1, acc); }
            P('orgDome', x, y + H, z, 0, 1.68 * r, r * 0.8, 1.68 * r, crown); P('glowCyl', x, y + H + r * 0.8, z, 0, 1.6, 8, 1.6, acc);
            a = b = r * 0.78;
        } else if (kind === 'tower') {
            a = w / 2 * 0.9; b = d / 2 * 0.9; ex = a / b; const seg = 3.5 * FH, N = Math.max(2, Math.ceil(fl / 3.5)); let yy = y, sc = 1, tw = yaw; H = 0;
            P('orgCyl', x, y, z, yaw, 2 * a + 2, 5, 2 * b + 2, jit(GOLD, 0.1)); yy += 5;
            for (let i = 0; i < N; i++) { const sn = 1 - 0.34 * Math.pow((i + 1) / N, 1.25), h = seg; frustum(x, yy, z, tw, b * sc, b * sn, h, jit(body, 0.03), ex); P('glowCyl', x, yy + h, z, tw, 2 * b * sn * ex + 1, 1.3, 2 * b * sn + 1, i & 1 ? acc : TEAL); yy += h; sc = sn; tw += 0.1; }
            P('orgCone', x, yy, z, tw, 2 * b * sc * 0.8 * ex, Math.max(40, fl * FH * 0.16), 2 * b * sc * 0.8, crown); P('glowCyl', x, yy + Math.max(40, fl * FH * 0.16), z, 0, 2.4, 16, 2.4, acc); H = yy - y + 40;
            city.poi.towers.push({ x, z, y: yy, h: H }); nTower++;
        } else if (kind === 'terraced') {
            const nT = clamp(Math.round(fl / 2), 2, 5), tH = 2 * FH; let k = 0.97, ox = 0, oz = 0; H = 0;
            for (let t = 0; t < nT; t++) { const ta = a * k, tb = b * k, yy = y + t * tH, [cx, cz] = [x + ox * cy - oz * sy, z + ox * sy + oz * cy]; P('orgCyl', cx, yy, cz, yaw, 2 * ta, tH, 2 * tb, jit(body, 0.04)); P('orgCyl', cx, yy + tH, cz, yaw, 2 * ta - 2, 0.9, 2 * tb - 2, jit(LEAF, 0.3)); P('glowCyl', cx, yy + tH * 0.5, cz, yaw, 2 * ta + 0.8, 0.9, 2 * tb + 0.8, t & 1 ? acc : TEAL);
                if (t < nT - 1) for (let q = 0; q < 2; q++) { const tr = R(-0.5, 0.5); P('orgDome', cx + cy * ta * tr, yy + tH + 0.9, cz + sy * ta * tr + (q ? 1 : -1) * tb * 0.4 * cy, 0, 9, 8, 9, jit(pick([LEAF, LIME, hexLin(0x2f9e6a)]), 0.2)); }
                ox += R(-0.12, 0.12) * w; oz += R(-0.12, 0.12) * d; k *= R(0.76, 0.86); }
            H = nT * tH; P('orgDome', x + ox * cy - oz * sy, y + H + 0.9, z + ox * sy + oz * cy, 0, 2 * a * k * 0.9, 9, 2 * b * k * 0.9, jit(LEAF, 0.2)); a *= 0.9; b *= 0.9;
        } else if (kind === 'hall') {
            H = FH * R(2.2, 3.2); P('orgCyl', x, y, z, yaw, w * 0.98, 3, d * 0.98, jit(GOLD, 0.1)); P('orgDome', x, y + 3, z, yaw, w * 0.94, H, d * 0.94, body); P('glowCyl', x, y + 3, z, yaw, w * 0.95, 0.9, d * 0.95, acc); P('orgDome', x, y + 3 + H * 0.5, z, yaw, w * 0.34, H * 0.7, d * 0.34, crown);
            a = w / 2 * 0.74; b = d / 2 * 0.74;
        } else if (kind === 'canopy') {
            const hc = R(20, 30); H = hc + 7; for (let q = 0; q < 5; q++) { const an = q / 5 * TAU + yaw, cx = x + Math.cos(an) * w * 0.36, cz = z + Math.sin(an) * d * 0.36; P('orgCyl', cx, y, cz, 0, 3.2, hc, 3.2, jit(PEARL[0], 0.05)); }
            P('orgDome', x, y + hc, z, yaw, w, 8, d, pick([LEAF, PEARL[3], crown])); P('glowCyl', x, y + hc - 0.6, z, yaw, w * 0.86, 0.7, d * 0.86, acc); P('orgCyl', x, y, z, yaw, w * 0.5, 0.8, d * 0.5, jit(LEAF, 0.2)); a = b = 0;
        } else {   // conservatory
            H = FH * R(2.2, 3.4); P('orgCyl', x, y, z, yaw, w * 0.98, 3.2, d * 0.98, jit(GOLD, 0.1)); P('glassDome', x, y + 3.2, z, yaw, w * 0.92, H, d * 0.92, hexLin(0xa8f0d8));
            for (let q = 0; q < 5; q++) { const tr = R(-0.35, 0.35), tq = R(-0.35, 0.35); P('orgDome', x + (cy * tr * w - sy * tq * d), y + 3.2, z + (sy * tr * w + cy * tq * d), 0, R(8, 14), R(8, 16), R(8, 14), jit(pick([LEAF, LIME, TEAL]), 0.2)); }
            for (let m = 0; m < 6; m++) { const an = m / 6 * Math.PI + yaw; beam('glow', x + Math.cos(an) * w * 0.46, y + 3.2, z + Math.sin(an) * d * 0.46, x, y + 3.2 + H, z, 0.7, 0.7, TEAL); }
            a = w / 2 * 0.7; b = d / 2 * 0.7;
        }
        if (a > 0) addCol(x, z, yaw, a * 0.76, b * 0.76, y - 2, y + H, y + H, 0);
        const door = doorFor(x, z, yaw, w, d, face); P('glow', door[0] - Math.cos(face) * 2, y + 0.3, door[1] - Math.sin(face) * 2, face, 0.8, 7, 5, WARM);
        const poi = { x, z, y: y + 0.5, yaw, door, bi: nB };
        if (kind === 'tower') { city.poi.works.push({ ...poi, kind: 'office' }); if (rnd() < 0.5) city.poi.homes.push(poi); }
        else if (kind === 'conservatory') city.poi.works.push({ ...poi, kind: 'workshop' });
        else if (kind === 'hall' || kind === 'canopy') city.poi.shops.push(poi);
        else { city.poi.homes.push(poi); if (rnd() < 0.15) city.poi.shops.push(poi); }
        city.buildings.push({ x, z, yaw, w, d, floors: Math.round(H / FH), kind, lvl: L.i, top: y + H }); nB++;
        occ[L.i].add({ x, z, r: Math.hypot(w, d) / 2 * 0.9 }, Math.hypot(w, d) / 2);
        return H;
    };
    const KW = [
        [['pod', .3], ['terraced', .22], ['hall', .14], ['canopy', .16], ['conservatory', .08], ['tower', .1]],
        [['pod', .3], ['hall', .22], ['terraced', .2], ['conservatory', .15], ['tower', .13]],
        [['tower', .28], ['pod', .24], ['terraced', .16], ['hall', .16], ['conservatory', .16]],
        [['hall', .24], ['canopy', .26], ['conservatory', .2], ['pod', .2], ['terraced', .1]],
        [['terraced', .34], ['conservatory', .26], ['pod', .2], ['hall', .2]],
        [['tower', .45], ['pod', .22], ['hall', .15], ['conservatory', .18]],
    ];
    const SKIP = [0.42, 0.3, 0.3, 0.52, 0.3, 0.2];
    const pickKind = (li) => { let t = rnd(), acc2 = 0; for (const [k, w] of KW[li]) { acc2 += w; if (t < acc2) return k; } return KW[li][0][0]; };
    // ---------- PYLONS: flared organic columns carrying every deck ----------
    for (const L of decks) {
        for (let r = L.rIn + 120, j = 0; r < L.R * 0.94; r += R(250, 300), j++) {
            const nA = Math.max(5, Math.round(TAU * r / R(270, 330))), a0 = R(0, TAU);
            for (let k = 0; k < nA; k++) {
                const a = a0 + (k + R(-0.2, 0.2)) / nA * TAU, x = Math.cos(a) * r, z = Math.sin(a) * r;
                if (!inLayer(L, x, z, 24) || L.holes.some(h => Math.hypot(h.x - x, h.z - z) < h.r + 46) || spirals.some(s => Math.hypot(s.x - x, s.z - z) < 150)) continue;
                const yb = topAt(x, z, L.y), H = L.y - CIT.DECK - yb; if (H < 30) continue;
                const bl0 = lay.find(q => q.i > 0 && Math.abs(q.y - yb) < 0.5), LB = bl0 || lay[0], rP = clamp(16 + H * 0.03, 18, 30);
                if (onRing(LB, x, z, rP + 3) || onSpoke(LB, x, z, rP + 3) || !freeAt(LB, x, z, rP) || (LB.i === 0 && nearGStreet(x, z, rP + 3, true))) continue;
                const r0 = clamp(16 + H * 0.03, 18, 30), rs = r0 * 0.58, c1 = jit(PEARL[(k + j) % PEARL.length], 0.06);
                const hb = Math.min(H * 0.34, 80), ht = Math.min(H * 0.26, 56);
                frustum(x, yb - 2, z, 0, r0, rs, hb + 2, c1); P('orgCyl', x, yb + hb, z, 0, rs * 2, H - hb - ht, rs * 2, c1); frustum(x, L.y - CIT.DECK - ht, z, 0, rs, rs * 1.75, ht, c1);
                P('glowCyl', x, L.y - CIT.DECK - ht - 1, z, 0, rs * 2 + 1.5, 1.6, rs * 2 + 1.5, (k + j) & 1 ? TEAL : AQUA);
                solidCyl(x, z, r0, yb - 2, L.y - CIT.DECK); { const bl = lay.find(q => q.i > 0 && Math.abs(q.y - yb) < 0.5); pylons.push({ x, z, L: L.i, base: bl ? bl.i : 0, r: r0 }); occ[bl ? bl.i : 0].add({ x, z, r: r0 + 4 }, r0 + 4); }
            }
        }
    }
    // plazas are reserved BEFORE the lots so nothing grows on them
    const plazaSpots = [];
    { const gp = axisPt(1750, 0); plazaSpots.push({ L: lay[3], x: gp[0], z: gp[1], r: 124, name: 'gate' }); occ[3].add({ x: gp[0], z: gp[1], r: 134 }, 134);
      for (const L of [lay[1], lay[2], lay[3], lay[3], lay[3], lay[4], lay[5]]) for (let tr = 0; tr < 200; tr++) {
          const a = R(0, TAU), r = R(L.rIn + 120, L.R * 0.8), x = Math.cos(a) * r, z = Math.sin(a) * r, pr = L.i === 5 ? 60 : L.i === 3 ? R(70, 100) : R(52, 74);
          if (!inLayer(L, x, z, pr + 24) || onStrip(x, z, pr + 20) || spiralNear(x, z, pr + 40) || plazaSpots.some(q => Math.hypot(q.x - x, q.z - z) < q.r + pr + 120) || nearPylon(L, x, z, pr + 12) || !freeAt(L, x, z, pr)) continue;
          plazaSpots.push({ L, x, z, r: pr, name: 'plaza' }); occ[L.i].add({ x, z, r: pr + 6 }, pr + 6); break;
      } }
    for (const L of lay) {
        for (let j = 0; j < L.rings.length; j++) for (const side of [-1, 1]) {
            const rr = L.rings[j]; let phi = R(0, TAU), end = phi + TAU;
            while (phi < end) {
                const w = R(34, 70), d = R(30, 54), rc = rr + side * (8 + d / 2 + 3), step = (w + R(4, 20)) / rc, pc = phi + (w / 2) / rc; phi += step;
                if (rnd() < SKIP[L.i]) continue;
                const x = Math.cos(pc) * rc, z = Math.sin(pc) * rc, yaw = pc + Math.PI / 2, mr = Math.hypot(w, d) / 2 * 0.92;
                if (!inLayer(L, x, z, mr + 8) || onStrip(x, z, mr + 10) || spiralNear(x, z, mr + 36) || onSpoke(L, x, z, mr) || nearPylon(L, x, z, mr + 12) || !freeAt(L, x, z, mr) || (L.i === 0 && nearGStreet(x, z, mr + 4, true))) continue;
                if (L.i === 0 && Math.hypot(x, z) < 262) continue;
                const clear = clearAbove(L, x, z); if (clear < 46) continue;
                let kind = pickKind(L.i), fl;
                if (kind === 'tower') { if (clear > 1e8) fl = Math.round(R(10, 34)); else fl = Math.floor(clear / FH) - 1; }
                else if (kind === 'pod') fl = Math.round(R(3, L.i === 3 ? 4 : 9)); else if (kind === 'terraced') fl = Math.round(R(4, 9)); else fl = 3;
                const cap = Math.floor((clear > 1e8 ? 99 : clear) / FH) - 1; fl = Math.min(fl, cap);
                if (fl < 2 && kind !== 'canopy' && kind !== 'hall' && kind !== 'conservatory') continue;
                if (kind === 'tower' && fl < 5) kind = 'pod';
                if (kind === 'canopy' && clear < 60) continue;
                if ((kind === 'hall' || kind === 'conservatory') && clear < 66) { if (clear < 50) continue; }
                bld(L, kind, x, z, yaw, w, d, fl, pc + (side > 0 ? Math.PI : 0));
            }
        }
    }
    city.stats.buildingsBuilt = nB;

    // ---------- v65: THE GROUND CITY, part 2 - ordinary city blocks on every bit of ground the citadel itself does not stand on ----------
    // Same blocks as the other cities (stepped wall boxes, gables, flat roofs with clutter, neon, AC boxes, cantilevers) in one of their palettes. They fill the frontage of every
    // ground street (the Roots' and the new ones), then the block interiors. Under a deck they are capped to the clearance; outside the decks they climb to towers.
    {
        const pal = PALETTES[Math.floor(h32(S.seedN, 12, 4, 6) * PALETTES.length)], GC = { walls: pal.walls.map(hexLin), roofs: pal.roofs.map(hexLin), trim: hexLin(pal.trim) };
        const NEONG = [hexLin(0xff4f8b), hexLin(0x35e0ff), hexLin(0xffd23a), hexLin(0x7dff6a), hexLin(0xff8a2a), hexLin(0xb06bff)], GREYG = [hexLin(0x8a8d90), hexLin(0x6a6e72), hexLin(0xa0a2a0)], TARPG = [hexLin(0x2f8fb0), hexLin(0xd9812b), hexLin(0xb8412f), hexLin(0x3a9a6a), hexLin(0xd8c24a)];
        const obbC = (o) => { const c = Math.cos(o.yaw), s = Math.sin(o.yaw), hx = o.w / 2, hz = o.d / 2; return [[-hx, -hz], [hx, -hz], [hx, hz], [-hx, hz]].map(([x, z]) => [o.x + x * c - z * s, o.z + x * s + z * c]); };
        const obbHit = (A, B, pad) => {
            const ax = [[Math.cos(A.yaw), Math.sin(A.yaw)], [-Math.sin(A.yaw), Math.cos(A.yaw)], [Math.cos(B.yaw), Math.sin(B.yaw)], [-Math.sin(B.yaw), Math.cos(B.yaw)]], ca = A._c || (A._c = obbC(A)), cb = B._c || (B._c = obbC(B));
            for (const [nx, nz] of ax) { let a0 = 1e18, a1 = -1e18, b0 = 1e18, b1 = -1e18; for (const p of ca) { const d = p[0] * nx + p[1] * nz; if (d < a0) a0 = d; if (d > a1) a1 = d; } for (const p of cb) { const d = p[0] * nx + p[1] * nz; if (d < b0) b0 = d; if (d > b1) b1 = d; } if (a1 + pad < b0 || b1 + pad < a0) return false; }
            return true;
        };
        const inObbG = (o, x, z, pad) => { const c = Math.cos(o.yaw), s = Math.sin(o.yaw), dx = x - o.x, dz = z - o.z, u = dx * c + dz * s, v = -dx * s + dz * c; return Math.abs(u) <= o.w / 2 + pad && Math.abs(v) <= o.d / 2 + pad; };
        const bg = new Grid(60), MAXG = 9500; let nG = 0, nGt = 0;
        const L0 = lay[0], fhG = () => R(17, 18.4);
        const loc = (b, u, v) => { const c = Math.cos(b.yaw), s = Math.sin(b.yaw); return [b.x + u * c - v * s, b.z + u * s + v * c]; };
        const onStreetG = (b) => { const rr = Math.hypot(b.w, b.d) / 2 + 4; for (const sg of gseg.near(b.x, b.z, rr + 30)) { if (distSeg(b.x, b.z, sg.ax, sg.az, sg.bx, sg.bz) > rr + sg.w / 2) continue; const n = Math.max(1, Math.ceil(sg.L / 3)); for (let k = 0; k <= n; k++) if (inObbG(b, sg.ax + (sg.bx - sg.ax) * k / n, sg.az + (sg.bz - sg.az) * k / n, sg.w / 2 + 0.3)) return true; } return false; };
        const lowHigh = (b) => { const c = Math.cos(b.yaw), s = Math.sin(b.yaw), hw = b.w / 2 + 0.6, hd = b.d / 2 + 0.6; let lo = 1e18, hi = -1e18; for (let i = 0; i < 5; i++) for (let j = 0; j < 5; j++) { const u = (i / 2 - 1) * hw, v = (j / 2 - 1) * hd, y = ground(b.x + u * c - v * s, b.z + u * s + v * c); if (y < lo) lo = y; if (y > hi) hi = y; } return [lo, hi]; };
        const accept = (b) => {
            if (nG >= MAXG) return false;
            const mr = Math.hypot(b.w, b.d) / 2, r = Math.hypot(b.x, b.z); if (r > cityEdge(b.x, b.z) - 20 || r < 285 || onCorr(b.x, b.z, mr + 6) || spiralNear(b.x, b.z, mr + 30)) return false;
            const out = r / cityEdge(b.x, b.z); if (out > 0.94 && rnd() < clamp((out - 0.94) * 9, 0, 0.9)) return false;      // thin out toward the meadow's edge
            for (const o of bg.near(b.x, b.z, mr + 4)) if (obbHit(b, o, 0.35)) return false;
            if (!freeAt(L0, b.x, b.z, mr * 0.78) || onStreetG(b)) return false;
            const clear = clearAbove(L0, b.x, b.z), cap = clear > 1e8 ? 99 : Math.floor((clear - 28) / b.fh);
            if (cap < 2) return false;
            const [lo, hi] = lowHigh(b); if (hi - lo > 12 + 0.5 * Math.min(b.w, b.d)) return false; b.yLo = lo; b.yHi = hi; b.y0 = lo + (hi - lo) * 0.5 + 0.3;
            b.floors = Math.min(b.floors, cap); if (out > 0.94) b.floors = Math.min(b.floors, Math.max(1, Math.round(lerp(5, 1, clamp((out - 0.94) / 0.06, 0, 1)))));
            if (b.kind === 'tower' && b.floors < 12) b.kind = 'house'; b._c = null; b.top = b.y0 + b.floors * b.fh; b.lvl = 0;
            bg.add(b, mr + 2); occ[0].add({ x: b.x, z: b.z, r: mr * 0.9 }, mr * 0.9); city.buildings.push(b); nG++; return true;
        };
        const makeG = (x, z, yaw, w, d, side) => {
            const r = Math.hypot(x, z), dd = clamp((r - 300) / 2400, 0, 1);
            let kind = 'house', floors = Math.max(2, Math.round(lerp(3, 10, Math.pow(dd, 0.8)) * R(0.65, 1.3)));
            const t = rnd();
            if (r > 1750 && t < 0.07) { kind = 'tower'; floors = Math.round(R(14, 28)); w *= 1.1; d *= 1.1; }
            else if (t < 0.2) { kind = 'workshop'; floors = 2 + Math.floor(rnd() * 3); w *= 1.12; }
            else if (t < 0.34) { kind = 'shop'; floors = Math.max(3, Math.round(floors * R(0.9, 1.3))); }
            return { x, z, yaw, w, d, floors, fh: fhG(), kind, side, ci: Math.floor(rnd() * 6) };
        };
        // frontage: both sides of every ground street
        for (const ch of G0) {
            const pts = ch.pts, cum = [0]; for (let i = 1; i < pts.length; i++) cum.push(cum[i - 1] + Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1])); const total = cum[cum.length - 1]; if (total < 20) continue;
            const at = (t) => { let i = 1; while (i < cum.length - 1 && cum[i] < t) i++; const a = pts[i - 1], b = pts[i], seg = cum[i] - cum[i - 1] || 1, f = clamp((t - cum[i - 1]) / seg, 0, 1), dx = (b[0] - a[0]) / seg, dz = (b[1] - a[1]) / seg; return [a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, dx, dz]; };
            for (const side of [1, -1]) {
                let t = rnd() * 10;
                while (t < total) {
                    const w = R(24, 52), d = R(30, 58), tc = t + w / 2; t += w + R(0.2, 1.0); if (tc > total) break;
                    const [qx, qz, dx, dz] = at(tc), nx = -dz, nz = dx, yaw = Math.atan2(dz, dx), off = ch.w / 2 + d / 2 + R(0.5, 1.5);
                    if (!accept(makeG(qx + nx * side * off, qz + nz * side * off, yaw, w, d, side))) { const w2 = w * 0.78, d2 = d * 0.62, off2 = ch.w / 2 + d2 / 2 + 0.8; accept(makeG(qx + nx * side * off2, qz + nz * side * off2, yaw, w2, d2, side)); }
                }
            }
        }
       
        // interior fill: random lots between streets, only where a street is near enough to reach the door
        const nearestSegG = (x, z) => { let best = null, bd = 1e18; for (const sg of gseg.near(x, z, 90)) { const dd = distSeg(x, z, sg.ax, sg.az, sg.bx, sg.bz); if (dd < bd) { bd = dd; best = sg; } } return best ? { sg: best, d: bd } : null; };
        for (let tries = 0; tries < 40000 && nG < MAXG; tries++) {
            const a = R(0, TAU), rr = rMaxG0() * Math.sqrt(rnd()), x = Math.cos(a) * rr, z = Math.sin(a) * rr, w = R(20, 44), d = R(20, 44);
            if (!groundCityOK(x, z, 20)) continue;
            const ns = nearestSegG(x, z); if (!ns || ns.d > 130 || ns.d < ns.sg.w / 2 + Math.max(w, d) * 0.5 + 0.5) continue;
            accept(makeG(x, z, ns.sg.yaw + R(-0.1, 0.1), w, d, 1));
        }
        function rMaxG0() { return Math.max(...C.rvT); }
       
        // ---- building -> pieces ----
        const trimC = GC.trim;
        for (let bi = 0; bi < city.buildings.length; bi++) {
            const b = city.buildings[bi]; if (b.lvl !== 0 || b.side === undefined || b.y0 === undefined) continue;
            const y0 = b.y0, H = b.floors * b.fh, wall = jit(GC.walls[b.ci % GC.walls.length], 0.16), roof = jit(GC.roofs[(b.ci + bi) % GC.roofs.length], 0.12), sk = 9 + Math.min(14, (b.yHi - b.yLo) * 0.45);
            const dir = b.side; const door = loc(b, 0, -dir * (b.d / 2 + 2.5));
            P('baseBox', b.x, b.yLo - sk, b.z, b.yaw, b.w + 0.8, y0 - b.yLo + sk + 0.6, b.d + 0.8, jit(trimC, 0.2));
            const nT = b.floors >= 20 ? 3 : b.floors >= 9 ? 2 : 1, tiers = []; let rem = b.floors, yy = y0, ku = 1, kv = 1, ou = 0, ov = 0;
            for (let t = 0; t < nT; t++) {
                const last = t === nT - 1, n = last ? rem : Math.max(3, Math.round(rem * R(0.45, 0.65))), [cx, cz] = loc(b, ou, ov), T = { cx, cz, w: b.w * ku, d: b.d * kv, y: yy, h: n * b.fh };
                P('wallBox', cx, yy, cz, b.yaw, T.w, T.h, T.d, t === 0 ? wall : jit(GC.walls[(b.ci + t) % GC.walls.length], 0.14)); tiers.push(T); yy += T.h; rem -= n;
                const k1 = R(0.8, 0.93), k2 = R(0.8, 0.95); ou += R(-1, 1) * (1 - k1) * b.w * 0.5; ov += R(-1, 1) * (1 - k2) * b.d * 0.5; ku *= k1; kv *= k2;
            }
            const T0 = tiers[0], TT = tiers[tiers.length - 1], yTop = yy, room = (() => { const c = clearAbove(L0, b.x, b.z); return c > 1e8 ? 1e9 : c - 14 - H; })();
            // facade dressing on the street side: storefront glow, neon, AC boxes
            const c0 = Math.cos(b.yaw), s0 = Math.sin(b.yaw), fx = -s0 * -dir * (b.w * 0), fz = 0; void fx; void fz;
            const faceP = (along, y, out, sx, sy, sz, cat, color) => { const p = loc(b, along * T0.w * 0.5 * 0.9, -dir * (T0.d / 2 + out / 2 - 0.2)); P(cat, p[0], y, p[1], b.yaw, sx, sy, out > 0 ? sz : sz, color); };
            if (b.kind === 'shop' || rnd() < 0.3) faceP(0, y0 + 2.2, 0.5, T0.w * 0.8, 4.4, 0.5, 'glow', jit(hexLin(0xffd9a0), 0.3));
            if (rnd() < 0.5) faceP(rnd() < 0.5 ? -0.8 : 0.8, y0 + R(7, Math.max(8, Math.min(T0.h - 8, 30))), 1.3, 0.8, R(5, 11), 1.3, 'glow', pick(NEONG));
            for (let k = Math.min(4, Math.floor(b.floors * 0.5)); k > 0; k--) faceP(R(-0.9, 0.9), y0 + b.fh * (1 + Math.floor(rnd() * Math.max(1, T0.h / b.fh - 1))) + 1.5, 1.9, 2.6, 1.8, 1.9, 'plainBox', jit(pick(GREYG), 0.15));
            if (b.kind === 'tower') {
                P('plainBox', TT.cx, yTop, TT.cz, b.yaw, TT.w + 1, 1.4, TT.d + 1, trimC); const hh = Math.min(R(14, 30), Math.max(0, room - 4)); if (hh > 6) { P('plainCyl', TT.cx, yTop + 1.4, TT.cz, 0, 0.6, hh, 0.6, trimC); P('glow', TT.cx, yTop + 1.4 + hh, TT.cz, 0, 1.1, 1.1, 1.1, hexLin(0xff3a2a)); }
                P('glow', T0.cx, y0 + T0.h * 0.5, T0.cz, b.yaw, T0.w + 0.5, 0.9, T0.d + 0.5, jit(pick(NEONG), 0.2)); city.poi.towers.push({ x: b.x, z: b.z, y: yTop, h: H }); city.poi.works.push({ x: b.x, z: b.z, y: y0, yaw: b.yaw, kind: 'office', door, bi }); nGt++;
            } else if (b.kind === 'workshop') {
                P('gable', T0.cx, yTop, T0.cz, b.yaw, T0.w + 1, Math.min(b.fh * 1.6, Math.max(6, room)), T0.d + 1, roof);
                P('glow', T0.cx, y0 + 3.5, T0.cz, b.yaw, T0.w + 0.5, 0.8, T0.d + 0.5, [1.0, 0.45, 0.12]); city.poi.works.push({ x: b.x, z: b.z, y: y0, yaw: b.yaw, kind: 'workshop', door, bi });
            } else {
                const gab = b.floors <= 6 && rnd() < 0.5 && room > b.fh * 1.8;
                if (gab) { if (TT.w >= TT.d) P('gable', TT.cx, yTop, TT.cz, b.yaw, TT.w + 1, b.fh * R(0.9, 1.6), TT.d + 1, roof); else P('gable', TT.cx, yTop, TT.cz, b.yaw + Math.PI / 2, TT.d + 1, b.fh * R(0.9, 1.6), TT.w + 1, roof); }
                else { P('plainBox', TT.cx, yTop, TT.cz, b.yaw, TT.w + 0.8, 1.2, TT.d + 0.8, roof);
                    if (room > 24 && rnd() < 0.5) { const u = R(-1, 1) * (TT.w / 2 - 3), v = R(-1, 1) * (TT.d / 2 - 3), p = loc({ x: TT.cx, z: TT.cz, yaw: b.yaw }, u, v), sw = R(5, 8), sd = R(4, 6); P('plainBox', p[0], yTop + 1.2, p[1], b.yaw + R(-0.2, 0.2), sw, 3.4, sd, jit(pick(TARPG), 0.3)); }
                    if (room > 40 && rnd() < 0.35) { const u = R(-1, 1) * (TT.w / 2 - 3), v = R(-1, 1) * (TT.d / 2 - 3), p = loc({ x: TT.cx, z: TT.cz, yaw: b.yaw }, u, v), hh = R(8, 18); P('plainCyl', p[0], yTop + 1.2, p[1], 0, 0.55, hh, 0.55, trimC); } }
                if (rnd() < 0.3) P('glow', door[0], y0 + 6.5, door[1], 0, 1.4, 1.4, 1.4, [1, 0.8, 0.5]);
                if (b.kind === 'shop') city.poi.shops.push({ x: b.x, z: b.z, y: y0, yaw: b.yaw, door, bi }); else { city.poi.homes.push({ x: b.x, z: b.z, y: y0, yaw: b.yaw, door, bi }); }
            }
            P('glow', door[0], y0 + 0.3, door[1], b.yaw, 0.8, 6, 4.4, WARM);
        }
        city.stats.groundBuildings = nG; city.stats.groundTowers = nGt;
    }

    // ---------- PLAZAS, LAWNS, PONDS, GROVES ----------
    const tree = (x, y, z, sz, big) => {
        const trunkC = hexLin(0x6a5a48), can = pick([LEAF, LIME, hexLin(0x2f9e6a), TEAL, hexLin(0x6fd6a0)]);
        P('plainCyl', x, y, z, 0, Math.max(1, sz * 0.1), sz * 0.7, Math.max(1, sz * 0.1), trunkC); P('orgDome', x, y + sz * 0.5, z, 0, sz, sz * 0.9, sz, jit(can, 0.25));
        if (big || rnd() < 0.18) { P('orgDome', x + R(-0.25, 0.25) * sz, y + sz * 0.9, z + R(-0.25, 0.25) * sz, 0, sz * 0.55, sz * 0.5, sz * 0.55, jit(pick([LIME, TEAL, AQUA]), 0.2)); P('glow', x + R(-0.3, 0.3) * sz, y + sz * 0.6, z + R(-0.3, 0.3) * sz, 0, 1.4, 1.4, 1.4, pick([TEAL, AQUA, GOLD, VIOLET])); }
    };
    for (const pz2 of plazaSpots) {
        const { L, x, z, r } = pz2, y = L.y; P('orgCyl', x, y, z, 0, 2 * r, 0.9, 2 * r, jit(PEARL[3], 0.04)); P('glowCyl', x, y + 0.9, z, 0, 2 * r * 0.96, 0.3, 2 * r * 0.96, TEAL); P('orgCyl', x, y + 0.9, z, 0, 2 * r * 0.86, 0.35, 2 * r * 0.86, jit(PEARL[0], 0.03));
        P('orgCyl', x, y, z, 0, 26, 4, 26, PEARL[1]); P('glowCyl', x, y + 3.6, z, 0, 22, 1.2, 22, AQUA); P('glowCyl', x, y + 4.5, z, 0, 2.6, 24, 2.6, [0.75, 0.95, 1]); P('orgDome', x, y + 20, z, 0, 8, 7, 8, [0.8, 0.98, 1]);
        for (let q = 0; q < 8; q++) { const an = q / 8 * TAU + 0.2, rr = r * 0.72, px2 = x + Math.cos(an) * rr, pz3 = z + Math.sin(an) * rr; P('orgCyl', px2, y + 0.9, pz3, 0, 7, 2.2, 7, PEARL[2]); tree(px2, y + 3, pz3, R(9, 13), false); }
        city.poi.plazas.push({ x, z, y: y + 0.5, r, kind: pz2.name }); city.poi.views.push({ x: x + r * 0.5, z, y: y + 0.9, kind: 'plaza' });
        occ[L.i].add({ x, z, r: r + 6 }, r + 6);
    }
    { const gi = city.poi.plazas.findIndex(q => q.kind === 'gate'); if (gi > 0) { const g = city.poi.plazas.splice(gi, 1)[0]; city.poi.plazas.unshift(g); } }
    let nTree = 0, nLawn = 0, nPond = 0;
    for (const L of lay) {
        const area = Math.PI * (L.R * L.R - L.rIn * L.rIn), nLawnT = Math.round(area / (L.i === 3 ? 26000 : 70000)), nTreeT = Math.round(area / (L.i === 3 ? 9000 : L.i === 0 ? 14000 : 24000));
        for (let tr = 0, got = 0; tr < nLawnT * 8 && got < nLawnT; tr++) {
            const a = R(0, TAU), r = R(L.rIn + 30, L.R * 0.95), x = Math.cos(a) * r, z = Math.sin(a) * r, rl = R(16, 44);
            if (!inLayer(L, x, z, rl + 6) || onStrip(x, z, rl + 4) || spiralNear(x, z, rl + 34) || onRing(L, x, z, rl * 0.6) || onSpoke(L, x, z, rl * 0.6) || !freeAt(L, x, z, rl * 0.7) || nearPylon(L, x, z, rl)) continue;
            const clear = clearAbove(L, x, z); if (clear < 26) continue; const y = L.i === 0 ? ground(x, z) + 0.2 : L.y;
            if (L.i > 0 && rnd() < (L.i === 3 ? 0.12 : 0.05)) { P('orgCyl', x, y, z, 0, 2 * rl, 1.2, 2 * rl, PEARL[2]); P('glowCyl', x, y + 1.2, z, 0, 2 * rl - 3, 0.5, 2 * rl - 3, jit(AQUA, 0.15)); nPond++; }
            else { P('orgCyl', x, y, z, R(0, 3), 2 * rl, 0.5, 2 * rl * R(0.7, 1), jit(pick([hexLin(0x58a84a), hexLin(0x6fbf5b), hexLin(0x4f9a52)]), 0.1)); nLawn++; }
            occ[L.i].add({ x, z, r: rl * 0.5 }, rl * 0.5); got++;
        }
        for (let tr = 0, got = 0; tr < nTreeT * 5 && got < nTreeT; tr++) {
            const a = R(0, TAU), r = R(L.rIn + 20, L.R * 0.97), x = Math.cos(a) * r, z = Math.sin(a) * r, sz = R(10, 21);
            if (!inLayer(L, x, z, sz * 0.5 + 6) || onStrip(x, z, 6) || spiralNear(x, z, sz + 30) || onRing(L, x, z, sz * 0.5) || onSpoke(L, x, z, sz * 0.5) || !freeAt(L, x, z, sz * 0.5) || nearPylon(L, x, z, sz)) continue;
            const clear = clearAbove(L, x, z); if (clear < sz * 1.6 + 6) continue;
            tree(x, L.i === 0 ? ground(x, z) - 0.5 : L.y, z, sz, false); occ[L.i].add({ x, z, r: sz * 0.5 }, sz * 0.5); got++; nTree++;
        }
    }
    city.stats.trees = nTree; city.stats.lawns = nLawn; city.stats.ponds = nPond;

    // ---------- THE ENCHANTED VALLEY: bioluminescent groves, crystals, lanterns, waterfalls, crest crystals ----------
    { let nV = 0; const Rv = C.Rv;
      for (let tr = 0; tr < 2600 && nV < 480; tr++) {
          const a = R(0, TAU), e0 = cityEdge(Math.cos(a) * 1000, Math.sin(a) * 1000), r = R(e0 + 12, Math.max(e0 + 260, Rv * 1.12)), x = Math.cos(a) * r, z = Math.sin(a) * r;   // v65: the enchanted groves begin where the ground city ends
          if (Math.abs(x * px + z * pz) < 90 && x * tx + z * tz > 1500) continue;
          const g = ground(x, z), gx = (ground(x + 14, z) - ground(x - 14, z)) / 28, gz = (ground(x, z + 14) - ground(x, z - 14)) / 28; if (Math.hypot(gx, gz) > 0.5) continue;
          const sz = R(16, 38); if (!freeAt(lay[0], x, z, sz * 0.5)) continue; tree(x, g - 1, z, sz, rnd() < 0.5); occ[0].add({ x, z, r: sz * 0.5 }, sz * 0.5); nV++;
      }
      for (let q = 0; q < 28; q++) { const a = R(0, TAU), e0 = cityEdge(Math.cos(a) * 1000, Math.sin(a) * 1000), r = R(e0 + 12, Math.max(e0 + 260, Rv * 1.1)), x = Math.cos(a) * r, z = Math.sin(a) * r, g = ground(x, z), col = pick([AQUA, TEAL, VIOLET, LEAF]); if (Math.abs(x * px + z * pz) < 90 && x * tx + z * tz > 1500) continue;
          for (let m = 0, n = 3 + (rnd() * 3 | 0); m < n; m++) { const hh = R(18, 70), dd = R(5, 13); P('orgCone', x + R(-10, 10), g - 4, z + R(-10, 10), 0, dd, hh + 4, dd, jit(col, 0.2)); P('glowCyl', x, g + hh * 0.2, z, 0, 1.2, 1.2, 1.2, col); } }
      for (let q = 0; q < 160; q++) { const a = R(0, TAU), e0 = cityEdge(Math.cos(a) * 1000, Math.sin(a) * 1000), r = R(e0 + 12, Math.max(e0 + 260, Rv * 1.1)), x = Math.cos(a) * r, z = Math.sin(a) * r; P('glow', x, ground(x, z) + R(30, 190), z, 0, 2.2, 2.2, 2.2, jit(pick([TEAL, AQUA, GOLD, LEAF, VIOLET]), 0.2)); }
      // waterfalls down the inner wall: a ribbon of glow hugging the ground from a high point to the floor, a pool and mist at the foot
      let nWF = 0; for (let tr = 0; tr < 80 && nWF < 6; tr++) {
          const a = R(0, TAU); let da = a - Math.atan2(-C.sa, C.ca); da -= TAU * Math.floor((da + Math.PI) / TAU); if (Math.abs(da) < 0.5) continue;
          let rTop = -1, rBase = -1; for (let r = Rv * 0.8; r < C.Rc; r += 20) { const g = ground(Math.cos(a) * r, Math.sin(a) * r) - F; if (rBase < 0 && g > 40) rBase = r; if (g > 520) { rTop = r; break; } } if (rTop < 0 || rBase < 0) continue; rBase = Math.max(rBase, cityEdge(Math.cos(a) * 1000, Math.sin(a) * 1000) + 70); if (rTop - rBase < 150) continue;
          let prev = null; for (let r = rTop; r >= rBase - 40; r -= 24) { const x = Math.cos(a) * r, z = Math.sin(a) * r, cur = [x, ground(x, z) + 1.4, z]; if (prev) beam('glow', prev[0], prev[1], prev[2], cur[0], cur[1], cur[2], 1.4, 9, [0.72, 0.95, 1]); prev = cur; }
          const fx = Math.cos(a) * (rBase - 50), fz = Math.sin(a) * (rBase - 50), fy = ground(fx, fz); P('glowCyl', fx, fy + 0.4, fz, 0, 80, 0.8, 80, [0.55, 0.9, 1]); P('orgCyl', fx, fy - 0.5, fz, 0, 90, 1.2, 90, PEARL[2]); nWF++; }
      city.stats.valleyTrees = nV; city.stats.waterfalls = nWF;
      let nCr = 0; for (let k = 0; k < 120 && nCr < 36; k++) { const a = k / 120 * TAU + R(-0.02, 0.02); let da = a - Math.atan2(-C.sa, C.ca); da -= TAU * Math.floor((da + Math.PI) / TAU); if (Math.abs(da) < 0.45) continue;
          let bh = -1e9, bx = 0, bz = 0; for (let r = Rv; r < C.Rc * 1.05; r += 24) { const x = Math.cos(a) * r, z = Math.sin(a) * r, g = ground(x, z); if (g > bh) { bh = g; bx = x; bz = z; } }
          const hh = R(90, 230), col = pick([AQUA, TEAL, LEAF]); P('orgCone', bx, bh - 8, bz, R(0, 3), R(18, 34), hh + 8, R(18, 34), jit(col, 0.15)); P('glowCyl', bx, bh + hh * 0.3, bz, 0, 3, 3, 3, col); nCr++; }
      city.stats.crystals = nCr;
    }
    // ---------- finish: probes, beacon, stats ----------
    { const stp = Math.max(1, Math.floor(city.buildings.length / 150)); for (let i = 0; i < city.buildings.length; i += stp) { const b = city.buildings[i]; if (b.lvl === 0) city.probes.push(b.x, b.z, ground(b.x, b.z)); } if (city.probes.length < 60) for (let k = 0; k < 40; k++) { const a = k * 0.7, r = 300 + k * 30; city.probes.push(Math.cos(a) * r, Math.sin(a) * r, ground(Math.cos(a) * r, Math.sin(a) * r)); } }
    city.beacon = { x: 0, y: F + SP_H, z: 0, color: AQUA, color2: LEAF };
    city.hubHeight = SP_H; city.megas = 0; city.domes = []; city.outposts = 0; city.spurs = 0; city.connectors = 0; city.greens = 0;
    city.stats = Object.assign(city.stats, { buildings: city.buildings.length, pieces: city.pieces.length, nodes: nodes.length, edges: edges.length, towers: nTower, spirals: spirals.length, pylons: pylons.length, homes: city.poi.homes.length, shops: city.poi.shops.length, works: city.poi.works.length, maxFloors: Math.max(0, ...city.buildings.map(b => b.floors)), tunnelLen: Math.round(C.sOut - sIn), roadLen: Math.round(C.sEnd - C.sOut), edgeStyles: 'citadel' });
    return city;
}
