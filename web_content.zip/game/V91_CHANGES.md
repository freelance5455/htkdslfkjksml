# v91 - the flower mobile, Phase 2 (stuck -> weapons -> ambush -> chip)
Not playtested in a browser: this environment cannot load three.js, so the full game could not be booted. What was checked: `node --check`, a static undefined-name check against v90 (nothing new), and `tests/test_v91_phase2.mjs`, which loads the real flower-mobile code from `game.js` into a stub sandbox and plays the whole path (lodge, three modules, assemble, fit, ambush, restart, aftermath, arrival gate, 33 checks, plus a walk-reachability check of the second warehouse). It cannot judge how anything looks or feels. Please playtest the drive, the fight and the chip scene.

## The flow (stage `ambushStage` 0-5, `flowerStage` stays 4 throughout)
1. **Lodged.** When 55% of the route to the city is behind you, the game looks for dry, flat land a short glide ahead. The coil fails, the vehicle steers itself in and wedges in the entrance of a **second, different warehouse** (a wide loading bay with a stuttering, sparking vehicle). You are put on the ground in front of it and the waypoint moves to the entrance. If the route is all water, it keeps looking until 25% remains, then gives up and skips the whole thing (never a trap).
2. **Second warehouse** (underground, same method as the first, own layout and collision): a wide hall, a relay vault to the north and the entrance alcove to the south, with the vehicle's underside jammed through the ceiling above it, colder light and one dying lamp. Three modules, each its own beat: **focus lens** (pry a crate), **harmonic relay** (cut a welded cage, costs 4 laser charge), **resonator coil** (dig it out of a collapsed rack). The workbench has three empty cradles and says so if you inspect it early. HUD: "Modules n/3".
3. **Assemble and free.** With all three, the AI assembles a rod at the bench. Back on the surface, "Fit the rod under the vehicle" frees it (a short cutscene).
4. **Weapons.** As the vehicle comes free the AI reads the rod's output, realises the modules are emitters, and seats them in the petals: eight amber emitters, one per petal tip (they spin with the ring and show in the cockpit).
5. **Ambush.** Once you have driven 380 units on from the lodge (or reach the city early) the Kefenkline return: **7 drones, 5 raiders and 2 wardens**, spawned 50-75 units out. Click (desktop) or the fire button (touch, relabelled FIRE PETALS) fires the petals at whatever the existing lock-on cone has; shots cost no laser charge. Speed is capped at 34 u/s during the fight so the drones can keep up, any straggler more than 130 units away is pulled back into the ring, and the hull regenerates at 2.5/s instead of the normal 18/s. Hostile count uses the existing HOSTILES bar.
6. **Dying** in the fight restarts it from a checkpoint taken at its start, in the vehicle, with the whole wave again (the death screen says so, and nothing is logged as a normal death). Reloading mid-fight puts you back on the road with the ambush re-armed.
7. **The scrape.** Early in the fight one drone "scrapes the hull and veers off", a spark and a shake and one line from the AI. That is the tracking chip being planted.
8. **The chip.** At the Vale city the arrival scene is unchanged until the swarm alarm. Then, if you came by the flower mobile and won the ambush, the AI finds the chip under the core cradle (the existing red broadcast overlay: "KEFENKLINE TRACKING CHIP... VALE CITY MAIN ENTRANCE"), says it is far too late, and "they followed us here" lands. The heavy transport is placed over the main entrance. Without the vehicle path, the old line plays as before.

## Other changes
- `whResolve` and the warehouse walking branch now work from the active layout/origin (`whLayoutId`, `whOrigin`), so the hatch warehouse behaves exactly as in v90.
- City arrival is held until the ambush is won and the aftermath lines have finished. It never traps you: on foot, with the lodge skipped, or on the old no-vehicle route it is always allowed.
- Saves carry `ambushStage, lodgeSite, lodgeModules, lodgeWarehouseSeen, weaponsOnline, flowerRouteTotal, ambushScrapeDone`. A save made underground in the second warehouse puts you back at its entrance.
- `spawnPhase4Swarm` takes an optional base angle (used to put the transport over the main entrance).

## Tunables (top of the v91 block in game.js)
`LODGE_AT` 0.55, `LODGE_GIVE_UP` 0.25, `AMBUSH_SPEED` 34, `AMBUSH_RAIDERS` 5, `AMBUSH_WARDENS` 2, `VEHICLE_SHOT_GAP` 0.16 s, `VEHICLE_SHOT_DAMAGE_K` 0.9 (x the laser pulse damage: raiders take 4 shots, wardens 6).

## Where I changed your plan
- The plan says the chip is found "after the fight when you have already made it to the Vale"; I put the discovery at the swarm alarm in the arrival scene, because that is the line it pays off.
- You asked for the modules to free the vehicle and then be seen as weapons; the AI assembles them as a lifting rod first (so freeing it is a real step), and the weapon realisation comes from reading that rod's output.
