# v108 - the AI's words on waking from the dream (game.js only)

- After "Asleep on the Water" is logged, the AI now says two lines instead of one, with a short pause between them:
  1. "Your heart rate spiked three times. I'd call it a nightmare, but I don't think it was only that. Your brain hasn't completely forgotten what happened. I think it's going to keep coming back, and clearer each time."
  2. "Your hand's still closed. Take a minute. The water's calm, and nothing followed us."
- The second line echoes the log entry ("I woke with my hand still closed") and settles the mood before the next stop.
- "Will only get clearer" became "I think it's going to keep coming back, and clearer each time": the AI hedges instead of promising.
- Nothing else changed. The dream, its timing, the save and the caption hiding are as in v107.
- Not verified: how long the two lines take with the browser voice, or how the pause feels in play.
