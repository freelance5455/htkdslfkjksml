// =====================================================================================
// city_collide.js - solid geometry of ONE city, in the city's plan space (x east, z south, y world height). Pure maths (no three.js),
// shared by the player (city_runtime.js -> game.js updatePlayer) and by the drones (city_sim.js). Tested headless (tests/test_collide.mjs).
//
// A collider is an oriented box in plan with a top that may ramp along its own x axis (streets, stairs, bridges climb):
//   9 floats: cx, cz, yaw, hw, hd, yBot, yTop0, yTop1, kind          (stride COL_STRIDE)
//   yaw  : direction (cos yaw, sin yaw) of the box's +x axis in plan (same convention as city_core.js)
//   hw/hd: half extents along x / z
//   yTop0 / yTop1 : top height at u = -hw / u = +hw (equal for buildings)
//   kind : 0 = solid (blocks the player and the drones), 1 = floor (a street / deck: the player walks on it and is blocked by its side,
//          but drones, which travel ON streets, ignore it)
//
// Player rules (resolve): walking up a step <= STEP lands you on top; coming down onto a roof lands you on it; flying up into the
// underside of a deck stops you; anything else slides you out sideways along the shortest way out of the box.
// =====================================================================================
export const COL_STRIDE = 9;
const CELL = 48, OFF = 1024;
const key = (i, j) => (i + OFF) * 4096 + (j + OFF);

export class CityCollider {
    constructor(cols, opts = {}) {
        this.c = cols; this.n = Math.floor(cols.length / COL_STRIDE); this.cell = opts.cell || CELL; this.grid = new Map();
        this.minX = 1e18; this.maxX = -1e18; this.minZ = 1e18; this.maxZ = -1e18; this.mark = new Int32Array(this.n); this.stamp = 0;
        const c = this.cell;
        for (let i = 0; i < this.n; i++) {
            const o = i * COL_STRIDE, cx = cols[o], cz = cols[o + 1], yaw = cols[o + 2], hw = cols[o + 3], hd = cols[o + 4];
            const cs = Math.abs(Math.cos(yaw)), sn = Math.abs(Math.sin(yaw)), ex = hw * cs + hd * sn, ez = hw * sn + hd * cs;
            if (cx - ex < this.minX) this.minX = cx - ex; if (cx + ex > this.maxX) this.maxX = cx + ex; if (cz - ez < this.minZ) this.minZ = cz - ez; if (cz + ez > this.maxZ) this.maxZ = cz + ez;
            for (let a = Math.floor((cx - ex) / c); a <= Math.floor((cx + ex) / c); a++) for (let b = Math.floor((cz - ez) / c); b <= Math.floor((cz + ez) / c); b++) {
                const k = key(a, b); let l = this.grid.get(k); if (!l) this.grid.set(k, l = []); l.push(i);
            }
        }
        this.reach = Math.max(Math.abs(this.minX), Math.abs(this.maxX), Math.abs(this.minZ), Math.abs(this.maxZ));   // distance from the plan origin that holds everything
        this._cand = [];
    }
    // candidates whose cell range touches the disc (x, z, r); each returned once
    near(x, z, r) {
        const out = this._cand; out.length = 0; const c = this.cell, st = ++this.stamp;
        for (let a = Math.floor((x - r) / c); a <= Math.floor((x + r) / c); a++) for (let b = Math.floor((z - r) / c); b <= Math.floor((z + r) / c); b++) {
            const l = this.grid.get(key(a, b)); if (!l) continue;
            for (let k = 0; k < l.length; k++) { const i = l[k]; if (this.mark[i] !== st) { this.mark[i] = st; out.push(i); } }
        }
        return out;
    }
    // local coordinates of (x, z) in box i
    _uv(i, x, z, o) { const b = i * COL_STRIDE, c = this.c, cs = Math.cos(c[b + 2]), sn = Math.sin(c[b + 2]), dx = x - c[b], dz = z - c[b + 1]; o.u = dx * cs + dz * sn; o.v = -dx * sn + dz * cs; return o; }
    topAtU(i, u) { const b = i * COL_STRIDE, c = this.c, hw = c[b + 3], t = hw > 1e-6 ? Math.max(0, Math.min(1, (u + hw) / (2 * hw))) : 0.5; return c[b + 6] + (c[b + 7] - c[b + 6]) * t; }
    // highest walkable top under (x, z) that is at most `maxTop` (used to stand on things); -Infinity when there is none
    floorAt(x, z, maxTop, r = 0) {
        let best = -Infinity; const uv = this._tmpUV || (this._tmpUV = { u: 0, v: 0 });
        for (const i of this.near(x, z, r + 2)) {
            const b = i * COL_STRIDE, hw = this.c[b + 3], hd = this.c[b + 4]; this._uv(i, x, z, uv);
            if (Math.abs(uv.u) > hw + r || Math.abs(uv.v) > hd + r) continue;
            const t = this.topAtU(i, Math.max(-hw, Math.min(hw, uv.u))); if (t <= maxTop && t > best) best = t;
        }
        return best;
    }
    // Resolve a moving body (eye position m = {x, y, z}) that has just moved from (px, py, pz) to m. `H` = eye height above the feet, `r` = radius,
    // `up` = how far the head reaches above the eye. Returns flags {grounded, hit}; m is corrected in place. Call it in small steps (<= ~3 units).
    resolve(m, px, py, pz, H, r, up, step) {
        let grounded = false, hit = false; const uv = this._tmpUV2 || (this._tmpUV2 = { u: 0, v: 0 }), c = this.c;
        for (let iter = 0; iter < 3; iter++) {
            let moved = false; const feet = m.y - H, head = m.y + up, pfeet = py - H, phead = py + up;
            for (const i of this.near(m.x, m.z, r + 6)) {
                const b = i * COL_STRIDE, hw = c[b + 3], hd = c[b + 4], yBot = c[b + 5];
                this._uv(i, m.x, m.z, uv); const au = Math.abs(uv.u), av = Math.abs(uv.v);
                if (au >= hw + r || av >= hd + r) continue;
                const top = this.topAtU(i, Math.max(-hw, Math.min(hw, uv.u)));
                if (head <= yBot || feet >= top) continue;                       // clear above or below
                // came from above (or the lip is a step): stand on it
                if (pfeet >= top - step) { m.y = top + H + 0.02; grounded = true; hit = true; moved = true; break; }
                // came from below: bump the head under it
                if (phead <= yBot + 0.05 && yBot < feet + H * 0.9 + up) { m.y = yBot - up - 0.02; hit = true; moved = true; break; }
                // otherwise a wall: shortest way out in plan
                const pu = hw + r - au, pv = hd + r - av, cs = Math.cos(c[b + 2]), sn = Math.sin(c[b + 2]);
                let du = 0, dv = 0; if (pu < pv) du = (uv.u >= 0 ? 1 : -1) * (pu + 0.01); else dv = (uv.v >= 0 ? 1 : -1) * (pv + 0.01);
                m.x += du * cs - dv * sn; m.z += du * sn + dv * cs; hit = true; moved = true; break;
            }
            if (!moved) break;
        }
        return { grounded, hit };
    }
    // Drones: push the point (d.x, d.z) out of every SOLID box that overlaps the body's height band [y - 0.5, y + 6] by `r`. Returns true if it moved.
    pushOutXZ(d, y, r) {
        let moved = false; const uv = this._tmpUV3 || (this._tmpUV3 = { u: 0, v: 0 }), c = this.c;
        for (let iter = 0; iter < 2; iter++) {
            let any = false;
            for (const i of this.near(d.x, d.z, r + 6)) {
                const b = i * COL_STRIDE; if (c[b + 8] === 1) continue;
                const hw = c[b + 3], hd = c[b + 4]; this._uv(i, d.x, d.z, uv); const au = Math.abs(uv.u), av = Math.abs(uv.v);
                if (au >= hw + r || av >= hd + r) continue;
                const top = Math.max(c[b + 6], c[b + 7]); if (top <= y + 0.8 || c[b + 5] >= y + 6) continue;   // below the drone's feet or above its antenna
                const pu = hw + r - au, pv = hd + r - av, cs = Math.cos(c[b + 2]), sn = Math.sin(c[b + 2]);
                let du = 0, dv = 0; if (pu < pv) du = (uv.u >= 0 ? 1 : -1) * (pu + 0.02); else dv = (uv.v >= 0 ? 1 : -1) * (pv + 0.02);
                d.x += du * cs - dv * sn; d.z += du * sn + dv * cs; moved = true; any = true; break;
            }
            if (!any) break;
        }
        return moved;
    }
    // true if the plan point is inside a solid box in the band [y0, y1] (diagnostics / tests)
    solidAt(x, z, y0, y1) {
        const uv = this._tmpUV4 || (this._tmpUV4 = { u: 0, v: 0 }), c = this.c;
        for (const i of this.near(x, z, 2)) {
            const b = i * COL_STRIDE; if (c[b + 8] === 1) continue; this._uv(i, x, z, uv);
            if (Math.abs(uv.u) >= c[b + 3] || Math.abs(uv.v) >= c[b + 4]) continue;
            if (c[b + 5] < y1 && Math.max(c[b + 6], c[b + 7]) > y0) return true;
        }
        return false;
    }
}
