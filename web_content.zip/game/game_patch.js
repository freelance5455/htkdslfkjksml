/* PANTANAL UPDATE: replace old monster area with swamp, animated frogs/eagles, swamp potion and skin creator. */
(function(){
  'use strict';
  const SWAMP_ZONE=15;
  window.swampZone=SWAMP_ZONE;
  zones[SWAMP_ZONE].name='Pantanal';
  zones[SWAMP_ZONE].bg='#3b5e45';
  zones[SWAMP_ZONE].accent='#8fd36c';
  if (skins[SWAMP_ZONE]) skins[SWAMP_ZONE].name='Pantanal';

  // Remove legacy ant-specific achievements/data from the visible achievement registry.
  try {
    const ACH=window.getAchievements?.();
    if(ACH){
      ['frog_queen'].forEach(k=>delete ACH[k]);
      const nextSkinIndex=skins.length;
      if(!skins.some(s=>s.name==='Brilhante Pantanal')){
        skins.push({name:'Brilhante Pantanal',a:'#b6ff7b',b:'#195b45',c:'#fff8b0',pattern:'shine',special:true,rarity:'ÉPICA'});
      }
      ACH.frog_slayer={name:'Guardião do Pantanal • ÉPICA',desc:'Derrote o Sapo Rei do Pantanal e libere o Criador de Skin.',icon:'🐸',rewardCoins:1200,rewardSkin:skins.findIndex(s=>s.name==='Brilhante Pantanal'),rarity:'ÉPICA'};
    }
  }catch(e){}

  // Profile state for the new gate and skin creator.
  window.__swampPotion=Number(window.__swampPotion||0);
  window.__skinCreatorUnlocked=!!window.__skinCreatorUnlocked;
  const oldApplyProfile=window.applyProfile;
  window.applyProfile=function(k,p){
    oldApplyProfile.call(window,k,p);
    window.__swampPotion=Math.max(0,Number(p?.swampPotion||0));
    window.__skinCreatorUnlocked=!!p?.skinCreatorUnlocked || !!p?.achievements?.includes?.('frog_slayer');
    window.__customSkinData=p?.customSkinData&&typeof p.customSkinData==='object'?p.customSkinData:null;
    if(window.__customSkinData){const ci=skins.findIndex(v=>v.custom);if(ci>=0)skins[ci]=window.__customSkinData;else skins.push(window.__customSkinData);}
    patchStoreUI();
    gateSkinButtons();
  };
  const oldSave=window.save;
  window.save=function(){
    oldSave.call(window);
    if(!loggedIn||!accountKeySaved)return;
    let raw={};try{raw=JSON.parse(SAFE_STORE.get(accountKeySaved)||'{}')}catch(e){}
    raw.swampPotion=window.__swampPotion||0;
    raw.skinCreatorUnlocked=!!window.__skinCreatorUnlocked;
    raw.customSkinData=window.__customSkinData||raw.customSkinData||null;
    SAFE_STORE.set(accountKeySaved,JSON.stringify(raw));
  };

  // Swamp background uses the exact image uploaded by the player.
  const swampTexture=new Image(); swampTexture.src='pantanal.jpg';
  const frogImg=new Image(); frogImg.src='frog.gif';
  const eagleImg=new Image(); eagleImg.src='eagle.gif';
  const texReady=()=>swampTexture.complete&&swampTexture.naturalWidth>0;

  function patchStoreUI(){
    const info=document.getElementById('swampPotionInfo');
    if(info)info.textContent=`Você possui ${window.__swampPotion||0}`;
    const btn=document.getElementById('swampPotionBuy');
    if(btn){btn.textContent='1.800';btn.disabled=money<1800;}
    const oldMag=document.getElementById('magnetBuy')?.closest('.upgrade');
    if(oldMag) oldMag.remove();
  }
  function buySwampPotion(){
    if(money<1800){showNotice('🌿 Você precisa de 1.800 moedas para a Poção de Não Afundar.',2600);warningSound();return;}
    money-=1800;window.__swampPotion=(window.__swampPotion||0)+1;buySound();save();renderStore();updateHud();showNotice('🧪 Poção de Não Afundar comprada. Ela permite entrar no Pantanal.',3000);
  }
  window.buySwampPotion=buySwampPotion;
  setTimeout(()=>{
    const b=document.getElementById('swampPotionBuy'); if(b)b.onclick=buySwampPotion;
    patchStoreUI();
  },50);

  // Make store renderer show the new potion state.
  const oldRenderStore=window.renderStore;
  window.renderStore=function(){oldRenderStore.call(window);patchStoreUI();};

  // Replace the old magnet item with the swamp potion in the actual DOM if needed.
  function ensureStoreRow(){
    const store=document.getElementById('store'); if(!store)return;
    const box=store.querySelector('.storeExtra'); if(!box)return;
    let row=document.getElementById('swampPotionBuy')?.closest('.upgrade');
    const magnetRow=document.getElementById('magnetBuy')?.closest('.upgrade');
    if(!row){
      row=document.createElement('div');row.className='upgrade';
      row.innerHTML='<div><b>🧪 Poção de Não Afundar</b><small id="swampPotionInfo">Você possui 0 • Permite entrar no Pantanal</small></div><button id="swampPotionBuy" class="buy">1.800</button>';
      if(magnetRow) magnetRow.replaceWith(row); else box.insertBefore(row,box.firstElementChild);
      document.getElementById('swampPotionBuy').onclick=buySwampPotion;
    }
    patchStoreUI();
  }
  setTimeout(ensureStoreRow,80);

  // Frogs live only in the Pantanal.
  let frogs=[];
  const frogTypes=[
    {name:'Sapo Rei',hp:260,maxHp:260,r:46,speed:62,damage:12,boss:true},
    {name:'Sapo Caçador',hp:90,maxHp:90,r:30,speed:72,damage:7},
    {name:'Sapo Caçador',hp:90,maxHp:90,r:30,speed:72,damage:7},
    {name:'Sapo Saltador',hp:75,maxHp:75,r:28,speed:84,damage:6},
    {name:'Sapo Saltador',hp:75,maxHp:75,r:28,speed:84,damage:6},
    {name:'Sapo do Brejo',hp:110,maxHp:110,r:34,speed:55,damage:9}
  ];
  const swampX0=zones[SWAMP_ZONE].start, swampX1=zones[SWAMP_ZONE].end;
  function clampSwamp(p){p.x=clamp(p.x,swampX0+35,swampX1-35);p.y=clamp(p.y,120,world.h-120);return p;}
  function spawnFrogs(){
    frogs=frogTypes.map((t,i)=>({
      ...t,x:rnd(swampX0+80,swampX1-80),y:rnd(300,world.h-300),phase:rnd(0,6.28),ang:rnd(-Math.PI,Math.PI),hitCd:0,jumpCd:rnd(.4,2),vx:0,vy:0,dead:false,id:'frog_'+i
    }));
    // Make the Sapo Rei central and easy to find.
    frogs[0].x=(swampX0+swampX1)/2;
    frogs[0].y=world.h/2;
  }
  spawnFrogs();

  function frogFrame(img){
    if(!img.complete||!img.naturalWidth)return;
    x.drawImage(img,-img.naturalWidth/2,-img.naturalHeight/2,img.naturalWidth,img.naturalHeight);
  }
  function drawFrogEntity(f){
    if(f.dead)return;
    x.save();x.translate(f.x,f.y+Math.sin(f.phase)*3);
    const scale=f.boss?1.55:f.r/30;
    x.scale(scale,scale);
    frogFrame(frogImg);
    x.restore();
    // health only on the boss and only short name tags on small frogs
    x.save();
    const bw=f.boss?92:48,bh=6;
    x.fillStyle='#132018';x.fillRect(f.x-bw/2,f.y-f.r-24,bw,bh);
    x.fillStyle='#59df70';x.fillRect(f.x-bw/2,f.y-f.r-24,bw*Math.max(0,f.hp/f.maxHp),bh);
    x.strokeStyle='#fff6';x.strokeRect(f.x-bw/2,f.y-f.r-24,bw,bh);
    if(f.boss){x.fillStyle='#fff';x.font='900 12px system-ui';x.textAlign='center';x.fillText('SAPO REI',f.x,f.y-f.r-30)}
    x.restore();
  }

  function frogTarget(f){
    let best=null,bd=Infinity;
    if(zoneAt(worm.x)===SWAMP_ZONE){const d=dist(f,worm);if(d<bd){bd=d;best=worm;}}
    for(const a of critters){if(zoneAt(a.x)!==SWAMP_ZONE)continue;const d=dist(f,a);if(d<bd){bd=d;best=a;}}
    return best;
  }
  function frogAttackPlayer(f){
    if(f.hitCd>0||zoneAt(worm.x)!==SWAMP_ZONE)return;
    const d=dist(f,worm);if(d>f.r+(worm.r||13)+10)return;
    const hit=f.damage;
    window.__hurtPlayer?.(hit,`${f.name} te acertou e te lançou!`);
    const away=Math.atan2(worm.y-f.y,worm.x-f.x);
    worm.x=clamp(worm.x+Math.cos(away)*95,40,world.w-40);
    worm.y=clamp(worm.y+Math.sin(away)*95,50,world.h-50);
    worm.__frogLaunch=0.55;f.hitCd=1.0;addParticle(worm.x,worm.y,'#9cff73',12);warningSound();
  }
  function frogAttackSnake(f,a){
    if(f.hitCd>0)return;
    if(zoneAt(a.x)!==SWAMP_ZONE)return;
    if(dist(f,a)<f.r+a.r+6){a.hp=Math.max(0,(a.hp??Math.max(12,a.len*3+a.level*8))-f.damage);f.hitCd=.75;addParticle(a.x,a.y,'#8cf06d',8);if(a.hp<=0){critters=critters.filter(v=>v!==a);}}
  }
  function killFrog(f){
    f.dead=true;addParticle(f.x,f.y,'#b8ff72',30);money+=f.boss?1200:80;addXp(worm,f.boss?350:70);
    if(f.boss){
      window.__skinCreatorUnlocked=true;
      try{window.awardAchievement?.('frog_slayer')}catch(e){}
      showNotice('🏆 SAPO REI DERROTADO! Recompensa ÉPICA + Criador de Skin liberado!',5200);buySound();
    }else showNotice(`${f.name} derrotado!`,1800);
    save();updateHud();
  }
  function frogStep(dt){
    if(!running||!worm)return;
    for(const f of frogs){
      if(f.dead)continue;
      f.phase+=dt*3.4;f.hitCd=Math.max(0,f.hitCd-dt);f.jumpCd-=dt;
      const target=frogTarget(f);
      if(target){
        const wanted=Math.atan2(target.y-f.y,target.x-f.x);let d=wanted-f.ang;while(d>Math.PI)d-=Math.PI*2;while(d<-Math.PI)d+=Math.PI*2;f.ang+=clamp(d,-2.8*dt,2.8*dt);
        const speed=f.speed*(f.jumpCd<=0?1.55:1);f.x+=Math.cos(f.ang)*speed*dt;f.y+=Math.sin(f.ang)*speed*dt;
        if(f.jumpCd<=0){f.jumpCd=rnd(1.4,2.8);f.vx=Math.cos(f.ang)*180;f.vy=Math.sin(f.ang)*180;showNotice('🐸 Um sapo saltou!',900)}
      }else{
        f.ang+=Math.sin(f.phase*.7)*dt*.8;f.x+=Math.cos(f.ang)*f.speed*.22*dt;f.y+=Math.sin(f.ang)*f.speed*.22*dt;
      }
      if(f.vx||f.vy){f.x+=f.vx*dt;f.y+=f.vy*dt;f.vx*=Math.pow(.03,dt);f.vy*=Math.pow(.03,dt)}
      clampSwamp(f);
      // Frog fights player and snakes, but never eagles.
      frogAttackPlayer(f);
      if(f.hitCd<=0){for(const a of critters){frogAttackSnake(f,a);if(f.hitCd>0)break;}}
    }
    if(zoneAt(worm.x)===SWAMP_ZONE && window.__getCombatStats){
      const s=window.__getCombatStats();
      if(s.attackEnabled){
        for(const f of frogs){if(f.dead)continue;const rr=f.r+(worm.r||13)+14;if(dist(f,worm)<rr && (f.boss||s.damage>=1)){const hit=Math.max(1,Number(s.damage||1));f.hp-=hit;f.vx=Math.cos(worm.ang||0)*120;f.vy=Math.sin(worm.ang||0)*120;addParticle(f.x,f.y,'#ffe36b',10);showNotice(`💥 Cabeçada no ${f.name}: -${hit} HP`,700);if(f.hp<=0)killFrog(f);break;}}
      }
    }
    frogs=frogs.filter(f=>!f.dead || f.boss);
  }

  // Pântano render: exact uploaded texture tiled across the area.
  function drawSwampTerrain(){
    x.save();
    x.beginPath();x.rect(swampX0,0,swampX1-swampX0,world.h);x.clip();
    if(texReady()){
      const tw=720,th=480;
      for(let yy=0;yy<world.h;yy+=th)for(let xx=swampX0;xx<swampX1;xx+=tw)x.drawImage(swampTexture,xx,yy,tw,th);
      x.fillStyle='#1c3f2a33';x.fillRect(swampX0,0,swampX1-swampX0,world.h);
    }else{x.fillStyle='#355044';x.fillRect(swampX0,0,swampX1-swampX0,world.h)}
    // shallow-water/mud pools
    for(let i=0;i<13;i++){
      const px=swampX0+70+(i*173)%Math.max(80,swampX1-swampX0-120), py=220+(i*431)%Math.max(100,world.h-420), rx=65+(i%3)*22, ry=34+(i%4)*13;
      x.fillStyle='#294f4b55';x.beginPath();x.ellipse(px,py,rx,ry,(i%5)*.3,0,Math.PI*2);x.fill();
    }
    x.restore();
  }
  window.__drawMonsterAreaTerrain=drawSwampTerrain;
  window.__drawMonsterAreas=function(){for(const f of frogs)drawFrogEntity(f);};

  // Eagles: one per biome, all based on the uploaded animated eagle asset.
  const EAGLE_COUNT=zones.length;
  function makeEagle(i){
    const z=zones[i],cx=(z.start+z.end)/2;
    return {id:i,x:rnd(z.start+70,z.end-70),y:rnd(200,world.h-200),zone:i,homeX:cx,homeY:rnd(300,world.h-300),phase:rnd(0,6.28),ang:rnd(-Math.PI,Math.PI),speed:92+(i%5)*9,type:{name:`Águia • ${z.name}`,speed:92+(i%5)*9,size:48},alert:1};
  }
  function spawnEagles(){hunters=[];for(let i=0;i<EAGLE_COUNT;i++)hunters.push(makeEagle(i));}
  window.spawnHunters=spawnEagles;
  function eagleTarget(h){
    if(zoneAt(worm.x)===h.zone)return worm;
    let best=null,bd=Infinity;
    for(const a of critters){if(zoneAt(a.x)!==h.zone)continue;const d=dist(h,a);if(d<bd){bd=d;best=a;}}
    return best;
  }
  function eagleStep(h,dt){
    const t=eagleTarget(h);
    if(t){
      const wanted=Math.atan2(t.y-h.y,t.x-h.x);let d=wanted-h.ang;while(d>Math.PI)d-=Math.PI*2;while(d<-Math.PI)d+=Math.PI*2;h.ang+=clamp(d,-2.7*dt,2.7*dt);
      h.x+=Math.cos(h.ang)*h.speed*dt;h.y+=Math.sin(h.ang)*h.speed*dt;
      if(t===worm && dist(h,worm)<h.type.size*.55+(worm.r||13)){
        melody([740,520,360]);tone(90,.7,'sawtooth',.24,55);showNotice(`🦅 ${h.type.name} te pegou!`,1400);die('Uma águia te alcançou.');
      }else if(t!==worm && dist(h,t)<h.type.size*.45+(t.r||10)){
        t.hp=0;critters=critters.filter(v=>v!==t);addParticle(t.x,t.y,'#fff3a0',14);
      }
    }else{
      h.ang+=Math.sin(h.phase*.6)*dt*.45;h.x+=Math.cos(h.ang)*h.speed*.35*dt;h.y+=Math.sin(h.ang)*h.speed*.35*dt;
    }
    h.phase+=dt*5.2;
    h.x=clamp(h.x,zones[h.zone].start+25,zones[h.zone].end-25);h.y=clamp(h.y,80,world.h-80);
  }
  window.__drawEagle=function(h){
    x.save();x.translate(h.x,h.y);x.rotate(Math.sin(h.phase)*.12);const scale=.82; x.scale(scale,scale);if(eagleImg.complete&&eagleImg.naturalWidth)x.drawImage(eagleImg,-eagleImg.naturalWidth/2,-eagleImg.naturalHeight/2);else {x.fillStyle='#6c5138';x.beginPath();x.ellipse(0,0,32,18,0,0,Math.PI*2);x.fill();}x.restore();
  };


  window.renderHunters=function(){
    const el=document.getElementById('hunterList'); if(!el)return;
    el.innerHTML=zones.map((z,i)=>`<div class="row hunterRow"><span class="hunterMini"></span><span><b>Águia • ${z.name}</b><small>${hunters[i]?'NO MAPA':'FORA DO MAPA'} • 1 nesta área</small></span><small>${hunterActive?'ATIVA':'PAUSADA'}</small></div>`).join('');
  };

  // Start each run with one eagle per biome.
  const oldReset=window.resetRun;
  window.resetRun=function(){oldReset.call(window);spawnEagles();spawnFrogs();};
  if(running)spawnEagles();

  // Keep the old update from moving the eagle flock, then run our biome-aware flock and frogs.
  const oldUpdate=window.update;
  window.update=function(dt){
    const wasHunter= hunterActive;
    hunterActive=false;
    oldUpdate.call(window,dt);
    hunterActive=wasHunter;
    if(!running||!worm)return;
    frogStep(dt);
    if(gameMode==='bots'&&hunterActive){for(const h of hunters)eagleStep(h,dt);}
    if(worm.__frogLaunch){worm.__frogLaunch=Math.max(0,worm.__frogLaunch-dt)}
  };

  // Draw animated eagles and hide all legacy ant rendering.
  const oldWorldDraw=window.worldDraw;
  window.worldDraw=function(){
    const wasHunter=hunterActive;hunterActive=false;oldWorldDraw.call(window);hunterActive=wasHunter;
    if(gameMode==='bots'&&hunterActive){x.save();x.translate(-cam.x,-cam.y);for(const h of hunters){if(h.x<cam.x-120||h.x>cam.x+W+120||h.y<cam.y-160||h.y>cam.y+H+160)continue;window.__drawEagle(h)}x.restore();}
  };

  const oldAwardAchievement=window.awardAchievement; window.awardAchievement=function(id){const r=oldAwardAchievement?.(id);if(id==='frog_slayer'){window.__skinCreatorUnlocked=true;gateSkinButtons();save();}return r;};

  // Direct walking into Pantanal requires the new potion.
  const oldUpdatePlayer=window.updatePlayer;
  let lastSwampGood={x:0,y:0};
  window.updatePlayer=function(dt){
    if(!worm){return oldUpdatePlayer.call(window,dt)}
    const before={x:worm.x,y:worm.y};
    const oldMoney=money,oldUnlocked=unlocked,oldSkin=selectedSkin,oldZone=lastZone,oldPotion=window.__swampPotion||0;
    oldUpdatePlayer.call(window,dt);
    const afterZone=zoneAt(worm.x),beforeZone=zoneAt(before.x);
    const entering=afterZone===SWAMP_ZONE&&beforeZone!==SWAMP_ZONE;
    if(entering && oldPotion<=0){
      worm.x=before.x;worm.y=before.y;money=oldMoney;unlocked=oldUnlocked;selectedSkin=oldSkin;lastZone=oldZone;save();
      warningSound();showNotice('🧪 Para entrar no Pantanal você precisa da Poção de Não Afundar.',3000);return;
    }
    if(entering && oldPotion>0){
      window.__swampPotion=oldPotion-1;showNotice('🧪 Poção de Não Afundar usada. Você entrou no Pantanal!',2600);save();renderStore();
    }
    if(afterZone===SWAMP_ZONE){lastSwampGood={x:worm.x,y:worm.y};}
  };

  const oldUsePortal=window.usePortal;
  window.usePortal=function(){
    const next=Math.min(zones.length-1,unlocked+1);
    if(next===SWAMP_ZONE && (window.__swampPotion||0)<=0){showNotice('🧪 O Portal para o Pantanal exige a Poção de Não Afundar.',3200);return;}
    const before=window.__swampPotion||0;
    oldUsePortal.call(window);
    if(next===SWAMP_ZONE && unlocked===SWAMP_ZONE && before>0){window.__swampPotion=before-1;save();renderStore();showNotice('🧪 Poção usada no portal do Pantanal.',2200);}
  };
  const oldUsePortalAt=window.usePortalAt;
  window.usePortalAt=function(o){
    const next=Math.min(zones.length-1,unlocked+1);
    if(next===SWAMP_ZONE && (window.__swampPotion||0)<=0){showNotice('🧪 O Portal para o Pantanal exige a Poção de Não Afundar.',3200);return;}
    const before=window.__swampPotion||0;oldUsePortalAt.call(window,o);
    if(next===SWAMP_ZONE && unlocked===SWAMP_ZONE && before>0){window.__swampPotion=before-1;save();renderStore();}
  };

  // Skin creator: unlocks only after the Sapo Rei achievement.
  const creatorPatterns=['bands','waves','spots','rings','crystal','flame','galaxy','aurora','shine','metal'];

  function gateSkinButtons(){
    const ids=['customSkinButton','menuCustomSkin'];
    for(const id of ids){const b=document.getElementById(id);if(!b)continue;b.style.display=window.__skinCreatorUnlocked?'':'none';b.onclick=openSkinCreator;}
    const c=document.getElementById('skinCreatorBtn');if(c)c.style.display=window.__skinCreatorUnlocked?'':'none';
    const s=document.getElementById('startSkinCreator');if(s)s.style.display=window.__skinCreatorUnlocked?'':'none';
  }

  function openSkinCreator(){
    if(!window.__skinCreatorUnlocked){showNotice('🔒 Derrote o Sapo Rei para desbloquear o Criador de Skin.',3000);return;}
    let modal=document.getElementById('skinCreator');
    if(!modal){
      modal=document.createElement('div');modal.id='skinCreator';modal.className='modal';
      modal.innerHTML=`<div class="modalCard"><div class="modalHead"><h2>🎨 Criador de Skin • ÉPICO</h2><button class="close">X</button></div><p class="sub">Escolha várias texturas e cores para criar sua própria skin.</p><div class="creatorGrid"><label>Cor 1 <input id="sc1" type="color" value="#58e66c"></label><label>Cor 2 <input id="sc2" type="color" value="#1c6d45"></label><label>Detalhe <input id="sc3" type="color" value="#f4ff9a"></label></div><div id="scPatterns" class="patternGrid"></div><button id="scMake" class="play">CRIAR / EQUIPAR SKIN</button><div id="scMeta" class="sub"></div></div>`;
      document.body.appendChild(modal);modal.querySelector('.close').onclick=()=>modal.style.display='none';
      const pg=modal.querySelector('#scPatterns');creatorPatterns.forEach((p,i)=>{const b=document.createElement('button');b.className='miniBtn';b.dataset.pattern=p;b.textContent=`TEXTURA ${i+1} • ${p.toUpperCase()}`;b.onclick=()=>{modal.querySelectorAll('[data-pattern]').forEach(v=>v.classList.remove('on'));b.classList.add('on');modal.dataset.pattern=p;};pg.appendChild(b)});pg.firstElementChild?.classList.add('on');modal.dataset.pattern=creatorPatterns[0];
      modal.querySelector('#scMake').onclick=()=>{
        const s={name:`Minha Skin • ${new Date().toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'})}`,a:modal.querySelector('#sc1').value,b:modal.querySelector('#sc2').value,c:modal.querySelector('#sc3').value,pattern:modal.dataset.pattern,special:true,rarity:'ÉPICA',custom:true};
        const idx=skins.findIndex(v=>v.custom);if(idx>=0)skins[idx]=s;else skins.push(s);window.__customSkinData=s;
        selectedSkin=skins.length-1;window.__achievementSkinUnlocks=window.__achievementSkinUnlocks||new Set();window.__achievementSkinUnlocks.add(selectedSkin);if(worm){worm.color=s.a;worm.skinIndex=selectedSkin;worm.skinName=s.name;worm.pattern=s.pattern;}save();renderStore();updateHud();showNotice('🎨 Sua Skin ÉPICA foi criada e equipada!',3500);
      };
    }
    modal.style.display='grid';document.body.classList.add('modal-open');
  }
  window.openSkinCreator=openSkinCreator;
  setTimeout(()=>{
    gateSkinButtons();
    const menu=document.getElementById('menuBtns');
    if(menu&&!document.getElementById('skinCreatorBtn')){const b=document.createElement('button');b.id='skinCreatorBtn';b.className='miniBtn';b.textContent='CRIADOR DE SKIN';b.onclick=openSkinCreator;menu.appendChild(b);}
    const start=document.querySelector('#startMenu .menuGrid');
    if(start&&!document.getElementById('startSkinCreator')){const b=document.createElement('button');b.id='startSkinCreator';b.className='miniBtn';b.textContent='CRIADOR DE SKIN';b.onclick=openSkinCreator;start.appendChild(b);}
  },120);

  // Remove leftover ant UI/file references from the page title area.
  document.title='Mundo da Minhoca Fusão • Pantanal';
  console.log('[Pantanal] Pantanal, sapos animados, poção de não afundar e uma águia por bioma ativos.');
})();
