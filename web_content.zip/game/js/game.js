/* RPG Sprite Game - single file engine. See ../README.md and ../docs/PROJECT_NOTES.md */
(() => {
'use strict';
const cv = document.getElementById('game'), ctx = cv.getContext('2d');
const CFG = {
  maxSpeed: 70,      // world px / s
  accel: 600,        // px / s^2
  friction: 500,     // px / s^2 when no input
  gravity: 520,      // px / s^2 (z axis)
  jumpVel: 175,      // px / s
  tilt: 0.8,         // vertical squash of ground plane -> angled camera feel
  world: { w: 640, h: 480 },
};

// ---------- assets ----------
const IMGS = {};
const load = (name, src) => new Promise(r => { const i = new Image(); i.onload = () => { IMGS[name] = i; r(); }; i.src = src; });

// ---------- input ----------
const input = { x: 0, y: 0, jump: false, sit: false, keys: {} };
const stick = document.getElementById('stick'), knob = document.getElementById('knob');
let stickId = null;
function stickMove(t) {
  const r = stick.getBoundingClientRect(), cx = r.left + r.width / 2, cy = r.top + r.height / 2;
  let dx = (t.clientX - cx) / (r.width / 2), dy = (t.clientY - cy) / (r.height / 2);
  const l = Math.hypot(dx, dy); if (l > 1) { dx /= l; dy /= l; }
  input.x = Math.abs(dx) < .15 ? 0 : dx; input.y = Math.abs(dy) < .15 ? 0 : dy;
  knob.style.transform = `translate(${dx * 37}px,${dy * 37}px)`;
}
function stickEnd() { stickId = null; input.x = input.y = 0; knob.style.transform = ''; }
stick.addEventListener('touchstart', e => { e.preventDefault(); const t = e.changedTouches[0]; stickId = t.identifier; stickMove(t); }, { passive: false });
stick.addEventListener('touchmove', e => { e.preventDefault(); for (const t of e.changedTouches) if (t.identifier === stickId) stickMove(t); }, { passive: false });
stick.addEventListener('touchend', e => { for (const t of e.changedTouches) if (t.identifier === stickId) stickEnd(); });
stick.addEventListener('touchcancel', stickEnd);
const btnJump = document.getElementById('btnJump'), btnSit = document.getElementById('btnSit');
const press = (el, fn) => { el.addEventListener('touchstart', e => { e.preventDefault(); fn(); }, { passive: false }); el.addEventListener('mousedown', fn); };
press(btnJump, () => input.jump = true);
press(btnSit, () => toggleSit());
addEventListener('keydown', e => { input.keys[e.code] = true; if (e.code === 'Space') input.jump = true; if (e.code === 'KeyC') toggleSit(); });
addEventListener('keyup', e => input.keys[e.code] = false);
addEventListener('contextmenu', e => e.preventDefault());

// ---------- world ----------
// Obstacles: x,y = feet center, w = collision width, h = collision depth, draw(ctx) draws at feet.
const rng = (() => { let s = 12345; return () => (s = (s * 1664525 + 1013904223) >>> 0) / 4294967296; })();
const props = [];
for (let i = 0; i < 22; i++) {
  const type = rng() < .6 ? 'tree' : 'rock';
  const x = 30 + rng() * (CFG.world.w - 60), y = 40 + rng() * (CFG.world.h - 60);
  if (Math.hypot(x - 320, y - 260) < 50) continue; // keep spawn clear
  props.push({ type, x, y, w: type === 'tree' ? 10 : 14, d: type === 'tree' ? 6 : 8 });
}
function drawProp(p) {
  const {x, y} = p;
  if (p.type === 'tree') {
    shadow(x, y, 14, 5);
    ctx.fillStyle = '#5a3a1e'; ctx.fillRect(x - 3, y - 14, 6, 14);
    ctx.fillStyle = '#2f6b2f'; ctx.fillRect(x - 12, y - 38, 24, 26);
    ctx.fillStyle = '#3d8a3d'; ctx.fillRect(x - 9, y - 44, 18, 8);
    ctx.fillStyle = '#245524'; ctx.fillRect(x - 12, y - 18, 24, 6);
  } else {
    shadow(x, y, 11, 4);
    ctx.fillStyle = '#7d7d85'; ctx.fillRect(x - 8, y - 9, 16, 9);
    ctx.fillStyle = '#9a9aa3'; ctx.fillRect(x - 6, y - 12, 10, 4);
  }
}
function shadow(x, y, rx, ry, a = .28) {
  ctx.fillStyle = `rgba(0,0,0,${a})`; ctx.beginPath(); ctx.ellipse(x, y, rx, ry, 0, 0, 7); ctx.fill();
}
function drawGround(cam, vw, vh) {
  ctx.fillStyle = '#3f7d3a'; ctx.fillRect(cam.x, cam.y, vw, vh);
  const T = 16, x0 = Math.floor(cam.x / T), y0 = Math.floor(cam.y / T);
  for (let ty = y0; ty < y0 + vh / T + 1; ty++) for (let tx = x0; tx < x0 + vw / T + 1; tx++) {
    if ((tx + ty) & 1) { ctx.fillStyle = '#438340'; ctx.fillRect(tx * T, ty * T, T, T); }
    const h = (tx * 73856093 ^ ty * 19349663) >>> 0;
    if (h % 7 === 0) { ctx.fillStyle = '#5fa055'; ctx.fillRect(tx * T + (h >> 3) % 12, ty * T + (h >> 5) % 12, 2, 2); }
  }
  // world border
  ctx.strokeStyle = '#1b3a1b'; ctx.lineWidth = 3; ctx.strokeRect(0, 0, CFG.world.w, CFG.world.h);
}

// ---------- player ----------
const P = { x: 320, y: 260, vx: 0, vy: 0, z: 0, vz: 0, dir: 'down', sitting: false, anim: 0, moving: false, land: 0 };
function toggleSit() { if (P.z > 0.5) return; P.sitting = !P.sitting; btnSit.classList.toggle('on', P.sitting); }
const FEET_W = 5, FEET_D = 3;
function blocked(x, y) {
  if (x < 6 || y < 8 || x > CFG.world.w - 6 || y > CFG.world.h - 2) return true;
  for (const p of props) if (Math.abs(x - p.x) < (p.w + FEET_W) / 2 && Math.abs(y - p.y) < (p.d + FEET_D) / 2) return true;
  return false;
}
function update(dt) {
  const k = input.keys;
  let ix = input.x + ((k.KeyD || k.ArrowRight) ? 1 : 0) - ((k.KeyA || k.ArrowLeft) ? 1 : 0);
  let iy = input.y + ((k.KeyS || k.ArrowDown) ? 1 : 0) - ((k.KeyW || k.ArrowUp) ? 1 : 0);
  const il = Math.hypot(ix, iy); if (il > 1) { ix /= il; iy /= il; }
  if (P.sitting) ix = iy = 0;
  // jump (z axis with real gravity)
  if (input.jump) { if (P.z <= 0 && !P.sitting) { P.vz = CFG.jumpVel; } input.jump = false; }
  if (P.z > 0 || P.vz > 0) {
    P.vz -= CFG.gravity * dt; P.z += P.vz * dt;
    if (P.z <= 0) { P.z = 0; P.vz = 0; P.land = .12; }
  }
  // horizontal movement: accel toward target velocity, friction when idle. Less air control.
  const air = P.z > 0 ? .5 : 1;
  const tx = ix * CFG.maxSpeed, ty = iy * CFG.maxSpeed * CFG.tilt;
  const step = (v, t) => { const a = (t === 0 ? CFG.friction : CFG.accel) * air * dt; return v < t ? Math.min(t, v + a) : Math.max(t, v - a); };
  P.vx = step(P.vx, tx); P.vy = step(P.vy, ty);
  let nx = P.x + P.vx * dt; if (!blocked(nx, P.y)) P.x = nx; else P.vx = 0;
  let ny = P.y + P.vy * dt; if (!blocked(P.x, ny)) P.y = ny; else P.vy = 0;
  const sp = Math.hypot(P.vx, P.vy / CFG.tilt);
  P.moving = sp > 8 && !P.sitting;
  if (P.moving && (ix || iy)) P.dir = Math.abs(ix) > Math.abs(iy) ? (ix > 0 ? 'right' : 'left') : (iy > 0 ? 'down' : 'up');
  if (P.moving && P.z <= 0) P.anim += dt * sp / 7;
  if (P.land > 0) P.land -= dt;
}
function drawPlayer() {
  const key = P.dir === 'down' ? 'front' : P.dir === 'up' ? 'back' : 'side';
  const img = IMGS[key], w = img.width, h = img.height;
  shadow(P.x, P.y, 6 - Math.min(P.z, 40) / 14, 2.2, .3 - Math.min(P.z, 40) / 200);
  ctx.save();
  ctx.translate(Math.round(P.x), Math.round(P.y - P.z));
  let sx = 1, sy = 1, bob = 0, rot = 0;
  if (P.sitting) { sy = .72; }
  else if (P.z > 0) { sy = 1 + Math.min(Math.abs(P.vz) / 1200, .12); sx = 2 - sy; }
  else if (P.land > 0) { sy = .88; sx = 1.08; }
  else if (P.moving) { const s = Math.sin(P.anim); bob = -Math.abs(s) * 1.6; rot = s * .045; }
  if (P.dir === 'left') sx *= -1;
  ctx.translate(0, bob); ctx.rotate(rot); ctx.scale(sx, sy);
  ctx.drawImage(img, -w / 2, -h);
  ctx.restore();
}

// ---------- main loop ----------
let S = 3, vw = 0, vh = 0; const cam = { x: 0, y: 0 };
function resize() {
  const dpr = devicePixelRatio || 1;
  cv.width = Math.round(innerWidth * dpr); cv.height = Math.round(innerHeight * dpr);
  S = Math.max(2, Math.round(Math.min(cv.width, cv.height) / 190));
  vw = cv.width / S; vh = cv.height / S;
}
addEventListener('resize', resize); resize();
let last = performance.now();
function frame(now) {
  const dt = Math.min((now - last) / 1000, .05); last = now;
  update(dt);
  const tx = P.x - vw / 2, ty = (P.y - P.z * .3) - vh / 2;
  cam.x += (tx - cam.x) * Math.min(1, dt * 8); cam.y += (ty - cam.y) * Math.min(1, dt * 8);
  cam.x = Math.max(-20, Math.min(cam.x, CFG.world.w - vw + 20)); cam.y = Math.max(-20, Math.min(cam.y, CFG.world.h - vh + 20));
  ctx.setTransform(S, 0, 0, S, 0, 0); ctx.imageSmoothingEnabled = false;
  ctx.fillStyle = '#000'; ctx.fillRect(0, 0, vw, vh);
  ctx.translate(-Math.round(cam.x), -Math.round(cam.y));
  drawGround(cam, vw, vh);
  // depth sort by feet y (angled camera: things lower on screen draw in front)
  const list = props.map(p => ({ y: p.y, f: () => drawProp(p) }));
  list.push({ y: P.y, f: drawPlayer });
  list.sort((a, b) => a.y - b.y).forEach(o => o.f());
  requestAnimationFrame(frame);
}
Promise.all([load('front', 'assets/front_px.png'), load('side', 'assets/side_px.png'), load('back', 'assets/back_px.png')])
  .then(() => requestAnimationFrame(frame));
})();
