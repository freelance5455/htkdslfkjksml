// =====================================================================================
// city_roads.js - road routing between two valley city-states (pure maths; runs in a chunk worker, tested in Node).
//
// A road = [ city A gate -> A's pass -> (A* over the terrain) -> B's pass -> city B gate ].
//   * The pass part follows each valley's own pass centreline (valley_sites.js: passAng / passCurl), so roads leave a valley by its pass.
//   * Between the two pass mouths a lazy A* runs on a coarse grid in the tangent plane of the midpoint (gnomonic, error < 3% at 100 km):
//     cost = distance * (1 + 5 slope^2); impassable: water / near sea level, slopes > 0.62 per grid step; hostile terrain (dune seas, spire
//     fields) is heavily penalised. Heights are sampled lazily, only for nodes the search touches.
//   * The path is smoothed (Chaikin) and resampled every ~70 units. OUTPUT = unit DIRECTIONS on the sphere (chart independent): each
//     chart turns them into chart points with geoToChart() and drapes the ribbon on the real terrain (getEnvironmentAt).
// =====================================================================================
import { PLANET_R } from './planet_core.js';
import { localFrame, localToDir } from './valley_sites.js';

const R = PLANET_R;
class Heap {
    constructor() { this.a = []; }
    push(k, v) { const a = this.a; a.push([k, v]); let i = a.length - 1; while (i > 0) { const p = (i - 1) >> 1; if (a[p][0] <= a[i][0]) break; [a[p], a[i]] = [a[i], a[p]]; i = p; } }
    pop() { const a = this.a, top = a[0], last = a.pop(); if (a.length) { a[0] = last; let i = 0; for (;;) { let l = 2 * i + 1, r = l + 1, m = i; if (l < a.length && a[l][0] < a[m][0]) m = l; if (r < a.length && a[r][0] < a[m][0]) m = r; if (m === i) break; [a[m], a[i]] = [a[i], a[m]]; i = m; } } return top; }
    get size() { return this.a.length; }
}
// the pass centreline of a site as local (a, n) points from the gate outwards to Rb
export function passPath(S, n = 14) {
    const out = [];
    for (let k = 0; k <= n; k++) {
        const t = k / n, th = S.passAng + S.passCurl * Math.sin(t * 2.1) * t, rad = (S.passR || S.Rf) * 0.985 + t * (S.Rb - (S.passR || S.Rf) * 0.985);
        out.push([Math.cos(th) * rad, Math.sin(th) * rad]);
    }
    return out;
}
export function buildRoad(T, A, B, opts = {}) {
    // retry with progressively looser slope limits (the mouth of a pass can sit under steep natural ground at the 500-unit scale)
    let r = null; for (const sl of (opts.slopes || [0.9, 1.4, 2.4])) { r = buildRoadOnce(T, A, B, opts, sl); if (r.ok) { r.slopeLimit = sl; return r; } }
    return r;
}
function buildRoadOnce(T, A, B, opts, SLOPE_MAX) {
    const t0 = (typeof performance !== 'undefined' ? performance : Date).now();
    const GS = opts.grid || 500, d = [0, 0, 0], o = {};
    const dirA = [0, 0, 0], dirB = [0, 0, 0];
    const pa = passPath(A), pb = passPath(B);
    localToDir(A, pa[pa.length - 1][0], pa[pa.length - 1][1], dirA); localToDir(B, pb[pb.length - 1][0], pb[pb.length - 1][1], dirB);
    // tangent plane at the midpoint
    const m = [dirA[0] + dirB[0], dirA[1] + dirB[1], dirA[2] + dirB[2]], il = 1 / Math.hypot(m[0], m[1], m[2]); m[0] *= il; m[1] *= il; m[2] *= il;
    const f = localFrame(m);
    const toPlane = (p) => { const k = 1 / (p[0] * m[0] + p[1] * m[1] + p[2] * m[2]); const x = p[0] * k - m[0], y = p[1] * k - m[1], z = p[2] * k - m[2]; return [(x * f.e[0] + y * f.e[1] + z * f.e[2]) * R, (x * f.n[0] + y * f.n[1] + z * f.n[2]) * R]; };
    const toDir = (u, v, out) => { const k = 1 / R, x = m[0] + (f.e[0] * u + f.n[0] * v) * k, y = m[1] + (f.e[1] * u + f.n[1] * v) * k, z = m[2] + (f.e[2] * u + f.n[2] * v) * k, l = 1 / Math.hypot(x, y, z); out[0] = x * l; out[1] = y * l; out[2] = z * l; return out; };
    const sa = toPlane(dirA), sb = toPlane(dirB), L = Math.hypot(sb[0] - sa[0], sb[1] - sa[1]);
    const W = Math.max(14, Math.ceil(L * 0.32 / GS));   // corridor half-width in cells
    const ex = (sb[0] - sa[0]) / L, ez = (sb[1] - sa[1]) / L;
    const cache = new Map(), key = (i, j) => (i + 4096) * 8192 + (j + 4096);
    const cell = (i, j) => { const k = key(i, j); let c = cache.get(k); if (!c) { toDir(i * GS, j * GS, d); const h = T.sample3(d[0] * R, d[1] * R, d[2] * R, o); c = { h, hostile: T.isHostile3(d[0] * R, d[1] * R, d[2] * R) }; cache.set(k, c); } return c; };
    const si = Math.round(sa[0] / GS), sj = Math.round(sa[1] / GS), ti = Math.round(sb[0] / GS), tj = Math.round(sb[1] / GS);
    const inCorridor = (i, j) => { const x = i * GS - sa[0], y = j * GS - sa[1], t = x * ex + y * ez, lat = Math.abs(-x * ez + y * ex); return t > -GS * 6 && t < L + GS * 6 && lat < W * GS; };
    const open = new Heap(), g = new Map(), from = new Map(), closed = new Set();
    g.set(key(si, sj), 0); open.push(0, [si, sj]);
    let found = false, expanded = 0;
    const N8 = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]];
    while (open.size && expanded < 90000) {
        const [, [ci, cj]] = open.pop(), ck = key(ci, cj); if (closed.has(ck)) continue; closed.add(ck); expanded++;
        if (ci === ti && cj === tj) { found = true; break; }
        const c0 = cell(ci, cj);
        for (const [di, dj] of N8) {
            const ni = ci + di, nj = cj + dj; if (!inCorridor(ni, nj)) continue;
            const nk = key(ni, nj); if (closed.has(nk)) continue;
            const c1 = cell(ni, nj), dist = Math.hypot(di, dj) * GS, slope = Math.abs(c1.h - c0.h) / dist;
            const endpoint = (ni === ti && nj === tj) || (ni === si && nj === sj);
            if (!endpoint && (c1.h < 3 || slope > SLOPE_MAX)) continue;
            const cost = dist * (1 + 5 * slope * slope + (c1.hostile ? 8 : 0) + (c1.h > 4200 ? 2 : 0)), ng = g.get(ck) + cost;
            if (ng < (g.get(nk) ?? 1e30)) { g.set(nk, ng); from.set(nk, ck); open.push(ng + Math.hypot(ni - ti, nj - tj) * GS, [ni, nj]); }
        }
    }
    if (!found) return { ok: false, reason: 'no path', expanded, ms: (typeof performance !== 'undefined' ? performance : Date).now() - t0 };
    // reconstruct, smooth (Chaikin x2), resample every ~70 units
    let path = []; { let k = key(ti, tj); const cells = []; while (k !== undefined) { cells.push(k); k = from.get(k); } cells.reverse(); for (const kk of cells) path.push([(Math.floor(kk / 8192) - 4096) * GS, ((kk % 8192) - 4096) * GS]); }
    path[0] = sa.slice(); path[path.length - 1] = sb.slice();
    for (let it = 0; it < 2; it++) { const q = [path[0]]; for (let i = 0; i + 1 < path.length; i++) { const a = path[i], b = path[i + 1]; q.push([a[0] * 0.75 + b[0] * 0.25, a[1] * 0.75 + b[1] * 0.25], [a[0] * 0.25 + b[0] * 0.75, a[1] * 0.25 + b[1] * 0.75]); } q.push(path[path.length - 1]); path = q; }
    // assemble the full polyline of directions: gateA -> passA -> (path) -> passB reversed -> gateB
    const dirs = [], push = (v) => dirs.push(v[0], v[1], v[2]);
    const tmp = [0, 0, 0];
    for (const p of pa) { localToDir(A, p[0], p[1], tmp); push(tmp); }
    let acc = 0, last = path[0];
    for (let i = 1; i < path.length; i++) { const p = path[i], seg = Math.hypot(p[0] - last[0], p[1] - last[1]); acc += seg; if (acc >= 70 || i === path.length - 1) { toDir(p[0], p[1], tmp); push(tmp); acc = 0; } last = p; }
    for (let k = pb.length - 1; k >= 0; k--) { localToDir(B, pb[k][0], pb[k][1], tmp); push(tmp); }
    // total ground length
    const pts = new Float32Array(dirs); let len = 0;
    for (let i = 3; i < pts.length; i += 3) len += Math.hypot(pts[i] - pts[i - 3], pts[i + 1] - pts[i - 2], pts[i + 2] - pts[i - 1]) * R;
    return { ok: true, pts, len, expanded, sampled: cache.size, ms: (typeof performance !== 'undefined' ? performance : Date).now() - t0 };
}
// which pairs of sites get a road: nearest neighbours within maxD ground units (each site links to at most 2; every pair once)
export function planRoads(sites, maxD = 100 * 4250) {
    const pairs = [], dist = (a, b) => Math.hypot(a.dir[0] - b.dir[0], a.dir[1] - b.dir[1], a.dir[2] - b.dir[2]) * R, seen = new Set();
    for (const a of sites) {
        const near = sites.filter(b => b !== a && (a.links || []).includes(b.id)).map(b => [dist(a, b), b]).filter(x => x[0] <= maxD).sort((x, y) => x[0] - y[0]).slice(0, 2);
        for (const [d, b] of near) { const k = Math.min(a.id, b.id) + ':' + Math.max(a.id, b.id); if (seen.has(k)) continue; seen.add(k); pairs.push({ a: Math.min(a.id, b.id), b: Math.max(a.id, b.id), dist: d }); }
    }
    return pairs;
}
