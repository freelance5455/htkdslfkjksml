// =====================================================================================
// terrain_core.js - the planet's geology, climate and biomes. Pure maths (no three.js / DOM), shared by
// game.js (the terrain mesh, collision, props) and the chunk workers, so everything always agrees.
//
// v34: TRUE 3D SPHERE GENERATOR. Every landform is now a function of a point on the sphere, P = unit direction * PLANET_R (world
// units), instead of a point on an equirectangular lon/lat map. All noise is 3D simplex sampled at P, so features have the same
// size and shape everywhere (no east-west squeezing toward the poles, no antimeridian, nothing special about the cube seams).
//   * Plates are a jittered Fibonacci set of sites on the sphere (spherical Voronoi). Each plate has an Euler-pole rotation, so
//     the relative velocity (and therefore the collision / rift / shear character) varies smoothly along a boundary.
//   * Hotspot chains and seamounts are lists of points on the sphere (found through a small 3D bucket index).
//   * The coarse height / rainfall cache lives on the six cube-face lattices (bilinear), and the rain-bearing wind is integrated
//     along the sphere (it follows the prevailing wind of the latitude it is passing over).
//   * Climate is still driven by true latitude (asin(P.y / R)): temperature, the three wind belts, zonal rainfall, polar caps.
//
// v59 (STEP 1, tectonic foundations): LAND NOW FOLLOWS THE PLATES. Continental plates sit high, oceanic plates low (soft crust blend), collisions and
// subduction margins thicken the crust, and islands appear only where tectonics supports them: curved island arcs with an outer trench, straight
// rift chains, hotspot chains with an age gradient, thick-crust patches and continental fringes - each with a main / satellite / islet hierarchy.
// See V59_CHANGES.md. (The v43 plate-independent noise continents and the scattered island-chain mask are gone.)
//  1. TECTONICS. The planet is cut into drifting plates. Each plate is continental or oceanic and rotates about its own pole.
//     Along every plate boundary the relative motion decides what is built there:
//       continent x continent  converging -> a collision orogen: huge fold-mountain belt + high plateau (Himalaya/Tibet)
//       ocean under continent  converging -> coastal cordillera of stratovolcanoes + offshore trench (Andes)
//       ocean x ocean          converging -> volcanic island arc + deep trench (Aleutians/Marianas)
//       diverging              -> mid-ocean ridge with rift axis & vents / continental rift valley with shoulders
//       sliding                -> fault trough and shear ridges
//     plus mantle hotspots (island chains of shield volcanoes), seamounts, guyots, oceanic plateaus and the
//     ancient eroded ranges of continental interiors. Mountain flanks use erosion-damped ridged noise so ridges
//     fork into drainage-like valleys instead of reading as uniform bumps.
//  2. CLIMATE. Temperature falls with latitude and altitude. Rainfall comes from a real moisture-transport
//     model: air blows along the prevailing wind of its latitude (trades / westerlies / polar easterlies),
//     re-charges over ocean, dries over land, and is wrung out when forced up a mountain (windward rain) and
//     arrives parched on the lee side (true continental rain shadow). Computed on a cached coarse grid.
//  3. BIOMES. ~80 biomes chosen from temperature, rainfall, altitude, relief, geology and ocean setting.
//
// API (all positions are P = (X, Y, Z) on the sphere of radius PLANET_R, e.g. unit direction from chartToGeo() * PLANET_R):
//   sample3 / sampleSmooth3 / microAt3 / classify3 / warm3 / rainAt3 / wetness3 / isHostile3
// =====================================================================================
import { PLANET_C, PLANET_R, CHART_HALF, FACE_COUNT, chartToGeo, geoToChart, faceOfGeo } from './planet_core.js';

export const MAX_MOUNTAIN_HEIGHT = 13000;   // v93: was 10500
export const WATER_LEVEL = 0;

// ---------------------------------------------------------------- noise (simplex 2D kept for legacy callers; 3D with analytic gradient) ----
const F2 = 0.5 * (Math.sqrt(3.0) - 1.0), G2 = (3.0 - Math.sqrt(3.0)) / 6.0;
const F3 = 1 / 3, G3 = 1 / 6, N3_SCALE = 33.1;   // 33.1 makes the 3D noise's standard deviation equal the old 2D noise's (0.443), so every threshold keeps its meaning
const grad3 = new Float32Array([1,1,0, -1,1,0, 1,-1,0, -1,-1,0, 1,0,1, -1,0,1, 1,0,-1, -1,0,-1, 0,1,1, 0,-1,1, 0,1,-1, 0,-1,-1]);
function mulberry32(seed) {
    return function() {
        seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
        let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
        t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
}
class Noise {
    constructor(seed) {
        const random = mulberry32(seed);
        this.perm = new Uint8Array(512); this.pm12 = new Uint8Array(512);
        const p = new Uint8Array(256); for (let i = 0; i < 256; i++) p[i] = Math.floor(random() * 256);
        for (let i = 0; i < 512; i++) { this.perm[i] = p[i & 255]; this.pm12[i] = this.perm[i] % 12; }
        this.gx = 0; this.gy = 0; this.gz = 0; // gradient written by nd3()
    }
    // 2D value (legacy / unused by the sphere generator)
    n(xin, yin) {
        const pm = this.pm12, perm = this.perm;
        let n0 = 0, n1 = 0, n2 = 0; const s = (xin + yin) * F2;
        const i = Math.floor(xin + s), j = Math.floor(yin + s); const t = (i + j) * G2;
        const x0 = xin - (i - t), y0 = yin - (j - t);
        const i1 = x0 > y0 ? 1 : 0, j1 = x0 > y0 ? 0 : 1;
        const x1 = x0 - i1 + G2, y1 = y0 - j1 + G2, x2 = x0 - 1.0 + 2.0 * G2, y2 = y0 - 1.0 + 2.0 * G2;
        const ii = i & 255, jj = j & 255;
        let t0 = 0.5 - x0 * x0 - y0 * y0; if (t0 > 0) { t0 *= t0; const g = pm[ii + perm[jj]] * 3; n0 = t0 * t0 * (grad3[g] * x0 + grad3[g + 1] * y0); }
        let t1 = 0.5 - x1 * x1 - y1 * y1; if (t1 > 0) { t1 *= t1; const g = pm[ii + i1 + perm[jj + j1]] * 3; n1 = t1 * t1 * (grad3[g] * x1 + grad3[g + 1] * y1); }
        let t2 = 0.5 - x2 * x2 - y2 * y2; if (t2 > 0) { t2 *= t2; const g = pm[ii + 1 + perm[jj + 1]] * 3; n2 = t2 * t2 * (grad3[g] * x2 + grad3[g + 1] * y2); }
        return 70.0 * (n0 + n1 + n2);
    }
    // 3D value
    n3(xin, yin, zin) {
        const pm = this.pm12, perm = this.perm;
        const s = (xin + yin + zin) * F3;
        const i = Math.floor(xin + s), j = Math.floor(yin + s), k = Math.floor(zin + s);
        const t = (i + j + k) * G3;
        const x0 = xin - (i - t), y0 = yin - (j - t), z0 = zin - (k - t);
        let i1, j1, k1, i2, j2, k2;
        if (x0 >= y0) {
            if (y0 >= z0) { i1 = 1; j1 = 0; k1 = 0; i2 = 1; j2 = 1; k2 = 0; }
            else if (x0 >= z0) { i1 = 1; j1 = 0; k1 = 0; i2 = 1; j2 = 0; k2 = 1; }
            else { i1 = 0; j1 = 0; k1 = 1; i2 = 1; j2 = 0; k2 = 1; }
        } else {
            if (y0 < z0) { i1 = 0; j1 = 0; k1 = 1; i2 = 0; j2 = 1; k2 = 1; }
            else if (x0 < z0) { i1 = 0; j1 = 1; k1 = 0; i2 = 0; j2 = 1; k2 = 1; }
            else { i1 = 0; j1 = 1; k1 = 0; i2 = 1; j2 = 1; k2 = 0; }
        }
        const x1 = x0 - i1 + G3, y1 = y0 - j1 + G3, z1 = z0 - k1 + G3;
        const x2 = x0 - i2 + 2 * G3, y2 = y0 - j2 + 2 * G3, z2 = z0 - k2 + 2 * G3;
        const x3 = x0 - 1 + 3 * G3, y3 = y0 - 1 + 3 * G3, z3 = z0 - 1 + 3 * G3;
        const ii = i & 255, jj = j & 255, kk = k & 255;
        let n = 0;
        let tt = 0.6 - x0 * x0 - y0 * y0 - z0 * z0;
        if (tt > 0) { tt *= tt; const g = pm[ii + perm[jj + perm[kk]]] * 3; n += tt * tt * (grad3[g] * x0 + grad3[g + 1] * y0 + grad3[g + 2] * z0); }
        tt = 0.6 - x1 * x1 - y1 * y1 - z1 * z1;
        if (tt > 0) { tt *= tt; const g = pm[ii + i1 + perm[jj + j1 + perm[kk + k1]]] * 3; n += tt * tt * (grad3[g] * x1 + grad3[g + 1] * y1 + grad3[g + 2] * z1); }
        tt = 0.6 - x2 * x2 - y2 * y2 - z2 * z2;
        if (tt > 0) { tt *= tt; const g = pm[ii + i2 + perm[jj + j2 + perm[kk + k2]]] * 3; n += tt * tt * (grad3[g] * x2 + grad3[g + 1] * y2 + grad3[g + 2] * z2); }
        tt = 0.6 - x3 * x3 - y3 * y3 - z3 * z3;
        if (tt > 0) { tt *= tt; const g = pm[ii + 1 + perm[jj + 1 + perm[kk + 1]]] * 3; n += tt * tt * (grad3[g] * x3 + grad3[g + 1] * y3 + grad3[g + 2] * z3); }
        return N3_SCALE * n;
    }
    // 3D value + gradient (this.gx / gy / gz, derivative with respect to the arguments)
    nd3(xin, yin, zin) {
        const pm = this.pm12, perm = this.perm;
        const s = (xin + yin + zin) * F3;
        const i = Math.floor(xin + s), j = Math.floor(yin + s), k = Math.floor(zin + s);
        const t = (i + j + k) * G3;
        const x0 = xin - (i - t), y0 = yin - (j - t), z0 = zin - (k - t);
        let i1, j1, k1, i2, j2, k2;
        if (x0 >= y0) {
            if (y0 >= z0) { i1 = 1; j1 = 0; k1 = 0; i2 = 1; j2 = 1; k2 = 0; }
            else if (x0 >= z0) { i1 = 1; j1 = 0; k1 = 0; i2 = 1; j2 = 0; k2 = 1; }
            else { i1 = 0; j1 = 0; k1 = 1; i2 = 1; j2 = 0; k2 = 1; }
        } else {
            if (y0 < z0) { i1 = 0; j1 = 0; k1 = 1; i2 = 0; j2 = 1; k2 = 1; }
            else if (x0 < z0) { i1 = 0; j1 = 1; k1 = 0; i2 = 0; j2 = 1; k2 = 1; }
            else { i1 = 0; j1 = 1; k1 = 0; i2 = 1; j2 = 1; k2 = 0; }
        }
        const ii = i & 255, jj = j & 255, kk = k & 255;
        let n = 0, dx = 0, dy = 0, dz = 0;
        for (let c = 0; c < 4; c++) {
            let x, y, z, g;
            if (c === 0) { x = x0; y = y0; z = z0; g = pm[ii + perm[jj + perm[kk]]] * 3; }
            else if (c === 1) { x = x0 - i1 + G3; y = y0 - j1 + G3; z = z0 - k1 + G3; g = pm[ii + i1 + perm[jj + j1 + perm[kk + k1]]] * 3; }
            else if (c === 2) { x = x0 - i2 + 2 * G3; y = y0 - j2 + 2 * G3; z = z0 - k2 + 2 * G3; g = pm[ii + i2 + perm[jj + j2 + perm[kk + k2]]] * 3; }
            else { x = x0 - 1 + 3 * G3; y = y0 - 1 + 3 * G3; z = z0 - 1 + 3 * G3; g = pm[ii + 1 + perm[jj + 1 + perm[kk + 1]]] * 3; }
            const tt = 0.6 - x * x - y * y - z * z; if (tt <= 0) continue;
            const gd = grad3[g] * x + grad3[g + 1] * y + grad3[g + 2] * z, t2 = tt * tt, t4 = t2 * t2, m = -8 * tt * t2 * gd;
            n += t4 * gd;
            dx += t4 * grad3[g] + m * x; dy += t4 * grad3[g + 1] + m * y; dz += t4 * grad3[g + 2] + m * z;
        }
        this.gx = N3_SCALE * dx; this.gy = N3_SCALE * dy; this.gz = N3_SCALE * dz;
        return N3_SCALE * n;
    }
}
const ss = (a, b, x) => { let t = (x - a) / (b - a); t = t < 0 ? 0 : t > 1 ? 1 : t; return t * t * (3 - 2 * t); };
const clamp = (x, a, b) => x < a ? a : x > b ? b : x;
const mix = (a, b, t) => a + (b - a) * t;
function capLift(t, cap) { const k = cap * 0.6; return t <= k ? t : k + (cap - k) * (1 - Math.exp(-(t - k) / (cap - k))); }   // a lifted value approaches `cap` smoothly (never lowers anything below it)
function softCap(x, cap, kf = 0.9) { const knee = cap * kf; if (x <= knee) return x; const r = cap - knee; return knee + r * (1 - Math.exp(-(x - knee) / r)); }

// ---------------------------------------------------------------- biome table ----
// [name, texture class, propId, colour, footstep]
// texture classes (terrain shader): 0 grass, 1 sand/dry earth, 2 rock strata, 3 snow/ice, 4 mossy wetland, 5 forest litter, 6 facet/crystal, 7 sediment
// propIds: 0 none, 1 pine, 2 plains trees+flowers, 3 desert, 4 swamp, 5 kelp, 6 crystal, 7 ice spikes, 8 savannah, 9 jungle, 10 vents,
//          11 mixed forest, 12 subalpine, 13 alpine meadow, 14 tundra shrub, 15 steppe, 16 mediterranean, 17 barren rock, 18 rainforest(temperate), 19 seagrass, 20 reef
export const BIOMES = [];
export const B = {};
function def(key, name, cls, prop, hex, foot, crystal) { B[key] = BIOMES.length; BIOMES.push({ id: BIOMES.length, key, name, cls, prop, hex, foot: foot || 'grass', crystal: crystal || null }); }
// --- ocean
def('ABYSSAL', 'ABYSSAL OCEAN', 7, 0, 0x4a4238, 'sand');
def('SHELF', 'COASTAL SHELF', 1, 5, 0xd6c093, 'sand');
def('VENT', 'HYDROTHERMAL VENT FIELD', 2, 10, 0x241a16, 'stone');
def('REEF', 'TROPICAL CORAL REEF', 6, 20, 0xdcc48f, 'sand');
def('SEA_VOLCANO', 'MID-SEA VOLCANO', 2, 0, 0x2b2623, 'stone');
def('KELP', 'KELP FOREST', 2, 5, 0x5a5a3c, 'stone');
def('SEAGRASS', 'SEAGRASS MEADOW', 1, 19, 0xb7b384, 'sand');
def('ROCKY_REEF', 'ROCKY REEF', 2, 5, 0x6c6558, 'stone');
def('POLAR_SHELF', 'POLAR SHELF', 7, 0, 0x8d9aa0, 'snow');
def('SLOPE', 'CONTINENTAL SLOPE', 7, 0, 0x7a6e5a, 'sand');
def('CANYON_SUB', 'SUBMARINE CANYON', 2, 0, 0x4c433a, 'stone');
def('SEEP', 'COLD SEEP BRINE POOLS', 7, 0, 0x2b3a3a, 'mud');
def('HILLS_SEA', 'ABYSSAL HILLS', 7, 0, 0x57493c, 'sand');
def('SEAMOUNT', 'SEAMOUNT', 2, 0, 0x3a332c, 'stone');
def('GUYOT', 'GUYOT PLATEAU', 2, 0, 0x6a6150, 'stone');
def('ATOLL', 'ATOLL REEF', 6, 20, 0xe6d6a8, 'sand');
def('RIDGE', 'MID-OCEAN RIDGE', 2, 0, 0x2e2622, 'stone');
def('RIFT_SEA', 'OCEAN RIFT VALLEY', 2, 10, 0x1d1613, 'stone');
def('TRENCH', 'HADAL TRENCH', 7, 0, 0x211c19, 'mud');
def('OC_PLATEAU', 'OCEANIC PLATEAU', 7, 0, 0x6d5f4c, 'sand');
def('ARC_SEA', 'SUBMARINE ARC VOLCANOES', 2, 10, 0x2a2420, 'stone');
def('SARGASSO', 'DEEP BASIN OOZE', 7, 0, 0x5d5547, 'mud');
// --- coast
def('SANDY_SHORE', 'SANDY SHORE', 1, 0, 0xe0d2a3, 'sand');
def('DELTA', 'MUDDY DELTA', 4, 0, 0x384a22, 'mud');
def('MANGROVE', 'MANGROVE COAST', 4, 4, 0x3a4a2a, 'mud');
def('SALT_MARSH', 'SALT MARSH', 4, 4, 0x6a7a45, 'mud');
def('ROCKY_SHORE', 'ROCKY SHORE', 2, 0, 0x6f6a60, 'stone');
def('FROZEN_COAST', 'FROZEN COAST', 3, 7, 0xdce8ee, 'snow');
def('TIDAL_FLATS', 'TIDAL MUD FLATS', 7, 0, 0x7d6f55, 'mud');
// --- hot lowlands
def('JUNGLE', 'DENSE JUNGLE', 4, 9, 0x12982f, 'mud');
def('SEASONAL', 'MONSOON FOREST', 4, 9, 0x4f9a2e, 'grass');
def('WOOD_SAV', 'WOODED SAVANNAH', 0, 8, 0xa9b042, 'sand');
def('SAVANNAH', 'ARID SAVANNAH', 1, 8, 0xd9b05a, 'sand', 'silicon');
def('THORN', 'THORN SCRUB', 1, 8, 0xb59a4e, 'sand');
def('DESERT_SCRUB', 'DESERT SCRUB', 1, 3, 0xc2a566, 'sand', 'silicon');
def('DUNES', 'SAND DUNES', 1, 3, 0xdcbb7e, 'sand', 'silicon');
def('HAMADA', 'ROCKY DESERT', 2, 3, 0xa88a62, 'stone', 'silicon');
def('SALT_FLATS', 'SALT FLATS', 1, 0, 0xe9e6dc, 'sand');
def('BADLANDS', 'TERRACED BADLANDS', 2, 3, 0xc9915a, 'stone', 'silicon');
def('MESAS', 'MESA COUNTRY', 2, 3, 0xb5703f, 'stone', 'silicon');
def('SPIRES', 'CRYSTAL SPIRES', 6, 6, 0x7ecbd6, 'stone');
def('KARST', 'KARST TOWERS', 4, 9, 0x4d7a45, 'stone');
def('SWAMP', 'MURKY SWAMP', 4, 4, 0x3a2e1c, 'mud');
def('FLOODPLAIN', 'FLOODPLAIN MARSH', 4, 4, 0x55703a, 'mud');
// --- temperate
def('PLAINS', 'LUSH PLAINS', 0, 2, 0x66b83c, 'grass', 'fluorite');
def('MIXED', 'MIXED WOODLAND', 5, 11, 0x3d7a3a, 'grass');
def('DECIDUOUS', 'DECIDUOUS FOREST', 5, 2, 0x4f8a34, 'grass');
def('TEMP_RAIN', 'TEMPERATE RAINFOREST', 5, 18, 0x1f6a38, 'mud');
def('SUBTROP_FOREST', 'SUBTROPICAL FOREST', 4, 9, 0x2f8a3a, 'grass');
def('MEDITERR', 'MEDITERRANEAN SCRUB', 1, 16, 0x9a9c52, 'sand');
def('STEPPE', 'DRY STEPPE', 1, 15, 0xb5ab62, 'sand');
def('SCRUBLAND', 'SCRUBLAND', 1, 8, 0x9aa05a, 'sand');
def('HEATH', 'WINDSWEPT MOORLAND', 0, 14, 0x7f7a52, 'grass');
def('COLD_DESERT', 'COLD DESERT', 1, 3, 0xb9a98a, 'stone');
def('RAINSHADOW', 'RAIN-SHADOW DESERT', 1, 3, 0xc7a874, 'sand', 'silicon');
// --- cold lowlands
def('TAIGA', 'BOREAL TAIGA', 5, 1, 0x2a6a3a, 'grass');
def('LARCH', 'LARCH WOODLAND', 5, 1, 0x7a8f4a, 'grass');
def('MUSKEG', 'MUSKEG BOG', 4, 4, 0x4a4a30, 'mud');
def('COLD_STEPPE', 'COLD STEPPE', 1, 15, 0xa7a68c, 'grass');
def('TUNDRA', 'FROZEN TUNDRA', 3, 7, 0xe3f2f7, 'snow');
def('ARCTIC', 'ARCTIC SHRUB TUNDRA', 3, 14, 0x8fa8ac, 'snow');
def('POLAR_DESERT', 'POLAR DESERT', 3, 0, 0xcdd6da, 'snow');
def('ICE_SHEET', 'ICE SHEET', 3, 0, 0xf0f6fa, 'snow');
// --- mountains & high ground
def('FOOTHILLS', 'FOOTHILL WOODLAND', 5, 11, 0x5a7a40, 'grass');
def('MONTANE', 'MONTANE FOREST', 5, 12, 0x2f6a40, 'grass');
def('CLOUD', 'CLOUD FOREST', 4, 9, 0x2a7a52, 'mud');
def('SUBALPINE', 'SUBALPINE FOREST', 5, 12, 0x2c5a40, 'grass');
def('ALPINE_MEADOW', 'ALPINE MEADOW', 0, 13, 0x6f9a52, 'grass');
def('ALPINE_TUNDRA', 'ALPINE TUNDRA', 3, 14, 0x8a8a70, 'stone');
def('ALPINE', 'ALPINE HIGHLANDS', 2, 0, 0x4a4845, 'stone', 'piezo');
def('GRANITE', 'GRANITE DOMES', 2, 0, 0x6a6864, 'stone', 'piezo');
def('SCREE', 'SCREE SLOPES', 2, 17, 0x5e5a54, 'stone', 'piezo');
def('CRAGS', 'JAGGED CRAGS', 2, 17, 0x403d3b, 'stone', 'piezo');
def('SNOW_PEAKS', 'CELESTIAL SNOW PEAKS', 3, 0, 0xf0f4f8, 'snow');
def('GLACIER', 'GLACIER FIELDS', 3, 0, 0xcfe6f0, 'snow');
def('PLATEAU', 'HIGH PLATEAU STEPPE', 1, 15, 0xb8a878, 'sand');
def('ALTIPLANO', 'SALT-PAN ALTIPLANO', 1, 0, 0xdad2c0, 'sand');
def('PLATEAU_COLD', 'FROZEN PLATEAU DESERT', 3, 0, 0xb4b8b8, 'snow');
def('RIFT', 'RIFT VALLEY FLOOR', 1, 8, 0xb89a62, 'sand');
def('ENCHANTED_VALLEY', 'ENCHANTED HIDDEN VALLEY', 0, 2, 0x4fd08a, 'grass', 'fluorite');
def('RIFT_WALL', 'RIFT ESCARPMENT', 2, 17, 0x8a6a4a, 'stone');
// --- volcanic
def('VOLCANO', 'DORMANT VOLCANO', 2, 0, 0x2b2927, 'stone');
def('LAVA', 'LAVA FIELDS', 2, 17, 0x1f1c1b, 'stone');
def('VOLC_HIGH', 'VOLCANIC HIGHLANDS', 2, 12, 0x3a3532, 'stone');
def('ASH', 'ASH PLAINS', 1, 14, 0x6a625a, 'sand');
def('FUMAROLE', 'FUMAROLE FIELDS', 2, 17, 0x9a8f58, 'stone');
def('VOLC_ISLAND', 'VOLCANIC ISLAND', 4, 9, 0x2f5a30, 'grass');
export const BIOME_BY_NAME = new Map(BIOMES.map(b => [b.name, b]));
const hexRGB = (h) => [((h >> 16) & 255) / 255, ((h >> 8) & 255) / 255, (h & 255) / 255];
for (const b of BIOMES) b.rgb = hexRGB(b.hex);

// ---------------------------------------------------------------- climate colour table ----
// [temperature C, rainfall mm/yr, colour]: blended continuously so lowland colour never snaps at a biome border
const CLIM_ANCHORS = [
    [-26, 40, 0xe4ecf0], [-26, 600, 0xf2f7fa], [-12, 120, 0xb2bdc0], [-10, 500, 0x86a082], [-4, 250, 0x93a07e],
    [-2, 800, 0x2e5c3c], [1, 1400, 0x27523a], [5, 200, 0xb3a58a], [6, 450, 0xa8a46a], [8, 750, 0x78a84a],
    [9, 1200, 0x3f7c3c], [9, 2600, 0x206a3a], [15, 150, 0xc2ae7c], [16, 450, 0x9a9c52], [16, 850, 0x68a63e],
    [18, 1800, 0x2f8a3a], [24, 60, 0xd9b46a], [32, 40, 0xe2c276], [20, 300, 0xb8a35c], [27, 500, 0xc9ad55],
    [27, 900, 0xa9b042], [27, 1500, 0x4f9a2e], [27, 2800, 0x138a2c]
];
const LUT_N = 40, LUT_T0 = -30, LUT_T1 = 36, LUT = new Float32Array(LUT_N * LUT_N * 3);
(function buildLUT() {
    const A = CLIM_ANCHORS.map(a => [a[0], a[1], hexRGB(a[2])]);
    for (let it = 0; it < LUT_N; it++) for (let ip = 0; ip < LUT_N; ip++) {
        const T = LUT_T0 + (LUT_T1 - LUT_T0) * it / (LUT_N - 1), u = ip / (LUT_N - 1), P = 3500 * u * u;
        let r = 0, g = 0, b = 0, ws = 0;
        for (const a of A) {
            const dt = (T - a[0]) / 14, dp = (Math.sqrt(P / 3500) - Math.sqrt(a[1] / 3500)) / 0.28;
            const w = 1 / (0.02 + dt * dt + dp * dp) ** 2; r += a[2][0] * w; g += a[2][1] * w; b += a[2][2] * w; ws += w;
        }
        const o = (it * LUT_N + ip) * 3; LUT[o] = r / ws; LUT[o + 1] = g / ws; LUT[o + 2] = b / ws;
    }
})();
function lutColor(T, P, out) {
    const ft = clamp((T - LUT_T0) / (LUT_T1 - LUT_T0), 0, 1) * (LUT_N - 1), fp = clamp(Math.sqrt(P / 3500), 0, 1) * (LUT_N - 1);
    const i0 = Math.min(LUT_N - 2, Math.floor(ft)), j0 = Math.min(LUT_N - 2, Math.floor(fp)), a = ft - i0, b = fp - j0;
    for (let c = 0; c < 3; c++) {
        const v00 = LUT[(i0 * LUT_N + j0) * 3 + c], v01 = LUT[(i0 * LUT_N + j0 + 1) * 3 + c], v10 = LUT[((i0 + 1) * LUT_N + j0) * 3 + c], v11 = LUT[((i0 + 1) * LUT_N + j0 + 1) * 3 + c];
        out[c] = (v00 * (1 - b) + v01 * b) * (1 - a) + (v10 * (1 - b) + v11 * b) * a;
    }
}


// ---------------------------------------------------------------- sphere / plate / cache constants ----
const R = PLANET_R;
// ---- WORLD-SHAPE TUNING (v35) ----
const CONT_FRAC = 0.36;            // fraction of plates that are continental (v34: 0.47) -> archipelago world
const COAST_ROUGH = 0.50;          // weight of the fbm coastline noise in continentalness (v34: 0.36) -> broken, island-studded coasts
const SEA_BIAS = 0.0;               // continentalness threshold (v34: 0.68)
const HOTSPOT_DENSITY = 0.26;      // volcanic island chains per 88k-unit cell (v34: 0.20, v35: 0.55)
const UPLIFT_SCALE = 0.68;         // overall mountain height scale (v34: 1.0, v35: 0.60)
// ---- v37 LANDMASS MODEL: many small, elongated, chain-like landmasses, each with a mountain spine down its middle ----
const SPINE_SITES = 215;           // jittered Fibonacci sites; each (if not gated out by the ocean-basin noise) starts one landmass chain
const SPINE_KEEP = 0.95;           // fraction of sites that spawn a chain (the rest leave open ocean)
const SPINE_STEP = 5200;           // spacing of the discs that make up a chain (units)
const SPINE_UPLIFT = 2500;         // mountain-spine uplift (units, before UPLIFT_SCALE)
const LAND_THRESH = 0.32;          // landness needed (plus coast noise) to be above water
const TECT_UPLIFT = 0.45;          // share of the plate-boundary uplift that is kept (the chains + their spines now carry most of the mountains)
const CLUSTER_FRAC = 0.55;         // v39: share of landmass sites that become an archipelago cluster instead of a chain
const VALLEY_T = 0.77;             // v39: hidden-valley field threshold (lower = more valleys)
const SPINE_NARROW = 2.2;          // v39: >1 narrows the mountain spine down the middle of each landmass (lowlands appear beside it)
const FOOT_EXP = 1.3;              // v39: >1 = gentle foothills that steepen toward the crest
const RIDGE_OCTS = 5;                // ridged-noise octaves at full detail (v34: 8) - fewer high-frequency octaves = rounder, smoother slopes
const MTN_SPAN = 0.5;              // v46: horizontal scale of mountain ridges (<1 = wider, longer ridges and broader massifs; same height, so gentler slopes)
// ---- v43: V15-STYLE CONTINENTS ----
const CONT_FREQ = 0.000014;        // continent noise frequency (per world unit) - identical to the old flat-map generator
const CONT_BIAS = 0.17;            // pushes the field toward ocean (V15: 0.16) -> ~30% land
const LAND_RISE = 1900, LAND_SWELL = 1400;   // interior elevation curve (see base height)
const RANGE_UPLIFT = 1400;         // height of the inland mountain belts (before UPLIFT_SCALE / foothill curve)
const LAND_TECT_DAMP = 0.65;       // share of plate-boundary uplift removed on land
const HILL_AMP = 400;              // rolling-hill amplitude on land (V15: ~420 at 0.00011)
// v60 rain shadows: forced ascent over the new boundary ridges now squeezes out more rain on the windward side and strips more moisture from the air
// (the moist air that arrives is what the lee side then lacks), so the far side of a range is drier. Global land rainfall moves only ~4%.
const OROG_K = 10, OROG_DEP = 0.70, OROG_MULT = 5000, RAIN_A = 0.4, RAIN_B = 1.7;   // (v59: 5.0, 0.55, 2600, 0.5, 1.7)
const RELIEF_CAP = 7200;           // v93: was 2400 (v60). Relief (height of mountains above the surrounding ground) now tops out around 5.6k units (~1.3 km real: 4.25 units = 1 m)
const PEAK_GAIN = 2.3;             // v93: extra growth of HIGH relief only (foothills untouched), so the tallest massifs tower over ordinary ranges
const RELIEF_KNEE = 0.80;          // v93: share of RELIEF_CAP where the soft cap starts to squeeze (was 0.78)
const RIDGE_REACH = 125000;        // v60: boundary ridges are only evaluated this close to a plate boundary
const HOT_K = 9, HOT_DX = 17000;   // v59: volcanoes per hotspot chain / spacing (older ones drown, so only the young end of the chain is land)
// ---- v59 TECTONIC LAND MODEL: land follows the plates ----
const CRUST_SW = 22000;            // soft-Voronoi width of the crust blend between plates (units)
const ARC_L = 62000;               // half-length scale over which an island arc curves away from its trench
const ISLE_AMP = 1.15;             // how far the island bump lifts continentalness (ocean floor is about -0.5)
const LAND_BIAS = 0.14;              // global sea-level nudge for the tectonic land model (+ = less land)
const NOISE_CONT = 0.27;           // organic variance of continentalness inside continental plates (oceanic plates get about a fifth of it)
const CELL = PLANET_C / 10;                                       // nominal plate size (175,000 units): continent radii are expressed in it
const N_PLATES = 32;                                              // ~ sphere area / CELL^2
const GRID_TARGET = 5000;                                         // coarse cache node spacing (units)
const NI = Math.round(2 * CHART_HALF / GRID_TARGET);              // lattice intervals across one cube face (88)
const GS = 2 * CHART_HALF / NI;                                   // actual node spacing (~4970)
const GM = 2;                                                     // margin nodes beyond each face edge (so bilinear lookups never leave the lattice)
const TILE = 14;                                                  // 14 x 14 node tiles
const NTILE = Math.ceil((NI + 1 + 2 * GM) / TILE);                // tiles per face side (7)
const NODES = NTILE * TILE;
const TWO_PI = Math.PI * 2;
const SPHERE_AREA = 4 * Math.PI * R * R;

function rotAbout(v, k, ang) { // Rodrigues rotation of v about unit axis k
    const c = Math.cos(ang), s = Math.sin(ang), kd = k[0] * v[0] + k[1] * v[1] + k[2] * v[2];
    const kx = [k[1] * v[2] - k[2] * v[1], k[2] * v[0] - k[0] * v[2], k[0] * v[1] - k[1] * v[0]];
    return [v[0] * c + kx[0] * s + k[0] * kd * (1 - c), v[1] * c + kx[1] * s + k[1] * kd * (1 - c), v[2] * c + kx[2] * s + k[2] * kd * (1 - c)];
}
function unit(v) { const l = Math.hypot(v[0], v[1], v[2]) || 1; return [v[0] / l, v[1] / l, v[2] / l]; }
function tangentBasis(d) { // two unit vectors perpendicular to unit d (and to each other)
    const a = Math.abs(d[1]) < 0.9 ? [0, 1, 0] : [1, 0, 0];
    const t1 = unit([a[1] * d[2] - a[2] * d[1], a[2] * d[0] - a[0] * d[2], a[0] * d[1] - a[1] * d[0]]);
    const t2 = [d[1] * t1[2] - d[2] * t1[1], d[2] * t1[0] - d[0] * t1[2], d[0] * t1[1] - d[1] * t1[0]];
    return [t1, t2];
}
// moisture-march sample distances (units upwind of the node), exactly the schedule the old equirectangular code used: 23 steps
const MARCH_D = [], MARCH_DL = [];
{ let dist = 10000 * 15 + 5000 * 8 + 1; for (let k = 0; k < 23; k++) { const dl = dist > 40000 ? 10000 : 5000; dist -= dl; if (dist < 0) dist = 0; MARCH_D.push(dist); MARCH_DL.push(dl); } }

// small 3D bucket index of points on the sphere (used for seamounts): cell size cs >= the largest feature radius
class SphereIndex {
    constructor(pts, cs) {
        this.cs = cs; this.cells = new Map();
        for (let i = 0; i < pts.length; i++) {
            const p = pts[i], key = this.key(Math.floor(p.x / cs), Math.floor(p.y / cs), Math.floor(p.z / cs));
            let l = this.cells.get(key); if (!l) this.cells.set(key, l = []); l.push(p);
        }
    }
    key(i, j, k) { return ((i + 64) * 256 + (j + 64)) * 256 + (k + 64); }
    // calls f(point) for every point in the 27 buckets around P
    each(X, Y, Z, f) {
        const cs = this.cs, i0 = Math.floor(X / cs), j0 = Math.floor(Y / cs), k0 = Math.floor(Z / cs);
        for (let a = -1; a <= 1; a++) for (let b = -1; b <= 1; b++) for (let c = -1; c <= 1; c++) {
            const l = this.cells.get(this.key(i0 + a, j0 + b, k0 + c)); if (!l) continue;
            for (let n = 0; n < l.length; n++) f(l[n]);
        }
    }
}

export class TerrainCore {
    constructor(seed) {
        this.seed = seed >>> 0;
        this.nz = new Noise(this.seed);
        this.tiles = new Array(FACE_COUNT * NTILE * NTILE).fill(null);
        this._tw = new Float64Array(4); this._sx = new Float64Array(9); this._dd = new Float64Array(9); this._pl = new Array(9);
        this._rgo = { crest: 0, mass: 0 }; this._c = { x: 0, z: 0 }; this._g = [0, 0, 0]; this._tmp = {};
        this._path = new Float64Array(24 * 3); this._sv = new Float64Array(8); this._sa = new Float64Array(8);
        this._buildPlates(); this._buildHotspots(); this._buildSeamounts(); this._buildJets();
        this.cnt = { hot: 0 };
    }
    hash(a, b, s) {
        let h = (Math.imul(a | 0, 374761393) + Math.imul(b | 0, 668265263) + Math.imul(s | 0, 1274126177) + this.seed) | 0;
        h = Math.imul(h ^ (h >>> 13), 1274126177); h ^= h >>> 16; h = Math.imul(h, 2246822519); h ^= h >>> 15;
        return (h >>> 0) / 4294967296;
    }
    // noise at P*f with a per-call translation (a, b) so every call is an independent field
    N(X, Y, Z, f, a, b) { return this.nz.n3(X * f + a, Y * f + (a + b) * 0.5 + 3.17, Z * f + b); }

    // ------------------------------------------------------------ sites on the sphere ----
    _randomUnit(i, salt) { const z = 1 - 2 * this.hash(i, 31, salt), a = TWO_PI * this.hash(i, 37, salt), r = Math.sqrt(Math.max(0, 1 - z * z)); return [r * Math.cos(a), z, r * Math.sin(a)]; }
    // PLATES: a randomly oriented, jittered Fibonacci lattice of N_PLATES sites on the sphere, each with an Euler pole
    _buildPlates() {
        const h = (i, s) => this.hash(i, 7919, 100 + s);
        const axis = this._randomUnit(0, 900), spin = TWO_PI * this.hash(0, 1, 901), golden = Math.PI * (3 - Math.sqrt(5));
        const spacing = Math.sqrt(4 * Math.PI / N_PLATES);
        // exactly CONT_FRAC of the plates are continental (ranked by a hash) so no seed is all ocean / all land
        const order = Array.from({ length: N_PLATES }, (_, i) => i).sort((a, b) => h(a, 1) - h(b, 1));
        // v59: continental plates are DISPERSED (a greedy pick that skips neighbours of already chosen ones for the first ~70%), so the land comes as
        // several separate continents / micro-continents with real ocean basins between them instead of one clumped supercontinent. The rest are random,
        // which still leaves the occasional pair of neighbouring continents that collide.
        const nCont = Math.round(CONT_FRAC * N_PLATES), contSet = new Set(), site = [];
        for (let i = 0; i < N_PLATES; i++) { const y = 1 - 2 * (i + 0.5) / N_PLATES, rr = Math.sqrt(1 - y * y), th = i * golden; site.push(rotAbout([rr * Math.cos(th), y, rr * Math.sin(th)], axis, spin)); }
        for (const i of order) {
            if (contSet.size >= Math.round(nCont * 0.7)) break;
            let ok = true; for (const j of contSet) { const dd = site[i][0] * site[j][0] + site[i][1] * site[j][1] + site[i][2] * site[j][2]; if (Math.acos(Math.max(-1, Math.min(1, dd))) < 1.45 * spacing) { ok = false; break; } }
            if (ok) contSet.add(i);
        }
        for (const lim of [1.12, 0.0]) for (const i of order) {   // the last ~30%: still prefer a gap, but accept neighbours (a collision) if nothing else is left
            if (contSet.size >= nCont) break; if (contSet.has(i)) continue;
            let ok = true; for (const j of contSet) { const dd = site[i][0] * site[j][0] + site[i][1] * site[j][1] + site[i][2] * site[j][2]; if (Math.acos(Math.max(-1, Math.min(1, dd))) < lim * spacing) { ok = false; break; } }
            if (ok) contSet.add(i);
        }
        const plates = [];
        for (let i = 0; i < N_PLATES; i++) {
            const y = 1 - 2 * (i + 0.5) / N_PLATES, rr = Math.sqrt(1 - y * y), th = i * golden;
            let d = rotAbout([rr * Math.cos(th), y, rr * Math.sin(th)], axis, spin);
            const [t1, t2] = tangentBasis(d), j1 = (h(i, 5) * 2 - 1) * 0.32 * spacing, j2 = (h(i, 6) * 2 - 1) * 0.32 * spacing;
            d = unit([d[0] + t1[0] * j1 + t2[0] * j2, d[1] + t1[1] * j1 + t2[1] * j2, d[2] + t1[2] * j1 + t2[2] * j2]);
            const cont = contSet.has(i), micro = h(i, 2) < 0.22, spd = 0.35 + 0.65 * h(i, 4), pole = this._randomUnit(i, 902);
            const om = spd * 1.25; // Euler-pole angular speed: speed at 90 deg from the pole ~ spd * 1.25 (the mean over the sphere is ~ 0.8 of that)
            const thick = h(i, 11), crust = cont ? (micro ? -0.17 + 0.17 * thick : -0.09 + 0.24 * thick) : -0.58 + 0.34 * thick;   // v59: thick continental crust sits high, thin oceanic crust sits deep; micro-continents ride low (big islands / shelves)
            const lat01 = Math.abs(d[1]), ag = h(i, 9), rT = h(i, 12);
            // v61 TECTONIC CHARACTER: 0 young/volcanic, 1 old/eroded/flat, 2 karst (warm, wet limestone country), 3 glaciated (high latitudes, some mid)
            const tag = (lat01 > 0.76 && rT < 0.50) ? 3 : ag < 0.34 ? 0 : ag > 0.70 ? 1 : (lat01 < 0.62 && rT < 0.55) ? 2 : (rT > 0.92 && lat01 > 0.55) ? 3 : (rT < 0.5 ? 0 : 1);
            plates.push({ id: i, tag, thick, crust, x: d[0] * R, y: d[1] * R, z: d[2] * R, cont, R: CELL * (cont ? (micro ? 0.20 + 0.08 * h(i, 7) : 0.30 + 0.17 * h(i, 7)) : 0.0),
                          ox: pole[0] * om, oy: pole[1] * om, oz: pole[2] * om, dens: h(i, 8), age: h(i, 9), hard: h(i, 10) });
        }
        this._sites = plates;
    }
    // LANDMASS CHAINS (v37): a jittered Fibonacci set of sites; most of them start a wandering, gently curving chain of overlapping
    // discs (an island arc / peninsula / ridge-spined island). Each disc has a radius (the chain pinches and swells, so it breaks
    // into separate islands where it pinches), and a spine strength (a mountain range runs down the middle of the chain).
    // Some chains sprout a shorter branch (a feather ridge / peninsula). Points are stored in a 3D bucket index.
    _buildLandmasses() {
        const pts = [], H = (a, b, c) => this.hash(a, b, 1300 + c);
        const golden = Math.PI * (3 - Math.sqrt(5)), axis = this._randomUnit(1, 1301), spin = TWO_PI * H(1, 1, 2);
        const spacing = Math.sqrt(4 * Math.PI / SPINE_SITES);
        const nz = this.nz;
        const chain = (c0, head0, len, Wmax, curv, strength, id, depth) => {
            let c = c0, head = head0;
            const steps = Math.max(3, Math.round(len / SPINE_STEP));
            const mids = [];
            let [t1, t2] = tangentBasis(c);
            for (let k = 0; k < steps; k++) {
                const u = k / (steps - 1), taper = Math.pow(Math.sin(Math.PI * (0.06 + 0.88 * u)), 0.55);
                // pearls: radius wobbles smoothly along the chain (and pinches into straits)
                const wob = 0.62 + 0.38 * nz.n3(c[0] * 1.9e-5 * R + id * 11.3, c[1] * 1.9e-5 * R + 4.1, c[2] * 1.9e-5 * R - id * 7.7) * 1.4;
                const r = Math.max(2200, Wmax * taper * Math.max(0.3, Math.min(1.25, wob)));
                const s = strength * (0.55 + 0.45 * taper) * (0.75 + 0.25 * Math.min(1, wob));
                pts.push({ x: c[0] * R, y: c[1] * R, z: c[2] * R, r, s, hb: 0 });
                if (k % 3 === 1) mids.push({ c: c.slice(), head, u });
                // advance along the great circle in direction `head`, then bend
                [t1, t2] = tangentBasis(c);
                const dir = [t1[0] * Math.cos(head) + t2[0] * Math.sin(head), t1[1] * Math.cos(head) + t2[1] * Math.sin(head), t1[2] * Math.cos(head) + t2[2] * Math.sin(head)];
                const ang = SPINE_STEP / R, ca = Math.cos(ang), sa = Math.sin(ang);
                c = unit([c[0] * ca + dir[0] * sa, c[1] * ca + dir[1] * sa, c[2] * ca + dir[2] * sa]);
                head += curv + (H(id * 131 + k, 5, 3) - 0.5) * 0.30;
            }
            if (depth === 0) {   // branches
                for (let m = 0; m < mids.length; m++) {
                    if (H(id * 977 + m, 6, 4) > 0.30) continue;
                    const side = H(id * 977 + m, 7, 5) < 0.5 ? -1 : 1, ang = side * (0.9 + 0.7 * H(id * 977 + m, 8, 6));
                    chain(mids[m].c, mids[m].head + ang, len * (0.25 + 0.3 * H(id * 977 + m, 9, 7)), Wmax * 0.72, curv * -0.5, strength * 0.8, id * 31 + m + 7, 1);
                }
            }
        };
        // v39 ARCHIPELAGO CLUSTERS: a 'hero' island (often with one big peak that rises straight out of the sea), a ring of smaller satellite islands
        // of mixed size scattered at irregular distances, and rocky islets / sea stacks close to shore. Between them the shelf stays shallow (see the
        // wide shelf in _terrain), so channels, lagoons and reefs form instead of every island sitting alone in deep ocean.
        const cluster = (d, i) => {
            const [b1, b2] = tangentBasis(d);
            const at = (dist, ang) => {
                const dir = [b1[0] * Math.cos(ang) + b2[0] * Math.sin(ang), b1[1] * Math.cos(ang) + b2[1] * Math.sin(ang), b1[2] * Math.cos(ang) + b2[2] * Math.sin(ang)];
                const a = dist / R, ca = Math.cos(a), sa = Math.sin(a);
                return unit([d[0] * ca + dir[0] * sa, d[1] * ca + dir[1] * sa, d[2] * ca + dir[2] * sa]);
            };
            const peak = H(i, 31, 20) < 0.45;                                   // a Breakpoint-style island: one big mountain straight out of the sea
            const R0 = (peak ? 10500 : 8500) + 5500 * H(i, 32, 21);
            pts.push({ x: d[0] * R, y: d[1] * R, z: d[2] * R, r: R0, s: peak ? 1.0 : 0.55 + 0.3 * H(i, 33, 22), hb: peak ? 1 : 0 });
            const nSat = 3 + Math.floor(6 * H(i, 34, 23)), a0 = TWO_PI * H(i, 35, 24);
            for (let k = 0; k < nSat; k++) {
                const ang = a0 + k * (TWO_PI / nSat) + (H(i * 53 + k, 36, 25) - 0.5) * 1.1;
                const dist = R0 * (1.35 + 2.2 * H(i * 53 + k, 37, 26));
                const c = at(dist, ang), r = R0 * (0.22 + 0.5 * H(i * 53 + k, 38, 27));
                pts.push({ x: c[0] * R, y: c[1] * R, z: c[2] * R, r, s: 0.35 + 0.5 * H(i * 53 + k, 39, 28), hb: 0 });
                if (H(i * 53 + k, 40, 29) < 0.4) {   // a twin: a smaller island tucked beside it
                    const c2 = at(dist + r * 1.1, ang + (H(i * 53 + k, 41, 30) - 0.5) * 0.4);
                    pts.push({ x: c2[0] * R, y: c2[1] * R, z: c2[2] * R, r: r * 0.5, s: 0.4, hb: 0 });
                }
            }
            const nIs = 3 + Math.floor(5 * H(i, 42, 31));
            for (let k = 0; k < nIs; k++) {      // rocky islets and sea stacks
                const ang = TWO_PI * H(i * 71 + k, 43, 32), dist = R0 * (0.9 + 3.4 * H(i * 71 + k, 44, 33));
                const c = at(dist, ang);
                pts.push({ x: c[0] * R, y: c[1] * R, z: c[2] * R, r: 2300 + 1600 * H(i * 71 + k, 45, 34), s: 0.95, hb: 0 });
            }
        };
        let n = 0;
        for (let i = 0; i < SPINE_SITES; i++) {
            const y = 1 - 2 * (i + 0.5) / SPINE_SITES, rr = Math.sqrt(1 - y * y), th = i * golden;
            let d = rotAbout([rr * Math.cos(th), y, rr * Math.sin(th)], axis, spin);
            const [a1, a2] = tangentBasis(d), j1 = (H(i, 11, 8) * 2 - 1) * 0.5 * spacing, j2 = (H(i, 12, 9) * 2 - 1) * 0.5 * spacing;
            d = unit([d[0] + a1[0] * j1 + a2[0] * j2, d[1] + a1[1] * j1 + a2[1] * j2, d[2] + a1[2] * j1 + a2[2] * j2]);
            // ocean-basin gate: large-scale noise leaves open ocean in some regions and clusters chains (archipelagos) in others
            const gate = nz.n3(d[0] * 3.1 + 17, d[1] * 3.1 + 5, d[2] * 3.1 - 9) * 0.5 + 0.5;
            if (H(i, 13, 10) > SPINE_KEEP * (0.45 + 1.1 * gate)) continue;
            const kind = H(i, 14, 11);
            if (H(i, 46, 35) < CLUSTER_FRAC) { cluster(d, i); n++; continue; }
            // kind: big ranges (rare), medium landmasses, short stubby islands
            let len, Wmax;
            if (kind < 0.18)      { len = 110000 + 70000 * H(i, 15, 12); Wmax = 13000 + 5000 * H(i, 16, 13); }
            else if (kind < 0.62) { len = 55000 + 55000 * H(i, 15, 12);  Wmax = 10500 + 4500 * H(i, 16, 13); }
            else                  { len = 20000 + 30000 * H(i, 15, 12);  Wmax = 7000 + 4000 * H(i, 16, 13); }
            const curv = (H(i, 17, 14) - 0.5) * 0.16, strength = 0.45 + 0.55 * H(i, 18, 15), head = TWO_PI * H(i, 19, 16);
            // start so that the chain is centred on the site
            const [b1, b2] = tangentBasis(d), back = -len * 0.5 / R, dir = [b1[0] * Math.cos(head) + b2[0] * Math.sin(head), b1[1] * Math.cos(head) + b2[1] * Math.sin(head), b1[2] * Math.cos(head) + b2[2] * Math.sin(head)];
            const start = unit([d[0] * Math.cos(back) + dir[0] * Math.sin(back), d[1] * Math.cos(back) + dir[1] * Math.sin(back), d[2] * Math.cos(back) + dir[2] * Math.sin(back)]);
            chain(start, head, len, Wmax, curv, strength, i + 1, 0);
            n++;
        }
        this._lmCount = n; this._lmPts = pts;
        this._lmIdx = new SphereIndex(pts, 46000);
    }
    // HOTSPOTS: ~25 mantle plumes at uniform random places; each leaves a 5-volcano chain dragged along a random great circle
    _buildHotspots() {
        const HC = 88000, n = Math.max(6, Math.round(SPHERE_AREA / (HC * HC) * HOTSPOT_DENSITY)), list = [];
        for (let i = 0; i < n; i++) {
            const c = this._randomUnit(i, 410), [t1, t2] = tangentBasis(c), ang = this.hash(i, 3, 403) * TWO_PI;
            const t = [t1[0] * Math.cos(ang) + t2[0] * Math.sin(ang), t1[1] * Math.cos(ang) + t2[1] * Math.sin(ang), t1[2] * Math.cos(ang) + t2[2] * Math.sin(ang)];
            const R0 = 8500 + 5500 * this.hash(i, 4, 404), A0 = 1700 + 1500 * this.hash(i, 5, 405), ch = new Float64Array(HOT_K * 3), jv = new Float64Array(HOT_K);
            for (let k = 0; k < HOT_K; k++) jv[k] = 0.85 + 0.3 * this.hash(i * 16 + k, 6, 406);   // v59: each volcano of the chain is a little bigger or smaller (a natural, not mechanical, line)
            {   // v61: the chain meanders (slow lateral drift + bend) and the volcanoes are unevenly spaced, so it no longer reads as a ruler line
                const nv = [c[1] * t[2] - c[2] * t[1], c[2] * t[0] - c[0] * t[2], c[0] * t[1] - c[1] * t[0]];
                const bend = (this.hash(i, 8, 408) - 0.5) * 0.9, ph0 = this.hash(i, 9, 409) * TWO_PI;
                let dist = 0;
                for (let k = 0; k < HOT_K; k++) {
                    if (k > 0) dist += HOT_DX * (0.72 + 0.56 * this.hash(i * 16 + k, 10, 410));
                    const phi = dist / R, cs = Math.cos(phi), sn = Math.sin(phi);
                    const lat = (bend * dist * dist / (HOT_DX * HOT_K) + 0.30 * HOT_DX * Math.sin(ph0 + k * 1.3) + 0.35 * HOT_DX * (this.hash(i * 16 + k, 11, 411) - 0.5)) / R;
                    let q0 = c[0] * cs - t[0] * sn + nv[0] * lat, q1 = c[1] * cs - t[1] * sn + nv[1] * lat, q2 = c[2] * cs - t[2] * sn + nv[2] * lat;
                    const ql = 1 / Math.sqrt(q0 * q0 + q1 * q1 + q2 * q2); ch[k * 3] = q0 * ql; ch[k * 3 + 1] = q1 * ql; ch[k * 3 + 2] = q2 * ql;
                }
            }
            list.push({ cx: c[0], cy: c[1], cz: c[2], R0, A0, ch, jv, cosReach: Math.cos((R0 * 3.4 + (HOT_K - 1) * HOT_DX * 1.3 + 6000) / R) });
        }
        this._hot = list;
    }
    // ------------------------------------------------------------ v61 REGIONS, LANDMARKS & NAMES ----
    // Every plate has a tectonic character (0 young/volcanic, 1 old/eroded, 2 karst, 3 glaciated) and a name; island arcs, orogens and hotspot chains
    // get names from their plates / chain. Pure functions of the seed, so main thread and workers agree.
    static get TAG_NAMES() { return ['young / volcanic', 'old / eroded', 'karst', 'glaciated']; }
    _nameWord(tag, kind, a, b) {
        const ADJ = [
            ['Ashen', 'Ember', 'Cinder', 'Smouldering', 'Obsidian', 'Basalt', 'Sulphur', 'Black'],
            ['Low', 'Worn', 'Pale', 'Weathered', 'Quiet', 'Ancient', 'Dun', 'Lonely'],
            ['Pillared', 'Hollow', 'Green', 'Mist', 'Spired', 'Whispering', 'Sunken', 'Lantern'],
            ['Frost', 'Rime', 'Glass', 'Pale-Ice', 'Grey', 'Winter', 'Silent', 'Cold']];
        const NOUN = { region: ['Reaches', 'Marches', 'Lands', 'Shelf', 'Expanse', 'Territories'], sea: ['Deeps', 'Shoals', 'Waters', 'Drift'], arc: ['Arc', 'Crescent', 'Garland', 'Sickle'],
            orogen: ['Spine', 'Crown', 'Wall', 'Teeth'], cordillera: ['Wall', 'Ridge', 'Divide', 'Backbone'], chain: ['Chain', 'Stair', 'Stepping Stones', 'Trail'], fjord: ['Fjords', 'Narrows', 'Sounds'] };
        const adj = ADJ[tag][Math.floor(this.hash(a, b, 7301) * ADJ[tag].length) % ADJ[tag].length], ns = NOUN[kind], noun = ns[Math.floor(this.hash(b, a, 7302) * ns.length) % ns.length];
        return 'the ' + adj + ' ' + noun;
    }
    plateName(i) { const p = this._sites[i]; return this._nameWord(p.tag, p.cont ? 'region' : 'sea', i, 1); }
    // The name of the place at a terrain sample `t` (the object _terrain filled in): { tag, tagName, region, feature, kind }.
    regionInfo(t) {
        const p = t.p1, ti = (t.tY >= t.tO && t.tY >= t.tK && t.tY >= t.tG) ? 0 : (t.tO >= t.tK && t.tO >= t.tG) ? 1 : (t.tK >= t.tG) ? 2 : 3;
        const out = { tag: ti, tagName: TerrainCore.TAG_NAMES[ti], region: this.plateName(p.id), feature: null, kind: 'region' };
        if (t.hotId >= 0 && t.hot > 0.25) { out.feature = this._nameWord(this._sites[p.id].tag, 'chain', 500 + t.hotId, 3); out.kind = 'chain'; }
        else if (t.p2 && t.ridgeKind > 0 && t.ridgeU > 300) {
            const a = Math.min(p.id, t.p2.id), b = Math.max(p.id, t.p2.id), tg = this._sites[a].tag;
            out.kind = t.ridgeKind === 3 ? 'arc' : t.ridgeKind === 1 ? 'orogen' : 'cordillera'; out.feature = this._nameWord(tg, out.kind, a + 100, b);
        } else if (t.arcAmt > 0.3) { const a = Math.min(p.id, t.p2.id), b = Math.max(p.id, t.p2.id); out.kind = 'arc'; out.feature = this._nameWord(this._sites[a].tag, 'arc', a + 100, b); }
        return out;
    }
    // Seeded landmark list for anchoring cities and stories: regions, the arcs / orogens / cordilleras between neighbouring plates (positions are the
    // midpoint of the two plate sites, close to the boundary), and every hotspot chain with its young end volcano. Each: { name, kind, tag, x, y, z, lat, lon }.
    landmarks() {
        if (this._landmarks) return this._landmarks;
        const L = [], S = this._sites, D = 180 / Math.PI, add = (name, kind, tag, x, y, z) => { const l = Math.sqrt(x * x + y * y + z * z); x *= R / l; y *= R / l; z *= R / l; L.push({ name, kind, tag, x, y, z, lat: Math.asin(y / R) * D, lon: Math.atan2(x, z) * D }); };
        for (const p of S) if (p.cont || p.thick > 0.55) add(this.plateName(p.id), p.cont ? 'region' : 'sea', p.tag, p.x, p.y, p.z);
        const lim = 1.55 * Math.sqrt(4 * Math.PI / N_PLATES);
        for (let i = 0; i < S.length; i++) for (let j = i + 1; j < S.length; j++) {
            const a = S[i], b = S[j], dd = (a.x * b.x + a.y * b.y + a.z * b.z) / (R * R);
            if (Math.acos(Math.max(-1, Math.min(1, dd))) > lim) continue;
            const kind = (!a.cont && !b.cont) ? 'arc' : (a.cont && b.cont) ? 'orogen' : 'cordillera';
            if (kind === 'arc' && this.hash(i, j, 7303) > 0.55) continue;   // not every ocean boundary is an arc
            add(this._nameWord(a.tag, kind, i + 100, j), kind, a.tag, a.x + b.x, a.y + b.y, a.z + b.z);
        }
        this._hot.forEach((H, k) => { let bi = 0, bd = -2; for (const p of S) { const d = (p.x * H.cx + p.y * H.cy + p.z * H.cz); if (d > bd) { bd = d; bi = p.id; } } const tg = S[bi].tag; add(this._nameWord(tg, 'chain', 500 + k, 3), 'chain', tg, H.ch[0], H.ch[1], H.ch[2]); });
        return (this._landmarks = L);
    }
    // ------------------------------------------------------------ JET STREAMS ----
    // Four meandering jets per planet (a subtropical and a polar-front jet in each hemisphere). Each is a band whose centre
    // latitude is a seeded sum of Rossby-wave harmonics of longitude, so the jets wander across the whole globe and differ per
    // seed. They steer the wind (and therefore the moisture transport that decides rainfall and biomes), carry the storm track,
    // and the game's clouds drift along them. Pure maths of (direction), no time dependence, so workers agree with the main thread.
    _buildJets() {
        const jets = [];
        for (let hs = 0; hs < 2; hs++) for (let j = 0; j < 2; j++) {
            const id = hs * 2 + j, polar = j === 1;
            const waves = polar ? [3, 4, 6] : [2, 4, 5], amp = polar ? [6.5, 4.0, 2.0] : [4.0, 2.5, 1.4], hm = [];
            for (let k = 0; k < 3; k++) { const ph = TWO_PI * this.hash(id, k + 5, 9101); hm.push({ m: waves[k], a: amp[k] * (0.7 + 0.6 * this.hash(id, k, 9100)), ph, cp: Math.cos(ph), sp: Math.sin(ph) }); }
            jets.push({ sgn: hs === 0 ? 1 : -1, base: (polar ? 54 : 30) + (this.hash(id, 11, 9102) - 0.5) * 6, width: polar ? 8.5 : 7, hm,
                        pm: 2 + Math.floor(this.hash(id, 12, 9103) * 3), pph: TWO_PI * this.hash(id, 13, 9104), pcp: 0, psp: 0 });
            const J = jets[jets.length - 1]; J.pcp = Math.cos(J.pph); J.psp = Math.sin(J.pph);
        }
        this._jets = jets;
        this._itcz = [{ m: 2, a: 3.5 + 2 * this.hash(0, 20, 9110), ph: TWO_PI * this.hash(0, 21, 9111) }, { m: 3, a: 2 + 1.5 * this.hash(0, 22, 9112), ph: TWO_PI * this.hash(0, 23, 9113) }];
        for (const h of this._itcz) { h.cp = Math.cos(h.ph); h.sp = Math.sin(h.ph); }
        this._sT = new Float64Array(8); this._cT = new Float64Array(8);
        this._js = { sub: 0, pol: 0, itcz: 0, js: 0, sP: 0, e: 1, n: 0 };
    }
    // Fills out { sub, pol (centre-latitude shift of the hemisphere's jets, deg), itcz (deg, signed), js (strongest jet 0..1),
    // sP (polar-jet strength), e, n (unit flow direction east/north of the jets blended by strength) } for a unit direction.
    _jetState(dx, dy, dz, out) {
        const latD = Math.asin(dy > 1 ? 1 : (dy < -1 ? -1 : dy)) * 57.29578, a = latD < 0 ? -latD : latD;
        const cl = Math.sqrt(dx * dx + dz * dz), cosLat = cl > 0.05 ? cl : 0.05, il0 = cl > 1e-9 ? 1 / cl : 0;
        const S = this._sT, C = this._cT; S[1] = dx * il0; C[1] = cl > 1e-9 ? dz * il0 : 1;           // sin / cos of longitude (no atan2)
        for (let m = 2; m <= 6; m++) { S[m] = S[m - 1] * C[1] + C[m - 1] * S[1]; C[m] = C[m - 1] * C[1] - S[m - 1] * S[1]; }
        const hs = latD >= 0 ? 0 : 1;
        let fe = 0, fn = 0, best = 0;
        out.sub = 0; out.pol = 0; out.sP = 0; out.lat = latD;
        for (let j = 0; j < 2; j++) {
            const J = this._jets[hs * 2 + j];
            let c = J.base, dc = 0;
            for (let k = 0; k < 3; k++) {
                const h = J.hm[k], sn = S[h.m] * h.cp + C[h.m] * h.sp, cs = C[h.m] * h.cp - S[h.m] * h.sp;
                c += h.a * sn; dc += h.a * h.m * cs;
            }
            const d = (a - c) / J.width, mod = 0.55 + 0.45 * (S[J.pm] * J.pcp + C[J.pm] * J.psp);
            if (d > 3.2 || d < -3.2) { if (j === 0) out.sub = c - J.base; else out.pol = c - J.base; continue; }   // far from this jet: no contribution
            const s = Math.exp(-d * d) * mod;
            // flow follows the curve lat = c(lon): east component cos(lat), north component d(lat)/d(lon)
            const nDeg = J.sgn * dc * 0.0174533, il = 1 / Math.sqrt(cosLat * cosLat + nDeg * nDeg);
            fe += s * cosLat * il; fn += s * nDeg * il; if (s > best) best = s;
            if (j === 0) out.sub = c - J.base; else { out.pol = c - J.base; out.sP = s; }
        }
        let ic = 0; for (let k = 0; k < 2; k++) { const h = this._itcz[k]; ic += h.a * (S[h.m] * h.cp + C[h.m] * h.sp); }
        out.itcz = ic; out.js = best;
        const l = Math.sqrt(fe * fe + fn * fn); if (l > 1e-6) { out.e = fe / l; out.n = fn / l; } else { out.e = 1; out.n = 0; }
        return out;
    }
    // Wind at a unit direction as (u east, w south): the latitude belts (trades / westerlies / polar easterlies) with their
    // boundaries pushed around by the jets, plus a strong flow along each jet core. Magnitude is the moisture-fetch length.
    _windAt(px, py, pz, out) {
        const st = this._jetState(px, py, pz, this._js), a = Math.abs(st.lat), nh = st.lat >= 0;
        const as = a - st.sub, ap = a - st.pol;
        const trade = 1 - ss(24, 34, as), west = ss(24, 34, as) * (1 - ss(56, 68, ap)), polE = ss(56, 68, ap);
        const u = -trade + west - 0.8 * polE, v = (-0.45 * trade + 0.45 * west - 0.3 * polE);
        let wz = nh ? -v : v, l = Math.hypot(u, wz) || 1, k = Math.min(1, l / 0.45) / l;
        let ox = u * k, oz = wz * k;
        const jk = 0.85 * st.js; ox += jk * st.e; oz += -jk * st.n;
        l = Math.hypot(ox, oz); if (l > 1.3) { ox *= 1.3 / l; oz *= 1.3 / l; }
        out[0] = ox; out[1] = oz; return out;
    }
    // Public: geographic wind at a unit direction. out = [east, north, jetStrength, polarJetStrength]
    windEN(dx, dy, dz, out) {
        const w = this._w2 || (this._w2 = [0, 0]); this._windAt(dx, dy, dz, w);
        out[0] = w[0]; out[1] = -w[1]; out[2] = this._js.js; out[3] = this._js.sP; return out;
    }
    // zonal-mean rainfall (mm/yr) with the wet storm track riding the polar jet and the ITCZ wobbling with longitude
    _zonalRainAt(dx, dy, dz) {
        const st = this._jetState(dx, dy, dz, this._js), latD = st.lat, a = Math.abs(latD);
        const itcz = 1750 * Math.exp(-Math.pow((latD - st.itcz) / 10.5, 2));
        const storm = 560 * Math.exp(-Math.pow((a - (52 + st.pol)) / 15, 2)) * (0.75 + 0.5 * st.sP);
        const polar = 1.0 - 0.7 * ss(62, 85, a);
        return (260 + itcz + storm) * polar;
    }

    // SEAMOUNTS / GUYOTS: ~300 points (only evaluated over ocean floor)
    _buildSeamounts() {
        const SC = 26000, n = Math.round(SPHERE_AREA / (SC * SC) * 0.22), pts = [];
        for (let i = 0; i < n; i++) {
            const c = this._randomUnit(i, 510), Rr = 6000 + 6000 * this.hash(i, 6, 503), hMax = 700 + 1700 * this.hash(i, 7, 504);
            const cap = this.hash(i, 8, 505) > 0.5 ? 1500 + 1900 * this.hash(i, 9, 506) : 0;
            pts.push({ x: c[0] * R, y: c[1] * R, z: c[2] * R, R: Rr, hMax, cap });
        }
        this._seamIdx = new SphereIndex(pts, 2 * SC);
    }

    // ------------------------------------------------------------ latitude climate helpers ----
    static tempSeaLevel(lat) { const c = Math.cos(lat); return -26 + 54 * Math.pow(Math.max(0, c), 1.45); }
    // zonal-mean rainfall (mm/yr) from the global circulation: wet ITCZ, dry subtropical highs, wet storm tracks, dry poles
    static zonalRain(lat) {
        const a = Math.abs(lat) * 57.29578;
        const itcz = 1750 * Math.exp(-Math.pow(a / 10.5, 2));
        const storm = 560 * Math.exp(-Math.pow((a - 52) / 15, 2));
        const polar = 1.0 - 0.7 * ss(62, 85, a);
        return (260 + itcz + storm) * polar;
    }
    // wind of a latitude as (u east, w south) components: trades / westerlies / polar easterlies
    static wind(lat, out) {
        const a = Math.abs(lat) * 57.29578, nh = lat >= 0;
        let u, v; // u eastward, v poleward
        const trade = 1 - ss(24, 34, a), west = ss(24, 34, a) * (1 - ss(56, 68, a)), polE = ss(56, 68, a);
        u = -trade + west - 0.8 * polE;
        v = (-0.45 * trade + 0.45 * west - 0.3 * polE);
        // poleward (v>0) in the northern hemisphere is toward the north = -south
        const wz = nh ? -v : v, l = Math.hypot(u, wz) || 1, k = Math.min(1, l / 0.45) / l; // calm belts (horse latitudes) shorten the fetch smoothly
        out[0] = u * k; out[1] = wz * k; return out;
    }


    // ------------------------------------------------------------ the core terrain evaluator ----
    // P = (X, Y, Z) on the sphere (|P| = PLANET_R). detail: 0 = macro (for the climate cache and rivers), 1 = full. Writes into o.
    // v60 BOUNDARY RIDGE: height (units, before the relief cap) of the mountain line that a convergent plate boundary raises, seen from a point that is
    // `qj` units from the boundary and `sAl` units along it. kind 1 = continent collision (twin crests, axial valley, parallel back range), 2 = Andean
    // cordillera (crest on the overriding continent, steep face toward the trench, gentle back slope, intermontane basins, a lower eastern range),
    // 3 = island arc (a narrow crest along the arc line, `qc0` from the boundary). Strength wanders along the crest, so there are high massifs and low
    // passes; the crest itself snakes; spurs branch off across the range and separate more the farther they run from the crest.
    _ridge(qj, sAl, pk, kind, qc0, out) {
        const nz = this.nz, a = sAl, k1 = pk * 1.13, k2 = pk * 0.71;
        const wig = nz.n3(a * 1.8e-5 + k1 * 3, 7.7, k2 * 1.9), m1 = nz.n3(a * 1.5e-5 + k1 + 40, 3.3, k2) * 0.5 + 0.5, m2 = nz.n3(a * 3.3e-5 - k1 - 20, 9.1, k2 * 4) * 0.5 + 0.5;
        const pas = nz.n3(a * 5.5e-5 + k1 * 7, 1.9, k2 * 3) * 0.5 + 0.5;              // passes: short low saddles along the crest
        let qc, wf, wb, A, off2 = 0, a2 = 0, vOff = 0, vW = 9000;
        if (kind === 1) { qc = 14000 + 5000 * wig; wf = 10500; wb = 21000; A = 2350; off2 = 46000; a2 = 0.34; vOff = 28000; }
        else if (kind === 2) { qc = 27000 + 7000 * wig; wf = 8500; wb = 20000; A = 1900; off2 = 50000; a2 = 0.32; vOff = 29000; }
        else { qc = qc0 + 2500 * wig; wf = 7000; wb = 9500; A = 1500; }
        const amp = A * (0.52 + 0.50 * ss(0.30, 0.68, m1) + 0.42 * ss(0.62, 0.78, m2)) * (1 - 0.42 * ss(0.58, 0.40, pas));   // massifs (m2 high) and passes (pas low)
        const d = qj - qc, wd = d < 0 ? wf : wb, g1 = Math.exp(-(d * d) / (wd * wd));
        let prof = g1 + 0.13 * Math.exp(-(d * d) / (2.4 * wd * 2.4 * wd));   // v61: broad foothill pedestal under the crest (layered profile)
        if (off2 > 0) {
            const d2 = qj - (qc + off2), s2 = 10000, g2 = a2 * Math.exp(-(d2 * d2) / (s2 * s2));
            const vd = qj - (qc + vOff), vv = Math.exp(-(vd * vd) / (vW * vW)) * ss(0.20, 0.45, nz.n3(a * 2.6e-5 + k1 * 5, 4.4, k2 * 2) * 0.5 + 0.5);   // longitudinal valley / basin behind the crest, in patches
            const d3 = qj - (qc + off2 * 1.9), g3 = 0.15 * Math.exp(-(d3 * d3) / (11000 * 11000));   // v61: a third, lower outer range
            prof = (g1 + g2 + g3) * (1 - 0.82 * vv);
        }
        // spurs: ridged noise stretched ACROSS the range makes ridge lines that run away from the crest; the valleys between them deepen with distance
        const sn = nz.n3(a / 15500 + k1 * 5.3, qj / 82000 + k2 * 0.9, k2 * 2.2 + 11), spur = Math.pow(1 - Math.abs(sn), 1.6);
        prof *= 1 - ss(5000, 42000, Math.abs(d)) * 0.72 * (1 - spur);
        prof *= ss(0, 8000, qj) * (1 - ss(70000, 112000, qj));   // zero exactly on the boundary: both sides agree (no seam), and a collision gets its axial trough
        out.crest = Math.exp(-(d * d) / (6000 * 6000)); out.mass = ss(0.62, 0.78, m2);
        return amp * prof;
    }
    _terrain(X, Y, Z, detail, o) {
        const nz = this.nz, N = this.N.bind(this);
        const ox = X / R, oy = Y / R, oz = Z / R;                       // unit direction of the point
        // --- plate-boundary warp: large swirls + medium wobble + fine ragged edge (3D vectors, then back onto the sphere)
        const w1x = N(X, Y, Z, 0.0000034, 11.3, 7.7), w1y = N(X, Y, Z, 0.0000034, 53.7, -12.9), w1z = N(X, Y, Z, 0.0000034, -31.1, 19.4);
        const w2x = N(X, Y, Z, 0.000013, 5.5, -2.5), w2y = N(X, Y, Z, 0.000013, 21.5, 33.5), w2z = N(X, Y, Z, 0.000013, -8.5, 14.5);
        const w3x = N(X, Y, Z, 0.00005, 60.1, 3.1), w3y = N(X, Y, Z, 0.00005, -77.7, 41.3), w3z = N(X, Y, Z, 0.00005, -20.9, -44.2);
        let Wx = X + w1x * 21000 + w2x * 6500 + w3x * 1800, Wy = Y + w1y * 21000 + w2y * 6500 + w3y * 1800, Wz = Z + w1z * 21000 + w2z * 6500 + w3z * 1800;
        const wl = R / Math.sqrt(Wx * Wx + Wy * Wy + Wz * Wz); Wx *= wl; Wy *= wl; Wz *= wl;
        const ux = Wx / R, uy = Wy / R, uz = Wz / R;                    // unit direction of the warped point
        // --- spherical Voronoi: the 9 nearest plate sites (sorted), and the union of the continental discs
        const S = this._sites, DD = this._dd, PL = this._pl;
        let cnt = 0;
        for (let i = 0; i < S.length; i++) {
            const p = S[i], ex = Wx - p.x, ey = Wy - p.y, ez = Wz - p.z, dd = ex * ex + ey * ey + ez * ez;
            if (cnt < 9 || dd < DD[8]) {
                let j = cnt < 9 ? cnt++ : 8;
                while (j > 0 && DD[j - 1] > dd) { DD[j] = DD[j - 1]; PL[j] = PL[j - 1]; j--; }
                DD[j] = dd; PL[j] = p;
            }
        }
        const p1 = PL[0], c1 = p1.cont, d1 = DD[0];
        const jit = w3z * 5000 + w2x * 2500;
        const gauss = (d, w) => Math.exp(-(d * d) / (w * w));
        // --- tectonic contributions: every neighbouring plate boundary adds its own landform, weighted by distance to
        // that boundary, so the sum is continuous everywhere (no cliffs where the "second nearest plate" changes).
        let ridgeAmp = 0, ridgeKind = 0, ridgeCrest = 0, ridgeMass = 0, U = 0, S_ = 0, plateau = 0, arcAmt = 0, riftAmt = 0, ridgeAmt = 0, trenchAmt = 0, shearAmt = 0, orogen = 0, convP = 0, divP = 0, boost = 0;
        // PAIR FORMULATION (v34): every pair of the nearest plates (k closer than l) contributes a landform in the frame of the CLOSER plate
        // (the "p1" role of the old code), faded by how much farther the closer plate is than the nearest one. Summing only the boundaries of
        // the single nearest plate (as before) gave a different set of boundaries on either side of a Voronoi edge near a triple junction,
        // i.e. cliffs of several km; with the pair sum both sides see the same set, so the surface is continuous everywhere.
        let uB = 1e12, loP = p1, hiP = p1;             // nearest (jittered) boundary: signed distance u (+ on the lower-id plate's side) and its two plates
        const sd1 = Math.sqrt(d1);
        // --- v59 CRUST: a soft Voronoi blend of the nearby plates' crust levels (continuous everywhere, also at triple junctions).
        // Continental plates sit high, oceanic plates low, micro-continents in between; the noise that follows only adds organic variance.
        let cwS = 0, crustCv = 0, contW = 0;
        const TW = this._tw; TW[0] = TW[1] = TW[2] = TW[3] = 0;
        for (let i = 0; i < cnt; i++) {
            const w = Math.exp(-(Math.sqrt(DD[i]) - sd1) / CRUST_SW), pp = PL[i];
            cwS += w; crustCv += w * pp.crust; if (pp.cont) contW += w; TW[pp.tag] += w;
        }
        crustCv /= cwS; contW /= cwS;
        const tY = TW[0] / cwS, tO = TW[1] / cwS, tK = TW[2] / cwS, tG = TW[3] / cwS;   // v61: soft (continuous) share of each tectonic character here
        // island-system potentials: sv[type] = strongest sign of a tectonic island line (1 arc, 2 rift chain, 3 fringe / thick crust), svAmp = relief weight
        const sv = this._sv, sa = this._sa; sv.fill(0); sa.fill(0);
        let collAmt = 0, tProx = 0, cvTect = 0, riftAge = 0, arcCurve = 0;
        for (let k = 0; k < 8; k++) {
            const a0 = PL[k], ek = Math.sqrt(DD[k]) - sd1;
            const gt = 1 - ss(0, 24000, ek);
            if (gt <= 0) break;                                                 // sorted by distance: nothing further matters
            for (let l = k + 1; l < 9; l++) {
                const b0 = PL[l], cx = b0.x - a0.x, cy = b0.y - a0.y, cz = b0.z - a0.z, bl = Math.sqrt(cx * cx + cy * cy + cz * cz) || 1;
                // signed distance to the (jittered) boundary, in a canonical orientation (lower plate id positive) so it does not depend on which plate happens to be nearer
                const s0 = (DD[l] - DD[k]) / (2 * bl), loIsA = a0.id < b0.id, u = (loIsA ? s0 : -s0) + jit;
                if (k === 0 && Math.abs(u) < Math.abs(uB)) { uB = u; loP = loIsA ? a0 : b0; hiP = loIsA ? b0 : a0; }
                // the plate whose side of the jittered boundary the point is on plays the "p1" role, the other one is "pj"
                const aIsA = (u >= 0) === loIsA, pa = aIsA ? a0 : b0, pj = aIsA ? b0 : a0, qj = Math.abs(u), ca = pa.cont;
                if (qj > 150000) continue;
                const bx = pj.x - pa.x, by = pj.y - pa.y, bz = pj.z - pa.z;
                // boundary normal = direction from plate a toward plate j, projected into the tangent plane at the point
                const rd = bx * ux + by * uy + bz * uz;
                let nx = bx - rd * ux, ny = by - rd * uy, nzv = bz - rd * uz; const nl = Math.sqrt(nx * nx + ny * ny + nzv * nzv) || 1; nx /= nl; ny /= nl; nzv /= nl;
                // relative surface velocity of the two plates here: (omega_a - omega_j) x u
                const dwx = pa.ox - pj.ox, dwy = pa.oy - pj.oy, dwz = pa.oz - pj.oz;
                const rvx = dwy * uz - dwz * uy, rvy = dwz * ux - dwx * uz, rvz = dwx * uy - dwy * ux;
                const conv = rvx * nx + rvy * ny + rvz * nzv;
                const tx = uy * nzv - uz * ny, ty = uz * nx - ux * nzv, tz = ux * ny - uy * nx;
                const shear = Math.abs(rvx * tx + rvy * ty + rvz * tz);
                const c01 = clamp(conv / 1.3, -1, 1), cP = Math.max(0, c01), dP = Math.max(0, -c01), c2 = pj.cont;
                const pk = (a0.id < b0.id ? a0.id * 64 + b0.id : b0.id * 64 + a0.id);
                const sAl = (Wx - (a0.x + b0.x) * 0.5) * tx + (Wy - (a0.y + b0.y) * 0.5) * ty + (Wz - (a0.z + b0.z) * 0.5) * tz;   // position along the boundary (from its midpoint)
                if (cP * gt > convP) convP = cP * gt; if (dP * gt > divP) divP = dP * gt;
                if (cP > 0.02) {
                    if (ca && c2) {                                   // continent collision: fold belt + plateau
                        const W = 30000 + 12000 * (N(X, Y, Z, 0.00002, 0, 0) * 0.5 + 0.5);
                        const og = cP * gauss(qj, W) * gt; orogen = Math.max(orogen, og); U += 1500 * og;   // v60: the broad swell only; the range itself is the boundary ridge below
                        if (qj < RIDGE_REACH) { const rA = this._ridge(qj, sAl, pk, 1, 0, this._rgo) * ss(0.10, 0.60, cP) * gt; if (rA > ridgeAmp) { ridgeAmp = rA; ridgeKind = 1; ridgeCrest = this._rgo.crest; ridgeMass = this._rgo.mass; } }
                        collAmt = Math.max(collAmt, og); cvTect = Math.max(cvTect, 0.20 * og); tProx = Math.max(tProx, cP * gauss(qj, 90000) * gt);   // v59: collisions thicken the crust -> a long, thick range
                        plateau = Math.max(plateau, cP * gauss(qj, 80000) * gt);
                    } else if (ca && !c2) {                           // Andean cordillera on the overriding continent
                        const arc = ss(0, 12000, qj) * gauss(qj - 22000, 16000) * cP * gt; arcAmt = Math.max(arcAmt, arc); U += 1200 * arc;
                        if (qj < RIDGE_REACH) { const rA = this._ridge(qj, sAl, pk, 2, 0, this._rgo) * ss(0.10, 0.60, cP) * gt; if (rA > ridgeAmp) { ridgeAmp = rA; ridgeKind = 2; ridgeCrest = this._rgo.crest; ridgeMass = this._rgo.mass; } }
                        cvTect = Math.max(cvTect, 0.10 * arc); tProx = Math.max(tProx, 0.8 * cP * gauss(qj, 80000) * gt);
                        plateau = Math.max(plateau, 0.45 * cP * ss(0, 24000, qj) * gauss(qj - 42000, 46000) * gt);
                        const tr = cP * gauss(qj, 9000) * gt; trenchAmt = Math.max(trenchAmt, tr); S_ += 3900 * tr;
                        boost = Math.max(boost, cP * ss(0, 9000, qj) * (1 - ss(9000, 42000, qj)) * 0.62 * gt);
                    } else if (!ca && c2) {                           // trench on the subducting ocean side
                        const tr = cP * gauss(qj, 9000) * gt; trenchAmt = Math.max(trenchAmt, tr); S_ += 3900 * tr;
                    } else {                                          // ocean/ocean: arc on the lighter plate, trench at the contact
                        const tr = cP * gauss(qj, 9000) * gt; trenchAmt = Math.max(trenchAmt, tr); S_ += 4300 * tr;     // v59: deeper outer trench
                        if (pa.dens < pj.dens) {
                            const arc = ss(0, 8000, qj) * gauss(qj - 17000, 8500) * cP * gt; arcAmt = Math.max(arcAmt, arc); U += 2700 * arc;
                            // v59 ISLAND ARC: the volcanic line sits on the overriding plate and BOWS away from the trench toward both ends (convex toward the
                            // trench), so it reads as a curved arc, not a straight band. Where it rises above the sea it becomes the island chain (see isle below).
                            const cu = Math.min(1.6, (sAl * sAl) / (ARC_L * ARC_L)) * (0.55 + 0.9 * this.hash(pk, 3, 5901)), arcD = 13000 + 21000 * cu;
                            const sA = gauss(qj - arcD, 12500) * Math.min(1, cP * 1.35) * gt;
                            sv[1] = Math.max(sv[1], sA); sa[1] += sA * 2300; arcCurve = Math.max(arcCurve, sA * cu);
                            if (qj < RIDGE_REACH) { const rA = this._ridge(qj, sAl, pk, 3, arcD, this._rgo) * ss(0.10, 0.60, cP) * gt; if (rA > ridgeAmp) { ridgeAmp = rA; ridgeKind = 3; ridgeCrest = this._rgo.crest; ridgeMass = this._rgo.mass; } }
                        }
                    }
                } else if (dP > 0.02) {
                    if (!ca && !c2) {                                 // mid-ocean ridge
                        const rg = dP * gauss(qj, 62000) * gt; ridgeAmt = Math.max(ridgeAmt, rg); U += 2500 * rg;
                        const rf = dP * gauss(qj, 3600) * gt; riftAmt = Math.max(riftAmt, rf); S_ += 800 * rf;
                        // v59 RIFT CHAIN: some spreading ridges surface as a STRAIGHT chain of islands along the axis; the islands get smaller and lower
                        // (older, more eroded) with distance along the chain from its young end.
                        if (this.hash(pk, 4, 5902) < 0.55) {
                            const dir = this.hash(pk, 5, 5903) < 0.5 ? -1 : 1, age = ss(-65000, 65000, sAl * dir), sR = gauss(qj, 5600) * dP * gt * (1 - 0.62 * age);
                            sv[2] = Math.max(sv[2], sR); sa[2] += sR * 1500 * (1 - 0.5 * age); if (sR > 0.2) riftAge = Math.max(riftAge, age);
                        }
                    } else if (ca && c2) {                            // continental rift: floor drops, shoulders rise
                        const rf = dP * gauss(qj, 9500) * gt; riftAmt = Math.max(riftAmt, rf); S_ += 1100 * rf;
                        U += 1500 * dP * gauss(qj - 17000, 9000) * gt;
                    } else { U += 500 * dP * gauss(qj, 20000) * gt; }
                }
                if (ca !== c2 && c01 <= 0 && ca) boost = Math.max(boost, 0.14 * ss(0, 9000, qj) * (1 - ss(9000, 70000, qj)) * gt); // passive margin shelf
                if (shear > 0.05) { const sa = Math.min(1, shear) * gauss(qj, 6000) * ss(0.05, 0.4, shear) * gt; shearAmt = Math.max(shearAmt, sa); U += 380 * sa; S_ += 260 * sa; }
            }
        }

        const wlo = 0.5 * (1 + ss(0, 24000, uB) - ss(0, 24000, -uB));          // weight of the lower-id plate of the nearest boundary: 0.5 on it, 1 / 0 deep inside either plate
        const q = Math.abs(uB);
        let landSide = (loP.cont ? 1 : 0) * wlo + (hiP.cont ? 1 : 0) * (1 - wlo);
        const ageW = loP.age * wlo + hiP.age * (1 - wlo), hardW = loP.hard * wlo + hiP.hard * (1 - wlo);

        // --- v59 TECTONIC LAND (replaces the v43 plate-independent noise continents and the scattered "chain mask" that made confetti islands).
        // 1. crustCv: continental plates sit high, oceanic plates low (soft blend above). 2. organic variance: broad swells that flood parts of continental
        // plates (gulfs, seas, big islands) and lift parts of oceanic ones. 3. boundary thickening: collisions and subduction margins raise the crust.
        // 4. island systems: arcs (curved, outer trench), straight rift chains, thick-crust patches and continental fringes carry a HIERARCHY -
        // a few large main islands in the cores, satellites that taper off along the line, tiny islets and reefs, and open ocean in between.
        // 5. hotspot chains (straight, young end tall, older islands lower and smaller, finally drowned).
        const cwx = N(X, Y, Z, 0.000008, 500, 500) * 7000 + N(X, Y, Z, 0.00003, 1500, 1500) * 1800;
        const cwy = N(X, Y, Z, 0.000008, -500, 500) * 7000 + N(X, Y, Z, 0.00003, -1500, 1500) * 1800;
        const cwz = N(X, Y, Z, 0.000008, -500, -500) * 7000 + N(X, Y, Z, 0.00003, 1500, -1500) * 1800;
        const CX = X + cwx, CY = Y + cwy, CZ = Z + cwz;
        const cvN = nz.n3(CX * 9.5e-6 + 7.1, CY * 9.5e-6 + 3.3, CZ * 9.5e-6 - 5.9) * 0.62 + nz.n3(CX * 2.44e-5 + 41, CY * 2.44e-5 - 9, CZ * 2.44e-5 + 17) * 0.28 + nz.n3(CX * 5.9e-5 - 13, CY * 5.9e-5 + 25, CZ * 5.9e-5 + 3) * 0.10;
        const coastRough = (1 - Math.abs(nz.n3(CX * CONT_FREQ * 7 + 80, CY * CONT_FREQ * 7 + 80, CZ * CONT_FREQ * 7 - 80))) * 0.14
                         + (1 - Math.abs(nz.n3(CX * CONT_FREQ * 17 - 80, CY * CONT_FREQ * 17 + 80, CZ * CONT_FREQ * 17 + 80))) * 0.06;
        const cvSm = crustCv + cvN * (NOISE_CONT / 0.3) * (0.2 + 0.8 * contW) + cvTect - LAND_BIAS;   // smooth part of continentalness
        // v63 SEAFLOOR: the ridged coastline noise carves squiggly contour lines into the shelf; it keeps full strength at the shore and fades out with depth
        const crF = 1 - 0.80 * ss(0.01, -0.13, cvSm);
        let cont = cvSm + (coastRough - 0.1) * COAST_ROUGH * (0.35 + 0.65 * contW) * crF;
        // continental fringe / thick oceanic crust: a weaker island system wherever the crust is intermediate
        { const fr = 0.60 * ss(-0.46, -0.24, crustCv) * (1 - ss(-0.02, 0.12, crustCv)); sv[3] = fr; sa[3] = fr * 1000; }
        // island hierarchy
        let isle = 0, sysV = Math.max(sv[1], sv[2], sv[3]), sysAmp = 0, sysT = 0;
        if (sysV > 0.04) {
            const sw = sa[1] + sa[2] + sa[3], vw = sv[1] + sv[2] + sv[3]; sysAmp = vw > 1e-6 ? sw / vw : 0;
            const aN = clamp(0.5 + 0.5 * (N(X, Y, Z, 1 / 46000, 300, 300) * 0.8 + N(X, Y, Z, 1 / 20000, 60, -60) * 0.25), 0, 1);        // main-island scale
            const bN = clamp(0.5 + 0.5 * N(X, Y, Z, 1 / 15500, -140, 80), 0, 1);                                                          // satellite scale
            const cN = clamp(0.5 + 0.5 * N(X, Y, Z, 1 / 6200, 17, -220), 0, 1);                                                           // islet / reef scale
            const mainB = sysV * ss(0.46, 0.66, aN);                                  // a few big islands in the cores
            const near = sysV * ss(0.22, 0.46, aN);                                   // ground within reach of a main island
            const satB = near * ss(0.52, 0.72, bN) * 0.78;                            // satellites: only near mains, they taper away along the line
            const isB = (0.45 * sysV + 0.55 * near) * ss(0.70, 0.84, cN) * 0.60;     // islets / reefs, a few per archipelago
            isle = Math.max(mainB, satB, isB);
            sysT = sv[1] >= sv[2] && sv[1] >= sv[3] ? 1 : (sv[2] >= sv[3] ? 2 : 3);
        }
        if (isle > 0) { const capI = (sv[1] * 0.34 + sv[2] * 0.30 + sv[3] * 0.18) / Math.max(1e-6, sv[1] + sv[2] + sv[3]); cont = Math.max(cont, capLift(cont + isle * ISLE_AMP, capI)); }   // island cores rise to a gentle ~0.34 continentalness at most (their relief comes from isleU)
        // hotspot chains (cv bump so the young volcanoes become real islands; the cones themselves are added further down)
        let hotCv = 0, hotAge = 0, hotU = 0, hotRaw = 0, hotT = 0, calderaRaw = 0, hotId = -1;
        {
            const HS = this._hot, R2 = R * R;
            for (let h = 0; h < HS.length; h++) {
                const H = HS[h];
                if (ox * H.cx + oy * H.cy + oz * H.cz < H.cosReach) continue;
                for (let k = 0; k < HOT_K; k++) {
                    const dot = ox * H.ch[k * 3] + oy * H.ch[k * 3 + 1] + oz * H.ch[k * 3 + 2]; let r2 = R2 * (2 - 2 * dot);
                    const Rk = H.R0 * H.jv[k] * (1 - 0.06 * k) * (k === 0 ? 1.35 : 1), sw = 2.8 * Rk;
                    if (r2 > sw * sw) continue;
                    r2 *= Math.max(0.2, 1 + 0.50 * N(X, Y, Z, 1 / 9000, 7 + h * 3, 5 + k * 5) + 0.26 * N(X, Y, Z, 1 / 3300, 21 + h * 3, 9 + k * 5));   // v61: organic outline (two scales): bays, headlands, lobes - not a disc
                    const age = Math.pow(0.80, k), t = 1 - r2 / (Rk * Rk);
                    if (t > 0) {
                        const b = 1.25 * Math.pow(t, 1.2) * age; if (b > hotCv) { hotCv = b; hotAge = k / (HOT_K - 1); hotId = h; }
                        const cone = t * t * H.A0 * Math.pow(0.74, k); hotRaw += cone; hotT = Math.max(hotT, t);
                        if (k === 0) calderaRaw = Math.max(calderaRaw, ss(0.88, 1.0, t));
                    }
                    const fs = 1 - r2 / (sw * sw), swell = 0.36 * age * fs * fs; if (swell > hotCv) hotCv = swell;   // shallow swell around each island (reef shelf)
                }
            }
        }
        if (hotCv > 0) cont = Math.max(cont, capLift(cont + hotCv, 0.34));   // young volcanic islands rise to a modest continentalness; the cones add the peak
        cont = softCap(cont, 0.50, 0.6);   // thick crust still tops out (no 14 km spikes where a collision meets a thick plate and a noise swell)
        const cv = cont;
        // range placement (V15): a low-frequency field decides where mountain belts sit; they need properly inland ground
        const rangeRaw = N(X, Y, Z, 0.00007 * MTN_SPAN, 900, 900);   // v46: lower frequency = longer, wider belts
        const inlandRaw = cv - 0.04;   // v59: continental crust tops out lower than the old noise continents did
        const foothillFactor = ss(0.0, 0.36, inlandRaw), highPeakFactor = ss(0.08, 0.46, inlandRaw);
        const mntBase = foothillFactor * 0.22 + Math.pow(highPeakFactor, 1.9) * 0.78;
        const rangeMask = ss(0.24, 0.58, (rangeRaw + 1) / 2);
        const mntMask = mntBase * (0.05 + rangeMask * 0.95) * (0.12 + 0.88 * Math.min(1, tProx * 1.5));   // v59: inland belts follow the plate boundaries (collisions, subduction margins)
        // landSide: soft 0..1 "this is continental ground" used by the ancient-range / rift logic below
        landSide = Math.max(landSide * 0.5, ss(0.0, 0.3, cv));
        // --- base height from continentalness
        let base;
        if (cv > 0) {
            // beach ramp -> low coastal plain -> a gently climbing interior (V15 curve): coasts slope into the sea, the land rises
            // progressively the further inland you go instead of snapping up into a mountain at the shore
            const inl = Math.max(0, cv - 0.06);
            base = -10 + 52 * ss(0.0, 0.07, cv) + 24 * ss(0.05, 0.22, cv) + LAND_RISE * Math.pow(inl, 0.85) + LAND_SWELL * Math.pow(Math.max(0, cv - 0.10), 1.4);
        } else {
            const f = -cv, shelfW = 0.10 + 0.08 * (N(X, Y, Z, 0.00002, 90, 90) * 0.5 + 0.5);   // broad shallow shelf -> reefs / shallows near the coast
            base = -12 - 240 * ss(0, shelfW, f) - 3350 * ss(shelfW * 0.8, shelfW + 0.62, f) - 700 * ss(0.5, 0.95, f);
        }
        const landK = ss(0.02, 0.18, cv);
        // plate-boundary uplift is full strength offshore (arcs, ridges, trenches) but mostly muted on land: mountains on land come from the
        // inland range belts above, not from a plate boundary that happens to cross a continent
        const landTaper = cv > 0 ? ss(0.0, 0.22, cv) : 1;   // plate-driven uplift fades in gradually with distance inland (no mountain wall at the shore)
        U *= TECT_UPLIFT * (1 - LAND_TECT_DAMP * ss(-0.08, 0.08, cv)) * landTaper;
        const rangeU = RANGE_UPLIFT * mntMask;
        const spineS = mntMask, spineU = rangeU;
        U += rangeU;
        // v59 ISLAND / COLLISION RELIEF: arcs, rift chains and fringes lift their islands (core high, coast low, scaled by the line's own weight);
        // collisions raise a long thick range. Both bypass the 'muted on land' damping above and only act where the ground is (nearly) above water.
        const landGate = ss(-0.02, 0.10, cv);
        const isleU = sysAmp * Math.pow(isle, 1.6) * landGate, collU = 600 * collAmt * ss(0.0, 0.14, cv);
        const ridgeU = ridgeAmp * landGate;                                     // v60: the boundary ridge only stands where the ground is (nearly) above water
        U += isleU + collU;
        if (mntMask > 0.05) { orogen = Math.max(orogen, Math.min(1, mntMask * 1.4)); }
        orogen = Math.max(orogen, Math.min(1, ridgeU / 1500));
        // plateau uplift (Tibet / Altiplano)
        const plateauH = 1500 * plateau * (1 - 0.6 * ss(0.0, 0.2, cv)) * (cv > 0 ? ss(0.0, 0.22, cv) : 1);
        // --- ancient eroded ranges inside continents (Urals/Appalachians): low, rounded
        let ancient = 0;
        {
            const an = N(X, Y, Z, 0.000026, 400, 400);
            const am = ss(0.15, 0.55, an) * landSide * landK;
            if (am > 0.001) { const rr = 1 - Math.abs(N(X, Y, Z, 0.000045, -700, -700)); ancient = am * Math.pow(Math.max(0, rr), 1.8) * 700 * (0.4 + 0.6 * hardW); }
        }
        // --- eroded ridged relief on top of uplift
        let relief = 0, mntDetail = 0;
        const upl = U + ancient * 2.2;
        if (upl > 60 || ridgeU > 60) {
            const octs = detail ? RIDGE_OCTS : 3;
            let sum = 0, sumF = 0, a = 1, f = 1, dxs = 0, dys = 0, dzs = 0, an = 0;
            for (let i = 0; i < octs; i++) {
                const fr = 0.000024 * MTN_SPAN * f;
                const v = nz.nd3(Wx * fr + 50, Wy * fr + 50, Wz * fr + 50);
                let gxs = nz.gx, gys = nz.gy, gzs = nz.gz; const gr = gxs * ux + gys * uy + gzs * uz; gxs -= gr * ux; gys -= gr * uy; gzs -= gr * uz; // slope along the surface only
                const sq = Math.sqrt(v * v + 0.03), r = 1 - sq;    // sharp-but-continuous crest: derivative -v/sqrt(v^2+eps)
                const rr = Math.pow(Math.max(0, r) / 0.94, 1.35);
                const sd = v / Math.sqrt(v * v + 0.06);   // softer sign for the slope-damping term so it can't flip abruptly at crests
                dxs += -sd * gxs * a * 0.9; dys += -sd * gys * a * 0.9; dzs += -sd * gzs * a * 0.9;
                const dmp = 1 / (1 + 0.55 * (dxs * dxs + dys * dys + dzs * dzs));
                sum += a * rr * dmp; sumF += a * (0.5 + 0.5 * v) * dmp;
                an += a; a *= 0.36; f *= 2.05;   // v46: 0.42 -> 0.36 (less fine-scale jaggedness on the mountains)
            }
            mntDetail = clamp((0.64 * sum * 1.9 + 0.36 * sumF * 1.25) / an, 0, 1.15);
            // v63 SEAFLOOR: the sharp ridged crests turn into the squiggly contour lines on the shallow seabed; offshore keep only the smooth swell
            { const seaK = 1 - ss(-0.14, 0.03, cv); if (seaK > 0) mntDetail = mix(mntDetail, clamp(sumF * 0.56 / an, 0, 1.15), 0.88 * seaK); }
            // v39 FOOTHILLS: ridged detail only grows where the uplift is real, and the uplift itself follows a convex curve - low uplift stays
            // gentle rolling ground, and the slope steepens progressively toward the crest (plains -> foothills -> ranges -> peaks).
            mntDetail *= ss(120, 1500, upl + ridgeU);
            const uplS = 2600 * Math.pow(upl / 2600, FOOT_EXP);
            relief = uplS * UPLIFT_SCALE * (0.30 + 0.70 * mntDetail);
            // v60: the boundary ridge keeps its crest line (the eroded detail only cuts into it), and the whole relief is capped near RELIEF_CAP
            relief += ridgeU * (0.40 + 0.60 * Math.min(1.1, mntDetail));
            relief *= 1 + 0.12 * tY - 0.22 * tO + 0.05 * tG;   // v61: young crust is craggier, old crust worn down
            relief *= 1 + (PEAK_GAIN - 1) * ss(700, 2400, relief);   // v93
            { const kn = RELIEF_CAP * RELIEF_KNEE; if (relief > kn) relief = kn + (RELIEF_CAP - kn) * (1 - Math.exp(-(relief - kn) / (RELIEF_CAP - kn))); }
        }
        // v60 CONTROLLED ANOMALIES: now and then a lone jagged peak or an out-of-place mountain (rare, bounded) so ranges and plains do not feel mechanical
        let anomaly = 0;
        if (cv > 0.12) {
            const an1 = N(X, Y, Z, 1 / 52000, 1234, -77) * 0.5 + 0.5, pk1 = ss(0.80, 0.93, an1);
            if (pk1 > 0.001) {
                const jag = 1 - Math.abs(N(X, Y, Z, 1 / 7500, 5, 5)), cone = 0.45 + 0.55 * Math.pow(Math.max(0, jag), 2.4);
                anomaly = pk1 * (480 + 640 * cone) * ss(0.12, 0.30, cv) * (0.55 + 0.45 * ss(0, 900, ridgeU)) * (0.25 + 0.75 * Math.max(tY, 0.6 * ss(0, 900, ridgeU)));   // v61: stray peaks / volcanic knobs sit on young crust or ranges, not everywhere
            }
        }
        // --- hills and plains texture on land (craton interiors flatter, young crust rougher)
        let hills = 0;
        {
            const h1 = N(X, Y, Z, 0.00008, 2200, 2200) * 0.7 + N(X, Y, Z, 0.00019, -900, -900) * 0.3;
            hills = h1 * HILL_AMP * (0.55 + 0.45 * (1 - ageW * 0.7)) * (1 - 0.40 * tO + 0.12 * tY) * landK * ss(15, 110, base);   // v44: hills fade out toward the beach (no ragged pools on the coastal plain)   // v43: V15-like rolling hills (broad, soft)
            if (detail) { const rw = N(X, Y, Z, 0.0007, 120, -120) * 0.65 + N(X, Y, Z, 0.0018, 60, -60) * 0.35; hills += rw * 45 * landK; }
        }
        // --- volcanism: hotspot chains + arc stratovolcano cones
        let volc = 0, hot = hotT, calderaK = calderaRaw;
        {   // v59: the hotspot chain was evaluated above (it also drives the continentalness bump); the cones keep their height on the new islands
            volc = hotRaw * (1 - 0.55 * ss(0.0, 0.25, cv));
            volc -= calderaK * 380 * (1 - 0.6 * ss(0.0, 0.25, cv));
        }
        let arcCones = 0;
        if (arcAmt > 0.08 && detail) {
            const cn = nz.n3(Wx * 0.00011 + 70, Wy * 0.00011 + 70, Wz * 0.00011 + 70) * 0.5 + 0.5;
            arcCones = arcAmt * Math.pow(Math.max(0, cn), 3.2) * 1500 * (1 - 0.8 * ss(0.0, 0.2, cv)); volc += arcCones; hot = Math.max(hot, arcAmt);
        }
        // --- ocean floor extras
        let seamount = 0, guyotK = 0, ocPlat = 0, abyHills = 0, seep = 0, canyon = 0, ventN = 0;
        if (detail && cv < 0.02) {
            this._seamIdx.each(X, Y, Z, (sm) => {
                const ddx = X - sm.x, ddy = Y - sm.y, ddz = Z - sm.z, r2 = ddx * ddx + ddy * ddy + ddz * ddz;
                if (r2 > sm.R * sm.R) return;
                const t = 1 - r2 / (sm.R * sm.R); let h = t * t * sm.hMax;
                if (sm.cap > 0 && h > sm.cap) { h = sm.cap; guyotK = 1; }
                if (h > seamount) seamount = h;
            });
            const pn = N(X, Y, Z, 0.000012, 800, -800);
            ocPlat = ss(0.52, 0.72, pn) * 1500 * (1 - ridgeAmt) * (1 - trenchAmt);
            abyHills = N(X, Y, Z, 0.0004, 1, 1) * 90 + N(X, Y, Z, 0.0011, -4, 4) * 45;
            ventN = N(X, Y, Z, 0.0005, 3000, 3000) * 0.5 + 0.5;
            seep = trenchAmt > 0.25 ? ss(0.62, 0.78, N(X, Y, Z, 0.0007, 40, -40) * 0.5 + 0.5) : 0;
            const slopeBand = ss(-0.02, -0.12, cv) * (1 - ss(-0.3, -0.45, cv));
            canyon = slopeBand * ss(0.8, 0.93, 1 - Math.abs(N(X, Y, Z, 0.00016, 30, -30)));
        }
        const oceanMask = 1 - ss(-0.07, -0.005, cv);   // v43: reaches 0 BEFORE the gate (cv < 0.02) above - the old mask was still 0.6 where the gate switched off = a cliff of up to 1.5 km at every coast

        // v43: seafloor tectonics (ridges, arcs, plateaus, seamounts) may build up the ocean floor but must not breach the surface by themselves:
        // that used to scatter spiky little rock islands over every shallow sea. Only hotspot volcanoes (volc) and the V15-style island-chain
        // mask above are allowed to make new islands. The extra height is squeezed into the room left below the waterline.
        const exUp = relief + anomaly + plateauH + ancient + hills + seamount * oceanMask + ocPlat * oceanMask;
        let exK = 0;
        if (cv < 0.06) {
            const room = Math.max(0, -60 - base), offK = 1 - ss(0.0, 0.06, cv);
            const sq = exUp > 0 ? room * (1 - Math.exp(-exUp / Math.max(room, 1))) : exUp;
            exK = mix(exUp, sq, offK);
        } else exK = exUp;
        // v63: seabed detail fades gracefully with depth: soft rolling abyss, smoothed shelf (the finest hills and the shelf-edge canyons thin out)
        const dpt = Math.max(0, -base), fineFade = 0.45 + 0.55 * ss(-0.6, -0.12, cv);
        abyHills *= 0.55 * fineFade;
        let h = base + exK - S_ + volc * 1.0 + abyHills * oceanMask - canyon * 520 * (0.6 + 0.4 * ss(0.0, 1.0, Math.min(1, dpt / 2500)));
        if (h > 5200) h = softCap(h, 9400, 0.66);   // v93: was softCap(h, 4600, 0.72) from 3300 (v60). Land now tops out near 9.4k units (~2.2 km real)
        // no accidental inland seas: land is kept above the shoreline except in the deep rifts
        if (cv > 0.08 && h < 25) h = mix(h, 25 + (h - 25) * 0.12, ss(0.08, 0.12, cv));   // (v34: blended - the old hard switch at cv = 0.1 was a cliff of up to 2.5 km wherever a trench met a coast)
        // v39 HIDDEN VALLEYS: now and then (a rare, smooth noise field - never forced) a closed basin appears inland: a flat, low, fertile floor ringed
        // all the way round by a wall of mountains. The ring is a closed iso-line of the field, so it has no gaps. Biome: ENCHANTED_VALLEY.
        let valleyK = 0;
        if (cv > 0.22 && Math.abs(oy) < 0.88) {
            const vn = N(X, Y, Z, 0.000052, 1900, -1900) * 0.5 + 0.5, vt = VALLEY_T;
            if (vn > vt - 0.12) {
                const gate = ss(0.22, 0.40, cv);
                const rim = ss(vt - 0.12, vt - 0.01, vn) * (1 - ss(vt - 0.01, vt + 0.07, vn));
                const flr = ss(vt - 0.01, vt + 0.08, vn) * gate;
                h += rim * gate * (850 + 350 * (0.5 + 0.5 * N(X, Y, Z, 0.00012, 5, -5)));
                if (flr > 0.001) h = h * (1 - flr) + (60 + 28 * N(X, Y, Z, 0.0004, 8, 8)) * flr;
                valleyK = flr;
            }
        }
        // v61 COASTS BY CHARACTER (all blends are continuous in the tag weights):
        //  glaciated -> fjords (narrow channels cut from the sea into coastal highland); old/eroded -> broad, gentle beaches and shallows;
        //  young/volcanic -> cliffs and a steep drop-off; karst/tropical -> flat reef shelves offshore with scattered shoals.
        if (h > -420 && h < 1500) {
            if (tG > 0.02 && cv > -0.05 && cv < 0.30) {
                const fl = 1 - Math.abs(N(Wx, Wy, Wz, 0.00008, 303, -303) + 0.35 * N(X, Y, Z, 0.00021, 12, -12)), fm = ss(0.74, 0.88, fl), gate = 1 - ss(0.14, 0.40, cv);
                const fj = fm * gate * Math.min(1, tG * 1.6) * ss(-0.05, 0.06, cv);
                if (fj > 0.003) { const bed = -150 - 260 * fm; h = h * (1 - fj) + Math.min(h, bed) * fj; }
            }
            if (tO > 0.02) { const k = tO * (1 - ss(70, 330, Math.abs(h))); h *= 1 - 0.55 * k; }
            if (tY > 0.02) {
                h += tY * ss(8, 60, h) * (1 - ss(300, 900, h)) * 130;
                if (h < 0) h -= tY * (1 - ss(-20, -260, h)) * ss(-420, -60, h) * 90 * ss(-0.02, 0.05, -cv + 0.03);
            }
            if (tK > 0.02 && h < -8) {
                const k = tK * ss(-420, -120, h) * (1 - ss(-60, -8, h)), sh = -42 - 30 * (N(X, Y, Z, 0.0004, 77, -5) * 0.5 + 0.5);
                h = h * (1 - 0.7 * k) + sh * 0.7 * k;
            }
        }
        // polar highlands
        const latRad = Math.asin(clamp(oy, -1, 1)), pa = Math.abs(latRad) * 57.29578;
        if (guyotK > 0) h = Math.min(h, pa < 24 ? -18 - 30 * (seamount % 7) / 7 : -260 - 150 * (seamount % 7) / 7); // tropical guyots reach the surface as reef-capped atolls
        if (pa > 83) { let t = Math.min(1, (pa - 83) / 5.5); t = t * t * (3 - 2 * t); h += Math.pow(t, 1.4) * 2600; }
        if (h < -7600) h = -7600;
        o.h = h; o.cv = cv; o.base = base; o.relief = relief; o.upl = upl; o.mntDetail = mntDetail; o.plateau = plateau; o.volc = volc; o.hot = hot;
        o.arcAmt = arcAmt; o.riftAmt = riftAmt; o.ridgeAmt = ridgeAmt; o.trenchAmt = trenchAmt; o.orogen = orogen; o.shearAmt = shearAmt;
        o.seamount = seamount; o.guyotK = guyotK; o.ocPlat = ocPlat; o.seep = seep; o.canyon = canyon; o.ventN = ventN; o.abyHills = abyHills;
        o.isle = isle; o.sysT = sysT; o.hotAge = hotAge; o.riftAge = riftAge; o.arcCurve = arcCurve; o.collAmt = collAmt; o.crustCv = crustCv; o.contW = contW; o.cvTect = cvTect; o.tProx = tProx; o.hotCv = hotCv; o.cvN = cvN;
        o.tY = tY; o.tO = tO; o.tK = tK; o.tG = tG; o.hotId = hotId; o.p2 = PL[1]; o.ridgeU = ridgeU; o.ridgeKind = ridgeKind; o.ridgeCrest = ridgeCrest; o.ridgeMass = ridgeMass; o.anomaly = anomaly; o.valleyK = valleyK; o.spineU = spineU; o.spineS = spineS; o.landSide = landSide; o.convP = convP; o.divP = divP; o.c1 = c1; o.p1 = p1; o.q = q; o.ancient = ancient; o.hills = hills; o.latRad = latRad; o.calderaK = calderaK;
        return h;
    }


    // ------------------------------------------------------------ cached climate grid (six cube-face lattices) ----
    // Node (i, j) of face f sits at chart (-CHART_HALF + (i - GM) * GS, -CHART_HALF + (j - GM) * GS); the GM margin nodes poke past
    // the face edge so bilinear lookups near an edge never run off the lattice. Every node is a pure function of its direction, so
    // neighbouring faces agree wherever their lattices overlap.
    _tileAt(f, tx, tz) {
        const key = (f * NTILE + tz) * NTILE + tx;
        let t = this.tiles[key];
        if (t) return t;
        t = { f, tx, tz, H: new Float32Array(TILE * TILE), P: null, M: null, Pp: null, Mp: null, row: 0 };
        const tmp = this._tmp, g = this._g;
        for (let j = 0; j < TILE; j++) for (let i = 0; i < TILE; i++) {
            const cx = -CHART_HALF + (tx * TILE + i - GM) * GS, cz = -CHART_HALF + (tz * TILE + j - GM) * GS;
            chartToGeo(f, cx, cz, g);
            t.H[j * TILE + i] = this._terrain(g[0] * R, g[1] * R, g[2] * R, 0, tmp);
        }
        this.tiles[key] = t; return t;
    }
    // which tile (and fractional node coordinates) holds direction d? writes this._c = {x: node x, z: node z, f: face}
    _locate(dx, dy, dz) {
        const f = faceOfGeo(dx, dy, dz), c = this._c; geoToChart(f, dx, dy, dz, c);
        c.f = f; c.fx = (c.x + CHART_HALF) / GS + GM; c.fz = (c.z + CHART_HALF) / GS + GM; return c;
    }
    _nodeH(f, i, j) { const tx = (i / TILE) | 0, tz = (j / TILE) | 0; return this._tileAt(f, tx, tz).H[(j - tz * TILE) * TILE + (i - tx * TILE)]; }
    // bilinear coarse height at a unit direction
    hBilDir(dx, dy, dz) {
        const c = this._locate(dx, dy, dz), f = c.f, fx = c.fx, fz = c.fz, ix = Math.floor(fx), iz = Math.floor(fz), a = fx - ix, b = fz - iz;
        return (this._nodeH(f, ix, iz) * (1 - a) + this._nodeH(f, ix + 1, iz) * a) * (1 - b) + (this._nodeH(f, ix, iz + 1) * (1 - a) + this._nodeH(f, ix + 1, iz + 1) * a) * b;
    }
    _ensureClimate(t) {
        if (t.P) return;
        while (!t.P) this._ensureClimateStep(t, 1e9);
    }
    // Step a unit direction `len` units along the direction the air came FROM (upwind) at its own latitude. Writes into out[0..2]; returns nothing.
    _stepUpwind(px, py, pz, len, out, o) {
        const w = this._w || (this._w = [0, 0]); this._windAt(px, py, pz, w);
        const cl = Math.sqrt(Math.max(1e-12, 1 - py * py)), sl = py;
        const Ex = pz / cl, Ez = -px / cl, Nx = -sl * px / cl, Ny = cl, Nz = -sl * pz / cl; // east / north unit vectors at the point
        // the air at this point moves with velocity (w[0] east, -w[1] north); upwind is the opposite: -w[0] east, +w[1] north
        const de = -w[0] * len, dn = w[1] * len, m = Math.hypot(de, dn);
        if (m < 1e-9) { out[0] = px; out[1] = py; out[2] = pz; return; }
        const tx = (de * Ex + dn * Nx) / m, ty = (dn * Ny) / m, tz = (de * Ez + dn * Nz) / m, th = m / R, c = Math.cos(th), s = Math.sin(th);
        let x = px * c + tx * s, y = py * c + ty * s, z = pz * c + tz * s; const il = 1 / Math.sqrt(x * x + y * y + z * z);
        out[0] = x * il; out[1] = y * il; out[2] = z * il;
    }
    // Moisture transport: march air from far upwind toward the node, recharging over sea, drying over land and
    // dropping rain when forced uphill. Returns annual rainfall (mm) and the arriving moisture fraction.
    // (dx, dy, dz) is the node's unit direction. The upwind path follows the wind of whatever latitude it is passing over.
    _marchDir(dx, dy, dz, res) {
        const lat = Math.asin(dy > 1 ? 1 : (dy < -1 ? -1 : dy));
        const Pz = this._zonalRainAt(dx, dy, dz);
        const path = this._path, tmp = this._pt || (this._pt = [0, 0, 0]);
        const K = MARCH_D.length;
        // build the path from the node outward (index K-1 = the node itself, index 0 = farthest), then one more point at 200000 for prevH
        path[(K - 1) * 3] = dx; path[(K - 1) * 3 + 1] = dy; path[(K - 1) * 3 + 2] = dz;
        for (let k = K - 2; k >= 0; k--) {
            this._stepUpwind(path[(k + 1) * 3], path[(k + 1) * 3 + 1], path[(k + 1) * 3 + 2], MARCH_D[k] - MARCH_D[k + 1], tmp);
            path[k * 3] = tmp[0]; path[k * 3 + 1] = tmp[1]; path[k * 3 + 2] = tmp[2];
        }
        this._stepUpwind(path[0], path[1], path[2], 200000 - MARCH_D[0], tmp);
        let M = 0.5, oro = 0, prevH = this.hBilDir(tmp[0], tmp[1], tmp[2]);
        const Tsea = TerrainCore.tempSeaLevel(lat);
        const Mocean = clamp(0.38 + 0.8 * (Tsea + 12) / 45, 0.3, 1.05);
        for (let k = 0; k < K; k++) {
            const dl = MARCH_DL[k], h = this.hBilDir(path[k * 3], path[k * 3 + 1], path[k * 3 + 2]);
            if (h <= 0) { M += (Mocean - M) * (1 - Math.exp(-dl / 22000)); oro *= 0.5; }
            else {
                const cap = Math.exp(-h / 3600);
                let rain = 0;
                if (M > cap) { rain = M - cap; M = cap; }
                const rise = Math.max(0, h - prevH) / dl;
                const lift = M * (1 - Math.exp(-rise * OROG_K));          // forced ascent squeezes out extra rain
                M -= lift * OROG_DEP; rain += lift * OROG_DEP;
                oro = oro * Math.exp(-dl / 9000) + rain;
                M += (0.42 - M) * (1 - Math.exp(-dl / 100000)) * 0.5;  // evapotranspiration recycling
                M *= Math.exp(-dl / 300000);                           // continental drying
            }
            prevH = h;
        }
        const warm = clamp(0.35 + 0.65 * (Tsea + 12) / 40, 0.3, 1.1);
        const P = Pz * (RAIN_A + RAIN_B * M) + oro * OROG_MULT * warm * (0.4 + 0.6 * Math.min(1, Pz / 400));
        res[0] = P; res[1] = M;
    }
    _ensureClimateStep(t, ms) {
        if (t.P) return;
        if (!t.Pp) { t.Pp = new Float32Array(TILE * TILE); t.Mp = new Float32Array(TILE * TILE); t.row = 0; }
        const res = [0, 0], t0 = performance.now(), g = this._g;
        while (t.row < TILE && performance.now() - t0 < ms) {
            const j = t.row++;
            for (let i = 0; i < TILE; i++) {
                const cx = -CHART_HALF + (t.tx * TILE + i - GM) * GS, cz = -CHART_HALF + (t.tz * TILE + j - GM) * GS;
                chartToGeo(t.f, cx, cz, g);
                this._marchDir(g[0], g[1], g[2], res); t.Pp[j * TILE + i] = res[0]; t.Mp[j * TILE + i] = res[1];
            }
        }
        if (t.row >= TILE) { t.P = t.Pp; t.M = t.Mp; t.Pp = t.Mp = null; }
    }
    // Incremental pre-computation so walking into new country never stalls: call every frame with the player's unit direction.
    // Does at most one small unit of work (one height tile, or a few rows of a rainfall tile) per call. Returns true if work remains.
    warm3(dx, dy, dz, maxMs) {
        const t0 = performance.now();
        const c0 = this._locate(dx, dy, dz), f0 = c0.f, cx0 = c0.x, cz0 = c0.z, g = this._g, tl = TILE * GS, lim = R * 1.45;
        const up = this._up || (this._up = [0, 0, 0]);
        for (let ring = 0; ring <= 3; ring++) {
            for (let dj = -ring; dj <= ring; dj++) for (let di = -ring; di <= ring; di++) {
                if (Math.max(Math.abs(di), Math.abs(dj)) !== ring) continue;
                chartToGeo(f0, clamp(cx0 + di * tl, -lim, lim), clamp(cz0 + dj * tl, -lim, lim), g);
                const gx = g[0], gy = g[1], gz = g[2];
                const c = this._locate(gx, gy, gz), f = c.f, tx = clamp(Math.floor(c.fx / TILE), 0, NTILE - 1), tz = clamp(Math.floor(c.fz / TILE), 0, NTILE - 1);
                const key = (f * NTILE + tz) * NTILE + tx;
                const t = this.tiles[key];
                if (!t) { this._tileAt(f, tx, tz); return true; }
                if (ring <= 1 && !t.P) {
                    // make sure the upwind height tiles exist first (one per call)
                    let px = gx, py = gy, pz = gz;
                    for (let k = 1; k <= 3; k++) {
                        this._stepUpwind(px, py, pz, tl, up); px = up[0]; py = up[1]; pz = up[2];
                        const u = this._locate(px, py, pz), ux = clamp(Math.floor(u.fx / TILE), 0, NTILE - 1), uz = clamp(Math.floor(u.fz / TILE), 0, NTILE - 1);
                        if (!this.tiles[(u.f * NTILE + uz) * NTILE + ux]) { this._tileAt(u.f, ux, uz); return true; }
                    }
                    this._ensureClimateStep(t, maxMs ? Math.max(1, maxMs - (performance.now() - t0)) : 4); return true;
                }
            }
        }
        return false;
    }
    // bilinear rainfall (mm/yr) and arrival moisture at a unit direction
    rainDir(dx, dy, dz, res) {
        const c = this._locate(dx, dy, dz), f = c.f, fx = c.fx, fz = c.fz, ix = Math.floor(fx), iz = Math.floor(fz), a = fx - ix, b = fz - iz;
        let P = 0, M = 0;
        for (let k = 0; k < 4; k++) {
            const di = k & 1, dj = k >> 1, jx = ix + di, jz = iz + dj;
            const tx = (jx / TILE) | 0, tz = (jz / TILE) | 0;
            const t = this._tileAt(f, tx, tz); this._ensureClimate(t);
            const o = (jz - tz * TILE) * TILE + (jx - tx * TILE);
            const wgt = (di ? a : 1 - a) * (dj ? b : 1 - b); P += t.P[o] * wgt; M += t.M[o] * wgt;
        }
        res[0] = P; res[1] = M;
    }

    // ------------------------------------------------------------ wetness / hostile (hostile3 is used by valley_sites.js) ----
    wetness3(X, Y, Z) { const r = this._wr || (this._wr = [0, 0]); this.rainDir(X / R, Y / R, Z / R, r); return clamp(r[0] / 1500, 0, 1); }
    isHostile3(X, Y, Z) {
        if ((this.N(X, Y, Z, 0.00005, 9000, 9000) + 1) / 2 > 0.62 && this.wetness3(X, Y, Z) < 0.18) return true; // dune seas
        if ((this.N(X, Y, Z, 0.00004, -6000, -6000) + 1) / 2 > 0.74) return true;                           // spire fields
        return false;
    }
    // ------------------------------------------------------------ full sample ----
    // Returns height plus climate, biome id and colour in o (colour r,g,b in 0..1).
    // Split in two so callers can cache the expensive, smooth part on a coarse lattice and add the cheap fine detail per vertex:
    //   sample3(P,o)       = softCap(o.hs + microAt3(P,o.rough))
    //   sampleSmooth3(P,o) = everything but the micro relief; sets o.hs, o.rough, o.pre (climate for classify3)
    microAt3(X, Y, Z, rough) {
        const nz = this.nz;
        // v44: bolder ground texture - a 250-unit mound octave on top of the old three (mounds, tussocks, rocky bumps)
        const base = nz.n3(X * 0.0042 + 17, Y * 0.0042 + 17, Z * 0.0042 + 17) * 6.0 + nz.n3(X * 0.006, Y * 0.006, Z * 0.006) * 2.6 + nz.n3(X * 0.018 + 40, Y * 0.018 + 40, Z * 0.018 + 40) * 1.1 + nz.n3(X * 0.032 + 80, Y * 0.032 + 80, Z * 0.032 + 80) * 0.35;
        // v64: variety. The land read as smooth because nothing lived between the ~250-unit mounds and the macro landforms (>2 km).
        // Add broad rolling swells (~1.1 km), knolls (~450 units) and low rocky ribs, all scaled by a slowly varying regional ruggedness
        // so some country stays gentle and some is knobbly, broken and ridged.
        const reg = 0.5 + 0.5 * nz.n3(X * 0.00013 + 311, Y * 0.00013 + 311, Z * 0.00013 + 311);          // 0..1, ~15 km patches
        const v = 0.35 + 1.25 * reg * reg;
        const swell = nz.n3(X * 0.0009 + 101, Y * 0.0009 + 101, Z * 0.0009 + 101) * 26.0 + nz.n3(X * 0.0021 + 57, Y * 0.0021 + 57, Z * 0.0021 + 57) * 14.0;
        const rib = nz.n3(X * 0.0034 + 9, Y * 0.0034 + 9, Z * 0.0034 + 9);
        const ribs = (1.0 - Math.abs(rib)) * (1.0 - Math.abs(rib)) * 9.0 - 3.0;                         // sharp-crested low ridges / rock ribs
        return (base * 1.4 + (swell + ribs * (0.4 + reg)) * v) * rough;
    }
    sample3(X, Y, Z, o) {
        this.sampleSmooth3(X, Y, Z, o);
        const finalH = softCap(o.hs + this.microAt3(X, Y, Z, o.rough), MAX_MOUNTAIN_HEIGHT);
        o.height = finalH;
        return finalH;
    }

    // Extra landform variety (see sampleSmooth). Returns { dh: height added, chr: regional ruggedness 0..1 }.
    _variety(X, Y, Z, h, t) {
        const nz = this.nz, V = this._vr || (this._vr = { dh: 0, chr: 0 });
        const land = ss(8, 70, h) * (1 - ss(9500, 13000, h) * 0.75);
        // regional character, two overlapping scales so neighbouring regions differ and borders are irregular
        const chr = clamp(((this.N(X, Y, Z, 0.000026, 400, -400) + 1) * 0.5) * 0.65 + ((this.N(X, Y, Z, 0.00008, -90, 90) + 1) * 0.5) * 0.35, 0, 1);
        V.chr = chr;
        if (land < 0.002) { V.dh = 0; return V; }
        const wx = this.N(X, Y, Z, 0.00009, 55, 55) * 900, wy = this.N(X, Y, Z, 0.00009, 13, -77) * 900, wz = this.N(X, Y, Z, 0.00009, -55, -55) * 900;   // domain warp: no straight grain
        const px = X + wx, py = Y + wy, pz = Z + wz;
        const hills = this.N(px, py, pz, 0.00022, 0, 0) + 0.25 * this.N(px, py, pz, 0.0007, 11, -11) + 0.04 * this.N(px, py, pz, 0.0018, -5, 5);   // v39: longer, softer undulation
        const amp = 30 + 150 * chr * chr;
        let dh = hills * amp * 0.75;
        // v44 ERODED RELIEF: slope-damped ridged noise at 1-9 km wavelengths. Ridges fork into drainage-like valleys, valley floors stay smooth
        // and crests stay sharp, so the land reads as carved country (spurs, saddles, hollows) instead of soft blobs. A slow 'highland' field
        // raises the amplitude regionally so some areas are gentle downs and others are steep, deeply cut hill country.
        {
            const zN = this.nz;
            const hiland = ss(0.30, 0.85, (this.N(X, Y, Z, 0.000021, 133, -133) + 1) * 0.5) * 0.6;   // v61: gentler regional ruggedness
            const rgK = ss(150, 1400, t.ridgeU || 0);   // v60: on a boundary ridge the 1-9 km erosion detail stays FULL (gullies, spurs, hanging valleys cut into the crest) instead of fading out with height
            const rangeK = Math.max(rgK, ss(550, 1900, h));   // v61: carved relief belongs to ranges; lowlands/foothills stay smooth, so mountains stand out as ranges
            const A = (110 + 330 * chr) * (1 + 1.1 * hiland) * (1 + 0.9 * rgK) * (0.12 + 0.88 * rangeK) * (1 + 0.30 * (t.tY || 0) - 0.40 * (t.tO || 0) + 0.10 * (t.tG || 0)) * (1 - 0.65 * ss(1400, 4200, h) * (1 - rgK));   // other mountains already carry their own relief
            let sum = 0, norm = 0, a = 1, f = 1, gx = 0, gy = 0, gz = 0;
            for (let i = 0; i < 4; i++) {
                const fr = 0.00011 * f;
                const v = zN.nd3(px * fr + 210, py * fr + 210, pz * fr + 210);
                gx += zN.gx * a; gy += zN.gy * a; gz += zN.gz * a;
                const r = Math.pow(Math.max(0, 1 - Math.sqrt(v * v + 0.02)), 1.5);
                const dmp = 1 / (1 + 0.18 * (gx * gx + gy * gy + gz * gz));
                sum += a * r * dmp; norm += a; a *= 0.5; f *= 2.05;
            }
            // (sum/norm has mean ~0.196, sd ~0.10; centre it so the term adds relief but no net height, and clamp the tails)
            dh += clamp(sum / norm - 0.196, -0.14, 0.30) * A * 4.4 * 1;
        }
        // sharp spines / ridgelines in rugged country
        const rg = 1 - Math.abs(this.N(px, py, pz, 0.00055, 300, -300));
        dh += Math.pow(Math.max(0, rg), 2.2) * 45 * ss(0.50, 0.90, chr) * (0.2 + 0.8 * Math.max(ss(150, 1400, t.ridgeU || 0), ss(550, 1900, h)));   // v61: spines only in ranges
        // benches and terraces: stair-stepped slopes (flat treads, steep risers) where a third field says so
        const tm = ss(0.18, 0.55, this.N(X, Y, Z, 0.00003, -800, 800));
        if (tm > 0.001) {
            const step = 70 + 110 * ((this.N(X, Y, Z, 0.00005, 9, -9) + 1) * 0.5);
            const u = (hills * amp * 0.9 + h * 0.35) / step, f = u - Math.floor(u);
            const terr = (Math.floor(u) + ss(0.22, 0.78, f)) * step - (hills * amp * 0.9 + h * 0.35);
            dh += terr * tm * 0.05;
        }
        // escarpments: long fault-scarp cliffs along an iso-line of a slow field
        const sc = this.N(X, Y, Z, 0.00022, 700, -700);
        dh += (ss(-0.35, 0.35, sc) - 0.5) * (20 + 40 * ss(0.3, 0.8, chr)) * ss(0.0, 0.35, this.N(X, Y, Z, 0.00004, 50, -50) + 0.1);   // v39: wide soft swell instead of a fault-scarp cliff
        // gullies: narrow incised valleys wandering through hilly ground
        // v43: gullies / dells removed - they read as dry river beds
        // v61 KARST: closed sinkholes (dolines) and rounded cockpit hollows on karst crust, on gentle ground only
        if ((t.tK || 0) > 0.05 && h > 120 && h < 1400) {
            const dn = this.N(px, py, pz, 0.0011, 91, -91) * 0.5 + 0.5, pit = ss(0.64, 0.82, dn) * (1 - ss(700, 1400, h));
            dh -= pit * t.tK * 85;
        }
        V.dh = dh * land;
        if (t.cv > 0.05 && h + V.dh < 10) V.dh += (10 - (h + V.dh)) * ss(0.05, 0.12, t.cv);
        return V;
    }

    sampleSmooth3(X, Y, Z, o) {
        const t = this._t || (this._t = {});
        this._terrain(X, Y, Z, 1, t);
        const nz = this.nz;
        let h = t.h;
        // REGIONAL VARIETY: every region gets its own character (smooth rolling plains -> broken hills -> rugged badland-like country)
        // with benches/terraces, escarpments, gullies and sharp spines layered on, so slopes range from flat to cliff instead of one
        // uniform noise texture. Only wavelengths >= ~330 units live here (the chunk builder interpolates this smooth part on a lattice);
        // the finest detail stays in microAt().
        const vr = this._variety(X, Y, Z, h, t);
        h += vr.dh;
        // fine micro relief (kept coarse enough for the mesh to resolve); rugged regions get more of it, plains less
        const rough = (1.0 + ss(0, 2500, t.relief) * 0.9) * (0.65 + 0.95 * vr.chr) * (0.08 + 0.92 * ss(0, 70, Math.abs(h)));   // v44: micro relief fades near the shoreline so beaches / shallows stay clean
        // special landforms driven by arid/hot geology masks (need climate first)
        const rr = [0, 0]; this.rainDir(X / R, Y / R, Z / R, rr);
        let P = rr[0], M = rr[1];
        const lat = t.latRad, aLat = Math.abs(lat) * 57.29578;
        // preliminary temperature (sea-level + lapse) used for landform masks
        const Tsl = TerrainCore.tempSeaLevel(lat) + this.N(X, Y, Z, 0.00004, 17, 17) * 2.6 + this.N(X, Y, Z, 0.00015, -3, 9) * 1.2;
        const cont = ss(0.0, 0.16, t.cv);
        // coastal moderation: oceans pull temperature toward the zonal mean, and the interior's extremes are larger
        let Tc0 = Tsl - Math.max(0, h) * 0.0065;
        // --- arid landforms: dunes, rocky desert, badlands/mesas, spire fields, karst
        const dryness = 1 - ss(150, 520, P), hotness = ss(8, 22, Tsl - Math.max(0, h) * 0.0065);
        const duneR = (this.N(X, Y, Z, 0.00005, 9000, 9000) + 1) / 2, badR = (this.N(X, Y, Z, 0.00005, 6000, 6000) + 1) / 2;
        const pilR = (this.N(X, Y, Z, 0.00004, -6000, -6000) + 1) / 2, saltR = (this.N(X, Y, Z, 0.00007, -3000, 3000) + 1) / 2;
        const lowRelief = 1 - ss(250, 700, t.relief);
        const flatBase = cont * lowRelief * (1 - ss(1200, 2600, h));
        let duneF = ss(0.60, 0.74, duneR) * dryness * (1 - ss(0.3, 0.8, t.hot)) * flatBase * ss(-5, 8, Tc0);
        let badF = ss(0.62, 0.76, badR) * ss(0.25, 0.6, 1 - ss(250, 700, P)) * cont * lowRelief * ss(0, 14, Tc0);
        const badH = ss(0.50, 0.92, badR) * cont * lowRelief * (0.25 + 0.75 * (1 - ss(250, 800, P)));
        let badlandsHeight = 0;
        if (badH > 0.001) {
            const bN = (this.N(X, Y, Z, 0.00007, 0, 0) + 1) / 2, steps = 7, tS = bN * steps, tF = Math.floor(tS);
            badlandsHeight = (((tF + ss(0.0, 1.0, tS - tF)) / steps) * 0.35 + bN * 0.65) * 700 * badH;   // v39: soft benches, half the height
        }
        let pillarF = ss(0.74, 0.84, pilR) * dryness * hotness * flatBase;
        let karstF = ss(0.70, 0.82, pilR) * ss(1100, 1700, P) * ss(18, 24, Tc0) * flatBase * (0.25 + 1.5 * (t.tK || 0));   // v61: karst country is where the karst plates are
        let pillarH = 0;
        if (pillarF > 0.001 || karstF > 0.001) {
            const pwy = this.N(X, Y, Z, 0.00006, 1900, -1900) * 500, pwx = this.N(X, Y, Z, 0.00006, 7200, 7200) * 500, pwz = this.N(X, Y, Z, 0.00006, -7200, -7200) * 500;
            const pN = clamp((this.N(X + pwx, Y + pwy, Z + pwz, 0.00015, 0, 0) + 1) / 2, 0, 1);   // v44: clamp - the 3D noise can slightly exceed +-1, and pow(negative, 3.5) was a NaN height (holes in the mesh)
            pillarH = Math.pow(pN, 5.0) * 700 * pillarF + Math.pow(pN, 3.5) * 450 * karstF;   // v39: rounded buttes / karst hills, no 2.7 km spires
        }
        let duneH = 0;
        if (duneF > 0.001 && h > -100) {
            const w = Math.abs(Math.sin(613 * Math.atan2(X, Z) + this.N(X, Y, Z, 0.0009, 0, 0) * 3.2)) * (55 + Math.abs(this.N(X, Y, Z, 0.00006, 0, 0)) * 90);
            duneH = w * duneF;
        }
        // lava fields near hotspots / arcs: rough black ground
        const lavaN = (this.N(X, Y, Z, 0.00012, 8, -8) * 0.5 + 0.5);
        const lavaF = ss(0.15, 0.55, t.hot) * ss(0.45, 0.62, lavaN) * (t.volc < 500 ? 1 : 0);
        o.hs = h + badlandsHeight + pillarH + duneH; o.rough = rough;
        // is there a big range directly upwind? (drives the named rain-shadow desert)
        let ridgeUp = 0;
        { const hh0 = this.hBilDir(X / R, Y / R, Z / R), up = this._up2 || (this._up2 = [0, 0, 0]);
          let ax = X / R, ay = Y / R, az = Z / R;
          for (let k = 1; k <= 4; k++) { this._stepUpwind(ax, ay, az, 12000, up); ax = up[0]; ay = up[1]; az = up[2]; const hu = this.hBilDir(ax, ay, az); if (hu - hh0 > ridgeUp) ridgeUp = hu - hh0; } }
        o.volcH = t.volc;
        o.pre = { ridgeUp, P, M, Tsl, t, lat, aLat, duneF, badF, pillarF, karstF, lavaF, saltR, cont };
        return o.hs;
    }

    // Biome / colour for a point whose final (post-river) height is known. Fills o.
    classify3(X, Y, Z, finalH, o) {
        const pre = o.pre, t = pre.t, nz = this.nz;
        const M = pre.M, aLat = pre.aLat, h = finalH;
        // v63 BIOME TRANSITIONS: the climate that picks the biome is jittered by smooth noise at two scales, so biome borders become ragged, interleaved
        // belts (patches and tongues of the neighbour) instead of clean iso-lines; the jitter vanishes at sea level / on bare ocean.
        const jn1 = this.N(X, Y, Z, 0.00011, 410, -410), jn2 = this.N(X, Y, Z, 0.00042, -77, 77), jn3 = this.N(X, Y, Z, 0.00016, 19, 91);
        const P = pre.P * (1 + 0.26 * jn1 + 0.12 * jn2);
        const rgb = o.rgb || (o.rgb = [0, 0, 0]);
        const Tc = pre.Tsl + 1.3 * jn3 + 0.5 * jn2 - Math.max(0, h) * 0.0065;                      // local mean temperature (C)
        const temp01 = clamp((Tc + 15) / 50, 0, 1);
        const lowP = P < 1 ? 1 : P;
        const moist01 = clamp(lowP / (lowP + 650), 0, 1);
        o.temp = temp01; o.moist = moist01; o.rain = P; o.tc = Tc; o.swamp = 0; o.crystal = null;
        const relief = t.relief + t.ancient, shadow = 1 - clamp(P / Math.max(80, this._zonalRainAt(X / R, Y / R, Z / R) * 1.4), 0, 1);
        const col = [0, 0, 0];
        let id;
        if (h < WATER_LEVEL) {
            // ---------------- OCEAN ----------------
            const depth = WATER_LEVEL - h, tSea = pre.Tsl;
            const warm = ss(17, 24, tSea), cold = 1 - ss(2, 10, tSea), polar = 1 - ss(-6, 2, tSea);
            let c0 = hexRGB(0xd6c093), c1 = hexRGB(0x4a4238);
            const k = Math.min(1, depth / 400);
            col[0] = mix(c0[0], c1[0], k); col[1] = mix(c0[1], c1[1], k); col[2] = mix(c0[2], c1[2], k);
            if (t.volc > 900) id = B.SEA_VOLCANO;
            else if (t.guyotK > 0 && depth < 900 && warm > 0.5 && depth < 80) id = B.ATOLL;
            else if (t.guyotK > 0 && depth > 150) id = B.GUYOT;
            else if (depth < 6 && P > 700 && tSea > 5 && pre.cont > -0.5 && t.cv > -0.04) id = B.TIDAL_FLATS;
            else if (depth < 55) {
                const rock = this.N(X, Y, Z, 0.003, 5, -5);
                if (polar > 0.6) id = B.POLAR_SHELF;
                else if (warm > 0.55 && P > 250 && rock > -0.25 && t.cv < 0.06) id = B.REEF;
                else if (warm > 0.2 && rock < 0.15) id = B.SEAGRASS;
                else if (cold > 0.3 && rock > -0.1) id = B.KELP;
                else id = B.ROCKY_REEF;
            } else if (depth < 260) id = polar > 0.6 ? B.POLAR_SHELF : B.SHELF;
            else if (t.canyon > 0.3 && depth < 3500) id = B.CANYON_SUB;
            else if (t.trenchAmt > 0.3 && depth > 4800) id = t.seep > 0.5 ? B.SEEP : B.TRENCH;
            else if (t.ridgeAmt > 0.15 && t.riftAmt > 0.25 && t.ventN > 0.42) id = B.RIFT_SEA;
            else if (t.ridgeAmt > 0.35) id = t.ventN > 0.6 ? B.VENT : B.RIDGE;
            else if (t.arcAmt > 0.2 && depth < 3000) id = B.ARC_SEA;
            else if (t.seamount > 500 && depth < 4000) id = B.SEAMOUNT;
            else if (t.ocPlat > 700) id = B.OC_PLATEAU;
            else if (depth < 3300 && t.cv > -0.5) id = B.SLOPE;
            else if (t.ventN > 0.8 && depth > 2800) id = B.VENT;
            else if (Math.abs(t.abyHills) > 90) id = B.HILLS_SEA;
            else id = (this.N(X, Y, Z, 0.00003, -5, 5) > 0.35) ? B.SARGASSO : B.ABYSSAL;
            const bi = BIOMES[id];
            const dark = id === B.VENT || id === B.RIDGE || id === B.RIFT_SEA || id === B.SEA_VOLCANO || id === B.TRENCH || id === B.ARC_SEA || id === B.SEEP;
            const bk = id === B.REEF || id === B.ATOLL ? 0.75 : (id === B.KELP || id === B.SEAGRASS || id === B.ROCKY_REEF ? 0.7 : (dark ? 0.8 : (id === B.SHELF || id === B.POLAR_SHELF || id === B.SLOPE ? 0.3 : 0.55)));
            for (let c = 0; c < 3; c++) col[c] = mix(col[c], bi.rgb[c], bk);
            if (id === B.REEF || id === B.ATOLL) { const cn = this.N(X, Y, Z, 0.02, 3, 3) * 0.5 + 0.5; col[0] = mix(col[0], 0.86, cn * 0.35); col[1] = mix(col[1], 0.52, cn * 0.35); col[2] = mix(col[2], 0.50, cn * 0.35); }
            if (id === B.VENT) { const m = 0.4 * ss(0.6, 0.75, t.ventN); col[0] = mix(col[0], 0.14, m); col[1] = mix(col[1], 0.10, m); col[2] = mix(col[2], 0.08, m); }
            o.prop = id === B.VENT || id === B.RIFT_SEA || id === B.ARC_SEA ? 10 : bi.prop;
            if (id === B.SHELF) o.prop = depth < 40 ? 5 : 0;
            if (id === B.SEA_VOLCANO) o.prop = 0;
        } else if (h < WATER_LEVEL + 15) {
            // ---------------- COAST ----------------
            const tSea = pre.Tsl;
            if (tSea < -6) id = B.FROZEN_COAST;
            else if (tSea > 21 && P > 1700 && relief < 200) id = B.DELTA;
            else if (tSea > 17 && P > 800 && relief < 300) id = B.MANGROVE;
            else if (tSea > 2 && P > 450 && relief < 300 && t.cv < 0.3) id = B.SALT_MARSH;
            else if (relief > 700 || t.arcAmt > 0.3) id = B.ROCKY_SHORE;
            else id = B.SANDY_SHORE;
            const bi = BIOMES[id]; col[0] = bi.rgb[0]; col[1] = bi.rgb[1]; col[2] = bi.rgb[2]; o.prop = id === B.MANGROVE || id === B.SALT_MARSH ? 4 : 0;
            if (id === B.MANGROVE || id === B.SALT_MARSH || id === B.DELTA) o.swamp = id === B.DELTA ? 0.0 : 0.55;
        } else {
            // ---------------- LAND ----------------
            lutColor(Tc, P, col);
            const geo = this.N(X, Y, Z, 0.000022, 21, -21);                  // rock-type field: <0 sedimentary, >0 granitic
            const snowT = -5.5, treeT = 0.5;                                          // annual mean C: permanent snow / tree line
            const snowW = ss(snowT + 1.5, snowT - 2.5, Tc);
            const alpineW = ss(treeT + 4, treeT - 1.5, Tc);                           // bare rock zone above the trees
            let tmp, rock = geo > 0.1 ? hexRGB(0x6a6864) : (geo < -0.25 ? hexRGB(0x8a7a62) : hexRGB(0x58544f));
            const volcRock = t.hot > 0.15 || t.arcAmt > 0.25;
            if (volcRock) rock = hexRGB(0x3d3835);
            const climB = BIOMES; let prop = 0;
            // ----- choose the base lowland biome from climate
            const Pl = P;
            const west = 1;
            if (Tc < -13) id = Pl > 120 ? B.ICE_SHEET : B.POLAR_DESERT;
            else if (Tc < -6) id = Pl > 300 ? B.TUNDRA : (Pl > 130 ? B.ARCTIC : B.POLAR_DESERT);
            else if (Tc < -1) id = Pl > 650 ? B.TAIGA : (Pl > 330 ? B.LARCH : (Pl > 160 ? B.COLD_STEPPE : B.COLD_DESERT));
            else if (Tc < 4) id = Pl > 900 ? B.TAIGA : (Pl > 520 ? B.MIXED : (Pl > 260 ? B.COLD_STEPPE : B.COLD_DESERT));
            else if (Tc < 12) id = Pl > 2100 ? B.TEMP_RAIN : (Pl > 1150 ? B.MIXED : (Pl > 650 ? B.DECIDUOUS : (Pl > 450 && relief < 500 ? B.PLAINS : (Pl > 300 ? B.STEPPE : B.COLD_DESERT))));
            else if (Tc < 19) id = Pl > 2300 ? B.SUBTROP_FOREST : (Pl > 1250 ? B.DECIDUOUS : (Pl > 800 ? B.PLAINS : (Pl > 450 ? (aLat > 28 && aLat < 46 && M > 0.35 ? B.MEDITERR : B.STEPPE) : (Pl > 230 ? B.SCRUBLAND : B.DESERT_SCRUB))));
            else id = Pl > 2400 ? B.JUNGLE : (Pl > 1500 ? B.SEASONAL : (Pl > 950 ? B.WOOD_SAV : (Pl > 520 ? B.SAVANNAH : (Pl > 280 ? B.THORN : B.DESERT_SCRUB))));
            // rain shadow: a deliberately named, distinct dry land on the lee of a range
            if (pre.ridgeUp > 1300 && Pl < 480 && Tc > 2 && relief < 1800 && (id === B.DESERT_SCRUB || id === B.COLD_DESERT || id === B.THORN || id === B.SCRUBLAND || id === B.STEPPE)) id = B.RAINSHADOW;
            prop = BIOMES[id].prop;
            if (Tc > 1 && Tc < 11 && Pl > 750 && Pl < 1700 && h > 220 && relief < 1000 && (this.N(X, Y, Z, 0.00009, 55, -55) > 0.15) && id !== B.TEMP_RAIN) { id = B.HEATH; const hc = hexRGB(0x7f7a52); for (let c = 0; c < 3; c++) col[c] = mix(col[c], hc[c], 0.45); }
            prop = BIOMES[id].prop;
            // wetlands: sodden flat lowlands in humid climates
            const wetN = this.N(X, Y, Z, 0.00012, 300, 300) * 0.5 + 0.5;
            let swampW = ss(1000, 1700, Pl) * ss(2, 12, Tc) * (1 - ss(300, 700, relief)) * (1 - ss(150, 500, h)) * ss(0.5, 0.68, wetN);
            if (Tc > 14 && swampW > 0.35) { id = B.SWAMP; prop = 4; }
            else if (Tc < 6 && Pl > 450 && relief < 350 && h < 450 && wetN > 0.66) { id = B.MUSKEG; prop = 4; swampW = Math.max(swampW, 0.5); }
            else if (swampW > 0.3 && h < 70) { id = B.FLOODPLAIN; prop = 4; }
            o.swamp = (id === B.SWAMP || id === B.MUSKEG || id === B.FLOODPLAIN) ? Math.min(1, swampW * 1.6) : 0;
            if (o.swamp > 0.03) { const sA = (this.N(X, Y, Z, 0.0035, 400, 400) + 1) * 0.5, sc = hexRGB(0x3a2e1c), sm = hexRGB(0x56452a); const k = ss(0.3, 0.7, sA); for (let c = 0; c < 3; c++) col[c] = mix(col[c], mix(sc[c], sm[c], k), Math.min(1, o.swamp * 1.4)); }
            // plains pop
            if (id === B.PLAINS) { const k = 0.45; const pc = BIOMES[B.PLAINS].rgb; for (let c = 0; c < 3; c++) col[c] = mix(col[c], pc[c], k); }
            // ----- arid landforms
            const mix2 = (hex, k) => { const r = hexRGB(hex); for (let c = 0; c < 3; c++) col[c] = mix(col[c], r[c], k); };
            if (pre.badF > 0.02 && relief < 700) { const bandT = (Math.floor(finalH / 9) % 2 === 0) ? 0 : 1; const bc = mix2(bandT ? 0x8a5228 : 0xc9915a, ss(0.02, 0.5, pre.badF)); if (pre.badF > 0.3) { id = (this.N(X, Y, Z, 0.0001, 0, 0) > 0.2 && h > 500) ? B.MESAS : B.BADLANDS; prop = 3; } }
            if (pre.pillarF > 0.02) { mix2(0x7ecbd6, ss(0.02, 0.5, pre.pillarF)); if (pre.pillarF > 0.3) { id = B.SPIRES; prop = 6; } }
            if (pre.karstF > 0.05 && pre.karstF > pre.pillarF) { mix2(0x58844a, ss(0.05, 0.5, pre.karstF) * 0.6); if (pre.karstF > 0.3) { id = B.KARST; prop = 9; } }
            if (pre.duneF > 0.05) { mix2(0xdcbb7e, ss(0.1, 0.6, pre.duneF)); if (pre.duneF > 0.35) { id = B.DUNES; prop = 3; } }
            // hamada (stony desert) and salt pans in dry basins
            if ((id === B.DESERT_SCRUB || id === B.RAINSHADOW || id === B.COLD_DESERT) && geo > 0.15 && pre.duneF < 0.2) { id = B.HAMADA; prop = 3; mix2(0xa88a62, 0.5); }
            if ((id === B.DESERT_SCRUB || id === B.RAINSHADOW || id === B.HAMADA || id === B.COLD_DESERT || id === B.PLATEAU) && pre.saltR > (h > 1800 ? 0.7 : 0.8) && relief < 400) {
                const k = ss(h > 1800 ? 0.7 : 0.8, 0.88, pre.saltR);
                mix2(0xe9e6dc, k); if (k > 0.5) { id = h > 2200 ? B.ALTIPLANO : B.SALT_FLATS; prop = 0; }
            }
            // ----- volcanic ground
            if (pre.lavaF > 0.1) { mix2(0x1f1c1b, ss(0.1, 0.7, pre.lavaF)); if (pre.lavaF > 0.45) { id = B.LAVA; prop = 17; } }
            // v61 rock character: dark basaltic ground on young crust, pale weathered ground on old, cool grey granite on glaciated
            if ((t.tY || 0) > 0.05) mix2(0x4a4640, 0.16 * t.tY); if ((t.tO || 0) > 0.05) mix2(0xb9a98a, 0.12 * t.tO); if ((t.tG || 0) > 0.05) mix2(0x9aa39a, 0.12 * t.tG);
            if (t.hot > 0.25 && t.volc < 500 && pre.lavaF < 0.4 && Pl > 300 && t.calderaK < 0.1 && (t.hot > 0.6) && Tc > -2) { /* fertile volcanic slopes keep climate colour */ }
            if (t.hot > 0.3 && P < 300 && Tc > 0 && pre.lavaF < 0.45 && t.volc < 500) { mix2(0x6a625a, 0.5 * ss(0.3, 0.7, t.hot)); id = B.ASH; prop = 14; }
            if (t.hot > 0.45 && t.volc < 500 && relief < 700 && (this.N(X, Y, Z, 0.0003, 9, -9) > 0.35)) { id = B.FUMAROLE; prop = 17; mix2(0x9a8f58, 0.55); }
            if (t.calderaK > 0.35 && h > 40) { id = B.FUMAROLE; prop = 17; mix2(0x9a8f58, 0.6); }
            // ----- tectonic landforms
            if (t.riftAmt > 0.25 && t.c1 && relief < 900) { id = (Pl > 900) ? B.RIFT : B.RIFT; mix2(0xb89a62, 0.35 * ss(0.25, 0.7, t.riftAmt)); prop = 8; }
            if (t.riftAmt < 0.25 && t.riftAmt > 0.04 && t.c1 && t.landSide > 0.5 && relief < 1400 && h > 200) { id = B.RIFT_WALL; prop = 17; mix2(0x8a6a4a, 0.35); }
            if (t.plateau > 0.35 && relief < 1900) {
                if (Tc < -4 && Pl < 300) { id = B.PLATEAU_COLD; prop = 0; mix2(0xb4b8b8, 0.4); }
                else if (Pl < 420) { id = B.PLATEAU; prop = 15; mix2(0xb8a878, 0.4); }
            }
            // ----- mountain zonation (driven by temperature: the same range climbs from jungle to ice)
            const mountainous = relief > 450;
            if (mountainous && h > 150 && Tc < 14) {
                if (alpineW > 0.02) {
                    const mm = ss(0.02, 0.9, alpineW);
                    for (let c = 0; c < 3; c++) col[c] = mix(col[c], rock[c] * (0.85 + 0.2 * (this.N(X, Y, Z, 0.002, 0, 0))), mm * 0.85);
                }
            }
            if (mountainous && Tc < treeT + 6 && Tc >= treeT && Pl > 450 && id !== B.TUNDRA && !(Tc < -1)) { /* handled below by treeline */ }
            // treeline zones
            if (relief > 700 && h > 400) {
                const wetEnough = Pl > 500;
                if (Tc >= treeT && Tc < treeT + 7 && Pl > 380) { id = Tc < treeT + 3 ? B.SUBALPINE : (Pl > 1300 && Tsl0(pre) > 18 ? B.CLOUD : B.MONTANE); prop = 12; if (id === B.CLOUD) prop = 9; }
                else if (Tc >= treeT + 7 && Tc < 14 && Pl > 800 && Tsl0(pre) > 20) { id = B.CLOUD; prop = 9; }
                else if (Tc >= treeT + 7 && Tc < 16 && Pl > 450) { id = B.FOOTHILLS; prop = 11; }
                else if (Tc >= snowT - 1 && Tc < treeT) {
                    if (relief > 2600 && t.mntDetail > 0.7) { id = B.CRAGS; prop = 17; }
                    else if (relief > 1900 && t.mntDetail > 0.5) { id = B.SCREE; prop = 17; }
                    else if (geo > 0.2 && relief > 1200) { id = B.GRANITE; prop = 0; }
                    else if (Pl > 500) { id = B.ALPINE_MEADOW; prop = 13; const mc = hexRGB(0x6f9a52); for (let c = 0; c < 3; c++) col[c] = mix(col[c], mc[c], 0.55 * (1 - alpineW * 0.4)); }
                    else if (relief > 1500) { id = B.ALPINE; prop = 0; }
                    else { id = B.ALPINE_TUNDRA; prop = 14; }
                }
            }
            if (Tc < snowT - 1 && h > 400) {
                if (Pl > 380 * (1 - 0.3 * (t.tG || 0)) && relief < 2600 && t.mntDetail < 0.55) { id = B.GLACIER; prop = 0; }
                else if (relief > 1800) { id = B.SNOW_PEAKS; prop = 0; }
                else if (Pl > 130) { id = id; }
            }
            if (id === B.GRANITE) { /* granite domes keep granite colour */ }
            if ((id === B.CRAGS || id === B.SCREE || id === B.ALPINE || id === B.GRANITE) && volcRock) { id = B.VOLC_HIGH; prop = 12; }
            // snow cover (continuous): needs both cold and some moisture; dry cold ground stays bare rock
            if (snowW > 0.001) {
                const dryK = ss(60, 260, P + (h > 3500 ? 120 : 0));
                const sw = snowW * (0.35 + 0.65 * dryK);
                for (let c = 0; c < 3; c++) col[c] = mix(col[c], (id === B.GLACIER ? [0.80, 0.90, 0.96] : [0.94, 0.96, 0.98])[c], sw);
            }
            if (id === B.ICE_SHEET || id === B.TUNDRA || id === B.POLAR_DESERT) { const k = id === B.ICE_SHEET ? 0.8 : (id === B.TUNDRA ? 0.4 : 0.25); const r = hexRGB(BIOMES[id].hex); for (let c = 0; c < 3; c++) col[c] = mix(col[c], r[c], k); }
            // hidden valleys: lush, slightly luminous, with drifting teal / emerald / gold tints and fluorite crystals among the trees
            if (t.valleyK > 0.45 && Tc > -6 && t.volc < 160) {
                const vk = ss(0.45, 0.85, t.valleyK), tn = (this.N(X, Y, Z, 0.0021, 77, -77) + 1) * 0.5, tm = (this.N(X, Y, Z, 0.0007, -31, 31) + 1) * 0.5;
                const a = hexRGB(0x3fcf84), b2 = hexRGB(0x38b8c4), g2 = hexRGB(0xc9d76a);
                for (let c = 0; c < 3; c++) col[c] = mix(col[c], mix(mix(a[c], b2[c], ss(0.35, 0.8, tm)), g2[c], ss(0.7, 0.95, tn) * 0.6), 0.78 * vk);
                id = B.ENCHANTED_VALLEY; prop = 2;
            }
            // volcanic cones
            if (t.volc > 500) { id = B.VOLCANO; prop = 0; const vc = hexRGB(0x2b2927); const k = ss(200, 700, t.volc); for (let c = 0; c < 3; c++) col[c] = mix(col[c], vc[c], k); }
            else if (t.volc > 160 && relief < 700 && Tc > 5 && P > 700 && h < 300 && t.hot > 0.1 && t.cv < 0.2) { id = B.VOLC_ISLAND; }
            o.prop = prop;
        }
        o.biomeId = id; o.biomeName = BIOMES[id].name; o.biomeClass = BIOMES[id].cls;
        rgb[0] = col[0]; rgb[1] = col[1]; rgb[2] = col[2];
        return id;
    }
}
function Tsl0(pre) { return pre.Tsl; }

