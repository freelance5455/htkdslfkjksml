# v69 - the storm becomes a dive (story step 2 of 6)
Not run in a browser; `game.js` passes a syntax check. Playtest the voyage first.

## What changed
- **The storm is now a stop on the voyage**, at 25% of the route (it used to be a 14-second visual at 60%). The AI warns of the front, then gives the order to dive ("...your survival takes absolute priority here. Go, go!"). That is the first plant of the line the ending depends on.
- **Hydrothermal vents on the seabed** (4 glowing vents around a rocky mound). Near them the player warms up quickly; away from them warmth drains (faster at the surface), floored at 5 so it never kills. The AI nags if the player lingers on the surface or swims aimlessly.
- **The storm holds at full strength until the player has spent ~14 s warming at the vents**, then it fades. The AI lashes the boat to an islet boulder (a tether is drawn from the boat to the mound).
- **The union marker now stands beside the vents** (it used to be at the wreck stop). When the front passes, the AI points it out; the existing marker scan and artifact entry fire from there.
- **New order:** storm and marker (25%), then wreck + rhombus drone (45%, was 40%), then obelisk + disc (75%). The player cannot board the boat to continue until the front has cleared.
- Reloading mid-storm-stop puts the player at the cleared state, so nobody is stuck.
- The old `triggerVoyageStorm` is no longer called (left in place, unused).

## Still to do
3. Tribunal decree + the AI's confession (and tie in the diary pages / photo / locket). 4. Text fixes + disc audio file. 5. Early plants for the ending. 6. Post-swarm handoff.
