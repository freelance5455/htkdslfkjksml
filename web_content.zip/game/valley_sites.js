// =====================================================================================
// valley_sites.js - hidden valley CITY-STATE sites: finder + terrain shaper (pure maths, no three.js, no DOM).
// Shared by game.js (main thread height queries), chunk_core.js (worker terrain / scatter) and city_core.js (city generator).
//
// DETERMINISM / FACE INDEPENDENCE
//   * The world is cut into a coarse grid of cells on EACH cube face (SITE_GRID x SITE_GRID per face, ~155k units = ~36 km wide).
//     A cell is addressed by (home face, i, j) and owns at most ONE site. All randomness is hashed from (seed, face, i, j, salt),
//     never from the chart the player stands on, so every worker and the main thread get the identical site list.
//   * A site is stored as a UNIT DIRECTION on the sphere (+ numbers in ground units), not as chart coordinates. Each chart converts
//     it with geoToChart() when it needs it, so crossing a cube-face edge never re-rolls a site.
//   * Per-site local frame: (a, n) = ground units east / north of the site centre. A chart point maps into it through the chart's own
//     rotation (chartPsi) and ground-units-per-chart-unit scale at the site, so the valley and city look the same on every chart.
// v53 - THE CITY ADAPTS TO THE LAND (not the land to the city)
//   Before v53 a site was a stamped bowl: flat floor, added walls, a carved pass. Now the terrain stays what the terrain generator made it.
//   shapeSite() MEASURES the natural ground (a 60-unit height grid around the site) and derives from it
//     ft[i]  how far the dense city reaches toward angle i (follows ridges, spurs and gullies: it runs up gentle ground and stops at cliffs)
//     ww[i]  width of the sparse hillside belt beyond that
//     sg     a smoothed copy of the natural height: inside the city the real ground is pulled 60% toward it (mid-scale bumps are
//            taken out so buildings sit on it; the slopes, spurs and gullies stay) - the ONLY change made to the terrain, plus
//            a hub square (a levelled plateau of ~56 units with a soft shoulder, the way any town has a square)
//     passPts the gate road: a slope-aware walk from the footprint edge out toward lower, gentler ground (no gorge is cut)
// =====================================================================================
// =====================================================================================
import { PLANET_R, CHART_HALF, FACES, chartToGeo, geoToChart, chartPsi, faceOfGeo } from './planet_core.js';

export const SITE_GRID = 24;            // cells per face side (24 * 24 * 6 = 3456 cells)
export const MIN_SITES = 4, MAX_SITES = 40;   // every world has "a few"; never more than MAX
export const SITE_MIN_SEP = 42000;      // ground units between kept sites
export const CLUSTER_KM = 30;           // preferred league spacing (km); 1 km = 4250 units
const R = PLANET_R;
const ss = (a, b, x) => { const t = Math.max(0, Math.min(1, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
const clamp = (x, a, b) => x < a ? a : x > b ? b : x;

export function h32(a, b, c, d) {
    let h = Math.imul(a | 0, 0x27d4eb2d) ^ Math.imul(b | 0, 0x165667b1) ^ Math.imul(c | 0, 0x9e3779b1) ^ Math.imul(d | 0, 0x85ebca6b);
    h = Math.imul(h ^ (h >>> 15), 0x85ebca6b); h = Math.imul(h ^ (h >>> 13), 0xc2b2ae35); h ^= h >>> 16;
    return (h >>> 0) / 4294967296;
}
export function mulberry(seed) { let s = seed >>> 0; return () => { s = (s + 0x6D2B79F5) >>> 0; let t = s; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

// ---- local tangent frame at a unit direction: east, north (matches planet_core chartPsi) ----
export function localFrame(d, out) {
    const sl = d[1], cl = Math.sqrt(Math.max(1e-12, 1 - sl * sl)), sLon = d[0] / cl, cLon = d[2] / cl;
    out = out || { e: [0, 0, 0], n: [0, 0, 0] };
    out.e[0] = cLon; out.e[1] = 0; out.e[2] = -sLon;
    out.n[0] = -sl * sLon; out.n[1] = cl; out.n[2] = -sl * cLon;
    return out;
}
// local ground offset (a east, n north) -> unit direction (gnomonic, exact enough for < 100 km)
export function localToDir(site, a, n, out) {
    const f = site._f || (site._f = localFrame(site.dir)), d = site.dir, k = 1 / R;
    const x = d[0] + (f.e[0] * a + f.n[0] * n) * k, y = d[1] + (f.e[1] * a + f.n[1] * n) * k, z = d[2] + (f.e[2] * a + f.n[2] * n) * k;
    const il = 1 / Math.sqrt(x * x + y * y + z * z); out[0] = x * il; out[1] = y * il; out[2] = z * il; return out;
}

// ======================================================================================== FINDER
// One candidate -> measurements. T = TerrainCore. All heights are final (micro included) sample3 heights.
function makeProbe(T) {
    const o = {}, d = [0, 0, 0];
    return {
        h(dir, f, a, n) {   // height at local offset (a, n) from dir
            const e = f.e, nn = f.n, k = 1 / R;
            let x = dir[0] + (e[0] * a + nn[0] * n) * k, y = dir[1] + (e[1] * a + nn[1] * n) * k, z = dir[2] + (e[2] * a + nn[2] * n) * k;
            const il = R / Math.sqrt(x * x + y * y + z * z);
            return T.sample3(x * il, y * il, z * il, o);
        },
        hostile(dir) { return T.isHostile3(dir[0] * R, dir[1] * R, dir[2] * R); }
    };
}
const RF_MIN = 380, RF_MAX = 560;           // floor radius range (ground units; the player is 8.5 units tall, 4.25 units = 1 m)
// v50: a site no longer sits on whatever point the grid hashed to: it slides downhill into the nearest natural hollow (two passes, 3x3 samples),
// so the valley is built where the ground already dips and the city follows what is there.
function settleDir(probe, dir) {
    let d = dir, f = localFrame(d), h = probe.h(d, f, 0, 0);
    for (const step of [420, 210]) {
        let ba = 0, bn = 0, bh = h;
        for (let i = -1; i <= 1; i++) for (let j = -1; j <= 1; j++) {
            if (!i && !j) continue;
            const a = i * step, n = j * step, hh = probe.h(d, f, a, n) + 0.012 * Math.hypot(a, n);
            if (hh < bh - 4) { bh = hh; ba = a; bn = n; }
        }
        if (ba || bn) { const nd = [0, 0, 0]; localToDir({ dir: d, _f: f }, ba, bn, nd); d = nd; f = localFrame(d); h = probe.h(d, f, 0, 0); }
    }
    return d;
}
export function evalCandidate(T, probe, dir, rnd, strict) {
    { const f0 = localFrame(dir), g0 = probe.h(dir, f0, 0, 0); if (!(g0 > (strict ? 650 : 300)) || g0 > 5600) return null; }
    dir = settleDir(probe, dir);
    const f = localFrame(dir), h0 = probe.h(dir, f, 0, 0);
    if (!(h0 > (strict ? 650 : 300)) || h0 > 5600) return null;
    // stage 1: ring at 1000
    let mn = 1e9, mx = -1e9, sum = 0;
    for (let i = 0; i < 8; i++) { const a = i * Math.PI / 4 + 0.2, h = probe.h(dir, f, Math.cos(a) * 1000, Math.sin(a) * 1000); sum += h; if (h < mn) mn = h; if (h > mx) mx = h; }
    const mean = sum / 8;
    if (mn < (strict ? 380 : 120) || mx - mn > 2400) return null;
    // buildable share: how much of the ground within ~500 units is gentle enough to build on (slope at the 60-unit scale)
    let ok = 0, nb = 0;
    for (const rad of [300, 600]) for (let k = 0; k < 6; k++) {
        const a = k * Math.PI / 3 + rad * 0.007, x = Math.cos(a) * rad, z = Math.sin(a) * rad, hh = probe.h(dir, f, x, z);
        const sl = Math.hypot(probe.h(dir, f, x + 60, z) - hh, probe.h(dir, f, x, z + 60) - hh) / 60; nb++; if (sl < 0.8) ok++;
    }
    const bf = ok / nb; if (bf < (strict ? 0.5 : 0.25)) return null;
    // a valley sits inside higher ground: look at 1700 too
    let sum2 = 0; for (let i = 0; i < 6; i++) { const a = i * Math.PI / 3 + 0.5; sum2 += probe.h(dir, f, Math.cos(a) * 1700, Math.sin(a) * 1700); }
    const mean2 = sum2 / 6;
    const elev = clamp((mean - 500) / 2400, 0, 1), encl = clamp(((mean + mean2) / 2 - h0) / 320, -0.3, 1), relief = mx - mn, relS = 1 - clamp(Math.abs(relief - 750) / 950, 0, 1);
    return { dir, h0, mean, mn, mx, elev, bowl: encl, floorH: h0, bf, f, score1: 0.4 * elev + 0.25 * Math.max(0, encl) + 0.2 * relS + 0.15 * bf };
}
// stage 2: provisional dimensions + the gentlest natural walk out (the real footprint and gate are measured later, in shapeSite)
export function finishSite(T, probe, c, cellKey, seed, strict) {
    const rr = mulberry(Math.floor(h32(seed, cellKey[0], cellKey[1] * 977 + cellKey[2], 41) * 4294967295));
    const Rf = 520 + rr() * 120, rimR = Rf * 1.7, Rb = rimR + 360;
    let bestSlope = 1e9, best = 0; const a0 = rr() * Math.PI * 2;
    for (let i = 0; i < 20; i++) {
        const ang = a0 + i * Math.PI / 10, ca = Math.cos(ang), sa = Math.sin(ang); let prev = probe.h(c.dir, c.f, ca * 450, sa * 450), slope = 0;
        for (let k = 1; k < 6; k++) { const rad = 450 + k * 220, h = probe.h(c.dir, c.f, ca * rad, sa * rad); slope = Math.max(slope, Math.abs(h - prev) / 220); prev = h; }
        if (slope < bestSlope) { bestSlope = slope; best = ang; }
    }
    if (bestSlope > (strict ? 0.7 : 1.1)) return null;
    const passScore = 1 - clamp(bestSlope / 0.7, 0, 1);
    const score = 0.6 * c.score1 + 0.25 * passScore + 0.15 * (c.h0 > 1100 ? 1 : 0.4);
    return { dir: [c.dir[0], c.dir[1], c.dir[2]], floorH: Math.round(c.floorH * 10) / 10, Rf, rimR, Rb, rimRise: 260, passAng: best, passCurl: 0, passW: 30, passProf: [],
             score, seedN: Math.floor(h32(seed, cellKey[0], cellKey[1], cellKey[2] * 31 + 7) * 4294967295) >>> 0, cell: cellKey.join(':'), strict };
}

// ======================================================================================== v53: MEASURED FOOTPRINT (the city follows the land)
// Three 64-entry tables around the centre + a smoothed height grid, all derived from the natural ground:
//   ft[i]  how far the dense city reaches toward angle i. Walks outward over the natural ground while the slope (60-unit scale) stays under the
//          site's own limit and the ground does not climb past ~480 units above the hub: it follows spurs and gullies and stops at cliffs.
//   ww[i]  the sparse hillside belt beyond ft (steeper ground, stilt houses / terraces / lookouts)
//   wr[i]  height of the ground at the outer edge of the belt above the hub (information only)
export const NA = 64;
const SG_STEP = 60, SG_N = 49, SG_HALF = (SG_N - 1) / 2 * SG_STEP;       // +-1440 units around the centre
const RISE_MAX = 280, RMAX = 1050, WMAX = 380;
const smoothRing = (arr, passes) => { for (let p = 0; p < passes; p++) { const b = arr.slice(); for (let i = 0; i < arr.length; i++) arr[i] = 0.25 * b[(i + arr.length - 1) % arr.length] + 0.5 * b[i] + 0.25 * b[(i + 1) % arr.length]; } return arr; };
// bilinear lookup in an SG_N x SG_N grid (index j*N+i, a = (i-24)*60 east, n = (j-24)*60 north)
function gridLook(G, a, n) {
    let fx = (a + SG_HALF) / SG_STEP, fz = (n + SG_HALF) / SG_STEP; fx = clamp(fx, 0, SG_N - 1.001); fz = clamp(fz, 0, SG_N - 1.001);
    const i = Math.floor(fx), j = Math.floor(fz), tx = fx - i, tz = fz - j, o = j * SG_N + i;
    return (G[o] * (1 - tx) + G[o + 1] * tx) * (1 - tz) + (G[o + SG_N] * (1 - tx) + G[o + SG_N + 1] * tx) * tz;
}
function natGrid(probe, S) {
    const f = localFrame(S.dir), H = new Float32Array(SG_N * SG_N);
    for (let j = 0; j < SG_N; j++) for (let i = 0; i < SG_N; i++) H[j * SG_N + i] = probe.h(S.dir, f, (i - (SG_N - 1) / 2) * SG_STEP, (j - (SG_N - 1) / 2) * SG_STEP);
    const SL = new Float32Array(SG_N * SG_N);
    for (let j = 0; j < SG_N; j++) for (let i = 0; i < SG_N; i++) {
        const i0 = Math.max(0, i - 1), i1 = Math.min(SG_N - 1, i + 1), j0 = Math.max(0, j - 1), j1 = Math.min(SG_N - 1, j + 1);
        SL[j * SG_N + i] = Math.hypot((H[j * SG_N + i1] - H[j * SG_N + i0]) / ((i1 - i0) * SG_STEP), (H[j1 * SG_N + i] - H[j0 * SG_N + i]) / ((j1 - j0) * SG_STEP));
    }
    return { H, SL };
}
// smooth random ring (0..1): a few low harmonics, so the size cap of a city is not a circle
function ringNoise(rr) { const hs = []; for (let j = 2; j <= 5; j++) hs.push([j, rr() * 6.283, 1 / j]); let tw = 0; for (const h of hs) tw += h[2]; const v = []; for (let k = 0; k < NA; k++) { let s = 0; for (const h of hs) s += h[2] * Math.cos(h[0] * k * 2 * Math.PI / NA + h[1]); v.push(0.5 + 0.5 * s / tw * 1.4); } return v.map(x => clamp(x, 0, 1)); }
function footprint(G, Slim, cap) {
    const h0 = gridLook(G.H, 0, 0), ft = [], ww = [], wr = [];
    for (let k = 0; k < NA; k++) {
        const ang = k * 2 * Math.PI / NA, ca = Math.cos(ang), sa = Math.sin(ang); let last = 0, gap = 0;
        for (let r = 30; r <= Math.min(RMAX, cap[k]); r += 30) {
            const hh = gridLook(G.H, ca * r, sa * r), s = gridLook(G.SL, ca * r, sa * r);
            if (s < Slim && hh - h0 < RISE_MAX && hh - h0 > -300 && hh > 40) { last = r; gap = 0; } else { gap += 30; if (gap > 60) break; }
        }
        ft.push(last);
    }
    smoothRing(ft, 3);
    for (let k = 0; k < NA; k++) ft[k] = clamp(ft[k], 330, RMAX + 50);
    for (let k = 0; k < NA; k++) {
        const ang = k * 2 * Math.PI / NA, ca = Math.cos(ang), sa = Math.sin(ang); let last = ft[k], gap = 0;
        for (let r = ft[k] + 30; r <= ft[k] + WMAX; r += 30) {
            const hh = gridLook(G.H, ca * r, sa * r), s = gridLook(G.SL, ca * r, sa * r);
            if (s < Slim * 1.8 && hh - h0 < RISE_MAX + 360) { last = r; gap = 0; } else { gap += 30; if (gap > 60) break; }
        }
        ww.push(clamp(last - ft[k], 90, WMAX));
    }
    smoothRing(ww, 2);
    for (let k = 0; k < NA; k++) { ww[k] = Math.min(ww[k], 1250 - ft[k]); const ang = k * 2 * Math.PI / NA; wr.push(gridLook(G.H, Math.cos(ang) * (ft[k] + ww[k]), Math.sin(ang) * (ft[k] + ww[k])) - h0); }
    const mean = ft.reduce((a, b) => a + b, 0) / NA;
    return { ft, ww, wr, mean, h0 };
}
export function shapeSite(T, probe, S) {
    const rr = mulberry(S.seedN ^ 0x7a31c5), Slim0 = 0.62 + 0.3 * rr(), Rcap = 560 + rr() * 380, nz = ringNoise(rr), cap = nz.map(v => Rcap * (0.78 + 0.44 * v));
    let G = null, fp = null;
    for (let pass = 0; pass < 2; pass++) {
        G = natGrid(probe, S); fp = footprint(G, Slim0, cap);
        if (fp.mean < 470) { const fp2 = footprint(G, Slim0 * 1.3, cap); if (fp2.mean > fp.mean) fp = fp2; }    // a narrow ravine: let the town climb steeper streets
        if (pass === 1) break;
        // hub: the gentlest ground close to the footprint's centroid (a town centre is not on a cliff)
        let A = 0, cx = 0, cz = 0; for (let i = 0; i < NA; i++) { const th = i * 2 * Math.PI / NA, r = fp.ft[i]; A += r * r; cx += r * r * r * Math.cos(th); cz += r * r * r * Math.sin(th); }
        cx *= 2 / 3 / A; cz *= 2 / 3 / A;
        let bx = 0, bz = 0, bc = 1e9;
        for (let da = -300; da <= 300; da += 60) for (let dn = -300; dn <= 300; dn += 60) {
            const a = cx + da, n = cz + dn; if (Math.hypot(a, n) > 420) continue;
            const s = gridLook(G.SL, a, n), s2 = Math.max(gridLook(G.SL, a + 90, n), gridLook(G.SL, a - 90, n), gridLook(G.SL, a, n + 90), gridLook(G.SL, a, n - 90)), c = s + 0.4 * s2 + 0.0012 * Math.hypot(da, dn);
            if (c < bc) { bc = c; bx = a; bz = n; }
        }
        if (Math.hypot(bx, bz) > 30) { const nd = [0, 0, 0]; localToDir(S, bx, bz, nd); S.dir = nd; delete S._f; } else break;
    }
    // smoothed height grid for the gentle grading inside the footprint
    const sg = Float32Array.from(G.H);
    for (let pass = 0; pass < 3; pass++) {
        const t = Float32Array.from(sg);
        for (let j = 0; j < SG_N; j++) for (let i = 0; i < SG_N; i++) { const i0 = Math.max(0, i - 1), i1 = Math.min(SG_N - 1, i + 1); sg[j * SG_N + i] = 0.25 * t[j * SG_N + i0] + 0.5 * t[j * SG_N + i] + 0.25 * t[j * SG_N + i1]; }
        const u = Float32Array.from(sg);
        for (let j = 0; j < SG_N; j++) { const j0 = Math.max(0, j - 1), j1 = Math.min(SG_N - 1, j + 1); for (let i = 0; i < SG_N; i++) sg[j * SG_N + i] = 0.25 * u[j0 * SG_N + i] + 0.5 * u[j * SG_N + i] + 0.25 * u[j1 * SG_N + i]; }
    }
    for (let i = 0; i < sg.length; i++) sg[i] = Math.round(sg[i] * 10) / 10;
    let mean = 0, mn = 1e9, mxRim = 0;
    for (let i = 0; i < NA; i++) { fp.ft[i] = Math.round(fp.ft[i] * 10) / 10; fp.ww[i] = Math.round(fp.ww[i] * 10) / 10; fp.wr[i] = Math.round(fp.wr[i] * 10) / 10; mean += fp.ft[i] / NA; mn = Math.min(mn, fp.ft[i]); mxRim = Math.max(mxRim, fp.ft[i] + fp.ww[i]); }
    S.ft = fp.ft; S.ww = fp.ww; S.wr = fp.wr; S.sg = sg; S.sgN = SG_N; S.sgStep = SG_STEP;
    S.floorH = Math.round(gridLook(sg, 0, 0) * 10) / 10;                        // hub level = the smoothed natural ground at the centre
    S.Rbase = Math.round(mean); S.Rf = Math.round(mean); S.Rmin = Math.round(mn); S.rimR = Math.round(mxRim); S.Rb = Math.round(mxRim + 360); S.slim = Math.round(Slim0 * 100) / 100;
    // terrain character (used by the generator for the city's name-tag style and by tests)
    let ss2 = 0, nn = 0; for (let k = 0; k < NA; k += 2) for (let r = 100; r < fp.ft[k]; r += 100) { ss2 += gridLook(G.SL, Math.cos(k * 2 * Math.PI / NA) * r, Math.sin(k * 2 * Math.PI / NA) * r); nn++; }
    S.meanSlope = Math.round(ss2 / Math.max(1, nn) * 100) / 100;
    findPass(probe, S, rr);
    return S;
}
// the gate road: from the footprint edge outward, a walk that picks at every step the heading with the gentlest slope (and prefers going down)
function findPass(probe, S, rr) {
    const f = localFrame(S.dir), STEP = 70, NSTEP = Math.max(8, Math.ceil((S.rimR + 420 - S.Rf * 0.9) / STEP));
    let best = null, bestScore = 1e9; const a0 = rr() * Math.PI * 2;
    for (let i = 0; i < 32; i++) {
        const ang = a0 + i * Math.PI / 16, R0 = ringAt(S.ft, ang) * 0.98; let x = Math.cos(ang) * R0, z = Math.sin(ang) * R0, hd = ang, ph = probe.h(S.dir, f, x, z), maxS = 0, climb = 0; const pts = [[x, z]];
        for (let s = 0; s < NSTEP; s++) {
            let bl = 0, bc = 1e9, bh = ph, bs = 0;
            for (const dl of [0, 0.3, -0.3, 0.6, -0.6]) {
                const ha = hd + dl; if (Math.abs(ha - ang) > 1.2) continue;
                const qh = probe.h(S.dir, f, x + Math.cos(ha) * STEP, z + Math.sin(ha) * STEP), sl = Math.abs(qh - ph) / STEP, c = sl + (qh > ph ? 0.3 * (qh - ph) / STEP : 0) + Math.abs(dl) * 0.06;
                if (c < bc) { bc = c; bl = dl; bh = qh; bs = sl; }
            }
            hd += bl * 0.7; x += Math.cos(hd) * STEP; z += Math.sin(hd) * STEP; maxS = Math.max(maxS, bs); climb += Math.max(0, bh - ph); ph = bh; pts.push([x, z]);
        }
        const score = maxS + climb / 900 * 0.6;
        if (score < bestScore) { bestScore = score; best = pts; }
    }
    S.passPts = best.map(p => [Math.round(p[0] * 10) / 10, Math.round(p[1] * 10) / 10]);
    S.passAng = Math.atan2(best[0][1], best[0][0]); S.passR = Math.round(Math.hypot(best[0][0], best[0][1])); S.passCurl = 0; S.passProf = []; S.passScore = Math.round(bestScore * 100) / 100;
}


// cheap land check along the chord between two sites (no sea / deep trench in between): used to favour leagues that a road can join
function landLinked(T, a, b, o) {
    let wet = 0;
    for (let k = 1; k < 16; k++) {
        const t = k / 16, x = a.dir[0] * (1 - t) + b.dir[0] * t, y = a.dir[1] * (1 - t) + b.dir[1] * t, z = a.dir[2] * (1 - t) + b.dir[2] * t, il = R / Math.hypot(x, y, z);
        if (T.sample3(x * il, y * il, z * il, o) < 3 && ++wet > 1) return false;   // at most one wet sample: the real route (A*) may bend around a lake / inlet
    }
    return true;
}
// Greedy deterministic site selection. T = TerrainCore. Returns { sites, stats }.
export function findSites(T, seed, opts = {}) {
    const t0 = (typeof performance !== 'undefined' ? performance : Date).now();
    const G = opts.grid || SITE_GRID, cw = 2 * CHART_HALF / G, probe = makeProbe(T), g = [0, 0, 0];
    let nCand = 0, nStage1 = 0;
    const stage1 = [];
    for (let f = 0; f < 6; f++) for (let i = 0; i < G; i++) for (let j = 0; j < G; j++) {
        let bestC = null;
        for (let k = 0; k < 2; k++) {                   // two hashed candidates per cell -> at most one site per cell
            const jx = 0.12 + 0.76 * h32(seed, f * 4096 + i, j, 100 + k * 2), jz = 0.12 + 0.76 * h32(seed, f * 4096 + i, j, 101 + k * 2);
            chartToGeo(f, -CHART_HALF + (i + jx) * cw, -CHART_HALF + (j + jz) * cw, g);
            if (Math.abs(g[1]) > 0.93) continue;        // > ~68 deg latitude: ice
            nCand++;
            const c = evalCandidate(T, probe, g.slice(), null, true);
            if (c && !probe.hostile(c.dir) && (!bestC || c.score1 > bestC.score1)) bestC = c;
        }
        if (bestC) { nStage1++; stage1.push({ c: bestC, key: [f, i, j] }); }
    }
    stage1.sort((a, b) => b.c.score1 - a.c.score1);
    // stage 1.5: big landmasses: share of land in rings at 30 and 60 km (roads and leagues need land); re-rank the best 110
    const lo = {};
    for (const s of stage1.slice(0, 420)) {
        let land = 0, n = 0; const d0 = s.c.dir, fr = s.c.f;
        for (const rad of [30, 60]) for (let k = 0; k < 10; k++) { const ang = k * Math.PI / 5, rr = rad * 4250; let x = d0[0] + (fr.e[0] * Math.cos(ang) + fr.n[0] * Math.sin(ang)) * rr / R, y = d0[1] + (fr.e[1] * Math.cos(ang) + fr.n[1] * Math.sin(ang)) * rr / R, z = d0[2] + (fr.e[2] * Math.cos(ang) + fr.n[2] * Math.sin(ang)) * rr / R; const il = R / Math.hypot(x, y, z); n++; if (T.sample3(x * il, y * il, z * il, lo) > 3) land++; }
        s.c.landFrac = land / n; s.c.score1 = s.c.score1 * 0.75 + 0.25 * s.c.landFrac;
    }
    stage1.sort((a, b) => b.c.score1 - a.c.score1);
    const cands = [];
    for (const s of stage1.slice(0, 220)) { const v = finishSite(T, probe, s.c, s.key, seed, true); if (v) cands.push(v); }
    cands.sort((a, b) => b.score - a.score || (a.cell < b.cell ? -1 : 1));
    // pick: "a few" per world (per-seed target 6..10). Greedy by score, with a mild bonus for being near an already-kept site so some
    // city-states form small leagues within road range (CLUSTER_KM) while others stay isolated. Keep SITE_MIN_SEP apart.
    const kept = [], sepC = SITE_MIN_SEP / R;
    const dist = (a, b) => Math.hypot(a.dir[0] - b.dir[0], a.dir[1] - b.dir[1], a.dir[2] - b.dir[2]) * R;
    const _lo = {}, _lc = new Map(), linkOf = (a, b) => { const key = a.cell < b.cell ? a.cell + '|' + b.cell : b.cell + '|' + a.cell; let v = _lc.get(key); if (v === undefined) { v = landLinked(T, a, b, _lo); _lc.set(key, v); } return v; };
    const want = opts.max || (28 + Math.floor(h32(seed, 7, 7, 7) * 5))   // v46: ~30 per world (28..32);
    const pool = cands.filter(v => v.score >= 0.42);
    while (kept.length < want && pool.length) {
        let bi = -1, bs = -1;
        for (let i = 0; i < pool.length; i++) {
            const v = pool[i]; let ok = true, bonus = 0;
            for (const k of kept) { const d = dist(k, v); if (d < SITE_MIN_SEP) { ok = false; break; } if (d < 95 * 4250) { const lk = linkOf(k, v); if (lk) bonus = Math.max(bonus, Math.exp(-d / (CLUSTER_KM * 4250))); } }
            if (!ok) continue;
            const eff = v.score + 0.3 * bonus; if (eff > bs) { bs = eff; bi = i; }
        }
        if (bi < 0) break;
        kept.push(pool[bi]); pool.splice(bi, 1);
    }
    // COMPANIONS: leagues need land. For the best sites that have no land-linked neighbour, look 20-80 km around them for a valley
    // joined by land (relaxed rules). Companions occupy their own grid cell, so still at most one site per cell.
    const cellOf = (dir) => { const f = faceOfGeo(dir[0], dir[1], dir[2]), c = { x: 0, z: 0 }; geoToChart(f, dir[0], dir[1], dir[2], c); return f + ':' + Math.floor((c.x + CHART_HALF) / cw) + ':' + Math.floor((c.z + CHART_HALF) / cw); };
    let relaxed0 = 0;
    const usedCells = new Set(kept.map(k => cellOf(k.dir)));
    let companions = 0;
    const order = kept.slice().sort((a, b) => b.score - a.score);
    for (const a of order) {
        if (companions >= 4 || kept.length >= want + 3) break;
        if (kept.some(k => k !== a && dist(k, a) < 95 * 4250 && linkOf(k, a))) continue;
        const fr = localFrame(a.dir); let best = null;
        for (let ri = 0; ri < 3; ri++) for (let ai = 0; ai < 16; ai++) {
            const rad = (16 + ri * 16 + 8 * h32(seed, a.id | 0, ri * 16 + ai, 77)) * 4250, ang = ai * Math.PI / 8 + h32(seed, ai, ri, 78);
            const dd = [0, 0, 0]; let x = a.dir[0] + (fr.e[0] * Math.cos(ang) + fr.n[0] * Math.sin(ang)) * rad / R, y = a.dir[1] + (fr.e[1] * Math.cos(ang) + fr.n[1] * Math.sin(ang)) * rad / R, z = a.dir[2] + (fr.e[2] * Math.cos(ang) + fr.n[2] * Math.sin(ang)) * rad / R, il = 1 / Math.hypot(x, y, z);
            dd[0] = x * il; dd[1] = y * il; dd[2] = z * il;
            if (Math.abs(dd[1]) > 0.95 || usedCells.has(cellOf(dd))) continue;
            const c = evalCandidate(T, probe, dd, null, false); if (!c) continue;
            const v = finishSite(T, probe, c, [7, ri, ai + 100 * (a.id | 0)], seed, false); if (!v || v.score < 0.3) continue;
            if (kept.some(k => dist(k, v) < SITE_MIN_SEP) || !landLinked(T, a, v, _lo)) continue;
            if (!best || v.score > best.score) best = v;
        }
        if (best) { kept.push(best); usedCells.add(cellOf(best.dir)); companions++; }
    }
    // TOP-UP (v46): if the strict pass found fewer than `want` (small land / few highlands), fill from relaxed candidates, best first.
    if (kept.length < want) {
        const extra = [], seen = new Set(kept.map(k => k.cell));
        for (let f = 0; f < 6; f++) for (let i = 0; i < G; i++) for (let j = 0; j < G; j++) {
            const jx = 0.2 + 0.6 * h32(seed, f * 4096 + i, j, 300), jz = 0.2 + 0.6 * h32(seed, f * 4096 + i, j, 301);
            chartToGeo(f, -CHART_HALF + (i + jx) * cw, -CHART_HALF + (j + jz) * cw, g);
            if (Math.abs(g[1]) > 0.94 || seen.has([f, i, j].join(':'))) continue;
            const c = evalCandidate(T, probe, g.slice(), null, false); if (!c || probe.hostile(c.dir)) continue;
            c.score1 *= 0.9; extra.push({ c, key: [f, i, j] });
        }
        extra.sort((a, b) => b.c.score1 - a.c.score1);
        for (const e of extra.slice(0, 160)) {
            if (kept.length >= want) break;
            const v = finishSite(T, probe, e.c, e.key, seed, false); if (!v || v.score < 0.35) continue;
            if (kept.some(k => dist(k, v) < SITE_MIN_SEP)) continue;
            kept.push(v); relaxed0++;
        }
    }
    // GUARANTEE (a few sites on every world): relax the rules until at least MIN_SITES exist
    let relaxed = relaxed0;
    if (kept.length < MIN_SITES) {
        const loose = [];
        for (let f = 0; f < 6 && loose.length < 400; f++) for (let i = 0; i < G; i += 1) for (let j = 0; j < G; j += 1) {
            const jx = 0.5, jz = 0.5; chartToGeo(f, -CHART_HALF + (i + jx) * cw, -CHART_HALF + (j + jz) * cw, g);
            if (Math.abs(g[1]) > 0.96) continue;
            const c = evalCandidate(T, probe, g.slice(), null, false); if (!c) continue;
            const v = finishSite(T, probe, c, [f, i, j], seed, false); if (v) loose.push(v);
        }
        loose.sort((a, b) => b.score - a.score || (a.cell < b.cell ? -1 : 1));
        for (const v of loose) { if (kept.length >= MIN_SITES) break; if (kept.some(k => dist(k, v) < SITE_MIN_SEP)) continue; kept.push(v); relaxed++; }
    }
    kept.forEach((s, i) => { s.id = i; shapeSite(T, probe, s); });
    // v56: the ROGUES' CITADEL - exactly one per world, appended last (so ordinary site ids do not change)
    let citadel = null;
    { const cs = findCitadelSite(T, probe, kept, seed);
      let tried = 0;
      for (const c of cs.slice(0, 60)) {
          const dir = centreOnHollow(probe, c.dir);
          const S = { dir, floorH: 0, Rf: 2300, rimR: 4000, Rb: 7000, rimRise: 0, passAng: 0, passCurl: 0, passW: 30, passProf: [], score: 1, seedN: Math.floor(h32(seed, c.key[0], c.key[1], c.key[2] * 31 + 77) * 4294967295) >>> 0, cell: 'citadel', strict: true, id: kept.length };
          if (shapeCitadel(T, probe, S)) { if (!citadel || S.citCost < citadel.citCost) citadel = S; if (++tried >= 10) break; }
      }
      if (citadel) kept.push(citadel); }
    for (const a of kept) { if (a === citadel) { a.links = []; continue; } a.links = kept.filter(b => b !== a && b !== citadel && dist(a, b) < 95 * 4250 && linkOf(a, b)).map(b => b.id); }
    const ms = (typeof performance !== 'undefined' ? performance : Date).now() - t0;
    return { sites: kept, stats: { ms, cells: 6 * G * G, candidates: nCand, stage1: nStage1, finished: cands.length, kept: kept.length, relaxed } };
}

// ======================================================================================== SHAPING
// A "placed" site = a site seen through one chart (centre in chart coords, rotation, ground-units-per-chart-unit).
const _ga = [0, 0, 0], _gb = [0, 0, 0], _gc = { x: 0, z: 0 };
export function placeSite(site, face) {
    if (!geoToChart(face, site.dir[0], site.dir[1], site.dir[2], _gc)) return null;
    const cx = _gc.x, cz = _gc.z, e = 20;
    chartToGeo(face, cx - e, cz, _ga); chartToGeo(face, cx + e, cz, _gb);
    const gx = Math.hypot(_gb[0] - _ga[0], _gb[1] - _ga[1], _gb[2] - _ga[2]) * R / (2 * e);
    chartToGeo(face, cx, cz - e, _ga); chartToGeo(face, cx, cz + e, _gb);
    const gz = Math.hypot(_gb[0] - _ga[0], _gb[1] - _ga[1], _gb[2] - _ga[2]) * R / (2 * e);
    const gnd = Math.sqrt(gx * gz), psi = chartPsi(face, cx, cz);
    return { site, face, cx, cz, c: Math.cos(psi), s: Math.sin(psi), gnd, reach: site.Rb * 1.25 / gnd, psi };
}
// chart point -> site-local ground offset (a east, n north)
export function toLocal(ps, x, z, out) { const dx = x - ps.cx, dz = z - ps.cz; out.a = (dx * ps.c + dz * ps.s) * ps.gnd; out.n = (dx * ps.s - dz * ps.c) * ps.gnd; return out; }
// site-local ground offset -> chart point
export function fromLocal(ps, a, n, out) { out.x = ps.cx + (a * ps.c + n * ps.s) / ps.gnd; out.z = ps.cz + (a * ps.s - n * ps.c) / ps.gnd; return out; }

// periodic Catmull-Rom lookup in a NA-entry ring table at angle th (radians)
function ringAt(tab, th) {
    let f = th / 6.283185307179586; f -= Math.floor(f); f *= NA;
    const i1 = Math.floor(f), u = f - i1, i0 = (i1 + NA - 1) % NA, i2 = (i1 + 1) % NA, i3 = (i1 + 2) % NA, i = i1 % NA;
    const p0 = tab[i0], p1 = tab[i], p2 = tab[i2], p3 = tab[i3];
    return p1 + 0.5 * u * (p2 - p0 + u * (2 * p0 - 5 * p1 + 4 * p2 - p3 + u * (3 * (p1 - p2) + p3 - p0)));
}
// the reach of the dense city in the direction of plan-local point (a, n) (follows the natural ground, see shapeSite())
export function floorRadius(S, a, n) { return S.ft ? ringAt(S.ft, Math.atan2(n, a)) : S.Rf; }
// extent of the whole settlement (dense city + hillside belt) in that direction
export function rimRadius(S, a, n) { if (!S.ft) return S.rimR; const th = Math.atan2(n, a); return ringAt(S.ft, th) + ringAt(S.ww, th); }
// v53: the terrain under a city. h = natural height at (a, n). Inside the footprint the ground is pulled 60% toward its own smoothed version
// (mid-scale bumps out, slopes / spurs / gullies stay) and the hub square is levelled; nothing else is changed (no bowl, no walls, no pass cut).
const HUB_FLAT = 84, HUB_SHOULDER = 220;
function valleyH(S, a, n, h) {
    if (S.citadel) return citadelH(S, a, n, h);
    if (!S.sg) return h;
    const r2 = a * a + n * n, RR = S.rimR + 120; if (r2 > RR * RR) return h;
    const r = Math.sqrt(r2), th = Math.atan2(n, a), Rt = ringAt(S.ft, th), W = ringAt(S.ww, th);
    let out = h; const w = 1 - ss(Rt * 0.75, Rt + W * 0.85, r);
    if (w > 0) out = h + (gridLook(S.sg, a, n) - h) * 0.6 * w;
    const kp = 1 - ss(HUB_FLAT, HUB_SHOULDER, r);
    if (kp > 0) out += (S.floorH - out) * 0.92 * kp;
    return out;
}
export function valleyHeight(S, a, n, h) { return valleyH(S, a, n, h); }
// 0..1: how much of this point is inside the city (paving tint, tree exclusion). Footprint = the dense city.
export function cityWeight(S, a, n) { if (S.citadel) return 0; const r = Math.sqrt(a * a + n * n), Rt = S.ft ? ringAt(S.ft, Math.atan2(n, a)) : S.Rf; return 1 - ss(Rt * 0.85, Rt * 1.08, r); }
// v65: where the ground city of the Rogues' Citadel ends toward local (a east, n north): the measured meadow outline `rvT` (where the natural land climbs 450 above the floor): the very edge of the valley
export function citEdge(C, a, n) { const NAc = C.rvT.length; let an = Math.atan2(n, a); if (an < 0) an += 6.283185307179586; const f = an / 6.283185307179586 * NAc, i = Math.floor(f) % NAc, t = f - Math.floor(f); return (C.rvT[i] * (1 - t) + C.rvT[(i + 1) % NAc] * t); }
export function clearRadius(S) { return S.citadel ? Math.max(S.cit.Rclear, Math.max(...S.cit.rvT) + 300) + 10 : S.rimR * 0.92; }
// v55: GRADED clearing instead of a hard cut. 1 = no trees / rocks / grass (the built-up city), falling smoothly to 0 a little way past the city's own edge
// (the dense reach ft), so the wild creeps up to the walls and a few trees and rocks stand among the outer buildings. Returns the chance (0..1) that a scatter point is suppressed.
export function clearP(S, a, n) {
    const r = Math.sqrt(a * a + n * n); if (S.citadel) { const C = S.cit, E = citEdge(C, a, n); return r <= E ? 1 : r >= E + 260 ? 0 : 1 - ss(E, E + 260, r); }   // v65: clear the whole ground city, let the wild creep back in over 260 units
    if (!S.ft) return r < S.rimR * 0.92 ? 1 : 0;
    const th = Math.atan2(n, a), Rt = ringAt(S.ft, th), W = ringAt(S.ww, th), r0 = Rt * 0.9, r1 = Rt + Math.min(W * 0.45, 140);
    if (r <= r0) return 1; if (r >= r1) return 0; const t = (r - r0) / (r1 - r0); return (1 - t * t * (3 - 2 * t)) * 0.97;
}
// is local point (a, n) inside the footprint that must be free of trees / props (the dense city + the inner half of the hillside belt)
export function clearHere(S, a, n) { if (S.citadel) { const E = citEdge(S.cit, a, n); return a * a + n * n < E * E; } const r2 = a * a + n * n, cr = S.rimR * 0.92; if (r2 > cr * cr) return false; if (!S.ft) return true; const th = Math.atan2(n, a); return Math.sqrt(r2) < ringAt(S.ft, th) + ringAt(S.ww, th) * 0.5; }

// Per-chart cache of placed sites. field.near(face, x0,x1,z0,z1) -> placed sites that touch a rectangle.
export class ValleyField {
    constructor(sites) { this.sites = sites || []; this._cache = new Map(); this._l = { a: 0, n: 0 }; }
    placed(face) {
        let p = this._cache.get(face);
        if (!p) { p = []; for (const s of this.sites) { const ps = placeSite(s, face); if (ps && Math.abs(ps.cx) < CHART_HALF * 1.15 && Math.abs(ps.cz) < CHART_HALF * 1.15) p.push(ps); } this._cache.set(face, p); }
        return p;
    }
    near(face, x0, x1, z0, z1) {
        const out = []; for (const ps of this.placed(face)) if (ps.cx + ps.reach >= x0 && ps.cx - ps.reach <= x1 && ps.cz + ps.reach >= z0 && ps.cz - ps.reach <= z1) out.push(ps); return out;
    }
    // shaped height at chart point (x,z) given the natural height h (list = field.near(...) or placed(face))
    apply(list, x, z, h) {
        for (let i = 0; i < list.length; i++) {
            const ps = list[i], dx = x - ps.cx, dz = z - ps.cz;
            if (dx * dx + dz * dz > ps.reach * ps.reach) continue;
            const l = toLocal(ps, x, z, this._l); h = valleyHeight(ps.site, l.a, l.n, h);
        }
        return h;
    }
    // 0..1 city weight at a point (for paving + props clearing)
    cityAt(list, x, z) {
        let w = 0;
        for (let i = 0; i < list.length; i++) { const ps = list[i], dx = x - ps.cx, dz = z - ps.cz; if (dx * dx + dz * dz > ps.reach * ps.reach) continue; const l = toLocal(ps, x, z, this._l); w = Math.max(w, cityWeight(ps.site, l.a, l.n)); }
        return w;
    }
    // v55: suppression chance 0..1 at a chart point (max over the sites that reach it)
    clearP(list, x, z) {
        let p = 0; for (let i = 0; i < list.length; i++) { const ps = list[i], dx = x - ps.cx, dz = z - ps.cz; const cr = clearRadius(ps.site) / ps.gnd; if (dx * dx + dz * dz > cr * cr) continue; const l = toLocal(ps, x, z, this._l); const q = clearP(ps.site, l.a, l.n); if (q > p) p = q; }
        return p;
    }
    clearAt(list, x, z) {
        for (let i = 0; i < list.length; i++) { const ps = list[i], dx = x - ps.cx, dz = z - ps.cz; const cr = clearRadius(ps.site) / ps.gnd; if (dx * dx + dz * dz > cr * cr) continue; const l = toLocal(ps, x, z, this._l); if (clearHere(ps.site, l.a, l.n)) return true; }
        return false;
    }
    // v56: lush enchanted-valley weight (0..1) at a chart point
    enchantAt(list, x, z) {
        let w = 0;
        for (let i = 0; i < list.length; i++) { const ps = list[i]; if (!ps.site.citadel) continue; const dx = x - ps.cx, dz = z - ps.cz, rr = ps.site.cit.Rc * 1.2 / ps.gnd; if (dx * dx + dz * dz > rr * rr) continue; const l = toLocal(ps, x, z, this._l); w = Math.max(w, enchantWeight(ps.site, l.a, l.n)); }
        return w;
    }
    nearest(face, x, z) { let b = null, bd = 1e30; for (const ps of this.placed(face)) { const d = (ps.cx - x) ** 2 + (ps.cz - z) ** 2; if (d < bd) { bd = d; b = ps; } } return b ? { ps: b, dist: Math.sqrt(bd) } : null; }
}


// =====================================================================================================================================
// v56: THE ROGUES' CITADEL - one per world. An enchanted ring valley (a caldera of mountains around a meadow floor) with a SADDLE in the rim
// where a straight tunnel passes under the mountain and opens onto the city's high Skyterrace. All of it is pure maths of (a, n) so the
// main thread, every chunk worker and the city generator see the identical ground.
//   floor  : meadow, radius ~Rv, gently rolling (flat under the city core)
//   rim    : irregular ring of crags rising ~1400-1700 units above the floor, crest radius ~Rc
//   saddle : along the tunnel direction the crest is lowered to a pass (just above the tunnel roof + rock cover)
//   tunnel : level bore at yT above the floor between sIn (inner portal, on the valley wall) and sOut (outer portal); terrain is raised to
//            guarantee rock cover over it
//   road   : from the outer portal a graded road bed (cut into / filled onto the outer slope) that follows the ground down to meet it
// =====================================================================================================================================
const CIT_YT = 300, CIT_HT = 54, CIT_WT = 34, CIT_WR = 46, CIT_COVER = 26;
function vhash(i, j, s) { let h = Math.imul(i | 0, 0x27d4eb2d) ^ Math.imul(j | 0, 0x165667b1) ^ Math.imul(s | 0, 0x9e3779b1); h = Math.imul(h ^ (h >>> 15), 0x85ebca6b); h = Math.imul(h ^ (h >>> 13), 0xc2b2ae35); h ^= h >>> 16; return (h >>> 0) / 4294967296; }
function vnoise(x, z, s) { const i = Math.floor(x), j = Math.floor(z), fx = x - i, fz = z - j, u = fx * fx * (3 - 2 * fx), v = fz * fz * (3 - 2 * fz); return (vhash(i, j, s) * (1 - u) + vhash(i + 1, j, s) * u) * (1 - v) + (vhash(i, j + 1, s) * (1 - u) + vhash(i + 1, j + 1, s) * u) * v; }
const angDiff = (a, b) => { let d = a - b; d -= Math.PI * 2 * Math.floor((d + Math.PI) / (Math.PI * 2)); return d; };
const ringNf = (C, ph, k) => 0.5 + 0.5 * (0.55 * Math.sin(2 * ph + C.p[k]) + 0.3 * Math.sin(3 * ph + C.p[k + 1]) + 0.15 * Math.sin(5 * ph + C.p[k + 2]));
// the valley without the tunnel's own earthworks. nat = the natural height here.
// v64: THE VALLEY IS THE NATURAL ONE. Before, a perfect-ish ring of synthetic crags (1400-1700 high) was stamped round whatever ground the site had.
// Now: C.rvT is the MEASURED radius at which the natural ground climbs out of the basin in each direction, so the meadow follows the real hollow;
// inside it the ground is eased onto one level (the city needs a level floor) and the natural slopes climb away from it untouched. A rim is only
// raised where nature left a gap (softly, to a modest minimum), and the saddle above the tunnel is just a lower minimum, never a carved notch.
const softplus = (x, k) => { const t = x / k; return t > 30 ? x : k * Math.log(1 + Math.exp(t)); };
export function citSurface(C, a, n, nat) {
    const r = Math.sqrt(a * a + n * n), ph = Math.atan2(n, a), d = angDiff(ph, C.th), gap = Math.exp(-(d / C.gapW) * (d / C.gapW));
    const RvA = ringAt(C.rvT, ph), RcA = RvA + 1500;
    const w2 = ss(RcA, C.Rout, r);
    const rollAmp = ss(430, 2100, r);   // dead flat under the heart plaza
    const roll = ((vnoise(a / 560, n / 560, C.s4) - 0.5) * 48 + (vnoise(a / 180, n / 180, C.s5) - 0.5) * 11) * rollAmp * (1 - ss(RvA * 0.8, RvA + 300, r));
    const floorW = 1 - ss(1850, RvA, r);                       // 1 = the level meadow, 0 = untouched natural ground
    let h = nat + (C.floorH + roll - nat) * floorW;
    const tIn = ss(RvA, RcA, r);
    if (tIn > 0) {
        const minRaw = C.rim * 0.62 * (0.85 + 0.3 * ringNf(C, ph, 6)), minRim = minRaw + (C.saddle - C.floorH - minRaw) * gap;
        const lift = C.floorH + minRim * tIn - h;
        h += softplus(lift, 90) * ss(0, 0.2, tIn);
    }
    return r < RcA ? h : h + (nat - h) * w2;
}
// tunnel / road centre-line height at axial distance s: level to the inner portal, then a steady descent (7 %) all the way out
export function citProfile(C, s) {
    if (s <= C.sOut || !C.road) return C.yT - C.gt * (s > C.sIn ? s - C.sIn : 0);
    const k = (s - C.sOut) / C.rStep, i = Math.min(C.road.length - 1, Math.floor(k)), j = Math.min(C.road.length - 1, i + 1), f = Math.min(1, k - i); return C.road[i] + (C.road[j] - C.road[i]) * f;
}
function citadelH(S, a, n, nat) {
    const C = S.cit, r2 = a * a + n * n; if (r2 > C.reachR * C.reachR) return nat;
    let h = r2 > C.Rout * C.Rout ? nat : citSurface(C, a, n, nat);
    const s = a * C.ca + n * C.sa; if (s < C.sIn - 262 || s > C.sEnd + 160) return h;
    const u = -a * C.sa + n * C.ca, au = u < 0 ? -u : u; if (au > CIT_WR + 260) return h;
    if (s < C.sIn + 12 && s > C.sIn - 260) {   // the cutting that leads the promenade into the inner portal (deck level = the tunnel floor)
        const wc = ss(C.sIn - 260, C.sIn - 200, s) * (1 - ss(C.sIn + 2, C.sIn + 12, s)), yb = C.yT - 1;
        if (h > yb && wc > 0) h += (yb - h) * (1 - ss(CIT_WR, CIT_WR + 40 + (h - yb) * 0.9, au)) * wc;
    }
    if (s < C.sOut) {   // rock cover over the bore
        if (au < CIT_WT + 170) { const wl = 1 - ss(CIT_WT + 70, CIT_WT + 170, au), wa = ss(C.sIn + 2, C.sIn + 60, s) * (1 - ss(C.sOut - 90, C.sOut - 6, s)), min = citProfile(C, s) + CIT_HT + CIT_COVER; if (h < min) h += (min - h) * wl * wa; }
        return h;
    }
    // the road bed from the outer portal: cut into the slope, filled (with 0.6 shoulders) where the slope falls away
    const wa = ss(C.sOut - 8, C.sOut + 14, s) * (1 - ss(C.sEnd, C.sEnd + 150, s)); if (wa <= 0) return h;
    const yr = citProfile(C, s), over = au > CIT_WR ? au - CIT_WR : 0, tgt = yr - over * 0.6;
    if (h < tgt) h += (tgt - h) * wa;                                   // fill
    else if (h > yr) h += (yr - h) * (1 - ss(CIT_WR, CIT_WR + 36 + (h - yr) * 0.9, au)) * wa;   // cut
    return h;
}
export function enchantWeight(S, a, n) { if (!S.citadel) return 0; const r = Math.sqrt(a * a + n * n), C = S.cit; return 1 - ss(C.Rc * 0.55, C.Rc * 1.15, r); }
export function citadelAxis(S, s, u, out) { const C = S.cit; out.a = s * C.ca - u * C.sa; out.n = s * C.sa + u * C.ca; return out; }
// shape + measure: choose the tunnel direction whose outward slope lets the road bed meet the ground most cheaply, find the portals, build the road profile
function shapeCitadel(T, probe, S) {
    const rr = mulberry(S.seedN ^ 0x3c1a77), f = localFrame(S.dir);
    S.floorH = Math.round(probe.h(S.dir, f, 0, 0) * 10) / 10;
    const base = { p: [], s1: Math.floor(rr() * 1e6), s2: Math.floor(rr() * 1e6), s3: Math.floor(rr() * 1e6), s4: Math.floor(rr() * 1e6), s5: Math.floor(rr() * 1e6), floorH: S.floorH, Rv: 2350, Rc: 4050, Rout: 6300, rim: 1380 + rr() * 330, gapW: 0.3, Rclear: 1850, saddle: S.floorH + CIT_YT + CIT_HT + CIT_COVER + 250 };
    for (let k = 0; k < 9; k++) base.p.push(rr() * 6.2832);
    const nat = new Map(); const natAt = (a, n) => { const k = Math.round(a / 40) * 100003 + Math.round(n / 40); let v = nat.get(k); if (v === undefined) { v = probe.h(S.dir, f, Math.round(a / 40) * 40, Math.round(n / 40) * 40); nat.set(k, v); } return v; };
    // v64: floor level = the natural level of the hollow (median of the natural ground within 1.5 km), and the basin outline measured from the land
    { const hs = []; for (let k = 0; k < 24; k++) { const an = k * 0.2618, rad = k < 8 ? 500 : k < 16 ? 1000 : 1500; hs.push(natAt(Math.cos(an) * rad, Math.sin(an) * rad)); } hs.push(natAt(0, 0)); hs.sort((x, y) => x - y); S.floorH = Math.round(hs[12] * 10) / 10; base.floorH = S.floorH; base.saddle = S.floorH + CIT_YT + CIT_HT + CIT_COVER + 250; }
    { const raw = []; for (let i = 0; i < NA; i++) { const an = i * 6.283185307179586 / NA, ca = Math.cos(an), sa = Math.sin(an); let rw = 3500; for (let r = 1100; r <= 3500; r += 50) { if (natAt(ca * r, sa * r) - S.floorH > 450) { rw = r; break; } } raw.push(rw); }
      const sm = raw.map((_, i) => { let s = 0; for (let k = -3; k <= 3; k++) s += raw[(i + k + NA) % NA]; return clamp(s / 7 * 0.94, 2250, 3500); });
      base.rvT = sm; base.Rv = sm.reduce((x, y) => x + y, 0) / NA; base.Rc = base.Rv + 1700; }
    let best = null;
    const a0 = rr() * 6.2832, YT = S.floorH + CIT_YT, GT = 0.07, roofAbove = CIT_HT + CIT_COVER + 4;
    for (let i = 0; i < 24; i++) {
        const th = a0 + i * Math.PI / 12, C = Object.assign({}, base, { th, ca: Math.cos(th), sa: Math.sin(th), yT: YT, gt: GT });
        const surf = (s) => { const a = C.ca * s, n = C.sa * s, nt = natAt(a, n); return s > C.Rout ? nt : citSurface(C, a, n, nt); };
        let sIn = -1, sCrest = -1, ymax = -1e9; for (let s = 600; s < C.Rout; s += 8) { const y = surf(s); if (sIn < 0 && y >= YT + roofAbove) sIn = s; if (y > ymax) { ymax = y; sCrest = s; } }
        if (sIn < 0 || ymax < YT + roofAbove + 60) continue;
        C.sIn = sIn; let sOut = -1; for (let s = Math.max(sCrest, sIn + 200); s < C.Rout + 4000; s += 8) if (surf(s) < citProfile(C, s) + roofAbove) { sOut = s; break; } if (sOut < 0 || sOut - sIn > 2900) continue;   // v64: natural mountains can be thick; refuse a bore longer than ~680 m
        // the road bed beyond the outer portal: the 7 % line while the slope is above it (cut); where the ground falls away it descends faster (<= 16 %) to meet it
        const rStep = 24, road = [citProfile(C, sOut)]; let sEnd = -1, fillSum = 0, above = false;
        for (let k = 1; k < 380; k++) { const s = sOut + k * rStep, g = surf(s) + 3, prev = road[k - 1], nominal = prev - rStep * GT; let y = nominal; if (g < nominal) y = Math.max(g, prev - rStep * 0.16); road.push(y); if (y > g + 2.5) { above = true; fillSum += y - g; } else if (above && k > 3) { sEnd = s; break; } if (!above && k * rStep > 3000) { sEnd = s; break; } }
        if (sEnd >= 0) C.road = road, C.rStep = rStep;
        if (sEnd < 0) continue;
        const score = fillSum / 3000 + (sEnd - sOut) * 0.05 + (sOut - sIn) * 0.02; if (!best || score < best.score) best = { score, C, sIn, sOut, sEnd, YT, road, rStep };
    }
    if (!best) return false;
    const { C } = best;
    // v64: earthwork cost = how far the finished valley ground departs from the natural ground (the lower the more natural the site)
    { let sum = 0, cnt = 0; for (let k = 0; k < 16; k++) { const an = k * 0.3927; for (let r = 300; r <= 5400; r += 400) { const a = Math.cos(an) * r, n = Math.sin(an) * r, nt = natAt(a, n); sum += Math.abs(citSurface(C, a, n, nt) - nt); cnt++; } } S.citCost = sum / cnt; }
    // the bore runs from sIn - 8 (facade) to sOut: inner portal sits where the wall rises above the roof; keep the saddle surface above the roof between
    Object.assign(C, { sIn: best.sIn, sOut: best.sOut, sEnd: best.sEnd, yT: YT, road: best.road, rStep: best.rStep }); C.reachR = Math.max(C.Rout, C.sEnd + 320);
    S.cit = C; S.citadel = true; S.Rf = 2300; S.Rbase = 2300; S.Rmin = 2000; S.rimR = Math.round(C.Rc); S.Rb = Math.round(C.reachR + 700); S.slim = 0.6; S.meanSlope = 0.2;
    S.ft = new Array(NA).fill(2300); S.ww = new Array(NA).fill(300); S.wr = new Array(NA).fill(0); S.sg = null; S.sgN = 0; S.sgStep = SG_STEP;
    S.passAng = C.th; S.passCurl = 0; S.passProf = []; S.passScore = 0;
    S.passPts = [[C.ca * C.sEnd, C.sa * C.sEnd], [C.ca * (C.sEnd + 60), C.sa * (C.sEnd + 60)]]; S.passR = Math.round(C.sEnd);
    S.name = "Rogues' Citadel"; S.links = [];
    return true;
}
// v64: slide a Citadel candidate to the spot of the surrounding ground that is already the most level (least earthwork for a 2.3 km meadow)
function centreOnHollow(probe, dir) {
    const f0 = localFrame(dir); let best = dir, bc = 1e9; const nd = [0, 0, 0];
    for (let i = -3; i <= 3; i++) for (let j = -3; j <= 3; j++) {
        const d = localToDir({ dir, _f: f0 }, i * 450, j * 450, nd).slice(), f = localFrame(d), hs = [];
        for (const rad of [500, 1000, 1500, 2000]) for (let k = 0; k < 8; k++) { const an = k * 0.7854 + rad * 0.001; hs.push(probe.h(d, f, Math.cos(an) * rad, Math.sin(an) * rad)); }
        hs.sort((x, y) => x - y); const med = hs[16]; let c = 0; for (const h of hs) c += Math.abs(h - med); c /= hs.length;
        c += 0.02 * Math.hypot(i, j) * 450;   // mild preference to stay near the original spot
        if (c < bc) { bc = c; best = d; }
    }
    return best;
}
// the one Citadel site of a world: elevated land inside real country (no sea within ~7 km), far from every ordinary city, with a calm outward slope
function findCitadelSite(T, probe, kept, seed) {
    const G = SITE_GRID, cw = 2 * CHART_HALF / G, g = [0, 0, 0], R_ = R;
    const dist = (d1, d2) => Math.hypot(d1[0] - d2[0], d1[1] - d2[1], d1[2] - d2[2]) * R_;
    const cands = [];
    for (let f = 0; f < 6; f++) for (let i = 1; i < G - 1; i++) for (let j = 1; j < G - 1; j++) {
        const jx = 0.2 + 0.6 * h32(seed, f * 4096 + i, j, 910), jz = 0.2 + 0.6 * h32(seed, f * 4096 + i, j, 911);
        chartToGeo(f, -CHART_HALF + (i + jx) * cw, -CHART_HALF + (j + jz) * cw, g); if (Math.abs(g[1]) > 0.88) continue;
        let ok = true; for (const k of kept) if (dist(k.dir, g) < 52000) { ok = false; break; } if (!ok) continue;
        const fr = localFrame(g), h0 = probe.h(g, fr, 0, 0); if (!(h0 > 650 && h0 < 4300)) continue;
        let mn = 1e9, mx = -1e9, wet = 0;
        for (const rad of [2400, 4400, 6600, 9000]) for (let k = 0; k < 8; k++) { const a = k * Math.PI / 4 + rad * 0.001, h = probe.h(g, fr, Math.cos(a) * rad, Math.sin(a) * rad); if (h < 60) wet++; if (h < mn) mn = h; if (h > mx) mx = h; }
        if (wet > 0 || mn < h0 - 900 || mx - h0 > 2600 || probe.hostile(g)) continue;
        // v64: a NATURAL basin: in how many of 16 directions does the real ground climb out of the hollow (>450) within 2.4-3.6 km?
        let encl = 0; for (let k = 0; k < 16; k++) { const a = k * Math.PI / 8 + 0.3; let up = false; for (const rad of [2400, 2900, 3400, 3800]) if (probe.h(g, fr, Math.cos(a) * rad, Math.sin(a) * rad) - h0 > 450) { up = true; break; } if (up) encl++; }
        encl /= 16; if (encl < 0.5) continue;
        // a calm outward direction: the best of 12 headings (slope along 3000..7000)
        let bs = 1e9; for (let k = 0; k < 12; k++) { const a = k * Math.PI / 6; let sl = 0, prev = probe.h(g, fr, Math.cos(a) * 3000, Math.sin(a) * 3000); for (let q = 1; q <= 5; q++) { const hh = probe.h(g, fr, Math.cos(a) * (3000 + q * 800), Math.sin(a) * (3000 + q * 800)); sl = Math.max(sl, Math.abs(hh - prev) / 800); prev = hh; } if (sl < bs) bs = sl; }
        const score = 0.40 * encl + 0.2 * (1 - Math.min(1, Math.abs(h0 - 2000) / 2200)) + 0.2 * (1 - Math.min(1, bs / 0.8)) + 0.1 * (1 - Math.min(1, (mx - mn) / 3000)) + 0.1 * h32(seed, f, i, j * 7 + 3);
        cands.push({ score, dir: g.slice(), key: [f, i, j] });
    }
    cands.sort((a, b) => b.score - a.score || (a.key.join() < b.key.join() ? -1 : 1));
    return cands;
}
