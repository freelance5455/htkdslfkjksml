# v101 - high cloud drift fix, biome arrival tint removed

- **High clouds sliding fast at the start (cloud_shaders.js, cirrus branch of `wxLayeredShaders`):** the jet-stream combing divided the
  absolute cirrus coordinate (`pr.x`, tens of thousands of units from the world origin) by `1 + 0.9 * jetS`. The jet map (`wxTerr.b`) is
  empty until its first pass finishes and is re-swapped every ~0.5 s, so each swap changed that divisor and the whole sheet slid across the
  sky - worst in the first seconds of the game. The stretch is now measured from the point above the camera (`xzA`), so the sky overhead no
  longer depends on the jet map at all and only the far field is combed. The v100 capped drift speeds are unchanged.
- **Biome arrival colour change removed (game.js):** the v99 grade wash when entering a new biome is gone (update block, state, and the
  `arrival` / `arrivalTint` uniforms and shader line).
