# v75 - Resources, tutorial gate, time pauses

## Resources (chunk_core.js, game.js)
- Piezo-Quartz, Silicon-Ferrite and Bio-Fluorite are no longer tied to one biome each. The world is cut into 380-unit cells and ~80% of cells hold a patch (radius 70-120): ~17% each crystal, 14% wood grove, 15% stone outcrop. Biomes still lean toward their old crystal (30% of crystal patches in a biome are its native one).
- Roughly 180-200 crystals per chunk (was 0-20), clustered densest at each patch centre, so the nearest patch of any type is about 15-20 s of walking away.
- Wood groves use the local flavour: acacia in savannah/desert, pine in cold/rocky country, deciduous elsewhere. Stone outcrops are boulders. Acacia is now harvestable as wood.
- Old single scattered crystals removed (patches only). Scatter cost is unchanged (headless: 16 chunks in ~6.0 s before and after).
- New crystal look: a tall faceted hex-prism spire with a pointed tip, five leaning satellites and dark base shards, with a baked dark-base to bright-tip gradient, flat-shaded and glowing. Geometry builders: buildMineralCluster (game.js). Lens highlight still works (same material names).

## Tutorial gate
- New onboardingDone flag, set when the last coach step ("Systems Nominal") hides. The Strange Signal prompt can no longer appear before that; its 40 s timer now counts from the end of the tutorial. Loaded saves count as done.

## Time
- Suit gathering: the clock was already frozen until the AI is repaired; unchanged.
- Shelter gathering: time runs (slow) after the repair, then stops at 0.70 (just before evening) until the shelter is built. A one-time AI line explains the held light. The old "no shelter at night" warnings/nudges can no longer trigger in normal play (left in as a safety net for odd saves).

## Not tested on a device
Verified: syntax of both files, headless scatter counts and timing. Not verified: how the new crystals look on screen, and the dusk hold in a live session.
