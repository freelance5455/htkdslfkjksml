// =====================================================================================
// cloud_shaders.js - every GLSL string used by the volumetric cloud sky (game.js imports this).
//
// Moved out of game.js so the shaders can be generated and rendered headlessly (see tests/cloud_harness)
// and so a typo in the sky can be caught without booting the whole game.
//
//   wxBuildCloudNoiseData(N)        the tileable 3D noise volume (RGBA8, N^3)
//   wxGlslCommon(env)                shared GLSL (weather-map sampling, noise, phase functions)
//   wxCumulusShaders(lite, env)      the raymarched cumulus -> stratus -> cumulonimbus slab (+ rain shafts, rainbow)
//   wxLayeredShaders(cfg, env)       thin sheets: alto-stratocumulus and cirrus
//
// env = { MAP_N, BASE, TOP, nightMin, nightOver }  (weather-map size, slab base/top altitude, night cloud visibility)
// =====================================================================================

export function wxBuildCloudNoiseData(N) {
            const total = N * N * N;
            const fr = new Float32Array(total), fg = new Float32Array(total), fb = new Float32Array(total), fa = new Float32Array(total);
            let seed = 987654321;
            const rnd = () => { seed = (Math.imul(seed, 1664525) + 1013904223) | 0; return (seed >>> 0) / 4294967296; };
            const mkTab = (p, dim) => { const t = new Float32Array(p * p * p * dim); for (let i = 0; i < t.length; i++) t[i] = rnd(); return t; };
            const wrap = (i, p) => { i %= p; return i < 0 ? i + p : i; };
            const worley = (tab, p, x, y, z) => {
                const cx = Math.floor(x), cy = Math.floor(y), cz = Math.floor(z);
                let best = 9;
                for (let dz = -1; dz <= 1; dz++) for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
                    const o = ((wrap(cz + dz, p) * p + wrap(cy + dy, p)) * p + wrap(cx + dx, p)) * 3;
                    const ex = cx + dx + tab[o] - x, ey = cy + dy + tab[o + 1] - y, ez = cz + dz + tab[o + 2] - z;
                    const d = ex * ex + ey * ey + ez * ez; if (d < best) best = d;
                }
                return 1 - Math.min(1, Math.sqrt(best));
            };
            const vnoise = (tab, p, x, y, z) => {
                const ix = Math.floor(x), iy = Math.floor(y), iz = Math.floor(z);
                let fx = x - ix, fy = y - iy, fz = z - iz;
                fx = fx * fx * (3 - 2 * fx); fy = fy * fy * (3 - 2 * fy); fz = fz * fz * (3 - 2 * fz);
                const g = (a, b, c) => tab[(wrap(iz + c, p) * p + wrap(iy + b, p)) * p + wrap(ix + a, p)];
                const l = (a, b, t) => a + (b - a) * t;
                return l(l(l(g(0,0,0), g(1,0,0), fx), l(g(0,1,0), g(1,1,0), fx), fy),
                         l(l(g(0,0,1), g(1,0,1), fx), l(g(0,1,1), g(1,1,1), fx), fy), fz);
            };
            const vt = [mkTab(4, 1), mkTab(8, 1), mkTab(16, 1)];
            const vm = [mkTab(2, 1), mkTab(4, 1)];
            const wt = [mkTab(4, 3), mkTab(8, 3), mkTab(16, 3)];
            const wd = [mkTab(6, 3), mkTab(12, 3), mkTab(24, 3)];
            const wb = [mkTab(3, 3), mkTab(6, 3)];
            let idx = 0;
            for (let k = 0; k < N; k++) for (let j = 0; j < N; j++) for (let i = 0; i < N; i++, idx++) {
                const u = (i + 0.5) / N, v = (j + 0.5) / N, w = (k + 0.5) / N;
                const perlin = 0.52 * vnoise(vt[0], 4, u * 4, v * 4, w * 4) + 0.30 * vnoise(vt[1], 8, u * 8, v * 8, w * 8) + 0.18 * vnoise(vt[2], 16, u * 16, v * 16, w * 16);
                const wf = 0.60 * worley(wt[0], 4, u * 4, v * 4, w * 4) + 0.28 * worley(wt[1], 8, u * 8, v * 8, w * 8) + 0.12 * worley(wt[2], 16, u * 16, v * 16, w * 16);
                fr[idx] = perlin * 0.45 + wf * 0.55;
                fg[idx] = 0.58 * worley(wd[0], 6, u * 6, v * 6, w * 6) + 0.27 * worley(wd[1], 12, u * 12, v * 12, w * 12) + 0.15 * worley(wd[2], 24, u * 24, v * 24, w * 24);
                fb[idx] = 0.62 * vnoise(vm[0], 2, u * 2, v * 2, w * 2) + 0.38 * vnoise(vm[1], 4, u * 4, v * 4, w * 4);
                fa[idx] = 0.6 * worley(wb[0], 3, u * 3, v * 3, w * 3) + 0.4 * worley(wb[1], 6, u * 6, v * 6, w * 6);
            }
            // Normalise each channel by its own mean / spread so the shader's thresholds are predictable
            const out = new Uint8Array(total * 4);
            [fr, fg, fb, fa].forEach((f, ch) => {
                let m = 0; for (let i = 0; i < total; i++) m += f[i]; m /= total;
                let s = 0; for (let i = 0; i < total; i++) { const d = f[i] - m; s += d * d; } s = Math.sqrt(s / total) || 1;
                for (let i = 0; i < total; i++) {
                    const x = (f[i] - m) / (s * 3.4) + 0.5;
                    out[i * 4 + ch] = Math.max(0, Math.min(255, Math.round(x * 255)));
                }
            });
            return out;
        }

export function wxGlslCommon(env) { return `
            uniform sampler2D wxMap; uniform vec3 wxInfo; uniform vec4 wxLightning; uniform float wxFlash;
            const float WX_N = ${env.MAP_N}.0;
            vec4 wxSample(vec2 xz) {
                vec2 uv = (xz - wxInfo.xy) / (2.0 * wxInfo.z) + 0.5;
                return textureLod(wxMap, clamp(uv, vec2(0.004), vec2(0.996)), 0.0);
            }
            // C1-smooth bilinear: plain bilinear on a 1.5km grid shows straight diagonal "triangle"
            // edges in the cloud coverage; easing the interpolation weights removes them.
            vec4 wxSampleS(vec2 xz) {
                vec2 uv = (xz - wxInfo.xy) / (2.0 * wxInfo.z) + 0.5;
                vec2 st = clamp(uv, vec2(0.004), vec2(0.996)) * WX_N - 0.5;
                vec2 i = floor(st); vec2 f = st - i; f = f * f * (3.0 - 2.0 * f);
                return textureLod(wxMap, (i + f + 0.5) / WX_N, 0.0);
            }
            uniform sampler2D wxTerr;
            vec4 wxTerrS(vec2 xz) {
                vec2 uv = (xz - wxInfo.xy) / (2.0 * wxInfo.z) + 0.5;
                vec2 st = clamp(uv, vec2(0.004), vec2(0.996)) * WX_N - 0.5;
                vec2 i = floor(st); vec2 f = st - i; f = f * f * (3.0 - 2.0 * f);
                return textureLod(wxTerr, (i + f + 0.5) / WX_N, 0.0);
            }
            float wxHash(vec3 p) { p = fract(p * 0.3183099 + 0.1); p *= 17.0; return fract(p.x * p.y * p.z * (p.x + p.y + p.z)); }
            float wxNoise(vec3 x) {
                vec3 i = floor(x); vec3 f = fract(x); f = f * f * (3.0 - 2.0 * f);
                return mix(mix(mix(wxHash(i + vec3(0,0,0)), wxHash(i + vec3(1,0,0)), f.x), mix(wxHash(i + vec3(0,1,0)), wxHash(i + vec3(1,1,0)), f.x), f.y),
                           mix(mix(wxHash(i + vec3(0,0,1)), wxHash(i + vec3(1,0,1)), f.x), mix(wxHash(i + vec3(0,1,1)), wxHash(i + vec3(1,1,1)), f.x), f.y), f.z);
            }
            float wxFbm2(vec3 p) { return 0.6667 * wxNoise(p) + 0.3333 * wxNoise(p * 2.03); }
            float wxFbm4(vec3 p) { float v = 0.0, a = 0.5; for (int i = 0; i < 4; i++) { v += a * wxNoise(p); p = p * 2.07 + vec3(1.7, 9.2, 3.1); a *= 0.5; } return v / 0.9375; }
            float wxFbm5(vec3 p) { float v = 0.0, a = 0.5; for (int i = 0; i < 5; i++) { v += a * wxNoise(p); p = p * 2.07 + vec3(1.7, 9.2, 3.1); a *= 0.52; } return v / 0.9702; }
            float wxHG(float c, float g) { float g2 = g * g; return (1.0 - g2) / (12.5664 * pow(1.0 + g2 - 2.0 * g * c, 1.5)); }
            vec3 wxHue(vec3 c) { return c / max(max(c.r, max(c.g, c.b)), 0.001); }
        
            // 4*pi * (forward Henyey-Greenstein + weaker back lobe): isotropic scattering = 1. 'k' < 1 widens both lobes (higher scattering orders).
            float wxPhase(float c, float k) { return min((0.30 * wxHG(c, -0.28 * k) + 0.70 * wxHG(c, 0.62 * k)) * 12.5664, 7.0); }
            // rainbow colour across the band: u = 0 violet (inside) ... 1 red (outside)
            vec3 wxSpectrum(float u) {
                return clamp(vec3(smoothstep(0.50, 0.85, u) + 0.30 * (1.0 - smoothstep(0.0, 0.18, u)),
                                  smoothstep(0.12, 0.40, u) * (1.0 - smoothstep(0.62, 0.92, u)),
                                  1.0 - smoothstep(0.30, 0.62, u)), 0.0, 1.0);
            }
        `; }

export function wxCumulusShaders(lite, env) {
            const vertexShader = `
                varying vec3 vDir;
                void main() { vDir = (modelMatrix * vec4(position, 1.0)).xyz - modelMatrix[3].xyz; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }
            `;
            const fragmentShader = `
                precision highp float; precision highp sampler3D;
                uniform mat4 projectionMatrix;
                uniform vec3 sunDir; uniform vec3 sunColor; uniform vec3 fogColor; uniform float time; uniform float nightFactor;
                uniform vec2 windOff; uniform vec2 windDir; uniform float grey; uniform float quality; uniform vec4 wxM4;
                vec2 wq2(vec2 xz) { return mat2(wxM4.x, wxM4.y, wxM4.z, wxM4.w) * xz + windOff; }
                uniform float floorY; uniform float rainBot; uniform float rainIn;
                uniform sampler3D noiseTex;
                uniform vec3 skyZen; uniform vec3 skyMid; uniform vec3 skyHor; uniform vec3 groundCol;
                varying vec3 vDir;
                #ifdef USE_LOGDEPTHBUF
                    uniform float logDepthBufFC;
                #endif
                ${wxGlslCommon(env)}
                const float BASE = ${env.BASE.toFixed(1)}; const float TOP = ${env.TOP.toFixed(1)}; const float MAXD = 38000.0;
                const int STEPS = ${lite ? 40 : 72};

                // set once per march step from the terrain map: how far the whole deck is lifted over the land,
                // and the ground height under the sample (for where rain shafts end)
                float gLift = 0.0; float gGround = 0.0; float gStreak = 1.0;
                // 0..1: how much fine detail this sample gets (fades out with distance from the camera)
                float gLod = 1.0; float gT = 0.0;
                // gMass: how large the cloud mass under this sample is (0..1, from the big low-frequency noise): bigger clouds
                // are deeper and taller. gAnv: how much storm-cell upwind of here (so this is where its anvil shelf spreads).
                float gMass = 0.5; float gAnv = 0.0;
                // cloud geometry + size for the CURRENT march step: computed once per step instead of once per density tap (identical result, every tap shares the same weather sample)
                vec4 gG = vec4(0.0); float gSz = 0.0;
                // x = cloud base, y = thickness, z = storm core 0..1, w = stratiform (overcast sheet) 0..1
                // cloud SIZE (0..1): a wide, well-covered cloud mass (big weather-map coverage) and a big low-frequency clump both
                // make a larger cloud, and larger clouds are deeper/taller, with wider rain shafts
                float cloudSize(vec4 w) { return clamp(smoothstep(0.28, 0.82, gMass) * 0.62 + smoothstep(0.42, 0.90, w.r) * 0.50, 0.0, 1.0); }
                vec4 cloudGeom(vec4 w) {
                    float core = smoothstep(0.10, 0.80, w.b);
                    // the anvil shelf downwind of a cell shares that cell's altitude, so it lines up with the tower
                    float stG = max(core, 0.85 * smoothstep(0.08, 0.70, gAnv));
                    float strat = smoothstep(0.82, 0.98, w.r) * (1.0 - stG);
                    float size = cloudSize(w);
                    float base = max(BASE - 320.0 * w.g - 150.0 * stG - 180.0 * strat + gLift, 800.0);   // never lower than 800 m above sea level
                    // cloud SIZE sets how deep it is: small puffs stay shallow, big cloud masses build tall
                    float cum = (650.0 + 1350.0 * smoothstep(0.2, 0.7, w.r)) * (0.50 + 0.95 * size);
                    float thick = mix(cum, (700.0 + 500.0 * w.g) * (0.68 + 0.64 * gMass), strat);   // overcast decks vary in thickness: soft mottled light and dark patches
                    thick = mix(thick, 2300.0 + 1500.0 * size, stG);          // storm: ~2.3-3.8 km (was 6.4 km), tops stay in the low sky
                    return vec4(base, thick, core, strat);
                }

                // Cloud density at world position p. 'dtp' >= 0 adds the fine erosion detail (skipped for the cheap
                // light-march samples). A cloud has ONE shape: the detail only fades with distance (gLod), it never changes the silhouette.
                float cloudDensity(vec3 p, vec4 w, float macro, float dtp) {
                    float cov = w.r;
                    float anv = gAnv;
                    if (cov < 0.17 && anv < 0.12) return 0.0;
                    vec4 g = gG;
                    float h = (p.y - g.x) / g.y;
                    if (h <= -0.03 || h >= 1.0) return 0.0;
                    float core = g.z, strat = g.w;
                    // noise is anchored to the cloud's own base height (not to absolute altitude or the terrain lift), so a
                    // cloud keeps the same shape wherever it drifts to
                    vec2 pw = wq2(p.xz);
                    vec3 q = vec3(pw.x, p.y - g.x + BASE, pw.y);
                    // (1) domain-warp the lookup with a very low-frequency field so clouds stop being evenly-sized round blobs on a
                    // lattice; (2) wind shear: the upper part of a cloud is dragged downwind, so towers lean instead of standing plumb;
                    // (3) a second, much larger scale is blended in so there are big cloud masses AND small isolated puffs.
                    vec2 cwp = textureLod(noiseTex, vec3(q.x, q.y * 0.5, q.z) / 19000.0 + vec3(0.57, 0.21, 0.13), 0.0).rg - 0.5;
                    vec2 shear = cwp * 1300.0 * (1.0 - 0.6 * strat) + windDir * (clamp(h, 0.0, 1.0) * g.y * 0.12);   // v100: gentler shear - looking up through a deck the old lean smeared the noise into long streaks
                    q.x += shear.x; q.z += shear.y;
                    vec4 n1 = textureLod(noiseTex, q / 8600.0, 0.0);
                    float nBig = textureLod(noiseTex, q / 26000.0 + vec3(0.13, 0.71, 0.29), 0.0).r;
                    // a mid-scale octave (~1 km puffs) inside the body: without it a cumulus is one smooth lobe with detail painted on top;
                    // with it the silhouette itself is made of separate rounded billows. Weights keep the same overall spread (sqrt(sum w^2)).
                    float nPuff = textureLod(noiseTex, vec3(q.x + n1.g * 900.0, q.y * 1.15, q.z - n1.g * 900.0) / 3300.0 + vec3(0.29, 0.07, 0.61), 0.0).r;
                    float body = clamp(0.5 + (n1.r * 0.64 + nBig * 0.16 + nPuff * 0.20 - 0.5) / 0.6958, 0.0, 1.0);
                    // underside: flat for cumulus, lumpy (mammatus) under storm anvils
                    float ragged = (n1.g - 0.5) * (0.07 + 0.22 * core);
                    float bottom = smoothstep(0.0, 0.05 + 0.09 * strat, h + ragged);
                    // tops: fair-weather puffs stay low; a storm core is a tower of cauliflower domes of DIFFERENT heights (the
                    // billow noise sets each dome's height), and near the tropopause a flat anvil shelf spreads out downwind
                    float topK = mix(0.34, 0.80, strat);
                    topK = mix(topK, 0.46 + 0.42 * n1.a, core);
                    float prof = bottom * (1.0 - smoothstep(topK, 1.0, h));
                    float shelf = smoothstep(0.50, 0.60, h) * (1.0 - smoothstep(0.78, 0.92, h)) * smoothstep(0.08, 0.60, anv);
                    prof = max(prof, bottom * shelf);
                    // local coverage: weather map + macro clumping (towers cluster, gaps open up)
                    float c = clamp(cov * 1.06 + (macro - 0.5) * 0.66 - 0.06 + core * 0.25 + w.g * 0.12, 0.0, 1.0);
                    c = mix(c, 1.0, strat * 0.7);
                    c = max(c, shelf * (0.62 + 0.30 * macro));
                    float thr = 0.97 - 0.94 * c + (1.0 - prof) * (0.46 - 0.26 * strat);
                    float soft = (0.17 - 0.05 * strat) * (1.0 + 1.2 * smoothstep(7000.0, 32000.0, gT));   // v100: far cloud edges soften instead of staying razor sharp
                    float d = clamp((body - thr) / soft, 0.0, 1.0);
                    if (dtp >= 0.0 && d > 0.0 && d < 0.985) {
                        // Three erosion octaves, each looked up through the SAME low-frequency curl (cwp), so the billows swirl and
                        // lean with the air instead of being three independent layers of speckle. The finest octave only exists
                        // close to the camera (gLod) - far clouds stay smooth and cheap, near ones get crisp cauliflower edges.
                        vec3 dq = vec3(q.x / 3000.0 + cwp.x * 0.30, q.y / 3000.0 + time * 0.0035, q.z / 3000.0 + cwp.y * 0.30);
                        float det = textureLod(noiseTex, dq, 0.0).g;
                        float farK = mix(1.0, 0.45, smoothstep(2500.0, 15000.0, gT));   // far clouds: calmer edges, no confetti
                        float er = mix(0.46, 0.16, strat) * farK;
                        d = clamp((d - (1.0 - det) * er) / (1.0 - er), 0.0, 1.0);
                        float det2 = textureLod(noiseTex, vec3(q.x / 1150.0 + cwp.x * 0.16, q.y / 1150.0 + time * 0.006, q.z / 1150.0 + cwp.y * 0.16) + vec3(0.31, 0.0, 0.17), 0.0).g;
                        float er2 = mix(0.26, 0.05, strat) * smoothstep(0.0, 0.35, d) * farK;
                        d = clamp((d - (1.0 - det2) * er2) / (1.0 - er2), 0.0, 1.0);
                        ${lite ? '' : `if (gLod > 0.02) {
                            float det3 = textureLod(noiseTex, vec3(q.x / 410.0, q.y / 410.0 + time * 0.010, q.z / 410.0) + vec3(0.63, 0.0, 0.41), 0.0).g;
                            float er3 = mix(0.17, 0.035, strat) * smoothstep(0.0, 0.30, d) * gLod;
                            d = clamp((d - (1.0 - det3) * er3) / (1.0 - er3), 0.0, 1.0);
                        }`}
                    }
                    return d * d * (3.0 - 2.0 * d);
                }

                // Rain shaft: a volumetric curtain hanging from the cloud it falls out of. It lives in world space and is built to
                // look like part of the cloud rather than a separate object:
                //  - it only exists where the cloud overhead really has mass (cloud density is sampled up at the base), so shafts
                //    hang from cloud bodies and fade out where the cloud thins - never from empty sky;
                //  - the shaft is a soft, dark, striated core (domain-warped strands) that is darkest right under the base, leans
                //    downwind and HOOKS the further it falls, and flares wider (more so under bigger clouds) as it descends;
                //  - the strands blur together toward the ground, and the lower part turns into a pale, wide MIST SKIRT that
                //    spreads out along the surface (spray + outflow) instead of the curtain just stopping;
                //  - light rain ends in ragged, tapering virga well above the ground; heavy rain reaches it and melts into the haze.
                float rainDensity(vec3 p, vec4 w, float camT) {
                    float pr = w.g;
                    if (pr < 0.07) return 0.0;
                    vec4 g = gG;
                    if (p.y > g.x + 250.0) return 0.0;
                    float size = gSz;
                    float lat = smoothstep(0.10, 0.62, pr);
                    float vTop = 1.0 - smoothstep(g.x - 160.0, g.x + 250.0, p.y);
                    float gnd = mix(gGround, floorY, 1.0 - smoothstep(1500.0, 4500.0, camT));
                    float fall = max(g.x - p.y, 0.0);
                    float fr = clamp(fall / max(g.x - gnd, 300.0), 0.0, 1.0);          // 0 at the cloud base, 1 at the ground
                    float near = smoothstep(10.0, 260.0, camT);
                    // darkest just under the base, thinning a little as it falls
                    float vMid = mix(0.62, 1.0, 1.0 - smoothstep(150.0, 1500.0, fall));
                    // wind shear: the strands lag the cloud and curve downwind, hooking more the further they fall
                    vec2 lean = windDir * (p.y - g.x) * (0.20 + 0.22 * fr);
                    vec3 wq = vec3(wq2(p.xz).x / 5200.0, p.y / 9000.0 + time * 0.012, wq2(p.xz).y / 5200.0);
                    vec2 warpM = (textureLod(noiseTex, wq + 0.23, 0.0).rb - 0.5) * 2.0 * 520.0 * (0.25 + 0.75 * fr);
                    vec2 pc = p.xz + lean + warpM;                                      // where this strand started, up at the cloud base
                    // is there cloud up there? two samples, the second pushed outward as the shaft falls so it flares and feathers
                    float hT = g.x + g.y * 0.14;
                    vec2 o2 = vec2(0.80, 0.60) * (250.0 + (650.0 + 1500.0 * size) * fr);
                    vec3 pa = vec3(pc.x, hT, pc.y), pb = vec3(pc.x + o2.x, hT + g.y * 0.10, pc.y + o2.y);
                    float mA = textureLod(noiseTex, vec3(wq2(pa.xz).x, 0.37, wq2(pa.xz).y) / 31000.0, 0.0).b;
                    float mB = textureLod(noiseTex, vec3(wq2(pb.xz).x, 0.37, wq2(pb.xz).y) / 31000.0, 0.0).b;
                    float under = smoothstep(0.03, 0.55, max(cloudDensity(pa, w, mA, -1.0), 0.70 * cloudDensity(pb, w, mB, -1.0)));
                    // a raining cell ALWAYS has a shaft under it, even where the cloud noise happens to be thin right at the base
                    under = max(under, 0.80 * smoothstep(0.30, 0.62, pr) * smoothstep(0.30, 0.65, w.r));
                    float reach = mix(0.50, 1.02, smoothstep(0.12, 0.60, pr));
                    float rag = textureLod(noiseTex, vec3(wq2(pc).x, 0.2, wq2(pc).y) / 1900.0 + 0.17, 0.0).g;
                    float endFr = 2.0;   // rain shafts never stop short: they always run all the way down to (and under) the ground
                    // soft strands: broad body + medium strands (stretched vertically) + a fine veil
                    vec3 q = vec3(wq2(pc).x / 2300.0, p.y / 12000.0 + time * 0.035, wq2(pc).y / 2300.0);
                    float b0 = textureLod(noiseTex, q * vec3(0.42, 0.50, 0.42), 0.0).g;
                    float b1 = textureLod(noiseTex, q * vec3(1.35, 0.30, 1.35) + 0.31, 0.0).g;
                    float b2 = textureLod(noiseTex, q * vec3(4.20, 0.12, 4.20) + 0.67, 0.0).g;
                    float sd = b0 * 0.38 + b1 * 0.38 + b2 * 0.24;
                    // strand contrast fades toward the ground, where the rain blurs into a smooth veil
                    float streak = mix(mix(0.08, 1.0, smoothstep(0.30, 0.74, sd)), 0.80, 0.40 * smoothstep(0.35, 1.0, fr));
                    gStreak = smoothstep(0.28, 0.85, sd);
                    float vBot = smoothstep(gnd - 420.0, gnd + 40.0, p.y);   // only the terrain itself ends a shaft
                    float shaft = under > 0.0 ? pr * lat * vTop * vBot * vMid * streak * under * near * 0.98 : 0.0;
                    // ---- mist skirt: rain that reaches the ground spreads into a wide, low, pale veil (much wider than the shaft) ----
                    float aboveG = p.y - gnd;
                    float skirtH = 260.0 + 260.0 * size;
                    float fm = textureLod(noiseTex, vec3(wq2(p.xz).x, p.y * 0.4, wq2(p.xz).y) / 2600.0 + 0.41, 0.0).g;
                    float heavy = smoothstep(0.34, 0.70, pr);
                    float skirt = heavy * smoothstep(gnd - 60.0, gnd + 50.0, p.y) * (1.0 - smoothstep(0.0, skirtH, aboveG))
                                * (0.30 + 0.70 * smoothstep(0.30, 0.78, fm)) * smoothstep(0.55, 0.95, endFr + 0.35) * near * 0.34;
                    // lowest part of the shaft itself also thickens a little as it meets the ground
                    float flare = 1.0 + 0.55 * smoothstep(0.70, 1.0, fr) * heavy;
                    // standing in the rain: a wet haze all around you, from the ground up to the cloud base, so it actually gets murky
                    float inside = rainIn * smoothstep(0.30, 0.62, pr) * (1.0 - smoothstep(g.x - 100.0, g.x + 200.0, p.y)) * (1.0 - smoothstep(250.0, 2600.0, camT)) * 0.55;
                    return shaft * flare + skirt;   // (the old camera-centred 'inside' haze dome is gone: real fog now does that job, per fragment, with no edge)
                }

                void main() {
                    vec3 ro = cameraPosition; vec3 rd = normalize(vDir);
                    // The march must always reach down to the ground: rain shafts hang below the cloud base and are seen
                    // from afar, so the slab can no longer stop at 1000 m unless it is raining on the player.
                    float botY = -60.0;
                    float t0, t1;
                    if (abs(rd.y) < 1e-4) { if (ro.y < botY || ro.y > TOP) discard; t0 = 0.0; t1 = MAXD; }
                    else {
                        float ta = (botY - ro.y) / rd.y, tb = (TOP - ro.y) / rd.y;
                        t0 = max(min(ta, tb), 0.0); t1 = max(ta, tb);
                    }
                    if (t1 <= 0.0) discard;
                    t1 = min(t1, MAXD);
                    if (t1 <= t0) discard;
                    // a camera below the cloud deck never needs rays that point well below the horizon
                    if (ro.y < BASE && rd.y < -0.30) discard;

                    int maxSteps = int(mix(34.0, float(STEPS), quality));
                    float dMin = clamp((t1 - t0) / (float(maxSteps) * 0.8), 60.0, 190.0);
                    float jit = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
                    float t = t0 + clamp(t0 * 0.06, dMin, 900.0) * jit;

                    vec3 L = sunDir.y > -0.1 ? sunDir : -sunDir;
                    float day = 1.0 - nightFactor;
                    vec3 sunH = wxHue(sunColor);
                    vec3 lightCol = mix(mix(sunH, vec3(1.0), 0.30) * 1.10, vec3(0.45, 0.55, 0.9) * 0.26, nightFactor);
                    float cosT = dot(rd, L);
                    // Multiple scattering (Wrenninge-style octaves): each higher order is dimmer, extinguishes more slowly and scatters
                    // more evenly. Together they give the bright, soft, glowing interiors real cumulus has - a single Beer term can only
                    // make a cloud either lit or black. silverK is the narrow forward lobe that lights thin edges right around the sun.
                    float ph0 = wxPhase(cosT, 1.0), ph1 = wxPhase(cosT, 0.55), ph2 = wxPhase(cosT, 0.30);
                    float silverK = min(wxHG(cosT, 0.93) * 0.50, 3.0);
                    // shaded sides are lit by the ACTUAL sky: blue overhead by day, pink/orange near the horizon at dusk, dim blue at
                    // night; the underside also gets a muted bounce of the land colour.
                    vec3 skyTopC = mix(wxHue(skyZen * 0.35 + skyMid * 0.65), vec3(1.0), 0.42);
                    vec3 skyHorC = mix(wxHue(skyHor), vec3(1.0), 0.40);
                    vec3 gndC = mix(wxHue(groundCol), vec3(1.0), 0.30) * 0.52;
                    // rainbow geometry: primary bow 40.5-42.5 deg and secondary 50.5-53.5 deg from the anti-solar point; needs a low sun
                    float bowK = smoothstep(-0.02, 0.06, L.y) * (1.0 - smoothstep(0.55, 0.72, L.y)) * day;
                    float bowTh = acos(clamp(-cosT, -1.0, 1.0));
                    float lodQ = step(0.45, quality);

                    float T = 1.0; vec3 acc = vec3(0.0); float wSum = 0.0, tSum = 0.0; float tFirst = -1.0;
                    // Two-speed march: big cheap strides through empty sky, and the moment a cloud is touched the
                    // ray steps back and walks it in fine steps. That is what makes cloud edges crisp and
                    // grain-free (no more razor-edge hit-or-miss sampling at distance).
                    bool fine = false; int miss = 0; float tTouch = 0.0;
                    for (int i = 0; i < STEPS; i++) {
                        if (i >= maxSteps || t > t1 || T < 0.025) break;
                        float dtc = clamp(t * 0.06, dMin, 900.0);
                        float dt = fine ? clamp(t * 0.011, 45.0, 190.0) : dtc;
                        vec3 p = ro + rd * t;
                        vec4 w = wxSampleS(p.xz);
                        vec4 trn = wxTerrS(p.xz); gLift = trn.r * 4000.0; gGround = trn.g * 8000.0;
                        if (t > 150.0 && p.y < gGround - 460.0) break;   // buried in a hill: nothing behind it can be seen, and cutting here avoids the hard depth-test silhouette
                        // storm cells upwind of here: this is where their anvil shelf spreads out (it blows downwind)
                        gAnv = clamp(max(wxSampleS(p.xz - windDir * 2600.0).b, 0.80 * wxSampleS(p.xz - windDir * 5400.0).b), 0.0, 1.0);
                        // empty sky (no cloud, no anvil, no rain here): cloudDensity and rainDensity would both return 0, so skip the
                        // noise fetches entirely. Same result as before, just without the work.
                        if (!fine && w.r < 0.17 && gAnv < 0.12 && w.g < 0.07) { t += dt; continue; }
                        vec2 pw = wq2(p.xz);
                        float macro = textureLod(noiseTex, vec3(pw.x, 0.37, pw.y) / 31000.0, 0.0).b;
                        gMass = macro;
                        gG = cloudGeom(w); gSz = cloudSize(w);
                        gT = t;
                        gLod = (1.0 - smoothstep(4500.0, 14000.0, t)) * lodQ;
                        float dtp = fine ? dt : -1.0;
                        float d = cloudDensity(p, w, macro, dtp);
                        float dr = rainDensity(p, w, t);
                        float eC = d * (0.40 + 0.60 * d) * 0.0118, eR = dr * 0.0022;
                        float ext = eC + eR;
                        if (!fine && d > 0.004) {
                            // touched a cloud: back up one stride and re-walk it finely (jittered start)
                            fine = true; miss = 0; tTouch = t;
                            t = max(t - dtc, t0) + clamp(t * 0.011, 45.0, 150.0) * jit;
                            continue;
                        }
                        if (ext > 0.00004) {
                            vec4 g = gG;
                            float hh = clamp((p.y - g.x) / g.y, 0.0, 1.0);
                            float wet = smoothstep(0.2, 0.85, w.g + w.b * 0.6);
                            vec3 cloudCol = vec3(0.0);
                            if (d > 0.004) {
                                miss = 0;
                                float od = cloudDensity(p + L * 90.0, w, macro, -1.0) * 90.0
                                         + cloudDensity(p + L * 260.0, w, macro, -1.0) * 170.0
                                         + cloudDensity(p + L * 700.0, w, macro, -1.0) * 440.0;
                                ${lite ? '' : 'if (quality > 0.5) od += cloudDensity(p + L * 1600.0, w, macro, -1.0) * 900.0;'}
                                od *= 1.0 - 0.45 * g.w;
                                float msum = ph0 * exp(-od * 0.0068) + 0.56 * ph1 * exp(-od * 0.0027) + 0.32 * ph2 * exp(-od * 0.0010);
                                float silver = silverK * exp(-od * 0.0032) * (1.0 - d * 0.50);
                                float ao = ${lite ? '0.8' : 'exp(-cloudDensity(p + vec3(0.0, 420.0, 0.0), w, macro, -1.0) * 1.7)'};
                                // billow shading: compare this (eroded) density with the density a short step toward the sun. Lumps whose sun side is
                                // thinner catch the light, lumps shadowed by their neighbour fall into shade - this is what makes a cumulus read as a
                                // cluster of rounded billows instead of one smooth airbrushed blob
                                float dSun = cloudDensity(p + L * 55.0, w, macro, dtp);
                                float facing = clamp(0.5 + (d - dSun) * 3.2, 0.0, 1.0);
                                float powder = 1.0 - 0.20 * exp(-d * 6.0) * (0.5 - 0.5 * cosT);
                                vec3 direct = lightCol * (msum * mix(0.58, 1.32, facing) + silver) * mix(1.0, 0.70, wet) * powder;
                                vec3 sky = mix(mix(gndC, skyHorC, smoothstep(0.0, 0.22, hh)), skyTopC, smoothstep(0.18, 0.85, hh));
                                sky = mix(sky, fogColor * 1.1, 0.16);
                                sky = mix(sky, vec3(0.64, 0.57, 0.44), wet * 0.60);
                                float amb = mix(0.34, 1.0, smoothstep(0.0, 0.45, hh)) * mix(0.30, 1.0, ao) * (1.0 - nightFactor * 0.82);
                                vec3 ambient = sky * amb * mix(0.72, 0.50, wet);
                                vec3 src = direct * 1.02 + ambient * 0.50;
                                // warm sunlit rim vs cool shadow core (the colour contrast that makes painted-sky clouds feel lit)
                                src *= mix(vec3(0.94, 0.98, 1.05), vec3(1.05, 1.01, 0.94), clamp(msum * 0.55, 0.0, 1.0));
                                // RAIN CLOUDS: dark, heavy bottoms. A cloud that is raining (or is a storm core / thick overcast sheet) loses most of its
                                // light toward the underside, so the base reads slate-grey/blue-black while the tops stay bright.
                                float rainyK = clamp(smoothstep(0.10, 0.55, w.g) + 0.75 * smoothstep(0.15, 0.7, w.b) + 0.35 * wet, 0.0, 1.0);
                                float bottomK = rainyK * (1.0 - smoothstep(0.0, 0.62, hh)) * (1.0 - nightFactor * 0.4);
                                src *= mix(vec3(1.0), vec3(0.23, 0.24, 0.27), bottomK * 0.88);
                                src = 1.0 - exp(-src * 1.25);
                                float lum = dot(src, vec3(0.299, 0.587, 0.114));
                                src = mix(src, vec3(lum) * vec3(1.07, 1.0, 0.86), clamp(grey * 0.4 + wet * 0.45, 0.0, 0.8));
                                float lg = wxLightning.w * exp(-length(p - wxLightning.xyz) / 3600.0);
                                src += vec3(0.62, 0.74, 1.0) * (lg * 3.2 + wxFlash * 0.22) * (0.4 + 0.6 * smoothstep(0.0, 0.3, d));
                                cloudCol = src;
                            } else if (fine && t > tTouch) miss++;
                            // rain takes the colour of the cloud deck it hangs from: the same underside sky/ambient mix, the same tone curve
                            // and desaturation, then it picks up the surrounding haze the further down it falls
                            vec3 rSky = mix(mix(vec3(0.40, 0.50, 0.70), skyHorC * 0.55, 0.45), fogColor * 1.1, 0.30);
                            rSky = mix(rSky, vec3(0.64, 0.57, 0.44), wet * 0.60);
                            vec3 rAmbient = rSky * 0.30 * (1.0 - nightFactor * 0.82) * mix(0.72, 0.50, wet);
                            vec3 rDirect = lightCol * (0.12 + 0.05 * ph0 * 0.25) * mix(1.0, 0.70, wet);
                            float rainBack = pow(max(cosT, 0.0), 3.0);
                            vec3 rSrc = rDirect + rAmbient * 0.85 + lightCol * rainBack * 0.20 * (0.4 + 0.6 * gStreak);
                            rSrc = 1.0 - exp(-rSrc * 1.15);
                            float rLum = dot(rSrc, vec3(0.299, 0.587, 0.114));
                            rSrc = mix(rSrc, vec3(rLum) * vec3(1.07, 1.0, 0.86), clamp(grey * 0.4 + wet * 0.45, 0.0, 0.8));
                            float rFall = clamp((g.x - p.y) / max(g.x - gGround, 300.0), 0.0, 1.0);
                            rSrc = mix(rSrc, fogColor * mix(1.0, 0.35, nightFactor) * 0.95, mix(0.5, 0.82, smoothstep(0.55, 1.0, rFall)) * smoothstep(0.1, 1.0, rFall));
                            vec3 rainCol = rSrc * mix(0.86, 1.10, gStreak);
                            rainCol += vec3(0.62, 0.74, 1.0) * wxFlash * 0.25;
                            // RAINBOW: sunlight refracted back by the falling drops. It exists only inside rain shafts the sun actually reaches,
                            // on the side of the sky opposite the sun, as a coloured ring around the anti-solar point (primary + faint secondary).
                            if (bowK > 0.0 && dr > 0.01) {
                                float u1 = (bowTh - 0.7069) / 0.0349;
                                float u2 = (0.9338 - bowTh) / 0.0524;
                                float m1 = step(0.0, u1) * step(u1, 1.0), m2 = step(0.0, u2) * step(u2, 1.0);
                                if (m1 + m2 > 0.0) {
                                    float sv = exp(-(cloudDensity(p + L * 700.0, w, macro, -1.0) * 700.0 + cloudDensity(p + L * 2000.0, w, macro, -1.0) * 1300.0) * 0.0046);
                                    float u = m1 > 0.0 ? u1 : u2;
                                    float bm = (m1 * 1.0 + m2 * 0.30) * sin(3.14159 * u);
                                    rainCol += wxSpectrum(u) * bm * sv * bowK * (0.55 + 0.45 * gStreak) * 1.5;
                                }
                            }
                            vec3 c = (cloudCol * eC + rainCol * eR) / ext;
                            float a = 1.0 - exp(-ext * dt);
                            float wgt = T * a;
                            acc += wgt * c; wSum += wgt; tSum += wgt * t;
                            T *= (1.0 - a);
                            if (tFirst < 0.0 && T < 0.88) tFirst = t;
                        } else if (fine && t > tTouch) miss++;
                        if (fine && miss >= 3) fine = false;
                        t += dt;
                    }
                    float alpha = 1.0 - T;
                    if (alpha < 0.003) discard;
                    float tHit = wSum > 0.0 ? tSum / wSum : t0;
                    // aerial perspective: distant cloud melts into the horizon haze (a touch brighter on the sun's side, like the sky behind it),
                    // then fades out entirely
                    float hz = 1.0 - exp(-tHit * 0.000034);
                    vec3 hazeC = fogColor + sunH * pow(max(cosT, 0.0), 6.0) * 0.16 * day;
                    acc = mix(acc, hazeC * alpha * mix(1.0, 0.35, nightFactor), hz * 0.72);
                    acc *= mix(1.0, 0.7, nightFactor);
                    // night: clouds recede into the dark - a clear night's clouds are faint dark wisps that let the stars show through,
                    // while a heavily overcast / stormy night keeps most of its density so the weather still reads
                    float nVis = mix(1.0, mix(${env.nightMin.toFixed(3)}, ${env.nightOver.toFixed(3)}, clamp(grey, 0.0, 1.0)), nightFactor);
                    acc *= nVis; alpha *= nVis;
                    float fade = 1.0 - smoothstep(24000.0, MAXD, tHit);
                    acc *= fade; alpha *= fade;
                    // depth of the density-weighted cloud position so terrain/mountains occlude correctly
                    float tDep = tFirst > 0.0 ? mix(tFirst, tHit, 0.30) : tHit;
                    vec4 clip = projectionMatrix * viewMatrix * vec4(ro + rd * tDep, 1.0);
                    #ifdef USE_LOGDEPTHBUF
                        gl_FragDepth = log2(max(1.0 + clip.w, 1.0)) * logDepthBufFC * 0.5;
                    #else
                        gl_FragDepth = clamp(clip.z / clip.w * 0.5 + 0.5, 0.0, 1.0);
                    #endif
                    gl_FragColor = vec4(acc, alpha);
                }
            `;
            return { vertexShader, fragmentShader };
        }


        // Thin planar cloud sheets built from the same noise volume. kind 1 = altostratocumulus,
        // kind 2 = cirrus (wind-combed filaments that thicken ahead of fronts).
export function wxLayeredShaders(cfg, env) {
            const f = (v) => Number(v).toFixed(4);
            const vertexShader = `
                varying vec3 vWorldPos; varying vec2 vLocalXZ;
                #ifdef USE_LOGDEPTHBUF
                    varying float vFragDepth; varying float vIsPerspective;
                #endif
                void main() {
                    vLocalXZ = position.xz;
                    vec4 wp = modelMatrix * vec4(position, 1.0);
                    vWorldPos = wp.xyz;
                    gl_Position = projectionMatrix * viewMatrix * wp;
                    #ifdef USE_LOGDEPTHBUF
                        vFragDepth = 1.0 + gl_Position.w; vIsPerspective = 1.0;
                    #endif
                }
            `;
            const fragmentShader = `
                precision highp float; precision highp sampler3D;
                uniform vec3 sunDir; uniform vec3 sunColor; uniform vec3 fogColor; uniform float time; uniform float nightFactor;
                uniform vec2 windOff; uniform vec2 windDir; uniform float grey; uniform vec4 wxM4;
                vec2 wq2(vec2 xz) { return mat2(wxM4.x, wxM4.y, wxM4.z, wxM4.w) * xz + windOff; }
                uniform sampler3D noiseTex;
                uniform vec3 skyZen; uniform vec3 skyMid; uniform vec3 skyHor;
                varying vec3 vWorldPos; varying vec2 vLocalXZ;
                #ifdef USE_LOGDEPTHBUF
                    uniform float logDepthBufFC; varying float vFragDepth; varying float vIsPerspective;
                #endif
                ${wxGlslCommon(env)}
                void main() {
                    #ifdef USE_LOGDEPTHBUF
                        gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2(vFragDepth) * logDepthBufFC * 0.5;
                    #endif
                    float camDy = abs(cameraPosition.y - ${f(cfg.altitude)});
                    float camFade = smoothstep(40.0, 700.0, camDy);
                    vec3 vdir = vWorldPos - cameraPosition;
                    // sheets viewed edge-on near the horizon alias into hatching: fade them out smoothly
                    float vlen = max(length(vdir), 1.0);
                    float sinE = abs(vdir.y) / vlen;
                    camFade *= smoothstep(0.03, 0.22, sinE);
                    if (camFade <= 0.002) discard;
                    // v100: a flat sheet is squeezed along the view direction the lower you look and the further it runs, which turned the noise into
                    // thin hard-edged streaks. Both effects soften the sheet instead: the finest octaves fade out and the edges widen (blurK 0 overhead / near,
                    // 1 low on the horizon / far away), so what is squeezed also gets blurred rather than staying razor sharp.
                    float blurK = clamp(max(smoothstep(8000.0, 50000.0, vlen), 0.85 * (1.0 - smoothstep(0.10, 0.50, sinE))), 0.0, 1.0);
                    float softK = 1.0 + 2.0 * blurK;
                    vec4 w = wxSampleS(vWorldPos.xz);
                    float wetDark = smoothstep(0.25, 0.85, w.g + w.b * 0.7);
                    vec2 xz = wq2(vWorldPos.xz);
                    vec3 L = sunDir.y > -0.1 ? sunDir : -sunDir;
                    float thr; float opMul = 1.0; float density; float densUp;
                    ${cfg.kind === 1 ? `
                        float m = smoothstep(0.10, 0.80, w.r);
                        thr = mix(0.70, 0.40, m); opMul = 0.45 + 0.55 * m;
                        vec3 q = vec3(xz.x / ${f(cfg.scale)}, time * 0.0005, xz.y / ${f(cfg.scale * 1.15)});
                        float kb = 1.0 - 0.55 * blurK, kc = 1.0 - blurK;
                        float flat0 = 0.5 * (0.30 * (1.0 - kb) + 0.15 * (1.0 - kc));   // the faded octaves collapse to their mean (0.5)
                        vec4 a = textureLod(noiseTex, q, 0.0);
                        vec4 b = textureLod(noiseTex, q * 2.9 + 0.17, 0.0);
                        vec4 c3 = textureLod(noiseTex, q * 8.3 + 0.41, 0.0);
                        float n = a.r * 0.55 + b.g * 0.30 * kb + c3.g * 0.15 * kc + flat0;
                        vec4 a2 = textureLod(noiseTex, q + vec3(L.x, 0.0, L.z) * 0.012, 0.0);
                        vec4 b2 = textureLod(noiseTex, (q + vec3(L.x, 0.0, L.z) * 0.012) * 2.9 + 0.17, 0.0);
                        vec4 c32 = textureLod(noiseTex, (q + vec3(L.x, 0.0, L.z) * 0.012) * 8.3 + 0.41, 0.0);
                        float n2 = a2.r * 0.55 + b2.g * 0.30 * kb + c32.g * 0.15 * kc + flat0;
                        density = smoothstep(thr, thr + ${f(cfg.softness)} * softK, n);
                        densUp = smoothstep(thr, thr + ${f(cfg.softness)} * softK, n2);` : `
                        vec2 wd = normalize(mat2(wxM4.x, wxM4.y, wxM4.z, wxM4.w) * windDir + vec2(0.0001));   // v64: windDir is in chart axes, xz is in the canonical weather frame
                        vec2 pr = vec2(dot(xz, wd), dot(xz, vec2(-wd.y, wd.x)));
                        float jetS = wxTerrS(vWorldPos.xz).b;
                        float m = clamp(0.35 + 0.4 * smoothstep(0.1, 0.55, w.r) * (1.0 - smoothstep(0.7, 0.95, w.r)) + 0.5 * jetS, 0.0, 1.0);
                        // v101: the jet-stream combing used to divide the ABSOLUTE coordinate (pr.x is tens of thousands of units out in the world).
                        // The jet map is re-swapped every half second (and is empty for the first one), so every swap slid the whole sheet across the
                        // sky - the fast high clouds at the start of the game. The stretch is now measured from the point above the camera: the sky
                        // overhead no longer depends on it at all, only the far field is combed.
                        vec2 xzA = wq2(cameraPosition.xz);
                        float prAx = dot(xzA, wd);
                        pr.x = prAx + (pr.x - prAx) / (1.0 + 0.9 * jetS);
                        thr = mix(0.80, 0.52, m); opMul = 1.0 - 0.8 * smoothstep(0.75, 0.95, w.r);
                        vec3 q = vec3(pr.x / ${f(cfg.scale * 1.7)}, pr.y / ${f(cfg.scale * 0.9)}, time * 0.0004);
                        float warp = textureLod(noiseTex, q * 0.4 + 0.5, 0.0).a - 0.5;
                        q.y += warp * 0.9;
                        vec4 a = textureLod(noiseTex, q, 0.0);
                        float fib = textureLod(noiseTex, vec3(pr.x / ${f(cfg.scale * 1.0)}, pr.y / ${f(cfg.scale * 0.30)}, 0.3), 0.0).g;
                        float fib2 = textureLod(noiseTex, vec3(pr.x / ${f(cfg.scale * 0.5)}, pr.y / ${f(cfg.scale * 0.12)}, 0.7), 0.0).g;
                        float kf = 1.0 - 0.7 * blurK, kf2 = 1.0 - blurK;
                        float n = clamp(a.r * 0.72 + (fib - 0.5) * 0.45 * kf + (fib2 - 0.5) * 0.22 * kf2 + 0.1, 0.0, 1.0);
                        density = smoothstep(thr, thr + ${f(cfg.softness)} * softK, n);
                        densUp = density * 0.9;`}
                    if (density <= 0.002) discard;
                    vec3 sunH = wxHue(sunColor);
                    float lowSun = 1.0 - smoothstep(0.02, 0.40, L.y);                  // 0 at noon .. 1 at sunset
                    vec3 viewDir = normalize(cameraPosition - vWorldPos);
                    float cs = dot(-viewDir, L);                                       // 1 = looking straight at the sun
                    float lightAmt = clamp(0.55 + (density - densUp) * 1.6 + L.y * 0.25, 0.05, 1.15);
                    lightAmt *= 1.0 - 0.22 * wetDark;
                    vec3 base = mix(${cfg.shadowCol}, ${cfg.litCol}, lightAmt);
                    base *= mix(vec3(1.0), sunH, 0.55 + 0.30 * lowSun);
                    // the shaded side takes the colour of the sky near the horizon: cool by day, rose and amber at dusk
                    base = mix(base, base * mix(vec3(1.0), wxHue(skyHor) * 1.1, 0.35 + 0.30 * lowSun), (1.0 - lightAmt * 0.7) * (0.4 + 0.6 * lowSun));
                    float lum = dot(base, vec3(0.299, 0.587, 0.114));
                    base = mix(base, vec3(lum) * vec3(1.07, 1.0, 0.86), clamp(grey * 0.4 + wetDark * 0.5, 0.0, 0.85));
                    // forward scattering: a broad glow toward the sun plus a narrow silver lining that is strongest on thin cloud
                    float sunFacing = pow(max(cs, 0.0), 10.0);
                    float silver = pow(max(cs, 0.0), 46.0);
                    base += sunH * (sunFacing * 0.55 + silver * 1.1 * (1.0 - density * 0.6)) * density * (1.0 - wetDark);
                    float lg = wxLightning.w * exp(-length(vWorldPos - wxLightning.xyz) / 4200.0);
                    base += vec3(0.62, 0.74, 1.0) * (lg * 2.6 + wxFlash * 0.2);
                    float camDist = length(cameraPosition - vWorldPos);
                    float fogBlend = clamp(camDist / ${f(cfg.edgeStart * 0.6)}, 0.06, 0.88);
                    base = mix(base, fogColor, fogBlend);
                    base *= mix(1.0, 0.3, nightFactor * 0.85);
                    float edgeFade = 1.0 - smoothstep(${f(cfg.edgeStart)}, ${f(cfg.edgeEnd)}, length(vLocalXZ));
                    float alpha = pow(density, ${f(cfg.densityPow)}) * ${f(cfg.opacity)} * opMul * edgeFade * camFade;
                    // high thin cloud almost vanishes at night (it would otherwise glow unnaturally against the stars)
                    alpha *= mix(1.0, mix(0.22, 0.70, clamp(grey, 0.0, 1.0)), nightFactor);
                    gl_FragColor = vec4(base, clamp(alpha, 0.0, 1.0));
                }
            `;
            return { vertexShader, fragmentShader };
        }
