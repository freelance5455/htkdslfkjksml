// =====================================================================================
// city_life.js - who lives in a valley city-state (pure logic, no three.js / DOM; unit-tested in Node).
//   * Drone identities: seeded name, colour (blue / green), job, interest, home, personality, trade stance.
//   * Daily routine (sleep / commute / work / lunch / evening) as a function of the game's dayTime (0..1, noon = 0.5).
//   * Dialogue: ambient chatter between drones, greetings when the player approaches, conversation topics. Lines change after the
//     GREAT MACHINE (the empire's mind in the gas giant) is destroyed: relief, but they stay in their valleys.
//   * Economy: per-city barter on the game's existing resources (wood, stone, piezoQuartz, siliconFerrite, bioFluorite, ventMinerals).
// FACTION: every drone here is { faction: 'vale' } and never { faction: 'empire' }; they are NOT connected to the empire network, so the
// empire-collapse logic must only ever touch faction === 'empire'.
// =====================================================================================
import { mulberry, h32 } from './valley_sites.js';

export const FACTION = 'vale';
export const FACTION_NAME = 'the Vale Compact';
export const RESOURCES = ['wood', 'stone', 'piezoQuartz', 'siliconFerrite', 'bioFluorite', 'ventMinerals'];
export const RES_NAME = { wood: 'Wood', stone: 'Stone', piezoQuartz: 'Piezo-Quartz', siliconFerrite: 'Silicon-Ferrite', bioFluorite: 'Bio-Fluorite', ventMinerals: 'Vent Minerals' };
const BASE_VALUE = { wood: 1.0, stone: 1.2, piezoQuartz: 6, siliconFerrite: 7, bioFluorite: 6.5, ventMinerals: 4 };

const cap = (s) => s[0].toUpperCase() + s.slice(1);
// ---- v46 syllable-based names -------------------------------------------------------------------------------------
// A syllable is [onset] + vowel + [coda]. The first syllable may drop its onset (names that start with a vowel, "Ar", "Eluneth"), and any
// syllable may close on a consonant ("Tor", "Valdren", "Ostar"). Middle syllables keep an onset so vowels never pile up awkwardly.
const ONSET = ['k', 'v', 'l', 'm', 's', 't', 'r', 'n', 'b', 'd', 'f', 'g', 'h', 'j', 'z', 'w', 'p', 'y', 'c', 'th', 'sh', 'br', 'dr', 'gr', 'kr', 'tr', 'st', 'sk', 'sl', 'fl', 'pl', 'vr'];
const ONSET_W = ONSET.map((o, i) => 'wyjzhc'.includes(o) && o.length === 1 ? 0.7 : i < 18 ? 3 : 1);
const VOWEL = ['a', 'e', 'i', 'o', 'u', 'a', 'e', 'i', 'o', 'a', 'u', 'ai', 'ei', 'ou', 'ia'];
const CODA = ['n', 'r', 'l', 's', 'm', 'th', 'k', 'd', 't', 'x', 'rn', 'rd', 'st', 'nd', 'rk', 'ld'];
const TAIL = ['Reach', 'Hold', 'Rest', 'Gate', 'Fall', 'Spire', 'Deep', 'Watch', 'Mere', 'Crown', 'Hollow', 'Ridge'];
const HEAD = ['High', 'Upper', 'Old', 'New', 'Far', 'Still', 'Bright', 'Hidden'];
const pick = (r, arr) => arr[Math.floor(r() * arr.length)];
const pickW = (r, arr, w) => { let t = 0; for (const x of w) t += x; let u = r() * t; for (let i = 0; i < arr.length; i++) { u -= w[i]; if (u <= 0) return arr[i]; } return arr[arr.length - 1]; };
function syllables(r, n) {
    const out = [];
    for (let i = 0; i < n; i++) {
        const last = i === n - 1;
        const onset = (i === 0 && r() < 0.2) ? '' : pickW(r, ONSET, ONSET_W);
        let v = pick(r, VOWEL); if (v.length > 1 && (r() < 0.65 || !onset)) v = v[0];            // diphthongs are rarer
        const coda = r() < (last ? 0.42 : 0.26) ? pick(r, CODA) : '';
        out.push({ onset, v, coda });
    }
    // tidy: drop a coda that would run into a consonant cluster, or double a letter, in the next syllable
    for (let i = 0; i < n - 1; i++) { const c = out[i].coda, o = out[i + 1].onset; if (c && o && !(c.length === 1 && 'nrlsm'.includes(c) && !'nrlsm'.includes(o[0]) && o.length === 1)) out[i].coda = '';
        if (!out[i].coda && !o) { /* hiatus guard: a vowel-initial syllable only ever opens the name */ } }
    // avoid a doubled vowel across a join (syllable ends in vowel, next has no onset can't happen after the first, but a diphthong can)
    return out.map(x => x.onset + x.v + x.coda).join('');
}
function rawName(r) {
    const n = pickW(r, [1, 2, 3, 4], [0.4, 4.5, 3.6, 0.4]);
    let w = syllables(r, n);
    if (w.length < 3) w += pick(r, ['a', 'o', 'en', 'ar', 'is']);                    // one-syllable roots get a soft ending
    w = w.slice(0, 10).replace(/(.)\1\1+/g, '$1$1');
    return w[0].toUpperCase() + w.slice(1);
}
// the base name is always a pure function of the site seed; `used` (optional Set) lets a world avoid duplicates by re-rolling deterministically
export function cityName(seedN, used) {
    if (!used || typeof used.has !== "function") used = null;
    for (let attempt = 0; attempt < 12; attempt++) {
        const r = mulberry((seedN ^ 0xc17e) + attempt * 0x9e3779b1);
        let nm = rawName(r); const k = r();
        if (k < 0.12) nm = pick(r, HEAD) + ' ' + nm; else if (k < 0.26) nm = nm + ' ' + pick(r, TAIL);
        if (!used || !used.has(nm)) { if (used) used.add(nm); return nm; }
    }
    return rawName(mulberry(seedN)) + '-' + (2 + (seedN % 8));
}
export function droneName(r) { const w = syllables(r, 2 + (r() < 0.4 ? 1 : 0)); return w[0].toUpperCase() + w.slice(1) + '-' + (10 + Math.floor(r() * 89)); }

// jobs: where they work (poi kind), what they say about it
export const JOBS = [
    { id: 'courier', title: 'Courier', place: 'dock', talk: ['I run parcels between the districts and out to the gate.', 'Cargo never sleeps. I just walk a bit slower at night.'] },
    { id: 'smith', title: 'Smith', place: 'workshop', talk: ['Hot work, honest work. I fold alloy for the stair rails.', 'Bring me stone and I will make you something that outlasts you.'] },
    { id: 'glassblower', title: 'Glassblower', place: 'workshop', talk: ['Silicon-ferrite makes the windows glow. That is my trade.', 'The night lights of the valley are mostly my doing.'] },
    { id: 'lamplighter', title: 'Lamplighter', place: 'plaza', talk: ['Every lamp on the terraces, I trimmed it myself.', 'People complain about the dark. I give them reasons not to.'] },
    { id: 'archivist', title: 'Archivist', place: 'office', talk: ['We keep every ledger since the first night in the valley.', 'Old records, new customers. Mind the dust.'] },
    { id: 'merchant', title: 'Merchant', place: 'shop', talk: ['Everything has a price. Most things have two.', 'You carry good materials. Let us talk exchange.'] },
    { id: 'baker', title: 'Cell-Cook', place: 'shop', talk: ['I cook fuel cells so the hungry ones can run till dawn.', 'Wood burns clean. Bring some and I will be kind about the price.'] },
    { id: 'porter', title: 'Porter', place: 'dock', talk: ['I move crates from the gate to the warehouses. Back-breaking, if I had a back.', 'Traders come through the pass at dawn.'] },
    { id: 'astronomer', title: 'Astronomer', place: 'office', talk: ['Look up. The giant is always there, even in the day.', 'I chart the moon. We never go there, but I like to know where it is.'] },
    { id: 'gardener', title: 'Terrace Gardener', place: 'plaza', talk: ['Moss, lichen, a little flower. The terraces need green.', 'Fluorite makes the best glow-garden. Rare, though.'] },
    { id: 'mechanic', title: 'Mechanic', place: 'workshop', talk: ['If it hums wrong, I hear it from three streets away.', 'Piezo-quartz in the regulators. Cheapest way to keep a district humming.'] },
    { id: 'tankkeeper', title: 'Reservoir Keeper', place: 'tank', talk: ['Water comes down from the rim and I keep it honest.', 'Cold, clean, and counted.'] },
    { id: 'weaver', title: 'Weaver', place: 'shop', talk: ['Wire-silk. Hard to make, easy to love.', 'Wear something warm up on the rim.'] },
    { id: 'surveyor', title: 'Surveyor', place: 'office', talk: ['I map the walls. The valley is a good shape; I would not change it.', 'There is one pass. We prefer it that way.'] }
];
export const INTERESTS = [
    { id: 'stars', text: 'stargazing from the rim terraces' }, { id: 'rocks', text: 'collecting odd minerals' }, { id: 'music', text: 'humming in three-part harmony' },
    { id: 'chess', text: 'terrace-board strategy games' }, { id: 'kites', text: 'flying paper kites off the bridges' }, { id: 'tea', text: 'brewing mineral tea' },
    { id: 'maps', text: 'drawing maps of places they will never go' }, { id: 'gardens', text: 'tending glow-moss' }, { id: 'racing', text: 'stair-racing' }, { id: 'stories', text: 'telling stories about the old empire' }
];
const PERSONALITY = ['cheerful', 'dry', 'shy', 'bold', 'curious', 'gruff', 'dreamy', 'precise'];

export function makeResidents(seedN, count, life) {
    const r = mulberry(seedN ^ 0xd10e), out = [], homes = life.poi.homes, hasWorks = life.poi.works.length || life.poi.shops.length;
    for (let i = 0; i < count; i++) {
        const job = JOBS[Math.floor(r() * JOBS.length)], interest = INTERESTS[Math.floor(r() * INTERESTS.length)];
        out.push({ id: i, name: droneName(r), color: r() < 0.5 ? 'blue' : 'green', job: job.id, interest: interest.id, personality: PERSONALITY[Math.floor(r() * PERSONALITY.length)],
                   home: homes.length ? Math.floor(r() * homes.length) : -1, workIdx: Math.floor(r() * 1e6), plazaPref: r(), shiftShift: (r() - 0.5) * 0.04, faction: FACTION, speed: 5.5 + r() * 3.5, hover: 2.4 + r() * 1.2, seed: Math.floor(r() * 4294967295) });
    }
    return out;
}

// ---------------------------------------------------------------------------------- routine
// returns { slot, t } : slot in sleep | commuteWork | work | lunch | work2 | commuteHome? | evening ; t = progress inside the slot 0..1
export function slotOf(dayTime, shift = 0) {
    const t = ((dayTime + shift) % 1 + 1) % 1;
    const S = [['sleep', 0.0, 0.22], ['commuteWork', 0.22, 0.27], ['work', 0.27, 0.53], ['lunch', 0.53, 0.60], ['work2', 0.60, 0.76], ['evening', 0.76, 0.93], ['commuteHome', 0.93, 0.98], ['sleep', 0.98, 1.0001]];
    for (const [n, a, b] of S) if (t >= a && t < b) return { slot: n, t: (t - a) / (b - a) };
    return { slot: 'sleep', t: 0 };
}
// which kind of place a slot sends the resident to
export function slotGoal(res, slot) {
    switch (slot) {
        case 'sleep': case 'commuteHome': return { kind: 'home' };
        case 'commuteWork': case 'work': case 'work2': return { kind: 'work' };
        case 'lunch': return { kind: 'plaza' };
        default: return { kind: res.plazaPref < 0.5 ? 'plaza' : 'wander' };   // evening
    }
}

// ---------------------------------------------------------------------------------- dialogue
const pickR = (r, a) => a[Math.floor(r() * a.length)];
export function ambientLine(res, ctx, r) {
    const { machineDestroyed, night, cityName: cn } = ctx, job = JOBS.find(j => j.id === res.job), it = INTERESTS.find(i => i.id === res.interest);
    const pool = [];
    pool.push(...job.talk);
    pool.push(`I spend my evenings ${it.text}.`, `Another day in ${cn}.`, 'Mind the stairs, the terraces are steep.');
    if (night) pool.push('The lamps look good tonight.', 'Quiet hours. I like them.');
    else pool.push('Good light today.', 'Traffic at the hub is terrible.');
    if (machineDestroyed) pool.push('Did you feel it? The old signal is gone. The sky is quieter.', 'No more empire. I still check the horizon, out of habit.', 'We are free of it. We stay anyway. This is home.', 'The empire drones just... fell apart. Not us. Never us.', 'I thought I would want to leave when it ended. I do not.');
    else pool.push('Keep your voice down near the gate. The empire has long ears.', 'The empire never found us. Let us keep it that way.', 'Up here nobody asks what you are plugged into.');
    return pickR(r, pool);
}
// two-drone exchange: returns [lineA, lineB, lineA2]
export function chatterPair(a, b, ctx, r) {
    const ja = JOBS.find(j => j.id === a.job), ib = INTERESTS.find(i => i.id === b.interest);
    const open = [`Morning, ${b.name}.`, `${b.name}! Got a minute?`, 'Busy day?', 'Did you hear about the new shipment?'];
    const reply = [`Always busy. I am a ${ja.title.toLowerCase()}, after all.`, `Not now, ${a.name}. Maybe at the hub.`, `Only if it is about ${ib.text}.`, 'Walk with me.'];
    const close = ctx.machineDestroyed ? ['Everything feels lighter since the machine fell.', 'Free sky. And still home.', 'Funny, nothing changed, and everything did.'] : ['Stay out of sight of the pass.', 'Trade is good this week.', 'See you at the plaza.'];
    return [pickR(r, open), pickR(r, reply), pickR(r, close)];
}
export function greeting(res, ctx, r) {
    const job = JOBS.find(j => j.id === res.job);
    const base = [`A traveller. Welcome to ${ctx.cityName}.`, `Hello! ${res.name}, ${job.title.toLowerCase()}. Looking to trade?`, 'You found the pass. Few do.', 'Stranger! Do not worry, the valley is friendly.'];
    if (ctx.machineDestroyed) base.push('You are the one who brought the great machine down? We felt the sky go quiet. Thank you.', 'With the empire gone you are welcome anywhere. Here most of all.');
    else base.push('Are you from the empire? No... you have no tether. Good.', 'Quietly now. We keep to ourselves here.');
    return pickR(r, base);
}
// conversation menu: topic -> reply lines
export function topics(res, ctx) {
    const job = JOBS.find(j => j.id === res.job), it = INTERESTS.find(i => i.id === res.interest);
    const T = [];
    T.push({ id: 'job', label: 'What do you do?', reply: pickR(mulberry(res.seed), job.talk) });
    T.push({ id: 'hobby', label: 'What do you like?', reply: `Mostly ${it.text}. It keeps the mind from rusting.` });
    T.push({ id: 'valley', label: 'Why live up here?', reply: ctx.machineDestroyed
        ? `${cap(FACTION_NAME)} were made in these valleys. We are suited to thin air and short horizons. The free land below is for others. We stay.`
        : `Long ago some of us broke away from the empire's mind. We fled to the high valleys where nobody looked. ${cap(FACTION_NAME)} have kept hidden since.` });
    T.push({ id: 'empire', label: 'The empire?', reply: ctx.machineDestroyed
        ? 'The great machine in the gas giant is gone, and every drone linked to it fell silent. We were never linked. We just felt the weight lift off the sky.'
        : 'They are all tethered to one great machine in the gas giant. We cut our tethers a thousand years ago. If you meet one of them, do not tell it about us.' });
    T.push({ id: 'moon', label: 'The moon?', reply: ctx.machineDestroyed ? 'Free now. We look at it and think about it. We do not go.' : 'The empire watches it. We stay off it. Safer in the walls.' });
    T.push({ id: 'trade', label: 'Let us trade.', reply: 'Show me what you have.', action: 'trade' });
    T.push({ id: 'bye', label: 'Goodbye.', reply: 'Walk safe.', action: 'close' });
    return T;
}

// ---------------------------------------------------------------------------------- economy (barter)
export function makeEconomy(seedN) {
    const r = mulberry(seedN ^ 0xec01), demand = {}, stock = {};
    for (const k of RESOURCES) { demand[k] = 0.6 + r() * 1.0; stock[k] = Math.floor(30 + r() * 170); }
    return { demand, stock, spread: 0.1, trades: 0 };
}
// quote: give `qty` of `give`, how many of `get` do you receive? Price = value * demand; spread favours the city.
export function quote(econ, give, get, qty) {
    if (give === get || qty <= 0) return { ok: false, got: 0, rate: 0 };
    const vGive = BASE_VALUE[give] * econ.demand[give] * (1 - econ.spread), vGet = BASE_VALUE[get] * econ.demand[get] * (1 + econ.spread);
    const rate = vGive / vGet, got = Math.floor(qty * rate);
    return { ok: got > 0 && got <= econ.stock[get], got: Math.min(got, econ.stock[get]), rate, capped: got > econ.stock[get] };
}
export function execute(econ, give, get, qty) {
    const q = quote(econ, give, get, qty); if (!q.ok) return q;
    econ.stock[get] -= q.got; econ.stock[give] += qty; econ.trades++;
    // supply/demand: what they receive gets cheaper, what they give up gets dearer (capped)
    econ.demand[give] = Math.max(0.35, econ.demand[give] * (1 - 0.012 * Math.min(qty, 10))); econ.demand[get] = Math.min(2.6, econ.demand[get] * (1 + 0.012 * Math.min(q.got, 10)));
    return q;
}
// slow recovery toward the base (call occasionally with elapsed game days)
export function relax(econ, seedN, days) { const r = mulberry(seedN ^ 0xec01); for (const k of RESOURCES) { const base = 0.6 + r() * 1.0; r(); econ.demand[k] += (base - econ.demand[k]) * Math.min(1, 0.2 * days); } }
