// =====================================================================================
// weather_core.js - pure weather math (no three.js, no DOM), so it can be unit-tested in Node.
//
// The world's weather is a set of slowly evolving noise fields that are ADVECTED by the wind
// (the whole pattern slides across the map), modulated by the local climate (moisture,
// temperature, terrain height). Everything the renderer needs at a point in space comes from
// sampleWeather(): cloud cover, precipitation, convective storm energy, thunder potential,
// dust, and whether precipitation falls as snow.
// =====================================================================================

export const WX_MAP_N = 64;          // weather map resolution (texels per side)
export const WX_MAP_SIZE = 140000;   // world units covered by the weather map
export const WX_CLIM_N = 16;         // coarse climate grid resolution

export const clamp01 = (x) => x < 0 ? 0 : x > 1 ? 1 : x;
export const lerp = (a, b, t) => a + (b - a) * t;
export function smooth(a, b, x) {
    const t = clamp01((x - a) / (b - a));
    return t * t * (3 - 2 * t);
}

// Named weather states (used by the K-key cycler and the scripted voyage storm). Each is the
// full set of fields the renderer understands.
export const WX_PRESETS = [
    { name: 'Clear skies',          cover: 0.04, precip: 0.0,  storm: 0.0, thunder: 0.0, dust: 0.0, cold: 0.0, mist: 0.0,  wind: 0.20 },
    { name: 'Fair-weather cumulus', cover: 0.40, precip: 0.0,  storm: 0.0, thunder: 0.0, dust: 0.0, cold: 0.0, mist: 0.0,  wind: 0.30 },
    { name: 'Broken clouds',        cover: 0.66, precip: 0.0,  storm: 0.0, thunder: 0.0, dust: 0.0, cold: 0.0, mist: 0.0,  wind: 0.40 },
    { name: 'Overcast',             cover: 0.94, precip: 0.0,  storm: 0.0, thunder: 0.0, dust: 0.0, cold: 0.0, mist: 0.1,  wind: 0.35 },
    { name: 'Rain',                 cover: 0.97, precip: 0.45, storm: 0.0, thunder: 0.0, dust: 0.0, cold: 0.0, mist: 0.2,  wind: 0.50 },
    { name: 'Heavy rain',           cover: 1.0,  precip: 0.85, storm: 0.25, thunder: 0.0, dust: 0.0, cold: 0.0, mist: 0.3, wind: 0.65 },
    { name: 'Thunderstorm',         cover: 1.0,  precip: 0.95, storm: 1.0, thunder: 1.0, dust: 0.0, cold: 0.0, mist: 0.15, wind: 0.90 },
    { name: 'Snowfall',             cover: 0.95, precip: 0.45, storm: 0.0, thunder: 0.0, dust: 0.0, cold: 1.0, mist: 0.2,  wind: 0.30 },
    { name: 'Blizzard',             cover: 1.0,  precip: 1.0,  storm: 0.5, thunder: 0.0, dust: 0.0, cold: 1.0, mist: 0.3,  wind: 1.0 },
    { name: 'Dense fog',            cover: 0.55, precip: 0.0,  storm: 0.0, thunder: 0.0, dust: 0.0, cold: 0.0, mist: 1.0,  wind: 0.08 },
    { name: 'Sandstorm',            cover: 0.30, precip: 0.0,  storm: 0.0, thunder: 0.0, dust: 1.0, cold: 0.0, mist: 0.0,  wind: 0.95 },
];
export const WX_STORM_PRESET = WX_PRESETS[6];

export function makeFields() {
    return { cover: 0, precip: 0, storm: 0, thunder: 0, dust: 0, cold: 0, mist: 0, wind: 0.3, temp: 0.5 };
}

// clim: { moist 0..1, temp 0..1, height (world units above sea level), ocean (bool) }
// ax/az are ADVECTED coordinates (world position minus accumulated wind offset); evo is a slow
// evolution clock (seconds) that makes the pattern morph as it travels.
export function sampleWeather(noise2D, ax, az, evo, clim, out) {
    const a = noise2D(ax / 46000 + 311.7 + evo * 0.0021, az / 46000 - 97.3);
    const b = noise2D(ax / 17000 - 40.1, az / 17000 + 12.4 + evo * 0.0047);
    const c = noise2D(ax / 6500 + 7.7 - evo * 0.011, az / 6500 + 91.0);
    const raw = 0.5 + 0.5 * (a * 0.55 + b * 0.33 + c * 0.12);

    const moist = clim.moist, temp = clim.temp;
    const oro = smooth(800, 3500, clim.height) * 0.16 * moist;
    const hotDry = smooth(0.55, 0.8, temp) * (1 - smooth(0.15, 0.4, moist)) * 0.10;
    const cover = smooth(0.30, 0.86, raw + (moist - 0.5) * 0.34 + 0.05 + oro - hotDry);

    const s1 = noise2D(ax / 15000 + 55.5 + evo * 0.004, az / 15000 - 31.2);
    const s2 = noise2D(ax / 5200 - 12.9, az / 5200 + 70.4 - evo * 0.009);
    const sraw = 0.5 + 0.5 * (s1 * 0.7 + s2 * 0.3);
    const wet = 0.25 + 0.75 * moist;
    const storm = smooth(0.60, 0.84, sraw) * smooth(0.50, 0.85, cover) * wet * smooth(0.22, 0.5, temp);

    // stratiform (frontal) rain under thick cloud + intense convective rain under storm cells
    const frontal = smooth(0.90, 1.0, cover) * (0.25 + 0.75 * moist) * 0.95;
    const lump = 0.25 + 0.75 * smooth(-0.55, 0.65, c);
    const dry = smooth(0.06, 0.22, moist);              // deserts don't rain
    const precip = clamp01(Math.max(frontal * lump, storm * 1.1)) * dry;

    const warm = smooth(0.42, 0.66, temp);              // thunder needs warm, unstable air
    const thunder = storm * warm * dry;

    const hot = smooth(0.52, 0.76, temp), arid = 1 - smooth(0.18, 0.42, moist);
    const dust = smooth(0.52, 0.84, sraw) * smooth(0.32, 0.70, raw) * hot * arid;

    out.cover = cover; out.precip = precip; out.storm = storm * dry; out.thunder = thunder; out.dust = dust;
    out.cold = 1 - smooth(0.28, 0.40, temp);
    out.temp = temp;
    out.wind = clamp01(0.18 + 0.30 * raw + 0.55 * storm + 0.25 * precip + 0.45 * dust);
    out.mist = 0;
    return out;
}

// Blend `out` toward a preset by weight w (0..1).
export function blendToPreset(out, p, w) {
    if (w <= 0) return out;
    out.cover = lerp(out.cover, p.cover, w);
    out.precip = lerp(out.precip, p.precip, w);
    out.storm = lerp(out.storm, p.storm, w);
    out.thunder = lerp(out.thunder, p.thunder, w);
    out.dust = lerp(out.dust, p.dust, w);
    out.cold = lerp(out.cold, p.cold, w);
    out.mist = lerp(out.mist, p.mist, w);
    out.wind = lerp(out.wind, p.wind, w);
    return out;
}

// Short human description of the present conditions.
export function describeWeather(f) {
    if (f.dust > 0.45) return 'Sandstorm';
    if (f.precip > 0.08) {
        if (f.cold > 0.5) return f.precip > 0.7 ? 'Blizzard' : f.precip > 0.3 ? 'Snow' : 'Light snow';
        if (f.thunder > 0.35 && f.precip > 0.4) return 'Thunderstorm';
        return f.precip > 0.7 ? 'Heavy rain' : f.precip > 0.3 ? 'Rain' : 'Light rain';
    }
    if (f.mist > 0.55) return 'Fog';
    if (f.mist > 0.25) return 'Mist';
    if (f.cover < 0.12) return 'Clear';
    if (f.cover < 0.40) return 'Few clouds';
    if (f.cover < 0.68) return 'Broken clouds';
    return 'Overcast';
}
export const toCelsius = (t01) => -20 + t01 * 60;
