# v60 - STEP 2: REALISTIC MOUNTAIN RANGES & RELIEF (terrain_core.js only)
NOT run in a browser/GPU. Verified headless in Node: test_sites, test_chunks, test_shape (all pass), test_v59 (land stats), test_v60_rainshadow (new), and shaded relief renders (tests/crop_shade.sh = map_crop.mjs + map_shade.py; FULL=1 adds the game's regional-variety layer, TERRAIN_MOD=<path> renders another version).

## What changed
- **Boundary ridges (`_ridge`).** Mountains are now built along convergent plate boundaries from the distance to the boundary (`qj`) and the position along it (`sAl`):
  - Main crest with an asymmetric profile: a short, steep face toward the collision / trench and a long gentle back slope. The crest snakes (noise offset) instead of following the boundary exactly.
  - Three kinds: continent collision (twin crests with an axial trough, a parallel back range, tallest), Andean cordillera on a continent beside a trench, island arc (narrow crest on the arc line, lowest).
  - Strength wanders along the crest: tall MASSIFS where one noise is high, low PASSES where another is low.
  - Longitudinal valleys / intermontane basins sit behind the crest in patches, between the crest and a second, lower range.
  - SPURS: ridged noise stretched across the range makes side ridges that branch off the crest; valleys between them deepen the farther they run from the crest.
  - Zero exactly on the boundary (both sides agree, no seam).
- **Erosion look.** The 1-9 km eroded-ridge layer in `_variety` no longer fades out with height on ridges and gets ~1.9x amplitude there, so crests are cut by gullies and spurs instead of being smooth highland blobs. The ridge keeps its crest line; the fractal detail only cuts into it.
- **Old blobs removed.** The noise "inland mountain belts" (8200 -> 1400 units), the huge collision / cordillera / arc uplift terms (7400 / 5900 / 5400 -> 1500 / 1200 / 2700), the collision island bonus (3500 -> 600) and the plateau (2300 -> 1500) are cut back to broad swells; the ranges themselves are the ridges.
- **Height scaling.** Relief is soft-capped at RELIEF_CAP = 2400 (knee at 78%). By boundary type: collision up to 2350 x strength, Andean 1900, arc 1500 (before massif / pass modulation). Land is soft-capped near 4.6 km. Polar highlands 5200 -> 2600. Highest point of the test world 13.3 km -> 4.8 km; land p99 3.7-5.1 km -> 2.5-2.7 km.
- **Controlled anomalies.** A rare noise field adds a lone jagged peak or out-of-place mountain (480-1100 units, only on land, bigger where there is already a ridge). Never more than a few percent of the map.
- **Rain shadows.** The moisture march is unchanged in structure; it is now more sensitive to forced ascent (lift coefficient 5 -> 10, depletion 0.55 -> 0.70, orographic rain multiplier 2600 -> 5000, moisture term 0.5+1.7M -> 0.4+1.7M). Over ridges fed by moist ocean air the lee side (15 km past the crest) is ~25% drier than the windward side (v59b: ~0-5%). Lee drier by >20% at 37-45% of true crests (v59b: ~17%). Land-mean rainfall -4%.
- Biome thresholds that assumed old heights were rescaled (CRAGS relief 3200 -> 1900, SCREE 2200 -> 1500).

## New fields on the terrain sample (for Step 3): `ridgeU` (ridge height), `ridgeKind` (1 collision, 2 cordillera, 3 arc), `ridgeCrest`, `ridgeMass`, `anomaly`.
## Tuning knobs (top of terrain_core.js): RELIEF_CAP, RIDGE_REACH, OROG_K / OROG_DEP / OROG_MULT / RAIN_A / RAIN_B; per-kind crest offset, widths (wf front / wb back), amplitude A in `_ridge`.

## Measured (seeds 424242, 7, 99991)
- Land 32-35%, 400-475 landmasses, largest 21-32% of land (unchanged from v59b). Land height p50/p90/p99 ~600-660 / 1540-1615 / 2530-2680. Cliff share 10.7-11.6% (v59b ~11%). 0 NaN. Chunk seams still 0.0000.
- Cost: `_terrain` 13.8 -> 15.6 us per call (+13%).

## Known / left for later
- Collisions are rare (continents are dispersed on purpose), so most ranges are cordilleras along continental margins. Interiors are mostly low and flat except for old eroded ranges.
- Hidden-valley rings (v39) still show as round lakes/basins in mountain country; unchanged.
- Rock types, region character, coast shapes, landmarks and naming = Step 3. Seafloor squiggles, biome blending, cloud climate = Step 4.
