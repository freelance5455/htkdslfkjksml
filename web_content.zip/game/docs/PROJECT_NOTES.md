# PROJECT NOTES (hand-off for any AI / developer)

## Vision
- Genre: **role-playing game** (RPG), 2D sprite, HTML5 canvas. Features will be added gradually (inventory, NPCs, dialogue, quests, maps, combat... not decided yet).
- Platform: **mobile, touch only**. Final plan: wrap as APK via a website/WebView.
- Camera: **angled top-down** (like Stardew Valley), NOT fully overhead. 4 facing directions.
- User's language is Persian (Farsi); reply in Persian unless asked otherwise.

## Character
- Brown messy hair, green jacket, white striped shirt, grey pants, brown shoes.
- 3 frames provided by user: front (down), side (faces right), back (up). Left = side mirrored via negative scale.
- Source images were AI-generated at ~16px-per-pixel blocks; they were cut out (black bg -> transparent) and downscaled to native pixel grid: front 17x34, side 15x34, back 17x35. Feet are the bottom-center anchor.
- **Eyes edit (user request):** original front-frame eyes stared straight at the player. Pupils were moved to the viewer's right/lower position and made dark brown, so he looks ahead/aside. Do not revert.
- Only static frames exist, so walking is faked in code (bob + slight rotation). Real walk frames can be added later.

## Physics system (js/game.js, CFG object at top)
- Velocity-based movement: acceleration toward target speed, friction when idle, analog joystick, diagonal normalized.
- Vertical axis speed scaled by `tilt` (0.8) for angled-camera feel.
- **Jump:** separate z axis with real gravity (`gravity`, `jumpVel`). Shadow stays on the ground, sprite rises; reduced air control; squash on landing.
- **Sit:** toggle; sprite squashed (scaleY 0.72), no movement; cannot sit while airborne, cannot jump while sitting.
- Collision: AABB at feet vs. props (trees/rocks) and world bounds. Axis-separated so player slides along obstacles.
- Rendering: world drawn at integer pixel scale (auto from screen size), `imageSmoothingEnabled=false`; objects depth-sorted by feet y.
- Camera follows player with smoothing, clamped to world.

## Placeholder content (replace later)
Ground, trees and rocks are drawn procedurally with rectangles; world is 640x480 with seeded random props.

## Ideas / TODO (not yet done)
- Real walk animation frames, idle animation, sitting sprite
- Tilemap + map loader, NPCs, dialogue box, inventory, save system
- Sound, UI polish, APK wrapper (Capacitor/WebView)
