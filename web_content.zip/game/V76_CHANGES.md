# v76 - The Freefall, dressed

freefall_cinematic.js (shaders untouched; everything below is a new overlay layer plus audio, wrapped so any error in it just switches it off):
- Ship telemetry on the glass: mission clock that jumps hours at every cut (00:01 -> 72:41), stabilizers offline, canopy integrity falling with the cracks, altitude, then distance to the giant's limb, then atmospheric pressure (bar) and skin temperature in the plunge. It comes into focus with the pilot's eyes, flickers under stress and dies in each lightning strike.
- Letterbox bars, film grain, anamorphic flare on every lightning bolt, breath/condensation on the cold glass in deep space (burned off by the heat), and re-entry streaks and embers rushing out of the vanishing point in shots 6-7.
- Audio: heartbeat from shot 4 that speeds up and hardens, a ringing in the ears after the final flash.
- Ending: after the white-out, a quiet card in the black: "Your survival takes absolute priority." / PHASE VI - ATLAS OF WORLDS. End hold extended 2.0 s to 6.5 s (total about 190 s).

Verified: syntax, and a full-timeline dry run with a stubbed DOM (no errors). Not verified on a real GPU: how it looks.
Standalone viewer: NewTerra_Freefall_Cinematic.html (the same module inlined, with a Play button).
