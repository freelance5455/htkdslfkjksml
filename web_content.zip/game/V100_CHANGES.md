# v100 - cloud sheets, calmer high clouds in the wake-up, coastal spawn

- **Stretched / razor-sharp cloud sheets (cloud_shaders.js, `wxLayeredShaders`):** a flat sheet is squeezed along the view direction the lower
  you look and the farther it runs, which turned the noise into thin hard-edged streaks. Two fixes: (1) less built-in stretch (cirrus
  along-wind stretch ~2.7x -> ~1.9x, fibres 5x/6.5x -> 3.3x/4.2x, jet-stream combing halved, alto's extra 1.5x -> 1.15x); (2) a `blurK` factor
  (0 overhead and near, 1 low on the horizon or far away): the finest noise octaves fade out and the edge softness widens up to 3x, so what is
  squeezed is also blurred. The horizon fade starts a little higher (sin elevation 0.03..0.22, was 0.018..0.16).
- **Low cloud slab (`cloudDensity`):** wind-shear lean reduced (2300 -> 1300 units of noise shear, 0.22 -> 0.12 lean) - looking up through a deck
  it smeared the noise into long streaks. Far cloud edges also soften (`soft` x up to 2.2 beyond ~7 km).
- **Top cloud layer too fast in the wake-up (game.js, `wxStep`):** the alto/cirrus offsets were fixed multiples (x1.5 / x2.6) of the low-cloud
  drift, so in a jet stream the cirrus crossed the sky at up to ~150 units/s, which looks like a time-lapse when you look straight up.
  They now integrate their own offsets (`oMx/oMz`, `oHx/oHz`) at a capped pace (alto <= 30, cirrus <= 38 units/s). During the wake-up pan the
  sheets crawl (`WX.calm` 0.3) and ease back to full pace over ~10 s once it ends (no sudden change). Loading a save skips the slow-down.
- **Spawn near the ocean (game.js, `findIdealSpawn`):** the old search wanted deep inland land and took the first flat pad, so the sea was
  2,700 to 6,000+ units away on the seeds tried. Now the start region must have a coast within ~2.8 km, and the pad itself must have open
  sea (checked 300 and 800 units past the shore, so ponds do not count) between 450 and 1500 units away. All the old pad rules still apply
  (flat, gentle fall-off, 25-130 above water, dry for 350). If no such pad exists the old inland search runs as before.
  Measured over 12 seeds: nearest sea 600-1440 units (was 2760 to >6000), and the search is faster.
