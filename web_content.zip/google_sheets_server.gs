// =========================================================================
// كود السيرفر السحابي لعيادة د. إبراهيم طرشة (Google Apps Script)
// مزود بدرع حماية متطور لمنع حذف أو تصفير ملفات السيرفر الأصلية
// ودعم القراءة المباشرة من جداول Google Sheets
// =========================================================================

function doGet(e) {
  var data = null;
  var prop = PropertiesService.getScriptProperties().getProperty('CLINIC_JSON');
  if (prop) {
    try {
      data = JSON.parse(prop);
    } catch (err) {}
  }
  
  // إذا كانت خاصية السكربت فارغة أو عدد المرضى فيها 0، نقرأ مباشرة من جداول الشيت
  if (!data || !data.patients || data.patients.length === 0) {
    var fromSheets = readFromReadableSheets();
    if (fromSheets && fromSheets.patients && fromSheets.patients.length > 0) {
      data = fromSheets;
      PropertiesService.getScriptProperties().setProperty('CLINIC_JSON', JSON.stringify(data));
    }
  }

  var out = data ? JSON.stringify(data) : JSON.stringify({ status: 'empty', patients: [], appointments: [] });
  return ContentService.createTextOutput(out).setMimeType(ContentService.MimeType.JSON);
}

function doPost(e) {
  try {
    var body = JSON.parse(e.postData.contents);
    if (!body || !body.payload) {
      return ContentService.createTextOutput(JSON.stringify({ ok: false, error: 'No payload provided' }))
        .setMimeType(ContentService.MimeType.JSON);
    }

    var incoming = body.payload;
    var incomingPatientsCount = (incoming.patients || []).length;

    // جلب البيانات المخزنة حالياً في السيرفر أو الشيت
    var prop = PropertiesService.getScriptProperties().getProperty('CLINIC_JSON');
    var currentData = null;
    if (prop) {
      try { currentData = JSON.parse(prop); } catch(err) {}
    }
    if (!currentData || !currentData.patients || currentData.patients.length === 0) {
      currentData = readFromReadableSheets();
    }
    var currentPatientsCount = (currentData && currentData.patients) ? currentData.patients.length : 0;

    // درع الأمان: منع تصفير السيرفر إذا كان الجهاز المرسل فارغاً والسيرفر يحتوي على بيانات أصلية
    if (incomingPatientsCount === 0 && currentPatientsCount > 0 && !body.forceOverwrite) {
      return ContentService.createTextOutput(JSON.stringify({
        ok: false,
        protected: true,
        message: 'تم حظر الكتابة لحماية الملف الأصلي: جهازك لا يحتوي على مرضى بينما السيرفر يحتوي على (' + currentPatientsCount + ') مريض. يرجى جلب البيانات من السيرفر أولاً.',
        patientsCount: currentPatientsCount
      })).setMimeType(ContentService.MimeType.JSON);
    }

    // حفظ البيانات في السيرفر وتفريغها في جداول الشيت
    PropertiesService.getScriptProperties().setProperty('CLINIC_JSON', JSON.stringify(incoming));
    syncToReadableSheets(incoming);

    return ContentService.createTextOutput(JSON.stringify({ 
      ok: true, 
      updatedAt: new Date().toISOString(),
      patientsCount: incomingPatientsCount 
    })).setMimeType(ContentService.MimeType.JSON);

  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({ ok: false, error: err.toString() }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

// دالة تفريغ البيانات في جداول Google Sheets (المرضى - الجلسات - المواعيد)
function syncToReadableSheets(data) {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    if (!ss) return;

    // 1. ورقة المرضى
    var pSheet = ss.getSheetByName('المرضى') || ss.insertSheet('المرضى');
    if (data.patients && data.patients.length > 0) {
      pSheet.clearContents();
      pSheet.appendRow(['معرف المريض', 'الاسم الثلاثي', 'العمر', 'رقم الهاتف', 'إجمالي المراجعات', 'ملاحظات المواعيد', 'السوابق المرضية', 'السوابق النفسية']);
      data.patients.forEach(function(p) {
        var visits = (parseInt(p.baseVisits || 0, 10) || 0) + ((p.sessions || []).length);
        pSheet.appendRow([p.id || '', p.name || '', p.age || '', p.phone || '', visits, p.adminNotes || '', p.medicalHistory || '', p.psychHistory || '']);
      });
    }

    // 2. ورقة الجلسات السريرية
    var sSheet = ss.getSheetByName('الجلسات_السريرية') || ss.insertSheet('الجلسات_السريرية');
    if (data.patients && data.patients.length > 0) {
      sSheet.clearContents();
      sSheet.appendRow(['معرف الجلسة', 'اسم المريض', 'تاريخ الجلسة', 'التشخيص', 'العلاج والدواء', 'ملاحظات الجلسة', 'الأعراض الجانبية الدوائية', 'شدة الأعراض الجانبية']);
      data.patients.forEach(function(p) {
        (p.sessions || []).forEach(function(s) {
          sSheet.appendRow([s.id || '', p.name || '', s.date || '', s.diagnosis || '', s.treatment || '', s.notes || '', s.sideEffects || '', s.sideEffectSeverity || 'none']);
        });
      });
    }

    // 3. ورقة المواعيد
    var aSheet = ss.getSheetByName('المواعيد') || ss.insertSheet('المواعيد');
    if (data.appointments && data.appointments.length > 0) {
      aSheet.clearContents();
      aSheet.appendRow(['معرف الموعد', 'معرف المريض', 'التاريخ', 'الوقت', 'نوع الموعد', 'الحالة', 'ملاحظة']);
      data.appointments.forEach(function(a) {
        aSheet.appendRow([a.id || '', a.patientId || '', a.date || '', a.time || '', a.type || '', a.status || '', a.note || '']);
      });
    }
  } catch (err) {}
}

// دالة قراءة البيانات واستعادتها من جداول Google Sheets إذا فُقدت من ذاكرة السكربت
function readFromReadableSheets() {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    if (!ss) return null;
    var pSheet = ss.getSheetByName('المرضى');
    if (!pSheet) return null;

    var pRows = pSheet.getDataRange().getValues();
    if (!pRows || pRows.length <= 1) return null;

    var patients = [];
    var patientMap = {};

    for (var i = 1; i < pRows.length; i++) {
      var r = pRows[i];
      if (!r[1] && !r[0]) continue;
      var pid = String(r[0] || ('p_' + i));
      var pObj = {
        id: pid,
        name: String(r[1] || ''),
        age: parseInt(r[2], 10) || 30,
        phone: String(r[3] || ''),
        baseVisits: parseInt(r[4], 10) || 0,
        adminNotes: String(r[5] || ''),
        medicalHistory: String(r[6] || ''),
        psychHistory: String(r[7] || ''),
        sessions: []
      };
      patients.push(pObj);
      patientMap[pObj.name] = pObj;
      patientMap[pObj.id] = pObj;
    }

    var sSheet = ss.getSheetByName('الجلسات_السريرية');
    if (sSheet) {
      var sRows = sSheet.getDataRange().getValues();
      if (sRows && sRows.length > 1) {
        for (var j = 1; j < sRows.length; j++) {
          var sr = sRows[j];
          var sid = String(sr[0] || ('s_' + j));
          var pName = String(sr[1] || '');
          var sessObj = {
            id: sid,
            date: sr[2] instanceof Date ? sr[2].toISOString().split('T')[0] : String(sr[2] || ''),
            diagnosis: String(sr[3] || ''),
            treatment: String(sr[4] || ''),
            notes: String(sr[5] || ''),
            sideEffects: String(sr[6] || ''),
            sideEffectSeverity: String(sr[7] || 'none')
          };
          if (patientMap[pName]) {
            patientMap[pName].sessions.push(sessObj);
          } else if (patients.length > 0) {
            patients[0].sessions.push(sessObj);
          }
        }
      }
    }

    var appointments = [];
    var aSheet = ss.getSheetByName('المواعيد');
    if (aSheet) {
      var aRows = aSheet.getDataRange().getValues();
      if (aRows && aRows.length > 1) {
        for (var k = 1; k < aRows.length; k++) {
          var ar = aRows[k];
          if (!ar[0] && !ar[2]) continue;
          var aid = String(ar[0] || ('a_' + k));
          var appObj = {
            id: aid,
            patientId: String(ar[1] || ''),
            date: ar[2] instanceof Date ? ar[2].toISOString().split('T')[0] : String(ar[2] || ''),
            time: String(ar[3] || ''),
            type: String(ar[4] || 'مراجعة دورية'),
            status: String(ar[5] || 'مؤكد'),
            note: String(ar[6] || '')
          };
          appointments.push(appObj);
        }
      }
    }

    return {
      clinicName: 'عيادة د. إبراهيم طرشة',
      updatedAt: new Date().toISOString(),
      patients: patients,
      appointments: appointments,
      templates: []
    };
  } catch (err) {
    return null;
  }
}
