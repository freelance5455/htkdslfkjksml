# Xtream Player Android-Projekt

Das Projekt enthält den WebView-Wrapper und die bereitgestellte HTML-App.

## APK in Android Studio erzeugen
1. Öffnen Sie diesen Ordner in Android Studio.
2. Warten Sie, bis Gradle synchronisiert ist.
3. Wählen Sie **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Android Studio legt die Debug-APK unter `app/build/outputs/apk/debug/app-debug.apk` ab.

Die App benötigt eine Internetverbindung, weil die HTML-Seite Tailwind, Font Awesome und HLS.js von CDNs lädt.
