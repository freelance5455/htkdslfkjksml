"""Offline administration: import, backup, restore and account recovery."""
from __future__ import annotations

import argparse
import getpass
import re
import sqlite3
from datetime import datetime
from pathlib import Path

from werkzeug.security import generate_password_hash

from school48 import create_app
from school48.db import audit, backup_bytes, get_db, now
from school48.importing import commit_import, parse_import, preview_import
from school48.validation import ValidationError, clean_text, validate_password


def ask_password() -> str:
    password = validate_password(getpass.getpass("New password (8-128 characters): "))
    if password != getpass.getpass("Confirm password: "):
        raise ValidationError("Passwords do not match.")
    return password


def save_backup(destination: Path) -> None:
    destination = destination.resolve()
    if destination == Path(get_db().execute("PRAGMA database_list").fetchone()[2]).resolve():
        raise ValidationError("A backup cannot overwrite the live database.")
    destination.parent.mkdir(parents=True, exist_ok=True)
    content = backup_bytes()
    with destination.open("xb") as file:
        file.write(content)
    try:
        destination.chmod(0o600)
    except OSError:
        pass
    print(f"Backup saved: {destination}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    backup = sub.add_parser("backup", help="Save a consistent SQLite backup; never overwrites a file")
    backup.add_argument("file", type=Path)
    restore = sub.add_parser("restore", help="Stop the web server before restoring")
    restore.add_argument("file", type=Path)
    restore.add_argument("--yes", action="store_true", help="Confirm replacing the current database after an automatic backup")
    imp = sub.add_parser("import-json", help="Preview by default; use --commit to import")
    imp.add_argument("file", type=Path)
    imp.add_argument("--commit", action="store_true")
    for name in ("create-admin", "reset-password"):
        p = sub.add_parser(name)
        p.add_argument("username")
        if name == "create-admin":
            p.add_argument("--name", default="Маъмур")
    args = parser.parse_args()
    app = create_app()
    with app.app_context():
        conn = get_db()
        if args.command == "backup":
            save_backup(args.file)
        elif args.command == "import-json":
            raw = args.file.read_bytes()
            rows = parse_import(raw)
            result = commit_import(rows, "cli") if args.commit else preview_import(rows, raw)
            print({key: result[key] for key in ("total", "added", "skipped")})
            if not args.commit:
                print("Preview only. Add --commit to import. Existing IDs are skipped.")
        elif args.command in ("create-admin", "reset-password"):
            username = args.username.strip().lower()
            if not re.fullmatch(r"[a-z0-9_.-]{3,32}", username):
                raise ValidationError("Username must use 3-32 ASCII letters, numbers, dots, hyphens or underscores.")
            user = conn.execute("SELECT id FROM users WHERE username=?", (username,)).fetchone()
            if args.command == "reset-password" and user is None:
                raise ValidationError("User not found.")
            if args.command == "create-admin" and user is not None:
                raise ValidationError("User already exists.")
            password_hash = generate_password_hash(ask_password())
            with conn:
                if args.command == "create-admin":
                    conn.execute("INSERT INTO users(username,display_name,password_hash,created_at) VALUES (?,?,?,?)",
                                 (username, clean_text(args.name, "Name", 80) or "Маъмур", password_hash, now()))
                else:
                    conn.execute("UPDATE users SET password_hash=? WHERE id=?", (password_hash, user[0]))
                    conn.execute("DELETE FROM sessions WHERE user_id=?", (user[0],))
                audit("password" if user else "setup", f"CLI: {args.command} {username}", "cli")
            print("Account updated. Sign in through the browser.")
        elif args.command == "restore":
            source = args.file.resolve()
            current = Path(app.config["DATABASE"]).resolve()
            if source == current or not source.is_file():
                raise ValidationError("Choose an existing backup file, not the live database.")
            if not args.yes:
                raise ValidationError("Stop the server, then run: python manage.py restore BACKUP.sqlite3 --yes")
            read_conn = sqlite3.connect(source.as_uri() + "?mode=ro", uri=True)
            try:
                if read_conn.execute("PRAGMA quick_check").fetchone()[0] != "ok":
                    raise ValidationError("Backup integrity check failed.")
                if read_conn.execute("PRAGMA user_version").fetchone()[0] != 1:
                    raise ValidationError("Unsupported database schema version.")
                required = {"students", "users", "settings", "sessions", "login_attempts", "audit_log"}
                tables = {r[0] for r in read_conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
                if not required.issubset(tables):
                    raise ValidationError("This is not a School48 database backup.")
                before = Path(app.instance_path) / "backups" / f"before_restore_{datetime.now():%Y%m%d_%H%M%S_%f}.sqlite3"
                save_backup(before)
                read_conn.backup(conn)
            finally:
                read_conn.close()
            with conn:
                conn.execute("DELETE FROM sessions")
                conn.execute("DELETE FROM login_attempts")
                audit("restore", "Пойгоҳи маълумот аз нусха барқарор шуд", "cli")
            print("Restored successfully. Previous sessions were revoked. Start the web server again.")


if __name__ == "__main__":
    try:
        main()
    except (ValidationError, OSError, sqlite3.Error) as error:
        raise SystemExit(str(error)) from None
