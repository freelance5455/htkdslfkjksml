"""Start the web application with a production WSGI server."""
import argparse
import os

from school48 import create_app

app = create_app()


if __name__ == "__main__":
    from waitress import serve

    parser = argparse.ArgumentParser(description="School 48 Flask + SQLite")
    parser.add_argument("--host", default=os.environ.get("HOST", "127.0.0.1"))
    parser.add_argument("--port", type=int, default=int(os.environ.get("PORT", "5000")))
    args = parser.parse_args()
    if not 1 <= args.port <= 65535:
        parser.error("Port must be between 1 and 65535")
    print("\nSchool 48 | Flask + SQLite", flush=True)
    print(f"Open: http://{'127.0.0.1' if args.host == '0.0.0.0' else args.host}:{args.port}", flush=True)
    print("First launch: create your administrator account in the browser.", flush=True)
    print("Stop: Ctrl+C\n", flush=True)
    serve(app, host=args.host, port=args.port, threads=6, expose_tracebacks=False,
          max_request_body_size=6 * 1024 * 1024, clear_untrusted_proxy_headers=True)
