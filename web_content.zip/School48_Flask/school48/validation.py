"""One validation path shared by the API and legacy JSON migration."""
from __future__ import annotations

import re
import unicodedata

FIELDS = (
    "name", "class_number", "section", "gender", "nation", "address", "phone",
    "father_name", "father_job", "mother_name", "mother_job", "student_phone",
)
LABELS = {
    "name": "Ному насаб", "class_number": "Синф", "section": "Ҳарфи синф",
    "gender": "Ҷинс", "nation": "Миллат", "address": "Ҷои истиқомат",
    "phone": "Телефони волидайн", "father_name": "Ному насаби падар",
    "father_job": "Вазифаи падар", "mother_name": "Ному насаби модар",
    "mother_job": "Вазифаи модар", "student_phone": "Телефони хонанда",
}
LIMITS = {field: 150 for field in FIELDS}
LIMITS.update(section=3, gender=10, nation=60, address=300, phone=32, student_phone=32)


class ValidationError(ValueError):
    def __init__(self, message: str, fields: dict | None = None, status: int = 422):
        super().__init__(message)
        self.fields = fields or {}
        self.status = status


def clean_text(value, label: str, maximum: int = 150) -> str:
    if not isinstance(value, str):
        raise ValueError(f"{label}: матн ворид кунед.")
    value = unicodedata.normalize("NFC", value)
    if any(unicodedata.category(char).startswith("C") for char in value):
        raise ValueError(f"{label}: аломатҳои идоракунӣ иҷозат дода намешаванд.")
    value = " ".join(value.split())
    if len(value) > maximum:
        raise ValueError(f"{label}: ҳадди аксар {maximum} аломат.")
    return value


def validate_student(payload: dict) -> dict:
    if not isinstance(payload, dict):
        raise ValidationError("Маълумоти хонанда бояд объект бошад.")
    result, errors = {}, {}
    for field in FIELDS:
        if field == "class_number":
            raw = payload.get(field)
            if isinstance(raw, bool) or not re.fullmatch(r"(?:[1-9]|10|11)", str(raw)):
                errors[field] = "Синф бояд адади бутуни аз 1 то 11 бошад."
            else:
                result[field] = int(raw)
            continue
        try:
            result[field] = clean_text(payload.get(field, ""), LABELS[field], LIMITS[field])
        except ValueError as exc:
            errors[field] = str(exc)
    if "name" in result and len(result["name"]) < 2:
        errors["name"] = "Ному насабро ворид кунед (камаш 2 аломат)."
    if result.get("section") and not re.fullmatch(r"[A-Za-zА-Яа-яЁёҒғӢӣҚқӮӯҲҳҶҷ]{1,3}", result["section"]):
        errors["section"] = "Аз 1 то 3 ҳарф ворид кунед."
    result["section"] = result.get("section", "").upper()
    if result.get("gender") not in ("", "Мард", "Зан"):
        errors["gender"] = "Ҷинсро аз рӯйхат интихоб кунед."
    for field in ("phone", "student_phone"):
        value = result.get(field, "")
        if value and (not re.fullmatch(r"\+?[0-9() -]+", value) or not 7 <= len(re.sub(r"\D", "", value)) <= 15):
            errors[field] = "Рақами дурусти телефонро ворид кунед (7–15 рақам)."
    if errors:
        raise ValidationError("Лутфан майдонҳои ишорашударо ислоҳ кунед.", errors)
    return result


def validate_password(password) -> str:
    if not isinstance(password, str) or not 8 <= len(password) <= 128:
        raise ValidationError("Рамз бояд аз 8 то 128 аломат дошта бошад.", {"password": "Камаш 8 аломат."})
    if password.isspace():
        raise ValidationError("Рамз танҳо аз фосила иборат шуда наметавонад.")
    return password


def version_from(payload: dict) -> int:
    version = payload.get("version")
    if type(version) is not int or version < 1:
        raise ValidationError("Версияи сабт гум шудааст. Рӯйхатро нав кунед.", status=400)
    return version
