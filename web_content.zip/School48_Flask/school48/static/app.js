"use strict";
(() => {
  const $ = id => document.getElementById(id);
  const text = value => String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  const icon = name => `<svg class="icon" aria-hidden="true"><use href="/static/icons.svg#${name}"></use></svg>`;
  const labels = {name:"Ному насаб",class_number:"Синф",section:"Ҳарфи синф",gender:"Ҷинс",nation:"Миллат",address:"Ҷои истиқомат",phone:"Телефони волидайн",father_name:"Ному насаби падар",father_job:"Вазифаи падар",mother_name:"Ному насаби модар",mother_job:"Вазифаи модар",student_phone:"Телефони хонанда"};
  const state = {page:1, pages:1, total:0, section:null, rows:[], summary:null, editing:null, detail:null, deleting:null, clearAll:false, listController:null, listRequest:0, summaryRequest:0, importFile:null, importFingerprint:null, importRequest:0, trashPage:1, trashPages:1, trashRows:[]};
  let csrf = document.querySelector('meta[name="csrf-token"]').content;
  let searchTimer;

  class ApiError extends Error {
    constructor(message, status=0, fields={}) { super(message); this.status=status; this.fields=fields; }
  }

  function connection(connected) {
    const node = $("connectionStatus");
    node.classList.toggle("offline", !connected);
    node.querySelector("span:last-child").textContent = connected ? "Сервер пайваст" : "Пайваст нест";
  }

  async function api(path, options={}) {
    const method = options.method || "GET";
    const headers = {"Accept":"application/json", ...options.headers};
    if (method !== "GET") headers["X-CSRF-Token"] = csrf;
    if (options.body && !(options.body instanceof FormData)) headers["Content-Type"] = "application/json";
    let response;
    const timeout = new AbortController();
    const timeoutId = setTimeout(() => timeout.abort(), 30000);
    const signal = options.signal ? AbortSignal.any([options.signal, timeout.signal]) : timeout.signal;
    try {
      response = await fetch(path, {...options, method, headers, credentials:"same-origin", signal});
      connection(true);
      let data;
      try { data = await response.json(); }
      catch { throw new ApiError("Ҷавоби сервер хонда нашуд. Амалро такрор кунед.", response.status); }
      if (response.status === 401) {
        window.location.assign("/login");
        throw new ApiError("Нишасти шумо анҷом ёфт. Аз нав ворид шавед.", 401);
      }
      if (!response.ok || data.ok === false) throw new ApiError(data.error || "Амал иҷро нашуд.", response.status, data.fields || {});
      return data;
    } catch (error) {
      if (error instanceof ApiError || options.signal?.aborted) throw error;
      connection(false);
      throw new ApiError("Ба сервер пайваст нашуд. Пайвастро санҷида, амалро такрор кунед.");
    } finally { clearTimeout(timeoutId); }
  }

  function toast(message, error=false) {
    const node = document.createElement("div");
    node.className = "toast" + (error ? " error" : "");
    node.innerHTML = icon(error ? "alert" : "check-circle") + `<span>${text(message)}</span><button aria-label="Пӯшидан">${icon("x")}</button>`;
    node.querySelector("button").addEventListener("click", () => node.remove());
    $("toastContainer").append(node);
    setTimeout(() => node.remove(), error ? 9000 : 5000);
    while ($("toastContainer").children.length > 4) $("toastContainer").firstChild.remove();
  }

  function formError(id, message) {
    $(id).textContent = message || "";
    $(id).hidden = !message;
  }

  function setBusy(form, busy) {
    const dialog = form.closest("dialog");
    if (dialog) dialog.dataset.busy = busy ? "true" : "false";
    form.setAttribute("aria-busy", String(busy));
    form.querySelectorAll("button, input, select").forEach(input => { input.disabled = busy; });
  }

  function openDialog(id) {
    const dialog = $(id);
    if (!dialog.open) dialog.showModal();
  }

  document.querySelectorAll("[data-close]").forEach(button => button.addEventListener("click", () => {
    const dialog = $(button.dataset.close);
    if (dialog.dataset.busy !== "true") dialog.close();
  }));
  document.querySelectorAll("dialog").forEach(dialog => {
    dialog.addEventListener("close", () => {
      if (document.activeElement?.classList.contains("skip-link")) $("main").focus({preventScroll:true});
    });
    dialog.addEventListener("cancel", event => { if (dialog.dataset.busy === "true") event.preventDefault(); });
    dialog.addEventListener("click", event => {
      if (event.target !== dialog || dialog.dataset.busy === "true") return;
      const box = dialog.getBoundingClientRect();
      if (event.clientX < box.left || event.clientX > box.right || event.clientY < box.top || event.clientY > box.bottom) dialog.close();
    });
  });

  function query() {
    const params = new URLSearchParams();
    [["q","searchInput"],["class_number","classFilter"],["nation","nationFilter"],["gender","genderFilter"],["sort","sortSelect"]].forEach(([key,id]) => {
      const value = $(id).value.trim();
      if (value) params.set(key,value);
    });
    if (state.section !== null) params.set("section",state.section);
    return params;
  }

  function updateExportLinks() {
    document.querySelectorAll("[data-export]").forEach(link => { link.href = `/api/export/${link.dataset.export}?${query()}`; });
  }

  function initials(name) { return name.trim().split(/\s+/).slice(0,2).map(n => n[0] || "").join("").toUpperCase(); }
  function classLabel(student) { return `${student.class_number}${student.section || ""}`; }
  function genderLabel(value) { return value === "Мард" ? "Писар" : value === "Зан" ? "Духтар" : "—"; }
  function date(value, withTime=false) {
    if (!value) return "—";
    const d = new Date(value);
    if (Number.isNaN(d.getTime())) return "—";
    const parts=localParts(d);
    return `${parts.day}.${parts.month}.${parts.year}${withTime ? ` ${parts.hour}:${parts.minute}` : ""}`;
  }
  function localParts(value) {
    return Object.fromEntries(new Intl.DateTimeFormat("en-GB", {timeZone:"Asia/Dushanbe",day:"2-digit",month:"2-digit",year:"numeric",hour:"2-digit",minute:"2-digit",hourCycle:"h23"}).formatToParts(value).filter(p=>p.type!=="literal").map(p=>[p.type,p.value]));
  }

  function renderRoster(data) {
    state.rows = data.students; state.page=data.page; state.pages=data.pages; state.total=data.total;
    $("listBadge").textContent = data.total;
    $("resultLabel").textContent = `${data.total} хонанда ёфт шуд`;
    $("sectionChip").hidden = state.section === null;
    $("sectionChip").textContent = state.section !== null ? `Синфи ${$("classFilter").value}${state.section}` : "";
    $("studentsList").innerHTML = data.students.map((s,index) => `<tr data-id="${text(s.id)}"><td class="row-number">${(data.page-1)*data.page_size+index+1}</td><td><div class="student-cell"><span class="student-avatar tone${index%4}" aria-hidden="true">${text(initials(s.name))}</span><div><button class="student-name" data-row-action="view">${text(s.name)}</button><span class="student-secondary" title="${text(s.address)}">${text(s.address || "Суроға ворид нашудааст")}</span></div></div></td><td><span class="class-tag">${text(classLabel(s))}</span></td><td><span class="gender-label">${text(genderLabel(s.gender))}</span><span class="nation-label">${text(s.nation || "—")}</span></td><td><span class="phone-text">${text(s.phone || "—")}</span></td><td><span class="parent-name" title="${text(s.father_name)}">${text(s.father_name || "—")}</span><span class="parent-name" title="${text(s.mother_name)}">${text(s.mother_name || "—")}</span></td><td><div class="row-actions"><button class="icon-btn" data-row-action="edit" title="Таҳрир" aria-label="Таҳрири ${text(s.name)}">${icon("edit")}</button><button class="icon-btn delete-action" data-row-action="delete" title="Ба сабад" aria-label="Ҳазфи ${text(s.name)}">${icon("trash")}</button></div></td></tr>`).join("");
    const hasFilters = Boolean($("searchInput").value.trim() || $("classFilter").value || $("nationFilter").value || $("genderFilter").value || state.section);
    $("emptyState").hidden = data.total !== 0;
    $("tableScroll").hidden = data.total === 0;
    $("emptyTitle").textContent = hasFilters ? "Бо ин шартҳо хонанда ёфт нашуд" : "Ҳоло хонандае илова нашудааст";
    $("emptyDescription").textContent = hasFilters ? "Матни ҷустуҷӯро дигар кунед ё филтрҳоро тоза намоед." : "Аввалин хонандаро сабт кунед, то рӯйхати мактабро оғоз намоед.";
    $("emptyButton").dataset.action = hasFilters ? "reset" : "add";
    $("emptyButton").innerHTML = icon(hasFilters ? "filter-x" : "plus") + (hasFilters ? " Тоза кардани филтрҳо" : " Иловаи хонанда");
    const start = data.total ? (data.page-1)*data.page_size+1 : 0;
    const end = Math.min(data.total, data.page*data.page_size);
    $("pageLabel").textContent = `${start}–${end} аз ${data.total} хонанда`;
    $("prevPage").disabled = data.page<=1;
    $("nextPage").disabled = data.page>=data.pages;
    const pages = [...new Set([1,data.page-1,data.page,data.page+1,data.pages])].filter(p => p>=1 && p<=data.pages).sort((a,b) => a-b);
    $("pageNumbers").innerHTML = pages.map((p,index) => (index && p-pages[index-1]>1 ? '<span class="page-ellipsis">…</span>' : "") + `<button class="page-button${p===data.page?' active':''}" data-page="${p}" aria-label="Саҳифаи ${p}" ${p===data.page?'aria-current="page"':''}>${p}</button>`).join("");
    updateExportLinks();
  }

  async function loadRoster() {
    state.listController?.abort();
    const controller = new AbortController(); state.listController=controller;
    const sequence = ++state.listRequest;
    const params = query(); params.set("page",state.page); params.set("page_size",$("pageSize").value);
    $("tableLoading").hidden = false;
    $("tableScroll").setAttribute("aria-busy","true");
    $("tableError").hidden = true;
    try {
      const data = await api(`/api/students?${params}`, {signal:controller.signal});
      if (sequence === state.listRequest) renderRoster(data);
    } catch (error) {
      if (controller.signal.aborted || sequence !== state.listRequest) return;
      $("tableErrorText").textContent = error.message + (state.rows.length ? " Рӯйхати пешина нишон дода шудааст." : "");
      $("tableError").hidden = false;
      $("resultLabel").textContent = "Маълумот нав нашуд";
    } finally {
      if (sequence === state.listRequest) {
        $("tableLoading").hidden = true;
        $("tableScroll").setAttribute("aria-busy","false");
      }
    }
  }

  function renderSummary(data) {
    state.summary=data;
    const c=data.counts;
    [["statTotal",c.total],["navCount",c.total],["statBoys",c.boys],["statGirls",c.girls],["statClasses",c.classes],["trashCount",data.trash]].forEach(([id,value]) => { $(id).textContent=value; });
    $("boysPercent").textContent=`${c.total ? Math.round(c.boys/c.total*100) : 0}% аз ҳамаи хонандагон`;
    $("girlsPercent").textContent=`${c.total ? Math.round(c.girls/c.total*100) : 0}% аз ҳамаи хонандагон`;
    const chosenNation = $("nationFilter").value;
    const nations = [...new Set(["Тоҷик","Узбек","Рус",...data.nations,...(chosenNation?[chosenNation]:[])])];
    $("nationFilter").innerHTML='<option value="">Ҳамаи миллатҳо</option>'+nations.map(n => `<option value="${text(n)}">${text(n)}</option>`).join("");
    $("nationFilter").value=chosenNation;
    $("classCards").innerHTML=data.classes.length ? data.classes.map(group => `<button class="class-card" data-class="${group.class_number}" data-section="${text(group.section)}"><span class="class-card-top"><span>${text(classLabel(group))}</span>${icon("arrow-up-right")}</span><h3>Синфи ${text(classLabel(group))}</h3><p>${group.total} хонанда дар рӯйхат</p><span class="class-card-bottom"><span><strong>${group.boys}</strong> Писар</span><span><strong>${group.girls}</strong> Духтар</span></span></button>`).join("") : '<div class="empty-card">Баъди иловаи хонандагон синфҳо дар ин ҷо пайдо мешаванд.</div>';
    const grades = Array.from({length:11},(_,i) => ({class_number:i+1,total:data.classes.filter(g => g.class_number===i+1).reduce((sum,g) => sum+g.total,0)}));
    const max = Math.max(1,...grades.map(g => g.total));
    $("classChart").innerHTML=grades.map(g => `<div class="chart-row"><span>Синфи ${g.class_number}</span><meter min="0" max="${max}" value="${g.total}" aria-label="Синфи ${g.class_number}: ${g.total} хонанда"></meter><strong>${g.total}</strong></div>`).join("");
    const actions={create:["plus","Хонанда илова шуд"],update:["edit","Маълумот таҳрир шуд"],delete:["trash","Ба сабад гузаронда шуд"],restore:["restore","Хонанда барқарор шуд"],clear:["trash","Тозакунии рӯйхат"],import:["upload","Воридоти маълумот"],login:["shield","Воридшавӣ"],setup:["shield","Сохтани ҳисоб"],settings:["settings","Танзимоти муассиса"],password:["lock","Иваз кардани рамз"]};
    $("recentActivity").innerHTML=data.recent.map(item => {
      const [name,label] = actions[item.action] || ["clock","Амал дар система"];
      return `<div class="activity-item"><span class="activity-icon">${icon(name)}</span><div><strong>${text(label)}</strong><p>${text(item.detail)}</p><small>${text(item.actor)} · ${text(date(item.created_at,true))}</small></div></div>`;
    }).join("") || '<p class="muted">Ҳанӯз амале сабт нашудааст.</p>';
  }

  async function loadSummary(silent=false) {
    const sequence = ++state.summaryRequest;
    try {
      const data=await api("/api/summary");
      if (sequence===state.summaryRequest) renderSummary(data);
    } catch (error) { if (!silent) toast(error.message,true); }
  }

  async function refresh() { await Promise.allSettled([loadRoster(),loadSummary()]); }
  function applyFilters() { clearTimeout(searchTimer); state.page=1; updateExportLinks(); loadRoster(); }
  function resetFilters() {
    $("filterForm").reset(); $("sortSelect").value="class-name"; state.section=null; applyFilters();
  }
  $("filterForm").addEventListener("submit",event => {event.preventDefault();applyFilters();});
  $("searchInput").addEventListener("input",() => {clearTimeout(searchTimer); searchTimer=setTimeout(applyFilters,300);});
  ["classFilter","nationFilter","genderFilter","sortSelect"].forEach(id => $(id).addEventListener("change",() => {if(id==="classFilter") state.section=null;applyFilters();}));
  $("pageSize").addEventListener("change",applyFilters);
  $("resetFilters").addEventListener("click",resetFilters);
  ["refreshButton","retryButton"].forEach(id => $(id).addEventListener("click",refresh));
  $("prevPage").addEventListener("click",() => {if(state.page>1){state.page--;loadRoster();}});
  $("nextPage").addEventListener("click",() => {if(state.page<state.pages){state.page++;loadRoster();}});
  $("pageNumbers").addEventListener("click",event => {const b=event.target.closest("[data-page]");if(b){state.page=Number(b.dataset.page);loadRoster();}});
  $("exportButton").addEventListener("click",() => {updateExportLinks();const open=$("exportMenu").hidden;$("exportMenu").hidden=!open;$("exportButton").setAttribute("aria-expanded",String(open));});
  document.addEventListener("click",event => {if(!event.target.closest(".dropdown")) {$("exportMenu").hidden=true;$("exportButton").setAttribute("aria-expanded","false");}});
  document.addEventListener("keydown",event => {if(event.key==="Escape"){$("exportMenu").hidden=true;$("exportButton").setAttribute("aria-expanded","false");closeSidebar();}});
  document.querySelectorAll("[data-export]").forEach(link => link.addEventListener("click",() => {$("exportMenu").hidden=true;$("exportButton").setAttribute("aria-expanded","false");}));

  function view(name, updateHash=true) {
    const names={students:"Хонандагон",overview:"Шарҳи умумӣ",classes:"Синфҳо",data:"Маълумот ва ҳисобот"};
    if (!Object.hasOwn(names,name)) name="students";
    document.querySelectorAll(".view-panel").forEach(panel => {panel.hidden=panel.id!==`view-${name}`;});
    document.querySelectorAll(".navigation .nav-link").forEach(button => {
      const active=button.dataset.view===name;button.classList.toggle("active",active);
      if(active)button.setAttribute("aria-current","page");else button.removeAttribute("aria-current");
    });
    $("breadcrumbTitle").textContent=names[name];
    document.title=`${names[name]} · Мактаби 48`;
    closeSidebar();
    if(updateHash && location.hash!==`#${name}`) history.pushState(null,"",`#${name}`);
  }
  document.querySelectorAll("[data-view]").forEach(button => button.addEventListener("click",() => view(button.dataset.view)));
  window.addEventListener("popstate",() => view(location.hash.slice(1),false));
  $("classCards").addEventListener("click",event => {
    const button=event.target.closest("[data-class]");if(!button)return;
    $("filterForm").reset();$("classFilter").value=button.dataset.class;state.section=button.dataset.section;
    view("students");applyFilters();$("studentsHeading").scrollIntoView({block:"start"});
  });
  function closeSidebar() {$("sidebar").classList.remove("open");$("sidebarOverlay").hidden=true;$("menuButton").setAttribute("aria-expanded","false");}
  $("menuButton").addEventListener("click",() => {const open=!$("sidebar").classList.contains("open");$("sidebar").classList.toggle("open",open);$("sidebarOverlay").hidden=!open;$("menuButton").setAttribute("aria-expanded",String(open));});
  $("sidebarOverlay").addEventListener("click",closeSidebar);

  function showEditor(student=null) {
    state.editing=student;
    $("studentForm").reset();formError("studentFormError","");
    document.querySelectorAll(".field-error").forEach(node => {node.textContent="";});
    Object.keys(labels).forEach(key => {
      const input=$("field-"+key); input.removeAttribute("aria-invalid");input.setAttribute("aria-describedby","error-"+key);
      if(student)input.value=student[key]??"";
    });
    if(!student && $("classFilter").value) {$("field-class_number").value=$("classFilter").value;$("field-section").value=state.section||"";}
    $("studentDialogTitle").textContent=student ? "Таҳрири маълумоти хонанда" : "Иловаи хонанда";
    openDialog("studentDialog");$("field-name").focus();
  }
  document.addEventListener("click",event => {
    const button=event.target.closest("[data-action]");if(!button)return;
    if(button.dataset.action==="add")showEditor();
    if(button.dataset.action==="reset")resetFilters();
    if(button.dataset.action==="settings"){formError("settingsError","");formError("passwordError","");$("passwordForm").reset();openDialog("settingsDialog");closeSidebar();}
  });

  $("studentForm").addEventListener("submit",async event => {
    event.preventDefault();
    const form=event.currentTarget;
    if(form.getAttribute("aria-busy")==="true")return;
    const payload=Object.fromEntries(new FormData(form));
    if(state.editing)payload.version=state.editing.version;
    Object.keys(labels).forEach(key => {$("error-"+key).textContent="";$("field-"+key).removeAttribute("aria-invalid");});
    formError("studentFormError","");
    setBusy(form,true);
    try {
      await api(state.editing?`/api/students/${encodeURIComponent(state.editing.id)}`:"/api/students",{method:state.editing?"PUT":"POST",body:JSON.stringify(payload)});
      $("studentDialog").close();toast(state.editing?"Маълумоти хонанда нав шуд.":"Хонанда бомуваффақият илова шуд.");
      await refresh();
    } catch(error) {
      formError("studentFormError",error.message);
      Object.entries(error.fields||{}).forEach(([key,message]) => {if($("error-"+key)){$("error-"+key).textContent=message;$("field-"+key).setAttribute("aria-invalid","true");}});
    } finally {
      setBusy(form,false);
      if($("studentDialog").open){const invalid=form.querySelector('[aria-invalid="true"]');if(invalid)invalid.focus();else $("studentFormError").scrollIntoView({block:"nearest"});}
    }
  });
  Object.keys(labels).forEach(key => {
    $("field-"+key).addEventListener("input",() => {
      $("error-"+key).textContent="";
      $("field-"+key).removeAttribute("aria-invalid");
    });
  });

  async function openDetail(student) {
    const data=await api(`/api/students/${encodeURIComponent(student.id)}`);const s=data.student;state.detail=s;
    $("detailTitle").textContent=s.name;
    const fields=["address","phone","student_phone","nation","gender","father_name","father_job","mother_name","mother_job"];
    $("detailBody").innerHTML=`<div class="detail-intro"><span class="student-avatar">${text(initials(s.name))}</span><p><span class="class-tag">${text(classLabel(s))}</span>Соли таҳсили ${text($("academicYear").textContent)}</p></div><dl class="detail-grid">${fields.map(key => `${key==="father_name"?'<h3>Маълумоти волидайн</h3>':''}<div class="${key==='address'?'wide':''}"><dt>${text(labels[key])}</dt><dd>${text(key==='gender'?genderLabel(s[key]):s[key]||'—')}</dd></div>`).join("")}</dl>`;
    $("detailUpdated").textContent=`Навсозӣ: ${date(s.updated_at,true)}`;
    openDialog("detailDialog");
  }
  $("detailEdit").addEventListener("click",() => {$("detailDialog").close();showEditor(state.detail);});
  $("studentsList").addEventListener("click",async event => {
    const button=event.target.closest("[data-row-action]");if(!button)return;
    const student=state.rows.find(s => s.id===button.closest("tr").dataset.id);if(!student)return;
    button.disabled=true;
    try {
      if(button.dataset.rowAction==="view")await openDetail(student);
      if(button.dataset.rowAction==="edit"){const data=await api(`/api/students/${encodeURIComponent(student.id)}`);showEditor(data.student);}
      if(button.dataset.rowAction==="delete")confirmDelete(student);
    } catch(error) {toast(error.message,true);}finally{button.disabled=false;}
  });

  function confirmDelete(student=null) {
    state.deleting=student;state.clearAll=student===null;
    $("confirmForm").reset();formError("confirmError","");
    $("clearAllFields").hidden=!state.clearAll;
    $("confirmTitle").textContent=state.clearAll?"Ҳамаи хонандагонро ба сабад гузаронем?":"Хонандаро ба сабад гузаронем?";
    $("confirmDescription").textContent=state.clearAll?`Ҳамаи ${state.summary?.counts.total||0} хонанда аз рӯйхати фаъол ба сабад мегузаранд. Онҳоро баъд барқарор кардан мумкин аст.`:`${student.name} аз рӯйхати фаъол хориҷ мешавад. Маълумоти ӯ дар сабад нигоҳ дошта мешавад.`;
    openDialog("confirmDialog");
  }
  $("clearAllButton").addEventListener("click",() => {
    if(!state.summary?.counts.total){toast("Рӯйхат аллакай холӣ аст.");return;}
    confirmDelete();
  });
  $("confirmForm").addEventListener("submit",async event => {
    event.preventDefault();const form=event.currentTarget;if(form.getAttribute("aria-busy")==="true")return;
    const payload=state.clearAll?{confirmation:$("clearConfirmation").value.trim(),password:$("clearPassword").value,expected_count:state.summary?.counts.total}: {version:state.deleting.version};
    setBusy(form,true);formError("confirmError","");
    try {
      await api(state.clearAll?"/api/students/clear":`/api/students/${encodeURIComponent(state.deleting.id)}`,{method:state.clearAll?"POST":"DELETE",body:JSON.stringify(payload)});
      $("confirmDialog").close();toast("Маълумот ба сабад гузаронда шуд.");await refresh();
    } catch(error){formError("confirmError",error.message);}finally{setBusy(form,false);}
  });

  $("settingsForm").addEventListener("submit",async event => {
    event.preventDefault();const form=event.currentTarget;const payload=Object.fromEntries(new FormData(form));setBusy(form,true);formError("settingsError","");
    try {
      const data=await api("/api/settings",{method:"PUT",body:JSON.stringify(payload)});
      $("academicYear").textContent=data.settings.academic_year;$("sidebarDistrict").textContent=data.settings.district;
      toast("Танзимоти муассиса сабт шуд.");await loadSummary(true);
    } catch(error){formError("settingsError",error.message);}finally{setBusy(form,false);}
  });
  $("passwordForm").addEventListener("submit",async event => {
    event.preventDefault();const form=event.currentTarget;const payload=Object.fromEntries(new FormData(form));setBusy(form,true);formError("passwordError","");
    try {
      const data=await api("/api/password",{method:"PUT",body:JSON.stringify(payload)});
      csrf=data.csrf_token;document.querySelector('meta[name="csrf-token"]').content=csrf;
      document.querySelectorAll('input[name="csrf_token"]').forEach(input => {input.value=csrf;});
      form.reset();toast("Рамзи нав сабт шуд.");await loadSummary(true);
    } catch(error){formError("passwordError",error.message);}finally{setBusy(form,false);}
  });

  $("importFile").addEventListener("change",async event => {
    const file=event.target.files[0];const requestId=++state.importRequest;
    state.importFile=null;state.importFingerprint=null;$("importCommit").hidden=true;
    $("importFileName").textContent=file?file.name:"Интихоби файли JSON";
    $("importPreview").hidden=!file;$("importPreview").classList.remove("error");
    if(!file)return;
    if(file.size>5*1024*1024){$("importPreview").textContent="Ҳаҷми файл аз 5 МБ зиёд аст.";$("importPreview").classList.add("error");return;}
    $("importPreview").textContent="Санҷиши маълумот…";
    const body=new FormData();body.append("file",file);
    try {
      const data=await api("/api/import/preview",{method:"POST",body});if(requestId!==state.importRequest)return;
      state.importFile=file;state.importFingerprint=data.fingerprint;
      $("importPreview").innerHTML=`<p>Дар файл: <strong>${data.total}</strong> · Нав: <strong>${data.added}</strong> · ID-и мавҷуда: <strong>${data.skipped}</strong></p><ul>${data.sample.map(s=>`<li>${text(s.name)} — синфи ${text(classLabel(s))}</li>`).join("")}</ul>`;
      $("importCommit").hidden=data.added===0;
    } catch(error){if(requestId===state.importRequest){$("importPreview").textContent=error.message;$("importPreview").classList.add("error");}}
  });
  $("importCommit").addEventListener("click",async () => {
    if(!state.importFile||!state.importFingerprint)return;
    const body=new FormData();body.append("file",state.importFile);body.append("fingerprint",state.importFingerprint);
    $("importCommit").disabled=true;$("importFile").disabled=true;
    try {
      const data=await api("/api/import/commit",{method:"POST",body});
      toast(`Ворид шуд: ${data.added}. ID-и мавҷуда: ${data.skipped}.`);
      $("importPreview").textContent=`Бомуваффақият анҷом ёфт. Илова шуд: ${data.added}; такрорӣ: ${data.skipped}.`;
      $("importCommit").hidden=true;state.importFile=null;state.importFingerprint=null;$("importFile").value="";
      await refresh();
    } catch(error){toast(error.message,true);}finally{$("importCommit").disabled=false;$("importFile").disabled=false;}
  });

  async function loadTrash() {
    $("trashList").innerHTML='<p class="muted">Боркунии сабад…</p>';
    try {
      const data=await api(`/api/trash?page=${state.trashPage}`);state.trashPage=data.page;state.trashPages=data.pages;state.trashRows=data.students;
      $("trashList").innerHTML=data.students.length?data.students.map(s => `<div class="trash-row" data-id="${text(s.id)}"><div><strong>${text(s.name)}</strong><p>Синфи ${text(classLabel(s))} · Ҳазф: ${text(date(s.deleted_at))}</p></div><button class="btn secondary" data-restore>${icon("restore")} Барқарор кардан</button></div>`).join(""):'<div class="empty-card">Сабад холӣ аст.</div>';
      $("trashPageLabel").textContent=`${data.page} / ${data.pages} · ${data.total} сабт`;
      $("trashPrev").disabled=data.page<=1;$("trashNext").disabled=data.page>=data.pages;
    } catch(error){$("trashList").textContent=error.message;toast(error.message,true);}
  }
  $("openTrash").addEventListener("click",() => {state.trashPage=1;openDialog("trashDialog");loadTrash();});
  $("trashPrev").addEventListener("click",() => {if(state.trashPage>1){state.trashPage--;loadTrash();}});
  $("trashNext").addEventListener("click",() => {if(state.trashPage<state.trashPages){state.trashPage++;loadTrash();}});
  $("trashList").addEventListener("click",async event => {
    const button=event.target.closest("[data-restore]");if(!button)return;
    const s=state.trashRows.find(row => row.id===button.closest("[data-id]").dataset.id);if(!s)return;
    button.disabled=true;
    try {
      await api(`/api/trash/${encodeURIComponent(s.id)}/restore`,{method:"POST",body:JSON.stringify({version:s.version})});
      toast("Хонанда барқарор карда шуд.");await Promise.allSettled([loadTrash(),refresh()]);
    } catch(error){toast(error.message,true);button.disabled=false;}
  });

  const today=localParts(new Date());
  const months=["январ","феврал","март","апрел","май","июн","июл","август","сентябр","октябр","ноябр","декабр"];
  $("todayDate").textContent=`${Number(today.day)} ${months[Number(today.month)-1]} ${today.year}`;
  $("currentYear").textContent=new Intl.DateTimeFormat("en",{timeZone:"Asia/Dushanbe",year:"numeric"}).format(new Date());
  window.addEventListener("online",()=>loadSummary(true));
  window.addEventListener("offline",()=>connection(false));
  setInterval(()=>{if(document.visibilityState==="visible")loadSummary(true);},60000);
  view(location.hash.slice(1)||"students",false);
  refresh();
})();
