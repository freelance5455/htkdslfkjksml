"use strict";
document.querySelectorAll(".password-toggle").forEach(button => {
  button.addEventListener("click", () => {
    const input = button.parentElement.querySelector("input");
    const showing = input.type === "password";
    input.type = showing ? "text" : "password";
    button.setAttribute("aria-pressed", String(showing));
    button.setAttribute("aria-label", showing ? "Пинҳон кардани рамз" : "Нишон додани рамз");
  });
});
document.getElementById("authForm")?.addEventListener("submit", event => {
  const button = event.currentTarget.querySelector('[type="submit"]');
  button.disabled = true;
  button.textContent = "Лутфан интизор шавед…";
});
