"""Offline Unicode PDF, real DOCX, CSV and JSON exports of filtered results."""
from __future__ import annotations

import csv
import io
import json
import threading
from datetime import datetime
from pathlib import Path
from xml.sax.saxutils import escape

from .db import LOCAL_TZ

FONT_PATH = Path(__file__).parent / "static" / "fonts"
FONT_LOCK = threading.Lock()
COLUMNS = (
    ("№", None, 26), ("Ному насаб", "name", 142), ("Синф", "class_label", 40),
    ("Ҷинс", "gender", 43), ("Миллат", "nation", 60), ("Ҷои истиқомат", "address", 142),
    ("Телефони волидайн", "phone", 85), ("Ному насаби падар", "father_name", 122),
    ("Вазифаи падар", "father_job", 83), ("Ному насаби модар", "mother_name", 122),
    ("Вазифаи модар", "mother_job", 83), ("Телефони хонанда", "student_phone", 85),
)


def row_values(student: dict, index: int) -> list[str]:
    data = dict(student, class_label=f"{student['class_number']}{student['section']}")
    return [str(index) if field is None else str(data.get(field, "") or "—") for _, field, _ in COLUMNS]


def export_csv(students: list[dict]) -> bytes:
    output = io.StringIO(newline="")
    writer = csv.writer(output)
    writer.writerow([label for label, _, _ in COLUMNS])
    for index, student in enumerate(students, 1):
        values = row_values(student, index)
        # Spreadsheet formula injection also applies to phone numbers starting +.
        writer.writerow(["'" + v if v.lstrip().startswith(("=", "+", "-", "@", "\t", "\r")) else v for v in values])
    return output.getvalue().encode("utf-8-sig")


def export_json(students: list[dict], school: dict) -> bytes:
    return json.dumps({"format": "school48", "schema_version": 1,
                       "exported_at": datetime.now(LOCAL_TZ).isoformat(),
                       "school": {key: school[key] for key in ("school_name", "district", "academic_year")},
                       "students": students}, ensure_ascii=False, indent=2).encode("utf-8")


def export_pdf(students: list[dict], school: dict, scope: str) -> bytes:
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_CENTER
    from reportlab.lib.pagesizes import A3, landscape
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.platypus import LongTable, Paragraph, SimpleDocTemplate, Spacer, TableStyle

    with FONT_LOCK:
        if "School48" not in pdfmetrics.getRegisteredFontNames():
            pdfmetrics.registerFont(TTFont("School48", str(FONT_PATH / "DejaVuSans.ttf")))
            pdfmetrics.registerFont(TTFont("School48Bold", str(FONT_PATH / "DejaVuSans-Bold.ttf")))
    output = io.BytesIO()
    doc = SimpleDocTemplate(output, pagesize=landscape(A3), leftMargin=24, rightMargin=24,
                            topMargin=28, bottomMargin=34, title="Рӯйхати хонандагон", author=school["school_name"])
    title = ParagraphStyle("Title", fontName="School48Bold", fontSize=17, leading=23, textColor=colors.HexColor("#152b47"))
    subtitle = ParagraphStyle("Subtitle", fontName="School48", fontSize=9, leading=14, textColor=colors.HexColor("#526479"))
    body = ParagraphStyle("Cell", fontName="School48", fontSize=7.3, leading=10.7, wordWrap="CJK")
    header = ParagraphStyle("Head", parent=body, fontName="School48Bold", textColor=colors.white, wordWrap=None)
    rows = [[Paragraph(escape(label).replace("Телефони ", "Телефони<br/>"), header) for label, _, _ in COLUMNS]]
    for index, student in enumerate(students, 1):
        rows.append([Paragraph(escape(value), body) for value in row_values(student, index)])
    width = doc.width
    total_width = sum(col[2] for col in COLUMNS)
    table = LongTable(rows, colWidths=[col[2] * width / total_width for col in COLUMNS], repeatRows=1, hAlign="LEFT")
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#193654")),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 5), ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ("TOPPADDING", (0, 0), (-1, -1), 8), ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f3f6f9")]),
        ("LINEBELOW", (0, 1), (-1, -1), 0.3, colors.HexColor("#dce3ec")),
    ]))
    story = [Paragraph(escape(school["school_name"]), title),
             Paragraph(escape(f"Рӯйхати хонандагон | {school['district']} | Соли таҳсили {school['academic_year']}"), subtitle),
             Paragraph(escape(f"{scope} | Ҳамагӣ: {len(students)} | {datetime.now(LOCAL_TZ):%d.%m.%Y}"), subtitle),
             Spacer(1, 18), table]

    def footer(canvas, document):
        canvas.setFont("School48", 8)
        canvas.setFillColor(colors.HexColor("#526479"))
        canvas.drawString(24, 18, "School 48 • Маълумоти дохилии муассиса")
        canvas.drawRightString(document.pagesize[0] - 24, 18, f"Саҳифаи {document.page}")

    doc.build(story, onFirstPage=footer, onLaterPages=footer)
    return output.getvalue()


def export_docx(students: list[dict], school: dict, scope: str) -> bytes:
    from docx import Document
    from docx.enum.section import WD_ORIENT
    from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from docx.shared import Mm, Pt, RGBColor

    doc = Document()
    section = doc.sections[0]
    section.orientation = WD_ORIENT.LANDSCAPE
    section.page_width, section.page_height = Mm(420), Mm(297)
    section.top_margin = section.bottom_margin = Mm(14)
    section.left_margin = section.right_margin = Mm(10)
    normal = doc.styles["Normal"]
    normal.font.name = "DejaVu Sans"
    normal.font.size = Pt(8)
    normal.paragraph_format.space_after = Pt(0)
    normal.paragraph_format.line_spacing = 1.15
    doc.styles["Title"].font.name = "DejaVu Sans"
    doc.styles["Title"].font.size = Pt(20)
    doc.styles["Title"].font.color.rgb = RGBColor(0, 0, 0)
    doc.styles["Title"].paragraph_format.space_after = Pt(14)
    # Remove template paragraph borders, including inherited title rules.
    for style in doc.styles:
        for border in list(style.element.iter(qn("w:pBdr"))):
            border.getparent().remove(border)
    doc.add_paragraph("Рӯйхати хонандагони мактаби 48", style="Title")
    doc.add_paragraph(f"{school['school_name']} · {school['district']} · Соли таҳсили {school['academic_year']}")
    doc.add_paragraph(f"{scope} · Ҳамагӣ {len(students)} хонанда · Сана {datetime.now(LOCAL_TZ):%d.%m.%Y}")
    doc.add_paragraph("")
    table = doc.add_table(rows=1, cols=len(COLUMNS))
    table.autofit = False
    table.style = "Table Grid"
    borders = OxmlElement("w:tblBorders")
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        border = OxmlElement(f"w:{edge}")
        for key, value in (("val", "single"), ("sz", "4"), ("color", "D9D9D9")):
            border.set(qn(f"w:{key}"), value)
        borders.append(border)
    table._tbl.tblPr.append(borders)
    total_width = sum(col[2] for col in COLUMNS)
    widths = [Mm(400 * col[2] / total_width) for col in COLUMNS]
    for column, width in zip(table.columns, widths):
        column.width = width
    for cell, (label, _, _), width in zip(table.rows[0].cells, COLUMNS, widths):
        cell.width = width
        cell.text = label
        shade = OxmlElement("w:shd")
        shade.set(qn("w:fill"), "193654")
        cell._tc.get_or_add_tcPr().append(shade)
        for run in cell.paragraphs[0].runs:
            run.bold = True
            run.font.color.rgb = RGBColor(255, 255, 255)
    repeat = OxmlElement("w:tblHeader")
    table.rows[0]._tr.get_or_add_trPr().append(repeat)
    for index, student in enumerate(students, 1):
        row = table.add_row()
        for cell, value, width in zip(row.cells, row_values(student, index), widths):
            cell.width = width
            cell.text = value
            if index % 2 == 0:
                shade = OxmlElement("w:shd")
                shade.set(qn("w:fill"), "F3F6F9")
                cell._tc.get_or_add_tcPr().append(shade)
    for row in table.rows:
        for index, cell in enumerate(row.cells):
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            margins = OxmlElement("w:tcMar")
            for side, value in (("top", "65"), ("bottom", "65"), ("left", "85"), ("right", "85")):
                element = OxmlElement(f"w:{side}")
                element.set(qn("w:w"), value)
                element.set(qn("w:type"), "dxa")
                margins.append(element)
            cell._tc.get_or_add_tcPr().append(margins)
            if index in (0, 2, 3):
                cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
    for paragraph in doc.paragraphs:
        for border in list(paragraph._p.iter(qn("w:pBdr"))):
            border.getparent().remove(border)
    output = io.BytesIO()
    doc.core_properties.title = "Рӯйхати хонандагон"
    doc.core_properties.author = school["school_name"]
    doc.save(output)
    return output.getvalue()
