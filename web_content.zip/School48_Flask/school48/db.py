"""Per-request SQLite connections, schema initialization, and online backups."""
from __future__ import annotations

import sqlite3
import tempfile
import unicodedata
from datetime import datetime, timedelta, timezone
from pathlib import Path

from flask import current_app, g

LOCAL_TZ = timezone(timedelta(hours=5))
TG_ALPHABET = "абвгғдеёжзиӣйкқлмнопрстуӯфхҳчҷшъэюя"
TG_ORDER = {letter: index for index, letter in enumerate(TG_ALPHABET)}


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def fold(value: str) -> str:
    return unicodedata.normalize("NFC", value or "").casefold()


def _tajik_compare(a: str, b: str) -> int:
    def key(s):
        return [(TG_ORDER.get(c, 1000 + ord(c)), c) for c in fold(s)]
    ka, kb = key(a), key(b)
    return (ka > kb) - (ka < kb)


def connect(path: str | Path) -> sqlite3.Connection:
    conn = sqlite3.connect(str(path), timeout=20)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA busy_timeout = 20000")
    conn.create_function("casefold", 1, fold, deterministic=True)
    conn.create_collation("TAJIK", _tajik_compare)
    return conn


def get_db() -> sqlite3.Connection:
    if "db" not in g:
        g.db = connect(current_app.config["DATABASE"])
    return g.db


def close_db(_error=None) -> None:
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()


def init_db() -> None:
    conn = get_db()
    version = conn.execute("PRAGMA user_version").fetchone()[0]
    if version > 1:
        raise RuntimeError("Database schema is newer than this application.")
    conn.execute("PRAGMA journal_mode = WAL")
    conn.executescript(Path(__file__).with_name("schema.sql").read_text(encoding="utf-8"))
    today = datetime.now(LOCAL_TZ)
    year = today.year if today.month >= 9 else today.year - 1
    defaults = {
        "school_name": "Муассисаи таҳсилоти миёнаи умумии №48",
        "district": "Ноҳияи Вахш",
        "academic_year": f"{year}-{year + 1}",
    }
    with conn:
        conn.executemany("INSERT OR IGNORE INTO settings(key,value) VALUES (?,?)", defaults.items())


def settings() -> dict:
    return dict(get_db().execute("SELECT key,value FROM settings"))


def audit(action: str, detail: str, actor: str | None = None) -> None:
    """Called inside the same transaction as the action it records."""
    if actor is None:
        user = getattr(g, "user", None)
        actor = user["username"] if user else "system"
    get_db().execute(
        "INSERT INTO audit_log(actor,action,detail,created_at) VALUES (?,?,?,?)",
        (actor, action, detail[:300], now()),
    )


def backup_bytes() -> bytes:
    """Use SQLite's backup API so committed WAL data is included."""
    with tempfile.TemporaryDirectory(prefix="school48-backup-") as directory:
        target = Path(directory) / "school48.sqlite3"
        destination = sqlite3.connect(target)
        try:
            get_db().backup(destination)
        finally:
            destination.close()
        return target.read_bytes()
