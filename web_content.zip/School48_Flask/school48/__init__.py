"""School 48 Flask application factory."""
from __future__ import annotations

import os
import secrets
import sqlite3
from datetime import timedelta
from pathlib import Path

from flask import Flask, g, jsonify, render_template, request
from werkzeug.exceptions import HTTPException
from werkzeug.security import generate_password_hash

from . import auth, db
from .validation import ValidationError


def _secret(instance: Path) -> str:
    explicit = os.environ.get("SECRET_KEY")
    if explicit:
        if len(explicit) < 32:
            raise RuntimeError("SECRET_KEY must contain at least 32 characters.")
        return explicit
    path = instance / "secret.key"
    try:
        # Exclusive creation prevents two workers choosing different secrets.
        fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError:
        return path.read_text(encoding="ascii").strip()
    with os.fdopen(fd, "w", encoding="ascii") as file:
        value = secrets.token_hex(32)
        file.write(value)
    return value


def create_app(test_config: dict | None = None) -> Flask:
    instance = Path((test_config or {}).get("INSTANCE_PATH") or os.environ.get("SCHOOL48_INSTANCE") or Path(__file__).resolve().parent.parent / "instance")
    instance = instance.resolve()
    instance.mkdir(parents=True, exist_ok=True, mode=0o700)
    app = Flask(__name__, instance_path=str(instance))
    app.config.from_mapping(
        SECRET_KEY=(test_config or {}).get("SECRET_KEY") or _secret(instance),
        DATABASE=str(instance / "school48.sqlite3"),
        MAX_CONTENT_LENGTH=6 * 1024 * 1024,
        MAX_FORM_MEMORY_SIZE=64 * 1024,
        MAX_FORM_PARTS=40,
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE", "0") == "1",
        SESSION_COOKIE_NAME="school48_session",
        SESSION_REFRESH_EACH_REQUEST=False,
        PERMANENT_SESSION_LIFETIME=timedelta(hours=8),
        DUMMY_PASSWORD_HASH=generate_password_hash(secrets.token_hex(24)),
    )
    if os.environ.get("TRUSTED_HOSTS"):
        app.config["TRUSTED_HOSTS"] = [s.strip() for s in os.environ["TRUSTED_HOSTS"].split(",") if s.strip()]
    if test_config:
        app.config.update(test_config)
    app.json.ensure_ascii = False
    app.teardown_appcontext(db.close_db)
    app.jinja_env.globals.update(csrf_token=auth.csrf_token)

    @app.before_request
    def security():
        if request.endpoint == "static":
            return None
        auth.load_user()
        if request.path.startswith("/api/") and g.user is None:
            return jsonify(ok=False, error="Барои идома ворид шавед."), 401
        return auth.check_csrf()

    @app.after_request
    def headers(response):
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "same-origin"
        response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; script-src 'self'; style-src 'self'; "
            "img-src 'self' data:; font-src 'self'; connect-src 'self'; "
            "object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'"
        )
        if request.endpoint != "static":
            response.headers["Cache-Control"] = "no-store"
        if app.config["SESSION_COOKIE_SECURE"]:
            response.headers["Strict-Transport-Security"] = "max-age=31536000"
        return response

    @app.errorhandler(ValidationError)
    def validation_error(error):
        return jsonify(ok=False, error=str(error), fields=error.fields), error.status

    @app.errorhandler(HTTPException)
    def http_error(error):
        messages = {400: "Дархост нодуруст аст.", 404: "Саҳифа ёфт нашуд.", 405: "Ин амал иҷозат дода нашудааст.",
                    413: "Файл хеле калон аст. Ҳадди аксар 5 МБ.", 415: "Маълумотро дар шакли JSON фиристед."}
        message = messages.get(error.code, "Дархост иҷро нашуд.")
        if request.path.startswith("/api/"):
            return jsonify(ok=False, error=message), error.code
        return render_template("error.html", code=error.code, message=message), error.code

    @app.errorhandler(sqlite3.Error)
    def database_error(error):
        app.logger.error("SQLite operation failed: %s", type(error).__name__)
        message = "Пойгоҳи маълумот муваққатан дастрас нест. Амалро дубора санҷед."
        if request.path.startswith("/api/"):
            return jsonify(ok=False, error=message), 503
        return render_template("error.html", code=503, message=message), 503

    @app.errorhandler(500)
    def server_error(_error):
        message = "Хатои дохилии сервер. Лутфан амалро дубора санҷед."
        if request.path.startswith("/api/"):
            return jsonify(ok=False, error=message), 500
        return render_template("error.html", code=500, message=message), 500

    from .web import bp as web_bp
    app.register_blueprint(auth.bp)
    app.register_blueprint(web_bp)
    with app.app_context():
        db.init_db()
        # Original data is migrated once, never silently replaced or erased.
        legacy_path = Path(__file__).resolve().parent.parent / "legacy" / "students.json"
        if not db.get_db().execute("SELECT 1 FROM settings WHERE key='legacy_imported'").fetchone():
            if legacy_path.exists():
                from .importing import commit_import, parse_import
                rows = parse_import(legacy_path.read_bytes())
                if rows:
                    commit_import(rows, "migration")
            with db.get_db():
                db.get_db().execute("INSERT OR IGNORE INTO settings(key,value) VALUES ('legacy_imported','1')")
    return app
