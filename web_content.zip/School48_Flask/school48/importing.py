"""Atomic, idempotent import of the old Node app and new JSON backups."""
from __future__ import annotations

import hashlib
import json
import re
import uuid

from .db import audit, get_db
from .students import insert_student
from .validation import ValidationError, validate_student

ALIASES = {
    "class_number": ("class_number", "class", "className", "classNumber"),
    "father_name": ("father_name", "fatherJobName", "father"),
    "father_job": ("father_job", "fatherJob"),
    "mother_name": ("mother_name", "motherJobName", "mother"),
    "mother_job": ("mother_job", "motherJob"),
    "student_phone": ("student_phone", "studentPhone", "studentPhoneNumber"),
}


def parse_import(raw: bytes) -> list[tuple[str, dict]]:
    if len(raw) > 5 * 1024 * 1024:
        raise ValidationError("Ҳаҷми файл аз 5 МБ зиёд аст.", status=413)
    try:
        payload = json.loads(raw.decode("utf-8-sig"))
    except (ValueError, UnicodeError, RecursionError):
        raise ValidationError("Файли дурусти JSON бо рамзгузории UTF-8 интихоб кунед.") from None
    rows = payload.get("students") if isinstance(payload, dict) else payload
    if not isinstance(rows, list):
        raise ValidationError("Файл бояд рӯйхати хонандагон ё объекти students дошта бошад.")
    if len(rows) > 10000:
        raise ValidationError("Дар як бор то 10 000 сабт ворид кардан мумкин аст.")
    normalized, seen, errors = [], set(), []
    for index, row in enumerate(rows, 1):
        if not isinstance(row, dict):
            errors.append(f"Сатри {index}: объект лозим аст.")
            continue
        mapped = dict(row)
        for field, aliases in ALIASES.items():
            for key in aliases:
                if key in row:
                    mapped[field] = row[key]
                    break
        legacy_class = str(mapped.get("class_number", "")).strip()
        match = re.fullmatch(r"(\d{1,2})\s*[- ]?\s*([A-Za-zА-Яа-яЁёҒғӢӣҚқӮӯҲҳҶҷ]{0,3})", legacy_class)
        if match:
            mapped["class_number"] = match.group(1)
            mapped.setdefault("section", match.group(2))
        gender = mapped.get("gender", "")
        if isinstance(gender, str):
            mapped["gender"] = {"писар": "Мард", "духтар": "Зан", "male": "Мард", "female": "Зан"}.get(gender.casefold(), gender)
        try:
            data = validate_student(mapped)
            original_id = row.get("id")
            if original_id is None or original_id == "":
                student_id = str(uuid.uuid5(uuid.NAMESPACE_URL, "school48:" + json.dumps(data, ensure_ascii=False, sort_keys=True)))
            elif isinstance(original_id, (int, str)) and not isinstance(original_id, bool) and re.fullmatch(r"[A-Za-z0-9_-]{1,64}", str(original_id)):
                student_id = str(original_id)
            else:
                raise ValidationError("ID сабт нодуруст аст.")
            if student_id in seen:
                raise ValidationError("ID дар дохили файл такрор шудааст.")
            seen.add(student_id)
            normalized.append((student_id, data))
        except ValidationError as exc:
            detail = "; ".join(exc.fields.values()) or str(exc)
            errors.append(f"Сатри {index}: {detail}")
        if len(errors) >= 12:
            break
    if errors:
        raise ValidationError("Файл ворид нашуд. " + " ".join(errors))
    return normalized


def preview_import(rows: list[tuple[str, dict]], raw: bytes) -> dict:
    existing = {row[0] for row in get_db().execute("SELECT id FROM students")}
    skipped = sum(student_id in existing for student_id, _ in rows)
    return dict(total=len(rows), added=len(rows) - skipped, skipped=skipped,
                fingerprint=hashlib.sha256(raw).hexdigest(), sample=[data for _, data in rows[:5]])


def commit_import(rows: list[tuple[str, dict]], actor=None) -> dict:
    conn, added, skipped = get_db(), 0, 0
    with conn:
        conn.execute("BEGIN IMMEDIATE")
        existing = {r[0] for r in conn.execute("SELECT id FROM students")}
        for student_id, data in rows:
            if student_id in existing:
                skipped += 1
                continue
            insert_student(data, student_id)
            added += 1
        audit("import", f"Ворид шуд: {added}; такрорӣ: {skipped}", actor)
    return dict(added=added, skipped=skipped, total=len(rows))
