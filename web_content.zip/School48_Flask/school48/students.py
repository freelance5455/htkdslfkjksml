"""Student queries and transactional operations. All SQL values are bound."""
from __future__ import annotations

import math
import re
import uuid

from flask import request

from .db import audit, fold, get_db, now
from .validation import FIELDS, ValidationError, validate_student, version_from

ORDERS = {
    "class-name": "class_number ASC, section COLLATE TAJIK, name COLLATE TAJIK, id",
    "name": "name COLLATE TAJIK, id",
    "name-desc": "name COLLATE TAJIK DESC, id",
    "class-desc": "class_number DESC, section COLLATE TAJIK, name COLLATE TAJIK, id",
    "nation": "nation COLLATE TAJIK, name COLLATE TAJIK, id",
    "recent": "created_at DESC, id",
}


def serialize(row) -> dict:
    return dict(row)


def filters(args) -> tuple[str, list, str, dict]:
    clauses, params, active = ["deleted_at IS NULL"], [], {}
    class_value = args.get("class_number", "")
    if class_value:
        if not re.fullmatch(r"[1-9]|10|11", class_value):
            raise ValidationError("Синфро дуруст интихоб кунед.", status=400)
        clauses.append("class_number=?")
        params.append(int(class_value))
        active["class_number"] = class_value
    for key in ("gender", "nation", "section"):
        value = args.get(key, "").strip()
        if len(value) > 60:
            raise ValidationError("Филтр хеле дароз аст.", status=400)
        if value or (key == "section" and key in args):
            clauses.append(f"{key}=?")
            params.append(value)
            active[key] = value
    search = args.get("q", "").strip()
    if len(search) > 150:
        raise ValidationError("Ҷустуҷӯ: ҳадди аксар 150 аломат.", status=400)
    if search:
        escaped = fold(search).replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
        fields = ("name", "father_name", "mother_name", "phone", "student_phone", "address")
        clauses.append("(" + " OR ".join(f"casefold({field}) LIKE ? ESCAPE '\\'" for field in fields) + ")")
        params.extend([f"%{escaped}%"] * len(fields))
        active["q"] = search
    sort = args.get("sort", "class-name")
    if sort not in ORDERS:
        raise ValidationError("Тартиби рӯйхат нодуруст аст.", status=400)
    active["sort"] = sort
    return " AND ".join(clauses), params, ORDERS[sort], active


def positive_int(value, default: int, maximum: int) -> int:
    if value is None:
        return default
    if not re.fullmatch(r"[1-9][0-9]{0,6}", str(value)) or int(value) > maximum:
        raise ValidationError("Рақами саҳифа ё шумораи сатрҳо нодуруст аст.", status=400)
    return int(value)


def listing(args, paginate=True) -> dict:
    where, params, order, active = filters(args)
    conn = get_db()
    # The count and the page belong to the same snapshot under concurrent edits.
    with conn:
        conn.execute("BEGIN")
        total = conn.execute(f"SELECT count(*) FROM students WHERE {where}", params).fetchone()[0]
        query = f"SELECT * FROM students WHERE {where} ORDER BY {order}"
        page, size, pages = 1, total, 1
        if paginate:
            size = positive_int(args.get("page_size"), 10, 100)
            pages = max(1, math.ceil(total / size))
            page = min(positive_int(args.get("page"), 1, 1_000_000), pages)
            query += " LIMIT ? OFFSET ?"
            params += [size, (page - 1) * size]
        rows = conn.execute(query, params).fetchall()
    return dict(students=[serialize(r) for r in rows], total=total, page=page,
                page_size=size, pages=pages, filters=active)


def insert_student(data: dict, student_id: str | None = None) -> dict:
    student_id = student_id or str(uuid.uuid4())
    stamp = now()
    columns = ("id",) + FIELDS + ("created_at", "updated_at")
    values = [student_id] + [data[key] for key in FIELDS] + [stamp, stamp]
    get_db().execute(
        f"INSERT INTO students ({','.join(columns)}) VALUES ({','.join('?' for _ in columns)})", values,
    )
    return dict(get_db().execute("SELECT * FROM students WHERE id=?", (student_id,)).fetchone())


def require_student(student_id: str, deleted=False):
    row = get_db().execute(
        "SELECT * FROM students WHERE id=? AND deleted_at IS " + ("NOT NULL" if deleted else "NULL"),
        (student_id,),
    ).fetchone()
    if row is None:
        raise ValidationError("Хонанда ёфт нашуд. Рӯйхатро нав кунед.", status=404)
    return row


def update_student(student_id: str, payload: dict) -> dict:
    data = validate_student(payload)
    version = version_from(payload)
    conn = get_db()
    with conn:
        changed = conn.execute(
            "UPDATE students SET " + ",".join(f"{key}=?" for key in FIELDS) +
            ", updated_at=?, version=version+1 WHERE id=? AND version=? AND deleted_at IS NULL",
            [data[key] for key in FIELDS] + [now(), student_id, version],
        ).rowcount
        if not changed:
            require_student(student_id)
            raise ValidationError("Сабтро корбари дигар тағйир дод. Рӯйхатро нав карда, дубора кушоед.", status=409)
        audit("update", data["name"])
        student = dict(require_student(student_id))
    return student


def delete_student(student_id: str, payload: dict) -> None:
    version = version_from(payload)
    conn, stamp = get_db(), now()
    with conn:
        row = require_student(student_id)
        changed = conn.execute(
            "UPDATE students SET deleted_at=?,updated_at=?,version=version+1 WHERE id=? AND version=? AND deleted_at IS NULL",
            (stamp, stamp, student_id, version),
        ).rowcount
        if not changed:
            raise ValidationError("Сабт тағйир ёфт. Аввал рӯйхатро нав кунед.", status=409)
        audit("delete", row["name"])


def summary() -> dict:
    conn = get_db()
    with conn:
        conn.execute("BEGIN")
        counts = dict(conn.execute(
            "SELECT count(*) total, COALESCE(sum(gender='Мард'),0) boys, "
            "COALESCE(sum(gender='Зан'),0) girls, "
            "count(DISTINCT cast(class_number AS TEXT)||':'||section) classes "
            "FROM students WHERE deleted_at IS NULL"
        ).fetchone())
        groups = [dict(r) for r in conn.execute(
            "SELECT class_number, section, count(*) total, COALESCE(sum(gender='Мард'),0) boys, "
            "COALESCE(sum(gender='Зан'),0) girls FROM students WHERE deleted_at IS NULL "
            "GROUP BY class_number,section ORDER BY class_number, section COLLATE TAJIK"
        )]
        nations = [r[0] for r in conn.execute(
            "SELECT DISTINCT nation FROM students WHERE deleted_at IS NULL AND nation!='' ORDER BY nation COLLATE TAJIK"
        )]
        recent = [dict(r) for r in conn.execute("SELECT * FROM audit_log ORDER BY id DESC LIMIT 8")]
        trash = conn.execute("SELECT count(*) FROM students WHERE deleted_at IS NOT NULL").fetchone()[0]
    return dict(counts=counts, classes=groups, nations=nations, recent=recent, trash=trash)
