"""Server-validated login, revocable sessions, CSRF, and persistent throttling."""
from __future__ import annotations

import hashlib
import hmac
import ipaddress
import re
import secrets
import sqlite3
import time
from functools import wraps

from flask import Blueprint, current_app, g, jsonify, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

from .db import audit, get_db, now
from .validation import ValidationError, clean_text, validate_password

bp = Blueprint("auth", __name__)


def csrf_token() -> str:
    if "csrf_token" not in session:
        session["csrf_token"] = secrets.token_hex(32)
    return session["csrf_token"]


def _sid_hash(sid: str) -> str:
    return hashlib.sha256(sid.encode()).hexdigest()


def establish_session(user_id: int) -> None:
    session.clear()
    sid = secrets.token_urlsafe(32)
    expires = int(time.time()) + int(current_app.permanent_session_lifetime.total_seconds())
    conn = get_db()
    with conn:
        conn.execute("DELETE FROM sessions WHERE expires_at <= ?", (int(time.time()),))
        conn.execute("INSERT INTO sessions VALUES (?,?,?)", (_sid_hash(sid), user_id, expires))
    session["sid"] = sid
    session.permanent = True
    csrf_token()


def load_user() -> None:
    g.user = None
    sid = session.get("sid")
    if isinstance(sid, str):
        g.user = get_db().execute(
            "SELECT u.* FROM users u JOIN sessions s ON s.user_id=u.id "
            "WHERE s.token_hash=? AND s.expires_at>?", (_sid_hash(sid), int(time.time())),
        ).fetchone()
        if g.user is None:
            session.clear()


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if g.user is None:
            if request.path.startswith("/api/"):
                return jsonify(ok=False, error="Барои идома аз нав ворид шавед."), 401
            return redirect(url_for("auth.login"))
        return view(*args, **kwargs)
    return wrapped


def check_csrf():
    if request.method in {"POST", "PUT", "PATCH", "DELETE"}:
        expected = session.get("csrf_token", "")
        received = request.headers.get("X-CSRF-Token", "") or request.form.get("csrf_token", "")
        if not expected or not isinstance(received, str) or not received.isascii() or not hmac.compare_digest(expected, received):
            if request.path.startswith("/api/"):
                return jsonify(ok=False, error="Нишонаи амниятӣ нав шуд. Саҳифаро нав кунед."), 403
            return render_template("error.html", code=403, message="Саҳифаро нав карда, амалро такрор кунед."), 403


def is_setup_needed() -> bool:
    return get_db().execute("SELECT 1 FROM users LIMIT 1").fetchone() is None


def _attempt_keys(username: str) -> tuple[str, str]:
    # Separate address and account limits prevent username/IP cycling bypasses.
    secret = str(current_app.secret_key).encode()
    return tuple(hmac.new(secret, value.encode(), hashlib.sha256).hexdigest() for value in (
        "ip:" + (request.remote_addr or "unknown"), "user:" + username.casefold(),
    ))


def throttled(username: str) -> int:
    remaining = 0
    for key in _attempt_keys(username):
        row = get_db().execute("SELECT blocked_until FROM login_attempts WHERE key=?", (key,)).fetchone()
        if row:
            remaining = max(remaining, row[0] - int(time.time()))
    return remaining


def failed_attempt(username: str) -> None:
    stamp = int(time.time())
    conn = get_db()
    with conn:
        conn.execute("DELETE FROM login_attempts WHERE window_start < ? AND blocked_until < ?", (stamp - 86400, stamp))
        for key in _attempt_keys(username):
            conn.execute(
                "INSERT INTO login_attempts(key,failures,window_start,blocked_until) VALUES (?,1,?,0) "
                "ON CONFLICT(key) DO UPDATE SET "
                "failures=CASE WHEN window_start<? THEN 1 ELSE failures+1 END, "
                "window_start=CASE WHEN window_start<? THEN ? ELSE window_start END",
                (key, stamp, stamp - 900, stamp - 900, stamp),
            )
            conn.execute("UPDATE login_attempts SET blocked_until=? WHERE key=? AND failures>=8", (stamp + 300, key))


@bp.route("/setup", methods=["GET", "POST"])
def setup():
    if not is_setup_needed():
        return redirect(url_for("auth.login"))
    try:
        local = ipaddress.ip_address(request.remote_addr or "0.0.0.0").is_loopback
    except ValueError:
        local = False
    if not local:
        return render_template("error.html", code=403, message="Танзими аввалро дар компютери сервер тавассути localhost анҷом диҳед."), 403
    error = ""
    if request.method == "POST":
        try:
            username = request.form.get("username", "").strip().lower()
            if not re.fullmatch(r"[a-z0-9_.-]{3,32}", username):
                raise ValidationError("Номи корбар: 3–32 ҳарфи лотинӣ, рақам, нуқта ё тире.")
            display_name = clean_text(request.form.get("display_name", ""), "Номи шумо", 80) or "Маъмур"
            password = validate_password(request.form.get("password"))
            if password != request.form.get("password_confirm"):
                raise ValidationError("Рамзҳои воридшуда якхела нестанд.")
            password_hash = generate_password_hash(password)
            conn = get_db()
            with conn:
                conn.execute("BEGIN IMMEDIATE")
                if not is_setup_needed():
                    return redirect(url_for("auth.login"))
                cursor = conn.execute(
                    "INSERT INTO users(username,display_name,password_hash,created_at) VALUES (?,?,?,?)",
                    (username, display_name, password_hash, now()),
                )
                user_id = cursor.lastrowid
                audit("setup", "Ҳисоби маъмур сохта шуд", username)
            establish_session(user_id)
            return redirect(url_for("web.index"))
        except (ValidationError, ValueError) as exc:
            error = str(exc)
        except sqlite3.IntegrityError:
            error = "Ҳисоб аллакай сохта шудааст. Аз саҳифаи воридшавӣ истифода баред."
    return render_template("auth.html", setup=True, error=error), 422 if error else 200


@bp.route("/login", methods=["GET", "POST"])
def login():
    if is_setup_needed():
        return redirect(url_for("auth.setup"))
    if g.user:
        return redirect(url_for("web.index"))
    error, status = "", 200
    if request.method == "POST":
        username = request.form.get("username", "")[:64].strip().lower()
        password = request.form.get("password", "")
        remaining = throttled(username)
        if remaining:
            error, status = f"Кӯшишҳо зиёданд. Баъд аз {remaining} сония такрор кунед.", 429
        else:
            user = get_db().execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
            candidate_hash = user["password_hash"] if user else current_app.config["DUMMY_PASSWORD_HASH"]
            valid = len(password) <= 128 and check_password_hash(candidate_hash, password)
            if user is not None and valid:
                with get_db():
                    # Clear account failures; the IP limit remains until its window ends.
                    get_db().execute("DELETE FROM login_attempts WHERE key=?", (_attempt_keys(username)[1],))
                    audit("login", "Воридшавӣ ба система", user["username"])
                establish_session(user["id"])
                return redirect(url_for("web.index"))
            failed_attempt(username)
            error, status = "Номи корбар ё рамз нодуруст аст.", 401
    response = current_app.make_response((render_template("auth.html", setup=False, error=error), status))
    if status == 429:
        response.headers["Retry-After"] = str(max(1, throttled(username)))
    return response


@bp.post("/logout")
@login_required
def logout():
    with get_db():
        get_db().execute("DELETE FROM sessions WHERE token_hash=?", (_sid_hash(session["sid"]),))
    session.clear()
    return redirect(url_for("auth.login"))
