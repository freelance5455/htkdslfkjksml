from __future__ import annotations

import hashlib
import io
import math
import re
import time
from datetime import datetime

from flask import Blueprint, g, jsonify, redirect, render_template, request, send_file, url_for
from werkzeug.security import check_password_hash, generate_password_hash

from . import exports, importing, students
from .auth import establish_session, is_setup_needed, login_required
from .db import LOCAL_TZ, audit, backup_bytes, get_db, now, settings
from .validation import ValidationError, clean_text, validate_password, validate_student, version_from

bp = Blueprint("web", __name__)


def json_object() -> dict:
    payload = request.get_json()
    if not isinstance(payload, dict):
        raise ValidationError("Маълумот бояд объекти JSON бошад.", status=400)
    return payload


@bp.get("/")
def index():
    if is_setup_needed():
        return redirect(url_for("auth.setup"))
    if g.user is None:
        return redirect(url_for("auth.login"))
    return render_template("index.html", school=settings(), user=g.user)


@bp.get("/health")
def health():
    get_db().execute("SELECT 1").fetchone()
    return jsonify(ok=True, service="School48", version="2.0.0")


@bp.get("/api/summary")
def summary():
    return jsonify(ok=True, **students.summary())


@bp.get("/api/students")
def list_students():
    return jsonify(ok=True, **students.listing(request.args))


@bp.post("/api/students")
def add_student():
    payload = validate_student(json_object())
    with get_db():
        student = students.insert_student(payload)
        audit("create", student["name"])
    return jsonify(ok=True, student=student), 201


@bp.get("/api/students/<student_id>")
def get_student(student_id):
    return jsonify(ok=True, student=dict(students.require_student(student_id)))


@bp.put("/api/students/<student_id>")
def edit_student(student_id):
    return jsonify(ok=True, student=students.update_student(student_id, json_object()))


@bp.delete("/api/students/<student_id>")
def delete_student(student_id):
    students.delete_student(student_id, json_object())
    return jsonify(ok=True)


@bp.post("/api/students/clear")
def clear_students():
    payload = json_object()
    if payload.get("confirmation") != "ҲАЗФ":
        raise ValidationError("Барои тасдиқ калимаи ҲАЗФ-ро ворид кунед.")
    password = payload.get("password", "")
    if not isinstance(password, str) or len(password) > 128 or not check_password_hash(g.user["password_hash"], password):
        raise ValidationError("Рамзи ҷорӣ нодуруст аст.", status=403)
    expected = payload.get("expected_count")
    if type(expected) is not int or expected < 0:
        raise ValidationError("Шумораи хонандагонро аз нав бор кунед.", status=400)
    conn, stamp = get_db(), now()
    with conn:
        conn.execute("BEGIN IMMEDIATE")
        count = conn.execute("SELECT count(*) FROM students WHERE deleted_at IS NULL").fetchone()[0]
        if count != expected:
            raise ValidationError("Рӯйхат тағйир ёфт. Онро нав карда, амалро такрор кунед.", status=409)
        conn.execute("UPDATE students SET deleted_at=?,updated_at=?,version=version+1 WHERE deleted_at IS NULL", (stamp, stamp))
        audit("clear", f"Ба сабад гузаронда шуд: {count}")
    return jsonify(ok=True, count=count)


@bp.get("/api/trash")
def trash():
    conn, size = get_db(), 20
    total = conn.execute("SELECT count(*) FROM students WHERE deleted_at IS NOT NULL").fetchone()[0]
    pages = max(1, math.ceil(total / size))
    page = min(students.positive_int(request.args.get("page"), 1, 1_000_000), pages)
    rows = conn.execute("SELECT * FROM students WHERE deleted_at IS NOT NULL ORDER BY deleted_at DESC, id LIMIT ? OFFSET ?", (size, (page - 1) * size))
    return jsonify(ok=True, students=[dict(r) for r in rows], page=page, pages=pages, total=total)


@bp.post("/api/trash/<student_id>/restore")
def restore_student(student_id):
    version = version_from(json_object())
    conn = get_db()
    with conn:
        row = students.require_student(student_id, deleted=True)
        changed = conn.execute("UPDATE students SET deleted_at=NULL,updated_at=?,version=version+1 WHERE id=? AND version=? AND deleted_at IS NOT NULL", (now(), student_id, version)).rowcount
        if not changed:
            raise ValidationError("Сабт тағйир ёфт. Сабадро нав кунед.", status=409)
        audit("restore", row["name"])
    return jsonify(ok=True)


@bp.get("/api/export/<format_name>")
def export_students(format_name):
    formats = {"csv": (exports.export_csv, "text/csv; charset=utf-8"),
               "json": (exports.export_json, "application/json; charset=utf-8"),
               "pdf": (exports.export_pdf, "application/pdf"),
               "docx": (exports.export_docx, "application/vnd.openxmlformats-officedocument.wordprocessingml.document")}
    if format_name not in formats:
        raise ValidationError("Навъи файл дастгирӣ намешавад.", status=404)
    result = students.listing(request.args, paginate=False)
    school = settings()
    scope = "Ҳамаи хонандагон" if len(result["filters"]) == 1 else "Рӯйхат бо филтрҳои интихобшуда"
    function, mimetype = formats[format_name]
    if format_name == "csv":
        content = function(result["students"])
    elif format_name == "json":
        content = function(result["students"], school)
    else:
        content = function(result["students"], school, scope)
    filename = f"School48_students_{datetime.now(LOCAL_TZ):%Y%m%d}.{format_name}"
    return send_file(io.BytesIO(content), mimetype=mimetype, as_attachment=True, download_name=filename, max_age=0)


@bp.get("/api/backup")
def backup():
    data = backup_bytes()
    return send_file(io.BytesIO(data), mimetype="application/vnd.sqlite3", as_attachment=True,
                     download_name=f"School48_backup_{datetime.now(LOCAL_TZ):%Y%m%d_%H%M%S}.sqlite3", max_age=0)


@bp.post("/api/import/<stage>")
def import_students(stage):
    if stage not in ("preview", "commit"):
        raise ValidationError("Амал ёфт нашуд.", status=404)
    upload = request.files.get("file")
    if upload is None or not upload.filename:
        raise ValidationError("Файли JSON-ро интихоб кунед.")
    raw = upload.read(5 * 1024 * 1024 + 1)
    rows = importing.parse_import(raw)
    if stage == "preview":
        return jsonify(ok=True, **importing.preview_import(rows, raw))
    if request.form.get("fingerprint") != hashlib.sha256(raw).hexdigest():
        raise ValidationError("Файл тағйир ёфт. Онро аз нав санҷед.", status=409)
    return jsonify(ok=True, **importing.commit_import(rows))


@bp.put("/api/settings")
def update_settings():
    payload = json_object()
    try:
        data = {key: clean_text(payload.get(key, ""), label, limit) for key, label, limit in (
            ("school_name", "Номи муассиса", 150), ("district", "Ноҳия", 100), ("academic_year", "Соли таҳсил", 9),
        )}
    except ValueError as exc:
        raise ValidationError(str(exc)) from None
    if not data["school_name"] or not data["district"]:
        raise ValidationError("Номи муассиса ва ноҳияро ворид кунед.")
    match = re.fullmatch(r"(20\d{2})-(20\d{2})", data["academic_year"])
    if not match or int(match.group(2)) != int(match.group(1)) + 1:
        raise ValidationError("Соли таҳсилро ба шакли 2026-2027 ворид кунед.")
    with get_db():
        get_db().executemany("UPDATE settings SET value=? WHERE key=?", [(value, key) for key, value in data.items()])
        audit("settings", "Маълумоти муассиса нав шуд")
    return jsonify(ok=True, settings=data)


@bp.put("/api/password")
def change_password():
    payload = json_object()
    current = payload.get("current_password", "")
    if not isinstance(current, str) or len(current) > 128 or not check_password_hash(g.user["password_hash"], current):
        raise ValidationError("Рамзи ҷорӣ нодуруст аст.", status=403)
    password = validate_password(payload.get("password"))
    if password != payload.get("password_confirm"):
        raise ValidationError("Рамзҳои нав якхела нестанд.")
    with get_db():
        get_db().execute("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(password), g.user["id"]))
        get_db().execute("DELETE FROM sessions WHERE user_id=?", (g.user["id"],))
        audit("password", "Рамз иваз шуд; нишастҳои пешина қатъ шуданд")
    establish_session(g.user["id"])
    from .auth import csrf_token
    return jsonify(ok=True, csrf_token=csrf_token())
