# School 48 — Python Flask + SQLite

See **[README_TG.md](README_TG.md)** for the complete Tajik installation and usage guide.

**Windows:** extract the archive, run `setup.bat` once, then `start.bat`.

**Linux / macOS:** `sh setup.sh`, then `sh start.sh`.

Open **http://127.0.0.1:5000** and create your administrator account on the first visit. Requires Python **3.10+**. There is no default password. Runtime data lives in `instance/`; keep this directory across code upgrades.

The server uses Waitress, not Flask's debug server. All student data is stored in SQLite. PDF and DOCX exports, fonts and UI assets work offline after the initial dependency installation. The original uploaded `students.json` contained no student records.

Use `python manage.py --help` for backup, offline restore, legacy JSON import and password recovery. Stop the server before a restore. Internet hosting needs your own persistent Python server and HTTPS; no hosting is included in this archive.
