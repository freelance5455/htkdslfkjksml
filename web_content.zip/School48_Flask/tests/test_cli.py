import sys

import manage
from school48.db import get_db
from .conftest import add


def test_cli_backup_restore_and_session_revocation(app, admin, headers, student, tmp_path, monkeypatch):
    row = add(admin, headers, student)
    monkeypatch.setenv("SCHOOL48_INSTANCE", app.instance_path)
    monkeypatch.setenv("SECRET_KEY", app.secret_key)
    backup = tmp_path / "manual.sqlite3"
    monkeypatch.setattr(sys, "argv", ["manage.py", "backup", str(backup)])
    manage.main()
    assert backup.is_file()
    assert admin.put(f"/api/students/{row['id']}", json=dict(student, name="Номи тағйиршуда", version=1), headers=headers).status_code == 200
    monkeypatch.setattr(sys, "argv", ["manage.py", "restore", str(backup), "--yes"])
    manage.main()
    with app.app_context():
        assert get_db().execute("SELECT name FROM students WHERE id=?", (row["id"],)).fetchone()[0] == student["name"]
        assert get_db().execute("SELECT count(*) FROM sessions").fetchone()[0] == 0
    assert admin.get("/api/students").status_code == 401
    assert list((tmp_path / "instance" / "backups").glob("before_restore_*.sqlite3"))
