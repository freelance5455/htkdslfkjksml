from concurrent.futures import ThreadPoolExecutor

import pytest

from school48 import create_app
from school48.db import get_db
from .conftest import PASSWORD, add


def test_complete_student_lifecycle_and_restore(app, admin, headers, student):
    saved = add(admin, headers, student)
    for key, value in student.items():
        assert saved[key] == value
    response = admin.get("/api/students").json
    assert response["students"][0]["id"] == saved["id"]
    assert response["total"] == 1
    updated = dict(student, name="Ҳусейнов Ҷамшеди Қодир", mother_job="Сартабиб", version=saved["version"])
    edit = admin.put(f"/api/students/{saved['id']}", json=updated, headers=headers)
    assert edit.status_code == 200
    assert edit.json["student"]["version"] == 2
    assert edit.json["student"]["mother_job"] == "Сартабиб"
    deleted = admin.delete(f"/api/students/{saved['id']}", json={"version": 2}, headers=headers)
    assert deleted.status_code == 200
    assert admin.get("/api/students").json["total"] == 0
    trash = admin.get("/api/trash").json["students"][0]
    assert trash["version"] == 3
    restore = admin.post(f"/api/trash/{saved['id']}/restore", json={"version": 3}, headers=headers)
    assert restore.status_code == 200
    assert admin.get(f"/api/students/{saved['id']}").json["student"]["version"] == 4
    with app.app_context():
        assert get_db().execute("SELECT count(*) FROM audit_log WHERE action IN ('create','update','delete','restore')").fetchone()[0] == 4


@pytest.mark.parametrize("field,value", [("class_number", 0), ("class_number", 12), ("class_number", True), ("class_number", 1.2), ("class_number", "7A"), ("name", "  "), ("name", "a"), ("name", None), ("name", "x\x00y"), ("phone", "123"), ("phone", "abc901234567"), ("gender", "other"), ("section", "7"), ("address", "x"*301), ("nation", ["Тоҷик"])])
def test_invalid_student_never_writes(admin, headers, student, field, value):
    response = admin.post("/api/students", json=dict(student, **{field: value}), headers=headers)
    assert response.status_code == 422
    assert field in response.json["fields"]
    assert admin.get("/api/students").json["total"] == 0


def test_optional_fields_are_not_mandatory(admin, headers):
    saved = add(admin, headers, {"name": "Хонандаи санҷишӣ", "class_number": 1})
    assert saved["phone"] == ""


def test_stale_edits_and_delete_cannot_overwrite(admin, headers, student):
    saved = add(admin, headers, student)
    url = f"/api/students/{saved['id']}"
    assert admin.put(url, json=dict(student, version=1), headers=headers).status_code == 200
    assert admin.put(url, json=dict(student, version=1, name="Changed"), headers=headers).status_code == 409
    assert admin.delete(url, json={"version": 1}, headers=headers).status_code == 409
    assert admin.put(url, json=student, headers=headers).status_code == 400


def test_two_simultaneous_edits_only_one_succeeds(app, admin, headers, student):
    saved = add(admin, headers, student)
    cookie = admin.get_cookie("school48_session").value
    def edit(name):
        with app.test_client() as client:
            client.set_cookie("school48_session", cookie)
            return client.put(f"/api/students/{saved['id']}", json=dict(student, version=1, name=name), headers=headers).status_code
    with ThreadPoolExecutor(max_workers=2) as pool:
        statuses = list(pool.map(edit, ["Хонандаи аввал", "Хонандаи дуюм"]))
    assert sorted(statuses) == [200, 409]


def test_filter_search_unicode_literal_and_pagination(admin, headers, student):
    add(admin, headers, student)
    add(admin, headers, dict(student, name="Ғафурова Қурбонбӣ", class_number=10, section="Б", gender="Зан", nation="Узбек"))
    for q in ("ҳусейнов", "ҚОДИР", "+992"):
        assert admin.get("/api/students", query_string={"q": q}).json["total"] >= 1
    for q in ("%", "_", "' OR 1=1--"):
        assert admin.get("/api/students", query_string={"q": q}).json["total"] == 0
    filtered = admin.get("/api/students?class_number=10&gender=Зан&nation=Узбек&section=Б").json
    assert filtered["total"] == 1
    assert filtered["students"][0]["name"] == "Ғафурова Қурбонбӣ"
    page = admin.get("/api/students?page_size=1&page=2").json
    assert page["pages"] == 2 and len(page["students"]) == 1
    assert page["students"][0]["class_number"] == 10
    assert admin.get("/api/students?page=999&page_size=1").json["page"] == 2
    summary = admin.get("/api/summary").json
    assert summary["counts"] == {"total": 2, "boys": 1, "girls": 1, "classes": 2}


@pytest.mark.parametrize("query", ["page=0", "page_size=200", "class_number=12", "sort=name;DROP TABLE students", "page=1.1"])
def test_invalid_query_rejected(admin, query):
    assert admin.get("/api/students?" + query).status_code == 400


def test_json_types_and_404(admin, headers):
    assert admin.post("/api/students", json=[], headers=headers).status_code == 400
    assert admin.post("/api/students", data="{oops", content_type="application/json", headers=headers).status_code == 400
    assert admin.post("/api/students", data="name=x", headers=headers).status_code == 415
    assert admin.get("/api/students/missing").status_code == 404
    assert admin.get("/api/not-real").status_code == 404


def test_clear_all_requires_password_confirmation_count_and_keeps_trash(admin, headers, student):
    add(admin, headers, student)
    payload = {"confirmation": "ҲАЗФ", "password": PASSWORD, "expected_count": 1}
    assert admin.post("/api/students/clear", json=dict(payload, confirmation="yes"), headers=headers).status_code == 422
    assert admin.post("/api/students/clear", json=dict(payload, password="wrong"), headers=headers).status_code == 403
    assert admin.post("/api/students/clear", json=dict(payload, expected_count=0), headers=headers).status_code == 409
    assert admin.get("/api/students").json["total"] == 1
    assert admin.post("/api/students/clear", json=payload, headers=headers).status_code == 200
    assert admin.get("/api/students").json["total"] == 0
    assert admin.get("/api/trash").json["total"] == 1


def test_sqlite_persists_between_application_instances(app, admin, headers, student):
    saved = add(admin, headers, student)
    second = create_app({"TESTING": True, "INSTANCE_PATH": app.instance_path, "SECRET_KEY": app.secret_key})
    with second.app_context():
        assert get_db().execute("SELECT name FROM students WHERE id=?", (saved["id"],)).fetchone()[0] == student["name"]


def test_settings_validation_and_saved_values(admin, headers):
    data = {"school_name": "Мактаби санҷишӣ", "district": "Вахш", "academic_year": "2026-2027"}
    assert admin.put("/api/settings", json=dict(data, academic_year="2026-2026"), headers=headers).status_code == 422
    result = admin.put("/api/settings", json=data, headers=headers)
    assert result.status_code == 200
    assert result.json["settings"] == data
    assert "Мактаби санҷишӣ".encode() in admin.get("/").data


def test_empty_section_filter_distinguishes_unlettered_class(admin, headers, student):
    add(admin, headers, student)
    add(admin, headers, dict(student, name="Хонандаи синфи бе ҳарф", section=""))
    assert admin.get("/api/students?class_number=7").json["total"] == 2
    response = admin.get("/api/students?class_number=7&section=")
    assert response.json["total"] == 1
    assert response.json["students"][0]["section"] == ""
