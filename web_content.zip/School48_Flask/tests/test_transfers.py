import io
import json
import sqlite3
import zipfile

from docx import Document
from pypdf import PdfReader

from .conftest import add


def upload(admin, headers, payload, stage="preview", fingerprint=None):
    raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    data = {"file": (io.BytesIO(raw), "students.json")}
    if fingerprint:
        data["fingerprint"] = fingerprint
    return admin.post(f"/api/import/{stage}", data=data, headers=headers)


def test_legacy_import_preserves_all_fields_and_is_idempotent(admin, headers):
    old = [{"id": 123, "name": "Қодирзода Ҷамшед", "class": "7А", "gender": "Мард", "nation": "Тоҷик",
            "address": "Вахш", "phone": "901234567", "fatherJobName": "Қодирзода Исмоил", "fatherJob": "Омӯзгор",
            "motherJobName": "Ғаниева Маҳина", "motherJob": "Табиб", "studentPhone": "901234568"}]
    preview = upload(admin, headers, old).json
    assert preview["added"] == 1
    assert preview["sample"][0]["father_name"] == old[0]["fatherJobName"]
    assert upload(admin, headers, old, "commit", preview["fingerprint"]).json["added"] == 1
    assert upload(admin, headers, old, "commit", preview["fingerprint"]).json["skipped"] == 1
    student = admin.get("/api/students").json["students"][0]
    assert student["id"] == "123"
    assert student["section"] == "А"
    assert student["student_phone"] == "901234568"
    assert student["mother_job"] == "Табиб"
    assert admin.put("/api/students/123", json=dict(student, mother_job="Муҳосиб"), headers=headers).status_code == 200


def test_other_legacy_server_shape(admin, headers):
    old = {"students": [{"id": "legacy-uuid", "name": "Одинаев Сомон", "className": "11", "father": "Одинаев Меҳроб", "mother": "Одинаева Меҳрона"}]}
    preview = upload(admin, headers, old).json
    assert upload(admin, headers, old, "commit", preview["fingerprint"]).status_code == 200
    row = admin.get("/api/students").json["students"][0]
    assert row["father_name"] == "Одинаев Меҳроб"
    assert row["class_number"] == 11


def test_import_validation_is_atomic_and_fingerprint_is_checked(admin, headers, student):
    rows = [dict(student, id="okay"), dict(student, id="bad", class_number=30)]
    assert upload(admin, headers, rows).status_code == 422
    assert admin.get("/api/students").json["total"] == 0
    assert upload(admin, headers, [student], "commit", "wrong").status_code == 409
    assert upload(admin, headers, [{**student, "id": "same"}, {**student, "id": "same"}]).status_code == 422
    assert upload(admin, headers, {"not_students": []}).status_code == 422


def test_json_export_round_trip(admin, headers, student):
    add(admin, headers, student)
    backup = admin.get("/api/export/json").json
    assert backup["format"] == "school48"
    assert backup["students"][0]["mother_name"] == student["mother_name"]
    preview = upload(admin, headers, backup).json
    assert preview["skipped"] == 1


def test_csv_utf8_and_formula_protection(admin, headers, student):
    add(admin, headers, dict(student, name="=HYPERLINK(\"test\")"))
    response = admin.get("/api/export/csv")
    assert response.status_code == 200
    assert response.data.startswith(b"\xef\xbb\xbf")
    content = response.data.decode("utf-8-sig")
    assert "'=HYPERLINK" in content
    assert "'+992" in content
    assert "attachment" in response.headers["Content-Disposition"]


def test_real_pdf_and_docx_include_unicode_and_filtered_data(admin, headers, student):
    add(admin, headers, student)
    add(admin, headers, dict(student, name="Хонандаи дигар", class_number=3))
    pdf = admin.get("/api/export/pdf?class_number=7")
    assert pdf.status_code == 200 and pdf.data.startswith(b"%PDF")
    reader = PdfReader(io.BytesIO(pdf.data))
    content = "".join(page.extract_text() for page in reader.pages)
    assert student["name"] in content and student["mother_name"] in content
    assert "Хонандаи дигар" not in content
    word = admin.get("/api/export/docx?class_number=7")
    assert word.status_code == 200 and zipfile.is_zipfile(io.BytesIO(word.data))
    doc = Document(io.BytesIO(word.data))
    assert len(doc.tables[0].rows) == 2
    assert len(doc.tables[0].columns) == 12
    assert student["name"] in doc.tables[0].cell(1, 1).text


def test_sqlite_backup_is_valid_includes_committed_data(admin, headers, student, tmp_path):
    add(admin, headers, student)
    response = admin.get("/api/backup")
    assert response.status_code == 200 and response.data.startswith(b"SQLite format 3")
    destination = tmp_path / "backup.sqlite3"
    destination.write_bytes(response.data)
    conn = sqlite3.connect(destination)
    try:
        assert conn.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
        assert conn.execute("SELECT name FROM students").fetchone()[0] == student["name"]
        assert conn.execute("SELECT count(*) FROM users").fetchone()[0] == 1
    finally:
        conn.close()


def test_empty_exports_are_valid(admin):
    assert PdfReader(io.BytesIO(admin.get("/api/export/pdf").data)).pages
    assert len(Document(io.BytesIO(admin.get("/api/export/docx").data)).tables[0].rows) == 1
