import pytest
from werkzeug.security import check_password_hash

from school48.db import get_db
from .conftest import PASSWORD, token


@pytest.mark.parametrize("path", ["/api/students", "/api/summary", "/api/export/json", "/api/export/pdf", "/api/backup", "/api/trash"])
def test_all_personal_data_requires_authentication(client, path):
    response = client.get(path)
    assert response.status_code == 401
    assert "students" not in response.get_json()


def test_first_setup_is_local_and_validated(client):
    assert client.get("/").location == "/setup"
    assert client.get("/setup", environ_overrides={"REMOTE_ADDR": "192.168.1.20"}).status_code == 403
    client.get("/setup")
    response = client.post("/setup", data={"csrf_token": token(client), "username": "admin", "password": "48", "password_confirm": "48"})
    assert response.status_code == 422
    assert client.post("/setup", data={"username": "admin"}).status_code == 403


def test_setup_uses_hash_and_has_no_reusable_default(app, admin):
    with app.app_context():
        row = get_db().execute("SELECT * FROM users").fetchone()
        assert row["password_hash"] != PASSWORD
        assert check_password_hash(row["password_hash"], PASSWORD)
        assert not check_password_hash(row["password_hash"], "48")
    assert admin.get("/setup").status_code == 302
    assert admin.get("/").status_code == 200


@pytest.mark.parametrize("method,path", [("post", "/api/students"), ("put", "/api/settings"), ("delete", "/api/students/missing"), ("post", "/api/import/commit")])
def test_mutations_require_csrf(admin, method, path):
    assert getattr(admin, method)(path, json={}).status_code == 403


def test_logout_revokes_old_cookie(app, admin):
    old_cookie = admin.get_cookie("school48_session").value
    csrf = token(admin)
    assert admin.post("/logout", data={"csrf_token": csrf}).status_code == 302
    replay = app.test_client()
    replay.set_cookie("school48_session", old_cookie)
    assert replay.get("/api/students").status_code == 401


def test_login_and_throttling(admin):
    admin.post("/logout", data={"csrf_token": token(admin)})
    admin.get("/login")
    for _ in range(8):
        response = admin.post("/login", data={"csrf_token": token(admin), "username": "admin", "password": "incorrect"})
        assert response.status_code == 401
    blocked = admin.post("/login", data={"csrf_token": token(admin), "username": "admin", "password": PASSWORD})
    assert blocked.status_code == 429
    assert int(blocked.headers["Retry-After"]) > 0


def test_password_change_revokes_sessions_and_rotates_csrf(app, admin, headers):
    old_cookie = admin.get_cookie("school48_session").value
    result = admin.put("/api/password", json={"current_password": PASSWORD, "password": "New-strong-pass48", "password_confirm": "New-strong-pass48"}, headers=headers)
    assert result.status_code == 200
    assert result.json["csrf_token"] != headers["X-CSRF-Token"]
    replay = app.test_client()
    replay.set_cookie("school48_session", old_cookie)
    assert replay.get("/api/students").status_code == 401
    assert admin.get("/api/students").status_code == 200
    admin.post("/logout", data={"csrf_token": token(admin)})
    admin.get("/login")
    response = admin.post("/login", data={"csrf_token": token(admin), "username": "admin", "password": "New-strong-pass48"})
    assert response.status_code == 302


def test_response_security_headers(admin):
    response = admin.get("/")
    assert response.headers["Cache-Control"] == "no-store"
    assert "script-src 'self'" in response.headers["Content-Security-Policy"]
    assert response.headers["X-Frame-Options"] == "DENY"
    assert response.headers["X-Content-Type-Options"] == "nosniff"
    assert "Access-Control-Allow-Origin" not in response.headers


def test_non_ascii_csrf_is_rejected_without_server_error(admin):
    assert admin.post("/logout", data={"csrf_token": "нишонаи нодуруст"}).status_code == 403
