import re

import pytest

from school48 import create_app

PASSWORD = "Testing-school48!"


def token(client):
    with client.session_transaction() as session:
        return session["csrf_token"]


@pytest.fixture
def app(tmp_path):
    return create_app({"TESTING": True, "INSTANCE_PATH": str(tmp_path / "instance"),
                       "SECRET_KEY": "only-for-tests-school48-secret-key"})


@pytest.fixture
def client(app):
    return app.test_client()


@pytest.fixture
def admin(client):
    client.get("/setup")
    result = client.post("/setup", data={"csrf_token": token(client), "username": "admin",
                         "display_name": "Маъмури санҷишӣ", "password": PASSWORD, "password_confirm": PASSWORD})
    assert result.status_code == 302
    return client


@pytest.fixture
def headers(admin):
    return {"X-CSRF-Token": token(admin)}


@pytest.fixture
def student():
    return {"name": "Ҳусейнов Ҷамшед", "class_number": 7, "section": "А", "gender": "Мард",
            "nation": "Тоҷик", "address": "Ноҳияи Вахш, кӯчаи Сино 48", "phone": "+992 90 123 45 67",
            "father_name": "Ҳусейнов Қодир", "father_job": "Омӯзгор", "mother_name": "Ғаниева Маҳина",
            "mother_job": "Табиб", "student_phone": "901234568"}


def add(client, headers, payload):
    response = client.post("/api/students", json=payload, headers=headers)
    assert response.status_code == 201, response.get_json()
    return response.get_json()["student"]
