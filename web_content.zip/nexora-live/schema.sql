-- NEXORA complete relational database schema

CREATE INDEX idx_events_type ON analytics_events(event_type);

CREATE INDEX idx_messages_receiver ON messages(receiver_id);

CREATE INDEX idx_notifications_user ON notifications(user_id);

CREATE INDEX idx_orders_buyer ON orders(buyer_id);

CREATE INDEX idx_orders_seller ON orders(seller_id);

CREATE INDEX idx_orders_status ON orders(status);

CREATE INDEX idx_payments_order ON payments(order_id);

CREATE INDEX idx_products_category ON products(category_id);

CREATE INDEX idx_products_seller ON products(seller_id);

CREATE TABLE addresses(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,label TEXT,address_text TEXT NOT NULL,city TEXT,lat REAL,lng REAL,is_default INTEGER DEFAULT 0,created_at TEXT NOT NULL,FOREIGN KEY(user_id) REFERENCES users(id));

CREATE TABLE analytics_events(id TEXT PRIMARY KEY,user_id TEXT,event_type TEXT NOT NULL,product_id TEXT,order_id TEXT,metadata_json TEXT,created_at TEXT NOT NULL,FOREIGN KEY(user_id) REFERENCES users(id),FOREIGN KEY(product_id) REFERENCES products(id),FOREIGN KEY(order_id) REFERENCES orders(id));

CREATE TABLE audit_log(id TEXT PRIMARY KEY,actor_id TEXT,action TEXT NOT NULL,entity_type TEXT,entity_id TEXT,meta_json TEXT,created_at TEXT NOT NULL,FOREIGN KEY(actor_id) REFERENCES users(id));

CREATE TABLE cart_items(id TEXT PRIMARY KEY,cart_id TEXT NOT NULL,product_id TEXT NOT NULL,quantity INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL,UNIQUE(cart_id,product_id),FOREIGN KEY(cart_id) REFERENCES carts(id) ON DELETE CASCADE,FOREIGN KEY(product_id) REFERENCES products(id));

CREATE TABLE carts(id TEXT PRIMARY KEY,user_id TEXT UNIQUE NOT NULL,created_at TEXT NOT NULL,updated_at TEXT,FOREIGN KEY(user_id) REFERENCES users(id));

CREATE TABLE categories(id TEXT PRIMARY KEY,name TEXT UNIQUE NOT NULL,parent_id TEXT,status TEXT NOT NULL DEFAULT 'active',FOREIGN KEY(parent_id) REFERENCES categories(id));

CREATE TABLE deliveries(id TEXT PRIMARY KEY,order_id TEXT UNIQUE NOT NULL,status TEXT NOT NULL DEFAULT 'pending',courier_name TEXT,courier_phone TEXT,region TEXT,address_text TEXT,lat REAL,lng REAL,estimated_at TEXT,delivered_at TEXT,created_at TEXT NOT NULL,updated_at TEXT,FOREIGN KEY(order_id) REFERENCES orders(id));

CREATE TABLE expenses(id TEXT PRIMARY KEY,title TEXT NOT NULL,amount REAL NOT NULL,category TEXT,notes TEXT,created_at TEXT NOT NULL);

CREATE TABLE favorites(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,product_id TEXT NOT NULL,created_at TEXT NOT NULL,UNIQUE(user_id,product_id),FOREIGN KEY(user_id) REFERENCES users(id),FOREIGN KEY(product_id) REFERENCES products(id));

CREATE TABLE fraud_flags(id TEXT PRIMARY KEY,user_id TEXT,order_id TEXT,payment_id TEXT,signal TEXT NOT NULL,risk_level TEXT NOT NULL,action TEXT,status TEXT NOT NULL DEFAULT 'open',created_at TEXT NOT NULL,FOREIGN KEY(user_id) REFERENCES users(id),FOREIGN KEY(order_id) REFERENCES orders(id),FOREIGN KEY(payment_id) REFERENCES payments(id));

CREATE TABLE messages(id TEXT PRIMARY KEY,sender_id TEXT NOT NULL,receiver_id TEXT NOT NULL,order_id TEXT,body TEXT NOT NULL,read_at TEXT,created_at TEXT NOT NULL,FOREIGN KEY(sender_id) REFERENCES users(id),FOREIGN KEY(receiver_id) REFERENCES users(id),FOREIGN KEY(order_id) REFERENCES orders(id));

CREATE TABLE notifications(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,title TEXT NOT NULL,body TEXT,read_at TEXT,created_at TEXT NOT NULL,FOREIGN KEY(user_id) REFERENCES users(id));

CREATE TABLE orders(id TEXT PRIMARY KEY,buyer_id TEXT NOT NULL,product_id TEXT NOT NULL,seller_id TEXT NOT NULL,quantity INTEGER NOT NULL,unit_price REAL NOT NULL,amount REAL NOT NULL,commission REAL NOT NULL,seller_net REAL NOT NULL,status TEXT NOT NULL,delivery_address_id TEXT,delivery_text TEXT,delivery_lat REAL,delivery_lng REAL,created_at TEXT NOT NULL,updated_at TEXT,FOREIGN KEY(buyer_id) REFERENCES users(id),FOREIGN KEY(product_id) REFERENCES products(id),FOREIGN KEY(seller_id) REFERENCES sellers(id),FOREIGN KEY(delivery_address_id) REFERENCES addresses(id));

CREATE TABLE payments(id TEXT PRIMARY KEY,order_id TEXT NOT NULL,method TEXT NOT NULL,amount REAL NOT NULL,status TEXT NOT NULL,provider_reference TEXT,created_at TEXT NOT NULL,updated_at TEXT,FOREIGN KEY(order_id) REFERENCES orders(id));

CREATE TABLE platform_settings(key TEXT PRIMARY KEY,value TEXT NOT NULL,updated_at TEXT NOT NULL);

CREATE TABLE products(id TEXT PRIMARY KEY,seller_id TEXT NOT NULL,category_id TEXT,name TEXT NOT NULL,description TEXT,price REAL NOT NULL,stock INTEGER NOT NULL DEFAULT 0,condition TEXT DEFAULT 'new',image_url TEXT,status TEXT NOT NULL DEFAULT 'active',views INTEGER DEFAULT 0,created_at TEXT NOT NULL,updated_at TEXT,FOREIGN KEY(seller_id) REFERENCES sellers(id),FOREIGN KEY(category_id) REFERENCES categories(id));

CREATE TABLE returns(id TEXT PRIMARY KEY,order_id TEXT NOT NULL,buyer_id TEXT NOT NULL,reason TEXT,amount REAL NOT NULL,status TEXT NOT NULL DEFAULT 'requested',decision TEXT,created_at TEXT NOT NULL,updated_at TEXT,FOREIGN KEY(order_id) REFERENCES orders(id),FOREIGN KEY(buyer_id) REFERENCES users(id));

CREATE TABLE reviews(id TEXT PRIMARY KEY,order_id TEXT NOT NULL,buyer_id TEXT NOT NULL,product_id TEXT NOT NULL,rating INTEGER NOT NULL,body TEXT,status TEXT NOT NULL DEFAULT 'published',created_at TEXT NOT NULL,FOREIGN KEY(order_id) REFERENCES orders(id),FOREIGN KEY(buyer_id) REFERENCES users(id),FOREIGN KEY(product_id) REFERENCES products(id));

CREATE TABLE security_settings(user_id TEXT PRIMARY KEY,two_factor_enabled INTEGER DEFAULT 0,last_login TEXT,failed_logins INTEGER DEFAULT 0,updated_at TEXT NOT NULL,FOREIGN KEY(user_id) REFERENCES users(id));

CREATE TABLE sellers(id TEXT PRIMARY KEY,user_id TEXT UNIQUE NOT NULL,store_name TEXT NOT NULL,description TEXT,status TEXT NOT NULL DEFAULT 'active',rating REAL DEFAULT 0,total_sales REAL DEFAULT 0,commission_rate REAL DEFAULT 0.10,created_at TEXT NOT NULL,FOREIGN KEY(user_id) REFERENCES users(id));

CREATE TABLE users(id TEXT PRIMARY KEY,name TEXT NOT NULL,email TEXT UNIQUE NOT NULL,password_hash TEXT,phone TEXT,role TEXT NOT NULL DEFAULT 'buyer',status TEXT NOT NULL DEFAULT 'active',verified INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL,last_login TEXT);

CREATE TABLE wallet_transactions(id TEXT PRIMARY KEY,wallet_id TEXT NOT NULL,type TEXT NOT NULL,amount REAL NOT NULL,reference_type TEXT,reference_id TEXT,description TEXT,created_at TEXT NOT NULL,FOREIGN KEY(wallet_id) REFERENCES wallets(id));

CREATE TABLE wallets(id TEXT PRIMARY KEY,user_id TEXT UNIQUE NOT NULL,balance REAL NOT NULL DEFAULT 0,pending REAL NOT NULL DEFAULT 0,earnings REAL NOT NULL DEFAULT 0,fees REAL NOT NULL DEFAULT 0,updated_at TEXT NOT NULL,FOREIGN KEY(user_id) REFERENCES users(id));