import Database from 'better-sqlite3';
import pg from 'pg';
import fs from 'fs';
const {Client}=pg;
const src=process.env.SQLITE_PATH||'./nexora.db';
const url=process.env.DATABASE_URL;
if(!url) throw new Error('DATABASE_URL is required');
const sqlite=new Database(src,{readonly:true});
const client=new Client({connectionString:url});
await client.connect();
await client.query(fs.readFileSync(new URL('./schema-postgres.sql',import.meta.url),'utf8'));
const tables=['users','categories','sellers','products','carts','cart_items','addresses','orders','payments','wallets','wallet_transactions','deliveries','messages','notifications','reviews','favorites','audit_log','analytics_events','returns','expenses','platform_settings','security_settings','fraud_flags','otp_codes','product_images','payment_webhooks','payout_jobs'];
for(const table of tables){const rows=sqlite.prepare(`SELECT * FROM ${table}`).all(); if(!rows.length) continue; const cols=Object.keys(rows[0]); for(const row of rows){const values=cols.map(c=>row[c]); const placeholders=values.map((_,i)=>'$'+(i+1)).join(','); await client.query(`INSERT INTO ${table} (${cols.join(',')}) VALUES (${placeholders}) ON CONFLICT DO NOTHING`,values)} console.log(table,rows.length)}
await client.end(); sqlite.close(); console.log('Migration complete');
