// Online-only service worker: intentionally does not cache application/API data.
self.addEventListener('install',()=>self.skipWaiting());
self.addEventListener('activate',e=>e.waitUntil(self.clients.claim()));
self.addEventListener('fetch',e=>{
  if(new URL(e.request.url).pathname.startsWith('/api/')) return;
  // Network-first; no offline application cache is created.
});
self.addEventListener('push',e=>{
  let data={title:'NEXORA',body:'لديك تحديث جديد'};
  try{data=Object.assign(data,e.data?.json()||{})}catch{}
  e.waitUntil(self.registration.showNotification(data.title,{body:data.body,icon:'/icon-192.png',data:data.url||'/'}));
});
self.addEventListener('notificationclick',e=>{e.notification.close();e.waitUntil(clients.openWindow(e.notification.data||'/'))});
